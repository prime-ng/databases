# Final Audit — SyllabusBooks / BookController

**Audited:** 2026-10-28 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/SyllabusBooks/app/Http/Controllers/BookController.php` (1,136 lines, 15 public methods + 5 private helpers)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /syllabus-books/books` (redirect to the Books tab) · `/books/create` · `POST /books` · `/books/{book}` · `/books/{book}/edit` · `PUT` · `DELETE` · `/books/trash/view` · `/books/{id}/restore` · `DELETE /books/{id}/force-delete` · `POST /books/{book}/toggle-status` · `GET /syllabus-books/get-subjects-by-class` · `POST /books/validate-import` · `POST /books/start-import` · `GET /books/download-template` |
| Menu path | Syllabus Books → Books tab; the create/edit pages are their own screens |
| Who uses it | Roles holding `tenant.syllabus-books.book.viewAny/create/update/delete/restore/forceDelete` (`config/permissionslist.php:1013`). |
| What a user does here | Catalogue a prescribed book: title, ISBN, publisher, year, pages, language, tags, cover image, eBook PDF, chapter-ready author links, class/subject mappings with primary/mandatory flags, and up to twenty attached files. The same screen edits a book, removes an attached file, and bulk-imports a whole catalogue from Excel. |
| Tables written | `slb_books`, `slb_book_author_jnt`, `slb_book_class_subject_jnt`, `slb_book_files`, `media_files`, activity log |
| Tables read | `slb_books`, `slb_book_authors`, `slb_book_author_jnt`, `slb_book_class_subject_jnt`, `slb_book_chapters`, `slb_book_files`, `sch_classes`, `sch_subjects`, `sch_subject_groups`, `sch_subject_study_format_jnt`, `sch_class_groups_jnt`, `org_academic_sessions`, `sys_dropdown_table` |
| Live data | `slb_books` = 86, `slb_book_author_jnt` = 89, `slb_book_files` = 8, `slb_book_chapters` = 324, `sys_dropdown_table` key `slb_books.language` = 6 rows (key `language` = 0) on `test.localhost` (tinker SELECT, 2026-10-28) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. The edit form's language dropdown queries a dropdown key that has **no rows**, so every edit shows an empty language list, and an eBook replacement deletes the old PDF before the new one is stored. Every failure path still sends the SQL error to the user, and the controller is a 1,136-line god controller with a 224-line `store()`. Effort: two days (L) plus a deferred split.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 3 | 5 | 2 | 1 | 11 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BOK-02, BOK-05 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | BOK-04, BOK-07 | F9 Queries/Perf | BOK-06 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | BOK-10, BOK-11 |
| F6 Controller shape | BOK-01, BOK-08, BOK-09 | F13 Deep read | BOK-03, BOK-04 |
| F7 Models | BOK-03 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php` | controller | 1136 | this report | ✅ |
| 2 | `Modules/SyllabusBooks/app/Http/Requests/BookRequest.php` | FormRequest | 161 | this report | ✅ |
| 3 | `Modules/SyllabusBooks/app/Models/BokBook.php` | model | 140 | ↗ tarun/StudentPortal-done/StudentPortalController — linked | ↗ linked |
| 4 | `Modules/SyllabusBooks/app/Models/BookAuthors.php` | model | 30 | ↗ [gaurav/SyllabusBooks/AuthorController](../AuthorController/01-report.md) | ↗ linked |
| 5 | `Modules/SyllabusBooks/app/Models/BookAuthorJnt.php` | model | 42 | ↗ [gaurav/SyllabusBooks/BookController](01-report.md) | ✅ |
| 6 | `Modules/SyllabusBooks/app/Models/BookClassSubject.php` | model | 64 | ↗ tarun/StudentPortal-done/MobilePrescribedBooksController — linked | ↗ linked |
| 7 | `Modules/SyllabusBooks/app/Models/BookFile.php` | model | 72 | ↗ tarun/StudentPortal-done/MobilePrescribedBooksController — linked | ↗ linked |
| 8 | `Modules/SyllabusBooks/app/Models/BookChapter.php` | model | 43 | ↗ tarun/StudentPortal-done — linked | ↗ linked |
| 9 | `Modules/SyllabusBooks/app/Policies/BookPolicy.php` | policy | 65 | ↗ [gaurav/SyllabusBooks/BookController](01-report.md) | ✅ |
| 10 | `Modules/SyllabusBooks/app/Policies/BookDownloadPolicy.php` | policy | 19 | ↗ [gaurav/SyllabusBooks/BookController](01-report.md) | ✅ |
| 11 | `Modules/SyllabusBooks/app/Imports/BookImport.php` | import | 153 | ↗ [gaurav/SyllabusBooks/BookController](01-report.md) | ✅ |
| 12 | `Modules/SyllabusBooks/app/Imports/BookReadOnly.php` | import | 16 | ↗ [gaurav/SyllabusBooks/BookController](01-report.md) | ✅ |
| 13 | `Modules/SyllabusBooks/resources/views/book/index.blade.php` | blade | 762 | this report | ✅ |
| 14 | `Modules/SyllabusBooks/resources/views/book/create.blade.php` | blade | 746 | this report | ✅ |
| 15 | `Modules/SyllabusBooks/resources/views/book/edit.blade.php` | blade | 644 | this report | ✅ |
| 16 | `Modules/SyllabusBooks/resources/views/book/show.blade.php` | blade | 369 | this report | ✅ |
| 17 | `Modules/SyllabusBooks/resources/views/book/trash.blade.php` | blade | 161 | this report | ✅ |
| 18 | `Modules/SyllabusBooks/resources/views/book/_files_tab.blade.php` | blade partial | 73 | ↗ [gaurav/SyllabusBooks/BookFileController](../BookFileController/01-report.md) | ↗ linked |
| 19 | `Modules/SyllabusBooks/resources/views/book/_chapters_tab.blade.php` | blade partial | 81 | ↗ [gaurav/SyllabusBooks/BookChapterController](../BookChapterController/01-report.md) | ↗ linked |

No pre-applied files.

## 4. Routes

```
GET|HEAD  syllabus-books/books                          syllabus-books.books.index            Modules\SyllabusBooks\Http\Controllers\BookController@index
POST      syllabus-books/books                          syllabus-books.books.store            Modules\SyllabusBooks\Http\Controllers\BookController@store
GET|HEAD  syllabus-books/books/create                   syllabus-books.books.create           Modules\SyllabusBooks\Http\Controllers\BookController@create
GET|HEAD  syllabus-books/books/download-template        syllabus-books.books.download-template Modules\SyllabusBooks\Http\Controllers\BookController@downloadTemplate
POST      syllabus-books/books/start-import             syllabus-books.books.start-import     Modules\SyllabusBooks\Http\Controllers\BookController@startImport
GET|HEAD  syllabus-books/books/trash/view               syllabus-books.books.trashed          Modules\SyllabusBooks\Http\Controllers\BookController@trashedBook
POST      syllabus-books/books/validate-import          syllabus-books.books.validate-import  Modules\SyllabusBooks\Http\Controllers\BookController@validateImport
GET|HEAD  syllabus-books/books/{book}                   syllabus-books.books.show             Modules\SyllabusBooks\Http\Controllers\BookController@show
PUT|PATCH syllabus-books/books/{book}                   syllabus-books.books.update           Modules\SyllabusBooks\Http\Controllers\BookController@update
DELETE    syllabus-books/books/{book}                   syllabus-books.books.destroy          Modules\SyllabusBooks\Http\Controllers\BookController@destroy
GET|HEAD  syllabus-books/books/{book}/edit              syllabus-books.books.edit             Modules\SyllabusBooks\Http\Controllers\BookController@edit
POST      syllabus-books/books/{book}/toggle-status     syllabus-books.books.toggleStatus     Modules\SyllabusBooks\Http\Controllers\BookController@toggleStatus
DELETE    syllabus-books/books/{id}/force-delete        syllabus-books.books.forceDelete      Modules\SyllabusBooks\Http\Controllers\BookController@forceDelete
GET|HEAD  syllabus-books/books/{id}/restore             syllabus-books.books.restore          Modules\SyllabusBooks\Http\Controllers\BookController@restore
GET|HEAD  syllabus-books/get-subjects-by-class          syllabus-books.getSubjectsByClass     Modules\SyllabusBooks\Http\Controllers\BookController@getSubjectsByClass
```

Unrouted public methods: none.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 30 | GET books | `...book.viewAny` | none (read) | none | — | — |
| `create` | 48 | GET books/create | `...book.create` | none (read) | none | — | BOK-10 |
| `store` | 95 | POST books | `...book.create` | controller (`:127`) | 'Created' (outside) | `slb_books`, `slb_book_author_jnt`, `slb_book_class_subject_jnt`, `media_files` | BOK-01, BOK-02, BOK-05, BOK-06, BOK-07 |
| `getSubjectsByClass` | 320 | GET get-subjects-by-class | `...book.viewAny` | none (read) | none | — | BOK-02, BOK-05 |
| `show` | 367 | GET books/{book} | `...book.view` | none (read) | none | — | BOK-09 |
| `edit` | 387 | GET books/{book}/edit | `...book.update` | none (read) | none | — | BOK-03 |
| `update` | 421 | PUT books/{book} | `...book.update` | controller (`:438`) | 'Updated' (outside) | same as store | BOK-01, BOK-02, BOK-04, BOK-05, BOK-06, BOK-07 |
| `trashedBook` | 711 | GET books/trash/view | `...book.restore` | none (read) | none | — | — |
| `destroy` | 729 | DELETE books/{book} | `...book.delete` | controller (`:736`) | 'Trashed' | `slb_books` | BOK-02, BOK-05 |
| `restore` | 758 | GET books/{id}/restore | `...book.restore` | controller (`:765`) | 'Restored' | `slb_books` | BOK-02, BOK-05 |
| `forceDelete` | 785 | DELETE books/{id}/force-delete | `...book.forceDelete` | controller (`:792`) | 'Deleted' | `slb_books`, `slb_book_files`, `media_files` | BOK-02, BOK-04, BOK-05 |
| `toggleStatus` | 830 | POST books/{book}/toggle-status | `...book.update` | controller (`:835`) | 'Toggled' | `slb_books` | BOK-02, BOK-05 |
| `validateImport` | 860 | POST books/validate-import | `...book.create` | none | none | — | BOK-02, BOK-05 |
| `startImport` | 977 | POST books/start-import | `...book.create` | controller (`:994`) | none | `slb_books`, junctions | BOK-02, BOK-05 |
| `downloadTemplate` | 1023 | GET books/download-template | `...book.create` | none | none | — | — |

## 6. Findings

### F1 — Errors

#### BOK-02 · B · ERR-01 — the SQL error text is returned to the user on nine paths

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:287-296` (`store`), `:358-360` (`getSubjectsByClass`), `:577-589` (`update`), `:751-755` (`destroy`), `:778-782` (`restore`), `:822-826` (`forceDelete`), `:849-853` (`toggleStatus`), `:965-970` (`validateImport`), `:1008-1013` (`startImport`) |
| **Root cause** | Each catch returns `$e->getMessage()` in a flash, a JSON body or a `detail` field; `store` even sanitises it for UTF-8 and still shows it. |
| **Consequence** | A user reads the failing SQL, table and column names; for the import endpoints the JSON body carries the driver error verbatim. |
| **Reproduce** | Import a workbook whose `class` column matches no class, then call `start-import`: the JSON `message` contains the driver text. |
| **Fix approach** | Replace every user-facing exception string with a fixed message and log the exception object (BOK-05 covers the catch shape). |
| **Plan item** | BOK-02 in `02-fix-plan.md` §1 |

```php
                $safeMessage = $this->sanitizeUtf8($e->getMessage());

                if ($request->expectsJson()) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Book could not be saved because a file attachment failed. Please try again.',
                        'detail'  => $safeMessage,
                    ], 500);
                }

                return redirect()->back()
                    ->withInput()
                    ->withErrors(['book_files' => 'File attachment failed: ' . $safeMessage]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/SyllabusBooks/app/Http/Controllers/BookController.php
228:            if (str_contains($e->getMessage(), 'Duplicate entry') &&
229:                str_contains($e->getMessage(), 'slb_book_author_jnt.PRIMARY')) {
262:                    'error'   => $e->getMessage(),
280:                    'cleanup_err' => $cleanupEx->getMessage(),
287:                $safeMessage = $this->sanitizeUtf8($e->getMessage());
359:            \Log::error('Error in getSubjectsByClass: ' . $e->getMessage());
360:            return response()->json(['error' => $e->getMessage()], 500);
542:            if (str_contains($e->getMessage(), 'Duplicate entry') && str_contains($e->getMessage(), 'slb_book_author_jnt.PRIMARY')) {
582:                'error'   => $e->getMessage(),
587:                ->withErrors(['book_files' => 'File attachment failed: ' . $e->getMessage()]);
754:                ->with('error', 'Failed to delete book: ' . $e->getMessage());
781:                ->with('error', 'Failed to restore book: ' . $e->getMessage());
822:                ->with('error', 'Failed to permanently delete book: ' . $e->getMessage());
826:                ->with('error', 'An error occurred while permanently deleting book: ' . $e->getMessage());
852:                'message' => 'Failed to update book status: ' . $e->getMessage(),
966:            \Log::error('Book import validation failed: ' . $e->getMessage());
969:                'message' => 'Validation error: ' . $e->getMessage(),
1009:            \Log::error('Book import failed: ' . $e->getMessage());
1012:                'message' => 'Import failed: ' . $e->getMessage(),
```

#### BOK-05 · M · ERR-00 — ten methods carry their own try/catch, including `QueryException`

| Field | Value |
|---|---|
| **Rule** | ERR-00 as settled by D1/D2 (M) — *no try/catch in controllers; never catch `QueryException` (it extends `RuntimeException`)* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:126`, `:225-231`, `:243-296`, `:323-361`, `:437`, `:539-545`, `:577-589`, `:735-755`, `:764-782`, `:791-826`, `:834-853`, `:864-970`, `:992-1013` |
| **Root cause** | The controller hand-rolls error handling for writes, reads and both import endpoints, and catches `QueryException` to translate one duplicate-author case. |
| **Consequence** | Twelve catch sites drift from the central renderer; real 500s become 302s, and the duplicate-author translation duplicates a rule the FormRequest could own. |
| **Reproduce** | static only — `grep -c "catch ("` returns 12. |
| **Fix approach** | Remove the catches and let the central handler log and render; move the duplicate-author check into `BookRequest` if it must stay user-facing. Deferred with the split (plan §10). |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
        } catch (\Illuminate\Validation\ValidationException $e) {
            throw $e;
        } catch (\Illuminate\Database\QueryException $e) {
            if (str_contains($e->getMessage(), 'Duplicate entry') &&
                str_contains($e->getMessage(), 'slb_book_author_jnt.PRIMARY')) {
                throw ValidationException::withMessages([
                    'authors' => ['Duplicate author entries detected. Please check your author selections.'],
                ]);
            }
            throw $e;
        }
```

**Evidence**
```
$ grep -c "catch (" Modules/SyllabusBooks/app/Http/Controllers/BookController.php
12
$ grep -n "catch (\\\\Illuminate\\\\Database\\\\QueryException" Modules/SyllabusBooks/app/Http/Controllers/BookController.php
227:        } catch (\Illuminate\Database\QueryException $e) {
541:        } catch (\Illuminate\Database\QueryException $e) {
814:        } catch (\Illuminate\Database\QueryException $e) {
```

### F2 — Transactions and audit

#### BOK-04 · H · TXN-03 — replacing an eBook deletes the old PDF before the new one is stored

| Field | Value |
|---|---|
| **Rule** | TXN-03 (H, lowered from B: the path needs a file upload, but the loss is permanent) — *no irreversible side effect before the write succeeds* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:555-558`, method `update()` |
| **Root cause** | `clearMediaCollection('ebook')` runs before `addMediaFromRequest('ebook_file')`. The collection is not registered `singleFile()` on `BokBook` for the `ebook` name, so the explicit clear is needed — but it leaves a window where the old PDF is gone and the new one is not stored. `deleteBookFiles()` (`:683-694`) has the same order for attached files. |
| **Consequence** | A failed upload during an edit permanently removes the book's eBook PDF; the book keeps its row and its students lose the file. |
| **Reproduce** | Edit a book that has an eBook, choose a PDF, and make the upload fail (disk full or a file over the 50 MB rule triggered after the form). The old eBook is gone. |
| **Fix approach** | Upload the new file first, then clear the old collection; for the delete path, soft-delete the row first and clear media after commit. |
| **Plan item** | BOK-04 in `02-fix-plan.md` §1 |

```php
        if ($request->hasFile('ebook_file')) {
            $book->clearMediaCollection('ebook');
            $book->addMediaFromRequest('ebook_file')->toMediaCollection('ebook');
        }
```

**Evidence**
```
$ sed -n '553,558p' Modules/SyllabusBooks/app/Http/Controllers/BookController.php
        if ($request->hasFile('ebook_file')) {
            $book->clearMediaCollection('ebook');
            $book->addMediaFromRequest('ebook_file')->toMediaCollection('ebook');
        }
$ sed -n '683,694p' Modules/SyllabusBooks/app/Http/Controllers/BookController.php
    private function deleteBookFiles(BokBook $book, array $ids): void
    {
        if (empty($ids)) {
            return;
        }

        $files = $book->files()->whereIn('id', $ids)->get();
        foreach ($files as $bookFile) {
            $bookFile->clearMediaCollection(BookFile::MEDIA_FILE);
            $bookFile->delete();
        }
    }
```

#### BOK-07 · M · TXN-04 — the create and update logs are written outside the transaction

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:303` and `:590` |
| **Root cause** | Both log calls sit after the transaction closure, and after the file phase in `store()`. |
| **Consequence** | A file-phase failure in `store()` rolls the book back but the "Created" log is only reached when it succeeds, while an `update` that fails on file attachment still exits before the log — the pairing is inconsistent, and a rollback after the log is impossible to distinguish. |
| **Reproduce** | static only — the `activityLog` calls are outside every `DB::transaction` closure. |
| **Fix approach** | Move the log inside the closure, after the last DB write. |
| **Plan item** | BOK-07 in `02-fix-plan.md` §3 |

```php
        activityLog($book, 'Created', ['message' => 'Book created.']);
```

**Evidence**
```
$ grep -n "DB::transaction\|activityLog" Modules/SyllabusBooks/app/Http/Controllers/BookController.php
127:            DB::transaction(function () use ($request, &$book) {
303:        activityLog($book, 'Created', ['message' => 'Book created.']);
438:            DB::transaction(function () use ($request, $book) {
590:        activityLog($book, 'Updated', ['message' => 'Book updated.']);
```

### F3 — Authorization

clean — every routed action authorizes first with a name declared at `config/permissionslist.php:1013`; `show`, `edit`, `update`, `destroy`, `toggleStatus` bind or authorize before loading. The policy is registered (`SyllabusBooksServiceProvider.php:69`) and the permission strings match the seeded keys.

### F4 — Validation and input

clean — `BookRequest.php:27-72` types every field, validates uploads with `file`+`mimes`+`max` (`cover 2 MB`, `ebook 50 MB`, `book_files` 20 rows with the configured book size), mirrors ISBN uniqueness with the model id, and drops empty repeater rows in `prepareForValidation()`; `store`/`update` write `validated()` values only.

### F5 — Routes

clean — fifteen routes, all resolve to existing methods; `books/download-template` and the import routes are registered before `Route::resource('books')` (`routes/web.php:36-48`), so they are not captured by `{book}`; the AJAX route sits before the resource too.

### F6 — Controller shape

#### BOK-01 · H · CTL-02 — `store()` is 224 lines and `update()` is 178

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — *methods over 150 lines are H; over 80 extract* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:95-318` (`store`, 224 lines) and `:421-598` (`update`, 178 lines) |
| **Root cause** | Both methods inline validation prep, book creation, author junction inserts, class/subject junction inserts, cover and eBook uploads, attached-file upserts, primary demotion and error translation. |
| **Consequence** | Every change to the book form is edited in two 200-line methods that must stay in step; the 20-line difference between them is a copy-paste risk. |
| **Reproduce** | static only — line spans measured with `awk 'NR>=95 && NR<=318' | wc -l` → 224. |
| **Fix approach** | Extract the author and class/subject writers into `BookService` and call them from both methods (a split, deferred per D3). |
| **Plan item** | BOK-01 in `02-fix-plan.md` §9 (DECISION — extraction/split) |

```php
    public function store(BookRequest $request)
    {
        Gate::authorize('tenant.syllabus-books.book.create');

        Validator::make($request->all(), [
            'class_subjects.*.academic_session_id' => [
```

**Evidence**
```
$ awk 'NR>=95 && NR<=318' Modules/SyllabusBooks/app/Http/Controllers/BookController.php | wc -l
     224
$ awk 'NR>=421 && NR<=598' Modules/SyllabusBooks/app/Http/Controllers/BookController.php | wc -l
     178
$ grep -nE 'public function [a-zA-Z_]+' Modules/SyllabusBooks/app/Http/Controllers/BookController.php | wc -l
     20
```

#### BOK-08 · M · DECISION · CTL-01 — a 1,136-line controller

| Field | Value |
|---|---|
| **Rule** | CTL-01 (M) — *over 1,000 lines or 25 public methods → split by resource/responsibility* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php` (1,136 lines, 15 public + 5 private methods) |
| **Root cause** | CRUD, the author/class-subject writers, file attachment and the Excel import/export all live in one class. |
| **Consequence** | The file cannot be read in one pass; shared helpers (`sanitizeUtf8`, `attachBookFiles`) are private to it, so the BookFileController has a second copy of the attach logic. |
| **Reproduce** | `wc -l Modules/SyllabusBooks/app/Http/Controllers/BookController.php` → 1136. |
| **Fix approach** | Split into BookCrud / BookImport / BookFile concerns; D3 defers the split, so this is a DECISION. |
| **Plan item** | BOK-08 in `02-fix-plan.md` §9 (DECISION — deferred split) |

```php
class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
```

**Evidence**
```
$ wc -l Modules/SyllabusBooks/app/Http/Controllers/BookController.php
    1136 Modules/SyllabusBooks/app/Http/Controllers/BookController.php
```

#### BOK-09 · M · CTL-03 — `show()` takes a raw id

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:367-381` |
| **Root cause** | The route is `books/{book}` but `show($id)` loads with `findOrFail`. |
| **Consequence** | No model policy or `withTrashed()` on the show path, unlike `edit`/`update`. |
| **Reproduce** | static only — compare `show($id)` with `edit(BokBook $book)` on the same parameter. |
| **Fix approach** | Bind `BokBook $book` and eager-load on it. |
| **Plan item** | BOK-09 in `02-fix-plan.md` §5 |

```php
    public function show($id)
    {
        Gate::authorize('tenant.syllabus-books.book.view');

        $book = BokBook::with([
```

**Evidence**
```
$ grep -n "public function show\|public function edit" Modules/SyllabusBooks/app/Http/Controllers/BookController.php
367:    public function show($id)
387:    public function edit(BokBook $book)
```

### F7 — Models

#### BOK-03 · H · MDL-09 — the edit form asks for a dropdown key that has no rows

| Field | Value |
|---|---|
| **Rule** | MDL-09 (H, raised from L: the edit screen loses the field's options) — *status/type strings are constants, not literals repeated across files* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:397` (compare `:52`) |
| **Root cause** | `create()` loads `Dropdown::where('key', 'slb_books.language')` (6 rows) while `edit()` loads `Dropdown::where('key', 'language')` (0 rows). The commented-out scaffolding at `:76` shows the old key. |
| **Consequence** | The language dropdown on the edit screen is empty, so an editor cannot see or set the language of an existing book; saving the form without touching it can wipe the value. |
| **Reproduce** | Open `/syllabus-books/books/{id}/edit`: the Language select has no options; `SELECT COUNT(*) FROM sys_dropdown_table WHERE key='language'` → 0. |
| **Fix approach** | Use the same key in both methods (or a model constant). |
| **Plan item** | BOK-03 in `02-fix-plan.md` §6 |

```php
        $languages = Dropdown::where('key', 'language')->get();
        $authors   = BookAuthors::where('is_active', 1)->get();
```

**Evidence**
```
$ grep -n "Dropdown::where" Modules/SyllabusBooks/app/Http/Controllers/BookController.php
52:        $languages = Dropdown::where('key', 'slb_books.language')->get();
76:    //     $languages = Dropdown::where('key', 'language')->get();
397:        $languages = Dropdown::where('key', 'language')->get();
$ php artisan tinker --execute='tenancy()->initialize(\Modules\Prime\Models\Domain::where("domain","test.localhost")->first()->tenant); echo "slb_books.language=".\DB::table("sys_dropdown_table")->where("key","slb_books.language")->count()." language=".\DB::table("sys_dropdown_table")->where("key","language")->count();'
slb_books.language=6 language=0
```

### F8 — Services and jobs

clean — no service or job is referenced; `BookImport` runs inside `DB::transaction` in `startImport` (`:994-996`) and stores ids, not models.

### F9 — Queries and performance

#### BOK-06 · M · QRY-07 — author and class/subject rows are inserted one statement at a time

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *bulk writes: `insert()`/`upsert()` instead of `create()`/`update()` per row in a loop* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:207` and `:210-219` (`store`), `:521` and `:524-533` (`update`), `:565-571` (book-file flags) |
| **Root cause** | For each class/subject row the controller demotes the old primary with one `UPDATE` and inserts with one statement; the book-file flags are updated row by row. Only the authors are batched. |
| **Consequence** | A book mapped to ten classes/subjects issues twenty statements inside the transaction; a form with twenty attached files issues twenty more. |
| **Reproduce** | static only — the `insert(['book_id' => …])` call is inside `foreach ($request->class_subjects as $cs)`. |
| **Fix approach** | Collect the rows and `insert()` once; demote primaries with one `whereIn` update per class/subject pair set. |
| **Plan item** | BOK-06 in `02-fix-plan.md` §6 |

```php
                        DB::table('slb_book_class_subject_jnt')->insert([
                            'book_id'             => $book->id,
                            'class_id'            => $cs['class_id'],
                            'subject_id'          => $cs['subject_id'],
                            'academic_session_id' => $sessionId,
                            'remarks'             => $cs['remarks'] ?? null,
                            'is_active'           => !empty($cs['is_active']),
                            'is_primary'          => !empty($cs['is_primary']),
                            'is_mandatory'        => !empty($cs['is_mandatory']),
                            'created_at'          => now(),
                            'updated_at'          => now(),
                        ]);
```

**Evidence**
```
$ grep -n "foreach (\$request->class_subjects\|slb_book_class_subject_jnt')->insert\|->update(\['is_primary'" Modules/SyllabusBooks/app/Http/Controllers/BookController.php
201:                if ($request->filled('class_subjects')) {
202:                    foreach ($request->class_subjects as $cs) {
210:                        DB::table('slb_book_class_subject_jnt')->insert([
449:                $book->update([
515:                if ($request->filled('class_subjects')) {
516:                    foreach ($request->class_subjects as $cs) {
524:                        DB::table('slb_book_class_subject_jnt')->insert([
```

### F10 — Views

clean — the five book blades render data passed in; the create/edit forms name the repeater fields the controller reads; `grep -nE "::where|DB::|->get\(\)" Modules/SyllabusBooks/resources/views/book/index.blade.php Modules/SyllabusBooks/resources/views/book/create.blade.php Modules/SyllabusBooks/resources/views/book/edit.blade.php Modules/SyllabusBooks/resources/views/book/show.blade.php Modules/SyllabusBooks/resources/views/book/trash.blade.php` → no output. No `{!! !!}` on user text (`grep -c '{!!'` → 0 in all five).

### F11 — Security and tenancy

clean apart from BOK-02 — uploads go through `addMedia` into `TenantMedia` (`BokBook` and `BookFile` both override `getMediaModel()`), no `env()`, no hard-coded ids. The import file is stored on the `local` disk under `imports/books`; the session key is per tenant domain.

### F12 — Style

#### BOK-10 · L · STY-02 — a commented-out `create()` block, no `strict_types`, not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean*; STY-01 — `declare(strict_types=1)`; STY-04 — *no commented-out code* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:74-91` (dead block), `:1-24` (header/imports) |
| **Root cause** | A 18-line commented-out `create()` duplicate remains; Pint reports seventeen fixers; no `declare(strict_types=1)`. |
| **Consequence** | Style only; the dead block suggests an alternative implementation that no longer exists. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookController.php` |
| **Fix approach** | Delete the dead block, add strict types, run Pint. |
| **Plan item** | BOK-10 in `02-fix-plan.md` §8 |

```php
    // public function create()
    // {
    //     $languages = Dropdown::where('key', 'language')->get();
    //     $authors   = BookAuthors::where('is_active', 1)->get();
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Http\/Controllers\/BookController.php","fixers":["class_attributes_separation","new_with_parentheses","single_space_around_construct","function_declaration","single_quote","fully_qualified_strict_types","control_structure_braces","concat_space","trailing_comma_in_multiline","unary_operator_spaces","braces_position","statement_indentation","not_operator_with_successor_space","no_extra_blank_lines","blank_line_before_statement","ordered_imports","binary_operator_spaces"]}]}
$ grep -c "declare(strict_types=1)" Modules/SyllabusBooks/app/Http/Controllers/BookController.php
0
$ sed -n '74,76p' Modules/SyllabusBooks/app/Http/Controllers/BookController.php
    // public function create()
    // {
    //     $languages = Dropdown::where('key', 'language')->get();
```

#### BOK-11 · L · CTL-04 — eleven public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:30`, `:48`, `:95`, `:320`, `:367`, `:387`, `:421`, `:711`, `:729`, `:758`, `:785`, `:830`, `:860`, `:977`, `:1023` |
| **Root cause** | No public method in the file declares a return type. |
| **Consequence** | The redirect, Blade, JSON and streamed-download methods are indistinguishable at the signature. |
| **Reproduce** | `grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/BookController.php` |
| **Fix approach** | Add the return type to each after the split (the split may move them). |
| **Plan item** | BOK-11 in `02-fix-plan.md` §8 |

```php
    public function index(Request $request)
    {
        Gate::authorize('tenant.syllabus-books.book.viewAny');
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/BookController.php
30:    public function index(Request $request)
48:    public function create()
95:    public function store(BookRequest $request)
320:    public function getSubjectsByClass(Request $request)
367:    public function show($id)
387:    public function edit(BokBook $book)
421:    public function update(BookRequest $request, BokBook $book)
711:    public function trashedBook()
729:    public function destroy($id)
758:    public function restore($id)
785:    public function forceDelete($id)
830:    public function toggleStatus(Request $request, BokBook $book)
860:    public function validateImport(Request $request)
977:    public function startImport(Request $request)
1023:    public function downloadTemplate()
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | BOK-04 (compensating cleanup) | BOK-08 | ok (ISBN unique + rule) | ok (unique index) | ok | BOK-02 | ok |
| `update` | BOK-03 (language wiped) | BOK-04 | BOK-08 | BOK-03 | ok | ok | BOK-02 | ok |
| `destroy` | ok | ok (soft) | ok | ok | ok | ok | BOK-02 | ok |
| `restore` | ok (does not reset is_active, but books are not filtered by it on restore) | ok | ok | ok | ok | ok | BOK-02 | ok |
| `forceDelete` | ok | BOK-04 (`:801` clears eBook inside the transaction) | ok | ok | ok | ok | BOK-02 | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | BOK-02 | ok |
| `startImport` | ok | ok (file deleted after import) | BOK-08 | ok | ok | ok | BOK-02 | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php` | duplicates `attachBookFiles`/`deleteBookFiles` logic in `BookFileService` | SVC-04 | already audited; see that report |
| `Modules/SyllabusBooks/resources/views/book/edit.blade.php` | reads the empty `$languages` list from BOK-03 | VIEW-02 | fixed by BOK-03 |

## 8. Not covered, and why

- The Excel import was not run (read-only audit); `BookImport` was read, and `startImport` is inside a transaction.
- The book form was read, not rendered; the empty language list is proven from the dropdown table counts and the two `Dropdown::where` calls.
- `BokBook`, `BookClassSubject`, `BookFile` and `BookChapter` are owned by the StudentPortal report and were linked.
