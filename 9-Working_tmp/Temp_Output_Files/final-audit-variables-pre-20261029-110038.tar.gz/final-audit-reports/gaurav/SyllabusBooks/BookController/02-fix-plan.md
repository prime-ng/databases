# Fix Plan — SyllabusBooks / BookController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/BookController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SyllabusBooks/routes/web.php` | route file shared by all twelve controllers |
| `Modules/SyllabusBooks/app/Models/BokBook.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/app/Models/BookFile.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/app/Http/Requests/BookRequest.php` | rules are complete; no change needed |
| `Modules/SyllabusBooks/app/Imports/BookImport.php` | no change needed for these findings |

## 1. Blockers reachable today

- [ ] **BOK-02** · B · ERR-01 · `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:287-296` — stop returning the exception text to the user; apply the same replacement to the other eight sites.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Before** (`BookController.php:287-296`):
    ```php
                $safeMessage = $this->sanitizeUtf8($e->getMessage());

                if ($request->expectsJson()) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Book could not be saved because a file attachment failed. Please try again.',
                        'detail'  => $safeMessage,
                    ], 500);
                }

                return redirect()->back()
                    ->withInput()
                    ->withErrors(['book_files' => 'File attachment failed: ' . $safeMessage]);
    ```
  - **After:**
    ```php
                if ($request->expectsJson()) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Book could not be saved because a file attachment failed. Please try again.',
                    ], 500);
                }

                return redirect()->back()
                    ->withInput()
                    ->withErrors(['book_files' => 'The attached file could not be saved. Please try again.']);
    ```
  - Then make these exact replacements in the same file:
    1. `'error'   => $e->getMessage(),` (inside the `Book create rolled back` log) becomes `'exception' => $e,`.
    2. `\Log::error('Error in getSubjectsByClass: ' . $e->getMessage());` becomes `report($e);`.
    3. `return response()->json(['error' => $e->getMessage()], 500);` becomes `return response()->json(['error' => 'Unable to load subjects.'], 500);`.
    4. `'error'   => $e->getMessage(),` (inside the `Book file attachment failed during update` log) becomes `'exception' => $e,`.
    5. `->withErrors(['book_files' => 'File attachment failed: ' . $e->getMessage()]);` becomes `->withErrors(['book_files' => 'The attached file could not be saved. Please try again.']);`.
    6. `'Failed to delete book: ' . $e->getMessage()` becomes `'The book could not be deleted.'`.
    7. `'Failed to restore book: ' . $e->getMessage()` becomes `'The book could not be restored.'`.
    8. `'Failed to permanently delete book: ' . $e->getMessage()` becomes `'The book could not be permanently deleted.'`.
    9. `'An error occurred while permanently deleting book: ' . $e->getMessage()` becomes `'The book could not be permanently deleted.'`.
    10. `'Failed to update book status: ' . $e->getMessage()` becomes `'The book status could not be updated.'`.
    11. `\Log::error('Book import validation failed: ' . $e->getMessage());` becomes `report($e);`.
    12. `'Validation error: ' . $e->getMessage()` becomes `'The import file could not be validated.'`.
    13. `\Log::error('Book import failed: ' . $e->getMessage());` becomes `report($e);`.
    14. `'Import failed: ' . $e->getMessage()` becomes `'The import could not be completed.'`.
  - **Verify:** `grep -n "with('error'.*getMessage\|withErrors(\['book_files'.*getMessage\|'message' => '.*getMessage\|\"error.*getMessage" Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **BOK-04** · H · TXN-03 · `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:555-558` — store the new eBook before clearing the old one, and delete attached files before removing their media.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Before** (`BookController.php:555-558`):
    ```php
        if ($request->hasFile('ebook_file')) {
            $book->clearMediaCollection('ebook');
            $book->addMediaFromRequest('ebook_file')->toMediaCollection('ebook');
        }
    ```
  - **After:**
    ```php
        if ($request->hasFile('ebook_file')) {
            $oldEbookMedia = $book->getMedia('ebook');

            $book->addMediaFromRequest('ebook_file')->toMediaCollection('ebook');

            foreach ($oldEbookMedia as $oldMedia) {
                $oldMedia->delete();
            }
        }
    ```
  - **Before** (`BookController.php:689-693`):
    ```php
        $files = $book->files()->whereIn('id', $ids)->get();
        foreach ($files as $bookFile) {
            $bookFile->clearMediaCollection(BookFile::MEDIA_FILE);
            $bookFile->delete();
        }
    ```
  - **After:**
    ```php
        $files = $book->files()->whereIn('id', $ids)->get();
        foreach ($files as $bookFile) {
            $bookFile->delete();
        }

        foreach ($files as $bookFile) {
            $bookFile->clearMediaCollection(BookFile::MEDIA_FILE);
        }
    ```
  - **Verify:** `sed -n '553,570p' Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Expect:** `addMediaFromRequest('ebook_file')` appears before the old-media loop, and `delete()` appears before `clearMediaCollection` in `deleteBookFiles`.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **BOK-07** · M · TXN-04 · `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:303` and `:590` — move the create and update logs inside their transactions.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Before** (`BookController.php:221-224`):
    ```php
                        ]);
                    }
                }
            });
    ```
  - **After:**
    ```php
                        ]);
                    }
                }

                activityLog($book, 'Created', ['message' => 'Book created.']);
            });
    ```
  - **Before** (`BookController.php:301-305`):
    ```php
        activityLog($book, 'Created', ['message' => 'Book created.']);

        session()->flash('success', flash('created.book'));
    ```
  - **After:**
    ```php
        session()->flash('success', flash('created.book'));
    ```
  - **Before** (`BookController.php:535-538`):
    ```php
                        ]);
                    }
                }
            });
    ```
  - **After:**
    ```php
                        ]);
                    }
                }

                activityLog($book, 'Updated', ['message' => 'Book updated.']);
            });
    ```
  - **Before** (`BookController.php:588-592`):
    ```php
        activityLog($book, 'Updated', ['message' => 'Book updated.']);

        return redirect()
    ```
  - **After:**
    ```php
        return redirect()
    ```
  - **Verify:** `grep -n "activityLog" Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Expect:** the `Created` and `Updated` calls sit inside their `DB::transaction` closures (indented with the closure body).
  - **Effort:** S

## 4. Authorization (F3)

None.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **BOK-09** · M · CTL-03 · `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:367-381` — bind the book model on show.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Before** (`BookController.php:367-381`):
    ```php
    public function show($id)
    {
        Gate::authorize('tenant.syllabus-books.book.view');

        $book = BokBook::with([
            'authors',
            'languageRelation',
            'classSubjects.class',
            'classSubjects.subject',
            'classSubjects.academicSession',
            'files',
            'chapters',
        ])->findOrFail($id);

        return view('syllabusbooks::book.show', compact('book'));
    }
    ```
  - **After:**
    ```php
    public function show(BokBook $book)
    {
        Gate::authorize('tenant.syllabus-books.book.view');

        $book->load([
            'authors',
            'languageRelation',
            'classSubjects.class',
            'classSubjects.subject',
            'classSubjects.academicSession',
            'files',
            'chapters',
        ]);

        return view('syllabusbooks::book.show', compact('book'));
    }
    ```
  - **Verify:** `grep -n "public function show" Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Expect:** `public function show(BokBook $book)`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **BOK-03** · H · MDL-09 · `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:397` — load the same language dropdown key the create form uses.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Before** (`BookController.php:397`):
    ```php
        $languages = Dropdown::where('key', 'language')->get();
    ```
  - **After:**
    ```php
        $languages = Dropdown::where('key', 'slb_books.language')->get();
    ```
  - **Verify:** `grep -n "Dropdown::where" Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Expect:** lines 52 and 397 both read `'slb_books.language'`; the commented-out line 76 is deleted by BOK-10.
  - **Effort:** S

- [ ] **BOK-06** · M · QRY-07 · `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:210-219` — insert the class/subject rows in one statement.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Before** (`BookController.php:201-222`):
    ```php
                if ($request->filled('class_subjects')) {
                    foreach ($request->class_subjects as $cs) {
                        if (empty($cs['class_id']) || empty($cs['subject_id'])) {
                            continue;
                        }

                        $sessionId = $cs['academic_session_id'] ?? $currentSessionId;

                        if (!empty($cs['is_primary'])) {
                            DB::table('slb_book_class_subject_jnt')
                                ->where('class_id', $cs['class_id'])
                                ->where('subject_id', $cs['subject_id'])
                                ->where('academic_session_id', $sessionId)
                                ->where('is_primary', true)
                                ->update(['is_primary' => false]);
                        }

                        DB::table('slb_book_class_subject_jnt')->insert([
                            'book_id'             => $book->id,
                            'class_id'            => $cs['class_id'],
                            'subject_id'          => $cs['subject_id'],
                            'academic_session_id' => $sessionId,
                            'remarks'             => $cs['remarks'] ?? null,
                            'is_active'           => !empty($cs['is_active']),
                            'is_primary'          => !empty($cs['is_primary']),
                            'is_mandatory'        => !empty($cs['is_mandatory']),
                            'created_at'          => now(),
                            'updated_at'          => now(),
                        ]);
                    }
                }
    ```
  - **After:**
    ```php
                if ($request->filled('class_subjects')) {
                    $classSubjectRows = [];

                    foreach ($request->class_subjects as $cs) {
                        if (empty($cs['class_id']) || empty($cs['subject_id'])) {
                            continue;
                        }

                        $sessionId = $cs['academic_session_id'] ?? $currentSessionId;

                        if (!empty($cs['is_primary'])) {
                            DB::table('slb_book_class_subject_jnt')
                                ->where('class_id', $cs['class_id'])
                                ->where('subject_id', $cs['subject_id'])
                                ->where('academic_session_id', $sessionId)
                                ->where('is_primary', true)
                                ->update(['is_primary' => false]);
                        }

                        $classSubjectRows[] = [
                            'book_id'             => $book->id,
                            'class_id'            => $cs['class_id'],
                            'subject_id'          => $cs['subject_id'],
                            'academic_session_id' => $sessionId,
                            'remarks'             => $cs['remarks'] ?? null,
                            'is_active'           => !empty($cs['is_active']),
                            'is_primary'          => !empty($cs['is_primary']),
                            'is_mandatory'        => !empty($cs['is_mandatory']),
                            'created_at'          => now(),
                            'updated_at'          => now(),
                        ];
                    }

                    if (!empty($classSubjectRows)) {
                        DB::table('slb_book_class_subject_jnt')->insert($classSubjectRows);
                    }
                }
    ```
  - **Note:** the same block is repeated at `:515-536` in `update()`; apply the identical replacement there. The per-primary demotion stays one statement per primary row, which is bounded by the number of classes the form submits.
  - **Verify:** `grep -c "slb_book_class_subject_jnt')->insert(\$classSubjectRows)" Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Expect:** `2` (store and update).
  - **Effort:** M

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **BOK-10** · L · STY-02 · `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:74-91` — delete the commented-out `create()` block, add `strict_types`, run Pint.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Before** (`BookController.php:74-78`):
    ```php
    // public function create()
    // {
    //     $languages = Dropdown::where('key', 'language')->get();
    //     $authors   = BookAuthors::where('is_active', 1)->get();
    //     $classes   = SchoolClass::where('is_active', 1)->get();
    ```
  - **After:**
    ```php
    /**
     * Store a newly created resource in storage.
     */
    ```
  - Delete every remaining commented line from the old block (lines 74-91), then change the header to:
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
    and run `vendor/bin/pint Modules/SyllabusBooks/app/Http/Controllers/BookController.php --format agent`.
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** M

- [ ] **BOK-11** · L · CTL-04 · `Modules/SyllabusBooks/app/Http/Controllers/BookController.php:30` — add the missing return types.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Before** (`BookController.php:30`):
    ```php
    public function index(Request $request)
    ```
  - **After:**
    ```php
    public function index(Request $request): RedirectResponse
    ```
  - Then: `create(): View`, `store(BookRequest $request): RedirectResponse`, `getSubjectsByClass(Request $request): JsonResponse`, `show(BokBook $book): View`, `edit(BokBook $book): View`, `update(BookRequest $request, BokBook $book): RedirectResponse`, `trashedBook(): View`, `destroy($id): RedirectResponse`, `restore($id): RedirectResponse`, `forceDelete($id): RedirectResponse`, `toggleStatus(Request $request, BokBook $book): JsonResponse`, `validateImport(Request $request): JsonResponse`, `startImport(Request $request): JsonResponse`, `downloadTemplate(): StreamedResponse`.
  - **Verify:** `grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/BookController.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BOK-01** · H · DECISION · CTL-02 — `store()` (224 lines) and `update()` (178) need extraction. Extract now or with the split?
  - **Why it is a decision:** extraction changes the class shape and touches the 1,136-line controller that BOK-08 wants to split; doing it twice is wasted work.
  - (a) ⭐ extract the author and class/subject writers into `Modules/SyllabusBooks/app/Services/BookService.php` now, call it from both methods, and keep the routes unchanged.
  - (b) do the extraction as part of the BOK-08 split (defer both).
  - (c) leave both methods as they are and record as accepted.
  - ➜ Choice: ____

- [ ] **BOK-08** · M · DECISION · CTL-01 — split the 1,136-line controller?
  - **Why it is a decision:** D3 keeps the same files, routes and route names for this pass; a split is a later structural change.
  - (a) ⭐ defer to the split pass (D3): BookCrud, BookImport and BookFile concerns as separate controllers/services.
  - (b) extract only the import actions (`validateImport`, `startImport`, `downloadTemplate`) into `BookImportController` now, keeping the route names.
  - (c) leave as is, record as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BOK-05 | removing twelve catch blocks from a 1,136-line controller must happen with the BOK-01/BOK-08 extraction; doing it first makes the extraction conflict with the report's line ranges |
