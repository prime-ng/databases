# Final Audit — SyllabusBooks / BookTopicMappingController

**Audited:** 2026-10-28 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php` (182 lines, 10 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/syllabus-books/book-topic-mappings` (index) · `/create` · `POST` · `/{book_topic_mapping}/edit` · `PUT` · `DELETE` · `/trash/view` · `/{id}/restore` · `/{id}/force-delete` · `/{bookTopicMapping}/toggle-status` |
| Menu path | Syllabus Books → Book Topic Mappings |
| Who uses it | Roles holding `tenant.syllabus-books.book-topic-mapping.viewAny/create/update/delete/restore/forceDelete` (`config/permissionslist.php:1014`). |
| What a user does here | Maps a prescribed book to a syllabus topic, recording chapter number/title, page range, section reference and remarks; then edits, deactivates, trashes or restores a mapping. |
| Tables written | `slb_book_topic_mapping` (declared by the model — **does not exist**, see BTM-01) |
| Tables read | `slb_book_topic_mapping`, `slb_books`, `slb_book_authors`, `slb_topics` |
| Live data | `slb_book_topic_mapping` = **table missing** in `test.localhost`; `slb_books` = 86, `slb_book_authors` = 18 (tinker SELECT, 2026-10-28) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

The whole screen is dead: the model points at a table that does not exist in the tenant database, so every action 500s. Even with the table, the index loads no mappings, passes a variable the view does not read, and renders the dashboard instead of its own view. Three actions also load a record before authorizing it. Effort: one migration plus a day (M).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 1 | 3 | 2 | 1 | 8 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | BTM-04 | F9 Queries/Perf | BTM-06, BTM-07 |
| F3 Authorization | BTM-03 | F10 Views | BTM-02 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | BTM-05 | F12 Style | BTM-08 |
| F6 Controller shape | BTM-02 | F13 Deep read | BTM-01, BTM-03 |
| F7 Models | BTM-01 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php` | controller | 182 | this report | ✅ |
| 2 | `Modules/SyllabusBooks/app/Http/Requests/BookTopicMappingRequest.php` | FormRequest | 74 | this report | ✅ |
| 3 | `Modules/SyllabusBooks/app/Models/BookTopicMapping.php` | model | 41 | ↗ [gaurav/SyllabusBooks/BookTopicMappingController](01-report.md) | ✅ |
| 4 | `Modules/SyllabusBooks/app/Policies/BookTopicMappingPolicy.php` | policy | 65 | ↗ [gaurav/SyllabusBooks/BookTopicMappingController](01-report.md) | ✅ |
| 5 | `Modules/SyllabusBooks/resources/views/book-topic-mapping/index.blade.php` | blade | 119 | this report | ✅ |
| 6 | `Modules/SyllabusBooks/resources/views/book-topic-mapping/create.blade.php` | blade | 130 | this report | ✅ |
| 7 | `Modules/SyllabusBooks/resources/views/book-topic-mapping/edit.blade.php` | blade | 141 | this report | ✅ |
| 8 | `Modules/SyllabusBooks/resources/views/book-topic-mapping/trash.blade.php` | blade | 81 | this report | ✅ |
| 9 | `Modules/SyllabusBooks/app/Models/BokBook.php` | model | 140 | ↗ tarun/StudentPortal-done/StudentPortalController — linked | ↗ linked |
| 10 | `Modules/SyllabusBooks/app/Models/BookAuthors.php` | model | 30 | ↗ [gaurav/SyllabusBooks/AuthorController](01-report.md) | ↗ linked |
| 11 | `Modules/Syllabus/app/Models/Topic.php` | other-module model | — | common — not audited (protocol §4.2) | ❌ common |

No pre-applied files.

## 4. Routes

```
GET|HEAD  syllabus-books/book-topic-mappings                              syllabus-books.book-topic-mappings.index       Modules\SyllabusBooks\Http\Controllers\BookTopicMappingController@index
POST      syllabus-books/book-topic-mappings                              syllabus-books.book-topic-mappings.store       Modules\SyllabusBooks\Http\Controllers\BookTopicMappingController@store
GET|HEAD  syllabus-books/book-topic-mappings/create                       syllabus-books.book-topic-mappings.create      Modules\SyllabusBooks\Http\Controllers\BookTopicMappingController@create
GET|HEAD  syllabus-books/book-topic-mappings/trash/view                   syllabus-books.book-topic-mappings.trashed     Modules\SyllabusBooks\Http\Controllers\BookTopicMappingController@trashedBookTopicMapping
POST      syllabus-books/book-topic-mappings/{bookTopicMapping}/toggle-status  syllabus-books.book-topic-mappings.toggleStatus Modules\SyllabusBooks\Http\Controllers\BookTopicMappingController@toggleStatus
PUT|PATCH syllabus-books/book-topic-mappings/{book_topic_mapping}          syllabus-books.book-topic-mappings.update      Modules\SyllabusBooks\Http\Controllers\BookTopicMappingController@update
DELETE    syllabus-books/book-topic-mappings/{book_topic_mapping}          syllabus-books.book-topic-mappings.destroy     Modules\SyllabusBooks\Http\Controllers\BookTopicMappingController@destroy
GET|HEAD  syllabus-books/book-topic-mappings/{book_topic_mapping}/edit     syllabus-books.book-topic-mappings.edit        Modules\SyllabusBooks\Http\Controllers\BookTopicMappingController@edit
DELETE    syllabus-books/book-topic-mappings/{id}/force-delete             syllabus-books.book-topic-mappings.forceDelete Modules\SyllabusBooks\Http\Controllers\BookTopicMappingController@forceDelete
GET|HEAD  syllabus-books/book-topic-mappings/{id}/restore                  syllabus-books.book-topic-mappings.restore     Modules\SyllabusBooks\Http\Controllers\BookTopicMappingController@restore
```

Unrouted public methods: `show()` (`:56`) — empty body, no route (BTM-05).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 19 | GET book-topic-mappings | `viewAny` policy | none (read) | none | — | BTM-02, BTM-07 |
| `create` | 31 | GET create | `create` policy | none (read) | none | — | BTM-06 |
| `store` | 43 | POST book-topic-mappings | `create` policy | none | none | `slb_book_topic_mapping` | BTM-01, BTM-04 |
| `show` | 56 | — not routed | none | none | none | — | BTM-05 |
| `edit` | 63 | GET {id}/edit | `update` policy | none (read) | none | — | BTM-06 |
| `update` | 79 | PUT {book_topic_mapping} | `update` policy | none | none | `slb_book_topic_mapping` | BTM-01, BTM-04 |
| `trashedBookTopicMapping` | 89 | GET trash/view | `restore` policy | none (read) | none | — | — |
| `destroy` | 101 | DELETE {book_topic_mapping} | `delete` policy | none | 'Trashed' | `slb_book_topic_mapping` | BTM-01, BTM-03, BTM-04 |
| `restore` | 120 | GET {id}/restore | `restore` policy | none | 'Restored' | `slb_book_topic_mapping` | BTM-01, BTM-03, BTM-04 |
| `forceDelete` | 138 | DELETE {id}/force-delete | `forceDelete` policy | none | 'Deleted' | `slb_book_topic_mapping` | BTM-01, BTM-03, BTM-04 |
| `toggleStatus` | 160 | POST {bookTopicMapping}/toggle-status | `update` policy | none | 'Toggled' | `slb_book_topic_mapping` | BTM-01, BTM-04 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try \{|catch \(|getMessage' Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php` → no output.

### F2 — Transactions and audit

#### BTM-04 · M · TXN-04 — five mutating methods write and log without a transaction

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:43-51`, `:79-87`, `:101-118`, `:120-137`, `:138-155`, `:160-180` |
| **Root cause** | Every write is a bare `create`/`update`/`delete` followed by `activityLog()` with no `DB::transaction` (`grep DB::transaction` → no output). `store()` does not log at all. |
| **Consequence** | If the log insert fails, the mapping is already written; if the mapping write fails, no log is written. The audit trail and the data can disagree. |
| **Reproduce** | static only — no `DB::transaction` in the file. |
| **Fix approach** | Wrap each mutation plus its log in one transaction; add a log to `store()`. |
| **Plan item** | BTM-04 in `02-fix-plan.md` §3 |

```php
        $mapping = BookTopicMapping::findOrFail($id);
        Gate::authorize('delete', $mapping);
        $mapping->delete();

        //begin::Activity Log
        activityLog(
            $mapping,
            'Trashed',
            ['message' => 'Book topic mapping was deactivated and trashed']
        );
```

**Evidence**
```
$ grep -n "DB::transaction" Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php
(no output)
$ grep -n "activityLog(" Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php
108:        activityLog(
127:        activityLog(
145:        activityLog(
168:        activityLog(
```

### F3 — Authorization

#### BTM-03 · H · AUTH-02 — three actions load the record before authorizing it

| Field | Value |
|---|---|
| **Rule** | AUTH-02 (H) — *authorize first, before loading records; loading first leaks whether an id exists* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:101-104`, `:120-123`, `:138-141` |
| **Root cause** | `destroy`, `restore` and `forceDelete` call `findOrFail($id)` first and `Gate::authorize()` second. A user without the permission gets a 404 for a missing id and a 403 for an existing one. |
| **Consequence** | An unauthorized user can enumerate which mapping ids exist by comparing 404 and 403 responses. |
| **Reproduce** | As a role without `book-topic-mapping.delete`, request `/syllabus-books/book-topic-mappings/999999` (404) and `/syllabus-books/book-topic-mappings/1` (403). |
| **Fix approach** | Authorize the class ability first (`Gate::authorize('delete', BookTopicMapping::class)`), then load with `findOrFail`. |
| **Plan item** | BTM-03 in `02-fix-plan.md` §4 |

```php
    public function destroy($id)
    {
        $mapping = BookTopicMapping::findOrFail($id);
        Gate::authorize('delete', $mapping);
        $mapping->delete();
```

**Evidence**
```
$ sed -n '101,105p' Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php
    public function destroy($id)
    {
        $mapping = BookTopicMapping::findOrFail($id);
        Gate::authorize('delete', $mapping);
        $mapping->delete();
$ sed -n '120,124p' Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php
    public function restore($id)
    {
        $mapping = BookTopicMapping::withTrashed()->findOrFail($id);
        Gate::authorize('restore', $mapping);
        $mapping->restore();
$ sed -n '138,142p' Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php
    public function forceDelete($id)
    {
        $mapping = BookTopicMapping::withTrashed()->findOrFail($id);
        Gate::authorize('forceDelete', $mapping);
        $mapping->forceDelete();
```

### F4 — Validation and input

clean — `BookTopicMappingRequest.php` types every field, mirrors `page_end >= page_start`, and maps POST/PUT to the policy abilities; `store()`/`update()` write only `$request->validated()` (`grep -n "request->all\|->except(" …` → no output).

### F5 — Routes

#### BTM-05 · M · RTE-03 — `show()` is an empty, unrouted public method

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public method is routed, or deliberately disabled per D5* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:56-58` |
| **Root cause** | The resource excludes `show` (`->except(['show'])` at `routes/web.php:69`) but the method remains with an empty body. |
| **Consequence** | Dead code; if the `except` is ever removed, the route returns an empty 200. |
| **Reproduce** | static only — `php artisan route:list` has no `book-topic-mappings/{id}` GET. |
| **Fix approach** | Per D5: body becomes `abort(403, …)` with a `NOT ROUTED` comment. |
| **Plan item** | BTM-05 in `02-fix-plan.md` §5 |

```php
    public function show($id)
    {
    }
```

**Evidence**
```
$ grep -n "except(\['show'\])" Modules/SyllabusBooks/routes/web.php
69:Route::resource('book-topic-mappings', BookTopicMappingController::class)->except(['show']);
$ sed -n '56,58p' Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php
    public function show($id)
    {
    }
```

### F6 — Controller shape

#### BTM-02 · B · VIEW-01 — the index queries nothing, passes an undefined variable and renders the wrong view

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (B, raised from H: the page 500s on a normal path) — *the controller must pass the data the view reads; a missing variable is an error, not an empty list* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:19-26` |
| **Root cause** | `index()` paginates books and authors but never queries mappings, then calls `compact('bookTopicMappings', …)` for a variable that was never defined, and returns `syllabusbooks::syllabus-book.index` (the 18-variable dashboard) instead of `syllabusbooks::book-topic-mapping.index`. That view reads `$mappings`, not `$bookTopicMappings`. |
| **Consequence** | Opening Book Topic Mappings raises an undefined-variable error (Laravel converts the warning to an exception) and, if it survived, would render the dashboard without its 18 variables. |
| **Reproduce** | Open `/syllabus-books/book-topic-mappings` → 500 before any mapping is listed. |
| **Fix approach** | Query the mappings with their book and topic, paginate, and render the module's own index view with `$mappings`. Apply only after BTM-01 creates the table. |
| **Plan item** | BTM-02 in `02-fix-plan.md` §2 |

```php
    public function index()
    {
        Gate::authorize('viewAny', BookTopicMapping::class);
        $books = BokBook::paginate(11);
        $authors = BookAuthors::paginate(11);

        return view('syllabusbooks::syllabus-book.index', compact('bookTopicMappings', 'books', 'authors'));
    }
```

**Evidence**
```
$ sed -n '19,26p' Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php
    public function index()
    {
        Gate::authorize('viewAny', BookTopicMapping::class);
        $books = BokBook::paginate(11);
        $authors = BookAuthors::paginate(11);

        return view('syllabusbooks::syllabus-book.index', compact('bookTopicMappings', 'books', 'authors'));
    }
$ grep -n "forelse" Modules/SyllabusBooks/resources/views/book-topic-mapping/index.blade.php
45:                                    @forelse($mappings as $mapping)
```

### F7 — Models

#### BTM-01 · B · MDL-07 — the model's table does not exist in the tenant database

| Field | Value |
|---|---|
| **Rule** | MDL-07 (B) — *every model's `$table` exists in a migration; a model over a missing table 500s on first use* |
| **Where** | `Modules/SyllabusBooks/app/Models/BookTopicMapping.php:14` |
| **Root cause** | The model declares `protected $table = 'slb_book_topic_mapping'`, but no migration creates it: `SHOW TABLES LIKE 'slb%'` on `test.localhost` has no `slb_book_topic_mapping` (it has `slb_book_author_jnt`, `slb_book_chapters`, `slb_book_files`, … but no mapping table). A second model in `Modules/Syllabus` declares the same table, also with no migration in this repo. |
| **Consequence** | Every action on this screen fails with SQLSTATE 42S02 "Base table or view not found"; no mapping can be created, listed or restored. |
| **Reproduce** | `SELECT COUNT(*) FROM slb_book_topic_mapping` on the tenant → error 1146. |
| **Fix approach** | Add a tenant migration for the table (columns as in `$fillable` plus timestamps and `deleted_at`), then run it with `php artisan tenants:migrate` — a migration is Tarun's hand. |
| **Plan item** | BTM-01 in `02-fix-plan.md` §9 (DECISION — new migration) |

```php
    protected $table = 'slb_book_topic_mapping';

    protected $fillable = [
        'book_id',
        'topic_id',
        'chapter_number',
        'chapter_title',
        'page_start',
        'page_end',
        'section_reference',
        'remarks',
        'is_active',
    ];
```

**Evidence**
```
$ php artisan tinker --execute='tenancy()->initialize(\Modules\Prime\Models\Domain::where("domain","test.localhost")->first()->tenant); try { echo \DB::table("slb_book_topic_mapping")->count(); } catch (\Throwable $e) { echo "MISSING: ".explode("(Connection", $e->getMessage())[0]; }'
MISSING: SQLSTATE[42S02]: Base table or view not found: 1146 Table 'xyz_school_00000000000040008000_202627.slb_book_topic_mapping' doesn't exist
$ grep -rn "slb_book_topic_mapping" Modules/SyllabusBooks/database Modules/Syllabus/database 2>/dev/null | head
(no output)
```

### F8 — Services and jobs

clean — no service or job; the controller writes directly.

### F9 — Queries and performance

#### BTM-06 · M · QRY-15 — create and edit load every book and author for their dropdowns

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *don't load every row of a big table for a create/edit page* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:31-37` and `:63-74` |
| **Root cause** | `BokBook::all()` and `BookAuthors::all()` (and `Topic::...->get()`) select every row with every column for three `<select>`s; `edit()` also loads authors that its view never uses. |
| **Consequence** | Every open of the create/edit form materialises all 86 books and 18 authors with all columns; the cost grows with the catalogue. |
| **Reproduce** | static only — `BokBook::all()` in both methods. |
| **Fix approach** | Select `id` + label only, and drop the unused authors query in `edit()` if the view does not use it. |
| **Plan item** | BTM-06 in `02-fix-plan.md` §6 |

```php
    public function create()
    {
        Gate::authorize('create', BookTopicMapping::class);
        $books  = BokBook::all();
        $topics = Topic::where('is_active', 1)->orderBy('name')->get();
```

**Evidence**
```
$ grep -n "::all()" Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php
34:        $books  = BokBook::all();
35:        $topics = Topic::where('is_active', 1)->orderBy('name')->get();
66:        $books  = BokBook::all();
67:        $topics = Topic::where('is_active', 1)->orderBy('name')->get();
68:        $authors = BookAuthors::all();
```

#### BTM-07 · L · QRY-13 — two paginators share the default page name and use 11 rows

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L) — *multiple paginators on one page use distinct page names; lists paginate at 10* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:22-23` |
| **Root cause** | `BokBook::paginate(11)` and `BookAuthors::paginate(11)` both use the default `page` parameter, and 11 is off-standard. |
| **Consequence** | Clicking page 2 on one list moves both lists; the list shows 11 rows instead of the standard 10. |
| **Reproduce** | static only — neither call passes a `pageName`. |
| **Fix approach** | `paginate(10, ['*'], 'books_page')` / `'authors_page'`; this block is replaced by BTM-02 anyway. |
| **Plan item** | BTM-07 in `02-fix-plan.md` §6 |

```php
        $books = BokBook::paginate(11);
        $authors = BookAuthors::paginate(11);
```

**Evidence**
```
$ sed -n '22,23p' Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php
        $books = BokBook::paginate(11);
        $authors = BookAuthors::paginate(11);
```

### F10 — Views

clean apart from BTM-02 — the four mapping blades render `$mappings`/`$bookTopicMapping` and loop over eager-loaded relations (`book`, `topic`); no query in Blade (`grep -nE "::where|DB::|->get\(\)" Modules/SyllabusBooks/resources/views/book-topic-mapping/*.blade.php` → no output). Sensitive `@canany` is present in the index table.

### F11 — Security and tenancy

clean — no `env()`, no hard-coded ids, no file access (`grep -nE "env\(|\?\? [0-9]|Storage::" …` → no output).

### F12 — Style

#### BTM-08 · L · STY-02 — the controller is not Pint-clean and has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)*; STY-01 — `declare(strict_types=1)`; STY-04 — no copy-pasted docblocks |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:1-16` |
| **Root cause** | Pint reports twelve fixers (`class_attributes_separation`, `method_argument_space`, `phpdoc_indent`, `single_line_comment_spacing`, `trailing_comma_in_multiline`, `unary_operator_spaces`, `braces_position`, `statement_indentation`, `not_operator_with_successor_space`, `single_line_empty_body`, `ordered_imports`, `binary_operator_spaces`); no `declare(strict_types=1)`. Every method carries a generic "Display a listing of the resource" docblock. |
| **Consequence** | Style only; the docblocks add no information. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php` |
| **Fix approach** | Add strict types, remove the generic docblocks, run Pint. |
| **Plan item** | BTM-08 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SyllabusBooks\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\SyllabusBooks\Models\BookTopicMapping;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Http\/Controllers\/BookTopicMappingController.php","fixers":["class_attributes_separation","method_argument_space","phpdoc_indent","single_line_comment_spacing","trailing_comma_in_multiline","unary_operator_spaces","braces_position","statement_indentation","not_operator_with_successor_space","single_line_empty_body","ordered_imports","binary_operator_spaces"]}]}
$ grep -c "declare(strict_types=1)" Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php
0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | BTM-01 | ok | ok | ok | ok | ok | ok | BTM-01 |
| `update` | BTM-01 | ok | ok | ok | ok | ok | ok | BTM-01 |
| `destroy` | BTM-01 | ok (soft delete) | ok | ok | ok | BTM-03 | ok | BTM-01 |
| `restore` | BTM-01 | ok | ok | ok | ok | BTM-03 | ok | BTM-01 |
| `forceDelete` | BTM-01 | ok | ok | ok | ok | BTM-03 | ok | BTM-01 |
| `toggleStatus` | BTM-01 | ok | ok | ok | ok | ok | ok | BTM-01 |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Syllabus/app/Models/BookTopicMapping.php` | declares the same missing table from a second module | MDL-07 | Syllabus module owner |
| `Modules/SyllabusBooks/resources/views/book-topic-mapping/index.blade.php` | expects `$mappings`, the controller sends `$bookTopicMappings` | VIEW-01 | this report (BTM-02) |

## 8. Not covered, and why

- The screen could not be opened because its table is missing; all claims are from source and the tenant schema.
- The migration's column types are inferred from `$fillable`; the DDL decision needs Tarun's confirmation.
- `Topic` is a Syllabus-module model and was not audited.
