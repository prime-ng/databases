# Fix Plan — SyllabusBooks / BookTopicMappingController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SyllabusBooks/routes/web.php` | route file shared by all twelve controllers |
| `Modules/Syllabus/app/Models/BookTopicMapping.php` | belongs to the Syllabus module |
| `Modules/SyllabusBooks/app/Models/BokBook.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/resources/views/book-topic-mapping/index.blade.php` | already reads `$mappings`; the controller must match it |

## 1. Blockers reachable today

BTM-01 needs a new table and is a DECISION in §9. BTM-02 is a Blocker but cannot be applied until that table exists — see §2.

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **BTM-02** · B · VIEW-01 · `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:19-26` — list the mappings and render the mapping view with the variable it reads.
  - **Do not apply before BTM-01 has created `slb_book_topic_mapping`.**
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Before** (`BookTopicMappingController.php:19-26`):
    ```php
    public function index()
    {
        Gate::authorize('viewAny', BookTopicMapping::class);
        $books = BokBook::paginate(11);
        $authors = BookAuthors::paginate(11);

        return view('syllabusbooks::syllabus-book.index', compact('bookTopicMappings', 'books', 'authors'));
    }
    ```
  - **After:**
    ```php
    public function index()
    {
        Gate::authorize('viewAny', BookTopicMapping::class);

        $mappings = BookTopicMapping::query()
            ->with(['book:id,title', 'topic:id,name'])
            ->orderByDesc('id')
            ->paginate(10, ['*'], 'mappings_page');

        return view('syllabusbooks::book-topic-mapping.index', compact('mappings'));
    }
    ```
  - **Verify:** `grep -n "compact('mappings')" Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Expect:** one hit in `index()`.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [ ] **BTM-04** · M · TXN-04 · `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:43-51`, `:79-87`, `:101-118`, `:120-137`, `:138-155`, `:160-180` — wrap each write and its log in one transaction, and log `store()`.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Before** (`BookTopicMappingController.php:43-51`):
    ```php
    public function store(BookTopicMappingRequest $request)
    {
        Gate::authorize('create', BookTopicMapping::class);
        BookTopicMapping::create($request->validated());

        return redirect()
            ->route('syllabus-books.book-topic-mappings.index')
            ->with('success', 'Book Topic Mapping created successfully');
    }
    ```
  - **After:**
    ```php
    public function store(BookTopicMappingRequest $request)
    {
        Gate::authorize('create', BookTopicMapping::class);

        $mapping = DB::transaction(function () use ($request) {
            $mapping = BookTopicMapping::create($request->validated());

            activityLog($mapping, 'Created', ['message' => 'Book topic mapping created']);

            return $mapping;
        });

        return redirect()
            ->route('syllabus-books.book-topic-mappings.index')
            ->with('success', 'Book Topic Mapping created successfully');
    }
    ```
  - Apply the same shape to `update`, `destroy`, `restore`, `forceDelete` and `toggleStatus`: put the write and the existing `activityLog(...)` call inside one `DB::transaction(function () { … });`. Keep every existing event literal and message unchanged.
  - Add `use Illuminate\Support\Facades\DB;` to the imports.
  - **Verify:** `grep -c "DB::transaction" Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Expect:** `6` (store, update, destroy, restore, forceDelete, toggleStatus).
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **BTM-03** · H · AUTH-02 · `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:101-104`, `:120-123`, `:138-141` — authorize before loading the record.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Before** (`BookTopicMappingController.php:101-105`):
    ```php
    public function destroy($id)
    {
        $mapping = BookTopicMapping::findOrFail($id);
        Gate::authorize('delete', $mapping);
        $mapping->delete();
    ```
  - **After:**
    ```php
    public function destroy($id)
    {
        Gate::authorize('delete', BookTopicMapping::class);

        $mapping = BookTopicMapping::findOrFail($id);
        $mapping->delete();
    ```
  - Do the same for `restore` (`Gate::authorize('restore', BookTopicMapping::class);` before `withTrashed()->findOrFail`) and `forceDelete` (`Gate::authorize('forceDelete', BookTopicMapping::class);` before `withTrashed()->findOrFail`).
  - **Verify:** `grep -n "Gate::authorize\|findOrFail" Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Expect:** in each of the three methods the `Gate::authorize` line has a lower line number than the `findOrFail` line.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **BTM-05** · M · RTE-03 · `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:56-58` — disable the unrouted `show()` per D5.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Before** (`BookTopicMappingController.php:56-58`):
    ```php
    public function show($id)
    {
    }
    ```
  - **After:**
    ```php
    // NOT ROUTED — kept for reference; the resource excludes show().
    public function show(string $id): never
    {
        abort(403, 'This action is not routed.');
    }
    ```
  - **Verify:** `grep -n "NOT ROUTED" Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Expect:** one hit in `show()`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **BTM-06** · M · QRY-15 · `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:34-35` and `:66-68` — load only the columns the dropdowns render.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Before** (`BookTopicMappingController.php:34-35`):
    ```php
        $books  = BokBook::all();
        $topics = Topic::where('is_active', 1)->orderBy('name')->get();
    ```
  - **After:**
    ```php
        $books  = BokBook::orderBy('title')->get(['id', 'title']);
        $topics = Topic::where('is_active', 1)->orderBy('name')->get(['id', 'name']);
    ```
  - Repeat the same two lines in `edit()` (`:66-67`), and delete `$authors = BookAuthors::all();` (`:68`) because `edit.blade.php` does not read `$authors`.
  - **Verify:** `grep -n "BookAuthors::all()" Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BTM-07** · L · QRY-13 · `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:22-23` — give each paginator its own page name and the standard page size.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Before** (`BookTopicMappingController.php:22-23`):
    ```php
        $books = BokBook::paginate(11);
        $authors = BookAuthors::paginate(11);
    ```
  - **After:**
    ```php
        $books = BokBook::paginate(10, ['*'], 'books_page');
        $authors = BookAuthors::paginate(10, ['*'], 'authors_page');
    ```
  - **Note:** BTM-02 replaces these lines with a single mappings paginator. Apply BTM-07 first, or skip it if BTM-02 removed the two lists.
  - **Verify:** `grep -n "paginate(11" Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **BTM-08** · L · STY-02 · `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php:1` — add `strict_types`, remove the generic docblocks, run Pint.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Before** (`BookTopicMappingController.php:1-3`):
    ```php
    <?php

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - Then delete every `/** … Display a listing of the resource. … */` and `/** … Show the form for creating a new resource. … */` docblock in the file, and run `vendor/bin/pint Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php --format agent`.
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookTopicMappingController.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BTM-01** · B · DECISION · MDL-07 — the model's table `slb_book_topic_mapping` does not exist. Create it?
  - **Why it is a decision:** it needs a new tenant migration, which this workflow never writes or runs (D4; migrations are Tarun's hand).
  - (a) ⭐ add `Modules/SyllabusBooks/database/migrations/tenant/2026_10_28_000001_create_slb_book_topic_mapping_table.php` with `book_id`, `topic_id`, `chapter_number`, `chapter_title`, `page_start`, `page_end`, `section_reference`, `remarks`, `is_active`, timestamps and `deleted_at`; Tarun runs `php artisan tenants:migrate`.
  - (b) drop the screen and the model until the mapping feature is scheduled.
  - (c) point the model at an existing table (none exists in `slb%` — this option needs a table name from Tarun).
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | every finding has a plan item |
