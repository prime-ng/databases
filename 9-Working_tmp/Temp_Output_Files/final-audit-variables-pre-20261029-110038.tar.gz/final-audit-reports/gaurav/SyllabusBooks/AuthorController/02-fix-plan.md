# Fix Plan — SyllabusBooks / AuthorController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SyllabusBooks/routes/web.php` | route file shared by all twelve controllers |
| `Modules/SyllabusBooks/app/Models/BokBook.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/app/Http/Requests/AuthorRequest.php` | rules already match the database; no change needed |
| `Modules/SyllabusBooks/resources/views/author/*.blade.php` | no change needed |

## 1. Blockers reachable today

ATH-01 is fixed by the same change as ATH-02; see §3 and §10.

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **ATH-03** · H · CTL-06 · `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:184-190` — re-activate the author while restoring it.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Before** (`AuthorController.php:185`):
    ```php
                $author->restore();
    ```
  - **After:**
    ```php
                $author->restore();
                $author->is_active = true;
                $author->save();
    ```
  - **Verify:** `grep -n "is_active = true" Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Expect:** one hit inside `restore()`.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [ ] **ATH-02** · M · ERR-00 · `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:46-268` — remove the six controller try/catch blocks (D1/D2); keep the transactions and the success branches.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Before** (`AuthorController.php:46-78`):
    ```php
    public function store(AuthorRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.author.create');

        try {
            DB::transaction(function () use ($request) {
                $author = BookAuthors::create($request->validated());
                activityLog($author, 'Created', ['message' => 'Author created.']);
            });

            session()->flash('success', flash('created.author'));

            return redirect()
                ->route('syllabus-books.index', ['tab' => 'author'])
                ->with('success', flash('created.author'));
        } catch (QueryException $e) {
            if ($e->getCode() === '23000') {
                return redirect()
                    ->back()
                    ->withInput()
                    ->with('error', 'Duplicate entry: An author with this name already exists.');
            }
            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'Failed to create author: ' . $e->getMessage());
        } catch (\Throwable $e) {
            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'An error occurred while creating author: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function store(AuthorRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.author.create');

        DB::transaction(function () use ($request) {
            $author = BookAuthors::create($request->validated());
            activityLog($author, 'Created', ['message' => 'Author created.']);
        });

        session()->flash('success', flash('created.author'));

        return redirect()
            ->route('syllabus-books.index', ['tab' => 'author'])
            ->with('success', flash('created.author'));
    }
    ```
  - **Before** (`AuthorController.php:104-136`):
    ```php
    public function update(AuthorRequest $request, BookAuthors $author): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.author.update');

        try {
            DB::transaction(function () use ($author, $request) {
                $author->update($request->validated());
                activityLog($author, 'Updated', ['message' => 'Author updated.']);
            });

            session()->flash('success', flash('updated.author'));

            return redirect()
                ->route('syllabus-books.index', ['tab' => 'author'])
                ->with('success', flash('updated.author'));
        } catch (QueryException $e) {
            if ($e->getCode() === '23000') {
                return redirect()
                    ->back()
                    ->withInput()
                    ->with('error', 'Duplicate entry: An author with this name already exists.');
            }
            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'Failed to update author: ' . $e->getMessage());
        } catch (\Throwable $e) {
            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'An error occurred while updating author: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function update(AuthorRequest $request, BookAuthors $author): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.author.update');

        DB::transaction(function () use ($author, $request) {
            $author->update($request->validated());
            activityLog($author, 'Updated', ['message' => 'Author updated.']);
        });

        session()->flash('success', flash('updated.author'));

        return redirect()
            ->route('syllabus-books.index', ['tab' => 'author'])
            ->with('success', flash('updated.author'));
    }
    ```
  - **Before** (`AuthorController.php:148-175`):
    ```php
    public function destroy($id)
    {
        Gate::authorize('tenant.syllabus-books.author.delete');

        $author = BookAuthors::findOrFail($id);

        try {
            DB::transaction(function () use ($author) {
                $author->is_active = false;
                $author->save();
                $author->delete();

                activityLog($author, 'Trashed', [
                    'message' => 'An author was deactivated and trashed.',
                ]);
            });

            session()->flash('success', flash('trashed.author'));

            return redirect()
                ->route('syllabus-books.index', ['tab' => 'author'])
                ->with('success', flash('trashed.author'));
        } catch (\Throwable $e) {
            return redirect()
                ->route('syllabus-books.index', ['tab' => 'author'])
                ->with('error', 'Failed to delete author: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function destroy(BookAuthors $author): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.author.delete');

        DB::transaction(function () use ($author) {
            $author->is_active = false;
            $author->save();
            $author->delete();

            activityLog($author, 'Trashed', [
                'message' => 'An author was deactivated and trashed.',
            ]);
        });

        session()->flash('success', flash('trashed.author'));

        return redirect()
            ->route('syllabus-books.index', ['tab' => 'author'])
            ->with('success', flash('trashed.author'));
    }
    ```
  - **Before** (`AuthorController.php:177-202`):
    ```php
    public function restore($id)
    {
        Gate::authorize('tenant.syllabus-books.author.restore');

        $author = BookAuthors::withTrashed()->findOrFail($id);

        try {
            DB::transaction(function () use ($author) {
                $author->restore();
                $author->is_active = true;
                $author->save();

                activityLog($author, 'Restored', [
                    'message' => 'An author was restored.',
                ]);
            });

            session()->flash('success', flash('restored.author'));

            return redirect()
                ->route('syllabus-books.authors.trashed')
                ->with('success', flash('restored.author'));
        } catch (\Throwable $e) {
            return redirect()
                ->route('syllabus-books.authors.trashed')
                ->with('error', 'Failed to restore author: ' . $e->getMessage());
        }
    }
    ```
  - **After** (shown with ATH-03 already applied):
    ```php
    public function restore($id)
    {
        Gate::authorize('tenant.syllabus-books.author.restore');

        $author = BookAuthors::withTrashed()->findOrFail($id);

        DB::transaction(function () use ($author) {
            $author->restore();
            $author->is_active = true;
            $author->save();

            activityLog($author, 'Restored', [
                'message' => 'An author was restored.',
            ]);
        });

        session()->flash('success', flash('restored.author'));

        return redirect()
            ->route('syllabus-books.authors.trashed')
            ->with('success', flash('restored.author'));
    }
    ```
  - **Before** (`AuthorController.php:204-242`):
    ```php
    public function forceDelete($id): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.author.forceDelete');

        $author = BookAuthors::withTrashed()->findOrFail($id);

        try {
            DB::transaction(function () use ($author) {
                DB::table('slb_book_author_jnt')
                    ->where('author_id', $author->id)
                    ->delete();

                $author->forceDelete();

                activityLog($author, 'Deleted', [
                    'message' => 'An author was permanently deleted.',
                ]);
            });

            session()->flash('success', flash('force_deleted.author'));

            return redirect()
                ->route('syllabus-books.authors.trashed')
                ->with('success', flash('force_deleted.author'));
        } catch (QueryException $e) {
            if ($e->getCode() === '23000') {
                return redirect()
                    ->route('syllabus-books.authors.trashed')
                    ->with('error', 'Cannot delete: This author is referenced by other records.');
            }
            return redirect()
                ->route('syllabus-books.authors.trashed')
                ->with('error', 'Failed to permanently delete author: ' . $e->getMessage());
        } catch (\Throwable $e) {
            return redirect()
                ->route('syllabus-books.authors.trashed')
                ->with('error', 'An error occurred while permanently deleting author: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function forceDelete($id): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.author.forceDelete');

        $author = BookAuthors::withTrashed()->findOrFail($id);

        DB::transaction(function () use ($author) {
            DB::table('slb_book_author_jnt')
                ->where('author_id', $author->id)
                ->delete();

            $author->forceDelete();

            activityLog($author, 'Deleted', [
                'message' => 'An author was permanently deleted.',
            ]);
        });

        session()->flash('success', flash('force_deleted.author'));

        return redirect()
            ->route('syllabus-books.authors.trashed')
            ->with('success', flash('force_deleted.author'));
    }
    ```
  - **Before** (`AuthorController.php:244-269`):
    ```php
    public function toggleStatus(Request $request, BookAuthors $author)
    {
        Gate::authorize('tenant.syllabus-books.author.update');

        try {
            DB::transaction(function () use ($author) {
                $author->is_active = ! $author->is_active;
                $author->save();

                activityLog($author, 'Toggled', [
                    'message' => 'Author status updated to ' . ($author->is_active ? 'Active' : 'Inactive'),
                ]);
            });

            return response()->json([
                'success' => true,
                'is_active' => $author->is_active,
                'message' => flash('status_updated.author')
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update author status: ' . $e->getMessage()
            ], 500);
        }
    }
    ```
  - **After:**
    ```php
    public function toggleStatus(Request $request, BookAuthors $author): JsonResponse
    {
        Gate::authorize('tenant.syllabus-books.author.update');

        DB::transaction(function () use ($author) {
            $author->is_active = ! $author->is_active;
            $author->save();

            activityLog($author, 'Toggled', [
                'message' => 'Author status updated to ' . ($author->is_active ? 'Active' : 'Inactive'),
            ]);
        });

        return response()->json([
            'success' => true,
            'is_active' => $author->is_active,
            'message' => flash('status_updated.author')
        ]);
    }
    ```
  - Remove the now-unused `use Illuminate\Database\QueryException;` import and add `use Illuminate\Http\JsonResponse;`.
  - **Verify:** `grep -c "catch (" Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php && grep -c "getMessage" Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Expect:** `0` for both commands.
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **ATH-05** · M · AUTH-05 · `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:140` — gate the trash list on the view permission.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Before** (`AuthorController.php:140`):
    ```php
        Gate::authorize('tenant.syllabus-books.author.restore');
    ```
  - **After:**
    ```php
        Gate::authorize('tenant.syllabus-books.author.viewAny');
    ```
  - **Verify:** `grep -n "Gate::authorize" Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Expect:** line 140 reads `...author.viewAny`; the restore/forceDelete gates keep their own permissions.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **ATH-04** · M · CTL-03 · `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:83-90` — bind the author on show.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Before** (`AuthorController.php:83-90`):
    ```php
    public function show($id)
    {
        Gate::authorize('tenant.syllabus-books.author.view');

        $author = BookAuthors::with(['books'])->findOrFail($id);

        return view('syllabusbooks::author.show', compact('author'));
    }
    ```
  - **After:**
    ```php
    public function show(BookAuthors $author): View
    {
        Gate::authorize('tenant.syllabus-books.author.view');

        $author->load('books');

        return view('syllabusbooks::author.show', compact('author'));
    }
    ```
  - **Verify:** `grep -n "public function show" Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Expect:** `public function show(BookAuthors $author): View`.
  - **Effort:** S

## 6. Queries & performance (F9)

None.

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **ATH-07** · L · CTL-04 · `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:22`, `:37`, `:95`, `:138`, `:148`, `:177` — add the missing return types.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Before** (`AuthorController.php:22`):
    ```php
    public function index(Request $request)
    ```
  - **After:**
    ```php
    public function index(Request $request): RedirectResponse
    ```
  - `create(): View`, `edit(BookAuthors $author): View` and `trashedAuthor(): View`; `destroy(BookAuthors $author): RedirectResponse` and `restore($id): RedirectResponse` (as written in ATH-02).
  - **Verify:** `grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **ATH-08** · L · STY-02 · `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:12` — remove the unused `Dropdown` import, add `strict_types`, run Pint.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Before** (`AuthorController.php:12`):
    ```php
    use Modules\GlobalMaster\Models\Dropdown;
    ```
  - **After:** (delete the line)
    ```php
    use Modules\SyllabusBooks\Models\BookAuthors;
    ```
  - Also change the header to:
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
    then run `vendor/bin/pint Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php --format agent`.
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** S

## 9. Deferred / decisions

None.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| ATH-01 | every `getMessage()` site sits inside a catch that ATH-02 removes; applying ATH-02 fixes ATH-01 with no second edit |
