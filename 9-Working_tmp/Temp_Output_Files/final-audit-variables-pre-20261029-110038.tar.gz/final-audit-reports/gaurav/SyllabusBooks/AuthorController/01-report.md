# Final Audit — SyllabusBooks / AuthorController

**Audited:** 2026-10-28 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php` (270 lines, 8 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /syllabus-books/authors` (redirect to the Authors tab) · `/authors/create` · `POST /authors` · `/authors/{author}` · `/authors/{author}/edit` · `PUT` · `DELETE` · `/authors/trash/view` · `/authors/{id}/restore` · `DELETE /authors/{id}/force-delete` · `POST /authors/{author}/toggle-status` |
| Menu path | Syllabus Books → Authors tab |
| Who uses it | Roles holding `tenant.syllabus-books.author.viewAny/create/update/delete/restore/forceDelete` (`config/permissionslist.php:1012`). |
| What a user does here | Maintain the author list used when cataloguing books: create an author with name, qualification and bio, edit it, view the books they wrote, deactivate, trash, restore or permanently delete it. |
| Tables written | `slb_book_authors`, `slb_book_author_jnt` (force delete), activity log |
| Tables read | `slb_book_authors`, `slb_book_author_jnt`, `slb_books` |
| Live data | `slb_book_authors` = 18 rows (0 trashed), `slb_book_author_jnt` = 89 rows on `test.localhost` (tinker SELECT, 2026-10-28) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready: every failure path sends the raw exception text (SQL, table and column names) to the user, and a restored author stays inactive so it never reappears in the Authors tab. The controller also wraps six writes in its own try/catch, which the Laravel-idiom decision (D1/D2) forbids. Effort: half a day (S/M).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 1 | 3 | 2 | 0 | 7 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | ATH-01, ATH-02 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | clean |
| F3 Authorization | ATH-05 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | ATH-07, ATH-08 |
| F6 Controller shape | ATH-03, ATH-04 | F13 Deep read | ATH-03 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php` | controller | 270 | this report | ✅ |
| 2 | `Modules/SyllabusBooks/app/Http/Requests/AuthorRequest.php` | FormRequest | 59 | this report | ✅ |
| 3 | `Modules/SyllabusBooks/app/Models/BookAuthors.php` | model | 30 | ↗ [gaurav/SyllabusBooks/AuthorController](01-report.md) | ✅ |
| 4 | `Modules/SyllabusBooks/app/Policies/AuthorPolicy.php` | policy | 65 | ↗ [gaurav/SyllabusBooks/AuthorController](01-report.md) | ✅ |
| 5 | `Modules/SyllabusBooks/resources/views/author/index.blade.php` | blade | 196 | this report | ✅ |
| 6 | `Modules/SyllabusBooks/resources/views/author/create.blade.php` | blade | 106 | this report | ✅ |
| 7 | `Modules/SyllabusBooks/resources/views/author/edit.blade.php` | blade | 115 | this report | ✅ |
| 8 | `Modules/SyllabusBooks/resources/views/author/show.blade.php` | blade | 133 | this report | ✅ |
| 9 | `Modules/SyllabusBooks/resources/views/author/trash.blade.php` | blade | 63 | this report | ✅ |
| 10 | `Modules/SyllabusBooks/app/Models/BokBook.php` | model | 140 | ↗ tarun/StudentPortal-done/StudentPortalController — linked | ↗ linked |
| 11 | `Modules/GlobalMaster/app/Models/Dropdown.php` | other-module model | — | imported but unused (ATH-08) | ❌ common |

No pre-applied files.

## 4. Routes

```
GET|HEAD  syllabus-books/authors                          syllabus-books.authors.index       Modules\SyllabusBooks\Http\Controllers\AuthorController@index
POST      syllabus-books/authors                          syllabus-books.authors.store       Modules\SyllabusBooks\Http\Controllers\AuthorController@store
GET|HEAD  syllabus-books/authors/create                   syllabus-books.authors.create      Modules\SyllabusBooks\Http\Controllers\AuthorController@create
GET|HEAD  syllabus-books/authors/trash/view               syllabus-books.authors.trashed     Modules\SyllabusBooks\Http\Controllers\AuthorController@trashedAuthor
GET|HEAD  syllabus-books/authors/{author}                 syllabus-books.authors.show        Modules\SyllabusBooks\Http\Controllers\AuthorController@show
PUT|PATCH syllabus-books/authors/{author}                 syllabus-books.authors.update      Modules\SyllabusBooks\Http\Controllers\AuthorController@update
DELETE    syllabus-books/authors/{author}                 syllabus-books.authors.destroy     Modules\SyllabusBooks\Http\Controllers\AuthorController@destroy
GET|HEAD  syllabus-books/authors/{author}/edit            syllabus-books.authors.edit        Modules\SyllabusBooks\Http\Controllers\AuthorController@edit
POST      syllabus-books/authors/{author}/toggle-status   syllabus-books.authors.toggleStatus Modules\SyllabusBooks\Http\Controllers\AuthorController@toggleStatus
DELETE    syllabus-books/authors/{id}/force-delete        syllabus-books.authors.forceDelete Modules\SyllabusBooks\Http\Controllers\AuthorController@forceDelete
GET|HEAD  syllabus-books/authors/{id}/restore             syllabus-books.authors.restore     Modules\SyllabusBooks\Http\Controllers\AuthorController@restore
```

Unrouted public methods: none.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 22 | GET authors | `tenant.syllabus-books.author.viewAny` | none (read) | none | — | ATH-07 |
| `create` | 37 | GET authors/create | `tenant.syllabus-books.author.create` | none (read) | none | — | ATH-07 |
| `store` | 46 | POST authors | `...author.create` | controller | 'Created' | `slb_book_authors`, log | ATH-01, ATH-02 |
| `show` | 83 | GET authors/{author} | `...author.view` | none (read) | none | — | ATH-04, ATH-07 |
| `edit` | 95 | GET authors/{author}/edit | `...author.update` | none (read) | none | — | ATH-07 |
| `update` | 104 | PUT authors/{author} | `...author.update` | controller | 'Updated' | `slb_book_authors`, log | ATH-01, ATH-02 |
| `trashedAuthor` | 138 | GET authors/trash/view | `...author.restore` | none (read) | none | — | ATH-05, ATH-07 |
| `destroy` | 148 | DELETE authors/{author} | `...author.delete` | controller | 'Trashed' | `slb_book_authors`, log | ATH-01, ATH-02 |
| `restore` | 177 | GET authors/{id}/restore | `...author.restore` | controller | 'Restored' | `slb_book_authors`, log | ATH-01, ATH-02, ATH-03 |
| `forceDelete` | 204 | DELETE authors/{id}/force-delete | `...author.forceDelete` | controller | 'Deleted' | `slb_book_author_jnt`, `slb_book_authors`, log | ATH-01, ATH-02 |
| `toggleStatus` | 244 | POST authors/{author}/toggle-status | `...author.update` | controller | 'Toggled' | `slb_book_authors`, log | ATH-01, ATH-02, ATH-07 |

## 6. Findings

### F1 — Errors

#### ATH-01 · B · ERR-01 — the raw exception text is shown to the user on nine paths

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:71`, `:76`, `:129`, `:134`, `:173`, `:200`, `:236`, `:240`, `:266` |
| **Root cause** | Every catch appends `$e->getMessage()` to the `error` flash or JSON message. A `QueryException` message includes the SQL statement, the table and the column names. |
| **Consequence** | A user who triggers a database error (for example by submitting a duplicate name in a race) reads the failing SQL and the schema of `slb_book_authors` on screen; the same text is rendered in the red flash. |
| **Reproduce** | Submit a new author with a name that already exists while a second tab also submits it; the red flash starts with `SQLSTATE[23000]…` and quotes the insert. |
| **Fix approach** | Remove the controller catches entirely (ATH-02): the central handler in `bootstrap/app.php` renders a generic message and logs the exception. |
| **Plan item** | none — fixed by the same change as ATH-02; listed in `02-fix-plan.md` §10 |

```php
            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'Failed to create author: ' . $e->getMessage());
```

**Evidence**
```
$ grep -n "getMessage" Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php
71:                ->with('error', 'Failed to create author: ' . $e->getMessage());
76:                ->with('error', 'An error occurred while creating author: ' . $e->getMessage());
129:                ->with('error', 'Failed to update author: ' . $e->getMessage());
134:                ->with('error', 'An error occurred while updating author: ' . $e->getMessage());
173:                ->with('error', 'Failed to delete author: ' . $e->getMessage());
200:                ->with('error', 'Failed to restore author: ' . $e->getMessage());
236:                ->with('error', 'Failed to permanently delete author: ' . $e->getMessage());
240:                ->with('error', 'An error occurred while permanently deleting author: ' . $e->getMessage());
266:                'message' => 'Failed to update author status: ' . $e->getMessage()
```

#### ATH-02 · M · ERR-00 — six mutating methods wrap their write in a controller try/catch

| Field | Value |
|---|---|
| **Rule** | ERR-00 as settled by D1/D2 (M) — *no try/catch in controllers; `DB::transaction` rolls back by itself; D2 forbids catching `QueryException` (it extends `RuntimeException`)* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:50-77` (`store`), `:108-135` (`update`), `:154-174` (`destroy`), `:183-201` (`restore`), `:210-241` (`forceDelete`), `:248-268` (`toggleStatus`) |
| **Root cause** | Each method catches `QueryException` and `\Throwable` and converts the failure into a redirect or JSON message. D1 keeps errors in the central handler, and D2 explicitly forbids catching `QueryException`. |
| **Consequence** | Nine hand-written error messages drift from the central renderer; a genuine 500 is disguised as a 302 with a flash, so monitoring never sees it, and the user is told a page-specific story that may be false. |
| **Reproduce** | static only — `grep -c "catch ("` returns 9 across six mutating methods. |
| **Fix approach** | Delete the catch blocks; keep the `DB::transaction` and the success branch unchanged. |
| **Plan item** | ATH-02 in `02-fix-plan.md` §3 |

```php
        try {
            DB::transaction(function () use ($request) {
                $author = BookAuthors::create($request->validated());
                activityLog($author, 'Created', ['message' => 'Author created.']);
            });

            session()->flash('success', flash('created.author'));

            return redirect()
                ->route('syllabus-books.index', ['tab' => 'author'])
                ->with('success', flash('created.author'));
        } catch (QueryException $e) {
```

**Evidence**
```
$ grep -n "catch (" Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php
61:        } catch (QueryException $e) {
72:        } catch (\Throwable $e) {
119:        } catch (QueryException $e) {
130:        } catch (\Throwable $e) {
170:        } catch (\Throwable $e) {
197:        } catch (\Throwable $e) {
228:        } catch (QueryException $e) {
237:        } catch (\Throwable $e) {
263:        } catch (\Throwable $e) {
$ grep -c "try {" Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php
6
```

### F2 — Transactions and audit

clean — `store`, `update`, `destroy`, `restore` and `forceDelete` each wrap their write and `activityLog()` in one `DB::transaction` (`:51`, `:109`, `:155`, `:184`, `:211`); `toggleStatus` does the same (`:249`). The pivot delete in `forceDelete` (`:212-214`) is inside the same transaction as the author delete.

### F3 — Authorization

clean — every routed action calls `Gate::authorize` first with a name declared at `config/permissionslist.php:1012`; `show`, `edit`, `destroy` and `toggleStatus` authorize before loading. `destroy`, `restore` and `forceDelete` use a permission string rather than a model policy, but the policy's abilities are permission checks only, so no guard is bypassed.

#### ATH-05 · M · AUTH-05 — the trash list is gated on the restore permission

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — *dead/inverted permission logic: a user allowed to view but not restore cannot see the trash* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:138-143` |
| **Root cause** | `trashedAuthor()` authorizes `...author.restore` although it only reads, while the index uses `...viewAny`. |
| **Consequence** | A role with `viewAny` but without `restore` cannot open the trash list even though it may view authors. |
| **Reproduce** | Role with `author.viewAny` only: `/syllabus-books/authors/trash/view` → 403. |
| **Fix approach** | Gate the read on `...author.viewAny`. |
| **Plan item** | ATH-05 in `02-fix-plan.md` §4 |

```php
    public function trashedAuthor()
    {
        Gate::authorize('tenant.syllabus-books.author.restore');
        $authors = BookAuthors::onlyTrashed()->paginate(10);
        return view('syllabusbooks::author.trash', compact('authors'));
    }
```

**Evidence**
```
$ sed -n '138,143p' Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php
    public function trashedAuthor()
    {
        Gate::authorize('tenant.syllabus-books.author.restore');
        $authors = BookAuthors::onlyTrashed()->paginate(10);
        return view('syllabusbooks::author.trash', compact('authors'));
    }
```

### F4 — Validation and input

clean — `AuthorRequest.php:20-36` types every field and validates `name` as unique against `slb_book_authors` (the table's `uq_author_name` index exists, so the rule matches the database); `store`/`update` write only `$request->validated()`.

### F5 — Routes

clean — eleven routes, all resolve to existing methods; `{author}` matches the bound argument on show/edit/update/destroy/toggle-status; tenancy + `auth` + `verified` are applied by the module group.

### F6 — Controller shape

#### ATH-03 · H · CTL-06 — a restored author stays inactive and never reappears

| Field | Value |
|---|---|
| **Rule** | CTL-06 (H, raised from M: the screen shows a success message for a record the user still cannot see) — *the state transition lives in the controller and is not completed* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:183-190`, method `restore()` |
| **Root cause** | `destroy()` sets `is_active = false` and then soft-deletes. `restore()` calls `$author->restore()` but never sets `is_active` back to true. The Authors tab lists active authors, so the restored row is invisible. |
| **Consequence** | The user restores a deleted author, sees "Author restored successfully", and the author is still missing from the list. |
| **Reproduce** | Delete an author, open the trash, restore it, then open the Authors tab: the author is absent. |
| **Fix approach** | Set `is_active = true` and save in the same transaction as the restore. |
| **Plan item** | ATH-03 in `02-fix-plan.md` §2 |

```php
            DB::transaction(function () use ($author) {
                $author->restore();

                activityLog($author, 'Restored', [
                    'message' => 'An author was restored.',
                ]);
            });
```

**Evidence**
```
$ sed -n '155,163p' Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php
            DB::transaction(function () use ($author) {
                $author->is_active = false;
                $author->save();
                $author->delete();

                activityLog($author, 'Trashed', [
                    'message' => 'An author was deactivated and trashed.',
                ]);
            });
$ sed -n '184,190p' Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php
            DB::transaction(function () use ($author) {
                $author->restore();

                activityLog($author, 'Restored', [
                    'message' => 'An author was restored.',
                ]);
            });
```

#### ATH-04 · M · CTL-03 — `show()` takes a raw id

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:83-90` |
| **Root cause** | The route is `authors/{author}` but the method is `show($id)` and calls `findOrFail`. |
| **Consequence** | The show page cannot use a policy or `withTrashed()` and behaves differently from `edit()` on the same URL parameter. |
| **Reproduce** | static only — compare `show($id)` with `edit(BookAuthors $author)` on the same route parameter. |
| **Fix approach** | Bind `BookAuthors $author`. |
| **Plan item** | ATH-04 in `02-fix-plan.md` §5 |

```php
    public function show($id)
    {
        Gate::authorize('tenant.syllabus-books.author.view');

        $author = BookAuthors::with(['books'])->findOrFail($id);
```

**Evidence**
```
$ grep -n "public function show\|public function edit" Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php
83:    public function show($id)
95:    public function edit(BookAuthors $author)
```

### F7 — Models

clean — `BookAuthors` declares `$fillable` and casts `is_active`; `$table = 'slb_book_authors'` exists with `deleted_at` (SoftDeletes correct) and the pivot `slb_book_author_jnt` has no `deleted_at`, so no `wherePivotNull` is needed; the `books()` relation resolves.

### F8 — Services and jobs

clean — no service or job; the controller owns the writes.

### F9 — Queries and performance

clean — `index` redirects without querying; `trashedAuthor` paginates 10; `show` eager-loads `books` once (`:87`); `grep -n "foreach\|::all()" Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php` → no output.

### F10 — Views

clean — the five author blades render data passed in and loop over `$author->books` from the eager load; `grep -nE "::where|DB::|->get\(\)" Modules/SyllabusBooks/resources/views/author/*.blade.php` → no output; no `{!! !!}` (`grep -c '{!!'` → 0 in all five).

### F11 — Security and tenancy

clean apart from ATH-01 — no `env()`, no hard-coded ids (`grep -nE "env\(|\?\? [0-9]" …` → no output).

### F12 — Style

#### ATH-07 · L · CTL-04 — seven public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:22`, `:37`, `:83`, `:95`, `:138`, `:148`, `:177`, `:244` |
| **Root cause** | Only `store`, `update` and `forceDelete` declare a return type. |
| **Consequence** | The JSON toggle and the Blade redirects are indistinguishable at the signature. |
| **Reproduce** | `grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php` |
| **Fix approach** | Add `: View`, `: RedirectResponse` or `: JsonResponse` to each. |
| **Plan item** | ATH-07 in `02-fix-plan.md` §8 |

```php
    public function index(Request $request)
    {
        Gate::authorize('tenant.syllabus-books.author.viewAny');
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php
22:    public function index(Request $request)
37:    public function create()
83:    public function show($id)
95:    public function edit(BookAuthors $author)
138:    public function trashedAuthor()
148:    public function destroy($id)
177:    public function restore($id)
244:    public function toggleStatus(Request $request, BookAuthors $author)
```

#### ATH-08 · L · STY-02 — the controller is not Pint-clean and imports an unused class

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean*; STY-01 — `declare(strict_types=1)`; STY-05 — no unused imports |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php:1-16` |
| **Root cause** | Pint reports eight fixers including `no_unused_imports` (the `Dropdown` import at line 12 is unused) and `concat_space`; no `declare(strict_types=1)`. |
| **Consequence** | Style only; the stale import misleads a reader into thinking the controller loads dropdowns. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php` |
| **Fix approach** | Remove the unused import, add strict types, run Pint. |
| **Plan item** | ATH-08 in `02-fix-plan.md` §8 |

```php
use App\Http\Controllers\Controller;
use Illuminate\Database\QueryException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\View\View;
use Modules\GlobalMaster\Models\Dropdown;
use Modules\SyllabusBooks\Models\BookAuthors;
use Modules\SyllabusBooks\Http\Requests\AuthorRequest;
use Modules\SyllabusBooks\Models\BokBook;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Http\/Controllers\/AuthorController.php","fixers":["class_attributes_separation","concat_space","trailing_comma_in_multiline","unary_operator_spaces","no_unused_imports","not_operator_with_successor_space","blank_line_before_statement","ordered_imports"]}]}
$ grep -c "declare(strict_types=1)" Modules/SyllabusBooks/app/Http/Controllers/AuthorController.php
0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok (unique index and rule agree) | ok (index rejects) | ok | ATH-01 | ok |
| `update` | ok | ok | ok | ok | ok | ok | ATH-01 | ok |
| `destroy` | ok | ok (soft only) | ok | ok | ok | ok | ok | ok |
| `restore` | ATH-03 | ok | ok | ok | ok | ok | ATH-03 | ok |
| `forceDelete` | ok (pivot rows removed with the author) | ok | ok | ok | ok | ok | ATH-01 | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ATH-01 | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SyllabusBooks/app/Policies/AuthorPolicy.php` | registered but this controller authorizes with permission strings; the policy is redundant, not bypassed | AUTH-05 | module owner, optional |

## 8. Not covered, and why

- No role/permission SELECT was run, so the live role set is not listed.
- `BokBook` is owned by the StudentPortal report and was linked, not re-audited.
- Restore behaviour was proven from the source, not from a browser round-trip.
