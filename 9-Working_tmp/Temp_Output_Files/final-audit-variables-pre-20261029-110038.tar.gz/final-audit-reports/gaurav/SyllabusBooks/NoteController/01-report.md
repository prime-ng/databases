# Final Audit — SyllabusBooks / NoteController

**Audited:** 2026-10-28 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php` (409 lines, 10 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /syllabus-books/notes` (redirect) · `/notes/create` · `POST /notes` · `/notes/{note}` · `/notes/{note}/edit` · `PUT` · `DELETE` · `/notes/trash/view` · `/notes/{id}/restore` · `DELETE /notes/{id}/force-delete` · `POST /notes/{note}/toggle-status` · `GET /syllabus-books/get-chapters-by-book` |
| Menu path | Syllabus Books → Notes tab |
| Who uses it | Roles holding `tenant.syllabus-books.note.viewAny/create/update/delete/restore/forceDelete` (`config/permissionslist.php:1024`). |
| What a user does here | Publish study notes for a class and subject: title, description, type, visibility, status (draft/pending/approved/rejected), tags and an optional file. Approvers move a note to APPROVED or REJECTED; teachers can deactivate, trash, restore or permanently delete a note. |
| Tables written | `slb_notes`, `slb_notes_files`, `slb_notes_ratings`, `slb_notes_downloads`, `media_files`, activity log |
| Tables read | `slb_notes`, `slb_notes_files`, `sch_classes`, `sch_subjects`, `slb_books`, `slb_book_chapters`, `slb_topics`, `sys_users`, `slb_config` |
| Live data | `slb_notes` = 15 rows, `slb_notes_files` = 0, `slb_notes_ratings` = 5, `slb_notes_downloads` = 5, `sys_users` = 5,671 on `test.localhost` (tinker SELECT, 2026-10-28) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. Every failure path sends the raw SQL error to the user, an edited note loses its file before the replacement is stored, and a restored note stays inactive so it never comes back to the Notes tab. The edit form also loads all 5,671 users. Effort: one day (M).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 1 | 5 | 2 | 0 | 10 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | NOT-01 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | NOT-02, NOT-04, NOT-10 | F9 Queries/Perf | NOT-05 |
| F3 Authorization | NOT-06 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | NOT-08, NOT-09 |
| F6 Controller shape | NOT-03, NOT-07 | F13 Deep read | NOT-02, NOT-03 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php` | controller | 409 | this report | ✅ |
| 2 | `Modules/SyllabusBooks/app/Http/Requests/NoteRequest.php` | FormRequest | 59 | this report | ✅ |
| 3 | `Modules/SyllabusBooks/app/Models/SlbNote.php` | model | 205 | ↗ tarun/StudentPortal-done/MobileStudyResourcesController — linked | ↗ linked |
| 4 | `Modules/SyllabusBooks/app/Models/SlbNotesFile.php` | model | 61 | ↗ [gaurav/SyllabusBooks/NoteFileController](../NoteFileController/01-report.md) | ↗ linked |
| 5 | `Modules/SyllabusBooks/app/Models/BookChapter.php` | model | 43 | ↗ tarun/StudentPortal-done — linked | ↗ linked |
| 6 | `Modules/SyllabusBooks/app/Policies/NotePolicy.php` | policy | 44 | ↗ [gaurav/SyllabusBooks/NoteController](01-report.md) | ✅ |
| 7 | `Modules/SyllabusBooks/resources/views/notes/index.blade.php` | blade | 432 | this report | ✅ |
| 8 | `Modules/SyllabusBooks/resources/views/notes/create.blade.php` | blade | 215 | this report | ✅ |
| 9 | `Modules/SyllabusBooks/resources/views/notes/edit.blade.php` | blade | 438 | this report | ✅ |
| 10 | `Modules/SyllabusBooks/resources/views/notes/show.blade.php` | blade | 241 | this report | ✅ |
| 11 | `Modules/SyllabusBooks/resources/views/notes/trash.blade.php` | blade | 101 | this report | ✅ |
| 12 | `Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php` | model | 72 | ↗ [gaurav/SyllabusBooks/SyllabusBookConfigController](../SyllabusBookConfigController/01-report.md) | ↗ linked |

No pre-applied files.

## 4. Routes

```
GET|HEAD  syllabus-books/notes                          syllabus-books.notes.index         Modules\SyllabusBooks\Http\Controllers\NoteController@index
POST      syllabus-books/notes                          syllabus-books.notes.store         Modules\SyllabusBooks\Http\Controllers\NoteController@store
GET|HEAD  syllabus-books/notes/create                   syllabus-books.notes.create        Modules\SyllabusBooks\Http\Controllers\NoteController@create
GET|HEAD  syllabus-books/notes/trash/view               syllabus-books.notes.trashed       Modules\SyllabusBooks\Http\Controllers\NoteController@trashedNote
DELETE    syllabus-books/notes/{id}/force-delete        syllabus-books.notes.forceDelete   Modules\SyllabusBooks\Http\Controllers\NoteController@forceDelete
GET|HEAD  syllabus-books/notes/{id}/restore             syllabus-books.notes.restore       Modules\SyllabusBooks\Http\Controllers\NoteController@restore
GET|HEAD  syllabus-books/notes/{note}                   syllabus-books.notes.show          Modules\SyllabusBooks\Http\Controllers\NoteController@show
PUT|PATCH syllabus-books/notes/{note}                   syllabus-books.notes.update        Modules\SyllabusBooks\Http\Controllers\NoteController@update
DELETE    syllabus-books/notes/{note}                   syllabus-books.notes.destroy       Modules\SyllabusBooks\Http\Controllers\NoteController@destroy
GET|HEAD  syllabus-books/notes/{note}/edit              syllabus-books.notes.edit          Modules\SyllabusBooks\Http\Controllers\NoteController@edit
POST      syllabus-books/notes/{note}/toggle-status     syllabus-books.notes.toggleStatus  Modules\SyllabusBooks\Http\Controllers\NoteController@toggleStatus
GET|HEAD  syllabus-books/get-chapters-by-book           syllabus-books.getChaptersByBook   Modules\SyllabusBooks\Http\Controllers\NoteController@getChaptersByBook
```

Unrouted public methods: none.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 28 | GET notes | `...note.viewAny` | none (read) | none | — | — |
| `create` | 43 | GET notes/create | `...note.create` | none (read) | none | — | NOT-05 |
| `store` | 71 | POST notes | `...note.create` | controller, row only | 'Created' (outside) | `slb_notes`, `media_files` | NOT-01, NOT-02, NOT-04 |
| `show` | 127 | GET notes/{note} | `...note.view` | none (read) | none | — | — |
| `edit` | 140 | GET notes/{note}/edit | `...note.update` | none (read) | none | — | NOT-05 |
| `update` | 182 | PUT notes/{note} | `...note.update` | controller, row only | 'Updated' (outside) | `slb_notes`, `media_files` | NOT-01, NOT-02, NOT-04 |
| `destroy` | 235 | DELETE notes/{note} | `...note.delete` | controller | 'Trashed' | `slb_notes`, log | NOT-01, NOT-07 |
| `restore` | 266 | GET notes/{id}/restore | `...note.restore` | controller | 'Restored' | `slb_notes`, log | NOT-01, NOT-03, NOT-07 |
| `forceDelete` | 295 | DELETE notes/{id}/force-delete | `...note.forceDelete` | controller | 'Deleted' | `slb_notes*`, `media_files` | NOT-01, NOT-07, NOT-10 |
| `trashedNote` | 346 | GET notes/trash/view | `...note.restore` | none (read) | none | — | NOT-06 |
| `toggleStatus` | 361 | POST notes/{note}/toggle-status | `...note.update` | controller | 'Toggled' | `slb_notes`, log | NOT-01 |
| `getChaptersByBook` | 392 | GET get-chapters-by-book | `...note.viewAny` | none (read) | none | — | NOT-01 |

## 6. Findings

### F1 — Errors

#### NOT-01 · B · ERR-01 — raw exception text reaches the user on eight paths, and the catches violate D1/D2

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak*. The same catch blocks also breach ERR-00 as settled by D1 (no try/catch in controllers) and D2 (never catch `QueryException`) |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:115-120`, `:223-228`, `:255-259`, `:284-288`, `:325-339`, `:380-385`, `:403-407` |
| **Root cause** | Seven `try/catch` blocks append `$e->getMessage()` to the flash or the JSON body, and `forceDelete()` also catches `QueryException` by code. `getChaptersByBook()` catches a read-only query and returns its message to an AJAX caller. |
| **Consequence** | A user can read the failing SQL, the table and the column names; a genuine 500 is disguised as a 302 with a red flash, so monitoring never sees it. |
| **Reproduce** | Submit a note whose `class_id` points at a deleted class in a race; the red flash begins `SQLSTATE[23000]…` and quotes the insert. |
| **Fix approach** | Remove all seven catches and let the central handler render and log the error (D1/D2). Keep the transactions and success branches. |
| **Plan item** | NOT-01 in `02-fix-plan.md` §3 |

```php
        } catch (\Throwable $e) {
            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'Failed to create note: '.$e->getMessage());
        }
```

**Evidence**
```
$ grep -n "getMessage" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
119:                ->with('error', 'Failed to create note: '.$e->getMessage());
227:                ->with('error', 'Failed to update note: '.$e->getMessage());
258:                ->with('error', 'Failed to delete note: '.$e->getMessage());
287:                ->with('error', 'Failed to restore note: '.$e->getMessage());
334:                ->with('error', 'Failed to permanently delete note: '.$e->getMessage());
338:                ->with('error', 'An error occurred while permanently deleting note: '.$e->getMessage());
383:                'message' => 'Failed to update note status: '.$e->getMessage(),
405:                'error' => 'Failed to load chapters: '.$e->getMessage(),
$ grep -c "catch (" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
7
```

### F2 — Transactions and audit

#### NOT-02 · B · TXN-03 — an edited note loses its file before the replacement is stored

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B) — *no irreversible side effect inside a transaction or before the write succeeds: file deletes cannot roll back* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:211-214`, method `update()` |
| **Root cause** | `update()` calls `clearMediaCollection()` before `addMediaFromRequest()`, outside the transaction. The collection is registered with `singleFile()`, which already replaces the old file after the new one is stored, so the explicit clear only creates a window where neither file exists. |
| **Consequence** | An edit whose new upload fails (disk error, or a file that passes the form rule but fails the media check) permanently loses the old file; the note keeps a broken attachment. |
| **Reproduce** | Edit a note with a file, choose a file that fails the disk write (or exceeds the configured size after the form check), save: the old file is gone and the note has no attachment. |
| **Fix approach** | Order writes before side effects: DB write in the transaction, media replacement after commit; for force delete, remove media after the last DB commit. |
| **Plan item** | NOT-02 in `02-fix-plan.md` §1 |

```php
            if ($request->hasFile('note_file')) {
                $note->clearMediaCollection(SlbNote::MEDIA_FILE);
                $note->addMediaFromRequest('note_file')->toMediaCollection(SlbNote::MEDIA_FILE);
            }
```

**Evidence**
```
$ sed -n '208,216p' Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
                $note->update($updateData);
            });

            if ($request->hasFile('note_file')) {
                $note->clearMediaCollection(SlbNote::MEDIA_FILE);
                $note->addMediaFromRequest('note_file')->toMediaCollection(SlbNote::MEDIA_FILE);
            }

            activityLog($note, 'Updated', ['message' => 'Note updated.']);
$ sed -n '302,315p' Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
            DB::transaction(function () use ($note) {
                // Delete related ratings & downloads
                $note->ratings()->delete();
                $note->downloads()->delete();

                // Clear media and delete related note files
                foreach ($note->files as $file) {
                    $file->clearMediaCollection(SlbNotesFile::MEDIA_FILE);
                    $file->delete();
                }

                // Clear note file media and force delete note
                $note->clearMediaCollection(SlbNote::MEDIA_FILE);
                $note->forceDelete();
```

#### NOT-04 · M · TXN-04 — the activity log is written outside the transaction

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:108`, `:216`, `:317` |
| **Root cause** | `store()`, `update()` and `forceDelete()` call `activityLog()` after the transaction closure returns, so the log can survive a rollback of the write it describes. |
| **Consequence** | A failed update can leave an "Updated" entry for a note that did not change. |
| **Reproduce** | static only — the `activityLog` calls are outside every `DB::transaction` closure. |
| **Fix approach** | Move each log call inside the closure, immediately after the write. |
| **Plan item** | NOT-04 in `02-fix-plan.md` §3 |

```php
            activityLog($note, 'Created', ['message' => 'Note created.']);
```

**Evidence**
```
$ grep -n "activityLog\|DB::transaction" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
85:            DB::transaction(function () use ($request, &$note, $config, $user) {
108:            activityLog($note, 'Created', ['message' => 'Note created.']);
189:            DB::transaction(function () use ($request, $note, $previousStatus) {
216:            activityLog($note, 'Updated', ['message' => 'Note updated.']);
302:            DB::transaction(function () use ($note) {
317:                activityLog($note, 'Deleted', ['message' => 'A note was permanently deleted.']);
```

#### NOT-10 · M · TXN-03 — force delete removes files inside the transaction

| Field | Value |
|---|---|
| **Rule** | TXN-03 (M, lowered from B: the action is admin-only, on an already-trashed note) — *no irreversible side effect inside a transaction* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:302-318`, method `forceDelete()` |
| **Root cause** | The transaction deletes ratings, downloads, each note file's media and the note's own media, then force-deletes the note. If any statement after the media clears fails, the DB rows return but the files are gone. |
| **Consequence** | A failed permanent delete leaves a note (or its file rows) that can never be downloaded again. |
| **Reproduce** | static only — media clears run before `forceDelete()` inside the same closure. |
| **Fix approach** | Move the media cleanup after the transaction commits (see plan §10 — deferred to the transaction pass). |
| **Plan item** | none — see plan §10 |

```php
                foreach ($note->files as $file) {
                    $file->clearMediaCollection(SlbNotesFile::MEDIA_FILE);
                    $file->delete();
                }

                // Clear note file media and force delete note
                $note->clearMediaCollection(SlbNote::MEDIA_FILE);
                $note->forceDelete();
```

**Evidence**
```
$ sed -n '302,318p' Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
            DB::transaction(function () use ($note) {
                // Delete related ratings & downloads
                $note->ratings()->delete();
                $note->downloads()->delete();

                // Clear media and delete related note files
                foreach ($note->files as $file) {
                    $file->clearMediaCollection(SlbNotesFile::MEDIA_FILE);
                    $file->delete();
                }

                // Clear note file media and force delete note
                $note->clearMediaCollection(SlbNote::MEDIA_FILE);
                $note->forceDelete();

                activityLog($note, 'Deleted', ['message' => 'A note was permanently deleted.']);
```

### F3 — Authorization

#### NOT-06 · M · AUTH-05 — the trash list is gated on the restore permission

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — *dead/inverted permission logic: a view-only role cannot open the trash* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:346-355` |
| **Root cause** | `trashedNote()` authorizes `...note.restore` although it only reads, while the index uses `...note.viewAny`. |
| **Consequence** | A role with `viewAny` but without `restore` cannot see the trash. |
| **Reproduce** | Role with `note.viewAny` only: `/syllabus-books/notes/trash/view` → 403. |
| **Fix approach** | Gate the read on `...note.viewAny`. |
| **Plan item** | NOT-06 in `02-fix-plan.md` §4 |

```php
    public function trashedNote()
    {
        Gate::authorize('tenant.syllabus-books.note.restore');

        $notes = SlbNote::onlyTrashed()
```

**Evidence**
```
$ sed -n '346,352p' Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
    public function trashedNote()
    {
        Gate::authorize('tenant.syllabus-books.note.restore');

        $notes = SlbNote::onlyTrashed()
            ->with(['schoolClass', 'subject'])
            ->paginate(10);
```

### F4 — Validation and input

clean — `NoteRequest.php:22-41` types every field, restricts both enums, validates the upload with `file`+`mimes`+`max:20480`, and `store/update` write `validated()` merged with server-side `uploaded_by_user_id` and status; `getChaptersByBook` reads `$request->book_id` through the query builder (bound parameter, no raw SQL).

### F5 — Routes

clean — twelve routes, all resolve to existing methods; `{note}`/`{id}` match the method parameters; custom AJAX routes are registered before `Route::resource('notes')` (`routes/web.php:85-88`), so `get-chapters-by-book` is not captured by `{note}`.

### F6 — Controller shape

#### NOT-03 · H · CTL-06 — a restored note stays inactive and never reappears

| Field | Value |
|---|---|
| **Rule** | CTL-06 (H, raised from M: the user sees success for a record they still cannot see) — *the state transition is incomplete* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:273-277` |
| **Root cause** | `destroy()` sets `is_active = false` then soft-deletes. `restore()` restores the row but never sets `is_active` back to true. The Notes tab lists active notes. |
| **Consequence** | Restoring a note shows "Note restored successfully" and the note remains absent from the list. |
| **Reproduce** | Trash a note, restore it, open the Notes tab: the note is missing. |
| **Fix approach** | Set `is_active = true` and save inside the restore transaction. |
| **Plan item** | NOT-03 in `02-fix-plan.md` §2 |

```php
            DB::transaction(function () use ($note) {
                $note->restore();

                activityLog($note, 'Restored', ['message' => 'A note was restored.']);
            });
```

**Evidence**
```
$ sed -n '242,247p' Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
            DB::transaction(function () use ($note) {
                $note->is_active = false;
                $note->save();
                $note->delete();

                activityLog($note, 'Trashed', ['message' => 'A note was deactivated and trashed.']);
$ sed -n '273,277p' Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
            DB::transaction(function () use ($note) {
                $note->restore();

                activityLog($note, 'Restored', ['message' => 'A note was restored.']);
            });
```

#### NOT-07 · M · CTL-03 — destroy, restore and force delete take a raw id

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:235-239`, `:266-270`, `:295-299` |
| **Root cause** | `destroy` is routed as `DELETE notes/{note}` but the method still takes `$id` and calls `findOrFail`; `restore`/`forceDelete` are routed as `{id}`. |
| **Consequence** | Two lookup styles on one resource; the id paths cannot use a model policy or `withTrashed()` consistently. |
| **Reproduce** | static only — `php artisan route:list` shows `DELETE notes/{note}` while `destroy($id)` calls `SlbNote::findOrFail($id)`. |
| **Fix approach** | Bind `SlbNote $note` on destroy; keep the trashed id lookups for restore and force delete. |
| **Plan item** | NOT-07 in `02-fix-plan.md` §5 |

```php
    public function destroy($id)
    {
        Gate::authorize('tenant.syllabus-books.note.delete');

        $note = SlbNote::findOrFail($id);
```

**Evidence**
```
$ grep -n "notes/{id}" Modules/SyllabusBooks/routes/web.php
92:Route::get('notes/{id}/restore', [NoteController::class, 'restore'])->name('notes.restore');
94:Route::delete('notes/{id}/force-delete', [NoteController::class, 'forceDelete'])->name('notes.forceDelete');
$ grep -n "public function destroy\|public function restore\|public function forceDelete" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
235:    public function destroy($id)
266:    public function restore($id)
295:    public function forceDelete($id)
```

### F7 — Models

clean — `SlbNote` overrides `getMediaModel()` (`SlbNote.php:107`) so its media stays in the tenant database; `$fillable`/`$casts` cover the columns the controller writes; `SlbNotesFile` is linked to the NoteFileController report, where its missing `getMediaModel()` is reported as a blocker.

### F8 — Services and jobs

clean — no service or job; the approval workflow lives in the controller (a split is out of scope, D3).

### F9 — Queries and performance

#### NOT-05 · M · QRY-15 — create and edit load whole tables, including all 5,671 users

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *don't load every row of a big table for a create/edit page* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:47-52`, `:146-151`, `:163` |
| **Root cause** | Five `get()` calls with `*` build the form dropdowns, and `edit()` adds `User::where('is_active',1)->get(['id','name','email'])` — every active user. |
| **Consequence** | Opening the create/edit note form materialises all classes, subjects, sessions, books, topics and 5,671 users; the page slows as the school grows. |
| **Reproduce** | Open `/syllabus-books/notes/edit/{id}` and count the entries in the user picker: every active user. |
| **Fix approach** | Select `id` + label only, and cap or search the user list. |
| **Plan item** | NOT-05 in `02-fix-plan.md` §6 |

```php
        $classes = SchoolClass::where('is_active', 1)->get();
        $subjects = Subject::where('is_active', 1)->get();
        $sessions = OrganizationAcademicSession::orderBy('start_date', 'desc')->get();
        $books = BokBook::where('is_active', 1)->orderBy('title')->get();

        $topics = Topic::where('is_active', 1)->orderBy('name')->get();
```

**Evidence**
```
$ grep -n "User::where\|->get();" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php | head
47:        $classes = SchoolClass::where('is_active', 1)->get();
48:        $subjects = Subject::where('is_active', 1)->get();
49:        $sessions = OrganizationAcademicSession::orderBy('start_date', 'desc')->get();
50:        $books = BokBook::where('is_active', 1)->orderBy('title')->get();
52:        $topics = Topic::where('is_active', 1)->orderBy('name')->get();
163:        $users = User::where('is_active', 1)->orderBy('name')->get(['id', 'name', 'email']);
```

### F10 — Views

clean — the five note blades render data passed in; the edit blade uses `$chapters` and `$users` from the controller; `grep -nE "::where|DB::|->get\(\)" Modules/SyllabusBooks/resources/views/notes/*.blade.php` → no output; no `{!! !!}` on user text (`grep -c '{!!'` → 0 in all five).

### F11 — Security and tenancy

clean apart from NOT-01 — no `env()`, no hard-coded ids, media served through the model's tenant media.

### F12 — Style

#### NOT-08 · L · CTL-04 — six public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:28`, `:43`, `:71`, `:127`, `:140`, `:182`, `:235`, `:266`, `:295`, `:346`, `:361`, `:392` |
| **Root cause** | Only `getChaptersByBook`'s sibling methods with JSON have no annotation; every method omits its return type. |
| **Consequence** | Blade, redirect and JSON methods are indistinguishable at the signature. |
| **Reproduce** | `grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/NoteController.php` |
| **Fix approach** | Add `: View`, `: RedirectResponse` or `: JsonResponse` to each. |
| **Plan item** | NOT-08 in `02-fix-plan.md` §8 |

```php
    public function index(Request $request)
    {
        Gate::authorize('tenant.syllabus-books.note.viewAny');
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
28:    public function index(Request $request)
43:    public function create()
71:    public function store(NoteRequest $request)
127:    public function show(SlbNote $note)
140:    public function edit(SlbNote $note)
182:    public function update(NoteRequest $request, SlbNote $note)
235:    public function destroy($id)
266:    public function restore($id)
295:    public function forceDelete($id)
346:    public function trashedNote()
361:    public function toggleStatus(Request $request, SlbNote $note)
392:    public function getChaptersByBook(Request $request)
```

#### NOT-09 · L · STY-02 — the controller is not Pint-clean and has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean*; STY-01 — `declare(strict_types=1)` |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:1-22` |
| **Root cause** | Pint reports `concat_space`, `not_operator_with_successor_space` and spacing fixers; no `declare(strict_types=1)`. |
| **Consequence** | Style only. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/NoteController.php` |
| **Fix approach** | Add strict types and run Pint on the file. |
| **Plan item** | NOT-09 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SyllabusBooks\Http\Controllers;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Http\/Controllers\/NoteController.php","fixers":["class_attributes_separation","concat_space","trailing_comma_in_multiline","not_operator_with_successor_space","blank_line_before_statement","ordered_imports"]}]}
$ grep -c "declare(strict_types=1)" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php
0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok (status forced from config, not from the form) | NOT-02 | ok | ok | ok | ok | NOT-01 | ok |
| `update` | ok (approval stamps set/cleared correctly) | NOT-02 | ok | ok | ok | ok | NOT-01 | ok |
| `destroy` | ok | ok (soft only) | ok | ok | ok | ok | ok | ok |
| `restore` | NOT-03 | ok | ok | ok | ok | ok | NOT-03 | ok |
| `forceDelete` | ok | NOT-10 | ok | ok | ok | ok | NOT-01 | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | NOT-01 | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SyllabusBooks/app/Models/SlbNotesFile.php` | no `getMediaModel()` — reported as NFC-01 in the NoteFileController report; `forceDelete()` here deletes its media too | TEN-01 | NoteFileController plan (NFC-01) |

## 8. Not covered, and why

- Nothing was uploaded or deleted; media ordering is proven from the source.
- `SlbNote`, `BookChapter` and the portal downloads are owned by the StudentPortal report and were linked.
- The approval workflow's effect on the portal was not exercised (no browser).
