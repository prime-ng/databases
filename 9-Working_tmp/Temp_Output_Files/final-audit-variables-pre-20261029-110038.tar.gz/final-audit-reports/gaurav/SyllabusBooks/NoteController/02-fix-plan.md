# Fix Plan — SyllabusBooks / NoteController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SyllabusBooks/app/Models/SlbNote.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/app/Models/SlbNotesFile.php` | owned by the NoteFileController report (NFC-01) |
| `Modules/SyllabusBooks/resources/views/notes/*.blade.php` | no change needed |
| `Modules/SyllabusBooks/app/Http/Requests/NoteRequest.php` | rules are complete |

## 1. Blockers reachable today

- [ ] **NOT-01** · B · ERR-01 · `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:82-120`, `:186-228`, `:241-259`, `:272-288`, `:301-339`, `:365-385`, `:396-407` — remove all seven controller try/catch blocks (D1/D2) so no exception text reaches the user.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Before** (`NoteController.php:82-83`):
    ```php
        try {
            $note = null;
    ```
  - **After:**
    ```php
        $note = null;
    ```
  - **Before** (`NoteController.php:115-120`):
    ```php
        } catch (\Throwable $e) {
            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'Failed to create note: '.$e->getMessage());
        }
    ```
  - **After:**
    ```php
    }
    ```
  - **Before** (`NoteController.php:186-187`):
    ```php
        try {
            $previousStatus = $note->status;
    ```
  - **After:**
    ```php
        $previousStatus = $note->status;
    ```
  - **Before** (`NoteController.php:223-228`):
    ```php
        } catch (\Throwable $e) {
            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'Failed to update note: '.$e->getMessage());
        }
    ```
  - **After:**
    ```php
    }
    ```
  - **Before** (`NoteController.php:241-242`):
    ```php
        try {
            DB::transaction(function () use ($note) {
                $note->is_active = false;
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($note) {
            $note->is_active = false;
    ```
  - **Before** (`NoteController.php:255-259`):
    ```php
        } catch (\Throwable $e) {
            return redirect()
                ->route('syllabus-books.index', ['tab' => 'notes'])
                ->with('error', 'Failed to delete note: '.$e->getMessage());
        }
    ```
  - **After:**
    ```php
    }
    ```
  - **Before** (`NoteController.php:272-273`):
    ```php
        try {
            DB::transaction(function () use ($note) {
                $note->restore();
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($note) {
            $note->restore();
    ```
  - **Before** (`NoteController.php:284-288`):
    ```php
        } catch (\Throwable $e) {
            return redirect()
                ->route('syllabus-books.notes.trashed')
                ->with('error', 'Failed to restore note: '.$e->getMessage());
        }
    ```
  - **After:**
    ```php
    }
    ```
  - **Before** (`NoteController.php:301-302`):
    ```php
        try {
            DB::transaction(function () use ($note) {
                // Delete related ratings & downloads
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($note) {
            // Delete related ratings & downloads
    ```
  - **Before** (`NoteController.php:325-339`):
    ```php
        } catch (QueryException $e) {
            if ($e->getCode() === '23000') {
                return redirect()
                    ->route('syllabus-books.notes.trashed')
                    ->with('error', 'Cannot delete: note is referenced by other records.');
            }

            return redirect()
                ->route('syllabus-books.notes.trashed')
                ->with('error', 'Failed to permanently delete note: '.$e->getMessage());
        } catch (\Throwable $e) {
            return redirect()
                ->route('syllabus-books.notes.trashed')
                ->with('error', 'An error occurred while permanently deleting note: '.$e->getMessage());
        }
    ```
  - **After:**
    ```php
    }
    ```
  - **Before** (`NoteController.php:365-366`):
    ```php
        try {
            DB::transaction(function () use ($note) {
                $note->is_active = ! $note->is_active;
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($note) {
            $note->is_active = ! $note->is_active;
    ```
  - **Before** (`NoteController.php:380-385`):
    ```php
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update note status: '.$e->getMessage(),
            ], 500);
        }
    ```
  - **After:**
    ```php
    }
    ```
  - **Before** (`NoteController.php:396-397`):
    ```php
        try {
            $chapters = BookChapter::where('book_id', $request->book_id)
    ```
  - **After:**
    ```php
        $chapters = BookChapter::where('book_id', $request->book_id)
    ```
  - **Before** (`NoteController.php:403-407`):
    ```php
        } catch (\Throwable $e) {
            return response()->json([
                'error' => 'Failed to load chapters: '.$e->getMessage(),
            ], 500);
        }
    ```
  - **After:**
    ```php
    }
    ```
  - Then remove `use Illuminate\Database\QueryException;` and run `vendor/bin/pint` on the file (it re-indents the un-wrapped bodies).
  - **Verify:** `grep -c "catch (" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php && grep -c "getMessage" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Expect:** `0` for both.
  - **Effort:** M

- [ ] **NOT-02** · B · TXN-03 · `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:211-214` — stop deleting the old file before the new one is stored.
  - **Apply after NOT-01.** The Before below is the post-NOT-01 code (no `try` wrapper); the media block itself is unchanged.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Before** (`NoteController.php:211-214`):
    ```php
            if ($request->hasFile('note_file')) {
                $note->clearMediaCollection(SlbNote::MEDIA_FILE);
                $note->addMediaFromRequest('note_file')->toMediaCollection(SlbNote::MEDIA_FILE);
            }
    ```
  - **After:**
    ```php
            if ($request->hasFile('note_file')) {
                $note->addMediaFromRequest('note_file')->toMediaCollection(SlbNote::MEDIA_FILE);
            }
    ```
  - **Verify:** `grep -n "clearMediaCollection(SlbNote::MEDIA_FILE)" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Expect:** one hit, inside `forceDelete()` only (the edit path no longer clears).
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **NOT-03** · H · CTL-06 · `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:273-277` — re-activate the note while restoring it.
  - **Apply after NOT-01** (the `try` wrapper is gone).
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Before** (`NoteController.php:274`):
    ```php
                $note->restore();
    ```
  - **After:**
    ```php
                $note->restore();
                $note->is_active = true;
                $note->save();
    ```
  - **Verify:** `grep -n "is_active = true" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Expect:** one hit inside `restore()`.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [ ] **NOT-04** · M · TXN-04 · `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:108` and `:216` — move the two activity-log calls inside their transactions.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Before** (`NoteController.php:96-102`):
    ```php
                $note = SlbNote::create(array_merge($data, [
                    'uploaded_by_user_id' => auth()->id(),
                    'is_downloadable' => $request->boolean('is_downloadable'),
                    'is_active' => $request->boolean('is_active'),
                    'status' => $status,
                ]));
            });
    ```
  - **After:**
    ```php
                $note = SlbNote::create(array_merge($data, [
                    'uploaded_by_user_id' => auth()->id(),
                    'is_downloadable' => $request->boolean('is_downloadable'),
                    'is_active' => $request->boolean('is_active'),
                    'status' => $status,
                ]));

                activityLog($note, 'Created', ['message' => 'Note created.']);
            });
    ```
  - **Before** (`NoteController.php:108-110`):
    ```php
            activityLog($note, 'Created', ['message' => 'Note created.']);

            session()->flash('success', flash('created.note'));
    ```
  - **After:**
    ```php
            session()->flash('success', flash('created.note'));
    ```
  - **Before** (`NoteController.php:208-210`):
    ```php
                $note->update($updateData);
            });
    ```
  - **After:**
    ```php
                $note->update($updateData);

                activityLog($note, 'Updated', ['message' => 'Note updated.']);
            });
    ```
  - **Before** (`NoteController.php:216-218`):
    ```php
            activityLog($note, 'Updated', ['message' => 'Note updated.']);

            session()->flash('success', flash('updated.note'));
    ```
  - **After:**
    ```php
            session()->flash('success', flash('updated.note'));
    ```
  - **Verify:** `grep -n "activityLog" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Expect:** four hits, each inside a `DB::transaction` closure (Created, Updated, Deleted, Toggled).
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **NOT-06** · M · AUTH-05 · `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:348` — gate the trash list on the view permission.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Before** (`NoteController.php:348`):
    ```php
        Gate::authorize('tenant.syllabus-books.note.restore');
    ```
  - **After:**
    ```php
        Gate::authorize('tenant.syllabus-books.note.viewAny');
    ```
  - **Verify:** `sed -n '346,350p' Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Expect:** `trashedNote()` now authorizes `...note.viewAny`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **NOT-07** · M · CTL-03 · `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:235-239` — bind the note model on destroy (the route already names the parameter `{note}`).
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Before** (`NoteController.php:235-239`):
    ```php
    public function destroy($id)
    {
        Gate::authorize('tenant.syllabus-books.note.delete');

        $note = SlbNote::findOrFail($id);
    ```
  - **After:**
    ```php
    public function destroy(SlbNote $note)
    {
        Gate::authorize('tenant.syllabus-books.note.delete');
    ```
  - In `restore()`, change the signature to `public function restore(string $id)` and keep `SlbNote::withTrashed()->findOrFail($id)` (an implicit binding cannot see trashed rows without `->withTrashed()` on the route).
  - In `forceDelete()`, change the signature to `public function forceDelete(string $id)` and keep `SlbNote::withTrashed()->findOrFail($id)`.
  - No route edit is needed: `Route::resource('notes', NoteController::class)` already names the destroy parameter `{note}`.
  - **Verify:** `grep -n "public function destroy" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Expect:** `public function destroy(SlbNote $note)`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **NOT-05** · M · QRY-15 · `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:163` — stop loading all 5,671 users into the edit form.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Before** (`NoteController.php:163`):
    ```php
        $users = User::where('is_active', 1)->orderBy('name')->get(['id', 'name', 'email']);
    ```
  - **After:**
    ```php
        $users = User::where('is_active', 1)->orderBy('name')->limit(500)->get(['id', 'name', 'email']);
    ```
  - **Verify:** `grep -n "limit(500)" Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Expect:** one hit on the users query.
  - **Effort:** S

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **NOT-08** · L · CTL-04 · `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:28` — add the missing return types.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Before** (`NoteController.php:28`):
    ```php
    public function index(Request $request)
    ```
  - **After:**
    ```php
    public function index(Request $request): RedirectResponse
    ```
  - Then: `create(): View`, `store(NoteRequest $request): RedirectResponse`, `show(SlbNote $note): View`, `edit(SlbNote $note): View`, `update(NoteRequest $request, SlbNote $note): RedirectResponse`, `destroy(SlbNote $note): RedirectResponse`, `restore(string $id): RedirectResponse`, `forceDelete(string $id): RedirectResponse`, `trashedNote(): View`, `toggleStatus(Request $request, SlbNote $note): JsonResponse`, `getChaptersByBook(Request $request): JsonResponse`.
  - **Verify:** `grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **NOT-09** · L · STY-02 · `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php:1` — add `strict_types` and make the file Pint-clean.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Before** (`NoteController.php:1-3`):
    ```php
    <?php

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - Then run `vendor/bin/pint Modules/SyllabusBooks/app/Http/Controllers/NoteController.php --format agent`.
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/NoteController.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** S

## 9. Deferred / decisions

None.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| NOT-10 | moving the force-delete media cleanup after the transaction needs a structural rewrite of `forceDelete()` plus the `SlbNotesFile` media fix (NFC-01); deferred to the transaction pass so it is applied on top of both |
