# Final Audit — SyllabusBooks / NoteFileController

**Audited:** 2026-10-28 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php` (122 lines, 5 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /syllabus-books/note-files` (redirect to the dashboard tab) · `GET /syllabus-books/note-files/create` · `POST /syllabus-books/note-files` · `DELETE /syllabus-books/note-files/{note_file}` · `POST /syllabus-books/note-files/{note_file}/toggle-status` |
| Menu path | Syllabus Books → Note Files tab (the create page is its own screen) |
| Who uses it | Roles holding `tenant.syllabus-books.note-file.viewAny/create/update/delete` (`config/permissionslist.php:1016`). |
| What a user does here | Upload one file for an existing study note, set its display order, then switch it active/inactive or remove it. |
| Tables written | `slb_notes_files`, `media_files` (through Spatie) |
| Tables read | `slb_notes_files`, `slb_notes` |
| Live data | `slb_notes_files` = 0 rows, `slb_notes` = 15 rows on `test.localhost` (tinker SELECT, 2026-10-28) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. The worst defect is invisible until a second tenant exists: this model uses Spatie media without overriding `getMediaModel()`, so every uploaded note file writes its media row to the **central** database (TEN-01). The upload also writes outside its transaction, and delete destroys the file before the row is safely removed. Effort: half a day (S/M).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 1 | 3 | 1 | 0 | 7 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | NFC-02, NFC-03, NFC-06 | F9 Queries/Perf | clean |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | NFC-05 | F11 Security/Tenancy | NFC-01 |
| F5 Routes | clean | F12 Style | NFC-07 |
| F6 Controller shape | NFC-04 | F13 Deep read | NFC-01, NFC-02, NFC-03 |
| F7 Models | NFC-01 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php` | controller | 122 | this report | ✅ |
| 2 | `Modules/SyllabusBooks/app/Models/SlbNotesFile.php` | model | 61 | ↗ [gaurav/SyllabusBooks/NoteFileController](01-report.md) | ✅ |
| 3 | `Modules/SyllabusBooks/app/Models/SlbNote.php` | model | 205 | ↗ tarun/StudentPortal-done/MobileStudyResourcesController — linked | ↗ linked |
| 4 | `Modules/SyllabusBooks/resources/views/note-files/create.blade.php` | blade | 74 | this report | ✅ |
| 5 | `Modules/SyllabusBooks/resources/views/note-files/index.blade.php` | blade | 195 | this report | ✅ |

No pre-applied files.

## 4. Routes

```
GET|HEAD  syllabus-books/note-files                            syllabus-books.note-files.index       Modules\SyllabusBooks\Http\Controllers\NoteFileController@index
POST      syllabus-books/note-files                            syllabus-books.note-files.store       Modules\SyllabusBooks\Http\Controllers\NoteFileController@store
GET|HEAD  syllabus-books/note-files/create                     syllabus-books.note-files.create      Modules\SyllabusBooks\Http\Controllers\NoteFileController@create
DELETE    syllabus-books/note-files/{note_file}                syllabus-books.note-files.destroy     Modules\SyllabusBooks\Http\Controllers\NoteFileController@destroy
POST      syllabus-books/note-files/{note_file}/toggle-status  syllabus-books.note-files.toggleStatus Modules\SyllabusBooks\Http\Controllers\NoteFileController@toggleStatus
```

Unrouted public methods: none.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 20 | GET note-files | `tenant.syllabus-books.note-file.viewAny` | none (read) | none | — | — |
| `create` | 33 | GET note-files/create | `tenant.syllabus-books.note-file.create` | none (read) | none | — | — |
| `store` | 48 | POST note-files | `tenant.syllabus-books.note-file.create` | controller, wraps only the first insert (`:61-67`) | 'Created' (outside tx) | `slb_notes_files`, `media_files` | NFC-02, NFC-05 |
| `destroy` | 86 | DELETE note-files/{note_file} | `tenant.syllabus-books.note-file.delete` | none | 'Trashed' (after) | `slb_notes_files`, `media_files` | NFC-03, NFC-04 |
| `toggleStatus` | 109 | POST note-files/{note_file}/toggle-status | `tenant.syllabus-books.note-file.update` | none | none | `slb_notes_files` | NFC-06 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try \{|catch \(|getMessage' Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php` → no output.

### F2 — Transactions and audit

#### NFC-02 · H · TXN-01 — the upload writes three times but only the first insert is in a transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write runs inside one `DB::transaction`* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:59-75`, method `store()` |
| **Root cause** | The transaction closes after `SlbNotesFile::create()`. The Spatie media upload, the `$noteFile->save()` that stores `media_id`, and `activityLog()` all run afterwards. If any of them fails, the row exists with no media and no log. |
| **Consequence** | A failed upload leaves a note-file row that the Notes screen lists but cannot download; the user sees a 500 with a half-created record. |
| **Reproduce** | static only — the media write at line 69 runs after the transaction at 61-67 has committed. |
| **Fix approach** | Create the row, upload the media and store `media_id` under one transaction, with the activity log inside it. |
| **Plan item** | NFC-02 in `02-fix-plan.md` §3 |

```php
        DB::transaction(function () use ($request, $validated, &$noteFile) {
            $noteFile = SlbNotesFile::create([
                'notes_id'  => $validated['notes_id'],
                'ordinal'   => $validated['ordinal'] ?? 1,
                'is_active' => isset($validated['is_active']) ? (bool) $validated['is_active'] : true,
            ]);
        });

        $media = $noteFile->addMediaFromRequest('note_file')
            ->toMediaCollection(SlbNotesFile::MEDIA_FILE);

        $noteFile->media_id = $media->id;
        $noteFile->save();

        activityLog($noteFile, 'Created', ['message' => 'Note file uploaded.']);
```

**Evidence**
```
$ grep -n "DB::transaction\|addMediaFromRequest\|->save()\|activityLog" Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php
61:        DB::transaction(function () use ($request, $validated, &$noteFile) {
69:        $media = $noteFile->addMediaFromRequest('note_file')
73:        $noteFile->save();
75:        activityLog($noteFile, 'Created', ['message' => 'Note file uploaded.']);
```

#### NFC-03 · B · TXN-03 — the note file is destroyed before its row is deleted

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B) — *no irreversible side effect before the write succeeds* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:86-103`, method `destroy()` |
| **Root cause** | `clearMediaCollection()` deletes the media row and the file on disk, then the model is soft-deleted. There is no transaction and no way back: a failure after the media clear leaves an active row with no file. |
| **Consequence** | Deleting a note file permanently destroys the upload; restoring the row later is impossible, and a crash between the two statements leaves a broken record. |
| **Reproduce** | Delete a note file, then restore the `slb_notes_files` row in the database: the file is gone. |
| **Fix approach** | Soft-delete the row first inside a transaction with its activity log, then clear the media after commit. |
| **Plan item** | NFC-03 in `02-fix-plan.md` §1 |

```php
        $noteFile = SlbNotesFile::findOrFail($id);

        $noteFile->clearMediaCollection(SlbNotesFile::MEDIA_FILE);

        $noteFile->is_active = false;
        $noteFile->save();
        $noteFile->delete();

        activityLog($noteFile, 'Trashed', ['message' => 'Note file trashed.']);
```

**Evidence**
```
$ sed -n '86,98p' Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php
    public function destroy($id): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-file.delete');

        $noteFile = SlbNotesFile::findOrFail($id);

        $noteFile->clearMediaCollection(SlbNotesFile::MEDIA_FILE);

        $noteFile->is_active = false;
        $noteFile->save();
        $noteFile->delete();

        activityLog($noteFile, 'Trashed', ['message' => 'Note file trashed.']);
```

#### NFC-06 · M · TXN-04 — toggling a note file writes without an activity log

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits after the write it describes* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:109-121`, method `toggleStatus()` |
| **Root cause** | The method flips `is_active` and saves, but never calls `activityLog()`; upload and delete in the same controller both log. |
| **Consequence** | A file can be hidden from students with no record of who did it. |
| **Reproduce** | static only — toggle a file and look for a `Toggled` entry: none is written. |
| **Fix approach** | Log the toggle after the save, inside a transaction with the write. |
| **Plan item** | NFC-06 in `02-fix-plan.md` §3 |

```php
        $noteFile->is_active = ! $noteFile->is_active;
        $noteFile->save();

        return response()->json([
```

**Evidence**
```
$ grep -n "activityLog" Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php
75:        activityLog($noteFile, 'Created', ['message' => 'Note file uploaded.']);
98:        activityLog($noteFile, 'Trashed', ['message' => 'Note file trashed.']);
$ sed -n '109,115p' Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php
    public function toggleStatus(Request $request, SlbNotesFile $noteFile): JsonResponse
    {
        Gate::authorize('tenant.syllabus-books.note-file.update');

        $noteFile->is_active = ! $noteFile->is_active;
        $noteFile->save();
```

### F3 — Authorization

clean — every routed action authorizes first, with a permission that exists in `config/permissionslist.php:1016`; no record-level rule is needed because a note file has no owner of its own beyond the school.

### F4 — Validation and input

#### NFC-05 · M · VAL-02 — upload validation is inline and there is no FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a FormRequest, not inline `$request->validate()`* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:48-57` |
| **Root cause** | `store()` validates four fields inline; the module has a FormRequest for every other resource. |
| **Consequence** | Rules cannot be reused by a future edit form, and the validation block sits in the controller. |
| **Reproduce** | static only — `ls Modules/SyllabusBooks/app/Http/Requests/ | grep -i notefile` returns nothing while the controller holds the rules. |
| **Fix approach** | Extract to `NoteFileRequest`, keeping the same rules. |
| **Plan item** | NFC-05 in `02-fix-plan.md` §5 |

```php
        $validated = $request->validate([
            'notes_id'  => ['required', 'integer', 'exists:slb_notes,id'],
            'note_file' => ['required', 'file', 'mimes:pdf,docx,jpg,jpeg,png,epub', 'max:20480'],
            'ordinal'   => ['nullable', 'integer', 'min:1', 'max:255'],
            'is_active' => ['nullable', 'boolean'],
        ]);
```

**Evidence**
```
$ grep -n "request->validate" Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php
52:        $validated = $request->validate([
$ ls Modules/SyllabusBooks/app/Http/Requests/ | grep -i notefile
(no output)
```

### F5 — Routes

clean — five routes, all resolve to existing methods; `{note_file}` matches `SlbNotesFile $noteFile` on the toggle route; the destroy route takes an id (NFC-04). All sit inside the tenant web group.

### F6 — Controller shape

#### NFC-04 · M · CTL-03 — delete takes a raw id instead of a bound model

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:86-90` |
| **Root cause** | The route is `note-files/{note_file}` and the toggle action binds `SlbNotesFile $noteFile`, but `destroy($id)` takes the raw id and calls `findOrFail`. |
| **Consequence** | The delete path cannot use `withTrashed()` or a policy on the model, and it behaves differently from the toggle path for the same URL parameter. |
| **Reproduce** | static only — compare `destroy($id)` with `toggleStatus(Request $request, SlbNotesFile $noteFile)`. |
| **Fix approach** | Bind `SlbNotesFile $noteFile` in `destroy()`. |
| **Plan item** | NFC-04 in `02-fix-plan.md` §5 |

```php
    public function destroy($id): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-file.delete');

        $noteFile = SlbNotesFile::findOrFail($id);
```

**Evidence**
```
$ grep -n "note-files" Modules/SyllabusBooks/routes/web.php
99:Route::resource('note-files', NoteFileController::class)->only(['index', 'create', 'store', 'destroy']);
$ grep -n "public function destroy\|public function toggleStatus" Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php
86:    public function destroy($id): RedirectResponse
109:    public function toggleStatus(Request $request, SlbNotesFile $noteFile): JsonResponse
```

### F7 — Models

#### NFC-01 · B · TEN-01 — note-file media is written to the central database

| Field | Value |
|---|---|
| **Rule** | TEN-01 (B) — *every model using Spatie `InteractsWithMedia` in tenant context must override `getMediaModel()`; otherwise media rows go to the central DB (cross-tenant leak)* (same defect as MDL-05) |
| **Where** | `Modules/SyllabusBooks/app/Models/SlbNotesFile.php:10-12` |
| **Root cause** | The model `implements HasMedia` and uses `InteractsWithMedia` but has no `getMediaModel()`, so Spatie writes `media` rows through the default (central) connection. `SlbNote` and `BookFile` in the same module both override it. |
| **Consequence** | The first note file uploaded from any tenant stores its media row centrally; every tenant's note-file media shares one table, and a central row points at a tenant file path. This is a cross-tenant data leak and breaks file resolution after the tenant connection switches. |
| **Reproduce** | static only — compare with `BookFile::getMediaModel()` at `BookFile.php:43-46` and `SlbNote::getMediaModel()` at `SlbNote.php:107`. |
| **Fix approach** | Add `getMediaModel()` returning `TenantMedia::class`, exactly as `BookFile` does. |
| **Plan item** | NFC-01 in `02-fix-plan.md` §1 |

```php
class SlbNotesFile extends Model implements HasMedia
{
    use SoftDeletes, InteractsWithMedia;
```

**Evidence**
```
$ grep -n "getMediaModel\|InteractsWithMedia" Modules/SyllabusBooks/app/Models/SlbNotesFile.php Modules/SyllabusBooks/app/Models/BookFile.php Modules/SyllabusBooks/app/Models/SlbNote.php
Modules/SyllabusBooks/app/Models/SlbNotesFile.php:8:use Spatie\MediaLibrary\InteractsWithMedia;
Modules/SyllabusBooks/app/Models/SlbNotesFile.php:12:    use SoftDeletes, InteractsWithMedia;
Modules/SyllabusBooks/app/Models/BookFile.php:43:    public function getMediaModel(): string
Modules/SyllabusBooks/app/Models/SlbNote.php:107:    public function getMediaModel(): string
```

### F8 — Services and jobs

clean — no service or job is referenced; the controller does its own writes.

### F9 — Queries and performance

clean — `create()` selects two columns for its dropdown (`:37-39`); no query in a loop (`grep -n "foreach\|map(" Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php` → no output).

### F10 — Views

clean — `note-files/create.blade.php` and `note-files/index.blade.php` render data passed in and build no queries (`grep -nE "::where|DB::|->get\(\)" Modules/SyllabusBooks/resources/views/note-files/*.blade.php` → no output); no `{!! !!}` (`grep -c '{!!'` → 0 in both).

### F11 — Security and tenancy

clean apart from NFC-01 — the upload is validated with `file`+`mimes`+`max`, and files are served by the note download path rather than a public URL.

### F12 — Style

#### NFC-07 · L · STY-02 — the controller is not Pint-clean and has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)*; STY-01 — `declare(strict_types=1)` |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:1-18` |
| **Root cause** | Pint reports `lambda_not_used_import`, `spaces_inside_parentheses`, `unary_operator_spaces`, `not_operator_with_successor_space` and `binary_operator_spaces`; no `declare(strict_types=1)`. |
| **Consequence** | Style only. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php` |
| **Fix approach** | Add strict types and run Pint on the file. |
| **Plan item** | NFC-07 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SyllabusBooks\Http\Controllers;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Http\/Controllers\/NoteFileController.php","fixers":["lambda_not_used_import","spaces_inside_parentheses","unary_operator_spaces","not_operator_with_successor_space","binary_operator_spaces"]}]}
$ grep -c "declare(strict_types=1)" Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php
0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | NFC-02 | ok | ok | ok | ok | ok | NFC-01 |
| `destroy` | ok | NFC-03 | ok | ok | ok | ok | ok | NFC-01 |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | NFC-06 | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SyllabusBooks/app/Models/SlbNote.php` | overrides `getMediaModel()` correctly — checked, not a defect | — | — |

## 8. Not covered, and why

- Nothing was uploaded or deleted (read-only audit, D4); the media-model defect is proven from the class definitions.
- `SlbNote` and the main dashboard belong to other reports and were linked, not re-audited.
