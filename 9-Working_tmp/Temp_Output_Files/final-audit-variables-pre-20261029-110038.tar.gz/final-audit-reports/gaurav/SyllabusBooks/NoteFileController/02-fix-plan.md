# Fix Plan — SyllabusBooks / NoteFileController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SyllabusBooks/routes/web.php` | route file shared by all twelve controllers |
| `Modules/SyllabusBooks/app/Models/SlbNote.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/resources/views/note-files/*.blade.php` | no change needed |

## 1. Blockers reachable today

- [ ] **NFC-01** · B · TEN-01 · `Modules/SyllabusBooks/app/Models/SlbNotesFile.php:10-12` — make Spatie write note-file media to the tenant database.
  - **Touches:** `Modules/SyllabusBooks/app/Models/SlbNotesFile.php`
  - **Before** (`SlbNotesFile.php:1-12`):
    ```php
    <?php

    namespace Modules\SyllabusBooks\Models;

    use Illuminate\Database\Eloquent\Model;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Spatie\MediaLibrary\HasMedia;
    use Spatie\MediaLibrary\InteractsWithMedia;

    class SlbNotesFile extends Model implements HasMedia
    {
        use SoftDeletes, InteractsWithMedia;
    ```
  - **After:**
    ```php
    <?php

    namespace Modules\SyllabusBooks\Models;

    use App\Models\TenantMedia;
    use Illuminate\Database\Eloquent\Model;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Spatie\MediaLibrary\HasMedia;
    use Spatie\MediaLibrary\InteractsWithMedia;

    class SlbNotesFile extends Model implements HasMedia
    {
        use SoftDeletes, InteractsWithMedia;

        public function getMediaModel(): string
        {
            return TenantMedia::class;
        }
    ```
  - **Verify:** `grep -n "getMediaModel\|TenantMedia" Modules/SyllabusBooks/app/Models/SlbNotesFile.php`
  - **Expect:** the import line and `public function getMediaModel(): string` returning `TenantMedia::class`.
  - **Effort:** S

- [ ] **NFC-03** · B · TXN-03 · `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:86-103` — delete the row first, then remove the file, so a failure cannot destroy the upload before the record is safe.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`
  - **Before** (`NoteFileController.php:86-103`):
    ```php
    public function destroy($id): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-file.delete');

        $noteFile = SlbNotesFile::findOrFail($id);

        $noteFile->clearMediaCollection(SlbNotesFile::MEDIA_FILE);

        $noteFile->is_active = false;
        $noteFile->save();
        $noteFile->delete();

        activityLog($noteFile, 'Trashed', ['message' => 'Note file trashed.']);

        return redirect()
            ->route('syllabus-books.index', ['tab' => 'note-files'])
            ->with('success', flash('trashed.note-file'));
    ```
  - **After:**
    ```php
    public function destroy(SlbNotesFile $noteFile): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-file.delete');

        DB::transaction(function () use ($noteFile) {
            $noteFile->is_active = false;
            $noteFile->save();
            $noteFile->delete();

            activityLog($noteFile, 'Trashed', ['message' => 'Note file trashed.']);
        });

        $noteFile->clearMediaCollection(SlbNotesFile::MEDIA_FILE);

        return redirect()
            ->route('syllabus-books.index', ['tab' => 'note-files'])
            ->with('success', flash('trashed.note-file'));
    ```
  - **Verify:** `grep -n "clearMediaCollection" Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`
  - **Expect:** one hit, after the `DB::transaction` closure closes.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **NFC-02** · H · TXN-01 · `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:59-75` — put the row, the media upload, the `media_id` save and the log in one transaction.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`
  - **Before** (`NoteFileController.php:59-75`):
    ```php
        $noteFile = null;

        DB::transaction(function () use ($request, $validated, &$noteFile) {
            $noteFile = SlbNotesFile::create([
                'notes_id'  => $validated['notes_id'],
                'ordinal'   => $validated['ordinal'] ?? 1,
                'is_active' => isset($validated['is_active']) ? (bool) $validated['is_active'] : true,
            ]);
        });

        $media = $noteFile->addMediaFromRequest('note_file')
            ->toMediaCollection(SlbNotesFile::MEDIA_FILE);

        $noteFile->media_id = $media->id;
        $noteFile->save();

        activityLog($noteFile, 'Created', ['message' => 'Note file uploaded.']);
    ```
  - **After:**
    ```php
        $noteFile = DB::transaction(function () use ($request, $validated) {
            $noteFile = SlbNotesFile::create([
                'notes_id'  => $validated['notes_id'],
                'ordinal'   => $validated['ordinal'] ?? 1,
                'is_active' => isset($validated['is_active']) ? (bool) $validated['is_active'] : true,
            ]);

            $media = $noteFile->addMediaFromRequest('note_file')
                ->toMediaCollection(SlbNotesFile::MEDIA_FILE);

            $noteFile->media_id = $media->id;
            $noteFile->save();

            activityLog($noteFile, 'Created', ['message' => 'Note file uploaded.']);

            return $noteFile;
        });
    ```
  - **Verify:** `sed -n '59,75p' Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`
  - **Expect:** a single `DB::transaction` block that contains `addMediaFromRequest`, `$noteFile->save()` and `activityLog`.
  - **Effort:** M

- [ ] **NFC-06** · M · TXN-04 · `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:113-114` — record the status toggle.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`
  - **Before** (`NoteFileController.php:113-114`):
    ```php
        $noteFile->is_active = ! $noteFile->is_active;
        $noteFile->save();
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($noteFile) {
            $noteFile->is_active = ! $noteFile->is_active;
            $noteFile->save();

            activityLog($noteFile, 'Toggled', ['message' => 'Note file status updated.']);
        });
    ```
  - **Verify:** `grep -n "Note file status updated" Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`
  - **Expect:** one hit inside `toggleStatus()`.
  - **Effort:** S

## 4. Authorization (F3)

None.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **NFC-05** · M · VAL-02 · `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:48-57` — move the upload rules into a FormRequest.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`, `Modules/SyllabusBooks/app/Http/Requests/NoteFileRequest.php`
  - **Before** (`NoteFileController.php:48-57`):
    ```php
    public function store(Request $request): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-file.create');

        $validated = $request->validate([
            'notes_id'  => ['required', 'integer', 'exists:slb_notes,id'],
            'note_file' => ['required', 'file', 'mimes:pdf,docx,jpg,jpeg,png,epub', 'max:20480'],
            'ordinal'   => ['nullable', 'integer', 'min:1', 'max:255'],
            'is_active' => ['nullable', 'boolean'],
        ]);
    ```
  - **After:**
    ```php
    public function store(NoteFileRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-file.create');

        $validated = $request->validated();
    ```
  - Add `use Modules\SyllabusBooks\Http\Requests\NoteFileRequest;` to the imports, and create `Modules/SyllabusBooks/app/Http/Requests/NoteFileRequest.php`:
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;

    class NoteFileRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }

        public function rules(): array
        {
            return [
                'notes_id'  => ['required', 'integer', 'exists:slb_notes,id'],
                'note_file' => ['required', 'file', 'mimes:pdf,docx,jpg,jpeg,png,epub', 'max:20480'],
                'ordinal'   => ['nullable', 'integer', 'min:1', 'max:255'],
                'is_active' => ['nullable', 'boolean'],
            ];
        }
    }
    ```
  - **Verify:** `php -l Modules/SyllabusBooks/app/Http/Requests/NoteFileRequest.php && grep -n "NoteFileRequest \$request" Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`
  - **Expect:** `No syntax errors detected` and one hit in `store()`.
  - **Effort:** M

- [ ] **NFC-04** · M · CTL-03 · `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:86` — bind the model on the destroy route.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`
  - **Before** (`NoteFileController.php:86-90`):
    ```php
    public function destroy($id): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-file.delete');

        $noteFile = SlbNotesFile::findOrFail($id);
    ```
  - **After:**
    ```php
    public function destroy(SlbNotesFile $noteFile): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-file.delete');
    ```
  - **Note:** NFC-03 already rewrites this block; apply NFC-03 first and skip this item if the signature is already `SlbNotesFile $noteFile`.
  - **Verify:** `grep -n "public function destroy" Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`
  - **Expect:** `public function destroy(SlbNotesFile $noteFile): RedirectResponse`.
  - **Effort:** S

## 6. Queries & performance (F9)

None.

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **NFC-07** · L · STY-02 · `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php:1` — add `strict_types` and make the file Pint-clean.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`
  - **Before** (`NoteFileController.php:1-3`):
    ```php
    <?php

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - Then run `vendor/bin/pint Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php --format agent` and accept its spacing changes.
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/NoteFileController.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** S

## 9. Deferred / decisions

None.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | every finding has a plan item |
