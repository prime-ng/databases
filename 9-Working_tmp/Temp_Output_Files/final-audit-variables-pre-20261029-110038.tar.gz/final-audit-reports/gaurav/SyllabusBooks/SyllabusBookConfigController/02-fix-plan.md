# Fix Plan — SyllabusBooks / SyllabusBookConfigController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/tenancy.php` | platform configuration shared by every module; enabling the cache bootstrapper is a platform change, not this controller's fix |
| `app/Traits/AuthorizesTenantFeature.php` | common trait used by other modules |
| `Modules/SyllabusBooks/database/seeders/*` | a seeder change is Tarun's hand (SBC-02 option b) |

## 1. Blockers reachable today

None at B severity.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **SBC-01** · H · TEN-02 · `Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php:55-65` — scope the settings cache key to the current tenant so one tenant cannot read another's configuration.
  - **Touches:** `Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php`
  - **Before** (`SyllabusBookConfig.php:55-65`):
    ```php
    public static function current(): self
    {
        return Cache::remember(self::CACHE_KEY, self::CACHE_TTL, function () {
            return self::query()->firstOrCreate(['id' => 1]);
        });
    }

    public static function flushCache(): void
    {
        Cache::forget(self::CACHE_KEY);
    }
    ```
  - **After:**
    ```php
    public static function current(): self
    {
        return Cache::remember(self::cacheKey(), self::CACHE_TTL, function () {
            return self::query()->firstOrCreate(['id' => 1]);
        });
    }

    public static function cacheKey(): string
    {
        return self::CACHE_KEY.'.'.(tenant('id') ?? 'central');
    }

    public static function flushCache(): void
    {
        Cache::forget(self::cacheKey());
    }
    ```
  - **Verify:** `grep -n "cacheKey()" Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php`
  - **Expect:** three lines: the `Cache::remember(self::cacheKey()…)` call, the `public static function cacheKey(): string` declaration and the `Cache::forget(self::cacheKey())` call.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **SBC-03** · M · AUTH-05 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php:18-20` — gate the settings page on `viewAny`, not `update`, so the declared view permission is not dead.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php`
  - **Before** (`SyllabusBookConfigController.php:18-20`):
    ```php
    public function edit(): View
    {
        Gate::authorize('tenant.syllabus-books.syllabus-book-config.update');
    ```
  - **After:**
    ```php
    public function edit(): View
    {
        Gate::authorize('tenant.syllabus-books.syllabus-book-config.viewAny');
    ```
  - **Verify:** `grep -n "Gate::authorize" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php`
  - **Expect:** line 20 reads `...syllabus-book-config.viewAny` and line 29 still reads `...syllabus-book-config.update`.
  - **Effort:** S

- [ ] **SBC-04** · L · AUTH-04 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php:27-31` — drop the controller's duplicate permission check; the FormRequest already authorizes the same permission for PUT.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php`
  - **Before** (`SyllabusBookConfigController.php:27-31`):
    ```php
    public function update(SyllabusBookConfigRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.syllabus-book-config.update');

        $this->service->update($request->validated());
    ```
  - **After:**
    ```php
    public function update(SyllabusBookConfigRequest $request): RedirectResponse
    {
        $this->service->update($request->validated());
    ```
  - **Verify:** `grep -c "Gate::authorize" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php`
  - **Expect:** `1` (only the `edit()` gate remains).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

clean — no items.

## 6. Queries & performance (F9)

clean — no items.

## 7. Views (F10)

clean — no items.

## 8. Style (F12) — one item per file

- [ ] **SBC-05** · L · STY-02 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php:1` — add `strict_types` and make the file Pint-clean.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php`
  - **Before** (`SyllabusBookConfigController.php:1-3`):
    ```php
    <?php

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - Then run `vendor/bin/pint Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php --format agent` and accept its only change: the empty constructor body collapses to one line —
    ```php
        public function __construct(private readonly SyllabusBookConfigService $service) {}
    ```
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** S

- [ ] **SBC-06** · L · STY-02 · `Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php:1` — add `strict_types` and make the file Pint-clean.
  - **Touches:** `Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php`
  - **Before** (`SyllabusBookConfig.php:1-3`):
    ```php
    <?php

    namespace Modules\SyllabusBooks\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Models;
    ```
  - Then run `vendor/bin/pint Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php --format agent` and accept its `class_attributes_separation` and `binary_operator_spaces` changes.
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **SBC-02** · M · DECISION · SVC-03 — the Settings page creates the config row on first read (`firstOrCreate(['id' => 1])`). Keep that, or create the row once in a seeder and make the read pure?
  - **Why it is a decision:** option (b) changes a seeder, which this workflow does not run (D4/Tarun's hand); option (a) accepts a write on a GET path.
  - (a) ⭐ accept the lazy create — it bootstraps the singleton row on an admin-only page and keeps this pass small; record it as accepted.
  - (b) add the row in `SyllabusBooksSeeder` and change `current()` to `self::query()->first()`; Tarun runs the seeder on new tenants.
  - (c) replace `['id' => 1]` with `firstOrCreate([])` and no hard-coded id, keeping the lazy write.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | every finding has a plan item |
