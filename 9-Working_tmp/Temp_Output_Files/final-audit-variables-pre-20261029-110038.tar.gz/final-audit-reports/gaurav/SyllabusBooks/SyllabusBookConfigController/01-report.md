# Final Audit — SyllabusBooks / SyllabusBookConfigController

**Audited:** 2026-10-28 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php` (37 lines, 2 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /syllabus-books/config` (edit) · `PUT /syllabus-books/config` (update) |
| Menu path | Syllabus Books → Settings (module tab; the page is reached from the module settings entry) |
| Who uses it | Any role holding `tenant.syllabus-books.syllabus-book-config.update`. Permission is declared in `config/permissionslist.php:1019`. Seeded role assignments were not queried — `⚠ UNVERIFIED — a SELECT on sys_role_has_permissions_jnt for this key would settle it.` |
| What a user does here | Sets tenant-wide limits for the module: maximum book and note file sizes, allowed formats, whether books/notes are downloadable, student upload and approval rules, watermark/print/copy protection and class visibility. Saving rewrites the single config row and clears its cache. |
| Tables written | `slb_config` (created lazily on the first read, updated on save) |
| Tables read | `slb_config` |
| Live data | `slb_config` = 1 row on `test.localhost` (`php artisan tinker` SELECT count, 2026-10-28) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready: the settings page reads a cache key that is shared by every tenant, so a tenant can be shown (and partly re-save) another tenant's configuration. The write-on-read `firstOrCreate` and the dead `viewAny` permission are smaller but real. Rough effort: one session (S/M).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 2 | 3 | 1 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | SBC-02 |
| F2 Transactions/Audit | clean | F9 Queries/Perf | clean |
| F3 Authorization | SBC-03, SBC-04 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | SBC-01 |
| F5 Routes | clean | F12 Style | SBC-05, SBC-06 |
| F6 Controller shape | clean | F13 Deep read | no new defect |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php` | controller | 37 | this report | ✅ |
| 2 | `Modules/SyllabusBooks/app/Http/Requests/SyllabusBookConfigRequest.php` | FormRequest | 58 | this report | ✅ |
| 3 | `Modules/SyllabusBooks/app/Services/SyllabusBookConfigService.php` | service | 23 | ↗ [gaurav/SyllabusBooks/SyllabusBookConfigController](01-report.md) | ✅ |
| 4 | `Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php` | model | 72 | ↗ [gaurav/SyllabusBooks/SyllabusBookConfigController](01-report.md) | ✅ |
| 5 | `Modules/SyllabusBooks/app/Policies/SyllabusBookConfigPolicy.php` | policy | 18 | ↗ [gaurav/SyllabusBooks/SyllabusBookConfigController](01-report.md) | ✅ |
| 6 | `Modules/SyllabusBooks/resources/views/config/edit.blade.php` | blade | 157 | this report | ✅ |
| 7 | `app/Traits/AuthorizesTenantFeature.php` | common trait | 55 | common — not audited (protocol §4.2) | ❌ common |
| 8 | `app/Helpers/activityLog.php` | common helper | 51 | common — not audited (protocol §4.2) | ❌ common |

No pre-applied files.

## 4. Routes

```
GET|HEAD  syllabus-books/config  syllabus-books.config.edit    Modules\SyllabusBooks\Http\Controllers\SyllabusBookConfigController@edit
PUT       syllabus-books/config  syllabus-books.config.update  Modules\SyllabusBooks\Http\Controllers\SyllabusBookConfigController@update
```

Unrouted public methods: none — `grep -nE 'public function [a-zA-Z_]+'` returns only `__construct`, `edit` and `update`, and both actions are routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `edit` | 18 | GET /syllabus-books/config | `tenant.syllabus-books.syllabus-book-config.update` | none (read path) | none | `slb_config` (lazy `firstOrCreate` inside `current()`) | SBC-02, SBC-03 |
| `update` | 27 | PUT /syllabus-books/config | `tenant.syllabus-books.syllabus-book-config.update` + FormRequest `...update` | none (one row, one statement) | none | `slb_config` | SBC-01, SBC-04 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try \{|catch \(|getMessage' Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php Modules/SyllabusBooks/app/Services/SyllabusBookConfigService.php` → no output.

### F2 — Transactions and audit

clean — one write per request (`$config->fill($payload)->save()` at `SyllabusBookConfigService.php:19`) and a single-row table; `grep -n "DB::transaction\|activityLog" Modules/SyllabusBooks/app/Services/SyllabusBookConfigService.php` → no output; no second table to keep in step.

### F3 — Authorization

#### SBC-03 · M · AUTH-05 — the read page checks the *update* permission, so `viewAny` is dead

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — *no dead permission logic; a permission that is declared and never consulted is dead* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php:18-20`, method `edit()` |
| **Root cause** | `edit()` authorizes `...syllabus-book-config.update` instead of `...syllabus-book-config.viewAny`. The policy declares `viewAny()` and `config/permissionslist.php:1019` seeds it, but nothing ever calls it, so a role granted only `viewAny` gets a 403 on the settings page while a role granted `update` can read it. |
| **Consequence** | A read-only administrator cannot open Settings although their role says they may view it. |
| **Reproduce** | Log in as a role holding `tenant.syllabus-books.syllabus-book-config.viewAny` but not `.update`, open `/syllabus-books/config` → 403. |
| **Fix approach** | Gate `edit()` on `.viewAny`; leave `update()` on `.update`. |
| **Plan item** | SBC-03 in `02-fix-plan.md` §4 |

```php
    public function edit(): View
    {
        Gate::authorize('tenant.syllabus-books.syllabus-book-config.update');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php
20:        Gate::authorize('tenant.syllabus-books.syllabus-book-config.update');
29:        Gate::authorize('tenant.syllabus-books.syllabus-book-config.update');
$ grep -n "viewAny" Modules/SyllabusBooks/app/Policies/SyllabusBookConfigPolicy.php
9:    public function viewAny(User $user): bool
```

#### SBC-04 · L · AUTH-04 — the same permission is checked twice on update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (FormRequest + Gate); keep one* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php:27-31` and `Modules/SyllabusBooks/app/Http/Requests/SyllabusBookConfigRequest.php:12-18`, method `update()` |
| **Root cause** | The FormRequest's `authorize()` already maps PUT to `...syllabus-book-config.update`; the controller repeats the same `Gate::authorize` on line 29. |
| **Consequence** | Two places must stay in sync; a later change to one silently widens or narrows the other. |
| **Reproduce** | static only — both checks read the same permission string. |
| **Fix approach** | Keep the FormRequest check (it runs first) and drop the duplicate in the controller. |
| **Plan item** | SBC-04 in `02-fix-plan.md` §4 |

```php
    public function update(SyllabusBookConfigRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.syllabus-book-config.update');

        $this->service->update($request->validated());
```

**Evidence**
```
$ grep -n "authorizeByCrudPermission\|Gate::authorize" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php Modules/SyllabusBooks/app/Http/Requests/SyllabusBookConfigRequest.php
Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php:20:        Gate::authorize('tenant.syllabus-books.syllabus-book-config.update');
Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php:29:        Gate::authorize('tenant.syllabus-books.syllabus-book-config.update');
Modules/SyllabusBooks/app/Http/Requests/SyllabusBookConfigRequest.php:17:        return $this->authorizeByCrudPermission('tenant.syllabus-books.syllabus-book-config');
```

### F4 — Validation and input

clean — `SyllabusBookConfigRequest.php:22-39` types every field (`integer`, `boolean`, `in:`, `string|max:150`), `update()` writes only `$request->validated()`; `grep -n "request->all()\|->except(" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php Modules/SyllabusBooks/app/Services/SyllabusBookConfigService.php` → no output.

### F5 — Routes

clean — two routes, both point at existing methods (`php artisan route:list` output in §4), both inside the module's web group with `InitializeTenancyByDomain`, `auth` and `verified` (`Modules/SyllabusBooks/app/Providers/RouteServiceProvider.php:50-61`); no state change over GET beyond SBC-02.

### F6 — Controller shape

clean — 37 lines, 2 public methods, constructor injection, return types on both methods.

### F7 — Models

clean — `$fillable` declared (`SyllabusBookConfig.php:18-36`), `$casts` cover every boolean and integer flag (`:38-53`), `$table = 'slb_config'` exists in the tenant schema (`SHOW TABLES LIKE 'slb%'` → `slb_config`), `SoftDeletes` matches the table. Model shape is clean apart from the cache key (SBC-01, F11) and style (SBC-06).

### F8 — Services and jobs

#### SBC-02 · M · DECISION · SVC-03 — a GET page creates a database row

| Field | Value |
|---|---|
| **Rule** | SVC-03 (M) — *no writes on read paths; `firstOrCreate` inside a method called by a GET page is a write* |
| **Where** | `Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php:55-60`, called by `SyllabusBookConfigService::get()` from `edit()` |
| **Root cause** | `current()` uses `firstOrCreate(['id' => 1])` so the settings row is created the first time the page is opened, and the literal id `1` assumes the row number. |
| **Consequence** | Opening Settings writes to the tenant database; a tenant that never saved settings still has a row created by whoever viewed the page first. |
| **Reproduce** | static only — the write runs on the `GET /syllabus-books/config` path through `service->get()`. |
| **Fix approach** | Decide whether lazy creation is intentional. It needs a seeder change, so it is a DECISION. |
| **Plan item** | SBC-02 in `02-fix-plan.md` §9 |

```php
    public static function current(): self
    {
        return Cache::remember(self::CACHE_KEY, self::CACHE_TTL, function () {
            return self::query()->firstOrCreate(['id' => 1]);
        });
    }
```

**Evidence**
```
$ grep -n "firstOrCreate\|Cache::remember" Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php
57:        return Cache::remember(self::CACHE_KEY, self::CACHE_TTL, function () {
58:            return self::query()->firstOrCreate(['id' => 1]);
$ grep -n "service->get()" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php
22:        $config = $this->service->get();
```

### F9 — Queries and performance

clean — one cached single-row read per request; `grep -n "foreach\|->get()\|::all()" Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php Modules/SyllabusBooks/app/Services/SyllabusBookConfigService.php` → no output.

### F10 — Views

clean — `config/edit.blade.php` renders only the `$config` passed by the controller and loops over two hard-coded format arrays; `grep -n "::where\|::find\|DB::\|->get()" Modules/SyllabusBooks/resources/views/config/edit.blade.php` → no output. No `{!! !!}` in the file (`grep -c '{!!'` → 0). The form posts to the named route with `@csrf @method('PUT')` (lines 27-28).

### F11 — Security and tenancy

#### SBC-01 · H · TEN-02 — the settings cache key is shared by every tenant

| Field | Value |
|---|---|
| **Rule** | TEN-02 (H) — *cache keys must include the tenant; a global key leaks values across tenants* (raised from H's default only by one clause: the cached value is tenant configuration, not personal data) |
| **Where** | `Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php:13` and `:55-65`, method `current()` / `flushCache()` |
| **Root cause** | `CACHE_KEY = 'slb.config'` is a constant and `CacheTenancyBootstrapper` is disabled in `config/tenancy.php:37-40`, so every tenant reads and writes the same cache entry. The first tenant to open Settings fills it for all tenants. |
| **Consequence** | Tenant B's Settings page shows tenant A's size limits, format allow-list, watermark text and download flags until the 300-second TTL expires; `update()` then saves B's form over B's row, but any field the form did not post keeps A's cached value. |
| **Reproduce** | static only — open `/syllabus-books/config` on two tenants within five minutes; the second renders the first tenant's values. |
| **Fix approach** | Suffix the cache key with `tenant('id')`; use the same helper in `flushCache()`. |
| **Plan item** | SBC-01 in `02-fix-plan.md` §3 |

```php
    public static function current(): self
    {
        return Cache::remember(self::CACHE_KEY, self::CACHE_TTL, function () {
            return self::query()->firstOrCreate(['id' => 1]);
        });
    }

    public static function flushCache(): void
    {
        Cache::forget(self::CACHE_KEY);
    }
```

**Evidence**
```
$ grep -n "CACHE_KEY\|Cache::remember\|Cache::forget" Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php
13:    public const CACHE_KEY = 'slb.config';
57:        return Cache::remember(self::CACHE_KEY, self::CACHE_TTL, function () {
64:        Cache::forget(self::CACHE_KEY);
$ sed -n '36,41p' config/tenancy.php
        // CacheTenancyBootstrapper is intentionally disabled because the current
        // default cache driver is 'database', which does not support cache tags.
        // Re-enable it (and RedisTenancyBootstrapper) once the cache driver is
        // switched to redis, otherwise cache keys will leak across tenants.
```

### F12 — Style

#### SBC-05 · L · STY-02 — controller is not Pint-clean and has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)*; STY-01 — `declare(strict_types=1)` in touched files |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php:1-16`, class header and constructor |
| **Root cause** | `vendor/bin/pint --test` reports `single_line_empty_body`; the file has no `declare(strict_types=1)`. |
| **Consequence** | Style only; no user-visible effect. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php` |
| **Fix approach** | Add `declare(strict_types=1)` and collapse the empty constructor. |
| **Plan item** | SBC-05 in `02-fix-plan.md` §8 |

```php
    public function __construct(private readonly SyllabusBookConfigService $service)
    {
    }
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Http\/Controllers\/SyllabusBookConfigController.php","fixers":["single_line_empty_body"]}]}
$ grep -c "declare(strict_types=1)" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookConfigController.php
0
```

#### SBC-06 · L · STY-02 — model is not Pint-clean and has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)*; STY-01 — `declare(strict_types=1)` |
| **Where** | `Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php:1`, file header |
| **Root cause** | `vendor/bin/pint --test` reports `class_attributes_separation` and `binary_operator_spaces`; the file has no `declare(strict_types=1)`. |
| **Consequence** | Style only. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php` |
| **Fix approach** | Run Pint on the file and add `declare(strict_types=1)` after the opening tag. |
| **Plan item** | SBC-06 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SyllabusBooks\Models;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Models\/SyllabusBookConfig.php","fixers":["class_attributes_separation","binary_operator_spaces"]}]}
$ grep -c "declare(strict_types=1)" Modules/SyllabusBooks/app/Models/SyllabusBookConfig.php
0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `update` | ok (writes only validated fields) | ok (single row update) | ok | n/a | ok (single row, id 1) | SBC-03 (read), SBC-04 (dup) | ok ("Settings updated successfully.") | SBC-02 (lazy row) |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `config/tenancy.php` | `CacheTenancyBootstrapper` is disabled whenever the cache driver is `database`; every module that caches tenant data with a bare key inherits SBC-01 | TEN-02 | platform owner, one change for all modules |

## 8. Not covered, and why

- Seeded role assignments were not queried (no role/permission SELECT was run); SBC-03 is proven from the code, not from a live 403.
- The cache leak was proven statically: reproducing it needs two tenant domains and a warm cache, which this read-only pass cannot do without browsing.
- `app/Traits/AuthorizesTenantFeature.php` and `app/Helpers/activityLog.php` are common classes (protocol §4.2) and were not audited.
