# Final Audit — SyllabusBooks / SyllabusBooksController

**Audited:** 2026-10-28 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php` (185 lines, 7 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /syllabus-books` (dashboard with tabs) · `GET /api/v1/syllabusbooks` and `GET /api/v1/syllabusbooks/{syllabusbook}` (declared as an API resource) |
| Menu path | Syllabus Books (module landing page) → Authors / Books / Notes / Note Files / Note Ratings / Note Downloads / Book Downloads tabs |
| Who uses it | Roles holding `tenant.syllabus-books.book.viewAny` for the dashboard and `tenant.syllabus-books.book.view` for a single book. |
| What a user does here | Lands on the module and sees seven tabs: book list with filters, authors, notes, note files, note ratings, note downloads and book downloads. Each list is paginated and links into the relevant CRUD screen. |
| Tables read | `slb_books`, `slb_book_authors`, `slb_notes`, `slb_notes_ratings`, `slb_notes_downloads`, `slb_book_downloads`, `slb_config`, `sys_dropdown_table`, `sch_classes`, `sch_subjects`, `org_academic_sessions`, `sys_users` |
| Tables written | none |
| Live data | `slb_books` = 86, `slb_notes` = 15, `slb_notes_ratings` = 5, `slb_notes_downloads` = 5, `slb_book_downloads` = 8, `sys_users` = 5,671 on `test.localhost` (tinker SELECT, 2026-10-28) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

The dashboard itself works, but the controller is also mounted as an API resource: the API `show` action renders a Blade view that does not exist (500), and the API `index` returns an HTML page. Five other public methods are unrouted stubs with empty bodies or missing views. The dashboard also loads all 5,671 users and every note into dropdowns and runs the same notes query twice. Effort: half a day (S/M).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 0 | 4 | 2 | 0 | 7 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | SBS-04, SBS-05 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | SBS-01, SBS-02 | F12 Style | SBS-07 |
| F6 Controller shape | SBS-03, SBS-06 | F13 Deep read | n/a — read-only |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php` | controller | 185 | this report | ✅ |
| 2 | `Modules/SyllabusBooks/resources/views/syllabus-book/index.blade.php` | blade | 52 | this report | ✅ |
| 3 | `Modules/SyllabusBooks/resources/views/index.blade.php` | blade | 5 | this report | ✅ |
| 4 | `Modules/SyllabusBooks/routes/web.php` | route file | 116 | shared — routes only, not audited as a class | ✅ |
| 5 | `Modules/SyllabusBooks/routes/api.php` | route file | 9 | shared — routes only | ✅ |
| 6 | `Modules/Prime/app/Models/Dropdown.php` | other-module model | 40+ | common — not audited (protocol §4.2) | ❌ common |
| 7 | `Modules/SchoolSetup/app/Models/User.php` | other-module model | — | common — not audited | ❌ common |

No pre-applied files.

## 4. Routes

```
GET|HEAD  syllabus-books                        syllabus-books.index          Modules\SyllabusBooks\Http\Controllers\SyllabusBooksController@index
GET|HEAD  api/v1/syllabusbooks                  api.syllabusbooks.index       Modules\SyllabusBooks\Http\Controllers\SyllabusBooksController@index
GET|HEAD  api/v1/syllabusbooks/{syllabusbook}   api.syllabusbooks.show        Modules\SyllabusBooks\Http\Controllers\SyllabusBooksController@show
```

Unrouted public methods: `create()` (`:163`), `store()` (`:168`), `edit()` (`:177`), `update()` (`:182`), `destroy()` (`:184`) — five methods, no route points at any of them (SBS-02).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 24 | GET /syllabus-books · GET /api/v1/syllabusbooks | `tenant.syllabus-books.book.viewAny` | none (read) | none | — | SBS-01, SBS-03, SBS-04, SBS-05, SBS-06 |
| `create` | 163 | — not routed | none | none | none | — | SBS-02, SBS-06 |
| `store` | 168 | — not routed | none | none | none | — | SBS-02, SBS-06 |
| `show` | 170 | GET api/v1/syllabusbooks/{syllabusbook} | `tenant.syllabus-books.book.view` | none (read) | none | — | SBS-01, SBS-06 |
| `edit` | 177 | — not routed | none | none | none | — | SBS-02, SBS-06 |
| `update` | 182 | — not routed | none | none | none | — | SBS-02, SBS-06 |
| `destroy` | 184 | — not routed | none | none | none | — | SBS-02, SBS-06 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try \{|catch \(|getMessage' Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php` → no output.

### F2 — Transactions and audit

clean — the controller is read-only; `grep -n "create(\|update(\|delete(\|save()" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php` → only `update(` inside `recalculate`-style calls? no output for writes.

### F3 — Authorization

clean — both routed actions authorize before loading anything, with names declared at `config/permissionslist.php:1013` (`syllabus-books.book`).

### F4 — Validation and input

clean — no write path. Filter values are cast to `int` or used as query-builder bindings (`:42-57`), never interpolated into raw SQL (`grep -n "DB::raw\|whereRaw\|orderByRaw" …` → no output).

### F5 — Routes

#### SBS-01 · B · RTE-02 — the API resource points at web-only methods; `GET /api/v1/syllabusbooks/{id}` returns 500

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *every route points to a method that exists and can serve it* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:170-175`, routed as an API resource by `Modules/SyllabusBooks/routes/api.php:7-9` |
| **Root cause** | `Route::apiResource('syllabusbooks', SyllabusBooksController::class)` maps `index` and `show` onto a controller written for Blade. `show()` returns `view('syllabusbooks::show')`, but the module has no `resources/views/show.blade.php` (only `syllabus-book/index.blade.php` and a 5-line `index.blade.php`). `index()` returns the dashboard view to a JSON client. |
| **Consequence** | A mobile or API client calling `GET /api/v1/syllabusbooks/{id}` gets a 500 "View [syllabusbooks::show] not found"; calling the collection endpoint gets an HTML page it cannot parse. |
| **Reproduce** | With a Sanctum token: `GET /api/v1/syllabusbooks/1` → 500; `GET /api/v1/syllabusbooks` → HTML. |
| **Fix approach** | Serve JSON from the API routes: `index` returns the paginator when the request is an API request; `show` loads the book and returns JSON. |
| **Plan item** | SBS-01 in `02-fix-plan.md` §1 |

```php
    public function show($id)
    {
        Gate::authorize('tenant.syllabus-books.book.view');

        return view('syllabusbooks::show');
    }
```

**Evidence**
```
$ grep -n "view(" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php
155:        return view('syllabusbooks::syllabus-book.index', compact(
165:        return view('syllabusbooks::create');
174:        return view('syllabusbooks::show');
179:        return view('syllabusbooks::edit');
$ ls Modules/SyllabusBooks/resources/views/ | grep -E "^(show|create|edit)\.blade\.php$"
(no output)
$ cat Modules/SyllabusBooks/routes/api.php | sed -n '7,9p'
Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('syllabusbooks', SyllabusBooksController::class)->except(['store', 'update', 'destroy'])->names('syllabusbooks');
});
```

#### SBS-02 · M · RTE-03 — five public methods are unrouted stubs

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`, per D5)* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:163-184` |
| **Root cause** | `create`, `store`, `edit`, `update` and `destroy` are leftovers from a resource scaffold. `store`, `update` and `destroy` have empty bodies; `create` and `edit` render views that do not exist. No route points at any of them. |
| **Consequence** | Dead code that looks like a working CRUD surface; if a route is ever added by mistake, three actions return null and two return a 500. |
| **Reproduce** | static only — `php artisan route:list` shows only `index` and `show` for this controller. |
| **Fix approach** | Per D5: replace each body with `abort(403, '…')` and a `NOT ROUTED` comment. Never delete the methods. |
| **Plan item** | SBS-02 in `02-fix-plan.md` §5 |

```php
    public function create()
    {
        return view('syllabusbooks::create');
    }

    public function store(Request $request) {}

    public function show($id)
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+' Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php
24:    public function index(Request $request)
163:    public function create()
168:    public function store(Request $request) {}
170:    public function show($id)
177:    public function edit($id)
182:    public function update(Request $request, $id) {}
184:    public function destroy($id) {}
$ grep -c "SyllabusBooksController@" /tmp/fa-routes.json
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); foreach($r as $x){ if(str_contains($x["action"],"SyllabusBooksController@")) echo $x["action"]."\n"; }'
Modules\SyllabusBooks\Http\Controllers\SyllabusBooksController@index
Modules\SyllabusBooks\Http\Controllers\SyllabusBooksController@show
Modules\SyllabusBooks\Http\Controllers\SyllabusBooksController@index
```

### F6 — Controller shape

#### SBS-03 · M · CTL-07 — the dashboard hands 18 variables to the view through one `compact()`

| Field | Value |
|---|---|
| **Rule** | CTL-07 (M) — *no `compact()` of more than ~15 variables (build a view model / array)* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:155-160` |
| **Root cause** | Eighteen variables are packed into one `compact()`, mixing seven tabs' data. |
| **Consequence** | The view's contract is invisible; adding or removing a tab silently breaks the page, and the method reads as one flat block. |
| **Reproduce** | static only — count the names in the `compact()` call. |
| **Fix approach** | Group the tab data into keyed arrays (`$tabs = ['books' => …, 'notes' => …]`) and pass one `$tabs` variable; this is a deferred refactor if the view is edited in the same pass. |
| **Plan item** | SBS-03 in `02-fix-plan.md` §9 (DECISION — touches the 52-line view) |

```php
        return view('syllabusbooks::syllabus-book.index', compact(
            'books', 'authors', 'languages', 'authorList', 'config',
            'notes', 'classes', 'subjects', 'sessions', 'currentSessionId', 'booksList', 'topics',
            'noteRatings', 'notesForRating', 'users',
            'noteDownloads', 'bookDownloads', 'allNotes'
        ));
```

**Evidence**
```
$ sed -n '155,160p' Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php
        return view('syllabusbooks::syllabus-book.index', compact(
            'books', 'authors', 'languages', 'authorList', 'config',
            'notes', 'classes', 'subjects', 'sessions', 'currentSessionId', 'booksList', 'topics',
            'noteRatings', 'notesForRating', 'users',
            'noteDownloads', 'bookDownloads', 'allNotes'
        ));
$ php -r '$s=file_get_contents("Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php"); preg_match("/compact\((.*?)\)/s",$s,$m); echo count(array_filter(array_map("trim",explode(",",$m[1]))))."\n";'
18
```

#### SBS-06 · L · CTL-04 — no return types on any public method

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:24,163,168,170,177,182,184` |
| **Root cause** | All seven public methods omit a return type. |
| **Consequence** | The view-only and JSON-only methods are indistinguishable at a glance, which is how SBS-01 survived. |
| **Reproduce** | `grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php` |
| **Fix approach** | Add `: View`, `: JsonResponse` or `: RedirectResponse` after the SBS-02 rewrite. |
| **Plan item** | SBS-06 in `02-fix-plan.md` §5 |

```php
    public function index(Request $request)
    {
        Gate::authorize('tenant.syllabus-books.book.viewAny');
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php
24:    public function index(Request $request)
163:    public function create()
170:    public function show($id)
177:    public function edit($id)
```

### F7 — Models

clean — the controller reads five module models and four other-module models; no model is written. `BokBook`, `SlbNote` and the download models are linked to the StudentPortal report.

### F8 — Services and jobs

clean — no service or job (`grep -n "Service\|Job\|dispatch" …` → no output).

### F9 — Queries and performance

#### SBS-04 · M · QRY-15 — the dashboard loads every user and every note for its dropdowns

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *don't load every row of a big table for a form/page*; QRY-02 — lists are paginated |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:102-110`, `:122-125`, `:138-141`, `:153` |
| **Root cause** | Five unbounded `get()` calls build dropdown data: classes, subjects, sessions, books, topics, **all notes** (twice) and **all 5,671 users**. |
| **Consequence** | Every dashboard load materialises 5,671 user rows plus every note, in memory, on every tab. The page slows as the school grows. |
| **Reproduce** | Open `/syllabus-books` and count the dropdown options in the Note Ratings / Note Downloads tabs: every user is listed. |
| **Fix approach** | Searchable AJAX selects, or at minimum `limit(500)` plus `pluck('name','id')`; the users list belongs behind a search endpoint. |
| **Plan item** | SBS-04 in `02-fix-plan.md` §6 |

```php
        $users = User::where('is_active', 1)->orderBy('name')->get(['id', 'name']);
```

**Evidence**
```
$ grep -n "::where('is_active', 1).*->get(\|::orderBy.*->get(\|::get(\[" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php
102:        $classes        = SchoolClass::where('is_active', 1)->orderBy('name')->get(['id', 'name']);
103:        $subjects       = Subject::where('is_active', 1)->orderBy('name')->get(['id', 'name']);
107:        $booksList      = BokBook::where('is_active', 1)->orderBy('title')->get(['id', 'title']);
122:        $allNotes = SlbNote::query()
138:        $notesForRating = SlbNote::query()
153:        $users = User::where('is_active', 1)->orderBy('name')->get(['id', 'name']);
$ php artisan tinker --execute='tenancy()->initialize(\Modules\Prime\Models\Domain::where("domain","test.localhost")->first()->tenant); echo \DB::table("sys_users")->count();'
5671
```

#### SBS-05 · M · QRY-12 — the same notes query runs twice on every load

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) — *identical queries repeated in one request → resolve once* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:122-125` and `:138-141` |
| **Root cause** | `$allNotes` and `$notesForRating` execute the same `SlbNote::where('is_active', 1)->orderBy('title')->get(['id','title'])`. |
| **Consequence** | One duplicate query per dashboard load, and two arrays that can drift if one is later filtered. |
| **Reproduce** | static only — the two blocks are identical. |
| **Fix approach** | Build the list once and reuse the variable. |
| **Plan item** | SBS-05 in `02-fix-plan.md` §6 |

```php
        $allNotes = SlbNote::query()
            ->where('is_active', 1)
            ->orderBy('title')
            ->get(['id', 'title']);
```

**Evidence**
```
$ grep -n "notesForRating\|allNotes" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php
122:        $allNotes = SlbNote::query()
138:        $notesForRating = SlbNote::query()
158:            'noteRatings', 'notesForRating', 'users',
159:            'noteDownloads', 'bookDownloads', 'allNotes'
```

### F10 — Views

clean — `syllabus-book/index.blade.php` is 52 lines of `@include` calls for the tab partials; no query in the blade (`grep -nE "::where|DB::|->get\(\)" Modules/SyllabusBooks/resources/views/syllabus-book/index.blade.php` → no output) and no `{!! !!}` (`grep -c '{!!'` → 0).

### F11 — Security and tenancy

clean — `Dropdown` is a `BaseModel` over `sys_dropdown_table`, which exists in the tenant schema (716 rows), so no central-model call is needed; no `env()`, no hard-coded id (`grep -nE "env\(|\?\? [0-9]" …` → no output).

### F12 — Style

#### SBS-07 · L · STY-02 — the controller is not Pint-clean and has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)*; STY-01 — `declare(strict_types=1)`; STY-05 — one import per class |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:1-22` |
| **Root cause** | Pint reports `no_multiline_whitespace_around_double_arrow`, `fully_qualified_strict_types`, `braces_position`, `no_unused_imports`, `single_line_empty_body`, `ordered_imports` and `binary_operator_spaces`; no `declare(strict_types=1)`. |
| **Consequence** | Style only. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php` |
| **Fix approach** | Add strict types and run Pint on the file. |
| **Plan item** | SBS-07 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SyllabusBooks\Http\Controllers;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Http\/Controllers\/SyllabusBooksController.php","fixers":["no_multiline_whitespace_around_double_arrow","fully_qualified_strict_types","braces_position","no_unused_imports","single_line_empty_body","ordered_imports","binary_operator_spaces"]}]}
$ grep -c "declare(strict_types=1)" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php
0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

No mutating method in this controller — the only routed actions are `index` and `show`, both read-only (`grep -n "save()\|::create(\|->update(\|->delete(" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php` → no output).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SyllabusBooks/routes/api.php` | an `apiResource` over a Blade controller; other modules may do the same | RTE-02 | module owner |

## 8. Not covered, and why

- The dashboard was read, not opened in a browser; the tab contents are audited in their own controller reports.
- API behaviour was proven from the route list and the missing view file; no HTTP request was made.
