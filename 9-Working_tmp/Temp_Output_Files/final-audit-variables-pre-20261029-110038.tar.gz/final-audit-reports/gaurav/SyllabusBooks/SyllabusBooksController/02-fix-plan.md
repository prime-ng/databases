# Fix Plan — SyllabusBooks / SyllabusBooksController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SyllabusBooks/resources/views/**` | tab partials belong to the other controller reports |
| `Modules/SyllabusBooks/app/Models/*` | owned by this report's models are linked to the StudentPortal report |
| `Modules/SyllabusBooks/app/Http/Controllers/BookController.php` | separate report |

## 1. Blockers reachable today

- [ ] **SBS-01** · B · RTE-02 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:170-175` — make the API routes return JSON instead of a missing Blade view.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Before** (`SyllabusBooksController.php:170-175`):
    ```php
    public function show($id)
    {
        Gate::authorize('tenant.syllabus-books.book.view');

        return view('syllabusbooks::show');
    }
    ```
  - **After:**
    ```php
    public function show(string $id): JsonResponse
    {
        Gate::authorize('tenant.syllabus-books.book.view');

        $book = BokBook::query()
            ->with(['authors:id,name', 'languageRelation:id,value'])
            ->withCount(['files', 'chapters', 'classSubjects'])
            ->findOrFail($id);

        return response()->json(['data' => $book]);
    }
    ```
  - And in `index()`, immediately before the `return view(...)` at line 155, add the API branch:
    ```php
        if ($request->is('api/*')) {
            return response()->json($books);
        }
    ```
  - Add `use Illuminate\Http\JsonResponse;` to the imports.
  - **Verify:** `php -l Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php && grep -n "is('api/\*')\|JsonResponse" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Expect:** `No syntax errors detected`, one `is('api/*')` branch and the `JsonResponse` import + return type.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None.

## 4. Authorization (F3)

None.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **SBS-02** · M · RTE-03 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:163-184` — disable the five unrouted methods per D5, never delete them. Do not touch `show()`: SBS-01 rewrites it.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Before** (`SyllabusBooksController.php:163-168`):
    ```php
    public function create()
    {
        return view('syllabusbooks::create');
    }

    public function store(Request $request) {}
    ```
  - **After:**
    ```php
    // NOT ROUTED — kept for reference; no route points at this action.
    public function create(): never
    {
        abort(403, 'This action is not routed.');
    }

    // NOT ROUTED — kept for reference; no route points at this action.
    public function store(Request $request): never
    {
        abort(403, 'This action is not routed.');
    }
    ```
  - **Before** (`SyllabusBooksController.php:177-184`):
    ```php
    public function edit($id)
    {
        return view('syllabusbooks::edit');
    }

    public function update(Request $request, $id) {}

    public function destroy($id) {}
    ```
  - **After:**
    ```php
    // NOT ROUTED — kept for reference; no route points at this action.
    public function edit(string $id): never
    {
        abort(403, 'This action is not routed.');
    }

    // NOT ROUTED — kept for reference; no route points at this action.
    public function update(Request $request, string $id): never
    {
        abort(403, 'This action is not routed.');
    }

    // NOT ROUTED — kept for reference; no route points at this action.
    public function destroy(string $id): never
    {
        abort(403, 'This action is not routed.');
    }
    ```
  - **Verify:** `grep -c "NOT ROUTED" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Expect:** `5`.
  - **Effort:** S

- [ ] **SBS-06** · L · CTL-04 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:24` — add the missing return type on `index`.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Before** (`SyllabusBooksController.php:24`):
    ```php
    public function index(Request $request)
    ```
  - **After:**
    ```php
    public function index(Request $request): View|JsonResponse
    ```
  - Add `use Illuminate\View\View;` to the imports. The other six methods get `never` in SBS-02 and `JsonResponse` in SBS-01.
  - **Verify:** `grep -n "public function index" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Expect:** `public function index(Request $request): View|JsonResponse`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **SBS-04** · M · QRY-15 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:153` — stop loading all 5,671 users into the dashboard.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Before** (`SyllabusBooksController.php:153`):
    ```php
        $users = User::where('is_active', 1)->orderBy('name')->get(['id', 'name']);
    ```
  - **After:**
    ```php
        $users = User::where('is_active', 1)->orderBy('name')->limit(500)->get(['id', 'name']);
    ```
  - **Note:** 500 is a stop-gap; the proper fix is a searchable user picker, which is a UI change outside this pass.
  - **Verify:** `grep -n "limit(500)" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Expect:** one hit on the users query.
  - **Effort:** S

- [ ] **SBS-05** · M · QRY-12 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:138-141` — reuse `$allNotes` instead of running the same query again.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Before** (`SyllabusBooksController.php:138-141`):
    ```php
        $notesForRating = SlbNote::query()
            ->where('is_active', 1)
            ->orderBy('title')
            ->get(['id', 'title']);
    ```
  - **After:**
    ```php
        $notesForRating = $allNotes;
    ```
  - **Verify:** `grep -c "SlbNote::query()" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Expect:** `2` (the notes tab query and the single `$allNotes` query).
  - **Effort:** S

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **SBS-07** · L · STY-02 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php:1` — add `strict_types` and make the file Pint-clean.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Before** (`SyllabusBooksController.php:1-3`):
    ```php
    <?php

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - Then run `vendor/bin/pint Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php --format agent` and accept its import order, spacing and unused-import changes.
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/SyllabusBooksController.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **SBS-03** · M · DECISION · CTL-07 — the dashboard passes 18 variables through one `compact()`. Split them into tab groups now, or accept?
  - **Why it is a decision:** grouping the variables rewrites the 52-line dashboard view and every `@include` that consumes them; that is a refactor, not a defect fix.
  - (a) ⭐ defer to the god-controller / view-model pass (D3) and record it as accepted for this pass.
  - (b) group them into one `$tabs` array now and update `syllabus-book/index.blade.php` in the same item.
  - (c) leave as is, record as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | every finding has a plan item |
