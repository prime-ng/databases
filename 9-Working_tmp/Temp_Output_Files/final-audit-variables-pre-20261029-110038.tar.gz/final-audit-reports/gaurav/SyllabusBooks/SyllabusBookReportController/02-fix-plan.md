# Fix Plan — SyllabusBooks / SyllabusBookReportController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SyllabusBooks/app/Models/BokBook.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/app/Models/SlbNote.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/app/Models/BookClassSubject.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/resources/views/reports/**` | the partials read the arrays the controller passes; no view change is needed |

## 1. Blockers reachable today

- [ ] **RPT-01** · B · ERR-01 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php:31-95` — remove the try/catch so the SQL error never reaches the screen (D1).
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php`
  - **Before** (`SyllabusBookReportController.php:31-32`):
    ```php
        try {
            $filters = [
    ```
  - **After:**
    ```php
        $filters = [
    ```
  - **Before** (`SyllabusBookReportController.php:88-96`):
    ```php
        } catch (\Throwable $e) {
            Log::error('SyllabusBookReportController@index failed', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->with('error', 'Unable to load Syllabus & Books Reports: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    }
    ```
  - Then remove `use Illuminate\Support\Facades\Log;` and run `vendor/bin/pint` on the file to re-indent the body.
  - **Verify:** `grep -c "catch (\|getMessage" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php`
  - **Expect:** `0`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **RPT-02** · H · MDL-09 · `Modules/SyllabusBooks/app/Services/SyllabusBookReportService.php:56-57` — compare the KPI against the status values that are actually stored.
  - **Touches:** `Modules/SyllabusBooks/app/Services/SyllabusBookReportService.php`
  - **Before** (`SyllabusBookReportService.php:56-57`):
    ```php
        $approvedNotes = (clone $notesQuery)->where('status', 'Approved')->count();
        $pendingNotes = (clone $notesQuery)->where('status', 'Pending')->count();
    ```
  - **After:**
    ```php
        $approvedNotes = (clone $notesQuery)->where('status', 'APPROVED')->count();
        $pendingNotes = (clone $notesQuery)->where('status', 'PENDING_APPROVAL')->count();
    ```
  - **Verify:** `grep -n "where('status'" Modules/SyllabusBooks/app/Services/SyllabusBookReportService.php`
  - **Expect:** the two KPI lines read `APPROVED` and `PENDING_APPROVAL`; the other report filters keep their existing values.
  - **Effort:** S

## 4. Authorization (F3)

None.

## 5. Validation, routes, models (F4/F5/F7)

None.

## 6. Queries & performance (F9)

None — RPT-03 is a DECISION in §9 (it changes how the five tab panes are rendered).

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **RPT-05** · L · CTL-04 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php:27` — add the return type on `index()`.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php`
  - **Before** (`SyllabusBookReportController.php:27`):
    ```php
    public function index(Request $request)
    ```
  - **After:**
    ```php
    public function index(Request $request): View
    ```
  - Add `use Illuminate\View\View;` to the imports.
  - **Verify:** `grep -n "public function index" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php`
  - **Expect:** `public function index(Request $request): View`.
  - **Effort:** S

- [ ] **RPT-06** · L · STY-02 · `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php:107` — replace `date()` with `now()` and run Pint.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php`
  - **Before** (`SyllabusBookReportController.php:107`):
    ```php
            $filename = 'syllabus_books_report_' . $tab . '_' . date('Y-m-d_His') . '.csv';
    ```
  - **After:**
    ```php
            $filename = 'syllabus_books_report_'.$tab.'_'.now()->format('Y-m-d_His').'.csv';
    ```
  - Then run `vendor/bin/pint Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php --format agent`.
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **RPT-04** · H · DECISION · SEC-02 — the CSV export of staff names and emails is gated on the general book view permission. How should it be protected?
  - **Why it is a decision:** a dedicated export permission is a new key in `config/permissionslist.php` plus a seeded role grant (`/system-config/sync-permissions`), and dropping a column changes the deliverable.
  - (a) ⭐ add `syllabus-books.book-report` with `export` to `config/permissionslist.php`, gate `exportCsv()` on `tenant.syllabus-books.book-report.export`, and remove the `Email` column from the teacher-contribution CSV.
  - (b) keep the current permission but remove the `Email` column only.
  - (c) leave as is and record the exposure as accepted by the school.
  - ➜ Choice: ____

- [ ] **RPT-03** · M · DECISION · QRY-12 — all five report datasets are computed on every page load. Compute only the active tab?
  - **Why it is a decision:** `reports/index.blade.php:21-25` includes all five partials unconditionally, so lazy computation also needs each `@include` wrapped in `@if ($activeTab === '…')` and a browser check that tab switching still loads the right pane.
  - (a) ⭐ compute only the active tab and wrap the five `@include` lines in `@if` guards; verify each tab link reloads with `?tab=` before shipping.
  - (b) keep all five computations (accept the cost) and record it as accepted.
  - (c) cache each report dataset per filter set for 60 seconds as a separate change.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | every finding has a plan item |
