# Final Audit — SyllabusBooks / SyllabusBookReportController

**Audited:** 2026-10-28 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php` (175 lines, 2 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /syllabus-books/reports` (five-tab report hub) · `GET /syllabus-books/reports/export-csv` |
| Menu path | Syllabus Books → Reports |
| Who uses it | Roles holding `tenant.syllabus-books.book.viewAny` (`config/permissionslist.php:1013`). There is no separate report or export permission. |
| What a user does here | Reviews five analytical tabs — prescribed books, coverage gap, study notes, teacher contribution, engagement ratings — filtered by session, class, subject, type and status; then downloads the active tab as a CSV. |
| Tables read | `slb_book_class_subject_jnt`, `slb_books`, `slb_book_authors`, `slb_book_chapters`, `slb_notes`, `slb_notes_ratings`, `slb_notes_downloads`, `sch_classes`, `sch_subjects`, `sys_users`, `org_academic_sessions` |
| Tables written | none |
| Live data | `slb_books` = 86, `slb_notes` = 15, `slb_notes_ratings` = 5, `slb_book_class_subject_jnt` = (present), `sys_users` = 5,671 on `test.localhost` (tinker SELECT, 2026-10-28) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. The KPI header reports **zero approved and zero pending notes** because the service compares against `Approved`/`Pending` while notes are stored as `APPROVED`/`PENDING_APPROVAL`. Every request also computes all five tabs (only one is shown), and the CSV export hands every teacher's name and email to anyone with the book view permission. The index catch sends SQL errors to the screen. Effort: one day (M).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 2 | 1 | 2 | 0 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | RPT-01 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | RPT-03 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | RPT-04 |
| F5 Routes | clean | F12 Style | RPT-05, RPT-06 |
| F6 Controller shape | clean | F13 Deep read | RPT-02 |
| F7 Models | RPT-02 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php` | controller | 175 | this report | ✅ |
| 2 | `Modules/SyllabusBooks/app/Services/SyllabusBookReportService.php` | service | 403 | ↗ [gaurav/SyllabusBooks/SyllabusBookReportController](01-report.md) | ✅ |
| 3 | `Modules/SyllabusBooks/resources/views/reports/index.blade.php` | blade | 116 | this report | ✅ |
| 4 | `Modules/SyllabusBooks/resources/views/reports/partials/_prescribed-books.blade.php` | blade partial | 303 | this report | ✅ |
| 5 | `Modules/SyllabusBooks/resources/views/reports/partials/_coverage-gap.blade.php` | blade partial | 309 | this report | ✅ |
| 6 | `Modules/SyllabusBooks/resources/views/reports/partials/_study-notes.blade.php` | blade partial | 305 | this report | ✅ |
| 7 | `Modules/SyllabusBooks/resources/views/reports/partials/_teacher-contribution.blade.php` | blade partial | 266 | this report | ✅ |
| 8 | `Modules/SyllabusBooks/resources/views/reports/partials/_engagement-ratings.blade.php` | blade partial | 330 | this report | ✅ |
| 9 | `Modules/SyllabusBooks/app/Models/BokBook.php` | model | 140 | ↗ tarun/StudentPortal-done/StudentPortalController — linked | ↗ linked |
| 10 | `Modules/SyllabusBooks/app/Models/BookClassSubject.php` | model | 64 | ↗ tarun/StudentPortal-done/MobilePrescribedBooksController — linked | ↗ linked |
| 11 | `Modules/SyllabusBooks/app/Models/SlbNote.php` | model | 205 | ↗ tarun/StudentPortal-done/MobileStudyResourcesController — linked | ↗ linked |

No pre-applied files.

## 4. Routes

```
GET|HEAD  syllabus-books/reports             syllabus-books.reports.index       Modules\SyllabusBooks\Http\Controllers\SyllabusBookReportController@index
GET|HEAD  syllabus-books/reports/export-csv  syllabus-books.reports.export-csv  Modules\SyllabusBooks\Http\Controllers\SyllabusBookReportController@exportCsv
```

Unrouted public methods: none.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 27 | GET reports | `tenant.syllabus-books.book.viewAny` | none (read) | none | — | RPT-01, RPT-03, RPT-05 |
| `exportCsv` | 101 | GET reports/export-csv | `tenant.syllabus-books.book.viewAny` | none (read) | none | — | RPT-04 |

## 6. Findings

### F1 — Errors

#### RPT-01 · B · ERR-01 — the report hub sends the SQL error to the screen and swallows the failure

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak*. Also ERR-00 under D1 (no try/catch in controllers) |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php:31-95`, method `index()` |
| **Root cause** | The whole method — including the five report queries and the `return view(...)` — sits inside `try { … } catch (\Throwable $e)`. The catch logs `getMessage()` plus a trace string and returns `back()->with('error', '…' . $e->getMessage())`. |
| **Consequence** | A failing report query shows `SQLSTATE[42S22]…` in the red flash; the redirect looks like a normal validation failure, so monitoring never sees the 500. A Blade error is also turned into a redirect, hiding the real bug. |
| **Reproduce** | Add a column to a filter that does not exist (or run against a tenant missing `slb_book_class_subject_jnt`) and open `/syllabus-books/reports` → red flash with the SQL. |
| **Fix approach** | Remove the try/catch; let the central handler render and log the failure (D1). |
| **Plan item** | RPT-01 in `02-fix-plan.md` §1 |

```php
        } catch (\Throwable $e) {
            Log::error('SyllabusBookReportController@index failed', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->with('error', 'Unable to load Syllabus & Books Reports: ' . $e->getMessage());
        }
```

**Evidence**
```
$ grep -n "getMessage\|Log::error\|catch (" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php
31:        try {
88:        } catch (\Throwable $e) {
89:            Log::error('SyllabusBookReportController@index failed', [
90:                'error' => $e->getMessage(),
91:                'trace' => $e->getTraceAsString(),
94:            return back()->with('error', 'Unable to load Syllabus & Books Reports: ' . $e->getMessage());
```

### F2 — Transactions and audit

clean — the controller is read-only (`grep -n "::create(\|->update(\|->delete(\|save()" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php` → no output).

### F3 — Authorization

clean — both actions authorize `tenant.syllabus-books.book.viewAny` before doing anything; RPT-04 is a scope problem, not a missing check.

### F4 — Validation and input

clean — the index casts every filter explicitly (`:32-44`); the export passes `$request->all()` but the service only reads the whitelisted keys (`SyllabusBookReportService.php:95-125` etc.) and none reaches raw SQL (`grep -n "DB::raw\|whereRaw\|orderByRaw" Modules/SyllabusBooks/app/Services/SyllabusBookReportService.php` → no output).

### F5 — Routes

clean — two routes, both resolve to existing methods and sit inside the tenant web group.

### F6 — Controller shape

clean — 175 lines, 2 public methods, constructor injection, the CSV writer is a closure inside `streamDownload`.

### F7 — Models

#### RPT-02 · H · MDL-09 — the KPI compares against status literals that are not stored

| Field | Value |
|---|---|
| **Rule** | MDL-09 (H, raised from L: the number shown is wrong on a real screen) — *status strings are enums/constants, not literals repeated across files* |
| **Where** | `Modules/SyllabusBooks/app/Services/SyllabusBookReportService.php:56-57` |
| **Root cause** | `where('status', 'Approved')` and `where('status', 'Pending')` compare against title-case values, while notes are stored as `DRAFT`, `PENDING_APPROVAL`, `APPROVED`, `REJECTED`, `ARCHIVED` (`NoteRequest.php:34` and the approval workflow in `NoteController`). |
| **Consequence** | The KPI header always shows 0 approved and 0 pending notes, whatever the school has; the coverage decision it feeds is wrong. |
| **Reproduce** | Open `/syllabus-books/reports` with 15 notes, some approved: the "Approved notes" card reads 0. |
| **Fix approach** | Use the stored values (or ideally `SlbNote` constants if declared). |
| **Plan item** | RPT-02 in `02-fix-plan.md` §3 |

```php
        $approvedNotes = (clone $notesQuery)->where('status', 'Approved')->count();
        $pendingNotes = (clone $notesQuery)->where('status', 'Pending')->count();
```

**Evidence**
```
$ sed -n '55,58p' Modules/SyllabusBooks/app/Services/SyllabusBookReportService.php
        $totalNotes = (clone $notesQuery)->count();
        $approvedNotes = (clone $notesQuery)->where('status', 'Approved')->count();
        $pendingNotes = (clone $notesQuery)->where('status', 'Pending')->count();
        $totalDownloads = (clone $notesQuery)->sum('download_count');
$ grep -n "'status'" Modules/SyllabusBooks/app/Http/Requests/NoteRequest.php
34:            'status'               => 'nullable|in:DRAFT,PENDING_APPROVAL,APPROVED,REJECTED,ARCHIVED',
```

### F8 — Services and jobs

clean apart from RPT-02 — the service is constructor-injected, does no HTTP work and performs no writes on this read path.

### F9 — Queries and performance

#### RPT-03 · M · QRY-12 — all five tab datasets are computed on every request

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) — *repeated queries in one request are resolved once; work for tabs that are not shown is not run* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php:64-72` |
| **Root cause** | The controller computes the KPI and all five reports (`getPrescribedBooksReport`, `getCoverageGapReport`, `getStudyNotesReport`, `getTeacherContributionReport`, `getEngagementRatingsReport`) regardless of `$activeTab`; only one partial is rendered. |
| **Consequence** | Every report page load runs four unused report queries, each with its own eager loads and aggregates, on tables that grow with the school. |
| **Reproduce** | Open `/syllabus-books/reports?tab=prescribed-books` and watch the query log: the coverage, notes, teacher and engagement queries all run. |
| **Fix approach** | Compute only the active tab (plus the KPI) and guard the five `@include` lines in the hub view. |
| **Plan item** | RPT-03 in `02-fix-plan.md` §9 (DECISION) |

```php
            $prescribedReport = $this->reportService->getPrescribedBooksReport($filters);
            $coverageReport = $this->reportService->getCoverageGapReport($filters);
            $studyNotesReport = $this->reportService->getStudyNotesReport($filters);
            $teacherReport = $this->reportService->getTeacherContributionReport($filters);
            $engagementReport = $this->reportService->getEngagementRatingsReport($filters);
```

**Evidence**
```
$ sed -n '64,72p' Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php
            // Executive KPI summary
            $kpi = $this->reportService->getExecutiveKpiSummary($filters);

            // Tab specific datasets
            $prescribedReport = $this->reportService->getPrescribedBooksReport($filters);
            $coverageReport = $this->reportService->getCoverageGapReport($filters);
            $studyNotesReport = $this->reportService->getStudyNotesReport($filters);
            $teacherReport = $this->reportService->getTeacherContributionReport($filters);
            $engagementReport = $this->reportService->getEngagementRatingsReport($filters);
```

### F10 — Views

clean — the five partials loop over arrays from the service; `grep -nE "::where|DB::|->get\(\)" Modules/SyllabusBooks/resources/views/reports/partials/*.blade.php` → no output. `{!! !!}` is absent (`grep -c '{!!'` → 0 in every partial).

### F11 — Security and tenancy

#### RPT-04 · H · SEC-02 — the CSV export hands out staff names and emails

| Field | Value |
|---|---|
| **Rule** | SEC-02 (H) — *no personal data over-exposed: JSON/CSV endpoints return mapped fields, not whole people* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php:101-107` and `:129-146` |
| **Root cause** | The export is gated on `tenant.syllabus-books.book.viewAny` — the same permission as opening the hub — and the teacher-contribution CSV writes every teacher's name, **email**, role and activity totals. There is no `report.export` permission and no field mapping beyond the header list. |
| **Consequence** | Any staff member who can open the report hub downloads the full staff directory with emails in one click; the CSV leaves the system and cannot be revoked. |
| **Reproduce** | As a role with only `book.viewAny`, open `/syllabus-books/reports/export-csv?tab=teacher-contribution` → the CSV contains the Email column for every teacher. |
| **Fix approach** | Gate the export on a dedicated permission (new key — a DECISION) and drop the email column unless it is required. |
| **Plan item** | RPT-04 in `02-fix-plan.md` §9 (DECISION — new permission key) |

```php
    public function exportCsv(Request $request): StreamedResponse
    {
        Gate::authorize('tenant.syllabus-books.book.viewAny');

        $tab = $request->input('tab', 'prescribed-books');
        $filters = $request->all();
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php
29:        Gate::authorize('tenant.syllabus-books.book.viewAny');
103:        Gate::authorize('tenant.syllabus-books.book.viewAny');
$ grep -n "Teacher Name\|Email" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php
131:                fputcsv($handle, ['Teacher Name', 'Email', 'Role', 'Total Notes', 'Approved Notes', 'Pending Notes', 'Rejected Notes', 'Approval Rate (%)', 'Total Views', 'Total Downloads', 'Avg Rating']);
```

### F12 — Style

#### RPT-05 · L · CTL-04 — `index()` has no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php:27` |
| **Root cause** | `index(Request $request)` declares no return type while `exportCsv()` declares `: StreamedResponse`. |
| **Consequence** | Style only. |
| **Reproduce** | `grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php` |
| **Fix approach** | Add `: View`. |
| **Plan item** | RPT-05 in `02-fix-plan.md` §8 |

```php
    public function index(Request $request)
    {
        Gate::authorize('tenant.syllabus-books.book.viewAny');
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php
27:    public function index(Request $request)
```

#### RPT-06 · L · STY-02 — the controller is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php:107` and the constructor/headers |
| **Root cause** | Pint reports `no_alias_functions` (`date()` should be `now()`), `concat_space`, `braces_position`, `not_operator_with_successor_space`, `single_line_empty_body` and `binary_operator_spaces`. |
| **Consequence** | Style only. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php` |
| **Fix approach** | Run Pint; replace `date('Y-m-d_His')` with `now()->format('Y-m-d_His')`. |
| **Plan item** | RPT-06 in `02-fix-plan.md` §8 |

```php
        $filename = 'syllabus_books_report_' . $tab . '_' . date('Y-m-d_His') . '.csv';
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Http\/Controllers\/SyllabusBookReportController.php","fixers":["no_alias_functions","concat_space","braces_position","not_operator_with_successor_space","single_line_empty_body","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

No mutating method — both actions are reads (`grep -n "::create(\|->update(\|->delete(" Modules/SyllabusBooks/app/Http/Controllers/SyllabusBookReportController.php` → no output). The report's correctness defect is RPT-02.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| — | none found | — | — |

## 8. Not covered, and why

- Reports were not run against a browser; RPT-02 is proven from the stored enum values and the service literal.
- Query counts were deduced from the controller's unconditional calls; no query log was captured.
- The five partials were read for queries and escaping, not rendered.
