# Fix Plan — SyllabusBooks / NoteRatingController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SyllabusBooks/app/Models/SlbNote.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/resources/views/note-ratings/index.blade.php` | no change needed |

## 1. Blockers reachable today

None at B severity.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **NRT-02** · H · TXN-01 · `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:29-39` — wrap each rating write, the average recalculation and the log in one transaction.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php`
  - **Before** (`NoteRatingController.php:29-39`):
    ```php
        $rating = SlbNotesRating::updateOrCreate(
            [
                'notes_id' => $request->notes_id,
                'user_id'  => $request->user_id,
            ],
            $request->validated()
        );

        $this->recalculateAvgRating($rating->notes_id);

        activityLog($rating, $rating->wasRecentlyCreated ? 'Created' : 'Updated', ['message' => 'Note rating saved.']);
    ```
  - **After:**
    ```php
        $rating = DB::transaction(function () use ($request) {
            $rating = SlbNotesRating::updateOrCreate(
                [
                    'notes_id' => $request->notes_id,
                    'user_id'  => $request->user_id,
                ],
                $request->validated()
            );

            $this->recalculateAvgRating($rating->notes_id);

            activityLog($rating, $rating->wasRecentlyCreated ? 'Created' : 'Updated', ['message' => 'Note rating saved.']);

            return $rating;
        });
    ```
  - Add `use Illuminate\Support\Facades\DB;` to the imports.
  - In `update()`, wrap lines 74-81 the same way:
    ```php
        DB::transaction(function () use ($rating, $request, $oldNoteId) {
            $rating->update($request->validated());

            $this->recalculateAvgRating($oldNoteId);
            if ($oldNoteId !== (int) $request->notes_id) {
                $this->recalculateAvgRating((int) $request->notes_id);
            }

            activityLog($rating, 'Updated', ['message' => 'Note rating updated.']);
        });
    ```
  - In `destroy()`, wrap the delete and recalculation with NRT-03.
  - **Verify:** `grep -c "DB::transaction" Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php`
  - **Expect:** `3`.
  - **Effort:** M

- [ ] **NRT-03** · M · TXN-04 · `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:105-109` — log the delete after it succeeds.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php`
  - **Before** (`NoteRatingController.php:105-109`):
    ```php
        activityLog($rating, 'Deleted', ['message' => 'Note rating removed by admin.']);

        $rating->delete();

        $this->recalculateAvgRating($noteId);
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($rating, $noteId) {
            $rating->delete();

            $this->recalculateAvgRating($noteId);

            activityLog($rating, 'Deleted', ['message' => 'Note rating removed by admin.']);
        });
    ```
  - **Verify:** `sed -n '103,114p' Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php`
  - **Expect:** `$rating->delete();` before the `activityLog(... 'Deleted' ...)` call, both inside `DB::transaction`.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **NRT-01** · H · AUTH-03 · `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:29-35` — stop taking the ratee's user id from the form.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php`, `Modules/SyllabusBooks/app/Http/Requests/NoteRatingRequest.php`
  - **Before** (`NoteRatingController.php:29-35`):
    ```php
        $rating = SlbNotesRating::updateOrCreate(
            [
                'notes_id' => $request->notes_id,
                'user_id'  => $request->user_id,
            ],
            $request->validated()
        );
    ```
  - **After:**
    ```php
        $rating = SlbNotesRating::updateOrCreate(
            [
                'notes_id' => $request->notes_id,
                'user_id'  => auth()->id(),
            ],
            $request->safe()->only(['notes_id', 'rating', 'review'])
        );
    ```
  - Also change the duplicate check in `update()` to use the same identity:
    ```php
            ->where('user_id', auth()->id())
    ```
    and replace `$rating->update($request->validated());` with `$rating->update($request->safe()->only(['notes_id', 'rating', 'review']));`.
  - Remove `'user_id'` from `NoteRatingRequest::rules()` so a posted id is ignored rather than validated.
  - **Verify:** `grep -n "user_id" Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php Modules/SyllabusBooks/app/Http/Requests/NoteRatingRequest.php`
  - **Expect:** no `$request->user_id` and no `user_id` rule; the only `user_id` usages read `auth()->id()`.
  - **Effort:** M

- [ ] **NRT-05** · L · AUTH-04 · `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:27` and `:58` — drop the duplicate permission checks.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php`
  - **Before** (`NoteRatingController.php:25-29`):
    ```php
    public function store(NoteRatingRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-rating.create');

        $rating = SlbNotesRating::updateOrCreate(
    ```
  - **After:**
    ```php
    public function store(NoteRatingRequest $request): RedirectResponse
    {
        $rating = SlbNotesRating::updateOrCreate(
    ```
  - Then delete the line `Gate::authorize('tenant.syllabus-books.note-rating.update');` at line 58 in `update()`.
  - **Verify:** `grep -c "Gate::authorize" Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php`
  - **Expect:** `2` (the `index` and `destroy` gates).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **NRT-04** · M · CTL-03 · `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:56-60` and `:98-102` — bind the rating model on update and delete.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php`, `Modules/SyllabusBooks/routes/web.php`
  - **Before** (`NoteRatingController.php:56-60`):
    ```php
    public function update(NoteRatingRequest $request, $id): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-rating.update');

        $rating = SlbNotesRating::findOrFail($id);
    ```
  - **After:**
    ```php
    public function update(NoteRatingRequest $request, SlbNotesRating $noteRating): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-rating.update');

        $rating = $noteRating;
    ```
  - In `destroy()`, change `public function destroy($id)` and `$rating = SlbNotesRating::findOrFail($id);` to `public function destroy(SlbNotesRating $noteRating)` and `$rating = $noteRating;`.
  - In `routes/web.php` change only the two rating URLs:
    ```php
    Route::put('note-ratings/{note_rating}', [NoteRatingController::class, 'update'])->name('note-ratings.update');
    ```
    ```php
    Route::delete('note-ratings/{note_rating}', [NoteRatingController::class, 'destroy'])->name('note-ratings.destroy');
    ```
  - **Verify:** `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '$r=json_decode(stream_get_contents(STDIN),true); foreach($r as $x) if(str_contains($x["uri"],"note-ratings")) echo $x["method"]." ".$x["uri"]."\n";'`
  - **Expect:** the update and delete URIs show `{note_rating}`.
  - **Effort:** M

## 6. Queries & performance (F9)

None.

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **NRT-06** · L · STY-02 · `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:10` — remove the unused import, add `strict_types`, run Pint.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php`
  - **Before** (`NoteRatingController.php:1-13`):
    ```php
    <?php

    namespace Modules\SyllabusBooks\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\SyllabusBooks\Http\Requests\NoteRatingRequest;
    use Modules\SchoolSetup\Models\User;
    use Modules\SyllabusBooks\Models\SlbNote;
    use Modules\SyllabusBooks\Models\SlbNotesRating;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\SyllabusBooks\Http\Requests\NoteRatingRequest;
    use Modules\SyllabusBooks\Models\SlbNote;
    use Modules\SyllabusBooks\Models\SlbNotesRating;
    ```
  - Then run `vendor/bin/pint Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php --format agent`.
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** S

## 9. Deferred / decisions

None.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | every finding has a plan item |
