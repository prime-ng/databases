# Final Audit — SyllabusBooks / NoteRatingController

**Audited:** 2026-10-28 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php` (133 lines, 4 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /syllabus-books/note-ratings` (redirect) · `POST /syllabus-books/note-ratings` · `PUT /syllabus-books/note-ratings/{id}` · `DELETE /syllabus-books/note-ratings/{id}` |
| Menu path | Syllabus Books → Note Ratings tab; the same form also appears on a note's edit page |
| Who uses it | Roles holding `tenant.syllabus-books.note-rating.viewAny/create/update/delete` (`config/permissionslist.php:1017`). |
| What a user does here | Record a 1–5 star rating and a short review for a note on behalf of a selected user, correct it, or remove it. Each save recomputes the note's average rating. |
| Tables written | `slb_notes_ratings`, `slb_notes` (`avg_rating`), activity log |
| Tables read | `slb_notes_ratings`, `slb_notes`, `sys_users` |
| Live data | `slb_notes_ratings` = 5 rows, `slb_notes` = 15 rows on `test.localhost` (tinker SELECT, 2026-10-28); `slb_notes_ratings` has the unique index `uq_rating_user_notes(notes_id, user_id)` |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Usable but not trustworthy: the "ratee" is taken from the form, so any permitted user can file or edit a rating under another user's name. Rating writes, the note average update and the audit entry also run as three separate statements with no transaction. Effort: half a day (S).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 2 | 2 | 0 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | NRT-02, NRT-03 | F9 Queries/Perf | clean |
| F3 Authorization | NRT-01, NRT-05 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | NRT-06 |
| F6 Controller shape | NRT-04 | F13 Deep read | NRT-01, NRT-02 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php` | controller | 133 | this report | ✅ |
| 2 | `Modules/SyllabusBooks/app/Http/Requests/NoteRatingRequest.php` | FormRequest | 43 | this report | ✅ |
| 3 | `Modules/SyllabusBooks/app/Models/SlbNotesRating.php` | model | 63 | ↗ tarun/StudentPortal-done/MobileStudyResourcesController — linked | ↗ linked |
| 4 | `Modules/SyllabusBooks/app/Models/SlbNote.php` | model | 205 | ↗ tarun/StudentPortal-done/MobileStudyResourcesController — linked | ↗ linked |
| 5 | `Modules/SyllabusBooks/app/Policies/NoteRatingPolicy.php` | policy | 44 | ↗ [gaurav/SyllabusBooks/NoteRatingController](01-report.md) | ✅ |
| 6 | `Modules/SyllabusBooks/resources/views/note-ratings/index.blade.php` | blade | 251 | this report | ✅ |

No pre-applied files.

## 4. Routes

```
POST      syllabus-books/note-ratings        syllabus-books.note-ratings.store    Modules\SyllabusBooks\Http\Controllers\NoteRatingController@store
PUT       syllabus-books/note-ratings/{id}   syllabus-books.note-ratings.update   Modules\SyllabusBooks\Http\Controllers\NoteRatingController@update
GET|HEAD  syllabus-books/note-ratings        syllabus-books.note-ratings.index    Modules\SyllabusBooks\Http\Controllers\NoteRatingController@index
DELETE    syllabus-books/note-ratings/{id}   syllabus-books.note-ratings.destroy  Modules\SyllabusBooks\Http\Controllers\NoteRatingController@destroy
```

Unrouted public methods: none.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 16 | GET note-ratings | `tenant.syllabus-books.note-rating.viewAny` | none (read) | none | — | — |
| `store` | 25 | POST note-ratings | `tenant.syllabus-books.note-rating.create` | none | 'Created'/'Updated' | `slb_notes_ratings`, `slb_notes` | NRT-01, NRT-02, NRT-05 |
| `update` | 56 | PUT note-ratings/{id} | `tenant.syllabus-books.note-rating.update` | none | 'Updated' | `slb_notes_ratings`, `slb_notes` | NRT-01, NRT-02, NRT-04, NRT-05 |
| `destroy` | 98 | DELETE note-ratings/{id} | `tenant.syllabus-books.note-rating.delete` | none | 'Deleted' (before the delete) | `slb_notes_ratings`, `slb_notes` | NRT-02, NRT-03, NRT-04 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try \{|catch \(|getMessage' Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php` → no output.

### F2 — Transactions and audit

#### NRT-02 · H · TXN-01 — rating, note average and log are three unguarded writes

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (a model + its audit row, a model + a parent counter) runs inside one `DB::transaction`* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:29-39` (`store`), `:73-81` (`update`), `:103-109` (`destroy`) |
| **Root cause** | Each method writes `slb_notes_ratings`, then calls `recalculateAvgRating()` which updates `slb_notes.avg_rating`, then writes the activity log — with no transaction anywhere (`grep DB::transaction` → no output). |
| **Consequence** | If the recalculation or the log fails, the rating exists but the note still shows the old average, and the screen disagrees with the data until the next rating is saved. |
| **Reproduce** | static only — three writes in each method, none inside `DB::transaction`. |
| **Fix approach** | Wrap each mutating method's writes (including the recalculation) in one transaction, with the log at the end. |
| **Plan item** | NRT-02 in `02-fix-plan.md` §3 |

```php
        $rating = SlbNotesRating::updateOrCreate(
            [
                'notes_id' => $request->notes_id,
                'user_id'  => $request->user_id,
            ],
            $request->validated()
        );

        $this->recalculateAvgRating($rating->notes_id);

        activityLog($rating, $rating->wasRecentlyCreated ? 'Created' : 'Updated', ['message' => 'Note rating saved.']);
```

**Evidence**
```
$ grep -n "DB::transaction" Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php
(no output)
$ grep -n "recalculateAvgRating\|SlbNote::where" Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php
37:        $this->recalculateAvgRating($rating->notes_id);
76:        $this->recalculateAvgRating($oldNoteId);
78:            $this->recalculateAvgRating((int) $request->notes_id);
109:        $this->recalculateAvgRating($noteId);
129:        SlbNote::where('id', $noteId)->update([
```

#### NRT-03 · M · TXN-04 — the delete is logged before it happens

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits after the write it describes* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:105-109`, method `destroy()` |
| **Root cause** | `activityLog()` runs before `$rating->delete()`; if the delete fails, the log claims a deletion that did not happen. |
| **Consequence** | The audit trail can contain a "Deleted" entry for a rating that still exists. |
| **Reproduce** | static only — the log call precedes the delete call. |
| **Fix approach** | Move the log after the delete, inside the new transaction. |
| **Plan item** | NRT-03 in `02-fix-plan.md` §3 |

```php
        activityLog($rating, 'Deleted', ['message' => 'Note rating removed by admin.']);

        $rating->delete();
```

**Evidence**
```
$ sed -n '103,110p' Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php
        $noteId = $rating->notes_id;

        activityLog($rating, 'Deleted', ['message' => 'Note rating removed by admin.']);

        $rating->delete();

        $this->recalculateAvgRating($noteId);
```

### F3 — Authorization

#### NRT-01 · H · AUTH-03 — a rating can be filed in another user's name

| Field | Value |
|---|---|
| **Rule** | AUTH-03 (H) — *record-level checks where data belongs to a person* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:29-35` and `:74`, plus `Modules/SyllabusBooks/app/Http/Requests/NoteRatingRequest.php:24` |
| **Root cause** | `user_id` is a required form field (`exists:sys_users,id`) and the controller writes it straight into the rating. Nothing compares it with `auth()->id()` or restricts it to the current user; `update()` can also move an existing rating to a different user. |
| **Consequence** | Any user allowed to create a rating can rate a note as a colleague or a student; the note's average and the visible reviewer name are then wrong, and the named user cannot remove it. |
| **Reproduce** | Open the Note Ratings tab, submit a rating with `user_id` set to another user's id → the row is saved under that user. |
| **Fix approach** | Ignore the posted `user_id` and always use `auth()->id()` (the admin screen is "rate on behalf" only if a `user_id` is deliberately allowed — a DECISION, not this fix). |
| **Plan item** | NRT-01 in `02-fix-plan.md` §4 |

```php
        $rating = SlbNotesRating::updateOrCreate(
            [
                'notes_id' => $request->notes_id,
                'user_id'  => $request->user_id,
            ],
            $request->validated()
        );
```

**Evidence**
```
$ grep -n "user_id" Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php Modules/SyllabusBooks/app/Http/Requests/NoteRatingRequest.php
Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:32:                'user_id'  => $request->user_id,
Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:63:            ->where('user_id', $request->user_id)
Modules/SyllabusBooks/app/Http/Requests/NoteRatingRequest.php:24:            'user_id'  => 'required|integer|exists:sys_users,id',
$ grep -n "auth()->id()\|Auth::id()" Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php
(no output)
```

#### NRT-05 · L · AUTH-04 — the same permission is checked twice on store and update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (FormRequest + Gate); keep one* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:27` and `:58`, plus `NoteRatingRequest.php:17` |
| **Root cause** | `NoteRatingRequest::authorize()` maps POST to `.create` and PUT to `.update`; the controller repeats the same `Gate::authorize` in both methods. |
| **Consequence** | Two copies of the rule drift apart; a change to one silently changes the effective permission. |
| **Reproduce** | static only — the same permission string appears in both files for each verb. |
| **Fix approach** | Keep the FormRequest check and drop the controller duplicate on `store` and `update`. |
| **Plan item** | NRT-05 in `02-fix-plan.md` §4 |

```php
    public function store(NoteRatingRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-rating.create');
```

**Evidence**
```
$ grep -n "Gate::authorize\|authorizeByCrudPermission" Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php Modules/SyllabusBooks/app/Http/Requests/NoteRatingRequest.php
Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:18:        Gate::authorize('tenant.syllabus-books.note-rating.viewAny');
Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:27:        Gate::authorize('tenant.syllabus-books.note-rating.create');
Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:58:        Gate::authorize('tenant.syllabus-books.note-rating.update');
Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:100:        Gate::authorize('tenant.syllabus-books.note-rating.delete');
Modules/SyllabusBooks/app/Http/Requests/NoteRatingRequest.php:17:        return $this->authorizeByCrudPermission('tenant.syllabus-books.note-rating');
```

### F4 — Validation and input

clean — `NoteRatingRequest.php:22-27` types every field and bounds the rating 1–5; the unique index `uq_rating_user_notes(notes_id, user_id)` backs `updateOrCreate`, so a duplicate cannot be stored (verified by `SHOW INDEX FROM slb_notes_ratings`).

### F5 — Routes

clean — four routes, all resolve to existing methods; `{id}` is intentional (NRT-04) but the routes sit inside the tenant web group.

### F6 — Controller shape

#### NRT-04 · M · CTL-03 — update and delete take a raw id

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:56-60` and `:98-102` |
| **Root cause** | Both routes use `{id}` and the controller calls `findOrFail($id)`; the rest of the module binds models. |
| **Consequence** | No model-level policy and no consistent 404 shape; the two methods repeat the lookup. |
| **Reproduce** | static only — `PUT /syllabus-books/note-ratings/999999` reaches `findOrFail`, not a binding. |
| **Fix approach** | Rename the route parameter to `{note_rating}` and bind `SlbNotesRating`; the route file change is shared, so it is part of the same item. |
| **Plan item** | NRT-04 in `02-fix-plan.md` §5 |

```php
    public function update(NoteRatingRequest $request, $id): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.note-rating.update');

        $rating = SlbNotesRating::findOrFail($id);
```

**Evidence**
```
$ grep -n "note-ratings/{id}" Modules/SyllabusBooks/routes/web.php
104:Route::put('note-ratings/{id}', [NoteRatingController::class, 'update'])->name('note-ratings.update');
106:Route::delete('note-ratings/{id}', [NoteRatingController::class, 'destroy'])->name('note-ratings.destroy');
$ grep -n "findOrFail" Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php
60:        $rating = SlbNotesRating::findOrFail($id);
102:        $rating = SlbNotesRating::findOrFail($id);
```

### F7 — Models

clean — `SlbNotesRating` declares `$fillable` and casts `rating`; the table exists and the unique index is present. `SlbNote::avg_rating` update is the intended counter.

### F8 — Services and jobs

clean — no service or job; `recalculateAvgRating()` is a private helper that aggregates in SQL (`avg('rating')`, `:128`), not in PHP.

### F9 — Queries and performance

clean — the recalculation is one aggregate query plus one update per affected note; `store` resolves `updateOrCreate` once. No query inside a loop (`grep -n "foreach" …` → no output).

### F10 — Views

clean — `note-ratings/index.blade.php` renders the paginator and rows passed in; `grep -nE "::where|DB::|->get\(\)" Modules/SyllabusBooks/resources/views/note-ratings/index.blade.php` → no output; no `{!! !!}` (`grep -c '{!!'` → 0).

### F11 — Security and tenancy

clean — no `env()`, no hard-coded user/tenant id (`grep -nE "env\(|\?\? [0-9]" Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php` → no output); NRT-01 is the authorization defect.

### F12 — Style

#### NRT-06 · L · STY-02 — unused import, not Pint-clean, no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)*; STY-01 — `declare(strict_types=1)`; STY-05 — one import per class |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php:10` |
| **Root cause** | `use Modules\SchoolSetup\Models\User;` is never referenced; Pint reports `no_unused_imports` and `binary_operator_spaces`; no `declare(strict_types=1)`. |
| **Consequence** | Style and a stale import that suggests the class is used. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php` |
| **Fix approach** | Remove the import, add strict types, run Pint. |
| **Plan item** | NRT-06 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SyllabusBooks\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Modules\SyllabusBooks\Http\Requests\NoteRatingRequest;
use Modules\SchoolSetup\Models\User;
use Modules\SyllabusBooks\Models\SlbNote;
use Modules\SyllabusBooks\Models\SlbNotesRating;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Http\/Controllers\/NoteRatingController.php","fixers":["no_unused_imports","binary_operator_spaces"]}]}
$ grep -c "declare(strict_types=1)" Modules/SyllabusBooks/app/Http/Controllers/NoteRatingController.php
0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok (unique index; no soft deletes on ratings) | ok (unique index rejects the race) | NRT-01 | ok | ok |
| `update` | ok (both averages recalculated when the note changes) | ok | ok | ok | ok | NRT-01 | ok | ok |
| `destroy` | ok | NRT-03 | ok | ok | ok | ok | NRT-03 | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SyllabusBooks/app/Policies/NoteRatingPolicy.php` | registered but never consulted by this controller (permission strings only); the policy's methods are redundant until the controller passes abilities | AUTH-05 | module owner, optional |

## 8. Not covered, and why

- The Note Ratings tab was read, not rendered; the blade claim is from its source.
- No role/permission SELECT was run, so the live role set is not listed.
