# Final Audit — SyllabusBooks / BookChapterController

**Audited:** 2026-10-28 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php` (44 lines, 3 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /syllabus-books/books/{book}/chapters` (JSON list) · `POST /syllabus-books/books/{book}/chapters/bulk` · `DELETE /syllabus-books/books/{book}/chapters/{chapter}` |
| Menu path | Syllabus Books → Books → open a book → Chapters tab |
| Who uses it | Roles holding `tenant.syllabus-books.book-chapter.viewAny` / `.create` / `.delete` (`config/permissionslist.php:1021`). |
| What a user does here | The Chapters tab lists a book's chapters and saves the whole chapter list in one request (add, edit and remove rows). A chapter row can also be deleted directly. |
| Tables written | `slb_book_chapters` |
| Tables read | `slb_book_chapters`, `slb_books` |
| Live data | `slb_book_chapters` = 324 rows, `slb_books` = 86 rows on `test.localhost` (tinker SELECT, 2026-10-28) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Usable but not safe as written: the delete route trusts the chapter id without checking that the chapter belongs to the book in the URL, so a crafted URL deletes another book's chapter. Chapter writes also leave no audit trail, and the JSON list returns full rows. Effort: one session (S).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 3 | 1 | 0 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | BCC-03 | F9 Queries/Perf | BCC-04 |
| F3 Authorization | BCC-01, BCC-02 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | BCC-05 |
| F6 Controller shape | clean | F13 Deep read | BCC-01 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php` | controller | 44 | this report | ✅ |
| 2 | `Modules/SyllabusBooks/app/Http/Requests/BookChapterBulkRequest.php` | FormRequest | 38 | this report | ✅ |
| 3 | `Modules/SyllabusBooks/app/Services/BookChapterService.php` | service | 57 | ↗ [gaurav/SyllabusBooks/BookChapterController](01-report.md) | ✅ |
| 4 | `Modules/SyllabusBooks/app/Policies/BookChapterPolicy.php` | policy | 34 | ↗ [gaurav/SyllabusBooks/BookChapterController](01-report.md) | ✅ |
| 5 | `Modules/SyllabusBooks/app/Models/BookChapter.php` | model | 43 | ↗ tarun/StudentPortal-done/MobileStudyResourcesController — linked | ↗ linked |
| 6 | `Modules/SyllabusBooks/app/Models/BokBook.php` | model | 140 | ↗ tarun/StudentPortal-done/StudentPortalController — linked | ↗ linked |
| 7 | `Modules/SyllabusBooks/resources/views/book/_chapters_tab.blade.php` | blade partial | 81 | this report | ✅ |

No pre-applied files.

## 4. Routes

```
GET|HEAD  syllabus-books/books/{book}/chapters           syllabus-books.books.chapters.index    Modules\SyllabusBooks\Http\Controllers\BookChapterController@index
POST      syllabus-books/books/{book}/chapters/bulk      syllabus-books.books.chapters.bulk     Modules\SyllabusBooks\Http\Controllers\BookChapterController@bulkUpsert
DELETE    syllabus-books/books/{book}/chapters/{chapter} syllabus-books.books.chapters.destroy  Modules\SyllabusBooks\Http\Controllers\BookChapterController@destroy
```

Unrouted public methods: none.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 20 | GET books/{book}/chapters | `tenant.syllabus-books.book-chapter.viewAny` | none (read) | none | — | BCC-04 |
| `bulkUpsert` | 27 | POST books/{book}/chapters/bulk | `tenant.syllabus-books.book-chapter.create` | service `BookChapterService::bulkUpsert` | none | `slb_book_chapters` | BCC-02, BCC-03 |
| `destroy` | 36 | DELETE books/{book}/chapters/{chapter} | `tenant.syllabus-books.book-chapter.delete` | none | none | `slb_book_chapters` | BCC-01, BCC-03 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try \{|catch \(|getMessage' Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php Modules/SyllabusBooks/app/Services/BookChapterService.php` → no output.

### F2 — Transactions and audit

#### BCC-03 · M · TXN-04 — chapter writes leave no activity-log entry

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/SyllabusBooks/app/Services/BookChapterService.php:25-50` and `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php:36-42`, methods `bulkUpsert()` / `destroy()` |
| **Root cause** | The bulk save and the single delete write `slb_book_chapters` without calling `activityLog()` at all; every other audited mutation in this module logs. |
| **Consequence** | Nobody can tell who rewrote or deleted a book's chapter list; an accidental bulk save is unrecoverable and unattributable. |
| **Reproduce** | static only — save the Chapters tab, then look for a row in the activity log for the book: none is written. |
| **Fix approach** | Log the book inside the bulk transaction and log the chapter after the delete. |
| **Plan item** | BCC-03 in `02-fix-plan.md` §3 |

```php
            $book->chapters()->whereNotIn('id', $keepIds)->delete();

            return $book->chapters()->get();
```

**Evidence**
```
$ grep -n "activityLog" Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php Modules/SyllabusBooks/app/Services/BookChapterService.php
(no output)
$ grep -n "DB::transaction" Modules/SyllabusBooks/app/Services/BookChapterService.php
25:        return DB::transaction(function () use ($book, $chapters) {
```

### F3 — Authorization

#### BCC-01 · H · AUTH-03 — a chapter can be deleted through another book's URL

| Field | Value |
|---|---|
| **Rule** | AUTH-03 (H) — *record-level checks where data belongs to a parent record* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php:36-42`, method `destroy()` |
| **Root cause** | `{book}` and `{chapter}` are bound independently. The policy checks only the `book-chapter.delete` permission on the chapter, never that `$chapter->book_id === $book->id`. |
| **Consequence** | A user allowed to delete chapters can remove a chapter from any book by editing the chapter id in the URL; the success message names the wrong book. |
| **Reproduce** | Open `/syllabus-books/books/1/chapters/324` where chapter 324 belongs to another book → the chapter is deleted. |
| **Fix approach** | Abort 404 when the chapter does not belong to the bound book. |
| **Plan item** | BCC-01 in `02-fix-plan.md` §4 |

```php
    public function destroy(BokBook $book, BookChapter $chapter): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.book-chapter.delete', $chapter);

        $this->service->delete($chapter);
```

**Evidence**
```
$ grep -n "public function destroy\|book_id\|Gate::authorize" Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php
36:    public function destroy(BokBook $book, BookChapter $chapter): RedirectResponse
38:        Gate::authorize('tenant.syllabus-books.book-chapter.delete', $chapter);
$ grep -n "book_id" Modules/SyllabusBooks/app/Services/BookChapterService.php
31:                    : new BookChapter(['book_id' => $book->id]);
41:                $chapter->book_id = $book->id;
```

#### BCC-02 · M · AUTH-05 — the update permission is never checked when existing chapters are rewritten

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — *no dead permission logic; a user with only `.update` can never save chapters* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php:27-31`, method `bulkUpsert()` |
| **Root cause** | The bulk endpoint upserts new and existing rows but authorizes only `...book-chapter.create`; `...book-chapter.update` (seeded at `config/permissionslist.php:1021` and declared in the policy) is never consulted. |
| **Consequence** | A role that may edit but not create chapters cannot use the Chapters tab, while a create-only role can overwrite existing chapters. |
| **Reproduce** | Role with only `.update`: saving the Chapters tab returns 403. |
| **Fix approach** | Accept either permission explicitly, with a 403 abort. |
| **Plan item** | BCC-02 in `02-fix-plan.md` §4 |

```php
    public function bulkUpsert(BookChapterBulkRequest $request, BokBook $book): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.book-chapter.create');
```

**Evidence**
```
$ grep -rn "book-chapter.update" Modules/SyllabusBooks/app
Modules/SyllabusBooks/app/Policies/BookChapterPolicy.php:27:        return $user->can('tenant.syllabus-books.book-chapter.update');
$ grep -n "Gate::authorize" Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php
22:        Gate::authorize('tenant.syllabus-books.book-chapter.viewAny');
29:        Gate::authorize('tenant.syllabus-books.book-chapter.create');
38:        Gate::authorize('tenant.syllabus-books.book-chapter.delete', $chapter);
```

### F4 — Validation and input

clean — `BookChapterBulkRequest.php:17-37` types every field, checks `end_page >= start_page`, and rejects duplicate chapter numbers in `withValidator()`; `$request->validated()['chapters']` is the only input the service sees (`grep -n "request->all\|->except(" Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php Modules/SyllabusBooks/app/Services/BookChapterService.php` → no output).

### F5 — Routes

clean — all three routes resolve to existing methods (§4), sit under the tenant web group, and the nested parameters match the method signatures (`{book}`/`{chapter}` ↔ `BokBook $book`/`BookChapter $chapter`).

### F6 — Controller shape

clean — 44 lines, 3 methods, constructor injection, typed returns.

### F7 — Models

clean — `BookChapter::$table` exists in the tenant schema (`slb_book_chapters` in `SHOW TABLES LIKE 'slb%'`), `$fillable` and `$casts` complete; `BokBook` is linked to the StudentPortal report.

### F8 — Services and jobs

clean — `BookChapterService` is constructor-injected, does no HTTP work, and wraps the whole bulk write in one `DB::transaction` (`:25`).

### F9 — Queries and performance

#### BCC-04 · M · QRY-03 — the chapters JSON endpoint returns whole rows

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M) — *select only what you use; JSON endpoints must not return whole models* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php:20-25`, method `index()` |
| **Root cause** | `$book->chapters()->get()` selects `*` and serialises the model, including `summary` and audit columns, with no stable order. |
| **Consequence** | The Chapters tab receives every column of every chapter, in unspecified order; the payload grows with the longest summaries and exposes timestamps the screen never uses. |
| **Reproduce** | Open a book, switch to Chapters: the network response contains `summary`, `created_at` and `updated_at` per row. |
| **Fix approach** | Select the columns the tab renders and order by `chapter_no`. |
| **Plan item** | BCC-04 in `02-fix-plan.md` §6 |

```php
    public function index(BokBook $book): JsonResponse
    {
        Gate::authorize('tenant.syllabus-books.book-chapter.viewAny');

        return response()->json(['data' => $book->chapters()->get()]);
```

**Evidence**
```
$ grep -n "chapters()->get()" Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php
24:        return response()->json(['data' => $book->chapters()->get()]);
$ grep -n "chapter_no\|title\|start_page\|end_page" Modules/SyllabusBooks/resources/views/book/_chapters_tab.blade.php | head -5
32:                            <input type="number" name="chapter_no" ... 
41:                            <input type="text" name="title" ...
47:                            <input type="number" name="start_page" ...
```

### F10 — Views

clean — `_chapters_tab.blade.php` loops over data passed by the book screen and performs no query (`grep -nE "::where|DB::|->get\(\)" Modules/SyllabusBooks/resources/views/book/_chapters_tab.blade.php` → no output).

### F11 — Security and tenancy

clean — no `env()`, no hard-coded ids, no file access (`grep -nE "env\(|\?\? 1|Storage::" Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php` → no output).

### F12 — Style

#### BCC-05 · L · STY-02 — the controller is not Pint-clean and has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)*; STY-01 — `declare(strict_types=1)` |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php:1-18` |
| **Root cause** | Pint reports `single_line_empty_body`; there is no `declare(strict_types=1)`. |
| **Consequence** | Style only. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php` |
| **Fix approach** | Add strict types and let Pint collapse the empty constructor. |
| **Plan item** | BCC-05 in `02-fix-plan.md` §8 |

```php
    public function __construct(private readonly BookChapterService $service)
    {
    }
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Http\/Controllers\/BookChapterController.php","fixers":["single_line_empty_body"]}]}
$ grep -c "declare(strict_types=1)" Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php
0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `bulkUpsert` | ok (payload carries every row the tab sends) | ok | ok | ok (no unique index on `book_id`+`chapter_no`) | ok (single transaction) | BCC-02 | ok | ok |
| `destroy` | BCC-01 | ok (soft delete) | ok | ok | ok | BCC-01 | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| — | none found | — | — |

## 8. Not covered, and why

- The Chapters tab was read, not rendered; the JSON shape claim comes from the controller and the partial's field names.
- `BookChapter` and `BokBook` are owned by the StudentPortal report and were not re-audited.
