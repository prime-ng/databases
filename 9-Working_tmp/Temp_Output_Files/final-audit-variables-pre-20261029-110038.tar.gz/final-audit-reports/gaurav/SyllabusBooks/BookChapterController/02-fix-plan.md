# Fix Plan — SyllabusBooks / BookChapterController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SyllabusBooks/routes/web.php` | route file shared by all twelve controllers |
| `Modules/SyllabusBooks/app/Models/BookChapter.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/resources/views/book/_chapters_tab.blade.php` | the chapter tab belongs to the Book screen; no change needed |

## 1. Blockers reachable today

None at B severity.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **BCC-03** · M · TXN-04 · `Modules/SyllabusBooks/app/Services/BookChapterService.php:47-49` — log the bulk chapter save inside its transaction, and log the single delete.
  - **Touches:** `Modules/SyllabusBooks/app/Services/BookChapterService.php`, `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php`
  - **Before** (`BookChapterService.php:47-49`):
    ```php
                $book->chapters()->whereNotIn('id', $keepIds)->delete();

                return $book->chapters()->get();
    ```
  - **After:**
    ```php
                $book->chapters()->whereNotIn('id', $keepIds)->delete();

                activityLog($book, 'Updated', ['message' => 'Book chapters saved.']);

                return $book->chapters()->get();
    ```
  - **Before** (`BookChapterController.php:36-42`):
    ```php
    public function destroy(BokBook $book, BookChapter $chapter): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.book-chapter.delete', $chapter);

        $this->service->delete($chapter);

        return back()->with('success', 'Chapter deleted.');
    ```
  - **After:**
    ```php
    public function destroy(BokBook $book, BookChapter $chapter): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.book-chapter.delete', $chapter);

        $this->service->delete($chapter);

        activityLog($chapter, 'Deleted', ['message' => 'Book chapter deleted.']);

        return back()->with('success', 'Chapter deleted.');
    ```
  - **Verify:** `grep -n "activityLog" Modules/SyllabusBooks/app/Services/BookChapterService.php Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php`
  - **Expect:** one hit in the service (inside the transaction, before `return $book->chapters()->get();`) and one in the controller after `$this->service->delete($chapter);`.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **BCC-01** · H · AUTH-03 · `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php:36-42` — refuse a chapter that does not belong to the book in the URL.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php`
  - **Before** (`BookChapterController.php:36-42`):
    ```php
    public function destroy(BokBook $book, BookChapter $chapter): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.book-chapter.delete', $chapter);

        $this->service->delete($chapter);

        return back()->with('success', 'Chapter deleted.');
    ```
  - **After:**
    ```php
    public function destroy(BokBook $book, BookChapter $chapter): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.book-chapter.delete', $chapter);

        abort_unless($chapter->book_id === $book->id, 404);

        $this->service->delete($chapter);

        return back()->with('success', 'Chapter deleted.');
    ```
  - **Verify:** `grep -n "abort_unless(\$chapter->book_id" Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php`
  - **Expect:** one hit on the line before `$this->service->delete($chapter);`.
  - **Effort:** S

- [ ] **BCC-02** · M · AUTH-05 · `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php:27-31` — let a role that may edit chapters save them, and refuse a role with neither permission.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php`
  - **Before** (`BookChapterController.php:27-31`):
    ```php
    public function bulkUpsert(BookChapterBulkRequest $request, BokBook $book): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.book-chapter.create');

        $this->service->bulkUpsert($book, $request->validated()['chapters']);
    ```
  - **After:**
    ```php
    public function bulkUpsert(BookChapterBulkRequest $request, BokBook $book): RedirectResponse
    {
        abort_unless(
            Gate::allows('tenant.syllabus-books.book-chapter.create')
            || Gate::allows('tenant.syllabus-books.book-chapter.update'),
            403
        );

        $this->service->bulkUpsert($book, $request->validated()['chapters']);
    ```
  - **Verify:** `grep -n "book-chapter.update" Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php`
  - **Expect:** one hit inside `bulkUpsert`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

None.

## 6. Queries & performance (F9)

- [ ] **BCC-04** · M · QRY-03 · `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php:20-25` — return only the columns the Chapters tab renders, in chapter order.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php`
  - **Before** (`BookChapterController.php:20-25`):
    ```php
    public function index(BokBook $book): JsonResponse
    {
        Gate::authorize('tenant.syllabus-books.book-chapter.viewAny');

        return response()->json(['data' => $book->chapters()->get()]);
    ```
  - **After:**
    ```php
    public function index(BokBook $book): JsonResponse
    {
        Gate::authorize('tenant.syllabus-books.book-chapter.viewAny');

        return response()->json([
            'data' => $book->chapters()
                ->orderBy('chapter_no')
                ->get(['id', 'book_id', 'chapter_no', 'title', 'start_page', 'end_page', 'summary', 'is_active']),
        ]);
    ```
  - **Verify:** `grep -n "get(\['id', 'book_id', 'chapter_no'" Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php`
  - **Expect:** one hit inside `index()`.
  - **Effort:** S

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **BCC-05** · L · STY-02 · `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php:1` — add `strict_types` and make the file Pint-clean.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php`
  - **Before** (`BookChapterController.php:1-3`):
    ```php
    <?php

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - Then run `vendor/bin/pint Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php --format agent` and accept the `single_line_empty_body` change:
    ```php
        public function __construct(private readonly BookChapterService $service) {}
    ```
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookChapterController.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** S

## 9. Deferred / decisions

None.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | every finding has a plan item |
