# Fix Plan — SyllabusBooks / NoteDownloadController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/NoteDownloadController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SyllabusBooks/resources/views/**` | dashboard views are owned by the SyllabusBooksController report |
| `Modules/SyllabusBooks/routes/web.php` | route file shared by all twelve controllers |

## 1. Blockers reachable today

None.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None.

## 4. Authorization (F3)

None.

## 5. Validation, routes, models (F4/F5/F7)

None.

## 6. Queries & performance (F9)

None.

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **NDL-01** · L · STY-01 · `Modules/SyllabusBooks/app/Http/Controllers/NoteDownloadController.php:1` — add `strict_types`.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/NoteDownloadController.php`
  - **Before** (`NoteDownloadController.php:1-3`):
    ```php
    <?php

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/SyllabusBooks/app/Http/Controllers/NoteDownloadController.php`
  - **Expect:** `3:declare(strict_types=1);`
  - **Effort:** S

## 9. Deferred / decisions

None.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | every finding has a plan item |
