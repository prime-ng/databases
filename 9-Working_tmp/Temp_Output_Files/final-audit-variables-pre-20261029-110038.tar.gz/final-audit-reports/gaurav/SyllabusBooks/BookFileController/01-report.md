# Final Audit — SyllabusBooks / BookFileController

**Audited:** 2026-10-28 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php` (100 lines, 5 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /syllabus-books/books/{book}/files` (JSON) · `POST`/`PUT`/`DELETE /syllabus-books/books/{book}/files[/{file}]` · `GET /syllabus-books/books/{book}/files/{file}/download` |
| Menu path | Syllabus Books → Books → open a book → Files tab |
| Who uses it | Roles holding `tenant.syllabus-books.book-file.viewAny/create/update/delete/download` (`config/permissionslist.php:1023` adds `download` to CRUD). |
| What a user does here | Attach a PDF/EPUB/image to a book, rename it, mark it the primary file, choose whether it is downloadable, then download or delete it. Each download is logged with user, time, IP and browser. |
| Tables written | `slb_book_files`, `slb_book_downloads`, `media_files` (through Spatie) |
| Tables read | `slb_book_files`, `slb_books`, `slb_config` |
| Live data | `slb_book_files` = 8 rows, `slb_book_downloads` = 8 rows on `test.localhost` (tinker SELECT, 2026-10-28) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready: the download guard that enforces "this file is not downloadable" never runs, because the controller passes a permission string where the policy expects a model ability. Deleting a file also destroys the stored media inside a transaction that cannot restore it, so a failed delete leaves a broken row. Effort: half a day (S/M).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 2 | 4 | 1 | 0 | 8 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BFC-04 | F8 Services/Jobs | BFC-03 |
| F2 Transactions/Audit | BFC-03, BFC-07 | F9 Queries/Perf | BFC-06 |
| F3 Authorization | BFC-01, BFC-02 | F10 Views | clean |
| F4 Validation | BFC-05 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | BFC-08 |
| F6 Controller shape | clean | F13 Deep read | BFC-01, BFC-02, BFC-03 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php` | controller | 100 | this report | ✅ |
| 2 | `Modules/SyllabusBooks/app/Http/Requests/BookFileRequest.php` | FormRequest | 43 | this report | ✅ |
| 3 | `Modules/SyllabusBooks/app/Services/BookFileService.php` | service | 140 | ↗ [gaurav/SyllabusBooks/BookFileController](01-report.md) | ✅ |
| 4 | `Modules/SyllabusBooks/app/Policies/BookFilePolicy.php` | policy | 43 | ↗ [gaurav/SyllabusBooks/BookFileController](01-report.md) | ✅ |
| 5 | `Modules/SyllabusBooks/app/Models/BookFile.php` | model | 72 | ↗ tarun/StudentPortal-done/MobilePrescribedBooksController — linked | ↗ linked |
| 6 | `Modules/SyllabusBooks/app/Models/BokBook.php` | model | 140 | ↗ tarun/StudentPortal-done/StudentPortalController — linked | ↗ linked |
| 7 | `Modules/SyllabusBooks/app/Models/SlbBookDownload.php` | model | 58 | ↗ tarun/StudentPortal-done/StudentPortalController — linked | ↗ linked |
| 8 | `Modules/SyllabusBooks/resources/views/book/_files_tab.blade.php` | blade partial | 73 | this report | ✅ |

No pre-applied files.

## 4. Routes

```
GET|HEAD  syllabus-books/books/{book}/files                    syllabus-books.books.files.index     Modules\SyllabusBooks\Http\Controllers\BookFileController@index
POST      syllabus-books/books/{book}/files                    syllabus-books.books.files.store     Modules\SyllabusBooks\Http\Controllers\BookFileController@store
PUT       syllabus-books/books/{book}/files/{file}             syllabus-books.books.files.update    Modules\SyllabusBooks\Http\Controllers\BookFileController@update
DELETE    syllabus-books/books/{book}/files/{file}             syllabus-books.books.files.destroy   Modules\SyllabusBooks\Http\Controllers\BookFileController@destroy
GET|HEAD  syllabus-books/books/{book}/files/{file}/download    syllabus-books.books.files.download  Modules\SyllabusBooks\Http\Controllers\BookFileController@downloadStream
```

Unrouted public methods: none.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 23 | GET books/{book}/files | `tenant.syllabus-books.book-file.viewAny` | none (read) | none | — | BFC-06 |
| `store` | 32 | POST books/{book}/files | `tenant.syllabus-books.book-file.create` | service `attach` | none | `slb_book_files`, `media_files` | BFC-07 |
| `update` | 41 | PUT books/{book}/files/{file} | `tenant.syllabus-books.book-file.update` | service `markPrimary` (only for the primary flag) | none | `slb_book_files` | BFC-02, BFC-05, BFC-07 |
| `destroy` | 64 | DELETE books/{book}/files/{file} | `tenant.syllabus-books.book-file.delete` | service `delete` | none | `slb_book_files`, `media_files`, `slb_book_downloads` | BFC-02, BFC-03, BFC-07 |
| `downloadStream` | 73 | GET books/{book}/files/{file}/download | `tenant.syllabus-books.book-file.download` | none | none | `slb_book_downloads` | BFC-01, BFC-02, BFC-04 |

## 6. Findings

### F1 — Errors

#### BFC-04 · M · ERR-05 — the download-log failure log keeps the message, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:88-93`, method `downloadStream()` |
| **Root cause** | The `catch (\Throwable $e)` writes `'error' => $e->getMessage()` into `Log::warning`, so the stack trace and the failing query are lost. |
| **Consequence** | When download logging starts failing (for example a missing column), the log says "SQLSTATE…" with no call site, and nobody can find which code path broke. |
| **Reproduce** | static only — the catch only runs when the insert fails. |
| **Fix approach** | Log the exception object through the `exception` key (or `report($e)` with a fixed message). |
| **Plan item** | BFC-04 in `02-fix-plan.md` §3 |

```php
        } catch (\Throwable $e) {
            \Log::warning('Failed to log book file download', [
                'book_file_id' => $file->id,
                'error'        => $e->getMessage(),
            ]);
        }
```

**Evidence**
```
$ grep -n "getMessage\|Log::warning" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php
89:            \Log::warning('Failed to log book file download', [
91:                'error'        => $e->getMessage(),
```

### F2 — Transactions and audit

#### BFC-03 · B · TXN-03 — deleting a book file destroys the stored file before the row is safely deleted

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B) — *no irreversible side effect inside a transaction; file deletes cannot roll back* |
| **Where** | `Modules/SyllabusBooks/app/Services/BookFileService.php:95-101`, method `delete()` |
| **Root cause** | `clearMediaCollection()` deletes media rows and the file on disk **inside** `DB::transaction`, then `$bookFile->delete()` soft-deletes the row. A rollback restores the row but not the file. Because the row is only soft-deleted, the "deleted" file cannot be restored either. |
| **Consequence** | A failed delete, or a mistaken delete, leaves a book-file row pointing at a media record that no longer exists; restoring the row produces a download that 404s. |
| **Reproduce** | Delete a file from the Files tab, then restore the `slb_book_files` row in the database: `GET …/download` returns 404. |
| **Fix approach** | Soft-delete the row first, commit, then clear the media collection outside the transaction; keep the media until a force delete. |
| **Plan item** | BFC-03 in `02-fix-plan.md` §1 |

```php
    public function delete(BookFile $bookFile): void
    {
        DB::transaction(function () use ($bookFile) {
            $bookFile->clearMediaCollection(BookFile::MEDIA_FILE);
            $bookFile->delete();
        });
    }
```

**Evidence**
```
$ sed -n '95,101p' Modules/SyllabusBooks/app/Services/BookFileService.php
    public function delete(BookFile $bookFile): void
    {
        DB::transaction(function () use ($bookFile) {
            $bookFile->clearMediaCollection(BookFile::MEDIA_FILE);
            $bookFile->delete();
        });
    }
$ grep -n "use SoftDeletes" Modules/SyllabusBooks/app/Models/BookFile.php
18:    use InteractsWithMedia, SoftDeletes;
```

#### BFC-07 · M · TXN-04 — attaching, editing and deleting a book file leave no activity-log entry

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/SyllabusBooks/app/Services/BookFileService.php:16-101` (all three mutating methods) |
| **Root cause** | `attach()`, `markPrimary()` and `delete()` never call `activityLog()`; the only log in this controller is the download log. |
| **Consequence** | Files can be replaced, re-flagged or removed with no record of who did it. |
| **Reproduce** | static only — upload then delete a file, the activity log has no `BookFile` entry. |
| **Fix approach** | Log inside the existing transactions, after each write. |
| **Plan item** | BFC-07 in `02-fix-plan.md` §3 |

```php
            $bookFile = $book->files()->create([
                'media_id'        => $media->id,          // valid FK — no null insert
                'file_format'     => $fileFormat,
                'file_size_kb'    => $fileSizeKb,
                'label'           => $meta['label'] ?? null,
                'is_downloadable' => (bool) ($meta['is_downloadable'] ?? $config->is_book_downloadable),
                'is_primary'      => $isPrimary,
                'book_edition'    => $meta['book_edition'] ?? null,
            ]);
```

**Evidence**
```
$ grep -n "activityLog" Modules/SyllabusBooks/app/Services/BookFileService.php Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php
(no output)
$ grep -n "public function attach\|public function markPrimary\|public function delete" Modules/SyllabusBooks/app/Services/BookFileService.php
16:    public function attach(BokBook $book, UploadedFile $file, array $meta): BookFile
85:    public function markPrimary(BookFile $bookFile): BookFile
95:    public function delete(BookFile $bookFile): void
```

### F3 — Authorization

#### BFC-01 · H · AUTH-05 — the "not downloadable" policy rule never runs

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (H) — *dead permission logic: `BookFilePolicy::download()` is never consulted, so its `is_downloadable` guard is dead* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:73-78` and `Modules/SyllabusBooks/app/Policies/BookFilePolicy.php:35-42` |
| **Root cause** | The controller calls `Gate::authorize('tenant.syllabus-books.book-file.download', $file)` — a permission **string**. Passing a model as the second argument does not select the policy; only `Gate::authorize('download', $file)` does. The policy method that checks `$bookFile->is_downloadable` and `$bookFile->book?->is_downloadable` never executes. |
| **Consequence** | Any user with the download permission downloads files the school marked non-downloadable, including books whose `is_downloadable` flag is off. |
| **Reproduce** | Turn a book's "downloadable" switch off, then open `…/files/{file}/download` as a permitted user: the file downloads. |
| **Fix approach** | Authorize the policy ability with the model: `Gate::authorize('download', $file)`; the policy already contains the permission check. |
| **Plan item** | BFC-01 in `02-fix-plan.md` §4 |

```php
    public function downloadStream(BokBook $book, BookFile $file): StreamedResponse
    {
        Gate::authorize('tenant.syllabus-books.book-file.download', $file);

        $media = $file->getFirstMedia(BookFile::MEDIA_FILE);
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php
25:        Gate::authorize('tenant.syllabus-books.book-file.viewAny');
34:        Gate::authorize('tenant.syllabus-books.book-file.create');
43:        Gate::authorize('tenant.syllabus-books.book-file.update', $file);
66:        Gate::authorize('tenant.syllabus-books.book-file.delete', $file);
75:        Gate::authorize('tenant.syllabus-books.book-file.download', $file);
$ sed -n '35,42p' Modules/SyllabusBooks/app/Policies/BookFilePolicy.php
    public function download(User $user, BookFile $bookFile): bool
    {
        if (! $bookFile->is_downloadable || ! $bookFile->book?->is_downloadable) {
            return false;
        }

        return $user->can('tenant.syllabus-books.book-file.download');
    }
```

#### BFC-02 · H · AUTH-03 — a file from another book can be edited, deleted or downloaded

| Field | Value |
|---|---|
| **Rule** | AUTH-03 (H) — *record-level checks where data belongs to a parent record* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:41-43`, `:64-66` and `:73-75` |
| **Root cause** | `{book}` and `{file}` bind independently; no method checks `$file->book_id === $book->id`. The policy checks only the permission. |
| **Consequence** | A user can rename, re-flag, delete or download any book's file by putting its id under a book they can open; the flash message reports success against the wrong book. |
| **Reproduce** | Open book 1's Files tab and request `DELETE /syllabus-books/books/1/files/8` where file 8 belongs to another book → the file is deleted. |
| **Fix approach** | `abort_unless($file->book_id === $book->id, 404);` in `update()`, `destroy()` and `downloadStream()`. |
| **Plan item** | BFC-02 in `02-fix-plan.md` §4 |

```php
    public function destroy(BokBook $book, BookFile $file): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.book-file.delete', $file);

        $this->service->delete($file);
```

**Evidence**
```
$ grep -n "book_id" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php Modules/SyllabusBooks/app/Services/BookFileService.php
(no output)
$ grep -n "public function update\|public function destroy\|public function downloadStream" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php
41:    public function update(Request $request, BokBook $book, BookFile $file): RedirectResponse
64:    public function destroy(BokBook $book, BookFile $file): RedirectResponse
73:    public function downloadStream(BokBook $book, BookFile $file): StreamedResponse
```

### F4 — Validation and input

#### BFC-05 · M · VAL-02 — the file edit form validates inline while a FormRequest sits unused for PUT

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a FormRequest; inline `$request->validate()` only for a one-field AJAX toggle* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:41-50` |
| **Root cause** | `update()` validates four fields inline. `BookFileRequest` exists for this controller but its `file` rule is `required_without:id`, which is always true on a PUT body without an `id`, so it cannot be reused as written. |
| **Consequence** | Two rule sets drift: the FormRequest allows `file_format` and the controller does not, and the next field added to one is forgotten in the other. |
| **Reproduce** | static only — PUT with `file_format` is silently dropped while POST accepts it. |
| **Fix approach** | Move the four rules into `BookFileRequest` behind a `isMethod('PUT')` branch, then type-hint it in `update()`. |
| **Plan item** | BFC-05 in `02-fix-plan.md` §5 |

```php
    public function update(Request $request, BokBook $book, BookFile $file): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.book-file.update', $file);

        $data = $request->validate([
            'label'           => 'nullable|string|max:150',
            'is_primary'      => 'nullable|boolean',
            'is_downloadable' => 'nullable|boolean',
            'book_edition'    => 'nullable|string|max:50',
        ]);
```

**Evidence**
```
$ grep -n "request->validate" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php
45:        $data = $request->validate([
$ grep -n "required_without:id" Modules/SyllabusBooks/app/Http/Requests/BookFileRequest.php
26:            'file'            => "required_without:id|file|mimes:pdf,epub,jpg,jpeg,png,docx,mobi|max:{$maxKb}",
```

### F5 — Routes

clean — five routes, all resolving to existing methods; nested parameters `{book}`/`{file}` match the typed arguments; all inside the tenant web group.

### F6 — Controller shape

clean — 100 lines, 5 methods, constructor injection, return types on all actions.

### F7 — Models

clean — `BookFile` overrides `getMediaModel()` (`BookFile.php:43-46`, TEN-01 satisfied), `$fillable`/`$casts` complete, table exists (`slb_book_files` in `SHOW TABLES LIKE 'slb%'`).

### F8 — Services and jobs

clean apart from BFC-03/BFC-07 — `BookFileService` injects nothing, performs no HTTP, and keeps Spatie file writes outside the DB transaction deliberately (`:37-39`).

### F9 — Queries and performance

#### BFC-06 · M · QRY-03 — the files JSON endpoint returns whole rows

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M) — *select only what you use; JSON endpoints must not return whole models* |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:23-30` |
| **Root cause** | `$book->files()->orderByDesc('is_primary')->get()` selects `*` and serialises every column, including `media_id` and timestamps. |
| **Consequence** | The Files tab receives internal media ids and audit columns it never renders. |
| **Reproduce** | Open a book's Files tab and inspect the JSON: `media_id`, `created_at`, `updated_at` are present. |
| **Fix approach** | Select the columns the tab uses. |
| **Plan item** | BFC-06 in `02-fix-plan.md` §6 |

```php
        return response()->json([
            'data' => $book->files()->orderByDesc('is_primary')->get(),
        ]);
```

**Evidence**
```
$ grep -n "files()->orderByDesc" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php
28:            'data' => $book->files()->orderByDesc('is_primary')->get(),
```

### F10 — Views

clean — `_files_tab.blade.php` renders only data from the JSON/loop and performs no query (`grep -nE "::where|DB::|->get\(\)" Modules/SyllabusBooks/resources/views/book/_files_tab.blade.php` → no output); no `{!! !!}` (`grep -c '{!!'` → 0).

### F11 — Security and tenancy

clean — the file is served through the authorized route from the media disk (`:95-98`), not a public URL; no `env()`, no hard-coded id (`grep -nE "env\(|\?\? 1" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php` → no output).

### F12 — Style

#### BFC-08 · L · STY-02 — the controller is not Pint-clean and has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)*; STY-01 — `declare(strict_types=1)` |
| **Where** | `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:1-21` |
| **Root cause** | Pint reports `unary_operator_spaces`, `not_operator_with_successor_space`, `single_line_empty_body` and `binary_operator_spaces`; no `declare(strict_types=1)`. |
| **Consequence** | Style only. |
| **Reproduce** | `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php` |
| **Fix approach** | Add strict types and run Pint on the file. |
| **Plan item** | BFC-08 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SyllabusBooks\Http\Controllers;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SyllabusBooks\/app\/Http\/Controllers\/BookFileController.php","fixers":["unary_operator_spaces","not_operator_with_successor_space","single_line_empty_body","binary_operator_spaces"]}]}
$ grep -c "declare(strict_types=1)" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php
0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok (media uploaded before insert, cleaned up on failure) | ok | ok | ok | ok | ok | BFC-07 |
| `update` | ok | ok | ok | ok | ok | BFC-02 | ok | ok |
| `destroy` | ok | BFC-03 | ok | ok | ok | BFC-02 | "File deleted." while the row is only soft-deleted — acceptable, the file is gone | ok |
| `downloadStream` | ok | ok | ok | ok | ok | BFC-01, BFC-02 | ok | BFC-01 (policy dead) |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SyllabusBooks/app/Policies/BookFilePolicy.php` | `download()` cannot be reached while the controller passes permission strings; the same pattern may exist in other modules that pass strings to policy-registered models | AUTH-05 | module owner, after BFC-01 |

## 8. Not covered, and why

- The Files tab was read, not rendered; its JSON claim is from the controller and the partial's field names.
- `BookFile`, `BokBook` and `SlbBookDownload` are owned by the StudentPortal report and were not re-audited.
- Spatie media cleanup behaviour was reasoned from the code; no upload or delete was run (read-only audit, D4).
