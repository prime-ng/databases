# Fix Plan — SyllabusBooks / BookFileController

**From:** `01-report.md` (2026-10-28) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SyllabusBooks/routes/web.php` | route file shared by all twelve controllers |
| `Modules/SyllabusBooks/app/Models/BookFile.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/app/Models/SlbBookDownload.php` | owned by the StudentPortal report |
| `Modules/SyllabusBooks/resources/views/book/_files_tab.blade.php` | belongs to the Book screen; no change needed |

## 1. Blockers reachable today

- [ ] **BFC-03** · B · TXN-03 · `Modules/SyllabusBooks/app/Services/BookFileService.php:95-101` — delete the row before the media, so a rollback cannot leave a row pointing at a destroyed file.
  - **Touches:** `Modules/SyllabusBooks/app/Services/BookFileService.php`
  - **Before** (`BookFileService.php:95-101`):
    ```php
    public function delete(BookFile $bookFile): void
    {
        DB::transaction(function () use ($bookFile) {
            $bookFile->clearMediaCollection(BookFile::MEDIA_FILE);
            $bookFile->delete();
        });
    }
    ```
  - **After:**
    ```php
    public function delete(BookFile $bookFile): void
    {
        DB::transaction(function () use ($bookFile) {
            $bookFile->delete();

            activityLog($bookFile, 'Deleted', ['message' => 'Book file deleted.']);
        });

        $bookFile->clearMediaCollection(BookFile::MEDIA_FILE);
    }
    ```
  - **Verify:** `grep -n "clearMediaCollection" Modules/SyllabusBooks/app/Services/BookFileService.php`
  - **Expect:** one hit, **outside** the `DB::transaction` closure (after its closing `});`).
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **BFC-04** · M · ERR-05 · `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:88-93` — log the exception object so the trace survives.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`
  - **Before** (`BookFileController.php:88-93`):
    ```php
        } catch (\Throwable $e) {
            \Log::warning('Failed to log book file download', [
                'book_file_id' => $file->id,
                'error'        => $e->getMessage(),
            ]);
        }
    ```
  - **After:**
    ```php
        } catch (\Throwable $e) {
            \Log::warning('Failed to log book file download', [
                'book_file_id' => $file->id,
                'exception'    => $e,
            ]);
        }
    ```
  - **Verify:** `grep -n "getMessage" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BFC-07** · M · TXN-04 · `Modules/SyllabusBooks/app/Services/BookFileService.php:56` — record attach, primary change and delete in the activity log, inside the existing transactions.
  - **Touches:** `Modules/SyllabusBooks/app/Services/BookFileService.php`
  - **Before** (`BookFileService.php:56-62`):
    ```php
                ]);

                if ($isPrimary) {
                    $this->demoteOtherPrimaries($book, $bookFile->id);
                }

                return $bookFile;
    ```
  - **After:**
    ```php
                ]);

                if ($isPrimary) {
                    $this->demoteOtherPrimaries($book, $bookFile->id);
                }

                activityLog($bookFile, 'Created', ['message' => 'Book file attached.']);

                return $bookFile;
    ```
  - Then add the same call to `markPrimary()` after the update, before the return:
    ```php
                $bookFile->update(['is_primary' => true]);

                activityLog($bookFile, 'Updated', ['message' => 'Book file marked primary.']);
    ```
    and in `delete()` as shown in BFC-03.
  - **Verify:** `grep -c "activityLog" Modules/SyllabusBooks/app/Services/BookFileService.php`
  - **Expect:** `3` (attach, markPrimary, delete).
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **BFC-01** · H · AUTH-05 · `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:73-78` — run the policy's `download()` ability so a non-downloadable book cannot be downloaded.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`
  - **Before** (`BookFileController.php:73-78`):
    ```php
    public function downloadStream(BokBook $book, BookFile $file): StreamedResponse
    {
        Gate::authorize('tenant.syllabus-books.book-file.download', $file);

        $media = $file->getFirstMedia(BookFile::MEDIA_FILE);
        abort_unless($media, 404, 'File not available.');
    ```
  - **After:**
    ```php
    public function downloadStream(BokBook $book, BookFile $file): StreamedResponse
    {
        Gate::authorize('download', $file);

        $media = $file->getFirstMedia(BookFile::MEDIA_FILE);
        abort_unless($media, 404, 'File not available.');
    ```
  - **Verify:** `grep -n "Gate::authorize('download'" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`
  - **Expect:** one hit inside `downloadStream()`.
  - **Effort:** S

- [ ] **BFC-02** · H · AUTH-03 · `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:41-43`, `:64-66`, `:73-75` — refuse a file that does not belong to the book in the URL.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`
  - **Before** (`BookFileController.php:41-43`):
    ```php
    public function update(Request $request, BokBook $book, BookFile $file): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.book-file.update', $file);
    ```
  - **After:**
    ```php
    public function update(Request $request, BokBook $book, BookFile $file): RedirectResponse
    {
        Gate::authorize('tenant.syllabus-books.book-file.update', $file);

        abort_unless($file->book_id === $book->id, 404);
    ```
  - Apply the same `abort_unless($file->book_id === $book->id, 404);` line immediately after the gate in `destroy()` (line 66) and `downloadStream()` (line 75).
  - **Verify:** `grep -c "abort_unless(\$file->book_id === \$book->id, 404)" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`
  - **Expect:** `3`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **BFC-05** · M · VAL-02 · `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:41-50` — move the four edit rules into `BookFileRequest` and type-hint it.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`, `Modules/SyllabusBooks/app/Http/Requests/BookFileRequest.php`
  - **Before** (`BookFileController.php:41`) — the signature only, so this edit does not collide with BFC-02:
    ```php
    public function update(Request $request, BokBook $book, BookFile $file): RedirectResponse
    ```
  - **After:**
    ```php
    public function update(BookFileRequest $request, BokBook $book, BookFile $file): RedirectResponse
    ```
  - **Before** (`BookFileController.php:45-50`) — the inline rule block:
    ```php
        $data = $request->validate([
            'label'           => 'nullable|string|max:150',
            'is_primary'      => 'nullable|boolean',
            'is_downloadable' => 'nullable|boolean',
            'book_edition'    => 'nullable|string|max:50',
        ]);
    ```
  - **After:**
    ```php
        $data = $request->validated();
    ```
  - And in `BookFileRequest::rules()`, replace the `file` rule and add nothing else — the four edit rules already exist in the same array — while making the upload optional on PUT:
    ```php
            'file'            => 'nullable|file|mimes:pdf,epub,jpg,jpeg,png,docx,mobi|max:'.$maxKb,
    ```
  - **Verify:** `grep -n "BookFileRequest \$request, BokBook \$book, BookFile \$file" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`
  - **Expect:** one hit in `update()`.
  - **Effort:** M

## 6. Queries & performance (F9)

- [ ] **BFC-06** · M · QRY-03 · `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:27-29` — return only the columns the Files tab renders.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`
  - **Before** (`BookFileController.php:27-29`):
    ```php
        return response()->json([
            'data' => $book->files()->orderByDesc('is_primary')->get(),
        ]);
    ```
  - **After:**
    ```php
        return response()->json([
            'data' => $book->files()
                ->orderByDesc('is_primary')
                ->get(['id', 'book_id', 'file_format', 'file_size_kb', 'label', 'is_downloadable', 'is_primary', 'book_edition', 'is_active']),
        ]);
    ```
  - **Verify:** `grep -n "get(\['id', 'book_id', 'file_format'" Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`
  - **Expect:** one hit inside `index()`.
  - **Effort:** S

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **BFC-08** · L · STY-02 · `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php:1` — add `strict_types` and make the file Pint-clean.
  - **Touches:** `Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`
  - **Before** (`BookFileController.php:1-3`):
    ```php
    <?php

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SyllabusBooks\Http\Controllers;
    ```
  - Then run `vendor/bin/pint Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php --format agent` and accept its spacing and empty-constructor changes.
  - **Verify:** `vendor/bin/pint --test Modules/SyllabusBooks/app/Http/Controllers/BookFileController.php`
  - **Expect:** no output and exit code 0.
  - **Effort:** S

## 9. Deferred / decisions

None.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | every finding has a plan item |
