# Fix Plan — Complaint / MedicalCheckController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

> ⚠ **Coordinated items.** MEDC-01, MEDC-03, MEDC-09 and MEDC-10 all edit the same controller file and several share the `store`/`update` methods. Apply them in the order printed; the fixer must re-read the file before each item (final-audit §9.2 #3) and stop on a mismatch. The `Before` blocks below are copied from the file as it stands today.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Complaint/routes/web.php` | ⚠ SHARED route file — only the single `Route::get(…restore…)` verb may change, and only under the MEDC-08 SHARED tick |
| `Modules/Complaint/app/Providers/ComplaintServiceProvider.php` | ⚠ SHARED provider file — only the `Gate::policy` line, and only under the MEDC-04 DECISION |
| `Modules/Complaint/database/seeders/MedicalCheckSeeder.php` | other report / runs only under the MEDC-20 DECISION |
| `database/migrations/tenant/*cmp_medical_checks*` | never edit an existing migration |
| `Modules/Complaint/app/Models/Complaint.php`, `Modules/Complaint/app/Models/ComplaintCategory.php` | owned by other reports (`gaurav/Complaint/ComplaintController`, `gaurav/Complaint/ComplaintCategoryController`) |
| `Modules/Complaint/resources/views/complaint/medical-checks/index.blade.php` | rendered by `ComplaintController@index`; owned by `gaurav/Complaint/ComplaintController` |
| `app/Models/TenantMedia.php`, `Modules/CommonChat/app/Models/ChatMessage.php` | shared/common — referenced only |

## 1. Blockers reachable today

- [ ] **MEDC-15** · B · MDL-05 / TEN-01 · `Modules/Complaint/app/Models/MedicalCheck.php:15-19` — override `getMediaModel()` so tenant evidence does not leak into the central `prime_db`.
  - **Touches:** `Modules/Complaint/app/Models/MedicalCheck.php`
  - **Before** (`MedicalCheck.php:43-47`):
    ```php
    //begin::Image Handling
    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('medical_img')->singleFile();
    }
    ```
  - **After:**
    ```php
    //begin::Image Handling
    public function getMediaModel(): string
    {
        return \App\Models\TenantMedia::class;
    }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('medical_img')->singleFile();
    }
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Models\MedicalCheck.php -Pattern "getMediaModel|TenantMedia"`
  - **Expect:** two matching lines (`function getMediaModel`, `return \App\Models\TenantMedia::class;`).
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

## 3. Errors & transactions (F1/F2)

- [ ] **MEDC-01** · H · TXN-01 / TXN-04 / TXN-03 · `MedicalCheckController.php:68-113` — rewrite `store()`: one transaction for the model write, media added by the single-file collection, an audit row, the shared guard, and no debug/redundant code; extract validation to a FormRequest (fixes VAL-02/VAL-06 folded in).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php`, `Modules/Complaint/app/Http/Requests/MedicalCheckRequest.php` (new)
  - **Before** (`MedicalCheckController.php:68-113`):
    ```php
    public function store(Request $request)
    {
        Gate::authorize('tenant.complaint.medical-check.create');
        // dd($request->all());
        // $request->merge([
        //     'evidence_uploded' => $request->has('evidence_uploded') ? 1 : 0,
        // ]);
        // dd($request->all());

        $validated = $this->validateMedicalCheck($request);

        $complaint = Complaint::find($validated['complaint_id']);
        if (!$complaint || !$complaint->is_medical_check_required) {
            return back()
                ->withInput()
                ->with('error', 'Medical check can only be created for complaints whose category requires a medical check.');
        }

        $medical = MedicalCheck::create($validated);

        if ($request->hasFile('medical_img')) {

            $medical->clearMediaCollection('medical_img');

            $medical
                ->addMediaFromRequest('medical_img')
                ->toMediaCollection('medical_img');

            // force DB write
            $medical->update([
                'evidence_uploaded' => true
            ]);
        } else {

            $medical->update([
                'evidence_uploaded' => false
            ]);
        }


        $medical->save();

        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'medical'])
            ->with('success', 'Medical check created successfully.');
    }
    ```
  - **After** (`Modules/Complaint/app/Http/Requests/MedicalCheckRequest.php` — new file, full content):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;

    class MedicalCheckRequest extends FormRequest
    {
        /**
         * Authorization stays in the controller (AUTH-04: authorize once).
         */
        public function authorize(): bool
        {
            return true;
        }

        public function rules(): array
        {
            return [
                'complaint_id' => 'required|exists:cmp_complaints,id',
                'check_type_id' => 'required|exists:sys_dropdown_table,id',
                'conducted_by' => 'nullable|string|max:100',
                'conducted_at' => 'required|date',
                'result' => 'required|exists:sys_dropdown_table,id',
                'reading_value' => 'nullable|string|max:50',
                'remarks' => 'nullable|string',
                'medical_img' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:5120',
            ];
        }
    }
    ```
    **After** (`MedicalCheckController.php` — replace the `store()` method and the `validateMedicalCheck()` helper):
    ```php
    public function store(MedicalCheckRequest $request)
    {
        Gate::authorize('tenant.complaint.medical-check.create');

        $validated = $request->validated();

        if (! $this->complaintRequiresMedicalCheck($validated['complaint_id'])) {
            return back()
                ->withInput()
                ->with('error', 'Medical check can only be created for complaints whose category requires a medical check.');
        }

        $medical = DB::transaction(function () use ($request, $validated) {
            $medical = MedicalCheck::create($validated);

            if ($request->hasFile('medical_img')) {
                $medical->addMediaFromRequest('medical_img')
                    ->toMediaCollection('medical_img');
            }

            $medical->update([
                'evidence_uploaded' => $request->hasFile('medical_img'),
            ]);

            activityLog($medical, 'Created', [
                'message' => 'Medical check created.',
            ]);

            return $medical;
        });

        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'medical'])
            ->with('success', 'Medical check created successfully.');
    }

    /**
     * A medical check may only be recorded for a complaint whose category requires one.
     */
    protected function complaintRequiresMedicalCheck(int $complaintId): bool
    {
        $complaint = Complaint::find($complaintId);

        return $complaint !== null && (bool) $complaint->is_medical_check_required;
    }
    ```
    Also: delete the old `validateMedicalCheck()` helper (lines 252-267), add `use Modules\Complaint\Http\Requests\MedicalCheckRequest;`, and delete `use Modules\Complaint\Models\ComplaintCategory;` (line 9, unused).
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern "validateMedicalCheck|ComplaintCategory|dd\("`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **MEDC-02** · M · TXN-04 / TXN-01 · `MedicalCheckController.php:185-195` and `:221-231` — wrap `destroy()` and `restore()` in a transaction and write an audit row.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php`
  - **Before** (`MedicalCheckController.php:185-195`):
    ```php
    public function destroy($id)
    {
        Gate::authorize('tenant.complaint.medical-check.delete');

        $medicalCheck = MedicalCheck::findOrFail($id);
        $medicalCheck->delete();

        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'medical'])
            ->with('success', 'Medical check moved to trash.');
    }
    ```
    **Before** (`MedicalCheckController.php:221-231`):
    ```php
    public function restore($id)
    {
        Gate::authorize('tenant.complaint.medical-check.restore');

        $medicalCheck = MedicalCheck::onlyTrashed()->findOrFail($id);
        $medicalCheck->restore();

        return redirect()
            ->route('complaint.medical-checks.trashed')
            ->with('success', 'Medical check restored successfully.');
    }
    ```
  - **After** (`destroy()`):
    ```php
    public function destroy($id)
    {
        Gate::authorize('tenant.complaint.medical-check.delete');

        $medicalCheck = MedicalCheck::findOrFail($id);

        DB::transaction(function () use ($medicalCheck) {
            $medicalCheck->delete();

            activityLog($medicalCheck, 'Deleted', [
                'message' => 'Medical check moved to trash.',
            ]);
        });

        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'medical'])
            ->with('success', 'Medical check moved to trash.');
    }
    ```
    **After** (`restore()`):
    ```php
    public function restore($id)
    {
        Gate::authorize('tenant.complaint.medical-check.restore');

        $medicalCheck = MedicalCheck::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($medicalCheck) {
            $medicalCheck->restore();

            activityLog($medicalCheck, 'Restored', [
                'message' => 'Medical check restored.',
            ]);
        });

        return redirect()
            ->route('complaint.medical-checks.trashed')
            ->with('success', 'Medical check restored successfully.');
    }
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern "activityLog"`
  - **Expect:** at least four matching lines (`'Created'`, `'Updated'`, `'Deleted'`, `'Restored'`, `'Force Deleted'`).
  - **Effort:** S

- [ ] **MEDC-03** · H · TXN-03 / TXN-01 / TXN-04 · `MedicalCheckController.php:138-178` and `:236-250` — rewrite `update()` (transaction, no clear-before-add, audit) and `forceDelete()` (delete the row first, clear media after, audit).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php`
  - **Before** (`MedicalCheckController.php:138-178`):
    ```php
    public function update(Request $request, $id)
    {
        Gate::authorize('tenant.complaint.medical-check.update');

        $medicalCheck = MedicalCheck::findOrFail($id);

        $validated = $this->validateMedicalCheck($request);

        $complaint = Complaint::find($validated['complaint_id']);
        if (!$complaint || !$complaint->is_medical_check_required) {
            return back()
                ->withInput()
                ->with('error', 'Medical check can only be created for complaints whose category requires a medical check.');
        }

        $medicalCheck->update($validated);

        if ($request->hasFile('medical_img')) {

            $medicalCheck->clearMediaCollection('medical_img');

            $medicalCheck
                ->addMediaFromRequest('medical_img')
                ->toMediaCollection('medical_img');

            $medicalCheck->update([
                'evidence_uploaded' => true
            ]);
        } else {

            if ($medicalCheck->getMedia('medical_img')->isEmpty()) {
                $medicalCheck->update([
                    'evidence_uploaded' => false
                ]);
            }
        }

        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'medical'])
            ->with('success', 'Medical check updated successfully.');
    }
    ```
    **Before** (`MedicalCheckController.php:236-250`):
    ```php
    public function forceDelete($id)
    {
        Gate::authorize('tenant.complaint.medical-check.forceDelete');

        $medicalCheck = MedicalCheck::onlyTrashed()->findOrFail($id);

        // Optional: delete media as well
        $medicalCheck->clearMediaCollection('medical_img');

        $medicalCheck->forceDelete();

        return redirect()
            ->route('complaint.medical-checks.trashed')
            ->with('success', 'Medical check permanently deleted.');
    }
    ```
  - **After** (`update()`):
    ```php
    public function update(MedicalCheckRequest $request, MedicalCheck $medicalCheck)
    {
        Gate::authorize('tenant.complaint.medical-check.update');

        $validated = $request->validated();

        if (! $this->complaintRequiresMedicalCheck($validated['complaint_id'])) {
            return back()
                ->withInput()
                ->with('error', 'Medical check can only be created for complaints whose category requires a medical check.');
        }

        DB::transaction(function () use ($request, $medicalCheck, $validated) {
            $medicalCheck->update($validated);

            if ($request->hasFile('medical_img')) {
                $medicalCheck->addMediaFromRequest('medical_img')
                    ->toMediaCollection('medical_img');

                $medicalCheck->update([
                    'evidence_uploaded' => true,
                ]);
            } elseif ($medicalCheck->getMedia('medical_img')->isEmpty()) {
                $medicalCheck->update([
                    'evidence_uploaded' => false,
                ]);
            }

            activityLog($medicalCheck, 'Updated', [
                'message' => 'Medical check updated.',
            ]);
        });

        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'medical'])
            ->with('success', 'Medical check updated successfully.');
    }
    ```
    **After** (`forceDelete()`):
    ```php
    public function forceDelete($id)
    {
        Gate::authorize('tenant.complaint.medical-check.forceDelete');

        $medicalCheck = MedicalCheck::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($medicalCheck) {
            $medicalCheck->forceDelete();

            activityLog($medicalCheck, 'Force Deleted', [
                'message' => 'Medical check permanently deleted.',
            ]);
        });

        $medicalCheck->clearMediaCollection('medical_img');

        return redirect()
            ->route('complaint.medical-checks.trashed')
            ->with('success', 'Medical check permanently deleted.');
    }
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern "clearMediaCollection"`
  - **Expect:** one matching line only, inside `forceDelete()` and **after** the `DB::transaction` block.
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **MEDC-05** · L · AUTH-01 · `MedicalCheckController.php:202` — gate the read-only trash list on the read permission `.viewAny`, not the write permission `.restore`.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php`
  - **Before** (`MedicalCheckController.php:200-202`):
    ```php
    public function trashed()
    {
        Gate::authorize('tenant.complaint.medical-check.restore');
    ```
  - **After:**
    ```php
    public function trashed()
    {
        Gate::authorize('tenant.complaint.medical-check.viewAny');
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern "viewAny|restore" -Context 0,0`
  - **Expect:** line 202 is now `Gate::authorize('tenant.complaint.medical-check.viewAny');`; the `.restore` gate remains only in `restore()`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7) and controller shape (F6)

- [ ] **MEDC-08** · H · RTE-01 · `Modules/Complaint/routes/web.php:171-174` — `restore` changes state, so it must not be a GET. ⚠ SHARED
  - **Touches:** `Modules/Complaint/routes/web.php` (⚠ SHARED — needs its own explicit tick)
  - **Before** (`Modules/Complaint/routes/web.php:171-174`):
    ```php
    Route::get(
        'medical-checks/{id}/restore',
        [MedicalCheckController::class, 'restore']
    )->name('medical-checks.restore');
    ```
  - **After:**
    ```php
    Route::delete(
        'medical-checks/{id}/restore',
        [MedicalCheckController::class, 'restore']
    )->name('medical-checks.restore');
    ```
    If the trash-row action links this route with a plain `<a href>`, the fixer must check `trash.blade.php` (`x-backend.table.action-trashed`) and report if a form/method change is also required — stop and ask rather than edit the shared component.
  - **Verify:** `Select-String -Path Modules\Complaint\routes\web.php -Pattern "medical-checks/\{id\}/restore" -Context 1,0`
  - **Expect:** the line above it is `Route::delete(`.
  - **Effort:** S

- [ ] **MEDC-09** · M · RTE-03 (D5) · `MedicalCheckController.php:19-48` — disable the unrouted `index()`.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php`
  - **Before** (`MedicalCheckController.php:19-48`):
    ```php
    public function index(Request $request)
    {
        Gate::authorize('tenant.complaint.medical-check.viewAny');

        $medicalChecks = MedicalCheck::with(['complaint', 'checkType', 'resultStatus'])
            ->when($request->check_type_id, fn($q, $v) => $q->where('check_type_id', $v))
            ->when($request->result, fn($q, $v) => $q->where('result', $v))
            ->when(
                $request->search,
                fn($q, $v) =>
                $q->where('conducted_by', 'like', "%{$v}%")
                    ->orWhere('complaint_id', $v)
            )
            ->latest()
            ->paginate(15)
            ->withQueryString();

        $checkTypes = DB::table('sys_dropdown_table')
            ->where('key', 'cmp_medical_checks.check_type_id')
            ->get(['id', 'value']);

        $results = DB::table('sys_dropdown_table')
            ->where('key', 'cmp_medical_checks.result')
            ->get(['id', 'value']);

        return view(
            'complaint::complaint.medical-checks.index',
            compact('medicalChecks', 'checkTypes', 'results')
        );
    }
    ```
  - **After:**
    ```php
    public function index(Request $request)
    {
        // NOT ROUTED — the Medical tab is served by ComplaintController@index
        // (Modules/Complaint/routes/web.php:161). Disabled per final-audit D5.
        abort(403, 'This action is not routed.');
    }
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern "NOT ROUTED"`
  - **Expect:** one matching line at the top of `index()`.
  - **Effort:** S

- [ ] **MEDC-10** · L · RTE-06 / CTL-03 · `MedicalCheckController.php:119-133`, `:185-195`, `:272-283` — use route model binding for `edit`, `destroy`, `show`. (The `update` signature is already changed by MEDC-03.)
  - **Touches:** `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php`
  - **Before** (`MedicalCheckController.php:119-127`):
    ```php
    public function edit($id)
    {
        Gate::authorize('tenant.complaint.medical-check.update');

        $medicalCheck = MedicalCheck::with([
            'complaint',
            'checkType',
            'resultStatus',
        ])->findOrFail($id);
    ```
    **Before** (`destroy`, `:185-189`):
    ```php
    public function destroy($id)
    {
        Gate::authorize('tenant.complaint.medical-check.delete');

        $medicalCheck = MedicalCheck::findOrFail($id);
    ```
    **Before** (`show`, `:272-280`):
    ```php
    public function show($id)
    {
        Gate::authorize('tenant.complaint.medical-check.view');

        $medicalCheck = MedicalCheck::with([
            'complaint',
            'checkType',
            'resultStatus',
        ])->findOrFail($id);
    ```
  - **After** (`edit()`):
    ```php
    public function edit(MedicalCheck $medicalCheck)
    {
        Gate::authorize('tenant.complaint.medical-check.update');

        $medicalCheck->load([
            'complaint',
            'checkType',
            'resultStatus',
        ]);
    ```
    **After** (`destroy()`):
    ```php
    public function destroy(MedicalCheck $medicalCheck)
    {
        Gate::authorize('tenant.complaint.medical-check.delete');
    ```
    **After** (`show()`):
    ```php
    public function show(MedicalCheck $medicalCheck)
    {
        Gate::authorize('tenant.complaint.medical-check.view');

        $medicalCheck->load([
            'complaint',
            'checkType',
            'resultStatus',
        ]);
    ```
    ⚠ Note for the fixer: MEDC-02 also edits `destroy()`. Apply MEDC-02 first (it keeps `$id` + `findOrFail`), then MEDC-10 converts the signature to binding and deletes the `$medicalCheck = MedicalCheck::findOrFail($id);` line. If the file does not match, stop and ask.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern "public function (edit|destroy|show)\("`
  - **Expect:** `edit(MedicalCheck $medicalCheck)`, `destroy(MedicalCheck $medicalCheck)`, `show(MedicalCheck $medicalCheck)`.
  - **Effort:** M

- [ ] **MEDC-13** · M · CTL-10 · `MedicalCheckController.php:9` — remove the unused `ComplaintCategory` import. (The redundant `$medical->save()` is removed by MEDC-01; the unused `create()` loads are fixed by MEDC-17.)
  - **Touches:** `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php`
  - **Before** (`MedicalCheckController.php:5-12`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\Complaint\Models\MedicalCheck;
    use Modules\Complaint\Models\ComplaintCategory;
    use Modules\SchoolSetup\Models\User;
    use Illuminate\Support\Facades\DB;
    use Modules\Complaint\Models\Complaint;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\Complaint\Http\Requests\MedicalCheckRequest;
    use Modules\Complaint\Models\MedicalCheck;
    use Modules\SchoolSetup\Models\User;
    use Illuminate\Support\Facades\DB;
    use Modules\Complaint\Models\Complaint;
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern "ComplaintCategory"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **MEDC-14** · L · CTL-04 · `MedicalCheckController.php:53, 119, 185, 221, 236, 272` — add return types to the public methods.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php`
  - **Before** (`MedicalCheckController.php:53`):
    ```php
    public function create()
    ```
  - **After:**
    ```php
    public function create(): \Illuminate\View\View
    ```
    Apply the same to: `edit` → `: \Illuminate\View\View`, `show` → `: \Illuminate\View\View`, `trashed` → `: \Illuminate\View\View`, `store` → `: \Illuminate\Http\RedirectResponse`, `update` → `: \Illuminate\Http\RedirectResponse`, `destroy` → `: \Illuminate\Http\RedirectResponse`, `restore` → `: \Illuminate\Http\RedirectResponse`, `forceDelete` → `: \Illuminate\Http\RedirectResponse`, `index` → `: never` (after MEDC-09).
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern "public function"`
  - **Expect:** every public method line ends with `: \Illuminate\View\View`, `: \Illuminate\Http\RedirectResponse` or `: never`.
  - **Effort:** S

- [ ] **MEDC-16** · L · MDL-04 · `Modules/Complaint/app/Models/MedicalCheck.php:75-94` — return-type the three relationships.
  - **Touches:** `Modules/Complaint/app/Models/MedicalCheck.php`
  - **Before** (`MedicalCheck.php:75-94`):
    ```php
    public function complaint()
    {
        return $this->belongsTo(Complaint::class, 'complaint_id');
    }

    public function checkType()
    {
        return $this->belongsTo(Dropdown::class, 'check_type_id');
    }

    public function resultStatus()
    {
        return $this->belongsTo(Dropdown::class, 'result');
    }
    ```
  - **After:**
    ```php
    public function complaint(): BelongsTo
    {
        return $this->belongsTo(Complaint::class, 'complaint_id');
    }

    public function checkType(): BelongsTo
    {
        return $this->belongsTo(Dropdown::class, 'check_type_id');
    }

    public function resultStatus(): BelongsTo
    {
        return $this->belongsTo(Dropdown::class, 'result');
    }
    ```
    Add `use Illuminate\Database\Eloquent\Relations\BelongsTo;` to the imports.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Models\MedicalCheck.php -Pattern ": BelongsTo"`
  - **Expect:** three matching lines.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **MEDC-17** · H · QRY-02 / QRY-15 · `MedicalCheckController.php:57-62` and `:129-132` — stop loading whole tables for the create/edit forms.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php`
  - **Before** (`create()`, `:57-62`):
    ```php
    return view('complaint::complaint.medical-checks.create', [
        'complaints' => Complaint::all(),
        'checkTypes' => DB::table('sys_dropdown_table')->where('key', 'cmp_medical_checks.check_type_id')->get(['id', 'value']),
        'results' => DB::table('sys_dropdown_table')->where('key', 'cmp_medical_checks.result')->get(['id', 'value']),
        'users' => User::all(),
    ]);
    ```
    **Before** (`edit()`, `:129-132`):
    ```php
    return view('complaint::complaint.medical-checks.edit', [
        'medicalCheck' => $medicalCheck,
        'complaints' => Complaint::all(),
    ]);
    ```
  - **After** (`create()` — `checkTypes`/`results` are loaded by `<x-backend.form.form-dropdown>` and `$users` is never read by `create.blade.php`, so all three are dropped):
    ```php
    return view('complaint::complaint.medical-checks.create', [
        'complaints' => Complaint::where('is_medical_check_required', true)
            ->get(['id', 'ticket_no', 'title']),
    ]);
    ```
    **After** (`edit()`):
    ```php
    return view('complaint::complaint.medical-checks.edit', [
        'medicalCheck' => $medicalCheck,
        'complaints' => Complaint::where('is_medical_check_required', true)
            ->get(['id', 'ticket_no', 'title']),
    ]);
    ```
    After this item, the `use Modules\SchoolSetup\Models\User;` import becomes unused — remove it (if MEDC-13 is not ticked, do it here).
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern "::all\(\)"`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

- [ ] **MEDC-18** · M · F13-Q8 (dead feature) · `Modules/Complaint/resources/views/complaint/medical-checks/edit.blade.php:94-98` — remove the "Evidence Uploaded" toggle the controller never reads.
  - **Touches:** `Modules/Complaint/resources/views/complaint/medical-checks/edit.blade.php`
  - **Before** (`edit.blade.php:88-101`):
    ```php
    <div class="col-md-4 mt-2">
        <div class="border rounded p-3">
            <label class="form-label fw-semibold d-block mb-2">
                Evidence Uploaded
            </label>

            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" id="evidence_uploaded"
                    name="evidence_uploaded" value="1"
                    {{ old('evidence_uploaded', $medicalCheck->evidence_uploaded) ? 'checked' : '' }}>
            </div>

        </div>
    </div>
    ```
  - **After:**
    ```php
    <div class="col-md-4 mt-2">
        <div class="border rounded p-3">
            <label class="form-label fw-semibold d-block mb-2">
                Evidence Uploaded
            </label>

            <span class="badge {{ $medicalCheck->evidence_uploaded ? 'bg-success' : 'bg-secondary' }}">
                {{ $medicalCheck->evidence_uploaded ? 'Yes' : 'No' }}
            </span>
            <small class="text-muted d-block mt-2">Set automatically from the uploaded evidence file.</small>
        </div>
    </div>
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\resources\views\complaint\medical-checks\edit.blade.php -Pattern 'name="evidence_uploaded"'`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **MEDC-19** · L · STY-01 / STY-02 / STY-04 · `MedicalCheckController.php` and `MedicalCheck.php` — add `strict_types`, delete the commented `dd()` block (if MEDC-01 was not ticked), and run Pint.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php`, `Modules/Complaint/app/Models/MedicalCheck.php`
  - **Before** (`MedicalCheckController.php:1-3`):
    ```php
    <?php

    namespace Modules\Complaint\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Http\Controllers;
    ```
    Same insertion in `MedicalCheck.php` after the opening `<?php`. Then run Pint on both files.
  - **Verify:** `vendor\bin\pint --test Modules\Complaint\app\Http\Controllers\MedicalCheckController.php Modules\Complaint\app\Models\MedicalCheck.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **MEDC-04** · M · DECISION · AUTH-06 — `MedicalCheckPolicy` is registered but never consulted (the controller uses permission strings). ⚠ SHARED (provider file)
  - **Why it is a decision:** removing a `Gate::policy` registration is a behaviour change, and option (b) rewrites every authorization call.
  - (a) ⭐ delete `Modules/Complaint/app/Policies/MedicalCheckPolicy.php` and the `Gate::policy(MedicalCheck::class, MedicalCheckPolicy::class);` line in `ComplaintServiceProvider.php:64`, keeping the string gates.
  - (b) keep the policy and convert every `Gate::authorize('tenant.complaint.medical-check.X')` to `Gate::authorize('X', MedicalCheck::class)`.
  - (c) leave as is and record it as accepted.
  - ➜ Choice: ____

- [ ] **MEDC-20** · M · DECISION · MDL-04 / F7 — the seeded `result` stores a label while the relation and controller treat it as a dropdown id. ⚠ SHARED (seeder)
  - **Why it is a decision:** it needs a data backfill and/or a seeder change and moves the meaning of a stored column.
  - (a) ⭐ fix `MedicalCheckSeeder` to insert dropdown ids for `result` and backfill the 4 existing rows (`result` = id of the matching `sys_dropdown_table.value`).
  - (b) keep labels and add a value-based accessor/relation instead of the id join.
  - (c) leave as is and record it as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| MEDC-06 | Folded into MEDC-01 — the `medical_img` `file|mimes|max` rule is written into the new `MedicalCheckRequest`. |
| MEDC-07 | Folded into MEDC-01 / MEDC-03 — the inline `validateMedicalCheck()` helper is replaced by `MedicalCheckRequest`. |
| MEDC-11 | Folded into MEDC-01 — the commented `dd()` block is removed by the `store()` rewrite. |
| MEDC-12 | Folded into MEDC-01 / MEDC-03 — the duplicated complaint guard becomes the shared `complaintRequiresMedicalCheck()` helper. |
