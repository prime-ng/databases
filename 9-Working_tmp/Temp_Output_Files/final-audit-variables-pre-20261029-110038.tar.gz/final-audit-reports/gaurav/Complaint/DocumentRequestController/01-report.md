# Final Audit — Complaint / DocumentRequestController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php` (118 lines, 3 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/complaint/documents` (list) · `/complaint/documents/{id}` (detail) · `POST /complaint/documents/{id}` (save). Resolved by the route probe below. |
| Menu path | Complaint → Document Requests. Menu row: `MenuSyncController.php:2945-2958`, `title => 'Document Requests'`, `route => 'complaint.documents.index'`. Breadcrumb parent is `complaint.complaint-mgt.index` (`app/Services/Breadcrumbs/registry.php:1340-1342`). |
| Who uses it | Super Admin and School Admin — the only roles holding `tenant.complaint.complaint.viewAny`, `.view`, `.update` and `.export` in the live tenant DB (measured, see §7 evidence). |
| What a user does here | An admin opens the list of document requests parents raised (transfer certificate, mark sheet, bonafide, …), filters by status / document type / student name, opens one request, then sets its status, an optional fee, admin notes, and uploads the fulfilled PDF or image. |
| Tables written | `ppt_document_requests` (UPDATE). `sys_media` through Spatie `addMediaFromRequest()` — but the media model is pinned to the CENTRAL `prime_db` (see §7). No audit-log table is written. |
| Tables read | `ppt_document_requests`, `std_students`, `std_guardians`, `sys_users`, `sys_dropdown_table`, `sys_media`. |
| Live data | `ppt_document_requests` **5 live rows, 0 trashed** (measured on tenant `xyz_school_00000000000040008000_202627`). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Not production-ready.** The list page's Status and Document Type filters build a query against columns that do not exist on `ppt_document_requests` — picking either filter returns a 500 (DOCR-01, proven against the live tenant DB). The single worst finding is DOCR-03: the save path deletes the currently-stored document *before* the replacement file is stored, so a failed upload destroys the existing document. The controller is short (118 lines) and the whole plan is small (roughly half a day), but DOCR-01 and DOCR-03 must land before the screen ships.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 2 | 2 | 4 | 1 | 10 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean (none used) |
| F2 Transactions/Audit | DOCR-03, DOCR-04, DOCR-05 | F9 Queries/Perf | DOCR-01, DOCR-02, DOCR-07 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | DOCR-06 | F11 Security/Tenancy | clean (media issue is cross-cutting §7) |
| F5 Routes | clean | F12 Style | DOCR-09, DOCR-10 |
| F6 Controller shape | DOCR-08 | F13 Deep read | table in F13 |
| F7 Models | ↗ linked (owned elsewhere) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php` | controller | 118 | this report | ✅ |
| 2 | `Modules/ParentPortal/app/Models/ParentDocumentRequest.php` | model | 214 | ↗ [tarun/ParentPortal-done/ParentDocumentController](../../../tarun/ParentPortal-done/ParentDocumentController-done/01-report.md) | ↗ linked |
| 3 | `Modules/ParentPortal/app/Services/PptDropdownResolver.php` | service | 41 | ↗ same owner as #2 (reached through the model) | ↗ linked |
| 4 | `Modules/Complaint/routes/web.php` | route file | 198 | shared route file | ↗ inspected for this controller's routes only |
| 5 | `Modules/Complaint/resources/views/document-request/index.blade.php` | view | 180 | this report | ✅ |
| 6 | `Modules/Complaint/resources/views/document-request/show.blade.php` | view | 170 | this report | ✅ |
| 7 | `config/permissionslist.php` | config | 1703 | shared config | ↗ checked for the three gates only |

No pre-applied files (the only `PRE-APPLIED-2026-10-10.md` is the TimetableFoundation one; it names no Complaint file).

The model in row 2 is owned by `tarun/ParentPortal-done/ParentDocumentController` (already claimed) and is **not re-audited here**; only how *this* controller uses it is reported. `PptDropdownResolver` is reached through that model, so it follows the same owner.

## 4. Routes

Fresh, uncached (`route:clear`, `APP_ROUTES_CACHE=<missing path>`), piped through the probe helper:

```
GET|HEAD  complaint/documents                                     complaint.documents.index           Modules\Complaint\Http\Controllers\DocumentRequestController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  complaint/documents/{documentRequest}                   complaint.documents.show            Modules\Complaint\Http\Controllers\DocumentRequestController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      complaint/documents/{documentRequest}                   complaint.documents.update          Modules\Complaint\Http\Controllers\DocumentRequestController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none (all three public methods appear above). Route parameter `{documentRequest}` matches the `$documentRequest` argument in `show()` and `update()` — binding is correct (F5 clean).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | GET /complaint/documents | `tenant.complaint.complaint.viewAny` | none (read) | none (read) | reads only | DOCR-01, DOCR-02, DOCR-07 |
| `show` | 63 | GET /complaint/documents/{documentRequest} | `tenant.complaint.complaint.view` | none (read) | none (read) | reads only | DOCR-08 |
| `update` | 83 | POST /complaint/documents/{documentRequest} | `tenant.complaint.complaint.update` | none | none | ppt_document_requests, sys_media (central) | DOCR-03, DOCR-04, DOCR-05, DOCR-06, DOCR-08, DOCR-09 |

## 6. Findings

### F1 — Errors

clean — `Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "try|catch|getMessage"` → no output. No `try/catch`, no exception text reaches the user.

### F2 — Transactions and audit

#### DOCR-03 · B · TXN-03 — the stored document is deleted before its replacement is saved

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B) — *no irreversible side effect inside a transaction or before the write succeeds: file deletes, mail, SMS, push, HTTP calls* |
| **Where** | `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php:106-113`, method `update()` |
| **Root cause** | `clearMediaCollection('fulfilled_documents')` deletes the existing media row *and its file on disk* first; only then does `addMediaFromRequest('document')->toMediaCollection(...)` store the new file. If the upload/store step fails, the old fulfilled document is already gone and nothing replaces it. |
| **Consequence** | An admin who uploads a replacement for a completed request can lose the original document entirely, leaving the parent unable to download a certificate the school already issued. |
| **Reproduce** | Open `/complaint/documents/{id}`, choose a file, Save. If the media store fails (e.g. the central/tenant media split in §7), the previous file is already deleted. |
| **Fix approach** | Store the new media first, update `fulfilled_media_id`, then delete the old media row after the write succeeds (see plan `DOCR-03`). |
| **Plan item** | DOCR-03 in `02-fix-plan.md` §1 |

```php
// DocumentRequestController.php:106-113 — CURRENT
        if ($request->hasFile('document')) {
            $documentRequest->clearMediaCollection('fulfilled_documents');
            
            $media = $documentRequest->addMediaFromRequest('document')
                ->toMediaCollection('fulfilled_documents');
                
            $documentRequest->update(['fulfilled_media_id' => $media->id]);
        }
```

**Evidence**
```
$ Read Modules/Complaint/app/Http/Controllers/DocumentRequestController.php:106-113
106:        if ($request->hasFile('document')) {
107:            $documentRequest->clearMediaCollection('fulfilled_documents');
108:
109:            $media = $documentRequest->addMediaFromRequest('document')
110:                ->toMediaCollection('fulfilled_documents');
111:
112:            $documentRequest->update(['fulfilled_media_id' => $media->id]);
113:        }
```
Line 107 (delete) precedes line 109 (store): the destructive call is first.

#### DOCR-04 · H · TXN-01 — the mutation performs multiple writes with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (two models, a model + its audit row, a model + pivot) runs inside one `DB::transaction`* |
| **Where** | `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php:100-113`, method `update()` |
| **Root cause** | The method issues two separate `ppt_document_requests` UPDATEs (line 100 and line 112) plus a media DELETE and a media INSERT, with no `DB::transaction`. A failure between them leaves a half-applied request (new status but old `fulfilled_media_id`, or vice-versa). |
| **Consequence** | A request can end up showing a new status while still pointing at the wrong/removed document, and there is no rollback. |
| **Reproduce** | Static only — the failure needs the DB write to throw mid-method; the missing transaction is visible in source. |
| **Fix approach** | Wrap the `ppt_document_requests` writes in one `DB::transaction`, with `activityLog()` inside (plan `DOCR-03`). |
| **Plan item** | DOCR-03 in `02-fix-plan.md` §1 (same change) |

```php
// DocumentRequestController.php:100-113 — CURRENT (two updates, no DB::transaction)
        $documentRequest->update([
            'status' => $request->status,
            'fee_required' => $request->fee_required ?? 0,
            'admin_notes' => $request->admin_notes,
        ]);

        if ($request->hasFile('document')) {
            $documentRequest->clearMediaCollection('fulfilled_documents');
            $media = $documentRequest->addMediaFromRequest('document')
                ->toMediaCollection('fulfilled_documents');
            $documentRequest->update(['fulfilled_media_id' => $media->id]);
        }
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "DB::|transaction"
(no output — no DB::transaction anywhere in the file)
```

#### DOCR-05 · M · TXN-04 — the mutation writes no audit-log entry

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php:83-117`, method `update()` |
| **Root cause** | No `activityLog()` call exists in the controller, yet every other Complaint mutation calls it (e.g. `ComplaintCategoryController.php:143`, `DepartmentSlaController.php:126`). A status change or a fulfilled-document upload leaves no tenant audit row. |
| **Consequence** | When a parent disputes a document request's status, there is no record of who changed it, when, or that a document was uploaded. |
| **Reproduce** | Update any request, then open System Config → Activity Log; no entry for the document request. |
| **Fix approach** | Add `activityLog($documentRequest, 'Updated', [...])` inside the transaction (plan `DOCR-03`). |
| **Plan item** | DOCR-03 in `02-fix-plan.md` §1 (same change) |

```php
// DocumentRequestController.php:100-104 — CURRENT: the only write, no audit row
        $documentRequest->update([
            'status' => $request->status,
            'fee_required' => $request->fee_required ?? 0,
            'admin_notes' => $request->admin_notes,
        ]);
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "activityLog"
(no output)
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintCategoryController.php" -Pattern "activityLog" | Select-Object -First 2
ComplaintCategoryController.php:72:                activityLog($category, 'Created', [
ComplaintCategoryController.php:143:                activityLog($category, 'Updated', [
```

### F3 — Authorization

clean — each routed method authorizes before touching data, with the correct verb:

```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "Gate::authorize"
19:        Gate::authorize('tenant.complaint.complaint.viewAny');
65:        Gate::authorize('tenant.complaint.complaint.view');
85:        Gate::authorize('tenant.complaint.complaint.update');
```

All three strings are declared by `config/permissionslist.php:859` (`'complaint.complaint' => array_merge($crud, ['manage', 'export'])`; `$crud` supplies `viewAny`/`view`/`update`). Read methods use read keys, the write method uses the write key — no read key used for a write. The permission is shared with the Complaint feature (there is no document-request-specific key); that is consistent with the menu row (`MenuSyncController.php:2956` gates on `tenant.complaint.complaint.viewAny`). No Policy is involved and none is bypassed.

### F4 — Validation and input

#### DOCR-06 · M · VAL-02 — validation is inline instead of a Form Request

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request, not inline `$request->validate()` — except one-field AJAX toggles* |
| **Where** | `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php:87-98`, method `update()` |
| **Root cause** | A four-field form (status, fee, notes, file) is validated with an inline `$request->validate([...])`; the module already has a `Modules/Complaint/app/Http/Requests/` folder and uses Form Requests elsewhere. The validated data is then discarded and the model is fed from the raw request (`$request->status`, `$request->fee_required`, `$request->admin_notes`). |
| **Consequence** | The rules are not reusable or testable in one place, and the code path reads unvalidated request values at lines 101-103 — the two can drift. |
| **Reproduce** | Static only — reading the method; no user-visible symptom on the happy path. |
| **Fix approach** | Move the rules into `UpdateDocumentRequestRequest` and type-hint it; read `$request->validated()` (plan `DOCR-06`). |
| **Plan item** | DOCR-06 in `02-fix-plan.md` §5 |

```php
// DocumentRequestController.php:87-104 — CURRENT
        $request->validate([
            'status' => 'required|in:' . implode(',', [
                ParentDocumentRequest::STATUS_PENDING,
                ParentDocumentRequest::STATUS_PROCESSING,
                ParentDocumentRequest::STATUS_READY,
                ParentDocumentRequest::STATUS_COMPLETED,
                ParentDocumentRequest::STATUS_REJECTED,
            ]),
            'fee_required' => 'nullable|numeric|min:0',
            'admin_notes' => 'nullable|string',
            'document' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
        ]);

        $documentRequest->update([
            'status' => $request->status,
            'fee_required' => $request->fee_required ?? 0,
            'admin_notes' => $request->admin_notes,
        ]);
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "->validate"
87:        $request->validate([
```

The upload rule already carries `file` + `mimes` + `max` (line 97), so VAL-06 is satisfied. `$request->all()` in `appends(...)` (line 54) is recorded under DOCR-07.

### F5 — Routes

clean — every public method is routed (three routes, three methods) and the `{documentRequest}` parameter name matches the controller argument (§4). Tenant + auth middleware are present on all three routes (route probe output, §4). No state change over GET; `update` is POST.

### F6 — Controller shape

#### DOCR-08 · L · CTL-04 — public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php:17`, `:63`, `:83` |
| **Root cause** | All three methods are declared without a return type. |
| **Consequence** | None for the user; the contract of each action is less clear to the next developer and to static analysis. |
| **Reproduce** | Static only — reading the signatures. |
| **Fix approach** | Add `: View` to `index`/`show` and `: RedirectResponse` to `update` (plan `DOCR-08`; `update`'s type is added together with DOCR-06). |
| **Plan item** | DOCR-08 in `02-fix-plan.md` §8 |

```php
// DocumentRequestController.php — CURRENT signatures
17:    public function index(Request $request)
63:    public function show(ParentDocumentRequest $documentRequest)
83:    public function update(Request $request, ParentDocumentRequest $documentRequest)
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "public function"
17:    public function index(Request $request)
63:    public function show(ParentDocumentRequest $documentRequest)
83:    public function update(Request $request, ParentDocumentRequest $documentRequest)
```
No `):` appears on any signature. The file is small (118 lines, 3 methods), so CTL-01/CTL-02 are not present.

### F7 — Models

The controller's only model, `Modules/ParentPortal/app/Models/ParentDocumentRequest.php`, is owned by `tarun/ParentPortal-done/ParentDocumentController` — **linked, not re-audited** here. Usage checked: the query uses the model's `active()` scope and the `student`/`guardian.user`/`createdBy` relations (all exist), and route-model binding is type-hinted. Two model facts surface in this controller's behaviour and are recorded as cross-cutting in §7 (missing `getMediaModel()`) and F9 (dropdown accessors query per call).

### F8 — Services and jobs

clean — the controller injects no service and dispatches no job: `Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "Service|Job|dispatch"` → no output. (It calls the static `PptDropdownResolver` only in the plan's fix, not today.)

### F9 — Queries and performance

#### DOCR-01 · B · MDL-07 — the Status and Document Type filters query columns that do not exist (500)

| Field | Value |
|---|---|
| **Rule** | MDL-07 (B) — *every schema object a query names must exist; a query over a missing one 500s on first use* (the rulebook states this for a model's table; here it is two columns — same defect class: the app disagrees with its own schema) |
| **Where** | `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php:26-32`, method `index()` |
| **Root cause** | The table stores the dropdown option as `status_option_id` and `document_type_option_id` (migration + live schema below). The controller filters on the *virtual* attribute names `status` and `document_type`, which the model exposes only as accessors (`getStatusAttribute`/`getDocumentTypeAttribute`) — an Eloquent `where()` never consults an accessor, so the query names non-existent columns. |
| **Consequence** | Any admin who picks a Status or Document Type in the filter and presses Search gets a 500 error page instead of the filtered list. |
| **Reproduce** | Open `/complaint/documents`, choose `Status = Pending`, Submit → 500. Same with `Document Type`. |
| **Fix approach** | Resolve the filter value to its option id (via the model's own `PptDropdownResolver`) and query the `*_option_id` column (plan `DOCR-01`). |
| **Plan item** | DOCR-01 in `02-fix-plan.md` §1 |

```php
// DocumentRequestController.php:26-32 — CURRENT
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('document_type')) {
            $query->where('document_type', $request->document_type);
        }
```

**Evidence**
```
$ php fa_counts2.php   (bootstraps the app, runs on the live tenant DB)
COLUMNS:["id","request_number","document_type_option_id","reason","urgency_option_id","status_option_id","admin_notes","fee_required","fee_paid","payment_reference","fulfilled_at","is_active","created_by","created_at","updated_at","student_id","guardian_id","fulfilled_media_id","deleted_at"]
DOCREQ_COUNT:5
DOCREQ_TRASHED:0
STATUS_WHERE:ERR:SQLSTATE[42S22]: Column not found: 1054 Unknown column 'status' in 'where clause' (Connection: tenant, Host: 127.0.0.1, Port: 3306, Database: xyz_school_00000000000040008000_202627, SQL: select count(*) as aggregate from `ppt_document_requests` where `status` = Pending and `ppt_document_requests`.`deleted_at` is null)
DOCTYPE_WHERE:ERR:SQLSTATE[42S22]: Column not found: 1054 Unknown column 'document_type' in 'where clause' (Connection: tenant, Host: 127.0.0.1, Port: 3306, Database: xyz_school_00000000000040008000_202627, SQL: select count(*) as aggregate from `ppt_document_requests` where `document_type` = TC and `ppt_document_requests`.`deleted_at` is null)
```
The migration agrees: `database/migrations/tenant/2026_06_16_105225_create_ppt_document_requests_table.php:17,28` define `document_type_option_id` and `status_option_id` and no `status`/`document_type` column.

#### DOCR-02 · H · QRY-01 — every dropdown value on the list page is one query per row (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; eager-load, pre-fetch into a keyed collection, or bulk-write* |
| **Where** | `Modules/Complaint/resources/views/document-request/index.blade.php:114,116,124,133` rendered with the paginator from `DocumentRequestController.php:54` |
| **Root cause** | The blade reads `$req->documentTypeLabel()`, `$req->urgency` and `$req->status`. Those resolve through the model's `document_type`/`urgency`/`status` accessors, each of which calls `PptDropdownResolver::value()`, which runs `Dropdown::find($id)` with **no memoisation** (`PptDropdownResolver.php:31-40`). So every row issues one `select * from sys_dropdown_table where id = ?` per accessor read — and `$req->status` is read twice (match at line 124, badge at line 133). |
| **Consequence** | A 20-row page issues roughly 80 extra dropdown queries before it renders; each row of the export feed does the same. The page slows down in proportion to rows-per-page. |
| **Reproduce** | Load `/complaint/documents` with 20 rows and watch the query count (3-4 `sys_dropdown_table` selects per row). |
| **Fix approach** | Pre-resolve the three dropdown columns once per request (a `DECISION`: the clean fix memoises `PptDropdownResolver::value()`, which belongs to the model's owner report; see plan `DOCR-02`). |
| **Plan item** | DOCR-02 in `02-fix-plan.md` §9 |

```php
// resources/views/document-request/index.blade.php:114,116,124,133 — the per-row accessor reads
114:                                <td>{{ $req->documentTypeLabel() }}</td>
116:                                    @if($req->urgency == 'Urgent')
124:                                        $color = match ($req->status) {
133:                                    <span class="badge badge-{{ $color }}">{{ $req->status }}</span>
```

**Evidence**
```
$ php fa_evidence3.php   (query log on the live tenant)
$doc = ParentDocumentRequest::first(); // then read $doc->document_type, ->urgency, ->status
ACCESSOR_QUERIES:4
  SQL:select * from `ppt_document_requests` where `ppt_document_requests`.`deleted_at` is null limit 1
  SQL:select * from `sys_dropdown_table` where `sys_dropdown_table`.`id` = ? and `sys_dropdown_table`.`deleted_at` is null limit 1
  SQL:select * from `sys_dropdown_table` where `sys_dropdown_table`.`id` = ? and `sys_dropdown_table`.`deleted_at` is null limit 1
  SQL:select * from `sys_dropdown_table` where `sys_dropdown_table`.`id` = ? and `sys_dropdown_table`.`deleted_at` is null limit 1
```
Three accessor reads → three identical `sys_dropdown_table` selects (no memoisation), repeated for every row of the list.

#### DOCR-07 · L · QRY-13 — pagination appends all request params and pages at 20, not the house 10

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L) — *filtered paginators keep filters (`->withQueryString()`); multiple paginators use distinct page names* (house standard C12 sets the list page size at 10) |
| **Where** | `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php:54`, method `index()` |
| **Root cause** | `->paginate(20)->appends($request->all())` re-appends every request key (including unrelated ones) rather than the current query string, and uses 20 rows per page where C12 says 10. |
| **Consequence** | Pagination links can carry stray query keys, and the list shows twice the house page size. No functional break. |
| **Reproduce** | Add `?foo=bar` to `/complaint/documents` and page forward — `foo=bar` is carried into the next page's links. |
| **Fix approach** | `->paginate(10)->withQueryString()` (plan `DOCR-07`). The export clone at line 52 is taken before pagination, so it is unaffected. |
| **Plan item** | DOCR-07 in `02-fix-plan.md` §6 |

```php
// DocumentRequestController.php:54 — CURRENT
        $documentRequests = $query->paginate(20)->appends($request->all());
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "paginate|appends"
54:        $documentRequests = $query->paginate(20)->appends($request->all());
```

### F10 — Views

clean. Both blades belong to this controller and were read in full.
- No queries in Blade: the only `request(...)` calls are the search-box value echoes; no `Model::`/`DB::`/`->where(` on a query builder. (`{{ request('search') }}` at `index.blade.php:20` is a helper read, not a query.)
- Relations used in `@foreach` are eager-loaded: `index()` eager-loads `student` and `guardian.user`; `show()` loads `student`, `guardian.user`, `createdBy`. The `student.full_name` used by the export resolver is a relation resolver owned by the export component.
- No `{!! !!}` anywhere; nothing dumps a whole row as JSON.
- Export gating: the view passes `'permission' => 'tenant.complaint.complaint.export'` (`index.blade.php:72`); the TenantCore `ExportController.php:44-45` enforces it with `Gate::authorize($exportData['permission'])` and the component checks `Gate::check($permission)` (`export-buttons.blade.php:304`). Gate present — clean.

### F11 — Security and tenancy

clean — no `env()` call, no hard-coded ids, no `?? 1`, no request body logged, no secrets. The only tenancy-relevant defect is in the **model** (missing `getMediaModel()`), recorded as a cross-cutting note in §7 because the model is owned elsewhere.

### F12 — Style

#### DOCR-09 · L · STY-02 — the file is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines between imports* |
| **Where** | `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php` (whole file) |
| **Root cause** | Three Pint rules fail: `concat_space` (line 88 `'...' . implode`), `method_chaining_indentation` (lines 109-110 and 37-41), `no_whitespace_in_blank_line` (lines 68, 108, 111). |
| **Consequence** | None for the user; the file drifts from the module's formatting baseline. |
| **Reproduce** | Static only — run Pint on the file (evidence below). |
| **Fix approach** | Run Pint on this file once (plan `DOCR-09`). |
| **Plan item** | DOCR-09 in `02-fix-plan.md` §8 |

```php
// DocumentRequestController.php:88 — the concat_space failure (space before '.')
            'status' => 'required|in:' . implode(',', [
// DocumentRequestController.php:108,111 — no_whitespace_in_blank_line (blank line with trailing spaces)
108:            
111:                
```

**Evidence**
```
$ vendor\bin\pint --test "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Complaint\\app\\Http\\Controllers\\DocumentRequestController.php","fixers":["concat_space","method_chaining_indentation","no_whitespace_in_blank_line"]}]}
```

#### DOCR-10 · L · STY-04 — a stale comment claims the export controller has no gate

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no commented-out code, no "temporary"/"debug" notes, no stale docblocks* |
| **Where** | `Modules/Complaint/resources/views/document-request/index.blade.php:58` |
| **Root cause** | The comment asserts `"ExportController has no Gate:: call"`. `Modules/TenantCore/app/Http/Controllers/ExportController.php:44-45` does call `Gate::authorize($exportData['permission'])`. The comment is now false and will mislead the next reader into "fixing" a gate that already exists. |
| **Consequence** | A future maintainer may duplicate or remove the working export gate based on a wrong comment. |
| **Reproduce** | Static only — read the comment and the controller it names. |
| **Fix approach** | Correct the comment to state that ExportController enforces the permission (plan `DOCR-10`). |
| **Plan item** | DOCR-10 in `02-fix-plan.md` §8 |

```php
// resources/views/document-request/index.blade.php:58 — CURRENT
                             ⚠ VIEW-SURFACE ONLY: ExportController has no Gate:: call.
```

**Evidence**
```
$ Read Modules/Complaint/resources/views/document-request/index.blade.php:58
58:                             ⚠ VIEW-SURFACE ONLY: ExportController has no Gate:: call.
$ Read Modules/TenantCore/app/Http/Controllers/ExportController.php:43-46
43:            // Authorize permission if specified
44:            if (! empty($exportData['permission'])) {
45:                Gate::authorize($exportData['permission']);
46:            }
```

### F13 — Deep read (answer all 8 questions for every mutating method)

Only `update()` mutates. `index()` and `show()` are reads.

| Mutating method | 1 wrong data | 2 delete before replacement | 3 duplicate impls | 4 soft-delete × unique | 5 race | 6 authz hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `update` | ok | **DOCR-03** | ok | ok | ok | ok | ok | ok |

Notes for the cells marked ok:
1. The write sets `status`, `fee_required`, `admin_notes`, `fulfilled_media_id` from the submitted form; it does not clear per-row overrides, so no unintended overwrite.
3. No second implementation of "update a document request" exists in this controller.
4. There is no create on this screen; the `request_number` and `payment_reference` unique indexes are not touched here.
5. No `count()`/`exists()`-then-write pattern.
6. All three routes sit behind auth + tenancy middleware and a `Gate::authorize`; there is no record-ownership model on this admin screen.
7. The flash `'Document request updated successfully.'` matches an actual write.
8. `fulfilled_media_id` is consumed by `ParentDocumentRequest::isDownloadable()` in the parent portal, so the stored value is used.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Models/ParentDocumentRequest.php` | The model uses `InteractsWithMedia` (line 23) but does **not** override `getMediaModel()`. `config('media-library.media_model')` resolves to `Modules\Prime\Models\Media`, which is pinned to `protected $connection = 'mysql'` (central `prime_db`, `Media.php:9`). So `addMediaFromRequest()` writes the media row to the CENTRAL `sys_media`, while `ppt_document_requests.fulfilled_media_id` has an FK to the TENANT `sys_media` (migration lines 47-48). Result: the stored id points at a row that does not exist in the tenant DB, and the follow-up `update(['fulfilled_media_id' => $media->id])` can raise FK 1452. This is the documented MDL-05/TEN-01 cross-tenant defect. ⚠ UNVERIFIED (the FK-1452 outcome) — what would settle it: run `update()` with an upload on a live tenant and read the SQL error. | MDL-05 / TEN-01 (B) | `tarun/ParentPortal-done/ParentDocumentController` (owner report) |
| `Modules/ParentPortal/app/Services/PptDropdownResolver.php` | `value()` calls `Dropdown::find($id)` on every invocation with no memoisation/cache, so the model's dropdown accessors are a per-call query (finding DOCR-02). Owned with the model's report. | QRY-12 (M) | `tarun/ParentPortal-done/ParentDocumentController` (owner report) |
| `Modules/TenantCore/app/Http/Controllers/ExportController.php` | Checked, no defect: it enforces the permission at lines 44-45. Recorded here only because this module's view wrongly claims it does not (DOCR-10). | — | — |

## 8. Not covered, and why

- **Browser rendering / live request behaviour** — this workflow is read-only and runs no tests (D4). The 500 in DOCR-01 is proven at the query layer against the live tenant DB, not by loading the page.
- **The media FK-failure in §7** — not exercised; only the mechanism (pinned central media model + missing override) is proven statically.
- **`ParentDocumentRequest` and `PptDropdownResolver` internals** — owned by `tarun/ParentPortal-done/ParentDocumentController`; linked, not re-audited. Only how this controller uses them is reported.
- **The scanner and self-check were skipped** because `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` do not exist (only `scan.php` and `00-RULEBOOK.md` are present) and the brief forbids running `scan.php`. The F1–F13 checklist was worked manually with read/grep plus the commands shown in each finding.
