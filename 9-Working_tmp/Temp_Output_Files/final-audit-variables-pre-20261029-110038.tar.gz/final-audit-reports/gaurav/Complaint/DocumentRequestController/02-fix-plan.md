# Fix Plan — Complaint / DocumentRequestController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/app/Models/ParentDocumentRequest.php` | owned by `tarun/ParentPortal-done/ParentDocumentController` |
| `Modules/ParentPortal/app/Services/PptDropdownResolver.php` | owned by `tarun/ParentPortal-done/ParentDocumentController` |
| `Modules/Complaint/routes/web.php` | shared route file |
| `config/permissionslist.php` | shared config; no new key is needed for this plan |
| `app/Helpers/activityLog.php` | shared helper; called, never edited |
| `Modules/TenantCore/**` | common module (export component / controller) |

## 1. Blockers reachable today

- [ ] **DOCR-01** · B · MDL-07 · `DocumentRequestController.php:26-32` — stop filtering on a column that does not exist; resolve the value to its `*_option_id`.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php`
  - **Before** (`DocumentRequestController.php:10`, the import anchor):
    ```php
    use Modules\ParentPortal\Models\ParentDocumentRequest;
    ```
  - **After** (import):
    ```php
    use Modules\ParentPortal\Models\ParentDocumentRequest;
    use Modules\ParentPortal\Services\PptDropdownResolver;
    ```
  - **Before** (`DocumentRequestController.php:26-32`):
    ```php
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('document_type')) {
            $query->where('document_type', $request->document_type);
        }
    ```
  - **After:**
    ```php
        if ($request->filled('status')) {
            $statusId = PptDropdownResolver::id('ppt_document_requests.status', (string) $request->status);
            $query->where('status_option_id', $statusId ?? 0);
        }

        if ($request->filled('document_type')) {
            $documentTypeId = PptDropdownResolver::id('ppt_document_requests.document_type', (string) $request->document_type);
            $query->where('document_type_option_id', $documentTypeId ?? 0);
        }
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "where\('status_option_id'|where\('document_type_option_id'" | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line }`
  - **Expect:** two lines — `where('status_option_id', ...)` and `where('document_type_option_id', ...)`.
  - **Effort:** S

- [ ] **DOCR-03** · B · TXN-03 (with TXN-01/TXN-04) · `DocumentRequestController.php:100-113` — store the new document before removing the old one, and run the write + audit in one transaction. *This one item also closes DOCR-04 (no transaction) and DOCR-05 (no audit row).*
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php`
  - **Before** (`DocumentRequestController.php:7`, the import anchor):
    ```php
    use App\Http\Controllers\Controller;
    ```
  - **After** (import):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Support\Facades\DB;
    ```
  - **Before** (`DocumentRequestController.php:100-113`):
    ```php
        $documentRequest->update([
            'status' => $request->status,
            'fee_required' => $request->fee_required ?? 0,
            'admin_notes' => $request->admin_notes,
        ]);

        if ($request->hasFile('document')) {
            $documentRequest->clearMediaCollection('fulfilled_documents');
            
            $media = $documentRequest->addMediaFromRequest('document')
                ->toMediaCollection('fulfilled_documents');
                
            $documentRequest->update(['fulfilled_media_id' => $media->id]);
        }
    ```
  - **After:**
    ```php
        $oldMediaId = $documentRequest->fulfilled_media_id;
        $fulfilledMediaId = $documentRequest->fulfilled_media_id;

        if ($request->hasFile('document')) {
            $media = $documentRequest->addMediaFromRequest('document')
                ->toMediaCollection('fulfilled_documents');

            $fulfilledMediaId = $media->id;
        }

        DB::transaction(function () use ($request, $documentRequest, $fulfilledMediaId) {
            $documentRequest->update([
                'status' => $request->status,
                'fee_required' => $request->fee_required ?? 0,
                'admin_notes' => $request->admin_notes,
                'fulfilled_media_id' => $fulfilledMediaId,
            ]);

            activityLog($documentRequest, 'Updated', [
                'message' => 'Document request updated.',
            ]);
        });

        if ($request->hasFile('document') && $oldMediaId && $oldMediaId !== $fulfilledMediaId) {
            $documentRequest->media()
                ->whereKey($oldMediaId)
                ->get()
                ->each->delete();
        }
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "clearMediaCollection|DB::transaction|activityLog"`
  - **Expect:** no `clearMediaCollection` line; one `DB::transaction(` line; one `activityLog(` line.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None. DOCR-01 and DOCR-03 are independent of each other and of the rest of the plan.

## 3. Errors & transactions (F1/F2)

None beyond DOCR-03 in §1 (it carries the transaction and the audit-log fix). F1 is clean — no try/catch exists.

## 4. Authorization (F3)

None. All three gates already use the correct existing permission (`tenant.complaint.complaint.*`).

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **DOCR-06** · M · VAL-02 · `DocumentRequestController.php:83-98` — move the inline validation into a Form Request.
  - **Touches:** `Modules/Complaint/app/Http/Requests/UpdateDocumentRequestRequest.php` (new file), `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php`
  - **New file** (`Modules/Complaint/app/Http/Requests/UpdateDocumentRequestRequest.php`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Http\Requests;

    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Modules\ParentPortal\Models\ParentDocumentRequest;

    class UpdateDocumentRequestRequest extends FormRequest
    {
        use AuthorizesTenantFeature;

        /**
         * The route is POST but the intent is an update, so the action is passed
         * explicitly — the trait's POST mapping would otherwise ask for `.create`.
         */
        public function authorize(): bool
        {
            return $this->authorizeByCrudPermission('tenant.complaint.complaint', 'update');
        }

        /**
         * @return array<string, string>
         */
        public function rules(): array
        {
            return [
                'status' => 'required|in:' . implode(',', [
                    ParentDocumentRequest::STATUS_PENDING,
                    ParentDocumentRequest::STATUS_PROCESSING,
                    ParentDocumentRequest::STATUS_READY,
                    ParentDocumentRequest::STATUS_COMPLETED,
                    ParentDocumentRequest::STATUS_REJECTED,
                ]),
                'fee_required' => 'nullable|numeric|min:0',
                'admin_notes' => 'nullable|string',
                'document' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
            ];
        }
    }
    ```
  - **Before** (`DocumentRequestController.php:8`, the import anchor):
    ```php
    use Illuminate\Http\Request;
    ```
  - **After** (import):
    ```php
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Modules\Complaint\Http\Requests\UpdateDocumentRequestRequest;
    ```
  - **Before** (`DocumentRequestController.php:83-98`):
    ```php
        public function update(Request $request, ParentDocumentRequest $documentRequest)
        {
            Gate::authorize('tenant.complaint.complaint.update');

            $request->validate([
                'status' => 'required|in:' . implode(',', [
                    ParentDocumentRequest::STATUS_PENDING,
                    ParentDocumentRequest::STATUS_PROCESSING,
                    ParentDocumentRequest::STATUS_READY,
                    ParentDocumentRequest::STATUS_COMPLETED,
                    ParentDocumentRequest::STATUS_REJECTED,
                ]),
                'fee_required' => 'nullable|numeric|min:0',
                'admin_notes' => 'nullable|string',
                'document' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
            ]);
    ```
  - **After:**
    ```php
        public function update(UpdateDocumentRequestRequest $request, ParentDocumentRequest $documentRequest): RedirectResponse
        {
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "->validate|UpdateDocumentRequestRequest"; php -l "Modules\Complaint\app\Http\Requests\UpdateDocumentRequestRequest.php"`
  - **Expect:** no `->validate` line; `UpdateDocumentRequestRequest` appears in the `use` line and the `update` signature; `No syntax errors detected` (and the trailing blank line after the method's `{` is removed by the fixer).
  - **Effort:** M
  - Note: the Form Request now carries the `.update` authorization, so the controller's `Gate::authorize('tenant.complaint.complaint.update');` line is removed (AUTH-04 — one check, not two). `$request->status` / `$request->fee_required` / `$request->admin_notes` continue to resolve because a Form Request is a Request; DOCR-03's After block is unaffected and stays valid whether or not DOCR-06 is ticked.

## 6. Queries & performance (F9)

- [ ] **DOCR-07** · L · QRY-13 · `DocumentRequestController.php:54` — page at the house size and append only the query string.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php`
  - **Before** (`DocumentRequestController.php:54`):
    ```php
            $documentRequests = $query->paginate(20)->appends($request->all());
    ```
  - **After:**
    ```php
            $documentRequests = $query->paginate(10)->withQueryString();
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "paginate\(" | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line }`
  - **Expect:** one line containing `paginate(10)->withQueryString()`.
  - **Effort:** S

## 7. Views (F10)

None. Both blades are clean; the only finding in `index.blade.php` is the stale comment handled as style in §8.

## 8. Style & controller shape (F12 / F6) — one item per file

- [ ] **DOCR-08** · L · CTL-04 · `DocumentRequestController.php:17,63` — add return types to `index` and `show` (`update`'s type is added by DOCR-06).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php`
  - **Before** (`DocumentRequestController.php:9`, the import anchor):
    ```php
    use Illuminate\Support\Facades\Gate;
    ```
  - **After** (import):
    ```php
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    ```
  - **Before** (`DocumentRequestController.php:17`):
    ```php
        public function index(Request $request)
    ```
  - **After:**
    ```php
        public function index(Request $request): View
    ```
  - **Before** (`DocumentRequestController.php:63`):
    ```php
        public function show(ParentDocumentRequest $documentRequest)
    ```
  - **After:**
    ```php
        public function show(ParentDocumentRequest $documentRequest): View
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" -Pattern "public function" | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line }`
  - **Expect:** `index(...): View` and `show(...): View`; `update(...): RedirectResponse` if DOCR-06 is ticked.
  - **Effort:** S

- [ ] **DOCR-09** · L · STY-02 · `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php` — run Pint on the file (fixers: `concat_space`, `method_chaining_indentation`, `no_whitespace_in_blank_line`).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DocumentRequestController.php`
  - **Before** (this is the Pint test, not a code paste — Pint computes the edits):
    ```
    $ vendor\bin\pint --test "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" --format agent
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Complaint\\app\\Http\\Controllers\\DocumentRequestController.php","fixers":["concat_space","method_chaining_indentation","no_whitespace_in_blank_line"]}]}
    ```
  - **After:** run `vendor\bin\pint "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" --format agent` (do not use `--dirty`). Apply this item **after** DOCR-01/DOCR-03/DOCR-06/DOCR-07 so Pint formats the final code.
  - **Verify:** `vendor\bin\pint --test "Modules\Complaint\app\Http\Controllers\DocumentRequestController.php" --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

- [ ] **DOCR-10** · L · STY-04 · `index.blade.php:58` — the comment claims the export controller has no gate; it does.
  - **Touches:** `Modules/Complaint/resources/views/document-request/index.blade.php`
  - **Before** (`index.blade.php:58`):
    ```blade
                                 ⚠ VIEW-SURFACE ONLY: ExportController has no Gate:: call.
    ```
  - **After:**
    ```blade
                                 ExportController DOES gate this (Gate::authorize($exportData['permission'])
                                 at Modules/TenantCore/app/Http/Controllers/ExportController.php:45); the component also Gate::check()s it.
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\resources\views\document-request\index.blade.php" -Pattern "no Gate"`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **DOCR-02** · H · DECISION · QRY-01 — the list renders one `sys_dropdown_table` query per accessor read per row (about 80 extra queries on a 20-row page).
  - **Why it is a decision:** the clean fix is to memoise `PptDropdownResolver::value()` — a class owned by `tarun/ParentPortal-done/ParentDocumentController` — or to pre-resolve the three columns and change the view; neither is a one-file change inside this controller.
  - (a) ⭐ Have the ParentPortal owner report memoise `PptDropdownResolver::value()` (a static, request-scoped cache keyed by dropdown id). One place fixes it for every consumer; no change here.
  - (b) Pre-resolve the three dropdown values for the current page in `index()` with a single `whereIn` query and pass a map to `index.blade.php`, replacing the `$req->document_type`/`urgency`/`status` reads. Touches this controller and its view.
  - (c) Accept as debt; record it as a known N+1 on the Document Requests list.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| none | Every finding has a plan item. DOCR-04 and DOCR-05 ride the DOCR-03 item; the `update` return type of DOCR-08 rides DOCR-06. |
