# Final Audit — Complaint / ComplaintCategoryController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php` (367 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | List tab: `http://test.localhost:8000/complaint/complaint-mgt?tab=category` (rendered by `ComplaintController@index`). This controller's own pages: `/complaint/complaint-categories/create`, `/complaint/complaint-categories/{id}/edit`, `/complaint/complaint-categories/{id}` (show), `/complaint/complaint-categories/trash/view`; mutations: `POST /complaint/complaint-categories` (store), `PUT /complaint/complaint-categories/{complaint_category}` (update), `DELETE .../{complaint_category}` (destroy), `GET .../{id}/restore`, `DELETE .../{id}/force-delete`, `POST .../{id}/toggle-status`. |
| Menu path | Support & Maintenance → Complaint (`glb_menus` id 297, route `complaint.complaint-mgt.index`, permission `tenant.complaint.complaint.viewAny`) → Category tab. |
| Who uses it | Roles that hold the permission: **Super Admin** (id 1) and **School Admin** (id 2) — both hold all 8 `tenant.complaint.complaint-category.*` abilities (measured in the tenant DB `sys_role_has_permissions_jnt`, 2026-10-17). |
| What a user does here | A school admin maintains the complaint-category tree: creates a category (name, code, required escalation-hour thresholds L1–L5, optional severity/priority dropdowns and escalation groups), edits it, toggles active/inactive, soft-deletes it into the trash, restores it, or permanently deletes it. Sub-categories are formed by setting a Parent Category. |
| Tables written | `cmp_complaint_categories` (INSERT/UPDATE/soft-DELETE), `sys_activity_logs` (INSERT via `activityLog()`). |
| Tables read | `cmp_complaint_categories`, `sys_dropdown_table` (Dropdown), `sch_entity_groups` (EntityGroup), `sch_departments` (Department). |
| Live data | Tenant DB `xyz_school_00000000000040008000_202627` @ `test.localhost`: `cmp_complaint_categories` **15 live, 0 trashed**. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready until the two data/audit defects are fixed. The single worst finding is `CCAT-18` (H): `forceDelete()` decides whether a category "has subcategories" with a query that cannot see **soft-deleted** children, but the table's `parent_id` foreign key is `ON DELETE CASCADE`, so permanently deleting a parent silently hard-deletes its trashed sub-tree — data that the trash screen exists to protect. The second-worst is `CCAT-03` (H): every create/update/delete writes **two** audit rows because the model's observers and the controller both call `activityLog()`. The rest is maintainability debt (six forbidden controller `try/catch` blocks per D1, a GET route that mutates, an unrouted `index()`, missing return types, unbounded dropdown queries, dead code, Pint failures). Rough effort: **M**, about half a day for one developer with the pre-written plan.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 3 | 7 | 9 | 2 | 19 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CCAT-01, CCAT-02 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | CCAT-03, CCAT-04 | F9 Queries/Perf | CCAT-14, CCAT-15 |
| F3 Authorization | CCAT-05, CCAT-06 | F10 Views | CCAT-16 |
| F4 Validation | CCAT-07 | F11 Security/Tenancy | clean |
| F5 Routes | CCAT-08, CCAT-09, CCAT-10 | F12 Style | CCAT-17 |
| F6 Controller shape | CCAT-11, CCAT-12 | F13 Deep read | CCAT-18, CCAT-19 |
| F7 Models | CCAT-13 | | |

Counts add up: F1(2) + F2(2) + F3(2) + F4(1) + F5(3) + F6(2) + F7(1) + F9(2) + F10(1) + F12(1) + F13(2) = 19. F8 and F11 are clean.

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php` | controller | 367 | this report | ✅ |
| 2 | `Modules/Complaint/app/Models/ComplaintCategory.php` | model | 182 | this report (Tarun override 2026-10-17) | ✅ |
| 3 | `Modules/Complaint/app/Http/Requests/ComplaintCategoryRequest.php` | FormRequest | 113 | this report | ✅ |
| 4 | `Modules/Complaint/app/Policies/ComplaintCategoryPolicy.php` | policy | 67 | this report | ✅ |
| 5 | `Modules/Complaint/resources/views/complaint/category/create.blade.php` | view | 170 | this report | ✅ |
| 6 | `Modules/Complaint/resources/views/complaint/category/edit.blade.php` | view | 173 | this report | ✅ |
| 7 | `Modules/Complaint/resources/views/complaint/category/trash.blade.php` | view | 70 | this report | ✅ |
| 8 | `Modules/Complaint/resources/views/complaint/category/show.blade.php` | view | 190 | this report | ✅ |
| 9 | `Modules/GlobalMaster/app/Models/Dropdown.php` | model | 141 | ↗ common (GlobalMaster — other module) | ↗ linked |
| 10 | `Modules/SchoolSetup/app/Models/EntityGroup.php` | model | — | ↗ common (SchoolSetup — other module) | ↗ linked |
| 11 | `Modules/SchoolSetup/app/Models/Department.php` | model | — | ↗ common (SchoolSetup — other module) | ↗ linked |
| 12 | `resources/views/components/backend/form/form-dropdown.blade.php` + `app/View/Components/Backend/Form/FormDropdown.php` | component | 40 / 78 | ↗ common (shared component) | ↗ linked |
| 13 | `resources/views/components/backend/form/status-switch.blade.php`, `table/action-trashed`, `tab/modal`, `tab/search-bar`, `components/breadcrum` | components | — | ↗ common | ↗ linked |
| 14 | `Modules/Complaint/resources/views/complaint/category/index.blade.php` | view | 355 | ↗ rendered by `ComplaintController@index` (out of scope) | ❌ not this controller |
| 15 | `Modules/Complaint/routes/web.php` | routes | — | ↗ shared route file (read only, never edited) | read-only |

No pre-applied files: `final-audit-reports/TimetableFoundation/PRE-APPLIED-2026-10-10.md` does not mention any file in this scope.

## 4. Routes

```
POST      complaint/complaint-categories                          complaint.complaint-categories.store
GET|HEAD  complaint/complaint-categories/create                   complaint.complaint-categories.create
GET|HEAD  complaint/complaint-categories/trash/view               complaint.complaint-categories.trashed
GET|HEAD  complaint/complaint-categories/{complaint_category}     complaint.complaint-categories.show
PUT|PATCH complaint/complaint-categories/{complaint_category}     complaint.complaint-categories.update
DELETE    complaint/complaint-categories/{complaint_category}     complaint.complaint-categories.destroy
GET|HEAD  complaint/complaint-categories/{complaint_category}/edit complaint.complaint-categories.edit
DELETE    complaint/complaint-categories/{id}/force-delete        complaint.complaint-categories.forceDelete
GET|HEAD  complaint/complaint-categories/{id}/restore             complaint.complaint-categories.restore
POST      complaint/complaint-categories/{id}/toggle-status       complaint.complaint-categories.toggleStatus
```

All 10 routes carry the tenant middleware stack (`web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:Complaint, Authenticate, EnsureEmailIsVerified`). The route name prefix `complaint.` comes from the module's `RouteServiceProvider`.

Unrouted public methods: **`index`** — `ComplaintCategoryController.php:22-27`. The list URL `complaint/complaint-categories` is registered to `ComplaintController@index` (`web.php:57`), and `Route::resource(...)->except(['index'])` (`web.php:58`) explicitly omits it. `ComplaintCategoryController@index` therefore has no route (see CCAT-09).

Note: `GET complaint/complaint-categories` (the closest URI) is 1 segment and `complaint/complaint-categories/trash/view` is 2 segments, so RTE-06 (custom route captured by `Route::resource`) is checked, **not present** — the custom trash/restore/forceDelete/toggle routes have distinct verb+path shapes that the resource cannot capture.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 22 | **no route** | `tenant.complaint.complaint-category.viewAny` | none | — | none | CCAT-09 |
| `create` | 33 | GET /complaint/complaint-categories/create | `tenant.complaint.complaint-category.create` | none | — | none | CCAT-14 |
| `store` | 62 | POST /complaint/complaint-categories | `tenant.complaint.complaint-category.create` | controller `DB::transaction` | `'Created'` | cmp_complaint_categories, sys_activity_logs | CCAT-01, CCAT-02, CCAT-03, CCAT-05 |
| `edit` | 96 | GET /complaint/complaint-categories/{complaint_category}/edit | `tenant.complaint.complaint-category.update` | none | — | none | CCAT-12, CCAT-14 |
| `update` | 120 | PUT/PATCH /complaint/complaint-categories/{complaint_category} | `tenant.complaint.complaint-category.update` | controller `DB::transaction` | `'Updated'` | cmp_complaint_categories, sys_activity_logs | CCAT-01, CCAT-02, CCAT-03, CCAT-05 |
| `destroy` | 169 | DELETE /complaint/complaint-categories/{complaint_category} | `tenant.complaint.complaint-category.delete` | controller `DB::transaction` | `'Deleted'` | cmp_complaint_categories, sys_activity_logs | CCAT-01, CCAT-02, CCAT-03, CCAT-19 |
| `trashed` | 206 | GET /complaint/complaint-categories/trash/view | `tenant.complaint.complaint-category.restore` | none | — | none | — |
| `restore` | 229 | GET /complaint/complaint-categories/{id}/restore | `tenant.complaint.complaint-category.restore` | controller `DB::transaction` | `'Restored'` | cmp_complaint_categories, sys_activity_logs | CCAT-01, CCAT-02, CCAT-08 |
| `forceDelete` | 263 | DELETE /complaint/complaint-categories/{id}/force-delete | `tenant.complaint.complaint-category.forceDelete` | controller `DB::transaction` | `'Force Deleted'` | cmp_complaint_categories, sys_activity_logs | CCAT-01, CCAT-02, CCAT-18 |
| `toggleStatus` | 306 | POST /complaint/complaint-categories/{id}/toggle-status | `tenant.complaint.complaint-category.update` | controller `DB::transaction` | `'Toggled'` | cmp_complaint_categories, sys_activity_logs | CCAT-01, CCAT-02 |
| `show` | 345 | GET /complaint/complaint-categories/{complaint_category} | `tenant.complaint.complaint-category.view` | none | — | none | CCAT-11, CCAT-12, CCAT-16 |

## 6. Findings

### F1 — Errors

#### CCAT-01 · M · ERR-00 (D1) — Every mutation is wrapped in a forbidden controller `try/catch (\Throwable)`

| Field | Value |
|---|---|
| **Rule** | ERR-00 (raised to the project's settled D1 idiom: **no try/catch in controllers** unless a D2 shape applies — none applies here) |
| **Where** | `ComplaintCategoryController.php` methods `store` 68-90, `update` 127-162, `restore` 236-257, `forceDelete` 277-298, `toggleStatus` 316-341 (`destroy` 175-200 has the same defect; its catch is removed by CCAT-19) |
| **Root cause** | The controller hand-rolls the Laravel idiom instead of using it: `DB::transaction()` already rolls back and rethrows, and `bootstrap/app.php` already renders the friendly error page. The six `catch (\Throwable $e)` blocks exist only to convert a (mostly impossible) failure into a custom flash message. |
| **Consequence** | A genuine server error is hidden behind a generic red flash and a log line, so a failed save looks like a business rejection; the code is ~5 lines longer per method than it needs to be. |
| **Reproduce** | static only — the catches only fire on a DB failure, which a normal user cannot trigger. |
| **Fix approach** | Delete the `try { ... } catch (\Throwable $e) { ... }` wrapper from the five listed methods, keep the `DB::transaction(...)` body and the `redirect()`/`json()` after it (see plan §3, CCAT-01; `destroy` in CCAT-19). |
| **Plan item** | CCAT-01 in `02-fix-plan.md` §3 |

```php
// ComplaintCategoryController.php:68-90 — CURRENT (store; the same shape repeats in update/destroy/restore/forceDelete/toggleStatus)
try {
    DB::transaction(function () use ($data) {
        $category = ComplaintCategory::create($data);

        activityLog($category, 'Created', [
            'message' => 'Complaint category created.',
            'performed_by' => Auth::user()->name ?? null,
        ]);
    });

    return redirect()
        ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
        ->with('success', flash('created.complaint_category'));
} catch (\Throwable $e) {
    Log::error('Failed to create complaint category: ' . $e->getMessage(), [
        'exception' => get_class($e),
        'data' => $data,
    ]);

    return redirect()
        ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
        ->with('error', flash('operation_failed.complaint_category', 'Failed to create the complaint category.'));
}
```

**Evidence**
```
$ grep -n "catch (" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php
82:            Log::error('Failed to create complaint category: ' . $e->getMessage(), [
81:        } catch (\Throwable $e) {
154:            Log::error('Failed to update complaint category: ' . $e->getMessage(), [
153:        } catch (\Throwable $e) {
192:            Log::error('Failed to delete complaint category: ' . $e->getMessage(), [
191:        } catch (\Throwable $e) {
249:            Log::error('Failed to restore complaint category: ' . $e->getMessage(), [
248:        } catch (\Throwable $e) {
290:            Log::error('Failed to force delete complaint category: ' . $e->getMessage(), [
289:        } catch (\Throwable $e) {
332:            Log::error('Failed to toggle complaint category status: ' . $e->getMessage(), [
331:        } catch (\Throwable $e) {
```

#### CCAT-02 · L · ERR-05 — The catch logs only `$e->getMessage()` plus the class name, losing the stack trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M default; lowered to **L** because the message never reaches the user — the flash is fixed text — so the only damage is a harder-to-debug log) |
| **Where** | `ComplaintCategoryController.php` 82-85, 154-157, 192-195, 249-252, 290-293, 332-335 |
| **Root cause** | `Log::error('...' . $e->getMessage(), ['exception' => get_class($e)])` records the message and the class name, not the exception object, so the trace and previous-exception chain are lost. |
| **Consequence** | When a save fails in production, the log shows a one-line SQL-ish message with no file/line, so the failure cannot be located from the log. |
| **Reproduce** | static only — log inspection, not a browser action. |
| **Fix approach** | Removing the try/catch (CCAT-01) deletes these log calls and lets the central handler log the full exception. If any catch must remain, use `report($e)`. |
| **Plan item** | CCAT-01 in `02-fix-plan.md` §3 (same edit removes these lines) |

```php
// ComplaintCategoryController.php:82-85 — CURRENT
Log::error('Failed to create complaint category: ' . $e->getMessage(), [
    'exception' => get_class($e),
    'data' => $data,
]);
```

**Evidence**
```
$ grep -n "get_class(" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php
83:                'exception' => get_class($e),
156:                'exception' => get_class($e),
194:                'exception' => get_class($e),
251:                'exception' => get_class($e),
292:                'exception' => get_class($e),
334:                'exception' => get_class($e),
```

### F2 — Transactions and audit

#### CCAT-03 · H · TXN-04 — Every mutation writes two audit rows; `destroy` writes three

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M default; raised to **H** — the audit trail is duplicated with *conflicting event names*, which destroys its evidentiary value) plus F13 deep-read #3 (duplicate implementations) |
| **Where** | Model observers `ComplaintCategory.php:19-50` and controller `activityLog()` calls `store:72`, `update:143`, `destroy:183`, `restore:240`, `forceDelete:281`, `toggleStatus:321` |
| **Root cause** | Audit logging is implemented in **two layers**. The model's `booted()` hooks log `'Stored'`/`'Updated'`/`'Trashed'`; the controller logs `'Created'`/`'Updated'`/`'Deleted'`/`'Restored'`/`'Force Deleted'`/`'Toggled'`. Both run for the same write. `destroy()` additionally saves `is_active = false` before deleting (`:178-179`), which fires the model's `updated` hook, so a single delete produces **three** rows. |
| **Consequence** | The activity-log screen shows the same category change two or three times with different event words, so anyone auditing "who changed this category" cannot tell which row is authoritative. |
| **Reproduce** | Create (or edit, or delete) any category, then open the activity log and filter by `ComplaintCategory` — two rows appear per action. |
| **Fix approach** | Choose one logging layer and delete the other (DECISION — see plan §9 CCAT-03). |
| **Plan item** | CCAT-03 in `02-fix-plan.md` §9 (DECISION) |

```php
// ComplaintCategory.php:19-50 — CURRENT (the model half of the duplicate)
protected static function booted(): void
{
    static::created(function (self $category) {
        try {
            activityLog($category, 'Stored', [
                'message'      => 'Complaint category created.',
                'performed_by' => Auth::user()->name ?? null,
            ]);
        } catch (\Throwable $e) {
        }
    });

    static::updated(function (self $category) {
        try {
            activityLog($category, 'Updated', [
                'message'      => 'Complaint category updated.',
                'performed_by' => Auth::user()->name ?? null,
            ]);
        } catch (\Throwable $e) {
        }
    });

    static::deleted(function (self $category) {
        try {
            activityLog($category, 'Trashed', [
                'message'      => 'Complaint category deleted.',
                'performed_by' => Auth::user()->name ?? null,
            ]);
        } catch (\Throwable $e) {
        }
    });
}
```

**Evidence**
```
$ grep -n "activityLog" Modules/Complaint/app/Models/ComplaintCategory.php Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php
Modules/Complaint/app/Models/ComplaintCategory.php:23:                activityLog($category, 'Stored', [
Modules/Complaint/app/Models/ComplaintCategory.php:33:                activityLog($category, 'Updated', [
Modules/Complaint/app/Models/ComplaintCategory.php:43:                activityLog($category, 'Trashed', [
Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php:72:                activityLog($category, 'Created', [
Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php:143:                activityLog($category, 'Updated', [
Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php:183:                activityLog($category, 'Deleted', [
Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php:240:                activityLog($category, 'Restored', [
Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php:281:                activityLog($category, 'Force Deleted', [
Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php:321:                activityLog($category, 'Toggled', [

$ php probe: SELECT event, COUNT(*) c FROM sys_activity_logs WHERE subject_type = 'Modules\Complaint\Models\ComplaintCategory' GROUP BY event
(0 rows in the live tenant — the 15 existing categories carry no log rows, so the duplication is proven by the two call sites above, not by live data.)
```

#### CCAT-04 · M · ERR-06 — The model observers swallow audit failures in an empty `catch`

| Field | Value |
|---|---|
| **Rule** | ERR-06 (H default; lowered to **M** — the swallowed failure is confined to the audit row, the business write has already succeeded) |
| **Where** | `ComplaintCategory.php:22-28`, `31-38`, `41-48` |
| **Root cause** | Each observer wraps `activityLog()` in `try { ... } catch (\Throwable $e) { }` with an empty body, so any failure to write the audit row is silently discarded. |
| **Consequence** | If the audit write fails (constraint, connection), nothing is logged and no one is told — the audit trail silently drops entries. |
| **Reproduce** | static only — requires inducing an audit-write failure. |
| **Fix approach** | Removing the observers (CCAT-03 option a) removes the empty catches too. If the observers stay, replace the empty body with `report($e);`. |
| **Plan item** | CCAT-03 in `02-fix-plan.md` §9 (same edit) |

```php
// ComplaintCategory.php:21-29 — CURRENT
static::created(function (self $category) {
    try {
        activityLog($category, 'Stored', [
            'message'      => 'Complaint category created.',
            'performed_by' => Auth::user()->name ?? null,
        ]);
    } catch (\Throwable $e) {
    }
});
```

**Evidence**
```
$ grep -n "catch (\\\\Throwable" Modules/Complaint/app/Models/ComplaintCategory.php
27:            } catch (\Throwable $e) {
37:            } catch (\Throwable $e) {
47:            } catch (\Throwable $e) {
$ sed -n '28p;38p;48p' Modules/Complaint/app/Models/ComplaintCategory.php
            }
            }
            }
(each catch body is a single closing brace — nothing is logged or rethrown)
```

### F3 — Authorization

#### CCAT-05 · L · AUTH-04 — `store`/`update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — don't authorize the same permission at two levels |
| **Where** | `ComplaintCategoryRequest.php:16-22` (`authorize()` → `authorizeByCrudPermission('tenant.complaint.complaint-category')`) and controller `store:64`, `update:122` |
| **Root cause** | The FormRequest maps the HTTP verb to the same CRUD ability the controller then checks with `Gate::authorize()`. POST → `create`, PUT/PATCH → `update` — identical strings. |
| **Consequence** | The permission is evaluated twice per request; no security change, only a redundant check that must be kept in sync in two files. |
| **Reproduce** | static only — behaviour is identical with either check removed. |
| **Fix approach** | Keep the FormRequest `authorize()` (it runs first) and remove the matching `Gate::authorize()` only if the team accepts keeping one; otherwise keep both and record as accepted (see plan §4). |
| **Plan item** | CCAT-05 in `02-fix-plan.md` §4 |

```php
// ComplaintCategoryRequest.php:16-22 — CURRENT
public function authorize(): bool
{
    // T6b — mirrors the controller's own gate: tenant.complaint-category.create on POST,
    // tenant.complaint-category.update on PUT/PATCH. Same permission, checked one step
    // earlier, so this narrows nothing and widens nothing.
    return $this->authorizeByCrudPermission('tenant.complaint.complaint-category');
}
```

**Evidence**
```
$ grep -n "Gate::authorize('tenant.complaint.complaint-category.create')\|Gate::authorize('tenant.complaint.complaint-category.update')" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php
35:        Gate::authorize('tenant.complaint.complaint-category.create');
64:        Gate::authorize('tenant.complaint.complaint-category.create');
98:        Gate::authorize('tenant.complaint.complaint-category.update');
122:        Gate::authorize('tenant.complaint.complaint-category.update');
308:        Gate::authorize('tenant.complaint.complaint-category.update');
```

#### CCAT-06 · L · AUTH-06 — `ComplaintCategoryPolicy` is registered but nothing consults it

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M default; lowered to **L** — the permission strings still authorize correctly; the policy is redundant, not a hole) and the F3 rule "report every Policy that nothing consults" |
| **Where** | `Modules/Complaint/app/Policies/ComplaintCategoryPolicy.php` (whole file); registration `Modules/Complaint/app/Providers/ComplaintServiceProvider.php:61` |
| **Root cause** | `Gate::policy(ComplaintCategory::class, ComplaintCategoryPolicy::class)` is registered, but every check in the module — controller `Gate::authorize('…string')`, FormRequest, and every blade `@can`/`permission=` — passes a **permission string**, never `Gate::authorize('update', $category)`. A string ability never reaches the policy. |
| **Consequence** | The policy is dead code that duplicates the permission names; a future developer editing it would change nothing. |
| **Reproduce** | static only. `grep -rn "->authorize('.*', \$" Modules/Complaint` returns no policy call sites. |
| **Fix approach** | Either delete the policy and its registration, or convert the controller to model-based abilities. Deleting touches a shared provider file, so this is recorded as accepted, not planned. |
| **Plan item** | none — see `02-fix-plan.md` §10 (accepted) |

```php
// ComplaintCategoryPolicy.php:14-25 — CURRENT (never reached from any call site)
public function viewAny(User $user): bool
{
    return $user->can('tenant.complaint.complaint-category.viewAny');
}

public function view(User $user, ComplaintCategory $complaintCategory): bool
{
    return $user->can('tenant.complaint.complaint-category.view');
}
```

**Evidence**
```
$ grep -rn "Gate::authorize('[a-z.]*', \\|->authorize('[a-z.]*', \\$" Modules/Complaint --include=*.php
(no output — no controller authorizes against a model instance, so the policy is never consulted)

Permission existence / seeding (F3 main check — all 8 names present and granted):
$ probe: SELECT id,name FROM sys_permissions WHERE name LIKE 'tenant.complaint.complaint-category.%'
2359 create · 2360 view · 2361 viewAny · 2362 update · 2363 delete · 2364 restore · 2365 forceDelete · 2366 export
$ probe: roles holding them → Super Admin (1), School Admin (2) hold all 8.
```

**F3 remainder — clean.** Every routed method calls `Gate::authorize()` **before** it loads a record (create:35, store:64, edit:98, update:122, destroy:171, trashed:208, restore:231, forceDelete:265, toggleStatus:308, show:347 — each precedes its `findOrFail`). No `Gate::any(...)` without `abort`. All permission strings follow `tenant.complaint.<feature>.<action>` and exist in `config/permissionslist.php:857` (`'complaint.complaint-category' => array_merge($crud, ['export'])`) and are seeded.

### F4 — Validation

#### CCAT-07 · M · VAL-07 — `parent_id` is not checked against descendants, so a category can become its own ancestor

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M) — cross-field / business checks belong in the FormRequest's `after()`; here the cycle check is simply absent |
| **Where** | `ComplaintCategoryRequest.php:53-57` (`'parent_id' => ['nullable','exists:cmp_complaint_categories,id', $id ? 'not_in:'.$id : '']`) |
| **Root cause** | The only self-reference guard is `not_in:$id`, which blocks setting the category as its *own* parent but not as the child of one of its *descendants*. The `edit()` controller also excludes only `id != $id` from the parent list (`:101-103`), so the dropdown offers descendants. |
| **Consequence** | A user can build a parent chain that loops (`A → B → A`); the tree is then logically corrupt, and any future recursive walk (the unused `recursiveChildren()` scope at `ComplaintCategory.php:110-113`) would recurse forever. |
| **Reproduce** | Create category A, create child B with parent A, edit A and set Parent = B, save — the update is accepted. |
| **Fix approach** | Add an `after()` rule that rejects a `parent_id` that is a descendant of the record being edited (see plan §5, CCAT-07). |
| **Plan item** | CCAT-07 in `02-fix-plan.md` §5 |

```php
// ComplaintCategoryRequest.php:53-57 — CURRENT
'parent_id' => [
    'nullable',
    'exists:cmp_complaint_categories,id',
    $id ? 'not_in:' . $id : '',
],
```

**Evidence**
```
$ grep -n "not_in\|parent_id" Modules/Complaint/app/Http/Requests/ComplaintCategoryRequest.php
31:        $id = $this->route('complaint_category') ?? $this->route('id');
45:                return $query->where('parent_id', $this->input('parent_id'));
53:            'parent_id' => [
56:                $id ? 'not_in:' . $id : '',
```

**F4 remainder — clean.** Uniqueness mirrors the real indexes: `Rule::unique('cmp_complaint_categories','code')` vs the DB unique `idx_cat_code`; the name rule is scoped to `parent_id` vs the DB unique `idx_cat_parent_name (parent_id,name)`. Neither rule adds `whereNull('deleted_at')`, so both see trashed rows exactly as the DB unique index does — no soft-delete 500 (VAL-04 checked, not present). No uploads. `toggleStatus` uses inline `$request->validate(['is_active' => 'required|boolean'])`, which VAL-02 permits for a one-field AJAX toggle. `prepareForValidation` (`:106-112`) coerces the checkboxes to booleans correctly (the shared `status-switch` component emits the field only when checked).

### F5 — Routes

#### CCAT-08 · H · RTE-01 — Restoring a category is a state change over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — no state change over GET; GET has no CSRF protection and link prefetchers trigger it |
| **Where** | `Modules/Complaint/routes/web.php:60` → `GET complaint/complaint-categories/{id}/restore` → `restore()` 229-258 |
| **Root cause** | `restore()` writes (`$category->restore()` plus an audit row) but is registered with `Route::get(...)`. |
| **Consequence** | A browser prefetch, a crawler, or a crafted `<img src>` can un-delete a category with no CSRF token and no confirmation. |
| **Reproduce** | Open `/complaint/complaint-categories/{id}/restore` in a logged-in admin's browser — the row is restored on a plain GET. |
| **Fix approach** | Change the route method to `Route::post(...)` (one line in the route file). The shared restore button (`action-trashed.blade.php`) reads the route's own methods and already emits a `POST`+`@csrf` form for a non-GET route, so no component/blade change is needed. Because it edits a shared route file it is a `⚠ SHARED` item (see plan §1, CCAT-08). |
| **Plan item** | CCAT-08 in `02-fix-plan.md` §1 |

```php
// Modules/Complaint/routes/web.php:60 — CURRENT
Route::get('complaint-categories/{id}/restore', [ComplaintCategoryController::class, 'restore'])->name('complaint-categories.restore');
```

**Evidence**
```
$ grep -n "restore" Modules/Complaint/routes/web.php
60:Route::get('complaint-categories/{id}/restore', [ComplaintCategoryController::class, 'restore'])->name('complaint-categories.restore');

$ route probe: GET|HEAD  complaint/complaint-categories/{id}/restore   complaint.complaint-categories.restore   Modules\Complaint\Http\Controllers\ComplaintCategoryController@restore
```

#### CCAT-09 · M · RTE-03 (D5) — `index()` is unrouted

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — every public method is routed, or deliberately disabled per D5 |
| **Where** | `ComplaintCategoryController.php:22-27`; routes `web.php:57-58` |
| **Root cause** | The category list URL is served by `ComplaintController@index`, and the resource is registered `->except(['index'])`, so this class's `index()` (a `Gate::authorize` + redirect) is dead. |
| **Consequence** | Nobody can reach it; per D5 it must be turned into an explicit `abort(403, '…')` with a `NOT ROUTED` comment so the next reader knows it is disabled on purpose, not forgotten. |
| **Reproduce** | static only — no URL maps to this method. |
| **Fix approach** | Replace the body with `abort(403, 'This endpoint is not routed.')` + a `NOT ROUTED` comment (see plan §5, CCAT-09). |
| **Plan item** | CCAT-09 in `02-fix-plan.md` §5 |

```php
// ComplaintCategoryController.php:22-27 — CURRENT
public function index()
{
    Gate::authorize('tenant.complaint.complaint-category.viewAny');

    return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'category']);
}
```

**Evidence**
```
$ grep -n "complaint-categories" Modules/Complaint/routes/web.php
57: Route::get('complaint-categories', [ComplaintController::class, 'index'])->name('complaint-categories.index');
58: Route::resource('complaint-categories', ComplaintCategoryController::class)->except(['index'])->names('complaint-categories');
(no route points at ComplaintCategoryController@index)
```

#### CCAT-10 · L · CTL-03 (F5) — Route parameter `{complaint_category}` does not match the controller argument `$id`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M default; lowered to **L** — it works via positional binding, only route-model binding is lost) |
| **Where** | Routes `web.php:58` produce `{complaint_category}`; controller args `edit($id)`, `update(..., $id)`, `destroy($id)`, `show($id)` |
| **Root cause** | The resource parameter is left un-singularized-matched: `Route::resource` emits `{complaint_category}` but the methods take `$id` with no type-hint, so Laravel passes the value positionally instead of binding a model. |
| **Consequence** | No functional break (the code calls `findOrFail($id)` explicitly), but the record is loaded by hand, `withTrashed()` is not expressed on the binding, and a future rename of the parameter would silently unbind. |
| **Reproduce** | static only. |
| **Fix approach** | Type-hint the parameter (`edit(ComplaintCategory $complaintCategory)` and the matching `update`/`destroy`/`show` signatures) and drop the manual `findOrFail` — this changes four method signatures and their bodies, so it is deferred to the god-controller/refactor pass rather than applied here. |
| **Plan item** | none — see `02-fix-plan.md` §10 (deferred) |

```php
// ComplaintCategoryController.php:96-100 — CURRENT (edit; same shape in update/destroy/show)
public function edit($id)
{
    Gate::authorize('tenant.complaint.complaint-category.update');

    $category = ComplaintCategory::findOrFail($id);
```

**Evidence**
```
$ route probe (resource routes): GET|HEAD complaint/complaint-categories/{complaint_category}/edit   complaint.complaint-categories.edit   Modules\Complaint\Http\Controllers\ComplaintCategoryController@edit
$ grep -n "public function edit\|public function update\|public function destroy\|public function show" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php
96:    public function edit($id)
120:    public function update(ComplaintCategoryRequest $request, $id)
169:    public function destroy($id)
345:    public function show($id)
```

### F6 — Controller shape

#### CCAT-11 · L · CTL-04 — Public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — return types on public methods |
| **Where** | all 11 public methods, `ComplaintCategoryController.php` |
| **Root cause** | No method declares `: View`, `: RedirectResponse`, or `: JsonResponse`. |
| **Consequence** | Minor: editors and static tools cannot see the response type; the controller is inconsistent with the project's typed style. |
| **Reproduce** | static only. |
| **Fix approach** | Add the return types (see plan §8, CCAT-11). |
| **Plan item** | CCAT-11 in `02-fix-plan.md` §8 |

```php
// ComplaintCategoryController.php:22,33,62,96,120,169,206,229,263,306,345 — CURRENT signatures
public function index()
public function create()
public function store(ComplaintCategoryRequest $request)
public function edit($id)
public function update(ComplaintCategoryRequest $request, $id)
public function destroy($id)
public function trashed()
public function restore($id)
public function forceDelete($id)
public function toggleStatus(Request $request, $id)
public function show($id)
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+\(' Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php
(none of the 11 lines ends with a return type — each ends in ")" as shown above)
```

#### CCAT-12 · L · CTL-10 — Dead code: identical `show()` branches, unused `edit()` variables, commented-out blocks

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M default; lowered to **L** — none of it changes behaviour) plus CTL-08 (`request()` helper) |
| **Where** | `show()` `361-365` (both branches return the same view); `show()` `361` uses `request()->ajax()` instead of an injected `Request`; `edit()` `104-105` load `$severityLevels`/`$priorityScores` that the view never reads (the `form-dropdown` component loads by `key`, not `type`); commented-out blocks `create:38-47` and `destroy:177` |
| **Root cause** | The AJAX branch was written but both arms are identical; the two `Dropdown::where('type', …)` queries and the commented-out `DB::table('sys_dropdown_table')` blocks are leftovers. |
| **Consequence** | Confusing dead code; two pointless DB queries per edit page; the commented `dd`/dropdown blocks invite confusion. |
| **Reproduce** | static only. |
| **Fix approach** | Collapse `show()` to a single `return view(...)`, drop the unused `$severityLevels`/`$priorityScores`, and delete the commented blocks (see plan §8, CCAT-12). |
| **Plan item** | CCAT-12 in `02-fix-plan.md` §8 |

```php
// ComplaintCategoryController.php:361-365 — CURRENT
if (request()->ajax()) {
    return view('complaint::complaint.category.show', compact('category'));
}

return view('complaint::complaint.category.show', compact('category'));
```

**Evidence**
```
$ grep -n "ajax()\|severityLevels\|priorityScores" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php
104:        $severityLevels = Dropdown::where('type', 'SEVERITY_LEVEL')->get();
105:        $priorityScores = Dropdown::where('type', 'PRIORITY_SCORE')->get();
361:        if (request()->ajax()) {
$ probe: SELECT COUNT(*) FROM sys_dropdown_table WHERE type IN ('SEVERITY_LEVEL','PRIORITY_SCORE') → 0
(both edit() queries return empty; the view uses the form-dropdown component keyed 'cmp_complaint_categories.severity_level_id' instead)
```

### F7 — Models

#### CCAT-13 · L · MDL-04 — Relationship methods are not return-typed

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — relationship methods return-typed (`: BelongsTo`, `: HasMany`) |
| **Where** | `ComplaintCategory.php` 94, 102, 110, 118, 126, 131, 136, 141, 145, 150, 155, 160, 165, 170, 176 |
| **Root cause** | Every relation method returns the relation without a declared type. |
| **Consequence** | Minor: no compile-time clarity; inconsistent with the project standard. |
| **Reproduce** | static only. |
| **Fix approach** | Add the return types (see plan §8, CCAT-13). |
| **Plan item** | CCAT-13 in `02-fix-plan.md` §8 |

```php
// ComplaintCategory.php:94-97 — CURRENT (same for all 15 relations)
public function parent()
{
    return $this->belongsTo(self::class, 'parent_id');
}
```

**Evidence**
```
$ grep -nE 'public function (parent|children|recursiveChildren|severityLevel|priorityScore|complaints|departmentSlas|subCategoryComplaints|aiPredictedInsights|l[1-5]Group)\(' Modules/Complaint/app/Models/ComplaintCategory.php
(each line ends in "()" with no return type)

Relation resolution proven in tenant context (all resolve, no error):
parent BelongsTo · children HasMany · recursiveChildren HasMany · severityLevel BelongsTo Dropdown · priorityScore BelongsTo Dropdown · complaints HasMany Complaint · departmentSlas HasMany DepartmentSla · subCategoryComplaints HasMany Complaint · aiPredictedInsights HasMany AiInsight · l1Group..l5Group BelongsTo EntityGroup
```

**F7 remainder — clean.** `$fillable` declared (55-75), no sensitive fields. `$casts` cover both booleans (80-83); the table has no date/decimal/json columns beyond the timestamps. `$table = 'cmp_complaint_categories'` exists in migration `2026_06_15_154510_create_cmp_complaint_categories_table.php`. `SoftDeletes` is present and the table has `deleted_at` (migration `2026_06_18_100113_add_deleted_at_to_cmp_complaint_categories_table.php`). No `belongsToMany` pivot. No Spatie media on this model. `$timestamps` not disabled. Unused imports `HasFactory` (line 6) and `Department` (line 10) are noted under CCAT-17.

### F8 — Services and jobs

clean — this controller calls no service, job, event, mail or notification. `grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b' ComplaintCategoryController.php` → no output.

### F9 — Queries and performance

#### CCAT-14 · M · QRY-15 (QRY-03) — Unbounded full-table loads for the create/edit dropdowns, with no column selection

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — don't load every row of a table for a form; QRY-03 — select only the columns used |
| **Where** | `create()` `37`, `48`, `50`; `edit()` `101-106` |
| **Root cause** | `ComplaintCategory::whereNull('parent_id')->get()`, `EntityGroup::all()`, `Department::select('id','name')->get()` (and in `edit()`, two `Dropdown::where('type',…)->get()` whose results are unused) fetch whole tables with `SELECT *`. |
| **Consequence** | Every create/edit page load scans `sch_entity_groups` and all root categories with no limit; as tenant data grows the form gets slower, and the two `Dropdown` queries in `edit()` are pure waste (0 rows, unused). |
| **Reproduce** | Open `/complaint/complaint-categories/create` — the query log shows three unbounded `select *` queries. |
| **Fix approach** | Select only the columns the `<select>` needs (`get(['id','name'])`) and drop the unused `Dropdown` queries (see plan §6, CCAT-14). |
| **Plan item** | CCAT-14 in `02-fix-plan.md` §6 |

```php
// ComplaintCategoryController.php:37-50 — CURRENT (create)
$parentCategories = ComplaintCategory::whereNull('parent_id')->get();
$groups = EntityGroup::all();

$departments = Department::select('id', 'name')->get();
```

**Evidence**
```
$ grep -n "::all()\|->get()" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php
37:        $parentCategories = ComplaintCategory::whereNull('parent_id')->get();
48:        $groups = EntityGroup::all();
50:        $departments = Department::select('id', 'name')->get();
101:        $parentCategories = ComplaintCategory::whereNull('parent_id')
103:            ->get();
104:        $severityLevels = Dropdown::where('type', 'SEVERITY_LEVEL')->get();
105:        $priorityScores = Dropdown::where('type', 'PRIORITY_SCORE')->get();
106:        $groups = EntityGroup::all();
$ probe: entity groups count=8 departments count=14 (small today; grows with the tenant)
```

#### CCAT-15 · M · DECISION · F9 — Cache the dropdown/group/department lookups

| Field | Value |
|---|---|
| **Rule** | F9 (protocol §6) — dropdowns/settings re-queried on every request are a caching candidate; adding a cache is a DECISION |
| **Where** | `create()` 37/48/50; `edit()` 101-106 |
| **Root cause** | The same lists are rebuilt on every page load with no cache. |
| **Consequence** | Repeated identical queries; a candidate for a tenant-keyed cache once the data grows. |
| **Reproduce** | reload the create page twice — the same queries run each time. |
| **Fix approach** | DECISION — add a tenant-keyed cache for these lookups (see plan §9, CCAT-15). |
| **Plan item** | CCAT-15 in `02-fix-plan.md` §9 (DECISION) |

```php
// ComplaintCategoryController.php:37,48 — CURRENT
$parentCategories = ComplaintCategory::whereNull('parent_id')->get();
$groups = EntityGroup::all();
```

**Evidence**
```
$ probe (two page loads not run — static): the same three queries appear in create() and again in edit().
Tenant-scoped key required (TEN-02) if cached.
```

### F10 — Views

#### CCAT-16 · L · F13 / module-finalization `??`-on-missing-column — `show.blade.php` reads two columns that do not exist

| Field | Value |
|---|---|
| **Rule** | F13 deep-read + module-finalization "a `??` on a column that does not exist is silent forever" |
| **Where** | `show.blade.php` 55-62 and 72-79 (`$category->severity_label`, `$category->priority_label`) |
| **Root cause** | The view checks `isset($category->severity_label)` / `priority_label`, but the table has no such columns (`severity_level_id` / `priority_score_id` are the real columns); the real value is shown from `$category->severityLevel?->value`. |
| **Consequence** | The label-based colour branches never run, so the "high/critical" badge colouring silently never applies; a reader expects a `severity_label` field that no migration provides. |
| **Reproduce** | Open `/complaint/complaint-categories/{id}` — the severity badge is always the fallback `badge-secondary`/`badge-info` set from `severityLevel?->value`. |
| **Fix approach** | Remove the dead `severity_label`/`priority_label` branches, or replace them with a real column (see plan §7, CCAT-16). |
| **Plan item** | CCAT-16 in `02-fix-plan.md` §7 |

```php
// show.blade.php:55-62 — CURRENT
@if ($category->severityLevel || isset($category->severity_label))
    <span
        class="badge 
        @if (isset($category->severity_label) && in_array(strtolower($category->severity_label), ['high', 'critical', 'urgent'])) badge-danger
        @elseif(isset($category->severity_label) && in_array(strtolower($category->severity_label), ['medium', 'moderate'])) badge-warning
        @elseif(isset($category->severity_label) && in_array(strtolower($category->severity_label), ['low', 'minor'])) badge-info
        @else badge-secondary @endif">
        {{ $category->severityLevel?->value ?? ($category->severity_label ?? '-') }}
    </span>
@else
```

**Evidence**
```
$ grep -n "severity_label\|priority_label" Modules/Complaint/resources/views/complaint/category/show.blade.php
55,58,59,60,62,72,75,76,77,79
$ probe SHOW COLUMNS FROM cmp_complaint_categories → no severity_label / priority_label column
```

**F10 remainder:** create/edit/trash blades use no DB queries (VIEW-01 clean in this controller's own views). The row `@can`/`@canany` and `permission=` strings match the seeded permissions. `category/index.blade.php:126-127` repeats the same `severity_label`/`priority_label` dead read, but that file is rendered by `ComplaintController@index` and is a **cross-cutting note** (see §7).

### F11 — Security and tenancy

clean — no `env()` in the controller/model/request; no hard-coded ids or `?? 1`; no secrets logged; all routes inside the tenant + auth middleware group; no cache added without a tenant key. `grep -n "env(" ComplaintCategoryController.php ComplaintCategory.php ComplaintCategoryRequest.php` → no output.

### F12 — Style

#### CCAT-17 · L · STY-01 / STY-02 / STY-04 — Pint fails on all three files; no `strict_types`; commented-out code; unused imports

| Field | Value |
|---|---|
| **Rule** | STY-01 (L), STY-02 (L), STY-04 (L), STY-05 (L) — grouped as one plan item per file |
| **Where** | controller, model, FormRequest (all three), plus route-file mojibake is out of scope |
| **Root cause** | `vendor/bin/pint --test` reports failures for all three; none declares `declare(strict_types=1);`; the controller holds commented-out blocks (`38-47`, `destroy:177`) and the model imports `HasFactory` (line 6) and `Department` (line 10) without using them. |
| **Consequence** | Style inconsistency; unused imports confuse readers; Pint/CI noise. |
| **Reproduce** | run `vendor/bin/pint --test Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php --format agent`. |
| **Fix approach** | Run Pint on the three files and add the two missing pieces (see plan §8, CCAT-17). |
| **Plan item** | CCAT-17 in `02-fix-plan.md` §8 (one item per file) |

```php
// ComplaintCategoryController.php:1-3 — CURRENT (no strict_types)
<?php

namespace Modules\Complaint\Http\Controllers;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php Modules/Complaint/app/Models/ComplaintCategory.php Modules/Complaint/app/Http/Requests/ComplaintCategoryRequest.php --format agent
{"tool":"pint","result":"fail","files":[
 {"path":"Modules\\Complaint\\app\\Http\\Controllers\\ComplaintCategoryController.php","fixers":["class_attributes_separation","control_structure_braces","concat_space","trailing_comma_in_multiline","braces_position","ordered_imports"]},
 {"path":"Modules\\Complaint\\app\\Models\\ComplaintCategory.php","fixers":["class_attributes_separation","single_line_comment_spacing","no_unused_imports","no_extra_blank_lines","binary_operator_spaces"]},
 {"path":"Modules\\Complaint\\app\\Http\\Requests\\ComplaintCategoryRequest.php","fixers":["fully_qualified_strict_types","concat_space","ordered_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1. Wrong data overwrite | 2. Delete-before-store | 3. Duplicate implementation | 4. Soft-delete × unique | 5. Race | 6. Auth hole | 7. Message lies | 8. Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` (62) | ok | ok | CCAT-03 | ok | ok | ok | ok | ok |
| `update` (120) | ok | ok | CCAT-03 | ok | ok | ok | ok | ok |
| `destroy` (169) | CCAT-19 | ok | CCAT-03 | ok | ok | ok | ok | ok |
| `restore` (229) | ok | ok | CCAT-03 | ok | ok | CCAT-08 (GET) | ok | ok |
| `forceDelete` (263) | CCAT-18 | CCAT-18 | CCAT-03 | ok | ok | ok | CCAT-03 | ok |
| `toggleStatus` (306) | ok | ok | CCAT-03 | ok | ok | ok | ok | ok |

#### CCAT-18 · H · TXN-03 / F13 — `forceDelete()`'s child check cannot see soft-deleted children, which the FK cascade then hard-deletes

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B default — irreversible side effect; kept at **H** because it requires a deliberate force-delete, but it is silent data loss) + F13 deep-read #1/#2 |
| **Where** | `ComplaintCategoryController.php:267-275`; migration `2026_06_15_154510_create_cmp_complaint_categories_table.php:31` |
| **Root cause** | `ComplaintCategory::where('parent_id', $category->id)->exists()` applies the `SoftDeletes` global scope, so it only counts **live** children. The table's `parent_id` foreign key is `ON DELETE CASCADE`, so the hard `DELETE` that `forceDelete()` issues removes **every** descendant row, live or trashed. |
| **Consequence** | An admin can permanently delete a parent that has only *trashed* sub-categories — believing the guard protected them — and the DB cascade silently destroys those trashed categories too, defeating the trash screen's purpose. |
| **Reproduce** | Soft-delete all children of a parent, open the trash, force-delete the parent — the trashed children disappear from the trash permanently. |
| **Fix approach** | Make the guard see trashed children (`withTrashed()->where('parent_id', …)->exists()`) and, when found, either block or cascade explicitly (see plan §1, CCAT-18). |
| **Plan item** | CCAT-18 in `02-fix-plan.md` §1 |

```php
// ComplaintCategoryController.php:267-275 — CURRENT
$category = ComplaintCategory::onlyTrashed()->findOrFail($id);

$hasChildren = ComplaintCategory::where('parent_id', $category->id)->exists();

if ($hasChildren) {
    return redirect()
        ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
        ->with('error', 'Cannot delete category having subcategories.');
}
```

**Evidence**
```
$ probe SHOW CREATE TABLE cmp_complaint_categories
CONSTRAINT `fk_cat_parent` FOREIGN KEY (`parent_id`) REFERENCES `cmp_complaint_categories` (`id`) ON DELETE CASCADE
$ grep -n "hasChildren" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php
269:        $hasChildren = ComplaintCategory::where('parent_id', $category->id)->exists();
(the default SoftDeletes scope excludes trashed children from this count)
```

#### CCAT-19 · M · F13 — `destroy()` has no child guard, so a parent with live children is soft-deleted and its subtree orphans

| Field | Value |
|---|---|
| **Rule** | F13 deep-read #1 (wrong data) — the counterpart guard exists in `forceDelete()` but not here |
| **Where** | `ComplaintCategoryController.php:169-201` |
| **Root cause** | `destroy()` deletes the category unconditionally; there is no check for live children, unlike `forceDelete()`. |
| **Consequence** | Soft-deleting a parent leaves its (still-live) children pointing at a hidden parent — the list shows the children with an empty Parent column until the parent is restored. |
| **Reproduce** | Create parent A and child B, delete A from the list — B still appears in the tab with Parent "-". |
| **Fix approach** | Block `destroy()` when live children exist (mirror the forceDelete guard), or cascade the soft-delete to children (see plan §1, CCAT-19). |
| **Plan item** | CCAT-19 in `02-fix-plan.md` §1 |

```php
// ComplaintCategoryController.php:173-181 — CURRENT
$category = ComplaintCategory::findOrFail($id);

try {
    DB::transaction(function () use ($category) {
        // optional: deactivate before delete
        $category->is_active = false;
        $category->save();

        $category->delete();
```

**Evidence**
```
$ grep -n "hasChildren\|delete()\|save()" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php
178:            $category->is_active = false;
179:            $category->save();
181:            $category->delete();
269:        $hasChildren = ComplaintCategory::where('parent_id', $category->id)->exists();
(destroy() runs no children check; forceDelete() at 269 does)
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Complaint/resources/views/complaint/category/index.blade.php:126-127` | Rendered by `ComplaintController@index`; it repeats the same `severity_label`/`priority_label` dead read as `show.blade.php` (columns that do not exist). | F13 | the owner report for `ComplaintController` |
| `Modules/GlobalMaster/app/Models/Dropdown.php` | Other-module model reached by this controller (severity/priority labels); relationship resolution verified, no defect recorded here. | — | GlobalMaster owner |
| `Modules/SchoolSetup/app/Models/EntityGroup.php`, `Department.php` | Other-module models used for dropdowns; no defect recorded here. | — | SchoolSetup owner |
| `resources/views/components/backend/form/form-dropdown.*` | Shared component that runs `Dropdown::where('key',…)` in its constructor for every render (un-memoised). Common component — not fixed by this workflow. | F9/SVC-05 | TenantCore / shared-UI owner |

## 8. Not covered, and why

- **Scanner + self-check skipped — the tooling is missing.** `final-audit-reports/_tools/scanfilter.py` and `final-audit-reports/_tools/selfcheck.py` do not exist on disk, and per Tarun's override `scan.php` must not be run. The F1–F13 checklist was therefore done manually with `read`/`grep` plus the route probe and DB probes. The §15 self-check could not be executed.
- **`category/index.blade.php`** (the category list/modal) is included by `ComplaintController@index` and fed by that controller's data (`$categories`, `$categoriesExport`, …); only its create **modal action** and row-action routes belong to this controller. Audited only for the shared permission strings and the dead `severity_label` read; the list query/filter/export logic is out of scope here.
- **Component internals** (`form-dropdown`, `status-switch`, `action-trashed`, `modal`, `search-bar`, `export-buttons`, layouts) are shared components — linked, not audited (§4.2).
- **Browser rendering** of `show()`'s fetch/modal JS was not exercised (D4 — no tests, no browser harness). The `show()` dead-branch and the dead `severity_label` branches are static findings.
- **Live duplication of audit rows** could not be shown as data: the tenant `sys_activity_logs` currently holds 0 rows for `ComplaintCategory`, so CCAT-03 is proven by the two call sites, not by captured rows.
- **`ensure-metadata` / queue jobs**: none involved.
