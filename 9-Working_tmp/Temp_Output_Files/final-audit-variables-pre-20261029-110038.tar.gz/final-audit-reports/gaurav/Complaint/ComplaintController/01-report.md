# Final Audit — Complaint / ComplaintController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php` (1,896 lines, 23 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

> **Instrument note (§8):** `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are
> MISSING, and `scan.php` must not be run (Tarun's tooling override). The F1–F13 checklist was done
> manually with `read`/`grep` plus the commands shown per finding. The scanner and self-check were
> therefore SKIPPED. Every quoted line was re-read from the file; every finding carries its own command.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/complaint/complaint-mgt` and `/complaint/complaints` (tabbed hub: dashboard, complaint-manage, category, sla, medical, actions, ai); `/complaint/complaint-mgt/create`; `/complaint/complaints/{id}/edit`; `/complaint/complaints/{id}`; `/complaint/complaints/trash/view`; `/complaint/complaints/manage` (shadowed — see CMP-12); `/complaint/get-table-data/{table}`; `/complaint/get-table-columns/{table}`; `/complaint/get-sections/{classId}`; `/complaint/complaints/ajax/*`; `/complaint/dashboard-data`; `/complaint/dashboard/donut/{severity-vs-department,department-vs-severity,department-status}`; API `GET/POST/PUT/DELETE /api/v1/complaints` |
| Menu path | ⚠ UNVERIFIED — `glb_menus` was not read in this pass. |
| Who uses it | ⚠ UNVERIFIED — the permission keys exist in `config/permissionslist.php` (lines 847–862) but the tenant `sys_role_has_permissions_jnt` seeding was not measured (tenant DB not queried). |
| What a user does here | Staff/School Admin lodge a complaint against a target (staff/vehicle/vendor/department), assign it, move it through its status lifecycle (Open → In-Progress → Resolved/Closed/Rejected), reopen a resolved one, browse the category / SLA / medical / action / AI tabs, and look at dashboard charts. It is the single page that drives the whole Complaint module. |
| Tables written | `cmp_complaints` (insert/update/soft-delete/restore/force-delete), `cmp_complaint_actions` (insert), `cmp_ai_insights` (via the `ComplaintSaved` listener), `sys_activity_logs` (via `activityLog()`), `sys_media` (media upload — but written to the CENTRAL DB, CMP-22). |
| Tables read | `cmp_complaints`, `cmp_complaint_categories`, `cmp_department_sla`, `cmp_medical_checks`, `cmp_ai_insights`, `sys_dropdown_table`, `sys_users`, `sys_roles`, `sch_departments`, `sch_designations`, `sch_classes`, `sch_class_sections`, `slb_entity_groups`, `std_students`, `std_guardians`, `std_student_guardian_jnt`, `std_student_academic_sessions`; **plus every allow-listed table via `getTableData`** (CMP-38). |
| Live data | ⚠ UNVERIFIED — the tenant DB was not reachable from this read-only session. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready**. It is a 1,896-line god controller that renders a working
but fragile Complaint hub, and several of its paths are broken today: the trash page is a copy-paste of
the Department-SLA trash view and reads a variable the controller never passes (CMP-34), the
`toggle-status` endpoint writes a column that does not exist (CMP-23), `reopen()` redirects to a route
name that does not exist so a successful reopen shows an error (CMP-13), and the `manage` route is
shadowed by the resource wildcard (CMP-12). The single worst finding is **CMP-23** (a plain POST 500 on
a normal admin action) — with **CMP-22** (every complaint media upload lands in the central DB) close
behind as a cross-tenant data-placement hole. Rough effort: **L** (3–5 days) once the split decision is
taken; the blockers alone are ~1 day.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 5 | 8 | 20 | 8 | 1 | 42 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CMP-01, CMP-02, CMP-03, CMP-04 | F8 Services/Jobs | CMP-27, CMP-28, CMP-29 |
| F2 Transactions/Audit | CMP-05, CMP-06, CMP-07 | F9 Queries/Perf | CMP-30, CMP-31, CMP-32, CMP-33 |
| F3 Authorization | CMP-08 | F10 Views | CMP-34, CMP-35, CMP-36, CMP-37 |
| F4 Validation | CMP-09, CMP-10 | F11 Security/Tenancy | CMP-38, CMP-39 |
| F5 Routes | CMP-11, CMP-12, CMP-13 | F12 Style | CMP-40, CMP-41 |
| F6 Controller shape | CMP-14, CMP-15, CMP-16, CMP-17, CMP-18, CMP-19, CMP-20, CMP-21 | F13 Deep read | table in F13 (no separate IDs) |
| F7 Models | CMP-22, CMP-23, CMP-24, CMP-25, CMP-26 | | |

Row total: 41 findings; plus 1 DECISION (CMP-14 god-controller split) = 42 entries.

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Complaint/app/Http/Controllers/ComplaintController.php` | controller | 1896 | this report | ✅ |
| 2 | `Modules/Complaint/app/Models/Complaint.php` | model | 370 | this report (Tarun override 2026-10-17) | ✅ |
| 3 | `Modules/Complaint/app/Models/ComplaintAction.php` | model | 101 | this report | ✅ |
| 4 | `Modules/Complaint/app/Models/AiInsight.php` | model | 69 | this report | ✅ |
| 5 | `Modules/Complaint/app/Services/ComplaintDashboardService.php` | service | 514 | this report | ✅ |
| 6 | `Modules/Complaint/app/Services/ComplaintAIInsightEngine.php` | service | 203 | this report | ✅ |
| 7 | `Modules/Complaint/app/Events/ComplaintSaved.php` | event | 19 | this report | ✅ |
| 8 | `Modules/Complaint/app/Listeners/ProcessComplaintAIInsights.php` | listener | 21 | this report | ✅ |
| 9 | `Modules/Complaint/app/Providers/EventServiceProvider.php` | provider | 33 | this report (verified listener wiring only) | ✅ |
| 10 | `Modules/Complaint/app/Models/ComplaintCategory.php` | model | 182 | ↗ [gaurav/Complaint/ComplaintCategoryController](../ComplaintCategoryController/01-report.md) | ↗ linked |
| 11 | `Modules/Complaint/app/Models/DepartmentSla.php` | model | 179 | ↗ [gaurav/Complaint/DepartmentSlaController](../DepartmentSlaController/01-report.md) | ↗ linked |
| 12 | `Modules/Complaint/app/Models/MedicalCheck.php` | model | 95 | ↗ [gaurav/Complaint/MedicalCheckController](../MedicalCheckController/01-report.md) | ↗ linked |
| 13 | `Modules/Complaint/resources/views/complaint/complaint/index.blade.php` | view | 182 | this report | ✅ |
| 14 | `Modules/Complaint/resources/views/complaint/complaint/create.blade.php` | view | 860 | this report | ✅ |
| 15 | `Modules/Complaint/resources/views/complaint/complaint/edit.blade.php` | view | 1382 | this report | ✅ |
| 16 | `Modules/Complaint/resources/views/complaint/complaint/show.blade.php` | view | 235 | this report | ✅ |
| 17 | `Modules/Complaint/resources/views/complaint/complaint/trash.blade.php` | view | 81 | this report | ✅ |
| 18 | `Modules/Complaint/resources/views/complaint/complaint-manage/index.blade.php` | view | 282 | this report | ✅ |

No in-scope file appears in a module `PRE-APPLIED-*.md`. `ComplaintCategory.php`, `DepartmentSla.php`
and `MedicalCheck.php` are owned by other reports and were not re-audited; this report checks only how
this controller uses them.

## 4. Routes

`php artisan route:clear; $env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --json | php ...routesprobe.php "Modules\Complaint\Http\Controllers\ComplaintController"` (middleware on every web line = `[web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:Complaint, Authenticate, EnsureEmailIsVerified]`; API lines = `[api, tenancy…, Authenticate:sanctum]`):

```
GET|HEAD  api/v1/complaints                                  api.complaint.index          @index
POST      api/v1/complaints                                  api.complaint.store          @store
GET|HEAD  api/v1/complaints/{complaint}                      api.complaint.show           @show
PUT|PATCH api/v1/complaints/{complaint}                      api.complaint.update         @update
DELETE    api/v1/complaints/{complaint}                      api.complaint.destroy        @destroy
GET|HEAD  complaint/ai-insights                              complaint.ai-insights.index  @index
GET|HEAD  complaint/complaint-actions                        complaint.complaint-actions.index @index
GET|HEAD  complaint/complaint-categories                     complaint.complaint-categories.index @index
GET|HEAD  complaint/complaint-mgt                            complaint.complaint-mgt.index @index
POST      complaint/complaint-mgt                            complaint.complaint-mgt.store @store
GET|HEAD  complaint/complaint-mgt/create                     complaint.complaint-mgt.create @create
GET|HEAD  complaint/complaint-mgt/{complaint_mgt}            complaint.complaint-mgt.show @show
PUT|PATCH complaint/complaint-mgt/{complaint_mgt}            complaint.complaint-mgt.update @update
DELETE    complaint/complaint-mgt/{complaint_mgt}            complaint.complaint-mgt.destroy @destroy
GET|HEAD  complaint/complaint-mgt/{complaint_mgt}/edit       complaint.complaint-mgt.edit @edit
GET|HEAD  complaint/complaints                               complaint.complaints.index   @index
POST      complaint/complaints                               complaint.complaints.store   @store
GET|HEAD  complaint/complaints/ajax/subcategories/{category} complaint.complaints.subCategories @getSubCategories
GET|HEAD  complaint/complaints/ajax/subcategory-meta/{category} complaint.complaints.categoryMeta @getCategoryMeta
GET|HEAD  complaint/complaints/ajax/users-by-role/{role}     complaint.complaints.usersByRole @usersByRole
GET|HEAD  complaint/complaints/create                        complaint.complaints.create  @create
GET|HEAD  complaint/complaints/manage                        complaint.complaints.manage  @manage
GET|HEAD  complaint/complaints/trash/view                    complaint.complaints.trashed @trashed
GET|HEAD  complaint/complaints/{complaint}                   complaint.complaints.show    @show
PUT|PATCH complaint/complaints/{complaint}                   complaint.complaints.update  @update
DELETE    complaint/complaints/{complaint}                   complaint.complaints.destroy @destroy
GET|HEAD  complaint/complaints/{complaint}/edit              complaint.complaints.edit    @edit
DELETE    complaint/complaints/{id}/force-delete             complaint.complaints.forceDelete @forceDelete
POST      complaint/complaints/{id}/reopen                   complaint.complaints.reopen  @reopen
GET|HEAD  complaint/complaints/{id}/restore                  complaint.complaints.restore @restore
POST      complaint/complaints/{id}/toggle-status            complaint.complaints.toggleStatus @toggleStatus
GET|HEAD  complaint/dashboard-data                           complaint.dashboard.data     @filter
GET|HEAD  complaint/dashboard/donut/department-status        complaint. (no name)         @departmentStatusDonut
GET|HEAD  complaint/dashboard/donut/department-vs-severity   complaint. (no name)         @departmentVsSeverityDonut
GET|HEAD  complaint/dashboard/donut/severity-vs-department   complaint. (no name)         @severityVsDepartmentDonut
GET|HEAD  complaint/department-sla                           complaint.department-sla.index @index
GET|HEAD  complaint/get-sections/{classId}                   complaint.getSectionsByClass @getSectionsByClass
GET|HEAD  complaint/get-table-columns/{table}                complaint.get-table-columns  @getTableColumns
GET|HEAD  complaint/get-table-data/{table}                   complaint.get-table-data     @getTableData
GET|HEAD  complaint/medical-checks                           complaint.medical-checks.index @index
```

Unrouted public methods: **none** — every `public function` is reachable from at least one of the three
resource registrations (`complaints`, `complaint-mgt`, `api.complaint`). The `__construct` is excluded.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 50 | GET complaint/{complaints,complaint-mgt,*-categories,department-sla,medical-checks,ai-insights,complaint-actions}; GET api/v1/complaints | `Gate::any([7 keys])` + `Gate::authorize('tenant.complaint.complaint.viewAny')` | none (read) | none | none (read) | CMP-04, CMP-08, CMP-15, CMP-18, CMP-30, CMP-33, CMP-35 |
| `create` | 232 | GET complaint/{complaints,complaint-mgt}/create | `tenant.complaint.complaint.create` | none (read) | none | none (read) | CMP-01, CMP-03, CMP-17 |
| `store` | 270 | POST complaint/{complaints,complaint-mgt}; POST api/v1/complaints | `tenant.complaint.complaint.create` | controller manual `beginTransaction` (320) | 'Created' (458, inside tx) | cmp_complaints, cmp_complaint_actions, sys_media, sys_activity_logs, cmp_ai_insights (listener) | CMP-01, CMP-03, CMP-04, CMP-05, CMP-06, CMP-07, CMP-09, CMP-10, CMP-15, CMP-17 |
| `show` | 485 | GET complaint/{complaints,complaint-mgt}/{id}; GET api/v1/complaints/{id} | `tenant.complaint.complaint.view` | none (read) | none | none (read) | CMP-04, CMP-16 |
| `edit` | 521 | GET complaint/{complaints,complaint-mgt}/{id}/edit | `tenant.complaint.complaint.update` | none (read) | none | none (read) | CMP-01, CMP-03, CMP-16, CMP-17 |
| `update` | 644 | PUT complaint/{complaints,complaint-mgt}/{id}; PUT api/v1/complaints/{id} | `tenant.complaint.complaint.update` | controller `DB::transaction` (740) | 'Updated' (808, inside tx) | cmp_complaints, cmp_complaint_actions, sys_media, sys_activity_logs, cmp_ai_insights (listener) | CMP-01, CMP-03, CMP-04, CMP-05, CMP-07, CMP-09, CMP-10, CMP-15, CMP-16, CMP-17 |
| `destroy` | 833 | DELETE complaint/{complaints,complaint-mgt}/{id}; DELETE api/v1/complaints/{id} | `tenant.complaint.complaint.delete` | controller `DB::transaction` (840) | 'Deleted' (858, inside tx) | cmp_complaints, cmp_complaint_actions, sys_activity_logs | CMP-01, CMP-03, CMP-04, CMP-16 |
| `trashed` | 879 | GET complaint/complaints/trash/view | `tenant.complaint.complaint.restore` | none (read) | none | none (read) | CMP-34 |
| `restore` | 897 | GET complaint/complaints/{id}/restore | `tenant.complaint.complaint.restore` | controller `DB::transaction` (904) | 'Restored' (907, inside tx) | cmp_complaints, sys_activity_logs | CMP-01, CMP-03, CMP-11, CMP-16 |
| `forceDelete` | 928 | DELETE complaint/complaints/{id}/force-delete | `tenant.complaint.complaint.forceDelete` | controller `DB::transaction` (935) | 'Force Deleted' (938, inside tx) | cmp_complaints, sys_activity_logs | CMP-01, CMP-03, CMP-16 |
| `reopen` | 959 | POST complaint/complaints/{id}/reopen | `tenant.complaint.complaint.update` | controller manual `beginTransaction` (987) | 'Reopened' (1015, inside tx) | cmp_complaints, cmp_complaint_actions, sys_activity_logs, cmp_ai_insights (listener) | CMP-01, CMP-03, CMP-06, CMP-07, CMP-13, CMP-16 |
| `toggleStatus` | 1037 | POST complaint/complaints/{id}/toggle-status | `tenant.complaint.complaint.update` | controller `DB::transaction` (1048) | 'Toggled' (1052, inside tx) | cmp_complaints | CMP-01, CMP-03, CMP-16, CMP-23 |
| `manage` | 1517 | GET complaint/complaints/manage | `tenant.complaint.complaint.manage` | none (read) | none | none (read) | CMP-12, CMP-16 |
| `getSectionsByClass` | 1537 | GET complaint/get-sections/{classId} | `tenant.complaint.complaint.viewAny` | none (read) | none | none (read) | CMP-38 |
| `getTableData` | 1550 | GET complaint/get-table-data/{table} | `tenant.complaint.complaint.viewAny` | none (read) | none | none (read) | CMP-15, CMP-20, CMP-32, CMP-38 |
| `getTableColumns` | 1705 | GET complaint/get-table-columns/{table} | `tenant.complaint.complaint.viewAny` | none (read) | none | none (read) | CMP-01, CMP-02, CMP-38 |
| `getSubCategories` | 1721 | GET complaint/complaints/ajax/subcategories/{category} | `tenant.complaint.complaint.viewAny` | none (read) | none | none (read) | — |
| `getCategoryMeta` | 1736 | GET complaint/complaints/ajax/subcategory-meta/{category} | `tenant.complaint.complaint.viewAny` | none (read) | none | none (read) | — |
| `usersByRole` | 1749 | GET complaint/complaints/ajax/users-by-role/{role} | `tenant.complaint.complaint.update` | none (read) | none | none (read) | — |
| `filter` | 1795 | GET complaint/dashboard-data | `tenant.complaint.complaint.viewAny` | none (read) | none | none (read) | CMP-10 |
| `severityVsDepartmentDonut` | 1824 | GET complaint/dashboard/donut/severity-vs-department | `tenant.complaint.complaint.viewAny` | none (read) | none | none (read) | CMP-09 |
| `departmentVsSeverityDonut` | 1849 | GET complaint/dashboard/donut/department-vs-severity | `tenant.complaint.complaint.viewAny` | none (read) | none | none (read) | CMP-09 |
| `departmentStatusDonut` | 1873 | GET complaint/dashboard/donut/department-status | `tenant.complaint.complaint.viewAny` | none (read) | none | none (read) | CMP-09 |

`logAction()` (private, line 1761) inserts `cmp_complaint_actions` and is always called inside a caller's
transaction. `activityLog()` is placed after the write in every mutating method (TXN-04 clean).

## 6. Findings

### F1 — Errors

#### CMP-01 · M · ERR-00 — try/catch blocks in a controller that D1 forbids

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M under D1) — *the Laravel idiom: no try/catch in controllers; `DB::transaction` rolls back and rethrows, `bootstrap/app.php` renders* |
| **Where** | `ComplaintController.php` methods `create` (243–254), `store` (322–479), `edit` (610–621), `update` (739–826), `destroy` (839–876), `restore` (903–925), `forceDelete` (934–956), `reopen` (988–1034), `toggleStatus` (1047–1072), `getTableColumns` (1710–1715); `getTableData` (1556–1566) and (1653–1662) |
| **Root cause** | The controller manages its own failure handling instead of letting the central exception handler render it. Seven of the blocks wrap writes and turn every `Throwable` into a flash/JSON error; no D2 shape applies (no truncate-then-rebuild, no `SnapshotProtectionException`). |
| **Consequence** | A genuine 500 on a complaint write is masked as "Please try again", so the failure is invisible in the UI and the operator has only a log line to work from. |
| **Reproduce** | Static only — the catch is reached whenever any statement inside the closure throws. |
| **Fix approach** | Delete the try/catch around the writes (D1); keep `findOrFail()` outside it; let `bootstrap/app.php` render. Keep only `report($e)` if a page-specific message is genuinely wanted, or move that to the service. |
| **Plan item** | CMP-01 in `02-fix-plan.md` §3 |

```php
// ComplaintController.php:322-334 — CURRENT (store, opening of the try)
        try {

            $statusId = DB::table('sys_dropdown_table')
                ->where('key', 'cmp_complaints.status_id')
                ->where('value', 'Open')
                ->first()
                    ?->id ?? 124; // Fallback to 124 if not found for safety

            $priorityScoreId = DB::table('sys_dropdown_table')
                ->where('key', 'cmp_complaint_categories.priority_score_id')
                ->where('value', 'Medium')
                ->first()
                    ?->id ?? 3; // Fallback to 3 if not found for safety
```

```php
// ComplaintController.php:468-479 — CURRENT (store, the matching catch)
        } catch (\Throwable $e) {
            DB::rollBack();

            Log::error('Failed to create complaint: ' . $e->getMessage(), [
                'ticket_no' => $ticketNo ?? null,
                'exception' => get_class($e),
            ]);

            return back()
                ->withInput()
                ->with('error', flash('operation_failed.complaint', 'Failed to create the complaint. Please try again.'));
        }
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "try \{|catch \("
322:        try {
468:        } catch (\Throwable $e) {
739:        try {
817:        } catch (\Throwable $e) {
839:        try {
867:        } catch (\Throwable $e) {
903:        try {
916:        } catch (\Throwable $e) {
934:        try {
947:        } catch (\Throwable $e) {
988:        try {
1025:        } catch (\Throwable $e) {
1047:        try {
1062:        } catch (\Throwable $e) {
```

#### CMP-02 · B · ERR-01 — `getTableColumns()` returns the raw exception text to the browser

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `ComplaintController.php:1710-1715`, method `getTableColumns()` |
| **Root cause** | The catch builds a JSON body from `$e->getMessage()`, so a schema error (e.g. a bad `{table}`) echoes the DB error verbatim. |
| **Consequence** | Any authenticated complaint user can read database driver error text (and probe the schema) from the browser. |
| **Reproduce** | `GET /complaint/get-table-columns/does_not_exist` → JSON `{"error":"<driver message>"}`. |
| **Fix approach** | Return a fixed message, or let the central handler render the failure; never include `$e->getMessage()`. |
| **Plan item** | CMP-02 in `02-fix-plan.md` §1 |

```php
// ComplaintController.php:1710-1715 — CURRENT
        try {
            $columns = DB::getSchemaBuilder()->getColumnListing($table);
            return response()->json($columns);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "getMessage"
253: \Log::error('Failed to fetch DB tables: ' . $e->getMessage());
471: Log::error('Failed to create complaint: ' . $e->getMessage(), [
620: \Log::error('Failed to fetch DB tables: ' . $e->getMessage());
818: Log::error('Failed to update complaint: ' . $e->getMessage(), [
868: Log::error('Failed to delete complaint: ' . $e->getMessage(), [
917: \Log::error('Failed to restore complaint: ' . $e->getMessage(), [
948: Log::error('Failed to force delete complaint: ' . $e->getMessage(), [
1028: Log::error('Failed to reopen complaint: ' . $e->getMessage(), [
1063: Log::error('Failed to toggle complaint status: ' . $e->getMessage(), [
1714: return response()->json(['error' => $e->getMessage()], 400);
```

#### CMP-03 · M · ERR-05 — nine catches log `getMessage()` instead of the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `ComplaintController.php:253, 471, 620, 818, 868, 917, 948, 1028, 1063` |
| **Root cause** | Every catch concatenates `$e->getMessage()` into the log line. Several also pass `'exception' => get_class($e)` (a class name, not the object), so the stack trace is never stored. |
| **Consequence** | When a complaint write fails in production the log has one line and no trace, so the root cause (which query, which row) is unrecoverable. |
| **Reproduce** | Static only — read the catch blocks. |
| **Fix approach** | Replace with `report($e);` (or pass the object under `'exception' => $e`). |
| **Plan item** | CMP-03 in `02-fix-plan.md` §3 |

```php
// ComplaintController.php:471-474 — CURRENT
            Log::error('Failed to create complaint: ' . $e->getMessage(), [
                'ticket_no' => $ticketNo ?? null,
                'exception' => get_class($e),
            ]);
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "getMessage"
471: Log::error('Failed to create complaint: ' . $e->getMessage(), [
818: Log::error('Failed to update complaint: ' . $e->getMessage(), [
868: Log::error('Failed to delete complaint: ' . $e->getMessage(), [
917: Log::error('Failed to restore complaint: ' . $e->getMessage(), [
948: Log::error('Failed to force delete complaint: ' . $e->getMessage(), [
1028: Log::error('Failed to reopen complaint: ' . $e->getMessage(), [
1063: Log::error('Failed to toggle complaint status: ' . $e->getMessage(), [
```

#### CMP-04 · M · ERR-04 — one method serves both the web form and the JSON API

| Field | Value |
|---|---|
| **Rule** | ERR-04 (M) — *JSON endpoints fail with JSON; form endpoints fail with a redirect; use `$request->expectsJson()` when one method serves both* |
| **Where** | `ComplaintController.php` `index` (returns `view()`), `show` (returns `view()`), `store` (returns `redirect()`), `update` (returns `redirect()`), `destroy` (returns `redirect()`), all mapped to `api.complaint.*` |
| **Root cause** | The API resource reuses the same controller methods as the web resource, but every method returns a web response (HTML view or 302 redirect) regardless of `expectsJson()`. |
| **Consequence** | `GET /api/v1/complaints` returns a full HTML page and `POST /api/v1/complaints` returns a 302 redirect, so an API client cannot consume them. |
| **Reproduce** | `curl /api/v1/complaints` (with a sanctum token) → HTML, not JSON. |
| **Fix approach** | Either point the API at `ComplaintMobileController` (which already returns `JsonResponse`) or split response shape on `$request->expectsJson()`. |
| **Plan item** | CMP-04 in `02-fix-plan.md` §3 |

```php
// ComplaintController.php:188-226 (index end) — CURRENT
        return view('complaint::complaint.index', compact(
            'categories',
            'categoriesExport',
            'complaintsExport',
            'slas',
            'slasExport',
            'medicalChecksExport',
            'medicalChecks',
            'checkTypes',
            'results',
            'complaints',
            'actions',
            'actionTypes',
            'actionUsers',
            'assignedUsers',
            'dashboard',
            'aiInsights',
            'sentimentLabels',
            'predictedCategories',
            'dateFrom',
            'dateTo',
            'dateLabel',
            'severityLevels',
            'priorityScores',
            'complaintStatuses',
            'parentCategories',
            'departments',
            'groups',
            'slaCategories',
            'slaDepartments',
            'designations',
            'roles',
            'users',
            'vehicles',
            'vendors',
            'medicalComplaints',
            'frustrationReport',
            'activeTab'
        ));
```

**Evidence**
```
$ php artisan route:list --json | php routesprobe.php "...ComplaintController"
GET|HEAD  api/v1/complaints   api.complaint.index   ...ComplaintController@index
POST      api/v1/complaints   api.complaint.store   ...ComplaintController@store
```

### F2 — Transactions and audit

#### CMP-05 · B · TXN-03 — notification and media deletion run inside the store() transaction

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B) — *no irreversible side effect inside a transaction or before the write succeeds: file deletes, mail, SMS, push, HTTP calls; do them after commit* |
| **Where** | `ComplaintController.php:422` (`Notification::send`), `445` (`clearMediaCollection`), and `745` (`clearMediaCollection` in `update`), all inside the DB transaction |
| **Root cause** | The transaction closure spans the notification and the media file deletion. `Notification::send()` here is synchronous (the notification is not queued), and the media deletion removes the old file immediately. |
| **Consequence** | If the complaint write fails and rolls back, the admins have already been emailed (or the old image already deleted), so the DB and the outside world disagree. |
| **Reproduce** | Static only — triggered by any rollback after line 422/445. |
| **Fix approach** | Move the notification and the media handling after the transaction commits (`DB::afterCommit()` or return from the closure and act on the result). |
| **Plan item** | CMP-05 in `02-fix-plan.md` §1 |

```php
// ComplaintController.php:418-422 — CURRENT
            event(new ComplaintSaved($complaint));

            //begin::Send Notification to Admin roles users
            $admins = User::role('Super Admin')->get();
            Notification::send($admins, new StudentPortalComplaintRegistered($complaint));
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "Notification::send|clearMediaCollection|event\(new ComplaintSaved"
418: event(new ComplaintSaved($complaint));
422: Notification::send($admins, new StudentPortalComplaintRegistered($complaint));
445: $complaint->clearMediaCollection('complaint_img');
745: $complaint->clearMediaCollection('complaint_img');
```

#### CMP-06 · M · TXN-02 — manual beginTransaction/commit/rollBack instead of the closure form

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`; never `return` between them* |
| **Where** | `ComplaintController.php:320, 463, 469` (`store`) and `987, 1020, 1026` (`reopen`) |
| **Root cause** | `store()` and `reopen()` open a transaction by hand and commit/roll back in separate branches. The other five mutating methods already use `DB::transaction()`, so the file uses two styles. |
| **Consequence** | Any early `return` or uncaught throw between `beginTransaction` and `commit` can leave an open transaction; the two endpoints behave differently on failure. |
| **Reproduce** | Static only — read `store()`/`reopen()`. |
| **Fix approach** | Convert both to `DB::transaction(function () { … })`; build the redirect after it returns. |
| **Plan item** | CMP-06 in `02-fix-plan.md` §3 |

```php
// ComplaintController.php:320-322 — CURRENT (store, transaction opened by hand)
        DB::beginTransaction();

        try {
```

```php
// ComplaintController.php:463-469 — CURRENT (store, commit then rollback in separate branches)
            DB::commit();

            return redirect()
                ->route('complaint.complaints.index', ['tab' => 'complaint-manage'])
                ->with('success', "Complaint Lodged. Ticket No: {$ticketNo}");
        } catch (\Throwable $e) {
            DB::rollBack();
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "beginTransaction|DB::commit|DB::rollBack"
320: DB::beginTransaction();
463: DB::commit();
469: DB::rollBack();
987: DB::beginTransaction();
1020: DB::commit();
1026: DB::rollBack();
```

#### CMP-07 · M · TXN-03 — `ComplaintSaved` event fires before the transaction commits

| Field | Value |
|---|---|
| **Rule** | TXN-03 (M) — *no side effect before the write succeeds; the event triggers a listener that writes `cmp_ai_insights`* |
| **Where** | `ComplaintController.php:418` (`store`), `752` (`update`), `996` (`reopen`) |
| **Root cause** | `event(new ComplaintSaved($complaint))` is called inside the transaction closure, i.e. before `commit()`. The listener (`ProcessComplaintAIInsights`) is registered (`Modules/Complaint/app/Providers/EventServiceProvider.php:17-19`) and runs synchronously. |
| **Consequence** | Any consumer added later that is queued or writes outside the transaction would observe a complaint that then rolls back; today the AI write shares the transaction so the effect is latent, not absent. |
| **Reproduce** | Static only — event sites vs `commit()` sites. |
| **Fix approach** | Dispatch the event after the transaction commits (move the three `event(...)` calls below the transaction/`commit`). |
| **Plan item** | CMP-07 in `02-fix-plan.md` §3 |

```php
// ComplaintController.php:418 (inside the store transaction; commit is at 463) — CURRENT
            event(new ComplaintSaved($complaint));
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "event\(new ComplaintSaved"
418: event(new ComplaintSaved($complaint));
752: event(new ComplaintSaved($complaint));
996: event(new ComplaintSaved($complaint));
# commit sites: 463 (store), end of DB::transaction (update), 1020 (reopen)
```

### F3 — Authorization

#### CMP-08 · M · AUTH-05 — `Gate::any([…])` is dead because line 99 requires one specific key

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — *no dead permission logic, e.g. `Gate::authorize(A)` followed by `Gate::any([A,B,C])`; the `any()` can never matter* |
| **Where** | `ComplaintController.php:52-60` (`Gate::any([7 tab keys]) || abort(403)`) then `99` (`Gate::authorize('tenant.complaint.complaint.viewAny')`) |
| **Root cause** | `index()` admits any of seven tab permissions at line 52, then unconditionally requires `tenant.complaint.complaint.viewAny` at line 99 before rendering. The second check is stricter and runs on every path. |
| **Consequence** | A user who holds only `tenant.complaint.complaint-category.viewAny` (a valid tab permission) passes the `any()` guard and is then 403'd a few lines later, so the category/SLA/medical/AI tabs are unreachable for the roles the `any()` was written for. |
| **Reproduce** | Grant a role only `tenant.complaint.complaint-category.viewAny` and open `/complaint/complaint-categories` → 403. |
| **Fix approach** | Decide the real rule: either keep `any()` and drop line 99, or keep line 99 and drop the `any()`. This is a behaviour change on a shared permission surface — flagged for the split decision; the safe immediate fix is to remove the redundant `any()` and keep the explicit per-tab checks. |
| **Plan item** | CMP-08 in `02-fix-plan.md` §4 |

```php
// ComplaintController.php:52-60 — CURRENT
        Gate::any([
            'tenant.complaint.complaint-dashboard.viewAny',
            'tenant.complaint.complaint-category.viewAny',
            'tenant.complaint.department-sla.viewAny',
            'tenant.complaint.complaint.viewAny',
            'tenant.complaint.medical-check.viewAny',
            'tenant.complaint.complaint-action.viewAny',
            'tenant.complaint.ai-insights.viewAny',
        ]) || abort(403);
```

```php
// ComplaintController.php:99 — CURRENT (runs on every path, after the any())
        Gate::authorize('tenant.complaint.complaint.viewAny');
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "Gate::any|Gate::authorize"
52:        Gate::any([
99:        Gate::authorize('tenant.complaint.complaint.viewAny');
234:       Gate::authorize('tenant.complaint.complaint.create');
```

### F4 — Validation and input

#### CMP-09 · M · VAL-02 — validation is inline in the controller, not in a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request; inline `validate()` is allowed only for a one-field AJAX toggle* |
| **Where** | `ComplaintController.php:296-317` (`store`), `659-695` (`update`), `1828-1832`/`1853-1857`/`1877-1881` (the three donut methods) |
| **Root cause** | The create/update rule arrays are hand-written in the controller (`update` even builds a conditional `$rules` array). None is a FormRequest, and no `ComplaintRequest` exists in the module. |
| **Consequence** | The 40+ complaint rules cannot be reused or tested, and the API/mobile paths validate differently against the same table. |
| **Reproduce** | Static only — read the two `validate()` calls. |
| **Fix approach** | Extract `StoreComplaintRequest` and `UpdateComplaintRequest` (rules and `authorize()` moved verbatim), type the donut methods' three-field validation inline is not allowed either — extract or accept as a documented exception. |
| **Plan item** | CMP-09 in `02-fix-plan.md` §5 |

```php
// ComplaintController.php:296-317 — CURRENT (store)
        $request->validate([
            'target_table_name' => 'nullable|string',
            'target_column' => 'nullable|string',
            'target_type_id' => 'required|exists:sys_dropdown_table,id',

            'complainant_type_id' => 'required|exists:sys_dropdown_table,id',
            'category_id' => 'required|exists:cmp_complaint_categories,id',
            'subcategory_id' => 'nullable|exists:cmp_complaint_categories,id',

            'severity_level_id' => 'required',
            'priority_score_id' => 'nullable',

            'title' => 'required|string|max:200',
            'description' => 'nullable|string',

            'location_details' => 'nullable|string|max:255',
            'incident_date' => 'nullable|date',

            'complainant_name' => 'nullable|string|max:150',
            'complainant_contact' => 'nullable|string|max:50',
            'complainant_user_id' => 'nullable',
        ]);
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "request->validate|->validate\("
296: $request->validate([
695: $validated = $request->validate($rules);
1828: $request->validate([
1853: $request->validate([
1877: $request->validate([
```

#### CMP-10 · H · VAL-05 — unvalidated fields are written to the model; `filter()` parses raw dates

| Field | Value |
|---|---|
| **Rule** | VAL-05 (H) — *every field is typed; write paths with no validation at all (e.g. `Carbon::parse($request->x)`) are H* |
| **Where** | `store`: `ticket_date` (376), `target_name` (388), `target_code` (389), `source_id` (407); `update`: `target_name` (716), `target_code` (719), `priority_score_id`; `filter()`: `Carbon::parse($request->from_date)` (1799), `Carbon::parse($request->to_date)` (1800) |
| **Root cause** | The `validate()` rules do not cover `target_name`, `target_code`, `ticket_date` or `source_id`, yet those request values are written straight into the `Complaint::create()`/`update()` payload. `filter()` has no `validate()` at all and feeds raw request strings into `Carbon::parse()`. |
| **Consequence** | A crafted POST can store an arbitrary `ticket_date`/`source_id`/`target_code`, and a `GET /complaint/dashboard-data?from_date=notadate` throws a 500 instead of a 422. |
| **Reproduce** | `GET /complaint/dashboard-data?from_date=x&to_date=y` → 500. |
| **Fix approach** | Add the missing keys to the FormRequest ruleset (nullable typed) and `Carbon::parse($validated['from_date'] ?? null)` with a default; validate the donut range too. |
| **Plan item** | CMP-10 in `02-fix-plan.md` §5 |

```php
// ComplaintController.php:1795-1804 — CURRENT (filter)
    public function filter(Request $request, ComplaintDashboardService $service)
    {
        Gate::authorize('tenant.complaint.complaint.viewAny');

        $from = Carbon::parse($request->from_date)->startOfDay();
        $to = Carbon::parse($request->to_date)->endOfDay();
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "target_name|target_code|ticket_date|Carbon::parse"
376: 'ticket_date' => $request->ticket_date ?: now(),
388: 'target_name' => $request->target_name,
389: 'target_code' => $request->target_code,
1799: $from = Carbon::parse($request->from_date)->startOfDay();
1800: $to = Carbon::parse($request->to_date)->endOfDay();
```

### F5 — Routes

#### CMP-11 · H · RTE-01 — a state change is exposed over GET (`restore`)

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Complaint/routes/web.php:113-116` → `ComplaintController::restore` |
| **Root cause** | The restore route is registered with `Route::get(...)`. Restoring a complaint writes `deleted_at = null`. |
| **Consequence** | A browser, crawler or prefetcher that follows the link restores a trashed complaint with no confirmation and no CSRF token. |
| **Reproduce** | `GET /complaint/complaints/1/restore` while logged in → the complaint is restored. |
| **Fix approach** | Change the verb to `POST` (or `PATCH`) and keep the route name; update the trash action component. **⚠ SHARED — route file.** |
| **Plan item** | CMP-11 in `02-fix-plan.md` §5 |

```php
// Modules/Complaint/routes/web.php:113-116 — CURRENT
Route::get(
    'complaints/{id}/restore',
    [ComplaintController::class, 'restore']
)->name('complaints.restore');
```

**Evidence**
```
$ php artisan route:list --json | php routesprobe.php "...ComplaintController"
GET|HEAD  complaint/complaints/{id}/restore   complaint.complaints.restore   ...ComplaintController@restore
```

#### CMP-12 · M · RTE-06 — `complaints/manage` is shadowed by the resource wildcard

| Field | Value |
|---|---|
| **Rule** | RTE-06 (M) — *custom routes sharing a prefix with `Route::resource` must be registered before it, else `/{id}` captures the path* |
| **Where** | `Modules/Complaint/routes/web.php:105-106` (`Route::resource('complaints', …)`) then `133-136` (`complaints/manage`) |
| **Root cause** | `Route::resource('complaints')` registers `GET complaints/{complaint}` before the custom `complaints/manage` route, so the wildcard matches first. |
| **Consequence** | `/complaint/complaints/manage` runs `show('manage')` → `findOrFail('manage')` → 404. The Manage-Complaint page is unreachable. |
| **Reproduce** | `GET /complaint/complaints/manage` → 404 (should be the manage page). |
| **Fix approach** | Move the `complaints/manage` route above `Route::resource('complaints', …)`. **⚠ SHARED — route file.** |
| **Plan item** | CMP-12 in `02-fix-plan.md` §5 |

```php
// Modules/Complaint/routes/web.php:105-136 — CURRENT
Route::resource('complaints', ComplaintController::class)
    ->names('complaints');

Route::get(
    'complaints/trash/view',
    [ComplaintController::class, 'trashed']
)->name('complaints.trashed');

Route::get(
    'complaints/{id}/restore',
    [ComplaintController::class, 'restore']
)->name('complaints.restore');

Route::delete(
    'complaints/{id}/force-delete',
    [ComplaintController::class, 'forceDelete']
)->name('complaints.forceDelete');

Route::post(
    'complaints/{id}/toggle-status',
    [ComplaintController::class, 'toggleStatus']
)->name('complaints.toggleStatus');

Route::post(
    'complaints/{id}/reopen',
    [ComplaintController::class, 'reopen']
)->name('complaints.reopen');

Route::get(
    'complaints/manage',
    [ComplaintController::class, 'manage']
)->name('complaints.manage');
```

**Evidence**
```
$ php routeprobe4.php   # matches /complaint/complaints/manage against the router's insertion order
1766: GET,HEAD complaint/complaints/{complaint}  =>  ...ComplaintController@show
1775: GET,HEAD complaint/complaints/manage       =>  ...ComplaintController@manage
FIRST MATCH /complaint/complaints/manage: complaint/complaints/{complaint}  =>  ...ComplaintController@show
```

#### CMP-13 · H · RTE-02 — `reopen()` redirects to a route name that does not exist

| Field | Value |
|---|---|
| **Rule** | RTE-02 (H) — *every route referenced by the code resolves; here the name `complaints.show` is referenced but never registered* |
| **Where** | `ComplaintController.php:1022-1024`, method `reopen()` |
| **Root cause** | The code calls `->route('complaints.show', $complaint->id)`. The registered name is `complaint.complaints.show` (and `complaint.complaint-mgt.show`); `complaints.show` does not exist. |
| **Consequence** | The reopen write commits (line 1020), then `route()` throws `RouteNotFoundException`, the catch returns `back()` with "Failed to reopen complaint" — a successful reopen is reported as a failure. |
| **Reproduce** | Reopen a resolved complaint → it is reopened in the DB but the screen shows an error. |
| **Fix approach** | Use `complaint.complaints.show`. |
| **Plan item** | CMP-13 in `02-fix-plan.md` §1 |

```php
// ComplaintController.php:1020-1024 — CURRENT
            DB::commit();

            return redirect()
                ->route('complaints.show', $complaint->id)
                ->with('success', 'Complaint reopened successfully.');
```

**Evidence**
```
$ php artisan route:list --json | php routesprobe.php "...ComplaintController"
GET|HEAD  complaint/complaints/{complaint}   complaint.complaints.show   ...ComplaintController@show
# no route named "complaints.show" exists in the listing above
```

### F6 — Controller shape

#### CMP-14 · M · CTL-01 — god controller (1,896 lines / 23 public methods) — SPLIT IS A DEFERRED DECISION

| Field | Value |
|---|---|
| **Rule** | CTL-01 (M, split deferred per D3) — *no god controllers; over 1,000 lines or 25 public methods → split by resource/responsibility; over 2,500 lines is H* |
| **Where** | `ComplaintController.php` (whole file) |
| **Root cause** | One class owns the tabbed hub, the complaint CRUD, the trash lifecycle, the AJAX table lookups, the dashboard service calls and the donut endpoints. 1,896 lines and 23 public methods. |
| **Consequence** | Every change to any Complaint screen risks every other screen; review and testing cost grows with each new tab. Not a crash — debt. |
| **Reproduce** | `php -l` + line count. |
| **Fix approach** | Split by responsibility (crud / trash-lifecycle / ajax-lookups / dashboard). Recorded as a DECISION; NOT applied in this pass (D3). |
| **Plan item** | CMP-14 in `02-fix-plan.md` §9 (DECISION) |

```php
// ComplaintController.php:36 — CURRENT
class ComplaintController extends Controller
{
```

**Evidence**
```
$ (Get-Content ComplaintController.php).Count
1896
$ (Select-String -Path ComplaintController.php -Pattern "public function").Count
24   # 23 routed methods + __construct
```

#### CMP-15 · H · CTL-02 — four methods exceed 150 lines, one exceeds 80

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — *method over 80 lines → extract; over 150 lines is H* |
| **Where** | `index` 50–227 (178), `store` 270–480 (211), `update` 644–827 (184), `getTableData` 1550–1703 (154); `edit` 521–639 (119) is the 80–150 case (M) |
| **Root cause** | The hub method inlines all tab data loading, and `store`/`update` inline the entire ticket/notification/action/media workflow. |
| **Consequence** | These methods are effectively four mini-applications; a change to any branch is unreviewable and untestable. |
| **Reproduce** | `Select-String -Pattern "public function"` and count between the anchors. |
| **Fix approach** | Extract the tab loaders (mostly already split into private `*Query` helpers) and move the store/update workflow into a `ComplaintService`. |
| **Plan item** | CMP-15 in `02-fix-plan.md` §6 |

```php
// ComplaintController.php:50-51 — CURRENT (index begins)
    public function index(Request $request)
    {
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "public function"
50: public function index(Request $request)
232: public function create()
270: public function store(Request $request)
485: public function show($id)
521: public function edit($id)
644: public function update(Request $request, $id)
833: public function destroy($id)
879: public function trashed()
897: public function restore($id)
928: public function forceDelete($id)
959: public function reopen(Request $request, $id)
1037: public function toggleStatus(Request $request, $id)
1517: public function manage($id)
1537: public function getSectionsByClass($classId)
1550: public function getTableData($table)
1705: public function getTableColumns($table)
1721: public function getSubCategories(ComplaintCategory $category)
1736: public function getCategoryMeta(ComplaintCategory $category)
1749: public function usersByRole($roleId)
1787: public function __construct(ComplaintDashboardService $dashboardService)
1795: public function filter(Request $request, ComplaintDashboardService $service)
1824: public function severityVsDepartmentDonut(Request $request)
1849: public function departmentVsSeverityDonut(Request $request)
1873: public function departmentStatusDonut(Request $request)
```

#### CMP-16 · M · CTL-03 — no route model binding (`$id` + `findOrFail`)

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Complaint $complaint)`), not `$id` + `findOrFail`* |
| **Where** | `show($id)` 485, `edit($id)` 521, `update($request,$id)` 644, `destroy($id)` 833, `restore($id)` 897, `forceDelete($id)` 928, `reopen($request,$id)` 959, `toggleStatus($request,$id)` 1037, `manage($id)` 1517 |
| **Root cause** | The routes declare `{complaint}` but every method takes `$id` and calls `findOrFail($id)` by hand. (`getSubCategories`/`getCategoryMeta` are the only two that bind.) |
| **Consequence** | Route-model binding, `withTrashed()` scope and 404 semantics are re-implemented per method, and the trash methods need the extra `onlyTrashed()` call each. |
| **Reproduce** | `php artisan route:list` shows `{complaint}`; the method signature is `$id`. |
| **Fix approach** | Inject `Complaint $complaint`; add `->withTrashed()` on the trash routes. |
| **Plan item** | CMP-16 in `02-fix-plan.md` §5 |

```php
// ComplaintController.php:485-498 — CURRENT
    public function show($id)
    {
        Gate::authorize('tenant.complaint.complaint.view');

        $complaint = Complaint::with([
            'category',
            'subCategory',
            'assignedRole',
            'assignedUser',
            'resolvedByRole',
            'resolvedByUser',
            'complainantUser',
            'creator',
        ])->findOrFail($id);
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "public function (show|edit|update|destroy)"
485:    public function show($id)
521:    public function edit($id)
644:    public function update(Request $request, $id)
833:    public function destroy($id)
```

#### CMP-17 · M · CTL-05 — copy-paste blocks (`SHOW TABLES`, complainant resolution, dropdowns)

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: dropdown loaders shared by create/edit, the same redirect string repeated, the same payload in store and update* |
| **Where** | `SHOW TABLES` loader duplicated at `243-254` (create), `610-621` (edit), `1556-1563` (getTableData); complainant-type resolution duplicated at `276-294` (store) and `703-714` (update); `getRecentCriticalTickets` duplicated between controller `1441` and service `104` |
| **Root cause** | Blocks were copied between methods instead of extracted. |
| **Consequence** | A fix to the table loader or the complainant fallback must be applied in three (or two) places, and one copy will be missed. |
| **Reproduce** | `Select-String -Pattern "SHOW TABLES"` shows three occurrences. |
| **Fix approach** | Extract a `listTenantTables()` helper and a `resolveComplainant()` helper; delete the controller's duplicate of `getRecentCriticalTickets`. |
| **Plan item** | CMP-17 in `02-fix-plan.md` §6 |

```php
// ComplaintController.php:243-254 — CURRENT (also at 610 and 1556)
        try {
            $rows = DB::select('SHOW TABLES');
            foreach ($rows as $row) {
                $tableName = array_values((array) $row)[0] ?? null;
                if (!$tableName) {
                    continue;
                }
                $tables[$tableName] = str_replace('_', ' ', $tableName);
            }
        } catch (\Exception $e) {
            \Log::error('Failed to fetch DB tables: ' . $e->getMessage());
        }
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "SHOW TABLES"
244: $rows = DB::select('SHOW TABLES');
611: $rows = DB::select('SHOW TABLES');
1557: $rows = DB::select('SHOW TABLES');
```

#### CMP-18 · M · CTL-07 — `compact()` of 28 variables in `index()`

| Field | Value |
|---|---|
| **Rule** | CTL-07 (M) — *no `compact()` of more than ~15 variables; build a view model / array* |
| **Where** | `ComplaintController.php:188-226`, method `index()` |
| **Root cause** | Every tab's view data is flattened into one 28-key `compact()` call. |
| **Consequence** | The view contract is unreadable; it is impossible to tell which view uses which key, so removing a key is unsafe. |
| **Reproduce** | Count the keys in the `compact()` call. |
| **Fix approach** | Pass a typed view-model object or one array per tab. |
| **Plan item** | CMP-18 in `02-fix-plan.md` §6 |

```php
// ComplaintController.php:188-226 — CURRENT
        return view('complaint::complaint.index', compact(
            'categories',
            'categoriesExport',
            'complaintsExport',
            'slas',
            'slasExport',
            'medicalChecksExport',
            'medicalChecks',
            'checkTypes',
            'results',
            'complaints',
            'actions',
            'actionTypes',
            'actionUsers',
            'assignedUsers',
            'dashboard',
            'aiInsights',
            'sentimentLabels',
            'predictedCategories',
            'dateFrom',
            'dateTo',
            'dateLabel',
            'severityLevels',
            'priorityScores',
            'complaintStatuses',
            'parentCategories',
            'departments',
            'groups',
            'slaCategories',
            'slaDepartments',
            'designations',
            'roles',
            'users',
            'vehicles',
            'vendors',
            'medicalComplaints',
            'frustrationReport',
            'activeTab'
        ));
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "compact\(" -Context 0,1
188: return view('complaint::complaint.index', compact(
# followed by 28 string arguments up to line 226
```

#### CMP-19 · M · CTL-10 — dead private methods, an unused variable, commented-out code

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: unused private methods, unused properties, commented-out blocks longer than 3 lines* |
| **Where** | `getRecentCriticalTickets()` 1441–1466 (never called — the call sites use `$this->dashboardService->getRecentCriticalTickets`), `getFilteredDashboardData()` 1810–1822 (never called), `$slasAll` 160 (assigned, never used), commented-out code at 22 (`// use …Dropdown;`) and 435 (`// 'action_type_id' => 157,`) |
| **Root cause** | Methods and variables were left behind after the logic moved into `ComplaintDashboardService` (comment at 1096–1108 explains the split). |
| **Consequence** | A future maintainer may "fix" a method that nothing runs, or reuse the wrong `getRecentCriticalTickets` (there are two different ones). |
| **Reproduce** | `Select-String -Pattern "getFilteredDashboardData"` shows only the definition. |
| **Fix approach** | Delete the two unused private methods and the `$slasAll` line; remove the two commented lines. |
| **Plan item** | CMP-19 in `02-fix-plan.md` §6 |

```php
// ComplaintController.php:1441-1442 — CURRENT (never called)
    private function getRecentCriticalTickets()
    {
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "getFilteredDashboardData|getRecentCriticalTickets|slasAll"
136: $dashboard['criticalTickets'] = $this->dashboardService->getRecentCriticalTickets($from, $to);
160: $slasAll = DepartmentSla::all();
1441: private function getRecentCriticalTickets()
1810: private function getFilteredDashboardData(?string $from = null, ?string $to = null): array
```

#### CMP-20 · L · CTL-08 — the `request()` helper is used instead of an injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods* |
| **Where** | `ComplaintController.php:69` (`request()->route()`), `1573-1575`, `1599`, `1622`, `1685-1697` (all in `getTableData`), `1711` (`getTableColumns` has no injected Request) |
| **Root cause** | `getTableData()` and `getTableColumns()` take `$table` only and reach for the global `request()`/`request()->query()`. |
| **Consequence** | The methods cannot be called with a constructed request in a test or from another caller. |
| **Reproduce** | `Select-String -Pattern "request\(\)"` outside method signatures. |
| **Fix approach** | Add `Request $request` to the two method signatures and use it. |
| **Plan item** | CMP-20 in `02-fix-plan.md` §8 |

```php
// ComplaintController.php:1684-1690 — CURRENT
        if ($table === 'sys_users') {
            if (request()->filled('user_type')) {
                $userType = strtoupper(request()->query('user_type'));
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "request\(\)->"
69:            $routeName = request()->route()?->getName();
1573:            $categoryId = request()->query('id');
1685:            if (request()->filled('user_type')) {
```

#### CMP-21 · L · CTL-04 — public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `ComplaintController.php` — all 23 public methods except the typed ones (only `__construct` is typed) |
| **Root cause** | Return types were never added. |
| **Consequence** | Static analysis and IDE navigation cannot tell a `View` method from a `JsonResponse` one. |
| **Reproduce** | `Select-String -Pattern "public function [a-zA-Z_]+\([^)]*\)(?!:)"`. |
| **Fix approach** | Add return types as each method is touched during the other fixes. |
| **Plan item** | CMP-21 in `02-fix-plan.md` §8 |

```php
// ComplaintController.php:232 — CURRENT
    public function create()
    {
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "public function"
232:    public function create()
485:    public function show($id)
# none of the public methods declares a return type except __construct
```

### F7 — Models

#### CMP-22 · B · MDL-05 — `Complaint` uses `InteractsWithMedia` with no `getMediaModel()` override (media goes to the CENTRAL DB)

| Field | Value |
|---|---|
| **Rule** | MDL-05 / TEN-01 (B) — *every model using Spatie `InteractsWithMedia` in tenant context overrides `getMediaModel()`, otherwise media rows go to the central DB (cross-tenant leak)* |
| **Where** | `Modules/Complaint/app/Models/Complaint.php:18-20` (uses `InteractsWithMedia`, no override); the media is written from `ComplaintController.php:447-449` and `744-747` |
| **Root cause** | `InteractsWithMedia::getMediaModel()` defaults to `config('media-library.media_model')`, which is the central `Modules\Prime\Models\Media` pinned to the `mysql` connection. `App\Models\TenantMedia` exists precisely to be returned here, and `Complaint` never returns it. |
| **Consequence** | Every `complaint_img` upload is written to the central database while its parent row lives in the tenant DB; the tenant's `sys_media` can hold a different row at the same id, so a later read can serve another module's file. |
| **Reproduce** | Static only — `getMediaModel` is defined nowhere in `Modules/Complaint`. |
| **Fix approach** | Add `public function getMediaModel(): string { return \App\Models\TenantMedia::class; }` to `Complaint` (and `MedicalCheck`, tracked in the MedicalCheck report). |
| **Plan item** | CMP-22 in `02-fix-plan.md` §1 |

```php
// Complaint.php:18-20 — CURRENT
class Complaint extends Model implements HasMedia
{
    use HasFactory, SoftDeletes, InteractsWithMedia;
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\**\*.php -Pattern "function getMediaModel"
# no output inside Modules\Complaint
$ Select-String -Path app\Models\TenantMedia.php -Pattern "function getMediaModel"
52:   public function getMediaModel(): string
```

#### CMP-23 · B · MDL-07 — `toggleStatus()` writes `is_active`, which is not a column on `cmp_complaints`

| Field | Value |
|---|---|
| **Rule** | MDL-07 (B) — *every model's `$table` exists in a migration; a write to a missing table/column 500s on first use* |
| **Where** | `ComplaintController.php:1049-1050`, method `toggleStatus()`; `cmp_complaints` migration `database/migrations/tenant/2026_06_15_154520_create_cmp_complaints_table.php` |
| **Root cause** | The method sets `$complaint->is_active = (bool) $request->is_active;` then `save()`. No `is_active` column exists on `cmp_complaints` in any migration (`is_active` appears only on `cmp_complaint_categories`, `cmp_department_sla`, `cmp_medical_checks`). Eloquent marks the attribute dirty and emits `UPDATE cmp_complaints SET is_active = ? …`. |
| **Consequence** | The toggle-status button fails every time with a caught 500 ("Failed to update complaint status"); the endpoint is permanently broken. |
| **Reproduce** | `POST /complaint/complaints/{id}/toggle-status` with `is_active=1` → JSON `{"status":false}` HTTP 500. |
| **Fix approach** | Either add the column (migration — a DECISION) or drop the toggle feature and the method. Discussed as a DECISION in the plan; the default recommendation is to remove the endpoint and its view button (no live consumer) — `is_active` timing is already answered by `status_id`/`actual_resolved_at`. |
| **Plan item** | CMP-23 in `02-fix-plan.md` §1 |

```php
// ComplaintController.php:1045-1050 — CURRENT
        $complaint = Complaint::withTrashed()->findOrFail($id);

        try {
            DB::transaction(function () use ($request, $complaint) {
                $complaint->is_active = (bool) $request->is_active;
                $complaint->save();
```

**Evidence**
```
$ Get-ChildItem database\migrations\tenant\* | Select-String -Pattern "cmp_complaints" | Where { $_.Line -match "is_active" }
# no output — is_active is not added to cmp_complaints by any migration
$ Select-String -Path ComplaintController.php -Pattern "is_active"
1042:            'is_active' => 'required|boolean',
1049:                $complaint->is_active = (bool) $request->is_active;
```

#### CMP-24 · M · MDL-01/07 — phantom `$fillable` columns and a broken polymorphic relation on `Complaint`

| Field | Value |
|---|---|
| **Rule** | MDL-01/MDL-07 (M) — *`$fillable` declared; every fillable column maps to a real column* |
| **Where** | `Modules/Complaint/app/Models/Complaint.php:44` (`'target_id'`), `75` (`'escalation_level'`), `177-180` (`target()` returns a scalar), `185-188` (`targetable()` uses the physical table name as the morph type) |
| **Root cause** | The migration's real columns are `target_selected_id` and `current_escalation_level`; `target_id` and `escalation_level` are fillable but do not exist. `targetable()` sets the morph type column to `target_table_name`, which stores physical table names (`sch_departments`), not model class names, so `morphTo()` resolves to a non-existent class. `target()` is documented as a relation but returns `$this->target_id`. |
| **Consequence** | Any future `create([...])`/`update()` using `target_id`/`escalation_level` silently drops the value, and any code that eager-loads `targetable` fatals. |
| **Reproduce** | Static only — compare the fillable list against the migration columns. |
| **Fix approach** | Remove the two phantom fillable keys; either delete `targetable()`/`target()` or correct the morph map/column. |
| **Plan item** | CMP-24 in `02-fix-plan.md` §5 |

```php
// Complaint.php:42-49 — CURRENT (phantom 'target_id' in $fillable)
        // Target
        'target_user_type_id',
        'target_id',
        'target_name',
        'target_table_name',
        'target_selected_id',
        'target_code',
        'target_type', // For standard MorphTo if needed
```

```php
// Complaint.php:177-188 — CURRENT (target() returns a scalar; targetable() uses a physical table name as the morph type)
    public function target()
    {
        return $this->target_id;
    }

    /**
     * Polymorphic relationship to any target model
     */
    public function targetable()
    {
        return $this->morphTo('targetable', 'target_table_name', 'target_id');
    }
```

**Evidence**
```
$ Select-String -Path database\migrations\tenant\2026_06_15_154520_create_cmp_complaints_table.php -Pattern "target_selected_id|current_escalation_level|target_id"
47:  $table->unsignedInteger('target_selected_id')->nullable();
32:  $table->unsignedTinyInteger('current_escalation_level')->default(0);
# there is no target_id and no escalation_level column
```

#### CMP-25 · L · MDL-04 — relationship methods are not return-typed

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`)* |
| **Where** | `Complaint.php` (all relations 151-290), `ComplaintAction.php` (56-100), `AiInsight.php` (49-68) |
| **Root cause** | No relation declares its return type. |
| **Consequence** | IDE/static analysis cannot verify the relation type; a wrong `belongsTo`/`hasMany` is only caught at runtime. |
| **Reproduce** | `Select-String -Pattern "public function [a-z]+\(\)$"` in the three models. |
| **Fix approach** | Add return types as the models are touched. |
| **Plan item** | CMP-25 in `02-fix-plan.md` §8 |

```php
// Complaint.php:151-154 — CURRENT
    public function complainantType()
    {
        return $this->belongsTo(Dropdown::class, 'complainant_type_id');
    }
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Models\Complaint.php -Pattern "public function [a-z]+\(\)"
151:    public function complainantType()
156:    public function complainantUser()
# none declares a return type
```

#### CMP-26 · L · MDL-02 — `$casts` gaps on `Complaint`/`AiInsight`

| Field | Value |
|---|---|
| **Rule** | MDL-02 (L) — *`$casts` for every boolean, date/datetime, decimal, json/array and enum column* |
| **Where** | `Complaint.php:92-102` (`incident_time` is a `time` column, not cast; `current_escalation_level` is an integer, not cast), `AiInsight.php:34-39` (fine), `ComplaintAction.php:35-37` |
| **Root cause** | Several typed columns have no cast. |
| **Consequence** | `incident_time` arrives as a raw string; `current_escalation_level` as a string on some drivers. |
| **Reproduce** | Compare the migration columns to the cast list. |
| **Fix approach** | Add the missing casts when the model is next touched. |
| **Plan item** | CMP-26 in `02-fix-plan.md` §8 |

```php
// Complaint.php:92-102 — CURRENT
    protected $casts = [
        'ticket_date' => 'date',
        'incident_date' => 'datetime',
        'resolution_due_at' => 'datetime',
        'actual_resolved_at' => 'datetime',
        'dept_specific_info' => 'array',
        'is_anonymous' => 'boolean',
        'is_escalated' => 'boolean',
        'is_medical_check_required' => 'boolean',
        'support_file' => 'boolean',
    ];
```

**Evidence**
```
$ Select-String -Path database\migrations\tenant\2026_06_15_154520_create_cmp_complaints_table.php -Pattern "incident_time|current_escalation_level"
27:  $table->time('incident_time')->nullable();
32:  $table->unsignedTinyInteger('current_escalation_level')->default(0);
# neither column is in Complaint::$casts
```

### F8 — Services and jobs

#### CMP-27 · H · QRY-01 — a query runs inside a loop in the dashboard heatmap service

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; eager-load, pre-fetch into a keyed collection, or aggregate in SQL* |
| **Where** | `Modules/Complaint/app/Services/ComplaintDashboardService.php:139-149` (the `foreach` over every complaint) calling `calculateCurrentEscalationLevel()` at `154-158`, which runs `DB::table('sys_dropdown_table')->where('id', $complaint->status_id)->value('value')` per row |
| **Root cause** | The status dropdown value is looked up individually for every complaint instead of being pre-loaded (`status` is not eager-loaded here, and the lookup is a fresh query). |
| **Consequence** | Loading the complaint dashboard with N complaints issues N+1 queries (one per complaint) plus the full-table load, so the hub page slows linearly with complaint volume. |
| **Reproduce** | Open `/complaint/complaint-mgt` and count queries in the query log for `getEscalationHeatmapData`. |
| **Fix approach** | Load the status dropdown map once (`pluck('value','id')`) before the loop and look up from the array; also eager-load `status`. |
| **Plan item** | CMP-27 in `02-fix-plan.md` §6 |

```php
// ComplaintDashboardService.php:139-158 — CURRENT
        foreach ($complaints as $complaint) {
            $level = $this->calculateCurrentEscalationLevel($complaint);

            if (!$level || !$complaint->category) {
                continue;
            }

            $categoryName = $complaint->category->name;
            $matrix[$categoryName][$level] =
                ($matrix[$categoryName][$level] ?? 0) + 1;
        }

        return $this->formatHeatmapSeries($matrix);
    }

    private function calculateCurrentEscalationLevel(Complaint $complaint): ?string
    {
        $status = DB::table('sys_dropdown_table')
            ->where('id', $complaint->status_id)
            ->value('value');
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Services\ComplaintDashboardService.php -Pattern "foreach|->where\('id'"
139:        foreach ($complaints as $complaint) {
156:        $status = DB::table('sys_dropdown_table')
157:            ->where('id', $complaint->status_id)
```

#### CMP-28 · M · SVC-04 — duplicate `getRecentCriticalTickets` implementation

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *one implementation per business operation; two copies that disagree are a bug source* |
| **Where** | `ComplaintController.php:1441-1466` (never called) vs `ComplaintDashboardService.php:104-129` (the one actually used) |
| **Root cause** | The logic moved into the service, but the controller copy was left behind. The controller copy has no date `whereBetween`, so the two would return different rows if the dead one were ever called. |
| **Consequence** | A maintainer who calls the controller's `getRecentCriticalTickets()` gets a different (unfiltered) list than the dashboard. |
| **Reproduce** | `Select-String -Pattern "getRecentCriticalTickets"`. |
| **Fix approach** | Delete the controller copy (same item as CMP-19). |
| **Plan item** | CMP-28 in `02-fix-plan.md` §6 |

```php
// ComplaintController.php:1441-1450 — CURRENT (duplicate, dead)
    private function getRecentCriticalTickets()
    {
        $now = now();

        return Complaint::with('category')
            ->whereNotNull('resolution_due_at')
            ->whereNull('actual_resolved_at')
            ->orderBy('resolution_due_at')
            ->limit(5)
            ->get()
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Services\ComplaintDashboardService.php -Pattern "function getRecentCriticalTickets"
104:    public function getRecentCriticalTickets(Carbon $from, Carbon $to)
$ Select-String -Path ComplaintController.php -Pattern "private function getRecentCriticalTickets"
1441:    private function getRecentCriticalTickets()
```

#### CMP-29 · L · JOB-04 — the AI-insight listener is not queued

| Field | Value |
|---|---|
| **Rule** | JOB-04 (L) — *listeners that do slow work (bulk writes, HTTP) `implements ShouldQueue`* |
| **Where** | `Modules/Complaint/app/Listeners/ProcessComplaintAIInsights.php:8`, driven by `event(new ComplaintSaved(...))` |
| **Root cause** | The listener runs synchronously inside the request; on every complaint create/update/reopen it runs `ComplaintAIInsightEngine::processComplaint()`, which does several queries and an `updateOrCreate`. It does not implement `ShouldQueue`. |
| **Consequence** | Every complaint save pays the AI-scoring cost in the request; a slow scorer delays the save response. |
| **Reproduce** | Static only — the listener has no `ShouldQueue`. |
| **Fix approach** | Have the listener implement `ShouldQueue` once a queue is part of the deploy (a DECISION-adjacent change; keep synchronous for now). |
| **Plan item** | CMP-29 in `02-fix-plan.md` §8 |

```php
// ProcessComplaintAIInsights.php:8-10 — CURRENT
class ProcessComplaintAIInsights
{
    protected ComplaintAIInsightEngine $engine;
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Listeners\ProcessComplaintAIInsights.php -Pattern "ShouldQueue|class "
8:class ProcessComplaintAIInsights
# no ShouldQueue
```

### F9 — Queries and performance

#### CMP-30 · M · QRY-15/QRY-02 — `index()` loads whole tables on every page load, whatever the tab

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *don't load every row of a big table for a form; `Model::get()` with no filter on a page* |
| **Where** | `ComplaintController.php:160` (`DepartmentSla::all()`), `173` (`ComplaintCategory::all()`), `175` (`EntityGroup::all()`), `178` (`Designation::all()`), `179` (`Role::all()`), `180` (`User::…->get()`), `181` (`Vehicle::all()`), `182` (`Vendor::all()`) |
| **Root cause** | The tabbed `index()` loads every dropdown source unconditionally, before the active tab is known, and `$slasAll` (160) is not even used. |
| **Consequence** | Opening any complaint tab loads eight full tables; as users/roles/designations grow the hub's first paint degrades for everyone. |
| **Reproduce** | Open `/complaint/complaints?tab=dashboard` and watch the query log. |
| **Fix approach** | Load each collection only inside the branch that renders the tab that uses it, and select only `id,name`. |
| **Plan item** | CMP-30 in `02-fix-plan.md` §6 |

```php
// ComplaintController.php:160 and 173-182 — CURRENT
        $slasAll = DepartmentSla::all();

        /* ================= COMPLAINT ACTIONS (NEW) ================= */
        [
            'actions' => $actions,
            'actionTypes' => $actionTypes,
            'actionUsers' => $actionUsers,
            'assignedUsers' => $assignedUsers,
        ] = $this->getComplaintActionsData($request, $activeTab);

        $aiInsights = $this->getAiInsights($request, $activeTab);

        $sentimentLabels = Dropdown::where('key', 'cmp_ai_insights.sentiment_label_id')->get();
        $predictedCategories = ComplaintCategory::all();

        $groups = EntityGroup::all();
        $slaCategories = ComplaintCategory::parents()->get();
        $slaDepartments = Department::select('id', 'name')->get();
        $designations = Designation::all();
        $roles = Role::all();
        $users = User::whereIn('user_type', ['EMPLOYEE', 'TEACHER', 'PRIME', 'SYSTEM'])->select('id', 'name')->get();
        $vehicles = class_exists(Vehicle::class) ? Vehicle::all() : collect();
        $vendors = class_exists(Vendor::class) ? Vendor::all() : collect();
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "::all\(\)"
160: $slasAll = DepartmentSla::all();
173: $predictedCategories = ComplaintCategory::all();
175: $groups = EntityGroup::all();
178: $designations = Designation::all();
179: $roles = Role::all();
181: $vehicles = class_exists(Vehicle::class) ? Vehicle::all() : collect();
182: $vendors = class_exists(Vendor::class) ? Vendor::all() : collect();
```

#### CMP-31 · M · QRY-12 — the same `User` list is queried twice in one request

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) — *identical queries repeated in one request → resolve once* |
| **Where** | `ComplaintController.php:1408` and `1409`, method `getComplaintActionsData()` |
| **Root cause** | `$actionUsers` and `$assignedUsers` are the identical `User::orderBy('name')->get(['id','name'])` query, run twice. |
| **Consequence** | Two identical full-user queries per Actions-tab load. |
| **Reproduce** | `Select-String -Pattern "User::orderBy"`. |
| **Fix approach** | Resolve once and reuse. |
| **Plan item** | CMP-31 in `02-fix-plan.md` §6 |

```php
// ComplaintController.php:1408-1409 — CURRENT
        $actionUsers = User::orderBy('name')->get(['id', 'name']);
        $assignedUsers = User::orderBy('name')->get(['id', 'name']);
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "User::orderBy"
1408: $actionUsers = User::orderBy('name')->get(['id', 'name']);
1409: $assignedUsers = User::orderBy('name')->get(['id', 'name']);
```

#### CMP-32 · M · QRY-11 — interpolated raw SQL table/column names in `getTableData`

| Field | Value |
|---|---|
| **Rule** | QRY-11 (M, downgraded from B) — *no interpolated raw SQL; QRY-11 is B by default, but here the table name is validated against `DB::select('SHOW TABLES')` at line 1568 before line 1654 is reached, so it is not injectable* |
| **Where** | `ComplaintController.php:1654` (`DB::select("SHOW COLUMNS FROM `$table`")`) and `1672/1682` (column names built into the select) |
| **Root cause** | Raw SQL is assembled by string interpolation rather than bindings. The allow-list check at 1568 mitigates it, but the pattern is fragile if the check ever moves. |
| **Consequence** | No exploit today (the string is allow-listed); a future refactor that removes the allow-list turns it into SQL injection. |
| **Reproduce** | Static only — see line 1654 in context with the guard at 1568. |
| **Fix approach** | Validate the table against `Schema::getTableListing()` once and keep the allow-list immediately above the interpolation, with a comment. |
| **Plan item** | CMP-32 in `02-fix-plan.md` §6 |

```php
// ComplaintController.php:1652-1654 — CURRENT
        if (!$nameColumn) {
            try {
                $columnMeta = DB::select("SHOW COLUMNS FROM `$table`");
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "SHOW COLUMNS"
1654:                $columnMeta = DB::select("SHOW COLUMNS FROM `$table`");
```

#### CMP-33 · M · QRY-05 — the service aggregates whole tables in PHP

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M) — *aggregate in SQL; `groupBy` + `selectRaw('count(*)')`, not `->get()->groupBy()`/`->sum()`/`->filter()` over a whole table* |
| **Where** | `ComplaintDashboardService.php:131-151` (`getEscalationHeatmapData` loads all complaints then groups in PHP), `265-293` (`getSentimentTrend` loads all insights then loops days in PHP), `436-513` (`getRepeatedTargetFrustration` loads all complaints then groups/filters/sorts in PHP) |
| **Root cause** | The service pulls every row in the date range and reduces it with collection methods. |
| **Consequence** | The dashboard's memory and time grow with the whole complaint history for the range, not with the page size. |
| **Reproduce** | Static only — `->get()` followed by `groupBy`/`where`/`sortBy` in the service. |
| **Fix approach** | Push the grouping/averaging into SQL (`groupBy` + `selectRaw`), or chunk the load. |
| **Plan item** | CMP-33 in `02-fix-plan.md` §6 |

```php
// ComplaintDashboardService.php:131-135 — CURRENT
    public function getEscalationHeatmapData(Carbon $from, Carbon $to): array
    {
        $complaints = Complaint::with('category')
            ->whereBetween('ticket_date', [$from, $to])
            ->get();
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Services\ComplaintDashboardService.php -Pattern "->get\(\)"
135:            ->get();          # getEscalationHeatmapData
274:            ->get()           # getSentimentTrend
447:            ->get();          # getRepeatedTargetFrustration
```

### F10 — Views

#### CMP-34 · B · VIEW-01 — the complaint trash view reads `$slas`, which the controller never passes (page-killer)

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (B) — *no undefined data in Blade; the view must receive what it iterates* |
| **Where** | `ComplaintController.php:879-895` (`trashed()` passes `compact('data')`) vs `Modules/Complaint/resources/views/complaint/complaint/trash.blade.php:32` (`@forelse($slas as $sla)`) and `:69` (`$slas->links()`) |
| **Root cause** | The view is a copy-paste of the Department-SLA trash view. The controller sends `data`; the view iterates `slas`. The title ("Trashed Department SLAs"), the `url="complaint.department-sla"` and the `restorePermission="tenant.complaint.department-sla.restore"` are all still Department-SLA. |
| **Consequence** | `/complaint/complaints/trash/view` throws "Undefined variable $slas" (500) instead of listing trashed complaints; and its restore/force-delete buttons carry Department-SLA permissions. |
| **Reproduce** | `GET /complaint/complaints/trash/view` → error. |
| **Fix approach** | Rewrite the view for complaints: iterate `$data`, pass complaint columns, title "Trashed Complaints", `url="complaints"`, `restorePermission="tenant.complaint.complaint.restore"`, `forceDeletePermission="tenant.complaint.complaint.forceDelete"`. |
| **Plan item** | CMP-34 in `02-fix-plan.md` §1 |

```php
// ComplaintController.php:894 — CURRENT
        return view('complaint::complaint.complaint.trash', compact('data'));
```

```blade
// trash.blade.php:32-69 — CURRENT
                                @forelse($slas as $sla)
                                    <tr>
                                        {{-- Complaint Category --}}
                                        <td>{{ $sla->category?->name ?? '-' }}</td>

                                        {{-- Complaint Sub Category --}}
                                        <td>{{ $sla->subCategory?->name ?? 'All Sub Categories' }}</td>

                                        {{-- Target Department --}}
                                        <td>{{ $sla->target_department_id ?? '-' }}</td>

                                        {{-- Expected Resolution --}}
                                        <td>{{ $sla->dept_expected_resolution_hours }} hrs</td>

                                        <td>
                                            <span class="badge bg-danger">Trashed</span>
                                        </td>
                                        @canany(['tenant.complaint.complaint.view', 'tenant.complaint.complaint.update', 'tenant.complaint.complaint.delete'])
                                        <td>
                                            <x-backend.table.action-trashed :id="$sla->id"
                                                url="complaint.department-sla"
                                                restorePermission="tenant.complaint.department-sla.restore"
                                                forceDeletePermission="tenant.complaint.department-sla.forceDelete"
                                            />
                                        </td>
                                        @endcanany
                                    </tr>
                                @empty
                                    <tr class="align-middle text-center">
                                        <td colspan="7">No Trashed Categories Found</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>

                        <div class="row d-flex justify-content-center align-items-center my-4 px-4">
                            <div class="col-sm-12">
                                {{ $slas->links() }}
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\resources\views\complaint\complaint\trash.blade.php -Pattern "slas|department-sla"
13: <x-backend.card.header title="Trashed Department SLAs" url="complaint.department-sla" />
32: @forelse($slas as $sla)
52: url="complaint.department-sla"
53: restorePermission="tenant.complaint.department-sla.restore"
69: {{ $slas->links() }}
$ Select-String -Path ComplaintController.php -Pattern "trash"
894: return view('complaint::complaint.complaint.trash', compact('data'));
```

#### CMP-35 · H · VIEW-01 — database queries run inside `@foreach` in two list views

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H) — *no queries in Blade, especially inside `@foreach`* |
| **Where** | `resources/views/complaint/complaint/index.blade.php:98-101` and `resources/views/complaint/complaint-manage/index.blade.php:209-212` and `:243` |
| **Root cause** | Each row looks up its priority/status dropdown value with a fresh `DB::table('sys_dropdown_table')` query inside the loop. |
| **Consequence** | Rendering the complaint list issues one query per row for priority and another for status — an N+1 that grows with the page and with every extra column. |
| **Reproduce** | Open `/complaint/complaints?tab=complaint-manage` and count `sys_dropdown_table` queries (≈10–20). |
| **Fix approach** | Resolve the dropdown value in the controller (the `priorityScore`/`status` relations are already eager-loaded in `complaintsQuery`) and pass it to the view; drop the inline `DB::`. |
| **Plan item** | CMP-35 in `02-fix-plan.md` §7 |

```php
// complaint/complaint/index.blade.php:98-101 — CURRENT
                            @php
                                $priority = DB::table('sys_dropdown_table')
                                    ->where('id', $complaint->priority_score_id)
                                    ->value('value');
                            @endphp
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\resources\views\complaint\complaint\index.blade.php -Pattern "DB::"
99: $priority = DB::table('sys_dropdown_table')
$ Select-String -Path Modules\Complaint\resources\views\complaint\complaint-manage\index.blade.php -Pattern "DB::"
210: $priority = DB::table('sys_dropdown_table')
243: ...{{ DB::table('sys_dropdown_table')->where('id', $complaint->status_id)->value('value') }}...
```

#### CMP-36 · H · VIEW-01 — `sla_remaining_seconds` is never defined; the SLA timer always shows "Breached"

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H) — *no query/attribute in Blade that resolves to nothing; a column that does not exist is silent forever* |
| **Where** | `resources/views/complaint/complaint/index.blade.php:116, 118-119` (`$complaint->sla_remaining_seconds`) |
| **Root cause** | `Complaint` has no `sla_remaining_seconds` attribute, accessor or `$appends` entry; the word appears nowhere else in the module. The view reads it as if it existed. |
| **Consequence** | The SLA timer column shows "Breached" for every complaint regardless of its real SLA state, and the countdown JS receives `data-seconds=""`. |
| **Reproduce** | Open `/complaint/complaints?tab=complaint-manage` and look at the SLA Remaining column. |
| **Fix approach** | Add a `getSlaRemainingSecondsAttribute()` accessor to `Complaint` (based on `resolution_due_at`), or remove the column from the view. |
| **Plan item** | CMP-36 in `02-fix-plan.md` §7 |

```php
// complaint/complaint/index.blade.php:114-122 — CURRENT
                        <td>
                            <span class="sla-timer text-warning fw-semibold"
                                data-seconds="{{ $complaint->sla_remaining_seconds }}" data-id="{{ $complaint->id }}">
                                <i class="fa fa-hourglass-half"></i>
                                @if ($complaint->sla_remaining_seconds > 0)
                                    {{ gmdate('H\h i\m s\s', $complaint->sla_remaining_seconds) }}
                                @else
                                    Breached
                                @endif
                            </span>
                        </td>
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\**\*.php -Pattern "sla_remaining_seconds|getSlaRemainingSeconds"
# no output — the attribute is defined nowhere
```

#### CMP-37 · L · VIEW-03 — `{!! !!}` on the complaint description

| Field | Value |
|---|---|
| **Rule** | VIEW-03 (L, downgraded from H) — *`{!! !!}` only for trusted HTML; the description is user text, but `Complaint` sanitizes it via `\App\Traits\SanitizesRichText` (`$sanitizable = ['description' => 'restricted']`), so it is not raw user HTML* |
| **Where** | `resources/views/complaint/complaint/edit.blade.php:150` and `resources/views/complaint/complaint/show.blade.php:160` |
| **Root cause** | The view renders `description` unescaped. The model's sanitizer reduces the risk, but the unescaped sink remains and depends on that trait running on every write path. |
| **Consequence** | Stored XSS only if a write path ever bypasses `SanitizesRichText`; today it is contained. |
| **Reproduce** | Static only — inspect the trait and the two `{!! !!}` sites. |
| **Fix approach** | Keep as-is while the sanitizer is the only writer, but add a comment linking the `{!! !!}` to `SanitizesRichText`. |
| **Plan item** | CMP-37 in `02-fix-plan.md` §8 |

```php
// complaint/complaint/edit.blade.php:150 — CURRENT
                                    {!! $complaint->description !!}
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\resources\views\complaint\complaint\edit.blade.php -Pattern "\{!!"
150: {!! $complaint->description !!}
$ Select-String -Path Modules\Complaint\app\Models\Complaint.php -Pattern "sanitizable"
23:    protected array $sanitizable = [
```

### F11 — Security and tenancy

#### CMP-38 · H · SEC-02 — `getTableData` exposes any allow-listed table, including PII

| Field | Value |
|---|---|
| **Rule** | SEC-02 (H) — *no personal data over-exposed; JSON endpoints return mapped arrays, not whole rows* |
| **Where** | `ComplaintController.php:1550-1703`, method `getTableData()`, gated only by `tenant.complaint.complaint.viewAny` |
| **Root cause** | The method accepts any table name that exists in the tenant DB (`SHOW TABLES` allow-list, 1557-1570) and returns rows from it, mapping `name`/`identity`/`contact` columns. For `std_students`, `std_guardians` and `sys_users` this returns names and mobile numbers to any user who holds only the read permission. |
| **Consequence** | A complaint-viewer can enumerate students, guardians and staff with contact numbers by calling `GET /complaint/get-table-data/std_guardians` — a data-access hole far wider than the complaint screen needs. |
| **Reproduce** | `GET /complaint/get-table-data/sys_users?user_type=parent` → JSON list of parents with `contact`. |
| **Fix approach** | Restrict the allowed tables to the small set the complaint forms actually target, and gate the lookup with the specific create/update permission rather than `viewAny`. |
| **Plan item** | CMP-38 in `02-fix-plan.md` §1 |

```php
// ComplaintController.php:1552-1570 — CURRENT
        Gate::authorize('tenant.complaint.complaint.viewAny');

        // Allow only real tables from current DB (prevents injection)
        $allowedTables = [];
        try {
            $rows = DB::select('SHOW TABLES');
            foreach ($rows as $row) {
                $tableName = array_values((array) $row)[0] ?? null;
                if ($tableName) {
                    $allowedTables[] = $tableName;
                }
            }
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to read tables'], 400);
        }

        if (!in_array($table, $allowedTables, true)) {
            return response()->json(['error' => 'Invalid table'], 400);
        }
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "table === 'std_guardians'|table === 'std_students'|table === 'sys_users'"
1598: if ($table === 'std_students') {
1621: if ($table === 'std_guardians') {
1684: if ($table === 'sys_users') {
```

#### CMP-39 · M · SEC-03 — hard-coded fallback ids (`?? 124`, `?? 3`)

| Field | Value |
|---|---|
| **Rule** | SEC-03 (M) — *no hard-coded ids or fallbacks such as `?? 1` for a user/tenant/status id* |
| **Where** | `ComplaintController.php:328` (`?? 124`) and `334` (`?? 3`) |
| **Root cause** | When the Open status / Medium priority dropdown lookup fails, the code silently falls back to a literal id measured on one database. |
| **Consequence** | On a tenant where id 124 is not "Open" the complaint is created in the wrong status with no error (or a foreign-key failure). |
| **Reproduce** | Static only — read lines 324-334. |
| **Fix approach** | Fail loudly (`firstOrFail()` / `\DomainException`) instead of falling back to a magic id. |
| **Plan item** | CMP-39 in `02-fix-plan.md` §2 |

```php
// ComplaintController.php:324-334 — CURRENT
            $statusId = DB::table('sys_dropdown_table')
                ->where('key', 'cmp_complaints.status_id')
                ->where('value', 'Open')
                ->first()
                    ?->id ?? 124; // Fallback to 124 if not found for safety

            $priorityScoreId = DB::table('sys_dropdown_table')
                ->where('key', 'cmp_complaint_categories.priority_score_id')
                ->where('value', 'Medium')
                ->first()
                    ?->id ?? 3; // Fallback to 3 if not found for safety
```

**Evidence**
```
$ Select-String -Path ComplaintController.php -Pattern "\?\? 124|\?\? 3"
328:                ?->id ?? 124; // Fallback to 124 if not found for safety
334:                    ?->id ?? 3; // Fallback to 3 if not found for safety
```

### F12 — Style

#### CMP-40 · L · STY-01 — no `declare(strict_types=1);` in any in-scope file

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files* |
| **Where** | `ComplaintController.php`, `Complaint.php`, `ComplaintAction.php`, `AiInsight.php`, `ComplaintDashboardService.php`, `ComplaintAIInsightEngine.php`, `ComplaintSaved.php`, `ProcessComplaintAIInsights.php` — all lack it |
| **Root cause** | Newer files were created without the declaration. |
| **Consequence** | Coercive typing hides type errors the strict mode would catch. |
| **Reproduce** | `Select-String -Pattern "strict_types"` → no output. |
| **Fix approach** | Add `declare(strict_types=1);` when each file is next touched. |
| **Plan item** | CMP-40 in `02-fix-plan.md` §8 |

```php
// ComplaintController.php:1-3 — CURRENT
<?php

namespace Modules\Complaint\Http\Controllers;
```

**Evidence**
```
$ Select-String -Path ComplaintController.php, Modules\Complaint\app\Services\ComplaintDashboardService.php -Pattern "declare\(strict_types"
# no output
```

#### CMP-41 · L · STY-02/STY-04 — Pint fails on the controller; commented-out code remains

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean*; STY-04 (L) — *no commented-out code* |
| **Where** | `ComplaintController.php` (Pint: `class_attributes_separation`, `ordered_imports`, `concat_space`, `not_operator_with_successor_space`, `blank_line_before_statement`, …); commented-out code at `22` (`// use Modules\GlobalMaster\Models\Dropdown;`) and `435` (`// 'action_type_id' => 157,`) |
| **Root cause** | The file was not run through Pint, and two commented lines were left in place. |
| **Consequence** | The codebase's style gate fails and the file drifts further from the preset with every edit. |
| **Reproduce** | `vendor\bin\pint --test ComplaintController.php --format agent`. |
| **Fix approach** | Run `vendor/bin/pint` on the controller (and the other in-scope files) once the other items are applied; delete the two commented lines. |
| **Plan item** | CMP-41 in `02-fix-plan.md` §8 |

```php
// ComplaintController.php:22 — CURRENT (commented-out import)
// use Modules\GlobalMaster\Models\Dropdown;
```

```php
// ComplaintController.php:435 — CURRENT (commented-out array key)
                // 'action_type_id' => 157,
```

**Evidence**
```
$ vendor\bin\pint --test ComplaintController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"...ComplaintController.php","fixers":["class_attributes_separation","single_space_around_construct","function_declaration","fully_qualified_strict_types","single_line_comment_spacing","concat_space","method_chaining_indentation","trailing_comma_in_multiline","not_operator_with_successor_space","no_extra_blank_lines","blank_line_before_statement","ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (one row per mutating method, eight questions)

Each cell is `ok`, or a finding ID. Questions: (1) overwrite data it should not · (2) delete before storing replacement · (3) duplicate implementations · (4) soft-delete × unique index · (5) race · (6) authorization hole · (7) message lies · (8) dead feature.

| Mutating method | (1) Overwrite | (2) Delete-then-store | (3) Duplicate | (4) Soft-delete×unique | (5) Race | (6) Auth hole | (7) Message lies | (8) Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | CMP-17 | ok | CMP-06 | ok | ok | ok |
| `update` | ok | CMP-05 | CMP-17 | ok | ok | ok | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | ok |
| `reopen` | ok | ok | ok | ok | ok | ok | CMP-13 | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | CMP-23 | CMP-23 |

Notes: (1) `update` does not reset unrelated columns; the `is_escalated`/`is_medical_check_required`/`is_anonymous` flags are rebuilt from `$request->has(...)` on every update, which is the intended edit-form semantics. (5) `store`'s ticket-number generation is a `lockForUpdate` + `exists()` loop inside a transaction — race-managed, but it uses a manual transaction (CMP-06). (7) `reopen()` commits then throws on the bad route name (CMP-13). (8) `toggleStatus` writes a non-existent column (CMP-23).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Complaint/Policies/{Complaint,ComplaintAction,AiInsight,ComplaintCategory,DepartmentSla,MedicalCheck}Policy` | All six policies are registered in `ComplaintServiceProvider::registerPolicies()` (lines 61-66) but every controller check is a `Gate::authorize('string')`, which never reaches a policy. The policies are dead for this controller. | AUTH (F3) | the reports that own those policies / the platform team |
| `Modules/Complaint/Models/ComplaintCategory.php` | `booted()` wraps three `activityLog()` calls in empty `catch (\Throwable $e) {}` blocks (lines 22-48) — swallowed failures on a write path. | ERR-06 | gaurav/Complaint/ComplaintCategoryController |
| `Modules/Complaint/Models/MedicalCheck.php` | Uses `InteractsWithMedia` with no `getMediaModel()` override (same central-DB media issue as CMP-22). | MDL-05/TEN-01 | gaurav/Complaint/MedicalCheckController |
| `Modules/Complaint/app/Services/ComplaintAIInsightEngine.php` | Reads `$c->is_sensitive` (line 185), but `cmp_complaints` has no `is_sensitive` column, so that safety boost never applies. | MDL-07 | this report owns the service — see CMP note in plan §10 |
| `Modules/Complaint/app/Services/ComplaintDashboardService.php` | `getHighRiskPredictions()` dereferences `$ai->complaint->ticket_no` (line 240) with no null guard; an insight whose complaint was hard-deleted would fatal. Noted, not raised as a numbered finding. | ERR-06 | this report (informational) |

## 8. Not covered, and why

- **Instrument gap:** `scanfilter.py` and `selfcheck.py` are missing and `scan.php` was not run (Tarun's
  override). The scanner's candidate rows and the self-check PASS line are therefore unavailable; the
  audit is a manual F1–F13 pass.
- **Database state:** live row counts, seeded permission rows (`sys_role_has_permissions_jnt`) and the
  menu path (`glb_menus`) were not measured — the tenant DB was not queried from this read-only session.
  `⚠ UNVERIFIED — what would settle it: run the counts and an exact-name `whereIn` permission query
  against the tenant database.`
- **Admin-parent views not walked:** `complaint/complaint/create.blade.php` (860 lines) and
  `edit.blade.php` (1,382 lines) were checked for `DB::`/`{!! !!}`/query sinks, not audited line by
  line; their live AJAX wiring to `getTableData` was confirmed but not executed in a browser.
- **Queue:** `ProcessComplaintAIInsights` was read; the queue driver, `$tries`/`$timeout` and a real
  dispatch were not exercised (no job runs in this workflow, D4).
- **API contract:** the `api.complaint.*` routes were confirmed to point at web-shaped methods
  (CMP-04); no live API client was run.
- **No tests run (D4).** No application code was modified.

