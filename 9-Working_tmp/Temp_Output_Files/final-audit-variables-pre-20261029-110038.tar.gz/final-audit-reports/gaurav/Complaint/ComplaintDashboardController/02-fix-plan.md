# Fix Plan — Complaint / ComplaintDashboardController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Complaint/app/Http/Controllers/ComplaintDashboardController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Complaint/routes/web.php` | route file (⚠ SHARED) — the commented dashboard route is only touched if the §9 CDSH-02 DECISION chooses "build it", and even then only with an explicit tick |
| `config/permissionslist.php` | shared config (⚠ SHARED) — already contains the `complaint.complaint-dashboard` keys; this plan adds none |
| `Modules/Complaint/app/Services/ComplaintDashboardService.php` | owned by `gaurav/Complaint/ComplaintController` (00-CLASS-OWNERS.md:437) |
| `Modules/Complaint/resources/views/components/layouts/app.blade.php` | common layout component (§4.2) |
| `final-audit-reports/00-CLASS-OWNERS.md`, `final-audit-reports/gaurav/Complaint/00-INDEX.md` | maintained by the main session |

## 1. Blockers reachable today

None. No route reaches this controller (`route:list` → no rows), so no live screen can break.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — the controller has no `try`/`catch` and no write path (F1/F2 clean in `01-report.md`).

## 4. Authorization (F3)

None — no method is routed, so there is nothing to guard (F3 clean in `01-report.md`).

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **CDSH-01** · M · RTE-03 · `ComplaintDashboardController.php:1-56` — disable the seven unrouted methods per D5 (`abort(403)` + `NOT ROUTED` comment); this one whole-file rewrite also fixes CDSH-02 (empty/broken bodies), CDSH-03 (missing `: never` return types) and CDSH-04 (`strict_types` + placeholder docblocks).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintDashboardController.php`
  - **Before** (`ComplaintDashboardController.php:1-56`, the entire current file):
    ```php
    <?php

    namespace Modules\Complaint\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;

    class ComplaintDashboardController extends Controller
    {
        /**
         * Display a listing of the resource.
         */
        public function index()
        {
            return view('complaint::index');
        }

        /**
         * Show the form for creating a new resource.
         */
        public function create()
        {
            return view('complaint::create');
        }

        /**
         * Store a newly created resource in storage.
         */
        public function store(Request $request) {}

        /**
         * Show the specified resource.
         */
        public function show($id)
        {
            return view('complaint::show');
        }

        /**
         * Show the form for editing the specified resource.
         */
        public function edit($id)
        {
            return view('complaint::edit');
        }

        /**
         * Update the specified resource in storage.
         */
        public function update(Request $request, $id) {}

        /**
         * Remove the specified resource from storage.
         */
        public function destroy($id) {}
    }
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;

    class ComplaintDashboardController extends Controller
    {
        // NOT ROUTED — no route reaches this method; routes/web.php:24 is commented out.
        // Disabled per final-audit D5 (2026-10-17). Wire up a real route to re-enable.
        public function index(): never
        {
            abort(403, 'The complaint dashboard is not available.');
        }

        // NOT ROUTED — see index().
        public function create(): never
        {
            abort(403, 'The complaint dashboard is not available.');
        }

        // NOT ROUTED — see index().
        public function store(Request $request): never
        {
            abort(403, 'The complaint dashboard is not available.');
        }

        // NOT ROUTED — see index().
        public function show($id): never
        {
            abort(403, 'The complaint dashboard is not available.');
        }

        // NOT ROUTED — see index().
        public function edit($id): never
        {
            abort(403, 'The complaint dashboard is not available.');
        }

        // NOT ROUTED — see index().
        public function update(Request $request, $id): never
        {
            abort(403, 'The complaint dashboard is not available.');
        }

        // NOT ROUTED — see index().
        public function destroy($id): never
        {
            abort(403, 'The complaint dashboard is not available.');
        }
    }
    ```
  - **Verify:** `php -l Modules/Complaint/app/Http/Controllers/ComplaintDashboardController.php`
  - **Expect:** `No syntax errors detected in Modules\Complaint\app\Http\Controllers\ComplaintDashboardController.php`
  - **Effort:** S

## 6. Queries & performance (F9)

None — no query of any kind (F9 clean in `01-report.md`).

## 7. Views (F10)

None separate — the dangling view targets (`complaint::create`/`show`/`edit`) disappear when CDSH-01 replaces the bodies with `abort(403)`; the surviving `complaint::index` Blade is query-free (F10 clean in `01-report.md`). No view file is edited.

## 8. Style (F12) — one item per file

None separate — the file's style findings (STY-01 missing `strict_types`, STY-04 placeholder docblocks) are grouped into the single whole-file rewrite **CDSH-01** above, one item for one file (per §12). No second item.

## 9. Deferred / decisions

- [ ] **CDSH-02** · M · DECISION · CTL-10 — this controller is an unimplemented scaffold (`store`/`update`/`destroy` empty, `create`/`show`/`edit` return Blades that do not exist). Disable it, or build the Complaint Dashboard for real?
  - **Why it is a decision:** building it needs a **new route** (route file, ⚠ SHARED) plus the three missing Blade views, which is a new feature and a scope change — not a fix for this pass (D3/D5, §9.3).
  - (a) ⭐ **Disable it cleanly** — tick **CDSH-01** in §5; all seven methods become `abort(403)`. No route file, no new views. (`ComplaintController`'s dashboard tab at `/complaint/complaint-mgt?tab=dashboard` is unaffected.)
  - (b) **Build the dashboard now** — uncomment/replace `routes/web.php:24`, add `complaint::create`/`show`/`edit` views and a real `dashboard` method. ⚠ SHARED: touches the route file; out of this pass.
  - (c) **Leave as is** — record the scaffold as accepted debt; CDSH-01 is not ticked and the controller stays silently dead.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | Every finding (CDSH-01, CDSH-02, CDSH-03, CDSH-04) is covered by the CDSH-01 item in §5; CDSH-02 also carries the §9 DECISION. |
