# Final Audit — Complaint / DepartmentSlaController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php` (309 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /complaint/department-sla/{id}/edit`, `PUT /complaint/department-sla/{id}`, `POST /complaint/department-sla`, `DELETE /complaint/department-sla/{id}`, `GET /complaint/department-sla/create`, `GET /complaint/department-sla/{id}`, `GET /complaint/department-sla/trash/view`, `GET /complaint/department-sla/{id}/restore`, `DELETE /complaint/department-sla/{id}/force-delete`, `POST /complaint/department-sla/{id}/toggle-status`. The SLA **list tab** itself is `GET /complaint/complaint-mgt?tab=sla` (served by `ComplaintController@index`, not this class). |
| Menu path | **Support & Maintenance → Complaint** (measured: `glb_menus` id 297, `route = complaint.complaint-mgt.index`, parent id 294 "Support & Maintenance"), then the **SLA** tab inside Complaint Management. |
| Who uses it | Super Admin and School Admin (measured in `sys_role_has_permissions_jnt`: all eight `tenant.complaint.department-sla.*` permissions are granted to role ids 1 and 2 only). |
| What a user does here | An admin sets the service-level-agreement for a complaint category (and optional sub-category, department, role, user, vehicle, vendor): how many hours until resolution and five escalation thresholds in increasing order. They can edit, soft-delete, restore, permanently delete, and toggle active/inactive. |
| Tables written | `cmp_department_sla` (INSERT/UPDATE/soft-DELETE/restore/force-DELETE). The audit helper also writes the tenant activity-log table `glb_activity_logs`. |
| Tables read | `cmp_department_sla`, `cmp_complaint_categories`, `sys_roles`, `sys_users`, `sch_departments`, `sch_designations`, `sch_entity_groups`, `tpt_vehicle`, `vnd_vendors`. |
| Live data | `cmp_department_sla` **15 live rows, 0 trashed** (measured on tenant `test.localhost`). Dropdown sources: `sys_users` **5,630**, `tpt_vehicle` 50, `vnd_vendors` 10, `sch_departments` 14, `sch_designations` 12, `sch_entity_groups` 8, `sys_roles` 10, `cmp_complaint_categories` 15. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready**. Its data model, validation and transactions are broadly sound, but it breaks the project's settled error-handling rule in every mutating method (D1: six hand-written `try/catch` blocks that log the exception *message* and hide the real error from the central handler), and it enforces the SLA's composite uniqueness **only** in PHP with no unique index in the database — so two admins saving at the same moment can create duplicate SLA rows. The single worst finding is **DSLA-02**: the composite uniqueness check (`DSLA-02`, H, TXN-06) is check-then-act against a table that has no unique index, so duplicate SLAs are possible and, because the rule also counts soft-deleted rows (`DSLA-04`), a legitimate re-create after a soft-delete is blocked. Route hygiene adds two more: `restore` changes state over **GET** (`DSLA-05`) and the class' own `index()` is unrouted and dead (`DSLA-06`). Rough effort to fix the plan: **M (≈1 day)**; the two migration-backed decisions need Tarun's call.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 7 | 9 | 3 | 18 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | DSLA-01 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | DSLA-02 | F9 Queries/Perf | DSLA-12, DSLA-13 |
| F3 Authorization | DSLA-03 | F10 Views | DSLA-14 |
| F4 Validation | DSLA-04 | F11 Security/Tenancy | clean |
| F5 Routes | DSLA-05, DSLA-06 | F12 Style | DSLA-15, DSLA-16, DSLA-17 |
| F6 Controller shape | DSLA-07, DSLA-08, DSLA-09 | F13 Deep read | DSLA-18 |
| F7 Models | DSLA-10, DSLA-11 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php` | controller | 309 | this report | ✅ |
| 2 | `Modules/Complaint/app/Models/DepartmentSla.php` | model | 179 | this report | ✅ |
| 3 | `Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php` | form request | 108 | this report | ✅ |
| 4 | `Modules/Complaint/resources/views/complaint/department-sla/index.blade.php` | blade | 376 | this report | ✅ |
| 5 | `Modules/Complaint/resources/views/complaint/department-sla/create.blade.php` | blade | 260 | this report | ✅ |
| 6 | `Modules/Complaint/resources/views/complaint/department-sla/edit.blade.php` | blade | 329 | this report | ✅ |
| 7 | `Modules/Complaint/resources/views/complaint/department-sla/show.blade.php` | blade | 187 | this report | ✅ |
| 8 | `Modules/Complaint/resources/views/complaint/department-sla/trash.blade.php` | blade | 81 | this report | ✅ |
| 9 | `Modules/Complaint/app/Models/ComplaintCategory.php` | model (shared) | 182 | ↗ [gaurav/Complaint/ComplaintCategoryController](../ComplaintCategoryController/01-report.md) (status CLAIMED) | ↗ linked |
| 10 | `Modules/GlobalMaster/Models/Dropdown.php` | model (other module) | – | common | ↗ linked |
| 11 | `Modules/SchoolSetup/Models/Department.php`, `Designation.php`, `EntityGroup.php`, `Role.php`, `User.php` | models (other module) | – | common | ↗ linked |
| 12 | `Modules/Transport/Models/Vehicle.php`, `Modules/Vendor/Models/Vendor.php` | models (other module) | – | common | ↗ linked |
| 13 | `app/Traits/AuthorizesTenantFeature.php` | trait (app glue) | 56 | common | ↗ linked |
| 14 | `app/Helpers/activityLog.php` | helper (app glue) | 51 | common | ↗ linked |
| 15 | `Modules/Complaint/routes/web.php` | route file (shared) | 198 | shared — routes reported, not edited | ↗ linked |
| 16 | `config/permissionslist.php` | config (shared) | – | shared — read for F3 | ↗ linked |
| 17 | `database/migrations/tenant/2026_06_15_155150_create_cmp_department_sla_table.php` | migration | 64 | read-only | ✅ |
| 18 | `database/migrations/tenant/2026_06_18_100114_add_deleted_at_to_cmp_department_sla_table.php` | migration | 32 | read-only | ✅ |

`ComplaintCategory` is owned by `gaurav/Complaint/ComplaintCategoryController` (status CLAIMED, so it may not be finished yet). This report only checked **how** the controller uses it (eager-loading, arguments) — see F9/F10.

No pre-applied files.

## 4. Routes

```
POST      complaint/department-sla                                complaint.department-sla.store      Modules\Complaint\Http\Controllers\DepartmentSlaController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  complaint/department-sla/create                         complaint.department-sla.create     Modules\Complaint\Http\Controllers\DepartmentSlaController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  complaint/department-sla/trash/view                     complaint.department-sla.trashed    Modules\Complaint\Http\Controllers\DepartmentSlaController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  complaint/department-sla/{department_sla}               complaint.department-sla.show       Modules\Complaint\Http\Controllers\DepartmentSlaController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH complaint/department-sla/{department_sla}               complaint.department-sla.update     Modules\Complaint\Http\Controllers\DepartmentSlaController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    complaint/department-sla/{department_sla}               complaint.department-sla.destroy    Modules\Complaint\Http\Controllers\DepartmentSlaController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  complaint/department-sla/{department_sla}/edit          complaint.department-sla.edit       Modules\Complaint\Http\Controllers\DepartmentSlaController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    complaint/department-sla/{id}/force-delete              complaint.department-sla.forceDelete Modules\Complaint\Http\Controllers\DepartmentSlaController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  complaint/department-sla/{id}/restore                   complaint.department-sla.restore    Modules\Complaint\Http\Controllers\DepartmentSlaController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      complaint/department-sla/{id}/toggle-status             complaint.department-sla.toggleStatus Modules\Complaint\Http\Controllers\DepartmentSlaController@toggleStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: `index()` at `DepartmentSlaController.php:24` — `GET /complaint/department-sla` is routed at `Modules/Complaint/routes/web.php:68` to `ComplaintController@index`, not this class, and `Route::resource('department-sla', DepartmentSlaController::class)->except(['index'])->names('department-sla')` at `routes/web.php:69` skips it. Reported as **DSLA-06** (RTE-03, D5). No other public method is unrouted.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 24 | **NOT ROUTED** | `tenant.complaint.department-sla.viewAny` | none | none | none | DSLA-06 |
| `create` | 37 | GET complaint/department-sla/create | `tenant.complaint.department-sla.create` | none | none | none | DSLA-12 |
| `store` | 54 | POST complaint/department-sla | `tenant.complaint.department-sla.create` | controller | `Stored` | cmp_department_sla, activity log | DSLA-01, DSLA-02, DSLA-03, DSLA-04 |
| `edit` | 80 | GET complaint/department-sla/{department_sla}/edit | `tenant.complaint.department-sla.update` | none | none | none | DSLA-07, DSLA-12 |
| `update` | 104 | PUT/PATCH complaint/department-sla/{department_sla} | `tenant.complaint.department-sla.update` | controller | `Updated` | cmp_department_sla, activity log | DSLA-01, DSLA-03, DSLA-04, DSLA-07 |
| `destroy` | 146 | DELETE complaint/department-sla/{department_sla} | `tenant.complaint.department-sla.delete` | controller | `Deleted` | cmp_department_sla, activity log | DSLA-01, DSLA-07 |
| `trashed` | 178 | GET complaint/department-sla/trash/view | `tenant.complaint.department-sla.restore` | none | none | none | DSLA-13, DSLA-14 |
| `restore` | 196 | GET complaint/department-sla/{id}/restore | `tenant.complaint.department-sla.restore` | controller | `Restored` | cmp_department_sla, activity log | DSLA-01, DSLA-05, DSLA-07 |
| `forceDelete` | 228 | DELETE complaint/department-sla/{id}/force-delete | `tenant.complaint.department-sla.forceDelete` | controller | `Force Deleted` | cmp_department_sla, activity log | DSLA-01, DSLA-07 |
| `show` | 259 | GET complaint/department-sla/{department_sla} | `tenant.complaint.department-sla.view` | none | none | none | DSLA-07 |
| `toggleStatus` | 271 | POST complaint/department-sla/{id}/toggle-status | `tenant.complaint.department-sla.update` | controller | `Toggled` | cmp_department_sla, activity log | DSLA-01, DSLA-07 |

## 6. Findings

### F1 — Errors

#### DSLA-01 · M · ERR-00 (D1) — a hand-written `try/catch` wraps all six mutating methods

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M, reason: structural debt that reverses the settled D1 decision; no crash today) — *D1 settles the open ERR-00 question: no `try/catch` in controllers; the central handler in `bootstrap/app.php` logs and renders errors.* |
| **Where** | `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php` — `store():58-74`, `update():111-140`, `destroy():152-169`, `restore():202-219`, `forceDelete():234-251`, `toggleStatus():281-301` |
| **Root cause** | Each mutation wraps its `DB::transaction` call in a `try { } catch (\Throwable $e)`. The catch logs the exception message plus `get_class($e)` and returns a redirect with a flash error (store's block is quoted below). D1 forbids controller try/catch and the repo already has a central renderer. The log line also violates ERR-05: it logs the message string and the class name, not the exception object, so the stack trace is lost. |
| **Consequence** | Any real failure (a DB error, a bug) is swallowed into a generic red flash, never reaches the central error handler, and is logged without a trace — so nobody can diagnose it. |
| **Reproduce** | Static only — triggering the catch needs a forced DB failure; the defect is the presence of the catch. |
| **Fix approach** | Remove the six `try/catch` blocks and the `use Illuminate\Support\Facades\Log;` import. Keep the `DB::transaction` call and the `activityLog` call; build the redirect after the closure (already done). Let `bootstrap/app.php` render errors (D1). |
| **Plan item** | DSLA-01 in `02-fix-plan.md` §3 |

```php
// DepartmentSlaController.php:58-74 — CURRENT (store; the other five are identical in shape)
        try {
            DB::transaction(function () use ($request) {
                $sla = DepartmentSla::create($request->validated());

                activityLog($sla, 'Stored', [
                    'message'      => 'Department SLA created.',
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });
        } catch (\Throwable $e) {
            Log::error('Department SLA create failed: ' . $e->getMessage(), [
                'exception' => get_class($e),
            ]);

            return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'sla'])
                ->with('error', flash('operation_failed.department_sla', 'Failed to create the department SLA.'));
        }
```

**Evidence**
```
$ grep -n "try {\|catch (\\\\Throwable\|getMessage()" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php
58:        try {
67:        } catch (\Throwable $e) {
68:            Log::error('Department SLA create failed: ' . $e->getMessage(), [
111:        try {
132:        } catch (\Throwable $e) {
133:            Log::error('Department SLA update failed: ' . $e->getMessage(), [
152:        try {
161:        } catch (\Throwable $e) {
162:            Log::error('Department SLA delete failed: ' . $e->getMessage(), [
202:        try {
211:        } catch (\Throwable $e) {
212:            Log::error('Department SLA restore failed: ' . $e->getMessage(), [
234:        try {
243:        } catch (\Throwable $e) {
244:            Log::error('Department SLA force delete failed: ' . $e->getMessage(), [
281:        try {
291:        } catch (\Throwable $e) {
292:            Log::error('Department SLA toggle failed: ' . $e->getMessage(), [
```

### F2 — Transactions and audit

#### DSLA-02 · H · TXN-06 — composite uniqueness is check-then-act with no unique index

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index: `count()` then insert, `exists()` then `create()`.* |
| **Where** | `Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php:37-51` (the uniqueness rule) vs `database/migrations/tenant/2026_06_15_155150_create_cmp_department_sla_table.php:14-54` (no unique index) |
| **Root cause** | The eight-column composite key is enforced only by the `Rule::unique` closure in the FormRequest. The table is created with foreign keys and no `unique()`; `SHOW COLUMNS` confirms none of the eight columns carries a unique key. Validation runs outside any lock, so two concurrent `store` requests both see "no duplicate" and both insert. |
| **Consequence** | Two admins saving the same SLA at the same instant can create two identical SLA rows; the escalation resolver (`EscalateComplaints::resolveDepartmentSla()` → `->first()`) then picks one arbitrarily. |
| **Reproduce** | Static only — a concurrency race cannot be shown in the browser; the missing index is proven by the migration and `SHOW COLUMNS`. |
| **Fix approach** | Add an additive tenant migration creating a unique index over the eight composite columns (with `deleted_at` handling — see DSLA-04) and let the FormRequest rule mirror it. This is a DECISION (new migration; running it is Tarun's hand). |
| **Plan item** | DSLA-02 in `02-fix-plan.md` §9 |

```php
// DepartmentSlaRequest.php:37-47 — the ONLY uniqueness guard
        $uniqueSlaRule = Rule::unique('cmp_department_sla', 'complaint_category_id')
            ->where(function ($query) {
                return $query->where('complaint_subcategory_id', $this->filled('complaint_subcategory_id') ? $this->input('complaint_subcategory_id') : null)
                    ->where('target_department_id', $this->filled('target_department_id') ? $this->input('target_department_id') : null)
                    ->where('target_designation_id', $this->filled('target_designation_id') ? $this->input('target_designation_id') : null)
                    ->where('target_role_id', $this->filled('target_role_id') ? $this->input('target_role_id') : null)
                    ->where('target_entity_group_id', $this->filled('target_entity_group_id') ? $this->input('target_entity_group_id') : null)
                    ->where('target_user_id', $this->filled('target_user_id') ? $this->input('target_user_id') : null)
                    ->where('target_vehicle_id', $this->filled('target_vehicle_id') ? $this->input('target_vehicle_id') : null)
                    ->where('target_vendor_id', $this->filled('target_vendor_id') ? $this->input('target_vendor_id') : null);
            });
```

**Evidence**
```
$ grep -n "unique(" database/migrations/tenant/2026_06_15_155150_create_cmp_department_sla_table.php
(no output — the table has no unique index)

$ php dsla_probe.php   # SHOW COLUMNS FROM cmp_department_sla
COLUMNS=id,dept_expected_resolution_hours,dept_escalation_hours_l1,dept_escalation_hours_l2,dept_escalation_hours_l3,dept_escalation_hours_l4,dept_escalation_hours_l5,is_active,created_at,updated_at,complaint_category_id,complaint_subcategory_id,target_department_id,target_designation_id,target_role_id,target_entity_group_id,target_user_id,target_vehicle_id,target_vendor_id,escalation_l1_entity_group_id,escalation_l2_entity_group_id,escalation_l3_entity_group_id,escalation_l4_entity_group_id,escalation_l5_entity_group_id,deleted_at
(no key column marked unique; SETUP shows only PRIMARY on id)
```

### F3 — Authorization

#### DSLA-03 · L · AUTH-04 — the same permission is authorized twice on `store`/`update`

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one.* |
| **Where** | `Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php:16-22` and `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php:56`, `:106` |
| **Root cause** | The FormRequest `authorize()` calls `authorizeByCrudPermission('tenant.complaint.department-sla')`, which maps POST→`create` and PUT/PATCH→`update`; the controller then calls `Gate::authorize('tenant.complaint.department-sla.create')`/`('.update')` for the same actions. Its own comment admits it "narrows nothing and widens nothing". |
| **Consequence** | No user-visible effect; it is a maintainability defect — a future permission rename must be made in two places or the checks silently diverge. |
| **Reproduce** | Static only — both checks pass or fail together today. |
| **Fix approach** | Keep the controller's explicit `Gate::authorize` and make the FormRequest `authorize()` return `true` (the controller is the single authorizer for these methods). |
| **Plan item** | DSLA-03 in `02-fix-plan.md` §4 |

```php
// DepartmentSlaRequest.php:16-22 — CURRENT
    public function authorize(): bool
    {
        // T6b — mirrors the controller's own gate: tenant.department-sla.create on POST,
        // tenant.department-sla.update on PUT/PATCH. Same permission, checked one step
        // earlier, so this narrows nothing and widens nothing.
        return $this->authorizeByCrudPermission('tenant.complaint.department-sla');
    }
```

**Evidence**
```
$ grep -n "authorize" Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php
Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php:21:        return $this->authorizeByCrudPermission('tenant.complaint.department-sla');
Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php:56:        Gate::authorize('tenant.complaint.department-sla.create');
Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php:106:        Gate::authorize('tenant.complaint.department-sla.update');
```

F3 otherwise clean: every routed method authorizes first; all eight `tenant.complaint.department-sla.*` names exist in `sys_permissions` and are granted to Super Admin + School Admin (evidence below). No Policy is declared for this model, so no dead Policy.

```
$ php dsla_probe.php
EXACT_FOUND=tenant.complaint.department-sla.create,tenant.complaint.department-sla.delete,tenant.complaint.department-sla.forceDelete,tenant.complaint.department-sla.restore,tenant.complaint.department-sla.update,tenant.complaint.department-sla.view,tenant.complaint.department-sla.viewAny
GRANTS tenant.complaint.department-sla.create => role_ids=[1,2] roles=[Super Admin,School Admin]
GRANTS tenant.complaint.department-sla.delete => role_ids=[1,2] roles=[Super Admin,School Admin]
GRANTS tenant.complaint.department-sla.export => role_ids=[1,2] roles=[Super Admin,School Admin]
GRANTS tenant.complaint.department-sla.forceDelete => role_ids=[1,2] roles=[Super Admin,School Admin]
GRANTS tenant.complaint.department-sla.restore => role_ids=[1,2] roles=[Super Admin,School Admin]
GRANTS tenant.complaint.department-sla.update => role_ids=[1,2] roles=[Super Admin,School Admin]
GRANTS tenant.complaint.department-sla.view => role_ids=[1,2] roles=[Super Admin,School Admin]
GRANTS tenant.complaint.department-sla.viewAny => role_ids=[1,2] roles=[Super Admin,School Admin]
```

### F4 — Validation and input

#### DSLA-04 · M · VAL-04 — the uniqueness rule ignores soft-deletes, blocking re-creation

| Field | Value |
|---|---|
| **Rule** | VAL-04 (M) — *uniqueness rules mirror the DB unique index **including soft-delete semantics**.* |
| **Where** | `Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php:37-51`; the soft-delete column is added at `database/migrations/tenant/2026_06_18_100114_add_deleted_at_to_cmp_department_sla_table.php:14-18` |
| **Root cause** | The `Rule::unique` closure never adds `->whereNull('deleted_at')`, so the check counts soft-deleted rows. The executed SQL (below) has no `deleted_at` filter. So after an admin soft-deletes an SLA, creating a new one for the same category/target returns "already exists" even though the row is gone from the UI. |
| **Consequence** | An admin who deletes an SLA and immediately re-adds the same configuration is blocked by a validation error that references a record they cannot see. |
| **Reproduce** | Soft-delete an SLA from the `?tab=sla` list, then submit the same category/sub-category/target in `Create Department SLA` → red "An SLA configuration for this category/subcategory and target assignment already exists." |
| **Fix approach** | DECISION — either add `->whereNull('deleted_at')` to the rule **and** a matching partial unique index (so the DB agrees), or make the DB index span trashed rows and keep the rule. Must be decided together with DSLA-02 (new migration). |
| **Plan item** | DSLA-04 in `02-fix-plan.md` §9 |

```php
// DepartmentSlaRequest.php:37-51 — no whereNull('deleted_at'); ignore() only skips the row's own id
        $uniqueSlaRule = Rule::unique('cmp_department_sla', 'complaint_category_id')
            ->where(function ($query) {
                return $query->where('complaint_subcategory_id', $this->filled('complaint_subcategory_id') ? $this->input('complaint_subcategory_id') : null)
                    ->where('target_department_id', $this->filled('target_department_id') ? $this->input('target_department_id') : null)
                    ->where('target_designation_id', $this->filled('target_designation_id') ? $this->input('target_designation_id') : null)
                    ->where('target_role_id', $this->filled('target_role_id') ? $this->input('target_role_id') : null)
                    ->where('target_entity_group_id', $this->filled('target_entity_group_id') ? $this->input('target_entity_group_id') : null)
                    ->where('target_user_id', $this->filled('target_user_id') ? $this->input('target_user_id') : null)
                    ->where('target_vehicle_id', $this->filled('target_vehicle_id') ? $this->input('target_vehicle_id') : null)
                    ->where('target_vendor_id', $this->filled('target_vendor_id') ? $this->input('target_vendor_id') : null);
            });

        if ($id) {
            $uniqueSlaRule = $uniqueSlaRule->ignore($id);
        }
```

**Evidence**
```
$ php dsla_validate.php
C duplicate existing composite:
  SQL: select count(*) as aggregate from `cmp_department_sla`
       where `complaint_category_id` = ? and (`complaint_subcategory_id` = ?
       and `target_department_id` = ? and `target_designation_id` = ?
       and `target_role_id` = ? and `target_entity_group_id` = ?
       and `target_user_id` = ? and `target_vehicle_id` is null
       and `target_vendor_id` is null)
  bindings=[1,7,1,1,1,1,1]
  ERR: An SLA configuration for this category/subcategory and target assignment already exists.
(no `deleted_at is null` clause in the generated SQL)
```

F4 other checks: cross-field `gt:` ordering rules execute correctly (evidence below); `prepareForValidation` always sets `is_active` to a boolean; optional fields use `filled() ? input() : null`; no `$request->all()`; no upload. Clean apart from DSLA-04.

```
$ php dsla_validate.php
== B l2 == l1 ==
passes=false
  ERR: Escalation L2 hours must be greater than L1 hours.
```

### F5 — Routes

#### DSLA-05 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle` and similar); GET has no CSRF protection and link prefetchers trigger it.* |
| **Where** | `Modules/Complaint/routes/web.php:76-79`; handler `DepartmentSlaController.php:196` |
| **Root cause** | The restore route is registered as `Route::get('department-sla/{id}/restore', [DepartmentSlaController::class, 'restore'])` (routes/web.php:76-79). A GET that performs a write (`$sla->restore()`) has no CSRF token and can be fired by any prefetcher, crawler or `<img src>` a logged-in admin loads. |
| **Consequence** | A soft-deleted SLA can be restored without the admin intending it (browser prefetch, pasted link, external page), silently re-activating a rule that was removed. |
| **Reproduce** | While logged in as School Admin, open `http://test.localhost:8000/complaint/department-sla/1/restore` in the address bar → the record is restored. |
| **Fix approach** | DECISION — change the route verb (`Route::patch` or `Route::delete`) and update the trash view's restore action to send that verb (both touch the shared route file). |
| **Plan item** | DSLA-05 in `02-fix-plan.md` §9 |

```php
// Modules/Complaint/routes/web.php:76-79 — CURRENT
Route::get(
    'department-sla/{id}/restore',
    [DepartmentSlaController::class, 'restore']
)->name('department-sla.restore');
```

**Evidence**
```
$ $env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --json | php routesprobe.php Modules\Complaint\Http\Controllers\DepartmentSlaController
GET|HEAD  complaint/department-sla/{id}/restore                   complaint.department-sla.restore    Modules\Complaint\Http\Controllers\DepartmentSlaController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

#### DSLA-06 · M · RTE-03 — the class' own `index()` is unrouted and dead (D5)

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`).* |
| **Where** | `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php:24-35` |
| **Root cause** | `GET complaint/department-sla` is routed to `ComplaintController@index` (`routes/web.php:68`) and the resource is registered `->except(['index'])` (`routes/web.php:69`), so `DepartmentSlaController::index()` is reachable through no route. It also returns the tab **partial** (`complaint::complaint.department-sla.index`) with only `compact('slas')`, though that partial reads `$slasExport`, `$slaCategories`, `$slaDepartments` and `$groups` — so if it were ever routed it would 500 on undefined variables. |
| **Consequence** | None today (dead code). It is a maintenance trap: a future `Route::resource` change would bind it and immediately error. |
| **Reproduce** | Static only — the method has no route. |
| **Fix approach** | Per D5, replace the body with `abort(403)` and a `NOT ROUTED` comment; do not delete it. |
| **Plan item** | DSLA-06 in `02-fix-plan.md` §5 |

```php
// DepartmentSlaController.php:24-35 — CURRENT
    public function index()
    {
        Gate::authorize('tenant.complaint.department-sla.viewAny');
        $slas = DepartmentSla::with([
            'category',
            'subCategory',
            'targetRole',
            'targetUser'
        ])->paginate(15);

        return view('complaint::complaint.department-sla.index', compact('slas'));
    }
```

**Evidence**
```
$ php artisan route:list --json | php routesprobe.php Modules\Complaint\Http\Controllers\DepartmentSlaController
(there is no `department-sla.index` line for this class; the list above starts at `store`)

$ grep -n "department-sla\|except" Modules/Complaint/routes/web.php
68:Route::get('department-sla', [ComplaintController::class, 'index'])->name('department-sla.index');
69:Route::resource('department-sla', DepartmentSlaController::class)->except(['index'])->names('department-sla');
```

F5 other checks: no route points at a missing method (all nine resource/custom handlers exist — `php -l` clean and `route:list` resolves each); `Route::resource` uses `{department_sla}` while the controller takes `$id` — harmless today because `$id` is a scalar resolved positionally, and it disappears when DSLA-07 applies route-model binding; tenant middleware is present on every route (see the `route:list` brackets). Custom routes are registered after the resource but do not collide (they are two-segment paths); RTE-06 not present.

### F6 — Controller shape

#### DSLA-07 · M · CTL-03 — `$id` + `findOrFail` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`), not `$id` + `findOrFail`.* |
| **Where** | `DepartmentSlaController.php:80`, `:104`, `:146`, `:259` (`edit`, `update`, `destroy`, `show`) |
| **Root cause** | The four resource methods take `$id` and call `DepartmentSla::findOrFail($id)`. The resource route parameter is `{department_sla}`, so the argument name does not even match the route. |
| **Consequence** | A missing record produces the framework 404 (acceptable), but the controller cannot take the trashed set into account and every method repeats the lookup; renaming the route parameter later would silently break the argument. |
| **Reproduce** | Static only — behaviour is currently correct. |
| **Fix approach** | Type-hint `DepartmentSla $departmentSla` on `edit`/`update`/`destroy`/`show` (the route parameter already matches). Leave the custom-route methods (`restore`, `forceDelete`, `toggleStatus`) on `$id` because their routes use `{id}`. |
| **Plan item** | DSLA-07 in `02-fix-plan.md` §5 |

```php
// DepartmentSlaController.php:80-84 — CURRENT (edit; destroy:146-150, show:259-263 identical shape)
    public function edit($id)
    {
        Gate::authorize('tenant.complaint.department-sla.update');

        $sla = DepartmentSla::findOrFail($id);
```

**Evidence**
```
$ grep -n "public function edit\|public function update\|public function destroy\|public function show\|findOrFail" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php
80:    public function edit($id)
84:        $sla = DepartmentSla::findOrFail($id);
104:    public function update(DepartmentSlaRequest $request, $id)
108:        $sla = DepartmentSla::findOrFail($id);
146:    public function destroy($id)
150:        $sla = DepartmentSla::findOrFail($id);
259:    public function show($id)
263:        $sla = DepartmentSla::findOrFail($id);
```

#### DSLA-08 · L · CTL-04 — no return types on the public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`).* |
| **Where** | `DepartmentSlaController.php` — all 11 public methods (`index:24`, `create:37`, `store:54`, `edit:80`, `update:104`, `destroy:146`, `trashed:178`, `restore:196`, `forceDelete:228`, `show:259`, `toggleStatus:271`) |
| **Root cause** | Not one method declares a return type. |
| **Consequence** | No runtime effect; static analysis and the D1 catch-shapes rule cannot rely on a declared type. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `: View`, `: RedirectResponse` and `: JsonResponse` return types and the matching imports. |
| **Plan item** | DSLA-08 in `02-fix-plan.md` §5 |

```php
// DepartmentSlaController.php:24-26 — CURRENT
    public function index()
    {
        Gate::authorize('tenant.complaint.department-sla.viewAny');
```

**Evidence**
```
$ grep -cE "public function [a-zA-Z_]+\(\)" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php
$ grep -nE "public function [a-zA-Z_]+\(.*\):" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php
(no output — no public method declares a return type)
```

#### DSLA-09 · M · CTL-05 — duplicated dropdown loaders in `create()` and `edit()`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: dropdown loaders shared by `create`/`edit`.* |
| **Where** | `DepartmentSlaController.php:41-51` (`create`) and `:90-101` (`edit`) |
| **Root cause** | Both methods build the identical dropdown payload (`categories`, `roles`, `users`, `departments`, `designations`, `entityGroups`, `vehicles`, `vendors`). A duplicate create form also exists: `create.blade.php` (page) and the `#createSlaModal` inside `index.blade.php` — two copies of the same 20-control form that can drift. |
| **Consequence** | Add a dropdown to one path and the other silently lacks it; the two create forms already differ (`edit`/page uses `entityGroups`, the modal uses `groups`). |
| **Reproduce** | Compare `/complaint/department-sla/create` with the modal on `/complaint/complaint-mgt?tab=sla`. |
| **Fix approach** | Extract one private `formDropdowns(): array` used by both `create()` and `edit()`. |
| **Plan item** | DSLA-09 in `02-fix-plan.md` §5 |

```php
// DepartmentSlaController.php:41-51 — CURRENT (create; edit:90-101 repeats the same eight sources)
        return view('complaint::complaint.department-sla.create', [
            'categories' => ComplaintCategory::parents()->get(),
            'subCategories' => collect(),
            'roles' => Role::all(),
            'users' => User::all(),
            'departments' => Department::all(),
            'designations' => Designation::all(),
            'entityGroups' => EntityGroup::all(),
            'vehicles' => Vehicle::all(),
            'vendors' => Vendor::all(),
        ]);
```

**Evidence**
```
$ grep -n "Role::all()\|User::all()\|Department::all()\|Designation::all()\|EntityGroup::all()\|Vehicle::all()\|Vendor::all()\|ComplaintCategory::parents" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php
42:            'categories' => ComplaintCategory::parents()->get(),
44:            'roles' => Role::all(),
45:            'users' => User::all(),
46:            'departments' => Department::all(),
47:            'designations' => Designation::all(),
48:            'entityGroups' => EntityGroup::all(),
49:            'vehicles' => Vehicle::all(),
50:            'vendors' => Vendor::all(),
92:            'categories' => ComplaintCategory::parents()->get(),
94:            'roles' => Role::all(),
95:            'users' => User::all(),
96:            'departments' => Department::all(),
97:            'designations' => Designation::all(),
98:            'entityGroups' => EntityGroup::all(),
99:            'vehicles' => Vehicle::all(),
100:            'vendors' => Vendor::all(),
```

F6 other checks: 309 lines / 11 public methods — under the 1,000-line and 25-method CTL-01 thresholds (clean); no method exceeds 80 lines (clean); no `compact()` over 15 vars (clean); `Request` is injected, no `request()` helper in methods (clean); no `dd()`/`dump()`/`var_dump()` (clean).

### F7 — Models

#### DSLA-10 · M · MDL-07 — a relationship points at a column that does not exist

| Field | Value |
|---|---|
| **Rule** | MDL-07 (M, applying its "model references a thing that is not in the migration" principle to a column) — *every model's table/columns exist in a migration.* |
| **Where** | `Modules/Complaint/app/Models/DepartmentSla.php:88-91` (`targetUserType()`), used by `DepartmentSlaController.php:187` (`trashed()` eager-loads `targetUserType`) |
| **Root cause** | `targetUserType()` is `belongsTo(Dropdown::class, 'target_user_type_id')`, and `$fillable` even lists `// 'target_user_type_id',` commented out, but `SHOW COLUMNS FROM cmp_department_sla` has no `target_user_type_id`. The column exists on `cmp_complaints`, not on this table. The relation can therefore never resolve. |
| **Consequence** | The trash view's eager load always returns null; any future code that reads `$sla->targetUserType` gets null forever with no error to explain it. |
| **Reproduce** | Static only — read the migration/SHOW COLUMNS. |
| **Fix approach** | Either add the column in the DSLA-02 migration decision, or remove the dead `targetUserType()` relation and its eager load from `trashed()`. |
| **Plan item** | DSLA-10 in `02-fix-plan.md` §5 |

```php
// DepartmentSla.php:88-91 — CURRENT
    public function targetUserType()
    {
        return $this->belongsTo(Dropdown::class, 'target_user_type_id');
    }
```

**Evidence**
```
$ grep -n "target_user_type_id" Modules/Complaint/app/Models/DepartmentSla.php database/migrations/tenant/2026_06_15_155150_create_cmp_department_sla_table.php
Modules/Complaint/app/Models/DepartmentSla.php:30:        // 'target_user_type_id',
Modules/Complaint/app/Models/DepartmentSla.php:90:        return $this->belongsTo(Dropdown::class, 'target_user_type_id');
(database migration: no match)

$ php dsla_probe.php
COLUMNS=id,dept_expected_resolution_hours,dept_escalation_hours_l1,dept_escalation_hours_l2,dept_escalation_hours_l3,dept_escalation_hours_l4,dept_escalation_hours_l5,is_active,created_at,updated_at,complaint_category_id,complaint_subcategory_id,target_department_id,target_designation_id,target_role_id,target_entity_group_id,target_user_id,target_vehicle_id,target_vendor_id,escalation_l1_entity_group_id,escalation_l2_entity_group_id,escalation_l3_entity_group_id,escalation_l4_entity_group_id,escalation_l5_entity_group_id,deleted_at
(no target_user_type_id)
```

#### DSLA-11 · L · MDL-04 — relationships have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`).* |
| **Where** | `Modules/Complaint/app/Models/DepartmentSla.php:77-131` (`category`, `subCategory`, `targetUserType`, `targetDepartment`, `targetRole`, `targetUser`, `targetDesignation`, `targetEntityGroup`, `targetVehicle`, `targetVendor`) |
| **Root cause** | None of the ten `belongsTo` methods declares a return type. |
| **Consequence** | No runtime effect; weaker static analysis and IDE support. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `: BelongsTo` return types. |
| **Plan item** | DSLA-11 in `02-fix-plan.md` §5 |

```php
// DepartmentSla.php:77-80 — CURRENT
    public function category()
    {
        return $this->belongsTo(ComplaintCategory::class, 'complaint_category_id');
    }
```

**Evidence**
```
$ grep -cE "public function .*\): " Modules/Complaint/app/Models/DepartmentSla.php
0
```

F7 other checks: `$fillable` declared, nothing sensitive (clean, MDL-01); `$casts` declares `is_active => boolean` (clean, MDL-02); `$table = 'cmp_department_sla'` exists in migration and `SoftDeletes` matches the `deleted_at` migration (clean, MDL-07/SoftDeletes); no `belongsToMany`, no `InteractsWithMedia`, no global scope (clean, MDL-03/05/08).

### F8 — Services and jobs

clean — this controller injects no service and dispatches no job: `grep -nE "Service|Job|dispatch" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php` → no output.

### F9 — Queries and performance

#### DSLA-12 · M · QRY-15 / QRY-03 — whole tables loaded for form dropdowns

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *don't load every row of a big table for a form;* combined with QRY-03 (M) — *select only the columns you use.* |
| **Where** | `DepartmentSlaController.php:45` (`User::all()`) in both `create()` and `edit()`, with `:44`, `:46-50` and `:94-100` loading the other masters whole. |
| **Root cause** | `User::all()` loads every user model with every column on each render of the create/edit page, and the blade renders one `<option>` per row. Measured on the live tenant: `sys_users` = **5,630 rows**. The sibling `ComplaintController@index` already does this correctly (`User::whereIn('user_type', ['EMPLOYEE', 'TEACHER', 'PRIME', 'SYSTEM'])->select('id', 'name')->get()`, ComplaintController.php:180). |
| **Consequence** | Opening Create/Edit Department SLA loads and renders 5,630+ user rows every time, making the page slow and the User dropdown unusable. |
| **Reproduce** | Open `/complaint/department-sla/create` and open the User `<select>` — thousands of options. |
| **Fix approach** | Filter `User` to the relevant user types and select only `id, name`; do the same (`select('id','name')` / `pluck`) for the other dropdowns. |
| **Plan item** | DSLA-12 in `02-fix-plan.md` §6 |

```php
// DepartmentSlaController.php:45 — CURRENT
            'users' => User::all(),
```

**Evidence**
```
$ grep -n "User::all()\|Role::all()\|Vehicle::all()\|Vendor::all()" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php
44:            'roles' => Role::all(),
45:            'users' => User::all(),
49:            'vehicles' => Vehicle::all(),
50:            'vendors' => Vendor::all(),
94:            'roles' => Role::all(),
95:            'users' => User::all(),
99:            'vehicles' => Vehicle::all(),
100:            'vendors' => Vendor::all(),

$ php dsla_counts.php
sys_users=5630
tpt_vehicle=50
vnd_vendors=10
```

#### DSLA-13 · L · QRY-13 (C12) — lists paginate at 15, not the standard 10

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L) — *filtered paginators keep filters; multiple paginators use distinct page names* (raised here for the project's paginate-at-10 convention, C12). |
| **Where** | `DepartmentSlaController.php:32` (dead `index`) and `:188` (live `trashed()`). |
| **Root cause** | Both paginate at 15; the live trash list is the one that matters. Neither passes a distinct `pageName`. |
| **Consequence** | The trash list shows 15 rows instead of the 10 the UI standard specifies; low impact while the trash list is the only live paginator here. |
| **Reproduce** | Open `/complaint/department-sla/trash/view` with more than 10 trashed rows. |
| **Fix approach** | Change `paginate(15)` to `paginate(10)` on the live `trashed()` list (and on `index()` if DSLA-06's dead method is ever revived). |
| **Plan item** | DSLA-13 in `02-fix-plan.md` §6 |

```php
// DepartmentSlaController.php:182-188 — CURRENT (trashed)
        $slas = DepartmentSla::onlyTrashed()->with([
            'category',
            'subCategory',
            'targetRole',
            'targetUser',
            'targetUserType'
        ])->paginate(15);
```

**Evidence**
```
$ grep -n "paginate(15)" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php
32:        ])->paginate(15);
188:        ])->paginate(15);
```

F9 other checks: no query inside a loop (clean, QRY-01); `index`/`trashed` eager-load their relations (clean, VIEW-02/N+1); no raw SQL (clean, QRY-11).

### F10 — Views

#### DSLA-14 · L · VIEW-02 — the trash view prints a raw foreign-key id

| Field | Value |
|---|---|
| **Rule** | VIEW-02 (L) — *relations used inside `@foreach` are eager-loaded by the controller.* |
| **Where** | `Modules/Complaint/resources/views/complaint/department-sla/trash.blade.php:41`; controller `trashed()` at `DepartmentSlaController.php:182-188` |
| **Root cause** | The trash index prints `{{ $sla->target_department_id ?? '-' }}` (the numeric id) while the live list and the show page print `$sla->targetDepartment?->name`. `trashed()` does not eager-load `targetDepartment`, so the friendly value is not available. |
| **Consequence** | Trashed rows show "3" instead of "Transport", inconsistent with the active list and confusing to the admin. |
| **Reproduce** | Open `/complaint/department-sla/trash/view`. |
| **Fix approach** | Eager-load `targetDepartment` in `trashed()` and print `$sla->targetDepartment?->name ?? '-'`. |
| **Plan item** | DSLA-14 in `02-fix-plan.md` §7 |

```php
// trash.blade.php:40-41 — CURRENT
                                        {{-- Target Department --}}
                                        <td>{{ $sla->target_department_id ?? '-' }}</td>
```

**Evidence**
```
$ grep -n "target_department_id\|targetDepartment" Modules/Complaint/resources/views/complaint/department-sla/trash.blade.php Modules/Complaint/resources/views/complaint/department-sla/index.blade.php
Modules/Complaint/resources/views/complaint/department-sla/trash.blade.php:41:                                        <td>{{ $sla->target_department_id ?? '-' }}</td>
Modules/Complaint/resources/views/complaint/department-sla/index.blade.php:87:                            <td class="">{{ $sla->targetDepartment?->name ?? '-' }}</td>
```

F10 other checks: no queries in Blade (clean, VIEW-01); no `{!! !!}` on user text (clean, VIEW-03); row actions use `x-backend.table.action` and trashed rows use `action-trashed` (clean); the index partial is `@include`d by `complaint/index.blade.php:24` and receives `$slasExport`/`$slaCategories`/`$slaDepartments`/`$groups` from `ComplaintController@index` (clean). `show.blade.php:109-158` carries commented-out markup (style, see DSLA-16 note).

### F11 — Security and tenancy

clean — `grep -nE "env\(|\\?\\? 1|dd\(|dump\(" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php` → no output; models are tenant-scoped and routes carry `InitializeTenancyByDomain` + `EnsureTenantHasModule` (see §4).

### F12 — Style

#### DSLA-15 · L · STY-02 / STY-01 — the controller is not Pint-clean and has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)*; STY-01 (L) — *`declare(strict_types=1);`*. |
| **Where** | `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php` (file-wide) |
| **Root cause** | `pint --test` fails on `concat_space`, `trailing_comma_in_multiline`, `ordered_imports`, `binary_operator_spaces`; the file has no `declare(strict_types=1);`. |
| **Consequence** | No runtime effect; inconsistent with the codebase's enforced style. |
| **Reproduce** | Run the Verify command. |
| **Fix approach** | One style item for this file (run Pint + add `strict_types`). |
| **Plan item** | DSLA-15 in `02-fix-plan.md` §8 |

```php
// DepartmentSlaController.php:1-6 — CURRENT
<?php

namespace Modules\Complaint\Http\Controllers;

use App\Http\Controllers\Controller;
```

**Evidence**
```
$ vendor\bin\pint --test Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Complaint\\app\\Http\\Controllers\\DepartmentSlaController.php","fixers":["concat_space","trailing_comma_in_multiline","ordered_imports","binary_operator_spaces"]}]}
```

#### DSLA-16 · L · STY-02 / STY-01 / STY-04 — model is not Pint-clean, no `strict_types`, carries commented-out code

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) / STY-01 (L) / STY-04 (L) — *Pint-clean, `strict_types`, no commented-out code.* |
| **Where** | `Modules/Complaint/app/Models/DepartmentSla.php` — `:30`, `:48-57`, `:133-143` and file-wide |
| **Root cause** | `pint --test` fails on `no_trailing_whitespace`, `no_unused_imports`, `no_extra_blank_lines`, `ordered_imports`; no `strict_types`; and two blocks of commented-out `$fillable` fields and relation methods remain. |
| **Consequence** | No runtime effect; dead commented code misleads readers about available columns/relations. |
| **Reproduce** | Run the Verify command. |
| **Fix approach** | One style item for this file (Pint + `strict_types` + delete the commented-out blocks). |
| **Plan item** | DSLA-16 in `02-fix-plan.md` §8 |

```php
// DepartmentSla.php:48-57 — CURRENT (commented-out code)
        // 'escalation_l1_role_id',        
        // 'escalation_l1_user_id',        
        // 'escalation_l2_role_id',        
        // 'escalation_l2_user_id',        
        // 'escalation_l3_role_id',        
        // 'escalation_l3_user_id',        
        // 'escalation_l4_role_id',        
        // 'escalation_l4_user_id',        
        // 'escalation_l5_role_id',        
        // 'escalation_l5_user_id',        
```

**Evidence**
```
$ vendor\bin\pint --test Modules/Complaint/app/Models/DepartmentSla.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Complaint\\app\\Models\\DepartmentSla.php","fixers":["no_trailing_whitespace","no_unused_imports","no_extra_blank_lines","ordered_imports"]}]}
```

#### DSLA-17 · L · STY-02 / STY-01 — the FormRequest is not Pint-clean and has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) / STY-01 (L). |
| **Where** | `Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php` (file-wide) |
| **Root cause** | `pint --test` fails on `fully_qualified_strict_types`, `ordered_imports`; no `declare(strict_types=1);`. |
| **Consequence** | No runtime effect. |
| **Reproduce** | Run the Verify command. |
| **Fix approach** | One style item for this file. |
| **Plan item** | DSLA-17 in `02-fix-plan.md` §8 |

```php
// DepartmentSlaRequest.php:1-7 — CURRENT
<?php

namespace Modules\Complaint\Http\Requests;

use App\Traits\AuthorizesTenantFeature;
use Illuminate\Foundation\Http\FormRequest;
```

**Evidence**
```
$ vendor\bin\pint --test Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Complaint\\app\\Http\\Requests\\DepartmentSlaRequest.php","fixers":["fully_qualified_strict_types","ordered_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

#### DSLA-18 · L · F13 deep-read #8 — the five escalation entity-group columns are write-only

| Field | Value |
|---|---|
| **Rule** | F13 deep-read #8 (L) — *dead feature: saved data no consumer reads.* (No numbered rulebook ID matches; this is the deep-read checklist item 8.) |
| **Where** | `DepartmentSlaRequest.php:75-79` (validated), `DepartmentSla.php:59-63` (`$fillable`), `create.blade.php:180-192` / `edit.blade.php:242-260` (the Level 1–5 selects) |
| **Root cause** | The five `escalation_l1..l5_entity_group_id` values are collected, validated and stored, but no code reads them. The escalation engine `EscalateComplaints` uses only the hour columns (`dept_escalation_hours_l1..l5`) and never the group ids; unlike `ComplaintCategory`, `DepartmentSla` declares no `escalationLXGroup()` relation. |
| **Consequence** | An admin fills in five escalation groups that do nothing — the saved configuration is never applied to any notification or assignment. |
| **Reproduce** | Set the Level 1–5 groups on an SLA, then run `php artisan complaints:escalate` — the groups have no effect. |
| **Fix approach** | Product decision: either wire the groups into the escalation/notification flow or remove the five selects and columns. Not fixed here. |
| **Plan item** | none — see plan §10 |

```php
// DepartmentSla.php:59-63 — CURRENT (stored, never read)
        'escalation_l1_entity_group_id',
        'escalation_l2_entity_group_id',
        'escalation_l3_entity_group_id',
        'escalation_l4_entity_group_id',
        'escalation_l5_entity_group_id',
```

**Evidence**
```
$ grep -rn "escalation_l[1-5]_entity_group_id" Modules/Complaint/app/Models/DepartmentSla.php Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php
Modules/Complaint/app/Models/DepartmentSla.php:59:        'escalation_l1_entity_group_id',
Modules/Complaint/app/Models/DepartmentSla.php:60:        'escalation_l2_entity_group_id',
Modules/Complaint/app/Models/DepartmentSla.php:61:        'escalation_l3_entity_group_id',
Modules/Complaint/app/Models/DepartmentSla.php:62:        'escalation_l4_entity_group_id',
Modules/Complaint/app/Models/DepartmentSla.php:63:        'escalation_l5_entity_group_id',
Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php:75:            'escalation_l1_entity_group_id' => 'nullable|exists:sch_entity_groups,id',
Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php:76:            'escalation_l2_entity_group_id' => 'nullable|exists:sch_entity_groups,id',
Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php:77:            'escalation_l3_entity_group_id' => 'nullable|exists:sch_entity_groups,id',
Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php:78:            'escalation_l4_entity_group_id' => 'nullable|exists:sch_entity_groups,id',
Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php:79:            'escalation_l5_entity_group_id' => 'nullable|exists:sch_entity_groups,id',
(no consumer in any service/command/controller in Modules/Complaint/app)
```

**F13 answers — one row per mutating method**

| Method | 1 overwrite? | 2 delete-before-store? | 3 duplicate impl? | 4 soft-delete×unique? | 5 race? | 6 auth hole? | 7 lying message? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | DSLA-09 | DSLA-04 | DSLA-02 | ok | ok | ok |
| `update` | ok | ok | DSLA-09 | DSLA-04 | DSLA-02 | ok | ok | ok |
| `destroy` (soft) | ok | ok | ok | DSLA-04 | ok | ok | ok | ok |
| `restore` | ok | ok | ok | DSLA-04 | ok | ok | ok | ok |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |
| (model, all writes) | ok | ok | ok | DSLA-04 | DSLA-02 | ok | ok | DSLA-18 |

Notes: (1) `update()` captures `$sla->getOriginal()` before the write and diffs `getChanges()` — no unintended overwrite. (2) `forceDelete()` is irreversible but deletes no files and is wrapped in a rollback-able transaction — no order problem. (7) success flashes are generic, not false.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/GlobalMaster/Models/Dropdown.php:106` | `hasMany(DepartmentSla::class, 'target_user_type_id')` references a column `cmp_department_sla` does not have (see DSLA-10). | MDL-07 | owner of `Dropdown` (GlobalMaster) |
| `Modules/Complaint/app/Console/Commands/EscalateComplaints.php:89-107` | `resolveDepartmentSla()` matches only `complaint_category_id` (+ one of department/role/user) and ignores the sub-category and the vehicle/vendor/entity-group/designation targets — an SLA scoped to a sub-category is applied to the whole parent category. Not owned by this controller. | SVC-04 | Complaint module maintainer |
| `config/permissionslist.php` / every method | Permission strings are repeated as literals in the controller, the FormRequest and the blades (AUTH-06). This is the app-wide pattern with no policy layer; a mechanical refactor, deferred. | AUTH-06 | cross-cutting |

## 8. Not covered, and why

- **No live STORE/UPDATE/DELETE was executed** — this audit is read-only (protocol §1). Mutation behaviour is proven from code, the migration, and the FormRequest's executed validation SQL, not by writing rows.
- **The scanner and self-check were skipped because the tools are missing.** Per Tarun's tooling override, `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` do not exist and `_tools/scan.php` must not be run, so the F1–F13 checklist was done manually with `read`/`grep` and the commands quoted above. No scanner output is available in this report.
- **Queue/jobs and the escalation command were not run** (D4: no tests). The dead-feature finding DSLA-18 rests on a static read of all `Modules/Complaint/app` consumers.
- **The `ComplaintCategory` model and the other-module master models were not audited** — they are owned elsewhere or common (§4.2/§5); only this controller's usage of them was checked.
- **The live SLA tab (`ComplaintController@index`) was not audited** — it belongs to `ComplaintController` (index row CLAIMED). Only the `department-sla` partial's data contract was verified.
