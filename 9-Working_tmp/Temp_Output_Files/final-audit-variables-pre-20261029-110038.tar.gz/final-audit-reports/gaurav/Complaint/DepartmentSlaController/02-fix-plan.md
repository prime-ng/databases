# Fix Plan — Complaint / DepartmentSlaController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

> ⚠ **Overlapping items.** DSLA-01, DSLA-07, DSLA-09 all edit `store`/`update`/`edit`; DSLA-10 and DSLA-14 both edit the eager-load list in `trashed()`. Apply in plan order and re-read the file before each edit (final-audit.md §9.2 #3). Every **Before** block below is the code as it exists **today**; if an earlier item already changed it, apply the same transformation to the current code.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Complaint/routes/web.php` | shared route file — the `restore` verb change is a DECISION (DSLA-05); routes are never edited by the fixer |
| `config/permissionslist.php` | shared config — no permission change is needed (all names already exist and are seeded) |
| `resources/views/components/**`, `resources/views/layouts/**` | shared UI components |
| `Modules/Complaint/app/Models/ComplaintCategory.php` | owned by `gaurav/Complaint/ComplaintCategoryController` |
| `Modules/GlobalMaster/Models/Dropdown.php` | other-module model (cross-cutting note §7) |
| `Modules/Complaint/app/Console/Commands/EscalateComplaints.php` | cross-cutting note §7, not this controller |
| `database/migrations/**` | existing migrations are never edited (a new migration is a DECISION — DSLA-02) |

## 1. Blockers reachable today

None. There is no B-severity finding. The two H findings (DSLA-02, DSLA-05) are DECISION items and live in §9.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **DSLA-01** · M · ERR-00 (D1) · `DepartmentSlaController.php:56-307` — remove the six `try/catch` blocks so errors reach the central handler; keep `DB::transaction` + `activityLog`.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Before** (`store`, `DepartmentSlaController.php:56-77`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.create');

        try {
            DB::transaction(function () use ($request) {
                $sla = DepartmentSla::create($request->validated());

                activityLog($sla, 'Stored', [
                    'message'      => 'Department SLA created.',
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });
        } catch (\Throwable $e) {
            Log::error('Department SLA create failed: ' . $e->getMessage(), [
                'exception' => get_class($e),
            ]);

            return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'sla'])
                ->with('error', flash('operation_failed.department_sla', 'Failed to create the department SLA.'));
        }

        return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'sla'])
            ->with('success', 'Department SLA created successfully.');
    ```
  - **After** (`store`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.create');

        DB::transaction(function () use ($request) {
            $sla = DepartmentSla::create($request->validated());

            activityLog($sla, 'Stored', [
                'message'      => 'Department SLA created.',
                'performed_by' => Auth::user()->name ?? null,
            ]);
        });

        return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'sla'])
            ->with('success', 'Department SLA created successfully.');
    ```
  - **Before** (`update`, `DepartmentSlaController.php:106-143`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.update');

        $sla = DepartmentSla::findOrFail($id);
        $original = $sla->getOriginal();

        try {
            DB::transaction(function () use ($request, $sla, $original) {
                $sla->update($request->validated());

                $changes = [];
                foreach ($sla->getChanges() as $field => $newValue) {
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                activityLog($sla, 'Updated', [
                    'message'      => 'Department SLA updated.',
                    'changes'      => $changes,
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });
        } catch (\Throwable $e) {
            Log::error('Department SLA update failed: ' . $e->getMessage(), [
                'id' => $id,
                'exception' => get_class($e),
            ]);

            return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'sla'])
                ->with('error', flash('operation_failed.department_sla', 'Failed to update the department SLA.'));
        }

        return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'sla'])
            ->with('success', 'Department SLA updated successfully.');
    ```
  - **After** (`update`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.update');

        $sla = DepartmentSla::findOrFail($id);
        $original = $sla->getOriginal();

        DB::transaction(function () use ($request, $sla, $original) {
            $sla->update($request->validated());

            $changes = [];
            foreach ($sla->getChanges() as $field => $newValue) {
                if ($field === 'updated_at') {
                    continue;
                }
                $changes[$field] = [
                    'old' => $original[$field] ?? null,
                    'new' => $newValue,
                ];
            }

            activityLog($sla, 'Updated', [
                'message'      => 'Department SLA updated.',
                'changes'      => $changes,
                'performed_by' => Auth::user()->name ?? null,
            ]);
        });

        return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'sla'])
            ->with('success', 'Department SLA updated successfully.');
    ```
  - **Before** (`destroy`, `DepartmentSlaController.php:148-172`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.delete');

        $sla = DepartmentSla::findOrFail($id);

        try {
            DB::transaction(function () use ($sla) {
                $sla->delete();

                activityLog($sla, 'Deleted', [
                    'message'      => 'Department SLA deleted.',
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });
        } catch (\Throwable $e) {
            Log::error('Department SLA delete failed: ' . $e->getMessage(), [
                'id' => $id,
                'exception' => get_class($e),
            ]);

            return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'sla'])
                ->with('error', flash('operation_failed.department_sla', 'Failed to delete the department SLA.'));
        }

        return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'sla'])
            ->with('success', 'Department SLA deleted successfully.');
    ```
  - **After** (`destroy`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.delete');

        $sla = DepartmentSla::findOrFail($id);

        DB::transaction(function () use ($sla) {
            $sla->delete();

            activityLog($sla, 'Deleted', [
                'message'      => 'Department SLA deleted.',
                'performed_by' => Auth::user()->name ?? null,
            ]);
        });

        return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'sla'])
            ->with('success', 'Department SLA deleted successfully.');
    ```
  - **Before** (`restore`, `DepartmentSlaController.php:198-222`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.restore');

        $sla = DepartmentSla::onlyTrashed()->findOrFail($id);

        try {
            DB::transaction(function () use ($sla) {
                $sla->restore();

                activityLog($sla, 'Restored', [
                    'message'      => 'Department SLA restored.',
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });
        } catch (\Throwable $e) {
            Log::error('Department SLA restore failed: ' . $e->getMessage(), [
                'id' => $id,
                'exception' => get_class($e),
            ]);

            return redirect()->route('complaint.department-sla.trashed')
                ->with('error', flash('operation_failed.department_sla', 'Failed to restore the department SLA.'));
        }

        return redirect()->route('complaint.department-sla.trashed')
            ->with('success', 'Department SLA restored successfully.');
    ```
  - **After** (`restore`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.restore');

        $sla = DepartmentSla::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($sla) {
            $sla->restore();

            activityLog($sla, 'Restored', [
                'message'      => 'Department SLA restored.',
                'performed_by' => Auth::user()->name ?? null,
            ]);
        });

        return redirect()->route('complaint.department-sla.trashed')
            ->with('success', 'Department SLA restored successfully.');
    ```
  - **Before** (`forceDelete`, `DepartmentSlaController.php:230-254`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.forceDelete');

        $sla = DepartmentSla::onlyTrashed()->findOrFail($id);

        try {
            DB::transaction(function () use ($sla) {
                $sla->forceDelete();

                activityLog($sla, 'Force Deleted', [
                    'message'      => 'Department SLA permanently deleted.',
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });
        } catch (\Throwable $e) {
            Log::error('Department SLA force delete failed: ' . $e->getMessage(), [
                'id' => $id,
                'exception' => get_class($e),
            ]);

            return redirect()->route('complaint.department-sla.trashed')
                ->with('error', flash('operation_failed.department_sla', 'Failed to permanently delete the department SLA.'));
        }

        return redirect()->route('complaint.department-sla.trashed')
            ->with('success', 'Department SLA permanently deleted.');
    ```
  - **After** (`forceDelete`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.forceDelete');

        $sla = DepartmentSla::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($sla) {
            $sla->forceDelete();

            activityLog($sla, 'Force Deleted', [
                'message'      => 'Department SLA permanently deleted.',
                'performed_by' => Auth::user()->name ?? null,
            ]);
        });

        return redirect()->route('complaint.department-sla.trashed')
            ->with('success', 'Department SLA permanently deleted.');
    ```
  - **Before** (`toggleStatus`, `DepartmentSlaController.php:273-307`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.update');

        $request->validate([
            'is_active' => 'required|boolean',
        ]);

        $sla = DepartmentSla::withTrashed()->findOrFail($id);

        try {
            DB::transaction(function () use ($request, $sla) {
                $sla->is_active = (bool) $request->is_active;
                $sla->save();

                activityLog($sla, 'Toggled', [
                    'message'      => 'Department SLA status toggled.',
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });
        } catch (\Throwable $e) {
            Log::error('Department SLA toggle failed: ' . $e->getMessage(), [
                'id' => $id,
                'exception' => get_class($e),
            ]);

            return response()->json([
                'success'   => false,
                'message'   => 'Failed to change the status of the department SLA.',
            ], 500);
        }

        return response()->json([
            'success'   => true,
            'is_active' => $sla->is_active,
            'message'   => 'Department SLA status updated successfully.',
        ]);
    ```
  - **After** (`toggleStatus`):
    ```php
        Gate::authorize('tenant.complaint.department-sla.update');

        $request->validate([
            'is_active' => 'required|boolean',
        ]);

        $sla = DepartmentSla::withTrashed()->findOrFail($id);

        DB::transaction(function () use ($request, $sla) {
            $sla->is_active = (bool) $request->is_active;
            $sla->save();

            activityLog($sla, 'Toggled', [
                'message'      => 'Department SLA status toggled.',
                'performed_by' => Auth::user()->name ?? null,
            ]);
        });

        return response()->json([
            'success'   => true,
            'is_active' => $sla->is_active,
            'message'   => 'Department SLA status updated successfully.',
        ]);
    ```
  - **Also remove** the now-unused import (`DepartmentSlaController.php:10`):
    - **Before:**
      ```php
      use Illuminate\Support\Facades\Log;
      ```
    - **After:** (delete the line)
      ```php
      ```
  - **Verify:** `grep -n "try {\|getMessage()" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Expect:** no output.
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **DSLA-03** · L · AUTH-04 · `Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php:11,16-22` — stop authorizing the same permission twice; the controller's `Gate::authorize` stays the single check.
  - **Touches:** `Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php`
  - **Before** (`DepartmentSlaRequest.php:5-22`):
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;

    class DepartmentSlaRequest extends FormRequest
    {
        use AuthorizesTenantFeature;

        /**
         * Determine if the user is authorized to make this request.
         */
        public function authorize(): bool
        {
            // T6b — mirrors the controller's own gate: tenant.department-sla.create on POST,
            // tenant.department-sla.update on PUT/PATCH. Same permission, checked one step
            // earlier, so this narrows nothing and widens nothing.
            return $this->authorizeByCrudPermission('tenant.complaint.department-sla');
        }
    ```
  - **After:**
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;

    class DepartmentSlaRequest extends FormRequest
    {
        /**
         * Determine if the user is authorized to make this request.
         *
         * DSLA-03 (2026-10-17): authorization lives in the controller's
         * Gate::authorize(). This used to repeat the same permission check.
         */
        public function authorize(): bool
        {
            return true;
        }
    ```
  - **Verify:** `grep -n "AuthorizesTenantFeature\|authorizeByCrudPermission" Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php`
  - **Expect:** no output.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7) and controller shape (F6)

- [ ] **DSLA-06** · M · RTE-03 · `DepartmentSlaController.php:24-35` — disable the unrouted `index()` per D5.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Before** (`DepartmentSlaController.php:24-35`):
    ```php
        public function index()
        {
            Gate::authorize('tenant.complaint.department-sla.viewAny');
            $slas = DepartmentSla::with([
                'category',
                'subCategory',
                'targetRole',
                'targetUser'
            ])->paginate(15);

            return view('complaint::complaint.department-sla.index', compact('slas'));
        }
    ```
  - **After:**
    ```php
        public function index()
        {
            // NOT ROUTED (final-audit.md D5). GET /complaint/department-sla is served by
            // ComplaintController@index (routes/web.php:68) and the resource is registered
            // ->except(['index']) (routes/web.php:69). Kept, not deleted. If it is ever
            // routed it must also pass $slasExport, $slaCategories, $slaDepartments and
            // $groups, which the included partial reads.
            abort(403, 'This action is not routed.');
        }
    ```
  - **Verify:** `grep -n "This action is not routed" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Expect:** one hit at the `index` body.
  - **Effort:** S

- [ ] **DSLA-07** · M · CTL-03 · `DepartmentSlaController.php:80,104,146,259` — use route model binding for the four resource methods.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Before** (`edit`, `DepartmentSlaController.php:80-84`):
    ```php
        public function edit($id)
        {
            Gate::authorize('tenant.complaint.department-sla.update');

            $sla = DepartmentSla::findOrFail($id);
    ```
  - **After** (`edit`):
    ```php
        public function edit(DepartmentSla $departmentSla)
        {
            Gate::authorize('tenant.complaint.department-sla.update');

            $sla = $departmentSla;
    ```
  - **Before** (`update`, `DepartmentSlaController.php:104-108`):
    ```php
        public function update(DepartmentSlaRequest $request, $id)
        {
            Gate::authorize('tenant.complaint.department-sla.update');

            $sla = DepartmentSla::findOrFail($id);
    ```
  - **After** (`update`):
    ```php
        public function update(DepartmentSlaRequest $request, DepartmentSla $departmentSla)
        {
            Gate::authorize('tenant.complaint.department-sla.update');

            $sla = $departmentSla;
    ```
  - **Before** (`destroy`, `DepartmentSlaController.php:146-150`):
    ```php
        public function destroy($id)
        {
            Gate::authorize('tenant.complaint.department-sla.delete');

            $sla = DepartmentSla::findOrFail($id);
    ```
  - **After** (`destroy`):
    ```php
        public function destroy(DepartmentSla $departmentSla)
        {
            Gate::authorize('tenant.complaint.department-sla.delete');

            $sla = $departmentSla;
    ```
  - **Before** (`show`, `DepartmentSlaController.php:259-263`):
    ```php
        public function show($id)
        {
            Gate::authorize('tenant.complaint.department-sla.view');

            $sla = DepartmentSla::findOrFail($id);
    ```
  - **After** (`show`):
    ```php
        public function show(DepartmentSla $departmentSla)
        {
            Gate::authorize('tenant.complaint.department-sla.view');

            $sla = $departmentSla;
    ```
  - **Verify:** `grep -n "public function edit(\|public function update(\|public function destroy(\|public function show(" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Expect:** each signature now contains `DepartmentSla $departmentSla` and none contains `$id`.
  - **Effort:** M

- [ ] **DSLA-09** · M · CTL-05 · `DepartmentSlaController.php:37-52,90-101` — extract the dropdown payload shared by `create()` and `edit()`.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Before** (`create`, `DepartmentSlaController.php:37-52`):
    ```php
        public function create()
        {
            Gate::authorize('tenant.complaint.department-sla.create');

            return view('complaint::complaint.department-sla.create', [
                'categories' => ComplaintCategory::parents()->get(),
                'subCategories' => collect(),
                'roles' => Role::all(),
                'users' => User::all(),
                'departments' => Department::all(),
                'designations' => Designation::all(),
                'entityGroups' => EntityGroup::all(),
                'vehicles' => Vehicle::all(),
                'vendors' => Vendor::all(),
            ]);
        }
    ```
  - **After** (`create` + new private helper):
    ```php
        public function create()
        {
            Gate::authorize('tenant.complaint.department-sla.create');

            return view('complaint::complaint.department-sla.create', [
                'subCategories' => collect(),
            ] + $this->formDropdowns());
        }

        /**
         * Dropdown sources shared by create() and edit().
         *
         * @return array<string, \Illuminate\Support\Collection>
         */
        private function formDropdowns(): array
        {
            return [
                'categories' => ComplaintCategory::parents()->get(),
                'roles' => Role::all(),
                'users' => User::all(),
                'departments' => Department::all(),
                'designations' => Designation::all(),
                'entityGroups' => EntityGroup::all(),
                'vehicles' => Vehicle::all(),
                'vendors' => Vendor::all(),
            ];
        }
    ```
  - **Before** (`edit` return, `DepartmentSlaController.php:90-101`):
    ```php
            return view('complaint::complaint.department-sla.edit', [
                'sla' => $sla,
                'categories' => ComplaintCategory::parents()->get(),
                'subCategories' => $subCategories,
                'roles' => Role::all(),
                'users' => User::all(),
                'departments' => Department::all(),
                'designations' => Designation::all(),
                'entityGroups' => EntityGroup::all(),
                'vehicles' => Vehicle::all(),
                'vendors' => Vendor::all(),
            ]);
    ```
  - **After** (`edit` return):
    ```php
            return view('complaint::complaint.department-sla.edit', [
                'sla' => $sla,
                'subCategories' => $subCategories,
            ] + $this->formDropdowns());
    ```
  - **Verify:** `grep -n "formDropdowns" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Expect:** three hits (the method declaration and two call sites).
  - **Effort:** S

- [ ] **DSLA-10** · M · MDL-07 · `DepartmentSla.php:88-91` and `DepartmentSlaController.php:182-188` — remove the relation that points at a column which does not exist.
  - **Touches:** `Modules/Complaint/app/Models/DepartmentSla.php`, `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Before** (`DepartmentSla.php:86-91`):
    ```php
        // Target resolution context
        public function targetUserType()
        {
            return $this->belongsTo(Dropdown::class, 'target_user_type_id');
        }
    ```
  - **After** (delete the block):
    ```php
        // Target resolution context
    ```
  - **Before** (`trashed`, `DepartmentSlaController.php:182-188`):
    ```php
            $slas = DepartmentSla::onlyTrashed()->with([
                'category',
                'subCategory',
                'targetRole',
                'targetUser',
                'targetUserType'
            ])->paginate(15);
    ```
  - **After** (`trashed`):
    ```php
            $slas = DepartmentSla::onlyTrashed()->with([
                'category',
                'subCategory',
                'targetRole',
                'targetUser'
            ])->paginate(15);
    ```
  - **Verify:** `grep -n "targetUserType" Modules/Complaint/app/Models/DepartmentSla.php Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **DSLA-12** · M · QRY-15 / QRY-03 · `DepartmentSlaController.php:45,95` — stop loading every user (5,630 rows) into the form dropdown.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Before** (the `users` line; two occurrences today, one after DSLA-09):
    ```php
                'users' => User::all(),
    ```
  - **After:**
    ```php
                'users' => User::whereIn('user_type', ['EMPLOYEE', 'TEACHER', 'PRIME', 'SYSTEM'])
                    ->select('id', 'name')
                    ->get(),
    ```
  - **Verify:** `grep -n "User::all()" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **DSLA-13** · L · QRY-13 (C12) · `DepartmentSlaController.php:188` — paginate the live trash list at 10.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Before** (`DepartmentSlaController.php:188`):
    ```php
            ])->paginate(15);
    ```
  - **After:**
    ```php
            ])->paginate(10);
    ```
  - **Verify:** `grep -n "paginate(15)" Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

- [ ] **DSLA-14** · L · VIEW-02 · `trash.blade.php:41` + `DepartmentSlaController.php:182-188` — show the department name, not its id.
  - **Touches:** `Modules/Complaint/resources/views/complaint/department-sla/trash.blade.php`, `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Before** (`trash.blade.php:40-41`):
    ```php
                                        {{-- Target Department --}}
                                        <td>{{ $sla->target_department_id ?? '-' }}</td>
    ```
  - **After** (`trash.blade.php`):
    ```php
                                        {{-- Target Department --}}
                                        <td>{{ $sla->targetDepartment?->name ?? '-' }}</td>
    ```
  - **Before** (`trashed` eager load, `DepartmentSlaController.php:182-188`):
    ```php
            $slas = DepartmentSla::onlyTrashed()->with([
                'category',
                'subCategory',
                'targetRole',
                'targetUser',
                'targetUserType'
            ])->paginate(15);
    ```
  - **After** (`trashed` eager load):
    ```php
            $slas = DepartmentSla::onlyTrashed()->with([
                'category',
                'subCategory',
                'targetRole',
                'targetUser',
                'targetDepartment'
            ])->paginate(15);
    ```
  - **Verify:** `grep -n "targetDepartment" Modules/Complaint/resources/views/complaint/department-sla/trash.blade.php`
  - **Expect:** one hit showing `$sla->targetDepartment?->name`.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **DSLA-15** · L · STY-01 / STY-02 · `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php` — add `strict_types` and make the file Pint-clean.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php`
  - **Before** (`DepartmentSlaController.php:1-3`):
    ```php
    <?php

    namespace Modules\Complaint\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Http\Controllers;
    ```
  - **Verify:** `vendor\bin\pint --test Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php --format agent`
  - **Expect:** `result: pass, no formatting errors` (run Pint on the file first — `vendor\bin\pint Modules/Complaint/app/Http/Controllers/DepartmentSlaController.php --format agent`).
  - **Effort:** S

- [ ] **DSLA-16** · L · STY-01 / STY-02 / STY-04 · `DepartmentSla.php` — add `strict_types`, make it Pint-clean, delete commented-out code, and add the relation return types from DSLA-11.
  - **Touches:** `Modules/Complaint/app/Models/DepartmentSla.php`
  - **Before** (`DepartmentSla.php:1-3`):
    ```php
    <?php

    namespace Modules\Complaint\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Models;
    ```
  - Also: delete the commented-out `$fillable` block at `:30` and `:48-57`, delete the commented-out relation block at `:133-143`, and add `: BelongsTo` to the ten relation methods at `:77-131` (import `Illuminate\Database\Eloquent\Relations\BelongsTo`).
  - **Verify:** `vendor\bin\pint --test Modules/Complaint/app/Models/DepartmentSla.php --format agent`
  - **Expect:** `result: pass, no formatting errors` (run Pint on the file first).
  - **Effort:** S

- [ ] **DSLA-17** · L · STY-01 / STY-02 · `Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php` — add `strict_types` and make the file Pint-clean.
  - **Touches:** `Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php`
  - **Before** (`DepartmentSlaRequest.php:1-3`):
    ```php
    <?php

    namespace Modules\Complaint\Http\Requests;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Http\Requests;
    ```
  - **Verify:** `vendor\bin\pint --test Modules/Complaint/app/Http/Requests/DepartmentSlaRequest.php --format agent`
  - **Expect:** `result: pass, no formatting errors` (run Pint on the file first).
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **DSLA-02** · H · DECISION · TXN-06 — add a unique index so concurrent saves cannot create duplicate SLAs?
  - **Why it is a decision:** new additive tenant migration; running it is Tarun's hand (`php artisan tenants:migrate`). Must be decided together with DSLA-04.
  - (a) ⭐ **Add a unique index over the eight composite columns** (`complaint_category_id, complaint_subcategory_id, target_department_id, target_designation_id, target_role_id, target_entity_group_id, target_user_id, target_vehicle_id, target_vendor_id`) in a new migration `database/migrations/tenant/2026_10_17_add_unique_index_to_cmp_department_sla.php`, then confirm the FormRequest rule mirrors it. Closes the race.
  - (b) Leave the check in PHP only and accept that duplicates are possible under concurrency.
  - (c) Wrap `store`'s check in a transaction with `lockForUpdate()` (partial mitigation; needs a matching index to be fully safe).
  - ➜ Choice: ____

- [ ] **DSLA-04** · M · DECISION · VAL-04 — should a soft-deleted SLA block re-creating the same configuration?
  - **Why it is a decision:** behaviour change + migration; pairs with DSLA-02.
  - (a) ⭐ **Exclude trashed rows** — add `->whereNull('deleted_at')` to the uniqueness rule and make the DSLA-02 index partial on `deleted_at IS NULL`; then a re-create after a soft-delete succeeds and the old trashed row stays until restored/purged.
  - (b) **Keep counting trashed rows** — leave the rule as-is and document that an SLA must be restored, not re-created, for the same target.
  - (c) On `store`, if a trashed match exists, restore it instead of inserting.
  - ➜ Choice: ____

- [ ] **DSLA-05** · H · DECISION · RTE-01 — change the `restore` route from GET to a state-changing verb.
  - **Why it is a decision:** touches the shared route file and the trash view's action; a route verb change.
  - (a) ⭐ **Make it `PATCH`** — register `Route::patch('department-sla/{id}/restore', [DepartmentSlaController::class, 'restore'])->name('department-sla.restore')` in `Modules/Complaint/routes/web.php` and update `resources/views/components/backend/table/action-trashed.blade.php`'s restore action to send `PATCH` (⚠ SHARED view component — needs its own explicit tick).
  - (b) **Make it `DELETE`** — same as (a) but `Route::delete('department-sla/{id}/restore', [DepartmentSlaController::class, 'restore'])` and a `@method('DELETE')` form.
  - (c) Leave GET and accept the CSRF/prefetch risk.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| DSLA-08 | L · CTL-04 — return types are folded into the rewrites in DSLA-01, DSLA-06, DSLA-07 and DSLA-09 (each After block is written without a return type today to stay minimal; add `: RedirectResponse` / `: View` / `: JsonResponse` when applying them). |
| DSLA-11 | L · MDL-04 — relation return types are folded into DSLA-16 (the model style item adds `: BelongsTo`). |
| DSLA-18 | L · F13 deep-read #8 — the five escalation entity-group columns are write-only. Wiring them into the escalation/notification flow (or removing the selects) is a product decision, out of scope for this pass. |
