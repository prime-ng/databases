# Fix Plan — Complaint / ComplaintReportController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | shared config; no permission change is needed |
| `resources/views/components/backend/**` | shared backend components (`x-backend.layouts.app`, `x-backend.tab.search-bar`, `x-backend.components.breadcrum`) |
| `Modules/Complaint/app/Models/ComplaintCategory.php` | owned by `gaurav/Complaint/ComplaintCategoryController` (linked) |
| `Modules/Prime/app/Models/Dropdown.php`, `Modules/SchoolSetup/app/Models/Department.php` | other-module (common) models |
| `routes/**`, `Modules/Complaint/routes/**` | route files |
| any migration | standing rule: never edit an existing migration |

## 1. Blockers reachable today

- [ ] **CRPT-04** · B · MDL-07 (by analogy) · `ComplaintReportController.php:172` + `:139` — the SLA query selects `c.escalation_level`, which does not exist, so the page 500s.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`
  - **Before** (`ComplaintReportController.php:163-173`):
    ```php
            ->select(
                'c.ticket_no',
                DB::raw('COALESCE(u.name, "Unassigned") as assigned_to'),
                't.value as defendant_type',
                'c.target_name as defendant_name',
                'cat.name as complaint_category',
                'c.resolution_due_at',
                'c.actual_resolved_at',
                DB::raw('TIMESTAMPDIFF(HOUR, c.resolution_due_at, COALESCE(c.actual_resolved_at, NOW())) as delay_hours'),
                'c.escalation_level'
            );
    ```
  - **After:**
    ```php
            ->select(
                'c.ticket_no',
                DB::raw('COALESCE(u.name, "Unassigned") as assigned_to'),
                't.value as defendant_type',
                'c.target_name as defendant_name',
                'cat.name as complaint_category',
                'c.resolution_due_at',
                'c.actual_resolved_at',
                DB::raw('TIMESTAMPDIFF(HOUR, c.resolution_due_at, COALESCE(c.actual_resolved_at, NOW())) as delay_hours'),
                'c.current_escalation_level as escalation_level'
            );
    ```
  - **Before** (`ComplaintReportController.php:138-140`):
    ```php
        if ($escalationLevel) {
            $query->where('c.escalation_level', '>=', (int) $escalationLevel);
        } else {
    ```
  - **After:**
    ```php
        if ($escalationLevel) {
            $query->where('c.current_escalation_level', '>=', (int) $escalationLevel);
        } else {
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "'c\.escalation_level'"`
  - **Expect:** no output (only `'c.current_escalation_level as escalation_level'` remains).
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — the controller is read-only and has no try/catch.

## 4. Authorization (F3)

None — `Gate::authorize('tenant.complaint.complaint.viewAny')` already uses an existing, seeded permission.

## 5. Validation, routes, models (F4/F5/F7)

None.

## 6. Queries & performance (F9)

- [ ] **CRPT-05** · H · QRY-01 · `ComplaintReportController.php:439-461` — stop issuing 2–3 queries per hotspot row inside `->map()`.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`
  - **Before** (`ComplaintReportController.php:439-461`):
    ```php
        return $hotspotData->map(function ($row) {
            $mostActiveComplainant = DB::table('cmp_complaints')
                ->where('target_selected_id', $row->target_id)
                ->select('complainant_user_id', DB::raw('COUNT(*) as cnt'))
                ->groupBy('complainant_user_id')
                ->orderByDesc('cnt')
                ->first();

            $row->unique_complainant = $mostActiveComplainant ? $mostActiveComplainant->complainant_user_id : null;

            $mostCommonCategory = DB::table('cmp_complaints')
                ->where('target_selected_id', $row->target_id)
                ->select('category_id', DB::raw('COUNT(*) as cnt'))
                ->groupBy('category_id')
                ->orderByDesc('cnt')
                ->first();

            $row->most_common_issue = $mostCommonCategory
                ? DB::table('cmp_complaint_categories')->where('id', $mostCommonCategory->category_id)->value('name')
                : null;

            return $row;
        });
    ```
  - **After:**
    ```php
        $targetIds = $hotspotData->pluck('target_id')->all();

        $topComplainants = DB::table('cmp_complaints')
            ->whereIn('target_selected_id', $targetIds)
            ->select('target_selected_id', 'complainant_user_id', DB::raw('COUNT(*) as cnt'))
            ->groupBy('target_selected_id', 'complainant_user_id')
            ->orderByDesc('cnt')
            ->get()
            ->groupBy('target_selected_id')
            ->map(fn ($rows) => $rows->first()->complainant_user_id);

        $topCategories = DB::table('cmp_complaints')
            ->whereIn('target_selected_id', $targetIds)
            ->select('target_selected_id', 'category_id', DB::raw('COUNT(*) as cnt'))
            ->groupBy('target_selected_id', 'category_id')
            ->orderByDesc('cnt')
            ->get()
            ->groupBy('target_selected_id')
            ->map(fn ($rows) => $rows->first()->category_id);

        $categoryNames = DB::table('cmp_complaint_categories')
            ->whereIn('id', $topCategories->filter()->unique()->values()->all())
            ->pluck('name', 'id');

        return $hotspotData->map(function ($row) use ($topComplainants, $topCategories, $categoryNames) {
            $row->unique_complainant = $topComplainants->get($row->target_id);

            $categoryId = $topCategories->get($row->target_id);
            $row->most_common_issue = $categoryId ? ($categoryNames[$categoryId] ?? null) : null;

            return $row;
        });
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "->map\(function \(\`$row\)" `
  - **Expect:** one hit (the new in-memory map), and no `where('target_selected_id'` inside the loop.
  - **Effort:** M

- [ ] **CRPT-06** · H · QRY-02 · `ComplaintReportController.php:154, :437, :542` — cap the three unbounded report lists.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`
  - **Before** (`ComplaintReportController.php:154`):
    ```php
        return $query->orderByDesc('delay_hours')->get();
    ```
  - **After:**
    ```php
        return $query->orderByDesc('delay_hours')->limit(500)->get();
    ```
  - **Before** (`ComplaintReportController.php:435-437`):
    ```php
            ->orderByDesc('total_complaints')
            ->orderByDesc('avg_risk_score')
            ->get();
    ```
  - **After:**
    ```php
            ->orderByDesc('total_complaints')
            ->orderByDesc('avg_risk_score')
            ->limit(500)
            ->get();
    ```
  - **Before** (`ComplaintReportController.php:540-542`):
    ```php
            ->orderByDesc('ai.safety_risk_score')
            ->orderByDesc('ai.escalation_risk_score')
            ->get();
    ```
  - **After:**
    ```php
            ->orderByDesc('ai.safety_risk_score')
            ->orderByDesc('ai.escalation_risk_score')
            ->limit(500)
            ->get();
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "->limit\(500\)"`
  - **Expect:** 3 hits.
  - **Effort:** S

- [ ] **CRPT-07** · H · QRY-03 (+ deep-read #8) · `ComplaintReportController.php:305-308` and two blade option lines — make the filter dropdowns populate.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`, `Modules/Complaint/resources/views/reports/complaint-status/index.blade.php`, `Modules/Complaint/resources/views/reports/hotspot/index.blade.php`
  - **Before** (`ComplaintReportController.php:305-308`):
    ```php
            'statuses' => Dropdown::where('type', 'status')->get(),
            'priorities' => Dropdown::where('type', 'priority')->get(),
            'severities' => Dropdown::where('type', 'severity')->get(),
            'complainantTypes' => Dropdown::where('type', 'complainant_type')->get(),
    ```
  - **After:**
    ```php
            'statuses' => Dropdown::where('key', 'cmp_complaints.status_id')->get(['id', 'value']),
            'priorities' => Dropdown::where('key', 'cmp_complaint_categories.priority_score_id')->get(['id', 'value']),
            'severities' => Dropdown::where('key', 'cmp_complaint_categories.severity_level_id')->get(['id', 'value']),
            'complainantTypes' => Dropdown::where('key', 'cmp_complaints.complainant_type_id')->get(['id', 'value']),
    ```
  - **Before** (`reports/complaint-status/index.blade.php:42`):
    ```blade
                    <option value="{{ $status->value }}" {{ request('status') == $status->value ? 'selected' : '' }}>
    ```
  - **After:**
    ```blade
                    <option value="{{ $status->id }}" {{ request('status') == $status->id ? 'selected' : '' }}>
    ```
  - **Before** (`reports/hotspot/index.blade.php:54`):
    ```blade
                        {{ $severity->name }}
    ```
  - **After:**
    ```blade
                        {{ $severity->value }}
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "where\('type'"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CRPT-08** · H · QRY-15 (filter wiring) · `ComplaintReportController.php:110` + `:126` — read the category filter under the name the forms actually submit.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`
  - **Before** (`ComplaintReportController.php:109-113`):
    ```php
        return [
            'categoryId' => $request->input('category'),
            'complainantTypeId' => $request->input('complainant_type_id'),
            'statusId' => $request->input('status'),
        ];
    ```
  - **After:**
    ```php
        return [
            'categoryId' => $request->input('category_id'),
            'complainantTypeId' => $request->input('complainant_type_id'),
            'statusId' => $request->input('status'),
        ];
    ```
  - **Before** (`ComplaintReportController.php:126`):
    ```php
        $categoryId = $request->input('category');
    ```
  - **After:**
    ```php
        $categoryId = $request->input('category_id');
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "input\('category'\)"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CRPT-09** · M · filter wiring · `ComplaintReportController.php:411-422` + `reports/hotspot/index.blade.php:32-39` — connect the hotspot tab's date/category/severity filters and drop the dead Target-Type control.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`, `Modules/Complaint/resources/views/reports/hotspot/index.blade.php`
  - **Before** (`ComplaintReportController.php:411-422`):
    ```php
        private function getComplainantHotspotReport(Request $request)
        {
            $minCount = $request->input('min_count', 1);
            $targetTypeId = $request->input('target_type_id');

            $query = DB::table('cmp_complaints as c')
                ->whereNotNull('c.target_selected_id');

            if ($targetTypeId) {
                // target_type_id column removed, fallback to raw mapping if needed, 
                // but for now ignore or map manually if possible
            }
    ```
  - **After:**
    ```php
        private function getComplainantHotspotReport(Request $request)
        {
            $startDate = $request->input('start_date', Carbon::now()->subMonth()->toDateString());
            $endDate = $request->input('end_date', Carbon::now()->toDateString());
            $minCount = $request->input('min_count', 1);
            $categoryId = $request->input('category_id');
            $severityId = $request->input('severity_id');

            $query = DB::table('cmp_complaints as c')
                ->whereNotNull('c.target_selected_id')
                ->whereBetween('c.ticket_date', [$startDate, $endDate]);

            if ($categoryId) {
                $query->where('c.category_id', $categoryId);
            }

            if ($severityId) {
                $query->where('c.severity_level_id', $severityId);
            }
    ```
  - **Before** (`reports/hotspot/index.blade.php:32-39`):
    ```blade
            <select name="target_type_id" class="form-select" style="width:17%">
                <option value="">All Target Types</option>
                @foreach ($targetTypes as $type)
                    <option value="{{ $type->id }}" {{ request('target_type_id') == $type->id ? 'selected' : '' }}>
                        {{ $type->value }}
                    </option>
                @endforeach
            </select>
    ```
  - **After:**
    ```blade
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\resources\views\reports\hotspot\index.blade.php" -Pattern "target_type_id"`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **CRPT-10** · M · filter wiring · `ComplaintReportController.php:54-58` + `reports/pareto/index.blade.php:7-23` — replace the ignored Month/Quarter selects with the date range the controller already reads.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`, `Modules/Complaint/resources/views/reports/pareto/index.blade.php`
  - **Before** (`ComplaintReportController.php:54-58`):
    ```php
            $paretoData = $this->getParetoReport(
                $startDate,
                $endDate,
                $request->input('severity')
            );
    ```
  - **After:**
    ```php
            $paretoData = $this->getParetoReport(
                $startDate,
                $endDate
            );
    ```
  - **Before** (`reports/pareto/index.blade.php:7-23`):
    ```blade
            <select name="month" class="form-select">
                <option value="">Select Month</option>
                @foreach (range(1, 12) as $m)
                    <option value="{{ $m }}" {{ request('month') == $m ? 'selected' : '' }}>
                        {{ \Carbon\Carbon::create()->month($m)->format('F') }}
                    </option>
                @endforeach
            </select>

            <select name="quarter" class="form-select">
                <option value="">Select Quarter</option>
                @foreach ([1, 2, 3, 4] as $q)
                    <option value="{{ $q }}" {{ request('quarter') == $q ? 'selected' : '' }}>
                        Q{{ $q }}
                    </option>
                @endforeach
            </select>
    ```
  - **After:**
    ```blade
            <div class="d-flex align-items-center" style="width: 35%">
                <input type="date" name="start_date" value="{{ request('start_date', $startDate) }}"
                    class="form-control form-control-sm">
                <span class="text-muted mx-1">to</span>
                <input type="date" name="end_date" value="{{ request('end_date', $endDate) }}"
                    class="form-control form-control-sm">
            </div>
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\resources\views\reports\pareto\index.blade.php" -Pattern 'name="month"|name="quarter"'`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **CRPT-11** · M · filter wiring · `ComplaintReportController.php:124, :145-152` + `reports/sla-violation/index.blade.php:24-31` — remove the inert Department filter (no mapping table exists).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`, `Modules/Complaint/resources/views/reports/sla-violation/index.blade.php`
  - **Before** (`ComplaintReportController.php:124`):
    ```php
        $departmentId = $request->input('department');
    ```
  - **After:**
    ```php
    ```
  - **Before** (`ComplaintReportController.php:145-152`):
    ```php
        // Department filter (ONLY if you have a mapping table)
        // Right now cat.department_id doesn't exist, so this can’t work safely.
        // If you have mapping, I'll adjust in 2 mins.
        if ($departmentId) {
            // Example (uncomment if mapping table exists):
            // $query->join('cmp_department_sla as sla', 'sla.complaint_category_id', '=', 'c.category_id')
            //       ->where('sla.department_id', $departmentId);
        }
    ```
  - **After:**
    ```php
    ```
  - **Before** (`reports/sla-violation/index.blade.php:24-31`):
    ```blade
            <select name="department" class="form-select" style="width: 17%">
                <option value="">All Departments</option>
                @foreach ($departments as $dept)
                    <option value="{{ $dept->id }}" {{ request('department') == $dept->id ? 'selected' : '' }}>
                        {{ Str::limit($dept->name, 15) }}
                    </option>
                @endforeach
            </select>
    ```
  - **After:**
    ```blade
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "departmentId"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CRPT-12** · L · CTL-10 (deep read #8) · `ComplaintReportController.php:469` — drop the `totalComplaints` key that sums a column the query never returns.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`
  - **Before** (`ComplaintReportController.php:467-471`):
    ```php
            return [
                /* ===== SUMMARY CARDS ===== */
                'totalComplaints' => $hotspotData->sum('complaint_count'),

                'hotspotCount' => $hotspotData->count(),
    ```
  - **After:**
    ```php
            return [
                /* ===== SUMMARY CARDS ===== */
                'hotspotCount' => $hotspotData->count(),
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "complaint_count"`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

- [ ] **CRPT-14** · M · VIEW (deep read #7) · `reports/hotspot/index.blade.php:142` — the column prints a user id, not a complainant name/count; relabel it to match what is stored.
  - **Touches:** `Modules/Complaint/resources/views/reports/hotspot/index.blade.php`
  - **Before** (`reports/hotspot/index.blade.php:142`):
    ```blade
                            <th class="text-center">Unique Complainants</th>
    ```
  - **After:**
    ```blade
                            <th class="text-center">Most Active Complainant (User ID)</th>
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\resources\views\reports\hotspot\index.blade.php" -Pattern "Unique Complainants"`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style & controller shape (F6/F12) — one item per file

- [ ] **CRPT-15** · L · STY-01/02/04 · `ComplaintReportController.php` — add `strict_types`, then run Pint; the commented-out Department block is deleted by CRPT-11.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`
  - **Before** (`ComplaintReportController.php:1-5`):
    ```php
    <?php
    
    namespace Modules\Complaint\Http\Controllers;
    
    use App\Http\Controllers\Controller;
    ```
  - **After:**
    ```php
    <?php
    
    declare(strict_types=1);
    
    namespace Modules\Complaint\Http\Controllers;
    
    use App\Http\Controllers\Controller;
    ```
  - **Verify:** `vendor\bin\pint --test "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}` (run Pint once on the file first: `vendor\bin\pint "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" --format agent`).
  - **Effort:** S

- [ ] **CRPT-01** · M · CTL-10 · `ComplaintReportController.php:364-409` — delete the three unused private methods.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`
  - **Before** (`ComplaintReportController.php:364-409`):
    ```php
        private function baseParetoQuery($startDate, $endDate)
        {
            return DB::table('cmp_complaints as c')
                ->join('cmp_complaint_categories as cat', 'cat.id', '=', 'c.category_id')
                ->leftJoin('cmp_complaint_categories as sub', 'sub.id', '=', 'c.subcategory_id')
                ->join('sys_dropdown_table as sev', 'sev.id', '=', 'c.severity_level_id')
                ->whereBetween('c.ticket_date', [$startDate, $endDate])
                ->groupBy('cat.name', 'sub.name')
                ->select(
                    'cat.name as category',
                    DB::raw('COALESCE(sub.name, "No Subcategory") as sub_category'),
                    DB::raw('COUNT(c.id) as ticket_count'),
                    DB::raw("
                    AVG(
                        CASE sev.value
                            WHEN 'Low' THEN 1
                            WHEN 'Medium' THEN 2
                            WHEN 'High' THEN 3
                            WHEN 'Critical' THEN 4
                        END
                    ) as severity_weight
                ")
                );
        }


        private function applyParetoSeverityFilter($query, $severityLevels)
        {
            $levels = is_array($severityLevels) ? $severityLevels : [$severityLevels];

            $query->whereIn('sev.value', $levels);
        }

        private function severityCaseSql()
        {
            return "
                AVG(
                    CASE sev.value
                        WHEN 'Low' THEN 1
                        WHEN 'Medium' THEN 2
                        WHEN 'High' THEN 3
                        WHEN 'Critical' THEN 4
                    END
                ) AS severity_weight
            ";
        }
    ```
  - **After:**
    ```php
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "baseParetoQuery|applyParetoSeverityFilter|severityCaseSql"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CRPT-02** · L · CTL-04 · `ComplaintReportController.php:16` — add the return type to `summary()`.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php`
  - **Before** (`ComplaintReportController.php:16`):
    ```php
        public function summary(Request $request)
    ```
  - **After:**
    ```php
        public function summary(Request $request): \Illuminate\View\View
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "public function summary"`
  - **Expect:** one hit ending in `: \Illuminate\View\View`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **CRPT-03** · M · DECISION · CTL-06 — move the five reports' query logic out of the controller into a `ComplaintReportService`?
      (a) ⭐ defer to a later refactor pass, fix only the defects now  (b) extract a service in this pass  (c) leave as is, record as accepted
  - **Why it is a decision:** it is a behaviour-neutral architectural refactor of a 544-line read-only controller, not a defect fix.
  - ➜ Choice: ____

- [ ] **CRPT-13** · L · DECISION · QRY (caching) — cache the filter dropdown lists (status/priority/severity/complainant type) behind a tenant-keyed cache?
      (a) no — tables are tiny (716 rows total) and change rarely, leave uncached  (b) ⭐ yes, add a tenant-keyed cache in a later pass  (c) cache centrally
  - **Why it is a decision:** adding a cache is explicitly a DECISION item (final-audit.md §6, F9); the key must carry the tenant id.
  - ➜ Choice: ____

## 10. Findings with no plan item

None — every finding (CRPT-01 … CRPT-15) has a plan item above.
