# Final Audit — Complaint / ComplaintReportController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php` (544 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/complaint/reports/summary-status` (route name `complaint.reports.summary`); tenant hosts such as `http://test.localhost:8000/complaint/reports/summary-status` |
| Menu path | ⚠ UNVERIFIED — the menu row is stored in a `glb_menus`-style table I did not read; the screen sits under the Complaint module's Reports area |
| Who uses it | Roles holding `tenant.complaint.complaint.viewAny` — measured: **Super Admin (role id 1)** and **School Admin (role id 2)** |
| What a user does here | Opens a five-tab analytics dashboard for complaints: a Summary/Status report (counts by status, category, severity, priority), an SLA Violation report (breached / at-risk tickets, delay hours), a Pareto (root-cause 80/20) report, a Complainant Cluster & Hotspot report, and an AI Risk & Sentiment report. The user picks a date range and filter dropdowns, submits, and reads the tables and charts. No data is created or changed here — it is read-only. |
| Tables written | none — the controller issues no INSERT/UPDATE/DELETE |
| Tables read | `cmp_complaints`, `cmp_ai_insights`, `cmp_complaint_categories`, `sys_dropdown_table`, `sys_users`, `sch_departments` |
| Live data | tenant DB `xyz_school_00000000000040008000_202627` — `cmp_complaints` **12** live / 0 trashed · `cmp_ai_insights` **10** · `cmp_complaint_categories` **15** · `sch_departments` **14** · `sys_dropdown_table` **716** |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Not production-ready — the whole screen is dead today.** The controller builds its SLA query against a column that does not exist (`cmp_complaints.escalation_level`; the real column is `current_escalation_level`), and that query runs on every page load, so `GET /complaint/reports/summary-status` throws a `SQLSTATE[42S22] Unknown column` and returns HTTP 500. The single worst finding is **CRPT-04 (B)** — the report page cannot open at all. Behind it sit four high findings: an N+1 loop in the hotspot report, three unbounded list queries, dropdown filters that are always empty, and a category filter whose field name never matches the form. Rough effort: **M** — the blocker is a two-token fix, and most of the remaining items are small mechanical edits to one controller plus its report Blade partials.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 4 | 6 | 4 | 2 | 15 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | n/a (no write path) | F9 Queries/Perf | CRPT-04, 05, 06, 07, 08, 09, 10, 11, 12, 13 |
| F3 Authorization | clean | F10 Views | CRPT-14 |
| F4 Validation | clean (read-only) | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | CRPT-15 |
| F6 Controller shape | CRPT-01, 02, 03 | F13 Deep read | table — no mutating methods |
| F7 Models | linked only (no owned model) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php` | controller | 544 | this report | ✅ |
| 2 | `Modules/Complaint/resources/views/reports/index.blade.php` | blade | 32 | this report (only this controller renders it) | ✅ |
| 3 | `Modules/Complaint/resources/views/reports/complaint-status/index.blade.php` | blade partial | 283 | this report | ✅ |
| 4 | `Modules/Complaint/resources/views/reports/sla-violation/index.blade.php` | blade partial | 301 | this report | ✅ |
| 5 | `Modules/Complaint/resources/views/reports/pareto/index.blade.php` | blade partial | 191 | this report | ✅ |
| 6 | `Modules/Complaint/resources/views/reports/hotspot/index.blade.php` | blade partial | 211 | this report | ✅ |
| 7 | `Modules/Complaint/resources/views/reports/sentiment/index.blade.php` | blade partial | 201 | this report | ✅ |
| 8 | `Modules/Complaint/app/Models/ComplaintCategory.php` | model | 182 | ↗ [gaurav/Complaint/ComplaintCategoryController](../ComplaintCategoryController/01-report.md) | ↗ linked |
| 9 | `Modules/Prime/app/Models/Dropdown.php` | model (other module) | 82 | common — not audited here (§4.2) | ❌ not in scope |
| 10 | `Modules/SchoolSetup/app/Models/Department.php` | model (other module) | 26 | common — not audited here (§4.2) | ❌ not in scope |

No pre-applied files.

**Linked-class usage checked here (D7):** the controller calls `ComplaintCategory::parents()->get()` (line 303) — an unbounded full-model load with no column narrowing; recorded as **CRPT-07**. `Dropdown::where('type', …)->get()` (lines 305–308) and `Department::where('is_active', true)->select('id','name')->get()` (line 310) are common classes; the `Dropdown` calls are recorded in **CRPT-07** because the fault is the controller's query, not the model.

## 4. Routes

```
GET|HEAD  complaint/reports/summary-status  complaint.reports.summary  Modules\Complaint\Http\Controllers\ComplaintReportController@summary  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Complaint,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Command:
```
php artisan route:clear
$env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"
php artisan route:list --json 2>$null | php "/tmp/opencode\routesprobe.php" "Modules\Complaint\Http\Controllers\ComplaintReportController"
```

Unrouted public methods: **none** — `summary()` is the only public method (line 16).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `summary` | 16 | GET complaint/reports/summary-status | `tenant.complaint.complaint.viewAny` | none (read) | none | none | CRPT-02, CRPT-04, CRPT-14, CRPT-15 |

All other methods are `private` helpers (lines 100, 107, 121, 157, 177, 203, 216, 251, 265, 289, 300, 325, 364, 390, 397, 411, 465, 500) and are exercised through `summary`.

## 6. Findings

### F1 — Errors

clean — `Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "try|catch|getMessage"` → no output. No try/catch, no exception text sent to the user, no swallowed failure (read-only controller).

### F2 — Transactions and audit

n/a — the controller has no mutating method. No `DB::transaction`, no `activityLog()` call exists in the file (`-Pattern "DB::transaction|activityLog"` → no output). No tables are written.

### F3 — Authorization

clean — the single routed method authorizes first, before any query:

```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "Gate::authorize"
18:        Gate::authorize('tenant.complaint.complaint.viewAny');
```

The permission name is declared in `config/permissionslist.php` (key `'complaint.complaint' => array_merge($crud, ['manage', 'export'])`, where `$crud` includes `viewAny`, line 176-179 + 859), built to `tenant.complaint.complaint.viewAny` by `App\Helpers\PermissionHelper::flatten()` (`"{$role}.{$module}.{$action}"`), seeded in the tenant DB, and used identically in the view (`reports/index.blade.php:14,17,20,23,26`) and the tab config (lines 7-11). Exact-name seeded check:

```
SELECT * FROM sys_permissions WHERE name = 'tenant.complaint.complaint.viewAny';
2377 | tenant.complaint.complaint.viewAny | web | 2026-10-10 20:58:02 | 2026-10-10 20:58:02
```

Roles holding it: Super Admin (id 1), School Admin (id 2). No Policy is referenced, so AUTH-04/05/06 do not apply.

### F4 — Validation and input

clean — read-only controller. No `$request->all()`, no writes, no uploads (VAL-01/06 n/a). Query-string values feed only parameter-bound query builder calls (`->where('c.category_id', $categoryId)`), so no interpolation risk. There is no FormRequest, which is correct for a GET-only report (VAL-02 applies to writes).

### F5 — Routes

clean — one route, no state change over GET (RTE-01), the target method exists (RTE-02), all public methods routed (RTE-03), and the tenant + auth middleware group is present (RTE-05). No `Route::resource` prefix collision.

### F6 — Controller shape

#### CRPT-01 · M · CTL-10 — three private methods are dead code

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: unused private methods, unused properties, commented-out blocks* |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:364-409`, methods `baseParetoQuery()`, `applyParetoSeverityFilter()`, `severityCaseSql()` |
| **Root cause** | `getParetoReport()` was inlined (lines 325-361) and no longer calls these three helpers, but they were left in the file. `baseParetoQuery()` also queries `sub.name` (line 371) and is never executed. |
| **Consequence** | A maintainer reading the file believes the Pareto report uses these helpers and may "fix" the wrong copy; the file carries ~45 lines nobody runs. |
| **Reproduce** | static only — dead code has no browser path. |
| **Fix approach** | Delete the three unused private methods. |
| **Plan item** | CRPT-01 in `02-fix-plan.md` §8 |

```php
// ComplaintReportController.php:364-409 — CURRENT (never called)
    private function baseParetoQuery($startDate, $endDate)
    {
        return DB::table('cmp_complaints as c')
            ->join('cmp_complaint_categories as cat', 'cat.id', '=', 'c.category_id')
            ->leftJoin('cmp_complaint_categories as sub', 'sub.id', '=', 'c.subcategory_id')
            ->join('sys_dropdown_table as sev', 'sev.id', '=', 'c.severity_level_id')
            ->whereBetween('c.ticket_date', [$startDate, $endDate])
            ->groupBy('cat.name', 'sub.name')
            ->select(
                'cat.name as category',
                DB::raw('COALESCE(sub.name, "No Subcategory") as sub_category'),
                DB::raw('COUNT(c.id) as ticket_count'),
                DB::raw("
                AVG(
                    CASE sev.value
                        WHEN 'Low' THEN 1
                        WHEN 'Medium' THEN 2
                        WHEN 'High' THEN 3
                        WHEN 'Critical' THEN 4
                    END
                ) as severity_weight
            ")
            );
    }
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "baseParetoQuery|applyParetoSeverityFilter|severityCaseSql"
364:    private function baseParetoQuery($startDate, $endDate)
390:    private function applyParetoSeverityFilter($query, $severityLevels)
397:    private function severityCaseSql()
```
(Each name appears once — the definition only; there is no call site.)

#### CRPT-02 · L · CTL-04 — public method has no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View` …)* |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:16`, method `summary()` |
| **Root cause** | `public function summary(Request $request)` declares no `: View` return type; every other method in the file is also untyped, but this is the only public one. |
| **Consequence** | Low — static analysers and IDEs cannot infer the response type; no runtime effect. |
| **Reproduce** | static only — a type hint has no browser behaviour. |
| **Fix approach** | Add `: \Illuminate\View\View` to `summary()`. |
| **Plan item** | CRPT-02 in `02-fix-plan.md` §8 |

```php
// ComplaintReportController.php:16 — CURRENT
    public function summary(Request $request)
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "public function"
16:    public function summary(Request $request)
```

#### CRPT-03 · M · CTL-06 — report query-building logic lives in the controller

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in services/actions; a controller method reads input, calls one service, returns a response* |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:16-543` — 17 private helpers build ~10 report queries inline |
| **Root cause** | All five reports (summary, SLA, Pareto, hotspot, AI sentiment) are assembled with raw `DB::table()` joins and window SQL inside the controller; nothing is reusable or unit-testable in isolation. |
| **Consequence** | Every report change risks the whole controller; the same report SQL cannot be reused by an API or export. |
| **Reproduce** | static only — an architecture concern, not a visible bug. |
| **Fix approach** | Extract the report queries into a `ComplaintReportService`; this is a behaviour-neutral refactor and is recorded as a DECISION (see plan §9). |
| **Plan item** | CRPT-03 in `02-fix-plan.md` §9 (DECISION, deferrable) |

```php
// ComplaintReportController.php:218-224 — representative inline report SQL
        $query = DB::table('cmp_complaints as c')
            ->join('sys_dropdown_table as s', 's.id', '=', 'c.status_id')
            ->join('sys_dropdown_table as p', 'p.id', '=', 'c.priority_score_id')
            ->join('cmp_complaint_categories as cat', 'cat.id', '=', 'c.category_id')
            ->leftJoin('cmp_complaint_categories as sub', 'sub.id', '=', 'c.subcategory_id')
            ->join('sys_dropdown_table as sev', 'sev.id', '=', 'c.severity_level_id')
            ->whereBetween('c.ticket_date', [$startDate, $endDate]);
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "DB::table|DB::query"
159:        return DB::table('cmp_complaints as c')
218:        $query = DB::table('cmp_complaints as c')
253:        $query = DB::table('cmp_complaints as c')
267:        $query = DB::table('cmp_complaints as c')
327:        $baseQuery = DB::table('cmp_complaints as c')
349:        return DB::query()
366:        return DB::table('cmp_complaints as c')
416:        $query = DB::table('cmp_complaints as c')
440:            $mostActiveComplainant = DB::table('cmp_complaints')
449:            $mostCommonCategory = DB::table('cmp_complaints')
457:                ? DB::table('cmp_complaint_categories')->where('id', $mostCommonCategory->category_id)->value('name')
511:        $query = DB::table('cmp_ai_insights as ai')
```

### F7 — Models

No model is owned by this controller. `ComplaintCategory` is audited elsewhere and linked in §3; this controller's only model-side defect is its own unbounded `parents()->get()` call, recorded as CRPT-07. `Dropdown` and `Department` are other-module (common) classes, referenced only.

### F8 — Services and jobs

clean — the controller injects no service and dispatches no job; `Select-String -Pattern "Service|Job|dispatch|event\("` → no output.

### F9 — Queries and performance

#### CRPT-04 · B · MDL-07 (by analogy) — the SLA query names a column that does not exist, so the whole page returns 500

| Field | Value |
|---|---|
| **Rule** | MDL-07 (B) — *a model/query over a missing schema object 500s on first use.* No rulebook ID covers a query over a non-existent column directly; MDL-07 is the nearest (missing schema object → 500 on first use), so it is cited by analogy and given its default B severity. |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:172` (select `'c.escalation_level'`) and `:139` (`where('c.escalation_level', …)`), method `baseSlaViolationQuery()` / `getSlaViolationReport()` |
| **Root cause** | The `cmp_complaints` table has no `escalation_level` column; the real column is `current_escalation_level` (the author even wrote it in the commented line 142). `getSlaViolationReport()` runs unconditionally from `summary()` (line 50), and `baseSlaViolationQuery()` always selects the bad column, so the first `->get()` throws. |
| **Consequence** | Any user opening `/complaint/reports/summary-status` sees a 500 error page instead of the reports dashboard — the screen is unusable. |
| **Reproduce** | Open `http://<tenant-host>/complaint/reports/summary-status`. Expected: the five report tabs; actual: HTTP 500. |
| **Fix approach** | Rename the column to `current_escalation_level` in both the select (keeping the `escalation_level` alias so the Blade keeps working) and the filter. |
| **Plan item** | CRPT-04 in `02-fix-plan.md` §1 |

```php
// ComplaintReportController.php:163-173 — CURRENT
            ->select(
                'c.ticket_no',
                DB::raw('COALESCE(u.name, "Unassigned") as assigned_to'),
                't.value as defendant_type',
                'c.target_name as defendant_name',
                'cat.name as complaint_category',
                'c.resolution_due_at',
                'c.actual_resolved_at',
                DB::raw('TIMESTAMPDIFF(HOUR, c.resolution_due_at, COALESCE(c.actual_resolved_at, NOW())) as delay_hours'),
                'c.escalation_level'
            );
```

**Evidence**
```
$ SHOW COLUMNS FROM cmp_complaints   (tenant xyz_school_00000000000040008000_202627)  → no column named escalation_level
(the columns present include: current_escalation_level, is_escalated, is_anonymous)

$ SELECT c.escalation_level FROM cmp_complaints c LEFT JOIN sys_dropdown_table t ON t.id = c.target_user_type_id LIMIT 1
ERR: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'c.escalation_level' in 'field list'

$ SELECT c.current_escalation_level FROM cmp_complaints c LIMIT 1
OK rows=1
```

#### CRPT-05 · H · QRY-01 — the hotspot report runs queries inside a loop (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; eager-load or pre-fetch into a keyed collection* |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:439-461`, method `getComplainantHotspotReport()` |
| **Root cause** | After the grouped hotspot query returns, the code `->map()`s over every hotspot row and issues 2 GROUP BY queries per row plus a third `value('name')` lookup, instead of joining/aggregating once. |
| **Consequence** | A tenant with H hotspots runs 1 + 3H queries in one request; the hotspot tab slows linearly with data volume and can time out. |
| **Reproduce** | Open the "Complainant Cluster & Hotspot" tab with several hotspots; the table is slow to render (static analysis proves the loop regardless of current row count). |
| **Fix approach** | Replace the per-row queries with window functions (e.g. `ROW_NUMBER() OVER (PARTITION BY target_selected_id ORDER BY cnt DESC)`) in the single grouped query, or pre-fetch complainant/category aggregates with `whereIn` and key them by id. |
| **Plan item** | CRPT-05 in `02-fix-plan.md` §6 |

```php
// ComplaintReportController.php:439-461 — CURRENT
        return $hotspotData->map(function ($row) {
            $mostActiveComplainant = DB::table('cmp_complaints')
                ->where('target_selected_id', $row->target_id)
                ->select('complainant_user_id', DB::raw('COUNT(*) as cnt'))
                ->groupBy('complainant_user_id')
                ->orderByDesc('cnt')
                ->first();

            $row->unique_complainant = $mostActiveComplainant ? $mostActiveComplainant->complainant_user_id : null;

            $mostCommonCategory = DB::table('cmp_complaints')
                ->where('target_selected_id', $row->target_id)
                ->select('category_id', DB::raw('COUNT(*) as cnt'))
                ->groupBy('category_id')
                ->orderByDesc('cnt')
                ->first();

            $row->most_common_issue = $mostCommonCategory
                ? DB::table('cmp_complaint_categories')->where('id', $mostCommonCategory->category_id)->value('name')
                : null;

            return $row;
        });
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "->map\(function|DB::table\('cmp_complaints'\)|DB::table\('cmp_complaint_categories'\)->where"
439:        return $hotspotData->map(function ($row) {
440:            $mostActiveComplainant = DB::table('cmp_complaints')
449:            $mostCommonCategory = DB::table('cmp_complaints')
457:                ? DB::table('cmp_complaint_categories')->where('id', $mostCommonCategory->category_id)->value('name')
```

#### CRPT-06 · H · QRY-02 — report lists are unbounded (no pagination / no limit)

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H) — *lists are paginated; no unbounded `->get()` feeding a list page* |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:154`, `:437`, `:542` |
| **Root cause** | `getSlaViolationReport()`, `getComplainantHotspotReport()` and `getAiRiskSentimentReport()` all end in `->get()` with no `limit`/`paginate`, and each feeds a table (`sla-violation`, `hotspot`, `sentiment` partials) rendered in full. |
| **Consequence** | On a tenant with thousands of complaints the SLA and AI sentiment tables load every matching row into memory and paint them all — a slow page and high memory use. |
| **Reproduce** | Open `/complaint/reports/summary-status` (after CRPT-04) on a data-heavy tenant; the SLA and AI tables render unbounded. |
| **Fix approach** | Either add a `->limit(…)` guard (these are top-N analytics) or paginate the three lists with distinct `pageName`s; add a DECISION note if a limit is chosen over pagination. |
| **Plan item** | CRPT-06 in `02-fix-plan.md` §6 |

```php
// ComplaintReportController.php:154 — CURRENT
        return $query->orderByDesc('delay_hours')->get();
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "->get\(\);"
154:        return $query->orderByDesc('delay_hours')->get();
360:            ->get();
437:            ->get();
542:            ->get();
```
(Line 360 is an aggregate `groupBy` result; lines 154, 437, 542 are unbounded row lists.)

#### CRPT-07 · H · QRY-03 — filter-dropdown queries use the wrong column, so every dropdown is empty (and load whole models)

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M) *select only what you use*, **raised to H**: the same queries also return zero rows, so the filters are non-functional — a silent failure, which is H per the severity table. Proving command for the wrong column is in **Evidence**. |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:300-323`, method `getFilterData()` (lines 305-308); option markup at `reports/complaint-status/index.blade.php:42` and `reports/hotspot/index.blade.php:54` |
| **Root cause** | `Dropdown` (`sys_dropdown_table`) stores its group in the `key` column (values such as `cmp_complaints.status_id`); every row has `type = 'String'`. The controller filters on `type = 'status' | 'priority' | 'severity' | 'complainant_type'`, which match **zero** rows. The queries also `->get()` full models instead of narrowing the columns. Two view-level faults sit behind the same interface: the Summary Status option submits the label text (`value="{{ $status->value }}"`) where the controller compares it to the integer `c.status_id`, and the Hotspot severity option reads `$severity->name`, a column that `sys_dropdown_table` does not have (it has `value`). |
| **Consequence** | The Status, Priority, Severity and Complainant-Type dropdowns render with no options on every report tab, so those filters can never be applied; even after the query is fixed, the Status filter would compare a text label to an id and the Hotspot severity labels would be blank. |
| **Reproduce** | Open `/complaint/reports/summary-status`; the Status dropdown on the Summary tab and the Severity/Complainant dropdowns are empty. |
| **Fix approach** | Filter by the correct `key` values, select only the thrown-away columns, make the Status option submit the dropdown id, and read `->value` in the Hotspot severity option. |
| **Plan item** | CRPT-07 in `02-fix-plan.md` §6 |

```php
// ComplaintReportController.php:302-310 — CURRENT
        return [
            'categories' => ComplaintCategory::parents()->get(),

            'statuses' => Dropdown::where('type', 'status')->get(),
            'priorities' => Dropdown::where('type', 'priority')->get(),
            'severities' => Dropdown::where('type', 'severity')->get(),
            'complainantTypes' => Dropdown::where('type', 'complainant_type')->get(),

            'departments' => Department::where('is_active', true)->select('id', 'name')->get(),
```

**Evidence**
```
$ SELECT type, COUNT(*) c FROM sys_dropdown_table GROUP BY type;
String = 716                      ← the only type value that exists

$ SELECT id,`key`,value FROM sys_dropdown_table WHERE `key` IN
  ('cmp_complaints.status_id','cmp_complaint_categories.priority_score_id',
   'cmp_complaint_categories.severity_level_id','cmp_complaints.complainant_type_id');
220 | cmp_complaints.status_id | Open
221 | cmp_complaints.status_id | In-Progress
223 | cmp_complaints.status_id | Resolved
224 | cmp_complaints.status_id | Closed
225 | cmp_complaints.status_id | Rejected
193 | cmp_complaint_categories.severity_level_id | Low
194 | cmp_complaint_categories.severity_level_id | Medium
195 | cmp_complaint_categories.severity_level_id | High
197 | cmp_complaint_categories.priority_score_id | Critical
199 | cmp_complaint_categories.priority_score_id | High
202 | cmp_complaints.complainant_type_id | Parent
203 | cmp_complaints.complainant_type_id | Student
```

#### CRPT-08 · H · QRY-15 (filter wiring) — the category filter never applies because the field name does not match

| Field | Value |
|---|---|
| **Rule** | No dedicated rulebook ID; this is a filter-wiring defect proved by grep. It is a silent failure (the control does nothing), which is H by the severity table. QRY-15 (M) is the nearest query rule (a filter that loads/does nothing); raised to H with this reason. |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:110` (reads `category`) and `:126` (reads `category`), versus `reports/complaint-status/index.blade.php:18` and `reports/hotspot/index.blade.php:41` (submit `category_id`) |
| **Root cause** | The forms submit `name="category_id"`; the controller reads `$request->input('category')`. The two names never meet, so `$categoryId` is always null and `applyCommonFilters()`/the SLA query skip the category restriction. |
| **Consequence** | Selecting a category (labelled "All Departments" on the Summary tab) changes nothing — the numbers stay the same, so the user is shown data they did not ask for. |
| **Reproduce** | On the Summary tab pick a category, press the filter button; the table/counts are identical to the unfiltered view. |
| **Fix approach** | Read `$request->input('category_id')` in `getCommonFilters()` and in `getSlaViolationReport()` (keep the query-string name the forms already use). |
| **Plan item** | CRPT-08 in `02-fix-plan.md` §6 |

```php
// ComplaintReportController.php:109-113 — CURRENT
        return [
            'categoryId' => $request->input('category'),
            'complainantTypeId' => $request->input('complainant_type_id'),
            'statusId' => $request->input('status'),
        ];
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "input\('category'\)"
110:            'categoryId' => $request->input('category'),
126:        $categoryId = $request->input('category');

$ Select-String -Path "Modules\Complaint\resources\views\reports\complaint-status\index.blade.php","Modules\Complaint\resources\views\reports\hotspot\index.blade.php" -Pattern 'name="category'
Modules\Complaint\resources\views\reports\complaint-status\index.blade.php:18:            <select name="category_id" class="form-select" style="width: 17%">
Modules\Complaint\resources\views\reports\hotspot\index.blade.php:41:            <select name="category_id" class="form-select" style="width:17%">
```

#### CRPT-09 · M · QRY (filter wiring) — the hotspot tab's filters are not connected

| Field | Value |
|---|---|
| **Rule** | No dedicated rulebook ID; filter-wiring defect. M because it affects one of five tabs and the tab still shows unfiltered data. |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:411-437`, method `getComplainantHotspotReport()`; form fields at `reports/hotspot/index.blade.php:25,28,32,41,50` |
| **Root cause** | The hotspot form submits `start_date`, `end_date`, `target_type_id`, `category_id`, `severity_id`, but the method reads only `min_count` and `target_type_id` (and the latter is deliberately ignored at lines 419-422). There is no `whereBetween('c.ticket_date', …)` and no category restriction, so the date/category/severity controls do nothing. Separately, `$targetTypes` is never passed by `getFilterData()`, so the Target-Type dropdown is always empty (the partial guards with `$targetTypes ?? collect()`). |
| **Consequence** | On the Hotspot tab the date range, category and severity pickers silently do nothing and the Target-Type picker has no options; the user reads a fixed all-time, all-category list no matter what they choose. |
| **Reproduce** | Open the "Complainant Cluster & Hotspot" tab, change the date range or category, submit; the table is unchanged. |
| **Fix approach** | Read `category_id`/`severity_id` and apply them plus a `ticket_date` between-filter in the hotspot query; pass a `targetTypes` collection (or remove the dead Target-Type control). |
| **Plan item** | CRPT-09 in `02-fix-plan.md` §6 |

```php
// ComplaintReportController.php:411-423 — CURRENT
    private function getComplainantHotspotReport(Request $request)
    {
        $minCount = $request->input('min_count', 1);
        $targetTypeId = $request->input('target_type_id');

        $query = DB::table('cmp_complaints as c')
            ->whereNotNull('c.target_selected_id');

        if ($targetTypeId) {
            // target_type_id column removed, fallback to raw mapping if needed, 
            // but for now ignore or map manually if possible
        }
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "input\('min_count'|input\('target_type_id'|whereBetween\('c.ticket_date'"
413:        $minCount = $request->input('min_count', 1);
414:        $targetTypeId = $request->input('target_type_id');
(no whereBetween('c.ticket_date' hit in getComplainantHotspotReport)

$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "targetTypes"
(no output — $targetTypes is never passed to the view)
```

#### CRPT-10 · M · QRY (filter wiring) — the Pareto report ignores its own Month/Quarter filters

| Field | Value |
|---|---|
| **Rule** | No dedicated rulebook ID; filter-wiring defect. M because the user can still read the (unfiltered) report. |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:54-58` (`getParetoReport($startDate, $endDate, $request->input('severity'))`) and `:325` (`getParetoReport($startDate, $endDate)`); form fields at `reports/pareto/index.blade.php:7,16` |
| **Root cause** | The Pareto form submits `month` and `quarter`, which the controller never reads. The 3rd argument the caller passes (`severity`) is discarded because the method signature `getParetoReport($startDate, $endDate)` accepts only two parameters. The report always uses the default last-30-day range from `getDateRange()`. |
| **Consequence** | Picking a Month or Quarter on the Pareto tab has no effect; every user sees the same trailing-30-day Pareto chart. |
| **Reproduce** | On the Pareto tab choose "March" (or Q2), submit; the table/chart is identical. |
| **Fix approach** | Either wire `month`/`quarter` into the date range for this report, or remove the two controls so the screen stops promising a filter it does not offer. |
| **Plan item** | CRPT-10 in `02-fix-plan.md` §6 |

```php
// ComplaintReportController.php:54-58 — CURRENT
        $paretoData = $this->getParetoReport(
            $startDate,
            $endDate,
            $request->input('severity')
        );
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "getParetoReport"
54:        $paretoData = $this->getParetoReport(
325:    private function getParetoReport($startDate, $endDate)

$ Select-String -Path "Modules\Complaint\resources\views\reports\pareto\index.blade.php" -Pattern 'name="month"|name="quarter"'
7:            <select name="month" class="form-select">
16:            <select name="quarter" class="form-select">
```

#### CRPT-11 · M · QRY (filter wiring) — the SLA Department filter is a commented-out no-op

| Field | Value |
|---|---|
| **Rule** | No dedicated rulebook ID; filter-wiring defect. M — one filter of the SLA tab is inert. |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:145-152` |
| **Root cause** | The department branch body is entirely commented out ("Right now cat.department_id doesn't exist"), so when `$departmentId` is set nothing is added to the query. The form still offers the dropdown. |
| **Consequence** | Choosing a Department on the SLA tab changes nothing; a manager reading "SLA violations for Facilities" actually sees every department. |
| **Reproduce** | On the SLA tab pick a department, submit; the table is unchanged. |
| **Fix approach** | Connect the filter via a real mapping (e.g. join the category→department mapping table) or remove the Department control from the SLA form. |
| **Plan item** | CRPT-11 in `02-fix-plan.md` §6 |

```php
// ComplaintReportController.php:145-152 — CURRENT
        // Department filter (ONLY if you have a mapping table)
        // Right now cat.department_id doesn't exist, so this can’t work safely.
        // If you have mapping, I'll adjust in 2 mins.
        if ($departmentId) {
            // Example (uncomment if mapping table exists):
            // $query->join('cmp_department_sla as sla', 'sla.complaint_category_id', '=', 'c.category_id')
            //       ->where('sla.department_id', $departmentId);
        }
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "departmentId"
124:        $departmentId = $request->input('department');
148:        if ($departmentId) {
```

#### CRPT-12 · L · CTL-10 (deep read #8) — `prepareHotspotViewData()` sums a key the query never returns

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) / deep-read #8 dead feature, lowered to **L**: the computed value is never rendered, so no user sees the wrong number. |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:469`, method `prepareHotspotViewData()` |
| **Root cause** | The hotspot query selects `COUNT(*) as total_complaints` (line 429), but the summary card computes `$hotspotData->sum('complaint_count')` — a key that does not exist — so `totalComplaints` is always 0. It is also never referenced by the hotspot Blade. |
| **Consequence** | None visible — the value is dead. It is a latent trap: a future blade that reads `totalComplaints` would show 0. |
| **Reproduce** | static only — `totalComplaints` is not used in any report blade. |
| **Fix approach** | Delete the unused `totalComplaints` key (or correct it to `total_complaints` if it is meant to be shown). |
| **Plan item** | CRPT-12 in `02-fix-plan.md` §6 |

```php
// ComplaintReportController.php:467-469 — CURRENT
        return [
            /* ===== SUMMARY CARDS ===== */
            'totalComplaints' => $hotspotData->sum('complaint_count'),
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "total_complaints|complaint_count"
429:                DB::raw('COUNT(*) as total_complaints'),
469:            'totalComplaints' => $hotspotData->sum('complaint_count'),
```

#### CRPT-13 · L · QRY (caching candidate) — dropdown data is re-queried on every request

| Field | Value |
|---|---|
| **Rule** | QRY (F9 caching note, L) — *dropdowns/settings re-queried on every request are a caching candidate; adding a cache is a DECISION* |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php:305-310` |
| **Root cause** | Four `Dropdown` queries plus a `Department` query run on every page load with no tenant-scoped cache, even though the values change rarely. |
| **Consequence** | Extra round-trips per page view; small today, grows with tenants. |
| **Reproduce** | static only — a performance observation, not a visible defect. |
| **Fix approach** | Introduce a tenant-keyed cache for the filter lists; recorded as a DECISION (see plan §9). |
| **Plan item** | CRPT-13 in `02-fix-plan.md` §9 (DECISION) |

```php
// ComplaintReportController.php:305-310 — CURRENT
            'statuses' => Dropdown::where('type', 'status')->get(),
            'priorities' => Dropdown::where('type', 'priority')->get(),
            'severities' => Dropdown::where('type', 'severity')->get(),
            'complainantTypes' => Dropdown::where('type', 'complainant_type')->get(),

            'departments' => Department::where('is_active', true)->select('id', 'name')->get(),
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "Dropdown::|Department::"
305:            'statuses' => Dropdown::where('type', 'status')->get(),
306:            'priorities' => Dropdown::where('type', 'priority')->get(),
307:            'severities' => Dropdown::where('type', 'severity')->get(),
308:            'complainantTypes' => Dropdown::where('type', 'complainant_type')->get(),
310:            'departments' => Department::where('is_active', true)->select('id', 'name')->get(),
```

### F10 — Views

#### CRPT-14 · M · VIEW (deep read #7) — the "Unique Complainants" column prints a raw user id

| Field | Value |
|---|---|
| **Rule** | VIEW family / deep-read #7 (messages that lie), M — a column headed "Unique Complainants" shows an id, so the figure is meaningless to the reader. |
| **Where** | `Modules/Complaint/resources/views/reports/hotspot/index.blade.php:154` rendering `$row->unique_complainant`, set at `ComplaintReportController.php:447` |
| **Root cause** | The controller stores `complainant_user_id` (an integer) in `unique_complainant`, and the Blade prints it verbatim under the header "Unique Complainants". |
| **Consequence** | The reader expects a name or a count and instead sees a bare number such as `5`; the column is misread. |
| **Reproduce** | Open the Hotspot tab; the "Unique Complainants" column shows numeric ids. |
| **Fix approach** | Show a name (join `sys_users`) or relabel the column to reflect what is stored; presenting the id is the defect. |
| **Plan item** | CRPT-14 in `02-fix-plan.md` §7 |

```php
// hotspot/index.blade.php:154 — CURRENT
                                <td class="text-center">{{ $row->unique_complainant }}</td>
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\resources\views\reports\hotspot\index.blade.php" -Pattern "unique_complainant"
142:                            <th class="text-center">Unique Complainants</th>
154:                                <td class="text-center">{{ $row->unique_complainant }}</td>

$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" -Pattern "unique_complainant"
447:            $row->unique_complainant = $mostActiveComplainant ? $mostActiveComplainant->complainant_user_id : null;
```

Breadcrumb **clean** — `reports/index.blade.php:2` keeps `:links="[]"`, which is correct: `.claude/rules/breadcrumb-standard.md` rule #8 states *"Blades never hardcode `:links`. The attribute stays `[]` or absent"* and §2.6 shows that passing a trail **breaks** the breadcrumb (the component's resolver builds the trail). Proving command: `Select-String -Path "Modules\Complaint\resources\views\reports\index.blade.php" -Pattern "breadcrum"` → `2: <x-backend.components.breadcrum title="Complaint Reports Management" :links="[]" />`.

#### F10 query checks (clean)

No queries in Blade — `Select-String -Path "Modules\Complaint\resources\views\reports\*\*.blade.php" -Pattern "DB::|::where|::all|->get\(|->count\(|->where\("` returns only in-memory Collection calls (`->where()->sum()` on already-loaded collections) and `@foreach` over controller-provided collections, no Eloquent/DB access. No relations are lazy-loaded in `@foreach` (the loops iterate the pre-loaded `$categories`, `$complainantTypes`, `$statuses`, `$departments`, `$escalationLevels`, `$violationTypes` arrays/collections). No `{!! !!}` on user text — `Select-String -Pattern "\{!!"` returns no output in any report blade; dynamic data is rendered with `{{ }}` or `@json()`.

### F11 — Security and tenancy

clean — no `env()` call in the controller or its views (`-Pattern "env\("` → no output); no hard-coded user/tenant ids (`?? 1` absent; the literals `3/4/5` are UI option values for the escalation-level dropdown, not fallbacks); no secrets logged; no cache keys to tenant-scope (no cache exists). The JSON blobs emitted to the Blade (`@json($statusDistribution)`, `@json($aiBubbleChartData)`) are aggregate/chart arrays, not user records.

### F12 — Style

#### CRPT-15 · L · STY-01 / STY-02 / STY-04 — not Pint-clean, no `strict_types`, commented-out code

| Field | Value |
|---|---|
| **Rule** | STY-01 (`strict_types`), STY-02 (Pint-clean), STY-04 (no commented-out code) — all L |
| **Where** | `Modules/Complaint/app/Http/Controllers/ComplaintReportController.php` (whole file); commented block at lines 145-152; smart apostrophe in the comment on line 146 |
| **Root cause** | The file fails Pint (`--test` reports 8 fixers) and has no `declare(strict_types=1);`; the department-filter block is commented-out code; a non-ASCII apostrophe (`can’t`) sits in a comment. |
| **Consequence** | Low — style/consistency debt; the commented block also hides the no-op filter (CRPT-11). |
| **Reproduce** | static only — run Pint. |
| **Fix approach** | Run Pint on the file; add `declare(strict_types=1);`; delete the commented-out lines (handled with CRPT-11). |
| **Plan item** | CRPT-15 in `02-fix-plan.md` §8 |

```php
// ComplaintReportController.php — Pint --test reports these fixers
class_attributes_separation, function_declaration, control_structure_braces, no_trailing_whitespace, trailing_comma_in_multiline, braces_position, blank_line_before_statement, ordered_imports
```

**Evidence**
```
$ php -l "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php"
No syntax errors detected in Modules\Complaint\app\Http\Controllers\ComplaintReportController.php

$ vendor\bin\pint --test "Modules\Complaint\app\Http\Controllers\ComplaintReportController.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Complaint\\app\\Http\\Controllers\\ComplaintReportController.php","fixers":["class_attributes_separation","function_declaration","control_structure_braces","no_trailing_whitespace","trailing_comma_in_multiline","braces_position","blank_line_before_statement","ordered_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

**There are no mutating methods in this controller.** `summary()` and all 17 helpers are read-only: they issue only `SELECT`/`DB::table()->select()` queries and never call `create`, `update`, `save`, `delete`, `insert`, or `activityLog`. Therefore the eight deep-read questions (wrong overwrite, delete-before-store, duplicate implementations, soft-delete × unique index, races, authorization holes, messages that lie, dead features) do not apply to a write path — there is none.

The closest analogues found on the **read** path are recorded above: deep-read #7 (messages that lie) → CRPT-14; deep-read #8 (dead features) → CRPT-07, CRPT-09, CRPT-10, CRPT-11, CRPT-12. Duplicate implementations (#3) → the Pareto base query exists twice (inlined at 327-347 and dead at 364-387), recorded as CRPT-01.

| Mutating method | Q1 wrong overwrite | Q2 delete-before-store | Q3 duplicate impl | Q4 soft-delete×unique | Q5 race | Q6 authz hole | Q7 message lies | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| (none — read-only controller) | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Prime/app/Models/Dropdown.php` | Its `$attributes = ['type' => 'String']` default means every row written without an explicit type gets `type = 'String'`; callers that filter on `type` (this controller and possibly others) get zero rows. Whether the default is wrong or the callers should filter on `key` is a model-owner decision. | MDL-06 / SEC-03 class | Dropdown model owner (Prime module) |
| Report SQL uses MySQL-only double-quoted string literals inside `DB::raw` (`COALESCE(u.name, "Unassigned")`, `"No Subcategory"`) and MySQL functions (`TIMESTAMPDIFF`, `DATE_ADD`). Under ANSI_QUOTES or on PostgreSQL these are identifiers, not literals. No bound variables are used, so this is not QRY-11. | QRY (portability) | Complaint module / DBA |

## 8. Not covered, and why

- **Menu path** — not verified; the `glb_menus`-style table was not read.
- **Queue / jobs / mail** — none exist on this path.
- **Blade rendering in a browser** — the page currently 500s (CRPT-04), so the two `@php`-heavy partials (sla-violation, pareto) could not be exercised end-to-end. Their compile-time shape was read statically; no `{{-- --}}` inside `@php` was found.
- **`sys_users` join** — the `leftJoin('sys_users as u', …)` was not executed against live data because the query fails earlier (CRPT-04); verified only that `sys_users` is a real table.
- **Scanner and self-check** — **skipped**: `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are missing, and `scan.php` was not run per the tooling override. The F1–F13 checklist was performed manually with `read`/grep, `php -l`, `pint --test` and direct tenant-DB queries.
- **`route:list` for the whole app** — not dumped; only this controller's route was extracted through the `routesprobe.php` helper.
