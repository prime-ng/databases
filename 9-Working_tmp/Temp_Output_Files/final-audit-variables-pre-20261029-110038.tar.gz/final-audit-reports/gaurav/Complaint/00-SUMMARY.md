# Complaint - Module Audit Summary

**Protocol:** `.claude/rules/final-audit.md` (13.2) - **Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md`
**Audited:** 2026-10-17 - **By:** opencode - **Developer folder:** gaurav
**Phase:** AUDIT. Read-only - no application code changed.

All 10 top-level controllers of `Modules/Complaint` are audited. One folder per controller holds
`01-report.md` + `02-fix-plan.md`. Tick items in each plan, then run `final-audit-fixer` on the path.

> **Self-check deviation:** `_tools/selfcheck.py` is not present in this checkout, so the automated
> self-check did not run (Tarun's override: audit manually, skip `scan.php`). The main session ran a
> manual sweep instead: every `01-report.md` has sections 0-8, no leftover template tokens remain, and
> all code-fence `...`/`etc.` elisions were removed (37 fixed in `ComplaintController`).

## 1. Per-controller results

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| ComplaintController | 1,896 | 5 | 8 | 20 | 8 | 1 | CMP-23 - `toggleStatus()` writes `is_active`, not a column on `cmp_complaints` (admin POST 500s); CMP-22 uploads tenant media to the central DB | [01](ComplaintController/01-report.md) |
| ComplaintMobileController | 686 | 3 | 8 | 12 | 2 | 2 | CMBL-25 - status/priority resolved via the wrong dropdown key (dashboard shows 0 open / 0 resolved; new complaints get foreign status ids) | [01](ComplaintMobileController/01-report.md) |
| ComplaintReportController | 544 | 1 | 4 | 6 | 4 | 2 | CRPT-04 - SLA query names a column that does not exist (`escalation_level`), so the page 500s | [01](ComplaintReportController/01-report.md) |
| ComplaintCategoryController | 367 | 0 | 3 | 7 | 9 | 2 | CCAT-18 - `forceDelete()`'s child check cannot see soft-deleted children, which the FK cascade then hard-deletes | [01](ComplaintCategoryController/01-report.md) |
| DepartmentSlaController | 309 | 0 | 2 | 7 | 9 | 3 | DSLA-02 - composite uniqueness is check-then-act with no unique index (race) | [01](DepartmentSlaController/01-report.md) |
| MedicalCheckController | 284 | 1 | 6 | 8 | 5 | 2 | MEDC-15 - tenant media is written to the central database (cross-tenant leak) | [01](MedicalCheckController/01-report.md) |
| DocumentRequestController | 118 | 2 | 2 | 2 | 4 | 1 | DOCR-01 - the Status and Document Type filters query columns that do not exist (500) | [01](DocumentRequestController/01-report.md) |
| ComplaintActionController | 72 | 2 | 1 | 1 | 4 | 1 | CACT-01 - two live routes call methods that do not exist (HTTP 500) | [01](ComplaintActionController/01-report.md) |
| AiInsightController | 56 | 0 | 0 | 2 | 3 | 0 | AIN-01 - every public method is unrouted, so the whole controller is unreachable | [01](AiInsightController/01-report.md) |
| ComplaintDashboardController | 56 | 0 | 0 | 2 | 2 | 1 | CDSH-01 - every public method of this controller is unrouted | [01](ComplaintDashboardController/01-report.md) |

## 2. Module totals

| B | H | M | L | Total findings | DECISIONs |
|---|---|---|---|---|---|
| **14** | **34** | **67** | **50** | **165** | **15** |

**Blockers (B=14):** `ComplaintController` x5, `ComplaintMobileController` x3, `DocumentRequestController` x2,
`ComplaintActionController` x2, `ComplaintReportController` x1, `MedicalCheckController` x1. Each is a
page-killer (schema drift or missing method) or a cross-tenant media leak on a reachable screen.

## 3. Cross-controller families (fix as one change)

1. **Schema drift -> 500s** (MDL-07). A cluster of code references columns/methods that do not exist:
   `CMP-23` (`is_active`), `DOCR-01` (Status/Document-Type filter columns), `CRPT-04`
   (`escalation_level`), `CACT-01` (two routed-but-missing methods). Each needs a model-column or
   route/method fix; verify against the live schema, do not guess.
2. **Cross-tenant media leak** (MDL-05 / TEN-01). Tenant media written to the CENTRAL DB in
   `MedicalCheckController` (`MEDC-15`) and `ComplaintController` (`CMP-22`): add the `getMediaModel()`
   override -> `App\Models\TenantMedia` on every affected tenant media model. One pattern, several files.
3. **State change over GET** (RTE-01) + **routed-but-missing methods** (RTE-02). `restore`/`forceDelete`
   are registered as `Route::get(...)` across `ComplaintController`, `ComplaintCategoryController` and
   `ComplaintActionController`; `CACT-01` routes call methods that do not exist. Route-file edits are
   `⚠ SHARED`.
4. **Unrouted controllers/methods** (RTE-03 / D5). `AiInsightController` and
   `ComplaintDashboardController` are entirely unrouted; `ComplaintActionController` has 4 unrouted
   methods. Report only - do not delete (D5).
5. **Route shadowing** (RTE-06). In `ComplaintController`, `complaints/manage` is registered AFTER
   `Route::resource('complaints')`, so the `{complaint}` wildcard captures it (`/complaints/manage`
   resolves to `show`). Reorder the route file (`⚠ SHARED`).
6. **God controller** (CTL-01). `ComplaintController` is 1,896 lines / ~30 public methods -> M; the
   split is a DEFERRED decision (D3), not applied in this pass.
7. **Missing transactions / misplaced writes** (TXN-01/03/06). `DSLA-02` (check-then-act without a unique
   index), `CCAT-18` (force-delete vs. soft-deleted children), `CMP` event dispatch
   (`new ComplaintSaved(...)`) fired before commit. Wrap multi-write blocks and move `activityLog`/events
   inside/after the transaction correctly.
8. **D1 try/catch in controllers.** `ComplaintCategoryController` (5 methods), `ComplaintMobileController`
   (`show`/load paths) and the manual `DB::beginTransaction` in `ComplaintController` swallow
   `findOrFail` (500 instead of 404) and never roll back cleanly.
9. **Dropdown/status resolution.** `CMBL-25` resolves status/priority through the wrong dropdown key, so
   mobile dashboard counts are 0 and new complaints get ids from the wrong option list.

## 4. Shared classes and their owner reports

`final-audit-reports/00-CLASS-OWNERS.md` is the registry (pre-assigned by the main session before batch 1).
Owners: `Complaint` / `ComplaintAction` / `AiInsight` / `ComplaintDashboardService` /
`ComplaintAIInsightEngine` / `ComplaintSaved` / `ProcessComplaintAIInsights` -> ComplaintController;
`ComplaintCategory` + `ComplaintCategoryRequest` -> ComplaintCategoryController; `DepartmentSla` +
`DepartmentSlaRequest` -> DepartmentSlaController; `MedicalCheck` -> MedicalCheckController. `ParentDocumentRequest`
is a LINK -> `tarun/ParentPortal-done/ParentDocumentController` (not re-audited).

**Overrides (recorded in the registry):** `Models/Complaint.php` and `Models/ComplaintCategory.php` were
already claimed by `tarun/ParentPortal-done/ParentComplaintController`; for this module pass gaurav re-audits
both (hence two rows per file in `00-CLASS-OWNERS.md`).

## 5. Module-wide decisions (need one answer, then apply everywhere)

1. **`getMediaModel()` override** - add it to every tenant media model flagged by `MEDC-15` / `CMP-22`.
2. **God controller split** - D3 deferred; decide whether/when `ComplaintController` is split.
3. **Unrouted controllers** - `AiInsightController` / `ComplaintDashboardController` are dead code;
   decide to wire routes or remove (D5 says report, not delete).
4. **Route-file fix order** - `manage` shadowing (RTE-06) plus GET restore routes (RTE-01): one shared
   route edit covering the module.

## 6. Not covered, and why

- **Automated scanner + self-check** - `_tools/scanfilter.py` and `_tools/selfcheck.py` are absent and
  `scan.php` was not run (Tarun override). All F1-F13 checks were done manually; manual sweep results are
  in the note at the top.
- **Live row counts / menu paths / permission seeding** - `ComplaintController` reached the tenant DB but
  leaned on `⚠ UNVERIFIED` for some §0 row counts; where the other reports show counts they were measured
  via read-only SQL probes.
- **Runtime behaviour** - no browser/test run (D4); every finding is static or a read-only SQL probe.

## 7. Status

- **Index:** all 10 rows `AUDITED` (`gaurav/Complaint/00-INDEX.md`).
- **Self-check:** not run (tool absent); manual sweep clean (sections present, no template tokens, no code-fence elisions).
- **Not fixed:** the audit is read-only. Fixes wait on ticking `02-fix-plan.md` items and the developer
  (gaurav) running `final-audit-fixer`.
- **Blocked:** nothing.
