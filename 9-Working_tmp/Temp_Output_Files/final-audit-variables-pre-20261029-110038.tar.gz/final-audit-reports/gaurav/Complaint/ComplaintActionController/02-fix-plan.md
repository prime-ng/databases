# Fix Plan — Complaint / ComplaintActionController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Complaint/app/Http/Controllers/ComplaintActionController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Complaint/routes/web.php` | route file (⚠ SHARED) — only edited by **CACT-01 option (a)**, and only with its own explicit tick (§9.3: a route change is Tarun's call) |
| `config/permissionslist.php` | shared config (⚠ SHARED) — already declares `complaint.complaint-action`; this plan adds no key |
| `Modules/Complaint/app/Models/ComplaintAction.php` | owned by `gaurav/Complaint/ComplaintController` (`00-CLASS-OWNERS.md:433`) |
| `Modules/Complaint/resources/views/**` | no view file is written or edited by this plan |
| `final-audit-reports/00-CLASS-OWNERS.md`, `final-audit-reports/gaurav/Complaint/00-INDEX.md` | maintained by the main session |

## 1. Blockers reachable today

- [ ] **CACT-01** · B · DECISION · RTE-02 · `Modules/Complaint/app/Http/Controllers/ComplaintActionController.php` + `Modules/Complaint/routes/web.php:147-155` — the live scaffold must be disposed of: two routes 500 on a missing method, one route 500s on a missing view, two routes silently do nothing. ⚠ SHARED (option (a) edits a route file).
  - **Why it is a decision:** every remedy either changes the **route file** (⚠ SHARED, and a route add/remove is a Tarun call, §9.3) or **builds a new feature** (real `restore`/`forceDelete`/`show`/`store`/`destroy` against `ComplaintAction`, which is a D3 scope change) — neither is a mechanical fix.
  - (a) ⭐ **Disable the scaffold and remove its orphan routes.** Tick this option **and** edit the route file (Before/After below) **and** replace the controller file with the After below. Net result: `GET …/restore` and `DELETE …/force-delete` no longer exist; `POST /complaint/complaint-actions`, `GET/DELETE /complaint/complaint-actions/{…}` answer `403` instead of `500`/silent-no-op; the four unrouted methods become `abort(403)` (D5). The real Complaint Actions tab (`complaint.complaint-mgt.index` → `ComplaintController@index`) is untouched.
  - (b) **Build the controller for real.** Add `restore()`/`forceDelete()`/working `show()`/`store()`/`destroy()` backed by the `ComplaintAction` model, and add the three missing Blade views. New feature — out of this pass (D3); do not apply now.
  - (c) **Leave as is.** Record the 500s and no-ops as accepted debt; no item ticked.
  - ➜ Choice: ____

  - **Touches (option (a)):** `Modules/Complaint/routes/web.php`, `Modules/Complaint/app/Http/Controllers/ComplaintActionController.php`
  - **Before** (`Modules/Complaint/routes/web.php:147-155`):
    ```php
    Route::get(
        'complaint-actions/{id}/restore',
        [ComplaintActionController::class, 'restore']
    )->name('complaint-actions.restore');

    Route::delete(
        'complaint-actions/{id}/force-delete',
        [ComplaintActionController::class, 'forceDelete']
    )->name('complaint-actions.forceDelete');
    ```
  - **After** (`Modules/Complaint/routes/web.php:147-155`) — the two orphan route blocks are removed; nothing replaces them because the controller has no `restore`/`forceDelete` methods:
    ```php

    ```
  - **Before** (`ComplaintActionController.php:1-72`, the entire current file):
    ```php
    <?php

    namespace Modules\Complaint\Http\Controllers;

    use Illuminate\Http\RedirectResponse;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;

    class ComplaintActionController extends Controller
    {
        /**
         * Display a listing of the resource.
         */
        public function index()
        {
            
            Gate::authorize('tenant.complaint.complaint-action.viewAny');
    return view('complaint::index');
        }

        /**
         * Show the form for creating a new resource.
         */
        public function create()
        {
            
            Gate::authorize('tenant.complaint.complaint-action.create');
    return view('complaint::create');
        }

        /**
         * Store a newly created resource in storage.
         */
        public function store(Request $request) {
            Gate::authorize('tenant.complaint.complaint-action.create');
    }

        /**
         * Show the specified resource.
         */
        public function show($id)
        {
            
            Gate::authorize('tenant.complaint.complaint-action.view');
    return view('complaint::show');
        }

        /**
         * Show the form for editing the specified resource.
         */
        public function edit($id)
        {
            
            Gate::authorize('tenant.complaint.complaint-action.update');
    return view('complaint::edit');
        }

        /**
         * Update the specified resource in storage.
         */
        public function update(Request $request, $id) {}

        /**
         * Remove the specified resource from storage.
         */
        public function destroy($id) {
            Gate::authorize('tenant.complaint.complaint-action.delete');
    }
    }
    ```
  - **After** (option (a) — the entire file):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;

    class ComplaintActionController extends Controller
    {
        // NOT ROUTED — complaint-actions.index points at ComplaintController@index,
        // not here. Disabled per final-audit D5 (2026-10-17).
        public function index(): never
        {
            abort(403, 'Complaint actions are managed from the complaint screen.');
        }

        // NOT ROUTED — see index().
        public function create(): never
        {
            abort(403, 'Complaint actions are managed from the complaint screen.');
        }

        // DISABLED 2026-10-17 (final-audit CACT-01) — the route was live but store()
        // never wrote anything; a 403 is honest where a silent 200 was not.
        public function store(Request $request): never
        {
            abort(403, 'Complaint actions are managed from the complaint screen.');
        }

        // DISABLED 2026-10-17 (final-audit CACT-01) — show() pointed at complaint::show,
        // a Blade file that does not exist (was HTTP 500 on every call).
        public function show($id): never
        {
            abort(403, 'Complaint actions are managed from the complaint screen.');
        }

        // NOT ROUTED — see index().
        public function edit($id): never
        {
            abort(403, 'Complaint actions are managed from the complaint screen.');
        }

        // NOT ROUTED — see index().
        public function update(Request $request, $id): never
        {
            abort(403, 'Complaint actions are managed from the complaint screen.');
        }

        // DISABLED 2026-10-17 (final-audit CACT-01) — destroy() authorized then returned
        // without deleting anything.
        public function destroy($id): never
        {
            abort(403, 'Complaint actions are managed from the complaint screen.');
        }
    }
    ```
  - **Verify (option (a)):** `php -l Modules/Complaint/app/Http/Controllers/ComplaintActionController.php; $env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --json 2>$null | php routesprobe.php "Modules\Complaint\Http\Controllers\ComplaintActionController"`
  - **Expect:** `No syntax errors detected` and a route list with **no** `restore` and **no** `forceDelete` row (only store/show/destroy remain).
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None. There is no working write path to protect; every item here disables or removes dead/broken code only.

## 3. Errors & transactions (F1/F2)

None — the controller has no `try`/`catch` (D1 clean) and no write path (F1/F2 clean in `01-report.md`).

## 4. Authorization (F3)

None — the three routed methods that exist already authorize with correctly-named, seeded permissions. The missing-method and unrouted states are handled by CACT-01 and CACT-03.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **CACT-03** · M · RTE-03 · `ComplaintActionController.php:17,27,54,64` — apply D5 to the four unrouted methods (`index`, `create`, `edit`, `update`): body becomes `abort(403, '…')` with a `NOT ROUTED` comment. Never delete the methods. (If **CACT-01 option (a)** is ticked, it already covers this; the fixer will find these four lines already rewritten and mark CACT-03 superseded.)
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintActionController.php`
  - **Before** (`ComplaintActionController.php:14-22`):
    ```php
        /**
         * Display a listing of the resource.
         */
        public function index()
        {
            
            Gate::authorize('tenant.complaint.complaint-action.viewAny');
    return view('complaint::index');
        }
    ```
  - **After:**
    ```php
        // NOT ROUTED — complaint-actions.index points at ComplaintController@index.
        // Disabled per final-audit D5 (2026-10-17).
        public function index(): never
        {
            abort(403, 'Complaint actions are managed from the complaint screen.');
        }
    ```
  - **Before** (`ComplaintActionController.php:24-32`):
    ```php
        /**
         * Show the form for creating a new resource.
         */
        public function create()
        {
            
            Gate::authorize('tenant.complaint.complaint-action.create');
    return view('complaint::create');
        }
    ```
  - **After:**
    ```php
        // NOT ROUTED — see index().
        public function create(): never
        {
            abort(403, 'Complaint actions are managed from the complaint screen.');
        }
    ```
  - **Before** (`ComplaintActionController.php:51-59`):
    ```php
        /**
         * Show the form for editing the specified resource.
         */
        public function edit($id)
        {
            
            Gate::authorize('tenant.complaint.complaint-action.update');
    return view('complaint::edit');
        }
    ```
  - **After:**
    ```php
        // NOT ROUTED — see index().
        public function edit($id): never
        {
            abort(403, 'Complaint actions are managed from the complaint screen.');
        }
    ```
  - **Before** (`ComplaintActionController.php:61-64`):
    ```php
        /**
         * Update the specified resource in storage.
         */
        public function update(Request $request, $id) {}
    ```
  - **After:**
    ```php
        // NOT ROUTED — see index().
        public function update(Request $request, $id): never
        {
            abort(403, 'Complaint actions are managed from the complaint screen.');
        }
    ```
  - **Verify:** `Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintActionController.php" -Pattern "view\('complaint::(index|create|edit)'\)"`
  - **Expect:** no output (all three `view()` calls in the unrouted methods are gone).
  - **Effort:** S

## 6. Queries & performance (F9)

None — no query of any kind (F9 clean in `01-report.md`).

## 7. Views (F10)

None — no view file is written. The dangling targets `complaint::create`/`show`/`edit` disappear when the methods are disabled by CACT-01 (option (a)) or CACT-03.

## 8. Style (F12) — one item per file

- [ ] **CACT-06** · L · STY-01 + STY-02 · `ComplaintActionController.php:1-10` — add `declare(strict_types=1);`, then run Pint (it removes the unused `RedirectResponse`/`View` imports, sorts imports and fixes braces/indentation/blank lines). This one item also covers **CACT-07** (STY-02) and **CACT-08** (STY-04): after Pint, delete any scaffold docblocks that remain (the generator comments at the current lines 14-16, 24-26, 34-36, 41-43, 51-53, 61-63, 66-68 — those whose methods were already rewritten by CACT-01/CACT-03 are already gone).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintActionController.php`
  - **Before** (`ComplaintActionController.php:1-10`):
    ```php
    <?php

    namespace Modules\Complaint\Http\Controllers;

    use Illuminate\Http\RedirectResponse;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    ```
  - **After** (the imports shown are what remains if the bodies still use `Gate`; if CACT-01 option (a) is ticked the bodies no longer use `Gate`, and the `vendor/bin/pint` run below removes that import automatically):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    ```
  - **Verify:** `vendor\bin\pint --test "Modules\Complaint\app\Http\Controllers\ComplaintActionController.php" --format agent; Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintActionController.php" -Pattern "declare\(strict_types"`
  - **Expect:** `{"tool":"pint","result":"passed"}` and one match for `declare(strict_types`.
  - **Effort:** S

## 9. Deferred / decisions

- The only DECISION is **CACT-01** in §1 (blocker; routes + scaffold disposition). Nothing else is deferred.
- **Deferred: a real Complaint Actions CRUD** — rebuilding `store`/`show`/`destroy`/`restore`/`forceDelete` against `ComplaintAction` and adding the three missing Blade views is a new feature and a D3 scope change. It is out of this pass; capture it as backlog if CACT-01 option (b) is ever chosen.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CACT-02 | Resolved by the **CACT-01** DECISION: option (a) deletes the `GET …/restore` route; if the route is kept instead, change its verb there. |
| CACT-04 | Resolved by the **CACT-01** DECISION (option (a) disables `show`/`store`/`destroy`; option (b) implements them + the missing views). |
| CACT-05 | Resolved by the **CACT-01** / **CACT-03** rewrites, which give every method `: never`. |
