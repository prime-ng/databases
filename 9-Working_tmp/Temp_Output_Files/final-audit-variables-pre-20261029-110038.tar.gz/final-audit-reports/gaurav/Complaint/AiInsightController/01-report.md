# Final Audit — Complaint / AiInsightController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Complaint/app/Http/Controllers/AiInsightController.php` (56 lines, 7 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | **None.** This controller has no route. `route:list` (uncached) returns zero rows whose action contains `Modules\Complaint\Http\Controllers\AiInsightController` and zero rows containing `ai-insight`. The live `ai-insights` page (route `ai-insights.index`, `GET /ai-insights`) is served by `ComplaintController@index` (`Modules/Complaint/routes/web.php:185`), not by this class. |
| Menu path | The only `ai-insights` menu/breadcrumb traces are `config/breadcrumbs_old_format_18_aug_2026.php:368` and `:951`, and a permission key `complaint.ai-insights` (`config/permissionslist.php:862`). None of them route to this controller. |
| Who uses it | No one reaches this controller. The permission `complaint.ai-insights` exists in `config/permissionslist.php:862`, but no method here checks it. Roles that hold it: ⚠ UNVERIFIED — measuring `sys_role_has_permissions_jnt` needs the tenant DB, which this read-only run did not open. |
| What a user does here | Nothing. There is no reachable page. The class is dead scaffolding left after the `ai-insights` resource route was deleted (`Modules/Complaint/routes/web.php:186-190`). |
| Tables written | None. The controller touches no model, no `DB::`, no `activityLog`, no `save()`/`create()`/`update()` (see F1 evidence). |
| Tables read | None. It runs no query of any kind. |
| Live data | Not applicable — the source performs no DB access, so there is no table to count. ⚠ UNVERIFIED for any DB figure because no tenant DB was opened. |

**How to reach each bug in the browser:** nothing is reachable (there is no URL). Each finding below is proved statically, and its **Reproduce** field says so.

## 1. Verdict

This controller is **not production-ready, but it is also not dangerous today**: it is completely unreachable. Every one of its **7 public methods is unrouted** — the `ai-insights` resource route was deleted and the class was left behind. The single worst finding is **AIN-01**: the whole controller is dead code, and D5 requires each unrouted method's body to become `abort(403)`. If the route were ever re-added, three methods (`create`, `show`, `edit`) would return HTTP 500 "View not found" (AIN-02) because `complaint::create`, `complaint::show` and `complaint::edit` do not exist, and the other three (`store`, `update`, `destroy`) would silently succeed while doing nothing. Effort to apply the plan: **S** (one small file, two mechanical edits).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 2 | 3 | 0 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | clean |
| F3 Authorization | clean | F10 Views | see AIN-02 (F6) |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | AIN-01 | F12 Style | AIN-04, AIN-05 |
| F6 Controller shape | AIN-02, AIN-03 | F13 Deep read | AIN-01, AIN-02 (table) |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Complaint/app/Http/Controllers/AiInsightController.php` | controller | 56 | this report | ✅ |
| 2 | `Modules/Complaint/resources/views/index.blade.php` | blade (`complaint::index`, rendered by `index()`) | 7 | this report | ✅ |
| 3 | `Modules/Complaint/resources/views/create.blade.php` | blade (`complaint::create`, rendered by `create()`) | 0 | this report | ❌ missing |
| 4 | `Modules/Complaint/resources/views/show.blade.php` | blade (`complaint::show`, rendered by `show()`) | 0 | this report | ❌ missing |
| 5 | `Modules/Complaint/resources/views/edit.blade.php` | blade (`complaint::edit`, rendered by `edit()`) | 0 | this report | ❌ missing |

The controller imports no model, service, FormRequest or policy, so no module class is in scope. The `AiInsight` model, `ComplaintAIInsightEngine` service and `ProcessComplaintAIInsights` listener are **not** used here and are owned elsewhere (`00-CLASS-OWNERS.md:436,438,440` → `gaurav/Complaint/ComplaintController`). The `complaint::` view namespace is bound to `Modules/Complaint/resources/views` by `ComplaintServiceProvider::registerViews()` (`loadViewsFrom($sourcePath, 'complaint')`, lines 153-160).

No pre-applied files.

## 4. Routes

```
$ php artisan route:clear
   INFO  Route cache cleared successfully.
$ $env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --json 2>$null | php routesprobe.php "Modules\Complaint\Http\Controllers\AiInsightController"
(no output — zero routes point at this controller)
```

The class is still imported by the route file but never used:
`Modules/Complaint/routes/web.php:4` — `use Modules\Complaint\Http\Controllers\AiInsightController;` (see §7).

Unrouted public methods: **all of them** —
`index` (`:13`), `create` (`:21`), `store` (`:29`), `show` (`:34`), `edit` (`:42`), `update` (`:50`), `destroy` (`:55`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 13 | none (unrouted) | none | none | none | none | AIN-01, AIN-03 |
| `create` | 21 | none (unrouted) | none | none | none | none | AIN-01, AIN-02, AIN-03 |
| `store` | 29 | none (unrouted) | none | none | none | none | AIN-01, AIN-02, AIN-03 |
| `show` | 34 | none (unrouted) | none | none | none | none | AIN-01, AIN-02, AIN-03 |
| `edit` | 42 | none (unrouted) | none | none | none | none | AIN-01, AIN-02, AIN-03 |
| `update` | 50 | none (unrouted) | none | none | none | none | AIN-01, AIN-02, AIN-03 |
| `destroy` | 55 | none (unrouted) | none | none | none | none | AIN-01, AIN-02, AIN-03 |

## 6. Findings

### F1 — Errors

clean — `Select-String -Path Modules\Complaint\app\Http\Controllers\AiInsightController.php -Pattern 'try','catch','getMessage'` → 0, 0, 0. No `try`/`catch`, no exception text reaches a user, no write path exists to swallow.

### F2 — Transactions and audit

clean — no mutation exists: the same scan gives `DB::` → 0, `activityLog` → 0, model `::find` → 0; `store`/`update`/`destroy` have empty bodies (`{}`). There is nothing to wrap in a transaction.

### F3 — Authorization

clean — no method is routed, so AUTH-01 (which targets *routed* methods) is not triggered. The unrouted state itself is reported as AIN-01 (F5), not duplicated here.

### F4 — Validation and input

clean — there is no write path: `validate(` → 0 and no input is written (empty bodies). Nothing unvalidated reaches a model.

### F5 — Routes

#### AIN-01 · M · RTE-03 — every public method is unrouted, so the whole controller is unreachable

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`)*; under protocol D5 the fixed body becomes `abort(403, '…')` with a `NOT ROUTED` comment |
| **Where** | `Modules/Complaint/app/Http/Controllers/AiInsightController.php:13-55`, methods `index`, `create`, `store`, `show`, `edit`, `update`, `destroy` |
| **Root cause** | The `ai-insights` `Route::resource` was deleted (documented at `Modules/Complaint/routes/web.php:186-190`) but the controller class was never disabled. No route file references the class in any action; the only mention is an unused `use` import at `web.php:4`. |
| **Consequence** | No user can reach any of these methods; the class is dead code that still occupies the module. |
| **Reproduce** | static only — no route resolves to this controller, so no URL exists. Proved by the uncached `route:list` probe (§4) returning zero rows and a grep of all three route files finding no action that names the class. |
| **Fix approach** | Apply D5: replace each method body with `abort(403, '…')` and a `NOT ROUTED` comment. Never delete the methods. |
| **Plan item** | AIN-01 in `02-fix-plan.md` §5 |

```php
// AiInsightController.php:13-55 — CURRENT
    public function index()
    {
        return view('complaint::index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('complaint::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {}

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('complaint::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('complaint::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id) {}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {}
```

**Evidence**
```
$ php artisan route:clear; $env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --json 2>$null | php routesprobe.php "Modules\Complaint\Http\Controllers\AiInsightController"
   INFO  Route cache cleared successfully.
(no output — zero routes)

$ Select-String -Path Modules\Complaint\routes\*.php -Pattern "AiInsightController" | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
4:use Modules\Complaint\Http\Controllers\AiInsightController;
186:// The AiInsightController resource is gone. After except() and only() cancelled each other
```

### F6 — Controller shape

#### AIN-02 · M · CTL-10 — dead code: three methods render views that do not exist, three have empty bodies

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code*; the deep-read checklist item 8 (dead feature) applies |
| **Where** | `AiInsightController.php` — `:23` (`complaint::create`), `:36` (`complaint::show`), `:44` (`complaint::edit`), and the empty bodies at `:29`, `:50`, `:55` |
| **Root cause** | The class is a leftover scaffold. `complaint::create`, `complaint::show` and `complaint::edit` have no file under `Modules/Complaint/resources/views/`; `store`, `update`, `destroy` have body `{}` and do nothing. |
| **Consequence** | If any of these methods is ever routed, `create`/`show`/`edit` return HTTP 500 "View [complaint::create] not found" (and the same for `complaint::show` and `complaint::edit`), and `store`/`update`/`destroy` return success while writing nothing. Today it is unreachable, so no user sees this. |
| **Reproduce** | static only — unrouted. Missing-view proof below. |
| **Fix approach** | No separate fix: the AIN-01 edit replaces every body with `abort(403)`, which removes the missing-view references and the empty bodies. |
| **Plan item** | none — see plan §10 (folded into AIN-01) |

```php
// AiInsightController.php:21-45 — CURRENT (the three missing-view references)
    public function create()
    {
        return view('complaint::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {}

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('complaint::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('complaint::edit');
    }
```

**Evidence**
```
$ Test-Path "Modules\Complaint\resources\views\index.blade.php","Modules\Complaint\resources\views\create.blade.php","Modules\Complaint\resources\views\show.blade.php","Modules\Complaint\resources\views\edit.blade.php"
True
False
False
False
```

#### AIN-03 · L · CTL-04 — public methods declare no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `AiInsightController.php:13, 21, 29, 34, 42, 50, 55` — every public method |
| **Root cause** | Scaffold stubs were written as `public function index()` with no `: View` / `: RedirectResponse` clause. |
| **Consequence** | Editors and static analysis cannot infer the response; no user-visible effect. |
| **Reproduce** | static only — style finding. |
| **Fix approach** | Covered by the AIN-01 edit: each body becomes `abort(403, '…')`, which never returns, so each method gets `: never`. |
| **Plan item** | none — see plan §10 (folded into AIN-01) |

```php
// AiInsightController.php:13 — CURRENT
    public function index()
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\AiInsightController.php -Pattern ': View|: RedirectResponse|: JsonResponse|: never'
(no output)
```

### F7 — Models

clean — the controller imports and references no model (`grep` for `::find`/`::create`: `::find` → 0; the single `::create` hit is the view name `complaint::create`, not a model write).

### F8 — Services and jobs

clean — no service, job, event, mail or notification is referenced (`Select-String -Path Modules\Complaint\app\Http\Controllers\AiInsightController.php -Pattern '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification|Export|Import)\b'` → no output).

### F9 — Queries and performance

clean — the controller contains no query: `DB::` → 0, `validate(` → 0, no Eloquent call.

### F10 — Views

clean for the one view that exists — `Modules/Complaint/resources/views/index.blade.php` (7 lines) has no query (`Model::`/`DB::`/`->get()`), no `@foreach`, and no `{!! !!}` on user text; its only `{!! config('complaint.name') !!}` is trusted config. The three missing views are recorded as **AIN-02** (F6).

### F11 — Security and tenancy

clean — `env(` → 0, no secrets or request bodies are logged (`Log::` → 0), no hard-coded ids or `?? 1`, no cache.

### F12 — Style

#### AIN-04 · L · STY-01 — file has no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `AiInsightController.php:1-3` (header) |
| **Root cause** | The scaffold was generated without a strict-types declaration. |
| **Consequence** | None user-visible; consistency only. |
| **Reproduce** | static only — style finding. |
| **Fix approach** | Add `declare(strict_types=1);` immediately after `<?php`. |
| **Plan item** | AIN-04 in `02-fix-plan.md` §8 |

```php
// AiInsightController.php:1-3 — CURRENT
<?php

namespace Modules\Complaint\Http\Controllers;
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\AiInsightController.php -Pattern 'declare\(strict_types'
(no output)
```

#### AIN-05 · L · STY-04 — seven copy-pasted scaffold docblocks

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *no copy-pasted docblocks that describe another resource; docblocks only where they add meaning* |
| **Where** | `AiInsightController.php:10-12, 18-20, 26-28, 31-33, 39-41, 47-49, 52-54` |
| **Root cause** | Generator boilerplate ("Display a listing of the resource." …) that describes generic CRUD, not this class. |
| **Consequence** | None user-visible; the comments mislead a reader once the methods are disabled. |
| **Reproduce** | static only — style finding. |
| **Fix approach** | Covered by the AIN-01 edit, which rewrites lines 13-55 and drops the docblocks. |
| **Plan item** | none — see plan §10 (folded into AIN-01) |

```php
// AiInsightController.php:10-12 — CURRENT (one of seven identical scaffold docblocks)
    /**
     * Display a listing of the resource.
     */
```
The other six are at `:18-20`, `:26-28`, `:31-33`, `:39-41`, `:47-49`, `:52-54`; their exact text is in the evidence output below.

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\AiInsightController.php -Pattern 'Display a listing|Show the form|Store a newly|Show the specified|Update the specified|Remove the specified'
11:* Display a listing of the resource.
19:* Show the form for creating a new resource.
27:* Store a newly created resource in storage.
32:* Show the specified resource.
40:* Show the form for editing the specified resource.
48:* Update the specified resource in storage.
53:* Remove the specified resource from storage.
```

### F13 — Deep read (answer all 8 questions for every mutating method)

Only `store`, `update` and `destroy` could mutate; all three have empty bodies and can only run if re-routed.

| Mutating method | 1 overwrite? | 2 delete-before-store? | 3 duplicate impl? | 4 soft-delete × unique? | 5 race? | 6 auth hole? | 7 message lies? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` (`:29`) | ok (no write) | ok | ok | ok | ok | AIN-01 | ok | AIN-02 |
| `update` (`:50`) | ok (no write) | ok | ok | ok | ok | AIN-01 | ok | AIN-02 |
| `destroy` (`:55`) | ok (no write) | ok | ok | ok | ok | AIN-01 | ok | AIN-02 |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Complaint/routes/web.php:4` | `use Modules\Complaint\Http\Controllers\AiInsightController;` is imported but no route uses it (dead import). A route file is a shared/common file, so it is out of scope for this report. | CTL-10 (dead code) / STY-05 | route-file owner / main session |
| `config/permissionslist.php:862` | `'complaint.ai-insights' => array_merge($crud, ['export'])` declares a permission no method of this controller checks; the live `ai-insights` page is served by `ComplaintController@index`. Either wire it to the real page or drop it. | AUTH-06 (M) / dead permission | `ComplaintController` report / main session |

## 8. Not covered, and why

- **Scanner and self-check skipped.** Per Tarun's tooling override for this run, `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are **missing** (`Test-Path` → False for both), so `scan.php` was **not** run and the §15 self-check was **not** run. The F1–F13 checklist above was worked manually with `read`/`grep`/`Select-String`, `php -l`, the uncached `route:list` probe, `Test-Path`, and `vendor/bin/pint --test`.
- **Role population for `complaint.ai-insights`** — ⚠ UNVERIFIED. Measuring it needs `sys_role_has_permissions_jnt` on the tenant DB, which this read-only run did not open.
- **Live row counts** — not applicable; the controller performs no DB access, so there is no table to count. No number is invented.
- **The three missing views** — their files do not exist, so their contents could not be read; that absence is the finding AIN-02 itself.
- **Pint** — `vendor/bin/pint --test Modules/Complaint/app/Http/Controllers/AiInsightController.php --format agent` returned `{"tool":"pint","result":"passed"}`, so STY-02 is clean and no style finding beyond STY-01/STY-04 was raised.
