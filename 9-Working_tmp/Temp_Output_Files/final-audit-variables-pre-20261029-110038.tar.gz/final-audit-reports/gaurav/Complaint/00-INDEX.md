# Complaint — Final Audit Index

Protocol: `.claude/rules/final-audit.md`.
⛔ Append a row to claim. Edit only your own row. Never rewrite this file.

| Controller | Status | B | H | M | L | Report | By | Updated |
|---|---|---|---|---|---|---|---|---|
| ComplaintCategoryController | AUDITED | 0 | 3 | 7 | 9 | [01-report](ComplaintCategoryController/01-report.md) | opencode | 2026-10-17 |
| DepartmentSlaController | AUDITED | 0 | 2 | 7 | 9 | [01-report](DepartmentSlaController/01-report.md) | opencode | 2026-10-17 |
| MedicalCheckController | AUDITED | 1 | 6 | 8 | 5 | [01-report](MedicalCheckController/01-report.md) | opencode | 2026-10-17 |
| ComplaintActionController | AUDITED | 2 | 1 | 1 | 4 | [01-report](ComplaintActionController/01-report.md) | opencode | 2026-10-17 |
| AiInsightController | AUDITED | 0 | 0 | 2 | 3 | [01-report](AiInsightController/01-report.md) | opencode | 2026-10-17 |
| ComplaintReportController | AUDITED | 1 | 4 | 6 | 4 | [01-report](ComplaintReportController/01-report.md) | opencode | 2026-10-17 |
| ComplaintDashboardController | AUDITED | 0 | 0 | 2 | 2 | [01-report](ComplaintDashboardController/01-report.md) | opencode | 2026-10-17 |
| DocumentRequestController | AUDITED | 2 | 2 | 2 | 4 | [01-report](DocumentRequestController/01-report.md) | opencode | 2026-10-17 |
| ComplaintMobileController | AUDITED | 3 | 8 | 12 | 2 | [01-report](ComplaintMobileController/01-report.md) | opencode | 2026-10-17 |
| ComplaintController | AUDITED | 5 | 8 | 20 | 8 | [01-report](ComplaintController/01-report.md) | opencode | 2026-10-17 |
