# Fix Plan — StudentProfile / StudentLeaveTypeController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/StudentProfile/routes/web.php` | shared route file — touched only if DECISION SLT-05 is ticked |
| `Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php` | shared provider — touched only if DECISION SLT-02 option (b) is chosen |
| `Modules/StudentProfile/app/Services/LeaveService.php` | owned by the StdLeaveController report |
| `database/migrations/tenant/2026_06_15_151301_create_std_leave_types_table.php` | migration — never edited by this workflow |
| `resources/views/components/**` and `Modules/TenantCore/**` | shared components, including `x-backend.table.action-trashed` |
| `app/Helpers/activityLog.php` | common helper |

## 1. Blockers reachable today

None. The two High findings are SLT-01 (§3) and SLT-05 (§9, DECISION).

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **SLT-01** · H · TXN-01 · `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:46-52` — wrap each mutating method's write + `activityLog()` in one `DB::transaction`.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php`
  - **Before** (`StudentLeaveTypeController.php:5-10`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\StudentProfile\Http\Requests\StudentLeaveTypeRequest;
    use Modules\StudentProfile\Models\LeaveType as StudentLeaveType;
    use Modules\StudentProfile\Services\LeaveService;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\StudentProfile\Http\Requests\StudentLeaveTypeRequest;
    use Modules\StudentProfile\Models\LeaveType as StudentLeaveType;
    use Modules\StudentProfile\Services\LeaveService;
    ```
  - **Before** (`StudentLeaveTypeController.php:46-57`):
    ```php
    public function store(StudentLeaveTypeRequest $request)
    {
        Gate::authorize('tenant.school-setup.leave-type.create');

        $leaveType = $this->leaveService->createLeaveType($request->validated());

        activityLog($leaveType, 'Created', ['message' => 'Leave type created']);

        return redirect()
            ->route('student-profile.student-leave.index', ['tab' => 'leave-type'])
            ->with('success', 'Student leave type created successfully');
    }
    ```
  - **After:**
    ```php
    public function store(StudentLeaveTypeRequest $request)
    {
        Gate::authorize('tenant.school-setup.leave-type.create');

        DB::transaction(function () use ($request) {
            $leaveType = $this->leaveService->createLeaveType($request->validated());
            activityLog($leaveType, 'Created', ['message' => 'Leave type created']);
        });

        return redirect()
            ->route('student-profile.student-leave.index', ['tab' => 'leave-type'])
            ->with('success', 'Student leave type created successfully');
    }
    ```
  - **Before** (`StudentLeaveTypeController.php:86-98`):
    ```php
    public function update(StudentLeaveTypeRequest $request, $id)
    {
        Gate::authorize('tenant.school-setup.leave-type.update');

        $leaveType = $this->leaveService->getLeaveType((int) $id);
        $this->leaveService->updateLeaveType($leaveType, $request->validated());

        activityLog($leaveType, 'Updated', ['message' => 'Leave type updated']);

        return redirect()
            ->route('student-profile.student-leave.index', ['tab' => 'leave-type'])
            ->with('success', 'Student leave type updated successfully');
    }
    ```
  - **After:**
    ```php
    public function update(StudentLeaveTypeRequest $request, $id)
    {
        Gate::authorize('tenant.school-setup.leave-type.update');

        $leaveType = $this->leaveService->getLeaveType((int) $id);

        DB::transaction(function () use ($leaveType, $request) {
            $this->leaveService->updateLeaveType($leaveType, $request->validated());
            activityLog($leaveType, 'Updated', ['message' => 'Leave type updated']);
        });

        return redirect()
            ->route('student-profile.student-leave.index', ['tab' => 'leave-type'])
            ->with('success', 'Student leave type updated successfully');
    }
    ```
  - **Before** (`StudentLeaveTypeController.php:115-127`):
    ```php
    public function destroy($id)
    {
        Gate::authorize('tenant.school-setup.leave-type.delete');

        $leaveType = $this->leaveService->getLeaveType((int) $id);
        $this->leaveService->deleteLeaveType($leaveType);

        activityLog($leaveType, 'Deleted', ['message' => 'Leave type deleted']);

        return redirect()
            ->route('student-profile.student-leave.index', ['tab' => 'leave-type'])
            ->with('success', 'Student leave type deleted successfully');
    }
    ```
  - **After:**
    ```php
    public function destroy($id)
    {
        Gate::authorize('tenant.school-setup.leave-type.delete');

        $leaveType = $this->leaveService->getLeaveType((int) $id);

        DB::transaction(function () use ($leaveType) {
            $this->leaveService->deleteLeaveType($leaveType);
            activityLog($leaveType, 'Deleted', ['message' => 'Leave type deleted']);
        });

        return redirect()
            ->route('student-profile.student-leave.index', ['tab' => 'leave-type'])
            ->with('success', 'Student leave type deleted successfully');
    }
    ```
  - **Before** (`StudentLeaveTypeController.php:132-143`):
    ```php
    public function restore($id)
    {
        Gate::authorize('tenant.school-setup.leave-type.restore');

        $leaveType = $this->leaveService->restoreLeaveType((int) $id);

        activityLog($leaveType, 'Restored', ['message' => 'Leave type restored']);

        return redirect()
            ->route('student-profile.student-leave.index', ['tab' => 'leave-type'])
            ->with('success', 'Student leave type restored successfully');
    }
    ```
  - **After:**
    ```php
    public function restore($id)
    {
        Gate::authorize('tenant.school-setup.leave-type.restore');

        DB::transaction(function () use ($id) {
            $leaveType = $this->leaveService->restoreLeaveType((int) $id);
            activityLog($leaveType, 'Restored', ['message' => 'Leave type restored']);
        });

        return redirect()
            ->route('student-profile.student-leave.index', ['tab' => 'leave-type'])
            ->with('success', 'Student leave type restored successfully');
    }
    ```
  - **Before** (`StudentLeaveTypeController.php:148-160`):
    ```php
    public function forceDelete($id)
    {
        Gate::authorize('tenant.school-setup.leave-type.forceDelete');

        $leaveType = $this->leaveService->getLeaveType((int) $id, true);
        $this->leaveService->forceDeleteLeaveType((int) $id);

        activityLog($leaveType, 'Force Deleted', ['message' => 'Leave type permanently deleted']);

        return redirect()
            ->route('student-profile.student-leave.index', ['tab' => 'leave-type'])
            ->with('success', 'Student leave type permanently deleted');
    }
    ```
  - **After:**
    ```php
    public function forceDelete($id)
    {
        Gate::authorize('tenant.school-setup.leave-type.forceDelete');

        $leaveType = $this->leaveService->getLeaveType((int) $id, true);

        DB::transaction(function () use ($leaveType, $id) {
            $this->leaveService->forceDeleteLeaveType((int) $id);
            activityLog($leaveType, 'Force Deleted', ['message' => 'Leave type permanently deleted']);
        });

        return redirect()
            ->route('student-profile.student-leave.index', ['tab' => 'leave-type'])
            ->with('success', 'Student leave type permanently deleted');
    }
    ```
  - **Before** (`StudentLeaveTypeController.php:165-178`):
    ```php
    public function toggleStatus(Request $request, StudentLeaveType $studentLeaveType)
    {
        Gate::authorize('tenant.school-setup.leave-type.update');

        $leaveType = $this->leaveService->toggleLeaveTypeStatus($studentLeaveType);

        activityLog($leaveType, 'Toggled', ['is_active' => $leaveType->is_active]);

        return response()->json([
            'success' => true,
            'is_active' => $leaveType->is_active,
            'message' => 'Status updated successfully',
        ]);
    }
    ```
  - **After:**
    ```php
    public function toggleStatus(Request $request, StudentLeaveType $studentLeaveType)
    {
        Gate::authorize('tenant.school-setup.leave-type.update');

        $leaveType = DB::transaction(function () use ($studentLeaveType) {
            $leaveType = $this->leaveService->toggleLeaveTypeStatus($studentLeaveType);
            activityLog($leaveType, 'Toggled', ['is_active' => $leaveType->is_active]);

            return $leaveType;
        });

        return response()->json([
            'success' => true,
            'is_active' => $leaveType->is_active,
            'message' => 'Status updated successfully',
        ]);
    }
    ```
  - **Verify:** `php -l Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php && grep -c "DB::transaction" Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php`
  - **Expect:** `No syntax errors detected` then `6`.
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **SLT-03** · L · AUTH-04 · `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:48` — drop the duplicate permission check in `store` and `update`; the FormRequest already checks it.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php`
  - **Before** (`StudentLeaveTypeController.php:46-48`):
    ```php
    public function store(StudentLeaveTypeRequest $request)
    {
        Gate::authorize('tenant.school-setup.leave-type.create');
    ```
  - **After:**
    ```php
    public function store(StudentLeaveTypeRequest $request)
    {
    ```
  - **Before** (`StudentLeaveTypeController.php:86-88`):
    ```php
    public function update(StudentLeaveTypeRequest $request, $id)
    {
        Gate::authorize('tenant.school-setup.leave-type.update');
    ```
  - **After:**
    ```php
    public function update(StudentLeaveTypeRequest $request, $id)
    {
    ```
  - **Verify:** `grep -n "Gate::authorize" Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php`
  - **Expect:** 10 lines; lines 48 and 88 are gone, all other abilities unchanged.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **SLT-04** · L · VAL-04 · `Modules/StudentProfile/app/Http/Requests/StudentLeaveTypeRequest.php:29` — resolve the route value without the nullsafe operator on a string.
  - **Touches:** `Modules/StudentProfile/app/Http/Requests/StudentLeaveTypeRequest.php`
  - **Before** (`StudentLeaveTypeRequest.php:27-31`):
    ```php
    public function rules(): array
    {
        $id = $this->route('student_leave_type')?->id ?? $this->route('student_leave_type');

        return [
    ```
  - **After:**
    ```php
    public function rules(): array
    {
        $routeValue = $this->route('student_leave_type');
        $id = $routeValue instanceof \Illuminate\Database\Eloquent\Model ? $routeValue->getKey() : $routeValue;

        return [
    ```
  - **Verify:** `grep -n "route('student_leave_type')?->id" Modules/StudentProfile/app/Http/Requests/StudentLeaveTypeRequest.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **SLT-07** · L · CTL-04 · `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:21` — add return types to all 11 public methods.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php`
  - **Before** (`StudentLeaveTypeController.php:5-7`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Contracts\View\View;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    ```
  - **Before** (`StudentLeaveTypeController.php:21`): `public function index(Request $request)`
  - **After:** `public function index(Request $request): RedirectResponse`
  - **Before** (`StudentLeaveTypeController.php:36`): `public function create()`
  - **After:** `public function create(): View`
  - **Before** (`StudentLeaveTypeController.php:46`): `public function store(StudentLeaveTypeRequest $request)`
  - **After:** `public function store(StudentLeaveTypeRequest $request): RedirectResponse`
  - **Before** (`StudentLeaveTypeController.php:62`): `public function show($id)`
  - **After:** `public function show($id): View`
  - **Before** (`StudentLeaveTypeController.php:74`): `public function edit($id)`
  - **After:** `public function edit($id): View`
  - **Before** (`StudentLeaveTypeController.php:86`): `public function update(StudentLeaveTypeRequest $request, $id)`
  - **After:** `public function update(StudentLeaveTypeRequest $request, $id): RedirectResponse`
  - **Before** (`StudentLeaveTypeController.php:103`): `public function trashed()`
  - **After:** `public function trashed(): View`
  - **Before** (`StudentLeaveTypeController.php:115`): `public function destroy($id)`
  - **After:** `public function destroy($id): RedirectResponse`
  - **Before** (`StudentLeaveTypeController.php:132`): `public function restore($id)`
  - **After:** `public function restore($id): RedirectResponse`
  - **Before** (`StudentLeaveTypeController.php:148`): `public function forceDelete($id)`
  - **After:** `public function forceDelete($id): RedirectResponse`
  - **Before** (`StudentLeaveTypeController.php:165`): `public function toggleStatus(Request $request, StudentLeaveType $studentLeaveType)`
  - **After:** `public function toggleStatus(Request $request, StudentLeaveType $studentLeaveType): JsonResponse`
  - **Verify:** `grep -cE 'public function [a-zA-Z]+\(.*\): (View|RedirectResponse|JsonResponse)' Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php`
  - **Expect:** `11`.
  - **Effort:** S

- [ ] **SLT-08** · L · MDL-04 · `Modules/StudentProfile/app/Models/LeaveType.php:48-56` — add return types to the two relationships.
  - **Touches:** `Modules/StudentProfile/app/Models/LeaveType.php`
  - **Before** (`LeaveType.php:7-10`):
    ```php
    use Modules\SchoolSetup\Models\User;
    use Illuminate\Database\Eloquent\Builder;
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **After:**
    ```php
    use Modules\SchoolSetup\Models\User;
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Before** (`LeaveType.php:48-56`):
    ```php
    public function leaveApplications()
    {
        return $this->hasMany(LeaveApplication::class, 'leave_type_id');
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
    ```
  - **After:**
    ```php
    public function leaveApplications(): HasMany
    {
        return $this->hasMany(LeaveApplication::class, 'leave_type_id');
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
    ```
  - **Verify:** `grep -nE 'public function (leaveApplications|createdBy)\(\): (HasMany|BelongsTo)' Modules/StudentProfile/app/Models/LeaveType.php`
  - **Expect:** two matching lines.
  - **Effort:** S

## 6. Queries & performance (F9)

None in scope — SLT-09's fix belongs to the `LeaveService` owner (see §10).

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **SLT-10** · L · STY-01 / STY-04 · `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:1` — add `strict_types` to three files and delete the commented-out Gate line.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php`, `Modules/StudentProfile/app/Http/Requests/StudentLeaveTypeRequest.php`, `Modules/StudentProfile/app/Policies/LeaveTypePolicy.php`
  - **Before** (`StudentLeaveTypeController.php:1-3`):
    ```php
    <?php

    namespace Modules\StudentProfile\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Http\Controllers;
    ```
  - **Before** (`StudentLeaveTypeController.php:23-27`):
    ```php
        Gate::authorize('tenant.school-setup.leave-type.viewAny');

        // Gate::authorize('prime.school-setup.department.viewAny');

        return redirect()->route(
    ```
  - **After:**
    ```php
        Gate::authorize('tenant.school-setup.leave-type.viewAny');

        return redirect()->route(
    ```
  - **Before** (`StudentLeaveTypeRequest.php:1-3`):
    ```php
    <?php

    namespace Modules\StudentProfile\Http\Requests;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Http\Requests;
    ```
  - **Before** (`LeaveTypePolicy.php:1-3`):
    ```php
    <?php

    namespace Modules\StudentProfile\Policies;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Policies;
    ```
  - **Verify:** `grep -rl "declare(strict_types=1)" Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php Modules/StudentProfile/app/Http/Requests/StudentLeaveTypeRequest.php Modules/StudentProfile/app/Policies/LeaveTypePolicy.php | wc -l`
  - **Expect:** `3`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **SLT-02** · M · DECISION · AUTH-05 — the registered `LeaveTypePolicy` is never consulted; what should happen to it?
  - **Why it is a decision:** it is an authorization-architecture choice (wire the policy, or delete the dead registration) and option (b) touches a shared provider.
  - (a) ⭐ Wire the controller to the policy — replace the string abilities with `$this->authorize('viewAny', LeaveType::class)` and `$this->authorize('view', $leaveType)` (record-level abilities after the load); the policy becomes live and permission strings move to one place (AUTH-06). Touches the controller and possibly the policy.
  - (b) Remove the dead registration from `StudentProfileServiceProvider` and delete `LeaveTypePolicy.php`, keeping the string abilities as the single mechanism. Touches a shared provider and deletes a class.
  - (c) Leave as is and record it as accepted debt.
  - ➜ Choice: ____

- [ ] **SLT-05** · H · DECISION · RTE-01 — `restore` changes state over GET; change it to a CSRF-protected verb?
  - **Why it is a decision:** it changes a route verb and touches a shared route file plus the shared `action-trashed` component.
  - (a) ⭐ Change the route to `Route::delete('student-leave-types/{id}/restore', ...)` and make `x-backend.table.action-trashed` submit a DELETE (form + `@csrf`); the browser cannot prefetch a mutation and CSRF is enforced. Touches `Modules/StudentProfile/routes/web.php` and the shared component.
  - (b) Change the route to `Route::post(...)` and have `action-trashed` submit a POST form with `@csrf`. Same two files.
  - (c) Leave as GET and record it as accepted risk.
  - ➜ Choice: ____

- [ ] **SLT-06** · M · DECISION · CTL-03 — use route model binding on show/edit/update/destroy?
  - **Why it is a decision:** the clean fix renames the resource route parameters (a shared route file) or accepts the current `$id` + service-load shape.
  - (a) ⭐ Defer to the controller-shape pass (D3) — keep `$id` and the service load for now.
  - (b) Rename the resource parameters to `{studentLeaveType}` and type-hint `StudentLeaveType $studentLeaveType` in the four methods now. Touches `Modules/StudentProfile/routes/web.php` and the controller.
  - (c) Leave as is and record it as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| SLT-09 | The duplicate lookup exists because `LeaveService::forceDeleteLeaveType(int $id)` re-loads the row the controller already loaded. The fix belongs to the `StdLeaveController` report that owns `LeaveService.php`; this controller cannot avoid the load without a service change. |
