# Final Audit — StudentProfile / StudentLeaveTypeController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php` (179 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/student-profile/student-leave-types` (redirects to `/student-profile/student-leave?tab=leave-type`) · `/student-profile/student-leave-types/create` · `/student-profile/student-leave-types/{id}` · `/student-profile/student-leave-types/{id}/edit` · `/student-profile/student-leave-types/trash` · `/student-profile/student-leave-types/{id}/restore` · `/student-profile/student-leave-types/{id}/force-delete` · `POST /student-profile/student-leave-types/{studentLeaveType}/toggle-status` |
| Menu path | Student Management → Student Leave → Leave Type tab (the list is rendered by `StdLeaveController` inside `leave-management/index.blade.php`; this controller owns the create/edit/show/trash screens and every write) |
| Who uses it | School Admin and Super Admin. Both hold all seven `tenant.school-setup.leave-type.*` permissions in the tenant DB `xyz_school_00000000000040008000_202627` (measured via `sys_role_has_permissions_jnt`). |
| What a user does here | Maintains the master list of student leave types (Sick Leave, Casual Leave, …): sets the code, display name, annual/per-application day caps, whether a document is required, whether half-days are allowed, the advance-notice days, and an active flag. A leave type can be deactivated, soft-deleted, restored, or permanently deleted. |
| Tables written | `std_leave_types` (create / update / soft delete / restore / force delete / toggle), `sys_activity_logs` (one audit row per write, written by the `activityLog()` helper) |
| Tables read | `std_leave_types`, `sys_permissions`, `sys_roles`, `sys_role_has_permissions_jnt` |
| Live data | `std_leave_types`: 10 live rows, 0 trashed. No duplicate `code` values. Permissions: 7 `tenant.school-setup.leave-type.*` rows exist and are granted to School Admin and Super Admin. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready**. It is small and easy to read, and every routed method does authorize, but two High findings stand out: (1) every write and its audit-log row are committed **separately**, so a failure between them leaves the data changed with no audit trail — the delete path additionally does two writes (`update` then `delete`) with no transaction at all; (2) `restore` is a state-changing action served over **GET**, so a link prefetcher or crawler can un-delete a leave type with no CSRF token. The single worst finding is SLT-01 (non-atomic write + audit log). Rough effort to apply the plan: **S–M** (a few hours), all inside the controller, the FormRequest, and the model.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 2 | 6 | 3 | 10 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean (usage only — LeaveService owned elsewhere) |
| F2 Transactions/Audit | SLT-01 | F9 Queries/Perf | SLT-09 |
| F3 Authorization | SLT-02, SLT-03 | F10 Views | clean |
| F4 Validation | SLT-04 | F11 Security/Tenancy | clean |
| F5 Routes | SLT-05 | F12 Style | SLT-10 |
| F6 Controller shape | SLT-06, SLT-07 | F13 Deep read | see table |
| F7 Models | SLT-08 | | |

DECISION items: SLT-02, SLT-05, SLT-06.

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php` | controller | 179 | this report | ✅ |
| 2 | `Modules/StudentProfile/app/Models/LeaveType.php` | model | 57 | this report | ✅ |
| 3 | `Modules/StudentProfile/app/Policies/LeaveTypePolicy.php` | policy | 44 | this report | ✅ |
| 4 | `Modules/StudentProfile/app/Http/Requests/StudentLeaveTypeRequest.php` | form request | 80 | this report | ✅ |
| 5 | `Modules/StudentProfile/app/Services/LeaveService.php` | service | 683 | ↗ [gaurav/StudentProfile/StdLeaveController](../StdLeaveController-done/01-report.md) | ↗ linked |
| 6 | `Modules/StudentProfile/resources/views/leave-management/leave-types/create.blade.php` | view | 121 | this report | ✅ |
| 7 | `Modules/StudentProfile/resources/views/leave-management/leave-types/edit.blade.php` | view | 120 | this report | ✅ |
| 8 | `Modules/StudentProfile/resources/views/leave-management/leave-types/show.blade.php` | view | 132 | this report | ✅ |
| 9 | `Modules/StudentProfile/resources/views/leave-management/leave-types/trash.blade.php` | view | 57 | this report | ✅ |
| 10 | `Modules/StudentProfile/resources/views/leave-management/leave-types/index.blade.php` | view | 143 | ↗ [gaurav/StudentProfile/StdLeaveController](../StdLeaveController-done/01-report.md) | ↗ linked |
| 11 | `app/Helpers/activityLog.php` | helper (common glue) | 51 | common | ✅ usage checked |
| 12 | `app/Traits/AuthorizesTenantFeature.php` | trait (common glue) | 56 | common | ✅ usage checked |

`LeaveService.php` is owned by the `StdLeaveController` report. This report checks only how this controller calls it (method names, arguments, atomicity); the service's internals are that report's business. `leave-types/index.blade.php` is rendered by `StdLeaveController@index` via `leave-management/index.blade.php`, which is the redirect target of this controller's `index()`.

No pre-applied files.

## 4. Routes

```
GET|HEAD  student-profile/student-leave-types                                      student-profile.student-leave-types.index            Modules\StudentProfile\Http\Controllers\StudentLeaveTypeController@index
POST      student-profile/student-leave-types                                      student-profile.student-leave-types.store            Modules\StudentProfile\Http\Controllers\StudentLeaveTypeController@store
GET|HEAD  student-profile/student-leave-types/create                               student-profile.student-leave-types.create           Modules\StudentProfile\Http\Controllers\StudentLeaveTypeController@create
GET|HEAD  student-profile/student-leave-types/trash                                student-profile.student-leave-types.trashed          Modules\StudentProfile\Http\Controllers\StudentLeaveTypeController@trashed
DELETE    student-profile/student-leave-types/{id}/force-delete                    student-profile.student-leave-types.forceDelete      Modules\StudentProfile\Http\Controllers\StudentLeaveTypeController@forceDelete
GET|HEAD  student-profile/student-leave-types/{id}/restore                         student-profile.student-leave-types.restore          Modules\StudentProfile\Http\Controllers\StudentLeaveTypeController@restore
POST      student-profile/student-leave-types/{studentLeaveType}/toggle-status     student-profile.student-leave-types.toggleStatus     Modules\StudentProfile\Http\Controllers\StudentLeaveTypeController@toggleStatus
GET|HEAD  student-profile/student-leave-types/{student_leave_type}                 student-profile.student-leave-types.show             Modules\StudentProfile\Http\Controllers\StudentLeaveTypeController@show
PUT|PATCH student-profile/student-leave-types/{student_leave_type}                 student-profile.student-leave-types.update           Modules\StudentProfile\Http\Controllers\StudentLeaveTypeController@update
DELETE    student-profile/student-leave-types/{student_leave_type}                 student-profile.student-leave-types.destroy          Modules\StudentProfile\Http\Controllers\StudentLeaveTypeController@destroy
GET|HEAD  student-profile/student-leave-types/{student_leave_type}/edit            student-profile.student-leave-types.edit             Modules\StudentProfile\Http\Controllers\StudentLeaveTypeController@edit
```

Unrouted public methods: none — all 11 public methods are routed.

Middleware on every route (measured from `route:list --json`): `web`, `PreventAccessFromCentralDomains`, `InitializeTenancyByDomain`, `EnsureTenantIsActive`, `Authenticate`, `EnsureEmailIsVerified`, `EnsureTenantHasModule:STUDENT`. Tenant middleware is present (RTE-05 clean).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 21 | GET /student-profile/student-leave-types | `tenant.school-setup.leave-type.viewAny` | none | none | none | — |
| `create` | 36 | GET /student-profile/student-leave-types/create | `tenant.school-setup.leave-type.create` | none | none | none | — |
| `store` | 46 | POST /student-profile/student-leave-types | `tenant.school-setup.leave-type.create` | none | `Created` | std_leave_types, sys_activity_logs | SLT-01, SLT-03 |
| `show` | 62 | GET /student-profile/student-leave-types/{student_leave_type} | `tenant.school-setup.leave-type.view` | none | none | none | SLT-06 |
| `edit` | 74 | GET /student-profile/student-leave-types/{student_leave_type}/edit | `tenant.school-setup.leave-type.update` | none | none | none | SLT-06 |
| `update` | 86 | PUT/PATCH /student-profile/student-leave-types/{student_leave_type} | `tenant.school-setup.leave-type.update` | none | `Updated` | std_leave_types, sys_activity_logs | SLT-01, SLT-03, SLT-06 |
| `trashed` | 103 | GET /student-profile/student-leave-types/trash | `tenant.school-setup.leave-type.restore` | none | none | none | — |
| `destroy` | 115 | DELETE /student-profile/student-leave-types/{student_leave_type} | `tenant.school-setup.leave-type.delete` | none | `Deleted` | std_leave_types, sys_activity_logs | SLT-01, SLT-06 |
| `restore` | 132 | GET /student-profile/student-leave-types/{id}/restore | `tenant.school-setup.leave-type.restore` | none | `Restored` | std_leave_types, sys_activity_logs | SLT-01, SLT-05 |
| `forceDelete` | 148 | DELETE /student-profile/student-leave-types/{id}/force-delete | `tenant.school-setup.leave-type.forceDelete` | none | `Force Deleted` | std_leave_types, sys_activity_logs | SLT-01, SLT-09 |
| `toggleStatus` | 165 | POST /student-profile/student-leave-types/{studentLeaveType}/toggle-status | `tenant.school-setup.leave-type.update` | none | `Toggled` | std_leave_types, sys_activity_logs | SLT-01 |

## 6. Findings

### F1 — Errors

Clean — no `try`/`catch`, no `getMessage()`, and the one `findOrFail()` lives in `LeaveService` (not in a catch). Proven by:
```
$ grep -nE 'try ?\{|catch ?\(|getMessage|findOrFail' Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php
(no output)
```

### F2 — Transactions and audit

#### SLT-01 · H · TXN-01 — a write and its audit-log row commit separately (six methods)

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (two models, a model + its audit row) runs inside ONE `DB::transaction`* (also TXN-04: `activityLog()` inside the transaction, after the write) |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:46-52`, method `store()` — same shape in `update()` 86-93, `destroy()` 115-122, `restore()` 132-138, `forceDelete()` 148-155, `toggleStatus()` 165-171 |
| **Root cause** | The controller calls the `LeaveService` write method and then calls `activityLog()` on the next statement. There is no `DB::transaction()` anywhere in the controller (confirmed below), so the model write and the `sys_activity_logs` insert are two independent commits. The service's `deleteLeaveType()` is itself two writes (`update(['is_active' => false])` then `delete()`), so `destroy` can leave `is_active = false` on a row that was never soft-deleted if the second write fails. |
| **Consequence** | If the audit insert fails (DB hiccup, missing `user_id` FK), the leave type is changed but the school can never prove who changed it; and a partial delete leaves a deactivated row that is not in the trash. |
| **Reproduce** | Static only — the defect is the missing transaction, not a button; any write path shows it (for example POST `/student-profile/student-leave-types`). |
| **Fix approach** | Wrap the service write and the `activityLog()` call in one `DB::transaction(function () { ... })` per mutating method, keeping the read (`getLeaveType`) outside it. Add `use Illuminate\Support\Facades\DB;`. |
| **Plan item** | SLT-01 in `02-fix-plan.md` §3 |

```php
    public function store(StudentLeaveTypeRequest $request)
    {
        Gate::authorize('tenant.school-setup.leave-type.create');

        $leaveType = $this->leaveService->createLeaveType($request->validated());

        activityLog($leaveType, 'Created', ['message' => 'Leave type created']);
```

**Evidence**
```
$ grep -nE 'DB::transaction|activityLog' Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php
52:        activityLog($leaveType, 'Created', ['message' => 'Leave type created']);
93:        activityLog($leaveType, 'Updated', ['message' => 'Leave type updated']);
122:        activityLog($leaveType, 'Deleted', ['message' => 'Leave type deleted']);
138:        activityLog($leaveType, 'Restored', ['message' => 'Leave type restored']);
155:        activityLog($leaveType, 'Force Deleted', ['message' => 'Leave type permanently deleted']);
171:        activityLog($leaveType, 'Toggled', ['is_active' => $leaveType->is_active]);
```
No line matches `DB::transaction`; the helper table is `sys_activity_logs` (`Modules/GlobalMaster/app/Models/ActivityLog.php:14`).

### F3 — Authorization

#### SLT-02 · M · AUTH-05 — the registered `LeaveTypePolicy` is never consulted

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — *no dead permission logic*; `Gate::authorize('some.string')` never reaches a Policy, so every Policy that nothing consults must be reported |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:23`, method `index()` — every authorization in the file is a plain string |
| **Root cause** | `StudentProfileServiceProvider` registers `Gate::policy(LeaveType::class, LeaveTypePolicy::class)` (line 68), but the controller only ever calls `Gate::authorize('tenant.school-setup.leave-type.<action>')` with a string ability. Laravel only consults a Policy when the ability is checked against the model class or an instance (`Gate::authorize('view', $leaveType)`), so `LeaveTypePolicy` is dead code. |
| **Consequence** | A future editor can "fix" the policy and believe access changed, when in fact the string abilities are the only thing enforced; the policy's seven methods have zero effect on the screen. |
| **Reproduce** | Static only — no browser action changes the outcome, because the policy is never entered. |
| **Fix approach** | Decide whether the policy is the intended mechanism (then wire `$this->authorize(...)` to it) or dead code (then remove the registration). Listed as a DECISION because wiring it changes every method's authorization call shape. |
| **Plan item** | SLT-02 in `02-fix-plan.md` §9 |

```php
        Gate::authorize('tenant.school-setup.leave-type.viewAny');

        // Gate::authorize('prime.school-setup.department.viewAny');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php
23:        Gate::authorize('tenant.school-setup.leave-type.viewAny');
25:        // Gate::authorize('prime.school-setup.department.viewAny');
38:        Gate::authorize('tenant.school-setup.leave-type.create');
48:        Gate::authorize('tenant.school-setup.leave-type.create');
64:        Gate::authorize('tenant.school-setup.leave-type.view');
76:        Gate::authorize('tenant.school-setup.leave-type.update');
88:        Gate::authorize('tenant.school-setup.leave-type.update');
105:        Gate::authorize('tenant.school-setup.leave-type.restore');
117:        Gate::authorize('tenant.school-setup.leave-type.delete');
134:        Gate::authorize('tenant.school-setup.leave-type.restore');
150:        Gate::authorize('tenant.school-setup.leave-type.forceDelete');
167:        Gate::authorize('tenant.school-setup.leave-type.update');

$ grep -rn "Gate::policy(LeaveType" Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php
68:        Gate::policy(LeaveType::class, LeaveTypePolicy::class);
```

#### SLT-03 · L · AUTH-04 — the same permission is checked twice on store and update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:46-48`, method `store()` — same duplication in `update()` at line 88 |
| **Root cause** | `StudentLeaveTypeRequest::authorize()` calls `authorizeByCrudPermission('tenant.school-setup.leave-type')`, which maps POST to `.create` and PUT/PATCH to `.update`. The controller then re-checks the identical ability with `Gate::authorize(...)` on line 48 (store) and line 88 (update). |
| **Consequence** | One request performs the same permission check twice; a future change to one string silently diverges from the other, and the duplicate makes it unclear which layer owns authorization. |
| **Reproduce** | Static only — both checks currently agree, so no user-visible difference. |
| **Fix approach** | Keep the Form Request check (it runs first) and delete the two redundant `Gate::authorize()` lines in `store` and `update`. |
| **Plan item** | SLT-03 in `02-fix-plan.md` §4 |

```php
    public function store(StudentLeaveTypeRequest $request)
    {
        Gate::authorize('tenant.school-setup.leave-type.create');

        $leaveType = $this->leaveService->createLeaveType($request->validated());
```

**Evidence**
```
$ grep -n "Gate::authorize\|authorizeByCrudPermission" Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php Modules/StudentProfile/app/Http/Requests/StudentLeaveTypeRequest.php
Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:48:        Gate::authorize('tenant.school-setup.leave-type.create');
Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:88:        Gate::authorize('tenant.school-setup.leave-type.update');
Modules/StudentProfile/app/Http/Requests/StudentLeaveTypeRequest.php:21:        return $this->authorizeByCrudPermission('tenant.school-setup.leave-type');
```

### F4 — Validation and input

#### SLT-04 · L · VAL-04 — the uniqueness `ignore()` reads `?->id` from a string route parameter

| Field | Value |
|---|---|
| **Rule** | VAL-04 (L, lowered from the H default) — *uniqueness rules must mirror the real index*; here the rule resolves its ignore key through the nullsafe operator on a value that is a string, not a model. No wrong validation results, so it is lowered to L. |
| **Where** | `Modules/StudentProfile/app/Http/Requests/StudentLeaveTypeRequest.php:29`, method `rules()` |
| **Root cause** | The update controller signature is `update(StudentLeaveTypeRequest $request, $id)` — `$id` is untyped, so Laravel never binds the route parameter `student_leave_type` to a model. `$this->route('student_leave_type')` therefore returns the raw string id, and `'5'?->id` emits "Attempt to read property \"id\" on string" before falling back to the string via `??`. |
| **Consequence** | Every update request writes a PHP warning to the log; the `ignore()` still receives the correct id, so validation is correct — the cost is log noise and a fragile expression. |
| **Reproduce** | Submit any edit form (`PUT /student-profile/student-leave-types/{id}`); the Laravel log gains an "Attempt to read property \"id\" on string" warning. |
| **Fix approach** | Resolve the route value once, and only read `->getKey()` when it is actually a model instance. |
| **Plan item** | SLT-04 in `02-fix-plan.md` §5 |

```php
    public function rules(): array
    {
        $id = $this->route('student_leave_type')?->id ?? $this->route('student_leave_type');

        return [
```

**Evidence**
```
$ php artisan tinker --execute='$s="5"; var_dump($s?->id);'
  <warning> WARNING </warning> Attempt to read property "id" on string on line 2.
NULL
```

### F5 — Routes

#### SLT-05 · H · RTE-01 — `restore` changes state over GET (no CSRF)

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET*; GET has no CSRF protection and link prefetchers trigger it |
| **Where** | `Modules/StudentProfile/routes/web.php:192`, route `student-profile.student-leave-types.restore`, controller method `restore()` |
| **Root cause** | The restore action is registered with `Route::get('student-leave-types/{id}/restore', ...)`. Restoring is a write, so it belongs on a verb with CSRF protection (DELETE or POST). |
| **Consequence** | Any tool that follows links (browser prefetch, email scanner, crawler, an `<img>` tag on a third-party page) can un-delete a leave type as the logged-in admin, with no confirmation and no CSRF token. |
| **Reproduce** | As School Admin, open `/student-profile/student-leave-types/5/restore` in the address bar — the record is restored on a plain GET. |
| **Fix approach** | Change the verb in the route file to DELETE (or POST) and update the `action-trashed` component usage that links to it. This touches a shared route file and a shared component, so it is a DECISION. |
| **Plan item** | SLT-05 in `02-fix-plan.md` §9 |

```php
    Route::get('student-leave-types/{id}/restore', [StudentLeaveTypeController::class, 'restore'])->name('student-leave-types.restore');
```

**Evidence**
```
$ grep -n "restore" Modules/StudentProfile/routes/web.php
54:    Route::patch('/student/{id}/restore', [StudentController::class, 'restore'])
55:        ->name('student.restore');
170:    Route::get('medical-incidents/{id}/restore', [MedicalIncidentController::class, 'restore'])->name('medical-incidents.restore');
192:    Route::get('student-leave-types/{id}/restore', [StudentLeaveTypeController::class, 'restore'])->name('student-leave-types.restore');
```
Line 54 shows the project's own better pattern (PATCH). Line 192 is a GET.

### F6 — Controller shape

#### SLT-06 · M · CTL-03 — no route model binding on show/edit/update/destroy

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:62-66`, method `show()` — same in `edit()` 74-80, `update()` 86-91, `destroy()` 115-120 |
| **Root cause** | The resource route parameter is `student_leave_type` but the methods take an untyped `$id` and load through `LeaveService::getLeaveType()`. Because the parameter is untyped, Laravel's `SubstituteBindings` cannot bind the model; the same is why the FormRequest hits the string warning in SLT-04. |
| **Consequence** | Four methods repeat the load-and-cast boilerplate instead of one binding, and the route parameter name no longer tells the truth about the argument. No user-visible failure today (the service still raises a 404 via `findOrFail`). |
| **Reproduce** | Static only — the load succeeds; the concern is duplicated loading logic and the broken binding contract. |
| **Fix approach** | Bind the model (type-hint matching the route parameter name, or rename the route parameter to `{studentLeaveType}`), then delete the manual `getLeaveType()` calls. Because the cleanest form renames a route parameter in a shared route file, this is a DEFERRED decision. |
| **Plan item** | SLT-06 in `02-fix-plan.md` §9 |

```php
    public function show($id)
    {
        Gate::authorize('tenant.school-setup.leave-type.view');

        $leaveType = $this->leaveService->getLeaveType((int) $id);
```

**Evidence**
```
$ grep -nE 'public function (show|edit|update|destroy)\(' Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php
62:    public function show($id)
74:    public function edit($id)
86:    public function update(StudentLeaveTypeRequest $request, $id)
115:    public function destroy($id)
```

#### SLT-07 · L · CTL-04 — public methods declare no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:21`, method `index()` — all 11 public methods lack a return type |
| **Root cause** | The methods were written without `: View`, `: RedirectResponse` or `: JsonResponse`. Return types are absent throughout, so `php -l` cannot catch a method that returns the wrong type at runtime. |
| **Consequence** | IDE and static analysis give no help; a future edit that returns `back()` from a `: View` method would only fail at runtime. |
| **Reproduce** | Static only. |
| **Fix approach** | Add the correct return type to every public method. |
| **Plan item** | SLT-07 in `02-fix-plan.md` §5 |

```php
    public function index(Request $request)
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z]+\(' Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php
21:    public function index(Request $request)
36:    public function create()
46:    public function store(StudentLeaveTypeRequest $request)
62:    public function show($id)
74:    public function edit($id)
86:    public function update(StudentLeaveTypeRequest $request, $id)
103:    public function trashed()
115:    public function destroy($id)
132:    public function restore($id)
148:    public function forceDelete($id)
165:    public function toggleStatus(Request $request, StudentLeaveType $studentLeaveType)
```

### F7 — Models

#### SLT-08 · L · MDL-04 — relationships have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed* (`: BelongsTo`, `: HasMany`) |
| **Where** | `Modules/StudentProfile/app/Models/LeaveType.php:48-56`, methods `leaveApplications()` and `createdBy()` |
| **Root cause** | Both relationships return the builder without declaring `: HasMany` / `: BelongsTo`. |
| **Consequence** | No runtime failure; the model loses the static-analysis and IDE support that typed relations give. Both relations do resolve (verified). |
| **Reproduce** | Static only. |
| **Fix approach** | Add the return types and the two imports (`HasMany`, `BelongsTo`). |
| **Plan item** | SLT-08 in `02-fix-plan.md` §5 |

```php
    public function leaveApplications()
    {
        return $this->hasMany(LeaveApplication::class, 'leave_type_id');
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
```

**Evidence**
```
$ grep -nE 'public function (leaveApplications|createdBy)' Modules/StudentProfile/app/Models/LeaveType.php
48:    public function leaveApplications()
53:    public function createdBy()

$ php artisan tinker --execute='... class_exists(...) ...'
LeaveApplication_exists=1
User_exists=1
```
Both relation target classes exist, so the relations resolve.

### F8 — Services and jobs

Clean for this controller's usage — `LeaveService` is constructor-injected, the used read methods are reads only, no HTTP/session/redirect calls inside them, and no jobs are involved. Proven by:
```
$ grep -nE 'request\(|session\(|redirect\(|response\(|back\(|Http::' Modules/StudentProfile/app/Services/LeaveService.php
(no output)
```
The service's internal two-write `deleteLeaveType()` (update + delete, no transaction) is recorded as a cross-cutting note in §7; `LeaveService.php` is owned by the `StdLeaveController` report.

### F9 — Queries and performance

#### SLT-09 · L · QRY-12 — `forceDelete` loads the same row twice

| Field | Value |
|---|---|
| **Rule** | QRY-12 (L) — *identical lookups repeated in one request should be resolved once* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:152-153`, method `forceDelete()` |
| **Root cause** | The controller calls `getLeaveType((int) $id, true)` and then `forceDeleteLeaveType((int) $id)`, which itself calls `getLeaveType($id, true)` a second time (`LeaveService.php:213`). The same row is selected twice in one request. |
| **Consequence** | One extra SELECT per force-delete; harmless at this scale, but the row is already in hand. |
| **Reproduce** | Static only. |
| **Fix approach** | Use the loaded `$leaveType` rather than re-passing the id (the service is owned elsewhere, so the smallest in-scope fix is to log from the loaded model and keep the service call; a full fix belongs with the service). |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
        $leaveType = $this->leaveService->getLeaveType((int) $id, true);
        $this->leaveService->forceDeleteLeaveType((int) $id);
```

**Evidence**
```
$ grep -nE 'getLeaveType|forceDeleteLeaveType' Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php
66:        $leaveType = $this->leaveService->getLeaveType((int) $id);
78:        $leaveType = $this->leaveService->getLeaveType((int) $id);
90:        $leaveType = $this->leaveService->getLeaveType((int) $id);
119:        $leaveType = $this->leaveService->getLeaveType((int) $id);
152:        $leaveType = $this->leaveService->getLeaveType((int) $id, true);
153:        $this->leaveService->forceDeleteLeaveType((int) $id);
```

### F10 — Views

Clean — no queries in Blade, no `{!! !!}`, no relation used in a `@foreach`, and the trash list uses `x-backend.table.action-trashed`. Proven by:
```
$ grep -nE 'Model::|DB::|->where\(|->get\(\)|->count\(\)|\{!! !!|action-trashed' Modules/StudentProfile/resources/views/leave-management/leave-types/*.blade.php
Modules/StudentProfile/resources/views/leave-management/leave-types/trash.blade.php:30: <x-backend.table.action-trashed :id="$type->id" url="student-profile.student-leave-types" tab="leave-type"
```
The only hit is the `action-trashed` component in the trash view; no query or raw-output pattern was found. `show.blade.php` lazily reads `$leaveType->createdBy?->name` once (not in a loop).

### F11 — Security and tenancy

Clean — no `env()`, no hard-coded ids or `?? 1`, no secrets logged, no cache/static cache, and no central model is reached from tenant context. Proven by:
```
$ grep -nE "env\(|\?\? 1|Log::|tenancy\(\)->central|asset\('storage" Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php Modules/StudentProfile/app/Http/Requests/StudentLeaveTypeRequest.php
(no output)
```

### F12 — Style

#### SLT-10 · L · STY-01 / STY-04 — missing `strict_types` and commented-out code

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files*; STY-04 (L) — *no commented-out code* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:1` (no `strict_types`), line 25 (commented-out Gate) — same missing declaration in `StudentLeaveTypeRequest.php:1` and `LeaveTypePolicy.php:1` |
| **Root cause** | The controller and the two other new-class files were created without `declare(strict_types=1);`; the controller also keeps a single commented-out `Gate::authorize` line from an earlier copy-paste. The model `LeaveType.php` correctly has the declaration. |
| **Consequence** | Files drift from the project style; the commented-out line points a future reader at a permission name that does not exist in this controller. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag in the three files and delete the commented-out Gate line. One item per file is grouped into one style item. |
| **Plan item** | SLT-10 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\StudentProfile\Http\Controllers;
```

**Evidence**
```
$ grep -nE 'declare\(strict_types|// Gate' Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php Modules/StudentProfile/app/Http/Requests/StudentLeaveTypeRequest.php Modules/StudentProfile/app/Models/LeaveType.php Modules/StudentProfile/app/Policies/LeaveTypePolicy.php
Modules/StudentProfile/app/Http/Controllers/StudentLeaveTypeController.php:25:        // Gate::authorize('prime.school-setup.department.viewAny');
Modules/StudentProfile/app/Models/LeaveType.php:3:declare(strict_types=1);
```
Only `LeaveType.php` declares `strict_types`; the controller's line 25 is the commented-out Gate.

### F13 — Deep read (answer all 8 questions for every mutating method)

Questions: (1) wrong overwrite (2) delete before replace (3) duplicate implementation (4) soft-delete × unique index (5) race (6) authorization hole (7) message lies (8) dead feature.

| Method | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok | ok | ok | ok | SLT-02 |
| `update` | ok | ok | ok | ok | ok | ok | ok | SLT-02 |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | SLT-02 |
| `restore` | ok | ok | ok | ok | ok | ok | ok | SLT-02 |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | SLT-02 |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | SLT-02 |

Notes on the answers:
- (1) wrong overwrite: `update` writes the whole validated payload; `destroy` sets `is_active = false` then soft-deletes; no per-row override is wiped.
- (4) soft-delete × unique index: the DDL unique index is `(code, deleted_at)` with a nullable `deleted_at`, so MySQL cannot enforce uniqueness among live rows — but the FormRequest rule blocks live duplicates and `restore` does not re-activate, so no duplicate is reachable from this screen. Recorded in §7 as a schema note.
- (5) race: `toggleStatus` is a read-then-write with no lock; concurrent toggles lose one flip (last write wins). Benign for a status flag, recorded as accepted.
- (8) dead feature: `LeaveTypePolicy` is registered but never consulted (SLT-02).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/StudentProfile/app/Services/LeaveService.php` | `deleteLeaveType()` (lines 180-184) performs two writes — `update(['is_active' => false])` then `delete()` — with no `DB::transaction`, so the two can diverge. Owned by the `StdLeaveController` report; this controller relies on it, so fixing SLT-01 by wrapping the call also makes it atomic here. | TXN-01 | gaurav/StudentProfile/StdLeaveController |
| `Modules/SchoolSetup/app/Http/Controllers/StudentLeaveTypeController.php` | A second controller with the same class name and near-identical CRUD exists for the `/school-setup/student-leave-types` routes. Two implementations of one operation is an SVC-04 duplicate-implementation risk. | SVC-04 | outside this report's scope |
| `database/migrations/tenant/2026_06_15_151301_create_std_leave_types_table.php:28` | `unique(['code', 'deleted_at'])` cannot enforce unique `code` among live rows because MySQL treats each NULL `deleted_at` as distinct. No user-visible failure today (the app-level rule guards live duplicates and restore keeps the row inactive). | VAL-04 | schema owner (migration — never edited by this workflow) |
| `std_leave_types` restore semantics | `deleteLeaveType` sets `is_active = false` and `restoreLeaveType` does not set it back, so a restored leave type comes back inactive while the flash says "restored successfully". Arguably intended; flagged so the message is not read as "active again". | — | inform only |
| `toggleStatus` (controller line 165) | Authorization runs after implicit route-model binding (`{studentLeaveType}`), so an unauthorized user can distinguish an existing id (403) from a missing one (404). This is the standard route-model-binding trade-off and is common across the app. | AUTH-02 | inform only |

## 8. Not covered, and why

- The `LeaveService` write methods (`createLeaveType`, `updateLeaveType`, `deleteLeaveType`, `restoreLeaveType`, `forceDeleteLeaveType`, `toggleLeaveTypeStatus`) are owned by the `StdLeaveController` report; only their signatures and this controller's use of them were checked here.
- `leave-types/index.blade.php` is rendered by `StdLeaveController@index`; this report checked it for queries/XSS only, not its full behavior.
- The `x-backend.*` components, the layout, the breadcrumb component and the `action-trashed` component are shared/common and were not audited.
- Queue jobs, mail, notifications and exports: none are reached by this controller.
- No runtime screen was opened (D4: no tests, no browser). All findings above are static or measured with read-only SQL/tinker.
