# Fix Plan — StudentProfile / AttendanceController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `database/migrations/tenant/2026_06_15_151309_create_std_student_attendance_table.php` | existing migration — never edited. The unique-index question is a DECISION (ATD-12) that needs a NEW additive migration |
| `Modules/StudentProfile/resources/views/student-attendance/create.blade.php` | view is included by other flows; the JS `marked_by` payload becomes redundant after ATD-01 but leaving the old clients' field is harmless — no view change in this plan |
| `Modules/StudentProfile/resources/views/index.blade.php` | shared view also rendered by StudentProfileController — owned by that report |
| `Modules/FrontOffice/app/Services/EarlyDepartureService.php` and `EarlyDepartureAttSyncJob.php` | callers of `AttendanceService` in another module — ATD-14 is a DECISION |
| `config/permissionslist.php` | `tenant.student-profile.attendance.*` already seeded and correct — unchanged |
| `Modules/StudentProfile/app/Models/MedicalIncident.php`, `Student.php` | owned by other reports (medical / student-report) |

## 1. Blockers reachable today

- [ ] **ATD-01** · B · ERR-01 · `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:129-170` + `:204-245` — stop sending the raw exception text to the user, and remove the controller try/catch (D1).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php`
  - **Before** (`AttendanceController.php:129-170` — scanAttendance write block):
    ```php
        try {
            $attendance = StudentAttendance::updateOrCreate(
                [
                    'student_id' => $student->id,
                    'attendance_date' => $request->date,
                    'attendance_period' => $request->period
                ],
                [
                    'academic_session_id' => $studentSession->academic_session_id,
                    'class_section_id' => $studentSession->class_section_id,
                    'status' => $request->status,
                    'remarks' => $request->remarks ?? null,
                    'marked_by' => $request->marked_by,
                    'marked_at' => now()
                ]
            );

            return response()->json([
                'status' => true,
                'message' => 'Attendance recorded successfully',
                'student' => [
                    'id' => $student->id,
                    'name' => $student->first_name . ' ' . ($student->middle_name ? $student->middle_name . ' ' : '') . $student->last_name,
                    'roll_number' => $studentSession->roll_no,
                    'class_section' => trim(($studentSession->classSection?->class?->name ?? '') . ' ' .
                        ($studentSession->classSection?->section?->name ?? ''))
                ],
                'attendance' => [
                    'id' => $attendance->id,
                    'attendance_date' => $attendance->attendance_date,
                    'attendance_period' => $attendance->attendance_period,
                    'status' => $attendance->status,
                    'remarks' => $attendance->remarks,
                    'marked_at' => $attendance->marked_at
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Failed to save attendance: ' . $e->getMessage()
            ]);
        }
    ```
  - **After:**
    ```php
        $attendance = StudentAttendance::updateOrCreate(
            [
                'student_id' => $student->id,
                'attendance_date' => $request->date,
                'attendance_period' => $request->period
            ],
            [
                'academic_session_id' => $studentSession->academic_session_id,
                'class_section_id' => $studentSession->class_section_id,
                'status' => $request->status,
                'remarks' => $request->remarks ?? null,
                'marked_by' => Auth::id(),
                'marked_at' => now()
            ]
        );

        activityLog($attendance, 'Attendance Marked', [
            'attendance_date' => $attendance->attendance_date,
            'attendance_period' => $attendance->attendance_period,
            'status' => $attendance->status,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Attendance recorded successfully',
            'student' => [
                'id' => $student->id,
                'name' => $student->first_name . ' ' . ($student->middle_name ? $student->middle_name . ' ' : '') . $student->last_name,
                'roll_number' => $studentSession->roll_no,
                'class_section' => trim(($studentSession->classSection?->class?->name ?? '') . ' ' .
                    ($studentSession->classSection?->section?->name ?? ''))
            ],
            'attendance' => [
                'id' => $attendance->id,
                'attendance_date' => $attendance->attendance_date,
                'attendance_period' => $attendance->attendance_period,
                'status' => $attendance->status,
                'remarks' => $attendance->remarks,
                'marked_at' => $attendance->marked_at
            ]
        ]);
    ```
  - **Before** (`AttendanceController.php:204-245` — manualAttendance write block):
    ```php
        try {
            $attendance = StudentAttendance::updateOrCreate(
                [
                    'student_id' => $student->id,
                    'attendance_date' => $request->date,
                    'attendance_period' => $request->period
                ],
                [
                    'academic_session_id' => $studentSession->academic_session_id,
                    'class_section_id' => $studentSession->class_section_id,
                    'status' => $request->status,
                    'remarks' => $request->remarks,
                    'marked_by' => $request->marked_by,
                    'marked_at' => now()
                ]
            );

            return response()->json([
                'status' => true,
                'message' => 'Attendance saved successfully',
                'student' => [
                    'id' => $student->id,
                    'name' => $student->first_name . ' ' . ($student->middle_name ? $student->middle_name . ' ' : '') . $student->last_name,
                    'roll_number' => $studentSession->roll_no,
                    'class_section' => trim(($studentSession->classSection?->class?->name ?? '') . ' ' .
                        ($studentSession->classSection?->section?->name ?? ''))
                ],
                'attendance' => [
                    'id' => $attendance->id,
                    'attendance_date' => $attendance->attendance_date,
                    'attendance_period' => $attendance->attendance_period,
                    'status' => $attendance->status,
                    'remarks' => $attendance->remarks,
                    'marked_at' => $attendance->marked_at
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Failed to save attendance: ' . $e->getMessage()
            ]);
        }
    ```
  - **After:**
    ```php
        $attendance = StudentAttendance::updateOrCreate(
            [
                'student_id' => $student->id,
                'attendance_date' => $request->date,
                'attendance_period' => $request->period
            ],
            [
                'academic_session_id' => $studentSession->academic_session_id,
                'class_section_id' => $studentSession->class_section_id,
                'status' => $request->status,
                'remarks' => $request->remarks,
                'marked_by' => Auth::id(),
                'marked_at' => now()
            ]
        );

        activityLog($attendance, 'Attendance Marked', [
            'attendance_date' => $attendance->attendance_date,
            'attendance_period' => $attendance->attendance_period,
            'status' => $attendance->status,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Attendance saved successfully',
            'student' => [
                'id' => $student->id,
                'name' => $student->first_name . ' ' . ($student->middle_name ? $student->middle_name . ' ' : '') . $student->last_name,
                'roll_number' => $studentSession->roll_no,
                'class_section' => trim(($studentSession->classSection?->class?->name ?? '') . ' ' .
                    ($studentSession->classSection?->section?->name ?? ''))
            ],
            'attendance' => [
                'id' => $attendance->id,
                'attendance_date' => $attendance->attendance_date,
                'attendance_period' => $attendance->attendance_period,
                'status' => $attendance->status,
                'remarks' => $attendance->remarks,
                'marked_at' => $attendance->marked_at
            ]
        ]);
    ```
  - **Verify:** `grep -n "getMessage\|try {\|catch (" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php`
  - **Expect:** no `getMessage`, no `try {`, no `catch (` in lines 88-246.
  - **Effort:** M

## 3. Errors & transactions (F1/F2)

- [ ] **ATD-02** · M · TXN-02 · `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:405-452` — rewrite bulk save with `DB::transaction(function () {...})`, single bulk upsert + one whereIn delete, validated status values, and no raw exception text.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php`
  - **Before** (`AttendanceController.php:405-452`):
    ```php
        $validated = $request->validate([
            'attendance_date' => 'required|date',
            'class_section_id' => 'required|exists:sch_class_section_jnt,id',
            'academic_session_id' => 'required|exists:sch_org_academic_sessions_jnt,id',
            'attendance' => 'required|array',
        ]);

        $userId = Auth::id();
        $data = $request->input('attendance', []);
        $academicSessionId = $request->input('academic_session_id');
        $classSectionId = $request->input('class_section_id');
        $date = $request->input('attendance_date');

        try {
            DB::beginTransaction();

            foreach ($data as $studentId => $status) {
                if ($status && $status !== 'null') {
                    StudentAttendance::updateOrCreate(
                        [
                            'student_id' => $studentId,
                            'academic_session_id' => $academicSessionId,
                            'class_section_id' => $classSectionId,
                            'attendance_date' => $date
                        ],
                        [
                            'status' => $status,
                            'marked_by' => $userId,
                            'marked_at' => now()
                        ]
                    );
                } else {
                    // Delete if status is empty or null
                    StudentAttendance::where([
                        'student_id' => $studentId,
                        'academic_session_id' => $academicSessionId,
                        'class_section_id' => $classSectionId,
                        'attendance_date' => $date
                    ])->delete();
                }
            }

            DB::commit();
            return redirect()->back()->with('success', 'Attendance saved successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Failed to save attendance: ' . $e->getMessage());
        }
    ```
  - **After:**
    ```php
        $validated = $request->validate([
            'attendance_date' => 'required|date',
            'class_section_id' => 'required|exists:sch_class_section_jnt,id',
            'academic_session_id' => 'required|exists:sch_org_academic_sessions_jnt,id',
            'attendance' => 'required|array',
            'attendance.*' => 'nullable|in:Present,Absent,Late,Half Day,Short Leave,Leave',
        ]);

        $userId = Auth::id();

        $rows = [];
        $clearStudentIds = [];

        foreach ($validated['attendance'] as $studentId => $status) {
            if ($status === null || $status === '' || $status === 'null') {
                $clearStudentIds[] = (int) $studentId;
                continue;
            }

            $rows[] = [
                'student_id' => (int) $studentId,
                'academic_session_id' => $validated['academic_session_id'],
                'class_section_id' => $validated['class_section_id'],
                'attendance_date' => $validated['attendance_date'],
                'attendance_period' => 0,
                'status' => $status,
                'marked_by' => $userId,
                'marked_at' => now(),
            ];
        }

        DB::transaction(function () use ($rows, $clearStudentIds, $validated) {
            if ($rows !== []) {
                StudentAttendance::upsert(
                    $rows,
                    ['student_id', 'attendance_date', 'attendance_period'],
                    ['academic_session_id', 'class_section_id', 'status', 'marked_by', 'marked_at']
                );
            }

            if ($clearStudentIds !== []) {
                StudentAttendance::where('attendance_date', $validated['attendance_date'])
                    ->where('academic_session_id', $validated['academic_session_id'])
                    ->where('class_section_id', $validated['class_section_id'])
                    ->whereIn('student_id', $clearStudentIds)
                    ->delete();
            }
        });

        return redirect()->back()->with('success', 'Attendance saved successfully.');
    ```
  - **Verify:** `grep -n "beginTransaction\|DB::commit\|rollBack\|getMessage" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php`
  - **Expect:** no output after line 405.
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **ATD-04** · M · AUTH-06 · `Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php:63` — remove the dead `AttendancePolicy` registration (the controller gates use string permissions, so the policy is never consulted).
  - **Touches:** `Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php` ⚠ SHARED (this provider registers the whole module's policies)
  - **Before** (`StudentProfileServiceProvider.php:62-64`):
    ```php
        Gate::policy(Student::class, StudentPolicy::class);
        Gate::policy(StudentAttendance::class, AttendancePolicy::class);
        Gate::policy(Guardian::class, GuardianPolicy::class);
    ```
  - **After:**
    ```php
        Gate::policy(Student::class, StudentPolicy::class);
        // AttendanceController authorizes with Gate::authorize('tenant.student-profile.attendance.*')
        // string gates, which never consult a policy. AttendancePolicy is dead — keep the
        // permission strings as the single source (final-audit ATD-04, 2026-10-10).
        Gate::policy(Guardian::class, GuardianPolicy::class);
    ```
  - **Verify:** `grep -n "AttendancePolicy" Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php`
  - **Expect:** the line contains only the explanatory comment, not a `Gate::policy(StudentAttendance::class, AttendancePolicy::class);` call.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **ATD-08** · M · RTE-03 · `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:251-273` — `getAttendanceReport` is not routed; per D5 replace the body with `abort(403)` + a `NOT ROUTED` comment.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php`
  - **Before** (`AttendanceController.php:251-273`):
    ```php
    public function getAttendanceReport(Request $request)
    {
        Gate::authorize('tenant.student-profile.attendance.viewAny');
        $request->validate([
            'class_section_id' => 'required|integer',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
            'academic_session_id' => 'required|integer'
        ]);

        $attendance = StudentAttendance::with(['student'])
            ->where('class_section_id', $request->class_section_id)
            ->where('academic_session_id', $request->academic_session_id)
            ->whereBetween('attendance_date', [$request->start_date, $request->end_date])
            ->orderBy('attendance_date')
            ->orderBy('attendance_period')
            ->get();

        return response()->json([
            'status' => true,
            'attendance' => $attendance
        ]);
    }
    ```
  - **After:**
    ```php
    public function getAttendanceReport(Request $request)
    {
        // NOT ROUTED (final-audit ATD-08, 2026-10-10). No route points at this method;
        // per D5 it stays as a 403 so nothing silently calls a report that returns whole
        // student models as JSON.
        abort(403, 'Not routed.');
    }
    ```
  - **Verify:** `grep -n "getAttendanceReport\|abort(403" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php`
  - **Expect:** the method body is only the `abort` line; no `StudentAttendance::with(['student'])` JSON path remains.
  - **Effort:** S

## 6. Queries & performance (F9)

## 7. Views (F10)

- [ ] **ATD-18** · M · VIEW-02 · `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:311-313` — eager-load `user` so the roster blade's `$student->user->email` does not run one query per student.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php`
  - **Before** (`AttendanceController.php:311-313`):
    ```php
                ->with(['currentAcademicSession' => function ($query) {
                    $query->select('student_id', 'roll_no', 'class_section_id');
                }])
    ```
  - **After:**
    ```php
                ->with([
                    'currentAcademicSession' => function ($query) {
                        $query->select('student_id', 'roll_no', 'class_section_id');
                    },
                    'user:id,email',
                ])
    ```
  - **Verify:** `grep -n "'user:id,email'" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php`
  - **Expect:** the `with([...])` array contains `'user:id,email'`.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **ATD-11** · L · CTL-04/STY-01 · `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php` — add `declare(strict_types=1);` and return types on the routed public methods (`create(): View`, `scanAttendance(): JsonResponse`, `manualAttendance(): JsonResponse`, `bulkAttendanceIndex(): View`, `storeBulkAttendance(): RedirectResponse`).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php`
  - **Before** (`AttendanceController.php:1-3`):
    ```php
    <?php

    namespace Modules\StudentProfile\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Http\Controllers;

    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\View\View;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php`
  - **Expect:** one `declare(strict_types=1);` after `<?php`; the three new `use` lines present.
  - **Effort:** M

- [ ] **ATD-13** · L · MDL-04/STY-01 · `Modules/StudentProfile/app/Models/StudentAttendance.php` — add `declare(strict_types=1);` and return types to the four relations (`student(): BelongsTo`, `academicSession(): BelongsTo`, `classSection(): BelongsTo`, `markedBy(): BelongsTo`).
  - **Touches:** `Modules/StudentProfile/app/Models/StudentAttendance.php`
  - **Before** (`StudentAttendance.php:1-10`):
    ```php
    <?php

    namespace Modules\StudentProfile\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Modules\StudentProfile\Models\Student;
    use Modules\SchoolSetup\Models\User;
    use Modules\SchoolSetup\Models\ClassSection;
    use Modules\SchoolSetup\Models\OrganizationAcademicSession;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Modules\StudentProfile\Models\Student;
    use Modules\SchoolSetup\Models\User;
    use Modules\SchoolSetup\Models\ClassSection;
    use Modules\SchoolSetup\Models\OrganizationAcademicSession;
    ```
  - **Before** (`StudentAttendance.php:34-52` — the four relation methods):
    ```php
        public function student()
        {
            return $this->belongsTo(Student::class, 'student_id');
        }
        
        public function academicSession()
        {
            return $this->belongsTo(OrganizationAcademicSession::class, 'academic_session_id');
        }
        
        public function classSection()
        {
            return $this->belongsTo(ClassSection::class, 'class_section_id');
        }
        
        public function markedBy()
        {
            return $this->belongsTo(User::class, 'marked_by');
        }
    ```
  - **After:**
    ```php
        public function student(): BelongsTo
        {
            return $this->belongsTo(Student::class, 'student_id');
        }
        
        public function academicSession(): BelongsTo
        {
            return $this->belongsTo(OrganizationAcademicSession::class, 'academic_session_id');
        }
        
        public function classSection(): BelongsTo
        {
            return $this->belongsTo(ClassSection::class, 'class_section_id');
        }
        
        public function markedBy(): BelongsTo
        {
            return $this->belongsTo(User::class, 'marked_by');
        }
    ```
  - **Verify:** `grep -n "public function student\|public function markedBy" Modules/StudentProfile/app/Models/StudentAttendance.php`
  - **Expect:** both lines end with `: BelongsTo`.
  - **Effort:** S

- [ ] **ATD-19** · L · STY-01 · `Modules/StudentProfile/app/Policies/AttendancePolicy.php` — add `declare(strict_types=1);`.
  - **Touches:** `Modules/StudentProfile/app/Policies/AttendancePolicy.php`
  - **Before** (`AttendancePolicy.php:1-5`):
    ```php
    <?php

    namespace Modules\StudentProfile\Policies;

    use Illuminate\Auth\Access\HandlesAuthorization;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Policies;

    use Illuminate\Auth\Access\HandlesAuthorization;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/StudentProfile/app/Policies/AttendancePolicy.php`
  - **Expect:** one `declare(strict_types=1);` after `<?php`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **ATD-05** · M · DECISION · VAL-02 — move scan/manual/bulk validation from inline `$request->validate()` into FormRequests?
  - **Why it is a decision:** creates two new files under `Modules/StudentProfile/app/Http/Requests/` and rewires the four call sites; the write-path rewrites above (ATD-01/ATD-02) must land first or the FormRequest `authorize()` would double-gate with the controller's `Gate::authorize` (AUTH-04).
  - (a) ⭐ defer to the post-rewrite pass — a dedicated `AttendanceScanRequest`, `AttendanceManualRequest`, `BulkAttendanceRequest` after ATD-01/ATD-02 are ticked; keeps this plan small
  - (b) do it now: add the three FormRequest classes and swap `$request->validate` for method injection in the same pass
  - (c) leave inline validation as accepted (each rule set is already inline and validated)
  - ➜ Choice: ____

- [ ] **ATD-09** · M · DECISION · CTL-02 — extract the 125-line `bulkAttendanceIndex` and the 84-line `scanAttendance`?
  - **Why it is a decision:** in-place extraction (D3) is allowed but touches a method the fixes above also rewrite; the medical-tab block belongs to the MedicalIncident screen and could be split later
  - (a) ⭐ defer to the split pass (D3) — record the extraction now, apply with the module's god-controller pass
  - (b) extract the medical-incident block into a private method now
  - (c) leave as is, record as accepted
  - ➜ Choice: ____

- [ ] **ATD-10** · M · DECISION · CTL-05 — dedupe the near-identical `scanAttendance` and `manualAttendance` bodies?
  - **Why it is a decision:** unify into one private `markAttendance(...)` helper; ATD-01 rewrites both methods in this pass, and a dedup on top is a behaviour-neutral refactor best done after that lands
  - (a) ⭐ defer to the split pass (D3) — apply after ATD-01 is ticked and verified
  - (b) extract the shared helper now, in the same pass as ATD-01
  - (c) leave both copies as accepted
  - ➜ Choice: ____

- [ ] **ATD-12** · M · DECISION · MDL — add `SoftDeletes` to `StudentAttendance`?
  - **Why it is a decision:** needs a NEW additive migration: the current unique index `uq_std_att_student_date` is on `(student_id, attendance_date, attendance_period)` and does NOT include `deleted_at`, so soft-deleting a row would still block re-marking the same slot (unique-index trap, VAL-04). Touches the table the bulk clear path deletes from.
  - (a) ⭐ no migration now: keep the hard delete, add a comment in the model documenting the divergence — attendance history is already hard-deleted today
  - (b) add `SoftDeletes` and a new additive migration that drops/re-creates the unique index with `deleted_at` (Tarun runs `php artisan tenants:migrate`)
  - (c) add `SoftDeletes` and drop the unique index entirely
  - ➜ Choice: ____

- [ ] **ATD-14** · M · DECISION · SVC-01 — pass `marked_by` into `AttendanceService::markAbsentFromPeriod()` instead of `auth()->id()` inside the service?
  - **Why it is a decision:** the service's two callers live in `Modules/FrontOffice` (`EarlyDepartureService`, `EarlyDepartureAttSyncJob`) — a signature change touches those files, and in the queue worker `auth()->id()` is currently null so rows are unattributed
  - (a) ⭐ add an optional `?int $markedBy = null` parameter, and update the two FrontOffice callers to pass the user id (or leave null in the job); keeps the service pure
  - (b) leave `auth()->id()` but document that the queue writer stores null marked_by
  - (c) move the whole operation into FrontOffice and stop sharing the service
  - ➜ Choice: ____

- [ ] **ATD-16** · M · DECISION · QRY-15 — cap the full-table loads (`create()` loads 9,759 academic-session rows; `bulkAttendanceIndex` loads all 1,825 students for `$incidentStudents`)?
  - **Why it is a decision:** the QR/manual dropdown and the medical-incident picker are UI screens; adding pagination or server-side search changes what a user can pick from
  - (a) ⭐ defer to the UI pass — add a search-as-you-type picker for `create()` and keep `$incidentStudents`, selecting only `id, first_name, middle_name, last_name`
  - (b) keep today's behavior and add `->select([...])` + `->limit(500)` as a stop-gap now
  - (c) leave as is, record as accepted
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| ATD-03 | activityLog is added by the After blocks of ATD-01 (scan/manual) and ATD-02 (bulk), inside the transaction after the write — TXN-04 satisfied there |
| ATD-06 | `attendance.*` value validation is added in ATD-02's After validation array |
| ATD-07 | `marked_by` comes from `Auth::id()` in ATD-01's After blocks for both scan and manual; the blade may keep sending it but the server ignores it |
| ATD-15 | the bulk per-row loop becomes one `upsert` + one `whereIn` delete inside ATD-02's After — QRY-01/QRY-07 closed there |
| ATD-17 | leading-wildcard LIKE on `std_medical_incidents` (674 live rows) is accepted as L; revisit with a search column when the table grows |