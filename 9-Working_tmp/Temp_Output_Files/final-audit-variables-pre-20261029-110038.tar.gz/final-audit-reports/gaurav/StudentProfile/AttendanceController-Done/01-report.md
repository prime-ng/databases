# Final Audit — StudentProfile / AttendanceController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php` (454 lines, 6 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/student-profile/attendance/create` — QR-scan screen. `http://test.localhost:8000/student-profile/bulk-attendance` — bulk-marking + medical-incident screen (one page, two tabs). Both pages POST to sibling URLs on the same prefix (`attendance/scan`, `attendance/manual`, `bulk-attendance/store`). |
| Menu path | Student Mgmt → Student Attendance (glb_menus id 70, menu_for tenant, route `student-profile.attendance.bulk`) |
| Who uses it | Roles that hold `tenant.student-profile.attendance.create` (id 843) and `.viewAny` (id 845): **Super Admin, School Admin** (measured in the tenant DB). |
| What a user does here | A clerk or teacher marks student attendance three ways: (1) scan a printed QR code → one attendance row per period; (2) manual entry of one student per period; (3) bulk marking — select a class section and a date, set Present/Absent/Late/etc. per student, save all at once. The same page includes a Medical Incident tab (search + list) whose data lives on this controller because the tab posts back to the bulk route. |
| Tables written | `std_student_attendance` (insert/update via updateOrCreate; hard delete when a status is cleared). No `sys_activity_logs` rows anywhere — the writes are not audited. |
| Tables read | `std_student_attendance`, `std_students`, `std_student_academic_sessions`, `std_medical_incidents`, `sch_class_section_jnt`, `sch_classes`, `sch_sections`, `sch_org_academic_sessions_jnt`, `sys_users`, `sys_dropdown_table` |
| Live data | `std_student_attendance` 99,334 live / 0 trashed; `std_students` 1,825; `std_student_academic_sessions` 9,759; `std_medical_incidents` 674; `sch_classes` 15; `sch_sections` 8; `sch_class_section_jnt` 43; `sys_users` 5,633 (all on tenant `xyz_school_00000000000040008000_202627`) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. Any write-path failure (QR scan, manual mark, bulk save) returns the raw SQL/exception text to the browser or the redirect — a Blocker (ATD-01). None of the three write methods records an activityLog, bulk save uses a manual transaction with a hand-rolled loop of per-student queries, and the model hard-deletes attendance rows instead of soft-deleting. `AttendanceController@getAttendanceReport` is unreachable dead code that also dumps full student models as JSON if ever routed. Rough effort: 2–4 hours for the ticked items; a further decision is needed on the soft-delete/unique-index trap (ATD-12).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 1 | 13 | 4 | 6 | 19 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | ATD-01 | F8 Services/Jobs | ATD-14 |
| F2 Transactions/Audit | ATD-02, ATD-03 | F9 Queries/Perf | ATD-15, ATD-16, ATD-17 |
| F3 Authorization | ATD-04 | F10 Views | ATD-18 |
| F4 Validation | ATD-05, ATD-06, ATD-07 | F11 Security/Tenancy | clean |
| F5 Routes | ATD-08 | F12 Style | ATD-11, ATD-13, ATD-19 |
| F6 Controller shape | ATD-09, ATD-10 | F13 Deep read | table in §6 |
| F7 Models | ATD-12, ATD-13 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php` | controller | 454 | this report | ✅ |
| 2 | `Modules/StudentProfile/app/Models/StudentAttendance.php` | model | 63 | this report (pre-assigned) | ✅ |
| 3 | `Modules/StudentProfile/app/Services/AttendanceService.php` | service | 42 | this report (pre-assigned) | ✅ |
| 4 | `Modules/StudentProfile/app/Policies/AttendancePolicy.php` | policy | 45 | this report (pre-assigned) | ✅ |
| 5 | `Modules/StudentProfile/resources/views/student-attendance/create.blade.php` | view | 919 | this report (used only by `create`) | ✅ (renders; JS reviewed) |
| 6 | `Modules/StudentProfile/resources/views/student-settings/index.blade.php` | view | 532 | this report (rendered via `studentprofile::index`) | ✅ |
| 7 | `Modules/StudentProfile/resources/views/index.blade.php` | view | 24 | this report (rendered by `bulkAttendanceIndex`) | ✅ |
| 8 | `Modules/StudentProfile/resources/views/medical-incident/index.blade.php` | view | 200 | this report (included from `studentprofile::index`) | ✅ |
| 9 | `Modules/StudentProfile/app/Models/Student.php` | model | — | ↗ [gaurav/StudentProfile/StudentReportController](../StudentReportController-done/01-report.md) | ↗ linked |
| 10 | `Modules/StudentProfile/app/Models/StudentAcademicSession.php` | model | — | ↗ [gaurav/StudentProfile/StudentController](../StudentController-done/01-report.md) | ↗ linked |
| 11 | `Modules/StudentProfile/app/Models/MedicalIncident.php` | model | — | ↗ [gaurav/StudentProfile/MedicalIncidentController](../MedicalIncidentController-done/01-report.md) | ↗ linked |
| 12 | `Modules/SchoolSetup/app/Models/ClassSection.php` | model | — | other module (common, §4.2) | referenced |
| 13 | `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php` | model | — | other module (common, §4.2) | referenced |
| 14 | `Modules/SchoolSetup/app/Models/SchoolClass.php` | model | — | other module (common, §4.2) | referenced |
| 15 | `Modules/SchoolSetup/app/Models/Section.php` | model | — | other module (common, §4.2) | referenced |
| 16 | `Modules/SchoolSetup/app/Models/User.php` | model | — | other module (common, §4.2) | referenced (`emp_code` lookup only) |
| 17 | `Modules/SystemConfig/app/Models/Dropdown.php` | model | — | other module (common, §4.2) | referenced |

No pre-applied files for StudentProfile.

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json 2>/dev/null | php -r '$r=json_decode(stream_get_contents(STDIN),true);
  foreach($r as $x) if(str_contains($x["action"],"AttendanceController@"))
    printf("%-7s %-55s %-50s %s\n",$x["method"],$x["uri"],$x["name"]??"-",$x["action"]);'

GET|HEAD student-profile/attendance/create                    student-profile.attendance.create       Modules\StudentProfile\Http\Controllers\AttendanceController@create
POST    student-profile/attendance/manual                     student-profile.attendance.manual        Modules\StudentProfile\Http\Controllers\AttendanceController@manualAttendance
POST    student-profile/attendance/scan                       student-profile.attendance.scan          Modules\StudentProfile\Http\Controllers\AttendanceController@scanAttendance
GET|HEAD student-profile/bulk-attendance                      student-profile.attendance.bulk          Modules\StudentProfile\Http\Controllers\AttendanceController@bulkAttendanceIndex
POST    student-profile/bulk-attendance/store                 student-profile.attendance.bulk.store    Modules\StudentProfile\Http\Controllers\AttendanceController@storeBulkAttendance
```

Unrouted public methods: `getAttendanceReport` at `AttendanceController.php:251` — no route points at it (per D5 it must become `abort(403)`).

Routes live under `Route::middleware('module:STUDENT')` inside the module `mapWebRoutes()` set: `web + InitializeTenancyByDomain + PreventAccessFromCentralDomains + EnsureTenantIsActive + auth + verified` — tenant middleware present (RTE-05 clean).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `create` | 22 | GET student-profile/attendance/create | `tenant.student-profile.attendance.create` | none (read-only) | none (read-only) | — | ATD-16, ATD-11 |
| `scanAttendance` | 88 | POST student-profile/attendance/scan | `tenant.student-profile.attendance.create` | none — single updateOrCreate, no closure | none — no activityLog | std_student_attendance | ATD-01, ATD-03, ATD-05, ATD-07, ATD-09, ATD-10, ATD-11 |
| `manualAttendance` | 176 | POST student-profile/attendance/manual | `tenant.student-profile.attendance.create` | none — single updateOrCreate, no closure | none — no activityLog | std_student_attendance | ATD-01, ATD-03, ATD-05, ATD-07, ATD-10, ATD-11 |
| `getAttendanceReport` | 251 | NOT ROUTED | `tenant.student-profile.attendance.viewAny` | none (read-only) | none (read-only) | — | ATD-08, ATD-05, ATD-11 |
| `bulkAttendanceIndex` | 275 | GET student-profile/bulk-attendance | `tenant.student-profile.attendance.viewAny` | none (read-only) | none (read-only) | — | ATD-09, ATD-16, ATD-17, ATD-18, ATD-11 |
| `storeBulkAttendance` | 401 | POST student-profile/bulk-attendance/store | `tenant.student-profile.attendance.create` | controller, manual begin/commit/rollBack | none — no activityLog | std_student_attendance | ATD-01, ATD-02, ATD-03, ATD-05, ATD-06, ATD-15, ATD-11 |

Service `AttendanceService::markAbsentFromPeriod` (called from FrontOffice, **not** from this controller) — ATD-14.

## 6. Findings

### F1 — Errors

#### ATD-01 · B · ERR-01 — every write failure leaks the raw exception text to the user

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *Never send exception text to the user. No `$e->getMessage()` in `withErrors`, `with('error')`, `response()->json`, or `back()`.* D1 — *no try/catch in a controller; the central handler renders errors* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:165-170` (`scanAttendance`), `:240-245` (`manualAttendance`), `:449-452` (`storeBulkAttendance`) |
| **Root cause** | Three write methods wrap their mutation in `try { ... } catch (\Exception $e)` and interpolate `$e->getMessage()` into the JSON or flash message. A DB failure (deadlock, MySQL enum rejection, FK violation) sends server internals — table/column names, SQL state — to the browser. D1 has been settled: controllers carry no try/catch; the exception propagates to `bootstrap/app.php`'s renderer. |
| **Consequence** | A clerk who makes a mistake (e.g. an invalid status in bulk save) sees "Failed to save attendance: SQLSTATE[23000]…std_student_attendance…" — an internal-error detail page / message instead of a safe notice. |
| **Reproduce** | POST `student-profile/attendance/scan` with `qr_code=anything`, `status=Bogus`, `date=2026-10-10`, `period=1`, `marked_by=1` — the MySQL enum rejects `Bogus`, the catch returns it in the JSON message. |
| **Fix approach** | Delete the `try/catch` (D1) and return fixed messages; let the central exception handler render failures. |
| **Plan item** | ATD-01 in `02-fix-plan.md` §1 (scan+manual rewrite; the bulk instance is fixed by ATD-02's closure rewrite) |

```php
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Failed to save attendance: ' . $e->getMessage()
            ]);
        }
```

**Evidence**
```
$ grep -n "getMessage" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
168:                'message' => 'Failed to save attendance: ' . $e->getMessage()
243:                'message' => 'Failed to save attendance: ' . $e->getMessage()
451:            return redirect()->back()->with('error', 'Failed to save attendance: ' . $e->getMessage());
```

### F2 — Transactions and audit

#### ATD-02 · M · TXN-02 — bulk save uses a manual transaction instead of the `DB::transaction` closure

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *Use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`.* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:418-452`, method `storeBulkAttendance()` |
| **Root cause** | The method calls `DB::beginTransaction()`, loops, `DB::commit()` / `DB::rollBack()` in the catch. The manual form leaks an open transaction on early `return` (none here today, but the pattern is the hazard) and contradicts the codebase rule. |
| **Consequence** | None user-visible today; the write is correctly atomic. This is the debt that makes the next refactor (ATD-15 bulk writes) harder. |
| **Reproduce** | Static only — the pattern is visible at lines 419, 447, 450. |
| **Fix approach** | Wrap the loop in `DB::transaction(function () use (...) { ... });` and drop manual begin/commit/rollBack. |
| **Plan item** | ATD-02 in `02-fix-plan.md` §3 (the closure rewrite also carries the bulk ERR-01/QRY fixes) |

```php
        try {
            DB::beginTransaction();

            foreach ($data as $studentId => $status) {
```

**Evidence**
```
$ grep -n "beginTransaction\|commit\|rollBack" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
419:            DB::beginTransaction();
447:            DB::commit();
450:            DB::rollBack();
```

#### ATD-03 · M · TXN-04 — no attendance write records an activityLog; scan/manual writes sit outside any transaction

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, **after** the write it describes.* F2 per-function rule — each mutating method must have a transaction and an `activityLog()`. |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:130-144` (`scanAttendance`), `:205-219` (`manualAttendance`), `:421-445` (`storeBulkAttendance`) |
| **Root cause** | The controller has zero `activityLog()` calls. Every other write controller in the module (MedicalIncidentController, StdLeaveController, StudentLeaveTypeController) logs its mutations; attendance — a 99,334-row audit-sensitive table — writes silently. scanAttendance/manualAttendance do a single `updateOrCreate` with no transaction at all, so adding the log later will require wrapping them. |
| **Consequence** | Nobody can answer "who changed this attendance mark and when" — the one question this screen is most likely to be asked. |
| **Reproduce** | Static only — `grep -c activityLog(` over the controller returns 0 (below). |
| **Fix approach** | Wrap each write and append `activityLog($attendance, 'Attendance Marked', [...])` after the write inside the transaction; keep scan/manual as one-model writes inside `DB::transaction`, and add the log inside storeBulkAttendance's transaction. |
| **Plan item** | none — fixed inside ATD-01 and ATD-02 (both After blocks add transaction + activityLog), see plan §10 |

```php
        try {
            $attendance = StudentAttendance::updateOrCreate(
                [
                    'student_id' => $student->id,
                    'attendance_date' => $request->date,
                    'attendance_period' => $request->period
                ],
```

**Evidence**
```
$ grep -c "activityLog(" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php Modules/StudentProfile/app/Services/AttendanceService.php
Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:0
Modules/StudentProfile/app/Services/AttendanceService.php:0
```

### F3 — Authorization

#### ATD-04 · M · AUTH-06 — AttendancePolicy is registered but nothing consults it

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *Permission strings live in one place — a Policy or constants — not repeated as literals in every method.* F3 — *report every Policy that nothing consults.* |
| **Where** | `Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php:63`, alongside `Modules/StudentProfile/app/Policies/AttendancePolicy.php` (whole file) |
| **Root cause** | `Gate::policy(StudentAttendance::class, AttendancePolicy::class)` registers the policy, but the controller authorizes with `Gate::authorize('tenant.student-profile.attendance.create')` — a raw string gate that never reaches a policy. The policy's seven methods re-declare the same strings and are dead. |
| **Consequence** | None user-visible — the permission check itself is correct and seeded. The dead policy is maintenance noise: a future developer "fixing" the policy will believe they have changed authorization when they have not. |
| **Reproduce** | Open `AttendancePolicy.php`, then `grep -rn "Gate::authorize" AttendanceController.php` — every call passes a string, none passes a model. |
| **Fix approach** | Leave the gate strings in the controller (they are the single source), and either delete the dead policy + registration or add a comment explaining it is superseded. Removing a registration is a behaviour-neutral cleanup. |
| **Plan item** | ATD-04 in `02-fix-plan.md` §4 |

```php
        Gate::policy(StudentAttendance::class, AttendancePolicy::class);
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
24:        Gate::authorize('tenant.student-profile.attendance.create');
90:        Gate::authorize('tenant.student-profile.attendance.create');
178:        Gate::authorize('tenant.student-profile.attendance.create');
253:        Gate::authorize('tenant.student-profile.attendance.viewAny');
277:        Gate::authorize('tenant.student-profile.attendance.viewAny');
403:        Gate::authorize('tenant.student-profile.attendance.create');
```

### F4 — Validation and input

#### ATD-05 · M · VAL-02 — four methods validate inline instead of a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *Validation lives in a FormRequest, not inline `$request->validate()` — except one-field AJAX toggles.* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:91` (`scanAttendance`), `:179` (`manualAttendance`), `:254` (`getAttendanceReport`), `:405` (`storeBulkAttendance`) |
| **Root cause** | No FormRequest class exists for any attendance endpoint (`Modules/StudentProfile/app/Http/Requests/` holds only `PrintIdCardsRequest` and `StudentLeaveTypeRequest`). Validation blocks are duplicated in the controller. |
| **Consequence** | Rule sets drift between endpoints (see ATD-07: `marked_by` accepted as a bare integer that should be `Auth::id()`); there is no single place to harden the input contract. |
| **Reproduce** | Static only — the four `$request->validate([` lines above. |
| **Fix approach** | Extract the scan/manual rule set and the bulk rule set into FormRequests (future work; two classes), or at minimum move `marked_by` handling out (ATD-07). |
| **Plan item** | ATD-05 · DECISION in `02-fix-plan.md` §9 (new files, so a decision) |

```php
        $request->validate([
            'qr_code' => 'required|string',
            'status' => 'required|in:Present,Absent,Late,Half Day,Short Leave,Leave',
            'date' => 'required|date',
            'period' => 'required|integer|min:1|max:8',
            'marked_by' => 'required|integer'
        ]);
```

**Evidence**
```
$ grep -n "\$request->validate" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
91:        $request->validate([
179:        $request->validate([
254:        $request->validate([
405:        $validated = $request->validate([
```

#### ATD-06 · M · VAL-05 — bulk attendance values are not typed (any string becomes a status)

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *Every field is typed… Write paths with no validation at all are H.* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:407-410` (validation) and `:422-427` (the value used verbatim) |
| **Root cause** | `storeBulkAttendance` validates `attendance` only as `required|array`. The inner values (`$status`) flow straight into `updateOrCreate([...], ['status' => $status])`. Scan/manual validate `status` with `in:Present,Absent,...`; the bulk path does not, relying on the MySQL enum to throw. |
| **Consequence** | A malformed POST (or a missed radio that submits `"null"` as a string) produces a raw DB error instead of a clean validation failure — and feeds ATD-01's message leak. |
| **Reproduce** | POST `student-profile/bulk-attendance/store` with `attendance[5]=Bogus` → MySQL enum rejection → captured by the catch. |
| **Fix approach** | Add `attendance.*` → `nullable|in:Present,Absent,Late,Half Day,Short Leave,Leave` to the validation and stop treating the literal string `'null'` as a sentinel. |
| **Plan item** | none — fixed inside ATD-02 (the rewrite adds `attendance.*` validation), see plan §10 |

```php
        $validated = $request->validate([
            'attendance_date' => 'required|date',
            'class_section_id' => 'required|exists:sch_class_section_jnt,id',
            'academic_session_id' => 'required|exists:sch_org_academic_sessions_jnt,id',
            'attendance' => 'required|array',
        ]);
```

**Evidence**
```
$ sed -n '422,427p' Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
                    StudentAttendance::updateOrCreate(
                        [
                            'student_id' => $studentId,
                            'academic_session_id' => $academicSessionId,
                            'class_section_id' => $classSectionId,
                            'attendance_date' => $date
```

#### ATD-07 · M · VAL-05 — `marked_by` comes from the client, not `Auth::id()`

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *Every field is typed… a write path whose meaning is not enforced.* (attribution integrity) |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:96` and `:185` (accepted from the request), `:141` and `:216` (written to the model) |
| **Root cause** | scanAttendance and manualAttendance validate `marked_by` as `required|integer` and write `$request->marked_by` into the row. The blade sends `auth()->id()` (see `create.blade.php:616,717`), but any client can send any integer — so attendance can be attributed to "someone else". `storeBulkAttendance` correctly uses `Auth::id()` (:412), which makes the scan/manual path an inconsistency. |
| **Consequence** | A malicious or curious staff member can misattribute marks to another user id, corrupting the audit trail the school would rely on. |
| **Reproduce** | POST `student-profile/attendance/manual` with `marked_by=1` while logged in as a different user — the row records user 1. |
| **Fix approach** | Derive `marked_by` from `Auth::id()` server-side in scan/manual (the blade's client-sent value becomes redundant); the routes already sit behind `auth`. |
| **Plan item** | none — fixed inside ATD-01 (both rewrite blocks use `Auth::id()`), see plan §10 |

```php
            'period' => 'required|integer|min:1|max:8',
            'marked_by' => 'required|integer'
        ]);
```

**Evidence**
```
$ grep -n "marked_by: {{ auth()->id() }}" Modules/StudentProfile/resources/views/student-attendance/create.blade.php
616:                        marked_by: {{ auth()->id() }}
717:                        marked_by: {{ auth()->id() }}
$ grep -n "marked_by" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
96:            'marked_by' => 'required|integer'
141:                    'marked_by' => $request->marked_by,
185:            'marked_by' => 'required|integer'
216:                    'marked_by' => $request->marked_by,
412:        $userId = Auth::id();
```

### F5 — Routes

#### ATD-08 · M · RTE-03 — dead public method `getAttendanceReport` (D5 → abort)

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *Every public controller method is routed, or is deliberately disabled (`abort(403)`).* D5 — *unrouted method body becomes `abort(403)` + `NOT ROUTED` comment.* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:251-273`, method `getAttendanceReport()` |
| **Root cause** | The method was written "if needed later" (its own docblock) and no route was ever registered. It also returns `StudentAttendance::with(['student'])` as a full JSON collection — full student models (including personal fields) would leak if a route were ever added. |
| **Consequence** | Dead code today; a latent SEC-02 exposure the moment someone wires a route. |
| **Reproduce** | `grep -n "getAttendanceReport" Modules/StudentProfile/routes/web.php` → no output. |
| **Fix approach** | Per D5: replace the body with `abort(403, 'Not routed.'); // NOT ROUTED` and keep the method. |
| **Plan item** | ATD-08 in `02-fix-plan.md` §5 |

```php
    public function getAttendanceReport(Request $request)
    {
        Gate::authorize('tenant.student-profile.attendance.viewAny');
```

**Evidence**
```
$ grep -rn "getAttendanceReport" Modules/StudentProfile/routes/ Modules/StudentProfile/Resources 2>/dev/null
(no route, no record — only the controller defines it)
```

### F6 — Controller shape

#### ATD-09 · M · CTL-02 — two methods exceed 80 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *Method length: over 80 lines → extract.* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:88-171` (`scanAttendance`, 84 lines) and `:275-399` (`bulkAttendanceIndex`, 125 lines) |
| **Root cause** | scanAttendance builds a full JSON response inline; bulkAttendanceIndex loads three dropdowns plus the medical-incident list inside one method. |
| **Consequence** | The two methods are hard to read and test; a third of `bulkAttendanceIndex` is the medical-incident screen that does not belong to attendance. |
| **Reproduce** | Static only — measured by `awk`. |
| **Fix approach** | Extract the JSON-response builder from scanAttendance and the medical-incident block from bulkAttendanceIndex (D3: in-place, same routes). |
| **Plan item** | ATD-09 · DECISION in `02-fix-plan.md` §9 (extraction, deferred under D3) |

```php
    public function bulkAttendanceIndex(Request $request)
    {
        Gate::authorize('tenant.student-profile.attendance.viewAny');
```

**Evidence**
```
$ awk 'NR>=88 && NR<=171{c1++} NR>=275 && NR<=399{c2++} END{print "scanAttendance lines (88-171):",c1; print "bulkAttendanceIndex lines (275-399):",c2}' Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
scanAttendance lines (88-171): 84
bulkAttendanceIndex lines (275-399): 125
```

#### ATD-10 · M · CTL-05 — scanAttendance and manualAttendance are copy-paste twins

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *No copy-paste: the same 30-line payload in `store` and `update`…* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:129-170` vs `:204-245` |
| **Root cause** | The two methods differ only in how they find the student (`qr_code` vs `student_id`) and one flash string. The `updateOrCreate` call and the identical 6-field JSON `student`/`attendance` response array are duplicated verbatim (scanner: identical array literal at lines 156 and 231). |
| **Consequence** | Any future change (e.g. a new status) must be made twice; the two copies will drift. |
| **Reproduce** | Static only — `grep -n "'attendance' => \["` shows both copies. |
| **Fix approach** | Extract one private helper `recordAttendance(Request $request, ...)` used by both; same routes (D3). |
| **Plan item** | ATD-10 · DECISION in `02-fix-plan.md` §9 (dedup, deferred under D3) |

```php
        try {
            $attendance = StudentAttendance::updateOrCreate(
                [
                    'student_id' => $student->id,
                    'attendance_date' => $request->date,
                    'attendance_period' => $request->period
                ],
```

**Evidence**
```
$ grep -n "'attendance' => \[" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
156:                'attendance' => [
231:                'attendance' => [
```

#### ATD-11 · L · CTL-04 — public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *Return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`).* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:22,88,176,251,275,401` |
| **Root cause** | None of the six public methods declares a return type. |
| **Consequence** | Contract is implicit; a later `response()->json` mistake is not caught by the type system. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `: View` / `: JsonResponse` / `: RedirectResponse` per method while touching the file (STY grouping). |
| **Plan item** | ATD-11 in `02-fix-plan.md` §8 |

```php
    public function create()
    {
        Gate::authorize('tenant.student-profile.attendance.create');
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+' Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
22:    public function create()
88:    public function scanAttendance(Request $request)
176:    public function manualAttendance(Request $request)
251:    public function getAttendanceReport(Request $request)
275:    public function bulkAttendanceIndex(Request $request)
401:    public function storeBulkAttendance(Request $request)
```

### F7 — Models

#### ATD-12 · M · MDL — StudentAttendance hard-deletes rows whose table declares `deleted_at`

| Field | Value |
|---|---|
| **Rule** | MDL (F7 checklist) · M — *SoftDeletes present if and only if the table has `deleted_at`.* The model must mirror the migration. |
| **Where** | `Modules/StudentProfile/app/Models/StudentAttendance.php:23-32` (no `SoftDeletes` trait) vs `database/migrations/tenant/2026_06_15_151309_create_std_student_attendance_table.php:38` (`$table->softDeletes()`) |
| **Root cause** | The migration adds `softDeletes()` (a `deleted_at` column), but the model only extends `BaseModel` and never imports `Illuminate\Database\Eloquent\SoftDeletes`. `storeBulkAttendance`'s clear-branch `->delete()` (line 438) therefore **hard-deletes** attendance rows, permanently. |
| **Consequence** | Clearing a mistaken mark destroys the row forever — no restore, and combined with ATD-03 no audit of the clear either. Adding SoftDeletes naively would then trip the unique index `uq_std_att_student_date(student,date,period)` which does not include `deleted_at` (a re-mark after soft-delete would 500) — so the fix needs a decision, not a one-line trait. |
| **Reproduce** | Static only — grep for `SoftDeletes` in the model returns nothing; the migration shows the column. |
| **Fix approach** | Decisions: (a) leave hard delete and document the divergence; (b) add SoftDeletes and alter the unique index to include `deleted_at` (migration); (c) add SoftDeletes and drop the unique index. |
| **Plan item** | ATD-12 in `02-fix-plan.md` §9 (DECISION) |

```php
class StudentAttendance extends BaseModel
{
    protected $table = 'std_student_attendance';
    
    protected $fillable = [
```

**Evidence**
```
$ grep -n "SoftDeletes" Modules/StudentProfile/app/Models/StudentAttendance.php; echo "model grep exit=$?"
$ grep -n "softDeletes" database/migrations/tenant/2026_06_15_151309_create_std_student_attendance_table.php
38:            $table->softDeletes();
```

#### ATD-13 · L · MDL-04 — model relations lack return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *Relationship methods return-typed (`: BelongsTo`, `: HasMany`…).* |
| **Where** | `Modules/StudentProfile/app/Models/StudentAttendance.php:34-52` (`student`, `academicSession`, `classSection`, `markedBy`) |
| **Root cause** | All four relations declare a body but no return type. |
| **Consequence** | Typing only; no runtime effect. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `: BelongsTo` to each relation while touching the file for STY. |
| **Plan item** | ATD-13 in `02-fix-plan.md` §8 |

```php
    public function student()
    {
        return $this->belongsTo(Student::class, 'student_id');
    }
```

**Evidence**
```
$ grep -n "public function student\|public function academicSession\|public function classSection\|public function markedBy" Modules/StudentProfile/app/Models/StudentAttendance.php
34:    public function student()
39:    public function academicSession()
44:    public function classSection()
49:    public function markedBy()
```

### F8 — Services and jobs

#### ATD-14 · M · SVC-01 — AttendanceService reaches into `auth()` and writes with no transaction/log

| Field | Value |
|---|---|
| **Rule** | SVC-01 (M) — *Services don't touch HTTP: no `request()`, `session()`, `redirect()`, `response()`, `back()`.* (auth is session state) plus F8 — services carry the same tx/activity rules. |
| **Where** | `Modules/StudentProfile/app/Services/AttendanceService.php:38` — `'marked_by' => auth()->id()` |
| **Root cause** | The service reads the authenticated user out of the session. When the only consumer in a queue worker (`Modules/FrontOffice/app/Jobs/EarlyDepartureAttSyncJob.php`) runs it, `auth()` has no session → `auth()->id()` is `null`, and the attendance row records `marked_by = null`. The `updateOrCreate` also runs with no transaction and no activityLog. |
| **Consequence** | "Short Leave" attendance written by the sync job is unattributed; the audit gap from ATD-03 extends into the queue path. |
| **Reproduce** | Dispatch `EarlyDepartureAttSyncJob` for a student — the `std_student_attendance.marked_by` is `null`. (⚠ UNVERIFIED in browser — would need a seeded job run; the static call path is `EarlyDepartureService.php:72`.) |
| **Fix approach** | Pass `marked_by` (or the acting user id) into `markAbsentFromPeriod()` from the callers; route the write through a transaction + activityLog. |
| **Plan item** | ATD-14 · DECISION in `02-fix-plan.md` §9 (touches FrontOffice callers — shared) |

```php
                'class_section_id' => (int) $session->class_section_id,
                'status'           => 'Short Leave',
                'remarks'          => 'Early departure at ' . $fromTime->format('h:i A'),
                'marked_by'        => auth()->id(),
```

**Evidence**
```
$ grep -n "auth()" Modules/StudentProfile/app/Services/AttendanceService.php
38:                'marked_by'        => auth()->id(),
```

### F9 — Queries and performance

#### ATD-15 · H · QRY-01/QRY-07 — bulk save loops per-student writes and deletes

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *No queries inside loops; bulk-write.* QRY-07 (M) — *`upsert()`/`whereIn()->update()` instead of `create()`/`update()` per row.* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:421-445`, method `storeBulkAttendance()` |
| **Root cause** | The `foreach ($data as $studentId => $status)` loop calls `updateOrCreate` (a SELECT + INSERT/UPDATE) and, in the clear branch, a `where(...)->delete()` per student. A class of 60 students = 60+ round trips per save. |
| **Consequence** | Slow saves on real classes, and under concurrency two bulk saves can hit the unique index race; the per-row pattern also masks the missing bulk-write semantics. |
| **Reproduce** | Open `/student-profile/bulk-attendance?class_section_id=…`, change every student, save — watch the request log for one query per student. |
| **Fix approach** | One `upsert` for present statuses and one `whereIn('student_id', ...)->delete()` for cleared ones, inside the `DB::transaction` closure (ATD-02). |
| **Plan item** | none — fixed inside ATD-02 (closure uses upsert + whereIn delete), see plan §10 |

```php
            foreach ($data as $studentId => $status) {
                if ($status && $status !== 'null') {
                    StudentAttendance::updateOrCreate(
                        [
                            'student_id' => $studentId,
                            'academic_session_id' => $academicSessionId,
                            'class_section_id' => $classSectionId,
                            'attendance_date' => $date
```

**Evidence**
```
$ grep -n "updateOrCreate\|->delete()" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
423:                    StudentAttendance::updateOrCreate(
438:                    StudentAttendance::where([
443:                    ])->delete();
```

#### ATD-16 · M · QRY-15 — dropdowns load every row of large tables

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *Don't load every row of a big table for a form.* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:29-40` (`create`) and `:376` (`bulkAttendanceIndex` → `$incidentStudents`) |
| **Root cause** | `create()` runs `StudentAcademicSession::with([...])->where('is_current',1)->...->get()` — 9,759 rows with guardians — to populate a manual-entry dropdown. `bulkAttendanceIndex` runs `Student::orderBy('first_name')->get()` (1,825 rows) for the medical-incident student picker. |
| **Consequence** | The QR/manual screen and the medical tab ship tens of megabytes of student payload; on slower connections the create page is sluggish. |
| **Reproduce** | Open `student-profile/attendance/create` — the page loads 9,759 academic-session rows with students and guardians. |
| **Fix approach** | Search-as-you-type (server-side `term` lookup) or restrict to the selected class section; minimum change: `pluck` only the columns the blade renders (`id`, names, `roll_no`). |
| **Plan item** | ATD-16 · DECISION in `02-fix-plan.md` §9 (limiting a dropdown is a behavior change) |

```php
        $studentSessions = StudentAcademicSession::with([
                'student.guardians',
                'classSection.class',
                'classSection.section'
            ])
            ->where('is_current', 1)
```

**Evidence**
```
$ php artisan tinker --execute '... echo "SAS=".DB::table("std_student_academic_sessions")->count().PHP_EOL;'
SAS=9759
$ grep -n "Student::orderBy('first_name')->get()" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
376:        $incidentStudents = Student::orderBy('first_name')->get();
```

#### ATD-17 · L · QRY-08 — six leading-wildcard `LIKE` searches

| Field | Value |
|---|---|
| **Rule** | QRY-08 (L) — *Leading-wildcard `LIKE '%x%'` can't use an index. Acceptable on small tables.* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:341-349`, medical-incident search in `bulkAttendanceIndex()` |
| **Root cause** | `where('location', 'like', "%{$term}%")` and five more `.orWhere(...like "%{$term}%")`, including `orWhereHas('student', ...)`. |
| **Consequence** | Acceptable today on 674 incidents; becomes a scan risk if the table grows. |
| **Reproduce** | Type in the medical-incident search box — the query uses leading-wildcard LIKE. |
| **Fix approach** | Prefix match or a dedicated search column when the table grows (documented, not urgent). |
| **Plan item** | none — accepted as-size on a small table, see plan §10 |

```php
                $q->where('location', 'like', "%{$term}%")
                    ->orWhere('description', 'like', "%{$term}%")
                    ->orWhereHas('student', function ($s) use ($term) {
```

**Evidence**
```
$ grep -n "'like'" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
341:                $q->where('location', 'like', "%{$term}%")
342:                    ->orWhere('description', 'like', "%{$term}%")
346:                        $s->where('first_name', 'like', "%{$term}%")
347:                            ->orWhere('middle_name', 'like', "%{$term}%")
348:                            ->orWhere('last_name', 'like', "%{$term}%")
349:                            ->orWhere('admission_no', 'like', "%{$term}%");
```

### F10 — Views

#### ATD-18 · M · VIEW-02 — bulk list lazy-loads `user` per row (N+1)

| Field | Value |
|---|---|
| **Rule** | VIEW-02 (M) — *Relations used inside `@foreach` are eager-loaded by the controller (lazy loads in a loop = N+1).* |
| **Where** | `Modules/StudentProfile/resources/views/student-settings/index.blade.php:228-231`, `@foreach ($students …)` — `$email = $student->email ?? ($student->user->email ?? 'N/A');` |
| **Root cause** | The blade reads `$student->user->email` inside the roster loop. `bulkAttendanceIndex`'s students query eager-loads only `currentAcademicSession` (`AttendanceController.php:311`), not `user`. `std_students` has **no `email` column** either — `$student->email` is always empty, so every row evaluates the `user` relation → one extra query per student. |
| **Consequence** | A 60-student roster = 60 extra `sys_users` queries on every bulk page load. |
| **Reproduce** | Open `/student-profile/bulk-attendance?class_section_id=…` with the debugbar/query log — one `select * from sys_users` per student row. |
| **Fix approach** | Eager-load `user` in the students query (`->with(['currentAcademicSession', 'user'])`). |
| **Plan item** | ATD-18 in `02-fix-plan.md` §7 |

```php
                                    @foreach ($students as $index => $student)
                                        @php
                                            $currentAttendance = $attendanceRecords[$student->id] ?? null;
                                            $email = $student->email ?? ($student->user->email ?? 'N/A');
```

**Evidence**
```
$ grep -n "with(\['currentAcademicSession'" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php
311:                ->with(['currentAcademicSession' => function ($query) {
```

F10 otherwise clean — all four in-scope blades compile (proven below) and none contains `Model::`/`DB::` queries or `{!! !!}` on user text.

```
$ php artisan tinker --execute '... foreach(["studentprofile::student-attendance.create","studentprofile::index","studentprofile::student-settings.index","studentprofile::medical-incident.index"] as $name){ try { $v->make($name); echo "OK $name",PHP_EOL; } catch (\Throwable $e) { echo "FAIL $name: ",$e->getMessage(),PHP_EOL; }}'
OK studentprofile::student-attendance.create
OK studentprofile::index
OK studentprofile::student-settings.index
OK studentprofile::medical-incident.index
```

### F11 — Security and tenancy

clean — no `env()` call in any in-scope file (`grep -rn "env(" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php Modules/StudentProfile/app/Models/StudentAttendance.php Modules/StudentProfile/app/Services/AttendanceService.php Modules/StudentProfile/app/Policies/AttendancePolicy.php` → no output); no hard-coded id fallbacks (`?? 1` absent); no secrets in logs; tenant routes all sit in the tenancy middleware group; no cache keys to tenant-key.

### F12 — Style

#### ATD-19 · L · STY-01 — strict_types missing in controller, model, policy

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched).* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:1`, `Modules/StudentProfile/app/Models/StudentAttendance.php:1`, `Modules/StudentProfile/app/Policies/AttendancePolicy.php:1` |
| **Root cause** | None of the three in-scope PHP classes opens with `declare(strict_types=1);`. (The pre-assigned `AttendanceService` already has it.) |
| **Consequence** | Type coercion stays loose; inconsistent with the service sibling. |
| **Reproduce** | Static only. |
| **Fix approach** | Add the declare line to each file the next time it is touched (STY grouping, one item per file). |
| **Plan item** | ATD-19 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\StudentProfile\Http\Controllers;
```

**Evidence**
```
$ grep -c "strict_types" Modules/StudentProfile/app/Http/Controllers/AttendanceController.php Modules/StudentProfile/app/Models/StudentAttendance.php Modules/StudentProfile/app/Policies/AttendancePolicy.php
Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:0
Modules/StudentProfile/app/Models/StudentAttendance.php:0
Modules/StudentProfile/app/Policies/AttendancePolicy.php:0
$ grep -c "strict_types" Modules/StudentProfile/app/Services/AttendanceService.php
1
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 wrong overwrite | 2 delete before store | 3 duplicate impl | 4 soft-delete×unique | 5 race | 6 auth hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `scanAttendance` | ok — keyed by student+date+period | n/a | ATD-10 (twin) | ok — no soft delete | ok — unique index `uq_std_att_student_date` guards (a duplicate would throw, caught) | ATD-07 (`marked_by`) | ok | ok |
| `manualAttendance` | ok — keyed by student+date+period | n/a | ATD-10 | ok | ok | ATD-07 | ok | ok |
| `storeBulkAttendance` | ok — keyed by student+session+class+date | ok — deletes replaced by re-marking, inside tx | ATD-10/ATD-15 | ATD-12 (hard delete + unique-index trap) | ATD-15 (per-row loop; unique index guards) | ok — uses `Auth::id()` | ok | ok |
| `AttendanceService::markAbsentFromPeriod` | ok | n/a | SVC duplication of attendance write | ok | ok | ATD-14 (`auth()` in queue = null marked_by) | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/StudentProfile/resources/views/index.blade.php` | The shared index view gates both tabs with `@can`, but `bulkAttendanceIndex` loads the medical-incident query for every caller who holds only `attendance.viewAny`; the extra query is wasted work on every visit. | QRY-12 | AttendanceController fix (in that controller: build `$incidents` only when `$isMedicalTab`) — tracked as part of ATD-09/ATD-16 |
| `Modules/StudentProfile/app/Models/Student.php` | Owned by StudentReportController; `currentAcademicSession` used by this controller is eager-loaded with a narrow select — no defect here. | — | none |
| `Modules/StudentProfile/app/Models/MedicalIncident.php` | Owned by MedicalIncidentController; the medical tab on this screen is a second read path over the same table with `orWhereHas('student', ...like...)`. | QRY-08 | MedicalIncidentController report, cross-reference |

## 8. Not covered, and why

- **Router cache truth**: the route:list was the authoritative, uncached output (`APP_ROUTES_CACHE=/tmp/fa-nocache.php`); the scanner JSON is a snapshot taken by the main session and its rows are candidates only.
- **The FrontOffice sync job wasn't executed** (D4, no tests/queues), so ATD-14's null-`marked_by` consequence is proven by static call path + code, not by a live job run — marked `⚠ UNVERIFIED` in the finding.
- **Blade runtime rendering beyond `view()->make()`**: the four blades compile and resolve, but full data-dependent rendering (e.g. the medical-incident tab with pagination) was not exercised in a browser.
- **`bulkAttendanceIndex`'s `$incidentsExport`** is passed to the medical blade for its export component; the export button itself was not clicked (D4).
- **Permission roll-out:** create/viewAny are granted only to Super Admin and School Admin on the test tenant; other roles in the checkbox surfaces were not enumerated per role.
- **The model's `boot()/saving` hook** forcibly re-sets `marked_at` on every save (even reads-then-save); the controller also passes `marked_at => now()` — redundant but not reported as a defect.
- **`getAttendanceReport`'s `->get()`** (QRY-02 on an unbounded list) is swallowed by ATD-08's abort fix; not double-reported.