# Final Audit — StudentProfile / StudentDashboardController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php` (277 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/student-profile/dashboard` — one GET page with five client-side tabs: `?tab=overview`, `?tab=students`, `?tab=leaves`, `?tab=attendance`, `?tab=health` |
| Menu path | Student Profile & Leave Mgmt. (menu id 64) → Dashboard (menu id 65, route `student-profile.dashboard`) |
| Who uses it | Roles that hold `tenant.student-profile.dashboard.viewAny` — measured on the live tenant: Super Admin (1 role), School Admin (1 role) |
| What a user does here | A school admin opens a read-only dashboard with five tabs. Overview counts students, leaves and medical incidents and lists recent admissions and recent leaves. Students shows gender/class/monthly-admission charts and a recent-students table. Leaves shows leave counts by status, a leave-type donut and pending/recent leave lists. Attendance shows today's present/absent counts, a 7-day weekly breakdown and a 6-month trend. Health counts health profiles, incidents and vaccinations and lists recent incidents and vaccinations. Every number is computed live from the tenant tables. Nothing on this screen is saved — there is no write path at all. |
| Tables written | none — this controller only reads |
| Tables read | `std_students` (1,825), `std_leave_applications` (4), `std_leave_types`, `std_medical_incidents` (674), `std_student_academic_sessions` (9,759), `sch_class_section_jnt`, `std_student_attendance` (99,334), `std_health_profiles` (1,825), `std_vaccination_records` (8,259), `sys_dropdown_table` |
| Live data | measured on tenant `xyz_school_00000000000040008000_202627` (domain `test.localhost`) on 2026-10-10; trashed rows: 0 in `std_students` and `std_leave_applications` |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

The controller is correctness-clean: it authorizes with a seeded exact-name permission before any data load, it is read-only, it runs all aggregates in SQL, every list is bounded with a `limit`, there is no query inside a loop, and the blade compiles with no raw-HTML output. It is **not** production-ready because of performance: one dashboard load issues about 46 SQL statements, 10 of which are byte-identical duplicate counts, and four of them full-scan the 99,334-row attendance table (EXPLAIN reports ~99,160 rows scanned per count). The single worst finding is **SDB-01**: `buildAttendanceStats()` cannot use any index on `std_student_attendance`. Rough effort: **S** (a few hours) for the mechanical items, plus one migration-bearing DECISION that Tarun must choose and run.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 2 | 2 | 1 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | SDB-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | SDB-01, SDB-02 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | SDB-05 |
| F6 Controller shape | SDB-04 | F13 Deep read | table in §6 (no mutating methods) |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php` | controller | 277 | this report | ✅ |
| 2 | `Modules/StudentProfile/resources/views/dashboard/index.blade.php` | view | 689 | this report | ✅ |
| 3 | `resources/views/components/backend/layouts/app.blade.php` | shared layout | 2 | common (§4.2) | ↗ common — not audited here |
| 4 | `resources/views/components/backend/components/breadcrum.blade.php` | shared component | 229 | common (§4.2) | ↗ common — not audited here |
| 5 | `resources/views/components/backend/tab/nav-tab.blade.php` | shared component | 328 | common (§4.2) | ↗ common — not audited here |
| 6 | `Modules/Dashboard/resources/views/components/stat-card-icon.blade.php` | other-module component | 37 | common (§4.2) | ↗ common — not audited here |

No models, FormRequests, policies, services or jobs are used — the controller reads via the query builder (`DB::table`) and the framework's `Gate`, `DB`, `Schema`, `Carbon` facade classes, which are app glue. No class needed a new claim in `00-CLASS-OWNERS.md`.

No pre-applied files.

## 4. Routes

From the uncached route table (`APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json`):

```
GET|HEAD student-profile/dashboard                               student-profile.dashboard                          Modules\StudentProfile\Http\Controllers\StudentDashboardController@index
```

Middleware on the route (from `route:list --json`): `web`, `PreventAccessFromCentralDomains`, `InitializeTenancyByDomain`, `EnsureTenantIsActive`, `Authenticate`, `EnsureEmailIsVerified`, `EnsureTenantHasModule:STUDENT`. Tenant-scoped and authenticated.

Unrouted public methods: none — the only public method is `index()` (line 14) and it is routed. The other six methods (`safeCount`, `buildOverview`, `buildStudentStats`, `buildLeaveStats`, `buildAttendanceStats`, `buildHealthStats`) are private helpers.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 14 | GET /student-profile/dashboard | `tenant.student-profile.dashboard.viewAny` | — (read-only) | — | none | SDB-01, SDB-02, SDB-04, SDB-05 |
| `safeCount` | 33 | — private | — | — | — | none | SDB-02, SDB-03 |
| `buildOverview` | 49 | — private | — | — | — | none | SDB-02 |
| `buildStudentStats` | 87 | — private | — | — | — | none | SDB-02 |
| `buildLeaveStats` | 132 | — private | — | — | — | none | SDB-02 |
| `buildAttendanceStats` | 188 | — private | — | — | — | none | SDB-01 |
| `buildHealthStats` | 236 | — private | — | — | — | none | SDB-02 |

## 6. Findings

### F1 — Errors

#### SDB-03 · M · ERR-07 — safeCount swallows every DB error and paints zeros

| Field | Value |
|---|---|
| **Rule** | ERR-07 (M) — *read-only methods need no try/catch under either variant* (D1: the only allowed catches are the D2 shapes; this is none of them) |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php:33-47`, method `safeCount()` |
| **Root cause** | `catch (\Exception $e) { return 0; }` sits on a read path. Any database failure — a locked table, a dropped column, a dead connection — is swallowed and reported as zero, so every card on the dashboard quietly lies instead of failing loud. `Schema::hasColumn` itself throws when the table is missing, and this catch hides that too. |
| **Consequence** | A school admin sees "Total Students: 0" or "Medical Incidents: 0" during a DB hiccup, with no error logged beyond the silent catch, and no one is told anything failed. |
| **Reproduce** | Make the tenant DB briefly unreachable (stop MySQL or run `FLUSH TABLES WITH READ LOCK` in another session) and refresh `/student-profile/dashboard` — the page renders with zeros instead of a 500 that names the failing query. Static evidence: the catch body returns 0. |
| **Fix approach** | Delete the `try/catch` so the query builder exception bubbles to the central handler in `bootstrap/app.php`, which logs it and renders the standard error page (D1). The same replacement is planned with SDB-02 because both changes are the same 15-line method. |
| **Plan item** | covered by SDB-02 in `02-fix-plan.md` §6 (one atomic replacement of `safeCount()`); recorded here so F1 is not silently empty |

```php
// StudentDashboardController.php:33-47 — CURRENT
    private function safeCount(string $table, array $conditions = []): int
    {
        try {
            $query = DB::table($table);
            if (\Illuminate\Support\Facades\Schema::hasColumn($table, 'deleted_at')) {
                $query->whereNull('deleted_at');
            }
            foreach ($conditions as $col => $val) {
                $query->where($col, $val);
            }
            return (int) $query->count();
        } catch (\Exception $e) {
            return 0;
        }
    }
```

**Evidence**
```
$ grep -nE 'try \{|catch \(' Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php
35:        try {
44:        } catch (\Exception $e) {
45:            return 0;
```

### F2 — Transactions and audit

clean — no write path exists: `grep -nE 'DB::transaction|beginTransaction|commit|rollBack|activityLog|->update\(|->create\(|->insert\(|->delete\(' Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php` → no output (exit 1).

### F3 — Authorization

clean — `index()` authorizes `tenant.student-profile.dashboard.viewAny` on line 16 before any record is loaded (AUTH-01, AUTH-02). The permission is declared in `config/permissionslist.php` (`'student-profile.dashboard' => $crud`, line 525) and seeded on the tenant: `SELECT COUNT(*) FROM sys_permissions WHERE name = 'tenant.student-profile.dashboard.viewAny'` → 1; `sys_role_has_permissions_jnt` joins → Super Admin (1), School Admin (1). Permission string appears exactly once in the controller (AUTH-06 satisfied — no dead duplicates).

### F4 — Validation and input

clean — the controller takes no user input at all; the only request data is the `tab` query parameter read in the blade (`request('tab', 'overview')`) and it is never echoed, only compared for equality.

### F5 — Routes

clean — the dashboard is a plain GET read route (RTE-01 satisfied — no state change), it points at an existing method (RTE-02), `index()` is the only public method and it is routed (RTE-03), and it sits inside the module middleware group with tenancy + auth middleware (RTE-05). No `Route::resource` prefix conflicts here.

### F6 — Controller shape

#### SDB-04 · L · CTL-04 — index() has no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php:14`, method `index()` |
| **Root cause** | Every private helper declares a return type (`: array`, `: int`), but the one public method does not. The scanner flagged it (`CTL-04 ... index — index() has no return type`). |
| **Consequence** | No runtime bug — a consistency/contract gap that makes the method's behaviour harder to read and lets a future change accidentally return the wrong shape. |
| **Reproduce** | Static only — the missing type is visible in the method signature. |
| **Fix approach** | Add `: \Illuminate\Contracts\View\View` to `index()`. |
| **Plan item** | SDB-04 in `02-fix-plan.md` §5 |

```php
// StudentDashboardController.php:14 — CURRENT
    public function index()
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+' Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php
14:    public function index()
```
Scanner row: `L CTL-04 Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php:14 index — index() has no return type`.

### F7 — Models

clean — no model is used: `grep -nE 'use Modules\\|::where|::find' Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php` → no output. All reads go through the query builder against tenant tables, so the MDL family does not apply.

### F8 — Services and jobs

clean — no service, job, listener or event is used: `grep -nE 'Service|job|Event|::dispatch' Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php` → no output. The SVC/JOB families do not apply.

### F9 — Queries and performance

#### SDB-01 · H · QRY-14 — attendance queries full-scan a 99,334-row table (raised from M)

| Field | Value |
|---|---|
| **Rule** | QRY-14 (M default, **raised to H** — four full index scans on the module's landing screen against a table that grows ~180k rows per school year) — *columns used in where/orderBy on large tables have indexes* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php:188-228`, method `buildAttendanceStats()` |
| **Root cause** | The table `std_student_attendance` has no index whose leading column is `attendance_date` — only `uq_std_att_student_date (student_id, attendance_date, attendance_period)` and `idx_std_att_class_date (class_section_id, attendance_date)`. The two today-counts use `whereDate('attendance_date', ...)`, which MySQL implements as `DATE(attendance_date) = ?` and which can never use an index even on a leading column. The weekly and monthly groupBy filters use a range on `attendance_date` but cannot use either index because `attendance_date` is not a leading column. EXPLAIN shows `type=index rows=99160` for every one of the four queries — each one walks the whole index. |
| **Consequence** | Every render of `/student-profile/dashboard` scans the ~99,334 attendance rows four times; as years of attendance accumulate, the page slows on the screen a school admin sees right after login. |
| **Reproduce** | Load `/student-profile/dashboard` (Attendance tab renders all four queries server-side on every load; the data is not lazy). Evidence below is the EXPLAIN on the live tenant. |
| **Fix approach** | Rewrite the two `whereDate` calls as range clauses on the raw column (`attendance_date >= today 00:00` and `< tomorrow 00:00`) and add an additive migration with an index on `attendance_date`. The migration makes this a DECISION item. |
| **Plan item** | SDB-01 in `02-fix-plan.md` §9 (DECISION — needs a migration) |

```php
// StudentDashboardController.php:188-213 — CURRENT
    private function buildAttendanceStats(): array
    {
        $todayPresent = DB::table('std_student_attendance')
            ->whereDate('attendance_date', Carbon::today())
            ->where('status', 'Present')
            ->count();

        $todayAbsent = DB::table('std_student_attendance')
            ->whereDate('attendance_date', Carbon::today())
            ->where('status', 'Absent')
            ->count();

        $todayTotal     = $todayPresent + $todayAbsent;
        $todayPercentage = $todayTotal > 0 ? round(($todayPresent / $todayTotal) * 100, 1) : 0;

        $weeklyAttendance = DB::table('std_student_attendance')
            ->where('attendance_date', '>=', Carbon::now()->subDays(7)->startOfDay())
            ->select(
                DB::raw("DATE_FORMAT(attendance_date, '%a %d %b') as day"),
                DB::raw("SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) as present"),
                DB::raw("SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) as absent"),
                DB::raw('count(*) as total')
            )
            ->groupBy('attendance_date')
            ->orderBy('attendance_date')
            ->get();
```

**Evidence**
```
$ php artisan tinker --execute '... tenancy()->initialize($d->tenant); EXPLAIN ...'
whereDate: type=index key=idx_std_att_class_date rows=99160
range:     type=index key=idx_std_att_class_date rows=99160
TOTAL_ROWS=99334
$ SHOW INDEX FROM std_student_attendance
PRIMARY | id
uq_std_att_student_date | student_id, attendance_date, attendance_period
idx_std_att_class_date | class_section_id, attendance_date
fk_att_marker | marked_by
-- no index leads with attendance_date
```

#### SDB-02 · M · QRY-12 — one render fires ~46 SQL statements and recounts the same tables twice

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) — *identical queries repeated in one request (the same dropdown id looked up 6×) → resolve once* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php:33-47` method `safeCount()`, called 14 times from `buildOverview()`, `buildStudentStats()`, `buildLeaveStats()`, `buildHealthStats()` |
| **Root cause** | `safeCount()` does TWO queries per call: `Schema::hasColumn($table, 'deleted_at')` (an information_schema lookup) plus the `count()`. The five builders independently recount the same tables: `std_students`, `std_students is_active=1`, `std_leave_applications`, `std_leave_applications status=Submitted` and `std_medical_incidents` are each counted twice in one request. Result: 14 count queries + 14 schema queries + 18 direct queries = ~46 statements, 10 of them byte-identical duplicates. |
| **Consequence** | A small school dashboard pays ~46 SQL round-trips every time it is opened; the duplicated work is pure waste and makes the page slower than the numbers alone suggest. |
| **Reproduce** | Load `/student-profile/dashboard`. Static evidence below counts the call sites and the duplicates. |
| **Fix approach** | Memoise in `safeCount()` with a per-request cache keyed by `table|conditions` so each unique count and each `hasColumn` check runs once (total drops to ~9 schema checks + ~9 counts + 18 direct = ~36 statements). The same replacement removes the catch (SDB-03), because both live in this one method. |
| **Plan item** | SDB-02 in `02-fix-plan.md` §6 (also closes SDB-03) |

```php
// StudentDashboardController.php:33-47 — CURRENT
    private function safeCount(string $table, array $conditions = []): int
    {
        try {
            $query = DB::table($table);
            if (\Illuminate\Support\Facades\Schema::hasColumn($table, 'deleted_at')) {
                $query->whereNull('deleted_at');
            }
            foreach ($conditions as $col => $val) {
                $query->where($col, $val);
            }
            return (int) $query->count();
        } catch (\Exception $e) {
            return 0;
        }
    }
```

**Evidence**
```
$ F=Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php
$ grep -oE "safeCount\('[^']+'([^)]*)\)" $F | sort | uniq -c
      1 safeCount('std_health_profiles')
      2 safeCount('std_leave_applications')
      1 safeCount('std_leave_applications', ['status' => 'Approved'])
      1 safeCount('std_leave_applications', ['status' => 'Rejected'])
      2 safeCount('std_leave_applications', ['status' => 'Submitted'])
      2 safeCount('std_medical_incidents')
      2 safeCount('std_students')
      2 safeCount('std_students', ['is_active' => 1])
      1 safeCount('std_vaccination_records')
$ echo "DB::table total: $(grep -c 'DB::table(' $F)"   # 19 = 1 in safeCount + 18 direct
DB::table total: 19
$ echo "safeCount call sites: $(grep -c 'safeCount(' $F)"   # 15 lines incl. the definition
safeCount call sites: 15
```
Runtime estimate: 14 × (1 hasColumn query + 1 count query) + 18 direct = **46 SQL statements per render**, 5 pairs of them duplicates.

QRY-01 (N+1): clean — no query appears inside a `foreach`/`map` in the controller (`grep -nE 'foreach' $F` shows only the `$conditions` loop building a single query, and the `mapWithKeys` over already-fetched rows). QRY-02 (unbounded gets): clean — every list carries `limit(8)` or `limit(10)`; the two groupBy aggregations without a limit are bounded by the time window (7 days / 6 months). QRY-04/QRY-05 (aggregate in SQL): clean — all counts and distributions use `count(*)`, `groupBy` and `SUM(CASE ...)` in SQL. QRY-11 (interpolated raw SQL): clean — all `DB::raw` strings are literals with no `$var` interpolation.

### F10 — Views

clean — `dashboard/index.blade.php` (689 lines) contains no query calls (`grep -nE '\{\{[!{]|::where|::get|DB::|->count\(\)'` → no output), no `{!! !!}` on user data, every echoed value is a mapped row from a bounded query, and the blade compiles: `compileString()` → 59,420 bytes, `php -l` on the compiled output → no syntax errors. All five route() targets used by the Quick Actions and View All links exist in the route table (verified: `student-profile.student.create`, `student-profile.student-leave.index`, `student-profile.attendance.bulk`, `student-profile.medical-incidents.index`, `student-profile.student.index`). The `@json(...)` chart payloads are escaped by Blade's JSON encoder (no stored XSS).

### F11 — Security and tenancy

clean — no `env()` (`grep -nE 'env\(' $F` → no output), no hard-coded record ids (the `is_active => 1` conditions are boolean flags, not ids — SEC-03 does not apply), no secrets logged, and all reads run against tenant tables inside the already-initialised tenancy. The chart `@json` payloads expose the same student names the page's own tables show to a holder of the dashboard permission — no wider audience.

### F12 — Style

#### SDB-05 · L · STY-02 — controller is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, alignment spacing, no stray blank lines* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php:7-10` (import order), `:37` (`\Illuminate\Support\Facades\Schema::hasColumn` fully qualified mid-method), `:18-22,51-55,89-90,134-137,200` (extra alignment spaces before `=`), `:42-43` (missing blank line before `return` inside `safeCount`) |
| **Root cause** | `vendor/bin/pint --test` reports the file as failing with four fixers: `fully_qualified_strict_types`, `blank_line_before_statement`, `ordered_imports`, `binary_operator_spaces`. A dry-run on a copy showed the exact diff: imports must sort `App\...`, `Carbon\...`, `Illuminate\...`; `Schema` must be a `use` import; the multi-assignment blocks lose their column alignment; a blank line is added before the `return` in `safeCount`. |
| **Consequence** | Style debt only — the file fails the project's own formatter, so `pint --dirty` on any future edit will reformat it uninvited. |
| **Reproduce** | Static: `vendor/bin/pint --test Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php` → `{"tool":"pint","result":"fail","fixers":[...]}`. |
| **Fix approach** | Run Pint on this file only (`vendor/bin/pint <file> --format agent`). |
| **Plan item** | SDB-05 in `02-fix-plan.md` §8 |

```php
// StudentDashboardController.php:7-10 — CURRENT
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/StudentProfile\/app\/Http\/Controllers\/StudentDashboardController.php",
"fixers":["fully_qualified_strict_types","blank_line_before_statement","ordered_imports","binary_operator_spaces"]}]}
```

GTY-01: `declare(strict_types=1)` is present on line 3. STY-03/04: names are camelCase, comments are English without emoji or commented-out code.

### F13 — Deep read (answer all 8 questions for every mutating method)

There are **no mutating methods** in this controller (verified by the F2 grep: no `DB::transaction`, `->update`, `->create`, `->insert`, `->delete`, `activityLog`). The eight questions therefore have no target; the controller cannot overwrite data, delete before storing, race on counts, or mis-authorize a write. Question 7 (messages that lie) is the one place a read-only screen can still lie — that is finding SDB-03 (errors swallowed as zeros).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| (none) | No defect found in the shared components used by this view (`x-backend.layouts.app`, `x-backend.components.breadcrum`, `x-backend.tab.nav-tab`, `x-dashboard::stat-card-icon`) — all are used with their documented props and compile. | — | — |

The `x-dashboard::stat-card-icon` component belongs to the `Modules/Dashboard` module and is shared by other screens; any change to it is out of this workflow's scope.

## 8. Not covered, and why

- **No real HTTP render of the dashboard** was executed with an authenticated session, so the shared components render only as far as `compileString()` proves they compile; a runtime component-resolution failure in `x-backend.*` or `x-dashboard::stat-card-icon` cannot be ruled out here (it would belong to those common classes anyway).
- **Browser timing of the page** was not measured; the query-count claims come from a static statement census and EXPLAIN, not a profiler run over HTTP.
- **The migration for SDB-01** was not written and will not be run — it is a DECISION for Tarun.