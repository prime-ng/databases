# Fix Plan — StudentProfile / StdLeaveController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/StudentProfile/routes/web.php` | shared route file; no ticked item renames a route |
| `config/permissionslist.php` | shared permission registry; every needed key already exists |
| `Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php` | shared provider; the policy DECISION is not applied in this pass |
| `Modules/StudentProfile/app/Models/StudentAttendance.php` | owned by `gaurav/StudentProfile/AttendanceController` |
| `Modules/StudentProfile/app/Models/Student.php` | owned by `gaurav/StudentProfile/StudentReportController` |
| `Modules/StudentProfile/app/Models/LeaveType.php` | owned by `gaurav/StudentProfile/StudentLeaveTypeController` |
| `bootstrap/app.php` | common exception handler |
| `database/migrations/**` | never edited by this workflow |
| `resources/views/components/**`, layouts, `Modules/TenantCore/**` | common components |

## 1. Blockers reachable today

- [ ] **SLV-11** · B · MDL-05 · `Modules/StudentProfile/app/Models/LeaveApplicationDocument.php:15-17` — give the model a tenant media model so uploads stop writing `sys_media` to the central database.
  - **Touches:** `Modules/StudentProfile/app/Models/LeaveApplicationDocument.php`
  - **Before** (`LeaveApplicationDocument.php:15-17`):
    ```php
    class LeaveApplicationDocument extends Model implements HasMedia
    {
        use SoftDeletes, InteractsWithMedia;
    ```
  - **After:**
    ```php
    class LeaveApplicationDocument extends Model implements HasMedia
    {
        use SoftDeletes, InteractsWithMedia;

        public function getMediaModel(): string
        {
            return \App\Models\TenantMedia::class;
        }
    ```
  - **Verify:** `grep -n "getMediaModel" Modules/StudentProfile/app/Models/LeaveApplicationDocument.php`
  - **Expect:** one hit, returning `\App\Models\TenantMedia::class`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None. No item here.

## 3. Errors & transactions (F1/F2)

- [ ] **SLV-02** · H · TXN-01 · `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:289-318` — wrap the remark, its documents and the audit row in one transaction.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php`
  - **Before** (`StdLeaveController.php:289-318`):
    ```php
            $remark = LeaveApplicationRemark::create([
                'leave_application_id' => $validated['leave_application_id'],
                'remark_type' => LeaveApplicationRemark::TYPE_COMMENT,
                'message' => $messageText,
                'is_from_teacher' => true,
                'remarked_by' => auth()->id(),
            ]);

            if ($request->hasFile('attachments')) {
                foreach ($request->file('attachments') as $file) {
                    $document = LeaveApplicationDocument::create([
                        'leave_application_id' => $validated['leave_application_id'],
                        'document_name' => $file->getClientOriginalName(),
                        'document_type_id' => $validated['document_type_id'] ?? null,
                        'description' => $validated['description'] ?? null,
                        'file_name' => $file->hashName(),
                        'uploaded_by' => auth()->id(),
                        'is_in_response_to_request' => false,
                        'request_remark_id' => $remark->id,
                    ]);

                    $document->addMedia($file)
                        ->usingFileName($file->hashName())
                        ->toMediaCollection('leave-documents');

                    $document->update(['media_id' => $document->getFirstMedia('leave-documents')?->id]);
                }
            }

            activityLog($application, 'Remark Added', ['leave_application_id' => $application->id]);
    ```
  - **After:**
    ```php
            $remark = DB::transaction(function () use ($validated, $request, $application, $messageText) {
                $remark = LeaveApplicationRemark::create([
                    'leave_application_id' => $validated['leave_application_id'],
                    'remark_type' => LeaveApplicationRemark::TYPE_COMMENT,
                    'message' => $messageText,
                    'is_from_teacher' => true,
                    'remarked_by' => auth()->id(),
                ]);

                if ($request->hasFile('attachments')) {
                    foreach ($request->file('attachments') as $file) {
                        $document = LeaveApplicationDocument::create([
                            'leave_application_id' => $validated['leave_application_id'],
                            'document_name' => $file->getClientOriginalName(),
                            'document_type_id' => $validated['document_type_id'] ?? null,
                            'description' => $validated['description'] ?? null,
                            'file_name' => $file->hashName(),
                            'uploaded_by' => auth()->id(),
                            'is_in_response_to_request' => false,
                            'request_remark_id' => $remark->id,
                        ]);

                        $document->addMedia($file)
                            ->usingFileName($file->hashName())
                            ->toMediaCollection('leave-documents');

                        $document->update(['media_id' => $document->getFirstMedia('leave-documents')?->id]);
                    }
                }

                activityLog($application, 'Remark Added', ['leave_application_id' => $application->id]);

                return $remark;
            });
    ```
  - **After (import — add above the class):** the new code needs the `DB` facade. Apply this pair too.
    - **Before** (`StdLeaveController.php:5-7`):
      ```php
      use App\Http\Controllers\Controller;
      use Illuminate\Http\Request;
      use Illuminate\Support\Facades\Gate;
      ```
    - **After:**
      ```php
      use App\Http\Controllers\Controller;
      use Illuminate\Http\Request;
      use Illuminate\Support\Facades\DB;
      use Illuminate\Support\Facades\Gate;
      ```
  - **Verify:** `grep -n "DB::transaction" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php`
  - **Expect:** one hit inside `storeRemark` (around line 289).
  - **Effort:** M

- [ ] **SLV-03** · H · TXN-04 · `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:363-365,403-405` — put the audit row inside the same transaction as the write it describes.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php`
  - **Before** (`StdLeaveController.php:363-365`):
    ```php
            $leaveService->review($application, $validated);

            activityLog($application, 'Reviewed', ['status' => $validated['status']]);
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($leaveService, $application, $validated) {
                $leaveService->review($application, $validated);

                activityLog($application, 'Reviewed', ['status' => $validated['status']]);
            });
    ```
  - **Before** (`StdLeaveController.php:402-408`):
    ```php
            try {
                $leaveService->updateApplication($application, $validated);

                activityLog($application, 'Updated', ['message' => 'Leave application updated']);
            } catch (\InvalidArgumentException $e) {
                return back()->withInput()->withErrors(['leave_type_id' => $e->getMessage()]);
            }
    ```
  - **After:**
    ```php
            try {
                DB::transaction(function () use ($leaveService, $application, $validated) {
                    $leaveService->updateApplication($application, $validated);

                    activityLog($application, 'Updated', ['message' => 'Leave application updated']);
                });
            } catch (\InvalidArgumentException $e) {
                return back()->withInput()->withErrors(['leave_type_id' => $e->getMessage()]);
            }
    ```
  - **Verify:** `grep -n "activityLog" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php`
  - **Expect:** each `activityLog` line is now indented inside a `DB::transaction` closure.
  - **Effort:** S

- [ ] **SLV-04** · H · TXN-01 · `Modules/StudentProfile/app/Services/LeaveService.php:180-184` — make the leave-type deactivate-and-delete atomic.
  - **Touches:** `Modules/StudentProfile/app/Services/LeaveService.php`
  - **Before** (`LeaveService.php:180-184`):
    ```php
        public function deleteLeaveType(LeaveType $leaveType): void
        {
            $leaveType->update(['is_active' => false]);
            $leaveType->delete();
        }
    ```
  - **After:**
    ```php
        public function deleteLeaveType(LeaveType $leaveType): void
        {
            DB::transaction(function () use ($leaveType) {
                $leaveType->update(['is_active' => false]);
                $leaveType->delete();
            });
        }
    ```
  - **Verify:** `grep -n "function deleteLeaveType" -A7 Modules/StudentProfile/app/Services/LeaveService.php`
  - **Expect:** the two writes are inside a `DB::transaction` closure.
  - **Effort:** S

## 4. Authorization (F3)

No non-decision item. The policy question is DECISION **SLV-05** in §9; the permission keys it would use already exist.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **SLV-06** · H · VAL-06 · `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:272` — restrict the attachment upload to an allow-list of types.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php`
  - **Before** (`StdLeaveController.php:272`):
    ```php
                'attachments.*' => 'nullable|file|max:5120', // 5MB max
    ```
  - **After:**
    ```php
                'attachments.*' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120', // 5MB max
    ```
  - **Verify:** `grep -n "attachments.\*" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php`
  - **Expect:** the rule now contains `mimes:pdf,jpg,jpeg,png`.
  - **Effort:** S

- [ ] **SLV-09** · M · CTL-03 · `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:334,347,375,387` — bind the route model instead of loading by id.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php`
  - **Before** (`StdLeaveController.php:334-339`):
    ```php
        public function review($id, LeaveService $leaveService)
        {
            Gate::authorize('tenant.student-profile.student-leave.review');

            $application = LeaveApplication::with(['student.user', 'leaveType', 'classSection.class', 'classSection.section', 'reviewedBy', 'appliedBy'])
                ->findOrFail($id);
    ```
  - **After:**
    ```php
        public function review(LeaveApplication $id, LeaveService $leaveService)
        {
            Gate::authorize('tenant.student-profile.student-leave.review');

            $application = $id->load(['student.user', 'leaveType', 'classSection.class', 'classSection.section', 'reviewedBy', 'appliedBy']);
    ```
  - **Before** (`StdLeaveController.php:347-350`):
    ```php
        public function updateReview(Request $request, int $id, LeaveService $leaveService)
        {
            Gate::authorize('tenant.student-profile.student-leave.update');
            $application = LeaveApplication::findOrFail($id);
    ```
  - **After:**
    ```php
        public function updateReview(Request $request, LeaveApplication $id, LeaveService $leaveService)
        {
            Gate::authorize('tenant.student-profile.student-leave.update');
            $application = $id;
    ```
  - **Before** (`StdLeaveController.php:375-379`):
    ```php
        public function edit($id, LeaveService $leaveService)
        {
            Gate::authorize('tenant.student-profile.student-leave.update');
            $application = LeaveApplication::with(['student.user', 'leaveType', 'classSection', 'appliedBy'])->findOrFail($id);
            $leaveTypes = $leaveService->getActiveLeaveTypes();
    ```
  - **Before** (`StdLeaveController.php:387-390`):
    ```php
        public function update(Request $request, int $id, LeaveService $leaveService)
        {
            Gate::authorize('tenant.student-profile.student-leave.update');
            $application = LeaveApplication::findOrFail($id);
    ```
  - **After** (for both `edit` and `update` above):
    ```php
        public function edit(LeaveApplication $id, LeaveService $leaveService)
        {
            Gate::authorize('tenant.student-profile.student-leave.update');
            $application = $id->load(['student.user', 'leaveType', 'classSection', 'appliedBy']);
            $leaveTypes = $leaveService->getActiveLeaveTypes();
    ```
    ```php
        public function update(Request $request, LeaveApplication $id, LeaveService $leaveService)
        {
            Gate::authorize('tenant.student-profile.student-leave.update');
            $application = $id;
    ```
  - **Verify:** `grep -nE "public function (review|updateReview|edit|update)\(" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php`
  - **Expect:** each signature type-hints `LeaveApplication $id` and no method still calls `LeaveApplication::...->findOrFail($id)`.
  - **Effort:** M

## 6. Queries & performance (F9)

- [ ] **SLV-14** · M · QRY-07 · `Modules/StudentProfile/app/Services/LeaveService.php:605-619` — replace the per-day `updateOrCreate` loop with one `upsert`.
  - **Touches:** `Modules/StudentProfile/app/Services/LeaveService.php`
  - **Before** (`LeaveService.php:605-619`):
    ```php
            foreach ($period as $day) {
                \Modules\StudentProfile\Models\StudentAttendance::updateOrCreate(
                    [
                        'student_id'          => $application->student_id,
                        'attendance_date'     => $day->format('Y-m-d'),
                        'academic_session_id' => $application->academic_session_id,
                    ],
                    [
                        'class_section_id' => $application->class_section_id,
                        'status'           => 'Leave',
                        'remarks'          => "Leave approved — Application #{$application->id}",
                        'marked_by'        => auth()->id(),
                    ]
                );
            }
    ```
  - **After:**
    ```php
            $rows = [];
            foreach ($period as $day) {
                $rows[] = [
                    'student_id'          => $application->student_id,
                    'academic_session_id' => $application->academic_session_id,
                    'class_section_id'    => $application->class_section_id,
                    'attendance_date'     => $day->format('Y-m-d'),
                    'attendance_period'   => 0,
                    'status'              => 'Leave',
                    'remarks'             => "Leave approved — Application #{$application->id}",
                    'marked_by'           => auth()->id(),
                ];
            }

            \Modules\StudentProfile\Models\StudentAttendance::upsert(
                $rows,
                ['student_id', 'attendance_date', 'attendance_period'],
                ['class_section_id', 'status', 'remarks', 'marked_by']
            );
    ```
  - **Verify:** `grep -n "updateOrCreate\|upsert" Modules/StudentProfile/app/Services/LeaveService.php`
  - **Expect:** no `updateOrCreate`; one `upsert` call.
  - **Effort:** M

## 7. Views (F10)

- [ ] **SLV-16** · H · VIEW-01 · `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:99-107` and `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_chat_item.blade.php:74-83` — eager-load the reply documents and stop querying inside the loop.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php`, `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_chat_item.blade.php`
  - **Before** (`StdLeaveController.php:99-107`):
    ```php
            if ($remarksApplicationId) {
                $remarks = LeaveApplicationRemark::where('leave_application_id', $remarksApplicationId)
                    ->with('remarkedBy')
                    ->orderBy('created_at')
                    ->get();
            } elseif ($remarksStudentId) {
                $remarks = LeaveApplicationRemark::whereHas('leaveApplication', function ($q) use ($remarksStudentId) {
                    $q->where('student_id', $remarksStudentId);
                })->with('remarkedBy')->orderBy('created_at')->get();
            }
    ```
  - **After:**
    ```php
            if ($remarksApplicationId) {
                $remarks = LeaveApplicationRemark::where('leave_application_id', $remarksApplicationId)
                    ->with(['remarkedBy', 'responseDocuments', 'parentRemark.responseDocuments'])
                    ->orderBy('created_at')
                    ->get();
            } elseif ($remarksStudentId) {
                $remarks = LeaveApplicationRemark::whereHas('leaveApplication', function ($q) use ($remarksStudentId) {
                    $q->where('student_id', $remarksStudentId);
                })->with(['remarkedBy', 'responseDocuments', 'parentRemark.responseDocuments'])->orderBy('created_at')->get();
            }
    ```
  - **Before** (`_chat_item.blade.php:74-83`):
    ```php
                @php
                    $docs = collect();
                    if($remark->remark_type === $TYPE_RESPONSE && $remark->parent_remark_id) {
                        $docs = \Modules\StudentProfile\Models\LeaveApplicationDocument::where('request_remark_id', $remark->parent_remark_id)
                            ->where('uploaded_by', $remark->remarked_by) // ensure it's their uploaded doc
                            ->get();
                    } else {
                        $docs = \Modules\StudentProfile\Models\LeaveApplicationDocument::where('request_remark_id', $remark->id)->get();
                    }
                @endphp
    ```
  - **After:**
    ```php
                @php
                    $docs = ($remark->remark_type === $TYPE_RESPONSE && $remark->parent_remark_id)
                        ? $remark->parentRemark?->responseDocuments->where('uploaded_by', $remark->remarked_by) ?? collect()
                        : $remark->responseDocuments;
                @endphp
    ```
  - **Verify:** `grep -n "LeaveApplicationDocument::where" Modules/StudentProfile/resources/views/leave-management/leave-remarks/_chat_item.blade.php`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **SLV-17** · M · TEN-04 · `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_chat_item.blade.php:89` and `Modules/StudentProfile/resources/views/leave-management/documents/index.blade.php:59` — use the tenant URL for the document fallback.
  - **Touches:** `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_chat_item.blade.php`, `Modules/StudentProfile/resources/views/leave-management/documents/index.blade.php`
  - **Before** (`_chat_item.blade.php:89`):
    ```php
                                $url = $doc->getFirstMediaUrl('leave-documents') ?: asset('storage/' . $doc->file_name);
    ```
  - **Before** (`documents/index.blade.php:59`):
    ```php
                    $url = $doc->getFirstMediaUrl('leave-documents') ?: asset('storage/' . $doc->file_name);
    ```
  - **After:**
    ```php
                                $url = $doc->getFirstMediaUrl('leave-documents') ?: tenant_asset('storage/' . $doc->file_name);
    ```
    ```php
                    $url = $doc->getFirstMediaUrl('leave-documents') ?: tenant_asset('storage/' . $doc->file_name);
    ```
  - **Verify:** `grep -rn "asset('storage" Modules/StudentProfile/resources/views/leave-management`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **SLV-18** · H · VIEW-03 · `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_js.blade.php:30-32,48-50` and `Modules/StudentProfile/resources/views/leave-management/documents/_js.blade.php:17-19,35-37` — build the dropdown options with `textContent`, not `innerHTML`.
  - **Touches:** `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_js.blade.php`, `Modules/StudentProfile/resources/views/leave-management/documents/_js.blade.php`
  - **Before** (`leave-remarks/_js.blade.php:30-32`):
    ```javascript
                        data.forEach(s => {
                            studentSelect.innerHTML += `<option value="${s.id}">${s.name}</option>`;
                        });
    ```
  - **After:**
    ```javascript
                        data.forEach(s => {
                            const opt = document.createElement('option');
                            opt.value = s.id;
                            opt.textContent = s.name;
                            studentSelect.appendChild(opt);
                        });
    ```
  - **Before** (`leave-remarks/_js.blade.php:48-50`):
    ```javascript
                        data.forEach(a => {
                            applicationSelect.innerHTML += `<option value="${a.id}">${a.label}</option>`;
                        });
    ```
  - **After:**
    ```javascript
                        data.forEach(a => {
                            const opt = document.createElement('option');
                            opt.value = a.id;
                            opt.textContent = a.label;
                            applicationSelect.appendChild(opt);
                        });
    ```
  - **Before** (`documents/_js.blade.php:17-19`):
    ```javascript
                    data.forEach(s => {
                        studentSelect.innerHTML += `<option value="${s.id}">${s.name}</option>`;
                    });
    ```
  - **After:**
    ```javascript
                    data.forEach(s => {
                        const opt = document.createElement('option');
                        opt.value = s.id;
                        opt.textContent = s.name;
                        studentSelect.appendChild(opt);
                    });
    ```
  - **Before** (`documents/_js.blade.php:35-37`):
    ```javascript
                    data.forEach(a => {
                        applicationSelect.innerHTML += `<option value="${a.id}">${a.label}</option>`;
                    });
    ```
  - **After:**
    ```javascript
                    data.forEach(a => {
                        const opt = document.createElement('option');
                        opt.value = a.id;
                        opt.textContent = a.label;
                        applicationSelect.appendChild(opt);
                    });
    ```
  - **Verify:** `grep -rn "innerHTML +=" Modules/StudentProfile/resources/views/leave-management/leave-remarks/_js.blade.php Modules/StudentProfile/resources/views/leave-management/documents/_js.blade.php`
  - **Expect:** no output.
  - **Effort:** M

## 8. Style (F12) — one item per file

- [ ] **SLV-19** · L · STY-01 · `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:1,168` and `Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php:1` — add `declare(strict_types=1)` and drop the emoji marker.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php`, `Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php`
  - **Before** (`StdLeaveController.php:1-3`):
    ```php
    <?php

    namespace Modules\StudentProfile\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Http\Controllers;
    ```
  - **Before** (`StdLeaveController.php:168`):
    ```php
         * ⚠ NOT the same lookup as getStudentsBySection() below. That one takes a
    ```
  - **After:**
    ```php
         * Note: NOT the same lookup as getStudentsBySection() below. That one takes a
    ```
  - **Before** (`LeaveApplicationPolicy.php:1-3`):
    ```php
    <?php

    namespace Modules\StudentProfile\Policies;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Policies;
    ```
  - **Verify:** `grep -n "declare(strict_types" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php`
  - **Expect:** one hit in each file.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **SLV-01** · M · DECISION · ERR-01 — how should the `LeaveService` business-rule exception be handled?
  - **Why it is a decision:** D2 wants `\DomainException`, but `LeaveService` throws `\InvalidArgumentException` at five sites and **four other controllers** (`ParentPortal` web + API, `StudentPortal` web + mobile) catch that concrete class. Changing only this controller cannot work; changing the service reaches four files outside this report.
  - (a) ⭐ Leave as is for this pass: record the D2 gap and migrate the whole service plus all five callers in one dedicated change later.
  - (b) Migrate `LeaveService` to `\DomainException` now and update all five catching controllers, then remove this controller's catch (needs edits in ParentPortal and StudentPortal).
  - (c) Keep the catch, but wrap the message and stop sending `$e->getMessage()` verbatim.
  - ➜ Choice: ____

- [ ] **SLV-05** · M · DECISION · AUTH-05 — wire `LeaveApplicationPolicy` or remove its dead registration?
  - **Why it is a decision:** both options change the authorization mechanism. Wiring the policy touches the shared provider and all nine controller checks; removing the registration leaves the string abilities as the single source of truth.
  - (a) ⭐ Accept the string abilities and remove the unused `Gate::policy(LeaveApplication::class, ...)` registration (touches the shared provider — needs an explicit tick).
  - (b) Wire the methods to the policy (`$this->authorize('view', $application)`) and keep string checks only for the list/AJAX methods.
  - (c) Leave both in place and record it as accepted debt.
  - ➜ Choice: ____

- [ ] **SLV-08** · M · DECISION · CTL-02 — extract the 137-line `index()` into per-tab loaders?
  - **Why it is a decision:** it is a behaviour-preserving refactor of a long method; D3 defers structural splits, and a wrong extraction changes which tabs load.
  - (a) ⭐ Defer to the structural refactor pass; keep the current method unchanged.
  - (b) Extract one private loader per tab now and call only the active tab's loader.
  - (c) Leave as is and record as accepted.
  - ➜ Choice: ____

- [ ] **SLV-13** · M · DECISION · CTL-02 — extract the shared overlap check from the two long service methods?
  - **Why it is a decision:** it rewrites `createAndSubmit()` (127 lines) and `updateApplication()` (108 lines) and must preserve both the create and the update semantics.
  - (a) ⭐ Defer; extract one shared `hasOverlappingApplication()` helper in a later service pass.
  - (b) Extract the helper now and call it from both methods.
  - (c) Leave as is and record as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| SLV-07 | FormRequest extraction is behaviour-neutral and is deferred to the FormRequest pass; the three inline validations are correct today. |
| SLV-10 | Adding return types to nine methods is a broad mechanical edit; deferred to the style pass to keep this plan focused. |
| SLV-12 | Adding return types to eighteen relationships across three files is a broad mechanical edit; deferred to the style pass. |
| SLV-15 | Leading-wildcard `LIKE` is accepted on the small `std_leave_types` table (10 rows); revisit only if the table grows large. |
