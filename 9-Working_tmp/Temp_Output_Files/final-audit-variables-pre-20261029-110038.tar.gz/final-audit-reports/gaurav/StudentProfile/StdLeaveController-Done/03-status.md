# Status — StudentProfile / StdLeaveController

**Fixed:** 2026-10-14 · **By:** antigravity · **Developer folder:** gaurav · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
(None)

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| SLV-02 | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:289` | Wrapped remark creation, document attachment loop, and audit log inside atomic `DB::transaction()` closure in `storeRemark()` per TXN-01 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php -Pattern "DB::transaction\(function \(\) use \(\$validated, \$request, \$application, \$messageText\)"` | `1 hit` | 2026-10-14 |
| SLV-03 | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:367,409` | Wrapped mutations and `activityLog()` together inside atomic `DB::transaction()` closures in `updateReview()` and `update()` per TXN-04 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php -Pattern "activityLog"` | `3 hits (all inside transactions)` | 2026-10-14 |
| SLV-04 | `Modules/StudentProfile/app/Services/LeaveService.php:183` | Wrapped deactivate and delete inside atomic `DB::transaction()` closure in `deleteLeaveType()` per TXN-01 | `Select-String -Path Modules/StudentProfile/app/Services/LeaveService.php -Pattern "function deleteLeaveType" -Context 0,5` | `1 hit (inside transaction)` | 2026-10-14 |
| SLV-06 | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:272` | Added `mimes:pdf,jpg,jpeg,png` to `attachments.*` rule in `storeRemark()` per VAL-06 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php -Pattern "attachments\.\*"` | `'attachments.*' => 'nullable\|file\|mimes:pdf,jpg,jpeg,png\|max:5120'` | 2026-10-14 |
| SLV-09 | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:338,350,380,392` | Bound route model `LeaveApplication $id` on `review`, `updateReview`, `edit`, and `update` per CTL-03 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php -Pattern "public function (review\|updateReview\|edit\|update)\("` | `4 hits with LeaveApplication $id` | 2026-10-14 |
| SLV-11 | `Modules/StudentProfile/app/Models/LeaveApplicationDocument.php:20` | Added `getMediaModel(): string` returning `TenantMedia::class` so Spatie media records stay in tenant DB per MDL-05 | `Select-String -Path Modules/StudentProfile/app/Models/LeaveApplicationDocument.php -Pattern "getMediaModel"` | `1 hit` | 2026-10-14 |
| SLV-14 | `Modules/StudentProfile/app/Services/LeaveService.php:622` | Replaced per-day `updateOrCreate` loop with atomic batch `StudentAttendance::upsert()` in `markAttendanceOnApproval()` per QRY-07 | `Select-String -Path Modules/StudentProfile/app/Services/LeaveService.php -Pattern "updateOrCreate\|upsert"` | `1 hit (StudentAttendance::upsert)` | 2026-10-14 |
| SLV-16 | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:99,104` and `resources/views/leave-management/leave-remarks/_chat_item.blade.php:74` | Eager-loaded `responseDocuments` and `parentRemark.responseDocuments` in controller and eliminated query inside Blade loop per VIEW-01 | `Select-String -Path Modules/StudentProfile/resources/views/leave-management/leave-remarks/_chat_item.blade.php -Pattern "LeaveApplicationDocument::where"` | `0 hits (query removed from loop)` | 2026-10-14 |
| SLV-17 | `resources/views/leave-management/leave-remarks/_chat_item.blade.php:84` and `resources/views/leave-management/documents/index.blade.php:59` | Replaced central `asset('storage/...')` with `tenant_asset('storage/...')` fallback per TEN-04 | `Get-ChildItem -Path Modules/StudentProfile/resources/views/leave-management -Recurse \| Select-String -Pattern "\basset\('storage"` | `0 hits (all use tenant_asset)` | 2026-10-14 |
| SLV-18 | `resources/views/leave-management/leave-remarks/_js.blade.php:30,48` and `resources/views/leave-management/documents/_js.blade.php:17,35` | Built dropdown options using DOM `createElement` and `textContent` instead of `innerHTML +=` per VIEW-03 | `Select-String -Path Modules/StudentProfile/resources/views/leave-management/documents/_js.blade.php -Pattern "innerHTML \+="` | `0 hits in documents/_js; safe DOM in remarks` | 2026-10-14 |
| SLV-19 | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:3,168` and `Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php:3` | Added `declare(strict_types=1);` and dropped warning emoji marker in comment per STY-01 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php, Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php -Pattern "declare\(strict_types"` | `2 hits (1 in each file)` | 2026-10-14 |

## 3. Deferred / Accepted
- `SLV-01` (ERR-01): **Deferred (Choice a).** Kept `\InvalidArgumentException` in `LeaveService` and callers for this pass. Migrating to `\DomainException` requires coordinate edits across 5 caller controllers in three separate modules (`StudentProfile`, `ParentPortal`, `StudentPortal`), deferred to a dedicated cross-portal pass.
- `SLV-05` (AUTH-05): **Accepted (Choice c).** Controller authorization is handled directly via `Gate::authorize('tenant.student-profile.student-leave.<ability>')` permission strings. `LeaveApplicationPolicy` is preserved as reference documentation. Shared provider `StudentProfileServiceProvider.php` left untouched per §0 boundary.
- `SLV-07` (VAL-03): **Deferred.** FormRequest extraction is behaviour-neutral; existing inline validations are correct and secured with mime restrictions. Deferred to module-wide FormRequest pass.
- `SLV-08` (CTL-02): **Deferred (Choice a).** 137-line `index()` dashboard method kept intact; structural extraction into per-tab loaders deferred to structural refactor pass to prevent tab-loading regressions per D3.
- `SLV-10` (CTL-04): **Deferred.** Adding return types to nine controller methods deferred to dedicated style pass.
- `SLV-12` (MDL-04): **Deferred.** Adding relationship return types across three models deferred to dedicated style pass.
- `SLV-13` (CTL-02): **Deferred (Choice a).** Shared date-overlap check helper extraction from `createAndSubmit()` and `updateApplication()` deferred to dedicated service refactoring pass.
- `SLV-15` (QRY-14): **Accepted.** Leading-wildcard `LIKE` accepted on the small `std_leave_types` lookup table (10 rows).

## 4. Needs Tarun's hand
- Browser testing of leave application review, remarks, and document attachments.

## 5. Unverifiable by this workflow (no tests, D4)
- Physical attachment uploads via live forms.

## 6. Verification log
```
$ php -l Modules/StudentProfile/app/Models/LeaveApplicationDocument.php
No syntax errors detected in Modules/StudentProfile/app/Models/LeaveApplicationDocument.php

$ php -l Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php

$ php -l Modules/StudentProfile/app/Services/LeaveService.php
No syntax errors detected in Modules/StudentProfile/app/Services/LeaveService.php

$ php -l Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php
No syntax errors detected in Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php

$ .\vendor\bin\pint.bat --test Modules/StudentProfile/app/Models/LeaveApplicationDocument.php Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php Modules/StudentProfile/app/Services/LeaveService.php Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php
{"tool":"pint","result":"passed"}
```
