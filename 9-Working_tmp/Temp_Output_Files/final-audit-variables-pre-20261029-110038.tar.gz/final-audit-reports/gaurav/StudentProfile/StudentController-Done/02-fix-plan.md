# Fix Plan — StudentProfile / StudentController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/StudentProfile/app/Http/Controllers/StudentController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php` | owned by this workflow only via STC-09's DECISION; unchanged otherwise |
| `Modules/StudentProfile/routes/web.php` | route-file change only under the ticked STC-13 DECISION |
| `config/permissionslist.php`, `database/migrations/**`, any seeder | new keys/migrations need Tarun's hand, none proposed |
| `Modules/Template/**`, `Modules/TenantCore/**`, `resources/views/components/**` | other-module / shared components |
| `Modules/SchoolSetup/**`, `Modules/GlobalMaster/**`, `Modules/SystemConfig/**`, `Modules/Notification/**`, `Modules/Prime/**` | other-module classes, audited elsewhere |
| `final-audit-reports/**` | the audit's own files |
| `Modules/StudentProfile/app/Models/Student.php`, `StudentProfile.php`, `StudentAttendance.php`, `MedicalIncident.php`, `LeaveApplication.php`, `LeaveType.php`, `StudentsExport` parent handling under STC-41 | `Student` etc. owned by linked reports; `StudentsExport` IS touched by STC-41 |

## 1. Blockers reachable today

- [ ] **STC-13** · B · RTE-02 · DECISION — three routes point at commented-out methods (500s). ⚠ SHARED route file.
  - **Why it is a decision:** removing or re-adding routes touches the module route file (§9.3), and option (b) restores ~200 lines of commented code with unclear intent.
  - (a) ⭐ Delete the three dead route registrations (`handleStudentUpdateView`, `updateVaccinationRecord`, `updateMedicalIncident`); the edit links in the health tab that point at them must be re-pointed at the delete routes. Routes are per-module; behaviour change.
  - (b) Restore the commented `updateVaccinationRecord()`/`updateMedicalIncident()`/`handleStudentUpdateView()` bodies as working methods.
  - (c) Leave as is (three guaranteed 500s).
  - ➜ Choice: ____

- [ ] **STC-01** · B · ERR-01 · `Modules/StudentProfile/app/Http/Controllers/StudentController.php` — stop sending raw exception text to the user (51 `getMessage()` uses).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:916-919`, `updateLogin` — the canonical catch):
    ```php
        } catch (\Throwable $e) {
            DB::rollBack();
            return back()->with('error', $e->getMessage())->withInput();
        }
    ```
  - **After:**
    ```php
        } catch (\Throwable $e) {
            DB::rollBack();
            report($e);
            return back()->withInput()->with('error', 'The student login could not be updated.');
        }
    ```
  - **Apply the same transform to every other `$e->getMessage()` return site in this file** (lines 864, 918, 987, 1261, 1443, 1603, 1606, 1860, 2013, 2199, 2380, 2413, 2417, 2588, 2818, 2824, 2989, 2995, 3052, 3058, 3143, 3149, 3335, 3338, 3505, 3639, 3645, 3672, 3678, 3785, 3849, 3883, 3944, 4078, 4080, 4126, 4167, 4327, 4431, 4490, 4508, 4531, 4551, 4573, 4596, 4618, 4640, 4711, 4774, 4842, 5263, 5266, 5306, 5308): replace the `with('error'|'message', …)` payload with a **fixed per-method message** (business text, no `$e->getMessage()`), always preceded by `report($e);`. Keep `DB::rollBack();` for the manual-transaction methods (STC-06 may already have removed the catch; if so, nothing to do there). Do not touch the D2 shapes (printIdCard's `\DomainException` catch at 431-435 stays verbatim).
  - **Verify:** `grep -c "getMessage" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 0 (after STC-06's conversions the count may already be lower; this item leaves none).
  - **Effort:** M

- [ ] **STC-05** · B · TXN-03 · `Modules/StudentProfile/app/Http/Controllers/StudentController.php:835-843` — send the credentials mail only after commit.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (canonical source — see the report Where):
    ```php
            if ($request->hasFile('user_img')) {
                $this->storeStudentPhoto($request, $student ?? null, $user);
            }

            Mail::to($user->email)->send(
                new StudentLoginCreated($user, $plainPassword)
            );

            DB::commit();
    ```
  - **After:**
    ```php
            if ($request->hasFile('user_img')) {
                $this->storeStudentPhoto($request, $student ?? null, $user);
            }

            DB::commit();

            Mail::to($user->email)->send(
                new StudentLoginCreated($user, $plainPassword)
            );
    ```
  - **Verify:** `grep -n "Mail::to" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** line 843 is now after `DB::commit();` (mail is at line 843+, commit before it).
  - **Effort:** S

- [ ] **STC-23** · B · MDL-05 · get `getMediaModel()` overrides so student photos/documents stay in the tenant DB.
  - **Touches:** `Modules/StudentProfile/app/Models/Guardian.php`, `Modules/StudentProfile/app/Models/StudentDocument.php`, `Modules/StudentProfile/app/Models/StudentHealthProfile.php`
  - **Before** (`Guardian.php:20-23` — add the method below `use` / after the class property block; same for the other two files):
    ```php
    use HasFactory, SoftDeletes, InteractsWithMedia {
        InteractsWithMedia::getFirstMediaUrl as traitGetFirstMediaUrl;
        InteractsWithMedia::hasMedia as traitHasMedia;
    }
    ```
  - **After:** (all three models; adjust the `use` line per file)
    ```php
    use HasFactory, SoftDeletes, InteractsWithMedia {
        InteractsWithMedia::getFirstMediaUrl as traitGetFirstMediaUrl;
        InteractsWithMedia::hasMedia as traitHasMedia;
    }
    ```
    plus, directly inside each class body:
    ```php
    public function getMediaModel(): string
    {
        return \Modules\Prime\Models\TenantMedia::class;
    }
    ```
  - **Verify:** `grep -c "getMediaModel" Modules/StudentProfile/app/Models/Guardian.php Modules/StudentProfile/app/Models/StudentDocument.php Modules/StudentProfile/app/Models/StudentHealthProfile.php`
  - **Expect:** 1 in each of the three files.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced — STC-02 before STC-01 where both are ticked)

- [ ] **STC-02** · H · ERR-02 · move `authorize()`/`validate()`/`findOrFail()` above the try in the 24 affected methods.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:790-795`, `createStudentLogin` — the canonical shape):
    ```php
        DB::beginTransaction();
        try {
            Gate::authorize('tenant.student-profile.student.create');
            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'short_name' => 'required|string|max:30|unique:sys_users,short_name',
    ```
  - **After:**
    ```php
        Gate::authorize('tenant.student-profile.student.create');
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'short_name' => 'required|string|max:30|unique:sys_users,short_name',
    ```
    then re-add the `DB::beginTransaction();` line directly above the (now deleted) `try {`. Apply the same reordering to the other 23 sites (lines 953-954, 1939-1940, 2314-2315, 2388-2389, 2634-2636, 2971-2972, 3026-3027, 3124-3125, 3169-3170, 3621-3622, 3653-3654, 3982, 4089-4090, 4137-4138, 4178-4179, 4338-4339, 4441-4442, 4543-4544, 4565-4566, 4587-4588, 4610-4611, 4632-4633, 4677-4679, 4739-4741, 4783-4785, 5088-5089): the `Gate::authorize`, `$request->validate` and `findOrFail`/`firstOrFail` calls move above the `DB::beginTransaction()`/`try`, the transaction opens after them, and the relevant `catch` is dropped (D1) — the Laravel exception handler renders the 404/403/422.
  - **Verify:** `grep -n "Gate::authorize\|->validate(\[" Modules/StudentProfile/app/Http/Controllers/StudentController.php | head -5`
  - **Expect:** the first 5 hits are all above their method's `DB::beginTransaction()` (no gate/validate inside a `try`).
  - **Effort:** M

- [ ] **STC-04** · H · ERR-06 · `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1990-2002` — stop swallowing the guardian-photo upload failure.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (canonical source — see the report Where):
    ```php
                } catch (\Exception $e) {
                    // \Log::error('Failed to upload guardian image: ' . $e->getMessage());
                }
    ```
  - **After:**
    ```php
                } catch (\Exception $e) {
                    report($e);
                    throw $e;
                }
    ```
    (The transaction's outer `catch` then rolls back the guardian update so the photo is never "saved" without a file.)
  - **Verify:** `grep -n "Failed to upload guardian image" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** only the comment removed — grep returns nothing (the commented line is gone).
  - **Effort:** S

- [ ] **STC-08** · H · TXN-01 · wrap `sendCredentials`' writes in one transaction; mail after commit.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:4463-4483`):
    ```php
            foreach ($students as $student) {
                try {
                    $plainPassword = '';

                    switch ($passwordOption) {
                        case 'existing':
                            $plainPassword = $plainPassword;
                            break;

                        case 'reset':
                            $plainPassword = Str::random(10);
                            $student->password = Hash::make($plainPassword);
                            $student->save();
                            break;
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($students, $passwordOption, $customPassword, $sendEmail) {
                foreach ($students as $student) {
                    $plainPassword = '';

                    switch ($passwordOption) {
                        case 'existing':
                            // no write; mail after commit omits the password (see STC-42)
                            break;

                        case 'reset':
                            $plainPassword = Str::random(10);
                            $student->password = Hash::make($plainPassword);
                            $student->save();
                            break;
    ```
    …and close the closure after the switch/loop; move the `Mail::to(…)->send(...)` block to AFTER the transaction (a `collect($students)->each(fn ($s) => Mail::…)` after the closure returns), so no mail is sent for rows that never committed, and every password reset is atomic.
  - **Verify:** `grep -c "DB::transaction" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 2 (startImport keeps its own; sendCredentials gains one).
  - **Effort:** M

- [ ] **STC-41** · H · deep-read — fix the export map so parent names and QR codes are real.
  - **Touches:** `Modules/StudentProfile/app/Exports/StudentsExport.php`
  - **Before** (`StudentsExport.php:152-161`):
    ```php
        if ($student->guardians) {
            foreach ($student->guardians as $guardian) {
                if ($guardian->relationship_type == 'father' || $guardian->guardian_type == 'father') {
                    $fatherName = trim($guardian->first_name . ' ' . $guardian->last_name);
                }
                if ($guardian->relationship_type == 'mother' || $guardian->guardian_type == 'mother') {
                    $motherName = trim($guardian->first_name . ' ' . $guardian->last_name);
                }
            }
        }
    ```
  - **After:**
    ```php
        if ($student->guardians) {
            foreach ($student->guardians as $guardian) {
                if ($guardian->pivot->relation_type === 'Father') {
                    $fatherName = trim($guardian->first_name . ' ' . $guardian->last_name);
                }
                if ($guardian->pivot->relation_type === 'Mother') {
                    $motherName = trim($guardian->first_name . ' ' . $guardian->last_name);
                }
            }
        }
    ```
    Also replace line 180 `$user->student_qr_code ?? 'N/A'` with `$student->student_qr_code ?? 'N/A'`.
  - **Verify:** `grep -n "pivot->relation_type" Modules/StudentProfile/app/Exports/StudentsExport.php`
  - **Expect:** 2 hits (Father, Mother).
  - **Effort:** S

- [ ] **STC-42** · M · deep-read — `sendCredentials`' `existing` branch must not email a blank password.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (canonical source — see the report Where):
    ```php
                    switch ($passwordOption) {
                        case 'existing':
                            $plainPassword = $plainPassword;
                            break;
    ```
  - **After:**
    ```php
                    switch ($passwordOption) {
                        case 'existing':
                            $plainPassword = '';
                            break;
    ```
    and in the mail step (line ~4485) only send the mail when `$plainPassword !== ''`, or pass an explicit flag so the password line is omitted for `existing`. The `StudentLoginCreated` mailable and `email.blade.php` stay unchanged (a blank password is no longer constructed).
  - **Verify:** `grep -n "plainPassword = \$plainPassword" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **STC-43** · M · TXN-06 · lock the guardian-mobile candidate so the unique-index race shows a friendly error.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:1732-1737`):
    ```php
                    // Handle New Guardian Creation
                    $existingGuardian = Guardian::where('mobile_no', $gData['mobile_no'])->first();

                    if ($existingGuardian) {
                        return redirect()->back()->withInput()->withErrors([
                            'guardian_mobile' => 'Mobile number already registered to another guardian.',
                        ]);
    ```
  - **After:**
    ```php
                    // Handle New Guardian Creation — lockForUpdate inside the open transaction prevents the
                    // uq_std_guardians_mobile race (STC-43, 2026-10-10).
                    $existingGuardian = Guardian::where('mobile_no', $gData['mobile_no'])->lockForUpdate()->first();

                    if ($existingGuardian) {
                        return redirect()->back()->withInput()->withErrors([
                            'guardian_mobile' => 'Mobile number already registered to another guardian.',
                        ]);
    ```
    (`createParentDetails` opens `DB::beginTransaction()` at line 1652, so the lock is inside a transaction already.)
  - **Verify:** `grep -n "lockForUpdate()" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 1 hit inside `createParentDetails`.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [ ] **STC-03** · M · ERR-05 · log the exception object, not the message, at all 12 log sites.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:1599-1601`, the canonical site):
    ```php
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('StudentController::toggleStatus failed', ['error' => $e->getMessage()]);
    ```
  - **After:**
    ```php
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('StudentController::toggleStatus failed', ['exception' => $e]);
    ```
  - Replace `['error' => $e->getMessage()]` with `['exception' => $e]` at lines 437, 525, 1601, 2586, 3330, 3503, 4125, 4166, 4326, 4430, 5262, 5305 (and any `'…: ' . $e->getMessage()` single-string logs at 2001/4488/4508/4526/5262/5305 with `Log::error('…', ['exception' => $e])` where the line survives STC-01/STC-04).
  - **Verify:** `grep -c "'error' => \$e->getMessage()" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 0.
  - **Effort:** S

- [ ] **STC-06** · M · TXN-02 · convert the 27 manual transaction pairs to `DB::transaction()` closures.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:1175-1179`, `updateStudentDetails` — the canonical pair):
    ```php
        DB::beginTransaction();
        try {
            $student = $this->storeStudent($request, $validated);
            $this->storeStudentProfile($request, $student->id);
    ```
  - **After:**
    ```php
        [$student, $redirect] = DB::transaction(function () use ($request, $student) {
            $student = $this->storeStudent($request, $validated);
            $this->storeStudentProfile($request, $student->id);
    ```
    …and close the closure after the method's final write, `return`ing the `$redirect` + success flash from inside the closure; delete the matching `catch`/`DB::rollBack` (D1). Apply the identical conversion to the other 26 manual pairs (lines 790/843/856-865, 890/910/916-919, 952/973/979-988, 1431/1435/1441-1444, 1579/1588/1599-1608, 1652/1852/1858-1865, 1938/2005/2011-2014, 2128/2186/2192-2200, 2312/2372/2378-2381, 2387/2394/2407-2418, 2469/2567/2584-2589, 2633/2801/2814-2817, 2970/2975/2985-2988, 3025/3035/3048-3051, 3123/3129/3139-3142, 3168/3301/3322-3339, 3354/3495/3501-3504, 3620/3625/3635-3638, 3652/3658/3668-3671, 3739/3770/3783-3786, 3803/3834/3847-3850, 3867/3879/3881-3884, 3905/3935/3942-3945, 4676/4698/4707-4712, 4738/4761/4770-4775, 4782/4823/4833-4843). `deleteStudentSession`'s `$request->ajax()` branching can return from inside the closure (`DB::transaction` returns it).
  - **Verify:** `grep -c "DB::beginTransaction()" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 0 (all converted).
  - **Effort:** L
  - **Order:** apply this item before STC-01 for the conversion sites, because this item deletes the catches on the write paths.

- [ ] **STC-07** · M · TXN-04 · put `activityLog()` inside the transaction after the write.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:1588-1592`, `toggleStatus`):
    ```php
            DB::commit();

            activityLog($student, 'Toggled', [
                'message' => 'Student and linked user status updated to ' . ($isActive ? 'Active' : 'Inactive'),
            ]);
    ```
  - **After:**
    ```php
            activityLog($student, 'Toggled', [
                'message' => 'Student and linked user status updated to ' . ($isActive ? 'Active' : 'Inactive'),
            ]);

            DB::commit();
    ```
    Move the `activityLog(...)` calls the same way in `destroy` (4698-4702), `restore` (4761-4765) and `forceDelete` (4823-4828) — the audit row becomes part of the transaction. The 22 mutators that have **no** `activityLog()` keep their current events (adding events is a behaviour decision; note it in `03-status.md`).
  - **Verify:** `sed -n '1588,1593p' Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** `activityLog(` appears before `DB::commit();`.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **STC-09** · M · AUTH-06 · DECISION — decide what the registered policies are for.
  - **Why it is a decision:** making the controller consult `StudentPolicy` changes who can open a record (record-ownership semantics); deleting the registrations changes what other modules observe.
  - (a) ⭐ Keep the string gates and delete the three policy registrations from `StudentProfileServiceProvider` (they are dead); document the record-ownership intention for the portal (StudentPortal module).
  - (b) Convert `show()`/`edit()`/`update`-family gates to model-bound `Gate::authorize('view'|'update', $student)` so `StudentPolicy::view()`'s own-record rules take effect on the web backend too (wider change; portal behaviour may shift).
  - (c) Leave as is, record as accepted.
  - ➜ Choice: ____

- [ ] **STC-10** · M · AUTH-02 · `Modules/StudentProfile/app/Http/Controllers/StudentController.php:790-792,953-954,3169-3170` — authorize before the transaction (covered by STC-02's transform for these sites; separate check that no gate call remains below a `beginTransaction`).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (canonical source — see the report Where):
    ```php
        DB::beginTransaction();
        try {
            Gate::authorize('tenant.student-profile.student.create');
    ```
  - **After:**
    ```php
        Gate::authorize('tenant.student-profile.student.create');

        DB::beginTransaction();
    ```
  - and ask the fixer to apply the same ordering at 953-954 and 3169-3170 (drop the stale `try {` when STC-06 or STC-02 removed it).
  - **Verify:** `grep -n "Gate::authorize" Modules/StudentProfile/app/Http/Controllers/StudentController.php | head -3`
  - **Expect:** the create gates at lines 356, 792, 954, 1452, 1626, 2019, 2423 are above their method's transaction or their method has none.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **STC-11** · M · VAL-02 · move the inline validation into FormRequests, starting with the login resource.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`, new `Modules/StudentProfile/app/Http/Requests/StudentLoginRequest.php`
  - **Before** (`StudentController.php:793-804`, the canonical inline array):
    ```php
            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'short_name' => 'required|string|max:30|unique:sys_users,short_name',
                'email' => 'required|email|max:150|unique:sys_users,email',
                'phone_no' => 'nullable|string|max:32',
                'mobile_no' => 'nullable|string|max:32',
                'password' => 'required|string|min:8|confirmed',
                'status' => 'required|in:ACTIVE,INVITED,DISABLED',
                'is_active' => 'nullable',
                'two_factor_auth_enabled' => 'nullable',
                'user_img' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            ]);
    ```
  - **After:** (new `StudentLoginRequest` authoritative for `createStudentLogin`; it also carries STC-12's typing)
    ```php
    <?php

    namespace Modules\StudentProfile\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Support\Facades\Gate;

    class StudentLoginRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return Gate::allows('tenant.student-profile.student.create');
        }

        public function rules(): array
        {
            return [
                'name' => ['required', 'string', 'max:255'],
                'short_name' => ['required', 'string', 'max:30', 'unique:sys_users,short_name'],
                'email' => ['required', 'email', 'max:150', 'unique:sys_users,email'],
                'phone_no' => ['nullable', 'string', 'max:32'],
                'mobile_no' => ['nullable', 'string', 'max:32'],
                'password' => ['required', 'string', 'min:8', 'confirmed'],
                'status' => ['required', 'in:ACTIVE,INVITED,DISABLED'],
                'is_active' => ['nullable', 'boolean'],
                'two_factor_auth_enabled' => ['nullable', 'boolean'],
                'user_img' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            ];
        }
    }
    ```
    then change `createStudentLogin`'s signature to `public function createStudentLogin(StudentLoginRequest $request)` and replace the inline array with `$validated = $request->validated();`. The remaining inline arrays (updateLogin, student-details+address, parent, session, previous-education, document, health, attendance, credentials, import) follow the same shape in follow-on items — the fixer creates one FormRequest per resource with the exact rules now inline and cross-field rules in an `after()` hook (VAL-07).
  - **Verify:** `grep -n "StudentLoginRequest" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 1 (the new signature) and no `$request->validate(` left in `createStudentLogin`.
  - **Effort:** L

- [ ] **STC-12** · M · VAL-05 · `Modules/StudentProfile/app/Http/Controllers/StudentController.php:801-802` — type the two booleans.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (canonical source — see the report Where):
    ```php
                'is_active' => 'nullable',
                'two_factor_auth_enabled' => 'nullable',
    ```
  - **After:**
    ```php
                'is_active' => 'nullable|boolean',
                'two_factor_auth_enabled' => 'nullable|boolean',
    ```
  - **Verify:** `grep -n "'is_active' => 'nullable|boolean'" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 1 hit (the `updateLogin` copy at 885-886 already has `|boolean`).
  - **Effort:** S

- [ ] **STC-14** · M · RTE-03 · D5-disable the ten unrouted methods.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:1542-1546`, `trashedStudent` — the canonical):
    ```php
    public function trashedStudent()
    {
        Gate::authorize('tenant.student-profile.student.delete');
        $students = User::onlyTrashed()->role('Student')->paginate(10);
        return view('studentprofile::student.trash', compact('students'));
    ```
  - **After:**
    ```php
    public function trashedStudent()
    {
        // NOT ROUTED — D5 (final-audit). Kept as a dead method per the protocol.
        abort(403, 'Not routed.');
    ```
    Apply the identical body to `store` (366-368), `update` (1611-1613), `showAttendance` (3709), `scanQrAttendance` (3725), `manualAttendance` (3789), `requestAttendanceCorrection` (3853), `bulkClassAttendance` (3887), `getStudentsByClass` (3948), `getTodayAttendance` (3964). The dead private helpers they call stay (CTL-10 note).
  - **Verify:** `grep -c "NOT ROUTED" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 10.
  - **Effort:** S

- [ ] **STC-17** · M · CTL-03 · use route model binding on the 19 scalar-parameter methods.
  - **Touches:** `Modules/StudentProfile/routes/web.php`, `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:2384-2389`, `deleteStudentSession` — canonical):
    ```php
    public function deleteStudentSession(Request $request, $sessionId)
    {
        Gate::authorize('tenant.student-profile.student.update');
        DB::beginTransaction();
        try {
            $session = StudentAcademicSession::findOrFail($sessionId);
    ```
  - **After:**
    ```php
    public function deleteStudentSession(Request $request, StudentAcademicSession $session)
    {
        Gate::authorize('tenant.student-profile.student.update');

        DB::beginTransaction();
        try {
            $sessionId = $session->id;
    ```
    (keep the method's body; the `findOrFail` line is deleted because binding already 404s.) Apply the same to `updateParentDetails(Guardian $guardian)` (with route param `parent` renamed via `->where` or method name kept), `createStudentSession`/`updateStudentSession` (StudentAcademicSession), `createStudentPrevEduDetails`/`updatePreviousEducation`/`deletePreviousEducation` (PreviousEducation), `updateStudentDocument`/`deleteStudentDocument` (StudentDocument), `deleteVaccinationRecord` (VaccinationRecord), `deleteMedicalIncident` (MedicalIncident), the five `get*Data` methods and `destroy`/`restore`/`forceDelete` (Student::class, `->withTrashed()` on restore/forceDelete).
  - **Verify:** `grep -c "findOrFail(" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 0.
  - **Effort:** M

- [ ] **STC-24** · M · MDL-07 · model the `deleted_at`/timestamps columns the tables already have.
  - **Touches:** `Modules/StudentProfile/app/Models/StudentDocument.php`, `Modules/StudentProfile/app/Models/StudentHealthProfile.php`, `Modules/StudentProfile/app/Models/VaccinationRecord.php`
  - **Before** (`StudentDocument.php:15-19`):
    ```php
    class StudentDocument extends Model implements HasMedia
    {
        use HasFactory, InteractsWithMedia;

        protected $table = 'std_student_documents';
    ```
  - **After:**
    ```php
    class StudentDocument extends Model implements HasMedia
    {
        use HasFactory, SoftDeletes, InteractsWithMedia;

        protected $table = 'std_student_documents';
    ```
    (`use Illuminate\Database\Eloquent\SoftDeletes;` added to the imports.) In `StudentHealthProfile` and `VaccinationRecord` remove the `public $timestamps = false;` lines so the models fill the `created_at`/`updated_at` columns (both tables already define `$table->timestamps()`; no migration).
  - **Verify:** `grep -n "SoftDeletes" Modules/StudentProfile/app/Models/StudentDocument.php && grep -n "timestamps = false" Modules/StudentProfile/app/Models/StudentHealthProfile.php Modules/StudentProfile/app/Models/VaccinationRecord.php`
  - **Expect:** `SoftDeletes` present in StudentDocument; no `timestamps = false` output for the two health files.
  - **Effort:** S

- [ ] **STC-25** · M · MDL-02 · cast `Guardian::$is_active`.
  - **Touches:** `Modules/StudentProfile/app/Models/Guardian.php`
  - **Before** (`Guardian.php:26-28`):
    ```php
    protected $casts = [
        'annual_income' => \App\Casts\SafeEncrypted::class,
    ];
    ```
  - **After:**
    ```php
    protected $casts = [
        'annual_income' => \App\Casts\SafeEncrypted::class,
        'is_active' => 'boolean',
    ];
    ```
  - **Verify:** `grep -n "'is_active' => 'boolean'" Modules/StudentProfile/app/Models/Guardian.php`
  - **Expect:** 1 hit.
  - **Effort:** S

- [ ] **STC-36** · M · SEC-03 · fail loudly instead of substituting magic ids.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`, `Modules/StudentProfile/app/Imports/StudentImport.php`
  - **Before** (`StudentController.php:4267`):
    ```php
                            'study_format_id' => $ssf?->id ?? 1,
    ```
  - **After:**
    ```php
                            'study_format_id' => $ssf?->id,
    ```
    (a null study format then throws a typed error at insert, surfacing the misconfiguration instead of silently writing `1`.) In `StudentImport.php` replace `?? 7`, `?? 92`, `?? 619` (lines 45, 51, 57) with `->value('id')` (no fallback) so a tenant without the seed rows fails the import loudly before a single row is written (the import runs inside a transaction).
  - **Verify:** `grep -n "?? \(1\|7\|92\|619\)" Modules/StudentProfile/app/Http/Controllers/StudentController.php Modules/StudentProfile/app/Imports/StudentImport.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **STC-27** · M · SVC-04 · import enrollments through the model so the count observers fire.
  - **Touches:** `Modules/StudentProfile/app/Imports/StudentImport.php`
  - **Before** (`StudentImport.php:267-278`):
    ```php
                        DB::table('std_student_academic_sessions')->insert([
                            'student_id'          => $student->id,
                            'academic_session_id' => $sessionId,
                            'class_section_id'    => $classSection->id,
                            'is_current'          => 1,
                            'session_status_id'   => $sessionStatusId,
                            'count_for_timetable' => 1,
                            'count_as_attrition'  => 0,
                            'dis_note'            => 'Imported via Excel',
                            'created_at'          => now(),
                            'updated_at'          => now(),
                        ]);
    ```
  - **After:**
    ```php
                        \Modules\StudentProfile\Models\StudentAcademicSession::create([
                            'student_id'          => $student->id,
                            'academic_session_id' => $sessionId,
                            'class_section_id'    => $classSection->id,
                            'is_current'          => 1,
                            'session_status_id'   => $sessionStatusId,
                            'count_for_timetable' => 1,
                            'count_as_attrition'  => 0,
                            'dis_note'            => 'Imported via Excel',
                        ]);
    ```
    (the model now writes `created_at`/`updated_at` and fires the `created` observer that refreshes `sch_class_section_jnt.actual_total_student`.)
  - **Verify:** `grep -c "StudentAcademicSession::create" Modules/StudentProfile/app/Imports/StudentImport.php`
  - **Expect:** 1, and `grep -c "DB::table('std_student_academic_sessions')"` → 0.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **STC-28** · H · QRY-01 · stop per-row queries in loops (N+1).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`, `Modules/StudentProfile/app/Imports/StudentImport.php`
  - **Before** (`StudentController.php:1732-1733`, `createParentDetails` — canonical):
    ```php
                    // Handle New Guardian Creation
                    $existingGuardian = Guardian::where('mobile_no', $gData['mobile_no'])->first();
    ```
  - **After:**
    ```php
                    // Handle New Guardian Creation — pre-fetched mobile map (STC-28, 2026-10-10).
                    $existingGuardian = $guardianMobileMap[$gData['mobile_no']] ?? null;
    ```
    where `$guardianMobileMap = Guardian::whereIn('mobile_no', $request->input('guardians.*.mobile_no'))->get()->keyBy('mobile_no');` is built once before the loop. The remaining per-row lookups in `updateStudentDetails` (1200), `storeStudentAddress` (1389), `createParentDetails` (1682/1695/1712/1715), `updatePreviousEducation` (2771), `createStudentMedicalDetails` (3279), `updateHealthProfile` (3403/3453), `bulkClassAttendance` (3911), `getSubjectGroupSubjects` (4104), `getStreamSubjects` (4207/4261/4282/4285), `validateImport` (5164/5178) and `StudentImport` (105/111/211) get the same one-lookup-per-batch treatment: pre-fetch with `whereIn` + `keyBy`/`pluck` before each loop.
  - **Verify:** `grep -nE "::(find|where)\(.*\)->(first|get)\(\)|\$guardianMobileMap" Modules/StudentProfile/app/Http/Controllers/StudentController.php | head -4`
  - **Expect:** the `guardianMobileMap` keyed lookup present; no `Guardian::where(...)->first()` remains inside a `foreach`.
  - **Effort:** L

- [ ] **STC-29** · M · QRY-07 · bulk-write per-row creates.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:2158-2179`, opted-subject sync — canonical):
    ```php
                // Sync opted subjects
                StudentOptedSubject::where('student_academic_session_id', $session->id)->delete();

                if (!empty($validated['opted_subjects'])) {
                    $processedSubjects = [];
                    foreach ($validated['opted_subjects'] as $optSubject) {
                        $subId = $optSubject['subject_id'];
                        if (in_array($subId, $processedSubjects)) {
                            continue;
                        }
                        $processedSubjects[] = $subId;

                        StudentOptedSubject::create([
    ```
  - **After:**
    ```php
                // Sync opted subjects
                StudentOptedSubject::where('student_academic_session_id', $session->id)->delete();

                $rows = [];
                if (!empty($validated['opted_subjects'])) {
                    $processedSubjects = [];
                    foreach ($validated['opted_subjects'] as $optSubject) {
                        $subId = $optSubject['subject_id'];
                        if (in_array($subId, $processedSubjects)) {
                            continue;
                        }
                        $processedSubjects[] = $subId;

                        $rows[] = [
                            'student_academic_session_id' => $session->id,
                            'subject_group_id' => $session->subject_group_id,
                            'subject_id' => $optSubject['subject_id'],
                            'study_format_id' => $optSubject['study_format_id'],
                            'subject_study_format_options_id' => $optSubject['subject_study_format_options_id'] ?? null,
                            'is_optional' => (int) ($optSubject['is_optional'] ?? 0),
                            'created_at' => now(),
                            'updated_at' => now(),
                        ];
                    }
                    StudentOptedSubject::insert($rows);
                }
    ```
    The other per-row write loops (updateStudentSession 2351, documents 2540/2773/2783, vaccinations 3281/3285/3408/3412, incidents 3458/3462, parent users/guardians 1691/1698/1721/1741/1761/1796/1849, attendance 3911/3918, credentials 4475/4481) get the same chunked-`insert()`/`whereIn()->update()` treatment.
  - **Verify:** `grep -c "StudentOptedSubject::insert" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 2 (create + update session), and `grep -c "StudentOptedSubject::create"` → 0.
  - **Effort:** L

- [ ] **STC-30** · M · QRY-15 · pluck `id/name` instead of loading whole reference tables.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:253`, canonical):
    ```php
        $academicSessions = OrganizationAcademicSession::orderBy('start_date', 'desc')->get();
    ```
  - **After:**
    ```php
        $academicSessions = OrganizationAcademicSession::orderBy('start_date', 'desc')->get(['id', 'name', 'start_date']);
    ```
    Apply `->get([...only the columns the blade uses...])` (or `->pluck('name', 'id')`) to the `OrganizationAcademicSession` loads (698, 1480), `Student::with('user')->get()` → `pluck` id/name/admission_no (1481-1488), `Guardian::with('media')->get()` → pluck id/first_name/last_name (716, 1491), `User::where('is_active',1)->get()` → pluck id/name (700, 1476), `ClassSection::…->get()` (695, 1478) and `SubjectGroup::…->get()` (699, 1479).
  - **Verify:** `grep -n "get(\['id'\|pluck(" Modules/StudentProfile/app/Http/Controllers/StudentController.php | head -5`
  - **Expect:** no bare `->get()` feeding the edit/create wizard except deliberate full use.
  - **Effort:** M

- [ ] **STC-31** · L · QRY-08 · drop the leading wildcard on name/admission searches.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:121`):
    ```php
                    $q->where('admission_no', 'like', "%{$search}%")
    ```
  - **After:**
    ```php
                    $q->where('admission_no', 'like', "{$search}%")
    ```
    Apply the same to the other 9 LIKE lines in `index` (122-130), the export block (4931-4939) and `getStreamSubjects` (4254-4263).
  - **Verify:** `grep -c '"like", "%{\$search}%"' Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 0.
  - **Effort:** S

- [ ] **STC-32** · M · QRY-05 · sort/dedupe sections in SQL.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:3990-4008`, sections block):
    ```php
            if ($classId) {
                $sections = ClassSection::where('class_id', $classId)
                    ->where('is_active', true)
                    ->with(['section' => function ($q) {
                        $q->select('id', 'name', 'ordinal');
                    }])
                    ->get()
                    ->sortBy(function ($jnt) {
                        return [$jnt->section?->ordinal ?? 9999, $jnt->section?->name ?? ''];
                    })
                    ->map(function ($jnt) {
                        return [
                            'id' => $jnt->section_id,
                            'class_section_id' => $jnt->id,
                            'name' => $jnt->section?->name ?? 'N/A',
                        ];
                    })
                    ->unique('id')
                    ->values();
            } else {
    ```
  - **After:**
    ```php
            if ($classId) {
                $sections = ClassSection::where('class_id', $classId)
                    ->where('is_active', true)
                    ->join('sch_sections', 'sch_sections.id', '=', 'sch_class_section_jnt.section_id')
                    ->select('sch_class_section_jnt.id as class_section_id', 'sch_class_section_jnt.section_id as id', 'sch_sections.name')
                    ->orderBy('sch_sections.ordinal')
                    ->orderBy('sch_sections.name')
                    ->get()
                    ->unique('id')
                    ->values();
            } else {
    ```
  - **Verify:** `grep -c "sortBy" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 0 in this method (no PHP-side sort in `getFilterDependencies`).
  - **Effort:** S

- [ ] **STC-33** · L · QRY-02 · paginate at 10 like every other list.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:191`):
    ```php
        $students = $studentsQuery->orderBy('id')->paginate(12, ['*'], 'students_page')->withQueryString();
    ```
  - **After:**
    ```php
        $students = $studentsQuery->orderBy('id')->paginate(10, ['*'], 'students_page')->withQueryString();
    ```
    and the same `12` → `10` on line 251 (`missing_page`).
  - **Verify:** `grep -c "paginate(12" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 0.
  - **Effort:** S

- [ ] **STC-34** · M · QRY-12 · DECISION — cache the wizard's dictionary dropdowns per tenant?
  - **Why it is a decision:** adding a cache is a DECISION item (§7; the cache keys must carry the tenant id — TEN-02), and it changes when admin dropdown edits show up.
  - (a) ⭐ Memoise once per request (a small `Dropdown::forKeys([...])` private helper used by `edit`/`editStudentDetails`/`index`) — no cache invalidation problem, immediate win.
  - (b) Add a `Cache::remember` with a tenant-scoped key (`"student_dropdowns_{".tenancy()->tenant->id."}"`) and a clear-tag on dropdown writes (touches other modules' dropdown update path).
  - (c) Leave as is; the 14 queries per page are acceptable at this tenant size.
  - ➜ Choice: ____

- [ ] **STC-35** · M · SEC-04 · stop logging the whole request body in `getFilterDependencies`.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:3982-3983`):
    ```php
        try {
            \Log::info('getFilterDependencies request', $request->all());
    ```
  - **After:**
    ```php
        try {
            // debug-only line removed (SEC-04, STC-35 2026-10-10)
    ```
  - **Verify:** `grep -n "getFilterDependencies request" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

None — the 29 student blades compile and contain no queries.

## 8. Style (F12) — one item per file

- [ ] **STC-37** · L · STY-06 · `\Log::` → `Log::` (14 sites).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:2001`):
    ```php
                    // \Log::error('Failed to upload guardian image: ' . $e->getMessage());
    ```
    *(the live `\Log::` sites are at 2586, 3330, 3503, 3983, 4071, 4125, 4166, 4326, 4430, 4507, 4527, 5262, 5305)*
  - **After:** (for each live `\Log::` site)
    ```php
                    Log::error('Failed to upload guardian image: ' . $e->getMessage());
    ```
  - **Verify:** `grep -c '\\Log::' Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 0.
  - **Effort:** S

- [ ] **STC-38** · L · STY-04 · drop emoji from `sendCredentials` messages and translate the helper comments.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`, `Modules/StudentProfile/app/Helpers/StudentProfileHelper.php`
  - **Before** (`StudentController.php:4488-4490`):
    ```php
                            $results[] = "✓ Email sent to {$student->name} ({$student->email})";
                        } catch (\Exception $e) {
                            $results[] = "✗ Failed to send email to {$student->name}: " . $e->getMessage();
    ```
  - **After:**
    ```php
                            $results[] = "Email sent to {$student->name} ({$student->email})";
                        } catch (\Exception $e) {
                            $results[] = "Failed to send email to {$student->name}: " . $e->getMessage();
    ```
    and translate `StudentProfileHelper.php:36,41` comments ("agar data hai to completed" → "if data exists, the tab counts as completed").
  - **Verify:** `grep -c '✓\|✗' Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 0.
  - **Effort:** S

- [ ] **STC-39** · L · STY-01 · add `declare(strict_types=1);` to the audited files when touched.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`, `Modules/StudentProfile/app/Models/Guardian.php`, `Modules/StudentProfile/app/Models/StudentAddress.php`, `Modules/StudentProfile/app/Models/StudentAcademicSession.php`, `Modules/StudentProfile/app/Models/StudentDocument.php`, `Modules/StudentProfile/app/Models/StudentGuardianJnt.php`, `Modules/StudentProfile/app/Models/StudentHealthProfile.php`, `Modules/StudentProfile/app/Models/StudentOptedSubject.php`, `Modules/StudentProfile/app/Models/PreviousEducation.php`, `Modules/StudentProfile/app/Models/StudentAttendanceCorrection.php`, `Modules/StudentProfile/app/Models/VaccinationRecord.php`, `Modules/StudentProfile/app/Policies/GuardianPolicy.php`, `Modules/StudentProfile/app/Policies/StudentDocumentPolicy.php`, `Modules/StudentProfile/app/Policies/StudentPolicy.php`, `Modules/StudentProfile/app/Http/Requests/PrintIdCardsRequest.php`
  - **Before** (`StudentController.php:1-2`, canonical for every listed file):
    ```php
    <?php

    namespace Modules\StudentProfile\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Http\Controllers;
    ```
  - **Verify:** `head -3 Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** line 3 is `declare(strict_types=1);`.
  - **Effort:** S

- [ ] **STC-40** · L · STY-02 · run Pint on the controller after the behavioural items.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** — the file currently fails `vendor/bin/pint --test` (20 fixers); the fixer runs `vendor/bin/pint Modules/StudentProfile/app/Http/Controllers/StudentController.php --format agent` (never `--dirty`) after applying the ticked items, then `php -l` and `vendor/bin/pint --test` again. The Pint fix is formatter output, not hand-edited code; the example block below is the opening that Pint rewrites.
    ```php
    <?php

    namespace Modules\StudentProfile\Http\Controllers;
    ```
  - **After:** Pint writes PSR-12 output for the whole file; the opening stays:
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Http\Controllers;
    ```
  - **Verify:** `vendor/bin/pint --test Modules/StudentProfile/app/Http/Controllers/StudentController.php 2>&1 | head -c 20`
  - **Expect:** `{"tool":"pint","result":"pass"...`
  - **Effort:** S

- [ ] **STC-18** · L · CTL-04 · add return types to the public methods as the STC-02/06/17 edits touch them.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:68`, canonical):
    ```php
    public function index(Request $request)
    {
        Gate::authorize('tenant.student-profile.student.viewAny');
    ```
  - **After:**
    ```php
    public function index(Request $request): View
    {
        Gate::authorize('tenant.student-profile.student.viewAny');
    ```
    (`use Illuminate\Contracts\View\View;` added; each redirect method gets `: RedirectResponse`, JSON methods `: JsonResponse` with `use Illuminate\Http\JsonResponse;`.)
  - **Verify:** `grep -cE "public function [a-zA-Z_]+\([^)]*\): (View|RedirectResponse|JsonResponse|Response)" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** ≥ 40 (all touched methods typed).
  - **Effort:** L

- [ ] **STC-19** · L · CTL-07 · replace the 34/32/20-var `compact()` calls with a view-model array.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:316-318`, canonical):
    ```php
        return view('studentprofile::student.index', compact(
            'students',
            'missingStudents',
    ```
  - **After:**
    ```php
        return view('studentprofile::student.index', [
            'students' => $students,
            'missingStudents' => $missingStudents,
    ```
    (complete the array for all 34 variables by keeping them in the same order as today's `compact()` list; same conversion for `edit` 732 and `editStudentDetails` 1503.)
  - **Verify:** `grep -c "compact(" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 0.
  - **Effort:** M

- [ ] **STC-22** · L · CTL-08 · inject `Request` instead of the `request()` helper.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Before** (`StudentController.php:444`):
    ```php
        $layout = request()->query('layout') === 'sheet' ? 'sheet' : 'card';
    ```
  - **After:**
    ```php
        $layout = $request->query('layout') === 'sheet' ? 'sheet' : 'card';
    ```
    (change the signatures to `printIdCard(Request $request, Student $student)` and `export(Request $request, $type)`, and rewrite `export`'s eight `request('…')` reads at 4892-4899 to `$request->input('…')`.)
  - **Verify:** `grep -c "request()" Modules/StudentProfile/app/Http/Controllers/StudentController.php`
  - **Expect:** 0.
  - **Effort:** S

- [ ] **STC-26** · L · MDL-04 · add relationship return types in the ten pre-assigned models.
  - **Touches:** `Modules/StudentProfile/app/Models/Guardian.php`, `Modules/StudentProfile/app/Models/StudentAddress.php`, `Modules/StudentProfile/app/Models/StudentAcademicSession.php`, `Modules/StudentProfile/app/Models/StudentDocument.php`, `Modules/StudentProfile/app/Models/StudentGuardianJnt.php`, `Modules/StudentProfile/app/Models/StudentHealthProfile.php`, `Modules/StudentProfile/app/Models/StudentOptedSubject.php`, `Modules/StudentProfile/app/Models/PreviousEducation.php`, `Modules/StudentProfile/app/Models/StudentAttendanceCorrection.php`, `Modules/StudentProfile/app/Models/VaccinationRecord.php`
  - **Before** (`Guardian.php:68-76`, canonical):
    ```php
    public function students()
    {
        return $this->belongsToMany(
            Student::class,
            'std_student_guardian_jnt',
            'guardian_id',
            'student_id'
        );
    }
    ```
  - **After:**
    ```php
    public function students(): \Illuminate\Database\Eloquent\Relations\BelongsToMany
    {
        return $this->belongsToMany(
            Student::class,
            'std_student_guardian_jnt',
            'guardian_id',
            'student_id'
        );
    }
    ```
    (each relation in each model gets its matching `: BelongsTo` / `: HasMany` / `: BelongsToMany` return type; `use` the relation classes where the file already imports them, or use fully-qualified names.)
  - **Verify:** `grep -c ": \Illumate\|: \\Illuminate" Modules/StudentProfile/app/Models/Guardian.php` — use instead `grep -cE "): (BelongsTo|HasMany|BelongsToMany)" Modules/StudentProfile/app/Models/Guardian.php`
  - **Expect:** ≥ 3 (user, students, preferredLanguage) in Guardian; every relation across the ten files typed.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **STC-15** · H · DECISION · CTL-01 — split this 5,500-line controller? (D3 — never applied this pass).
  - **Why it is a decision:** god-controller split, deferred by D3; touches routes, menus and five controller reports.
  - (a) ⭐ Defer to a dedicated split pass; this plan only fixes in place.
  - (b) Plan the split now into `StudentCrudController`, `StudentGuardianController`, `StudentSessionController`, `StudentDocumentController`, `StudentHealthController`, `StudentImportExportController`, `StudentPrintController` (routes/menus change — later pass).
  - (c) Leave as one file, record as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| STC-16 | The method-length extraction is delivered in two places: the concrete shared-flow extraction is STC-20's item, and the full split is the deferred STC-15 DECISION. No separate item. |
| STC-21 | The dead code removal rides on the other items in the same file: the empty `store`/`update` stubs and `trashedStudent` become D5 `abort(403)` bodies under STC-14, and the commented-out method blocks are resolved by the STC-13 DECISION. `cleanOldInput()` (never called) is deleted in the STC-14 item's same-file edit. No separate item. |