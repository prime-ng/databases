# Final Audit — StudentProfile / StudentProfileController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php` (70 lines, 7 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `api/v1/studentprofiles` (GET, POST) and `api/v1/studentprofiles/{studentprofile}` (GET, PUT/PATCH, DELETE) — Sanctum-authenticated API endpoints. There is NO web screen behind this controller; the web menu item "Student Profile" (`student-profile.student.index`) points at `StudentController`, not this controller. |
| Menu path | Student Mgmt. (menu id 52) → Student Profile & Leave Mgmt. (id 64) → Student Profile (id 66) → `student-profile.student.index`, which is a different controller. Nothing in the menu reaches `StudentProfileController`. |
| Who uses it | The five permission strings are seeded and granted to exactly 2 roles: Super Admin and School Admin. Any caller must also hold a valid Sanctum bearer token. |
| What a user does here | Currently nothing useful. `index` returns the shared module landing blade, `store`/`update`/`destroy` return an empty 200 without writing a single row, and `show` renders a blade that does not exist. This is untouched nwidart scaffold (the file `Modules/StudentProfile/routes/api.php` registers `apiResource('studentprofiles', ...)` exactly as the module generator creates it). |
| Tables written | none — the three write endpoints perform no SQL at all |
| Tables read | none by the controller; the model reads `std_student_profiles` (and `sys_dropdown_table` through the `Dropdown` relations) |
| Live data | `std_student_profiles` = 1,825 rows live, 0 trashed (tenant `xyz_school_00000000000040008000_202627` on test.localhost); `std_students` = 1,825 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. This controller is the untouched output of the module generator: the API resource it serves has no tenancy middleware, three of its five routed methods silently succeed without writing anything, and the routed `show()` returns a Blade view that does not exist, so it 500s. The single worst finding is the cross-tenant media leak in the pre-assigned model `StudentProfile` (SPR-06, B): it implements Spatie `InteractsWithMedia` without overriding `getMediaModel()`, so any upload attached to a profile row lands in the central `prime_db.sys_media` instead of the tenant database. The training-wheel fix for the whole controller is one decision (SPR-02: implement the API or disable it as scaffold) plus two mechanical D5-body fixes and three low items. Rough effort: S (under an hour for the mechanical items; the decision option (b) "implement" is a small feature build).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 3 | 1 | 4 | 1 | 9 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | SPR-02 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean (no write exists — SPR-02) | F9 Queries/Perf | clean |
| F3 Authorization | clean (routed methods gate; create/edit → SPR-01) | F10 Views | SPR-03 |
| F4 Validation | clean (no write validates — moot until SPR-02) | F11 Security/Tenancy | SPR-06, SPR-04 |
| F5 Routes | SPR-01, SPR-04 | F12 Style | SPR-08, SPR-09 |
| F6 Controller shape | SPR-05 (+CTL-10 root of SPR-02/SPR-03) | F13 Deep read | SPR-02 (F13 #8 dead features) |
| F7 Models | SPR-06, SPR-07 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php` | controller | 70 | this report | ✅ |
| 2 | `Modules/StudentProfile/app/Models/StudentProfile.php` | model | 117 | this report (pre-assigned) | ✅ |
| 3 | `Modules/StudentProfile/routes/api.php` | routes | 9 | this report | ✅ |
| 4 | `Modules/StudentProfile/app/Models/Student.php` | model (relation target) | — | ↗ [gaurav/StudentProfile/StudentReportController](../StudentReportController-done/01-report.md) | ↗ linked (usage only) |
| 5 | `Modules/SystemConfig/app/Models/Dropdown.php` | model (relation target) | — | common §4.2 — different module, shared lookup | ↗ linked (usage only) |
| 6 | `Modules/StudentProfile/resources/views/index.blade.php` | view | 33 | this report (rendered by `index`) | ✅ |
| 7 | `Modules/StudentProfile/resources/views/student-settings/index.blade.php` | view (include) | — | ↗ AttendanceController report renders it with data | ↗ linked (usage check) |
| 8 | `Modules/StudentProfile/resources/views/medical-incident/index.blade.php` | view (include) | — | ↗ MedicalIncidentController report renders it with data | ↗ linked (usage check) |
| 9 | `Modules/StudentProfile/resources/views/show.blade.php`, `create.blade.php`, `edit.blade.php` | views | — | **do not exist** — see SPR-03 | ❌ missing files |

No pre-applied files (no `PRE-APPLIED-*.md` exists for the StudentProfile module).

## 4. Routes

```
GET|HEAD   api/v1/studentprofiles                                  api.studentprofile.index                      Modules\StudentProfile\Http\Controllers\StudentProfileController@index
POST       api/v1/studentprofiles                                  api.studentprofile.store                      Modules\StudentProfile\Http\Controllers\StudentProfileController@store
GET|HEAD   api/v1/studentprofiles/{studentprofile}                 api.studentprofile.show                       Modules\StudentProfile\Http\Controllers\StudentProfileController@show
PUT|PATCH  api/v1/studentprofiles/{studentprofile}                 api.studentprofile.update                     Modules\StudentProfile\Http\Controllers\StudentProfileController@update
DELETE     api/v1/studentprofiles/{studentprofile}                 api.studentprofile.destroy                    Modules\StudentProfile\Http\Controllers\StudentProfileController@destroy
```

All five routes carry exactly this middleware stack (read from the already-run scan's route list):
```
['api', 'Illuminate\Auth\Middleware\Authenticate:sanctum']
```

Unrouted public methods: `create()` (`StudentProfileController.php:24`), `edit()` (`StudentProfileController.php:50`). `apiResource` never registers `create`/`edit` routes.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 14 | GET api/v1/studentprofiles | `tenant.student-profile.student.viewAny` | none | none | none | SPR-03 (view needs data never passed) |
| `create` | 24 | NOT ROUTED | none | none | none | none | SPR-01 |
| `store` | 32 | POST api/v1/studentprofiles | `tenant.student-profile.student.create` | none | none | none (no-op) | SPR-02 |
| `show` | 40 | GET api/v1/studentprofiles/{studentprofile} | `tenant.student-profile.student.view` | none | none | none | SPR-03 (missing view → 500) |
| `edit` | 50 | NOT ROUTED | none | none | none | none | SPR-01 |
| `update` | 58 | PUT/PATCH api/v1/studentprofiles/{studentprofile} | `tenant.student-profile.student.update` | none | none | none (no-op) | SPR-02 |
| `destroy` | 66 | DELETE api/v1/studentprofiles/{studentprofile} | `tenant.student-profile.student.delete` | none | none | none (no-op) | SPR-02 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try \{|catch \(|getMessage|withErrors'` on the controller AND the model → no output (only `Gate::authorize` lines exist; the central handler in `bootstrap/app.php` renders 500s, so the missing view in SPR-03 surfaces as a JSON 500, not a swallowed error).

#### SPR-02 · H · ERR-06 — `store()`, `update()` and `destroy()` respond success but write nothing

| Field | Value |
|---|---|
| **Rule** | ERR-06 (H) — *no swallowed failures in write paths*: a write path that continues as if the write succeeded |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:32-35` (`store()`), `:58-61` (`update()`), `:66-69` (`destroy()`) |
| **Root cause** | Unimplemented generator scaffold. Each body ends immediately after `Gate::authorize(...)`, so the method returns `null` and Laravel answers HTTP 200 with an empty body — no insert, no update, no (soft) delete, no audit row, no transaction. |
| **Consequence** | Any client that calls `POST`/`PUT`/`DELETE` on `api/v1/studentprofiles` is told the operation succeeded while `std_student_profiles` is untouched — the caller's data silently disappears from their point of view. |
| **Reproduce** | Static — `sed -n '32,35p'` shows the body ends at the Gate line; `grep -cE '::(where|find|all|get|first|count)\b|DB::'` on the controller returns `0`, so no SQL can run. (Firing the request needs a Sanctum token — D4.) |
| **Fix approach** | One coherent choice covers all three plus reads (SPR-03/04/05): either implement a real tenant write path (`DB::transaction` + `activityLog`, FormRequest, tenancy middleware) or disable the scaffold exactly as D5 does for unrouted methods. See DECISION SPR-02 in `02-fix-plan.md` §9. |
| **Plan item** | SPR-02 in `02-fix-plan.md` §9 |

```php
    public function store(Request $request)
    {
        Gate::authorize('tenant.student-profile.student.create');
    }
```

**Evidence**
```
$ sed -n '32,35p' Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php
    public function store(Request $request)
    {
        Gate::authorize('tenant.student-profile.student.create');
    }
$ sed -n '66,69p' Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php
    public function destroy($id)
    {
        Gate::authorize('tenant.student-profile.student.delete');
    }
```

### F2 — Transactions and audit

clean — `grep -nE 'DB::transaction|beginTransaction|activityLog|->save\(|->update\(|->create\(|->delete\('` on the controller → no output. There are no writes at all; the write endpoints that SHOULD touch `std_student_profiles` are the no-ops of SPR-02. The tables each mutation SHOULD touch: `store` → `std_student_profiles` (+ `sys_activity_logs` if audited); `update` → `std_student_profiles`; `destroy` → `std_student_profiles` (soft delete).

### F3 — Authorization

clean — every ROUTED method authorizes before doing anything else, the strings follow `scope.module.feature.action`, they exist in `config/permissionslist.php` under key `student-profile.student` (`$crud` expands to `create, view, viewAny, update, delete, restore, forceDelete`), and all five are seeded with an exact-name match: `perm_rows=1 roles=2` for each. `create()`/`edit()` have no Gate, but they are unrouted — that is RTE-03 (SPR-01), not AUTH-01. Duplicates (AUTH-04): none — no FormRequest re-checks the same permission.

### F4 — Validation and input

clean-with-note — `store()` and `update()` receive a `$request` but read nothing and validate nothing; no FormRequest exists for this controller (`Modules/StudentProfile/app/Http/Requests/` holds only `PrintIdCardsRequest` and `StudentLeaveTypeRequest`). VAL rules are moot while the endpoints write nothing; the moment SPR-02 option (b) implements a write, a FormRequest becomes mandatory. That is recorded inside the SPR-02 decision, not as a separate finding.

### F5 — Routes

#### SPR-01 · M · RTE-03 — `create()` and `edit()` are public but unrouted (and unguarded)

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or deliberately disabled* (`abort(403)`, per D5) |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:24-27` and `:50-53`, methods `create()`, `edit()` |
| **Root cause** | Generator scaffold. `apiResource` registers only index/store/show/update/destroy; `create`/`edit` were left in the class without a route and without a Gate. |
| **Consequence** | Two dead, unguarded public methods sit in a shipped controller; if anyone later wires a web route to them, they render HTML with zero authorization. |
| **Reproduce** | Static only — a browser/HTTP hit on any URL that matches `create`/`edit` under `api/` gives 404 before the controller (no route exists). |
| **Fix approach** | D5 is binding: replace both bodies with `abort(403, 'Student profile scaffold — NOT ROUTED')` and a `// NOT ROUTED` comment. Keep the methods. |
| **Plan item** | SPR-01 in `02-fix-plan.md` §5 |

```php
    public function create()
    {
        return view('studentprofile::create');
    }
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+' Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php
14:    public function index()
24:    public function create()
32:    public function store(Request $request)
40:    public function show($id)
50:    public function edit($id)
58:    public function update(Request $request, $id)
66:    public function destroy($id)
```

#### SPR-04 · H · RTE-05 — the API resource group carries no tenancy middleware

| Field | Value |
|---|---|
| **Rule** | RTE-05 (H) — *every tenant route sits inside the auth + tenancy middleware group* |
| **Where** | `Modules/StudentProfile/routes/api.php:5-7`, the `apiResource` registration |
| **Root cause** | The generator-created `routes/api.php` wraps the resource in `['auth:sanctum']` only. The rest of the app's tenant APIs (e.g. `Modules/SchoolSetup/routes/api.php:17`) use `['mobile.key', 'tenant.mobile', 'auth:sanctum']`; `bootstrap/app.php` even documents that `tenant.mobile` must run before `auth:sanctum` because Sanctum looks up `personal_access_tokens` in the tenant database. |
| **Consequence** | With no `tenant.mobile` (an `InitializeTenancyByMobileHeader` alias) the request reaches `auth:sanctum` without tenant context, so a real school's token cannot be found — every call 401s; a central token that did pass would resolve no tenant for the request. |
| **Reproduce** | Static — the middleware stack for all five routes is exactly `['api', 'Illuminate\Auth\Middleware\Authenticate:sanctum']` (read from `/tmp/fa-routes.json`); no tenancy initializer anywhere in the stack. |
| **Fix approach** | Only coherent if SPR-02 chooses "implement". Add the mobile middlewares to the group (or move the resource into the module's `mobile_api.php` pattern). Route-file change per §9.3 — recorded in the SPR-02 decision and in §10. |
| **Plan item** | none — see plan §10 |

```php
Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('studentprofiles', StudentProfileController::class)->names('studentprofile');
});
```

**Evidence**
```
$ python3 - <<'EOF'
import json
r=json.load(open('/tmp/fa-routes.json'))
for x in r:
    if 'StudentProfileController@' in x.get('action',''):
        print(x['method'], x['uri'], '|', x.get('middleware'))
EOF
GET|HEAD api/v1/studentprofiles | ['api', 'Illuminate\\Auth\\Middleware\\Authenticate:sanctum']
POST api/v1/studentprofiles | ['api', 'Illuminate\\Auth\\Middleware\\Authenticate:sanctum']
GET|HEAD api/v1/studentprofiles/{studentprofile} | ['api', 'Illuminate\\Auth\\Middleware\\Authenticate:sanctum']
PUT|PATCH api/v1/studentprofiles/{studentprofile} | ['api', 'Illuminate\\Auth\\Middleware\\Authenticate:sanctum']
DELETE api/v1/studentprofiles/{studentprofile} | ['api', 'Illuminate\\Auth\\Middleware\\Authenticate:sanctum']
```

### F6 — Controller shape

#### SPR-05 · L · CTL-04 — none of the seven public methods declares a return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:14-69`, all seven methods |
| **Root cause** | Generator scaffold never added types. |
| **Consequence** | No consequence today (L), but the shape of each signature changes with the SPR-02 outcome, so the types are added as part of that choice. |
| **Reproduce** | Static only — scanner rows. |
| **Fix approach** | `create()`/`edit()` get `: never` inside SPR-01's D5 change. The remaining five wait for the SPR-02 decision (`: never` if disabled, `: JsonResponse` if implemented). |
| **Plan item** | none — see plan §10 |

```php
    public function index()
    {
        Gate::authorize('tenant.student-profile.student.viewAny');

        return view('studentprofile::index');
    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php | grep CTL-04
L  CTL-04   Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:14  index — index() has no return type
L  CTL-04   Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:24  create — create() has no return type
L  CTL-04   Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:32  store — store() has no return type
L  CTL-04   Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:40  show — show() has no return type
L  CTL-04   Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:50  edit — edit() has no return type
L  CTL-04   Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:58  update — update() has no return type
L  CTL-04   Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:66  destroy — destroy() has no return type
```

### F7 — Models

#### SPR-06 · B · MDL-05 (TEN-01) — `StudentProfile` uses Spatie media without overriding `getMediaModel()`

| Field | Value |
|---|---|
| **Rule** | MDL-05 (B) — *every model using `InteractsWithMedia` in tenant context overrides `getMediaModel()` — otherwise media rows go to the central DB (cross-tenant leak)* |
| **Where** | `Modules/StudentProfile/app/Models/StudentProfile.php:14-16` (class + traits) with the `user_img` collection registered at `:101-104` |
| **Root cause** | The trait's default `getMediaModel()` returns `config('media-library.media_model')`, which is `Modules\Prime\Models\Media` — the CENTRAL model pinned to `prime_db`. Tenant models that actually store uploads (`SchoolSetup\User`, `SchoolSetup\Employee`, `Admission\Application`) all override it to return `\App\Models\TenantMedia::class`. `StudentProfile` does not. |
| **Consequence** | The first upload to the `user_img` single-file collection writes `sys_media` into the central `prime_db` instead of the tenant DB — a cross-tenant media leak. Latent today: a grep shows no caller ever adds media to a `StudentProfile` (uploads go to `User`/`Student`), and tenant `sys_media` has 0 rows for this model. |
| **Reproduce** | `(new \Modules\StudentProfile\Models\StudentProfile)->getMediaModel()` returns `Modules\Prime\Models\Media` (proven in tinker) instead of `App\Models\TenantMedia`. |
| **Fix approach** | Add the standard override returning `\App\Models\TenantMedia::class` (same shape as `User`, `Employee`, `Application`). |
| **Plan item** | SPR-06 in `02-fix-plan.md` §2 |

```php
class StudentProfile extends Model implements HasMedia
{
    use HasFactory, SoftDeletes, InteractsWithMedia;
```

**Evidence**
```
$ php artisan tinker --execute '... method_exists(...)=...
   echo "method_exists getMediaModel=".(method_exists(\Modules\StudentProfile\Models\StudentProfile::class, "getMediaModel") ? "true" : "false").PHP_EOL;
   echo "getMediaModel()=".(new \Modules\StudentProfile\Models\StudentProfile)->getMediaModel().PHP_EOL;
   echo "media rows for model in TENANT=".\DB::table("sys_media")->where("model_type", \Modules\StudentProfile\Models\StudentProfile::class)->count().PHP_EOL;'
method_exists getMediaModel=true
getMediaModel()=Modules\Prime\Models\Media
media rows for model in TENANT=0
```

#### SPR-07 · L · MDL-04 — the five relations have no return types, and `registerMediaConversions()` uses an implicit nullable parameter

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed*; the nullable signature is the same "typed signature" concern and triggers a PHP 8.4 deprecation warning on every class load |
| **Where** | `Modules/StudentProfile/app/Models/StudentProfile.php:58-93` (relations) and `:106` (`registerMediaConversions(Media $media = null)`) |
| **Root cause** | Generator scaffold: `belongsTo(...)` methods without `: BelongsTo`, and a pre-8.4 nullable style. |
| **Consequence** | L today. PHP prints `DEPRECATED` on every load of the model until `$media = null` becomes `?Media $media`. |
| **Reproduce** | `php -l Modules/StudentProfile/app/Models/StudentProfile.php` → `No syntax errors` plus `DEPRECATED ... Implicitly marking parameter $media as nullable is deprecated ... on line 106`. |
| **Fix approach** | Add `: BelongsTo` return types to the five relations and change the signature to `registerMediaConversions(?Media $media = null): void` (Spatie's current API keeps the default). |
| **Plan item** | SPR-07 in `02-fix-plan.md` §5 |

```php
    public function student()
    {
        return $this->belongsTo(Student::class, 'student_id');
    }
```

**Evidence**
```
$ php -l Modules/StudentProfile/app/Models/StudentProfile.php
No syntax errors detected in Modules/StudentProfile/app/Models/StudentProfile.php
  <warning> DEPRECATED </warning> Modules\StudentProfile\Models\StudentProfile::registerMediaConversions(): Implicitly marking parameter $media as nullable is deprecated, the explicit nullable type must be used instead in Modules/StudentProfile/app/Models/StudentProfile.php on line 106.
```

The remaining model checks are clean and proven: `$fillable` declared (`:23-43`), `$casts` cover both booleans, both decimals, the date, the JSON column and the two encrypted PII columns (`:45-54`), `$table = 'std_student_profiles'` exists in migration `database/migrations/tenant/2026_06_15_151312_create_std_student_profiles_table.php` (MDL-07), `SoftDeletes` matches `$table->softDeletes()` in that migration, and the `student()` relation resolves in tinker (`student relation -> student_id=1`).

### F8 — Services and jobs

clean — the controller names no service, job, event, mail or notification (`grep -nE 'Service|new .*Request|request\('` → no output).

### F9 — Queries and performance

clean — the controller executes zero DB queries (`grep -cE '::(where|find|all|get|first|count)\b|DB::'` → `0`). Nothing to paginate, select or cache here.

### F10 — Views

#### SPR-03 · H · CTL-10 — the routed `show()` returns a view that does not exist, and `index()` renders guarded includes it never fills with data

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M — *no dead code*: an unimplemented method whose named view is absent) — raised to H because the route is live and crashes |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:40-45` (`show()`), with `create()` `:24-27` and `edit()` `:50-53` naming the same missing views, and `index()` `:14-19` |
| **Root cause** | Scaffold methods return views that were never written. `view('studentprofile::show'|'create'|'edit')` resolve to `Modules/StudentProfile/resources/views/show|create|edit.blade.php` — none exist (only `index.blade.php` and `email.blade.php` sit in that folder). `index()` renders `studentprofile::index`, which `@can`-guards `@include('studentprofile::student-settings.index')` and `...medical-incident.index`; those blades need `$students`, `$class_section_id`, `$date`, `$academicSession`, `$incidents` etc. — `index()` passes nothing, so under a Super Admin (whose `Gate::before` grants the `@can`) the page throws "Undefined variable". |
| **Consequence** | `GET api/v1/studentprofiles/{studentprofile}` (with any valid token on a tenanted route) returns a 500 "View [show] not found" instead of a profile; `GET api/v1/studentprofiles` renders an index that is empty for non-admin callers and a 500 for Super Admin. |
| **Reproduce** | `view()->exists()` in tinker — `show`, `create`, `edit` all return `false`; then read the includes of `index.blade.php` and the variables they reference. |
| **Fix approach** | The two coherent outcomes are exactly SPR-02's: (a) disable these methods (`abort(403)` + `// NOT ROUTED`) or (b) rebuild them with real data wiring. No independent fix survives both choices, so this finding is recorded here and resolved by SPR-02 (see §10). |
| **Plan item** | none — see plan §10 |

```php
    public function show($id)
    {
        Gate::authorize('tenant.student-profile.student.view');

        return view('studentprofile::show');
    }
```

**Evidence**
```
$ php artisan tinker --execute 'var_dump(view()->exists("studentprofile::index")); var_dump(view()->exists("studentprofile::show")); var_dump(view()->exists("studentprofile::create")); var_dump(view()->exists("studentprofile::edit"));'
bool(true)
bool(false)
bool(false)
bool(false)
```

### F11 — Security and tenancy

SPR-06 (media leak to the central DB) and SPR-04 (API group without tenancy middleware) carry the F11 findings. Also clean: no `env()` in either in-scope PHP file (`grep -nE 'env\('` → no output), no hard-coded ids, nothing logged.

### F12 — Style

#### SPR-08 · L · STY-01 — controller has no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:1` |
| **Root cause** | Generator scaffold. `vendor/bin/pint ... --test` already reports the file "passed", so strict_types is the only style gap here. |
| **Consequence** | L — consistency across the module. |
| **Reproduce** | Static — first line is `<?php` with no `declare`. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag. |
| **Plan item** | SPR-08 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\StudentProfile\Http\Controllers;
```

**Evidence**
```
$ vendor/bin/pint Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php --test --format agent
{"tool":"pint","result":"passed"}
```

#### SPR-09 · L · STY-01/02 — model lacks strict_types and is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) and STY-02 (L — Pint-clean: sorted imports, ordered traits) |
| **Where** | `Modules/StudentProfile/app/Models/StudentProfile.php:1-16` |
| **Root cause** | Scaffold imports are not alphabetically sorted (`Factories\HasFactory` before `Model`), the same-namespace `use Modules\StudentProfile\Models\Student;` is redundant, the class-body `use HasFactory, SoftDeletes, InteractsWithMedia;` is not alphabetically ordered, and there is no `declare(strict_types=1)`. |
| **Consequence** | L — `vendor/bin/pint` would rewrite 6 fixers on first touch. |
| **Reproduce** | `vendor/bin/pint Modules/StudentProfile/app/Models/StudentProfile.php --test --format agent` → `"result":"fail"` listing 6 fixers. |
| **Fix approach** | Add strict_types, sort the imports (dropping the redundant same-namespace `Student` import), order the traits, then run Pint on the touched file (the fixer's §10 already mandates `vendor/bin/pint <touched files>`). |
| **Plan item** | SPR-09 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\StudentProfile\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Modules\SystemConfig\Models\Dropdown;
use Modules\StudentProfile\Models\Student;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
```

**Evidence**
```
$ vendor/bin/pint Modules/StudentProfile/app/Models/StudentProfile.php --test --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\/StudentProfile\/app\/Models\/StudentProfile.php","fixers":["fully_qualified_strict_types","nullable_type_declaration_for_default_null_value","single_line_comment_spacing","ordered_traits","no_unused_imports","ordered_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

The three methods that SHOULD mutate — `store()`, `update()`, `destroy()` — do nothing, so the deep-read answers are dominated by SPR-02:

| Question | `store` | `update` | `destroy` |
|---|---|---|---|
| 1. Write overwrite wrong data? | ok — no write at all | ok — no write | ok — no write |
| 2. Deleted before replacement stored? | ok | ok | ok |
| 3. Duplicate implementations? | ok — none | ok | ok |
| 4. Soft-delete × unique trap? | ok — `uq_std_profiles_studentId` unique on `student_id` exists; a future create must use `firstOrCreate` inside a transaction or rely on the index (TXN-06) | ok | ok |
| 5. Race? | ok — no check-then-act exists | ok | ok |
| 6. Authorization hole? | ok — `Gate::authorize` present on all three routed writes | ok | ok |
| 7. Does any message lie? | **SPR-02** — returns HTTP 200 success when nothing happened | **SPR-02** — same | **SPR-02** — same |
| 8. Dead feature? | **SPR-02** — no consumer reads the result; no menu, no caller, no media path | **SPR-02** | **SPR-02** |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SystemConfig/app/Models/Dropdown.php` | none seen — the four `belongsTo(Dropdown::class, ...)` relations match the `sys_dropdown_table` FKs in the tenant migration | — | none (common §4.2) |
| `Modules/StudentProfile/resources/views/student-settings/index.blade.php`, `medical-incident/index.blade.php` | none of their own — they are filled with data by `AttendanceController`/`MedicalIncidentController`. This controller's failure to pass that data is SPR-03, this report's business | VIEW-01/02 | this report (via SPR-02) |
| `bootstrap/app.php` render hook | correct behaviour that makes SPR-03 surface as a JSON 500; no defect | — | none |

## 8. Not covered, and why

- **End-to-end HTTP behaviour.** The write endpoints' "200 with empty body" claim and the missing-view 500 are proven statically (`view()->exists` + the empty method bodies), but no request was fired: exercising them needs a Sanctum token minted in the tenant DB, and D4 bans any test run.
- **The `index()` Super-Admin 500** relies on the app-global `Gate::before` bypass in `app/Providers/AppServiceProvider.php` — proven by source read, not by a browser.
- **Media upload path** for `StudentProfile` is latent (0 tenant rows today); the fix is still required for when anything starts uploading.
- **Live route probing via browser** executed nowhere (D4).