# Fix Plan — StudentProfile / StudentProfileController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | shared, permission-source of truth — the five `tenant.student-profile.student.*` keys already exist and are seeded; no edit needed |
| `Modules/StudentProfile/routes/web.php`, `routes/mobile_api.php` | route files used by other controllers' reports (StudentController, AttendanceController, ...) |
| `Modules/StudentProfile/resources/views/student-settings/index.blade.php`, `views/medical-incident/index.blade.php` | shared views owned/filled by AttendanceController and MedicalIncidentController reports |
| `database/migrations/tenant/*` | never edit an existing migration |
| `Modules/StudentProfile/app/Models/Student.php` and every class owned by another report in `final-audit-reports/00-CLASS-OWNERS.md` | owned elsewhere (StudentReportController, StdLeaveController, ...) |
| `app/Providers/AppServiceProvider.php`, `bootstrap/app.php` | shared app glue |

## 1. Blockers reachable today

None. The only B finding (SPR-06) is a latent media leak — no code path uploads to `StudentProfile` today — so it sits in §2 as the first "arms a latent defect" item.

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **SPR-06** · B · MDL-05/TEN-01 · `Modules/StudentProfile/app/Models/StudentProfile.php:14-16` — override `getMediaModel()` so media rows stay in the tenant DB.
  - **Touches:** `Modules/StudentProfile/app/Models/StudentProfile.php`
  - **Before** (`StudentProfile.php:14-16`):
    ```php
    class StudentProfile extends Model implements HasMedia
    {
        use HasFactory, SoftDeletes, InteractsWithMedia;
    ```
  - **After:**
    ```php
    class StudentProfile extends Model implements HasMedia
    {
        use HasFactory, SoftDeletes, InteractsWithMedia;

        /**
         * Tenant uploads must land in the tenant DB, not the central one (SPR-06, 2026-10-10).
         */
        public function getMediaModel(): string
        {
            return \App\Models\TenantMedia::class;
        }
    ```
  - **Verify:** `php artisan tinker --execute 'echo (new \Modules\StudentProfile\Models\StudentProfile)->getMediaModel();'`
  - **Expect:** `App\Models\TenantMedia`
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

## 4. Authorization (F3)

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **SPR-01** · M · RTE-03 · `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:24-27,50-53` — disable the two unrouted scaffold methods under D5 (`abort(403)` + `// NOT ROUTED`).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php`
  - **Before** (`StudentProfileController.php:24-27`):
    ```php
    public function create()
    {
        return view('studentprofile::create');
    }
    ```
  - **After:**
    ```php
    public function create(): never
    {
        // NOT ROUTED — apiResource never registers create() (SPR-01, 2026-10-10).
        abort(403, 'Student profile create is not routed.');
    }
    ```
  - **Before** (`StudentProfileController.php:50-53`):
    ```php
    public function edit($id)
    {
        return view('studentprofile::edit');
    }
    ```
  - **After:**
    ```php
    public function edit($id): never
    {
        // NOT ROUTED — apiResource never registers edit() (SPR-01, 2026-10-10).
        abort(403, 'Student profile edit is not routed.');
    }
    ```
  - **Verify:** `grep -n "NOT ROUTED" Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php`
  - **Expect:** two lines — one for `create()`, one for `edit()`.
  - **Effort:** S

- [ ] **SPR-07** · L · MDL-04 · `Modules/StudentProfile/app/Models/StudentProfile.php:58-116` — add `BelongsTo` return types to the five relations and make the media-conversion parameter explicitly nullable.
  - **Touches:** `Modules/StudentProfile/app/Models/StudentProfile.php`
  - **Before** (`StudentProfile.php:56-116`):
    ```php
        //begin::Eloquent Relationship

        public function student()
        {
            return $this->belongsTo(Student::class, 'student_id');
        }

        public function religion()
        {
            return $this->belongsTo(
                Dropdown::class,
                'religion'
            );
        }

        public function casteCategory()
        {
            return $this->belongsTo(
                Dropdown::class,
                'caste_category'
            );
        }

        public function nationality()
        {
            return $this->belongsTo(
                Dropdown::class,
                'nationality'
            );
        }

        public function motherTongue()
        {
            return $this->belongsTo(
                Dropdown::class,
                'mother_tongue'
            );
        }

        //end::Eloquent Relationship

        /* =======================
         | Media Library
         ======================= */

        public function registerMediaCollections(): void
        {
            $this->addMediaCollection('user_img')->singleFile();
        }

        public function registerMediaConversions(Media $media = null): void
        {
            $this->addMediaConversion('small')
                ->width(100)->height(100)->sharpen(10);

            $this->addMediaConversion('medium')
                ->width(300)->height(300)->sharpen(10);

            $this->addMediaConversion('large')
                ->width(600)->height(600)->sharpen(10);
        }
    ```
  - **After:**
    ```php
        //begin::Eloquent Relationship

        public function student(): BelongsTo
        {
            return $this->belongsTo(Student::class, 'student_id');
        }

        public function religion(): BelongsTo
        {
            return $this->belongsTo(
                Dropdown::class,
                'religion'
            );
        }

        public function casteCategory(): BelongsTo
        {
            return $this->belongsTo(
                Dropdown::class,
                'caste_category'
            );
        }

        public function nationality(): BelongsTo
        {
            return $this->belongsTo(
                Dropdown::class,
                'nationality'
            );
        }

        public function motherTongue(): BelongsTo
        {
            return $this->belongsTo(
                Dropdown::class,
                'mother_tongue'
            );
        }

        //end::Eloquent Relationship

        /* =======================
         | Media Library
         ======================= */

        public function registerMediaCollections(): void
        {
            $this->addMediaCollection('user_img')->singleFile();
        }

        public function registerMediaConversions(?Media $media = null): void
        {
            $this->addMediaConversion('small')
                ->width(100)->height(100)->sharpen(10);

            $this->addMediaConversion('medium')
                ->width(300)->height(300)->sharpen(10);

            $this->addMediaConversion('large')
                ->width(600)->height(600)->sharpen(10);
        }
    ```
  - **Verify:** `sed -n '56,116p' Modules/StudentProfile/app/Models/StudentProfile.php | grep -nE "public function (student|religion|casteCategory|nationality|motherTongue)\(\): BelongsTo|registerMediaConversions\(\?Media"`
  - **Expect:** six matching lines (five `: BelongsTo` relations plus one `?Media` signature).
  - **Effort:** S

## 6. Queries & performance (F9)

## 7. Views (F10)

## 8. Style (F12) — one item per file

- [ ] **SPR-08** · L · STY-01 · `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php:1` — add `declare(strict_types=1)` to the controller.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php`
  - **Before** (`StudentProfileController.php:1-3`):
    ```php
    <?php

    namespace Modules\StudentProfile\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Http\Controllers;
    ```
  - **Verify:** `sed -n '1,5p' Modules/StudentProfile/app/Http/Controllers/StudentProfileController.php`
  - **Expect:** line 3 reads `declare(strict_types=1);`.
  - **Effort:** S

- [ ] **SPR-09** · L · STY-01/02 · `Modules/StudentProfile/app/Models/StudentProfile.php:1-16` — add strict_types, sort the imports (drop the redundant same-namespace `Student` import) and order the traits in the class body.
  - **Touches:** `Modules/StudentProfile/app/Models/StudentProfile.php`
  - **Before** (`StudentProfile.php:1-16`):
    ```php
    <?php

    namespace Modules\StudentProfile\Models;

    use Illuminate\Database\Eloquent\Model;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\SystemConfig\Models\Dropdown;
    use Modules\StudentProfile\Models\Student;
    use Spatie\MediaLibrary\HasMedia;
    use Spatie\MediaLibrary\InteractsWithMedia;
    use Spatie\MediaLibrary\MediaCollections\Models\Media;

    class StudentProfile extends Model implements HasMedia
    {
        use HasFactory, SoftDeletes, InteractsWithMedia;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentProfile\Models;

    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\Model;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\SystemConfig\Models\Dropdown;
    use Spatie\MediaLibrary\HasMedia;
    use Spatie\MediaLibrary\InteractsWithMedia;
    use Spatie\MediaLibrary\MediaCollections\Models\Media;

    class StudentProfile extends Model implements HasMedia
    {
        use HasFactory, InteractsWithMedia, SoftDeletes;
    ```
  - **Verify:** `sed -n '1,16p' Modules/StudentProfile/app/Models/StudentProfile.php`
  - **Expect:** `declare(strict_types=1);` on line 3, imports alphabetically sorted with no `use Modules\StudentProfile\Models\Student;`, and `use HasFactory, InteractsWithMedia, SoftDeletes;` in the class body.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **SPR-02** · H · DECISION · ERR-06 — the `apiResource` scaffold: implement a real tenant API, or disable it as NOT ROUTED?
  - **Why it is a decision:** behaviour change covering five routed methods; option (b) also touches a route file (§9.3) and needs a new FormRequest. SPR-03 (reads 500/empty), SPR-04 (missing tenancy middleware) and SPR-05 (return types) are all resolved by this single choice.
  - (a) ⭐ **Disable the scaffold** — in `index()`, `store()`, `show()`, `update()`, `destroy()` replace each body with `abort(403, 'Student profile scaffold — NOT ROUTED');` plus a `// NOT ROUTED` comment (the D5 pattern; the routes stay registered but refuse). Touches only the controller. SPR-03/04/05 then need nothing further; only SPR-01/06/07/08/09 apply.
  - (b) **Implement a minimal real API** — add the mobile tenancy middleware to `Modules/StudentProfile/routes/api.php` (fixes SPR-04), create a `StudentProfileRequest` FormRequest (`authorize()` checking the same `tenant.student-profile.student.*` strings + typed rules), write `store()`/`update()`/`destroy()` as `DB::transaction` + `activityLog` mutations of `std_student_profiles` with route-model binding, and return `: JsonResponse` from all five methods (fixes SPR-05). Requires the SPR-04 middleware in the same change; a small feature build.
  - (c) **Accept as-is** — keep the endpoints returning `200 empty` on writes and `500` on `show()`, and record the accepted risk.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| SPR-03 | Read half of the same scaffold — SPR-02 option (a) disables `show()`/`index()` bodies; option (b) rebuilds them with data wiring. No independent fix survives either choice. |
| SPR-04 | Route-file middleware change, meaningful only if SPR-02 chooses (b) implement; it lands with that build. A fixer must not re-scope routes on its own (§9.3). |
| SPR-05 | Return types follow the SPR-02 outcome (`: never` for disabled bodies, `: JsonResponse` for a real API); the two unrouted methods already receive `: never` through SPR-01. |