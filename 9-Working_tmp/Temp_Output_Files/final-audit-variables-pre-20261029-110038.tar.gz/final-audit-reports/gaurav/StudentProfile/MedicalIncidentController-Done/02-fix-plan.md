# Fix Plan — StudentProfile / MedicalIncidentController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `database/migrations/tenant/2026_06_15_151305_create_std_medical_incidents_table.php` | existing migration — never edited |
| `config/permissionslist.php` | shared; the 7 permission names already exist, no change needed |
| `resources/views/index.blade.php` | shared — includes `medical-incident/index.blade.php` for AttendanceController's bulk page |
| `Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php` | shared provider — only MIC-03's DECISION may touch it, and only if Tarun ticks it |
| `Modules/SystemConfig/app/Models/Dropdown.php`, `Modules/SchoolSetup/app/Models/User.php`, `Modules/SchoolSetup/app/Models/ClassSection.php` | common classes owned elsewhere — usage fixes live in our module's views/controller |
| `Modules/StudentProfile/app/Models/Student.php`, `StudentAcademicSession.php` | owned by StudentReportController / StudentController reports |

## 1. Blockers reachable today

- [ ] **MIC-16** · B · DECISION · VIEW — `index()` 500s because the blade needs `$incidentsExport` which `index()` never passes.
  - **Why it is a decision:** the fix either changes the route's behaviour (option a) or duplicates AttendanceController's loader logic and edits a shared blade (option b).
  - (a) ⭐ redirect `index()` to the Bulk Attendance tab — `return redirect()->route('student-profile.attendance.bulk', ['tab' => 'medical-incident']);` — the tab already renders this exact partial with all variables; the shared blade stays untouched; dashboard "Medical Incidents" links land on the tab that already worked.
  - (b) make `index()` build `$incidentsExport`/`$incidentStudents`/`$incidentTypes` exactly like `AttendanceController::bulkAttendanceIndex()` (lines 358-395) — duplicates logic and re-renders a bare tab fragment as a standalone page.
  - (c) remove the `medical-incidents.index` route and point the dashboard link at `attendance.bulk` instead.
  - ➜ Choice: ____

## 2. Fixes that arm a latent defect (sequenced)

Order matters: MIC-12 (media model) MUST land before MIC-06's option (a) ever saves a file.

- [ ] **MIC-12** · B · MDL-05 · `Modules/StudentProfile/app/Models/MedicalIncident.php:17` — add `getMediaModel()` so any tenant media write stays in the tenant DB.
  - **Touches:** `Modules/StudentProfile/app/Models/MedicalIncident.php`
  - **Before** (`MedicalIncident.php:11-17`):
    ```php
    use Spatie\MediaLibrary\HasMedia;
    use Spatie\MediaLibrary\InteractsWithMedia;
    use Spatie\MediaLibrary\MediaCollections\Models\Media;

    class MedicalIncident extends Model implements HasMedia
    {
        use HasFactory, SoftDeletes, InteractsWithMedia;
    ```
  - **After:**
    ```php
    use Spatie\MediaLibrary\HasMedia;
    use Spatie\MediaLibrary\InteractsWithMedia;
    use Spatie\MediaLibrary\MediaCollections\Models\Media;

    class MedicalIncident extends Model implements HasMedia
    {
        use HasFactory, SoftDeletes, InteractsWithMedia;

        public function getMediaModel(): string
        {
            return \App\Models\TenantMedia::class;
        }
    ```
  - **Verify:** `grep -n "getMediaModel" Modules/StudentProfile/app/Models/MedicalIncident.php`
  - **Expect:** `20:        public function getMediaModel(): string` (or the line where the method landed).
  - **Effort:** S

- [ ] **MIC-06** · H · DECISION · VAL-06 — the "Medical Document" upload is accepted by the forms and silently dropped.
  - **Why it is a decision:** implementing the upload (option a) is a new feature that needs the MIC-12 media model first; removing the control (option b) is the minimal no-lie fix.
  - (a) implement the upload: add `'medical_document' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:2048'` to a FormRequest (MIC-04), `addMediaFromRequest('medical_document')->toMediaCollection('medical_documents')` inside the store/update transactions, fix the singular/plural collection-name mismatch (`addMediaCollection('medical_document')` in the model and `medical_documents` everywhere in views), then display it on show. Requires MIC-12 ticked first.
  - (b) ⭐ remove the dead upload: delete the `image-with-preview` blocks in `create.blade.php:143-145` and `edit.blade.php:149-151`, remove `enctype="multipart/form-data"` from both forms, delete the media card in `show.blade.php:126-141`, and drop the `registerMediaCollections()`/`registerMediaConversions()` methods and the `HasMedia`/`InteractsWithMedia` traits from the model.
  - (c) leave as is and record as accepted.
  - ➜ Choice: ____

## 3. Errors & transactions (F1/F2)

- [ ] **MIC-01** · H · TXN-01 · TXN-04 · `MedicalIncidentController.php` — wrap each of the six mutation methods in one `DB::transaction` with `activityLog()` inside, after the write.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Before** (`MedicalIncidentController.php:189-205`, update()):
    ```php
            $incident->update($validated);

            $changes = [];
            foreach ($incident->getChanges() as $field => $newValue) {
                if ($field === 'updated_at')
                    continue;
                $changes[$field] = [
                    'old' => $original[$field] ?? null,
                    'new' => $newValue,
                ];
            }

            activityLog($incident, 'Updated', [
                'message' => 'Medical incident updated.',
                'changes' => $changes,
                'performed_by' => Auth::user()->name ?? null,
            ]);
    ```
  - **After:** (apply the same shape to `update`, `destroy` (215-229), `restore` (253-267), `forceDelete` (272-286), `toggleFollowUp` (291-312), `toggleParentNotified` (317-338))
    ```php
    // update() — the write + audit log go inside one closure
            DB::transaction(function () use ($incident, $original, $validated) {
                $incident->update($validated);

                $changes = [];
                foreach ($incident->getChanges() as $field => $newValue) {
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                activityLog($incident, 'Updated', [
                    'message' => 'Medical incident updated.',
                    'changes' => $changes,
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });

    // destroy()
            DB::transaction(function () use ($incident) {
                $incident->delete();

                activityLog($incident, 'Deleted', [
                    'message' => 'Medical incident deleted'
                ]);
            });

    // restore()
            DB::transaction(function () use ($incident) {
                $incident->restore();

                activityLog($incident, 'Restored', [
                    'message' => 'Medical incident restored'
                ]);
            });

    // forceDelete()
            DB::transaction(function () use ($incident) {
                $incident->forceDelete();

                activityLog($incident, 'Force Deleted', [
                    'message' => 'Medical incident permanently deleted'
                ]);
            });

    // toggleFollowUp()
            DB::transaction(function () use ($incident, $request) {
                $incident->follow_up_required = (bool) $request->follow_up_required;
                $incident->save();

                activityLog($incident, 'Toggled', [
                    'message' => 'Medical incident follow-up status toggled.',
                ]);
            });

    // toggleParentNotified()
            DB::transaction(function () use ($incident, $request) {
                $incident->parent_notified = (bool) $request->parent_notified;
                $incident->save();

                activityLog($incident, 'Toggled', [
                    'message' => 'Medical incident parent notified status toggled.',
                ]);
            });
    ```
  - **Verify:** `grep -c "DB::transaction" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Expect:** `6` (one per mutation method; `update` at 189, `destroy` 219, `restore` 257, `forceDelete` 276, `toggleFollowUp` 299, `toggleParentNotified` 325 — line numbers approximate after edits).
  - **Effort:** S

- [ ] **MIC-02** · M · TXN-04 · `MedicalIncidentController.php:115` — `store()` must audit its own write like every other mutation.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Before** (`MedicalIncidentController.php:115-120`):
    ```php
            MedicalIncident::create($validated);

            return redirect()
                ->route('student-profile.attendance.bulk', ['tab' => 'medical-incident'])
                ->with('success', flash('created.medical_incident'));
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($validated) {
                $incident = MedicalIncident::create($validated);

                activityLog($incident, 'Created', [
                    'message' => 'Medical incident created.',
                ]);
            });

            return redirect()
                ->route('student-profile.attendance.bulk', ['tab' => 'medical-incident'])
                ->with('success', flash('created.medical_incident'));
    ```
  - **Verify:** `grep -n "'Created'" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Expect:** the line `activityLog($incident, 'Created', [` inside `store()`.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **MIC-03** · M · DECISION · AUTH-06 — `MedicalIncidentPolicy` is registered but never consulted; the permission strings are duplicated in the controller and policy.
  - **Why it is a decision:** removing the class touches the shared `StudentProfileServiceProvider` (⚠ SHARED), and whether to keep the policy as documentation is a team policy choice.
  - (a) ⭐ remove the dead policy: delete `Modules/StudentProfile/app/Policies/MedicalIncidentPolicy.php` and the `use` + `Gate::policy(MedicalIncident::class, MedicalIncidentPolicy::class);` lines in `StudentProfileServiceProvider.php:19,65` — behaviour-neutral, because nothing calls a policy method for this model today.
  - (b) keep the policy but add a comment in the class docblock: "Never consulted — the controller authorizes with Gate::authorize(permission-string); this class is documentation only."
  - (c) keep as is, record as accepted.
  - ➜ Choice: ____

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **MIC-04** · M · VAL-02 · `MedicalIncidentController.php:101,175` — move the 11-rule validation into a FormRequest. Applies after MIC-01/MIC-02 (the transactions stay in place).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`, `Modules/StudentProfile/app/Http/Requests/MedicalIncidentRequest.php` (new file)
  - **Before** (`MedicalIncidentController.php:97-120`, store()):
    ```php
        public function store(Request $request)
        {
            Gate::authorize('tenant.student-profile.medical-incident.create');

            $validated = $request->validate([
                'student_id' => 'required|exists:std_students,id',
                'incident_date' => 'required|date',
                'incident_type_id' => 'required|exists:sys_dropdown_table,id',
                'location' => 'required|string|max:100',
                'description' => 'required|string',
                'first_aid_given' => 'nullable|string|max:512',
                'action_taken' => 'nullable|string|max:255',
                'reported_by' => 'required|exists:sys_users,id',
                'parent_notified' => 'boolean',
                'closure_date' => 'nullable|date|after_or_equal:incident_date',
                'follow_up_required' => 'boolean',
            ]);

            MedicalIncident::create($validated);

            return redirect()
                ->route('student-profile.attendance.bulk', ['tab' => 'medical-incident'])
                ->with('success', flash('created.medical_incident'));
        }
    ```
  - **After:**
    ```php
    // NEW FILE Modules/StudentProfile/app/Http/Requests/MedicalIncidentRequest.php — create it first
    <?php

    namespace Modules\StudentProfile\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;

    class MedicalIncidentRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }

        public function rules(): array
        {
            return [
                'student_id' => 'required|exists:std_students,id',
                'incident_date' => 'required|date',
                'incident_type_id' => 'required|exists:sys_dropdown_table,id',
                'location' => 'required|string|max:100',
                'description' => 'required|string',
                'first_aid_given' => 'nullable|string|max:512',
                'action_taken' => 'nullable|string|max:255',
                'reported_by' => 'required|exists:sys_users,id',
                'parent_notified' => 'boolean',
                'closure_date' => 'nullable|date|after_or_equal:incident_date',
                'follow_up_required' => 'boolean',
            ];
        }
    }

    // MedicalIncidentController.php — store() becomes (signature + validation line only; the DB::transaction from MIC-02 stays)
        public function store(MedicalIncidentRequest $request)
        {
            Gate::authorize('tenant.student-profile.medical-incident.create');

            $validated = $request->validated();

            DB::transaction(function () use ($validated) {
                $incident = MedicalIncident::create($validated);

                activityLog($incident, 'Created', [
                    'message' => 'Medical incident created.',
                ]);
            });

            return redirect()
                ->route('student-profile.attendance.bulk', ['tab' => 'medical-incident'])
                ->with('success', flash('created.medical_incident'));
        }

    // MedicalIncidentController.php — update() becomes (signature + validation line; the DB::transaction from MIC-01 stays)
        public function update(MedicalIncidentRequest $request, $id)
        {
            Gate::authorize('tenant.student-profile.medical-incident.update');

            $incident = MedicalIncident::findOrFail($id);
            $original = $incident->getOriginal();

            $validated = $request->validated();

            DB::transaction(function () use ($incident, $original, $validated) {
                $incident->update($validated);

                $changes = [];
                foreach ($incident->getChanges() as $field => $newValue) {
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                activityLog($incident, 'Updated', [
                    'message' => 'Medical incident updated.',
                    'changes' => $changes,
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });

            return redirect()
                ->route('student-profile.attendance.bulk', ['tab' => 'medical-incident'])
                ->with('success', flash('updated.medical_incident'));
        }
    ```
  - **Verify:** `grep -n "request->validate" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`; `php -l Modules/StudentProfile/app/Http/Requests/MedicalIncidentRequest.php`
  - **Expect:** only lines 295 and 321 remain (the two one-field AJAX toggles — allowed by VAL-02); the new request file lints clean.
  - **Effort:** S

- [ ] **MIC-05** · M · CTL-05 · `MedicalIncidentController.php:42-47,150-155,101-113,175-187` — kill the copy-pasted dropdown loaders and the duplicated validation array.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Before** (`MedicalIncidentController.php:38-66`, create() loaders):
    ```php
        public function create()
        {
            Gate::authorize('tenant.student-profile.medical-incident.create');

            $students = Student::where('is_active', true)->get();
            $incidentTypes = Dropdown::where('key', 'std_medical_incidents.incident_type_id')
                ->where('is_active', 1)
                ->orderBy('ordinal')
                ->get();
            $users = User::active()->get();

            $classSections = ClassSection::with(['class', 'section'])
                ->join('sch_classes', 'sch_class_section_jnt.class_id', '=', 'sch_classes.id')
                ->join('sch_sections', 'sch_class_section_jnt.section_id', '=', 'sch_sections.id')
                ->where('sch_class_section_jnt.is_active', 1)
                ->whereHas('class')
                ->whereHas('section')
                ->orderBy('sch_classes.ordinal')
                ->orderBy('sch_sections.ordinal')
                ->select('sch_class_section_jnt.*')
                ->get();

            return view('studentprofile::medical-incident.create', compact(
                'students',
                'incidentTypes',
                'users',
                'classSections'
            ));
        }
    ```
  - **After:**
    ```php
        public function create()
        {
            Gate::authorize('tenant.student-profile.medical-incident.create');

            [$students, $incidentTypes, $users] = $this->incidentFormData();

            $classSections = ClassSection::with(['class', 'section'])
                ->join('sch_classes', 'sch_class_section_jnt.class_id', '=', 'sch_classes.id')
                ->join('sch_sections', 'sch_class_section_jnt.section_id', '=', 'sch_sections.id')
                ->where('sch_class_section_jnt.is_active', 1)
                ->whereHas('class')
                ->whereHas('section')
                ->orderBy('sch_classes.ordinal')
                ->orderBy('sch_sections.ordinal')
                ->select('sch_class_section_jnt.*')
                ->get();

            return view('studentprofile::medical-incident.create', compact(
                'students',
                'incidentTypes',
                'users',
                'classSections'
            ));
        }

        private function incidentFormData(): array
        {
            return [
                Student::active()->get(),
                Dropdown::where('key', 'std_medical_incidents.incident_type_id')
                    ->where('is_active', 1)
                    ->orderBy('ordinal')
                    ->get(),
                User::active()->get(),
            ];
        }

    // edit() — replace lines 149-155 with the same helper
        public function edit($id)
        {
            Gate::authorize('tenant.student-profile.medical-incident.update');

            $incident = MedicalIncident::findOrFail($id);
            [$students, $incidentTypes, $users] = $this->incidentFormData();

            return view('studentprofile::medical-incident.edit', compact(
                'incident',
                'students',
                'incidentTypes',
                'users'
            ));
        }
    ```
    (The duplicated validation array disappears with MIC-04's FormRequest; apply MIC-04 before this item.)
  - **Verify:** `grep -c "Dropdown::where('key', 'std_medical_incidents.incident_type_id')" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Expect:** `1` (only the private helper) instead of the current 2.
  - **Effort:** S

- [ ] **MIC-07** · H · RTE-01 · `Modules/StudentProfile/routes/web.php:170` — `restore` must not mutate over GET. ⚠ SHARED route file.
  - **Touches:** `Modules/StudentProfile/routes/web.php` ⚠ SHARED
  - **Before** (`web.php:170`):
    ```php
        Route::get('medical-incidents/{id}/restore', [MedicalIncidentController::class, 'restore'])->name('medical-incidents.restore');
    ```
  - **After:**
    ```php
        Route::patch('medical-incidents/{id}/restore', [MedicalIncidentController::class, 'restore'])->name('medical-incidents.restore');
    ```
  - **Verify:** `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list 2>/dev/null | grep "medical-incidents/{id}/restore"`
  - **Expect:** `PATCH|HEAD` (or `PATCH`) on `student-profile/medical-incidents/{id}/restore`.
  - **Effort:** S

- [ ] **MIC-08** · M · CTL-03 · `MedicalIncidentController.php` — use route model binding on the resource routes. Applies after MIC-01/MIC-02/MIC-04 (keeps the transactions and FormRequests).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Before** (`MedicalIncidentController.php:125-140`, show()):
    ```php
        public function show($id)
        {
            Gate::authorize('tenant.student-profile.medical-incident.view');

            $incident = MedicalIncident::with([
                'student',
                'reporter',
                'incidentType'
            ])->findOrFail($id);

            if (request()->ajax()) {
                return view('studentprofile::medical-incident.show', compact('incident'));
            }

            return view('studentprofile::medical-incident.show', compact('incident'));
        }
    ```
  - **After:**
    ```php
        public function show(Request $request, MedicalIncident $medicalIncident)
        {
            Gate::authorize('tenant.student-profile.medical-incident.view');

            $incident = $medicalIncident->load([
                'student',
                'reporter',
                'incidentType'
            ]);

            return view('studentprofile::medical-incident.show', compact('incident'));
        }

    // edit() — same binding (drop the findOrFail)
        public function edit(MedicalIncident $medicalIncident)
        {
            Gate::authorize('tenant.student-profile.medical-incident.update');

            $incident = $medicalIncident;
            [$students, $incidentTypes, $users] = $this->incidentFormData();

            return view('studentprofile::medical-incident.edit', compact(
                'incident',
                'students',
                'incidentTypes',
                'users'
            ));
        }

    // update() — same binding (the DB::transaction and FormRequest from MIC-01/MIC-04 stay)
        public function update(MedicalIncidentRequest $request, MedicalIncident $medicalIncident)
        {
            Gate::authorize('tenant.student-profile.medical-incident.update');

            $incident = $medicalIncident;
            $original = $incident->getOriginal();

            $validated = $request->validated();

            DB::transaction(function () use ($incident, $original, $validated) {
                $incident->update($validated);

                $changes = [];
                foreach ($incident->getChanges() as $field => $newValue) {
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                activityLog($incident, 'Updated', [
                    'message' => 'Medical incident updated.',
                    'changes' => $changes,
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });

            return redirect()
                ->route('student-profile.attendance.bulk', ['tab' => 'medical-incident'])
                ->with('success', flash('updated.medical_incident'));
        }

    // destroy() — same binding
        public function destroy(MedicalIncident $medicalIncident)
        {
            Gate::authorize('tenant.student-profile.medical-incident.delete');

            $incident = $medicalIncident;

            DB::transaction(function () use ($incident) {
                $incident->delete();

                activityLog($incident, 'Deleted', [
                    'message' => 'Medical incident deleted'
                ]);
            });

            return redirect()
                ->route('student-profile.attendance.bulk', ['tab' => 'medical-incident'])
                ->with('success', 'Medical incident deleted successfully!');
        }
    ```
  - **Verify:** `php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); var_dump(method_exists(Modules\StudentProfile\Http\Controllers\MedicalIncidentController::class, "show"));'`
  - **Expect:** `bool(true)` and `php -l` clean; a GET on a missing id returns 404 from binding.
  - **Effort:** M

- [ ] **MIC-13** · L · MDL-04 · `Modules/StudentProfile/app/Models/MedicalIncident.php:47-60` — type the three relationship methods.
  - **Touches:** `Modules/StudentProfile/app/Models/MedicalIncident.php`
  - **Before** (`MedicalIncident.php:47-60`):
    ```php
        public function student()
        {
            return $this->belongsTo(Student::class, 'student_id');
        }

        public function reporter()
        {
            return $this->belongsTo(User::class, 'reported_by');
        }

        public function incidentType()
        {
            return $this->belongsTo(Dropdown::class, 'incident_type_id');
        }
    ```
  - **After:**
    ```php
        public function student(): BelongsTo
        {
            return $this->belongsTo(Student::class, 'student_id');
        }

        public function reporter(): BelongsTo
        {
            return $this->belongsTo(User::class, 'reported_by');
        }

        public function incidentType(): BelongsTo
        {
            return $this->belongsTo(Dropdown::class, 'incident_type_id');
        }
    ```
    Add the import at the top of the file next to the other `use` lines: `use Illuminate\Database\Eloquent\Relations\BelongsTo;`
  - **Verify:** `grep -n "BelongsTo" Modules/StudentProfile/app/Models/MedicalIncident.php`
  - **Expect:** one `use` line plus three method signatures ending in `: BelongsTo`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **MIC-14** · M · QRY-15 · `MedicalIncidentController.php:42,150` — cap the student dropdown instead of loading every active student on a form page. (Users and the small type dropdown stay as-is; `incidentFormData()` from MIC-05 keeps the loader in one place.)
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Before** (`MedicalIncidentController.php:42-47`, create() — the current file shape; if MIC-05 was applied first, apply the same `orderBy('first_name')->limit(100)` inside the `incidentFormData()` helper instead):
    ```php
        $students = Student::where('is_active', true)->get();
        $incidentTypes = Dropdown::where('key', 'std_medical_incidents.incident_type_id')
            ->where('is_active', 1)
            ->orderBy('ordinal')
            ->get();
        $users = User::active()->get();
    ```
  - **After:** (if MIC-05 was applied, this is the `incidentFormData()` helper body; otherwise apply the same `ORDER BY first_name LIMIT 100` to `create()` line 42 and `edit()` line 150)
    ```php
            return [
                Student::active()
                    ->orderBy('first_name')
                    ->limit(100)
                    ->get(),
                Dropdown::where('key', 'std_medical_incidents.incident_type_id')
                    ->where('is_active', 1)
                    ->orderBy('ordinal')
                    ->get(),
                User::active()->get(),
            ];
    ```
    Direct form when MIC-05 was NOT applied — `create()` and `edit()`:
    ```php
        $students = Student::active()
            ->orderBy('first_name')
            ->limit(100)
            ->get();
    ```
    The create page still filters the full student list through `ajaxGetStudents` (class-section filter), so a student beyond the first 100 is reachable there. If MIC-05 was not applied, apply the same `orderBy('first_name')->limit(100)` to lines 42 and 150 directly.
  - **Verify:** `grep -n "limit(100)" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Expect:** one line with `->limit(100)`.
  - **Effort:** S

- [ ] **MIC-15** · H · QRY-02 · `MedicalIncidentController.php:76-91` — never serialise the whole active-student table from the AJAX endpoint.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Before** (`MedicalIncidentController.php:71-92`, ajaxGetStudents()):
    ```php
        public function ajaxGetStudents(Request $request)
        {
            Gate::authorize('tenant.student-profile.medical-incident.view');
            $classSectionId = $request->class_section_id;

            $query = Student::active()->with(['user']);

            if ($classSectionId) {
                $query->whereHas('currentAcademicSession', function ($q) use ($classSectionId) {
                    $q->where('class_section_id', $classSectionId);
                });
            }

            $students = $query->get()->map(function ($student) {
                return [
                    'id' => $student->id,
                    'name' => ($student->user->name ?? $student->full_name) . ' - ' . $student->admission_no
                ];
            });

            return response()->json($students);
        }
    ```
  - **After:**
    ```php
        public function ajaxGetStudents(Request $request)
        {
            Gate::authorize('tenant.student-profile.medical-incident.view');
            $classSectionId = $request->class_section_id;

            if (! $classSectionId) {
                return response()->json([]);
            }

            $students = Student::active()
                ->with(['user'])
                ->whereHas('currentAcademicSession', function ($q) use ($classSectionId) {
                    $q->where('class_section_id', $classSectionId);
                })
                ->limit(200)
                ->get()
                ->map(function ($student) {
                    return [
                        'id' => $student->id,
                        'name' => ($student->user->name ?? $student->full_name) . ' - ' . $student->admission_no,
                    ];
                });

            return response()->json($students);
        }
    ```
  - **Verify:** `grep -n "if (! \$classSectionId)" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Expect:** the guard line present; the endpoint returns `[]` when no class-section is selected.
  - **Effort:** S

## 7. Views (F10)

- [ ] **MIC-17** · H · VIEW · `Modules/StudentProfile/resources/views/medical-incident/trash.blade.php` — the 0-byte view renders a blank page; give it a real body. Applies after MIC-07 (the restore form uses `PATCH`).
  - **Touches:** `Modules/StudentProfile/resources/views/medical-incident/trash.blade.php`
  - **Before** (whole file is empty):
    ```php
    ```
  - **After:**
    ```blade
    <x-backend.layouts.app>
        <x-backend.components.breadcrum title="Trashed Medical Incidents" :links="[]" />

        <div class="container-fluid">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h3 class="card-title">Trashed Medical Incidents</h3>
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>Incident Date</th>
                                <th>Student</th>
                                <th>Type</th>
                                <th>Location</th>
                                <th>Deleted At</th>
                                <th width="220">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($incidents as $incident)
                                <tr>
                                    <td>{{ $incident->incident_date->format('d M Y H:i') }}</td>
                                    <td>{{ $incident->student?->admission_no ?? '-' }}</td>
                                    <td>{{ $incident->incidentType?->value ?? '-' }}</td>
                                    <td>{{ $incident->location }}</td>
                                    <td>{{ $incident->deleted_at ? $incident->deleted_at->format('d M Y H:i') : '-' }}</td>
                                    <td>
                                        <form action="{{ route('student-profile.medical-incidents.restore', $incident->id) }}" method="POST" class="d-inline">
                                            @csrf
                                            @method('PATCH')
                                            <button class="btn btn-sm btn-success">Restore</button>
                                        </form>
                                        <form action="{{ route('student-profile.medical-incidents.forceDelete', $incident->id) }}" method="POST" class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn btn-sm btn-danger">Delete Permanently</button>
                                        </form>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6" class="text-center">No trashed medical incidents found</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    {{ $incidents->links() }}
                </div>
            </div>
        </div>
    </x-backend.layouts.app>
    ```
  - **Verify:** `wc -c Modules/StudentProfile/resources/views/medical-incident/trash.blade.php`
  - **Expect:** a byte count greater than 0 and the file compiles (no stray `{{-- --}}` inside `@php`; no `Model::` queries inside the blade).
  - **Effort:** M

- [ ] **MIC-18** · M · VIEW · fallback reads of columns that do not exist (`dropdown_name`, `name`, `student->name`).
  - **Touches:** `Modules/StudentProfile/resources/views/medical-incident/edit.blade.php`, `Modules/StudentProfile/resources/views/medical-incident/show.blade.php`
  - **Before** (`edit.blade.php:21-27` and `edit.blade.php:48-54`):
    ```blade
                                        @foreach ($students as $student)
                                            <option value="{{ $student->id }}"
                                                {{ old('student_id', $incident->student_id) == $student->id ? 'selected' : '' }}>
                                                {{ $student->user->name ?? $student->name }} -
                                                {{ $student->admission_no }}
                                            </option>
                                        @endforeach
    ```
  - **After:**
    ```blade
                                        @foreach ($students as $student)
                                            <option value="{{ $student->id }}"
                                                {{ old('student_id', $incident->student_id) == $student->id ? 'selected' : '' }}>
                                                {{ $student->user?->name ?? $student->full_name }} -
                                                {{ $student->admission_no }}
                                            </option>
                                        @endforeach

    // edit.blade.php:48-54 — the Incident Type options label becomes
                                        @foreach ($incidentTypes as $type)
                                            <option value="{{ $type->id }}"
                                                {{ old('incident_type_id', $incident->incident_type_id) == $type->id ? 'selected' : '' }}>
                                                {{ $type->value }}
                                            </option>
                                        @endforeach

    // show.blade.php:30 — student cell becomes null-safe and uses the real column
                                        <strong>{{ $incident->student?->user?->name ?? $incident->student?->full_name }}</strong>
                                        ({{ $incident->student?->admission_no }})

    // show.blade.php:43-46 — the type badge uses the real column
                                        <span
                                            class="badge badge-info">{{ $incident->incidentType?->value ?? '-' }}</span>
    ```
  - **Verify:** `grep -n "dropdown_name\|student->name\|student->user->name" Modules/StudentProfile/resources/views/medical-incident/edit.blade.php Modules/StudentProfile/resources/views/medical-incident/show.blade.php`
  - **Expect:** no output (all three wrong-column reads replaced).
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **MIC-09** · L · CTL-08 · `MedicalIncidentController.php:135` — inject `Request` in `show()` instead of the `request()` helper. Applies before MIC-11 (which collapses the branch MIC-09's `$request->ajax()` feeds).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Before** (`MedicalIncidentController.php:125-140`, show()):
    ```php
        public function show($id)
        {
            Gate::authorize('tenant.student-profile.medical-incident.view');

            $incident = MedicalIncident::with([
                'student',
                'reporter',
                'incidentType'
            ])->findOrFail($id);

            if (request()->ajax()) {
                return view('studentprofile::medical-incident.show', compact('incident'));
            }

            return view('studentprofile::medical-incident.show', compact('incident'));
        }
    ```
  - **After:**
    ```php
        public function show(Request $request, MedicalIncident $medicalIncident)
        {
            Gate::authorize('tenant.student-profile.medical-incident.view');

            $incident = $medicalIncident->load([
                'student',
                'reporter',
                'incidentType'
            ]);

            if ($request->ajax()) {
                return view('studentprofile::medical-incident.show', compact('incident'));
            }

            return view('studentprofile::medical-incident.show', compact('incident'));
        }
    ```
  - **Verify:** `grep -n "request()->ajax()" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Expect:** no output (the `request()` helper is gone).
  - **Effort:** S

- [ ] **MIC-10** · L · CTL-04 · `MedicalIncidentController.php` — add return types to all 13 public methods.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Before** (`MedicalIncidentController.php:22-33`, index() — the first method; the same rule applies to the other 12):
    ```php
        public function index()
        {
            Gate::authorize('tenant.student-profile.medical-incident.viewAny');

            $incidents = MedicalIncident::with([
                'student',
                'reporter',
                'incidentType'
            ])->latest('incident_date')->paginate(10);

            return view('studentprofile::medical-incident.index', compact('incidents'));
        }
    ```
  - **After:** (apply to the current signatures — take the bound-parameter versions if MIC-08 was applied)
    ```php
        public function index(): View
        public function create(): View
        public function ajaxGetStudents(Request $request): JsonResponse
        public function store(Request $request): RedirectResponse
        public function show(Request $request, MedicalIncident $medicalIncident): View
        public function edit(MedicalIncident $medicalIncident): View
        public function update(Request $request, MedicalIncident $medicalIncident): RedirectResponse
        public function destroy(MedicalIncident $medicalIncident): RedirectResponse
        public function trashed(): View
        public function restore($id): RedirectResponse
        public function forceDelete($id): RedirectResponse
        public function toggleFollowUp(Request $request, $id): JsonResponse
        public function toggleParentNotified(Request $request, $id): JsonResponse
    ```
    The body of `index()` becomes:
    ```php
        public function index(): View
        {
            Gate::authorize('tenant.student-profile.medical-incident.viewAny');

            return view('studentprofile::medical-incident.index', [
                'incidents' => MedicalIncident::with([
                    'student',
                    'reporter',
                    'incidentType'
                ])->latest('incident_date')->paginate(10),
            ]);
        }
    ```
    Add the imports `use Illuminate\Contracts\View\View;` and `use Illuminate\Http\JsonResponse;` and `use Illuminate\Http\RedirectResponse;` to the controller's `use` block.
  - **Verify:** `grep -c ": View\|RedirectResponse\|JsonResponse" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Expect:** at least 13 matching return-type tokens.
  - **Effort:** S

- [ ] **MIC-11** · M · CTL-10 · `MedicalIncidentController.php` — remove the two unused imports and the if/else whose branches return the same view. Applies after MIC-09 (which introduced `$request->ajax()`).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Before** (`MedicalIncidentController.php:135-139`, show() tail):
    ```php
            if (request()->ajax()) {
                return view('studentprofile::medical-incident.show', compact('incident'));
            }

            return view('studentprofile::medical-incident.show', compact('incident'));
    ```
  - **After:**
    ```php
            return view('studentprofile::medical-incident.show', compact('incident'));
    ```
    Also delete these two `use` lines (8 and 15) which are never referenced:
    ```php
    use Illuminate\Support\Facades\DB;
    use Modules\StudentProfile\Models\StudentAcademicSession;
    ```
  - **Verify:** `grep -n "use Illuminate\Support\Facades\DB;\|use Modules\StudentProfile\Models\StudentAcademicSession;" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php` and `grep -c "compact('incident')" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`
  - **Expect:** no output for the two `use` lines; the `compact('incident')` count in `show()` falls to 1.
  - **Effort:** S

- [ ] **MIC-19** · L · STY-01 · add `declare(strict_types=1);` to the three owned PHP files.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php`, `Modules/StudentProfile/app/Models/MedicalIncident.php`, `Modules/StudentProfile/app/Policies/MedicalIncidentPolicy.php`
  - **Before** (`MedicalIncidentController.php:1-2`):
    ```php
    <?php

    ```
  - **After:** (same change at the top of all three files)
    ```php
    <?php

    declare(strict_types=1);

    ```
  - **Verify:** `grep -rc "declare(strict_types" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php Modules/StudentProfile/app/Models/MedicalIncident.php Modules/StudentProfile/app/Policies/MedicalIncidentPolicy.php`
  - **Expect:** `...:1` for all three files.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **MIC-20** · M · DECISION · F13#8 — the two toggle buttons in `show.blade.php` have no JS handler, so `toggleFollowUp`/`toggleParentNotified` are unreachable from the UI.
  - **Why it is a decision:** adding the handler means writing new page JavaScript (a feature decision); removing the buttons drops an advertised capability (a scope decision).
  - (a) wire the buttons: add an inline `@push('scripts')` block in `show.blade.php` that attaches a click handler to `.toggle-follow-up` / `.toggle-parent-notified` and POSTs `{ follow_up_required: 1|0 }` / `{ parent_notified: 1|0 }` to the two existing routes (they already validate `required|boolean` and return JSON).
  - (b) ⭐ remove the two buttons from `show.blade.php:171-181` and leave the endpoints (they are already routed; the edit form edits the same flags); or delete the two endpoints + controller methods as a separate team decision (D5: unrouted public methods become `abort(403, '...')` with a NOT ROUTED comment, never deleted).
  - (c) leave as is and record as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| *(none)* | Every finding MIC-01 … MIC-20 has a plan item above. |