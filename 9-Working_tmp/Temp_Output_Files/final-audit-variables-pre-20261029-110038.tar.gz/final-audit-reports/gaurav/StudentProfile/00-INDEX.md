# StudentProfile — Final Audit Index

Protocol: `.claude/rules/final-audit.md`.
⛔ Append a row to claim. Edit only your own row. Never rewrite this file.

| Controller | Status | B | H | M | L | Report | By | Updated |
|---|---|---|---|---|---|---|---|---|
| StudentProfileController | AUDITED | 1 | 3 | 1 | 4 | [01-report](StudentProfileController-NotUsed/01-report.md) | opencode | 2026-10-10 |
| StudentLeaveTypeController | AUDITED | 0 | 2 | 2 | 6 | [01-report](StudentLeaveTypeController-done/01-report.md) | opencode | 2026-10-10 |
| StudentReportController | AUDITED | 1 | 2 | 5 | 3 | [01-report](StudentReportController-done/01-report.md) | opencode | 2026-10-10 |
| StudentDashboardController | AUDITED | 0 | 1 | 2 | 2 | [01-report](StudentDashboardController-done/01-report.md) | opencode | 2026-10-10 |
| MedicalIncidentController | AUDITED | 2 | 5 | 9 | 4 | [01-report](MedicalIncidentController-done/01-report.md) | opencode | 2026-10-10 |
| StdLeaveController | AUDITED | 1 | 6 | 8 | 4 | [01-report](StdLeaveController-done/01-report.md) | opencode | 2026-10-10 |
| AttendanceController | AUDITED | 1 | 1 | 13 | 4 | [01-report](AttendanceController-done/01-report.md) | opencode | 2026-10-10 |
| StudentController | AUDITED | 4 | 7 | 22 | 10 | [01-report](StudentController-done/01-report.md) | opencode | 2026-10-10 |
