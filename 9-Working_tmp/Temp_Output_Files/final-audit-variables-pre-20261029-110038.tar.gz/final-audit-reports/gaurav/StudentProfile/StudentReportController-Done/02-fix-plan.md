# Fix Plan — StudentProfile / StudentReportController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/StudentProfile/app/Http/Controllers/StudentReportController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/StudentProfile/routes/web.php` | shared route file; no route change is planned |
| `config/permissionslist.php` | shared config; the permission already exists |
| `Modules/StudentProfile/app/Policies/StudentPolicy.php` | owned by the StudentController report |
| `Modules/StudentProfile/app/Models/StudentProfile.php`, `StudentAcademicSession.php`, `StudentAttendance.php`, `StudentHealthProfile.php`, `StudentDocument.php`, `Guardian.php`, `LeaveApplication.php`, `MedicalIncident.php`, `PreviousEducation.php` | owned by other reports; only usage was audited here |
| `resources/views/components/**` | shared UI components (breadcrumb, nav-tab) |
| `database/migrations/**` | never edited by this workflow |

## 1. Blockers reachable today

- [ ] **SRP-08** · B · MDL-05 · `Modules/StudentProfile/app/Models/Student.php:340` — override `getMediaModel()` so student photos stay in the tenant database.
  - **Touches:** `Modules/StudentProfile/app/Models/Student.php`
  - **Before** (`Student.php:340`):
    ```php
        public function registerMediaCollections(): void
    ```
  - **After:**
    ```php
        public function getMediaModel(): string
        {
            return \App\Models\TenantMedia::class;
        }

        public function registerMediaCollections(): void
    ```
  - **Verify:** `grep -n "getMediaModel" Modules/StudentProfile/app/Models/Student.php`
  - **Expect:** one match declaring `public function getMediaModel(): string`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

(empty — the two error/query fixes below are independent.)

## 3. Errors & transactions (F1/F2)

(empty — nothing to change; the controller and service have no catch and no write.)

## 4. Authorization (F3)

(empty — SRP-07 has no plan item; see §10.)

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **SRP-04** · M · RTE-03 · `Modules/StudentProfile/app/Http/Controllers/StudentReportController.php:211-222` — disable the two unrouted legacy methods per D5.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentReportController.php`
  - **Before** (`StudentReportController.php:211-214`):
    ```php
        public function combinedStudentReport(Request $request): View
        {
            return $this->index($request);
        }
    ```
  - **After:**
    ```php
        public function combinedStudentReport(Request $request): View
        {
            // NOT ROUTED — no route points at this method; kept for legacy compatibility (final-audit D5).
            abort(403, 'This report view is not available.');
        }
    ```
  - **Before** (`StudentReportController.php:219-222`):
    ```php
        public function classWiseStrengthReport(Request $request): View
        {
            return $this->index($request->merge(['tab' => 'student-strength']));
        }
    ```
  - **After:**
    ```php
        public function classWiseStrengthReport(Request $request): View
        {
            // NOT ROUTED — no route points at this method; kept for legacy compatibility (final-audit D5).
            abort(403, 'This report view is not available.');
        }
    ```
  - **Verify:** `grep -n "NOT ROUTED" Modules/StudentProfile/app/Http/Controllers/StudentReportController.php`
  - **Expect:** two output lines.
  - **Effort:** S

- [ ] **SRP-09** · M · TEN-04 · `Modules/StudentProfile/app/Models/Student.php:389-403` — fix the photo accessor: test the real column and build a tenant URL.
  - **Touches:** `Modules/StudentProfile/app/Models/Student.php`
  - **Before** (`Student.php:389-403`):
    ```php
        public function getPhotoUrlAttribute()
        {
            $media = $this->getFirstMedia('student_photo') ?: $this->getFirstMedia('user_img');

            if ($media) {
                return $media->getUrl();
            }

            // Fallback to old field or placeholder
            if ($this->first_media_id) {
                return asset('storage/students/' . $this->photo_file_name);
            } else {
                return asset('assets/images/avatar.png');
            }
        }
    ```
  - **After:**
    ```php
        public function getPhotoUrlAttribute()
        {
            $media = $this->getFirstMedia('student_photo') ?: $this->getFirstMedia('user_img');

            if ($media) {
                return $media->getUrl();
            }

            if ($this->photo_file_name) {
                return tenant_asset('storage/students/' . $this->photo_file_name);
            }

            return asset('assets/images/avatar.png');
        }
    ```
  - **Verify:** `grep -n "first_media_id" Modules/StudentProfile/app/Models/Student.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **SRP-01** · H · QRY-01 · `Modules/StudentProfile/app/Services/StudentAnalyticsService.php:712-722` — replace the per-student attendance query with one grouped query.
  - **Touches:** `Modules/StudentProfile/app/Services/StudentAnalyticsService.php`
  - **Before** (`StudentAnalyticsService.php:712-722`):
    ```php
            $sessions = $sessionsQuery->get();
            $queue = [];

            foreach ($sessions as $s) {
                $st = $s->student;
                if (!$st) continue;

                $attendances = StudentAttendance::where('academic_session_id', $sessionId)
                    ->where('student_id', $st->id)
                    ->orderByDesc('attendance_date')
                    ->get();
    ```
  - **After:**
    ```php
            $sessions = $sessionsQuery->get();
            $queue = [];

            $attendanceByStudent = StudentAttendance::where('academic_session_id', $sessionId)
                ->whereIn('student_id', $sessions->pluck('student_id')->filter()->unique()->all())
                ->get()
                ->groupBy('student_id');

            foreach ($sessions as $s) {
                $st = $s->student;
                if (!$st) continue;

                $attendances = $attendanceByStudent->get($st->id, collect());
    ```
  - **Verify:** `grep -n "where('student_id', \$st->id)" Modules/StudentProfile/app/Services/StudentAnalyticsService.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **SRP-02** · H · QRY-01 · `Modules/StudentProfile/app/Services/StudentAnalyticsService.php:346-369` — pre-fetch enrolled ids and attendance in two queries instead of two per section.
  - **Touches:** `Modules/StudentProfile/app/Services/StudentAnalyticsService.php`
  - **Before** (`StudentAnalyticsService.php:346-369`):
    ```php
            foreach ($classSections as $cs) {
                $studentIds = StudentAcademicSession::where('academic_session_id', $sessionId)
                    ->where('class_section_id', $cs->id)
                    ->where('is_current', 1)
                    ->pluck('student_id')
                    ->toArray();

                $enrolled = count($studentIds);
                if ($enrolled === 0) {
                    continue;
                }
                $totalEnrolledAll += $enrolled;

                $attQuery = StudentAttendance::where('academic_session_id', $sessionId)
                    ->whereIn('student_id', $studentIds);

                if (!empty($filters['start_date'])) {
                    $attQuery->whereDate('attendance_date', '>=', $filters['start_date']);
                }
                if (!empty($filters['end_date'])) {
                    $attQuery->whereDate('attendance_date', '<=', $filters['end_date']);
                }

                $attRecords = $attQuery->get();
    ```
  - **After:**
    ```php
            $enrolledBySection = StudentAcademicSession::where('academic_session_id', $sessionId)
                ->where('is_current', 1)
                ->whereIn('class_section_id', $classSections->pluck('id'))
                ->get(['student_id', 'class_section_id'])
                ->groupBy('class_section_id')
                ->map(fn ($rows) => $rows->pluck('student_id')->all());

            $attendanceQuery = StudentAttendance::where('academic_session_id', $sessionId)
                ->whereIn('student_id', $enrolledBySection->flatten()->unique()->values());

            if (!empty($filters['start_date'])) {
                $attendanceQuery->whereDate('attendance_date', '>=', $filters['start_date']);
            }
            if (!empty($filters['end_date'])) {
                $attendanceQuery->whereDate('attendance_date', '<=', $filters['end_date']);
            }

            $attendanceByStudent = $attendanceQuery->get()->groupBy('student_id');

            foreach ($classSections as $cs) {
                $studentIds = $enrolledBySection->get($cs->id, []);

                $enrolled = count($studentIds);
                if ($enrolled === 0) {
                    continue;
                }
                $totalEnrolledAll += $enrolled;

                $attRecords = collect($studentIds)
                    ->flatMap(fn ($studentId) => $attendanceByStudent->get($studentId, collect()));
    ```
  - **Verify:** `grep -n "StudentAcademicSession::where('academic_session_id', \$sessionId)" Modules/StudentProfile/app/Services/StudentAnalyticsService.php`
  - **Expect:** one match (the bulk pre-fetch), none inside the `foreach`.
  - **Effort:** M

## 7. Views (F10)

(empty)

## 8. Style (F12) — one item per file

(empty — SRP-11 has no plan item; see §10.)

## 9. Deferred / decisions

- [ ] **SRP-03** · M · DECISION · QRY-02 — should the reports hubs stop building every tab's dataset on every request?
  - **Why it is a decision:** behaviour change. The tabs are rendered server-side and switched client-side, so removing the non-active datasets needs a move to lazy per-tab loading, which is a new interaction pattern.
    (a) ⭐ Fix SRP-01/SRP-02 first, then accept the remaining cost and re-measure; revisit only if the page is still slow.
    (b) Move each hub to lazy AJAX loading per tab now (touches controller, routes and both Blade hubs).
    (c) Leave as is and record as accepted.
    ➜ Choice: ____
- [ ] **SRP-05** · M · DECISION · CTL-05 — extract the duplicated session-resolution block?
  - **Why it is a decision:** refactor. The shared block spans `index()` (lines 30-39) and `actionCenter()` (lines 96-104); extracting it changes the shape of both methods.
    (a) ⭐ Extract a private `resolveReportContext(Request $request): array` and call it from both methods.
    (b) Defer to the controller-split pass (D3).
    (c) Leave as is and record as accepted.
    ➜ Choice: ____
- [ ] **SRP-06** · M · DECISION · CTL-02 — split the five long service methods?
  - **Why it is a decision:** refactor of a class with live screens; a mistake here changes report numbers. No functional defect depends on it.
    (a) ⭐ Defer to a dedicated refactor pass; the SRP-01/SRP-02 fixes land independently.
    (b) Extract the per-report mapping into private methods now.
    (c) Leave as is and record as accepted.
    ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| SRP-07 | Only two occurrences of a correct permission string; centralising is opportunistic. Owner: this controller, no behaviour change. |
| SRP-10 | 27 relation methods need return types; best applied as one codemod across the model, not by hand in this pass. |
| SRP-11 | Enabling `declare(strict_types=1)` on a model with 1,825 live consumers can surface latent TypeErrors that D4 cannot test; deferred. |
