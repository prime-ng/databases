# Final Audit — Accounting / BankReconciliationMatchController

**Audited:** 2026-10-24 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php` (433 lines, 13 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/cheques-reconciliation?tab=bank-reconciliation-matches` (list) · `/accounting/bank-reconciliation-match/create` · `/accounting/bank-reconciliation-match/{id}` · `/accounting/bank-reconciliation-match/{id}/edit` · `/accounting/bank-reconciliation-match/trash/view` |
| Menu path | Accounting → Cheques Reconciliation (`accounting.menu.chequesReconciliation`) → **Bank Reconciliation Matches** tab (`bank-reconciliation-matches`) |
| Who uses it | Account Manager, Account Staff, Management, School Admin, Super Admin (measured: `sys_role_has_permissions_jnt` for `tenant.accounting.bank-reconciliation-match.%`) |
| What a user does here | Links one bank-statement line to one posted voucher line (a manual reconciliation match). The user can save it as Proposed or Confirmed, later confirm, reject or undo it, and restore or permanently delete a trashed match. Only a Confirmed match marks the voucher line as reconciled. |
| Tables written | `acc_bank_reconciliation_matches` (match row), `acc_bank_statement_entries` (`match_status`, `matched_amount`), `acc_voucher_items` (`is_reconciled`, `reconciled_at`, `bank_value_date`), `sys_activity_logs` (through `activityLog()`) |
| Tables read | `acc_bank_reconciliation_matches`, `acc_bank_reconciliations`, `acc_bank_statement_entries`, `acc_vouchers`, `acc_voucher_items`, `sys_users` (relation lookups) |
| Live data | Tenant `xyz_school_00000000000040008000_202627`: 4 matches (4 Confirmed, 0 Proposed, 0 trashed), 7 statement entries, 2 reconciliations, 98 voucher items |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**No, this controller is not production-ready.** The worst defect is BKRM-05: editing a confirmed match to point at a different statement entry or voucher line leaves the **old** rows marked `Matched` / `is_reconciled = true` forever, so the reconciliation screen silently shows money as reconciled twice. On top of that, all eight mutation methods flash the raw exception text (including SQL) to the user (BKRM-01) and use hand-written transactions (BKRM-04). The fixes are mechanical but touch most of the controller: roughly one to two days of careful work, then a re-audit.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 9 | 7 | 6 | 4 | 24 |

> `DECISION` counts plan items that need Tarun's choice (BKRM-09, BKRM-15, BKRM-18, BKRM-20). Those findings are already included in the B/H/M/L columns, so the row totals 24 findings.

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BKRM-01, BKRM-02, BKRM-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | BKRM-04, BKRM-05, BKRM-06, BKRM-07, BKRM-08 | F9 Queries/Perf | BKRM-20, BKRM-21 |
| F3 Authorization | BKRM-09 | F10 Views | clean |
| F4 Validation | BKRM-10, BKRM-11, BKRM-12, BKRM-13, BKRM-14 | F11 Security/Tenancy | clean |
| F5 Routes | BKRM-15 | F12 Style | BKRM-22, BKRM-23, BKRM-24 |
| F6 Controller shape | BKRM-16, BKRM-17, BKRM-18 | F13 Deep read | no new findings (answers reference BKRM-05 to BKRM-08, BKRM-14) |
| F7 Models | BKRM-19 | | |

## 3. Scope - every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php` | controller | 433 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/BankReconciliationMatch.php` | model | 96 | this report (registry pre-assigned 2026-10-19) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/BankReconciliationMatchRequest.php` | FormRequest | 112 | this report (registry pre-assigned 2026-10-19) | ✅ |
| 4 | `Modules/Accounting/app/Policies/BankReconciliationMatchPolicy.php` | policy | 46 | this report (not in the registry; read only, see BKRM-09) | ✅ |
| 5 | `Modules/Accounting/resources/views/bank-reconciliation-match/create.blade.php` | blade | 170 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/bank-reconciliation-match/edit.blade.php` | blade | 163 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/bank-reconciliation-match/show.blade.php` | blade | 257 | this report | ✅ |
| 8 | `Modules/Accounting/resources/views/bank-reconciliation-match/trash.blade.php` | blade | 77 | this report | ✅ |
| 9 | `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_bank-reconciliation-matches.blade.php` | blade (list tab) | 563 | ↗ `gaurav/Accounting/AccDashboardController` (row CLAIMED, may not be finished) | ↗ linked |
| 10 | `Modules/Accounting/app/Models/BankReconciliation.php` | model | 242 | ↗ `gaurav/Accounting/BankReconciliationController` | ↗ linked |
| 11 | `Modules/Accounting/app/Models/BankStatementEntry.php` | model | 176 | ↗ `gaurav/Accounting/BankStatementEntryController` | ↗ linked |
| 12 | `Modules/Accounting/app/Models/Voucher.php` | model | 415 | ↗ `gaurav/Accounting/VoucherController` (not yet audited) | ↗ linked |
| 13 | `Modules/Accounting/app/Models/VoucherItem.php` | model | 172 | unclaimed; only the columns this controller reads/writes were checked | ✅ usage |
| 14 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | model (base) | 74 | ↗ `gaurav/Accounting/AccountingStatusMasterController` | ↗ linked |
| 15 | `Modules/Accounting/app/Services/AccountingContext.php` | service | 110 | ↗ `gaurav/Accounting/AccountGroupController` | ↗ linked |
| 16 | `Modules/Accounting/routes/web.php` (lines 251-258) | route file | shared | ⚠ SHARED — read only, not audited as a class | ✅ read |
| 17 | `database/migrations/tenant/2026_09_16_100062_create_acc_bank_reconciliation_matches_table.php` | migration | 76 | read only (never edited) | ✅ read |
| 18 | `database/migrations/tenant/2026_09_16_130001_add_soft_deletes_and_is_active_to_accounting_tables.php` | migration | shared | read only (never edited) | ✅ read |
| 19 | `config/permissionslist.php` (line 642) | config | shared | ⚠ SHARED — read only | ✅ read |
| 20 | `app/Helpers/activityLog.php` | helper (common) | 52 | common — never claimed | ✅ read |

The Account Manager / Account Staff / Management / School Admin / Super Admin roles hold all ten permission keys on the live test tenant. The list tab itself is rendered by `AccDashboardController::chequesReconciliation()` (owned by that report); this report only checks how that view calls this controller's routes.

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/bank-reconciliation-match                    accounting.bank-reconciliation-match.index       BankReconciliationMatchController@index
POST      accounting/bank-reconciliation-match                    accounting.bank-reconciliation-match.store       BankReconciliationMatchController@store
GET|HEAD  accounting/bank-reconciliation-match/create             accounting.bank-reconciliation-match.create      BankReconciliationMatchController@create
GET|HEAD  accounting/bank-reconciliation-match/trash/view         accounting.bank-reconciliation-match.trashed     BankReconciliationMatchController@trashed
GET|HEAD  accounting/bank-reconciliation-match/{bank_reconciliation_match} accounting.bank-reconciliation-match.show BankReconciliationMatchController@show
PUT|PATCH accounting/bank-reconciliation-match/{bank_reconciliation_match} accounting.bank-reconciliation-match.update BankReconciliationMatchController@update
DELETE    accounting/bank-reconciliation-match/{bank_reconciliation_match} accounting.bank-reconciliation-match.destroy BankReconciliationMatchController@destroy
POST      accounting/bank-reconciliation-match/{bank_reconciliation_match}/confirm accounting.bank-reconciliation-match.confirm BankReconciliationMatchController@confirm
GET|HEAD  accounting/bank-reconciliation-match/{bank_reconciliation_match}/edit accounting.bank-reconciliation-match.edit BankReconciliationMatchController@edit
POST      accounting/bank-reconciliation-match/{bank_reconciliation_match}/reject accounting.bank-reconciliation-match.reject BankReconciliationMatchController@reject
POST      accounting/bank-reconciliation-match/{bank_reconciliation_match}/undo accounting.bank-reconciliation-match.undo BankReconciliationMatchController@undo
DELETE    accounting/bank-reconciliation-match/{id}/force-delete  accounting.bank-reconciliation-match.forceDelete BankReconciliationMatchController@forceDelete
GET|HEAD  accounting/bank-reconciliation-match/{id}/restore       accounting.bank-reconciliation-match.restore     BankReconciliationMatchController@restore
```

Every route carries `[web, Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains, Stancl\Tenancy\Middleware\InitializeTenancyByDomain, App\Http\Middleware\EnsureTenantIsActive, App\Http\Middleware\EnsureTenantHasModule:Accounting, Illuminate\Auth\Middleware\Authenticate, Illuminate\Auth\Middleware\EnsureEmailIsVerified]`.

Unrouted public methods: none. All 13 public methods have a route.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 21 | GET /accounting/bank-reconciliation-match | `tenant.accounting.bank-reconciliation-match.viewAny` | none | none | none | BKRM-16 |
| `create` | 28 | GET /accounting/bank-reconciliation-match/create | `tenant.accounting.bank-reconciliation-match.create` | none | none | none | BKRM-16, BKRM-17, BKRM-20 |
| `store` | 45 | POST /accounting/bank-reconciliation-match | `tenant.accounting.bank-reconciliation-match.create` | controller (manual) | `'Created'` | matches, statement entries, voucher items, activity log | BKRM-01, BKRM-02, BKRM-04, BKRM-11, BKRM-12 |
| `show` | 93 | GET /accounting/bank-reconciliation-match/{id} | `tenant.accounting.bank-reconciliation-match.view` | none | none | none | BKRM-16 |
| `edit` | 110 | GET /accounting/bank-reconciliation-match/{id}/edit | `tenant.accounting.bank-reconciliation-match.update` | none | none | none | BKRM-16, BKRM-17, BKRM-20 |
| `update` | 140 | PUT/PATCH /accounting/bank-reconciliation-match/{id} | `tenant.accounting.bank-reconciliation-match.update` | controller (manual) | `'Updated'` | matches, statement entries, voucher items, activity log | BKRM-01, BKRM-02, BKRM-04, BKRM-05, BKRM-06, BKRM-10, BKRM-12, BKRM-14 |
| `destroy` | 199 | DELETE /accounting/bank-reconciliation-match/{id} | `tenant.accounting.bank-reconciliation-match.delete` | controller (manual) | `'Deleted'` | matches, statement entries, voucher items, activity log | BKRM-01, BKRM-02, BKRM-04, BKRM-06, BKRM-08 |
| `confirm` | 246 | POST /accounting/bank-reconciliation-match/{id}/confirm | `tenant.accounting.bank-reconciliation-match.confirm` | controller (manual) | `'Confirmed'` | matches, statement entries, voucher items, activity log | BKRM-01, BKRM-02, BKRM-04, BKRM-13, BKRM-14 |
| `reject` | 289 | POST /accounting/bank-reconciliation-match/{id}/reject | `tenant.accounting.bank-reconciliation-match.reject` | controller (manual) | `'Rejected'` | matches, activity log | BKRM-01, BKRM-02, BKRM-04, BKRM-14 |
| `undo` | 321 | POST /accounting/bank-reconciliation-match/{id}/undo | `tenant.accounting.bank-reconciliation-match.undo` | controller (manual) | `'Undone'` | matches, statement entries, voucher items, activity log | BKRM-01, BKRM-02, BKRM-04, BKRM-06, BKRM-08, BKRM-14 |
| `trashed` | 373 | GET /accounting/bank-reconciliation-match/trash/view | `tenant.accounting.bank-reconciliation-match.restore` | none | none | none | BKRM-21 |
| `restore` | 382 | GET /accounting/bank-reconciliation-match/{id}/restore | `tenant.accounting.bank-reconciliation-match.restore` | controller (manual) | `'Restored'` | matches, activity log | BKRM-01, BKRM-02, BKRM-03, BKRM-04, BKRM-07 |
| `forceDelete` | 407 | DELETE /accounting/bank-reconciliation-match/{id}/force-delete | `tenant.accounting.bank-reconciliation-match.forceDelete` | controller (manual) | `'Deleted'` | matches, activity log | BKRM-01, BKRM-02, BKRM-03, BKRM-04 |

## 6. Findings

### F1 — Errors

#### BKRM-01 · B · ERR-01 — Raw exception text is flashed to the user on every mutation

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:87-89`, `:193-195`, `:240-242`, `:283-285`, `:315-317`, `:367-369`, `:401-403`, `:427-429`; methods `store`, `update`, `destroy`, `confirm`, `reject`, `undo`, `restore`, `forceDelete` |
| **Root cause** | Each catch appends `$e->getMessage()` to the flash message. Laravel's `QueryException` message contains the full SQL, table and column names. |
| **Consequence** | A duplicate match, a bad column value or a database outage shows the user a red banner containing the SQL statement instead of a safe message. |
| **Reproduce** | Submit the create modal twice with the same statement entry and voucher line; the `uq_acc_brm` violation is rendered in the red flash. |
| **Fix approach** | Remove every controller `try/catch` (D1) and let the central handler render the error. Keep only `DB::transaction(...)` closures. |
| **Plan item** | BKRM-01 and BKRM-05 and BKRM-07 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchController.php:85-90 — CURRENT (same shape in all eight methods)
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Bank Reconciliation Match', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'Failed to create match: ' . $e->getMessage());
        }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "getMessage"
87:Log::error('Failed to create Bank Reconciliation Match', ['error' => $e->getMessage()]);
89:return back()->withInput()->with('error', 'Failed to create match: ' . $e->getMessage());
193:Log::error('Failed to update Bank Reconciliation Match', ['id' => $bankReconciliationMatch->id, 'error' => $e->getMessage()]);
195:return back()->withInput()->with('error', 'Failed to update match: ' . $e->getMessage());
240:Log::error('Failed to delete Bank Reconciliation Match', ['id' => $bankReconciliationMatch->id, 'error' => $e->getMessage()]);
242:return back()->with('error', 'Failed to delete match: ' . $e->getMessage());
283:Log::error('Failed to confirm match', ['id' => $bankReconciliationMatch->id, 'error' => $e->getMessage()]);
285:return back()->with('error', 'Failed to confirm match: ' . $e->getMessage());
315:Log::error('Failed to reject match', ['id' => $bankReconciliationMatch->id, 'error' => $e->getMessage()]);
317:return back()->with('error', 'Failed to reject match: ' . $e->getMessage());
367:Log::error('Failed to undo match', ['id' => $bankReconciliationMatch->id, 'error' => $e->getMessage()]);
369:return back()->with('error', 'Failed to undo match: ' . $e->getMessage());
401:Log::error('Failed to restore match', ['id' => $id, 'error' => $e->getMessage()]);
403:return back()->with('error', 'Failed to restore match: ' . $e->getMessage());
427:Log::error('Failed to force delete match', ['id' => $id, 'error' => $e->getMessage()]);
429:return back()->with('error', 'Failed to delete match: ' . $e->getMessage());
```

#### BKRM-02 · M · ERR-05 — The catch logs only the message, so the trace is lost and D1 is broken

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception object, not its message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:87`, `:193`, `:240`, `:283`, `:315`, `:367`, `:401`, `:427` |
| **Root cause** | `Log::error('...', ['error' => $e->getMessage()])` stores a string, not the throwable. The surrounding `try/catch` is also the D1/ERR-00 violation: a Laravel controller should not catch at all. |
| **Consequence** | Support cannot see which line or query failed; the log line is only the database's one-line message. |
| **Reproduce** | Static only — every catch block is quoted at the lines above. |
| **Fix approach** | Remove the catches together with BKRM-01; the central handler logs the full throwable. |
| **Plan item** | none — covered by the BKRM-01, BKRM-05 and BKRM-07 rewrites (see §10) |

```php
// BankReconciliationMatchController.php:85-88 — CURRENT
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Bank Reconciliation Match', ['error' => $e->getMessage()]);
```

**Evidence**
```
PS> (Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "Log::error").Count
8
PS> (Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "DB::rollBack").Count
8
```

#### BKRM-03 · H · ERR-02 — `restore()` and `forceDelete()` turn a missing id into a redirect instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:386-404` (`restore`) and `:411-430` (`forceDelete`) |
| **Root cause** | `findOrFail()` sits inside the `try`, and the generic `catch (\Throwable $e)` catches `ModelNotFoundException` before Laravel can render the 404. |
| **Consequence** | Opening a restore/force-delete link for a row that no longer exists shows a red "Failed to restore match" flash and a 302, not the expected 404 page. |
| **Reproduce** | Open `/accounting/bank-reconciliation-match/999999/restore`. Expected 404; actual redirect with a red flash. |
| **Fix approach** | Move `findOrFail()` above the transaction and delete the catch. |
| **Plan item** | BKRM-07 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchController.php:386-389 — CURRENT
        DB::beginTransaction();
        try {
            $model = BankReconciliationMatch::onlyTrashed()->findOrFail($id);
            $model->restore();
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "findOrFail"
388:$model = BankReconciliationMatch::onlyTrashed()->findOrFail($id);
413:$model = BankReconciliationMatch::withTrashed()->findOrFail($id);
```

### F2 — Transactions and audit

#### BKRM-04 · M · TXN-02 — Eight mutations use manual `beginTransaction` / `commit` / `rollBack`

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => ...)`, never manual `beginTransaction` / `commit` / `rollBack`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:51`, `:81`, `:86`; `:147`, `:187`, `:192`; `:203`, `:234`, `:239`; `:252`, `:277`, `:282`; `:297`, `:309`, `:314`; `:329`, `:361`, `:366`; `:386`, `:396`, `:400`; `:411`, `:422`, `:426` |
| **Root cause** | Each mutation opens a transaction by hand. An early `return` between `beginTransaction()` and `commit()` would leave the connection open. |
| **Consequence** | A future edit that returns early inside the `try` leaks an open transaction; the pattern is also eight times more code than the closure form. |
| **Reproduce** | Static only — the counts below prove the pattern. |
| **Fix approach** | Replace each hand-written pair with `DB::transaction(function () { ... });` and return the redirect after the closure. |
| **Plan item** | BKRM-01 and BKRM-05 and BKRM-07 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchController.php:51-52 — CURRENT
        DB::beginTransaction();
        try {
```

**Evidence**
```
PS> (Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "DB::beginTransaction").Count
8
PS> (Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "DB::commit").Count
8
PS> (Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "DB::rollBack").Count
8
```

#### BKRM-05 · B · TXN-01 — Editing a confirmed match leaves the old statement entry and voucher line reconciled

| Field | Value |
| --- | --- |
| **Rule** | TXN-01 (B, raised from H) — *a multi-table write must leave every related table consistent* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:145-180`, method `update()` |
| **Root cause** | The method captures `$oldStatus` but never captures or releases the **old** `statement_entry_id` / `voucher_item_id`. After `update($validated)` it only marks the **new** rows. If the user changes the statement entry or voucher line, the old rows keep `match_status = Matched` and `is_reconciled = true`. |
| **Consequence** | The old bank line and voucher line stay marked reconciled with no match pointing at them, so the reconciliation difference is wrong and a line can never be matched again until someone edits the database. |
| **Reproduce** | Open an existing Confirmed match, change the Statement Entry dropdown (and/or Voucher Item) to a different row, save, then check the old statement entry: it still shows Matched and the old voucher line shows Reconciled. |
| **Fix approach** | Capture the old ids before the update; if the old status was Confirmed and the reference changed or the status moved away from Confirmed, release the old statement entry and voucher item (with sibling checks). |
| **Plan item** | BKRM-05 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchController.php:145-180 — CURRENT
        $oldStatus = $bankReconciliationMatch->status;

        DB::beginTransaction();
        try {
            if ($validated['status'] === 'Confirmed' && $oldStatus !== 'Confirmed') {
                $validated['confirmed_at'] = now();
                $validated['confirmed_by'] = auth()->id();
            }

            $bankReconciliationMatch->update($validated);

            // Re-sync statement entry and voucher item if confirmed
            if ($bankReconciliationMatch->status === 'Confirmed') {
                BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                    'match_status'   => 'Matched',
                    'matched_amount' => $bankReconciliationMatch->amount,
                ]);

                VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                    'is_reconciled'   => true,
                    'reconciled_at'   => now(),
                    'bank_value_date' => $bankReconciliationMatch->bank_value_date ?? now()->toDateString(),
                ]);
            } elseif ($oldStatus === 'Confirmed' && $bankReconciliationMatch->status !== 'Confirmed') {
                // If moved away from confirmed
                BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                    'match_status'   => $bankReconciliationMatch->status === 'Proposed' ? 'Proposed' : 'Unmatched',
                    'matched_amount' => 0.00,
                ]);

                VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                    'is_reconciled'   => false,
                    'reconciled_at'   => null,
                    'bank_value_date' => null,
                ]);
            }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "statement_entry_id|voucher_item_id" | Select-Object -First 8
62:BankStatementEntry::where('id', $match->statement_entry_id)->update([
67:VoucherItem::where('id', $match->voucher_item_id)->update([
154:$bankReconciliationMatch->update($validated);
158:BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
163:VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
170:BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
175:VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
```
No `$oldStatementEntryId` or `$oldVoucherItemId` exists in the method; the only `$old...` variable is `$oldStatus` at line 145.

#### BKRM-06 · H · TXN-01 — Release logic ignores sibling confirmed matches

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *the same multi-table write must keep every sibling match consistent* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:168-180` (`update`), `:219-223` (`destroy`), `:350-354` (`undo`) |
| **Root cause** | `update()` sets the new statement entry to `Unmatched` without checking whether another Confirmed match still uses it. `destroy()` and `undo()` check siblings only for the statement entry (lines 207-217, 338-348) and **never** for the voucher item. |
| **Consequence** | With two matches sharing a statement entry or a voucher line, un-confirming/deleting one flips the shared row to Unmatched / unreconciled while the other Confirmed match still claims it. The screen then shows a confirmed match whose underlying line is not reconciled. |
| **Reproduce** | Create two Confirmed matches on the same statement entry (different voucher lines), then delete one; its `bank_value_date`, `is_reconciled` and `matched_amount` are cleared even though the second match is still Confirmed. |
| **Fix approach** | Release a statement entry or voucher item only when no other Confirmed match (excluding this id) references it. Reuse one helper for both columns. |
| **Plan item** | BKRM-05 and BKRM-07 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchController.php:207-223 — CURRENT
                $hasOtherMatches = BankReconciliationMatch::where('statement_entry_id', $bankReconciliationMatch->statement_entry_id)
                    ->where('id', '!=', $bankReconciliationMatch->id)
                    ->where('status', 'Confirmed')
                    ->exists();

                if (!$hasOtherMatches) {
                    BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                        'match_status'   => 'Unmatched',
                        'matched_amount' => 0.00,
                    ]);
                }

                VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                    'is_reconciled'   => false,
                    'reconciled_at'   => null,
                    'bank_value_date' => null,
                ]);
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "hasOtherMatches"
207:$hasOtherMatches = BankReconciliationMatch::where('statement_entry_id', $bankReconciliationMatch->statement_entry_id)
212:if (!$hasOtherMatches) {
338:$hasOtherMatches = BankReconciliationMatch::where('statement_entry_id', $bankReconciliationMatch->statement_entry_id)
343:if (!$hasOtherMatches) {
```
Only `statement_entry_id` is checked; `voucher_item_id` is never part of the sibling test.

#### BKRM-07 · H · TXN-01 — Restoring a confirmed match does not re-apply its reconciliation state

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *a restore must leave the related tables in the state the restored row claims* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:382-405`, method `restore()` |
| **Root cause** | `destroy()` resets the statement entry and voucher item when no sibling Confirmed match remains. `restore()` only calls `$model->restore()` and writes the activity log; it never sets `match_status` / `is_reconciled` back. |
| **Consequence** | After restoring a match that was Confirmed when deleted, the match row says Confirmed but its bank line is Unmatched and its voucher line is not reconciled. The reconciliation totals stay wrong. |
| **Reproduce** | Delete a Confirmed match, open Trash, restore it, then view the match: status Confirmed; open the statement entry: Unmatched. |
| **Fix approach** | Inside the restore transaction, when the restored row is Confirmed, re-apply `Matched` / `is_reconciled` to its statement entry and voucher item, using the same values as `confirm()`. |
| **Plan item** | BKRM-07 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchController.php:386-395 — CURRENT
        DB::beginTransaction();
        try {
            $model = BankReconciliationMatch::onlyTrashed()->findOrFail($id);
            $model->restore();

            activityLog($model, 'Restored', [
                'message'      => 'Reconciliation match restored #' . $model->id,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "restore\(\)|BankStatementEntry::|VoucherItem::" | Select-String -Pattern "38[0-9]|39[0-9]|40[0-9]"
388:$model = BankReconciliationMatch::onlyTrashed()->findOrFail($id);
389:$model->restore();
```
No `BankStatementEntry` or `VoucherItem` write appears between lines 382 and 405.

#### BKRM-08 · M · TXN-06 — `destroy()` and `undo()` check-then-act without a lock

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:207-217` (`destroy`), `:338-348` (`undo`) |
| **Root cause** | `exists()` counts other Confirmed matches and the following `update()` trusts that answer. No `lockForUpdate()` is taken and no DB constraint enforces "at least one confirmed match". |
| **Consequence** | Two users undoing/deleting two Confirmed matches on the same statement entry at the same time can both see the other as still Confirmed and both skip the reset, leaving an entry Matched with no Confirmed match. |
| **Reproduce** | Concurrency only — requires two simultaneous requests (static proof is the missing lock). |
| **Fix approach** | Lock the statement entry row (`BankStatementEntry::whereKey(...)->lockForUpdate()->first()`) inside the transaction before the sibling check, or move the release into one `ReconciliationService` method that locks. |
| **Plan item** | BKRM-07 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchController.php:206-213 — CURRENT
            if ($bankReconciliationMatch->status === 'Confirmed') {
                $hasOtherMatches = BankReconciliationMatch::where('statement_entry_id', $bankReconciliationMatch->statement_entry_id)
                    ->where('id', '!=', $bankReconciliationMatch->id)
                    ->where('status', 'Confirmed')
                    ->exists();

                if (!$hasOtherMatches) {
                    BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "lockForUpdate"
PS>
```
The second command printed nothing: no row lock is used anywhere in the controller.

### F3 — Authorization

#### BKRM-09 · M · AUTH-06 — The registered policy is never consulted; permission strings are duplicated

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place, not repeated as literals* |
| **Where** | `Modules/Accounting/app/Policies/BankReconciliationMatchPolicy.php:12-45`; `Modules/Accounting/app/Providers/AccountingServiceProvider.php:171`; controller gates at `:23`, `:30`, `:47`, `:95`, `:112`, `:142`, `:201`, `:248`, `:291`, `:323`, `:375`, `:384`, `:409` |
| **Root cause** | The provider registers `Gate::policy(BankReconciliationMatch::class, BankReconciliationMatchPolicy::class)`, but every controller check is `Gate::authorize('tenant.accounting.bank-reconciliation-match.*')`. A permission string is handled by the permission gate, never by the model policy, so the policy is dead for this screen. |
| **Consequence** | Two copies of the same seven permission names drift apart; a permission renamed in the policy but not the controller (or the reverse) fails silently. |
| **Reproduce** | Static only — `grep` finds the policy name only in the provider and its own file. |
| **Fix approach** | Decide: delete the dead policy and its registration, or switch the controller to `$this->authorize('update', $match)` style and keep one source. |
| **Plan item** | BKRM-09 in `02-fix-plan.md` §9 (DECISION) |

```php
// BankReconciliationMatchPolicy.php:12-17 — CURRENT
    public function viewAny(User $user): bool
    {
        return $user->can('tenant.accounting.bank-reconciliation-match.viewAny');
    }
```

**Evidence**
```
PS> Get-ChildItem -Recurse "Modules\Accounting\app" -Filter "*.php" | ForEach-Object { $m = Select-String -Path $_.FullName -Pattern "BankReconciliationMatchPolicy" -SimpleMatch; if($m){ $_.Name + ":" + ($m.LineNumber -join ',') } }
BankReconciliationMatchPolicy.php:10
AccountingServiceProvider.php:66,171
```
The policy is referenced only by the service provider, not by the controller.

### F4 — Validation and input

#### BKRM-10 · H · VAL-05 — Audit fields are accepted from the client and mass-assigned

| Field | Value |
|---|---|
| **Rule** | VAL-05 (H) — *every field written is typed and controlled; client input must not set audit fields* |
| **Where** | `Modules/Accounting/app/Http/Requests/BankReconciliationMatchRequest.php:29-34`; `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:154` |
| **Root cause** | The rules allow `confirmed_at`, `confirmed_by`, `undone_at`, `undone_by`, and `update()` passes the whole `validated()` array to `update()`. A user can set those fields on a Proposed match even though the controller only sets them on the Confirmed branch. |
| **Consequence** | A user with update permission can forge "confirmed by" and "undone by" audit values, producing a fake approval trail. |
| **Reproduce** | Edit a Proposed match and add `confirmed_by=1&confirmed_at=2026-01-01 00:00:00` to the PUT body; the values are stored. |
| **Fix approach** | Remove the four audit fields from `rules()`; the controller sets them from `auth()->id()` and `now()` only. |
| **Plan item** | BKRM-10 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchRequest.php:29-34 — CURRENT
            'confirmed_at'        => 'nullable|date',
            'confirmed_by'        => 'nullable|integer',
            'rejected_reason'     => 'required_if:status,Rejected|nullable|string|max:500',
            'undone_at'           => 'nullable|date',
            'undone_by'           => 'nullable|integer',
            'undo_reason'         => 'required_if:status,Undone|nullable|string|max:500',
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Requests\BankReconciliationMatchRequest.php" -Pattern "confirmed_at|confirmed_by|undone_at|undone_by"
29:'confirmed_at'        => 'nullable|date',
30:'confirmed_by'        => 'nullable|integer',
32:'undone_at'           => 'nullable|date',
33:'undone_by'           => 'nullable|integer',
```

#### BKRM-11 · H · VAL-04 — No uniqueness rule mirrors the `uq_acc_brm` index

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the real DB unique index* |
| **Where** | `Modules/Accounting/app/Http/Requests/BankReconciliationMatchRequest.php:18-36`; index at `database/migrations/tenant/2026_09_16_100062_create_acc_bank_reconciliation_matches_table.php:43` |
| **Root cause** | The table has `unique(['statement_entry_id', 'voucher_item_id'])`, but the FormRequest has no `unique` rule for that pair. The duplicate reaches the database and throws a `QueryException`. |
| **Consequence** | Re-submitting the same pair shows the raw SQL error (BKRM-01) instead of a field-level "this pair is already matched" message. |
| **Reproduce** | Submit the create modal twice with the same statement entry and voucher line. |
| **Fix approach** | Add a `Rule::unique` on `statement_entry_id` scoped by `voucher_item_id`, ignoring the current model on update. |
| **Plan item** | BKRM-10 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchRequest.php:19-22 — CURRENT (no unique rule)
            'reconciliation_id'   => 'required|exists:acc_bank_reconciliations,id',
            'statement_entry_id'  => 'required|exists:acc_bank_statement_entries,id',
            'voucher_item_id'     => 'required|exists:acc_voucher_items,id',
            'voucher_id'          => 'required|exists:acc_vouchers,id',
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Requests\BankReconciliationMatchRequest.php" -Pattern "unique"
PS>
PS> Select-String -Path "database\migrations\tenant\2026_09_16_100062_create_acc_bank_reconciliation_matches_table.php" -Pattern "unique\("
43:$table->unique(['statement_entry_id', 'voucher_item_id'], 'uq_acc_brm');
```

#### BKRM-12 · H · VAL-07 — No cross-field check that the records belong together

| Field | Value |
|---|---|
| **Rule** | VAL-07 (H, raised from M) — *cross-field business checks belong in the FormRequest* |
| **Where** | `Modules/Accounting/app/Http/Requests/BankReconciliationMatchRequest.php:18-36` |
| **Root cause** | `reconciliation_id`, `statement_entry_id` and `voucher_item_id` are validated only with `exists`. Nothing checks that the statement entry belongs to the chosen reconciliation, or that the voucher line is on that reconciliation's `bank_ledger_id`. The create/edit dropdowns are independent. |
| **Consequence** | A user can link a statement entry from one bank account to a voucher line from another, producing a reconciliation that points at unrelated records and a wrong difference. |
| **Reproduce** | In the create modal, choose Reconciliation A and a Statement Entry that belongs to Reconciliation B, then save. |
| **Fix approach** | Add an `after()` hook that compares `BankStatementEntry::reconciliation_id` with `reconciliation_id` and `VoucherItem::ledger_id` with `BankReconciliation::bank_ledger_id`, adding a field error. |
| **Plan item** | BKRM-10 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchRequest.php:19-21 — CURRENT
            'reconciliation_id'   => 'required|exists:acc_bank_reconciliations,id',
            'statement_entry_id'  => 'required|exists:acc_bank_statement_entries,id',
            'voucher_item_id'     => 'required|exists:acc_voucher_items,id',
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Requests\BankReconciliationMatchRequest.php" -Pattern "reconciliation_id"
19:'reconciliation_id'   => 'required|exists:acc_bank_reconciliations,id',
76:$reconId = $this->input('reconciliation_id');
```
The only other use is the `prepareForValidation()` lookup; no comparison with `statement_entry_id` exists.

#### BKRM-13 · H · VAL-05 — `confirm()` writes an unvalidated `bank_value_date`

| Field | Value |
|---|---|
| **Rule** | VAL-05 (H) — *a write path with no validation for a field is high* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:246-259` |
| **Root cause** | `confirm()` reads `$request->input('bank_value_date', ...)` and writes it to `acc_bank_reconciliation_matches.bank_value_date` and `acc_voucher_items.bank_value_date` without a validation rule. |
| **Consequence** | A crafted POST with `bank_value_date=not-a-date` reaches the database; MySQL either rejects it (500) or stores a coerced value, and the voucher line gets the wrong clearance date. |
| **Reproduce** | POST to `/accounting/bank-reconciliation-match/{id}/confirm` with `bank_value_date=abc`. |
| **Fix approach** | Validate `bank_value_date` as `nullable|date` at the top of `confirm()` before the status guard. |
| **Plan item** | BKRM-01 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchController.php:250 — CURRENT
        $bankValueDate = $request->input('bank_value_date', $bankReconciliationMatch->bank_value_date ?? now()->toDateString());
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "bankValueDate = "
250:$bankValueDate = $request->input('bank_value_date', $bankReconciliationMatch->bank_value_date ?? now()->toDateString());
```

#### BKRM-14 · H · VAL-07 — `confirm` / `reject` / `undo` do not enforce legal status transitions

| Field | Value |
|---|---|
| **Rule** | VAL-07 (H, raised from M) — *a business state check must be enforced, not left to the view* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:246-259` (`confirm`), `:289-302` (`reject`), `:321-336` (`undo`) |
| **Root cause** | None of the three methods checks the current status. The parallel `ReconciliationService::confirmMatch()` / `rejectMatch()` / `undoMatch()` does (`throw_unless($match->status === 'Proposed', ...)` at lines 143, 179, 200). The controller bypasses those guards. |
| **Consequence** | A direct POST can reject a Confirmed match: `reject()` sets `status = Rejected` and leaves the statement entry Matched and the voucher line reconciled, so a rejected match still counts as reconciled. A direct POST can also re-confirm an Undone match. |
| **Reproduce** | POST to `/accounting/bank-reconciliation-match/{confirmed-id}/reject` with a reason; the match becomes Rejected but its statement entry stays Matched. |
| **Fix approach** | Add the same `throw_unless(... \DomainException ...)` guards: confirm/reject only from `Proposed`, undo only from `Confirmed`. |
| **Plan item** | BKRM-01 in `02-fix-plan.md` §1 |

```php
// BankReconciliationMatchController.php:246-259 — CURRENT (no status check)
    public function confirm(Request $request, BankReconciliationMatch $bankReconciliationMatch)
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.confirm');

        $bankValueDate = $request->input('bank_value_date', $bankReconciliationMatch->bank_value_date ?? now()->toDateString());

        DB::beginTransaction();
        try {
            $bankReconciliationMatch->update([
                'status'          => 'Confirmed',
                'confirmed_at'    => now(),
                'confirmed_by'    => auth()->id(),
                'bank_value_date' => $bankValueDate,
            ]);
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Services\ReconciliationService.php" -Pattern "throw_unless"
143:throw_unless($match->status === 'Proposed', \DomainException::class, 'Only proposed matches can be confirmed.');
179:throw_unless($match->status === 'Proposed', \DomainException::class, 'Only proposed matches can be rejected.');
200:throw_unless($match->status === 'Confirmed', \DomainException::class, 'Only confirmed matches can be undone.');
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "DomainException|throw_unless"
PS>
```
The controller has no transition guard at all.

### F5 — Routes

#### BKRM-15 · H · RTE-01 — Restore is a GET route that changes state

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:253` |
| **Root cause** | `Route::get('/bank-reconciliation-match/{id}/restore', ...)` performs `$model->restore()`. |
| **Consequence** | A browser prefetch, a crawler or a shared link can restore a trashed match without a CSRF token or a confirmation. |
| **Reproduce** | Open `/accounting/bank-reconciliation-match/{trashed-id}/restore` directly in the address bar; the row is restored. |
| **Fix approach** | Change the verb to `Route::post(...)` (same URI and name). The shared `action-trashed` component already reads the route verb and emits `@csrf` for POST. |
| **Plan item** | BKRM-15 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// Modules/Accounting/routes/web.php:253 — CURRENT
Route::get('/bank-reconciliation-match/{id}/restore', [BankReconciliationMatchController::class, 'restore'])->name('bank-reconciliation-match.restore');
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "bank-reconciliation-match/.*restore"
253:Route::get('/bank-reconciliation-match/{id}/restore', [BankReconciliationMatchController::class, 'restore'])->name('bank-reconciliation-match.restore');
```

### F6 — Controller shape

#### BKRM-16 · L · CTL-04 — Ten of thirteen public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:21`, `:28`, `:45`, `:93`, `:110`, `:140`, `:199`, `:246`, `:289`, `:321` |
| **Root cause** | Only `trashed()`, `restore()` and `forceDelete()` declare a return type. |
| **Consequence** | A reader cannot tell a redirect from a view without tracing the body; static analysis is weaker. |
| **Reproduce** | Static only — the signatures are quoted below. |
| **Fix approach** | Add `: \Illuminate\View\View` / `: \Illuminate\Http\RedirectResponse` to the ten methods. |
| **Plan item** | BKRM-16 in `02-fix-plan.md` §5 |

```php
// BankReconciliationMatchController.php:21-45 — CURRENT
    public function index()
    public function create()
    public function store(BankReconciliationMatchRequest $request)
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "public function" | ForEach-Object { $_.Line.Trim() }
public function index()
public function create()
public function store(BankReconciliationMatchRequest $request)
public function show(BankReconciliationMatch $bankReconciliationMatch)
public function edit(BankReconciliationMatch $bankReconciliationMatch)
public function update(BankReconciliationMatchRequest $request, BankReconciliationMatch $bankReconciliationMatch)
public function destroy(BankReconciliationMatch $bankReconciliationMatch)
public function confirm(Request $request, BankReconciliationMatch $bankReconciliationMatch)
public function reject(Request $request, BankReconciliationMatch $bankReconciliationMatch)
public function undo(Request $request, BankReconciliationMatch $bankReconciliationMatch)
public function trashed(): \Illuminate\View\View
public function restore($id): \Illuminate\Http\RedirectResponse
public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

#### BKRM-17 · M · CTL-10 — `create()` and `edit()` load `$vouchers` that no view uses

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:34` (`create`), `:126` (`edit`), `:42` and `:137` (the `compact`) |
| **Root cause** | Both methods query up to 100 posted vouchers and pass `$vouchers` to the view, but none of the four blades references it. |
| **Consequence** | Every create/edit page runs one unnecessary `acc_vouchers` query and hydrates 100 models for nothing. |
| **Reproduce** | Static only — the blade grep below returns zero. |
| **Fix approach** | Delete the `$vouchers` query and remove it from both `compact()` calls. |
| **Plan item** | BKRM-16 in `02-fix-plan.md` §5 |

```php
// BankReconciliationMatchController.php:34-42 — CURRENT
        $vouchers         = Voucher::where('status', 'Posted')->orderByDesc('voucher_date')->take(100)->get();
        $voucherItems     = VoucherItem::with(['voucher.voucherType', 'ledger'])
            ->where('voucher_status', 'Posted')
            ->where('is_reconciled', false)
            ->orderByDesc('voucher_date')
            ->take(100)
            ->get();

        return view('accounting::bank-reconciliation-match.create', compact('reconciliations', 'statementEntries', 'vouchers', 'voucherItems'));
```

**Evidence**
```
PS> Get-ChildItem "Modules\Accounting\resources\views\bank-reconciliation-match\*.blade.php" | ForEach-Object { $m=(Select-String -Path $_.FullName -Pattern '\$vouchers' -AllMatches | Measure-Object).Count; "$($_.Name): $m" }
create.blade.php: 0
edit.blade.php: 0
show.blade.php: 0
trash.blade.php: 0
```

#### BKRM-18 · M · CTL-05 — The reconciliation-state block is copy-pasted four times and duplicates `ReconciliationService`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste; one implementation per operation* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:61-72`, `:157-180`, `:261-270`, `:343-354`; parallel service at `Modules/Accounting/app/Services/ReconciliationService.php:141-230` |
| **Root cause** | The "mark statement entry Matched + voucher item reconciled" block is written four times with small differences. The module already has `ReconciliationService::confirmMatch()`, `rejectMatch()` and `undoMatch()` doing the same operations with status guards. |
| **Consequence** | The two implementations disagree: the service enforces transitions and does not set `matched_amount`, the controller does not enforce transitions and does. Fixing one does not fix the other. |
| **Reproduce** | Static only — compare the quoted controller blocks with the service methods. |
| **Fix approach** | Defer to the service-adoption decision; until then keep the corrected controller code from BKRM-01/05/07 and record the duplication. |
| **Plan item** | BKRM-18 in `02-fix-plan.md` §9 (DECISION) |

```php
// BankReconciliationMatchController.php:61-72 — CURRENT (one of four copies)
            if ($match->status === 'Confirmed') {
                BankStatementEntry::where('id', $match->statement_entry_id)->update([
                    'match_status'   => 'Matched',
                    'matched_amount' => $match->amount,
                ]);

                VoucherItem::where('id', $match->voucher_item_id)->update([
                    'is_reconciled'   => true,
                    'reconciled_at'   => now(),
                    'bank_value_date' => $match->bank_value_date ?? now()->toDateString(),
                ]);
            }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "'match_status'   => 'Matched'"
63:'match_status'   => 'Matched',
159:'match_status'   => 'Matched',
262:'match_status'   => 'Matched',
```

### F7 — Models

#### BKRM-19 · L · MDL-04 — Relationships and scopes have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed* |
| **Where** | `Modules/Accounting/app/Models/BankReconciliationMatch.php:45`, `:50`, `:55`, `:60`, `:65`, `:70`, `:75`, `:82`, `:87`, `:92` |
| **Root cause** | The seven `belongsTo` methods and three scopes omit their return types. |
| **Consequence** | IDE and static analysis cannot resolve the relation target; a wrong relation class is only found at runtime. |
| **Reproduce** | Static only — the signatures are quoted below. |
| **Fix approach** | Add `: \Illuminate\Database\Eloquent\Relations\BelongsTo` to the seven relations and `: \Illuminate\Database\Eloquent\Builder` to the scopes. |
| **Plan item** | BKRM-19 in `02-fix-plan.md` §5 |

```php
// BankReconciliationMatch.php:45-48 — CURRENT
    public function reconciliation()
    {
        return $this->belongsTo(BankReconciliation::class);
    }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Models\BankReconciliationMatch.php" -Pattern "public function" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
45:public function reconciliation()
50:public function statementEntry()
55:public function voucherItem()
60:public function voucher()
65:public function confirmedByUser()
70:public function undoneByUser()
75:public function creator()
82:public function scopeActive($query)
87:public function scopeConfirmed($query)
92:public function scopeProposed($query)
```

### F8 — Services and jobs

clean — the controller injects no service and dispatches no job. Proved with `Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "Service|Job|dispatch|Mail|Notification"` → no output. The duplication of service logic is recorded as BKRM-18.

### F9 — Queries and performance

#### BKRM-20 · M · QRY-15 — `create()` and `edit()` load every reconciliation and unmatched entry for a dropdown

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *do not load every row of a big table for a form* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:32-33` (`create`), `:124-125` (`edit`) |
| **Root cause** | The dropdown queries use `->get()` with no limit for `BankReconciliation` and (in `create`) for `BankStatementEntry`. Only `VoucherItem` is capped at 100. |
| **Consequence** | On a busy tenant the create page hydrates thousands of reconciliations and statement entries before it renders; the page slows down as the school's history grows. |
| **Reproduce** | Static only — the queries are quoted below; live tenant has only 2 reconciliations and 7 entries, so the cost is latent today. |
| **Fix approach** | Defer to a searchable/capped dropdown pass; a mechanical cap can hide valid options. |
| **Plan item** | BKRM-20 in `02-fix-plan.md` §9 (DECISION) |

```php
// BankReconciliationMatchController.php:32-33 — CURRENT
        $reconciliations  = BankReconciliation::with('bankLedger')->where('status', '!=', 'Completed')->get();
        $statementEntries = BankStatementEntry::whereIn('match_status', ['Unmatched', 'Proposed'])->get();
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "BankReconciliation::|BankStatementEntry::" | Select-Object -First 4
32:$reconciliations  = BankReconciliation::with('bankLedger')->where('status', '!=', 'Completed')->get();
33:$statementEntries = BankStatementEntry::whereIn('match_status', ['Unmatched', 'Proposed'])->get();
124:$reconciliations  = BankReconciliation::with('bankLedger')->get();
125:$statementEntries = BankStatementEntry::where('reconciliation_id', $bankReconciliationMatch->reconciliation_id)->get();
```

#### BKRM-21 · L · QRY-02 — The trash list paginates at 15, not the project standard 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (L, lowered from H) — *the list is paginated, but the project standard is 10 per page* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php:377` |
| **Root cause** | `->paginate(15)`. |
| **Consequence** | The trash tab shows 15 rows while every other list in the module shows 10; the page name is not set either. |
| **Reproduce** | Open `/accounting/bank-reconciliation-match/trash/view` with more than 10 trashed rows. |
| **Fix approach** | Change to `->paginate(10)`. |
| **Plan item** | BKRM-16 in `02-fix-plan.md` §5 |

```php
// BankReconciliationMatchController.php:377 — CURRENT
        $matches = BankReconciliationMatch::onlyTrashed()->with(['reconciliation.bankLedger', 'statementEntry'])->orderByDesc('created_at')->paginate(15);
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "paginate\("
377:$matches = BankReconciliationMatch::onlyTrashed()->with(['reconciliation.bankLedger', 'statementEntry'])->orderByDesc('created_at')->paginate(15);
```

### F10 — Views

clean — no queries, no `{!! !!}`, and every relation used in the four own blades is eager-loaded by `show()`/`edit()`/`trashed()`. Proved with `Get-ChildItem "Modules\Accounting\resources\views\bank-reconciliation-match\*.blade.php" | ForEach-Object { Select-String -Path $_.FullName -Pattern "::|->where\(|->get\(\)|DB::|\{!!" }` → only HTML comments matched. The list tab partial is owned by `AccDashboardController` (linked, not re-audited).

### F11 — Security and tenancy

clean — no `env()`, no hard-coded ids, no secrets in logs, and every route is inside the tenancy + auth middleware group. Proved with `Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "env\(|\?\? 1|Log::(info|debug)\(\$request"` → no output. The raw SQL leak is recorded once as BKRM-01.

### F12 — Style

#### BKRM-22 · L · STY-02 — Controller is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php` (whole file) |
| **Root cause** | `pint --test` reports `fully_qualified_strict_types`, `concat_space`, `method_chaining_indentation`, `not_operator_with_successor_space`, `ordered_imports`, `binary_operator_spaces`, `single_blank_line_at_eof`. |
| **Consequence** | The file fails the project's formatting gate and will be reformatted by the next `--dirty` run. |
| **Reproduce** | Run `vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" --format agent`. |
| **Fix approach** | Run Pint on the file after the code items land. |
| **Plan item** | BKRM-22 in `02-fix-plan.md` §8 |

```php
// Current evidence only; the fix is a formatter run, not a hand edit.
// vendor\bin\pint "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" --format agent
```

**Evidence**
```
PS> vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\BankReconciliationMatchController.php","fixers":["fully_qualified_strict_types","concat_space","method_chaining_indentation","not_operator_with_successor_space","ordered_imports","binary_operator_spaces","single_blank_line_at_eof"]}]}
```

#### BKRM-23 · L · STY-02 — FormRequest is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Http/Requests/BankReconciliationMatchRequest.php` |
| **Root cause** | `pint --test` reports `fully_qualified_strict_types`, `not_operator_with_successor_space`, `binary_operator_spaces`. |
| **Consequence** | The request file fails the formatting gate. |
| **Reproduce** | Run `vendor\bin\pint --test "Modules\Accounting\app\Http\Requests\BankReconciliationMatchRequest.php" --format agent`. |
| **Fix approach** | Run Pint on the file after BKRM-10 lands. |
| **Plan item** | BKRM-23 in `02-fix-plan.md` §8 |

```php
// Current evidence only; the fix is a formatter run, not a hand edit.
// vendor\bin\pint "Modules\Accounting\app\Http\Requests\BankReconciliationMatchRequest.php" --format agent
```

**Evidence**
```
PS> vendor\bin\pint --test "Modules\Accounting\app\Http\Requests\BankReconciliationMatchRequest.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\BankReconciliationMatchRequest.php","fixers":["fully_qualified_strict_types","not_operator_with_successor_space","binary_operator_spaces"]}]}
```

#### BKRM-24 · L · STY-02 — Model is not Pint-clean and imports an unused `BaseModel`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Models/BankReconciliationMatch.php:7` |
| **Root cause** | `use App\Models\BaseModel;` is never referenced. Pint also reports `fully_qualified_strict_types`, `single_line_after_imports`, `binary_operator_spaces`. |
| **Consequence** | The model fails the formatting gate and carries a misleading import. |
| **Reproduce** | Run `vendor\bin\pint --test "Modules/Accounting/app/Models/BankReconciliationMatch.php" --format agent`. |
| **Fix approach** | Run Pint on the file after BKRM-19 lands. |
| **Plan item** | BKRM-24 in `02-fix-plan.md` §8 |

```php
// BankReconciliationMatch.php:7 — CURRENT
use App\Models\BaseModel;
```

**Evidence**
```
PS> vendor\bin\pint --test "Modules\Accounting\app\Models\BankReconciliationMatch.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\BankReconciliationMatch.php","fixers":["fully_qualified_strict_types","no_unused_imports","single_line_after_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1. Overwrites data it should not? | 2. Deletes before replacement stored? | 3. Duplicate implementation? | 4. Soft-delete × unique trap? | 5. Race? | 6. Authorization hole? | 7. Message lies? | 8. Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | BKRM-12 (can link unrelated entry/line) | ok | BKRM-18 | BKRM-11 (unique index includes trashed rows; no rule) | ok | ok (gated `create`) | BKRM-01 | ok |
| `update` | BKRM-05 (old refs never released) | ok | BKRM-18 | BKRM-11 | ok | BKRM-10 (audit fields) | ok | ok |
| `destroy` | BKRM-06 (voucher item cleared despite sibling) | ok | BKRM-18 | ok | BKRM-08 | ok (gated `delete`) | ok | ok |
| `confirm` | BKRM-14 (re-confirms any status) | ok | BKRM-18 | ok | ok | BKRM-13 (unvalidated date) | ok | ok |
| `reject` | BKRM-14 (rejects a Confirmed match, leaves it reconciled) | ok | ok | ok | ok | ok (gated `reject`) | ok | ok |
| `undo` | BKRM-06 (voucher item cleared despite sibling) | ok | BKRM-18 | ok | BKRM-08 | BKRM-14 | ok | ok |
| `restore` | BKRM-07 (state not re-applied) | ok | ok | BKRM-11 | ok | ok (gated `restore`) | ok | ok |
| `forceDelete` | BKRM-07 (does not release a Confirmed row) | ok | ok | ok | ok | ok (gated `forceDelete`) | ok | ok |

Question 2 is `ok` for every method because the replacement values are written before the old row is removed; the defect in BKRM-07 is a **missing** write, not an ordering problem. Question 8 is `ok`; the standalone `create` page duplicates the create modal, but the controller method is routed and functional, so it is recorded as an observation rather than a finding.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | `updated_by = Auth::id() ?? 1` uses a hard-coded user id when unauthenticated. | SEC-03 | `gaurav/Accounting/AccountingStatusMasterController` (owner) |
| `Modules/Accounting/app/Models/BankStatementEntry.php` and `VoucherItem.php` | Both `use SoftDeletes` while already extending `BaseAccountingModel`, which also uses the trait. Redundant but not harmful. | MDL-03 / STY | `gaurav/Accounting/BankStatementEntryController` and the unclaimed VoucherItem owner |
| `Modules/Accounting/app/Services/ReconciliationService.php` | `confirmMatch()` / `rejectMatch()` / `undoMatch()` implement the same operations with status guards but no `matched_amount`; the controller's copy disagrees (BKRM-18). | SVC-04 | unclaimed service; first controller that reaches it should claim it |
| `Modules/Accounting/app/Policies/BankReconciliationMatchPolicy.php` | Registered in `AccountingServiceProvider` but only string gates are used (BKRM-09). | AUTH-06 | this report flags it; the decision item is in `02-fix-plan.md` §9 |
| `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_bank-reconciliation-matches.blade.php` | The list tab that calls `confirm`, `reject`, `undo`, `destroy` and the create modal is rendered by `AccDashboardController`, not this controller. Its queries and export config are that report's scope. | VIEW | `gaurav/Accounting/AccDashboardController` (row CLAIMED) |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:73` | `index()` redirects to a page gated by `tenant.accounting.dashboard.view`. All five match roles currently hold it, so no user is blocked today. | AUTH | `gaurav/Accounting/AccDashboardController` |

## 8. Not covered, and why

- **Scanner and self-check were skipped.** `final-audit-reports/_tools/scanfilter.py` and `selfcheck.py` are missing, and `scan.php` must not be run under this audit's tooling override. F1-F13 were worked manually with `read`/`grep`/`Select-String` and the commands quoted above. No scanner row was available to cross-check.
- **No tests were run** (D4). The FormRequest was not executed against a live payload; the cross-field findings are proved from the rules, not from a request run.
- **Blades were not rendered in a browser.** They were checked statically for queries, `{!! !!}`, eager loads and route names. A visual check of the confirm/reject/undo modals is still needed.
- **`ReconciliationService` was read only** for the duplicate-implementation evidence and the status guards. It is not called by this controller and is not registered as owned; its own behaviour is not audited here.
- **The list tab partial is owned elsewhere.** Its eager-loading and export columns are not re-audited; only the routes it calls into this controller were checked.
- **Concurrency findings (BKRM-08) are static.** Reproducing them needs two simultaneous requests, which the audit does not run.
- **Live counts** come from the tenant database `xyz_school_00000000000040008000_202627` on the central `prime_db` host, not from a browser session.
- **Policy runtime was not exercised.** The finding is that the policy is not consulted, which is proved by the absence of any model-ability gate call.
