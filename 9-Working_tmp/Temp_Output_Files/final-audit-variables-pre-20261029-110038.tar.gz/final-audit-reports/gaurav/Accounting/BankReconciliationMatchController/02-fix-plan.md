# Fix Plan — Accounting / BankReconciliationMatchController

**From:** `01-report.md` (2026-10-24) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | shared route file; only the ticked **BKRM-15** decision may change line 253 |
| `Modules/Accounting/app/Services/ReconciliationService.php` | not owned by this report; the BKRM-18 decision is elsewhere |
| `Modules/Accounting/app/Providers/AccountingServiceProvider.php` | shared provider; the BKRM-09 decision may touch line 171 |
| `Modules/Accounting/app/Policies/BankReconciliationMatchPolicy.php` | only the ticked BKRM-09 decision may delete it |
| `config/permissionslist.php` | shared permission registry; no new key is proposed |
| `database/migrations/**` | never edit an existing migration |
| `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_bank-reconciliation-matches.blade.php` | owned by `gaurav/Accounting/AccDashboardController` |
| `Modules/Accounting/app/Models/BankReconciliation.php`, `BankStatementEntry.php`, `Voucher.php`, `VoucherItem.php` | owned by other reports or unclaimed; this plan only issues runtime `update()` calls against them |
| `resources/views/components/**` and layouts | common components; the `action-trashed` component already supports POST restore |

## 1. Blockers reachable today

- [ ] **BKRM-10** · H · VAL-04 / VAL-05 / VAL-07 · `BankReconciliationMatchRequest.php:16-37` — stop the client setting audit fields, mirror the unique index, and reject unrelated records.
  - **Touches:** `Modules/Accounting/app/Http/Requests/BankReconciliationMatchRequest.php`
  - **Before** (`BankReconciliationMatchRequest.php:7`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    ```
  - **After:**
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    ```
  - **Before** (`BankReconciliationMatchRequest.php:16-37`):
    ```php
    public function rules(): array
    {
        return [
            'reconciliation_id'   => 'required|exists:acc_bank_reconciliations,id',
            'statement_entry_id'  => 'required|exists:acc_bank_statement_entries,id',
            'voucher_item_id'     => 'required|exists:acc_voucher_items,id',
            'voucher_id'          => 'required|exists:acc_vouchers,id',
            'amount'              => 'required|numeric|min:0.01',
            'match_method'        => 'required|in:Auto_Exact,Auto_Scored,Learned,Manual',
            'confidence'          => 'nullable|numeric|between:0,1',
            'score_breakdown'     => 'nullable|array',
            'status'              => 'required|in:Proposed,Confirmed,Rejected,Undone',
            'bank_value_date'     => 'nullable|date',
            'confirmed_at'        => 'nullable|date',
            'confirmed_by'        => 'nullable|integer',
            'rejected_reason'     => 'required_if:status,Rejected|nullable|string|max:500',
            'undone_at'           => 'nullable|date',
            'undone_by'           => 'nullable|integer',
            'undo_reason'         => 'required_if:status,Undone|nullable|string|max:500',
            'is_active'           => 'nullable|boolean',
        ];
    }
    ```
  - **After:**
    ```php
    public function rules(): array
    {
        return [
            'reconciliation_id'   => 'required|exists:acc_bank_reconciliations,id',
            'statement_entry_id'  => [
                'required',
                'exists:acc_bank_statement_entries,id',
                Rule::unique('acc_bank_reconciliation_matches', 'statement_entry_id')
                    ->where(fn ($query) => $query->where('voucher_item_id', $this->input('voucher_item_id')))
                    ->ignore($this->route('bank_reconciliation_match')),
            ],
            'voucher_item_id'     => 'required|exists:acc_voucher_items,id',
            'voucher_id'          => 'required|exists:acc_vouchers,id',
            'amount'              => 'required|numeric|min:0.01',
            'match_method'        => 'required|in:Auto_Exact,Auto_Scored,Learned,Manual',
            'confidence'          => 'nullable|numeric|between:0,1',
            'score_breakdown'     => 'nullable|array',
            'status'              => 'required|in:Proposed,Confirmed,Rejected,Undone',
            'bank_value_date'     => 'nullable|date',
            'rejected_reason'     => 'required_if:status,Rejected|nullable|string|max:500',
            'undo_reason'         => 'required_if:status,Undone|nullable|string|max:500',
            'is_active'           => 'nullable|boolean',
        ];
    }

    public function after(): array
    {
        return [function (\Illuminate\Validation\Validator $validator): void {
            if ($validator->errors()->isNotEmpty()) {
                return;
            }

            $statementEntry = \Modules\Accounting\Models\BankStatementEntry::find($this->input('statement_entry_id'));
            if ($statementEntry && (int) $statementEntry->reconciliation_id !== (int) $this->input('reconciliation_id')) {
                $validator->errors()->add('statement_entry_id', 'The selected statement entry does not belong to the selected reconciliation.');
            }

            $reconciliation = \Modules\Accounting\Models\BankReconciliation::find($this->input('reconciliation_id'));
            $voucherItem = \Modules\Accounting\Models\VoucherItem::find($this->input('voucher_item_id'));
            if ($reconciliation && $voucherItem && (int) $voucherItem->ledger_id !== (int) $reconciliation->bank_ledger_id) {
                $validator->errors()->add('voucher_item_id', 'The selected voucher line is not on the reconciliation bank ledger.');
            }
        }];
    }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\BankReconciliationMatchRequest.php" -Pattern "Rule::unique|function after|confirmed_by"`
  - **Expect:** the `Rule::unique` and `function after` lines are present; the `confirmed_by` line is absent.
  - **Effort:** M

- [ ] **BKRM-01** · B · ERR-01 — remove every catch from `store`, `confirm`, `reject` and `undo`; use `DB::transaction`; validate the confirm date; enforce the status transitions.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php`
  - **Before** (`BankReconciliationMatchController.php:45-91`):
    ```php
    public function store(BankReconciliationMatchRequest $request)
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.create');

        $validated = $request->validated();

        DB::beginTransaction();
        try {
            $validated['created_by'] = auth()->id();
            if ($validated['status'] === 'Confirmed') {
                $validated['confirmed_at'] = now();
                $validated['confirmed_by'] = auth()->id();
            }

            $match = BankReconciliationMatch::create($validated);

            if ($match->status === 'Confirmed') {
                BankStatementEntry::where('id', $match->statement_entry_id)->update([
                    'match_status'   => 'Matched',
                    'matched_amount' => $match->amount,
                ]);

                VoucherItem::where('id', $match->voucher_item_id)->update([
                    'is_reconciled'   => true,
                    'reconciled_at'   => now(),
                    'bank_value_date' => $match->bank_value_date ?? now()->toDateString(),
                ]);
            }

            activityLog($match, 'Created', [
                'message'      => 'Reconciliation match recorded with amount ' . $match->amount . ' (' . $match->status . ')',
                'amount'       => $match->amount,
                'status'       => $match->status,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
                ->with('success', 'Reconciliation match created successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Bank Reconciliation Match', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'Failed to create match: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function store(BankReconciliationMatchRequest $request): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        if ($validated['status'] === 'Confirmed') {
            $validated['confirmed_at'] = now();
            $validated['confirmed_by'] = auth()->id();
        }

        DB::transaction(function () use ($validated): void {
            $match = BankReconciliationMatch::create($validated);

            if ($match->status === 'Confirmed') {
                BankStatementEntry::where('id', $match->statement_entry_id)->update([
                    'match_status'   => 'Matched',
                    'matched_amount' => $match->amount,
                ]);

                VoucherItem::where('id', $match->voucher_item_id)->update([
                    'is_reconciled'   => true,
                    'reconciled_at'   => now(),
                    'bank_value_date' => $match->bank_value_date ?? now()->toDateString(),
                ]);
            }

            activityLog($match, 'Created', [
                'message'      => 'Reconciliation match recorded with amount ' . $match->amount . ' (' . $match->status . ')',
                'amount'       => $match->amount,
                'status'       => $match->status,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
            ->with('success', 'Reconciliation match created successfully.');
    }
    ```
  - **Before** (`BankReconciliationMatchController.php:246-287`):
    ```php
    public function confirm(Request $request, BankReconciliationMatch $bankReconciliationMatch)
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.confirm');

        $bankValueDate = $request->input('bank_value_date', $bankReconciliationMatch->bank_value_date ?? now()->toDateString());

        DB::beginTransaction();
        try {
            $bankReconciliationMatch->update([
                'status'          => 'Confirmed',
                'confirmed_at'    => now(),
                'confirmed_by'    => auth()->id(),
                'bank_value_date' => $bankValueDate,
            ]);

            BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                'match_status'   => 'Matched',
                'matched_amount' => $bankReconciliationMatch->amount,
            ]);

            VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                'is_reconciled'   => true,
                'reconciled_at'   => now(),
                'bank_value_date' => $bankValueDate,
            ]);

            activityLog($bankReconciliationMatch, 'Confirmed', [
                'message'      => 'Reconciliation match confirmed #' . $bankReconciliationMatch->id,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
                ->with('success', 'Reconciliation match confirmed successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to confirm match', ['id' => $bankReconciliationMatch->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to confirm match: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function confirm(Request $request, BankReconciliationMatch $bankReconciliationMatch): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.confirm');

        $request->validate([
            'bank_value_date' => 'nullable|date',
        ]);

        if ($bankReconciliationMatch->status !== 'Proposed') {
            throw new \DomainException('Only proposed matches can be confirmed.');
        }

        $bankValueDate = $request->input('bank_value_date', $bankReconciliationMatch->bank_value_date ?? now()->toDateString());

        DB::transaction(function () use ($bankReconciliationMatch, $bankValueDate): void {
            $bankReconciliationMatch->update([
                'status'          => 'Confirmed',
                'confirmed_at'    => now(),
                'confirmed_by'    => auth()->id(),
                'bank_value_date' => $bankValueDate,
            ]);

            BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                'match_status'   => 'Matched',
                'matched_amount' => $bankReconciliationMatch->amount,
            ]);

            VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                'is_reconciled'   => true,
                'reconciled_at'   => now(),
                'bank_value_date' => $bankValueDate,
            ]);

            activityLog($bankReconciliationMatch, 'Confirmed', [
                'message'      => 'Reconciliation match confirmed #' . $bankReconciliationMatch->id,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
            ->with('success', 'Reconciliation match confirmed successfully.');
    }
    ```
  - **Before** (`BankReconciliationMatchController.php:289-319`):
    ```php
    public function reject(Request $request, BankReconciliationMatch $bankReconciliationMatch)
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.reject');

        $request->validate([
            'rejected_reason' => 'required|string|max:500',
        ]);

        DB::beginTransaction();
        try {
            $bankReconciliationMatch->update([
                'status'          => 'Rejected',
                'rejected_reason' => $request->input('rejected_reason'),
            ]);

            activityLog($bankReconciliationMatch, 'Rejected', [
                'message'      => 'Reconciliation match rejected #' . $bankReconciliationMatch->id . ': ' . $request->input('rejected_reason'),
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
                ->with('success', 'Reconciliation match rejected.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to reject match', ['id' => $bankReconciliationMatch->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to reject match: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function reject(Request $request, BankReconciliationMatch $bankReconciliationMatch): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.reject');

        $request->validate([
            'rejected_reason' => 'required|string|max:500',
        ]);

        if ($bankReconciliationMatch->status !== 'Proposed') {
            throw new \DomainException('Only proposed matches can be rejected.');
        }

        DB::transaction(function () use ($request, $bankReconciliationMatch): void {
            $bankReconciliationMatch->update([
                'status'          => 'Rejected',
                'rejected_reason' => $request->input('rejected_reason'),
            ]);

            activityLog($bankReconciliationMatch, 'Rejected', [
                'message'      => 'Reconciliation match rejected #' . $bankReconciliationMatch->id . ': ' . $request->input('rejected_reason'),
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
            ->with('success', 'Reconciliation match rejected.');
    }
    ```
  - **Before** (`BankReconciliationMatchController.php:321-371`):
    ```php
    public function undo(Request $request, BankReconciliationMatch $bankReconciliationMatch)
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.undo');

        $request->validate([
            'undo_reason' => 'required|string|max:500',
        ]);

        DB::beginTransaction();
        try {
            $bankReconciliationMatch->update([
                'status'      => 'Undone',
                'undone_at'   => now(),
                'undone_by'   => auth()->id(),
                'undo_reason' => $request->input('undo_reason'),
            ]);

            $hasOtherMatches = BankReconciliationMatch::where('statement_entry_id', $bankReconciliationMatch->statement_entry_id)
                ->where('id', '!=', $bankReconciliationMatch->id)
                ->where('status', 'Confirmed')
                ->exists();

            if (!$hasOtherMatches) {
                BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                    'match_status'   => 'Unmatched',
                    'matched_amount' => 0.00,
                ]);
            }

            VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                'is_reconciled'   => false,
                'reconciled_at'   => null,
                'bank_value_date' => null,
            ]);

            activityLog($bankReconciliationMatch, 'Undone', [
                'message'      => 'Reconciliation match undone #' . $bankReconciliationMatch->id . ': ' . $request->input('undo_reason'),
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
                ->with('success', 'Reconciliation match undone.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to undo match', ['id' => $bankReconciliationMatch->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to undo match: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function undo(Request $request, BankReconciliationMatch $bankReconciliationMatch): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.undo');

        $request->validate([
            'undo_reason' => 'required|string|max:500',
        ]);

        if ($bankReconciliationMatch->status !== 'Confirmed') {
            throw new \DomainException('Only confirmed matches can be undone.');
        }

        DB::transaction(function () use ($request, $bankReconciliationMatch): void {
            $bankReconciliationMatch->update([
                'status'      => 'Undone',
                'undone_at'   => now(),
                'undone_by'   => auth()->id(),
                'undo_reason' => $request->input('undo_reason'),
            ]);

            $entryStillConfirmed = BankReconciliationMatch::where('statement_entry_id', $bankReconciliationMatch->statement_entry_id)
                ->where('id', '!=', $bankReconciliationMatch->id)
                ->where('status', 'Confirmed')
                ->exists();

            if (! $entryStillConfirmed) {
                BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                    'match_status'   => 'Unmatched',
                    'matched_amount' => 0.00,
                ]);
            }

            $itemStillConfirmed = BankReconciliationMatch::where('voucher_item_id', $bankReconciliationMatch->voucher_item_id)
                ->where('id', '!=', $bankReconciliationMatch->id)
                ->where('status', 'Confirmed')
                ->exists();

            if (! $itemStillConfirmed) {
                VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                    'is_reconciled'   => false,
                    'reconciled_at'   => null,
                    'bank_value_date' => null,
                ]);
            }

            activityLog($bankReconciliationMatch, 'Undone', [
                'message'      => 'Reconciliation match undone #' . $bankReconciliationMatch->id . ': ' . $request->input('undo_reason'),
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
            ->with('success', 'Reconciliation match undone.');
    }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "getMessage|DB::beginTransaction|DomainException"`
  - **Expect:** no `getMessage` and no `DB::beginTransaction`; three `DomainException` lines (confirm, reject, undo).
  - **Effort:** L

- [ ] **BKRM-05** · B · TXN-01 — release the old statement entry and voucher item when a confirmed match is edited.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php`
  - **Before** (`BankReconciliationMatchController.php:140-197`):
    ```php
    public function update(BankReconciliationMatchRequest $request, BankReconciliationMatch $bankReconciliationMatch)
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.update');

        $validated = $request->validated();
        $oldStatus = $bankReconciliationMatch->status;

        DB::beginTransaction();
        try {
            if ($validated['status'] === 'Confirmed' && $oldStatus !== 'Confirmed') {
                $validated['confirmed_at'] = now();
                $validated['confirmed_by'] = auth()->id();
            }

            $bankReconciliationMatch->update($validated);

            // Re-sync statement entry and voucher item if confirmed
            if ($bankReconciliationMatch->status === 'Confirmed') {
                BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                    'match_status'   => 'Matched',
                    'matched_amount' => $bankReconciliationMatch->amount,
                ]);

                VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                    'is_reconciled'   => true,
                    'reconciled_at'   => now(),
                    'bank_value_date' => $bankReconciliationMatch->bank_value_date ?? now()->toDateString(),
                ]);
            } elseif ($oldStatus === 'Confirmed' && $bankReconciliationMatch->status !== 'Confirmed') {
                // If moved away from confirmed
                BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                    'match_status'   => $bankReconciliationMatch->status === 'Proposed' ? 'Proposed' : 'Unmatched',
                    'matched_amount' => 0.00,
                ]);

                VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                    'is_reconciled'   => false,
                    'reconciled_at'   => null,
                    'bank_value_date' => null,
                ]);
            }

            activityLog($bankReconciliationMatch, 'Updated', [
                'message'      => 'Reconciliation match updated #' . $bankReconciliationMatch->id,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
                ->with('success', 'Reconciliation match updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to update Bank Reconciliation Match', ['id' => $bankReconciliationMatch->id, 'error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'Failed to update match: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function update(BankReconciliationMatchRequest $request, BankReconciliationMatch $bankReconciliationMatch): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.update');

        $validated = $request->validated();
        $oldStatus = $bankReconciliationMatch->status;
        $oldStatementEntryId = $bankReconciliationMatch->statement_entry_id;
        $oldVoucherItemId = $bankReconciliationMatch->voucher_item_id;

        DB::transaction(function () use ($bankReconciliationMatch, $validated, $oldStatus, $oldStatementEntryId, $oldVoucherItemId): void {
            if ($validated['status'] === 'Confirmed' && $oldStatus !== 'Confirmed') {
                $validated['confirmed_at'] = now();
                $validated['confirmed_by'] = auth()->id();
            }

            $bankReconciliationMatch->update($validated);

            $referencesChanged = (int) $oldStatementEntryId !== (int) $bankReconciliationMatch->statement_entry_id
                || (int) $oldVoucherItemId !== (int) $bankReconciliationMatch->voucher_item_id;

            if ($oldStatus === 'Confirmed' && ($bankReconciliationMatch->status !== 'Confirmed' || $referencesChanged)) {
                $oldEntryStillConfirmed = BankReconciliationMatch::where('statement_entry_id', $oldStatementEntryId)
                    ->where('id', '!=', $bankReconciliationMatch->id)
                    ->where('status', 'Confirmed')
                    ->exists();

                if (! $oldEntryStillConfirmed) {
                    BankStatementEntry::where('id', $oldStatementEntryId)->update([
                        'match_status'   => $bankReconciliationMatch->status === 'Proposed' ? 'Proposed' : 'Unmatched',
                        'matched_amount' => 0.00,
                    ]);
                }

                $oldItemStillConfirmed = BankReconciliationMatch::where('voucher_item_id', $oldVoucherItemId)
                    ->where('id', '!=', $bankReconciliationMatch->id)
                    ->where('status', 'Confirmed')
                    ->exists();

                if (! $oldItemStillConfirmed) {
                    VoucherItem::where('id', $oldVoucherItemId)->update([
                        'is_reconciled'   => false,
                        'reconciled_at'   => null,
                        'bank_value_date' => null,
                    ]);
                }
            }

            if ($bankReconciliationMatch->status === 'Confirmed') {
                BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                    'match_status'   => 'Matched',
                    'matched_amount' => $bankReconciliationMatch->amount,
                ]);

                VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                    'is_reconciled'   => true,
                    'reconciled_at'   => now(),
                    'bank_value_date' => $bankReconciliationMatch->bank_value_date ?? now()->toDateString(),
                ]);
            }

            activityLog($bankReconciliationMatch, 'Updated', [
                'message'      => 'Reconciliation match updated #' . $bankReconciliationMatch->id,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
            ->with('success', 'Reconciliation match updated successfully.');
    }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "oldStatementEntryId|oldVoucherItemId"`
  - **Expect:** the two variables are assigned once and used in the release block (four lines or more).
  - **Effort:** M

- [ ] **BKRM-07** · H · TXN-01 — make delete/restore/force-delete keep the statement entry and voucher line in step, and stop turning a 404 into a flash.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php`
  - **Before** (`BankReconciliationMatchController.php:199-244`):
    ```php
    public function destroy(BankReconciliationMatch $bankReconciliationMatch)
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.delete');

        DB::beginTransaction();
        try {
            // Unmatch statement entry if confirmed and no other matches
            if ($bankReconciliationMatch->status === 'Confirmed') {
                $hasOtherMatches = BankReconciliationMatch::where('statement_entry_id', $bankReconciliationMatch->statement_entry_id)
                    ->where('id', '!=', $bankReconciliationMatch->id)
                    ->where('status', 'Confirmed')
                    ->exists();

                if (!$hasOtherMatches) {
                    BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                        'match_status'   => 'Unmatched',
                        'matched_amount' => 0.00,
                    ]);
                }

                VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                    'is_reconciled'   => false,
                    'reconciled_at'   => null,
                    'bank_value_date' => null,
                ]);
            }

            $id = $bankReconciliationMatch->id;
            $bankReconciliationMatch->delete();

            activityLog($bankReconciliationMatch, 'Deleted', [
                'message'      => 'Reconciliation match deleted #' . $id,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
                ->with('success', 'Reconciliation match deleted successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to delete Bank Reconciliation Match', ['id' => $bankReconciliationMatch->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete match: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function destroy(BankReconciliationMatch $bankReconciliationMatch): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.delete');

        $id = $bankReconciliationMatch->id;

        DB::transaction(function () use ($bankReconciliationMatch, $id): void {
            if ($bankReconciliationMatch->status === 'Confirmed') {
                $entryStillConfirmed = BankReconciliationMatch::where('statement_entry_id', $bankReconciliationMatch->statement_entry_id)
                    ->where('id', '!=', $id)
                    ->where('status', 'Confirmed')
                    ->exists();

                if (! $entryStillConfirmed) {
                    BankStatementEntry::where('id', $bankReconciliationMatch->statement_entry_id)->update([
                        'match_status'   => 'Unmatched',
                        'matched_amount' => 0.00,
                    ]);
                }

                $itemStillConfirmed = BankReconciliationMatch::where('voucher_item_id', $bankReconciliationMatch->voucher_item_id)
                    ->where('id', '!=', $id)
                    ->where('status', 'Confirmed')
                    ->exists();

                if (! $itemStillConfirmed) {
                    VoucherItem::where('id', $bankReconciliationMatch->voucher_item_id)->update([
                        'is_reconciled'   => false,
                        'reconciled_at'   => null,
                        'bank_value_date' => null,
                    ]);
                }
            }

            $bankReconciliationMatch->delete();

            activityLog($bankReconciliationMatch, 'Deleted', [
                'message'      => 'Reconciliation match deleted #' . $id,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches'])
            ->with('success', 'Reconciliation match deleted successfully.');
    }
    ```
  - **Before** (`BankReconciliationMatchController.php:382-405`):
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.restore');

        DB::beginTransaction();
        try {
            $model = BankReconciliationMatch::onlyTrashed()->findOrFail($id);
            $model->restore();

            activityLog($model, 'Restored', [
                'message'      => 'Reconciliation match restored #' . $model->id,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.bank-reconciliation-match.trashed')->with('success', 'Reconciliation match restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore match', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore match: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.restore');

        $model = BankReconciliationMatch::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($model): void {
            $model->restore();

            if ($model->status === 'Confirmed') {
                BankStatementEntry::where('id', $model->statement_entry_id)->update([
                    'match_status'   => 'Matched',
                    'matched_amount' => $model->amount,
                ]);

                VoucherItem::where('id', $model->voucher_item_id)->update([
                    'is_reconciled'   => true,
                    'reconciled_at'   => now(),
                    'bank_value_date' => $model->bank_value_date ?? now()->toDateString(),
                ]);
            }

            activityLog($model, 'Restored', [
                'message'      => 'Reconciliation match restored #' . $model->id,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.bank-reconciliation-match.trashed')->with('success', 'Reconciliation match restored successfully.');
    }
    ```
  - **Before** (`BankReconciliationMatchController.php:407-431`):
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.forceDelete');

        DB::beginTransaction();
        try {
            $model = BankReconciliationMatch::withTrashed()->findOrFail($id);
            $idVal = $model->id;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Reconciliation match permanently deleted #' . $idVal,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.bank-reconciliation-match.trashed')->with('success', 'Reconciliation match permanently deleted.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to force delete match', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete match: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.forceDelete');

        $model = BankReconciliationMatch::withTrashed()->findOrFail($id);
        $idVal = $model->id;

        DB::transaction(function () use ($model, $idVal): void {
            if ($model->status === 'Confirmed') {
                $entryStillConfirmed = BankReconciliationMatch::where('statement_entry_id', $model->statement_entry_id)
                    ->where('id', '!=', $idVal)
                    ->where('status', 'Confirmed')
                    ->exists();

                if (! $entryStillConfirmed) {
                    BankStatementEntry::where('id', $model->statement_entry_id)->update([
                        'match_status'   => 'Unmatched',
                        'matched_amount' => 0.00,
                    ]);
                }

                $itemStillConfirmed = BankReconciliationMatch::where('voucher_item_id', $model->voucher_item_id)
                    ->where('id', '!=', $idVal)
                    ->where('status', 'Confirmed')
                    ->exists();

                if (! $itemStillConfirmed) {
                    VoucherItem::where('id', $model->voucher_item_id)->update([
                        'is_reconciled'   => false,
                        'reconciled_at'   => null,
                        'bank_value_date' => null,
                    ]);
                }
            }

            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Reconciliation match permanently deleted #' . $idVal,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.bank-reconciliation-match.trashed')->with('success', 'Reconciliation match permanently deleted.');
    }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "findOrFail|itemStillConfirmed"`
  - **Expect:** both `findOrFail` calls are outside any `try`; the `itemStillConfirmed` check appears in destroy, undo and forceDelete.
  - **Effort:** L

## 2. Fixes that arm a latent defect (sequenced)

None. BKRM-11 (the unique rule) is inside BKRM-10 and is listed first in §1, before BKRM-01 removes the catch that currently hides the duplicate-key exception.

## 3. Errors & transactions (F1/F2)

All F1/F2 fixes are items **BKRM-01**, **BKRM-05** and **BKRM-07** in §1. They are placed first so the application order is: rule (BKRM-10) → controller methods. Splitting them per finding would make the Before blocks collide, because four findings share the same methods.

## 4. Authorization (F3)

No fix here. BKRM-09 is a DECISION in §9: the permission strings already exist and are seeded, so no new key is needed.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **BKRM-16** · L · CTL-04 / CTL-10 / QRY-02 — add return types, remove the unused `$vouchers` query, and paginate the trash at 10.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php`
  - **Before** (`BankReconciliationMatchController.php:21-26`):
    ```php
    public function index()
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.viewAny');

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches']);
    }
    ```
  - **After:**
    ```php
    public function index(): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.viewAny');

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-reconciliation-matches']);
    }
    ```
  - **Before** (`BankReconciliationMatchController.php:28-43`):
    ```php
    public function create()
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.create');

        $reconciliations  = BankReconciliation::with('bankLedger')->where('status', '!=', 'Completed')->get();
        $statementEntries = BankStatementEntry::whereIn('match_status', ['Unmatched', 'Proposed'])->get();
        $vouchers         = Voucher::where('status', 'Posted')->orderByDesc('voucher_date')->take(100)->get();
        $voucherItems     = VoucherItem::with(['voucher.voucherType', 'ledger'])
            ->where('voucher_status', 'Posted')
            ->where('is_reconciled', false)
            ->orderByDesc('voucher_date')
            ->take(100)
            ->get();

        return view('accounting::bank-reconciliation-match.create', compact('reconciliations', 'statementEntries', 'vouchers', 'voucherItems'));
    }
    ```
  - **After:**
    ```php
    public function create(): \Illuminate\View\View
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.create');

        $reconciliations  = BankReconciliation::with('bankLedger')->where('status', '!=', 'Completed')->get();
        $statementEntries = BankStatementEntry::whereIn('match_status', ['Unmatched', 'Proposed'])->get();
        $voucherItems     = VoucherItem::with(['voucher.voucherType', 'ledger'])
            ->where('voucher_status', 'Posted')
            ->where('is_reconciled', false)
            ->orderByDesc('voucher_date')
            ->take(100)
            ->get();

        return view('accounting::bank-reconciliation-match.create', compact('reconciliations', 'statementEntries', 'voucherItems'));
    }
    ```
  - **Before** (`BankReconciliationMatchController.php:93-108`):
    ```php
    public function show(BankReconciliationMatch $bankReconciliationMatch)
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.view');

        $bankReconciliationMatch->load([
            'reconciliation.bankLedger',
            'statementEntry',
            'voucherItem.ledger',
            'voucher.voucherType',
            'confirmedByUser',
            'undoneByUser',
            'creator',
        ]);

        return view('accounting::bank-reconciliation-match.show', compact('bankReconciliationMatch'));
    }
    ```
  - **After:**
    ```php
    public function show(BankReconciliationMatch $bankReconciliationMatch): \Illuminate\View\View
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.view');

        $bankReconciliationMatch->load([
            'reconciliation.bankLedger',
            'statementEntry',
            'voucherItem.ledger',
            'voucher.voucherType',
            'confirmedByUser',
            'undoneByUser',
            'creator',
        ]);

        return view('accounting::bank-reconciliation-match.show', compact('bankReconciliationMatch'));
    }
    ```
  - **Before** (`BankReconciliationMatchController.php:110-138`):
    ```php
    public function edit(BankReconciliationMatch $bankReconciliationMatch)
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.update');

        $bankReconciliationMatch->load([
            'reconciliation.bankLedger',
            'statementEntry',
            'voucherItem.ledger',
            'voucher',
            'confirmedByUser',
            'undoneByUser',
            'creator',
        ]);

        $reconciliations  = BankReconciliation::with('bankLedger')->get();
        $statementEntries = BankStatementEntry::where('reconciliation_id', $bankReconciliationMatch->reconciliation_id)->get();
        $vouchers         = Voucher::where('status', 'Posted')->orderByDesc('voucher_date')->take(100)->get();
        $voucherItems     = VoucherItem::with(['voucher.voucherType', 'ledger'])
            ->where(function ($q) use ($bankReconciliationMatch) {
                $q->where('is_reconciled', false)
                  ->orWhere('id', $bankReconciliationMatch->voucher_item_id);
            })
            ->where('voucher_status', 'Posted')
            ->orderByDesc('voucher_date')
            ->take(100)
            ->get();

        return view('accounting::bank-reconciliation-match.edit', compact('bankReconciliationMatch', 'reconciliations', 'statementEntries', 'vouchers', 'voucherItems'));
    }
    ```
  - **After:**
    ```php
    public function edit(BankReconciliationMatch $bankReconciliationMatch): \Illuminate\View\View
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.update');

        $bankReconciliationMatch->load([
            'reconciliation.bankLedger',
            'statementEntry',
            'voucherItem.ledger',
            'voucher',
            'confirmedByUser',
            'undoneByUser',
            'creator',
        ]);

        $reconciliations  = BankReconciliation::with('bankLedger')->get();
        $statementEntries = BankStatementEntry::where('reconciliation_id', $bankReconciliationMatch->reconciliation_id)->get();
        $voucherItems     = VoucherItem::with(['voucher.voucherType', 'ledger'])
            ->where(function ($q) use ($bankReconciliationMatch) {
                $q->where('is_reconciled', false)
                  ->orWhere('id', $bankReconciliationMatch->voucher_item_id);
            })
            ->where('voucher_status', 'Posted')
            ->orderByDesc('voucher_date')
            ->take(100)
            ->get();

        return view('accounting::bank-reconciliation-match.edit', compact('bankReconciliationMatch', 'reconciliations', 'statementEntries', 'voucherItems'));
    }
    ```
  - **Before** (`BankReconciliationMatchController.php:373-380`):
    ```php
    public function trashed(): \Illuminate\View\View
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.restore');

        $matches = BankReconciliationMatch::onlyTrashed()->with(['reconciliation.bankLedger', 'statementEntry'])->orderByDesc('created_at')->paginate(15);

        return view('accounting::bank-reconciliation-match.trash', compact('matches'));
    }
    ```
  - **After:**
    ```php
    public function trashed(): \Illuminate\View\View
    {
        Gate::authorize('tenant.accounting.bank-reconciliation-match.restore');

        $matches = BankReconciliationMatch::onlyTrashed()->with(['reconciliation.bankLedger', 'statementEntry'])->orderByDesc('created_at')->paginate(10);

        return view('accounting::bank-reconciliation-match.trash', compact('matches'));
    }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" -Pattern "\$vouchers|paginate\(15\)"`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **BKRM-19** · L · MDL-04 — add return types to the model relations and scopes.
  - **Touches:** `Modules/Accounting/app/Models/BankReconciliationMatch.php`
  - **Before** (`BankReconciliationMatch.php:45-95`):
    ```php
    public function reconciliation()
    {
        return $this->belongsTo(BankReconciliation::class);
    }

    public function statementEntry()
    {
        return $this->belongsTo(BankStatementEntry::class, 'statement_entry_id');
    }

    public function voucherItem()
    {
        return $this->belongsTo(VoucherItem::class, 'voucher_item_id');
    }

    public function voucher()
    {
        return $this->belongsTo(Voucher::class);
    }

    public function confirmedByUser()
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'confirmed_by');
    }

    public function undoneByUser()
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'undone_by');
    }

    public function creator()
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'created_by');
    }

    // ─── Scopes ──────────────────────────────────────────────────────────

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeConfirmed($query)
    {
        return $query->where('status', 'Confirmed');
    }

    public function scopeProposed($query)
    {
        return $query->where('status', 'Proposed');
    }
    ```
  - **After:**
    ```php
    public function reconciliation(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(BankReconciliation::class);
    }

    public function statementEntry(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(BankStatementEntry::class, 'statement_entry_id');
    }

    public function voucherItem(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(VoucherItem::class, 'voucher_item_id');
    }

    public function voucher(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Voucher::class);
    }

    public function confirmedByUser(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'confirmed_by');
    }

    public function undoneByUser(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'undone_by');
    }

    public function creator(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'created_by');
    }

    // ─── Scopes ──────────────────────────────────────────────────────────

    public function scopeActive(\Illuminate\Database\Eloquent\Builder $query): \Illuminate\Database\Eloquent\Builder
    {
        return $query->where('is_active', true);
    }

    public function scopeConfirmed(\Illuminate\Database\Eloquent\Builder $query): \Illuminate\Database\Eloquent\Builder
    {
        return $query->where('status', 'Confirmed');
    }

    public function scopeProposed(\Illuminate\Database\Eloquent\Builder $query): \Illuminate\Database\Eloquent\Builder
    {
        return $query->where('status', 'Proposed');
    }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Models\BankReconciliationMatch.php" -Pattern "public function (reconciliation|scopeActive)\("`
  - **Expect:** both lines end with a return type (`BelongsTo` and `Builder`).
  - **Effort:** S

## 6. Queries & performance (F9)

No mechanical item here. BKRM-20 (unbounded dropdowns) is a DECISION in §9 because the correct fix is a searchable dropdown, not a silent row cap. BKRM-21 is included in the BKRM-16 item above.

## 7. Views (F10)

No fix. The four own blades are clean and the list tab is owned by `AccDashboardController`.

## 8. Style (F12) — one item per file

- [ ] **BKRM-22** · L · STY-02 — run Pint on the controller.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankReconciliationMatchController.php`
  - **Before:** `vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" --format agent` reports `fail` with `fully_qualified_strict_types`, `concat_space`, `method_chaining_indentation`, `not_operator_with_successor_space`, `ordered_imports`, `binary_operator_spaces`, `single_blank_line_at_eof`.
  - **After:**
    ```php
    // No hand edit. Run the formatter on the one file:
    // vendor\bin\pint "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" --format agent
    ```
  - **Verify:** `vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\BankReconciliationMatchController.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"pass"}`
  - **Effort:** S

- [ ] **BKRM-23** · L · STY-02 — run Pint on the FormRequest.
  - **Touches:** `Modules/Accounting/app/Http/Requests/BankReconciliationMatchRequest.php`
  - **Before:** `vendor\bin\pint --test "Modules\Accounting\app\Http\Requests\BankReconciliationMatchRequest.php" --format agent` reports `fail` with `fully_qualified_strict_types`, `not_operator_with_successor_space`, `binary_operator_spaces`.
  - **After:**
    ```php
    // No hand edit. Run the formatter on the one file:
    // vendor\bin\pint "Modules\Accounting\app\Http\Requests\BankReconciliationMatchRequest.php" --format agent
    ```
  - **Verify:** `vendor\bin\pint --test "Modules\Accounting\app\Http\Requests\BankReconciliationMatchRequest.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"pass"}`
  - **Effort:** S

- [ ] **BKRM-24** · L · STY-02 — run Pint on the model.
  - **Touches:** `Modules/Accounting/app/Models/BankReconciliationMatch.php`
  - **Before:** `vendor\bin\pint --test "Modules\Accounting\app\Models\BankReconciliationMatch.php" --format agent` reports `fail` with `fully_qualified_strict_types`, `no_unused_imports`, `single_line_after_imports`, `binary_operator_spaces`.
  - **After:**
    ```php
    // No hand edit. Run the formatter on the one file:
    // vendor\bin\pint "Modules\Accounting\app\Models\BankReconciliationMatch.php" --format agent
    ```
  - **Verify:** `vendor\bin\pint --test "Modules\Accounting\app\Models\BankReconciliationMatch.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"pass"}`
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BKRM-15** · H · DECISION · RTE-01 — change the restore route from GET to POST? ⚠ SHARED (`Modules/Accounting/routes/web.php`)
  - **Why it is a decision:** it changes the HTTP verb of a shared route file, which D3 otherwise keeps fixed.
  - (a) ⭐ change `Route::get('/bank-reconciliation-match/{id}/restore', ...)` to `Route::post(...)`; same URI and name, and `action-trashed` already emits `@csrf` for POST.
  - (b) keep GET and accept the CSRF/prefetch risk.
  - (c) add a POST route and keep the GET route as a deprecated alias.
  - ➜ Choice: ____

- [ ] **BKRM-09** · M · DECISION · AUTH-06 — delete the unused `BankReconciliationMatchPolicy`, or switch the controller to it? ⚠ SHARED (provider)
  - **Why it is a decision:** it removes or rewires a registered policy and touches `AccountingServiceProvider`.
  - (a) ⭐ delete the policy and its `Gate::policy(...)` line; the string gates already work and are seeded.
  - (b) keep the policy and replace each `Gate::authorize('...')` string with a model-ability call; the view `@can` strings would need the same change.
  - (c) leave both and record the duplication as accepted.
  - ➜ Choice: ____

- [ ] **BKRM-18** · M · DECISION · CTL-05 — replace the controller's state-sync code with `ReconciliationService`?
  - **Why it is a decision:** the service enforces status guards but uses `AuditService` and does not accept the operator's `bank_value_date`; switching changes the audit trail and the confirm behaviour.
  - (a) ⭐ keep the corrected controller code from BKRM-01/BKRM-05/BKRM-07 for this pass; adopt the service in a separate refactor.
  - (b) make `ReconciliationService::confirmMatch()` accept `$bankValueDate` and an audit note, then call it from the controller now.
  - (c) extract the four blocks into a new controller-private service and leave `ReconciliationService` alone.
  - ➜ Choice: ____

- [ ] **BKRM-20** · M · DECISION · QRY-15 — replace the unbounded reconciliation/statement-entry dropdowns with searchable lookups?
  - **Why it is a decision:** a hard row cap can hide a valid option; the proper fix is a new searchable dropdown component and a lookup endpoint.
  - (a) ⭐ defer to the dropdown/search pass; the live tenant has 2 reconciliations and 7 entries today.
  - (b) add `->limit(500)` now as a damage-control cap and document the limit in the form.
  - (c) leave as is and accept the page cost on large tenants.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BKRM-02 | The message-only logging is removed by the BKRM-01, BKRM-05 and BKRM-07 rewrites; a separate edit would touch the same catch blocks and collide. |
