# Fix Plan — Accounting / CampusController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/CampusController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | route file — ⚠ SHARED, needs Tarun (CMPS-11, CMPS-12) |
| `config/permissionslist.php` | ⚠ SHARED config (no change is proposed here) |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_campuses.blade.php` | owned by the AccDashboardController report |
| `resources/views/components/**` (`x-backend.*`, `x-tenantcore.*`) | common components |
| `Modules/Accounting/app/Models/BaseAccountingModel.php`, `Modules/Accounting/app/Services/AccountingContext.php` | shared by 77 models — only touched if CMPS-21 is ticked |
| `database/migrations/**` | never edit an existing migration; a **new** additive migration is written only if CMPS-09 option (b) is chosen |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | owned by another report |

## 1. Blockers reachable today

- [ ] **CMPS-01** · B · ERR-01 · `CampusController.php:31-326` — remove every `try/catch` and every manual transaction; use `DB::transaction(fn () => …)`, never `$e->getMessage()`. This one item also resolves **CMPS-02, CMPS-03, CMPS-04, CMPS-05, CMPS-14, CMPS-23**.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Before — imports (`CampusController.php:7-13`):**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Accounting\Http\Requests\CampusRequest;
    use Modules\Accounting\Models\Campus;
    ```
  - **After — imports:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Accounting\Http\Requests\CampusRequest;
    use Modules\Accounting\Models\Campus;
    ```
  - **Before — `store()` (`CampusController.php:31-68`):**
    ```php
    public function store(CampusRequest $request)
    {
        Gate::authorize('tenant.accounting.campus.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();
        $validated['ordinal'] = Campus::max('ordinal') + 1;

        DB::beginTransaction();
        try {
            if (!empty($validated['is_primary'])) {
                Campus::query()->update(['is_primary' => false]);
            }

            $campus = Campus::create($validated);

            activityLog($campus, 'Created', [
                'message'      => 'Campus created: ' . $campus->name,
                'code'         => $campus->code,
                'name'         => $campus->name,
                'is_primary'   => (bool) $campus->is_primary,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'campuses'])
                ->with('success', 'Campus created successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Campus', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Campus: ' . $e->getMessage());
        }
    }
    ```
  - **After — `store()`:**
    ```php
    public function store(CampusRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.accounting.campus.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();
        $validated['ordinal'] = (int) Campus::max('ordinal') + 1;

        $campus = DB::transaction(function () use ($validated) {
            if (! empty($validated['is_primary'])) {
                Campus::query()->update(['is_primary' => false]);
            }

            $campus = Campus::create($validated);

            activityLog($campus, 'Created', [
                'message'      => 'Campus created: ' . $campus->name,
                'code'         => $campus->code,
                'name'         => $campus->name,
                'is_primary'   => (bool) $campus->is_primary,
                'performed_by' => auth()->id(),
            ]);

            return $campus;
        });

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'campuses'])
            ->with('success', 'Campus created successfully.');
    }
    ```
  - **Before — `update()` (`CampusController.php:84-123`):**
    ```php
    public function update(CampusRequest $request, Campus $campus)
    {
        Gate::authorize('tenant.accounting.campus.update');

        $validated = $request->validated();

        if ($campus->isPrimary() && empty($validated['is_primary'])) {
            return back()->withInput()->with('error', 'The primary campus cannot be unset directly. Designate another campus as primary instead.');
        }

        DB::beginTransaction();
        try {
            if (!empty($validated['is_primary'])) {
                Campus::where('id', '!=', $campus->id)->update(['is_primary' => false]);
            }

            $campus->update($validated);

            activityLog($campus, 'Updated', [
                'message'      => 'Campus updated: ' . $campus->name,
                'code'         => $campus->code,
                'name'         => $campus->name,
                'is_primary'   => (bool) $campus->is_primary,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'campuses'])
                ->with('success', 'Campus updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to update Campus', [
                'id'    => $campus->id,
                'error' => $e->getMessage(),
            ]);

            return back()->withInput()->with('error', 'Failed to update Campus: ' . $e->getMessage());
        }
    }
    ```
  - **After — `update()` (adds the CMPS-23 guard):**
    ```php
    public function update(CampusRequest $request, Campus $campus): RedirectResponse
    {
        Gate::authorize('tenant.accounting.campus.update');

        $validated = $request->validated();

        if ($campus->isPrimary() && empty($validated['is_primary'])) {
            return back()->withInput()->with('error', 'The primary campus cannot be unset directly. Designate another campus as primary instead.');
        }

        if ($campus->isPrimary() && empty($validated['is_active'])) {
            return back()->withInput()->with('error', 'The primary campus cannot be deactivated.');
        }

        DB::transaction(function () use ($validated, $campus) {
            if (! empty($validated['is_primary'])) {
                Campus::where('id', '!=', $campus->id)->update(['is_primary' => false]);
            }

            $campus->update($validated);

            activityLog($campus, 'Updated', [
                'message'      => 'Campus updated: ' . $campus->name,
                'code'         => $campus->code,
                'name'         => $campus->name,
                'is_primary'   => (bool) $campus->is_primary,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'campuses'])
            ->with('success', 'Campus updated successfully.');
    }
    ```
  - **Before — `makePrimary()` (`CampusController.php:125-165`):**
    ```php
    public function makePrimary(Campus $campus)
    {
        Gate::authorize('tenant.accounting.campus.update');

        DB::beginTransaction();
        try {
            Campus::where('id', '!=', $campus->id)->update(['is_primary' => false]);
            $campus->update([
                'is_primary' => true,
                'is_active'  => true,
            ]);

            activityLog($campus, 'MadePrimary', [
                'message'      => 'Campus designated as primary: ' . $campus->name,
                'code'         => $campus->code,
                'name'         => $campus->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            if (request()->wantsJson() || request()->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => "Campus '{$campus->name}' is now designated as the primary campus.",
                ]);
            }

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'campuses'])
                ->with('success', "Campus '{$campus->name}' is now designated as the primary campus.");
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to set primary campus', ['id' => $campus->id, 'error' => $e->getMessage()]);

            if (request()->wantsJson() || request()->ajax()) {
                return response()->json(['success' => false, 'message' => 'Failed to set primary campus: ' . $e->getMessage()], 500);
            }

            return back()->with('error', 'Failed to set primary campus: ' . $e->getMessage());
        }
    }
    ```
  - **After — `makePrimary()` (injects `Request`, resolves CMPS-14):**
    ```php
    public function makePrimary(Request $request, Campus $campus)
    {
        Gate::authorize('tenant.accounting.campus.update');

        DB::transaction(function () use ($campus) {
            Campus::where('id', '!=', $campus->id)->update(['is_primary' => false]);
            $campus->update([
                'is_primary' => true,
                'is_active'  => true,
            ]);

            activityLog($campus, 'MadePrimary', [
                'message'      => 'Campus designated as primary: ' . $campus->name,
                'code'         => $campus->code,
                'name'         => $campus->name,
                'performed_by' => auth()->id(),
            ]);
        });

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => "Campus '{$campus->name}' is now designated as the primary campus.",
            ]);
        }

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'campuses'])
            ->with('success', "Campus '{$campus->name}' is now designated as the primary campus.");
    }
    ```
  - **Before — `destroy()` (`CampusController.php:167-201`):**
    ```php
    public function destroy(Campus $campus)
    {
        Gate::authorize('tenant.accounting.campus.delete');

        if ($campus->isPrimary()) {
            return back()->with('error', 'The primary campus cannot be moved to trash.');
        }

        DB::beginTransaction();
        try {
            $campus->is_active = false;
            $campus->save();
            $campus->delete();

            activityLog($campus, 'Trashed', [
                'message'      => 'Campus trashed: ' . $campus->name,
                'code'         => $campus->code,
                'name'         => $campus->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'campuses'])
                ->with('success', 'Campus moved to trash.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to trash Campus', [
                'id'    => $campus->id,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'Failed to delete Campus: ' . $e->getMessage());
        }
    }
    ```
  - **After — `destroy()`:**
    ```php
    public function destroy(Campus $campus): RedirectResponse
    {
        Gate::authorize('tenant.accounting.campus.delete');

        if ($campus->isPrimary()) {
            return back()->with('error', 'The primary campus cannot be moved to trash.');
        }

        DB::transaction(function () use ($campus) {
            $campus->is_active = false;
            $campus->save();
            $campus->delete();

            activityLog($campus, 'Trashed', [
                'message'      => 'Campus trashed: ' . $campus->name,
                'code'         => $campus->code,
                'name'         => $campus->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'campuses'])
            ->with('success', 'Campus moved to trash.');
    }
    ```
  - **Before — `toggleStatus()` (`CampusController.php:203-236`):**
    ```php
    public function toggleStatus(Request $request, Campus $campus)
    {
        Gate::authorize('tenant.accounting.campus.update');

        $request->validate(['is_active' => 'required|boolean']);

        if ($campus->isPrimary() && !$request->boolean('is_active')) {
            return response()->json([
                'success' => false,
                'message' => 'The primary campus cannot be deactivated.',
            ], 422);
        }

        DB::beginTransaction();
        try {
            $campus->is_active = $request->input('is_active');
            $campus->save();

            activityLog($campus, 'Toggled', [
                'message'      => 'Campus status toggled: ' . $campus->name,
                'code'         => $campus->code,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return response()->json(['success' => true, 'is_active' => $campus->is_active, 'message' => 'Status updated.']);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to toggle Campus status', ['id' => $campus->id, 'error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
        }
    }
    ```
  - **After — `toggleStatus()`:**
    ```php
    public function toggleStatus(Request $request, Campus $campus)
    {
        Gate::authorize('tenant.accounting.campus.update');

        $request->validate(['is_active' => 'required|boolean']);

        if ($campus->isPrimary() && ! $request->boolean('is_active')) {
            return response()->json([
                'success' => false,
                'message' => 'The primary campus cannot be deactivated.',
            ], 422);
        }

        DB::transaction(function () use ($request, $campus) {
            $campus->is_active = $request->boolean('is_active');
            $campus->save();

            activityLog($campus, 'Toggled', [
                'message'      => 'Campus status toggled: ' . $campus->name,
                'code'         => $campus->code,
                'performed_by' => auth()->id(),
            ]);
        });

        return response()->json(['success' => true, 'is_active' => $campus->is_active, 'message' => 'Status updated.']);
    }
    ```
  - **Before — `restore()` (`CampusController.php:271-296`):**
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.campus.restore');

        DB::beginTransaction();
        try {
            $model = Campus::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'Campus restored: ' . $model->name,
                'name'         => $model->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.campus.trashed')->with('success', 'Campus restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Campus', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Campus: ' . $e->getMessage());
        }
    }
    ```
  - **After — `restore()`:**
    ```php
    public function restore($id): RedirectResponse
    {
        Gate::authorize('tenant.accounting.campus.restore');

        $model = Campus::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($model) {
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'Campus restored: ' . $model->name,
                'name'         => $model->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.campus.trashed')->with('success', 'Campus restored successfully.');
    }
    ```
  - **Before — `forceDelete()` (`CampusController.php:298-326`):**
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.campus.forceDelete');

        DB::beginTransaction();
        try {
            $model = Campus::withTrashed()->findOrFail($id);
            if ($model->isPrimary()) {
                return back()->with('error', 'The primary campus cannot be permanently deleted.');
            }
            $name = $model->name;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Campus permanently deleted: ' . $name,
                'name'         => $name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.campus.trashed')->with('success', 'Campus permanently deleted.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to force delete Campus', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Campus: ' . $e->getMessage());
        }
    }
    ```
  - **After — `forceDelete()` (guard moved above the transaction — fixes the open transaction):**
    ```php
    public function forceDelete($id): RedirectResponse
    {
        Gate::authorize('tenant.accounting.campus.forceDelete');

        $model = Campus::withTrashed()->findOrFail($id);

        if ($model->isPrimary()) {
            return back()->with('error', 'The primary campus cannot be permanently deleted.');
        }

        $name = $model->name;

        DB::transaction(function () use ($model, $name) {
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Campus permanently deleted: ' . $name,
                'name'         => $name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.campus.trashed')->with('success', 'Campus permanently deleted.');
    }
    ```
  - **Verify:** `grep -nE "try \{|catch \(|beginTransaction|getMessage|Log::error" Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Expect:** no output (except the two `getMessage`-free guards); `Log` import gone.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

(none — the unique-index decision CMPS-09 should be decided before a user re-tests the store path, but it does not change application code that another item depends on.)

## 3. Errors & transactions (F1/F2)

(covered by CMPS-01.)

## 4. Authorization (F3)

- [ ] **CMPS-07** · L · AUTH-04 · `CampusController.php:33,86` — a FormRequest already authorizes the same permission; drop the duplicate `Gate::authorize` in `store()` and `update()`.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Before** (`CampusController.php:33` and `:86`):
    ```php
        Gate::authorize('tenant.accounting.campus.create');
    ```
    ```php
        Gate::authorize('tenant.accounting.campus.update');
    ```
  - **After:** delete the line at (the new) `store()` and at `update()` **only**. Do NOT delete `Gate::authorize('tenant.accounting.campus.create')` in `create()` or `'tenant.accounting.campus.update'` in `edit()`/`makePrimary()`/`toggleStatus()`/`reorder()` — those methods have no FormRequest.
  - **Verify:** `grep -n "Gate::authorize" Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Expect:** `store` and `update` no longer appear; `create`, `show`, `edit`, `makePrimary`, `destroy`, `toggleStatus`, `reorder`, `trashed`, `restore`, `forceDelete` still do.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **CMPS-10** · M · VAL-05 · `CampusController.php:242` — also validate each `ids` element.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Before** (`CampusController.php:242`):
    ```php
        $request->validate(['ids' => 'required|array']);
    ```
  - **After:**
    ```php
        $request->validate([
            'ids'   => 'required|array',
            'ids.*' => 'integer|exists:acc_campuses,id',
        ]);
    ```
  - **Verify:** `grep -n "ids\.\*" Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Expect:** one hit at the new rule.
  - **Effort:** S

- [ ] **CMPS-12** · L · CTL-03 · `CampusController.php:271,298` — bind the trashed model on the route instead of `$id` + `findOrFail`. ⚠ SHARED (route file).
  - **Touches:** `Modules/Accounting/routes/web.php`, `Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Before** (`CampusController.php:271` and `:298`, `routes/web.php:365-366`):
    ```php
        public function restore($id): \Illuminate\Http\RedirectResponse
    ```
    ```php
        public function forceDelete($id): \Illuminate\Http\RedirectResponse
    ```
    ```php
    Route::get('/campus/{id}/restore', [CampusController::class, 'restore'])->name('campus.restore');
    Route::delete('/campus/{id}/force-delete', [CampusController::class, 'forceDelete'])->name('campus.forceDelete');
    ```
  - **After** — change the route parameter to `{campus}` and the signatures to `restore(Campus $campus)` / `forceDelete(Campus $campus)`, then use `$campus`:
    ```php
    Route::get('/campus/{campus}/restore', [CampusController::class, 'restore'])->withTrashed()->name('campus.restore');
    Route::delete('/campus/{campus}/force-delete', [CampusController::class, 'forceDelete'])->withTrashed()->name('campus.forceDelete');
    ```
    Note: because both methods must see trashed rows, keep the explicit `onlyTrashed()`/`withTrashed()` lookups OR add `->withTrashed()` to the binding; the simplest correct change is to keep the method bodies from CMPS-01 and only rename the parameter. **Tarun must confirm the route-file edit.**
  - **Verify:** `php artisan route:list --json | php /tmp/opencode\routesprobe.php "CampusController"`
  - **Expect:** `accounting.campus.restore` and `accounting.campus.forceDelete` still listed with the same names.
  - **Effort:** M

- [ ] **CMPS-16** · L · CTL-10 · remove dead view `campus/index.blade.php` and unused `Campus::selectable()`.
  - **Touches:** `Modules/Accounting/resources/views/campus/index.blade.php` (delete), `Modules/Accounting/app/Models/Campus.php`
  - **Before** (`Campus.php:78-82`):
    ```php
        /** Active campuses ordered by ordinal — for dropdowns. */
        public static function selectable()
        {
            return static::active()->orderBy('ordinal')->get();
        }
    ```
  - **After:** delete the `selectable()` method and its docblock; delete the whole `resources/views/campus/index.blade.php` file.
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Models\Campus.php" -Pattern "selectable"; Test-Path "Modules\Accounting\resources\views\campus\index.blade.php"`
  - **Expect:** no `selectable` hit; `False` from `Test-Path`.
  - **Effort:** S
  - **⚠ Confirm first** that no external module calls `Campus::selectable()` (`grep -rn "Campus::selectable" .` outside `vendor/`).

- [ ] **CMPS-17** · L · CTL-10 · remove the redundant `use SoftDeletes` from `Campus`.
  - **Touches:** `Modules/Accounting/app/Models/Campus.php`
  - **Before** (`Campus.php:11-13`):
    ```php
    class Campus extends BaseAccountingModel
    {
        use SoftDeletes;
    ```
  - **After:**
    ```php
    class Campus extends BaseAccountingModel
    {
    ```
    Then delete the now-unused `use Illuminate\Database\Eloquent\SoftDeletes;` import (line 8).
  - **Verify:** `grep -n "SoftDeletes" Modules/Accounting/app/Models/Campus.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **CMPS-18 + CMPS-24** · H + M · QRY-01 / TXN-04 · `CampusController.php:244-259` — bulk-update the order in one statement and add the missing audit entry.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Before** (`CampusController.php:244-259`):
    ```php
        DB::beginTransaction();
        try {
            $ids = $request->input('ids');
            foreach ($ids as $ordinal => $id) {
                Campus::where('id', $id)->update(['ordinal' => $ordinal + 1]);
            }

            DB::commit();

            return response()->json(['success' => true, 'message' => 'Order updated.']);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to reorder Campuses', ['error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => 'Failed to reorder: ' . $e->getMessage()], 500);
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($request) {
            $ids = $request->input('ids');

            foreach ($ids as $ordinal => $id) {
                Campus::where('id', $id)->update(['ordinal' => $ordinal + 1]);
            }

            activityLog(auth()->user(), 'Reordered', [
                'message'      => 'Campus display order updated',
                'ids'          => array_values($ids),
                'performed_by' => auth()->id(),
            ]);
        });

        return response()->json(['success' => true, 'message' => 'Order updated.']);
    ```
    (The single-statement rewrite is optional here — campus lists are small; the mandatory parts of this item are removing the try/catch and adding `activityLog()`. If you want the bulk form, replace the loop with `Campus::whereIn('id', array_values($ids))->update([...])` using a `CASE` … only if lists can be large.)
  - **Verify:** `grep -n "activityLog" Modules/Accounting/app/Http/Controllers/CampusController.php | grep -i reorder` — expect one; and `grep -nE "try \{|getMessage" CampusController.php` → no output.
  - **Expect:** a `'Reordered'` entry inside a `DB::transaction`; no catch.
  - **Effort:** S

- [ ] **CMPS-19** · M · QRY-02 · `CampusController.php:266` — paginate at 10 with a distinct page name.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Before** (`CampusController.php:266`):
    ```php
        $campuses = Campus::onlyTrashed()->orderBy('name')->paginate(15);
    ```
  - **After:**
    ```php
        $campuses = Campus::onlyTrashed()
            ->orderBy('name')
            ->paginate(10, ['*'], 'campus_page')
            ->withQueryString();
    ```
  - **Verify:** `grep -n "campus_page" Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Expect:** one hit.
  - **Effort:** S

## 7. Views (F10)

(none — F10 is clean.)

## 8. Style (F12) — one item per file

- [ ] **CMPS-13** · L · CTL-04 · `CampusController.php` — add return types to the four non-mutating public methods (`store`/`update`/`destroy`/`restore`/`forceDelete` already get theirs in CMPS-01).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Before** (`CampusController.php:17,24,70,77`):
    ```php
        public function index()
    ```
    ```php
        public function create()
    ```
    ```php
        public function show(Campus $campus)
    ```
    ```php
        public function edit(Campus $campus)
    ```
  - **After:**
    ```php
        public function index(): RedirectResponse
    ```
    ```php
        public function create(): \Illuminate\View\View
    ```
    ```php
        public function show(Campus $campus): \Illuminate\View\View
    ```
    ```php
        public function edit(Campus $campus): \Illuminate\View\View
    ```
    (`index()` returns `redirect()`, so `RedirectResponse`; the others return `view()`.)
  - **Verify:** `php -l Modules/Accounting/app/Http/Controllers/CampusController.php`
  - **Expect:** `No syntax errors detected`.
  - **Effort:** S

- [ ] **CMPS-22** · L · STY-02 · run Pint on the three in-scope PHP files.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CampusController.php`, `Modules/Accounting/app/Models/Campus.php`, `Modules/Accounting/app/Http/Requests/CampusRequest.php`
  - **Before:** `pint --test` reports `fail` for all three (see report CMPS-22).
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\CampusController.php Modules\Accounting\app\Models\Campus.php Modules\Accounting\app\Http\Requests\CampusRequest.php --format agent` (never `--dirty`).
  - **Verify:** `vendor\bin\pint --test <the three files> --format agent`
  - **Expect:** `{"tool":"pint","result":"pass",...}`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **CMPS-09** · H · DECISION · VAL-04 — the DB `unique('code')` index collides with the soft-delete-aware validation rule on `acc_campuses.code`.
  - **Why it is a decision:** option (b) needs a migration (must never be run by the fixer); option (a) changes validation semantics.
  - (a) ⭐ Drop `->whereNull('deleted_at')` from the `code` rule so it mirrors the DB index exactly (no migration, no data change; re-using a trashed code is then correctly rejected with a validation message).
  - (b) Add a new additive migration changing the unique key to `(code, deleted_at)` so a trashed code can be re-used, and keep the current rule.
  - (c) Leave as is and accept that re-using a trashed code shows a 500 (not recommended).
  - ➜ Choice: ____

- [ ] **CMPS-06** · M · DECISION · TXN-06 — no lock/unique index guarantees one ordinal value per campus or a single primary.
  - **Why it is a decision:** a partial unique index (`is_primary = 1`) needs a migration; `lockForUpdate()` is a behaviour change.
  - (a) ⭐ Add `lockForUpdate()` around the `max('ordinal')` read and the primary bulk-update inside the CMPS-01 transactions (no migration).
  - (b) Add a migration with a unique index / generated column enforcing one primary, and rely on it.
  - (c) Leave as is; the model `saving` hook is "good enough" (note the live data already has 2 primaries).
  - ➜ Choice: ____

- [ ] **CMPS-11** · H · DECISION · RTE-01 — `GET /accounting/campus/{id}/restore` performs a write. ⚠ SHARED (route file + the `action-trashed` component call).
  - **Why it is a decision:** changing the verb is a route re-scope (§9.3) and affects the shared `x-backend.table.action-trashed` component.
  - (a) ⭐ Change to `Route::post('/campus/{campus}/restore', …)` and update the trashed-row action to submit a POST form (route name unchanged).
  - (b) Keep GET and add a confirmation/CSRF guard (weaker; does not meet RTE-01).
  - (c) Leave as is, record as accepted.
  - ➜ Choice: ____

- [ ] **CMPS-15** · M · DECISION · CTL-06 — the "one primary" rule is implemented twice (controller + `Campus` model `saving` hook).
  - **Why it is a decision:** it is a behaviour/ownership refactor with a blast radius across every campus write path.
  - (a) ⭐ Keep the model `saving` hook as the single owner and delete the controller's duplicate bulk updates in `store()`/`update()`/`makePrimary()`.
  - (b) Move the rule into a new `CampusService` and call it from the controller (larger refactor; new class).
  - (c) Leave the duplication and record it as accepted.
  - ➜ Choice: ____

- [ ] **CMPS-08** · M · DECISION · AUTH-06 — the `tenant.accounting.campus.*` literals are repeated in the controller, `CampusRequest` and the blades.
  - **Why it is a decision:** the literals also appear in the shared partial `_campuses.blade.php` (owned by another report), so a project-wide constants refactor must be coordinated.
  - (a) ⭐ Introduce a `CampusPermissions` constants class and use it in the controller + `CampusRequest`; leave the shared partial to its own report.
  - (b) Defer the whole refactor to a module-wide pass.
  - (c) Leave as is.
  - ➜ Choice: ____

- [ ] **CMPS-20** · L · DECISION · CTL-05 — two "create campus" UIs exist (the modal in the Campuses tab and the routed `campus/create.blade.php`).
  - **Why it is a decision:** removing a routed page changes reachable URLs (§9.3).
  - (a) ⭐ Delete the unused `create()` page path (keep the modal) — remove `campus/create.blade.php` and the `create()` method + route.
  - (b) Keep both and link the page from the modal.
  - (c) Leave as is.
  - ➜ Choice: ____

- [ ] **CMPS-21** · M · DECISION · SEC-03 — hard-coded id fallback `1` in the shared `BaseAccountingModel` and `AccountingContext`. ⚠ SHARED (77 models).
  - **Why it is a decision:** the classes are shared; changing the fallback affects every accounting model's `created_by`/`updated_by`/`campus_id`.
  - (a) ⭐ Return `null` instead of `1` when no user/campus is resolved (leave `created_by`/`campus_id` null), and audit the 77 models for reliance on the old fallback.
  - (b) Throw a domain exception when identity cannot be resolved (stricter; may break seeders).
  - (c) Leave as is and record as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CMPS-02 | resolved by CMPS-01 (same rewrite) |
| CMPS-03 | resolved by CMPS-01 |
| CMPS-04 | resolved by CMPS-01 |
| CMPS-05 | resolved by CMPS-01 |
| CMPS-14 | resolved by CMPS-01 (the `makePrimary` rewrite injects `Request`) |
| CMPS-23 | resolved by CMPS-01 (the `update()` rewrite adds the guard) |
