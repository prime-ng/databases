# Final Audit — Accounting / TdsPaymentAllocationController

**Audited:** 2026-10-23 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php` (131 lines, 2 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/tds?tab=tds-allocations` (the tab that renders the form and the list); form posts to `POST /accounting/tds-payment-allocation`; each row's delete button calls `DELETE /accounting/tds-payment-allocation/{tds_payment_allocation}` |
| Menu path | Accounting → TDS (TDS Management) → **TDS Allocations** tab |
| Who uses it | **Measured: no role holds the permission.** `tenant.accounting.tds-payment.create` and `.delete` are absent from `config/permissionslist.php`, absent from `sys_permissions`, and granted 0 times in `sys_role_has_permissions_jnt`. Only a user with both `is_super_admin` and `super_admin_flag` reaches the screen, because `AppServiceProvider::boot()` bypasses every gate for that user (`app/Providers/AppServiceProvider.php:78-83`). |
| What a user does here | Allocates part (or all) of a TDS challan's deposited amount to an unpaid TDS deduction, then removes an allocation if it was entered against the wrong deduction. Saving an allocation updates the challan's `allocated_amount`/`status` and the deduction's `paid_amount`/`status`, and writes an activity-log row. |
| Tables written | `acc_tds_payment_allocations`, `acc_tds_payments`, `acc_tds_deductions`, `sys_activity_logs` (through `activityLog()`) |
| Tables read | `acc_tds_payments`, `acc_tds_deductions`, `acc_tds_payment_allocations` (the FormRequest's `exists`/`unique` checks); `sys_permissions` through each `Gate` call |
| Live data | `acc_tds_payment_allocations` 1 row (not trashed), `acc_tds_payments` 1, `acc_tds_deductions` 1; 0 payments in `Filed` status and 0 deductions in `Reversed` status. ⚠ The single live allocation (₹2,400) was inserted by `AccountingSeeder` with `allocated_amount = 0.00` on the payment and `paid_amount = 0.00` on the deduction (see §7). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No — the screen is not production-ready. The single worst finding is **TDSA-12**: the model expects an `updated_at` column that no migration creates, so every allocation insert and every soft delete fails with `SQLSTATE[42S22]`, and **TDSA-01** then shows that SQL text to the user in the red flash. The screen cannot create or remove a single allocation until the model/schema mismatch is fixed; after that, the missing permission key (TDSA-06) still locks every non-super-admin role out. Rough effort is **S** — about half a developer-day for TDSA-12, TDSA-01, TDSA-08 and the Pint pass; TDSA-06 and TDSA-14 need Tarun's decision.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 5 | 4 | 3 | 2 | 14 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TDSA-01, TDSA-02, TDSA-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | TDSA-04, TDSA-05 | F9 Queries/Perf | clean |
| F3 Authorization | TDSA-06, TDSA-07 | F10 Views | n/a — no view is rendered by this controller |
| F4 Validation | TDSA-08, TDSA-09 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | TDSA-13 |
| F6 Controller shape | TDSA-10, TDSA-11 | F13 Deep read | TDSA-14 |
| F7 Models | TDSA-12 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php` | controller | 131 | this report | ✅ |
| 2 | `Modules/Accounting/app/Http/Requests/TdsPaymentAllocationRequest.php` | FormRequest | 55 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Models/TdsPaymentAllocation.php` | model | 49 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | model base | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 5 | `Modules/Accounting/app/Models/TdsPayment.php` | model | 148 | ↗ [gaurav/Accounting/TdsPaymentController](../TdsPaymentController/01-report.md) | ↗ linked |
| 6 | `Modules/Accounting/app/Models/TdsDeduction.php` | model | 193 | ↗ [gaurav/Accounting/TdsDeductionController](../TdsDeductionController/01-report.md) | ↗ linked |
| 7 | `Modules/Accounting/app/Services/AccountingContext.php` | service | 110 | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 8 | `app/Helpers/activityLog.php` | helper (common) | 51 | common — see §7 | ⚠ cross-cutting |
| 9 | `Modules/GlobalMaster/app/Models/ActivityLog.php` | model (common, reached through the helper) | 50 | common — see §7 | ⚠ cross-cutting |

`AccountingContext` is linked but **not exercised** on this path: `TdsPaymentAllocation::$fillable` has no `created_by`, `financial_year_id`, `period_id` or `campus_id`, so `BaseAccountingModel::resolveAccountingContextOnCreating()` has nothing to assign.

No pre-applied files.

## 4. Routes

```
POST      accounting/tds-payment-allocation                       accounting.tds-payment-allocation.store Modules\Accounting\Http\Controllers\TdsPaymentAllocationController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/tds-payment-allocation/{tds_payment_allocation} accounting.tds-payment-allocation.destroy Modules\Accounting\Http\Controllers\TdsPaymentAllocationController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none — `store()` and `destroy()` are the only public methods, and both are routed.

Route parameter binding is correct: the route uses `{tds_payment_allocation}` and the method argument is `$tdsPaymentAllocation`; Laravel's `ImplicitRouteBinding::getParameterName()` snake-cases the argument name to find the route parameter (`vendor/laravel/framework/src/Illuminate/Routing/ImplicitRouteBinding.php`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `store` | 19 | POST /accounting/tds-payment-allocation | `tenant.accounting.tds-payment.create` (FormRequest **and** controller) | controller, manual `beginTransaction` — left open by the two early returns at 37/41 | `Created` (line 63) | `acc_tds_payment_allocations`, `acc_tds_payments`, `acc_tds_deductions`, `sys_activity_logs` | TDSA-01, TDSA-02, TDSA-03, TDSA-04, TDSA-05, TDSA-06, TDSA-07, TDSA-08, TDSA-09, TDSA-12, TDSA-14 |
| `destroy` | 84 | DELETE /accounting/tds-payment-allocation/{tds_payment_allocation} | `tenant.accounting.tds-payment.delete` | controller, manual `beginTransaction`/`commit`/`rollBack` | `Deleted` (line 114) | `acc_tds_payments`, `acc_tds_deductions`, `acc_tds_payment_allocations`, `sys_activity_logs` | TDSA-01, TDSA-03, TDSA-04, TDSA-05, TDSA-06, TDSA-11, TDSA-12, TDSA-14 |

## 6. Findings

### F1 — Errors

#### TDSA-01 · B · ERR-01 — Both catch blocks show the raw SQL exception to the user

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak*. Also violates D1: no `try/catch` in a controller unless a D2 shape applies. |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:73-81` (`store()`), `:124-129` (`destroy()`) |
| **Root cause** | Both mutations wrap the whole write in `catch (\Throwable $e)` and append `$e->getMessage()` to the flash. `QueryException` extends `RuntimeException`, so duplicate keys, missing columns and foreign-key failures reach the browser as SQL, including table and column names. The broad catch is itself the D1 violation. |
| **Consequence** | A user who submits an allocation sees `Failed to allocate TDS: SQLSTATE[42S22] Unknown column 'updated_at'` (with the failing INSERT into `acc_tds_payment_allocations`) instead of a business message. |
| **Reproduce** | Open `http://test.localhost:8000/accounting/tds?tab=tds-allocations`, fill the allocation form and submit. Expected a success flash; actual a red flash containing the SQL text (the schema mismatch in TDSA-12 triggers it today). |
| **Fix approach** | Remove both `try/catch` blocks (D1) and let `bootstrap/app.php` log and render the exception. Plan item TDSA-01 rewrites both methods. |
| **Plan item** | TDSA-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentAllocationController.php:73-81 — CURRENT (store; destroy's catch is at 124-129)
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create TDS Payment Allocation', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to allocate TDS: ' . $e->getMessage());
        }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "getMessage|catch \("
73:        } catch (\Throwable $e) {
76:                'error' => $e->getMessage(),
80:            return back()->withInput()->with('error', 'Failed to allocate TDS: ' . $e->getMessage());
124:        } catch (\Throwable $e) {
126:            Log::error('Failed to delete TDS Allocation', ['id' => $tdsPaymentAllocation->id, 'error' => $e->getMessage()]);
128:            return back()->with('error', 'Failed to delete TDS Allocation: ' . $e->getMessage());
```

#### TDSA-02 · H · ERR-02 — A soft-deleted challan or deduction becomes a redirect instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or a 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:25-28` and `:73-81`, method `store()` |
| **Root cause** | `TdsPayment::findOrFail()` and `TdsDeduction::findOrFail()` sit inside the `try`, and `catch (\Throwable $e)` swallows `ModelNotFoundException`. The FormRequest's `exists` rules do not filter `deleted_at`, so an id belonging to a soft-deleted row passes validation and then reaches `findOrFail()`. |
| **Consequence** | A stale form that references a deleted challan or deduction redirects back with a red "Failed to allocate TDS" flash instead of a 404, so the user cannot tell a stale page from a server failure. |
| **Reproduce** | Static only — needs a soft-deleted row in `acc_tds_payments` or `acc_tds_deductions`; none exists on `test.localhost` today. Submit the form with that id: validation passes, `findOrFail()` throws, the catch redirects. |
| **Fix approach** | TDSA-01 loads both rows with `lockForUpdate()` inside `DB::transaction` and removes the catch, so `ModelNotFoundException` reaches the central handler as a 404. |
| **Plan item** | TDSA-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentAllocationController.php:25-28 — CURRENT
        DB::beginTransaction();
        try {
            $payment = TdsPayment::findOrFail($validated['tds_payment_id']);
            $deduction = TdsDeduction::findOrFail($validated['tds_deduction_id']);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "findOrFail|catch \("
27:            $payment = TdsPayment::findOrFail($validated['tds_payment_id']);
28:            $deduction = TdsDeduction::findOrFail($validated['tds_deduction_id']);
73:        } catch (\Throwable $e) {
124:        } catch (\Throwable $e) {
```

#### TDSA-03 · M · ERR-05 — The log stores the message string, not the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:75-78` (`store()`), `:126` (`destroy()`) |
| **Root cause** | The catches call `Log::error('Failed to create TDS Payment Allocation', ['error' => $e->getMessage()])`; `store()` also stores `getTraceAsString()` as text. No exception object is passed, so the central reporter in `bootstrap/app.php` never sees the failure. |
| **Consequence** | Production debugging is slower: the log has a string rather than the exception class, context and stack that the central handler would record. |
| **Reproduce** | Static only — read the two catch blocks; a log inspection would be needed after forcing a failure. |
| **Fix approach** | Let the exception escape (D1); the central handler reports the object. No catch remains. |
| **Plan item** | TDSA-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentAllocationController.php:75-78 — CURRENT
            Log::error('Failed to create TDS Payment Allocation', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "Log::error"
75:            Log::error('Failed to create TDS Payment Allocation', [
126:            Log::error('Failed to delete TDS Allocation', ['id' => $tdsPaymentAllocation->id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### TDSA-04 · M · TXN-02 — Both methods hand-roll the transaction and two early returns abandon it

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`; never `return` between them* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:25, 37, 41, 69, 74` (`store()`); `:88, 120, 125` (`destroy()`) |
| **Root cause** | Both methods open the transaction by hand. In `store()`, the two balance failures `return back()` before `DB::commit()` or `DB::rollBack()`, so the transaction stays open until the connection is torn down. |
| **Consequence** | The write paths are fragile: an early return or a later throw can leave the request inside an open transaction, and the manual shape is what the D1 rewrite has to unwind anyway. |
| **Reproduce** | Static only — submit an amount larger than the challan balance; the redirect is returned from inside the open transaction. |
| **Fix approach** | Wrap each mutation in `DB::transaction(function () { … })`, build the response after it, and remove the manual calls (TDSA-01). |
| **Plan item** | TDSA-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentAllocationController.php:25-41 — CURRENT
        DB::beginTransaction();
        try {
            $payment = TdsPayment::findOrFail($validated['tds_payment_id']);
            $deduction = TdsDeduction::findOrFail($validated['tds_deduction_id']);

            $amount = (float) $validated['amount'];

            // Validation: cannot allocate more than payment remaining or deduction remaining
            $paymentRemaining = (float) $payment->total_amount - (float) $payment->allocated_amount;
            $deductionRemaining = (float) $deduction->tds_amount - (float) $deduction->paid_amount;

            if ($amount > $paymentRemaining + 0.001) {
                return back()->with('error', 'Allocation amount (' . number_format($amount, 2) . ') exceeds unallocated challan balance (' . number_format($paymentRemaining, 2) . ').');
            }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "DB::beginTransaction|DB::commit|DB::rollBack|return back"
25:        DB::beginTransaction();
37:                return back()->with('error', 'Allocation amount (' . number_format($amount, 2) . ') exceeds unallocated challan balance (' . number_format($paymentRemaining, 2) . ').');
41:                return back()->with('error', 'Allocation amount (' . number_format($amount, 2) . ') exceeds remaining unpaid deduction amount (' . number_format($deductionRemaining, 2) . ').');
69:            DB::commit();
74:            DB::rollBack();
80:            return back()->withInput()->with('error', 'Failed to allocate TDS: ' . $e->getMessage());
88:        DB::beginTransaction();
120:            DB::commit();
125:            DB::rollBack();
128:            return back()->with('error', 'Failed to delete TDS Allocation: ' . $e->getMessage());
```

#### TDSA-05 · H · TXN-06 — Two concurrent allocations can over-allocate a challan or deduction

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:33-34, 48-53, 56-61` (`store()`); `:96-108` (`destroy()`) |
| **Root cause** | Both methods read `allocated_amount`/`paid_amount`, add or subtract in PHP and write the absolute new value with `update()`. Neither load uses `lockForUpdate()`, so two requests that arrive together read the same baseline; when they target different deductions, both inserts succeed and the second write overwrites the first aggregate. |
| **Consequence** | Two simultaneous allocations of different deductions against the same challan can both pass the remaining-amount check and leave `allocated_amount`/`paid_amount` lower than the sum of the real allocation rows, so the dashboard under-reports what is allocated and allows over-allocation. |
| **Reproduce** | Static only — requires two overlapping requests; no parallel submission was made under D4. |
| **Fix approach** | Inside the transaction, load the payment and deduction with `lockForUpdate()` and recompute the totals there (TDSA-01's rewrite does this). |
| **Plan item** | TDSA-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentAllocationController.php:33-34 — CURRENT (the read)
            $paymentRemaining = (float) $payment->total_amount - (float) $payment->allocated_amount;
            $deductionRemaining = (float) $deduction->tds_amount - (float) $deduction->paid_amount;
```

```php
// TdsPaymentAllocationController.php:48-53 — CURRENT (the write-back)
            $newPaymentAllocated = (float) $payment->allocated_amount + $amount;
            $paymentStatus = $newPaymentAllocated >= (float) $payment->total_amount ? 'Allocated' : ($payment->status === 'Draft' ? 'Paid' : $payment->status);
            $payment->update([
                'allocated_amount' => $newPaymentAllocated,
                'status'           => $paymentStatus,
            ]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "lockForUpdate"
(no output — no row lock is taken anywhere in the controller)

> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "allocated_amount|paid_amount"
33:            $paymentRemaining = (float) $payment->total_amount - (float) $payment->allocated_amount;
34:            $deductionRemaining = (float) $deduction->tds_amount - (float) $deduction->paid_amount;
48:            $newPaymentAllocated = (float) $payment->allocated_amount + $amount;
51:                'allocated_amount' => $newPaymentAllocated,
56:            $newDeductionPaid = (float) $deduction->paid_amount + $amount;
59:                'paid_amount' => $newDeductionPaid,
96:                $newAlloc = max(0, (float) $payment->allocated_amount - $amount);
98:                    'allocated_amount' => $newAlloc,
105:                $newPaid = max(0, (float) $deduction->paid_amount - $amount);
107:                    'paid_amount' => $newPaid,
```

### F3 — Authorization

#### TDSA-06 · H · AUTH-01 — The permission the screen checks does not exist, so only Super Admin can use it

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (H) — *every routed method authorizes with a permission that is declared and seeded* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:21, 86`; `Modules/Accounting/app/Http/Requests/TdsPaymentAllocationRequest.php:15-18`; `config/permissionslist.php` (no `accounting.tds-payment` key) |
| **Root cause** | The controller and the FormRequest build `tenant.accounting.tds-payment.{create,delete}` from a base key that is not declared in `config/permissionslist.php`; the tenant database therefore has no such rows and no role grants. `Gate::allows()` returns `false` for every normal user. A user with both super-admin flags bypasses gates in `AppServiceProvider`. |
| **Consequence** | Account Manager and Account Staff — the roles that should record TDS allocations — receive a 403 as soon as the form is submitted, so the feature is usable only by Super Admin. |
| **Reproduce** | Log in as Account Manager, open `http://test.localhost:8000/accounting/tds?tab=tds-allocations`, submit the allocation form. Expected the allocation to save; actual 403 "This action is unauthorized." |
| **Fix approach** | Decide whether to add `'accounting.tds-payment' => $crud` to `config/permissionslist.php`, sync permissions and grant it. This is a new permission key on a shared config file, so it is a DECISION item. |
| **Plan item** | TDSA-06 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// TdsPaymentAllocationController.php:19-21 — CURRENT
    public function store(TdsPaymentAllocationRequest $request)
    {
        Gate::authorize('tenant.accounting.tds-payment.create');
```

**Evidence**
```
> Select-String -Path "config\*.php" -Pattern "tds-payment"
config\breadcrumbs.php:246: 'tab' => 'tds-payments',
config\breadcrumbs.php:248: 'accounting.tds-payment-allocation.index' => [
(no permission declaration)

> mysql -u root -N -e "SELECT name FROM xyz_school_00000000000040008000_202627.sys_permissions WHERE name IN ('tenant.accounting.tds-payment.create','tenant.accounting.tds-payment.delete'); SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_role_has_permissions_jnt j JOIN xyz_school_00000000000040008000_202627.sys_permissions p ON p.id=j.permission_id WHERE p.name LIKE 'tenant.accounting.tds-payment.%';"
0

> Select-String -Path "app\Providers\AppServiceProvider.php" -Pattern "is_super_admin" -Context 0,2
79:            if ($user->is_super_admin && $user->super_admin_flag) {
80:                return true;
```

#### TDSA-07 · L · AUTH-04 — `store` checks the create permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *do not authorize the same permission twice; keep one* |
| **Where** | `Modules/Accounting/app/Http/Requests/TdsPaymentAllocationRequest.php:15-18` and `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:21` |
| **Root cause** | The FormRequest's `authorize()` maps POST to `tenant.accounting.tds-payment.create`, then `store()` calls `Gate::authorize()` with the same name. The FormRequest runs first, so the controller call can never add anything. |
| **Consequence** | No runtime difference today; a future permission rename must be made in two places, and one copy can drift. |
| **Reproduce** | Static only — inspect the FormRequest `authorize()` and line 21. |
| **Fix approach** | Keep the FormRequest check and remove the duplicate `Gate::authorize()` from `store()`; `destroy()` has no FormRequest, so it keeps its own check. TDSA-01 does this. |
| **Plan item** | TDSA-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentAllocationRequest.php:15-18 — CURRENT
    public function authorize(): bool
    {
        return $this->authorizeByCrudPermission('tenant.accounting.tds-payment');
    }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\TdsPaymentAllocationRequest.php","Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "authorizeByCrudPermission|Gate::authorize"
TdsPaymentAllocationRequest.php:17:        return $this->authorizeByCrudPermission('tenant.accounting.tds-payment');
TdsPaymentAllocationController.php:21:        Gate::authorize('tenant.accounting.tds-payment.create');
TdsPaymentAllocationController.php:86:        Gate::authorize('tenant.accounting.tds-payment.delete');
```

### F4 — Validation and input

#### TDSA-08 · H · VAL-04 — A soft-deleted allocation passes the unique rule but violates the database index

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules must mirror the DB unique index, including soft-delete semantics* |
| **Where** | `Modules/Accounting/app/Http/Requests/TdsPaymentAllocationRequest.php:26-33`; `database/migrations/tenant/2026_09_16_100075_create_acc_tds_payment_allocations_table.php:29` |
| **Root cause** | The rule ends with `->withoutTrashed()`, which tells the validator to ignore rows with `deleted_at`; the unique index `uq_acc_tdsalloc (tds_payment_id, tds_deduction_id)` has no `deleted_at` column and still counts trashed rows. The model soft-deletes through `BaseAccountingModel`, so the row survives. |
| **Consequence** | After an allocation is removed, re-allocating the same challan to the same deduction passes validation and then fails the insert with a duplicate-key `QueryException`, which TDSA-01 shows to the user as SQL text. |
| **Reproduce** | Delete allocation #1 (after TDSA-12 is fixed), then submit the same challan + deduction pair again. Expected a friendly "already allocated" message; actual a duplicate-key `SQLSTATE[23000]` error that names `uq_acc_tdsalloc`. |
| **Fix approach** | Remove `->withoutTrashed()` so the rule sees the trashed row and returns a normal validation message. |
| **Plan item** | TDSA-08 in `02-fix-plan.md` §2 |

```php
// TdsPaymentAllocationRequest.php:26-33 — CURRENT
            'tds_deduction_id' => [
                'required',
                'exists:acc_tds_deductions,id',
                Rule::unique('acc_tds_payment_allocations', 'tds_deduction_id')
                    ->where(fn($q) => $q->where('tds_payment_id', $this->input('tds_payment_id')))
                    ->ignore($id)
                    ->withoutTrashed(),
            ],
```

**Evidence**
```
> mysql -u root -N -e "SELECT INDEX_NAME, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA='xyz_school_00000000000040008000_202627' AND TABLE_NAME='acc_tds_payment_allocations' AND NON_UNIQUE=0 GROUP BY INDEX_NAME;"
PRIMARY	id
uq_acc_tdsalloc	tds_payment_id,tds_deduction_id

> mysql -u root -N -e "SHOW COLUMNS FROM xyz_school_00000000000040008000_202627.acc_tds_payment_allocations;" | Select-String -Pattern "deleted_at"
deleted_at	timestamp	YES		NULL

> Select-String -Path "Modules\Accounting\app\Http\Requests\TdsPaymentAllocationRequest.php" -Pattern "withoutTrashed"
32:                    ->withoutTrashed(),
```

#### TDSA-09 · M · VAL-07 — The two balance rules are hand-written in the controller

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M) — *cross-field/business checks belong in the FormRequest's `after()` hook, not in the controller* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:32-42` |
| **Root cause** | The "amount must not exceed the challan or deduction remaining" rules are written inline, after the FormRequest has already returned, instead of in `TdsPaymentAllocationRequest::after()`. |
| **Consequence** | No user-visible bug today; the rules cannot be unit-checked with the rest of the request's validation and sit in the controller's write path. |
| **Reproduce** | Static only — compare the FormRequest (no `after()`) with lines 36-42. |
| **Fix approach** | Not planned in this pass: both checks need the two loaded models, and TDSA-01 moves them inside the transaction. Recorded as accepted maintainability debt; move them to `after()` when the TDS screen is next reworked. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// TdsPaymentAllocationController.php:32-42 — CURRENT
            // Validation: cannot allocate more than payment remaining or deduction remaining
            $paymentRemaining = (float) $payment->total_amount - (float) $payment->allocated_amount;
            $deductionRemaining = (float) $deduction->tds_amount - (float) $deduction->paid_amount;

            if ($amount > $paymentRemaining + 0.001) {
                return back()->with('error', 'Allocation amount (' . number_format($amount, 2) . ') exceeds unallocated challan balance (' . number_format($paymentRemaining, 2) . ').');
            }

            if ($amount > $deductionRemaining + 0.001) {
                return back()->with('error', 'Allocation amount (' . number_format($amount, 2) . ') exceeds remaining unpaid deduction amount (' . number_format($deductionRemaining, 2) . ').');
            }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\TdsPaymentAllocationRequest.php" -Pattern "after\(|withValidator"
(no output — the request has no after() hook)

> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "exceeds unallocated|exceeds remaining"
37:                return back()->with('error', 'Allocation amount (' . number_format($amount, 2) . ') exceeds unallocated challan balance (' . number_format($paymentRemaining, 2) . ').');
41:                return back()->with('error', 'Allocation amount (' . number_format($amount, 2) . ') exceeds remaining unpaid deduction amount (' . number_format($deductionRemaining, 2) . ').');
```

### F5 — Routes

clean — `php artisan route:list --json` through the route probe shows exactly two routes, `POST accounting/tds-payment-allocation` → `store` and `DELETE accounting/tds-payment-allocation/{tds_payment_allocation}` → `destroy`; both methods exist (`Select-String -Pattern "public function"` → lines 19 and 84); every route is POST/DELETE (no state change over GET), the route parameter `tds_payment_allocation` resolves to `$tdsPaymentAllocation` (Laravel `ImplicitRouteBinding::getParameterName()` snake-cases the argument), and both routes carry the tenancy/auth/module middleware group shown in §4.

### F6 — Controller shape

#### TDSA-10 · L · CTL-04 — Both public methods lack return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:19, 84` |
| **Root cause** | `store()` and `destroy()` declare no return type; both return a `RedirectResponse`. |
| **Consequence** | No runtime effect; the response contract is invisible to static analysis and to the next developer. |
| **Reproduce** | Static only — inspect the two signatures. |
| **Fix approach** | Add `: \Illuminate\Http\RedirectResponse` to both signatures. |
| **Plan item** | TDSA-10 in `02-fix-plan.md` §8 |

```php
// TdsPaymentAllocationController.php:19 and 84 — CURRENT
    public function store(TdsPaymentAllocationRequest $request)
    public function destroy(TdsPaymentAllocation $tdsPaymentAllocation)
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "public function"
19:    public function store(TdsPaymentAllocationRequest $request)
84:    public function destroy(TdsPaymentAllocation $tdsPaymentAllocation)
```

#### TDSA-11 · M · CTL-10 — The payment status ternary returns `'Paid'` on both branches

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code; a branch that can never change the value is dead code* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:99` |
| **Root cause** | `$newAlloc <= 0 ? 'Paid' : 'Paid'` returns the same literal whichever way the condition goes. |
| **Consequence** | No user-visible change today; the meaningless branch hides the intended status rule and is copied forward as if it mattered. |
| **Reproduce** | Static only — read line 99. |
| **Fix approach** | Replace the ternary with the literal `'Paid'` (TDSA-01's destroy rewrite does this). Any real terminal-status rule is TDSA-14's decision. |
| **Plan item** | TDSA-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentAllocationController.php:99 — CURRENT
                    'status'           => $newAlloc <= 0 ? 'Paid' : 'Paid',
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "\? 'Paid' : 'Paid'"
99:                    'status'           => $newAlloc <= 0 ? 'Paid' : 'Paid',
```

### F7 — Models

#### TDSA-12 · B · MDL-07 — The model writes `updated_at`, but the table has no such column

| Field | Value |
|---|---|
| **Rule** | MDL-07 (B) — *a model must match a table that exists in a migration; here the table exists but the model writes a column no migration creates (same class of failure, B because it crashes the normal write path)* |
| **Where** | `Modules/Accounting/app/Models/TdsPaymentAllocation.php:9-11`; `database/migrations/tenant/2026_09_16_100075_create_acc_tds_payment_allocations_table.php:20-36` |
| **Root cause** | `TdsPaymentAllocation` inherits Eloquent's default timestamps (verified: `usesTimestamps()` is `true`, `getUpdatedAtColumn()` is `updated_at`). The migration creates only `created_at` plus the soft-delete/is-active columns added later; no migration ever adds `updated_at`. Eloquent therefore includes `updated_at` in the INSERT and in the soft-delete UPDATE. |
| **Consequence** | Every `TdsPaymentAllocation::create()` in `store()` and every soft delete in `destroy()` fails with `SQLSTATE[42S22] Unknown column 'updated_at'`; no allocation can be created or removed, and TDSA-01 shows the SQL to the user. |
| **Reproduce** | Open `http://test.localhost:8000/accounting/tds?tab=tds-allocations`, submit the allocation form. Expected a success flash; actual the red SQL error. Static proof below because this audit is read-only. |
| **Fix approach** | Add `public const UPDATED_AT = null;` to the model. Eloquent then stops writing `updated_at` while still writing `created_at`; the table keeps its DDL shape and no migration is touched. |
| **Plan item** | TDSA-12 in `02-fix-plan.md` §1 |

```php
// TdsPaymentAllocation.php:7-11 — CURRENT
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class TdsPaymentAllocation extends BaseAccountingModel
{
    protected $table = 'acc_tds_payment_allocations';
```

**Evidence**
```
> mysql -u root -N -e "SHOW COLUMNS FROM xyz_school_00000000000040008000_202627.acc_tds_payment_allocations;"
id	bigint unsigned	NO	PRI	NULL	auto_increment
tds_payment_id	bigint unsigned	NO	MUL	NULL	
tds_deduction_id	bigint unsigned	NO	MUL	NULL	
amount	decimal(15,2)	NO		NULL	
allocated_by	int unsigned	YES	MUL	NULL	
created_at	timestamp	NO		CURRENT_TIMESTAMP	DEFAULT_GENERATED
is_active	tinyint(1)	NO		1	
deleted_at	timestamp	YES		NULL	
(no updated_at row)

> php artisan tinker --execute="dump((new Modules\Accounting\Models\TdsPaymentAllocation)->usesTimestamps()); dump((new Modules\Accounting\Models\TdsPaymentAllocation)->getUpdatedAtColumn());"
true // vendor\psy\psysh\src\ExecutionClosure.php(41) : eval()'d code:1
"updated_at" // vendor\psy\psysh\src\ExecutionClosure.php(41) : eval()'d code:2

> Select-String -Path "database\migrations\tenant\2026_09_16_100075_create_acc_tds_payment_allocations_table.php" -Pattern "created_at|updated_at|unique"
26:            $table->timestamp('created_at')->useCurrent();
29:            $table->unique(['tds_payment_id', 'tds_deduction_id'], 'uq_acc_tdsalloc');
(no updated_at)
```

### F8 — Services and jobs

clean — `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "Service|Job|dispatch|queue"` → no output. The controller calls no service and dispatches no job; `AccountingContext` is reached only through the model base and is not exercised (see §3).

### F9 — Queries and performance

clean — no loop, no list query and no raw SQL in the controller: `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "foreach|for \(|->get\(|paginate|DB::raw|whereRaw|select\("` → no output. `store()` issues two keyed loads and two keyed updates; `destroy()` issues two belongs-to loads and two keyed updates. The live tables are one row each.

### F10 — Views

n/a — the controller renders no Blade view; both methods return redirects. The `tds-allocations` tab partial is rendered by `AccDashboardController::tdsManagement()` and its `$allocations` query is eager-loaded with `allocations.tdsPayment`, `allocations.tdsDeduction` and related relations (`Modules/Accounting/app/Http/Controllers/AccDashboardController.php:1464-1480`), so no view finding belongs to this report.

### F11 — Security and tenancy

clean — `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "env\(|DB::raw|whereRaw|\?\? 1|Log::.*request"` → no output; the controller uses no raw SQL, no hard-coded ids and no `env()`. Every route carries the tenant middleware group (§4), and the log entries contain no request body, password or payment-card data.

### F12 — Style

#### TDSA-13 · L · STY-02 — Pint fails on all three in-scope PHP files

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php`; `Modules/Accounting/app/Http/Requests/TdsPaymentAllocationRequest.php`; `Modules/Accounting/app/Models/TdsPaymentAllocation.php` |
| **Root cause** | The controller fails `concat_space`, `no_unused_imports` (unused `Illuminate\Http\Request`), `ordered_imports` and `binary_operator_spaces`; the request fails `function_declaration` (`fn($q)`), `ordered_imports` and `binary_operator_spaces`; the model fails `fully_qualified_strict_types`, `no_unused_imports` (`App\Models\BaseModel`), `single_line_after_imports` and `binary_operator_spaces`. |
| **Consequence** | The style gate fails, and the next Pint run rewrites the files, creating review noise in unrelated lines. |
| **Reproduce** | Run `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php --format agent`, then the same command for the request and the model. |
| **Fix approach** | Run Pint on the three files after the functional items; it removes the two unused imports and normalises the spacing. |
| **Plan item** | TDSA-13 in `02-fix-plan.md` §8 |

```php
// TdsPaymentAllocation.php:7-8 — CURRENT (unused BaseModel import; no blank line after imports)
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
```

**Evidence**
```
> vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" "Modules\Accounting\app\Http\Requests\TdsPaymentAllocationRequest.php" "Modules\Accounting\app\Models\TdsPaymentAllocation.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\TdsPaymentAllocationController.php","fixers":["concat_space","no_unused_imports","ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Http\\Requests\\TdsPaymentAllocationRequest.php","fixers":["function_declaration","ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Models\\TdsPaymentAllocation.php","fixers":["fully_qualified_strict_types","no_unused_imports","single_line_after_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 Wrong data? | Q2 Delete before replacement? | Q3 Duplicate implementation? | Q4 Soft-delete × unique? | Q5 Race? | Q6 Auth hole? | Q7 Message lies? | Q8 Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | TDSA-14 | ok | ok | TDSA-08 | TDSA-05 | TDSA-06 | ok | ok |
| `destroy` | TDSA-14 | ok | ok | TDSA-08 | TDSA-05 | TDSA-06 | TDSA-11 | ok |

#### TDSA-14 · H · F13-Q1 — Terminal statuses are not respected by either method

| Field | Value |
|---|---|
| **Rule** | F13 deep-read Q1 (H) — *a write must not overwrite data it should not* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:27-28, 49-53` (`store()`); `:95-110` (`destroy()`) |
| **Root cause** | `store()` loads the challan and deduction without checking their status, so an allocation can be added to a challan in `Filed`/`Cancelled` status or a deduction in `Reversed` status. `destroy()` writes the payment status as the literal `'Paid'` (line 99) and the deduction as `'Deducted'`/`'Partly_Paid'` (line 108), so deleting an allocation from a `Filed` challan silently moves it back to `Paid` and a `Reversed` deduction back to `Deducted`/`Partly_Paid`. |
| **Consequence** | A challan that was filed can lose its `Filed` status, and cancelled/reversed TDS records can be changed by an allocation edit, so the TDS register no longer matches the statutory filings. |
| **Reproduce** | Set the challan status to `Filed` through the TDS Payment screen, then delete its allocation on this tab; the challan status becomes `Paid`. Zero `Filed` payments and zero `Reversed` deductions exist on `test.localhost` today, so the live data does not show it yet. |
| **Fix approach** | Decide whether to block allocation changes on terminal records or to preserve the terminal status when recomputing. This is a behaviour decision, not a mechanical edit. |
| **Plan item** | TDSA-14 in `02-fix-plan.md` §9 (DECISION) |

```php
// TdsPaymentAllocationController.php:95-100 — CURRENT (payment)
            if ($payment) {
                $newAlloc = max(0, (float) $payment->allocated_amount - $amount);
                $payment->update([
                    'allocated_amount' => $newAlloc,
                    'status'           => $newAlloc <= 0 ? 'Paid' : 'Paid',
                ]);
            }
```

```php
// TdsPaymentAllocationController.php:104-110 — CURRENT (deduction)
            if ($deduction) {
                $newPaid = max(0, (float) $deduction->paid_amount - $amount);
                $deduction->update([
                    'paid_amount' => $newPaid,
                    'status'      => $newPaid <= 0 ? 'Deducted' : 'Partly_Paid',
                ]);
            }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Models\TdsPayment.php" -Pattern "statuses\(\)|'Filed'"
107:            return $query->where('status', 'Filed');
146:        return ['Draft', 'Paid', 'Allocated', 'Filed', 'Cancelled'];

> Select-String -Path "Modules\Accounting\app\Models\TdsDeduction.php" -Pattern "statuses\(\)|'Reversed'"
122:            return $query->where('status', 'Reversed');
191:        return ['Deducted', 'Partly_Paid', 'Paid', 'Reversed'];

> mysql -u root -N -e "SELECT 'filed_payments', COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_tds_payments WHERE status='Filed' UNION ALL SELECT 'reversed_deductions', COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_tds_deductions WHERE status='Reversed';"
filed_payments	0
reversed_deductions	0
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `config/permissionslist.php:600-644` | The Accounting permission block declares no `accounting.tds-payment` or `accounting.tds-deduction` key, so **both** `TdsPaymentController` and `TdsDeductionController` also gate on permissions that do not exist and are 0-granted in the tenant database. TDSA-06 fixes this controller; the other two reports need the same decision once, module-wide. | AUTH-01 | Tarun / module owner — shared config, new key |
| `Modules/Accounting/database/seeders/AccountingSeeder.php:2348-2354` | The seeder inserts an `acc_tds_payment_allocations` row directly and never updates `acc_tds_payments.allocated_amount` or `acc_tds_deductions.paid_amount`. The live tenant proves the drift: allocation ₹2,400, payment `allocated_amount = 0.00` (status `Draft`), deduction `paid_amount = 0.00` (status `Deducted`). The controller trusts those aggregates, so the demo data already allows a second allocation against the same balances. | F13-Q1 (data integrity) | seeder owner — not a controller fix |
| `Modules/Accounting/app/Models/TdsDeduction.php:7` | Unused `use App\Models\BaseModel;` import (the model extends `BaseAccountingModel`). Pint reports `no_unused_imports` for that file. | STY-02 | [gaurav/Accounting/TdsDeductionController](../TdsDeductionController/01-report.md) |
| `app/Helpers/activityLog.php` | The helper is shared; this report checked only that it is called after the write and inside the transaction. It creates the log model inside the same transaction, so a failed log insert rolls the allocation back — acceptable, but a module-wide concern. | TXN-01 | common helper owner |

## 8. Not covered, and why

- **Scanner and self-check skipped.** `final-audit-reports/_tools/scanfilter.py` and `final-audit-reports/_tools/selfcheck.py` are missing, and `scan.php` must not be run under the tooling override. F1–F13 were checked manually with `read`, `Select-String`, `php -l`, `route:list`, the route probe, `mysql` and Pint.
- **No tests run** (D4). No browser render or form submission was performed. TDSA-12 was proven from the model (`usesTimestamps()`/`getUpdatedAtColumn()`) and the live `SHOW COLUMNS` output, not by writing a row.
- **No view audited.** The controller renders no Blade; the `tds-allocations` tab is rendered by `AccDashboardController::tdsManagement()` and belongs to that controller's report.
- **Linked classes were not re-audited.** `BaseAccountingModel`, `TdsPayment`, `TdsDeduction` and `AccountingContext` are owned elsewhere; this report checked only how this controller uses them. `AccountingContext` is not exercised because the allocation model has no accounting-context columns.
- **The FormRequest was not executed.** Its unique rule was checked against the live index and its authorize path against the live permission table; no payload was submitted (D4).
- **Route model binding was proven from framework source, not from a live request** — `ImplicitRouteBinding::getParameterName()` snake-cases the method argument.
