# Fix Plan — Accounting / TdsPaymentAllocationController

**From:** `01-report.md` (2026-10-23) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | shared permission list — only TDSA-06, if approved (⚠ SHARED) |
| `Modules/Accounting/routes/web.php` | shared route file; no route change is needed or planned |
| `database/migrations/tenant/*` | migrations are out of bounds for every final-audit fix; TDSA-12 is fixed in the model instead |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | owned by [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) |
| `Modules/Accounting/app/Models/TdsPayment.php` | owned by [gaurav/Accounting/TdsPaymentController](../TdsPaymentController/01-report.md) |
| `Modules/Accounting/app/Models/TdsDeduction.php` | owned by [gaurav/Accounting/TdsDeductionController](../TdsDeductionController/01-report.md) |
| `Modules/Accounting/app/Services/AccountingContext.php` | owned by [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) |
| `app/Helpers/activityLog.php` | shared helper — cross-cutting note §7 |
| `Modules/GlobalMaster/app/Models/ActivityLog.php` | shared model — cross-cutting note §7 |
| `Modules/Accounting/resources/views/pages/partials/tds-management/_tds-allocations.blade.php` | rendered by `AccDashboardController`, not by this controller |
| `Modules/Accounting/database/seeders/AccountingSeeder.php` | seeder data drift is a cross-cutting note §7, not a controller fix |

## 1. Blockers reachable today

- [ ] **TDSA-12** · B · MDL-07 · `TdsPaymentAllocation.php:7-11` — stop Eloquent writing `updated_at` to a table that has only `created_at`.
  - **Touches:** `Modules/Accounting/app/Models/TdsPaymentAllocation.php`
  - **Before** (`TdsPaymentAllocation.php:7-11`):
```php
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class TdsPaymentAllocation extends BaseAccountingModel
{
    protected $table = 'acc_tds_payment_allocations';
```
  - **After:**
```php
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class TdsPaymentAllocation extends BaseAccountingModel
{
    public const UPDATED_AT = null;

    protected $table = 'acc_tds_payment_allocations';
```
  - **Verify:** `php artisan tinker --execute="dump((new Modules\Accounting\Models\TdsPaymentAllocation)->getUpdatedAtColumn());"`
  - **Expect:** `null`
  - **Effort:** S

- [ ] **TDSA-01** · B · ERR-01 · `TdsPaymentAllocationController.php:19-130` — remove both try/catch blocks (D1), use `DB::transaction`, take row locks, and stop showing exception text. This one item fixes TDSA-01, TDSA-02, TDSA-03, TDSA-04, TDSA-05, TDSA-07 and TDSA-11.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php`
  - **Before** (`TdsPaymentAllocationController.php:7-15`):
```php
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Modules\Accounting\Http\Requests\TdsPaymentAllocationRequest;
use Modules\Accounting\Models\TdsPaymentAllocation;
use Modules\Accounting\Models\TdsPayment;
use Modules\Accounting\Models\TdsDeduction;
```
  - **After:**
```php
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Modules\Accounting\Http\Requests\TdsPaymentAllocationRequest;
use Modules\Accounting\Models\TdsPaymentAllocation;
use Modules\Accounting\Models\TdsPayment;
use Modules\Accounting\Models\TdsDeduction;
```
  - **Before** (`TdsPaymentAllocationController.php:19-82`, method `store`):
```php
    public function store(TdsPaymentAllocationRequest $request)
    {
        Gate::authorize('tenant.accounting.tds-payment.create');

        $validated = $request->validated();

        DB::beginTransaction();
        try {
            $payment = TdsPayment::findOrFail($validated['tds_payment_id']);
            $deduction = TdsDeduction::findOrFail($validated['tds_deduction_id']);

            $amount = (float) $validated['amount'];

            // Validation: cannot allocate more than payment remaining or deduction remaining
            $paymentRemaining = (float) $payment->total_amount - (float) $payment->allocated_amount;
            $deductionRemaining = (float) $deduction->tds_amount - (float) $deduction->paid_amount;

            if ($amount > $paymentRemaining + 0.001) {
                return back()->with('error', 'Allocation amount (' . number_format($amount, 2) . ') exceeds unallocated challan balance (' . number_format($paymentRemaining, 2) . ').');
            }

            if ($amount > $deductionRemaining + 0.001) {
                return back()->with('error', 'Allocation amount (' . number_format($amount, 2) . ') exceeds remaining unpaid deduction amount (' . number_format($deductionRemaining, 2) . ').');
            }

            $validated['allocated_by'] = auth()->id();
            $allocation = TdsPaymentAllocation::create($validated);

            // Update payment allocated_amount
            $newPaymentAllocated = (float) $payment->allocated_amount + $amount;
            $paymentStatus = $newPaymentAllocated >= (float) $payment->total_amount ? 'Allocated' : ($payment->status === 'Draft' ? 'Paid' : $payment->status);
            $payment->update([
                'allocated_amount' => $newPaymentAllocated,
                'status'           => $paymentStatus,
            ]);

            // Update deduction paid_amount and status
            $newDeductionPaid = (float) $deduction->paid_amount + $amount;
            $deductionStatus = $newDeductionPaid >= (float) $deduction->tds_amount ? 'Paid' : 'Partly_Paid';
            $deduction->update([
                'paid_amount' => $newDeductionPaid,
                'status'      => $deductionStatus,
            ]);

            activityLog($allocation, 'Created', [
                'message'      => 'TDS Challan allocated: ₹' . number_format($amount, 2) . ' from Challan ' . $payment->challan_no . ' to Deduction #' . $deduction->id,
                'amount'       => $amount,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-allocations'])
                ->with('success', 'TDS allocation recorded successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create TDS Payment Allocation', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to allocate TDS: ' . $e->getMessage());
        }
    }
```
  - **After:**
```php
    public function store(TdsPaymentAllocationRequest $request)
    {
        $validated = $request->validated();
        $amount = (float) $validated['amount'];
        $error = null;

        DB::transaction(function () use ($validated, $amount, &$error) {
            $payment = TdsPayment::lockForUpdate()->findOrFail($validated['tds_payment_id']);
            $deduction = TdsDeduction::lockForUpdate()->findOrFail($validated['tds_deduction_id']);

            $paymentRemaining = (float) $payment->total_amount - (float) $payment->allocated_amount;
            $deductionRemaining = (float) $deduction->tds_amount - (float) $deduction->paid_amount;

            if ($amount > $paymentRemaining + 0.001) {
                $error = 'Allocation amount (' . number_format($amount, 2) . ') exceeds unallocated challan balance (' . number_format($paymentRemaining, 2) . ').';

                return;
            }

            if ($amount > $deductionRemaining + 0.001) {
                $error = 'Allocation amount (' . number_format($amount, 2) . ') exceeds remaining unpaid deduction amount (' . number_format($deductionRemaining, 2) . ').';

                return;
            }

            $validated['allocated_by'] = auth()->id();
            $allocation = TdsPaymentAllocation::create($validated);

            $newPaymentAllocated = (float) $payment->allocated_amount + $amount;
            $paymentStatus = $newPaymentAllocated >= (float) $payment->total_amount ? 'Allocated' : ($payment->status === 'Draft' ? 'Paid' : $payment->status);
            $payment->update([
                'allocated_amount' => $newPaymentAllocated,
                'status'           => $paymentStatus,
            ]);

            $newDeductionPaid = (float) $deduction->paid_amount + $amount;
            $deductionStatus = $newDeductionPaid >= (float) $deduction->tds_amount ? 'Paid' : 'Partly_Paid';
            $deduction->update([
                'paid_amount' => $newDeductionPaid,
                'status'      => $deductionStatus,
            ]);

            activityLog($allocation, 'Created', [
                'message'      => 'TDS Challan allocated: ₹' . number_format($amount, 2) . ' from Challan ' . $payment->challan_no . ' to Deduction #' . $deduction->id,
                'amount'       => $amount,
                'performed_by' => auth()->id(),
            ]);
        });

        if ($error !== null) {
            return back()->with('error', $error);
        }

        return redirect()->route('accounting.menu.tds', ['tab' => 'tds-allocations'])
            ->with('success', 'TDS allocation recorded successfully.');
    }
```
  - **Before** (`TdsPaymentAllocationController.php:84-130`, method `destroy`):
```php
    public function destroy(TdsPaymentAllocation $tdsPaymentAllocation)
    {
        Gate::authorize('tenant.accounting.tds-payment.delete');

        DB::beginTransaction();
        try {
            $payment = $tdsPaymentAllocation->tdsPayment;
            $deduction = $tdsPaymentAllocation->tdsDeduction;
            $amount = (float) $tdsPaymentAllocation->amount;

            // Revert payment allocated amount
            if ($payment) {
                $newAlloc = max(0, (float) $payment->allocated_amount - $amount);
                $payment->update([
                    'allocated_amount' => $newAlloc,
                    'status'           => $newAlloc <= 0 ? 'Paid' : 'Paid',
                ]);
            }

            // Revert deduction paid amount
            if ($deduction) {
                $newPaid = max(0, (float) $deduction->paid_amount - $amount);
                $deduction->update([
                    'paid_amount' => $newPaid,
                    'status'      => $newPaid <= 0 ? 'Deducted' : 'Partly_Paid',
                ]);
            }

            $tdsPaymentAllocation->delete();

            activityLog($tdsPaymentAllocation, 'Deleted', [
                'message'      => 'TDS Allocation removed: ₹' . number_format($amount, 2),
                'amount'       => $amount,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-allocations'])
                ->with('success', 'TDS Allocation removed successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to delete TDS Allocation', ['id' => $tdsPaymentAllocation->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete TDS Allocation: ' . $e->getMessage());
        }
    }
```
  - **After:**
```php
    public function destroy(TdsPaymentAllocation $tdsPaymentAllocation)
    {
        Gate::authorize('tenant.accounting.tds-payment.delete');

        DB::transaction(function () use ($tdsPaymentAllocation) {
            $payment = TdsPayment::lockForUpdate()->find($tdsPaymentAllocation->tds_payment_id);
            $deduction = TdsDeduction::lockForUpdate()->find($tdsPaymentAllocation->tds_deduction_id);
            $amount = (float) $tdsPaymentAllocation->amount;

            if ($payment) {
                $newAlloc = max(0, (float) $payment->allocated_amount - $amount);
                $payment->update([
                    'allocated_amount' => $newAlloc,
                    'status'           => 'Paid',
                ]);
            }

            if ($deduction) {
                $newPaid = max(0, (float) $deduction->paid_amount - $amount);
                $deduction->update([
                    'paid_amount' => $newPaid,
                    'status'      => $newPaid <= 0 ? 'Deducted' : 'Partly_Paid',
                ]);
            }

            $tdsPaymentAllocation->delete();

            activityLog($tdsPaymentAllocation, 'Deleted', [
                'message'      => 'TDS Allocation removed: ₹' . number_format($amount, 2),
                'amount'       => $amount,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.tds', ['tab' => 'tds-allocations'])
            ->with('success', 'TDS Allocation removed successfully.');
    }
```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "catch \(|getMessage|DB::beginTransaction|DB::commit|DB::rollBack"`
  - **Expect:** no output.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **TDSA-08** · H · VAL-04 · `TdsPaymentAllocationRequest.php:26-33` — make the unique rule mirror `uq_acc_tdsalloc` by dropping the soft-delete filter.
  - **Touches:** `Modules/Accounting/app/Http/Requests/TdsPaymentAllocationRequest.php`
  - **Before** (`TdsPaymentAllocationRequest.php:26-33`):
```php
            'tds_deduction_id' => [
                'required',
                'exists:acc_tds_deductions,id',
                Rule::unique('acc_tds_payment_allocations', 'tds_deduction_id')
                    ->where(fn($q) => $q->where('tds_payment_id', $this->input('tds_payment_id')))
                    ->ignore($id)
                    ->withoutTrashed(),
            ],
```
  - **After:**
```php
            'tds_deduction_id' => [
                'required',
                'exists:acc_tds_deductions,id',
                Rule::unique('acc_tds_payment_allocations', 'tds_deduction_id')
                    ->where(fn($q) => $q->where('tds_payment_id', $this->input('tds_payment_id')))
                    ->ignore($id),
            ],
```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\TdsPaymentAllocationRequest.php" -Pattern "withoutTrashed"`
  - **Expect:** no output.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

No items — TDSA-01 (blocker §1) rewrites both transaction/catch blocks.

## 4. Authorization (F3)

No items — TDSA-06 is a DECISION in §9; TDSA-07 is fixed by TDSA-01.

## 5. Validation, routes, models (F4/F5/F7)

No items — TDSA-08 is in §2, TDSA-12 is in §1; no route change is needed.

## 6. Queries & performance (F9)

No items — the controller has no loop, list query or raw SQL.

## 7. Views (F10)

No items — the controller renders no view.

## 8. Style (F12) — one item per file

- [ ] **TDSA-10** · L · CTL-04 · `TdsPaymentAllocationController.php:19, 84` — add the missing return types.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php`
  - **Before** (`TdsPaymentAllocationController.php:19`):
```php
    public function store(TdsPaymentAllocationRequest $request)
```
  - **After:**
```php
    public function store(TdsPaymentAllocationRequest $request): \Illuminate\Http\RedirectResponse
```
  - **Before** (`TdsPaymentAllocationController.php:84`):
```php
    public function destroy(TdsPaymentAllocation $tdsPaymentAllocation)
```
  - **After:**
```php
    public function destroy(TdsPaymentAllocation $tdsPaymentAllocation): \Illuminate\Http\RedirectResponse
```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentAllocationController.php" -Pattern "public function (store|destroy)\("`
  - **Expect:** two matches, each ending with `: \Illuminate\Http\RedirectResponse`.
  - **Effort:** S

- [ ] **TDSA-13** · L · STY-02 · `TdsPaymentAllocationController.php`, `TdsPaymentAllocationRequest.php`, `TdsPaymentAllocation.php` — make the three files Pint-clean.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php`, `Modules/Accounting/app/Http/Requests/TdsPaymentAllocationRequest.php`, `Modules/Accounting/app/Models/TdsPaymentAllocation.php`
  - **Before** (`TdsPaymentAllocation.php:7-8`):
```php
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
```
  - **After:** run `vendor\bin\pint Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php Modules/Accounting/app/Http/Requests/TdsPaymentAllocationRequest.php Modules/Accounting/app/Models/TdsPaymentAllocation.php --format agent`. Pint rewrites the files in place (it removes the two unused imports, sorts imports, adds the missing blank line after the imports and normalises `fn ($q)` and operator spacing). Do not hand-edit; the command is the change.
  - **Verify:** `vendor\bin\pint --test Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php Modules/Accounting/app/Http/Requests/TdsPaymentAllocationRequest.php Modules/Accounting/app/Models/TdsPaymentAllocation.php --format agent`
  - **Expect:** `"result":"pass"` and no `"result":"fail"`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **TDSA-06** · H · DECISION · AUTH-01 — the `tenant.accounting.tds-payment.*` permissions do not exist, so only Super Admin can use the screen. ⚠ SHARED
  - **Why it is a decision:** it needs a new key in the shared `config/permissionslist.php`, then `/system-config/sync-permissions` and role grants — both are Tarun's hand (final-audit.md §8.2).
  - (a) ⭐ add `'accounting.tds-payment' => $crud` to the Accounting block of `config/permissionslist.php` (next to `'accounting.tax-rate' => $crud`), sync, then grant create/delete to Account Manager and Account Staff
  - (b) add both `'accounting.tds-payment' => $crud` and `'accounting.tds-deduction' => $crud` in one change, because `TdsPaymentController` and `TdsDeductionController` use the same missing prefixes
  - (c) leave the screen Super-Admin-only and record it as accepted
  - ➜ Choice: ____

- [ ] **TDSA-14** · H · DECISION · F13-Q1 — allocations can change records in a terminal status (`Filed`, `Cancelled`, `Reversed`).
  - **Why it is a decision:** it is a behaviour change — block the edit or preserve the terminal status; both change what an accountant can do.
  - (a) ⭐ block both actions when the challan is `Filed`/`Cancelled` or the deduction is `Reversed`, with a business message
  - (b) allow the action but preserve a terminal payment status in `destroy()` instead of forcing `Paid` (a `Filed` challan stays `Filed`)
  - (c) accept; editing an allocation can reset a filed/reversed record
  - **If TDSA-01 is also ticked:** choice (a) adds a status guard before both mutations; choice (b) replaces the literal `'Paid'` in the new `destroy()` with a guard that keeps `Filed`/`Cancelled`.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TDSA-02 | Fixed by TDSA-01: the two `findOrFail()` calls move inside the transaction and the catch is removed, so a missing row is a 404. |
| TDSA-03 | Fixed by TDSA-01: no catch remains; the central handler in `bootstrap/app.php` reports the exception object. |
| TDSA-04 | Fixed by TDSA-01: `DB::transaction` closures replace `beginTransaction`/`commit`/`rollBack`, and the early returns become a returned error value checked after the closure. |
| TDSA-05 | Fixed by TDSA-01: both methods now load the payment and deduction with `lockForUpdate()` and recompute inside the transaction. |
| TDSA-07 | Fixed by TDSA-01: the duplicate `Gate::authorize()` in `store()` is removed (the FormRequest authorizes). `destroy()` keeps its own check because it has no FormRequest. |
| TDSA-09 | Accepted maintainability debt. The two balance checks still read two loaded models; moving them to the FormRequest's `after()` needs the same two queries and a UX decision on where the message appears. TDSA-01 moves them inside the transaction. |
| TDSA-11 | Fixed by TDSA-01: the `? 'Paid' : 'Paid'` ternary becomes the literal `'Paid'`. The real terminal-status rule is TDSA-14's decision. |
