# Fix Plan — Accounting / FixedAssetController

**From:** `01-report.md` (2026-10-23) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/FixedAssetController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/resources/views/pages/partials/assets-integration/_fixed-assets.blade.php` | rendered by `AccDashboardController`, not this controller |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | shared base model, owned by AccountingStatusMasterController |
| `Modules/Accounting/app/Services/AccountingContext.php` | shared service, owned by AccountGroupController |
| `Modules/Accounting/app/Services/VoucherService.php` | shared service; forcing `Draft` is its contract, not a defect |
| `Modules/Accounting/app/Models/Voucher.php` | shared model, owned by VoucherController |
| `Modules/Accounting/app/Models/AssetCategory.php` | shared model, owned by AssetCategoryController |
| `Modules/Accounting/app/Models/AssetDisposal.php` | shared model, owned by AssetDisposalController |
| `Modules/Accounting/app/Models/DepreciationEntry.php` | shared model, owned by DepreciationEntryController |
| `database/migrations/tenant/*` | never edit an existing migration |
| `config/permissionslist.php` | no new permission key is needed by this plan |
| `glb_menus` | no menu change is needed by this plan |

## 1. Blockers reachable today

- [ ] **1.1** · B · SVC-04 · `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:153-224` — make Post Voucher create a real voucher, post it, and serialize the duplicate check (fixes FXAS-04, FXAS-07, FXAS-11, FXAS-12).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php`, `Modules/Accounting/app/Http/Requests/FixedAssetVoucherRequest.php` (new)
  - **Before** (`FixedAssetController.php:7-21`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Accounting\Http\Requests\FixedAssetRequest;
    use Modules\Accounting\Models\AssetCategory;
    use Modules\Accounting\Models\FinancialYear;
    use Modules\Accounting\Models\FixedAsset;
    use Modules\Accounting\Models\Voucher;
    use Modules\Accounting\Services\DepreciationService;
    use Modules\Vendor\Models\Vendor;

    class FixedAssetController extends Controller
    {
        public function __construct(private readonly DepreciationService $service) {}
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Validation\ValidationException;
    use Modules\Accounting\Http\Requests\FixedAssetRequest;
    use Modules\Accounting\Http\Requests\FixedAssetVoucherRequest;
    use Modules\Accounting\Models\AssetCategory;
    use Modules\Accounting\Models\FinancialYear;
    use Modules\Accounting\Models\FixedAsset;
    use Modules\Accounting\Models\Voucher;
    use Modules\Accounting\Services\DepreciationService;
    use Modules\Accounting\Services\VoucherService;
    use Modules\Vendor\Models\Vendor;

    class FixedAssetController extends Controller
    {
        public function __construct(
            private readonly DepreciationService $service,
            private readonly VoucherService $voucherService,
        ) {}
    ```
  - **Before** (`FixedAssetController.php:153-224`):
    ```php
    public function postVoucher(Request $request, FixedAsset $fixedAsset)
    {
        Gate::authorize('tenant.accounting.fixed-asset.update');

        if ($fixedAsset->voucher_id) {
            return back()->with('error', 'A voucher is already posted for this Fixed Asset.');
        }

        $request->validate([
            'voucher_type_id'  => 'required|exists:acc_voucher_types,id',
            'debit_ledger_id'  => 'required|exists:acc_ledgers,id',
            'credit_ledger_id' => 'required|exists:acc_ledgers,id',
            'date'             => 'required|date',
            'amount'           => 'required|numeric|min:0.01',
            'narration'        => 'nullable|string|max:500',
        ]);

        try {
            $fy = FinancialYear::where('is_active', true)->first();
            if (!$fy) {
                return back()->with('error', 'No active Financial Year found.');
            }

            if ($fy->isLocked()) {
                return back()->with('error', 'Cannot post voucher in a locked Financial Year.');
            }

            $voucher = DB::transaction(function () use ($request, $fixedAsset, $fy) {
                /** @var \Modules\Accounting\Services\VoucherService $voucherService */
                $voucherService = app(\Modules\Accounting\Services\VoucherService::class);

                $voucher = $voucherService->create([
                    'voucher_type_id'   => (int) $request->input('voucher_type_id'),
                    'financial_year_id' => $fy->id,
                    'date'              => $request->input('date', $fixedAsset->purchase_date?->format('Y-m-d') ?? now()->format('Y-m-d')),
                    'narration'         => $request->input('narration') ?: "Purchase of Fixed Asset: {$fixedAsset->name} [{$fixedAsset->asset_code}]",
                    'status'            => 'posted',
                    'is_active'         => true,
                ], [
                    [
                        'ledger_id' => (int) $request->input('debit_ledger_id'),
                        'entry_type'      => 'Dr',
                        'amount'    => (float) $request->input('amount', $fixedAsset->purchase_cost),
                        'narration' => "Fixed Asset: {$fixedAsset->asset_code}",
                    ],
                    [
                        'ledger_id' => (int) $request->input('credit_ledger_id'),
                        'entry_type'      => 'Cr',
                        'amount'    => (float) $request->input('amount', $fixedAsset->purchase_cost),
                        'narration' => "Fixed Asset: {$fixedAsset->asset_code}",
                    ],
                ]);

                $fixedAsset->update(['voucher_id' => $voucher->id]);

                return $voucher;
            });

            activityLog($fixedAsset, 'VoucherPosted', [
                'message'        => 'Purchase voucher posted for Fixed Asset.',
                'name'           => $fixedAsset->name,
                'asset_code'     => $fixedAsset->asset_code,
                'voucher_id'     => $voucher->id,
                'voucher_number' => $voucher->formatted_number,
            ]);

            return back()->with('success', "Voucher {$voucher->formatted_number} posted successfully for Fixed Asset {$fixedAsset->name}.");
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('FixedAsset postVoucher failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return back()->with('error', 'Failed to post voucher: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function postVoucher(FixedAssetVoucherRequest $request, FixedAsset $fixedAsset)
    {
        $validated = $request->validated();

        $voucher = DB::transaction(function () use ($validated, $fixedAsset) {
            $lockedAsset = FixedAsset::whereKey($fixedAsset->id)->lockForUpdate()->firstOrFail();

            if ($lockedAsset->voucher_id) {
                throw ValidationException::withMessages([
                    'voucher_type_id' => 'A voucher is already posted for this Fixed Asset.',
                ]);
            }

            $fy = FinancialYear::where('is_active', true)->first();
            if (! $fy) {
                throw ValidationException::withMessages([
                    'voucher_type_id' => 'No active Financial Year found.',
                ]);
            }

            if ($fy->isLocked()) {
                throw ValidationException::withMessages([
                    'voucher_type_id' => 'Cannot post voucher in a locked Financial Year.',
                ]);
            }

            $voucher = $this->voucherService->create([
                'voucher_type_id'   => (int) $validated['voucher_type_id'],
                'financial_year_id' => $fy->id,
                'voucher_date'      => $validated['date'],
                'narration'         => ($validated['narration'] ?? null) ?: "Purchase of Fixed Asset: {$lockedAsset->name} [{$lockedAsset->asset_code}]",
            ], [
                [
                    'ledger_id'  => (int) $validated['debit_ledger_id'],
                    'entry_type' => 'Dr',
                    'amount'     => (float) $validated['amount'],
                    'narration'  => "Fixed Asset: {$lockedAsset->asset_code}",
                ],
                [
                    'ledger_id'  => (int) $validated['credit_ledger_id'],
                    'entry_type' => 'Cr',
                    'amount'     => (float) $validated['amount'],
                    'narration'  => "Fixed Asset: {$lockedAsset->asset_code}",
                ],
            ]);

            try {
                $this->voucherService->post($voucher->fresh());
            } catch (\DomainException $e) {
                // ERR-01 (2026-10-23): DomainException carries a user-safe business message.
                throw ValidationException::withMessages([
                    'voucher_type_id' => $e->getMessage(),
                ]);
            }

            $voucher = $voucher->fresh();

            $lockedAsset->update(['voucher_id' => $voucher->id]);

            activityLog($lockedAsset, 'VoucherPosted', [
                'message'        => 'Purchase voucher posted for Fixed Asset.',
                'name'           => $lockedAsset->name,
                'asset_code'     => $lockedAsset->asset_code,
                'voucher_id'     => $voucher->id,
                'voucher_number' => $voucher->formatted_number,
            ]);

            return $voucher;
        });

        return back()->with('success', "Voucher {$voucher->formatted_number} posted successfully for Fixed Asset {$fixedAsset->name}.");
    }
    ```
  - **New file** `Modules/Accounting/app/Http/Requests/FixedAssetVoucherRequest.php`:
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Accounting\Http\Requests;

    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;

    class FixedAssetVoucherRequest extends FormRequest
    {
        use AuthorizesTenantFeature;

        public function authorize(): bool
        {
            return $this->authorizeByCrudPermission('tenant.accounting.fixed-asset', 'update');
        }

        public function rules(): array
        {
            return [
                'voucher_type_id' => 'required|exists:acc_voucher_types,id',
                'debit_ledger_id' => 'required|exists:acc_ledgers,id',
                'credit_ledger_id' => 'required|exists:acc_ledgers,id',
                'date' => 'required|date',
                'amount' => 'required|numeric|min:0.01',
                'narration' => 'nullable|string|max:500',
            ];
        }

        public function attributes(): array
        {
            return [
                'voucher_type_id' => 'Voucher Type',
                'debit_ledger_id' => 'Debit Ledger',
                'credit_ledger_id' => 'Credit Ledger',
                'date' => 'Voucher Date',
                'amount' => 'Amount',
                'narration' => 'Narration',
            ];
        }
    }
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/FixedAssetController.php -Pattern "voucher_date|->post\(|lockForUpdate"`; `php -l Modules/Accounting/app/Http/Requests/FixedAssetVoucherRequest.php`
  - **Expect:** three matches (`voucher_date`, `->post(`, `lockForUpdate`) in the controller and `No syntax errors detected` for the new request.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None. FXAS-04 becomes reachable only after 1.1, and 1.1 already adds the `lockForUpdate()` re-check, so it is fixed by the same item.

## 3. Errors & transactions (F1/F2)

- [ ] **3.1** · H · TXN-04 · `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:54-74` — put the audit row inside the transaction and stop catching `Throwable` (fixes FXAS-01, FXAS-03).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php`
  - **Before** (`FixedAssetController.php:54-74`):
    ```php
    public function store(FixedAssetRequest $request)
    {
        Gate::authorize('tenant.accounting.fixed-asset.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();
        $validated['updated_by'] = auth()->id();

        try {
            $fixedAsset = DB::transaction(function () use ($validated) {
                return FixedAsset::create($validated);
            });

            activityLog($fixedAsset, 'Created', ['message' => 'Fixed Asset created.', 'name' => $fixedAsset->name, 'asset_code' => $fixedAsset->asset_code]);

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'fixed-assets'])->with('success', 'Fixed Asset created successfully.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('FixedAsset create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return back()->with('error', 'Failed to create Fixed Asset: ' . $e->getMessage())->withInput();
        }
    }
    ```
  - **After:**
    ```php
    public function store(FixedAssetRequest $request)
    {
        Gate::authorize('tenant.accounting.fixed-asset.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();
        $validated['updated_by'] = auth()->id();

        $fixedAsset = DB::transaction(function () use ($validated) {
            $fixedAsset = FixedAsset::create($validated);

            activityLog($fixedAsset, 'Created', ['message' => 'Fixed Asset created.', 'name' => $fixedAsset->name, 'asset_code' => $fixedAsset->asset_code]);

            return $fixedAsset;
        });

        return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'fixed-assets'])->with('success', 'Fixed Asset created successfully.');
    }
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/FixedAssetController.php -Pattern "FixedAsset create failed|Failed to create Fixed Asset"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **3.2** · H · TXN-04 · `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:132-151` — put the audit row inside the transaction and stop catching `Throwable` (fixes FXAS-01, FXAS-03).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php`
  - **Before** (`FixedAssetController.php:132-151`):
    ```php
    public function update(FixedAssetRequest $request, FixedAsset $fixedAsset)
    {
        Gate::authorize('tenant.accounting.fixed-asset.update');

        $validated = $request->validated();
        $validated['updated_by'] = auth()->id();

        try {
            DB::transaction(function () use ($fixedAsset, $validated) {
                $fixedAsset->update($validated);
            });

            activityLog($fixedAsset, 'Updated', ['message' => 'Fixed Asset updated.', 'name' => $fixedAsset->name, 'asset_code' => $fixedAsset->asset_code]);

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'fixed-assets'])->with('success', 'Fixed Asset updated successfully.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('FixedAsset update failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return back()->with('error', 'Failed to update Fixed Asset: ' . $e->getMessage())->withInput();
        }
    }
    ```
  - **After:**
    ```php
    public function update(FixedAssetRequest $request, FixedAsset $fixedAsset)
    {
        Gate::authorize('tenant.accounting.fixed-asset.update');

        $validated = $request->validated();
        $validated['updated_by'] = auth()->id();

        DB::transaction(function () use ($fixedAsset, $validated) {
            $fixedAsset->update($validated);

            activityLog($fixedAsset, 'Updated', ['message' => 'Fixed Asset updated.', 'name' => $fixedAsset->name, 'asset_code' => $fixedAsset->asset_code]);
        });

        return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'fixed-assets'])->with('success', 'Fixed Asset updated successfully.');
    }
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/FixedAssetController.php -Pattern "FixedAsset update failed|Failed to update Fixed Asset"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **3.3** · H · TXN-04 · `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:226-244` — put the audit row inside the transaction and stop catching `Throwable` (fixes FXAS-01, FXAS-03).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php`
  - **Before** (`FixedAssetController.php:226-244`):
    ```php
    public function destroy(FixedAsset $fixedAsset)
    {
        Gate::authorize('tenant.accounting.fixed-asset.delete');

        try {
            DB::transaction(function () use ($fixedAsset) {
                $fixedAsset->is_active = false;
                $fixedAsset->save();
                $fixedAsset->delete();
            });

            activityLog($fixedAsset, 'Trashed', ['message' => 'Fixed Asset trashed.', 'name' => $fixedAsset->name, 'asset_code' => $fixedAsset->asset_code]);

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'fixed-assets'])->with('success', 'Fixed Asset moved to trash.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('FixedAsset destroy failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to delete Fixed Asset: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function destroy(FixedAsset $fixedAsset)
    {
        Gate::authorize('tenant.accounting.fixed-asset.delete');

        DB::transaction(function () use ($fixedAsset) {
            $fixedAsset->is_active = false;
            $fixedAsset->save();
            $fixedAsset->delete();

            activityLog($fixedAsset, 'Trashed', ['message' => 'Fixed Asset trashed.', 'name' => $fixedAsset->name, 'asset_code' => $fixedAsset->asset_code]);
        });

        return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'fixed-assets'])->with('success', 'Fixed Asset moved to trash.');
    }
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/FixedAssetController.php -Pattern "FixedAsset destroy failed|Failed to delete Fixed Asset"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **3.4** · H · TXN-04 · `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:246-265` — put the audit row inside the transaction and stop catching `Throwable` (fixes FXAS-01, FXAS-03).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php`
  - **Before** (`FixedAssetController.php:246-265`):
    ```php
    public function toggleStatus(Request $request, FixedAsset $fixedAsset)
    {
        Gate::authorize('tenant.accounting.fixed-asset.update');

        $request->validate(['is_active' => 'required|boolean']);

        try {
            DB::transaction(function () use ($fixedAsset, $request) {
                $fixedAsset->is_active = $request->boolean('is_active');
                $fixedAsset->save();
            });

            activityLog($fixedAsset, 'Toggled', ['message' => 'Fixed Asset status toggled.', 'name' => $fixedAsset->name, 'active' => $fixedAsset->is_active]);

            return response()->json(['success' => true, 'is_active' => $fixedAsset->is_active, 'message' => 'Status updated.']);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('FixedAsset toggleStatus failed: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Failed to update status.'], 500);
        }
    }
    ```
  - **After:**
    ```php
    public function toggleStatus(Request $request, FixedAsset $fixedAsset)
    {
        Gate::authorize('tenant.accounting.fixed-asset.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::transaction(function () use ($fixedAsset, $request) {
            $fixedAsset->is_active = $request->boolean('is_active');
            $fixedAsset->save();

            activityLog($fixedAsset, 'Toggled', ['message' => 'Fixed Asset status toggled.', 'name' => $fixedAsset->name, 'active' => $fixedAsset->is_active]);
        });

        return response()->json(['success' => true, 'is_active' => $fixedAsset->is_active, 'message' => 'Status updated.']);
    }
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/FixedAssetController.php -Pattern "FixedAsset toggleStatus failed"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **3.5** · H · TXN-04 · `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:267-294` — put the audit row inside the transaction, keep only the `DomainException` catch (fixes FXAS-01, FXAS-03).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php`
  - **Before** (`FixedAssetController.php:267-294`):
    ```php
    public function runDepreciation(FixedAsset $fixedAsset)
    {
        Gate::authorize('tenant.accounting.fixed-asset.depreciate');

        $fy = FinancialYear::where('is_active', true)->first();
        if (! $fy) {
            return back()->with('error', 'No active Financial Year found.');
        }

        try {
            $entry = DB::transaction(function () use ($fixedAsset, $fy) {
                return $this->service->runForAsset($fixedAsset, $fy);
            });

            activityLog($fixedAsset, 'Depreciated', [
                'message'        => 'Depreciation run for Fixed Asset.',
                'name'           => $fixedAsset->name,
                'asset_code'     => $fixedAsset->asset_code,
                'amount'         => $entry->depreciation_amount,
                'voucher_number' => $entry->voucher?->formatted_number,
            ]);

            return back()->with('success', "Depreciation ₹{$entry->depreciation_amount} posted (Voucher {$entry->voucher?->formatted_number}).");
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('FixedAsset runDepreciation failed: ' . $e->getMessage());
            return back()->with('error', $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function runDepreciation(FixedAsset $fixedAsset)
    {
        Gate::authorize('tenant.accounting.fixed-asset.depreciate');

        $fy = FinancialYear::where('is_active', true)->first();
        if (! $fy) {
            return back()->with('error', 'No active Financial Year found.');
        }

        try {
            $entry = DB::transaction(function () use ($fixedAsset, $fy) {
                $entry = $this->service->runForAsset($fixedAsset, $fy);

                activityLog($fixedAsset, 'Depreciated', [
                    'message'        => 'Depreciation run for Fixed Asset.',
                    'name'           => $fixedAsset->name,
                    'asset_code'     => $fixedAsset->asset_code,
                    'amount'         => $entry->depreciation_amount,
                    'voucher_number' => $entry->voucher?->formatted_number,
                ]);

                return $entry;
            });
        } catch (\DomainException $e) {
            // ERR-01 (2026-10-23): DomainException carries a user-safe business message.
            return back()->with('error', $e->getMessage());
        }

        return back()->with('success', "Depreciation ₹{$entry->depreciation_amount} posted (Voucher {$entry->voucher?->formatted_number}).");
    }
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/FixedAssetController.php -Pattern "catch \(\\Throwable"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **3.6** · H · ERR-02 · `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:305-324` — resolve the model outside any catch and put the audit row inside the transaction (fixes FXAS-01, FXAS-02, FXAS-03).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php`
  - **Before** (`FixedAssetController.php:305-324`):
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.fixed-asset.restore');

        try {
            $model = DB::transaction(function () use ($id) {
                $model = FixedAsset::onlyTrashed()->findOrFail($id);
                $model->restore();
                $model->update(['is_active' => true]);
                return $model;
            });

            activityLog($model, 'Restored', ['message' => 'Fixed Asset restored.', 'name' => $model->name]);

            return redirect()->route('accounting.fixed-asset.trashed')->with('success', 'Fixed Asset restored successfully.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('FixedAsset restore failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to restore Fixed Asset: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.fixed-asset.restore');

        $model = FixedAsset::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($model) {
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', ['message' => 'Fixed Asset restored.', 'name' => $model->name]);
        });

        return redirect()->route('accounting.fixed-asset.trashed')->with('success', 'Fixed Asset restored successfully.');
    }
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/FixedAssetController.php -Pattern "FixedAsset restore failed"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **3.7** · B · F13 #2 · `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:326-342` — refuse force-delete when depreciation, a disposal or a voucher exists, and put the audit row inside the transaction (fixes FXAS-01, FXAS-02, FXAS-03, FXAS-17).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php`
  - **Before** (`FixedAssetController.php:326-342`):
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.fixed-asset.forceDelete');

        try {
            DB::transaction(function () use ($id) {
                $model = FixedAsset::withTrashed()->findOrFail($id);
                $model->forceDelete();
                activityLog($model, 'Deleted', ['message' => 'Fixed Asset permanently deleted.', 'name' => $model->name]);
            });

            return redirect()->route('accounting.fixed-asset.trashed')->with('success', 'Fixed Asset permanently deleted.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('FixedAsset forceDelete failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to permanently delete Fixed Asset: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.fixed-asset.forceDelete');

        $model = FixedAsset::withTrashed()->findOrFail($id);

        if ($model->depreciationEntries()->withTrashed()->exists() || $model->disposal()->exists() || $model->voucher_id) {
            return back()->with('error', 'This Fixed Asset has posted accounting entries and cannot be permanently deleted. Move it to trash instead.');
        }

        DB::transaction(function () use ($model) {
            $model->forceDelete();

            activityLog($model, 'Deleted', ['message' => 'Fixed Asset permanently deleted.', 'name' => $model->name]);
        });

        return redirect()->route('accounting.fixed-asset.trashed')->with('success', 'Fixed Asset permanently deleted.');
    }
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/FixedAssetController.php -Pattern "depreciationEntries\(\)->withTrashed|FixedAsset forceDelete failed"`
  - **Expect:** one match for `depreciationEntries()->withTrashed` and no match for `FixedAsset forceDelete failed`.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **4.1** · L · AUTH-04 · `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:56,134` — remove the duplicate Gate checks; the FormRequest already authorizes the same abilities.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php`
  - **Before** (`FixedAssetController.php:54-58` and `132-136`):
    ```php
    public function store(FixedAssetRequest $request)
    {
        Gate::authorize('tenant.accounting.fixed-asset.create');

        $validated = $request->validated();
    ```
    ```php
    public function update(FixedAssetRequest $request, FixedAsset $fixedAsset)
    {
        Gate::authorize('tenant.accounting.fixed-asset.update');

        $validated = $request->validated();
    ```
  - **After:**
    ```php
    public function store(FixedAssetRequest $request)
    {
        $validated = $request->validated();
    ```
    ```php
    public function update(FixedAssetRequest $request, FixedAsset $fixedAsset)
    {
        $validated = $request->validated();
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/FixedAssetController.php -Pattern "Gate::authorize\('tenant.accounting.fixed-asset.(create|update)'\)"`
  - **Expect:** no output; the ability is now checked only by `FixedAssetRequest::authorize()`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **5.1** · H · RTE-01 · `Modules/Accounting/routes/web.php:269` — change restore from GET to DELETE so a prefetch cannot restore an asset. ⚠ SHARED
  - **Touches:** `Modules/Accounting/routes/web.php`
  - **Before** (`web.php:268-270`):
    ```php
    Route::get('/fixed-asset/trash/view', [FixedAssetController::class, 'trashed'])->name('fixed-asset.trashed');
    Route::get('/fixed-asset/{id}/restore', [FixedAssetController::class, 'restore'])->name('fixed-asset.restore');
    Route::delete('/fixed-asset/{id}/force-delete', [FixedAssetController::class, 'forceDelete'])->name('fixed-asset.forceDelete');
    ```
  - **After:**
    ```php
    Route::get('/fixed-asset/trash/view', [FixedAssetController::class, 'trashed'])->name('fixed-asset.trashed');
    Route::delete('/fixed-asset/{id}/restore', [FixedAssetController::class, 'restore'])->name('fixed-asset.restore');
    Route::delete('/fixed-asset/{id}/force-delete', [FixedAssetController::class, 'forceDelete'])->name('fixed-asset.forceDelete');
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/routes/web.php -Pattern "fixed-asset/\{id\}/restore"`
  - **Expect:** one line starting with `Route::delete(`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **6.1** · M · QRY-01 · `Modules/Accounting/app/Models/FixedAsset.php:65-70` — memoize the accumulated-depreciation accessor and use the loaded relation when present (fixes FXAS-13).
  - **Touches:** `Modules/Accounting/app/Models/FixedAsset.php`
  - **Before** (`FixedAsset.php:51-61`):
    ```php
    protected $casts = [
        'purchase_date'       => 'date',
        'put_to_use_date'     => 'date',
        'warranty_upto'       => 'date',
        'insured_upto'        => 'date',
        'purchase_cost'       => 'decimal:2',
        'salvage_value'       => 'decimal:2',
        'depreciation_rate'   => 'decimal:4',
        'useful_life_years'   => 'integer',
        'is_active'           => 'boolean',
    ];
    ```
  - **After:**
    ```php
    protected $casts = [
        'purchase_date'       => 'date',
        'put_to_use_date'     => 'date',
        'warranty_upto'       => 'date',
        'insured_upto'        => 'date',
        'purchase_cost'       => 'decimal:2',
        'salvage_value'       => 'decimal:2',
        'depreciation_rate'   => 'decimal:4',
        'useful_life_years'   => 'integer',
        'is_active'           => 'boolean',
    ];

    private ?float $accumulatedDepreciationMemo = null;
    ```
  - **Before** (`FixedAsset.php:65-70`):
    ```php
    public function getAccumulatedDepreciationAttribute(): float
    {
        return (float) $this->depreciationEntries()
            ->where('is_posted', true)
            ->sum('depreciation_amount');
    }
    ```
  - **After:**
    ```php
    public function getAccumulatedDepreciationAttribute(): float
    {
        if ($this->accumulatedDepreciationMemo !== null) {
            return $this->accumulatedDepreciationMemo;
        }

        $this->accumulatedDepreciationMemo = $this->relationLoaded('depreciationEntries')
            ? (float) $this->depreciationEntries->where('is_posted', true)->sum('depreciation_amount')
            : (float) $this->depreciationEntries()->where('is_posted', true)->sum('depreciation_amount');

        return $this->accumulatedDepreciationMemo;
    }
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Models/FixedAsset.php -Pattern "accumulatedDepreciationMemo"`
  - **Expect:** three matches (the property and the two reads/writes in the accessor).
  - **Effort:** S

- [ ] **6.2** · L · QRY-02 · `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:300` — use the house page size of 10 (fixes FXAS-15).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php`
  - **Before** (`FixedAssetController.php:300`):
    ```php
    $assets = FixedAsset::onlyTrashed()->with(['assetCategory', 'campus', 'custodian'])->orderBy('name')->paginate(15);
    ```
  - **After:**
    ```php
    $assets = FixedAsset::onlyTrashed()->with(['assetCategory', 'campus', 'custodian'])->orderBy('name')->paginate(10);
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/FixedAssetController.php -Pattern "paginate\("`
  - **Expect:** `paginate(10)`.
  - **Effort:** S

## 7. Views (F10)

None. The four in-scope views are clean and need no change.

## 8. Style (F12) — one item per file

- [ ] **8.1** · L · STY-02 · `Modules/Accounting/app/Http/Controllers/FixedAssetController.php` — remove the three unused imports, then run Pint (fixes FXAS-16).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php`
  - **Before** (`FixedAssetController.php:12-17`):
    ```php
    use Modules\Accounting\Models\AssetCategory;
    use Modules\Accounting\Models\FinancialYear;
    use Modules\Accounting\Models\FixedAsset;
    use Modules\Accounting\Models\Voucher;
    use Modules\Accounting\Services\DepreciationService;
    use Modules\Vendor\Models\Vendor;
    ```
  - **After** (then run `vendor\bin\pint Modules/Accounting/app/Http/Controllers/FixedAssetController.php --format agent`):
    ```php
    use Modules\Accounting\Models\FinancialYear;
    use Modules\Accounting\Models\FixedAsset;
    use Modules\Accounting\Services\DepreciationService;
    ```
  - **Verify:** `vendor\bin\pint --test Modules/Accounting/app/Http/Controllers/FixedAssetController.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass"}`
  - **Effort:** S

- [ ] **8.2** · L · STY-02 · `Modules/Accounting/app/Models/FixedAsset.php` — remove the unused `BaseModel` import, then run Pint.
  - **Touches:** `Modules/Accounting/app/Models/FixedAsset.php`
  - **Before** (`FixedAsset.php:7-11`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\Relations\HasOne;
    ```
  - **After** (then run `vendor\bin\pint Modules/Accounting/app/Models/FixedAsset.php --format agent`):
    ```php
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\Relations\HasOne;
    ```
  - **Verify:** `vendor\bin\pint --test Modules/Accounting/app/Models/FixedAsset.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass"}`
  - **Effort:** S

- [ ] **8.3** · L · STY-02 · `Modules/Accounting/app/Http/Requests/FixedAssetRequest.php` — reorder imports, then run Pint.
  - **Touches:** `Modules/Accounting/app/Http/Requests/FixedAssetRequest.php`
  - **Before** (`FixedAssetRequest.php:7-9`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Validation\Rule;
    ```
  - **After** (then run `vendor\bin\pint Modules/Accounting/app/Http/Requests/FixedAssetRequest.php --format agent`):
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    ```
  - **Verify:** `vendor\bin\pint --test Modules/Accounting/app/Http/Requests/FixedAssetRequest.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass"}`
  - **Effort:** S

- [ ] **8.4** · L · STY-02 · `Modules/Accounting/app/Services/DepreciationService.php` — split the grouped import, then run Pint.
  - **Touches:** `Modules/Accounting/app/Services/DepreciationService.php`
  - **Before** (`DepreciationService.php:10`):
    ```php
    use Modules\Accounting\Models\{AccountingPeriod, DepreciationEntry, FinancialYear, FixedAsset, VoucherType};
    ```
  - **After** (then run `vendor\bin\pint Modules/Accounting/app/Services/DepreciationService.php --format agent`):
    ```php
    use Modules\Accounting\Models\AccountingPeriod;
    use Modules\Accounting\Models\DepreciationEntry;
    use Modules\Accounting\Models\FinancialYear;
    use Modules\Accounting\Models\FixedAsset;
    use Modules\Accounting\Models\VoucherType;
    ```
  - **Verify:** `vendor\bin\pint --test Modules/Accounting/app/Services/DepreciationService.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass"}`
  - **Effort:** S

- [ ] **8.5** · L · STY-02 · `Modules/Accounting/app/Policies/FixedAssetPolicy.php` — reorder imports, then run Pint.
  - **Touches:** `Modules/Accounting/app/Policies/FixedAssetPolicy.php`
  - **Before** (`FixedAssetPolicy.php:7-8`):
    ```php
    use Modules\SchoolSetup\Models\User;
    use Modules\Accounting\Models\FixedAsset;
    ```
  - **After** (then run `vendor\bin\pint Modules/Accounting/app/Policies/FixedAssetPolicy.php --format agent`):
    ```php
    use Modules\Accounting\Models\FixedAsset;
    use Modules\SchoolSetup\Models\User;
    ```
  - **Verify:** `vendor\bin\pint --test Modules/Accounting/app/Policies/FixedAssetPolicy.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass"}`
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **9.1** · M · DECISION · AUTH-06 — should this module keep the permission-string gates, or move to the registered model policy?
  - **Why it is a decision:** touching the policy affects every Accounting controller pattern and needs a module-wide convention; the policy is a shared, unclaimed class.
  - (a) ⭐ Move the controller to policy abilities (`$this->authorize('update', $fixedAsset)`) and add `restore`/`forceDelete` to `FixedAssetPolicy`; requires a module-wide pass over the other Accounting controllers.
  - (b) Delete `FixedAssetPolicy` and its registration, keeping the string gates as the single source of truth.
  - (c) Leave as is and record the dead policy as accepted.
  - ➜ Choice: ____

- [ ] **9.2** · H · DECISION · CTL-03 — what should happen to `fixed-asset.runDepreciation.legacy`?
  - **Why it is a decision:** removing a route changes the public surface and may break an old link or bookmark.
  - (a) ⭐ Remove the legacy `fixed-asset.runDepreciation.legacy` route line; the working route already exists at `{fixed_asset}/run-depreciation`.
  - (b) Add `{fixed_asset}` to the legacy URI and keep the same handler.
  - (c) Keep it and document that it always fails.
  - ➜ Choice: ____

- [ ] **9.3** · M · DECISION · QRY-15 — how should the create/edit pickers be bounded?
  - **Why it is a decision:** a searchable select needs a new endpoint or component contract; a plain limit changes what users can choose.
  - (a) ⭐ Convert custodians, ledgers and vouchers to a searchable select backed by a small JSON endpoint; keep the small campus/cost-center/fund lists eager-loaded.
  - (b) Add a fixed `->limit(500)` to the three large loaders now, and defer search.
  - (c) Leave as is and accept the page weight on large tenants.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| FXAS-10 | Cosmetic CTL-04 return types; add them opportunistically when the methods are next edited. No behaviour change, so it does not justify its own diff. |
