# Final Audit — Accounting / FixedAssetController

**Audited:** 2026-10-23 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/FixedAssetController.php` (343 lines, 13 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost/accounting/assets-integration?tab=fixed-assets` (the list tab), `http://test.localhost/accounting/fixed-asset/create`, `http://test.localhost/accounting/fixed-asset/{id}`, `http://test.localhost/accounting/fixed-asset/{id}/edit`, `http://test.localhost/accounting/fixed-asset/trash/view` |
| Menu path | Accounting → Assets & Integration → Fixed Assets tab |
| Who uses it | Account Manager, Account Staff, Management, School Admin, Super Admin (the five roles that hold all eight `tenant.accounting.fixed-asset.*` permissions) |
| What a user does here | Record a fixed asset (code, category, purchase date, cost, custodian, campus), edit it, post its purchase voucher, run period depreciation, toggle active status, and restore or permanently delete trashed assets. The list itself is rendered by the Assets & Integration dashboard, not by `index()`. |
| Tables written | `acc_fixed_assets`, `acc_vouchers`, `acc_voucher_items`, `acc_depreciation_entries`, `sys_activity_logs` |
| Tables read | `acc_fixed_assets`, `acc_asset_categories`, `vnd_vendors`, `sys_users`, `acc_campuses`, `acc_cost_centers`, `acc_funds`, `acc_vouchers`, `acc_ledgers`, `acc_voucher_types`, `acc_financial_years`, `acc_accounting_periods`, `acc_depreciation_entries` |
| Live data | `acc_fixed_assets` 5 live / 0 trashed · `acc_depreciation_entries` 5 · `acc_asset_categories` 14 · `acc_vouchers` 30 (tenant `test.localhost`, DB `xyz_school_00000000000040008000_202627`) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No — not production-ready. The Post Voucher button can never succeed: it sends a `date` key that `Voucher` does not accept, omits the `voucher_date` column that is `NOT NULL`, and never calls `VoucherService::post()`, so the insert fails and, if the key were fixed, the voucher would still stay a Draft while the UI says "posted" (FXAS-12). The single worst finding is that one. The plan is M-sized, roughly one working day including re-test of the four write paths.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 3 | 5 | 5 | 4 | 3 | 17 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | FXAS-01, FXAS-02 | F8 Services/Jobs | FXAS-11, FXAS-12 |
| F2 Transactions/Audit | FXAS-03, FXAS-04 | F9 Queries/Perf | FXAS-13, FXAS-14, FXAS-15 |
| F3 Authorization | FXAS-05, FXAS-06 | F10 Views | clean |
| F4 Validation | FXAS-07 | F11 Security/Tenancy | clean |
| F5 Routes | FXAS-08, FXAS-09 | F12 Style | FXAS-16 |
| F6 Controller shape | FXAS-10 | F13 Deep read | FXAS-17 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/FixedAssetController.php` | controller | 343 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/FixedAsset.php` | model | 299 | this report | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/FixedAssetRequest.php` | request | 106 | this report | ✅ |
| 4 | `Modules/Accounting/app/Services/DepreciationService.php` | service (shared, UNCLAIMED) | 210 | this report audits; listed in RETURN | ✅ |
| 5 | `Modules/Accounting/app/Policies/FixedAssetPolicy.php` | policy (shared, UNCLAIMED) | 41 | this report audits; listed in RETURN | ✅ |
| 6 | `Modules/Accounting/routes/web.php` | routes | 268-275 | this report (route findings) | ✅ |
| 7 | `Modules/Accounting/resources/views/fixed-asset/create.blade.php` | view | — | this report | ✅ |
| 8 | `Modules/Accounting/resources/views/fixed-asset/edit.blade.php` | view | — | this report | ✅ |
| 9 | `Modules/Accounting/resources/views/fixed-asset/show.blade.php` | view | — | this report | ✅ |
| 10 | `Modules/Accounting/resources/views/fixed-asset/trash.blade.php` | view | — | this report | ✅ |
| 11 | `Modules/Accounting/resources/views/pages/partials/assets-integration/_fixed-assets.blade.php` | view (other controller) | 725 | ↗ AccDashboardController (CLAIMED, report not yet written) | ↗ linked |
| 12 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | base model (shared) | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 13 | `Modules/Accounting/app/Services/AccountingContext.php` | service (shared) | — | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 14 | `Modules/Accounting/app/Models/AssetCategory.php` | model (shared) | — | ↗ [gaurav/Accounting/AssetCategoryController](../AssetCategoryController/01-report.md) | ↗ linked |
| 15 | `Modules/Accounting/app/Models/AssetDisposal.php` | model (shared) | — | ↗ [gaurav/Accounting/AssetDisposalController](../AssetDisposalController/01-report.md) | ↗ linked |
| 16 | `Modules/Accounting/app/Models/DepreciationEntry.php` | model (shared) | — | ↗ DepreciationEntryController (CLAIMED, report not yet written) | ↗ linked |
| 17 | `Modules/Accounting/app/Models/Voucher.php` | model (shared) | — | ↗ VoucherController (CLAIMED, report not yet written) | ↗ linked |
| 18 | `Modules/Accounting/app/Services/VoucherService.php` | service (shared) | — | ↗ VoucherController (CLAIMED, report not yet written) | ↗ linked |

No pre-applied files.

## 4. Routes

```
  GET|HEAD        accounting/fixed-asset accounting.fixed-asset.index › Modules\Accounting\Http\Controllers\FixedAsse…
  POST            accounting/fixed-asset accounting.fixed-asset.store › Modules\Accounting\Http\Controllers\FixedAsse…
  GET|HEAD        accounting/fixed-asset/create accounting.fixed-asset.create › Modules\Accounting\Http\Controllers\F…
  POST            accounting/fixed-asset/depreciation/run accounting.fixed-asset.runDepreciation.legacy › Modules\Acc…
  GET|HEAD        accounting/fixed-asset/trash/view accounting.fixed-asset.trashed › Modules\Accounting\Http\Controll…
  GET|HEAD        accounting/fixed-asset/{fixed_asset} accounting.fixed-asset.show › Modules\Accounting\Http\Controll…
  PUT|PATCH       accounting/fixed-asset/{fixed_asset} accounting.fixed-asset.update › Modules\Accounting\Http\Contro…
  DELETE          accounting/fixed-asset/{fixed_asset} accounting.fixed-asset.destroy › Modules\Accounting\Http\Contr…
  GET|HEAD        accounting/fixed-asset/{fixed_asset}/edit accounting.fixed-asset.edit › Modules\Accounting\Http\Con…
  POST            accounting/fixed-asset/{fixed_asset}/post-voucher accounting.fixed-asset.postVoucher › Modules\Acco…
  POST            accounting/fixed-asset/{fixed_asset}/run-depreciation accounting.fixed-asset.runDepreciation › Modu…
  POST            accounting/fixed-asset/{fixed_asset}/toggle-status accounting.fixed-asset.toggleStatus › Modules\Ac…
  DELETE          accounting/fixed-asset/{id}/force-delete accounting.fixed-asset.forceDelete › Modules\Accounting\Ht…
  GET|HEAD        accounting/fixed-asset/{id}/restore accounting.fixed-asset.restore › Modules\Accounting\Http\Contro…

                                                                                                   Showing [14] routes
```

Unrouted public methods: none (all 13 public methods have a route; `index()` is reachable but redirects to `accounting.menu.assetsIntegration`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 22 | GET /accounting/fixed-asset | `tenant.accounting.fixed-asset.viewAny` | none | none | none | — |
| `create` | 29 | GET /accounting/fixed-asset/create | `tenant.accounting.fixed-asset.create` | none | none | none | FXAS-14 |
| `store` | 54 | POST /accounting/fixed-asset | `tenant.accounting.fixed-asset.create` | controller (63-65) | `'Created'` (after tx) | `acc_fixed_assets`, `sys_activity_logs` | FXAS-01, FXAS-03, FXAS-06 |
| `show` | 76 | GET /accounting/fixed-asset/{fixed_asset} | `tenant.accounting.fixed-asset.view` | none | none | none | — |
| `edit` | 100 | GET /accounting/fixed-asset/{fixed_asset}/edit | `tenant.accounting.fixed-asset.update` | none | none | none | FXAS-14 |
| `update` | 132 | PUT/PATCH /accounting/fixed-asset/{fixed_asset} | `tenant.accounting.fixed-asset.update` | controller (140-142) | `'Updated'` (after tx) | `acc_fixed_assets`, `sys_activity_logs` | FXAS-01, FXAS-03, FXAS-06 |
| `postVoucher` | 153 | POST /accounting/fixed-asset/{fixed_asset}/post-voucher | `tenant.accounting.fixed-asset.update` | controller (180-209) | `'VoucherPosted'` (after tx) | `acc_vouchers`, `acc_voucher_items`, `acc_fixed_assets`, `sys_activity_logs` | FXAS-01, FXAS-03, FXAS-04, FXAS-07, FXAS-11, FXAS-12 |
| `destroy` | 226 | DELETE /accounting/fixed-asset/{fixed_asset} | `tenant.accounting.fixed-asset.delete` | controller (231-235) | `'Trashed'` (after tx) | `acc_fixed_assets`, `sys_activity_logs` | FXAS-01, FXAS-03 |
| `toggleStatus` | 246 | POST /accounting/fixed-asset/{fixed_asset}/toggle-status | `tenant.accounting.fixed-asset.update` | controller (253-256) | `'Toggled'` (after tx) | `acc_fixed_assets`, `sys_activity_logs` | FXAS-01, FXAS-03 |
| `runDepreciation` | 267 | POST /accounting/fixed-asset/{fixed_asset}/run-depreciation | `tenant.accounting.fixed-asset.depreciate` | controller (277-279) + service (89-156) | `'Depreciated'` (after tx) | `acc_vouchers`, `acc_voucher_items`, `acc_depreciation_entries`, `sys_activity_logs` | FXAS-01, FXAS-03, FXAS-09 |
| `trashed` | 296 | GET /accounting/fixed-asset/trash/view | `tenant.accounting.fixed-asset.restore` | none | none | none | FXAS-15 |
| `restore` | 305 | GET /accounting/fixed-asset/{id}/restore | `tenant.accounting.fixed-asset.restore` | controller (310-315) | `'Restored'` (after tx) | `acc_fixed_assets`, `sys_activity_logs` | FXAS-01, FXAS-02, FXAS-03, FXAS-08 |
| `forceDelete` | 326 | DELETE /accounting/fixed-asset/{id}/force-delete | `tenant.accounting.fixed-asset.forceDelete` | controller (331-335) | `'Deleted'` (inside tx) | `acc_fixed_assets`, `acc_depreciation_entries` (cascade), `sys_activity_logs` | FXAS-01, FXAS-02, FXAS-03, FXAS-17 |

## 6. Findings

### F1 — Errors

#### FXAS-01 · B · ERR-01 — Raw exception text is printed to the user in seven handlers

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never expose raw exception text to the user; log it and show a safe message* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:70-72, 147-149, 220-222, 240-242, 290-292, 320-322, 338-340`; broad catches at 261-263 too |
| **Root cause** | Every mutation wraps the whole operation in `catch (\Throwable $e)` and concatenates `$e->getMessage()` into the flash message (the toggle handler logs it but still catches `\Throwable`). D1 forbids the wrapper; D2 allows only the specific catches listed there. |
| **Consequence** | A failed insert shows SQL, constraint and table names in the red banner (e.g. the `voucher_date` failure), leaking schema details and burying the real error. |
| **Reproduce** | Open an asset's Post Voucher form and submit it: the banner reads `Failed to post voucher: SQLSTATE[HY000]: General error: 1364 Field 'voucher_date' doesn't have a default value` (see FXAS-12) instead of a safe message. |
| **Fix approach** | Delete the seven `try/catch (\Throwable)` wrappers and let the central handler render the 500. Keep only the `DomainException` catches in `postVoucher` and `runDepreciation`, because those messages are user-safe business rules (D2). |
| **Plan item** | 1.1, 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7 in `02-fix-plan.md` §1 and §3 |

```php
// FixedAssetController.php:70-72 — CURRENT
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('FixedAsset create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return back()->with('error', 'Failed to create Fixed Asset: ' . $e->getMessage())->withInput();
        }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern 'catch \(\\Throwable|getMessage\(\)'
70: } catch (\Throwable $e) {
71: \Illuminate\Support\Facades\Log::error('FixedAsset create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
72: return back()->with('error', 'Failed to create Fixed Asset: ' . $e->getMessage())->withInput();
147: } catch (\Throwable $e) {
148: \Illuminate\Support\Facades\Log::error('FixedAsset update failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
149: return back()->with('error', 'Failed to update Fixed Asset: ' . $e->getMessage())->withInput();
220: } catch (\Throwable $e) {
221: \Illuminate\Support\Facades\Log::error('FixedAsset postVoucher failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
222: return back()->with('error', 'Failed to post voucher: ' . $e->getMessage());
240: } catch (\Throwable $e) {
241: \Illuminate\Support\Facades\Log::error('FixedAsset destroy failed: ' . $e->getMessage());
242: return back()->with('error', 'Failed to delete Fixed Asset: ' . $e->getMessage());
261: } catch (\Throwable $e) {
262: \Illuminate\Support\Facades\Log::error('FixedAsset toggleStatus failed: ' . $e->getMessage());
290: } catch (\Throwable $e) {
291: \Illuminate\Support\Facades\Log::error('FixedAsset runDepreciation failed: ' . $e->getMessage());
292: return back()->with('error', $e->getMessage());
320: } catch (\Throwable $e) {
321: \Illuminate\Support\Facades\Log::error('FixedAsset restore failed: ' . $e->getMessage());
322: return back()->with('error', 'Failed to restore Fixed Asset: ' . $e->getMessage());
338: } catch (\Throwable $e) {
339: \Illuminate\Support\Facades\Log::error('FixedAsset forceDelete failed: ' . $e->getMessage());
340: return back()->with('error', 'Failed to permanently delete Fixed Asset: ' . $e->getMessage());
```

#### FXAS-02 · H · ERR-02 — A missing asset in restore/forceDelete becomes a flash instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:309-323` (`restore`) and `330-341` (`forceDelete`) |
| **Root cause** | `findOrFail()` is called inside the `try`, and `catch (\Throwable $e)` swallows `ModelNotFoundException` and redirects with a red flash. |
| **Consequence** | Opening a stale trash link reports "Failed to restore Fixed Asset" instead of the honest 404, and the failure is logged as an application error. |
| **Reproduce** | As a user with `restore`, open `http://test.localhost/accounting/fixed-asset/999999/restore`. Expected 404; actual 302 back with a red flash. |
| **Fix approach** | Resolve the model with `findOrFail()` outside any catch and delete the wrapper (plan 3.6/3.7). |
| **Plan item** | 3.6, 3.7 in `02-fix-plan.md` §3 |

```php
// FixedAssetController.php:309-323 — CURRENT
        try {
            $model = DB::transaction(function () use ($id) {
                $model = FixedAsset::onlyTrashed()->findOrFail($id);
                $model->restore();
                $model->update(['is_active' => true]);
                return $model;
            });

            activityLog($model, 'Restored', ['message' => 'Fixed Asset restored.', 'name' => $model->name]);

            return redirect()->route('accounting.fixed-asset.trashed')->with('success', 'Fixed Asset restored successfully.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('FixedAsset restore failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to restore Fixed Asset: ' . $e->getMessage());
        }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern 'findOrFail'
311: $model = FixedAsset::onlyTrashed()->findOrFail($id);
332: $model = FixedAsset::withTrashed()->findOrFail($id);
```

### F2 — Transactions and audit

#### FXAS-03 · H · TXN-04 — Audit rows are written after the transaction commits

| Field | Value |
|---|---|
| **Rule** | TXN-04 (H) — *the audit row must be written inside the same transaction as the business write* |
| **Where** | `FixedAssetController.php:67` (`store`), `144` (`update`), `211` (`postVoucher`), `237` (`destroy`), `258` (`toggleStatus`), `281` (`runDepreciation`), `317` (`restore`); `forceDelete` at 334 is already inside |
| **Root cause** | `activityLog()` is called after the `DB::transaction()` block returns, so the business row is committed before the audit insert is attempted. |
| **Consequence** | If the audit insert fails, the asset change is already saved but the user is told it failed; the change has no audit trail, and a retry duplicates it. |
| **Reproduce** | Static only — the ordering is visible at the quoted lines; no write was executed (D4). |
| **Fix approach** | Move `activityLog()` inside the transaction closure, after the business write, in all seven methods. |
| **Plan item** | 1.1, 3.1, 3.2, 3.3, 3.4, 3.5, 3.6 in `02-fix-plan.md` §1 and §3 |

```php
// FixedAssetController.php:62-73 — CURRENT
        try {
            $fixedAsset = DB::transaction(function () use ($validated) {
                return FixedAsset::create($validated);
            });

            activityLog($fixedAsset, 'Created', ['message' => 'Fixed Asset created.', 'name' => $fixedAsset->name, 'asset_code' => $fixedAsset->asset_code]);

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'fixed-assets'])->with('success', 'Fixed Asset created successfully.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('FixedAsset create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return back()->with('error', 'Failed to create Fixed Asset: ' . $e->getMessage())->withInput();
        }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern 'activityLog|DB::transaction' | Select-Object -First 16
63: $fixedAsset = DB::transaction(function () use ($validated) {
67: activityLog($fixedAsset, 'Created', ['message' => 'Fixed Asset created.', 'name' => $fixedAsset->name, 'asset_code' => $fixedAsset->asset_code]);
140: DB::transaction(function () use ($fixedAsset, $validated) {
144: activityLog($fixedAsset, 'Updated', ['message' => 'Fixed Asset updated.', 'name' => $fixedAsset->name, 'asset_code' => $fixedAsset->asset_code]);
180: $voucher = DB::transaction(function () use ($request, $fixedAsset, $fy) {
211: activityLog($fixedAsset, 'VoucherPosted', [
231: DB::transaction(function () use ($fixedAsset) {
237: activityLog($fixedAsset, 'Trashed', ['message' => 'Fixed Asset trashed.', 'name' => $fixedAsset->name, 'asset_code' => $fixedAsset->asset_code]);
253: DB::transaction(function () use ($fixedAsset, $request) {
258: activityLog($fixedAsset, 'Toggled', ['message' => 'Fixed Asset status toggled.', 'name' => $fixedAsset->name, 'active' => $fixedAsset->is_active]);
277: $entry = DB::transaction(function () use ($fixedAsset, $fy) {
281: activityLog($fixedAsset, 'Depreciated', [
310: $model = DB::transaction(function () use ($id) {
317: activityLog($model, 'Restored', ['message' => 'Fixed Asset restored.', 'name' => $model->name]);
331: DB::transaction(function () use ($id) {
334: activityLog($model, 'Deleted', ['message' => 'Fixed Asset permanently deleted.', 'name' => $model->name]);
```

#### FXAS-04 · H · TXN-06 — Concurrent Post Voucher requests can double-post

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *a check-then-act on a uniqueness invariant must be serialized by a lock or a unique index* |
| **Where** | `FixedAssetController.php:157-159` (read), `180-206` (transaction and write) |
| **Root cause** | `voucher_id` is checked before the transaction and written inside it, with no `lockForUpdate()` and no unique index. Two requests for the same asset both see `null`. |
| **Consequence** | Two posted vouchers debit the same purchase twice, and one `voucher_id` overwrites the other, so the ledger and the asset subledger disagree. Latent today because FXAS-12 aborts the create; armed as soon as FXAS-12 is fixed. |
| **Reproduce** | Static only — requires two concurrent HTTP writes, which D4 forbids during an audit. |
| **Fix approach** | Inside the transaction, re-select the asset with `lockForUpdate()` and re-check `voucher_id`; throw a validation error on the second request. Fixed by the same rewrite as FXAS-12. |
| **Plan item** | 1.1 in `02-fix-plan.md` §1 |

```php
// FixedAssetController.php:157-159 — CURRENT
        if ($fixedAsset->voucher_id) {
            return back()->with('error', 'A voucher is already posted for this Fixed Asset.');
        }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern 'voucher_id|lockForUpdate'
157: if ($fixedAsset->voucher_id) {
206: $fixedAsset->update(['voucher_id' => $voucher->id]);
215: 'voucher_id'     => $voucher->id,
```
(no `lockForUpdate` match; the asset row is never locked)

### F3 — Authorization

#### FXAS-05 · M · AUTH-06 — The registered FixedAssetPolicy is dead and lacks restore/forceDelete

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *use the policy registered for the model; do not keep a parallel permission-string authorization path* |
| **Where** | `Modules/Accounting/app/Policies/FixedAssetPolicy.php:10-41`; registered at `Modules/Accounting/app/Providers/AccountingServiceProvider.php:149`; controller uses string gates at lines 24, 31, 56, 78, 102, 134, 155, 228, 248, 269, 298, 307, 328 |
| **Root cause** | All checks call `Gate::authorize('tenant.accounting.fixed-asset.…')` directly, so the model policy is never consulted. The policy also has no `restore` or `forceDelete` method even though those abilities exist. |
| **Consequence** | Any future `@can('restore', $fixedAsset)` or `$this->authorize('update', $fixedAsset)` silently denies, because the policy has no such method; there are two authorization sources that can drift. |
| **Reproduce** | `php artisan tinker` → `Gate::forUser($user)->allows('restore', $asset)` returns `false` while the string gate `tenant.accounting.fixed-asset.restore` returns `true` for the same user. |
| **Fix approach** | DECISION, module-wide: either move the controller to policy abilities and add `restore`/`forceDelete` to the policy, or delete the dead policy. Do not do half of each. |
| **Plan item** | none — see `02-fix-plan.md` §9 (DECISION) |

```php
// FixedAssetPolicy.php:10-41 — CURRENT
class FixedAssetPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('tenant.accounting.fixed-asset.viewAny');
    }

    public function view(User $user, FixedAsset $fixedAsset): bool
    {
        return $user->can('tenant.accounting.fixed-asset.view');
    }

    public function create(User $user): bool
    {
        return $user->can('tenant.accounting.fixed-asset.create');
    }

    public function update(User $user, FixedAsset $fixedAsset): bool
    {
        return $user->can('tenant.accounting.fixed-asset.update');
    }

    public function delete(User $user, FixedAsset $fixedAsset): bool
    {
        return $user->can('tenant.accounting.fixed-asset.delete');
    }

    public function depreciate(User $user, FixedAsset $fixedAsset): bool
    {
        return $user->can('tenant.accounting.fixed-asset.depreciate');
    }
}
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Providers\AccountingServiceProvider.php -Pattern 'FixedAssetPolicy'
149: Gate::policy(FixedAsset::class, FixedAssetPolicy::class);
$ Select-String -Path Modules\Accounting\app\Policies\FixedAssetPolicy.php -Pattern 'public function'
12: public function viewAny(User $user): bool
17: public function view(User $user, FixedAsset $fixedAsset): bool
22: public function create(User $user): bool
27: public function update(User $user, FixedAsset $fixedAsset): bool
32: public function delete(User $user, FixedAsset $fixedAsset): bool
37: public function depreciate(User $user, FixedAsset $fixedAsset): bool
```

#### FXAS-06 · L · AUTH-04 — Store and update authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *one authorization check per request path* |
| **Where** | `Modules/Accounting/app/Http/Requests/FixedAssetRequest.php:15-18` plus `FixedAssetController.php:56` and `:134` |
| **Root cause** | The FormRequest calls `authorizeByCrudPermission('tenant.accounting.fixed-asset')` (POST → `create`, PUT/PATCH → `update`), then the controller repeats `Gate::authorize()` with the same ability. |
| **Consequence** | Every save performs two permission lookups, and a future change to one path can leave the other granting or denying differently. |
| **Reproduce** | Static only — the duplicate calls are visible at the quoted lines. |
| **Fix approach** | Remove the two controller Gate calls and rely on the FormRequest. |
| **Plan item** | 4.1 in `02-fix-plan.md` §4 |

```php
// FixedAssetRequest.php:15-18 — CURRENT
    public function authorize(): bool
    {
        return $this->authorizeByCrudPermission('tenant.accounting.fixed-asset');
    }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern "Gate::authorize\('tenant.accounting.fixed-asset.create'\)|Gate::authorize\('tenant.accounting.fixed-asset.update'\)"
31: Gate::authorize('tenant.accounting.fixed-asset.create');
56: Gate::authorize('tenant.accounting.fixed-asset.create');
102: Gate::authorize('tenant.accounting.fixed-asset.update');
134: Gate::authorize('tenant.accounting.fixed-asset.update');
155: Gate::authorize('tenant.accounting.fixed-asset.update');
248: Gate::authorize('tenant.accounting.fixed-asset.update');
```

### F4 — Validation and input

#### FXAS-07 · M · VAL-02 — Post Voucher validates six fields inline instead of in a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation rules belong in a FormRequest, not in the controller* |
| **Where** | `FixedAssetController.php:153-168`, method `postVoucher()` |
| **Root cause** | The method takes the base `Request` and calls `$request->validate()` with a six-rule inline array; there is no request class and no per-field attribute labels. |
| **Consequence** | The rules cannot be reused or unit-tested, the 422 messages show raw column names, and the method mixes transport, validation and posting. |
| **Reproduce** | Submit Post Voucher with an empty amount: the error names `amount`, not "Amount". |
| **Fix approach** | Add `FixedAssetVoucherRequest` and type the method against it; the same rewrite fixes FXAS-12. |
| **Plan item** | 1.1 in `02-fix-plan.md` §1 |

```php
// FixedAssetController.php:153-168 — CURRENT
    public function postVoucher(Request $request, FixedAsset $fixedAsset)
    {
        Gate::authorize('tenant.accounting.fixed-asset.update');

        if ($fixedAsset->voucher_id) {
            return back()->with('error', 'A voucher is already posted for this Fixed Asset.');
        }

        $request->validate([
            'voucher_type_id'  => 'required|exists:acc_voucher_types,id',
            'debit_ledger_id'  => 'required|exists:acc_ledgers,id',
            'credit_ledger_id' => 'required|exists:acc_ledgers,id',
            'date'             => 'required|date',
            'amount'           => 'required|numeric|min:0.01',
            'narration'        => 'nullable|string|max:500',
        ]);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern '\$request->validate'
165: $request->validate([
```

### F5 — Routes

#### FXAS-08 · H · RTE-01 — Restore is a GET request that changes state

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *state-changing routes must not use GET* |
| **Where** | `Modules/Accounting/routes/web.php:269`; handler `FixedAssetController.php:305-324` |
| **Root cause** | The GET route for `/fixed-asset/{id}/restore` declares a mutation as a read. |
| **Consequence** | A link prefetcher, crawler or browser URL prefetch can restore trashed assets with no confirmation and no CSRF token; the action is also unsafe to retry. |
| **Reproduce** | While logged in as a role with `restore`, paste `http://test.localhost/accounting/fixed-asset/{id}/restore` in the address bar and press Enter: the asset is restored by a GET. |
| **Fix approach** | Change the verb to DELETE; the shared `x-backend.table.action-trashed` component already emits POST plus `@method`, so no Blade change is needed. |
| **Plan item** | 5.1 in `02-fix-plan.md` §5 (⚠ SHARED) |

```php
// routes/web.php:268-270 — CURRENT
Route::get('/fixed-asset/trash/view', [FixedAssetController::class, 'trashed'])->name('fixed-asset.trashed');
Route::get('/fixed-asset/{id}/restore', [FixedAssetController::class, 'restore'])->name('fixed-asset.restore');
Route::delete('/fixed-asset/{id}/force-delete', [FixedAssetController::class, 'forceDelete'])->name('fixed-asset.forceDelete');
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\routes\web.php -Pattern 'fixed-asset/\{id\}/restore'
269: Route::get('/fixed-asset/{id}/restore', [FixedAssetController::class, 'restore'])->name('fixed-asset.restore');
```

#### FXAS-09 · H · CTL-03 — The legacy depreciation route has no asset parameter and always fails

| Field | Value |
|---|---|
| **Rule** | CTL-03 (H) — *every route must bind the parameters its action needs; a dead route must be removed* |
| **Where** | `Modules/Accounting/routes/web.php:275`; handler `FixedAssetController.php:267-294` |
| **Root cause** | `POST /fixed-asset/depreciation/run` points at `runDepreciation(FixedAsset $fixedAsset)` but supplies no `{fixed_asset}`. Laravel injects a new, empty `FixedAsset` model, so `is_active` is `null` and the service rejects it. |
| **Consequence** | Every caller of the legacy URL gets "Cannot run depreciation on an inactive asset." and no depreciation is ever posted; the route is a dead feature with a misleading name. |
| **Reproduce** | POST `/accounting/fixed-asset/depreciation/run` with a valid session and CSRF token: always the inactive-asset error, never an entry. |
| **Fix approach** | DECISION: remove the legacy route (recommended), or add `{fixed_asset}` and point it at the same handler as the current route. |
| **Plan item** | none — see `02-fix-plan.md` §9 (DECISION) |

```php
// routes/web.php:274-275 — CURRENT
Route::post('/fixed-asset/{fixed_asset}/run-depreciation', [FixedAssetController::class, 'runDepreciation'])->name('fixed-asset.runDepreciation');
Route::post('/fixed-asset/depreciation/run', [FixedAssetController::class, 'runDepreciation'])->name('fixed-asset.runDepreciation.legacy');
```

**Evidence**
```
$ php artisan route:list --name=fixed-asset
  POST            accounting/fixed-asset/depreciation/run accounting.fixed-asset.runDepreciation.legacy › Modules\Acc…
  POST            accounting/fixed-asset/{fixed_asset}/run-depreciation accounting.fixed-asset.runDepreciation › Modu…
```

### F6 — Controller shape

#### FXAS-10 · L · CTL-04 — Ten public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *declared return types make the action contract explicit* |
| **Where** | `FixedAssetController.php:22, 29, 54, 76, 100, 132, 153, 226, 246, 267` |
| **Root cause** | `index`, `create`, `store`, `show`, `edit`, `update`, `postVoucher`, `destroy`, `toggleStatus` and `runDepreciation` omit the return type; only `trashed`, `restore` and `forceDelete` declare one. |
| **Consequence** | A wrong return (e.g. an array instead of a redirect) is only caught at runtime; static analysis cannot verify the action. |
| **Reproduce** | Static only — see the quoted signatures. |
| **Fix approach** | None now; add `View|RedirectResponse|JsonResponse` opportunistically when the methods are next edited. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// FixedAssetController.php:22-27 — CURRENT
    public function index()
    {
        Gate::authorize('tenant.accounting.fixed-asset.viewAny');

        return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'fixed-assets']);
    }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern 'public function'
22: public function index()
29: public function create()
54: public function store(FixedAssetRequest $request)
76: public function show(FixedAsset $fixedAsset)
100: public function edit(FixedAsset $fixedAsset)
132: public function update(FixedAssetRequest $request, FixedAsset $fixedAsset)
153: public function postVoucher(Request $request, FixedAsset $fixedAsset)
226: public function destroy(FixedAsset $fixedAsset)
246: public function toggleStatus(Request $request, FixedAsset $fixedAsset)
267: public function runDepreciation(FixedAsset $fixedAsset)
296: public function trashed(): \Illuminate\View\View
305: public function restore($id): \Illuminate\Http\RedirectResponse
326: public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

### F7 — Models
clean — `Select-String -Path Modules/Accounting/app/Models/FixedAsset.php -Pattern 'protected \$table|protected \$casts'` → `17: protected $table = 'acc_fixed_assets';` and the cast block covers all date/decimal/boolean columns; relationships are typed; the only defect is the accessor in FXAS-13.

### F8 — Services and jobs

#### FXAS-11 · M · SVC-02 — VoucherService is resolved with `app()` inside the method

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies must be constructor-injected, not resolved with `app()` or the service locator* |
| **Where** | `FixedAssetController.php:181-182`; constructor at `:21` injects only `DepreciationService` |
| **Root cause** | The method calls `app(\Modules\Accounting\Services\VoucherService::class)` instead of declaring the dependency. |
| **Consequence** | The dependency is hidden from the constructor, cannot be swapped in a test, and a renamed class string fails only when the method runs. |
| **Reproduce** | Static only — see the quoted lines. |
| **Fix approach** | Add `VoucherService` to the constructor and use `$this->voucherService`; done in the same rewrite as FXAS-12. |
| **Plan item** | 1.1 in `02-fix-plan.md` §1 |

```php
// FixedAssetController.php:180-182 — CURRENT
            $voucher = DB::transaction(function () use ($request, $fixedAsset, $fy) {
                /** @var \Modules\Accounting\Services\VoucherService $voucherService */
                $voucherService = app(\Modules\Accounting\Services\VoucherService::class);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern 'app\('
182: $voucherService = app(\Modules\Accounting\Services\VoucherService::class);
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern 'function __construct'
21: public function __construct(private readonly DepreciationService $service) {}
```

#### FXAS-12 · B · SVC-04 — Post Voucher never creates a postable voucher

| Field | Value |
|---|---|
| **Rule** | SVC-04 (B) — *one business operation has one implementation; a controller must not re-implement service semantics incorrectly* |
| **Where** | `FixedAssetController.php:184-209`, success message at `:219` |
| **Root cause** | Three independent defects in one payload: (1) it sends `'date'`, but `Voucher` is fillable for `voucher_date` and the column is `NOT NULL` with no default; (2) it sends `'status' => 'posted'`, but `VoucherService::create()` overwrites `$data['status'] = 'Draft'`; (3) it never calls `VoucherService::post()`, so even a successful insert stays Draft. |
| **Consequence** | The request fails with `SQLSTATE[HY000]: General error: 1364 Field 'voucher_date' doesn't have a default value` and no voucher exists; if only the key were corrected, the UI would claim "posted" while `acc_vouchers.status` stays `Draft` and the ledger is untouched. |
| **Reproduce** | Open `/accounting/fixed-asset/{id}/edit`, fill the Post Voucher panel and submit: red banner with the SQL error; `select count(*) from acc_vouchers` is unchanged. |
| **Fix approach** | Use the same pattern as `ConcessionController.php:214-238`: send `voucher_date`, drop `status`/`is_active`, call `post($voucher->fresh())`, refresh the voucher, and log inside the transaction (plan 1.1). |
| **Plan item** | 1.1 in `02-fix-plan.md` §1 |

```php
// FixedAssetController.php:184-190 — CURRENT
                $voucher = $voucherService->create([
                    'voucher_type_id'   => (int) $request->input('voucher_type_id'),
                    'financial_year_id' => $fy->id,
                    'date'              => $request->input('date', $fixedAsset->purchase_date?->format('Y-m-d') ?? now()->format('Y-m-d')),
                    'narration'         => $request->input('narration') ?: "Purchase of Fixed Asset: {$fixedAsset->name} [{$fixedAsset->asset_code}]",
                    'status'            => 'posted',
                    'is_active'         => true,
                ], [
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Services\VoucherService.php -Pattern "status'\] = 'Draft'"
31: $data['status'] = 'Draft';
$ Select-String -Path database\migrations\tenant\2026_09_16_100040_create_acc_vouchers_table.php -Pattern "voucher_date"
31: $table->date('voucher_date')->comment('The accounting date. Drives which period it lands in');
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern 'post\('
(no output)
```

### F9 — Queries and performance

#### FXAS-13 · M · QRY-01 — The accumulated-depreciation accessor queries on every read

| Field | Value |
|---|---|
| **Rule** | QRY-01 (M) — *an accessor used in a list must not issue one query per access* |
| **Where** | `Modules/Accounting/app/Models/FixedAsset.php:65-70`; consumed at `_fixed-assets.blade.php:250, 253, 314, 315` |
| **Root cause** | `getAccumulatedDepreciationAttribute()` always runs `depreciationEntries()->sum()`, with no memoization and no use of an already-loaded relation. The list partial reads both `accumulated_depreciation` and `net_book_value` twice per row (visible cell and data attribute), and `net_book_value` calls the same accessor. |
| **Consequence** | The Fixed Assets tab issues about four SUM queries per row (two reads × two attributes), so a 15-row page runs dozens of identical queries and slows down as entries grow. |
| **Reproduce** | Open `/accounting/assets-integration?tab=fixed-assets` with a query logger: repeated `select sum(depreciation_amount) from acc_depreciation_entries where fixed_asset_id = ? and is_posted = 1` for each row. |
| **Fix approach** | Memoize the value per model instance and, when the relation is loaded, sum in PHP instead of querying (plan 6.1). |
| **Plan item** | 6.1 in `02-fix-plan.md` §6 |

```php
// FixedAsset.php:65-70 — CURRENT
    public function getAccumulatedDepreciationAttribute(): float
    {
        return (float) $this->depreciationEntries()
            ->where('is_posted', true)
            ->sum('depreciation_amount');
    }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\resources\views\pages\partials\assets-integration\_fixed-assets.blade.php -Pattern 'accumulated_depreciation|net_book_value'
250: ?{{ number_format((float) $fixedAsset->accumulated_depreciation, 2) }}
253: ?{{ number_format((float) $fixedAsset->net_book_value, 2) }}
314: data-accum-dep="{{ number_format((float)$fixedAsset->accumulated_depreciation, 2) }}"
315: data-net-book-value="{{ number_format((float)$fixedAsset->net_book_value, 2) }}"
$ Select-String -Path Modules\Accounting\app\Models\FixedAsset.php -Pattern 'return \(float\) \$this->depreciationEntries'
67: return (float) $this->depreciationEntries()
```

#### FXAS-14 · M · QRY-15 — Create/edit loaders fetch every row into the page

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *picker data must be bounded or searchable; never `->get()` an unbounded table into a form* |
| **Where** | `Modules/Accounting/app/Models/FixedAsset.php:251-274` (`selectableVouchers`, `selectableCustodians`, `selectableLedgers`, `selectableCategories`); called at `FixedAssetController.php:33-40, 106-115` |
| **Root cause** | Every picker uses `->get()` with no `limit`, no search and no pagination, and `selectableLedgers()` also eager-loads `accountGroup` for every ledger. |
| **Consequence** | On a tenant with thousands of users, ledgers or vouchers the create/edit HTML embeds thousands of option elements, ballooning memory and response time. |
| **Reproduce** | Open `/accounting/fixed-asset/create` with a query logger: the full `sys_users`, `acc_ledgers` and `acc_vouchers` sets are selected, regardless of page size. |
| **Fix approach** | DECISION: switch these pickers to a bounded searchable select (limit + server-side search), or at minimum cap the result set. |
| **Plan item** | none — see `02-fix-plan.md` §9 (DECISION) |

```php
// FixedAsset.php:251-261 — CURRENT
    public static function selectableVouchers()
    {
        return Voucher::where('is_active', true)
            ->orderByDesc('voucher_date')
            ->get(['id', 'voucher_number', 'voucher_prefix', 'voucher_display_no']);
    }

    public static function selectableLedgers()
    {
        return Ledger::active()->with('accountGroup')->orderBy('name')->get();
    }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Models\FixedAsset.php -Pattern 'selectableVouchers|selectableCustodians|selectableLedgers|selectableCategories'
239: public static function selectableCategories()
251: public static function selectableVouchers()
258: public static function selectableLedgers()
268: public static function selectableCustodians()
```
(all four end in `->get()` with no limit; see lines 241, 255, 260, 273)

#### FXAS-15 · L · QRY-02 — The trash page paginates 15 rows while the house standard is 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (L) — *list pages use the house page size (10)* |
| **Where** | `FixedAssetController.php:300` |
| **Root cause** | `paginate(15)` is hardcoded. |
| **Consequence** | The trash list shows a different page size from every other accounting list, which breaks visual and navigation consistency. |
| **Reproduce** | Open `/accounting/fixed-asset/trash/view`: the paginator reports 15 per page. |
| **Fix approach** | Change to `paginate(10)`. |
| **Plan item** | 6.2 in `02-fix-plan.md` §6 |

```php
// FixedAssetController.php:300 — CURRENT
        $assets = FixedAsset::onlyTrashed()->with(['assetCategory', 'campus', 'custodian'])->orderBy('name')->paginate(15);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern 'paginate\('
300: $assets = FixedAsset::onlyTrashed()->with(['assetCategory', 'campus', 'custodian'])->orderBy('name')->paginate(15);
```

### F10 — Views
clean — `Select-String -Path Modules\Accounting\resources\views\fixed-asset\*.blade.php -Pattern 'DB::|::where|::all\(|::first\(|\{!!'` → no matches; the four in-scope Blades query nothing and print escaped values.

### F11 — Security and tenancy
clean — `Select-String -Path Modules\Accounting\app\Http\Controllers\FixedAssetController.php -Pattern 'env\(|DB::raw|whereRaw|->statement\('` → no matches; the controller runs behind the tenant middleware and receives the tenant connection from the model layer. The only exposure is FXAS-01, which is reported under F1.

### F12 — Style

#### FXAS-16 · L · STY-02 — Five in-scope files fail Pint

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *changed files must be Pint-clean* |
| **Where** | `FixedAssetController.php`, `FixedAsset.php`, `FixedAssetRequest.php`, `DepreciationService.php`, `FixedAssetPolicy.php` |
| **Root cause** | Import order, unused imports, `!$var` spacing, concat spacing, braces position, trailing commas and method-chain indentation were never normalized. |
| **Consequence** | The CI Pint gate fails for every change in this area, so real review comments are buried in formatting noise. |
| **Reproduce** | `vendor\bin\pint --test` on each of the five files returns `"result":"fail"`. |
| **Fix approach** | Run Pint on each file (one plan item per file); also remove the three unused imports in the controller. |
| **Plan item** | 8.1-8.5 in `02-fix-plan.md` §8 |

```php
// FixedAssetController.php:12-17 — CURRENT
use Modules\Accounting\Models\AssetCategory;
use Modules\Accounting\Models\FinancialYear;
use Modules\Accounting\Models\FixedAsset;
use Modules\Accounting\Models\Voucher;
use Modules\Accounting\Services\DepreciationService;
use Modules\Vendor\Models\Vendor;
```

**Evidence**
```
$ vendor\bin\pint --test Modules/Accounting/app/Http/Controllers/FixedAssetController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\FixedAssetController.php","fixers":["class_attributes_separation","fully_qualified_strict_types","concat_space","trailing_comma_in_multiline","unary_operator_spaces","braces_position","no_unused_imports","not_operator_with_successor_space","single_line_empty_body","blank_line_before_statement","ordered_imports","binary_operator_spaces"]}]}
$ vendor\bin\pint --test Modules/Accounting/app/Models/FixedAsset.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\FixedAsset.php","fixers":["function_declaration","fully_qualified_strict_types","no_unused_imports","not_operator_with_successor_space","ordered_imports","binary_operator_spaces"]}]}
$ vendor\bin\pint --test Modules/Accounting/app/Http/Requests/FixedAssetRequest.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\FixedAssetRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
$ vendor\bin\pint --test Modules/Accounting/app/Services/DepreciationService.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Services\\DepreciationService.php","fixers":["single_import_per_statement","method_chaining_indentation","unary_operator_spaces","braces_position","not_operator_with_successor_space","single_line_empty_body","binary_operator_spaces"]}]}
$ vendor\bin\pint --test Modules/Accounting/app/Policies/FixedAssetPolicy.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Policies\\FixedAssetPolicy.php","fixers":["ordered_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 overwrite? | Q2 delete before replace? | Q3 duplicate impl? | Q4 soft-delete × unique? | Q5 race? | Q6 auth hole? | Q7 lying message? | Q8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok (`create` only) | ok | ok | ok (unique on `asset_code`; default scope excludes trashed) | ok | ok | FXAS-01 | ok |
| `update` | ok (fillable list) | ok | ok | ok | ok | ok | FXAS-01 | ok |
| `postVoucher` | ok | ok | FXAS-12 | ok | FXAS-04 | ok | FXAS-12 | ok |
| `destroy` | ok (sets `is_active=false` then soft-deletes) | ok | ok | ok | ok | ok | FXAS-01 | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |
| `runDepreciation` | ok | ok | ok | ok (unique `uq_acc_de_asset_period`) | ok (DB unique) | ok | FXAS-01 | FXAS-09 |
| `restore` | ok | ok | ok | FXAS-08 (GET) | ok | ok | FXAS-01/FXAS-02 | ok |
| `forceDelete` | ok | ok | ok | FXAS-17 | ok | ok | FXAS-01/FXAS-02 | ok |

#### FXAS-17 · B · F13 #2 — Force delete destroys the depreciation history

| Field | Value |
|---|---|
| **Rule** | F13 #2 (B) — *never delete history before its replacement is stored; a destructive delete must be guarded* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FixedAssetController.php:326-342`; FK at `database/migrations/tenant/2026_09_16_100065_create_acc_depreciation_entries_table.php:47` |
| **Root cause** | The FK `fk_acc_de_asset` is `cascadeOnDelete()`, and `forceDelete()` has no guard on `depreciationEntries()`, `voucher_id` or the disposal row. |
| **Consequence** | Permanently deleting an asset that has posted depreciation silently deletes its period entries, so the subledger no longer matches the surviving voucher and the depreciation audit trail is unrecoverable. |
| **Reproduce** | Force-delete an asset with entries (for example one of the five live `acc_depreciation_entries`): `select count(*) from acc_depreciation_entries` drops by that asset's rows. Static only — D4 forbids the write. |
| **Fix approach** | Before the transaction, refuse when `depreciationEntries()->withTrashed()->exists()`, `disposal()->exists()` or `voucher_id` is set; tell the user to trash instead (plan 3.7). |
| **Plan item** | 3.7 in `02-fix-plan.md` §3 |

```php
// FixedAssetController.php:330-335 — CURRENT
        try {
            DB::transaction(function () use ($id) {
                $model = FixedAsset::withTrashed()->findOrFail($id);
                $model->forceDelete();
                activityLog($model, 'Deleted', ['message' => 'Fixed Asset permanently deleted.', 'name' => $model->name]);
            });
```

**Evidence**
```
$ Select-String -Path database\migrations\tenant\2026_09_16_100065_create_acc_depreciation_entries_table.php -Pattern 'fixed_asset_id'
47: $table->foreign('fixed_asset_id', 'fk_acc_de_asset')->references('id')->on('acc_fixed_assets')->cascadeOnDelete();
$ Select-String -Path database\migrations\tenant\2026_09_16_100061_create_acc_asset_disposals_table.php -Pattern 'fixed_asset_id'
48: $table->foreign('fixed_asset_id', 'fk_acc_disposal_asset')->references('id')->on('acc_fixed_assets')->restrictOnDelete();
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `VoucherService` | `create()` unconditionally overwrites `status` with `Draft`, so every caller must call `post()` explicitly; this is correct behaviour but easy to misuse (as FXAS-12 shows). | — (informational) | VoucherController report owner; do not change here |
| `BaseAccountingModel` | Resolves `financial_year_id`, `period_id` and `campus_id` on create, but never defaults `voucher_date`; callers that omit it hit the NOT NULL error. | — (informational) | AccountingStatusMasterController report owner |
| `FixedAssetPolicy` | Registered but unreachable through the controller; missing `restore`/`forceDelete`. | AUTH-06 | Unclaimed shared class — flagged in RETURN |
| `DepreciationService` | Shared, unclaimed. Reviewed clean for this controller; the `(asset, period)` race is already protected by `uq_acc_de_asset_period`. | — | Unclaimed shared class — flagged in RETURN |

## 8. Not covered, and why

- **Scanner and self-check were skipped.** `final-audit-reports/_tools/scan.php` and `final-audit-reports/_tools/selfcheck.py` are not present in this checkout, so F1-F13 were checked by hand with `Select-String` and `php -l`; no scan JSON exists for this run.
- **No write was executed.** D4 forbids running tests or mutations, so FXAS-12's SQL failure is proven statically from the `voucher_date` NOT NULL migration plus the missing fillable key, not by submitting the form.
- **Blade rendering was not exercised in a browser.** The four in-scope views and the shared tab partial were read and grepped; no HTTP render was performed.
- **Depreciation arithmetic was not re-derived.** `DepreciationService` is a shared, unclaimed class; only its call contract (transaction, idempotency index, `post()` call) was audited here.
- **Queue/console paths:** none of this controller's methods dispatch jobs or run in a console command.
