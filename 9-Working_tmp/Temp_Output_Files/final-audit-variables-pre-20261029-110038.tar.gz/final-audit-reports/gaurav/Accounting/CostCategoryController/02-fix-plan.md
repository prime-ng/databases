# Fix Plan — Accounting / CostCategoryController

**From:** `01-report.md` (2026-10-22) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/CostCategoryController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | Shared route file — edited only by the `⚠ SHARED` DECISION CSCA-11 |
| `resources/views/components/backend/table/action-trashed.blade.php` | Shared component with 475 call sites — it already adapts to the route verb, so no edit is needed |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_cost-categories.blade.php` | Rendered by `AccDashboardController::setupMasters()` — outside this controller's scope |
| `Modules/Accounting/resources/views/cost-category/index.blade.php` | Orphaned view — cleanup pass, not this plan (CSCA-15, see §10) |
| `database/migrations/tenant/2026_09_16_100003_create_acc_cost_categories_table.php` | Migration — the schema is correct; never edit an existing migration |
| `Modules/GlobalMaster/app/Models/ActivityLog.php` | Shared model reached through `activityLog()` — owned by the GlobalMaster report |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | Owned by another report |
| `Modules/Accounting/app/Services/AccountingContext.php` | Owned by another report; not exercised by this model |
| `Modules/Accounting/app/Models/CostCategory.php` | Only the Pint item CSCA-16c may touch it; no functional edit in this plan |

## 1. Blocker reachable today

- [ ] **CSCA-01** · B · ERR-01 — replace the seven hand-rolled transactions with `DB::transaction()` and stop sending exception text to the browser.
  - **Fixes in the same pass:** CSCA-02 (missing trash row now 404s), CSCA-03 (no message-string logging; the framework records the exception), CSCA-04 (all seven mutations use `DB::transaction`), CSCA-05 (`Reordered` audit event), CSCA-06 (next ordinal computed under `lockForUpdate` inside the transaction), CSCA-07 (duplicate `Gate::authorize` calls removed from `store`/`update`), CSCA-10 (`ids.*` validated), CSCA-13 (return types on nine methods), CSCA-17 (a supplied ordinal is honoured), CSCA-19 (null ordinal keeps the current value).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CostCategoryController.php`
  - **Before** (`CostCategoryController.php:1-254`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Accounting\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Accounting\Http\Requests\CostCategoryRequest;
    use Modules\Accounting\Models\CostCategory;

    class CostCategoryController extends Controller
    {
        public function index()
        {
            Gate::authorize('tenant.accounting.cost-category.viewAny');

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-categories']);
        }

        public function create()
        {
            Gate::authorize('tenant.accounting.cost-category.create');

            return view('accounting::cost-category.create');
        }

        public function store(CostCategoryRequest $request)
        {
            Gate::authorize('tenant.accounting.cost-category.create');

            $validated = $request->validated();
            $validated['ordinal'] = CostCategory::max('ordinal') + 1;

            DB::beginTransaction();
            try {
                $costCategory = CostCategory::create($validated);

                activityLog($costCategory, 'Created', [
                    'message'      => 'Cost Category created: ' . $costCategory->name,
                    'code'         => $costCategory->code,
                    'name'         => $costCategory->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-categories'])
                    ->with('success', 'Cost Category created successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to create Cost Category', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString(),
                ]);

                return back()->withInput()->with('error', 'Failed to create Cost Category: ' . $e->getMessage());
            }
        }

        public function show(CostCategory $costCategory)
        {
            Gate::authorize('tenant.accounting.cost-category.view');

            return view('accounting::cost-category.show', compact('costCategory'));
        }

        public function edit(CostCategory $costCategory)
        {
            Gate::authorize('tenant.accounting.cost-category.update');

            return view('accounting::cost-category.edit', compact('costCategory'));
        }

        public function update(CostCategoryRequest $request, CostCategory $costCategory)
        {
            Gate::authorize('tenant.accounting.cost-category.update');

            DB::beginTransaction();
            try {
                $costCategory->update($request->validated());

                activityLog($costCategory, 'Updated', [
                    'message'      => 'Cost Category updated: ' . $costCategory->name,
                    'code'         => $costCategory->code,
                    'name'         => $costCategory->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-categories'])
                    ->with('success', 'Cost Category updated successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to update Cost Category', [
                    'id'    => $costCategory->id,
                    'error' => $e->getMessage(),
                ]);

                return back()->withInput()->with('error', 'Failed to update Cost Category: ' . $e->getMessage());
            }
        }

        public function destroy(CostCategory $costCategory)
        {
            Gate::authorize('tenant.accounting.cost-category.delete');

            DB::beginTransaction();
            try {
                $costCategory->is_active = false;
                $costCategory->save();
                $costCategory->delete();

                activityLog($costCategory, 'Trashed', [
                    'message'      => 'Cost Category trashed: ' . $costCategory->name,
                    'code'         => $costCategory->code,
                    'name'         => $costCategory->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-categories'])
                    ->with('success', 'Cost Category moved to trash.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to trash Cost Category', [
                    'id'    => $costCategory->id,
                    'error' => $e->getMessage(),
                ]);

                return back()->with('error', 'Failed to delete Cost Category: ' . $e->getMessage());
            }
        }

        public function toggleStatus(Request $request, CostCategory $costCategory)
        {
            Gate::authorize('tenant.accounting.cost-category.update');

            $request->validate(['is_active' => 'required|boolean']);

            DB::beginTransaction();
            try {
                $costCategory->is_active = $request->input('is_active');
                $costCategory->save();

                activityLog($costCategory, 'Toggled', [
                    'message'      => 'Cost Category status toggled: ' . $costCategory->name,
                    'code'         => $costCategory->code,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return response()->json(['success' => true, 'is_active' => $costCategory->is_active, 'message' => 'Status updated.']);
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to toggle Cost Category status', ['id' => $costCategory->id, 'error' => $e->getMessage()]);

                return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
            }
        }

        public function reorder(Request $request)
        {
            Gate::authorize('tenant.accounting.cost-category.update');

            $request->validate(['ids' => 'required|array']);

            DB::beginTransaction();
            try {
                $ids = $request->input('ids');
                foreach ($ids as $ordinal => $id) {
                    CostCategory::where('id', $id)->update(['ordinal' => $ordinal + 1]);
                }

                DB::commit();

                return response()->json(['success' => true, 'message' => 'Order updated.']);
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to reorder Cost Categories', ['error' => $e->getMessage()]);

                return response()->json(['success' => false, 'message' => 'Failed to reorder: ' . $e->getMessage()], 500);
            }
        }

        public function trashed(): \Illuminate\View\View
        {
            Gate::authorize('tenant.accounting.cost-category.restore');

            $costCategories = CostCategory::onlyTrashed()->orderBy('name')->paginate(15);

            return view('accounting::cost-category.trash', compact('costCategories'));
        }

        public function restore($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.cost-category.restore');

            DB::beginTransaction();
            try {
                $model = CostCategory::onlyTrashed()->findOrFail($id);
                $model->restore();
                $model->update(['is_active' => true]);

                activityLog($model, 'Restored', [
                    'message'      => 'Cost Category restored: ' . $model->name,
                    'name'         => $model->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.cost-category.trashed')->with('success', 'Cost Category restored successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to restore Cost Category', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to restore Cost Category: ' . $e->getMessage());
            }
        }

        public function forceDelete($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.cost-category.forceDelete');

            DB::beginTransaction();
            try {
                $model = CostCategory::withTrashed()->findOrFail($id);
                $name = $model->name;
                $model->forceDelete();

                activityLog($model, 'Deleted', [
                    'message'      => 'Cost Category permanently deleted: ' . $name,
                    'name'         => $name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.cost-category.trashed')->with('success', 'Cost Category permanently deleted.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to force delete Cost Category', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to delete Cost Category: ' . $e->getMessage());
            }
        }
    }
    ```
  - **After** (replaces the whole file, `CostCategoryController.php:1-208`; this content is `php -l` clean and Pint clean):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Accounting\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\Accounting\Http\Requests\CostCategoryRequest;
    use Modules\Accounting\Models\CostCategory;

    class CostCategoryController extends Controller
    {
        public function index(): RedirectResponse
        {
            Gate::authorize('tenant.accounting.cost-category.viewAny');

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-categories']);
        }

        public function create(): View
        {
            Gate::authorize('tenant.accounting.cost-category.create');

            return view('accounting::cost-category.create');
        }

        public function store(CostCategoryRequest $request): RedirectResponse
        {
            $validated = $request->validated();

            DB::transaction(function () use ($validated) {
                if (! array_key_exists('ordinal', $validated) || $validated['ordinal'] === null) {
                    $validated['ordinal'] = (int) CostCategory::lockForUpdate()->max('ordinal') + 1;
                }

                $costCategory = CostCategory::create($validated);

                activityLog($costCategory, 'Created', [
                    'message' => 'Cost Category created: '.$costCategory->name,
                    'code' => $costCategory->code,
                    'name' => $costCategory->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-categories'])
                ->with('success', 'Cost Category created successfully.');
        }

        public function show(CostCategory $costCategory): View
        {
            Gate::authorize('tenant.accounting.cost-category.view');

            return view('accounting::cost-category.show', compact('costCategory'));
        }

        public function edit(CostCategory $costCategory): View
        {
            Gate::authorize('tenant.accounting.cost-category.update');

            return view('accounting::cost-category.edit', compact('costCategory'));
        }

        public function update(CostCategoryRequest $request, CostCategory $costCategory): RedirectResponse
        {
            $validated = $request->validated();

            if (array_key_exists('ordinal', $validated) && $validated['ordinal'] === null) {
                $validated['ordinal'] = $costCategory->ordinal;
            }

            DB::transaction(function () use ($validated, $costCategory) {
                $costCategory->update($validated);

                activityLog($costCategory, 'Updated', [
                    'message' => 'Cost Category updated: '.$costCategory->name,
                    'code' => $costCategory->code,
                    'name' => $costCategory->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-categories'])
                ->with('success', 'Cost Category updated successfully.');
        }

        public function destroy(CostCategory $costCategory): RedirectResponse
        {
            Gate::authorize('tenant.accounting.cost-category.delete');

            DB::transaction(function () use ($costCategory) {
                $costCategory->is_active = false;
                $costCategory->save();
                $costCategory->delete();

                activityLog($costCategory, 'Trashed', [
                    'message' => 'Cost Category trashed: '.$costCategory->name,
                    'code' => $costCategory->code,
                    'name' => $costCategory->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-categories'])
                ->with('success', 'Cost Category moved to trash.');
        }

        public function toggleStatus(Request $request, CostCategory $costCategory): JsonResponse
        {
            Gate::authorize('tenant.accounting.cost-category.update');

            $validated = $request->validate(['is_active' => 'required|boolean']);

            DB::transaction(function () use ($validated, $costCategory) {
                $costCategory->is_active = (bool) $validated['is_active'];
                $costCategory->save();

                activityLog($costCategory, 'Toggled', [
                    'message' => 'Cost Category status toggled: '.$costCategory->name,
                    'code' => $costCategory->code,
                    'performed_by' => auth()->id(),
                ]);
            });

            return response()->json(['success' => true, 'is_active' => $costCategory->is_active, 'message' => 'Status updated.']);
        }

        public function reorder(Request $request): JsonResponse
        {
            Gate::authorize('tenant.accounting.cost-category.update');

            $validated = $request->validate([
                'ids' => ['required', 'array'],
                'ids.*' => ['required', 'integer', 'exists:acc_cost_categories,id'],
            ]);

            $ids = array_values($validated['ids']);

            DB::transaction(function () use ($ids) {
                foreach ($ids as $ordinal => $id) {
                    CostCategory::where('id', $id)->update(['ordinal' => $ordinal + 1]);
                }

                activityLog(CostCategory::withTrashed()->find($ids[0]), 'Reordered', [
                    'message' => 'Cost Categories reordered',
                    'ids' => $ids,
                    'performed_by' => auth()->id(),
                ]);
            });

            return response()->json(['success' => true, 'message' => 'Order updated.']);
        }

        public function trashed(): View
        {
            Gate::authorize('tenant.accounting.cost-category.restore');

            $costCategories = CostCategory::onlyTrashed()->orderBy('name')->paginate(15);

            return view('accounting::cost-category.trash', compact('costCategories'));
        }

        public function restore($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.cost-category.restore');

            $model = CostCategory::onlyTrashed()->findOrFail($id);

            DB::transaction(function () use ($model) {
                $model->restore();
                $model->update(['is_active' => true]);

                activityLog($model, 'Restored', [
                    'message' => 'Cost Category restored: '.$model->name,
                    'name' => $model->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.cost-category.trashed')->with('success', 'Cost Category restored successfully.');
        }

        public function forceDelete($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.cost-category.forceDelete');

            $model = CostCategory::withTrashed()->findOrFail($id);
            $name = $model->name;

            DB::transaction(function () use ($model, $name) {
                $model->forceDelete();

                activityLog($model, 'Deleted', [
                    'message' => 'Cost Category permanently deleted: '.$name,
                    'name' => $name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.cost-category.trashed')->with('success', 'Cost Category permanently deleted.');
        }
    }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "catch|getMessage|beginTransaction|Log::error"`
  - **Expect:** no output (zero matches).
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None. The two FormRequest items in §5 are independent of each other and of §1.

## 3. Errors & transactions (F1/F2)

Covered by CSCA-01 in §1: the `try/catch` blocks, the message-string logging, the hand-rolled `beginTransaction`/`commit`/`rollBack` calls and the missing reorder audit all disappear in the rewrite.

## 4. Authorization (F3)

Covered by CSCA-01 in §1: the duplicate `Gate::authorize()` calls in `store()` and `update()` are removed; `CostCategoryRequest::authorize()` already checks `tenant.accounting.cost-category` by CRUD permission.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **CSCA-08** · H · VAL-04 — make the unique rules include trashed rows, matching the database indexes.
  - **Touches:** `Modules/Accounting/app/Http/Requests/CostCategoryRequest.php`
  - **Before** (`CostCategoryRequest.php:25-26`):
    ```php
                'code'           => ['required', 'string', 'max:20', Rule::unique('acc_cost_categories', 'code')->ignore($id)->whereNull('deleted_at')],
                'name'           => ['required', 'string', 'max:100', Rule::unique('acc_cost_categories', 'name')->ignore($id)->whereNull('deleted_at')],
    ```
  - **After:**
    ```php
                'code' => ['required', 'string', 'max:20', Rule::unique('acc_cost_categories', 'code')->ignore($id)],
                'name' => ['required', 'string', 'max:100', Rule::unique('acc_cost_categories', 'name')->ignore($id)],
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\CostCategoryRequest.php" -Pattern "whereNull"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CSCA-09** · H · VAL-03 — an absent checkbox must mean unchecked, not `true`.
  - **Touches:** `Modules/Accounting/app/Http/Requests/CostCategoryRequest.php`
  - **Before** (`CostCategoryRequest.php:49-53`):
    ```php
            $mergeData = [
                'is_mandatory'   => $this->boolean('is_mandatory', false),
                'allow_multiple' => $this->boolean('allow_multiple', true),
                'is_active'      => $this->boolean('is_active', true),
            ];
    ```
  - **After:**
    ```php
            $mergeData = [
                'is_mandatory' => $this->boolean('is_mandatory', false),
                'allow_multiple' => $this->boolean('allow_multiple', false),
                'is_active' => $this->boolean('is_active', false),
            ];
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\CostCategoryRequest.php" -Pattern "boolean\('allow_multiple', true\)|boolean\('is_active', true\)"`
  - **Expect:** no output. The create form's `Active` switch is checked and submits `1`, so it still saves active.
  - **Effort:** S

Routes are handled by the CSCA-11 decision in §9. The model is only reformatted by CSCA-16c in §8.

## 6. Queries & performance (F9)

None. CSCA-14 (one `UPDATE` per reordered row) is accepted while the table has 6 live rows; see §10.

## 7. Views (F10)

None. CSCA-15 (orphaned `cost-category/index.blade.php`) is a dead-file cleanup, not a controller fix; see §10.

## 8. Style (F12) — one item per file

- [ ] **CSCA-16a** · L · STY-02 — make the controller Pint clean.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CostCategoryController.php`
  - **Before** (`CostCategoryController.php:7-13`) — the file fails with `["fully_qualified_strict_types","concat_space","ordered_imports","binary_operator_spaces"]`:
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Accounting\Http\Requests\CostCategoryRequest;
    use Modules\Accounting\Models\CostCategory;
    ```
    If CSCA-01 is ticked, its After already includes `JsonResponse`, `RedirectResponse` and `View` imports, concatenation without spaces and the Pint import order, so this item becomes a no-op.
  - **After:** run `php vendor\bin\pint "Modules\Accounting\app\Http\Controllers\CostCategoryController.php"`; the formatter rewrites the file in place.
  - **Verify:** `php vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"passed"}`
  - **Effort:** S

- [ ] **CSCA-16b** · L · STY-02 — make the FormRequest Pint clean.
  - **Touches:** `Modules/Accounting/app/Http/Requests/CostCategoryRequest.php`
  - **Before** (`CostCategoryRequest.php:7-9`) — the file fails with `["ordered_imports","binary_operator_spaces"]`; the array arrows are also column-aligned in `rules()`, `attributes()` and `prepareForValidation()`:
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Validation\Rule;
    ```
  - **After:** run `php vendor\bin\pint "Modules\Accounting\app\Http\Requests\CostCategoryRequest.php"`; the formatter rewrites the file in place.
  - **Verify:** `php vendor\bin\pint --test "Modules\Accounting\app\Http\Requests\CostCategoryRequest.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"passed"}`
  - **Effort:** S

- [ ] **CSCA-16c** · L · STY-02 — make the model Pint clean and drop the unused import.
  - **Touches:** `Modules/Accounting/app/Models/CostCategory.php`
  - **Before** (`CostCategory.php:7-9`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    ```
  - **After:**
    ```php
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Verify:** `php vendor\bin\pint --test "Modules/Accounting/app/Models/CostCategory.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"passed"}`
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **CSCA-11** · H · DECISION · RTE-01 · ⚠ SHARED — restoring a category changes state over GET.
  - **Why it is a decision:** the fix changes a route verb in the shared `Modules/Accounting/routes/web.php`. The shared `x-backend.table.action-trashed` component is used by 475 call sites and already reads the route verb at runtime (it renders a `@csrf` POST form when the verb is not GET), so no component edit is needed.
  - **Touches:** `Modules/Accounting/routes/web.php` (⚠ SHARED) and `Modules/Accounting/app/Http/Controllers/CostCategoryController.php` for options (a) and (b); nothing for option (c).
  - (a) ⭐ POST restore plus route-model binding: change line 389 to `Route::post('/cost-category/{cost_category}/restore', [CostCategoryController::class, 'restore'])->withTrashed()->name('cost-category.restore');`, then change `restore()` and `forceDelete()` to take `CostCategory $costCategory` (both routes `->withTrashed()`), add `abort_unless($costCategory->trashed(), 404);` in `restore()`, and use `$costCategory->restore()`. Resolves CSCA-11 and CSCA-12. Touches `Modules/Accounting/routes/web.php` (⚠ SHARED) and the controller; apply after CSCA-01 if both are ticked.
  - (b) POST restore only: change the same route line to `Route::post('/cost-category/{id}/restore', [CostCategoryController::class, 'restore'])->name('cost-category.restore');`, keep `{id}` and `findOrFail`. Resolves CSCA-11; CSCA-12 remains open.
  - (c) Accept RTE-01: restore stays a GET; record as accepted. CSCA-12 remains open.
  - ➜ Choice: ____

- [ ] **CSCA-18** · M · DECISION · F13-Q1 — a referenced category can be trashed, or force-deleted into a raw foreign-key error.
  - **Why it is a decision:** it changes what the user is allowed to do and what the screen says; no migration is needed.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CostCategoryController.php` for options (a) and (b); nothing for option (c).
  - (a) ⭐ Block the action when references exist: in `destroy()` and `forceDelete()`, count rows in `acc_cost_centers` (via `costCenters()`), `acc_voucher_item_cost_centers` (via `voucherItemCostCenters()`) and `acc_expense_claim_lines` (by table), and return `back()->with('error', 'This cost category is used by N cost centers / N voucher lines / N expense-claim lines and cannot be trashed or deleted.')` before any write. Touches the controller only.
  - (b) Cascade the soft delete to the child rows; the children still point at a hidden category. Not recommended: it hides reference data from reports.
  - (c) Accept the current behaviour: trashing hides the category from pickers, force-delete returns the database `RESTRICT` error (through CSCA-01 it becomes a 500 page, not SQL text). Record CSCA-18 as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CSCA-02 | No separate item — the lookup moves above the transaction inside CSCA-01, so a missing trash row 404s instead of redirecting. |
| CSCA-03 | No separate item — CSCA-01 removes the `catch` and the `Log::error` message string; the framework's exception handler records the exception. |
| CSCA-04 | No separate item — CSCA-01 replaces all seven hand-rolled transactions with `DB::transaction()`. |
| CSCA-05 | No separate item — CSCA-01 adds the `Reordered` audit event inside the reorder transaction. |
| CSCA-06 | No separate item — CSCA-01 computes the next ordinal with `lockForUpdate()->max('ordinal')` inside the transaction. |
| CSCA-07 | No separate item — CSCA-01 removes the duplicate `Gate::authorize()` calls from `store()` and `update()`. |
| CSCA-10 | No separate item — CSCA-01 validates `ids.*` as `required|integer|exists:acc_cost_categories,id`. |
| CSCA-12 | No separate item — resolved only if CSCA-11 choice (a) is taken; choices (b) and (c) leave it open. |
| CSCA-13 | No separate item — CSCA-01 adds return types to the nine methods that lack them. |
| CSCA-14 | Accepted: one `UPDATE` per dragged row at 6 live rows; revisit when the table grows. A bulk upsert is not viable because the table's `code` column has no default. |
| CSCA-15 | Accepted: `cost-category/index.blade.php` is orphaned; delete it in a separate dead-file cleanup pass. |
| CSCA-17 | No separate item — CSCA-01 makes `store()` honour a supplied ordinal and only compute `max + 1` when the field is absent or empty. |
| CSCA-19 | No separate item — CSCA-01 makes `update()` keep the current ordinal when the submitted value is null. |
