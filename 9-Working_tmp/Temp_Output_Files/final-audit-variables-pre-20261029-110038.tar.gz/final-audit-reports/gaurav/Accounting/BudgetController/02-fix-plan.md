# Fix Plan — Accounting / BudgetController

**From:** `01-report.md` (2026-10-24) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/BudgetController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | Shared route file. BDGT-08 is a decision and needs its own tick; no route change is applied here without it. |
| `config/permissionslist.php` | Shared permission catalogue. This plan adds no permission key. |
| `database/migrations/tenant/*` | Existing migrations are immutable. BDGT-03 and BDGT-06 options (b) need a new additive migration written by Tarun, not an edit to a shipped migration. |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | Owns the Transactions listing and the Budgets create modal. The `title` search bug and the ten-row list size are cross-cutting notes, not fixes here. |
| `Modules/Accounting/resources/views/pages/partials/transactions/_budgets.blade.php` | Owned by AccDashboardController. The modal's Ledger field is not required; that UI change is out of scope. |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | Shared base model. The `Auth::id() ?? 1` fallback belongs to AccountingStatusMasterController. |
| `Modules/Accounting/app/Models/AccountingPeriod.php` | Owned by AccountingPeriodController. The `forYear()` recursion is not fixed here. |
| `app/Helpers/activityLog.php` | Common helper (§4.2), not audited. |
| `app/Traits/AuthorizesTenantFeature.php` | Common trait (§4.2), not audited. |
| `resources/views/components/backend/**` | Shared Blade components. BDGT-08 depends on `action-trashed` and needs its own explicit tick. |

## 1. Blockers reachable today

- [ ] **BDGT-01** · B · ERR-01 · `Modules/Accounting/app/Http/Controllers/BudgetController.php:59-139` — remove the six `try`/`catch (\Throwable)` blocks so raw SQL and exception text can never reach the user. This also closes BDGT-02.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BudgetController.php`
  - **Before** (`BudgetController.php:11-13`):
    ```php
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    ```
  - **Before** (`BudgetController.php:59-139`, `store()`):
    ```php
        public function store(BudgetRequest $request): RedirectResponse
        {
            Gate::authorize('tenant.accounting.budget.create');

            $validated = $request->validated();
            $validated['created_by'] = auth()->id();

            try {
                $budgetLine = DB::transaction(function () use ($validated) {
                    $financialYear = FinancialYear::find($validated['financial_year_id']);
                    $budgetType    = $validated['budget_type'] ?? 'Original';
                    $supersedesId  = $validated['supersedes_budget_id'] ?? null;
                    $revisionReason = $validated['revision_reason'] ?? null;
                    $version       = 1;

                    if ($supersedesId) {
                        $budgetType = 'Revised';
                        $supersededBudget = Budget::find($supersedesId);
                        if ($supersededBudget) {
                            $version = $supersededBudget->version + 1;
                        }
                    }

                    $header = Budget::firstOrCreate(
                        [
                            'financial_year_id' => $validated['financial_year_id'],
                            'budget_type'       => $budgetType,
                            'version'           => $version,
                        ],
                        [
                            'code'                 => 'BUD-' . $validated['financial_year_id'] . ($version > 1 ? '-V' . $version : ''),
                            'name'                 => 'Budget ' . ($financialYear?->name ?? (string) $validated['financial_year_id']) . ($version > 1 ? " (Rev v{$version})" : ''),
                            'supersedes_budget_id' => $supersedesId,
                            'revision_reason'      => $revisionReason,
                            'status'               => 'Active',
                            'breach_action'        => $validated['breach_action'] ?? 'Warn',
                            'breach_tolerance_pct' => $validated['breach_tolerance_pct'] ?? 0.0000,
                            'is_active'            => true,
                            'created_by'           => $validated['created_by'],
                        ]
                    );

                    if ($supersedesId && (! $header->supersedes_budget_id || ! $header->revision_reason)) {
                        $header->update([
                            'supersedes_budget_id' => $supersedesId,
                            'revision_reason'      => $revisionReason,
                        ]);
                    }

                    $line = BudgetLine::updateOrCreate(
                        [
                            'budget_id'        => $header->id,
                            'ledger_id'        => $validated['ledger_id'] ?? null,
                            'account_group_id' => $validated['account_group_id'] ?? null,
                            'cost_center_id'   => $validated['cost_center_id'] ?? null,
                            'fund_id'          => $validated['fund_id'] ?? null,
                            'campus_id'        => $validated['campus_id'] ?? null,
                            'period_id'        => $validated['period_id'] ?? null,
                        ],
                        [
                            'budgeted_amount' => $validated['budgeted_amount'],
                            'notes'           => $validated['notes'] ?? null,
                            'is_active'       => $validated['is_active'] ?? true,
                        ]
                    );

                    activityLog($header, 'Created', [
                        'message' => 'Budget allocated for ledger ' . ($validated['ledger_id'] ?? 'N/A'),
                        'name'    => $header->name,
                    ]);

                    return $line;
                });
            } catch (\Throwable $e) {
                Log::error('Budget create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
                return back()->with('error', 'Failed to create budget: ' . $e->getMessage())->withInput();
            }

            return redirect()->route('accounting.menu.transactions', ['tab' => 'budgets'])
                ->with('success', 'Budget created successfully.');
        }
    ```
  - **After:**
    ```php
        public function store(BudgetRequest $request): RedirectResponse
        {
            Gate::authorize('tenant.accounting.budget.create');

            $validated = $request->validated();
            $validated['created_by'] = auth()->id();

            $budgetLine = DB::transaction(function () use ($validated) {
                $financialYear = FinancialYear::find($validated['financial_year_id']);
                $budgetType    = $validated['budget_type'] ?? 'Original';
                $supersedesId  = $validated['supersedes_budget_id'] ?? null;
                $revisionReason = $validated['revision_reason'] ?? null;
                $version       = 1;

                if ($supersedesId) {
                    $budgetType = 'Revised';
                    $supersededBudget = Budget::find($supersedesId);
                    if ($supersededBudget) {
                        $version = $supersededBudget->version + 1;
                    }
                }

                $header = Budget::firstOrCreate(
                    [
                        'financial_year_id' => $validated['financial_year_id'],
                        'budget_type'       => $budgetType,
                        'version'           => $version,
                    ],
                    [
                        'code'                 => 'BUD-' . $validated['financial_year_id'] . ($version > 1 ? '-V' . $version : ''),
                        'name'                 => 'Budget ' . ($financialYear?->name ?? (string) $validated['financial_year_id']) . ($version > 1 ? " (Rev v{$version})" : ''),
                        'supersedes_budget_id' => $supersedesId,
                        'revision_reason'      => $revisionReason,
                        'status'               => 'Active',
                        'breach_action'        => $validated['breach_action'] ?? 'Warn',
                        'breach_tolerance_pct' => $validated['breach_tolerance_pct'] ?? 0.0000,
                        'is_active'            => true,
                        'created_by'           => $validated['created_by'],
                    ]
                );

                if ($supersedesId && (! $header->supersedes_budget_id || ! $header->revision_reason)) {
                    $header->update([
                        'supersedes_budget_id' => $supersedesId,
                        'revision_reason'      => $revisionReason,
                    ]);
                }

                $line = BudgetLine::updateOrCreate(
                    [
                        'budget_id'        => $header->id,
                        'ledger_id'        => $validated['ledger_id'] ?? null,
                        'account_group_id' => $validated['account_group_id'] ?? null,
                        'cost_center_id'   => $validated['cost_center_id'] ?? null,
                        'fund_id'          => $validated['fund_id'] ?? null,
                        'campus_id'        => $validated['campus_id'] ?? null,
                        'period_id'        => $validated['period_id'] ?? null,
                    ],
                    [
                        'budgeted_amount' => $validated['budgeted_amount'],
                        'notes'           => $validated['notes'] ?? null,
                        'is_active'       => $validated['is_active'] ?? true,
                    ]
                );

                activityLog($header, 'Created', [
                    'message' => 'Budget allocated for ledger ' . ($validated['ledger_id'] ?? 'N/A'),
                    'name'    => $header->name,
                ]);

                return $line;
            });

            return redirect()->route('accounting.menu.transactions', ['tab' => 'budgets'])
                ->with('success', 'Budget created successfully.');
        }
    ```
  - **Before** (`BudgetController.php:180-260`, `update()`):
    ```php
        public function update(BudgetRequest $request, $id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.budget.update');

            $validated = $request->validated();

            try {
                DB::transaction(function () use ($id, $validated) {
                    $line = BudgetLine::find($id);
                    if ($line) {
                        if (!empty($validated['financial_year_id'])) {
                            $financialYear = FinancialYear::find($validated['financial_year_id']);
                            $budgetType    = $validated['budget_type'] ?? 'Original';
                            $supersedesId  = $validated['supersedes_budget_id'] ?? null;
                            $revisionReason = $validated['revision_reason'] ?? null;
                            $version       = 1;

                            if ($supersedesId) {
                                $budgetType = 'Revised';
                                $supersededBudget = Budget::find($supersedesId);
                                if ($supersededBudget) {
                                    $version = $supersededBudget->version + 1;
                                }
                            }

                            $header = Budget::firstOrCreate(
                                [
                                    'financial_year_id' => $validated['financial_year_id'],
                                    'budget_type'       => $budgetType,
                                    'version'           => $version,
                                ],
                                [
                                    'code'                 => 'BUD-' . $validated['financial_year_id'] . ($version > 1 ? '-V' . $version : ''),
                                    'name'                 => 'Budget ' . ($financialYear?->name ?? (string) $validated['financial_year_id']) . ($version > 1 ? " (Rev v{$version})" : ''),
                                    'supersedes_budget_id' => $supersedesId,
                                    'revision_reason'      => $revisionReason,
                                    'status'               => 'Active',
                                    'breach_action'        => $validated['breach_action'] ?? 'Warn',
                                    'breach_tolerance_pct' => $validated['breach_tolerance_pct'] ?? 0.0000,
                                    'is_active'            => true,
                                    'created_by'           => auth()->id(),
                                ]
                            );

                            if ($supersedesId) {
                                $header->update([
                                    'supersedes_budget_id' => $supersedesId,
                                    'revision_reason'      => $revisionReason,
                                ]);
                            }

                            $line->budget_id = $header->id;
                        }

                        $line->update([
                            'budget_id'        => $line->budget_id,
                            'ledger_id'        => $validated['ledger_id'] ?? null,
                            'account_group_id' => $validated['account_group_id'] ?? null,
                            'cost_center_id'   => $validated['cost_center_id'] ?? null,
                            'fund_id'          => $validated['fund_id'] ?? null,
                            'campus_id'        => $validated['campus_id'] ?? null,
                            'period_id'        => $validated['period_id'] ?? null,
                            'budgeted_amount'  => $validated['budgeted_amount'],
                            'notes'            => $validated['notes'] ?? null,
                            'is_active'        => $validated['is_active'] ?? true,
                        ]);
                        activityLog($line, 'Updated', ['message' => 'Budget line updated.']);
                    } else {
                        $budget = Budget::findOrFail($id);
                        $budget->update($validated);
                        activityLog($budget, 'Updated', ['message' => 'Budget updated.', 'name' => $budget->name]);
                    }
                });
            } catch (\Throwable $e) {
                Log::error('Budget update failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
                return back()->with('error', 'Failed to update budget: ' . $e->getMessage())->withInput();
            }

            return redirect()->route('accounting.menu.transactions', ['tab' => 'budgets'])
                ->with('success', 'Budget updated successfully.');
        }
    ```
  - **After:**
    ```php
        public function update(BudgetRequest $request, $id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.budget.update');

            $validated = $request->validated();

            DB::transaction(function () use ($id, $validated) {
                $line = BudgetLine::find($id);
                if ($line) {
                    if (!empty($validated['financial_year_id'])) {
                        $financialYear = FinancialYear::find($validated['financial_year_id']);
                        $budgetType    = $validated['budget_type'] ?? 'Original';
                        $supersedesId  = $validated['supersedes_budget_id'] ?? null;
                        $revisionReason = $validated['revision_reason'] ?? null;
                        $version       = 1;

                        if ($supersedesId) {
                            $budgetType = 'Revised';
                            $supersededBudget = Budget::find($supersedesId);
                            if ($supersededBudget) {
                                $version = $supersededBudget->version + 1;
                            }
                        }

                        $header = Budget::firstOrCreate(
                            [
                                'financial_year_id' => $validated['financial_year_id'],
                                'budget_type'       => $budgetType,
                                'version'           => $version,
                            ],
                            [
                                'code'                 => 'BUD-' . $validated['financial_year_id'] . ($version > 1 ? '-V' . $version : ''),
                                'name'                 => 'Budget ' . ($financialYear?->name ?? (string) $validated['financial_year_id']) . ($version > 1 ? " (Rev v{$version})" : ''),
                                'supersedes_budget_id' => $supersedesId,
                                'revision_reason'      => $revisionReason,
                                'status'               => 'Active',
                                'breach_action'        => $validated['breach_action'] ?? 'Warn',
                                'breach_tolerance_pct' => $validated['breach_tolerance_pct'] ?? 0.0000,
                                'is_active'            => true,
                                'created_by'           => auth()->id(),
                            ]
                        );

                        if ($supersedesId) {
                            $header->update([
                                'supersedes_budget_id' => $supersedesId,
                                'revision_reason'      => $revisionReason,
                            ]);
                        }

                        $line->budget_id = $header->id;
                    }

                    $line->update([
                        'budget_id'        => $line->budget_id,
                        'ledger_id'        => $validated['ledger_id'] ?? null,
                        'account_group_id' => $validated['account_group_id'] ?? null,
                        'cost_center_id'   => $validated['cost_center_id'] ?? null,
                        'fund_id'          => $validated['fund_id'] ?? null,
                        'campus_id'        => $validated['campus_id'] ?? null,
                        'period_id'        => $validated['period_id'] ?? null,
                        'budgeted_amount'  => $validated['budgeted_amount'],
                        'notes'            => $validated['notes'] ?? null,
                        'is_active'        => $validated['is_active'] ?? true,
                    ]);
                    activityLog($line, 'Updated', ['message' => 'Budget line updated.']);
                } else {
                    $budget = Budget::findOrFail($id);
                    $budget->update($validated);
                    activityLog($budget, 'Updated', ['message' => 'Budget updated.', 'name' => $budget->name]);
                }
            });

            return redirect()->route('accounting.menu.transactions', ['tab' => 'budgets'])
                ->with('success', 'Budget updated successfully.');
        }
    ```
  - **Before** (`BudgetController.php:262-289`, `destroy()`):
    ```php
        public function destroy($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.budget.delete');

            try {
                DB::transaction(function () use ($id) {
                    $line = BudgetLine::find($id);
                    if ($line) {
                        $line->is_active = false;
                        $line->save();
                        $line->delete();
                        activityLog($line, 'Trashed', ['message' => 'Budget line trashed.']);
                    } else {
                        $budget = Budget::findOrFail($id);
                        $budget->is_active = false;
                        $budget->save();
                        $budget->delete();
                        activityLog($budget, 'Trashed', ['message' => 'Budget trashed.', 'name' => $budget->name]);
                    }
                });
            } catch (\Throwable $e) {
                Log::error('Budget delete failed: ' . $e->getMessage());
                return back()->with('error', 'Failed to delete budget: ' . $e->getMessage());
            }

            return redirect()->route('accounting.menu.transactions', ['tab' => 'budgets'])
                ->with('success', 'Budget moved to trash.');
        }
    ```
  - **After:**
    ```php
        public function destroy($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.budget.delete');

            DB::transaction(function () use ($id) {
                $line = BudgetLine::find($id);
                if ($line) {
                    $line->is_active = false;
                    $line->save();
                    $line->delete();
                    activityLog($line, 'Trashed', ['message' => 'Budget line trashed.']);
                } else {
                    $budget = Budget::findOrFail($id);
                    $budget->is_active = false;
                    $budget->save();
                    $budget->delete();
                    activityLog($budget, 'Trashed', ['message' => 'Budget trashed.', 'name' => $budget->name]);
                }
            });

            return redirect()->route('accounting.menu.transactions', ['tab' => 'budgets'])
                ->with('success', 'Budget moved to trash.');
        }
    ```
  - **Before** (`BudgetController.php:291-318`, `toggleStatus()`):
    ```php
        public function toggleStatus(Request $request, $id)
        {
            Gate::authorize('tenant.accounting.budget.update');

            $request->validate(['is_active' => 'required|boolean']);

            try {
                $isActive = $request->boolean('is_active');
                DB::transaction(function () use ($id, $isActive) {
                    $line = BudgetLine::find($id);
                    if ($line) {
                        $line->is_active = $isActive;
                        $line->save();
                        activityLog($line, 'Toggled', ['message' => 'Budget line status toggled.']);
                    } else {
                        $budget = Budget::findOrFail($id);
                        $budget->is_active = $isActive;
                        $budget->save();
                        activityLog($budget, 'Toggled', ['message' => 'Budget status toggled.', 'name' => $budget->name]);
                    }
                });
            } catch (\Throwable $e) {
                Log::error('Budget toggleStatus failed: ' . $e->getMessage());
                return response()->json(['success' => false, 'message' => 'Failed to update status.'], 500);
            }

            return response()->json(['success' => true, 'is_active' => $request->boolean('is_active'), 'message' => 'Status updated.']);
        }
    ```
  - **After:**
    ```php
        public function toggleStatus(Request $request, $id)
        {
            Gate::authorize('tenant.accounting.budget.update');

            $request->validate(['is_active' => 'required|boolean']);

            $isActive = $request->boolean('is_active');
            DB::transaction(function () use ($id, $isActive) {
                $line = BudgetLine::find($id);
                if ($line) {
                    $line->is_active = $isActive;
                    $line->save();
                    activityLog($line, 'Toggled', ['message' => 'Budget line status toggled.']);
                } else {
                    $budget = Budget::findOrFail($id);
                    $budget->is_active = $isActive;
                    $budget->save();
                    activityLog($budget, 'Toggled', ['message' => 'Budget status toggled.', 'name' => $budget->name]);
                }
            });

            return response()->json(['success' => true, 'is_active' => $request->boolean('is_active'), 'message' => 'Status updated.']);
        }
    ```
  - **Before** (`BudgetController.php:332-356`, `restore()`):
    ```php
        public function restore($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.budget.restore');

            try {
                DB::transaction(function () use ($id) {
                    $line = BudgetLine::onlyTrashed()->find($id);
                    if ($line) {
                        $line->restore();
                        $line->update(['is_active' => true]);
                        activityLog($line, 'Restored', ['message' => 'Budget line restored.']);
                    } else {
                        $model = Budget::onlyTrashed()->findOrFail($id);
                        $model->restore();
                        $model->update(['is_active' => true]);
                        activityLog($model, 'Restored', ['message' => 'Budget restored.', 'name' => $model->name]);
                    }
                });
            } catch (\Throwable $e) {
                Log::error('Budget restore failed: ' . $e->getMessage());
                return back()->with('error', 'Failed to restore budget: ' . $e->getMessage());
            }

            return redirect()->route('accounting.budget.trashed')->with('success', 'Budget restored successfully.');
        }
    ```
  - **After:**
    ```php
        public function restore($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.budget.restore');

            DB::transaction(function () use ($id) {
                $line = BudgetLine::onlyTrashed()->find($id);
                if ($line) {
                    $line->restore();
                    $line->update(['is_active' => true]);
                    activityLog($line, 'Restored', ['message' => 'Budget line restored.']);
                } else {
                    $model = Budget::onlyTrashed()->findOrFail($id);
                    $model->restore();
                    $model->update(['is_active' => true]);
                    activityLog($model, 'Restored', ['message' => 'Budget restored.', 'name' => $model->name]);
                }
            });

            return redirect()->route('accounting.budget.trashed')->with('success', 'Budget restored successfully.');
        }
    ```
  - **Before** (`BudgetController.php:358-381`, `forceDelete()`):
    ```php
        public function forceDelete($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.budget.forceDelete');

            try {
                DB::transaction(function () use ($id) {
                    $line = BudgetLine::withTrashed()->find($id);
                    if ($line) {
                        $line->forceDelete();
                        activityLog($line, 'Deleted', ['message' => 'Budget line permanently deleted.']);
                    } else {
                        $model = Budget::withTrashed()->findOrFail($id);
                        $model->forceDelete();
                        activityLog($model, 'Deleted', ['message' => 'Budget permanently deleted.', 'name' => $model->name]);
                    }
                });
            } catch (\Throwable $e) {
                Log::error('Budget forceDelete failed: ' . $e->getMessage());
                return back()->with('error', 'Failed to permanently delete budget: ' . $e->getMessage());
            }

            return redirect()->route('accounting.budget.trashed')->with('success', 'Budget permanently deleted.');
        }
    ```
  - **After:**
    ```php
        public function forceDelete($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.budget.forceDelete');

            DB::transaction(function () use ($id) {
                $line = BudgetLine::withTrashed()->find($id);
                if ($line) {
                    $line->forceDelete();
                    activityLog($line, 'Deleted', ['message' => 'Budget line permanently deleted.']);
                } else {
                    $model = Budget::withTrashed()->findOrFail($id);
                    $model->forceDelete();
                    activityLog($model, 'Deleted', ['message' => 'Budget permanently deleted.', 'name' => $model->name]);
                }
            });

            return redirect()->route('accounting.budget.trashed')->with('success', 'Budget permanently deleted.');
        }
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Controllers/BudgetController.php" -Pattern "catch \(|getMessage|Log::"`
  - **Expect:** no output.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

Nothing in §1 arms a new defect, but §1 removes the catch that currently hides two data-integrity failures. After BDGT-01, the duplicate-key collisions described in BDGT-03 and BDGT-06 become a 500 instead of a red flash with SQL text, so decide those two before exposing the create modal to finance users.

Sequence:

1. Apply §1 first. It rewrites the six write paths in one file.
2. §4 is independent of §1: its Before text still exists after the rewrite.
3. §5 BDGT-10 **Requires BDGT-01**: its Before block is the post-BDGT-01 text, already dedented.
4. §5 BDGT-11 and §9 BDGT-09 are decisions about shape; if BDGT-09 chooses a split, do not apply BDGT-10 until the split is done.
5. §8 runs last because Pint rewrites imports and spacing.

The two-table identity risk is real with the current data: `acc_budgets` has 1 header and `acc_budget_lines` has 9 rows, so low ids overlap. Do not test the header branches with a stray URL before BDGT-09 is decided.

## 3. Errors & transactions (F1/F2)

No items here.

- BDGT-01 is in §1 because it is the only blocker.
- BDGT-02 is closed by the same edit; see §10.
- BDGT-03 is a transaction/identity decision in §9.

## 4. Authorization (F3)

- [ ] **BDGT-04** · L · AUTH-04 · `Modules/Accounting/app/Http/Controllers/BudgetController.php:61,182` — remove the duplicate `Gate::authorize` calls; `BudgetRequest` already authorizes the same permission.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BudgetController.php`
  - **Before** (`BudgetController.php:61-63`, `store()`):
    ```php
            Gate::authorize('tenant.accounting.budget.create');

            $validated = $request->validated();
    ```
  - **After:**
    ```php
            $validated = $request->validated();
    ```
  - **Before** (`BudgetController.php:182-184`, `update()`):
    ```php
            Gate::authorize('tenant.accounting.budget.update');

            $validated = $request->validated();
    ```
  - **After:**
    ```php
            $validated = $request->validated();
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Controllers/BudgetController.php" -Pattern "Gate::authorize\('tenant.accounting.budget.(create|update)'\)"`
  - **Expect:** three matches only: `create` in `create()`, `update` in `edit()`, `update` in `toggleStatus()`; none in `store()` or `update()`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

### Validation (F4)

- [ ] **BDGT-07** · H · VAL-07 · `Modules/Accounting/app/Http/Requests/BudgetRequest.php:24-32` — enforce the DDL's own rules: at least one grouping dimension, a revision reason when superseding, and the same financial year for the superseded budget.
  - **Touches:** `Modules/Accounting/app/Http/Requests/BudgetRequest.php`
  - **Before** (`BudgetRequest.php:7-9`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Validation\Rule;
    ```
  - **After:**
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Illuminate\Validation\Validator;
    ```
  - **Before** (`BudgetRequest.php:31-32`):
    ```php
                'supersedes_budget_id' => 'nullable|exists:acc_budgets,id',
                'revision_reason'      => 'nullable|string|max:1000',
    ```
  - **After:**
    ```php
                'supersedes_budget_id' => [
                    'nullable',
                    Rule::exists('acc_budgets', 'id')->where(
                        fn ($query) => $query->where('financial_year_id', $this->input('financial_year_id'))
                    ),
                ],
                'revision_reason'      => 'nullable|string|max:1000',
    ```
  - **Before** (`BudgetRequest.php:39-41`):
    ```php
        }

        public function attributes(): array
    ```
  - **After:**
    ```php
        }

        public function withValidator(Validator $validator): void
        {
            $validator->after(function (Validator $validator): void {
                $hasDimension = filled($this->input('ledger_id'))
                    || filled($this->input('account_group_id'))
                    || filled($this->input('cost_center_id'))
                    || filled($this->input('fund_id'));

                if (! $hasDimension) {
                    $validator->errors()->add('ledger_id', 'Choose at least one of ledger, account group, cost centre or fund.');
                }

                if ($this->filled('supersedes_budget_id') && blank($this->input('revision_reason'))) {
                    $validator->errors()->add('revision_reason', 'A revision reason is required when superseding a budget.');
                }
            });
        }

        public function attributes(): array
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Requests/BudgetRequest.php" -Pattern "withValidator|Rule::exists|Choose at least one|revision reason is required"`
  - **Expect:** four matching lines: the `withValidator` signature, the `Rule::exists` call, and the two messages.
  - **Effort:** S

### Controller shape (F6)

- [ ] **BDGT-10** · M · CTL-05 · `Modules/Accounting/app/Http/Controllers/BudgetController.php:67-106,187-232` — extract the header/version block copied between `store` and `update` into one private method. **Requires BDGT-01**: the Before blocks below are the post-BDGT-01 text. The helper keeps `store`'s guarded update, so `update` no longer overwrites an existing revised header's reason.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BudgetController.php`
  - **Before** (`store()`, after BDGT-01):
    ```php
                $financialYear = FinancialYear::find($validated['financial_year_id']);
                $budgetType    = $validated['budget_type'] ?? 'Original';
                $supersedesId  = $validated['supersedes_budget_id'] ?? null;
                $revisionReason = $validated['revision_reason'] ?? null;
                $version       = 1;

                if ($supersedesId) {
                    $budgetType = 'Revised';
                    $supersededBudget = Budget::find($supersedesId);
                    if ($supersededBudget) {
                        $version = $supersededBudget->version + 1;
                    }
                }

                $header = Budget::firstOrCreate(
                    [
                        'financial_year_id' => $validated['financial_year_id'],
                        'budget_type'       => $budgetType,
                        'version'           => $version,
                    ],
                    [
                        'code'                 => 'BUD-' . $validated['financial_year_id'] . ($version > 1 ? '-V' . $version : ''),
                        'name'                 => 'Budget ' . ($financialYear?->name ?? (string) $validated['financial_year_id']) . ($version > 1 ? " (Rev v{$version})" : ''),
                        'supersedes_budget_id' => $supersedesId,
                        'revision_reason'      => $revisionReason,
                        'status'               => 'Active',
                        'breach_action'        => $validated['breach_action'] ?? 'Warn',
                        'breach_tolerance_pct' => $validated['breach_tolerance_pct'] ?? 0.0000,
                        'is_active'            => true,
                        'created_by'           => $validated['created_by'],
                    ]
                );

                if ($supersedesId && (! $header->supersedes_budget_id || ! $header->revision_reason)) {
                    $header->update([
                        'supersedes_budget_id' => $supersedesId,
                        'revision_reason'      => $revisionReason,
                    ]);
                }
    ```
  - **After:**
    ```php
                $header = $this->resolveHeader($validated, $validated['created_by']);
    ```
  - **Before** (`update()`, after BDGT-01):
    ```php
                        $financialYear = FinancialYear::find($validated['financial_year_id']);
                        $budgetType    = $validated['budget_type'] ?? 'Original';
                        $supersedesId  = $validated['supersedes_budget_id'] ?? null;
                        $revisionReason = $validated['revision_reason'] ?? null;
                        $version       = 1;

                        if ($supersedesId) {
                            $budgetType = 'Revised';
                            $supersededBudget = Budget::find($supersedesId);
                            if ($supersededBudget) {
                                $version = $supersededBudget->version + 1;
                            }
                        }

                        $header = Budget::firstOrCreate(
                            [
                                'financial_year_id' => $validated['financial_year_id'],
                                'budget_type'       => $budgetType,
                                'version'           => $version,
                            ],
                            [
                                'code'                 => 'BUD-' . $validated['financial_year_id'] . ($version > 1 ? '-V' . $version : ''),
                                'name'                 => 'Budget ' . ($financialYear?->name ?? (string) $validated['financial_year_id']) . ($version > 1 ? " (Rev v{$version})" : ''),
                                'supersedes_budget_id' => $supersedesId,
                                'revision_reason'      => $revisionReason,
                                'status'               => 'Active',
                                'breach_action'        => $validated['breach_action'] ?? 'Warn',
                                'breach_tolerance_pct' => $validated['breach_tolerance_pct'] ?? 0.0000,
                                'is_active'            => true,
                                'created_by'           => auth()->id(),
                            ]
                        );

                        if ($supersedesId) {
                            $header->update([
                                'supersedes_budget_id' => $supersedesId,
                                'revision_reason'      => $revisionReason,
                            ]);
                        }
    ```
  - **After:**
    ```php
                        $header = $this->resolveHeader($validated, auth()->id());
    ```
  - **Before** (`BudgetController.php:379-381`, end of file after BDGT-01):
    ```php
            return redirect()->route('accounting.budget.trashed')->with('success', 'Budget permanently deleted.');
        }
    }
    ```
  - **After:**
    ```php
            return redirect()->route('accounting.budget.trashed')->with('success', 'Budget permanently deleted.');
        }

        private function resolveHeader(array $validated, ?int $createdBy): Budget
        {
            $financialYear  = FinancialYear::find($validated['financial_year_id']);
            $budgetType     = $validated['budget_type'] ?? 'Original';
            $supersedesId   = $validated['supersedes_budget_id'] ?? null;
            $revisionReason = $validated['revision_reason'] ?? null;
            $version        = 1;

            if ($supersedesId) {
                $budgetType = 'Revised';
                $supersededBudget = Budget::find($supersedesId);

                if ($supersededBudget) {
                    $version = $supersededBudget->version + 1;
                }
            }

            $header = Budget::firstOrCreate(
                [
                    'financial_year_id' => $validated['financial_year_id'],
                    'budget_type'       => $budgetType,
                    'version'           => $version,
                ],
                [
                    'code'                 => 'BUD-' . $validated['financial_year_id'] . ($version > 1 ? '-V' . $version : ''),
                    'name'                 => 'Budget ' . ($financialYear?->name ?? (string) $validated['financial_year_id']) . ($version > 1 ? " (Rev v{$version})" : ''),
                    'supersedes_budget_id' => $supersedesId,
                    'revision_reason'      => $revisionReason,
                    'status'               => 'Active',
                    'breach_action'        => $validated['breach_action'] ?? 'Warn',
                    'breach_tolerance_pct' => $validated['breach_tolerance_pct'] ?? 0.0000,
                    'is_active'            => true,
                    'created_by'           => $createdBy,
                ]
            );

            if ($supersedesId && (! $header->supersedes_budget_id || ! $header->revision_reason)) {
                $header->update([
                    'supersedes_budget_id' => $supersedesId,
                    'revision_reason'      => $revisionReason,
                ]);
            }

            return $header;
        }
    }
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Controllers/BudgetController.php" -Pattern "firstOrCreate|resolveHeader"`
  - **Expect:** four matches: one `firstOrCreate` inside `resolveHeader`, one method declaration, and two calls.
  - **Effort:** M

- [ ] **BDGT-13** · L · CTL-04 · `Modules/Accounting/app/Http/Controllers/BudgetController.php:27,291` — add the missing public return types.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BudgetController.php`
  - **Before** (`BudgetController.php:8-9`):
    ```php
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    ```
  - **After:**
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    ```
  - **Before** (`BudgetController.php:27`):
    ```php
        public function index()
    ```
  - **After:**
    ```php
        public function index(): RedirectResponse
    ```
  - **Before** (`BudgetController.php:291`):
    ```php
        public function toggleStatus(Request $request, $id)
    ```
  - **After:**
    ```php
        public function toggleStatus(Request $request, $id): JsonResponse
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Controllers/BudgetController.php" -Pattern "public function index|public function toggleStatus"`
  - **Expect:** `public function index(): RedirectResponse` and `public function toggleStatus(Request $request, $id): JsonResponse`.
  - **Effort:** S

### Models (F7)

- [ ] **BDGT-15** · M · MDL-01 · `Modules/Accounting/app/Models/Budget.php:17-34` — add `is_active` to `$fillable` so the Active flag is not silently dropped.
  - **Touches:** `Modules/Accounting/app/Models/Budget.php`
  - **Before** (`Budget.php:28-30`):
    ```php
            'status',
            'approved_by',
            'approved_at',
    ```
  - **After:**
    ```php
            'status',
            'is_active',
            'approved_by',
            'approved_at',
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Models/Budget.php" -Pattern "'is_active',"`
  - **Expect:** one match inside `$fillable`.
  - **Effort:** S

- [ ] **BDGT-16** · L · MDL-02 · `Modules/Accounting/app/Models/Budget.php:36-40` — cast `is_active` to boolean.
  - **Touches:** `Modules/Accounting/app/Models/Budget.php`
  - **Before** (`Budget.php:36-40`):
    ```php
        protected $casts = [
            'breach_tolerance_pct' => 'decimal:4',
            'version'              => 'integer',
            'approved_at'          => 'datetime',
        ];
    ```
  - **After:**
    ```php
        protected $casts = [
            'breach_tolerance_pct' => 'decimal:4',
            'version'              => 'integer',
            'is_active'            => 'boolean',
            'approved_at'          => 'datetime',
        ];
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Models/Budget.php" -Pattern "'is_active'\s*=>\s*'boolean'"`
  - **Expect:** one match.
  - **Effort:** S

- [ ] **BDGT-17** · M · CTL-10 · `Modules/Accounting/app/Models/Budget.php:71-74` — delete `scopeByCostCenter`, which filters a column `acc_budgets` does not have.
  - **Touches:** `Modules/Accounting/app/Models/Budget.php`
  - **Before** (`Budget.php:71-76`):
    ```php
        public function scopeByCostCenter($query, int $ccId)
        {
            return $query->where('cost_center_id', $ccId);
        }

        public function scopeActive($query)
    ```
  - **After:**
    ```php
        public function scopeActive($query)
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Models/Budget.php" -Pattern "byCostCenter"`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **BDGT-18** · M · QRY-15 · `Modules/Accounting/app/Http/Controllers/BudgetController.php:41-45,161-165` — select only the columns the dropdowns read instead of every column of every row.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BudgetController.php`
  - **Before** (`BudgetController.php:41-45`, `create()`):
    ```php
            $accountGroups  = AccountGroup::active()->orderBy('name')->get();
            $funds          = Fund::active()->orderBy('name')->get();
            $campuses       = Campus::active()->orderBy('name')->get();
            $periods        = AccountingPeriod::selectableActive();
            $existingBudgets = Budget::orderBy('name')->get();
    ```
  - **After:**
    ```php
            $accountGroups  = AccountGroup::active()->orderBy('name')->get(['id', 'name']);
            $funds          = Fund::active()->orderBy('name')->get(['id', 'name']);
            $campuses       = Campus::active()->orderBy('name')->get(['id', 'name']);
            $periods        = AccountingPeriod::selectableActive();
            $existingBudgets = Budget::orderBy('name')->get(['id', 'name', 'code', 'version']);
    ```
  - **Before** (`BudgetController.php:161-165`, `edit()`):
    ```php
            $accountGroups   = AccountGroup::active()->orderBy('name')->get();
            $funds           = Fund::active()->orderBy('name')->get();
            $campuses        = Campus::active()->orderBy('name')->get();
            $periods         = AccountingPeriod::selectableActive();
            $existingBudgets = Budget::where('id', '!=', $budget->budget_id ?? $budget->id)->orderBy('name')->get();
    ```
  - **After:**
    ```php
            $accountGroups   = AccountGroup::active()->orderBy('name')->get(['id', 'name']);
            $funds           = Fund::active()->orderBy('name')->get(['id', 'name']);
            $campuses        = Campus::active()->orderBy('name')->get(['id', 'name']);
            $periods         = AccountingPeriod::selectableActive();
            $existingBudgets = Budget::where('id', '!=', $budget->budget_id ?? $budget->id)->orderBy('name')->get(['id', 'name', 'code', 'version']);
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Controllers/BudgetController.php" -Pattern "->orderBy\('name'\)->get\(\);"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BDGT-19** · L · QRY-13 · `Modules/Accounting/app/Http/Controllers/BudgetController.php:324-327` — paginate the trash list at ten rows with its own page name and keep the query string.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BudgetController.php`
  - **Before** (`BudgetController.php:324-327`):
    ```php
            $budgets = BudgetLine::onlyTrashed()
                ->with(['budget.financialYear', 'costCenter', 'ledger', 'fund', 'campus', 'accountGroup'])
                ->orderByDesc('deleted_at')
                ->paginate(15);
    ```
  - **After:**
    ```php
            $budgets = BudgetLine::onlyTrashed()
                ->with(['budget.financialYear', 'costCenter', 'ledger', 'fund', 'campus', 'accountGroup'])
                ->orderByDesc('deleted_at')
                ->paginate(10, ['*'], 'bl_page')
                ->withQueryString();
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Controllers/BudgetController.php" -Pattern "paginate\(10, \['\*'\], 'bl_page'\)->withQueryString\(\)"`
  - **Expect:** one match.
  - **Effort:** S

## 7. Views (F10)

No items. F10 is clean; the only view finding, BDGT-14, is a dead file and has no behaviour fix. See §10.

## 8. Style (F12) — one item per file

Run these after §1, §4, §5 and §6. Pint edits imports and spacing, so it must be last. If BDGT-05 option (a) deletes `BudgetPolicy.php`, skip BDGT-24.

- [ ] **BDGT-20** · L · STY-02 · `Modules/Accounting/app/Http/Controllers/BudgetController.php` — make the controller Pint-clean.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BudgetController.php`
  - **Before** (`pint --test`, current output):
    ```json
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\BudgetController.php","fixers":["concat_space","unary_operator_spaces","not_operator_with_successor_space","blank_line_before_statement","binary_operator_spaces"]}]}
    ```
  - **After:** `vendor\bin\pint "Modules/Accounting/app/Http/Controllers/BudgetController.php"`
  - **Verify:** `vendor\bin\pint --test "Modules/Accounting/app/Http/Controllers/BudgetController.php" --format agent`
  - **Expect:** `"result":"pass"` with no files listed.
  - **Effort:** S

- [ ] **BDGT-21** · L · STY-02 · `Modules/Accounting/app/Models/Budget.php` — make the model Pint-clean.
  - **Touches:** `Modules/Accounting/app/Models/Budget.php`
  - **Before** (`pint --test`, current output):
    ```json
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\Budget.php","fixers":["fully_qualified_strict_types","no_unused_imports","ordered_imports","binary_operator_spaces"]}]}
    ```
  - **After:** `vendor\bin\pint "Modules/Accounting/app/Models/Budget.php"`
  - **Verify:** `vendor\bin\pint --test "Modules/Accounting/app/Models/Budget.php" --format agent`
  - **Expect:** `"result":"pass"` with no files listed.
  - **Effort:** S

- [ ] **BDGT-22** · L · STY-02 · `Modules/Accounting/app/Models/BudgetLine.php` — make the model Pint-clean.
  - **Touches:** `Modules/Accounting/app/Models/BudgetLine.php`
  - **Before** (`pint --test`, current output):
    ```json
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\BudgetLine.php","fixers":["no_unused_imports","single_line_after_imports","binary_operator_spaces"]}]}
    ```
  - **After:** `vendor\bin\pint "Modules/Accounting/app/Models/BudgetLine.php"`
  - **Verify:** `vendor\bin\pint --test "Modules/Accounting/app/Models/BudgetLine.php" --format agent`
  - **Expect:** `"result":"pass"` with no files listed.
  - **Effort:** S

- [ ] **BDGT-23** · L · STY-02 · `Modules/Accounting/app/Http/Requests/BudgetRequest.php` — make the request Pint-clean. `Rule` is used by BDGT-07, so Pint fixes only ordering and spacing.
  - **Touches:** `Modules/Accounting/app/Http/Requests/BudgetRequest.php`
  - **Before** (`pint --test`, current output):
    ```json
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\BudgetRequest.php","fixers":["no_unused_imports","ordered_imports","binary_operator_spaces"]}]}
    ```
  - **After:** `vendor\bin\pint "Modules/Accounting/app/Http/Requests/BudgetRequest.php"`
  - **Verify:** `vendor\bin\pint --test "Modules/Accounting/app/Http/Requests/BudgetRequest.php" --format agent`
  - **Expect:** `"result":"pass"` with no files listed.
  - **Effort:** S

- [ ] **BDGT-24** · L · STY-02 · `Modules/Accounting/app/Policies/BudgetPolicy.php` — make the policy Pint-clean.
  - **Touches:** `Modules/Accounting/app/Policies/BudgetPolicy.php`
  - **Before** (`pint --test`, current output):
    ```json
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Policies\\BudgetPolicy.php","fixers":["ordered_imports"]}]}
    ```
  - **After:** `vendor\bin\pint "Modules/Accounting/app/Policies/BudgetPolicy.php"`
  - **Verify:** `vendor\bin\pint --test "Modules/Accounting/app/Policies/BudgetPolicy.php" --format agent`
  - **Expect:** `"result":"pass"` with no files listed.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BDGT-03** · H · DECISION · TXN-06 — the header identity keys do not match the unique index, and the line upsert uses the same nullable dimensions as `uq_acc_bl`, so a second budget either crashes or silently replaces an amount. Which fix?
  - **Why it is a decision:** option (a) changes generated `code` values and turns an upsert into a validation error; option (b) is a DDL migration for Tarun's hand; option (c) accepts silent overwrites.
  - **Touches:** `BudgetController.php` and `BudgetRequest.php` (a); a new additive tenant migration (b).
  - (a) ⭐ Reject a duplicate header/line with a validation error and include `budget_type` in newly generated header codes so `(code, version)` stays unique per type. No schema change; existing rows keep their codes.
  - (b) Add a new additive migration that replaces `uq_acc_budget_code` and `uq_acc_bl` with type-aware and deleted-at-aware keys. Tarun runs it; this plan does not edit an existing migration.
  - (c) Leave the current `firstOrCreate`/`updateOrCreate` behaviour and document that a same-dimension save replaces the amount.
  - ➜ Choice: ____

- [ ] **BDGT-05** · M · DECISION · AUTH-06 — `BudgetPolicy` is dead and the permission literal is repeated in 11 gates. What should own the permission strings?
  - **Why it is a decision:** deleting a file, registering a policy or adding a constants class changes architecture; option (b) needs a provider registration and edits every gate.
  - **Touches:** `BudgetController.php`, `BudgetPolicy.php`, optionally a new permissions class or a service provider.
  - (a) ⭐ Delete `BudgetPolicy.php` and keep the existing string abilities. Smallest change; `Gate::authorize('tenant.accounting.budget.*')` already resolves through the permission gate.
  - (b) Register `BudgetPolicy` with `Gate::policy(Budget::class, BudgetPolicy::class)` and convert the 11 string checks to model abilities.
  - (c) Add a `BudgetPermissions` constants class and keep string gates that reference the constants.
  - ➜ Choice: ____

- [ ] **BDGT-06** · H · DECISION · VAL-04 — a trashed row keeps its unique key, so re-creating the same allocation throws a duplicate-key error. How should a trashed match be handled?
  - **Why it is a decision:** option (a) adds a pre-check and a user-facing choice; option (b) is a DDL migration; option (c) accepts a dead end that only force-delete can clear.
  - **Touches:** `BudgetController.php` and `BudgetRequest.php` (a); a new tenant migration (b).
  - (a) ⭐ Before the line upsert, look up a matching `withTrashed()` line; if found, stop with a validation error that tells the user to restore it from Trash. No schema change.
  - (b) Add a new additive migration that includes a non-null deleted-at marker in `uq_acc_bl` and `uq_acc_budget_code`. Tarun runs it.
  - (c) Leave it; force-delete is the only way to reuse the dimensions.
  - ➜ Choice: ____

- [ ] **BDGT-08** · H · DECISION · RTE-01 · ⚠ SHARED — restore changes state over GET, so a prefetcher or a planted image can restore a trashed budget. Which change?
  - **Why it is a decision:** changing the verb breaks bookmarks and needs the shared `action-trashed` component updated; this item needs its own explicit tick.
  - **Touches:** `Modules/Accounting/routes/web.php`, `Modules/Accounting/app/Http/Controllers/BudgetController.php`, `Modules/Accounting/resources/views/budget/trash.blade.php`, `resources/views/components/backend/**`.
  - (a) ⭐ Change the route to POST, keep the route name, and make the trash action submit a CSRF form; update `action-trashed` only if it still renders an anchor.
  - (b) Change the route to DELETE and update the component with `@method('DELETE')`.
  - (c) Accept the GET restore and record the risk; no code change.
  - ➜ Choice: ____

- [ ] **BDGT-09** · H · DECISION · CTL-03 — one numeric id is resolved against `acc_budget_lines` and `acc_budgets`, so an action can hit the wrong record. Which shape?
  - **Why it is a decision:** option (a) changes route parameters and method signatures and makes header URLs return 404; option (b) is the D3 split and is not applied in this pass.
  - **Touches:** `BudgetController.php`, `Modules/Accounting/routes/web.php` (a and b).
  - (a) ⭐ Make the controller line-only: bind `BudgetLine` on `show`, `edit`, `update`, `destroy`, `toggleStatus`, `restore` and `forceDelete`, drop the `Budget` fallback, rename the custom route parameters from `{id}` to `{budget}`, and keep header creation in `store`/`update`. Header URLs return 404.
  - (b) Split into `BudgetController` for headers and `BudgetLineController` for lines in the D3 split pass; do not apply now.
  - (c) Leave the two-table fallback and document that an id can address either table.
  - ➜ Choice: ____

- [ ] **BDGT-11** · M · DECISION · CTL-06 — version numbering and header creation are business logic inside the controller. Extract now or defer?
  - **Why it is a decision:** a new service class and a controller split are structural; D3 defers god-controller splits.
  - **Touches:** a new `Modules/Accounting/app/Services/BudgetRevisionService.php` (b); `BudgetController.php`.
  - (a) ⭐ Defer the service extraction to the D3 split pass. Apply BDGT-10's private `resolveHeader()` now; the revision rule stays in one place inside this controller.
  - (b) Extract `BudgetRevisionService` now and have `store` and `update` call one method each.
  - (c) Leave the duplicated logic and record it as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BDGT-02 | Closed by BDGT-01. Removing the `try`/`catch` lets `ModelNotFoundException` render as the framework's 404 instead of a redirect or a 500 JSON response. |
| BDGT-12 | Closed by BDGT-01. Both 81-line methods drop below the 80-line limit once the catch blocks are gone. The larger extraction is BDGT-11's decision. |
| BDGT-14 | Dead view only. `budget/index.blade.php` is never rendered because `index()` redirects; deleting it is optional housekeeping, not a behaviour fix. |
