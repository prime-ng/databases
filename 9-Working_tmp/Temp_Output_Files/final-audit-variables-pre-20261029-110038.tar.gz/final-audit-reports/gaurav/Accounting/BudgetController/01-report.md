# Final Audit — Accounting / BudgetController

**Audited:** 2026-10-24 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/BudgetController.php` (381 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/transactions?tab=budgets` (list and create modal, rendered by `AccDashboardController`, not this controller) · `http://test.localhost:8000/accounting/budget/create` (standalone create page) · `http://test.localhost:8000/accounting/budget/{id}/edit` · `http://test.localhost:8000/accounting/budget/{id}` · `http://test.localhost:8000/accounting/budget/trash/view` · `http://test.localhost:8000/accounting/budget/{id}/restore` (GET) · `http://test.localhost:8000/accounting/budget/{id}/force-delete` (DELETE) · `http://test.localhost:8000/accounting/budget/{budget}/toggle-status` (POST) |
| Menu path | Accounting → Transactions → Budgets tab (`glb_menus` has no Budget row; the tab lives inside menu id 90, `accounting.menu.transactions`) |
| Who uses it | Account Manager, Account Staff, Management, School Admin, Super Admin — all seven `tenant.accounting.budget.*` permissions are granted to these five roles in `sys_role_has_permissions_jnt` |
| What a user does here | A finance user records how much money a ledger (or account group / cost centre / fund) may spend in a financial year, optionally for one accounting period. They can revise a budget by pointing it at the budget it supersedes. They can switch an allocation active/inactive, trash it, restore it, or permanently delete it. The list itself is rendered by the Transactions page; this controller handles the write paths and the trash screen. |
| Tables written | `acc_budgets` (header), `acc_budget_lines` (the amount), `sys_activity_logs` (audit row) |
| Tables read | `acc_budgets`, `acc_budget_lines`, `acc_financial_years`, `acc_cost_centers`, `acc_ledgers`, `acc_account_groups`, `acc_funds`, `acc_campuses`, `acc_accounting_periods`, plus the permission tables behind every `Gate::authorize` |
| Live data | Tenant `test.localhost` (`xyz_school_00000000000040008000_202627`): `acc_budgets` 1 row, `acc_budget_lines` 9 rows, 0 trashed lines, 0 trashed headers; `acc_financial_years` 3, `acc_cost_centers` 12, `acc_ledgers` 56, `acc_accounting_periods` 12 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No, this controller is not production-ready. Its single worst finding is BDGT-01: every write path catches `\Throwable` and prints `$e->getMessage()` into the user's red flash, so any duplicate-key or CHECK-constraint failure shows raw SQL and table/column names to a finance user. That leak is not theoretical — two ordinary paths (create a second budget type for the same financial year, or re-create a trashed allocation) throw database exceptions that this controller then displays. The second structural problem is that one numeric `$id` is resolved against two different tables (`acc_budget_lines` first, `acc_budgets` second), so a header id can act on an unrelated line. Fixing the mechanical items is small; fixing the identity/unique-key design needs three decisions before code is safe.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 6 | 7 | 10 | 6 | 24 |

DECISION is a subset of the severity columns: six findings carry a decision item.

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BDGT-01, BDGT-02 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | BDGT-03 | F9 Queries/Perf | BDGT-18, BDGT-19 |
| F3 Authorization | BDGT-04, BDGT-05 | F10 Views | clean |
| F4 Validation | BDGT-06, BDGT-07 | F11 Security/Tenancy | clean |
| F5 Routes | BDGT-08 | F12 Style | BDGT-20, BDGT-21, BDGT-22, BDGT-23, BDGT-24 |
| F6 Controller shape | BDGT-09, BDGT-10, BDGT-11, BDGT-12, BDGT-13, BDGT-14 | F13 Deep read | no new finding — answers in the table below |
| F7 Models | BDGT-15, BDGT-16, BDGT-17 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/BudgetController.php` | controller | 381 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/Budget.php` | model | 80 | this report | ✅ |
| 3 | `Modules/Accounting/app/Models/BudgetLine.php` | model | 84 | this report (not in `00-CLASS-OWNERS.md`) | ✅ |
| 4 | `Modules/Accounting/app/Http/Requests/BudgetRequest.php` | FormRequest | 78 | this report | ✅ |
| 5 | `Modules/Accounting/app/Policies/BudgetPolicy.php` | policy | 36 | this report (not in `00-CLASS-OWNERS.md`) | ✅ |
| 6 | `Modules/Accounting/resources/views/budget/create.blade.php` | blade | 155 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/budget/edit.blade.php` | blade | 291 | this report | ✅ |
| 8 | `Modules/Accounting/resources/views/budget/show.blade.php` | blade | 85 | this report | ✅ |
| 9 | `Modules/Accounting/resources/views/budget/trash.blade.php` | blade | 94 | this report | ✅ |
| 10 | `Modules/Accounting/resources/views/budget/index.blade.php` | blade (dead) | 93 | this report | ✅ |
| 11 | `Modules/Accounting/routes/web.php` | route file | 536 | shared — every controller in the module | ✅ read, not edited |
| 12 | `config/permissionslist.php` | shared config | 1824 | shared app-wide | ✅ read, not edited |
| 13 | `Modules/Accounting/app/Models/FinancialYear.php` | model | — | ↗ [gaurav/Accounting/FinancialYearController](../FinancialYearController/01-report.md) | ↗ linked |
| 14 | `Modules/Accounting/app/Models/AccountingPeriod.php` | model | — | ↗ [gaurav/Accounting/AccountingPeriodController](../AccountingPeriodController/01-report.md) | ↗ linked |
| 15 | `Modules/Accounting/app/Models/Ledger.php` | model | — | ↗ [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) | ↗ linked |
| 16 | `Modules/Accounting/app/Models/AccountGroup.php` | model | — | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 17 | `Modules/Accounting/app/Models/CostCenter.php` | model | — | ↗ [gaurav/Accounting/CostCenterController](../CostCenterController/01-report.md) | ↗ linked |
| 18 | `Modules/Accounting/app/Models/Campus.php` | model | — | ↗ [gaurav/Accounting/CampusController](../CampusController/01-report.md) | ↗ linked |
| 19 | `Modules/Accounting/app/Models/Fund.php` | model | — | ↗ [gaurav/Accounting/FundController](../FundController/01-report.md) | ↗ linked |
| 20 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | base model | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 21 | `Modules/GlobalMaster/app/Models/ActivityLog.php` (via `activityLog()`) | model | — | ↗ [gaurav/Accounting/CostCategoryController](../CostCategoryController/01-report.md) | ↗ linked |
| 22 | `app/Helpers/activityLog.php` | common helper | 51 | common (§4.2) | not audited |
| 23 | `app/Traits/AuthorizesTenantFeature.php` | common trait | 56 | common (§4.2) | not audited |
| 24 | `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | list/create-modal owner | — | not this controller; no report yet | ❌ cross-cutting note only |
| 25 | `resources/views/components/backend/**` | shared components | — | common (§4.2) | not audited |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/budget                                       accounting.budget.index             Modules\Accounting\Http\Controllers\BudgetController@index
POST      accounting/budget                                       accounting.budget.store             Modules\Accounting\Http\Controllers\BudgetController@store
GET|HEAD  accounting/budget/create                                accounting.budget.create            Modules\Accounting\Http\Controllers\BudgetController@create
GET|HEAD  accounting/budget/trash/view                            accounting.budget.trashed           Modules\Accounting\Http\Controllers\BudgetController@trashed
GET|HEAD  accounting/budget/{budget}                              accounting.budget.show              Modules\Accounting\Http\Controllers\BudgetController@show
PUT|PATCH accounting/budget/{budget}                              accounting.budget.update            Modules\Accounting\Http\Controllers\BudgetController@update
DELETE    accounting/budget/{budget}                              accounting.budget.destroy           Modules\Accounting\Http\Controllers\BudgetController@destroy
GET|HEAD  accounting/budget/{budget}/edit                         accounting.budget.edit              Modules\Accounting\Http\Controllers\BudgetController@edit
POST      accounting/budget/{budget}/toggle-status                accounting.budget.toggleStatus      Modules\Accounting\Http\Controllers\BudgetController@toggleStatus
DELETE    accounting/budget/{id}/force-delete                     accounting.budget.forceDelete       Modules\Accounting\Http\Controllers\BudgetController@forceDelete
GET|HEAD  accounting/budget/{id}/restore                          accounting.budget.restore           Modules\Accounting\Http\Controllers\BudgetController@restore
```

Every route carries `web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Accounting`, `auth`, `verified`.

Unrouted public methods: none.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 27 | GET accounting/budget | `tenant.accounting.budget.viewAny` | none | none | none | BDGT-14 |
| `create` | 34 | GET accounting/budget/create | `tenant.accounting.budget.create` | none | none | none | BDGT-18 |
| `store` | 59 | POST accounting/budget | `tenant.accounting.budget.create` (also FormRequest) | controller 67-131 | `Created` (125) | acc_budgets, acc_budget_lines, sys_activity_logs | BDGT-01, BDGT-02, BDGT-03, BDGT-04, BDGT-06, BDGT-07, BDGT-09, BDGT-10, BDGT-11, BDGT-18 |
| `show` | 141 | GET accounting/budget/{budget} | `tenant.accounting.budget.view` | none | none | none | BDGT-09 |
| `edit` | 151 | GET accounting/budget/{budget}/edit | `tenant.accounting.budget.update` | none | none | none | BDGT-09, BDGT-18 |
| `update` | 180 | PUT/PATCH accounting/budget/{budget} | `tenant.accounting.budget.update` (also FormRequest) | controller 187-252 | `Updated` (246, 250) | acc_budgets, acc_budget_lines, sys_activity_logs | BDGT-01, BDGT-02, BDGT-03, BDGT-04, BDGT-06, BDGT-07, BDGT-09, BDGT-10, BDGT-11 |
| `destroy` | 262 | DELETE accounting/budget/{budget} | `tenant.accounting.budget.delete` | controller 267-281 | `Trashed` (273, 279) | acc_budgets or acc_budget_lines, sys_activity_logs | BDGT-01, BDGT-02, BDGT-09 |
| `toggleStatus` | 291 | POST accounting/budget/{budget}/toggle-status | `tenant.accounting.budget.update` | controller 299-311 | `Toggled` (304, 309) | acc_budgets or acc_budget_lines, sys_activity_logs | BDGT-02, BDGT-09, BDGT-13 |
| `trashed` | 320 | GET accounting/budget/trash/view | `tenant.accounting.budget.restore` | none | none | none | BDGT-19 |
| `restore` | 332 | GET accounting/budget/{id}/restore | `tenant.accounting.budget.restore` | controller 337-349 | `Restored` (342, 347) | acc_budgets or acc_budget_lines, sys_activity_logs | BDGT-01, BDGT-02, BDGT-08, BDGT-09 |
| `forceDelete` | 358 | DELETE accounting/budget/{id}/force-delete | `tenant.accounting.budget.forceDelete` | controller 363-373 | `Deleted` (367, 371) | acc_budgets or acc_budget_lines, sys_activity_logs | BDGT-01, BDGT-02, BDGT-09 |

## 6. Findings

### F1 — Errors

#### BDGT-01 · B · ERR-01 — raw SQL and exception text are printed into the user's flash

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:132-135`, `253-256`, `282-285`, `350-353`, `374-377` — methods `store()`, `update()`, `destroy()`, `restore()`, `forceDelete()` |
| **Root cause** | Each mutation wraps the whole transaction in `catch (\Throwable $e)` and interpolates `$e->getMessage()` into the flash. A duplicate key, CHECK-constraint failure or deadlock therefore prints the MySQL message, table name and column name verbatim. |
| **Consequence** | After an ordinary duplicate submit, the finance user sees `Failed to create budget: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry ... for key 'uq_acc_bl'` instead of a sentence they can act on, and the tenant's schema is disclosed. |
| **Reproduce** | In the Budgets tab modal save the same financial year + ledger twice, or leave Ledger/Group/Cost centre/Fund all empty. Expected: a validation message. Actual: a red flash containing the SQL error. |
| **Fix approach** | Remove the six try/catch blocks (D1). `DB::transaction()` already rolls back, and `bootstrap/app.php` logs and renders the failure. One plan item removes all five leaks. |
| **Plan item** | BDGT-01 in `02-fix-plan.md` §1 (also closes BDGT-02) |

```php
// BudgetController.php:132-135 — CURRENT (store; the same shape is at 253, 282, 350, 374)
        } catch (\Throwable $e) {
            Log::error('Budget create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return back()->with('error', 'Failed to create budget: ' . $e->getMessage())->withInput();
        }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "getMessage" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
133:Log::error('Budget create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
134:return back()->with('error', 'Failed to create budget: ' . $e->getMessage())->withInput();
254:Log::error('Budget update failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
255:return back()->with('error', 'Failed to update budget: ' . $e->getMessage())->withInput();
283:Log::error('Budget delete failed: ' . $e->getMessage());
284:return back()->with('error', 'Failed to delete budget: ' . $e->getMessage());
313:Log::error('Budget toggleStatus failed: ' . $e->getMessage());
351:Log::error('Budget restore failed: ' . $e->getMessage());
352:return back()->with('error', 'Failed to restore budget: ' . $e->getMessage());
375:Log::error('Budget forceDelete failed: ' . $e->getMessage());
376:return back()->with('error', 'Failed to permanently delete budget: ' . $e->getMessage());
```

#### BDGT-02 · H · ERR-02 — `findOrFail()` inside the catch turns a 404 into a redirect or a 500 JSON

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* (D1: no controller try/catch) |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:246-256` (`update`), `275-284` (`destroy`), `306-314` (`toggleStatus`), `344-352` (`restore`), `369-377` (`forceDelete`) |
| **Root cause** | `Budget::findOrFail()` sits inside the transaction inside the `try`. The generic `catch (\Throwable)` swallows `ModelNotFoundException` and converts it into a flash/redirect, or in `toggleStatus` into a 500 JSON response. `BudgetRequest` validation also runs on `update` before the try, but the not-found path is still swallowed. |
| **Consequence** | A stale edit link (the row was deleted by another user) shows "Failed to update budget: No query results for model" and is logged as an application error, instead of the 404 the browser and monitoring expect. |
| **Reproduce** | Open `http://test.localhost:8000/accounting/budget/999999/edit`, submit the form. Expected HTTP 404. Actual redirect with a red flash. |
| **Fix approach** | Same change as BDGT-01: delete the try/catch and let the framework render the 404. |
| **Plan item** | none — see `02-fix-plan.md` §10 (closed by the same edit as BDGT-01) |

```php
// BudgetController.php:246-256 — CURRENT
                    activityLog($line, 'Updated', ['message' => 'Budget line updated.']);
                } else {
                    $budget = Budget::findOrFail($id);
                    $budget->update($validated);
                    activityLog($budget, 'Updated', ['message' => 'Budget updated.', 'name' => $budget->name]);
                }
            });
        } catch (\Throwable $e) {
            Log::error('Budget update failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return back()->with('error', 'Failed to update budget: ' . $e->getMessage())->withInput();
        }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "catch \(" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
132:} catch (\Throwable $e) {
253:} catch (\Throwable $e) {
282:} catch (\Throwable $e) {
312:} catch (\Throwable $e) {
350:} catch (\Throwable $e) {
374:} catch (\Throwable $e) {

PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "findOrFail" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
146:?? Budget::with(['financialYear'])->findOrFail($id);
156:?? Budget::with(['financialYear'])->findOrFail($id);
248:$budget = Budget::findOrFail($id);
275:$budget = Budget::findOrFail($id);
306:$budget = Budget::findOrFail($id);
344:$model = Budget::onlyTrashed()->findOrFail($id);
369:$model = Budget::withTrashed()->findOrFail($id);
```

### F2 — Transactions and audit

#### BDGT-03 · H · TXN-06 — the identity keys do not match the unique indexes, so a second budget overwrites a line or crashes

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index that actually covers the operation* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:82-123` (`store`), `205-232` (`update`); `database/migrations/tenant/2026_09_16_100011_create_acc_budgets_table.php:42`; `database/migrations/tenant/2026_09_16_100033_create_acc_budget_lines_table.php:41` |
| **Root cause** | `Budget::firstOrCreate()` identifies a header by `(financial_year_id, budget_type, version)`, but the table's unique key is `(code, version)` and `code` is generated as `BUD-{financial_year_id}` without the type. An Original and a Forecast budget for the same year both ask for `(BUD-1, 1)`; the second insert raises 1062. Separately, `BudgetLine::updateOrCreate()` identifies a line by its seven nullable dimensions, which is exactly `uq_acc_bl`; a second allocation with the same dimensions updates the first row's amount instead of creating a new one. No lock is taken. |
| **Consequence** | "Create Forecast budget for a year that already has an Original" fails with a duplicate-key flash from BDGT-01, and "create the same ledger/cost centre again" silently replaces the earlier amount while the flash says "Budget created successfully." |
| **Reproduce** | (a) Create Original, FY 2026-27, ledger A, ₹100. Then create Forecast, FY 2026-27, ledger B → duplicate-key error. (b) Create FY 2026-27 ledger A ₹100, then FY 2026-27 ledger A ₹200 → the list still shows one row at ₹200. |
| **Fix approach** | Decision required. Recommended: reject an existing (header + dimensions) with a validation error, and include `budget_type` in the generated code so `(code, version)` stays unique per type. The alternative is a migration that aligns the unique keys; that is a DDL change and is not applied here. |
| **Plan item** | BDGT-03 in `02-fix-plan.md` §9 (DECISION) |

```php
// BudgetController.php:82-99 — CURRENT
                $header = Budget::firstOrCreate(
                    [
                        'financial_year_id' => $validated['financial_year_id'],
                        'budget_type'       => $budgetType,
                        'version'           => $version,
                    ],
                    [
                        'code'                 => 'BUD-' . $validated['financial_year_id'] . ($version > 1 ? '-V' . $version : ''),
                        'name'                 => 'Budget ' . ($financialYear?->name ?? (string) $validated['financial_year_id']) . ($version > 1 ? " (Rev v{$version})" : ''),
                        'supersedes_budget_id' => $supersedesId,
                        'revision_reason'      => $revisionReason,
                        'status'               => 'Active',
                        'breach_action'        => $validated['breach_action'] ?? 'Warn',
                        'breach_tolerance_pct' => $validated['breach_tolerance_pct'] ?? 0.0000,
                        'is_active'            => true,
                        'created_by'           => $validated['created_by'],
                    ]
                );
```

**Evidence**
```
PS> Select-String -Path "database\migrations\tenant\2026_09_16_100011_create_acc_budgets_table.php","database\migrations\tenant\2026_09_16_100033_create_acc_budget_lines_table.php" -Pattern "unique\(" | ForEach-Object { "$([System.IO.Path]::GetFileName($_.Path)):$($_.LineNumber):$($_.Line.Trim())" }
2026_09_16_100033_create_acc_budget_lines_table.php:41:$table->unique(['budget_id', 'ledger_marker', 'group_marker', 'cc_marker', 'fund_marker', 'campus_marker', 'period_marker'], 'uq_acc_bl');
2026_09_16_100011_create_acc_budgets_table.php:42:$table->unique(['code', 'version'], 'uq_acc_budget_code');

PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "firstOrCreate|updateOrCreate" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
82:$header = Budget::firstOrCreate(
108:$line = BudgetLine::updateOrCreate(
205:$header = Budget::firstOrCreate(
```

### F3 — Authorization

#### BDGT-04 · L · AUTH-04 — `store` and `update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *do not authorize the same permission twice* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:61`, `182`; `Modules/Accounting/app/Http/Requests/BudgetRequest.php:17` |
| **Root cause** | `BudgetRequest::authorize()` already maps POST→`create` and PUT/PATCH→`update` through `authorizeByCrudPermission('tenant.accounting.budget')`; the controller then repeats the same `Gate::authorize`. |
| **Consequence** | No user-visible effect today, but two authorization surfaces must be kept in sync; a future change to one silently diverges from the other. |
| **Reproduce** | static only — both checks pass or fail together on the current permission set. |
| **Fix approach** | Keep the FormRequest check (it runs first) and remove the two `Gate::authorize` lines in `store`/`update`. |
| **Plan item** | BDGT-04 in `02-fix-plan.md` §4 |

```php
// BudgetController.php:59-63 — CURRENT
    public function store(BudgetRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.accounting.budget.create');

        $validated = $request->validated();
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "Gate::authorize" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
29:Gate::authorize('tenant.accounting.budget.viewAny');
36:Gate::authorize('tenant.accounting.budget.create');
61:Gate::authorize('tenant.accounting.budget.create');
143:Gate::authorize('tenant.accounting.budget.view');
153:Gate::authorize('tenant.accounting.budget.update');
182:Gate::authorize('tenant.accounting.budget.update');
264:Gate::authorize('tenant.accounting.budget.delete');
293:Gate::authorize('tenant.accounting.budget.update');
322:Gate::authorize('tenant.accounting.budget.restore');
334:Gate::authorize('tenant.accounting.budget.restore');
360:Gate::authorize('tenant.accounting.budget.forceDelete');

PS> Select-String -Path "Modules\Accounting\app\Http\Requests\BudgetRequest.php" -Pattern "authorizeByCrudPermission" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
17:return $this->authorizeByCrudPermission('tenant.accounting.budget');
```

#### BDGT-05 · M · AUTH-06 — `BudgetPolicy` is never consulted, and the permission literal is repeated in 11 gates

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy, or constants* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:29`, `36`, `61`, `143`, `153`, `182`, `264`, `293`, `322`, `334`, `360`; `Modules/Accounting/app/Policies/BudgetPolicy.php:1-36` |
| **Root cause** | Nothing registers or consults `BudgetPolicy` (no `Gate::policy`, no `AuthServiceProvider` entry, no model-ability call). Every check is the string ability `tenant.accounting.budget.*`, which Spatie resolves directly; the policy is dead weight and the literals are copy-pasted. |
| **Consequence** | Editing `BudgetPolicy` changes no behaviour, while a typo in one of the 11 literals silently 403s one button and not the rest. |
| **Reproduce** | static only — `BudgetPolicy` greps to zero references outside its own file. |
| **Fix approach** | Decision: wire the policy to `Budget` and call model abilities, introduce a small constants class and keep string gates, or delete the dead policy. Do not mix the three. |
| **Plan item** | BDGT-05 in `02-fix-plan.md` §9 (DECISION) |

```php
// BudgetPolicy.php:1-36 — CURRENT (never reached)
class BudgetPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('tenant.accounting.budget.viewAny');
    }

    public function view(User $user, Budget $budget): bool
    {
        return $user->can('tenant.accounting.budget.view');
    }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\**\*.php","app\**\*.php","config\*.php" -Pattern "BudgetPolicy" -ErrorAction SilentlyContinue | ForEach-Object { "$($_.Path):$($_.LineNumber):$($_.Line.Trim())" }
(no output)

PS> Select-String -Path "config\permissionslist.php" -Pattern "accounting.budget" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
603:'accounting.budget' => $crud,

PS> mysql -uroot xyz_school_00000000000040008000_202627 -e "SELECT p.name, GROUP_CONCAT(r.name ORDER BY r.name SEPARATOR ', ') AS roles FROM sys_permissions p LEFT JOIN sys_role_has_permissions_jnt rp ON rp.permission_id=p.id LEFT JOIN sys_roles r ON r.id=rp.role_id WHERE p.name LIKE 'tenant.accounting.budget%' GROUP BY p.id, p.name ORDER BY p.name;"
name	roles
tenant.accounting.budget.create	Account Manager, Account Staff, Management, School Admin, Super Admin
tenant.accounting.budget.delete	Account Manager, Account Staff, Management, School Admin, Super Admin
tenant.accounting.budget.forceDelete	Account Manager, Account Staff, Management, School Admin, Super Admin
tenant.accounting.budget.restore	Account Manager, Account Staff, Management, School Admin, Super Admin
tenant.accounting.budget.update	Account Manager, Account Staff, Management, School Admin, Super Admin
tenant.accounting.budget.view	Account Manager, Account Staff, Management, School Admin, Super Admin
tenant.accounting.budget.viewAny	Account Manager, Account Staff, Management, School Admin, Super Admin
```

### F4 — Validation and input

#### BDGT-06 · H · VAL-04 — a trashed row still owns the unique key, so re-creating the same allocation throws a SQL error

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules must mirror the DB unique index including soft-delete semantics* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:82-123`; `database/migrations/tenant/2026_09_16_100033_create_acc_budget_lines_table.php:41`; `database/migrations/tenant/2026_09_16_100011_create_acc_budgets_table.php:42` |
| **Root cause** | `uq_acc_bl` and `uq_acc_budget_code` do not include a deleted-at marker, so a soft-deleted budget line or header keeps its key. `firstOrCreate()`/`updateOrCreate()` exclude trashed rows, so after trashing a row the next identical create attempts an INSERT and collides with the trashed row. |
| **Consequence** | Trash a budget line, then add the same FY/ledger/cost centre/period again: the form returns a duplicate-key SQL error (shown in full by BDGT-01) instead of restoring or creating the row. |
| **Reproduce** | From the Budgets tab, delete a line, then use the create modal with exactly the same financial year, ledger, cost centre, campus and period. Expected: a new line or a restore prompt. Actual: 1062 duplicate entry for `uq_acc_bl`. |
| **Fix approach** | Decision: detect a matching trashed row in the controller and offer restore / a validation error (no schema change), or add a deleted-at marker to both unique keys in a new additive migration (Tarun's hand). |
| **Plan item** | BDGT-06 in `02-fix-plan.md` §9 (DECISION) |

```php
// 2026_09_16_100033_create_acc_budget_lines_table.php:41 — CURRENT
            $table->unique(['budget_id', 'ledger_marker', 'group_marker', 'cc_marker', 'fund_marker', 'campus_marker', 'period_marker'], 'uq_acc_bl');
```

**Evidence**
```
PS> mysql -uroot xyz_school_00000000000040008000_202627 -e "SHOW INDEX FROM acc_budget_lines WHERE Key_name='uq_acc_bl';"
Table	Non_unique	Key_name	Seq_in_index	Column_name	Collation	Cardinality	Sub_part	Packed	Null	Index_type	Comment	Index_comment	Visible	Expression
acc_budget_lines	0	uq_acc_bl	1	budget_id	A	1	NULL	NULL		BTREE			YES	NULL
acc_budget_lines	0	uq_acc_bl	2	ledger_marker	A	8	NULL	NULL	YES	BTREE			YES	NULL
acc_budget_lines	0	uq_acc_bl	3	group_marker	A	8	NULL	NULL	YES	BTREE			YES	NULL
acc_budget_lines	0	uq_acc_bl	4	cc_marker	A	9	NULL	NULL	YES	BTREE			YES	NULL
acc_budget_lines	0	uq_acc_bl	5	fund_marker	A	9	NULL	NULL	YES	BTREE			YES	NULL
acc_budget_lines	0	uq_acc_bl	6	campus_marker	A	9	NULL	NULL	YES	BTREE			YES	NULL
acc_budget_lines	0	uq_acc_bl	7	period_marker	A	9	NULL	NULL	YES	BTREE			YES	NULL
```

#### BDGT-07 · H · VAL-07 — the FormRequest does not enforce the DDL's own business rules

| Field | Value |
|---|---|
| **Rule** | VAL-07 (H) — *cross-field / business checks go in the FormRequest's `after()` hook* |
| **Where** | `Modules/Accounting/app/Http/Requests/BudgetRequest.php:24-27`, `31-32`; `database/migrations/tenant/2026_09_16_100033_create_acc_budget_lines_table.php:61` |
| **Root cause** | All four grouping fields are `nullable` and there is no `after()` rule, while `chk_acc_bl_dimension` requires at least one of ledger / account group / cost centre / fund. `revision_reason` is nullable even when `supersedes_budget_id` is set, although the DDL comment for BR-BUD-04 says a revision with no reason is a moved goalpost. `supersedes_budget_id` is not constrained to the same financial year. |
| **Consequence** | The create modal (where Ledger is not marked required) can submit with every grouping field blank, producing a CHECK-constraint 500. A revision can also be saved without a reason and can point at a budget from a different year, corrupting the revision chain. |
| **Reproduce** | Open the Budgets tab modal, leave Ledger empty, choose no group/cost centre/fund, amount 100, submit. Expected: a validation message. Actual: 500 from `chk_acc_bl_dimension`. |
| **Fix approach** | Add a `withValidator()` `after()` block: require one dimension, require `revision_reason` when `supersedes_budget_id` is filled, and reject a superseded budget from another financial year. |
| **Plan item** | BDGT-07 in `02-fix-plan.md` §5 |

```php
// BudgetRequest.php:24-27 — CURRENT
            'ledger_id'            => 'nullable|exists:acc_ledgers,id',
            'account_group_id'     => 'nullable|exists:acc_account_groups,id',
            'cost_center_id'       => 'nullable|exists:acc_cost_centers,id',
            'fund_id'              => 'nullable|exists:acc_funds,id',
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Requests\BudgetRequest.php" -Pattern "ledger_id|account_group_id|cost_center_id|fund_id|supersedes_budget_id|revision_reason" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
24:'ledger_id'            => 'nullable|exists:acc_ledgers,id',
25:'account_group_id'     => 'nullable|exists:acc_account_groups,id',
26:'cost_center_id'       => 'nullable|exists:acc_cost_centers,id',
27:'fund_id'              => 'nullable|exists:acc_funds,id',
31:'supersedes_budget_id' => 'nullable|exists:acc_budgets,id',
32:'revision_reason'      => 'nullable|string|max:1000',

PS> Select-String -Path "database\migrations\tenant\2026_09_16_100033_create_acc_budget_lines_table.php" -Pattern "chk_acc_bl_dimension" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
61:DB::statement("ALTER TABLE `acc_budget_lines` ADD CONSTRAINT `chk_acc_bl_dimension` CHECK (`ledger_id` IS NOT NULL OR `account_group_id` IS NOT NULL OR `cost_center_id` IS NOT NULL OR `fund_id` IS NOT NULL)");
```

### F5 — Routes

#### BDGT-08 · H · RTE-01 — restore changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection* |
| **Where** | `Modules/Accounting/routes/web.php:184`; `Modules/Accounting/app/Http/Controllers/BudgetController.php:332-356` |
| **Root cause** | Restore is registered as `Route::get('/budget/{id}/restore', ...)` and the trash row links to it as a normal anchor. |
| **Consequence** | A link prefetcher, crawler, or an `<img src>` planted in a comment can restore a trashed budget without the user clicking anything. |
| **Reproduce** | While authenticated, open `http://test.localhost:8000/accounting/budget/1/restore` directly in the address bar; the trashed line is restored and the activity log records `Restored`. |
| **Fix approach** | Decision: switch to POST (or DELETE) and update the shared `action-trashed` component's link to a form, or leave as accepted. Any route change is `⚠ SHARED`. |
| **Plan item** | BDGT-08 in `02-fix-plan.md` §9 (DECISION, `⚠ SHARED`) |

```php
// routes/web.php:183-187 — CURRENT
Route::get('/budget/trash/view', [BudgetController::class, 'trashed'])->name('budget.trashed');
Route::get('/budget/{id}/restore', [BudgetController::class, 'restore'])->name('budget.restore');
Route::delete('/budget/{id}/force-delete', [BudgetController::class, 'forceDelete'])->name('budget.forceDelete');
Route::resource('budget', BudgetController::class);
Route::post('/budget/{budget}/toggle-status', [BudgetController::class, 'toggleStatus'])->name('budget.toggleStatus');
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "budget/|Route::resource\('budget'" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
183:Route::get('/budget/trash/view', [BudgetController::class, 'trashed'])->name('budget.trashed');
184:Route::get('/budget/{id}/restore', [BudgetController::class, 'restore'])->name('budget.restore');
185:Route::delete('/budget/{id}/force-delete', [BudgetController::class, 'forceDelete'])->name('budget.forceDelete');
186:Route::resource('budget', BudgetController::class);
187:Route::post('/budget/{budget}/toggle-status', [BudgetController::class, 'toggleStatus'])->name('budget.toggleStatus');
```

### F6 — Controller shape

#### BDGT-09 · H · CTL-03 — one numeric id is resolved against two tables, so an action can hit the wrong record

| Field | Value |
|---|---|
| **Rule** | CTL-03 (H, raised from M because the same id can address two independent tables) — *use route model binding, not `$id` plus `findOrFail`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:145-146` (`show`), `155-156` (`edit`), `188`/`248` (`update`), `268`/`275` (`destroy`), `300`/`306` (`toggleStatus`), `338`/`344` (`restore`), `364`/`369` (`forceDelete`) |
| **Root cause** | The routes bind an untyped `$id`; every method tries `BudgetLine` first and falls back to `Budget`. `acc_budget_lines.id` (bigint) and `acc_budgets.id` (int) are independent sequences, so id 7 can mean both. The resource route parameter is named `{budget}`, which does not match the `$id` argument, so implicit binding cannot disambiguate. The header branches are not reachable from the transaction list (which lists lines), but they are reachable from any stale or hand-made URL. |
| **Consequence** | A stale header link can trash, restore, toggle or update an unrelated budget line that happens to share the id. Deleting a header also leaves its `acc_budget_lines` rows active, so a "deleted" budget still contributes to variance reporting. |
| **Reproduce** | Find a header id that also exists as a line id, then open `/accounting/budget/{headerId}/edit` and submit; the controller updates the line, not the header. |
| **Fix approach** | Decision: make this a line-only controller (drop the `Budget` fallback and add `BudgetLine $budgetLine` binding), or split header and line into separate controllers under the D3 split pass. |
| **Plan item** | BDGT-09 in `02-fix-plan.md` §9 (DECISION) |

```php
// BudgetController.php:145-146 — CURRENT
        $budget = BudgetLine::with(['budget.financialYear', 'costCenter', 'ledger', 'fund', 'campus', 'period', 'accountGroup'])->find($id)
            ?? Budget::with(['financialYear'])->findOrFail($id);
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "BudgetLine::|Budget::(find|with|firstOrCreate|onlyTrashed|withTrashed|orderBy)" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
45:$existingBudgets = Budget::orderBy('name')->get();
76:$supersededBudget = Budget::find($supersedesId);
82:$header = Budget::firstOrCreate(
108:$line = BudgetLine::updateOrCreate(
145:$budget = BudgetLine::with(['budget.financialYear', 'costCenter', 'ledger', 'fund', 'campus', 'period', 'accountGroup'])->find($id)
146:?? Budget::with(['financialYear'])->findOrFail($id);
155:$budget = BudgetLine::with(['budget.financialYear', 'costCenter', 'ledger', 'fund', 'campus', 'period', 'accountGroup'])->find($id)
156:?? Budget::with(['financialYear'])->findOrFail($id);
188:$line = BudgetLine::find($id);
205:$header = Budget::firstOrCreate(
248:$budget = Budget::findOrFail($id);
268:$line = BudgetLine::find($id);
275:$budget = Budget::findOrFail($id);
300:$line = BudgetLine::find($id);
306:$budget = Budget::findOrFail($id);
324:$budgets = BudgetLine::onlyTrashed()
338:$line = BudgetLine::onlyTrashed()->find($id);
344:$model = Budget::onlyTrashed()->findOrFail($id);
364:$line = BudgetLine::withTrashed()->find($id);
369:$model = Budget::withTrashed()->findOrFail($id);

PS> $env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --json 2>$null | php "/tmp/opencode\routesprobe.php" "Modules\Accounting\Http\Controllers\BudgetController"
PUT|PATCH accounting/budget/{budget}                              accounting.budget.update            Modules\Accounting\Http\Controllers\BudgetController@update
```

#### BDGT-10 · M · CTL-05 — about 40 lines of header/version creation are copied between `store` and `update`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same payload in `store` and `update`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:67-106` (`store`), `187-231` (`update`) |
| **Root cause** | The header lookup, supersedes/version calculation, code/name generation and `firstOrCreate` payload were copied into `update`; the copies have already diverged (`update` calls `$header->update` whenever `$supersedesId` is set, `store` only when the field is empty). |
| **Consequence** | Fixing revision behaviour in one method leaves the other wrong; the two write paths already produce different headers for the same input. |
| **Reproduce** | static only — the divergence is visible in the two code blocks. |
| **Fix approach** | Extract one private `resolveHeader(array $validated, ?int $createdBy): Budget` and call it from both methods. |
| **Plan item** | BDGT-10 in `02-fix-plan.md` §5 |

```php
// BudgetController.php:74-80 — CURRENT (store copy)
                if ($supersedesId) {
                    $budgetType = 'Revised';
                    $supersededBudget = Budget::find($supersedesId);
                    if ($supersededBudget) {
                        $version = $supersededBudget->version + 1;
                    }
                }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "firstOrCreate" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
82:$header = Budget::firstOrCreate(
205:$header = Budget::firstOrCreate(

PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "if \(\$supersedesId\)" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
74:if ($supersedesId) {
101:if ($supersedesId && (! $header->supersedes_budget_id || ! $header->revision_reason)) {
197:if ($supersedesId) {
224:if ($supersedesId) {
```

#### BDGT-11 · M · CTL-06 — version numbering and header creation are business logic inside the controller

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in services/actions; a controller method reads input, calls one service, returns a response* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:67-131` (`store`), `187-252` (`update`) |
| **Root cause** | The controller decides what "Revised" means, computes `version = superseded + 1`, builds the code and name, and reconciles `supersedes_budget_id`/`revision_reason`. No service owns the budget-revision rule. |
| **Consequence** | The revision rule cannot be reused by an import or API, and D4 means it is not covered by tests; any future caller must copy it (BDGT-10 shows that already happened once). |
| **Reproduce** | static only — no service is referenced by the controller. |
| **Fix approach** | Decision: extract a `BudgetRevisionService` (or action) that owns header identity, versioning and line upsert, and have both methods call it. A split/extraction is DEFERRED per D3. |
| **Plan item** | BDGT-11 in `02-fix-plan.md` §9 (DECISION) |

```php
// BudgetController.php:67-80 — CURRENT
            $budgetLine = DB::transaction(function () use ($validated) {
                $financialYear = FinancialYear::find($validated['financial_year_id']);
                $budgetType    = $validated['budget_type'] ?? 'Original';
                $supersedesId  = $validated['supersedes_budget_id'] ?? null;
                $revisionReason = $validated['revision_reason'] ?? null;
                $version       = 1;

                if ($supersedesId) {
                    $budgetType = 'Revised';
                    $supersededBudget = Budget::find($supersedesId);
                    if ($supersededBudget) {
                        $version = $supersededBudget->version + 1;
                    }
                }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "Service|Action" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
(no output)
```

#### BDGT-12 · M · CTL-02 — `store()` and `update()` are 81 lines each

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *methods over 80 lines are extracted* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:59-139`, `180-260` |
| **Root cause** | Validation, header resolution, line write and activity log all live in one method; the try/catch adds nine more lines. |
| **Consequence** | The two highest-risk write paths are the hardest to review, and the header block is duplicated (BDGT-10). |
| **Reproduce** | static only — measured with `Get-Content`. |
| **Fix approach** | Removing the try/catch (BDGT-01) brings both under 80 lines; the service extraction (BDGT-11) finishes the job. |
| **Plan item** | none — see `02-fix-plan.md` §10 (closed by BDGT-01) |

```php
// BudgetController.php:59-70 — CURRENT (start of the 81-line method)
    public function store(BudgetRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.accounting.budget.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        try {
            $budgetLine = DB::transaction(function () use ($validated) {
                $financialYear = FinancialYear::find($validated['financial_year_id']);
                $budgetType    = $validated['budget_type'] ?? 'Original';
                $supersedesId  = $validated['supersedes_budget_id'] ?? null;
```

**Evidence**
```
PS> $lines=Get-Content "Modules\Accounting\app\Http\Controllers\BudgetController.php"; "total lines: $($lines.Count)"; foreach($r in @(@(59,139),@(180,260))){ "method span $($r[0])-$($r[1]) = $($r[1]-$r[0]+1) lines" }
total lines: 381
method span 59-139 = 81 lines
method span 180-260 = 81 lines
```

#### BDGT-13 · L · CTL-04 — `index()` and `toggleStatus()` have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:27`, `291` |
| **Root cause** | Both signatures omit the type even though the bodies only return `RedirectResponse` and `JsonResponse`. |
| **Consequence** | No runtime effect; the contract is invisible to static analysis and to the next developer. |
| **Reproduce** | static only — read the two signatures. |
| **Fix approach** | Add `: RedirectResponse` and `: JsonResponse`; import `JsonResponse`. |
| **Plan item** | BDGT-13 in `02-fix-plan.md` §5 |

```php
// BudgetController.php:27-31 — CURRENT
    public function index()
    {
        Gate::authorize('tenant.accounting.budget.viewAny');

        return redirect()->route('accounting.menu.transactions', ['tab' => 'budgets']);
    }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "public function" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
27:public function index()
34:public function create(): View
59:public function store(BudgetRequest $request): RedirectResponse
141:public function show($id): View
151:public function edit($id): View
180:public function update(BudgetRequest $request, $id): RedirectResponse
262:public function destroy($id): RedirectResponse
291:public function toggleStatus(Request $request, $id)
320:public function trashed(): View
332:public function restore($id): RedirectResponse
358:public function forceDelete($id): RedirectResponse
```

#### BDGT-14 · L · CTL-10 — `budget/index.blade.php` is dead

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *no dead code; `index()` redirects and never renders the view* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:27-32`; `Modules/Accounting/resources/views/budget/index.blade.php:1-93` |
| **Root cause** | The listing moved to the Transactions page partial (`pages/partials/transactions/_budgets.blade.php`), but the old view was left behind. `index()` only redirects. |
| **Consequence** | No user-visible effect; 93 lines of dead UI can drift from the live table and mislead the next developer. |
| **Reproduce** | static only — the route redirects before any view is resolved. |
| **Fix approach** | Delete the unused view (optional housekeeping). |
| **Plan item** | none — see `02-fix-plan.md` §10 (harmless dead file) |

```php
// BudgetController.php:27-32 — CURRENT
    public function index()
    {
        Gate::authorize('tenant.accounting.budget.viewAny');

        return redirect()->route('accounting.menu.transactions', ['tab' => 'budgets']);
    }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\*.php","Modules\Accounting\resources\views\**\*.blade.php" -Pattern "budget.index|budget/index" -ErrorAction SilentlyContinue | ForEach-Object { "$($_.Path):$($_.LineNumber):$($_.Line.Trim())" }
/Users/bkwork/Herd/prime_ai_dev\Modules\Accounting\resources\views\budget\show.blade.php:11:<a href="{{ route('accounting.budget.index') }}" class="btn btn-sm btn-light border">
```

### F7 — Models

#### BDGT-15 · M · MDL-01 — `is_active` is not fillable on `Budget`, so the Active flag is silently dropped

| Field | Value |
|---|---|
| **Rule** | MDL-01 (M, raised from H's "declared" default because the declaration exists and only one key is missing) — *`$fillable` must cover the columns the application mass-assigns* |
| **Where** | `Modules/Accounting/app/Models/Budget.php:17-34`; `Modules/Accounting/app/Http/Controllers/BudgetController.php:96`, `219` |
| **Root cause** | `$fillable` lists `notes`, `created_by`, `updated_by` but not `is_active`. `Budget::firstOrCreate(..., ['is_active' => true])` and `$budget->update($validated)` therefore drop the key. The DB default `1` masks the create case today. |
| **Consequence** | Creating an inactive budget from the standalone create page still produces an active one; on the header edit path the Status switch is ignored while the flash says "Budget updated successfully." |
| **Reproduce** | Edit a budget header by direct URL with `is_active` unchecked; after submit the list still shows Active. |
| **Fix approach** | Add `'is_active'` to `Budget::$fillable`. |
| **Plan item** | BDGT-15 in `02-fix-plan.md` §5 |

```php
// Budget.php:17-34 — CURRENT
    protected $fillable = [
        'code',
        'name',
        'financial_year_id',
        'campus_id',
        'budget_type',
        'version',
        'supersedes_budget_id',
        'revision_reason',
        'breach_action',
        'breach_tolerance_pct',
        'status',
        'approved_by',
        'approved_at',
        'notes',
        'created_by',
        'updated_by',
    ];
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Models\Budget.php" -Pattern "is_active" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
78:return $query->where('is_active', true);

PS> mysql -uroot xyz_school_00000000000040008000_202627 -e "SHOW COLUMNS FROM acc_budgets LIKE 'is_active';"
Field	Type	Null	Key	Default	Extra
is_active	tinyint(1)	NO		1	
```

#### BDGT-16 · L · MDL-02 — `Budget` has no `is_active` cast

| Field | Value |
|---|---|
| **Rule** | MDL-02 (L, lowered from M because truthiness still works) — *`$casts` for every boolean, date, decimal, json and enum column* |
| **Where** | `Modules/Accounting/app/Models/Budget.php:36-40` |
| **Root cause** | The cast list covers `breach_tolerance_pct`, `version` and `approved_at` only; `is_active` comes back as `1`/`0` and the FK ids as strings. |
| **Consequence** | JSON exports and comparisons such as `=== true` behave differently from `BudgetLine`, which casts `is_active` correctly. |
| **Reproduce** | static only — no JSON endpoint in this controller; the mismatch shows in the export component and in Blade comparisons. |
| **Fix approach** | Add `'is_active' => 'boolean'`. |
| **Plan item** | BDGT-16 in `02-fix-plan.md` §5 |

```php
// Budget.php:36-40 — CURRENT
    protected $casts = [
        'breach_tolerance_pct' => 'decimal:4',
        'version'              => 'integer',
        'approved_at'          => 'datetime',
    ];
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Models\Budget.php" -Pattern "casts|is_active" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
36:protected $casts = [
37:'breach_tolerance_pct' => 'decimal:4',
38:'version'              => 'integer',
39:'approved_at'          => 'datetime',
78:return $query->where('is_active', true);
```

#### BDGT-17 · M · CTL-10 — `Budget::scopeByCostCenter` filters a column that `acc_budgets` does not have

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code; a scope that cannot run is dead* |
| **Where** | `Modules/Accounting/app/Models/Budget.php:71-74` |
| **Root cause** | The scope was copied from a model whose table has `cost_center_id`; `acc_budgets` has no such column (the cost centre lives on `acc_budget_lines`). |
| **Consequence** | Any future `Budget::byCostCenter($id)` throws `Unknown column 'cost_center_id'`, and the model advertises an API that cannot work. |
| **Reproduce** | static only — no caller today (`byCostCenter` greps to no output). |
| **Fix approach** | Delete the scope. |
| **Plan item** | BDGT-17 in `02-fix-plan.md` §5 |

```php
// Budget.php:71-74 — CURRENT
    public function scopeByCostCenter($query, int $ccId)
    {
        return $query->where('cost_center_id', $ccId);
    }
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\**\*.php","app\**\*.php" -Pattern "byCostCenter" -ErrorAction SilentlyContinue | ForEach-Object { "$($_.Path):$($_.LineNumber):$($_.Line.Trim())" }
(no output)

PS> mysql -uroot xyz_school_00000000000040008000_202627 -e "SHOW COLUMNS FROM acc_budgets;" 
Field	Type	Null	Key	Default	Extra
id	int unsigned	NO	PRI	NULL	auto_increment
code	varchar(30)	NO	MUL	NULL	
name	varchar(150)	NO		NULL	
financial_year_id	smallint unsigned	NO	MUL	NULL	
campus_id	smallint unsigned	YES	MUL	NULL	
budget_type	enum('Original','Revised','Forecast','Scenario')	NO	MUL	Original	
version	smallint unsigned	NO		1	
supersedes_budget_id	int unsigned	YES	MUL	NULL	
revision_reason	varchar(1000)	YES		NULL	
breach_action	enum('None','Warn','Approve','Block')	NO		Warn	
breach_tolerance_pct	decimal(9,4)	NO		0.0000	
status	enum('Draft','Approved','Active','Superseded','Closed')	NO		Draft	
approved_by	int unsigned	YES	MUL	NULL	
approved_at	datetime	YES		NULL	
notes	varchar(1000)	YES		NULL	
created_by	int unsigned	YES	MUL	NULL	
updated_by	int unsigned	YES	MUL	NULL	
created_at	timestamp	NO		CURRENT_TIMESTAMP	DEFAULT_GENERATED	
updated_at	timestamp	NO		CURRENT_TIMESTAMP	DEFAULT_GENERATED	on update CURRENT_TIMESTAMP
is_active	tinyint(1)	NO		1	
deleted_at	timestamp	YES		NULL	
```

### F8 — Services and jobs

clean — `Select-String -Path "Modules/Accounting/app/Http/Controllers/BudgetController.php" -Pattern "Service|Job|Event|Mail|Notification"` → no output.

### F9 — Queries and performance

#### BDGT-18 · M · QRY-15 — create/edit load every budget and full models for dropdowns

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *do not load every row of a table for a form* (with QRY-03 for the full-model dropdowns) |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:41-45` (`create`), `161-165` (`edit`) |
| **Root cause** | `AccountGroup::active()->orderBy('name')->get()`, `Fund::active()...`, `Campus::active()...` and `Budget::orderBy('name')->get()` select every column of every row to fill four `<select>` elements. The budgets list is unbounded. |
| **Consequence** | The create/edit page reads the whole catalogue (56 ledgers, 12 cost centres, all budgets, all account groups, funds and campuses) on every request; on a tenant with thousands of budgets the form becomes slow before it paints. |
| **Reproduce** | Open `http://test.localhost:8000/accounting/budget/create` with the query log enabled; the four `get()` calls return every column. |
| **Fix approach** | Select only the columns the selects read (`id`, `name`, `code`, `version`) and cap the supersedes list to the selected financial year where possible. |
| **Plan item** | BDGT-18 in `02-fix-plan.md` §6 |

```php
// BudgetController.php:41-45 — CURRENT
        $accountGroups  = AccountGroup::active()->orderBy('name')->get();
        $funds          = Fund::active()->orderBy('name')->get();
        $campuses       = Campus::active()->orderBy('name')->get();
        $periods        = AccountingPeriod::selectableActive();
        $existingBudgets = Budget::orderBy('name')->get();
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "::selectableActive|->orderBy\('name'\)->get\(\)|::active\(\)" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
38:$financialYears = FinancialYear::selectableActive();
39:$costCenters    = CostCenter::selectableActive();
40:$ledgers        = Ledger::selectableActive();
41:$accountGroups  = AccountGroup::active()->orderBy('name')->get();
42:$funds          = Fund::active()->orderBy('name')->get();
43:$campuses       = Campus::active()->orderBy('name')->get();
44:$periods        = AccountingPeriod::selectableActive();
158:$financialYears  = FinancialYear::selectableActive();
159:$costCenters     = CostCenter::selectableActive();
160:$ledgers         = Ledger::selectableActive();
161:$accountGroups   = AccountGroup::active()->orderBy('name')->get();
162:$funds           = Fund::active()->orderBy('name')->get();
163:$campuses        = Campus::active()->orderBy('name')->get();
164:$periods         = AccountingPeriod::selectableActive();
165:$existingBudgets = Budget::where('id', '!=', $budget->budget_id ?? $budget->id)->orderBy('name')->get();
```

#### BDGT-19 · L · QRY-13 — the trash list paginates 15 rows with no page name and no query string

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L) — *multiple paginators need distinct page names; filtered paginators keep filters* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php:324-327` |
| **Root cause** | `paginate(15)` uses the default `page` name and loses any filter; project C12 asks for 10 rows and a distinct `pageName` per list. |
| **Consequence** | A second paginated list on the same screen would share `page=1`, and 15 rows is inconsistent with the estate's list standard. |
| **Reproduce** | Open the trash page and move to page 2; the URL has `?page=2` only. |
| **Fix approach** | `paginate(10, ['*'], 'bl_page')->withQueryString()`. |
| **Plan item** | BDGT-19 in `02-fix-plan.md` §6 |

```php
// BudgetController.php:324-327 — CURRENT
        $budgets = BudgetLine::onlyTrashed()
            ->with(['budget.financialYear', 'costCenter', 'ledger', 'fund', 'campus', 'accountGroup'])
            ->orderByDesc('deleted_at')
            ->paginate(15);
```

**Evidence**
```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\BudgetController.php" -Pattern "paginate" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
327:->paginate(15);
```

### F10 — Views

clean — `Select-String -Path "Modules/Accounting/resources/views/budget/*.blade.php" -Pattern "Model::|DB::|->where\(|->get\(\)|->count\(\)"` → no output. Every relation read in `show`, `edit` and `trash` (`ledger`, `costCenter`, `fund`, `campus`, `accountGroup`, `budget.financialYear`, `period`) is eager-loaded at `BudgetController.php:145`, `155` and `324`. The one dead view is BDGT-14 (F6).

### F11 — Security and tenancy

clean — `Select-String -Path "Modules/Accounting/app/Http/Controllers/BudgetController.php","Modules/Accounting/app/Models/Budget.php","Modules/Accounting/app/Models/BudgetLine.php","Modules/Accounting/app/Http/Requests/BudgetRequest.php" -Pattern "env\(|dd\(|dump\(|var_dump|print_r|ray\(|Log::.*request"` → no output. All 11 routes carry the tenancy and auth middleware (see §4), and no cache or static cache is used.

### F12 — Style

#### BDGT-20 · L · STY-02 — the controller is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BudgetController.php` (whole file) |
| **Root cause** | `concat_space`, `unary_operator_spaces`, `not_operator_with_successor_space`, `blank_line_before_statement` and `binary_operator_spaces` all report. |
| **Consequence** | House style is inconsistent; a later `pint` run touches this file out of band. |
| **Reproduce** | Run the command below. |
| **Fix approach** | Run Pint on this file after the behavioural items. |
| **Plan item** | BDGT-20 in `02-fix-plan.md` §8 |

```php
// BudgetController.php:101 — CURRENT (one of the offending lines)
            if ($supersedesId && (! $header->supersedes_budget_id || ! $header->revision_reason)) {
```

**Evidence**
```
PS> vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\BudgetController.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\BudgetController.php","fixers":["concat_space","unary_operator_spaces","not_operator_with_successor_space","blank_line_before_statement","binary_operator_spaces"]}]}
```

#### BDGT-21 · L · STY-02 — the `Budget` model is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Models/Budget.php` (whole file) |
| **Root cause** | Unused `App\Models\BaseModel` import, inline `\Illuminate\Database\Eloquent\Relations\HasMany` instead of an import, import order and `binary_operator_spaces`. |
| **Consequence** | House style is inconsistent; the unused import hides the fact that the model extends `BaseAccountingModel`. |
| **Reproduce** | Run the command below. |
| **Fix approach** | Remove the unused import, import `HasMany`, then run Pint. |
| **Plan item** | BDGT-21 in `02-fix-plan.md` §8 |

```php
// Budget.php:7-11 — CURRENT
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Budget extends BaseAccountingModel
```

**Evidence**
```
PS> vendor\bin\pint --test "Modules\Accounting\app\Models\Budget.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\Budget.php","fixers":["fully_qualified_strict_types","no_unused_imports","ordered_imports","binary_operator_spaces"]}]}
```

#### BDGT-22 · L · STY-02 — the `BudgetLine` model is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Models/BudgetLine.php` (whole file) |
| **Root cause** | Unused `App\Models\BaseModel` import, no blank line after the imports and `binary_operator_spaces`. |
| **Consequence** | House style is inconsistent; the dead import suggests a base class that is not used. |
| **Reproduce** | Run the command below. |
| **Fix approach** | Remove the unused import and let Pint fix the rest. |
| **Plan item** | BDGT-22 in `02-fix-plan.md` §8 |

```php
// BudgetLine.php:7-9 — CURRENT
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class BudgetLine extends BaseAccountingModel
```

**Evidence**
```
PS> vendor\bin\pint --test "Modules\Accounting\app\Models\BudgetLine.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\BudgetLine.php","fixers":["no_unused_imports","single_line_after_imports","binary_operator_spaces"]}]}
```

#### BDGT-23 · L · STY-02 — `BudgetRequest` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Http/Requests/BudgetRequest.php` (whole file) |
| **Root cause** | Unused `Illuminate\Validation\Rule` import, import order and `binary_operator_spaces`. |
| **Consequence** | House style is inconsistent; the unused `Rule` import suggests uniqueness rules that are not there. |
| **Reproduce** | Run the command below. |
| **Fix approach** | BDGT-07 starts using `Rule`; otherwise remove it, then run Pint. |
| **Plan item** | BDGT-23 in `02-fix-plan.md` §8 |

```php
// BudgetRequest.php:7-9 — CURRENT
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Validation\Rule;
```

**Evidence**
```
PS> vendor\bin\pint --test "Modules\Accounting\app\Http\Requests\BudgetRequest.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\BudgetRequest.php","fixers":["no_unused_imports","ordered_imports","binary_operator_spaces"]}]}
```

#### BDGT-24 · L · STY-02 — `BudgetPolicy` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Policies/BudgetPolicy.php` (whole file) |
| **Root cause** | Import order (`User` before `Budget`). |
| **Consequence** | House style is inconsistent. |
| **Reproduce** | Run the command below. |
| **Fix approach** | Run Pint after BDGT-05's decision is applied. |
| **Plan item** | BDGT-24 in `02-fix-plan.md` §8 |

```php
// BudgetPolicy.php:7-8 — CURRENT
use Modules\SchoolSetup\Models\User;
use Modules\Accounting\Models\Budget;
```

**Evidence**
```
PS> vendor\bin\pint --test "Modules\Accounting\app\Policies\BudgetPolicy.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Policies\\BudgetPolicy.php","fixers":["ordered_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1. Wrong data | 2. Delete before replacement | 3. Duplicate implementation | 4. Soft-delete × unique | 5. Race | 6. Auth hole | 7. Message lies | 8. Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | BDGT-03 | ok | BDGT-10 | BDGT-06 | BDGT-03 | ok | BDGT-03 | ok |
| `update` | BDGT-15 | ok | BDGT-10 | BDGT-06 | BDGT-03 | ok | BDGT-15 | BDGT-09 |
| `destroy` | BDGT-09 | ok | ok | ok | ok | ok | ok | BDGT-09 |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | BDGT-09 |
| `restore` | ok | ok | ok | BDGT-06 | ok | ok | ok | BDGT-09 |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | BDGT-09 |

Answers in words:

1. **Wrong data:** `store` overwrites an existing line with the same seven dimensions (BDGT-03); `update` on a header drops `is_active` and the line fields while reporting success (BDGT-15); `destroy` on a header leaves its lines active (BDGT-09).
2. **Delete before replacement:** none — every write stores the replacement before any delete, and soft deletes are used.
3. **Duplicate implementation:** the header/version block exists twice (BDGT-10).
4. **Soft-delete × unique index:** both `uq_acc_bl` and `uq_acc_budget_code` keep trashed rows (BDGT-06).
5. **Race:** `firstOrCreate`/`updateOrCreate` are check-then-act with no lock (BDGT-03).
6. **Authorization hole:** none found — every routed method authorizes before loading, and all seven permission names exist and are seeded.
7. **Messages that lie:** "Budget created successfully" when an existing line was updated (BDGT-03); "Budget updated successfully" when the header update discarded fields (BDGT-15).
8. **Dead feature:** the `Budget` header branches of the six methods are unreachable from the listing, and `budget/index.blade.php` is dead (BDGT-09, BDGT-14).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:727-749` | The Budgets tab search does `$bq->where('title', 'like', ...)`, but `acc_budgets` has no `title` column (it is `name`); typing in the budget search throws an SQL error. Pages at 25, not the estate's 10. | QRY-14 | AccDashboardController audit (no report yet) |
| `Modules/Accounting/app/Models/AccountingPeriod.php:121-124` | `forYear()` calls `static::forYear(...)` inside itself — infinite recursion / stack exhaustion whenever it is called. | CTL-10 | [gaurav/Accounting/AccountingPeriodController](../AccountingPeriodController/01-report.md) |
| `Modules/Accounting/app/Models/BaseAccountingModel.php:28` | `$model->updated_by = Auth::id() ?? 1;` invents user id 1 when unauthenticated (SEC-03 hard-coded fallback). | SEC-03 | [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) |
| `Modules/Accounting/resources/views/pages/partials/transactions/_budgets.blade.php:147-149` | The listing prints `$budget->period->period_name`, but `acc_accounting_periods` has `name`, not `period_name`; the period sub-label is always blank. | VIEW-01 | AccDashboardController audit (no report yet) |
| `Modules/Accounting/resources/views/pages/partials/transactions/_budgets.blade.php:190-290` | The create modal is owned by AccDashboardController's page and posts to `accounting.budget.store`; its Ledger field is not required, which is what makes BDGT-07 reachable. | VAL-07 | AccDashboardController audit (no report yet) |

## 8. Not covered, and why

- **F1-F13 scanner and self-check were skipped** because `final-audit-reports/_tools/scan.php` must not be run and `scanfilter.py` / `selfcheck.py` are missing from `_tools`. Every family above was worked manually with `Select-String`, `Get-Content`, `mysql` and `pint`.
- **No tests were run and none were written** (D4). Every "Reproduce" step is either an HTTP action the developer can perform or marked "static only".
- **No browser was opened.** The screen's JS (`x-backend.table.status-switch`, `action-trashed`) was not exercised; only its route/permission contract was read.
- **Shared Blade components and layouts** (`x-backend.*`, `x-tenantcore::export-buttons`) were not audited (§4.2). The trash row's restore link is inside `action-trashed`; BDGT-08's fix depends on how that component builds the URL.
- **The listing itself belongs to `AccDashboardController::transactions()`**, not to this controller. Only its interaction with BudgetController (the create modal and the budget search) is noted in §7; its SQL was not audited here.
- **Live counts come from one tenant** (`test.localhost`, database `xyz_school_00000000000040008000_202627`), not from every tenant database.
- **`BudgetPolicy` runtime resolution is unverified by execution** — `Gate::authorize('tenant.accounting.budget.*')` resolves through the permission gate in this build; the claim that no policy is consulted rests on the zero-reference grep and the absence of a `Gate::policy` registration.
- **`BudgetLine` and `BudgetPolicy` are not listed in `00-CLASS-OWNERS.md`.** They were audited here because no other report owns them; the registry was not edited, per the brief.
