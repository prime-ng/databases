# Final Audit — Accounting / TdsDeductionController

**Audited:** 2026-10-23 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/TdsDeductionController.php` (310 lines, 12 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

---

## 0. The screen in plain words

| Field | Value |
|---|---|
| **URL(s)** | `GET /accounting/tds?tab=tds-deductions` (hub, `accounting.menu.tds`); `GET /accounting/tds-deduction` (index → hub redirect); `GET /accounting/tds-deduction/create`; `POST /accounting/tds-deduction`; `GET /accounting/tds-deduction/{tds_deduction}`; `GET /accounting/tds-deduction/{tds_deduction}/edit`; `PUT/PATCH /accounting/tds-deduction/{tds_deduction}`; `DELETE /accounting/tds-deduction/{tds_deduction}`; `POST /accounting/tds-deduction/{tds_deduction}/toggle-status`; `POST /accounting/tds-deduction/{tds_deduction}/change-status`; `GET /accounting/tds-deduction/trash/view`; `GET /accounting/tds-deduction/{id}/restore`; `DELETE /accounting/tds-deduction/{id}/force-delete` |
| **Menu path** | Accounting → TDS Management → **TDS Deductions** tab (modal inside `pages/partials/tds-management/_tds-deductions.blade.php`) |
| **Who uses it** | Intended: School Admin, Management, Account Staff, Account Manager (all hold `tenant.accounting.dashboard.view`). Actual today: **every controller action is Super-Admin-only** — the TDS permission key is not declared, so every non-super-admin gets 403 (TDSD-03). The table shell can still render for `dashboard.view` holders via the hub partial, but Create/Edit/Show/Trash all 403. |
| **What a user does** | Records a TDS deduction against a voucher line (section, taxable, rate, TDS, certificate), edits it, views it, toggles active, changes status, moves it to trash, restores or permanently deletes it. |
| **Tables written** | `acc_tds_deductions`, `acc_tds_certificates` (consumption counter only), `sys_activity_logs` |
| **Tables read** | `acc_tds_deductions`, `acc_tds_certificates`, `acc_ledgers`, `acc_financial_years`, `acc_accounting_periods`, `acc_tax_rules`, `acc_vouchers`, `acc_voucher_items`, `sys_permissions` |
| **Live data** (tenant DB, 2026-10-23) | `acc_tds_deductions` **1 live / 0 trashed**; `acc_tds_certificates` **1**; `acc_ledgers` 56; `acc_vouchers` 30; `acc_voucher_items` 98; `acc_financial_years` 3; `acc_accounting_periods` 12; `acc_tax_rules` 6. Seeded row: `id=1, voucher_item_id=1, tds_certificate_id=1, status=Deducted, taxable_amount=120000.00, tds_amount=2400.00, is_active=1`. Linked certificate #1: `certificate_no=LDC/2026/000145, consumed_amount=0.00, limit_amount=NULL, certified_rate=0, status=Active` — already out of sync with the 120000 deduction (TDSD-02). |

---

## 1. Verdict

**No — not production-ready.** Every controller action is currently **Super-Admin-only** because each `tenant.accounting.tds-deduction.*` permission is undeclared and unseeded (TDSD-03, Blocker); the hub table may render for `dashboard.view` holders, but Create/Edit/Show/Trash all 403. Separately, all seven write paths hand-roll transactions and print the raw DB error to the user (TDSD-01, Blocker); the database's duplicate-line unique index makes that reachable from the UI on the first repeated create.

The worst finding is **TDSD-03**: it is a one-line config omission that silently removes the feature from four intended roles, and it is invisible to a Super-Admin tester. Get that decision signed off first (it is a shared config/role change, §9 of the fix plan), then apply the code plan in order: **TDSD-06 → TDSD-01 → TDSD-09**.

**Effort: M (~1–2 days)** — 2 decisions (permission key, restore verb), 1 controller rewrite of 7 methods, 1 validation rule set, 1 model cast, 2 view fixes, and Pint on 4 files.

---

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 4 | 4 | 7 | 2 | 17 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TDSD-01 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | TDSD-02 | F9 Queries/Perf | TDSD-12 |
| F3 Authorization | TDSD-03, TDSD-04, TDSD-05 | F10 Views | clean |
| F4 Validation | TDSD-06, TDSD-07 | F11 Security/Tenancy | TDSD-13 |
| F5 Routes | TDSD-08 | F12 Style | TDSD-14, TDSD-15, TDSD-16, TDSD-17 |
| F6 Controller shape | TDSD-09, TDSD-10 | F13 Deep read | clean |
| F7 Models | TDSD-11 | | |

**⚠ SHARED:** TDSD-03 (`config/permissionslist.php`), TDSD-04 (`_tds-deductions.blade.php`), TDSD-08 (`routes/web.php`).

**DECISION:** TDSD-03 (permission key), TDSD-08 (restore route) — both ⚠ SHARED.

**Family notes:** F8 — no `Service|Job|Event|Mail|Notification|dispatch` references; F10 — no `User::/Ledger::/DB::` or `->get()` inside the three blades (the missing template is TDSD-09); F13 — no debug calls; `$id` in the request becomes used by TDSD-06; unused `Log`/`BaseModel` imports are covered by TDSD-14/15/17.

What was checked: F1 every catch/`getMessage`; F2 every `beginTransaction`/`commit`/`rollBack`; F3 every `Gate::authorize`/FormRequest; F4 every rule vs schema; F5 every route verb; F6 every action/view; F7 `$casts`/`$fillable`; F8 `Service|Job|Event|Mail|Notification|dispatch`; F9 every query; F10 every blade for raw output/SQL; F11 every `??`/`eval`/`exec`; F12 `pint --test` on the 4 PHP files; F13 unused imports/debug helpers.

---

## 3. Scope — every file this controller uses

| # | File | Role | Verdict |
|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/TdsDeductionController.php` | Controller under audit (310 lines, 12 public methods) | **Audited** — 17 findings |
| 2 | `Modules/Accounting/app/Http/Requests/TdsDeductionRequest.php` | Form request (122 lines) | **Audited** — in this report (pre-assigned) |
| 3 | `Modules/Accounting/app/Models/TdsDeduction.php` | Eloquent model (193 lines) | **Audited** — in this report (pre-assigned) |
| 4 | `Modules/Accounting/app/Models/TaxRule.php` | Rule lookup model (104 lines) | **Audited** — unclaimed, used by this controller (`TaxRule::where('is_active', true)`) |
| 5 | `Modules/Accounting/app/Models/VoucherItem.php` | Voucher-line model (172 lines) | **Audited** — unclaimed, used by the request's `prepareForValidation()` |
| 6 | `Modules/Accounting/app/Models/Ledger.php` | Party/TDS ledger lookup | **Linked** ↗ `LedgerController` — not audited here |
| 7 | `Modules/Accounting/app/Models/FinancialYear.php` | FY lookup | **Linked** ↗ `FinancialYearController` — not audited here |
| 8 | `Modules/Accounting/app/Models/AccountingPeriod.php` | Period lookup | **Linked** ↗ `AccountingPeriodController` — not audited here |
| 9 | `Modules/Accounting/app/Models/TdsCertificate.php` | Certificate counter | **Linked** ↗ `TdsCertificateController` — not audited here |
| 10 | `Modules/Accounting/app/Models/Voucher.php` | Voucher lookup | **Linked** ↗ `VoucherController` — not audited here |
| 11 | `Modules/Accounting/app/Models/TdsPaymentAllocation.php` | Payment allocation (not referenced here) | **Linked** ↗ `TdsPaymentAllocationController` — not audited here |
| 12 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | Base model / context hook | **Linked** ↗ `AccountingStatusMasterController` — not audited here |
| 13 | `Modules/Accounting/app/Models/Concerns/AccountingContext.php` | Accounting-context trait | **Linked** ↗ `AccountGroupController` — not audited here |
| 14 | `Modules/Accounting/resources/views/tds-deduction/edit.blade.php` | Edit screen (373 lines) | **Audited** — compiles; one finding (TDSD-13) |
| 15 | `Modules/Accounting/resources/views/tds-deduction/show.blade.php` | Detail screen (185 lines) | **Audited** — compiles clean |
| 16 | `Modules/Accounting/resources/views/tds-deduction/trash.blade.php` | Trash screen (70 lines) | **Audited** — compiles; restore link is GET (TDSD-08) |
| 17 | `Modules/Accounting/resources/views/pages/partials/tds-management/_tds-deductions.blade.php` | Hub tab partial (538 lines) | **Linked** ↗ `AccDashboardController` — cross-cutting gate drift, discussed in TDSD-04 |
| 18 | `Modules/Accounting/resources/views/tds-deduction/create.blade.php` | Create screen | **Missing** — this *is* TDSD-09 (no file on disk) |
| 19 | `Modules/Accounting/routes/web.php:464-469` | Route registrations (shared file) | **Measured** — all 12 actions routed; TDSD-08 is a route decision |
| 20 | `app/Providers/AppServiceProvider.php:78-87` | Super-admin `Gate::before` bypass | **Read-only context** — explains why the audit sees the screens and normal users do not |
| 21 | `config/permissionslist.php:600-645` | Permission producer (⚠ SHARED) | **Read-only evidence** — no `accounting.tds-deduction` key (TDSD-03) |

No `PRE-APPLIED-*` file exists for this folder, so there are no pre-applied changes to exclude.

---

## 4. Routes

All 12 public methods are routed. Every route carries: `web` → `Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains` → `Stancl\Tenancy\Middleware\InitializeTenancyByDomain` → `EnsureTenantIsActive` → `EnsureTenantHasModule:Accounting` → `Authenticate` → `EnsureEmailIsVerified` → controller.

| Method | URI | Name | Action |
|---|---|---|---|
| GET | `accounting/tds-deduction` | `accounting.tds-deduction.index` | `index` |
| GET | `accounting/tds-deduction/create` | `accounting.tds-deduction.create` | `create` |
| POST | `accounting/tds-deduction` | `accounting.tds-deduction.store` | `store` |
| GET | `accounting/tds-deduction/trash/view` | `accounting.tds-deduction.trashed` | `trashed` |
| GET | `accounting/tds-deduction/{tds_deduction}` | `accounting.tds-deduction.show` | `show` |
| GET | `accounting/tds-deduction/{tds_deduction}/edit` | `accounting.tds-deduction.edit` | `edit` |
| PUT/PATCH | `accounting/tds-deduction/{tds_deduction}` | `accounting.tds-deduction.update` | `update` |
| DELETE | `accounting/tds-deduction/{tds_deduction}` | `accounting.tds-deduction.destroy` | `destroy` |
| POST | `accounting/tds-deduction/{tds_deduction}/toggle-status` | `accounting.tds-deduction.toggleStatus` | `toggleStatus` |
| POST | `accounting/tds-deduction/{tds_deduction}/change-status` | `accounting.tds-deduction.changeStatus` | `changeStatus` |
| **GET** | `accounting/tds-deduction/{id}/restore` | `accounting.tds-deduction.restore` | `restore` — **state change on GET (TDSD-08)** |
| DELETE | `accounting/tds-deduction/{id}/force-delete` | `accounting.tds-deduction.forceDelete` | `forceDelete` |

**No action is unrouted.** The route file is shared; no route was added/removed by this audit.

---

## 5. Per-method table

| # | Method | Line | Route | Gate (controller) | Tx (where) | activityLog (event) | Tables written | Findings |
|---|---|---|---|---|---|---|---|---|
| 1 | `index` | 23 | `GET accounting/tds-deduction` | `...viewAny` | — | — | — | TDSD-03, TDSD-04 |
| 2 | `create` | 30 | `GET .../create` | `...create` | — | — | — | TDSD-03, **TDSD-09**, TDSD-12 |
| 3 | `store` | 47 | `POST ...` | `...create` (+ FormRequest `create`) | controller, manual `beginTransaction` | `Created` | `acc_tds_deductions`, `acc_tds_certificates`, `sys_activity_logs` | **TDSD-01**, TDSD-02, TDSD-03, TDSD-05, TDSD-06 |
| 4 | `show` | 90 | `GET .../{tds_deduction}` | `...view` | — | — | — | TDSD-03 |
| 5 | `edit` | 109 | `GET .../{tds_deduction}/edit` | `...update` | — | — | — | TDSD-03, TDSD-12, TDSD-13 |
| 6 | `update` | 140 | `PUT/PATCH .../{tds_deduction}` | `...update` (+ FormRequest `update`) | controller, manual `beginTransaction` | `Updated` | `acc_tds_deductions`, `sys_activity_logs` | **TDSD-01**, TDSD-02, TDSD-03, TDSD-05, TDSD-06 |
| 7 | `destroy` | 170 | `DELETE .../{tds_deduction}` | `...delete` | controller, manual `beginTransaction` | `Deleted` | `acc_tds_deductions`, `sys_activity_logs` | **TDSD-01**, TDSD-02, TDSD-03, TDSD-06 |
| 8 | `toggleStatus` | 195 | `POST .../{tds_deduction}/toggle-status` | `...update` | controller, manual `beginTransaction` | `Toggled` | `acc_tds_deductions`, `sys_activity_logs` | **TDSD-01**, TDSD-03 |
| 9 | `changeStatus` | 222 | `POST .../{tds_deduction}/change-status` | `...update` | controller, manual `beginTransaction` | `StatusChanged` | `acc_tds_deductions`, `sys_activity_logs` | **TDSD-01**, TDSD-03, TDSD-07 |
| 10 | `trashed` | 250 | `GET .../trash/view` | `...restore` | — | — | — | TDSD-03, TDSD-04 |
| 11 | `restore` | 259 | `GET .../{id}/restore` | `...restore` | controller, manual `beginTransaction` | `Restored` | `acc_tds_deductions`, `sys_activity_logs` | **TDSD-01**, TDSD-02, TDSD-03, **TDSD-08** |
| 12 | `forceDelete` | 285 | `DELETE .../{id}/force-delete` | `...forceDelete` | controller, manual `beginTransaction` | `Deleted` | `acc_tds_deductions`, `sys_activity_logs` | **TDSD-01**, TDSD-02, TDSD-03 |

`destroy` and `forceDelete` both log the event name `Deleted`; that is consistent, but note `forceDelete` logs after the row is gone (the model still holds attributes, so the log is valid).

---

## 6. Findings

### F1 — Errors

#### TDSD-01 · Blocker · ERR-01 — Raw SQL leaked through a hand-rolled transaction (7 methods)

| Field | Value |
|---|---|
| **Rule** | `ERR-01` (ERR-00 Variant H) — no manual `try/catch` around writes; no `getMessage()` to the user; let Laravel render |
| **Where** | `TdsDeductionController.php:53-87`, `144-167`, `174-192`, `201-219`, `228-247`, `263-282`, `289-308` |
| **Root cause** | All 7 mutating methods call `DB::beginTransaction()` and wrap the body in `catch (\Throwable $e)`; they `Log::error($e->getMessage())` and return `'...: ' . $e->getMessage()` to the browser. `restore`/`forceDelete` put `findOrFail()` **inside** the `try`, so a 404 is swallowed. |
| **Consequence** | Any DB error (duplicate voucher line + section, NOT NULL `voucher_item_id`, deadlock) renders raw MySQL (`SQLSTATE[23000]`, table/column names) in the flash or JSON 500; a stale trash id shows "Failed to restore…" instead of 404. |
| **Reproduce** | Seeded row 1 exists; POST the create modal for the same `voucher_item_id` + `section_code` → flash contains `SQLSTATE[23000]...Duplicate entry`. |
| **Fix approach** | Delete the 7 `try/catch` blocks; use `DB::transaction(fn () => …)`; resolve `restore`/`forceDelete` targets **before** the transaction; let `ModelNotFoundException` render 404. |
| **Plan item** | `TDSD-01` — `02-fix-plan.md` §1 |

```php
// current — store() lines 53-87 (the other six are identical in shape)
        DB::beginTransaction();
        try {
            $deduction = TdsDeduction::create($validated);

            // If certificate was used, update consumed amount
            if (!empty($validated['tds_certificate_id'])) {
                $cert = TdsCertificate::find($validated['tds_certificate_id']);
                if ($cert) {
                    $cert->increment('consumed_amount', (float) $validated['taxable_amount']);
                    if ($cert->isExhausted()) {
                        $cert->update(['status' => 'Exhausted']);
                    }
                }
            }

            activityLog($deduction, 'Created', [
                'message'      => 'TDS Deduction recorded: ₹' . number_format((float) $deduction->tds_amount, 2) . ' under Section ' . $deduction->section_code,
                'section_code' => $deduction->section_code,
                'tds_amount'   => $deduction->tds_amount,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-deductions'])
                ->with('success', 'TDS Deduction recorded successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create TDS Deduction', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create TDS Deduction: ' . $e->getMessage());
        }
```

**Evidence**
```
$ Select-String -Path TdsDeductionController.php -Pattern "beginTransaction|catch \(|getMessage|findOrFail|Log::error"
53:  DB::beginTransaction();
79:  } catch (\Throwable $e) {
80:  DB::rollBack();
86:  return back()->withInput()->with('error', 'Failed to create TDS Deduction: ' . $e->getMessage());
144: DB::beginTransaction();
159: } catch (\Throwable $e) {
166: return back()->withInput()->with('error', 'Failed to update TDS Deduction: ' . $e->getMessage());
174: DB::beginTransaction();
187: } catch (\Throwable $e) {
191: return back()->with('error', 'Failed to delete TDS Deduction: ' . $e->getMessage());
201: DB::beginTransaction();
214: } catch (\Throwable $e) {
218: return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
228: DB::beginTransaction();
242: } catch (\Throwable $e) {
246: return back()->with('error', 'Failed to update status: ' . $e->getMessage());
263: DB::beginTransaction();
265: $model = TdsDeduction::onlyTrashed()->findOrFail($id);
277: } catch (\Throwable $e) {
281: return back()->with('error', 'Failed to restore TDS Deduction: ' . $e->getMessage());
289: DB::beginTransaction();
291: $model = TdsDeduction::withTrashed()->findOrFail($id);
303: } catch (\Throwable $e) {
307: return back()->with('error', 'Failed to delete TDS Deduction: ' . $e->getMessage());
```

---

### F2 — Transactions and audit

#### TDSD-02 · High · TXN-06 — Certificate consumption is unlocked and never reconciled

| Field | Value |
|---|---|
| **Rule** | `TXN-06` — check-then-act on a shared counter needs a lock; a counter must be reversed when its owning row is edited/deleted |
| **Where** | `TdsDeductionController.php:58-65` (store), `144-155` (update), `174-183` (destroy), `263-274` (restore), `289-300` (forceDelete) |
| **Root cause** | `TdsCertificate::find()` then `increment('consumed_amount', …)` with no `lockForUpdate()`; only `store()` touches the counter. `update()`, `destroy()`, `restore()` and `forceDelete()` never subtract or re-add the deduction's `taxable_amount`. |
| **Consequence** | The live data is already drifted: deduction #1 has `taxable_amount=120000.00` and `tds_certificate_id=1`, but certificate #1 has `consumed_amount=0.00` (and `limit_amount=NULL`). Editing taxable `120000 → 10000` will subtract an amount that was never added, then add `10000`; deleting/restoring never touches the counter; two concurrent creates can race the same certificate. |
| **Reproduce** | Read-only: the grep below shows the only `consumed_amount` references are in `store()`; the update/delete/restore methods have none, and `tdsd_certprobe.php` shows `consumed=0.00` against the 120000 deduction. |
| **Fix approach** | Lock the certificate row on create (included in the TDSD-01 rewrite) and reverse/re-apply consumption in update/destroy/restore/forceDelete (TDSD-02). |
| **Plan item** | `TDSD-02` — `02-fix-plan.md` §3 |

```php
// current — store() 58-65, and the only place the counter is touched
            if (!empty($validated['tds_certificate_id'])) {
                $cert = TdsCertificate::find($validated['tds_certificate_id']);
                if ($cert) {
                    $cert->increment('consumed_amount', (float) $validated['taxable_amount']);
                    if ($cert->isExhausted()) {
                        $cert->update(['status' => 'Exhausted']);
                    }
                }
            }
```

**Evidence**
```
$ Select-String -Path TdsDeductionController.php -Pattern "consumed_amount|lockForUpdate|tds_certificate_id|isExhausted"
58: if (!empty($validated['tds_certificate_id'])) {
59: $cert = TdsCertificate::find($validated['tds_certificate_id']);
61: $cert->increment('consumed_amount', (float) $validated['taxable_amount']);
62: if ($cert->isExhausted()) {
```
Only 5 hits, all inside `store()`. `update()` (146-147), `destroy()` (176), `restore()` (266-267) and `forceDelete()` (293) contain no certificate code.

```
$ php tdsd_certprobe.php
DED id=1 cert=1 taxable=120000.00 tds=2400.00 is_active=1 deleted=NULL
CERT id=1 certificate_no='LDC/2026/000145' section_code='194C' certified_rate='0.000000000'
CERT limit_amount=NULL consumed_amount='0.00' status='Active'
CERT isExhausted=false remaining=0
```
The linked certificate is already inconsistent with its deduction: `consumed_amount=0.00` despite a `120000.00` deduction. `limit_amount=NULL` means `isExhausted()` is always false for this row (the model requires `limit_amount > 0`).

---

### F3 — Authorization

#### TDSD-03 · Blocker · AUTH-01 — TDS permission key is undeclared, so the feature is Super-Admin-only

| Field | Value |
|---|---|
| **Rule** | `AUTH-01` — every routed method authorizes through a permission that can actually be produced and granted |
| **Where** | `config/permissionslist.php:600-645` (no `accounting.tds-deduction` key); `TdsDeductionController.php:25,32,49,92,111,142,172,197,224,252,261,287` |
| **Root cause** | 12 gate calls use `tenant.accounting.tds-deduction.*`, but the config has no `accounting.tds-deduction` key. `PermissionHelper::flatten()` emits nothing, `sys_permissions` has no row, and `Gate::authorize` denies everyone except the `Gate::before` super-admin bypass (`AppServiceProvider.php:78-87`). |
| **Consequence** | School Admin, Management, Account Staff and Account Manager (who all hold `accounting.dashboard.view`) get **403** on every TDS action; only Super Admin can operate the screen. The same gap exists for `accounting.tds-payment` and `accounting.tds-certificate`. |
| **Reproduce** | Log in as School Admin → Accounting → TDS Management → TDS Deductions → open the modal → submit → 403. |
| **Fix approach** | **DECISION (⚠ SHARED)** — add `'accounting.tds-deduction' => $crud` to the accounting block, run the permission sync/seed, and grant it to the four intended roles. `$crud` already contains `create, view, viewAny, update, delete, restore, forceDelete`, which covers all 12 gates. |
| **Plan item** | `TDSD-03` — `02-fix-plan.md` §9 |

```php
// current — config/permissionslist.php:644 (end of accounting block); no TDS-deduction key
        'accounting.event-posting'  => array_merge($crud, ['process']),
    ],
```

**Evidence**
```
$ php tdsd_permcfg.php
TDS_KEYS_IN_CONFIG=NONE
DEDUCTION_KEY_PRESENT=NO

$ php tdsd_roles.php
PERM tenant.accounting.tds-deduction.viewAny | MISSING from sys_permissions
PERM tenant.accounting.tds-deduction.create | MISSING from sys_permissions
PERM tenant.accounting.tds-deduction.update | MISSING from sys_permissions
PERM tenant.accounting.tds-deduction.delete | MISSING from sys_permissions
PERM tenant.accounting.tds-deduction.restore | MISSING from sys_permissions
PERM tenant.accounting.tds-deduction.forceDelete | MISSING from sys_permissions
PERM tenant.accounting.dashboard.view | FOUND (id 1278) | roles: Super Admin, School Admin, Management, Account Staff, Account Manager
```

---

#### TDSD-04 · Medium · AUTH-06 — Screen gates disagree: `dashboard.view` vs `tds-deduction.*`

| Field | Value |
|---|---|
| **Rule** | `AUTH-06` — screen-level gates must match the controller's gates; destructive/record actions need `@can` in the blade |
| **Where** | Hub partial `_tds-deductions.blade.php:6` (`tenant.accounting.tds-deduction`), `:89` and `:265` (`tenant.accounting.dashboard.view`); controller `:25` (`viewAny`), `:142` (`update`), `:261` (`restore`); `edit.blade.php:50`; `trash.blade.php:40` |
| **Root cause** | One feature is gated on three different names. The search bar (line 6) correctly asks for `tenant.accounting.tds-deduction.create/.restore`, but that base key is unproducible (TDSD-03). The table config (line 89) and the create modal (line 265) ask for `tenant.accounting.dashboard.view`, which is the wrong feature. The edit/trash blades render forms/links with no `@can`; only the controller blocks. |
| **Consequence** | Anyone with `dashboard.view` sees the TDS table and modal shell but not the Create/Trash triggers (line 6 fails); a stale tab or devtools can open the modal and the POST 403s. Anyone granted only `tds-deduction.*` cannot see the tab at all. No data leak — the controller still blocks — but the UI lies in both directions. |
| **Reproduce** | Grant `dashboard.view` but not `tds-deduction.*`: the table and modal render, the "Record TDS Deduction" button is absent; open `#createTdsDeductionModal` via devtools and submit → 403. |
| **Fix approach** | **⚠ SHARED** — keep line 6; set line 89 to `tenant.accounting.tds-deduction.viewAny` and line 265 to `tenant.accounting.tds-deduction.create` (the modal's `permission` prop is a full ability, `app/View/Components/Backend/Tab/Modal.php:133`). Wrap the edit/trash record actions in `@can('tenant.accounting.tds-deduction.update'/'restore')`. Owner of the partial is `AccDashboardController`. |
| **Plan item** | `TDSD-04` — `02-fix-plan.md` §4 |

```blade
{{-- current — _tds-deductions.blade.php:5-7 (correct key, but it cannot resolve until TDSD-03) --}}
<x-backend.tab.search-bar url="accounting.tds-deduction"
    permissions="tenant.accounting.tds-deduction"
    createModal="#createTdsDeductionModal"
{{-- current — _tds-deductions.blade.php:89 (wrong feature) --}}
'permission' => 'tenant.accounting.dashboard.view',
{{-- current — _tds-deductions.blade.php:265 (wrong feature; expects a FULL ability) --}}
permission="tenant.accounting.dashboard.view">
{{-- current — edit.blade.php:50 / trash.blade.php:40 (no @can at all) --}}
<form action="{{ route('accounting.tds-deduction.update', $tdsDeduction->id) }}" method="POST">
<a href="{{ route('accounting.tds-deduction.restore', $ded->id) }}" class="btn btn-sm btn-outline-success">
```

**Evidence**
```
$ Select-String -Path "_tds-deductions.blade.php" -Pattern "permission|permissions"
5:  <x-backend.tab.search-bar url="accounting.tds-deduction"
6:      permissions="tenant.accounting.tds-deduction"
89:     'permission' => 'tenant.accounting.dashboard.view',
265:    permission="tenant.accounting.dashboard.view">

$ Select-String -Path "edit.blade.php","trash.blade.php" -Pattern "@can"
(no output)

$ Select-String -Path "app\View\Components\Backend\Tab\Modal.php" -Pattern "canRender|FULL ability"
86:  * @param string|null $permission FULL ability, e.g. tenant.hr-staff.hr-leave-type.create.
133: $this->canRender = blank($permission) || Gate::check($permission);
```

---

#### TDSD-05 · Low · AUTH-04 — Duplicate authorization on store/update

| Field | Value |
|---|---|
| **Rule** | `AUTH-04` — one authorization site per action (`L`) |
| **Where** | `TdsDeductionRequest.php:16-17` + `TdsDeductionController.php:49` (store), `:142` (update) |
| **Root cause** | `authorizeByCrudPermission('tenant.accounting.tds-deduction')` in the FormRequest and `Gate::authorize('tenant.accounting.tds-deduction.create/update')` in the controller both run for the same request. |
| **Consequence** | No functional change; two policy lookups and a second place to edit when the verb changes. |
| **Reproduce** | Static — both checks are visible on the same code path. |
| **Fix approach** | Keep the FormRequest `authorize()` (it already maps the verb); delete the two controller `Gate::authorize()` lines. |
| **Plan item** | `TDSD-05` — `02-fix-plan.md` §4 |

```php
// current — request 16-17
    public function authorize(): bool
    {
        return $this->authorizeByCrudPermission('tenant.accounting.tds-deduction');
    }

// current — controller 49 and 142
        Gate::authorize('tenant.accounting.tds-deduction.create');
        Gate::authorize('tenant.accounting.tds-deduction.update');
```

**Evidence**
```
$ Select-String -Path TdsDeductionRequest.php -Pattern "authorizeByCrudPermission"
17: return $this->authorizeByCrudPermission('tenant.accounting.tds-deduction');
```
Combined with the `Gate::authorize` calls at controller lines 49/142 (full grep in TDSD-01).

---

### F4 — Validation and input

#### TDSD-06 · High · VAL-04 — Validation does not mirror `NOT NULL` / unique index

| Field | Value |
|---|---|
| **Rule** | `VAL-04` — validation must mirror schema nullability and unique constraints |
| **Where** | `TdsDeductionRequest.php:26`; migration `2026_09_16_100067_create_acc_tds_deductions_table.php:23`, `:51` |
| **Root cause** | `voucher_item_id` is `nullable` in the request but `NOT NULL` in the schema; the request has no unique rule for `(voucher_item_id, section_code)`, which the table enforces as `uq_acc_tdsded`. |
| **Consequence** | `prepareForValidation()` usually fills `voucher_item_id`, but when the voucher has no matching ledger line it stays `null` → insert fails with a raw SQL error (TDSD-01). A duplicate line+section also reaches the DB and produces the same 500. |
| **Reproduce** | Create with a `voucher_id` whose party ledger has no `VoucherItem` → `voucher_item_id` null → NOT NULL error. Repeat the seeded row's `voucher_item_id=1, section_code=194C` → `uq_acc_tdsded` violation. |
| **Fix approach** | Make the rule `required` and add `Rule::unique('acc_tds_deductions', 'voucher_item_id')->where(fn ($q) => $q->where('section_code', $this->input('section_code')))->ignore($id)`; `$id` is already computed at line 22. |
| **Plan item** | `TDSD-06` — `02-fix-plan.md` §1 (must be applied **before** TDSD-01) |

```php
// current — request line 26
        'voucher_item_id'         => ['nullable', 'exists:acc_voucher_items,id'],

// current — migration lines 23 and 51
$table->unsignedBigInteger('voucher_item_id')->comment('the party line the deduction was made from');
$table->unique(['voucher_item_id', 'section_code'], 'uq_acc_tdsded');
```

**Evidence**
```
$ Select-String -Path TdsDeductionRequest.php -Pattern "voucher_item_id|unique"
26: 'voucher_item_id' => ['nullable', 'exists:acc_voucher_items,id'],
(no "unique" occurrence in the rules)

$ php tdsd_cols.php
voucher_item_id nullable=NO type=bigint unsigned
voucher_id nullable=NO type=bigint unsigned
deduction_date nullable=NO type=date

$ Select-String -Path database\migrations\tenant\2026_09_16_100067_create_acc_tds_deductions_table.php -Pattern "voucher_item_id|unique"
23: $table->unsignedBigInteger('voucher_item_id')->comment('the party line the deduction was made from');
51: $table->unique(['voucher_item_id', 'section_code'], 'uq_acc_tdsded');
```

---

#### TDSD-07 · Medium · VAL-07 — TDS amount and Paid status are not reconciled

| Field | Value |
|---|---|
| **Rule** | `VAL-07` — cross-field amounts must be validated server-side |
| **Where** | `TdsDeductionRequest.php:33-48`; `TdsDeductionController.php:226-231` |
| **Root cause** | `tds_amount` is accepted as any `numeric|min:0` and never checked against `taxable_amount * rate / 100`; `status` accepts `Paid` regardless of `paid_amount`. |
| **Consequence** | A deduction can store ₹1 TDS on ₹1,20,000 taxable; the register and the TDS payable ledger disagree. A row can claim `Paid` with `paid_amount=0`. |
| **Reproduce** | Submit `taxable_amount=120000, tds_amount=1` → accepted (no rule ties them). |
| **Fix approach** | Add a `withValidator`/`after()` reconciliation with a tolerance (`abs(tds_amount - taxable*rate/100) <= max(1, 0.01*tds_amount)`) and decide whether `Paid` requires `paid_amount >= tds_amount`. **Needs a business decision** (override allowed? tolerance?), so no plan item. |
| **Plan item** | none — see §10 |

```php
// current — request 33-48 (no cross-field rule)
        'section_code'            => ['required', 'string', 'max:20'],
        'nature_of_payment'       => ['nullable', 'string', 'max:150'],
        'tax_rule_id'             => ['nullable', 'exists:acc_tax_rules,id'],
        'tds_certificate_id'      => ['nullable', 'exists:acc_tds_certificates,id'],
        'pan'                     => ['nullable', 'string', 'max:15'],
        'is_higher_rate_no_pan'   => ['boolean'],
        'gross_amount'            => ['required', 'numeric', 'min:0'],
        'taxable_amount'          => ['required', 'numeric', 'min:0'],
        'rate_applied'            => ['required', 'numeric', 'min:0', 'max:100'],
        'tds_amount'              => ['required', 'numeric', 'min:0'],
        'net_paid_amount'         => ['required', 'numeric', 'min:0'],
        'cumulative_at_deduction' => ['nullable', 'numeric', 'min:0'],
        'deduct_on'               => ['required', 'in:Credit,Payment'],
        'tds_ledger_id'           => ['nullable', 'exists:acc_ledgers,id'],
        'status'                  => ['required', 'in:Deducted,Partly_Paid,Paid,Reversed'],
```

**Evidence**
```
$ Select-String -Path TdsDeductionRequest.php -Pattern "tds_amount|taxable_amount|paid_amount|status"
39: 'taxable_amount' => ['required', 'numeric', 'min:0'],
41: 'tds_amount'     => ['required', 'numeric', 'min:0'],
46: 'status'         => ['required', 'in:Deducted,Partly_Paid,Paid,Reversed'],
47: 'paid_amount'    => ['nullable', 'numeric', 'min:0', 'lte:tds_amount'],
(no rule references taxable_amount + rate_applied together)
```

---

### F5 — Routes

#### TDSD-08 · High · RTE-01 — Restore is a GET route

| Field | Value |
|---|---|
| **Rule** | `RTE-01` — state-changing routes must not be `GET` |
| **Where** | `routes/web.php:465`; `trash.blade.php:40` |
| **Root cause** | `Route::get('{id}/restore', …)` and an `<a href>` in the trash table. |
| **Consequence** | A CSRF-free state change; a prefetch, crawler or link preview can restore a deleted deduction. No `@csrf`/method spoofing is possible on a link. |
| **Reproduce** | Open the trash page, copy the Restore link into a new tab → the row is restored. |
| **Fix approach** | **DECISION (⚠ SHARED route file)** — change to `Route::delete('{id}/restore', …)` and render a `@method('DELETE')` form with `@csrf`; or keep GET and accept the risk. |
| **Plan item** | `TDSD-08` — `02-fix-plan.md` §9 |

```php
// current — routes/web.php:465
Route::get('/tds-deduction/{id}/restore', [TdsDeductionController::class, 'restore'])->name('tds-deduction.restore');
```
```blade
{{-- current — trash.blade.php:40 --}}
<a href="{{ route('accounting.tds-deduction.restore', $ded->id) }}" class="btn btn-sm btn-outline-success">
```

**Evidence**
```
$ Select-String -Path routes\web.php -Pattern "tds-deduction.*restore"
465: Route::get('/tds-deduction/{id}/restore', [TdsDeductionController::class, 'restore'])->name('tds-deduction.restore');
$ php artisan route:list --json | routesprobe.php
GET|HEAD  accounting/tds-deduction/{id}/restore  accounting.tds-deduction.restore  TdsDeductionController@restore
$ Select-String -Path trash.blade.php -Pattern "restore"
40: <a href="{{ route('accounting.tds-deduction.restore', $ded->id) }}" class="btn btn-sm btn-outline-success">
```

---

### F6 — Controller shape

#### TDSD-09 · High · CTL-10 — `create()` renders a view that does not exist (500)

| Field | Value |
|---|---|
| **Rule** | `CTL-10` — an action must not render a missing view |
| **Where** | `TdsDeductionController.php:30-45`; expected `Modules/Accounting/resources/views/tds-deduction/create.blade.php` |
| **Root cause** | `create()` returns `view('accounting::tds-deduction.create')`, but it is the only missing blade in the folder (`edit`, `show`, `trash` exist). |
| **Consequence** | `GET /accounting/tds-deduction/create` → `InvalidArgumentException: View [accounting::tds-deduction.create] not found` → **500**. Reachable by Super Admin today; the hub uses a modal, so this path is legacy. |
| **Reproduce** | As Super Admin, open `/accounting/tds-deduction/create`. |
| **Fix approach** | Redirect to the hub tab (`accounting.menu.tds?tab=tds-deductions`) with an info flash, since creation is the modal in the partial. This also drops 7 unused loader queries. |
| **Plan item** | `TDSD-09` — `02-fix-plan.md` §1 |

```php
// current — lines 30-45
    public function create()
    {
        Gate::authorize('tenant.accounting.tds-deduction.create');

        $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
        $tdsLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
        $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
        $periods = AccountingPeriod::where('is_active', true)->orderBy('period_no')->get();
        $taxRules = TaxRule::where('is_active', true)->get();
        $certificates = TdsCertificate::where('status', 'Active')->get();
        $vouchers = Voucher::orderByDesc('voucher_date')->limit(50)->get();

        return view('accounting::tds-deduction.create', compact(
            'partyLedgers', 'tdsLedgers', 'financialYears', 'periods', 'taxRules', 'certificates', 'vouchers'
        ));
    }
```

**Evidence**
```
$ php tdsd_blade.php
create: MISSING -> accounting::tds-deduction.create
edit:   COMPILE_OK
show:   COMPILE_OK
trash:  COMPILE_OK
```

---

#### TDSD-10 · Low · CTL-04 — Nine public actions omit return types

| Field | Value |
|---|---|
| **Rule** | `CTL-04` — public controller actions declare a return type (`L`) |
| **Where** | `:23,30,47,90,109,140,170,195,222`; `trashed` (250), `restore` (259), `forceDelete` (285) are already typed |
| **Root cause** | 9 of 12 actions have no return type; three typed actions use inline FQCNs (`\Illuminate\View\View`, `\Illuminate\Http\RedirectResponse`) instead of imports. |
| **Consequence** | Static-analysis/IDE noise; the FQCN imports are a Pint failure. |
| **Reproduce** | Static. |
| **Fix approach** | Add `: View|RedirectResponse|JsonResponse` during the TDSD-01/09 rewrite; Pint's `fully_qualified_strict_types` imports the FQCNs. |
| **Plan item** | none separately — folded into TDSD-01/09/14; see §10 |

```php
// current — signatures
    public function index()          // no return type
    public function create()         // no return type
    public function store(TdsDeductionRequest $request)  // no return type
    public function show(TdsDeduction $tdsDeduction)      // no return type
    public function edit(TdsDeduction $tdsDeduction)      // no return type
    public function update(TdsDeductionRequest $request, TdsDeduction $tdsDeduction) // no return type
    public function destroy(TdsDeduction $tdsDeduction)   // no return type
    public function toggleStatus(Request $request, TdsDeduction $tdsDeduction) // no return type
    public function changeStatus(Request $request, TdsDeduction $tdsDeduction) // no return type
    public function trashed(): \Illuminate\View\View
    public function restore($id): \Illuminate\Http\RedirectResponse
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

**Evidence**
```
$ Select-String -Path TdsDeductionController.php -Pattern "public function"
23:  public function index()
30:  public function create()
47:  public function store(TdsDeductionRequest $request)
90:  public function show(TdsDeduction $tdsDeduction)
109: public function edit(TdsDeduction $tdsDeduction)
140: public function update(TdsDeductionRequest $request, TdsDeduction $tdsDeduction)
170: public function destroy(TdsDeduction $tdsDeduction)
195: public function toggleStatus(Request $request, TdsDeduction $tdsDeduction)
222: public function changeStatus(Request $request, TdsDeduction $tdsDeduction)
250: public function trashed(): \Illuminate\View\View
259: public function restore($id): \Illuminate\Http\RedirectResponse
285: public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

---

### F7 — Models

#### TDSD-11 · Medium · MDL-02 — `is_active` is not cast to boolean

| Field | Value |
|---|---|
| **Rule** | `MDL-02` — boolean columns must be cast |
| **Where** | `TdsDeduction.php:42-54` |
| **Root cause** | `is_active` is `tinyint(1)` and in `$fillable`, but `$casts` has no `'is_active' => 'boolean'`. The live row returns integer `1`. |
| **Consequence** | `$model->is_active === true` is false; JSON returns `1`; `@if($model->is_active)` and strict comparisons drift between MySQL and the model. |
| **Reproduce** | `TdsDeduction::first()->is_active` → `1` (int), not `true`. |
| **Fix approach** | Add `'is_active' => 'boolean'` to `$casts`. |
| **Plan item** | `TDSD-11` — `02-fix-plan.md` §5 |

```php
// current — casts 42-54 (no is_active)
    protected $casts = [
        'deduction_date'         => 'date',
        'quarter'                => 'integer',
        'gross_amount'           => 'decimal:2',
        'taxable_amount'         => 'decimal:2',
        'rate_applied'           => 'decimal:9,4',
        'tds_amount'             => 'decimal:2',
        'net_paid_amount'        => 'decimal:2',
        'cumulative_at_deduction'=> 'decimal:2',
        'is_higher_rate_no_pan'  => 'boolean',
        'paid_amount'            => 'decimal:2',
        'certificate_issued_at'  => 'datetime',
    ];
```

**Evidence**
```
$ php tdsd_relprobe.php
DED is_active_TYPE:integer VALUE:1

$ Select-String -Path TdsDeduction.php -Pattern "is_active|casts"
39: 'is_active',
42: protected $casts = [
(no is_active cast)
```

---

### F8 — Services and jobs

clean — `Select-String -Path TdsDeductionController.php -Pattern "Service|Job|Event|Mail|Notification|dispatch"` → no output.

### F9 — Queries and performance

#### TDSD-12 · Medium · QRY-12 — Duplicate identical ledger queries and whole-table dropdowns

| Field | Value |
|---|---|
| **Rule** | `QRY-12` — no duplicate identical queries; select only needed columns |
| **Where** | `:34-35` (create) and `:115-116` (edit); whole-model selectors at `:36-41` / `:117-121` |
| **Root cause** | `$partyLedgers` and `$tdsLedgers` execute the same `Ledger::where('is_active', true)->orderBy('name')->get()`; all loaders fetch `*`. |
| **Consequence** | Two identical 56-row scans per request; the modal ships unused columns. |
| **Reproduce** | Static — the two lines are identical except for the variable name. |
| **Fix approach** | One query, reuse the collection for both dropdowns; select `id,name,code` (ledgers), `id,name` (FY), `id,name,period_no` (periods), `id,name,rate` (rules). `create()` is removed by TDSD-09, so only `edit()` changes. |
| **Plan item** | `TDSD-12` — `02-fix-plan.md` §6 |

```php
// current — edit 115-116
        $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
        $tdsLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
```

**Evidence**
```
$ Select-String -Path TdsDeductionController.php -Pattern "Ledger::where"
34: $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
35: $tdsLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
115: $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
116: $tdsLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
```

---

### F10 — Views

clean — `Select-String -Path Modules\Accounting\resources\views\tds-deduction\*.blade.php -Pattern "User::|Ledger::|DB::|->where\(|->get\(\)|->count\(\)|::all\("` → no output. The missing `create` template is TDSD-09, not a blade-safety issue.

### F11 — Security and tenancy

#### TDSD-13 · Low · SEC-03 — `?? 1` fallback in the edit blade

| Field | Value |
|---|---|
| **Rule** | `SEC-03` — no fallback that can mask a missing ownership value (`L`) |
| **Where** | `edit.blade.php:55` |
| **Root cause** | `$tdsDeduction->voucher_item_id ?? 1` injects voucher item 1 when the value is null. The column is `NOT NULL` and the seeded row is `1`, so it is dead today. |
| **Consequence** | If the column is ever made nullable (or the view is reused on an unsaved model), the form silently targets line 1 — a different voucher item than the deduction — and a later update can corrupt the wrong line. |
| **Reproduce** | Static; live row `voucher_item_id=1`, so the fallback never fires. |
| **Fix approach** | Remove `?? 1` and bind the real value. |
| **Plan item** | `TDSD-13` — `02-fix-plan.md` §7 |

```blade
{{-- current — edit.blade.php:55 --}}
<option value="{{ $vi->id }}" {{ $tdsDeduction->voucher_item_id ?? 1 == $vi->id ? 'selected' : '' }}>
```

**Evidence**
```
$ Select-String -Path edit.blade.php -Pattern "\?\? 1"
55: <option value="{{ $vi->id }}" {{ $tdsDeduction->voucher_item_id ?? 1 == $vi->id ? 'selected' : '' }}>
```

---

### F12 — Style

#### TDSD-14 · Low · STY-02 — Controller fails Pint

| Field | Value |
|---|---|
| **Rule** | `STY-02` — touched files must pass Pint (`L`) |
| **Where** | `TdsDeductionController.php` |
| **Root cause** | Import order, concat spacing, `!` spacing, FQCN imports and operator alignment are non-conforming. |
| **Consequence** | `pint --test` fails; CI/format checks block the file. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\TdsDeductionController.php` → `{"result":"fail"}`. |
| **Fix approach** | Run Pint on the touched file after TDSD-01/09 (it removes the now-unused `Log` import and imports the FQCNs). |
| **Plan item** | `TDSD-14` — `02-fix-plan.md` §8 |

```php
// current — imports 7-19 (not alphabetical; Log becomes unused after TDSD-01)
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Modules\Accounting\Http\Requests\TdsDeductionRequest;
use Modules\Accounting\Models\TdsDeduction;
use Modules\Accounting\Models\Ledger;
use Modules\Accounting\Models\FinancialYear;
use Modules\Accounting\Models\AccountingPeriod;
use Modules\Accounting\Models\TaxRule;
use Modules\Accounting\Models\TdsCertificate;
use Modules\Accounting\Models\Voucher;
```

**Evidence**
```
$ vendor\bin\pint --test TdsDeductionController.php --format json
{"tool":"pint","result":"fail","files":[{"path":"Modules/Accounting/app/Http/Controllers/TdsDeductionController.php","fixers":["fully_qualified_strict_types","concat_space","not_operator_with_successor_space","ordered_imports","binary_operator_spaces"]}]}
```

---

#### TDSD-15 · Low · STY-02 — Model fails Pint

| Field | Value |
|---|---|
| **Rule** | `STY-02` (`L`) |
| **Where** | `TdsDeduction.php` |
| **Root cause** | Unused `App\Models\BaseModel` import; missing blank line after imports; operator alignment. |
| **Consequence** | `pint --test` fails. |
| **Reproduce** | `pint --test TdsDeduction.php` → fail. |
| **Fix approach** | Remove the unused import and run Pint. |
| **Plan item** | `TDSD-15` — `02-fix-plan.md` §8 |

```php
// current — lines 7-9
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class TdsDeduction extends BaseAccountingModel
```

**Evidence**
```
$ vendor\bin\pint --test TdsDeduction.php --format json
{"path":"Modules/Accounting/app/Models/TdsDeduction.php","fixers":["fully_qualified_strict_types","no_unused_imports","single_line_after_imports","binary_operator_spaces"]}
```

---

#### TDSD-16 · Low · STY-02 — Form request fails Pint

| Field | Value |
|---|---|
| **Rule** | `STY-02` (`L`) |
| **Where** | `TdsDeductionRequest.php` |
| **Root cause** | Import order (`App\Traits` after `Illuminate\Foundation`), unused import, FQCNs in `prepareForValidation()`, operator alignment. |
| **Consequence** | `pint --test` fails. |
| **Reproduce** | `pint --test TdsDeductionRequest.php` → fail. |
| **Fix approach** | Run Pint after TDSD-06 (the `$id` becomes used, and the FQCNs are imported). |
| **Plan item** | `TDSD-16` — `02-fix-plan.md` §8 |

```php
// current — imports 7-9
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Validation\Rule;
```

**Evidence**
```
$ vendor\bin\pint --test TdsDeductionRequest.php --format json
{"path":"Modules/Accounting/app/Http/Requests/TdsDeductionRequest.php","fixers":["fully_qualified_strict_types","no_unused_imports","ordered_imports","binary_operator_spaces"]}
```

---

#### TDSD-17 · Low · STY-02 — `TaxRule` fails Pint

| Field | Value |
|---|---|
| **Rule** | `STY-02` (`L`) |
| **Where** | `TaxRule.php` |
| **Root cause** | Unused `App\Models\BaseModel`, unsorted imports, method-chain indentation, operator alignment. |
| **Consequence** | `pint --test` fails. |
| **Reproduce** | `pint --test TaxRule.php` → fail. |
| **Fix approach** | Remove the unused import and run Pint (no behaviour change). |
| **Plan item** | `TDSD-17` — `02-fix-plan.md` §8 |

```php
// current — lines 7-11
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TaxRule extends BaseAccountingModel
```

**Evidence**
```
$ vendor\bin\pint --test TaxRule.php --format json
{"path":"Modules/Accounting/app/Models/TaxRule.php","fixers":["fully_qualified_strict_types","method_chaining_indentation","no_unused_imports","ordered_imports","binary_operator_spaces"]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

clean — `Select-String -Path TdsDeductionController.php -Pattern "\bdd\(|\bdump\(|var_dump|\bprint_r\("` → no output; no private/protected dead helpers (`private function|protected function` → no output). The unused imports are style-only (TDSD-14/15/17), and the request's `$id` becomes used by TDSD-06.

---

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| # | Note | Applies to |
|---|---|---|
| 1 | The `accounting.tds-deduction` permission key is absent, and so are `accounting.tds-payment` and `accounting.tds-certificate`. Adding only the deduction key fixes this screen but leaves the sibling TDS screens Super-Admin-only. | TDSD-03; `TdsPaymentController`, `TdsCertificateController` |
| 2 | `BaseAccountingModel::resolveAccountingContextOnCreating` resolves the accounting period from `now()`, not from `deduction_date`; a back-dated deduction can land in the current month's period. Not changed here because the base model is ↗ `AccountingStatusMasterController`. | store/update |
| 3 | `_tds-deductions.blade.php` is owned by `AccDashboardController`; lines 89 and 265 gate the table/modal on `dashboard.view`, while line 6 already uses the TDS base key. The file cannot be edited by this controller's fixer without the owner's sign-off. | TDSD-04 |
| 4 | The `create()` URL is legacy: the only live entry point is the modal in the hub partial. TDSD-09 intentionally redirects instead of adding a second create screen. | TDSD-09 |
| 5 | `restore` and `forceDelete` are `$id`-based closures while `show/edit/update/destroy` use route-model binding; the mix is legal but the `findOrFail` must move out of the `try` (TDSD-01). | TDSD-01 |

---

## 8. Not covered, and why

| Item | Why |
|---|---|
| `_tools/scanfilter.py`, `_tools/selfcheck.py` | **Missing from the repository** — F1–F13 were performed manually; the scanner and self-check were **not run**. |
| `scan.php` | Must not be run (project rule). |
| Automated tests | **No test run** (D4). Verification is static + live read-only probes. |
| Live mutation of the seeded row | Audit is read-only; no POST/PUT/DELETE was executed. TDSD-02's drift was proven from code paths, not by mutating data. |
| Browser rendering of the blades | `edit/show/trash` were compiled and `php -l`'d, but not rendered; the missing `create` view is proven by file absence. |
| `TaxRule` / `VoucherItem` full audits | Audited only as used by this controller/request; their own screens are out of scope. |
| Route file changes | Not made — TDSD-08 is a decision. |
| Permission seeding | Not run — TDSD-03 is a decision (⚠ SHARED). |
| Sibling TDS controllers | Out of scope; the permission gap is noted in §7. |


