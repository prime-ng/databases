# Final Audit — Accounting / DonationController

**Audited:** 2026-10-24 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/DonationController.php` (328 lines, 14 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/donation` (redirects to the list) · `http://test.localhost:8000/accounting/school-specific?tab=donations` (list + create modal) · `http://test.localhost:8000/accounting/donation/{id}` (show) · `http://test.localhost:8000/accounting/donation/{id}/edit` · `http://test.localhost:8000/accounting/donation/{id}/certificate` · `http://test.localhost:8000/accounting/donation/trash/view` |
| Menu path | Accounting → School & Grants → **Donations & 80G Receipts** tab |
| Who uses it | Five roles hold `tenant.accounting.dashboard.view` and can open the School & Grants page: Account Manager, Account Staff, Management, School Admin, Super Admin. The Donations tab itself is wrapped in `@can('tenant.accounting.donation.viewAny')`, and that permission does not exist in the tenant database, so today **only Super Admin** (the `Gate::before` bypass in `AppServiceProvider`) can see it. |
| What a user does here | Records a donation receipt with donor details, nature (Corpus / General / Restricted), fund, amount and payment mode; prints the 80G tax-exemption certificate; posts the receipt to the ledger as a Receipt voucher; cancels a receipt (the number is kept); trashes, restores or permanently deletes a receipt. |
| Tables written | `acc_donations` directly. `post()` also writes `acc_vouchers`, `acc_voucher_items` and `acc_audit_logs` through `VoucherService`. After the plan, `sys_activity_logs`. |
| Tables read | `acc_donations`, `acc_financial_years`, `acc_ledgers`, `acc_account_groups`, `acc_funds`, `acc_voucher_types`, `acc_accounting_periods`, `acc_campuses`, `sys_users` |
| Live data | `acc_donations` 2 rows, 0 trashed · `acc_ledgers` 56 · `acc_funds` 4 · `acc_financial_years` 3 · `acc_voucher_types` 18 · `acc_vouchers` 30 · `acc_voucher_items` 98 · `acc_audit_logs` 5 · donation permissions seeded: **0** |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. The Donations tab is invisible to every role except Super Admin because all fourteen `tenant.accounting.donation.*` permission names are missing from `config/permissionslist.php` and from the tenant database, and the routed `/accounting/donation/create` URL points at a method that does not exist, so it is a guaranteed 500. The single worst finding is that `post()` marks a donation **Posted** even when it could not create a voucher: the ledger never records the income, and the two live donations are already in exactly that state (`status = Posted`, `voucher_id = NULL`). The fix is a medium effort: three method rewrites (store / update / post), one missing method, a model fillable entry, two view fixes, and a permission decision that needs Tarun's hand.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 3 | 8 | 15 | 9 | 5 | 35 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | DNAT-01, DNAT-02, DNAT-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | DNAT-04, DNAT-05, DNAT-06 | F9 Queries/Perf | DNAT-26, DNAT-27 |
| F3 Authorization | DNAT-07, DNAT-08 | F10 Views | DNAT-28 |
| F4 Validation | DNAT-09, DNAT-10, DNAT-11, DNAT-12 | F11 Security/Tenancy | clean |
| F5 Routes | DNAT-13, DNAT-14 | F12 Style | DNAT-29, DNAT-30, DNAT-31 |
| F6 Controller shape | DNAT-15, DNAT-16, DNAT-17, DNAT-18, DNAT-19, DNAT-20 | F13 Deep read | DNAT-32, DNAT-33, DNAT-34, DNAT-35 |
| F7 Models | DNAT-21, DNAT-22, DNAT-23, DNAT-24, DNAT-25 | | |

## 3. Scope - every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/DonationController.php` | controller | 328 | this report | ✅ |
| 2 | `Modules/Accounting/app/Http/Requests/DonationRequest.php` | FormRequest | 69 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Models/Donation.php` | model | 162 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/app/Models/FinancialYear.php` | model | 168 | ↗ [gaurav/Accounting/FinancialYearController](../FinancialYearController/01-report.md) | ↗ linked |
| 5 | `Modules/Accounting/app/Models/Fund.php` | model | 68 | ↗ [gaurav/Accounting/FundController](../FundController/01-report.md) | ↗ linked |
| 6 | `Modules/Accounting/app/Models/Ledger.php` | model | 408 | ↗ [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) | ↗ linked |
| 7 | `Modules/Accounting/app/Models/VoucherType.php` | model | 185 | ↗ [gaurav/Accounting/VoucherTypeController](../VoucherTypeController/01-report.md) | ↗ linked |
| 8 | `Modules/Accounting/app/Services/VoucherService.php` | service | 402 | ↗ [gaurav/Accounting/VoucherController](../VoucherController/01-report.md) (not yet audited) | ↗ linked |
| 9 | `Modules/Accounting/resources/views/donation/show.blade.php` | blade | 156 | this report | ✅ |
| 10 | `Modules/Accounting/resources/views/donation/edit.blade.php` | blade | 102 | this report | ✅ |
| 11 | `Modules/Accounting/resources/views/donation/certificate.blade.php` | blade | 83 | this report | ✅ |
| 12 | `Modules/Accounting/resources/views/donation/trash.blade.php` | blade | 67 | this report | ✅ |
| 13 | `Modules/Accounting/resources/views/pages/partials/school-specific/_donations.blade.php` | blade (list + create modal) | 450 | this report — shared partial, not in `00-CLASS-OWNERS.md`; registry edits are forbidden on this run | ✅ |
| 14 | `Modules/Accounting/routes/web.php` | route file (shared) | 536 | shared app-wide | ❌ shared — routes read, file not audited |
| 15 | `config/permissionslist.php` | config (shared) | 1824 | shared app-wide | ❌ shared — permission existence checked only |
| 16 | `database/migrations/tenant/2026_09_16_100044_create_acc_donations_table.php` | migration (DDL) | 95 | shared | ❌ read-only DDL reference |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/donation                                     accounting.donation.index           DonationController@index
POST      accounting/donation                                     accounting.donation.store           DonationController@store
GET|HEAD  accounting/donation/create                              accounting.donation.create          DonationController@create
GET|HEAD  accounting/donation/trash/view                          accounting.donation.trashed         DonationController@trashed
GET|HEAD  accounting/donation/{donation}                          accounting.donation.show            DonationController@show
PUT|PATCH accounting/donation/{donation}                          accounting.donation.update          DonationController@update
DELETE    accounting/donation/{donation}                          accounting.donation.destroy         DonationController@destroy
POST      accounting/donation/{donation}/cancel                   accounting.donation.cancel          DonationController@cancel
GET|HEAD  accounting/donation/{donation}/certificate              accounting.donation.certificate     DonationController@certificate
GET|HEAD  accounting/donation/{donation}/edit                     accounting.donation.edit            DonationController@edit
POST      accounting/donation/{donation}/issue-certificate        accounting.donation.issueCertificate DonationController@issueCertificate
POST      accounting/donation/{donation}/post                     accounting.donation.post            DonationController@post
POST      accounting/donation/{donation}/toggle-status            accounting.donation.toggleStatus    DonationController@toggleStatus
DELETE    accounting/donation/{id}/force-delete                   accounting.donation.forceDelete     DonationController@forceDelete
GET|HEAD  accounting/donation/{id}/restore                        accounting.donation.restore         DonationController@restore
```

Every route carries `web`, `PreventAccessFromCentralDomains`, `InitializeTenancyByDomain`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Accounting`, `Authenticate` and `EnsureEmailIsVerified`.

Unrouted public methods: none. The reverse defect exists — route `accounting.donation.create` points at `DonationController@create`, which does not exist (DNAT-13).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 26 | GET /accounting/donation | `tenant.accounting.donation.viewAny` | — | none | none | DNAT-19, DNAT-20 |
| `store` | 33 | POST /accounting/donation | `tenant.accounting.donation.create` | controller, manual (68) | none | acc_donations | DNAT-01, DNAT-02, DNAT-04, DNAT-05, DNAT-06, DNAT-09, DNAT-10, DNAT-15, DNAT-32, DNAT-33 |
| `show` | 81 | GET /accounting/donation/{donation} | `tenant.accounting.donation.view` | — | none | none | DNAT-19 |
| `edit` | 90 | GET /accounting/donation/{donation}/edit | `tenant.accounting.donation.update` | — | none | none | DNAT-19, DNAT-26 |
| `update` | 100 | PUT/PATCH /accounting/donation/{donation} | `tenant.accounting.donation.update` | controller, manual (118) | none | acc_donations | DNAT-01, DNAT-02, DNAT-04, DNAT-05 |
| `post` | 131 | POST /accounting/donation/{donation}/post | `tenant.accounting.donation.post` | controller, manual (143) | none | acc_donations, acc_vouchers, acc_voucher_items, acc_audit_logs | DNAT-01, DNAT-02, DNAT-03, DNAT-04, DNAT-05, DNAT-15, DNAT-16 |
| `issueCertificate` | 228 | POST /accounting/donation/{donation}/issue-certificate | `tenant.accounting.donation.issueCertificate` | none | none | acc_donations | DNAT-05, DNAT-35 |
| `certificate` | 245 | GET /accounting/donation/{donation}/certificate | `tenant.accounting.donation.view` | — | none | none | DNAT-19, DNAT-28 |
| `cancel` | 254 | POST /accounting/donation/{donation}/cancel | `tenant.accounting.donation.cancel` | none | none | acc_donations | DNAT-05, DNAT-11, DNAT-34 |
| `toggleStatus` | 277 | POST /accounting/donation/{donation}/toggle-status | `tenant.accounting.donation.update` | none | none | none (silently discarded) | DNAT-21, DNAT-22 |
| `destroy` | 286 | DELETE /accounting/donation/{donation} | `tenant.accounting.donation.delete` | none | none | acc_donations | DNAT-05 |
| `trashed` | 300 | GET /accounting/donation/trash/view | `tenant.accounting.donation.delete` | — | none | none | DNAT-19, DNAT-27 |
| `restore` | 309 | GET /accounting/donation/{id}/restore | `tenant.accounting.donation.delete` | none | none | acc_donations | DNAT-05, DNAT-14, DNAT-18 |
| `forceDelete` | 319 | DELETE /accounting/donation/{id}/force-delete | `tenant.accounting.donation.delete` | none | none | acc_donations | DNAT-05, DNAT-18 |

## 6. Findings

### F1 — Errors

#### DNAT-01 · B · ERR-01 — Raw SQL text is shown to the user on every failed write

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:75-78` (`store()`), `:125-128` (`update()`), `:222-225` (`post()`) |
| **Root cause** | Each `catch (\Throwable $e)` builds the red flash by concatenating `$e->getMessage()`. A `QueryException` message contains the SQL statement, the table name and the column name. |
| **Consequence** | A duplicate receipt number or a missing ledger shows the user a raw `SQLSTATE[23000] ... Duplicate entry ... for key 'uq_acc_don_sequence'` message instead of a friendly error. |
| **Reproduce** | Open `/accounting/school-specific?tab=donations`, record two receipts on the same date (the numbering bug DNAT-06/DNAT-09 makes this easy), and submit the second. The red flash prints the SQL. |
| **Fix approach** | Delete the three `catch` blocks (D1). The central renderer in `bootstrap/app.php` logs and renders the failure. |
| **Plan item** | DNAT-01 (store), DNAT-03 (post), DNAT-04 (update) in `02-fix-plan.md` |

```php
// DonationController.php:75-78, 125-128, 222-225 — CURRENT
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->withInput()->with('error', 'Failed to create donation: ' . $e->getMessage());
        }
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'getMessage' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
77:return redirect()->back()->withInput()->with('error', 'Failed to create donation: ' . $e->getMessage());
127:return redirect()->back()->withInput()->with('error', 'Failed to update donation: ' . $e->getMessage());
224:return redirect()->back()->with('error', 'Failed to post donation: ' . $e->getMessage());
```

#### DNAT-02 · M · ERR-00 — Three write methods keep a controller try/catch that D1 forbids

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M under D1) — *the Laravel idiom is no try/catch in a controller; `DB::transaction()` rolls back and rethrows by itself* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:69-78` (`store()`), `:119-128` (`update()`), `:144-225` (`post()`) |
| **Root cause** | The controller predates the final-audit decision and keeps a page-specific catch on each mutation. D2 allows no catch shape here: none of the three is a truncate-then-rebuild method, and none rethrows. |
| **Consequence** | Every failure is converted into a redirect with a raw message (DNAT-01), and the 403/404/422 classes are flattened instead of rendered by the central handler. |
| **Reproduce** | Static only — the catch fires on any database failure; the message leak is reproduced under DNAT-01. |
| **Fix approach** | Remove all three catches with the DNAT-01 / DNAT-03 / DNAT-04 rewrites. |
| **Plan item** | resolved by DNAT-01, DNAT-03 and DNAT-04 in `02-fix-plan.md` |

```php
// DonationController.php:68-71 — CURRENT
        DB::beginTransaction();
        try {
            $donation = Donation::create($validated);
            DB::commit();
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'try \{' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
69:try {
119:try {
144:try {
```

#### DNAT-03 · H · ERR-06 — `post()` reports success and marks the donation Posted even when no voucher was created

| Field | Value |
|---|---|
| **Rule** | ERR-06 (H) — *no swallowed failure on a write path; never continue as if the write succeeded* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:173-216`, method `post()` |
| **Root cause** | The voucher is created only inside `if ($debitLedgerId && $creditLedgerId) { ... if ($rcpType) { ... } }`. When a receiving ledger, an income ledger or a receipt voucher type is missing — and always for `mode = In_Kind`, which sets `$debitLedgerId = null` — execution falls through to lines 214-216 and saves `status = 'Posted'` with `voucher_id` still `NULL`. |
| **Consequence** | The receipt says Posted and prints as an 80G receipt, but no income reaches the ledger; the two live donations are already Posted with `voucher_id = NULL`, so the books understate donation income. |
| **Reproduce** | Record a donation with mode `In_Kind`, then press Post. The green flash says "posted successfully"; `/accounting/donation/{id}` shows "Receipt Voucher Pending" while the status badge says Posted. |
| **Fix approach** | Resolve both ledgers and the receipt type first; throw `DomainException` (the class is already imported at line 9) when any is missing, so the transaction rolls back and the receipt stays Draft. |
| **Plan item** | DNAT-03 in `02-fix-plan.md` §3 |

```php
// DonationController.php:173-216 — CURRENT
            if ($debitLedgerId && $creditLedgerId) {
                $rcpType = VoucherType::where('base_type', 'Receipt')->where('is_active', true)->first()
                    ?? VoucherType::where('base_type', 'Receipt')->first()
                    ?? VoucherType::where(function ($q) {
                        $q->whereIn('code', ['RECEIPT', 'RCP', 'RCT'])
                          ->orWhere('code', 'like', 'RCP%')
                          ->orWhere('code', 'like', 'RCT%')
                          ->orWhere('name', 'like', '%Receipt%');
                    })->first()
                    ?? VoucherType::where('is_active', true)->first();

                if ($rcpType) {
                    $voucher = $this->voucherService->create([
                        'voucher_type_id'   => $rcpType->id,
                        'financial_year_id' => $donation->financial_year_id,
                        'period_id'         => $donation->period_id,
                        'campus_id'         => $donation->campus_id,
                        'voucher_date'      => $donation->donation_date->format('Y-m-d'),
                        'narration'         => "Donation receipt {$donation->receipt_no} ({$donation->donation_nature}) from " . ($donation->donor_name ?? 'Donor'),
                        'party_ledger_id'   => $donation->donor_ledger_id,
                        'status'            => 'draft',
                    ], [
                        [
                            'ledger_id'  => $debitLedgerId,
                            'entry_type' => 'Dr',
                            'amount'     => (float) $donation->amount,
                            'narration'  => "Received via {$donation->mode}" . ($donation->instrument_no ? " #{$donation->instrument_no}" : ''),
                        ],
                        [
                            'ledger_id'  => $creditLedgerId,
                            'entry_type' => 'Cr',
                            'amount'     => (float) $donation->amount,
                            'narration'  => "Donation income/corpus: {$donation->purpose}",
                        ],
                    ]);

                    $this->voucherService->post($voucher->fresh());
                    $donation->voucher_id = $voucher->id;
                }
            }

            $donation->status = 'Posted';
```

**Evidence**
```
PS> php "$env:TEMP\perm-probe2.php"      # select id,receipt_no,status,voucher_id from acc_donations
{"id":1,"receipt_no":"80G\/2026-27\/0001","status":"Posted","amount":"251000.00","mode":"NEFT","is_80g_eligible":1,"voucher_id":null}
{"id":2,"receipt_no":"80G\/2026-27\/0002","status":"Posted","amount":"50000.00","mode":"Cheque","is_80g_eligible":1,"voucher_id":null}
```

### F2 — Transactions and audit

#### DNAT-04 · M · TXN-02 — Three manual transactions instead of `DB::transaction()`

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual begin/commit/rollBack* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:68-78` (`store()`), `:118-128` (`update()`), `:143-225` (`post()`) |
| **Root cause** | Each method opens a transaction by hand, commits inside the `try`, and rolls back in the `catch`. The pattern leaks an open transaction on any early `return` between begin and commit and cannot express "return data, then build the response". |
| **Consequence** | A future early return inside one of these blocks leaves a dangling transaction on the connection; the response is built before the transaction closes, which is why the redirects sit inside the `try`. |
| **Reproduce** | Static only — the current bodies have no early return, so the leak is latent. |
| **Fix approach** | Replace each with `DB::transaction(function () { ... });` and build the redirect after the closure, as shown in DNAT-01 / DNAT-03 / DNAT-04. |
| **Plan item** | DNAT-01 (store), DNAT-03 (post), DNAT-04 (update) in `02-fix-plan.md` |

```php
// DonationController.php:143-145 — CURRENT
        DB::beginTransaction();
        try {
            // Find cash/bank receiving ledger
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'beginTransaction|DB::commit|DB::rollBack' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
68:DB::beginTransaction();
71:DB::commit();
76:DB::rollBack();
118:DB::beginTransaction();
121:DB::commit();
126:DB::rollBack();
143:DB::beginTransaction();
218:DB::commit();
223:DB::rollBack();
```

#### DNAT-05 · M · TXN-04 — No mutation writes an activity-log row

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php` — all nine mutating methods: `store()` 70, `update()` 120, `post()` 185-216, `issueCertificate()` 236, `cancel()` 267, `toggleStatus()` 281, `destroy()` 294, `restore()` 313, `forceDelete()` 323 |
| **Root cause** | The controller never calls the global `activityLog()` helper; every sibling Accounting controller does (for example `AccountGroupController.php:44`). |
| **Consequence** | Nobody can answer "who cancelled receipt 0002, and when?" — a cancelled 80G receipt leaves no audit trail even though the number is preserved precisely for audit purposes (BR-DON-02). |
| **Reproduce** | Cancel a donation, then open `/accounting/audit-log` (or query `sys_activity_logs`); no row for the donation exists. |
| **Fix approach** | Add one `activityLog($donation, '<Event>', ['message' => …])` inside each write, after the write. Events: `Created`, `Updated`, `Posted`, `Certificate Issued`, `Cancelled`, `Toggled`, `Trashed`, `Restored`, `Deleted`. |
| **Plan item** | DNAT-05 in `02-fix-plan.md` §3 |

```php
// DonationController.php:236-239 — CURRENT (the only trace of the write is the row itself)
        $donation->update([
            'certificate_issued_at' => now(),
            'updated_by'            => auth()->id(),
        ]);
```

**Evidence**
```
PS> (Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'activityLog').Count
0
```

#### DNAT-06 · H · TXN-06 — The receipt-sequence lock is taken outside the transaction

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index; `lockForUpdate()` only works inside a transaction* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:55-63`, with the transaction opened at `:68` |
| **Root cause** | `Donation::…->lockForUpdate()->max('receipt_sequence')` runs on line 56, twelve lines before `DB::beginTransaction()`. In autocommit mode MySQL releases the lock immediately, so two concurrent creates read the same max and compute the same `receipt_sequence`. |
| **Consequence** | Two clerks saving a receipt at the same moment produce the same number; the second insert hits `uq_acc_don_sequence` and, because of DNAT-01, the user sees the raw duplicate-key SQL. |
| **Reproduce** | Static only — a race needs two concurrent requests. The SQL proof of the lock order is in the evidence. |
| **Fix approach** | Move the numbering inside the transaction and serialise on the financial-year row (`FinancialYear::whereKey(...)->lockForUpdate()`), as shown in DNAT-01. |
| **Plan item** | DNAT-01 in `02-fix-plan.md` §1 |

```php
// DonationController.php:54-63 — CURRENT
        // Sequential 80G numbering per FY under row lock
        if (empty($validated['receipt_no']) || empty($validated['receipt_sequence'])) {
            $maxSeq = (int) Donation::where('financial_year_id', $fyId)->lockForUpdate()->max('receipt_sequence');
            $nextSeq = $maxSeq + 1;
            $validated['receipt_sequence'] = $nextSeq;

            $fy = FinancialYear::find($fyId);
            $fyCode = $fy?->code ?? Carbon::now()->format('Y');
            $validated['receipt_no'] = sprintf('80G/%s/%04d', $fyCode, $nextSeq);
        }
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'lockForUpdate|beginTransaction' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
56:$maxSeq = (int) Donation::where('financial_year_id', $fyId)->lockForUpdate()->max('receipt_sequence');
68:DB::beginTransaction();
```

### F3 — Authorization

#### DNAT-07 · B · AUTH-01 — The donation permissions do not exist, so every method 403s for non-super-admins

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B) — *every routed method authorizes with a permission that exists* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:28,35,83,92,102,133,230,247,256,279,288,302,311,321` |
| **Root cause** | `config/permissionslist.php` is the single producer of tenant permission names, and it has no `accounting.donation` key (the Accounting block runs `'accounting.account-group'` … `'accounting.event-posting'` with no donation row). Consequently no `tenant.accounting.donation.*` row is seeded: the tenant database holds 312 `tenant.accounting.%` permissions, none of them donation. The blade hides the tab with the same missing string at `school-specific.blade.php:18`. |
| **Consequence** | Account Manager, Account Staff, Management and School Admin can open School & Grants but cannot see or use the Donations tab at all; only Super Admin reaches the screen, through the `Gate::before` bypass. |
| **Reproduce** | Sign in as School Admin and open `/accounting/school-specific?tab=donations`. The tab is absent, and a direct visit to `/accounting/donation` returns 403. |
| **Fix approach** | Add `'accounting.donation' => array_merge($crud, ['post', 'cancel', 'issueCertificate'])` to `config/permissionslist.php`, then run `/system-config/sync-permissions`. This is a shared-file, new-key change, so it is a DECISION. |
| **Plan item** | DNAT-07 in `02-fix-plan.md` §9 (DECISION) |

```php
// DonationController.php:28 — CURRENT (one of fourteen identical strings)
        Gate::authorize('tenant.accounting.donation.viewAny');
```

**Evidence**
```
PS> Select-String -Path config\permissionslist.php -Pattern 'donation' -SimpleMatch
(no output)

PS> php "$env:TEMP\perm-probe2.php"      # exact-name SQL on the tenant DB
count=0
-- exact viewAny: 0
```

#### DNAT-08 · M · AUTH-06 — Fourteen permission literals and no DonationPolicy

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place, not repeated as literals* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:28,35,83,92,102,133,230,247,256,279,288,302,311,321` |
| **Root cause** | Each method repeats the `tenant.accounting.donation.*` string; `Modules/Accounting/app/Policies/` has no `DonationPolicy`, and no `Gate::define` names a donation ability. |
| **Consequence** | A permission rename needs fourteen edits in this file plus the views, and a typo in any one of them is invisible until that action 403s. |
| **Reproduce** | Static only — the count is the proof. |
| **Fix approach** | Introduce a `DonationPolicy` (or string constants) and route every check through it. Behaviour-neutral refactor, so it is a DECISION. |
| **Plan item** | DNAT-08 in `02-fix-plan.md` §9 (DECISION) |

```php
// DonationController.php:133 — CURRENT
        Gate::authorize('tenant.accounting.donation.post');
```

**Evidence**
```
PS> (Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'tenant\.accounting\.donation').Count
14
PS> Get-ChildItem Modules\Accounting\app\Policies | Where-Object { $_.Name -match 'Donation' }
(no output)
```

### F4 — Validation and input

#### DNAT-09 · H · VAL-04 — The sequence ignores trashed rows but the unique index includes them

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness must mirror the real DB index, including soft-delete semantics* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:56`; index at `database/migrations/tenant/2026_09_16_100044_create_acc_donations_table.php:59` |
| **Root cause** | `Donation::where(...)->max('receipt_sequence')` carries the `SoftDeletes` global scope, so trashed rows are ignored. The database index `uq_acc_don_sequence` is a plain unique key over `(financial_year_id, receipt_sequence)` and **does** include trashed rows. |
| **Consequence** | Delete the highest draft receipt, create a new one: the new receipt gets the deleted row's sequence, the insert hits the unique index, and the user sees the raw duplicate-key SQL. Restoring that deleted row later fails the same way. |
| **Reproduce** | Trash the newest Draft receipt, record another donation on the same date. Expected a new number; actual red flash with `Duplicate entry ... for key 'uq_acc_don_sequence'`. |
| **Fix approach** | Compute the max over `Donation::withTrashed()` inside the transaction, as shown in DNAT-01. |
| **Plan item** | DNAT-01 in `02-fix-plan.md` §1 |

```php
// DonationController.php:56 — CURRENT
            $maxSeq = (int) Donation::where('financial_year_id', $fyId)->lockForUpdate()->max('receipt_sequence');
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'withTrashed|onlyTrashed|->max\(' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
56:$maxSeq = (int) Donation::where('financial_year_id', $fyId)->lockForUpdate()->max('receipt_sequence');
304:$donations = Donation::onlyTrashed()->with(['donorLedger', 'financialYear'])->paginate(25);
313:$donation = Donation::onlyTrashed()->findOrFail($id);
323:$donation = Donation::onlyTrashed()->findOrFail($id);

PS> Select-String -Path database\migrations\tenant\2026_09_16_100044_create_acc_donations_table.php -Pattern "uq_acc_don_sequence" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
59:$table->unique(['financial_year_id', 'receipt_sequence'], 'uq_acc_don_sequence');
```

#### DNAT-10 · M · VAL-05 — The statutory receipt number and sequence are accepted from the request

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed and business-controlled; statutory numbering is not user input* |
| **Where** | `Modules/Accounting/app/Http/Requests/DonationRequest.php:21-22` |
| **Root cause** | `receipt_no` (string, max 50) and `receipt_sequence` (integer, min 1) are validated as ordinary optional input. In `store()` the whole numbering block is skipped when either is non-empty, so a crafted request sets any number it likes. |
| **Consequence** | A user can skip a receipt number, reuse another receipt's number in the same FY, or jump the sequence, defeating the gap watch that BR-DON-02 exists to protect. |
| **Reproduce** | Static only — the create modal does not expose these fields, so it needs a hand-crafted POST. |
| **Fix approach** | Delete both rules; the server assigns both values inside the store transaction (DNAT-01). |
| **Plan item** | DNAT-10 in `02-fix-plan.md` §5 |

```php
// DonationRequest.php:21-22 — CURRENT
            'receipt_no'            => ['nullable', 'string', 'max:50'],
            'receipt_sequence'      => ['nullable', 'integer', 'min:1'],
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Requests\DonationRequest.php -Pattern 'receipt_no|receipt_sequence' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
21:'receipt_no'            => ['nullable', 'string', 'max:50'],
22:'receipt_sequence'      => ['nullable', 'integer', 'min:1'],
```

#### DNAT-11 · M · VAL-02 — `cancel()` validates inline instead of in a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a FormRequest; inline `validate()` only for a one-field AJAX toggle* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:258-260`, method `cancel()` |
| **Root cause** | The cancellation reason is a required textarea on a normal form POST, but it is validated in the controller. The module's other writes all use FormRequests. |
| **Consequence** | The rule cannot be reused by any other cancel surface, and the controller keeps a validation concern that the future `cancel()` rewrite (DNAT-34) would have to carry. |
| **Reproduce** | Static only — submit the cancel form with an empty reason and observe the framework redirect, not a page-level rule. |
| **Fix approach** | Add `DonationCancelRequest` with the same rule and type-hint it in `cancel()`. |
| **Plan item** | DNAT-11 in `02-fix-plan.md` §5 |

```php
// DonationController.php:258-260 — CURRENT
        $request->validate([
            'cancelled_reason' => 'required|string|max:500',
        ]);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern '->validate\(' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
258:$request->validate([
```

#### DNAT-12 · H · VAL-07 — In-kind donations never set `is_in_kind`, so the valuation rule and the DB check are unreachable

| Field | Value |
|---|---|
| **Rule** | VAL-07 (H) — *cross-field business checks run in the FormRequest; the check keys on a field the form never sends* |
| **Where** | `Modules/Accounting/app/Http/Requests/DonationRequest.php:61-66`; create modal `Modules/Accounting/resources/views/pages/partials/school-specific/_donations.blade.php:361-367` (mode) with no `is_in_kind` control anywhere |
| **Root cause** | The rule requires `valuation_basis` when `is_in_kind` is true, but the form only sets `mode = In_Kind`; it never posts `is_in_kind`. The validated payload therefore carries `is_in_kind = false` (the column default), the after-hook never fires, and the DDL check `chk_acc_don_in_kind` never runs, while `mode` records the donation as in kind. |
| **Consequence** | An in-kind donation is accepted with no valuation basis (BR-DON-04) and is stored as not-in-kind, so `post()` skips its debit ledger and no voucher is created (DNAT-03). |
| **Reproduce** | Record a donation with mode `In_Kind` and leave Valuation Basis empty; it saves. Expected a validation error on Valuation Basis. |
| **Fix approach** | In the modal, set `is_in_kind` from the selected mode (a hidden input updated by the existing `toggleInKind()` script), and keep the request rule. Both changes must land together or the CHECK constraint will reject the insert. |
| **Plan item** | DNAT-12 in `02-fix-plan.md` §2 |

```php
// DonationRequest.php:61-66 — CURRENT
            $isInKind = filter_var($this->input('is_in_kind'), FILTER_VALIDATE_BOOLEAN);
            $valuationBasis = $this->input('valuation_basis');

            if ($isInKind && empty($valuationBasis)) {
                $validator->errors()->add('valuation_basis', 'Valuation basis is mandatory for donations in kind.');
            }
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\resources\views\pages\partials\school-specific\_donations.blade.php -Pattern 'is_in_kind' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
(no output)

PS> Select-String -Path Modules\Accounting\resources\views\pages\partials\school-specific\_donations.blade.php -Pattern 'name="mode"' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
361:<select name="mode" id="don_mode" class="form-select form-select-sm" required>
```

### F5 — Routes

#### DNAT-13 · B · RTE-02 — The `create` route points at a method that does not exist

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *every route points to a method that exists* |
| **Where** | `Modules/Accounting/routes/web.php:518` (`Route::resource('donation', DonationController::class)`), registered action `DonationController@create`; the class has no `create()` method |
| **Root cause** | The resource route auto-registers `create`, but the controller only has `index`, `store`, `show`, `edit`, `update`, `destroy`. The screen creates receipts through a modal, so the page method was never written. |
| **Consequence** | Any visit to `http://test.localhost:8000/accounting/donation/create` throws `BadMethodCallException` and renders a 500 instead of a page. |
| **Reproduce** | Open `/accounting/donation/create` while signed in as Super Admin. Expected a form; actual 500. |
| **Fix approach** | Add a `create()` method that authorizes the same permission and redirects to the list tab where the create modal lives. No route change is needed. |
| **Plan item** | DNAT-13 in `02-fix-plan.md` §1 |

```php
// routes/web.php:518 — CURRENT
Route::resource('donation', DonationController::class);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'function create' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
(no output)

PS> Select-String -Path Modules\Accounting\routes\web.php -Pattern "Route::resource\('donation'" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
518:Route::resource('donation', DonationController::class);
```

#### DNAT-14 · H · RTE-01 — `GET /accounting/donation/{id}/restore` changes state

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:511`; the link is `Modules/Accounting/resources/views/donation/trash.blade.php:40` |
| **Root cause** | `restore` is registered with `Route::get` and the trash page renders it as a plain `<a href>`, so restoring a receipt is a GET. |
| **Consequence** | A browser prefetch, a crawler or a shared link can restore a deleted receipt without a CSRF token; the action is also repeatable by reload. |
| **Reproduce** | Open `/accounting/donation/trash/view` and refresh the page after clicking Restore; the GET re-runs the restore. |
| **Fix approach** | Register the route as `POST` and turn the trash link into a CSRF form. This edits a shared route file, so it is a DECISION. |
| **Plan item** | DNAT-14 in `02-fix-plan.md` §9 (DECISION) |

```php
// routes/web.php:511 — CURRENT
Route::get('/donation/{id}/restore', [DonationController::class, 'restore'])->name('donation.restore');
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\routes\web.php -Pattern "donation.*restore" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
511:Route::get('/donation/{id}/restore', [DonationController::class, 'restore'])->name('donation.restore');

PS> Select-String -Path Modules\Accounting\resources\views\donation\trash.blade.php -Pattern 'donation.restore' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
40:<a href="{{ route('accounting.donation.restore', $item->id) }}" class="btn btn-xs btn-outline-success" title="Restore">
```

### F6 — Controller shape

#### DNAT-15 · M · CTL-02 — `post()` is 96 lines long

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *a method over 80 lines is extracted; over 150 is H* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:131-226`, method `post()` |
| **Root cause** | Ledger resolution, voucher-type fallback, voucher creation, posting, donation update and the response are all inline in one method. |
| **Consequence** | The method cannot be tested or reused, and every change to the posting rule re-opens a 96-line body. |
| **Reproduce** | Static only — the line span is the proof. |
| **Fix approach** | Extract the ledger/voucher work to a service. That is the CTL-06 decision DNAT-16; a mechanical split would leave the same logic in the controller. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// DonationController.php:131 and 226 — CURRENT
    public function post(Donation $donation): RedirectResponse
```
```php
    }
```

**Evidence**
```
PS> (Get-Content Modules\Accounting\app\Http\Controllers\DonationController.php)[130..225].Count
96
```

#### DNAT-16 · M · CTL-06 — Ledger resolution and posting logic sit in the controller

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in services/actions; the controller reads input, calls one service, returns a response* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:145-216`, method `post()` |
| **Root cause** | The controller searches for cash/bank, income/corpus and receipt-type ledger rows with `like` patterns, then composes the voucher payload and posts it. `VoucherService` already owns voucher creation and posting, but not "post this donation". |
| **Consequence** | The donation posting rule exists only in an HTTP controller, so any second surface (an import, a job, a bulk post) must copy it and will drift. |
| **Reproduce** | Static only. |
| **Fix approach** | Extract a `DonationPostingService` with one `post(Donation): Voucher` method. This is a design change, so it is a DECISION (defer per D3, or extract now). |
| **Plan item** | DNAT-16 in `02-fix-plan.md` §9 (DECISION) |

```php
// DonationController.php:148 — CURRENT
                $debitLedgerId = Ledger::where('is_active', true)->where('ledger_type', 'Cash')->value('id');
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'Ledger::where' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
148:$debitLedgerId = Ledger::where('is_active', true)->where('ledger_type', 'Cash')->value('id');
150:$debitLedgerId = Ledger::where('is_active', true)->where('ledger_type', 'Bank')->value('id');
157:$creditLedgerId = Ledger::where('is_active', true)
163:$creditLedgerId = Ledger::where('is_active', true)
```

#### DNAT-17 · M · CTL-05 — The cash-over-2000 rule is duplicated in `store()` and `update()`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste blocks* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:49-52` and `:112-114` |
| **Root cause** | The same 80G cash rule is written twice, with the comment only on the first copy. |
| **Consequence** | A change to the statutory threshold (₹2,000) applied to one copy silently leaves the other accepting ineligible receipts. |
| **Reproduce** | Static only. |
| **Fix approach** | Extract the rule to one place (a model mutator or the posting service). It is the same extraction as DNAT-16. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// DonationController.php:49-52 — CURRENT
        // Cash donations > 2000 are not 80G eligible
        if ($mode === 'Cash' && $amount > 2000.0) {
            $validated['is_80g_eligible'] = false;
        }
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern "mode === 'Cash'" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
50:if ($mode === 'Cash' && $amount > 2000.0) {
112:if ($mode === 'Cash' && $amount > 2000.0) {
```

#### DNAT-18 · L · CTL-03 — `restore()` and `forceDelete()` use `$id` + `findOrFail()`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (L) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:309-314` and `:319-324` |
| **Root cause** | The routes pass `{id}` and the methods open with `Donation::onlyTrashed()->findOrFail($id)`, while every other method uses `Donation $donation`. |
| **Consequence** | A missing id is a framework 404 rather than a scoped route binding, and the trash lookup is duplicated in two methods. |
| **Reproduce** | Static only. |
| **Fix approach** | Type-hint `Donation $donation` and use `->withTrashed()` on the binding if the route is renamed; with the current `{id}` routes the signature must change together with the route. Low priority. |
| **Plan item** | none — see `02-fix-plan.md` §10 (folded into DNAT-14) |

```php
// DonationController.php:309-314 — CURRENT
    public function restore(int $id): RedirectResponse
    {
        Gate::authorize('tenant.accounting.donation.delete');

        $donation = Donation::onlyTrashed()->findOrFail($id);
        $donation->restore();
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'onlyTrashed\(\)->findOrFail' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
313:$donation = Donation::onlyTrashed()->findOrFail($id);
323:$donation = Donation::onlyTrashed()->findOrFail($id);
```

#### DNAT-19 · L · CTL-04 — Five public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:26` (`index`), `:81` (`show`), `:90` (`edit`), `:245` (`certificate`), `:300` (`trashed`) |
| **Root cause** | The five render/redirect methods were written without a return type; the nine newer methods have one. |
| **Consequence** | A wrong return type is a runtime `TypeError` instead of a static error, and the reader cannot see what each method returns. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `: RedirectResponse` to `index`, `: View` to `show`, `edit`, `certificate`, `trashed`. |
| **Plan item** | DNAT-29 in `02-fix-plan.md` §8 (bundles this with DNAT-20) |

```php
// DonationController.php:26 — CURRENT
    public function index(Request $request)
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'public function (index|show|edit|certificate|trashed)\(' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
26:public function index(Request $request)
81:public function show(Donation $donation)
90:public function edit(Donation $donation)
245:public function certificate(Donation $donation)
300:public function trashed()
```

#### DNAT-20 · L · CTL-10 — `index()` takes a `Request` it never reads

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *dead code: unused parameters* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:26` |
| **Root cause** | `index(Request $request)` ignores `$request`; the method only redirects. |
| **Consequence** | The signature suggests the page reads filters that it does not. |
| **Reproduce** | Static only. |
| **Fix approach** | Drop the parameter; the route still resolves. |
| **Plan item** | DNAT-29 in `02-fix-plan.md` §8 (bundles this with DNAT-19) |

```php
// DonationController.php:26-31 — CURRENT
    public function index(Request $request)
    {
        Gate::authorize('tenant.accounting.donation.viewAny');

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'donations']);
    }
```

**Evidence**
```
PS> (Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern '\$request' | Where-Object { $_.LineNumber -lt 33 }).Count
1
```

### F7 — Models

#### DNAT-21 · M · MDL-01 — `is_active` is not fillable, so `toggleStatus()` silently does nothing

| Field | Value |
|---|---|
| **Rule** | MDL-01 (M raised from the rulebook default H: no screen control reaches this route today, so the lie is latent) — *`$fillable` declared and complete for the columns the app writes* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:277-284`; `Modules/Accounting/app/Models/Donation.php:18-50` |
| **Root cause** | `Donation::$fillable` lists 31 columns and omits `is_active`, which the later migration adds. `$donation->update(['is_active' => …])` therefore mass-assigns nothing (the project does not enable `preventSilentlyDiscardingAttributes`), and `save()` has no dirty attribute to write. |
| **Consequence** | The flash says "Donation status updated." while the row is unchanged; the method is a dead feature — no view has a control that posts to it either. |
| **Reproduce** | `POST /accounting/donation/1/toggle-status` as Super Admin, then re-open the donation: `is_active` is unchanged, the page says success. |
| **Fix approach** | Add `is_active` to `$fillable` and cast it to `boolean` (DNAT-22). |
| **Plan item** | DNAT-21 in `02-fix-plan.md` §5 |

```php
// DonationController.php:277-284 — CURRENT
    public function toggleStatus(Donation $donation): RedirectResponse
    {
        Gate::authorize('tenant.accounting.donation.update');

        $donation->update(['is_active' => !$donation->is_active]);

        return redirect()->back()->with('success', 'Donation status updated.');
    }
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Models\Donation.php -Pattern 'is_active' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
143:return $query->where('is_active', true);
```

#### DNAT-22 · M · MDL-02 — `is_active` has no boolean cast

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` cover every boolean, date, decimal and JSON column* |
| **Where** | `Modules/Accounting/app/Models/Donation.php:52-60` |
| **Root cause** | The `$casts` array covers `is_anonymous`, `is_in_kind` and `is_80g_eligible` but not `is_active`, which the table adds. |
| **Consequence** | `is_active` comes back as `0`/`1` instead of `true`/`false`; any strict comparison or JSON output treats `1` differently from `true`. |
| **Reproduce** | Static only — the cast block is the proof. |
| **Fix approach** | Add `'is_active' => 'boolean'`; the DNAT-21 item does this in the same edit. |
| **Plan item** | DNAT-21 in `02-fix-plan.md` §5 |

```php
// Donation.php:52-60 — CURRENT
    protected $casts = [
        'donation_date'        => 'date',
        'amount'               => 'decimal:2',
        'is_anonymous'         => 'boolean',
        'is_in_kind'           => 'boolean',
        'is_80g_eligible'      => 'boolean',
        'certificate_issued_at'=> 'datetime',
        'receipt_sequence'     => 'integer',
    ];
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Models\Donation.php -Pattern "'is_active' =>" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
(no output)
```

#### DNAT-23 · L · MDL-04 — The eight scopes have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship/scope methods are return-typed* |
| **Where** | `Modules/Accounting/app/Models/Donation.php:106-144` |
| **Root cause** | Every `scope*` method is declared as `public function scopeDraft($query)` with no `: Builder` return type and an untyped `$query`. |
| **Consequence** | A broken scope is a runtime error, and the model is inconsistent with the typed relations above it. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `: Builder` (import `Illuminate\Database\Eloquent\Builder`) and `Builder $query` to the eight scopes. |
| **Plan item** | DNAT-23 in `02-fix-plan.md` §5 |

```php
// Donation.php:106-109 — CURRENT
    public function scopeDraft($query)
    {
        return $query->where('status', 'Draft');
    }
```

**Evidence**
```
PS> (Select-String -Path Modules\Accounting\app\Models\Donation.php -Pattern 'public function scope').Count
8
```

#### DNAT-24 · L · MDL-09 — Status, nature and mode literals are repeated across controller and model

| Field | Value |
|---|---|
| **Rule** | MDL-09 (L) — *status/type strings are PHP enums or model constants, not literals repeated across files* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:66,104,135,139,214,262,268,290`; the model already exposes `statuses()`, `donationNatures()` and `modes()` at `Donation.php:148-161` |
| **Root cause** | The controller compares and writes `'Draft'`, `'Posted'` and `'Cancelled'` as string literals, ignoring the helpers it already imports the model for. |
| **Consequence** | A new status or a spelling change is a search-and-replace across the controller and views with no compiler help. |
| **Reproduce** | Static only. |
| **Fix approach** | Introduce constants or a backed enum and replace the literals. This is a style refactor that touches the views too; deferred to the enum pass. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// DonationController.php:104 — CURRENT
        if (in_array($donation->status, ['Posted', 'Cancelled'], true)) {
```

**Evidence**
```
PS> (Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern "'Posted'|'Cancelled'|'Draft'").Count
9
```

#### DNAT-25 · L · CTL-10 — `Donation` re-declares `use SoftDeletes` already applied by its parent

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *dead code* |
| **Where** | `Modules/Accounting/app/Models/Donation.php:14`; parent `Modules/Accounting/app/Models/BaseAccountingModel.php:14` |
| **Root cause** | `BaseAccountingModel` already applies `SoftDeletes`; the child applies it again. |
| **Consequence** | Duplicate trait bootstrapping, and a reader cannot tell which class owns the soft-delete behaviour. |
| **Reproduce** | Static only. |
| **Fix approach** | Delete line 14 and the `SoftDeletes` import. Folded into the model style item. |
| **Plan item** | DNAT-31 in `02-fix-plan.md` §8 |

```php
// Donation.php:12-16 — CURRENT
class Donation extends BaseAccountingModel
{
    use SoftDeletes;

    protected $table = 'acc_donations';
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Models\Donation.php,Modules\Accounting\app\Models\BaseAccountingModel.php -Pattern 'use SoftDeletes' | ForEach-Object { "$($_.Filename):$($_.LineNumber):$($_.Line.Trim())" }
Donation.php:14:use SoftDeletes;
BaseAccountingModel.php:14:use SoftDeletes;
```

### F8 — Services and jobs

clean — `Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'Service|Job|dispatch'` → only `VoucherService` (import line 20, constructor line 24, calls at 185 and 209). `VoucherService::create()` already wraps its own `DB::transaction` and writes `acc_audit_logs`, so this controller adds no un-transactioned second write. No HTTP, no cache, no job.

### F9 — Queries and performance

#### DNAT-26 · M · QRY-15 — `edit()` loads every active ledger and fund with every column

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *do not load every row of a big table for a form; select only the columns used* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:94-95` |
| **Root cause** | Two unfiltered `get()` calls with the default `SELECT *`; the edit view reads only `id` and `name` from each. |
| **Consequence** | The edit page hydrates all 56 active ledger rows (408-line model, many columns) and all 4 funds for two dropdowns; the ledger table grows with every school. |
| **Reproduce** | Open `/accounting/donation/1/edit` with query logging on; two full-row selects run on every edit page load. |
| **Fix approach** | `->get(['id', 'name'])` on both queries. The shared list page has the same pattern but it belongs to `AccDashboardController` (cross-cutting). |
| **Plan item** | DNAT-26 in `02-fix-plan.md` §6 |

```php
// DonationController.php:94-95 — CURRENT
        $donorLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
        $funds = Fund::where('is_active', true)->orderBy('name')->get();
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'orderBy\(.name.\)->get\(\)' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
94:$donorLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
95:$funds = Fund::where('is_active', true)->orderBy('name')->get();
```

#### DNAT-27 · M · QRY-02 — The trash list paginates at 25, not the module's 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M) — *lists paginate; the protocol fixes the page size at 10* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:304` |
| **Root cause** | `paginate(25)` uses the default page name; the protocol (F9/C12) requires 10 rows per page and a distinct page name per list. |
| **Consequence** | Up to 25 trashed receipts render per page, against the module standard, and the page size is inconsistent with the sibling lists. |
| **Reproduce** | Open `/accounting/donation/trash/view` with more than 10 trashed rows. |
| **Fix approach** | `paginate(10, ['*'], 'donation_trash_page')`. |
| **Plan item** | DNAT-27 in `02-fix-plan.md` §6 |

```php
// DonationController.php:304 — CURRENT
        $donations = Donation::onlyTrashed()->with(['donorLedger', 'financialYear'])->paginate(25);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'paginate' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
304:$donations = Donation::onlyTrashed()->with(['donorLedger', 'financialYear'])->paginate(25);
```

### F10 — Views

#### DNAT-28 · H · VIEW-02 — The 80G certificate prints `$donation->pan`, a column that does not exist

| Field | Value |
| --- | --- |
| **Rule** | VIEW-02 (H raised from M: a missing PAN on a printed 80G certificate is a wrong legal document, not a style issue) — *a property that does not exist is silent forever* |
| **Where** | `Modules/Accounting/resources/views/donation/certificate.blade.php:47-48` |
| **Root cause** | The column is `donor_pan`; the blade reads `$donation->pan`. Eloquent returns `null` for an unknown attribute, so the condition falls back to `$donation->donorLedger?->pan`. When the donation has a PAN but no linked ledger (the normal case for a one-off donor), nothing prints. |
| **Consequence** | The certificate omits the donor PAN even though it was entered and stored — a 80G receipt that does not meet the PAN requirement. |
| **Reproduce** | Record a donation with Donor PAN `ABCDE1234F` and no Donor Ledger, post it, issue the certificate, and open `/accounting/donation/{id}/certificate`. The PAN line is absent. |
| **Fix approach** | Read `$donation->donor_pan` in both places. |
| **Plan item** | DNAT-28 in `02-fix-plan.md` §7 |

```php
// certificate.blade.php:47-48 — CURRENT
                        @if($donation->pan || $donation->donorLedger?->pan)
                            (PAN: <span class="font-monospace fw-bold">{{ $donation->pan ?: $donation->donorLedger?->pan }}</span>)
                        @endif
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\resources\views\donation\certificate.blade.php -Pattern '\$donation->pan' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
47:@if($donation->pan || $donation->donorLedger?->pan)
48:(PAN: <span class="font-monospace fw-bold">{{ $donation->pan ?: $donation->donorLedger?->pan }}</span>)

PS> Select-String -Path database\migrations\tenant\2026_09_16_100044_create_acc_donations_table.php -Pattern 'donor_pan' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
31:$table->string('donor_pan', 15)->nullable();
```

### F11 — Security and tenancy

clean — `Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'env\(|Log::|DB::raw|whereRaw|orderByRaw|\?\? 1'` → no output. The model extends `BaseAccountingModel`, which runs on the tenant connection and resolves context on create; no cache or static state is used; no uploads or file serving. Donor PII is rendered only on the permission-gated show/certificate views.

### F12 — Style

#### DNAT-29 · L · STY-02 — `DonationController.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php` |
| **Root cause** | Nine fixers apply: `function_declaration`, `concat_space`, `method_chaining_indentation`, `braces_position`, `no_unused_imports`, `not_operator_with_successor_space`, `single_line_empty_body`, `blank_line_before_statement`, `binary_operator_spaces`. |
| **Consequence** | The file does not match the project's formatter, so every later edit produces unrelated diff noise. |
| **Reproduce** | Run the Verify command in the plan item. |
| **Fix approach** | Run Pint on this file only, after the code changes. |
| **Plan item** | DNAT-29 in `02-fix-plan.md` §8 |

```php
// DonationController.php:24 — CURRENT (one-line body is the first fixer hit)
    public function __construct(private readonly VoucherService $voucherService) {}
```

**Evidence**
```
PS> vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\DonationController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\DonationController.php","fixers":["function_declaration","concat_space","method_chaining_indentation","braces_position","no_unused_imports","not_operator_with_successor_space","single_line_empty_body","blank_line_before_statement","binary_operator_spaces"]}]}
```

#### DNAT-30 · L · STY-02 — `DonationRequest.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Http/Requests/DonationRequest.php` |
| **Root cause** | `not_operator_with_successor_space` and `binary_operator_spaces` are flagged; the `!` and `=>` alignment miss the preset. |
| **Consequence** | Formatting noise on every future edit of the request. |
| **Reproduce** | Run the Verify command in the plan item. |
| **Fix approach** | Run Pint on this file only. |
| **Plan item** | DNAT-30 in `02-fix-plan.md` §8 |

```php
// DonationRequest.php:57 — CURRENT
            if (!$isAnonymous && empty($donorLedgerId) && empty($donorName)) {
```

**Evidence**
```
PS> vendor\bin\pint --test Modules\Accounting\app\Http\Requests\DonationRequest.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\DonationRequest.php","fixers":["not_operator_with_successor_space","binary_operator_spaces"]}]}
```

#### DNAT-31 · L · STY-02 — `Donation.php` is not Pint-clean and carries an unused import

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Models/Donation.php:7` |
| **Root cause** | `use App\Models\BaseModel;` is never referenced, and `binary_operator_spaces` flags the aligned casts. |
| **Consequence** | A misleading import suggests the model extends `BaseModel` directly; formatting drifts from the preset. |
| **Reproduce** | Run the Verify command in the plan item. |
| **Fix approach** | Run Pint, which removes the unused import; the same item deletes the redundant `use SoftDeletes` (DNAT-25). |
| **Plan item** | DNAT-31 in `02-fix-plan.md` §8 |

```php
// Donation.php:7 — CURRENT
use App\Models\BaseModel;
```

**Evidence**
```
PS> vendor\bin\pint --test Modules\Accounting\app\Models\Donation.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\Donation.php","fixers":["no_unused_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 Wrong data | Q2 Delete before store | Q3 Duplicate impl. | Q4 Soft-delete × unique | Q5 Race | Q6 Auth hole | Q7 Message lies | Q8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | DNAT-32, DNAT-33 | ok | DNAT-17 | DNAT-09 | DNAT-06 | DNAT-07 | ok | ok |
| `update` | ok | ok | DNAT-17 | ok | ok | DNAT-07 | ok | ok |
| `post` | DNAT-03 | ok | ok | ok | ok | DNAT-07 | DNAT-03 | ok |
| `issueCertificate` | DNAT-35 | ok | ok | ok | ok | DNAT-07 | ok | ok |
| `cancel` | DNAT-34 | ok | ok | ok | ok | DNAT-07 | ok | ok |
| `toggleStatus` | DNAT-21 | ok | ok | ok | ok | DNAT-07 | DNAT-21 | DNAT-21 |
| `destroy` | ok | ok | ok | DNAT-09 | ok | DNAT-07 | ok | ok |
| `restore` | ok | ok | DNAT-18 | DNAT-09 | ok | DNAT-07 | ok | ok |
| `forceDelete` | ok | ok | DNAT-18 | ok | ok | DNAT-07 | ok | ok |

#### DNAT-32 · H · F13-Q1 — A receipt is booked into the newest financial year, not the year of its date

| Field | Value |
|---|---|
| **Rule** | F13-Q1 (H) — *does any write put the record in the wrong place?* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:39-44`, method `store()` |
| **Root cause** | When the request omits `financial_year_id` (the create modal never sends it), the fallback is `FinancialYear::where('is_active', true)->orderByDesc('start_date')->first()`. All three live years have `is_active = 1`, so the query returns FY 2027-28 — a year that starts on 2027-04-01 — for a donation dated today. `BaseAccountingModel` cannot correct it because `financial_year_id` is now non-null. |
| **Consequence** | A receipt dated October 2026 is filed under FY 2027-28 and its voucher posts into a future year, so the 2026-27 books understate donations and the 2027-28 books open with unexplained income. |
| **Reproduce** | Record a donation with today's date, then open `/accounting/donation/{id}`; the linked financial year is FY 2027-28. |
| **Fix approach** | Resolve the year from `donation_date` with a `start_date <= date <= end_date` lookup inside the store transaction; reject a date no year covers with a validation error. |
| **Plan item** | DNAT-01 in `02-fix-plan.md` §1 |

```php
// DonationController.php:39-44 — CURRENT
        $fyId = $validated['financial_year_id'] ?? null;
        if (!$fyId) {
            $activeFy = FinancialYear::where('is_active', true)->orderByDesc('start_date')->first();
            $fyId = $activeFy?->id;
            $validated['financial_year_id'] = $fyId;
        }
```

**Evidence**
```
PS> php "$env:TEMP\fy-probe.php"      # acc_financial_years
id=1 name=FY 2025-26 start=2025-04-01 end=2026-03-31 is_current=0 is_active=1
id=2 name=FY 2026-27 start=2026-04-01 end=2027-03-31 is_current=1 is_active=1
id=3 name=FY 2027-28 start=2027-04-01 end=2028-03-31 is_current=0 is_active=1

PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern "orderByDesc\('start_date'\)" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
41:$activeFy = FinancialYear::where('is_active', true)->orderByDesc('start_date')->first();
```

#### DNAT-33 · M · F13-Q7 — The receipt prefix is the calendar year because `acc_financial_years` has no `code` column

| Field | Value |
|---|---|
| **Rule** | F13-Q7 (M) — *a message that lies: the number says one year, the row belongs to another* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:60-62` |
| **Root cause** | `$fy?->code` reads an attribute the table does not have, so it is always `null` and the `?? Carbon::now()->format('Y')` fallback always wins. Receipts created now are numbered `80G/2026/0001`, while the seeded series is `80G/2026-27/0001`. |
| **Consequence** | The statutory receipt number carries the calendar year instead of the financial year, so January 2027 receipts say `80G/2027/…` although they belong to FY 2026-27, and the series no longer matches the seeded one. |
| **Reproduce** | Record a donation in January 2027: the receipt reads `80G/2027/…`; the row's financial year is FY 2026-27. |
| **Fix approach** | Build the prefix from the year's `start_date` and `end_date` (`2026-27`), as shown in DNAT-01. |
| **Plan item** | DNAT-01 in `02-fix-plan.md` §1 |

```php
// DonationController.php:60-62 — CURRENT
            $fy = FinancialYear::find($fyId);
            $fyCode = $fy?->code ?? Carbon::now()->format('Y');
            $validated['receipt_no'] = sprintf('80G/%s/%04d', $fyCode, $nextSeq);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Models\FinancialYear.php -Pattern "'code'" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
(no output)

PS> php "$env:TEMP\fy-probe.php"      # show columns from acc_financial_years
id,name,start_date,end_date,is_current,current_flag,status,closed_at,closed_by,carry_forward_at,carry_forward_by,is_active,created_at,updated_at,deleted_at
```

#### DNAT-34 · H · F13-Q1 — Cancelling a posted donation leaves its posted voucher untouched

| Field | Value |
|---|---|
| **Rule** | F13-Q1 (H) — *a write that should reverse data instead only changes a status flag* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:254-275`, method `cancel()` |
| **Root cause** | `cancel()` writes `status = 'Cancelled'` and the reason, and never calls `VoucherService::cancel()` on `$donation->voucher_id`. The class imports the service only for `post()` (calls at lines 185 and 209). |
| **Consequence** | The receipt is cancelled but its Receipt voucher stays Posted, so the ledger still counts the income while the receipt says cancelled — and the 80G certificate can still be printed for a cancelled receipt. |
| **Reproduce** | Post a donation, cancel it, then open `/accounting/voucher/{voucher_id}`: the voucher is still Posted. |
| **Fix approach** | Cancel the linked voucher in the same transaction when it is Posted. Whether the voucher should be cancelled or reversed is a business answer, so it is a DECISION. |
| **Plan item** | DNAT-34 in `02-fix-plan.md` §9 (DECISION) |

```php
// DonationController.php:262-271 — CURRENT
        if ($donation->status === 'Cancelled') {
            return redirect()->back()->with('warning', 'Donation is already cancelled.');
        }

        // BR-DON-02: A cancelled receipt keeps its number to prevent gap detection findings
        $donation->update([
            'status'           => 'Cancelled',
            'cancelled_reason' => $request->input('cancelled_reason'),
            'updated_by'       => auth()->id(),
        ]);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'voucherService' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
20:use Modules\Accounting\Services\VoucherService;
24:public function __construct(private readonly VoucherService $voucherService) {}
185:$voucher = $this->voucherService->create([
209:$this->voucherService->post($voucher->fresh());
```

#### DNAT-35 · M · F13-Q1 — A certificate can be issued for a Draft or Cancelled donation

| Field | Value |
|---|---|
| **Rule** | F13-Q1 (M) — *a guard that the screen implies but the method does not enforce* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DonationController.php:228-243` |
| **Root cause** | `issueCertificate()` checks only `is_80g_eligible`. The list only shows the button for `status === 'Posted'` (`_donations.blade.php:207`), but the POST route is reachable directly, so the status is never enforced server-side. |
| **Consequence** | A certificate timestamp can be set on a Draft receipt that has no voucher, or on a Cancelled receipt whose income was reversed — the printed certificate then claims an 80G deduction that the books do not support. |
| **Reproduce** | POST `/accounting/donation/{draft_id}/issue-certificate`; the flash says the certificate was issued. |
| **Fix approach** | Return a red flash unless `status === 'Posted'`. |
| **Plan item** | DNAT-35 in `02-fix-plan.md` §5 |

```php
// DonationController.php:232-239 — CURRENT
        if (!$donation->is_80g_eligible) {
            return redirect()->back()->with('error', 'This donation is not eligible for an 80G certificate.');
        }

        $donation->update([
            'certificate_issued_at' => now(),
            'updated_by'            => auth()->id(),
        ]);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\resources\views\pages\partials\school-specific\_donations.blade.php -Pattern "status === 'Posted'" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
207:@if($donation->is_80g_eligible && !$donation->certificate_issued_at && $donation->status === 'Posted')
```

## 7. Cross-cutting notes (common or other-module classes - not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:2478-2618` | The donations list, the create modal and its dropdown data (`$donations`, `$donorLedgers`, `$funds`) are assembled here, gated only by `tenant.accounting.dashboard.view`. The whole list is rendered inside `@can('tenant.accounting.donation.viewAny')` in the view, but the controller still loads all donations and all ledgers for every visitor of the page, whatever tab is open. | QRY-02 / AUTH-01 | AccDashboardController report |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:2640-2660` | The list query filters `receipt_no`, `donor_name`, `donor_pan`, `instrument_no` with leading-wildcard `LIKE` (QRY-08). Acceptable while `acc_donations` is small (2 rows); revisit when the table grows. | QRY-08 | AccDashboardController report |
| `Modules/Accounting/resources/views/pages/partials/school-specific/_donations.blade.php:263-450` | The create form carries 17 controls (date, anonymous, name, PAN, ledger, phone, email, nature, fund, amount, mode, instrument, valuation basis, valued by, in-kind description, purpose, 80G flag). `modal-standard.md` §2.5 puts the modal limit at 15 controls; a form this size should be a page. The missing `create()` page (DNAT-13) and the modal standard are the same gap. Not fixed here because the partial is shared with `AccDashboardController`. | VIEW / modal-standard §2.5 | AccDashboardController report, or a UI-standard pass |
| `Modules/Accounting/app/Services/VoucherService.php:28-96` | `create()` already opens its own `DB::transaction`; `post()` runs whichever posting service owns the voucher. The controller's `post()` nests the donation write around it, so the donation flag and the voucher commit together. Audited in the VoucherController report, which is still `CLAIMED` — its verdict is not available yet. | SVC | VoucherController report |
| `Modules/Accounting/app/Models/BaseAccountingModel.php:36-73` | The parent resolves `financial_year_id` from the transaction date on create. The controller pre-empts it with a non-null value (DNAT-32), which is why the parent's correct resolution never runs. The parent itself is correct; the defect is the controller's. | — | AccountingStatusMasterController report |
| `Modules/Accounting/app/Models/FinancialYear.php` | No `code` column and no accessor. The donation receipt prefix needs a year label; the model offers `name` (`FY 2026-27`) and the dates. Nothing here is broken, but there is no `code` to read, which is the trap DNAT-33 fell into. | MDL | FinancialYearController report |

## 8. Not covered, and why

- **Scanner and self-check skipped.** `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are missing in this checkout, and `scan.php` was explicitly forbidden for this run. F1–F13 were therefore worked manually with `read`, `grep`/`Select-String`, `php -l`, `pint --test`, `route:list` and direct read-only SQL against the tenant database. The §15 self-check has not been run; the report was checked by hand against the template (every finding carries all eight fields plus two code blocks, every finding has a plan item or a §10 row, no placeholders and no EXAMPLE blocks).
- **No tests were run** (D4). The race in DNAT-06 and the concurrency proof for the unique-index trap in DNAT-09 are static; settling them needs two simultaneous requests or a transaction-level integration test.
- **`VoucherService` / `PostingService`** are owned by the VoucherController report and were read only for how this controller calls them. The voucher-side rules (period locks, number allocation, posting invariants) are not audited here.
- **Blade compilation** was not run as a separate step. The four `donation/*` blades and the `_donations` partial were read in full; no `@php` block contains a `{{-- --}}`, and no query, `{!! !!}` or model dump was found (`Select-String` count 0 for `{!!` and for `DB::|->where\(|->get\(\)|::where`).
- **The live rows (`acc_donations` ids 1 and 2)** are seeder data. They are quoted only as the end state that the code path produces (`status = Posted`, `voucher_id = NULL`); the code proof for DNAT-03 is the unconditional write at line 214.
- **Browser rendering of the modal** was not exercised. Whether the school-specific page's shell wraps the modal in a second permission check is the `AccDashboardController` report's business.
- **`glb_menus`** was not checked; the donations surface is a tab, not a menu row, so a menu edit is not part of this controller's scope.
