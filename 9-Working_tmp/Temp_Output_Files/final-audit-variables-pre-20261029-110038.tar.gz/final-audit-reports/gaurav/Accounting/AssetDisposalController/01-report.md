# Final Audit — Accounting / AssetDisposalController

**Audited:** 2026-10-23 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php` (88 lines, 4 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /accounting/asset-disposal` (redirects to `/accounting/assets-integration?tab=asset-disposals`), `POST /accounting/asset-disposal`, `GET /accounting/asset-disposal/{asset_disposal}`, `POST /accounting/asset-disposal/preview` (AJAX). The visible tab itself is `/accounting/assets-integration?tab=asset-disposals`, rendered by `AccDashboardController::assetsIntegration()`. |
| Menu path | Accounting → Assets & Integration → **Asset Disposals** tab |
| Who uses it | Roles holding `tenant.accounting.fixed-asset.viewAny` / `.update` on test.localhost, measured with an exact-name query: `Account Manager`, `Account Staff`, `Management`, `School Admin`, `Super Admin`. |
| What a user does here | Disposes an active fixed asset (Sale, Scrap, Donation, Loss or Transfer). The screen freezes the asset's cost and accumulated depreciation, computes gain/loss, posts an automatic disposal journal voucher, changes the asset status to Disposed/Written_Off/Lost, and lets the user open a read-only disposal receipt. |
| Tables written | `acc_asset_disposals`, `acc_fixed_assets` (status), `acc_vouchers`, `acc_voucher_items`, `acc_ledger_period_balances` (posting), `acc_ledgers` and `acc_account_groups` (first gain/loss ledger auto-create), `sys_activity_logs` |
| Tables read | `acc_fixed_assets`, `acc_asset_categories`, `acc_financial_years`, `acc_voucher_types`, `acc_ledgers`, `acc_vouchers`, `acc_voucher_items`, `sys_users` |
| Live data | Tenant `xyz_school_00000000000040008000_202627`: `acc_asset_disposals` **1 live, 0 trashed**; `acc_fixed_assets` **5 live, 5 Active, 0 trashed**; `acc_vouchers` **30**. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready**. Its write path is a single generic `try/catch` that sends the raw exception message to the user, and four resource routes point at methods that do not exist. The single worst finding is **ASDI-04 (B, AUTH-01)**: the AJAX `preview` endpoint has no authorization check at all, so any authenticated tenant user can read any asset's purchase cost, accumulated depreciation and net book value by posting an id. Two more blockers sit beside it: the raw-error catch (**ASDI-01**, B) and the missing `create/edit/update/destroy` methods behind `Route::resource` (**ASDI-08**, B). Effort to clear the plan is **S/M** (roughly half a day): one catch removal, one small preview FormRequest, one cross-field rule, one service helper, one route restriction, and five Pint runs.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 3 | 2 | 5 | 5 | 0 | 15 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | ASDI-01, ASDI-02 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | ASDI-03 | F9 Queries/Perf | ASDI-11 |
| F3 Authorization | ASDI-04, ASDI-05 | F10 Views | clean |
| F4 Validation | ASDI-06, ASDI-07 | F11 Security/Tenancy | clean |
| F5 Routes | ASDI-08 | F12 Style | ASDI-12, ASDI-13, ASDI-14, ASDI-15 |
| F6 Controller shape | ASDI-09, ASDI-10 | F13 Deep read | answers in §F13 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php` | controller | 88 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/AssetDisposal.php` | model | 99 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/AssetDisposalRequest.php` | form request | 54 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/app/Services/AssetDisposalService.php` | service | 214 | this report (pre-assigned) | ✅ |
| 5 | `Modules/Accounting/resources/views/asset-disposal/show.blade.php` | blade | 323 | this report | ✅ |
| 6 | `Modules/Accounting/routes/web.php` (lines 286-287) | route file | 536 | this report, ⚠ SHARED — ASDI-08 only | ✅ |
| 7 | `Modules/Accounting/app/Models/FixedAsset.php` | model | 299 | ↗ [gaurav/Accounting/FixedAssetController](../FixedAssetController/01-report.md) | ↗ linked |
| 8 | `Modules/Accounting/app/Models/AssetCategory.php` | model | 108 | ↗ [gaurav/Accounting/AssetCategoryController](../AssetCategoryController/01-report.md) | ↗ linked |
| 9 | `Modules/Accounting/app/Models/Ledger.php` | model | 408 | ↗ [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) | ↗ linked |
| 10 | `Modules/Accounting/app/Models/Voucher.php` | model | 415 | ↗ [gaurav/Accounting/VoucherController](../VoucherController/01-report.md) (not yet audited) | ↗ linked |
| 11 | `Modules/Accounting/app/Models/VoucherType.php` | model | 185 | ↗ [gaurav/Accounting/VoucherTypeController](../VoucherTypeController/01-report.md) | ↗ linked |
| 12 | `Modules/Accounting/app/Models/AccountGroup.php` | model | 179 | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 13 | `Modules/Accounting/app/Models/FinancialYear.php` | model | 168 | ↗ [gaurav/Accounting/FinancialYearController](../FinancialYearController/01-report.md) | ↗ linked |
| 14 | `Modules/Accounting/app/Services/VoucherService.php` | service | 402 | ↗ [gaurav/Accounting/VoucherController](../VoucherController/01-report.md) (not yet audited) | ↗ linked |
| 15 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | base model | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 16 | `Modules/Accounting/app/Services/AccountingContext.php` | service | 110 | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 17 | `Modules/GlobalMaster/app/Models/ActivityLog.php` | model | 50 | ↗ [gaurav/Accounting/CostCategoryController](../CostCategoryController/01-report.md) | ↗ linked |
| 18 | `Modules/SchoolSetup/app/Models/User.php` | other-module model | 318 | not claimed — used only as a `belongsTo` target (`approver`, `creator`) | read only |

No pre-applied files.

The listing table and its `_asset-disposals.blade.php` partial are rendered by `AccDashboardController::assetsIntegration()` (row `CLAIMED` in `gaurav/Accounting/00-INDEX.md`), not by this controller. This report audits only the show blade and flags the two cross-cutting defects in §7.

## 4. Routes

```
GET|HEAD  accounting/asset-disposal                          accounting.asset-disposal.index    Modules\Accounting\Http\Controllers\AssetDisposalController@index
POST      accounting/asset-disposal                          accounting.asset-disposal.store    Modules\Accounting\Http\Controllers\AssetDisposalController@store
GET|HEAD  accounting/asset-disposal/create                   accounting.asset-disposal.create   Modules\Accounting\Http\Controllers\AssetDisposalController@create
POST      accounting/asset-disposal/preview                  accounting.asset-disposal.preview  Modules\Accounting\Http\Controllers\AssetDisposalController@preview
GET|HEAD  accounting/asset-disposal/{asset_disposal}         accounting.asset-disposal.show     Modules\Accounting\Http\Controllers\AssetDisposalController@show
PUT|PATCH accounting/asset-disposal/{asset_disposal}         accounting.asset-disposal.update   Modules\Accounting\Http\Controllers\AssetDisposalController@update
DELETE    accounting/asset-disposal/{asset_disposal}         accounting.asset-disposal.destroy  Modules\Accounting\Http\Controllers\AssetDisposalController@destroy
GET|HEAD  accounting/asset-disposal/{asset_disposal}/edit    accounting.asset-disposal.edit     Modules\Accounting\Http\Controllers\AssetDisposalController@edit
```

All eight routes carry `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:Accounting, Authenticate, EnsureEmailIsVerified`.

Unrouted public methods: **none**.

⚠ Four routed actions — `create`, `edit`, `update`, `destroy` — have no controller method. They are registered by the full `Route::resource` at `routes/web.php:287` and are reported as **ASDI-08**.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 18 | GET /accounting/asset-disposal | `tenant.accounting.fixed-asset.viewAny` | — | — | — | — |
| `store` | 25 | POST /accounting/asset-disposal | `tenant.accounting.fixed-asset.create` (FormRequest line 16) **and** `tenant.accounting.fixed-asset.update` (controller line 27) | service `AssetDisposalService::dispose()` lines 45-182 | `'Disposed'` (controller line 35) | acc_asset_disposals, acc_fixed_assets, acc_vouchers, acc_voucher_items, acc_ledger_period_balances, acc_ledgers, acc_account_groups, sys_activity_logs | ASDI-01, ASDI-02, ASDI-03, ASDI-05, ASDI-06, ASDI-09 |
| `preview` | 50 | POST /accounting/asset-disposal/preview | **none** | — | — | — | ASDI-04, ASDI-07, ASDI-09, ASDI-11 |
| `show` | 80 | GET /accounting/asset-disposal/{asset_disposal} | `tenant.accounting.fixed-asset.view` | — | — | — | — |

## 6. Findings

### F1 — Errors

#### ASDI-01 · B · ERR-01 — Raw exception text reaches the user when a disposal fails

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php:32-47`, method `store()` |
| **Root cause** | The whole service call is wrapped in `catch (\Throwable $e)` and the catch puts `$e->getMessage()` into the red flash. The catch also logs only the message and a string trace instead of reporting the exception object. D1 makes the catch itself unnecessary: `DB::transaction()` already rolls back and rethrows. |
| **Consequence** | A failed disposal — an unbalanced journal, a duplicate disposal, a missing voucher type — shows the raw MySQL or `InvalidArgumentException` text (table and column names) instead of a friendly message. |
| **Reproduce** | Open Asset Disposals, choose an active asset, enter Sale Proceeds `500`, leave Settlement/Buyer Account empty, and submit. The flash begins `Failed to dispose asset: Debits (500) do not equal credits (...)`. |
| **Fix approach** | Delete the try/catch and the message log; call the service directly and let the central handler report the failure (D1). |
| **Plan item** | ASDI-01 in `02-fix-plan.md` §1 (also closes ASDI-02) |

```php
// AssetDisposalController.php:32-47 — CURRENT
        try {
            $disposal = $this->service->dispose($asset, $validated);

            activityLog($disposal, 'Disposed', [
                'message'          => 'Fixed Asset disposed.',
                'asset_code'       => $asset->asset_code,
                'disposal_type'    => $disposal->disposal_type,
                'gain_loss_amount' => $disposal->gain_loss_amount,
            ]);

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'asset-disposals'])
                ->with('success', "Asset [{$asset->asset_code}] disposed successfully. Voucher posted.");
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('AssetDisposal failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return back()->with('error', 'Failed to dispose asset: ' . $e->getMessage())->withInput();
        }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AssetDisposalController.php -Pattern "getMessage|catch \(" | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
44: } catch (\Throwable $e) {
45: \Illuminate\Support\Facades\Log::error('AssetDisposal failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
46: return back()->with('error', 'Failed to dispose asset: ' . $e->getMessage())->withInput();
```

#### ASDI-02 · H · ERR-02 — A missing asset or a business-rule refusal becomes a redirect instead of a 404/409

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422/abort into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php:30` and `:32-47`, method `store()` |
| **Root cause** | `FixedAsset::findOrFail()` sits inside the `try`, and `catch (\Throwable $e)` swallows `ModelNotFoundException`. The same catch also swallows the service's `DomainException` ("already disposed") and the voucher's `InvalidArgumentException` (unbalanced journal), so every one of them becomes a red flash + redirect. |
| **Consequence** | A user who submits an asset id that has just been deleted sees "Failed to dispose asset: No query results for model ..." instead of a 404; a business refusal is logged as a system failure. |
| **Reproduce** | Static only — submit the modal with a `fixed_asset_id` that is deleted after validation, or dispose the same asset twice from two tabs. Expected 404/409; actual redirect with raw text. |
| **Fix approach** | Remove the try/catch per D1 (ASDI-01). `findOrFail()` and `DomainException` then reach the central handler with their real status. |
| **Plan item** | None of its own — closed by ASDI-01 in `02-fix-plan.md` §1; see `02-fix-plan.md` §10 |

```php
// AssetDisposalController.php:30-47 — CURRENT
        $asset = FixedAsset::findOrFail($validated['fixed_asset_id']);

        try {
            $disposal = $this->service->dispose($asset, $validated);

            activityLog($disposal, 'Disposed', [
                'message'          => 'Fixed Asset disposed.',
                'asset_code'       => $asset->asset_code,
                'disposal_type'    => $disposal->disposal_type,
                'gain_loss_amount' => $disposal->gain_loss_amount,
            ]);

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'asset-disposals'])
                ->with('success', "Asset [{$asset->asset_code}] disposed successfully. Voucher posted.");
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('AssetDisposal failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return back()->with('error', 'Failed to dispose asset: ' . $e->getMessage())->withInput();
        }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AssetDisposalController.php -Pattern "findOrFail|catch \(" | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
30: $asset = FixedAsset::findOrFail($validated['fixed_asset_id']);
44: } catch (\Throwable $e) {
```

### F2 — Transactions and audit

#### ASDI-03 · M · TXN-04 — The audit row is written after the disposal transaction has already committed

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php:33-40`; the transaction is `Modules/Accounting/app/Services/AssetDisposalService.php:45-182` |
| **Root cause** | The only `DB::transaction` lives inside `AssetDisposalService::dispose()`. The controller calls `activityLog()` after that method returns, i.e. after the commit. |
| **Consequence** | The disposal and its audit row are not atomic: if the audit insert fails, the asset is already disposed and the voucher already posted. With ASDI-01's catch still present the user is told the disposal failed, although it succeeded. |
| **Reproduce** | Static only — the transaction boundary is `Service.php:45` and the log call is `Controller.php:35`, outside it. |
| **Fix approach** | Move the `activityLog()` call into `dispose()` after `$asset->update()` and before `return $disposal`, so the audit row is part of the same transaction. |
| **Plan item** | ASDI-03 in `02-fix-plan.md` §3 |

```php
// AssetDisposalController.php:33-40 — CURRENT (outside the service transaction)
        $disposal = $this->service->dispose($asset, $validated);

        activityLog($disposal, 'Disposed', [
            'message'          => 'Fixed Asset disposed.',
            'asset_code'       => $asset->asset_code,
            'disposal_type'    => $disposal->disposal_type,
            'gain_loss_amount' => $disposal->gain_loss_amount,
        ]);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AssetDisposalController.php,Modules\Accounting\app\Services\AssetDisposalService.php -Pattern "activityLog|return DB::transaction" | ForEach-Object { $_.Filename+":"+$_.LineNumber+": "+$_.Line.Trim() }
AssetDisposalController.php:35: activityLog($disposal, 'Disposed', [
AssetDisposalService.php:45: return DB::transaction(function () use (
```

### F3 — Authorization

#### ASDI-04 · B · AUTH-01 — The preview endpoint has no authorization check

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B) — *every routed controller method authorizes before loading records* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php:50-78`, method `preview()` |
| **Root cause** | `preview()` takes a plain `Request`, calls no `Gate::authorize`, has no `can:` middleware and no FormRequest. The route carries only the shared auth/tenant middleware. |
| **Consequence** | Any authenticated tenant user — including a role with no Accounting permission — can POST any `fixed_asset_id` and read that asset's purchase cost, accumulated depreciation and net book value. |
| **Reproduce** | Log in as a user without `tenant.accounting.fixed-asset.view`; run `POST /accounting/asset-disposal/preview` with `Accept: application/json` and body `{"fixed_asset_id":1}`. The response is `200` with the financial figures instead of `403`. |
| **Fix approach** | Add an `AssetDisposalPreviewRequest` whose `authorize()` checks `tenant.accounting.fixed-asset.view` and whose rules type the three inputs; type-hint it on `preview()`. |
| **Plan item** | ASDI-04 in `02-fix-plan.md` §1 (also closes ASDI-07) |

```php
// AssetDisposalController.php:50-59 — CURRENT
    public function preview(Request $request)
    {
        $assetId = (int) $request->input('fixed_asset_id');
        $saleProceeds = max(0.0, (float) $request->input('sale_proceeds', 0));
        $disposalCost = max(0.0, (float) $request->input('disposal_cost', 0));

        $asset = FixedAsset::with(['assetCategory', 'depreciationEntries'])->find($assetId);
        if (! $asset) {
            return response()->json(['success' => false, 'message' => 'Asset not found.'], 404);
        }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AssetDisposalController.php -Pattern 'Gate::authorize' | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
20: Gate::authorize('tenant.accounting.fixed-asset.viewAny');
27: Gate::authorize('tenant.accounting.fixed-asset.update');
82: Gate::authorize('tenant.accounting.fixed-asset.view');
$ php artisan route:list --json | php routesprobe.php "Modules\Accounting\Http\Controllers\AssetDisposalController"
POST      accounting/asset-disposal/preview                  accounting.asset-disposal.preview  ...AssetDisposalController@preview  [web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:Accounting, Authenticate, EnsureEmailIsVerified]
```

#### ASDI-05 · M · AUTH-04 — One action is authorized twice with two different permissions

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (M, raised from L — the mismatch blocks a legitimate custom role) — *do not authorize the same action twice; keep one permission* |
| **Where** | `Modules/Accounting/app/Http/Requests/AssetDisposalRequest.php:16`; `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php:27`; `Modules/Accounting/resources/views/pages/partials/assets-integration/_asset-disposals.blade.php:217` |
| **Root cause** | `AuthorizesTenantFeature` maps POST to `create`, so the FormRequest requires `tenant.accounting.fixed-asset.create`; the controller then requires `...update`; the modal button is shown for `...update`. Disposing an existing asset is an update operation, so the request is checking the wrong verb. |
| **Consequence** | A custom role granted `update` but not `create` sees the Dispose button (gated on update) and is then refused by the FormRequest. All five seeded roles hold both today, so the defect is latent but real. |
| **Reproduce** | Static only — grant a test role `tenant.accounting.fixed-asset.update` without `.create`, open the Asset Disposals tab, and submit the modal. Expected: allowed. Actual: 403 from the FormRequest. |
| **Fix approach** | Make the FormRequest check the `update` action explicitly and delete the duplicate `Gate::authorize(...update)` from `store()`. |
| **Plan item** | ASDI-05 in `02-fix-plan.md` §4 |

```php
// AssetDisposalRequest.php:16 — CURRENT
        return $this->authorizeByCrudPermission('tenant.accounting.fixed-asset');
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Requests\AssetDisposalRequest.php -Pattern 'authorizeByCrudPermission' | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
16: return $this->authorizeByCrudPermission('tenant.accounting.fixed-asset');
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AssetDisposalController.php -Pattern 'Gate::authorize' | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
27: Gate::authorize('tenant.accounting.fixed-asset.update');
$ Select-String -Path Modules\Accounting\resources\views\pages\partials\assets-integration\_asset-disposals.blade.php -Pattern 'permission=' | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
217: permission="tenant.accounting.fixed-asset.update">
```

### F4 — Validation and input

#### ASDI-06 · H · VAL-07 — Sale proceeds or disposal cost without a settlement account produces an unbalanced voucher

| Field | Value |
|---|---|
| **Rule** | VAL-07 (H, raised from M — the unguarded path fails a normal disposal) — *cross-field business checks belong in the FormRequest's `after()` hook* |
| **Where** | `Modules/Accounting/app/Http/Requests/AssetDisposalRequest.php:25-27`; `Modules/Accounting/app/Services/AssetDisposalService.php:79-80, 118-119` |
| **Root cause** | `buyer_ledger_id` is `nullable`, but the debit for sale proceeds and the credit for disposal cost are only added when a buyer ledger is present. The gain/loss figure still includes both amounts, so the journal has an unequal debit/credit total and `VoucherService::create()` throws. |
| **Consequence** | A sale with proceeds but no Settlement/Buyer Account selected cannot be disposed; the user sees the raw imbalance text (ASDI-01) and the asset stays Active. |
| **Reproduce** | Open Asset Disposals, select an active asset, choose `Sale`, enter Sale Proceeds `500`, leave Settlement/Buyer Account empty, and submit. The journal items total 0 debit against 500+ credit. |
| **Fix approach** | Add an `after()` rule: when `sale_proceeds > 0` or `disposal_cost > 0`, `buyer_ledger_id` is required. |
| **Plan item** | ASDI-06 in `02-fix-plan.md` §5 |

```php
// AssetDisposalRequest.php:25-27 — CURRENT
            'buyer_ledger_id' => 'nullable|exists:acc_ledgers,id',
            'sale_proceeds'   => 'nullable|numeric|min:0',
            'disposal_cost'   => 'nullable|numeric|min:0',
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Services\AssetDisposalService.php -Pattern "saleProceeds > 0|disposalCost > 0" | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
79: if ($saleProceeds > 0 && $buyerLedgerId) {
118: if ($disposalCost > 0 && $buyerLedgerId) {
$ Select-String -Path Modules\Accounting\app\Services\VoucherService.php -Pattern "do not equal credits" | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
44: throw new \InvalidArgumentException("Debits ({$debitSum}) do not equal credits ({$creditSum}) under Invariant Rule R-01.");
104: throw new \InvalidArgumentException("Debits ({$debitSum}) do not equal credits ({$creditSum}) under Invariant Rule R-01.");
```

#### ASDI-07 · M · VAL-05 — Preview input is cast, never validated or typed

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; write/read paths do not trust raw input* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php:52-54`, method `preview()` |
| **Root cause** | The method reads `$request->input()` directly and casts with `(int)` / `(float)`. There is no validator, no `exists` rule and no upper bound. PHP casts an array to `1`, so a malformed `fixed_asset_id` silently previews asset #1. |
| **Consequence** | A malformed or tampered AJAX request can show the figures of a different asset; negative values are silently clamped to zero instead of rejected. No data is written. |
| **Reproduce** | Static only — POST `{"fixed_asset_id":[99],"sale_proceeds":-5}`; the id becomes `1` and the proceeds become `0`. |
| **Fix approach** | Covered by the `AssetDisposalPreviewRequest` added in ASDI-04: `required|integer|exists` for the id and `nullable|numeric|min:0` for the two amounts. |
| **Plan item** | ASDI-04 in `02-fix-plan.md` §1 (the same preview request) |

```php
// AssetDisposalController.php:52-54 — CURRENT
        $assetId = (int) $request->input('fixed_asset_id');
        $saleProceeds = max(0.0, (float) $request->input('sale_proceeds', 0));
        $disposalCost = max(0.0, (float) $request->input('disposal_cost', 0));
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AssetDisposalController.php -Pattern 'request->input' | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
52: $assetId = (int) $request->input('fixed_asset_id');
53: $saleProceeds = max(0.0, (float) $request->input('sale_proceeds', 0));
54: $disposalCost = max(0.0, (float) $request->input('disposal_cost', 0));
```

### F5 — Routes

#### ASDI-08 · B · RTE-02 — Four routes point at methods that do not exist

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *every route points to a method that exists* |
| **Where** | `Modules/Accounting/routes/web.php:287`; `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php` has only `index`, `store`, `preview`, `show` |
| **Root cause** | `Route::resource('asset-disposal', AssetDisposalController::class)` registers all seven REST actions, but the controller implements only three of them. Disposals are immutable in the UI (`:editUnavailable="true"` / `:deleteUnavailable="true"`), so the missing methods are never provided. |
| **Consequence** | `GET /accounting/asset-disposal/create`, `GET /accounting/asset-disposal/{id}/edit`, `PUT/PATCH /accounting/asset-disposal/{id}` and `DELETE /accounting/asset-disposal/{id}` return a 500 `BadMethodCallException` instead of a 404/405. |
| **Reproduce** | Static only — visit `GET /accounting/asset-disposal/create` while authenticated; Laravel cannot find `create()` and throws. |
| **Fix approach** | Restrict the resource route to the implemented actions: `->only(['index', 'store', 'show'])`. |
| **Plan item** | ASDI-08 in `02-fix-plan.md` §1 — ⚠ SHARED (route file) |

```php
// Modules/Accounting/routes/web.php:286-287 — CURRENT
Route::post('/asset-disposal/preview', [\Modules\Accounting\Http\Controllers\AssetDisposalController::class, 'preview'])->name('asset-disposal.preview');
Route::resource('asset-disposal', \Modules\Accounting\Http\Controllers\AssetDisposalController::class);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AssetDisposalController.php -Pattern 'public function' | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
16: public function __construct(private readonly AssetDisposalService $service) {}
18: public function index()
25: public function store(AssetDisposalRequest $request)
50: public function preview(Request $request)
80: public function show(AssetDisposal $assetDisposal)
```

### F6 — Controller shape

#### ASDI-09 · M · CTL-06 — The gain/loss formula is implemented twice

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in services/actions, not duplicated in the controller* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php:61-64`; `Modules/Accounting/app/Services/AssetDisposalService.php:38-43` |
| **Root cause** | The preview recomputes cost, accumulated depreciation, NBV and gain/loss in the controller, while `dispose()` computes the same four figures in the service. There is one implementation per operation, and this is two. |
| **Consequence** | If the NBV or gain/loss rule changes in the service, the preview shown before submission silently disagrees with the posted voucher. |
| **Reproduce** | Static only — the same four lines appear at controller `61-64` and service `38-43`. |
| **Fix approach** | Add `AssetDisposalService::calculateFigures()` and call it from both `dispose()` and `preview()`. |
| **Plan item** | ASDI-09 in `02-fix-plan.md` §5 |

```php
// AssetDisposalController.php:61-64 — CURRENT
        $cost = (float) $asset->purchase_cost;
        $accum = (float) $asset->accumulated_depreciation;
        $nbv = max(0.0, round($cost - $accum, 2));
        $gainLoss = round($saleProceeds - $disposalCost - $nbv, 2);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AssetDisposalController.php,Modules\Accounting\app\Services\AssetDisposalService.php -Pattern "purchase_cost|accumulated_depreciation|round\(.*2\)" | ForEach-Object { $_.Filename+":"+$_.LineNumber+": "+$_.Line.Trim() }
AssetDisposalController.php:61: $cost = (float) $asset->purchase_cost;
AssetDisposalController.php:62: $accum = (float) $asset->accumulated_depreciation;
AssetDisposalController.php:64: $gainLoss = round($saleProceeds - $disposalCost - $nbv, 2);
AssetDisposalService.php:38: $costAtDisposal = (float) $asset->purchase_cost;
AssetDisposalService.php:39: $accumDep = (float) $asset->accumulated_depreciation;
AssetDisposalService.php:43: $gainLoss = round($saleProceeds - $disposalCost - $netBookValue, 2);
```

#### ASDI-10 · L · CTL-04 — No return types on the public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php:18, 25, 50, 80` |
| **Root cause** | None of the four actions declares `: RedirectResponse`, `: JsonResponse` or `: View`. |
| **Consequence** | No runtime effect; the controller is harder to reason about and static analysis cannot prove the response shape. |
| **Reproduce** | Static only — the four signatures have no `:` return type. |
| **Fix approach** | Add the three response imports and the matching return types. |
| **Plan item** | ASDI-10 in `02-fix-plan.md` §8 |

```php
// AssetDisposalController.php:18,25,50,80 — CURRENT
    public function index()
    public function store(AssetDisposalRequest $request)
    public function preview(Request $request)
    public function show(AssetDisposal $assetDisposal)
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AssetDisposalController.php -Pattern 'public function' | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
18: public function index()
25: public function store(AssetDisposalRequest $request)
50: public function preview(Request $request)
80: public function show(AssetDisposal $assetDisposal)
```

### F7 — Models

clean — `Select-String -Path Modules\Accounting\app\Models\AssetDisposal.php -Pattern "table|fillable|casts|SoftDeletes"` shows `$table = 'acc_asset_disposals'`, a 16-column `$fillable`, casts for every date/decimal/boolean, and the model inherits `SoftDeletes`; `SHOW COLUMNS FROM acc_asset_disposals` in the tenant DB returns 20 columns including `deleted_at` and `is_active`. No finding.

### F8 — Services and jobs

clean — `Select-String -Path Modules\Accounting\app\Services\AssetDisposalService.php -Pattern "request\(|session\(|redirect\(|response\(|back\(|new VoucherService|app\("` returns no output; the service is constructor-injected (`VoucherService $voucherService`), has no HTTP calls, and writes only from `dispose()`. No finding.

### F9 — Queries and performance

#### ASDI-11 · M · QRY-03 — Preview eager-loads two relations it never uses

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M) — *select only what you use* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php:56`, method `preview()` |
| **Root cause** | `FixedAsset::with(['assetCategory', 'depreciationEntries'])` loads the category and every depreciation row, but the method only reads `purchase_cost`, `accumulated_depreciation`, `asset_code` and `name`. The `accumulated_depreciation` accessor issues its own `sum()` query, so the eager load is pure overhead. |
| **Consequence** | Every preview request loads one category row plus all depreciation rows for the asset; the payload and latency grow with the asset's age and never help the response. |
| **Reproduce** | Static only — line 56 is the only use of `assetCategory` / `depreciationEntries` in the method, and neither name appears again. |
| **Fix approach** | Replace the eager load with `FixedAsset::find($assetId)`. |
| **Plan item** | ASDI-11 in `02-fix-plan.md` §6 |

```php
// AssetDisposalController.php:56 — CURRENT
        $asset = FixedAsset::with(['assetCategory', 'depreciationEntries'])->find($assetId);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AssetDisposalController.php -Pattern 'assetCategory|depreciationEntries|FixedAsset::with' | ForEach-Object { $_.LineNumber.ToString()+": "+$_.Line.Trim() }
56: $asset = FixedAsset::with(['assetCategory', 'depreciationEntries'])->find($assetId);
```

### F10 — Views

clean — `Select-String -Path Modules\Accounting\resources\views\asset-disposal\show.blade.php -Pattern "\{!!|DB::|::where|::find|->get\(\)|->count\(\)"` returns one line, `231: @if($assetDisposal->voucher->items && $assetDisposal->voucher->items->count() > 0)`, and `voucher.items.ledger` is eager-loaded by the controller at line 84. No `{!! !!}`, no query builder call. No finding.

### F11 — Security and tenancy

clean — `Select-String -Path Modules\Accounting\app\Http\Controllers\AssetDisposalController.php,Modules\Accounting\app\Services\AssetDisposalService.php,Modules\Accounting\app\Http\Requests\AssetDisposalRequest.php,Modules\Accounting\app\Models\AssetDisposal.php -Pattern "env\(|\?\? 1|Log::.*request|->all\(\)|except\("` returns no output; no `env()`, no hard-coded user/tenant id, no `$request->all()`, no request body logged. Tenant scoping is provided by `InitializeTenancyByDomain`. The authorization gap itself is reported as ASDI-04. No separate finding.

### F12 — Style

#### ASDI-12 · L · STY-02 — `AssetDisposalController.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php` |
| **Root cause** | Pint reports `fully_qualified_strict_types`, `single_import_per_statement`, `concat_space`, `unary_operator_spaces`, `braces_position`, `no_unused_imports`, `not_operator_with_successor_space`, `single_line_empty_body`, `blank_line_before_statement`, `ordered_imports` and `binary_operator_spaces`. |
| **Consequence** | No user-visible effect; the file fails the project style gate. |
| **Reproduce** | Run the Verify command below. |
| **Fix approach** | Run Pint on the file after the other items. |
| **Plan item** | ASDI-12 in `02-fix-plan.md` §8 |

```php
// AssetDisposalController.php:11 — CURRENT
use Modules\Accounting\Models\{AssetDisposal, FixedAsset, Ledger};
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\AssetDisposalController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\AssetDisposalController.php","fixers":["fully_qualified_strict_types","single_import_per_statement","concat_space","unary_operator_spaces","braces_position","no_unused_imports","not_operator_with_successor_space","single_line_empty_body","blank_line_before_statement","ordered_imports","binary_operator_spaces"]}]}
```

#### ASDI-13 · L · STY-02 — `AssetDisposalService.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Services/AssetDisposalService.php` |
| **Root cause** | Pint reports `single_space_around_construct`, `single_import_per_statement`, `method_chaining_indentation`, `unary_operator_spaces`, `braces_position`, `not_operator_with_successor_space`, `single_line_empty_body` and `binary_operator_spaces`. |
| **Consequence** | No user-visible effect; the file fails the project style gate. |
| **Reproduce** | Run the Verify command below. |
| **Fix approach** | Run Pint on the file after ASDI-03 and ASDI-09. |
| **Plan item** | ASDI-13 in `02-fix-plan.md` §8 |

```php
// AssetDisposalService.php:9 — CURRENT
use Modules\Accounting\Models\{AccountGroup, AssetDisposal, FinancialYear, FixedAsset, Ledger, Voucher, VoucherType};
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Services\AssetDisposalService.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Services\\AssetDisposalService.php","fixers":["single_space_around_construct","single_import_per_statement","method_chaining_indentation","unary_operator_spaces","braces_position","not_operator_with_successor_space","single_line_empty_body","binary_operator_spaces"]}]}
```

#### ASDI-14 · L · STY-02 — `AssetDisposalRequest.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Http/Requests/AssetDisposalRequest.php` |
| **Root cause** | Pint reports `ordered_imports` and `binary_operator_spaces`. |
| **Consequence** | No user-visible effect; the file fails the project style gate. |
| **Reproduce** | Run the Verify command below. |
| **Fix approach** | Run Pint on the file after ASDI-05 and ASDI-06. |
| **Plan item** | ASDI-14 in `02-fix-plan.md` §8 |

```php
// AssetDisposalRequest.php:7-8 — CURRENT
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Http\Requests\AssetDisposalRequest.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\AssetDisposalRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
```

#### ASDI-15 · L · STY-02 — `AssetDisposal.php` is not Pint-clean and imports an unused class

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean; no unused imports* |
| **Where** | `Modules/Accounting/app/Models/AssetDisposal.php:7` and throughout |
| **Root cause** | Pint reports `fully_qualified_strict_types`, `no_unused_imports`, `single_line_after_imports` and `binary_operator_spaces`; `use App\Models\BaseModel;` is unused because the model extends `BaseAccountingModel`. |
| **Consequence** | No user-visible effect; style gate failure and a misleading import. |
| **Reproduce** | Run the Verify command below. |
| **Fix approach** | Run Pint on the file; the unused import is removed by `no_unused_imports`. |
| **Plan item** | ASDI-15 in `02-fix-plan.md` §8 |

```php
// AssetDisposal.php:7 — CURRENT
use App\Models\BaseModel;
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Models\AssetDisposal.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\AssetDisposal.php","fixers":["fully_qualified_strict_types","no_unused_imports","single_line_after_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutating method | 1 Overwrite? | 2 Delete-before-store? | 3 Duplicate impl? | 4 Soft-delete x unique? | 5 Race? | 6 Authz hole? | 7 Lying message? | 8 Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` (25) → `AssetDisposalService::dispose()` | ok | ok | ASDI-09 | ok — `uq_acc_ad_asset` and `isDisposed()` prevent a second disposal | ok — the unique index rejects the second insert and the whole transaction (including its voucher) rolls back | ASDI-05 | ASDI-03 | ASDI-08 |

**Notes on the answers.** Q1: the method only changes the chosen asset's status; it never resets unrelated rows. Q2: it deletes nothing. Q4: a soft-deleted disposal still occupies `fixed_asset_id`, but no UI path re-disposes an asset after a disposal row exists. Q5: the race is contained by the unique key; the raw duplicate-key message is ASDI-01's problem. Q7: with ASDI-01 and ASDI-03 in place, a post-commit log failure tells the user the disposal failed after it succeeded. Q8: the four resource routes are dead code.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:1345` | `$disposableAssets = FixedAsset::where('status', 'Active')->where('is_active', true)->orderBy('name')->get()` loads every active asset into the disposal dropdown. 5 rows today; unbounded as the register grows. | QRY-15 | `gaurav/Accounting/AccDashboardController` (row `CLAIMED`; report not yet written) |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:1173` | The page this controller's `index` redirects to authorizes `tenant.accounting.dashboard.view`, while the tab and this controller use `tenant.accounting.fixed-asset.viewAny`. All five seeded roles hold both today, so the mismatch is latent. | AUTH-06 | `gaurav/Accounting/AccDashboardController` (row `CLAIMED`) |
| `Modules/Accounting/app/Models/BaseAccountingModel.php:27` | `updated_by = Auth::id() ?? 1` falls back to user 1. This path is not reached by the disposal service because it sets `updated_by` explicitly. | SEC-03 | [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) |
| `Modules/Accounting/app/Services/AccountingContext.php` | `getUserId()` / `getCampusId()` fall back to hard-coded `1`. Not reached by this controller's explicit `created_by` / campus data. | SEC-03 | [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) |

## 8. Not covered, and why

- **Scanner and self-check skipped.** `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are missing and `scan.php` must not be run per the audit brief. F1-F13 were worked manually with `Select-String`, `php -l`, `pint` and direct MySQL probes. The §15 self-check could not be executed.
- **No browser session and no tests (D4).** Every "Reproduce" line is either a static proof or a described request; no tenant login, no Pest/Dusk run.
- **Listing tab.** The table, filters, export button and modal partial are rendered by `AccDashboardController::assetsIntegration()`, whose index row is `CLAIMED`. They are not audited here; only the two cross-cutting defects above are recorded.
- **`VoucherService` / `PostingService` internals.** Owned by `VoucherController` (not yet audited). This report checks only how the disposal service calls them: `create()` throws on an unbalanced journal (used in ASDI-06) and `post()` is called inside the disposal transaction.
- **`FinancialYear` fallback.** `AssetDisposalService.php:59-63` falls back to the latest active financial year when the disposal date is outside every active year. ⚠ UNVERIFIED — whether the accounting policy allows that fallback; a product/accounting decision would settle it.
- **`approved_by` / `approved_at`.** `AssetDisposalService.php:162-163` stamps the current user as approver at creation. ⚠ UNVERIFIED — no written approval requirement was found for BR-FA-05; if one exists, this is a self-approval hole.
- **Blade compilation.** `show.blade.php` was read, not compiled or rendered.
