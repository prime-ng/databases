# ConcessionController — Fix Plan

Companion to `01-report.md`. Every "Before" block below is copied from the file as it stands; every "After" block is paste-ready. No item may be applied out of section order where the section says so.

**Apply in this order:** §1 (06 → 01 → 04 → 09), then §2, then §3, §5, §7, §8. §9 items need an answer first.

## 0. Do not touch

- `Modules/Accounting/resources/views/pages/partials/school-specific/_concessions.blade.php` — the list tab and create modal belong to `AccDashboardController`; no report exists for it. Any change here is a separate audit.
- `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` — same reason.
- `Modules/Accounting/routes/web.php` — shared. The only planned change (§9, CNCS-10) must be approved as a route change.
- `config/permissionslist.php` — shared. The only planned change (§9, CNCS-03) must be approved.
- `Modules/Accounting/app/Services/VoucherService.php`, `Ledger`, `Voucher`, `VoucherType` — owned elsewhere; only call/query them.
- `database/migrations/tenant/2026_09_16_100073_create_acc_concessions_table.php` — schema is correct; the defects are in code.
- `Modules/Accounting/database/seeders/AccountingPermissionSeeder.php` — deliberately a no-op; permissions come from `config/permissionslist.php`.
- `Modules/Accounting/app/Models/BaseAccountingModel.php` — shared base; no change needed.

## 1. Blockers reachable today

> Reachable **after** CNCS-03 is granted. Today the feature 403s for everyone but a super admin, so "reachable" here means reachable by the only account that can open the screen.

### 1.1 CNCS-06 — Generate the number from the highest suffix, including trashed rows

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:57-61`

**Before**

```php
        if (empty($validated['concession_no'])) {
            $year = Carbon::parse($validated['concession_date'])->format('Y');
            $count = Concession::whereYear('concession_date', $year)->count() + 1;
            $validated['concession_no'] = sprintf('CON-%s-%04d', $year, $count);
        }
```

**After**

```php
        if (empty($validated['concession_no'])) {
            $year = Carbon::parse($validated['concession_date'])->format('Y');

            $lastSequence = Concession::withTrashed()
                ->whereYear('concession_date', $year)
                ->pluck('concession_no')
                ->map(fn (string $number): int => (int) substr($number, -4))
                ->max() ?? 0;

            $validated['concession_no'] = sprintf('CON-%s-%04d', $year, $lastSequence + 1);
        }
```

**Why this shape:** `withTrashed()` makes deleted rows participate, so the unique index (`uq_acc_conc_no`) is no longer hit after a soft delete. `max()` of the last four digits is monotonic even when a row was force-deleted (a `count()+1` would reuse a gap). Residual risk: two concurrent creates still race between read and insert; the unique index catches it and the request fails — acceptable until a dedicated sequence table exists (out of scope).

**Verify:** create 0001 and 0002 in 2026, soft-delete 0001, create again → `CON-2026-0003` (no SQL error). Repeat after deleting 0002 → `CON-2026-0004`.

### 1.2 CNCS-01 — One `DB::transaction()` per write, no raw exception text

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php` — three blocks, in this order.

#### store(): replace lines 72-82

**Before**

```php
        DB::beginTransaction();
        try {
            $concession = Concession::create($validated);
            DB::commit();

            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
                ->with('success', "Concession {$concession->concession_no} created successfully.");
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->withInput()->with('error', 'Failed to create concession: ' . $e->getMessage());
        }
```

**After**

```php
        $concession = DB::transaction(function () use ($validated): Concession {
            $concession = Concession::create($validated);

            activityLog($concession, 'Created', [
                'message'      => "Concession {$concession->concession_no} created",
                'performed_by' => auth()->id(),
            ]);

            return $concession;
        });

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
            ->with('success', "Concession {$concession->concession_no} created successfully.");
```

#### update(): replace lines 142-152

**Before**

```php
        DB::beginTransaction();
        try {
            $concession->update($validated);
            DB::commit();

            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
                ->with('success', "Concession {$concession->concession_no} updated successfully.");
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->withInput()->with('error', 'Failed to update concession: ' . $e->getMessage());
        }
```

**After**

```php
        DB::transaction(function () use ($concession, $validated): void {
            $concession->update($validated);

            activityLog($concession, 'Updated', [
                'message'      => "Concession {$concession->concession_no} updated",
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
            ->with('success', "Concession {$concession->concession_no} updated successfully.");
```

#### post(): two spans, replace lines 182-183 and 250-257

**Before (span A)**

```php
        DB::beginTransaction();
        try {
```

**After (span A)**

```php
        DB::transaction(function () use ($concession): void {
```

**Before (span B)**

```php
            DB::commit();

            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
                ->with('success', "Concession {$concession->concession_no} posted successfully.");
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Failed to post concession: ' . $e->getMessage());
        }
```

**After (span B)**

```php
            activityLog($concession, 'Posted', [
                'message'      => "Concession {$concession->concession_no} posted",
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
            ->with('success', "Concession {$concession->concession_no} posted successfully.");
```

**Do not re-indent the body between span A and span B.** It already sits at the depth the closure expects (12 spaces), and `$this` is bound automatically inside a closure declared in a method. `$validated` is not used in `post()`, so `use ($concession)` is sufficient.

**Remove the now-unused import?** `DomainException` is still thrown at line 199 and `Illuminate\Http\Request` is still used by `index()`; leave both.

**Verify:** "Before" blocks no longer match, `Select-String -Pattern 'getMessage\('` returns nothing, and a forced failure (e.g. duplicate number by racing) rolls back both the concession and its activity-log row.

### 1.3 CNCS-04 — Status may only move through approve/post/cancel

**Files:** controller (two spots) and `Modules\Accounting\resources\views\concession\edit.blade.php:229-237`.

#### store(): insert after line 41

**Before**

```php
        $validated = $request->validated();

        $gross = (float) $validated['gross_amount'];
```

**After**

```php
        $validated = $request->validated();

        if (!in_array($validated['status'] ?? 'Draft', ['Draft', 'Approved'], true)) {
            $validated['status'] = 'Draft';
        }

        $gross = (float) $validated['gross_amount'];
```

This is the **first** of the two identical `$validated` / `$gross` pairs in the file (store at 41-43, update at 128-130). The create modal only offers Draft/Approved, so this only rejects a crafted `status=Posted|Cancelled`.

#### update(): insert after line 128

**Before**

```php
        $validated = $request->validated();

        $gross = (float) $validated['gross_amount'];
```

**After**

```php
        $validated = $request->validated();
        unset($validated['status']);

        $gross = (float) $validated['gross_amount'];
```

This is the **second** pair (update). Use the surrounding `in_array($concession->status, ['Posted', 'Cancelled'], true)` guard at line 124 to confirm you are editing the right one.

#### edit.blade — make Status read-only

**Before**

```blade
                                    <div class="col-md-12">
                                        <label for="edit_status" class="form-label fw-semibold">Status <span class="text-danger">*</span></label>
                                        <select name="status" id="edit_status" class="form-select form-select-sm" required>
                                            <option value="Draft" {{ old('status', $concession->status) === 'Draft' ? 'selected' : '' }}>Draft</option>
                                            <option value="Approved" {{ old('status', $concession->status) === 'Approved' ? 'selected' : '' }}>Approved</option>
                                            <option value="Posted" {{ old('status', $concession->status) === 'Posted' ? 'selected' : '' }}>Posted</option>
                                            <option value="Cancelled" {{ old('status', $concession->status) === 'Cancelled' ? 'selected' : '' }}>Cancelled</option>
                                        </select>
                                    </div>
```

**After**

```blade
                                    <div class="col-md-12">
                                        <label class="form-label fw-semibold">Status</label>
                                        <div class="pt-1">
                                            <span class="badge bg-secondary">{{ $concession->status }}</span>
                                            <small class="text-muted ms-2">Changed only through Approve, Post or Cancel.</small>
                                        </div>
                                    </div>
```

**Why also the view:** with `status` unset in the controller, the form would promise a change that never happens. Removing the control keeps the UI honest.

**Verify:** a user with only `...update` submits the edit form with `status=Posted` added by hand → the row keeps `Draft`/`Approved` and `voucher_id` is unchanged.

### 1.4 CNCS-09 — Give the `create` route a real endpoint

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php` — insert between `index()` and `store()`.

**Before**

```php
        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions']);
    }

    public function store(ConcessionRequest $request): RedirectResponse
```

**After**

```php
        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions']);
    }

    public function create(): RedirectResponse
    {
        Gate::authorize('tenant.accounting.concession.create');

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions']);
    }

    public function store(ConcessionRequest $request): RedirectResponse
```

**Why not `->except(['create'])`:** that edits a shared route file for a cosmetic 404; a redirect keeps the resource intact, honours the gate, and lands the user on the tab whose modal is the real create form.

**Verify:** `GET accounting/concession/create` → 302 to `accounting.menu.schoolSpecific?tab=concessions`, not 500.

## 2. Fixes that arm a latent defect (sequenced)

### 2.1 CNCS-18 — Deterministic ledger and voucher-type selection in `post()`

**Must be applied before CNCS-03** (granting the permissions is what makes `post()` reachable for Account Staff).

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:188-212`

**Before (ledger)**

```php
                if (!$concessionLedgerId) {
                    $concessionLedgerId = Ledger::where('is_active', true)
                        ->where(function ($q) {
                            $q->where('name', 'like', '%Concession%')
                              ->orWhere('name', 'like', '%Scholarship%')
                              ->orWhere('name', 'like', '%Fee Discount%');
                        })
                        ->value('id');
                }
```

**After (ledger)**

```php
                if (!$concessionLedgerId) {
                    $concessionLedgerId = Ledger::where('is_active', true)
                        ->whereHas('accountGroup', fn ($q) => $q->whereIn('nature', ['Expense', 'Income']))
                        ->where(function ($q) {
                            $q->where('name', 'like', '%Concession%')
                              ->orWhere('name', 'like', '%Scholarship%')
                              ->orWhere('name', 'like', '%Fee Discount%');
                        })
                        ->orderBy('name')
                        ->value('id');
                }
```

The nature filter excludes "Merit Scholarship Endowment" (Equity, id 46) and leaves "Fee Concessions and Scholarships" (Expense, id 51); `orderBy('name')` makes the choice deterministic if more than one remains.

**Before (voucher type)**

```php
                $crnType = VoucherType::whereIn('base_type', ['Credit_Note', 'Journal'])->where('is_active', true)->first()
                    ?? VoucherType::whereIn('base_type', ['Credit_Note', 'Journal'])->first()
                    ?? VoucherType::where(function ($q) {
                        $q->whereIn('code', ['CREDIT_NOTE', 'CRN', 'CDN', 'JOURNAL', 'JNL', 'JRN'])
                          ->orWhere('code', 'like', 'CRN%')
                          ->orWhere('code', 'like', 'CDN%')
                          ->orWhere('code', 'like', 'JNL%')
                          ->orWhere('code', 'like', 'JRN%');
                    })->first()
                    ?? VoucherType::where('is_active', true)->first()
                    ?? VoucherType::firstOrFail();
```

**After (voucher type)**

```php
                $crnType = VoucherType::where('base_type', 'Credit_Note')->where('is_active', true)->orderBy('id')->first()
                    ?? VoucherType::where('base_type', 'Credit_Note')->orderBy('id')->first()
                    ?? VoucherType::where('base_type', 'Journal')->where('is_active', true)->orderBy('id')->first()
                    ?? VoucherType::where('base_type', 'Journal')->orderBy('id')->first()
                    ?? VoucherType::where(function ($q) {
                        $q->whereIn('code', ['CREDIT_NOTE', 'CRN', 'CDN'])
                          ->orWhere('code', 'like', 'CRN%')
                          ->orWhere('code', 'like', 'CDN%');
                    })->where('is_active', true)->orderBy('id')->first()
                    ?? VoucherType::where('is_active', true)->orderBy('id')->first()
                    ?? VoucherType::orderBy('id')->firstOrFail();
```

Credit Note is now preferred over Journal at every tier, and every tier has an `orderBy`.

**Verify:** run `post()` on a Draft concession with `timing = After_Demand` and no ledgers selected; the created voucher's `voucher_type_id` is a `Credit_Note` type, and the debit line's ledger is an Expense/Income ledger.

## 3. Errors & transactions (F1/F2)

### 3.1 CNCS-02 — Activity log for the six writes not covered in §1.2

`store`, `update` and `post` already log inside their new transactions (see §1.2). Six remain.

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php`

#### approve(): replace lines 163-171

**Before**

```php
        $concession->update([
            'status'        => 'Approved',
            'authorised_by' => auth()->id(),
            'authorised_at' => now(),
            'updated_by'    => auth()->id(),
        ]);

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
            ->with('success', "Concession {$concession->concession_no} approved successfully.");
```

**After**

```php
        DB::transaction(function () use ($concession): void {
            $concession->update([
                'status'        => 'Approved',
                'authorised_by' => auth()->id(),
                'authorised_at' => now(),
                'updated_by'    => auth()->id(),
            ]);

            activityLog($concession, 'Approved', [
                'message'      => "Concession {$concession->concession_no} approved",
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
            ->with('success', "Concession {$concession->concession_no} approved successfully.");
```

#### cancel(): replace lines 272-279

**Before**

```php
        $concession->update([
            'status'           => 'Cancelled',
            'cancelled_reason' => $request->input('cancelled_reason'),
            'updated_by'       => auth()->id(),
        ]);

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
            ->with('success', "Concession {$concession->concession_no} cancelled successfully.");
```

**After**

```php
        DB::transaction(function () use ($concession, $request): void {
            $concession->update([
                'status'           => 'Cancelled',
                'cancelled_reason' => $request->input('cancelled_reason'),
                'updated_by'       => auth()->id(),
            ]);

            activityLog($concession, 'Cancelled', [
                'message'      => "Concession {$concession->concession_no} cancelled",
                'reason'       => $request->input('cancelled_reason'),
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
            ->with('success', "Concession {$concession->concession_no} cancelled successfully.");
```

#### toggleStatus(): replace lines 286-288

**Before**

```php
        $concession->update(['is_active' => !$concession->is_active]);

        return redirect()->back()->with('success', 'Concession status updated.');
```

**After**

```php
        DB::transaction(function () use ($concession): void {
            $concession->update(['is_active' => !$concession->is_active]);

            activityLog($concession, 'StatusChanged', [
                'message'      => "Concession {$concession->concession_no} " . ($concession->is_active ? 'activated' : 'deactivated'),
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->back()->with('success', 'Concession status updated.');
```

#### destroy(): replace lines 299-302

**Before**

```php
        $concession->delete();

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
            ->with('success', 'Concession deleted successfully.');
```

**After**

```php
        DB::transaction(function () use ($concession): void {
            $concession->delete();

            activityLog($concession, 'Trashed', [
                'message'      => "Concession {$concession->concession_no} moved to trash",
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'concessions'])
            ->with('success', 'Concession deleted successfully.');
```

#### restore(): replace lines 318-321

**Before**

```php
        $concession = Concession::onlyTrashed()->findOrFail($id);
        $concession->restore();

        return redirect()->route('accounting.concession.trashed')->with('success', 'Concession restored successfully.');
```

**After**

```php
        $concession = Concession::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($concession): void {
            $concession->restore();

            activityLog($concession, 'Restored', [
                'message'      => "Concession {$concession->concession_no} restored",
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.concession.trashed')->with('success', 'Concession restored successfully.');
```

#### forceDelete(): replace lines 328-331

**Before**

```php
        $concession = Concession::onlyTrashed()->findOrFail($id);
        $concession->forceDelete();

        return redirect()->route('accounting.concession.trashed')->with('success', 'Concession permanently deleted.');
```

**After**

```php
        $concession = Concession::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($concession): void {
            $concession->forceDelete();

            activityLog($concession, 'Deleted', [
                'message'      => "Concession {$concession->concession_no} permanently deleted",
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.concession.trashed')->with('success', 'Concession permanently deleted.');
```

**Verify:** approve/post/cancel/toggle/destroy/restore/force-delete each add exactly one row to the tenant activity log, and each log row is in the same transaction as its write (delete the log insert temporarily → the write rolls back).

## 4. Authorization (F3)

Both F3 findings that change behaviour are **DECISIONs**, not mechanical fixes:

- **CNCS-03** (missing permission keys, blocker) → §9.1.
- **CNCS-05** (post from Draft, medium) → §9.2.
- CNCS-04 is fixed in §1.3 because it is a write-path defect, not a permission-model question.

No other authorization change is proposed: the seven existing abilities map 1:1 to the methods, and `ConcessionRequest::authorize()` returning `true` is correct because every method gates explicitly.

## 5. Validation, routes, models (F4/F5/F7)

### 5.1 CNCS-07 — Let an unticked checkbox mean "inactive" on update

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:139-140`

**Before**

```php
        $validated['updated_by'] = auth()->id();
        $validated['is_active']  = $request->boolean('is_active', true);
```

**After**

```php
        $validated['updated_by'] = auth()->id();
        $validated['is_active']  = $request->boolean('is_active');
```

`store()` at line 70 keeps its `true` default: a new concession should be active when the create modal omits the field. Only `update()` has the unchecked-box problem.

**Verify:** untick "Active Record" on the edit form, save → `is_active = 0`; tick it, save → `1`.

### 5.2 CNCS-08 — Move the cancel validation into a FormRequest

**New file:** `Modules\Accounting\app\Http\Requests\CancelConcessionRequest.php`

```php
<?php

declare(strict_types=1);

namespace Modules\Accounting\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CancelConcessionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'cancelled_reason' => ['required', 'string', 'max:500'],
        ];
    }
}
```

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php`

**Before**

```php
use Modules\Accounting\Http\Requests\ConcessionRequest;
```

**After**

```php
use Modules\Accounting\Http\Requests\CancelConcessionRequest;
use Modules\Accounting\Http\Requests\ConcessionRequest;
```

**Before**

```php
    public function cancel(Request $request, Concession $concession): RedirectResponse
    {
        Gate::authorize('tenant.accounting.concession.cancel');

        $request->validate([
            'cancelled_reason' => 'required|string|max:500',
        ]);

```

**After**

```php
    public function cancel(CancelConcessionRequest $request, Concession $concession): RedirectResponse
    {
        Gate::authorize('tenant.accounting.concession.cancel');

```

Apply **before** §3.1's `cancel()` block? Either order works: §3.1 replaces the `$concession->update(...)` block, §5.2 replaces the signature and the `validate` block; the text spans do not overlap. Leave `$request->input('cancelled_reason')` in place — it still works from a FormRequest.

**Note:** `Illuminate\Http\Request` remains imported for `index(Request $request)`.

**Verify:** submit the cancel form with an empty reason → 302 back with a validation error, not a 500; `php -l` passes on the new file.

### 5.3 CNCS-13 — Correct the decimal cast

**File:** `Modules\Accounting\app\Models\Concession.php:55`

**Before**

```php
        'concession_percent' => 'decimal:9,4',
```

**After**

```php
        'concession_percent' => 'decimal:4',
```

**Verify:** `cast='25.5000'` for a stored `25.5000`, and the other four decimal casts in the model (`gross_amount`, `concession_amount`, `net_amount`) already use `decimal:2`.

## 6. Queries & performance (F9)

None. CNCS-14 is a DECISION (§9.5) because the same query lives in the create modal, which this plan may not edit. No N+1 was found: `show()` eager-loads 11 relations and `trashed()` eager-loads the two it prints.

## 7. Views (F10)

### 7.1 CNCS-15 — Stop interpolating `concession_no` into inline JavaScript

**File:** `Modules\Accounting\resources\views\concession\show.blade.php` — two buttons.

#### Approve button (lines 23-33)

**Before**

```blade
                                <button type="button" class="btn btn-sm btn-outline-primary" title="Approve Concession"
                                        onclick="const form = this.closest('form'); Swal.fire({
                                            title: 'Approve Concession?',
                                            html: 'Are you sure you want to approve concession <strong>{{ $concession->concession_no }}</strong> for <strong>₹{{ number_format((float) $concession->concession_amount, 2) }}</strong>?',
                                            icon: 'question',
                                            showCancelButton: true,
                                            confirmButtonColor: '#0d6efd',
                                            cancelButtonColor: '#6c757d',
                                            confirmButtonText: '<i class=\'bi bi-check2-circle me-1\'></i> Yes, approve',
                                            cancelButtonText: 'Cancel'
                                        }).then((r) => { if (r.isConfirmed && form) form.submit(); });">
```

**After**

```blade
                                <button type="button" class="btn btn-sm btn-outline-primary" title="Approve Concession"
                                        data-concession-no="{{ $concession->concession_no }}"
                                        data-amount="{{ number_format((float) $concession->concession_amount, 2) }}"
                                        onclick="const form = this.closest('form'); const no = this.dataset.concessionNo; const amount = this.dataset.amount; Swal.fire({
                                            title: 'Approve Concession?',
                                            text: 'Are you sure you want to approve concession ' + no + ' for Rs ' + amount + '?',
                                            icon: 'question',
                                            showCancelButton: true,
                                            confirmButtonColor: '#0d6efd',
                                            cancelButtonColor: '#6c757d',
                                            confirmButtonText: 'Yes, approve',
                                            cancelButtonText: 'Cancel'
                                        }).then((r) => { if (r.isConfirmed && form) form.submit(); });">
```

#### Post button (lines 44-54)

**Before**

```blade
                                <button type="button" class="btn btn-sm btn-outline-success" title="Post Concession"
                                        onclick="const form = this.closest('form'); Swal.fire({
                                            title: 'Post Concession?',
                                            html: 'Posting concession <strong>{{ $concession->concession_no }}</strong> (₹{{ number_format((float) $concession->concession_amount, 2) }}) will commit accounting voucher entries. This action cannot be undone.',
                                            icon: 'warning',
                                            showCancelButton: true,
                                            confirmButtonColor: '#198754',
                                            cancelButtonColor: '#6c757d',
                                            confirmButtonText: '<i class=\'bi bi-send-check me-1\'></i> Yes, post it!',
                                            cancelButtonText: 'Cancel'
                                        }).then((r) => { if (r.isConfirmed && form) form.submit(); });">
```

**After**

```blade
                                <button type="button" class="btn btn-sm btn-outline-success" title="Post Concession"
                                        data-concession-no="{{ $concession->concession_no }}"
                                        data-amount="{{ number_format((float) $concession->concession_amount, 2) }}"
                                        onclick="const form = this.closest('form'); const no = this.dataset.concessionNo; const amount = this.dataset.amount; Swal.fire({
                                            title: 'Post Concession?',
                                            text: 'Posting concession ' + no + ' (Rs ' + amount + ') will commit accounting voucher entries. This action cannot be undone.',
                                            icon: 'warning',
                                            showCancelButton: true,
                                            confirmButtonColor: '#198754',
                                            cancelButtonColor: '#6c757d',
                                            confirmButtonText: 'Yes, post it!',
                                            cancelButtonText: 'Cancel'
                                        }).then((r) => { if (r.isConfirmed && form) form.submit(); });">
```

**Why this is safe:** the value now leaves Blade as an HTML attribute (escaped by `{{ }}`) and is read back through `dataset`; it is then passed to SweetAlert's `text:` option, which sets `textContent`. No string from the database ever enters a JavaScript source position. Dropping the `<strong>`/`<i>` markup is the cost of removing `html:`.

**Note:** the identical `html:` pattern in `_concessions.blade.php:247` is **out of scope** (§0) and must be fixed by the `AccDashboardController` report.

**Verify:** set `concession_no` to `X');alert(1);//`, open the detail page, click Approve → the dialog shows the literal text and no script runs.

## 8. Style (F12) - one item per file

### 8.1 CNCS-17 — Run Pint on the three files

```
.\vendor\bin\pint Modules/Accounting/app/Http/Controllers/ConcessionController.php Modules/Accounting/app/Http/Requests/ConcessionRequest.php Modules/Accounting/app/Models/Concession.php
```

**File:** `Modules/Accounting/app/Models/Concession.php:7` — Pint's `no_unused_imports` deletes the line; no manual edit needed:

```php
use App\Models\BaseModel;
```

**Before running:** apply §1-§5 first, otherwise Pint will rewrite the "Before" blocks and this plan stops matching the file. Then re-check:

```
.\vendor\bin\pint --test <the three files>
```

Expected: `{"tool":"pint","result":"pass"}`.

## 9. Deferred / decisions

### 9.1 CNCS-03 — Add the concession permission key (blocker)

**Question:** should the Concessions tab be granted to the same roles that hold the other 312 accounting permissions?

**If yes**, add one line to `config/permissionslist.php`, after line 644 (`'accounting.event-posting' => ...`):

```php
        'accounting.concession' => array_merge($crud, ['approve', 'post', 'cancel']),
```

This is the same shape as `'accounting.voucher'` (line 615). ⚠ SHARED: the file is global and the change also appears on the role-permission screen. Nothing else in the codebase needs to change: the gates already name these abilities.

**If no**, the feature stays super-admin-only and the controller should say so (remove the gates and document it); that is a worse outcome than granting the permissions.

**Sequencing:** do §2.1 (CNCS-18) **before** this. Once Account Staff can post, the non-deterministic ledger/voucher-type fallback becomes a live financial risk.

### 9.2 CNCS-05 — Require approval before posting (medium)

**Question:** may a Draft be posted directly?

**Recommended:** no. Change line 178:

**Before**

```php
        if (!in_array($concession->status, ['Draft', 'Approved'], true)) {
```

**After**

```php
        if ($concession->status !== 'Approved') {
```

and delete the self-authorisation fallback at lines 243-246:

**Before**

```php
            if (!$concession->authorised_by) {
                $concession->authorised_by = auth()->id();
                $concession->authorised_at = now();
            }
```

**After** — remove those four lines entirely.

If the product owner wants Draft-posting kept, leave the code as-is and record that the `...approve` gate is advisory.

### 9.3 CNCS-10 — Make restore a POST (high)

**Question:** may the route method change? ⚠ SHARED: `Modules/Accounting/routes/web.php`.

**File:** `Modules\Accounting\routes\web.php:501`

**Before**

```php
Route::get('/concession/{id}/restore', [ConcessionController::class, 'restore'])->name('concession.restore');
```

**After**

```php
Route::post('/concession/{id}/restore', [ConcessionController::class, 'restore'])->name('concession.restore');
```

**File:** `Modules\Accounting\resources\views\concession\trash.blade.php:42-44`

**Before**

```blade
                                            <a href="{{ route('accounting.concession.restore', $item->id) }}" class="btn btn-xs btn-outline-success" title="Restore">
                                                <i class="bi bi-arrow-counterclockwise"></i> Restore
                                            </a>
```

**After**

```blade
                                            <form action="{{ route('accounting.concession.restore', $item->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Restore this concession?');">
                                                @csrf
                                                <button type="submit" class="btn btn-xs btn-outline-success" title="Restore">
                                                    <i class="bi bi-arrow-counterclockwise"></i> Restore
                                                </button>
                                            </form>
```

**Alternative:** keep GET and swap the hand-rolled cell for `<x-backend.table.action-trashed ... />`, which adapts to the route method — but that does not remove the CSRF problem, so it is not a fix.

### 9.4 CNCS-11 — Extract the posting flow (medium, refactor)

**Question:** do we refactor now or after the behaviour fixes?

**Recommended:** after. Shape:

- `Modules\Accounting\app\Services\ConcessionPostingService.php` with `post(Concession $concession): Voucher|null`, owning the `After_Demand` branch, the ledger/type resolution (CNCS-18's code moves here verbatim), the `VoucherService` calls and the concession write.
- `ConcessionController::post()` becomes: gate → status policy → `$this->posting->post($concession)` → activity log → redirect.

Not paste-ready by design: it moves ~60 lines and needs its own test. Do it in one commit with no behaviour change.

### 9.5 CNCS-14 — Bound the authoriser dropdown (medium)

**Question:** who may be nominated as `authorised_by`?

**Options:**

1. **Permission-filtered (recommended):** list only users holding `tenant.accounting.concession.approve`. This is the smallest set and matches the semantic. Implement once the permission key exists (§9.1), and apply the same query in `AccDashboardController::schoolSpecific()` (line 2569) for the create modal — two files, one decision.
2. **Searchable remote select:** keep all users, add an AJAX search endpoint. Bigger UI change, also two files.
3. **Accept:** leave 5,671 options; document the page-weight cost.

Do **not** apply a `limit()` as a half-fix: it silently hides approvers and is worse than the slow page.

### 9.6 CNCS-16 — Decide what cancelling a Posted concession means (high)

**Question:** is a Posted concession cancellable at all?

**Option A — forbid (recommended until a reversal exists).** In `cancel()`, after the "already cancelled" guard:

**Before**

```php
        if ($concession->status === 'Cancelled') {
            return redirect()->back()->with('warning', 'Concession is already cancelled.');
        }
```

**After**

```php
        if ($concession->status === 'Cancelled') {
            return redirect()->back()->with('warning', 'Concession is already cancelled.');
        }

        if ($concession->status === 'Posted') {
            return redirect()->back()->with('error', 'A posted concession cannot be cancelled until its credit note is reversed.');
        }
```

The message names the missing capability honestly. `VoucherService` has no reversal method today, so this is the only correct action.

**Option B — reverse.** Implement a `VoucherService::reverse(Voucher $voucher)` (or a new credit note) and call it here, then clear `voucher_id`. This needs a finance decision and a new service method (not in scope).

Either way, the current behaviour (cancel while the voucher stays posted) must not survive.

## 10. Findings with no plan item

- **CNCS-12** (missing return types on `index`, `show`, `edit`, `trashed`). Zero runtime impact. Fold it into CNCS-11's refactor (§9.4) rather than a separate commit: adding `: RedirectResponse` to `index`, `: View` to `show`/`edit`/`trashed` is a four-line change that has no test to prove.
