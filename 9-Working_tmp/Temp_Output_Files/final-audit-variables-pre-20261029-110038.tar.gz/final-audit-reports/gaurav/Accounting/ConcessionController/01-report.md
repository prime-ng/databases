# ConcessionController — Final Audit Report

- **Controller:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php`
- **Abbreviation:** CNCS
- **Developer:** gaurav
- **Module:** Accounting
- **Mode:** module
- **Protocol:** `.claude/rules/final-audit.md`
- **Date:** 2026-10-24

---

## 0. The screen in plain words

"Concessions" is the Accounting register of fee waivers and scholarships. An accountant records the gross fee, the amount waived and the net demand, optionally links the student's ledger and the concession (expense) ledger, then moves the record through **Draft → Approved → Posted**, or **→ Cancelled**. "Posting" is the moment money becomes real: for a concession timed `After_Demand` the controller asks `VoucherService` to create and post a credit-note voucher against the student ledger, and stores that voucher id on the concession. A concession timed `Before_Demand` just flips its status to Posted with no voucher. The screen is a tab (not a standalone page) inside **Accounting → School & Grants**, and the list is rendered by `AccDashboardController::schoolSpecific()`, not by this controller's `index()`. The user sees a tabbed table, a create modal, an edit form, a detail card, and a Trash page.

## 1. Verdict

**18 findings: 4 blocker, 5 high, 5 medium, 4 low — 6 of them are DECISIONs that must be answered before anyone writes code.**

The screen is not usable today by any normal user. The controller gates every action on `tenant.accounting.concession.*` abilities, but **not one of those abilities exists**: `config/permissionslist.php` has no `accounting.concession` key, so the tenant has 0 concession permissions out of 312 accounting permissions. A School Admin can open the Accounting dashboard (`true`) but fails every concession gate (`false`) and gets 403 on every route. Only a super admin (via `Gate::before`) can use the screen.

Three further blockers stand behind that one. Every database failure flashes the raw SQL message to the browser (CNCS-01). `GET /accounting/concession/create` is registered by `Route::resource` but `ConcessionController` has no `create()` method → 500 (CNCS-09). And the workflow status is mass-assignable: a user holding only `...update` can set `status=Posted` on a Draft/Approved row through the edit form, skipping both the `...approve` and `...post` gates and producing a Posted concession with no voucher (CNCS-04).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 4 | 5 | 5 | 4 | 6 | 18 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors & logging | CNCS-01, CNCS-02 | F8 Queries | CNCS-14 |
| F2 Transactions & state | CNCS-16 | F9 Views | CNCS-15 |
| F3 Authorization | CNCS-03, CNCS-04, CNCS-05 | F10 Style | CNCS-17 |
| F4 Validation | CNCS-06, CNCS-07, CNCS-08 | F11 Dead code | — |
| F5 Routes | CNCS-09, CNCS-10 | F12 Duplication | — |
| F6 Controller shape | CNCS-11, CNCS-12, CNCS-18 | F13 Cross-cutting | — |
| F7 Models | CNCS-13 | | |

## 3. Scope - every file this controller uses

| File | Lines | Role | Owner |
|---|---|---|---|
| `Modules\Accounting\app\Http\Controllers\ConcessionController.php` | 333 | audited controller, 13 public methods | **this report** |
| `Modules\Accounting\app\Http\Requests\ConcessionRequest.php` | 61 | validation for store/update | **this report** |
| `Modules\Accounting\app\Models\Concession.php` | 175 | model, fillable, casts, scopes | **this report** |
| `Modules\Accounting\resources\views\concession\edit.blade.php` | 332 | edit form | **this report** |
| `Modules\Accounting\resources\views\concession\show.blade.php` | 200 | detail card + action buttons | **this report** |
| `Modules\Accounting\resources\views\concession\trash.blade.php` | 69 | trash list | **this report** |
| `Modules\Accounting\resources\views\pages\partials\school-specific\_concessions.blade.php` | 612 | list tab + create modal | LINK ↗ `AccDashboardController` |
| `Modules\Accounting\app\Http\Controllers\AccDashboardController.php` | 2646 | renders the list (`schoolSpecific`, line 2478) | LINK ↗ unclaimed |
| `Modules\Accounting\app\Services\VoucherService.php` | 402 | `create()`/`post()` for the credit note | LINK ↗ VoucherController |
| `Modules\Accounting\app\Models\Ledger.php` | 408 | student + concession ledgers | LINK ↗ LedgerController |
| `Modules\Accounting\app\Models\Voucher.php` | 415 | linked voucher | LINK ↗ VoucherController |
| `Modules\Accounting\app\Models\VoucherType.php` | 185 | credit-note type lookup | LINK ↗ VoucherTypeController |
| `Modules\Accounting\app\Models\Campus.php` | 83 | campus dropdown | LINK ↗ CampusController |
| `Modules\Accounting\app\Models\FinancialYear.php` | 168 | active-year default | LINK ↗ FinancialYearController |
| `Modules\Accounting\app\Models\AccountingPeriod.php` | 137 | period dropdown | LINK ↗ AccountingPeriodController |
| `Modules\Accounting\app\Models\BillReference.php` | 206 | bill-reference dropdown | LINK ↗ BillReferenceController |
| `Modules\Accounting\app\Models\BaseAccountingModel.php` | 74 | created_by/updated_by injection, SoftDeletes | LINK ↗ AccountGroupController |
| `Modules\StudentProfile\app\Models\Student.php` | 620 | `student()` relation | LINK ↗ StudentReportController |
| `Modules\SchoolSetup\app\Models\User.php` | 318 | authoriser dropdown | LINK ↗ MobileTeacherDashboardController |
| `Modules\Accounting\routes\web.php` | 536 | routes 499-507 | ⚠ SHARED |
| `config/permissionslist.php` | 1824 | permission names, `$crud` at 176 | ⚠ SHARED |
| `database/migrations/tenant/2026_09_16_100073_create_acc_concessions_table.php` | 91 | schema, unique index, CHECK | read-only |
| `app\Helpers\activityLog.php` | 51 | audit-log helper | shared helper |

## 4. Routes

Route probe (method, URI, middleware as registered):

```
accounting.concession.trashed | GET | accounting/concession/trash/view
accounting.concession.restore | GET | accounting/concession/{id}/restore
accounting.concession.forceDelete | DELETE | accounting/concession/{id}/force-delete
accounting.concession.approve | POST | accounting/concession/{concession}/approve
accounting.concession.post | POST | accounting/concession/{concession}/post
accounting.concession.cancel | POST | accounting/concession/{concession}/cancel
accounting.concession.toggleStatus | POST | accounting/concession/{concession}/toggle-status
accounting.concession.index | GET | accounting/concession
accounting.concession.create | GET | accounting/concession/create
accounting.concession.store | POST | accounting/concession
accounting.concession.show | GET | accounting/concession/{concession}
accounting.concession.edit | GET | accounting/concession/{concession}/edit
accounting.concession.update | PUT,PATCH | accounting/concession/{concession}
accounting.concession.destroy | DELETE | accounting/concession/{concession}
```

Notes:

- Source: `Modules\Accounting\routes\web.php:499-507` — five explicit routes, then `Route::resource('concession', ...)` at 507.
- All 14 routes sit inside the Accounting module group and therefore carry the tenant middleware stack (tenancy initialization + auth). No route is marked `withoutMiddleware`.
- `accounting.concession.create` exists in the route table but **not in the controller** (CNCS-09).
- `accounting.concession.restore` is a **GET** that mutates state (CNCS-10).
- `accounting.concession.index` exists but only redirects to the School & Grants tab; the list itself is served by `accounting.menu.schoolSpecific`.
- Parameter name difference: `restore`/`forceDelete` take `{id}` and receive `int`; the other actions take `{concession}` and receive a route-model-bound model. This is consistent within each method and is not a finding.

## 5. Per-method table

| # | Method | Lines | Gate | Validation | Transaction | Activity log | Findings |
|---|---|---|---|---|---|---|---|
| 1 | `index` | 30-35 | `...viewAny` | — | — | — | CNCS-12 |
| 2 | `store` | 37-83 | `...create` | `ConcessionRequest` | manual, try/catch | **none** | CNCS-01, CNCS-02, CNCS-04, CNCS-06 |
| 3 | `show` | 85-92 | `...view` | — | — | — | CNCS-12 |
| 4 | `edit` | 94-118 | `...update` | — | — | — | CNCS-12, CNCS-14 |
| 5 | `update` | 120-153 | `...update` | `ConcessionRequest` | manual, try/catch | **none** | CNCS-01, CNCS-02, CNCS-04, CNCS-07 |
| 6 | `approve` | 155-172 | `...approve` | — | **none** | **none** | CNCS-02 |
| 7 | `post` | 174-258 | `...post` | — | manual, try/catch | **none** | CNCS-01, CNCS-02, CNCS-05, CNCS-11, CNCS-18 |
| 8 | `cancel` | 260-280 | `...cancel` | inline `$request->validate` | **none** | **none** | CNCS-02, CNCS-08, CNCS-16 |
| 9 | `toggleStatus` | 282-289 | `...update` | — | **none** | **none** | CNCS-02 |
| 10 | `destroy` | 291-303 | `...delete` | — | **none** | **none** | CNCS-02 |
| 11 | `trashed` | 305-312 | `...delete` | — | — | — | CNCS-12 |
| 12 | `restore` | 314-322 | `...delete` | — | **none** | **none** | CNCS-02, CNCS-10 |
| 13 | `forceDelete` | 324-332 | `...delete` | — | **none** | **none** | CNCS-02 |
| — | `create` | **absent** | — | — | — | — | CNCS-09 |

`store`, `update` and `post` are the only methods with any error handling; the other seven mutating methods have none.

## 6. Findings

### CNCS-01 — B — ERR-01 — Raw database exception text is flashed to the browser

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:79-81`, `149-151`, `254-256`

**Evidence:**

```
$f="Modules\Accounting\app\Http\Controllers\ConcessionController.php"
"getMessage=" + (Select-String -Path $f -Pattern 'getMessage\(\)' -AllMatches).Count
getMessage=3
```

Line 81, for example:

```php
return redirect()->back()->withInput()->with('error', 'Failed to create concession: ' . $e->getMessage());
```

**Reproduce:** force a DB error on `store` (e.g. a `concession_no` duplicate that passes the `unique` rule in a race, or a NULL `financial_year_id`) and submit the create form. The flash message is `... SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry ... for key 'uq_acc_conc_no' ...` including the table and column names.

**Consequence:** internal schema details are shown in the UI and the raw message is never logged, so the only record of the failure is the browser flash the user may have dismissed.

---

### CNCS-02 — M — TXN-04 — Nine mutating methods write no activity log

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php` (whole file)

**Evidence:**

```
activityLog=0
beginTransaction=3
```

`store`, `update`, `post` open a manual transaction but never call the helper; `approve`, `cancel`, `toggleStatus`, `destroy`, `restore`, `forceDelete` have no transaction at all.

**Reproduce:** approve a concession, then query `glb_activity_logs` (tenant) for `subject_type = Modules\Accounting\Models\Concession`. No row exists.

**Consequence:** there is no audit trail of who approved, posted or cancelled a waiver — the one control an auditor asks for on a concessions register — and a failed multi-table write in `post()` is not rolled back together with its log (because there is no log).

---

### CNCS-03 — B — AUTH-01 — The permission names the controller gates on do not exist (DECISION)

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:32, 39, 87, 96, 122, 157, 176, 262, 284, 293, 307, 316, 326` against `config/permissionslist.php`

**Evidence:**

```
Select-String -Path config\permissionslist.php -Pattern "accounting\.concession" -Quiet
NOT FOUND

php artisan tinker   (tenant initialized)
concession.viewAny=false
concession.approve=false
concession perm rows=0
accounting perm rows=312
account-group.viewAny=true
```

The Accounting permission block (`config/permissionslist.php:600-644`) lists 45 resources and `accounting.concession` is not one of them. `AccountingPermissionSeeder.php` is a declared no-op that points at this file as the single producer.

**Reproduce:** log in as user 99 (School Admin, `is_super_admin = 0`), open `accounting/concession/trash/view`. Spatie's `checkPermissionTo` catches `PermissionDoesNotExist` and returns `false`, so `Gate::authorize` throws `AuthorizationException` → 403.

**Consequence:** the entire feature is dark for every non-super-admin role. This is also why the runtime defects below have never been seen: nobody but a super admin can reach them.

**DECISION:** add one key to `config/permissionslist.php`, after line 644:

```php
'accounting.concession' => array_merge($crud, ['approve', 'post', 'cancel']),
```

This mints `tenant.accounting.concession.{create,view,viewAny,update,delete,restore,forceDelete,approve,post,cancel}`. Note that adding permissions is not additive with the rest of the plan: once a role is granted them, `post()` becomes reachable for Account Staff and CNCS-18 starts firing. ⚠ SHARED: the file is global; adding a key also adds it to the role-permission screen.

---

### CNCS-04 — B — AUTH-01 — `status` is writable through `update` (and `store`), bypassing approve/post

**Files:** `Modules\Accounting\app\Http\Requests\ConcessionRequest.php:47`, `Modules\Accounting\app\Models\Concession.php:42`, `Modules\Accounting\app\Http\Controllers\ConcessionController.php:64-65`, `128`, `144`, `Modules\Accounting\resources\views\concession\edit.blade.php:231-236`

**Evidence:**

```
L47: 'status' => ['nullable', Rule::in(Concession::statuses())],      (request)
L42: 'status',                                                        (model fillable)
L128: $validated = $request->validated();                             (update)
L144: $concession->update($validated);                                (update)
```

The edit form offers the full lifecycle:

```blade
<option value="Draft" {{ old('status', $concession->status) === 'Draft' ? 'selected' : '' }}>Draft</option>
<option value="Approved" {{ old('status', $concession->status) === 'Approved' ? 'selected' : '' }}>Approved</option>
<option value="Posted" {{ old('status', $concession->status) === 'Posted' ? 'selected' : '' }}>Posted</option>
<option value="Cancelled" {{ old('status', $concession->status) === 'Cancelled' ? 'selected' : '' }}>Cancelled</option>
```

**Reproduce:** as a user holding only `tenant.accounting.concession.update`, open `/accounting/concession/{id}/edit` for the live Draft row, change Status to `Posted`, submit. The status guard at line 124 checks the **old** value (`Draft`), so the write proceeds and the row becomes `Posted` with `voucher_id = NULL`. `approve` and `post` were never called. A crafted POST to `store` with `status=Posted` does the same on create.

**Consequence:** the approve and post gates are decorative — the update permission is strictly more powerful than both, and a Posted concession can exist without authorisation and without its credit-note voucher.

---

### CNCS-05 — M — AUTH-05 — `post()` accepts a Draft, so approval can be skipped (DECISION)

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:178`

**Evidence:**

```php
if (!in_array($concession->status, ['Draft', 'Approved'], true)) {
```

**Reproduce:** as a user with `...post` but not `...approve`, post a Draft concession from the list's action menu. It succeeds; `post()` even self-authorises at lines 243-246 (`if (!$concession->authorised_by) { ... }`).

**Consequence:** the Draft → Approved step is optional, and the poster becomes the authoriser. Two-person control (BR-CONC-03) is not enforced. **DECISION:** require `Approved` (recommended), or drop the approve gate as a formality. This changes super-admin behaviour, so it is not applied silently.

---

### CNCS-06 — H — VAL-04 / TXN-06 — Number generator ignores soft-deleted rows and collides with the unique index

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:57-61`

**Evidence:**

```php
$count = Concession::whereYear('concession_date', $year)->count() + 1;
$validated['concession_no'] = sprintf('CON-%s-%04d', $year, $count);
```

The `SoftDeletes` trait adds `deleted_at is null` to that query:

```
select * from `acc_concessions` where year(`concession_date`) = ? and `acc_concessions`.`deleted_at` is null
withTrashed_sql=select * from `acc_concessions` where year(`concession_date`) = ?
```

The table has `$table->unique('concession_no', 'uq_acc_conc_no')` (migration line 54).

**Reproduce:** create two concessions in 2026 (`0001`, `0002`), soft-delete `0001`, create a third with a blank number. The count of visible rows is 2 → `CON-2026-0003`; soft-delete `0002` as well and the next one is again `CON-2026-0003` → duplicate key. Also, two concurrent creates both read the same count.

**Consequence:** after the first trash-and-recreate cycle the create form fails with a SQL integrity error rendered as a flash message (CNCS-01).

---

### CNCS-07 — H — VAL-03 — Unticking "Active Record" on the edit form cannot deactivate a concession

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:140`, `Modules\Accounting\resources\views\concession\edit.blade.php:247`

**Evidence:**

```
L140: $validated['is_active']  = $request->boolean('is_active', true);
```

An unchecked HTML checkbox submits nothing. `boolean('is_active', true)` returns the **default** `true` when the key is absent.

**Reproduce:** edit any active concession, untick "Active Record", save. The row stays `is_active = 1`. Only `toggleStatus` (line 286) can deactivate it.

**Consequence:** the edit form silently lies, and the only working deactivate path is a separate POST endpoint that the list exposes.

---

### CNCS-08 — L — VAL-02 — `cancel()` validates inline instead of using the FormRequest

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:264-266`

**Evidence:**

```
L264: $request->validate([
```

**Reproduce:** `Select-String` shows the only inline validation in the controller; every other write path uses `ConcessionRequest`.

**Consequence:** validation rules and messages live in two places, and `cancelled_reason` is not covered by the request's message set.

---

### CNCS-09 — B — RTE-02 — `GET /accounting/concession/create` is routable but the method does not exist

**Files:** `Modules\Accounting\routes\web.php:507`, controller whole file

**Evidence:**

```
accounting.concession.create | GET | accounting/concession/create
create_exists=no
```

**Reproduce:** `php artisan route:list` shows the route; `method_exists(ConcessionController::class, 'create')` is `false`. Visiting the URL with any authenticated user raises `BadMethodCallException: Method ...::create does not exist` → 500 (after the gate at the resource level is not even reached, because the router invokes the controller first).

**Consequence:** a 500 on a URL the framework advertises; the screen's real create UI is a modal in the partial, so the route has no legitimate consumer.

---

### CNCS-10 — H — RTE-01 — Restore is a GET that mutates state (DECISION)

**Files:** `Modules\Accounting\routes\web.php:501`, `Modules\Accounting\resources\views\concession\trash.blade.php:42`

**Evidence:**

```
Route::get('/concession/{id}/restore', [ConcessionController::class, 'restore'])->name('concession.restore');
<a href="{{ route('accounting.concession.restore', $item->id) }}" class="btn btn-xs btn-outline-success" title="Restore">
```

**Reproduce:** while signed in, request `accounting/concession/{id}/restore` in a new tab (or let a browser prefetch/crawler follow the link). The concession is restored with no POST and no CSRF token.

**Consequence:** a state-changing operation is reachable by link prefetch, an `<img src>`, or a cross-site navigation; the audit trail (CNCS-02) cannot distinguish it from a user action.

**DECISION:** change the route to `Route::post(...)` and let `x-backend.table.action-trashed` render the form (the component reads the route method and emits `@csrf` automatically). ⚠ SHARED: the route file is shared, and the view is this report's file.

---

### CNCS-11 — M — CTL-02 / CTL-06 — `post()` is an 85-line method mixing three concerns (DECISION)

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:174-258`

**Evidence:** the method spans 85 lines and performs (a) status policy, (b) fallback master-data resolution for the concession ledger and voucher type, (c) voucher creation + posting, and (d) the concession write.

**Reproduce:** count the method body; there is no private method or service call in the controller.

**Consequence:** the fallback logic cannot be unit-tested in isolation and any change to posting touches all four concerns. **DECISION:** extract a `ConcessionPostingService` (or at minimum a private `resolveCreditNoteContext()`), sequenced with CNCS-18.

---

### CNCS-12 — L — CTL-04 — Four public methods omit return types

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:30, 85, 94, 305`

**Evidence:**

```php
public function index(Request $request)
public function show(Concession $concession)
public function edit(Concession $concession)
public function trashed()
```

All four return a `RedirectResponse` or `View`; the rest of the class declares `: RedirectResponse`.

**Consequence:** no runtime effect; static analysis and IDE navigation lose the contract.

---

### CNCS-13 — L — MDL-02 — `decimal:9,4` is parsed as **nine decimal places**

**File:** `Modules\Accounting\app\Models\Concession.php:55`

**Evidence:**

```
cast='25.500000000'
asDecimal("25.5","9,4")='25.500000000'
```

The column is `decimal(9, 4)` (migration line 36), i.e. 4 decimal places. Laravel casts `(int) "9,4"` → `9`.

**Reproduce:** hydrate a concession with `concession_percent = 25.5` and read the attribute; it returns `25.500000000`. The show page happens to re-format it to 2 dp (`show.blade.php:122`), so the defect is invisible there.

**Consequence:** the attribute carries 9 decimals while the database stores 4; every other consumer (JSON, exports, comparisons) sees the inflated precision, and the cast no longer documents the column.

---

### CNCS-14 — M — QRY-15 — The edit page loads all 5,671 active users into a `<select>` (DECISION)

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:104`

**Evidence:**

```php
$users = User::where('is_active', true)->orderBy('name')->get(['id', 'name', 'email']);
```

Live count: `sys_users` = 5,671 rows, all active. The same query is in `AccDashboardController.php:2569` and feeds the create modal.

**Reproduce:** open the edit page and count the `<option>` elements in `#edit_authorised_by`; 5,671 options (three columns each) are rendered on every request.

**Consequence:** ~1 MB of HTML and a slow admin page, on a dropdown where a user picks one name. **DECISION:** the fix must cover both the edit page and the create modal (owned by `AccDashboardController`), so it is a shared decision: a permission-filtered list (users who can approve) or a searchable remote select.

---

### CNCS-15 — H — VIEW-03 — `concession_no` is interpolated into inline JavaScript and an HTML string

**File:** `Modules\Accounting\resources\views\concession\show.blade.php:26`, `47`

**Evidence:**

```
L26: html: 'Are you sure you want to approve concession <strong>{{ $concession->concession_no }}</strong> for <strong>₹{{ number_format((float) $concession->concession_amount, 2) }}</strong>?',
L47: html: 'Posting concession <strong>{{ $concession->concession_no }}</strong> (₹{{ number_format((float) $concession->concession_amount, 2) }}) will commit accounting voucher entries. This action cannot be undone.',
```

`concession_no` is user-editable (`ConcessionRequest` line 26, `max:50`) and is echoed inside a **single-quoted JS string** that is itself inside a double-quoted `onclick` attribute.

**Reproduce:** create or edit a concession with `concession_no` = `X');alert(document.cookie);//`, then open its detail page and click Approve or Post. The confirmation dialog executes the injected code. (The same pattern exists in the out-of-scope partial at `_concessions.blade.php:247`.)

**Consequence:** stored XSS in the accounting back office, triggered by an approver clicking the button the attacker wants clicked — and the attacker only needs `create` or `update`.

---

### CNCS-16 — H — TXN-06 — A Posted concession can be cancelled without reversing its voucher (DECISION)

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:260-280`

**Evidence:**

```php
if ($concession->status === 'Cancelled') {
    return redirect()->back()->with('warning', 'Concession is already cancelled.');
}

$concession->update([
    'status'           => 'Cancelled',
    'cancelled_reason' => $request->input('cancelled_reason'),
    'updated_by'       => auth()->id(),
]);
```

The only legal-status check is "already cancelled". There is no `Posted` branch and no call into `VoucherService` to reverse `voucher_id`.

**Reproduce:** post a Draft concession (a credit-note voucher is created and posted), then cancel it. `acc_concessions.status` becomes `Cancelled`, while the voucher stays posted and `voucher_id` still points at it. `destroy()` then refuses only `Posted`, so a cancelled-then-soft-deleted row can leave a live credit note with no register entry.

**Consequence:** the ledger keeps a posted credit note that the register says was cancelled — a financial inconsistency that no screen corrects. **DECISION:** forbid cancelling a Posted concession (recommended until a reversal exists) or implement the reversal; §9.6 has both.

---

### CNCS-17 — L — STY-02 — Pint fails on all three PHP files

**Files:** controller, request, model

**Evidence:**

```
{"tool":"pint","result":"fail","files":[
 {"path":"Modules\\Accounting\\app\\Http\\Controllers\\ConcessionController.php","fixers":["function_declaration","single_quote","concat_space","method_chaining_indentation","braces_position","not_operator_with_successor_space","single_line_empty_body","blank_line_before_statement","binary_operator_spaces"]},
 {"path":"Modules\\Accounting\\app\\Http\\Requests\\ConcessionRequest.php","fixers":["binary_operator_spaces"]},
 {"path":"Modules\\Accounting\\app\\Models\\Concession.php","fixers":["no_unused_imports","binary_operator_spaces"]}]}
```

**Reproduce:** `.\vendor\bin\pint --test <the three files>` → exit 1.

**Consequence:** `composer lint`/CI style gate fails; the model also carries an unused `use App\Models\BaseModel;` (line 7) because it extends `BaseAccountingModel`.

---

### CNCS-18 — M — CTL-06 — `post()` fallbacks pick the wrong voucher type and any ledger by name

**File:** `Modules\Accounting\app\Http\Controllers\ConcessionController.php:188-212`

**Evidence:**

```php
$concessionLedgerId = Ledger::where('is_active', true)
    ->where(function ($q) {
        $q->where('name', 'like', '%Concession%')
          ->orWhere('name', 'like', '%Scholarship%')
          ->orWhere('name', 'like', '%Fee Discount%');
    })
    ->value('id');
```

```php
$crnType = VoucherType::whereIn('base_type', ['Credit_Note', 'Journal'])->where('is_active', true)->first()
    ?? VoucherType::whereIn('base_type', ['Credit_Note', 'Journal'])->first()
    ?? VoucherType::where(function ($q) {
        $q->whereIn('code', ['CREDIT_NOTE', 'CRN', 'CDN', 'JOURNAL', 'JNL', 'JRN'])
          ->orWhere('code', 'like', 'CRN%')
          ->orWhere('code', 'like', 'CDN%')
          ->orWhere('code', 'like', 'JNL%')
          ->orWhere('code', 'like', 'JRN%');
    })->first()
```

Neither query has an `orderBy`. On the live tenant the ledger `LIKE` matches both id 51 "Fee Concessions and Scholarships" (Expense) and id 46 "Merit Scholarship Endowment" (Equity); the voucher-type query has no preference between `Credit_Note` and `Journal` and no `orderBy`, so `first()` returns `{"id":3,"code":"JRNL","base_type":"Journal"}`.

**Reproduce:** run the two queries as written (tinker) against the tenant and inspect the returned ids.

**Consequence:** with no concession ledger chosen, the credit note may debit an Equity endowment instead of the Expense account, and may be booked as a Journal instead of a Credit Note — non-deterministically, depending on row order. This is currently latent because no non-super-admin can reach `post()`, but CNCS-03 arms it.

## 7. Cross-cutting notes (common or other-module classes - not fixed here)

- **The list and the create modal are not this controller's.** `AccDashboardController::schoolSpecific()` (`AccDashboardController.php:2478-2519`) runs the list query (`paginate(25, ['*'], 'c_page')`) and renders `_concessions.blade.php`. The create modal posts to `accounting.concession.store` and is gated by `tenant.accounting.concession.create` (partial line 306). It offers `authorised_by`, `timing` and `sanction_reference`; it does **not** offer `status=Posted` or `Cancelled`. Any fix to the create form (including CNCS-14's user dropdown and the injection pattern at partial line 247) belongs to that report. No report for `AccDashboardController` exists in `gaurav\Accounting`, so this is flagged as unclaimed.
- **`VoucherService` is the posting engine.** `create(array $data, array $items): Voucher` (line 28) and `post(Voucher, ?int)` (line 205) are called at controller lines 214-238. Its balance rules, period locks and idempotency were not audited here; if it throws, CNCS-01's raw-message handler is the only presentation.
- **`Ledger` / `Voucher` / `VoucherType`** are owned by their own controllers; this report only uses their queries as evidence (CNCS-18).
- **`BaseAccountingModel`** auto-fills `created_by`/`updated_by` on create/update when blank. The controller also sets both explicitly, so the two mechanisms agree; no finding.
- **`User` model** is shared with the teacher portal; the 5,671-row dropdown problem (CNCS-14) is a query choice in this controller, not a defect in the model.
- **`config/permissionslist.php`** is the single permission producer (the module seeder says so explicitly). CNCS-03 is therefore a config decision, not a seeder fix.

## 8. Not covered, and why

- **`_tools\scanfilter.py` / `_tools\selfcheck.py` were not run** — both are missing from the repository, and `scan.php` was explicitly forbidden by the task instructions, so the F1-F13 checks in this report were performed manually and the automated self-check was skipped.
- **No HTTP request was issued and no test was executed.** The protocol is read-only; every runtime claim above is proven by a static query, a tinker expression against the live tenant, `route:list`, `php -l` or Pint, and each has its command and output in §6.
- **Concurrency was not load-tested.** CNCS-06's race is inferred from the read-then-write shape of the generator and the unique index; the duplicate-key outcome is certain, the frequency is not.
- **Browser rendering was not exercised.** CNCS-15 is proven from the escaping context (single-quoted JS inside an HTML attribute) and the editable field, not from a live alert.
- **`AccDashboardController` and `_concessions.blade.php` were not audited** (different owner, no report to link to). Their interaction with this controller is covered only where this controller's routes/gates are involved.
- **`VoucherService` internals, `AccountingContext`, and tenant middleware** were read for signatures only; a full audit of tenancy edge cases (e.g. what happens if the tenant is not initialized) is out of scope.
- **`php -l` passed on the controller, request and model**, so no syntax-level finding is reported.
