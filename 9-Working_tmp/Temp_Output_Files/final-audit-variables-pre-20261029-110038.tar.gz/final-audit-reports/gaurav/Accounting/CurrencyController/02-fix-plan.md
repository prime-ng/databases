# Fix Plan — Accounting / CurrencyController

**From:** `01-report.md` (2026-10-22) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/CurrencyController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | route file — ⚠ SHARED, touched only by CRNC-10 |
| `config/permissionslist.php` | ⚠ SHARED config (no change is proposed here) |
| `resources/views/components/**` (`x-backend.*`, `x-tenantcore.*`) | common components |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_currencies.blade.php` | owned by the AccDashboardController report |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | owned by another report |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | owned by the AccountingStatusMasterController report |
| `Modules/Accounting/app/Services/AccountingContext.php` | owned by the AccountGroupController report |
| `Modules/Accounting/app/Models/ExchangeRate.php` | owned by the ExchangeRateController report |
| `database/migrations/**` | never edit an existing migration; CRNC-20 option (c) would need a new additive migration |

## 1. Blockers reachable today

- [ ] **CRNC-01** · B · ERR-01 · `CurrencyController.php:31-298` — remove every `try/catch` and every manual transaction; use `DB::transaction()`, never `$e->getMessage()`. This one item also resolves **CRNC-02, CRNC-03, CRNC-04, CRNC-05, CRNC-06, CRNC-12, CRNC-13, CRNC-14, CRNC-19**.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CurrencyController.php`
  - **Before — imports (`CurrencyController.php:7-13`):**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Accounting\Http\Requests\CurrencyRequest;
    use Modules\Accounting\Models\Currency;
    ```
  - **After — imports:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\Accounting\Http\Requests\CurrencyRequest;
    use Modules\Accounting\Models\Currency;
    ```
  - **Before — `index()` and `create()` (`CurrencyController.php:17-29`):**
    ```php
        public function index()
        {
            Gate::authorize('tenant.accounting.currency.viewAny');

            return redirect()->route('accounting.menu.configurations', ['tab' => 'currencies']);
        }

        public function create()
        {
            Gate::authorize('tenant.accounting.currency.create');

            return view('accounting::currency.create');
        }
    ```
  - **After — `index()` and `create()`:**
    ```php
        public function index(): RedirectResponse
        {
            Gate::authorize('tenant.accounting.currency.viewAny');

            return redirect()->route('accounting.menu.configurations', ['tab' => 'currencies']);
        }

        public function create(): View
        {
            Gate::authorize('tenant.accounting.currency.create');

            return view('accounting::currency.create');
        }
    ```
  - **Before — `show()` and `edit()` (`CurrencyController.php:68-80`):**
    ```php
        public function show(Currency $currency)
        {
            Gate::authorize('tenant.accounting.currency.view');

            return view('accounting::currency.show', compact('currency'));
        }

        public function edit(Currency $currency)
        {
            Gate::authorize('tenant.accounting.currency.update');

            return view('accounting::currency.edit', compact('currency'));
        }
    ```
  - **After — `show()` and `edit()`:**
    ```php
        public function show(Currency $currency): View
        {
            Gate::authorize('tenant.accounting.currency.view');

            return view('accounting::currency.show', compact('currency'));
        }

        public function edit(Currency $currency): View
        {
            Gate::authorize('tenant.accounting.currency.update');

            return view('accounting::currency.edit', compact('currency'));
        }
    ```
  - **Before — `store()` (`CurrencyController.php:31-66`):**
    ```php
        public function store(CurrencyRequest $request)
        {
            Gate::authorize('tenant.accounting.currency.create');

            $validated = $request->validated();

            DB::beginTransaction();
            try {
                if (!empty($validated['is_base'])) {
                    Currency::query()->update(['is_base' => false]);
                }

                $currency = Currency::create($validated);

                activityLog($currency, 'Created', [
                    'message'      => 'Currency created: ' . $currency->name,
                    'code'         => $currency->code,
                    'name'         => $currency->name,
                    'is_base'      => (bool) $currency->is_base,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.configurations', ['tab' => 'currencies'])
                    ->with('success', 'Currency created successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to create Currency', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString(),
                ]);

                return back()->withInput()->with('error', 'Failed to create Currency: ' . $e->getMessage());
            }
        }
    ```
  - **After — `store()`:**
    ```php
        public function store(CurrencyRequest $request): RedirectResponse
        {
            Gate::authorize('tenant.accounting.currency.create');

            $validated = $request->validated();

            if (! empty($validated['is_base']) && empty($validated['is_active'])) {
                return back()->withInput()->with('error', 'The base currency must remain active.');
            }

            DB::transaction(function () use ($validated): void {
                if (! empty($validated['is_base'])) {
                    $this->unsetOtherBaseCurrencies();
                }

                $currency = Currency::create($validated);

                activityLog($currency, 'Created', [
                    'message'      => 'Currency created: ' . $currency->name,
                    'code'         => $currency->code,
                    'name'         => $currency->name,
                    'is_base'      => (bool) $currency->is_base,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.configurations', ['tab' => 'currencies'])
                ->with('success', 'Currency created successfully.');
        }
    ```
  - **Before — `update()` (`CurrencyController.php:82-121`):**
    ```php
        public function update(CurrencyRequest $request, Currency $currency)
        {
            Gate::authorize('tenant.accounting.currency.update');

            $validated = $request->validated();

            if ($currency->isBase() && empty($validated['is_base'])) {
                return back()->withInput()->with('error', 'Cannot unset base currency status. Designate another currency as base instead.');
            }

            DB::beginTransaction();
            try {
                if (!empty($validated['is_base'])) {
                    Currency::where('id', '!=', $currency->id)->update(['is_base' => false]);
                }

                $currency->update($validated);

                activityLog($currency, 'Updated', [
                    'message'      => 'Currency updated: ' . $currency->name,
                    'code'         => $currency->code,
                    'name'         => $currency->name,
                    'is_base'      => (bool) $currency->is_base,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.configurations', ['tab' => 'currencies'])
                    ->with('success', 'Currency updated successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to update Currency', [
                    'id'    => $currency->id,
                    'error' => $e->getMessage(),
                ]);

                return back()->withInput()->with('error', 'Failed to update Currency: ' . $e->getMessage());
            }
        }
    ```
  - **After — `update()` (adds the CRNC-19 guard):**
    ```php
        public function update(CurrencyRequest $request, Currency $currency): RedirectResponse
        {
            Gate::authorize('tenant.accounting.currency.update');

            $validated = $request->validated();

            if ($currency->isBase() && empty($validated['is_base'])) {
                return back()->withInput()->with('error', 'Cannot unset base currency status. Designate another currency as base instead.');
            }

            if ($currency->isBase() && empty($validated['is_active'])) {
                return back()->withInput()->with('error', 'The base currency cannot be deactivated. Designate another currency as base first.');
            }

            DB::transaction(function () use ($currency, $validated): void {
                if (! empty($validated['is_base'])) {
                    $this->unsetOtherBaseCurrencies((int) $currency->id);
                }

                $currency->update($validated);

                activityLog($currency, 'Updated', [
                    'message'      => 'Currency updated: ' . $currency->name,
                    'code'         => $currency->code,
                    'name'         => $currency->name,
                    'is_base'      => (bool) $currency->is_base,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.configurations', ['tab' => 'currencies'])
                ->with('success', 'Currency updated successfully.');
        }
    ```
  - **Before — `makeBase()` (`CurrencyController.php:123-163`):**
    ```php
        public function makeBase(Currency $currency)
        {
            Gate::authorize('tenant.accounting.currency.update');

            DB::beginTransaction();
            try {
                Currency::where('id', '!=', $currency->id)->update(['is_base' => false]);
                $currency->update([
                    'is_base'   => true,
                    'is_active' => true,
                ]);

                activityLog($currency, 'MadeBase', [
                    'message'      => 'Currency designated as base currency: ' . $currency->code,
                    'code'         => $currency->code,
                    'name'         => $currency->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                if (request()->wantsJson() || request()->ajax()) {
                    return response()->json([
                        'success' => true,
                        'message' => "Currency {$currency->code} is now the primary reporting base currency.",
                    ]);
                }

                return redirect()->route('accounting.menu.configurations', ['tab' => 'currencies'])
                    ->with('success', "Currency {$currency->code} is now the primary reporting base currency.");
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to set base currency', ['id' => $currency->id, 'error' => $e->getMessage()]);

                if (request()->wantsJson() || request()->ajax()) {
                    return response()->json(['success' => false, 'message' => 'Failed to set base currency: ' . $e->getMessage()], 500);
                }

                return back()->with('error', 'Failed to set base currency: ' . $e->getMessage());
            }
        }
    ```
  - **After — `makeBase()` (injects `Request`, CRNC-13):**
    ```php
        public function makeBase(Request $request, Currency $currency): JsonResponse|RedirectResponse
        {
            Gate::authorize('tenant.accounting.currency.update');

            DB::transaction(function () use ($currency): void {
                $this->unsetOtherBaseCurrencies((int) $currency->id);

                $currency->update([
                    'is_base'   => true,
                    'is_active' => true,
                ]);

                activityLog($currency, 'MadeBase', [
                    'message'      => 'Currency designated as base currency: ' . $currency->code,
                    'code'         => $currency->code,
                    'name'         => $currency->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            if ($request->wantsJson() || $request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => "Currency {$currency->code} is now the primary reporting base currency.",
                ]);
            }

            return redirect()->route('accounting.menu.configurations', ['tab' => 'currencies'])
                ->with('success', "Currency {$currency->code} is now the primary reporting base currency.");
        }
    ```
  - **Before — `destroy()` (`CurrencyController.php:165-197`):**
    ```php
        public function destroy(Currency $currency)
        {
            Gate::authorize('tenant.accounting.currency.delete');

            if ($currency->isBase()) {
                return back()->with('error', 'The base currency cannot be deleted because all accounts and reports depend on it.');
            }

            DB::beginTransaction();
            try {
                $name = $currency->name;
                $code = $currency->code;
                $currency->is_active = false;
                $currency->save();
                $currency->delete();

                activityLog($currency, 'Trashed', [
                    'message'      => 'Currency moved to trash: ' . $name,
                    'code'         => $code,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.configurations', ['tab' => 'currencies'])
                    ->with('success', 'Currency moved to trash.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to trash Currency', ['id' => $currency->id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to trash Currency: ' . $e->getMessage());
            }
        }
    ```
  - **After — `destroy()` (adds the CRNC-06 lock):**
    ```php
        public function destroy(Currency $currency): RedirectResponse
        {
            Gate::authorize('tenant.accounting.currency.delete');

            $trashed = DB::transaction(function () use ($currency): bool {
                $locked = Currency::whereKey($currency->id)->lockForUpdate()->firstOrFail();

                if ($locked->isBase()) {
                    return false;
                }

                $name = $locked->name;
                $code = $locked->code;
                $locked->is_active = false;
                $locked->save();
                $locked->delete();

                activityLog($locked, 'Trashed', [
                    'message'      => 'Currency moved to trash: ' . $name,
                    'code'         => $code,
                    'performed_by' => auth()->id(),
                ]);

                return true;
            });

            if (! $trashed) {
                return back()->with('error', 'The base currency cannot be deleted because all accounts and reports depend on it.');
            }

            return redirect()->route('accounting.menu.configurations', ['tab' => 'currencies'])
                ->with('success', 'Currency moved to trash.');
        }
    ```
  - **Before — `toggleStatus()` (`CurrencyController.php:199-232`):**
    ```php
        public function toggleStatus(Request $request, Currency $currency)
        {
            Gate::authorize('tenant.accounting.currency.update');

            $request->validate(['is_active' => 'required|boolean']);

            if ($currency->isBase() && !$request->boolean('is_active')) {
                return response()->json([
                    'success' => false,
                    'message' => 'The base currency cannot be deactivated.',
                ], 422);
            }

            DB::beginTransaction();
            try {
                $currency->is_active = $request->input('is_active');
                $currency->save();

                activityLog($currency, 'Toggled', [
                    'message'      => 'Currency status toggled: ' . $currency->name,
                    'code'         => $currency->code,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return response()->json(['success' => true, 'is_active' => $currency->is_active, 'message' => 'Status updated.']);
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to toggle Currency status', ['id' => $currency->id, 'error' => $e->getMessage()]);

                return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
            }
        }
    ```
  - **After — `toggleStatus()`:**
    ```php
        public function toggleStatus(Request $request, Currency $currency): JsonResponse
        {
            Gate::authorize('tenant.accounting.currency.update');

            $request->validate(['is_active' => 'required|boolean']);

            if ($currency->isBase() && ! $request->boolean('is_active')) {
                return response()->json([
                    'success' => false,
                    'message' => 'The base currency cannot be deactivated.',
                ], 422);
            }

            DB::transaction(function () use ($request, $currency): void {
                $currency->is_active = $request->boolean('is_active');
                $currency->save();

                activityLog($currency, 'Toggled', [
                    'message'      => 'Currency status toggled: ' . $currency->name,
                    'code'         => $currency->code,
                    'performed_by' => auth()->id(),
                ]);
            });

            return response()->json(['success' => true, 'is_active' => $currency->is_active, 'message' => 'Status updated.']);
        }
    ```
  - **Before — `restore()` (`CurrencyController.php:243-268`):**
    ```php
        public function restore($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.currency.restore');

            DB::beginTransaction();
            try {
                $model = Currency::onlyTrashed()->findOrFail($id);
                $model->restore();
                $model->update(['is_active' => true]);

                activityLog($model, 'Restored', [
                    'message'      => 'Currency restored: ' . $model->name,
                    'name'         => $model->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.currency.trashed')->with('success', 'Currency restored successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to restore Currency', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to restore Currency: ' . $e->getMessage());
            }
        }
    ```
  - **After — `restore()`:**
    ```php
        public function restore($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.currency.restore');

            $model = Currency::onlyTrashed()->findOrFail($id);

            DB::transaction(function () use ($model): void {
                $model->restore();
                $model->update(['is_active' => true]);

                activityLog($model, 'Restored', [
                    'message'      => 'Currency restored: ' . $model->name,
                    'name'         => $model->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.currency.trashed')->with('success', 'Currency restored successfully.');
        }
    ```
  - **Before — `forceDelete()` (`CurrencyController.php:270-298`):**
    ```php
        public function forceDelete($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.currency.forceDelete');

            DB::beginTransaction();
            try {
                $model = Currency::withTrashed()->findOrFail($id);
                if ($model->isBase()) {
                    return back()->with('error', 'The base currency cannot be deleted.');
                }
                $name = $model->name;
                $model->forceDelete();

                activityLog($model, 'Deleted', [
                    'message'      => 'Currency permanently deleted: ' . $name,
                    'name'         => $name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.currency.trashed')->with('success', 'Currency permanently deleted.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to force delete Currency', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to delete Currency: ' . $e->getMessage());
            }
        }
    ```
  - **After — `forceDelete()` (guard moved above the transaction; the reference guard is CRNC-20):**
    ```php
        public function forceDelete($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.currency.forceDelete');

            $model = Currency::withTrashed()->findOrFail($id);

            if ($model->isBase()) {
                return back()->with('error', 'The base currency cannot be deleted.');
            }

            $name = $model->name;

            DB::transaction(function () use ($model, $name): void {
                $model->forceDelete();

                activityLog($model, 'Deleted', [
                    'message'      => 'Currency permanently deleted: ' . $name,
                    'name'         => $name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.currency.trashed')->with('success', 'Currency permanently deleted.');
        }
    ```
  - **After — add this private helper after `forceDelete()`, before the class closing brace (resolves CRNC-14):**
    ```php

        private function unsetOtherBaseCurrencies(?int $exceptId = null): void
        {
            $query = Currency::query();

            if ($exceptId !== null) {
                $query->where('id', '!=', $exceptId);
            }

            $query->update(['is_base' => false]);
        }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\CurrencyController.php" -Pattern "getMessage|beginTransaction|DB::commit|DB::rollBack|Log::error"` and `php -l "Modules\Accounting\app\Http\Controllers\CurrencyController.php"`
  - **Expect:** no `getMessage` / `beginTransaction` / `DB::commit` / `DB::rollBack` / `Log::error` hits; `No syntax errors detected`.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None. CRNC-20 (the permanent-delete reference policy) is a decision, not a prerequisite for CRNC-01.

## 3. Errors & transactions (F1/F2)

All F1/F2 findings are resolved by **CRNC-01** in §1.

## 4. Authorization (F3)

CRNC-07 is accepted as a harmless duplicate (see §10). CRNC-08 is a decision (§9).

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **CRNC-10** · H · RTE-01 · `Modules/Accounting/routes/web.php:374` — perform the restore over POST, not GET. ⚠ SHARED.
  - **Touches:** `Modules/Accounting/routes/web.php`
  - **Before** (`routes/web.php:374`):
    ```php
    Route::get('/currency/{id}/restore', [CurrencyController::class, 'restore'])->name('currency.restore');
    ```
  - **After:**
    ```php
    Route::post('/currency/{id}/restore', [CurrencyController::class, 'restore'])->name('currency.restore');
    ```
  - **Verify:** `php artisan route:list --json 2>$null | php "/tmp/opencode\routesprobe.php" "Modules\Accounting\Http\Controllers\CurrencyController"` (after `php artisan route:clear`)
  - **Expect:** `POST accounting/currency/{id}/restore accounting.currency.restore`.
  - **Effort:** S

- [ ] **CRNC-16** · L · CTL-10 · `CurrencyController.php` — remove the dead view `currency/index.blade.php` and the unused `Currency::selectable()`.
  - **Touches:** `Modules/Accounting/resources/views/currency/index.blade.php` (delete), `Modules/Accounting/app/Models/Currency.php`
  - **Before** (`Currency.php:69-73`):
    ```php
        /** Active currencies ordered by code — for dropdowns. */
        public static function selectable()
        {
            return static::active()->orderBy('code')->get();
        }
    ```
  - **After:** delete the `selectable()` method and its docblock; delete the whole `resources/views/currency/index.blade.php` file.
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Models\Currency.php" -Pattern "selectable"; Test-Path "Modules\Accounting\resources\views\currency\index.blade.php"`
  - **Expect:** no `selectable` hit; `False` from `Test-Path`.
  - **Effort:** S
  - **⚠ Confirm first** that no external module calls `Currency::selectable()` (`grep -rn "Currency::selectable" .` outside `vendor/`).

## 6. Queries & performance (F9)

- [ ] **CRNC-17** · M · QRY-02 · `CurrencyController.php:238` — paginate the trash list at the standard 10 with a distinct page name.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CurrencyController.php`
  - **Before** (`CurrencyController.php:238`):
    ```php
            $currencies = Currency::onlyTrashed()->orderBy('code')->paginate(15);
    ```
  - **After:**
    ```php
            $currencies = Currency::onlyTrashed()->orderBy('code')->paginate(10, ['*'], 'currency_page');
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\CurrencyController.php" -Pattern "paginate"`
  - **Expect:** `paginate(10, ['*'], 'currency_page')`.
  - **Effort:** S

## 7. Views (F10)

- [ ] **CRNC-09** · L · VAL-05 · `create.blade.php:77-89` — remove the dead `base_flag` form control (a generated column that is never validated or stored).
  - **Touches:** `Modules/Accounting/resources/views/currency/create.blade.php`
  - **Before** (`create.blade.php:77-89`):
    ```blade
                                        </div>

                                        <div class="col-md-6 col-lg-4">
                                            <x-backend.form.input-text
                                                type="text"
                                                name="base_flag"
                                                id="base_flag"
                                                label="Base Flag"
                                                placeholder="Enter base flag"
                                                required="false"
                                                value="{{ old('base_flag') }}"
                                            />
                                        </div>
    ```
  - **After:**
    ```blade
                                        </div>
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\resources\views\currency\create.blade.php" -Pattern "base_flag"`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **CRNC-18** · L · STY-02 · run Pint on the three in-scope PHP files.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CurrencyController.php`, `Modules/Accounting/app/Models/Currency.php`, `Modules/Accounting/app/Http/Requests/CurrencyRequest.php`
  - **Before:** `pint --test` reports `fail` for all three (report CRNC-18).
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\CurrencyController.php Modules\Accounting\app\Models\Currency.php Modules\Accounting\app\Http\Requests\CurrencyRequest.php --format agent` (never `--dirty`).
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\CurrencyController.php Modules\Accounting\app\Models\Currency.php Modules\Accounting\app\Http\Requests\CurrencyRequest.php --format agent`
  - **Expect:** `{"tool":"pint","result":"passed"}`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **CRNC-08** · M · DECISION · AUTH-06 — replace the twelve repeated `tenant.accounting.currency.*` literals with one source of truth (constants or a Policy)?
  - **Why it is a decision:** cross-file refactor (controller + FormRequest + four blades); a new class or constants file.
  - (a) ⭐ Add a `CurrencyPermissions` constants class, reference it from controller/request/views (one mechanical pass).
  - (b) Add a `CurrencyPolicy` and use `$this->authorize()`/`@can` against it.
  - (c) Leave the literals as is and record as accepted.
  - ➜ Choice: ____

- [ ] **CRNC-15** · L · DECISION · CTL-05 — two "create currency" UIs exist (the modal in the Currencies tab and the routed `currency/create.blade.php`).
  - **Why it is a decision:** removing a routed page changes reachable URLs (§9.3).
  - (a) ⭐ Delete the unused `create()` page path (keep the modal) — remove `currency/create.blade.php` and stop routing `create()`.
  - (b) Keep both and link the full page from the modal.
  - (c) Leave as is.
  - ➜ Choice: ____

- [ ] **CRNC-20** · H · DECISION · CTL-06 — what should permanent delete do when the currency is still referenced by a ledger, voucher, bill reference, opening balance or exchange rate?
  - **Why it is a decision:** the fix is a behaviour change (and option c needs an additive migration that this workflow never runs).
  - (a) ⭐ Pre-check the five RESTRICT tables inside `forceDelete()` and refuse with a friendly message naming the dependency.
  - (b) Let the FK reject the delete and show a generic error page (no code change beyond CRNC-01).
  - (c) Change the five FKs to `CASCADE`/`SET NULL` in a new additive migration, then allow the permanent delete.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CRNC-02 | resolved by CRNC-01 (the `restore()`/`forceDelete()` rewrite moves `findOrFail()` above the transaction) |
| CRNC-03 | resolved by CRNC-01 (all `Log::error()` calls are removed with the catches) |
| CRNC-04 | resolved by CRNC-01 (all seven `try/catch` blocks are removed) |
| CRNC-05 | resolved by CRNC-01 (manual transactions replaced by `DB::transaction()`; the `forceDelete()` early return moves above the transaction) |
| CRNC-06 | resolved by CRNC-01 (the `destroy()` rewrite re-fetches with `lockForUpdate()` inside the transaction) |
| CRNC-07 | accepted — the duplicate FormRequest + Gate check is harmless; keeping both is a deliberate defence-in-depth choice and touching it during the rewrite adds risk |
| CRNC-11 | deferred — route-model binding for `restore()`/`forceDelete()` needs `->withTrashed()` on the shared route, which is a `⚠ SHARED` route change; not worth mixing with CRNC-10 |
| CRNC-12 | resolved by CRNC-01 (the rewrite adds `RedirectResponse`/`View`/`JsonResponse` return types) |
| CRNC-13 | resolved by CRNC-01 (the `makeBase()` rewrite injects `Request`) |
| CRNC-14 | resolved by CRNC-01 (the `unsetOtherBaseCurrencies()` helper removes the three copies) |
| CRNC-19 | resolved by CRNC-01 (the `store()`/`update()` rewrites add the base-must-be-active guards) |
