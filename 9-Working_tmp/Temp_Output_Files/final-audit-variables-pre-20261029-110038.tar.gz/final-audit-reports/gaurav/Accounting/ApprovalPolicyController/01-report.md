# Final Audit — Accounting / ApprovalPolicyController

**Audited:** 2026-10-22 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php` (254 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/configurations?tab=approval-policies` (list + create modal, served by `AccDashboardController`); `…/accounting/approval-policy/create`; `…/accounting/approval-policy/{id}`; `…/accounting/approval-policy/{id}/edit`; `…/accounting/approval-policy/trash/view` |
| Menu path | Accounting → Configurations → Approval Policies tab |
| Who uses it | 5 roles hold `tenant.accounting.approval-policy.viewAny` on the test tenant: Super Admin, School Admin, Management, Account Staff, Account Manager |
| What a user does here | A finance administrator defines approval rules for vouchers: which voucher type and campus they cover, the amount band, how many approval levels are required (1–3), which role approves each level, whether self-approval is forbidden, whether a senior user may override, and after how many hours the request escalates. Policies can be switched active/inactive, soft-deleted to trash, restored, or permanently deleted. |
| Tables written | `acc_approval_policies` (insert/update/soft-delete/restore/force-delete); `sys_activity_logs` (audit row on every mutation); `acc_voucher_approvals.policy_id` is set to NULL by the FK when a policy is force-deleted |
| Tables read | `acc_approval_policies`, `acc_voucher_types`, `acc_campuses`, `acc_account_groups`, `sys_roles`, `sys_users` (creator) |
| Live data | `acc_approval_policies`: 2 live rows, 0 trashed, on the test tenant (`00000000-0000-4000-8000-000000000001`) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No — this controller is not production-ready. The single worst finding is **APPV-01**: every create/update/delete/toggle/restore/force-delete path catches `\Throwable` and returns `$e->getMessage()` to the browser, so SQL errors, table names and column names leak to the user on a normal failure. Two more high-impact issues sit behind it: the restore route changes state over **GET** (APPV-08), and the policy detail page can never display an approver role because the model has no `approver1Role`/`approver2Role`/`approver3Role` relationships (APPV-14). The plan is a medium-sized controller rewrite (roughly 3–5 hours): one D1 transaction conversion, one route verb change, one model relation addition, and a handful of small cleanups.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 3 | 7 | 6 | 1 | 17 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | APPV-01, APPV-02, APPV-03, APPV-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | APPV-05 | F9 Queries/Perf | APPV-15 |
| F3 Authorization | APPV-06, APPV-07 | F10 Views | APPV-16 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | APPV-08, APPV-09 | F12 Style | APPV-17 |
| F6 Controller shape | APPV-10, APPV-11, APPV-12, APPV-13 | F13 Deep read | table below (no new IDs) |
| F7 Models | APPV-14 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php` | controller | 254 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/ApprovalPolicy.php` | model | 80 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/ApprovalPolicyRequest.php` | form request | 97 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/app/Policies/ApprovalPolicyPolicy.php` | policy | 46 | this report (unclaimed shared class — see RETURN) | ✅ |
| 5 | `Modules/Accounting/resources/views/approval-policy/create.blade.php` | blade | 257 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/approval-policy/edit.blade.php` | blade | 266 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/approval-policy/show.blade.php` | blade | 145 | this report | ✅ |
| 8 | `Modules/Accounting/resources/views/approval-policy/trash.blade.php` | blade | 72 | this report | ✅ |
| 9 | `Modules/Accounting/resources/views/approval-policy/index.blade.php` | blade (unused) | 90 | this report | ✅ |
| 10 | `Modules/Accounting/routes/web.php` (approval-policy rows only) | route file (shared) | — | shared file — route rows checked, not owned | ✅ |
| 11 | `Modules/Accounting/app/Models/VoucherType.php` | model | 185 | ↗ [gaurav/Accounting/VoucherTypeController](../VoucherTypeController/01-report.md) | ↗ linked |
| 12 | `Modules/Accounting/app/Models/Campus.php` | model | 83 | ↗ [gaurav/Accounting/CampusController](../CampusController/01-report.md) | ↗ linked |
| 13 | `Modules/Accounting/app/Models/AccountGroup.php` | model | 179 | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 14 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | base model | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 15 | `Modules/SchoolSetup/app/Models/Role.php` | other-module model | 53 | common (SchoolSetup) — not audited here | ↗ linked |
| 16 | `app/Helpers/activityLog.php` | helper (common) | 51 | common — not audited here | ↗ linked |
| 17 | `database/migrations/tenant/2026_09_16_100030_create_acc_approval_policies_table.php` | migration (schema reference) | 64 | read-only schema proof | ✅ |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/approval-policy                              accounting.approval-policy.index    Modules\Accounting\Http\Controllers\ApprovalPolicyController@index       [web,tenancy,EnsureTenantIsActive,EnsureTenantHasModule:Accounting,Authenticate,EnsureEmailIsVerified]
POST      accounting/approval-policy                              accounting.approval-policy.store    Modules\Accounting\Http\Controllers\ApprovalPolicyController@store       [web,tenancy,EnsureTenantIsActive,EnsureTenantHasModule:Accounting,Authenticate,EnsureEmailIsVerified]
GET|HEAD  accounting/approval-policy/create                       accounting.approval-policy.create   Modules\Accounting\Http\Controllers\ApprovalPolicyController@create      [web,tenancy,EnsureTenantIsActive,EnsureTenantHasModule:Accounting,Authenticate,EnsureEmailIsVerified]
GET|HEAD  accounting/approval-policy/trash/view                   accounting.approval-policy.trashed  Modules\Accounting\Http\Controllers\ApprovalPolicyController@trashed     [web,tenancy,EnsureTenantIsActive,EnsureTenantHasModule:Accounting,Authenticate,EnsureEmailIsVerified]
GET|HEAD  accounting/approval-policy/{approval_policy}            accounting.approval-policy.show     Modules\Accounting\Http\Controllers\ApprovalPolicyController@show        [web,tenancy,EnsureTenantIsActive,EnsureTenantHasModule:Accounting,Authenticate,EnsureEmailIsVerified]
PUT|PATCH accounting/approval-policy/{approval_policy}            accounting.approval-policy.update   Modules\Accounting\Http\Controllers\ApprovalPolicyController@update      [web,tenancy,EnsureTenantIsActive,EnsureTenantHasModule:Accounting,Authenticate,EnsureEmailIsVerified]
DELETE    accounting/approval-policy/{approval_policy}            accounting.approval-policy.destroy  Modules\Accounting\Http\Controllers\ApprovalPolicyController@destroy     [web,tenancy,EnsureTenantIsActive,EnsureTenantHasModule:Accounting,Authenticate,EnsureEmailIsVerified]
GET|HEAD  accounting/approval-policy/{approval_policy}/edit       accounting.approval-policy.edit     Modules\Accounting\Http\Controllers\ApprovalPolicyController@edit        [web,tenancy,EnsureTenantIsActive,EnsureTenantHasModule:Accounting,Authenticate,EnsureEmailIsVerified]
POST      accounting/approval-policy/{approval_policy}/toggle-status accounting.approval-policy.toggleStatus Modules\Accounting\Http\Controllers\ApprovalPolicyController@toggleStatus [web,tenancy,EnsureTenantIsActive,EnsureTenantHasModule:Accounting,Authenticate,EnsureEmailIsVerified]
DELETE    accounting/approval-policy/{id}/force-delete            accounting.approval-policy.forceDelete Modules\Accounting\Http\Controllers\ApprovalPolicyController@forceDelete [web,tenancy,EnsureTenantIsActive,EnsureTenantHasModule:Accounting,Authenticate,EnsureEmailIsVerified]
GET|HEAD  accounting/approval-policy/{id}/restore                 accounting.approval-policy.restore  Modules\Accounting\Http\Controllers\ApprovalPolicyController@restore    [web,tenancy,EnsureTenantIsActive,EnsureTenantHasModule:Accounting,Authenticate,EnsureEmailIsVerified]
```

Unrouted public methods: none — all 11 public methods are routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 22 | GET /accounting/approval-policy | `tenant.accounting.approval-policy.viewAny` | none | none | none | — |
| `create` | 29 | GET /accounting/approval-policy/create | `tenant.accounting.approval-policy.create` | none | none | none | APPV-10 |
| `store` | 41 | POST /accounting/approval-policy | `tenant.accounting.approval-policy.create` (also FormRequest) | controller, manual `beginTransaction`/`commit` | 'Created' | `acc_approval_policies`, `sys_activity_logs` | APPV-01, APPV-02, APPV-04, APPV-05, APPV-06, APPV-10, APPV-12 |
| `show` | 76 | GET /accounting/approval-policy/{approval_policy} | `tenant.accounting.approval-policy.view` | none | none | none | APPV-14 |
| `edit` | 86 | GET /accounting/approval-policy/{approval_policy}/edit | `tenant.accounting.approval-policy.update` | none | none | none | APPV-10 |
| `update` | 99 | PUT/PATCH /accounting/approval-policy/{approval_policy} | `tenant.accounting.approval-policy.update` (also FormRequest) | controller, manual `beginTransaction`/`commit` | 'Updated' | `acc_approval_policies`, `sys_activity_logs` | APPV-01, APPV-02, APPV-04, APPV-05, APPV-06, APPV-10, APPV-12 |
| `destroy` | 133 | DELETE /accounting/approval-policy/{approval_policy} | `tenant.accounting.approval-policy.delete` | controller, manual `beginTransaction`/`commit` | 'Trashed' | `acc_approval_policies` (update + soft delete), `sys_activity_logs` | APPV-01, APPV-02, APPV-04, APPV-05 |
| `toggleStatus` | 164 | POST /accounting/approval-policy/{approval_policy}/toggle-status | `tenant.accounting.approval-policy.update` | controller, manual `beginTransaction`/`commit` | 'Toggled' | `acc_approval_policies`, `sys_activity_logs` | APPV-01, APPV-02, APPV-04, APPV-05 |
| `trashed` | 192 | GET /accounting/approval-policy/trash/view | `tenant.accounting.approval-policy.restore` | none | none | none | APPV-15, APPV-16 |
| `restore` | 201 | GET /accounting/approval-policy/{id}/restore | `tenant.accounting.approval-policy.restore` | controller, manual `beginTransaction`/`commit` | 'Restored' | `acc_approval_policies`, `sys_activity_logs` | APPV-01, APPV-02, APPV-03, APPV-04, APPV-05, APPV-08, APPV-09 |
| `forceDelete` | 228 | DELETE /accounting/approval-policy/{id}/force-delete | `tenant.accounting.approval-policy.forceDelete` | controller, manual `beginTransaction`/`commit` | 'Deleted' | `acc_approval_policies`, `acc_voucher_approvals` (FK NULL), `sys_activity_logs` | APPV-01, APPV-02, APPV-03, APPV-04, APPV-05, APPV-09 |

## 6. Findings

### F1 — Errors

#### APPV-01 · B · ERR-01 — Raw exception text is shown to the user on every mutation

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:72,129,160,188,224,251`, methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Each `catch (\Throwable $e)` builds the flash/JSON message with `'…: ' . $e->getMessage()`, so the raw exception string (including SQLSTATE, table and column names) is rendered to the browser. |
| **Consequence** | A failed create/update/delete shows the user the database's own error text — for example the table name, the failing column, or the SQL statement — instead of a friendly message. |
| **Reproduce** | Open `/accounting/configurations?tab=approval-policies`, submit the create modal with a value that violates a DB constraint (for example a duplicate/invalid foreign key) and read the red flash: it contains the raw exception text. |
| **Fix approach** | Remove the controller `try/catch` (D1). Let `bootstrap/app.php` render the error, and keep only the success flash. |
| **Plan item** | APPV-01 in `02-fix-plan.md` §1 (also resolves APPV-02, APPV-03, APPV-04, APPV-05) |

```php
            return back()->withInput()->with('error', 'Failed to create Approval Policy: ' . $e->getMessage());
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'getMessage'
68:                'error' => $e->getMessage(),
72:            return back()->withInput()->with('error', 'Failed to create Approval Policy: ' . $e->getMessage());
126:                'error' => $e->getMessage(),
129:            return back()->withInput()->with('error', 'Failed to update Approval Policy: ' . $e->getMessage());
157:                'error' => $e->getMessage(),
160:            return back()->with('error', 'Failed to delete Approval Policy: ' . $e->getMessage());
186:            Log::error('Failed to toggle Approval Policy status', ['id' => $approvalPolicy->id, 'error' => $e->getMessage()]);
188:            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
222:            Log::error('Failed to restore Approval Policy', ['id' => $id, 'error' => $e->getMessage()]);
224:            return back()->with('error', 'Failed to restore Approval Policy: ' . $e->getMessage());
249:            Log::error('Failed to force delete Approval Policy', ['id' => $id, 'error' => $e->getMessage()]);
251:            return back()->with('error', 'Failed to delete Approval Policy: ' . $e->getMessage());
```

#### APPV-02 · M · ERR-00 (D1) — Six controller methods use a hand-rolled try/catch instead of the Laravel idiom

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M, raised to M from the rulebook's open decision because D1 settles it) — *no try/catch in controllers; `DB::transaction()` rolls back and rethrows; the central handler logs and renders* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:52,109,138,171,206,233`, methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Every mutation wraps its write in `try { … } catch (\Throwable $e) { … }`. D1 removes this shape: the catch is the place where the 404/message/log bugs below live, and the central handler already logs and renders failures. |
| **Consequence** | Every failure path is hand-written, duplicated six times, and diverges from the rest of the application; each copy is a new opportunity to swallow a 404 or leak a message. |
| **Reproduce** | Static only — the shape is visible in the six methods; no browser action is needed. |
| **Fix approach** | Delete the six `try/catch` blocks and use `DB::transaction(fn () => …)` (see APPV-01's plan item). |
| **Plan item** | APPV-01 in `02-fix-plan.md` §1 |

```php
        try {
            $policy = ApprovalPolicy::create($validated);
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'try \{|\} catch'
52:        try {
65:        } catch (\Throwable $e) {
109:        try {
122:        } catch (\Throwable $e) {
138:        try {
153:        } catch (\Throwable $e) {
171:        try {
184:        } catch (\Throwable $e) {
206:        try {
220:        } catch (\Throwable $e) {
233:        try {
247:        } catch (\Throwable $e) {
```

#### APPV-03 · H · ERR-02 — A missing record becomes a redirect + red flash instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:207,220-224,234,247-251`, methods `restore()`, `forceDelete()` |
| **Root cause** | `ApprovalPolicy::onlyTrashed()->findOrFail($id)` and `ApprovalPolicy::withTrashed()->findOrFail($id)` sit **inside** the `try`, so `ModelNotFoundException` is caught by `catch (\Throwable $e)` and converted into `back()->with('error', …)`. |
| **Consequence** | A user who opens a restore/permanent-delete link for a record that no longer exists sees a red "Failed to …" flash and stays on the page, instead of the correct 404 page. The failure is also logged as an application error. |
| **Reproduce** | Open `/accounting/approval-policy/999999/restore` (GET) or send DELETE to `/accounting/approval-policy/999999/force-delete`. Expected 404; actual redirect with "Failed to restore …: No query results for model …". |
| **Fix approach** | Move `findOrFail()` above the transaction and remove the catch (D1), as shown in APPV-01's plan item. |
| **Plan item** | APPV-01 in `02-fix-plan.md` §1 |

```php
        try {
            $model = ApprovalPolicy::onlyTrashed()->findOrFail($id);
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'findOrFail|\} catch'
207:            $model = ApprovalPolicy::onlyTrashed()->findOrFail($id);
220:        } catch (\Throwable $e) {
234:            $model = ApprovalPolicy::withTrashed()->findOrFail($id);
247:        } catch (\Throwable $e) {
```

#### APPV-04 · M · ERR-05 — Logs record only the message, losing the stack trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception object (`report($e)` or `['exception' => $e]`), not just `getMessage()`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:67-70,124-127,155-158,186,222,249`, methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Five catches pass `'error' => $e->getMessage()` into `Log::error()`; only `store()` adds a separate `'trace' => $e->getTraceAsString()` string. A message string loses the exception class, code and object. |
| **Consequence** | When a policy write fails in production, the log tells the developer only the message text; the exact throw site and the exception object are gone, slowing diagnosis. |
| **Reproduce** | Static only — inspect the six `Log::error` calls; no browser action is needed. |
| **Fix approach** | The six catches are removed by the D1 conversion, so the central handler logs the exception object. |
| **Plan item** | APPV-01 in `02-fix-plan.md` §1 |

```php
            Log::error('Failed to create Approval Policy', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'Log::error'
67:            Log::error('Failed to create Approval Policy', [
124:            Log::error('Failed to update Approval Policy', [
155:            Log::error('Failed to trash Approval Policy', [
186:            Log::error('Failed to toggle Approval Policy status', ['id' => $approvalPolicy->id, 'error' => $e->getMessage()]);
222:            Log::error('Failed to restore Approval Policy', ['id' => $id, 'error' => $e->getMessage()]);
249:            Log::error('Failed to force delete Approval Policy', ['id' => $id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### APPV-05 · M · TXN-02 — Six methods use manual `beginTransaction`/`commit`/`rollBack`

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`; never return between begin and commit* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:51-61,108-118,137-149,170-181,205-217,232-244`, methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Each mutation opens a transaction by hand and commits/rolls back inside the controller. An early return or a new exception branch can leave the transaction open; the closure form cannot. |
| **Consequence** | A future edit that returns between `beginTransaction()` and `commit()` leaks an open transaction; the current code works but is fragile and duplicated six times. |
| **Reproduce** | Static only — the six `beginTransaction`/`commit` pairs are visible in the controller. |
| **Fix approach** | Replace each pair with `DB::transaction(function () use (…) { … });` and build the redirect/JSON response after the closure (see APPV-01's plan item). |
| **Plan item** | APPV-01 in `02-fix-plan.md` §1 |

```php
        DB::beginTransaction();
        try {
            $policy = ApprovalPolicy::create($validated);
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'DB::beginTransaction|DB::commit|DB::rollBack'
51:        DB::beginTransaction();
61:            DB::commit();
66:            DB::rollBack();
108:        DB::beginTransaction();
118:            DB::commit();
123:            DB::rollBack();
137:        DB::beginTransaction();
149:            DB::commit();
154:            DB::rollBack();
170:        DB::beginTransaction();
181:            DB::commit();
185:            DB::rollBack();
205:        DB::beginTransaction();
217:            DB::commit();
221:            DB::rollBack();
232:        DB::beginTransaction();
244:            DB::commit();
248:            DB::rollBack();
```

### F3 — Authorization

#### APPV-06 · L · AUTH-04 — `store`/`update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:43,101`; `Modules/Accounting/app/Http/Requests/ApprovalPolicyRequest.php:16` |
| **Root cause** | `ApprovalPolicyRequest::authorize()` calls `authorizeByCrudPermission('tenant.accounting.approval-policy')`, which checks `…create` for POST and `…update` for PUT/PATCH. The controller then calls `Gate::authorize()` with the same permission again. |
| **Consequence** | No user-visible effect; the permission is evaluated twice, and a future change to one copy can silently diverge from the other. |
| **Reproduce** | Static only — both checks are visible at the named lines. |
| **Fix approach** | Keep the FormRequest check (it runs first) and remove the two controller `Gate::authorize` calls in `store()`/`update()`. |
| **Plan item** | APPV-06 in `02-fix-plan.md` §4 |

```php
        Gate::authorize('tenant.accounting.approval-policy.create');
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/app/Http/Requests/ApprovalPolicyRequest.php -Pattern 'authorizeByCrudPermission'
16:        return $this->authorizeByCrudPermission('tenant.accounting.approval-policy');
$ Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'Gate::authorize'
43:        Gate::authorize('tenant.accounting.approval-policy.create');
101:        Gate::authorize('tenant.accounting.approval-policy.update');
```

#### APPV-07 · L · AUTH-05 — The registered `ApprovalPolicyPolicy` is never consulted

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (L) — *no dead permission logic* |
| **Where** | `Modules/Accounting/app/Providers/AccountingServiceProvider.php:161` (registration); `Modules/Accounting/app/Policies/ApprovalPolicyPolicy.php`; controller authorizes with string abilities at lines 24–230 |
| **Root cause** | The policy is registered with `Gate::policy(ApprovalPolicy::class, ApprovalPolicyPolicy::class)`, but the controller only calls `Gate::authorize('tenant.accounting.approval-policy.*')` with string permission names. A string ability never reaches a model policy method, so the policy's `view`/`update`/etc. methods are unreachable. A repository search finds the class only in its own file and the provider registration. |
| **Consequence** | No login is broken — the string checks work through the Spatie gate hook — but the policy is dead code, and a developer reading it will wrongly believe the model-level checks are active. |
| **Reproduce** | Static only — search for `ApprovalPolicyPolicy` across `Modules/Accounting`; the only hits are the class and the registration. |
| **Fix approach** | Informational: either delete the unused policy or migrate the controller to model-ability checks in a later pass. No runtime change is needed now. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
        Gate::authorize('tenant.accounting.approval-policy.update');
```

**Evidence**
```
$ Get-ChildItem -Recurse -Path Modules/Accounting -Filter '*.php' | Select-String -Pattern 'ApprovalPolicyPolicy'
Modules\Accounting\app\Policies\ApprovalPolicyPolicy.php:10
Modules\Accounting\app\Providers\AccountingServiceProvider.php:56
Modules\Accounting\app\Providers\AccountingServiceProvider.php:161
```

### F4 — Validation and input

clean — `Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern '->all\(\)|->except\(|->fill\('` → no output, and `ApprovalPolicyRequest` supplies every write field (`$request->validated()` at controller lines 45 and 103). `->validate()` appears only in the one-field `toggleStatus` AJAX toggle (line 168), which VAL-02 allows.

### F5 — Routes

#### APPV-08 · H · RTE-01 — Restore changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (restore, delete, toggle, publish, approve, sync, generate); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:405` → `ApprovalPolicyController@restore` |
| **Root cause** | The restore route is declared with `Route::get('/approval-policy/{id}/restore', …)`. Restoring writes `acc_approval_policies` (soft-delete restore + `is_active` update) and writes `sys_activity_logs`. |
| **Consequence** | A browser prefetch, a crawler, or a user opening the restore URL from history restores a deleted policy without any CSRF token or confirmation. |
| **Reproduce** | Open `/accounting/approval-policy/1/restore` directly in the browser (GET). The policy is restored. |
| **Fix approach** | Change the route verb to POST. The shared `x-backend.table.action-trashed` component reads the route's verb and automatically renders a POST form with `@csrf`, so no component change is needed. |
| **Plan item** | APPV-08 in `02-fix-plan.md` §5 (⚠ SHARED — route file) |

```php
Route::get('/approval-policy/{id}/restore', [ApprovalPolicyController::class, 'restore'])->name('approval-policy.restore');
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/routes/web.php -Pattern 'approval-policy'
404:Route::get('/approval-policy/trash/view', [ApprovalPolicyController::class, 'trashed'])->name('approval-policy.trashed');
405:Route::get('/approval-policy/{id}/restore', [ApprovalPolicyController::class, 'restore'])->name('approval-policy.restore');
406:Route::delete('/approval-policy/{id}/force-delete', [ApprovalPolicyController::class, 'forceDelete'])->name('approval-policy.forceDelete');
407:Route::resource('approval-policy', ApprovalPolicyController::class);
408:Route::post('/approval-policy/{approval_policy}/toggle-status', [ApprovalPolicyController::class, 'toggleStatus'])->name('approval-policy.toggleStatus');
```

#### APPV-09 · M · CTL-03 — `restore`/`forceDelete` use `$id` + `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` + `findOrFail`; use `->withTrashed()` on trash routes* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:201-207,228-234` |
| **Root cause** | The custom routes pass `{id}` and the methods accept `$id`, then query `ApprovalPolicy::onlyTrashed()` / `ApprovalPolicy::withTrashed()` themselves. |
| **Consequence** | No user-visible bug; it is extra controller code and the only reason the 404-swallow in APPV-03 exists. |
| **Reproduce** | Static only — the signatures and `findOrFail` calls are visible at the named lines. |
| **Fix approach** | No change in this pass: implicit binding for a soft-deleted record needs an explicit `withTrashed` binding for a custom route. After APPV-01 moves `findOrFail` outside the catch, the behaviour is correct; binding can be revisited in a later refactor. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
    public function restore($id): \Illuminate\Http\RedirectResponse
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'findOrFail'
207:            $model = ApprovalPolicy::onlyTrashed()->findOrFail($id);
234:            $model = ApprovalPolicy::withTrashed()->findOrFail($id);
```

### F6 — Controller shape

#### APPV-10 · M · CTL-05 — The same dropdown loader and slug logic is copy-pasted in `create`/`edit` and `store`/`update`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: dropdown loaders shared by `create`/`edit`, the same payload in `store`/`update`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:33-36,90-93` (loaders) and `48-49,105-106` (slug logic) |
| **Root cause** | The four dropdown queries are duplicated verbatim in `create()` and `edit()`, and the `Str::slug()` block is duplicated in `store()` and `update()`. |
| **Consequence** | A change to one copy (a new column, a new filter, a different order) silently leaves the other screen inconsistent. |
| **Reproduce** | Static only — the duplicated blocks are visible at the named lines. |
| **Fix approach** | Extract the four queries into one private `formOptions()` helper used by both methods. |
| **Plan item** | APPV-10 in `02-fix-plan.md` §5 |

```php
        $voucherTypes = VoucherType::active()->orderBy('name')->get();
        $campuses = Campus::active()->orderBy('name')->get();
        $ledgerGroups = AccountGroup::active()->orderBy('name')->get();
        $roles = Role::orderBy('name')->get();
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern "::active\(\)->orderBy\('name'\)->get\(\)"
33:        $voucherTypes = VoucherType::active()->orderBy('name')->get();
34:        $campuses = Campus::active()->orderBy('name')->get();
35:        $ledgerGroups = AccountGroup::active()->orderBy('name')->get();
90:        $voucherTypes = VoucherType::active()->orderBy('name')->get();
91:        $campuses = Campus::active()->orderBy('name')->get();
92:        $ledgerGroups = AccountGroup::active()->orderBy('name')->get();
```

#### APPV-11 · L · CTL-04 — Eight public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:22,29,41,76,86,99,133,164` |
| **Root cause** | `index`, `create`, `store`, `show`, `edit`, `update`, `destroy` and `toggleStatus` declare no return type; only `trashed`, `restore` and `forceDelete` do. |
| **Consequence** | No user-visible effect; it weakens IDE/static analysis and lets a wrong return shape slip through. |
| **Reproduce** | Static only — `Select-String -Pattern 'public function'` shows the missing types. |
| **Fix approach** | Add `: View`, `: RedirectResponse` or `: JsonResponse` to each signature and import the classes. |
| **Plan item** | APPV-11 in `02-fix-plan.md` §8 |

```php
    public function store(ApprovalPolicyRequest $request)
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'public function'
22:    public function index()
29:    public function create()
41:    public function store(ApprovalPolicyRequest $request)
76:    public function show(ApprovalPolicy $approvalPolicy)
86:    public function edit(ApprovalPolicy $approvalPolicy)
99:    public function update(ApprovalPolicyRequest $request, ApprovalPolicy $approvalPolicy)
133:    public function destroy(ApprovalPolicy $approvalPolicy)
164:    public function toggleStatus(Request $request, ApprovalPolicy $approvalPolicy)
192:    public function trashed(): \Illuminate\View\View
201:    public function restore($id): \Illuminate\Http\RedirectResponse
228:    public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

#### APPV-12 · M · DECISION · CTL-10 — `approver_role_slug` is computed but has no column and is not fillable

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code; no code that cannot affect behaviour* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:48-49,105-106`; model `Modules/Accounting/app/Models/ApprovalPolicy.php:17-33`; migration `2026_09_16_100030_create_acc_approval_policies_table.php:20-50` |
| **Root cause** | `store()`/`update()` write `$validated['approver_role_slug']`, but `acc_approval_policies` has no `approver_role_slug` column and the model does not list it in `$fillable`. Mass assignment silently drops it, so the computation never reaches the database and nothing reads it. |
| **Consequence** | The screen appears to save an approver-role slug, but it never exists; a future consumer expecting that field would read null. The code also misleads a maintainer into thinking the column exists (the migration's `approver1_role_id` comment even mentions it). |
| **Reproduce** | Run the probe below on the test tenant: `has_column_approver_role_slug=no`, `isFillable_approver_role_slug=no`. |
| **Fix approach** | DECISION: remove the dead lines (recommended), or add the column + `$fillable` entry if the slug is a real feature. |
| **Plan item** | APPV-12 in `02-fix-plan.md` §9 (DECISION) |

```php
        $role1 = Role::find($validated['approver1_role_id'] ?? null);
        $validated['approver_role_slug'] = $role1 ? Str::slug($role1->name) : 'accountant';
```

**Evidence**
```
$ php ap-probe.php
model=Modules\Accounting\Models\ApprovalPolicy
has_column_approver_role_slug=no
isFillable_approver_role_slug=no
method_approver1Role=no
attr_approver1Role=NULL
```

#### APPV-13 · L · CTL-10 — `index.blade.php` is never rendered

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *no dead code* |
| **Where** | `Modules/Accounting/resources/views/approval-policy/index.blade.php` (90 lines); controller `index()` at line 26 redirects instead of rendering it |
| **Root cause** | `index()` returns `redirect()->route('accounting.menu.configurations', …)`. A repository search finds no `approval-policy.index` view render or `@include` of `approval-policy/index`, so the view is unreachable. |
| **Consequence** | No user-visible effect; the file is maintenance noise and its lazy `$policy->voucherType` loop would be an N+1 if someone wired it up later. |
| **Reproduce** | Static only — the search below returns no hits. |
| **Fix approach** | Delete the unused view in a later cleanup, or leave it as an accepted fallback. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
        return redirect()->route('accounting.menu.configurations', ['tab' => 'approval-policies']);
```

**Evidence**
```
$ Get-ChildItem -Recurse -Path Modules/Accounting/resources/views -Filter '*.blade.php' | Select-String -Pattern "approval-policy\.index|approval-policy/index"
(no output)
```

### F7 — Models

#### APPV-14 · H · MDL-04 — The show page can never display an approver role

| Field | Value |
|---|---|
| **Rule** | MDL-04 (H, raised from L because the screen always shows the wrong value) — *relationships are declared and resolve; relationships used by a view must exist* |
| **Where** | `Modules/Accounting/resources/views/approval-policy/show.blade.php:120,125,130`; `Modules/Accounting/app/Models/ApprovalPolicy.php:46-64` (only `voucherType`, `campus`, `ledgerGroup`, `creator` exist) |
| **Root cause** | The view reads `$policy->approver1Role`, `$policy->approver2Role` and `$policy->approver3Role`, but the model defines no such relationships. Eloquent returns `null` for an undefined attribute, so the `?? '-'` fallback always wins. |
| **Consequence** | Every approval policy's detail page shows "-" for Approver 1/2/3 Role, even when the row has valid role ids. A finance user cannot see who is supposed to approve. |
| **Reproduce** | Open `/accounting/approval-policy/1` (the seeded "Routine Transactions Auto-Approval" policy has `approver1_role_id` set). The Approvers panel shows "-" for every level. |
| **Fix approach** | Add `approver1Role()`, `approver2Role()` and `approver3Role()` `BelongsTo` relationships to the model and eager-load them in `show()`. |
| **Plan item** | APPV-14 in `02-fix-plan.md` §5 |

```php
                                            <span class="fw-medium text-dark">{{ $policy->approver1Role->name ?? '-' }}</span>
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/resources/views/approval-policy/show.blade.php -Pattern 'approver[123]Role'
120:                                            <span class="fw-medium text-dark">{{ $policy->approver1Role->name ?? '-' }}</span>
125:                                            <span class="fw-medium text-dark">{{ $policy->approver2Role->name ?? '-' }}</span>
130:                                            <span class="fw-medium text-dark">{{ $policy->approver3Role->name ?? '-' }}</span>
$ Select-String -Path Modules/Accounting/app/Models/ApprovalPolicy.php -Pattern 'public function'
46:    public function voucherType(): BelongsTo
51:    public function campus(): BelongsTo
56:    public function ledgerGroup(): BelongsTo
61:    public function creator(): BelongsTo
68:    public function scopeActive($query)
73:    public function scopeForType($query, int $voucherTypeId)
```

### F8 — Services and jobs

clean — the controller injects no service and dispatches no job (`Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'Service|Job|dispatch'` → no output); the only helper is the common `activityLog()`.

### F9 — Queries and performance

#### APPV-15 · L · QRY-02 — The trash list paginates at 15, not the house size of 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (L, lowered because the list *is* paginated; only the page size differs from the house standard) — *lists paginate at 10* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:196` |
| **Root cause** | `paginate(15)` on the only list this controller renders. |
| **Consequence** | The trash screen shows 15 rows per page instead of the standard 10; a purely consistency issue, not a load problem. |
| **Reproduce** | Open `/accounting/approval-policy/trash/view` with more than 10 trashed rows and count the rows. |
| **Fix approach** | Change `15` to `10` in the same edit that adds the eager load (APPV-16). |
| **Plan item** | resolved by APPV-16 in `02-fix-plan.md` §6; see §10 |

```php
        $policies = ApprovalPolicy::onlyTrashed()->orderBy('name')->paginate(15);
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'paginate'
196:        $policies = ApprovalPolicy::onlyTrashed()->orderBy('name')->paginate(15);
```

### F10 — Views

#### APPV-16 · M · VIEW-02 — The trash list lazy-loads `voucherType` once per row

| Field | Value |
|---|---|
| **Rule** | VIEW-02 (M) — *relations used inside `@foreach` are eager-loaded; lazy loads in a loop are N+1* |
| **Where** | `Modules/Accounting/resources/views/approval-policy/trash.blade.php:33`; query at `ApprovalPolicyController.php:196` |
| **Root cause** | `trashed()` loads trashed policies without `with('voucherType')`, while the Blade accesses `$policy->voucherType->name` inside the row loop. |
| **Consequence** | 10–15 extra voucher-type queries per trash page; the page slows as the trash grows. |
| **Reproduce** | Open `/accounting/approval-policy/trash/view`; the query log shows one `acc_voucher_types` query per row. |
| **Fix approach** | Add `->with('voucherType')` before `orderBy` and use `paginate(10)` (also fixes APPV-15). |
| **Plan item** | APPV-16 in `02-fix-plan.md` §6 |

```php
                                                <span class="badge bg-info text-dark">{{ $policy->voucherType->name ?? '-' }}</span>
```

**Evidence**
```
$ Select-String -Path Modules/Accounting/resources/views/approval-policy/trash.blade.php -Pattern 'voucherType'
33:                                                <span class="badge bg-info text-dark">{{ $policy->voucherType->name ?? '-' }}</span>
$ Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'paginate'
196:        $policies = ApprovalPolicy::onlyTrashed()->orderBy('name')->paginate(15);
```

### F11 — Security and tenancy

clean — no `env()` in the controller (`Select-String -Pattern 'env\('` → no output); no raw SQL (`Select-String -Pattern 'whereRaw|DB::raw|selectRaw|DB::select|orderByRaw'` → no output); the toggle JSON returns only `success`, `is_active` and a fixed message (line 183); logs carry ids, not request bodies or secrets.

### F12 — Style

#### APPV-17 · L · STY-02 — Pint fails on all four in-scope PHP files

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray lines* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php`; `…/Models/ApprovalPolicy.php`; `…/Http/Requests/ApprovalPolicyRequest.php`; `…/Policies/ApprovalPolicyPolicy.php` |
| **Root cause** | Pint reports fixers in every file: controller (`fully_qualified_strict_types`, `concat_space`, `ordered_imports`, `binary_operator_spaces`), model (`…`, `method_chaining_indentation`, `no_unused_imports`, `ordered_imports`, `binary_operator_spaces`), request (`cast_spaces`, `not_operator_with_successor_space`, `ordered_imports`, `binary_operator_spaces`), policy (`ordered_imports`). The model also imports `App\Models\BaseModel`, which it never uses. |
| **Consequence** | No user-visible effect; the files diverge from the project's formatting standard and future diffs carry style noise. |
| **Reproduce** | Run `vendor\bin\pint --test <file> --format agent` on each file; all four report `"result":"fail"`. |
| **Fix approach** | Run Pint on the four files. |
| **Plan item** | APPV-17 in `02-fix-plan.md` §8 |

```php
        if (!$this->filled('name') && $this->filled('policy_name')) {
```

**Evidence**
```
$ vendor\bin\pint --test Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\ApprovalPolicyController.php","fixers":["fully_qualified_strict_types","concat_space","ordered_imports","binary_operator_spaces"]}]}
$ vendor\bin\pint --test Modules/Accounting/app/Models/ApprovalPolicy.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\ApprovalPolicy.php","fixers":["fully_qualified_strict_types","method_chaining_indentation","no_unused_imports","ordered_imports","binary_operator_spaces"]}]}
$ vendor\bin\pint --test Modules/Accounting/app/Http/Requests/ApprovalPolicyRequest.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\ApprovalPolicyRequest.php","fixers":["cast_spaces","not_operator_with_successor_space","ordered_imports","binary_operator_spaces"]}]}
$ vendor\bin\pint --test Modules/Accounting/app/Policies/ApprovalPolicyPolicy.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Policies\\ApprovalPolicyPolicy.php","fixers":["ordered_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Delete before replace | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | APPV-12 (slug dropped) | ok | APPV-10 | ok — no unique index on `name` | ok — no check-then-act | APPV-06 | ok | APPV-12 |
| `update` | APPV-12 (slug dropped) | ok | APPV-10 | ok | ok | APPV-06 | ok | APPV-12 |
| `destroy` | ok — forces `is_active=false` before soft delete (intended trash state) | ok | APPV-10 | ok | ok | ok | ok — flash "moved to trash" matches | ok |
| `toggleStatus` | ok — writes only `is_active` | ok | APPV-10 | ok | ok | ok | ok | ok |
| `restore` | ok — restored row is reactivated by design | ok | APPV-10 | ok | ok | ok | ok | ok |
| `forceDelete` | ok — FK `nullOnDelete` clears `acc_voucher_approvals.policy_id` | ok — permanent delete is the operation | APPV-10 | ok | ok | ok | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:545` | The approval-policy list tab loads every live policy with `$policiesQuery->get()` — no pagination. The list is served by `AccDashboardController`, not this controller. | QRY-02 | The `AccDashboardController` owner report (currently CLAIMED) |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_approval-policies.blade.php` | The real list/create-modal UI lives in this partial and is rendered by `AccDashboardController`; it is outside this controller's render set. It does eager-load `voucherType`/`campus`/`ledgerGroup` through the dashboard query. | VIEW-02 / QRY-02 | The `AccDashboardController` owner report |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | Base model shared by the module; not re-audited here. | — | ↗ AccountingStatusMasterController report |
| `Modules/SchoolSetup/app/Models/Role.php` | Other-module model used for the role dropdown; not audited here. | — | common — SchoolSetup |

## 8. Not covered, and why

- **Scanner (`scan.php`) was not run** and **`selfcheck.py` was not run**: the tooling override for this run says `_tools\scanfilter.py` and `_tools\selfcheck.py` are missing and `scan.php` must not be run. F1–F13 were checked manually with `read`/`grep`/`Select-String` and the commands quoted above.
- **Blade compilation was not executed.** The five approval-policy blades were read statically; no `Blade::compileString()` was run, so a syntax-only Blade error is not ruled out.
- **No browser or HTTP request was made (D4).** CSRF behaviour of the new POST restore route, the modal flow, and the actual rendered page were not exercised.
- **The role/permission seeding was verified only for `viewAny`** (row id 1345, 5 roles). The other five actions (`create`, `view`, `update`, `delete`, `restore`, `forceDelete`) are declared by `config/permissionslist.php` and emitted by `PermissionHelper::flatten()`, but their tenant rows were not individually counted.
- **`ApprovalPolicyPolicy` was not executed.** It is registered but unreachable from this controller (APPV-07); its methods were read, not invoked.
- **`AccDashboardController` (the real list page) is another controller's report.** Only the approval-policy route rows and the query at line 545 were inspected for context.
- **Queue jobs, listeners, mail and events:** none are involved in this controller.
