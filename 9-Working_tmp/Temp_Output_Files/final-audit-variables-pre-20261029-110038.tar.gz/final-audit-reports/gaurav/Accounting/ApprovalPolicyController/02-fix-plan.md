# Fix Plan — Accounting / ApprovalPolicyController

**From:** `01-report.md` (2026-10-22) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | Shared route file. Only the single APPV-08 line may be edited, and only when APPV-08 is explicitly ticked. |
| `resources/views/components/backend/table/action-trashed.blade.php` | Shared component. It already reads the route verb and emits POST + `@csrf`; no change is needed or allowed. |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | Owned by the `AccDashboardController` report. |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | Owned by the `AccountingStatusMasterController` report. |
| `Modules/SchoolSetup/app/Models/Role.php` | Other-module model, common. |
| `database/migrations/**` | No migration is applied in this pass. APPV-12 option (b) would need one, and only if Tarun chooses it. |
| `final-audit-reports/00-CLASS-OWNERS.md`, `final-audit-reports/gaurav/Accounting/00-INDEX.md` | Registries. The fixer updates only the controller's own index row per protocol; it never rewrites these files. |

## 1. Blockers reachable today

- [ ] **APPV-01** · B · ERR-01 · `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:41-74,99-131,133-162,164-190,201-226,228-253` — remove the six hand-rolled try/catch transactions so no exception text reaches the user and a 404 stays a 404. Also resolves APPV-02, APPV-03, APPV-04 and APPV-05.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php`
  - **Before** (`ApprovalPolicyController.php:41-74`, `store`):
    ```php
    public function store(ApprovalPolicyRequest $request)
    {
        Gate::authorize('tenant.accounting.approval-policy.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        $role1 = Role::find($validated['approver1_role_id'] ?? null);
        $validated['approver_role_slug'] = $role1 ? Str::slug($role1->name) : 'accountant';

        DB::beginTransaction();
        try {
            $policy = ApprovalPolicy::create($validated);

            activityLog($policy, 'Created', [
                'message'      => 'Approval Policy created: ' . $policy->name,
                'name'         => $policy->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.configurations', ['tab' => 'approval-policies'])
                ->with('success', 'Approval Policy created successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Approval Policy', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Approval Policy: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`store`):
    ```php
    public function store(ApprovalPolicyRequest $request)
    {
        Gate::authorize('tenant.accounting.approval-policy.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        $role1 = Role::find($validated['approver1_role_id'] ?? null);
        $validated['approver_role_slug'] = $role1 ? Str::slug($role1->name) : 'accountant';

        DB::transaction(function () use ($validated) {
            $policy = ApprovalPolicy::create($validated);

            activityLog($policy, 'Created', [
                'message'      => 'Approval Policy created: ' . $policy->name,
                'name'         => $policy->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.configurations', ['tab' => 'approval-policies'])
            ->with('success', 'Approval Policy created successfully.');
    }
    ```
  - **Before** (`ApprovalPolicyController.php:99-131`, `update`):
    ```php
    public function update(ApprovalPolicyRequest $request, ApprovalPolicy $approvalPolicy)
    {
        Gate::authorize('tenant.accounting.approval-policy.update');

        $validated = $request->validated();

        $role1 = Role::find($validated['approver1_role_id'] ?? null);
        $validated['approver_role_slug'] = $role1 ? Str::slug($role1->name) : ($approvalPolicy->approver_role_slug ?? 'accountant');

        DB::beginTransaction();
        try {
            $approvalPolicy->update($validated);

            activityLog($approvalPolicy, 'Updated', [
                'message'      => 'Approval Policy updated: ' . $approvalPolicy->name,
                'name'         => $approvalPolicy->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.configurations', ['tab' => 'approval-policies'])
                ->with('success', 'Approval Policy updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to update Approval Policy', [
                'id'    => $approvalPolicy->id,
                'error' => $e->getMessage(),
            ]);

            return back()->withInput()->with('error', 'Failed to update Approval Policy: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`update`):
    ```php
    public function update(ApprovalPolicyRequest $request, ApprovalPolicy $approvalPolicy)
    {
        Gate::authorize('tenant.accounting.approval-policy.update');

        $validated = $request->validated();

        $role1 = Role::find($validated['approver1_role_id'] ?? null);
        $validated['approver_role_slug'] = $role1 ? Str::slug($role1->name) : ($approvalPolicy->approver_role_slug ?? 'accountant');

        DB::transaction(function () use ($approvalPolicy, $validated) {
            $approvalPolicy->update($validated);

            activityLog($approvalPolicy, 'Updated', [
                'message'      => 'Approval Policy updated: ' . $approvalPolicy->name,
                'name'         => $approvalPolicy->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.configurations', ['tab' => 'approval-policies'])
            ->with('success', 'Approval Policy updated successfully.');
    }
    ```
  - **Before** (`ApprovalPolicyController.php:133-162`, `destroy`):
    ```php
    public function destroy(ApprovalPolicy $approvalPolicy)
    {
        Gate::authorize('tenant.accounting.approval-policy.delete');

        DB::beginTransaction();
        try {
            $approvalPolicy->is_active = false;
            $approvalPolicy->save();
            $approvalPolicy->delete();

            activityLog($approvalPolicy, 'Trashed', [
                'message'      => 'Approval Policy trashed: ' . $approvalPolicy->name,
                'name'         => $approvalPolicy->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.configurations', ['tab' => 'approval-policies'])
                ->with('success', 'Approval Policy moved to trash.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to trash Approval Policy', [
                'id'    => $approvalPolicy->id,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'Failed to delete Approval Policy: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`destroy`):
    ```php
    public function destroy(ApprovalPolicy $approvalPolicy)
    {
        Gate::authorize('tenant.accounting.approval-policy.delete');

        DB::transaction(function () use ($approvalPolicy) {
            $approvalPolicy->is_active = false;
            $approvalPolicy->save();
            $approvalPolicy->delete();

            activityLog($approvalPolicy, 'Trashed', [
                'message'      => 'Approval Policy trashed: ' . $approvalPolicy->name,
                'name'         => $approvalPolicy->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.configurations', ['tab' => 'approval-policies'])
            ->with('success', 'Approval Policy moved to trash.');
    }
    ```
  - **Before** (`ApprovalPolicyController.php:164-190`, `toggleStatus`):
    ```php
    public function toggleStatus(Request $request, ApprovalPolicy $approvalPolicy)
    {
        Gate::authorize('tenant.accounting.approval-policy.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::beginTransaction();
        try {
            $approvalPolicy->is_active = $request->input('is_active');
            $approvalPolicy->save();

            activityLog($approvalPolicy, 'Toggled', [
                'message'      => 'Approval Policy status toggled: ' . $approvalPolicy->name,
                'name'         => $approvalPolicy->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return response()->json(['success' => true, 'is_active' => $approvalPolicy->is_active, 'message' => 'Status updated.']);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to toggle Approval Policy status', ['id' => $approvalPolicy->id, 'error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
        }
    }
    ```
  - **After** (`toggleStatus`):
    ```php
    public function toggleStatus(Request $request, ApprovalPolicy $approvalPolicy)
    {
        Gate::authorize('tenant.accounting.approval-policy.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::transaction(function () use ($request, $approvalPolicy) {
            $approvalPolicy->is_active = $request->input('is_active');
            $approvalPolicy->save();

            activityLog($approvalPolicy, 'Toggled', [
                'message'      => 'Approval Policy status toggled: ' . $approvalPolicy->name,
                'name'         => $approvalPolicy->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return response()->json(['success' => true, 'is_active' => $approvalPolicy->is_active, 'message' => 'Status updated.']);
    }
    ```
  - **Before** (`ApprovalPolicyController.php:201-226`, `restore`):
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.approval-policy.restore');

        DB::beginTransaction();
        try {
            $model = ApprovalPolicy::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'Approval Policy restored: ' . $model->name,
                'name'         => $model->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.approval-policy.trashed')->with('success', 'Approval Policy restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Approval Policy', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Approval Policy: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`restore`):
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.approval-policy.restore');

        $model = ApprovalPolicy::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($model) {
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'Approval Policy restored: ' . $model->name,
                'name'         => $model->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.approval-policy.trashed')->with('success', 'Approval Policy restored successfully.');
    }
    ```
  - **Before** (`ApprovalPolicyController.php:228-253`, `forceDelete`):
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.approval-policy.forceDelete');

        DB::beginTransaction();
        try {
            $model = ApprovalPolicy::withTrashed()->findOrFail($id);
            $name = $model->name;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Approval Policy permanently deleted: ' . $name,
                'name'         => $name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.approval-policy.trashed')->with('success', 'Approval Policy permanently deleted.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to force delete Approval Policy', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Approval Policy: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`forceDelete`):
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.approval-policy.forceDelete');

        $model = ApprovalPolicy::withTrashed()->findOrFail($id);
        $name = $model->name;

        DB::transaction(function () use ($model, $name) {
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Approval Policy permanently deleted: ' . $name,
                'name'         => $name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.approval-policy.trashed')->with('success', 'Approval Policy permanently deleted.');
    }
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'try \{|DB::beginTransaction|getMessage'`
  - **Expect:** no output.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

No item here. APPV-01 is the enabling fix; the items below assume it has been applied.

## 3. Errors & transactions (F1/F2)

All F1/F2 findings (APPV-01–APPV-05) are resolved by the one APPV-01 item above. No separate item is needed.

## 4. Authorization (F3)

- [ ] **APPV-06** · L · AUTH-04 · `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:43,101` — remove the duplicate `Gate::authorize` calls; the FormRequest already authorizes the same permission first.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php`
  - **Before** (`ApprovalPolicyController.php:41-45`, `store`):
    ```php
    public function store(ApprovalPolicyRequest $request)
    {
        Gate::authorize('tenant.accounting.approval-policy.create');

        $validated = $request->validated();
    ```
  - **After** (`store`):
    ```php
    public function store(ApprovalPolicyRequest $request)
    {
        $validated = $request->validated();
    ```
  - **Before** (`ApprovalPolicyController.php:99-103`, `update`):
    ```php
    public function update(ApprovalPolicyRequest $request, ApprovalPolicy $approvalPolicy)
    {
        Gate::authorize('tenant.accounting.approval-policy.update');

        $validated = $request->validated();
    ```
  - **After** (`update`):
    ```php
    public function update(ApprovalPolicyRequest $request, ApprovalPolicy $approvalPolicy)
    {
        $validated = $request->validated();
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern "Gate::authorize\('tenant.accounting.approval-policy.create'\)|Gate::authorize\('tenant.accounting.approval-policy.update'\)"`
  - **Expect:** no output.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **APPV-08** · H · RTE-01 · `Modules/Accounting/routes/web.php:405` — stop restoring a policy over GET; POST carries CSRF. **⚠ SHARED — route file.**
  - **Touches:** `Modules/Accounting/routes/web.php` (one line only)
  - **Before** (`web.php:405`):
    ```php
    Route::get('/approval-policy/{id}/restore', [ApprovalPolicyController::class, 'restore'])->name('approval-policy.restore');
    ```
  - **After:**
    ```php
    Route::post('/approval-policy/{id}/restore', [ApprovalPolicyController::class, 'restore'])->name('approval-policy.restore');
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/routes/web.php -Pattern 'approval-policy/\{id\}/restore'`
  - **Expect:** one line beginning `Route::post(`.
  - **Effort:** S

- [ ] **APPV-10** · M · CTL-05 · `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:33-36,90-93` — replace the duplicated dropdown loaders with one private helper.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php`
  - **Before** (`ApprovalPolicyController.php:33-38`, `create`):
    ```php
        $voucherTypes = VoucherType::active()->orderBy('name')->get();
        $campuses = Campus::active()->orderBy('name')->get();
        $ledgerGroups = AccountGroup::active()->orderBy('name')->get();
        $roles = Role::orderBy('name')->get();

        return view('accounting::approval-policy.create', compact('voucherTypes', 'campuses', 'ledgerGroups', 'roles'));
    ```
  - **After** (`create`):
    ```php
        return view('accounting::approval-policy.create', $this->formOptions());
    ```
  - **Before** (`ApprovalPolicyController.php:90-96`, `edit`):
    ```php
        $voucherTypes = VoucherType::active()->orderBy('name')->get();
        $campuses = Campus::active()->orderBy('name')->get();
        $ledgerGroups = AccountGroup::active()->orderBy('name')->get();
        $roles = Role::orderBy('name')->get();
        $policy = $approvalPolicy;

        return view('accounting::approval-policy.edit', compact('approvalPolicy', 'policy', 'voucherTypes', 'campuses', 'ledgerGroups', 'roles'));
    ```
  - **After** (`edit`):
    ```php
        $policy = $approvalPolicy;

        return view('accounting::approval-policy.edit', $this->formOptions() + [
            'approvalPolicy' => $approvalPolicy,
            'policy' => $policy,
        ]);
    ```
  - **Add** this private method inside `ApprovalPolicyController`, immediately after the opening `{` of the class (before `public function index()`):
    ```php
    private function formOptions(): array
    {
        return [
            'voucherTypes' => VoucherType::active()->orderBy('name')->get(),
            'campuses' => Campus::active()->orderBy('name')->get(),
            'ledgerGroups' => AccountGroup::active()->orderBy('name')->get(),
            'roles' => Role::orderBy('name')->get(),
        ];
    }
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'formOptions'`
  - **Expect:** 3 lines (one definition, two calls).
  - **Effort:** S

- [ ] **APPV-14** · H · MDL-04 · `Modules/Accounting/app/Models/ApprovalPolicy.php:46-64` and `…/ApprovalPolicyController.php:80` — add the three approver-role relationships so the show page can display them.
  - **Touches:** `Modules/Accounting/app/Models/ApprovalPolicy.php`, `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php`
  - **Before** (`ApprovalPolicy.php:8-9`):
    ```php
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    ```
  - **After** (`ApprovalPolicy.php` imports):
    ```php
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Modules\SchoolSetup\Models\Role;
    ```
  - **Before** (`ApprovalPolicy.php:61-64`, after `creator()`):
    ```php
    public function creator(): BelongsTo
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'created_by');
    }
    ```
  - **After** (`ApprovalPolicy.php`, add the three relations):
    ```php
    public function creator(): BelongsTo
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'created_by');
    }

    public function approver1Role(): BelongsTo
    {
        return $this->belongsTo(Role::class, 'approver1_role_id');
    }

    public function approver2Role(): BelongsTo
    {
        return $this->belongsTo(Role::class, 'approver2_role_id');
    }

    public function approver3Role(): BelongsTo
    {
        return $this->belongsTo(Role::class, 'approver3_role_id');
    }
    ```
  - **Before** (`ApprovalPolicyController.php:80`, `show`):
    ```php
        $approvalPolicy->load(['voucherType', 'campus', 'ledgerGroup', 'creator']);
    ```
  - **After** (`show`):
    ```php
        $approvalPolicy->load(['voucherType', 'campus', 'ledgerGroup', 'creator', 'approver1Role', 'approver2Role', 'approver3Role']);
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Models/ApprovalPolicy.php -Pattern 'function approver[123]Role'`
  - **Expect:** 3 lines.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **APPV-16** · M · VIEW-02 · `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:196` — eager-load the voucher type for the trash list and use the house page size of 10 (also resolves APPV-15).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php`
  - **Before** (`ApprovalPolicyController.php:196`):
    ```php
        $policies = ApprovalPolicy::onlyTrashed()->orderBy('name')->paginate(15);
    ```
  - **After:**
    ```php
        $policies = ApprovalPolicy::onlyTrashed()->with('voucherType')->orderBy('name')->paginate(10);
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'onlyTrashed\(\)->with'`
  - **Expect:** one line containing `with('voucherType')` and `paginate(10)`.
  - **Effort:** S

## 7. Views (F10)

No separate item. APPV-16 fixes the only view finding (the trash list N+1).

## 8. Style (F12) — one item per file

- [ ] **APPV-11** · L · CTL-04 · `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php:22,29,41,76,86,99,133,164` — add return types to the eight public methods that lack them.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php`
  - **Before** (`ApprovalPolicyController.php:7-11`, imports):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    ```
  - **After** (add the three type imports; Pint will sort them):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    ```
  - **Before** (`index`):
    ```php
    public function index()
    ```
  - **After:**
    ```php
    public function index(): RedirectResponse
    ```
  - **Before** (`create`):
    ```php
    public function create()
    ```
  - **After:**
    ```php
    public function create(): View
    ```
  - **Before** (`store`):
    ```php
    public function store(ApprovalPolicyRequest $request)
    ```
  - **After:**
    ```php
    public function store(ApprovalPolicyRequest $request): RedirectResponse
    ```
  - **Before** (`show`):
    ```php
    public function show(ApprovalPolicy $approvalPolicy)
    ```
  - **After:**
    ```php
    public function show(ApprovalPolicy $approvalPolicy): View
    ```
  - **Before** (`edit`):
    ```php
    public function edit(ApprovalPolicy $approvalPolicy)
    ```
  - **After:**
    ```php
    public function edit(ApprovalPolicy $approvalPolicy): View
    ```
  - **Before** (`update`):
    ```php
    public function update(ApprovalPolicyRequest $request, ApprovalPolicy $approvalPolicy)
    ```
  - **After:**
    ```php
    public function update(ApprovalPolicyRequest $request, ApprovalPolicy $approvalPolicy): RedirectResponse
    ```
  - **Before** (`destroy`):
    ```php
    public function destroy(ApprovalPolicy $approvalPolicy)
    ```
  - **After:**
    ```php
    public function destroy(ApprovalPolicy $approvalPolicy): RedirectResponse
    ```
  - **Before** (`toggleStatus`):
    ```php
    public function toggleStatus(Request $request, ApprovalPolicy $approvalPolicy)
    ```
  - **After:**
    ```php
    public function toggleStatus(Request $request, ApprovalPolicy $approvalPolicy): JsonResponse
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php -Pattern 'public function (index|create|store|show|edit|update|destroy|toggleStatus)\([^)]*\): '`
  - **Expect:** 8 lines.
  - **Effort:** S

- [ ] **APPV-17** · L · STY-02 · four in-scope PHP files — make them Pint-clean.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php`, `Modules/Accounting/app/Models/ApprovalPolicy.php`, `Modules/Accounting/app/Http/Requests/ApprovalPolicyRequest.php`, `Modules/Accounting/app/Policies/ApprovalPolicyPolicy.php`
  - **Before** (`ApprovalPolicyRequest.php:76`, one of the changes Pint makes):
    ```php
            if (!$this->filled('name') && $this->filled('policy_name')) {
    ```
  - **After:**
    ```php
            if (! $this->filled('name') && $this->filled('policy_name')) {
    ```
  - **Command to run (this is the actual fix — it applies the same normalisation to all four files):**
    ```powershell
    vendor\bin\pint Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php Modules/Accounting/app/Models/ApprovalPolicy.php Modules/Accounting/app/Http/Requests/ApprovalPolicyRequest.php Modules/Accounting/app/Policies/ApprovalPolicyPolicy.php --format agent
    ```
  - **Verify:** `vendor\bin\pint --test Modules/Accounting/app/Http/Controllers/ApprovalPolicyController.php Modules/Accounting/app/Models/ApprovalPolicy.php Modules/Accounting/app/Http/Requests/ApprovalPolicyRequest.php Modules/Accounting/app/Policies/ApprovalPolicyPolicy.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass",...}` for all four files.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **APPV-12** · M · DECISION · CTL-10 — what should happen to the dead `approver_role_slug` code?
  - **Why it is a decision:** option (b) needs a new column (migration + `$fillable`); option (a) removes a computed value; option (c) accepts dead code. There is no single mechanical answer.
  - (a) ⭐ **Remove the dead code** — delete `store` lines 48-49 (`$role1 = Role::find(...)` and `$validated['approver_role_slug'] = ...`) and `update` lines 105-106 (the same two lines). Nothing reads the slug; no migration. Recommended.
  - (b) **Implement the missing field** — write a new additive tenant migration adding `approver_role_slug` VARCHAR(60) NULL to `acc_approval_policies`, add it to `$fillable`, keep the controller code, and backfill existing rows. This is a migration decision and is **not** applied by this pass.
  - (c) **Leave as is** — record it as accepted dead code; the field will keep being silently dropped.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| APPV-02 | Resolved by APPV-01: removing the six try/catch blocks removes the D1 violation. No separate edit. |
| APPV-03 | Resolved by APPV-01: `findOrFail()` moves above `DB::transaction()`, so a missing record returns 404. |
| APPV-04 | Resolved by APPV-01: the catches are gone, so the central handler logs the exception object. |
| APPV-05 | Resolved by APPV-01: manual begin/commit/rollBack is replaced by `DB::transaction()`. |
| APPV-07 | Informational: the registered `ApprovalPolicyPolicy` is unreachable from this controller but causes no runtime harm. Delete or migrate to model abilities in a later pass. |
| APPV-09 | No fix in this pass: implicit binding for soft-deleted records needs a `withTrashed` custom binding. After APPV-01 the explicit `findOrFail` behaves correctly. |
| APPV-13 | Dead view `index.blade.php` is unreachable because `index()` redirects. Safe to delete in a cleanup pass; no user impact today. |
| APPV-15 | Resolved by APPV-16: the same line is changed to `paginate(10)`. |
