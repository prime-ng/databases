# Final Audit — Accounting / TdsCertificateController

**Audited:** 2026-10-22 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php` (304 lines, 12 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/tds?tab=tds-certificates` (list tab), `/accounting/tds-certificate`, `/accounting/tds-certificate/create`, `/accounting/tds-certificate/{id}`, `/accounting/tds-certificate/{id}/edit`, `/accounting/tds-certificate/{id}/download`, `/accounting/tds-certificate/{id}/toggle-status`, `/accounting/tds-certificate/trash/view`, `/accounting/tds-certificate/{id}/restore`, `/accounting/tds-certificate/{id}/force-delete` |
| Menu path | Accounting → TDS Management → Lower/Nil Certificates tab |
| Who uses it | No role holds any `tenant.accounting.tds-certificate.*` permission: exact-name count is `0` in `sys_permissions` and `0` rows in `sys_role_has_permissions_jnt`. Five roles hold `tenant.accounting.dashboard.view`: Super Admin, School Admin, Management, Account Staff, Account Manager. Only Super Admin reaches this controller, through the `Gate::before` bypass. |
| What a user does here | Maintains lower-deduction and nil-deduction TDS certificates under section 197: certificate number, payee ledger, section, rate, validity window, ceiling amount, consumed amount, status and an optional scanned certificate document. The list tab opens a create modal; a user edits a certificate, downloads the scanned document, toggles active status, soft-deletes it to trash, restores it, or permanently deletes it. |
| Tables written | `acc_tds_certificates`, `sys_media`, `sys_activity_logs` |
| Tables read | `acc_tds_certificates`, `acc_ledgers`, `sys_media`, `sys_users`, `acc_tds_deductions` (proposed guard only) |
| Live data | On `xyz_school_00000000000040008000_202627`: `acc_tds_certificates` 1 live / 0 trashed; `acc_ledgers` 56; `sys_media` 8; `acc_tds_deductions` 1, and 1 of those references certificate id 1. The only certificate has no uploaded document (`media_id` is NULL). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No, this controller is not production-ready. The single worst finding is TDSC-06: every route authorizes with a `tenant.accounting.tds-certificate.*` permission that is not declared in `config/permissionslist.php` and is not seeded, so every role except Super Admin is refused at the gate and the whole feature is invisible to them. Once that is opened, TDSC-01 is the next blocker: six mutation methods catch `\Throwable` and put the raw exception text (SQL, constraint names) into the flash or JSON response. The permission namespace also leaves four other roles unable to exercise the form, which is why the validation and FK defects (TDSC-08, TDSC-09, TDSC-22) have stayed hidden. Rough effort: **M**, about two developer-days plus a permission sync performed by Tarun.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 7 | 8 | 5 | 2 | 22 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TDSC-01, TDSC-02, TDSC-03, TDSC-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | TDSC-05 | F9 Queries/Perf | TDSC-17, TDSC-18 |
| F3 Authorization | TDSC-06, TDSC-07 | F10 Views | clean |
| F4 Validation | TDSC-08, TDSC-09, TDSC-10 | F11 Security/Tenancy | TDSC-19, TDSC-20 |
| F5 Routes | TDSC-11 | F12 Style | TDSC-21 |
| F6 Controller shape | TDSC-12, TDSC-13, TDSC-14, TDSC-15 | F13 Deep read | TDSC-22 |
| F7 Models | TDSC-16 | | |

Counts add up: F1(4) + F2(1) + F3(2) + F4(3) + F5(1) + F6(4) + F7(1) + F9(2) + F11(2) + F12(1) + F13(1) = 22.

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php` | controller | 304 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/TdsCertificate.php` | model | 115 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/TdsCertificateRequest.php` | FormRequest | 79 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/resources/views/tds-certificate/show.blade.php` | view | 141 | this report | ✅ |
| 5 | `Modules/Accounting/resources/views/tds-certificate/edit.blade.php` | view | 225 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/tds-certificate/trash.blade.php` | view | 68 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/tds-certificate/create.blade.php` | view | 0 | this report | ❌ file does not exist — see TDSC-15 |
| 8 | `database/migrations/tenant/2026_09_16_100028_create_acc_tds_certificates_table.php` | migration (DDL evidence) | 64 | this report | ✅ read-only |
| 9 | `Modules/Accounting/resources/views/pages/partials/tds-management/_tds-certificates.blade.php` | list-tab view | 408 | ↗ [gaurav/Accounting/AccDashboardController](../AccDashboardController/01-report.md) (CLAIMED) | ↗ linked, out of scope |
| 10 | `Modules/Accounting/app/Models/Ledger.php` | model (dropdown) | 408 | ↗ [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) | ↗ linked |
| 11 | `app/Models/TenantMedia.php` | model (media row) | 80 | ↗ [tarun/SystemConfig-done/TenantMediaStoreController](../../../tarun/SystemConfig-done/TenantMediaStoreController/01-report.md) | ↗ linked |
| 12 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | model parent | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 13 | `Modules/Accounting/app/Services/AccountingContext.php` | service used by the model parent | 110 | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 14 | `Modules/Accounting/routes/web.php` | route file | 536 | shared — checked F5 only | ✅ checked only |
| 15 | `config/permissionslist.php` | shared config | 1804 | shared — checked F3 only | ✅ checked only |

No pre-applied files were found for this module.

## 4. Routes

```
GET|HEAD  accounting/tds-certificate                              accounting.tds-certificate.index    Modules\Accounting\Http\Controllers\TdsCertificateController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/tds-certificate                              accounting.tds-certificate.store    Modules\Accounting\Http\Controllers\TdsCertificateController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-certificate/create                       accounting.tds-certificate.create   Modules\Accounting\Http\Controllers\TdsCertificateController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-certificate/trash/view                   accounting.tds-certificate.trashed  Modules\Accounting\Http\Controllers\TdsCertificateController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/tds-certificate/{id}/force-delete            accounting.tds-certificate.forceDelete Modules\Accounting\Http\Controllers\TdsCertificateController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-certificate/{id}/restore                 accounting.tds-certificate.restore  Modules\Accounting\Http\Controllers\TdsCertificateController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-certificate/{tds_certificate}            accounting.tds-certificate.show     Modules\Accounting\Http\Controllers\TdsCertificateController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/tds-certificate/{tds_certificate}            accounting.tds-certificate.update   Modules\Accounting\Http\Controllers\TdsCertificateController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/tds-certificate/{tds_certificate}            accounting.tds-certificate.destroy  Modules\Accounting\Http\Controllers\TdsCertificateController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-certificate/{tds_certificate}/download   accounting.tds-certificate.downloadCertificate Modules\Accounting\Http\Controllers\TdsCertificateController@downloadCertificate  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-certificate/{tds_certificate}/edit       accounting.tds-certificate.edit     Modules\Accounting\Http\Controllers\TdsCertificateController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/tds-certificate/{tds_certificate}/toggle-status accounting.tds-certificate.toggleStatus Modules\Accounting\Http\Controllers\TdsCertificateController@toggleStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none. All 12 public methods appear in the uncached route list above.
Route notes: the custom trash/download/toggle routes at `Modules/Accounting/routes/web.php:456-460` sit before `Route::resource` at `:461`. The resource routes bind `{tds_certificate}` and the controller arguments match (`$tdsCertificate`). `restore` and `forceDelete` use `{id}` and `$id`, so they bind an integer and call `findOrFail()` themselves. `restore` is a GET that writes (TDSC-11). The tenant middleware stack is present on every route.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 20 | GET /accounting/tds-certificate | `tenant.accounting.tds-certificate.viewAny` | none | none | none | TDSC-06, TDSC-14 |
| `create` | 27 | GET /accounting/tds-certificate/create | `tenant.accounting.tds-certificate.create` | none | none | none | TDSC-06, TDSC-14, TDSC-15, TDSC-18 |
| `store` | 36 | POST /accounting/tds-certificate | `tenant.accounting.tds-certificate.create` (also FormRequest `create`) | controller, manual 42-80 | 'Created' | acc_tds_certificates, sys_media, sys_activity_logs | TDSC-01, TDSC-03, TDSC-04, TDSC-05, TDSC-06, TDSC-07, TDSC-12, TDSC-14, TDSC-20 |
| `show` | 95 | GET /accounting/tds-certificate/{tds_certificate} | `tenant.accounting.tds-certificate.view` | none | none | none | TDSC-06, TDSC-14, TDSC-19 |
| `edit` | 104 | GET /accounting/tds-certificate/{tds_certificate}/edit | `tenant.accounting.tds-certificate.update` | none | none | none | TDSC-06, TDSC-14, TDSC-18, TDSC-20 |
| `update` | 114 | PUT/PATCH /accounting/tds-certificate/{tds_certificate} | `tenant.accounting.tds-certificate.update` (also FormRequest `update`) | controller, manual 118-151 | 'Updated' | acc_tds_certificates, sys_media, sys_activity_logs | TDSC-01, TDSC-03, TDSC-04, TDSC-05, TDSC-06, TDSC-07, TDSC-08, TDSC-12, TDSC-14, TDSC-20 |
| `downloadCertificate` | 166 | GET /accounting/tds-certificate/{tds_certificate}/download | `tenant.accounting.tds-certificate.view` | none | none | none | TDSC-06, TDSC-14, TDSC-20 |
| `destroy` | 188 | DELETE /accounting/tds-certificate/{tds_certificate} | `tenant.accounting.tds-certificate.delete` | controller, manual 192-202 | 'Deleted' | acc_tds_certificates, sys_activity_logs | TDSC-01, TDSC-03, TDSC-04, TDSC-05, TDSC-06, TDSC-14 |
| `toggleStatus` | 214 | POST /accounting/tds-certificate/{tds_certificate}/toggle-status | `tenant.accounting.tds-certificate.update` | controller, manual 220-231 | 'Toggled' | acc_tds_certificates, sys_activity_logs | TDSC-01, TDSC-03, TDSC-04, TDSC-05, TDSC-06, TDSC-14 |
| `trashed` | 242 | GET /accounting/tds-certificate/trash/view | `tenant.accounting.tds-certificate.restore` | none | none | none | TDSC-06, TDSC-14, TDSC-17 |
| `restore` | 251 | GET /accounting/tds-certificate/{id}/restore | `tenant.accounting.tds-certificate.restore` | controller, manual 255-267 | 'Restored' | acc_tds_certificates, sys_activity_logs | TDSC-01, TDSC-02, TDSC-03, TDSC-04, TDSC-05, TDSC-06, TDSC-11, TDSC-14 |
| `forceDelete` | 278 | DELETE /accounting/tds-certificate/{id}/force-delete | `tenant.accounting.tds-certificate.forceDelete` | controller, manual 282-294 | 'Deleted' | acc_tds_certificates, sys_activity_logs | TDSC-01, TDSC-02, TDSC-03, TDSC-04, TDSC-05, TDSC-06, TDSC-14, TDSC-20, TDSC-22 |

## 6. Findings

### F1 — Errors

#### TDSC-01 · B · ERR-01 — Raw exception text is shown to the user on every failed write

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; no `$e->getMessage()` in `withErrors`, `with('error')`, `response()->json` or `back()`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:91, 162, 210, 238, 274, 301`, methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Every mutation catches `\Throwable` and concatenates `$e->getMessage()` into the flash or JSON response. The catch also swallows the framework's own rendering, so a duplicate key, a CHECK constraint or an FK restriction is presented as prose instead of the central error page. |
| **Consequence** | A user who saves an invalid amount or deletes a used certificate sees raw SQLSTATE text, table names and constraint names in the red banner or JSON body. |
| **Reproduce** | As Super Admin open `/accounting/tds-certificate/1/edit`, set Consumed Amount above Limit Amount, save. The flash contains the SQL CHECK-constraint text from `chk_acc_tdscert_consumed`. |
| **Fix approach** | Remove the six catches, use `DB::transaction()`, and let Laravel's central handler render failures; keep fixed, user-safe flash text only on success. Also resolves TDSC-02, TDSC-03, TDSC-04 and TDSC-05 for the five methods it rewrites. |
| **Plan item** | TDSC-01 in `02-fix-plan.md` §1 (forceDelete is covered by TDSC-22) |

```php
// TdsCertificateController.php:84-92 — CURRENT (store; the same shape is repeated five times)
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create TDS Certificate', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create TDS Certificate: ' . $e->getMessage());
        }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "getMessage"
87:                'error' => $e->getMessage(),
91:            return back()->withInput()->with('error', 'Failed to create TDS Certificate: ' . $e->getMessage());
159:                'error' => $e->getMessage(),
162:            return back()->withInput()->with('error', 'Failed to update TDS Certificate: ' . $e->getMessage());
208:            Log::error('Failed to delete TDS Certificate', ['id' => $tdsCertificate->id, 'error' => $e->getMessage()]);
210:            return back()->with('error', 'Failed to delete TDS Certificate: ' . $e->getMessage());
236:            Log::error('Failed to toggle TDS Certificate status', ['id' => $tdsCertificate->id, 'error' => $e->getMessage()]);
238:            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
272:            Log::error('Failed to restore TDS Certificate', ['id' => $id, 'error' => $e->getMessage()]);
274:            return back()->with('error', 'Failed to restore TDS Certificate: ' . $e->getMessage());
299:            Log::error('Failed to force delete TDS Certificate', ['id' => $id, 'error' => $e->getMessage()]);
301:            return back()->with('error', 'Failed to delete TDS Certificate: ' . $e->getMessage());
```

#### TDSC-02 · H · ERR-02 — A missing record gives a redirect instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422/`abort()` into a redirect or 500; `findOrFail()` belongs before the try* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:257, 284`, methods `restore()` and `forceDelete()` |
| **Root cause** | `findOrFail()` sits inside the `try`, so the generic `catch (\Throwable $e)` also catches `ModelNotFoundException` and converts a 404 into a redirect with an error flash. |
| **Consequence** | Opening a restore/force-delete URL for a deleted or non-existent id shows a red "Failed to restore/delete" flash (with raw exception text) instead of the normal 404 page. |
| **Reproduce** | Open `/accounting/tds-certificate/999999/restore` as Super Admin. Expected 404; actual redirect with a red flash. |
| **Fix approach** | Resolve the model before the transaction and do not catch it. TDSC-01 moves `restore()`; TDSC-22 rewrites `forceDelete()`. |
| **Plan item** | TDSC-01 and TDSC-22 in `02-fix-plan.md` §1 |

```php
// restore() — CURRENT
        DB::beginTransaction();
        try {
            $model = TdsCertificate::onlyTrashed()->findOrFail($id);

// forceDelete() — CURRENT
        DB::beginTransaction();
        try {
            $model = TdsCertificate::withTrashed()->findOrFail($id);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "findOrFail"
257:            $model = TdsCertificate::onlyTrashed()->findOrFail($id);
284:            $model = TdsCertificate::withTrashed()->findOrFail($id);
```

#### TDSC-03 · M · ERR-05 — `Log::error()` logs the message string, losing the stack trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:86-89, 157-159, 208, 236, 272, 299` |
| **Root cause** | Each catch logs an array containing only the message (store also logs a stringified trace). The exception object, previous exceptions and request context are discarded. |
| **Consequence** | When a write fails in production, the log has one sentence and no stack trace, so support cannot tell which query or line failed. |
| **Reproduce** | Static only — the log format is visible in source; no browser action needed. |
| **Fix approach** | Removing the catches (TDSC-01/TDSC-22) removes these logs. If a log is still wanted, use `report($e)` inside the central handler. |
| **Plan item** | TDSC-01 and TDSC-22 in `02-fix-plan.md` §1 |

```php
// TdsCertificateController.php:86-89 — CURRENT
            Log::error('Failed to create TDS Certificate', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "Log::error"
86:            Log::error('Failed to create TDS Certificate', [
157:            Log::error('Failed to update TDS Certificate', [
208:            Log::error('Failed to delete TDS Certificate', ['id' => $tdsCertificate->id, 'error' => $e->getMessage()]);
236:            Log::error('Failed to toggle TDS Certificate status', ['id' => $tdsCertificate->id, 'error' => $e->getMessage()]);
272:            Log::error('Failed to restore TDS Certificate', ['id' => $id, 'error' => $e->getMessage()]);
299:            Log::error('Failed to force delete TDS Certificate', ['id' => $id, 'error' => $e->getMessage()]);
```

#### TDSC-04 · M · ERR-00 — Six controller `try/catch` blocks violate the D1 idiom

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M) — *under D1 there is no `try/catch` in a controller; `DB::transaction()` rolls back and rethrows, and the central handler logs/renders* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:43, 119, 193, 221, 256, 283` |
| **Root cause** | The controller keeps the old house-A1 shape (manual transaction plus catch) instead of the Laravel idiom settled in D1. The rulebook leaves ERR-00 open, but `final-audit.md` D1 overrides it for final audit. |
| **Consequence** | Six failure paths must each be maintained for ERR-01/02/03/05; a future edit can reintroduce a leak or swallow a 404 in any one of them. |
| **Reproduce** | Static only — structural pattern. |
| **Fix approach** | Delete all six blocks in the TDSC-01/TDSC-22 rewrites. |
| **Plan item** | TDSC-01 and TDSC-22 in `02-fix-plan.md` §1 |

```php
// TdsCertificateController.php:42-43 — CURRENT (representative)
        DB::beginTransaction();
        try {
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "try \{"
43:        try {
119:        try {
193:        try {
221:        try {
256:        try {
283:        try {
```

### F2 — Transactions and audit

#### TDSC-05 · M · TXN-02 — Manual `beginTransaction()/commit()/rollBack()` in six methods

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`; never return between begin and commit* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:42-85, 118-156, 192-207, 220-235, 255-271, 282-298` |
| **Root cause** | Every mutation hand-rolls its transaction boundary and duplicates the rollback in a catch. |
| **Consequence** | A future early return or non-caught error between begin and commit leaves an open transaction; the same rollback code is repeated six times. |
| **Reproduce** | Static only — structural pattern. |
| **Fix approach** | Replace each with `DB::transaction(function () { … });` in TDSC-01/TDSC-22. |
| **Plan item** | TDSC-01 and TDSC-22 in `02-fix-plan.md` §1 |

```php
// each of the six mutations — CURRENT
        DB::beginTransaction();
        try {
            // mutation
            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
        }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "beginTransaction|DB::commit|DB::rollBack"
42:        DB::beginTransaction();
80:            DB::commit();
85:            DB::rollBack();
118:        DB::beginTransaction();
151:            DB::commit();
156:            DB::rollBack();
192:        DB::beginTransaction();
202:            DB::commit();
207:            DB::rollBack();
220:        DB::beginTransaction();
231:            DB::commit();
235:            DB::rollBack();
255:        DB::beginTransaction();
267:            DB::commit();
271:            DB::rollBack();
282:        DB::beginTransaction();
294:            DB::commit();
298:            DB::rollBack();
```

### F3 — Authorization

#### TDSC-06 · B · AUTH-01 — The permission namespace does not exist, so every method denies every non-super-admin role

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B) — *every routed method authorizes with a permission that is declared in `config/permissionslist.php` and seeded with an exact-name query* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:22, 29, 38, 97, 106, 116, 168, 190, 216, 244, 253, 280`; `config/permissionslist.php:600-644`; `Modules/Accounting/app/Http/Requests/TdsCertificateRequest.php:17` |
| **Root cause** | Every gate names `tenant.accounting.tds-certificate.*`, but the `accounting.tds-certificate` key was never added to the Accounting block of `config/permissionslist.php`, and the live tenant has zero such permission rows and zero role grants. The Super Admin bypass is the only path through the Gate. |
| **Consequence** | School Admin, Management, Account Staff and Account Manager receive 403 on every route, and the Lower/Nil Certificates tab is hidden from them; only Super Admin can use the feature. |
| **Reproduce** | Log in as a School Admin and open `/accounting/tds-certificate`. Expected the list; actual 403. |
| **Fix approach** | Add `'accounting.tds-certificate' => $crud` beside `'accounting.tax-rate' => $crud`, then run the permission sync and grant the new keys to the accounting roles. Adding a key is a DECISION; seeding is Tarun's hand. |
| **Plan item** | TDSC-06 in `02-fix-plan.md` §4 (DECISION, ⚠ SHARED) |

```php
// TdsCertificateController.php:20-25 — CURRENT (same literal in all 12 methods)
    public function index()
    {
        Gate::authorize('tenant.accounting.tds-certificate.viewAny');

        return redirect()->route('accounting.menu.tds', ['tab' => 'tds-certificates']);
    }
```

**Evidence**
```
> Select-String -Path "config\permissionslist.php" -Pattern "accounting.tds"
(no output)
> mysql -u root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_permissions WHERE name LIKE 'tenant.accounting.tds-certificate%';"
0
> mysql -u root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_role_has_permissions_jnt j JOIN xyz_school_00000000000040008000_202627.sys_permissions p ON p.id=j.permission_id WHERE p.name LIKE 'tenant.accounting.tds-certificate%';"
0
> mysql -u root -N -e "SELECT r.name FROM xyz_school_00000000000040008000_202627.sys_roles r JOIN xyz_school_00000000000040008000_202627.sys_role_has_permissions_jnt j ON j.role_id=r.id JOIN xyz_school_00000000000040008000_202627.sys_permissions p ON p.id=j.permission_id WHERE p.name='tenant.accounting.dashboard.view';"
Super Admin
School Admin
Management
Account Staff
Account Manager
```

#### TDSC-07 · L · AUTH-04 — The same permission is authorized twice in store and update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *do not authorize the same permission twice (FormRequest `authorize()` plus `Gate::authorize`); keep one* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:38, 116`; `Modules/Accounting/app/Http/Requests/TdsCertificateRequest.php:17` |
| **Root cause** | `store()` and `update()` call `Gate::authorize()` with `create`/`update`, and the injected FormRequest also authorizes the same action through `authorizeByCrudPermission()`. |
| **Consequence** | Two sources of truth for the same decision can drift; no user-visible effect today because both resolve to the same missing permission. |
| **Reproduce** | Static only — inspect the two authorize calls. |
| **Fix approach** | Remove the two controller `Gate::authorize()` calls and let the FormRequest authorize; TDSC-01 does this. |
| **Plan item** | TDSC-01 in `02-fix-plan.md` §1 |

```php
// TdsCertificateRequest.php:15-18 — CURRENT
    public function authorize(): bool
    {
        return $this->authorizeByCrudPermission('tenant.accounting.tds-certificate');
    }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php","Modules\Accounting\app\Http\Requests\TdsCertificateRequest.php" -Pattern "Gate::authorize\('tenant.accounting.tds-certificate.(create|update)'|authorizeByCrudPermission"
Modules\Accounting\app\Http\Controllers\TdsCertificateController.php:29:        Gate::authorize('tenant.accounting.tds-certificate.create');
Modules\Accounting\app\Http\Controllers\TdsCertificateController.php:38:        Gate::authorize('tenant.accounting.tds-certificate.create');
Modules\Accounting\app\Http\Controllers\TdsCertificateController.php:106:        Gate::authorize('tenant.accounting.tds-certificate.update');
Modules\Accounting\app\Http\Controllers\TdsCertificateController.php:116:        Gate::authorize('tenant.accounting.tds-certificate.update');
Modules\Accounting\app\Http\Controllers\TdsCertificateController.php:216:        Gate::authorize('tenant.accounting.tds-certificate.update');
Modules\Accounting\app\Http\Requests\TdsCertificateRequest.php:17:        return $this->authorizeByCrudPermission('tenant.accounting.tds-certificate');
```

### F4 — Validation and input

#### TDSC-08 · H · VAL-04 — Re-creating a trashed certificate passes validation then hits the unique index

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the DB unique index including soft-delete semantics; a rule that excludes trashed rows under a unique index that includes them is a 500* |
| **Where** | `Modules/Accounting/app/Http/Requests/TdsCertificateRequest.php:26-34`; `database/migrations/tenant/2026_09_16_100028_create_acc_tds_certificates_table.php:40` |
| **Root cause** | The validation rule ends with `->withoutTrashed()`, but the database unique key `uq_acc_tdscert` is `(party_ledger_id, certificate_no, section_code)` with no `deleted_at` column, so it also covers soft-deleted rows. |
| **Consequence** | A user who deletes a certificate and then registers another with the same payee, certificate number and section passes validation and gets a duplicate-key SQL error instead of a validation message. |
| **Reproduce** | Soft-delete certificate `LDC/2026/000145`, then create another certificate with the same party ledger, certificate number and section. Expected a validation error; actual SQL duplicate-key error. |
| **Fix approach** | Remove `->withoutTrashed()` so the rule matches the real index and returns a field error. |
| **Plan item** | TDSC-08 in `02-fix-plan.md` §2 |

```php
// TdsCertificateRequest.php:26-34 — CURRENT
            'certificate_no'   => [
                'required',
                'string',
                'max:50',
                Rule::unique('acc_tds_certificates', 'certificate_no')
                    ->where(fn($q) => $q->where('party_ledger_id', $this->input('party_ledger_id'))->where('section_code', $this->input('section_code')))
                    ->ignore($id)
                    ->withoutTrashed(),
            ],
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\TdsCertificateRequest.php" -Pattern "withoutTrashed"
33:                    ->withoutTrashed(),
> Select-String -Path "database\migrations\tenant\2026_09_16_100028_create_acc_tds_certificates_table.php" -Pattern "unique"
40:            $table->unique(['party_ledger_id', 'certificate_no', 'section_code'], 'uq_acc_tdscert');
```

#### TDSC-09 · H · VAL-07 — Consumed amount above the limit passes validation and hits the DB CHECK constraint

| Field | Value |
|---|---|
| **Rule** | VAL-07 (H, raised from M — a normal save reaches a DB CHECK and 500s) — *cross-field/business checks belong in the FormRequest, not only in the database* |
| **Where** | `Modules/Accounting/app/Http/Requests/TdsCertificateRequest.php:41-42`; `database/migrations/tenant/2026_09_16_100028_create_acc_tds_certificates_table.php:54` |
| **Root cause** | `consumed_amount` is validated only as `numeric|min:0`. The ceiling rule `consumed_amount <= limit_amount` exists only in the `chk_acc_tdscert_consumed` CHECK constraint. |
| **Consequence** | A user can enter a consumed amount larger than the ceiling; validation passes, the INSERT/UPDATE fails at the database, and the raw CHECK-constraint error is shown (TDSC-01). |
| **Reproduce** | Edit certificate 1, set Limit Amount 1000 and Consumed Amount 2000, save. Expected a validation message; actual SQL CHECK-constraint error. |
| **Fix approach** | Add a closure rule that compares the two submitted values. |
| **Plan item** | TDSC-09 in `02-fix-plan.md` §2 |

```php
// TdsCertificateRequest.php:41-42 — CURRENT
            'limit_amount'     => ['nullable', 'numeric', 'min:0'],
            'consumed_amount'  => ['nullable', 'numeric', 'min:0'],
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\TdsCertificateRequest.php" -Pattern "consumed_amount"
42:            'consumed_amount'  => ['nullable', 'numeric', 'min:0'],
> Select-String -Path "database\migrations\tenant\2026_09_16_100028_create_acc_tds_certificates_table.php" -Pattern "chk_acc_tdscert_consumed"
54:        DB::statement("ALTER TABLE `acc_tds_certificates` ADD CONSTRAINT `chk_acc_tdscert_consumed` CHECK (`consumed_amount` >= 0 AND (`limit_amount` IS NULL OR `consumed_amount` <= `limit_amount`))");
```

#### TDSC-10 · M · VAL-05 — The Active Record checkbox cannot be switched off

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is validated and trusted as submitted; a boolean field must not be rewritten to a different value* |
| **Where** | `Modules/Accounting/app/Http/Requests/TdsCertificateRequest.php:69-72`; `Modules/Accounting/resources/views/tds-certificate/edit.blade.php:166` |
| **Root cause** | `prepareForValidation()` calls `$this->boolean('is_active', true)`. Browsers omit an unchecked checkbox, so the absent key takes the default `true` and the user's choice is lost. |
| **Consequence** | A user unchecks Active Record, saves, and the certificate is still active; the form silently lies. |
| **Reproduce** | Edit certificate 1, clear Active Record, save, reopen the edit page. The checkbox is still checked. |
| **Fix approach** | Remove the forced default: `$this->boolean('is_active')`. The form already defaults the checkbox to checked on create, so only an unchecked box becomes false. |
| **Plan item** | TDSC-10 in `02-fix-plan.md` §5 |

```php
// TdsCertificateRequest.php:69-72 — CURRENT
    protected function prepareForValidation(): void
    {
        $this->merge([
            'is_active'       => $this->boolean('is_active', true),
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\TdsCertificateRequest.php" -Pattern "boolean\('is_active'"
72:            'is_active'       => $this->boolean('is_active', true),
> Select-String -Path "Modules\Accounting\resources\views\tds-certificate\edit.blade.php" -Pattern "name=\"is_active\""
166:                                                        <input type="checkbox" name="is_active" id="tc_is_active" class="form-check-input" value="1" {{ old('is_active', $tdsCertificate->is_active) ? 'checked' : '' }}>
```

### F5 — Routes

#### TDSC-11 · H · RTE-01 — A restore (state change) is performed over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:457`; `Modules/Accounting/resources/views/tds-certificate/trash.blade.php:38` |
| **Root cause** | Restore is registered as a `GET` route, and the trash view renders it as a plain `<a href>` link. |
| **Consequence** | A prefetcher, crawler or shared URL can restore a trashed certificate without a POST or CSRF token; the action is not protected from cross-site triggering. |
| **Reproduce** | While logged in, open `/accounting/tds-certificate/1/restore` directly. The certificate is restored without a form submission. |
| **Fix approach** | Register the route as POST and replace the link with a CSRF-protected form. |
| **Plan item** | TDSC-11 in `02-fix-plan.md` §5 (⚠ SHARED — route file) |

```php
// Modules/Accounting/routes/web.php:457 — CURRENT
Route::get('/tds-certificate/{id}/restore', [TdsCertificateController::class, 'restore'])->name('tds-certificate.restore');
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "tds-certificate/\{id\}/restore"
457:Route::get('/tds-certificate/{id}/restore', [TdsCertificateController::class, 'restore'])->name('tds-certificate.restore');
> Select-String -Path "Modules\Accounting\resources\views\tds-certificate\trash.blade.php" -Pattern "tds-certificate.restore"
38:                                            <a href="{{ route('accounting.tds-certificate.restore', $cert->id) }}" class="btn btn-sm btn-outline-success">
```

### F6 — Controller shape

#### TDSC-12 · M · CTL-05 — The media-creation payload is copy-pasted in `store()` and `update()`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same 30-line payload in `store` and `update` must be shared* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:46-65` and `122-141` |
| **Root cause** | The 18-line `TenantMedia::create()` block is duplicated. The two copies already differ: store creates with `model_id = 0` and updates afterwards; update writes the id directly. |
| **Consequence** | A future field added to the media row must be added twice; the copies will drift, and update already has no cleanup for the replaced media. |
| **Reproduce** | Static only — compare the two blocks. |
| **Fix approach** | Extract one private `storeCertificateMedia()` helper used by both; TDSC-01 includes it. |
| **Plan item** | TDSC-01 in `02-fix-plan.md` §1 |

```php
// TdsCertificateController.php:51-64 — CURRENT (repeated at 127-140)
                $media = TenantMedia::create([
                    'model_type'        => TdsCertificate::class,
                    'model_id'          => 0,
                    'collection_name'   => 'tds_certificates',
                    'name'              => pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME),
                    'file_name'         => $file->getClientOriginalName(),
                    'mime_type'         => $file->getClientMimeType(),
                    'disk'              => 'public',
                    'size'              => $file->getSize(),
                    'manipulations'     => [],
                    'custom_properties' => ['stored_path' => $storedPath],
                    'responsive_images' => [],
                ]);
                $validated['media_id'] = $media->id;
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "TenantMedia::create"
51:                $media = TenantMedia::create([
127:                $media = TenantMedia::create([
```

#### TDSC-13 · L · CTL-03 — `restore()` and `forceDelete()` use `$id` plus `findOrFail()` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (L, lowered from M because the current code is correct and the fix needs a shared route file) — *use route model binding (`show(Homework $homework)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:251-257, 278-284`; `Modules/Accounting/routes/web.php:457-458` |
| **Root cause** | The two trash routes bind `{id}` as an integer, while every resource method binds `{tds_certificate}`. |
| **Consequence** | No functional bug today; the 404 handling is duplicated and the two trash methods are inconsistent with the rest of the controller. |
| **Reproduce** | Static only — compare the route parameter names with the method signatures. |
| **Fix approach** | None in this pass; binding a trashed model needs `->withTrashed()` in the shared route file. Accepted as debt (see plan §10). |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// TdsCertificateController.php:251-257 — CURRENT
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-certificate.restore');

        DB::beginTransaction();
        try {
            $model = TdsCertificate::onlyTrashed()->findOrFail($id);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "tds-certificate/\{id\}/restore|tds-certificate/\{id\}/force-delete"
457:Route::get('/tds-certificate/{id}/restore', [TdsCertificateController::class, 'restore'])->name('tds-certificate.restore');
458:Route::delete('/tds-certificate/{id}/force-delete', [TdsCertificateController::class, 'forceDelete'])->name('tds-certificate.forceDelete');
```

#### TDSC-14 · L · CTL-04 — Nine public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:20, 27, 36, 95, 104, 114, 166, 188, 214` |
| **Root cause** | Only `trashed()`, `restore()` and `forceDelete()` declare a return type. |
| **Consequence** | Static analysis cannot catch a method that returns the wrong response type; no runtime effect. |
| **Reproduce** | Static only — inspect the signatures. |
| **Fix approach** | Add the types in the TDSC-01 rewrite, including `StreamedResponse|RedirectResponse` for the download. |
| **Plan item** | TDSC-01 in `02-fix-plan.md` §1 |

```php
// TdsCertificateController.php:20, 27, 36 — CURRENT
    public function index()
    public function create()
    public function store(TdsCertificateRequest $request)
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "public function"
20:    public function index()
27:    public function create()
36:    public function store(TdsCertificateRequest $request)
95:    public function show(TdsCertificate $tdsCertificate)
104:    public function edit(TdsCertificate $tdsCertificate)
114:    public function update(TdsCertificateRequest $request, TdsCertificate $tdsCertificate)
166:    public function downloadCertificate(TdsCertificate $tdsCertificate)
188:    public function destroy(TdsCertificate $tdsCertificate)
214:    public function toggleStatus(Request $request, TdsCertificate $tdsCertificate)
242:    public function trashed(): \Illuminate\View\View
251:    public function restore($id): \Illuminate\Http\RedirectResponse
278:    public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

#### TDSC-15 · M · CTL-10 — `create()` renders a view that does not exist

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code; a method that no UI reaches and that cannot render is dead surface* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:27-34`; missing `Modules/Accounting/resources/views/tds-certificate/create.blade.php` |
| **Root cause** | `create()` returns `view('accounting::tds-certificate.create')`, but the module has only `edit`, `show` and `trash` blades. The list tab creates through a modal, and no file links to the routed create page. |
| **Consequence** | Visiting `/accounting/tds-certificate/create` throws "View [tds-certificate.create] not found" and returns a 500, even for Super Admin. The route exists but is unusable. |
| **Reproduce** | Open `/accounting/tds-certificate/create` as Super Admin. Expected a form; actual 500. |
| **Fix approach** | DECISION: remove the routed create page and keep the modal, or add the missing blade and link it. |
| **Plan item** | TDSC-15 in `02-fix-plan.md` §9 (DECISION) |

```php
// TdsCertificateController.php:27-34 — CURRENT
    public function create()
    {
        Gate::authorize('tenant.accounting.tds-certificate.create');

        $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();

        return view('accounting::tds-certificate.create', compact('partyLedgers'));
    }
```

**Evidence**
```
> Test-Path "Modules\Accounting\resources\views\tds-certificate\create.blade.php"
False
> Get-ChildItem "Modules\Accounting\resources\views\tds-certificate" | Select-Object Name
edit.blade.php
show.blade.php
trash.blade.php
```

### F7 — Models

#### TDSC-16 · M · MDL-02 — The two enum columns have no casts

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` for every boolean, date/datetime, decimal, json/array and enum column* |
| **Where** | `Modules/Accounting/app/Models/TdsCertificate.php:34-41`; `database/migrations/tenant/2026_09_16_100028_create_acc_tds_certificates_table.php:24, 33` |
| **Root cause** | `certificate_type` and `status` are MySQL enum columns but are absent from `$casts`. Other accounting models cast their status-like columns to `string` (for example `OpeningBalance`). |
| **Consequence** | The attributes are raw driver values with no declared contract, so a future move to PHP enums or a typo check has to rediscover every consumer. |
| **Reproduce** | Static only — compare the migration columns with the model casts. |
| **Fix approach** | Add `'certificate_type' => 'string'` and `'status' => 'string'` to `$casts`. |
| **Plan item** | TDSC-16 in `02-fix-plan.md` §5 |

```php
// TdsCertificate.php:34-41 — CURRENT
    protected $casts = [
        'valid_from'       => 'date',
        'valid_to'         => 'date',
        'certified_rate'   => 'decimal:9,4',
        'limit_amount'     => 'decimal:2',
        'consumed_amount'  => 'decimal:2',
        'is_active'        => 'boolean',
    ];
```

**Evidence**
```
> Select-String -Path "database\migrations\tenant\2026_09_16_100028_create_acc_tds_certificates_table.php" -Pattern "enum\("
24:            $table->enum('certificate_type', ['Lower_Deduction', 'Nil_Deduction', 'Self_Declaration_15G', 'Self_Declaration_15H'])->default('Lower_Deduction');
33:            $table->enum('status', ['Active', 'Exhausted', 'Expired', 'Revoked'])->default('Active');
```

### F8 — Services and jobs

clean — `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "dispatch|Service|Job|env\("` → no output. The controller injects no service and dispatches no job.

### F9 — Queries and performance

#### TDSC-17 · M · QRY-02 — The trash list paginates at 15, not the standard 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M) — *lists are paginated; the project standard is 10 rows per page with a distinct page name per list* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:246` |
| **Root cause** | `paginate(15)` is hard-coded instead of the standard `paginate(10, ['*'], 'trash_page')`. |
| **Consequence** | The trash page renders 50% more rows and DOM than every other paginated list in the module, and a second paginator on the same page would collide on the default page name. |
| **Reproduce** | Open `/accounting/tds-certificate/trash/view` with more than 15 trashed rows; the page shows 15 rows. |
| **Fix approach** | Change to `paginate(10, ['*'], 'trash_page')`. |
| **Plan item** | TDSC-17 in `02-fix-plan.md` §6 |

```php
// TdsCertificateController.php:246 — CURRENT
        $certificates = TdsCertificate::onlyTrashed()->with('partyLedger')->orderBy('certificate_no')->paginate(15);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "paginate\("
246:        $certificates = TdsCertificate::onlyTrashed()->with('partyLedger')->orderBy('certificate_no')->paginate(15);
```

#### TDSC-18 · L · QRY-15 — The create/edit dropdown loads every active ledger

| Field | Value |
|---|---|
| **Rule** | QRY-15 (L, lowered from M because the table holds 56 rows today) — *do not load every row of a big table for a form* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:31, 109` |
| **Root cause** | `Ledger::where('is_active', true)->orderBy('name')->get()` fetches every column of every active ledger for a simple dropdown. |
| **Consequence** | As the chart of accounts grows, the edit/create page grows linearly and loads columns the dropdown never uses. |
| **Reproduce** | Static only — live `acc_ledgers` has 56 rows, so the impact is small today. |
| **Fix approach** | None in this pass; a searchable remote dropdown is a UI decision. If kept, select only `id`, `name`, `code`. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// TdsCertificateController.php:31 — CURRENT (repeated at 109)
        $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "Ledger::where"
31:        $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
109:        $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
> mysql -u root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_ledgers;"
56
```

### F10 — Views

clean — `Select-String -Path "Modules\Accounting\resources\views\tds-certificate\show.blade.php","Modules\Accounting\resources\views\tds-certificate\edit.blade.php","Modules\Accounting\resources\views\tds-certificate\trash.blade.php" -Pattern "Model::|DB::|->get\(\)|->count\(\)|->where\(|\{!!"` → no output. The three existing blades render no queries and no unescaped user text. (The missing create blade is TDSC-15, recorded under F6 because the defect is the dead route.)

### F11 — Security and tenancy

#### TDSC-19 · H · TEN-03 — The creator relation reads the central user table, so the show page attributes the wrong person

| Field | Value |
|---|---|
| **Rule** | TEN-03 (H) — *central models reached from tenant context must not be queried as if they were tenant data; the wrong connection returns another tenant's row* |
| **Where** | `Modules/Accounting/app/Models/TdsCertificate.php:55-58`; `Modules/Prime/app/Models/User.php:37, 43`; tenant `sys_users` |
| **Root cause** | `creator()` points at `Modules\Prime\Models\User`, which pins `$connection = 'mysql'` (the central database). The `created_by` FK points at the tenant `sys_users` table. Every other Accounting model uses `Modules\SchoolSetup\Models\User`, whose connection follows tenancy. |
| **Consequence** | The show page resolves the tenant user id against the central `sys_users` table: for certificate 1 it displays "Super Admin" (central id 1) instead of the tenant's "Root User" (tenant id 1), or "System" when that id does not exist centrally. The record is attributed to the wrong person and to another database. |
| **Reproduce** | Open `/accounting/tds-certificate/1` as Super Admin. Created By shows "Super Admin"; the tenant row `created_by = 1` is "Root User". |
| **Fix approach** | Point `creator()` at `Modules\SchoolSetup\Models\User`. |
| **Plan item** | TDSC-19 in `02-fix-plan.md` §5 |

```php
// TdsCertificate.php:55-58 — CURRENT
    public function creator(): BelongsTo
    {
        return $this->belongsTo(\Modules\Prime\Models\User::class, 'created_by');
    }
```

**Evidence**
```
> Select-String -Path "Modules\Prime\app\Models\User.php" -SimpleMatch "protected `$connection = 'mysql';"
43:    protected $connection = 'mysql';
> Select-String -Path "Modules\SchoolSetup\app\Models\User.php" -SimpleMatch "protected `$table = 'sys_users';"
46:    protected $table = 'sys_users';
> mysql -u root -N -e "SELECT id,name,email FROM xyz_school_00000000000040008000_202627.sys_users WHERE id=1; SELECT id,name,email FROM prime_db.sys_users WHERE id=1;"
1	Root User	root@tenant.com
1	Super Admin	superadmin@prime.com
```

#### TDSC-20 · H · SEC-05 — Certificate documents are stored on the public disk and old copies are never removed

| Field | Value |
|---|---|
| **Rule** | SEC-05 (H) — *files are served through signed/authorised routes when private; uploads are stored in tenant paths* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:49, 125, 177-182`; `Modules/Accounting/resources/views/tds-certificate/edit.blade.php:134` |
| **Root cause** | Uploads go to the `public` disk under `accounting/tds-certificates`, and the edit view previews the file with a direct `asset()` URL. The public disk is a shared storage root across tenants, and a replaced or force-deleted document is never deleted. |
| **Consequence** | Anyone who knows the URL can download a TDS certificate without authentication; because the public root is shared, the same path is served under every tenant host. Superseded documents remain downloadable forever. |
| **Reproduce** | Static today: no certificate has a document (`media_id` is NULL). Once one is uploaded, copy the preview URL from the edit page into a private browser window; it downloads without login. |
| **Fix approach** | Store new files on the private `local` disk, download through the authorised controller route, delete the old media after replacement and after force-delete, and remove the direct public preview. |
| **Plan item** | TDSC-01 (disk and replacement cleanup), TDSC-22 (force-delete cleanup), TDSC-20 in `02-fix-plan.md` §1 |

```php
// store() and update() — CURRENT
                $storedPath = $file->store('accounting/tds-certificates', 'public');

// downloadCertificate():177-178 — CURRENT
        if ($storedPath && Storage::disk('public')->exists($storedPath)) {
            return Storage::disk('public')->download($storedPath, $media->file_name);
        }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "store\('accounting/tds-certificates'|Storage::disk\('public'\)"
49:                $storedPath = $file->store('accounting/tds-certificates', 'public');
125:                $storedPath = $file->store('accounting/tds-certificates', 'public');
177:        if ($storedPath && Storage::disk('public')->exists($storedPath)) {
178:            return Storage::disk('public')->download($storedPath, $media->file_name);
> Select-String -Path "Modules\Accounting\resources\views\tds-certificate\edit.blade.php" -Pattern "asset\('storage"
134:                                            image="{{ $tdsCertificate->media ? asset('storage/' . ($tdsCertificate->media->custom_properties['stored_path'] ?? '')) : '' }}"
```

### F12 — Style

#### TDSC-21 · L · STY-02 — Pint fails on all three in-scope PHP files

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines between imports* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php`, `Modules/Accounting/app/Models/TdsCertificate.php`, `Modules/Accounting/app/Http/Requests/TdsCertificateRequest.php` |
| **Root cause** | The files were not formatted with the project's Pint preset. The model also carries an unused `use App\Models\BaseModel;` import. |
| **Consequence** | Style drift and a failing Pint gate; no runtime effect. |
| **Reproduce** | Run `vendor\bin\pint --test <the three files> --format agent`. |
| **Fix approach** | Run Pint on the three files only (never `--dirty`). |
| **Plan item** | TDSC-21 in `02-fix-plan.md` §8 |

```php
// TdsCertificate.php:5-9 — CURRENT
namespace Modules\Accounting\Models;

use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
```

**Evidence**
```
> vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" "Modules\Accounting\app\Models\TdsCertificate.php" "Modules\Accounting\app\Http\Requests\TdsCertificateRequest.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\TdsCertificateController.php","fixers":["fully_qualified_strict_types","concat_space","unary_operator_spaces","not_operator_with_successor_space","ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Models\\TdsCertificate.php","fixers":["fully_qualified_strict_types","method_chaining_indentation","no_unused_imports","ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Http\\Requests\\TdsCertificateRequest.php","fixers":["function_declaration","ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1. Wrong data? | 2. Delete before replacement? | 3. Duplicate implementation? | 4. Soft-delete × unique? | 5. Race? | 6. Authorization hole? | 7. Message lies? | 8. Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | TDSC-20 | TDSC-12 | TDSC-08 | ok | TDSC-06 | ok | ok |
| `update` | ok | TDSC-20 | TDSC-12 | TDSC-08 | ok | TDSC-06 | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | TDSC-06 | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | TDSC-06 | ok | ok |
| `restore` | ok | ok | ok | ok | ok | TDSC-06 | ok | ok |
| `forceDelete` | TDSC-22 | TDSC-20 | ok | ok | ok | TDSC-06 | ok | ok |

#### TDSC-22 · H · CTL-06 — Permanently deleting a used certificate is an unguarded 500

| Field | Value |
|---|---|
| **Rule** | CTL-06 (H, raised from M because the only certificate in the live tenant is referenced and the delete path always 500s) — *business rules live in the controller/service layer, not in the database alone* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php:278-303`; `database/migrations/tenant/2026_09_16_100067_create_acc_tds_deductions_table.php:68` |
| **Root cause** | `forceDelete()` calls `$model->forceDelete()` with no check for dependent `acc_tds_deductions`. The foreign key `fk_acc_tdsded_cert` is `restrictOnDelete()`, so the database rejects the delete. |
| **Consequence** | A user who trashes a certificate that has a TDS deduction and then permanently deletes it gets a raw SQL integrity-constraint error (via TDSC-01) instead of a business message; the certificate remains. |
| **Reproduce** | Trash certificate 1, open `/accounting/tds-certificate/trash/view`, click Delete. Live data has 1 deduction referencing it, so the request fails with a QueryException. |
| **Fix approach** | Check `TdsDeduction::where('tds_certificate_id', …)->exists()` and throw `\DomainException` with a fixed message; run the delete in `DB::transaction()` and remove the media after commit. |
| **Plan item** | TDSC-22 in `02-fix-plan.md` §1 |

```php
// TdsCertificateController.php:282-286 — CURRENT
        DB::beginTransaction();
        try {
            $model = TdsCertificate::withTrashed()->findOrFail($id);
            $certNo = $model->certificate_no;
            $model->forceDelete();
```

**Evidence**
```
> Select-String -Path "database\migrations\tenant\2026_09_16_100067_create_acc_tds_deductions_table.php" -Pattern "fk_acc_tdsded_cert"
68:            $table->foreign('tds_certificate_id', 'fk_acc_tdsded_cert')->references('id')->on('acc_tds_certificates')->restrictOnDelete();
> mysql -u root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_tds_deductions; SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_tds_deductions d JOIN xyz_school_00000000000040008000_202627.acc_tds_certificates c ON c.id=d.tds_certificate_id;"
1
1
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/resources/views/pages/partials/tds-management/_tds-certificates.blade.php` | The list tab, create modal, filters and export button are rendered by `AccDashboardController`, which is `CLAIMED` and not audited here. The tab's create button bypasses the routed `create()` page. | VIEW / CTL | `gaurav/Accounting/AccDashboardController` |
| `config/permissionslist.php` | No `accounting.tds-certificate` key. Shared config; changing it is a DECISION and a permission sync is Tarun's hand. | AUTH-01 | Tarun / TDSC-06 |
| `Modules/Accounting/routes/web.php` | `restore` is registered as GET. Shared route file; changing it is a ⚠ SHARED item. | RTE-01 | TDSC-11 |
| `Modules/Prime/app/Models/User.php` | Pins `$connection = 'mysql'` (central). This is correct for the central app; the defect is that `TdsCertificate::creator()` uses it. | TEN-03 | TDSC-19 (our model) |
| `app/Models/TenantMedia.php` | Shared media model; the controller creates rows manually instead of going through a media service. No defect found in the model itself. | — | — |

## 8. Not covered, and why

- **Scanner and self-check were skipped.** `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are missing from this checkout, and the tooling override forbids running `scan.php`. F1-F13 were therefore worked manually with `read`, `Select-String`, `php -l`, `pint --test` and direct MySQL probes. The §15 self-check could not be executed.
- **No tests were run (D4).** The browser flows for store/update/restore/force-delete are described from source and live data, not executed.
- **The public-file exposure was proven statically.** The only live certificate has no `media_id`, so there was no unauthenticated download to perform. The disk and URL construction are proven from source.
- **The list tab and the dashboard controller are out of scope.** `_tds-certificates.blade.php` belongs to the `AccDashboardController` report (CLAIMED).
- **`TdsDeduction`, `Ledger`, `TenantMedia`, `BaseAccountingModel` and `AccountingContext` were linked, not re-audited.** Their reports are listed in §3. `TdsDeduction` is used only by the proposed TDSC-22 guard.
- **Permission seeding was not run.** The counts in TDSC-06 come from the live tenant database, not from a seeder run. Seeding and role grants are Tarun's hand.
