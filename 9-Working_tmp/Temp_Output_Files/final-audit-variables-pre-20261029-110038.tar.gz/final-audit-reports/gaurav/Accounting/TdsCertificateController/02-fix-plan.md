# Fix Plan — Accounting / TdsCertificateController

**From:** `01-report.md` (2026-10-22) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | route file — ⚠ SHARED, touched only by TDSC-11 |
| `config/permissionslist.php` | ⚠ SHARED config — touched only by TDSC-06 |
| `Modules/Accounting/resources/views/pages/partials/tds-management/_tds-certificates.blade.php` | owned by the `AccDashboardController` report |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | owned by another report |
| `Modules/Accounting/app/Models/Ledger.php` | owned by the `LedgerController` report |
| `app/Models/TenantMedia.php` | owned by `tarun/SystemConfig-done/TenantMediaStoreController` |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | owned by the `AccountingStatusMasterController` report |
| `Modules/Accounting/app/Services/AccountingContext.php` | owned by the `AccountGroupController` report |
| `Modules/Accounting/app/Models/TdsDeduction.php` | owned by the `TdsDeductionController` report — referenced by TDSC-22 only |
| `database/migrations/**` | never edit an existing migration |
| `resources/views/components/**` (`x-backend.*`, `x-tenantcore.*`) | common components |

## 1. Blockers reachable today

- [ ] **TDSC-01** · B · ERR-01 · `TdsCertificateController.php:20-276` — remove every `try/catch`, every manual transaction and every `$e->getMessage()`; use `DB::transaction()` and one media helper. This one item also resolves **TDSC-02 (restore half), TDSC-03, TDSC-04, TDSC-05 (five methods), TDSC-07, TDSC-12, TDSC-14**, and the disk/replacement half of **TDSC-20**. `forceDelete()` is rewritten by TDSC-22 and is deliberately not part of this item.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php`
  - **Before — imports (`TdsCertificateController.php:7-16`):**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use App\Models\TenantMedia;
    use Illuminate\Support\Facades\Storage;
    use Modules\Accounting\Http\Requests\TdsCertificateRequest;
    use Modules\Accounting\Models\TdsCertificate;
    use Modules\Accounting\Models\Ledger;
    ```
  - **After — imports:**
    ```php
    use App\Http\Controllers\Controller;
    use App\Models\TenantMedia;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\Support\Facades\Storage;
    use Illuminate\View\View;
    use Modules\Accounting\Http\Requests\TdsCertificateRequest;
    use Modules\Accounting\Models\Ledger;
    use Modules\Accounting\Models\TdsCertificate;
    use Symfony\Component\HttpFoundation\StreamedResponse;
    ```
    > `Log` stays imported because the untouched `forceDelete()` still uses it until TDSC-22 lands; Pint removes it once it is truly unused.
  - **Before — `index()` and `create()` (`TdsCertificateController.php:20-34`):**
    ```php
        public function index()
        {
            Gate::authorize('tenant.accounting.tds-certificate.viewAny');

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-certificates']);
        }

        public function create()
        {
            Gate::authorize('tenant.accounting.tds-certificate.create');

            $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();

            return view('accounting::tds-certificate.create', compact('partyLedgers'));
        }
    ```
  - **After — `index()` and `create()`:**
    ```php
        public function index(): RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-certificate.viewAny');

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-certificates']);
        }

        public function create(): View
        {
            Gate::authorize('tenant.accounting.tds-certificate.create');

            $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();

            return view('accounting::tds-certificate.create', compact('partyLedgers'));
        }
    ```
  - **Before — `store()` (`TdsCertificateController.php:36-93`):**
    ```php
        public function store(TdsCertificateRequest $request)
        {
            Gate::authorize('tenant.accounting.tds-certificate.create');

            $validated = $request->validated();

            DB::beginTransaction();
            try {
                $validated['created_by'] = auth()->id();

                // Handle Certificate Document Upload
                if ($request->hasFile('certificate_file')) {
                    $file = $request->file('certificate_file');
                    $storedPath = $file->store('accounting/tds-certificates', 'public');

                    $media = TenantMedia::create([
                        'model_type'        => TdsCertificate::class,
                        'model_id'          => 0,
                        'collection_name'   => 'tds_certificates',
                        'name'              => pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME),
                        'file_name'         => $file->getClientOriginalName(),
                        'mime_type'         => $file->getClientMimeType(),
                        'disk'              => 'public',
                        'size'              => $file->getSize(),
                        'manipulations'     => [],
                        'custom_properties' => ['stored_path' => $storedPath],
                        'responsive_images' => [],
                    ]);
                    $validated['media_id'] = $media->id;
                }

                $certificate = TdsCertificate::create($validated);

                if (isset($media)) {
                    $media->update(['model_id' => $certificate->id]);
                }

                activityLog($certificate, 'Created', [
                    'message'        => 'TDS Certificate created: ' . $certificate->certificate_no,
                    'certificate_no' => $certificate->certificate_no,
                    'section_code'   => $certificate->section_code,
                    'performed_by'   => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.tds', ['tab' => 'tds-certificates'])
                    ->with('success', 'TDS Certificate created successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to create TDS Certificate', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString(),
                ]);

                return back()->withInput()->with('error', 'Failed to create TDS Certificate: ' . $e->getMessage());
            }
        }
    ```
  - **After — `store()`:**
    ```php
        public function store(TdsCertificateRequest $request): RedirectResponse
        {
            $validated = $request->validated();
            $validated['created_by'] = auth()->id();

            DB::transaction(function () use ($request, $validated): void {
                $certificate = TdsCertificate::create($validated);

                $this->storeCertificateMedia($request, $certificate);

                activityLog($certificate, 'Created', [
                    'message'        => 'TDS Certificate created: ' . $certificate->certificate_no,
                    'certificate_no' => $certificate->certificate_no,
                    'section_code'   => $certificate->section_code,
                    'performed_by'   => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-certificates'])
                ->with('success', 'TDS Certificate created successfully.');
        }
    ```
  - **Before — `show()` and `edit()` (`TdsCertificateController.php:95-112`):**
    ```php
        public function show(TdsCertificate $tdsCertificate)
        {
            Gate::authorize('tenant.accounting.tds-certificate.view');

            $tdsCertificate->load(['partyLedger', 'creator', 'media']);

            return view('accounting::tds-certificate.show', compact('tdsCertificate'));
        }

        public function edit(TdsCertificate $tdsCertificate)
        {
            Gate::authorize('tenant.accounting.tds-certificate.update');

            $tdsCertificate->loadMissing('media');
            $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();

            return view('accounting::tds-certificate.edit', compact('tdsCertificate', 'partyLedgers'));
        }
    ```
  - **After — `show()` and `edit()`:**
    ```php
        public function show(TdsCertificate $tdsCertificate): View
        {
            Gate::authorize('tenant.accounting.tds-certificate.view');

            $tdsCertificate->load(['partyLedger', 'creator', 'media']);

            return view('accounting::tds-certificate.show', compact('tdsCertificate'));
        }

        public function edit(TdsCertificate $tdsCertificate): View
        {
            Gate::authorize('tenant.accounting.tds-certificate.update');

            $tdsCertificate->loadMissing('media');
            $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();

            return view('accounting::tds-certificate.edit', compact('tdsCertificate', 'partyLedgers'));
        }
    ```
  - **Before — `update()` (`TdsCertificateController.php:114-164`):**
    ```php
        public function update(TdsCertificateRequest $request, TdsCertificate $tdsCertificate)
        {
            Gate::authorize('tenant.accounting.tds-certificate.update');

            DB::beginTransaction();
            try {
                $validated = $request->validated();

                // Handle replacement document upload
                if ($request->hasFile('certificate_file')) {
                    $file = $request->file('certificate_file');
                    $storedPath = $file->store('accounting/tds-certificates', 'public');

                    $media = TenantMedia::create([
                        'model_type'        => TdsCertificate::class,
                        'model_id'          => $tdsCertificate->id,
                        'collection_name'   => 'tds_certificates',
                        'name'              => pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME),
                        'file_name'         => $file->getClientOriginalName(),
                        'mime_type'         => $file->getClientMimeType(),
                        'disk'              => 'public',
                        'size'              => $file->getSize(),
                        'manipulations'     => [],
                        'custom_properties' => ['stored_path' => $storedPath],
                        'responsive_images' => [],
                    ]);
                    $validated['media_id'] = $media->id;
                }

                $tdsCertificate->update($validated);

                activityLog($tdsCertificate, 'Updated', [
                    'message'        => 'TDS Certificate updated: ' . $tdsCertificate->certificate_no,
                    'certificate_no' => $tdsCertificate->certificate_no,
                    'performed_by'   => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.tds', ['tab' => 'tds-certificates'])
                    ->with('success', 'TDS Certificate updated successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to update TDS Certificate', [
                    'id'    => $tdsCertificate->id,
                    'error' => $e->getMessage(),
                ]);

                return back()->withInput()->with('error', 'Failed to update TDS Certificate: ' . $e->getMessage());
            }
        }
    ```
  - **After — `update()`:**
    ```php
        public function update(TdsCertificateRequest $request, TdsCertificate $tdsCertificate): RedirectResponse
        {
            $previousMedia = $tdsCertificate->media;
            $validated = $request->validated();

            DB::transaction(function () use ($request, $validated, $tdsCertificate): void {
                $tdsCertificate->update($validated);

                $this->storeCertificateMedia($request, $tdsCertificate);

                activityLog($tdsCertificate, 'Updated', [
                    'message'        => 'TDS Certificate updated: ' . $tdsCertificate->certificate_no,
                    'certificate_no' => $tdsCertificate->certificate_no,
                    'performed_by'   => auth()->id(),
                ]);
            });

            if ($previousMedia !== null && (int) $previousMedia->getKey() !== (int) $tdsCertificate->media_id) {
                $storedPath = $previousMedia->custom_properties['stored_path'] ?? null;

                if ($storedPath !== null) {
                    Storage::disk($previousMedia->disk ?? 'local')->delete($storedPath);
                }

                $previousMedia->delete();
            }

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-certificates'])
                ->with('success', 'TDS Certificate updated successfully.');
        }
    ```
  - **Before — `downloadCertificate()` (`TdsCertificateController.php:166-186`):**
    ```php
        public function downloadCertificate(TdsCertificate $tdsCertificate)
        {
            Gate::authorize('tenant.accounting.tds-certificate.view');

            $tdsCertificate->loadMissing('media');
            $media = $tdsCertificate->media;
            if (! $media) {
                return back()->with('error', 'No certificate document is attached to this record.');
            }

            $storedPath = $media->custom_properties['stored_path'] ?? null;
            if ($storedPath && Storage::disk('public')->exists($storedPath)) {
                return Storage::disk('public')->download($storedPath, $media->file_name);
            }

            if (! empty($media->file_name) && Storage::disk($media->disk ?? 'public')->exists($media->file_name)) {
                return Storage::disk($media->disk ?? 'public')->download($media->file_name, $media->file_name);
            }

            return back()->with('error', 'Certificate file could not be found in storage.');
        }
    ```
  - **After — `downloadCertificate()`:**
    ```php
        public function downloadCertificate(TdsCertificate $tdsCertificate): StreamedResponse|RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-certificate.view');

            $tdsCertificate->loadMissing('media');
            $media = $tdsCertificate->media;
            if (! $media) {
                return back()->with('error', 'No certificate document is attached to this record.');
            }

            $disk = $media->disk ?? 'local';
            $storedPath = $media->custom_properties['stored_path'] ?? null;
            if ($storedPath !== null && Storage::disk($disk)->exists($storedPath)) {
                return Storage::disk($disk)->download($storedPath, $media->file_name);
            }

            if (! empty($media->file_name) && Storage::disk($disk)->exists($media->file_name)) {
                return Storage::disk($disk)->download($media->file_name, $media->file_name);
            }

            return back()->with('error', 'Certificate file could not be found in storage.');
        }
    ```
  - **Before — `destroy()` (`TdsCertificateController.php:188-212`):**
    ```php
        public function destroy(TdsCertificate $tdsCertificate)
        {
            Gate::authorize('tenant.accounting.tds-certificate.delete');

            DB::beginTransaction();
            try {
                $tdsCertificate->delete();

                activityLog($tdsCertificate, 'Deleted', [
                    'message'        => 'TDS Certificate moved to trash: ' . $tdsCertificate->certificate_no,
                    'certificate_no' => $tdsCertificate->certificate_no,
                    'performed_by'   => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.tds', ['tab' => 'tds-certificates'])
                    ->with('success', 'TDS Certificate moved to trash.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to delete TDS Certificate', ['id' => $tdsCertificate->id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to delete TDS Certificate: ' . $e->getMessage());
            }
        }
    ```
  - **After — `destroy()`:**
    ```php
        public function destroy(TdsCertificate $tdsCertificate): RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-certificate.delete');

            DB::transaction(function () use ($tdsCertificate): void {
                $tdsCertificate->delete();

                activityLog($tdsCertificate, 'Deleted', [
                    'message'        => 'TDS Certificate moved to trash: ' . $tdsCertificate->certificate_no,
                    'certificate_no' => $tdsCertificate->certificate_no,
                    'performed_by'   => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-certificates'])
                ->with('success', 'TDS Certificate moved to trash.');
        }
    ```
  - **Before — `toggleStatus()` (`TdsCertificateController.php:214-240`):**
    ```php
        public function toggleStatus(Request $request, TdsCertificate $tdsCertificate)
        {
            Gate::authorize('tenant.accounting.tds-certificate.update');

            $request->validate(['is_active' => 'required|boolean']);

            DB::beginTransaction();
            try {
                $tdsCertificate->is_active = $request->input('is_active');
                $tdsCertificate->save();

                activityLog($tdsCertificate, 'Toggled', [
                    'message'        => 'TDS Certificate status toggled: ' . $tdsCertificate->certificate_no,
                    'certificate_no' => $tdsCertificate->certificate_no,
                    'performed_by'   => auth()->id(),
                ]);

                DB::commit();

                return response()->json(['success' => true, 'is_active' => $tdsCertificate->is_active, 'message' => 'Status updated.']);
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to toggle TDS Certificate status', ['id' => $tdsCertificate->id, 'error' => $e->getMessage()]);

                return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
            }
        }
    ```
  - **After — `toggleStatus()`:**
    ```php
        public function toggleStatus(Request $request, TdsCertificate $tdsCertificate): JsonResponse
        {
            Gate::authorize('tenant.accounting.tds-certificate.update');

            $request->validate(['is_active' => 'required|boolean']);

            DB::transaction(function () use ($request, $tdsCertificate): void {
                $tdsCertificate->is_active = $request->boolean('is_active');
                $tdsCertificate->save();

                activityLog($tdsCertificate, 'Toggled', [
                    'message'        => 'TDS Certificate status toggled: ' . $tdsCertificate->certificate_no,
                    'certificate_no' => $tdsCertificate->certificate_no,
                    'performed_by'   => auth()->id(),
                ]);
            });

            return response()->json(['success' => true, 'is_active' => $tdsCertificate->is_active, 'message' => 'Status updated.']);
        }
    ```
  - **Before — `restore()` (`TdsCertificateController.php:251-276`):**
    ```php
        public function restore($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-certificate.restore');

            DB::beginTransaction();
            try {
                $model = TdsCertificate::onlyTrashed()->findOrFail($id);
                $model->restore();
                $model->update(['is_active' => true]);

                activityLog($model, 'Restored', [
                    'message'        => 'TDS Certificate restored: ' . $model->certificate_no,
                    'certificate_no' => $model->certificate_no,
                    'performed_by'   => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.tds-certificate.trashed')->with('success', 'TDS Certificate restored successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to restore TDS Certificate', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to restore TDS Certificate: ' . $e->getMessage());
            }
        }
    ```
  - **After — `restore()` plus the new private media helper (append both after `restore()`):**
    ```php
        public function restore($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-certificate.restore');

            $model = TdsCertificate::onlyTrashed()->findOrFail($id);

            DB::transaction(function () use ($model): void {
                $model->restore();
                $model->update(['is_active' => true]);

                activityLog($model, 'Restored', [
                    'message'        => 'TDS Certificate restored: ' . $model->certificate_no,
                    'certificate_no' => $model->certificate_no,
                    'performed_by'   => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.tds-certificate.trashed')->with('success', 'TDS Certificate restored successfully.');
        }

        private function storeCertificateMedia(Request $request, TdsCertificate $certificate): void
        {
            if (! $request->hasFile('certificate_file')) {
                return;
            }

            $file = $request->file('certificate_file');
            $storedPath = $file->store('accounting/tds-certificates', 'local');

            $media = TenantMedia::create([
                'model_type'        => TdsCertificate::class,
                'model_id'          => $certificate->id,
                'collection_name'   => 'tds_certificates',
                'name'              => pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME),
                'file_name'         => $file->getClientOriginalName(),
                'mime_type'         => $file->getClientMimeType(),
                'disk'              => 'local',
                'size'              => $file->getSize(),
                'manipulations'     => [],
                'custom_properties' => ['stored_path' => $storedPath],
                'responsive_images' => [],
            ]);

            $certificate->update(['media_id' => $media->id]);
        }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "beginTransaction|catch \(|getMessage|Log::error"`
  - **Expect:** no output between lines 1 and 276 (the only remaining occurrences are in `forceDelete()`, cleared by TDSC-22).
  - **Effort:** L

- [ ] **TDSC-22** · H · CTL-06 · `TdsCertificateController.php:278-303` — guard the permanent delete against dependent deductions, then rewrite it to the D1 idiom.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php`
  - **Before** (`TdsCertificateController.php:278-303`):
    ```php
        public function forceDelete($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-certificate.forceDelete');

            DB::beginTransaction();
            try {
                $model = TdsCertificate::withTrashed()->findOrFail($id);
                $certNo = $model->certificate_no;
                $model->forceDelete();

                activityLog($model, 'Deleted', [
                    'message'        => 'TDS Certificate permanently deleted: ' . $certNo,
                    'certificate_no' => $certNo,
                    'performed_by'   => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.tds-certificate.trashed')->with('success', 'TDS Certificate permanently deleted.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to force delete TDS Certificate', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to delete TDS Certificate: ' . $e->getMessage());
            }
        }
    ```
  - **After:**
    ```php
        public function forceDelete($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-certificate.forceDelete');

            $certificate = TdsCertificate::withTrashed()->findOrFail($id);

            if (\Modules\Accounting\Models\TdsDeduction::where('tds_certificate_id', $certificate->id)->exists()) {
                throw new \DomainException('This certificate is used by a TDS deduction and cannot be permanently deleted.');
            }

            $certificateNo = $certificate->certificate_no;
            $media = $certificate->media;

            DB::transaction(function () use ($certificate, $certificateNo): void {
                $certificate->forceDelete();

                activityLog($certificate, 'Deleted', [
                    'message'        => 'TDS Certificate permanently deleted: ' . $certificateNo,
                    'certificate_no' => $certificateNo,
                    'performed_by'   => auth()->id(),
                ]);
            });

            if ($media !== null) {
                $storedPath = $media->custom_properties['stored_path'] ?? null;

                if ($storedPath !== null) {
                    Storage::disk($media->disk ?? 'local')->delete($storedPath);
                }

                $media->delete();
            }

            return redirect()->route('accounting.tds-certificate.trashed')->with('success', 'TDS Certificate permanently deleted.');
        }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "TdsDeduction|DomainException"`
  - **Expect:** two lines: the `TdsDeduction` guard and the `DomainException` throw. No `beginTransaction`, `catch (`, `getMessage` or `Log::error` remains in `forceDelete()`.
  - **Effort:** S

- [ ] **TDSC-20** · H · SEC-05 · `edit.blade.php:130-136` — stop exposing the certificate document through a direct public `asset()` URL.
  - **Touches:** `Modules/Accounting/resources/views/tds-certificate/edit.blade.php`
  - **Before** (`edit.blade.php:130-136`):
    ```blade
                                        <x-backend.form.image-with-preview
                                            name="certificate_file"
                                            id="tc_certificate_file"
                                            label="Upload / Replace Certificate Document (PDF, Image)"
                                            image="{{ $tdsCertificate->media ? asset('storage/' . ($tdsCertificate->media->custom_properties['stored_path'] ?? '')) : '' }}"
                                            accept=".pdf,image/*"
                                        />
    ```
  - **After:**
    ```blade
                                        <x-backend.form.image-with-preview
                                            name="certificate_file"
                                            id="tc_certificate_file"
                                            label="Upload / Replace Certificate Document (PDF, Image)"
                                            image=""
                                            accept=".pdf,image/*"
                                        />
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\resources\views\tds-certificate\edit.blade.php" -Pattern "asset\('storage"`
  - **Expect:** no output. The existing "Download Attached Certificate" button stays and goes through the authorised route.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

Apply these before TDSC-06 unlocks the screen for the four accounting roles.

- [ ] **TDSC-08** · H · VAL-04 · `TdsCertificateRequest.php:26-34` — make the certificate-number uniqueness rule match the real unique index, including trashed rows.
  - **Touches:** `Modules/Accounting/app/Http/Requests/TdsCertificateRequest.php`
  - **Before** (`TdsCertificateRequest.php:26-34`):
    ```php
                'certificate_no'   => [
                    'required',
                    'string',
                    'max:50',
                    Rule::unique('acc_tds_certificates', 'certificate_no')
                        ->where(fn($q) => $q->where('party_ledger_id', $this->input('party_ledger_id'))->where('section_code', $this->input('section_code')))
                        ->ignore($id)
                        ->withoutTrashed(),
                ],
    ```
  - **After:**
    ```php
                'certificate_no'   => [
                    'required',
                    'string',
                    'max:50',
                    Rule::unique('acc_tds_certificates', 'certificate_no')
                        ->where(fn($q) => $q->where('party_ledger_id', $this->input('party_ledger_id'))->where('section_code', $this->input('section_code')))
                        ->ignore($id),
                ],
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\TdsCertificateRequest.php" -Pattern "withoutTrashed"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **TDSC-09** · H · VAL-07 · `TdsCertificateRequest.php:41-42` — reject a consumed amount above the ceiling before the database CHECK does it.
  - **Touches:** `Modules/Accounting/app/Http/Requests/TdsCertificateRequest.php`
  - **Before — imports (`TdsCertificateRequest.php:7-9`):**
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Validation\Rule;
    ```
  - **After — imports:**
    ```php
    use Closure;
    use Illuminate\Foundation\Http\FormRequest;
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Validation\Rule;
    ```
  - **Before** (`TdsCertificateRequest.php:41-42`):
    ```php
                'limit_amount'     => ['nullable', 'numeric', 'min:0'],
                'consumed_amount'  => ['nullable', 'numeric', 'min:0'],
    ```
  - **After:**
    ```php
                'limit_amount'     => ['nullable', 'numeric', 'min:0'],
                'consumed_amount'  => ['nullable', 'numeric', 'min:0', function (string $attribute, mixed $value, Closure $fail): void {
                    $limit = $this->input('limit_amount');

                    if ($limit !== null && $limit !== '' && (float) $value > (float) $limit) {
                        $fail('The consumed amount may not be greater than the limit amount.');
                    }
                }],
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\TdsCertificateRequest.php" -Pattern "may not be greater than the limit"`
  - **Expect:** one line containing the new message.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

No separate items. TDSC-01 rewrites five mutations; TDSC-22 rewrites the sixth. Together they resolve TDSC-02, TDSC-03, TDSC-04 and TDSC-05.

## 4. Authorization (F3)

- [ ] **TDSC-06** · B · DECISION · AUTH-01 — the `tenant.accounting.tds-certificate.*` namespace is absent from `config/permissionslist.php` and from the live tenant, so only Super Admin can reach the screen.
  - **Why it is a decision:** it adds a new permission key and needs a permission sync plus role grants; both are Tarun's hand (`/system-config/sync-permissions`).
  - (a) ⭐ Add `'accounting.tds-certificate' => $crud,` beside `'accounting.tax-rate' => $crud,` at `config/permissionslist.php:614`, run the sync, then grant the eight new keys to School Admin, Management, Account Staff and Account Manager.
  - (b) Grant the existing `tenant.accounting.dashboard.*` keys to those roles and leave the controller literals unchanged. This makes the screen reachable but leaves the dead namespace in code.
  - (c) Leave as is and record the feature as Super-Admin-only.
  - ➜ Choice: ____

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **TDSC-10** · M · VAL-05 · `TdsCertificateRequest.php:72` — let an unchecked Active Record checkbox stay false.
  - **Touches:** `Modules/Accounting/app/Http/Requests/TdsCertificateRequest.php`
  - **Before** (`TdsCertificateRequest.php:72`):
    ```php
                'is_active'       => $this->boolean('is_active', true),
    ```
  - **After:**
    ```php
                'is_active'       => $this->boolean('is_active'),
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\TdsCertificateRequest.php" -Pattern "boolean\('is_active'"`
  - **Expect:** one line with no second argument.
  - **Effort:** S

- [ ] **TDSC-11** · H · RTE-01 · `routes/web.php:457` + `trash.blade.php:38-40` — restore over POST with CSRF instead of GET. ⚠ SHARED
  - **Touches:** `Modules/Accounting/routes/web.php`, `Modules/Accounting/resources/views/tds-certificate/trash.blade.php`
  - **Before — route (`web.php:457`):**
    ```php
    Route::get('/tds-certificate/{id}/restore', [TdsCertificateController::class, 'restore'])->name('tds-certificate.restore');
    ```
  - **After — route:**
    ```php
    Route::post('/tds-certificate/{id}/restore', [TdsCertificateController::class, 'restore'])->name('tds-certificate.restore');
    ```
  - **Before — view (`trash.blade.php:38-40`):**
    ```blade
                                            <a href="{{ route('accounting.tds-certificate.restore', $cert->id) }}" class="btn btn-sm btn-outline-success">
                                                <i class="fa-solid fa-rotate-left me-1"></i> Restore
                                            </a>
    ```
  - **After — view:**
    ```blade
                                            <form action="{{ route('accounting.tds-certificate.restore', $cert->id) }}" method="POST" class="d-inline">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-outline-success">
                                                    <i class="fa-solid fa-rotate-left me-1"></i> Restore
                                                </button>
                                            </form>
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "tds-certificate/\{id\}/restore"`
  - **Expect:** a POST route line for the same URI and no GET line.
  - **Effort:** S

- [ ] **TDSC-16** · M · MDL-02 · `TdsCertificate.php:34-41` — cast the two enum columns.
  - **Touches:** `Modules/Accounting/app/Models/TdsCertificate.php`
  - **Before** (`TdsCertificate.php:34-41`):
    ```php
        protected $casts = [
            'valid_from'       => 'date',
            'valid_to'         => 'date',
            'certified_rate'   => 'decimal:9,4',
            'limit_amount'     => 'decimal:2',
            'consumed_amount'  => 'decimal:2',
            'is_active'        => 'boolean',
        ];
    ```
  - **After:**
    ```php
        protected $casts = [
            'valid_from'       => 'date',
            'valid_to'         => 'date',
            'certified_rate'   => 'decimal:9,4',
            'limit_amount'     => 'decimal:2',
            'consumed_amount'  => 'decimal:2',
            'is_active'        => 'boolean',
            'certificate_type' => 'string',
            'status'           => 'string',
        ];
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Models\TdsCertificate.php" -Pattern "'certificate_type' => 'string'|'status' => 'string'"`
  - **Expect:** two lines in `$casts`.
  - **Effort:** S

- [ ] **TDSC-19** · H · TEN-03 · `TdsCertificate.php:55-58` — point the creator relation at the tenant user model.
  - **Touches:** `Modules/Accounting/app/Models/TdsCertificate.php`
  - **Before** (`TdsCertificate.php:55-58`):
    ```php
        public function creator(): BelongsTo
        {
            return $this->belongsTo(\Modules\Prime\Models\User::class, 'created_by');
        }
    ```
  - **After:**
    ```php
        public function creator(): BelongsTo
        {
            return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'created_by');
        }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Models\TdsCertificate.php" -SimpleMatch "SchoolSetup\Models\User"`
  - **Expect:** one line inside `creator()`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **TDSC-17** · M · QRY-02 · `TdsCertificateController.php:246` — paginate the trash list at the standard 10 with its own page name.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php`
  - **Before** (`TdsCertificateController.php:246`):
    ```php
            $certificates = TdsCertificate::onlyTrashed()->with('partyLedger')->orderBy('certificate_no')->paginate(15);
    ```
  - **After:**
    ```php
            $certificates = TdsCertificate::onlyTrashed()->with('partyLedger')->orderBy('certificate_no')->paginate(10, ['*'], 'trash_page');
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsCertificateController.php" -Pattern "paginate\(10, \['\*'\], 'trash_page'\)"`
  - **Expect:** one line.
  - **Effort:** S

## 7. Views (F10)

No separate items. TDSC-20 covers the only blade defect found.

## 8. Style (F12) — one item per file

- [ ] **TDSC-21** · L · STY-02 — run Pint on the three in-scope PHP files.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TdsCertificateController.php`, `Modules/Accounting/app/Models/TdsCertificate.php`, `Modules/Accounting/app/Http/Requests/TdsCertificateRequest.php`
  - **Before:** `pint --test` reports `fail` for all three (report TDSC-21 in `01-report.md` §6).
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\TdsCertificateController.php Modules\Accounting\app\Models\TdsCertificate.php Modules\Accounting\app\Http\Requests\TdsCertificateRequest.php --format agent` (never `--dirty`).
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\TdsCertificateController.php Modules\Accounting\app\Models\TdsCertificate.php Modules\Accounting\app\Http\Requests\TdsCertificateRequest.php --format agent`
  - **Expect:** `{"tool":"pint","result":"passed"}`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **TDSC-15** · M · DECISION · CTL-10 — `create()` returns a blade that does not exist and no UI links to the route.
  - **Why it is a decision:** removing a route changes reachable URLs (§9.3); adding a full-page form duplicates the list-tab modal.
  - (a) ⭐ Remove the routed create page and keep the modal: change `Route::resource('tds-certificate', TdsCertificateController::class);` at `Modules/Accounting/routes/web.php:461` to `->except(['create'])`, then replace the body of `create()` with `abort(403, 'This page is not routed. Use the create modal on the TDS Management tab.');` and a `NOT ROUTED` comment, per D5. ⚠ SHARED route file.
  - (b) Add `Modules/Accounting/resources/views/tds-certificate/create.blade.php` (copy the modal fields into a page) and link it from the list tab.
  - (c) Leave as is and record the 500 as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TDSC-13 | Cosmetic route-model binding for `restore`/`forceDelete`. The current code is correct; fixing it needs `->withTrashed()` in the shared route file and buys nothing user-visible. Accepted as debt. |
| TDSC-18 | The unbounded ledger dropdown has only 56 rows today. Replacing it with a searchable remote dropdown is a UI decision, not a mechanical fix in this pass. Accepted as debt. |
