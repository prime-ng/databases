# Final Audit — Accounting / TdsPaymentController

**Audited:** 2026-10-23 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php` (359 lines, 13 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/tds?tab=tds-payments` (list tab), `/accounting/tds-payment`, `/accounting/tds-payment/create`, `/accounting/tds-payment/{id}`, `/accounting/tds-payment/{id}/edit`, `/accounting/tds-payment/{id}/receipt`, `/accounting/tds-payment/{id}/toggle-status`, `/accounting/tds-payment/{id}/change-status`, `/accounting/tds-payment/trash/view`, `/accounting/tds-payment/{id}/restore`, `/accounting/tds-payment/{id}/force-delete` |
| Menu path | Accounting → TDS Management → TDS Payments tab |
| Who uses it | No role holds any `tenant.accounting.tds-payment.*` permission: the exact-name count is `0` in `sys_permissions` and `0` grant rows in `sys_role_has_permissions_jnt`. Five roles hold `tenant.accounting.dashboard.view`: Super Admin, School Admin, Management, Account Staff, Account Manager. Only Super Admin reaches this controller, through the `Gate::before` bypass in `app/Providers/AppServiceProvider.php:78-87`. |
| What a user does here | Records a TDS challan payment: financial year, quarter, section, CIN/challan number, BSR code, challan and deposit dates, tax/surcharge/cess/interest/late fee, the bank ledger and payment voucher, the return-filing status, and an optional scanned challan receipt. A user views a payment, edits it, downloads the receipt, toggles active status, changes the workflow status, soft-deletes it to trash, restores it, or permanently deletes it. |
| Tables written | `acc_tds_payments`, `sys_media`, `sys_activity_logs`; `acc_tds_payment_allocations` is cascaded by a permanent delete (TDSP-24) |
| Tables read | `acc_tds_payments`, `acc_ledgers`, `acc_financial_years`, `acc_vouchers`, `sys_media`, `sys_users`, `acc_tds_deductions`, `acc_tds_payment_allocations` |
| Live data | On `xyz_school_00000000000040008000_202627`: `acc_tds_payments` 0 live / 0 trashed; `acc_tds_payment_allocations` 0; `acc_tds_deductions` 0; `acc_ledgers` 10; `acc_financial_years` 1; `acc_vouchers` 2; `sys_media` rows attached to a TDS payment 0. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No, this controller is not production-ready. The single worst finding is TDSP-08: every route authorizes with a `tenant.accounting.tds-payment.*` permission that is not declared in `config/permissionslist.php` and is not seeded, so every role except Super Admin is refused and the whole feature is invisible to them. The next blockers are TDSP-01 (five mutation methods send raw exception text to the user) and TDSP-10 (every edit silently resets the derived `allocated_amount` to zero, which then lets the allocation screen over-allocate the same challan). The controller is small (359 lines), so the fixes are mechanical; rough effort is **M**, about two developer-days, plus the permission sync that only Tarun can run.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 3 | 6 | 8 | 7 | 3 | 24 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TDSP-01, TDSP-02, TDSP-03, TDSP-04, TDSP-05 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | TDSP-06, TDSP-07 | F9 Queries/Perf | TDSP-20, TDSP-21 |
| F3 Authorization | TDSP-08, TDSP-09 | F10 Views | clean |
| F4 Validation | TDSP-10, TDSP-11, TDSP-12 | F11 Security/Tenancy | TDSP-22 |
| F5 Routes | TDSP-13 | F12 Style | TDSP-23 |
| F6 Controller shape | TDSP-14, TDSP-15, TDSP-16, TDSP-17, TDSP-18 | F13 Deep read | TDSP-24 |
| F7 Models | TDSP-19 | | |

Counts add up: F1(5) + F2(2) + F3(2) + F4(3) + F5(1) + F6(5) + F7(1) + F9(2) + F11(1) + F12(1) + F13(1) = 24.

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php` | controller | 359 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/TdsPayment.php` | model | 148 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/TdsPaymentRequest.php` | FormRequest | 107 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/resources/views/tds-payment/edit.blade.php` | view | 256 | this report | ✅ |
| 5 | `Modules/Accounting/resources/views/tds-payment/show.blade.php` | view | 184 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/tds-payment/trash.blade.php` | view | 68 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/tds-payment/create.blade.php` | view | 0 | this report | ❌ file does not exist — see TDSP-15 |
| 8 | `database/migrations/tenant/2026_09_16_100054_create_acc_tds_payments_table.php` | migration (DDL evidence) | 75 | this report | ✅ read-only |
| 9 | `database/migrations/tenant/2026_09_16_100075_create_acc_tds_payment_allocations_table.php` | migration (DDL evidence) | 51 | this report | ✅ read-only |
| 10 | `database/migrations/tenant/2026_09_16_130001_add_soft_deletes_and_is_active_to_accounting_tables.php` | migration (cascade evidence) | 153 | this report | ✅ read-only |
| 11 | `Modules/Accounting/resources/views/pages/partials/tds-management/_tds-payments.blade.php` | list tab and create modal | 479 | ↗ [gaurav/Accounting/AccDashboardController](../AccDashboardController/01-report.md) (CLAIMED) | ↗ linked, out of scope |
| 12 | `Modules/Accounting/app/Models/Ledger.php` | model (dropdown) | 408 | ↗ [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) | ↗ linked |
| 13 | `Modules/Accounting/app/Models/FinancialYear.php` | model (dropdown) | 168 | ↗ [gaurav/Accounting/FinancialYearController](../FinancialYearController/01-report.md) | ↗ linked |
| 14 | `Modules/Accounting/app/Models/Voucher.php` | model (dropdown) | 415 | ↗ [gaurav/Accounting/VoucherController](../VoucherController/01-report.md) | ↗ linked |
| 15 | `Modules/Accounting/app/Models/TdsPaymentAllocation.php` | model (cascade and derived total) | 49 | ↗ [gaurav/Accounting/TdsPaymentAllocationController](../TdsPaymentAllocationController/01-report.md) (CLAIMED) | ↗ linked |
| 16 | `Modules/Accounting/app/Models/TdsDeduction.php` | model (eager load and deduction balance) | 193 | ↗ [gaurav/Accounting/TdsDeductionController](../TdsDeductionController/01-report.md) (CLAIMED) | ↗ linked |
| 17 | `app/Models/TenantMedia.php` | model (media row) | 80 | ↗ [tarun/SystemConfig-done/TenantMediaStoreController](../../../tarun/SystemConfig-done/TenantMediaStoreController/01-report.md) | ↗ linked |
| 18 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | model parent | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 19 | `Modules/Accounting/app/Services/AccountingContext.php` | service used by the model parent | 110 | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 20 | `Modules/Accounting/routes/web.php` | route file | 536 | shared — checked F5 only | ✅ checked only |
| 21 | `config/permissionslist.php` | shared config | 1804 | shared — checked F3 only | ✅ checked only |

No pre-applied files were found for this module.

## 4. Routes

```
GET|HEAD  accounting/tds-payment                                  accounting.tds-payment.index        Modules\Accounting\Http\Controllers\TdsPaymentController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/tds-payment                                  accounting.tds-payment.store        Modules\Accounting\Http\Controllers\TdsPaymentController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-payment/create                           accounting.tds-payment.create       Modules\Accounting\Http\Controllers\TdsPaymentController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-payment/trash/view                       accounting.tds-payment.trashed      Modules\Accounting\Http\Controllers\TdsPaymentController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/tds-payment/{id}/force-delete                accounting.tds-payment.forceDelete  Modules\Accounting\Http\Controllers\TdsPaymentController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-payment/{id}/restore                     accounting.tds-payment.restore      Modules\Accounting\Http\Controllers\TdsPaymentController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-payment/{tds_payment}                    accounting.tds-payment.show         Modules\Accounting\Http\Controllers\TdsPaymentController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/tds-payment/{tds_payment}                    accounting.tds-payment.update       Modules\Accounting\Http\Controllers\TdsPaymentController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/tds-payment/{tds_payment}                    accounting.tds-payment.destroy      Modules\Accounting\Http\Controllers\TdsPaymentController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/tds-payment/{tds_payment}/change-status      accounting.tds-payment.changeStatus Modules\Accounting\Http\Controllers\TdsPaymentController@changeStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-payment/{tds_payment}/edit               accounting.tds-payment.edit         Modules\Accounting\Http\Controllers\TdsPaymentController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tds-payment/{tds_payment}/receipt            accounting.tds-payment.downloadReceipt Modules\Accounting\Http\Controllers\TdsPaymentController@downloadReceipt  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/tds-payment/{tds_payment}/toggle-status      accounting.tds-payment.toggleStatus Modules\Accounting\Http\Controllers\TdsPaymentController@toggleStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none. All 13 public methods appear in the uncached route list above.

Route notes: the custom trash/download/toggle/change routes at `Modules/Accounting/routes/web.php:472-477` sit before `Route::resource` at `:478`. The resource routes bind `{tds_payment}` and the controller argument `$tdsPayment` matches. `restore` and `forceDelete` bind `{id}` as an integer and call `findOrFail()` themselves. `restore` is a GET that writes (TDSP-13). The tenant middleware stack is present on every route.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 23 | GET /accounting/tds-payment | `tenant.accounting.tds-payment.viewAny` | none | none | none | TDSP-08 |
| `create` | 30 | GET /accounting/tds-payment/create | `tenant.accounting.tds-payment.create` | none | none | none | TDSP-08, TDSP-15, TDSP-21 |
| `store` | 41 | POST /accounting/tds-payment | `tenant.accounting.tds-payment.create` (also FormRequest `create`) | controller, manual 47-96 | 'Created' | acc_tds_payments, sys_media, sys_activity_logs | TDSP-01, TDSP-04, TDSP-05, TDSP-06, TDSP-07, TDSP-08, TDSP-09, TDSP-10, TDSP-11, TDSP-14, TDSP-17, TDSP-22 |
| `show` | 106 | GET /accounting/tds-payment/{tds_payment} | `tenant.accounting.tds-payment.view` | none | none | none | TDSP-08 |
| `edit` | 122 | GET /accounting/tds-payment/{tds_payment}/edit | `tenant.accounting.tds-payment.update` | none | none | none | TDSP-08, TDSP-21 |
| `update` | 134 | PUT/PATCH /accounting/tds-payment/{tds_payment} | `tenant.accounting.tds-payment.update` (also FormRequest `update`) | controller, manual 138-183 | 'Updated' | acc_tds_payments, sys_media, sys_activity_logs | TDSP-01, TDSP-04, TDSP-05, TDSP-06, TDSP-07, TDSP-08, TDSP-09, TDSP-10, TDSP-11, TDSP-14, TDSP-17, TDSP-22 |
| `downloadReceipt` | 193 | GET /accounting/tds-payment/{tds_payment}/receipt | `tenant.accounting.tds-payment.view` | none | none | none | TDSP-08, TDSP-22 |
| `destroy` | 215 | DELETE /accounting/tds-payment/{tds_payment} | `tenant.accounting.tds-payment.delete` | controller, manual 219-234 | 'Deleted' | acc_tds_payments, sys_activity_logs | TDSP-01, TDSP-03, TDSP-04, TDSP-05, TDSP-06, TDSP-08, TDSP-17 |
| `toggleStatus` | 241 | POST /accounting/tds-payment/{tds_payment}/toggle-status | `tenant.accounting.tds-payment.update` | controller, manual 247-262 | 'Toggled' | acc_tds_payments, sys_activity_logs | TDSP-01, TDSP-03, TDSP-04, TDSP-05, TDSP-06, TDSP-08, TDSP-12, TDSP-17, TDSP-18 |
| `changeStatus` | 269 | POST /accounting/tds-payment/{tds_payment}/change-status | `tenant.accounting.tds-payment.update` | controller, manual 275-290 | 'StatusChanged' | acc_tds_payments, sys_activity_logs | TDSP-01, TDSP-03, TDSP-04, TDSP-05, TDSP-06, TDSP-08, TDSP-17, TDSP-18 |
| `trashed` | 297 | GET /accounting/tds-payment/trash/view | `tenant.accounting.tds-payment.restore` | none | none | none | TDSP-08, TDSP-20 |
| `restore` | 306 | GET /accounting/tds-payment/{id}/restore | `tenant.accounting.tds-payment.restore` | controller, manual 310-326 | 'Restored' | acc_tds_payments, sys_activity_logs | TDSP-01, TDSP-02, TDSP-03, TDSP-04, TDSP-05, TDSP-06, TDSP-08, TDSP-13, TDSP-16 |
| `forceDelete` | 333 | DELETE /accounting/tds-payment/{id}/force-delete | `tenant.accounting.tds-payment.forceDelete` | controller, manual 337-353 | 'Deleted' | acc_tds_payments, acc_tds_payment_allocations (cascade), sys_activity_logs | TDSP-01, TDSP-02, TDSP-03, TDSP-04, TDSP-05, TDSP-06, TDSP-08, TDSP-17, TDSP-22, TDSP-24 |

TDSP-19 (model casts) and TDSP-23 (Pint) apply to the model and the whole controller, not to one method.

## 6. Findings

### F1 — Errors

#### TDSP-01 · B · ERR-01 — Raw exception text is shown to the user on every failed write

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; no `$e->getMessage()` in `withErrors`, `with('error')`, `response()->json` or `back()`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:102, 189, 237, 265, 293, 329, 356`, methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `changeStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Every mutation catches `\Throwable` and concatenates `$e->getMessage()` into the flash or JSON response. The catch also replaces the framework's own rendering, so a duplicate key, a CHECK constraint or an FK restriction is presented as prose instead of the central error page. |
| **Consequence** | A user who saves a duplicate challan or deletes a referenced payment sees raw SQLSTATE text, table names and constraint names in the red banner or JSON body. |
| **Reproduce** | As Super Admin create a payment, then create a second one with the same challan number and date. Expected a field error; the flash shows the duplicate-key SQL text. |
| **Fix approach** | Remove the seven catches, use `DB::transaction()`, and let Laravel's central handler render failures. The rewrite is plan item TDSP-01. |
| **Plan item** | TDSP-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentController.php:95-103 — CURRENT (store; the same shape is repeated seven times)
        } catch (\Throwable $e) {
            DB::rollBack();
            \Illuminate\Support\Facades\Log::error('Failed to create TDS Payment', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create TDS Payment: ' . $e->getMessage());
        }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "getMessage"
98:                'error' => $e->getMessage(),
102:            return back()->withInput()->with('error', 'Failed to create TDS Payment: ' . $e->getMessage());
186:                'error' => $e->getMessage(),
189:            return back()->withInput()->with('error', 'Failed to update TDS Payment: ' . $e->getMessage());
235:            Log::error('Failed to delete TDS Payment', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);
237:            return back()->with('error', 'Failed to delete TDS Payment: ' . $e->getMessage());
263:            Log::error('Failed to toggle TDS Payment status', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);
265:            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
291:            Log::error('Failed to change TDS Payment status', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);
293:            return back()->with('error', 'Failed to update status: ' . $e->getMessage());
327:            Log::error('Failed to restore TDS Payment', ['id' => $id, 'error' => $e->getMessage()]);
329:            return back()->with('error', 'Failed to restore TDS Payment: ' . $e->getMessage());
354:            Log::error('Failed to force delete TDS Payment', ['id' => $id, 'error' => $e->getMessage()]);
356:            return back()->with('error', 'Failed to delete TDS Payment: ' . $e->getMessage());
```

#### TDSP-02 · H · ERR-02 — A missing record gives a redirect instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422/`abort()` into a redirect or 500; `findOrFail()` belongs before the try* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:312, 339`, methods `restore()` and `forceDelete()` |
| **Root cause** | `findOrFail()` sits inside the `try`, so the generic `catch (\Throwable $e)` also catches `ModelNotFoundException` and converts a 404 into a redirect with an error flash. |
| **Consequence** | Opening a restore or permanent-delete URL for a deleted or non-existent id shows a red "Failed to restore/delete" flash, with raw exception text, instead of the normal 404 page. |
| **Reproduce** | Open `/accounting/tds-payment/999999/restore` as Super Admin. Expected 404; actual redirect with a red flash. |
| **Fix approach** | Resolve the model before the transaction and do not catch it (part of the TDSP-01 rewrite). |
| **Plan item** | TDSP-01 in `02-fix-plan.md` §1 |

```php
// restore() and forceDelete() — CURRENT
        DB::beginTransaction();
        try {
            $model = TdsPayment::onlyTrashed()->findOrFail($id);

// forceDelete()
        DB::beginTransaction();
        try {
            $model = TdsPayment::withTrashed()->findOrFail($id);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "findOrFail"
312:            $model = TdsPayment::onlyTrashed()->findOrFail($id);
339:            $model = TdsPayment::withTrashed()->findOrFail($id);
```

#### TDSP-03 · H · ERR-00 — The `catch` in five methods calls `Log` without importing it, so the recovery path itself fatals

| Field | Value |
|---|---|
| **Rule** | ERR-00 (H) — *D1: no `try/catch` in a controller; while the old shape remains, a catch that references an unresolved class turns a handled failure into a 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:235, 263, 291, 327, 354`; imports at `:7-19` |
| **Root cause** | The file imports no `Illuminate\Support\Facades\Log`, and an unqualified `Log::error` inside namespace `Modules\Accounting\Http\Controllers` resolves to `Modules\Accounting\Http\Controllers\Log`, which does not exist. The first two catches use the fully qualified `\Illuminate\Support\Facades\Log`, the other five do not. |
| **Consequence** | When `destroy`, `toggleStatus`, `changeStatus`, `restore` or `forceDelete` fails, the catch throws "Class Modules\Accounting\Http\Controllers\Log not found"; the user gets a generic 500 instead of the intended flash, and the real exception is never logged. |
| **Reproduce** | Static only — the five catches are reached only on a failing write. The missing import is visible in the source. |
| **Fix approach** | Delete the catches (TDSP-01), which removes the unresolved reference with them. |
| **Plan item** | TDSP-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentController.php:235 and 263 — CURRENT
            Log::error('Failed to delete TDS Payment', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);
            Log::error('Failed to toggle TDS Payment status', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "Log::"
97:\Illuminate\Support\Facades\Log::error('Failed to create TDS Payment', [
184:\Illuminate\Support\Facades\Log::error('Failed to update TDS Payment', [
235:            Log::error('Failed to delete TDS Payment', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);
263:            Log::error('Failed to toggle TDS Payment status', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);
291:            Log::error('Failed to change TDS Payment status', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);
327:            Log::error('Failed to restore TDS Payment', ['id' => $id, 'error' => $e->getMessage()]);
354:            Log::error('Failed to force delete TDS Payment', ['id' => $id, 'error' => $e->getMessage()]);
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "^use "
7:use App\Http\Controllers\Controller;
8:use Illuminate\Http\Request;
9:use Illuminate\Support\Facades\DB;
10:use Illuminate\Support\Facades\Gate;
11:use App\Models\TenantMedia;
12:use App\Support\Media\TenantPathPrefix;
13:use Illuminate\Support\Facades\Storage;
14:use Illuminate\Support\Str;
15:use Modules\Accounting\Http\Requests\TdsPaymentRequest;
16:use Modules\Accounting\Models\TdsPayment;
17:use Modules\Accounting\Models\Ledger;
18:use Modules\Accounting\Models\FinancialYear;
19:use Modules\Accounting\Models\Voucher;
```

#### TDSP-04 · M · ERR-00 — Seven controller `try/catch` blocks violate the D1 idiom

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M) — *under D1 there is no `try/catch` in a controller; `DB::transaction()` rolls back and rethrows, and the central handler logs and renders* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:48, 139, 220, 248, 276, 311, 338` |
| **Root cause** | Every mutation keeps the old house-A1 shape (manual transaction plus catch) instead of the Laravel idiom settled in D1. |
| **Consequence** | Seven failure paths each need to be maintained for ERR-01/02/03/05; a future edit can reintroduce a leak or swallow a 404 in any one of them. |
| **Reproduce** | Static only — structural pattern. |
| **Fix approach** | Delete all seven blocks in the TDSP-01 rewrite. |
| **Plan item** | TDSP-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentController.php:47-48 — CURRENT (representative)
        DB::beginTransaction();
        try {
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "try \{"
48:        try {
139:        try {
220:        try {
248:        try {
276:        try {
311:        try {
338:        try {
```

#### TDSP-05 · M · ERR-05 — `Log::error()` logs the message string, losing the stack trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:97-100, 184-187, 235, 263, 291, 327, 354` |
| **Root cause** | Each catch logs an array containing the message; store also logs a stringified trace. The exception object, its previous exceptions and the request context are discarded. |
| **Consequence** | When a write fails in production, the log has one sentence and no stack trace, so support cannot tell which query or line failed. |
| **Reproduce** | Static only — the log format is visible in source. |
| **Fix approach** | Removing the catches (TDSP-01) removes these logs; the central handler uses `report($e)`. |
| **Plan item** | TDSP-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentController.php:97-100 — CURRENT
            \Illuminate\Support\Facades\Log::error('Failed to create TDS Payment', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "Log::error"
97:\Illuminate\Support\Facades\Log::error('Failed to create TDS Payment', [
184:\Illuminate\Support\Facades\Log::error('Failed to update TDS Payment', [
235:            Log::error('Failed to delete TDS Payment', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);
263:            Log::error('Failed to toggle TDS Payment status', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);
291:            Log::error('Failed to change TDS Payment status', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);
327:            Log::error('Failed to restore TDS Payment', ['id' => $id, 'error' => $e->getMessage()]);
354:            Log::error('Failed to force delete TDS Payment', ['id' => $id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### TDSP-06 · M · TXN-02 — Manual `beginTransaction()/commit()/rollBack()` in seven methods

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`; never return between begin and commit* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:47-96, 138-183, 219-234, 247-262, 275-290, 310-326, 337-353` |
| **Root cause** | Every mutation hand-rolls its transaction boundary and duplicates the rollback in a catch. The `activityLog()` call is correctly inside the transaction and after the write in all seven methods. |
| **Consequence** | A future early return or non-caught error between begin and commit leaves an open transaction; the same rollback code is repeated seven times. |
| **Reproduce** | Static only — structural pattern. |
| **Fix approach** | Replace each with `DB::transaction(function () { … });` in the TDSP-01 rewrite. |
| **Plan item** | TDSP-01 in `02-fix-plan.md` §1 |

```php
// each of the seven mutations — CURRENT
        DB::beginTransaction();
        try {
            // mutation
            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
        }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "beginTransaction|DB::commit|DB::rollBack"
47:        DB::beginTransaction();
91:            DB::commit();
96:            DB::rollBack();
138:        DB::beginTransaction();
178:            DB::commit();
183:            DB::rollBack();
219:        DB::beginTransaction();
229:            DB::commit();
234:            DB::rollBack();
247:        DB::beginTransaction();
258:            DB::commit();
262:            DB::rollBack();
275:        DB::beginTransaction();
285:            DB::commit();
290:            DB::rollBack();
310:        DB::beginTransaction();
322:            DB::commit();
326:            DB::rollBack();
337:        DB::beginTransaction();
349:            DB::commit();
353:            DB::rollBack();
```

#### TDSP-07 · L · TXN-03 — A rolled-back upload leaves an orphan file on the public disk

| Field | Value |
|---|---|
| **Rule** | TXN-03 (L, lowered from B — only a file is orphaned; no user data is lost) — *no irreversible side effect before the write succeeds* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:47-54` and `:138-147` |
| **Root cause** | `$file->store(...)` runs inside the transaction (after `beginTransaction` at 47/138). The database rows roll back on failure, but the file already on disk does not. |
| **Consequence** | A failed save leaves a receipt file nobody references; over time the storage grows with invisible files. No user sees a wrong result. |
| **Reproduce** | Static only — the upload has no live rows today, so there is no file to inspect. |
| **Fix approach** | None in this pass. Moving the write after commit needs a two-phase media row; recorded as accepted debt in plan §10. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// TdsPaymentController.php:47-54 — CURRENT
        DB::beginTransaction();
        try {
            if ($request->hasFile('challan_file')) {
                $file = $request->file('challan_file');
                $origName = $file->getClientOriginalName();
                $tenantPrefix = TenantPathPrefix::get();
                $targetDir = $tenantPrefix !== '' ? rtrim($tenantPrefix, '/') . '/accounting/tds-challans' : 'accounting/tds-challans';
                $storedPath = $file->store($targetDir, 'public');
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern 'beginTransaction|file->store'
47:        DB::beginTransaction();
54:                $storedPath = $file->store($targetDir, 'public');
138:        DB::beginTransaction();
147:                $storedPath = $file->store($targetDir, 'public');
219:        DB::beginTransaction();
247:        DB::beginTransaction();
275:        DB::beginTransaction();
310:        DB::beginTransaction();
337:        DB::beginTransaction();
```

### F3 — Authorization

#### TDSP-08 · B · AUTH-01 — The permission namespace does not exist, so every route denies every non-super-admin role

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B) — *every routed method authorizes with a permission that is declared in `config/permissionslist.php` and seeded with an exact-name query* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:25, 32, 43, 108, 124, 136, 195, 217, 243, 271, 299, 308, 335`; `config/permissionslist.php:600-644`; `Modules/Accounting/app/Http/Requests/TdsPaymentRequest.php:17` |
| **Root cause** | Every gate names `tenant.accounting.tds-payment.*`, but the `accounting.tds-payment` key was never added to the Accounting block of `config/permissionslist.php`, and the live tenant has zero such permission rows and zero role grants. The Super Admin bypass is the only path through the Gate. |
| **Consequence** | School Admin, Management, Account Staff and Account Manager receive 403 on every route, and the TDS Payments tab is hidden from them; only Super Admin can use the feature. |
| **Reproduce** | Log in as a School Admin and open `/accounting/tds`. Expected the tab; actual 403 on the tab and on every payment URL. |
| **Fix approach** | Add `'accounting.tds-payment' => $crud,` beside `'accounting.tax-rate' => $crud,`, then run the permission sync and grant the new keys to the accounting roles. Adding a key is a DECISION; seeding is Tarun's hand. |
| **Plan item** | TDSP-08 in `02-fix-plan.md` §4 (DECISION, ⚠ SHARED) |

```php
// TdsPaymentController.php:23-28 — CURRENT (the same namespace in all 13 methods)
    public function index()
    {
        Gate::authorize('tenant.accounting.tds-payment.viewAny');

        return redirect()->route('accounting.menu.tds', ['tab' => 'tds-payments']);
    }
```

**Evidence**
```
> Select-String -Path "config\permissionslist.php" -Pattern "accounting.tds"
(no output)
> mysql -u root -N -e "SELECT 'perm_count', COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_permissions WHERE name LIKE 'tenant.accounting.tds-payment%'; SELECT 'role_grants', COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_role_has_permissions_jnt j JOIN xyz_school_00000000000040008000_202627.sys_permissions p ON p.id=j.permission_id WHERE p.name LIKE 'tenant.accounting.tds-payment%';"
perm_count	0
role_grants	0
> mysql -u root -N -e "SELECT r.name FROM xyz_school_00000000000040008000_202627.sys_roles r JOIN xyz_school_00000000000040008000_202627.sys_role_has_permissions_jnt j ON j.role_id=r.id JOIN xyz_school_00000000000040008000_202627.sys_permissions p ON p.id=j.permission_id WHERE p.name='tenant.accounting.dashboard.view';"
Super Admin
School Admin
Management
Account Staff
Account Manager
```

#### TDSP-09 · L · AUTH-04 — The same permission is authorized twice in store and update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *do not authorize the same permission twice (FormRequest `authorize()` plus `Gate::authorize`); keep one* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:43, 136`; `Modules/Accounting/app/Http/Requests/TdsPaymentRequest.php:17` |
| **Root cause** | `store()` and `update()` call `Gate::authorize()` with `create`/`update`, and the injected FormRequest also authorizes the same action through `authorizeByCrudPermission()`. The FormRequest runs first. |
| **Consequence** | Two sources of truth for the same decision can drift; no user-visible effect today because both resolve to the same missing permission. |
| **Reproduce** | Static only — inspect the two authorize calls. |
| **Fix approach** | Remove the two controller `Gate::authorize()` calls and let the FormRequest authorize; TDSP-01 does this. |
| **Plan item** | TDSP-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentRequest.php:15-18 — CURRENT
    public function authorize(): bool
    {
        return $this->authorizeByCrudPermission('tenant.accounting.tds-payment');
    }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php","Modules\Accounting\app\Http\Requests\TdsPaymentRequest.php" -Pattern "Gate::authorize\('tenant.accounting.tds-payment.(create|update)'|authorizeByCrudPermission"
Modules\Accounting\app\Http\Controllers\TdsPaymentController.php:43:        Gate::authorize('tenant.accounting.tds-payment.create');
Modules\Accounting\app\Http\Controllers\TdsPaymentController.php:136:        Gate::authorize('tenant.accounting.tds-payment.update');
Modules\Accounting\app\Http\Requests\TdsPaymentRequest.php:17:        return $this->authorizeByCrudPermission('tenant.accounting.tds-payment');
```

### F4 — Validation and input

#### TDSP-10 · B · VAL-07 — Every edit silently resets the derived `allocated_amount` to zero

| Field | Value |
|---|---|
| **Rule** | VAL-07 (B, raised from M — a normal edit corrupts a financial balance and the allocation screen trusts it) — *cross-field/business rules for a derived column belong in the FormRequest, not as a client-supplied value* |
| **Where** | `Modules/Accounting/app/Http/Requests/TdsPaymentRequest.php:46, 75, 103`; `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:170`; `Modules/Accounting/resources/views/tds-payment/edit.blade.php` (no `allocated_amount` input) |
| **Root cause** | The migration comment calls `allocated_amount` "DERIVED from acc_tds_payment_allocations", but the request still accepts it from the client and `prepareForValidation()` always writes `(float) $this->input('allocated_amount', 0)`. The edit form has no such field, so every edit sends nothing and the merge writes `0`; `update($validated)` then persists it. |
| **Consequence** | Editing an allocated payment wipes its allocated total to ₹0. The allocation screen computes "unallocated balance" from that stored column, so the same challan can then be allocated again beyond its real balance. |
| **Reproduce** | Create a payment of ₹10,000, allocate ₹4,000, then open the payment's edit page and save without touching anything. The list's Allocated column becomes ₹0 and the allocation modal offers ₹10,000 again. |
| **Fix approach** | Remove `allocated_amount` from the request rules, from `prepareForValidation()` and from `attributes()`. The column keeps its DB default 0 on create and its stored value on update; only `TdsPaymentAllocationController` writes it after this fix. |
| **Plan item** | TDSP-10 in `02-fix-plan.md` §1 |

```php
// TdsPaymentRequest.php:46 and 103 — CURRENT
            'allocated_amount'       => ['nullable', 'numeric', 'min:0', 'lte:total_amount'],

            'allocated_amount' => (float) $this->input('allocated_amount', 0),
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\TdsPaymentRequest.php" -Pattern 'allocated_amount'
46:            'allocated_amount'       => ['nullable', 'numeric', 'min:0', 'lte:total_amount'],
75:            'allocated_amount'       => 'Allocated Amount',
103:            'allocated_amount' => (float) $this->input('allocated_amount', 0),
> Select-String -Path "Modules\Accounting\resources\views\tds-payment\edit.blade.php" -Pattern "allocated_amount"
(no output)
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern 'update\(\$validated\)'
170:            $tdsPayment->update($validated);
```

#### TDSP-11 · H · VAL-04 — Re-creating a trashed challan passes validation then hits the unique index

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the DB unique index including soft-delete semantics; a rule that excludes trashed rows under an index that includes them is a 500* |
| **Where** | `Modules/Accounting/app/Http/Requests/TdsPaymentRequest.php:28-36`; `database/migrations/tenant/2026_09_16_100054_create_acc_tds_payments_table.php:48` |
| **Root cause** | The rule ends with `->withoutTrashed()`, but the unique key `uq_acc_tdspay_challan` is `(challan_no, challan_date)` with no `deleted_at` column, so it also covers soft-deleted rows. |
| **Consequence** | A user who deletes a challan and then records another with the same number and date passes validation and gets a duplicate-key SQL error (shown raw today, TDSP-01) instead of a field message. |
| **Reproduce** | Soft-delete payment `CIN-001` dated 2026-04-30, then create another with the same number and date. Expected a validation error; actual duplicate-key SQL error. |
| **Fix approach** | Remove `->withoutTrashed()` so the rule matches the real index. |
| **Plan item** | TDSP-11 in `02-fix-plan.md` §5 |

```php
// TdsPaymentRequest.php:28-36 — CURRENT
            'challan_no'             => [
                'required',
                'string',
                'max:50',
                Rule::unique('acc_tds_payments', 'challan_no')
                    ->where(fn($q) => $q->where('challan_date', $this->input('challan_date')))
                    ->ignore($id)
                    ->withoutTrashed(),
            ],
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\TdsPaymentRequest.php" -Pattern "withoutTrashed"
35:                    ->withoutTrashed(),
> Select-String -Path "database\migrations\tenant\2026_09_16_100054_create_acc_tds_payments_table.php" -Pattern "uq_acc_tdspay_challan"
48:            $table->unique(['challan_no', 'challan_date'], 'uq_acc_tdspay_challan');
```

#### TDSP-12 · M · VAL-05 — The Active Record checkbox cannot be switched off from the edit form

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is validated and trusted as submitted; a boolean field must not be rewritten to a different value* |
| **Where** | `Modules/Accounting/app/Http/Requests/TdsPaymentRequest.php:97`; `Modules/Accounting/resources/views/tds-payment/edit.blade.php:201` |
| **Root cause** | `prepareForValidation()` calls `$this->boolean('is_active', true)`. Browsers omit an unchecked checkbox, so the absent key takes the default `true` and the user's choice is lost. |
| **Consequence** | A user unchecks Active Record, saves, and the payment is still active; the form silently lies. The separate toggle route is not wired to any view (TDSP-18), so there is no other way to deactivate it. |
| **Reproduce** | Edit a payment, clear Active Record, save, reopen the edit page. The checkbox is still checked. |
| **Fix approach** | Remove the forced default: `$this->boolean('is_active')`. The create modal already defaults the checkbox to checked, so only an unchecked box becomes false. |
| **Plan item** | TDSP-12 in `02-fix-plan.md` §5 |

```php
// TdsPaymentRequest.php:96-105 — CURRENT
        $this->merge([
            'is_active'        => $this->boolean('is_active', true),
            'surcharge'        => $surcharge,
            'cess'             => $cess,
            'interest'         => $interest,
            'late_fee'         => $lateFee,
            'total_amount'     => $total,
            'allocated_amount' => (float) $this->input('allocated_amount', 0),
            'status'           => $this->input('status', 'Draft'),
        ]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\TdsPaymentRequest.php" -Pattern "boolean\('is_active'"
97:            'is_active'        => $this->boolean('is_active', true),
> Select-String -Path "Modules\Accounting\resources\views\tds-payment\edit.blade.php" -Pattern 'name="is_active"'
201:                                <input type="checkbox" name="is_active" id="edit_is_active" class="form-check-input" value="1" {{ old('is_active', $tdsPayment->is_active) ? 'checked' : '' }}>
```

### F5 — Routes

#### TDSP-13 · H · RTE-01 — A restore (state change) is performed over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:473`; `Modules/Accounting/resources/views/tds-payment/trash.blade.php:38` |
| **Root cause** | Restore is registered as a `GET` route, and the trash view renders it as a plain `<a href>` link. |
| **Consequence** | A prefetcher, crawler or shared URL can restore a trashed challan without a POST or CSRF token; the action is not protected from cross-site triggering. |
| **Reproduce** | While logged in, open `/accounting/tds-payment/1/restore` directly. The payment is restored without a form submission. |
| **Fix approach** | Register the route as POST and replace the link with a CSRF-protected form. |
| **Plan item** | TDSP-13 in `02-fix-plan.md` §5 (⚠ SHARED — route file) |

```php
// Modules/Accounting/routes/web.php:473 — CURRENT
Route::get('/tds-payment/{id}/restore', [TdsPaymentController::class, 'restore'])->name('tds-payment.restore');
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "tds-payment/\{id\}/restore"
473:Route::get('/tds-payment/{id}/restore', [TdsPaymentController::class, 'restore'])->name('tds-payment.restore');
> Select-String -Path "Modules\Accounting\resources\views\tds-payment\trash.blade.php" -Pattern "tds-payment.restore"
38:                                            <a href="{{ route('accounting.tds-payment.restore', $pay->id) }}" class="btn btn-sm btn-outline-success">
```

### F6 — Controller shape

#### TDSP-14 · M · CTL-05 — The media-creation payload is copy-pasted in `store()` and `update()`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same media payload in `store` and `update` must be shared* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:49-75` and `:142-168` |
| **Root cause** | The 27-line upload-and-`TenantMedia::create()` block is duplicated. The two copies already differ: store creates with `model_id = 0` and updates it afterwards; update writes the id directly. |
| **Consequence** | A future field added to the media row must be added twice; the copies will drift, and update has no cleanup for the replaced media (TDSP-22). |
| **Reproduce** | Static only — compare the two blocks. |
| **Fix approach** | Extract one private `storeChallanMedia()` helper used by both; TDSP-01 includes it. |
| **Plan item** | TDSP-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentController.php:54-72 — CURRENT (repeated at 147-165)
                $storedPath = $file->store($targetDir, 'public');

                $media = TenantMedia::create([
                    'model_type'            => TdsPayment::class,
                    'model_id'              => 0,
                    'uuid'                  => (string) Str::uuid(),
                    'collection_name'       => 'tds_challan_receipts',
                    'name'                  => pathinfo($origName, PATHINFO_FILENAME),
                    'file_name'             => $origName,
                    'mime_type'             => $file->getMimeType() ?: 'application/octet-stream',
                    'disk'                  => 'public',
                    'size'                  => $file->getSize(),
                    'manipulations'         => [],
                    'custom_properties'     => [
                        'stored_path' => $storedPath,
                    ],
                    'generated_conversions' => [],
                    'responsive_images'     => [],
                ]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "TenantMedia::create"
56:                $media = TenantMedia::create([
149:                $media = TenantMedia::create([
```

#### TDSP-15 · M · CTL-10 — `create()` renders a view that does not exist

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code; a method that no UI reaches and that cannot render is dead surface* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:30-39`; missing `Modules/Accounting/resources/views/tds-payment/create.blade.php` |
| **Root cause** | `create()` returns `view('accounting::tds-payment.create')`, but the module has only `edit`, `show` and `trash` blades. The list tab creates through a modal, and no view references the routed create page. |
| **Consequence** | Visiting `/accounting/tds-payment/create` throws "View [tds-payment.create] not found" and returns a 500, even for Super Admin. The route exists but is unusable. |
| **Reproduce** | Open `/accounting/tds-payment/create` as Super Admin. Expected a form; actual 500. |
| **Fix approach** | DECISION: remove the routed create page and keep the modal, or add the missing blade and link it. |
| **Plan item** | TDSP-15 in `02-fix-plan.md` §9 (DECISION) |

```php
// TdsPaymentController.php:30-39 — CURRENT
    public function create()
    {
        Gate::authorize('tenant.accounting.tds-payment.create');

        $bankLedgers = Ledger::selectableBankAccounts();
        $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
        $vouchers = Voucher::orderByDesc('voucher_date')->limit(50)->get();

        return view('accounting::tds-payment.create', compact('bankLedgers', 'financialYears', 'vouchers'));
    }
```

**Evidence**
```
> Test-Path "Modules\Accounting\resources\views\tds-payment\create.blade.php"
False
> Get-ChildItem "Modules\Accounting\resources\views\tds-payment" | Select-Object Name
edit.blade.php
show.blade.php
trash.blade.php
> Get-ChildItem "Modules\Accounting\resources\views" -Recurse -Include *.blade.php | Select-String -Pattern "tds-payment.create"
(no output)
```

#### TDSP-16 · L · CTL-03 — `restore()` and `forceDelete()` use `$id` plus `findOrFail()` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (L, lowered from M because the current code is correct and the fix needs a shared route file) — *use route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:306-312, 333-339`; `Modules/Accounting/routes/web.php:473-474` |
| **Root cause** | The two trash routes bind `{id}` as an integer, while every resource method binds `{tds_payment}`. |
| **Consequence** | No functional bug today; the 404 handling is duplicated and the two trash methods are inconsistent with the rest of the controller. |
| **Reproduce** | Static only — compare the route parameter names with the method signatures. |
| **Fix approach** | None in this pass; binding a trashed model needs `->withTrashed()` in the shared route file. Accepted as debt. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// TdsPaymentController.php:306-313 — CURRENT
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-payment.restore');

        DB::beginTransaction();
        try {
            $model = TdsPayment::onlyTrashed()->findOrFail($id);
            $model->restore();
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "tds-payment/\{id\}/restore|tds-payment/\{id\}/force-delete"
473:Route::get('/tds-payment/{id}/restore', [TdsPaymentController::class, 'restore'])->name('tds-payment.restore');
474:Route::delete('/tds-payment/{id}/force-delete', [TdsPaymentController::class, 'forceDelete'])->name('tds-payment.forceDelete');
```

#### TDSP-17 · L · CTL-04 — Ten public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:23, 30, 41, 106, 122, 134, 193, 215, 241, 269` |
| **Root cause** | Only `trashed()`, `restore()` and `forceDelete()` declare a return type. |
| **Consequence** | Static analysis cannot catch a method that returns the wrong response type; no runtime effect. |
| **Reproduce** | Static only — inspect the signatures. |
| **Fix approach** | Add the types in the TDSP-01 rewrite, including `StreamedResponse|RedirectResponse` for the download. |
| **Plan item** | TDSP-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentController.php:23, 30, 41 — CURRENT
    public function index()
    public function create()
    public function store(TdsPaymentRequest $request)
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "public function"
23:    public function index()
30:    public function create()
41:    public function store(TdsPaymentRequest $request)
106:    public function show(TdsPayment $tdsPayment)
122:    public function edit(TdsPayment $tdsPayment)
134:    public function update(TdsPaymentRequest $request, TdsPayment $tdsPayment)
193:    public function downloadReceipt(TdsPayment $tdsPayment)
215:    public function destroy(TdsPayment $tdsPayment)
241:    public function toggleStatus(Request $request, TdsPayment $tdsPayment)
269:    public function changeStatus(Request $request, TdsPayment $tdsPayment)
297:    public function trashed(): \Illuminate\View\View
306:    public function restore($id): \Illuminate\Http\RedirectResponse
333:    public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

#### TDSP-18 · L · CTL-10 — The status-toggle and status-change routes have no caller in any view

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *no dead code; a routed method that no UI reaches duplicates the edit form's status field* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:241-295`; `Modules/Accounting/routes/web.php:476-477` |
| **Root cause** | The list tab renders a status badge and a view/edit/delete action component; it never renders a status switch and never posts to `toggle-status` or `change-status`. The edit form already saves `status` and `is_active`. |
| **Consequence** | Two extra write endpoints exist with no user path; `changeStatus` duplicates the edit form, and `toggleStatus` is the only route that can deactivate a record but is unreachable. No user-visible failure today. |
| **Reproduce** | Static only — search every blade for the two route names. |
| **Fix approach** | DECISION: wire a status switch into the list tab, or remove both routes and methods, or accept the dead endpoints. |
| **Plan item** | TDSP-18 in `02-fix-plan.md` §9 (DECISION) |

```php
// TdsPaymentController.php:241-250 — CURRENT (toggleStatus; changeStatus is the same shape)
    public function toggleStatus(Request $request, TdsPayment $tdsPayment)
    {
        Gate::authorize('tenant.accounting.tds-payment.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::beginTransaction();
        try {
            $tdsPayment->is_active = $request->input('is_active');
            $tdsPayment->save();
```

**Evidence**
```
> Get-ChildItem "Modules\Accounting\resources\views" -Recurse -Include *.blade.php | Select-String -Pattern "tds-payment.toggleStatus|tds-payment.changeStatus"
(no output)
> Select-String -Path "Modules\Accounting\resources\views\pages\partials\tds-management\_tds-payments.blade.php" -Pattern "url|status-switch|change-status|data-url"
5:<x-backend.tab.search-bar url="accounting.tds-payment"
217:                                            url="accounting.tds-payment"
```

### F7 — Models

#### TDSP-19 · M · MDL-02 — `is_active` and `status` have no casts

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` for every boolean, date/datetime, decimal, json/array and enum column* |
| **Where** | `Modules/Accounting/app/Models/TdsPayment.php:42-54`; `database/migrations/tenant/2026_09_16_100058` equivalent columns at `100054:41` and `130001:81` |
| **Root cause** | `is_active` is a MySQL `tinyint(1)` added by migration `130001`, and `status` is a MySQL enum, but neither is cast. The model declares `'is_active'` in `$fillable` and the controller writes it in `toggleStatus()`. |
| **Consequence** | `toggleStatus()` returns the raw submitted `"0"` string in its JSON body, which is truthy in JavaScript, so the UI can show a record as still active after it was switched off; a future enum or boolean comparison has no declared contract. |
| **Reproduce** | Static only — `is_active` is written by `toggleStatus()` at controller line 249 and read back at line 260. |
| **Fix approach** | Add `'is_active' => 'boolean'` and `'status' => 'string'` to `$casts`. |
| **Plan item** | TDSP-19 in `02-fix-plan.md` §5 |

```php
// TdsPayment.php:42-54 — CURRENT
    protected $casts = [
        'quarter'          => 'integer',
        'challan_date'     => 'date',
        'deposit_date'     => 'date',
        'tax_amount'       => 'decimal:2',
        'surcharge'        => 'decimal:2',
        'cess'             => 'decimal:2',
        'interest'         => 'decimal:2',
        'late_fee'         => 'decimal:2',
        'total_amount'     => 'decimal:2',
        'allocated_amount' => 'decimal:2',
        'return_filed_on'  => 'date',
    ];
```

**Evidence**
```
> Select-String -Path "database\migrations\tenant\2026_09_16_130001_add_soft_deletes_and_is_active_to_accounting_tables.php" -Pattern "'acc_tds_payments'"
81:            'acc_tds_payments' => ['need' => ['is_active'], 'after' => 'updated_at'],
> Select-String -Path "Modules\Accounting\app\Models\TdsPayment.php" -Pattern "'is_active'|'status'"
37:        'status',
39:        'is_active',
92:        return $query->where('status', 'Draft');
```

### F8 — Services and jobs

clean — `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "dispatch|Service|Job|env\("` → no output. The controller injects no service and dispatches no job.

### F9 — Queries and performance

#### TDSP-20 · M · QRY-02 — The trash list paginates at 15, not the standard 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M) — *lists are paginated; the project standard is 10 rows per page with a distinct page name per list* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:301` |
| **Root cause** | `paginate(15)` is hard-coded instead of the standard `paginate(10, ['*'], 'trash_page')`, and no `withQueryString()` is applied. |
| **Consequence** | The trash page renders 50% more rows and DOM than every other paginated list in the module, and a second paginator on the same page would collide on the default page name. |
| **Reproduce** | Open `/accounting/tds-payment/trash/view` with more than 15 trashed rows; the page shows 15 rows. |
| **Fix approach** | Change to `paginate(10, ['*'], 'trash_page')->withQueryString()`. |
| **Plan item** | TDSP-20 in `02-fix-plan.md` §6 |

```php
// TdsPaymentController.php:301 — CURRENT
        $payments = TdsPayment::onlyTrashed()->with(['bankLedger', 'financialYear'])->orderByDesc('deposit_date')->paginate(15);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "paginate\("
301:        $payments = TdsPayment::onlyTrashed()->with(['bankLedger', 'financialYear'])->orderByDesc('deposit_date')->paginate(15);
```

#### TDSP-21 · L · QRY-03 — The create and edit dropdowns load whole models

| Field | Value |
|---|---|
| **Rule** | QRY-03 (L, lowered from M because the tables hold 10 ledgers, 1 financial year and 2 vouchers today) — *select only what you use; dropdowns use `pluck` or an explicit column list* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:34-36, 127-129` |
| **Root cause** | `FinancialYear::…->get()` and `Voucher::…->limit(50)->get()` fetch every column for simple option lists; `Ledger::selectableBankAccounts()` is the shared owner's method. |
| **Consequence** | As the chart of accounts and voucher history grow, the create/edit pages grow linearly and hydrate columns the options never read. |
| **Reproduce** | Static only — live counts are small, so the impact is negligible today. |
| **Fix approach** | None in this pass; the voucher option uses the `voucher_display_no` accessor, so a column whitelist must be checked against that accessor first. Accepted as debt. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// TdsPaymentController.php:34-36 — CURRENT (repeated at 127-129)
        $bankLedgers = Ledger::selectableBankAccounts();
        $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
        $vouchers = Voucher::orderByDesc('voucher_date')->limit(50)->get();
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "::selectableBankAccounts|FinancialYear::|Voucher::"
34:        $bankLedgers = Ledger::selectableBankAccounts();
35:        $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
36:        $vouchers = Voucher::orderByDesc('voucher_date')->limit(50)->get();
127:        $bankLedgers = Ledger::selectableBankAccounts();
128:        $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
129:        $vouchers = Voucher::orderByDesc('voucher_date')->limit(50)->get();
```

### F10 — Views

clean — `Select-String -Path "Modules\Accounting\resources\views\tds-payment\*.blade.php" -Pattern "Model::|DB::|->get\(\)|->count\(\)|->where\(|\{!!"` → one hit only, the direct `asset('storage/…')` preview at `edit.blade.php:159`, recorded as the security finding TDSP-22. The show and trash blades render no queries and no unescaped user text. (The missing create blade is TDSP-15, recorded under F6 because the defect is the dead route.)

### F11 — Security and tenancy

#### TDSP-22 · H · SEC-05 — Challan receipts are stored on the public disk and superseded files are never removed

| Field | Value |
|---|---|
| **Rule** | SEC-05 (H) — *files are served through signed/authorised routes when private; uploads are stored in tenant paths* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:54, 147, 204-209`; `Modules/Accounting/resources/views/tds-payment/edit.blade.php:159` |
| **Root cause** | Uploads go to the `public` disk under `accounting/tds-challans`, and the edit view previews the file with a direct `asset('storage/…')` URL. `storage/app/public` is served by the `public/storage` symlink and the per-tenant folder prefix is the only separation. The controller never deletes the media row or file when a receipt is replaced (`update`) or permanently deleted (`forceDelete`). |
| **Consequence** | Anyone who knows the URL can download a challan receipt without authentication; a replaced or permanently deleted receipt remains downloadable forever, and its `sys_media` row is orphaned. |
| **Reproduce** | Static today: no payment has a receipt (`sys_media` rows for TdsPayment = 0). Once one is uploaded, copy the preview URL from the edit page into a private browser window; it downloads without login. |
| **Fix approach** | Store new files on the private `local` disk, download through the authorised controller route, delete the old media after commit, remove the direct public preview, and delete media on force-delete. The TDSP-01 rewrite includes this. |
| **Plan item** | TDSP-01 in `02-fix-plan.md` §1 |

```php
// store() and update() — CURRENT
                $storedPath = $file->store($targetDir, 'public');

// downloadReceipt():204-209 — CURRENT
        if ($storedPath && Storage::disk('public')->exists($storedPath)) {
            return Storage::disk('public')->download($storedPath, $media->file_name);
        }

        if (!empty($media->file_name) && Storage::disk($media->disk ?? 'public')->exists($media->file_name)) {
            return Storage::disk($media->disk ?? 'public')->download($media->file_name, $media->file_name);
        }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern 'store\(|Storage::disk'
54:                $storedPath = $file->store($targetDir, 'public');
147:                $storedPath = $file->store($targetDir, 'public');
204:        if ($storedPath && Storage::disk('public')->exists($storedPath)) {
205:            return Storage::disk('public')->download($storedPath, $media->file_name);
208:        if (!empty($media->file_name) && Storage::disk($media->disk ?? 'public')->exists($media->file_name)) {
209:            return Storage::disk($media->disk ?? 'public')->download($media->file_name, $media->file_name);
> Select-String -Path "Modules\Accounting\resources\views\tds-payment\edit.blade.php" -Pattern "asset\('storage"
159:                                        image="{{ $tdsPayment->media ? asset('storage/' . ($tdsPayment->media->custom_properties['stored_path'] ?? '')) : '' }}"
```

### F12 — Style

#### TDSP-23 · L · STY-02 — Pint fails on all three in-scope PHP files

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines between imports* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php`, `Modules/Accounting/app/Models/TdsPayment.php`, `Modules/Accounting/app/Http/Requests/TdsPaymentRequest.php` |
| **Root cause** | The files were not formatted with the project's Pint preset. The model carries an unused `use App\Models\BaseModel;` import. |
| **Consequence** | Style drift and a failing Pint gate; no runtime effect. |
| **Reproduce** | Run `vendor\bin\pint --test <the three files> --format agent`. |
| **Fix approach** | Run Pint on the three files only (never `--dirty`). |
| **Plan item** | TDSP-23 in `02-fix-plan.md` §8 |

```php
// TdsPayment.php:7-9 — CURRENT
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
```

**Evidence**
```
> vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" "Modules\Accounting\app\Models\TdsPayment.php" "Modules\Accounting\app\Http\Requests\TdsPaymentRequest.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\TdsPaymentController.php","fixers":["fully_qualified_strict_types","concat_space","unary_operator_spaces","not_operator_with_successor_space","ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Models\\TdsPayment.php","fixers":["fully_qualified_strict_types","no_unused_imports","ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Http\\Requests\\TdsPaymentRequest.php","fixers":["function_declaration","ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1. Wrong data? | 2. Delete before replacement? | 3. Duplicate implementation? | 4. Soft-delete × unique? | 5. Race? | 6. Authorization hole? | 7. Message lies? | 8. Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | TDSP-10 | TDSP-07 | TDSP-14 | TDSP-11 | ok | TDSP-08 | ok | TDSP-15 |
| `update` | TDSP-10 | TDSP-22 | TDSP-14 | TDSP-11 | ok | TDSP-08 | ok | TDSP-15 |
| `destroy` | ok | ok | ok | ok | ok | TDSP-08 | ok | TDSP-18 |
| `toggleStatus` | TDSP-19 | ok | TDSP-18 | ok | ok | TDSP-08 | ok | TDSP-18 |
| `changeStatus` | ok | ok | TDSP-18 | ok | ok | TDSP-08 | ok | TDSP-18 |
| `restore` | ok | ok | ok | ok | ok | TDSP-08 | ok | ok |
| `forceDelete` | TDSP-24 | TDSP-22 | ok | ok | ok | TDSP-08 | ok | ok |

#### TDSP-24 · H · CTL-06 — A permanent delete cascades the allocations and leaves the deductions marked paid

| Field | Value |
|---|---|
| **Rule** | CTL-06 (H) — *business rules live in the controller/service layer, not in the database schema alone* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php:333-358`; `database/migrations/tenant/2026_09_16_100075_create_acc_tds_payment_allocations_table.php:35` |
| **Root cause** | `forceDelete()` calls `$model->forceDelete()` with no check for dependent `acc_tds_payment_allocations`. The FK `fk_acc_tdsalloc_payment` is `cascadeOnDelete()`, so the allocation rows are removed silently. Nothing reverts `acc_tds_deductions.paid_amount`, which `TdsPaymentAllocationController` incremented when each allocation was created. |
| **Consequence** | Permanently deleting a challan that has been allocated destroys the allocation rows and leaves the linked deductions looking paid, so the same deduction can never be allocated again and the TDS outstanding total is understated. |
| **Reproduce** | Static today: the live tenant has 0 payments and 0 allocations. With an allocated payment, trash it and click Delete; the request succeeds and the allocation history disappears with no warning. |
| **Fix approach** | Refuse the permanent delete while active allocations exist, with a fixed `\DomainException` message (D2). The TDSP-01 rewrite includes the guard. |
| **Plan item** | TDSP-01 in `02-fix-plan.md` §1 |

```php
// TdsPaymentController.php:337-341 — CURRENT
        DB::beginTransaction();
        try {
            $model = TdsPayment::withTrashed()->findOrFail($id);
            $cNo = $model->challan_no;
            $model->forceDelete();
```

**Evidence**
```
> Select-String -Path "database\migrations\tenant\2026_09_16_100075_create_acc_tds_payment_allocations_table.php" -Pattern "fk_acc_tdsalloc_payment"
35:            $table->foreign('tds_payment_id', 'fk_acc_tdsalloc_payment')->references('id')->on('acc_tds_payments')->cascadeOnDelete();
> mysql -u root -N -e "SELECT 'allocations', COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_tds_payment_allocations; SELECT 'payments', COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_tds_payments;"
allocations	0
payments	0
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/resources/views/pages/partials/tds-management/_tds-payments.blade.php` | The list tab, create modal, filters and export button are rendered by `AccDashboardController`, which is `CLAIMED` and not audited here. The tab's create button bypasses the routed `create()` page. | VIEW / CTL | `gaurav/Accounting/AccDashboardController` |
| `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php:33, 48` | Trusts the stored `acc_tds_payments.allocated_amount` as the unallocated balance. After TDSP-10 the stored value is 0, so the same challan can be over-allocated. This is a consequence of our fix, not a defect in the allocation controller. | CTL-06 | TDSP-10 / TDSP-02 |
| `config/permissionslist.php` | No `accounting.tds-payment` key. Shared config; changing it is a DECISION and a permission sync is Tarun's hand. | AUTH-01 | Tarun / TDSP-08 |
| `Modules/Accounting/routes/web.php` | `restore` is registered as GET; `create` points at a missing blade; `toggle-status` and `change-status` have no caller. Shared route file. | RTE-01 / CTL-10 | TDSP-13, TDSP-15, TDSP-18 |
| `app/Models/TenantMedia.php` | Shared media model; the controller creates rows manually instead of going through a media service. No defect found in the model itself. The disk and cleanup defect is in our controller and view. | — | — |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | `updating()` sets `updated_by = Auth::id() ?? 1`; the fallback is a hard-coded user id, reported by the owner report. It does not affect this controller's writes beyond the shared fallback. | SEC-03 | `AccountingStatusMasterController` report (owner) |

## 8. Not covered, and why

- **Scanner and self-check were skipped.** `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are missing from this checkout, and the tooling override forbids running `scan.php`. F1-F13 were therefore worked manually with `read`, `Select-String`, `php -l`, `pint --test` and direct MySQL probes. The §15 self-check could not be executed.
- **No tests were run (D4).** The browser flows for store/update/restore/force-delete are described from source and live data, not executed.
- **The public-file exposure was proven statically.** The only live tenant has 0 TDS payments and 0 TDS media rows, so there was no unauthenticated download to perform. The disk and URL construction are proven from source.
- **The allocation corruption was not exercised.** The live tenant has 0 payments, 0 allocations and 0 deductions, so TDSP-10 and TDSP-24 are proven from the request, the controller and the DDL, not by walking an allocated payment through edit and force-delete.
- **The list tab and the dashboard controller are out of scope.** `_tds-payments.blade.php` belongs to the `AccDashboardController` report (CLAIMED).
- **`Ledger`, `FinancialYear`, `Voucher`, `TdsPaymentAllocation`, `TdsDeduction`, `TenantMedia`, `BaseAccountingModel` and `AccountingContext` were linked, not re-audited.** Their owner reports are listed in §3.
- **Permission seeding was not run.** The counts in TDSP-08 come from the live tenant database, not from a seeder run. Seeding and role grants are Tarun's hand.
- **The two unused status routes may have non-browser callers.** TDSP-18 proves no blade calls them; an external integration or direct URL could still use them, which is why the fix is a DECISION.
