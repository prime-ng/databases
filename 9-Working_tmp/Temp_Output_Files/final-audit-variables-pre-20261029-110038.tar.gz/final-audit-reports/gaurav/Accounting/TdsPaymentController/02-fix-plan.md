# Fix Plan — Accounting / TdsPaymentController

**From:** `01-report.md` (2026-10-23) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | route file — ⚠ SHARED, touched only by TDSP-13 (and TDSP-15 option (a) or TDSP-18 option (b), if chosen) |
| `config/permissionslist.php` | ⚠ SHARED config — touched only by TDSP-08 |
| `Modules/Accounting/resources/views/pages/partials/tds-management/_tds-payments.blade.php` | owned by the `AccDashboardController` report |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | owned by another report |
| `Modules/Accounting/app/Models/Ledger.php` | owned by the `LedgerController` report |
| `Modules/Accounting/app/Models/FinancialYear.php` | owned by the `FinancialYearController` report |
| `Modules/Accounting/app/Models/Voucher.php` | owned by the `VoucherController` report |
| `Modules/Accounting/app/Models/TdsPaymentAllocation.php` | owned by the `TdsPaymentAllocationController` report |
| `Modules/Accounting/app/Models/TdsDeduction.php` | owned by the `TdsDeductionController` report |
| `Modules/Accounting/app/Http/Controllers/TdsPaymentAllocationController.php` | owned by another report — the over-allocation consequence is fixed by TDSP-10, not here |
| `app/Models/TenantMedia.php` | owned by `tarun/SystemConfig-done/TenantMediaStoreController` |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | owned by the `AccountingStatusMasterController` report |
| `Modules/Accounting/app/Services/AccountingContext.php` | owned by the `AccountGroupController` report |
| `database/migrations/**` | never edit an existing migration |
| `resources/views/components/**` (`x-backend.*`, `x-tenantcore.*`) | common components |

## 1. Blockers reachable today

- [ ] **TDSP-01** · B · ERR-01 · `TdsPaymentController.php:7-359` + `edit.blade.php:155-161` — remove every `try/catch`, every manual transaction and every `$e->getMessage()`; use `DB::transaction()`, shared media helpers, the private `local` disk, one authorised download route, and a force-delete allocation guard. This one item also resolves **TDSP-02, TDSP-03, TDSP-04, TDSP-05, TDSP-06, TDSP-09, TDSP-14, TDSP-17, TDSP-22 and TDSP-24**.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php`, `Modules/Accounting/resources/views/tds-payment/edit.blade.php`
  - **Before — imports (`TdsPaymentController.php:7-19`):**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use App\Models\TenantMedia;
    use App\Support\Media\TenantPathPrefix;
    use Illuminate\Support\Facades\Storage;
    use Illuminate\Support\Str;
    use Modules\Accounting\Http\Requests\TdsPaymentRequest;
    use Modules\Accounting\Models\TdsPayment;
    use Modules\Accounting\Models\Ledger;
    use Modules\Accounting\Models\FinancialYear;
    use Modules\Accounting\Models\Voucher;
    ```
  - **After — imports:**
    ```php
    use App\Http\Controllers\Controller;
    use App\Models\TenantMedia;
    use App\Support\Media\TenantPathPrefix;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Storage;
    use Illuminate\Support\Str;
    use Illuminate\View\View;
    use Modules\Accounting\Http\Requests\TdsPaymentRequest;
    use Modules\Accounting\Models\FinancialYear;
    use Modules\Accounting\Models\Ledger;
    use Modules\Accounting\Models\TdsPayment;
    use Modules\Accounting\Models\Voucher;
    use Symfony\Component\HttpFoundation\StreamedResponse;
    ```
  - **Before — `index()` and `create()` (`TdsPaymentController.php:23-39`):**
    ```php
        public function index()
        {
            Gate::authorize('tenant.accounting.tds-payment.viewAny');

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-payments']);
        }

        public function create()
        {
            Gate::authorize('tenant.accounting.tds-payment.create');

            $bankLedgers = Ledger::selectableBankAccounts();
            $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
            $vouchers = Voucher::orderByDesc('voucher_date')->limit(50)->get();

            return view('accounting::tds-payment.create', compact('bankLedgers', 'financialYears', 'vouchers'));
        }
    ```
  - **After — `index()` and `create()`:**
    ```php
        public function index(): RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-payment.viewAny');

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-payments']);
        }

        public function create(): View
        {
            Gate::authorize('tenant.accounting.tds-payment.create');

            $bankLedgers = Ledger::selectableBankAccounts();
            $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
            $vouchers = Voucher::orderByDesc('voucher_date')->limit(50)->get();

            return view('accounting::tds-payment.create', compact('bankLedgers', 'financialYears', 'vouchers'));
        }
    ```
  - **Before — `store()` (`TdsPaymentController.php:41-104`):**
    ```php
        public function store(TdsPaymentRequest $request)
        {
            Gate::authorize('tenant.accounting.tds-payment.create');

            $validated = $request->validated();

            DB::beginTransaction();
            try {
                if ($request->hasFile('challan_file')) {
                    $file = $request->file('challan_file');
                    $origName = $file->getClientOriginalName();
                    $tenantPrefix = TenantPathPrefix::get();
                    $targetDir = $tenantPrefix !== '' ? rtrim($tenantPrefix, '/') . '/accounting/tds-challans' : 'accounting/tds-challans';
                    $storedPath = $file->store($targetDir, 'public');

                    $media = TenantMedia::create([
                        'model_type'            => TdsPayment::class,
                        'model_id'              => 0,
                        'uuid'                  => (string) Str::uuid(),
                        'collection_name'       => 'tds_challan_receipts',
                        'name'                  => pathinfo($origName, PATHINFO_FILENAME),
                        'file_name'             => $origName,
                        'mime_type'             => $file->getMimeType() ?: 'application/octet-stream',
                        'disk'                  => 'public',
                        'size'                  => $file->getSize(),
                        'manipulations'         => [],
                        'custom_properties'     => [
                            'stored_path' => $storedPath,
                        ],
                        'generated_conversions' => [],
                        'responsive_images'     => [],
                    ]);

                    $validated['media_id'] = $media->id;
                }

                $validated['created_by'] = auth()->id();
                $payment = TdsPayment::create($validated);

                if (isset($media)) {
                    $media->update(['model_id' => $payment->id]);
                }

                activityLog($payment, 'Created', [
                    'message'      => 'TDS Payment / Challan recorded: ' . $payment->challan_no . ' (₹' . number_format((float) $payment->total_amount, 2) . ')',
                    'challan_no'   => $payment->challan_no,
                    'total_amount' => $payment->total_amount,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.tds', ['tab' => 'tds-payments'])
                    ->with('success', 'TDS Payment / Challan created successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                \Illuminate\Support\Facades\Log::error('Failed to create TDS Payment', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString(),
                ]);

                return back()->withInput()->with('error', 'Failed to create TDS Payment: ' . $e->getMessage());
            }
        }
    ```
  - **After — `store()`:**
    ```php
        public function store(TdsPaymentRequest $request): RedirectResponse
        {
            $validated = $request->validated();
            $validated['created_by'] = auth()->id();

            DB::transaction(function () use ($request, $validated): void {
                $payment = TdsPayment::create($validated);

                $this->storeChallanMedia($request, $payment);

                activityLog($payment, 'Created', [
                    'message'      => 'TDS Payment / Challan recorded: ' . $payment->challan_no . ' (₹' . number_format((float) $payment->total_amount, 2) . ')',
                    'challan_no'   => $payment->challan_no,
                    'total_amount' => $payment->total_amount,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-payments'])
                ->with('success', 'TDS Payment / Challan created successfully.');
        }
    ```
  - **Before — `show()` and `edit()` (`TdsPaymentController.php:106-132`):**
    ```php
        public function show(TdsPayment $tdsPayment)
        {
            Gate::authorize('tenant.accounting.tds-payment.view');

            $tdsPayment->load([
                'financialYear',
                'bankLedger',
                'voucher',
                'media',
                'creator',
                'allocations.tdsDeduction.partyLedger',
            ]);

            return view('accounting::tds-payment.show', compact('tdsPayment'));
        }

        public function edit(TdsPayment $tdsPayment)
        {
            Gate::authorize('tenant.accounting.tds-payment.update');

            $tdsPayment->loadMissing('media');
            $bankLedgers = Ledger::selectableBankAccounts();
            $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
            $vouchers = Voucher::orderByDesc('voucher_date')->limit(50)->get();

            return view('accounting::tds-payment.edit', compact('tdsPayment', 'bankLedgers', 'financialYears', 'vouchers'));
        }
    ```
  - **After — `show()` and `edit()`:**
    ```php
        public function show(TdsPayment $tdsPayment): View
        {
            Gate::authorize('tenant.accounting.tds-payment.view');

            $tdsPayment->load([
                'financialYear',
                'bankLedger',
                'voucher',
                'media',
                'creator',
                'allocations.tdsDeduction.partyLedger',
            ]);

            return view('accounting::tds-payment.show', compact('tdsPayment'));
        }

        public function edit(TdsPayment $tdsPayment): View
        {
            Gate::authorize('tenant.accounting.tds-payment.update');

            $tdsPayment->loadMissing('media');
            $bankLedgers = Ledger::selectableBankAccounts();
            $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
            $vouchers = Voucher::orderByDesc('voucher_date')->limit(50)->get();

            return view('accounting::tds-payment.edit', compact('tdsPayment', 'bankLedgers', 'financialYears', 'vouchers'));
        }
    ```
  - **Before — `update()` (`TdsPaymentController.php:134-191`):**
    ```php
        public function update(TdsPaymentRequest $request, TdsPayment $tdsPayment)
        {
            Gate::authorize('tenant.accounting.tds-payment.update');

            DB::beginTransaction();
            try {
                $validated = $request->validated();

                if ($request->hasFile('challan_file')) {
                    $file = $request->file('challan_file');
                    $origName = $file->getClientOriginalName();
                    $tenantPrefix = TenantPathPrefix::get();
                    $targetDir = $tenantPrefix !== '' ? rtrim($tenantPrefix, '/') . '/accounting/tds-challans' : 'accounting/tds-challans';
                    $storedPath = $file->store($targetDir, 'public');

                    $media = TenantMedia::create([
                        'model_type'            => TdsPayment::class,
                        'model_id'              => $tdsPayment->id,
                        'uuid'                  => (string) Str::uuid(),
                        'collection_name'       => 'tds_challan_receipts',
                        'name'                  => pathinfo($origName, PATHINFO_FILENAME),
                        'file_name'             => $origName,
                        'mime_type'             => $file->getMimeType() ?: 'application/octet-stream',
                        'disk'                  => 'public',
                        'size'                  => $file->getSize(),
                        'manipulations'         => [],
                        'custom_properties'     => [
                            'stored_path' => $storedPath,
                        ],
                        'generated_conversions' => [],
                        'responsive_images'     => [],
                    ]);

                    $validated['media_id'] = $media->id;
                }

                $tdsPayment->update($validated);

                activityLog($tdsPayment, 'Updated', [
                    'message'      => 'TDS Payment / Challan updated: ' . $tdsPayment->challan_no,
                    'challan_no'   => $tdsPayment->challan_no,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.tds', ['tab' => 'tds-payments'])
                    ->with('success', 'TDS Payment updated successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                \Illuminate\Support\Facades\Log::error('Failed to update TDS Payment', [
                    'id'    => $tdsPayment->id,
                    'error' => $e->getMessage(),
                ]);

                return back()->withInput()->with('error', 'Failed to update TDS Payment: ' . $e->getMessage());
            }
        }
    ```
  - **After — `update()`:**
    ```php
        public function update(TdsPaymentRequest $request, TdsPayment $tdsPayment): RedirectResponse
        {
            $previousMedia = $tdsPayment->media;
            $validated = $request->validated();

            DB::transaction(function () use ($request, $validated, $tdsPayment): void {
                $tdsPayment->update($validated);

                $this->storeChallanMedia($request, $tdsPayment);

                activityLog($tdsPayment, 'Updated', [
                    'message'      => 'TDS Payment / Challan updated: ' . $tdsPayment->challan_no,
                    'challan_no'   => $tdsPayment->challan_no,
                    'performed_by' => auth()->id(),
                ]);
            });

            if ($previousMedia !== null && (int) $previousMedia->getKey() !== (int) $tdsPayment->media_id) {
                $this->deleteChallanMedia($previousMedia);
            }

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-payments'])
                ->with('success', 'TDS Payment updated successfully.');
        }
    ```
  - **Before — `downloadReceipt()` (`TdsPaymentController.php:193-213`):**
    ```php
        public function downloadReceipt(TdsPayment $tdsPayment)
        {
            Gate::authorize('tenant.accounting.tds-payment.view');

            $tdsPayment->loadMissing('media');
            $media = $tdsPayment->media;
            if (! $media) {
                return back()->with('error', 'No challan receipt document is attached to this payment.');
            }

            $storedPath = $media->custom_properties['stored_path'] ?? null;
            if ($storedPath && Storage::disk('public')->exists($storedPath)) {
                return Storage::disk('public')->download($storedPath, $media->file_name);
            }

            if (!empty($media->file_name) && Storage::disk($media->disk ?? 'public')->exists($media->file_name)) {
                return Storage::disk($media->disk ?? 'public')->download($media->file_name, $media->file_name);
            }

            return back()->with('error', 'Challan receipt file could not be found in storage.');
        }
    ```
  - **After — `downloadReceipt()`:**
    ```php
        public function downloadReceipt(TdsPayment $tdsPayment): StreamedResponse|RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-payment.view');

            $tdsPayment->loadMissing('media');
            $media = $tdsPayment->media;
            if (! $media) {
                return back()->with('error', 'No challan receipt document is attached to this payment.');
            }

            $disk = $media->disk ?? 'local';
            $storedPath = $media->custom_properties['stored_path'] ?? null;
            if ($storedPath !== null && Storage::disk($disk)->exists($storedPath)) {
                return Storage::disk($disk)->download($storedPath, $media->file_name);
            }

            if (! empty($media->file_name) && Storage::disk($disk)->exists($media->file_name)) {
                return Storage::disk($disk)->download($media->file_name, $media->file_name);
            }

            return back()->with('error', 'Challan receipt file could not be found in storage.');
        }
    ```
  - **Before — `destroy()` (`TdsPaymentController.php:215-239`):**
    ```php
        public function destroy(TdsPayment $tdsPayment)
        {
            Gate::authorize('tenant.accounting.tds-payment.delete');

            DB::beginTransaction();
            try {
                $tdsPayment->delete();

                activityLog($tdsPayment, 'Deleted', [
                    'message'      => 'TDS Payment moved to trash: ' . $tdsPayment->challan_no,
                    'challan_no'   => $tdsPayment->challan_no,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.tds', ['tab' => 'tds-payments'])
                    ->with('success', 'TDS Payment moved to trash.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to delete TDS Payment', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to delete TDS Payment: ' . $e->getMessage());
            }
        }
    ```
  - **After — `destroy()`:**
    ```php
        public function destroy(TdsPayment $tdsPayment): RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-payment.delete');

            DB::transaction(function () use ($tdsPayment): void {
                $tdsPayment->delete();

                activityLog($tdsPayment, 'Deleted', [
                    'message'      => 'TDS Payment moved to trash: ' . $tdsPayment->challan_no,
                    'challan_no'   => $tdsPayment->challan_no,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-payments'])
                ->with('success', 'TDS Payment moved to trash.');
        }
    ```
  - **Before — `toggleStatus()` (`TdsPaymentController.php:241-267`):**
    ```php
        public function toggleStatus(Request $request, TdsPayment $tdsPayment)
        {
            Gate::authorize('tenant.accounting.tds-payment.update');

            $request->validate(['is_active' => 'required|boolean']);

            DB::beginTransaction();
            try {
                $tdsPayment->is_active = $request->input('is_active');
                $tdsPayment->save();

                activityLog($tdsPayment, 'Toggled', [
                    'message'      => 'TDS Payment status toggled: ' . $tdsPayment->challan_no,
                    'challan_no'   => $tdsPayment->challan_no,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return response()->json(['success' => true, 'is_active' => $tdsPayment->is_active, 'message' => 'Status updated.']);
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to toggle TDS Payment status', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);

                return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
            }
        }
    ```
  - **After — `toggleStatus()`:**
    ```php
        public function toggleStatus(Request $request, TdsPayment $tdsPayment): JsonResponse
        {
            Gate::authorize('tenant.accounting.tds-payment.update');

            $request->validate(['is_active' => 'required|boolean']);

            DB::transaction(function () use ($request, $tdsPayment): void {
                $tdsPayment->is_active = $request->boolean('is_active');
                $tdsPayment->save();

                activityLog($tdsPayment, 'Toggled', [
                    'message'      => 'TDS Payment status toggled: ' . $tdsPayment->challan_no,
                    'challan_no'   => $tdsPayment->challan_no,
                    'performed_by' => auth()->id(),
                ]);
            });

            return response()->json(['success' => true, 'is_active' => $tdsPayment->is_active, 'message' => 'Status updated.']);
        }
    ```
  - **Before — `changeStatus()` (`TdsPaymentController.php:269-295`):**
    ```php
        public function changeStatus(Request $request, TdsPayment $tdsPayment)
        {
            Gate::authorize('tenant.accounting.tds-payment.update');

            $request->validate(['status' => 'required|in:Draft,Paid,Allocated,Filed,Cancelled']);

            DB::beginTransaction();
            try {
                $tdsPayment->status = $request->input('status');
                $tdsPayment->save();

                activityLog($tdsPayment, 'StatusChanged', [
                    'message'      => 'TDS Payment status changed to ' . $tdsPayment->status,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.tds', ['tab' => 'tds-payments'])
                    ->with('success', 'Status updated successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to change TDS Payment status', ['id' => $tdsPayment->id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to update status: ' . $e->getMessage());
            }
        }
    ```
  - **After — `changeStatus()`:**
    ```php
        public function changeStatus(Request $request, TdsPayment $tdsPayment): RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-payment.update');

            $request->validate(['status' => 'required|in:Draft,Paid,Allocated,Filed,Cancelled']);

            DB::transaction(function () use ($request, $tdsPayment): void {
                $tdsPayment->status = $request->input('status');
                $tdsPayment->save();

                activityLog($tdsPayment, 'StatusChanged', [
                    'message'      => 'TDS Payment status changed to ' . $tdsPayment->status,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-payments'])
                ->with('success', 'Status updated successfully.');
        }
    ```
  - **Before — `restore()` (`TdsPaymentController.php:306-331`):**
    ```php
        public function restore($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-payment.restore');

            DB::beginTransaction();
            try {
                $model = TdsPayment::onlyTrashed()->findOrFail($id);
                $model->restore();
                $model->update(['is_active' => true]);

                activityLog($model, 'Restored', [
                    'message'      => 'TDS Payment restored: ' . $model->challan_no,
                    'challan_no'   => $model->challan_no,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.tds-payment.trashed')->with('success', 'TDS Payment restored successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to restore TDS Payment', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to restore TDS Payment: ' . $e->getMessage());
            }
        }
    ```
  - **After — `restore()` plus the two new private media helpers (append both after `restore()`):**
    ```php
        public function restore($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-payment.restore');

            $model = TdsPayment::onlyTrashed()->findOrFail($id);

            DB::transaction(function () use ($model): void {
                $model->restore();
                $model->update(['is_active' => true]);

                activityLog($model, 'Restored', [
                    'message'      => 'TDS Payment restored: ' . $model->challan_no,
                    'challan_no'   => $model->challan_no,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.tds-payment.trashed')->with('success', 'TDS Payment restored successfully.');
        }

        private function storeChallanMedia(Request $request, TdsPayment $payment): void
        {
            if (! $request->hasFile('challan_file')) {
                return;
            }

            $file = $request->file('challan_file');
            $tenantPrefix = TenantPathPrefix::get();
            $targetDir = $tenantPrefix !== '' ? rtrim($tenantPrefix, '/') . '/accounting/tds-challans' : 'accounting/tds-challans';
            $storedPath = $file->store($targetDir, 'local');

            $media = TenantMedia::create([
                'model_type'            => TdsPayment::class,
                'model_id'              => $payment->id,
                'uuid'                  => (string) Str::uuid(),
                'collection_name'       => 'tds_challan_receipts',
                'name'                  => pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME),
                'file_name'             => $file->getClientOriginalName(),
                'mime_type'             => $file->getMimeType() ?: 'application/octet-stream',
                'disk'                  => 'local',
                'size'                  => $file->getSize(),
                'manipulations'         => [],
                'custom_properties'     => [
                    'stored_path' => $storedPath,
                ],
                'generated_conversions' => [],
                'responsive_images'     => [],
            ]);

            $payment->update(['media_id' => $media->id]);
        }

        private function deleteChallanMedia(TenantMedia $media): void
        {
            $storedPath = $media->custom_properties['stored_path'] ?? null;

            if ($storedPath !== null) {
                Storage::disk($media->disk ?? 'local')->delete($storedPath);
            }

            $media->delete();
        }
    ```
  - **Before — `forceDelete()` (`TdsPaymentController.php:333-358`):**
    ```php
        public function forceDelete($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-payment.forceDelete');

            DB::beginTransaction();
            try {
                $model = TdsPayment::withTrashed()->findOrFail($id);
                $cNo = $model->challan_no;
                $model->forceDelete();

                activityLog($model, 'Deleted', [
                    'message'      => 'TDS Payment permanently deleted: ' . $cNo,
                    'challan_no'   => $cNo,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.tds-payment.trashed')->with('success', 'TDS Payment permanently deleted.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to force delete TDS Payment', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to delete TDS Payment: ' . $e->getMessage());
            }
        }
    ```
  - **After — `forceDelete()`:**
    ```php
        public function forceDelete($id): RedirectResponse
        {
            Gate::authorize('tenant.accounting.tds-payment.forceDelete');

            $payment = TdsPayment::withTrashed()->findOrFail($id);

            if ($payment->allocations()->exists()) {
                throw new \DomainException('This TDS payment has allocations and cannot be permanently deleted.');
            }

            $challanNo = $payment->challan_no;
            $media = $payment->media;

            DB::transaction(function () use ($payment, $challanNo): void {
                $payment->forceDelete();

                activityLog($payment, 'Deleted', [
                    'message'      => 'TDS Payment permanently deleted: ' . $challanNo,
                    'challan_no'   => $challanNo,
                    'performed_by' => auth()->id(),
                ]);
            });

            if ($media !== null) {
                $this->deleteChallanMedia($media);
            }

            return redirect()->route('accounting.tds-payment.trashed')->with('success', 'TDS Payment permanently deleted.');
        }
    ```
  - **Before — receipt preview (`edit.blade.php:155-161`):**
    ```blade
                                        <x-backend.form.image-with-preview
                                            name="challan_file"
                                            id="edit_challan_file"
                                            label="Upload / Replace Challan Receipt (PDF, Image)"
                                            image="{{ $tdsPayment->media ? asset('storage/' . ($tdsPayment->media->custom_properties['stored_path'] ?? '')) : '' }}"
                                            accept=".pdf,image/*"
                                        />
    ```
  - **After — receipt preview:**
    ```blade
                                        <x-backend.form.image-with-preview
                                            name="challan_file"
                                            id="edit_challan_file"
                                            label="Upload / Replace Challan Receipt (PDF, Image)"
                                            image="{{ $tdsPayment->media ? route('accounting.tds-payment.downloadReceipt', $tdsPayment) : '' }}"
                                            accept=".pdf,image/*"
                                        />
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php","Modules\Accounting\resources\views\tds-payment\edit.blade.php" -Pattern "beginTransaction|catch \(|getMessage|Log::|store\(.*public|asset\('storage"`
  - **Expect:** no output. The only remaining `store(` is `$file->store($targetDir, 'local')` in the helper.
  - **Effort:** L

- [ ] **TDSP-10** · B · VAL-07 · `TdsPaymentRequest.php:46, 75, 103` — stop accepting and merging the derived `allocated_amount`; after this item only `TdsPaymentAllocationController` writes that column, so a normal edit can no longer reset it to zero.
  - **Touches:** `Modules/Accounting/app/Http/Requests/TdsPaymentRequest.php`
  - **Before — rule (`TdsPaymentRequest.php:45-47`):**
    ```php
                'total_amount'           => ['required', 'numeric', 'min:0'],
                'allocated_amount'       => ['nullable', 'numeric', 'min:0', 'lte:total_amount'],
                'bank_ledger_id'         => ['nullable', 'exists:acc_ledgers,id'],
    ```
  - **After — rule:**
    ```php
                'total_amount'           => ['required', 'numeric', 'min:0'],
                'bank_ledger_id'         => ['nullable', 'exists:acc_ledgers,id'],
    ```
  - **Before — attribute (`TdsPaymentRequest.php:74-76`):**
    ```php
                'total_amount'           => 'Total Amount',
                'allocated_amount'       => 'Allocated Amount',
                'bank_ledger_id'         => 'Bank Ledger',
    ```
  - **After — attribute:**
    ```php
                'total_amount'           => 'Total Amount',
                'bank_ledger_id'         => 'Bank Ledger',
    ```
  - **Before — merge (`TdsPaymentRequest.php:96-105`):**
    ```php
            $this->merge([
                'is_active'        => $this->boolean('is_active', true),
                'surcharge'        => $surcharge,
                'cess'             => $cess,
                'interest'         => $interest,
                'late_fee'         => $lateFee,
                'total_amount'     => $total,
                'allocated_amount' => (float) $this->input('allocated_amount', 0),
                'status'           => $this->input('status', 'Draft'),
            ]);
    ```
  - **After — merge:**
    ```php
            $this->merge([
                'is_active'        => $this->boolean('is_active', true),
                'surcharge'        => $surcharge,
                'cess'             => $cess,
                'interest'         => $interest,
                'late_fee'         => $lateFee,
                'total_amount'     => $total,
                'status'           => $this->input('status', 'Draft'),
            ]);
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\TdsPaymentRequest.php" -Pattern "allocated_amount"`
  - **Expect:** no output.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

No standalone items. **Sequencing note:** TDSP-10 (§1) must land before TDSP-08 unlocks the screen. TDSP-11 is a §5 item but it also arms a 500 once other roles reach the form; if TDSP-11 and TDSP-08 are both ticked, run the fixer for TDSP-11 alone first, then run it for TDSP-08.

## 3. Errors & transactions (F1/F2)

No separate items. TDSP-01 rewrites all seven mutations (`store`, `update`, `destroy`, `toggleStatus`, `changeStatus`, `restore`, `forceDelete`), removes the five unresolved `Log::` references and the seven manual transaction blocks, and lets the central handler render and log failures. It resolves TDSP-02, TDSP-03, TDSP-04 and TDSP-05.

## 4. Authorization (F3)

- [ ] **TDSP-08** · B · DECISION · AUTH-01 — the `tenant.accounting.tds-payment.*` namespace is absent from `config/permissionslist.php` and from the live tenant, so only Super Admin can reach any route.
  - **Why it is a decision:** it adds a new permission key and needs a permission sync plus role grants; both are Tarun's hand (`/system-config/sync-permissions`). The file is ⚠ SHARED.
  - (a) ⭐ Add `'accounting.tds-payment' => $crud,` directly after `'accounting.tax-rate' => $crud,` at `config/permissionslist.php:614`, run the sync, then grant the seven new keys (`create`, `view`, `viewAny`, `update`, `delete`, `restore`, `forceDelete`) to School Admin, Management, Account Staff and Account Manager. Apply TDSP-01, TDSP-10 and TDSP-11 before granting.
  - (b) Grant the existing `tenant.accounting.dashboard.*` keys to those roles and leave the controller literals unchanged. This makes the screen reachable but leaves the dead namespace in code and hides the real permission model.
  - (c) Leave as is and record the feature as Super-Admin-only.
  - ➜ Choice: ____

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **TDSP-11** · H · VAL-04 · `TdsPaymentRequest.php:28-36` — make the challan uniqueness rule match the real unique index, which includes soft-deleted rows.
  - **Touches:** `Modules/Accounting/app/Http/Requests/TdsPaymentRequest.php`
  - **Before** (`TdsPaymentRequest.php:28-36`):
    ```php
                'challan_no'             => [
                    'required',
                    'string',
                    'max:50',
                    Rule::unique('acc_tds_payments', 'challan_no')
                        ->where(fn($q) => $q->where('challan_date', $this->input('challan_date')))
                        ->ignore($id)
                        ->withoutTrashed(),
                ],
    ```
  - **After:**
    ```php
                'challan_no'             => [
                    'required',
                    'string',
                    'max:50',
                    Rule::unique('acc_tds_payments', 'challan_no')
                        ->where(fn($q) => $q->where('challan_date', $this->input('challan_date')))
                        ->ignore($id),
                ],
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\TdsPaymentRequest.php" -Pattern "withoutTrashed"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **TDSP-12** · M · VAL-05 · `TdsPaymentRequest.php:97` — let an unchecked Active Record checkbox stay false instead of being forced back to true.
  - **Touches:** `Modules/Accounting/app/Http/Requests/TdsPaymentRequest.php`
  - **Before** (`TdsPaymentRequest.php:97`):
    ```php
                'is_active'        => $this->boolean('is_active', true),
    ```
  - **After:**
    ```php
                'is_active'        => $this->boolean('is_active'),
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\TdsPaymentRequest.php" -Pattern "boolean\('is_active'"`
  - **Expect:** one line ending `$this->boolean('is_active'),` with no second argument.
  - **Effort:** S

- [ ] **TDSP-13** · H · RTE-01 · `routes/web.php:473` + `trash.blade.php:38-40` — restore over POST with CSRF instead of GET. ⚠ SHARED
  - **Touches:** `Modules/Accounting/routes/web.php`, `Modules/Accounting/resources/views/tds-payment/trash.blade.php`
  - **Before — route (`web.php:473`):**
    ```php
    Route::get('/tds-payment/{id}/restore', [TdsPaymentController::class, 'restore'])->name('tds-payment.restore');
    ```
  - **After — route:**
    ```php
    Route::post('/tds-payment/{id}/restore', [TdsPaymentController::class, 'restore'])->name('tds-payment.restore');
    ```
  - **Before — view (`trash.blade.php:38-40`):**
    ```blade
                                            <a href="{{ route('accounting.tds-payment.restore', $pay->id) }}" class="btn btn-sm btn-outline-success">
                                                <i class="fa-solid fa-rotate-left me-1"></i> Restore
                                            </a>
    ```
  - **After — view:**
    ```blade
                                            <form action="{{ route('accounting.tds-payment.restore', $pay->id) }}" method="POST" class="d-inline">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-outline-success">
                                                    <i class="fa-solid fa-rotate-left me-1"></i> Restore
                                                </button>
                                            </form>
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "tds-payment/\{id\}/restore"`
  - **Expect:** one POST line for the same URI and no GET line.
  - **Effort:** S

- [ ] **TDSP-19** · M · MDL-02 · `TdsPayment.php:42-54` — cast the boolean and enum columns.
  - **Touches:** `Modules/Accounting/app/Models/TdsPayment.php`
  - **Before** (`TdsPayment.php:42-54`):
    ```php
        protected $casts = [
            'quarter'          => 'integer',
            'challan_date'     => 'date',
            'deposit_date'     => 'date',
            'tax_amount'       => 'decimal:2',
            'surcharge'        => 'decimal:2',
            'cess'             => 'decimal:2',
            'interest'         => 'decimal:2',
            'late_fee'         => 'decimal:2',
            'total_amount'     => 'decimal:2',
            'allocated_amount' => 'decimal:2',
            'return_filed_on'  => 'date',
        ];
    ```
  - **After:**
    ```php
        protected $casts = [
            'quarter'          => 'integer',
            'challan_date'     => 'date',
            'deposit_date'     => 'date',
            'tax_amount'       => 'decimal:2',
            'surcharge'        => 'decimal:2',
            'cess'             => 'decimal:2',
            'interest'         => 'decimal:2',
            'late_fee'         => 'decimal:2',
            'total_amount'     => 'decimal:2',
            'allocated_amount' => 'decimal:2',
            'return_filed_on'  => 'date',
            'is_active'        => 'boolean',
            'status'           => 'string',
        ];
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Models\TdsPayment.php" -Pattern "'is_active' => 'boolean'|'status' => 'string'"`
  - **Expect:** two lines inside `$casts`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **TDSP-20** · M · QRY-02 · `TdsPaymentController.php:301` — paginate the trash list at the standard 10 with its own page name and keep the query string.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php`
  - **Before** (`TdsPaymentController.php:301`):
    ```php
            $payments = TdsPayment::onlyTrashed()->with(['bankLedger', 'financialYear'])->orderByDesc('deposit_date')->paginate(15);
    ```
  - **After:**
    ```php
            $payments = TdsPayment::onlyTrashed()->with(['bankLedger', 'financialYear'])->orderByDesc('deposit_date')->paginate(10, ['*'], 'trash_page')->withQueryString();
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" -Pattern "paginate\(10, \['\*'\], 'trash_page'\)->withQueryString\(\)"`
  - **Expect:** one line.
  - **Effort:** S

## 7. Views (F10)

No separate items. The only blade defect — the direct `asset('storage/…')` receipt preview — is fixed inside TDSP-01.

## 8. Style (F12) — one item per file

- [ ] **TDSP-23** · L · STY-02 — run Pint on the three in-scope PHP files.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TdsPaymentController.php`, `Modules/Accounting/app/Models/TdsPayment.php`, `Modules/Accounting/app/Http/Requests/TdsPaymentRequest.php`
  - **Before:** `pint --test` reports `fail` for all three (finding TDSP-23 in `01-report.md` §6).
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\TdsPaymentController.php Modules\Accounting\app\Models\TdsPayment.php Modules\Accounting\app\Http\Requests\TdsPaymentRequest.php --format agent` (never `--dirty`).
  - **Verify:** `vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\TdsPaymentController.php" "Modules\Accounting\app\Models\TdsPayment.php" "Modules\Accounting\app\Http\Requests\TdsPaymentRequest.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"passed"}`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **TDSP-15** · M · DECISION · CTL-10 — `create()` returns a blade that does not exist and no UI links to the route.
  - **Why it is a decision:** removing the route changes a reachable URL (§9.3); adding a full-page form duplicates the list-tab create modal.
  - (a) ⭐ Remove the routed create page and keep the modal: change `Route::resource('tds-payment', TdsPaymentController::class);` at `Modules/Accounting/routes/web.php:478` to `->except(['create'])`, then replace the body of `create()` with `abort(403, 'This page is not routed. Use the create modal on the TDS Management tab.');` and change its signature from `: View` to `: never`. ⚠ SHARED route file.
  - (b) Add `Modules/Accounting/resources/views/tds-payment/create.blade.php` (copy the modal fields into a page) and link it from the list tab; keep the route and the `: View` signature from TDSP-01.
  - (c) Leave as is and record the 500 as accepted.
  - ➜ Choice: ____

- [ ] **TDSP-18** · L · DECISION · CTL-10 — the status-toggle and status-change routes have no caller in any view.
  - **Why it is a decision:** removing endpoints changes reachable URLs; wiring the status switch requires the `_tds-payments.blade.php` partial, which belongs to the `AccDashboardController` report.
  - (a) ⭐ Accept the two endpoints as internal API surface: keep `toggleStatus()` and `changeStatus()` and their routes at `web.php:476-477`, and record that no blade calls them. No file changes.
  - (b) Remove `toggleStatus()` and `changeStatus()` and the two routes at `web.php:476-477`. ⚠ SHARED route file. The edit form still saves `status` and `is_active`.
  - (c) Wire a status switch into the list tab — the `_tds-payments.blade.php` partial is owned by the `AccDashboardController` report, so that report's owner must make the change.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TDSP-07 | A rolled-back upload can leave an orphan file, because the file is stored inside the transaction. Moving it after commit needs a two-phase media row and a cleanup job; no user data is lost, only storage bytes. Accepted as debt. |
| TDSP-16 | `restore()`/`forceDelete()` use `{id}` + `findOrFail()` instead of route-model binding. The current code is correct; binding a trashed model needs `->withTrashed()` in the shared route file and buys nothing user-visible. Accepted as debt. |
| TDSP-21 | The create/edit dropdowns load whole models. Live rows are 10 ledgers, 1 financial year and 2 vouchers, and the voucher option uses the `voucher_display_no` accessor, so a column whitelist must be checked against that accessor first. Accepted as debt. |
