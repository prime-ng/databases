# Fix Plan — Accounting / ChequeRegisterController

**From:** `01-report.md` (2026-10-24) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/app/Models/ChequeLeaf.php` | owned by [gaurav/Accounting/ChequeLeafController](../ChequeLeafController/01-report.md) |
| `Modules/Accounting/app/Models/Ledger.php` | owned by [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | owned by [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) |
| `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_cheque-registers.blade.php` | rendered by `AccDashboardController`, not by this controller |
| `resources/views/components/backend/table/action-trashed.blade.php` | shared component (no change is needed — it already emits `@csrf` for non-GET routes) |
| `database/migrations/**` | migrations are never edited; the schema is read-only evidence |
| `final-audit-reports/00-CLASS-OWNERS.md`, `final-audit-reports/gaurav/Accounting/00-INDEX.md` | registry/index files; the auditor must not edit them |

`Modules/Accounting/routes/web.php` is edited **only** by CHQR-07, which is marked `⚠ SHARED`.

## 1. Blockers reachable today

- [ ] **CHQR-11** · B · SVC-04 · `Modules/Accounting/app/Models/ChequeRegister.php:38-68` — remove the `created` hook so leaf stock is generated once, not twice; this makes creating a register work at all.
  - **Touches:** `Modules/Accounting/app/Models/ChequeRegister.php`
  - **Before** (`ChequeRegister.php:38-68`):
    ```php
    protected static function booted(): void
    {
        parent::booted();

        static::creating(function (self $model): void {
            if (empty($model->total_leaves) && !empty($model->start_leaf_no) && !empty($model->end_leaf_no)) {
                $model->total_leaves = max(1, (int) ($model->end_leaf_no - $model->start_leaf_no + 1));
            }
            if (empty($model->status)) {
                $model->status = 'Active';
            }
        });

        static::created(function (self $model): void {
            if (!empty($model->start_leaf_no) && !empty($model->end_leaf_no)) {
                $leaves = [];
                $now = now();
                for ($leaf = (int) $model->start_leaf_no; $leaf <= (int) $model->end_leaf_no; $leaf++) {
                    $leaves[] = [
                        'cheque_register_id' => $model->id,
                        'bank_ledger_id'     => $model->bank_ledger_id,
                        'leaf_no'            => $leaf,
                        'status'             => 'Unused',
                        'created_at'         => $now,
                        'updated_at'         => $now,
                    ];
                }
                ChequeLeaf::insert($leaves);
            }
        });
    }
    ```
  - **After:**
    ```php
    protected static function booted(): void
    {
        parent::booted();

        static::creating(function (self $model): void {
            if (empty($model->total_leaves) && !empty($model->start_leaf_no) && !empty($model->end_leaf_no)) {
                $model->total_leaves = max(1, (int) ($model->end_leaf_no - $model->start_leaf_no + 1));
            }
            if (empty($model->status)) {
                $model->status = 'Active';
            }
        });
    }
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Models\ChequeRegister.php -Pattern "static::created|ChequeLeaf::insert"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CHQR-01** · B · ERR-01 · `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php:34-83,109-138,140-164,166-192` — stop sending `$e->getMessage()` to the user; drop the try/catch and use `DB::transaction` (D1), for `store`, `update`, `destroy` and `toggleStatus`.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php`
  - **Before** (`ChequeRegisterController.php:34-83`):
    ```php
    public function store(ChequeRegisterRequest $request)
    {
        Gate::authorize('tenant.accounting.cheque-register.create');

        $validated = $request->validated();

        DB::beginTransaction();
        try {
            $validated['total_leaves'] = (int) $validated['end_leaf_no'] - (int) $validated['start_leaf_no'] + 1;
            $validated['created_by'] = auth()->id();
            $chequeRegister = ChequeRegister::create($validated);

            // Generate individual cheque leaves stock
            $leaves = [];
            $now = now();
            for ($i = (int) $validated['start_leaf_no']; $i <= (int) $validated['end_leaf_no']; $i++) {
                $leaves[] = [
                    'cheque_register_id' => $chequeRegister->id,
                    'bank_ledger_id'     => $chequeRegister->bank_ledger_id,
                    'leaf_no'            => $i,
                    'status'             => 'Unused',
                    'created_at'         => $now,
                    'updated_at'         => $now,
                    'is_active'          => 1,
                ];
            }
            if (!empty($leaves)) {
                \Modules\Accounting\Models\ChequeLeaf::insert($leaves);
            }

            activityLog($chequeRegister, 'Created', [
                'message'      => 'Cheque Register created: ' . $chequeRegister->book_number,
                'book_number'  => $chequeRegister->book_number,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-registers'])
                ->with('success', 'Cheque Register created successfully and ' . count($leaves) . ' leaves generated.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Cheque Register', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Cheque Register: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`store`):
    ```php
    public function store(ChequeRegisterRequest $request)
    {
        Gate::authorize('tenant.accounting.cheque-register.create');

        $validated = $request->validated();
        $validated['total_leaves'] = (int) $validated['end_leaf_no'] - (int) $validated['start_leaf_no'] + 1;
        $validated['created_by'] = auth()->id();

        $chequeRegister = DB::transaction(function () use ($validated) {
            $chequeRegister = ChequeRegister::create($validated);

            $leaves = [];
            $now = now();
            for ($i = (int) $validated['start_leaf_no']; $i <= (int) $validated['end_leaf_no']; $i++) {
                $leaves[] = [
                    'cheque_register_id' => $chequeRegister->id,
                    'bank_ledger_id'     => $chequeRegister->bank_ledger_id,
                    'leaf_no'            => $i,
                    'status'             => 'Unused',
                    'created_at'         => $now,
                    'updated_at'         => $now,
                    'is_active'          => 1,
                ];
            }
            if (!empty($leaves)) {
                \Modules\Accounting\Models\ChequeLeaf::insert($leaves);
            }

            activityLog($chequeRegister, 'Created', [
                'message'      => 'Cheque Register created: ' . $chequeRegister->book_number,
                'book_number'  => $chequeRegister->book_number,
                'performed_by' => auth()->id(),
            ]);

            return $chequeRegister;
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-registers'])
            ->with('success', 'Cheque Register created successfully and ' . (int) $validated['total_leaves'] . ' leaves generated.');
    }
    ```
  - **Before** (`ChequeRegisterController.php:109-138`):
    ```php
    public function update(ChequeRegisterRequest $request, ChequeRegister $chequeRegister)
    {
        Gate::authorize('tenant.accounting.cheque-register.update');

        DB::beginTransaction();
        try {
            $validated = $request->validated();
            $validated['updated_by'] = auth()->id();
            $chequeRegister->update($validated);

            activityLog($chequeRegister, 'Updated', [
                'message'      => 'Cheque Register updated: ' . $chequeRegister->book_number,
                'book_number'  => $chequeRegister->book_number,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-registers'])
                ->with('success', 'Cheque Register updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to update Cheque Register', [
                'id'    => $chequeRegister->id,
                'error' => $e->getMessage(),
            ]);

            return back()->withInput()->with('error', 'Failed to update Cheque Register: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`update`):
    ```php
    public function update(ChequeRegisterRequest $request, ChequeRegister $chequeRegister)
    {
        Gate::authorize('tenant.accounting.cheque-register.update');

        $validated = $request->validated();
        $validated['updated_by'] = auth()->id();

        DB::transaction(function () use ($chequeRegister, $validated) {
            $chequeRegister->update($validated);

            activityLog($chequeRegister, 'Updated', [
                'message'      => 'Cheque Register updated: ' . $chequeRegister->book_number,
                'book_number'  => $chequeRegister->book_number,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-registers'])
            ->with('success', 'Cheque Register updated successfully.');
    }
    ```
  - **Before** (`ChequeRegisterController.php:140-164`):
    ```php
    public function destroy(ChequeRegister $chequeRegister)
    {
        Gate::authorize('tenant.accounting.cheque-register.delete');

        DB::beginTransaction();
        try {
            $chequeRegister->delete();

            activityLog($chequeRegister, 'Deleted', [
                'message'      => 'Cheque Register moved to trash: ' . $chequeRegister->book_number,
                'book_number'  => $chequeRegister->book_number,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-registers'])
                ->with('success', 'Cheque Register moved to trash.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to delete Cheque Register', ['id' => $chequeRegister->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Cheque Register: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`destroy`):
    ```php
    public function destroy(ChequeRegister $chequeRegister)
    {
        Gate::authorize('tenant.accounting.cheque-register.delete');

        DB::transaction(function () use ($chequeRegister) {
            $chequeRegister->delete();

            activityLog($chequeRegister, 'Deleted', [
                'message'      => 'Cheque Register moved to trash: ' . $chequeRegister->book_number,
                'book_number'  => $chequeRegister->book_number,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-registers'])
            ->with('success', 'Cheque Register moved to trash.');
    }
    ```
  - **Before** (`ChequeRegisterController.php:166-192`):
    ```php
    public function toggleStatus(Request $request, ChequeRegister $chequeRegister)
    {
        Gate::authorize('tenant.accounting.cheque-register.update');

        $request->validate(['status' => 'required|string']);

        DB::beginTransaction();
        try {
            $chequeRegister->status = $request->input('status');
            $chequeRegister->save();

            activityLog($chequeRegister, 'Toggled', [
                'message'      => 'Cheque Register status toggled: ' . $chequeRegister->book_number,
                'book_number'  => $chequeRegister->book_number,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return response()->json(['success' => true, 'status' => $chequeRegister->status, 'message' => 'Status updated.']);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to toggle Cheque Register status', ['id' => $chequeRegister->id, 'error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
        }
    }
    ```
  - **After** (`toggleStatus`):
    ```php
    public function toggleStatus(Request $request, ChequeRegister $chequeRegister)
    {
        Gate::authorize('tenant.accounting.cheque-register.update');

        $request->validate(['status' => 'required|string']);

        DB::transaction(function () use ($chequeRegister, $request) {
            $chequeRegister->status = $request->input('status');
            $chequeRegister->save();

            activityLog($chequeRegister, 'Toggled', [
                'message'      => 'Cheque Register status toggled: ' . $chequeRegister->book_number,
                'book_number'  => $chequeRegister->book_number,
                'performed_by' => auth()->id(),
            ]);
        });

        return response()->json(['success' => true, 'status' => $chequeRegister->status, 'message' => 'Status updated.']);
    }
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "getMessage|beginTransaction"`
  - **Expect:** no output.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None. The two blockers above are independent of the deferred edit-time stock decision (CHQR-12), which is already reachable on seeded data.

## 3. Errors & transactions (F1/F2)

- [ ] **CHQR-02** · H · ERR-02 · `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php:204-229,231-256` — load the record before the transaction so a missing id gives a 404, and remove the try/catch that leaks the message.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php`
  - **Before** (`ChequeRegisterController.php:204-229`):
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-register.restore');

        DB::beginTransaction();
        try {
            $model = ChequeRegister::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['status' => 'Active']);

            activityLog($model, 'Restored', [
                'message'      => 'Cheque Register restored: ' . $model->book_number,
                'book_number'  => $model->book_number,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.cheque-register.trashed')->with('success', 'Cheque Register restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Cheque Register', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Cheque Register: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`restore`):
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-register.restore');

        $model = ChequeRegister::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($model) {
            $model->restore();
            $model->update(['status' => 'Active']);

            activityLog($model, 'Restored', [
                'message'      => 'Cheque Register restored: ' . $model->book_number,
                'book_number'  => $model->book_number,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.cheque-register.trashed')->with('success', 'Cheque Register restored successfully.');
    }
    ```
  - **Before** (`ChequeRegisterController.php:231-256`):
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-register.forceDelete');

        DB::beginTransaction();
        try {
            $model = ChequeRegister::withTrashed()->findOrFail($id);
            $bookNumber = $model->book_number;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Cheque Register permanently deleted: ' . $bookNumber,
                'book_number'  => $bookNumber,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.cheque-register.trashed')->with('success', 'Cheque Register permanently deleted.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to force delete Cheque Register', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Cheque Register: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`forceDelete`):
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-register.forceDelete');

        $model = ChequeRegister::withTrashed()->findOrFail($id);

        DB::transaction(function () use ($model) {
            $bookNumber = $model->book_number;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Cheque Register permanently deleted: ' . $bookNumber,
                'book_number'  => $bookNumber,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.cheque-register.trashed')->with('success', 'Cheque Register permanently deleted.');
    }
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "catch \(\\\\Throwable|findOrFail\("`
  - **Expect:** only the two `findOrFail(` lines remain, and no `catch (\Throwable` line.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **CHQR-04** · L · AUTH-04 · `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php:36,111` — remove the duplicate `Gate::authorize()` in `store`/`update`; the FormRequest already checked the same permission.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php`
  - **Before** (`store`, `ChequeRegisterController.php:36-38`):
    ```php
        Gate::authorize('tenant.accounting.cheque-register.create');

        $validated = $request->validated();
    ```
  - **After** (`store`):
    ```php
        $validated = $request->validated();
    ```
  - **Before** (`update`, `ChequeRegisterController.php:111-113`):
    ```php
        Gate::authorize('tenant.accounting.cheque-register.update');

        DB::beginTransaction();
    ```
  - **After** (`update`):
    ```php
        $validated = $request->validated();
        $validated['updated_by'] = auth()->id();
    ```
    Note: CHQR-01 already removed the `DB::beginTransaction()` line from `update`; if CHQR-01 is ticked, its rewritten body starts with `$validated = $request->validated();`. Apply CHQR-04 by deleting only the `Gate::authorize(...)` line and the blank line after it.
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "Gate::authorize" | Measure-Object | Select-Object -ExpandProperty Count`
  - **Expect:** `9` (11 minus the two removed lines).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **CHQR-05** · H · VAL-04 · `Modules/Accounting/app/Http/Requests/ChequeRegisterRequest.php:7-33` — mirror the DB unique key `(bank_ledger_id, book_number)` in the FormRequest so a duplicate is a field error, not a 500.
  - **Touches:** `Modules/Accounting/app/Http/Requests/ChequeRegisterRequest.php`
  - **Before** (`ChequeRegisterRequest.php:7-8`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use App\Traits\AuthorizesTenantFeature;
    ```
  - **After:**
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    ```
  - **Before** (`ChequeRegisterRequest.php:21-33`):
    ```php
        return [
            'bank_ledger_id' => 'required|exists:acc_ledgers,id',
            'book_number'    => 'required|string|max:50',
            'leaf_prefix'    => 'nullable|string|max:10',
            'start_leaf_no'  => 'required|integer|min:1',
            'end_leaf_no'    => 'required|integer|gte:start_leaf_no',
            'total_leaves'   => 'required|integer|min:1',
            'received_date'  => 'nullable|date',
            'status'         => 'required|in:Active,Exhausted,Cancelled,Lost',
            'notes'          => 'nullable|string|max:500',
            'is_active'      => 'required|boolean',
        ];
    ```
  - **After:**
    ```php
        return [
            'bank_ledger_id' => 'required|exists:acc_ledgers,id',
            'book_number'    => [
                'required',
                'string',
                'max:50',
                Rule::unique('acc_cheque_registers', 'book_number')
                    ->where(fn ($query) => $query->where('bank_ledger_id', $this->input('bank_ledger_id')))
                    ->ignore($this->route('cheque_register')),
            ],
            'leaf_prefix'    => 'nullable|string|max:10',
            'start_leaf_no'  => 'required|integer|min:1',
            'end_leaf_no'    => 'required|integer|gte:start_leaf_no',
            'total_leaves'   => 'required|integer|min:1',
            'received_date'  => 'nullable|date',
            'status'         => 'required|in:Active,Exhausted,Cancelled,Lost',
            'notes'          => 'nullable|string|max:500',
            'is_active'      => 'required|boolean',
        ];
    ```
    Do not add `whereNull('deleted_at')` — the real index `uq_acc_chqreg` includes trashed rows, so a soft-deleted book number must fail validation too.
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Requests\ChequeRegisterRequest.php -Pattern "Rule::unique"` 
  - **Expect:** `Rule::unique('acc_cheque_registers', 'book_number')` is printed once.
  - **Effort:** S

- [ ] **CHQR-06** · M · VAL-05 · `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php:170` — constrain the toggle status to the four values the DB enum accepts.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php`
  - **Before** (`ChequeRegisterController.php:170`):
    ```php
        $request->validate(['status' => 'required|string']);
    ```
  - **After:**
    ```php
        $request->validate(['status' => 'required|in:Active,Exhausted,Cancelled,Lost']);
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -SimpleMatch -Pattern "required|in:Active,Exhausted,Cancelled,Lost"`
  - **Expect:** one match on the `toggleStatus` validation line.
  - **Effort:** S

- [ ] **CHQR-07** · H · RTE-01 · `Modules/Accounting/routes/web.php:139` — make restore a POST so a GET cannot change state. ⚠ SHARED
  - **Touches:** `Modules/Accounting/routes/web.php`
  - **Before** (`web.php:139`):
    ```php
    Route::get('/cheque-register/{id}/restore', [ChequeRegisterController::class, 'restore'])->name('cheque-register.restore');
    ```
  - **After:**
    ```php
    Route::post('/cheque-register/{id}/restore', [ChequeRegisterController::class, 'restore'])->name('cheque-register.restore');
    ```
    No view change is needed: `resources/views/components/backend/table/action-trashed.blade.php:29-38` reads the route verb and emits `@csrf` plus the confirm form for any non-GET route.
  - **Verify:** `php artisan route:list --path=cheque-register` (with `APP_ROUTES_CACHE` pointed at a missing file)
  - **Expect:** the restore route now starts with `POST`, not `GET|HEAD`; route name and path unchanged.
  - **Effort:** S

- [ ] **CHQR-09** · L · MDL-02 · `Modules/Accounting/app/Models/ChequeRegister.php:17-36` — make the existing `is_active` column fillable and cast it to boolean.
  - **Touches:** `Modules/Accounting/app/Models/ChequeRegister.php`
  - **Before** (`ChequeRegister.php:17-36`):
    ```php
    protected $fillable = [
        'bank_ledger_id',
        'book_number',
        'leaf_prefix',
        'start_leaf_no',
        'end_leaf_no',
        'total_leaves',
        'received_date',
        'status',
        'notes',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'start_leaf_no'  => 'integer',
        'end_leaf_no'    => 'integer',
        'total_leaves'   => 'integer',
        'received_date'  => 'date',
    ];
    ```
  - **After:**
    ```php
    protected $fillable = [
        'bank_ledger_id',
        'book_number',
        'leaf_prefix',
        'start_leaf_no',
        'end_leaf_no',
        'total_leaves',
        'received_date',
        'status',
        'notes',
        'is_active',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'start_leaf_no' => 'integer',
        'end_leaf_no' => 'integer',
        'total_leaves' => 'integer',
        'received_date' => 'date',
        'is_active' => 'boolean',
    ];
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Models\ChequeRegister.php -SimpleMatch -Pattern "'is_active'"`
  - **Expect:** two matches — one in `$fillable`, one in `$casts`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **CHQR-13** · L · QRY-02 · `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php:198` — paginate the trash list at the project standard of 10.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php`
  - **Before** (`ChequeRegisterController.php:198`):
    ```php
        $registers = ChequeRegister::onlyTrashed()->with('bankLedger')->orderBy('book_number')->paginate(15);
    ```
  - **After:**
    ```php
        $registers = ChequeRegister::onlyTrashed()->with('bankLedger')->orderBy('book_number')->paginate(10);
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "paginate\(10\)"`
  - **Expect:** one match on line 198.
  - **Effort:** S

## 7. Views (F10)

Clean — no items. The controller's five views were checked: the show page uses `$register->leaves`, `$register->bankLedger` and `$leaf->voucher` already eager-loaded by `show()`, and no Blade file in `Modules/Accounting/resources/views/cheque-register/` queries a model (`Select-String ... -Pattern "::where|::find|::all|DB::"` → no output).

## 8. Style (F12) — one item per file

- [ ] **CHQR-14** · L · STY-02 · `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php` — run Pint on the controller after the code items (it also removes the then-unused `Log` import).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php`
  - **Before** (`vendor\bin\pint --test ... --format agent`):
    ```
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\ChequeRegisterController.php","fixers":["fully_qualified_strict_types","concat_space","not_operator_with_successor_space","ordered_imports","binary_operator_spaces"]}]}
    ```
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php --format agent`; the file is rewritten.
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`
  - **Effort:** S

- [ ] **CHQR-15** · L · STY-02 · `Modules/Accounting/app/Models/ChequeRegister.php` — run Pint on the model.
  - **Touches:** `Modules/Accounting/app/Models/ChequeRegister.php`
  - **Before** (`vendor\bin\pint --test ... --format agent`):
    ```
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\ChequeRegister.php","fixers":["not_operator_with_successor_space","binary_operator_spaces"]}]}
    ```
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Models\ChequeRegister.php --format agent`; the file is rewritten.
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Models\ChequeRegister.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`
  - **Effort:** S

- [ ] **CHQR-16** · L · STY-02 · `Modules/Accounting/app/Http/Requests/ChequeRegisterRequest.php` — run Pint on the FormRequest after CHQR-05.
  - **Touches:** `Modules/Accounting/app/Http/Requests/ChequeRegisterRequest.php`
  - **Before** (`vendor\bin\pint --test ... --format agent`):
    ```
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\ChequeRegisterRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
    ```
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Requests\ChequeRegisterRequest.php --format agent`; the file is rewritten.
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Requests\ChequeRegisterRequest.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **CHQR-10** · M · DECISION · MDL-09 — `restore()` forces every restored register to status `Active`, discarding the `Cancelled`/`Exhausted`/`Lost` value that is still stored on the soft-deleted row. Keep that reset?
  - **Why it is a decision:** changing it changes a business outcome (whether a retired book becomes issuable again).
  - (a) ⭐ Preserve the stored status: delete the line `$model->update(['status' => 'Active']);` in `restore()`; the row keeps the value it had before deletion.
  - (b) Keep the reset to `Active` — record it as intended behaviour and accept that a cancelled book becomes active on restore.
  - (c) Reset to `Active` only when the stored status is `Cancelled` — needs a small conditional and a stated rule.
  - ➜ Choice: ____

- [ ] **CHQR-12** · H · DECISION · SVC-04 — `update()` changes `bank_ledger_id`, `start_leaf_no`, `end_leaf_no` and `total_leaves` without touching `acc_cheque_leaves`, so an edited register and its stock disagree. How should edit-time stock be handled?
  - **Why it is a decision:** it is a behaviour change on a financial master, and the options trade safety against convenience; regenerating stock can destroy issued-leaf history if done carelessly.
  - (a) ⭐ Block the range/bank/total fields once the register has stock (or once any leaf is not `Unused`): add a FormRequest `after()` rule that compares the submitted values with the stored ones and rejects the change; make the three range fields read-only in `edit.blade.php`.
  - (b) Regenerate the unused leaves inside the `update()` transaction: delete the `Unused` leaves in the new range, keep `Issued`/`Cancelled`/`Spoiled`/`Lost`, insert any missing leaves, and reject a new range that collides with another register on the same bank.
  - (c) Leave `update()` as is and record the inconsistency as accepted.
  - ➜ Choice: ____

- [ ] **CHQR-17** · M · DECISION · CTL-03 — `restore()`/`forceDelete()` use `$id` + `findOrFail()` while the resource routes use `{cheque_register}` binding. Adopt route model binding now?
  - **Why it is a decision:** it needs the route parameter changed from `{id}` to `{cheque_register}` in a shared route file, plus an explicit `withTrashed()` binding; that is a route re-scope and is deferred by D3.
  - (a) ⭐ Defer to the route pass; keep `$id` + `findOrFail()` above the transaction (CHQR-02 already makes the 404 correct).
  - (b) Change both routes to `{cheque_register}` now, type the arguments `ChequeRegister $chequeRegister`, and register a `withTrashed()` binding for the trash routes.
  - (c) Leave as is permanently and record as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CHQR-03 | Resolved by CHQR-01 and CHQR-02: both replace the manual `DB::beginTransaction()`/`DB::commit()`/`DB::rollBack()` blocks with `DB::transaction()`. |
