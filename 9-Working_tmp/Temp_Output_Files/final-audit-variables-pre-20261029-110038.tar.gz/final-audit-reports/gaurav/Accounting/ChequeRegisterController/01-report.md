# Final Audit — Accounting / ChequeRegisterController

**Audited:** 2026-10-24 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php` (257 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/cheques-reconciliation?tab=cheque-registers` (list, rendered by `AccDashboardController`); `http://test.localhost:8000/accounting/cheque-register/create`; `http://test.localhost:8000/accounting/cheque-register/{id}`; `http://test.localhost:8000/accounting/cheque-register/{id}/edit`; `http://test.localhost:8000/accounting/cheque-register/trash/view` |
| Menu path | Finance → Accounting → Cheques & Reconciliation → Cheque Registers tab (menu row 718, parent 713, parent 711 in `glb_menus`) |
| Who uses it | Roles holding `tenant.accounting.cheque-register.viewAny` (measured in the tenant DB): Super Admin (1), School Admin (2), Management (3), Account Staff (8), Account Manager (9) |
| What a user does here | Record a physical cheque book received from a bank (bank ledger, book number, leaf range). The system creates one stock row per leaf so finance can later issue a leaf against a voucher, cancel it or mark it lost. A user can edit the book, activate/deactivate its status, move it to trash, restore it, or permanently delete it. |
| Tables written | `acc_cheque_registers`, `acc_cheque_leaves`, `sys_activity_logs` |
| Tables read | `acc_cheque_registers`, `acc_cheque_leaves`, `acc_ledgers`, `acc_vouchers` (show page, through `ChequeLeaf::voucher`) |
| Live data | Tenant `xyz_school_00000000000040008000_202627`: `acc_cheque_registers` 2 live / 0 trashed; `acc_cheque_leaves` 45 rows; `acc_ledgers` 56 rows. Register 1 says 50 leaves but has 25 leaf rows (100001–100025); register 2 says 50 but has 20 (500101–500120). The stock is already thinner than the register total in the seeded data. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**No — not production-ready.** The single worst finding is CHQR-11: creating any cheque register fails, because the leaf stock is inserted twice (once by the `ChequeRegister` model's `created` hook and once by the controller) into a table with a unique key on `(bank_ledger_id, leaf_no)`; the second insert raises a duplicate-key error, the transaction rolls back, and the user sees a red flash containing raw SQL. On top of that, every failure message leaks the exception text (CHQR-01), and editing a register can silently desynchronise the register's leaf range from its stock (CHQR-12). Rough effort: **M** (about 4–8 hours of edits, mostly mechanical, plus one business decision about edit-time stock reconciliation).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 4 | 4 | 6 | 3 | 16 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CHQR-01, CHQR-02 | F8 Services/Jobs | CHQR-11, CHQR-12 |
| F2 Transactions/Audit | CHQR-03 | F9 Queries/Perf | CHQR-13 |
| F3 Authorization | CHQR-04 | F10 Views | clean |
| F4 Validation | CHQR-05, CHQR-06 | F11 Security/Tenancy | clean |
| F5 Routes | CHQR-07 | F12 Style | CHQR-14, CHQR-15, CHQR-16 |
| F6 Controller shape | CHQR-17 | F13 Deep read | table below, no new IDs |
| F7 Models | CHQR-09, CHQR-10 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php` | controller | 257 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/ChequeRegister.php` | model | 79 | this report | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/ChequeRegisterRequest.php` | form request | 78 | this report | ✅ |
| 4 | `Modules/Accounting/app/Models/ChequeLeaf.php` | model | 44 | ↗ [gaurav/Accounting/ChequeLeafController](../ChequeLeafController/01-report.md) | ↗ linked |
| 5 | `Modules/Accounting/app/Models/Ledger.php` | model | 408 | ↗ [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) | ↗ linked |
| 6 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | base model | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 7 | `Modules/Accounting/resources/views/cheque-register/create.blade.php` | view | 159 | this report | ✅ |
| 8 | `Modules/Accounting/resources/views/cheque-register/edit.blade.php` | view | 163 | this report | ✅ |
| 9 | `Modules/Accounting/resources/views/cheque-register/show.blade.php` | view | 525 | this report | ✅ |
| 10 | `Modules/Accounting/resources/views/cheque-register/trash.blade.php` | view | 82 | this report | ✅ |
| 11 | `Modules/Accounting/resources/views/cheque-register/index.blade.php` | view | 97 | this report | ❌ dead — no route or view renders it; the list is `pages/partials/cheques-reconciliation/_cheque-registers.blade.php` rendered by `AccDashboardController` |
| 12 | `Modules/Accounting/routes/web.php` | route file | 536 | this report (F5 only) | ✅ |
| 13 | `database/migrations/tenant/2026_09_16_100019_create_acc_cheque_registers_table.php` | migration | 60 | schema evidence only | ✅ |
| 14 | `database/migrations/tenant/2026_09_16_100042_create_acc_cheque_leaves_table.php` | migration | 57 | schema evidence only | ✅ |
| 15 | `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_cheque-registers.blade.php` | view | 182 | `AccDashboardController` (CLAIMED) | ❌ not audited — it belongs to another controller; its use of this controller's routes is noted in §7 |
| 16 | `resources/views/components/backend/table/action-trashed.blade.php` | shared component | — | common (final-audit §4.2) | ❌ common; its GET-supporting behaviour is quoted in CHQR-07 |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/cheque-register                              accounting.cheque-register.index    Modules\Accounting\Http\Controllers\ChequeRegisterController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/cheque-register                              accounting.cheque-register.store    Modules\Accounting\Http\Controllers\ChequeRegisterController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cheque-register/create                       accounting.cheque-register.create   Modules\Accounting\Http\Controllers\ChequeRegisterController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cheque-register/trash/view                   accounting.cheque-register.trashed  Modules\Accounting\Http\Controllers\ChequeRegisterController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cheque-register/{cheque_register}            accounting.cheque-register.show     Modules\Accounting\Http\Controllers\ChequeRegisterController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/cheque-register/{cheque_register}            accounting.cheque-register.update   Modules\Accounting\Http\Controllers\ChequeRegisterController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/cheque-register/{cheque_register}            accounting.cheque-register.destroy  Modules\Accounting\Http\Controllers\ChequeRegisterController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cheque-register/{cheque_register}/edit       accounting.cheque-register.edit     Modules\Accounting\Http\Controllers\ChequeRegisterController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/cheque-register/{cheque_register}/toggle-status accounting.cheque-register.toggleStatus Modules\Accounting\Http\Controllers\ChequeRegisterController@toggleStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/cheque-register/{id}/force-delete            accounting.cheque-register.forceDelete Modules\Accounting\Http\Controllers\ChequeRegisterController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cheque-register/{id}/restore                 accounting.cheque-register.restore  Modules\Accounting\Http\Controllers\ChequeRegisterController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none — all 11 public methods appear in the route list above.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 18 | GET `accounting/cheque-register` | `tenant.accounting.cheque-register.viewAny` | — | — | none | — |
| `create` | 25 | GET `accounting/cheque-register/create` | `tenant.accounting.cheque-register.create` | — | — | none | — |
| `store` | 34 | POST `accounting/cheque-register` | `tenant.accounting.cheque-register.create` (also FormRequest `create`) | controller, manual | `Created` | `acc_cheque_registers`, `acc_cheque_leaves`, `sys_activity_logs` | CHQR-01, CHQR-04, CHQR-11 |
| `show` | 85 | GET `accounting/cheque-register/{cheque_register}` | `tenant.accounting.cheque-register.view` | — | — | none | — |
| `edit` | 99 | GET `accounting/cheque-register/{cheque_register}/edit` | `tenant.accounting.cheque-register.update` | — | — | none | — |
| `update` | 109 | PUT/PATCH `accounting/cheque-register/{cheque_register}` | `tenant.accounting.cheque-register.update` (also FormRequest `update`) | controller, manual | `Updated` | `acc_cheque_registers`, `sys_activity_logs` (leaves are NOT touched) | CHQR-01, CHQR-04, CHQR-05, CHQR-12 |
| `destroy` | 140 | DELETE `accounting/cheque-register/{cheque_register}` | `tenant.accounting.cheque-register.delete` | controller, manual | `Deleted` | `acc_cheque_registers` (soft), `sys_activity_logs` | CHQR-01 |
| `toggleStatus` | 166 | POST `accounting/cheque-register/{cheque_register}/toggle-status` | `tenant.accounting.cheque-register.update` | controller, manual | `Toggled` | `acc_cheque_registers`, `sys_activity_logs` | CHQR-01, CHQR-06 |
| `trashed` | 194 | GET `accounting/cheque-register/trash/view` | `tenant.accounting.cheque-register.restore` | — | — | none | CHQR-13 |
| `restore` | 204 | GET `accounting/cheque-register/{id}/restore` | `tenant.accounting.cheque-register.restore` | controller, manual | `Restored` | `acc_cheque_registers`, `sys_activity_logs` | CHQR-01, CHQR-02, CHQR-07, CHQR-10 |
| `forceDelete` | 231 | DELETE `accounting/cheque-register/{id}/force-delete` | `tenant.accounting.cheque-register.forceDelete` | controller, manual | `Deleted` | `acc_cheque_registers`, `acc_cheque_leaves` (FK cascade), `sys_activity_logs` | CHQR-01, CHQR-02 |

## 6. Findings

### F1 — Errors

#### CHQR-01 · B · ERR-01 — Every failed write shows the raw exception text to the user

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `ChequeRegisterController.php:74-82` (`store`), `129-137` (`update`), `158-163` (`destroy`), `186-191` (`toggleStatus`), `223-228` (`restore`), `250-255` (`forceDelete`) |
| **Root cause** | Each method catches `\Throwable` and puts `$e->getMessage()` into the flash message or JSON response. The catch exists only because of the hand-written transaction, so D1 applies twice. |
| **Consequence** | A cashier who hits any database error (duplicate book number, wrong column, deadlock) is shown the SQLSTATE and often the SQL statement, and the same text is written to the log as a string. |
| **Reproduce** | Cheque Registers tab → Add Cheque Register → submit a book number that already exists on the same bank. Expected a field error; actual red flash reading `Failed to create Cheque Register: SQLSTATE[23000] ... Duplicate entry ... for key 'uq_acc_chqreg'`. |
| **Fix approach** | Delete the try/catch (D1) and use `DB::transaction(fn () => ...)`; the central handler renders the failure. This is done together with CHQR-02 for the two `$id` methods. |
| **Plan item** | CHQR-01 (store/update/destroy/toggleStatus) and CHQR-02 (restore/forceDelete) in `02-fix-plan.md` §1 and §3 |

```php
// ChequeRegisterController.php:74-82 — CURRENT (the same shape repeats in five more methods)
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Cheque Register', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Cheque Register: ' . $e->getMessage());
        }
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "getMessage" | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
77:                'error' => $e->getMessage(),
81:            return back()->withInput()->with('error', 'Failed to create Cheque Register: ' . $e->getMessage());
133:                'error' => $e->getMessage(),
136:            return back()->withInput()->with('error', 'Failed to update Cheque Register: ' . $e->getMessage());
160:            Log::error('Failed to delete Cheque Register', ['id' => $chequeRegister->id, 'error' => $e->getMessage()]);
162:            return back()->with('error', 'Failed to delete Cheque Register: ' . $e->getMessage());
188:            Log::error('Failed to toggle Cheque Register status', ['id' => $chequeRegister->id, 'error' => $e->getMessage()]);
190:            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
225:            Log::error('Failed to restore Cheque Register', ['id' => $id, 'error' => $e->getMessage()]);
227:            return back()->with('error', 'Failed to restore Cheque Register: ' . $e->getMessage());
252:            Log::error('Failed to force delete Cheque Register', ['id' => $id, 'error' => $e->getMessage()]);
254:            return back()->with('error', 'Failed to delete Cheque Register: ' . $e->getMessage());
```

#### CHQR-02 · H · ERR-02 — A missing register on restore/force-delete shows a red flash instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `ChequeRegisterController.php:208-228` (`restore`), `235-255` (`forceDelete`) |
| **Root cause** | `findOrFail()` is called inside the `try`; `ModelNotFoundException` is caught by `\Throwable` and converted to `back()->with('error', ...)` instead of propagating to the 404 renderer. |
| **Consequence** | A user who opens a stale restore link sees "Failed to restore Cheque Register: No query results for model ..." and the error is logged as a failure, instead of a clean 404. |
| **Reproduce** | Open `http://test.localhost:8000/accounting/cheque-register/999999/restore`. Expected 404; actual redirect back with a red flash. |
| **Fix approach** | Load the record before the transaction and outside any catch (`ChequeRegister::onlyTrashed()->findOrFail($id)` / `withTrashed()`), then wrap only the writes in `DB::transaction`. |
| **Plan item** | CHQR-02 in `02-fix-plan.md` §3 |

```php
// ChequeRegisterController.php:208-228 — CURRENT
        DB::beginTransaction();
        try {
            $model = ChequeRegister::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['status' => 'Active']);

            activityLog($model, 'Restored', [
                'message'      => 'Cheque Register restored: ' . $model->book_number,
                'book_number'  => $model->book_number,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.cheque-register.trashed')->with('success', 'Cheque Register restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Cheque Register', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Cheque Register: ' . $e->getMessage());
        }
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "findOrFail|catch \(" | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
74:        } catch (\Throwable $e) {
129:        } catch (\Throwable $e) {
158:        } catch (\Throwable $e) {
186:        } catch (\Throwable $e) {
210:            $model = ChequeRegister::onlyTrashed()->findOrFail($id);
223:        } catch (\Throwable $e) {
237:            $model = ChequeRegister::withTrashed()->findOrFail($id);
250:        } catch (\Throwable $e) {
```

### F2 — Transactions and audit

#### CHQR-03 · M · TXN-02 — All six mutations use hand-written begin/commit/rollback instead of `DB::transaction`

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual begin/commit/rollBack* |
| **Where** | `store` 40/70/75, `update` 113/125/130, `destroy` 144/154/159, `toggleStatus` 172/183/187, `restore` 208/220/224, `forceDelete` 235/247/251 |
| **Root cause** | Each method opens a transaction by hand and relies on its own catch to roll back. This is the same code block copied six times; it is also what forces the try/catch that leaks messages. |
| **Consequence** | Every future edit has six places to get rollback wrong; an early `return` between begin and commit would leak an open transaction. |
| **Reproduce** | Static only — the pattern is visible at the six line pairs above; there is no user-visible symptom separate from CHQR-01. |
| **Fix approach** | Replace each with `DB::transaction(function () use (...) { ... });`. The rewritten methods in CHQR-01/CHQR-02 already do this, so no separate item is needed. |
| **Plan item** | none — see `02-fix-plan.md` §10 (resolved by CHQR-01 and CHQR-02) |

```php
// ChequeRegisterController.php:40-44 — CURRENT (same pattern in five more methods)
        DB::beginTransaction();
        try {
            $validated['total_leaves'] = (int) $validated['end_leaf_no'] - (int) $validated['start_leaf_no'] + 1;
            $validated['created_by'] = auth()->id();
            $chequeRegister = ChequeRegister::create($validated);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "beginTransaction|DB::commit|rollBack" | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
40:        DB::beginTransaction();
70:            DB::commit();
75:            DB::rollBack();
113:        DB::beginTransaction();
125:            DB::commit();
130:            DB::rollBack();
144:        DB::beginTransaction();
154:            DB::commit();
159:            DB::rollBack();
172:        DB::beginTransaction();
183:            DB::commit();
187:            DB::rollBack();
208:        DB::beginTransaction();
220:            DB::commit();
224:            DB::rollBack();
235:        DB::beginTransaction();
247:            DB::commit();
251:            DB::rollBack();
```

### F3 — Authorization

#### CHQR-04 · L · AUTH-04 — `store` and `update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (FormRequest + Gate); keep one* |
| **Where** | `ChequeRegisterController.php:36` and `111`; `ChequeRegisterRequest.php:16` |
| **Root cause** | `ChequeRegisterRequest::authorize()` already maps POST→`create` and PUT/PATCH→`update` through `authorizeByCrudPermission('tenant.accounting.cheque-register')`, then the controller repeats the same check with `Gate::authorize()`. |
| **Consequence** | No security hole; the second check is dead weight and hides which layer is the real guard. |
| **Reproduce** | Static only — both checks return the same answer for every role. |
| **Fix approach** | Keep the FormRequest check (it runs first) and delete the two controller `Gate::authorize()` lines in `store`/`update`. |
| **Plan item** | CHQR-04 in `02-fix-plan.md` §4 |

```php
// ChequeRegisterRequest.php:14-17 — CURRENT (runs before the controller)
    public function authorize(): bool
    {
        return $this->authorizeByCrudPermission('tenant.accounting.cheque-register');
    }
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "Gate::authorize" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
20:Gate::authorize('tenant.accounting.cheque-register.viewAny');
27:Gate::authorize('tenant.accounting.cheque-register.create');
36:Gate::authorize('tenant.accounting.cheque-register.create');
87:Gate::authorize('tenant.accounting.cheque-register.view');
101:Gate::authorize('tenant.accounting.cheque-register.update');
111:Gate::authorize('tenant.accounting.cheque-register.update');
142:Gate::authorize('tenant.accounting.cheque-register.delete');
168:Gate::authorize('tenant.accounting.cheque-register.update');
196:Gate::authorize('tenant.accounting.cheque-register.restore');
206:Gate::authorize('tenant.accounting.cheque-register.restore');
233:Gate::authorize('tenant.accounting.cheque-register.forceDelete');
PS> Select-String -Path Modules\Accounting\app\Http\Requests\ChequeRegisterRequest.php -Pattern "authorizeByCrudPermission" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
16:return $this->authorizeByCrudPermission('tenant.accounting.cheque-register');
```

### F4 — Validation and input

#### CHQR-05 · H · VAL-04 — Duplicate book numbers are not validated; the DB unique key surfaces as a 500/flash

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the DB unique index, including soft-delete semantics* |
| **Where** | `ChequeRegisterRequest.php:21-33` (`rules()`); index at `2026_09_16_100019_create_acc_cheque_registers_table.php:38` |
| **Root cause** | The table has `UNIQUE (bank_ledger_id, book_number)` but the FormRequest has no `unique` rule for `book_number`. The key also includes trashed rows (the index has no `deleted_at`), so a trashed register still owns its pair. |
| **Consequence** | Typing an existing book number for the same bank produces a database duplicate-key error (raw SQL in the flash per CHQR-01) instead of a field-level message; re-using the book number of a trashed register also fails with no explanation. |
| **Reproduce** | Cheque Registers tab → Add Cheque Register → enter `CHQ-HDFC-2026-01` with bank ledger 4 (the seeded pair) → submit. Expected "book number already taken"; actual database error. |
| **Fix approach** | Add `Rule::unique('acc_cheque_registers', 'book_number')->where('bank_ledger_id', ...)->ignore($this->route('cheque_register'))`. Do **not** add `whereNull('deleted_at')`: the real index includes trashed rows. |
| **Plan item** | CHQR-05 in `02-fix-plan.md` §5 |

```php
// ChequeRegisterRequest.php:21-33 — CURRENT (no uniqueness rule)
        return [
            'bank_ledger_id' => 'required|exists:acc_ledgers,id',
            'book_number'    => 'required|string|max:50',
            'leaf_prefix'    => 'nullable|string|max:10',
            'start_leaf_no'  => 'required|integer|min:1',
            'end_leaf_no'    => 'required|integer|gte:start_leaf_no',
            'total_leaves'   => 'required|integer|min:1',
            'received_date'  => 'nullable|date',
            'status'         => 'required|in:Active,Exhausted,Cancelled,Lost',
            'notes'          => 'nullable|string|max:500',
            'is_active'      => 'required|boolean',
        ];
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Requests\ChequeRegisterRequest.php -Pattern "unique" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
(no output)
PS> Select-String -Path database\migrations\tenant\2026_09_16_100019_create_acc_cheque_registers_table.php -Pattern "unique" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
37:// Unique keys
38:$table->unique(['bank_ledger_id', 'book_number'], 'uq_acc_chqreg');
```

#### CHQR-06 · M · VAL-05 — `toggleStatus` accepts any status string, then the DB enum rejects it

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; an unconstrained string on a write path is not validation* |
| **Where** | `ChequeRegisterController.php:170` |
| **Root cause** | `$request->validate(['status' => 'required|string'])` allows `"Foo"`, but `acc_cheque_registers.status` is `ENUM('Active','Exhausted','Cancelled','Lost')`. |
| **Consequence** | A stale or hand-crafted toggle request reaches the database, throws a data-truncation error, and the JSON response returns 500 with the SQL text (CHQR-01). |
| **Reproduce** | POST `accounting/cheque-register/{id}/toggle-status` with `status=Foo` (DevTools → copy the toggle request and edit the body). Expected 422; actual 500. |
| **Fix approach** | Constrain the inline rule to the four enum values: `required|in:Active,Exhausted,Cancelled,Lost`. |
| **Plan item** | CHQR-06 in `02-fix-plan.md` §5 |

```php
// ChequeRegisterController.php:170 — CURRENT
        $request->validate(['status' => 'required|string']);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "validate\(\[" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
170:$request->validate(['status' => 'required|string']);
```

### F5 — Routes

#### CHQR-07 · H · RTE-01 — Restore changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:139`; action `restore()` at `ChequeRegisterController.php:204` |
| **Root cause** | The route is registered as `Route::get(...)` even though `restore()` writes two columns. The shared `action-trashed` component reads the route verb and therefore renders a GET form, which reinforces the mistake. |
| **Consequence** | Any GET to the URL (browser prefetch, a crawler, a user pasting the link, the back button after a redirect) restores a trashed register and writes an audit row without a CSRF token. |
| **Reproduce** | Trash a register, then open `http://test.localhost:8000/accounting/cheque-register/{id}/restore` directly in the address bar. The register is restored. |
| **Fix approach** | Change the verb to POST in the route file. `action-trashed.blade.php:29-38` already emits `@csrf` for any non-GET route, so no view change is needed. The route name and path stay the same. |
| **Plan item** | CHQR-07 in `02-fix-plan.md` §5 (⚠ SHARED: route file) |

```php
// Modules/Accounting/routes/web.php:139 — CURRENT
Route::get('/cheque-register/{id}/restore', [ChequeRegisterController::class, 'restore'])->name('cheque-register.restore');
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\routes\web.php -Pattern "cheque-register" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
138:Route::get('/cheque-register/trash/view', [ChequeRegisterController::class, 'trashed'])->name('cheque-register.trashed');
139:Route::get('/cheque-register/{id}/restore', [ChequeRegisterController::class, 'restore'])->name('cheque-register.restore');
140:Route::delete('/cheque-register/{id}/force-delete', [ChequeRegisterController::class, 'forceDelete'])->name('cheque-register.forceDelete');
141:Route::resource('cheque-register', ChequeRegisterController::class);
142:Route::post('/cheque-register/{cheque_register}/toggle-status', [ChequeRegisterController::class, 'toggleStatus'])->name('cheque-register.toggleStatus');
```

### F6 — Controller shape

#### CHQR-17 · M · CTL-03 — `restore`/`forceDelete` use `$id` + `findOrFail` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` + `findOrFail` (`->withTrashed()` on trash routes)* |
| **Where** | `ChequeRegisterController.php:204` (`restore`), `231` (`forceDelete`); routes `web.php:139-140` |
| **Root cause** | Both methods take a raw `$id` and query the model by hand, because the routes use `{id}` instead of `{cheque_register}`. The resource routes already bind `{cheque_register}` correctly to `$chequeRegister`. |
| **Consequence** | Two ways of loading a register side by side; the trash routes silently lose the 404-before-authority ordering and the type safety the other eight routes have. No immediate user-visible break beyond CHQR-02. |
| **Reproduce** | Static only — compare the signatures at lines 204/231 with `show`/`edit` at 85/99. |
| **Fix approach** | Deferred: switching the parameter to `{cheque_register}` and typing the argument requires a shared-route change and `withTrashed()` binding. Recorded as a decision, not applied in this pass. |
| **Plan item** | CHQR-17 in `02-fix-plan.md` §9 (DECISION, deferred) |

```php
// ChequeRegisterController.php:204,210,231,237 — CURRENT
    public function restore($id): \Illuminate\Http\RedirectResponse
...
            $model = ChequeRegister::onlyTrashed()->findOrFail($id);
...
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
...
            $model = ChequeRegister::withTrashed()->findOrFail($id);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "public function restore|public function forceDelete|findOrFail\(" | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
204:    public function restore($id): \Illuminate\Http\RedirectResponse
210:            $model = ChequeRegister::onlyTrashed()->findOrFail($id);
231:    public function forceDelete($id): \Illuminate\Http\RedirectResponse
237:            $model = ChequeRegister::withTrashed()->findOrFail($id);
```

### F7 — Models

#### CHQR-09 · L · MDL-02 — `is_active` is a boolean column but is neither fillable nor cast

| Field | Value |
|---|---|
| **Rule** | MDL-02 (L) — *`$casts` for every boolean, date, decimal, JSON and enum column* (default M lowered to L: the value currently has no reader and the DB default is `true`) |
| **Where** | `Modules/Accounting/app/Models/ChequeRegister.php:17-29` (`$fillable`), `31-36` (`$casts`) |
| **Root cause** | The shared migration added `is_active` to `acc_cheque_registers`, and `ChequeRegisterRequest` requires it, but the model neither accepts it nor casts it. `ChequeRegister::create($validated)` and `->update($validated)` silently drop it. |
| **Consequence** | The `is_active` checkbox/value is a dead field: it never persists and is read back as `1`/`0` without a PHP boolean. No screen breaks today because the DB default is `true`. |
| **Reproduce** | Static only — `grep 'is_active'` on the model returns nothing. |
| **Fix approach** | Add `is_active` to `$fillable` and `'is_active' => 'boolean'` to `$casts`. |
| **Plan item** | CHQR-09 in `02-fix-plan.md` §5 |

```php
// Modules/Accounting/app/Models/ChequeRegister.php:17-36 — CURRENT
    protected $fillable = [
        'bank_ledger_id',
        'book_number',
        'leaf_prefix',
        'start_leaf_no',
        'end_leaf_no',
        'total_leaves',
        'received_date',
        'status',
        'notes',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'start_leaf_no'  => 'integer',
        'end_leaf_no'    => 'integer',
        'total_leaves'   => 'integer',
        'received_date'  => 'date',
    ];
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Models\ChequeRegister.php -SimpleMatch -Pattern "'is_active'","protected `$casts" | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
31:    protected $casts = [
```

#### CHQR-10 · M · MDL-09 — `restore` hard-codes status `Active`, overwriting the stored status

| Field | Value |
|---|---|
| **Rule** | MDL-09 (M) — *status/type strings are enums or model constants, not literals repeated across files* (default L raised to M: the literal overwrites a persisted business state on restore) |
| **Where** | `ChequeRegisterController.php:212` |
| **Root cause** | After `$model->restore()`, the method unconditionally calls `$model->update(['status' => 'Active'])`. A soft delete does not change `status`, so the original value is still in the row and is then overwritten. |
| **Consequence** | Restoring a `Cancelled`, `Exhausted` or `Lost` book silently makes it `Active`, so the bank and the accounts team can start issuing from a book that was deliberately retired. |
| **Reproduce** | Create/edit a register and set status `Cancelled`, delete it, open the trash tab, restore it. The list shows `Active`. |
| **Fix approach** | Decision required: preserve the stored status (recommended) or keep the reset. Do not apply without Tarun's choice. |
| **Plan item** | CHQR-10 in `02-fix-plan.md` §9 (DECISION) |

```php
// ChequeRegisterController.php:211-212 — CURRENT
            $model->restore();
            $model->update(['status' => 'Active']);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "status' => 'Active'" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
212:$model->update(['status' => 'Active']);
```

### F8 — Services and jobs

#### CHQR-11 · B · SVC-04 — Leaf stock is created twice, so creating a register always fails

| Field | Value |
|---|---|
| **Rule** | SVC-04 (B) — *one implementation per business operation; duplicate implementations that disagree are a bug source* (default M raised to B: it is a crash on the normal create path) |
| **Where** | `Modules/Accounting/app/Models/ChequeRegister.php:51-67` (`static::created`) and `ChequeRegisterController.php:46-62` (`store`); unique key at `2026_09_16_100042_create_acc_cheque_leaves_table.php:33` |
| **Root cause** | The model's `created` hook already inserts one `acc_cheque_leaves` row per leaf. The controller then builds the same range and inserts it again. The leaves table has `UNIQUE (bank_ledger_id, leaf_no)`, so the second insert collides. Only one create path exists (`ChequeRegister::create` at controller line 44), so removing either copy is safe. |
| **Consequence** | **No cheque register can be created.** Every attempt rolls back and the user sees a duplicate-key SQL error; no register and no leaf rows are saved. |
| **Reproduce** | Cheque Registers tab → Add Cheque Register → fill any bank/book/range (e.g. 200001–200010) → Save. Expected a new register; actual red flash with `SQLSTATE[23000] ... Duplicate entry ... for key 'uq_acc_chqleaf'`. |
| **Fix approach** | Remove the model's `created` hook (the controller's loop also sets `is_active` and is the copy the success message counts). The alternative — removing the controller loop — is equivalent but edits two methods later in this plan, so the model edit is the isolated fix. |
| **Plan item** | CHQR-11 in `02-fix-plan.md` §1 |

```php
// Modules/Accounting/app/Models/ChequeRegister.php:51-67 — CURRENT
        static::created(function (self $model): void {
            if (!empty($model->start_leaf_no) && !empty($model->end_leaf_no)) {
                $leaves = [];
                $now = now();
                for ($leaf = (int) $model->start_leaf_no; $leaf <= (int) $model->end_leaf_no; $leaf++) {
                    $leaves[] = [
                        'cheque_register_id' => $model->id,
                        'bank_ledger_id'     => $model->bank_ledger_id,
                        'leaf_no'            => $leaf,
                        'status'             => 'Unused',
                        'created_at'         => $now,
                        'updated_at'         => $now,
                    ];
                }
                ChequeLeaf::insert($leaves);
            }
        });
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Models\ChequeRegister.php -Pattern "static::created|ChequeLeaf::insert" | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
51:        static::created(function (self $model): void {
65:                ChequeLeaf::insert($leaves);
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "Generate individual|ChequeLeaf::insert" | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
46:            // Generate individual cheque leaves stock
61:                \Modules\Accounting\Models\ChequeLeaf::insert($leaves);
PS> Select-String -Path database\migrations\tenant\2026_09_16_100042_create_acc_cheque_leaves_table.php -Pattern "unique" | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
32:            // Unique keys
33:            $table->unique(['bank_ledger_id', 'leaf_no'], 'uq_acc_chqleaf');
```

#### CHQR-12 · H · SVC-04 — Editing a register changes the range/bank/total but never reconciles the leaf stock

| Field | Value |
|---|---|
| **Rule** | SVC-04 (H) — *one implementation per business operation* (default M raised to H: an edit silently leaves a second, disagreeing source of truth for the leaf range) |
| **Where** | `ChequeRegisterController.php:115-117` (`update`); editable fields at `edit.blade.php:48,86,98,110` |
| **Root cause** | Leaf stock is created by `store` only. `update` writes `bank_ledger_id`, `start_leaf_no`, `end_leaf_no` and `total_leaves` to the register, but never inserts, removes or re-points the `acc_cheque_leaves` rows. The total is also taken from user input (`prepareForValidation` trusts a supplied `total_leaves`) instead of being derived from the range. |
| **Consequence** | A user can change a book from 100001–100050 to 100001–100100 (or move it to another bank) and the register says 100 leaves while the stock still has 50 — and those 50 keep the old `bank_ledger_id`. Issuing a leaf then picks from the wrong range/bank. |
| **Reproduce** | Edit the seeded register 1 (`/accounting/cheque-register/1/edit`), change End Leaf No from 100050 to 100100, Save. The show page then says 50 total (or whatever `total_leaves` was submitted) while the leaf table still lists 25 rows ending at 100025. |
| **Fix approach** | Decision required: block range/bank edits once stock exists, or regenerate the unused leaves (keeping issued/cancelled ones) inside the same transaction. Not applied here. |
| **Plan item** | CHQR-12 in `02-fix-plan.md` §9 (DECISION) |

```php
// ChequeRegisterController.php:115-117 — CURRENT
            $validated = $request->validated();
            $validated['updated_by'] = auth()->id();
            $chequeRegister->update($validated);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\resources\views\cheque-register\edit.blade.php -Pattern 'name="bank_ledger_id"|name="start_leaf_no"|name="end_leaf_no"|name="total_leaves"' | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
48:<select name="bank_ledger_id" id="bank_ledger_id" class="form-select" required>
86:name="start_leaf_no"
98:name="end_leaf_no"
110:name="total_leaves"
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -SimpleMatch -Pattern '$request->validated();','$chequeRegister->update($validated);' | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
38:        $validated = $request->validated();
115:            $validated = $request->validated();
117:            $chequeRegister->update($validated);
```

### F9 — Queries and performance

#### CHQR-13 · L · QRY-02 — The trash list paginates 15 rows, not the project standard of 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (L) — *lists are paginated* (the list is paginated; only the page size differs from the project standard, so the default H is lowered to L) |
| **Where** | `ChequeRegisterController.php:198` |
| **Root cause** | `paginate(15)` where the project standard is 10, and the page name is not distinct (`page` is shared with any other paginator on the trash page). |
| **Consequence** | The trash tab shows 15 rows per page instead of the house standard; no data or security impact. |
| **Reproduce** | Trash a few registers and open `/accounting/cheque-register/trash/view`; the page size is 15. |
| **Fix approach** | Use `paginate(10)`; the page is a standalone view, so the default `page` name is acceptable. |
| **Plan item** | CHQR-13 in `02-fix-plan.md` §6 |

```php
// ChequeRegisterController.php:198 — CURRENT
        $registers = ChequeRegister::onlyTrashed()->with('bankLedger')->orderBy('book_number')->paginate(15);
```

**Evidence**
```
PS> Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "onlyTrashed\(\)->with|paginate\(" | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
198:        $registers = ChequeRegister::onlyTrashed()->with('bankLedger')->orderBy('book_number')->paginate(15);
```

### F10 — Views

clean — `Select-String -Path Modules\Accounting\resources\views\cheque-register\*.blade.php -Pattern "::where|::find|::all|DB::"` → no output; `show` eager-loads `bankLedger` and `leaves.voucher.partyLedger` in the controller, and `create`/`edit` receive `$ledgers` already loaded.

### F11 — Security and tenancy

clean — `Select-String -Path Modules\Accounting\app\Models\ChequeRegister.php,Modules\Accounting\app\Http\Requests\ChequeRegisterRequest.php,Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php -Pattern "env\(|->getMessage\(\)|DB::raw|whereRaw|orderByRaw"` finds no `env()`/raw SQL; tenant middleware is present on all 11 routes (§4); permission names are declared in `config/permissionslist.php:636` and seeded exactly (evidence below).

```
PS> Select-String -Path config\permissionslist.php -Pattern "cheque-register" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
636:'accounting.cheque-register' => $crud,
```
`sys_permissions` in the tenant DB holds exactly `tenant.accounting.cheque-register.{create,delete,forceDelete,restore,update,view,viewAny}` (ids 1396–1402); roles 1, 2, 3, 8, 9 hold `viewAny`.

### F12 — Style

#### CHQR-14 · L · STY-02 — The controller is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeRegisterController.php` (whole file) |
| **Root cause** | Imports, concatenation spacing, `!empty` spacing, operator alignment and fully-qualified return types were not run through Pint. |
| **Consequence** | The file diverges from the rest of the module and will churn the next time anyone runs Pint. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php --format agent` |
| **Fix approach** | Run Pint on the file (no `--dirty`); apply it after the code items so it also removes the now-unused `Log` import. |
| **Plan item** | CHQR-14 in `02-fix-plan.md` §8 |

```php
// ChequeRegisterController.php:60-61 — CURRENT (two of the reported fixers)
            if (!empty($leaves)) {
                \Modules\Accounting\Models\ChequeLeaf::insert($leaves);
```

**Evidence**
```
PS> vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\ChequeRegisterController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\ChequeRegisterController.php","fixers":["fully_qualified_strict_types","concat_space","not_operator_with_successor_space","ordered_imports","binary_operator_spaces"]}]}
```

#### CHQR-15 · L · STY-02 — The model is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Models/ChequeRegister.php` |
| **Root cause** | `!empty(...)` spacing and aligned `=>` operators do not match the Laravel preset. |
| **Consequence** | Same as CHQR-14. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Models\ChequeRegister.php --format agent` |
| **Fix approach** | Run Pint on the file. |
| **Plan item** | CHQR-15 in `02-fix-plan.md` §8 |

```php
// ChequeRegister.php:42-44 — CURRENT (one of the reported fixers)
        static::creating(function (self $model): void {
            if (empty($model->total_leaves) && !empty($model->start_leaf_no) && !empty($model->end_leaf_no)) {
                $model->total_leaves = max(1, (int) ($model->end_leaf_no - $model->start_leaf_no + 1));
```

**Evidence**
```
PS> vendor\bin\pint --test Modules\Accounting\app\Models\ChequeRegister.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\ChequeRegister.php","fixers":["not_operator_with_successor_space","binary_operator_spaces"]}]}
```

#### CHQR-16 · L · STY-02 — The FormRequest is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Http/Requests/ChequeRegisterRequest.php` |
| **Root cause** | Imports are not sorted and the rules are aligned with multiple spaces around `=>`. |
| **Consequence** | Same as CHQR-14. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Http\Requests\ChequeRegisterRequest.php --format agent` |
| **Fix approach** | Run Pint on the file (after CHQR-05, which adds the `Rule` import). |
| **Plan item** | CHQR-16 in `02-fix-plan.md` §8 |

```php
// ChequeRegisterRequest.php:7-8 — CURRENT (ordered_imports)
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
```

**Evidence**
```
PS> vendor\bin\pint --test Modules\Accounting\app\Http\Requests\ChequeRegisterRequest.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\ChequeRegisterRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1. Overwrites data it should not? | 2. Deletes before replacement stored? | 3. Duplicate implementation? | 4. Soft-delete × unique-index trap? | 5. Race? | 6. Authorization hole? | 7. Message lies? | 8. Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | CHQR-11 | CHQR-05 | ok — unique key is the guard | ok — FormRequest + Gate | CHQR-11 (says leaves generated; none are saved) | ok |
| `update` | CHQR-12 | ok | CHQR-12 | CHQR-05 | ok — unique key is the guard | ok — FormRequest + Gate | ok | ok |
| `destroy` | ok | ok | ok | CHQR-05 (re-create of a trashed book number) | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | CHQR-06 (invalid values reach the DB) |
| `restore` | CHQR-10 | ok | ok | CHQR-05 | ok | ok | ok | ok |
| `forceDelete` | ok | expected (permanent delete) | ok | ok | ok | ok | ok | ok |

Notes: `forceDelete` relies on `fk_acc_chqleaf_register … cascadeOnDelete()` (migration line 41) to remove the leaves, so it does not orphan them. `destroy` soft-deletes only the register; the leaves stay in place for the later restore, which is correct.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Models/ChequeLeaf.php` | The table `acc_cheque_leaves` has `deleted_at` and `is_active` (migration `2026_09_16_130001` lines 53), but the model does not use `SoftDeletes`. Trashed leaves would be invisible to the model but still occupy the `uq_acc_chqleaf` pair. Also the model has no `is_active` cast/fillable. | F7 soft-delete check | [gaurav/Accounting/ChequeLeafController](../ChequeLeafController/01-report.md) |
| `Modules/Accounting/app/Models/Ledger.php` | `selectableBankAccounts()` returns full `Ledger` models (`->get()`) for a dropdown instead of `pluck('name', 'id')`; fine at 56 rows, wasteful if the chart of accounts grows. | QRY-03 (M) | [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) |
| `resources/views/components/backend/table/action-trashed.blade.php` | The component reads the route verb and emits a GET form when the route is GET, which makes the unsafe restore route look supported. It already emits `@csrf` for non-GET, so the route fix (CHQR-07) needs no component change. | VIEW (shared) | common-component owner |
| `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_cheque-registers.blade.php` | The actual list/create modal for this screen is rendered by `AccDashboardController::chequesReconciliation`, not by this controller. It posts to this controller's `store`, `update` and `destroy` routes and uses the same permission strings (lines 96-99, 122-123). Not audited here; the create modal also omits the `is_active` field, which is why CHQR-09 is invisible today. | F10 (other controller) | `AccDashboardController` report (CLAIMED) |
| `database/migrations/tenant/2026_09_16_130001_add_soft_deletes_and_is_active_to_accounting_tables.php` | Documents that 19 Accounting tables now carry both `status` and `is_active` (two sources of truth). `acc_cheque_registers` is one of them; this report treats `status` as the source of truth and CHQR-09 only makes the display flag round-trip. | MDL-09 | module-wide decision (Tarun) |

## 8. Not covered, and why

- **Scanner and self-check were skipped.** `final-audit-reports/_tools/scanfilter.py` and `selfcheck.py` are missing and `scan.php` must not be run in this run (tooling override). F1–F13 were therefore done manually with `read`, `Select-String`, `php -l`, `pint --test` and the uncached route probe.
- **No tests, no browser run (D4).** Every "Reproduce" is either a static proof or the exact URL/action a tester should use; nothing was executed against a browser or a test suite.
- **`index.blade.php` was not audited as a live screen** because no route or view renders it (the list is the `AccDashboardController` tab partial). If it is meant to stay, it is dead code; if not, it should be deleted in a separate change.
- **Views were read, not compiled/rendered.** `create`, `edit`, `show` and `trash` were checked for queries, `{!! !!}` and missing null checks; no Blade compile was run.
- **The tab partial and the listing queries belong to `AccDashboardController`** (index row `CLAIMED`), so its `$chequeRegisters`/`$bankLedgers` queries, export buttons and search behaviour were not audited here.
- **`ChequeLeaf`, `Ledger` and `BaseAccountingModel` are audited by other reports**; only this controller's use of them was checked (see §3 and §7).
- **No queue, job, mail or file side effects exist in this controller**, so JOB/SVC-01..03 and TXN-03 were checked as not present.
