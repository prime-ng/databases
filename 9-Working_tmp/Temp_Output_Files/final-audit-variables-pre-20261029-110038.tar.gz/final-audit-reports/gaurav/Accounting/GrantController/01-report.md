# Final Audit — Accounting / GrantController

**Audited:** 2026-10-24 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/GrantController.php` (295 lines, 14 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/school-specific?tab=grants` (the list; `accounting.grant.index` and `accounting.grant.create` redirect here) · `http://test.localhost:8000/accounting/grant/{grant}` (details) · `http://test.localhost:8000/accounting/grant/{grant}/edit` (edit) · `http://test.localhost:8000/accounting/grant/trash/view` (trash) |
| Menu path | Accounting → School Specific → **Institutional Grants** tab |
| Who uses it | Measured in the tenant database: `sys_permissions` holds **0** rows matching `tenant.accounting.grant%`, so **no role** can open this tab. Only Super Admin sees it, through the `Gate::before` bypass in `app/Providers/AppServiceProvider.php:78-87`. The parent dashboard permission is held by 5 roles: Super Admin, School Admin, Management, Account Staff, Account Manager. |
| What a user does here | Registers an institutional grant (government / CSR / trust funding) against a dedicated fund, records the utilisation certificate, recognises the grant receivable as an accounting voucher, moves the grant through its statuses, and soft-deletes / restores records. |
| Tables written | `acc_grants`; `acc_vouchers` and `acc_voucher_items` (through `VoucherService` when a receivable is recognised); `sys_activity_logs` (expected, currently never written). |
| Tables read | `acc_grants`, `acc_funds`, `acc_ledgers`, `acc_account_groups`, `acc_campuses`, `acc_cost_centers`, `acc_voucher_types`, `acc_financial_years`, `acc_fund_balances`, `sys_users`, `sys_media`. |
| Live data | Tenant `xyz_school_00000000000040008000_202627`: `acc_grants` **1** live row (0 trashed, 1 active), `acc_funds` **4**, `acc_ledgers` **56**, `sys_media` **2**. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**No — not production-ready.** The controller authorizes, validates and transacts in the right places in outline, but three defects make the shipped screen unsafe or unreachable: the permission key `accounting.grant` does not exist in `config/permissionslist.php` or in the tenant database, so every non-Super-Admin role gets a 403 and the Grants tab is hidden; the three write methods put `$e->getMessage()` straight into the red flash, so a failed SQL statement shows table and column names to the user; and `toggleStatus()` writes `is_active`, which is missing from `Grant::$fillable`, so the switch reports success while changing nothing.
The single worst finding is **GRNT-01 (B, ERR-01)** — raw exception text reaches the browser. The most user-visible is **GRNT-06 (H, AUTH-01)** — the feature is invisible to all five intended roles.
Effort: **M** (roughly one working day for the controller rewrite, one new FormRequest, one shared route/permission decision, and a Pint pass). Nothing in this report was applied.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 7 | 8 | 6 | 2 | 22 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | GRNT-01, GRNT-02 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | GRNT-03, GRNT-04, GRNT-05 | F9 Queries/Perf | GRNT-16 |
| F3 Authorization | GRNT-06, GRNT-07, GRNT-08 | F10 Views | GRNT-17 |
| F4 Validation | GRNT-09, GRNT-10 | F11 Security/Tenancy | clean |
| F5 Routes | GRNT-11 | F12 Style | GRNT-18, GRNT-19, GRNT-20 |
| F6 Controller shape | GRNT-12, GRNT-13 | F13 Deep read | GRNT-21, GRNT-22 |
| F7 Models | GRNT-14, GRNT-15 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/GrantController.php` | controller | 295 | this report | ✅ |
| 2 | `Modules/Accounting/app/Http/Requests/GrantRequest.php` | FormRequest | 51 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Models/Grant.php` | model | 147 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/resources/views/grant/show.blade.php` | view | 136 | this report | ✅ |
| 5 | `Modules/Accounting/resources/views/grant/edit.blade.php` | view | 121 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/grant/trash.blade.php` | view | 67 | this report | ✅ |
| 7 | `Modules/Accounting/app/Services/VoucherService.php` | service | 402 | ↗ [gaurav/Accounting/VoucherController](../VoucherController/01-report.md) — report not written yet | ↗ linked |
| 8 | `Modules/Accounting/app/Models/Fund.php` | model | 68 | ↗ [gaurav/Accounting/FundController](../FundController/01-report.md) — report not written yet | ↗ linked |
| 9 | `Modules/Accounting/app/Models/FundBalance.php` | model | 63 | ↗ [gaurav/Accounting/FundController](../FundController/01-report.md) — report not written yet | ↗ linked |
| 10 | `Modules/Accounting/app/Models/Ledger.php` | model | 408 | ↗ [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) — report not written yet | ↗ linked |
| 11 | `Modules/Accounting/app/Models/Campus.php` | model | 83 | ↗ [gaurav/Accounting/CampusController](../CampusController/01-report.md) — report not written yet | ↗ linked |
| 12 | `Modules/Accounting/app/Models/CostCenter.php` | model | 262 | ↗ [gaurav/Accounting/CostCenterController](../CostCenterController/01-report.md) — report not written yet | ↗ linked |
| 13 | `Modules/Accounting/app/Models/FinancialYear.php` | model | 168 | ↗ [gaurav/Accounting/FinancialYearController](../FinancialYearController/01-report.md) — report not written yet | ↗ linked |
| 14 | `Modules/Accounting/app/Models/VoucherType.php` | model | 185 | ↗ [gaurav/Accounting/VoucherTypeController](../VoucherTypeController/01-report.md) — report not written yet | ↗ linked |
| 15 | `Modules/Accounting/app/Models/Voucher.php` | model | 415 | ↗ [gaurav/Accounting/VoucherController](../VoucherController/01-report.md) — report not written yet | ↗ linked |
| 16 | `Modules/Accounting/resources/views/pages/partials/school-specific/_grants.blade.php` | view | 488 | ↗ [gaurav/Accounting/AccDashboardController](../AccDashboardController/01-report.md) — this controller does not render it | ↗ linked |

No pre-applied files. `Modules/Accounting/app/Models/BaseAccountingModel.php` is owned by
[gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) and is linked only.

## 4. Routes

Uncached (`php artisan route:clear`, then `APP_ROUTES_CACHE` pointed at a missing temp path):

```
GET|HEAD  accounting/grant                                        accounting.grant.index              Modules\Accounting\Http\Controllers\GrantController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/grant                                        accounting.grant.store              Modules\Accounting\Http\Controllers\GrantController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/grant/create                                 accounting.grant.create             Modules\Accounting\Http\Controllers\GrantController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/grant/trash/view                             accounting.grant.trashed            Modules\Accounting\Http\Controllers\GrantController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/grant/{grant}                                accounting.grant.show               Modules\Accounting\Http\Controllers\GrantController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/grant/{grant}                                accounting.grant.update             Modules\Accounting\Http\Controllers\GrantController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/grant/{grant}                                accounting.grant.destroy            Modules\Accounting\Http\Controllers\GrantController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/grant/{grant}/change-status                  accounting.grant.changeStatus       Modules\Accounting\Http\Controllers\GrantController@changeStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/grant/{grant}/edit                           accounting.grant.edit               Modules\Accounting\Http\Controllers\GrantController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/grant/{grant}/file-certificate               accounting.grant.fileCertificate    Modules\Accounting\Http\Controllers\GrantController@fileCertificate  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/grant/{grant}/recognise-receivable           accounting.grant.recogniseReceivable Modules\Accounting\Http\Controllers\GrantController@recogniseReceivable  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/grant/{grant}/toggle-status                  accounting.grant.toggleStatus       Modules\Accounting\Http\Controllers\GrantController@toggleStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/grant/{id}/force-delete                      accounting.grant.forceDelete        Modules\Accounting\Http\Controllers\GrantController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/grant/{id}/restore                           accounting.grant.restore            Modules\Accounting\Http\Controllers\GrantController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: **none** — all 14 public methods (13 actions + the constructor) appear above.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 28 | GET /accounting/grant | `tenant.accounting.grant.viewAny` | none | none | none (redirect) | GRNT-06 |
| `create` | 35 | GET /accounting/grant/create | `tenant.accounting.grant.create` | none | none | none (redirect) | GRNT-06 |
| `store` | 42 | POST /accounting/grant | `tenant.accounting.grant.create` | controller, manual | none | `acc_grants`; `acc_vouchers`, `acc_voucher_items` via service | GRNT-01, GRNT-02, GRNT-03, GRNT-04, GRNT-05, GRNT-06, GRNT-07 |
| `show` | 69 | GET /accounting/grant/{grant} | `tenant.accounting.grant.view` | none | none | none (read) | GRNT-06 |
| `edit` | 80 | GET /accounting/grant/{grant}/edit | `tenant.accounting.grant.update` | none | none | none (read) | GRNT-06 |
| `update` | 93 | PUT/PATCH /accounting/grant/{grant} | `tenant.accounting.grant.update` | controller, manual | none | `acc_grants`; `acc_vouchers`, `acc_voucher_items` on first recognition | GRNT-01, GRNT-02, GRNT-03, GRNT-04, GRNT-05, GRNT-06, GRNT-07, GRNT-22 |
| `recogniseReceivable` | 122 | POST /accounting/grant/{grant}/recognise-receivable | `tenant.accounting.grant.update` | controller, manual | none | `acc_grants`, `acc_vouchers`, `acc_voucher_items` | GRNT-01, GRNT-02, GRNT-03, GRNT-04, GRNT-05, GRNT-06 |
| `fileCertificate` | 205 | POST /accounting/grant/{grant}/file-certificate | `tenant.accounting.grant.update` | none (single row) | none | `acc_grants` | GRNT-05, GRNT-06, GRNT-09, GRNT-10, GRNT-21 |
| `changeStatus` | 227 | POST /accounting/grant/{grant}/change-status | `tenant.accounting.grant.update` | none (single row) | none | `acc_grants` | GRNT-05, GRNT-06, GRNT-21 |
| `toggleStatus` | 244 | POST /accounting/grant/{grant}/toggle-status | `tenant.accounting.grant.update` | none (single row) | none | `acc_grants` (silently discarded) | GRNT-05, GRNT-06, GRNT-14 |
| `destroy` | 253 | DELETE /accounting/grant/{grant} | `tenant.accounting.grant.delete` | none (single row) | none | `acc_grants` (soft delete) | GRNT-04, GRNT-05, GRNT-06 |
| `trashed` | 267 | GET /accounting/grant/trash/view | `tenant.accounting.grant.delete` | none | none | none (read) | GRNT-06, GRNT-08, GRNT-16 |
| `restore` | 276 | GET /accounting/grant/{id}/restore | `tenant.accounting.grant.delete` | none (single row) | none | `acc_grants` | GRNT-05, GRNT-06, GRNT-08, GRNT-11, GRNT-12 |
| `forceDelete` | 286 | DELETE /accounting/grant/{id}/force-delete | `tenant.accounting.grant.delete` | none (single row) | none | `acc_grants` | GRNT-05, GRNT-06, GRNT-08, GRNT-11, GRNT-12 |

## 6. Findings

### F1 — Errors

#### GRNT-01 · B · ERR-01 — raw exception text is shown to the user

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-01 · B · ERR-01 |
| Category | Errors |
| Where | `GrantController.php:65`, `:118`, `:139` |
| What is wrong | All three write paths put `$e->getMessage()` into the red flash verbatim. |
| Why it matters | A failed insert/update exposes SQL, table names, column names and driver messages to the browser, and a crafted duplicate key can echo the submitted value. This is the only B in the file. |
| Root cause | `catch (\Throwable $e)` is used as the error handler instead of letting Laravel's handler report and render the exception. |
| Reproduce | Super Admin → Institutional Grants → create a grant → the insert fails (for example, a duplicated `grant_code` raced past validation) → the flash reads `Failed to create grant: SQLSTATE[23000]: Integrity constraint violation: ... acc_grants.grant_code ...`. |
| Fix | Remove the `try/catch` and use `DB::transaction(fn () => …)`; let the central handler render. See plan GRNT-01. |

Current code:

```php
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->withInput()->with('error', 'Failed to create grant: ' . $e->getMessage());
        }
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "getMessage"
65:            return redirect()->back()->withInput()->with('error', 'Failed to create grant: ' . $e->getMessage());
118:            return redirect()->back()->withInput()->with('error', 'Failed to update grant: ' . $e->getMessage());
139:            return redirect()->back()->with('error', 'Failed to recognise grant receivable: ' . $e->getMessage());
```

#### GRNT-02 · H · ERR-06 — a failed receivable recognition reports success

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-02 · H · ERR-06 |
| Category | Errors |
| Where | `GrantController.php:55-56`, `:108-109`, `:132-133`; helper guards `:162`, `:172` |
| What is wrong | `recogniseReceivableInternal()` returns `void`. When the grantor ledger, the liability ledger, the sanctioned amount or the journal voucher type is missing, it returns early having written nothing, and the caller still flashes "created / updated / recognised". |
| Why it matters | The user believes a receivable was posted, the grant shows no `receivable_voucher_id`, and the ledger stays out of balance against the sanction. There is no way to tell from the UI that recognition was skipped. |
| Root cause | The helper reports "nothing to do" by silence; the callers do not inspect any outcome. |
| Reproduce | Create a grant with `recognition_basis = On_Sanction`, `grantor_name` that matches no ledger, sanctioned amount 50000 → success flash, `acc_grants.receivable_voucher_id` is NULL, `acc_vouchers` count unchanged. |
| Fix | Return `bool` from the helper (`false` on both early exits) and let the caller warn. See plan GRNT-01. |

Current code:

```php
            if ($grant->recognition_basis === 'On_Sanction') {
                $this->recogniseReceivableInternal($grant);
            }
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "recogniseReceivableInternal|^        if \(\$grantorLedgerId"
55:                $this->recogniseReceivableInternal($grant);
109:                $this->recogniseReceivableInternal($grant);
132:                $this->recogniseReceivableInternal($grant);
143:    private function recogniseReceivableInternal(Grant $grant): void
162:        if ($grantorLedgerId && $liabilityLedgerId && (float) $grant->sanctioned_amount > 0) {
```

### F2 — Transactions and audit

#### GRNT-03 · M · TXN-02 — hand-rolled transactions

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-03 · M · TXN-02 |
| Category | Transactions / audit trail |
| Where | `GrantController.php:50,59,64`, `:104,112,117`, `:130,133,138` |
| What is wrong | Three methods call `DB::beginTransaction()`, `DB::commit()` and `DB::rollBack()` manually instead of `DB::transaction()`. |
| Why it matters | A missed `commit`/`rollBack` on a future edit leaves the connection in an open transaction; the pattern is also the direct cause of GRNT-01 (the catch exists only to roll back). |
| Root cause | Copy-paste from the older controller pattern instead of the project's `DB::transaction(fn () => …)` convention. |
| Reproduce | Static: the nine call sites above. A thrown exception outside the `try` (for example, in the redirect) leaves the transaction open. |
| Fix | Replace all three blocks with `DB::transaction()`. See plan GRNT-01. |

Current code:

```php
        DB::beginTransaction();
        try {
            $grant = Grant::create($validated);
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "DB::(beginTransaction|commit|rollBack)"
50:        DB::beginTransaction();
59:            DB::commit();
64:            DB::rollBack();
104:        DB::beginTransaction();
112:            DB::commit();
117:            DB::rollBack();
130:        DB::beginTransaction();
133:            DB::commit();
138:            DB::rollBack();
```

#### GRNT-04 · H · TXN-06 — check-then-act on `receivable_voucher_id`

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-04 · H · TXN-06 |
| Category | Transactions / audit trail |
| Where | `GrantController.php:108`, `:126`, `:257` |
| What is wrong | All three paths read `$grant->receivable_voucher_id` from the route-bound instance and then act, with no row lock. Two concurrent requests both pass the guard. |
| Why it matters | Two operators clicking "Recognise" (or a double submit) can post two receivable vouchers against one grant, doubling the ledger receivable. A delete racing a recognition can remove a grant that just got a voucher. |
| Root cause | No `lockForUpdate()` (or unique index on `acc_grants.receivable_voucher_id`) around the read. |
| Reproduce | Open the grant in two tabs, click "Recognise receivable" in both within the same second → the second request still sees NULL and posts a second voucher. |
| Fix | Lock the grant row inside the transaction and re-read the flag. See plan GRNT-01 (update/recognise) and GRNT-05 (destroy). |

Current code:

```php
        if ($grant->receivable_voucher_id) {
            return redirect()->back()->with('warning', 'Receivable voucher already exists for this grant.');
        }
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "receivable_voucher_id"
108:            if ($grant->recognition_basis === 'On_Sanction' && !$grant->receivable_voucher_id) {
126:        if ($grant->receivable_voucher_id) {
199:                $grant->receivable_voucher_id = $voucher->id;
257:        if ($grant->receivable_voucher_id) {
```

#### GRNT-05 · M · TXN-04 — no audit-trail entry for any grant mutation

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-05 · M · TXN-04 |
| Category | Transactions / audit trail |
| Where | whole controller — 0 occurrences of `activityLog` |
| What is wrong | None of the nine mutating methods writes to `sys_activity_logs`. |
| Why it matters | Grant approvals, certificate filing, status changes and deletions are financial events with no audit trail; "who changed the sanction amount" cannot be answered. |
| Root cause | `activityLog()` was never added; the module helper exists (`app/Helpers/helpers.php`). |
| Reproduce | Super Admin → edit a grant → save → `SELECT COUNT(*) FROM sys_activity_logs WHERE subject_type LIKE '%Grant%'` stays 0. |
| Fix | Add `activityLog($grant, '<Event>', [...])` inside the transaction, after the write, for every mutation. See plan GRNT-01, GRNT-05, GRNT-09, GRNT-11. |

Current code (the whole method has no log):

```php
        $grant->update(['is_active' => !$grant->is_active]);

        return redirect()->back()->with('success', 'Grant status updated.');
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "activityLog"
(no output)
```

### F3 — Authorization

#### GRNT-06 · H · AUTH-01 — the permission key does not exist; the screen is unreachable

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-06 · H · AUTH-01 |
| Category | Authorization |
| Where | `GrantController.php` (all gates `tenant.accounting.grant.*`) vs `config/permissionslist.php:633` |
| What is wrong | The controller and both blades gate on `tenant.accounting.grant`, but `config/permissionslist.php` declares no `accounting.grant` key and the tenant database has **0** `tenant.accounting.grant%` rows. Only the Super Admin `Gate::before` bypass passes. |
| Why it matters | No real role can use the feature: the Grants tab is hidden (`@can('tenant.accounting.grant.viewAny')`) and a direct URL returns 403. Five roles already hold the fund and dashboard permissions, which is the pattern a grant key would follow. |
| Root cause | The permission key was never added to the shared config, so `sync-permissions` never seeded it. |
| Reproduce | Log in as School Admin → Accounting → School Specific → the Grants tab is absent; open `/accounting/grant/trash/view` directly → 403. |
| Fix | ⚠ DECISION — add the key + `recogniseReceivable`/`fileCertificate` abilities, then sync. See plan GRNT-06. |

Current code:

```php
        Gate::authorize('tenant.accounting.grant.viewAny');
```

Evidence:

```
PS> Select-String -Path "config\permissionslist.php" -Pattern "accounting\.(grant|fund)"
633: 'accounting.fund' => $crud,
634: 'accounting.fund-balance' => ['viewAny', 'view'],

PS> mysql -u root -N -e "select count(*) from xyz_school_00000000000040008000_202627.sys_permissions where name like 'tenant.accounting.grant%';"
0
PS> mysql -u root -N -e "select count(*) from xyz_school_00000000000040008000_202627.sys_permissions where name like 'tenant.accounting.fund%';"
9
```

#### GRNT-07 · M · AUTH-02 — `GrantRequest::authorize()` is unconditional

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-07 · M · AUTH-02 |
| Category | Authorization |
| Where | `GrantRequest.php:14-17` |
| What is wrong | `authorize()` returns `true`, so the FormRequest authorizes nothing; the controller's `Gate::authorize` is the only check, and it runs after the request has been resolved and validated. |
| Why it matters | Authorization should happen before validation/loading. The project already has `AuthorizesTenantFeature` for exactly this; FundRequest uses it. |
| Root cause | The class was generated without the trait. |
| Reproduce | Static: `return true;`. A caller that forgets the controller gate would accept any authenticated tenant user. |
| Fix | `use AuthorizesTenantFeature; return $this->authorizeByCrudPermission('tenant.accounting.grant');`. See plan GRNT-07. |

Current code:

```php
    public function authorize(): bool
    {
        return true;
    }
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Requests\GrantRequest.php" -Pattern "function authorize" -Context 0,3
14:    public function authorize(): bool
15:    {
16:        return true;
17:    }
```

#### GRNT-08 · M · AUTH-05 — trash surfaces use `.delete`, the shared UI uses `.restore`

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-08 · M · AUTH-05 |
| Category | Authorization |
| Where | `GrantController.php:269`, `:278`, `:288`; `config/permissionslist.php:176-184`; `x-backend.tab.search-bar` |
| What is wrong | `trashed()`, `restore()` and `forceDelete()` all require `tenant.accounting.grant.delete`. The config declares separate `.restore` and `.forceDelete` abilities, the trash button in `search-bar` checks `.restore`, and `x-backend.table.action-trashed` derives `.restore`/`.forceDelete` URLs. FundController uses `.restore`/`.forceDelete`. |
| Why it matters | A role with `delete` but not `restore` can open the trash but sees no Trash button; a role with `restore` but not `delete` sees the button and gets 403. Permanent deletion is guarded by the wrong, weaker ability. |
| Root cause | The three methods were copy-pasted with the delete gate. |
| Reproduce | Grant `.restore` but not `.delete` to a role → the Trash tab appears (search-bar checks `.restore`) → clicking it returns 403 (trashed() checks `.delete`). |
| Fix | `trashed()`/`restore()` → `.restore`; `forceDelete()` → `.forceDelete`. See plan GRNT-11. |

Current code:

```php
    public function forceDelete(int $id): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.delete');
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "accounting\.grant\.(delete|restore|forceDelete)"
255:        Gate::authorize('tenant.accounting.grant.delete');
269:        Gate::authorize('tenant.accounting.grant.delete');
278:        Gate::authorize('tenant.accounting.grant.delete');
288:        Gate::authorize('tenant.accounting.grant.delete');

PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\FundController.php" -Pattern "accounting\.fund\.(restore|forceDelete)"
181:        Gate::authorize('tenant.accounting.fund.restore');
190:        Gate::authorize('tenant.accounting.fund.restore');
217:        Gate::authorize('tenant.accounting.fund.forceDelete');
```

### F4 — Validation and input

#### GRNT-09 · M · VAL-02 — inline validation in the controller

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-09 · M · VAL-02 |
| Category | Validation |
| Where | `GrantController.php:209-213` |
| What is wrong | `fileCertificate()` validates three fields with `$request->validate([...])` inside the action instead of a FormRequest. `store()`/`update()` already use `GrantRequest`; this action does not. |
| Why it matters | Rules live in two places for one resource, cannot be reused by tests or other callers, and the action authorizes before it validates, so the check order differs from the rest of the controller. |
| Root cause | The endpoint was added later without a FormRequest. |
| Reproduce | Static: the inline array at :209. |
| Fix | New `FileCertificateRequest`; type-hint it in the action. See plan GRNT-09. |

Current code:

```php
        $request->validate([
            'utilisation_cert_filed_on' => 'required|date',
            'utilisation_cert_media_id' => 'nullable|integer',
            'notes'                     => 'nullable|string|max:1000',
        ]);
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "request->validate"
209:        $request->validate([
231:        $request->validate([
```

#### GRNT-10 · M · VAL-05 — `utilisation_cert_media_id` is not checked against `sys_media`

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-10 · M · VAL-05 |
| Category | Validation |
| Where | `GrantController.php:211`, `:217`; `GrantRequest.php` has no such field |
| What is wrong | The media id rule is `nullable|integer` only. No `exists:sys_media,id`, no ownership check. The column is a plain nullable integer with no FK. |
| Why it matters | Any integer can be stored (including another tenant's media id if the request is hand-crafted), and `show.blade.php` will try to render a missing file. |
| Root cause | The rule was written as a type check only. |
| Reproduce | POST `accounting.grant.fileCertificate` with `utilisation_cert_media_id=999999` and a valid date → 302 success, the grant stores 999999. |
| Fix | `['nullable', 'integer', 'exists:sys_media,id']` in the new FormRequest. See plan GRNT-09. |

Current code:

```php
            'utilisation_cert_media_id' => $request->input('utilisation_cert_media_id'),
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "utilisation_cert_media_id"
211:            'utilisation_cert_media_id' => 'nullable|integer',
217:            'utilisation_cert_media_id' => $request->input('utilisation_cert_media_id'),

PS> mysql -u root -N -e "select count(*) from xyz_school_00000000000040008000_202627.sys_media;"
2
```

### F5 — Routes

#### GRNT-11 · H · RTE-01 — restoring a grant is a GET

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-11 · H · RTE-01 |
| Category | Routes |
| Where | `Modules/Accounting/routes/web.php:522` |
| What is wrong | `GET /accounting/grant/{id}/restore` performs a state change. Any prefetch, crawler, link preview or `<img src>` can restore a deleted grant. |
| Why it matters | Unauthenticated GET side effects are CSRF-able and are the classic "link preview deletes data" bug. It also uses `{id}`, bypassing route-model binding (GRNT-12). |
| Root cause | The route was written as a link target for the hand-rolled trash row actions. |
| Reproduce | As a user with trash access, paste `/accounting/grant/1/restore` in the address bar → grant restored with no confirmation. |
| Fix | `POST /grant/{grant}/restore` + `->withTrashed()`; the trash view posts through `x-backend.table.action-trashed`. See plan GRNT-11. |

Current code:

```php
Route::get('/grant/{id}/restore', [GrantController::class, 'restore'])->name('grant.restore');
Route::delete('/grant/{id}/force-delete', [GrantController::class, 'forceDelete'])->name('grant.forceDelete');
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "grant.(restore|forceDelete)|grant/trash"
521: Route::get('/grant/trash/view', [GrantController::class, 'trashed'])->name('grant.trashed');
522: Route::get('/grant/{id}/restore', [GrantController::class, 'restore'])->name('grant.restore');
523: Route::delete('/grant/{id}/force-delete', [GrantController::class, 'forceDelete'])->name('grant.forceDelete');
```

### F6 — Controller shape

#### GRNT-12 · M · CTL-03 — `{id}` plus `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-12 · M · CTL-03 |
| Category | Controller shape |
| Where | `GrantController.php:280`, `:290` |
| What is wrong | `restore(int $id)` and `forceDelete(int $id)` accept a raw id and resolve it with `Grant::onlyTrashed()->findOrFail($id)`, while every other action uses `Grant $grant`. |
| Why it matters | The two paths need hand-written 404/403 handling, cannot use implicit binding for trashed rows, and are the only methods where the "instance" is fetched after the gate. |
| Root cause | The routes use `{id}`. |
| Reproduce | Static: `restore(int $id)` at :276. |
| Fix | `restore(Grant $grant)` / `forceDelete(Grant $grant)` + `->withTrashed()` on the routes. See plan GRNT-11. |

Current code:

```php
        $grant = Grant::onlyTrashed()->findOrFail($id);
        $grant->restore();
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "function (trashed|restore|forceDelete)"
267:    public function trashed()
276:    public function restore(int $id): RedirectResponse
286:    public function forceDelete(int $id): RedirectResponse
```

#### GRNT-13 · L · CTL-04 — missing return types

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-13 · L · CTL-04 |
| Category | Controller shape |
| Where | `GrantController.php:28`, `:35`, `:69`, `:80`, `:267` |
| What is wrong | `index()`, `create()`, `show()`, `edit()` and `trashed()` have no return type. |
| Why it matters | The IDE and static analysis cannot tell a redirect from a view; the rest of the module (`FundController`) declares them. |
| Root cause | Omitted declarations. |
| Reproduce | Static: the five signatures. |
| Fix | `: RedirectResponse` for index/create; `: View` for show/edit/trashed. See plan item GRNT-11 (`trashed`) and §10 for the rest. |

Current code:

```php
    public function show(Grant $grant)
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "^    public function (index|create|show|edit|trashed)\("
28:    public function index(Request $request)
35:    public function create()
69:    public function show(Grant $grant)
80:    public function edit(Grant $grant)
267:    public function trashed()
```

### F7 — Models

#### GRNT-14 · H · MDL-01 — `is_active` is written but not fillable, so the toggle is a no-op

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-14 · H · MDL-01 |
| Category | Models |
| Where | `Grant.php:18-45` (fillable), `:47-55` (casts); migration `2026_09_16_130001_add_soft_deletes_and_is_active_to_accounting*.php` adds `acc_grants.is_active` |
| What is wrong | The column exists and `toggleStatus()` calls `$grant->update(['is_active' => ! $grant->is_active])`, but `is_active` is absent from `$fillable` and `$casts`. Eloquent discards it silently. |
| Why it matters | The Active/Inactive switch flashes "Grant status updated." and changes nothing; inactive grants stay visible in every dropdown. The database and UI disagree. |
| Root cause | The shared migration added the column after the model was written; the model was not updated. |
| Reproduce | Super Admin → Grants → toggle a row off → success flash → reload → the switch is still on and `acc_grants.is_active` is still 1. |
| Fix | Add `'is_active'` to `$fillable` and `'is_active' => 'boolean'` to `$casts`. See plan GRNT-14. |

Current code:

```php
        'created_by',
        'updated_by',
    ];
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Models\Grant.php" -Pattern "is_active"
128:        return $query->where('is_active', true);

PS> mysql -u root -N -e "show columns from xyz_school_00000000000040008000_202627.acc_grants like 'is_active';"
is_active	tinyint(1)	NO		1	
```

#### GRNT-15 · L · MDL-09 — status and basis strings are bare literals

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-15 · L · MDL-09 |
| Category | Models |
| Where | `GrantController.php:48`, `:55`, `:97`, `:108`, `:219`, `:232`; `Grant.php` |
| What is wrong | `'Sanctioned'`, `'On_Sanction'`, `'Closed'`, `'Cancelled'`, `'Fully_Utilised'` and the validation list are repeated string literals. The model has `grantorTypes()` but no status constants/enum. |
| Why it matters | A typo in one place (`'Fully_Utilised'` vs `'Fully Utilised'`) silently creates an unreachable state and breaks the status badge; the validation list can drift from the constants. |
| Root cause | No enum was introduced when the column was added. |
| Reproduce | Static: the repeated literals. |
| Fix | PHP enums or model constants; use them in controller, request and model. Informational — see §10. |

Current code:

```php
        $validated['status']     = 'Sanctioned';
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "Sanctioned|Fully_Utilised|On_Sanction|'Closed'"
48:        $validated['status']     = 'Sanctioned';
55:            if ($grant->recognition_basis === 'On_Sanction') {
97:        if (in_array($grant->status, ['Closed', 'Cancelled'], true)) {
108:            if ($grant->recognition_basis === 'On_Sanction' && !$grant->receivable_voucher_id) {
219:            'status'                    => 'Fully_Utilised',
232:            'status' => 'required|in:Sanctioned,Active,Fully_Utilised,Closed,Cancelled,Lapsed',
```

### F8 — Services and jobs

No findings.

### F9 — Queries and performance

#### GRNT-16 · L · QRY-02 — trash page size is 25

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-16 · L · QRY-02 |
| Category | Queries / performance |
| Where | `GrantController.php:271` |
| What is wrong | `paginate(25)` while the module standard is 10 (neighbouring accounting lists use 10; `FundController` uses 15). |
| Why it matters | The trash list shows 25 rows per page, inconsistent with every other accounting list, and scans a heavier eager-load set per page. Today `acc_grants` has 1 row, so the practical impact is cosmetic. |
| Root cause | Copy-paste default. |
| Reproduce | Trash more than 10 grants → the page shows up to 25 rows and the pager reports the 25-row page count. |
| Fix | `paginate(10, ['*'], 'trashed_page')`. Applied by plan GRNT-11. |

Current code:

```php
        $grants = Grant::onlyTrashed()->with(['fund', 'grantorLedger'])->paginate(25);
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "paginate\("
271:        $grants = Grant::onlyTrashed()->with(['fund', 'grantorLedger'])->paginate(25);
```

### F10 — Views

#### GRNT-17 · M · CTL-05 — hand-rolled trash row actions

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-17 · M · CTL-05 |
| Category | Views |
| Where | `grant/trash.blade.php:38-50` |
| What is wrong | The row actions are a hand-written Restore link plus a hand-written force-delete form, duplicating `x-backend.table.action-trashed` (which the rest of the module uses and which derives the correct route names and permissions). |
| Why it matters | The duplicate already encodes the wrong verb (GET restore, GRNT-11) and the wrong permission props; any future change to the shared component will not reach this page. |
| Root cause | Copy-paste instead of the shared component. |
| Reproduce | Open the trash page as a user with `.restore` — the markup is raw `<a>`/`<form>`, not the component. |
| Fix | Replace lines 38-50 with `<x-backend.table.action-trashed :id="$item->id" :url="route('accounting.grant.restore', $item->id)" tab="grants" />`. See plan GRNT-11. |

Current code:

```blade
                                            <a href="{{ route('accounting.grant.restore', $item->id) }}" class="btn btn-xs btn-outline-success" title="Restore">
                                                <i class="bi bi-arrow-counterclockwise"></i> Restore
                                            </a>
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\resources\views\grant\trash.blade.php" -Pattern "action-trashed|grant.restore|grant.forceDelete"
40: <a href="{{ route('accounting.grant.restore', $item->id) }}" ...
43: <form action="{{ route('accounting.grant.forceDelete', $item->id) }}" ...
(no "action-trashed" match)
```

### F11 — Security and tenancy

No findings.

### F12 — Style

#### GRNT-18 · L · STY-02 — the controller is not Pint-clean

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-18 · L · STY-02 |
| Category | Style |
| Where | `Modules/Accounting/app/Http/Controllers/GrantController.php` |
| What is wrong | `pint --test` fails with nine fixers. |
| Why it matters | The repo's style gate rejects the file, so CI/lint cannot pass and unrelated edits will keep producing noise. |
| Root cause | The file was written by hand and never formatted. |
| Reproduce | `php vendor\bin\pint --test Modules/Accounting/app/Http/Controllers/GrantController.php`. |
| Fix | Remove the unused `DomainException` import, then run Pint. See plan GRNT-18. |

Current code:

```php
use App\Http\Controllers\Controller;
use DomainException;
use Illuminate\Http\RedirectResponse;
```

Evidence:

```
PS> php vendor\bin\pint --test Modules/Accounting/app/Http/Controllers/GrantController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\GrantController.php","fixers":["function_declaration","concat_space","method_chaining_indentation","braces_position","no_unused_imports","not_operator_with_successor_space","single_line_empty_body","blank_line_before_statement","binary_operator_spaces"]}]}
```

#### GRNT-19 · L · STY-02 — `GrantRequest` is not Pint-clean

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-19 · L · STY-02 |
| Category | Style |
| Where | `Modules/Accounting/app/Http/Requests/GrantRequest.php` |
| What is wrong | The aligned `=>` columns violate `binary_operator_spaces`. |
| Why it matters | Lint gate failure. |
| Root cause | Manually aligned array. |
| Reproduce | `php vendor\bin\pint --test Modules/Accounting/app/Http/Requests/GrantRequest.php`. |
| Fix | Single space around `=>` (or run Pint). See plan GRNT-19. |

Current code:

```php
            'grant_code'                     => ['required', 'string', 'max:30', Rule::unique('acc_grants', 'grant_code')->ignore($grantId)],
            'name'                           => ['required', 'string', 'max:200'],
```

Evidence:

```
PS> php vendor\bin\pint --test Modules/Accounting/app/Http/Requests/GrantRequest.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\GrantRequest.php","fixers":["binary_operator_spaces"]}]}
```

#### GRNT-20 · L · STY-02 — `Grant` model is not Pint-clean

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-20 · L · STY-02 |
| Category | Style |
| Where | `Modules/Accounting/app/Models/Grant.php` |
| What is wrong | Unused `App\Models\BaseModel` import plus aligned casts. |
| Why it matters | Lint gate failure; the dead import suggests the model once extended `BaseModel` and no longer does. |
| Root cause | Unused import left behind. |
| Reproduce | `php vendor\bin\pint --test Modules/Accounting/app/Models/Grant.php`. |
| Fix | Remove the import, then run Pint. See plan GRNT-20. |

Current code:

```php
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
```

Evidence:

```
PS> php vendor\bin\pint --test Modules/Accounting/app/Models/Grant.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\Grant.php","fixers":["no_unused_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

#### GRNT-21 · H · CTL-06 — the closed/cancelled guard covers only `update()`

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-21 · H · CTL-06 |
| Category | Controller shape / business rules |
| Where | guard at `GrantController.php:97`; bypassed at `:205` (`fileCertificate`) and `:227` (`changeStatus`) |
| What is wrong | `update()` refuses to touch a grant whose status is `Closed` or `Cancelled`, but `fileCertificate()` and `changeStatus()` accept the same grant and write to it. `changeStatus()` can move a Closed grant back to Active; `fileCertificate()` can flip it to `Fully_Utilised`. |
| Why it matters | The guard defines the accounting boundary (a closed grant is final). Two endpoints walk around it, so a closed grant can be reopened or re-certified, and the audit trail (once added) would show a "closed" record changing afterwards. |
| Root cause | The rule was implemented per action instead of at one choke point (a service/action or a policy check shared by all writers). |
| Reproduce | Set a grant to `Closed` via changeStatus, then call changeStatus again with `Active` → 302 success; or file a certificate on the same grant → status becomes `Fully_Utilised`. |
| Fix | Apply the same guard in `changeStatus()` and `fileCertificate()`. See plan GRNT-05 and GRNT-09. |

Current code:

```php
        if (in_array($grant->status, ['Closed', 'Cancelled'], true)) {
            return redirect()->back()->with('error', "Cannot modify a grant with status [{$grant->status}].");
        }
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "Cannot modify a grant"
98:            return redirect()->back()->with('error', "Cannot modify a grant with status [{$grant->status}].");

PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "public function (update|fileCertificate|changeStatus)"
93:    public function update(GrantRequest $request, Grant $grant): RedirectResponse
205:    public function fileCertificate(Request $request, Grant $grant): RedirectResponse
227:    public function changeStatus(Request $request, Grant $grant): RedirectResponse
```

#### GRNT-22 · H · TXN-01 — DECISION: editing a recognised grant leaves the posted voucher stale

| Field | Value |
|---|---|
| ID / severity / rule | GRNT-22 · H · TXN-01 |
| Category | Transactions / audit trail |
| Where | `GrantController.php:101-110` |
| What is wrong | `update()` writes any validated field, including `sanctioned_amount`, `recognition_basis`, `fund_id` and `campus_id`. Once `receivable_voucher_id` is set, the existing voucher is never reversed or re-posted; the `if (! $grant->receivable_voucher_id)` guard skips recognition. |
| Why it matters | The grant says 100000 and the ledger receivable says 50000 (or On_Receipt with an existing on-sanction voucher). Financial statements and the grant report disagree permanently, with no correction path in the UI. |
| Root cause | Grant and voucher are two aggregates; no invariant or compensating action links them after the first post. |
| Reproduce | Create an On_Sanction grant (voucher posted), edit `sanctioned_amount` from 50000 to 100000 → success → the voucher still totals 50000. |
| Fix | ⚠ DECISION — block the financial fields after recognition (recommended) or reverse + repost. See plan GRNT-22. |

Current code:

```php
        $grant->update($validated);

        if ($grant->recognition_basis === 'On_Sanction' && !$grant->receivable_voucher_id) {
            $this->recogniseReceivableInternal($grant);
        }
```

Evidence:

```
PS> Select-String -Path "Modules\Accounting\app\Http\Controllers\GrantController.php" -Pattern "sanctioned_amount|receivable_voucher_id"
108:            if ($grant->recognition_basis === 'On_Sanction' && !$grant->receivable_voucher_id) {
187:                        'amount'     => (float) $grant->sanctioned_amount,
193:                        'amount'     => (float) $grant->sanctioned_amount,
199:                $grant->receivable_voucher_id = $voucher->id;
```

## 7. Cross-cutting notes (common or other-module classes - not fixed here)

| Where | What | Owner |
|---|---|---|
| `Modules/Accounting/resources/views/pages/partials/school-specific/_grants.blade.php:105`, `:181` | Buttons check `@can('tenant.accounting.grant.recogniseReceivable')` and `@can('tenant.accounting.grant.fileCertificate')`, abilities the config does not declare; with GRNT-06 unfixed both are always false. | ↗ [AccDashboardController](../AccDashboardController/01-report.md) |
| `_grants.blade.php` create modal | ~17 form controls in one modal (project standard ≤15). | ↗ [AccDashboardController](../AccDashboardController/01-report.md) |
| `Modules/Accounting/app/Services/VoucherService.php:37` | `'voucher_category_id' => $data['voucher_category_id'] ?? 1` hard-codes category 1 for every voucher created through the service, including grant receivables. | ↗ [VoucherController](../VoucherController/01-report.md) — SEC-03 |
| `Modules/Accounting/app/Models/BaseAccountingModel.php:28` | `Auth::id() ?? 1` attributes writes to user 1 when unauthenticated. | ↗ [AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) — SEC-03 |

## 8. Not covered, and why

- **Scanner + self-check were skipped.** `final-audit-reports/_tools/scanfilter.py` and `final-audit-reports/_tools/selfcheck.py` do not exist in this workspace, and `scan.php` is forbidden by the binding override for this audit. F1–F13 were therefore walked by hand from the rulebook; no automated report validation was possible.
- **No tests were run** (protocol D4, read-only audit).
- **No write path was executed** against the tenant. Permission and row counts in §0/§6 are read-only `SELECT`s from `xyz_school_00000000000040008000_202627`; the race in GRNT-04 and the stale voucher in GRNT-22 are proven by code reading, not by concurrent requests.
- **`VoucherService` internals were not audited** (owned by VoucherController); only its `create()`/`post()` signatures and the grant call sites were checked.
- **Blades were read, not rendered.** `trash.blade.php` was checked for the row-action component; `show`/`edit` were checked for the fields they dereference, not for pixel layout.
- **`_grants.blade.php` is owned by AccDashboardController** — only the grant-specific permissions and modal size were noted; the rest of that 488-line view was not audited.
- **No `pint.json` exists** in the project, so the default Laravel preset is the style truth.

## 9. What needs your decision

1. **GRNT-06 — grant the feature to real roles?** Adding `'accounting.grant' => array_merge($crud, ['recogniseReceivable', 'fileCertificate'])` to `config/permissionslist.php` (⚠ SHARED) plus a per-tenant permission sync is the only way the tab becomes visible to non-Super-Admins. The alternative is to keep it Super-Admin-only and document that. Recommended: add it, matching the 5 roles that already hold `accounting.fund` and `accounting.dashboard.view`.
2. **GRNT-22 — what happens when a recognised grant is edited?** Recommended: block changes to `sanctioned_amount`, `recognition_basis`, `fund_id` and `campus_id` while `receivable_voucher_id` is set, with a message to reverse the voucher first. The alternative is automatic reverse + repost (more code, touches VoucherService, and needs a reversal convention this module does not currently have).

Judgment calls already made (not counted as decisions): `trashed()` will gate on `.restore` (matches `FundController` and `search-bar`); the destructively-verb route fix keeps DELETE for force-delete but changes restore to POST; style is fixed by Pint rather than by hand-formatting every line.

## 10. Findings whose fix is applied by another item

| Finding | Severity | Applied by | Note |
|---|---|---|---|
| GRNT-02 | H | GRNT-01 | Helper returns `bool`; callers warn on `false`. |
| GRNT-03 | M | GRNT-01 | All three manual blocks become `DB::transaction()`. |
| GRNT-04 | H | GRNT-01, GRNT-05 | `lockForUpdate()` in update/recognise/destroy. |
| GRNT-08 | M | GRNT-11 | `.restore` / `.forceDelete` gates. |
| GRNT-10 | M | GRNT-09 | `exists:sys_media,id` in `FileCertificateRequest`. |
| GRNT-12 | M | GRNT-11 | `Grant $grant` + `->withTrashed()` routes. |
| GRNT-13 | L | GRNT-11 + informational | `trashed(): View`; the other four are one-line declarations, listed here as not worth a separate item. |
| GRNT-15 | L | informational | Enums/constants are a refactor, not a defect fix; no behaviour change recommended in this pass. |
| GRNT-16 | L | GRNT-11 | `paginate(10, ['*'], 'trashed_page')` in the rewritten `trashed()`. |
| GRNT-17 | M | GRNT-11 | Row actions replaced by `x-backend.table.action-trashed`. |
| GRNT-21 | H | GRNT-05, GRNT-09 | Guard added to `changeStatus()` and `fileCertificate()`. |

