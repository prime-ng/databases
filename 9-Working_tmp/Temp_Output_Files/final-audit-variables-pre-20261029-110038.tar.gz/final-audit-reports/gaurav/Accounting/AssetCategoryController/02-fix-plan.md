# Fix Plan - AssetCategoryController

**Controller:** `Modules\Accounting\app\Http\Controllers\AssetCategoryController.php`  
**ABBR:** ASCA  
**Report:** `01-report.md`  
**Mode:** read-only audit; apply in the order shown and re-measure after each item.

> Apply **ASCA-01** first. It rewrites the six mutators that several later items refer to. Do not change `00-CLASS-OWNERS.md` or `gaurav\Accounting\00-INDEX.md`.

## 0. Do not touch

- **Owner-limited linked classes:** `Modules\Accounting\app\Models\Ledger.php`, `Modules\Accounting\app\Models\FixedAsset.php`, `Modules\Accounting\app\Models\BaseAccountingModel.php`, `Modules\Accounting\Services\AccountingContext.php` - owned by the linked reports named in `01-report.md` section 7; do not edit them here.
- **AccDashboard-owned UI:** `Modules\Accounting\resources\views\pages\partials\assets-integration\_asset-categories.blade.php` and `AccDashboardController::assetsIntegration()` - own the real list/modal; do not edit them here.
- **Shared routes:** `Modules\Accounting\routes\web.php` - only the two asset-category lines named in **ASCA-04** and **ASCA-17** may be touched, and only when those `⚠ SHARED` items are ticked; every other controller's routes are out of bounds.
- **Helpers and process:** No new helper is needed. The rewrite keeps the existing `activityLog()` helper and `AssetCategory::isDeletable()`. Do not duplicate either. Do not commit unless asked; do not run the test suite (D4). Do not change `00-CLASS-OWNERS.md` or `gaurav\Accounting\00-INDEX.md`.

## 1. Blockers reachable today

- [ ] **ASCA-01** - B - ERR-01, ERR-02, ERR-05, TXN-04, TXN-06, STY-07 - `AssetCategoryController.php:32-182` - rewrite all six mutators: no `try/catch`, every `activityLog()` inside the transaction, resolve the trashed row before any write, lock the row before `isDeletable()` in `destroy()`, and make the destroy message tell the truth. This one item also closes **ASCA-02, ASCA-03, ASCA-05, ASCA-14 and ASCA-21**.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AssetCategoryController.php`
  - **Before - `store()` (`AssetCategoryController.php:32-51`):**
    ```php
    public function store(AssetCategoryRequest $request)
    {
        Gate::authorize('tenant.accounting.asset-category.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        try {
            $category = \Illuminate\Support\Facades\DB::transaction(function () use ($validated) {
                return AssetCategory::create($validated);
            });

            activityLog($category, 'Created', ['message' => 'Asset Category created.', 'name' => $category->name]);

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'asset-categories'])->with('success', 'Asset Category created successfully.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('AssetCategory create failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to create Asset Category: ' . $e->getMessage())->withInput();
        }
    }
    ```
  - **After - `store()`:**
    ```php
    public function store(AssetCategoryRequest $request): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.asset-category.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        \Illuminate\Support\Facades\DB::transaction(function () use ($validated) {
            $category = AssetCategory::create($validated);

            activityLog($category, 'Created', ['message' => 'Asset Category created.', 'name' => $category->name]);
        });

        return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'asset-categories'])->with('success', 'Asset Category created successfully.');
    }
    ```
  - **Before - `update()` (`AssetCategoryController.php:73-89`):**
    ```php
    public function update(AssetCategoryRequest $request, AssetCategory $assetCategory)
    {
        Gate::authorize('tenant.accounting.asset-category.update');

        try {
            \Illuminate\Support\Facades\DB::transaction(function () use ($assetCategory, $request) {
                $assetCategory->update($request->validated());
            });

            activityLog($assetCategory, 'Updated', ['message' => 'Asset Category updated.', 'name' => $assetCategory->name]);

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'asset-categories'])->with('success', 'Asset Category updated successfully.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('AssetCategory update failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to update Asset Category: ' . $e->getMessage())->withInput();
        }
    }
    ```
  - **After - `update()`:**
    ```php
    public function update(AssetCategoryRequest $request, AssetCategory $assetCategory): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.asset-category.update');

        $validated = $request->validated();

        \Illuminate\Support\Facades\DB::transaction(function () use ($assetCategory, $validated) {
            $assetCategory->update($validated);

            activityLog($assetCategory, 'Updated', ['message' => 'Asset Category updated.', 'name' => $assetCategory->name]);
        });

        return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'asset-categories'])->with('success', 'Asset Category updated successfully.');
    }
    ```
  - **Before - `destroy()` (`AssetCategoryController.php:91-113`):**
    ```php
    public function destroy(AssetCategory $assetCategory)
    {
        Gate::authorize('tenant.accounting.asset-category.delete');

        if (! $assetCategory->isDeletable()) {
            return back()->with('error', 'Cannot delete category with existing fixed assets.');
        }

        try {
            \Illuminate\Support\Facades\DB::transaction(function () use ($assetCategory) {
                $assetCategory->is_active = false;
                $assetCategory->save();
                $assetCategory->delete();
            });

            activityLog($assetCategory, 'Trashed', ['message' => 'Asset Category trashed.', 'name' => $assetCategory->name]);

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'asset-categories'])->with('success', 'Asset Category moved to trash.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('AssetCategory destroy failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to delete Asset Category: ' . $e->getMessage());
        }
    }
    ```
  - **After - `destroy()`:**
    ```php
    public function destroy(AssetCategory $assetCategory): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.asset-category.delete');

        $deleted = \Illuminate\Support\Facades\DB::transaction(function () use ($assetCategory) {
            $locked = AssetCategory::whereKey($assetCategory->getKey())->lockForUpdate()->first();

            if ($locked === null || ! $locked->isDeletable()) {
                return false;
            }

            $locked->is_active = false;
            $locked->save();
            $locked->delete();

            activityLog($locked, 'Trashed', ['message' => 'Asset Category trashed.', 'name' => $locked->name]);

            return true;
        });

        if (! $deleted) {
            return back()->with('error', 'Cannot delete a category that has fixed assets or sub-categories.');
        }

        return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'asset-categories'])->with('success', 'Asset Category moved to trash.');
    }
    ```
  - **Before - `toggleStatus()` (`AssetCategoryController.php:115-134`):**
    ```php
    public function toggleStatus(Request $request, AssetCategory $assetCategory)
    {
        Gate::authorize('tenant.accounting.asset-category.update');

        $request->validate(['is_active' => 'required|boolean']);

        try {
            \Illuminate\Support\Facades\DB::transaction(function () use ($assetCategory, $request) {
                $assetCategory->is_active = $request->boolean('is_active');
                $assetCategory->save();
            });

            activityLog($assetCategory, 'Toggled', ['message' => 'Asset Category status toggled.', 'name' => $assetCategory->name, 'active' => $assetCategory->is_active]);

            return response()->json(['success' => true, 'is_active' => $assetCategory->is_active, 'message' => 'Status updated.']);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('AssetCategory toggleStatus failed: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Failed to update status.'], 500);
        }
    }
    ```
  - **After - `toggleStatus()`:**
    ```php
    public function toggleStatus(Request $request, AssetCategory $assetCategory): \Illuminate\Http\JsonResponse
    {
        Gate::authorize('tenant.accounting.asset-category.update');

        $request->validate(['is_active' => 'required|boolean']);

        \Illuminate\Support\Facades\DB::transaction(function () use ($assetCategory, $request) {
            $assetCategory->is_active = $request->boolean('is_active');
            $assetCategory->save();

            activityLog($assetCategory, 'Toggled', ['message' => 'Asset Category status toggled.', 'name' => $assetCategory->name, 'active' => $assetCategory->is_active]);
        });

        return response()->json(['success' => true, 'is_active' => $assetCategory->is_active, 'message' => 'Status updated.']);
    }
    ```
  - **Before - `restore()` (`AssetCategoryController.php:145-164`):**
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.asset-category.restore');

        try {
            $model = \Illuminate\Support\Facades\DB::transaction(function () use ($id) {
                $model = AssetCategory::onlyTrashed()->findOrFail($id);
                $model->restore();
                $model->update(['is_active' => true]);
                return $model;
            });

            activityLog($model, 'Restored', ['message' => 'Asset Category restored.', 'name' => $model->name]);

            return redirect()->route('accounting.asset-category.trashed')->with('success', 'Asset Category restored successfully.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('AssetCategory restore failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to restore Asset Category: ' . $e->getMessage());
        }
    }
    ```
  - **After - `restore()`:**
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.asset-category.restore');

        \Illuminate\Support\Facades\DB::transaction(function () use ($id) {
            $model = AssetCategory::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', ['message' => 'Asset Category restored.', 'name' => $model->name]);
        });

        return redirect()->route('accounting.asset-category.trashed')->with('success', 'Asset Category restored successfully.');
    }
    ```
  - **Before - `forceDelete()` (`AssetCategoryController.php:166-182`):**
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.asset-category.forceDelete');

        try {
            \Illuminate\Support\Facades\DB::transaction(function () use ($id) {
                $model = AssetCategory::withTrashed()->findOrFail($id);
                $model->forceDelete();
                activityLog($model, 'Deleted', ['message' => 'Asset Category permanently deleted.', 'name' => $model->name]);
            });

            return redirect()->route('accounting.asset-category.trashed')->with('success', 'Asset Category permanently deleted.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('AssetCategory forceDelete failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to permanently delete Asset Category: ' . $e->getMessage());
        }
    }
    ```
  - **After - `forceDelete()`:**
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.asset-category.forceDelete');

        \Illuminate\Support\Facades\DB::transaction(function () use ($id) {
            $model = AssetCategory::withTrashed()->findOrFail($id);
            $name = $model->name;
            $model->forceDelete();

            activityLog($model, 'Deleted', ['message' => 'Asset Category permanently deleted.', 'name' => $name]);
        });

        return redirect()->route('accounting.asset-category.trashed')->with('success', 'Asset Category permanently deleted.');
    }
    ```
  - **Verify:** `php -l Modules/Accounting/app/Http/Controllers/AssetCategoryController.php`; `Select-String -Path Modules/Accounting/app/Http/Controllers/AssetCategoryController.php -Pattern 'getMessage|catch \(\\Throwable'`
  - **Expect:** no syntax errors; no `getMessage` and no `catch (\Throwable` in the controller; the six `activityLog()` calls are inside `DB::transaction()` closures.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None. No fix in this plan arms a latent defect; the only cross-file changes are the two explicitly ticketed shared-route decisions.

## 3. Errors & transactions (F1/F2)

Covered by **ASCA-01** - see section 1. It removes the raw exception messages, moves every log inside its transaction, resolves the trashed row before the transaction, and adds the `lockForUpdate()` guard to `destroy()`.

## 4. Authorization (F3)

- [ ] **ASCA-08** - L - AUTH-04 - `AssetCategoryController.php:34,75` - the FormRequest already authorizes the same permission; drop the duplicate `Gate::authorize` in `store()` and `update()`.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AssetCategoryController.php`
  - **Before (`AssetCategoryController.php:34` and `:75`):**
    ```php
        Gate::authorize('tenant.accounting.asset-category.create');
    ```
    ```php
        Gate::authorize('tenant.accounting.asset-category.update');
    ```
  - **After:** delete the line in `store()` and the line in `update()` **only**. Do NOT delete `Gate::authorize('tenant.accounting.asset-category.create')` in `create()` or `'tenant.accounting.asset-category.update'` in `edit()`/`toggleStatus()` - those methods have no FormRequest.
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/AssetCategoryController.php -Pattern 'Gate::authorize'`
  - **Expect:** 9 remaining lines: `index`, `create`, `show`, `edit`, `destroy`, `toggleStatus`, `trashed`, `restore`, `forceDelete`. No `store`/`update` duplicate.
  - **Effort:** S

- [ ] **ASCA-07** - M - DECISION - AUTH-05 - `AccountingServiceProvider.php:148` registers `AssetCategoryPolicy`, but the controller never consults it.
  - **Why it is a decision:** the policy is correct but unused. Deleting it touches the shared provider; making it live means changing every check and adding `restore`/`forceDelete` methods, which overlaps ASCA-09.
  - (a) Delete `Modules/Accounting/app/Policies/AssetCategoryPolicy.php` and the `Gate::policy(AssetCategory::class, AssetCategoryPolicy::class);` line in `AccountingServiceProvider.php:148` - no behavior change, removes dead code.
  - (b) Make it live: add `restore`/`forceDelete`, switch controller checks to `$this->authorize(...)` model abilities, and switch the FormRequest/views consistently. Larger change; overlaps ASCA-09.
  - (c) Leave it registered but unused; record as accepted debt.
  - **Choice:** ____

- [ ] **ASCA-09** - M - DECISION - AUTH-06 - permission strings are repeated as literals in the controller, request and views.
  - **Why it is a decision:** the literals also appear in `_asset-categories.blade.php`, which is owned by the AccDashboard report, so a project-wide constants refactor must be coordinated.
  - (a) Add `Modules/Accounting/app/Support/AssetCategoryPermissions.php` with one constant per action and use it in `AssetCategoryController` + `AssetCategoryRequest`; leave the shared partial to the AccDashboard report.
  - (b) Defer the whole refactor to a module-wide permission pass.
  - (c) Leave as is.
  - **Choice:** ____

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **ASCA-06** - H - VAL-03 - `AssetCategoryRequest.php:56` - an omitted checkbox must become `false`, not `true`.
  - **Touches:** `Modules/Accounting/app/Http/Requests/AssetCategoryRequest.php`
  - **Before:**
    ```php
            'is_active'                      => $this->boolean('is_active', true),
    ```
  - **After:**
    ```php
            'is_active'                      => $this->boolean('is_active'),
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Requests/AssetCategoryRequest.php -Pattern "boolean\('is_active'"`; create via the modal with Active unchecked.
  - **Expect:** the request value is `false`; the new category stores `is_active = 0`.
  - **Effort:** S

- [ ] **ASCA-13** - M - VAL-07 - `AssetCategoryRequest.php:27` + `AssetCategoryController.php:64-67` - reject a parent that is the category itself or one of its descendants.
  - **Touches:** `Modules/Accounting/app/Http/Requests/AssetCategoryRequest.php`
  - **Before - imports:**
    ```php
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Validation\Rule;
    ```
  - **After - imports:**
    ```php
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;
use Modules\Accounting\Models\AssetCategory;
    ```
  - **Before - end of `prepareForValidation()`:**
    ```php
        ]);
    }
}
    ```
  - **After - end of `prepareForValidation()` plus the new `after()`:**
    ```php
        ]);
    }

    public function after(): array
    {
        return [
            function (Validator $validator): void {
                $id = $this->route('asset_category')?->id;
                $parentId = $this->input('parent_id');

                if (! $id || ! $parentId) {
                    return;
                }

                $ancestorId = (int) $parentId;
                $visited = [];

                while ($ancestorId > 0 && ! isset($visited[$ancestorId])) {
                    if ($ancestorId === (int) $id) {
                        $validator->errors()->add('parent_id', 'The selected parent category would create a loop.');

                        return;
                    }

                    $visited[$ancestorId] = true;
                    $ancestorId = (int) AssetCategory::withTrashed()->whereKey($ancestorId)->value('parent_id');
                }
            },
        ];
    }
}
    ```
  - **Verify:** `php -l Modules/Accounting/app/Http/Requests/AssetCategoryRequest.php`; edit `A` and choose its child `B` as parent; then choose `A` itself.
  - **Expect:** both attempts return a `parent_id` validation error; a valid unrelated parent still saves.
  - **Effort:** M

- [ ] **ASCA-17** - L - DECISION - CTL-10 - the list view is dead and the standalone `/create` page duplicates the modal.
  - **Why it is a decision:** removing the create route changes a reachable URL, `web.php` is shared, and `AssetCategoryCrudTest.php:47` calls `accounting.asset-category.create`, so the test must change too.
  - (a) Delete `resources/views/asset-category/index.blade.php`; retire the standalone create path (remove `create()` + `asset-category/create.blade.php` + the `create` route in `web.php`) and keep the modal. ⚠ SHARED route file.
  - (b) Delete only the dead `index.blade.php`; keep `/create` and link it from the tab.
  - (c) Leave both.
  - **Choice:** ____

- [ ] **ASCA-18** - L - CTL-10 - `AssetCategory.php:8,14` - remove the duplicate `SoftDeletes` trait; the parent already applies it.
  - **Touches:** `Modules/Accounting/app/Models/AssetCategory.php`
  - **Before - imports (`AssetCategory.php:7-10`):**
    ```php
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
    ```
  - **After - imports:**
    ```php
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
    ```
  - **Before - class head:**
    ```php
class AssetCategory extends BaseAccountingModel
{
    use SoftDeletes;

    protected $table = 'acc_asset_categories';
    ```
  - **After - class head:**
    ```php
class AssetCategory extends BaseAccountingModel
{
    protected $table = 'acc_asset_categories';
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Models/AssetCategory.php -Pattern 'SoftDeletes|App\\Models\\BaseModel'`
  - **Expect:** no matches; soft deletes still come from `BaseAccountingModel`.
  - **Effort:** S

- [ ] **ASCA-04** - H - DECISION - RTE-01 - `web.php:262` restores a trashed category over `GET`.
  - **Why it is a decision:** it changes the HTTP verb of a reachable URL; bookmarks/links using GET will stop working and the route file is shared. The shared `action-trashed` component already adapts the form to the route's method.
  - (a) Change `Route::get('/asset-category/{id}/restore', ...)` to `Route::post(...)`; keep the controller signature. The component renders `POST` + `@csrf` automatically. ⚠ SHARED route file.
  - (b) Keep GET and accept the state-change risk.
  - (c) Add a POST route and keep GET for backward compatibility (two routes; not recommended).
  - **Choice:** ____

## 6. Queries & performance (F9)

- [ ] **ASCA-10** - M - QRY-02 - `AssetCategoryController.php:140` - use the house page size and a distinct page name.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AssetCategoryController.php`
  - **Before:**
    ```php
        $categories = AssetCategory::onlyTrashed()->orderBy('name')->paginate(15);
    ```
  - **After:**
    ```php
        $categories = AssetCategory::onlyTrashed()->orderBy('name')->paginate(10, ['*'], 'ac_trash_page')->withQueryString();
    ```
  - **Verify:** open `/accounting/asset-category/trash/view`; inspect the pagination links.
  - **Expect:** 10 rows per page; links use `ac_trash_page`; filters survive page changes.
  - **Effort:** S

- [ ] **ASCA-11** - M - QRY-03 - `AssetCategoryController.php:26-27,64-68` - select only the columns the dropdowns use.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AssetCategoryController.php`
  - **Before - `create()`:**
    ```php
        $parentAssetCategories = AssetCategory::active()->orderBy('name')->get();
        $fixedAssetLedgers     = \Modules\Accounting\Models\Ledger::where('is_active', true)->orderBy('name')->get();
    ```
  - **After - `create()`:**
    ```php
        $parentAssetCategories = AssetCategory::active()->orderBy('name')->get(['id', 'name', 'code']);
        $fixedAssetLedgers     = \Modules\Accounting\Models\Ledger::where('is_active', true)->orderBy('name')->get(['id', 'name']);
    ```
  - **Before - `edit()`:**
    ```php
        $parentAssetCategories = AssetCategory::active()
            ->where('id', '!=', $assetCategory->id)
            ->orderBy('name')
            ->get();
        $fixedAssetLedgers = \Modules\Accounting\Models\Ledger::where('is_active', true)->orderBy('name')->get();
    ```
  - **After - `edit()`:**
    ```php
        $parentAssetCategories = AssetCategory::active()
            ->where('id', '!=', $assetCategory->id)
            ->orderBy('name')
            ->get(['id', 'name', 'code']);
        $fixedAssetLedgers = \Modules\Accounting\Models\Ledger::where('is_active', true)->orderBy('name')->get(['id', 'name']);
    ```
  - **Verify:** open `/accounting/asset-category/create` and `/{id}/edit`; inspect the parent and ledger `<select>` options.
  - **Expect:** same option labels/values; no missing `code` in the parent label.
  - **Effort:** S

- [ ] **ASCA-12** - M - QRY-04 - `AssetCategory.php:106` - use `exists()` instead of two `count()` queries.
  - **Touches:** `Modules/Accounting/app/Models/AssetCategory.php`
  - **Before:**
    ```php
        return $this->fixedAssets()->count() === 0 && $this->children()->count() === 0;
    ```
  - **After:**
    ```php
        return ! $this->fixedAssets()->exists() && ! $this->children()->exists();
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Models/AssetCategory.php -Pattern 'isDeletable|exists\(\)'`
  - **Expect:** `exists()` twice, no `count()` in `isDeletable()`.
  - **Effort:** S

## 7. Views (F10)

No view item of its own. The dead `index.blade.php` and the duplicate create page are covered by the **ASCA-17** decision.

## 8. Style (F12) - one item per file

- [ ] **ASCA-16** - L - CTL-04 - add return types to the four read methods. `ASCA-01` already types `store`, `update`, `destroy`, `toggleStatus`, `restore`, `forceDelete`.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AssetCategoryController.php`
  - **Before:**
    ```php
    public function index()
    ```
    ```php
    public function create()
    ```
    ```php
    public function show(AssetCategory $assetCategory)
    ```
    ```php
    public function edit(AssetCategory $assetCategory)
    ```
  - **After:**
    ```php
    public function index(): \Illuminate\Http\RedirectResponse
    ```
    ```php
    public function create(): \Illuminate\View\View
    ```
    ```php
    public function show(AssetCategory $assetCategory): \Illuminate\View\View
    ```
    ```php
    public function edit(AssetCategory $assetCategory): \Illuminate\View\View
    ```
  - **Verify:** `Select-String -Path Modules/Accounting/app/Http/Controllers/AssetCategoryController.php -Pattern 'public function'`
  - **Expect:** all 11 public methods have a return type.
  - **Effort:** S

- [ ] **ASCA-20** - L - STY-02 - run Pint on the three in-scope PHP files after the functional items.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AssetCategoryController.php`, `Modules/Accounting/app/Http/Requests/AssetCategoryRequest.php`, `Modules/Accounting/app/Models/AssetCategory.php`
  - **Before:** `pint --test` reports `fail` for all three; see the JSON in report ASCA-20.
  - **After:** the same command exits 0.
  - **Verify:** `vendor\bin\pint.bat --test Modules/Accounting/app/Http/Controllers/AssetCategoryController.php Modules/Accounting/app/Http/Requests/AssetCategoryRequest.php Modules/Accounting/app/Models/AssetCategory.php`
  - **Expect:** `pass` for all three files.
  - **Effort:** S

## 9. Deferred / decisions

The four decisions are recorded inline: **ASCA-04** and **ASCA-17** in section 5, **ASCA-07** and **ASCA-09** in section 4. No other decision is deferred; two findings have no plan item (section 10).

| ID | Decision | Default if unchosen |
|---|---|---|
| ASCA-04 | POST restore vs keep GET | Keep GET (current risk) |
| ASCA-07 | Delete dead policy vs make it live | Leave registered |
| ASCA-09 | Permission constants vs module-wide pass | Leave literals |
| ASCA-17 | Retire standalone create vs keep both | Keep both |

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| ASCA-15 | `restore()`/`forceDelete()` use `{id}` + `findOrFail()`. The current lookup is correct; binding a trashed model needs `->withTrashed()` in the shared route file and buys nothing user-visible. Accepted as debt. |
| ASCA-19 | `depreciation_method` is a DB enum consumed as a plain string. Casting it needs a new PHP enum class and a behaviour review; no user-visible defect today. Deferred to the enum/typed-model pass. |
