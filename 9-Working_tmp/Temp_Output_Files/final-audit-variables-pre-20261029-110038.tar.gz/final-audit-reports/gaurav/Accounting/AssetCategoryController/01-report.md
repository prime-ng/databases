# Final Audit - AssetCategoryController

**Module:** Accounting  
**Class:** `Modules\Accounting\app\Http\Controllers\AssetCategoryController.php`  
**ABBR:** ASCA  
**Auditor:** gaurav (final audit agent)  
**Date:** 2026-10-23  
**Mode:** read-only

## 0. The screen in plain words

| | |
|---|---|
| **URL(s)** | `GET /accounting/asset-category` (redirects to `accounting.menu.assetsIntegration`), `GET /accounting/asset-category/create`, `GET /accounting/asset-category/{asset_category}`, `GET /accounting/asset-category/{asset_category}/edit`, `GET /accounting/asset-category/trash/view`; write routes `POST`, `PUT/PATCH`, `DELETE /{asset_category}`, `POST /{asset_category}/toggle-status`, `DELETE /{id}/force-delete`, `GET /{id}/restore` |
| **Menu path** | Accounting -> Assets & Integration -> Asset Categories tab |
| **Who uses it** | Roles with `tenant.accounting.asset-category.viewAny` (measured: Account Manager, Account Staff, Management, School Admin, Super Admin) |
| **What a user does** | Create and edit asset categories (code, name, parent, depreciation method/rate/life, posting ledgers, active flag) in the Assets & Integration modal; view a category; toggle active from the list; move to trash; restore; permanently delete trashed rows. |
| **Tables it writes** | `acc_asset_categories`, `sys_activity_logs` |
| **Tables it reads** | `acc_asset_categories`, `acc_ledgers`, `acc_fixed_assets`, `sys_users` |
| **Live data** | 14 asset categories (0 trashed), 5 fixed assets |
| **Permissions** | `config/permissionslist.php:601` defines `accounting.asset-category => $crud`; the tenant seeder adds the `tenant.` prefix. The tenant DB has exactly 7 permissions, all granted to 5 roles. |
| **Route surface** | 11 routes; all tenant-scoped (`web`, `InitializeTenancyByDomain`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Accounting`, `Authenticate`, `EnsureEmailIsVerified`). |

## 1. Verdict

**NOT PRODUCTION-READY.**

The CRUD works on the happy path, but every write path is wrapped in `try/catch (\Throwable)` and five of the six mutators put raw exception text in front of the user. `restore` changes state over `GET`. The `is_active` checkbox cannot be unset because the FormRequest forces an omitted value to `true`. A category can be made its own ancestor because no cycle check exists. Fixes are local to one controller, one FormRequest, one model and four decisions; no migration is required.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 3 | 10 | 7 | 4 | 21 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | ASCA-01, ASCA-02, ASCA-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | ASCA-05, ASCA-14 | F9 Queries/Perf | ASCA-10, ASCA-11, ASCA-12 |
| F3 Authorization | ASCA-07, ASCA-08, ASCA-09 | F10 Views | clean |
| F4 Validation | ASCA-06, ASCA-13 | F11 Security/Tenancy | clean |
| F5 Routes | ASCA-04 | F12 Style | ASCA-20 |
| F6 Controller shape | ASCA-15, ASCA-16, ASCA-17 | F13 Deep read | ASCA-21 |
| F7 Models | ASCA-18, ASCA-19 | | |

DECISION: ASCA-04, ASCA-07, ASCA-09, ASCA-17.

**Worst finding:** ASCA-01 - five write methods return the raw `$e->getMessage()` to the browser, exposing SQL, tenant, path and class details. It is fixed by one controller rewrite.

## 3. Scope - every file this controller uses

Read in full (target) or checked (linked):

| Class / file | Lines | Why it is in scope |
|---|---:|---|
| `Modules\Accounting\app\Http\Controllers\AssetCategoryController.php` | 183 | Audit target; all 11 public methods |
| `Modules\Accounting\app\Http\Requests\AssetCategoryRequest.php` | 65 | Validation, authorization, parent/active coercion |
| `Modules\Accounting\app\Models\AssetCategory.php` | 108 | Relationships, scopes, casts, `isDeletable()` |
| `Modules\Accounting\app\Policies\AssetCategoryPolicy.php` | 36 | Registered policy; checked for actual use |
| `Modules\Accounting\app\Models\Ledger.php` | - | Linked report: `LedgerController`; only fields read by AssetCategory |
| `Modules\Accounting\app\Models\FixedAsset.php` | - | Linked report: `FixedAssetController`; FK `asset_category_id` |
| `Modules\Accounting\app\Models\BaseAccountingModel.php` | - | Linked report: `AccountingStatusMasterController`; supplies `SoftDeletes` |
| `Modules\Accounting\Services\AccountingContext.php` | - | Linked report: `AccountGroupController`; tenant/campus context |
| `Modules\Accounting\routes\web.php` | 261-265 | Asset-category routes |
| `Modules\Accounting\app\Providers\AccountingServiceProvider.php` | 148 | Policy registration |
| `Modules\Accounting\resources\views\asset-category/*.blade.php` | - | create/edit/show/trash/index views |
| `Modules\Accounting\resources\views\pages\partials\assets-integration\_asset-categories.blade.php` | - | Real list/modal UI; owned by AccDashboard report |
| `Modules\Accounting\app\Http\Controllers\AccDashboardController.php` | 1171-1187 | Real list query; cross-cutting note |
| `database/migrations/tenant/2026_09_16_100017_create_acc_asset_categories_table.php` | - | Schema, unique code, FKs, soft deletes |
| `database/migrations/tenant/2026_09_16_100049_create_acc_fixed_assets_table.php` | 70 | FK `asset_category_id` restrictOnDelete |
| `config/permissionslist.php` | 601 | Permission definition |
| `app/Helpers/activityLog.php` | - | Audit helper used by every mutator |

Skipped: `vendor/`, `node_modules/`, `public/`, `storage/`, framework files, generated caches. Tests were not run (D4).

## 4. Routes

Probe:

```text
PS> php artisan route:list --path=asset-category --json
GET|HEAD accounting/asset-category -> accounting.asset-category.index
POST accounting/asset-category -> accounting.asset-category.store
GET|HEAD accounting/asset-category/create -> accounting.asset-category.create
GET|HEAD accounting/asset-category/trash/view -> accounting.asset-category.trashed
GET|HEAD accounting/asset-category/{asset_category} -> accounting.asset-category.show
PUT|PATCH accounting/asset-category/{asset_category} -> accounting.asset-category.update
DELETE accounting/asset-category/{asset_category} -> accounting.asset-category.destroy
GET|HEAD accounting/asset-category/{asset_category}/edit -> accounting.asset-category.edit
POST accounting/asset-category/{asset_category}/toggle-status -> accounting.asset-category.toggleStatus
DELETE accounting/asset-category/{id}/force-delete -> accounting.asset-category.forceDelete
GET|HEAD accounting/asset-category/{id}/restore -> accounting.asset-category.restore
```

The middleware column is trimmed above for readability. All 11 routes carry the same stack, in order: `web`, `Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains`, `Stancl\Tenancy\Middleware\InitializeTenancyByDomain`, `App\Http\Middleware\EnsureTenantIsActive`, `App\Http\Middleware\EnsureTenantHasModule:Accounting`, `Illuminate\Auth\Middleware\Authenticate`, `Illuminate\Auth\Middleware\EnsureEmailIsVerified`. The `toggle-status` route is registered after the resource route and does not conflict.

`restore` is a `GET` that writes state (ASCA-04). The route file is shared: any change is a shared-file edit.

## 5. Per-method table

`Tx` = the method opens `DB::transaction()`; `activityLog` is the event passed to the helper. "Writes" counts the tables the method is expected to touch.

| Method | Line | Routed (verb uri) | Gate | Tx | activityLog | Writes | Findings |
|---|---:|---|---|---|---|---|---|
| `index` | 15 | `GET accounting/asset-category` | `tenant.accounting.asset-category.viewAny` | - | - | - | ASCA-17 |
| `create` | 22 | `GET accounting/asset-category/create` | `tenant.accounting.asset-category.create` | - | - | - | ASCA-11, ASCA-17 |
| `store` | 32 | `POST accounting/asset-category` | `tenant.accounting.asset-category.create` + FormRequest | insert only | `Created` (outside) | `acc_asset_categories`, `sys_activity_logs` | ASCA-01, ASCA-03, ASCA-05, ASCA-06 |
| `show` | 53 | `GET accounting/asset-category/{asset_category}` | `tenant.accounting.asset-category.view` | - | - | - | - |
| `edit` | 60 | `GET accounting/asset-category/{asset_category}/edit` | `tenant.accounting.asset-category.update` | - | - | - | ASCA-11 |
| `update` | 73 | `PUT/PATCH accounting/asset-category/{asset_category}` | `tenant.accounting.asset-category.update` + FormRequest | update only | `Updated` (outside) | `acc_asset_categories`, `sys_activity_logs` | ASCA-01, ASCA-03, ASCA-05, ASCA-06, ASCA-13 |
| `destroy` | 91 | `DELETE accounting/asset-category/{asset_category}` | `tenant.accounting.asset-category.delete` | update + soft delete | `Trashed` (outside) | `acc_asset_categories`, `sys_activity_logs` | ASCA-01, ASCA-03, ASCA-05, ASCA-14, ASCA-21 |
| `toggleStatus` | 115 | `POST accounting/asset-category/{asset_category}/toggle-status` | `tenant.accounting.asset-category.update` | update only | `Toggled` (outside) | `acc_asset_categories`, `sys_activity_logs` | ASCA-01, ASCA-03, ASCA-05 |
| `trashed` | 136 | `GET accounting/asset-category/trash/view` | `tenant.accounting.asset-category.restore` | - | - | - | ASCA-10 |
| `restore` | 145 | `GET accounting/asset-category/{id}/restore` | `tenant.accounting.asset-category.restore` | restore + update | `Restored` (outside) | `acc_asset_categories`, `sys_activity_logs` | ASCA-01, ASCA-02, ASCA-03, ASCA-05 |
| `forceDelete` | 166 | `DELETE accounting/asset-category/{id}/force-delete` | `tenant.accounting.asset-category.forceDelete` | hard delete | `Deleted` (inside) | `acc_asset_categories`, `sys_activity_logs` | ASCA-01, ASCA-02, ASCA-03 |

## 6. Findings

### F1 - Errors & transactions (ERR)

**ASCA-01 - BLOCKER - ERR-01: raw exception text is returned to the browser on five write paths.**

- **Location:** `AssetCategoryController.php:47-49, 85-87, 109-111, 160-162, 178-180`. `toggleStatus` at `130-132` returns generic JSON but still logs only the message.
- **Finding:** `store`, `update`, `destroy`, `restore` and `forceDelete` catch `\Throwable` and put `$e->getMessage()` into a user-visible redirect. The messages can contain SQL fragments, table/tenant names, file paths and class names.
- **Root cause:** every mutator wraps its work in `try/catch` and treats the exception message as a user-facing string.
- **Consequence:** information disclosure and a poor retry experience; a failed audit-log write is reported as a failed data write even when the data committed (see ASCA-05).
- **Evidence:**

```php
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('AssetCategory create failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to create Asset Category: ' . $e->getMessage())->withInput();
        }
```

```text
PS> Select-String -Path ... -Pattern 'getMessage|catch'
47:} catch (\Throwable $e) {
48:\Illuminate\Support\Facades\Log::error('AssetCategory create failed: ' . $e->getMessage());
49:return back()->with('error', 'Failed to create Asset Category: ' . $e->getMessage())->withInput();
85:} catch (\Throwable $e) {
86:\Illuminate\Support\Facades\Log::error('AssetCategory update failed: ' . $e->getMessage());
87:return back()->with('error', 'Failed to update Asset Category: ' . $e->getMessage())->withInput();
109:} catch (\Throwable $e) {
110:\Illuminate\Support\Facades\Log::error('AssetCategory destroy failed: ' . $e->getMessage());
111:return back()->with('error', 'Failed to delete Asset Category: ' . $e->getMessage());
130:} catch (\Throwable $e) {
131:\Illuminate\Support\Facades\Log::error('AssetCategory toggleStatus failed: ' . $e->getMessage());
160:} catch (\Throwable $e) {
161:\Illuminate\Support\Facades\Log::error('AssetCategory restore failed: ' . $e->getMessage());
162:return back()->with('error', 'Failed to restore Asset Category: ' . $e->getMessage());
178:} catch (\Throwable $e) {
179:\Illuminate\Support\Facades\Log::error('AssetCategory forceDelete failed: ' . $e->getMessage());
180:return back()->with('error', 'Failed to permanently delete Asset Category: ' . $e->getMessage());
```

- **Fix direction:** delete every `try/catch`; let Laravel render the 500; if the team wants server logs, log `['exception' => $e]`, never the raw message in the response. Apply ASCA-01 in the plan.

**ASCA-02 - HIGH - ERR-02: `findOrFail()` sits inside the `try` block in `restore()` and `forceDelete()`.**

- **Location:** `AssetCategoryController.php:149-152, 170-173`.
- **Finding:** a missing trashed id throws `ModelNotFoundException` inside the `try`; the catch turns a 404 into a redirect (or a 500) and leaks the model/query text.
- **Root cause:** the lookup is part of the wrapped transaction instead of a precondition.
- **Consequence:** stale trash links and double-clicks produce a confusing "No query results for model ..." message instead of a clean 404.
- **Evidence:**

```php
        try {
            $model = \Illuminate\Support\Facades\DB::transaction(function () use ($id) {
                $model = AssetCategory::onlyTrashed()->findOrFail($id);
```

```php
        try {
            \Illuminate\Support\Facades\DB::transaction(function () use ($id) {
                $model = AssetCategory::withTrashed()->findOrFail($id);
```

- **Fix direction:** resolve the model before the transaction/catch and use `onlyTrashed()` / `withTrashed()` explicitly. Apply ASCA-01.

**ASCA-03 - MEDIUM - ERR-05: the server log records only `$e->getMessage()`.**

- **Location:** `AssetCategoryController.php:48, 86, 110, 131, 161, 179`.
- **Finding:** the six log calls lose the exception object, stack trace and request context.
- **Root cause:** `Log::error('...' . $e->getMessage())` instead of Laravel's exception reporter.
- **Consequence:** an operator cannot tell which tenant, row or query failed.
- **Evidence:**

```php
            \Illuminate\Support\Facades\Log::error('AssetCategory update failed: ' . $e->getMessage());
```

- **Fix direction:** remove the catch blocks. If a log is still needed, use `report($e)` or `Log::error('message', ['exception' => $e])`. Apply ASCA-01.

### F2 - Transactions (TXN)

**ASCA-05 - MEDIUM - TXN-04: the audit log is written outside the transaction in five mutators.**

- **Location:** `store` line 44, `update` line 82, `destroy` line 106, `toggleStatus` line 127, `restore` line 157. `forceDelete` line 174 is already inside.
- **Finding:** the data write commits, then `activityLog()` runs. If the log write fails, the catch reports the whole operation as failed although the data committed.
- **Root cause:** `activityLog()` calls were placed after `DB::transaction()` instead of inside the closure.
- **Consequence:** a user retries a create that already succeeded (duplicate code) or a delete that already happened (404); the audit trail can also be missing for a successful write.
- **Evidence:**

```text
PS> Select-String -Path ... -Pattern 'activityLog|findOrFail'
44:activityLog($category, 'Created', ['message' => 'Asset Category created.', 'name' => $category->name]);
82:activityLog($assetCategory, 'Updated', ['message' => 'Asset Category updated.', 'name' => $assetCategory->name]);
106:activityLog($assetCategory, 'Trashed', ['message' => 'Asset Category trashed.', 'name' => $assetCategory->name]);
127:activityLog($assetCategory, 'Toggled', ['message' => 'Asset Category status toggled.', 'name' => $assetCategory->name, 'active' => $assetCategory->is_active]);
157:activityLog($model, 'Restored', ['message' => 'Asset Category restored.', 'name' => $model->name]);
174:activityLog($model, 'Deleted', ['message' => 'Asset Category permanently deleted.', 'name' => $model->name]);
```

- **Fix direction:** move each `activityLog()` inside its `DB::transaction()` closure. Apply ASCA-01.

**ASCA-14 - MEDIUM - TXN-06: `destroy()` checks `isDeletable()` outside the transaction (check-then-act).**

- **Location:** `AssetCategoryController.php:95-100`.
- **Finding:** the "has fixed assets or children" check runs before the transaction; a fixed asset or child can be inserted between the check and the soft delete.
- **Root cause:** no row lock around the parent category.
- **Consequence:** a category can be trashed while a fixed asset is being attached to it; the asset keeps a foreign key to a soft-deleted category and the default relation returns `null`, so the asset appears uncategorized. The race window is small but real.
- **Evidence:**

```php
        if (! $assetCategory->isDeletable()) {
            return back()->with('error', 'Cannot delete category with existing fixed assets.');
        }

        try {
            \Illuminate\Support\Facades\DB::transaction(function () use ($assetCategory) {
```

```text
PS> Select-String -Path ... -Pattern 'isDeletable'
95:if (! $assetCategory->isDeletable()) {
```

- **Fix direction:** re-check inside the transaction with `lockForUpdate()` on the category row. Apply ASCA-01 (the rewritten `destroy()` includes the lock).

### F3 - Authorization (AUTH)

**ASCA-07 - MEDIUM - AUTH-05: the registered `AssetCategoryPolicy` is never consulted.**

- **Location:** `AccountingServiceProvider.php:148`; all 11 controller checks use `Gate::authorize('tenant.accounting.asset-category.*')`.
- **Finding:** the policy exists and mirrors the permission names, but the controller calls string abilities, so the policy methods are dead code.
- **Root cause:** the controller was written against string abilities instead of model abilities.
- **Consequence:** the policy can drift from the controller and still look authoritative; developers may assume `delete()` policy logic is enforced.
- **Evidence:**

```php
        Gate::policy(AssetCategory::class, AssetCategoryPolicy::class);
```

```php
    public function update(AssetCategoryRequest $request, AssetCategory $assetCategory)
    {
        Gate::authorize('tenant.accounting.asset-category.update');
```

- **Fix direction:** decide in the plan - either delete the unused policy + registration, or route checks through it. Do not leave it half-live.

**ASCA-08 - LOW - AUTH-04: `store()` and `update()` authorize twice.**

- **Location:** `AssetCategoryController.php:34, 75`; `AssetCategoryRequest.php:17`.
- **Finding:** the FormRequest's `authorize()` already checks the same `create`/`update` permission via `authorizeByCrudPermission()`, then the controller checks it again.
- **Root cause:** copy-paste of the Gate call into methods that already receive a FormRequest.
- **Consequence:** two policy/Gate resolutions per write; if the two ever diverge, behavior depends on which one runs first.
- **Evidence:**

```php
        return $this->authorizeByCrudPermission('tenant.accounting.asset-category');
```

```php
        Gate::authorize('tenant.accounting.asset-category.create');
```

```php
        Gate::authorize('tenant.accounting.asset-category.update');
```

- **Fix direction:** delete the `Gate::authorize` lines from `store()` and `update()` only; keep the FormRequest authorization. Do not delete the checks in `create()`/`edit()`/`destroy()`/`toggleStatus()`/`trashed()`/`restore()`/`forceDelete()` - those have no FormRequest.

**ASCA-09 - MEDIUM - AUTH-06: permission strings are repeated literals.**

- **Location:** 11 literals in the controller; 1 base string in `AssetCategoryRequest`; 15 more in the asset-category views and the shared `_asset-categories.blade.php`.
- **Finding:** `tenant.accounting.asset-category.*` is written by hand in every check.
- **Root cause:** no constants/enum for the feature permissions.
- **Consequence:** renaming a permission or adding an action requires a cross-file search; a typo silently denies access.
- **Evidence:**

```text
PS> Select-String -Path ... -Pattern 'tenant\.accounting\.asset-category\.[A-Za-z]+'
AssetCategoryController.php:17:Gate::authorize('tenant.accounting.asset-category.viewAny');
AssetCategoryController.php:24:Gate::authorize('tenant.accounting.asset-category.create');
AssetCategoryController.php:34:Gate::authorize('tenant.accounting.asset-category.create');
AssetCategoryController.php:55:Gate::authorize('tenant.accounting.asset-category.view');
AssetCategoryController.php:62:Gate::authorize('tenant.accounting.asset-category.update');
AssetCategoryController.php:75:Gate::authorize('tenant.accounting.asset-category.update');
AssetCategoryController.php:93:Gate::authorize('tenant.accounting.asset-category.delete');
AssetCategoryController.php:117:Gate::authorize('tenant.accounting.asset-category.update');
AssetCategoryController.php:138:Gate::authorize('tenant.accounting.asset-category.restore');
AssetCategoryController.php:147:Gate::authorize('tenant.accounting.asset-category.restore');
AssetCategoryController.php:168:Gate::authorize('tenant.accounting.asset-category.forceDelete');
```

- **Fix direction:** decide in the plan - a small `AssetCategoryPermissions` constants class used in the controller + request, leaving the shared partial to the AccDashboard report; or defer to a module-wide pass.

### F4 - Validation (VAL)

**ASCA-06 - HIGH - VAL-03: an unchecked `is_active` becomes `true`.**

- **Location:** `AssetCategoryRequest.php:56`; create modal `_asset-categories.blade.php:278`.
- **Finding:** `prepareForValidation()` calls `$this->boolean('is_active', true)`. Browsers omit an unchecked checkbox, so the request invents `true` instead of `false`.
- **Root cause:** the default argument is `true`.
- **Consequence:** a user who unchecks Active while creating a category gets an active category. The same coercion applies on update.
- **Evidence:**

```php
            'is_active'                      => $this->boolean('is_active', true),
```

```blade
<input type="checkbox" name="is_active" id="asc_is_active" class="form-check-input" value="1" {{ old('is_active', true) ? 'checked' : '' }}>
```

- **Fix direction:** `'is_active' => $this->boolean('is_active')` (default false). The `required|boolean` rule then sees `false` and passes.

**ASCA-13 - MEDIUM - VAL-07: a category can be made its own descendant (parent cycle).**

- **Location:** `AssetCategoryRequest.php:27`; `AssetCategoryController.php:64-67`.
- **Finding:** `parent_id` is only `nullable|exists`. The edit dropdown excludes the current id but not its descendants, and no server-side `after()` check walks the ancestor chain.
- **Root cause:** self-exclusion was implemented in the view, not in validation.
- **Consequence:** `A.parent = B` while `B.parent = A` creates an endless hierarchy; any recursive traversal, delete guard or future tree render can loop.
- **Evidence:**

```php
            'parent_id'                      => 'nullable|exists:acc_asset_categories,id',
```

```php
        $parentAssetCategories = AssetCategory::active()
            ->where('id', '!=', $assetCategory->id)
            ->orderBy('name')
            ->get();
```

- **Fix direction:** add an `after()` validator that walks `parent_id` to the root with a visited set and rejects the current id. See plan ASCA-13.

### F5 - Routes (RTE)

**ASCA-04 - HIGH - RTE-01: `restore` changes state over `GET`.**

- **Location:** `Modules\Accounting\routes\web.php:262`.
- **Finding:** a GET request restores a trashed category. Any prefetch, link preview, crawler or bookmark can restore data.
- **Root cause:** the route uses `Route::get` for a write action.
- **Consequence:** unintended restores and CSRF-free state changes; GET is also cached by proxies.
- **Evidence:**

```php
Route::get('/asset-category/{id}/restore', [AssetCategoryController::class, 'restore'])->name('asset-category.restore');
```

```blade
    $restoreMethods = collect($restoreRoute?->methods() ?? ['GET'])->reject(fn ($method) => $method === 'HEAD')->values();
    $restoreMethod = strtoupper($restoreMethods->first() ?? 'GET');
```

```blade
    <form action="{{ route($restoreRouteName, $restoreParams) }}"
          method="{{ $restoreMethod === 'GET' ? 'GET' : 'POST' }}"
```

- **Fix direction:** change the route to `Route::post`; the shared `action-trashed` component reads the route's methods and automatically renders `POST` + `@csrf`. The controller signature does not change. This is a shared route file edit - see the decision in the plan.

### F6 - Controller structure (CTL)

**ASCA-15 - LOW - CTL-03: `restore()`/`forceDelete()` use `{id}` + `findOrFail()` instead of route-model binding.**

- **Location:** `AssetCategoryController.php:145, 166`; routes `web.php:262-263`.
- **Finding:** both methods take a raw `$id` and look the model up by hand.
- **Root cause:** the routes declare `{id}`, and a trashed model needs `withTrashed()` binding.
- **Consequence:** none user-visible; the current lookup is correct. A binding refactor is not worth a shared route change.
- **Evidence:**

```php
    public function restore($id): \Illuminate\Http\RedirectResponse
```

```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

- **Fix direction:** none in this pass - see report section 10. Accepted as debt.

**ASCA-16 - LOW - CTL-04: eight public methods have no return type.**

- **Location:** `index:15`, `create:22`, `store:32`, `show:53`, `edit:60`, `update:73`, `destroy:91`, `toggleStatus:115`. `trashed`, `restore`, `forceDelete` already declare types.
- **Finding:** the public surface is untyped while the rest of the accounting controllers return `View`/`RedirectResponse`/`JsonResponse`.
- **Root cause:** the controller was written without return types; three methods were later typed.
- **Consequence:** static analysis cannot verify the response contract; IDE support is weaker.
- **Evidence:**

```php
    public function index()
```

```php
    public function create()
```

```php
    public function show(AssetCategory $assetCategory)
```

```php
    public function edit(AssetCategory $assetCategory)
```

- **Fix direction:** add the response types. The four mutators get them in ASCA-01; this item covers `index`, `create`, `show`, `edit`.

**ASCA-17 - LOW - CTL-10: the list view is dead; the standalone create page duplicates the modal.**

- **Location:** `AssetCategoryController.php:15-20`; `resources/views/asset-category/index.blade.php`; `create` route + `create.blade.php`.
- **Finding:** `index()` redirects and no code renders `asset-category.index`; the route name survives only in the breadcrumb registry and feature tests, so `index.blade.php` is unreachable. The `/create` page is reachable but is a superseded, incomplete form (no parent or ledger fields) next to the live Assets & Integration modal.
- **Root cause:** the list moved to `AccDashboardController::assetsIntegration()` and the modal, but the old view/page were never removed.
- **Consequence:** dead code confuses maintainers; a user who reaches `/create` gets a form that cannot set the fields the modal sets. The feature tests also call the create route (`AssetCategoryCrudTest.php:47`), so retiring it needs a test update.
- **Evidence:**

```php
    public function index()
    {
        Gate::authorize('tenant.accounting.asset-category.viewAny');

        return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'asset-categories']);
    }
```

```text
PS> Get-ChildItem -Path "Modules\Accounting\resources\views","Modules\Accounting\app" -Recurse -File -Include *.php,*.blade.php |
    Select-String -Pattern "accounting::asset-category\.index|asset-category/index"
(no matches)
```

```text
PS> Select-String -Path "app\Services\Breadcrumbs\registry.php","Modules\Accounting\tests\Feature\AssetCategoryCrudTest.php" -Pattern "accounting\.asset-category\.index"
registry.php:350:'accounting.asset-category.index' => [
AssetCategoryCrudTest.php:21:$this->get(route('accounting.asset-category.index'))->assertRedirect();
AssetCategoryCrudTest.php:33:$response = $this->get(route('accounting.asset-category.index'));
```

- **Fix direction:** decide in the plan - delete the dead `index.blade.php` and either retire or link the standalone create page. Removing the create route is a shared route change.

### F7 - Models (MDL)

**ASCA-18 - LOW - CTL-10: `AssetCategory` re-declares `SoftDeletes` already provided by its parent.**

- **Location:** `AssetCategory.php:8, 14`; `BaseAccountingModel.php:14`.
- **Finding:** the model imports `SoftDeletes` and applies the trait again even though `BaseAccountingModel` already applies it.
- **Root cause:** the trait was copied into the child class.
- **Consequence:** redundant trait boot; the import is also flagged as unused by Pint once the duplicate is removed.
- **Evidence:**

```php
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
```

```php
class AssetCategory extends BaseAccountingModel
{
    use SoftDeletes;
```

```php
abstract class BaseAccountingModel extends BaseModel
{
    use SoftDeletes;
```

- **Fix direction:** remove the duplicate `use SoftDeletes;` and both unused imports (`App\Models\BaseModel`, `Illuminate\Database\Eloquent\SoftDeletes`). `BaseAccountingModel` keeps the behavior.

**ASCA-19 - MEDIUM - MDL-02: the `depreciation_method` enum has no cast.**

- **Location:** migration `2026_09_16_100017...:25`; `AssetCategory.php:32-36`.
- **Finding:** the column is a DB enum (`SLM`, `WDV`, `None`) but the model casts only the decimal, integer and boolean columns. The value is compared as a raw string in `isSLM()`/`isWDV()`/`isNone()`.
- **Root cause:** the enum was not added to `$casts`.
- **Consequence:** no type safety; a typo in a comparison is silent and any future enum change has no single source of truth.
- **Evidence:**

```php
$table->enum('depreciation_method', ['SLM', 'WDV', 'None'])->default('SLM')->comment('SLM(straight Line)-same amount each year, WDV(written-Down Value)-a percentage of the reducing balance)');
```

```php
    protected $casts = [
        'depreciation_rate' => 'decimal:4',
        'useful_life_years' => 'integer',
        'is_active'         => 'boolean',
    ];
```

- **Fix direction:** no fix in this pass - casting an enum needs a PHP enum class and a behavior review. See report section 10.

### F8 - Services, jobs, events

Clean. The controller dispatches no job, event, listener, mail or notification and injects no service; the only side effect is the `activityLog()` helper.

```text
PS> Select-String -Path ... -Pattern 'Service|Job|Event|Listener|dispatch|queue|Mail|Notification'
(no output)
```

### F9 - Queries (QRY)

**ASCA-10 - MEDIUM - QRY-02: the trash list paginates 15 rows with the default page name.**

- **Location:** `AssetCategoryController.php:140`.
- **Finding:** the house standard for these lists is 10 per page with a distinct page name; this uses `paginate(15)` and the default `page`.
- **Root cause:** copy-paste from an older controller.
- **Consequence:** inconsistent page size; the default `page` name can collide if a second paginator is added to the trash page.
- **Evidence:**

```php
        $categories = AssetCategory::onlyTrashed()->orderBy('name')->paginate(15);
```

- **Fix direction:** `paginate(10, ['*'], 'ac_trash_page')->withQueryString()`.

**ASCA-11 - MEDIUM - QRY-03: create/edit load full models for dropdowns.**

- **Location:** `AssetCategoryController.php:26-27, 64-68`.
- **Finding:** parent categories and ledgers are loaded with `get()` and all columns for `<select>` options. The edit parent select needs only `id`, `name`, `code`; the ledger selects need only `id`, `name`.
- **Root cause:** no column whitelist on the option queries.
- **Consequence:** each create/edit page hydrates every column of every active ledger/category; on a large chart of accounts this is unnecessary memory and transfer.
- **Evidence:**

```php
        $parentAssetCategories = AssetCategory::active()->orderBy('name')->get();
        $fixedAssetLedgers     = \Modules\Accounting\Models\Ledger::where('is_active', true)->orderBy('name')->get();
```

```php
        $parentAssetCategories = AssetCategory::active()
            ->where('id', '!=', $assetCategory->id)
            ->orderBy('name')
            ->get();
        $fixedAssetLedgers = \Modules\Accounting\Models\Ledger::where('is_active', true)->orderBy('name')->get();
```

- **Fix direction:** `get(['id', 'name', 'code'])` for parents (the edit view prints `code`; the create view does not render the parent select at all) and `get(['id', 'name'])` for ledgers (all three selects use only `id` and `name`).

**ASCA-12 - MEDIUM - QRY-04: `isDeletable()` runs two `COUNT(*)` queries instead of `exists()`.**

- **Location:** `AssetCategory.php:106`.
- **Finding:** both guards use `count() === 0`, so the database scans/counts every matching fixed asset and child even though one row is enough to answer.
- **Root cause:** `count()` was used as a boolean proxy.
- **Consequence:** unnecessary work on the delete path; worse as fixed assets grow.
- **Evidence:**

```php
        return $this->fixedAssets()->count() === 0 && $this->children()->count() === 0;
```

- **Fix direction:** `return ! $this->fixedAssets()->exists() && ! $this->children()->exists();`

### F10 - Views (VIEW)

Clean. The four asset-category blades contain no Eloquent/DB query, no raw SQL and no unescaped `{!! !!}` output. The only `count()` is a Collection count on an already-paginated result.

```text
PS> Select-String -Path "Modules\Accounting\resources\views\asset-category\*.blade.php" -Pattern "Model::|DB::|->get\(|->where\(|->count\(|::all\(|\{!!"
index.blade.php:13:@if($categories->count() > 0)
```

Note: the real list/modal is `pages/partials/assets-integration/_asset-categories.blade.php`, owned by the AccDashboard report. Its lazy loads are recorded in section 7, not as an ASCA finding.

### F11 - Concurrency (CON)

No unsafe transaction patterns beyond the ones in F1/F2. The six mutators use `DB::transaction()`; there is no `whereRaw`, `selectRaw`, `orderByRaw`, `havingRaw`, `DB::raw`, manual `beginTransaction`, or unlocked counter update.

```text
PS> Select-String -Path ... -Pattern 'DB::transaction|lockForUpdate|sharedLock|beginTransaction|commit\(|rollBack|whereRaw|selectRaw|orderByRaw|havingRaw|DB::raw'
AssetCategoryController.php:40:$category = \Illuminate\Support\Facades\DB::transaction(function () use ($validated) {
AssetCategoryController.php:78:\Illuminate\Support\Facades\DB::transaction(function () use ($assetCategory, $request) {
AssetCategoryController.php:100:\Illuminate\Support\Facades\DB::transaction(function () use ($assetCategory) {
AssetCategoryController.php:122:\Illuminate\Support\Facades\DB::transaction(function () use ($assetCategory, $request) {
AssetCategoryController.php:150:$model = \Illuminate\Support\Facades\DB::transaction(function () use ($id) {
AssetCategoryController.php:171:\Illuminate\Support\Facades\DB::transaction(function () use ($id) {
```

### F12 - Style (STY)

**ASCA-20 - LOW - STY-02: Pint fails on all three in-scope PHP files.**

- **Location:** controller, FormRequest, model.
- **Finding:** `pint --test` reports `fail` with style fixers in each file.
- **Root cause:** the files were not run through the project formatter.
- **Consequence:** CI/style gates fail; style diffs mix with functional diffs.
- **Evidence:**

```text
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\AssetCategoryController.php","fixers":["fully_qualified_strict_types","concat_space","unary_operator_spaces","not_operator_with_successor_space","blank_line_before_statement","ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Http\\Requests\\AssetCategoryRequest.php","fixers":["ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Models\\AssetCategory.php","fixers":["fully_qualified_strict_types","no_unused_imports","ordered_imports","binary_operator_spaces"]}]}
```

- **Fix direction:** apply the functional items first, then run Pint on exactly these three files.

### F13 - Deep read of every mutating method

Read each method top to bottom. Questions:

- **Q1** correct business rules?
- **Q2** safe on live data?
- **Q3** existing helper reused?
- **Q4** validation matches DB?
- **Q5** writes atomic?
- **Q6** authorization on the right permission?
- **Q7** side effects logged, messages truthful?
- **Q8** right abstraction (controller vs service vs model)?

| Method | Q1 | Q2 | Q3 | Q4 | Q5 | Q6 | Q7 | Q8 |
|---|---|---|---|---|---|---|---|---|
| `store` | ASCA-06 | ok | ok | ASCA-06 | ASCA-05 | ok | ASCA-05 | ok |
| `update` | ASCA-06, ASCA-13 | ok | ok | ASCA-06 | ASCA-05 | ok | ASCA-05 | ASCA-13 |
| `destroy` | ok | ok | ok | ok | ASCA-14 | ok | ASCA-05, ASCA-21 | ok |
| `toggleStatus` | ok | ok | ok | ok | ASCA-05 | ok | ASCA-05 | ok |
| `restore` | ok | ok | ok | ok | ASCA-05 | ok | ASCA-05 | ok |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | ok |

**ASCA-21 - LOW - STY-07: the destroy error message does not match the guard.**

- **Location:** `AssetCategoryController.php:95-96`; guard at `AssetCategory.php:106`.
- **Finding:** `isDeletable()` blocks fixed assets **and child categories**, but the user-facing message mentions only fixed assets.
- **Root cause:** the message predates the child-category guard.
- **Consequence:** a user with an empty category that has children is told to remove fixed assets, which is not the blocker.
- **Evidence:**

```php
        if (! $assetCategory->isDeletable()) {
            return back()->with('error', 'Cannot delete category with existing fixed assets.');
        }
```

```php
        return $this->fixedAssets()->count() === 0 && $this->children()->count() === 0;
```

- **Fix direction:** say "Cannot delete a category that has fixed assets or sub-categories." Apply ASCA-01.

## 7. Cross-cutting notes (common or other-module classes - not fixed here)

- **The real list is not this controller.** The Asset Categories tab is rendered by `AccDashboardController::assetsIntegration()` at `Modules\Accounting\app\Http\Controllers\AccDashboardController.php:1171-1187`. It paginates 25 with `ac_page` and does not eager-load `parent`, `assetLedger`, `accumDepLedger`, `depreciationExpenseLedger`. The partial reads all four relations inside the row loop (`_asset-categories.blade.php:110, 125, 128, 131`), so the tab issues roughly 4 extra queries per row. This belongs to the AccDashboard report; it is recorded here so the list behavior is not mistaken for this controller's.
- **The tab gate differs from this controller's gate.** `AccDashboardController::assetsIntegration()` authorizes `tenant.accounting.dashboard.view` at line 1173, while `AssetCategoryController::index()` authorizes `tenant.accounting.asset-category.viewAny`. The tab's role mapping is an AccDashboard concern; the 5 asset-category roles above are not proof that they can open the tab.
- **The live create/edit UI is the modal, not `create.blade.php`.** The modal is in the shared partial owned by AccDashboard. `AssetCategoryRequest` is reused by both paths, so ASCA-06 applies to both.
- **`AssetCategoryPolicy` is registered but dead.** See ASCA-07. Do not make it live in this pass without a decision; a partial switch would leave two authorization styles.
- **The route file is shared.** ASCA-04 and ASCA-17 change lines in `Modules\Accounting\routes\web.php`; the `action-trashed` component auto-adapts to a POST restore, so the component itself must not be edited.
- **`BaseAccountingModel` / `AccountingContext` are shared.** `created_by` is injected by the model boot hook; this controller's `store()` also sets it explicitly. That is consistent with the existing pattern, not a finding.
- **`FixedAsset` FK is `restrictOnDelete`.** `forceDelete()` relies on the database to stop a permanent delete while fixed assets exist. `isDeletable()` is the user-facing guard for soft delete.

## 8. Not covered, and why

| Not covered | Why |
|---|---|
| `AccDashboardController::assetsIntegration()` and `_asset-categories.blade.php` | Owned by the AccDashboard report; recorded as cross-cutting only |
| `FixedAssetController` / `FixedAsset` behavior | Linked report; only the FK and `isDeletable()` read were checked |
| `LedgerController` / `Ledger` behavior | Linked report; only the dropdown queries were checked |
| `BaseAccountingModel` / `AccountingContext` context resolution | Linked reports; only the `SoftDeletes` trait and `created_by` hook were checked |
| Live HTTP requests, JS modal behavior, browser form submission | Read-only audit; no server was driven |
| Tests / `php artisan test` | D4 - tests were not run |
| `_tools/scanfilter.py` and `_tools/selfcheck.py` | Missing from the checkout. Per the tooling override, `scan.php` was not run; all 13 families were audited manually. |
| `vendor/`, `node_modules/`, `public/`, `storage/` | Out of scope |
| Common Blade components (`action-trashed`, `tab.modal`, `status-switch`) | Shared components; behavior inferred from the call sites, not audited |
| Trashed-code uniqueness | Checked: the FormRequest unique rule does **not** exclude trashed rows and the DB unique index includes them, so validation matches the database. Not a finding. |
