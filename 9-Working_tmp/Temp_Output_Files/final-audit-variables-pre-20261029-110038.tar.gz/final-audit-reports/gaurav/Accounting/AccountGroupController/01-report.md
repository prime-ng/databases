# Final Audit — Accounting / AccountGroupController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/AccountGroupController.php` (296 lines, 12 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /accounting/account-group` (redirects to `/accounting/setup-masters?tab=account-groups`), `GET /accounting/account-group/create`, `GET /accounting/account-group/{id}`, `GET /accounting/account-group/{id}/edit`, `GET /accounting/account-group/trash/view` |
| Menu path | Accounting → Setup Masters → **Account Groups** tab (`accounting.menu.setupMasters?tab=account-groups`) |
| Who uses it | Roles holding the permission on test.localhost: `Super Admin` and `School Admin` (measured, exact-name query on `sys_role_has_permissions_jnt`) |
| What a user does here | Maintains the chart-of-accounts hierarchy: creates an account group (code, name, alias, parent, nature, flags), edits it, activates/deactivates it, marks it as a "system" group, soft-deletes it to a trash list, and restores or permanently deletes from that list. |
| Tables written | `acc_account_groups` (INSERT/UPDATE/soft-DELETE/force-DELETE), `sys_activity_logs` (via the `activityLog()` helper) |
| Tables read | `acc_account_groups`, `acc_ledgers` (delete guard), `sys_users` (FK targets) |
| Live data | `acc_account_groups`: **51 live, 0 trashed** (all 51 `is_system = 1`, 9 Equity); `acc_ledgers`: 56 live. Measured on `xyz_school_00000000000040008000_202627`. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/AccountGroupController.php` | controller | 296 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/AccountGroup.php` | model | 179 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/AccountGroupRequest.php` | form request | 58 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/resources/views/account-group/create.blade.php` | blade | 189 | this report | ✅ |
| 5 | `Modules/Accounting/resources/views/account-group/edit.blade.php` | blade | 191 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/account-group/show.blade.php` | blade | 165 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/account-group/trash.blade.php` | blade | 88 | this report | ✅ |
| 8 | `Modules/Accounting/resources/views/account-group/index.blade.php` | blade | 164 | this report | ✅ (dead — see ACGR-11) |
| 9 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | model (base) | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 10 | `Modules/Accounting/app/Services/AccountingContext.php` | service | 110 | unclaimed (reached only through BaseAccountingModel) | ✅ light |
| 11 | `Modules/Accounting/resources/views/pages/partials/setup-masters/_account-groups.blade.php` | blade | 559 | ↗ `gaurav/Accounting/AccDashboardController` (row CLAIMED) | ↗ linked |
| 12 | `Modules/Accounting/resources/views/pages/partials/setup-masters/_account-group-node.blade.php` | blade | 132 | ↗ `gaurav/Accounting/AccDashboardController` (row CLAIMED) | ↗ linked |
| 13 | `Modules/Accounting/routes/web.php` (account-group lines 107-112) | route file | — | ⚠ SHARED — not audited as a class | ⚠ |
| 14 | `resources/views/components/backend/table/action-trashed.blade.php` | common component | 110 | common (never claimed) | read for ACGR-08 |

No pre-applied files.

The account-groups tab is rendered by `AccDashboardController::setupMasters()` (line 81) whose row in `gaurav/Accounting/00-INDEX.md` is `CLAIMED`, not `AUDITED`. Its list query (`AccountGroup::with('childrenRecursive')->orderBy('name')->get()`, line 108, no pagination) and the two partials above belong to that report; this report only flags the model methods they call.

## 4. Routes

```
GET|HEAD  accounting/account-group                                accounting.account-group.index      AccountGroupController@index
POST      accounting/account-group                                accounting.account-group.store      AccountGroupController@store
GET|HEAD  accounting/account-group/create                         accounting.account-group.create     AccountGroupController@create
GET|HEAD  accounting/account-group/trash/view                     accounting.account-group.trashed    AccountGroupController@trashed
GET|HEAD  accounting/account-group/{account_group}                accounting.account-group.show       AccountGroupController@show
PUT|PATCH accounting/account-group/{account_group}                accounting.account-group.update     AccountGroupController@update
DELETE    accounting/account-group/{account_group}                accounting.account-group.destroy    AccountGroupController@destroy
GET|HEAD  accounting/account-group/{account_group}/edit           accounting.account-group.edit       AccountGroupController@edit
POST      accounting/account-group/{account_group}/toggle-status  accounting.account-group.toggleStatus AccountGroupController@toggleStatus
POST      accounting/account-group/{account_group}/toggle-system  accounting.account-group.toggleSystem AccountGroupController@toggleSystem
DELETE    accounting/account-group/{id}/force-delete              accounting.account-group.forceDelete AccountGroupController@forceDelete
GET|HEAD  accounting/account-group/{id}/restore                   accounting.account-group.restore    AccountGroupController@restore
```

All routes carry `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:Accounting, Authenticate, EnsureEmailIsVerified`.

Unrouted public methods: **none** — all 12 public methods are routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | GET /accounting/account-group | `tenant.accounting.account-group.viewAny` | — | — | — | — |
| `create` | 24 | GET /accounting/account-group/create | `tenant.accounting.account-group.create` | — | — | — | ACGR-09 |
| `store` | 33 | POST /accounting/account-group | `tenant.accounting.account-group.create` (×2) | controller (manual) | `'Created'` | acc_account_groups, sys_activity_logs | ACGR-01, ACGR-03, ACGR-04, ACGR-05, ACGR-09 |
| `show` | 66 | GET /accounting/account-group/{account_group} | `tenant.accounting.account-group.view` | — | — | — | — |
| `edit` | 75 | GET /accounting/account-group/{account_group}/edit | `tenant.accounting.account-group.update` | — | — | — | ACGR-09 |
| `update` | 88 | PUT/PATCH /accounting/account-group/{account_group} | `tenant.accounting.account-group.update` (×2) | controller (manual) | `'Updated'` | acc_account_groups, sys_activity_logs | ACGR-01, ACGR-03, ACGR-04, ACGR-05, ACGR-06, ACGR-07, ACGR-09 |
| `destroy` | 122 | DELETE /accounting/account-group/{account_group} | `tenant.accounting.account-group.delete` | controller (manual) | `'Trashed'` | acc_account_groups, sys_activity_logs | ACGR-01, ACGR-03 |
| `trashed` | 170 | GET /accounting/account-group/trash/view | `tenant.accounting.account-group.restore` | — | — | — | — |
| `restore` | 179 | GET /accounting/account-group/{id}/restore | `tenant.accounting.account-group.restore` | controller (manual) | `'Restored'` | acc_account_groups, sys_activity_logs | ACGR-01, ACGR-02, ACGR-03, ACGR-08 |
| `forceDelete` | 207 | DELETE /accounting/account-group/{id}/force-delete | `tenant.accounting.account-group.forceDelete` | controller (manual) | `'Deleted'` | acc_account_groups, sys_activity_logs | ACGR-01, ACGR-02, ACGR-03 |
| `toggleStatus` | 236 | POST /accounting/account-group/{account_group}/toggle-status | `tenant.accounting.account-group.update` | controller (manual) | `'Toggled'` | acc_account_groups, sys_activity_logs | ACGR-01, ACGR-03 |
| `toggleSystem` | 264 | POST /accounting/account-group/{account_group}/toggle-system | `tenant.accounting.account-group.update` | controller (manual) | `'System Status Toggled'` | acc_account_groups, sys_activity_logs | ACGR-01, ACGR-03, ACGR-19 |

## 6. Findings

### F1 — Errors

#### ACGR-01 · B · ERR-01 — Raw exception text is shown to the user in all seven write actions

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AccountGroupController.php:55-63, 111-119, 159-167, 199-204, 228-233, 256-261, 289-294` — methods `store()`, `update()`, `destroy()`, `restore()`, `forceDelete()`, `toggleStatus()`, `toggleSystem()` |
| **Root cause** | Every mutation uses a hand-written `try { … } catch (\Throwable $e)` and puts `$e->getMessage()` into the flash/JSON payload. `DB::transaction()` already rolls back and re-throws (D1), so the try/catch exists only to do the wrong thing. A duplicate `name`/`code` (the table has unique indexes on both) throws a `QueryException` whose message contains the table and column names. |
| **Consequence** | When a save fails — e.g. a duplicate group name — the user sees the raw MySQL error (table and column names) instead of a friendly message. |
| **Reproduce** | Open the Account Groups tab, use "Add Account Group", submit a `name` that already exists; the flash is `Failed to create Account Group: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry '…' for key 'uq_acc_ag_name'`. |
| **Fix approach** | Delete the try/catch and the manual transaction; wrap the writes in `DB::transaction(fn () => …)` and let the central handler report the failure (D1). |
| **Plan item** | ACGR-01 in `02-fix-plan.md` §1 (also closes ACGR-02, ACGR-03, ACGR-04) |

```php
// AccountGroupController.php:55-63 — CURRENT (store; same shape in the other six methods)
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Account Group', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Account Group: ' . $e->getMessage());
        }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AccountGroupController.php -Pattern "getMessage" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
58:'error' => $e->getMessage(),
62:return back()->withInput()->with('error', 'Failed to create Account Group: ' . $e->getMessage());
115:'error' => $e->getMessage(),
118:return back()->withInput()->with('error', 'Failed to update Account Group: ' . $e->getMessage());
163:'error' => $e->getMessage(),
166:return back()->with('error', 'Failed to delete Account Group: ' . $e->getMessage());
201:Log::error('Failed to restore Account Group', ['id' => $id, 'error' => $e->getMessage()]);
203:return back()->with('error', 'Failed to restore Account Group: ' . $e->getMessage());
230:Log::error('Failed to force delete Account Group', ['id' => $id, 'error' => $e->getMessage()]);
232:return back()->with('error', 'Failed to delete Account Group: ' . $e->getMessage());
258:Log::error('Failed to toggle Account Group status', ['id' => $accountGroup->id, 'error' => $e->getMessage()]);
260:return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
291:Log::error('Failed to toggle Account Group system status', ['id' => $accountGroup->id, 'error' => $e->getMessage()]);
293:return response()->json(['success' => false, 'message' => 'Failed to update system status: ' . $e->getMessage()], 500);
```

#### ACGR-02 · H · ERR-02 — A missing record returns a redirect with an error instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AccountGroupController.php:185, 199-204` (`restore()`) and `213, 228-233` (`forceDelete()`) |
| **Root cause** | `findOrFail()` is called **inside** the `try`, and `catch (\Throwable $e)` swallows the `ModelNotFoundException`, converting a 404 into a redirect with a flash that also leaks the exception text (ACGR-01). |
| **Consequence** | Opening a restore/force-delete link for a record that no longer exists shows "Failed to restore Account Group: No query results…" instead of a clean 404, and logs a failure. |
| **Reproduce** | `GET /accounting/account-group/999999/restore` (or `DELETE /accounting/account-group/999999/force-delete`). Expected 404; actual redirect + red flash. |
| **Fix approach** | Call `findOrFail()` before the transaction (outside any try), per D1. |
| **Plan item** | ACGR-01 in `02-fix-plan.md` §1 |

```php
// AccountGroupController.php:183-204 — CURRENT (restore)
        DB::beginTransaction();
        try {
            $group = AccountGroup::onlyTrashed()->findOrFail($id);
            $group->restore();
            $group->update(['is_active' => true]);
            ...
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Account Group', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Account Group: ' . $e->getMessage());
        }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AccountGroupController.php -Pattern "findOrFail|catch \(" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
55:} catch (\Throwable $e) {
111:} catch (\Throwable $e) {
159:} catch (\Throwable $e) {
185:$group = AccountGroup::onlyTrashed()->findOrFail($id);
199:} catch (\Throwable $e) {
213:$group = AccountGroup::withTrashed()->findOrFail($id);
228:} catch (\Throwable $e) {
256:} catch (\Throwable $e) {
289:} catch (\Throwable $e) {
```

#### ACGR-03 · M · ERR-05 — Logs record only the message; four of seven omit the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AccountGroupController.php:57-60` (has trace), but `113-116`, `161-164`, `201`, `230`, `258`, `291` log `$e->getMessage()` only |
| **Root cause** | The catch blocks were copied; only `store()` was given a `trace` key. The other six log the message alone, so the stack trace is lost. |
| **Consequence** | When a save fails in production, the log line names the failure but not where it happened, making diagnosis slower. |
| **Reproduce** | static only — no user-visible symptom; verify by reading the log handlers. |
| **Fix approach** | Remove the try/catch entirely (ACGR-01); the central handler logs the full exception. |
| **Plan item** | ACGR-01 in `02-fix-plan.md` §1 |

```php
// AccountGroupController.php:113-116 — CURRENT (update; no exception object)
            Log::error('Failed to update Account Group', [
                'id'    => $accountGroup->id,
                'error' => $e->getMessage(),
            ]);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AccountGroupController.php -Pattern "trace" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
59:'trace' => $e->getTraceAsString(),
```
(only one `trace` key in the whole controller, for seven catches)

### F2 — Transactions and audit

#### ACGR-04 · M · TXN-02 — Hand-rolled beginTransaction/commit/rollBack in seven methods

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`; never return between them* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AccountGroupController.php:40, 96, 142, 183, 211, 242, 270` (begin) with their closes |
| **Root cause** | Each mutation opens a transaction manually. In `restore()`/`forceDelete()` the `findOrFail()` sits between begin and commit, so a 404 leaves the manual flow dependent on `rollBack()` in the catch. The closure form ties the transaction's life to one block. |
| **Consequence** | A future edit that returns early between `beginTransaction()` and `commit()` would leave a transaction open for the rest of the request, risking locked rows. |
| **Reproduce** | static only — the current code always reaches `commit()`/`rollBack()`. |
| **Fix approach** | Replace with `DB::transaction(...)` in all seven methods (same item as ACGR-01). |
| **Plan item** | ACGR-01 in `02-fix-plan.md` §1 |

```php
// AccountGroupController.php:40-51 — CURRENT (store)
        DB::beginTransaction();
        try {
            $group = AccountGroup::create($validated);
            ...
            DB::commit();

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'account-groups'])
                ->with('success', 'Account Group created successfully.');
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AccountGroupController.php -Pattern "beginTransaction|::commit|rollBack" | Measure-Object | Select-Object -ExpandProperty Count
21
```
(7 begins + 7 commits + 7 rollBacks = 21 lines)

### F3 — Authorization

#### ACGR-05 · L · AUTH-04 — `store`/`update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice; keep one* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AccountGroupController.php:35, 90` vs `AccountGroupRequest::authorize()` (`Modules/Accounting/app/Http/Requests/AccountGroupRequest.php:17`) |
| **Root cause** | The FormRequest maps POST→`create` and PUT/PATCH→`update` via `AuthorizesTenantFeature::crudActionFromMethod()`, and the controller then calls `Gate::authorize()` with the identical string. Both run. |
| **Consequence** | No user-visible effect; the same gate is evaluated twice per save and the permission lives in two places. |
| **Reproduce** | static only. |
| **Fix approach** | Keep the FormRequest's `authorize()`; delete the two redundant controller `Gate::authorize()` lines. |
| **Plan item** | ACGR-05 in `02-fix-plan.md` §4 |

```php
// AccountGroupController.php:33-38 — CURRENT (store)
    public function store(AccountGroupRequest $request)
    {
        Gate::authorize('tenant.accounting.account-group.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();
```

**Evidence**
```
$ Select-String -Path app\Traits\AuthorizesTenantFeature.php -Pattern "'POST'|'PUT'" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
49:'POST'   => 'create',
50:'PUT',
51:'PATCH'  => 'update',
```
The FormRequest therefore already checks `tenant.accounting.account-group.create` / `.update`. Permission strings exist and are seeded — see F3 evidence below.

**F3 clean (permission existence):** all seven names are declared in `config/permissionslist.php:586` (`'accounting.account-group' => $crud`) and seeded, exact-name query:
```
EXACT_FOUND=["tenant.accounting.account-group.create","tenant.accounting.account-group.delete","tenant.accounting.account-group.forceDelete","tenant.accounting.account-group.restore","tenant.accounting.account-group.update","tenant.accounting.account-group.view","tenant.accounting.account-group.viewAny"]
PERM tenant.accounting.account-group.viewAny ROLES=2
PERM tenant.accounting.account-group.forceDelete ROLES=2
```
Gate-first ordering: every routed method calls `Gate::authorize()` before loading (lines 19, 26, 35, 68, 77, 90, 124, 172, 181, 209, 238, 266) — clean.

### F4 — Validation and input

#### ACGR-06 · H · VAL-04 — Uniqueness rules do not mirror the real unique indexes (code soft-delete mismatch; name has no rule)

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the DB unique index including soft-delete semantics* |
| **Where** | `Modules/Accounting/app/Http/Requests/AccountGroupRequest.php:25-26` vs the migration `database/migrations/tenant/2026_09_16_100001_create_acc_account_groups_table.php:40-41` |
| **Root cause** | The table has `unique('code','uq_acc_ag_code')` and `unique('name','uq_acc_ag_name')` on **all** rows (soft-deleted included). The `code` rule adds `->whereNull('deleted_at')`, so it does not see trashed rows, and `name` has no unique rule at all. A re-created `code` or a duplicate `name` passes validation then hits the DB index. |
| **Consequence** | Creating a group whose code belongs to a trashed group, or reusing any existing name, is accepted by validation and then fails with a raw SQL duplicate-key error (see ACGR-01). |
| **Reproduce** | Account Groups → Add: use a `name` that already exists → SQLSTATE 1062 error flash instead of a field-level "already taken" message. Trash a group, then create a new one with its code → same. |
| **Fix approach** | Add a `name` unique rule and drop the `whereNull('deleted_at')` from the `code` rule so both mirror the physical index; also align the max lengths to the DDL (`code` 30, `name` 120). |
| **Plan item** | ACGR-06 in `02-fix-plan.md` §5 |

```php
// AccountGroupRequest.php:25-26 — CURRENT
            'name'                 => 'required|string|max:100',
            'code'                 => ['required', 'string', 'max:20', Rule::unique('acc_account_groups', 'code')->ignore($id)->whereNull('deleted_at')],
```

**Evidence**
```
$ Select-String -Path database\migrations\tenant\2026_09_16_100001_create_acc_account_groups_table.php -Pattern "unique\(" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
40:$table->unique('code', 'uq_acc_ag_code');
41:$table->unique('name', 'uq_acc_ag_name');
```

#### ACGR-07 · H · VAL-07 — Parent selection has no self/cycle guard; the tree can be made cyclic

| Field | Value |
|---|---|
| **Rule** | VAL-07 (H) — *cross-field / business checks belong in the FormRequest's `after()` hook* |
| **Where** | `Modules/Accounting/app/Http/Requests/AccountGroupRequest.php:28` (`parent_id` rule) and `Modules/Accounting/app/Models/AccountGroup.php:63-74` (update hook that rebuilds depth/path) |
| **Root cause** | `parent_id` is validated only with `exists:acc_account_groups,id`. It may be the group's own id or one of its descendants. The DB trigger only blocks `parent_id = id` (self), and `selectableParents($excludeId)` only removes the group itself from the edit dropdown; nothing stops a crafted POST from choosing a descendant. The `updating`/`updated` hooks then set `depth`/`path` from the new parent and call `recalculateChildrenTree()`, which recurses. |
| **Consequence** | A group can be reparented under one of its own sub-groups, corrupting the materialised `path`/`depth` of the whole subtree and risking unbounded recursion when the tree is read. |
| **Reproduce** | static only — craft the edit form POST with `parent_id` set to a child of the group being edited. |
| **Fix approach** | Add an `after()` check that rejects `parent_id === id` and any parent whose `path` already contains the current group's id. |
| **Plan item** | ACGR-07 in `02-fix-plan.md` §5 |

```php
// AccountGroupRequest.php:28 — CURRENT
            'parent_id'            => 'nullable|exists:acc_account_groups,id',
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Models\AccountGroup.php -Pattern "selectableParents|excludeId|withTrashed\(\)->find" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
46:                    $parent = static::withTrashed()->find($model->parent_id);
55:                $parent = static::withTrashed()->find($model->parent_id);
66:                    $parent = static::withTrashed()->find($model->parent_id);
166:    public static function selectableParents($excludeId = null)
168:        return static::active()
169:            ->when($excludeId, fn ($q) => $q->where('id', '!=', $excludeId))
```
The only exclusion is `id != $excludeId`; descendants are not excluded.

### F5 — Routes

#### ACGR-08 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:109` — `Route::get('/account-group/{id}/restore', …)->name('account-group.restore')` |
| **Root cause** | Restore is a write (it flips `deleted_at` and `is_active`) exposed as `GET`. |
| **Consequence** | A crawler, a link prefetcher, or a crafted `<img src>` can silently restore a trashed group without any CSRF token. |
| **Reproduce** | While logged in, visit `GET /accounting/account-group/{id}/restore` directly in the address bar. |
| **Fix approach** | Change the verb to POST. The shared `action-trashed` component reads the route's HTTP method at render time and emits a CSRF-protected form automatically, so no component change is needed. |
| **Plan item** | ACGR-08 in `02-fix-plan.md` §5 (⚠ SHARED — route file) |

```php
// Modules/Accounting/routes/web.php:109 — CURRENT
Route::get('/account-group/{id}/restore', [AccountGroupController::class, 'restore'])->name('account-group.restore');
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\routes\web.php -Pattern "account-group" | ForEach-Object { "$($_.LineNumber): $($_.Line.Trim())" }
107: Route::resource('account-group', AccountGroupController::class);
108: Route::get('/account-group/trash/view', [AccountGroupController::class, 'trashed'])->name('account-group.trashed');
109: Route::get('/account-group/{id}/restore', [AccountGroupController::class, 'restore'])->name('account-group.restore');
```
The component adapts:
```
$ Select-String -Path resources\views\components\backend\table\action-trashed.blade.php -Pattern "restoreMethod|@csrf" | ForEach-Object { "$($_.LineNumber): $($_.Line.Trim())" }
20:$restoreMethod = strtoupper($restoreMethods->first() ?? 'GET');
30:method="{{ $restoreMethod === 'GET' ? 'GET' : 'POST' }}"
33:@csrf
```

### F6 — Controller shape

#### ACGR-09 · M · CTL-05 — Copy-paste: the nature dropdown exists in three places and the two page copies are missing `Equity`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste; the same payload repeated / copies that disagree* |
| **Where** | `Modules/Accounting/resources/views/account-group/create.blade.php:108-111`, `Modules/Accounting/resources/views/account-group/edit.blade.php:110-113`, and the modal copy in `Modules/Accounting/resources/views/pages/partials/setup-masters/_account-groups.blade.php:346-350` |
| **Root cause** | The `nature` select is duplicated verbatim. The modal copy lists all five natures (Asset, Liability, Equity, Income, Expense); the create and edit page copies dropped `Equity`. `AccountGroup::natures()` and the FormRequest both allow Equity. |
| **Consequence** | An Equity group cannot be created from the create page, and editing one on the edit page forces a different nature (so its statement placement silently changes) — the option it needs is absent. |
| **Reproduce** | Open `/accounting/account-group/create` and look at "Nature": there is no Equity option. Open `/accounting/account-group/{equity-id}/edit`: no Equity is selected even though the record is Equity. |
| **Fix approach** | Add the missing `Equity` option to both page copies (one line each). |
| **Plan item** | ACGR-09 in `02-fix-plan.md` §5 |

```php
// create.blade.php:108-111 — CURRENT (edit.blade.php has the same four, using old('nature', $accountGroup->nature))
<option value="Asset" {{ old('nature') == 'Asset' ? 'selected' : '' }}>Asset</option>
<option value="Liability" {{ old('nature') == 'Liability' ? 'selected' : '' }}>Liability</option>
<option value="Income" {{ old('nature') == 'Income' ? 'selected' : '' }}>Income</option>
<option value="Expense" {{ old('nature') == 'Expense' ? 'selected' : '' }}>Expense</option>
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\resources\views\account-group\create.blade.php,Modules\Accounting\resources\views\account-group\edit.blade.php -Pattern "Equity" | ForEach-Object { "$($_.Filename):$($_.LineNumber)" }
(no output)
$ Select-String -Path Modules\Accounting\resources\views\pages\partials\setup-masters\_account-groups.blade.php -Pattern "Equity" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
19:@foreach (['Asset', 'Liability', 'Equity', 'Income', 'Expense'] as $nat)
104:'Equity' => [
348:<option value="Equity" {{ old('nature') == 'Equity' ? 'selected' : '' }}>Equity</option>
```

#### ACGR-10 · L · CTL-04 — No return types on any of the 12 public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AccountGroupController.php:17, 24, 33, 66, 75, 88, 122, 170, 179, 207, 236, 264` |
| **Root cause** | None of the public methods declares a return type, so a wrong return in a future edit is not caught. |
| **Consequence** | No user-visible effect; weaker static safety. |
| **Reproduce** | static only. |
| **Fix approach** | Add `View` / `RedirectResponse` / `JsonResponse` return types (imports included). |
| **Plan item** | ACGR-10 in `02-fix-plan.md` §8 |

```php
// AccountGroupController.php:17-18 — CURRENT
    public function index()
    {
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AccountGroupController.php -Pattern "public function" | ForEach-Object { $_.Line.Trim() }
public function index()
public function create()
public function store(AccountGroupRequest $request)
...
```
(12 matches; none ends with a `:` return type)

#### ACGR-11 · M · CTL-10 — `index.blade.php` is dead (never rendered by any controller)

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code* |
| **Where** | `Modules/Accounting/resources/views/account-group/index.blade.php` (164 lines) |
| **Root cause** | `AccountGroupController::index()` redirects to the Setup Masters tab; the list is rendered by `AccDashboardController` through `_account-groups.blade.php`. Nothing renders `account-group.index`, and no file references it. |
| **Consequence** | Dead template that can drift from the live one and confuse the next maintainer. |
| **Reproduce** | static only. |
| **Fix approach** | Delete the file (or keep with a header note if a historical reference is wanted). |
| **Plan item** | none — see `02-fix-plan.md` §10 |

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\*.php -Pattern "account-group.index" | ForEach-Object { "$($_.Filename):$($_.LineNumber)" }
(no output)
$ Get-ChildItem -Recurse Modules\Accounting\resources\views -Filter *.blade.php | Select-String -Pattern "account-group\.index" | ForEach-Object { "$($_.Path):$($_.LineNumber)" }
(only index.blade.php's own two self-references to the route)
```

### F7 — Models

#### ACGR-12 · M · MDL-06 — `AccountGroup::booted()` overrides the parent without `parent::booted()`, so `updated_by` is never populated

| Field | Value |
|---|---|
| **Rule** | MDL-06 (M) — *data normalisation belongs in the model; here the model's boot hook silently disables the audit-column normalisation* |
| **Where** | `Modules/Accounting/app/Models/AccountGroup.php:42-51` vs `Modules/Accounting/app/Models/BaseAccountingModel.php:18-31` |
| **Root cause** | `BaseAccountingModel::booted()` registers a `creating` callback (accounting context) and an `updating` callback that sets `updated_by = Auth::id()`. `AccountGroup` defines its own `booted()` and never calls `parent::booted()`, so neither parent callback is registered. The controller only sets `created_by` on `store`; `updated_by` is never set anywhere. |
| **Consequence** | The `updated_by` audit column stays `NULL` on every edit, so "who last changed this group" is never recorded. (Measured: all 51 live rows have `updated_by` null.) |
| **Reproduce** | static only — edit any non-system group and re-read `acc_account_groups.updated_by`. |
| **Fix approach** | Call `parent::booted();` as the first line of `AccountGroup::booted()`. |
| **Plan item** | ACGR-12 in `02-fix-plan.md` §5 |

```php
// AccountGroup.php:42-44 — CURRENT
    protected static function booted(): void
    {
        static::creating(function (AccountGroup $model) {
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Models\BaseAccountingModel.php -Pattern "parent::booted|updating" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
20:parent::booted();
26:static::updating(function (self $model): void {
27:if ($model->isFillable('updated_by') && empty($model->updated_by)) {
28:$model->updated_by = Auth::id() ?? 1;
```
```
$ php probe_data.php
NUPDATEDBY=51
```
(all 51 rows have `updated_by` null)

#### ACGR-13 · M · MDL-02 — The `nature` enum column has no cast; `parent_id` is untyped

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` for every boolean, date, decimal, json/array and enum column* |
| **Where** | `Modules/Accounting/app/Models/AccountGroup.php:34-40` |
| **Root cause** | `nature` is a DB `enum` but is not cast to a PHP enum or string-typed; `parent_id` has no integer cast. The five-nature list is then repeated as string literals in the model, the FormRequest and three views. |
| **Consequence** | No user-visible bug today; the allowed-nature list can drift between the DB enum, the FormRequest and the views (it already has — see ACGR-09). |
| **Reproduce** | static only. |
| **Fix approach** | Add a `nature` cast (a backed enum) and `parent_id => 'integer'`; drive the form options from `AccountGroup::natures()`. Creating the enum class is a decision, so the plan defers it. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// AccountGroup.php:34-40 — CURRENT
    protected $casts = [
        'affects_gross_profit' => 'boolean',
        'depth'                => 'integer',
        'is_system'            => 'boolean',
        'is_subledger'         => 'boolean',
        'is_active'            => 'boolean',
    ];
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Models\AccountGroup.php -Pattern "casts|nature" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
34:protected $casts = [
...
175:public static function natures(): array
177:return ['Asset', 'Liability', 'Equity', 'Income', 'Expense'];
```

### F8 — Services and jobs

clean — the controller names no service, job, event or listener (`grep -nE "Service|Job|Event|Mail|Notification" Modules/Accounting/app/Http/Controllers/AccountGroupController.php` → no output). `AccountingContext` is reached only through the linked `BaseAccountingModel`; its `getUserId()` uses `Auth::id() ?? 1` (`AccountingContext.php:108`) — a hard-coded fallback, noted as a cross-cutting item under §7.

### F9 — Queries and performance

#### ACGR-14 · M · QRY-04 — `isDeletable()` uses `count()` instead of `exists()`, and it is called once per row in the list

| Field | Value |
|---|---|
| **Rule** | QRY-04 (M) — *use `exists()` not `count() > 0`* |
| **Where** | `Modules/Accounting/app/Models/AccountGroup.php:157`, called from `Modules/Accounting/resources/views/pages/partials/setup-masters/_account-group-node.blade.php:115` |
| **Root cause** | `isDeletable()` runs `$this->ledgers()->count() === 0`. The node partial is included once per group while rendering the tab, so the count runs for every row of the tree. |
| **Consequence** | The Account Groups tab fires one extra `COUNT` query per group row (51 today) where `exists()` would stop at the first ledger. |
| **Reproduce** | static only — enable the query log and open `/accounting/setup-masters?tab=account-groups`. |
| **Fix approach** | Use `! $this->ledgers()->exists()`. |
| **Plan item** | ACGR-14 in `02-fix-plan.md` §6 |

```php
// AccountGroup.php:155-158 — CURRENT
    public function isDeletable(): bool
    {
        return ! $this->is_system && ! $this->is_subledger && $this->ledgers()->count() === 0;
    }
```

**Evidence**
```
$ Get-ChildItem -Recurse Modules\Accounting\resources\views -Filter *.blade.php | Select-String -Pattern "isDeletable" | ForEach-Object { "$($_.Path):$($_.LineNumber)" }
...\_account-group-node.blade.php:115
...\index.blade.php:78
...\_ledgers.blade.php:219
...\ledger\index.blade.php:77
```

#### ACGR-15 · M · QRY-01 — `recalculateChildrenTree()` queries and saves per child inside the loop

| Field | Value |
|---|---|
| **Rule** | QRY-01 (M for a small tree; H would apply on a large one) — *no queries inside loops; pre-fetch / bulk-write* |
| **Where** | `Modules/Accounting/app/Models/AccountGroup.php:83-92` |
| **Root cause** | For each child it runs `saveQuietly()` and then recurses, so reparenting a group issues one `UPDATE` (and one lazy query) per descendant node. |
| **Consequence** | Editing the parent of a large subtree issues many round-trips; a 500-node subtree is 500 updates in one request. |
| **Reproduce** | static only — reparent a group with children and count queries. |
| **Fix approach** | Rewrite the subtree in `path`-prefix batches. Because a correct bulk rewrite of `path`/`depth` is non-trivial, the plan defers it as a decision item. |
| **Plan item** | ACGR-15 in `02-fix-plan.md` §9 (DECISION) |

```php
// AccountGroup.php:83-92 — CURRENT
    public function recalculateChildrenTree(): void
    {
        $children = static::where('parent_id', $this->id)->get();
        foreach ($children as $child) {
            $child->depth = $this->depth + 1;
            $child->path = $this->path . $child->id . '/';
            $child->saveQuietly();
            $child->recalculateChildrenTree();
        }
    }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Models\AccountGroup.php -Pattern "saveQuietly|foreach" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
86:foreach ($children as $child) {
89:$child->saveQuietly();
```

### F10 — Views

clean — the five blades render no queries (`Model::`/`DB::`/`->where(` absent), use no `{!! !!}`, and the `@foreach` relations (`$group->childrenRecursive`, `$accountGroup->ledgers`) are eager-loaded by the callers. `grep -nE "\{!!|DB::|Model::" Modules/Accounting/resources/views/account-group/*.blade.php` → no output. (The one view defect — the missing `Equity` option — is recorded as ACGR-09 under F6 because its root cause is the copied dropdown.)

### F11 — Security and tenancy

clean — no `env()` in the controller or its classes, no hard-coded ids, no secrets in logs (only model ids and messages), and every route is inside the tenant middleware group. `grep -n "env(" Modules/Accounting/app/Http/Controllers/AccountGroupController.php` → no output.

### F12 — Style

#### ACGR-16 · L · STY-02 — `AccountGroupController.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AccountGroupController.php` |
| **Root cause** | Pint reports `concat_space` and `binary_operator_spaces` violations. |
| **Consequence** | No user-visible effect; the file fails the project style gate. |
| **Reproduce** | Run the Verify command below. |
| **Fix approach** | Run Pint on the file (after the other items, since they rewrite much of it). |
| **Plan item** | ACGR-16 in `02-fix-plan.md` §8 |

```php
// AccountGroupController.php:1-13 — CURRENT (full file)
<?php

declare(strict_types=1);

namespace Modules\Accounting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Modules\Accounting\Http\Requests\AccountGroupRequest;
use Modules\Accounting\Models\AccountGroup;
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\AccountGroupController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\AccountGroupController.php","fixers":["concat_space","binary_operator_spaces"]}]}
```

#### ACGR-17 · L · STY-02 — `AccountGroup.php` is not Pint-clean and imports an unused class

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Models/AccountGroup.php:7` and throughout |
| **Root cause** | Pint reports `fully_qualified_strict_types`, `concat_space`, `unary_operator_spaces`, `no_unused_imports`, `not_operator_with_successor_space`, `ordered_imports`, `binary_operator_spaces`. `use App\Models\BaseModel;` (line 7) is unused. |
| **Consequence** | No user-visible effect; style gate failure and a misleading import. |
| **Reproduce** | Run the Verify command below. |
| **Fix approach** | Run Pint on the file. |
| **Plan item** | ACGR-17 in `02-fix-plan.md` §8 |

```php
// AccountGroup.php:7-10 — CURRENT
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Models\AccountGroup.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\AccountGroup.php","fixers":["fully_qualified_strict_types","concat_space","unary_operator_spaces","no_unused_imports","not_operator_with_successor_space","ordered_imports","binary_operator_spaces"]}]}
```

#### ACGR-18 · L · STY-02 — `AccountGroupRequest.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Accounting/app/Http/Requests/AccountGroupRequest.php:8-9` and throughout |
| **Root cause** | Pint reports `ordered_imports` and `binary_operator_spaces`. |
| **Consequence** | No user-visible effect; style gate failure. |
| **Reproduce** | Run the Verify command below. |
| **Fix approach** | Run Pint on the file (after ACGR-06/07 rewrite it). |
| **Plan item** | ACGR-18 in `02-fix-plan.md` §8 |

```php
// AccountGroupRequest.php:7-9 — CURRENT
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Validation\Rule;
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Http\Requests\AccountGroupRequest.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\AccountGroupRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutating method | 1 Overwrite? | 2 Delete-before-store? | 3 Duplicate impl? | 4 Soft-delete × unique? | 5 Race? | 6 Authz hole? | 7 Lying message? | 8 Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` (33) | ok | ok | ACGR-04 | ACGR-06 | ok | ACGR-05 | ok | ok |
| `update` (88) | ACGR-07 | ok | ACGR-04 | ACGR-06 | ok | ACGR-05 | ok | ok |
| `destroy` (122) | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` (179) | ACGR-07 (resets `is_active` to true, losing the pre-delete state) | ok | ok | ACGR-06 | ok | ok | ok | ok |
| `forceDelete` (207) | ok | ok | ok | ok | ok | ACGR-19 | ok | ok |
| `toggleStatus` (236) | ok | ok | ok | ok | ok | ACGR-19 | ok | ok |
| `toggleSystem` (264) | ACGR-19 | ok | ACGR-19 | ok | ok | ACGR-19 | ok | ok |

#### ACGR-19 · M · SVC-04 — The "system group" protection is enforced in three methods but bypassed by `toggleSystem`

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *one implementation per business operation; copies that disagree are a bug source* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AccountGroupController.php:79-81` (`edit`), `92-94` (`update`), `126-128` (`destroy`) vs `264-273` (`toggleSystem`) |
| **Root cause** | `edit`, `update` and `destroy` refuse when `$accountGroup->isSystem()`. `toggleSystem` (which only needs the `update` permission) can set `is_system` to `false` on any group, so the protection those three guards enforce can be switched off from another method, after which `update`/`destroy` will happily run. |
| **Consequence** | A user with `update` can un-mark any of the 51 protected system groups and then edit or delete it — the protection is not a single, consistent rule. Whether the toggle is *meant* to override the guard is a product decision, not something the code states. |
| **Reproduce** | static only — compare the three `isSystem()` guards with the absent guard in `toggleSystem`. |
| **Fix approach** | Decide: keep the toggle as an override, block `toggleSystem` when the group is already system, or gate it behind a separate permission. |
| **Plan item** | ACGR-19 in `02-fix-plan.md` §9 (DECISION — behaviour change) |

```php
// AccountGroupController.php:264-273 — CURRENT (toggleSystem: no isSystem() guard)
    public function toggleSystem(Request $request, AccountGroup $accountGroup)
    {
        Gate::authorize('tenant.accounting.account-group.update');

        $request->validate(['is_system' => 'required|boolean']);

        DB::beginTransaction();
        try {
            $accountGroup->is_system = (bool) $request->input('is_system');
            $accountGroup->save();
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\AccountGroupController.php -Pattern "isSystem\(\)" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
79:        if ($accountGroup->isSystem()) {
92:        if ($accountGroup->isSystem()) {
126:        if ($accountGroup->isSystem()) {
```
(three guards; `toggleSystem` at 264 is not one of them)

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 4 | 9 | 5 | 2 | 19 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | ACGR-01, ACGR-02, ACGR-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | ACGR-04 | F9 Queries/Perf | ACGR-14, ACGR-15 |
| F3 Authorization | ACGR-05 | F10 Views | clean |
| F4 Validation | ACGR-06, ACGR-07 | F11 Security/Tenancy | clean |
| F5 Routes | ACGR-08 | F12 Style | ACGR-16, ACGR-17, ACGR-18 |
| F6 Controller shape | ACGR-09, ACGR-10, ACGR-11 | F13 Deep read | ACGR-19 |
| F7 Models | ACGR-12, ACGR-13 | | |

## 1. Verdict

This controller is **not production-ready as written**: every one of its seven write actions wraps the database in a hand-written try/catch that sends the raw `$e->getMessage()` to the user, so a duplicate group name shows the SQL error and a missing restore id shows an error instead of a 404. The single worst finding is **ACGR-01 (B, ERR-01)** — raw database error text (table and column names) reaches the user on a normal duplicate-name save, and it is the same code shape in all seven mutations. Around it sit four High findings: uniqueness rules that do not mirror the physical unique indexes (ACGR-06), a missing parent self/cycle guard that can corrupt the tree (ACGR-07), restore performed over GET (ACGR-08), and the swallowed 404 (ACGR-02). The permission model itself is sound — all seven names exist in config and are seeded to the two admin roles. Effort to clear the plan is **S/M** (roughly a day): most of the High and the Blocker collapse into one mechanical "replace begin/try/catch with `DB::transaction`" edit, plus two FormRequest rules, one route verb, and three Pint runs.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | `updating()` sets `updated_by = Auth::id() ?? 1`; the `?? 1` is a hard-coded user fallback. Also its `booted()` is bypassed by `AccountGroup` (ACGR-12). | SEC-03 | [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) |
| `Modules/Accounting/app/Services/AccountingContext.php` | `getUserId()` returns `Auth::id() ?? 1` and `getCampusId()` returns `1` as a fallback. | SEC-03 | unclaimed — reported here |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:108` | The account-groups list query `AccountGroup::with('childrenRecursive')->orderBy('name')->get()` is unbounded (no pagination). 51 rows today; grows with the chart of accounts. | QRY-02 | `gaurav/Accounting/AccDashboardController` (row CLAIMED) |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_account-groups.blade.php`, `_account-group-node.blade.php` | Rendered by `AccDashboardController`; the node calls `isDeletable()` per row (ACGR-14). | QRY-01 | `gaurav/Accounting/AccDashboardController` (row CLAIMED) |
| `resources/views/components/backend/table/action-trashed.blade.php` | Reads the restore route's HTTP verb and builds GET/POST/`@method` accordingly — this is why ACGR-08 can be fixed without touching the component. | — | common (not fixed here) |

## 8. Not covered, and why

- **The live Account Groups list** is rendered by `AccDashboardController::setupMasters()` (2646 lines) whose index row is `CLAIMED`. Its query and its two partials are not audited here; only the `AccountGroup` methods they call are.
- **Browser rendering / JS AJAX** for `toggleStatus` / `toggleSystem` / the trash confirm dialogs was not exercised (D4 — no browser or test run). Findings there are static.
- **Queue jobs, listeners and scheduled commands**: none are reached by this controller (F8 clean).
- **`sys_activity_logs` writes**: `activityLog()` is a common helper; only the event literals (`'Created'`, `'Updated'`, `'Trashed'`, `'Restored'`, `'Deleted'`, `'Toggled'`, `'System Status Toggled'`) were recorded here, not the helper's internals.
- **Instruments:** `_tools/scanfilter.py` and `_tools/selfcheck.py` are missing and `scan.php` was not run (per the audit brief), so F1–F13 were worked manually with `grep`/`Select-String`, `php -l`, `pint` and direct DB probes. The §15 self-check could not be executed.
