# Fix Plan — Accounting / AccountGroupController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/AccountGroupController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | owned by `gaurav/Accounting/AccountingStatusMasterController` |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | owned by `gaurav/Accounting/AccDashboardController` (row CLAIMED) |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_account-groups.blade.php` | owned by `gaurav/Accounting/AccDashboardController` |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_account-group-node.blade.php` | owned by `gaurav/Accounting/AccDashboardController` |
| `resources/views/components/backend/table/action-trashed.blade.php` | common component — no change needed (it already adapts to the route verb) |
| any file under `database/migrations/` | migrations are never edited |

## 1. Blockers reachable today

- [ ] **ACGR-01** · B · ERR-01 · `AccountGroupController.php:40-63,96-119,142-167,183-204,211-233,242-261,270-293` — remove every try/catch and manual transaction; use `DB::transaction()` and let the central handler report failures. This item also closes **ACGR-02** (swallowed 404), **ACGR-03** (message-only logs) and **ACGR-04** (manual `beginTransaction`).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AccountGroupController.php`
  - **Before** (`AccountGroupController.php:7-13`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Accounting\Http\Requests\AccountGroupRequest;
    use Modules\Accounting\Models\AccountGroup;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Accounting\Http\Requests\AccountGroupRequest;
    use Modules\Accounting\Models\AccountGroup;
    ```
  - **Before** (`AccountGroupController.php:40-63`, method `store`):
    ```php
            DB::beginTransaction();
            try {
                $group = AccountGroup::create($validated);

                activityLog($group, 'Created', [
                    'message'      => 'Account Group created: ' . $group->name,
                    'code'         => $group->code,
                    'name'         => $group->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.setupMasters', ['tab' => 'account-groups'])
                    ->with('success', 'Account Group created successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to create Account Group', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString(),
                ]);

                return back()->withInput()->with('error', 'Failed to create Account Group: ' . $e->getMessage());
            }
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($validated) {
                $group = AccountGroup::create($validated);

                activityLog($group, 'Created', [
                    'message'      => 'Account Group created: ' . $group->name,
                    'code'         => $group->code,
                    'name'         => $group->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'account-groups'])
                ->with('success', 'Account Group created successfully.');
    ```
  - **Before** (`AccountGroupController.php:96-119`, method `update`):
    ```php
            DB::beginTransaction();
            try {
                $accountGroup->update($request->validated());

                activityLog($accountGroup, 'Updated', [
                    'message'      => 'Account Group updated: ' . $accountGroup->name,
                    'code'         => $accountGroup->code,
                    'name'         => $accountGroup->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.setupMasters', ['tab' => 'account-groups'])
                    ->with('success', 'Account Group updated successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to update Account Group', [
                    'id'    => $accountGroup->id,
                    'error' => $e->getMessage(),
                ]);

                return back()->withInput()->with('error', 'Failed to update Account Group: ' . $e->getMessage());
            }
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($request, $accountGroup) {
                $accountGroup->update($request->validated());

                activityLog($accountGroup, 'Updated', [
                    'message'      => 'Account Group updated: ' . $accountGroup->name,
                    'code'         => $accountGroup->code,
                    'name'         => $accountGroup->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'account-groups'])
                ->with('success', 'Account Group updated successfully.');
    ```
  - **Before** (`AccountGroupController.php:142-167`, method `destroy`):
    ```php
            DB::beginTransaction();
            try {
                $accountGroup->is_active = false;
                $accountGroup->save();
                $accountGroup->delete();

                activityLog($accountGroup, 'Trashed', [
                    'message'      => 'Account Group trashed: ' . $accountGroup->name,
                    'code'         => $accountGroup->code,
                    'name'         => $accountGroup->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.setupMasters', ['tab' => 'account-groups'])
                    ->with('success', 'Account Group moved to trash.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to trash Account Group', [
                    'id'    => $accountGroup->id,
                    'error' => $e->getMessage(),
                ]);

                return back()->with('error', 'Failed to delete Account Group: ' . $e->getMessage());
            }
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($accountGroup) {
                $accountGroup->is_active = false;
                $accountGroup->save();
                $accountGroup->delete();

                activityLog($accountGroup, 'Trashed', [
                    'message'      => 'Account Group trashed: ' . $accountGroup->name,
                    'code'         => $accountGroup->code,
                    'name'         => $accountGroup->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'account-groups'])
                ->with('success', 'Account Group moved to trash.');
    ```
  - **Before** (`AccountGroupController.php:183-204`, method `restore`):
    ```php
            DB::beginTransaction();
            try {
                $group = AccountGroup::onlyTrashed()->findOrFail($id);
                $group->restore();
                $group->update(['is_active' => true]);

                activityLog($group, 'Restored', [
                    'message'      => 'Account Group restored: ' . $group->name,
                    'code'         => $group->code,
                    'name'         => $group->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.account-group.trashed')->with('success', 'Account Group restored successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to restore Account Group', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to restore Account Group: ' . $e->getMessage());
            }
    ```
  - **After:**
    ```php
            $group = AccountGroup::onlyTrashed()->findOrFail($id);

            DB::transaction(function () use ($group) {
                $group->restore();
                $group->update(['is_active' => true]);

                activityLog($group, 'Restored', [
                    'message'      => 'Account Group restored: ' . $group->name,
                    'code'         => $group->code,
                    'name'         => $group->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.account-group.trashed')->with('success', 'Account Group restored successfully.');
    ```
  - **Before** (`AccountGroupController.php:211-233`, method `forceDelete`):
    ```php
            DB::beginTransaction();
            try {
                $group = AccountGroup::withTrashed()->findOrFail($id);
                $name = $group->name;
                $code = $group->code;
                $group->forceDelete();

                activityLog($group, 'Deleted', [
                    'message'      => 'Account Group permanently deleted: ' . $name,
                    'code'         => $code,
                    'name'         => $name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.account-group.trashed')->with('success', 'Account Group permanently deleted.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to force delete Account Group', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to delete Account Group: ' . $e->getMessage());
            }
    ```
  - **After:**
    ```php
            $group = AccountGroup::withTrashed()->findOrFail($id);
            $name = $group->name;
            $code = $group->code;

            DB::transaction(function () use ($group, $name, $code) {
                $group->forceDelete();

                activityLog($group, 'Deleted', [
                    'message'      => 'Account Group permanently deleted: ' . $name,
                    'code'         => $code,
                    'name'         => $name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.account-group.trashed')->with('success', 'Account Group permanently deleted.');
    ```
  - **Before** (`AccountGroupController.php:242-261`, method `toggleStatus`):
    ```php
            DB::beginTransaction();
            try {
                $accountGroup->is_active = $request->input('is_active');
                $accountGroup->save();

                activityLog($accountGroup, 'Toggled', [
                    'message'      => 'Account Group status toggled: ' . $accountGroup->name,
                    'code'         => $accountGroup->code,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return response()->json(['success' => true, 'is_active' => $accountGroup->is_active, 'message' => 'Status updated.']);
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to toggle Account Group status', ['id' => $accountGroup->id, 'error' => $e->getMessage()]);

                return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
            }
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($request, $accountGroup) {
                $accountGroup->is_active = $request->input('is_active');
                $accountGroup->save();

                activityLog($accountGroup, 'Toggled', [
                    'message'      => 'Account Group status toggled: ' . $accountGroup->name,
                    'code'         => $accountGroup->code,
                    'performed_by' => auth()->id(),
                ]);
            });

            return response()->json(['success' => true, 'is_active' => $accountGroup->is_active, 'message' => 'Status updated.']);
    ```
  - **Before** (`AccountGroupController.php:270-293`, method `toggleSystem`):
    ```php
            DB::beginTransaction();
            try {
                $accountGroup->is_system = (bool) $request->input('is_system');
                $accountGroup->save();

                activityLog($accountGroup, 'System Status Toggled', [
                    'message'      => 'Account Group system status toggled: ' . $accountGroup->name,
                    'code'         => $accountGroup->code,
                    'is_system'    => $accountGroup->is_system,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return response()->json([
                    'success'   => true,
                    'is_system' => $accountGroup->is_system,
                    'message'   => $accountGroup->is_system ? 'Marked as system group.' : 'Unmarked as system group.',
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to toggle Account Group system status', ['id' => $accountGroup->id, 'error' => $e->getMessage()]);

                return response()->json(['success' => false, 'message' => 'Failed to update system status: ' . $e->getMessage()], 500);
            }
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($request, $accountGroup) {
                $accountGroup->is_system = (bool) $request->input('is_system');
                $accountGroup->save();

                activityLog($accountGroup, 'System Status Toggled', [
                    'message'      => 'Account Group system status toggled: ' . $accountGroup->name,
                    'code'         => $accountGroup->code,
                    'is_system'    => $accountGroup->is_system,
                    'performed_by' => auth()->id(),
                ]);
            });

            return response()->json([
                'success'   => true,
                'is_system' => $accountGroup->is_system,
                'message'   => $accountGroup->is_system ? 'Marked as system group.' : 'Unmarked as system group.',
            ]);
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\AccountGroupController.php -Pattern "getMessage|beginTransaction|catch \(" | Measure-Object | Select-Object -ExpandProperty Count`
  - **Expect:** `0`
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

## 3. Errors & transactions (F1/F2)

(ACGR-01 above covers F1 and F2.)

## 4. Authorization (F3)

- [ ] **ACGR-05** · L · AUTH-04 · `AccountGroupController.php:35,90` — drop the controller `Gate::authorize()` calls that duplicate `AccountGroupRequest::authorize()`.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AccountGroupController.php`
  - **Before** (`AccountGroupController.php:33-38`, method `store`):
    ```php
        public function store(AccountGroupRequest $request)
        {
            Gate::authorize('tenant.accounting.account-group.create');

            $validated = $request->validated();
            $validated['created_by'] = auth()->id();
    ```
  - **After:**
    ```php
        public function store(AccountGroupRequest $request)
        {
            $validated = $request->validated();
            $validated['created_by'] = auth()->id();
    ```
  - **Before** (`AccountGroupController.php:88-94`, method `update`):
    ```php
        public function update(AccountGroupRequest $request, AccountGroup $accountGroup)
        {
            Gate::authorize('tenant.accounting.account-group.update');

            if ($accountGroup->isSystem()) {
                return back()->with('error', 'System account groups cannot be modified.');
            }
    ```
  - **After:**
    ```php
        public function update(AccountGroupRequest $request, AccountGroup $accountGroup)
        {
            if ($accountGroup->isSystem()) {
                return back()->with('error', 'System account groups cannot be modified.');
            }
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\AccountGroupController.php -Pattern "account-group.create'\)|account-group.update'\)" | Measure-Object | Select-Object -ExpandProperty Count`
  - **Expect:** `0`
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **ACGR-06** · H · VAL-04 · `AccountGroupRequest.php:25-26` — make the uniqueness rules mirror the physical unique indexes (`code` includes trashed rows; `name` gets a rule) and align the max lengths to the DDL.
  - **Touches:** `Modules/Accounting/app/Http/Requests/AccountGroupRequest.php`
  - **Before** (`AccountGroupRequest.php:25-26`):
    ```php
                'name'                 => 'required|string|max:100',
                'code'                 => ['required', 'string', 'max:20', Rule::unique('acc_account_groups', 'code')->ignore($id)->whereNull('deleted_at')],
    ```
  - **After:**
    ```php
                'name'                 => ['required', 'string', 'max:120', Rule::unique('acc_account_groups', 'name')->ignore($id)],
                'code'                 => ['required', 'string', 'max:30', Rule::unique('acc_account_groups', 'code')->ignore($id)],
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Requests\AccountGroupRequest.php -Pattern "whereNull\('deleted_at'\)|Rule::unique" | ForEach-Object { $_.Line.Trim() }`
  - **Expect:** two `Rule::unique(...)` lines, neither containing `whereNull`.
  - **Effort:** S

- [ ] **ACGR-07** · H · VAL-07 · `AccountGroupRequest.php` — reject a parent that is the group itself or one of its own descendants.
  - **Touches:** `Modules/Accounting/app/Http/Requests/AccountGroupRequest.php`
  - **Before** (`AccountGroupRequest.php:7-9`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Validation\Rule;
    ```
  - **After:**
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Validation\Rule;
    use Illuminate\Validation\Validator;
    use Modules\Accounting\Models\AccountGroup;
    ```
  - **Before** (`AccountGroupRequest.php:37`):
    ```php
        public function attributes(): array
    ```
  - **After:**
    ```php
        /**
         * Reject a parent that is the group itself or one of its own sub-groups
         * (a cycle would corrupt the materialised path/depth tree).
         */
        public function after(): array
        {
            return [
                function (Validator $validator): void {
                    $id = $this->route('account_group')?->id ?? $this->route('account_group');
                    $parentId = $this->input('parent_id');

                    if (! $id || ! $parentId) {
                        return;
                    }

                    if ((int) $parentId === (int) $id) {
                        $validator->errors()->add('parent_id', 'A group cannot be its own parent.');

                        return;
                    }

                    $candidate = AccountGroup::withTrashed()->find($parentId);

                    if ($candidate && str_contains((string) $candidate->path, '/' . $id . '/')) {
                        $validator->errors()->add('parent_id', 'A group cannot be moved under one of its own sub-groups.');
                    }
                },
            ];
        }

        public function attributes(): array
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Requests\AccountGroupRequest.php -Pattern "function after\(" | Measure-Object | Select-Object -ExpandProperty Count`
  - **Expect:** `1`
  - **Effort:** M

- [ ] **ACGR-08** · H · RTE-01 · `Modules/Accounting/routes/web.php:109` — register `restore` as POST, not GET. ⚠ SHARED (route file — needs its own tick).
  - **Touches:** `Modules/Accounting/routes/web.php`
  - **Before** (`Modules/Accounting/routes/web.php:109`):
    ```php
    Route::get('/account-group/{id}/restore', [AccountGroupController::class, 'restore'])->name('account-group.restore');
    ```
  - **After:**
    ```php
    Route::post('/account-group/{id}/restore', [AccountGroupController::class, 'restore'])->name('account-group.restore');
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\routes\web.php -Pattern "account-group/\{id\}/restore"`
  - **Expect:** one line, starting with `Route::post(`.
  - **Effort:** S

- [ ] **ACGR-09** · M · CTL-05 · `create.blade.php:108-111` and `edit.blade.php:110-113` — add the missing `Equity` option so the two page forms match the modal and the model's `natures()`.
  - **Touches:** `Modules/Accounting/resources/views/account-group/create.blade.php`, `Modules/Accounting/resources/views/account-group/edit.blade.php`
  - **Before** (`create.blade.php:108-111`):
    ```php
    <option value="Asset" {{ old('nature') == 'Asset' ? 'selected' : '' }}>Asset</option>
    <option value="Liability" {{ old('nature') == 'Liability' ? 'selected' : '' }}>Liability</option>
    <option value="Income" {{ old('nature') == 'Income' ? 'selected' : '' }}>Income</option>
    <option value="Expense" {{ old('nature') == 'Expense' ? 'selected' : '' }}>Expense</option>
    ```
  - **After:**
    ```php
    <option value="Asset" {{ old('nature') == 'Asset' ? 'selected' : '' }}>Asset</option>
    <option value="Liability" {{ old('nature') == 'Liability' ? 'selected' : '' }}>Liability</option>
    <option value="Equity" {{ old('nature') == 'Equity' ? 'selected' : '' }}>Equity</option>
    <option value="Income" {{ old('nature') == 'Income' ? 'selected' : '' }}>Income</option>
    <option value="Expense" {{ old('nature') == 'Expense' ? 'selected' : '' }}>Expense</option>
    ```
  - **Before** (`edit.blade.php:110-113`):
    ```php
    <option value="Asset" {{ old('nature', $accountGroup->nature) == 'Asset' ? 'selected' : '' }}>Asset</option>
    <option value="Liability" {{ old('nature', $accountGroup->nature) == 'Liability' ? 'selected' : '' }}>Liability</option>
    <option value="Income" {{ old('nature', $accountGroup->nature) == 'Income' ? 'selected' : '' }}>Income</option>
    <option value="Expense" {{ old('nature', $accountGroup->nature) == 'Expense' ? 'selected' : '' }}>Expense</option>
    ```
  - **After:**
    ```php
    <option value="Asset" {{ old('nature', $accountGroup->nature) == 'Asset' ? 'selected' : '' }}>Asset</option>
    <option value="Liability" {{ old('nature', $accountGroup->nature) == 'Liability' ? 'selected' : '' }}>Liability</option>
    <option value="Equity" {{ old('nature', $accountGroup->nature) == 'Equity' ? 'selected' : '' }}>Equity</option>
    <option value="Income" {{ old('nature', $accountGroup->nature) == 'Income' ? 'selected' : '' }}>Income</option>
    <option value="Expense" {{ old('nature', $accountGroup->nature) == 'Expense' ? 'selected' : '' }}>Expense</option>
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\resources\views\account-group\create.blade.php,Modules\Accounting\resources\views\account-group\edit.blade.php -Pattern "value=.Equity" | Measure-Object | Select-Object -ExpandProperty Count`
  - **Expect:** `2`
  - **Effort:** S

- [ ] **ACGR-12** · M · MDL-06 · `AccountGroup.php:42-44` — call `parent::booted()` so the inherited `updated_by` audit hook runs.
  - **Touches:** `Modules/Accounting/app/Models/AccountGroup.php`
  - **Before** (`AccountGroup.php:42-44`):
    ```php
        protected static function booted(): void
        {
            static::creating(function (AccountGroup $model) {
    ```
  - **After:**
    ```php
        protected static function booted(): void
        {
            parent::booted();

            static::creating(function (AccountGroup $model) {
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Models\AccountGroup.php -Pattern "parent::booted\(\);" | Measure-Object | Select-Object -ExpandProperty Count`
  - **Expect:** `1`
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **ACGR-14** · M · QRY-04 · `AccountGroup.php:157` — use `exists()` instead of `count()` in `isDeletable()`.
  - **Touches:** `Modules/Accounting/app/Models/AccountGroup.php`
  - **Before** (`AccountGroup.php:155-158`):
    ```php
        public function isDeletable(): bool
        {
            return ! $this->is_system && ! $this->is_subledger && $this->ledgers()->count() === 0;
        }
    ```
  - **After:**
    ```php
        public function isDeletable(): bool
        {
            return ! $this->is_system && ! $this->is_subledger && ! $this->ledgers()->exists();
        }
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Models\AccountGroup.php -Pattern "ledgers\(\)->count" | Measure-Object | Select-Object -ExpandProperty Count`
  - **Expect:** `0`
  - **Effort:** S

## 7. Views (F10)

## 8. Style (F12) — one item per file

- [ ] **ACGR-10** · L · CTL-04 · `AccountGroupController.php` — add return types to the 12 public methods and the imports they need.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AccountGroupController.php`
  - **Before** (`AccountGroupController.php:7-12`, after ACGR-01):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Accounting\Http\Requests\AccountGroupRequest;
    use Modules\Accounting\Models\AccountGroup;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\Accounting\Http\Requests\AccountGroupRequest;
    use Modules\Accounting\Models\AccountGroup;
    ```
  - **Before** (`AccountGroupController.php:17,24,33,66,75,88,122,170,179,207,236,264`):
    ```php
        public function index()
        public function create()
        public function store(AccountGroupRequest $request)
        public function show(AccountGroup $accountGroup)
        public function edit(AccountGroup $accountGroup)
        public function update(AccountGroupRequest $request, AccountGroup $accountGroup)
        public function destroy(AccountGroup $accountGroup)
        public function trashed()
        public function restore($id)
        public function forceDelete($id)
        public function toggleStatus(Request $request, AccountGroup $accountGroup)
        public function toggleSystem(Request $request, AccountGroup $accountGroup)
    ```
  - **After:**
    ```php
        public function index(): RedirectResponse
        public function create(): View
        public function store(AccountGroupRequest $request): RedirectResponse
        public function show(AccountGroup $accountGroup): View
        public function edit(AccountGroup $accountGroup): View|RedirectResponse
        public function update(AccountGroupRequest $request, AccountGroup $accountGroup): RedirectResponse
        public function destroy(AccountGroup $accountGroup): RedirectResponse
        public function trashed(): View
        public function restore($id): RedirectResponse
        public function forceDelete($id): RedirectResponse
        public function toggleStatus(Request $request, AccountGroup $accountGroup): JsonResponse
        public function toggleSystem(Request $request, AccountGroup $accountGroup): JsonResponse
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\AccountGroupController.php -Pattern "public function" | Select-String -NotMatch "\):" | Measure-Object | Select-Object -ExpandProperty Count`
  - **Expect:** `0`
  - **Effort:** M

- [ ] **ACGR-16** · L · STY-02 · `AccountGroupController.php` — run Pint on the file.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AccountGroupController.php`
  - **Before** (`AccountGroupController.php`, current style):
    ```php
    $validated['created_by'] = auth()->id();
    ```
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\AccountGroupController.php --format agent` (no manual edit).
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\AccountGroupController.php --format agent`
  - **Expect:** `"result":"pass"` and an empty `files` array.
  - **Effort:** S

- [ ] **ACGR-17** · L · STY-02 · `AccountGroup.php` — run Pint on the file (also removes the unused `App\Models\BaseModel` import).
  - **Touches:** `Modules/Accounting/app/Models/AccountGroup.php`
  - **Before** (`AccountGroup.php:7`):
    ```php
    use App\Models\BaseModel;
    ```
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Models\AccountGroup.php --format agent` (the unused import is removed by the `no_unused_imports` fixer).
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Models\AccountGroup.php --format agent`
  - **Expect:** `"result":"pass"` and an empty `files` array.
  - **Effort:** S

- [ ] **ACGR-18** · L · STY-02 · `AccountGroupRequest.php` — run Pint on the file.
  - **Touches:** `Modules/Accounting/app/Http/Requests/AccountGroupRequest.php`
  - **Before** (`AccountGroupRequest.php:7-9`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Validation\Rule;
    ```
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Requests\AccountGroupRequest.php --format agent` (imports are reordered automatically).
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Requests\AccountGroupRequest.php --format agent`
  - **Expect:** `"result":"pass"` and an empty `files` array.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **ACGR-15** · M · DECISION · QRY-01 — rewrite `AccountGroup::recalculateChildrenTree()` to avoid one query/write per descendant node?
  - **Why it is a decision:** a correct bulk rewrite must recompute both `depth` and the materialised `path` of every descendant; doing it wrong corrupts the tree. Current tree is 51 rows.
  - (a) ⭐ defer to a dedicated tree-service pass; keep the recursive method for now
  - (b) rewrite in `path`-prefix `chunkById` batches inside one transaction (needs a correctness review)
  - (c) leave as is, record as accepted (small trees only)
  - ➜ Choice: ____

- [ ] **ACGR-19** · M · DECISION · SVC-04 — should `toggleSystem` be allowed to change `is_system` when the same controller refuses to edit/update/delete a system group?
  - **Why it is a decision:** it is a behaviour/product question; the code does not state which is intended. The current guard trio (`edit`/`update`/`destroy`) can be switched off by `toggleSystem`.
  - (a) ⭐ keep the toggle as an explicit admin override and document it
  - (b) block `toggleSystem` when the group is already `is_system` (mirror the other three guards)
  - (c) move `toggleSystem` behind a separate permission key (new key = decision + seed)
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| ACGR-11 | `index.blade.php` is unused. Deletion is a cleanup, not a behaviour fix; left for Tarun to delete or annotate. |
| ACGR-13 | Casting `nature` to a PHP enum needs a new enum class (a decision); recorded for a model-hardening pass. |

Tick items in `02-fix-plan.md`, then run `final-audit-fixer` on this controller path for developer `gaurav`.
