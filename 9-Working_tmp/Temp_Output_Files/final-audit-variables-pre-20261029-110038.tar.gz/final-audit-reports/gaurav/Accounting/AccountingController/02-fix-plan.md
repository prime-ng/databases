# Fix Plan — Accounting / AccountingController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/AccountingController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | shared tenant route file — no item here changes routes |
| `Modules/Accounting/routes/api.php` | shared API route file — the former `apiResource` was already removed; its comment stays |
| `config/permissionslist.php` | shared permission registry — no new key is introduced |

## 1. Blockers reachable today

No items. The controller has 0 routes, so no blocker is reachable by a user.

## 2. Fixes that arm a latent defect (sequenced)

No items.

## 3. Errors & transactions (F1/F2)

No items. The controller has no error handling and no write path.

## 4. Authorization (F3)

No items. There is no routed method, so no Gate applies.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **ACCT-01** · M · RTE-03 · `Modules/Accounting/app/Http/Controllers/AccountingController.php:1-33` — retire the five unrouted stubs per D5 so they abort instead of returning an empty 200.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AccountingController.php`
  - **Before** (`AccountingController.php:1-33`):
    ```php
    <?php

    namespace Modules\Accounting\Http\Controllers;

    use App\Http\Controllers\Controller;

    class AccountingController extends Controller
    {
        public function index()
        {
            return response()->json([]);
        }

        public function store()
        {
            return response()->json([]);
        }

        public function show($id)
        {
            return response()->json([]);
        }

        public function update($id)
        {
            return response()->json([]);
        }

        public function destroy($id)
        {
            return response()->json([]);
        }
    }
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Accounting\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;

    class AccountingController extends Controller
    {
        public function index(): JsonResponse
        {
            // NOT ROUTED - kept per D5; no route points at this method.
            abort(403, 'This endpoint is not routed.');
        }

        public function store(): JsonResponse
        {
            // NOT ROUTED - kept per D5; no route points at this method.
            abort(403, 'This endpoint is not routed.');
        }

        public function show($id): JsonResponse
        {
            // NOT ROUTED - kept per D5; no route points at this method.
            abort(403, 'This endpoint is not routed.');
        }

        public function update($id): JsonResponse
        {
            // NOT ROUTED - kept per D5; no route points at this method.
            abort(403, 'This endpoint is not routed.');
        }

        public function destroy($id): JsonResponse
        {
            // NOT ROUTED - kept per D5; no route points at this method.
            abort(403, 'This endpoint is not routed.');
        }
    }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\AccountingController.php" -Pattern "NOT ROUTED" | Measure-Object | Select-Object -ExpandProperty Count`
  - **Expect:** `5`
  - **Effort:** S

## 6. Queries & performance (F9)

No items. The controller executes no query.

## 7. Views (F10)

No items. The controller renders no view.

## 8. Style (F12) — one item per file

No separate item. The file's style defects (ACCT-03) and return types (ACCT-02) are folded into the ACCT-01 rewrite, because all three changes touch the same 33 lines and separate Before blocks would collide after the first edit.

## 9. Deferred / decisions

None. This plan has no DECISION items.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| ACCT-02 | Folded into ACCT-01 — the After block adds `: JsonResponse` to all five methods and imports `Illuminate\Http\JsonResponse`. |
| ACCT-03 | Folded into ACCT-01 — the After block adds `declare(strict_types=1);` at the top of the same file. |
