# Final Audit - Accounting / AccountingStatusMasterController

**Audited:** 2026-10-19 | **By:** opencode | **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` (85 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` | **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/accounting-status-master` - `index()` only; it returns a redirect. Every other URL in section 4 returns `403` from the method body. |
| Menu path | Accounting -> Setup & Masters (`glb_menus` id `86`, route `accounting.menu.setupMasters`, permission `tenant.accounting.dashboard.view`). There is **no** Status Masters menu item and **no** Status Masters tab. |
| Who uses it | Super Admin and School Admin hold `tenant.accounting.dashboard.view` (2 rows in `sys_role_has_permissions_jnt`; 312 accounting permissions each). The feature's own permission namespace has 0 rows. |
| What a user does here | Nothing. The feature was retired in Accounting DDL v4.6: every action aborts `403`, and the only live behaviour is `index()`, which redirects to Setup & Masters. No record can be listed, created, edited or deleted. |
| Tables written | None. Every mutating method aborts before any query; the controller contains no `DB::`, `save`, `update`, `delete` or `activityLog` call. |
| Tables read | None by this controller. The redirect target (`AccDashboardController@setupMasters`) reads the Setup & Masters tables. |
| Live data | `acc_accounting_status_masters` does not exist in the live tenant DB `xyz_school_00000000000040008000_202627` (`information_schema` count `0`; `SELECT * FROM acc_accounting_status_masters WHERE 1 = 0` returns `ERROR 1146`). The 3 tables matching `%status_master%` belong to Admission, Hostel and Library, not Accounting. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Production-safe as a retired tombstone, but not clean: there are no B/H blockers, and every data-touching action is a hard `403`. The single worst finding is `ACSM-01` (M): the one live action, `index()`, redirects to `tab=status-masters`, a tab that no longer exists on the Setup & Masters page, so a bookmarked or breadcrumb "Status Masters" link silently opens Account Groups; the class docblock says it "renders fine", which is false. The rest is dead-surface debt: a model over a dropped table with a read-masking `newQuery()`, an orphaned 222-line partial and four unreachable blades, a dead FormRequest/Policy/Seeder, missing return types, and three Pint failures. Rough effort: **S**, under an hour - one redirect line, eleven return types, and a delete-or-keep decision.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 1 | 4 | 1 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | clean |
| F3 Authorization | clean (see section 6 F3) | F10 Views | clean (dead blades covered by ACSM-02) |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | ACSM-05 |
| F6 Controller shape | ACSM-02, ACSM-04 | F13 Deep read | ACSM-01 |
| F7 Models | ACSM-03 | | |

Counts add up: F6(2) + F7(1) + F12(1) + F13(1) = 5.

## 3. Scope - every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` | controller | 85 | this report | yes |
| 2 | `Modules/Accounting/app/Models/AccountingStatusMaster.php` | model | 58 | this report (registry pre-assigned 2026-10-19) | yes |
| 3 | `Modules/Accounting/app/Http/Requests/AccountingStatusMasterRequest.php` | FormRequest | 58 | this report (registry pre-assigned 2026-10-19) | yes |
| 4 | `Modules/Accounting/app/Policies/AccountingStatusMasterPolicy.php` | policy | 98 | this report (not in registry; auto-discovered by Gate) | yes |
| 5 | `Modules/Accounting/resources/views/accounting-status-master/create.blade.php` | view | 78 | this report | yes, unreachable |
| 6 | `Modules/Accounting/resources/views/accounting-status-master/edit.blade.php` | view | 110 | this report | yes, unreachable |
| 7 | `Modules/Accounting/resources/views/accounting-status-master/show.blade.php` | view | 98 | this report | yes, unreachable |
| 8 | `Modules/Accounting/resources/views/accounting-status-master/trash.blade.php` | view | 80 | this report | yes, unreachable |
| 9 | `Modules/Accounting/resources/views/pages/partials/setup-masters/_status-masters.blade.php` | view partial | 222 | this report (orphaned; would belong to `AccDashboardController@setupMasters` if wired) | yes, unreachable |
| 10 | `Modules/Accounting/database/seeders/AccountingStatusMasterSeeder.php` | seeder | 18 | this report | yes |
| 11 | `Modules/Accounting/routes/web.php` (lines 410-415) | route file | 534 | shared, read-only | linked |
| 12 | `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` (redirect target) | controller | 2569 | other report | linked |
| 13 | `app/Services/Breadcrumbs/registry.php` (lines 152-156) | app-wide registry | 4007 | common, read-only | linked |

No pre-applied files.

## 4. Routes

Uncached `route:list`, filtered through the route probe:

```
GET|HEAD  accounting/accounting-status-master                     accounting.accounting-status-master.index Modules\Accounting\Http\Controllers\AccountingStatusMasterController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/accounting-status-master                     accounting.accounting-status-master.store Modules\Accounting\Http\Controllers\AccountingStatusMasterController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/accounting-status-master/create              accounting.accounting-status-master.create Modules\Accounting\Http\Controllers\AccountingStatusMasterController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/accounting-status-master/trash/view          accounting.accounting-status-master.trashed Modules\Accounting\Http\Controllers\AccountingStatusMasterController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/accounting-status-master/{accounting_status_master} accounting.accounting-status-master.show Modules\Accounting\Http\Controllers\AccountingStatusMasterController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/accounting-status-master/{accounting_status_master} accounting.accounting-status-master.update Modules\Accounting\Http\Controllers\AccountingStatusMasterController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/accounting-status-master/{accounting_status_master} accounting.accounting-status-master.destroy Modules\Accounting\Http\Controllers\AccountingStatusMasterController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/accounting-status-master/{accounting_status_master}/edit accounting.accounting-status-master.edit Modules\Accounting\Http\Controllers\AccountingStatusMasterController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/accounting-status-master/{accounting_status_master}/toggle-status accounting.accounting-status-master.toggleStatus Modules\Accounting\Http\Controllers\AccountingStatusMasterController@toggleStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/accounting-status-master/{id}/force-delete   accounting.accounting-status-master.forceDelete Modules\Accounting\Http\Controllers\AccountingStatusMasterController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/accounting-status-master/{id}/restore        accounting.accounting-status-master.restore Modules\Accounting\Http\Controllers\AccountingStatusMasterController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none. All 11 public methods resolve to a route.

Route notes: the resource is registered at `Modules/Accounting/routes/web.php:411`; the four custom routes follow it at `412-415`. No collision occurs because `trash/view` is two segments and the resource `show` pattern is one segment. `restore` is a `GET` route but its body only aborts `403`, so it cannot change state (RTE-01 is not triggered). The route parameter is `{id}` on `restore`/`forceDelete` and `{accounting_status_master}` on the resource; both are ignored by the controller, so no binding is attempted.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 31 | GET `/accounting/accounting-status-master` | none in this method; destination checks `tenant.accounting.dashboard.view` (`AccDashboardController.php:83`) | none | none | none | ACSM-01, ACSM-04 |
| `create` | 36 | GET `/accounting/accounting-status-master/create` | none - unconditional `abort(403)` | none | none | none | ACSM-04 |
| `store` | 41 | POST `/accounting/accounting-status-master` | none - unconditional `abort(403)` | none | none | none | ACSM-04 |
| `show` | 46 | GET `/accounting/accounting-status-master/{accounting_status_master}` | none - unconditional `abort(403)` | none | none | none | ACSM-04 |
| `edit` | 51 | GET `/accounting/accounting-status-master/{accounting_status_master}/edit` | none - unconditional `abort(403)` | none | none | none | ACSM-04 |
| `update` | 56 | PUT/PATCH `/accounting/accounting-status-master/{accounting_status_master}` | none - unconditional `abort(403)` | none | none | none | ACSM-04 |
| `destroy` | 61 | DELETE `/accounting/accounting-status-master/{accounting_status_master}` | none - unconditional `abort(403)` | none | none | none | ACSM-04 |
| `toggleStatus` | 66 | POST `/accounting/accounting-status-master/{accounting_status_master}/toggle-status` | none - unconditional `abort(403)` | none | none | none | ACSM-04 |
| `trashed` | 71 | GET `/accounting/accounting-status-master/trash/view` | none - unconditional `abort(403)` | none | none | none | ACSM-04 |
| `restore` | 76 | GET `/accounting/accounting-status-master/{id}/restore` | none - unconditional `abort(403)` | none | none | none | ACSM-04 |
| `forceDelete` | 81 | DELETE `/accounting/accounting-status-master/{id}/force-delete` | none - unconditional `abort(403)` | none | none | none | ACSM-04 |

## 6. Findings

### F1 - Errors

clean - `grep -n "try\|catch\|getMessage" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` -> no output (`EXIT=1`). There is no catch to swallow a 404/403/422.

### F2 - Transactions and audit

clean - `grep -n "DB::\|transaction\|activityLog\|->save(\|->update(\|->delete(" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` -> no output (`EXIT=1`). There is no write to wrap and no audit event to place.

### F3 - Authorization

clean for every live path. `grep -n "Gate\|authorize" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` -> no output: the 10 non-index methods deny with `abort(403)` before loading anything, and `index()` redirects to `AccDashboardController@setupMasters`, which calls `Gate::authorize('tenant.accounting.dashboard.view')` at `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:83`.

Latent note, recorded under ACSM-02 rather than as a live hole: the dead FormRequest and Policy name `tenant.accounting.accounting-status-master.*`, which is absent from `config/permissionslist.php` and from the live tenant `sys_permissions` (exact-name count `0`). Nothing routed reaches those strings today.

### F4 - Validation and input

clean - `grep -n "request->\|validate(\|validated(\|fill(\|create(" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` -> no output (`EXIT=1`). No input is read and no model is written. The unused `Request $request` parameters are covered by ACSM-02.

### F5 - Routes

clean - the route probe above resolves all 11 actions; `grep -n "accounting-status-master" Modules/Accounting/routes/web.php` returns lines `411-415`; every row carries the tenant stack (`PreventAccessFromCentralDomains`, `InitializeTenancyByDomain`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Accounting`, `Authenticate`, `EnsureEmailIsVerified`). `restore` is `GET` but aborts, so RTE-01 is not triggered. The custom routes follow `Route::resource` (RTE-06 shape), but no collision exists: `trash/view` is two segments, the resource `show` is one.

### F6 - Controller shape

#### ACSM-02 - L - CTL-10 - the retired surface is still present as 600+ lines of unreachable code

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) - *no dead code: unused private methods, unused properties, commented-out blocks longer than 3 lines*. Severity lowered to **L**: the retirement is deliberate (D3/D5), every action denies, and no live path reaches any of these files. |
| **Where** | `Modules/Accounting/app/Http/Requests/AccountingStatusMasterRequest.php:12-26`; `Modules/Accounting/app/Policies/AccountingStatusMasterPolicy.php:22,36`; the four blades under `Modules/Accounting/resources/views/accounting-status-master/`; `Modules/Accounting/resources/views/pages/partials/setup-masters/_status-masters.blade.php`; `Modules/Accounting/database/seeders/AccountingStatusMasterSeeder.php`; unused imports at `AccDashboardController.php:11` and `BankReconciliationController.php:14`. |
| **Root cause** | The retirement was done by aborting every action and leaving the surface in place. The views, partial, FormRequest, Policy and Seeder were not removed, the partial was dropped from `setup-masters.blade.php` without deleting it, and the permission namespace those files name was never added to `config/permissionslist.php` or seeded. The FormRequest computes `$id` at lines 23-26 and never uses it; it also imports `Illuminate\Validation\Rule` at line 9 without using it. |
| **Consequence** | About 600 lines look live but cannot be reached. The partial is not included anywhere; the FormRequest is not referenced by any controller; the Policy is only consulted by the unreachable `show.blade.php:25`; the Seeder seeds nothing. A future developer can waste a day "repairing" a feature that is intentionally gone, and the undeclared permission strings would deny every gate if the feature were switched back on. |
| **Reproduce** | Static only: every action returns `403`; `grep -rn "AccountingStatusMasterRequest" Modules app routes config --include=*.php` returns only its own class line; `grep -n "@include" Modules/Accounting/resources/views/pages/setup-masters.blade.php` lists 7 includes, none `_status-masters`; `grep -rn "_status-masters" Modules app resources --include=*.blade.php` returns only Admission's own partial. |
| **Fix approach** | Choose keep-and-accept (D3/D5) or delete the dead surface (plan section 9). Deleting it also removes the undeclared permission namespace; keeping it requires only the ACSM-01, ACSM-04 and ACSM-05 fixes. |
| **Plan item** | ACSM-02 in `02-fix-plan.md` section 9 (DECISION); ACSM-03 is covered by the same decision. |

```php
// AccountingStatusMasterRequest.php:12-26 - CURRENT (never referenced by a controller)
class AccountingStatusMasterRequest extends FormRequest
{
    use AuthorizesTenantFeature;

    public function authorize(): bool
    {
        return $this->authorizeByCrudPermission('tenant.accounting.accounting-status-master');
    }

    public function rules(): array
    {
        $id = $this->route('accounting_status_master');
        if ($id instanceof AccountingStatusMaster) {
            $id = $id->id;
        }
```

**Evidence**
```
$ grep -rn "AccountingStatusMasterRequest" Modules app routes config --include=*.php
Modules/Accounting/app/Http/Requests/AccountingStatusMasterRequest.php:12:class AccountingStatusMasterRequest extends FormRequest

$ grep -n "@include" Modules/Accounting/resources/views/pages/setup-masters.blade.php
19:  @include('accounting::pages.partials.setup-masters._account-groups')
23:  @include('accounting::pages.partials.setup-masters._ledgers')
27:  @include('accounting::pages.partials.setup-masters._cost-categories')
31:  @include('accounting::pages.partials.setup-masters._cost-centers')
35:  @include('accounting::pages.partials.setup-masters._funds')
39:  @include('accounting::pages.partials.setup-masters._campuses')
43:  @include('accounting::pages.partials.setup-masters._bill-references')

$ grep -rn "_status-masters" Modules app resources --include=*.blade.php
Modules/Admission/resources/views/pages/setup.blade.php:15: @include('admission::pages.partials.setup._status-masters')

$ mysql --host=localhost --user=root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_permissions WHERE name LIKE 'tenant.accounting.accounting-status-master%';"
0
$ mysql --host=localhost --user=root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_permissions WHERE name LIKE '%status-master%';"
20   (14 admission.adm-status-master.*, 6 library.lib-library-status-masters.*)
```

#### ACSM-04 - L - CTL-04 - no return types on any public method

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) - *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php:31,36,41,46,51,56,61,66,71,76,81` |
| **Root cause** | Every signature omits its return type. The class was rewritten to abort-only and the types were not added back. |
| **Consequence** | Editors and static tools cannot see the response type; the controller is inconsistent with the project's typed style. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `: RedirectResponse` to `index()` and `: never` to the ten abort-only methods (the project already uses `: never`, e.g. `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:177`). |
| **Plan item** | ACSM-04 in `02-fix-plan.md` section 8 |

```php
// AccountingStatusMasterController.php:31-84 - CURRENT signatures
    public function index()
    public function create()
    public function store(Request $request)
    public function show($id)
    public function edit($id)
    public function update(Request $request, $id)
    public function destroy($id)
    public function toggleStatus(Request $request, $id)
    public function trashed()
    public function restore($id)
    public function forceDelete($id)
```

**Evidence**
```
$ grep -c "public function" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php
11
$ grep -n "public function" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php
31:    public function index()
36:    public function create()
41:    public function store(Request $request)
46:    public function show($id)
51:    public function edit($id)
56:    public function update(Request $request, $id)
61:    public function destroy($id)
66:    public function toggleStatus(Request $request, $id)
71:    public function trashed()
76:    public function restore($id)
81:    public function forceDelete($id)
```

### F7 - Models

#### ACSM-03 - L - MDL-07 - the deprecated model points at a dropped table; `newQuery()` masks reads only

| Field | Value |
|---|---|
| **Rule** | MDL-07 (B) - *every model's `$table` exists in a migration; a model over a missing table 500s on first use*. Severity lowered to **L**: the table is deliberately dropped, the class is a tombstone, and no live caller exists. |
| **Where** | `Modules/Accounting/app/Models/AccountingStatusMaster.php:18,33-36`; drop migration `database/migrations/tenant/2026_09_16_090001_drop_legacy_accounting_tables.php:68`. |
| **Root cause** | `$table = 'acc_accounting_status_masters'` names a table that DDL v4.6 dropped. `newQuery()` adds `whereRaw('1 = 0')`, but that does not stop Eloquent emitting `FROM acc_accounting_status_masters`; the live DB rejects the statement with error 1146. `save()`/`create()` use `newModelQuery()`, which the override does not touch, so an INSERT would target the missing table. The class is kept "so existing code compiles"; its only importers are two controllers that never use it. |
| **Consequence** | Reads silently return an empty set instead of failing, which hides the breakage; any future write returns a 500. Today no user reaches it. |
| **Reproduce** | Static only - no live caller. The probe below prints the SQL Eloquent would send; the live DB has no such table. |
| **Fix approach** | Delete the model (part of the retired-surface decision) or keep it and record the tombstone as accepted. There is no safe column to add: the table is gone. |
| **Plan item** | ACSM-02 in `02-fix-plan.md` section 9 (same decision); see section 10 |

```php
// AccountingStatusMaster.php:18,33-36 - CURRENT
    protected $table = 'acc_accounting_status_masters';

    public function newQuery()
    {
        return parent::newQuery()->whereRaw('1 = 0');
    }
```

**Evidence**
```
$ php acsm_probe.php
newQuery:       select * from `acc_accounting_status_masters` where 1 = 0 and `acc_accounting_status_masters`.`deleted_at` is null
newModelQuery:  select * from `acc_accounting_status_masters`
POLICY: Modules\Accounting\Policies\AccountingStatusMasterPolicy

$ mysql --host=localhost --user=root -N -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='xyz_school_00000000000040008000_202627' AND table_name='acc_accounting_status_masters';"
0

$ grep -rn "AccountingStatusMaster" Modules/Accounting/app/Http/Controllers --include=*.php
Modules/Accounting/app/Http/Controllers/AccDashboardController.php:11:use Modules\Accounting\Models\AccountingStatusMaster;
Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php:27:class AccountingStatusMasterController extends Controller
Modules/Accounting/app/Http/Controllers/BankReconciliationController.php:14:use Modules\Accounting\Models\AccountingStatusMaster;
```

The two model `use` lines are the only references to the model class (the third hit is the controller's own class name); neither controller uses the class in its body. `Gate::getPolicyFor()` resolves `Modules\Accounting\Policies\AccountingStatusMasterPolicy` by Laravel auto-discovery, so the policy is not "unregistered" - it is simply only consulted by the unreachable `show.blade.php:25`.

### F8 - Services and jobs

clean - `grep -n "Service\|Job\|dispatch(\|->handle(" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` -> no output (`EXIT=1`).

### F9 - Queries and performance

clean - `grep -n "::where\|::find\|::all\|->get(\|->paginate(\|->count(\|->first(" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` -> no output (`EXIT=1`). The model's `whereRaw('1 = 0')` is a constant, not interpolated SQL, so QRY-11 is not triggered.

### F10 - Views

clean - `grep -n "view(" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` -> no output (`EXIT=1`); the controller renders nothing. The four blades and the 222-line partial are unreachable and are covered by ACSM-02. For the record, the partial is not included by `setup-masters.blade.php` (7 includes, none `_status-masters`), and the four blades link back to the removed `tab=status-masters` (`create.blade.php:68`, `edit.blade.php:20,98`, `show.blade.php:22`, `trash.blade.php:16,51`).

### F11 - Security and tenancy

clean - `grep -n "env(\|config(\|Log::\|password\|token\|secret\|?? 1" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` -> no output (`EXIT=1`). All 11 routes sit inside the tenant middleware stack (route probe above); there is no input, no file and no cross-tenant model access.

### F12 - Style

#### ACSM-05 - L - STY-02 - Pint fails on the model, FormRequest and Policy (the controller passes)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) - *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines between imports* |
| **Where** | `Modules/Accounting/app/Models/AccountingStatusMaster.php:7` (unused `App\Models\BaseModel` import; file ends with an extra blank line); `Modules/Accounting/app/Http/Requests/AccountingStatusMasterRequest.php:7-10` (unused `Illuminate\Validation\Rule`; import order; `=>` alignment); `Modules/Accounting/app/Policies/AccountingStatusMasterPolicy.php:7-8` (import order). |
| **Root cause** | The three files were not Pint-clean before retirement and were left untouched. |
| **Consequence** | Pint/CI noise; the unused `Rule` and `BaseModel` imports make readers think the classes are used. |
| **Reproduce** | `.\vendor\bin\pint.bat --test Modules/Accounting/app/Models/AccountingStatusMaster.php Modules/Accounting/app/Http/Requests/AccountingStatusMasterRequest.php Modules/Accounting/app/Policies/AccountingStatusMasterPolicy.php --format=json` |
| **Fix approach** | Run Pint on the three files (plan section 8, one item). If the deletion decision (ACSM-02) is chosen, this item becomes superseded. |
| **Plan item** | ACSM-05 in `02-fix-plan.md` section 8 |

```php
// AccountingStatusMaster.php:7-8 - CURRENT
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;

// AccountingStatusMasterRequest.php:7-10 - CURRENT
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Validation\Rule;
use Modules\Accounting\Models\AccountingStatusMaster;

// AccountingStatusMasterPolicy.php:7-8 - CURRENT
use Modules\SchoolSetup\Models\User;
use Modules\Accounting\Models\AccountingStatusMaster;
```

**Evidence**
```
$ .\vendor\bin\pint.bat --test Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php --format=json
{"tool":"pint","result":"passed"}

$ .\vendor\bin\pint.bat --test Modules/Accounting/app/Models/AccountingStatusMaster.php Modules/Accounting/app/Http/Requests/AccountingStatusMasterRequest.php Modules/Accounting/app/Policies/AccountingStatusMasterPolicy.php --format=json
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\AccountingStatusMaster.php","fixers":["no_unused_imports","single_blank_line_at_eof"]},{"path":"Modules\\Accounting\\app\\Http\\Requests\\AccountingStatusMasterRequest.php","fixers":["no_unused_imports","ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Policies\\AccountingStatusMasterPolicy.php","fixers":["ordered_imports"]}]}
```

### F13 - Deep read

There is no mutating method: all ten non-index bodies are `abort(403)` before any query, and `index()` only redirects. The eight-question table therefore has no mutating rows. Questions **#7 (messages that lie)** and **#8 (dead features)** are answered for the only live path below.

#### ACSM-01 - M - CTL-10 - `index()` sends "Status Masters" to a tab that no longer exists, and the docblock says it works

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) - *no dead code*; the finding is the deep-read checklist #7 (a message that lies) and #8 (a dead feature). Severity kept at **M**: the URL is reachable and silently shows a different screen. |
| **Where** | `Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php:24-25,31-34`, method `index()`; `Modules/Accounting/resources/views/pages/setup-masters.blade.php:8-16`; `resources/views/components/backend/tab/nav-tab.blade.php:75-80`; `app/Services/Breadcrumbs/registry.php:152-156`. |
| **Root cause** | When the Status Masters tab and partial were removed from `setup-masters.blade.php`, the redirect kept `['tab' => 'status-masters']`. `nav-tab` only honours `?tab=` when it names a real tab in the strip; otherwise it falls back to the first permitted tab (`account-groups`, lines 78-80). `AccDashboardController@setupMasters` accepts any tab not in its `$configTabs` list and renders the page, so no error is raised. The docblock claim that the tab "renders fine because AccDashboardController feeds it an empty paginator" describes a tab that no longer exists. |
| **Consequence** | A bookmarked or breadcrumb "Status Masters" link opens Setup & Masters on Account Groups (the tab button and pane are switched by the component's inline script), with no message. With JavaScript disabled the server-rendered first tab still shows Account Groups because of the component's `noscript` rule; either way the user never sees Status Masters or an error. |
| **Reproduce** | Log in as School Admin (holds `tenant.accounting.dashboard.view`), open `http://test.localhost:8000/accounting/accounting-status-master`. The browser lands on `/accounting/setup-masters?tab=status-masters`; the strip has 7 tabs and none is Status Masters; Account Groups is active and its pane is shown. |
| **Fix approach** | Drop the dead `tab` argument so the destination uses its own default, and correct the docblock (plan section 5). The breadcrumb registry entry is a cross-cutting note (do not edit here). |
| **Plan item** | ACSM-01 in `02-fix-plan.md` section 5 |

```php
// AccountingStatusMasterController.php:24-25,31-34 - CURRENT
 * `index()` is the one exception: it redirects to the Setup Masters tab, which renders
 * fine because AccDashboardController feeds it an empty paginator.
 */
class AccountingStatusMasterController extends Controller
{
    private const GONE = 'Status Masters were removed in Accounting DDL v4.6. Each entity now has its own status.';

    public function index()
    {
        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'status-masters']);
    }
```

**Evidence**
```
$ grep -n "status-masters" Modules/Accounting/resources/views/pages/setup-masters.blade.php
(no output)

$ grep -n "request('tab'" resources/views/components/backend/tab/nav-tab.blade.php
76:    $requestedTab = request('tab');
78:    $resolvedActive = in_array($requestedTab, $tabIds, true)
79:        ? $requestedTab
80:        : (in_array($active, $tabIds, true) ? $active : ($tabIds[0] ?? null));

$ grep -n "accounting.accounting-status-master.index" -A 4 app/Services/Breadcrumbs/registry.php
152:    'accounting.accounting-status-master.index' => [
153:        'title' => 'Status Masters',
154:        'parent' => 'accounting.menu.setupMasters',
155:        'tab' => 'status-masters',
156:    ],

$ grep -n "Gate::authorize" Modules/Accounting/app/Http/Controllers/AccDashboardController.php
71:        Gate::authorize('tenant.accounting.dashboard.viewAny');
83:        Gate::authorize('tenant.accounting.dashboard.view');
379:        Gate::authorize('tenant.accounting.dashboard.view');
680:        Gate::authorize('tenant.accounting.dashboard.view');
882:        Gate::authorize('tenant.accounting.dashboard.view');
1173:        Gate::authorize('tenant.accounting.dashboard.view');
1343:        Gate::authorize('tenant.accounting.dashboard.view');
1520:        Gate::authorize('tenant.accounting.dashboard.view');
2056:        Gate::authorize('tenant.accounting.dashboard.view');
2093:        Gate::authorize('tenant.accounting.dashboard.view');
2440:        Gate::authorize('tenant.accounting.dashboard.view');
2554:        Gate::authorize('tenant.accounting.dashboard.view');
```

## 7. Cross-cutting notes (common or other-module classes - not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `app/Services/Breadcrumbs/registry.php:152-156` | The "Status Masters" breadcrumb still points at `accounting.accounting-status-master.index` with `tab => 'status-masters'`; the tab no longer exists and the route just redirects. | STY-04 / dead feature | App-wide breadcrumb owner (not this report) |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:11,347-348,368-369` | Imports `AccountingStatusMaster` without using it, and builds/passes `$statusMasters`/`$statusTypes` that `setup-masters.blade.php` never reads (the partial that would read them is not included). | CTL-10 | `AccDashboardController` report |
| `Modules/Accounting/app/Http/Controllers/BankReconciliationController.php:14` | Imports `AccountingStatusMaster` without using it. | CTL-10 | `BankReconciliationController` report |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_status-masters.blade.php` | 222-line orphaned partial. It names the undeclared `tenant.accounting.accounting-status-master.*` permissions and posts to a `store` route that always returns 403; it is not included by any view. | CTL-10 / VIEW | Delete with the retired surface, or wire it only if the feature is reactivated |
| `config/permissionslist.php` | No `accounting.accounting-status-master` key. Adding one is a shared-file change that also needs `/system-config/sync-permissions`; not proposed while the surface is retired. | AUTH-06 | Tarun's hand, only if the feature is reactivated |

## 8. Not covered, and why

- **Scanner and self-check skipped.** `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are missing in this checkout, and `_tools/scan.php` must not be run (tooling override for this session). F1-F13 were therefore done manually, with the commands quoted in each family.
- **No rendered views.** Every controller action is a 403 or a redirect, so the four blades and the partial were read statically; no HTML was exercised in a browser. The `_status-masters` partial has no include, so it cannot be reached even by URL.
- **No request execution.** The FormRequest is not referenced by any controller, so its rules were read, not executed. The request's `$id` block (lines 23-26) is computed and discarded.
- **No write path executed.** The model's table is gone; running `create()` would return error 1146. The probe generated the SQL only (`toSql()`), without sending a write.
- **No tests (D4).** No Pest/PHPUnit/Dusk run; verification is static plus the route probe, `php -l` and Pint.
- **Policy resolution was checked, not exercised.** `Gate::getPolicyFor(AccountingStatusMaster::class)` resolves the policy by auto-discovery; no live ability call exists because the only `@can` on it is in the unreachable `show.blade.php:25`.
