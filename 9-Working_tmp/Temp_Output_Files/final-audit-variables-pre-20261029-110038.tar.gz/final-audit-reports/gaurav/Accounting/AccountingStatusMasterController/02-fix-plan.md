# Fix Plan — Accounting / AccountingStatusMasterController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | Shared route file. D3 keeps the existing routes and route names. |
| `config/permissionslist.php` | Shared. No new key while the surface is retired; a new key also needs seeding (`/system-config/sync-permissions`). |
| `resources/views/components/backend/tab/nav-tab.blade.php` | Shared component. Its fallback to the first permitted tab is by design; the bug is the redirect, not the component. |
| `app/Services/Breadcrumbs/registry.php` | App-wide registry. The stale Status Masters entry is a cross-cutting note (report §7). |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | Owned by another report. Read only here. |
| `Modules/Accounting/app/Http/Controllers/BankReconciliationController.php` | Owned by another report. Read only here. |
| `Modules/Accounting/resources/views/pages/setup-masters.blade.php` | Owned by the `AccDashboardController` report. Do not re-add the Status Masters tab. |
| `database/migrations/tenant/*` | Never edit an existing migration. The drop in `2026_09_16_090001_drop_legacy_accounting_tables.php:68` is correct. |

## 1. Blockers reachable today

None. There is no B- or H-severity finding. The only reachable defect is `ACSM-01` (M), in §5.

## 2. Fixes that arm a latent defect (sequenced)

None. If the `ACSM-02` DECISION chooses deletion (option b), the Pint item in §8 becomes superseded: the fixer re-measures and records it as superseded, not applied.

## 3. Errors & transactions (F1/F2)

None. F1 and F2 are clean (report §6).

## 4. Authorization (F3)

None. Every live path is either a hard `403` or a redirect to a page that calls `Gate::authorize('tenant.accounting.dashboard.view')` (`AccDashboardController.php:83`).

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **ACSM-01** · M · CTL-10 · `Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php:24-25,33` — stop redirecting to the removed `status-masters` tab and correct the docblock.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php`
  - **Before — docblock** (`AccountingStatusMasterController.php:24-25`):
    ```php
     * `index()` is the one exception: it redirects to the Setup Masters tab, which renders
     * fine because AccDashboardController feeds it an empty paginator.
    ```
  - **After — docblock:**
    ```php
     * `index()` is the one exception: it redirects to Setup & Masters. There is no
     * `status-masters` tab there any more, so it must not request one.
    ```
  - **Before — redirect** (`AccountingStatusMasterController.php:33`):
    ```php
            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'status-masters']);
    ```
  - **After — redirect:**
    ```php
            return redirect()->route('accounting.menu.setupMasters');
    ```
  - **Verify:** `grep -n "status-masters\|empty paginator" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

None. F9 is clean (report §6).

## 7. Views (F10)

None. The controller renders no view. The four unreachable blades and the orphaned 222-line partial are handled by the `ACSM-02` DECISION in §9.

## 8. Style (F12) — one item per file

- [ ] **ACSM-04** · L · CTL-04 · `Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php:7-8,31,36,41,46,51,56,61,66,71,76,81` — add return types to all 11 public methods.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php`
  - **Before — imports** (`AccountingStatusMasterController.php:7-8`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    ```
  - **After — imports:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    ```
  - **Before/After — signatures** (`AccountingStatusMasterController.php:31,36,41,46,51,56,61,66,71,76,81`):
    - `public function index()` → `public function index(): RedirectResponse`
    - `public function create()` → `public function create(): never`
    - `public function store(Request $request)` → `public function store(Request $request): never`
    - `public function show($id)` → `public function show($id): never`
    - `public function edit($id)` → `public function edit($id): never`
    - `public function update(Request $request, $id)` → `public function update(Request $request, $id): never`
    - `public function destroy($id)` → `public function destroy($id): never`
    - `public function toggleStatus(Request $request, $id)` → `public function toggleStatus(Request $request, $id): never`
    - `public function trashed()` → `public function trashed(): never`
    - `public function restore($id)` → `public function restore($id): never`
    - `public function forceDelete($id)` → `public function forceDelete($id): never`
  - **Verify:** `grep -n "public function" Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php` then `php -l Modules/Accounting/app/Http/Controllers/AccountingStatusMasterController.php`
  - **Expect:** 11 signatures; `index` ends `: RedirectResponse`, the other 10 end `: never`; `No syntax errors detected`.
  - **Effort:** S

- [ ] **ACSM-05** · L · STY-02 · three files — make the in-scope model, FormRequest and Policy Pint-clean.
  - **Touches:** `Modules/Accounting/app/Models/AccountingStatusMaster.php`, `Modules/Accounting/app/Http/Requests/AccountingStatusMasterRequest.php`, `Modules/Accounting/app/Policies/AccountingStatusMasterPolicy.php`
  - **Before — model** (`AccountingStatusMaster.php:7-8`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **After — model:**
    ```php
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Before — FormRequest** (`AccountingStatusMasterRequest.php:7-10`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Validation\Rule;
    use Modules\Accounting\Models\AccountingStatusMaster;
    ```
  - **After — FormRequest:**
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Modules\Accounting\Models\AccountingStatusMaster;
    ```
  - **Before — Policy** (`AccountingStatusMasterPolicy.php:7-8`):
    ```php
    use Modules\SchoolSetup\Models\User;
    use Modules\Accounting\Models\AccountingStatusMaster;
    ```
  - **After — Policy:**
    ```php
    use Modules\Accounting\Models\AccountingStatusMaster;
    use Modules\SchoolSetup\Models\User;
    ```
  - **Apply:** `.\vendor\bin\pint.bat Modules/Accounting/app/Models/AccountingStatusMaster.php Modules/Accounting/app/Http/Requests/AccountingStatusMasterRequest.php Modules/Accounting/app/Policies/AccountingStatusMasterPolicy.php`
  - **Verify:** `.\vendor\bin\pint.bat --test Modules/Accounting/app/Models/AccountingStatusMaster.php Modules/Accounting/app/Http/Requests/AccountingStatusMasterRequest.php Modules/Accounting/app/Policies/AccountingStatusMasterPolicy.php --format=json`
  - **Expect:** `{"tool":"pint","result":"passed"}`
  - **Effort:** S
  - **Note:** `Rule` is unused and Pint removes it; `AccountingStatusMaster` stays because the FormRequest uses it in the `$id` check at lines 24-26. Pint also aligns the `=>` arrays and fixes the model's extra blank line at EOF (`single_blank_line_at_eof`). If the `ACSM-02` DECISION chooses deletion, skip this item.

## 9. Deferred / decisions

- [ ] **ACSM-02** · L · DECISION · CTL-10 — what should happen to the retired Status Masters surface (model, FormRequest, Policy, Seeder, four blades, orphaned partial) and its undeclared permission namespace?
  - **Why it is a decision:** deleting files or declaring/seeding permissions is a product decision; reactivating the feature needs a migration, a permission key, a menu/tab and tests.
  - (a) ⭐ **keep the surface per D3/D5 and record it as accepted.** Leave the dead files in place; `ACSM-01`, `ACSM-04` and `ACSM-05` still apply. The permission strings stay undeclared because nothing routed reaches them.
  - (b) **delete the dead surface.** Files: `Modules/Accounting/app/Http/Requests/AccountingStatusMasterRequest.php`, `Modules/Accounting/app/Policies/AccountingStatusMasterPolicy.php`, `Modules/Accounting/app/Models/AccountingStatusMaster.php`, `Modules/Accounting/database/seeders/AccountingStatusMasterSeeder.php`, the four blades under `Modules/Accounting/resources/views/accounting-status-master/`, and `Modules/Accounting/resources/views/pages/partials/setup-masters/_status-masters.blade.php`. Also remove the unused imports at `AccDashboardController.php:11` and `BankReconciliationController.php:14` (⚠ SHARED — other reports) and the breadcrumb entry at `app/Services/Breadcrumbs/registry.php:152-156` (⚠ SHARED — app-wide).
  - (c) **reactivate the feature** (new migration, `accounting.accounting-status-master` key + seeding, menu/tab, controller, blades). Out of scope for this pass.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| ACSM-03 | Covered by the `ACSM-02` DECISION: the model is part of the same retired surface. Option (b) deletes it; option (a) accepts the tombstone and its `newQuery()` guard as-is. |
