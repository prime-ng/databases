# Fix Plan — Accounting / BankStatementEntryController

**From:** `01-report.md` (2026-10-24) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `final-audit-reports/00-CLASS-OWNERS.md`, `final-audit-reports/gaurav/Accounting/00-INDEX.md` | registry / index — updated by the main session, not by this plan |
| `database/migrations/tenant/**` | migrations are frozen (standing rule); BKSE-12 option (b) would need a new additive migration, which this pass never runs |
| `Modules/Accounting/app/Services/ReconciliationService.php` | unclaimed shared service (§7 of the report); BKSE-09 only removes its injection here, it does not edit the service |
| `Modules/Accounting/app/Models/BankReconciliation.php` | owned by `gaurav/Accounting/BankReconciliationController` |
| `Modules/Accounting/app/Models/Ledger.php` | owned by `gaurav/Accounting/LedgerController` |
| `Modules/Accounting/app/Models/BankReconciliationMatch.php` | owned by `gaurav/Accounting/BankReconciliationMatchController` |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | owned by `gaurav/Accounting/AccountingStatusMasterController` |
| `resources/views/components/backend/table/action-trashed.blade.php` | shared component; already supports `DELETE` (component lines 22–40) |
| `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_bank-statement-entries.blade.php` | rendered by `AccDashboardController`, not by this controller |
| `config/permissionslist.php` | shared config; no new permission key is needed by this plan |
| `app/Helpers/activityLog.php`, `app/Traits/AuthorizesTenantFeature.php` | common glue (§4.2); no defect found |

## 1. Blockers reachable today

- [ ] **BKSE-01** · B · ERR-01 · `BankStatementEntryController.php:69-71,113-115,134-136` — stop flashing the raw exception text: delete the three write catches.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php`
  - **Before** (import block, `BankStatementEntryController.php:9-12`):
    ```php
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Modules\Accounting\Http\Requests\BankStatementEntryRequest;
    ```
  - **After:**
    ```php
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Modules\Accounting\Http\Requests\BankStatementEntryRequest;
    ```
  - **Before** (`BankStatementEntryController.php:58-72`, `store()`):
    ```php
        try {
            $entry = DB::transaction(function () use ($validated) {
                $entry = BankStatementEntry::create($validated);

                activityLog($entry, 'Created', [
                    'message'      => 'Bank Statement Entry created.',
                    'performed_by' => auth()->id(),
                ]);

                return $entry;
            });
        } catch (\Throwable $e) {
            Log::error('Bank Statement Entry create failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to create statement entry: ' . $e->getMessage())->withInput();
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($validated) {
            $entry = BankStatementEntry::create($validated);

            activityLog($entry, 'Created', [
                'message'      => 'Bank Statement Entry created.',
                'performed_by' => auth()->id(),
            ]);
        });
    ```
  - **Before** (`BankStatementEntryController.php:104-116`, `update()`):
    ```php
        try {
            DB::transaction(function () use ($bankStatementEntry, $validated) {
                $bankStatementEntry->update($validated);

                activityLog($bankStatementEntry, 'Updated', [
                    'message'      => 'Bank Statement Entry updated.',
                    'performed_by' => auth()->id(),
                ]);
            });
        } catch (\Throwable $e) {
            Log::error('Bank Statement Entry update failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to update statement entry: ' . $e->getMessage())->withInput();
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($bankStatementEntry, $validated) {
            $bankStatementEntry->update($validated);

            activityLog($bankStatementEntry, 'Updated', [
                'message'      => 'Bank Statement Entry updated.',
                'performed_by' => auth()->id(),
            ]);
        });
    ```
  - **Before** (`BankStatementEntryController.php:126-137`, `destroy()`):
    ```php
        try {
            DB::transaction(function () use ($bankStatementEntry) {
                $bankStatementEntry->delete();
                activityLog($bankStatementEntry, 'Deleted', [
                    'message'      => 'Bank Statement Entry deleted.',
                    'performed_by' => auth()->id(),
                ]);
            });
        } catch (\Throwable $e) {
            Log::error('Bank Statement Entry delete failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to delete statement entry: ' . $e->getMessage());
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($bankStatementEntry) {
            $bankStatementEntry->delete();
            activityLog($bankStatementEntry, 'Deleted', [
                'message'      => 'Bank Statement Entry deleted.',
                'performed_by' => auth()->id(),
            ]);
        });
    ```
  - **Verify:** `Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "Bank Statement Entry (create|update|delete) failed"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BKSE-02** · B · ERR-01 / ERR-02 · `BankStatementEntryController.php:152-192` and `Modules/Accounting/routes/web.php:246-247` — make the trash actions resource-shaped: `DELETE` restore, model binding with trashed rows, and no catch. ⚠ SHARED (route file).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php`, `Modules/Accounting/routes/web.php`
  - **Before** (`routes/web.php:246-247`):
    ```php
Route::get('/bank-statement-entry/{id}/restore', [\Modules\Accounting\Http\Controllers\BankStatementEntryController::class, 'restore'])->name('bank-statement-entry.restore');
Route::delete('/bank-statement-entry/{id}/force-delete', [\Modules\Accounting\Http\Controllers\BankStatementEntryController::class, 'forceDelete'])->name('bank-statement-entry.forceDelete');
    ```
  - **After:**
    ```php
Route::delete('/bank-statement-entry/{bank_statement_entry}/restore', [\Modules\Accounting\Http\Controllers\BankStatementEntryController::class, 'restore'])->name('bank-statement-entry.restore')->withTrashed();
Route::delete('/bank-statement-entry/{bank_statement_entry}/force-delete', [\Modules\Accounting\Http\Controllers\BankStatementEntryController::class, 'forceDelete'])->name('bank-statement-entry.forceDelete')->withTrashed();
    ```
  - **Before** (`BankStatementEntryController.php:152-171`, `restore()`):
    ```php
    public function restore(int $id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-statement-entry.restore');

        try {
            DB::transaction(function () use ($id) {
                $item = BankStatementEntry::onlyTrashed()->findOrFail($id);
                $item->restore();
                activityLog($item, 'Restored', [
                    'message'      => 'Bank Statement Entry restored.',
                    'performed_by' => auth()->id(),
                ]);
            });
        } catch (\Throwable $e) {
            return back()->with('error', 'Failed to restore entry: ' . $e->getMessage());
        }

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-statement-entries'])
            ->with('success', 'Bank Statement Entry restored successfully.');
    }
    ```
  - **After:**
    ```php
    public function restore(BankStatementEntry $bankStatementEntry): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-statement-entry.restore');

        abort_unless($bankStatementEntry->trashed(), 404);

        DB::transaction(function () use ($bankStatementEntry) {
            $bankStatementEntry->restore();
            activityLog($bankStatementEntry, 'Restored', [
                'message'      => 'Bank Statement Entry restored.',
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-statement-entries'])
            ->with('success', 'Bank Statement Entry restored successfully.');
    }
    ```
  - **Before** (`BankStatementEntryController.php:173-192`, `forceDelete()`):
    ```php
    public function forceDelete(int $id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-statement-entry.forceDelete');

        try {
            DB::transaction(function () use ($id) {
                $item = BankStatementEntry::withTrashed()->findOrFail($id);
                $item->forceDelete();
                activityLog($item, 'ForceDeleted', [
                    'message'      => 'Bank Statement Entry permanently deleted.',
                    'performed_by' => auth()->id(),
                ]);
            });
        } catch (\Throwable $e) {
            return back()->with('error', 'Failed to permanently delete entry: ' . $e->getMessage());
        }

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-statement-entries'])
            ->with('success', 'Bank Statement Entry permanently deleted.');
    }
    ```
  - **After:**
    ```php
    public function forceDelete(BankStatementEntry $bankStatementEntry): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-statement-entry.forceDelete');

        DB::transaction(function () use ($bankStatementEntry) {
            $bankStatementEntry->forceDelete();
            activityLog($bankStatementEntry, 'ForceDeleted', [
                'message'      => 'Bank Statement Entry permanently deleted.',
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'bank-statement-entries'])
            ->with('success', 'Bank Statement Entry permanently deleted.');
    }
    ```
  - **Verify:** `Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "getMessage"` and `Select-String -LiteralPath "Modules\Accounting\routes\web.php" -Pattern "bank-statement-entry/\{id\}"`
  - **Expect:** no output from either command.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

Neither item below arms another defect; both are F6 controller-shape fixes. `BKSE-10` is placed before `BKSE-16` only because both touch the same file and the fixer works top-down.

- [ ] **BKSE-09** · M · CTL-10 · `BankStatementEntryController.php:15,19` — drop the injected service that is never used.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php`
  - **Before** (`BankStatementEntryController.php:15-19`):
    ```php
use Modules\Accounting\Services\ReconciliationService;

class BankStatementEntryController extends Controller
{
    public function __construct(private readonly ReconciliationService $service) {}
    ```
  - **After:**
    ```php
class BankStatementEntryController extends Controller
{
    ```
  - **Verify:** `Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "ReconciliationService"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BKSE-10** · M · CTL-05 · `BankStatementEntryController.php:32-35,92-95` — one `formData()` helper for both dropdowns, selecting only the columns the form uses.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php`
  - **Before** (`BankStatementEntryController.php:14`, import block):
    ```php
use Modules\Accounting\Models\BankStatementEntry;
    ```
  - **After:**
    ```php
use Modules\Accounting\Models\BankStatementEntry;
use Modules\Accounting\Models\Ledger;
    ```
  - **Before** (`BankStatementEntryController.php:32-35`, `create()`):
    ```php
        $reconciliations = BankReconciliation::with('bankLedger')->where('is_active', true)->orderByDesc('statement_date')->get();
        $bankLedgers = \Modules\Accounting\Models\Ledger::selectableBankAccounts();

        return view('accounting::bank-statement-entry.create', compact('reconciliations', 'bankLedgers'));
    ```
  - **After:**
    ```php
        return view('accounting::bank-statement-entry.create', $this->formData());
    ```
  - **Before** (`BankStatementEntryController.php:91-95`, `edit()`):
    ```php
        $bankStatementEntry->load(['reconciliation.bankLedger', 'bankLedger']);
        $reconciliations = BankReconciliation::with('bankLedger')->where('is_active', true)->orderByDesc('statement_date')->get();
        $bankLedgers = \Modules\Accounting\Models\Ledger::selectableBankAccounts();

        return view('accounting::bank-statement-entry.edit', compact('bankStatementEntry', 'reconciliations', 'bankLedgers'));
    ```
  - **After:**
    ```php
        $bankStatementEntry->load(['reconciliation.bankLedger', 'bankLedger']);

        return view('accounting::bank-statement-entry.edit', $this->formData() + ['bankStatementEntry' => $bankStatementEntry]);
    ```
  - **Before** (`BankStatementEntryController.php:212-214`, end of class):
    ```php
        return back()->with('success', 'Bank statement entry excluded from reconciliation.');
    }
}
    ```
  - **After:**
    ```php
        return back()->with('success', 'Bank statement entry excluded from reconciliation.');
    }

    private function formData(): array
    {
        return [
            'reconciliations' => BankReconciliation::query()
                ->with('bankLedger:id,name')
                ->where('is_active', true)
                ->orderByDesc('statement_date')
                ->get(['id', 'bank_ledger_id', 'statement_date']),
            'bankLedgers' => Ledger::selectableBankAccounts(),
        ];
    }
}
    ```
  - **Verify:** `Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "formData"`
  - **Expect:** three lines — the private method and its two callers.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [ ] **BKSE-04** · H · TXN-01 · `BankStatementEntryController.php:198-210` — put the exclude update and its audit row in one transaction, and read the value from `validate()`.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php`
  - **Before** (`BankStatementEntryController.php:198-210`):
    ```php
        $request->validate([
            'exclude_reason' => 'required|string|max:500',
        ]);

        $bankStatementEntry->update([
            'match_status'   => 'Excluded',
            'exclude_reason' => $request->input('exclude_reason'),
        ]);

        activityLog($bankStatementEntry, 'Excluded', [
            'message'      => 'Bank Statement Entry excluded: ' . $request->input('exclude_reason'),
            'performed_by' => auth()->id(),
        ]);
    ```
  - **After:**
    ```php
        $validated = $request->validate([
            'exclude_reason' => 'required|string|max:500',
        ]);

        DB::transaction(function () use ($bankStatementEntry, $validated) {
            $bankStatementEntry->update([
                'match_status'   => 'Excluded',
                'exclude_reason' => $validated['exclude_reason'],
            ]);

            activityLog($bankStatementEntry, 'Excluded', [
                'message'      => 'Bank Statement Entry excluded: ' . $validated['exclude_reason'],
                'performed_by' => auth()->id(),
            ]);
        });
    ```
  - **Verify:** `Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "DB::transaction"`
  - **Expect:** six matching lines (five existing plus this one).
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **BKSE-05** · L · AUTH-04 · `BankStatementEntryController.php:40,100` — remove the duplicate Gate call from `store()` and `update()`; the FormRequest already authorized the same string.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php`
  - **Before** (`BankStatementEntryController.php:38-42`):
    ```php
    public function store(BankStatementEntryRequest $request)
    {
        Gate::authorize('tenant.accounting.bank-statement-entry.create');

        $validated = $request->validated();
    ```
  - **After:**
    ```php
    public function store(BankStatementEntryRequest $request)
    {
        $validated = $request->validated();
    ```
  - **Before** (`BankStatementEntryController.php:98-102`):
    ```php
    public function update(BankStatementEntryRequest $request, BankStatementEntry $bankStatementEntry)
    {
        Gate::authorize('tenant.accounting.bank-statement-entry.update');

        $validated = $request->validated();
    ```
  - **After:**
    ```php
    public function update(BankStatementEntryRequest $request, BankStatementEntry $bankStatementEntry)
    {
        $validated = $request->validated();
    ```
  - **Verify:** `Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "Gate::authorize"`
  - **Expect:** nine matching lines (eleven before, two removed).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **BKSE-06** · H · VAL-05 · `BankStatementEntryRequest.php:23-24` and `BankStatementEntryController.php:46-56` — validate both ids against their tables and stop substituting the first bank account.
  - **Touches:** `Modules/Accounting/app/Http/Requests/BankStatementEntryRequest.php`, `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php`
  - **Before** (`BankStatementEntryRequest.php:22-24`):
    ```php
        return [
            'reconciliation_id'  => $this->isMethod('POST') ? ['required', 'integer'] : ['nullable', 'integer'],
            'bank_ledger_id'     => ['nullable', 'integer'],
    ```
  - **After:**
    ```php
        return [
            'reconciliation_id'  => $this->isMethod('POST') ? ['required', 'integer', 'exists:acc_bank_reconciliations,id'] : ['nullable', 'integer', 'exists:acc_bank_reconciliations,id'],
            'bank_ledger_id'     => ['nullable', 'integer', 'exists:acc_ledgers,id'],
    ```
  - **Before** (`BankStatementEntryController.php:46-56`):
    ```php
        if (empty($validated['bank_ledger_id']) && !empty($validated['reconciliation_id'])) {
            $recon = BankReconciliation::find($validated['reconciliation_id']);
            if ($recon) {
                $validated['bank_ledger_id'] = $recon->bank_ledger_id;
            }
        }

        if (empty($validated['bank_ledger_id'])) {
            $firstBank = \Modules\Accounting\Models\Ledger::bankAccounts()->value('id');
            $validated['bank_ledger_id'] = $firstBank;
        }
    ```
  - **After:**
    ```php
        if (empty($validated['bank_ledger_id']) && !empty($validated['reconciliation_id'])) {
            $bankLedgerId = BankReconciliation::whereKey($validated['reconciliation_id'])->value('bank_ledger_id');

            if ($bankLedgerId === null) {
                throw new \DomainException('The selected reconciliation profile has no bank account.');
            }

            $validated['bank_ledger_id'] = $bankLedgerId;
        }
    ```
  - **Verify:** `Select-String -LiteralPath "Modules\Accounting\app\Http\Requests\BankStatementEntryRequest.php" -Pattern "exists:acc_"` and `Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "bankAccounts\("`
  - **Expect:** two lines from the request; no output from the controller.
  - **Effort:** S

- [ ] **BKSE-13** · H · VAL-04 · `BankStatementEntry.php:136-141` — count soft-deleted rows when computing `row_occurrence`, so a deleted line's unique key is stepped over.
  - **Touches:** `Modules/Accounting/app/Models/BankStatementEntry.php`
  - **Before** (`BankStatementEntry.php:136-141`):
    ```php
            if (empty($entry->row_occurrence) && !empty($entry->reconciliation_id)) {
                $count = static::where('reconciliation_id', $entry->reconciliation_id)
                    ->where('row_hash', $entry->row_hash)
                    ->count();
                $entry->row_occurrence = $count + 1;
            }
    ```
  - **After:**
    ```php
            if (empty($entry->row_occurrence) && !empty($entry->reconciliation_id)) {
                $count = static::withTrashed()
                    ->where('reconciliation_id', $entry->reconciliation_id)
                    ->where('row_hash', $entry->row_hash)
                    ->count();
                $entry->row_occurrence = $count + 1;
            }
    ```
  - **Verify:** `Select-String -LiteralPath "Modules\Accounting\app\Models\BankStatementEntry.php" -Pattern "withTrashed\(\)"`
  - **Expect:** one matching line.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **BKSE-16** · M · QRY-02 · `BankStatementEntryController.php:147` — paginate the trash list at the house size of 10.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php`
  - **Before** (`BankStatementEntryController.php:147`):
    ```php
        $items = BankStatementEntry::onlyTrashed()->with(['reconciliation.bankLedger', 'bankLedger'])->orderByDesc('deleted_at')->paginate(20);
    ```
  - **After:**
    ```php
        $items = BankStatementEntry::onlyTrashed()->with(['reconciliation.bankLedger', 'bankLedger'])->orderByDesc('deleted_at')->paginate(10);
    ```
  - **Verify:** `Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "paginate\(10\)"`
  - **Expect:** one matching line.
  - **Effort:** S

## 7. Views (F10)

None — F10 is clean (`01-report.md` §6, F10).

## 8. Style (F12) — one item per file

- [ ] **BKSE-17** · L · STY-02 · `BankStatementEntryController.php` — run Pint on the controller.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php`
  - **Before** (`BankStatementEntryController.php:143`):
    ```php
    public function trashed(): \Illuminate\Contracts\View\View
    ```
  - **After:**
    ```php
    public function trashed(): View
    ```
    (plus `use Illuminate\Contracts\View\View;` — Pint adds the import and applies the remaining fixers `fully_qualified_strict_types`, `concat_space`, `braces_position`, `not_operator_with_successor_space`, `single_line_empty_body`, `blank_line_before_statement`, `ordered_imports`, `binary_operator_spaces`.)
  - **Verify:** `vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`.
  - **Effort:** S

- [ ] **BKSE-18** · L · STY-02 · `BankStatementEntryRequest.php` — run Pint on the FormRequest.
  - **Touches:** `Modules/Accounting/app/Http/Requests/BankStatementEntryRequest.php`
  - **Before** (`BankStatementEntryRequest.php:68-69`):
    ```php
            'reconciliation_id'  => 'Bank Reconciliation Profile',
            'bank_ledger_id'     => 'Bank Account',
    ```
  - **After:**
    ```php
            'reconciliation_id' => 'Bank Reconciliation Profile',
            'bank_ledger_id' => 'Bank Account',
    ```
    (Pint applies the remaining fixers `ordered_imports` and `binary_operator_spaces` across the file.)
  - **Verify:** `vendor\bin\pint --test "Modules\Accounting\app\Http\Requests\BankStatementEntryRequest.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`.
  - **Effort:** S

- [ ] **BKSE-19** · L · STY-02 · `BankStatementEntry.php` — run Pint on the model.
  - **Touches:** `Modules/Accounting/app/Models/BankStatementEntry.php`
  - **Before** (`BankStatementEntry.php:7`):
    ```php
use App\Models\BaseModel;
    ```
  - **After:** the line is deleted (Pint's `no_unused_imports`), and Pint applies `fully_qualified_strict_types`, `concat_space`, `cast_spaces`, `not_operator_with_successor_space`, `ordered_imports`, `binary_operator_spaces`.
  - **Verify:** `vendor\bin\pint --test "Modules\Accounting\app\Models\BankStatementEntry.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BKSE-12** · M · DECISION · MDL-04 — `creator()` and `matchedByUser()` query `created_by` / `matched_by`, which `acc_bank_statement_entries` does not have. What should happen?
  - **Why it is a decision:** option (b) needs a migration, and the DDL wins until Tarun says otherwise.
  - (a) ⭐ delete both relations from `BankStatementEntry.php` — nothing in the module reads them, and the table has no such columns.
  - (b) add `created_by` and `matched_by` to the table with a new additive migration (written, never run here) and keep the relations.
  - (c) leave as is, record as accepted — the relations are dead today but fail with a SQL error the day someone uses them.
  - ➜ Choice: ____

- [ ] **BKSE-14** · M · DECISION · MDL-06 — `row_hash` is computed only on create, so editing an imported line leaves a stale idempotency key and the next import re-adds the line. What should happen?
  - **Why it is a decision:** it changes what a user may edit after an import, and option (b) can collide with `uq_acc_bse_hash` and must then be handled with a duplicate message.
  - (a) ⭐ freeze the hash-covered fields (`transaction_date`, `description`, `reference`, `instrument_no`, `debit`, `credit`, `balance`) once `entry_type` is `Imported`, and remove them from the edit form for imported rows.
  - (b) recompute `row_hash` and `row_occurrence` in an `updating` hook, and show a duplicate warning when the recomputed key already exists.
  - (c) leave stale, record as accepted.
  - ➜ Choice: ____

- [ ] **BKSE-20** · H · DECISION · VAL-07 — a reconciled line can be re-flagged, moved to another reconciliation, or permanently deleted (which cascades its `acc_bank_reconciliation_matches` row). What should the server refuse?
  - **Why it is a decision:** it changes the allowed workflow for `Matched` lines and needs a rule for the confirmed match (block, or undo first).
  - (a) ⭐ when a `Confirmed` match exists, make `match_status`, `matched_amount` and `reconciliation_id` read-only, and refuse `destroy` / `forceDelete` with a clear message.
  - (b) allow it but first reject/undo the confirmed match inside the same transaction, writing an audit event for the undo.
  - (c) leave as is, record as accepted — the only guard today is the blade's Exclude button.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BKSE-07 | Inline validation of a single field (`exclude_reason`). Lowered to L on purpose: the rule is complete and the field count is one; the value read is fixed by BKSE-04, and extracting a FormRequest for one field is not worth a new file. Accepted. |
