# Final Audit — Accounting / DepreciationEntryController

**Audited:** 2026-10-24 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php` (298 lines, 12 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/depreciation-entry` (redirects to the Assets Integration tab) · `/accounting/depreciation-entry/create` · `/accounting/depreciation-entry/{id}` · `/accounting/depreciation-entry/{id}/edit` · `/accounting/depreciation-entry/trash/view` |
| Menu path | Accounting → Assets Integration → **Depreciation Entries** tab |
| Who uses it | **No seeded role holds any `tenant.accounting.depreciation-entry.*` permission** — the tenant has `0` such permission rows and `0` role grants. Only the Super Admin role reaches the screen, through the `Gate::before` bypass in `AppServiceProvider`. Five roles (Super Admin, School Admin, Management, Account Staff, Account Manager) hold `tenant.accounting.fixed-asset.viewAny`, so they can see the other Assets Integration tabs but not this one. |
| What a user does here | Records the depreciation charge for one fixed asset for one accounting period. The user picks an asset, a financial year and a date, enters the charge amount, and optionally lets the system create and post the Dr Depreciation Expense / Cr Accumulated Depreciation journal voucher. The same amount can be edited later, and entries can be deactivated, soft-deleted, restored or permanently deleted. |
| Tables written | `acc_depreciation_entries`; on auto-post `acc_vouchers`, `acc_voucher_items` (and any reference rows) through `VoucherService`; `sys_activity_logs` through `activityLog()`. |
| Tables read | `acc_depreciation_entries`, `acc_fixed_assets`, `acc_asset_categories`, `acc_financial_years`, `acc_accounting_periods`, `acc_vouchers`, `acc_voucher_types`, `sys_users`. |
| Live data | `acc_depreciation_entries` **5 live, 0 trashed** (all 5 `is_posted = 1`, all 5 `voucher_id = NULL`); `acc_fixed_assets` 5; `acc_financial_years` 3; `acc_accounting_periods` 12; `acc_vouchers` 30; `sys_activity_logs` 405. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No, this controller is not production-ready. The single worst finding is **DPRE-02 (B, AUTH-01)**: the seven `tenant.accounting.depreciation-entry.*` permissions are declared nowhere in `config/permissionslist.php` and do not exist in the tenant database, so every non-Super-Admin role is refused at the gate and the whole Depreciation Entries tab is invisible to them. That mask hides a second blocker: **DPRE-01 (B, ERR-01)** — `store`, `update` and `destroy` catch `\Throwable` and put `$e->getMessage()` straight into the red flash, so the first duplicate asset/period save shows raw SQL, table and constraint names to the Super Admin who can reach it. Behind those sit seven High findings: a missing transaction around five mutations, a unique `(asset, period)` key that no validation rule mirrors, a GET restore, an update path that silently rewrites the stored depreciation basis, and a preview that always returns straight-line figures. Rough effort: **M**, about one and a half to two developer-days plus a permission sync performed by Tarun.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 3 | 7 | 8 | 7 | 6 | 25 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | DPRE-01, DPRE-04, DPRE-11 | F8 Services/Jobs | DPRE-16 |
| F2 Transactions/Audit | DPRE-05, DPRE-12 | F9 Queries/Perf | DPRE-18, DPRE-21, DPRE-22 |
| F3 Authorization | DPRE-02, DPRE-03, DPRE-13 | F10 Views | DPRE-23 |
| F4 Validation | DPRE-06, DPRE-08, DPRE-14, DPRE-15 | F11 Security/Tenancy | clean |
| F5 Routes | DPRE-07 | F12 Style | DPRE-24 |
| F6 Controller shape | DPRE-17, DPRE-19 | F13 Deep read | DPRE-09, DPRE-10, DPRE-25 |
| F7 Models | DPRE-20 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php` | controller | 298 | this report | ✅ |
| 2 | `Modules/Accounting/app/Http/Requests/DepreciationEntryRequest.php` | form request | 114 | this report | ✅ |
| 3 | `Modules/Accounting/app/Models/DepreciationEntry.php` | model | 103 | this report | ✅ |
| 4 | `Modules/Accounting/app/Policies/DepreciationEntryPolicy.php` | policy | 46 | this report (no registry row) | ✅ |
| 5 | `Modules/Accounting/resources/views/depreciation-entry/create.blade.php` | view | 218 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/depreciation-entry/edit.blade.php` | view | 129 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/depreciation-entry/show.blade.php` | view | 90 | this report | ✅ |
| 8 | `Modules/Accounting/resources/views/depreciation-entry/trash.blade.php` | view | 76 | this report | ✅ |
| 9 | `Modules/Accounting/app/Models/FixedAsset.php` | model | 299 | ↗ [gaurav/Accounting/FixedAssetController](../FixedAssetController/01-report.md) | ↗ linked |
| 10 | `Modules/Accounting/app/Models/AssetCategory.php` | model | 108 | ↗ [gaurav/Accounting/AssetCategoryController](../AssetCategoryController/01-report.md) | ↗ linked |
| 11 | `Modules/Accounting/app/Models/FinancialYear.php` | model | 168 | ↗ [gaurav/Accounting/FinancialYearController](../FinancialYearController/01-report.md) (report not written yet) | ↗ linked |
| 12 | `Modules/Accounting/app/Models/AccountingPeriod.php` | model | 137 | ↗ [gaurav/Accounting/AccountingPeriodController](../AccountingPeriodController/01-report.md) (report not written yet) | ↗ linked |
| 13 | `Modules/Accounting/app/Models/Voucher.php` | model | 415 | ↗ [gaurav/Accounting/VoucherController](../VoucherController/01-report.md) (CLAIMED, not written yet) | ↗ linked |
| 14 | `Modules/Accounting/app/Models/VoucherType.php` | model | 185 | ↗ [gaurav/Accounting/VoucherTypeController](../VoucherTypeController/01-report.md) (report not written yet) | ↗ linked |
| 15 | `Modules/Accounting/app/Services/VoucherService.php` | service | 402 | ↗ [gaurav/Accounting/VoucherController](../VoucherController/01-report.md) (CLAIMED, not written yet) | ↗ linked |
| 16 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | base model | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 17 | `Modules/Accounting/app/Services/AccountingContext.php` | service | 110 | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 18 | `Modules/Accounting/routes/web.php` | route file | 536 | shared | checked F5/RTE only |
| 19 | `config/permissionslist.php` | shared config | 1824 | shared | checked F3 only |
| 20 | `Modules/Accounting/resources/views/pages/partials/assets-integration/_depreciation-entries.blade.php` | shared view | 556 | ↗ `gaurav/Accounting/AccDashboardController` (CLAIMED, no report yet) | checked for this controller's routes/permissions only |
| 21 | `resources/views/components/**`, layouts, `activityLog()` | common | — | app-wide | not audited (common, §4.2) |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/depreciation-entry                           accounting.depreciation-entry.index           Modules\Accounting\Http\Controllers\DepreciationEntryController@index
POST      accounting/depreciation-entry                           accounting.depreciation-entry.store           Modules\Accounting\Http\Controllers\DepreciationEntryController@store
POST      accounting/depreciation-entry/calculate-preview         accounting.depreciation-entry.calculatePreview Modules\Accounting\Http\Controllers\DepreciationEntryController@calculatePreview
GET|HEAD  accounting/depreciation-entry/create                    accounting.depreciation-entry.create          Modules\Accounting\Http\Controllers\DepreciationEntryController@create
GET|HEAD  accounting/depreciation-entry/trash/view                accounting.depreciation-entry.trashed          Modules\Accounting\Http\Controllers\DepreciationEntryController@trashed
GET|HEAD  accounting/depreciation-entry/{depreciation_entry}      accounting.depreciation-entry.show            Modules\Accounting\Http\Controllers\DepreciationEntryController@show
PUT|PATCH accounting/depreciation-entry/{depreciation_entry}      accounting.depreciation-entry.update          Modules\Accounting\Http\Controllers\DepreciationEntryController@update
DELETE    accounting/depreciation-entry/{depreciation_entry}      accounting.depreciation-entry.destroy         Modules\Accounting\Http\Controllers\DepreciationEntryController@destroy
GET|HEAD  accounting/depreciation-entry/{depreciation_entry}/edit accounting.depreciation-entry.edit            Modules\Accounting\Http\Controllers\DepreciationEntryController@edit
POST      accounting/depreciation-entry/{depreciation_entry}/toggle-status accounting.depreciation-entry.toggleStatus Modules\Accounting\Http\Controllers\DepreciationEntryController@toggleStatus
DELETE    accounting/depreciation-entry/{id}/force-delete         accounting.depreciation-entry.forceDelete     Modules\Accounting\Http\Controllers\DepreciationEntryController@forceDelete
GET|HEAD  accounting/depreciation-entry/{id}/restore              accounting.depreciation-entry.restore         Modules\Accounting\Http\Controllers\DepreciationEntryController@restore
```

All twelve routes carry the tenant middleware stack (`PreventAccessFromCentralDomains`, `InitializeTenancyByDomain`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Accounting`, `Authenticate`, `EnsureEmailIsVerified`).

Unrouted public methods: **none**.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 21 | GET /accounting/depreciation-entry | `tenant.accounting.depreciation-entry.viewAny` | — | — | — | DPRE-02 |
| `create` | 32 | GET /accounting/depreciation-entry/create | `tenant.accounting.depreciation-entry.create` | — | — | — | DPRE-02, DPRE-18 |
| `store` | 44 | POST /accounting/depreciation-entry | `tenant.accounting.depreciation-entry.create` | controller, `DB::transaction` line 56 (log outside) | 'Created' | `acc_depreciation_entries`, `acc_vouchers`, `acc_voucher_items`, `sys_activity_logs` | DPRE-01, DPRE-02, DPRE-04, DPRE-11, DPRE-12, DPRE-16 |
| `show` | 111 | GET /accounting/depreciation-entry/{depreciation_entry} | `tenant.accounting.depreciation-entry.view` | — | — | — | DPRE-02, DPRE-22, DPRE-23 |
| `edit` | 120 | GET /accounting/depreciation-entry/{depreciation_entry}/edit | `tenant.accounting.depreciation-entry.update` | — | — | — | DPRE-02, DPRE-18 |
| `update` | 134 | PUT/PATCH /accounting/depreciation-entry/{depreciation_entry} | `tenant.accounting.depreciation-entry.update` | none | 'Updated' | `acc_depreciation_entries`, `sys_activity_logs` | DPRE-01, DPRE-02, DPRE-05, DPRE-08, DPRE-11 |
| `destroy` | 158 | DELETE /accounting/depreciation-entry/{depreciation_entry} | `tenant.accounting.depreciation-entry.delete` | none | 'Trashed' | `acc_depreciation_entries`, `sys_activity_logs` | DPRE-01, DPRE-02, DPRE-05, DPRE-11 |
| `toggleStatus` | 183 | POST /accounting/depreciation-entry/{depreciation_entry}/toggle-status | `tenant.accounting.depreciation-entry.update` | none | 'Toggled' | `acc_depreciation_entries`, `sys_activity_logs` | DPRE-02, DPRE-05 |
| `trashed` | 204 | GET /accounting/depreciation-entry/trash/view | `tenant.accounting.depreciation-entry.restore` | — | — | — | DPRE-02, DPRE-21, DPRE-22 |
| `restore` | 213 | GET /accounting/depreciation-entry/{id}/restore | `tenant.accounting.depreciation-entry.restore` | none | 'Restored' | `acc_depreciation_entries`, `sys_activity_logs` | DPRE-02, DPRE-05, DPRE-07, DPRE-17 |
| `forceDelete` | 229 | DELETE /accounting/depreciation-entry/{id}/force-delete | `tenant.accounting.depreciation-entry.forceDelete` | none | 'Deleted' | `acc_depreciation_entries`, `sys_activity_logs` | DPRE-02, DPRE-05, DPRE-10, DPRE-17 |
| `calculatePreview` | 244 | POST /accounting/depreciation-entry/calculate-preview | **none** | — | — | — | DPRE-03, DPRE-09, DPRE-14 |

## 6. Findings

### F1 — Errors

#### DPRE-01 · B · ERR-01 — Raw database error text is shown to the user on three write paths

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:105-108`, method `store()`; the same shape at `:152-155` (`update()`) and `:177-180` (`destroy()`). All three sit under D1: a controller `try/catch` is itself forbidden. |
| **Root cause** | Each mutation wraps its work in `try { ... } catch (\Throwable $e)` and concatenates `$e->getMessage()` into `back()->with('error', ...)`. The panel also logs with `Log::error('...' . $e->getMessage())` instead of `report($e)`. |
| **Consequence** | A duplicate `(asset, period)` save, a foreign-key failure or a missing restore id shows the raw SQL, table name and constraint name in the red flash. |
| **Reproduce** | Create an entry for asset 1, period 3, then create a second entry for the same pair. Expected a validation message; actual a red flash containing `SQLSTATE[23000] ... uq_acc_de_asset_period`. |
| **Fix approach** | Delete the three `try/catch` wrappers (D1). Load records before the write. Let `DB::transaction` roll back and the central handler render the error. |
| **Plan item** | DPRE-01 in `02-fix-plan.md` §1 |

```php
// DepreciationEntryController.php:105-108 — CURRENT (store; update and destroy repeat it)
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('DepreciationEntry create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return back()->with('error', 'Failed to record depreciation entry: ' . $e->getMessage())->withInput();
        }
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "try \{|catch \(|getMessage|Log::error" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
52: try {
105: } catch (\Throwable $e) {
106: \Illuminate\Support\Facades\Log::error('DepreciationEntry create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
107: return back()->with('error', 'Failed to record depreciation entry: ' . $e->getMessage())->withInput();
141: try {
152: } catch (\Throwable $e) {
153: \Illuminate\Support\Facades\Log::error('DepreciationEntry update failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
154: return back()->with('error', 'Failed to update depreciation entry: ' . $e->getMessage())->withInput();
164: try {
177: } catch (\Throwable $e) {
178: \Illuminate\Support\Facades\Log::error('DepreciationEntry delete failed: ' . $e->getMessage());
179: return back()->with('error', 'Failed to delete depreciation entry: ' . $e->getMessage());
```

#### DPRE-04 · H · ERR-02 — A missing fixed asset on save shows a red flash instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:52-54`, method `store()` |
| **Root cause** | `FixedAsset::findOrFail()` sits inside the `try` whose `catch (\Throwable)` swallows `ModelNotFoundException`. |
| **Consequence** | A crafted or stale form submit for a deleted asset redirects with "Failed to record depreciation entry" and logs a failure, instead of returning 404. |
| **Reproduce** | Submit the create form with `fixed_asset_id=999999` by editing the POST body. Expected 404; actual redirect plus red flash. |
| **Fix approach** | Move the `findOrFail()` above the transaction and delete the catch (DPRE-01). |
| **Plan item** | DPRE-01 in `02-fix-plan.md` §1 |

```php
// DepreciationEntryController.php:52-54 — CURRENT
        try {
            $fixedAsset = FixedAsset::with('assetCategory')->findOrFail($validated['fixed_asset_id']);
            $depreciationAmount = (float) $validated['depreciation_amount'];
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "findOrFail|catch \(" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
53: $fixedAsset = FixedAsset::with('assetCategory')->findOrFail($validated['fixed_asset_id']);
105: } catch (\Throwable $e) {
152: } catch (\Throwable $e) {
177: } catch (\Throwable $e) {
217: $entry = DepreciationEntry::onlyTrashed()->findOrFail($id);
233: $entry = DepreciationEntry::withTrashed()->findOrFail($id);
```

#### DPRE-11 · M · ERR-05 — The catches log the message, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `report($e)` keeps the trace* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:106`, `:153`, `:178` |
| **Root cause** | All three catches call `Log::error('...' . $e->getMessage(), ['trace' => $e->getTraceAsString()])`; the exception object is thrown away. |
| **Consequence** | The log line has no exception class, no request context and no stack object for the handler; debugging a failed voucher post is harder. |
| **Reproduce** | Static only — the log shape is the same on every failure. |
| **Fix approach** | Delete the catches (DPRE-01); the central handler reports the exception. |
| **Plan item** | DPRE-01 in `02-fix-plan.md` §1 |

```php
// DepreciationEntryController.php:106 — CURRENT
            \Illuminate\Support\Facades\Log::error('DepreciationEntry create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "Log::error" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
106: \Illuminate\Support\Facades\Log::error('DepreciationEntry create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
153: \Illuminate\Support\Facades\Log::error('DepreciationEntry update failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
178: \Illuminate\Support\Facades\Log::error('DepreciationEntry delete failed: ' . $e->getMessage());
```

### F2 — Transactions and audit

#### DPRE-05 · H · TXN-01 — Five mutations write the row and its audit log without a transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (a model and its audit row) runs inside one `DB::transaction`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:141-148` (`update`), `:164-173` (`destroy`), `:187-195` (`toggleStatus`), `:217-224` (`restore`), `:233-239` (`forceDelete`) |
| **Root cause** | Only `store` opens a transaction (line 56). The other five mutations call the model write and `activityLog()` as two independent writes. |
| **Consequence** | If the audit insert fails, the business row stays changed but the user sees an error and retries; the retry can then fail on the unique key or duplicate the change. |
| **Reproduce** | Static only — the transaction is absent on all five methods. |
| **Fix approach** | Wrap each write and its `activityLog()` in one `DB::transaction` closure; `update` and `destroy` are rewritten by DPRE-01, the other three by DPRE-05. |
| **Plan item** | DPRE-01 in `02-fix-plan.md` §1 (update, destroy) and DPRE-05 in `02-fix-plan.md` §3 (toggleStatus, restore, forceDelete) |

```php
// DepreciationEntryController.php:141-148 — CURRENT (update; no DB::transaction)
        try {
            $depreciationEntry->update($validated);

            activityLog($depreciationEntry, 'Updated', [
                'message'             => 'Depreciation Entry updated.',
                'fixed_asset_id'      => $depreciationEntry->fixed_asset_id,
                'depreciation_amount' => $depreciationEntry->depreciation_amount,
            ]);
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "DB::transaction|activityLog|->save\(|->delete\(|->restore\(|->forceDelete\(|->update\(" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
56: $entry = DB::transaction(function () use ($validated, $fixedAsset, $depreciationAmount, $request) {
96: activityLog($entry, 'Created', [
142: $depreciationEntry->update($validated);
144: activityLog($depreciationEntry, 'Updated', [
166: $depreciationEntry->save();
167: $depreciationEntry->delete();
169: activityLog($depreciationEntry, 'Trashed', [
190: $depreciationEntry->save();
192: activityLog($depreciationEntry, 'Toggled', [
218: $entry->restore();
219: $entry->update(['is_active' => true]);
221: activityLog($entry, 'Restored', [
234: $entry->forceDelete();
236: activityLog($entry, 'Deleted', [
```

#### DPRE-12 · M · TXN-04 — `store` writes its "Created" audit row after the transaction commits

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:91-101`, method `store()` |
| **Root cause** | `DepreciationEntry::create()` is inside the `DB::transaction` closure, but the `activityLog($entry, 'Created', ...)` call is after the closure returns. |
| **Consequence** | The audit row can fail after the entry has already committed; the user sees a failed save while the entry exists, and the audit trail is missing for it. |
| **Reproduce** | Static only — the call order is visible at lines 91 and 96. |
| **Fix approach** | Move the `activityLog` call inside the closure, directly after `DepreciationEntry::create()`. |
| **Plan item** | DPRE-01 in `02-fix-plan.md` §1 |

```php
// DepreciationEntryController.php:91-101 — CURRENT
                $entry = DepreciationEntry::create($validated);

                return $entry;
            });

            activityLog($entry, 'Created', [
                'message'             => 'Depreciation Entry created.',
                'fixed_asset_id'      => $entry->fixed_asset_id,
                'depreciation_amount' => $entry->depreciation_amount,
                'depreciation_date'   => $entry->depreciation_date?->format('Y-m-d'),
            ]);
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "DepreciationEntry::create|activityLog\(\$entry, 'Created'" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
91: $entry = DepreciationEntry::create($validated);
96: activityLog($entry, 'Created', [
```

### F3 — Authorization

#### DPRE-02 · B · AUTH-01 — The permission namespace does not exist, so only the Super Admin can use the screen

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B) — *every routed method authorizes with a permission that is declared in `config/permissionslist.php` and seeded* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:23, 34, 46, 113, 122, 136, 160, 185, 206, 215, 231`; `config/permissionslist.php:600-616` |
| **Root cause** | Every gate names `tenant.accounting.depreciation-entry.*`, but the `accounting.depreciation-entry` key was never added to the Accounting block of `config/permissionslist.php`, and the live tenant has `0` such permission rows and `0` role grants. Spatie's `Gate::before` grants only the Super Admin. |
| **Consequence** | School Admin, Management, Account Staff and Account Manager get 403 on every route and the Depreciation Entries tab is hidden; only the Super Admin can record, edit, restore or delete an entry. |
| **Reproduce** | Log in as a School Admin and open `/accounting/depreciation-entry`. Expected the list; actual 403, and the tab strip on `/accounting/assets-integration` omits Depreciation Entries. |
| **Fix approach** | Add `'accounting.depreciation-entry' => $crud` to the Accounting block, run `/system-config/sync-permissions`, and grant the new keys to the accounting roles. Both are Tarun's hand. |
| **Plan item** | DPRE-02 in `02-fix-plan.md` §1 (DECISION, ⚠ SHARED) |

```php
// DepreciationEntryController.php:23 — CURRENT (all 11 guarded methods use the same namespace)
        Gate::authorize('tenant.accounting.depreciation-entry.viewAny');
```

**Evidence**
```
> Select-String -Path config\permissionslist.php -Pattern "accounting.depreciation-entry"
(no output)
> mysql -u root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_permissions WHERE name LIKE 'tenant.accounting.depreciation-entry%';"
0
> mysql -u root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_role_has_permissions_jnt j JOIN xyz_school_00000000000040008000_202627.sys_permissions p ON p.id=j.permission_id WHERE p.name LIKE 'tenant.accounting.depreciation-entry%';"
0
> mysql -u root -N -e "SELECT r.name FROM xyz_school_00000000000040008000_202627.sys_roles r JOIN xyz_school_00000000000040008000_202627.sys_role_has_permissions_jnt j ON j.role_id=r.id JOIN xyz_school_00000000000040008000_202627.sys_permissions p ON p.id=j.permission_id WHERE p.name='tenant.accounting.fixed-asset.viewAny';"
Super Admin
School Admin
Management
Account Staff
Account Manager
```

#### DPRE-03 · B · AUTH-01 — The preview endpoint has no authorization at all

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B) — *every routed controller method authorizes* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:244-247`, method `calculatePreview()` |
| **Root cause** | The method takes a plain `Request` and never calls `Gate::authorize`; every other method in the controller does. |
| **Consequence** | Any authenticated tenant user — including a role that cannot see the screen — can POST any `fixed_asset_id` and read that asset's purchase cost, salvage value, accumulated depreciation and current book value. |
| **Reproduce** | Log in as a role without the depreciation permission and POST `{"fixed_asset_id":1}` to `/accounting/depreciation-entry/calculate-preview`. Expected 403; actual 200 with the asset's financial figures. |
| **Fix approach** | Replace `Request` with a `DepreciationPreviewRequest` whose `authorize()` checks `tenant.accounting.depreciation-entry.view`. |
| **Plan item** | DPRE-03 in `02-fix-plan.md` §1 |

```php
// DepreciationEntryController.php:244-249 — CURRENT
    public function calculatePreview(Request $request)
    {
        $assetId = (int) $request->input('fixed_asset_id');
        $date = $request->input('date', now()->format('Y-m-d'));

        $asset = FixedAsset::with('assetCategory')->find($assetId);
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "Gate::authorize" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
23: Gate::authorize('tenant.accounting.depreciation-entry.viewAny');
34: Gate::authorize('tenant.accounting.depreciation-entry.create');
46: Gate::authorize('tenant.accounting.depreciation-entry.create');
113: Gate::authorize('tenant.accounting.depreciation-entry.view');
122: Gate::authorize('tenant.accounting.depreciation-entry.update');
136: Gate::authorize('tenant.accounting.depreciation-entry.update');
160: Gate::authorize('tenant.accounting.depreciation-entry.delete');
185: Gate::authorize('tenant.accounting.depreciation-entry.update');
206: Gate::authorize('tenant.accounting.depreciation-entry.restore');
215: Gate::authorize('tenant.accounting.depreciation-entry.restore');
231: Gate::authorize('tenant.accounting.depreciation-entry.forceDelete');
```

#### DPRE-13 · M · AUTH-05 — The registered `DepreciationEntryPolicy` is never consulted

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — *no dead permission logic; a policy that nothing consults is dead logic* |
| **Where** | `Modules/Accounting/app/Policies/DepreciationEntryPolicy.php:12-45`; registration at `Modules/Accounting/app/Providers/AccountingServiceProvider.php:150` |
| **Root cause** | Every check passes a string ability (`Gate::authorize('tenant.accounting.depreciation-entry.viewAny')`). The Gate resolves a string through Spatie's permission check, never through `DepreciationEntryPolicy`; the policy is registered but unreachable. |
| **Consequence** | A reader of the policy believes it is the authorization source, while the controller's string gates are. Changing one has no effect on the other, and the policy's seven methods are dead code. |
| **Reproduce** | Static only — `Gate::authorize('viewAny', DepreciationEntry::class)` does not appear anywhere in the controller. |
| **Fix approach** | Choose one source: keep the string gates and delete the inert policy plus its provider line, or switch the gates to policy form. |
| **Plan item** | DPRE-13 in `02-fix-plan.md` §9 (DECISION) |

```php
// DepreciationEntryPolicy.php:12-15 — CURRENT (the policy is registered but nothing calls it)
    public function viewAny(User $user): bool
    {
        return $user->can('tenant.accounting.depreciation-entry.viewAny');
    }
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Providers\AccountingServiceProvider.php -Pattern "DepreciationEntry" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
89: use Modules\Accounting\Models\DepreciationEntry;
150: Gate::policy(DepreciationEntry::class, DepreciationEntryPolicy::class);
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "Gate::authorize\('viewAny'" 
(no output)
```

### F4 — Validation and input

#### DPRE-06 · H · VAL-04 — No uniqueness rule mirrors `uq_acc_de_asset_period`, so a re-run or a re-create is a 500

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the DB unique index, including soft-delete semantics* |
| **Where** | `Modules/Accounting/app/Http/Requests/DepreciationEntryRequest.php:20-34`; index `uq_acc_de_asset_period` on `acc_depreciation_entries(fixed_asset_id, period_id)` |
| **Root cause** | The request has no `unique` rule at all. The physical unique key does **not** include `deleted_at`, so a soft-deleted entry still occupies the `(asset, period)` pair; the next create for that pair throws a duplicate-key `QueryException`, which DPRE-01 then shows as raw SQL. |
| **Consequence** | Recording a second depreciation for the same asset and period, or re-recording one after deleting the old row, fails with a database error instead of a validation message. |
| **Reproduce** | Trash the entry for asset 1, period 3, then create a new entry for the same asset and period. Expected a validation message; actual the red flash from DPRE-01 with `uq_acc_de_asset_period`. |
| **Fix approach** | Add a `Rule::unique('acc_depreciation_entries', 'fixed_asset_id')->where('period_id', ...)->ignore(current id)` rule with a clear message; do not add `whereNull('deleted_at')`, because the physical key includes trashed rows. |
| **Plan item** | DPRE-06 in `02-fix-plan.md` §5 |

```php
// DepreciationEntryRequest.php:20-34 — CURRENT (no unique rule)
        return [
            'fixed_asset_id'      => 'required|exists:acc_fixed_assets,id',
            'financial_year_id'   => 'required|exists:acc_financial_years,id',
            'period_id'           => 'required|exists:acc_accounting_periods,id',
            'depreciation_date'   => 'required|date',
            'method'              => 'required|in:SLM,WDV',
            'rate_applied'        => 'required|numeric|min:0|max:100',
            'opening_wdv'         => 'required|numeric|min:0',
            'depreciation_amount' => 'required|numeric|min:0.01',
            'closing_wdv'         => 'required|numeric|min:0',
            'days_in_use'         => 'nullable|integer|min:0|max:366',
            'voucher_id'          => 'nullable|exists:acc_vouchers,id',
            'is_posted'           => 'nullable|boolean',
            'is_active'           => 'required|boolean',
        ];
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Requests\DepreciationEntryRequest.php -Pattern "unique"
(no output)
> mysql -u root -N -e "SHOW INDEX FROM xyz_school_00000000000040008000_202627.acc_depreciation_entries;"
acc_depreciation_entries	0	PRIMARY	1	id	A	5	NULL	NULL		BTREE			YES	NULL
acc_depreciation_entries	0	uq_acc_de_asset_period	1	fixed_asset_id	A	5	NULL	NULL		BTREE			YES	NULL
acc_depreciation_entries	0	uq_acc_de_asset_period	2	period_id	A	5	NULL	NULL		BTREE			YES	NULL
```

#### DPRE-08 · H · VAL-05/VAL-07 — `prepareForValidation()` rewrites stored fields on every update

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M, raised to H: silent financial corruption) — *every field is typed and defaulted explicitly*; VAL-07 — *cross-field and business logic lives in the Form Request* |
| **Where** | `Modules/Accounting/app/Http/Requests/DepreciationEntryRequest.php:84-112`; edit form `Modules/Accounting/resources/views/depreciation-entry/edit.blade.php:25-105`; controller `:139` |
| **Root cause** | `prepareForValidation()` treats create and update identically. The edit form submits only `fixed_asset_id`, `financial_year_id`, `depreciation_date`, `depreciation_amount`, `voucher_id` and `is_active`. Every other field is re-derived: `is_posted` becomes `false`, `is_active` becomes `true` when the checkbox is absent, `method`/`rate_applied` are re-read from the current asset category, and `opening_wdv` is computed from `depreciationEntries()->sum()` which **includes the entry being edited**. |
| **Consequence** | Editing a posted entry silently unposts it and rewrites its method, rate, opening WDV and closing WDV; the asset's accumulated depreciation and book value change without any user action on those figures. |
| **Reproduce** | Open a posted entry (all five live rows are posted), change only the amount, save, then inspect the row: `is_posted` is now 0, `opening_wdv` and `closing_wdv` differ, and the show page's book value moved. |
| **Fix approach** | Make the request update-aware: preserve the stored `method`, `rate_applied`, `opening_wdv`, `days_in_use` and `is_posted` when the form does not submit them; recompute only `closing_wdv` from the preserved opening and the new amount. Treat an absent `is_active` checkbox as `false`, not `true`. |
| **Plan item** | DPRE-08 in `02-fix-plan.md` §5 (the controller half is DPRE-01 in §1) |

```php
// DepreciationEntryRequest.php:96-112 — CURRENT
        $closingWdv = $this->input('closing_wdv');
        if ($closingWdv === null || $closingWdv === '') {
            $salvage = $asset ? (float) ($asset->salvage_value ?? 0) : 0.0;
            $closingWdv = max($salvage, round((float) $openingWdv - $depAmount, 2));
        }

        $this->merge([
            'period_id'           => $periodId,
            'method'              => $method,
            'rate_applied'        => (float) $rateApplied,
            'opening_wdv'         => (float) $openingWdv,
            'closing_wdv'         => (float) $closingWdv,
            'days_in_use'         => $this->input('days_in_use') !== '' && $this->input('days_in_use') !== null ? (int) $this->input('days_in_use') : null,
            'voucher_id'          => $this->input('voucher_id') ?: null,
            'is_posted'           => $this->boolean('is_posted', false),
            'is_active'           => $this->boolean('is_active', true),
        ]);
```

**Evidence**
```
> Select-String -Path Modules\Accounting\resources\views\depreciation-entry\edit.blade.php -Pattern "name=" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
45: <select name="fixed_asset_id" id="fixed_asset_id" class="form-select" required>
59: <select name="financial_year_id" id="financial_year_id" class="form-select" required>
73: <input type="date" name="depreciation_date" id="depreciation_date" class="form-control" required value="{{ old('depreciation_date', $depreciationEntry->depreciation_date?->format('Y-m-d')) }}" />
81: <input type="number" step="0.01" name="depreciation_amount" id="depreciation_amount" class="form-control fw-bold text-end" required value="{{ old('depreciation_amount', $depreciationEntry->depreciation_amount) }}" />
88: <select name="voucher_id" id="voucher_id" class="form-select">
105: <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" {{ old('is_active', $depreciationEntry->is_active) ? 'checked' : '' }}>
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "is_posted" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
86: $validated['is_posted'] = true;
```

#### DPRE-14 · M · VAL-02 — The preview endpoint validates nothing and can 500 on a bad date

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request*; VAL-05 — *every field is typed* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:246-247`, `:262-263` |
| **Root cause** | The method casts `fixed_asset_id` with `(int)` and passes the raw `date` string to `Carbon::parse()`. No rule checks either field. |
| **Consequence** | A malformed `date` throws `InvalidFormatException` and returns a 500 JSON instead of a 422 with a field message. |
| **Reproduce** | POST `{"fixed_asset_id":1,"date":"not-a-date"}` to `/accounting/depreciation-entry/calculate-preview`. Expected 422; actual 500. |
| **Fix approach** | Move the two fields into the `DepreciationPreviewRequest` introduced by DPRE-03 (`required|integer|exists` and `nullable|date_format:Y-m-d`) and read only `validated()`. |
| **Plan item** | DPRE-03 in `02-fix-plan.md` §1 |

```php
// DepreciationEntryController.php:246-247, 262-263 — CURRENT
        $assetId = (int) $request->input('fixed_asset_id');
        $date = $request->input('date', now()->format('Y-m-d'));
...
        $purchaseDate = $asset->purchase_date ? \Carbon\Carbon::parse($asset->purchase_date) : now();
        $targetDate = \Carbon\Carbon::parse($date);
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "request->input|Carbon::parse" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
246: $assetId = (int) $request->input('fixed_asset_id');
247: $date = $request->input('date', now()->format('Y-m-d'));
262: $purchaseDate = $asset->purchase_date ? \Carbon\Carbon::parse($asset->purchase_date) : now();
263: $targetDate = \Carbon\Carbon::parse($date);
```

#### DPRE-15 · M · VAL-07 — A depreciation charge can exceed the opening book value less salvage

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M) — *cross-field and business checks go in the Form Request* |
| **Where** | `Modules/Accounting/app/Http/Requests/DepreciationEntryRequest.php:28` |
| **Root cause** | `depreciation_amount` is `required|numeric|min:0.01`; there is no upper bound relative to `opening_wdv` or `salvage_value`. The controller posts the full amount to the voucher (lines 82-83) while the stored `closing_wdv` is floored at salvage (line 99), so the two disagree. |
| **Consequence** | A typo such as 100000 instead of 10000 posts an over-sized expense and accumulated depreciation, and the asset's closing book value no longer reconciles with the posted journal. |
| **Reproduce** | Create an entry for an asset whose opening WDV is 10,000 and salvage 1,000, with a charge of 50,000. The save succeeds and the voucher is posted for 50,000. |
| **Fix approach** | Add an `after()` rule that rejects an amount greater than `opening_wdv - salvage_value` for the selected asset. |
| **Plan item** | DPRE-15 in `02-fix-plan.md` §9 (DECISION) |

```php
// DepreciationEntryRequest.php:28 — CURRENT
            'depreciation_amount' => 'required|numeric|min:0.01',
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Requests\DepreciationEntryRequest.php -Pattern "max:" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
26: 'rate_applied'        => 'required|numeric|min:0|max:100',
30: 'days_in_use'         => 'nullable|integer|min:0|max:366',
```

### F5 — Routes

#### DPRE-07 · H · RTE-01 — Restore is a state change over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:279`; link at `Modules/Accounting/resources/views/depreciation-entry/trash.blade.php:42` |
| **Root cause** | `Route::get('/depreciation-entry/{id}/restore', ...)` is registered as a GET and the trash view renders it as an `<a href>`. |
| **Consequence** | A browser prefetch, a crawler or a link opened from history can restore a deleted entry without a CSRF token or a confirmation. |
| **Reproduce** | Open `/accounting/depreciation-entry/trash/view` as the Super Admin and hover or prefetch the restore icon; the entry is restored on the GET. |
| **Fix approach** | Register restore as `POST`, render it as a form with `@csrf` in the trash view, and keep the route name and URL. |
| **Plan item** | DPRE-07 in `02-fix-plan.md` §5 (⚠ SHARED — route file) |

```php
// routes/web.php:279 — CURRENT
Route::get('/depreciation-entry/{id}/restore', [\Modules\Accounting\Http\Controllers\DepreciationEntryController::class, 'restore'])->name('depreciation-entry.restore');
```

**Evidence**
```
> Select-String -Path Modules\Accounting\routes\web.php -Pattern "depreciation-entry/.*restore" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
279: Route::get('/depreciation-entry/{id}/restore', [\Modules\Accounting\Http\Controllers\DepreciationEntryController::class, 'restore'])->name('depreciation-entry.restore');
> Select-String -Path Modules\Accounting\resources\views\depreciation-entry\trash.blade.php -Pattern "depreciation-entry.restore" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
42: <a href="{{ route('accounting.depreciation-entry.restore', $entry->id) }}" class="btn btn-sm btn-outline-success" title="Restore">
```

### F6 — Controller shape

#### DPRE-17 · M · CTL-03 — `restore` and `forceDelete` use `$id` and `findOrFail` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:213`, `:229`; routes `web.php:279-280` |
| **Root cause** | The two custom trash routes take `{id}` and the methods resolve the model by hand; the five resource methods use implicit binding. |
| **Consequence** | The controller has two binding styles, and the trash routes cannot use `->withTrashed()` model binding. There is no user-visible failure today. |
| **Reproduce** | Static only — the signatures and route parameters differ from the resource methods. |
| **Fix approach** | Either bind `{depreciationEntry}` with `->withTrashed()` on both routes (⚠ route file), or record the current shape as accepted. |
| **Plan item** | DPRE-17 in `02-fix-plan.md` §9 (DECISION) |

```php
// DepreciationEntryController.php:213, 229 — CURRENT
    public function restore($id)
...
    public function forceDelete($id)
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "public function restore|public function forceDelete" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
213: public function restore($id)
229: public function forceDelete($id)
> Select-String -Path Modules\Accounting\routes\web.php -Pattern "depreciation-entry/\{id\}" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
279: Route::get('/depreciation-entry/{id}/restore', [\Modules\Accounting\Http\Controllers\DepreciationEntryController::class, 'restore'])->name('depreciation-entry.restore');
280: Route::delete('/depreciation-entry/{id}/force-delete', [\Modules\Accounting\Http\Controllers\DepreciationEntryController::class, 'forceDelete'])->name('depreciation-entry.forceDelete');
```

#### DPRE-19 · L · CTL-04 — No public method declares a return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:21-244` (all 12 public methods) |
| **Root cause** | Every method is declared `public function name(...)` with no `: View`, `: RedirectResponse` or `: JsonResponse`. |
| **Consequence** | A wrong return branch (for example `return back()` from a method expected to return a view) is a runtime `TypeError` rather than a compile-time catch. |
| **Reproduce** | Static only. |
| **Fix approach** | Add the return types and the three imports (`View`, `RedirectResponse`, `JsonResponse`). |
| **Plan item** | DPRE-19 in `02-fix-plan.md` §5 |

```php
// DepreciationEntryController.php:21-244 — CURRENT (signatures only)
    public function index(Request $request)
    public function create()
    public function store(DepreciationEntryRequest $request)
    public function show(DepreciationEntry $depreciationEntry)
    public function edit(DepreciationEntry $depreciationEntry)
    public function update(DepreciationEntryRequest $request, DepreciationEntry $depreciationEntry)
    public function destroy(DepreciationEntry $depreciationEntry)
    public function toggleStatus(Request $request, DepreciationEntry $depreciationEntry)
    public function trashed()
    public function restore($id)
    public function forceDelete($id)
    public function calculatePreview(Request $request)
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "public function" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
21: public function index(Request $request)
32: public function create()
44: public function store(DepreciationEntryRequest $request)
111: public function show(DepreciationEntry $depreciationEntry)
120: public function edit(DepreciationEntry $depreciationEntry)
134: public function update(DepreciationEntryRequest $request, DepreciationEntry $depreciationEntry)
158: public function destroy(DepreciationEntry $depreciationEntry)
183: public function toggleStatus(Request $request, DepreciationEntry $depreciationEntry)
204: public function trashed()
213: public function restore($id)
229: public function forceDelete($id)
244: public function calculatePreview(Request $request)
```

### F7 — Models

#### DPRE-20 · L · MDL-04 — Three relationship methods point at the same `computed_by` column; two are unused

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods are purposeful and return-typed* |
| **Where** | `Modules/Accounting/app/Models/DepreciationEntry.php:67-80` |
| **Root cause** | `computedByUser()`, `computer()` and `creator()` all `belongsTo(User::class, 'computed_by')`. The list partial uses only `computedByUser`; `computer` and `creator` have no caller. `creator` is also semantically wrong (there is no `created_by` column). |
| **Consequence** | A reader cannot tell which relation is the real one, and dead aliases survive future refactors. No runtime failure. |
| **Reproduce** | Static only. |
| **Fix approach** | Delete `computer()` and `creator()`; keep `computedByUser()`. |
| **Plan item** | DPRE-20 in `02-fix-plan.md` §5 |

```php
// DepreciationEntry.php:67-80 — CURRENT
    public function computedByUser(): BelongsTo
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'computed_by');
    }

    public function computer(): BelongsTo
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'computed_by');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'computed_by');
    }
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Models\DepreciationEntry.php -Pattern "public function (computedByUser|computer|creator)" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
67: public function computedByUser(): BelongsTo
72: public function computer(): BelongsTo
77: public function creator(): BelongsTo
> Select-String -Path Modules\Accounting\resources\views\pages\partials\assets-integration\_depreciation-entries.blade.php -Pattern "computedByUser|computer|creator" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
216: @if($entry->computedByUser)
218: <i class="bi bi-person-badge text-primary me-1"></i>{{ $entry->computedByUser->name }}
```

### F8 — Services and jobs

#### DPRE-16 · M · SVC-02 — `VoucherService` is resolved with `app()` inside the method

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection, not `app(Foo::class)` mid-method* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:71-72` |
| **Root cause** | The controller has no constructor and resolves the service with `app(VoucherService::class)` only on the auto-post branch. |
| **Consequence** | The dependency is hidden from the class's public surface and cannot be substituted in a test without the container; the controller is harder to read. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `__construct(private readonly VoucherService $voucherService)` and call `$this->voucherService->create(...)`. |
| **Plan item** | DPRE-01 in `02-fix-plan.md` §1 |

```php
// DepreciationEntryController.php:71-72 — CURRENT
                            /** @var VoucherService $voucherService */
                            $voucherService = app(VoucherService::class);
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "app\(VoucherService" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
72: $voucherService = app(VoucherService::class);
```

### F9 — Queries and performance

#### DPRE-18 · M · QRY-15/QRY-03 — The create and edit forms load every active asset and 100 full voucher models

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *do not load every row of a big table for a form*; QRY-03 (M) — *select only the columns used* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:36-41` (`create`) and `:126-131` (`edit`) |
| **Root cause** | `FixedAsset::with('assetCategory')->...->get()` returns whole models and eager-loads a relation neither view uses; `Voucher::...->get()` returns every column of up to 100 rows; `$periods` is loaded and passed but neither view renders it. |
| **Consequence** | The form's cost grows with the asset register and voucher table, even though each dropdown needs three or seven columns. Five assets and 30 vouchers today; unbounded later. |
| **Reproduce** | Static only — open `/accounting/depreciation-entry/create` and count the columns returned by the two queries. |
| **Fix approach** | Select `id, name, asset_code` for assets; select the columns `formatted_number` needs for vouchers and eager-load `voucherType`; drop the unused `assetCategory` eager load and the unused `$periods` query. |
| **Plan item** | DPRE-18 in `02-fix-plan.md` §6 |

```php
// DepreciationEntryController.php:36-41 — CURRENT (edit repeats it at 126-131)
        $fixedAssets = FixedAsset::with('assetCategory')->where('is_active', true)->where('status', 'Active')->orderBy('name')->get();
        $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
        $periods = \Modules\Accounting\Models\AccountingPeriod::where('is_active', true)->orderBy('start_date')->get();
        $vouchers = Voucher::orderByDesc('voucher_date')->limit(100)->get();

        return view('accounting::depreciation-entry.create', compact('fixedAssets', 'financialYears', 'periods', 'vouchers'));
```

**Evidence**
```
> mysql -u root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_fixed_assets; SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_vouchers; SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_accounting_periods;"
5
30
12
> Select-String -Path Modules\Accounting\resources\views\depreciation-entry\*.blade.php -Pattern "\$periods|\$fixedAssets|\$vouchers" | ForEach-Object {"$([System.IO.Path]::GetFileName($_.Path)):$($_.LineNumber): $($_.Line.Trim())"}
create.blade.php:33: @foreach($fixedAssets as $asset)
create.blade.php:127: @foreach($vouchers as $v)
edit.blade.php:47: @foreach($fixedAssets as $asset)
edit.blade.php:90: @foreach($vouchers as $v)
```

#### DPRE-21 · L · QRY-02 — The trash list paginates 15 rows and has no distinct page name

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H, lowered to L: the list is paginated; only the page size and page name differ from the standard) — *lists are paginated* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:208` |
| **Root cause** | `paginate(15)` uses the default page size and the default `page` query key. |
| **Consequence** | The trash list does not match the module's 10-row standard and shares the `page` key with any other paginator on the same request. Cosmetic today. |
| **Reproduce** | Open `/accounting/depreciation-entry/trash/view`; the page size is 15. |
| **Fix approach** | `paginate(10, ['*'], 'depreciationTrashPage')`. |
| **Plan item** | DPRE-21 in `02-fix-plan.md` §6 |

```php
// DepreciationEntryController.php:208 — CURRENT
        $entries = DepreciationEntry::onlyTrashed()->with(['fixedAsset.assetCategory', 'financialYear', 'period', 'voucher', 'computedByUser'])->orderByDesc('deleted_at')->paginate(15);
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "paginate" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
208: $entries = DepreciationEntry::onlyTrashed()->with(['fixedAsset.assetCategory', 'financialYear', 'period', 'voucher', 'computedByUser'])->orderByDesc('deleted_at')->paginate(15);
```

#### DPRE-22 · L · QRY-03 — `show` and `trashed` eager-load relations their views never use

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M, lowered to L: one extra query each, fixed rows) — *select/eager-load only what you use* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:115` (`show`), `:208` (`trashed`) |
| **Root cause** | `show` loads `period` and `computedByUser`; `trashed` loads `period`, `voucher` and `computedByUser`; neither view reads them. |
| **Consequence** | Two and three unnecessary queries on each page. |
| **Reproduce** | Static only. |
| **Fix approach** | `show`: keep `fixedAsset.assetCategory`, `financialYear`, `voucher`. `trashed`: keep `fixedAsset.assetCategory`, `financialYear`. |
| **Plan item** | DPRE-22 in `02-fix-plan.md` §6 (the `trashed` half is closed by DPRE-21) |

```php
// DepreciationEntryController.php:115 — CURRENT (trashed repeats the pattern at 208)
        $depreciationEntry->load(['fixedAsset.assetCategory', 'financialYear', 'period', 'voucher', 'computedByUser']);
```

**Evidence**
```
> Select-String -Path Modules\Accounting\resources\views\depreciation-entry\show.blade.php -Pattern "computedByUser|period" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
(no output)
> Select-String -Path Modules\Accounting\resources\views\depreciation-entry\trash.blade.php -Pattern "computedByUser|period|voucher" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
(no output)
```

### F10 — Views

#### DPRE-23 · L · VIEW-01 — The show page triggers two `SUM` queries through `FixedAsset` accessors

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H, lowered to L: a single row, two queries) — *no queries during Blade rendering; pass data from the controller* |
| **Where** | `Modules/Accounting/resources/views/depreciation-entry/show.blade.php:78`, `:82`; accessor `Modules/Accounting/app/Models/FixedAsset.php:65-70` |
| **Root cause** | The view reads `$depreciationEntry->fixedAsset->accumulated_depreciation` and `->current_value`. Both call `getAccumulatedDepreciationAttribute()`, which runs `depreciationEntries()->where('is_posted', true)->sum(...)`; `current_value` calls it a second time. |
| **Consequence** | The show page runs two extra `SUM` queries after the controller has already loaded the relations. |
| **Reproduce** | Open `/accounting/depreciation-entry/1` with query logging on; two `select sum(depreciation_amount)` queries run during rendering. |
| **Fix approach** | Compute the accumulated total once in `show()` and pass it, with the current book value, to the view; print the variables. |
| **Plan item** | DPRE-23 in `02-fix-plan.md` §7 |

```php
// show.blade.php:78, 82 — CURRENT
                                <strong class="text-danger">₹ {{ number_format((float) $depreciationEntry->fixedAsset->accumulated_depreciation, 2) }}</strong>
...
                                <strong class="text-success">₹ {{ number_format((float) $depreciationEntry->fixedAsset->current_value, 2) }}</strong>
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Models\FixedAsset.php -Pattern "getAccumulatedDepreciationAttribute|depreciationEntries\(\)" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
65: public function getAccumulatedDepreciationAttribute(): float
67: return (float) $this->depreciationEntries()
> Select-String -Path Modules\Accounting\resources\views\depreciation-entry\show.blade.php -Pattern "accumulated_depreciation|current_value" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
78: <strong class="text-danger">₹ {{ number_format((float) $depreciationEntry->fixedAsset->accumulated_depreciation, 2) }}</strong>
82: <strong class="text-success">₹ {{ number_format((float) $depreciationEntry->fixedAsset->current_value, 2) }}</strong>
```

### F11 — Security and tenancy

Clean — `Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "env\(|\?\? 1|Log::.*request|->all\(\)"` returns no output; the routes carry the tenant + auth middleware (see §4), and the model has no media/tenant-path handling.

### F12 — Style

#### DPRE-24 · L · STY-02 — The controller is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php` (whole file) |
| **Root cause** | Pint reports nine fixers: `single_quote`, `fully_qualified_strict_types`, `concat_space`, `method_chaining_indentation`, `not_operator_with_successor_space`, `blank_line_before_statement`, `ordered_imports`, `binary_operator_spaces`, `single_blank_line_at_eof`. |
| **Consequence** | The file violates the repo's formatter baseline; a later `--dirty` run would reformat unrelated lines. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php --format agent`. |
| **Fix approach** | Apply the code items first, then run Pint on this file. |
| **Plan item** | DPRE-24 in `02-fix-plan.md` §8 |

```php
// DepreciationEntryController.php — CURRENT (Pint finding, not source lines)
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\DepreciationEntryController.php","fixers":["single_quote","fully_qualified_strict_types","concat_space","method_chaining_indentation","not_operator_with_successor_space","blank_line_before_statement","ordered_imports","binary_operator_spaces","single_blank_line_at_eof"]}]}
```

**Evidence**
```
> vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\DepreciationEntryController.php","fixers":["single_quote","fully_qualified_strict_types","concat_space","method_chaining_indentation","not_operator_with_successor_space","blank_line_before_statement","ordered_imports","binary_operator_spaces","single_blank_line_at_eof"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 wrong data | 2 delete before replace | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | DPRE-15 | ok | ok | DPRE-06 | ok (DB unique key) | DPRE-02 | ok | DPRE-25 |
| `update` | DPRE-08 | ok | ok | DPRE-06 | ok | DPRE-02 | ok | DPRE-25 |
| `destroy` | ok | ok (soft delete) | ok | DPRE-06 | ok | DPRE-02 | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | DPRE-02 | ok | ok |
| `restore` | ok | ok | ok | ok (row already owns the key) | ok | DPRE-02 | ok | ok |
| `forceDelete` | DPRE-10 | DPRE-10 | ok | ok | ok | DPRE-02 | ok | ok |

#### DPRE-09 · H · VAL-07 — The preview always returns straight-line figures and ignores the asset's own method and rate

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M, raised to H: the create form prefills the posted amount from it) — *business calculations follow the selected method* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:255-269`, `:295`; prefill at `create.blade.php:206-208` |
| **Root cause** | `$usefulLife`, `$depRate` and `$method` are read only from `$asset->assetCategory`, so an asset-level `depreciation_method`/`depreciation_rate` override is ignored. The annual figure is always `(cost - salvage) / usefulLife`, even when `$method` is `WDV`; the result is returned as `suggested_amount` and the create page writes it into the amount input when the field is empty. |
| **Consequence** | A WDV asset, or an asset whose own rate/method differs from its category, is prefilled with an SLM charge; the stored `method` (set by the FormRequest from the asset) then disagrees with the amount. |
| **Reproduce** | Open create, pick a WDV asset, and compare the prefilled amount with `opening WDV × rate`. The prefilled figure is `(cost - salvage) / life`. |
| **Fix approach** | Read the effective method/rate/life from the asset (`getEffectiveDepreciationMethod`, `getEffectiveDepreciationRate`, `getEffectiveUsefulLife`) and compute WDV as `opening WDV × rate / 100`. |
| **Plan item** | DPRE-09 in `02-fix-plan.md` §9 (DECISION) |

```php
// DepreciationEntryController.php:255-269 — CURRENT
        $cat = $asset->assetCategory;
        $cost = (float) $asset->purchase_cost;
        $salvage = (float) $asset->salvage_value;
        $usefulLife = max(1.0, (float) ($cat?->useful_life_years ?? 1.0));
        $depRate = (float) ($cat?->depreciation_rate ?? 0.0);
        $method = $cat?->depreciation_method ?? 'SLM';

        // Calculate age in years from purchase date to depreciation date
        $purchaseDate = $asset->purchase_date ? \Carbon\Carbon::parse($asset->purchase_date) : now();
        $targetDate = \Carbon\Carbon::parse($date);
        $daysDiff = max(0, $purchaseDate->diffInDays($targetDate));
        $ageYears = round($daysDiff / 365.25, 2);

        // Formulas:
        // 1. Annual Depreciation = (Purchase Cost - Salvage Value) / Useful Life (Years)
        $annualDepreciation = max(0.0, round(($cost - $salvage) / $usefulLife, 2));
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "assetCategory|getEffective|depreciation_method|depreciation_rate|annualDepreciation|suggested_amount" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
255: $cat = $asset->assetCategory;
258: $depRate = (float) ($cat?->depreciation_rate ?? 0.0);
259: $method = $cat?->depreciation_method ?? 'SLM';
269: $annualDepreciation = max(0.0, round(($cost - $salvage) / $usefulLife, 2));
295: 'suggested_amount' => $annualDepreciation,
> Select-String -Path Modules\Accounting\app\Models\FixedAsset.php -Pattern "getEffectiveDepreciationMethod|getEffectiveDepreciationRate|getEffectiveUsefulLife" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
185: public function getEffectiveDepreciationMethod(): string
190: public function getEffectiveDepreciationRate(): float
199: public function getEffectiveUsefulLife(): int
```

#### DPRE-10 · H · VAL-07 — Permanently deleting a posted entry leaves its journal voucher posted

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M, raised to H: the ledger and the sub-ledger diverge) — *business rules guard irreversible actions* |
| **Where** | `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:229-242` |
| **Root cause** | `forceDelete()` calls `$entry->forceDelete()` with no check on `is_posted` or `voucher_id`, and no reversal of the linked voucher. |
| **Consequence** | A posted entry disappears while its voucher remains in the ledger; `FixedAsset::accumulated_depreciation` drops, so the asset's book value rises with no journal entry to explain it. |
| **Reproduce** | As the Super Admin, permanently delete a posted entry with a linked voucher (or the seeded posted rows); the entry is gone and the voucher still shows in `/accounting/voucher/{id}`. |
| **Fix approach** | Refuse force-delete while `is_posted` is true (fixed 422 message), or reverse the voucher in the same transaction before deleting. |
| **Plan item** | DPRE-10 in `02-fix-plan.md` §9 (DECISION) |

```php
// DepreciationEntryController.php:229-239 — CURRENT
    public function forceDelete($id)
    {
        Gate::authorize('tenant.accounting.depreciation-entry.forceDelete');

        $entry = DepreciationEntry::withTrashed()->findOrFail($id);
        $entry->forceDelete();

        activityLog($entry, 'Deleted', [
            'message' => 'Depreciation Entry permanently deleted.',
            'id'      => $entry->id,
        ]);
```

**Evidence**
```
> Select-String -Path Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php -Pattern "is_posted" | ForEach-Object {"$($_.LineNumber): $($_.Line.Trim())"}
86: $validated['is_posted'] = true;
> mysql -u root -N -e "SELECT id, is_posted, voucher_id FROM xyz_school_00000000000040008000_202627.acc_depreciation_entries;"
1	1	NULL
2	1	NULL
3	1	NULL
4	1	NULL
5	1	NULL
```

#### DPRE-25 · L · VAL-05 — `days_in_use` is never populated

| Field | Value |
|---|---|
| **Rule** | VAL-05 (L, informational) — *every field is typed and written* |
| **Where** | `Modules/Accounting/app/Http/Requests/DepreciationEntryRequest.php:108`; no field in `create.blade.php` or `edit.blade.php`; no assignment in the controller |
| **Root cause** | The request merges `null` when `days_in_use` is absent, neither form submits it, and the controller never computes it. The column comment says it is meant for pro-rata in the year of purchase or disposal. |
| **Consequence** | The column is always `NULL`, so any report that uses it (the accounting reporting views) has no pro-rata data. |
| **Reproduce** | Create or edit any entry and inspect the row: `days_in_use` is `NULL`. |
| **Fix approach** | Decide whether to compute it from `purchase_date`/`put_to_use_date` and the period, or drop it. No code change is proposed in this pass. |
| **Plan item** | none — see `02-fix-plan.md` §10 (informational) |

```php
// DepreciationEntryRequest.php:108 — CURRENT
            'days_in_use'         => $this->input('days_in_use') !== '' && $this->input('days_in_use') !== null ? (int) $this->input('days_in_use') : null,
```

**Evidence**
```
> Select-String -Path Modules\Accounting\resources\views\depreciation-entry\create.blade.php,Modules\Accounting\resources\views\depreciation-entry\edit.blade.php -Pattern "days_in_use"
(no output)
> mysql -u root -N -e "SELECT COUNT(*) AS total, SUM(days_in_use IS NULL) AS null_days FROM xyz_school_00000000000040008000_202627.acc_depreciation_entries;"
5	5
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/resources/views/pages/partials/assets-integration/_depreciation-entries.blade.php` | The tab, export button, status switch and row actions all test `tenant.accounting.depreciation-entry.*`, the namespace that does not exist (DPRE-02). Until the key is added and granted, the whole tab stays hidden for every non-Super-Admin role. | AUTH-01 | `gaurav/Accounting/AccDashboardController` (CLAIMED, report not written) |
| `Modules/Accounting/resources/views/pages/partials/assets-integration/_depreciation-entries.blade.php` | The partial carries its own create modal (line 280 posts to `accounting.depreciation-entry.store`) while this controller also routes a full `/create` page. Two create UIs for one resource; the same rules must be maintained in both. | CTL-05 | `gaurav/Accounting/AccDashboardController` |
| `Modules/Accounting/app/Models/FixedAsset.php` | `getAccumulatedDepreciationAttribute()` runs a `SUM` query on every access. The show page calls it twice (DPRE-23); any list that prints it would run one query per row. | QRY-01 | `gaurav/Accounting/FixedAssetController` |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | `updating()` falls back to `updated_by = Auth::id() ?? 1`. `DepreciationEntry` has no `updated_by` column, so this path is not reached here; the hard-coded `1` remains a module-wide risk. | SEC-03 | `gaurav/Accounting/AccountingStatusMasterController` |
| `Modules/Accounting/app/Services/AccountingContext.php` | `getUserId()` / `getCampusId()` fall back to hard-coded `1`. Not reached by `DepreciationEntry` (it has no `created_by` or `campus_id` fillable), so the risk is latent. | SEC-03 | `gaurav/Accounting/AccountGroupController` |
| `Modules/Accounting/app/Services/VoucherService.php` | Internals not audited; the controller's auto-post path calls `create()` inside its transaction. Owned by `VoucherController` (CLAIMED). | — | `gaurav/Accounting/VoucherController` |

## 8. Not covered, and why

- **Scanner and self-check were skipped.** `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are missing, and `_tools/scan.php` must not be run under the binding tooling override. F1–F13 were worked manually with `read`/`grep`/`Select-String`, `php -l`, Pint, the route probe and read-only MySQL queries. This report's shape was not machine-verified.
- **No browser, queue or test run.** D4 forbids tests. Every "Reproduce" line is either static evidence or a described manual browser action; no request was executed against the app.
- **`VoucherService::create()` internals** (voucher numbering, item/ledger rows, posting rules) were not audited. They are owned by `VoucherController` (CLAIMED, report not written). Only the call shape and the surrounding transaction were checked.
- **`FixedAsset`, `AssetCategory`, `FinancialYear`, `AccountingPeriod`, `Voucher`, `VoucherType`** were read only where this controller touches them; their internal rules, casts and policies are owned by their own reports.
- **The Assets Integration list partial** is owned by `AccDashboardController` (CLAIMED, report not written). It was checked only for this controller's routes, permission strings and create-modal duplication.
- **The tenant database was queried read-only** (`SHOW INDEX`, `SHOW COLUMNS`, `COUNT`). No row was created, updated or deleted. The live counts are a snapshot of the test tenant at audit time.
- **`glb_menus` / menu configuration** was not checked; the tab visibility comes from the partial and its `viewAny` permission, not from a menu row.
- **`activityLog()` internals** (the common helper) were not audited. Its placement is audited per DPRE-05/DPRE-12.
- **Production environment** was not exercised; the `env()` and config-cache risks (SEC-01) are therefore static only, and none were found in this controller.
