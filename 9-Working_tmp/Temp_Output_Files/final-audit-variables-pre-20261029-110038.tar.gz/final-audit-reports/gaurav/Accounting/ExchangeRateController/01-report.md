# Final Audit — Accounting / ExchangeRateController

**Audited:** 2026-10-22 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php` (231 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /accounting/configurations?tab=exchange-rates` (the list, rendered by `AccDashboardController@configurations`); `GET /accounting/exchange-rate` (redirects there); `GET /accounting/exchange-rate/create`; `GET /accounting/exchange-rate/{exchange_rate}`; `GET /accounting/exchange-rate/{exchange_rate}/edit`; `GET /accounting/exchange-rate/trash/view` |
| Menu path | Accounting → Configurations → Exchange Rates tab |
| Who uses it | Super Admin, School Admin, Management, Account Staff, Account Manager — all five roles hold all seven `tenant.accounting.exchange-rate.*` permissions (measured on `test.localhost`, see evidence in §6 F3) |
| What a user does here | Reads the table of currency-to-base exchange rates on the Configurations tab, adds a rate in the "Add Exchange Rate" modal or on the create page, edits a rate, flips its Active switch, moves a row to the trash, and restores or permanently deletes a trashed rate |
| Tables written | `acc_exchange_rates` (create/update/soft-delete/restore/force-delete/toggle) and `sys_activity_logs` (every mutation) |
| Tables read | `acc_exchange_rates`, `acc_currencies`, plus `sys_permissions`/`sys_roles`/`sys_role_has_permissions_jnt` for authorization |
| Live data | tenant `test.localhost` (id `00000000-0000-4000-8000-000000000001`): `acc_exchange_rates` 4 live rows, 0 trashed; `acc_currencies` 5 live rows, 4 selectable (active, non-base) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No — this controller is not production-ready. The single worst finding is EXRT-01: every one of the six mutating methods catches `\Throwable` and shows `$e->getMessage()` to the user, so a duplicate-rate SQL error is printed on screen with table and column names. Behind it sit three silent-data problems: the Active switch is validated but discarded by the model (EXRT-12), the request turns an unticked box back into `true` (EXRT-07), and the composite unique index is not mirrored in validation, so a trashed rate blocks re-entry with a raw SQL failure (EXRT-06). Effort to clear the plan: small-to-medium, roughly 3–4 hours including manual verification.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 5 | 4 | 4 | 1 | 14 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | EXRT-01, EXRT-02, EXRT-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | EXRT-04 | F9 Queries/Perf | EXRT-13 |
| F3 Authorization | EXRT-05 | F10 Views | clean |
| F4 Validation | EXRT-06, EXRT-07, EXRT-08 | F11 Security/Tenancy | clean |
| F5 Routes | EXRT-09 | F12 Style | EXRT-14 |
| F6 Controller shape | EXRT-10, EXRT-11 | F13 Deep read | see the table in F13 (no new IDs) |
| F7 Models | EXRT-12 | | |

DECISION counts plan items, not findings: EXRT-09 (route method) is the one DECISION item and is also the H finding listed above.

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php` | controller | 231 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/ExchangeRate.php` | model (pre-assigned) | 58 | this report | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php` | FormRequest (pre-assigned) | 68 | this report | ✅ |
| 4 | `Modules/Accounting/app/Models/Currency.php` | model | 74 | ↗ [gaurav/Accounting/CurrencyController](../CurrencyController/01-report.md) | ↗ linked |
| 5 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | base model | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 6 | `Modules/Accounting/resources/views/exchange-rate/create.blade.php` | view | 111 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/exchange-rate/edit.blade.php` | view | 132 | this report | ✅ |
| 8 | `Modules/Accounting/resources/views/exchange-rate/show.blade.php` | view | 121 | this report | ✅ |
| 9 | `Modules/Accounting/resources/views/exchange-rate/trash.blade.php` | view | 96 | this report | ✅ |
| 10 | `Modules/Accounting/resources/views/exchange-rate/index.blade.php` | view | 100 | this report | ❌ not rendered — no route renders it (see §7 note 2) |
| 11 | `Modules/Accounting/resources/views/pages/partials/setup-masters/_exchange-rates.blade.php` | view (shared list) | 192 | ↗ [gaurav/Accounting/AccDashboardController](../AccDashboardController/01-report.md) (CLAIMED — may not be finished) | ↗ linked — only its use of this controller's routes checked |
| 12 | `Modules/Accounting/routes/web.php` | route file (shared) | — | shared | read only (lines 381–385) |
| 13 | `database/migrations/tenant/2026_09_16_100013_create_acc_exchange_rates_table.php` | migration | 51 | shared | read only |
| 14 | `database/migrations/tenant/2026_09_16_130001_add_soft_deletes_and_is_active_to_accounting_tables.php` | migration | 153 | shared | read only |
| 15 | `config/permissionslist.php` | shared config | — | shared | read only (lines 176–184, 624) |
| 16 | `app/Traits/AuthorizesTenantFeature.php` | common trait | 56 | common — not audited | usage checked |
| 17 | `app/Helpers/activityLog.php` | common helper | 51 | common — not audited | usage checked |
| 18 | `resources/views/components/backend/table/status-switch.blade.php` | common component | 48 | common — not audited | usage checked |
| 19 | `resources/views/components/backend/table/action-trashed.blade.php` | common component | 76 | common — not audited | usage checked |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/exchange-rate                                accounting.exchange-rate.index      Modules\Accounting\Http\Controllers\ExchangeRateController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/exchange-rate                                accounting.exchange-rate.store      Modules\Accounting\Http\Controllers\ExchangeRateController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/exchange-rate/create                         accounting.exchange-rate.create     Modules\Accounting\Http\Controllers\ExchangeRateController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/exchange-rate/trash/view                     accounting.exchange-rate.trashed    Modules\Accounting\Http\Controllers\ExchangeRateController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/exchange-rate/{exchange_rate}                accounting.exchange-rate.show       Modules\Accounting\Http\Controllers\ExchangeRateController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/exchange-rate/{exchange_rate}                accounting.exchange-rate.update     Modules\Accounting\Http\Controllers\ExchangeRateController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/exchange-rate/{exchange_rate}                accounting.exchange-rate.destroy    Modules\Accounting\Http\Controllers\ExchangeRateController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/exchange-rate/{exchange_rate}/edit           accounting.exchange-rate.edit       Modules\Accounting\Http\Controllers\ExchangeRateController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/exchange-rate/{exchange_rate}/toggle-status  accounting.exchange-rate.toggleStatus Modules\Accounting\Http\Controllers\ExchangeRateController@toggleStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/exchange-rate/{id}/force-delete              accounting.exchange-rate.forceDelete Modules\Accounting\Http\Controllers\ExchangeRateController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/exchange-rate/{id}/restore                   accounting.exchange-rate.restore    Modules\Accounting\Http\Controllers\ExchangeRateController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none — all 11 public methods have a route.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 18 | GET /accounting/exchange-rate | `tenant.accounting.exchange-rate.viewAny` | — | — | — (redirect) | — |
| `create` | 25 | GET /accounting/exchange-rate/create | `tenant.accounting.exchange-rate.create` | — | — | reads `acc_currencies` | — |
| `store` | 34 | POST /accounting/exchange-rate | `tenant.accounting.exchange-rate.create` (FormRequest + controller) | controller, manual begin/commit | `'Created'` | `acc_exchange_rates`, `sys_activity_logs` | EXRT-01, EXRT-03, EXRT-04, EXRT-05, EXRT-06, EXRT-08, EXRT-12 |
| `show` | 68 | GET /accounting/exchange-rate/{exchange_rate} | `tenant.accounting.exchange-rate.view` | — | — | reads `acc_exchange_rates`, `acc_currencies` | — |
| `edit` | 75 | GET /accounting/exchange-rate/{exchange_rate}/edit | `tenant.accounting.exchange-rate.update` | — | — | reads `acc_currencies` | — |
| `update` | 84 | PUT/PATCH /accounting/exchange-rate/{exchange_rate} | `tenant.accounting.exchange-rate.update` (FormRequest + controller) | controller, manual begin/commit | `'Updated'` | `acc_exchange_rates`, `sys_activity_logs` | EXRT-01, EXRT-03, EXRT-04, EXRT-05, EXRT-06, EXRT-07, EXRT-12 |
| `destroy` | 118 | DELETE /accounting/exchange-rate/{exchange_rate} | `tenant.accounting.exchange-rate.delete` | controller, manual begin/commit | `'Deleted'` | `acc_exchange_rates` (soft), `sys_activity_logs` | EXRT-01, EXRT-03, EXRT-04, EXRT-06 |
| `toggleStatus` | 144 | POST /accounting/exchange-rate/{exchange_rate}/toggle-status | `tenant.accounting.exchange-rate.update` | controller, manual begin/commit | `'Toggled'` | `acc_exchange_rates`, `sys_activity_logs` | EXRT-01, EXRT-03, EXRT-04 |
| `trashed` | 171 | GET /accounting/exchange-rate/trash/view | `tenant.accounting.exchange-rate.restore` | — | — | — (reads `acc_exchange_rates`, `acc_currencies`) | EXRT-13 |
| `restore` | 180 | GET /accounting/exchange-rate/{id}/restore | `tenant.accounting.exchange-rate.restore` | controller, manual begin/commit | `'Restored'` | `acc_exchange_rates`, `sys_activity_logs` | EXRT-01, EXRT-02, EXRT-03, EXRT-04, EXRT-09, EXRT-10, EXRT-12 |
| `forceDelete` | 206 | DELETE /accounting/exchange-rate/{id}/force-delete | `tenant.accounting.exchange-rate.forceDelete` | controller, manual begin/commit | `'Permanently Deleted'` | `acc_exchange_rates` (hard), `sys_activity_logs` | EXRT-01, EXRT-02, EXRT-03, EXRT-04, EXRT-10 |

## 6. Findings

### F1 — Errors

#### EXRT-01 · B · ERR-01 — Raw exception text is shown to the user by all six mutations

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php:57-65`, `106-115`, `136-141`, `163-168`, `198-203`, `224-229`; methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | The class is written in the old Variant-H style: every mutation opens a manual transaction and wraps it in `catch (\Throwable $e)` that answers with `'…: ' . $e->getMessage()`. D1 settled that controllers use the Laravel idiom, so the six catches should not exist at all. |
| **Consequence** | A duplicate rate or a missing foreign row prints the SQL error (table name, column name, SQLSTATE) in a red flash or a JSON 500, telling the user — and anyone who screenshots it — the schema. |
| **Reproduce** | Add an exchange rate for a currency/date/type that already exists: the flash reads `Failed to create Exchange Rate: SQLSTATE[23000]: Integrity constraint violation… uq_acc_fx_rate`. |
| **Fix approach** | Delete all six `try/catch` blocks and let one `DB::transaction(fn () => …)` per mutation roll back and rethrow; the central handler in `bootstrap/app.php` logs and renders. |
| **Plan item** | EXRT-01 in `02-fix-plan.md` §1 |

```php
// ExchangeRateController.php:57-65 — CURRENT
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Exchange Rate', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Exchange Rate: ' . $e->getMessage());
        }
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php" -Pattern "getMessage\(\)" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
60: 'error' => $e->getMessage(),
64: return back()->withInput()->with('error', 'Failed to create Exchange Rate: ' . $e->getMessage());
110: 'error' => $e->getMessage(),
114: return back()->withInput()->with('error', 'Failed to update Exchange Rate: ' . $e->getMessage());
138: Log::error('Failed to delete Exchange Rate', ['id' => $exchangeRate->id, 'error' => $e->getMessage()]);
140: return back()->with('error', 'Failed to delete Exchange Rate: ' . $e->getMessage());
165: Log::error('Failed to toggle Exchange Rate status', ['id' => $exchangeRate->id, 'error' => $e->getMessage()]);
167: return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
200: Log::error('Failed to restore Exchange Rate', ['id' => $id, 'error' => $e->getMessage()]);
202: return back()->with('error', 'Failed to restore Exchange Rate: ' . $e->getMessage());
226: Log::error('Failed to force delete Exchange Rate', ['id' => $id, 'error' => $e->getMessage()]);
228: return back()->with('error', 'Failed to delete Exchange Rate: ' . $e->getMessage());
```

#### EXRT-02 · H · ERR-02 — A missing record is turned into a redirect instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php:184-188` (`restore()`), `210-214` (`forceDelete()`) |
| **Root cause** | `findOrFail($id)` sits inside the `try`, and the generic `catch (\Throwable $e)` swallows its `ModelNotFoundException` (the same catch that exists because of EXRT-01). |
| **Consequence** | Opening an old restore/force-delete link for a row that is already gone shows "Failed to restore Exchange Rate: No query results for model [ExchangeRate]…" with HTTP 302, instead of a plain 404. |
| **Reproduce** | Open `/accounting/exchange-rate/999999/restore` (or delete the same trashed row twice from two tabs). Expected 404; actual redirect with the model class name in the flash. |
| **Fix approach** | Remove the catch (EXRT-01) so `findOrFail()` rethrows; keep the lookup inside the transaction so it still locks nothing and still rolls back cleanly. |
| **Plan item** | none of its own — covered by the EXRT-01 rewrite (see plan §10) |

```php
// ExchangeRateController.php:184-188 — CURRENT
        DB::beginTransaction();
        try {
            $model = ExchangeRate::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php" -Pattern "findOrFail" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
186: $model = ExchangeRate::onlyTrashed()->findOrFail($id);
212: $model = ExchangeRate::withTrashed()->findOrFail($id);
```

#### EXRT-03 · M · ERR-05 — Exception logging stores the message text instead of the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php:59-62`, `108-112`, `138`, `165`, `200`, `226` |
| **Root cause** | Each catch logs `'error' => $e->getMessage()` and, in two places, `'trace' => $e->getTraceAsString()` — a flattened string with no exception class and no previous-exception chain. |
| **Consequence** | An operator reading `storage/logs` cannot filter by exception type or see the chained cause, so a real production failure takes longer to diagnose. |
| **Reproduce** | static only — the failure path needs a forced DB error, which this workflow does not run (D4). |
| **Fix approach** | With the catches removed (EXRT-01) nothing is logged here; the central handler logs the exception object. If a page-specific log were kept, D2 would require `report($e)`. |
| **Plan item** | none of its own — covered by the EXRT-01 rewrite (see plan §10) |

```php
// ExchangeRateController.php:59-62 — CURRENT
            Log::error('Failed to create Exchange Rate', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php" -Pattern "Log::error" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
59: Log::error('Failed to create Exchange Rate', [
108: Log::error('Failed to update Exchange Rate', [
138: Log::error('Failed to delete Exchange Rate', ['id' => $exchangeRate->id, 'error' => $e->getMessage()]);
165: Log::error('Failed to toggle Exchange Rate status', ['id' => $exchangeRate->id, 'error' => $e->getMessage()]);
200: Log::error('Failed to restore Exchange Rate', ['id' => $id, 'error' => $e->getMessage()]);
226: Log::error('Failed to force delete Exchange Rate', ['id' => $id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### EXRT-04 · M · TXN-02 — Manual begin/commit/rollback instead of the closure form

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php:41-53`, `90-102`, `122-132`, `150-160`, `184-195`, `210-221` |
| **Root cause** | Each mutation manages the transaction by hand and returns from inside the `try`, so the rollback depends on the catch block being correct (and it is not — EXRT-01/02). |
| **Consequence** | Any future early `return` or new exception type between `beginTransaction()` and `commit()` leaves the request's connection inside an open transaction, which can hold locks until the request ends. |
| **Reproduce** | static only — no production path returns early today; the risk is the hand-managed shape itself. |
| **Fix approach** | Replace every pair with `DB::transaction(function () { … })`; build the redirect after the closure returns (TXN-05). |
| **Plan item** | none of its own — covered by the EXRT-01 rewrite (see plan §10) |

```php
// ExchangeRateController.php:41-53 — CURRENT
        DB::beginTransaction();
        try {
            $exchangeRate = ExchangeRate::create($validated);

            activityLog($exchangeRate, 'Created', [
                'message'      => 'Exchange rate created for: ' . $exchangeRate->currency->code,
                'currency_id'  => $exchangeRate->currency_id,
                'rate_date'    => $exchangeRate->rate_date->toDateString(),
                'rate_to_base' => $exchangeRate->rate_to_base,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php" -Pattern "DB::beginTransaction|DB::commit|DB::rollBack" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
41: DB::beginTransaction();
53: DB::commit();
58: DB::rollBack();
90: DB::beginTransaction();
102: DB::commit();
107: DB::rollBack();
122: DB::beginTransaction();
132: DB::commit();
137: DB::rollBack();
150: DB::beginTransaction();
160: DB::commit();
164: DB::rollBack();
184: DB::beginTransaction();
195: DB::commit();
199: DB::rollBack();
210: DB::beginTransaction();
221: DB::commit();
225: DB::rollBack();
```

**Other F2 checks — clean:** TXN-01 (one transaction covers the model write and the `activityLog()` row), TXN-03 (mail/file/HTTP: none), TXN-04 (`activityLog()` is after the write in every mutation — evidence: `Select-String "activityLog" …` → lines 45, 94, 126, 155, 190, 216, each after the preceding create/update/delete/save), TXN-05 (redirects are built after `DB::commit()` except the manual shape, fixed by EXRT-01), TXN-06 (the DB unique index `uq_acc_fx_rate` is the guard — see EXRT-06).

### F3 — Authorization

#### EXRT-05 · L · AUTH-04 — The same permission is checked twice on store and update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`). Keep one.* |
| **Where** | `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php:18`; `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php:36` (`store`), `86` (`update`) |
| **Root cause** | The FormRequest maps POST/PUT to `create`/`update` and calls `Gate::allows()`; the controller then calls `Gate::authorize()` on the same name. |
| **Consequence** | No user-visible difference today. The risk is drift: if one of the two strings is renamed later, the surviving check silently decides access and the other becomes dead logic. |
| **Reproduce** | static only — both checks resolve to the same seeded permission (evidence below). |
| **Fix approach** | Keep the FormRequest's `authorize()` (it runs first and covers both verbs) and drop the duplicated `Gate::authorize()` lines in `store()`/`update()`; the rewrite in EXRT-01 does this. |
| **Plan item** | none — accepted as covered by the EXRT-01 rewrite (see plan §10) |

```php
// ExchangeRateRequest.php:18 — CURRENT
        return $this->authorizeByCrudPermission('tenant.accounting.exchange-rate');
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php","Modules\Accounting\app\Http\Requests\ExchangeRateRequest.php" -Pattern "Gate::authorize|authorizeByCrudPermission" | ForEach-Object { $_.Filename + ":" + $_.LineNumber + ": " + $_.Line.Trim() }
ExchangeRateController.php:20: Gate::authorize('tenant.accounting.exchange-rate.viewAny');
ExchangeRateController.php:27: Gate::authorize('tenant.accounting.exchange-rate.create');
ExchangeRateController.php:36: Gate::authorize('tenant.accounting.exchange-rate.create');
ExchangeRateController.php:70: Gate::authorize('tenant.accounting.exchange-rate.view');
ExchangeRateController.php:77: Gate::authorize('tenant.accounting.exchange-rate.update');
ExchangeRateController.php:86: Gate::authorize('tenant.accounting.exchange-rate.update');
ExchangeRateController.php:120: Gate::authorize('tenant.accounting.exchange-rate.delete');
ExchangeRateController.php:146: Gate::authorize('tenant.accounting.exchange-rate.update');
ExchangeRateController.php:173: Gate::authorize('tenant.accounting.exchange-rate.restore');
ExchangeRateController.php:182: Gate::authorize('tenant.accounting.exchange-rate.restore');
ExchangeRateController.php:208: Gate::authorize('tenant.accounting.exchange-rate.forceDelete');
ExchangeRateRequest.php:18: return $this->authorizeByCrudPermission('tenant.accounting.exchange-rate');
```

**Other F3 checks — clean:** every routed method authorizes before it loads anything (evidence above; the only loads are route-bound models resolved after middleware and the FormRequest's `authorize()`), the seven names exist in `config/permissionslist.php` (`'accounting.exchange-rate' => $crud`, line 624; `$crud` is the seven verbs, lines 176–184) and are seeded in the tenant with exact names, granted to five roles:
```
$ php /tmp/opencode\exrt_probe.php
PERM tenant.accounting.exchange-rate.viewAny = id 1322 | roles: Super Admin,School Admin,Management,Account Staff,Account Manager
PERM tenant.accounting.exchange-rate.view = id 1321 | roles: Super Admin,School Admin,Management,Account Staff,Account Manager
PERM tenant.accounting.exchange-rate.create = id 1320 | roles: Super Admin,School Admin,Management,Account Staff,Account Manager
PERM tenant.accounting.exchange-rate.update = id 1323 | roles: Super Admin,School Admin,Management,Account Staff,Account Manager
PERM tenant.accounting.exchange-rate.delete = id 1324 | roles: Super Admin,School Admin,Management,Account Staff,Account Manager
PERM tenant.accounting.exchange-rate.restore = id 1325 | roles: Super Admin,School Admin,Management,Account Staff,Account Manager
PERM tenant.accounting.exchange-rate.forceDelete = id 1326 | roles: Super Admin,School Admin,Management,Account Staff,Account Manager
```
No `Gate::any()` without abort, no string-only policy call, no record-level data (this is global master data).

### F4 — Validation and input

#### EXRT-06 · H · VAL-04 — The composite unique index is not mirrored in validation, and trashed rows keep their key

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the DB unique index including soft-delete semantics* |
| **Where** | `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php:24`; index `uq_acc_fx_rate` in `database/migrations/tenant/2026_09_16_100013_create_acc_exchange_rates_table.php:31` |
| **Root cause** | The request validates `currency_id` with a plain `exists` and has no `unique` rule at all, while the table has a three-column unique key `(currency_id, rate_date, rate_type)`. Migration 130001 deliberately did not add `del_marker` to that key, so a soft-deleted row still occupies it. |
| **Consequence** | Trashing a rate and then adding the same currency/date/type — a normal operator action after a mistyped rate — fails at the database instead of being explained, and (with EXRT-01) the SQL text is printed to the user. Editing a live rate onto an existing combination fails the same way. |
| **Reproduce** | Trash the USD 2026-04-01 Standard row, then add USD / 2026-04-01 / Standard: the DB raises `Integrity constraint violation … uq_acc_fx_rate` (4 live rows, 0 trashed today). |
| **Fix approach** | Add a `Rule::unique('acc_exchange_rates','currency_id')` with the date and rate type as `where` conditions, `ignore()` the bound model on update, and no `whereNull('deleted_at')` so it matches the index; add a human message. |
| **Plan item** | EXRT-06 in `02-fix-plan.md` §5 |

```php
// ExchangeRateRequest.php:23-30 — CURRENT
        return [
            'currency_id'  => 'required|exists:acc_currencies,id',
            'rate_date'    => 'required|date',
            'rate_to_base' => 'required|numeric|min:0.00000001',
            'rate_type'    => ['required', Rule::in(ExchangeRate::rateTypes())],
            'source'       => 'nullable|string|max:100',
            'is_active'    => 'required|boolean',
        ];
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Requests\ExchangeRateRequest.php" -Pattern "unique" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
(no output)

$ Select-String -Path "database\migrations\tenant\2026_09_16_100013_create_acc_exchange_rates_table.php" -Pattern "unique" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
30: // Unique keys
31: $table->unique(['currency_id', 'rate_date', 'rate_type'], 'uq_acc_fx_rate');

$ php /tmp/opencode\exrt_schema.php
INDEX uq_acc_fx_rate col=currency_id non_unique=0
INDEX uq_acc_fx_rate col=rate_date non_unique=0
INDEX uq_acc_fx_rate col=rate_type non_unique=0
ROW {"id":1,"currency_id":2,"rate_date":"2026-04-01","rate_type":"Standard","is_active":1,"deleted_at":null}
```

#### EXRT-07 · H · VAL-03 — An unticked Active box is validated back to `true`, so the edit switch cannot turn a rate off

| Field | Value |
|---|---|
| **Rule** | VAL-03 (H) — *optional fields must be read with their absence in mind; a missing key must not silently become a value* |
| **Where** | `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php:62-66` |
| **Root cause** | `prepareForValidation()` merges `'is_active' => $this->boolean('is_active', true)`. A browser sends nothing for an unticked checkbox, so the second argument turns "absent" into `true` on every request, including PUT/PATCH. |
| **Consequence** | A user opens a rate, unticks Active, saves, sees "updated successfully", and the rate is still active — the form's own Active switch is a control that cannot switch anything off. |
| **Reproduce** | Edit a rate (`/accounting/exchange-rate/1/edit`), untick Active, save: the row stays `is_active = 1`. |
| **Fix approach** | Default to `true` only on POST (create, where the standalone create page has no field); on PUT/PATCH treat an absent key as `false`. Both code paths are in the same `merge()`. |
| **Plan item** | EXRT-07 in `02-fix-plan.md` §5 |

```php
// ExchangeRateRequest.php:62-66 — CURRENT
        $this->merge([
            'is_active' => $this->boolean('is_active', true),
            'source'    => $this->input('source') ?: null,
            'rate_type' => $rateType,
        ]);
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Requests\ExchangeRateRequest.php" -Pattern "boolean\('is_active'" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
63: 'is_active' => $this->boolean('is_active', true),

$ Select-String -Path "Modules\Accounting\resources\views\exchange-rate\edit.blade.php" -Pattern "name=.is_active" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
109: <input class="form-check-input" type="checkbox" name="is_active" id="is_active" value="1" {{ old('is_active', $exchangeRate->is_active) ? 'checked' : '' }}>
```

#### EXRT-08 · M · VAL-05 — Any existing currency is accepted, including the base, an inactive one, or a trashed one

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is validated; the server must enforce the rule the form implies* |
| **Where** | `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php:24` vs the dropdown filter at `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php:29` and `79` |
| **Root cause** | The rule is `exists:acc_currencies,id`. The dropdown offers only `Currency::active()->where('is_base', false)`, but the request does not repeat those conditions. |
| **Consequence** | A crafted POST can store a rate against the base currency (where "1 unit = 1 unit" is meaningless) or against a deleted/disabled currency that no dropdown will ever show again; the row then appears in the list with an unexpected currency. |
| **Reproduce** | POST `currency_id` of the base currency id directly to `/accounting/exchange-rate` with a valid CSRF token; the rate is accepted. |
| **Fix approach** | Replace the string `exists` with `Rule::exists('acc_currencies','id')->where('is_base', false)->where('is_active', true)->whereNull('deleted_at')`, so the server mirrors the dropdown. |
| **Plan item** | none of its own — covered by the EXRT-06 `rules()` rewrite (see plan §10) |

```php
// ExchangeRateRequest.php:24 — CURRENT
            'currency_id'  => 'required|exists:acc_currencies,id',
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Requests\ExchangeRateRequest.php" -Pattern "exists:acc_currencies" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
24: 'currency_id'  => 'required|exists:acc_currencies,id',

$ Select-String -Path "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php" -Pattern "Currency::active" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
29: $currencies = Currency::active()->where('is_base', false)->orderBy('code')->get();
79: $currencies = Currency::active()->where('is_base', false)->orderBy('code')->get();
```

**Other F4 checks — clean:** VAL-01 (`validated()` is used and passed to `create`/`update`; evidence `Select-String "->all\(|->except\(|->input\(" →` only `$request->input('is_active')` at line 152, a one-field toggle allowed by VAL-02), VAL-02 (the modal/create/edit forms use the FormRequest; only the AJAX status toggle validates inline, which is the allowed exception), VAL-06 (no uploads), VAL-07 (no cross-field rule needed beyond the composite key).

### F5 — Routes

#### EXRT-09 · H · RTE-01 — Restoring a rate is a state change over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:382` |
| **Root cause** | The route is registered with `Route::get`, unlike its sibling `force-delete` which correctly uses `Route::delete`. |
| **Consequence** | Any authenticated user who is made to load that URL — a link prefetcher, a copied "restore" URL, an `<img src>` — restores a trashed rate without a CSRF token or a confirm step. |
| **Reproduce** | While signed in, open `/accounting/exchange-rate/{id}/restore` directly after trashing row `{id}`: the row is restored on a plain GET. |
| **Fix approach** | Change line 382 to `Route::delete(...)`. The shared `x-backend.table.action-trashed` component reads the route's methods and switches the form to POST + `@method('DELETE')` with CSRF automatically, so no Blade edit is needed. |
| **Plan item** | EXRT-09 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED route file) |

```php
// Modules/Accounting/routes/web.php:382 — CURRENT
Route::get('/exchange-rate/{id}/restore', [ExchangeRateController::class, 'restore'])->name('exchange-rate.restore');
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "exchange-rate" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
381: Route::get('/exchange-rate/trash/view', [ExchangeRateController::class, 'trashed'])->name('exchange-rate.trashed');
382: Route::get('/exchange-rate/{id}/restore', [ExchangeRateController::class, 'restore'])->name('exchange-rate.restore');
383: Route::delete('/exchange-rate/{id}/force-delete', [ExchangeRateController::class, 'forceDelete'])->name('exchange-rate.forceDelete');
384: Route::resource('exchange-rate', ExchangeRateController::class);
385: Route::post('/exchange-rate/{exchange_rate}/toggle-status', [ExchangeRateController::class, 'toggleStatus'])->name('exchange-rate.toggleStatus');
```

**Other F5 checks — clean:** RTE-02 (every action exists — `php -l` reported no syntax errors and all 11 actions executed in the route probe), RTE-03 (no unrouted public method), RTE-05 (tenant group: all 11 routes carry `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Accounting`, `Authenticate`, `EnsureEmailIsVerified` — see §4), RTE-06 (`/trash/view` and `/{id}/restore` are registered before `Route::resource`; `toggle-status` is POST-only and cannot be captured by the resource's `{exchange_rate}` GET/PUT routes).

### F6 — Controller shape

#### EXRT-10 · M · CTL-03 — Restore and force-delete use `$id` + `findOrFail` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, `->withTrashed()` on trash routes, not `$id` + `findOrFail`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php:180-186`, `206-212` |
| **Root cause** | The two trashed-row methods take a raw `$id` and query the model by hand, while the other five resource methods use implicit binding. |
| **Consequence** | A missing id must be handled by hand (and is handled wrongly — EXRT-02); the route cannot express `withTrashed()`, so the lookup rule lives in the controller instead of the route. |
| **Reproduce** | static only — there is no user-visible difference while the manual lookup is correct. |
| **Fix approach** | Rename the route parameters to `{exchange_rate}` and bind `ExchangeRate $exchangeRate` with `->withTrashed()`, or keep `$id`; because the route file is shared, this is deferred (see plan §10). |
| **Plan item** | none — deferred, needs a shared route-file edit (plan §10) |

```php
// ExchangeRateController.php:180-186 — CURRENT
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.exchange-rate.restore');

        DB::beginTransaction();
        try {
            $model = ExchangeRate::onlyTrashed()->findOrFail($id);
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php" -Pattern "public function (restore|forceDelete)" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
180: public function restore($id): \Illuminate\Http\RedirectResponse
206: public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

#### EXRT-11 · L · CTL-04 — Eight public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php:18`, `25`, `34`, `68`, `75`, `84`, `118`, `144` |
| **Root cause** | `index`, `create`, `store`, `show`, `edit`, `update`, `destroy` and `toggleStatus` declare no `: View` / `: RedirectResponse` / `: JsonResponse`; only the three trash methods do. |
| **Consequence** | No runtime effect. Static analysis and the IDE cannot tell a caller what each action returns, and a wrong `return` inside a method is not caught early. |
| **Reproduce** | static only. |
| **Fix approach** | Add the return types shown in the EXRT-01 replacement file, which also imports `JsonResponse`, `RedirectResponse` and `View`. |
| **Plan item** | none of its own — covered by the EXRT-01 rewrite (see plan §10) |

```php
// ExchangeRateController.php:18-19 — CURRENT
    public function index()
    {
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php" -Pattern "public function [a-zA-Z_]+" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
18: public function index()
25: public function create()
34: public function store(ExchangeRateRequest $request)
68: public function show(ExchangeRate $exchangeRate)
75: public function edit(ExchangeRate $exchangeRate)
84: public function update(ExchangeRateRequest $request, ExchangeRate $exchangeRate)
118: public function destroy(ExchangeRate $exchangeRate)
144: public function toggleStatus(Request $request, ExchangeRate $exchangeRate)
171: public function trashed(): \Illuminate\View\View
180: public function restore($id): \Illuminate\Http\RedirectResponse
206: public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

**Other F6 checks — clean:** CTL-01 (231 lines, 11 public methods — below both thresholds), CTL-02 (longest method `store`/`update` = 33 lines — below 80), CTL-05 (the repeated activity payload is small and now shares one shape; no 30-line copy), CTL-06 (thin actions; no notifications or calculations), CTL-07 (no `extract`, no `compact()` over 15), CTL-08 (`Request` is injected where needed — line 144), CTL-09 (no `dd`/`dump`/`ray` — grep returned no output), CTL-10 (no dead private methods or commented-out blocks in the controller).

### F7 — Models

#### EXRT-12 · H · MDL-01 — `is_active` is validated and shown, but not fillable, so every write silently drops it

| Field | Value |
|---|---|
| **Rule** | MDL-01 (H) — *`$fillable` declared; a field outside it is silently discarded by `fill()`* |
| **Where** | `Modules/Accounting/app/Models/ExchangeRate.php:13-25`; call sites `ExchangeRateController.php:43` (`create($validated)`), `92` (`update($validated)`), `188` (`update(['is_active' => true])`) |
| **Root cause** | Both forms collect `is_active` and `ExchangeRateRequest` validates and merges it, but `$fillable` does not list it and `$casts` does not type it. Laravel's `fill()` drops the key without an error. |
| **Consequence** | Creating an inactive rate, deactivating one through the edit form, and `restore()`'s intent to set the restored rate active all report success while the database value never changes. With EXRT-07 this makes the Active control completely inert. |
| **Reproduce** | Edit `/accounting/exchange-rate/1/edit`, untick Active, save: the flash says updated, the row still has `is_active = 1`. |
| **Fix approach** | Add `'is_active'` to `$fillable` and add `'is_active' => 'boolean'` to `$casts`. Nothing else reads the value differently; the toggle endpoint writes the attribute directly and keeps working. |
| **Plan item** | EXRT-12 in `02-fix-plan.md` §5 |

```php
// ExchangeRate.php:13-25 — CURRENT
    protected $fillable = [
        'currency_id',
        'rate_date',
        'rate_to_base',
        'rate_type',
        'source',
        'created_by',
    ];

    protected $casts = [
        'rate_date'    => 'date',
        'rate_to_base' => 'decimal:8',
    ];
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Models\ExchangeRate.php" -Pattern "is_active" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
(no output)

$ Select-String -Path "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php" -Pattern "update\(\['is_active'" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
188: $model->update(['is_active' => true]);
```

**Other F7 checks — clean:** `$table = 'acc_exchange_rates'` exists (migration 100013 line 20), `SoftDeletes` matches the `deleted_at` column added by 130001 (`COLUMNS=…,is_active,deleted_at`), no `$guarded = []`, no pivot with `deleted_at`, both relationships are return-typed (`: BelongsTo`), no Spatie media, no global scope, the two scopes are simple `where`s. The missing `is_active` cast is fixed with EXRT-12.

### F8 — Services and jobs

clean — the controller references no service, job, event, listener, mail or notification (`Select-String -Path "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php" -Pattern "Service|Job|Event|Mail|Notification"` → no output). The only cross-class writes are the `activityLog()` helper, already covered by F2.

### F9 — Queries and performance

#### EXRT-13 · L · QRY-02 — The trash list paginates 15 rows instead of the house 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H) — *lists are paginated*; protocol §6 F9 fixes the house size at 10 per page (severity lowered to L: the list is paginated, this is only density) |
| **Where** | `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php:175` |
| **Root cause** | `->paginate(15)` was copied from an older screen; the current house standard is 10. |
| **Consequence** | The trash tab shows 15 rows per page instead of 10 — inconsistent with every other list, no correctness impact. |
| **Reproduce** | Open `/accounting/exchange-rate/trash/view` with more than 10 trashed rows and count the rows on page 1. |
| **Fix approach** | Change `paginate(15)` to `paginate(10)` (included in the EXRT-01 replacement file). |
| **Plan item** | none of its own — covered by the EXRT-01 rewrite (see plan §10) |

```php
// ExchangeRateController.php:175 — CURRENT
        $exchangeRates = ExchangeRate::onlyTrashed()->with('currency')->orderBy('rate_date', 'desc')->paginate(15);
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php" -Pattern "paginate\(" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }
175: $exchangeRates = ExchangeRate::onlyTrashed()->with('currency')->orderBy('rate_date', 'desc')->paginate(15);
```

**Other F9 checks — clean:** no query inside a loop (`Select-String "foreach|->map\(|->each\("` → no output), the trash list eager-loads `currency` (line 175), the two currency dropdowns are a single small query (5 live rows), no raw/interpolated SQL (`Select-String "DB::raw|whereRaw|orderByRaw|selectRaw"` → no output), no `->get()` feeding a list in this controller.

### F10 — Views

clean — no queries and no `{!! !!}` in any of the five exchange-rate blades (`Select-String -Path "Modules/Accounting/resources/views/exchange-rate/*.blade.php" -Pattern "\{!!|DB::|::where|->get\(\)|->count\(\)"` → no output). The trash view's `$rate->currency` is eager-loaded by `trashed()` (line 175), so there is no N+1. Two view notes are recorded in §7 (not fixed in this plan).

### F11 — Security and tenancy

clean — no `env()` in the controller (`Select-String "env\("` → no output), no raw SQL (same grep as F9 → no output), no hard-coded ids or `?? 1` in the controller (`Select-String "?? 1"` → no output), no request body/password/token logging (`Select-String "Log::"` shows only `id` and the exception message, lines 59, 108, 138, 165, 200, 226), and the model is a normal tenant-table model (no `tenancy()->central()` needed). The exception-message leak is F1's business; the fix there also removes the leak into logs.

### F12 — Style

#### EXRT-14 · L · STY-02 — Pint is not clean on the controller, the model and the FormRequest

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines* |
| **Where** | `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php:12-14`, `171`, `180`, `206`; `Modules/Accounting/app/Models/ExchangeRate.php:7-9`, `36`; `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php:7-10` |
| **Root cause** | The imports are not alphabetised, `View`/`RedirectResponse` are written as fully-qualified names inside signatures, the model imports `BaseModel` without using it, the model uses a fully-qualified `User` in `creator()`, and the aligned `=>`/` . ` operators do not match the Laravel preset (single space / no spaces around `.`). |
| **Consequence** | Style only — no runtime effect. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\ExchangeRateController.php Modules\Accounting\app\Models\ExchangeRate.php Modules\Accounting\app\Http\Requests\ExchangeRateRequest.php --format agent` — result `fail`. |
| **Fix approach** | The EXRT-01 replacement file is already Pint-clean; the EXRT-06/EXRT-07 blocks are written in Pint style; one item fixes the model's unused/fully-qualified imports and runs Pint on the model and FormRequest. |
| **Plan item** | EXRT-14 in `02-fix-plan.md` §8 |

```php
// ExchangeRateController.php:12-14 — CURRENT
use Modules\Accounting\Http\Requests\ExchangeRateRequest;
use Modules\Accounting\Models\ExchangeRate;
use Modules\Accounting\Models\Currency;
```

**Evidence**
```
$ vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\ExchangeRateController.php" "Modules\Accounting\app\Models\ExchangeRate.php" "Modules\Accounting\app\Http\Requests\ExchangeRateRequest.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\ExchangeRateController.php","fixers":["fully_qualified_strict_types","concat_space","cast_spaces","ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Models\\ExchangeRate.php","fixers":["fully_qualified_strict_types","no_unused_imports","single_line_after_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Http\\Requests\\ExchangeRateRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
```

**Other F12 checks:** STY-01 (`declare(strict_types=1)` present at line 3 of all three files), STY-03 (camelCase variables — grep of `public function` and local names shows no abbreviations), STY-04 (comments are plain English, no emoji, no commented-out code), STY-05 (one import per class — the model's unused `BaseModel` is removed with EXRT-14), STY-06 (one logging style: `Log::`), STY-07 (flash strings are literals; no `__()` keys exist for this module — consistent with the rest of Accounting).

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data? | 2 Delete before replace? | 3 Duplicate impl? | 4 Soft-delete × unique? | 5 Race? | 6 Auth hole? | 7 Lying message? | 8 Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | EXRT-06 | EXRT-06 | ok (FormRequest `create`) | ok | EXRT-12 |
| `update` | EXRT-12, EXRT-07 | ok | ok | EXRT-06 | EXRT-06 | ok (FormRequest `update`) | ok | EXRT-07, EXRT-12 |
| `destroy` | ok (soft delete only) | ok | ok | EXRT-06 (the trashed row keeps the key) | ok | ok | ok ("moved to trash") | ok |
| `toggleStatus` | ok (writes the bool directly) | ok | ok | ok | ok | ok (`update`) | ok | ok |
| `restore` | EXRT-12 (`is_active => true` discarded) | ok (`restore()` before the status update) | ok | EXRT-06 | ok | ok (`restore`) | ok | EXRT-12 |
| `forceDelete` | ok | ok (delete, then log, both inside one transaction) | ok | ok (the hard-deleted row releases the key) | ok | ok (`forceDelete`) | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_exchange-rates.blade.php` | The list table has no pagination (`->links()`) — the number of rates per currency/date/type grows without bound and the whole set is rendered | QRY-02 | `AccDashboardController` report (owns the configurations list) |
| `resources/views/components/backend/table/status-switch.blade.php` | The partial passes `permission="tenant.accounting.exchange-rate.update"`, but the component's props are `canToggle`/`scope` — `permission` is ignored, so the switch renders for a user who lacks update; the server correctly 403s | VIEW-01 (UI standard) | shared component owner / `AccDashboardController` report |
| `Modules/Accounting/resources/views/exchange-rate/index.blade.php` | Unreachable: the route action `index()` redirects to the configurations tab and no code renders `accounting::exchange-rate.index` (`Select-String "exchange-rate.index"` finds only the breadcrumb registry) | CTL-10 | cleanup in a views pass |
| `show.blade.php`, `index.blade.php`, `_exchange-rates.blade.php` | Legacy rate-type branches (`Spot`, `Forward`, `Closing`, `Average`) can never match: the enum stores only `Standard`, `Selling`, `Buying`, `Custom` and `prepareForValidation()` normalises the aliases | CTL-10 | cleanup in a views pass |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | `updated_by` is only auto-set when the child lists it in `$fillable`; `ExchangeRate` does not, so rate edits record no updater | MDL-01 | `AccountingStatusMasterController` report (owner) |

## 8. Not covered, and why

- **Scanner and self-check were not run.** `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are missing and the brief forbids running `scan.php`. All F1–F13 checks were done manually with Read/Select-String and the route probe.
- **No browser and no tests** (D4). Every "Reproduce" marked *static only* was not exercised; the permission refusals were not clicked through.
- **The Configurations list** (`GET /accounting/configurations?tab=exchange-rates`) is rendered by `AccDashboardController@configurations`, whose report is still `CLAIMED`. Its query, pagination and the shared partial are linked, not audited here. `AccDashboardController/01-report.md` may not exist yet.
- **Currency model** is owned by `CurrencyController` and **BaseAccountingModel** by `AccountingStatusMasterController`; only this controller's use of them was checked.
- **Blade components** (`status-switch`, `action-trashed`, `breadcrum`, `input-text`, `tab.modal`) are common per §4.2; only the props this screen passes were checked.
- **The FormRequest was not executed against a payload** (`module-finalization.md` §3.5.1). Its cross-field behaviour is inferred from the code and the DB index; validating it needs a request, which D4 rules out here.
- **Migration 130001** states the unique keys were deliberately left to include trashed rows; this report treats that as the DDL contract and fixes the application side, not the index.
