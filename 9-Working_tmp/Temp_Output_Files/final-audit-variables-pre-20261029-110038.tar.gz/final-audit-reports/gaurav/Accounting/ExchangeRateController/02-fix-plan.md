# Fix Plan — Accounting / ExchangeRateController

**From:** `01-report.md` (2026-10-22) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | shared route file — only EXRT-09 may touch line 382, and only when that ⚠ SHARED DECISION is ticked with a choice |
| `config/permissionslist.php` | shared config — no permission changes are proposed |
| `database/migrations/tenant/2026_09_16_100013_create_acc_exchange_rates_table.php` | existing migration — never edited |
| `database/migrations/tenant/2026_09_16_130001_add_soft_deletes_and_is_active_to_accounting_tables.php` | existing migration — never edited |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_exchange-rates.blade.php` | shared list partial, owned by the `AccDashboardController` report |
| `Modules/Accounting/resources/views/exchange-rate/*.blade.php` | no view fix is proposed in this plan; EXRT-07/EXRT-12 need no Blade change |
| `resources/views/components/backend/table/status-switch.blade.php` | shared component |
| `resources/views/components/backend/table/action-trashed.blade.php` | shared component |
| `Modules/Accounting/app/Models/Currency.php` | owned by the `CurrencyController` report |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | owned by the `AccountingStatusMasterController` report |
| `app/Helpers/activityLog.php` | common helper |
| `app/Traits/AuthorizesTenantFeature.php` | common trait |

## 1. Blockers reachable today

- [ ] **EXRT-01** · B · ERR-01 · `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php:1-231` — replace the whole controller so no catch sends `$e->getMessage()` to the user, every mutation uses `DB::transaction()`, and the class is typed and Pint-clean.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ExchangeRateController.php`
  - **Also fixes (no separate item, listed in §10):** EXRT-02, EXRT-03, EXRT-04, EXRT-05, EXRT-11, EXRT-13.
  - **Before** (`ExchangeRateController.php:1-231`):
    ```php
<?php

declare(strict_types=1);

namespace Modules\Accounting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Modules\Accounting\Http\Requests\ExchangeRateRequest;
use Modules\Accounting\Models\ExchangeRate;
use Modules\Accounting\Models\Currency;

class ExchangeRateController extends Controller
{
    public function index()
    {
        Gate::authorize('tenant.accounting.exchange-rate.viewAny');

        return redirect()->route('accounting.menu.configurations', ['tab' => 'exchange-rates']);
    }

    public function create()
    {
        Gate::authorize('tenant.accounting.exchange-rate.create');

        $currencies = Currency::active()->where('is_base', false)->orderBy('code')->get();

        return view('accounting::exchange-rate.create', compact('currencies'));
    }

    public function store(ExchangeRateRequest $request)
    {
        Gate::authorize('tenant.accounting.exchange-rate.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        DB::beginTransaction();
        try {
            $exchangeRate = ExchangeRate::create($validated);

            activityLog($exchangeRate, 'Created', [
                'message'      => 'Exchange rate created for: ' . $exchangeRate->currency->code,
                'currency_id'  => $exchangeRate->currency_id,
                'rate_date'    => $exchangeRate->rate_date->toDateString(),
                'rate_to_base' => $exchangeRate->rate_to_base,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.configurations', ['tab' => 'exchange-rates'])
                ->with('success', 'Exchange rate created successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Exchange Rate', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Exchange Rate: ' . $e->getMessage());
        }
    }

    public function show(ExchangeRate $exchangeRate)
    {
        Gate::authorize('tenant.accounting.exchange-rate.view');

        return view('accounting::exchange-rate.show', compact('exchangeRate'));
    }

    public function edit(ExchangeRate $exchangeRate)
    {
        Gate::authorize('tenant.accounting.exchange-rate.update');

        $currencies = Currency::active()->where('is_base', false)->orderBy('code')->get();

        return view('accounting::exchange-rate.edit', compact('exchangeRate', 'currencies'));
    }

    public function update(ExchangeRateRequest $request, ExchangeRate $exchangeRate)
    {
        Gate::authorize('tenant.accounting.exchange-rate.update');

        $validated = $request->validated();

        DB::beginTransaction();
        try {
            $exchangeRate->update($validated);

            activityLog($exchangeRate, 'Updated', [
                'message'      => 'Exchange rate updated for: ' . ($exchangeRate->currency->code ?? $exchangeRate->currency_id),
                'currency_id'  => $exchangeRate->currency_id,
                'rate_date'    => $exchangeRate->rate_date->toDateString(),
                'rate_to_base' => $exchangeRate->rate_to_base,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.configurations', ['tab' => 'exchange-rates'])
                ->with('success', 'Exchange rate updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to update Exchange Rate', [
                'id'    => $exchangeRate->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to update Exchange Rate: ' . $e->getMessage());
        }
    }

    public function destroy(ExchangeRate $exchangeRate)
    {
        Gate::authorize('tenant.accounting.exchange-rate.delete');

        DB::beginTransaction();
        try {
            $exchangeRate->delete();

            activityLog($exchangeRate, 'Deleted', [
                'message'      => 'Exchange rate moved to trash for: ' . ($exchangeRate->currency->code ?? $exchangeRate->currency_id),
                'currency_id'  => $exchangeRate->currency_id,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.configurations', ['tab' => 'exchange-rates'])
                ->with('success', 'Exchange rate moved to trash.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to delete Exchange Rate', ['id' => $exchangeRate->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Exchange Rate: ' . $e->getMessage());
        }
    }

    public function toggleStatus(Request $request, ExchangeRate $exchangeRate)
    {
        Gate::authorize('tenant.accounting.exchange-rate.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::beginTransaction();
        try {
            $exchangeRate->is_active = $request->input('is_active');
            $exchangeRate->save();

            activityLog($exchangeRate, 'Toggled', [
                'message'      => 'Exchange rate status toggled for: ' . ($exchangeRate->currency->code ?? $exchangeRate->currency_id),
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return response()->json(['success' => true, 'is_active' => $exchangeRate->is_active, 'message' => 'Status updated.']);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to toggle Exchange Rate status', ['id' => $exchangeRate->id, 'error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
        }
    }

    public function trashed(): \Illuminate\View\View
    {
        Gate::authorize('tenant.accounting.exchange-rate.restore');

        $exchangeRates = ExchangeRate::onlyTrashed()->with('currency')->orderBy('rate_date', 'desc')->paginate(15);

        return view('accounting::exchange-rate.trash', compact('exchangeRates'));
    }

    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.exchange-rate.restore');

        DB::beginTransaction();
        try {
            $model = ExchangeRate::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'Exchange rate restored for: ' . ($model->currency->code ?? $model->currency_id),
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.exchange-rate.trashed')->with('success', 'Exchange rate restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Exchange Rate', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Exchange Rate: ' . $e->getMessage());
        }
    }

    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.exchange-rate.forceDelete');

        DB::beginTransaction();
        try {
            $model = ExchangeRate::withTrashed()->findOrFail($id);
            $code = $model->currency->code ?? (string)$model->currency_id;
            $model->forceDelete();

            activityLog($model, 'Permanently Deleted', [
                'message'      => 'Exchange rate permanently deleted for: ' . $code,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.exchange-rate.trashed')->with('success', 'Exchange rate permanently deleted.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to force delete Exchange Rate', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Exchange Rate: ' . $e->getMessage());
        }
    }
}
    ```
  - **After:**
    ```php
<?php

declare(strict_types=1);

namespace Modules\Accounting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\View\View;
use Modules\Accounting\Http\Requests\ExchangeRateRequest;
use Modules\Accounting\Models\Currency;
use Modules\Accounting\Models\ExchangeRate;

class ExchangeRateController extends Controller
{
    public function index(): RedirectResponse
    {
        Gate::authorize('tenant.accounting.exchange-rate.viewAny');

        return redirect()->route('accounting.menu.configurations', ['tab' => 'exchange-rates']);
    }

    public function create(): View
    {
        Gate::authorize('tenant.accounting.exchange-rate.create');

        $currencies = Currency::active()->where('is_base', false)->orderBy('code')->get();

        return view('accounting::exchange-rate.create', compact('currencies'));
    }

    public function store(ExchangeRateRequest $request): RedirectResponse
    {
        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        DB::transaction(function () use ($validated): void {
            $exchangeRate = ExchangeRate::create($validated);

            activityLog($exchangeRate, 'Created', [
                'message' => 'Exchange rate created for: '.$exchangeRate->currency->code,
                'currency_id' => $exchangeRate->currency_id,
                'rate_date' => $exchangeRate->rate_date->toDateString(),
                'rate_to_base' => $exchangeRate->rate_to_base,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.configurations', ['tab' => 'exchange-rates'])
            ->with('success', 'Exchange rate created successfully.');
    }

    public function show(ExchangeRate $exchangeRate): View
    {
        Gate::authorize('tenant.accounting.exchange-rate.view');

        return view('accounting::exchange-rate.show', compact('exchangeRate'));
    }

    public function edit(ExchangeRate $exchangeRate): View
    {
        Gate::authorize('tenant.accounting.exchange-rate.update');

        $currencies = Currency::active()->where('is_base', false)->orderBy('code')->get();

        return view('accounting::exchange-rate.edit', compact('exchangeRate', 'currencies'));
    }

    public function update(ExchangeRateRequest $request, ExchangeRate $exchangeRate): RedirectResponse
    {
        $validated = $request->validated();

        DB::transaction(function () use ($exchangeRate, $validated): void {
            $exchangeRate->update($validated);

            activityLog($exchangeRate, 'Updated', [
                'message' => 'Exchange rate updated for: '.($exchangeRate->currency->code ?? $exchangeRate->currency_id),
                'currency_id' => $exchangeRate->currency_id,
                'rate_date' => $exchangeRate->rate_date->toDateString(),
                'rate_to_base' => $exchangeRate->rate_to_base,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.configurations', ['tab' => 'exchange-rates'])
            ->with('success', 'Exchange rate updated successfully.');
    }

    public function destroy(ExchangeRate $exchangeRate): RedirectResponse
    {
        Gate::authorize('tenant.accounting.exchange-rate.delete');

        DB::transaction(function () use ($exchangeRate): void {
            $exchangeRate->delete();

            activityLog($exchangeRate, 'Deleted', [
                'message' => 'Exchange rate moved to trash for: '.($exchangeRate->currency->code ?? $exchangeRate->currency_id),
                'currency_id' => $exchangeRate->currency_id,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.configurations', ['tab' => 'exchange-rates'])
            ->with('success', 'Exchange rate moved to trash.');
    }

    public function toggleStatus(Request $request, ExchangeRate $exchangeRate): JsonResponse
    {
        Gate::authorize('tenant.accounting.exchange-rate.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::transaction(function () use ($request, $exchangeRate): void {
            $exchangeRate->is_active = $request->boolean('is_active');
            $exchangeRate->save();

            activityLog($exchangeRate, 'Toggled', [
                'message' => 'Exchange rate status toggled for: '.($exchangeRate->currency->code ?? $exchangeRate->currency_id),
                'performed_by' => auth()->id(),
            ]);
        });

        return response()->json(['success' => true, 'is_active' => $exchangeRate->is_active, 'message' => 'Status updated.']);
    }

    public function trashed(): View
    {
        Gate::authorize('tenant.accounting.exchange-rate.restore');

        $exchangeRates = ExchangeRate::onlyTrashed()->with('currency')->orderBy('rate_date', 'desc')->paginate(10);

        return view('accounting::exchange-rate.trash', compact('exchangeRates'));
    }

    public function restore($id): RedirectResponse
    {
        Gate::authorize('tenant.accounting.exchange-rate.restore');

        DB::transaction(function () use ($id): void {
            $model = ExchangeRate::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message' => 'Exchange rate restored for: '.($model->currency->code ?? $model->currency_id),
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.exchange-rate.trashed')->with('success', 'Exchange rate restored successfully.');
    }

    public function forceDelete($id): RedirectResponse
    {
        Gate::authorize('tenant.accounting.exchange-rate.forceDelete');

        DB::transaction(function () use ($id): void {
            $model = ExchangeRate::withTrashed()->findOrFail($id);
            $code = $model->currency->code ?? (string) $model->currency_id;
            $model->forceDelete();

            activityLog($model, 'Permanently Deleted', [
                'message' => 'Exchange rate permanently deleted for: '.$code,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.exchange-rate.trashed')->with('success', 'Exchange rate permanently deleted.');
    }
}
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Controllers/ExchangeRateController.php" -Pattern "catch \(|DB::beginTransaction|getMessage\(\)|Log::error" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }`
  - **Expect:** no output. Then `php -l Modules/Accounting/app/Http/Controllers/ExchangeRateController.php` prints `No syntax errors detected`.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None. The is_active pair (EXRT-07 + EXRT-12) must both land before the Active switch works; they are independent code changes and neither arms the other.

## 3. Errors & transactions (F1/F2)

None left after EXRT-01. EXRT-02, EXRT-03 and EXRT-04 are removed by that single rewrite (see §10).

## 4. Authorization (F3)

None. The only authorization finding (EXRT-05, duplicate check) is resolved by the EXRT-01 rewrite, which keeps the FormRequest's `authorize()` and drops the duplicate `Gate::authorize()` in `store()`/`update()`.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **EXRT-12** · H · MDL-01 · `Modules/Accounting/app/Models/ExchangeRate.php:13-25` — add `is_active` to `$fillable` and cast it to boolean so create/update/restore stop silently discarding it.
  - **Touches:** `Modules/Accounting/app/Models/ExchangeRate.php`
  - **Before** (`ExchangeRate.php:13-25`):
    ```php
    protected $fillable = [
        'currency_id',
        'rate_date',
        'rate_to_base',
        'rate_type',
        'source',
        'created_by',
    ];

    protected $casts = [
        'rate_date'    => 'date',
        'rate_to_base' => 'decimal:8',
    ];
    ```
  - **After:**
    ```php
    protected $fillable = [
        'currency_id',
        'rate_date',
        'rate_to_base',
        'rate_type',
        'source',
        'is_active',
        'created_by',
    ];

    protected $casts = [
        'rate_date' => 'date',
        'rate_to_base' => 'decimal:8',
        'is_active' => 'boolean',
    ];
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Models/ExchangeRate.php" -Pattern "'is_active'" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }`
  - **Expect:** two lines — one inside `$fillable`, one inside `$casts`.
  - **Effort:** S

- [ ] **EXRT-06** · H · VAL-04 · `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php:21-31` — mirror the three-column unique index (including trashed rows) and restrict `currency_id` to an active, non-base, non-trashed currency.
  - **Touches:** `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php`
  - **Also fixes (no separate item):** EXRT-08, listed in §10.
  - **Before** (`ExchangeRateRequest.php:21-31`):
    ```php
    public function rules(): array
    {
        return [
            'currency_id'  => 'required|exists:acc_currencies,id',
            'rate_date'    => 'required|date',
            'rate_to_base' => 'required|numeric|min:0.00000001',
            'rate_type'    => ['required', Rule::in(ExchangeRate::rateTypes())],
            'source'       => 'nullable|string|max:100',
            'is_active'    => 'required|boolean',
        ];
    }
    ```
  - **After:**
    ```php
    public function rules(): array
    {
        return [
            'currency_id' => [
                'required',
                Rule::exists('acc_currencies', 'id')
                    ->where(fn ($query) => $query->where('is_base', false)->where('is_active', true)->whereNull('deleted_at')),
                Rule::unique('acc_exchange_rates', 'currency_id')
                    ->where(fn ($query) => $query
                        ->where('rate_date', $this->input('rate_date'))
                        ->where('rate_type', $this->input('rate_type')))
                    ->ignore($this->route('exchange_rate')),
            ],
            'rate_date' => 'required|date',
            'rate_to_base' => 'required|numeric|min:0.00000001',
            'rate_type' => ['required', Rule::in(ExchangeRate::rateTypes())],
            'source' => 'nullable|string|max:100',
            'is_active' => 'required|boolean',
        ];
    }

    public function messages(): array
    {
        return [
            'currency_id.unique' => 'An exchange rate for this currency, date and rate type already exists, including a trashed one. Restore that record instead.',
        ];
    }
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php" -Pattern "Rule::unique|whereNull\('deleted_at'\)|messages\(\)" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }`
  - **Expect:** three lines — `whereNull('deleted_at')`, `Rule::unique(`, and `public function messages(): array`.
  - **Effort:** S

- [ ] **EXRT-07** · H · VAL-03 · `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php:62-66` — stop turning an unticked Active box into `true` on update.
  - **Touches:** `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php`
  - **Before** (`ExchangeRateRequest.php:62-66`):
    ```php
        $this->merge([
            'is_active' => $this->boolean('is_active', true),
            'source'    => $this->input('source') ?: null,
            'rate_type' => $rateType,
        ]);
    ```
  - **After:**
    ```php
        $this->merge([
            'is_active' => $this->isMethod('POST') ? $this->boolean('is_active', true) : $this->boolean('is_active'),
            'source' => $this->input('source') ?: null,
            'rate_type' => $rateType,
        ]);
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php" -Pattern "isMethod\('POST'\)" | ForEach-Object { $_.LineNumber.ToString() + ": " + $_.Line.Trim() }`
  - **Expect:** one line containing `$this->isMethod('POST')`.
  - **Effort:** S

## 6. Queries & performance (F9)

None left after EXRT-01. EXRT-13 (trash list `paginate(15)` → `paginate(10)`) is included in that rewrite (see §10).

## 7. Views (F10)

None. No Blade file changes are needed for any item in this plan.

## 8. Style (F12) — one item per file

- [ ] **EXRT-14** · L · STY-02 · `Modules/Accounting/app/Models/ExchangeRate.php:7-9,36` and `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php:7-10` — finish the Pint cleanup the other items leave behind (unused import, fully-qualified `User`, import order, operator alignment).
  - **Touches:** `Modules/Accounting/app/Models/ExchangeRate.php`, `Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php`
  - **Before** (`ExchangeRate.php:7-9`):
    ```php
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class ExchangeRate extends BaseAccountingModel
    ```
  - **After** (`ExchangeRate.php:7-9`):
    ```php
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Modules\SchoolSetup\Models\User;

class ExchangeRate extends BaseAccountingModel
    ```
  - **Before** (`ExchangeRate.php:34-37`):
    ```php
    public function creator(): BelongsTo
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'created_by');
    }
    ```
  - **After** (`ExchangeRate.php:34-37`):
    ```php
    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
    ```
  - **Before** (`ExchangeRateRequest.php:7-10`):
    ```php
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Validation\Rule;
use Modules\Accounting\Models\ExchangeRate;
    ```
  - **After** (`ExchangeRateRequest.php:7-10`):
    ```php
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Modules\Accounting\Models\ExchangeRate;
    ```
  - **Then run:** `vendor\bin\pint Modules/Accounting/app/Models/ExchangeRate.php Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php --format agent` — this applies the remaining operator alignment (`attributes()`, `prepareForValidation()`'s `$map`).
  - **Verify:** `vendor\bin\pint --test "Modules/Accounting/app/Models/ExchangeRate.php" "Modules/Accounting/app/Http/Requests/ExchangeRateRequest.php" --format agent`
  - **Expect:** `{"tool":"pint","result":"passed"}`
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **EXRT-09** · H · DECISION · RTE-01 · `Modules/Accounting/routes/web.php:382` — restore is a GET that changes data; convert it to DELETE?
  - **Why it is a decision:** it edits the **shared** `Modules/Accounting/routes/web.php`, and a route change stops the fixer (§9.3) unless Tarun chooses it.
  - **Blast radius (measured):** one route line. The shared `x-backend.table.action-trashed` component reads the route's methods and already renders a POST form with `@method('DELETE')` + CSRF for a non-GET route, so no Blade edit is needed. No other controller uses `accounting.exchange-rate.restore`.
  - (a) ⭐ change line 382 to `Route::delete('/exchange-rate/{id}/restore', [ExchangeRateController::class, 'restore'])->name('exchange-rate.restore');` — the trash button becomes a CSRF-protected DELETE automatically.
  - (b) leave the GET route and record it as accepted; the link-prefetch/CSRF exposure stays.
  - (c) convert every Accounting trash restore route to DELETE in one estate-wide pass (wider than this controller).
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| EXRT-02 | Covered by the EXRT-01 rewrite: `findOrFail()` is no longer inside a catch, so a missing id propagates as a 404. |
| EXRT-03 | Covered by EXRT-01: the six catches and their `Log::error(…, ['error' => $e->getMessage()])` calls are deleted; the central handler logs the exception object. |
| EXRT-04 | Covered by EXRT-01: all six manual `beginTransaction`/`commit`/`rollBack` blocks become `DB::transaction()`. |
| EXRT-05 | Covered by EXRT-01: the duplicate controller `Gate::authorize()` in `store()`/`update()` is dropped; the FormRequest's `authorize()` remains. |
| EXRT-08 | Covered by the EXRT-06 `rules()` rewrite: the `Rule::exists` conditions now require an active, non-base, non-trashed currency. |
| EXRT-10 | Deferred: route model binding for `restore`/`forceDelete` needs the shared route parameter renamed to `{exchange_rate}` and `->withTrashed()`; low value, not worth a shared route change in this pass. |
| EXRT-11 | Covered by EXRT-01: the replacement file adds `: View`, `: RedirectResponse` and `: JsonResponse` to all eight methods. |
| EXRT-13 | Covered by EXRT-01: `paginate(15)` becomes `paginate(10)`. |
