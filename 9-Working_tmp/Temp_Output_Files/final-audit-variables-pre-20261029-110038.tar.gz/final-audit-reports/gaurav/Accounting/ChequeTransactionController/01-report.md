# Final Audit — Accounting / ChequeTransactionController

**Audited:** 2026-10-24 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php` (294 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/cheque-transaction` (redirects to the reconciliation tab)<br>`http://test.localhost:8000/accounting/cheque-transaction/create` (500 — missing view)<br>`http://test.localhost:8000/accounting/cheque-transaction/{id}` (show)<br>`http://test.localhost:8000/accounting/cheque-transaction/{id}/edit` (edit)<br>`http://test.localhost:8000/accounting/cheque-transaction/trash/view` (trash)<br>`http://test.localhost:8000/accounting/menu/cheques-reconciliation?tab=cheque-transactions` (actual list, rendered by `AccDashboardController`) |
| Menu path | Finance → Accounting → Cheques & Reconciliation → Cheque Transactions |
| Who uses it | Account Manager, Account Staff, Management, School Admin, Super Admin (roles holding `tenant.accounting.cheque-transaction.viewAny`) |
| What a user does here | Records an issued or received cheque against a posted voucher and a bank ledger, picks a cheque leaf, marks it stale when needed, and moves a cheque through Present / Clear / Bounce / Stop / Cancel. The list itself is a tab on the Cheques & Reconciliation dashboard. |
| Tables written | `acc_cheque_transactions`, `acc_cheque_leaves`, `sys_activity_logs` |
| Tables read | `acc_cheque_transactions`, `acc_cheque_leaves`, `acc_vouchers`, `acc_voucher_bank_details`, `acc_ledgers`, `sys_users`, `sys_activity_logs` |
| Live data | `acc_cheque_transactions` 1 live, 0 trashed; `acc_cheque_leaves` 45 live, 40 still `Unused` (tenant `xyz_school_00000000000040008000_202627`) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No — not production-ready. The table has no `updated_at` column while the model keeps Eloquent timestamps on, so every normal create, update, soft delete, restore, and status transition currently dies with an unknown-column SQL error; only hard delete can succeed. The second blocker is that the raw SQL error text is flashed back to the user. The controller is otherwise a conventional CRUD controller with a serious missing-view route, a GET restore route, duplicated authorization, and an unsynchronised cheque-leaf lifecycle. Worst finding: `CHQT-14`. Effort: S for the blocker, M for the full plan (roughly one to two days).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 4 | 10 | 5 | 4 | 21 |

Total 21 = B + H + M + L; 4 of those findings are also DECISION items.

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CHQT-01, CHQT-02, CHQT-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | CHQT-03 | F9 Queries/Perf | CHQT-16, CHQT-17 |
| F3 Authorization | CHQT-05 | F10 Views | CHQT-18 |
| F4 Validation | CHQT-06, CHQT-07, CHQT-08 | F11 Security/Tenancy | clean |
| F5 Routes | CHQT-09, CHQT-10 | F12 Style | CHQT-19 |
| F6 Controller shape | CHQT-11, CHQT-12, CHQT-13 | F13 Deep read | CHQT-20, CHQT-21 |
| F7 Models | CHQT-14, CHQT-15 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php` | controller | 294 | this report | ✅ |
| 2 | `Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php` | form request | 67 | this report | ✅ |
| 3 | `Modules/Accounting/app/Models/ChequeTransaction.php` | model | 105 | this report | ✅ |
| 4 | `Modules/Accounting/resources/views/cheque-transaction/create.blade.php` | blade | 0 (missing on disk) | this report | ❌ missing |
| 5 | `Modules/Accounting/resources/views/cheque-transaction/edit.blade.php` | blade | 195 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/cheque-transaction/show.blade.php` | blade | 187 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/cheque-transaction/trash.blade.php` | blade | 84 | this report | ✅ |
| 8 | `Modules/Accounting/app/Models/Ledger.php` | model | 408 | ↗ [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) | ↗ linked |
| 9 | `Modules/Accounting/app/Models/Voucher.php` | model | 415 | ↗ [gaurav/Accounting/VoucherController](../VoucherController/01-report.md) | ↗ linked |
| 10 | `Modules/Accounting/app/Models/ChequeLeaf.php` | model | 44 | ↗ [gaurav/Accounting/ChequeLeafController](../ChequeLeafController/01-report.md) | ↗ linked |
| 11 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | base model | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 12 | `Modules/Accounting/app/Models/VoucherBankDetail.php` | model | 79 | unclaimed (no CLASS-OWNERS row) | ❌ usage only |
| 13 | `app/Models/BaseModel.php` | common base model | 22 | common | ❌ common |
| 14 | `app/Helpers/activityLog.php` | common helper | 51 | common | ❌ common |
| 15 | `Modules/SchoolSetup/app/Models/User.php` | model | 318 | unclaimed (used only by a relation) | ❌ usage only |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/cheque-transaction ....................... accounting.cheque-transaction.index › Accounting\ChequeTransactionController@index
POST      accounting/cheque-transaction ....................... accounting.cheque-transaction.store › Accounting\ChequeTransactionController@store
GET|HEAD  accounting/cheque-transaction/create ................ accounting.cheque-transaction.create › Accounting\ChequeTransactionController@create
GET|HEAD  accounting/cheque-transaction/{cheque_transaction} .. accounting.cheque-transaction.show › Accounting\ChequeTransactionController@show
PUT|PATCH accounting/cheque-transaction/{cheque_transaction} .. accounting.cheque-transaction.update › Accounting\ChequeTransactionController@update
DELETE    accounting/cheque-transaction/{cheque_transaction} .. accounting.cheque-transaction.destroy › Accounting\ChequeTransactionController@destroy
GET|HEAD  accounting/cheque-transaction/{cheque_transaction}/edit accounting.cheque-transaction.edit › Accounting\ChequeTransactionController@edit
GET|HEAD  accounting/cheque-transaction/trash/view ............ accounting.cheque-transaction.trashed › Accounting\ChequeTransactionController@trashed
GET|HEAD  accounting/cheque-transaction/{id}/restore .......... accounting.cheque-transaction.restore › Accounting\ChequeTransactionController@restore
DELETE    accounting/cheque-transaction/{id}/force-delete ..... accounting.cheque-transaction.forceDelete › Accounting\ChequeTransactionController@forceDelete
POST      accounting/cheque-transaction/{cheque_transaction}/transition accounting.cheque-transaction.transition › Accounting\ChequeTransactionController@transition
```

All routes are inside the `accounting` prefix and the tenant/auth/module middleware group. Unrouted public methods: none.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 20 | GET /accounting/cheque-transaction | `tenant.accounting.cheque-transaction.viewAny` | — | — | none (redirects) | — |
| `create` | 27 | GET /accounting/cheque-transaction/create | `tenant.accounting.cheque-transaction.create` | — | — | none | CHQT-10, CHQT-12, CHQT-16 |
| `store` | 39 | POST /accounting/cheque-transaction | `tenant.accounting.cheque-transaction.create` | controller, manual | `Created` | `acc_cheque_transactions`, `acc_cheque_leaves`, `sys_activity_logs` | CHQT-01, CHQT-03, CHQT-04, CHQT-05, CHQT-07, CHQT-08, CHQT-14, CHQT-20 |
| `show` | 82 | GET /accounting/cheque-transaction/{cheque_transaction} | `tenant.accounting.cheque-transaction.view` | — | — | none | CHQT-21 |
| `edit` | 101 | GET /accounting/cheque-transaction/{cheque_transaction}/edit | `tenant.accounting.cheque-transaction.update` | — | — | none | CHQT-12, CHQT-16, CHQT-18 |
| `update` | 127 | PUT/PATCH /accounting/cheque-transaction/{cheque_transaction} | `tenant.accounting.cheque-transaction.update` | controller, manual | `Updated` | `acc_cheque_transactions`, `sys_activity_logs` | CHQT-01, CHQT-03, CHQT-04, CHQT-05, CHQT-07, CHQT-08, CHQT-14, CHQT-20 |
| `destroy` | 155 | DELETE /accounting/cheque-transaction/{cheque_transaction} | `tenant.accounting.cheque-transaction.delete` | controller, manual | `Deleted` | `acc_cheque_transactions`, `sys_activity_logs` | CHQT-01, CHQT-03, CHQT-04, CHQT-14, CHQT-20 |
| `transition` | 182 | POST /accounting/cheque-transaction/{cheque_transaction}/transition | `tenant.accounting.cheque-transaction.update` | controller, manual | `StatusTransition` | `acc_cheque_transactions`, `sys_activity_logs` | CHQT-01, CHQT-03, CHQT-04, CHQT-06, CHQT-07, CHQT-08, CHQT-14, CHQT-20 |
| `trashed` | 232 | GET /accounting/cheque-transaction/trash/view | `tenant.accounting.cheque-transaction.restore` | — | — | none | CHQT-17 |
| `restore` | 241 | GET /accounting/cheque-transaction/{id}/restore | `tenant.accounting.cheque-transaction.restore` | controller, manual | `Restored` | `acc_cheque_transactions`, `sys_activity_logs` | CHQT-01, CHQT-02, CHQT-03, CHQT-04, CHQT-14 |
| `forceDelete` | 267 | DELETE /accounting/cheque-transaction/{id}/force-delete | `tenant.accounting.cheque-transaction.forceDelete` | controller, manual | `Deleted` | `acc_cheque_transactions`, `sys_activity_logs` | CHQT-01, CHQT-02, CHQT-03, CHQT-04, CHQT-20 |

## 6. Findings

### F1 — Errors

#### CHQT-01 · B · ERR-01 — Raw SQL exception text is shown to the user

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:78` (also 151, 178, 228, 263, 290)
- **Evidence:**
  ```bash
  $ sed -n '74,79p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
          } catch (\Throwable $e) {
              DB::rollBack();
              Log::error('Failed to create Cheque Transaction', ['error' => $e->getMessage()]);
  
              return back()->withInput()->with('error', 'Failed to record Cheque Transaction: ' . $e->getMessage());
          }
  ```
  ```bash
  $ grep -n "getMessage\(\)" Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
  76:            Log::error('Failed to create Cheque Transaction', ['error' => $e->getMessage()]);
  78:            return back()->withInput()->with('error', 'Failed to record Cheque Transaction: ' . $e->getMessage());
  149:            Log::error('Failed to update Cheque Transaction', ['id' => $chequeTransaction->id, 'error' => $e->getMessage()]);
  151:            return back()->withInput()->with('error', 'Failed to update Cheque Transaction: ' . $e->getMessage());
  176:            Log::error('Failed to delete Cheque Transaction', ['id' => $chequeTransaction->id, 'error' => $e->getMessage()]);
  178:            return back()->with('error', 'Failed to delete Cheque Transaction: ' . $e->getMessage());
  226:            Log::error('Failed to transition Cheque Transaction', ['id' => $chequeTransaction->id, 'error' => $e->getMessage()]);
  228:            return back()->with('error', 'Failed to transition Cheque status: ' . $e->getMessage());
  261:            Log::error('Failed to restore Cheque Transaction', ['id' => $id, 'error' => $e->getMessage()]);
  263:            return back()->with('error', 'Failed to restore Cheque Transaction: ' . $e->getMessage());
  288:            Log::error('Failed to force delete Cheque Transaction', ['id' => $id, 'error' => $e->getMessage()]);
  290:            return back()->with('error', 'Failed to delete Cheque Transaction: ' . $e->getMessage());
  ```
- **Consequence:** A failed write prints the database message — including table/column names and SQL fragments — into the page flash, exposing schema and data to any user allowed to submit the form.
- **Reproduce:** Submit any create today; the missing `updated_at` SQL error is shown verbatim in the red flash.
- **Fix approach:** Never put `$e->getMessage()` in a user-facing string. Remove the try/catch and let the framework exception handler record and render the failure (D1), or `report($e)` and return one fixed message.

#### CHQT-02 · H · ERR-02 — A missing record in restore/force-delete becomes a redirect, not a 404

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:245` and `:271`
- **Evidence:**
  ```bash
  $ sed -n '241,265p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
      public function restore($id): \Illuminate\Http\RedirectResponse
      {
          Gate::authorize('tenant.accounting.cheque-transaction.restore');
  
          DB::beginTransaction();
          try {
              $model = ChequeTransaction::onlyTrashed()->findOrFail($id);
              $model->restore();
  
              activityLog($model, 'Restored', [
                  'message'      => 'Cheque Transaction restored: ' . $model->instrument_no,
                  'instrument_no'=> $model->instrument_no,
                  'performed_by' => auth()->id(),
              ]);
  
              DB::commit();
  
              return redirect()->route('accounting.cheque-transaction.trashed')->with('success', 'Cheque Transaction restored successfully.');
          } catch (\Throwable $e) {
              DB::rollBack();
              Log::error('Failed to restore Cheque Transaction', ['id' => $id, 'error' => $e->getMessage()]);
  
              return back()->with('error', 'Failed to restore Cheque Transaction: ' . $e->getMessage());
          }
      }
  ```
  ```bash
  $ grep -n "findOrFail" Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
  247:            $model = ChequeTransaction::onlyTrashed()->findOrFail($id);
  273:            $model = ChequeTransaction::withTrashed()->findOrFail($id);
  ```
- **Consequence:** Requesting a nonexistent id does not produce a 404; the user is redirected back with a database-looking error, and monitoring cannot distinguish a bad URL from a real failure.
- **Reproduce:** While signed in, open `/accounting/cheque-transaction/999999/restore`; the response is a redirect with an error flash instead of 404.
- **Fix approach:** Resolve the model before any try block; with the catch removed (CHQT-01), `ModelNotFoundException` reaches the handler and returns 404.

#### CHQT-04 · M · ERR-05 — The log keeps only the message, not the exception

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:76` (also 149, 176, 226, 261, 288)
- **Evidence:**
  ```bash
  $ sed -n '76p;149p;176p;226p;261p;288p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
              Log::error('Failed to create Cheque Transaction', ['error' => $e->getMessage()]);
              Log::error('Failed to update Cheque Transaction', ['id' => $chequeTransaction->id, 'error' => $e->getMessage()]);
              Log::error('Failed to delete Cheque Transaction', ['id' => $chequeTransaction->id, 'error' => $e->getMessage()]);
              Log::error('Failed to transition Cheque Transaction', ['id' => $chequeTransaction->id, 'error' => $e->getMessage()]);
              Log::error('Failed to restore Cheque Transaction', ['id' => $id, 'error' => $e->getMessage()]);
              Log::error('Failed to force delete Cheque Transaction', ['id' => $id, 'error' => $e->getMessage()]);
  ```
- **Consequence:** Production logs lose the stack trace and the line that failed, so a reported write failure cannot be traced back to its cause.
- **Reproduce:** No browser step; inspect `storage/logs/laravel.log` after a failed create.
- **Fix approach:** `report($e)` or `Log::error('Cheque transaction failed', ['exception' => $e])`; do not re-implement the handler.

### F2 — Transactions/Audit

#### CHQT-03 · M · TXN-02 — Six writers use manual beginTransaction/commit instead of DB::transaction

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:45-79` (also 133-152, 159-179, 197-229, 245-264, 271-291)
- **Evidence:**
  ```bash
  $ sed -n '45,79p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
          DB::beginTransaction();
          try {
              if (empty($validated['stale_on']) && !empty($validated['instrument_date'])) {
                  $validated['stale_on'] = date('Y-m-d', strtotime($validated['instrument_date'] . ' +3 months'));
              }
              $validated['actioned_by'] = auth()->id();
  
              $txn = ChequeTransaction::create($validated);
  
              // If leaf is assigned, update leaf status to Issued
              if (!empty($validated['cheque_leaf_id'])) {
                  ChequeLeaf::where('id', $validated['cheque_leaf_id'])->update([
                      'status'      => 'Issued',
                      'voucher_id'  => $validated['voucher_id'],
                      'issued_date' => $validated['instrument_date'],
                  ]);
              }
  
              activityLog($txn, 'Created', [
                  'message'       => 'Cheque transaction recorded: ' . $txn->instrument_no . ' (' . $txn->status . ')',
                  'instrument_no' => $txn->instrument_no,
                  'status'        => $txn->status,
                  'performed_by'  => auth()->id(),
              ]);
  
              DB::commit();
  
              return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-transactions'])
                  ->with('success', 'Cheque transaction recorded successfully.');
          } catch (\Throwable $e) {
              DB::rollBack();
              Log::error('Failed to create Cheque Transaction', ['error' => $e->getMessage()]);
  
              return back()->withInput()->with('error', 'Failed to record Cheque Transaction: ' . $e->getMessage());
          }
  ```
  ```bash
  $ grep -n "DB::beginTransaction\|DB::commit\|DB::rollBack" Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
  45:        DB::beginTransaction();
  70:            DB::commit();
  75:            DB::rollBack();
  133:        DB::beginTransaction();
  143:            DB::commit();
  148:            DB::rollBack();
  159:        DB::beginTransaction();
  170:            DB::commit();
  175:            DB::rollBack();
  197:        DB::beginTransaction();
  220:            DB::commit();
  225:            DB::rollBack();
  245:        DB::beginTransaction();
  256:            DB::commit();
  260:            DB::rollBack();
  271:        DB::beginTransaction();
  283:            DB::commit();
  287:            DB::rollBack();
  ```
- **Consequence:** Six independent transaction blocks must be maintained by hand; a future early return or added write can leave the leaf update and the audit row committed separately, and the controller contradicts D1 and house transaction standard.
- **Reproduce:** No browser step; the pattern is visible in all six writer methods.
- **Fix approach:** Wrap the writes in a `DB::transaction()` closure and let the framework roll back on any throw.

### F3 — Authorization

#### CHQT-05 · L · AUTH-04 — store/update authorize the same permission twice

- **Where:** `Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php:14-17`; `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:41` and `:129`
- **Evidence:**
  ```bash
  $ sed -n '12,19p' Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php
      public function authorize(): bool
      {
          if ($this->isMethod('POST')) {
              return Gate::allows('tenant.accounting.cheque-transaction.create');
          }
  
          return Gate::allows('tenant.accounting.cheque-transaction.update');
      }
  ```
  ```bash
  $ sed -n '41p;129p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
          Gate::authorize('tenant.accounting.cheque-transaction.create');
          Gate::authorize('tenant.accounting.cheque-transaction.update');
  ```
- **Consequence:** Both layers enforce the same permission; the request already distinguishes POST from PUT/PATCH, so the controller checks are redundant and a future permission change can diverge between the two.
- **Reproduce:** No browser step; the duplicate is visible in the two files.
- **Fix approach:** Keep authorization in the FormRequest (or the controller), not both.

### F4 — Validation

#### CHQT-06 · M · VAL-02 — transition validates eight fields inline

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:186-195`
- **Evidence:**
  ```bash
  $ sed -n '186,195p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
          $request->validate([
              'status'                 => 'required|in:Issued,Presented,Cleared,Bounced,Stopped,Cancelled,Stale',
              'status_date'            => 'required|date',
              'status_note'            => 'nullable|string|max:500',
              'bounce_reason'          => 'required_if:status,Bounced|nullable|string|max:255',
              'bounce_charge_amount'   => 'nullable|numeric|min:0',
              'reversal_voucher_id'    => 'nullable|exists:acc_vouchers,id',
              'charge_voucher_id'      => 'nullable|exists:acc_vouchers,id',
              'replacement_voucher_id' => 'nullable|exists:acc_vouchers,id',
          ]);
  ```
- **Consequence:** A multi-field state change bypasses `ChequeTransactionRequest`, so transition rules cannot be reused, unit-tested, or kept in step with store/update.
- **Reproduce:** No browser step; the inline array is the only validation on the transition POST.
- **Fix approach:** A dedicated transition FormRequest (authorize `tenant.accounting.cheque-transaction.update`, rules above) or one form-request method; not a one-field AJAX rule, so VAL-02 applies.

#### CHQT-07 · M · VAL-07 — No cross-field rule ties the cheque leaf to the bank account or its status

- **Where:** `Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php:42-65`; leaf mutation at `ChequeTransactionController.php:55-61`
- **Evidence:**
  ```bash
  $ sed -n '42,65p' Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php
              'voucher_id'             => 'required|exists:acc_vouchers,id',
              'voucher_bank_detail_id' => 'nullable|exists:acc_voucher_bank_details,id',
              'bank_ledger_id'         => 'required|exists:acc_ledgers,id',
              'party_ledger_id'        => 'nullable|exists:acc_ledgers,id',
              'direction'              => 'required|in:Issued,Received,Outward,Inward',
              'cheque_leaf_id'         => 'nullable|exists:acc_cheque_leaves,id',
              'instrument_no'          => 'required|string|max:50',
              'instrument_date'        => 'required|date',
              'amount'                 => 'required|numeric|min:0.01',
              'favouring_name'         => 'nullable|string|max:200',
              'counterparty_bank'      => 'nullable|string|max:150',
              'status'                 => 'required|in:Issued,Presented,Cleared,Bounced,Stopped,Cancelled,Stale',
              'status_date'            => 'required|date',
              'status_note'            => 'nullable|string|max:500',
              'is_post_dated'          => 'nullable|boolean',
              'stale_on'               => 'nullable|date',
              'bounce_reason'          => 'required_if:status,Bounced|nullable|string|max:255',
              'bounce_charge_amount'   => 'nullable|numeric|min:0',
              'reversal_voucher_id'    => 'nullable|exists:acc_vouchers,id',
              'charge_voucher_id'      => 'nullable|exists:acc_vouchers,id',
              'replacement_voucher_id' => 'nullable|exists:acc_vouchers,id',
              'actioned_by'            => 'nullable|exists:sys_users,id',
              'is_active'              => 'nullable|boolean',
          ];
  ```
  ```bash
  $ grep -n "cheque_leaf_id\|bank_ledger_id\|stale_on" Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php
  44:            'bank_ledger_id'         => 'required|exists:acc_ledgers,id',
  47:            'cheque_leaf_id'         => 'nullable|exists:acc_cheque_leaves,id',
  57:            'stale_on'               => 'nullable|date',
  ```
- **Consequence:** A crafted POST can attach a leaf from another bank, attach an already-issued leaf, or submit `stale_on` earlier than `instrument_date`; the controller then marks that leaf `Issued` without re-checking, so two cheques can claim one leaf.
- **Reproduce:** Submit the form with a `cheque_leaf_id` belonging to another bank ledger; the request validates because only `exists` is checked.
- **Fix approach:** Add an `after()` validator: leaf must belong to `bank_ledger_id`, must be `Unused` (or already attached to this transaction on update), and `stale_on` must not precede `instrument_date`.

#### CHQT-08 · H · VAL-04 — The unique key uq_acc_chqtxn_state has no matching validation rule

- **Where:** `database/migrations/tenant/2026_09_16_100064_create_acc_cheque_transactions_table.php:47`; `Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php:42-50`
- **Evidence:**
  ```bash
  $ sed -n '46,47p' database/migrations/tenant/2026_09_16_100064_create_acc_cheque_transactions_table.php
              // Unique keys
              $table->unique(['voucher_id', 'instrument_no', 'status', 'status_date'], 'uq_acc_chqtxn_state');
  ```
  ```bash
  $ sed -n '42,50p' Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php
              'voucher_id'             => 'required|exists:acc_vouchers,id',
              'voucher_bank_detail_id' => 'nullable|exists:acc_voucher_bank_details,id',
              'bank_ledger_id'         => 'required|exists:acc_ledgers,id',
              'party_ledger_id'        => 'nullable|exists:acc_ledgers,id',
              'direction'              => 'required|in:Issued,Received,Outward,Inward',
              'cheque_leaf_id'         => 'nullable|exists:acc_cheque_leaves,id',
              'instrument_no'          => 'required|string|max:50',
              'instrument_date'        => 'required|date',
              'amount'                 => 'required|numeric|min:0.01',
  ```
  ```bash
  $ grep -n "unique" Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php
  (no output)
  ```
- **Consequence:** A resubmitted or duplicated transition reaches the database and throws a raw unique-constraint exception; because soft-deleted rows still occupy the key, a restore/edit can hit the same 500. The user sees the SQL error through CHQT-01.
- **Reproduce:** POST the same `voucher_id`, `instrument_no`, `status`, and `status_date` twice; the second write fails with a duplicate-key SQL error.
- **Fix approach:** Mirror the composite key with a `Rule::unique` rule carrying `where` constraints and `ignore` on update; do not exclude trashed rows, because the database does not.

### F5 — Routes

#### CHQT-09 · H · RTE-01 — GET /{id}/restore changes state

- **Where:** `Modules/Accounting/routes/web.php:153`
- **Evidence:**
  ```bash
  $ sed -n '153p' Modules/Accounting/routes/web.php
  Route::get('{id}/restore', [ChequeTransactionController::class, 'restore'])->name('restore');
  ```
- **Consequence:** A link prefetch, crawler, or browser history replay can restore a deleted cheque without the user submitting a form; the action is not idempotent-safe over GET.
- **Reproduce:** Open the trash list while signed in and follow the Restore link; it is a plain anchor.
- **Fix approach:** Change to `DELETE` (or `POST`) and update the shared trash action component/form. ⚠ SHARED route file.

#### CHQT-10 · H · RTE-02 — GET create renders a Blade file that does not exist

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:35`; missing `Modules/Accounting/resources/views/cheque-transaction/create.blade.php`
- **Evidence:**
  ```bash
  $ php artisan tinker --execute="echo view()->exists('accounting::cheque-transaction.create') ? 'true' : 'false';"
  false
  ```
  ```bash
  $ ls Modules/Accounting/resources/views/cheque-transaction
  edit.blade.php
  show.blade.php
  trash.blade.php
  ```
- **Consequence:** Any user who follows the create URL gets `View [accounting::cheque-transaction.create] not found` (HTTP 500); creation is only possible if something else renders the form.
- **Reproduce:** Open `/accounting/cheque-transaction/create`; the response is a 500.
- **Fix approach:** Add the create Blade view (matching edit's fields) or remove the route and the create permission from the flow. DECISION.

### F6 — Controller shape

#### CHQT-11 · L · CTL-04 — Eight public methods have no return type

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:20,27,39,82,101,127,155,182`
- **Evidence:**
  ```bash
  $ grep -n "public function (index|create|store|show|edit|update|destroy|transition)\(" Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
  20:    public function index()
  27:    public function create()
  39:    public function store(ChequeTransactionRequest $request)
  82:    public function show(ChequeTransaction $chequeTransaction)
  101:    public function edit(ChequeTransaction $chequeTransaction)
  127:    public function update(ChequeTransactionRequest $request, ChequeTransaction $chequeTransaction)
  155:    public function destroy(ChequeTransaction $chequeTransaction)
  182:    public function transition(Request $request, ChequeTransaction $chequeTransaction)
  ```
- **Consequence:** Callers and static analysis cannot tell a view response from a redirect; the three already-typed methods use inline FQCNs, so the file is inconsistent.
- **Reproduce:** No browser step; the signatures are visible above.
- **Fix approach:** Add `: View` / `: RedirectResponse` and import those classes; no behavior change.

#### CHQT-12 · M · CTL-05 — create() and edit() copy the same four dropdown loaders

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:31-34` and `:116-119`
- **Evidence:**
  ```bash
  $ sed -n '31,34p;116,119p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
          $bankLedgers  = Ledger::selectableBankAccounts();
          $partyLedgers = Ledger::where('ledger_type', 'Party')->orWhereNotNull('party_type')->orderBy('name')->get();
          $vouchers     = Voucher::where('status', 'Posted')->orderByDesc('voucher_date')->take(100)->get();
          $unusedLeaves = ChequeLeaf::where('status', 'Unused')->orderBy('leaf_no')->get();
          $bankLedgers  = Ledger::selectableBankAccounts();
          $partyLedgers = Ledger::where('ledger_type', 'Party')->orWhereNotNull('party_type')->orderBy('name')->get();
          $vouchers     = Voucher::where('status', 'Posted')->orderByDesc('voucher_date')->take(100)->get();
          $unusedLeaves = ChequeLeaf::where('status', 'Unused')->orWhere('id', $chequeTransaction->cheque_leaf_id)->orderBy('leaf_no')->get();
  ```
- **Consequence:** The two forms can drift; a fix to the party query or the voucher limit must be made twice, and the edit form has a different leaf query from create.
- **Reproduce:** No browser step; the blocks are identical.
- **Fix approach:** One private loader (or a small data class) used by both actions.

#### CHQT-13 · M · CTL-06 — Cheque lifecycle rules live in the controller

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:47-49` (stale date), `:55-61` (leaf issue), `:200-211` (append-only transition copy)
- **Evidence:**
  ```bash
  $ sed -n '47,49p;55,61p;200,211p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
              if (empty($validated['stale_on']) && !empty($validated['instrument_date'])) {
                  $validated['stale_on'] = date('Y-m-d', strtotime($validated['instrument_date'] . ' +3 months'));
              }
              if (!empty($validated['cheque_leaf_id'])) {
                  ChequeLeaf::where('id', $validated['cheque_leaf_id'])->update([
                      'status'      => 'Issued',
                      'voucher_id'  => $validated['voucher_id'],
                      'issued_date' => $validated['instrument_date'],
                  ]);
              }
              $newTxn = $chequeTransaction->replicate();
              $newTxn->status                 = $request->input('status');
              $newTxn->status_date            = $request->input('status_date');
              $newTxn->status_note            = $request->input('status_note');
              $newTxn->bounce_reason          = $request->input('bounce_reason');
              $newTxn->bounce_charge_amount   = $request->input('bounce_charge_amount');
              $newTxn->reversal_voucher_id    = $request->input('reversal_voucher_id');
              $newTxn->charge_voucher_id      = $request->input('charge_voucher_id');
              $newTxn->replacement_voucher_id = $request->input('replacement_voucher_id');
              $newTxn->actioned_by            = auth()->id();
              $newTxn->created_at             = now();
              $newTxn->save();
  ```
- **Consequence:** The 3-month stale rule, leaf issuance, and append-only status copy are three domain rules encoded in HTTP handlers; the list page and any future import/API cannot reuse them, and each copy can diverge.
- **Reproduce:** No browser step; the rules are inline in store and transition.
- **Fix approach:** A service/action (`ChequeTransactionService`) owning create/transition; DECISION because it is a refactor with behaviour risk, not a bug fix.

### F7 — Models

#### CHQT-14 · B · MDL-07 — The model writes updated_at, but the table has no such column

- **Where:** `Modules/Accounting/app/Models/ChequeTransaction.php:8-10`; `Modules/Accounting/app/Models/BaseAccountingModel.php:14`; `database/migrations/tenant/2026_09_16_100064_create_acc_cheque_transactions_table.php:20-44`
- **Evidence:**
  ```bash
  $ sed -n '8,10p' Modules/Accounting/app/Models/ChequeTransaction.php
  class ChequeTransaction extends BaseAccountingModel
  {
      protected $table = 'acc_cheque_transactions';
  ```
  ```bash
  $ sed -n '12,14p' Modules/Accounting/app/Models/BaseAccountingModel.php
  abstract class BaseAccountingModel extends BaseModel
  {
      use SoftDeletes;
  ```
  ```bash
  $ mysql -u root -N -e "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='xyz_school_00000000000040008000_202627' AND TABLE_NAME='acc_cheque_transactions' AND COLUMN_NAME='updated_at';"
  0
  ```
  ```bash
  $ php artisan tinker --execute="echo (new Modules\Accounting\Models\ChequeTransaction())->usesTimestamps() ? 'true' : 'false';"
  true
  ```
  ```bash
  $ php artisan tinker --execute="config(['database.connections.probe'=>array_merge(config('database.connections.mysql'),['database'=>'xyz_school_00000000000040008000_202627'])]); DB::purge('probe'); echo DB::connection('probe')->pretend(function(){ (new Modules\Accounting\Models\ChequeTransaction())->setConnection('probe')->forceFill(['voucher_id'=>1,'instrument_no'=>'PROBE','status'=>'Issued','status_date'=>'2026-10-24','direction'=>'Outward','amount'=>1])->save(); })[0]['query'];"
  insert into `acc_cheque_transactions` (`voucher_id`, `instrument_no`, `status`, `status_date`, `direction`, `amount`, `updated_at`, `created_at`) values (1, 'PROBE', 'Issued', '2026-10-24 00:00:00', 'Outward', 1, '2026-10-24 19:16:34', '2026-10-24 19:16:34')
  ```
- **Consequence:** The `INSERT` names `updated_at`, which the table does not have, so every create dies with `SQLSTATE[42S22] Unknown column 'updated_at'`; update, soft delete, and restore add the same column and fail too. `forceDelete` is the only write that can succeed.
- **Reproduce:** Create a cheque from the UI; the write fails and CHQT-01 flashes the SQL error.
- **Fix approach:** `public const UPDATED_AT = null;` on the model (keeps `created_at`, stops Eloquent writing `updated_at`), or add an `updated_at` column in a new migration. The constant is the smaller, no-DDL fix.

#### CHQT-15 · L · MDL-04 — Nine relations have no return type

- **Where:** `Modules/Accounting/app/Models/ChequeTransaction.php:48-91`
- **Evidence:**
  ```bash
  $ grep -n "public function" Modules/Accounting/app/Models/ChequeTransaction.php
  48:    public function voucher()
  53:    public function voucherBankDetail()
  58:    public function bankLedger()
  63:    public function partyLedger()
  68:    public function chequeLeaf()
  73:    public function reversalVoucher()
  78:    public function chargeVoucher()
  83:    public function replacementVoucher()
  88:    public function actionedBy()
  97:    public function getIsStaleAttribute(): bool
  ```
- **Consequence:** None of the nine `belongsTo` relations declares `: BelongsTo`, so IDE and static analysis cannot check them and the file is inconsistent with the typed accessor below.
- **Reproduce:** No browser step; the signatures are visible above.
- **Fix approach:** Add `: BelongsTo` to the nine relations; no behavior change.

### F9 — Queries/Perf

#### CHQT-16 · M · QRY-15 — edit() loads every party ledger and every unused leaf

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:32-34` and `:117-122`
- **Evidence:**
  ```bash
  $ sed -n '32,34p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
          $partyLedgers = Ledger::where('ledger_type', 'Party')->orWhereNotNull('party_type')->orderBy('name')->get();
          $vouchers     = Voucher::where('status', 'Posted')->orderByDesc('voucher_date')->take(100)->get();
          $unusedLeaves = ChequeLeaf::where('status', 'Unused')->orderBy('leaf_no')->get();
  ```
  ```bash
  $ sed -n '117,122p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
          $partyLedgers = Ledger::where('ledger_type', 'Party')->orWhereNotNull('party_type')->orderBy('name')->get();
          $vouchers     = Voucher::where('status', 'Posted')->orderByDesc('voucher_date')->take(100)->get();
          $unusedLeaves = ChequeLeaf::where('status', 'Unused')->orWhere('id', $chequeTransaction->cheque_leaf_id)->orderBy('leaf_no')->get();
          $voucherBankDetails = \Modules\Accounting\Models\VoucherBankDetail::where('bank_ledger_id', $chequeTransaction->bank_ledger_id)
              ->orWhere('id', $chequeTransaction->voucher_bank_detail_id)
              ->take(100)->get();
  ```
- **Consequence:** The edit form hydrates every party ledger and every unused leaf into memory on each request; at 45 leaves this is small, but the queries are unbounded and will grow with the tenant. The blade then triggers one query per row for the related names.
- **Reproduce:** Open `/accounting/cheque-transaction/{id}/edit` with query logging; the two `get()` calls return the full sets.
- **Fix approach:** Eager-load the three relations and bound the lists; select only the columns the blades use. Merge with CHQT-18.

#### CHQT-17 · L · QRY-02 — The trash list paginates at 15, not the house 10

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:236`
- **Evidence:**
  ```bash
  $ sed -n '236p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
          $transactions = ChequeTransaction::onlyTrashed()->with(['voucher', 'bankLedger'])->latest('deleted_at')->paginate(15);
  ```
- **Consequence:** The trash screen shows a different page size from every other trash screen, and the extra rows cost an extra query worth of related data.
- **Reproduce:** Open `/accounting/cheque-transaction/trash/view`; the pager length is 15.
- **Fix approach:** `paginate(10)`.

### F10 — Views

#### CHQT-18 · M · VIEW-02 — edit.blade lazy-loads three relations inside loops

- **Where:** `Modules/Accounting/resources/views/cheque-transaction/edit.blade.php:106-110,117-121,128-132`; loader at `ChequeTransactionController.php:116-122`
- **Evidence:**
  ```bash
  $ sed -n '106,110p;117,121p;128,132p' Modules/Accounting/resources/views/cheque-transaction/edit.blade.php
                                          @foreach(($unusedLeaves ?? []) as $uLeaf)
                                              <option value="{{ $uLeaf->id }}" {{ old('cheque_leaf_id', $chequeTransaction->cheque_leaf_id) == $uLeaf->id ? 'selected' : '' }}>
                                                  Leaf #{{ $uLeaf->leaf_no }} ({{ $uLeaf->bankLedger->name ?? 'Bank' }})
                                              </option>
                                          @endforeach
                                          @foreach(($vouchers ?? []) as $v)
                                              <option value="{{ $v->id }}" {{ old('voucher_id', $chequeTransaction->voucher_id) == $v->id ? 'selected' : '' }}>
                                                  #{{ $v->voucher_number }} ({{ $v->voucherType->name ?? 'Voucher' }} - {{ number_format($v->total_amount, 2) }})
                                              </option>
                                          @endforeach
                                          @foreach(($voucherBankDetails ?? []) as $vbd)
                                              <option value="{{ $vbd->id }}" {{ old('voucher_bank_detail_id', $chequeTransaction->voucher_bank_detail_id) == $vbd->id ? 'selected' : '' }}>
                                                  #{{ $vbd->id }} [Voucher #{{ $vbd->voucher->voucher_number ?? $vbd->voucher_id }}] - {{ $vbd->transaction_type }} ({{ $vbd->instrument_no ?: 'No Inst' }})
                                              </option>
                                          @endforeach
  ```
- **Consequence:** Rendering a form with 100 vouchers, 45 leaves, and 100 bank details fires one query per row for `voucherType`, `bankLedger`, and `voucher`, turning one edit page into hundreds of queries.
- **Reproduce:** Open the edit page with query logging; each `<option>` adds a relation query.
- **Fix approach:** `with('voucherType')`, `with('bankLedger')`, and `with('voucher')` in the edit loaders; select the keys the relations need.

### F12 — Style

#### CHQT-19 · L · STY-02 — Pint fails on all three files

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`; `Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php`; `Modules/Accounting/app/Models/ChequeTransaction.php`
- **Evidence:**
  ```bash
  $ vendor/bin/pint --test Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php Modules/Accounting/app/Models/ChequeTransaction.php --format agent
  {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\ChequeTransactionController.php","fixers":["fully_qualified_strict_types","concat_space","not_operator_with_successor_space","ordered_imports","binary_operator_spaces","single_blank_line_at_eof"]},{"path":"Modules\\Accounting\\app\\Http\\Requests\\ChequeTransactionRequest.php","fixers":["binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Models\\ChequeTransaction.php","fixers":["fully_qualified_strict_types","no_unused_imports","not_operator_with_successor_space","single_line_after_imports","binary_operator_spaces"]}]}
  ```
- **Consequence:** CI style checks fail on all owned files, and the mixed inline FQCN/imported names make diffs noisy.
- **Reproduce:** Run the command above.
- **Fix approach:** Run Pint on the three files; no manual style rewriting required.

### F13 — Deep read

| Method | Rule | Input | Validation | Authorization | Database | Transaction | Result |
|---|---|---|---|---|---|---|---|
| `store` | BR-CHEQUE-01, BR-CHEQUE-06 | FormRequest + leaf + optional stale date | `ChequeTransactionRequest` | request + controller Gate | insert txn; leaf update unconditional | manual `beginTransaction` | fails on `updated_at`; leaf is marked `Issued` even for `Received` |
| `update` | BR-CHEQUE-01, BR-CHEQUE-06 | FormRequest | `ChequeTransactionRequest` | request + controller Gate | update txn only; leaf not resynced | manual `beginTransaction` | fails on `updated_at`; old/new leaf drifts |
| `destroy` | BR-CHEQUE-06 | route model | none | controller Gate | soft delete txn only; leaf untouched | manual `beginTransaction` | fails on `updated_at`; leaf left `Issued` |
| `transition` | BR-CHEQUE-06 (append-only) | 8 inline fields | inline `$request->validate()` | controller Gate | insert replicated txn; leaf untouched | manual `beginTransaction` | fails on `updated_at`; duplicate state hits the unique key; leaf left `Issued` |
| `restore` | BR-CHEQUE-06 | route id | none | controller Gate | restore txn only; leaf untouched | manual `beginTransaction` | fails on `updated_at`; leaf state not rechecked |
| `forceDelete` | BR-CHEQUE-06 | route id | none | controller Gate | hard delete txn only; leaf untouched | manual `beginTransaction` | deletes the row; leaf stays `Issued` forever |

#### CHQT-20 · M · F13 #1 — The cheque leaf's status is written on store and never corrected

- **Where:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:55-61`; no leaf writes in `update` (127-153), `destroy` (155-180), `transition` (182-230)
- **Evidence:**
  ```bash
  $ sed -n '55,61p' Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
              if (!empty($validated['cheque_leaf_id'])) {
                  ChequeLeaf::where('id', $validated['cheque_leaf_id'])->update([
                      'status'      => 'Issued',
                      'voucher_id'  => $validated['voucher_id'],
                      'issued_date' => $validated['instrument_date'],
                  ]);
              }
  ```
  ```bash
  $ grep -n "ChequeLeaf\|cheque_leaf_id" Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php
  13:use Modules\Accounting\Models\ChequeLeaf;
  34:        $unusedLeaves = ChequeLeaf::where('status', 'Unused')->orderBy('leaf_no')->get();
  55:            if (!empty($validated['cheque_leaf_id'])) {
  56:                ChequeLeaf::where('id', $validated['cheque_leaf_id'])->update([
  119:        $unusedLeaves = ChequeLeaf::where('status', 'Unused')->orWhere('id', $chequeTransaction->cheque_leaf_id)->orderBy('leaf_no')->get();
  ```
- **Consequence:** A received cheque (direction `Inward`, stored as `Received`) also marks its leaf `Issued`; changing the leaf on edit leaves the old leaf `Issued` forever; force-deleting the cheque never releases the leaf. The leaf register slowly fills with false `Issued` rows and the next user cannot select them.
- **Reproduce:** Create a received cheque with a leaf, then edit it to no leaf; the original leaf stays `Issued`.
- **Fix approach:** Only mark the leaf `Issued` for an issued/outward cheque; on update, release the old leaf and claim the new one; on force-delete, release it. A soft delete keeps the leaf tied to the recoverable row.

#### CHQT-21 · M · F13 #7 — Every Issued cheque is displayed as "Inward"

- **Where:** `Modules/Accounting/resources/views/cheque-transaction/show.blade.php:15-19`; stored values at `Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php:21-30`
- **Evidence:**
  ```bash
  $ sed -n '15,19p' Modules/Accounting/resources/views/cheque-transaction/show.blade.php
                              @if($chequeTransaction->direction === 'Outward')
                                  <span class="badge bg-danger-subtle text-danger border border-danger-subtle">Outward</span>
                              @else
                                  <span class="badge bg-success-subtle text-success border border-success-subtle">Inward</span>
                              @endif
  ```
  ```bash
  $ sed -n '21,30p' Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php
          protected function prepareForValidation(): void
          {
              if ($this->has('direction')) {
                  $dir = (string) $this->input('direction');
                  if ($dir === 'Outward') {
                      $this->merge(['direction' => 'Issued']);
                  } elseif ($dir === 'Inward') {
                      $this->merge(['direction' => 'Received']);
                  }
              }
  ```
- **Consequence:** The form normalises to `Issued`/`Received`, but the show page compares against `Outward`, so the condition is never true and every issued cheque is displayed with a warning “Inward” badge — the opposite of its type.
- **Reproduce:** Open any issued cheque's show page; the badge says Inward.
- **Fix approach:** Compare against `Issued` (or use the model's `direction_label`) and render the matching badge.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` + `_cheque-transactions.blade.php` | The real list is a dashboard tab owned by another controller; it renders every append-only history row and its own Delete action. It is outside this controller's route surface. | CTL-06, VIEW-02 | owner of `AccDashboardController` |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | Soft deletes were added after the accounting tables were created, so `uq_acc_chqtxn_state` still includes trashed rows; a deleted cheque keeps its unique slot. | VAL-04 | owner of `AccountingStatusMasterController` |
| `Modules/Accounting/app/Models/VoucherBankDetail.php` | Used by `edit()` and `edit.blade.php` but has no row in `00-CLASS-OWNERS.md`; its schema/relations were read, not audited. | MDL-04 | unclaimed; assign an owner before changing it |
| `Modules/SchoolSetup/app/Models/User.php` | Read only through `ChequeTransaction::actionedBy()`; no owner row in `00-CLASS-OWNERS.md`. | MDL-04 | unclaimed; assign an owner |
| `resources/views/components/backend/table/action-trashed.blade.php` | Shared trash controls already detect the HTTP method, so the GET restore is this controller's route defect, not the component's. | RTE-01 | shared component owner (no change needed) |
| `app/Helpers/activityLog.php` | Writes the tenant or central `sys_activity_logs` row; no defect found in the helper itself. | — | common helper owner (no change needed) |

## 8. Not covered, and why

- The automated scanner and self-check were **skipped**: `_tools/scanfilter.py` and `_tools/selfcheck.py` are missing from this checkout, and `_tools/scan.php` was not run. F1-F13 were checked manually.
- No test suite was run; the protocol (D4) forbids using tests as part of this audit.
- No browser session was opened. Route behaviour was taken from `route:list`, view existence from `view()->exists()`, and the missing `create.blade.php` was confirmed on disk; the 500 on `/create` was not reproduced in a browser.
- The live tenant DB was queried read-only (`xyz_school_00000000000040008000_202627`) for schema and row counts; no INSERT/UPDATE/DELETE was executed, so the `updated_at` failure is proven with a `pretend()` insert rather than a real failed write.
- Only one tenant was sampled; no second tenant was checked for the same schema.
- The dashboard list page and its modal (`AccDashboardController@chequesReconciliation`, `_cheque-transactions.blade.php`) were not audited; they are another owner's scope and are recorded in §7.
- The linked `Ledger`, `Voucher`, `ChequeLeaf`, `BaseAccountingModel`, `VoucherBankDetail`, and `SchoolSetup\User` files were read only far enough to confirm the calls, relations, and columns this controller uses; they are not audited here.
- `create.blade.php` does not exist, so its field names and defaults could not be compared with the request rules.
- No queue jobs, scheduled commands, or events are dispatched by this controller.

