# Fix Plan — Accounting / FundController

**From:** `01-report.md` (2026-10-24) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/FundController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | shared route file — only FUND-11 (DECISION) edits it, and only when ticked |
| `config/permissionslist.php` | shared config — no change proposed |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_funds.blade.php` | owned by the AccDashboardController report; FUND-10 does not edit it |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | owned by another report |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | shared by every accounting model; owned by another report |
| `Modules/Accounting/app/Services/AccountingContext.php` | shared; owned by the AccountGroupController report |
| `Modules/Accounting/app/Policies/FundBalancePolicy.php` | not in the class registry; no change here |
| `Modules/Accounting/app/Policies/FundPolicy.php` | only touched if FUND-08 option (a) is ticked |
| `resources/views/components/**`, `resources/views/layouts/**` | common components and layouts |
| `database/migrations/**` | never edit an existing migration; a new additive migration is written only if FUND-09 option (b) or FUND-24 option (c) is ticked, and the fixer never runs it |

## 1. Blockers reachable today

- [ ] **FUND-01** · B · ERR-01 · `Modules/Accounting/app/Http/Controllers/FundController.php:36-239` — remove every `try/catch` and every manual transaction; use the `DB::transaction` closure form; never send `$e->getMessage()` to the user. This one item also resolves **FUND-02, FUND-03, FUND-04, FUND-05 and FUND-06**.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FundController.php`
  - **Before - imports (`FundController.php:7-15`):**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Accounting\Http\Requests\FundRequest;
    use Modules\Accounting\Models\Campus;
    use Modules\Accounting\Models\Fund;
    use Modules\Accounting\Models\Ledger;
    ```
  - **After - imports (the `Log` import is no longer used):**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Accounting\Http\Requests\FundRequest;
    use Modules\Accounting\Models\Campus;
    use Modules\Accounting\Models\Fund;
    use Modules\Accounting\Models\Ledger;
    ```
  - **Before - `store()` (`FundController.php:36-67`):**
    ```php
    public function store(FundRequest $request)
    {
        Gate::authorize('tenant.accounting.fund.create');

        $validated = $request->validated();

        DB::beginTransaction();
        try {
            $validated['created_by'] = auth()->id();
            $fund = Fund::create($validated);

            activityLog($fund, 'Created', [
                'message'      => 'Fund created: ' . $fund->name,
                'code'         => $fund->code,
                'name'         => $fund->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'funds'])
                ->with('success', 'Fund created successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Fund', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Fund: ' . $e->getMessage());
        }
    }
    ```
  - **After - `store()`:**
    ```php
    public function store(FundRequest $request)
    {
        Gate::authorize('tenant.accounting.fund.create');

        DB::transaction(function () use ($request) {
            $validated = $request->validated();
            $validated['created_by'] = auth()->id();
            $fund = Fund::create($validated);

            activityLog($fund, 'Created', [
                'message'      => 'Fund created: ' . $fund->name,
                'code'         => $fund->code,
                'name'         => $fund->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'funds'])
            ->with('success', 'Fund created successfully.');
    }
    ```
  - **Before - `update()` (`FundController.php:93-123`):**
    ```php
    public function update(FundRequest $request, Fund $fund)
    {
        Gate::authorize('tenant.accounting.fund.update');

        DB::beginTransaction();
        try {
            $validated = $request->validated();
            $validated['updated_by'] = auth()->id();
            $fund->update($validated);

            activityLog($fund, 'Updated', [
                'message'      => 'Fund updated: ' . $fund->name,
                'code'         => $fund->code,
                'name'         => $fund->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'funds'])
                ->with('success', 'Fund updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to update Fund', [
                'id'    => $fund->id,
                'error' => $e->getMessage(),
            ]);

            return back()->withInput()->with('error', 'Failed to update Fund: ' . $e->getMessage());
        }
    }
    ```
  - **After - `update()`:**
    ```php
    public function update(FundRequest $request, Fund $fund)
    {
        Gate::authorize('tenant.accounting.fund.update');

        DB::transaction(function () use ($request, $fund) {
            $validated = $request->validated();
            $validated['updated_by'] = auth()->id();
            $fund->update($validated);

            activityLog($fund, 'Updated', [
                'message'      => 'Fund updated: ' . $fund->name,
                'code'         => $fund->code,
                'name'         => $fund->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'funds'])
            ->with('success', 'Fund updated successfully.');
    }
    ```
  - **Before - `destroy()` (`FundController.php:125-149`):**
    ```php
    public function destroy(Fund $fund)
    {
        Gate::authorize('tenant.accounting.fund.delete');

        DB::beginTransaction();
        try {
            $fund->delete();

            activityLog($fund, 'Deleted', [
                'message'      => 'Fund moved to trash: ' . $fund->name,
                'code'         => $fund->code,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'funds'])
                ->with('success', 'Fund moved to trash.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to delete Fund', ['id' => $fund->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Fund: ' . $e->getMessage());
        }
    }
    ```
  - **After - `destroy()` (the event is now `'Trashed'`, not `'Deleted'`):**
    ```php
    public function destroy(Fund $fund)
    {
        Gate::authorize('tenant.accounting.fund.delete');

        DB::transaction(function () use ($fund) {
            $fund->delete();

            activityLog($fund, 'Trashed', [
                'message'      => 'Fund moved to trash: ' . $fund->name,
                'code'         => $fund->code,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'funds'])
            ->with('success', 'Fund moved to trash.');
    }
    ```
  - **Before - `toggleStatus()` (`FundController.php:151-177`):**
    ```php
    public function toggleStatus(Request $request, Fund $fund)
    {
        Gate::authorize('tenant.accounting.fund.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::beginTransaction();
        try {
            $fund->is_active = $request->input('is_active');
            $fund->save();

            activityLog($fund, 'Toggled', [
                'message'      => 'Fund status toggled: ' . $fund->name,
                'code'         => $fund->code,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return response()->json(['success' => true, 'is_active' => $fund->is_active, 'message' => 'Status updated.']);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to toggle Fund status', ['id' => $fund->id, 'error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
        }
    }
    ```
  - **After - `toggleStatus()`:**
    ```php
    public function toggleStatus(Request $request, Fund $fund)
    {
        Gate::authorize('tenant.accounting.fund.update');

        $validated = $request->validate(['is_active' => 'required|boolean']);

        DB::transaction(function () use ($fund, $validated) {
            $fund->is_active = (bool) $validated['is_active'];
            $fund->save();

            activityLog($fund, 'Toggled', [
                'message'      => 'Fund status toggled: ' . $fund->name,
                'code'         => $fund->code,
                'performed_by' => auth()->id(),
            ]);
        });

        return response()->json(['success' => true, 'is_active' => $fund->is_active, 'message' => 'Status updated.']);
    }
    ```
  - **Before - `restore()` (`FundController.php:188-213`):**
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.fund.restore');

        DB::beginTransaction();
        try {
            $model = Fund::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'Fund restored: ' . $model->name,
                'name'         => $model->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.fund.trashed')->with('success', 'Fund restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Fund', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Fund: ' . $e->getMessage());
        }
    }
    ```
  - **After - `restore()` (the lookup is outside the transaction; a missing id becomes a 404):**
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.fund.restore');

        $model = Fund::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($model) {
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'Fund restored: ' . $model->name,
                'name'         => $model->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.fund.trashed')->with('success', 'Fund restored successfully.');
    }
    ```
  - **Before - `forceDelete()` (`FundController.php:215-240`):**
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.fund.forceDelete');

        DB::beginTransaction();
        try {
            $model = Fund::withTrashed()->findOrFail($id);
            $name = $model->name;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Fund permanently deleted: ' . $name,
                'name'         => $name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.fund.trashed')->with('success', 'Fund permanently deleted.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to force delete Fund', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Fund: ' . $e->getMessage());
        }
    }
    ```
  - **After - `forceDelete()`:**
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.fund.forceDelete');

        $model = Fund::withTrashed()->findOrFail($id);
        $name = $model->name;

        DB::transaction(function () use ($model, $name) {
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Fund permanently deleted: ' . $name,
                'name'         => $name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.fund.trashed')->with('success', 'Fund permanently deleted.');
    }
    ```
  - **Verify:**
    ```
    Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'beginTransaction|catch \(|getMessage\(\)|Log::error'
    Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -SimpleMatch "activityLog($fund, 'Trashed'"
    php -l Modules\Accounting\app\Http\Controllers\FundController.php
    ```
  - **Expect:** the first command prints nothing; the second prints one hit at the `destroy()` event; `php -l` prints `No syntax errors detected in Modules\Accounting\app\Http\Controllers\FundController.php`.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

- **FUND-09 is the latent defect.** Removing the catches (FUND-01) turns a duplicate code/name that passes validation into a 500 rendered by the central handler instead of a flash with raw SQL. If FUND-01 is ticked, tick FUND-09 option (a) in the same pass so the duplicate is rejected as a validation error instead. The two items edit different files, so the order in which the fixer applies them does not matter.
- **FUND-11 is a route re-scope.** It edits the shared `routes/web.php` and must be ticked explicitly. The shared `action-trashed` component already emits a POST + CSRF form when the route is POST, so no component edit is needed.

## 3. Errors & transactions (F1/F2)

All F1/F2 findings (FUND-02, FUND-03, FUND-04, FUND-05, FUND-06) are resolved by **FUND-01** in §1. No separate item is needed here.

## 4. Authorization (F3)

- [ ] **FUND-07** · L · AUTH-04 · `Modules/Accounting/app/Http/Controllers/FundController.php:38,95` — remove the two `Gate::authorize` calls that duplicate `FundRequest::authorize()`.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FundController.php`
  - **Before - `store()` (`FundController.php:36-40`):**
    ```php
    public function store(FundRequest $request)
    {
        Gate::authorize('tenant.accounting.fund.create');

        $validated = $request->validated();
    ```
  - **After - `store()`:**
    ```php
    public function store(FundRequest $request)
    {
        $validated = $request->validated();
    ```
  - **Before - `update()` (`FundController.php:93-99`):**
    ```php
    public function update(FundRequest $request, Fund $fund)
    {
        Gate::authorize('tenant.accounting.fund.update');

        DB::beginTransaction();
    ```
  - **After - `update()`:**
    ```php
    public function update(FundRequest $request, Fund $fund)
    {
        DB::beginTransaction();
    ```
  - **Note:** if FUND-01 is also ticked, the line after the `update()` signature is `DB::transaction(function () use ($request, $fund) {` instead of `DB::beginTransaction();`. Delete only the `Gate::authorize('tenant.accounting.fund.update');` line and the blank line that follows it; leave the transaction line untouched.
  - **Verify:**
    ```
    (Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'Gate::authorize').Count
    Select-String -Path Modules\Accounting\app\Http\Requests\FundRequest.php -Pattern 'authorizeByCrudPermission'
    ```
  - **Expect:** `9` (down from 11) and one hit at `FundRequest.php:17`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **FUND-15** · L · CTL-10 · `Modules/Accounting/resources/views/fund/index.blade.php` — delete the dead view. Keep the `index()` redirect and the `accounting.fund.index` route name (`Modules/Accounting/app/Models/Exception.php:142` calls the route).
  - **Touches:** `Modules/Accounting/resources/views/fund/index.blade.php` (delete the file)
  - **Before:** `Test-Path Modules\Accounting\resources\views\fund\index.blade.php` → `True`; the file has 105 lines / 7,143 bytes.
  - **After:** the file is deleted. No controller, route or Blade reference to `view('accounting::fund.index')` exists.
  - **Verify:**
    ```
    Test-Path Modules\Accounting\resources\views\fund\index.blade.php
    Get-ChildItem Modules\Accounting\resources,Modules\Accounting\app -Recurse -Include *.php,*.blade.php | Select-String -Pattern 'fund\.index|fund/index'
    ```
  - **Expect:** `False`; the grep prints only `Modules/Accounting/app/Models/Exception.php:142: return route('accounting.fund.index');`.
  - **Effort:** S

- [ ] **FUND-16** · L · MDL-04 · `Modules/Accounting/app/Models/Fund.php:42-60` — add return types to the four relations.
  - **Touches:** `Modules/Accounting/app/Models/Fund.php`
  - **Before - imports (`Fund.php:7-8`):**
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **After - imports (add the two relation imports; leave the existing two lines in place):**
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Before - relations (`Fund.php:42-60`):**
    ```php
    public function grantorLedger()
    {
        return $this->belongsTo(Ledger::class, 'grantor_ledger_id');
    }

    public function fundLedger()
    {
        return $this->belongsTo(Ledger::class, 'fund_ledger_id');
    }

    public function campus()
    {
        return $this->belongsTo(\Modules\Accounting\Models\Campus::class);
    }

    public function balances()
    {
        return $this->hasMany(FundBalance::class);
    }
    ```
  - **After - relations:**
    ```php
    public function grantorLedger(): BelongsTo
    {
        return $this->belongsTo(Ledger::class, 'grantor_ledger_id');
    }

    public function fundLedger(): BelongsTo
    {
        return $this->belongsTo(Ledger::class, 'fund_ledger_id');
    }

    public function campus(): BelongsTo
    {
        return $this->belongsTo(Campus::class);
    }

    public function balances(): HasMany
    {
        return $this->hasMany(FundBalance::class);
    }
    ```
  - **Verify:**
    ```
    Select-String -Path Modules\Accounting\app\Models\Fund.php -Pattern ': BelongsTo|: HasMany'
    php -l Modules\Accounting\app\Models\Fund.php
    ```
  - **Expect:** four hits (`grantorLedger`, `fundLedger`, `campus`, `balances`); `No syntax errors detected`.
  - **Effort:** S

- [ ] **FUND-17** · L · CTL-10 · `Modules/Accounting/app/Models/Fund.php:8,12` — remove the redundant `SoftDeletes` declaration; the parent already uses the trait.
  - **Touches:** `Modules/Accounting/app/Models/Fund.php`
  - **Before (`Fund.php:7-14`):**
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;

    class Fund extends BaseAccountingModel
    {
        use SoftDeletes;

        protected $table = 'acc_funds';
    ```
  - **After:**
    ```php
    use App\Models\BaseModel;

    class Fund extends BaseAccountingModel
    {
        protected $table = 'acc_funds';
    ```
  - **Verify:**
    ```
    Select-String -Path Modules\Accounting\app\Models\Fund.php -Pattern 'SoftDeletes'
    Select-String -Path Modules\Accounting\app\Models\BaseAccountingModel.php -Pattern 'SoftDeletes'
    ```
  - **Expect:** no output for `Fund.php`; one hit at `BaseAccountingModel.php:14`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **FUND-19** · M · QRY-02 · `Modules/Accounting/app/Http/Controllers/FundController.php:183` — use the house page size and a distinct page name for the trash list.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FundController.php`
  - **Before (`FundController.php:183`):**
    ```php
    $funds = Fund::onlyTrashed()->orderBy('code')->paginate(15);
    ```
  - **After:**
    ```php
    $funds = Fund::onlyTrashed()->orderBy('code')->paginate(10, ['*'], 'funds_page');
    ```
  - **Note:** `Modules/Accounting/resources/views/fund/trash.blade.php:65` calls `$funds->links()`, which reads the page name from the paginator; no view change is needed.
  - **Verify:**
    ```
    Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'paginate\(10, \[''\*''\], ''funds_page'''
    ```
  - **Expect:** one hit at line 183.
  - **Effort:** S

- [ ] **FUND-20** · M · QRY-03 · `Modules/Accounting/app/Http/Controllers/FundController.php:30-31,73-78,87-88` — select only the columns the dropdowns use and drop the unused `balances` eager load.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FundController.php`
  - **Before - `create()` (`FundController.php:30-31`):**
    ```php
    $campuses = Campus::where('is_active', true)->orderBy('ordinal')->get();
    $ledgers  = Ledger::where('is_active', true)->orderBy('name')->get();
    ```
  - **After - `create()`:**
    ```php
    $campuses = Campus::where('is_active', true)->orderBy('ordinal')->get(['id', 'name']);
    $ledgers  = Ledger::where('is_active', true)->orderBy('name')->get(['id', 'name']);
    ```
  - **Before - `show()` (`FundController.php:73-78`):**
    ```php
    $fund->load([
        'grantorLedger',
        'fundLedger',
        'campus',
        'balances',
    ]);
    ```
  - **After - `show()`:**
    ```php
    $fund->load([
        'grantorLedger',
        'fundLedger',
        'campus',
    ]);
    ```
  - **Before - `edit()` (`FundController.php:87-88`):**
    ```php
    $campuses = Campus::where('is_active', true)->orderBy('ordinal')->get();
    $ledgers  = Ledger::where('is_active', true)->orderBy('name')->get();
    ```
  - **After - `edit()`:**
    ```php
    $campuses = Campus::where('is_active', true)->orderBy('ordinal')->get(['id', 'name']);
    $ledgers  = Ledger::where('is_active', true)->orderBy('name')->get(['id', 'name']);
    ```
  - **Verify:**
    ```
    Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern "'balances'"
    Get-ChildItem Modules\Accounting\resources\views\fund -Filter *.blade.php | Select-String -Pattern 'balances'
    ```
  - **Expect:** no output from both commands.
  - **Effort:** S

## 7. Views (F10)

No F10 findings. The only view change in this plan belongs to the FUND-10 decision in §9 (`edit.blade.php`); it is not a separate F10 item.

## 8. Style (F12) - one item per file

- [ ] **FUND-13** · L · CTL-04 · `Modules/Accounting/app/Http/Controllers/FundController.php` — add return types to the eight untyped public methods.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FundController.php`
  - **Before - signatures (`FundController.php:19,26,36,69,83,93,125,151`):**
    ```php
    public function index()
    public function create()
    public function store(FundRequest $request)
    public function show(Fund $fund)
    public function edit(Fund $fund)
    public function update(FundRequest $request, Fund $fund)
    public function destroy(Fund $fund)
    public function toggleStatus(Request $request, Fund $fund)
    ```
  - **After - signatures:**
    ```php
    public function index(): RedirectResponse
    public function create(): View
    public function store(FundRequest $request): RedirectResponse
    public function show(Fund $fund): View
    public function edit(Fund $fund): View
    public function update(FundRequest $request, Fund $fund): RedirectResponse
    public function destroy(Fund $fund): RedirectResponse
    public function toggleStatus(Request $request, Fund $fund): JsonResponse
    ```
  - **Also add these three imports** (leave every existing import untouched):
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\View\View;
    ```
  - **Note:** the `trashed()`, `restore()` and `forceDelete()` signatures already have return types; do not change them here. FQCN return types on `restore()`/`forceDelete()` are normalized by the Pint item FUND-21.
  - **Verify:**
    ```
    Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'public function (index|create|store|show|edit|update|destroy|toggleStatus).*:'
    php -l Modules\Accounting\app\Http\Controllers\FundController.php
    ```
  - **Expect:** eight hits; `No syntax errors detected`.
  - **Effort:** S

- [ ] **FUND-21** · L · STY-02 · `Modules/Accounting/app/Http/Controllers/FundController.php` — make the controller Pint-clean.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/FundController.php`
  - **Before:** `vendor\bin\pint --test --format agent Modules\Accounting\app\Http\Controllers\FundController.php` → `fail`, fixers `fully_qualified_strict_types`, `concat_space`, `ordered_imports`, `binary_operator_spaces`.
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\FundController.php --format agent` (never `--dirty`).
  - **Verify:** `vendor\bin\pint --test --format agent Modules\Accounting\app\Http\Controllers\FundController.php`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`.
  - **Effort:** S

- [ ] **FUND-22** · L · STY-02 · `Modules/Accounting/app/Models/Fund.php` — make the model Pint-clean.
  - **Touches:** `Modules/Accounting/app/Models/Fund.php`
  - **Before:** `vendor\bin\pint --test --format agent Modules\Accounting\app\Models\Fund.php` → `fail`, fixers `fully_qualified_strict_types`, `no_unused_imports`, `binary_operator_spaces`.
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Models\Fund.php --format agent` (never `--dirty`).
  - **Verify:** `vendor\bin\pint --test --format agent Modules\Accounting\app\Models\Fund.php`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`.
  - **Effort:** S

- [ ] **FUND-23** · L · STY-02 · `Modules/Accounting/app/Http/Requests/FundRequest.php` — make the form request Pint-clean.
  - **Touches:** `Modules/Accounting/app/Http/Requests/FundRequest.php`
  - **Before:** `vendor\bin\pint --test --format agent Modules\Accounting\app\Http\Requests\FundRequest.php` → `fail`, fixers `ordered_imports`, `binary_operator_spaces`.
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Requests\FundRequest.php --format agent` (never `--dirty`).
  - **Verify:** `vendor\bin\pint --test --format agent Modules\Accounting\app\Http\Requests\FundRequest.php`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`.
  - **Effort:** S

## 9. Deferred / decisions

These items run after the Pint items in §8. If a chosen option edits PHP, run `vendor\bin\pint` on each edited file afterwards.

- [ ] **FUND-09** · H · DECISION · VAL-04 — the DB unique index includes trashed rows, but validation adds `->withoutTrashed()`.
  - **Why it is a decision:** option (b) needs a new additive migration (the fixer must never run it); option (a) changes validation semantics for re-used codes.
  - (a) ⭐ Drop `->withoutTrashed()` from both rules so validation mirrors the DB index exactly. No migration, no data change; a code/name held by a trashed fund is rejected with a validation message.
    ```php
    'code'                => ['required', 'string', 'max:30', Rule::unique('acc_funds', 'code')->ignore($id)],
    'name'                => ['required', 'string', 'max:150', Rule::unique('acc_funds', 'name')->ignore($id)],
    ```
  - (b) Add a new additive migration that drops `uq_acc_fund_code`/`uq_acc_fund_name` and enforces uniqueness only among live rows (a generated `code_active`/`name_active` column plus a unique key), then keep the current rules. A composite `(code, deleted_at)` key is not enough in MySQL because multiple live rows have `deleted_at = NULL` and MySQL treats NULLs as distinct.
  - (c) Leave as is and accept that re-using a trashed code/name is a 500.
  - ➜ Choice: ____

- [ ] **FUND-10** · H · DECISION · VAL-07/VAL-05 — the edit form omits `status`, omits `Corpus`/`Designated`, and the request invents defaults.
  - **Why it is a decision:** it changes the edit form's fields and the meaning of an absent `is_active`; the request must also preserve the bound model's values.
  - (a) ⭐ Fix `edit.blade.php` and `FundRequest.php` together:
    - Add `Corpus` and `Designated` options after the `Unrestricted` option (`edit.blade.php:82`):
      ```blade
      <option value="Corpus" {{ old('fund_type', $fund->fund_type) == 'Corpus' ? 'selected' : '' }}>Corpus</option>
      <option value="Designated" {{ old('fund_type', $fund->fund_type) == 'Designated' ? 'selected' : '' }}>Designated</option>
      ```
    - Add a Status select after the fund-type column (`edit.blade.php:85`):
      ```blade
      <div class="col-md-4">
          <div class="form-group mb-0">
              <label for="status" class="form-label">Status</label>
              <select name="status" id="status" class="form-select form-select-sm">
                  <option value="Active" {{ old('status', $fund->status) == 'Active' ? 'selected' : '' }}>Active</option>
                  <option value="Fully_Utilised" {{ old('status', $fund->status) == 'Fully_Utilised' ? 'selected' : '' }}>Fully Utilised</option>
                  <option value="Suspended" {{ old('status', $fund->status) == 'Suspended' ? 'selected' : '' }}>Suspended</option>
                  <option value="Closed" {{ old('status', $fund->status) == 'Closed' ? 'selected' : '' }}>Closed</option>
              </select>
          </div>
      </div>
      ```
    - Add a hidden zero before the `is_active` checkbox (`edit.blade.php:213`) so an unchecked box submits `0`:
      ```blade
      <input type="hidden" name="is_active" value="0">
      ```
    - Replace the defaulting block in `FundRequest.php:77-84`:
      ```php
      $status = $this->input('status');
      if ($status === null || $status === '') {
          $status = $this->route('fund')?->status ?? 'Active';
      }

      $mergeData = [
          'is_active'        => $this->has('is_active')
              ? $this->boolean('is_active')
              : ($this->route('fund')?->is_active ?? true),
          'status'           => $status,
          'fund_type'        => $mappedType,
          'overspend_action' => $mappedOverspend ?: 'Block',
      ];
      ```
  - (b) Add only the `status` select and the hidden `is_active` zero; leave the missing `Corpus`/`Designated` options (the type can still be coerced).
  - (c) Leave as is and record the status/type reset as accepted.
  - ➜ Choice: ____

- [ ] **FUND-11** · H · DECISION · RTE-01 — `GET /accounting/fund/{id}/restore` changes state. ⚠ SHARED (route file).
  - **Why it is a decision:** changing the verb is a route re-scope (final-audit.md §9.3) and edits `Modules/Accounting/routes/web.php`. The shared `action-trashed` component already reads the route method and emits a POST + CSRF form, so no component edit is needed.
  - (a) ⭐ Change the verb to POST:
    ```php
    Route::post('/fund/{id}/restore', [FundController::class, 'restore'])->name('fund.restore');
    ```
  - (b) Keep GET and add a confirmation/CSRF guard (does not meet RTE-01).
  - (c) Leave as is and record it as accepted.
  - ➜ Choice: ____

- [ ] **FUND-24** · H · DECISION · CTL-06 — `forceDelete()` has no usage guard; nine FKs restrict and `acc_fund_balances` cascades.
  - **Why it is a decision:** it changes what a permanent delete does (block vs database error vs silent cascade) and which tables are checked.
  - (a) ⭐ Block with a friendly flash when any of the nine restrict tables or `acc_fund_balances` references the fund. Apply FUND-01 first; place this after the `$name = $model->name;` line and before the `DB::transaction` closure:
    ```php
    $usedBy = collect([
        'acc_budget_lines'           => 'budget lines',
        'acc_grants'                 => 'grants',
        'acc_ledger_period_balances' => 'ledger period balances',
        'acc_opening_balances'       => 'opening balances',
        'acc_fixed_assets'           => 'fixed assets',
        'acc_donations'              => 'donations',
        'acc_bill_references'        => 'bill references',
        'acc_expense_claim_lines'    => 'expense claim lines',
        'acc_voucher_item_funds'     => 'voucher fund allocations',
    ])->first(fn (string $label, string $table): bool => DB::table($table)->where('fund_id', $model->id)->exists());

    if ($usedBy !== null) {
        return back()->with('error', "This fund is used by {$usedBy} and cannot be permanently deleted.");
    }

    if ($model->balances()->exists()) {
        return back()->with('error', 'This fund has balance rows and cannot be permanently deleted.');
    }
    ```
  - (b) Let the database reject the delete and convert the `QueryException` to a friendly flash. D2 forbids catching `RuntimeException`/`QueryException` in a controller, so this option needs a service.
  - (c) Change the FK behaviour in a new additive migration (cascade or set null); the fixer never runs migrations.
  - ➜ Choice: ____

- [ ] **FUND-08** · M · DECISION · AUTH-06 — the `tenant.accounting.fund.*` literals are repeated 11 times and `FundPolicy` is never consulted.
  - **Why it is a decision:** a new constants class plus edits across the controller, the request and the policy; the policy is shared infrastructure.
  - (a) ⭐ Add `Modules/Accounting/app/Support/FundPermissions.php` with one constant per action (`BASE = 'tenant.accounting.fund'`, `VIEW_ANY`, `VIEW`, `CREATE`, `UPDATE`, `DELETE`, `RESTORE`, `FORCE_DELETE`) and replace the literals in `FundController`, `FundRequest` and `FundPolicy`. Keep `FundPolicy` registered so future model-based checks have a single source.
  - (b) Use the registered `FundPolicy` abilities in the controller (`Gate::authorize('view', $fund)` and so on). `trashed()` has no matching ability, so it keeps a literal; the request keeps its base string.
  - (c) Leave the literals and record the duplication as accepted.
  - ➜ Choice: ____

- [ ] **FUND-14** · L · DECISION · CTL-05 — two "create fund" forms exist (the live modal and the routed page).
  - **Why it is a decision:** option (a) removes a reachable URL and edits the shared resource route; option (b) adds a new entry point to the live UI.
  - (a) ⭐ Delete the routed page: remove `create()` from `FundController`, delete `Modules/Accounting/resources/views/fund/create.blade.php`, and change the resource route to `Route::resource('fund', FundController::class)->except(['create']);` in `Modules/Accounting/routes/web.php`. ⚠ SHARED route file. Keep the modal as the only create surface.
  - (b) Keep both and add a "Full form" link from the live Funds tab to `accounting.fund.create`.
  - (c) Leave both and accept that the page has no Status/Active controls.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| FUND-02 | resolved by FUND-01 (the same rewrite moves both `findOrFail` calls out of the catch) |
| FUND-03 | resolved by FUND-01 (all `Log::error` calls are removed; the central handler logs the exception object) |
| FUND-04 | resolved by FUND-01 (all six try/catch blocks are removed) |
| FUND-05 | resolved by FUND-01 (all six manual transactions become `DB::transaction`) |
| FUND-06 | resolved by FUND-01 (the `destroy()` event becomes `'Trashed'`) |
| FUND-12 | accepted for now: renaming `{id}` is a shared route re-scope for an L-severity shape issue, and the explicit `onlyTrashed()` lookup is required to 404 on a live id |
| FUND-18 | deferred: an enum/constants pass across the request, model, filters and five views; it belongs with the AccDashboard filter fix, not this controller |
