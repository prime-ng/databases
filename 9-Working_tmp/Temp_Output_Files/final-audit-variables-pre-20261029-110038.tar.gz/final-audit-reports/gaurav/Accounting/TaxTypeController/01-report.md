# Final Audit — Accounting / TaxTypeController

**Audited:** 2026-10-22 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/TaxTypeController.php` (239 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/configurations?tab=tax-types` (list tab), `/accounting/tax-type`, `/accounting/tax-type/create`, `/accounting/tax-type/{id}`, `/accounting/tax-type/{id}/edit`, `/accounting/tax-type/trash/view`, `/accounting/tax-type/{id}/restore`, `/accounting/tax-type/{id}/force-delete` |
| Menu path | Accounting → Configurations → Tax Types tab |
| Who uses it | No role holds any `tenant.accounting.tax-type.*` permission (exact-name count `0` in `sys_permissions`, `0` rows in `sys_role_has_permissions_jnt`). Five roles hold `tenant.accounting.dashboard.view`: Super Admin, School Admin, Management, Account Staff, Account Manager. Only the Super Admin role reaches the controller, through the `Gate::before` bypass. |
| What a user does here | Maintains the tax-type master: code, name, tax family, input-credit flag, display order and active status. A user creates one from the list tab modal, edits one, toggles active/inactive, moves one to the trash, restores it, or permanently deletes it. |
| Tables written | `acc_tax_types`, `sys_activity_logs` |
| Tables read | `acc_tax_types`; the list itself is read by `AccDashboardController` (out of this report's scope) |
| Live data | `acc_tax_types` 7 live, 0 trashed; `sys_activity_logs` 407 rows. The table has 6 seeded types (CGST, SGST, IGST, CESS, TDS, TCS) plus one added row. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No, this controller is not production-ready. The single worst finding is TXTP-06: every method authorizes with a `tenant.accounting.tax-type.*` permission that is not declared in `config/permissionslist.php` and is not seeded, so no role except Super Admin can reach the screen at all. Super Admin can reach it, and then hits TXTP-09: create and update send `tax_family = null` into a `NOT NULL` enum column, so every save fails with a raw SQL error (which TXTP-01 then shows in the browser). Restore is also a state change over GET (TXTP-10), and all six mutations hand-roll transactions and leak exception text (TXTP-01, TXTP-04). Rough effort is M, about one and a half developer-days, plus a permission sync performed by Tarun.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 3 | 2 | 7 | 3 | 5 | 15 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TXTP-01, TXTP-02, TXTP-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | TXTP-04, TXTP-05 | F9 Queries/Perf | TXTP-13 |
| F3 Authorization | TXTP-06, TXTP-07, TXTP-08 | F10 Views | clean |
| F4 Validation | TXTP-09 | F11 Security/Tenancy | clean |
| F5 Routes | TXTP-10 | F12 Style | TXTP-15 |
| F6 Controller shape | TXTP-11, TXTP-12 | F13 Deep read | TXTP-14 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/TaxTypeController.php` | controller | 239 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/TaxType.php` | model | 40 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/TaxTypeRequest.php` | FormRequest | 71 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/app/Policies/TaxTypePolicy.php` | policy | 55 | this report (unclaimed shared class) | ✅ |
| 5 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | model base | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 6 | `Modules/Accounting/app/Services/AccountingContext.php` | service (reached through the model base) | 110 | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 7 | `Modules/GlobalMaster/app/Models/ActivityLog.php` | model (reached through `activityLog()`) | 50 | ↗ [gaurav/Accounting/CostCategoryController](../CostCategoryController/01-report.md) | ↗ linked |
| 8 | `Modules/Accounting/resources/views/tax-type/create.blade.php` | view | 64 | this report | ✅ |
| 9 | `Modules/Accounting/resources/views/tax-type/edit.blade.php` | view | 96 | this report | ✅ |
| 10 | `Modules/Accounting/resources/views/tax-type/show.blade.php` | view | 88 | this report | ✅ |
| 11 | `Modules/Accounting/resources/views/tax-type/trash.blade.php` | view | 72 | this report | ✅ |
| 12 | `Modules/Accounting/resources/views/pages/partials/setup-masters/_tax-types.blade.php` | view (list tab, rendered by `AccDashboardController`) | 189 | not this report — `gaurav/Accounting/AccDashboardController` (CLAIMED) | ❌ out of scope, see §7 |
| 13 | `config/permissionslist.php` | shared config | 1798 | common/shared | checked only (F3) |
| 14 | `Modules/Accounting/routes/web.php` | shared route file | 536 | common/shared | checked only (F5) |
| 15 | `database/migrations/tenant/2026_09_16_100008_create_acc_tax_types_table.php` | migration | 46 | DDL — not edited by audits | checked only (F4/F7) |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/tax-type                                     accounting.tax-type.index           Modules\Accounting\Http\Controllers\TaxTypeController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/tax-type                                     accounting.tax-type.store           Modules\Accounting\Http\Controllers\TaxTypeController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tax-type/create                              accounting.tax-type.create          Modules\Accounting\Http\Controllers\TaxTypeController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tax-type/trash/view                          accounting.tax-type.trashed         Modules\Accounting\Http\Controllers\TaxTypeController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/tax-type/{id}/force-delete                   accounting.tax-type.forceDelete     Modules\Accounting\Http\Controllers\TaxTypeController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tax-type/{id}/restore                        accounting.tax-type.restore         Modules\Accounting\Http\Controllers\TaxTypeController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tax-type/{tax_type}                          accounting.tax-type.show            Modules\Accounting\Http\Controllers\TaxTypeController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/tax-type/{tax_type}                          accounting.tax-type.update          Modules\Accounting\Http\Controllers\TaxTypeController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/tax-type/{tax_type}                          accounting.tax-type.destroy         Modules\Accounting\Http\Controllers\TaxTypeController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tax-type/{tax_type}/edit                     accounting.tax-type.edit            Modules\Accounting\Http\Controllers\TaxTypeController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/tax-type/{tax_type}/toggle-status            accounting.tax-type.toggleStatus    Modules\Accounting\Http\Controllers\TaxTypeController@toggleStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none — all 11 public methods have a route (see the list above).

Route notes: `restore` is a `GET` route at `Modules/Accounting/routes/web.php:206` even though it writes (`TXTP-10`). The custom routes sit before `Route::resource` (`web.php:205-208`) except `toggle-status` at `web.php:209`; no collision exists because `toggle-status` is a POST with three URI segments while the resource POST route is `/tax-type` and the resource show route is two segments. The route parameter is `{id}` on `restore`/`forceDelete` and `{tax_type}` on the resource methods; the controller arguments match each name (`$id`, `$taxType`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | GET /accounting/tax-type | `tenant.accounting.tax-type.viewAny` | none | none | none | TXTP-06, TXTP-11 |
| `create` | 24 | GET /accounting/tax-type/create | `tenant.accounting.tax-type.create` | none | none | none | TXTP-06, TXTP-11, TXTP-14 |
| `store` | 31 | POST /accounting/tax-type | `tenant.accounting.tax-type.create` (also `TaxTypeRequest::authorize()`) | controller, manual (37-59) | `Created` | `acc_tax_types`, `sys_activity_logs` | TXTP-01, TXTP-03, TXTP-04, TXTP-06, TXTP-08, TXTP-09, TXTP-12, TXTP-14 |
| `show` | 62 | GET /accounting/tax-type/{tax_type} | `tenant.accounting.tax-type.view` | none | none | none | TXTP-06, TXTP-07, TXTP-11 |
| `edit` | 69 | GET /accounting/tax-type/{tax_type}/edit | `tenant.accounting.tax-type.update` | none | none | none | TXTP-06, TXTP-11, TXTP-14 |
| `update` | 76 | PUT/PATCH /accounting/tax-type/{tax_type} | `tenant.accounting.tax-type.update` (also `TaxTypeRequest::authorize()`) | controller, manual (80-102) | `Updated` | `acc_tax_types`, `sys_activity_logs` | TXTP-01, TXTP-03, TXTP-04, TXTP-06, TXTP-08, TXTP-09, TXTP-12, TXTP-14 |
| `destroy` | 105 | DELETE /accounting/tax-type/{tax_type} | `tenant.accounting.tax-type.delete` | controller, manual (109-134) | `Trashed` | `acc_tax_types`, `sys_activity_logs` | TXTP-01, TXTP-03, TXTP-04, TXTP-06, TXTP-12 |
| `toggleStatus` | 137 | POST /accounting/tax-type/{tax_type}/toggle-status | `tenant.accounting.tax-type.update` | controller, manual (143-172) | `Toggled` | `acc_tax_types`, `sys_activity_logs` | TXTP-01, TXTP-03, TXTP-04, TXTP-06, TXTP-12 |
| `trashed` | 175 | GET /accounting/tax-type/trash/view | `tenant.accounting.tax-type.restore` | none | none | none | TXTP-06, TXTP-13 |
| `restore` | 184 | GET /accounting/tax-type/{id}/restore | `tenant.accounting.tax-type.restore` | controller, manual (188-209) | `Restored` | `acc_tax_types`, `sys_activity_logs` | TXTP-01, TXTP-02, TXTP-03, TXTP-04, TXTP-06, TXTP-10, TXTP-12 |
| `forceDelete` | 212 | DELETE /accounting/tax-type/{id}/force-delete | `tenant.accounting.tax-type.forceDelete` | controller, manual (216-237) | `Deleted` | `acc_tax_types`, `sys_activity_logs` | TXTP-01, TXTP-02, TXTP-03, TXTP-04, TXTP-06, TXTP-12 |

## 6. Findings

### F1 — Errors

#### TXTP-01 · B · ERR-01 — The raw exception text is shown to the user in six write paths

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:58, 101, 133, 170, 208, 236`, methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Every mutation has its own `try/catch (\Throwable)` and appends `$e->getMessage()` to the flash or JSON message. `QueryException` extends `RuntimeException`, so a duplicate key, the `tax_family` NOT NULL failure or a trigger error reaches the browser as SQL text. |
| **Consequence** | A user who saves a tax type sees the database error (for example `SQLSTATE[23000]: Column 'tax_family' cannot be null`) instead of a friendly message, and table/column names are exposed. |
| **Reproduce** | As Super Admin, open the Tax Types tab and submit the create modal with a valid code and name. The save fails at TXTP-09 and the red flash contains the SQL error. |
| **Fix approach** | Remove the `try/catch` (D1) and let `bootstrap/app.php` render the error. The plan item TXTP-01 rewrites all six methods to `DB::transaction` closures. |
| **Plan item** | TXTP-01 in `02-fix-plan.md` §1 |

```php
// TaxTypeController.php:51-58 — CURRENT
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Tax Type', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Tax Type: ' . $e->getMessage());
        }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxTypeController.php" -Pattern "getMessage" | ForEach-Object { "$($_.LineNumber):$($_.Line)" }
54:                'error' => $e->getMessage(),
58:            return back()->withInput()->with('error', 'Failed to create Tax Type: ' . $e->getMessage());
98:                'error' => $e->getMessage(),
101:            return back()->withInput()->with('error', 'Failed to update Tax Type: ' . $e->getMessage());
130:                'error' => $e->getMessage(),
133:            return back()->with('error', 'Failed to delete Tax Type: ' . $e->getMessage());
165:                'error' => $e->getMessage()
170:                'message' => 'Failed to update status: ' . $e->getMessage()
206:            Log::error('Failed to restore Tax Type', ['id' => $id, 'error' => $e->getMessage()]);
208:            return back()->with('error', 'Failed to restore Tax Type: ' . $e->getMessage());
234:            Log::error('Failed to force delete Tax Type', ['id' => $id, 'error' => $e->getMessage()]);
236:            return back()->with('error', 'Failed to delete Tax Type: ' . $e->getMessage());
```

#### TXTP-02 · H · ERR-02 — A missing record becomes a redirect instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:190` (`restore()`), `:218` (`forceDelete()`) |
| **Root cause** | `findOrFail()` sits inside the `try`, and `catch (\Throwable $e)` swallows `ModelNotFoundException`, redirects back and flashes "Failed to restore" or "Failed to delete". |
| **Consequence** | A restore or force-delete URL for an id that is not in the expected state (already restored, already deleted, or a stale link) shows a red flash instead of a 404, so the operator cannot tell a bad link from a server failure. |
| **Reproduce** | Open `/accounting/tax-type/999999/restore` as Super Admin. Expected 404; actual redirect with "Failed to restore Tax Type". |
| **Fix approach** | Move `findOrFail()` above the transaction; the D1 rewrite in TXTP-01 removes the `try` entirely. |
| **Plan item** | none — fixed by TXTP-01; see `02-fix-plan.md` §10 |

```php
// TaxTypeController.php:188-191 — CURRENT
        DB::beginTransaction();
        try {
            $model = TaxType::onlyTrashed()->findOrFail($id);
            $model->restore();

// TaxTypeController.php:216-218 — CURRENT
        DB::beginTransaction();
        try {
            $model = TaxType::withTrashed()->findOrFail($id);
            $name = $model->name;
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxTypeController.php" -Pattern "findOrFail|catch \(" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
51:} catch (\Throwable $e) {
94:} catch (\Throwable $e) {
126:} catch (\Throwable $e) {
161:} catch (\Throwable $e) {
190:$model = TaxType::onlyTrashed()->findOrFail($id);
204:} catch (\Throwable $e) {
218:$model = TaxType::withTrashed()->findOrFail($id);
232:} catch (\Throwable $e) {
```

#### TXTP-03 · M · ERR-05 — The log records the message string, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:53-56, 96-99, 128-131, 163-166, 206, 234` |
| **Root cause** | The catches call `Log::error()` with only a message string; `store()` also stores `getTraceAsString()` as text. No exception object is passed, so the handler cannot render or group the failure. |
| **Consequence** | Production debugging is slower: the log has a string, not the exception class and stack, and nothing is reported to the central handler. |
| **Reproduce** | Static only — a log inspection is needed after forcing any write failure. |
| **Fix approach** | Let the exception escape (D1) so the central handler logs the object; if a D2 catch is ever kept, use `report($e)`. |
| **Plan item** | none — fixed by TXTP-01; see `02-fix-plan.md` §10 |

```php
// TaxTypeController.php:53-56 — CURRENT
            Log::error('Failed to create Tax Type', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxTypeController.php" -Pattern "Log::error" | ForEach-Object { "$($_.LineNumber): $($_.Line.Trim())" }
53:Log::error('Failed to create Tax Type', [
96:Log::error('Failed to update Tax Type', [
128:Log::error('Failed to delete Tax Type', [
163:Log::error('Failed to toggle Tax Type status', [
206:Log::error('Failed to restore Tax Type', ['id' => $id, 'error' => $e->getMessage()]);
234:Log::error('Failed to force delete Tax Type', ['id' => $id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### TXTP-04 · M · TXN-02 — Six methods hand-roll `beginTransaction`/`commit`/`rollBack`

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:37-59, 80-102, 109-134, 143-172, 188-209, 216-237` |
| **Root cause** | Each mutation opens a transaction by hand and guards it with a controller `try/catch` (D1 forbids that shape). A future early `return` between `beginTransaction()` and `commit()` leaves the connection inside an open transaction. |
| **Consequence** | The write paths are fragile: one added early return or throw can leak a transaction and make later queries on the same request behave unpredictably. |
| **Reproduce** | Static only — the current paths reach commit or rollBack, but the shape is not safe to extend. |
| **Fix approach** | Wrap each mutation in `DB::transaction(function () { … })`; build the redirect/JSON after the closure. TXTP-01 does this for all six methods. |
| **Plan item** | none — fixed by TXTP-01; see `02-fix-plan.md` §10 |

```php
// TaxTypeController.php:37-59 — CURRENT (store)
        DB::beginTransaction();
        try {
            $taxType = TaxType::create($validated);

            activityLog($taxType, 'Created', [
                'message'      => 'Tax Type created: ' . $taxType->name . ' (' . $taxType->code . ')',
                'name'         => $taxType->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])
                ->with('success', 'Tax Type created successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Tax Type', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Tax Type: ' . $e->getMessage());
        }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxTypeController.php" -Pattern "DB::beginTransaction|DB::commit|DB::rollBack" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
37:DB::beginTransaction();
47:DB::commit();
52:DB::rollBack();
80:DB::beginTransaction();
90:DB::commit();
95:DB::rollBack();
109:DB::beginTransaction();
122:DB::commit();
127:DB::rollBack();
143:DB::beginTransaction();
154:DB::commit();
162:DB::rollBack();
188:DB::beginTransaction();
200:DB::commit();
205:DB::rollBack();
216:DB::beginTransaction();
228:DB::commit();
233:DB::rollBack();
```

#### TXTP-05 · M · TXN-06 — The name-uniqueness check has no database index to back it

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M, lowered from H: the duplicate is cosmetic and `code` is still protected by `uq_acc_tt_code`) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/Accounting/app/Http/Requests/TaxTypeRequest.php:36-40` |
| **Root cause** | `Rule::unique('acc_tax_types', 'name')` checks for an existing row and then the insert runs. The table has no unique index on `name`, so two simultaneous submits can both pass the check and both insert. |
| **Consequence** | Two users saving the same name at the same moment can create duplicate tax-type names; the list then shows two rows that validation would otherwise have rejected. |
| **Reproduce** | Static only — the race needs two concurrent POSTs; the index list below proves the missing constraint. |
| **Fix approach** | Decide whether names are globally unique. If yes, add a unique index in a new migration (Tarun runs `php artisan tenants:migrate`); if no, drop the name unique rule. |
| **Plan item** | TXTP-05 in `02-fix-plan.md` §9 (DECISION) |

```php
// TaxTypeRequest.php:36-40 — CURRENT
            'name'       => [
                'required',
                'string',
                'max:100',
                Rule::unique('acc_tax_types', 'name')->ignore($id)
            ],
```

**Evidence**
```
> mysql -u root -N -e "SHOW INDEX FROM xyz_school_00000000000040008000_202627.acc_tax_types;"
acc_tax_types	0	PRIMARY	1	id	A	7	NULL	NULL		BTREE			YES	NULL
acc_tax_types	0	uq_acc_tt_code	1	code	A	7	NULL	NULL		BTREE			YES	NULL
acc_tax_types	1	idx_acc_tt_family	1	tax_family	A	3	NULL	NULL		BTREE			YES	NULL
acc_tax_types	1	idx_acc_tt_family	2	is_active	A	4	NULL	NULL		BTREE			YES	NULL
```

### F3 — Authorization

#### TXTP-06 · B · AUTH-01 — The permission namespace does not exist, so every method denies every non-super-admin role

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B) — *every routed method authorizes with a permission that is declared in `config/permissionslist.php` and seeded* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:19, 26, 33, 64, 71, 78, 107, 139, 177, 186, 214`; `config/permissionslist.php:600-616` |
| **Root cause** | Every gate names `tenant.accounting.tax-type.*`, but the `accounting.tax-type` key was never added to the Accounting block in `config/permissionslist.php`, and the live tenant has `0` such rows. Spatie's `Gate::before` only grants an ability the user actually holds; the Super Admin role is the only bypass. |
| **Consequence** | School Admin, Management, Account Staff and Account Manager get 403 on every route, and the Tax Types tab is hidden from them; only Super Admin can use the feature. |
| **Reproduce** | Log in as a School Admin and open `/accounting/tax-type`. Expected the list; actual 403. The tab strip also omits Tax Types. |
| **Fix approach** | Add `'accounting.tax-type' => $crud` beside `'accounting.tax-rate' => $crud`, then run `/system-config/sync-permissions` and grant the new keys to the accounting roles. Both are Tarun's hand. |
| **Plan item** | TXTP-06 in `02-fix-plan.md` §1 (DECISION, ⚠ SHARED) |

```php
// TaxTypeController.php:17-22 — CURRENT (index(); all 11 methods use the same pattern)
    public function index()
    {
        Gate::authorize('tenant.accounting.tax-type.viewAny');

        return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types']);
    }
```

**Evidence**
```
> Select-String -Path "config\permissionslist.php" -Pattern "accounting.tax-type"
(no output)
> mysql -u root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_permissions WHERE name LIKE 'tenant.accounting.tax-type%';"
0
> mysql -u root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_role_has_permissions_jnt j JOIN xyz_school_00000000000040008000_202627.sys_permissions p ON p.id=j.permission_id WHERE p.name LIKE 'tenant.accounting.tax-type%';"
0
> mysql -u root -N -e "SELECT r.name FROM xyz_school_00000000000040008000_202627.sys_roles r JOIN xyz_school_00000000000040008000_202627.sys_role_has_permissions_jnt j ON j.role_id=r.id JOIN xyz_school_00000000000040008000_202627.sys_permissions p ON p.id=j.permission_id WHERE p.name='tenant.accounting.dashboard.view';"
Super Admin
School Admin
Management
Account Staff
Account Manager
```

#### TXTP-07 · M · AUTH-05 — `TaxTypePolicy` is registered but no gate ever consults it

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — *no dead permission logic; a policy that nothing consults is dead logic* |
| **Where** | `Modules/Accounting/app/Policies/TaxTypePolicy.php:13-18`; registration at `Modules/Accounting/app/Providers/AccountingServiceProvider.php:135` |
| **Root cause** | All 11 checks pass a string ability (`Gate::authorize('tenant.accounting.tax-type.viewAny')`). The Gate resolves a string through Spatie's permission check, never through `TaxTypePolicy`. The policy's `dashboard.view` fallback and its `is_super_admin` check therefore never run. |
| **Consequence** | The intended fallback for the five dashboard roles is silently dead; a reader of the policy believes those roles can view tax types, while the controller still returns 403. |
| **Reproduce** | Static only — `Gate::authorize('viewAny', TaxType::class)` does not appear anywhere in the controller. |
| **Fix approach** | Either accept the policy as inert (fix TXTP-06 first), switch the 11 calls to policy form (`Gate::authorize('viewAny', TaxType::class)`), or delete the policy and its provider line. |
| **Plan item** | TXTP-07 in `02-fix-plan.md` §9 (DECISION) |

```php
// TaxTypePolicy.php:13-18 — CURRENT
    public function viewAny(User $user): bool
    {
        return $user->can('tenant.accounting.tax-type.viewAny')
            || $user->can('tenant.accounting.dashboard.view')
            || ($user->is_super_admin ?? false);
    }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxTypeController.php" -Pattern "Gate::authorize\('view"
(no output)
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxTypeController.php" -Pattern "Gate::authorize" | ForEach-Object { "$($_.LineNumber):$($_.Line.Trim())" }
19:Gate::authorize('tenant.accounting.tax-type.viewAny');
26:Gate::authorize('tenant.accounting.tax-type.create');
33:Gate::authorize('tenant.accounting.tax-type.create');
64:Gate::authorize('tenant.accounting.tax-type.view');
71:Gate::authorize('tenant.accounting.tax-type.update');
78:Gate::authorize('tenant.accounting.tax-type.update');
107:Gate::authorize('tenant.accounting.tax-type.delete');
139:Gate::authorize('tenant.accounting.tax-type.update');
177:Gate::authorize('tenant.accounting.tax-type.restore');
186:Gate::authorize('tenant.accounting.tax-type.restore');
214:Gate::authorize('tenant.accounting.tax-type.forceDelete');
```

#### TXTP-08 · L · AUTH-04 — `store`/`update` authorize the same permission twice

| Field | Value |
| --- | --- |
| **Rule** | AUTH-04 (L) — *do not authorize the same permission twice; keep one* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:33` (`store`), `:78` (`update`); `Modules/Accounting/app/Http/Requests/TaxTypeRequest.php:16` |
| **Root cause** | The FormRequest calls `authorizeByCrudPermission('tenant.accounting.tax-type')` (POST becomes `create`, PUT/PATCH becomes `update`), and the controller then runs `Gate::authorize` with the identical string. |
| **Consequence** | No runtime difference; a future permission rename must be made in two places, and one copy can drift. |
| **Reproduce** | Static only — two authorization calls run on every store and update. |
| **Fix approach** | Remove the two controller `Gate::authorize` lines; the FormRequest already authorizes. TXTP-01 does this. |
| **Plan item** | none — fixed by TXTP-01; see `02-fix-plan.md` §10 |

```php
// TaxTypeController.php:31-35 — CURRENT
    public function store(TaxTypeRequest $request)
    {
        Gate::authorize('tenant.accounting.tax-type.create');

        $validated = $request->validated();
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\TaxTypeRequest.php","Modules\Accounting\app\Http\Controllers\TaxTypeController.php" -Pattern "authorizeByCrudPermission|Gate::authorize\('tenant.accounting.tax-type.create'\)|Gate::authorize\('tenant.accounting.tax-type.update'\)" | ForEach-Object { "$($_.Filename):$($_.LineNumber): $($_.Line.Trim())" }
TaxTypeRequest.php:16: return $this->authorizeByCrudPermission('tenant.accounting.tax-type');
TaxTypeController.php:33: Gate::authorize('tenant.accounting.tax-type.create');
TaxTypeController.php:78: Gate::authorize('tenant.accounting.tax-type.update');
```

### F4 — Validation and input

#### TXTP-09 · B · VAL-05 — `tax_family` is nullable and untyped, but the column is a NOT NULL 4-value enum, so every create and update fails

| Field | Value |
| --- | --- |
| **Rule** | VAL-05 (B, raised from M: both write paths are dead on a normal user path) — *every field is typed and validation mirrors the column* |
| **Where** | `Modules/Accounting/app/Http/Requests/TaxTypeRequest.php:41` and `:66`; column at `database/migrations/tenant/2026_09_16_100008_create_acc_tax_types_table.php:23` |
| **Root cause** | The request declares `tax_family` as `nullable|string|max:50` and `prepareForValidation()` converts an absent value to `null`. The column is `enum('GST','TDS','TCS','Other') NOT NULL DEFAULT 'GST'` (confirmed live), and MySQL runs with `STRICT_TRANS_TABLES`. Neither the create modal nor `create.blade.php` nor `edit.blade.php` has a `tax_family` control, so every save explicitly inserts `NULL` into a NOT NULL column. |
| **Consequence** | Every create and every edit fails with `SQLSTATE[23000]: Column 'tax_family' cannot be null`; because of TXTP-01 the user sees that SQL text in the red flash. A crafted request with `tax_family=VAT` also passes validation and then fails at the enum. |
| **Reproduce** | As Super Admin, open the Tax Types tab and submit the modal with code `TEST1`, name `Test 1`, Active on. Expected a created row; actual red flash containing the SQL error 1048. |
| **Fix approach** | Default an absent `tax_family` to `'GST'` in `prepareForValidation()` and constrain the rule with `Rule::in(TaxType::taxFamilies())`. The plan item TXTP-09 does both. |
| **Plan item** | TXTP-09 in `02-fix-plan.md` §1 |

```php
// TaxTypeRequest.php:41 — CURRENT
            'tax_family' => ['nullable', 'string', 'max:50'],

// TaxTypeRequest.php:66 — CURRENT
            'tax_family' => $this->input('tax_family') ? strtoupper(trim((string) $this->input('tax_family'))) : null,
```

**Evidence**
```
> mysql -u root -N -e "SHOW COLUMNS FROM xyz_school_00000000000040008000_202627.acc_tax_types;"
id	smallint unsigned	NO	PRI	NULL	auto_increment
code	varchar(15)	NO	UNI	NULL
name	varchar(100)	NO		NULL
tax_family	enum('GST','TDS','TCS','Other')	NO	MUL	GST
is_input	tinyint(1)	NO		0
ordinal	smallint unsigned	NO		0
is_active	tinyint(1)	NO		1
created_at	timestamp	NO		CURRENT_TIMESTAMP	DEFAULT_GENERATED
updated_at	timestamp	NO		CURRENT_TIMESTAMP	DEFAULT_GENERATED on update CURRENT_TIMESTAMP
deleted_at	timestamp	YES		NULL
> mysql -u root -N -e "SELECT @@sql_mode;"
ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION
> Select-String -Path "Modules\Accounting\resources\views\tax-type\create.blade.php","Modules\Accounting\resources\views\tax-type\edit.blade.php" -Pattern "tax_family|is_input|ordinal"
(no output)
```

### F5 — Routes

#### TXTP-10 · H · RTE-01 — Restoring a tax type changes state over GET

| Field | Value |
| --- | --- |
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:206`; handler `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:184-210` |
| **Root cause** | The route is `Route::get('/tax-type/{id}/restore', [TaxTypeController::class, 'restore'])`, and `restore()` writes `deleted_at = NULL` and `is_active = true`. |
| **Consequence** | A prefetcher, a crawler or a pasted URL can restore a trashed tax type without a CSRF token or a confirmation, and the action is recorded as if the user did it. |
| **Reproduce** | While logged in as Super Admin, open `/accounting/tax-type/{trashed-id}/restore` directly. The record is restored on a plain GET. |
| **Fix approach** | Register the route as `DELETE`; the shared `x-backend.table.action-trashed` component already renders the route's real verb with a CSRF token. |
| **Plan item** | TXTP-10 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// Modules/Accounting/routes/web.php:206 — CURRENT
Route::get('/tax-type/{id}/restore', [TaxTypeController::class, 'restore'])->name('tax-type.restore');
```

**Evidence**
```
> php artisan route:list --json | php routesprobe.php "Modules\Accounting\Http\Controllers\TaxTypeController"
GET|HEAD  accounting/tax-type/{id}/restore                        accounting.tax-type.restore         Modules\Accounting\Http\Controllers\TaxTypeController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

### F6 — Controller shape

#### TXTP-11 · L · CTL-04 — Eight public methods have no return type

| Field | Value |
| --- | --- |
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:17, 24, 31, 62, 69, 76, 105, 137` |
| **Root cause** | `index`, `create`, `store`, `show`, `edit`, `update`, `destroy` and `toggleStatus` declare no return type; only `trashed`, `restore` and `forceDelete` do. |
| **Consequence** | The controller's contract is invisible to static analysis, and a wrong return in a branch becomes a runtime `TypeError` only. |
| **Reproduce** | Static only — the signatures are quoted below. |
| **Fix approach** | Add `RedirectResponse`, `View`, `JsonResponse` return types. |
| **Plan item** | TXTP-11 in `02-fix-plan.md` §8 |

```php
// TaxTypeController.php:17-137 — CURRENT
    public function index()
    public function create()
    public function store(TaxTypeRequest $request)
    public function show(TaxType $taxType)
    public function edit(TaxType $taxType)
    public function update(TaxTypeRequest $request, TaxType $taxType)
    public function destroy(TaxType $taxType)
    public function toggleStatus(Request $request, TaxType $taxType)
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxTypeController.php" -Pattern "public function" | ForEach-Object { "$($_.LineNumber): $($_.Line.Trim())" }
17: public function index()
24: public function create()
31: public function store(TaxTypeRequest $request)
62: public function show(TaxType $taxType)
69: public function edit(TaxType $taxType)
76: public function update(TaxTypeRequest $request, TaxType $taxType)
105: public function destroy(TaxType $taxType)
137: public function toggleStatus(Request $request, TaxType $taxType)
175: public function trashed(): \Illuminate\View\View
184: public function restore($id): \Illuminate\Http\RedirectResponse
212: public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

#### TXTP-12 · M · CTL-05 — Six mutations copy the same audit/redirect block

| Field | Value |
| --- | --- |
| **Rule** | CTL-05 (M) — *no copy-paste; the same redirect string and the same payload repeated across methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:41-45, 84-88, 116-120, 148-152, 194-198, 222-226` |
| **Root cause** | Every mutation rebuilds the same `activityLog($model, event, ['message' => …, 'name' => …, 'performed_by' => auth()->id()])` array and the same `redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])` chain. |
| **Consequence** | A change to the audit payload or the return URL must be made in six places; one missed copy produces an inconsistent audit trail. |
| **Reproduce** | Static only — the six identical arrays are listed by the evidence command. |
| **Fix approach** | Accept for this pass: the TXTP-01 rewrite normalises the six blocks; extracting a helper would save about ten lines but add indirection for a 239-line controller. |
| **Plan item** | none — accepted; see `02-fix-plan.md` §10 |

```php
// TaxTypeController.php:41-45 — CURRENT (one of six copies)
            activityLog($taxType, 'Created', [
                'message'      => 'Tax Type created: ' . $taxType->name . ' (' . $taxType->code . ')',
                'name'         => $taxType->name,
                'performed_by' => auth()->id(),
            ]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxTypeController.php" -Pattern "activityLog\(" | ForEach-Object { "$($_.LineNumber): $($_.Line.Trim())" }
41:activityLog($taxType, 'Created', [
84:activityLog($taxType, 'Updated', [
116:activityLog($taxType, 'Trashed', [
148:activityLog($taxType, 'Toggled', [
194:activityLog($model, 'Restored', [
222:activityLog($model, 'Deleted', [
```

### F7 — Models

clean — `Select-String -Path "Modules/Accounting/app/Models/TaxType.php" -Pattern "\$table|\$fillable|\$casts|SoftDeletes"` returns `protected $table = 'acc_tax_types';`, `$fillable` with six columns, `$casts` for both booleans and `ordinal`, and `use SoftDeletes;`; `SHOW COLUMNS FROM acc_tax_types` shows the matching `deleted_at` column, and the live table exists. `MDL-01`, `MDL-02`, `MDL-05`, `MDL-07` and `MDL-08` are not present. The only model defect is the unused `App\Models\BaseModel` import, counted under TXTP-15 (STY-02).

### F8 — Services and jobs

clean — the controller injects no service and dispatches no job: `Select-String -Path "Modules/Accounting/app/Http/Controllers/TaxTypeController.php" -Pattern "Service|Job|dispatch|Event::"` returns no output.

### F9 — Queries and performance

#### TXTP-13 · M · QRY-02 — The trash list paginates at 15, not the standard 10, with the default page name

| Field | Value |
| --- | --- |
| **Rule** | QRY-02 (M) / C12 — *lists paginate; the standard page size is 10 with a distinct `pageName` per list* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:179` |
| **Root Cause** | `paginate(15)` uses a non-standard size and the default `page` name. |
| **Consequence** | The trash list shows 15 rows instead of the house standard 10, and a future second paginator on the same screen would collide on `?page=`. |
| **Reproduce** | Open `/accounting/tax-type/trash/view`; the paginator offers 15 rows per page. |
| **Fix approach** | `paginate(10, ['*'], 'tt_page')`, matching the list tab's `tt_page` name. |
| **Plan item** | TXTP-13 in `02-fix-plan.md` §6 |

```php
// TaxTypeController.php:179 — CURRENT
        $taxTypes = TaxType::onlyTrashed()->orderBy('name')->paginate(15);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxTypeController.php" -Pattern "paginate\(" | ForEach-Object { "$($_.LineNumber): $($_.Line.Trim())" }
179: $taxTypes = TaxType::onlyTrashed()->orderBy('name')->paginate(15);
```

### F10 — Views

clean — `Select-String -Path "Modules/Accounting/resources/views/tax-type/create.blade.php","Modules/Accounting/resources/views/tax-type/edit.blade.php","Modules/Accounting/resources/views/tax-type/show.blade.php","Modules/Accounting/resources/views/tax-type/trash.blade.php" -Pattern "Model::|DB::|->where\(|->get\(|->count\(|\{!!|@php"` returns no output. The trash rows use `x-backend.table.action-trashed` and the edit link is wrapped in `@can('tenant.accounting.tax-type.update')`. The four blades were not compiled or rendered (D4); see §8.

### F11 — Security and tenancy

clean — `Select-String -Path "Modules/Accounting/app/Http/Controllers/TaxTypeController.php" -Pattern "env\(|Log::.*request|->all\(\)|except\(|\?\? 1"` returns no output. The route probe shows the full tenant stack (`PreventAccessFromCentralDomains`, `InitializeTenancyByDomain`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Accounting`, `Authenticate`, `EnsureEmailIsVerified`) on every route.

### F12 — Style

#### TXTP-15 · L · STY-02 — Pint fails on all three in-scope PHP files

| Field | Value |
| --- | --- |
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxTypeController.php`, `Modules/Accounting/app/Models/TaxType.php`, `Modules/Accounting/app/Http/Requests/TaxTypeRequest.php` |
| **Root cause** | The files were written with aligned `=>` arrays, spaced concatenation, fully-qualified return types, an unsorted import and an unused `App\Models\BaseModel` import. |
| **Consequence** | The touched files fail the repository's formatter gate; future diffs carry unrelated whitespace noise. |
| **Reproduce** | Run `vendor\bin\pint --test "Modules/Accounting/app/Http/Controllers/TaxTypeController.php" --format agent`. |
| **Fix approach** | Apply the formatter item in `02-fix-plan.md` §8; the command is the change. |
| **Plan item** | TXTP-15 in `02-fix-plan.md` §8 |

```php
// TaxType.php:7 — CURRENT
use App\Models\BaseModel;

// TaxTypeRequest.php:7-9 — CURRENT
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Validation\Rule;

// TaxTypeController.php:175 — CURRENT
    public function trashed(): \Illuminate\View\View
```

**Evidence**
```
> vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\TaxTypeController.php" "Modules\Accounting\app\Models\TaxType.php" "Modules\Accounting\app\Http\Requests\TaxTypeRequest.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\TaxTypeController.php","fixers":["fully_qualified_strict_types","concat_space","trailing_comma_in_multiline","ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Models\\TaxType.php","fixers":["no_unused_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Http\\Requests\\TaxTypeRequest.php","fixers":["trailing_comma_in_multiline","ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 Wrong data? | Q2 Irreversible order? | Q3 Duplicate implementation? | Q4 Soft-delete × unique? | Q5 Race? | Q6 Authorization hole? | Q7 Lying message? | Q8 Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok (code rule includes trashed, matching `uq_acc_tt_code`) | TXTP-05 (name) | TXTP-06, TXTP-08 | ok | TXTP-14 |
| `update` | ok | ok | ok | ok | TXTP-05 (name) | TXTP-06, TXTP-08 | ok | TXTP-14 |
| `destroy` | ok (sets `is_active = false` before the soft delete, which is the intended trash state) | ok (audit row written after the delete, inside the transaction) | ok | ok | ok | TXTP-06 | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | TXTP-06 | ok | ok |
| `restore` | ok (reactivates the restored row by design) | ok | ok | ok (the code cannot be reused while trashed) | ok | TXTP-06 | ok | ok |
| `forceDelete` | ok | ok (the audit row is inside the transaction; a log failure rolls the delete back) | ok | ok | ok | TXTP-06 | ok | ok |

The only deep-read defect is Q8/TXTP-14: `tax_family`, `is_input` and `ordinal` exist on the model, are validated and are exported, but no create or edit control writes them, so the list's Tax Family and Input Credit filters can never match a user-set value.

#### TXTP-14 · M · F13-Q8 — Three validated columns have no input control, so the family/credit filters are dead

| Field | Value |
| --- | --- |
| **Rule** | F13-Q8 (M) — *dead feature: a screen whose saved data no consumer reads, or a field no screen writes* |
| **Where** | `Modules/Accounting/resources/views/tax-type/create.blade.php:23-48`, `Modules/Accounting/resources/views/tax-type/edit.blade.php:43-67`, `Modules/Accounting/resources/views/pages/partials/setup-masters/_tax-types.blade.php:17-29` |
| **Root cause** | The create form and the create modal submit only `code`, `name` and `is_active`; the edit form submits the same three. `tax_family`, `is_input` and `ordinal` are therefore never user-set, while the list tab offers Tax Family and Input Credit filters and exports all three columns. |
| **Consequence** | Users cannot create a TDS, TCS or input-credit tax type from the UI; every new row is GST/Output/ordinal 0, so the family and credit filters only ever match the seeded rows. |
| **Reproduce** | Open the create modal, enter a code and name, save. The new row shows Tax Family `GST` and Input Credit `No`; there was no control to choose otherwise. |
| **Fix approach** | Add the three controls to the modal and the edit view, or remove the filters/columns from the list partial. Both are UI decisions; the modal lives in the `AccDashboardController` partial. |
| **Plan item** | TXTP-14 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// create.blade.php:23-48 — CURRENT
                        <form action="{{ route('accounting.tax-type.store') }}" method="POST">
                            @csrf

                            <div class="bg-white rounded p-4 mb-4 border shadow-sm">
                                <h6 class="fw-semibold mb-3 text-secondary border-bottom pb-2">Tax Type Details</h6>
                                <div class="row g-4 mb-4">
                                    <div class="col-md-6 col-lg-4">
                                        <x-backend.form.input-text type="text" name="code" id="code" label="Code"
                                            placeholder="Enter Code (e.g. CGST)" maxlength="10" required="true"
                                            value="{{ old('code') }}" />
                                    </div>

                                    <div class="col-md-6 col-lg-4">
                                        <x-backend.form.input-text type="text" name="name" id="name" label="Name"
                                            placeholder="Enter Name (e.g. Central GST)" required="true"
                                            value="{{ old('name') }}" />
                                    </div>

                                    <div class="col-md-4 d-flex align-items-center">
                                        <div class="form-check form-switch pt-1">
                                            <input type="checkbox" name="is_active" id="is_active"
                                                class="form-check-input" value="1"
                                                {{ old('is_active', true) ? 'checked' : '' }}>
                                            <label for="is_active" class="form-check-label ps-2">Active Status</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\resources\views\tax-type\create.blade.php","Modules\Accounting\resources\views\tax-type\edit.blade.php" -Pattern "tax_family|is_input|ordinal"
(no output)
> Select-String -Path "Modules\Accounting\resources\views\pages\partials\setup-masters\_tax-types.blade.php" -Pattern "tax_family|is_input|ordinal" | ForEach-Object { "$($_.LineNumber): $($_.Line.Trim())" }
17: <select name="tax_family" class="form-select form-select-sm" style="width: auto; min-width: 125px;">
26: <select name="is_input" class="form-select form-select-sm" style="width: auto; min-width: 125px;">
51: 'Tax Family' => (request('tab') === 'tax-types' && request('tax_family')) ? request('tax_family') : null,
52: 'Input'      => (request('tab') === 'tax-types' && request('is_input') !== null && request('is_input') !== '') ? (request('is_input') === '1' ? 'Input Credit' : 'Output') : null,
59: 'columns'    => ['code', 'name', 'tax_family', 'is_input', 'ordinal', 'is_active'],
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_tax-types.blade.php` | The Tax Family filter offers `VAT` and `Service_Tax`, which are not in the `acc_tax_types.tax_family` enum; it also implies the three columns are editable when no form writes them. | VAL-05 / F13-Q8 | `gaurav/Accounting/AccDashboardController` (CLAIMED) |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:548-566` | The list tab queries `TaxType::orderBy('code')` and paginates at 25 with `tt_page`; this is the real list surface, not `TaxTypeController@index` (which only redirects). | QRY-02 (context only) | `gaurav/Accounting/AccDashboardController` (CLAIMED) |
| `resources/views/components/backend/table/action-trashed.blade.php` | Reads the route verb dynamically and already emits `@csrf` plus `@method` for a non-GET restore, so the TXTP-10 route change needs no component edit. Recorded so the fixer does not touch the shared component. | RTE-01 (context only) | no change needed |
| `Modules/Accounting/app/Providers/AccountingServiceProvider.php:135` | Registers `TaxTypePolicy` that nothing consults; see TXTP-07. The provider is shared by the whole module. | AUTH-05 | this report's TXTP-07 decision; provider edit is ⚠ SHARED |

## 8. Not covered, and why

- **Scanner and self-check were skipped.** `final-audit-reports/_tools/scanfilter.py` and `selfcheck.py` are missing, and the tooling override forbids running `scan.php`. F1–F13 were checked manually with `read`/`grep`/`Select-String` and the SQL queries quoted above.
- **No tests, no browser run (D4).** Every "Reproduce" that needs a click is marked as such; the SQL and route evidence is static.
- **The list tab is not this controller's code.** `AccountingController@index` only redirects; the list, its filters, its export buttons and the create modal are rendered by `AccDashboardController::configurations()`. That controller's report owns those findings. The tables and counts here describe the data the screen touches, not that controller's implementation.
- **The create/edit blades were not compiled or rendered (D4).** Their content was read and grepped; a Pint/blade-compile check belongs to the fixer's §10 verification.
- **`TaxTypePolicy` was audited statically.** No live user was impersonated to prove the 403/redirect behaviour; the permission counts and the Spatie `Gate::before` implementation are the proof.
- **The DB row counts are a snapshot** of `xyz_school_00000000000040008000_202627` on 2026-10-22 (`acc_tax_types` 7 live, 0 trashed; `sys_activity_logs` 407).
