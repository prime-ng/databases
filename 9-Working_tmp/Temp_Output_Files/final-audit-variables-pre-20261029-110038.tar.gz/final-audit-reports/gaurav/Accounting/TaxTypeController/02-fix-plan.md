# Fix Plan — Accounting / TaxTypeController

**From:** `01-report.md` (2026-10-22) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/TaxTypeController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | shared route file; TXTP-10 is deferred and needs Tarun's own tick |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_tax-types.blade.php` | owned by `gaurav/Accounting/AccDashboardController`; TXTP-14 is a UI decision |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | owned by another claimed report; it renders the real list tab |
| `resources/views/components/backend/table/action-trashed.blade.php` | shared component; already handles a DELETE restore, so no edit is needed |
| `Modules/Accounting/app/Providers/AccountingServiceProvider.php` | shared module provider; only TXTP-07 option (c) would touch it, and only on Tarun's tick |
| `database/migrations/tenant/2026_09_16_100008_create_acc_tax_types_table.php` | applied migration; TXTP-05 option (a) creates a NEW migration instead |

## 1. Blockers reachable today

- [ ] **TXTP-06** · B · AUTH-01 · DECISION · `config/permissionslist.php:614` — declare the `accounting.tax-type` permission key so the gates can ever pass.
  - **Why it is a decision:** it edits a shared config file and needs a live permission sync plus role grants; only Tarun can run that on the tenants.
  - **Touches:** `config/permissionslist.php` (⚠ SHARED) and the tenant permission sync.
  - **Before** (`permissionslist.php:614`):
    ```php
            'accounting.tax-rate' => $crud,
    ```
  - **After:**
    ```php
            'accounting.tax-rate' => $crud,
            'accounting.tax-type' => $crud,
    ```
  - **Ops step (not the fixer):** open `http://test.localhost:8000/system-config/sync-permissions?apply=1&tenant=00000000-0000-4000-8000-000000000000` as Super Admin. The endpoint is additive and grants the new keys to Super Admin and School Admin only. Management, Account Staff and Account Manager get the keys from option (b) below.
  - (a) ⭐ Add the key, sync, and grant `tenant.accounting.tax-type.*` to the four non-super-admin accounting roles.
  - (b) Add the key and sync only; School Admin works, the other three roles stay 403 until granted later.
  - (c) Do not add the key; leave the feature Super-Admin-only and accept the 403s.
  - ➜ Choice: ____
  - **Verify:** `Select-String -Path "config\permissionslist.php" -Pattern "accounting.tax-type"`
  - **Expect:** one line containing `'accounting.tax-type' => $crud,`.
  - **Effort:** S (plus the sync)

- [ ] **TXTP-01** · B · ERR-01 · `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:31-238` — rewrite all six mutations to `DB::transaction`, drop the `try/catch` and the raw exception text, and stop double-authorizing store/update.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TaxTypeController.php` only.
  - **Before — store, lines 31-60:**
    ```php
        public function store(TaxTypeRequest $request)
        {
            Gate::authorize('tenant.accounting.tax-type.create');

            $validated = $request->validated();

            DB::beginTransaction();
            try {
                $taxType = TaxType::create($validated);

                activityLog($taxType, 'Created', [
                    'message'      => 'Tax Type created: ' . $taxType->name . ' (' . $taxType->code . ')',
                    'name'         => $taxType->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])
                    ->with('success', 'Tax Type created successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to create Tax Type', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString(),
                ]);

                return back()->withInput()->with('error', 'Failed to create Tax Type: ' . $e->getMessage());
            }
        }
    ```
  - **Before — update, lines 76-103:**
    ```php
        public function update(TaxTypeRequest $request, TaxType $taxType)
        {
            Gate::authorize('tenant.accounting.tax-type.update');

            DB::beginTransaction();
            try {
                $taxType->update($request->validated());

                activityLog($taxType, 'Updated', [
                    'message'      => 'Tax Type updated: ' . $taxType->name,
                    'name'         => $taxType->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])
                    ->with('success', 'Tax Type updated successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to update Tax Type', [
                    'id'    => $taxType->id,
                    'error' => $e->getMessage(),
                ]);

                return back()->withInput()->with('error', 'Failed to update Tax Type: ' . $e->getMessage());
            }
        }
    ```
  - **Before — destroy, lines 105-135:**
    ```php
        public function destroy(TaxType $taxType)
        {
            Gate::authorize('tenant.accounting.tax-type.delete');

            DB::beginTransaction();
            try {
                $name = $taxType->name;
                $taxType->is_active = false;
                $taxType->save();
                $taxType->delete();

                activityLog($taxType, 'Trashed', [
                    'message'      => 'Tax Type deleted: ' . $name,
                    'name'         => $name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])
                    ->with('success', 'Tax Type moved to trash.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to delete Tax Type', [
                    'id'    => $taxType->id,
                    'error' => $e->getMessage(),
                ]);

                return back()->with('error', 'Failed to delete Tax Type: ' . $e->getMessage());
            }
        }
    ```
  - **Before — toggleStatus, lines 137-173:**
    ```php
        public function toggleStatus(Request $request, TaxType $taxType)
        {
            Gate::authorize('tenant.accounting.tax-type.update');

            $request->validate(['is_active' => 'required|boolean']);

            DB::beginTransaction();
            try {
                $taxType->is_active = (bool) $request->input('is_active');
                $taxType->save();

                activityLog($taxType, 'Toggled', [
                    'message'      => 'Tax Type status toggled: ' . $taxType->name,
                    'name'         => $taxType->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return response()->json([
                    'success'   => true,
                    'is_active' => $taxType->is_active,
                    'message'   => 'Status updated successfully.',
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to toggle Tax Type status', [
                    'id'    => $taxType->id,
                    'error' => $e->getMessage()
                ]);

                return response()->json([
                    'success' => false,
                    'message' => 'Failed to update status: ' . $e->getMessage()
                ], 500);
            }
        }
    ```
  - **Before — restore, lines 184-210:**
    ```php
        public function restore($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.tax-type.restore');

            DB::beginTransaction();
            try {
                $model = TaxType::onlyTrashed()->findOrFail($id);
                $model->restore();
                $model->update(['is_active' => true]);

                activityLog($model, 'Restored', [
                    'message'      => 'Tax Type restored: ' . $model->name,
                    'name'         => $model->name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])
                    ->with('success', 'Tax Type restored successfully.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to restore Tax Type', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to restore Tax Type: ' . $e->getMessage());
            }
        }
    ```
  - **Before — forceDelete, lines 212-238:**
    ```php
        public function forceDelete($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.tax-type.forceDelete');

            DB::beginTransaction();
            try {
                $model = TaxType::withTrashed()->findOrFail($id);
                $name = $model->name;
                $model->forceDelete();

                activityLog($model, 'Deleted', [
                    'message'      => 'Tax Type permanently deleted: ' . $name,
                    'name'         => $name,
                    'performed_by' => auth()->id(),
                ]);

                DB::commit();

                return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])
                    ->with('success', 'Tax Type permanently deleted.');
            } catch (\Throwable $e) {
                DB::rollBack();
                Log::error('Failed to force delete Tax Type', ['id' => $id, 'error' => $e->getMessage()]);

                return back()->with('error', 'Failed to delete Tax Type: ' . $e->getMessage());
            }
        }
    ```
  - **After — store:**
    ```php
        public function store(TaxTypeRequest $request)
        {
            DB::transaction(function () use ($request): void {
                $taxType = TaxType::create($request->validated());

                activityLog($taxType, 'Created', [
                    'message'      => 'Tax Type created: ' . $taxType->name . ' (' . $taxType->code . ')',
                    'name'         => $taxType->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])
                ->with('success', 'Tax Type created successfully.');
        }
    ```
  - **After — update:**
    ```php
        public function update(TaxTypeRequest $request, TaxType $taxType)
        {
            DB::transaction(function () use ($request, $taxType): void {
                $taxType->update($request->validated());

                activityLog($taxType, 'Updated', [
                    'message'      => 'Tax Type updated: ' . $taxType->name,
                    'name'         => $taxType->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])
                ->with('success', 'Tax Type updated successfully.');
        }
    ```
  - **After — destroy:**
    ```php
        public function destroy(TaxType $taxType)
        {
            Gate::authorize('tenant.accounting.tax-type.delete');

            $name = $taxType->name;

            DB::transaction(function () use ($taxType, $name): void {
                $taxType->is_active = false;
                $taxType->save();
                $taxType->delete();

                activityLog($taxType, 'Trashed', [
                    'message'      => 'Tax Type deleted: ' . $name,
                    'name'         => $name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])
                ->with('success', 'Tax Type moved to trash.');
        }
    ```
  - **After — toggleStatus:**
    ```php
        public function toggleStatus(Request $request, TaxType $taxType)
        {
            Gate::authorize('tenant.accounting.tax-type.update');

            $request->validate(['is_active' => 'required|boolean']);

            DB::transaction(function () use ($request, $taxType): void {
                $taxType->is_active = (bool) $request->input('is_active');
                $taxType->save();

                activityLog($taxType, 'Toggled', [
                    'message'      => 'Tax Type status toggled: ' . $taxType->name,
                    'name'         => $taxType->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return response()->json([
                'success'   => true,
                'is_active' => $taxType->is_active,
                'message'   => 'Status updated successfully.',
            ]);
        }
    ```
  - **After — restore:**
    ```php
        public function restore($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.tax-type.restore');

            $model = TaxType::onlyTrashed()->findOrFail($id);

            DB::transaction(function () use ($model): void {
                $model->restore();
                $model->update(['is_active' => true]);

                activityLog($model, 'Restored', [
                    'message'      => 'Tax Type restored: ' . $model->name,
                    'name'         => $model->name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])
                ->with('success', 'Tax Type restored successfully.');
        }
    ```
  - **After — forceDelete:**
    ```php
        public function forceDelete($id): \Illuminate\Http\RedirectResponse
        {
            Gate::authorize('tenant.accounting.tax-type.forceDelete');

            $model = TaxType::withTrashed()->findOrFail($id);
            $name = $model->name;

            DB::transaction(function () use ($model, $name): void {
                $model->forceDelete();

                activityLog($model, 'Deleted', [
                    'message'      => 'Tax Type permanently deleted: ' . $name,
                    'name'         => $name,
                    'performed_by' => auth()->id(),
                ]);
            });

            return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-types'])
                ->with('success', 'Tax Type permanently deleted.');
        }
    ```
  - **Note:** `use Illuminate\Support\Facades\Log;` (line 11) becomes unused after this item; TXTP-15 removes it. Do not delete it here.
  - **Verify:** `php -l "Modules/Accounting/app/Http/Controllers/TaxTypeController.php"; Select-String -Path "Modules/Accounting/app/Http/Controllers/TaxTypeController.php" -Pattern "beginTransaction|Log::error|catch \("`
  - **Expect:** `No syntax errors detected in Modules/Accounting/app/Http/Controllers/TaxTypeController.php` and no lines from `Select-String`.
  - **Effort:** M

- [ ] **TXTP-09** · B · VAL-05 · `Modules/Accounting/app/Http/Requests/TaxTypeRequest.php:41,66` — default `tax_family` to `GST` and constrain it to the enum, so create and update stop failing.
  - **Touches:** `Modules/Accounting/app/Http/Requests/TaxTypeRequest.php` only.
  - **Before** (`TaxTypeRequest.php:41`):
    ```php
                'tax_family' => ['nullable', 'string', 'max:50'],
    ```
  - **Before** (`TaxTypeRequest.php:66`):
    ```php
                'tax_family' => $this->input('tax_family') ? strtoupper(trim((string) $this->input('tax_family'))) : null,
    ```
  - **After** (`TaxTypeRequest.php:41`):
    ```php
                'tax_family' => ['required', 'string', Rule::in(TaxType::taxFamilies())],
    ```
  - **After** (`TaxTypeRequest.php:66`):
    ```php
                'tax_family' => strtoupper(trim((string) ($this->input('tax_family') ?: 'GST'))),
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Requests/TaxTypeRequest.php" -Pattern "tax_family"`
  - **Expect:** the rule line contains `Rule::in(TaxType::taxFamilies())` and the merge line contains `?: 'GST'`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None. TXTP-06 must be synced before any browser check of the other items; that ordering is stated in the TXTP-06 ops step.

## 3. Errors & transactions (F1/F2)

No separate items. TXTP-01 rewrites all six mutations and thereby resolves TXTP-02 (the swallowed `findOrFail`), TXTP-03 (message-string logging) and TXTP-04 (manual transactions); TXTP-08 is resolved by the same rewrite.

## 4. Authorization (F3)

No separate items. TXTP-06 is the blocker in §1; TXTP-07 is a decision in §9.

## 5. Validation, routes, models (F4/F5/F7)

No separate items. TXTP-09 is in §1 because it blocks every save; TXTP-10 is a decision in §9. No model defect exists beyond the unused import handled by TXTP-15.

## 6. Queries & performance (F9)

- [ ] **TXTP-13** · M · QRY-02 · `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:179` — paginate the trash list at 10 with a distinct page name.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TaxTypeController.php` only.
  - **Before** (`TaxTypeController.php:179`):
    ```php
            $taxTypes = TaxType::onlyTrashed()->orderBy('name')->paginate(15);
    ```
  - **After:**
    ```php
            $taxTypes = TaxType::onlyTrashed()->orderBy('name')->paginate(10, ['*'], 'tt_page');
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Controllers/TaxTypeController.php" -Pattern "paginate\("`
  - **Expect:** `179: $taxTypes = TaxType::onlyTrashed()->orderBy('name')->paginate(10, ['*'], 'tt_page');`
  - **Effort:** S

## 7. Views (F10)

No items. The four in-scope blades are clean; the missing form controls are TXTP-14 (decision in §9, and two of the three files are owned elsewhere).

## 8. Style (F12) — one item per file

- [ ] **TXTP-11** · L · CTL-04 · `Modules/Accounting/app/Http/Controllers/TaxTypeController.php:17,24,31,62,69,76,105,137` — add return types to the eight public methods. TXTP-01 leaves every signature unchanged, so this item is applied after it.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TaxTypeController.php` only.
  - **Before** (`TaxTypeController.php:17,24,31,62,69,76,105,137`):
    ```php
        public function index()
        public function create()
        public function store(TaxTypeRequest $request)
        public function show(TaxType $taxType)
        public function edit(TaxType $taxType)
        public function update(TaxTypeRequest $request, TaxType $taxType)
        public function destroy(TaxType $taxType)
        public function toggleStatus(Request $request, TaxType $taxType)
    ```
  - **After:**
    ```php
        public function index(): \Illuminate\Http\RedirectResponse
        public function create(): \Illuminate\View\View
        public function store(TaxTypeRequest $request): \Illuminate\Http\RedirectResponse
        public function show(TaxType $taxType): \Illuminate\View\View
        public function edit(TaxType $taxType): \Illuminate\View\View
        public function update(TaxTypeRequest $request, TaxType $taxType): \Illuminate\Http\RedirectResponse
        public function destroy(TaxType $taxType): \Illuminate\Http\RedirectResponse
        public function toggleStatus(Request $request, TaxType $taxType): \Illuminate\Http\JsonResponse
    ```
  - **Verify:** `Select-String -Path "Modules/Accounting/app/Http/Controllers/TaxTypeController.php" -Pattern "public function" | ForEach-Object { "$($_.LineNumber): $($_.Line.Trim())" }`
  - **Expect:** all 11 signatures end with `: \Illuminate\Http\RedirectResponse` and similar.
  - **Effort:** S

- [ ] **TXTP-15** · L · STY-02 · `Modules/Accounting/app/Http/Controllers/TaxTypeController.php`, `Modules/Accounting/app/Models/TaxType.php`, `Modules/Accounting/app/Http/Requests/TaxTypeRequest.php` — run Pint on the three files.
  - **Touches:** the three files above only.
  - **Before** (`vendor\bin\pint --test "Modules/Accounting/app/Http/Controllers/TaxTypeController.php" "Modules/Accounting/app/Models/TaxType.php" "Modules/Accounting/app/Http/Requests/TaxTypeRequest.php" --format agent`):
    ```
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\TaxTypeController.php","fixers":["fully_qualified_strict_types","concat_space","trailing_comma_in_multiline","ordered_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Models\\TaxType.php","fixers":["no_unused_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Http\\Requests\\TaxTypeRequest.php","fixers":["trailing_comma_in_multiline","ordered_imports","binary_operator_spaces"]}]}
    ```
  - **After:**
    ```powershell
    vendor\bin\pint "Modules/Accounting/app/Http/Controllers/TaxTypeController.php" "Modules/Accounting/app/Models/TaxType.php" "Modules/Accounting/app/Http/Requests/TaxTypeRequest.php"
    ```
  - **Verify:** `vendor\bin\pint --test "Modules/Accounting/app/Http/Controllers/TaxTypeController.php" "Modules/Accounting/app/Models/TaxType.php" "Modules/Accounting/app/Http/Requests/TaxTypeRequest.php"`
  - **Expect:** exit code 0 and `PASS` for the three files.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **TXTP-05** · M · DECISION · TXN-06 — `name` is checked unique in the request but has no unique index, so concurrent saves can duplicate it.
  - **Why it is a decision:** option (a) adds a tenant migration, which Tarun runs with `php artisan tenants:migrate`; option (b) changes behaviour (duplicate names become allowed).
  - (a) ⭐ Add a unique index on `name` and keep the rule. Safe today: `SELECT name, COUNT(*) FROM acc_tax_types GROUP BY name HAVING COUNT(*) > 1` returns no rows on the test tenant. New migration body:
    ```php
    Schema::table('acc_tax_types', function (Blueprint $table) {
        $table->unique('name', 'uq_acc_tt_name');
    });
    ```
  - (b) Keep the table as is and drop `Rule::unique('acc_tax_types', 'name')` from `TaxTypeRequest.php:39`; duplicate names become allowed and the validation stops lying.
  - (c) Leave it; accept the rare duplicate under concurrency.
  - ➜ Choice: ____

- [ ] **TXTP-07** · M · DECISION · AUTH-05 — `TaxTypePolicy` is registered but no gate consults it, so its `dashboard.view` fallback is dead.
  - **Why it is a decision:** wiring the policy changes who can reach the screen; deleting it removes a class other code may reference.
  - (a) ⭐ Accept the policy as inert documentation of the intended rules and fix TXTP-06 first; no code change.
  - (b) Switch the 11 `Gate::authorize('tenant.accounting.tax-type.*')` calls to policy form; this activates the `dashboard.view` fallback for School Admin, Management, Account Staff and Account Manager and needs the policy to implement every CRUD method.
  - (c) Delete `TaxTypePolicy.php` and its `Gate::policy(TaxType::class, TaxTypePolicy::class)` line at `AccountingServiceProvider.php:135`; ⚠ SHARED provider.
  - ➜ Choice: ____

- [ ] **TXTP-10** · H · DECISION · RTE-01 — restore changes state over GET.
  - **Why it is a decision:** it edits the shared route file and changes the HTTP verb the trash table uses.
  - (a) ⭐ Change the verb; the shared component already emits `@method('DELETE')` plus CSRF. New line at `Modules/Accounting/routes/web.php:206`:
    ```php
    Route::delete('/tax-type/{id}/restore', [TaxTypeController::class, 'restore'])->name('tax-type.restore');
    ```
  - (b) Keep GET and add a confirmation page or JS confirm; the action is still prefetchable and CSRF-free.
  - (c) Leave it; accept the risk.
  - ➜ Choice: ____

- [ ] **TXTP-14** · M · DECISION · F13-Q8 — `tax_family`, `is_input` and `ordinal` have no input control, so the list's family and input-credit filters can never match a user-created row.
  - **Why it is a decision:** the create modal lives in a partial owned by `AccDashboardController`; this is a UI/behaviour choice.
  - (a) ⭐ Add a Tax Family select, an Input Credit switch and an Ordinal number input to the create modal and to `create.blade.php`/`edit.blade.php`; the request and model already accept them.
  - (b) Remove the Tax Family and Input Credit filters and the three columns from `_tax-types.blade.php`; the fields stay API-only.
  - (c) Leave it; every new row is GST/Output/ordinal 0.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TXTP-02 | Fixed inside TXTP-01: `findOrFail()` moved above `DB::transaction`, so a missing id gives 404. |
| TXTP-03 | Fixed inside TXTP-01: the catch blocks disappear, so the central handler logs the exception object. |
| TXTP-04 | Fixed inside TXTP-01: all six mutations use `DB::transaction`. |
| TXTP-08 | Fixed inside TXTP-01: the duplicate `Gate::authorize` calls in `store` and `update` are removed; `TaxTypeRequest::authorize()` keeps the check. |
| TXTP-12 | Accepted: the six audit/redirect blocks stay inline. TXTP-01 normalises them; extracting a helper would add indirection to a 239-line controller for about ten saved lines. |
