# Fix Plan — Accounting / TaxRateController

**From:** `01-report.md` (2026-10-22) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/TaxRateController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

**Apply order:** §1 → §5 → §6 → §7 → §8. Items in §9 are approved by choice, not auto-applied.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_tax-rates.blade.php` | the real list/create modal, rendered by `AccDashboardController`; owned by the `AccDashboardController` report |
| `Modules/Accounting/resources/views/tax-rate/index.blade.php` | never rendered; its deletion is deferred (TXRT-18), not part of this pass |
| `Modules/Accounting/resources/views/tax-rate/show.blade.php` | audited, no finding — no edit needed |
| `database/migrations/tenant/2026_09_16_100027_create_acc_tax_rates_table.php` | DDL; audits never edit migrations |
| `config/permissionslist.php` | shared permission config; all seven `tenant.accounting.tax-rate.*` keys already exist and are seeded |
| `app/Helpers/activityLog.php` | common app helper; not edited here |
| `Modules/Accounting/app/Policies/TaxRatePolicy.php` | touched only if DECISION TXRT-07 option (b) is chosen |
| `Modules/Accounting/app/Providers/AccountingServiceProvider.php` | module provider; touched only if DECISION TXRT-07 option (b) is chosen |
| `Modules/Accounting/routes/web.php` | shared route file; touched only if DECISION TXRT-09 is ticked |
| `Modules/Accounting/tests/**` | tests are not run or edited in an audit (D4) |

## 1. Blockers reachable today

- [ ] **TXRT-01** · B · ERR-01 · `TaxRateController.php:31-226` — remove the six hand-rolled `try/catch` transactions so no exception text reaches the user.
  - Also fixes TXRT-02 (missing restore id → 404), TXRT-03 (central handler logs the exception), TXRT-04 (`DB::transaction()`) and TXRT-06 (the FormRequest is the only authorization for `store`/`update`).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TaxRateController.php`
  - **Before** (`TaxRateController.php:31-61`, `store()`):
    ```php
    public function store(TaxRateRequest $request)
    {
        Gate::authorize('tenant.accounting.tax-rate.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        DB::beginTransaction();
        try {
            $taxRate = TaxRate::create($validated);

            activityLog($taxRate, 'Created', [
                'message'      => 'Tax Rate created: ' . $taxRate->name,
                'name'         => $taxRate->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-rates'])
                ->with('success', 'Tax Rate created successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Tax Rate', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Tax Rate: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`store()`):
    ```php
    public function store(TaxRateRequest $request): \Illuminate\Http\RedirectResponse
    {
        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        DB::transaction(function () use ($validated): void {
            $taxRate = TaxRate::create($validated);

            activityLog($taxRate, 'Created', [
                'message' => 'Tax Rate created: ' . $taxRate->name,
                'name' => $taxRate->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-rates'])
            ->with('success', 'Tax Rate created successfully.');
    }
    ```
  - **Before** (`TaxRateController.php:77-104`, `update()`):
    ```php
    public function update(TaxRateRequest $request, TaxRate $taxRate)
    {
        Gate::authorize('tenant.accounting.tax-rate.update');

        DB::beginTransaction();
        try {
            $taxRate->update($request->validated());

            activityLog($taxRate, 'Updated', [
                'message'      => 'Tax Rate updated: ' . $taxRate->name,
                'name'         => $taxRate->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-rates'])
                ->with('success', 'Tax Rate updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to update Tax Rate', [
                'id'    => $taxRate->id,
                'error' => $e->getMessage(),
            ]);

            return back()->withInput()->with('error', 'Failed to update Tax Rate: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`update()`):
    ```php
    public function update(TaxRateRequest $request, TaxRate $taxRate): \Illuminate\Http\RedirectResponse
    {
        $validated = $request->validated();

        DB::transaction(function () use ($taxRate, $validated): void {
            $taxRate->update($validated);

            activityLog($taxRate, 'Updated', [
                'message' => 'Tax Rate updated: ' . $taxRate->name,
                'name' => $taxRate->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-rates'])
            ->with('success', 'Tax Rate updated successfully.');
    }
    ```
  - **Before** (`TaxRateController.php:106-135`, `destroy()`):
    ```php
    public function destroy(TaxRate $taxRate)
    {
        Gate::authorize('tenant.accounting.tax-rate.delete');

        DB::beginTransaction();
        try {
            $taxRate->is_active = false;
            $taxRate->save();
            $taxRate->delete();

            activityLog($taxRate, 'Trashed', [
                'message'      => 'Tax Rate trashed: ' . $taxRate->name,
                'name'         => $taxRate->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-rates'])
                ->with('success', 'Tax Rate moved to trash.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to delete Tax Rate', [
                'id'    => $taxRate->id,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'Failed to delete Tax Rate: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`destroy()`):
    ```php
    public function destroy(TaxRate $taxRate): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tax-rate.delete');

        DB::transaction(function () use ($taxRate): void {
            $taxRate->is_active = false;
            $taxRate->save();
            $taxRate->delete();

            activityLog($taxRate, 'Trashed', [
                'message' => 'Tax Rate trashed: ' . $taxRate->name,
                'name' => $taxRate->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-rates'])
            ->with('success', 'Tax Rate moved to trash.');
    }
    ```
  - **Before** (`TaxRateController.php:137-163`, `toggleStatus()`):
    ```php
    public function toggleStatus(Request $request, TaxRate $taxRate)
    {
        Gate::authorize('tenant.accounting.tax-rate.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::beginTransaction();
        try {
            $taxRate->is_active = $request->input('is_active');
            $taxRate->save();

            activityLog($taxRate, 'Toggled', [
                'message'      => 'Tax Rate status toggled: ' . $taxRate->name,
                'name'         => $taxRate->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return response()->json(['success' => true, 'is_active' => $taxRate->is_active, 'message' => 'Status updated.']);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to toggle Tax Rate status', ['id' => $taxRate->id, 'error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
        }
    }
    ```
  - **After** (`toggleStatus()`):
    ```php
    public function toggleStatus(Request $request, TaxRate $taxRate): \Illuminate\Http\JsonResponse
    {
        Gate::authorize('tenant.accounting.tax-rate.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::transaction(function () use ($request, $taxRate): void {
            $taxRate->is_active = $request->input('is_active');
            $taxRate->save();

            activityLog($taxRate, 'Toggled', [
                'message' => 'Tax Rate status toggled: ' . $taxRate->name,
                'name' => $taxRate->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return response()->json(['success' => true, 'is_active' => $taxRate->is_active, 'message' => 'Status updated.']);
    }
    ```
  - **Before** (`TaxRateController.php:174-199`, `restore()`):
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tax-rate.restore');

        DB::beginTransaction();
        try {
            $model = TaxRate::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'Tax Rate restored: ' . $model->name,
                'name'         => $model->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.tax-rate.trashed')->with('success', 'Tax Rate restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Tax Rate', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Tax Rate: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`restore()` — keeps `$id` + `findOrFail`; CTL-03 is deferred, see §10):
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tax-rate.restore');

        DB::transaction(function () use ($id): void {
            $taxRate = TaxRate::onlyTrashed()->findOrFail($id);
            $taxRate->restore();
            $taxRate->update(['is_active' => true]);

            activityLog($taxRate, 'Restored', [
                'message' => 'Tax Rate restored: ' . $taxRate->name,
                'name' => $taxRate->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.tax-rate.trashed')->with('success', 'Tax Rate restored successfully.');
    }
    ```
  - **Before** (`TaxRateController.php:201-226`, `forceDelete()`):
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tax-rate.forceDelete');

        DB::beginTransaction();
        try {
            $model = TaxRate::withTrashed()->findOrFail($id);
            $name = $model->name;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Tax Rate permanently deleted: ' . $name,
                'name'         => $name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.tax-rate.trashed')->with('success', 'Tax Rate permanently deleted.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to force delete Tax Rate', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Tax Rate: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`forceDelete()` — keeps `$id` + `findOrFail`; CTL-03 is deferred, see §10):
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tax-rate.forceDelete');

        DB::transaction(function () use ($id): void {
            $taxRate = TaxRate::withTrashed()->findOrFail($id);
            $name = $taxRate->name;
            $taxRate->forceDelete();

            activityLog($taxRate, 'Deleted', [
                'message' => 'Tax Rate permanently deleted: ' . $name,
                'name' => $name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.tax-rate.trashed')->with('success', 'Tax Rate permanently deleted.');
    }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "getMessage\(|beginTransaction|DB::commit|DB::rollBack|Log::error|catch \(" | ForEach-Object { "$($_.LineNumber): $($_.Line.Trim())" }`
  - **Expect:** no output.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None — TXRT-01 is self-contained and no item here enables another.

## 3. Errors & transactions (F1/F2)

None — TXRT-02, TXRT-03, TXRT-04 and TXRT-06 are all fixed inside TXRT-01 (§1).

## 4. Authorization (F3)

None — TXRT-06 is fixed inside TXRT-01 (§1); TXRT-05 and TXRT-07 are DECISION items in §9.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **TXRT-08** · H · VAL-03 · `TaxRateRequest.php:52` — an unchecked Active box must stay unchecked, not be forced back to true.
  - **Touches:** `Modules/Accounting/app/Http/Requests/TaxRateRequest.php`
  - **Before** (`TaxRateRequest.php:48-55`):
    ```php
    protected function prepareForValidation(): void
    {
        $effectiveFrom = $this->input('effective_from') ?: now()->toDateString();
        $mergeData = [
            'is_active'      => $this->boolean('is_active', true),
            'is_interstate'  => $this->boolean('is_interstate', false),
            'effective_from' => $effectiveFrom,
        ];
    ```
  - **After:**
    ```php
    protected function prepareForValidation(): void
    {
        $effectiveFrom = $this->input('effective_from') ?: now()->toDateString();
        $mergeData = [
            'is_active'      => $this->boolean('is_active', false),
            'is_interstate'  => $this->boolean('is_interstate', false),
            'effective_from' => $effectiveFrom,
        ];
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\TaxRateRequest.php" -Pattern "boolean\('is_active'" | ForEach-Object { $_.Line.Trim() }`
  - **Expect:** `'is_active'      => $this->boolean('is_active', false),`
  - **Effort:** S

- [ ] **TXRT-11** · L · CTL-04 · `TaxRateController.php:17, 24, 63, 70` — add return types to the four read methods (`TXRT-01` already added them to the six mutators).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TaxRateController.php`
  - **Before** (`TaxRateController.php:17, 24, 63, 70`):
    ```php
    public function index()
    public function create()
    public function show(TaxRate $taxRate)
    public function edit(TaxRate $taxRate)
    ```
  - **After:**
    ```php
    public function index(): \Illuminate\Http\RedirectResponse
    public function create(): \Illuminate\View\View
    public function show(TaxRate $taxRate): \Illuminate\View\View
    public function edit(TaxRate $taxRate): \Illuminate\View\View
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "public function (index|create|show|edit)\(.*\):" | ForEach-Object { $_.Line.Trim() }`
  - **Expect:** four lines, each ending in a return type:
    ```
    public function index(): \Illuminate\Http\RedirectResponse
    public function create(): \Illuminate\View\View
    public function show(TaxRate $taxRate): \Illuminate\View\View
    public function edit(TaxRate $taxRate): \Illuminate\View\View
    ```
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **TXRT-12** · M · QRY-02 · `TaxRateController.php:169` — paginate the trash list at the standard 10 rows and eager-load the tax type.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TaxRateController.php`
  - **Before** (`TaxRateController.php:165-172`):
    ```php
    public function trashed(): \Illuminate\View\View
    {
        Gate::authorize('tenant.accounting.tax-rate.restore');

        $taxRates = TaxRate::onlyTrashed()->orderBy('name')->paginate(15);

        return view('accounting::tax-rate.trash', compact('taxRates'));
    }
    ```
  - **After:**
    ```php
    public function trashed(): \Illuminate\View\View
    {
        Gate::authorize('tenant.accounting.tax-rate.restore');

        $taxRates = TaxRate::with('taxType')->onlyTrashed()->orderBy('name')->paginate(10);

        return view('accounting::tax-rate.trash', compact('taxRates'));
    }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "paginate\(|with\('taxType'\)" | ForEach-Object { $_.Line.Trim() }`
  - **Expect:** `$taxRates = TaxRate::with('taxType')->onlyTrashed()->orderBy('name')->paginate(10);`
  - **Effort:** S

## 7. Views (F10)

- [ ] **TXRT-13** · H · VIEW-01 · `create.blade.php:63`, `edit.blade.php:72` — move the `TaxType` query out of Blade into `create()`/`edit()`.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TaxRateController.php`, `Modules/Accounting/resources/views/tax-rate/create.blade.php`, `Modules/Accounting/resources/views/tax-rate/edit.blade.php`
  - **Before** (`TaxRateController.php:7-13`, imports):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Accounting\Http\Requests\TaxRateRequest;
    use Modules\Accounting\Models\TaxRate;
    ```
  - **After** (imports):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Accounting\Http\Requests\TaxRateRequest;
    use Modules\Accounting\Models\TaxRate;
    use Modules\Accounting\Models\TaxType;
    ```
  - **Before** (`TaxRateController.php:28`, `create()`):
    ```php
    return view('accounting::tax-rate.create');
    ```
  - **After** (`create()`):
    ```php
    $taxTypes = TaxType::query()->orderBy('name')->get(['id', 'name']);

    return view('accounting::tax-rate.create', compact('taxTypes'));
    ```
  - **Before** (`TaxRateController.php:74`, `edit()`):
    ```php
    return view('accounting::tax-rate.edit', compact('taxRate'));
    ```
  - **After** (`edit()`):
    ```php
    $taxTypes = TaxType::query()->orderBy('name')->get(['id', 'name']);

    return view('accounting::tax-rate.edit', compact('taxRate', 'taxTypes'));
    ```
  - **Before** (`create.blade.php:63`):
    ```php
    @foreach (\Modules\Accounting\Models\TaxType::orderBy('name')->get() as $taxType)
    ```
  - **After** (`create.blade.php`):
    ```php
    @foreach ($taxTypes as $taxType)
    ```
  - **Before** (`edit.blade.php:72`):
    ```php
    @foreach (\Modules\Accounting\Models\TaxType::orderBy('name')->get() as $taxType)
    ```
  - **After** (`edit.blade.php`):
    ```php
    @foreach ($taxTypes as $taxType)
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php","Modules\Accounting\resources\views\tax-rate\create.blade.php","Modules\Accounting\resources\views\tax-rate\edit.blade.php" -Pattern "TaxType::" | ForEach-Object { "$($_.Filename): $($_.Line.Trim())" }`
  - **Expect:** exactly two lines, both from `TaxRateController.php`:
    ```
    TaxRateController.php: $taxTypes = TaxType::query()->orderBy('name')->get(['id', 'name']);
    TaxRateController.php: $taxTypes = TaxType::query()->orderBy('name')->get(['id', 'name']);
    ```
  - **Effort:** M

- [ ] **TXRT-14** · M · VIEW-02 · `trash.blade.php:32` — show the related tax-type name instead of the non-existent `tax_type` column.
  - **Touches:** `Modules/Accounting/resources/views/tax-rate/trash.blade.php`
  - **Before** (`trash.blade.php:32`):
    ```php
    <td>{{ $taxRate->tax_type }}</td>
    ```
  - **After:**
    ```php
    <td>{{ $taxRate->taxType?->name ?? '-' }}</td>
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\resources\views\tax-rate\trash.blade.php" -Pattern "tax_type" | ForEach-Object { $_.Line.Trim() }`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **TXRT-15** · L · STY-02 · `TaxRateController.php` — run Pint on the file (also removes the now-unused `Log` import and the fully-qualified return types after TXRT-01/TXRT-11).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/TaxRateController.php`
  - **Before** (`TaxRateController.php:11`, current style):
    ```php
    use Illuminate\Support\Facades\Log;
    ```
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\TaxRateController.php --format agent` (no manual edit).
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\TaxRateController.php --format agent`
  - **Expect:** `"result":"pass"` and an empty `files` array.
  - **Effort:** S

- [ ] **TXRT-16** · L · STY-02 · `TaxRate.php` — run Pint on the file (also removes the unused `App\Models\BaseModel` import).
  - **Touches:** `Modules/Accounting/app/Models/TaxRate.php`
  - **Before** (`TaxRate.php:7`):
    ```php
    use App\Models\BaseModel;
    ```
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Models\TaxRate.php --format agent` (the unused import is removed by the `no_unused_imports` fixer).
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Models\TaxRate.php --format agent`
  - **Expect:** `"result":"pass"` and an empty `files` array.
  - **Effort:** S

- [ ] **TXRT-17** · L · STY-02 · `TaxRateRequest.php` — run Pint on the file (import order and operator spacing).
  - **Touches:** `Modules/Accounting/app/Http/Requests/TaxRateRequest.php`
  - **Before** (`TaxRateRequest.php:7-8`, current style):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use App\Traits\AuthorizesTenantFeature;
    ```
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Requests\TaxRateRequest.php --format agent` (no manual edit).
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Requests\TaxRateRequest.php --format agent`
  - **Expect:** `"result":"pass"` and an empty `files` array.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **TXRT-05** · M · DECISION · AUTH-02 — `show`/`edit`/`update`/`destroy`/`toggleStatus` load the record (route-model binding) before the in-method `Gate::authorize` runs, so an unauthorized user can tell an existing id (403) from a missing id (404). Accept the framework order, or move authorization ahead of `SubstituteBindings`?
  - **Why it is a decision:** the only real fix changes controller/middleware architecture (a global middleware-priority change or a permission middleware on every route), not a mechanical edit; the leak is just id existence to an already-authenticated user.
  - (a) ⭐ accept the framework order — every controller in the module behaves this way; record as accepted, no file changes.
  - (b) add a per-route permission middleware that runs before `SubstituteBindings` — changes `Modules/Accounting/routes/web.php` (shared) and may need a global priority list in `bootstrap/app.php`.
  - (c) convert the five methods to `Gate::authorize` inside a `FormRequest`/middleware pair and drop implicit binding — larger rewrite across the controller.
  - ➜ Choice: ____

- [ ] **TXRT-07** · M · DECISION · AUTH-05 — `TaxRatePolicy` is registered with `Gate::policy()` but never consulted; every check is a literal permission string. Keep the dead policy, delete it, or switch the gates to model abilities?
  - **Why it is a decision:** deleting it touches the module provider; switching to model abilities touches all 11 gates and needs `restore`/`forceDelete` methods added; either way the behaviour contract changes.
  - (a) ⭐ delete `TaxRatePolicy.php` and line 142 + import line 42 of `AccountingServiceProvider.php` — removes dead code, no runtime change (nothing consults it).
  - (b) extend the policy with `restore`/`forceDelete` and convert the 11 gates to `Gate::authorize('<ability>', TaxRate::class|$taxRate)` — makes the policy real, larger change.
  - (c) leave it inert for this pass and record it as accepted.
  - ➜ Choice: ____

- [ ] **TXRT-09** · H · DECISION · RTE-01 — `restore` changes state over `GET` (`web.php:191`), so a prefetch, crawler or cross-site image can restore a trashed rate without a CSRF token. Change the verb?
  - **Why it is a decision:** it changes a **shared route file**, and `⚠ SHARED` — it needs its own explicit tick, not "tick all".
  - ⚠ SHARED
  - (a) ⭐ change line 191 to `Route::delete('/tax-rate/{id}/restore', [TaxRateController::class, 'restore'])->name('tax-rate.restore');` — `x-backend.table.action-trashed` already reads the route verb and emits a CSRF-protected form, so no component edit is needed.
  - (b) keep `GET` and accept the CSRF exposure for this pass.
  - (c) point the component at a new `POST` route instead — also updates `resources/views/components/backend/table/action-trashed.blade.php` (shared component).
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TXRT-02 | Fixed by TXRT-01 (§1): removing the catch lets `ModelNotFoundException` reach the central handler as a 404. |
| TXRT-03 | Fixed by TXRT-01 (§1): no controller `Log::error` remains; the central handler logs the exception object. |
| TXRT-04 | Fixed by TXRT-01 (§1): each mutation becomes one `DB::transaction()` closure. |
| TXRT-06 | Fixed by TXRT-01 (§1): the duplicate `Gate::authorize` calls in `store`/`update` are removed; the FormRequest already authorizes. |
| TXRT-10 | Deferred: converting `restore`/`forceDelete` to route-model binding overlaps both the TXRT-01 body rewrite and TXRT-09's route change; do it in a follow-up pass after those land. |
| TXRT-18 | No code change: `index.blade.php` deletion and the duplicate standalone create form are a separate cleanup; `create.blade.php` is still reachable by URL, so it is not removed here. |
