# Fix Plan — Accounting / ChequeLeafController

**From:** `01-report.md` (2026-10-24) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

All line numbers quote the audit snapshot (`01-report.md`). Earlier ticked items shift them, so the fixer matches the quoted code, not the number.

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | shared route file; only CHQF-10 (⚠ SHARED) names it |
| `Modules/Accounting/app/Providers/AccountingServiceProvider.php` | shared provider; the policy registration is not changed by any ticked item |
| `Modules/Accounting/app/Policies/ChequeLeafPolicy.php` | touched only if CHQF-05 chooses option (b) |
| `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_cheque-leaves.blade.php` | host-page partial rendered by `AccDashboardController`; the two defects are cross-cutting (§7 of the report) |
| `Modules/Accounting/app/Models/ChequeRegister.php` | owned by ChequeRegisterController report |
| `Modules/Accounting/app/Models/Ledger.php` | owned by LedgerController report |
| `Modules/Accounting/app/Models/Voucher.php` | owned by VoucherController report |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | owned by AccountingStatusMasterController report |
| `Modules/Accounting/app/Services/AccountingContext.php` | owned by AccountGroupController report |
| `database/migrations/**` | never edit an existing migration |
| `final-audit-reports/00-CLASS-OWNERS.md`, `final-audit-reports/gaurav/Accounting/00-INDEX.md` | registry and index files are not edited by this plan |

## 1. Blockers reachable today

Order note: CHQF-07 (H) runs before CHQF-01 (B) because §2 requires the unique rule to exist before the catch is removed. CHQF-01 is the only B in this report.

- [ ] **CHQF-07** · H · VAL-04 · `Modules/Accounting/app/Http/Requests/ChequeLeafRequest.php:21-35` — add the unique rule that mirrors `uq_acc_chqleaf`.
  - **Touches:** `Modules/Accounting/app/Http/Requests/ChequeLeafRequest.php`
  - **Before** (`ChequeLeafRequest.php:7-8`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Support\Facades\Gate;
    ```
  - **After:**
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Validation\Rule;
    ```
  - **Before** (`ChequeLeafRequest.php:21-35`):
    ```php
    public function rules(): array
    {
        $leafId = $this->route('cheque_leaf') ? $this->route('cheque_leaf')->id : null;

        return [
            'cheque_register_id' => 'required|exists:acc_cheque_registers,id',
            'bank_ledger_id'     => 'required|exists:acc_ledgers,id',
            'leaf_no'            => 'required|integer|min:1',
            'status'             => 'required|in:Unused,Issued,Cancelled,Spoiled,Lost',
            'voucher_id'         => 'nullable|exists:acc_vouchers,id',
            'issued_date'        => 'nullable|date',
            'cancelled_reason'   => 'nullable|string|max:500',
            'is_active'          => 'nullable|boolean',
        ];
    }
    ```
  - **After:**
    ```php
    public function rules(): array
    {
        $leafId = $this->route('cheque_leaf') ? $this->route('cheque_leaf')->id : null;

        return [
            'cheque_register_id' => 'required|exists:acc_cheque_registers,id',
            'bank_ledger_id'     => 'required|exists:acc_ledgers,id',
            'leaf_no'            => [
                'required',
                'integer',
                'min:1',
                Rule::unique('acc_cheque_leaves', 'leaf_no')
                    ->where(fn ($query) => $query->where('bank_ledger_id', $this->input('bank_ledger_id')))
                    ->ignore($leafId),
            ],
            'status'             => 'required|in:Unused,Issued,Cancelled,Spoiled,Lost',
            'voucher_id'         => 'nullable|exists:acc_vouchers,id',
            'issued_date'        => 'nullable|date',
            'cancelled_reason'   => 'nullable|string|max:500',
        ];
    }
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Requests\ChequeLeafRequest.php -Pattern "Rule::unique|is_active"`
  - **Expect:** one hit for `Rule::unique`; no hit for `is_active`.
  - **Effort:** S

- [ ] **CHQF-01** · B · ERR-01 · `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:36-235` — remove the hand-rolled try/catch and manual transactions from store, update, destroy, restore and forceDelete. This item also closes CHQF-02 (missing leaf becomes a 404), CHQF-03 (log loses the trace) and the five-method part of CHQF-04.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php`
  - **Before** (`ChequeLeafController.php:9-12`):
    ```php
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Accounting\Http\Requests\ChequeLeafRequest;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Accounting\Http\Requests\ChequeLeafRequest;
    ```
  - **Before** (`ChequeLeafController.php:36-62`, method `store()`):
    ```php
    public function store(ChequeLeafRequest $request)
    {
        Gate::authorize('tenant.accounting.cheque-leaf.create');

        $validated = $request->validated();

        DB::beginTransaction();
        try {
            $leaf = ChequeLeaf::create($validated);

            activityLog($leaf, 'Created', [
                'message'      => 'Cheque Leaf created: ' . $leaf->leaf_no,
                'leaf_no'      => $leaf->leaf_no,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-leaves'])
                ->with('success', 'Cheque Leaf created successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Cheque Leaf', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'Failed to create Cheque Leaf: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function store(ChequeLeafRequest $request)
    {
        Gate::authorize('tenant.accounting.cheque-leaf.create');

        $validated = $request->validated();

        DB::transaction(function () use ($validated) {
            $leaf = ChequeLeaf::create($validated);

            activityLog($leaf, 'Created', [
                'message'      => 'Cheque Leaf created: ' . $leaf->leaf_no,
                'leaf_no'      => $leaf->leaf_no,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-leaves'])
            ->with('success', 'Cheque Leaf created successfully.');
    }
    ```
  - **Before** (`ChequeLeafController.php:84-110`, method `update()`):
    ```php
    public function update(ChequeLeafRequest $request, ChequeLeaf $chequeLeaf)
    {
        Gate::authorize('tenant.accounting.cheque-leaf.update');

        $validated = $request->validated();

        DB::beginTransaction();
        try {
            $chequeLeaf->update($validated);

            activityLog($chequeLeaf, 'Updated', [
                'message'      => 'Cheque Leaf updated: ' . $chequeLeaf->leaf_no,
                'leaf_no'      => $chequeLeaf->leaf_no,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-leaves'])
                ->with('success', 'Cheque Leaf updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to update Cheque Leaf', ['id' => $chequeLeaf->id, 'error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'Failed to update Cheque Leaf: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function update(ChequeLeafRequest $request, ChequeLeaf $chequeLeaf)
    {
        Gate::authorize('tenant.accounting.cheque-leaf.update');

        $validated = $request->validated();

        DB::transaction(function () use ($chequeLeaf, $validated) {
            $chequeLeaf->update($validated);

            activityLog($chequeLeaf, 'Updated', [
                'message'      => 'Cheque Leaf updated: ' . $chequeLeaf->leaf_no,
                'leaf_no'      => $chequeLeaf->leaf_no,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-leaves'])
            ->with('success', 'Cheque Leaf updated successfully.');
    }
    ```
  - **Before** (`ChequeLeafController.php:112-137`, method `destroy()`):
    ```php
    public function destroy(ChequeLeaf $chequeLeaf)
    {
        Gate::authorize('tenant.accounting.cheque-leaf.delete');

        DB::beginTransaction();
        try {
            $leafNo = $chequeLeaf->leaf_no;
            $chequeLeaf->delete();

            activityLog($chequeLeaf, 'Deleted', [
                'message'      => 'Cheque Leaf deleted: ' . $leafNo,
                'leaf_no'      => $leafNo,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-leaves'])
                ->with('success', 'Cheque Leaf deleted successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to delete Cheque Leaf', ['id' => $chequeLeaf->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Cheque Leaf: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function destroy(ChequeLeaf $chequeLeaf)
    {
        Gate::authorize('tenant.accounting.cheque-leaf.delete');

        DB::transaction(function () use ($chequeLeaf) {
            $leafNo = $chequeLeaf->leaf_no;
            $chequeLeaf->delete();

            activityLog($chequeLeaf, 'Deleted', [
                'message'      => 'Cheque Leaf deleted: ' . $leafNo,
                'leaf_no'      => $leafNo,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-leaves'])
            ->with('success', 'Cheque Leaf deleted successfully.');
    }
    ```
  - **Before** (`ChequeLeafController.php:184-208`, method `restore()`):
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-leaf.restore');

        DB::beginTransaction();
        try {
            $model = ChequeLeaf::onlyTrashed()->findOrFail($id);
            $model->restore();

            activityLog($model, 'Restored', [
                'message'      => 'Cheque Leaf restored: ' . $model->leaf_no,
                'leaf_no'      => $model->leaf_no,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.cheque-leaf.trashed')->with('success', 'Cheque Leaf restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Cheque Leaf', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Cheque Leaf: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-leaf.restore');

        $model = ChequeLeaf::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($model) {
            $model->restore();

            activityLog($model, 'Restored', [
                'message'      => 'Cheque Leaf restored: ' . $model->leaf_no,
                'leaf_no'      => $model->leaf_no,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.cheque-leaf.trashed')->with('success', 'Cheque Leaf restored successfully.');
    }
    ```
  - **Before** (`ChequeLeafController.php:210-235`, method `forceDelete()`):
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-leaf.forceDelete');

        DB::beginTransaction();
        try {
            $model = ChequeLeaf::withTrashed()->findOrFail($id);
            $leafNo = $model->leaf_no;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Cheque Leaf permanently deleted: ' . $leafNo,
                'leaf_no'      => $leafNo,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.cheque-leaf.trashed')->with('success', 'Cheque Leaf permanently deleted.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to force delete Cheque Leaf', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Cheque Leaf: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-leaf.forceDelete');

        $model = ChequeLeaf::withTrashed()->findOrFail($id);

        DB::transaction(function () use ($model) {
            $leafNo = $model->leaf_no;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Cheque Leaf permanently deleted: ' . $leafNo,
                'leaf_no'      => $leafNo,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.cheque-leaf.trashed')->with('success', 'Cheque Leaf permanently deleted.');
    }
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "catch \(|getMessage|beginTransaction"`
  - **Expect:** only the `catch (` / `getMessage` lines inside `changeStatus()` remain until CHQF-08 is applied; CHQF-08 removes them, after which the command returns no output.
  - **Effort:** M

- [ ] **CHQF-10** · H · RTE-01 · `Modules/Accounting/routes/web.php:146` — restore must be a DELETE. ⚠ SHARED
  - **Touches:** `Modules/Accounting/routes/web.php`
  - **Before** (`routes/web.php:146`):
    ```php
    Route::get('/cheque-leaf/{id}/restore', [ChequeLeafController::class, 'restore'])->name('cheque-leaf.restore');
    ```
  - **After:**
    ```php
    Route::delete('/cheque-leaf/{id}/restore', [ChequeLeafController::class, 'restore'])->name('cheque-leaf.restore');
    ```
  - **Verify:** `php artisan route:list --json 2>$null | php "/tmp/opencode\routesprobe.php" "Modules\Accounting\Http\Controllers\ChequeLeafController"`
  - **Expect:** the restore line starts with `DELETE` and keeps the name `accounting.cheque-leaf.restore`.
  - **Effort:** S

- [ ] **CHQF-15** · H · DECISION · VIEW-01 — the routed create page renders a Blade file that does not exist.
  - **Why it is a decision:** it changes the user-visible meaning of the `/cheque-leaf/create` URL; option (c) changes a shared route file.
  - (a) ⭐ make `create()` redirect to `accounting.menu.chequesReconciliation` with `tab=cheque-leaves`, matching `index()` and the modal UI; removes the 500 with no new file and deletes the two register queries at `ChequeLeafController.php:30-31` (replace the body with `return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-leaves']);`)
  - (b) add the missing `Modules/Accounting/resources/views/cheque-leaf/create.blade.php` (a new form page modelled on `edit.blade.php`) and keep `create()` as it is
  - (c) remove the `create` route from the shared route file and delete the method (⚠ SHARED route change; not recommended)
  - ➜ Choice: ____

- [ ] **CHQF-18** · H · DECISION · TXN-03 — permanent delete can remove a leaf that a voucher still references.
  - **Why it is a decision:** each option changes a destructive action's business rule; option (c) needs a migration.
  - (a) ⭐ refuse the permanent delete when `$model->voucher_id` is not null, with a flash message ("This leaf is linked to a voucher and cannot be permanently deleted."), and leave the soft-deleted row in place; insert `if ($model->voucher_id !== null) { return back()->with('error', 'This leaf is linked to a voucher and cannot be permanently deleted.'); }` immediately after the `findOrFail` line in CHQF-01's `forceDelete()`
  - (b) leave it as is and record the risk as accepted (only an administrator reaches force delete)
  - (c) add a database foreign key from `acc_voucher_bank_details.cheque_leaf_id` to `acc_cheque_leaves.id` (new additive migration; Tarun runs it)
  - ➜ Choice: ____

## 2. Fixes that arm a latent defect (sequenced)

Apply **CHQF-07 before CHQF-01** (both in §1). CHQF-07 turns the duplicate-leaf case into a 422 validation error; if CHQF-01 ran first, that same case would reach the central handler as a 500 page. With CHQF-07 first, the duplicate path never becomes an exception. No other item in this plan arms a latent defect.

## 3. Errors & transactions (F1/F2)

- [ ] **CHQF-19** · L · TXN-04 · `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:220` — record a distinct audit event for a permanent delete.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php`
  - **Before** (`ChequeLeafController.php:220-224`):
    ```php
            activityLog($model, 'Deleted', [
                'message'      => 'Cheque Leaf permanently deleted: ' . $leafNo,
                'leaf_no'      => $leafNo,
                'performed_by' => auth()->id(),
            ]);
    ```
  - **After:**
    ```php
            activityLog($model, 'ForceDeleted', [
                'message'      => 'Cheque Leaf permanently deleted: ' . $leafNo,
                'leaf_no'      => $leafNo,
                'performed_by' => auth()->id(),
            ]);
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "ForceDeleted"`
  - **Expect:** one hit.
  - **Effort:** XS

## 4. Authorization (F3)

- [ ] **CHQF-06** · L · AUTH-04 · `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:38, 86` — remove the second permission check; the FormRequest runs first and already checks it.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php`
  - **Before** (`ChequeLeafController.php:36-40`, method `store()`):
    ```php
    public function store(ChequeLeafRequest $request)
    {
        Gate::authorize('tenant.accounting.cheque-leaf.create');

        $validated = $request->validated();
    ```
  - **After:**
    ```php
    public function store(ChequeLeafRequest $request)
    {
        $validated = $request->validated();
    ```
  - **Before** (`ChequeLeafController.php:84-88`, method `update()`):
    ```php
    public function update(ChequeLeafRequest $request, ChequeLeaf $chequeLeaf)
    {
        Gate::authorize('tenant.accounting.cheque-leaf.update');

        $validated = $request->validated();
    ```
  - **After:**
    ```php
    public function update(ChequeLeafRequest $request, ChequeLeaf $chequeLeaf)
    {
        $validated = $request->validated();
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "Gate::authorize" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }`
  - **Expect:** no `create` or `update` hit inside `store()`/`update()`; the `changeStatus()` hit remains until CHQF-08 removes it.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **CHQF-08** · M · VAL-02 · `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:139-173` — move the status modal's validation into a FormRequest and finish its transaction rewrite.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php`, `Modules/Accounting/app/Http/Requests/ChequeLeafStatusRequest.php` (new)
  - **Before** (controller imports after CHQF-01, `ChequeLeafController.php:8-11`):
    ```php
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Accounting\Http\Requests\ChequeLeafRequest;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Accounting\Http\Requests\ChequeLeafRequest;
    use Modules\Accounting\Http\Requests\ChequeLeafStatusRequest;
    ```
  - **Before** (`ChequeLeafController.php:139-173`):
    ```php
    public function changeStatus(Request $request, ChequeLeaf $chequeLeaf)
    {
        Gate::authorize('tenant.accounting.cheque-leaf.update');

        $request->validate([
            'status'           => 'required|in:Unused,Issued,Cancelled,Spoiled,Lost',
            'cancelled_reason' => 'nullable|string|max:500',
        ]);

        DB::beginTransaction();
        try {
            $chequeLeaf->status = $request->input('status');
            if ($request->filled('cancelled_reason')) {
                $chequeLeaf->cancelled_reason = $request->input('cancelled_reason');
            }
            $chequeLeaf->save();

            activityLog($chequeLeaf, 'StatusChanged', [
                'message'      => 'Cheque Leaf status changed to ' . $chequeLeaf->status,
                'leaf_no'      => $chequeLeaf->leaf_no,
                'status'       => $chequeLeaf->status,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-leaves'])
                ->with('success', 'Cheque leaf status updated.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to change Cheque Leaf status', ['id' => $chequeLeaf->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to update status: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`ChequeLeafController.php`):
    ```php
    public function changeStatus(ChequeLeafStatusRequest $request, ChequeLeaf $chequeLeaf): \Illuminate\Http\RedirectResponse
    {
        $validated = $request->validated();

        DB::transaction(function () use ($validated, $chequeLeaf) {
            $chequeLeaf->status = $validated['status'];
            if (! empty($validated['cancelled_reason'])) {
                $chequeLeaf->cancelled_reason = $validated['cancelled_reason'];
            }
            $chequeLeaf->save();

            activityLog($chequeLeaf, 'StatusChanged', [
                'message'      => 'Cheque Leaf status changed to ' . $chequeLeaf->status,
                'leaf_no'      => $chequeLeaf->leaf_no,
                'status'       => $chequeLeaf->status,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-leaves'])
            ->with('success', 'Cheque leaf status updated.');
    }
    ```
  - **After** (new file `Modules/Accounting/app/Http/Requests/ChequeLeafStatusRequest.php`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Accounting\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Support\Facades\Gate;

    class ChequeLeafStatusRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return Gate::allows('tenant.accounting.cheque-leaf.update');
        }

        public function rules(): array
        {
            return [
                'status'           => 'required|in:Unused,Issued,Cancelled,Spoiled,Lost',
                'cancelled_reason' => 'nullable|string|max:500',
            ];
        }
    }
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "request->validate|\$request->input"` and `php -l Modules\Accounting\app\Http\Requests\ChequeLeafStatusRequest.php`
  - **Expect:** no hits in the controller; `No syntax errors detected` for the new file.
  - **Effort:** S

- [ ] **CHQF-09** · L · MDL-02 · `Modules/Accounting/app/Models/ChequeLeaf.php:25-28` — cast the boolean `is_active` column.
  - **Touches:** `Modules/Accounting/app/Models/ChequeLeaf.php`
  - **Before** (`ChequeLeaf.php:25-28`):
    ```php
    protected $casts = [
        'leaf_no'      => 'integer',
        'issued_date'  => 'date',
    ];
    ```
  - **After:**
    ```php
    protected $casts = [
        'leaf_no'      => 'integer',
        'issued_date'  => 'date',
        'is_active'    => 'boolean',
    ];
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Models\ChequeLeaf.php -Pattern "'is_active'"`
  - **Expect:** one hit inside `$casts`.
  - **Effort:** XS

## 6. Queries & performance (F9)

- [ ] **CHQF-13** · M · QRY-01 · `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:78` — eager-load the bank ledger used by the edit dropdown.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php`
  - **Before** (`ChequeLeafController.php:78`):
    ```php
        $registers   = ChequeRegister::orderBy('book_number')->get();
    ```
  - **After:**
    ```php
        $registers   = ChequeRegister::with('bankLedger')->orderBy('book_number')->get();
    ```
  - **Before** (`ChequeLeafController.php:30`, only if CHQF-15 chose option (b)):
    ```php
        $registers   = ChequeRegister::where('status', 'Active')->orderBy('book_number')->get();
    ```
  - **After** (only if CHQF-15 chose option (b)):
    ```php
        $registers   = ChequeRegister::where('status', 'Active')->with('bankLedger')->orderBy('book_number')->get();
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "ChequeRegister::"`
  - **Expect:** every remaining `ChequeRegister::` query used by a view contains `with('bankLedger')`.
  - **Effort:** XS

- [ ] **CHQF-14** · L · QRY-02 · `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:179` — use the standard page size and a distinct page name.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php`
  - **Before** (`ChequeLeafController.php:179`):
    ```php
        $leaves = ChequeLeaf::onlyTrashed()->with(['chequeRegister', 'bankLedger'])->orderBy('leaf_no')->paginate(15);
    ```
  - **After:**
    ```php
        $leaves = ChequeLeaf::onlyTrashed()->with(['chequeRegister', 'bankLedger'])->orderBy('leaf_no')->paginate(10, ['*'], 'leaves_page');
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "paginate\("`
  - **Expect:** one hit containing `paginate(10, ['*'], 'leaves_page')`.
  - **Effort:** XS

## 7. Views (F10)

- [ ] **CHQF-16** · M · VIEW-01 · `Modules/Accounting/resources/views/cheque-leaf/show.blade.php:84-87` — remove the row that reads the non-existent `cancelled_date` column.
  - **Touches:** `Modules/Accounting/resources/views/cheque-leaf/show.blade.php`
  - **Before** (`show.blade.php:80-90`):
    ```blade
                                        <tr>
                                            <td class="text-muted" style="width: 40%;">Issued Date:</td>
                                            <td class="fw-semibold">{{ $chequeLeaf->issued_date ? date('d M Y', strtotime($chequeLeaf->issued_date)) : '-' }}</td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Cancelled Date:</td>
                                            <td class="fw-semibold">{{ $chequeLeaf->cancelled_date ? date('d M Y', strtotime($chequeLeaf->cancelled_date)) : '-' }}</td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Reason / Notes:</td>
    ```
  - **After:**
    ```blade
                                        <tr>
                                            <td class="text-muted" style="width: 40%;">Issued Date:</td>
                                            <td class="fw-semibold">{{ $chequeLeaf->issued_date ? date('d M Y', strtotime($chequeLeaf->issued_date)) : '-' }}</td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Reason / Notes:</td>
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\resources\views\cheque-leaf\show.blade.php -Pattern "cancelled_date"`
  - **Expect:** no output.
  - **Effort:** XS

## 8. Style (F12) - one item per file

- [ ] **CHQF-17 / CHQF-11** · L · STY-02 / CTL-04 · `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php` — add the missing return types and run Pint on this file.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php`
  - **Before** (`ChequeLeafController.php:19`):
    ```php
    public function index()
    ```
  - **After:**
    ```php
    public function index(): \Illuminate\Http\RedirectResponse
    ```
  - **Before** (`ChequeLeafController.php:36`):
    ```php
    public function store(ChequeLeafRequest $request)
    ```
  - **After:**
    ```php
    public function store(ChequeLeafRequest $request): \Illuminate\Http\RedirectResponse
    ```
  - **Before** (`ChequeLeafController.php:64`):
    ```php
    public function show(ChequeLeaf $chequeLeaf)
    ```
  - **After:**
    ```php
    public function show(ChequeLeaf $chequeLeaf): \Illuminate\View\View
    ```
  - **Before** (`ChequeLeafController.php:73`):
    ```php
    public function edit(ChequeLeaf $chequeLeaf)
    ```
  - **After:**
    ```php
    public function edit(ChequeLeaf $chequeLeaf): \Illuminate\View\View
    ```
  - **Before** (`ChequeLeafController.php:84`):
    ```php
    public function update(ChequeLeafRequest $request, ChequeLeaf $chequeLeaf)
    ```
  - **After:**
    ```php
    public function update(ChequeLeafRequest $request, ChequeLeaf $chequeLeaf): \Illuminate\Http\RedirectResponse
    ```
  - **Before** (`ChequeLeafController.php:112`):
    ```php
    public function destroy(ChequeLeaf $chequeLeaf)
    ```
  - **After:**
    ```php
    public function destroy(ChequeLeaf $chequeLeaf): \Illuminate\Http\RedirectResponse
    ```
  - **Step:** run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\ChequeLeafController.php --format agent` after the signature edits. It normalizes the FQCN types into imports and fixes `concat_space`, `ordered_imports`, `binary_operator_spaces` and `single_blank_line_at_eof`. Leave `create()` untyped until CHQF-15 is decided; if CHQF-15 option (a) is chosen, type it `create(): \Illuminate\Http\RedirectResponse`, and if option (b) is chosen, type it `create(): \Illuminate\View\View`. CHQF-08 types `changeStatus()`.
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\ChequeLeafController.php --format agent` and `php -l Modules\Accounting\app\Http\Controllers\ChequeLeafController.php`
  - **Expect:** `{"tool":"pint","result":"pass"}` and `No syntax errors detected`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **CHQF-05** · M · DECISION · AUTH-05 — the registered `ChequeLeafPolicy` is never consulted and implements only `viewAny`/`view`.
  - **Why it is a decision:** moving authorization into the policy rewrites 11 gate calls and adds five policy methods; leaving it records a known trap.
  - (a) ⭐ leave the policy as redundant and record it as accepted; the Spatie permission gates already enforce all 11 abilities, and the policy is only a trap for a future developer
  - (b) move all checks into the policy: add `create`, `update`, `delete`, `restore`, `forceDelete` methods to `ChequeLeafPolicy` and change the 11 calls to `$this->authorize('viewAny')`, `$this->authorize('create')`, `$this->authorize('view', $chequeLeaf)` and the matching abilities
  - (c) delete the policy and its `Gate::policy` registration in `AccountingServiceProvider.php:169` (⚠ SHARED provider)
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here | What to do |
|---|---|---|
| CHQF-12 | Route model binding for `restore`/`forceDelete` needs `->withTrashed()` on two shared route entries. It has no user-visible effect and the route change is out of scope for this pass, so it is deferred (D3). | No action now. When the route file is next touched, add `->withTrashed()` to the two route entries and bind `ChequeLeaf $chequeLeaf`. |
