# Accounting — Final Audit Index

Protocol: `.claude/rules/final-audit.md`.
⛔ Append a row to claim. Edit only your own row. Never rewrite this file.

| Controller | Status | B | H | M | L | Report | By | Updated |
|---|---|---|---|---|---|---|---|---|
| AccDashboardController | CLAIMED | - | - | - | - | [01-report](AccDashboardController/01-report.md) | opencode | 2026-10-19 |
| AccountGroupController | AUDITED | 1 | 4 | 9 | 5 | [01-report](AccountGroupController/01-report.md) | opencode | 2026-10-19 |
| AccountingController | AUDITED | 0 | 0 | 1 | 2 | [01-report](AccountingController/01-report.md) | opencode | 2026-10-19 |
| AccountingPeriodController | CLAIMED | - | - | - | - | [01-report](AccountingPeriodController/01-report.md) | opencode | 2026-10-19 |
| AccountingStatusMasterController | AUDITED | 0 | 0 | 1 | 4 | [01-report](AccountingStatusMasterController/01-report.md) | opencode | 2026-10-19 |
| AccReportController | CLAIMED | - | - | - | - | [01-report](AccReportController/01-report.md) | opencode | 2026-10-19 |
| ApprovalPolicyController | AUDITED | 1 | 3 | 7 | 6 | [01-report](ApprovalPolicyController/01-report.md) | opencode | 2026-10-19 |
| AssetCategoryController | AUDITED | 1 | 3 | 10 | 7 | [01-report](AssetCategoryController/01-report.md) | opencode | 2026-10-23 |
| AssetDisposalController | AUDITED | 3 | 2 | 5 | 5 | [01-report](AssetDisposalController/01-report.md) | opencode | 2026-10-23 |
| BankReconciliationController | CLAIMED | - | - | - | - | [01-report](BankReconciliationController/01-report.md) | opencode | 2026-10-19 |
| BankReconciliationMatchController | CLAIMED | - | - | - | - | [01-report](BankReconciliationMatchController/01-report.md) | opencode | 2026-10-19 |
| BankStatementEntryController | CLAIMED | - | - | - | - | [01-report](BankStatementEntryController/01-report.md) | opencode | 2026-10-19 |
| BankStatementMappingController | CLAIMED | - | - | - | - | [01-report](BankStatementMappingController/01-report.md) | opencode | 2026-10-19 |
| BillAllocationController | CLAIMED | - | - | - | - | [01-report](BillAllocationController/01-report.md) | opencode | 2026-10-19 |
| BillReferenceController | CLAIMED | - | - | - | - | [01-report](BillReferenceController/01-report.md) | opencode | 2026-10-19 |
| BudgetController | AUDITED | 1 | 6 | 7 | 10 | [01-report](BudgetController/01-report.md) | opencode | 2026-10-23 |
| CampusController | AUDITED | 1 | 4 | 11 | 8 | [01-report](CampusController/01-report.md) | opencode | 2026-10-19 |
| ChequeLeafController | AUDITED | 1 | 5 | 6 | 7 | [01-report](ChequeLeafController/01-report.md) | opencode | 2026-10-23 |
| ChequeRegisterController | AUDITED | 2 | 4 | 4 | 6 | [01-report](ChequeRegisterController/01-report.md) | opencode | 2026-10-23 |
| ChequeTransactionController | AUDITED | 2 | 4 | 10 | 5 | [01-report](ChequeTransactionController/01-report.md) | opencode | 2026-10-23 |
| ConcessionController | AUDITED | 4 | 5 | 5 | 4 | [01-report](ConcessionController/01-report.md) | opencode | 2026-10-23 |
| CostCategoryController | AUDITED | 1 | 5 | 9 | 4 | [01-report](CostCategoryController/01-report.md) | opencode | 2026-10-19 |
| CostCenterController | AUDITED | 1 | 4 | 6 | 4 | [01-report](CostCenterController/01-report.md) | opencode | 2026-10-19 |
| CurrencyController | AUDITED | 1 | 4 | 7 | 8 | [01-report](CurrencyController/01-report.md) | opencode | 2026-10-19 |
| DepreciationEntryController | AUDITED | 3 | 7 | 8 | 7 | [01-report](DepreciationEntryController/01-report.md) | opencode | 2026-10-23 |
| DonationController | AUDITED | 3 | 8 | 15 | 9 | [01-report](DonationController/01-report.md) | opencode | 2026-10-23 |
| EventVoucherConfigController | CLAIMED | - | - | - | - | [01-report](EventVoucherConfigController/01-report.md) | opencode | 2026-10-19 |
| ExceptionController | CLAIMED | - | - | - | - | [01-report](ExceptionController/01-report.md) | opencode | 2026-10-19 |
| ExchangeRateController | AUDITED | 1 | 5 | 4 | 4 | [01-report](ExchangeRateController/01-report.md) | opencode | 2026-10-19 |
| ExpenseClaimController | CLAIMED | - | - | - | - | [01-report](ExpenseClaimController/01-report.md) | opencode | 2026-10-19 |
| FinancialYearController | CLAIMED | - | - | - | - | [01-report](FinancialYearController/01-report.md) | opencode | 2026-10-19 |
| FixedAssetController | AUDITED | 3 | 5 | 5 | 4 | [01-report](FixedAssetController/01-report.md) | opencode | 2026-10-23 |
| FundController | AUDITED | 1 | 5 | 7 | 11 | [01-report](FundController/01-report.md) | opencode | 2026-10-23 |
| GrantController | AUDITED | 1 | 7 | 8 | 6 | [01-report](GrantController/01-report.md) | opencode | 2026-10-23 |
| InterestComputationController | CLAIMED | - | - | - | - | [01-report](InterestComputationController/01-report.md) | opencode | 2026-10-19 |
| InterestRuleController | CLAIMED | - | - | - | - | [01-report](InterestRuleController/01-report.md) | opencode | 2026-10-19 |
| LedgerController | CLAIMED | - | - | - | - | [01-report](LedgerController/01-report.md) | opencode | 2026-10-19 |
| LedgerMappingController | CLAIMED | - | - | - | - | [01-report](LedgerMappingController/01-report.md) | opencode | 2026-10-19 |
| ModuleEventController | CLAIMED | - | - | - | - | [01-report](ModuleEventController/01-report.md) | opencode | 2026-10-19 |
| OpeningBalanceController | CLAIMED | - | - | - | - | [01-report](OpeningBalanceController/01-report.md) | opencode | 2026-10-19 |
| PeriodCloseChecklistController | CLAIMED | - | - | - | - | [01-report](PeriodCloseChecklistController/01-report.md) | opencode | 2026-10-19 |
| RecurringTemplateController | CLAIMED | - | - | - | - | [01-report](RecurringTemplateController/01-report.md) | opencode | 2026-10-19 |
| TallyExportController | CLAIMED | - | - | - | - | [01-report](TallyExportController/01-report.md) | opencode | 2026-10-19 |
| TallyLedgerMappingController | CLAIMED | - | - | - | - | [01-report](TallyLedgerMappingController/01-report.md) | opencode | 2026-10-19 |
| TaxRateController | AUDITED | 1 | 4 | 7 | 6 | [01-report](TaxRateController/01-report.md) | opencode | 2026-10-19 |
| TaxTypeController | AUDITED | 3 | 2 | 7 | 3 | [01-report](TaxTypeController/01-report.md) | opencode | 2026-10-19 |
| TdsCertificateController | AUDITED | 2 | 7 | 8 | 5 | [01-report](TdsCertificateController/01-report.md) | opencode | 2026-10-19 |
| TdsDeductionController | AUDITED | 2 | 4 | 4 | 7 | [01-report](TdsDeductionController/01-report.md) | opencode | 2026-10-19 |
| TdsPaymentAllocationController | AUDITED | 2 | 5 | 4 | 3 | [01-report](TdsPaymentAllocationController/01-report.md) | opencode | 2026-10-19 |
| TdsPaymentController | AUDITED | 3 | 6 | 8 | 7 | [01-report](TdsPaymentController/01-report.md) | opencode | 2026-10-19 |
| VoucherApprovalController | CLAIMED | - | - | - | - | [01-report](VoucherApprovalController/01-report.md) | opencode | 2026-10-19 |
| VoucherCategoryController | CLAIMED | - | - | - | - | [01-report](VoucherCategoryController/01-report.md) | opencode | 2026-10-19 |
| VoucherController | CLAIMED | - | - | - | - | [01-report](VoucherController/01-report.md) | opencode | 2026-10-19 |
| VoucherTypeController | CLAIMED | - | - | - | - | [01-report](VoucherTypeController/01-report.md) | opencode | 2026-10-19 |
