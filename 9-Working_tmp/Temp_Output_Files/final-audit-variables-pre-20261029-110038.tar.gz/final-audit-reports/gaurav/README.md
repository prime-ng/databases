# Final audit — gaurav's controllers

Reports for controllers assigned to **gaurav** live here as `<Module>/<Controller>/`.
Protocol: `prime_ai_dev/.claude/rules/final-audit.md` (read §3.0, §8, §9 before your first fix).

## What is in each controller folder

| File | Written by | What it is |
|---|---|---|
| `01-report.md` | auditor | **Read §0 first** — what the screen does and its URL. Then each finding: rule, where, root cause, what the user sees, how to reproduce it, the fix approach, and the proof |
| `02-fix-plan.md` | auditor, ticked by Tarun | Every fix as exact **Before → After** code, a **Verify** command and the output to **Expect**. §0 lists files you must not touch |
| `03-status.md` | fixer | What was applied, what was not and why, what needs Tarun's hand |
| `04-reaudit.md` | re-audit | Tarun's check of your fixes: FIXED / STILL OPEN / REGRESSED / NOT TICKED |

## How to fix your controllers (OpenCode)

1. Wait until Tarun has ticked items in `02-fix-plan.md`. Only ticked `[x]` items are applied.
2. In OpenCode, started inside `prime_ai_dev/`, run the `final-audit-fixer` agent with:
   ```
   Fix Modules/<Module>/app/Http/Controllers/<Controller>.php — developer gaurav
   ```
3. The fixer applies each ticked item exactly as written. If an item's **Before** code is no
   longer in the file, it records "superseded" and moves on — it does not improvise.
4. Read `03-status.md`. Do whatever is under **Needs Tarun's hand** together with Tarun
   (a migration, a permission sync, a browser check).
5. Open the screen URL from `01-report.md` §0 and click through what you changed.
6. Tell Tarun the controller is `FIXED` so he can re-audit it.

## Rules that are not negotiable

- ⛔ Do **not** edit `01-report.md` or `02-fix-plan.md`. If you disagree with a finding, write it
  in `03-status.md` §3 and tell Tarun.
- ⛔ Do **not** run or write tests (`php artisan test`, pest, dusk) — protocol D4.
- ⛔ Do **not** edit an existing migration, and do not run a new one — that is Tarun's step.
- ⛔ Do **not** touch the files in `02-fix-plan.md` §0 or anything marked `⚠ SHARED` unless that
  exact item is ticked.
- ⛔ Never `pkill` / `kill` a server.
