> **Vendored copy for the final audit** (copied 2026-10-10 from `prime_info/Final/CodeReview/00-RULEBOOK.md`
> so developers without `prime_info` can read it). ⚠ **ERR-00 is NOT open for the final audit** —
> `.claude/rules/final-audit.md` D1 settled it: the Laravel idiom (no try/catch in controllers). Where
> this file says "undecided", D1/D2 govern. If the two files disagree, `final-audit.md` wins.

# Pre-Deployment Code Review — Rulebook

**Prime AI · Laravel 12 / PHP 8.2+ · written 2026-10-09**

This is the standard the final review measures every controller, model, service, form request, route,
Blade view, job, listener and command against. It merges:

- Laravel 12 documentation conventions (controllers, validation, Eloquent, queues, error handling)
- PSR-12 and Laravel Pint defaults
- Community practice of senior Laravel reviewers (thin controllers, Form Requests, route model binding,
  query discipline, no logic in views)
- The project's own rules — `.kimi/rules/*.md` and `.claude/rules/controller-alignment.md` (A1/A2/A3)
- The defect patterns found in the four single-controller reviews of 2026-10-09

Where the project rules contradicted each other, this book says which wins. **The one open decision
is ERR-00** — it is deliberately left undecided, and findings are tagged so either answer can be applied.

---

## How to read a rule

| Field | Meaning |
|---|---|
| **ID** | `FAMILY-NN`. Quoted in every finding. |
| **Sev** | Default severity. A reviewer may raise or lower it with a reason. |
| **Detect** | `S` = the static scanner finds it · `D` = needs a human/agent deep read · `S~` = scanner finds candidates, a read confirms |

### Severity

| Sev | Name | Meaning | Deploy? |
|---|---|---|---|
| **B** | Blocker | Data loss or corruption, security hole, or a crash on a normal user path | **Must fix before go-live** |
| **H** | High | Wrong result, wrong status code, silent failure, or a serious performance trap on a real screen | Fix before go-live if the screen ships |
| **M** | Medium | Maintainability or performance debt that will cost later | First post-launch sprint |
| **L** | Low | Style and consistency | Opportunistic / codemod |

---

## ERR — Error handling

### ERR-00 · The open decision — try/catch everywhere vs the Laravel idiom

Two defensible standards exist. The review reports against **both**; Tarun picks one later.

| | **Variant H — House rule A1** (controller-alignment.md) | **Variant L — Laravel idiom** |
|---|---|---|
| Shape | `try { DB::transaction(...) } catch (ModelNotFoundException) { throw } catch (\Throwable) { log; friendly response }` in every mutation | No `try` in controllers. `DB::transaction()` rolls back and rethrows by itself. One renderer in `bootstrap/app.php` → `withExceptions()` gives the friendly 500 page/JSON |
| Pro | Every failure gets a page-specific message; already applied to ~1,500 methods | ~60–70% fewer lines; the 404/403/422 class of bug (ERR-02) becomes impossible |
| Con | Every catch is a place to get ERR-01..04 wrong — today's four reviews found 20+ such bugs | Reverses two months of A1 work; message is generic, not page-specific |

**Whichever wins, ERR-01 to ERR-06 apply.** Findings that only exist under Variant H are tagged `[H-only]`.

| ID | Sev | Rule | Detect |
|---|---|---|---|
| ERR-01 | **B** | Never send exception text to the user. No `$e->getMessage()` in `withErrors`, `with('error')`, `response()->json`, or `back()`. SQL, table and column names leak. (SECURITY_RULES 13 wins over LARAVEL_RULES 10.) | S |
| ERR-02 | **H** | A catch must never turn a 404/403/422/`abort()` into a redirect or 500. Under Variant H: `catch (ModelNotFoundException\|AuthorizationException\|ValidationException\|HttpExceptionInterface $e) { throw $e; }` before the generic catch. `validate()`, `authorize()` and `findOrFail()` belong **before** the `try`. | S |
| ERR-03 | **H** | A catch must return the method's declared return type. `: View` + `return back()` in a catch is a `TypeError` → 500, and `catch (\Exception)` doesn't catch it. | S |
| ERR-04 | M | JSON endpoints fail with JSON; form endpoints fail with a redirect. Use `$request->expectsJson()` when one method serves both. | S~ |
| ERR-05 | M | Log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`. `getMessage()` alone loses the trace. | S |
| ERR-06 | H | No swallowed failures in write paths — an empty `catch`, or a catch that logs and then continues as if the write succeeded. | S~ |
| ERR-07 | M | Read-only methods (`index`, `show`, `create`, `edit`, lookups) need no try/catch under either variant. | S |

```php
// ERR-01 + ERR-02 — wrong
try {
    $homework = Homework::findOrFail($id);          // 404 swallowed
    $request->validate([...]);                       // 422 swallowed
    ...
} catch (Throwable $e) {
    return back()->withErrors(['x' => $e->getMessage()]);   // SQL shown to user
}

// right (Variant H)
$request->validate([...]);
$homework = Homework::findOrFail($id);     // or route model binding
try {
    DB::transaction(fn () => ...);
} catch (\Throwable $e) {
    report($e);
    return back()->with('error', 'The homework could not be saved.');
}
```

---

## TXN — Transactions and audit

| ID | Sev | Rule | Detect |
|---|---|---|---|
| TXN-01 | H | More than one write (two models, a model + its audit row, a model + pivot) runs inside **one** `DB::transaction`. (House A2.) | S~ |
| TXN-02 | M | Use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`. Never `return` between `beginTransaction` and `commit`. | S |
| TXN-03 | **B** | No irreversible side effect inside a transaction or before the write succeeds: file deletes, mail, SMS, push, HTTP calls. Do them after commit (`DB::afterCommit()`, or after the closure returns). | S~ |
| TXN-04 | M | `activityLog()` sits inside the transaction, **after** the write it describes. Not before it (it logs a write that may fail), not after commit. (House A3.) | S |
| TXN-05 | M | The transaction closure returns data (a model, a count). Build `redirect()` / `response()` **after** it. | S |
| TXN-06 | H | Check-then-act needs a lock or a unique index: `count()` then insert, `exists()` then `create()`. Use `lockForUpdate()` inside the transaction, or rely on a DB unique index and catch the duplicate. | D |

---

## AUTH — Authorization

| ID | Sev | Rule | Detect |
|---|---|---|---|
| AUTH-01 | **B** | Every routed controller method authorizes: `Gate::authorize`, `$this->authorize`, a `can:` route middleware, or a Form Request whose `authorize()` checks a permission (not just `auth()->check()`). | S |
| AUTH-02 | H | Authorize first — before loading records and outside any `try`. Loading first leaks whether an id exists (404 vs 403). | S |
| AUTH-03 | H | Record-level checks where data belongs to a person: portals (student/parent sees only their own), teacher-owned records, download endpoints. | D |
| AUTH-04 | L | Don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`). Keep one. | S |
| AUTH-05 | M | No dead permission logic, e.g. `Gate::authorize(A)` followed by `Gate::any([A, B, C])` — the `any()` can never matter. | S |
| AUTH-06 | M | Permission strings live in one place — a Policy, or constants — not repeated as literals in every method. | S~ |

---

## VAL — Validation and input

| ID | Sev | Rule | Detect |
|---|---|---|---|
| VAL-01 | **B** | Never write unvalidated input: no `create($request->all())`, `update($request->all())`, `fill($request->all())`, `$request->except(...)` into a model. | S |
| VAL-02 | M | Validation lives in a Form Request (project rule), not inline `$request->validate()` — except one-field AJAX toggles. | S |
| VAL-03 | H | Optional fields: `$validated['key']` throws "Undefined array key" when a `nullable` field is absent. Use `$request->validated()` whole, `$validated['key'] ?? null`, or `$request->safe()->...`. | S~ |
| VAL-04 | H | Uniqueness rules mirror the DB unique index **including soft-delete semantics**. A DB unique index that includes trashed rows + a rule with `whereNull('deleted_at')` = a 500 on re-create. | D |
| VAL-05 | M | Every field is typed: `boolean`, `integer`, `date`, `Rule::enum()`. `'sometimes'` alone validates nothing. Write paths with no validation at all (e.g. `Carbon::parse($request->x)`) are **H**. | S~ |
| VAL-06 | H | Every upload has `file` + `mimes:`/`mimetypes:` + `max:`. | S |
| VAL-07 | M | Cross-field / business checks (shift matches, cap not exceeded, same academic term) go in the Form Request's `after()` hook, not hand-written in the controller. | D |

---

## CTL — Controllers

| ID | Sev | Rule | Detect |
|---|---|---|---|
| CTL-01 | M | No god controllers. Over **1,000 lines** or **25 public methods** → split by resource/responsibility (CRUD / workflow / lookups / reports). Over 2,500 lines is **H**. | S |
| CTL-02 | M | Method length: over 80 lines → extract; over 150 lines is **H**. | S |
| CTL-03 | M | Route model binding (`show(Homework $homework)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`. | S |
| CTL-04 | L | Return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`). | S |
| CTL-05 | M | No copy-paste: dropdown loaders shared by `create`/`edit`, the same redirect string repeated 10×, the same 30-line payload in `store` and `update`. | S~ |
| CTL-06 | M | Business logic lives in services/actions: notifications, assignment generation, fee calculation, anything reused. A controller method reads input, calls one service, returns a response. | D |
| CTL-07 | M | No `extract()`; no `compact()` of more than ~15 variables (build a view model / array). | S |
| CTL-08 | L | Inject `Request`; don't call the `request()` helper inside controller methods. | S |
| CTL-09 | H | No debug leftovers: `dd()`, `dump()`, `var_dump()`, `print_r()`, `ray()`, `phpinfo()` — including commented-out `// dd(` (signals untested paths). Live ones are **B**. | S |
| CTL-10 | M | No dead code: unused private methods, unused properties, commented-out blocks longer than 3 lines. | S~ |

---

## MDL — Models

| ID | Sev | Rule | Detect |
|---|---|---|---|
| MDL-01 | H | `$fillable` declared; never `$guarded = []`. | S |
| MDL-02 | M | `$casts` for every boolean, date/datetime, decimal, json/array, and enum column. | S~ |
| MDL-03 | H | A `belongsToMany` over a pivot table that has `deleted_at` must add `->wherePivotNull('deleted_at')`, or removed rows still count as members. | S~ |
| MDL-04 | L | Relationship methods return-typed (`: BelongsTo`, `: HasMany`…). | S |
| MDL-05 | **B** | Every model using Spatie `InteractsWithMedia` in tenant context overrides `getMediaModel()` — otherwise media rows go to the **central** DB (cross-tenant leak). | S |
| MDL-06 | M | Data normalisation (upper-casing codes, trimming) in mutators/`Attribute` casts, not in controllers. | D |
| MDL-07 | **B** | Every model's `$table` exists in a migration. A model over a missing table 500s on first use. | S |
| MDL-08 | M | Global scopes stay cheap — no correlated `orderByRaw` subqueries that run on every query of the model. | S~ |
| MDL-09 | L | Status/type strings are PHP enums or model constants, not literals repeated across files. | D |

---

## SVC — Services and actions

| ID | Sev | Rule | Detect |
|---|---|---|---|
| SVC-01 | M | Services don't touch HTTP: no `request()`, `session()`, `redirect()`, `response()`, `back()`. Pass data in, return data out. | S |
| SVC-02 | M | Dependencies arrive by constructor injection — not `new FooService()` or `app(Foo::class)` mid-method. | S |
| SVC-03 | H | No writes on read paths: no `updateOrCreate`/`firstOrCreate`/seeding inside methods called by GET pages or lookups. | S~ |
| SVC-04 | M | One implementation per business operation. Three copies of "assign students" that disagree = bug source. | D |
| SVC-05 | M | Repeated lookups inside a request (status ids, settings) are memoised or cached once. | S~ |

---

## QRY — Query optimisation

| ID | Sev | Rule | Detect |
|---|---|---|---|
| QRY-01 | H | **No queries inside loops.** No `Model::where/find/create/update`, `->save()` or lazy relation access inside `foreach`/`for`/`->map()`/`->each()`. Eager-load with `with()`, pre-fetch into a keyed collection (`->keyBy('id')`), or bulk-write. | S |
| QRY-02 | H | **Lists are paginated.** No `Model::all()` or unbounded `->get()` feeding a list page or JSON list. Use `paginate()`; `simplePaginate()`/`cursorPaginate()` for very large tables. | S |
| QRY-03 | M | **Select only what you use.** Dropdowns: `pluck('name', 'id')` or `get(['id', 'name'])`. JSON endpoints must not return whole models. | S~ |
| QRY-04 | M | **Let the DB answer.** `exists()` not `count() > 0` / `->first()` to test; `count()` not `->get()->count()`; `pluck()`/`value()` not `->get()->pluck()`; `max()`/`sum()` not `->get()->max()`. | S |
| QRY-05 | M | **Aggregate in SQL.** `groupBy` + `selectRaw('count(*)')`, `withCount`, `withSum`, `withExists` — not `->get()->groupBy()` / `->sum()` / `->filter()` over a whole table. | S |
| QRY-06 | M | **Bulk data in batches.** `chunkById()`, `lazyById()` or `cursor()` for exports, jobs, commands, seeders over large tables. | S~ |
| QRY-07 | M | **Bulk writes.** `insert()`, `upsert()`, `whereIn(...)->update()` instead of `create()`/`update()` per row in a loop. | S |
| QRY-08 | M | Leading-wildcard `LIKE '%x%'` can't use an index. Acceptable on small tables; on large ones use a prefix match, FULLTEXT, or a search column. | S |
| QRY-09 | M | `whereHas` chains 3+ levels deep, or `orWhereHas` in search, on large tables → `whereIn` subquery or a join. | S |
| QRY-10 | L | Conditional filters with `when()`; reuse a base query with `clone` instead of rebuilding the same filters 3–9 times. | S~ |
| QRY-11 | **B** | **No interpolated raw SQL.** `DB::raw("…$var")`, `whereRaw("… {$x}")`, `orderByRaw($request->…)`, `DB::select("…$x")` → bindings (`?`). | S |
| QRY-12 | M | Identical queries repeated in one request (the same dropdown id looked up 6×) → resolve once. | S~ |
| QRY-13 | L | Filtered paginators keep filters (`->withQueryString()`); multiple paginators on one page use distinct page names. | S~ |
| QRY-14 | M | Columns used in `where`/`orderBy` on large tables have indexes (FKs are indexed by default). | D |
| QRY-15 | M | Don't load every row of a big table for a form: `Topic::get()`, `Student::get()` with no filter on a create/edit page. | S~ |

```php
// QRY-01 — wrong: 1 + N queries
foreach ($students as $student) {
    $section = ClassSection::find($student->class_section_id);
}
// right: 2 queries
$sections = ClassSection::whereIn('id', $students->pluck('class_section_id'))->get()->keyBy('id');

// QRY-04 / QRY-05 — wrong
$total = Homework::where('class_id', $c)->get()->count();
$bySubject = Homework::all()->groupBy('subject_id')->map->count();
// right
$total = Homework::where('class_id', $c)->count();
$bySubject = Homework::selectRaw('subject_id, count(*) as total')->groupBy('subject_id')->pluck('total', 'subject_id');

// QRY-07 — wrong: N inserts
foreach ($rows as $r) { Allocation::create($r); }
// right: 1 statement per 1,000 rows
foreach (array_chunk($rows, 1000) as $chunk) { Allocation::insert($chunk); }
```

---

## RTE — Routes

| ID | Sev | Rule | Detect |
|---|---|---|---|
| RTE-01 | H | No state change over GET (`restore`, `delete`, `toggle`, `publish`, `approve`, `sync`, `generate`). GET has no CSRF protection, and link prefetchers trigger it. | S |
| RTE-02 | **B** | Every route points to a method that exists. | S |
| RTE-03 | M | Every public controller method is routed, or is deliberately disabled (`abort(403)`, per the alignment tracker rule). | S |
| RTE-04 | L | Reads are GET. A POST used for a lookup (`get-students-by-class`) breaks caching and back-button behaviour. | S |
| RTE-05 | H | Every tenant route sits inside the auth + tenancy middleware group; every API route has `auth:sanctum`. | S~ |
| RTE-06 | M | Custom routes that share a prefix with `Route::resource` are registered **before** it (else `/{id}` captures `/trash`). | S |

---

## VIEW — Blade (queries only)

| ID | Sev | Rule | Detect |
|---|---|---|---|
| VIEW-01 | H | No queries in Blade: no `Model::`, `DB::`, `->where(`, `->get()`, `->count()` on a relation query inside templates — especially inside `@foreach`. Pass data from the controller. | S |
| VIEW-02 | M | Relations used inside `@foreach` are eager-loaded by the controller (lazy loads in a loop = N+1). | D |
| VIEW-03 | H | `{!! !!}` only for trusted HTML. User-entered text through `{!! !!}` = stored XSS. | S~ |

---

## JOB — Jobs, listeners, commands

| ID | Sev | Rule | Detect |
|---|---|---|---|
| JOB-01 | **B** | Jobs that touch tenant data run in tenant context (dispatched inside the tenant, or `$tenant->run()`); commands iterate tenants with `tenancy()->runForMultiple()` / `$tenant->run()`. | D |
| JOB-02 | M | Queued jobs declare `$tries`, `$timeout` (and `$backoff` for external calls) and implement `failed()` when a failure must be visible. | S |
| JOB-03 | M | Jobs and commands over large tables use `chunkById`/`lazyById` (QRY-06). | S~ |
| JOB-04 | M | Listeners that do slow work (mail, PDF, HTTP, bulk writes) `implements ShouldQueue`. | S~ |
| JOB-05 | M | Jobs store ids, not whole models with loaded relations (`SerializesModels` re-queries; huge payloads otherwise). | D |

---

## SEC — Security (beyond the above)

| ID | Sev | Rule | Detect |
|---|---|---|---|
| SEC-01 | **B** | `env()` is only called inside `config/`. Elsewhere it returns `null` once `php artisan config:cache` runs in production. | S |
| SEC-02 | H | No personal data over-exposed: JSON endpoints return mapped arrays / API Resources, not full `Student`/`User` models. | S~ |
| SEC-03 | M | No hard-coded ids or fallbacks such as `?? 1` for a user/tenant/status id. | S |
| SEC-04 | H | Never log request bodies, passwords, tokens or payment data (`Log::…($request->all())`). | S |
| SEC-05 | H | Files are served through signed/authorised routes when private; uploads stored in tenant paths. | D |

---

## TEN — Tenancy

| ID | Sev | Rule | Detect |
|---|---|---|---|
| TEN-01 | **B** | See MDL-05 — Spatie media in tenant context. | S |
| TEN-02 | H | Cache keys and static/in-memory caches include the tenant (and snapshot/session where relevant). | S~ |
| TEN-03 | H | Central models from tenant context go through `tenancy()->central()`. | D |
| TEN-04 | M | Tenant file URLs via `tenant_asset()`, not `asset('storage/…')`. | S |

---

## STY — Style and consistency

| ID | Sev | Rule | Detect |
|---|---|---|---|
| STY-01 | L | `declare(strict_types=1);` in PHP files (new files mandatory; old files when touched). | S |
| STY-02 | L | Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines between imports. | S |
| STY-03 | L | Variables camelCase and unabbreviated: not `$Homework`, `$asgn`, `$psp`. | S |
| STY-04 | L | Comments in English, no emoji markers, no commented-out code, no "temporary"/"debug" notes, no copy-pasted docblocks that describe another resource. | S~ |
| STY-05 | L | One import per class — no aliasing the same class twice (`Request` + `Request as HttpRequest`). | S |
| STY-06 | L | One style per concern: `Log::` not `\Log::`; `Auth::id()` or `auth()->id()` consistently. | S |
| STY-07 | L | User-facing messages through `flash()` / `__()` keys, not hard-coded strings in 12 places. | S~ |

---

## Deep-read checklist (for agents and humans)

The scanner can't see these. A deep read of a file answers each question:

1. **Wrong data.** Does any write overwrite data it shouldn't (resetting statuses, wiping per-row overrides, re-sending notifications on unrelated edits)?
2. **Irreversible order.** Is anything deleted (files, rows) before the replacement is safely stored? (TXN-03)
3. **Duplicate implementations** of one operation that disagree. (SVC-04)
4. **Soft-delete × unique index** mismatches on create/restore/re-add. (VAL-04, MDL-03)
5. **Races** — count-then-insert, exists-then-create. (TXN-06)
6. **Authorization holes** — unguarded methods, record ownership, read permission used for writes. (AUTH-01/03)
7. **Messages that lie** — wrong event name, wrong flash resource, success returned when nothing happened.
8. **Dead features** — a screen whose saved data no consumer reads (e.g. parallel groups ignored by the generator).

---

## Contradictions resolved

| Old rule | Conflict | This book |
|---|---|---|
| LARAVEL_RULES 10 shows `Log::error(..., ['error' => $e->getMessage()])` | Loses the trace; was copied into hundreds of catches | ERR-05: log the exception object |
| LARAVEL_RULES 10 manual `beginTransaction`/`commit` | Leaks open transactions on early return | TXN-02: closure form |
| CODE_STYLE 2 "all public methods need docblocks" | Produced thousands of "Display a listing of the resource." | STY-04: docblocks only where they add meaning; return types replace `@return` |
| SECURITY_RULES 7 "permission checks at BOTH levels" | Leads to AUTH-04 duplicates | Route middleware **or** Gate/Policy **or** Form Request — at least one, exactly one per concern |
| controller-alignment A1 vs Laravel idiom | Undecided | ERR-00 — both reported |
