#!/usr/bin/env python3
"""
Final-audit report self-check — final-audit.md §15.

Usage (from prime_ai_dev/):
    python3 final-audit-reports/_tools/selfcheck.py final-audit-reports/<dev>/<Module>/<Controller>

Checks 01-report.md and 02-fix-plan.md for the mechanical requirements of §8. Exit 0 = PASS.
It checks SHAPE, not truth: a PASS does not mean the findings are correct, only complete.
Fix every FAIL line, then run it again. Paste the final PASS output into your hand-back.
"""
import os
import re
import sys
from pathlib import Path

# The application under audit. These tools moved to prime_testing/final-audit-reports/_tools on
# 2026-10-26, so quoted code is checked against the sibling prime_ai_dev/, not the current directory.
# Override with PRIME_AI_ROOT=/path/to/prime_ai_dev.
APP_ROOT = Path(os.environ.get('PRIME_AI_ROOT', Path(__file__).resolve().parents[3] / 'prime_ai_dev'))

HTML_TAGS = {
    'br', 'td', 'th', 'tr', 'div', 'span', 'input', 'select', 'option', 'form', 'table', 'code',
    'a', 'button', 'label', 'script', 'p', 'i', 'b', 'ul', 'li', 'tbody', 'thead', 'img', 'small',
    'strong', 'em', 'pre', 'textarea', 'style', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'hr', 'nav',
}
FINDING_FIELDS = ['**Rule**', '**Where**', '**Root cause**', '**Consequence**',
                  '**Reproduce**', '**Fix approach**', '**Plan item**', '**Evidence**']
ITEM_FIELDS = ['**Touches:**', '**Before**', '**After:**', '**Verify:**', '**Expect:**', '**Effort:**']
ID_RE = r'[A-Z][A-Z0-9]*-\d+[a-z]?'

errors: list[str] = []


def fail(msg: str) -> None:
    errors.append(msg)


def strip_code(text: str) -> str:
    """Blank out comments, fenced blocks and inline code, keeping newlines so line numbers hold."""
    keep_lines = lambda m: re.sub(r'[^\n]', ' ', m.group(0))
    text = re.sub(r'<!--.*?-->', keep_lines, text, flags=re.S)
    text = re.sub(r'```.*?```', keep_lines, text, flags=re.S)
    return re.sub(r'`[^`\n]*`', keep_lines, text)


def check_placeholders(name: str, text: str) -> None:
    clean = strip_code(text)
    for m in re.finditer(r'<([^<>\n]{1,80})>', clean):
        inner = m.group(1).strip()
        head = re.split(r'[\s/]', inner.lstrip('/'), maxsplit=1)[0].lower()
        if head in HTML_TAGS or inner.startswith(('x-', '?', '!', 'http')):
            continue
        line = clean[:m.start()].count('\n') + 1
        fail(f'{name}: unreplaced placeholder {m.group(0)} (near line {line})')


def blocks(text: str, start_re: str, stop_re: str) -> list[tuple[str, str]]:
    out, cur_id, buf = [], None, []
    for line in text.splitlines():
        m = re.match(start_re, line)
        if m:
            if cur_id:
                out.append((cur_id, '\n'.join(buf)))
            cur_id, buf = m.group(1), [line]
            continue
        if cur_id and re.match(stop_re, line):
            out.append((cur_id, '\n'.join(buf)))
            cur_id, buf = None, []
            continue
        if cur_id:
            buf.append(line)
    if cur_id:
        out.append((cur_id, '\n'.join(buf)))
    return out


def table_rows_after(text: str, heading: str) -> int:
    sect = re.split(r'\n## ', text.split(heading, 1)[1])[0] if heading in text else ''
    rows = [l for l in sect.splitlines() if l.startswith('|') and not re.match(r'^\|[\s|:-]+\|$', l)]
    return max(0, len(rows) - 1)  # minus the header row


def fences(body: str) -> list[str]:
    return re.findall(r'```[a-zA-Z]*\n(.*?)```', body, flags=re.S)


def code_lines(code: str) -> list[str]:
    return [l.strip() for l in code.splitlines() if l.strip() and not l.strip().startswith('//')]


def code_in_file(path: str, code: str) -> str | None:
    """None if the quoted code exists contiguously in the file (whitespace-insensitive), else a reason."""
    f = Path(path) if Path(path).is_absolute() else APP_ROOT / path
    if not f.is_file():
        return f'file not found: {path} (paths are relative to {APP_ROOT})'
    want = code_lines(code)
    if not want or want[0].startswith('(none'):
        return None
    have = code_lines(f.read_text(errors='ignore'))
    n = len(want)
    for i in range(len(have) - n + 1):
        if have[i:i + n] == want:
            return None
    return f'quoted code not found in {path} — copy it with sed -n, never retype it (first line: "{want[0][:60]}")'


def first_path(text: str) -> str | None:
    m = re.search(r'`([A-Za-z0-9_./-]+\.(?:php|js|css))(?::[0-9-]+)?`', text)
    return m.group(1) if m else None


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    d = Path(sys.argv[1])
    rep, plan = d / '01-report.md', d / '02-fix-plan.md'
    for f in (rep, plan):
        if not f.exists():
            fail(f'missing file: {f}')
    if errors:
        return report()
    r, p = rep.read_text(), plan.read_text()

    for name, text in (('01-report.md', r), ('02-fix-plan.md', p)):
        if 'EXAMPLE' in text:
            fail(f'{name}: still contains the template EXAMPLE block — delete it')
        check_placeholders(name, text)

    for sect in ['## 0. The screen in plain words', '## 1. Verdict', '## 2. Counts', '## 3. Scope',
                 '## 4. Routes', '## 5. Per-method table', '## 6. Findings', '## 7. Cross-cutting',
                 '## 8. Not covered']:
        if sect not in r:
            fail(f'01-report.md: missing section "{sect}"')
    if table_rows_after(r, '## 3. Scope') < 1:
        fail('01-report.md: §3 scope table has no rows')
    if table_rows_after(r, '## 5. Per-method table') < 1:
        fail('01-report.md: §5 per-method table has no rows')

    findings = blocks(r, rf'^#### ({ID_RE}) · ', r'^(#### |### |## )')
    sev = {'B': 0, 'H': 0, 'M': 0, 'L': 0}
    for fid, body in findings:
        m = re.match(rf'^#### {re.escape(fid)} · (B|H|M|L) · ', body)
        if not m:
            fail(f'01-report.md: {fid} heading must be "#### {fid} · <B|H|M|L> · <RULE-ID> — <title>"')
        else:
            sev[m.group(1)] += 1
        for fld in FINDING_FIELDS:
            if fld not in body:
                fail(f'01-report.md: {fid} is missing field {fld}')
        if body.count('```') < 4:
            fail(f'01-report.md: {fid} needs TWO code blocks — the quoted lines AND the evidence output')
        where = re.search(r'\*\*Where\*\*[^\n]*', body)
        path = first_path(where.group(0)) if where else None
        blocks_ = fences(body)
        if path and blocks_:
            why = code_in_file(path, blocks_[0])
            if why:
                fail(f'01-report.md: {fid}: {why}')
    if not findings:
        fail('01-report.md: no findings parsed. Headings must look like "#### ABC-01 · H · ERR-02 — title". '
             'If the controller is truly clean, say so in §1 and keep this check output in the hand-back.')

    m = re.search(r'## 2\. Counts.*?\n\|[^\n]*\n\|[-| :]+\n\|([^\n]*)\|', r, flags=re.S)
    if m:
        cells = [c.strip() for c in m.group(1).split('|')]
        try:
            got = dict(zip('BHML', (int(c) for c in cells[:4])))
            if got != sev:
                fail(f'01-report.md: §2 counts {got} do not match the findings {sev}')
        except ValueError:
            fail('01-report.md: §2 counts row must be numbers')

    items = blocks(p, rf'^- \[[ xX]\] \*\*({ID_RE})\*\* · ', r'^(- \[|## )')
    plan_ids = set()
    for iid, body in items:
        plan_ids.add(iid)
        if 'DECISION' in body.splitlines()[0]:
            if '➜ Choice:' not in body or '(a)' not in body:
                fail(f'02-fix-plan.md: DECISION {iid} needs options (a)/(b) and a "➜ Choice:" line')
            continue
        for fld in ITEM_FIELDS:
            if fld not in body:
                fail(f'02-fix-plan.md: {iid} is missing {fld}')
        if body.count('```') < 4:
            fail(f'02-fix-plan.md: {iid} needs a Before code block AND an After code block')
        touches = re.search(r'\*\*Touches:\*\*([^\n]*)', body)
        paths = re.findall(r'`([A-Za-z0-9_./-]+\.(?:php|js|css))`', touches.group(1)) if touches else []
        bpos = body.find('**Before**')
        before_blocks = fences(body[bpos:]) if bpos >= 0 else []
        if paths and before_blocks:
            reasons = [code_in_file(pp, before_blocks[0]) for pp in paths]
            if all(reasons):
                fail(f'02-fix-plan.md: {iid}: Before block — {reasons[0]}')
        if re.search(r'^\s*(//\s*)?\.\.\.\s*$|\betc\.', body, flags=re.M):
            fail(f'02-fix-plan.md: {iid} After/Before uses "..." or "etc." — write the full code')
    if '## 0. Do not touch' not in p:
        fail('02-fix-plan.md: missing "## 0. Do not touch" section')

    finding_ids = {fid for fid, _ in findings}
    unplanned_sect = p.split('## 10.', 1)[1] if '## 10.' in p else ''
    unplanned = set(re.findall(ID_RE, unplanned_sect))
    for fid in sorted(finding_ids - plan_ids - unplanned):
        fail(f'{fid} is in the report but neither in a plan item nor in plan §10')
    for iid in sorted(plan_ids - finding_ids):
        fail(f'02-fix-plan.md: {iid} has no matching finding in 01-report.md')

    return report(len(findings), len(items))


def report(nf: int = 0, ni: int = 0) -> int:
    if errors:
        print(f'SELF-CHECK FAIL — {len(errors)} problem(s):')
        for e in errors:
            print('  ✗', e)
        return 1
    print(f'SELF-CHECK PASS — {nf} findings, {ni} plan items, every field present.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
