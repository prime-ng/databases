# Path repair — 2026-10-27

**Scope:** `final-audit-reports/`, the two Final Audit agent twins, and
`.claude/rules/final-audit.md` in `prime_testing/`.

## What changed

1. **Application root:** every path that pointed at `/Users/bkwork/Herd/prime_ai` now points at
   `/Users/bkwork/Herd/prime_ai_dev`. The old folder exists but is empty.
2. **Teammate machine paths** were mapped to this machine:
   - `/home/tarun-chauhan/Desktop/Apps/primeworkspace/prime_ai` → `/Users/bkwork/Herd/prime_ai_dev`
   - `/home/tarun-chauhan/Desktop/Apps/primeworkspace/primeadmin` → `/Users/bkwork/Herd/mobile_school`
   - `/home/tarun-chauhan/Desktop/Apps/primeworkspace/pgdatabase` → `/Users/bkwork/WorkFolder/2-New_Primedb/pgdatabase`
   - `C:\laragon\www\PG\prime_ai*` and `c:\laragon\www\prime_ai_dev*` → `/Users/bkwork/Herd/prime_ai_dev`
   - `C:\Users\GAURAV~1\AppData\Local\Temp\opencode` → `/tmp/opencode`
3. **Registry/metadata location:** `00-CLASS-OWNERS.md`, `FINAL-AUDIT-PROTOCOL.md`,
   `PATH-REPAIR-2026-10-27.md` and `README.md` live at the **reports root**. They were briefly
   moved into a temporary `_Info` subfolder on 2026-10-27 and moved back to the root on 2026-10-28; every reference
   now resolves to the root, and all 1,148 owner links in the registry are relative to the root.
4. **Local Markdown links:** broken links were repaired mechanically, including `-done` folder
   renames, `Module-done` names, `StudentProfileController-NotUsed`, and cross-developer links.
5. **Tools:** `selfcheck.py` now defaults `APP_ROOT` to `../prime_ai_dev`; the scanner and
   scan-filter usage text uses `prime_ai_dev`.
6. **Protocol and agent twins:** both now say “start in `prime_testing/`; the application is
   `../prime_ai_dev`”; the report/application path split is stated at the top.

## Verification

- `selfcheck.py` on an unchanged, audited controller: **PASS** (22 findings, 6 plan items).
- Scanner: **4,516 files / 32,585 findings** (1 parse error, pre-existing).
- `route:list`: **8,124 routes**.
- Local Markdown links: **3,149 / 3,270 resolve**.
- Remaining 121 broken links are not path typos:
  - **46** owner-registry links and **73** Accounting index/report links point to **54
    `gaurav/Accounting` controller reports that have never been written** (for example
    `VoucherController`, `LedgerController`, `FinancialYearController`).
  - **2** are intentional placeholders in `_templates/01-report.md` and the protocol.
- No application code was changed.

## Backup

Before the repair:
`/Users/bkwork/WorkFolder/1-Old_PrimeDB/old_db/9-Working_tmp/Temp_Output_Files/final-audit-reports-backup-20261027-104844.tar.gz`

## Related additions

- `_templates/04-module-status.md` — module-wide status shape used by the Code Auditor.
- `OpenCode_Brain/agents/code-auditor.md` and `OpenCode_Brain/.opencode/agents/code-auditor.md` —
  module-level Audit / Status agent.
