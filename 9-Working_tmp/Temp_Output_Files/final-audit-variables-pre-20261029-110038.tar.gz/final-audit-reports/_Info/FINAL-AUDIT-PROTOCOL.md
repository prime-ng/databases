# Final Audit — one controller at a time, tracked to the last change

**Scope:** The last pass before production. You get ONE controller path. You audit that
controller **and every class that belongs to it**. You write a report and a fix plan, then
STOP. Tarun ticks what gets fixed. A second run applies only the ticked items and records
what it did.

**Read by:** `final-audit-auditor` and `final-audit-fixer` (Claude Code, `.claude/agents/`),
and their OpenCode twins (`.opencode/agents/`). The agent files are thin drivers.

> **Teammate copy for OpenCode, made 2026-10-12** from `.claude/rules/final-audit.md`.
> The content is the same protocol. Only the paths are corrected and §0.1 (setup) is new.
> ⚠ The OpenCode agents load `.claude/rules/final-audit.md`, not this copy. Do not edit this copy
> on its own. Send a change to Tarun so both files stay the same.

Settled 2026-10-10 by Tarun. Each decision is listed in §1. Do not re-ask them.

---

## 0.1 Setup for a teammate running OpenCode *(new in this copy)*

1. **Pull the repo.** All of these are in git, and the agents need them:
   - `.claude/rules/final-audit.md` and the rule files listed in §2;
   - `.opencode/agents/final-audit-auditor.md` and `final-audit-fixer.md`;
   - `final-audit-reports/_templates/` and `final-audit-reports/_tools/`.
2. **Start OpenCode inside `prime_testing/`.** Report paths (`final-audit-reports/…`) are relative to `prime_testing/`; application paths (`Modules/…`, `app/…`, `config/…`) and every `php artisan` command run from `../prime_ai_dev/`.
3. **Model.** Both agents name `opencode-go/deepseek-v4-flash` in their front matter. If your
   OpenCode has no `opencode-go` provider, change the `model:` line in your local copy of the two
   agent files. Do not commit that change.
4. **Your folder.** `<dev>` is `tarun`, `shailesh` or `gaurav`. The folder already exists.
   Never create a new developer folder (§3.0).
5. **How to call the agents:**
   - Audit: `@final-audit-auditor Modules/<M>/app/Http/Controllers/<X>Controller.php — <dev>`
   - Fix (only after Tarun has ticked `02-fix-plan.md`):
     `@final-audit-fixer Modules/<M>/app/Http/Controllers/<X>Controller.php — <dev>`
6. **Your local tenant.** F7 and L10-style checks run `tinker` against a tenant. Initialise it first.
   Use your own tenant domain if it is not `test.localhost`:
   ```php
   $d = \Modules\Prime\Models\Domain::where('domain','test.localhost')->first();
   tenancy()->initialize($d->tenant);
   ```
7. **No structured question tool?** Ask with the numbered format in
   `.claude/rules/module-finalization.md` §5.6.7. Number the options and put the recommended one first.
8. **Before you start, and again before every write,** pull or re-read `00-INDEX.md` and
   `final-audit-reports/00-CLASS-OWNERS.md`. Tarun and other sessions write them at the same time (§3, §12).

---

## 0. The flow

```
 TARUN    gives a controller path AND a developer name (tarun | shailesh | gaurav)
   │
 AUDITOR  §3  claim the row in <dev>/<Module>/00-INDEX.md   (append-only)
          §4  resolve the scope: routes, FormRequests, policy, services, models, jobs, blades
          §5  claim every non-common class in final-audit-reports/00-CLASS-OWNERS.md, or link to its owner
          §6  run the checklist, one family at a time, with evidence
          §8  write 01-report.md and 02-fix-plan.md
          ══  STOP. Hand back a short summary. Nothing in prime_ai_dev/ code has changed.
   │
 TARUN    ticks [x] in 02-fix-plan.md, writes a choice next to every DECISION item
   │
 FIXER    §9  applies ONLY the ticked items, in plan order
          §10 verifies with php -l, class_exists, route:list, blade compile, scan.php, grep
          §11 writes 03-status.md and updates the index row
          ══  STOP. Hand back the change table and anything that needs Tarun's hand.
```

---

## 1. Settled decisions — binding, do not re-ask

| # | Decision | Consequence |
|---|---|---|
| D1 | **ERR-00 = the Laravel idiom.** No try/catch in controllers. `DB::transaction(fn () => …)` rolls back by itself. The central handler in `bootstrap/app.php` logs and renders errors. | A controller try/catch is a finding, unless D2 allows it. House rule A1 does NOT apply to modules under final audit. |
| D2 | **ERR-01 sub-decisions.** Business-rule messages use `\DomainException`. Never catch `RuntimeException` (QueryException extends it). A truncate-then-rebuild method keeps ONE catch with the fixed message "…now empty. The error has been logged.", because TRUNCATE commits and cannot roll back. `SnapshotProtectionException` messages are user-safe and shown verbatim. Services use `report($e)` plus a fixed message. | These are the ONLY allowed catches. Each one gets a comment naming ERR-01 and the date. |
| D3 | **Fix in place.** Same files, routes, URLs and route names. God-controller splits come later. | A CTL-01 split goes in the plan as a DEFERRED decision. It is never applied in this pass. |
| D4 | **NO testing of any kind.** Never run `php artisan test`, pest or dusk. Never write or edit tests unless Tarun asks. | Verify with §10 only. A fix that needs a test to be trusted is reported as "unverified by this workflow". |
| D5 | **Unrouted public method → body becomes `abort(403, '…')` with a `NOT ROUTED` comment.** Never delete it. | Its now-dead private helpers stay. Report them as CTL-10. |
| D6 | **One controller = one folder, under the DEVELOPER's folder**: `final-audit-reports/<dev>/<Module>/<Controller>/`, with `01-report.md`, `02-fix-plan.md`, `03-status.md`. *(Changed 2026-10-10 — §3.0.)* | §3.0, §8. |
| D7 | **Scope = everything the controller uses**, minus "common" classes (§4.2). A class shared by several controllers is audited ONCE, by the first controller that reaches it. Later reports link to that report. | §5. |
| D8 | **Approval = tick boxes. TARUN ticks; the DEVELOPER runs the fixer** (settled 2026-10-10). `[ ]` → `[x]` in `02-fix-plan.md`. A DECISION item shows its options inline; Tarun writes the choice next to it. The fixer applies only ticked items. | §8.3, §9.1. |
| D11 | **Reports are written to be acted on by a SMALLER model** (OpenCode / deepseek-v4-flash) and a developer who has never opened the controller. Every plan item is paste-ready code; nothing is left to inference. *(settled 2026-10-10)* | §8.4, §15, §16. |
| D9 | **Parallel use.** Tarun plus the team, Claude Code plus OpenCode. Claim before starting. Write append-only. | §3, §12. |
| D10 | **TimetableFoundation work done on 2026-10-10 is logged, not re-done.** The audit is fresh. A file touched that day gets a "Pre-applied 2026-10-10" section at the top of its `03-status.md`. | Read `final-audit-reports/tarun/TimetableFoundation-done/PRE-APPLIED-2026-10-10.md`. |

Standing rules from the wider project still apply:

- Never edit an existing migration.
- The DDL wins (`module-finalization.md` §1.4, with its §1.4.1 carve-out).
- Never `pkill`.
- Verify every edit by grep.
- Run Pint only on touched files (`vendor/bin/pint <file> --format agent`), never `--dirty`. Other sessions' files would be reformatted.
- Never put a Claude/AI trailer in a commit.

---

## 2. Inputs every agent loads first

| File | Why |
|---|---|
| **this file** | the protocol |
| `final-audit-reports/_tools/00-RULEBOOK.md` | the rule IDs (ERR, TXN, AUTH, VAL, CTL, MDL, SVC, QRY, RTE, VIEW, JOB, SEC, TEN, STY) and the deep-read checklist. ⚠ Vendored copy inside `prime_testing/final-audit-reports` (teammates may not have `prime_info`). Its ERR-00 "undecided" is overridden by D1 |
| `../prime_ai_dev/.claude/rules/controller-alignment.md` §0, §0.1, §6 | measure before fixing; a perfect table hides a MISSING write; count across controller AND service |
| `../prime_ai_dev/.claude/rules/module-finalization.md` §1.5.1, §3.3.1, §3.4.3, §4 | the instrument can lie; unbound route models; private copies of shared loaders; the known-issue catalogue |
| `../prime_ai_dev/.claude/rules/table-action-standard.md`, `modal-standard.md`, `breadcrumb-standard.md`, `export-component-standard.md` §11, `import-component-standard.md` §10 | the UI standards the VIEW family checks |
| `../prime_ai_dev/.claude/skills/laravel-best-practices/SKILL.md` | Laravel Boost guidance for the QRY/PERF family |
| `../prime_ai_dev/.ai/rules/index.md` **if it exists** | Boost project rules. If the folder is missing, continue without it |

⚠ **Read the NAMED SECTIONS only, and only when their family comes up.** Several of these files
are over 1,000 lines. Loading them whole fills a small model's context and pushes the controller
code out. Read this file in full; read the others section by section, at the point you need them.

---

## 3. Claiming — parallel-safe

### 3.0 The developer folder *(settled 2026-10-10, Tarun)*

Every report lives under the folder of the developer it belongs to:

```
final-audit-reports/
├── 00-CLASS-OWNERS.md         shared-class registry (append-only)
├── FINAL-AUDIT-PROTOCOL.md    this protocol copy
├── README.md                  usage guide
├── PATH-REPAIR-2026-10-27.md  path-repair record
├── _templates/                the file shapes
├── _tools/                    rulebook · scanner · self-check
├── tarun/  shailesh/  gaurav/ ← the developer folders
│   └── <Module>/ or <Module>-done/
│       ├── 00-INDEX.md        this developer's index for this module
│       ├── 00-SUMMARY.md      module mode only (§13)
│       ├── 00-STATUS.md       module-wide status / re-check (Code Auditor)
│       └── <Controller>/      or <Controller>-done/
│           ├── 01-report.md · 02-fix-plan.md · 03-status.md · 04-reaudit.md
└── tarun/TimetableFoundation-done/   LEGACY pre-2026-10-10 reports. Do not add to it.
```

- **Tarun names the developer with the controller path.** No name → ASK. Never pick one, never
  default to `tarun`.
- The name must be an existing folder under `final-audit-reports/`. An unknown name → stop and
  list the folders that exist. **Never create a developer folder yourself.**
- `<dev>` in the rest of this file means that folder.
- **The fixer and the re-audit use the SAME developer folder as the audit.** If none is named,
  look for `*/<Module>/<Controller>/01-report.md`: exactly one hit → use it and say so; zero or
  several → ask.
- ⚠ **Claims are checked ACROSS ALL developer folders, legacy included** (§3.1 step 2), because
  two developers must never audit the same controller.

Several sessions run at once. They must not audit the same controller, and they must not
overwrite each other's files.

### 3.1 The module index

`final-audit-reports/<dev>/<Module>/00-INDEX.md` — one row per controller:

```
| Controller | Status | B | H | M | L | Report | By | Updated |
```

Status values: `CLAIMED` → `AUDITED` → `APPROVED` → `FIXING` → `FIXED` (or `BLOCKED`).

**To claim:**

1. Re-read the index **immediately before** writing.
2. Check **every** index for this module, not just yours:
   `grep -n '| <Controller> ' final-audit-reports/*/<Module>/00-INDEX.md 2>/dev/null`.
   If any row for the controller has a status other than `FIXED`, STOP. Report the folder and who holds it.
3. Otherwise **append** one row with `CLAIMED`, your agent name (`claude`/`opencode`) and the date.
   If `<dev>/<Module>/00-INDEX.md` does not exist, create it (and the `<Module>/` folder) from
   `final-audit-reports/_templates/00-INDEX.md`.

**To update:** change ONLY your own row, with an exact-match edit. ⛔ **Never rewrite the
file.** Never use a truncating write (`content[:i] + new`). A parallel session may have
appended rows after yours. A truncating write once destroyed 72 lines of a rule file
(`screen-readiness-fix.md` §7.4).

### 3.2 The class-ownership registry

`final-audit-reports/00-CLASS-OWNERS.md` is one file for the whole app, because a controller
can reach a class in another module — and it is shared by **all developers**, so it lives in ``. It is append-only, one line per class. The owner link is **relative to the root** and
includes the developer: `[<dev>/<Module>/<Controller>](<dev>/<Module>/<Controller>/01-report.md)`.
⚠ Legacy rows now point at `tarun/TimetableFoundation-done/…`.

```
| Class (path) | Owner report | Claimed |
```

§5 says when to read it and when to append to it.

---

## 4. Resolving the scope

### 4.1 Build the list mechanically — never from the brief

```bash
cd ../prime_ai_dev
C=Modules/<M>/app/Http/Controllers/<X>Controller.php
php -l "$C"

# 1. routes that point at this controller (uncached — a stale cache lies)
APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json 2>/dev/null \
  | php -r '$r=json_decode(stream_get_contents(STDIN),true);
            foreach($r as $x) if(str_contains($x["action"],"<X>Controller@"))
              printf("%-7s %-55s %-50s %s\n",$x["method"],$x["uri"],$x["name"]??"-",$x["action"]);'

# 2. every public method, and whether it is routed
grep -nE 'public function [a-zA-Z_]+' "$C"

# 3. what the controller imports and injects
grep -nE '^use |function __construct' "$C"

# 4. FormRequests, policies, services, jobs, events, mail, notifications it names
grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b' "$C" | sort -u

# 5. views it renders, and every partial / component those include
grep -oE "view\(['\"][^'\"]+" "$C" | sort -u
```

If `route:list` fatals for the whole app, use the router probe in
`screen-readiness-audit.md` C13 #7. Then walk outward from each view through `@include`
and `<x-…>` until the list stops growing (`module-finalization.md` §3.8.1).

### 4.2 What is "common" — referenced, never audited here

- Framework and app glue: `app/` (base `Controller`, `BaseModel`, `User`, helpers, Providers, Breadcrumbs).
- Shared components under `resources/views/components/**` and the layouts.
- `Modules/TenantCore/**` (export, import, shared UI).
- Models and services of a **different module**, unless this controller is the first one to reach them. In that case §5 applies.

A defect found in a common class is recorded as a **cross-cutting note** in the report (§8.1 §7).
It is never fixed by this workflow.

### 4.3 The scope table

The report opens with one row per in-scope file:

```
| # | File | Kind | Lines | Owner | Audited |
```

- **Owner** is this report, or a link to another report (§5).
- **Audited** is ✅, `↗ linked`, or ❌ with a reason.
- A file without a row was not audited. "Everything checked" without the table is a failed audit.

---

## 5. Shared-class ownership (D7)

Use this for every non-common class in the scope: model, service, FormRequest, policy, job, blade partial.

1. `grep -F '<class path>' final-audit-reports/00-CLASS-OWNERS.md`
2. **Owned elsewhere?** Do not re-audit it. Mark the scope row `↗ linked` and point at that
   report. Still check **how this controller uses it** — wrong arguments, a missing eager load,
   a guard it bypasses. That usage is this report's business.
3. **Not owned?** Append a claim line, then audit it fully in this report.
4. **The owner report is still `CLAIMED`** (in progress)? Link it anyway. Say in the report
   that the class is audited elsewhere and may not be finished yet.

A FormRequest or blade used only by this controller is owned by this controller. Do not
register it. Register only classes another controller could plausibly reach.

---

## 6. The checklist

Work the families in this order. For every finding, record:

- an **ID** (`<ABBR>-NN`, where ABBR is a short form of the controller name, e.g. `ACT`, `RCON`, `TAV`);
- the **rule ID** from `00-RULEBOOK.md`;
- the **severity** (B / H / M / L, rulebook meanings);
- `file:line`, with the lines quoted;
- the **evidence command**;
- the **user consequence**, in one sentence.

A clean family gets one line: "clean — <the command that proved it>".
`module-finalization.md` §4's catalogue applies in full: for each family in it, report an
instance or write "checked, not present".

### F1 — Errors (ERR-01..07, under D1/D2)

- No `try/catch` in a controller, except the D2 shapes.
- No `$e->getMessage()` reaching the user. Check `with()`, `withErrors`, `json()`, `back()` and flash strings.
- No `catch (\RuntimeException)`.
- Services: `report($e)` plus a fixed message. Never `Log::error(…, ['error' => $e->getMessage()])` alone.
- No swallowed failure on a write path.
- A `findOrFail()` must not sit inside a catch that turns a 404 into a redirect.

### F2 — Transactions and audit (TXN-01..06, house A2/A3, C7.1)

- Every multi-table write runs inside ONE `DB::transaction` closure. Every mutation that calls `activityLog()` counts as multi-table.
- **Per function, not per file**: each mutating method must have:
  - a transaction;
  - `activityLog()` placed **after** the write and **inside** the transaction;
  - its event literal recorded verbatim.
- No irreversible side effect inside a transaction (mail, file delete, HTTP).
- Check-then-act needs a lock or a unique index.
- ⛔ `controller-alignment.md` §0.1: name the tables each mutation SHOULD touch before counting the ones it does.
- §6 there: count across the controller **and** every service it calls, and say where each transaction lives.

### F3 — Authorization (AUTH-01..06)

- Every routed method authorizes, before it loads any record.
- The permission name follows `scope.module.feature.action`.
- That name is declared in `config/permissionslist.php` and appears identically on all four surfaces:
  - the controller;
  - the FormRequest's `authorize()` — it runs FIRST;
  - the view (`@can`, `permission=`);
  - the config.
- Check it is seeded with an **exact-name** query, never `LIKE`.
- `Gate::any(...)` without `|| abort(403)` is a no-op.
- `Gate::authorize('string')` never reaches a Policy. Report every Policy that nothing consults.

### F4 — Validation and input (VAL-01..07)

- Validation lives in a FormRequest. Inline `validate()` is allowed only for a one-field AJAX toggle.
- Use `validated()` / `safe()`. Never `$request->all()` or `except()` into a model.
- Optional fields are read with `?? null`.
- Uniqueness rules mirror the real index, including soft-delete semantics.
- Every field is typed.
- Uploads carry `file` + `mimes` + `max`.
- **Execute** every FormRequest that has a cross-field rule against a realistic payload (`module-finalization.md` §3.5.1). Reading the rules alone is not enough.

### F5 — Routes (RTE-01..06)

- No state change over GET.
- Every route points at a method that exists.
- Every public method is routed, or follows D5.
- Custom routes are registered before `Route::resource`.
- The route parameter name matches the controller argument (§3.3.1: an unbound model becomes an INSERT).
- Tenant middleware is present.

### F6 — Controller shape (CTL-01..10)

- Size: over 1,000 lines or 25 methods is M; over 2,500 lines is H. Split → DEFERRED, per D3.
- Methods over 80 lines (M) or 150 lines (H).
- Route model binding.
- Return types.
- Copy-paste blocks.
- Business logic sitting in the controller.
- `compact()` over ~15 variables.
- `request()` helper used instead of an injected `Request`.
- Debug leftovers.
- Dead code.

### F7 — Models (MDL-01..09)

- `$fillable` declared. Nothing sensitive in it.
- `$casts` cover every boolean, date, decimal and JSON column.
- `$table` exists in a migration.
- `SoftDeletes` present if and only if the table has `deleted_at`.
- Pivots with `deleted_at` use `wherePivotNull`.
- Relationships have return types and resolve. **Prove it in tinker.**
- A Spatie `InteractsWithMedia` model overrides `getMediaModel()` (TEN-01).
- `$timestamps = false` comes with a `created_at` cast (§4 catalogue).

### F8 — Services and jobs (SVC-01..05, JOB-01..05)

- No HTTP inside a service.
- Constructor injection.
- No writes on a read path.
- One implementation per operation.
- Repeated lookups are memoised.
- Jobs run in tenant context, declare tries and timeout, and store ids rather than models.
- Slow listeners are queued.
- Tenant-scoped cache keys.

### F9 — Queries and performance (QRY-01..15, CACHE-001)

- No query inside a loop (N+1).
- Lists paginate at **10**, with a distinct `pageName` per list (C12).
- Select only the columns used.
- Prefer `exists()` / `count()` / `pluck()` / `value()` to `->get()->…`.
- Aggregate in SQL.
- Big tables are chunked.
- Bulk writes.
- No interpolated raw SQL (QRY-11 is B).
- The same lookup is resolved once per request.
- Dropdowns/settings re-queried on every request are a caching candidate.
  - Cache keys must carry the tenant id.
  - Adding a cache is a DECISION item, not a fix.

### F10 — Views (VIEW-01..03 plus the UI standards)

- No queries in Blade.
- Relations used inside `@foreach` are eager-loaded.
- No `{!! !!}` on user text.
- Row actions use `x-backend.table.action`; trash rows use `action-trashed`. `:canEdit` does nothing.
- A create form with 15 or fewer controls is a modal (`modal-standard.md` §2.5).
- Breadcrumb: resolve the trail. Never just read the config.
- Export/import gates use `.export` / `.import`. An import must call `Gate::authorize` in all three controller methods.
- A `{{ $model->relation }}` dumps the whole row as JSON — a data leak (C13.2).
- A `??` on a column that does not exist is silent forever.
- Blades must compile. Never a `{{-- --}}` inside `@php`.

### F11 — Security and tenancy (SEC-01..05, TEN-01..04)

- `env()` only inside `config/`.
- No personal data over-exposed in JSON.
- No hard-coded ids or `?? 1`.
- No secrets in logs.
- Private files are served through authorised routes.
- Cache and static caches are keyed by tenant (and snapshot where relevant).
- Central models are reached via `tenancy()->central()`.

### F12 — Style (STY-01..07)

Report as **L**, grouped as ONE plan item per file, never one item per line:

- Pint-clean;
- `strict_types` on files you touch;
- camelCase names;
- one import per class;
- English comments without emoji;
- no commented-out code;
- no copy-pasted docblocks.

### F13 — Deep read (rulebook deep-read checklist)

For each mutation, answer:

1. Can a write overwrite data it should not?
2. Is anything deleted before its replacement is stored?
3. Are there duplicate implementations of one operation?
4. Is there a soft-delete × unique index trap?
5. Is there a race?
6. Is there an authorization hole?
7. Does any message lie?
8. Is there a dead feature?

### Instruments

Run the scanner once per audit and keep only the rows for in-scope files. Export a FRESH route
list first — the scanner reads it, and a stale one reports dead routes that are not dead:

```bash
APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json > /tmp/fa-routes.json
php final-audit-reports/_tools/scan.php . /tmp/fa-routes.json /tmp/fa-<ctrl>.json
python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-<ctrl>.json <every in-scope file path from §4.3>
```

⛔ **Never `cat`, `head`, `grep` or read the scan JSON directly** — it is ~12 MB and ~34,000 rows,
and it will flood a small model's context. `scanfilter.py` is the only way to read it.
The scan takes ~45 s; run it **once per session**, and in module mode reuse the same file for
every controller.

⛔ **The scanner finds candidates, never verdicts.** Confirm every hit in source before reporting it.
Prove every ABSENCE with a loose query that can see a PRESENCE (`module-finalization.md` §1.5.1).
A `grep -c` counts lines, matches comments, and double-counts slot components (C13).

---

## 7. Severity and plan order

The rulebook gives the default severity. Raise or lower it with a one-line reason.

Order the plan by **what the brokenness is suppressing**, not by severity
(`module-finalization.md` §6.2.1). Ask: *if I fix only this, what becomes reachable that was
not reachable before?*

Default plan groups:

1. **Blockers** that are reachable today: B-severity, page-killers, data leaks.
2. Fixes that ARM a latent defect, sequenced so the latent one is fixed first.
3. Errors and transactions (F1/F2).
4. Authorization (F3) — only when the permission name already exists. A new key is a DECISION.
5. Validation, routes, models (F4/F5/F7).
6. Queries and performance (F9) — mechanical items only. Caching is a DECISION.
7. Views (F10).
8. Style (F12) — one item per file.
9. **Deferred** — splits (D3), and anything waiting on another controller's report.

---

## 8. The three files

Templates live in `final-audit-reports/_templates/`. Copy them; never invent a new shape.

### 8.1 `01-report.md` — the evidence

Sections, in order (the template has every heading — keep them):

0. **The screen in plain words** — URL(s), menu path, who uses it (roles that hold the
   permission, measured), what a user does there, tables written and read, live row counts.
   This is the section that lets a developer who never opened the controller follow the rest.
1. **Verdict** — 3-5 sentences:
   - Is this controller production-ready?
   - What is the single worst finding?
   - What is the rough effort?
2. **Counts** by severity and by family.
3. **Scope table** (§4.3).
4. **Routes** — the uncached `route:list` output, plus unrouted methods.
5. **Per-method table**:

   ```
   | Method | Routed | Gate | Tx | activityLog (event) | Writes tables | Findings |
   ```

6. **Findings by family** F1→F13. Heading: `#### <ABBR>-NN · <B|H|M|L> · <RULE-ID> — <title>`.
   Each finding carries **all eight** fields of the template table, plus two code blocks:
   - **Rule** — the ID, its severity AND its one-line meaning copied from the rulebook;
   - **Where** — `file:line-range` and the method name;
   - **Root cause** — WHY the code is wrong, not just what is wrong;
   - **Consequence** — what a real user sees, in one sentence;
   - **Reproduce** — the URL / action that shows it in the browser, or "static only — <why>";
   - **Fix approach** — the direction, one or two sentences;
   - **Plan item** — the ID and section in `02-fix-plan.md`, or "none — see plan §10";
   - **Evidence** — the command you ran and its REAL output;
   - code block 1: the quoted current lines; code block 2: the evidence output.
7. **Cross-cutting notes** — defects in common or other-module classes. Not fixed here.
8. **What this audit did not cover**, and why.

Write it for a developer who has not read the code. Use plain English first and code second.

### 8.2 `02-fix-plan.md` — the approval sheet

One item per fix, grouped per §7. Every item is a checkbox Tarun can tick, and **every
non-DECISION item carries six fields** (copy the template's example item):

````markdown
- [ ] **ACT-03** · B · ERR-01 · `ActivityController.php:410-418` — stop sending the raw exception text to the user.
  - **Touches:** `Modules/TimetableFoundation/app/Http/Controllers/ActivityController.php`
  - **Before** (`ActivityController.php:410-418`):
    ```php
    <the exact current lines, copied from the file>
    ```
  - **After:**
    ```php
    <the exact replacement — complete, paste-ready, no "..." and no "etc.">
    ```
  - **Verify:** `grep -n "getMessage" Modules/TimetableFoundation/app/Http/Controllers/ActivityController.php`
  - **Expect:** no output.
  - **Effort:** S
````

⛔ **Before must be copied, not retyped** — read the lines with `sed -n '410,418p' <file>` and paste
them. A Before block that does not match the file byte for byte makes the fixer stop on that item.

DECISION items carry their options inline, with the recommendation first:

```markdown
- [ ] **ACT-09** · M · DECISION · CTL-01 — split the 1,340-line controller?
      (a) ⭐ defer to the split pass (D3)  (b) extract the generation methods now
      (c) leave as is, record as accepted
      ➜ Choice: ____
```

Rules:

- One item = one coherent change. Group the same fix across one file into one item.
- Every item names the file(s) it will touch. The fixer edits nothing else.
- An item that touches a **shared** file is marked `⚠ SHARED`:
  - `config/permissionslist.php`;
  - a component;
  - a route file;
  - a class owned by another report.

  Tarun must tick it explicitly. `"tick all"` does not cover `⚠ SHARED` items.
- An item that needs a **migration**, a **new permission key**, or a `glb_menus` edit is always
  a DECISION item (`screen-readiness-fix.md` §3.2).
- Open with **"## 0. Do not touch"** — the real file names this plan must not edit (shared
  components, layouts, route files, migrations, classes owned by another report).
- End with **"## 10. Findings with no plan item"** — every finding ID that has no item, with why.
  Every finding appears either as an item or in §10. The self-check (§15) enforces it.
- Keep the "How to approve" box: Tarun ticks `[x]` and fills every `➜ Choice:`; the developer
  then runs the fixer on this controller path.

### 8.3 `03-status.md` — the ledger

Written by the fixer. Sections, in order:

1. **Pre-applied 2026-10-10** — only for files listed in the module's `PRE-APPLIED-2026-10-10.md`. Copy the relevant rows.
2. **Applied** — one row per item:

   ```
   | ID | File:line | What changed | Verify command | Output | Date |
   ```

3. **Not applied** — every unticked item, plus anything blocked, each with a reason.
4. **Needs Tarun's hand** — for example:
   - a migration to run (`php artisan tenants:migrate`);
   - `/system-config/sync-permissions`;
   - a seeder;
   - a browser check.
5. **Unverifiable by this workflow (D4)** — for example, a permission refusal no seeded role can exercise.
6. **Verification log** — the exact commands run and their output.
7. **Final state** — the controller's status, and the remaining open items by severity.

### 8.4 The writing standard — for a developer and a smaller model *(D11)*

The reader of `01-report.md` is a developer who has never opened this controller. The reader of
`02-fix-plan.md` is the fixer agent, which may be a small model. Write for both:

| # | Rule | Why |
|---|---|---|
| 1 | **Plain English first, code second.** Gloss every term the first time (soft delete, N+1, transaction, FormRequest). | the developer decides from the words, not the code |
| 2 | **One finding = one root cause.** Five methods with the same missing transaction are ONE finding listing the five methods, not five findings. | keeps the plan to one item per change |
| 3 | **No speculation words** — "may", "might", "could", "appears", "seems", "probably". Either prove it or write `⚠ UNVERIFIED — <what would settle it>`. | an unproven claim sends the fixer to change correct code |
| 4 | **Every line number comes from a command** (`grep -n`, `sed -n 'A,Bp'`), never from memory. | a small model's recalled line numbers drift |
| 5 | **Copy literals exactly** — Gate strings, event names, flash text, column names, route names. | the fixer greps for them |
| 6 | **After blocks are complete**: every `use` import the new code needs is shown (a separate small Before/After pair at the top of the file is fine); no `...`, no `etc.`, no "same as above". | the fixer pastes, it does not compose |
| 7 | **One item touches as few files as possible.** If it needs two files, list both under Touches and give a Before/After for each. | the fixer refuses to edit an unnamed file (§9.2 #2) |
| 8 | **Severity carries its reason** when you change the rulebook default — one clause in the Rule field. | Tarun ticks by severity |
| 9 | **Every in-scope method gets a row in §5**, including clean ones. **F13 is answered as a table** — one row per mutating method, eight columns (the eight questions), each cell `ok` or a finding ID. | completeness is visible, not asserted |
| 10 | **A clean family is one line with its proving command and output** — never just "clean". | absence needs evidence too (§1.5.1 of module-finalization) |

---

## 9. The fixer's rules

### 9.1 Entry gate — refuse if any of these is missing

- `01-report.md` and `02-fix-plan.md` exist for the given controller.
- At least one item is ticked `[x]`.
- Every ticked DECISION item has a filled `➜ Choice:`. If one is empty, stop and list it.

### 9.2 While fixing

1. **Re-read every shared file immediately before editing it.** Re-run the §4.1 route probe at the start (`module-finalization.md` §1.5.2).
2. Apply ticked items **in plan order**. Touch only the files the item names. If an item needs a file it does not name, stop that item and report it.
3. **Re-measure before each change.** If the code no longer matches the report — someone else fixed it, or it moved — record "already applied" or "superseded". Never apply blind (`controller-alignment.md` §0).
4. Keep `findOrFail()` outside any remaining catch. Follow D1/D2 exactly.
5. Keep the existing `activityLog` event literals, flash text and route names, unless the item says otherwise.
6. Grep for callers before renaming or removing anything. A relation named in `with([...])` is a bare string.
7. Add a feature-context comment where the reason is non-obvious, citing the finding ID and the date.
8. Never edit an existing migration. A new additive migration is written only when the ticked DECISION says so — and **never run**. Running it is Tarun's hand.
9. A new permission key goes in `config/permissionslist.php` only when its DECISION is ticked. Seeding it is Tarun's hand (`/system-config/sync-permissions`).
10. When a fix touches a method whose *behaviour* is also wrong, and that behaviour fix was not ticked: wrap it, leave it, and say so in a code comment (`screen-readiness-fix.md` §7.3).

### 9.3 Stop and ask instead of fixing

Stop on any of these:

- the change reaches outside the item's named files;
- a shared component or layout is involved;
- a route is added, removed or re-scoped;
- `glb_menus` is involved;
- an answer to "what should it do?" is needed.

Measure the blast radius first, and quote the number when you ask.

---

## 10. Verification — D4: no tests

After every item, and again at the end:

```bash
php -l <every touched php file>
php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php";
        $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
        var_dump(class_exists(<FQCN>::class));'                       # every touched class
APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json >/dev/null && echo ROUTES-OK
# every routed action still has its method (method_exists over the route list)
# every touched blade compiles AND emits no stray directive:
#   compileString() → php -l; compare substr_count($src,'@push(') with substr_count($out,'startPush')
vendor/bin/pint <touched files> --format agent
APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json > /tmp/fa-routes.json
php final-audit-reports/_tools/scan.php . /tmp/fa-routes.json /tmp/fa-<ctrl>-after.json
# diff the in-scope rows before vs after: fixed IDs gone, nothing new introduced
grep -n '<the exact added/removed construct>' <file>                # count construct vs change
```

- Re-run `php -l` and `class_exists` **after Pint** — it edits imports.
- `class_exists` is the gate. `php -l` cannot see an inheritance fatal.
- `replace_all` matches leading whitespace, so count both call sites and changes (`module-finalization.md` §6.3.1).

---

## 11. Hand-back — the only thing the user sees

**Auditor**, in 10 lines or fewer:

- the report path;
- counts B/H/M/L;
- the single worst finding, in one sentence;
- the number of DECISION items;
- any class it linked to another report;
- the **self-check PASS line** (§15) — an auditor hand-back without it is not finished;
- the line "Tick items in 02-fix-plan.md, then run final-audit-fixer on this path."

**Fixer**:

- the change table;
- what it did not apply, and why;
- what needs Tarun's hand;
- what is unverifiable;
- the final status.

Neither agent reports git status, and neither runs anything that tests the screen.

---

## 12. Traps already measured — read before the first command

| Trap | Guard |
|---|---|
| A stale route/config/event cache | `config:clear`, `route:clear` and `event:clear` before the scan. Pass `APP_ROUTES_CACHE=<missing path>` to `route:list`. |
| `LIKE '%a_b%'` matches `a-b` | Use exact-name queries for permissions. |
| A shell-escaped FQCN in `tinker --execute` returns a false zero | Use `Model::class`. |
| A grep hit inside a comment | Read the matched lines. |
| A count of `<x-component` doubles because of closing tags | Count the opening form only. |
| A truncating write on a shared file | Splice a bounded span, or append. Assert the line count did not shrink. |
| The brief's counts are stale | Measure. Your numbers win. Say so where they disagree. |
| The controller holds no transaction because the service does | Count both (`controller-alignment.md` §6). |
| An unbound route model | Compare `parameterNames()` with the method's parameter names (`module-finalization.md` §3.3.1). |
| Another session changed a file under you | An unexplained change means you have not found the change yet. Re-read before you conclude anything. |

---

## 13. Module mode — Tarun gives a MODULE path *(settled 2026-10-10)*

Input: `Modules/<Module>`. Decisions (asked and answered 2026-10-10):

| # | Decision | Answer |
|---|---|---|
| M1 | Report layout | **One folder per controller** (§8) **plus `<dev>/<Module>/00-SUMMARY.md`** — all under the developer folder (§3.0) |
| M2 | Concurrency | **3 auditor agents at a time** (changed from 5 on 2026-10-10), the main session checks each batch before starting the next |
| M3 | Re-audit output | **`04-reaudit.md`** per controller; `01-report.md` stays untouched as the baseline (§14) |

### 13.1 Order of work (main session drives, agents audit)

1. List the controllers: `ls Modules/<M>/app/Http/Controllers/*.php` with line counts. Skip any row already `AUDITED`+ in `00-INDEX.md` unless Tarun asks for a redo.
2. **Batch to avoid shared-class races.** Controllers that reach the same model go in DIFFERENT batches, or the first one in the batch audits the model and the rest link (§5). Put the largest controller (god-controller) in the **last** batch so it can link to the shared-class reports that already exist.
3. Per batch: spawn up to 3 `final-audit-auditor` agents, one controller each. Each claims its own index row (§3) and writes only its own folder.
4. After each batch: the main session checks every report exists, each index row is `AUDITED` with counts, and `final-audit-reports/00-CLASS-OWNERS.md` has no duplicate claim. Fix duplicates by keeping the earlier claim and linking the later report.
5. After the last batch: write `00-SUMMARY.md` (§13.2). Hand back in ≤10 lines and STOP.

⛔ The main session never self-dispatches the NEXT module. Tarun picks it.

### 13.2 `<dev>/<Module>/00-SUMMARY.md`

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|

Then: module totals; **cross-controller families** (the same defect in N controllers — report it once here, with the list, so the team fixes it as one change); shared classes and their owner reports; decisions that apply module-wide (e.g. policies unreachable because gates pass strings).

### 13.3 Module-wide status re-check — `00-STATUS.md`

The Code Auditor can re-check every `02-fix-plan.md` item in a module without applying fixes.
It writes `<dev>/<Module>/00-STATUS.md` (or `00-STATUS-<date>.md` if one already exists) from
`_templates/04-module-status.md`. This is read-only: it does not edit `01-report.md`,
`02-fix-plan.md`, `03-status.md` or `00-INDEX.md`, and it never changes application code.

---

## 14. Re-audit mode — after the team's fixes *(settled 2026-10-10)*

Trigger: Tarun asks to re-audit a controller or a whole module whose rows are `FIXED`/`BLOCKED`.

- Read the baseline `01-report.md`, `02-fix-plan.md` and `03-status.md` in the developer folder that holds them (§3.0). **Never edit them.** `04-reaudit.md` goes in the same folder.
- Re-measure every original finding against the current code with its original evidence command. Mark each **FIXED / STILL OPEN / REGRESSED / NOT TICKED** (not ticked = intentionally skipped by the team).
- Run the full F1-F13 checklist again for **NEW** findings; give them new IDs continuing the sequence.
- Write `04-reaudit.md`: date, by, a status table of every original ID, then the new findings in §8.1 format, then a verdict.
- Update the index row: status `RE-AUDITED` and the counts of what is still open + new.
- Re-audit is read-only, exactly like the audit (§1, D4).

---

## 15. Self-check — the auditor runs it before handing back *(settled 2026-10-10)*

```bash
cd ../prime_ai_dev
python3 final-audit-reports/_tools/selfcheck.py final-audit-reports/<dev>/<Module>/<Controller>
```

It fails on: a missing section; an unreplaced `<placeholder>`; a leftover `EXAMPLE`; a finding
missing any of the eight fields or its two code blocks; §2 counts that disagree with the
findings; a plan item missing Touches/Before/After/Verify/Expect/Effort; `...` or `etc.` in code;
a finding with no plan item and no §10 row; a plan item with no finding; and — the important one —
**a quoted code block or a Before block that does not exist in the named file** (hallucinated or
retyped code).

- **Fix every FAIL line and run it again until it prints PASS.** Do not hand back on a FAIL.
- Paste the PASS line into the hand-back (§11).
- ⚠ **PASS means complete, not correct.** It checks shape and that quoted code is real. It does not
  check that your reasoning is right — §1.5 and §1.5.1 still apply to every finding.

---

## 16. Operating rules for a smaller model (OpenCode / deepseek-v4-flash) *(D11)*

The audit is run on OpenCode to save cost. A smaller model loses track over a long run, so:

1. **One controller per session.** Never two. In module mode the main session dispatches one agent per controller.
2. **Write the report as you go, family by family.** Create `01-report.md` from the template first,
   then save it after each family F1…F13. A long run that loses context must not lose the findings.
3. **Re-read, do not recall.** Before writing a finding, re-run `sed -n 'A,Bp' <file>` for the exact
   lines. Never quote code from memory — §15 rejects quoted code that is not in the file.
4. **Run every command for real and paste its real output.** Never write what a command "would" print.
5. **When unsure, mark it** `⚠ UNVERIFIED — <what would settle it>` and move on. A wrong confident
   finding costs more than an honest gap.
6. **Do not load whole rule files** (§2 note). Read the named section when its family comes up.
7. **Order of writing:** §0 screen → §3 scope → §4 routes → §5 per-method → §6 findings → §2 counts
   → §1 verdict last (you only know the verdict at the end) → `02-fix-plan.md` → §15 self-check.
8. **Use the question format in `module-finalization.md` §5.6.7** if you must ask Tarun anything.
