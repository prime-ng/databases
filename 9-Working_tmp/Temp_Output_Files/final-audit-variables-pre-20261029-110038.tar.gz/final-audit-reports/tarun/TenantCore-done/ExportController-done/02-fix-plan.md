# Fix Plan — TenantCore / ExportController

**From:** `01-report.md` (2026-10-15) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/TenantCore/app/Http/Controllers/ExportController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/TenantCore/resources/views/components/export-buttons.blade.php` | shared component (common, §4.2) — its session-key and view-surface issues are cross-cutting notes, §7 of the report |
| `Modules/TenantCore/routes/web.php` | route file — no route change is needed (the endpoint and its name stay exactly as they are) |
| `database/migrations/**` | migrations are never edited or added by this plan |
| `config/permissionslist.php` | only touched if the EXP-04 DECISION is ticked with option (b), and then it is a `⚠ SHARED` edit |
| `bootstrap/app.php` | the central handler already renders a 403 for `AuthorizationException` and a safe 500 elsewhere — do not change it |

## 1. Blockers reachable today

- [x] **EXP-01** · B · ERR-01 · `Modules/TenantCore/app/Http/Controllers/ExportController.php:16-128` — replace the generic `catch (\Exception)` so no raw exception text reaches the user, a 403 stays a 403, and business-rule refusals keep their message.
  - **Touches:** `Modules/TenantCore/app/Http/Controllers/ExportController.php`
  - **Before** (`ExportController.php:16-128`):
    ```php
    public function export(Request $request)
    {

        try {
            $format = $request->input('format', 'excel');
            $tab = $request->input('tab');
            $label = $request->input('label');

            // Validate format
            $validFormats = ['excel', 'pdf', 'print'];
            if (! in_array($format, $validFormats)) {
                throw new \InvalidArgumentException('Unsupported export format: '.$format);
            }

            // Boost memory and execution time to process up to 3k records (especially for DomPDF)
            @ini_set('memory_limit', '512M');
            @set_time_limit(300);

            // Get data from session
            $identifier = (! empty($tab)) ? $tab : (! empty($label) ? $label : 'default');
            $sessionKey = 'export_data_'.md5($identifier);
            $exportData = session()->get($sessionKey);

            if (! $exportData) {
                throw new \RuntimeException('Export data not found. Please refresh the page and try again.');
            }

            // Authorize permission if specified
            if (! empty($exportData['permission'])) {
                Gate::authorize($exportData['permission']);
            }

            $data = $exportData['data'] ?? null;
            $columns = $exportData['columns'] ?? [];
            $resolvers = $exportData['resolvers'] ?? [];
            $headers = $exportData['headers'] ?? [];
            $title = $exportData['title'] ?? 'Export';
            $appliedFilters = $exportData['appliedFilters'] ?? [];

            // Global 3k (3,000) export limit across all formats (Excel, PDF, Print)
            $maxLimit = (int) ($exportData['max_limit'] ?? 3000);
            $currentCount = max($data ? $data->count() : 0, (int) ($exportData['total_records'] ?? 0), (int) ($exportData['record_count'] ?? 0));

            if (! empty($exportData['limit_exceeded']) || $currentCount > $maxLimit) {
                $count = max($currentCount, (int) ($exportData['record_count'] ?? 0));
                throw new \RuntimeException('Export limit exceeded: Current selection contains '.number_format($count).' records. Maximum allowable export limit is '.number_format($maxLimit).' records. Please apply filters to reduce the record count before exporting.');
            }

            // Filter columns based on user's custom selection from modal
            if ($request->filled('selected_columns')) {
                $selectedColumns = (array) $request->input('selected_columns');
                $columns = array_values(array_intersect($columns, $selectedColumns));
                $headers = array_intersect_key($headers, array_flip($columns));
            }

            if (empty($columns)) {
                throw new \RuntimeException('Please select at least one column to export.');
            }

            if (! $data || $data->count() === 0) {
                throw new \RuntimeException('No data available to export.');
            }

            $fileName = $this->sanitizeFileName($title);

            return $this->handleExport($format, $data, $columns, $resolvers, $headers, $title, $fileName, $appliedFilters);

        } catch (\Exception $e) {
            Log::error('Export error: '.$e->getMessage(), [
                'trace' => $e->getTraceAsString(),
                'format' => $request->input('format'),
                'user_id' => auth()->id(),
            ]);

            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage(),
                ], 422);
            }

            $safeMsg = htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');

            return response("
                <!DOCTYPE html>
                <html lang='en'>
                <head>
                    <meta charset='utf-8'>
                    <meta name='viewport' content='width=device-width, initial-scale=1'>
                    <title>Export Error</title>
                    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>
                    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>
                </head>
                <body class='bg-light d-flex align-items-center justify-content-center' style='min-height: 100vh; padding: 20px;'>
                    <div class='card shadow border-0 rounded-4' style='max-width: 520px; width: 100%;'>
                        <div class='card-body p-4 text-center'>
                            <div class='text-danger mb-3'>
                                <i class='fa-solid fa-circle-exclamation' style='font-size: 3.5rem;'></i>
                            </div>
                            <h4 class='fw-bold text-danger mb-2'>Export Not Allowed</h4>
                            <p class='text-muted fs-6 mb-4'>{$safeMsg}</p>
                            <div class='d-flex justify-content-center gap-2'>
                                <button class='btn btn-outline-secondary px-4 rounded-pill' onclick='window.close();'>
                                    <i class='fa-solid fa-xmark me-1'></i> Close Tab
                                </button>
                            </div>
                        </div>
                    </div>
                </body>
                </html>
            ", 422);
        }
    }
    ```
  - **After:**
    ```php
    public function export(Request $request)
    {
        try {
            $format = $request->input('format', 'excel');
            $tab = $request->input('tab');
            $label = $request->input('label');

            // Validate format
            $validFormats = ['excel', 'pdf', 'print'];
            if (! in_array($format, $validFormats, true)) {
                throw new \DomainException('Unsupported export format: '.$format);
            }

            // Boost memory and execution time to process up to 3k records (especially for DomPDF)
            @ini_set('memory_limit', '512M');
            @set_time_limit(300);

            // Get data from session
            $identifier = (! empty($tab)) ? $tab : (! empty($label) ? $label : 'default');
            $sessionKey = 'export_data_'.md5($identifier);
            $exportData = session()->get($sessionKey);

            if (! $exportData) {
                throw new \DomainException('Export data not found. Please refresh the page and try again.');
            }

            // Authorize permission if specified. Gate::authorize throws
            // AuthorizationException, which is NOT a \DomainException, so a 403 is
            // never swallowed by the catch below (EXP-02).
            if (! empty($exportData['permission'])) {
                Gate::authorize($exportData['permission']);
            }

            $data = $exportData['data'] ?? null;
            $columns = $exportData['columns'] ?? [];
            $resolvers = $exportData['resolvers'] ?? [];
            $headers = $exportData['headers'] ?? [];
            $title = $exportData['title'] ?? 'Export';
            $appliedFilters = $exportData['appliedFilters'] ?? [];

            // Global 3k (3,000) export limit across all formats (Excel, PDF, Print)
            $maxLimit = (int) ($exportData['max_limit'] ?? 3000);
            $currentCount = max($data ? $data->count() : 0, (int) ($exportData['total_records'] ?? 0), (int) ($exportData['record_count'] ?? 0));

            if (! empty($exportData['limit_exceeded']) || $currentCount > $maxLimit) {
                $count = max($currentCount, (int) ($exportData['record_count'] ?? 0));
                throw new \DomainException('Export limit exceeded: Current selection contains '.number_format($count).' records. Maximum allowable export limit is '.number_format($maxLimit).' records. Please apply filters to reduce the record count before exporting.');
            }

            // Filter columns based on user's custom selection from modal
            if ($request->filled('selected_columns')) {
                $selectedColumns = (array) $request->input('selected_columns');
                $columns = array_values(array_intersect($columns, $selectedColumns));
                $headers = array_intersect_key($headers, array_flip($columns));
            }

            if (empty($columns)) {
                throw new \DomainException('Please select at least one column to export.');
            }

            if (! $data || $data->count() === 0) {
                throw new \DomainException('No data available to export.');
            }

            $fileName = $this->sanitizeFileName($title);

            return $this->handleExport($format, $data, $columns, $resolvers, $headers, $title, $fileName, $appliedFilters);
        } catch (\DomainException $e) {
            // ERR-01 (2026-10-15): the ONE allowed business-rule catch (D2). The message is
            // written for the user and contains no SQL or trace, so it is shown. Every other
            // failure — AuthorizationException, QueryException, TypeError — is left to the
            // central handler in bootstrap/app.php, so a 403 stays a 403 and a 500 never
            // leaks the raw exception text.
            Log::warning('Export refused: '.$e->getMessage(), [
                'format' => $request->input('format'),
                'user_id' => auth()->id(),
            ]);

            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage(),
                ], 422);
            }

            $safeMsg = htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');

            return response("
                <!DOCTYPE html>
                <html lang='en'>
                <head>
                    <meta charset='utf-8'>
                    <meta name='viewport' content='width=device-width, initial-scale=1'>
                    <title>Export Error</title>
                    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>
                    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>
                </head>
                <body class='bg-light d-flex align-items-center justify-content-center' style='min-height: 100vh; padding: 20px;'>
                    <div class='card shadow border-0 rounded-4' style='max-width: 520px; width: 100%;'>
                        <div class='card-body p-4 text-center'>
                            <div class='text-danger mb-3'>
                                <i class='fa-solid fa-circle-exclamation' style='font-size: 3.5rem;'></i>
                            </div>
                            <h4 class='fw-bold text-danger mb-2'>Export Not Allowed</h4>
                            <p class='text-muted fs-6 mb-4'>{$safeMsg}</p>
                            <div class='d-flex justify-content-center gap-2'>
                                <button class='btn btn-outline-secondary px-4 rounded-pill' onclick='window.close();'>
                                    <i class='fa-solid fa-xmark me-1'></i> Close Tab
                                </button>
                            </div>
                        </div>
                    </div>
                </body>
                </html>
            ", 422);
        }
    }
    ```
  - **Verify:** `grep -nE "catch \(\\\\Exception|getMessage" Modules/TenantCore/app/Http/Controllers/ExportController.php`
  - **Expect:** the only `catch (` line left in the file is `} catch (\DomainException $e) {`; no `$e->getMessage()` outside that catch.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [x] **EXP-03** · M · ERR-00 · `Modules/TenantCore/app/Http/Controllers/ExportController.php:130-270` — remove the three remaining controller `catch (\Exception)` blocks (D1) and let the central handler deal with failures; also extract the duplicated PDF/Print payload and select only the columns the school header uses.
  - **Touches:** `Modules/TenantCore/app/Http/Controllers/ExportController.php`
  - **Before** (`ExportController.php:130-220`, `handleExport()`):
    ```php
    protected function handleExport($format, $data, $columns, $resolvers, $headers, $title, $fileName, array $appliedFilters = [])
    {
        $school = $this->getSchoolDetails();
        $colCount = count($columns);

        $requestedOrientation = request('orientation', 'auto');
        $requestedPaperSize = request('paper_size', 'auto');

        // Smart auto-detection if orientation is 'auto'
        if ($requestedOrientation === 'auto' || empty($requestedOrientation)) {
            $orientation = ($colCount > 6) ? 'landscape' : 'portrait';
        } else {
            $orientation = in_array(strtolower($requestedOrientation), ['landscape', 'portrait'], true) ? strtolower($requestedOrientation) : 'portrait';
        }

        // Smart auto-detection if paper size is 'auto'
        if ($requestedPaperSize === 'auto' || empty($requestedPaperSize)) {
            if ($colCount > 13) {
                $paperSize = 'a3';
            } elseif ($colCount > 9) {
                $paperSize = 'legal';
            } else {
                $paperSize = 'a4';
            }
        } else {
            $paperSize = in_array(strtolower($requestedPaperSize), ['a4', 'a3', 'legal', 'letter'], true) ? strtolower($requestedPaperSize) : 'a4';
        }

        try {
            switch ($format) {
                case 'excel':
                    return Excel::download(
                        new DataExport(
                            $data,
                            $columns,
                            $resolvers,
                            $headers,
                            $school['name'] ?? $this->getBrandName(),
                            $title,
                            $appliedFilters
                        ),
                        $fileName.'.xlsx'
                    );

                case 'pdf':
                    $pdf = Pdf::loadView('tenantcore::exports.pdf-export', [
                        'data' => $data,
                        'columns' => $columns,
                        'resolvers' => $resolvers,
                        'headers' => $headers,
                        'title' => $title,
                        'date' => now()->format('Y-m-d H:i:s'),
                        'brandName' => $school['name'] ?? $this->getBrandName(),
                        'school' => $school,
                        'appliedFilters' => $appliedFilters,
                        'colCount' => $colCount,
                        'paperSize' => $paperSize,
                        'orientation' => $orientation,
                    ]);

                    $pdf->setPaper($paperSize, $orientation);

                    return $pdf->download($fileName.'.pdf');

                case 'print':
                    return view('tenantcore::exports.print-view', [
                        'data' => $data,
                        'columns' => $columns,
                        'resolvers' => $resolvers,
                        'headers' => $headers,
                        'title' => $title,
                        'date' => now()->format('Y-m-d H:i:s'),
                        'brandName' => $school['name'] ?? $this->getBrandName(),
                        'school' => $school,
                        'appliedFilters' => $appliedFilters,
                        'colCount' => $colCount,
                        'paperSize' => $paperSize,
                        'orientation' => $orientation,
                    ]);

                default:
                    throw new \InvalidArgumentException('Unsupported export format');
            }
        } catch (\Exception $e) {
            Log::error('Export processing failed: '.$e->getMessage(), [
                'format' => $format,
                'trace' => $e->getTraceAsString(),
            ]);
            throw $e;
        }
    }
    ```
  - **After:** (`ExportController.php:130-220`, `handleExport()` + new helper):
    ```php
    protected function handleExport($format, $data, $columns, $resolvers, $headers, $title, $fileName, array $appliedFilters = [])
    {
        $school = $this->getSchoolDetails();
        $colCount = count($columns);

        $requestedOrientation = request('orientation', 'auto');
        $requestedPaperSize = request('paper_size', 'auto');

        // Smart auto-detection if orientation is 'auto'
        if ($requestedOrientation === 'auto' || empty($requestedOrientation)) {
            $orientation = ($colCount > 6) ? 'landscape' : 'portrait';
        } else {
            $orientation = in_array(strtolower($requestedOrientation), ['landscape', 'portrait'], true) ? strtolower($requestedOrientation) : 'portrait';
        }

        // Smart auto-detection if paper size is 'auto'
        if ($requestedPaperSize === 'auto' || empty($requestedPaperSize)) {
            if ($colCount > 13) {
                $paperSize = 'a3';
            } elseif ($colCount > 9) {
                $paperSize = 'legal';
            } else {
                $paperSize = 'a4';
            }
        } else {
            $paperSize = in_array(strtolower($requestedPaperSize), ['a4', 'a3', 'legal', 'letter'], true) ? strtolower($requestedPaperSize) : 'a4';
        }

        switch ($format) {
            case 'excel':
                return Excel::download(
                    new DataExport(
                        $data,
                        $columns,
                        $resolvers,
                        $headers,
                        $school['name'] ?? $this->getBrandName(),
                        $title,
                        $appliedFilters
                    ),
                    $fileName.'.xlsx'
                );

            case 'pdf':
                $pdf = Pdf::loadView('tenantcore::exports.pdf-export', $this->buildExportViewData($data, $columns, $resolvers, $headers, $title, $school, $appliedFilters, $colCount, $paperSize, $orientation));

                $pdf->setPaper($paperSize, $orientation);

                return $pdf->download($fileName.'.pdf');

            case 'print':
                return view('tenantcore::exports.print-view', $this->buildExportViewData($data, $columns, $resolvers, $headers, $title, $school, $appliedFilters, $colCount, $paperSize, $orientation));

            default:
                throw new \DomainException('Unsupported export format');
        }
    }

    protected function buildExportViewData($data, $columns, $resolvers, $headers, $title, $school, $appliedFilters, $colCount, $paperSize, $orientation): array
    {
        return [
            'data' => $data,
            'columns' => $columns,
            'resolvers' => $resolvers,
            'headers' => $headers,
            'title' => $title,
            'date' => now()->format('Y-m-d H:i:s'),
            'brandName' => $school['name'] ?? $this->getBrandName(),
            'school' => $school,
            'appliedFilters' => $appliedFilters,
            'colCount' => $colCount,
            'paperSize' => $paperSize,
            'orientation' => $orientation,
        ];
    }
    ```
  - **Before** (`ExportController.php:222-259`, `getSchoolDetails()`):
    ```php
    protected function getSchoolDetails(): array
    {
        try {
            $org = DB::table('sch_organizations')->first();
            if ($org) {
                $addressParts = array_filter([
                    $org->address_1 ?? null,
                    $org->address_2 ?? null,
                    $org->area ?? null,
                    $org->pincode ? 'PIN: '.$org->pincode : null,
                ]);

                return [
                    'name' => $org->name ?? $this->getBrandName(),
                    'code' => $org->code ?? null,
                    'affiliation_no' => $org->affiliation_no ?? null,
                    'udise_code' => $org->udise_code ?? null,
                    'address' => implode(', ', $addressParts),
                    'phone' => $org->phone_1 ?? $org->phone_2 ?? null,
                    'email' => $org->email ?? null,
                    'website' => $org->website_url ?? null,
                ];
            }
        } catch (\Exception $e) {
            Log::warning('Could not retrieve school organization details: '.$e->getMessage());
        }

        return [
            'name' => $this->getBrandName(),
            'code' => null,
            'affiliation_no' => null,
            'udise_code' => null,
            'address' => null,
            'phone' => null,
            'email' => null,
            'website' => null,
        ];
    }
    ```
  - **After:** (`ExportController.php:222-259`, `getSchoolDetails()`):
    ```php
    protected function getSchoolDetails(): array
    {
        $org = DB::table('sch_organizations')
            ->select(['name', 'code', 'affiliation_no', 'udise_code', 'address_1', 'address_2', 'area', 'pincode', 'phone_1', 'phone_2', 'email', 'website_url'])
            ->first();

        if ($org) {
            $addressParts = array_filter([
                $org->address_1 ?? null,
                $org->address_2 ?? null,
                $org->area ?? null,
                $org->pincode ? 'PIN: '.$org->pincode : null,
            ]);

            return [
                'name' => $org->name ?? $this->getBrandName(),
                'code' => $org->code ?? null,
                'affiliation_no' => $org->affiliation_no ?? null,
                'udise_code' => $org->udise_code ?? null,
                'address' => implode(', ', $addressParts),
                'phone' => $org->phone_1 ?? $org->phone_2 ?? null,
                'email' => $org->email ?? null,
                'website' => $org->website_url ?? null,
            ];
        }

        return [
            'name' => $this->getBrandName(),
            'code' => null,
            'affiliation_no' => null,
            'udise_code' => null,
            'address' => null,
            'phone' => null,
            'email' => null,
            'website' => null,
        ];
    }
    ```
  - **Before** (`ExportController.php:261-270`, `getBrandName()`):
    ```php
    protected function getBrandName()
    {
        try {
            $name = (function_exists('tenant') && tenant()) ? tenant('name') : null;

            return $name ?: config('app.name', 'Prime Gurukul');
        } catch (\Exception $e) {
            return config('app.name', 'Prime Gurukul');
        }
    }
    ```
  - **After:** (`ExportController.php:261-270`, `getBrandName()`):
    ```php
    protected function getBrandName(): string
    {
        $name = (function_exists('tenant') && tenant()) ? tenant('name') : null;

        return $name ?: config('app.name', 'Prime Gurukul');
    }
    ```
  - **Verify:** `grep -nE "catch \(" Modules/TenantCore/app/Http/Controllers/ExportController.php`
  - **Expect:** exactly one `catch (` line remains in the whole file, `} catch (\DomainException $e) {` (line ~83), and it is the one added by EXP-01.
  - **Effort:** M

## 4. Authorization (F3)

All authorization work is a DECISION — see §9, item EXP-04.

## 5. Validation, routes, models (F4/F5/F7)

All validation work is a DECISION — see §9, item EXP-05. No route or model change is needed.

## 6. Queries & performance (F9)

No standalone item — the one query finding (EXP-11) is fixed inside the EXP-03 `getSchoolDetails()` rewrite.

## 7. Views (F10)

None — both blades are clean and compile.

## 8. Style (F12) — one item per file

- [x] **EXP-12** · L · STY-01 · `ExportController.php:1` + `DataExport.php:1` — add `declare(strict_types=1);`.
  - **Touches:** `Modules/TenantCore/app/Http/Controllers/ExportController.php`, `Modules/TenantCore/app/Exports/DataExport.php`
  - **Before** (`ExportController.php:1-3`):
    ```php
    <?php

    namespace Modules\TenantCore\Http\Controllers;
    ```
  - **After:** (`ExportController.php:1-4`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\TenantCore\Http\Controllers;
    ```
  - **Before** (`DataExport.php:1-3`):
    ```php
    <?php

    namespace Modules\TenantCore\Exports;
    ```
  - **After:** (`DataExport.php:1-4`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\TenantCore\Exports;
    ```
  - **Verify:** `grep -c 'declare(strict_types=1)' Modules/TenantCore/app/Http/Controllers/ExportController.php Modules/TenantCore/app/Exports/DataExport.php`
  - **Expect:** `1` for each file.
  - **Effort:** S

- [x] **EXP-13** · L · STY-02 · `DataExport.php:46` — make the file Pint-clean.
  - **Touches:** `Modules/TenantCore/app/Exports/DataExport.php`
  - **Before** (`DataExport.php:46`):
    ```php
        $headings[] = ['Generated on: ' . now()->format('Y-m-d H:i:s')];
    ```
  - **After:**
    ```php
        $headings[] = ['Generated on: '.now()->format('Y-m-d H:i:s')];
    ```
  - **Verify:** `vendor/bin/pint --test Modules/TenantCore/app/Exports/DataExport.php; echo "exit=$?"`
  - **Expect:** no fixer list printed and `exit=0`. If Pint still lists fixers (there are eight, not just the one shown), run `vendor/bin/pint Modules/TenantCore/app/Exports/DataExport.php` and re-check.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **EXP-04** · M · DECISION · AUTH-01 — should the export endpoint be gated by a fixed permission when the session payload carries none?
  - **Why it is a decision:** it adds a permission key and changes who can export on screens whose `export-buttons` call passes no `permission` prop — a behaviour and config change. A new key must be declared in `config/permissionslist.php` (`⚠ SHARED`) and seeded by Tarun (`/system-config/sync-permissions`).
  - (a) ⭐ require a fixed endpoint permission (for example `tenant.tenant-core.export`) in addition to the session permission, and declare it per key; callers that pass nothing are then refused.
  - (b) audit every `export-buttons` call site and add a `.export` `permission` prop to the ones that pass none (no controller change; large cross-module edits).
  - (c) accept the gap: the endpoint only serves the caller’s own session data; record it as accepted and close.
  - ➜ Choice: (c) — accepted; endpoint serves the caller's own session data 2026-10-21

- [x] **EXP-05** · M · DECISION · VAL-02 — extract an `ExportRequest` for the POST?
  - **Why it is a decision:** a FormRequest changes the failure UX. A validation failure on a form that posts with `target="_blank"` would redirect back with field errors, replacing the current single error page; the endpoint’s permission is dynamic and would still be checked in the controller.
  - (a) ⭐ leave the inline whitelists as they are — every field is whitelisted server-side and none reaches a model; record as accepted.
  - (b) add `Modules/TenantCore/app/Http/Requests/ExportRequest.php` with rules for `format`, `orientation`, `paper_size`, `selected_columns`, `tab`, `label` and `authorize(): true`, and accept the redirect-based error UX.
  - (c) add the FormRequest but keep the HTML error page by overriding `failedValidation()`.
  - ➜ Choice: (a) — inline whitelists kept, accepted 2026-10-21

- [x] **EXP-06** · M · DECISION · CTL-02 — split the two over-length methods?
  - **Why it is a decision:** D3 makes a split a DEFERRED refactor, never applied during a fix pass. Extracting `resolveExportPayload()` (from `export()`) and per-format builders (from `handleExport()`) is behaviour-preserving but reshapes the controller.
  - (a) ⭐ defer to the dedicated split pass (D3); keep the EXP-01/EXP-03 rewrites only.
  - (b) extract the precondition block and the format branches now, in this pass.
  - (c) leave as is and record as accepted debt.
  - ➜ Choice: (a) — deferred to the split pass 2026-10-21

- [x] **EXP-08** · M · DECISION · CTL-05 — extract one shared value resolver used by `DataExport` and both blades?
  - **Why it is a decision:** the fix adds a new `Support` class and edits the shared component `export-buttons.blade.php` (`⚠ SHARED`), so it touches code other controllers render.
  - (a) ⭐ defer to a dedicated refactor; record the four copies in the report and fix them together later.
  - (b) create `Modules/TenantCore/Support/ExportValueResolver` now, call it from `DataExport` and the two blades, and from `export-buttons.blade.php`.
  - (c) leave as is and record as accepted debt.
  - ➜ Choice: (a) — deferred to a dedicated refactor 2026-10-21

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| EXP-02 | Fixed by the EXP-01 rewrite of the same `catch` — an `AuthorizationException` is not a `\DomainException`, so it propagates to the central handler and renders a 403. |
| EXP-07 | Extracted as part of the EXP-03 `handleExport()` rewrite (`buildExportViewData`). |
| EXP-09 | Partially applied by the EXP-03 rewrite (`getBrandName(): string`); `export()`/`handleExport()` are deferred because a single safe return type is not available (they return `View`/`Response`/`BinaryFileResponse`). |
| EXP-10 | Accepted as low — the `request()` helper works and the method is otherwise correct. |
| EXP-11 | Applied as part of the EXP-03 `getSchoolDetails()` rewrite (explicit `->select([...])`). |
