# 03 — Status · ExportController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun

Decisions taken with the user's approval (2026-10-21):
- EXP-04 → (c) accepted; the endpoint only serves the caller's own session payload.
- EXP-05 → (a) accepted; the inline server-side whitelists stay.
- EXP-06 → (a) deferred to the split pass (D3).
- EXP-08 → (a) deferred to a dedicated refactor.

## 1. Pre-applied 2026-10-10
None for this controller.

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| EXP-01 | `ExportController.php:18-129` | the generic `catch (\Exception)` became the single D2 `catch (\DomainException)`; all business-rule throws are `\DomainException`; `in_array` is strict; `Gate::authorize` documented as not-caught | `grep -nE "catch \(|getMessage" <file>` | one catch at line 87; `getMessage` only inside it (93, 101, 105) | 2026-10-21 |
| EXP-03 | `ExportController.php:130-265` | all three remaining `catch (\Exception)` blocks removed (D1); the duplicated PDF/Print payload extracted to `buildExportViewData()`; `getSchoolDetails()` selects only the columns it reads; `getBrandName(): string` with no catch | `grep -nE "catch \(" <file>` | exactly one catch (line 87) | 2026-10-21 |
| EXP-12 | `ExportController.php:3`, `DataExport.php:3` | `declare(strict_types=1)` added to both | `grep -c 'declare(strict_types=1)' <both>` | 1 each | 2026-10-21 |
| EXP-13 | `Exports/DataExport.php` | Pint-clean (spacing, casts, concat, import order, EOF) | `pint --test <file>` | passed (exit 0) | 2026-10-21 |

## 3. Not applied
- **EXP-04** (M, DECISION) — accepted; no new permission key and no `config/permissionslist.php` edit.
- **EXP-05** (M, DECISION) — accepted; no `ExportRequest`.
- **EXP-06** (M, DECISION) — deferred; `export()` stays 119 lines.
- **EXP-08** (M, DECISION) — deferred; the four value-resolver copies stay.
- **EXP-09** (partial) — `getBrandName()` is typed; `export()` / `handleExport()` return types are not added because they return `View` / `Response` / `BinaryFileResponse` (accepted in plan §10).

## 4. Needs Tarun's hand
- None to seed. If EXP-04 is ever revisited, it needs a new `tenant.tenant-core.export` key in `config/permissionslist.php` (⚠ SHARED) and `/system-config/sync-permissions`.

## 5. Unverifiable by this workflow (D4)
- The export paths (Excel/PDF/Print) were not exercised in a browser; the exception behaviour is static.
- `DB::table('sch_organizations')->select([...])` assumes the listed columns exist; they were all read by the old code, so the schema is unchanged.

## 6. Verification log
```
php -l ExportController.php                            No syntax errors
php -l DataExport.php                                  No syntax errors
class_exists(ExportController::class)                  bool(true)
class_exists(DataExport::class)                        bool(true)
grep "catch (" ExportController.php                    one — } catch (\DomainException $e) {
grep "->select(["                                      line 217 (school header columns only)
grep "function getBrandName"                           line 252 — : string
pint --test DataExport.php                             passed
route:list                                             ROUTES-OK
```

Post-fix scanner candidates still open (all known/accepted): CTL-02 (`export()` length, EXP-06), CTL-04 (no return type, EXP-09), AUTH-02 (`Gate` inside try — safe because the catch is `\DomainException` only, EXP-02), ERR-05 (`getMessage()` in the refusal log — intentional), the domain-message row (intentional D2).

## 7. Final state
Status **FIXED**. Open: EXP-04/EXP-05 (accepted), EXP-06/EXP-08 (deferred), EXP-09 (partial, accepted).
