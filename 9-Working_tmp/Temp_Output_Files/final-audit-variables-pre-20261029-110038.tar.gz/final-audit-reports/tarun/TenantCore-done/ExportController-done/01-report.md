# Final Audit — TenantCore / ExportController

**Audited:** 2026-10-15 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/TenantCore/app/Http/Controllers/ExportController.php` (279 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `POST http://test.localhost:8000/tenantcore/export` (route name `tenantcore.export`). There is no GET page — it is the form-post target of the “Export & Print Options” modal that every list screen renders. |
| Menu path | Not a menu item. The user opens it from the print icon in the search bar of any list screen that includes the `<x-tenantcore::export-buttons>` component (hundreds of screens across the estate). |
| Who uses it | Any authenticated, verified tenant user who can see the button. The controller re-checks the permission carried in the session payload (`$exportData['permission']`) only when that key is present. Measured on the tenant: **161** `.export` permissions are seeded (`sys_permissions` 5,746 rows). |
| What a user does here | On a list screen the user picks a format (Excel / PDF / Print) and the columns to include, then submits the modal form. The list controller has already staged the row data in the session in a `stdClass` collection. `export()` reads that payload and streams back an XLSX, a PDF, or a printable HTML page. The user never edits business data here. |
| Tables written | **None.** `export()` is read-only — grep for every write construct returned nothing (`grep -nE 'DB::transaction\|->insert(\|->update(\|->create(\|->delete(\|->save(\|activityLog'` → no output). |
| Tables read | `sch_organizations` (the school identity block printed in the PDF/print header). |
| Live data | Tenant measured `test.localhost` → `xyz_school_00000000000040008000_202627`: `sch_organizations` **1** row (name “Demo CBSE Senior Secondary School”, code `DEMO_CBSE_001`); `sys_permissions` **5,746** rows, of which **161** are `.export`. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Not production-ready as written. 1 blocker, 1 HIGH.** The controller’s only job is to turn a
session payload into a download, and that part works — but its error handling is written in the
old house style that the final audit has retired (D1), and that single habit causes both the
blocker and the HIGH.

The single worst finding is **EXP-01**: on any failure the endpoint prints the raw exception text
into the JSON `message` and into the red “Export Not Allowed” page, so a database or PDF error
shows the user SQL/table names and file paths. Directly behind it is **EXP-02**: `Gate::authorize`
runs *inside* the `try`, so an authorization failure is caught by the generic `catch (\Exception)`
and returned as a **422 “validation” response with the message “This action is unauthorized.”**
instead of a clean **403**.

The rest is maintainability debt: four controller `try/catch` blocks (D1), a conditional
authorization that can be bypassed when the session carries no permission (the export standard’s
“view surface only” gap), no FormRequest, two over-length methods, a value-resolution algorithm
copied in four places, and missing `strict_types`/Pint. Effort to fix the plan: **about one day**,
mostly mechanical. Four DECISION items need your call first.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 1 | 6 | 5 | 4 | 13 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | EXP-01, EXP-02, EXP-03 | F8 Services/Jobs | clean — no service, job, event or mail (`grep -nE 'Service\|dispatch(\|event(\|Job\|Mail::\|Notification'` → no output) |
| F2 Transactions/Audit | clean — read-only controller, no write path (`grep -nE 'DB::transaction\|->insert(\|->update(\|->create(\|->delete(\|->save(\|activityLog'` → no output) | F9 Queries/Perf | EXP-11 |
| F3 Authorization | EXP-04 | F10 Views | clean — both blades compile and contain no DB query or `{!! !!}` (see F10 line) |
| F4 Validation | EXP-05 | F11 Security/Tenancy | clean — no `env()` outside config, tenant middleware present, central table not touched (see F11 line) |
| F5 Routes | clean — `POST tenantcore/export` → existing method, tenant middleware present (§4) | F12 Style | EXP-12, EXP-13 |
| F6 Controller shape | EXP-06, EXP-07, EXP-08, EXP-09, EXP-10 | F13 Deep read | clean — export() writes nothing; all eight questions answered in §6 |
| F7 Models | n/a — no model in scope | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TenantCore/app/Http/Controllers/ExportController.php` | controller | 279 | this report | ✅ whole class |
| 2 | `Modules/TenantCore/app/Exports/DataExport.php` | export class (Maatwebsite Excel) | 104 | this report — **not owned elsewhere** | ✅ whole class |
| 3 | `Modules/TenantCore/resources/views/exports/pdf-export.blade.php` | blade (DomPDF) | 217 | this report | ✅ whole file |
| 4 | `Modules/TenantCore/resources/views/exports/print-view.blade.php` | blade (print) | 130 | this report | ✅ whole file |
| 5 | `Modules/TenantCore/routes/web.php:6` | route | 1 | this report | ✅ |
| 6 | `Modules/TenantCore/app/Providers/RouteServiceProvider.php` | provider (middleware group) | 76 | common — module glue (§4.2) | referenced for F5 only |
| — | `Modules/TenantCore/resources/views/components/export-buttons.blade.php` (`x-tenantcore::export-buttons`) | shared component, reaches every list screen | 734 | common (§4.2) | props/usage checked only — §7 note |

§5 ownership check: `grep -F 'Modules/TenantCore/Exports/DataExport.php' final-audit-reports/00-CLASS-OWNERS.md`
(and the `pdf-export` / `print-view` names) → **no output** for every probe — none of the in-scope
files is owned by another report.

No pre-applied files: `Modules/TenantCore/` does not appear in any `PRE-APPLIED-*.md`.

## 4. Routes

```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true);
           foreach($r as $x){ if(str_contains($x["action"],"ExportController@")){ printf("%-7s %-55s %-20s %s\n",$x["method"],$x["uri"],$x["name"],$x["action"]); } }'
POST    tenantcore/export                                     tenantcore.export    Modules\TenantCore\Http\Controllers\ExportController@export
```

Middleware on the route (uncached `route:list --json`):

```
web, Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,
Stancl\Tenancy\Middleware\InitializeTenancyByDomain, App\Http\Middleware\SetTenantAuthGuard,
App\Http\Middleware\EnsureTenantIsActive, Illuminate\Auth\Middleware\Authenticate,
Illuminate\Auth\Middleware\EnsureEmailIsVerified
```

Tenant middleware is present (RTE-05 satisfied). The route is a POST (no state change over GET).
The route action resolves to `export()`, which exists. Registered in
`Modules/TenantCore/routes/web.php:6`, prefixed `tenantcore` and name-prefixed `tenantcore.` by
`RouteServiceProvider::mapWebRoutes()`.

**Unrouted public methods:** none. The only public method is `export` (routed). `handleExport`,
`getSchoolDetails`, `getBrandName` and `sanitizeFileName` are `protected` helpers and all four are
called; there is no dead code (CTL-10 clean).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `export` | 16 | POST tenantcore/export | `$exportData['permission']` — **conditional, dynamic** | none (read-only) | — | none | EXP-01, EXP-02, EXP-03, EXP-04, EXP-05, EXP-06, EXP-09 |
| `handleExport` | 130 | via `export()` | — | none | — | none | EXP-03, EXP-06, EXP-07, EXP-10 |
| `getSchoolDetails` | 222 | helper | — | none | — | reads `sch_organizations` | EXP-03, EXP-11 |
| `getBrandName` | 261 | helper | — | none | — | none | EXP-03, EXP-04, EXP-09 |
| `sanitizeFileName` | 272 | helper | — | none | — | none | EXP-09 |

## 6. Findings

### F1 — Errors

#### EXP-01 · B · ERR-01 — the export error handler sends the raw exception text to the user

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user: no `$e->getMessage()` in `withErrors`, flash, `response()->json`, or an error page.* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ExportController.php:83-94`, method `export()` |
| **Root cause** | A single generic `catch (\Exception $e)` builds both the JSON `message` field (line 93) and the HTML error paragraph (line 97 via `$safeMsg`) from `$e->getMessage()`. Because the catch is `\Exception`-wide, any failure — a `QueryException` from `sch_organizations`, a DomPDF error, a filesystem error — is stringified straight into the response. |
| **Consequence** | A user (or anyone they are screen-sharing with) sees raw SQL, table/column names, class names and file paths whenever an export fails. |
| **Reproduce** | On any screen, open the Export modal and submit with a `tab` whose session payload has expired: `POST /tenantcore/export` with `tab=<expired>`. Expected: a generic “please refresh” message; actual: the red page prints the exception text verbatim. |
| **Fix approach** | Catch `\DomainException` only (the D2 business-rule catch); show only the business message; let every other exception reach the central handler in `bootstrap/app.php`. |
| **Plan item** | EXP-01 in `02-fix-plan.md` §1 |

```php
// ExportController.php:83-94 — CURRENT
        } catch (\Exception $e) {
            Log::error('Export error: '.$e->getMessage(), [
                'trace' => $e->getTraceAsString(),
                'format' => $request->input('format'),
                'user_id' => auth()->id(),
            ]);

            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage(),
                ], 422);
            }
```

**Evidence**
```
$ grep -n "getMessage" Modules/TenantCore/app/Http/Controllers/ExportController.php
84:            Log::error('Export error: '.$e->getMessage(), [
93:                    'message' => $e->getMessage(),
97:            $safeMsg = htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
214:            Log::error('Export processing failed: '.$e->getMessage(), [
246:            Log::warning('Could not retrieve school organization details: '.$e->getMessage());
```

#### EXP-02 · H · ERR-02 — an authorization failure is returned as a 422 “validation” error, not a 403

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500 (here, into a 422).* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ExportController.php:43-46` (the `Gate::authorize` call) with the catch at line 83 |
| **Root cause** | `Gate::authorize($exportData['permission'])` throws `Illuminate\Auth\Access\AuthorizationException`, which extends `\Exception`. It is called inside the `try`, so the generic `catch (\Exception $e)` at line 83 catches it and returns HTTP **422** with the message “This action is unauthorized.” The central handler in `bootstrap/app.php:100-113` deliberately preserves a real 403 for `AuthorizationException`, but the exception never reaches it. |
| **Consequence** | A user without the export permission gets a 422 that the front end treats as a validation error, not a 403; the failure is also logged as an export error and the status code is wrong for any API consumer. |
| **Reproduce** | Log in as a role without the screen’s `.export` permission, stage a payload, and `POST /tenantcore/export`: expected 403 “This action is unauthorized.”; actual 422 with the same text. |
| **Fix approach** | Restrict the catch to `\DomainException` (EXP-01). `AuthorizationException` is not a `\DomainException`, so it will propagate to the central handler and render a 403. |
| **Plan item** | none — fixed by the EXP-01 rewrite (same `catch`); recorded in `02-fix-plan.md` §10 |

```php
// ExportController.php:43-46 — the Gate runs inside the try that line 83 catches
            // Authorize permission if specified
            if (! empty($exportData['permission'])) {
                Gate::authorize($exportData['permission']);
            }
```

**Evidence**
```
$ grep -nE "Gate::authorize|catch \(" Modules/TenantCore/app/Http/Controllers/ExportController.php
45:                Gate::authorize($exportData['permission']);
83:        } catch (\Exception $e) {
213:        } catch (\Exception $e) {
245:        } catch (\Exception $e) {
267:        } catch (\Exception $e) {
```

#### EXP-03 · M · ERR-00 — the controller catches and handles exceptions itself (D1)

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M) — *D1: no `try/catch` in a controller; `DB::transaction` rolls back and the central handler in `bootstrap/app.php` logs and renders. A controller catch is a finding unless it is a D2 shape.* No D2 shape applies here (no truncate-rebuild, no `\DomainException` business catch, no `SnapshotProtectionException`). |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ExportController.php:158-219` (`handleExport`), `:224-247` (`getSchoolDetails`), `:263-269` (`getBrandName`) — plus `export()` at `:19-128`, handled by EXP-01 |
| **Root cause** | Four `catch (\Exception $e)` blocks exist because the old house rule (A1) required them. `handleExport`’s catch only logs and rethrows (dead code); `getSchoolDetails`’ and `getBrandName`’s catches swallow the error, and `getSchoolDetails` logs `$e->getMessage()` without the exception object (ERR-05) and then continues with a fallback as if nothing failed (ERR-06). Read-only helpers need no catch at all (ERR-07). |
| **Consequence** | A genuine DB failure during an export is either silently masked (school header falls back to the tenant name, no trace in the log) or logged as a bare string with no class/file/line, which makes production triage slow. |
| **Reproduce** | Static only — the catches are visible in source; a real `sch_organizations` failure cannot be forced from the browser without breaking the DB. |
| **Fix approach** | Remove the three helper catches; let failures reach the central handler (which logs the class/file/line and renders a safe 500). `handleExport`’s rethrow-catch is simply deleted. |
| **Plan item** | EXP-03 in `02-fix-plan.md` §3 |

```php
// ExportController.php:263-269 — getBrandName(), CURRENT
        try {
            $name = (function_exists('tenant') && tenant()) ? tenant('name') : null;

            return $name ?: config('app.name', 'Prime Gurukul');
        } catch (\Exception $e) {
            return config('app.name', 'Prime Gurukul');
        }
```

**Evidence**
```
$ grep -nE "catch \(" Modules/TenantCore/app/Http/Controllers/ExportController.php
83:        } catch (\Exception $e) {
213:        } catch (\Exception $e) {
245:        } catch (\Exception $e) {
267:        } catch (\Exception $e) {
```

### F2 — Transactions and audit

clean — `grep -nE 'DB::transaction|->insert\(|->update\(|->create\(|->delete\(|->save\(|activityLog' Modules/TenantCore/app/Http/Controllers/ExportController.php` → no output. `export()` only reads the session and the `sch_organizations` row; there is no write path to guard. No `activityLog` is required.

### F3 — Authorization

#### EXP-04 · M · AUTH-01 — export is authorized only when the session payload happens to carry a permission

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (M, lowered from B) — *every routed method authorizes.* Lowered because the endpoint can only serve the caller’s own session payload, staged by a screen the caller can already open, so no cross-user or cross-tenant data is exposed; it is a standards/consistency gap, not a data leak. |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ExportController.php:44-46`, method `export()` |
| **Root cause** | Authorization is `if (! empty($exportData['permission'])) { Gate::authorize(...); }`. The permission is data written into the session by the shared `export-buttons` component. When a caller passes no `permission` prop, the component still stages the payload (its own check at `export-buttons.blade.php:304` is `if ($permission && ...)`, skipped when null), and this endpoint then performs **no** authorization check at all. The export standard (`export-component-standard.md` §11.3) names exactly this: the gate is “view surface only”, so the correct prop hides the button but leaves the endpoint open to anyone who knows the URL. |
| **Consequence** | A user who can only *view* a paginated list can pull the same screen’s full staged dataset into Excel/PDF. No data they could not already see crosses a boundary, but the `.export` ability is not enforced for callers that omit the prop. |
| **Reproduce** | On a screen whose export component has no `permission` prop, open the modal and export — the request succeeds with no `Gate::authorize` call. |
| **Fix approach** | Decide a fixed endpoint permission (for example `tenant.tenant-core.export`) and require it unconditionally, keeping the session permission as an additional check. A new permission key is a DECISION item. |
| **Plan item** | EXP-04 in `02-fix-plan.md` §9 (DECISION) |

```php
// ExportController.php:44-46 — CURRENT
            // Authorize permission if specified
            if (! empty($exportData['permission'])) {
                Gate::authorize($exportData['permission']);
            }
```

**Evidence**
```
$ grep -n "Gate::" Modules/TenantCore/app/Http/Controllers/ExportController.php
45:                Gate::authorize($exportData['permission']);
```

### F4 — Validation and input

#### EXP-05 · M · DECISION · VAL-02 — the POST has no FormRequest; input is validated inline

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a FormRequest, not inline in the controller (except a one-field AJAX toggle).* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ExportController.php:20-25` and `:135-136`, methods `export()` / `handleExport()` |
| **Root cause** | The endpoint reads `format`, `tab`, `label`, `selected_columns`, `orientation` and `paper_size` directly from the request and validates them with hand-written whitelists (`$validFormats`, `in_array(...)`), not a FormRequest. No field is unsafe — `tab`/`label` only feed `md5()` for the session key, and `selected_columns` is intersected against the known column list — so there is no unvalidated-write risk (VAL-01 does not apply). |
| **Consequence** | The rules live in the controller instead of one testable place, and a future field could be added without whitelisting. |
| **Reproduce** | Static only — reading the request is all that happens; no model is written. |
| **Fix approach** | DECISION: extracting an `ExportRequest` centralises the rules but changes the failure UX (a validation failure on a `target="_blank"` download form would redirect back with errors instead of showing the current error page), so it needs your call. |
| **Plan item** | EXP-05 in `02-fix-plan.md` §9 (DECISION) |

```php
// ExportController.php:20-25 — CURRENT inline input handling
            $format = $request->input('format', 'excel');
            $tab = $request->input('tab');
            $label = $request->input('label');

            // Validate format
            $validFormats = ['excel', 'pdf', 'print'];
            if (! in_array($format, $validFormats)) {
```

**Evidence**
```
$ sed -n '20,28p' Modules/TenantCore/app/Http/Controllers/ExportController.php
            $format = $request->input('format', 'excel');
            $tab = $request->input('tab');
            $label = $request->input('label');

            // Validate format
            $validFormats = ['excel', 'pdf', 'print'];
            if (! in_array($format, $validFormats)) {
                throw new \InvalidArgumentException('Unsupported export format: '.$format);
            }
```

### F5 — Routes

clean — the uncached route list (§4) shows `POST tenantcore/export` resolving to
`ExportController@export`, which exists; the tenant middleware group is present; no state changes
over GET; there are no unrouted public methods.

### F6 — Controller shape

#### EXP-06 · M · CTL-02 — two methods exceed 80 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method length: over 80 lines extract; over 150 is H.* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ExportController.php:16-128` (`export`, 113 lines) and `:130-220` (`handleExport`, 91 lines) |
| **Root cause** | All precondition checks, session reads, limit math and the three format branches sit in two long methods with no extraction. |
| **Consequence** | Hard to review and to test by eye; a change to one concern risks the others. No user-visible failure on its own. |
| **Reproduce** | Static only — measured with `awk`, see evidence. |
| **Fix approach** | DECISION: extracting the precondition block (a `resolveExportPayload()` method) and the per-format branches is a behaviour-preserving refactor; per D3 a split is DEFERRED, so it needs your call. |
| **Plan item** | EXP-06 in `02-fix-plan.md` §9 (DECISION) |

```php
// ExportController.php:16-20 — CURRENT (method opener)
    public function export(Request $request)
    {

        try {
            $format = $request->input('format', 'excel');
```

**Evidence**
```
$ php -r '$s=file("Modules/TenantCore/app/Http/Controllers/ExportController.php"); foreach([[16,128,"export"],[130,220,"handleExport"]] as $r){ printf("%s: %d lines (%d-%d)\n",$r[2],$r[1]-$r[0]+1,$r[0],$r[1]); }'
export: 113 lines (16-128)
handleExport: 91 lines (130-220)
```

#### EXP-07 · M · CTL-05 — the twelve-key view payload is written out twice

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same payload repeated for two branches.* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ExportController.php:175-188` and `:195-208`, method `handleExport()` |
| **Root cause** | The `pdf` and `print` cases build the identical 12-key array (`data`, `columns`, `resolvers`, `headers`, `title`, `date`, `brandName`, `school`, `appliedFilters`, `colCount`, `paperSize`, `orientation`) for `Pdf::loadView(...)` and `view(...)`. |
| **Consequence** | A new key must be added in two places; missing one makes the PDF and the print view disagree. Maintainability only. |
| **Reproduce** | Static only — the two arrays are visible at lines 175 and 195. |
| **Fix approach** | Extract one private `buildExportViewData()` used by both branches (applied inside the EXP-03 rewrite of `handleExport`). |
| **Plan item** | none — extracted as part of the EXP-03 `handleExport()` rewrite; recorded in `02-fix-plan.md` §10 |

```php
// ExportController.php:175-188 — CURRENT (the pdf array; the print array at 195-208 is identical)
                    $pdf = Pdf::loadView('tenantcore::exports.pdf-export', [
                        'data' => $data,
                        'columns' => $columns,
                        'resolvers' => $resolvers,
                        'headers' => $headers,
                        'title' => $title,
                        'date' => now()->format('Y-m-d H:i:s'),
                        'brandName' => $school['name'] ?? $this->getBrandName(),
                        'school' => $school,
                        'appliedFilters' => $appliedFilters,
                        'colCount' => $colCount,
                        'paperSize' => $paperSize,
                        'orientation' => $orientation,
                    ]);
```

**Evidence**
```
$ sed -n '195,208p' Modules/TenantCore/app/Http/Controllers/ExportController.php
                    return view('tenantcore::exports.print-view', [
                        'data' => $data,
                        'columns' => $columns,
                        'resolvers' => $resolvers,
                        'headers' => $headers,
                        'title' => $title,
                        'date' => now()->format('Y-m-d H:i:s'),
                        'brandName' => $school['name'] ?? $this->getBrandName(),
                        'school' => $school,
                        'appliedFilters' => $appliedFilters,
                        'colCount' => $colCount,
                        'paperSize' => $paperSize,
                        'orientation' => $orientation,
                    ]);
```

#### EXP-08 · M · CTL-05 — the value-resolution algorithm is copied four times

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: one algorithm implemented repeatedly will drift.* |
| **Where** | `Modules/TenantCore/app/Exports/DataExport.php:75-104` (`resolveValue`), `Modules/TenantCore/resources/views/exports/pdf-export.blade.php:174-196`, `Modules/TenantCore/resources/views/exports/print-view.blade.php:87-109`, and the shared component `export-buttons.blade.php:338-357` |
| **Root cause** | The same relation/`options`/`boolean`/`date` resolution ladder exists in four places. Two copies are in this controller’s own blades, one in `DataExport`, one in the shared component. |
| **Consequence** | A fix to one copy (for example, a new `date` format or a JSON column) silently leaves the other three behind, so Excel, PDF and Print can render the same field differently. Maintainability only. |
| **Reproduce** | Static only — see the evidence markers at four locations. |
| **Fix approach** | DECISION: extract one shared resolver (for example `Modules/TenantCore/Support/ExportValueResolver`) and call it from `DataExport` and both blades. This touches the shared component, so it is a deferred refactor needing your call. |
| **Plan item** | EXP-08 in `02-fix-plan.md` §9 (DECISION) |

```php
// DataExport.php:79-96 — CURRENT (one of the four copies)
        $val = isset($this->resolvers[$column]['relation'])
            ? data_get($row, $this->resolvers[$column]['relation'], ($row->$column ?? ''))
            : ($row->$column ?? '');

        if (isset($this->resolvers[$column]['options']) && is_array($this->resolvers[$column]['options'])) {
            return $this->resolvers[$column]['options'][$val] ?? $val;
        }

        if (isset($this->resolvers[$column]['boolean']) && $this->resolvers[$column]['boolean']) {
            $boolConfig = $this->resolvers[$column]['boolean'];
            $isTrue = !empty($val) && $val != '0' && $val !== false;
            if (is_array($boolConfig) && count($boolConfig) === 2) {
                return $isTrue ? $boolConfig[0] : $boolConfig[1];
            }
            if ($column === 'is_active' || $boolConfig === 'status') {
                return $isTrue ? 'Active' : 'Inactive';
            }
            return $isTrue ? 'Yes' : 'No';
        }
```

**Evidence**
```
$ grep -n "property_exists\|data_get\|boolConfig\|CarbonInterface" Modules/TenantCore/app/Exports/DataExport.php Modules/TenantCore/resources/views/exports/pdf-export.blade.php Modules/TenantCore/resources/views/exports/print-view.blade.php
Modules/TenantCore/app/Exports/DataExport.php:75:        if (is_object($row) && !($row instanceof \Illuminate\Database\Eloquent\Model) && property_exists($row, $column)) {
Modules/TenantCore/app/Exports/DataExport.php:80:            ? data_get($row, $this->resolvers[$column]['relation'], ($row->$column ?? ''))
Modules/TenantCore/app/Exports/DataExport.php:88:            $boolConfig = $this->resolvers[$column]['boolean'];
Modules/TenantCore/app/Exports/DataExport.php:90:            if (is_array($boolConfig) && count($boolConfig) === 2) {
Modules/TenantCore/app/Exports/DataExport.php:91:                return $isTrue ? $boolConfig[0] : $boolConfig[1];
Modules/TenantCore/app/Exports/DataExport.php:93:            if ($column === 'is_active' || $boolConfig === 'status') {
Modules/TenantCore/app/Exports/DataExport.php:100:            return $val instanceof \Carbon\CarbonInterface ? $val->format('Y-m-d') : ($val ? (string)$val : '');
Modules/TenantCore/resources/views/exports/pdf-export.blade.php:174:                            if (is_object($row) && !($row instanceof \Illuminate\Database\Eloquent\Model) && property_exists($row, $column)) {
Modules/TenantCore/resources/views/exports/pdf-export.blade.php:178:                                    ? data_get($row, $resolvers[$column]['relation'], ($row->$column ?? ''))
Modules/TenantCore/resources/views/exports/print-view.blade.php:87:                            if (is_object($row) && !($row instanceof \Illuminate\Database\Eloquent\Model) && property_exists($row, $column)) {
Modules/TenantCore/resources/views/exports/print-view.blade.php:91:                                    ? data_get($row, $resolvers[$column]['relation'], ($row->$column ?? ''))
```

#### EXP-09 · L · CTL-04 — the public/helper methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods.* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ExportController.php:16` (`export`), `:130` (`handleExport`), `:261` (`getBrandName`), `:272` (`sanitizeFileName`) |
| **Root cause** | None of the four methods declares a return type. `getSchoolDetails` is the only one that does (`: array`). |
| **Consequence** | The IDE and static analysis cannot check the callers’ expectations. Cosmetic. |
| **Reproduce** | Static only — grep for return types on the four methods. |
| **Fix approach** | Add `: string` to `getBrandName()` and `sanitizeFileName(string $fileName): string` (partly done by the EXP-03 rewrite of `getBrandName`). `export()` and `handleExport()` return a union of `View`/`Response`/`BinaryFileResponse`, so a single safe annotation is not available — deferred. |
| **Plan item** | none — partially applied by the EXP-03 rewrite (`getBrandName`); the file-returning methods are deferred; recorded in `02-fix-plan.md` §10 |

```php
// ExportController.php:16 — CURRENT, no return type
    public function export(Request $request)
```

**Evidence**
```
$ grep -nE "public function|protected function" Modules/TenantCore/app/Http/Controllers/ExportController.php
16:    public function export(Request $request)
130:    protected function handleExport($format, $data, $columns, $resolvers, $headers, $title, $fileName, array $appliedFilters = [])
222:    protected function getSchoolDetails(): array
261:    protected function getBrandName()
272:    protected function sanitizeFileName($fileName)
```

#### EXP-10 · L · CTL-08 — the `request()` helper is called inside a controller method

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don’t call the `request()` helper inside controller methods.* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ExportController.php:135-136`, method `handleExport()` |
| **Root cause** | `handleExport()` has no injected `Request` and reaches for the global `request()` helper to read `orientation` and `paper_size`. |
| **Consequence** | Hidden dependency; makes the method untestable without booting the request. Cosmetic. |
| **Reproduce** | Static only. |
| **Fix approach** | Left as is (low value) or pass the two values from `export()` when `handleExport` is next refactored. |
| **Plan item** | none — accepted as low; recorded in `02-fix-plan.md` §10 |

```php
// ExportController.php:135-136 — CURRENT
        $requestedOrientation = request('orientation', 'auto');
        $requestedPaperSize = request('paper_size', 'auto');
```

**Evidence**
```
$ grep -n "request(" Modules/TenantCore/app/Http/Controllers/ExportController.php
135:        $requestedOrientation = request('orientation', 'auto');
136:        $requestedPaperSize = request('paper_size', 'auto');
```

### F7 — Models

n/a — no model is in scope. `DataExport` is a Maatwebsite export class, not an Eloquent model, and the controller touches `sch_organizations` only through the query builder.

### F8 — Services and jobs

clean — `grep -nE 'Service|dispatch\(|event\(|Job|Mail::|Notification' Modules/TenantCore/app/Http/Controllers/ExportController.php` → no output. The controller calls no service or job; the only external collaborators are `Excel`, `Pdf` and `DataExport`.

### F9 — Queries and performance

#### EXP-11 · L · QRY-03 — the school row is read with every column

| Field | Value |
|---|---|
| **Rule** | QRY-03 (L, lowered from M) — *select only the columns you use.* Lowered because `sch_organizations` holds a single row (measured live: 1), so there is no measurable cost; this is hygiene only. |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ExportController.php:225`, method `getSchoolDetails()` |
| **Root cause** | `DB::table('sch_organizations')->first()` selects `*`; the method uses only 12 of the table’s ~30 columns. |
| **Consequence** | None visible — one row. Recorded for the same rule the rest of the app follows. |
| **Reproduce** | Static only. |
| **Fix approach** | Add an explicit `->select([...])` for the 12 columns used (applied inside the EXP-03 rewrite of `getSchoolDetails`). |
| **Plan item** | none — applied as part of the EXP-03 `getSchoolDetails()` rewrite; recorded in `02-fix-plan.md` §10 |

```php
// ExportController.php:225 — CURRENT
            $org = DB::table('sch_organizations')->first();
```

**Evidence**
```
$ grep -n "sch_organizations" Modules/TenantCore/app/Http/Controllers/ExportController.php
225:            $org = DB::table('sch_organizations')->first();
```

### F10 — Views

clean — both blades compile and emit no stray directive. Both contain no `DB::`/`Model::` query
and no `{!! !!}`; the only `->count()` (`print-view.blade.php:123`) is a Collection method, not a
query. `{{ $val }}` is escaped. There is no `{{ $model->relation }}` JSON dump — the payload in the
session is already a collection of `stdClass` rows.

```
$ php -r '...'  # compileString both blades, then php -l on the compiled output
Modules/TenantCore/resources/views/exports/pdf-export.blade.php => No syntax errors detected | push(0) startPush(0)
Modules/TenantCore/resources/views/exports/print-view.blade.php => No syntax errors detected | push(0) startPush(0)
```

### F11 — Security and tenancy

clean — `grep -nE '\benv\('` on the controller, `DataExport` and both blades → no output (SEC-01).
`sch_organizations` is a **tenant** table (`database/migrations/tenant/2026_06_16_152548_create_sch_organizations_table.php`),
so reaching it from tenant context is correct — no `tenancy()->central()` is needed (TEN-03 clean).
No hard-coded ids, no secrets logged, no personal data dumped. The error page links hosted CDN
stylesheets only (no data leak). The one authorization gap is reported under F3 (EXP-04).

### F12 — Style

#### EXP-12 · L · STY-01 — `declare(strict_types=1)` is missing

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files.* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ExportController.php:1` and `Modules/TenantCore/app/Exports/DataExport.php:1` |
| **Root cause** | Neither file declares strict types. |
| **Consequence** | Loose typing on the export helpers. Cosmetic. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` after `<?php` in both files. |
| **Plan item** | EXP-12 in `02-fix-plan.md` §8 |

```php
// ExportController.php:1-3 — CURRENT
<?php

namespace Modules\TenantCore\Http\Controllers;
```

**Evidence**
```
$ grep -c 'declare(strict_types=1)' Modules/TenantCore/app/Http/Controllers/ExportController.php Modules/TenantCore/app/Exports/DataExport.php
Modules/TenantCore/app/Http/Controllers/ExportController.php:0
Modules/TenantCore/app/Exports/DataExport.php:0
```

#### EXP-13 · L · STY-02 — `DataExport.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset).* |
| **Where** | `Modules/TenantCore/app/Exports/DataExport.php:46` (and others) |
| **Root cause** | Pint reports eight fixers pending: `class_attributes_separation`, `fully_qualified_strict_types`, `concat_space`, `cast_spaces`, `not_operator_with_successor_space`, `blank_line_before_statement`, `ordered_imports`, `single_blank_line_at_eof`. |
| **Consequence** | Inconsistent formatting; a later `pint --dirty` run will reformat it anyway. Cosmetic. |
| **Reproduce** | Run Pint in test mode, see evidence. |
| **Fix approach** | Run Pint on the file (fixes only `DataExport.php`). |
| **Plan item** | EXP-13 in `02-fix-plan.md` §8 |

```php
// DataExport.php:46 — CURRENT (one of the concat-space hits)
        $headings[] = ['Generated on: ' . now()->format('Y-m-d H:i:s')];
```

**Evidence**
```
$ vendor/bin/pint --test Modules/TenantCore/app/Http/Controllers/ExportController.php Modules/TenantCore/app/Exports/DataExport.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/TenantCore\/app\/Exports\/DataExport.php","fixers":["class_attributes_separation","fully_qualified_strict_types","concat_space","cast_spaces","not_operator_with_successor_space","blank_line_before_statement","ordered_imports","single_blank_line_at_eof"]}]}
```
(`ExportController.php` passed — it is not listed.)

### F13 — Deep read (answer all 8 questions for every mutating method)

There are **no mutating methods** in scope — `export()` and its helpers only read. The eight
questions, applied to the one method for completeness:

| Method | 1. Overwrite? | 2. Delete-before-store? | 3. Duplicate impl? | 4. Soft-delete × unique? | 5. Race? | 6. Auth hole? | 7. Lying message? | 8. Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `export` | ok — no writes | ok — no deletes | EXP-07, EXP-08 | ok — no unique index touched | ok — no check-then-act | EXP-04 | ok — the “Export Not Allowed” title is generic and true | ok — every branch is reachable |

Note (not a finding in this report): the session key is `export_data_` . `md5($identifier)` where
`$identifier` is the `tab`/`label` string. Two screens that use the same `tab` value would collide
on one session slot. This is written by the shared component
(`export-buttons.blade.php:320,362`); callers are already warned in-source
(`Modules/HrStaff/resources/views/pages/partials/appraisals/_appraisal-cycles.blade.php:9-11`). See §7.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/TenantCore/resources/views/components/export-buttons.blade.php` (`x-tenantcore::export-buttons`, common) | Its session key is derived from the caller’s `tab`/`label`; two screens sharing a tab value overwrite each other’s export payload. | F13 wrong-data | the owner of the shared export component |
| `export-buttons.blade.php:384-389` | Broad `catch (\Exception $e)` that logs `getMessage()` and returns silently (a common-class ERR-01/ERR-05 instance). | ERR-01/ERR-05 | the owner of the shared export component |
| `export-buttons.blade.php:304` | The export permission is enforced at the **view surface only** (`Gate::check` before staging); the endpoint’s own gate is conditional (EXP-04). | AUTH-01 | the owner of the shared export component + Tarun (see EXP-04 decision) |

## 8. Not covered, and why

- **The shared `export-buttons` component was not audited** — §4.2 classifies `Modules/TenantCore/**`
  shared export/import UI as common when it is reached from a controller outside its own module. Its
  usage *by this controller* (the session payload contract) is covered; its internals are not.
- **PDF/XLSX rendering was not executed** — D4 forbids tests, and generating a real file needs a
  staged session and a live tenant request. The two blades were compile-checked instead (§F10).
- **The `route:list` action was not invoked in a browser** — the audit is static plus route/config
  inspection; no HTTP request was made.
- **Permission seeding was sampled, not enumerated** — `sys_permissions` has 5,746 rows, 161 of them
  `.export`; the exact per-screen names live with each calling controller’s own report, not here.
