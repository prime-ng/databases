# Fix Plan — TenantCore / TenantCoreController

**From:** `01-report.md` (2026-10-15) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/TenantCore/app/Http/Controllers/TenantCoreController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/TenantCore/routes/web.php` | shared route file; routing this scaffold (or deleting it) is a product decision, not a D5 fix |
| `Modules/TenantCore/routes/api.php` | shared route file; its comment only records that the `apiResource` was removed — leave the record intact |
| `Modules/TenantCore/resources/views/index.blade.php` | only consumer is this unrouted controller; kept as-is |

## 1. Blockers reachable today

## 2. Fixes that arm a latent defect (sequenced)

## 3. Errors & transactions (F1/F2)

## 4. Authorization (F3)

## 5. Validation, routes, models (F4/F5/F7)

- [x] **TCC-01** · M · RTE-03 · `Modules/TenantCore/app/Http/Controllers/TenantCoreController.php:1-56` — D5: the whole scaffold controller is unrouted; replace every method body with `abort(403, 'Not routed.')` under a `NOT ROUTED` docblock, add `: never` return types (resolves TCC-02), drop the three dead `view()` calls to views that do not exist (resolves TCC-03), and add `declare(strict_types=1);` plus cleaned docblocks (resolves TCC-04). Keep every method signature so nothing is deleted.
  - **Touches:** `Modules/TenantCore/app/Http/Controllers/TenantCoreController.php`
  - **Before** (`TenantCoreController.php:1-56`):
    ```php
    <?php

    namespace Modules\TenantCore\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;

    class TenantCoreController extends Controller
    {
        /**
         * Display a listing of the resource.
         */
        public function index()
        {
            return view('tenantcore::index');
        }

        /**
         * Show the form for creating a new resource.
         */
        public function create()
        {
            return view('tenantcore::create');
        }

        /**
         * Store a newly created resource in storage.
         */
        public function store(Request $request) {}

        /**
         * Show the specified resource.
         */
        public function show($id)
        {
            return view('tenantcore::show');
        }

        /**
         * Show the form for editing the specified resource.
         */
        public function edit($id)
        {
            return view('tenantcore::edit');
        }

        /**
         * Update the specified resource in storage.
         */
        public function update(Request $request, $id) {}

        /**
         * Remove the specified resource from storage.
         */
        public function destroy($id) {}
    }
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\TenantCore\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;

    class TenantCoreController extends Controller
    {
        /**
         * NOT ROUTED — no route points at this controller (verified 2026-10-15;
         * final-audit TCC-01, D5). Kept, not deleted.
         */
        public function index(): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (TCC-01, D5).
         */
        public function create(): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (TCC-01, D5).
         */
        public function store(Request $request): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (TCC-01, D5).
         */
        public function show($id): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (TCC-01, D5).
         */
        public function edit($id): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (TCC-01, D5).
         */
        public function update(Request $request, $id): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (TCC-01, D5).
         */
        public function destroy($id): never
        {
            abort(403, 'Not routed.');
        }
    }
    ```
  - **Verify:** `grep -c "NOT ROUTED" Modules/TenantCore/app/Http/Controllers/TenantCoreController.php`
  - **Expect:** `7` (one docblock per method), then `php -l` on the file reports no syntax errors, then `vendor/bin/pint Modules/TenantCore/app/Http/Controllers/TenantCoreController.php --format agent` reformats nothing.
  - **Effort:** S

## 6. Queries & performance (F9)

## 7. Views (F10)

## 8. Style (F12) — one item per file

## 9. Deferred / decisions

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TCC-02 | Missing return types: no separate item because the TCC-01 rewrite declares `: never` on every method — the accurate contract for a method that always throws. |
| TCC-03 | `create`/`show`/`edit` reference views that do not exist, and the write methods are empty stubs: no separate item because the single TCC-01 rewrite removes all three `view()` calls and replaces every empty body with `abort(403, 'Not routed.')` in one paste-ready file replacement. The `tenantcore::index` placeholder blade is left untouched. |
| TCC-04 | Missing `strict_types` and scaffold docblocks: no separate item because the TCC-01 rewrite adds `declare(strict_types=1);` and replaces every copy-pasted docblock with a `NOT ROUTED (TCC-01, D5)` docblock. |
