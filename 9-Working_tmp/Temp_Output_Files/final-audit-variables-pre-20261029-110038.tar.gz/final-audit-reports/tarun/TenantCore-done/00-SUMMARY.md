# TenantCore — Final Audit Summary

**Audited:** 2026-10-15 · **By:** opencode (main session driving 4 auditors) · **Developer folder:** tarun
**Protocol:** `.claude/rules/final-audit.md` · **Index:** [`00-INDEX.md`](00-INDEX.md)
**Phase:** AUDIT. Read-only: no `prime_ai_dev/` application code was changed.

## Per-controller

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| ActivityLogController | 142 | 0 | 0 | 4 | 3 | 3 | ALC-06 — the two tab headers print each other's record counts (All Logs shows the Student & Parent total and vice-versa), so a wrong number shows on every load. | [01-report](ActivityLogController-done/01-report.md) |
| ExportController | 279 | 1 | 1 | 6 | 5 | 4 | EXP-01 — the export error handler prints the raw exception text into the JSON `message` and the red "Export Not Allowed" page, leaking SQL/table names and file paths. | [01-report](ExportController-done/01-report.md) |
| TenantCoreController | 56 | 0 | 0 | 2 | 2 | 0 | TCC-01 — the whole controller is dead scaffold: all seven public methods are unrouted and three call views that do not exist. | [01-report](TenantCoreController-done/01-report.md) |
| EvaluationController | 150 | 1 | 1 | 4 | 3 | 1 | EVL-02 — a locking finalize burns vector annotations into the student's PDF **inside** the `DB::transaction`, so a later failure rolls the DB back while the file on disk stays rewritten. | [01-report](EvaluationController-done/01-report.md) |
| **Module totals** | **627** | **2** | **2** | **16** | **13** | **8** | | |

**Total findings: 33** · self-check PASS on all four (`SELF-CHECK PASS — …`, run independently by the main session).

## Cross-controller families (fix once, module-wide)

| Family | Rule | Instances | Note |
|---|---|---|---|
| Raw `$e->getMessage()` reaching the user / logged instead of `report($e)` | ERR-01, ERR-05 | EXP-01 (B), EVL-01 (M), EVL-08 (M) | Export surfaces the exception text to the browser; both Evaluation catches log only the message and drop the trace. |
| `request()` helper instead of an injected `Request` | CTL-08 | EXP-10 (L), EVL-07 (L) | Fix with the same edit shape in both files. |
| Public/helper methods have no return types | CTL-04 | ALC-03, EXP-09, TCC-02 | Three controllers. |
| Missing `declare(strict_types=1)` | STY-01 | EXP-12, TCC-04 | ActivityLog + Evaluation already have it. |
| Files not Pint-clean | STY-01/STY-02 | ALC-07, EXP-13, EVL-09 | Run Pint on the named files only (`--format agent`, never `--dirty`). |
| Oversized / copy-pasted method bodies | CTL-02, CTL-05 | ALC-02 (121-line `index()`), EXP-06, EXP-07, EXP-08 | Splits are D3 DEFERRED decisions. |
| Export authorization is enforced at the view surface but only conditionally in the controller | AUTH-01 | EXP-04 (M), plus the shared `export-buttons.blade.php` (see EXP-01 cross-cutting) | See the module-wide DECISION below. |

## Shared classes registered (owner reports)

`TenantCore` is a "common" module per protocol §4.2, so its reusable classes had no owner. This audit
registered them in [`00-CLASS-OWNERS.md`](../../00-CLASS-OWNERS.md) (root), so other modules' reports link
here instead of re-auditing:

- `Modules/TenantCore/app/Models/ActivityLog.php` → [tarun/TenantCore-done/ActivityLogController](ActivityLogController-done/01-report.md)
- `Modules/TenantCore/app/Exports/DataExport.php` → [tarun/TenantCore-done/ExportController](ExportController-done/01-report.md)
- 37 `Modules/TenantCore/app/Evaluation/**` framework classes (contracts, registry, 5 services, totals pipeline + 5 rules, 3 models, driver base, exception, 12 DTOs, 3 events) → [tarun/TenantCore-done/EvaluationController](EvaluationController-done/01-report.md)

Not registered (controller-private, protocol §5): the controller class itself and the five
`Http/Requests/Evaluation/*` FormRequests.

## Module-wide decisions (for Tarun)

- **Export authorization shape** (EXP-04, M · AUTH-01) — the `POST /export` gate runs only when the
  staged session payload carries a `permission` key. Either make the gate mandatory for the endpoint,
  or accept the view-only gate. Affects every list screen that uses `x-tenantcore::export-buttons`.
- **Activity-log permission literals** (ALC-01) — the same permission name is hard-coded in five
  places (controller, view, config); centralise it or leave as-is.
- **Live cross-cutting defects not fixed by this workflow** (recorded in the reports, §7):
  `Modules/SchoolSetup/app/Models/Section.php` has a typo'd broken relation and a global `orderBy`
  scope that re-orders the Section dropdown; the shared `x-tenantcore::export-buttons` component
  shares one session key across screens with the same tab value, and swallows exceptions. These belong
  to the SchoolSetup owner and the shared-component owner respectively.

## Next step

Tick items in each controller's `02-fix-plan.md`, fill every `➜ Choice:` on the ticked DECISION items,
then run `final-audit-fixer` on that controller path for developer `tarun`.
