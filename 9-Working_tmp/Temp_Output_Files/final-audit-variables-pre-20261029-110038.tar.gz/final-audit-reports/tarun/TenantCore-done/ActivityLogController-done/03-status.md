# 03 — Status · ActivityLogController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun

Decisions taken with the user's approval (2026-10-21):
- ALC-01 → (a) centralise the two permission strings as `ActivityLog` constants.
- ALC-02 → (a) defer the 121-line `index()` split (D3).
- ALC-05 → (a) accept the leading-wildcard `LIKE` search.

## 1. Pre-applied 2026-10-10
None for this controller.

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| ALC-01 | `Models/ActivityLog.php:19,22`; `ActivityLogController.php:24`; `index.blade.php:6,7,57,237` | `PERM_VIEW_ANY` / `PERM_EXPORT` constants added; the gate, the two tab entries and the two export configs now reference them | `grep -n "PERM_VIEW_ANY\|PERM_EXPORT" <controller> <view>` | controller line 24; view lines 6, 7, 57, 237 | 2026-10-21 |
| ALC-03 | `ActivityLogController.php:8,22` | `use Illuminate\View\View;` added; `index(Request $request): View` | `grep -n "public function index" <file>` | `public function index(Request $request): View` | 2026-10-21 |
| ALC-04 | `Models/ActivityLog.php:40,45` | `subject(): MorphTo` and `user(): BelongsTo` return types (+ relation imports) | `grep -nE "public function (subject\|user)\(" <file>` | both typed | 2026-10-21 |
| ALC-06 | `resources/views/activity-log/index.blade.php:77,272` | the two badge totals swapped back to their own paginator (`$activityLogs` on All Logs, `$studentParentLogs` on Student & Parent) | `grep -n "records" <view>` | line 77 `$activityLogs->total()`; line 272 `$studentParentLogs->total()` | 2026-10-21 |
| ALC-07 | `Models/ActivityLog.php:3-13` | `declare(strict_types=1)`, import order fixed, blank line after `use HasFactory;`; Pint clean | `grep -c strict_types <file>`; `pint --test <file>` | 1; passed | 2026-10-21 |

## 3. Not applied
- **ALC-02** (M, DECISION) — deferred to the split pass; `index()` stays 121 lines.
- **ALC-05** (M, DECISION) — accepted; the three `LIKE "%…%"` clauses stay.

## 4. Needs Tarun's hand
- None.

## 5. Unverifiable by this workflow (D4)
- The two badges were not checked in a browser; the Blade compiles cleanly (`compileString()` + `php -l`).
- The export permission constants are read by the shared `export-buttons` component; no browser export was run.

## 6. Verification log
```
php -l ActivityLogController.php                       No syntax errors
php -l ActivityLog.php                                 No syntax errors
class_exists(ActivityLogController::class)             bool(true)
class_exists(ActivityLog::class)                       bool(true)
blade compileString + php -l                           no syntax errors; @push 0 / startPush 0
vendor/bin/pint <touched files> --format agent         fixed: strict types/import order on the model
```

Post-fix scanner candidates still open (all known): CTL-02 (index length, ALC-02), QRY-08 (LIKE, ALC-05).

## 7. Final state
Status **FIXED**. Open: ALC-02 (M, deferred), ALC-05 (M, accepted).
