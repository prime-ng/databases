# Fix Plan — TenantCore / ActivityLogController

**From:** `01-report.md` (2026-10-15) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `routes/tenant.php` | route file — this plan adds, removes and re-scopes no route |
| `config/permissionslist.php` | shared config — no new key is needed; it is edited only if ALC-01's option (a) is chosen and even then only after Tarun confirms |
| `Modules/TenantCore/resources/views/components/export-buttons.blade.php` | shared component (common, §4.2) |
| `resources/views/components/backend/layouts/app.blade.php` and `resources/views/components/backend/tab/*.blade.php` and `…/breadcrum*.blade.php` | shared layout/components (common, §4.2) |
| `Modules/SchoolSetup/app/Models/ClassSection.php`, `SchoolClass.php`, `Section.php` | common other-module models — cross-cutting notes only (§7 of the report) |
| `Modules/StudentProfile/app/Models/Student.php` | owned by `gaurav/StudentProfile/StudentReportController` |
| `database/migrations/**` | migrations are never edited |

## 1. Blockers reachable today

None. There is no B-severity finding; the page renders and authorizes correctly.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — the controller is read-only and has no `try`/`catch` (F1 clean) and no write to wrap (F2 clean).

## 4. Authorization (F3)

- [x] **ALC-01** · M · DECISION · AUTH-06 — centralise the two activity-log permission names, or accept the literals?
  - **Why it is a decision:** the permission name is a raw string in the controller (line 23) and again in the view's tab array (lines 6-7) and export config (lines 57, 237). Where to centralise the name — a model constant versus config — changes the view, which builds its own tab array, so this is a design choice.
  - (a) ⭐ add class constants `PERM_VIEW_ANY = 'tenant.system-config.activity-log.viewAny'` and `PERM_EXPORT = 'tenant.system-config.activity-log.export'` to `Modules\TenantCore\Models\ActivityLog`, and reference them from the controller and the view
  - (b) leave the five literals as they are and record the duplication as accepted
  - ➜ Choice: (a) — centralised in ActivityLog constants 2026-10-21

## 5. Validation, routes, models (F4/F5/F7)

- [x] **ALC-04** · L · MDL-04 · `Modules/TenantCore/app/Models/ActivityLog.php:29-41` — add return types to the two relationship methods.
  - **Touches:** `Modules/TenantCore/app/Models/ActivityLog.php`
  - **Before** (`ActivityLog.php:29-41`):
    ```php
        public function subject()
        {
            return $this->morphTo();
        }

        public function user()
        {
            if (tenancy()->initialized) {
                return $this->belongsTo(TenantUser::class);
            }

            return $this->belongsTo(CentralUser::class);
        }
    ```
  - **After:**
    ```php
        public function subject(): \Illuminate\Database\Eloquent\Relations\MorphTo
        {
            return $this->morphTo();
        }

        public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
        {
            if (tenancy()->initialized) {
                return $this->belongsTo(TenantUser::class);
            }

            return $this->belongsTo(CentralUser::class);
        }
    ```
  - **Verify:** `grep -nE 'public function (subject|user)\(' Modules/TenantCore/app/Models/ActivityLog.php`
  - **Expect:** line 29 reads `public function subject(): \Illuminate\Database\Eloquent\Relations\MorphTo` and line 34 reads `public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **ALC-05** · M · DECISION · QRY-08 — replace the three leading-wildcard `LIKE` search clauses on the activity log?
  - **Why it is a decision:** a FULLTEXT option needs a migration, and a prefix match changes what the search box finds; accepting is valid when `sys_activity_logs` is small (its size was not measured).
  - (a) ⭐ accept — keep `LIKE "%value%"`; an admin activity log is normally small and the option is reversible if the table grows
  - (b) switch the three clauses to a prefix match `->where('subject_type', 'like', "{$search}%")` (and likewise for `event`, `ip_address`) — mid-string matches stop working
  - (c) add a FULLTEXT index in an additive migration and search with `MATCH … AGAINST` (Tarun runs the migration)
  - ➜ Choice: (a) — accepted, LIKE search kept 2026-10-21

## 7. Views (F10)

- [x] **ALC-06** · M · VIEW-02 · `Modules/TenantCore/resources/views/activity-log/index.blade.php:77,272` — swap the two recorded-count badges back to their own paginator.
  - **Touches:** `Modules/TenantCore/resources/views/activity-log/index.blade.php`
  - **Before** (`index.blade.php:74-78`):
    ```php
                            <h3 class="card-title mb-0">
                                <i class="fa-solid fa-clock-rotate-left me-2"></i>Activity Log
                            </h3>
                            <span class="badge bg-secondary">{{ $studentParentLogs->total() }} records</span>
    ```
  - **After:**
    ```php
                            <h3 class="card-title mb-0">
                                <i class="fa-solid fa-clock-rotate-left me-2"></i>Activity Log
                            </h3>
                            <span class="badge bg-secondary">{{ $activityLogs->total() }} records</span>
    ```
  - **Before** (`index.blade.php:268-272`):
    ```php
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h3 class="card-title mb-0">
                                <i class="fa-solid fa-user-graduate me-2"></i>Student & Parent Activity
                            </h3>
                            <span class="badge bg-secondary">{{ $activityLogs->total() }} records</span>
    ```
  - **After:**
    ```php
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h3 class="card-title mb-0">
                                <i class="fa-solid fa-user-graduate me-2"></i>Student & Parent Activity
                            </h3>
                            <span class="badge bg-secondary">{{ $studentParentLogs->total() }} records</span>
    ```
  - **Verify:** `grep -n "records" Modules/TenantCore/resources/views/activity-log/index.blade.php`
  - **Expect:** line 77 shows `$activityLogs->total()` and line 272 shows `$studentParentLogs->total()`.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [x] **ALC-03** · L · CTL-04 · `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php:21` — give `index()` a return type.
  - **Touches:** `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php`
  - **Before** (`ActivityLogController.php:21-22`):
    ```php
        public function index(Request $request)
        {
    ```
  - **After:**
    ```php
    // Add this import alongside the existing `use Illuminate\Support\Facades\Gate;` line:
    use Illuminate\View\View;

    // Then change the method signature to:
        public function index(Request $request): View
        {
    ```
  - **Verify:** `grep -n 'public function index' Modules/TenantCore/app/Http/Controllers/ActivityLogController.php`
  - **Expect:** line 21 reads `public function index(Request $request): View`.
  - **Effort:** S

- [x] **ALC-07** · L · STY-01 · `Modules/TenantCore/app/Models/ActivityLog.php:1-13` — add `declare(strict_types=1);` and make the file Pint-clean.
  - **Touches:** `Modules/TenantCore/app/Models/ActivityLog.php`
  - **Before** (`ActivityLog.php:1-13`):
    ```php
    <?php

    namespace Modules\TenantCore\Models;

    use App\Models\BaseModel;
    use Modules\Prime\Models\User as CentralUser;
    use Modules\SchoolSetup\Models\User as TenantUser;
    use Illuminate\Database\Eloquent\Factories\HasFactory;

    class ActivityLog extends BaseModel
    {
        use HasFactory;
        protected $table = 'sys_activity_logs';
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\TenantCore\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Modules\Prime\Models\User as CentralUser;
    use Modules\SchoolSetup\Models\User as TenantUser;

    class ActivityLog extends BaseModel
    {
        use HasFactory;

        protected $table = 'sys_activity_logs';
    ```
  - **Verify:** `grep -n "declare(strict_types" Modules/TenantCore/app/Models/ActivityLog.php && vendor/bin/pint --test Modules/TenantCore/app/Models/ActivityLog.php`
  - **Expect:** line 3 shows `declare(strict_types=1);` and Pint reports no failure for this file.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **ALC-02** · M · DECISION · CTL-02 — `index()` is 121 lines; extract the Student & Parent resolver (lines 92-110) and the two dropdown loads, or defer?
  - **Why it is a decision:** this is a structural refactor of a working, read-only screen (D3). Extraction must not change behaviour, so it is sequenced as a choice rather than applied blindly.
  - (a) ⭐ defer to the split pass (D3) — the method is readable today and the AL-01 note already documents why
  - (b) extract the class/section resolver (lines 92-110) and the `classes`/`sections` loads (lines 126-127) into private methods now
  - (c) leave as is and record the 121-line method as accepted
  - ➜ Choice: (a) — deferred to the split pass 2026-10-21

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| none | Every finding (ALC-01 … ALC-07) has a plan item above. |
