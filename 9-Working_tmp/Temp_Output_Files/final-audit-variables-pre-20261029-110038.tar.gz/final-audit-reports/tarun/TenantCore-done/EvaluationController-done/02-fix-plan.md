# Fix Plan — TenantCore / EvaluationController

**From:** `01-report.md` (2026-10-15) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/TenantCore/app/Http/Controllers/EvaluationController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/TenantCore/routes/web.php` | route file — no route, URI or name changes in this plan |
| `config/permissionslist.php` | ⚠ SHARED — permission config; this plan adds no key |
| `database/migrations/tenant/2026_09_25_120000_create_lms_eval_tables.php` | migration — never edited |
| `bootstrap/app.php` | central exception handler referenced by EVL-01 but not edited here |
| `Modules/LmsExam/app/Evaluation/*.php`, `Modules/LmsQuests/app/Evaluation/*.php`, `Modules/LmsHomework/app/Evaluation/*.php`, `Modules/Admission/app/Evaluation/*.php` | concrete drivers owned by other modules' reports |
| `Modules/TenantCore/app/Evaluation/Data/*.php`, `Totals/**`, `Events/*.php` | audited clean; EVL-09 touches only the five files it names |
| `final-audit-reports/00-CLASS-OWNERS.md` | append-only; the main session appends |

## 1. Blockers reachable today

- [x] **EVL-02** · B · DECISION · TXN-03 — a locking finalize rewrites the student's PDF inside the database transaction.
  - **Why it is a decision:** it changes the ordering of the burn relative to the commit; the fix must also decide where the annotation soft-delete and the burn audit row live, or a rollback leaves a changed file with rolled-back rows.
  - **Touches (whichever option is chosen):** `Modules/TenantCore/app/Evaluation/Services/EvaluationService.php`, `Modules/TenantCore/app/Evaluation/Services/AnnotationBurnService.php`
  - (a) ⭐ **Move the whole burn after the commit.** In `EvaluationService::finalize()`, capture `$needsBurn = $actionDef->burnsAnnotations()` inside the transaction, return `$totals` from it, and after the transaction returns call `$this->burner->burn($driver, $script, $ownerId, $subjectId)` (wrap the burn's own DB writes in their own `DB::transaction`). A rolled-back finalize can then never leave a rewritten PDF; if the burn itself fails, the script is locked and the annotation overlay is still intact (degraded, consistent).
  - (b) **Keep the order, document it.** Add a comment at `EvaluationService.php:97` stating the residual risk that a rollback after a successful file write leaves the PDF burned with the DB rolled back.
  - (c) **Leave as is, record as accepted.**
  - ➜ Choice: (a) — move the burn after commit 2026-10-21

## 2. Fixes that arm a latent defect (sequenced)

(none)

## 3. Errors & transactions (F1/F2)

- [x] **EVL-01** · M · ERR-05 · `EvaluationController.php:134-148` — the generic catch logs only the message; make the domain catch the only catch (D1/D2).
  - **Touches:** `Modules/TenantCore/app/Http/Controllers/EvaluationController.php`, `Modules/TenantCore/app/Evaluation/Exceptions/EvaluationException.php`
  - **Before** (`EvaluationController.php:7-10`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\Log;
    ```
  - **After:**
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Routing\Controller;
    ```
  - **Before** (`EvaluationController.php:134-148`):
    ```php
            try {
                return response()->json(['success' => true] + $work($driver));
            } catch (EvaluationException $e) {
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage(),
                    'errors' => [$e->field ?? 'general' => [$e->getMessage()]],
                ], 422);
            } catch (ModelNotFoundException $e) {
                throw $e; // Rule A1: a missing record stays a 404
            } catch (\Throwable $e) {
                Log::error('EvaluationController failed', ['context' => $context, 'owner' => $owner, 'subject' => $subject, 'error' => $e->getMessage()]);

                return response()->json(['success' => false, 'message' => 'The operation could not be completed.'], 500);
            }
    ```
  - **After:**
    ```php
            try {
                return response()->json(['success' => true] + $work($driver));
            } catch (EvaluationException $e) {
                // ERR-01 / ERR-05: EvaluationException carries an authored business-rule message
                // (safe to show); unexpected throwables bubble to the central handler. 2026-10-15
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage(),
                    'errors' => [$e->field ?? 'general' => [$e->getMessage()]],
                ], 422);
            }
    ```
  - **Before** (`EvaluationException.php:5-10`):
    ```php
    namespace Modules\TenantCore\Evaluation\Exceptions;

    use RuntimeException;

    /** Base for evaluation-framework errors. `field` lets the controller return a 422 against one input. */
    class EvaluationException extends RuntimeException
    ```
  - **After:**
    ```php
    namespace Modules\TenantCore\Evaluation\Exceptions;

    /** Base for evaluation-framework errors. `field` lets the controller return a 422 against one input. */
    class EvaluationException extends \DomainException
    ```
  - **Verify:** `grep -n "catch (ModelNotFoundException\|Log::error('EvaluationController failed'\|extends RuntimeException" Modules/TenantCore/app/Http/Controllers/EvaluationController.php Modules/TenantCore/app/Evaluation/Exceptions/EvaluationException.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **EVL-03** · H · TXN-01 · `AnnotationService.php:31-52` — wrap the annotation autosave in one transaction and stop the per-row SELECT.
  - **Touches:** `Modules/TenantCore/app/Evaluation/Services/AnnotationService.php`
  - **Before** (`AnnotationService.php:7-9`):
    ```php
    use Modules\TenantCore\Evaluation\Exceptions\EvaluationException;
    use Modules\TenantCore\Evaluation\Models\EvalAnnotation;
    use Modules\TenantCore\Evaluation\Models\EvalScript;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Facades\DB;
    use Modules\TenantCore\Evaluation\Exceptions\EvaluationException;
    use Modules\TenantCore\Evaluation\Models\EvalAnnotation;
    use Modules\TenantCore\Evaluation\Models\EvalScript;
    ```
  - **Before** (`AnnotationService.php:31-52`):
    ```php
        public function sync(EvalScript $script, array $upserts, array $deletes, array $allowedTools): void
        {
            if (count($upserts) + count($deletes) > self::MAX_PER_SYNC) {
                throw EvaluationException::invalidMark('Too many annotation changes in one save.', 'annotations');
            }
            $userId = (int) auth()->id();

            foreach ($upserts as $i => $a) {
                $row = $this->clean($a, $allowedTools, $i);
                $existing = EvalAnnotation::where('script_id', $script->id)->where('client_uid', $row['client_uid'])->first();
                if ($existing) {
                    $existing->update($row + ['updated_by' => $userId]);
                } else {
                    EvalAnnotation::create($row + ['script_id' => $script->id, 'created_by' => $userId, 'updated_by' => $userId]);
                }
            }

            $uids = array_values(array_filter(array_map('strval', $deletes), fn ($u) => $this->validUid($u)));
            if ($uids !== []) {
                EvalAnnotation::where('script_id', $script->id)->whereIn('client_uid', $uids)->get()->each->delete();
            }
        }
    ```
  - **After:**
    ```php
        public function sync(EvalScript $script, array $upserts, array $deletes, array $allowedTools): void
        {
            if (count($upserts) + count($deletes) > self::MAX_PER_SYNC) {
                throw EvaluationException::invalidMark('Too many annotation changes in one save.', 'annotations');
            }

            DB::transaction(function () use ($script, $upserts, $deletes, $allowedTools) {
                $userId = (int) auth()->id();

                $rows = [];
                foreach ($upserts as $i => $a) {
                    $rows[] = $this->clean($a, $allowedTools, $i);
                }
                $existing = $rows === [] ? collect() : EvalAnnotation::where('script_id', $script->id)
                    ->whereIn('client_uid', array_column($rows, 'client_uid'))
                    ->get()
                    ->keyBy('client_uid');

                foreach ($rows as $row) {
                    $model = $existing->get($row['client_uid']);
                    if ($model !== null) {
                        $model->update($row + ['updated_by' => $userId]);
                    } else {
                        EvalAnnotation::create($row + ['script_id' => $script->id, 'created_by' => $userId, 'updated_by' => $userId]);
                    }
                }

                $uids = array_values(array_filter(array_map('strval', $deletes), fn ($u) => $this->validUid($u)));
                if ($uids !== []) {
                    EvalAnnotation::where('script_id', $script->id)->whereIn('client_uid', $uids)->get()->each->delete();
                }
            });
        }
    ```
  - **Verify:** `grep -n "DB::transaction\|->first()" Modules/TenantCore/app/Evaluation/Services/AnnotationService.php`
  - **Expect:** one `DB::transaction` line (inside `sync`) and no `->first()` line.
  - **Effort:** M

- [x] **EVL-04** · M · TXN-01 · `ScriptService.php:32-37` — wrap the lock transition and its audit row in one transaction.
  - **Touches:** `Modules/TenantCore/app/Evaluation/Services/ScriptService.php`
  - **Before** (`ScriptService.php:7`):
    ```php
    use Modules\TenantCore\Evaluation\Contracts\EvaluationDriver;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Facades\DB;
    use Modules\TenantCore\Evaluation\Contracts\EvaluationDriver;
    ```
  - **Before** (`ScriptService.php:32-37`):
    ```php
            if (! $script->isLocked() && $driver->capabilities()->enabled('lock_from_subject')
                && $driver->loadScript($ownerId, $subjectId)->locked) {
                $old = $script->status;
                $script->update(['status' => EvalScript::STATUS_LOCKED, 'locked_at' => now(), 'updated_by' => $userId]);
                $this->audit->record($script, 'status', $old, $script->status, null, 'finalized outside the evaluator');
            }
    ```
  - **After:**
    ```php
            if (! $script->isLocked() && $driver->capabilities()->enabled('lock_from_subject')
                && $driver->loadScript($ownerId, $subjectId)->locked) {
                DB::transaction(function () use ($script, $userId) {
                    $old = $script->status;
                    $script->update(['status' => EvalScript::STATUS_LOCKED, 'locked_at' => now(), 'updated_by' => $userId]);
                    $this->audit->record($script, 'status', $old, $script->status, null, 'finalized outside the evaluator');
                });
            }
    ```
  - **Verify:** `grep -n "DB::transaction" Modules/TenantCore/app/Evaluation/Services/ScriptService.php`
  - **Expect:** one line (inside `open()`).
  - **Effort:** S

- [x] **EVL-08** · M · ERR-05 · `AnnotationBurnService.php:64-66` — log the exception, not just its message, when a PDF is skipped.
  - **Touches:** `Modules/TenantCore/app/Evaluation/Services/AnnotationBurnService.php`
  - **Before** (`AnnotationBurnService.php:7-8`):
    ```php
    use Illuminate\Support\Collection;
    use Illuminate\Support\Facades\Log;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Collection;
    ```
  - **Before** (`AnnotationBurnService.php:62-67`):
    ```php
                try {
                    $rendered[$ref] = [$this->render(Storage::disk($target['disk'])->get($target['path']), $annotations), $annotations];
                } catch (\Throwable $e) {
                    Log::warning('Annotation burn skipped', ['script' => $script->id, 'ref' => $ref, 'error' => $e->getMessage()]);
                    $skipped[$ref] = 'unreadable PDF: '.mb_substr($e->getMessage(), 0, 120);
                }
    ```
  - **After:**
    ```php
                try {
                    $rendered[$ref] = [$this->render(Storage::disk($target['disk'])->get($target['path']), $annotations), $annotations];
                } catch (\Throwable $e) {
                    report($e); // ERR-01 / ERR-05: full trace to the log; the user gets the safe skip text below. 2026-10-15
                    $skipped[$ref] = 'unreadable PDF: '.mb_substr($e->getMessage(), 0, 120);
                }
    ```
  - **Verify:** `grep -n "Log::" Modules/TenantCore/app/Evaluation/Services/AnnotationBurnService.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

(none — F3 is clean; authorization is delegated to `$driver->authorize()` before any record load)

## 5. Validation, routes, models (F4/F5/F7)

(none — see §10 for the two accepted findings EVL-05 and EVL-06)

## 6. Queries & performance (F9)

(none — the only in-scope N+1 is fixed by EVL-03 in §3)

## 7. Views (F10)

(none — no Blade views)

## 8. Style (F12) — one item per file

- [x] **EVL-07** · L · CTL-08 · `EvaluationController.php:40-45` — inject `Request` in `queue()` instead of the `request()` helper.
  - **Touches:** `Modules/TenantCore/app/Http/Controllers/EvaluationController.php`
  - **Before** (`EvaluationController.php:8-9`):
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Routing\Controller;
    ```
  - **After:**
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    ```
  - **Before** (`EvaluationController.php:40-47`):
    ```php
        public function queue(string $context, string $owner): JsonResponse
        {
            return $this->run($context, $owner, null, EvaluationDriver::ABILITY_VIEW, function (EvaluationDriver $driver) use ($owner) {
                $filters = request()->only(['status', 'search', 'allocation_id']);

                return ['queue' => array_map(fn (QueueEntry $e) => $e->toArray(), $driver->queue($owner, $filters))];
            });
        }
    ```
  - **After:**
    ```php
        public function queue(Request $request, string $context, string $owner): JsonResponse
        {
            return $this->run($context, $owner, null, EvaluationDriver::ABILITY_VIEW, function (EvaluationDriver $driver) use ($request, $owner) {
                $filters = $request->only(['status', 'search', 'allocation_id']);

                return ['queue' => array_map(fn (QueueEntry $e) => $e->toArray(), $driver->queue($owner, $filters))];
            });
        }
    ```
  - **Verify:** `grep -n "request()" Modules/TenantCore/app/Http/Controllers/EvaluationController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **EVL-09** · L · STY-02 · `TotalsLine.php`, `Capabilities.php`, `AnswerData.php`, `AnnotationService.php`, `EvalScript.php` — make the five files Pint-clean (blank line between adjacent class members/consts).
  - **Touches:** `Modules/TenantCore/app/Evaluation/Totals/TotalsLine.php`, `Modules/TenantCore/app/Evaluation/Data/Capabilities.php`, `Modules/TenantCore/app/Evaluation/Data/AnswerData.php`, `Modules/TenantCore/app/Evaluation/Services/AnnotationService.php`, `Modules/TenantCore/app/Evaluation/Models/EvalScript.php`
  - **Before** (`TotalsLine.php:12-15`):
    ```php
        public ?float $effective;
        public float $floor = 0.0;
        public bool $counted = true;
        /** @var string[] */
    ```
  - **After:**
    ```php
        public ?float $effective;

        public float $floor = 0.0;

        public bool $counted = true;

        /** @var string[] */
    ```
  - **Before** (`Capabilities.php:14-15`):
    ```php
        public const GRANULARITY_ITEM = 'item';     // marks per question
        public const GRANULARITY_SCRIPT = 'script'; // one mark for the whole submission
    ```
  - **After:**
    ```php
        public const GRANULARITY_ITEM = 'item';     // marks per question

        public const GRANULARITY_SCRIPT = 'script'; // one mark for the whole submission
    ```
  - **Before** (`AnswerData.php:14-17`):
    ```php
        public const KIND_FILE = 'file';
        public const KIND_TEXT = 'text';
        public const KIND_MCQ = 'mcq';
        public const KIND_NONE = 'none';
    ```
  - **After:**
    ```php
        public const KIND_FILE = 'file';

        public const KIND_TEXT = 'text';

        public const KIND_MCQ = 'mcq';

        public const KIND_NONE = 'none';
    ```
  - **Before** (`AnnotationService.php:17-18`):
    ```php
        private const MAX_PAYLOAD_BYTES = 65536;
        private const MAX_PER_SYNC = 500;
    ```
  - **After:**
    ```php
        private const MAX_PAYLOAD_BYTES = 65536;

        private const MAX_PER_SYNC = 500;
    ```
  - **Before** (`EvalScript.php:16-18`):
    ```php
        public const STATUS_DRAFT = 'draft';
        public const STATUS_SUBMITTED = 'submitted';
        public const STATUS_LOCKED = 'locked';
    ```
  - **After:**
    ```php
        public const STATUS_DRAFT = 'draft';

        public const STATUS_SUBMITTED = 'submitted';

        public const STATUS_LOCKED = 'locked';
    ```
  - **Verify:** `vendor/bin/pint --test Modules/TenantCore/app/Evaluation/Totals/TotalsLine.php Modules/TenantCore/app/Evaluation/Data/Capabilities.php Modules/TenantCore/app/Evaluation/Data/AnswerData.php Modules/TenantCore/app/Evaluation/Services/AnnotationService.php Modules/TenantCore/app/Evaluation/Models/EvalScript.php`
  - **Expect:** `{"tool":"pint","result":"pass",...}` and exit code 0.
  - **Effort:** S

## 9. Deferred / decisions

(none beyond EVL-02 in §1)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| EVL-05 | Accepted by design — `FinalizeRequest` is intentionally shape-only; each concrete driver coerces the `input` keys it consumes (`filter_var`, `mb_substr`). |
| EVL-06 | Accepted by design — `GET …/scripts/{subject}` lazy-creates the evaluator's own tracking row; moving creation to a POST would change the boot flow of every context. |
