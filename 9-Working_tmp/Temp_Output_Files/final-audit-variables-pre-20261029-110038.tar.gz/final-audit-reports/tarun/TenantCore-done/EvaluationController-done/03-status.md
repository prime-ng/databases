# 03 — Status · EvaluationController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun

Decisions taken with the user's approval (2026-10-21):
- EVL-02 → (a) move the annotation burn after the finalize transaction commits.

## 1. Pre-applied 2026-10-10
None for this controller.

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| EVL-02 | `EvaluationService.php:79-110` | `$needsBurn` is captured inside the finalize transaction; the burn now runs after it returns, inside its own `DB::transaction`; `ScriptFinalized` still dispatches inside the original transaction | `grep -n "needsBurn\|burner->burn" <file>` | 79, 82, 95, 106, 107 | 2026-10-21 |
| EVL-01 | `EvaluationController.php:5-9,134-144`; `EvaluationException.php:7-8` | `ModelNotFoundException` and `Log` imports and both generic catches removed; only the `EvaluationException` catch remains; the exception now extends `\DomainException` (D2) | `grep -n "catch (ModelNotFoundException\|Log::error('EvaluationController failed'\|extends RuntimeException" <two files>` | no output | 2026-10-21 |
| EVL-03 | `AnnotationService.php:6,31-67` | autosave wrapped in one `DB::transaction`; one `whereIn(client_uid)` load replaces the per-row `->first()` | `grep -n "DB::transaction\|->first()" <file>` | one `DB::transaction` (line 39); no `->first()` | 2026-10-21 |
| EVL-04 | `ScriptService.php:6,35-40` | the lock transition and its audit row share one `DB::transaction` | `grep -n "DB::transaction" <file>` | line 35 | 2026-10-21 |
| EVL-07 | `EvaluationController.php:6,39-43` | `queue()` takes an injected `Illuminate\Http\Request`; the `request()` helper is gone | `grep -n "request()" <file>` | no output | 2026-10-21 |
| EVL-08 | `AnnotationBurnService.php:7,64` | `Log::warning(...)` replaced with `report($e)` (full trace); the `Log` import removed | `grep -n "Log::" <file>` | no output | 2026-10-21 |
| EVL-09 | five files | Pint-clean: blank lines between adjacent members/consts in `TotalsLine`, `Capabilities`, `AnswerData`, `AnnotationService`, `EvalScript` | `pint --test <five files>` | passed (exit 0) | 2026-10-21 |

## 3. Not applied
None — every item in this plan was ticked.

## 4. Needs Tarun's hand
- **EVL-02 residual:** a burn failure after the finalize commits now bubbles to the controller and returns a 500 even though the script is already locked. If you prefer "finalize succeeded, burn skipped" to be reported as success, add a catch around the post-commit burn in a follow-up.
- `EvaluationException` is now a `\DomainException` instead of a `\RuntimeException`. No code in `Modules/` or `app/` catches `RuntimeException` around the evaluator (measured), but any out-of-tree caller that did would stop catching it.

## 5. Unverifiable by this workflow (D4)
- The finalize/rollback ordering was not exercised against a live database.
- The burn's file writes cannot be rolled back by `DB::transaction`; only its DB writes can. This is the accepted residual from the plan.

## 6. Verification log
```
php -l (9 touched PHP files)                           No syntax errors
class_exists (controller, exception, services)         all bool(true)
grep catch/Log::error/RuntimeException (EVL-01)        no output
grep DB::transaction / ->first() (EVL-03)              one / none
grep DB::transaction (EVL-04)                          one (ScriptService:35)
grep request() (EVL-07)                                no output
grep Log:: (EVL-08)                                    no output
pint --test (5 EVL-09 files)                           passed
route:list                                             ROUTES-OK
```

Post-fix scanner candidates still open (all known/accepted): AUTH-01 rows are static false positives — each action delegates to `$driver->authorize()` in `run()` before loading a record (report §F3); QRY-07 per-row writes inside `AnnotationService::sync()` are bounded by `MAX_PER_SYNC`; err-domain-message rows are the intentional D2 message.

## 7. Final state
Status **FIXED**. Open: none from the plan (EVL-05/EVL-06 remain accepted by design).
