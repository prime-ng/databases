# Status — TeacherPortal / TeacherPortalController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output |
|---|---|---|---|---|
| TPC-01 | `TeacherPortalController.php` | Four controller try/catch blocks removed; unused `Log`/`ValidationException` imports dropped. | `grep "try {\|} catch"` | none |
| TPC-02 | `Services/TeacherLeaveService.php` | Paid + Submitted portal leave now debits `total_pending` inside the existing transaction. | `grep "increment('total_pending'"` | 1 hit |
| TPC-05 | — | Accepted ⭐ (a): keep the `role:Teacher` web gate + service ownership; no new permission key. | — | — |
| TPC-06 | `TeacherPortalController.php` | `?week=` / `?month=` validated with `Carbon::hasFormat()` before parsing. | `grep "Carbon::parse(\$request"` | none |
| TPC-07 | `Requests/StoreAttendanceRequest.php`, `Requests/ReviewStudentLeaveRequest.php` (new) | Inline validation replaced by Form Requests. | `grep "\$request->validate("` | none |
| TPC-08 | `Modules/TeacherPortal/routes/api.php` | Dead `apiResource('teacherportals')` routes removed. | `route:list --path=api/v1/teacherportals` | no routes |
| TPC-10 | `TeacherPortalController.php` | `chat()` injects `Request`; no `request()` helper. | `grep "request()"` | none |
| TPC-12 | `Services/TeacherClassesService.php` | `classSections()` memoised per request/user. | `grep "classSectionsCache"` | present |

## 3. Not applied / deferred
- **TPC-03/04** — recorded for the SchoolSetup leave audit (not reachable from this controller / disproportionate).
- **TPC-09** — accepted as designed (self-scoped, idempotent read).
- **TPC-11/13/14** — recorded (shared-model typing sweep / UI pagination decision / cosmetic markers).

## 4. Shared changes
- `Modules/TeacherPortal/routes/api.php` dead resource removed (applied here).
- No portal-access route change (TPC-05 ⭐ a).

## 5. Verification
- Pint passed; `php -l` clean; route list shows no dead teacherportal API route; `view:cache` compiled.

## 6. Final state
FIXED. TPC-05 accepted; TPC-03/04/09/11/13/14 recorded.
