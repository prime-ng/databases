# Fix Plan — TeacherPortal / TeacherPortalController

**From:** `01-report.md` (2026-10-14) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/TeacherPortal/Providers/TeacherPortalServiceProvider.php` | module provider — only the route file is named, and only if TPC-08 option (a) is chosen |
| `Modules/TeacherPortal/routes/web.php` | web route table — no web route changes in this plan |
| `Modules/StudentProfile/app/Models/LeaveApplication.php` | owned by [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController-done/01-report.md) |
| `Modules/TeacherPortal/app/Services/TeacherContext.php` | owned by [tarun/TeacherPortal-done/MobileTeacherDashboardController](../MobileTeacherDashboardController/01-report.md) |
| `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php` | owned by [tarun/TeacherPortal-done/MobileTeacherAttendanceController](../MobileTeacherAttendanceController/01-report.md) |
| `Modules/TeacherPortal/app/Services/TeacherStudentLeaveService.php` | owned by [tarun/TeacherPortal-done/MobileTeacherAttendanceController](../MobileTeacherAttendanceController/01-report.md) |
| `Modules/TeacherPortal/resources/views/**` | no VIEW finding in this audit; nothing to change |
| `Modules/SchoolSetup/app/Models/Employee.php` | does not appear in any ticked item (TPC-11 is recorded, not planned) |
| `config/permissionslist.php` | only TPC-08 option (a), if chosen, or a new TPC-05 permission key approved by Tarun |

## 1. Blockers reachable today

- [ ] **TPC-08** · B · DECISION · RTE-02 — `routes/api.php` registers five REST routes whose methods do not exist; every `/api/v1/teacherportals` call 500s.
  - **Why it is a decision:** fixing it removes or adds routes, which is a route change (final-audit.md §9.3). The module is display-only, so the honest fix is to delete the dead resource.
  - **Touches:** `Modules/TeacherPortal/routes/api.php` (⚠ SHARED — a route file; Tarun must tick it explicitly).
  - (a) ⭐ Remove the API resource. Delete the `Route::apiResource(...)` line so `routes/api.php` declares no routes, and confirm the module's `mapApiRoutes()` then registers nothing. This matches `module.json` ("Display-only") and the web-only route design.
  - (b) Keep the resource and implement read-only `index()` and `show()` methods (a list of the signed-in teacher's own summary data) plus `Route::apiResource(...)->only(['index','show'])`; remove `store`/`update`/`destroy`.
  - (c) Keep the resource and implement all five methods as a full CRUD API — not recommended; this module is a read/self-service portal, not a resource manager.
  - ➜ Choice: ____

## 2. Fixes that arm a latent defect (sequenced)

None. The plan has no item that must land before another to avoid arming a latent defect.

## 3. Errors & transactions (F1/F2)

- [ ] **TPC-01** · M · ERR-00 — remove the four controller `try`/`catch` blocks (D1: no try/catch in a controller) and the two now-unused imports.
  - **Touches:** `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php`
  - **Before** (`TeacherPortalController.php:620-635`, `applyLeave`):
    ```php
    try {
        $this->leaveService->apply($ctx, $validated);
    } catch (ValidationException $e) {
        throw $e;
    } catch (\Throwable $e) {
        Log::error('Teacher portal leave application failed', [
            'user_id' => $ctx->user->id,
            'employee_id' => $ctx->employeeId,
            'exception' => $e,
        ]);

        return redirect()
            ->route('teacher-portal.my-leave', ['tab' => 'apply'])
            ->withInput()
            ->with('error', 'Your leave application could not be filed. Please try again.');
    }
    ```
  - **After:**
    ```php
    $this->leaveService->apply($ctx, $validated);
    ```
  - **Before** (`TeacherPortalController.php:762-776`, `storeAttendance`):
    ```php
    try {
        $result = $this->attendance->save(
            $ctx, $csId, $date,
            $validated['status'],
            $validated['remarks'] ?? [],
        );
    } catch (\Throwable $e) {
        Log::error('Teacher portal attendance save failed', [
            'user_id' => $ctx->user->id, 'class_section' => $csId, 'exception' => $e,
        ]);

        return redirect()
            ->route('teacher-portal.attendance', ['class_section' => $csId])
            ->with('error', 'Attendance could not be saved. Please try again.');
    }
    ```
  - **After:**
    ```php
    $result = $this->attendance->save(
        $ctx, $csId, $date,
        $validated['status'],
        $validated['remarks'] ?? [],
    );
    ```
  - **Before** (`TeacherPortalController.php:834-843`, `reviewStudentLeave`):
    ```php
    try {
        $done = $this->studentLeave->review($ctx, $application, $validated);
    } catch (\Throwable $e) {
        Log::error('Teacher portal leave review failed', [
            'user_id' => $ctx->user->id, 'application_id' => $application->id, 'exception' => $e,
        ]);

        return $this->backToLeaveTab($csId, $request)
            ->with('error', 'The leave application could not be updated. Please try again.');
    }
    ```
  - **After:**
    ```php
    $done = $this->studentLeave->review($ctx, $application, $validated);
    ```
  - **Before** (`TeacherPortalController.php:670-681`, `attendance` — the date guard):
    ```php
    /*
     * ⚠ A BAD ?date= FALLS BACK TO TODAY RATHER THAN THROWING. Carbon::parse() raises on
     * junk, and a malformed bookmark should not 500 a register.
     */
    $date = Carbon::today();
    if ($request->filled('date')) {
        try {
            $date = Carbon::parse($request->string('date')->toString())->startOfDay();
        } catch (\Throwable) {
            $date = Carbon::today();
        }
    }
    ```
  - **After:**
    ```php
    /*
     * A bad ?date= falls back to today rather than throwing. hasFormat() returns false for
     * junk instead of raising, so no try/catch is needed (D1, TPC-01, 2026-10-14).
     */
    $date = Carbon::today();
    $rawDate = $request->string('date')->toString();
    if ($rawDate !== '' && Carbon::hasFormat($rawDate, 'Y-m-d')) {
        $date = Carbon::createFromFormat('Y-m-d', $rawDate)->startOfDay();
    }
    ```
  - **Before** (`TeacherPortalController.php:12-15` — drop the two imports that are now unused):
    ```php
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Log;
    use Illuminate\Validation\Rule;
    use Illuminate\Validation\ValidationException;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Facades\DB;
    use Illuminate\Validation\Rule;
    ```
  - **Verify:** `grep -nE 'try \{|\} catch|Log::|ValidationException' Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **TPC-02** · H · TXN-01 — debit `total_pending` when a paid, submitted leave is filed from the portal, matching the admin path.
  - **Touches:** `Modules/TeacherPortal/app/Services/TeacherLeaveService.php`
  - **Before** (`TeacherLeaveService.php:372-389`):
    ```php
    return DB::transaction(function () use ($payload, $policy, $ctx): int {
        $application = EmployeeLeaveApplication::create($payload);

        if ($payload['status'] === 'Submitted' && $policy) {
            $this->staffLeave->createApprovalRecords($application, $policy, $ctx->user->id);
        }

        activityLog($application, $payload['status'] === 'Submitted' ? 'Submitted' : 'Created', [
            'message' => 'Leave application '
                .($payload['status'] === 'Submitted' ? 'submitted' : 'saved as draft')
                .' from the Teacher Portal.',
            'from_date' => $payload['from_date'],
            'to_date' => $payload['to_date'],
            'total_days' => $payload['total_days'],
        ]);

        return (int) $application->id;
    });
    ```
  - **After:**
    ```php
    return DB::transaction(function () use ($payload, $policy, $ctx, $leaveType, $sessionId): int {
        $application = EmployeeLeaveApplication::create($payload);

        if ($payload['status'] === 'Submitted' && $policy) {
            $this->staffLeave->createApprovalRecords($application, $policy, $ctx->user->id);
        }

        /*
         * The admin screen debits total_pending when a paid application is Submitted
         * (EmployeeLeaveApplicationController::store), and StaffLeaveService::cancelApplication()
         * decrements it again on cancel. The portal omitted the debit, so its applications were
         * invisible to the balance and a later cancel drove total_pending negative. TPC-02,
         * 2026-10-14.
         */
        if ($payload['status'] === 'Submitted' && $leaveType->is_paid) {
            DB::table('sch_employee_leave_balance')
                ->where('employee_id', $ctx->employeeId)
                ->where('annual_leave_sessions_id', $sessionId)
                ->where('leave_type_id', $payload['leave_type_id'])
                ->whereNull('deleted_at')
                ->increment('total_pending', (float) $payload['total_days']);
        }

        activityLog($application, $payload['status'] === 'Submitted' ? 'Submitted' : 'Created', [
            'message' => 'Leave application '
                .($payload['status'] === 'Submitted' ? 'submitted' : 'saved as draft')
                .' from the Teacher Portal.',
            'from_date' => $payload['from_date'],
            'to_date' => $payload['to_date'],
            'total_days' => $payload['total_days'],
        ]);

        return (int) $application->id;
    });
    ```
  - **Verify:** `grep -n "increment('total_pending'" Modules/TeacherPortal/app/Services/TeacherLeaveService.php`
  - **Expect:** one line at the new increment inside `apply()`.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **TPC-05** · M · DECISION · AUTH-01 — no permission check on any method; access is `role:Teacher` middleware plus service ownership, and there is no `teacher-portal` permission key.
  - **Why it is a decision:** a new permission key. It must go in `config/permissionslist.php` and be seeded (`/system-config/sync-permissions`), which is Tarun's hand (final-audit.md §9.2 #9).
  - **Touches:** `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php`, `config/permissionslist.php` (⚠ SHARED), and the route/seed path named by the chosen option.
  - (a) ⭐ Accept the documented model: keep `role:Teacher` and the per-record ownership checks, and record the decision in the module docblock. No code change; zero risk to the 85 teachers who hold zero permissions.
  - (b) Add a `tenant.teacher-portal.view` permission set, seed it to the `Teacher` role, and add `Gate::authorize('tenant.teacher-portal.view')` to every read method and the matching `store`/`review` abilities to the writes. Also set `ApplyLeaveRequest::authorize()` to the same check.
  - (c) Add the permission keys but gate only the write methods (`applyLeave`, `storeAttendance`, `reviewStudentLeave`), leaving the reads on `role:Teacher`.
  - ➜ Choice: ____

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **TPC-06** · H · VAL-05 — a junk `?week=` or `?month=` reaches `Carbon::parse()` and 500s the page.
  - **Touches:** `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php`
  - **Before** (`TeacherPortalController.php:168-170`, `timetable`):
    ```php
    $anchor = $request->filled('week')
        ? Carbon::parse($request->string('week')->toString())
        : Carbon::today();
    ```
  - **After:**
    ```php
    $rawWeek = $request->string('week')->toString();
    $anchor = ($rawWeek !== '' && Carbon::hasFormat($rawWeek, 'Y-m-d'))
        ? Carbon::createFromFormat('Y-m-d', $rawWeek)
        : Carbon::today();
    ```
  - **Before** (`TeacherPortalController.php:547-549`, `leave`):
    ```php
    $month = $request->filled('month')
        ? Carbon::parse($request->string('month')->toString())->startOfMonth()
        : Carbon::today()->startOfMonth();
    ```
  - **After:**
    ```php
    $rawMonth = $request->string('month')->toString();
    $month = ($rawMonth !== '' && Carbon::hasFormat($rawMonth, 'Y-m-d'))
        ? Carbon::createFromFormat('Y-m-d', $rawMonth)->startOfMonth()
        : Carbon::today()->startOfMonth();
    ```
  - **Verify:** `grep -n 'Carbon::parse($request' Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **TPC-07** · M · VAL-02 — move the two inline `$request->validate()` payloads into Form Requests.
  - **Touches:** `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php`, `Modules/TeacherPortal/app/Http/Requests/StoreAttendanceRequest.php` (new), `Modules/TeacherPortal/app/Http/Requests/ReviewStudentLeaveRequest.php` (new)
  - **Before** (`TeacherPortalController.php:742-749`, `storeAttendance`):
    ```php
    $validated = $request->validate([
        'class_section' => ['required', 'integer'],
        'date' => ['required', 'date'],
        'status' => ['required', 'array'],
        'status.*' => ['required', 'string', Rule::in(TeacherAttendanceService::STATUSES)],
        'remarks' => ['nullable', 'array'],
        'remarks.*' => ['nullable', 'string', 'max:255'],
    ]);
    ```
  - **After:** new file `Modules/TeacherPortal/app/Http/Requests/StoreAttendanceRequest.php`:
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\TeacherPortal\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Modules\TeacherPortal\Services\TeacherAttendanceService;

    class StoreAttendanceRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }

        public function rules(): array
        {
            return [
                'class_section' => ['required', 'integer'],
                'date' => ['required', 'date'],
                'status' => ['required', 'array'],
                'status.*' => ['required', 'string', Rule::in(TeacherAttendanceService::STATUSES)],
                'remarks' => ['nullable', 'array'],
                'remarks.*' => ['nullable', 'string', 'max:255'],
            ];
        }
    }
    ```
  - **After — controller** (`TeacherPortalController.php:738` signature, and line 742 becomes one call):
    ```php
    public function storeAttendance(StoreAttendanceRequest $request): RedirectResponse
    {
        $ctx = TeacherContext::for(auth()->user());

        $validated = $request->validated();
    ```
  - **Before** (`TeacherPortalController.php:813-832`, `reviewStudentLeave`):
    ```php
    $validated = $request->validate([
        'status' => ['required', 'string', Rule::in(TeacherStudentLeaveService::REVIEW_STATUSES)],
        /*
         * ⚠ REQUIRED FOR THE TWO REQUEST STATUSES. 'Info Requested' and 'Doc Requested'
         * create a remark the student must reply to, and a request with no question is
         * a dead end they cannot answer — see TeacherStudentLeaveService::REQUEST_REMARK_TYPE.
         * required_if is not used because the status values contain a space.
         */
        'review_remarks' => [
            Rule::requiredIf(fn () => in_array(
                $request->input('status'),
                array_keys(TeacherStudentLeaveService::REQUEST_REMARK_TYPE),
                true,
            )),
            'nullable', 'string', 'max:1000',
        ],
        'approved_days' => ['nullable', 'integer', 'min:0', 'max:'.(int) $application->total_days],
    ], [
        'review_remarks.required' => 'Say what you need from the student — they can only reply to a question that was actually asked.',
    ]);
    ```
  - **After — new file** `Modules/TeacherPortal/app/Http/Requests/ReviewStudentLeaveRequest.php`:
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\TeacherPortal\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Modules\TeacherPortal\Services\TeacherStudentLeaveService;

    class ReviewStudentLeaveRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }

        public function rules(): array
        {
            $application = $this->route('application');
            $maxDays = $application ? (int) $application->total_days : 0;

            return [
                'status' => ['required', 'string', Rule::in(TeacherStudentLeaveService::REVIEW_STATUSES)],
                /*
                 * Required for the two request statuses: 'Info Requested' and 'Doc Requested'
                 * create a remark the student must reply to, so a request with no question is a
                 * dead end. required_if is not used because the status values contain a space.
                 */
                'review_remarks' => [
                    Rule::requiredIf(fn () => in_array(
                        $this->input('status'),
                        array_keys(TeacherStudentLeaveService::REQUEST_REMARK_TYPE),
                        true,
                    )),
                    'nullable', 'string', 'max:1000',
                ],
                'approved_days' => ['nullable', 'integer', 'min:0', 'max:'.$maxDays],
            ];
        }

        public function messages(): array
        {
            return [
                'review_remarks.required' => 'Say what you need from the student — they can only reply to a question that was actually asked.',
            ];
        }
    }
    ```
  - **After — controller** (`TeacherPortalController.php:806` signature, and line 813 becomes one call):
    ```php
    public function reviewStudentLeave(ReviewStudentLeaveRequest $request, LeaveApplication $application): RedirectResponse
    {
        $ctx = TeacherContext::for(auth()->user());
        $csId = (int) $application->class_section_id;

        abort_unless($this->studentLeave->canReview($ctx, $csId), 403);

        $validated = $request->validated();
    ```
  - **After — controller imports** (`TeacherPortalController.php:14` and `:18`; drop the now-unused `Rule` import and add the two new ones):
    ```php
    use Illuminate\Validation\Rule;
    use Modules\TeacherPortal\Http\Requests\ApplyLeaveRequest;
    ```
    becomes
    ```php
    use Modules\TeacherPortal\Http\Requests\ApplyLeaveRequest;
    use Modules\TeacherPortal\Http\Requests\ReviewStudentLeaveRequest;
    use Modules\TeacherPortal\Http\Requests\StoreAttendanceRequest;
    ```
  - **Verify:** `grep -n '$request->validate(' Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php`
  - **Expect:** no output; and `php -l` is clean on all three files.
  - **Effort:** M

## 6. Queries & performance (F9)

- [ ] **TPC-12** · M · SVC-05 — memoise `TeacherClassesService::classSections()` so the My Classes page stops issuing the same query six times.
  - **Touches:** `Modules/TeacherPortal/app/Services/TeacherClassesService.php`
  - **Before** (`TeacherClassesService.php:36-41`):
    ```php
    public function classSections(TeacherContext $ctx): Collection
    {
        if ($ctx->classSections->isEmpty()) {
            return collect();
        }

    ```
    (the method continues to line 72; the full replacement is below)
  - **After:**
    ```php
    public function classSections(TeacherContext $ctx): Collection
    {
        if ($this->classSectionsCache !== null && $this->classSectionsCachedFor === $ctx->user->id) {
            return $this->classSectionsCache;
        }

        $this->classSectionsCachedFor = $ctx->user->id;

        if ($ctx->classSections->isEmpty()) {
            return $this->classSectionsCache = collect();
        }

        $rows = collect(DB::table('sch_class_section_jnt as cs')
            ->leftJoin('sch_classes as c', 'c.id', '=', 'cs.class_id')
            ->leftJoin('sch_sections as s', 's.id', '=', 'cs.section_id')
            ->where('cs.is_active', true)
            ->get([
                'cs.id', 'cs.class_id', 'cs.section_id', 'cs.class_teacher_id',
                'c.name as class_name', 's.name as section_name',
            ]));

        $wanted = $ctx->classSections
            ->map(fn ($x) => ((int) $x->class_id).'-'.((int) ($x->section_id ?? 0)))
            ->flip();

        $ownId = $ctx->classTeacherOf->class_section_id ?? null;

        return $this->classSectionsCache = $rows
            ->filter(function ($r) use ($wanted, $ownId) {
                $key = ((int) $r->class_id).'-'.((int) ($r->section_id ?? 0));

                return $wanted->has($key) || (int) $r->id === (int) $ownId;
            })
            ->map(function ($r) use ($ownId) {
                $r->is_own_class = (int) $r->id === (int) $ownId;
                $r->label = trim(($r->class_name ?? '?').' '.($r->section_name ?? ''));

                return $r;
            })
            ->sortBy([['is_own_class', 'desc'], ['class_id', 'asc'], ['section_id', 'asc']])
            ->values();
    }
    ```
    and at the top of the class, declare the two properties:
  - **Before** (`TeacherClassesService.php:23-24`):
    ```php
    final class TeacherClassesService
    {
    ```
  - **After:**
    ```php
    final class TeacherClassesService
    {
        /** @var Collection<int, object>|null Memoised per request — see classSections() (TPC-12). */
        private ?Collection $classSectionsCache = null;

        private ?int $classSectionsCachedFor = null;
    ```
  - **Verify:** `grep -n 'classSectionsCache' Modules/TeacherPortal/app/Services/TeacherClassesService.php`
  - **Expect:** four lines (two property declarations, two uses in `classSections()`).
  - **Effort:** S

## 7. Views (F10)

No item. F10 is clean — no queries in Blade, relations eager-loaded, no `{!! !!}` on user text, all 21 blades compile. See `01-report.md` F10.

## 8. Style (F12) — one item per file

- [ ] **TPC-10** · L · CTL-08 — inject `Request` into `chat()` instead of calling the `request()` helper.
  - **Touches:** `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php`
  - **Before** (`TeacherPortalController.php:292-300`):
    ```php
    public function chat(): View
    {
        activityLog(auth()->user(), 'Viewed', [
            'message' => 'Teacher viewed the chat page.',
            'context' => [
                'module' => 'TeacherPortal',
                'route' => request()->route()?->getName(),
            ],
        ]);
    ```
  - **After:**
    ```php
    public function chat(Request $request): View
    {
        activityLog(auth()->user(), 'Viewed', [
            'message' => 'Teacher viewed the chat page.',
            'context' => [
                'module' => 'TeacherPortal',
                'route' => $request->route()?->getName(),
            ],
        ]);
    ```
  - **Verify:** `grep -nE '\brequest\(\)' Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- **God-controller split — DEFERRED (D3).** `TeacherPortalController` is 871 lines with 15 public methods, below both thresholds (1,000 lines / 25 methods). No split is proposed or applied.
- **TPC-05** and **TPC-08** are the two DECISION items; they live in §4 and §1 above respectively.
- **TPC-11** (model return types + `strict_types`) is deferred to a typed-relations sweep — it touches three shared SchoolSetup models for an L-severity change; see §10.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TPC-03 | `StaffLeaveService::storeDocuments()` has no transaction, but it is not reachable from `TeacherPortalController` (its callers are the admin and mobile leave controllers). The correct fix orders the DB writes against `addMedia()`'s file write (TXN-03) and belongs with the admin-path leave audit. |
| TPC-04 | `createApprovalRecords()` creates one row per policy level in a loop; on this tenant a policy has one or two levels, so the gain is disproportionate to the risk of changing a shared service. Reported for the SchoolSetup leave audit. |
| TPC-09 | Opening a notification writes `read_at` over GET. Accepted as designed (idempotent, self-scoped, documented at `TeacherPortalController.php:484-488`); changing it would move the read action to the existing POST. |
| TPC-11 | Relationship return types and `strict_types` are missing on three shared SchoolSetup models; an L-severity change with a wide blast radius. Recorded for a typed-relations sweep, not this plan. |
| TPC-13 | The notification list is fetched unbounded; scoped to the signed-in user and 4 rows live today. Paginating changes the tab-bin UI, which is a design decision, so it is recorded rather than planned. |
| TPC-14 | Emoji/symbol markers in comments are the module's deliberate documentation voice; a cosmetic sweep across 11 files for an L-severity convention difference. Recorded, not planned. |
