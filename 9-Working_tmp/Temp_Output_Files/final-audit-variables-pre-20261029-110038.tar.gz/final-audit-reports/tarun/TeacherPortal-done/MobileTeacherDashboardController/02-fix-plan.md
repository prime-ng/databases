# Fix Plan — TeacherPortal / MobileTeacherDashboardController

**From:** `01-report.md` (2026-10-14) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `final-audit-reports/00-CLASS-OWNERS.md` | shared, append-only, main session owns it |
| `final-audit-reports/tarun/TeacherPortal-done/00-INDEX.md` | shared index, main session owns it |
| `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | owned by [tarun/StandardTimetable/StandardTimetableController-done](../../StandardTimetable-done/StandardTimetableController-done/01-report.md) |
| `Modules/SmartTimetable/app/Services/SubstitutionHistoryReader.php` | owned by [tarun/SmartTimetable/SubstitutionController](../../SmartTimetable-done/SubstitutionController-done/01-report.md) |
| `Modules/TimetableFoundation/app/Services/PublishedTimetable.php` | owned by [TimetableFoundation/TimetableFoundationController](../../../tarun/TimetableFoundation-done/TimetableFoundationController-done/01-report.md) |
| `Modules/TimetableFoundation/app/Models/Timetable.php` | owned by [TimetableFoundation/TimetableController](../../../tarun/TimetableFoundation-done/TimetableController-done/01-report.md) — earlier registry claim wins (reconciled 2026-10-14) |
| `Modules/TeacherPortal/routes/mobile_api.php`, `routes/api.php` | route files — touched ONLY if DECISION MTD-01 chooses option (a) |
| `database/migrations/**` | never edit an existing migration |

## 1. Blockers reachable today

None. No B-severity finding, no page-killer and no data leak was found in this controller.

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **MTD-10** · M · SVC-02 · `Modules/TeacherPortal/app/Services/TeacherScheduleService.php:55-58,651` — inject `SnapshotContext` and `SubstitutionHistoryReader` through the constructor instead of resolving them with `app()`.
  - **Touches:** `Modules/TeacherPortal/app/Services/TeacherScheduleService.php`
  - **Before** (`TeacherScheduleService.php:55-58`):
    ```php
    private function snapshots(): SnapshotContext
    {
        return app(SnapshotContext::class);
    }
    ```
  - **After:**
    ```php
    public function __construct(
        private readonly SnapshotContext $snapshotContext,
        private readonly SubstitutionHistoryReader $substitutionHistory,
    ) {}

    private function snapshots(): SnapshotContext
    {
        return $this->snapshotContext;
    }
    ```
  - **Before** (`TeacherScheduleService.php:651`):
    ```php
    $rows = app(SubstitutionHistoryReader::class)->eachSource(fn () => DB::table('tt_substitution_logs as sl')
    ```
  - **After:**
    ```php
    $rows = $this->substitutionHistory->eachSource(fn () => DB::table('tt_substitution_logs as sl')
    ```
  - **Note:** the third `app(...)` site is line 227 inside `substitutionsToday()`; it is rewritten by MTD-05 (applied next) and must not be edited here, to keep the two items from overlapping.
  - **Verify:** `grep -n "app(SnapshotContext::class)\|app(SubstitutionHistoryReader::class)" Modules/TeacherPortal/app/Services/TeacherScheduleService.php`
  - **Expect:** only `227:        return app(SubstitutionHistoryReader::class)->eachSource(...)` remains (MTD-05 rewrites it).
  - **Effort:** S

## 3. Errors, transactions and service data shape (F1/F2/F8/F9)

- [ ] **MTD-05** · H · QRY-03 · `Modules/TeacherPortal/app/Services/TeacherScheduleService.php:227-248` — decorate the substitution rows so the Substitutions tab gets its period label and clock times.
  - **Touches:** `Modules/TeacherPortal/app/Services/TeacherScheduleService.php`
  - **Depends on:** MTD-10 (adds `$this->substitutionHistory`). Apply MTD-10 first.
  - **Before** (`TeacherScheduleService.php:227-248`):
    ```php
    return app(SubstitutionHistoryReader::class)->eachSource(fn () => DB::table('tt_substitution_logs as sl')
        ->join('tt_timetable_cells as c', 'c.id', '=', 'sl.cell_id')
        ->leftJoin('tt_activities as a', 'a.id', '=', 'c.activity_id')
        ->leftJoin('sch_classes as cl', 'cl.id', '=', 'a.class_id')
        ->leftJoin('sch_sections as sec', 'sec.id', '=', 'a.section_id')
        ->leftJoin('sch_subjects as sub', 'sub.id', '=', 'a.subject_id')
        ->leftJoin('sch_rooms as r', 'r.id', '=', 'c.room_id')
        ->leftJoin('sch_teachers as at', 'at.id', '=', 'sl.absent_teacher_id')
        ->leftJoin('sys_users as au', 'au.id', '=', 'at.user_id')
        ->where('sl.substitute_teacher_id', $ctx->teacherId)
        ->whereDate('sl.substitution_date', $date->toDateString())
        ->where('sl.is_active', true)
        ->whereNull('sl.deleted_at')
        ->orderBy('c.period_ord')
        ->get([
            'sl.id', 'sl.status', 'sl.reason',
            'c.timetable_id', 'c.day_of_week', 'c.period_ord',
            'a.class_id', 'a.section_id',
            'cl.name as class_name', 'sec.name as section_name',
            'sub.name as subject_name', 'r.name as room_name',
            'au.name as absent_teacher_name',
        ]))->sortBy('period_ord')->values();
    ```
  - **After:**
    ```php
    return $this->decorate($this->substitutionHistory->eachSource(fn () => DB::table('tt_substitution_logs as sl')
        ->join('tt_timetable_cells as c', 'c.id', '=', 'sl.cell_id')
        ->leftJoin('tt_activities as a', 'a.id', '=', 'c.activity_id')
        ->leftJoin('sch_classes as cl', 'cl.id', '=', 'a.class_id')
        ->leftJoin('sch_sections as sec', 'sec.id', '=', 'a.section_id')
        ->leftJoin('sch_subjects as sub', 'sub.id', '=', 'a.subject_id')
        ->leftJoin('sch_rooms as r', 'r.id', '=', 'c.room_id')
        ->leftJoin('sch_teachers as at', 'at.id', '=', 'sl.absent_teacher_id')
        ->leftJoin('sys_users as au', 'au.id', '=', 'at.user_id')
        ->where('sl.substitute_teacher_id', $ctx->teacherId)
        ->whereDate('sl.substitution_date', $date->toDateString())
        ->where('sl.is_active', true)
        ->whereNull('sl.deleted_at')
        ->orderBy('c.period_ord')
        ->get([
            'sl.id', 'sl.status', 'sl.reason',
            'c.timetable_id', 'c.day_of_week', 'c.period_ord',
            'a.class_id', 'a.section_id',
            'cl.name as class_name', 'sec.name as section_name',
            'sub.name as subject_name', 'r.name as room_name',
            'au.name as absent_teacher_name',
        ]))->sortBy('period_ord')->values());
    ```
  - **Verify:** `grep -n "return \$this->decorate(\$this->substitutionHistory" Modules/TeacherPortal/app/Services/TeacherScheduleService.php`
  - **Expect:** `227:        return $this->decorate($this->substitutionHistory->eachSource(fn () => DB::table('tt_substitution_logs as sl')`
  - **Effort:** S

## 4. Authorization (F3)

No plan item here. MTD-01 is a DECISION (route-file change) and lives in §9.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **MTD-03** · H · MDL-03 · `Modules/SchoolSetup/app/Models/Teacher.php:131-140` — exclude soft-deleted pivot rows from `timetableCells()`.
  - **Touches:** `Modules/SchoolSetup/app/Models/Teacher.php`
  - **Before** (`Teacher.php:131-140`):
    ```php
    public function timetableCells()
    {
        return $this->belongsToMany(
            TimetableCell::class,
            'tt_timetable_cell_teachers',
            'teacher_id',
            'cell_id'
        )->withPivot('assignment_role_id', 'is_substitute')
            ->withTimestamps();
    }
    ```
  - **After:**
    ```php
    public function timetableCells()
    {
        return $this->belongsToMany(
            TimetableCell::class,
            'tt_timetable_cell_teachers',
            'teacher_id',
            'cell_id'
        )->withPivot('assignment_role_id', 'is_substitute')
            ->wherePivotNull('deleted_at')
            ->withTimestamps();
    }
    ```
  - **Verify:** `grep -n "wherePivotNull('deleted_at')" Modules/SchoolSetup/app/Models/Teacher.php`
  - **Expect:** one line after this item (`timetableCells`); MTD-04 adds the second.
  - **Effort:** S

- [ ] **MTD-04** · H · MDL-03 · `Modules/SchoolSetup/app/Models/Teacher.php:145-154` — exclude soft-deleted pivot rows from `activities()`.
  - **Touches:** `Modules/SchoolSetup/app/Models/Teacher.php`
  - **Before** (`Teacher.php:145-154`):
    ```php
    public function activities()
    {
        return $this->belongsToMany(
            Activity::class,
            'tt_activity_teachers',
            'teacher_id',
            'activity_id'
        )->using(ActivityTeacher::class)
            ->withPivot('assignment_role_id', 'is_required', 'ordinal')
            ->withTimestamps();
    }
    ```
  - **After:**
    ```php
    public function activities()
    {
        return $this->belongsToMany(
            Activity::class,
            'tt_activity_teachers',
            'teacher_id',
            'activity_id'
        )->using(ActivityTeacher::class)
            ->withPivot('assignment_role_id', 'is_required', 'ordinal')
            ->wherePivotNull('deleted_at')
            ->withTimestamps();
    }
    ```
  - **Verify:** `grep -c "wherePivotNull('deleted_at')" Modules/SchoolSetup/app/Models/Teacher.php`
  - **Expect:** `2`
  - **Effort:** S

- [ ] **MTD-06** · M · MDL-02 · `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php:27-30` — cast the boolean flags.
  - **Touches:** `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php`
  - **Before** (`OrganizationAcademicSession.php:27-30`):
    ```php
    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date'
    ];
    ```
  - **After:**
    ```php
    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
        'is_current' => 'boolean',
        'is_active' => 'boolean',
        'current_flag' => 'boolean',
    ];
    ```
  - **Verify:** `grep -n "'is_current' => 'boolean'" Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php`
  - **Expect:** `30:        'is_current' => 'boolean',`
  - **Effort:** S

## 6. Queries and performance (F9)

- [ ] **MTD-09** · M · QRY-12 · `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php:92,11` — read the teacher photo from the user's media, not a non-existent `sch_teachers` column, and drop the redundant query and unused import.
  - **Touches:** `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php`
  - **Before** (`MobileTeacherDashboardController.php:92`):
    ```php
    'photo_url'           => Teacher::where('user_id', $user->id)->first()?->photo_url ?? null,
    ```
  - **After:**
    ```php
    'photo_url'           => $user->getFirstMediaUrl('user_img') ?: null,
    ```
  - **Before** (`MobileTeacherDashboardController.php:8-14`):
    ```php
    use Carbon\Carbon;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Support\Facades\Auth;
    use Modules\SchoolSetup\Models\Teacher;
    use Modules\TeacherPortal\Services\TeacherContext;
    use Modules\TeacherPortal\Services\TeacherDashboardService;
    use Modules\TeacherPortal\Services\TeacherScheduleService;
    ```
  - **After:**
    ```php
    use Carbon\Carbon;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Support\Facades\Auth;
    use Modules\TeacherPortal\Services\TeacherContext;
    use Modules\TeacherPortal\Services\TeacherDashboardService;
    use Modules\TeacherPortal\Services\TeacherScheduleService;
    ```
  - **Verify:** `grep -n "Teacher::\|use Modules\\\\SchoolSetup\\\\Models\\\\Teacher;" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

No plan item — this controller renders no Blade.

## 8. Style (F12) — one item per file

- [ ] **MTD-11** · L · STY-02 · `MobileTeacherDashboardController.php`, `Teacher.php`, `OrganizationAcademicSession.php` — run Pint so the three files are formatter-clean.
  - **Touches:** `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php`, `Modules/SchoolSetup/app/Models/Teacher.php`, `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php`
  - **Before** (`MobileTeacherDashboardController.php:45-46`):
    ```php
        $user = Auth::user();
        $ctx  = TeacherContext::for($user);
    ```
  - **After:**
    ```php
        $user = Auth::user();
        $ctx = TeacherContext::for($user);
    ```
  - **Note:** the remaining fixers are applied by the command below. On `Teacher.php` Pint also reorders the imports, changes `//begin` to `// begin`, `!$this` to `! $this`, adds a trailing comma and imports `Illuminate\Support\Facades\DB`; on `OrganizationAcademicSession.php` it switches `"..."` to `'...'`, adds a trailing comma and normalises the comment/blank lines.
  - **Verify:** `vendor/bin/pint Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php Modules/SchoolSetup/app/Models/Teacher.php Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php --test --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`
  - **Effort:** S

- [ ] **MTD-12** · L · STY-01 · `Teacher.php`, `OrganizationAcademicSession.php`, `User.php` — add `declare(strict_types=1);`.
  - **Touches:** `Modules/SchoolSetup/app/Models/Teacher.php`, `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php`, `Modules/SchoolSetup/app/Models/User.php`
  - **Before** (`Teacher.php:1-5`):
    ```php
    <?php

    namespace Modules\SchoolSetup\Models;

    use App\Models\BaseModel;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SchoolSetup\Models;

    use App\Models\BaseModel;
    ```
  - **Before** (`OrganizationAcademicSession.php:1-3`):
    ```php
    <?php

    namespace Modules\SchoolSetup\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SchoolSetup\Models;
    ```
  - **Before** (`User.php:1-3`):
    ```php
    <?php

    namespace Modules\SchoolSetup\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SchoolSetup\Models;
    ```
  - **Verify:** `grep -L "declare(strict_types=1);" Modules/SchoolSetup/app/Models/Teacher.php Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php Modules/SchoolSetup/app/Models/User.php`
  - **Expect:** no output (every file now contains the declaration).
  - **Effort:** S

- [ ] **MTD-13** · L · STY-04 · `TeacherContext.php`, `TeacherDashboardService.php`, `TeacherScheduleService.php`, `Teacher.php`, `User.php` — replace the `⛔`/`⚠` comment markers with the plain prefix `NOTE:`.
  - **Touches:** `Modules/TeacherPortal/app/Services/TeacherContext.php`, `Modules/TeacherPortal/app/Services/TeacherDashboardService.php`, `Modules/TeacherPortal/app/Services/TeacherScheduleService.php`, `Modules/SchoolSetup/app/Models/Teacher.php`, `Modules/SchoolSetup/app/Models/User.php`
  - **Before** (`TeacherContext.php:16-19`):
    ```php
     * Everything the dashboard needs to know about WHO is looking at it, resolved once.
     *
     * ⛔ THREE DIFFERENT IDs IDENTIFY ONE TEACHER, AND THEY ARE NOT INTERCHANGEABLE.
     * Getting this wrong returns an empty block rather than an error, which is why it is
    ```
  - **After:**
    ```php
     * Everything the dashboard needs to know about WHO is looking at it, resolved once.
     *
     * NOTE: THREE DIFFERENT IDs IDENTIFY ONE TEACHER, AND THEY ARE NOT INTERCHANGEABLE.
     * Getting this wrong returns an empty block rather than an error, which is why it is
    ```
  - **Before** (`Teacher.php:221`):
    ```php
     * ⛔ THIS USED TO CHECK `sys_users.is_active` AND THAT IS THE WRONG FLAG. When a
    ```
  - **After:**
    ```php
     * NOTE: THIS USED TO CHECK `sys_users.is_active` AND THAT IS THE WRONG FLAG. When a
    ```
  - **Before** (`User.php:62`):
    ```php
     * ⚠ On EDIT, the row's CURRENT type is added to this list when it is not already in
    ```
  - **After:**
    ```php
     * NOTE: On EDIT, the row's CURRENT type is added to this list when it is not already in
    ```
  - **Verify:** `grep -rcE '⛔|⚠' Modules/TeacherPortal/app/Services/TeacherContext.php Modules/TeacherPortal/app/Services/TeacherDashboardService.php Modules/TeacherPortal/app/Services/TeacherScheduleService.php Modules/SchoolSetup/app/Models/Teacher.php Modules/SchoolSetup/app/Models/User.php`
  - **Expect:** `0` for each of the five files.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **MTD-01** · M · DECISION · AUTH-01 — should the teacher mobile routes carry the `role:Teacher` gate that the web stack already applies?
  - **Why it is a decision:** it edits a route file (`routes/api.php`, ⚠ SHARED) and changes which accounts may call the endpoint.
  - (a) ⭐ Add `role:Teacher` to the teacher mobile route group in `routes/api.php` (the gate the web twin uses at `RouteServiceProvider.php:65`), keeping the controller's 403 as a second line of defence.
  - (b) Leave the controller's `sch_teachers` presence check as the only gate; record the deviation from AUTH-01 as accepted.
  - (c) Add the same `role:Teacher` middleware inside `Modules/TeacherPortal/routes/mobile_api.php` around the `teacher` prefix.
  - ➜ Choice: ____

- [ ] **MTD-02** · M · DECISION · CTL-02 — split the 137-line `dashboard()`?
  - **Why it is a decision:** a split is a DEFERRED decision under D3 and must not be applied in this pass.
  - (a) ⭐ Defer to the god-controller/split pass (D3): record and leave the method unchanged.
  - (b) Extract the payload now into a `TeacherDashboardPresenter` (new file; behaviour-preserving).
  - (c) Leave as is and record as accepted on the grounds that it is serialization, not logic.
  - ➜ Choice: ____

- [ ] **MTD-07** · H · DECISION · MDL-01 — remove `is_super_admin` from the tenant `User::$fillable`?
  - **Why it is a decision:** `Modules/SchoolSetup/app/Models/User.php` is used app-wide; removing a mass-assignable attribute can change any create/update path, and the flag mirrors the generated `super_admin_flag` column.
  - (a) ⭐ Remove `'is_super_admin'` from `$fillable` and set it only through an explicit, audited path.
  - (b) Leave it and document the exposure as accepted (SEC-002 stays open).
  - (c) Leave it in `$fillable` for now and add a guard where user input is mass-assigned (out of this controller's scope).
  - ➜ Choice: ____

- [ ] **MTD-08** · M · DECISION · MDL-04 — what should happen to `OrganizationAcademicSession::organization()`?
  - **Why it is a decision:** the relation guesses a foreign key (`organization_id`) that does not exist, and no caller was found; removing it versus repointing it is a product/data question.
  - (a) ⭐ Remove the dead relation (grep for callers first; none found as of 2026-10-14).
  - (b) Repoint it at the real link if one is intended (needs the correct foreign key named).
  - (c) Leave it and record as a known latent defect.
  - ➜ Choice: ____

## 10. Findings with no plan item

None — every finding (MTD-01 through MTD-13) has a plan item in §2, §3, §5, §6, §8 or §9 above.
