# Status — TeacherPortal / Mobile\MobileTeacherDashboardController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output |
|---|---|---|---|---|
| MTD-01 | `routes/api.php`, `Modules/TeacherPortal/routes/mobile_api.php` | Teacher mobile routes wrapped in `role:Teacher`, matching the web twin. | `route:list --json` middleware | `RoleMiddleware:Teacher` |
| MTD-03/04 | `SchoolSetup/Teacher.php` | Pivot relations exclude soft-deleted junction rows. | `grep wherePivotNull` | 2 hits |
| MTD-05 | `Services/TeacherScheduleService.php` | `substitutionsToday()` decorates rows (period label + clock times). | `grep "decorate(\$this->substitutionHistory"` | present |
| MTD-06 | `SchoolSetup/OrganizationAcademicSession.php` | Boolean casts for `is_current`/`is_active`/`current_flag`. | `grep "is_current' => 'boolean"` | present |
| MTD-07 | `SchoolSetup/User.php` | `is_super_admin` removed from `$fillable` (⭐ a). | `grep fillable` | absent |
| MTD-08 | `SchoolSetup/OrganizationAcademicSession.php` | Dead `organization()` relation removed (⭐ a). | `grep "function organization"` | none |
| MTD-09 | `MobileTeacherDashboardController.php` | Teacher photo from user media, not the non-existent column. | `grep "sch_teachers.*photo"` | none |
| MTD-10 | `Services/TeacherScheduleService.php` | `SnapshotContext` + `SubstitutionHistoryReader` constructor-injected. | `grep "app(SnapshotContext"` | none |
| MTD-11/12/13 | controller + 6 models/services | Pint-clean, `declare(strict_types=1)`, `⛔`/`⚠` markers replaced with `NOTE:`. | Pint / grep markers | passed / 0 |

## 3. Not applied / deferred
- **MTD-02** — accepted ⭐: 137-line `dashboard()` split deferred (D3).

## 4. Shared changes
- `routes/api.php` role:Teacher wrapper around the TeacherPortal mobile routes (applied here).

## 5. Verification
- Pint passed; `php -l` clean (7 files); route list boots; mobile routes carry `role:Teacher`; `view:cache` compiled.

## 6. Final state
FIXED. MTD-02 deferred.
