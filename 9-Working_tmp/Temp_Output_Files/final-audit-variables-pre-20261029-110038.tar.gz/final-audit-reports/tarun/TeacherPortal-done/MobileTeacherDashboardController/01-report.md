# Final Audit — TeacherPortal / MobileTeacherDashboardController

**Audited:** 2026-10-14 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php` (211 lines, 1 routed public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET https://{tenant}/api/mobile/v1/teacher/dashboard` (JSON) — the only page this controller serves |
| Menu path | PrimeAdmin mobile app → Teacher Portal → Dashboard (home screen) |
| Who uses it | Accounts that own a `sch_teachers` row (89 rows on the dev tenant). The web twin of this screen is gated by Spatie `role:Teacher` (85 users). No permission key is consulted. |
| What a user does here | Opens the teacher's home screen. The phone shows one screen of panels: today's own lessons, the weekly load strip, today's substitutions, the class-teacher's "My Class" day, recent homework and assessments, staff notices / circulars / events, PTM bookings, leave balances and applications, and this month's own attendance. |
| Tables written | None. The controller and both services are read-only (every call is `DB::table(...)->get()` / Eloquent `->first()`). |
| Tables read | `sch_teachers`, `sch_employees`, `sch_class_section_jnt`, `sch_classes`, `sch_sections`, `sch_org_academic_sessions_jnt`, `tt_timetables`, `tt_timetable_cells`, `tt_timetable_cell_teachers`, `tt_activities`, `tt_activity_teachers`, `tt_substitution_logs`, `tt_snap_*` (snapshot mirror), `tt_class_timetable_types_jnt`, `tt_period_set_periods_jnt`, `tt_period_configs`, `lms_homework`, `lms_quizzes`, `lms_quests`, `fof_notices`, `fof_circulars`, `fof_school_events`, `ptm_slot_bookings`, `ptm_slots`, `ptm_events`, `std_students`, `sch_employee_leave_balance`, `sch_employee_leave_applications`, `sch_staff_leave_types`, `sch_employee_attendance`, `sys_users`. |
| Live data | Per `SELECT COUNT(*)` on tenant `test.localhost` (2026-10-14): `sys_users` 5630 · `sch_teachers` 89 · `sch_employees` 139 · `sch_class_section_jnt` 43 · `tt_timetables` 5 · `tt_timetable_cells` 59,680 · `tt_timetable_cell_teachers` 4,559 · `tt_substitution_logs` 9 · `lms_homework` 558 · `lms_quizzes` 268 · `lms_quests` 244 · `fof_notices` 14 · `fof_circulars` 10 · `fof_school_events` 25 · `ptm_slot_bookings` 21 · `sch_employee_leave_balance` 623 · `sch_employee_leave_applications` 356 · `sch_employee_attendance` 890. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Almost production-ready; one high-value correctness bug.** The controller is thin, read-only, correctly tenant-scoped, and returns only the signed-in user's own data — no cross-user or cross-tenant leak was found. The one defect a teacher can see without special data is the **Substitutions tab** (MTD-05, H): the service returns rows that were never decorated, so a cover lesson renders with no period label and no clock time. A second visible defect is the teacher **photo** (MTD-09, M): it is read from `sch_teachers.photo_url`, a column that does not exist, so the avatar is permanently null and the controller pays a redundant query for it. The rest is debt: a hand-rolled authorization check instead of the module's own `role:Teacher` gate (MTD-01, M), a 137-line `dashboard()` (MTD-02, M), three real model-level soft-delete/cast/fillable defects in the pre-assigned models (MTD-03/04/06/07/08), service-locator calls (MTD-10, M) and style drift (MTD-11/12/13, L). Rough effort: **M — half a day** for the code items; the four DECISION items are one tick each.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 4 | 6 | 3 | 4 | 13 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | MTD-10 |
| F2 Transactions/Audit | clean (no writes) | F9 Queries/Perf | MTD-05, MTD-09 |
| F3 Authorization | MTD-01 | F10 Views | clean (no Blade) |
| F4 Validation | clean (no input) | F11 Security/Tenancy | clean (MTD-07 is model-level) |
| F5 Routes | clean | F12 Style | MTD-11, MTD-12, MTD-13 |
| F6 Controller shape | MTD-02 | F13 Deep read | table in §6 |
| F7 Models | MTD-03, MTD-04, MTD-06, MTD-07, MTD-08 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php` | controller | 211 | this report | ✅ |
| 2 | `Modules/TeacherPortal/app/Services/TeacherContext.php` | service | 227 | this report | ✅ |
| 3 | `Modules/TeacherPortal/app/Services/TeacherDashboardService.php` | service | 259 | this report | ✅ |
| 4 | `Modules/TeacherPortal/app/Services/TeacherScheduleService.php` | service | 936 | this report | ✅ |
| 5 | `Modules/SchoolSetup/app/Models/Teacher.php` | model | 512 | this report | ✅ |
| 6 | `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php` | model | 56 | this report | ✅ |
| 7 | `Modules/SchoolSetup/app/Models/User.php` | model | 317 | this report | ✅ |
| 8 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | 516 | ↗ [TimetableFoundation/TimetableController](../../../tarun/TimetableFoundation-done/TimetableController-done/01-report.md) — earlier registry claim wins; duplicate reconciled by main session 2026-10-14 | ↗ linked |
| 9 | `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | support | 342 | ↗ [tarun/StandardTimetable/StandardTimetableController-done](../../StandardTimetable-done/StandardTimetableController-done/01-report.md) | ↗ linked |
| 10 | `Modules/SmartTimetable/app/Services/SubstitutionHistoryReader.php` | service | 118 | ↗ [tarun/SmartTimetable/SubstitutionController](../../SmartTimetable-done/SubstitutionController-done/01-report.md) | ↗ linked |
| 11 | `Modules/TimetableFoundation/app/Services/PublishedTimetable.php` | service | 255 | ↗ [TimetableFoundation/TimetableFoundationController](../../../tarun/TimetableFoundation-done/TimetableFoundationController-done/01-report.md) | ↗ linked |

No pre-applied files: no `PRE-APPLIED-*.md` names any in-scope file.

Reached but not in scope (other-module models used only through the services, read-only): `Activity`, `TimetableCell`, `TimetableCellTeacher` (TimetableFoundation / SmartTimetable) — those are the services' collaborators, not this controller's.

## 4. Routes

```
GET|HEAD  api/mobile/v1/teacher/dashboard ......... Modules\TeacherPortal\Http\Controllers\Mobile\MobileTeacherDashboardController@dashboard
          middleware: api, App\Http\Middleware\ValidateMobileApiKey, App\Http\Middleware\InitializeTenancyByMobileHeader, Illuminate\Auth\Middleware\Authenticate:sanctum
```

Unrouted public methods: none. The only public method besides `__construct` is `dashboard()`, and it is routed. Source: `grep -nE 'public function [a-zA-Z_]+' <controller>` → `__construct` (line 37), `dashboard` (line 43).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `dashboard` | 43 | GET `api/mobile/v1/teacher/dashboard` | none — a hand-rolled `sch_teachers` presence check returning 403 (see MTD-01) | none (read-only) | none (read-only) | none (read-only) | MTD-01, MTD-02, MTD-05, MTD-09 |

## 6. Findings

### F1 — Errors

clean — `grep -nE "try \{|catch \(|getMessage|Log::error|->withErrors|report\(" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php Modules/TeacherPortal/app/Services/TeacherContext.php Modules/TeacherPortal/app/Services/TeacherDashboardService.php Modules/TeacherPortal/app/Services/TeacherScheduleService.php` → no output. There is no `try/catch` in any in-scope file (D1 holds), no exception text reaches the response, and no write path exists that could swallow a failure.

### F2 — Transactions and audit

clean (not applicable) — the controller and both services perform **no writes** (`grep -nE "->update\(|->insert\(|->create\(|->save\(|->delete\(|DB::transaction" <controller> <all three services>` → no output). Every statement is a read; a dashboard is a read path. TXN-01..06 have no target.

### F3 — Authorization

#### MTD-01 · M · AUTH-01 — the mobile route is gated by a hand-rolled presence check, not the module's own `role:Teacher`

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B) — *every routed controller method authorizes: `Gate::authorize`, `$this->authorize`, a `can:` route middleware, or a FormRequest `authorize()` that checks a permission*. Lowered to **M**: the controller does check authorization (a `sch_teachers` presence test returning **403**) and every returned block is keyed on the caller's own `sys_users.id` / `sch_teachers.id` / `sch_employees.id`, so no other person's data is reachable; the deviation is that it is not one of the four framework shapes and the mobile route lacks the `role:Teacher` gate the web twin uses. |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php:43-53`, method `dashboard()` |
| **Root cause** | The controller resolves `TeacherContext::for($user)` and returns a 403 only when `$ctx->teacherId === null`. The route (`Modules/TeacherPortal/routes/mobile_api.php:15-19`) is loaded under `routes/api.php:34` inside `mobile.key + tenant.mobile + auth:sanctum` and carries **no** `role:Teacher` middleware, although `Modules/TeacherPortal/app/Providers/RouteServiceProvider.php:65` applies exactly that gate to the web stack. |
| **Consequence** | Any authenticated user of the tenant (for example a parent or student with a valid mobile token) can call the endpoint; they receive a 403 JSON, but they still trigger the full dashboard query set before the rejection, and a future account that gains a `sch_teachers` row silently gains the teacher home screen without holding the `Teacher` role. |
| **Reproduce** | Send `GET /api/mobile/v1/teacher/dashboard` with a valid student/parent Bearer token plus `X-App-Key`/`X-School-Code`: HTTP 403 `{"status":"error","message":"This account is not linked to a teacher record."}` (expected 403, but no route-level role gate exists). |
| **Fix approach** | Add `role:Teacher` to the teacher mobile route group, so the gate matches the web stack and every other TeacherPortal screen. This is a route-file change: a DECISION (plan §9, ⚠ SHARED). |
| **Plan item** | MTD-01 in `02-fix-plan.md` §9 |

```php
// MobileTeacherDashboardController.php:43-53 — CURRENT
    public function dashboard(): JsonResponse
    {
        $user = Auth::user();
        $ctx  = TeacherContext::for($user);

        if ($ctx->teacherId === null) {
            return response()->json([
                'status'  => 'error',
                'message' => 'This account is not linked to a teacher record.',
            ], 403);
        }
```

**Evidence**
```
$ grep -nE "Gate::|->authorize\(|->can\(|role:" \
    Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php \
    Modules/TeacherPortal/routes/mobile_api.php
(no output)

$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '...'   # middleware for this route
GET|HEAD api/mobile/v1/teacher/dashboard
  middleware: api, App\Http\Middleware\ValidateMobileApiKey,
              App\Http\Middleware\InitializeTenancyByMobileHeader,
              Illuminate\Auth\Middleware\Authenticate:sanctum
  # no role middleware

$ grep -n "role:Teacher" Modules/TeacherPortal/app/Providers/RouteServiceProvider.php
65:            'role:Teacher',
```

### F4 — Validation and input

clean — the controller reads no request input: `grep -nE "request\(|->validate\(|->validated\(|->input\(|->all\(|Request \$" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php` → no output, and the route is a GET with no route parameters. VAL-01..07 have no target.

### F5 — Routes

clean — the single route points at a method that exists (`dashboard()`, controller line 43); it is a GET that changes no state; it is inside the tenant middleware (`InitializeTenancyByMobileHeader`); the route parameter list is empty so RTE-06 and the §3.3.1 unbound-model trap do not apply. Evidence: route block in §4 plus `grep -nE "public function [a-zA-Z_]+" <controller>` → `dashboard` at line 43.

### F6 — Controller shape

#### MTD-02 · M · CTL-02 — `dashboard()` is a 137-line method

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method over 80 lines → extract; over 150 lines is H* |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php:43-179`, method `dashboard()` |
| **Root cause** | The whole JSON payload is assembled inline: thirteen panels (teacher header, load strip, tabs, my_schedule, class_day, substitutions, homework, assessments, notices, circulars, events, ptm_bookings, leave, attendance) are mapped in one method body. It is serialization, so it is not CTL-06 business logic, but it is 137 lines against the 80-line guideline. |
| **Consequence** | A developer editing one panel must scroll a 137-line method; the three `->map(fn ($l) => $this->lesson($l))` call sites (lines 105, 107, 110) already drifted (see MTD-05) precisely because the shapes are assembled far apart. |
| **Reproduce** | Static only — the size is a property of the source, not of a running screen. |
| **Fix approach** | Extract the payload into a `TeacherDashboardPresenter` (or one private `payload()` method per panel group). A split is a DEFERRED decision under D3: recorded, not applied in this pass (plan §9). |
| **Plan item** | MTD-02 in `02-fix-plan.md` §9 |

```php
// MobileTeacherDashboardController.php:43-46 — CURRENT (method runs to line 179)
    public function dashboard(): JsonResponse
    {
        $user = Auth::user();
        $ctx  = TeacherContext::for($user);
```

**Evidence**
```
$ grep -nE "public function [a-zA-Z_]+" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php
37:    public function __construct(
43:    public function dashboard(): JsonResponse

$ sed -n '179p' Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php
    }

# dashboard() spans lines 43..179 = 137 lines
```

### F7 — Models

#### MTD-03 · H · MDL-03 — `Teacher::timetableCells()` ignores soft-deleted pivot rows

| Field | Value |
|---|---|
| **Rule** | MDL-03 (H) — *a `belongsToMany` over a pivot table that has `deleted_at` must add `->wherePivotNull('deleted_at')`, or removed rows still count as members* |
| **Where** | `Modules/SchoolSetup/app/Models/Teacher.php:131-140`, method `timetableCells()` |
| **Root cause** | The pivot `tt_timetable_cell_teachers` has a `deleted_at` column (verified live), but the relation declares only `withPivot(...)` and `withTimestamps()`. A soft-deleted assignment row therefore remains a member of `$teacher->timetableCells`. |
| **Consequence** | Any screen that reads a teacher's cells through this relation (the scope `scopeForTimetable`, the workload helpers) counts lessons the school has removed, inflating a teacher's timetable/load by stale rows. |
| **Reproduce** | Static only — proving it needs a soft-deleted pivot row; the DDL/live schema proves the column exists (evidence below). |
| **Fix approach** | Add `->wherePivotNull('deleted_at')` to the relation (plan §5, MTD-03). |
| **Plan item** | MTD-03 in `02-fix-plan.md` §5 |

```php
// Teacher.php:131-140 — CURRENT
    public function timetableCells()
    {
        return $this->belongsToMany(
            TimetableCell::class,
            'tt_timetable_cell_teachers',
            'teacher_id',
            'cell_id'
        )->withPivot('assignment_role_id', 'is_substitute')
            ->withTimestamps();
    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-teacherportal.json Modules/SchoolSetup/app/Models/Teacher.php
H  MDL-03   Modules/SchoolSetup/app/Models/Teacher.php:131  timetableCells — belongsToMany over soft-delete pivot 'tt_timetable_cell_teachers' without wherePivotNull('deleted_at')

$ php artisan tinker --execute '... SHOW COLUMNS FROM tt_timetable_cell_teachers ...'
tt_timetable_cell_teachers : id,is_substitute,is_active,cell_id,teacher_id,assignment_role_id,created_at,updated_at,deleted_at
```

#### MTD-04 · H · MDL-03 — `Teacher::activities()` ignores soft-deleted pivot rows

| Field | Value |
|---|---|
| **Rule** | MDL-03 (H) — *a `belongsToMany` over a pivot table that has `deleted_at` must add `->wherePivotNull('deleted_at')`* |
| **Where** | `Modules/SchoolSetup/app/Models/Teacher.php:145-154`, method `activities()` |
| **Root cause** | Same as MTD-03, on the `tt_activity_teachers` pivot (which also has `deleted_at` live). |
| **Consequence** | A teacher's activity list keeps activities that were unassigned, so any count or dropdown built from `$teacher->activities` over-reports. |
| **Reproduce** | Static only — the live schema proves the pivot has `deleted_at`. |
| **Fix approach** | Add `->wherePivotNull('deleted_at')` to the relation (plan §5, MTD-04). |
| **Plan item** | MTD-04 in `02-fix-plan.md` §5 |

```php
// Teacher.php:145-154 — CURRENT
    public function activities()
    {
        return $this->belongsToMany(
            Activity::class,
            'tt_activity_teachers',
            'teacher_id',
            'activity_id'
        )->using(ActivityTeacher::class)
            ->withPivot('assignment_role_id', 'is_required', 'ordinal')
            ->withTimestamps();
    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-teacherportal.json Modules/SchoolSetup/app/Models/Teacher.php
H  MDL-03   Modules/SchoolSetup/app/Models/Teacher.php:145  activities — belongsToMany over soft-delete pivot 'tt_activity_teachers' without wherePivotNull('deleted_at')

$ php artisan tinker --execute '... SHOW COLUMNS FROM tt_activity_teachers ...'
tt_activity_teachers : id,is_required,ordinal,is_active,activity_id,teacher_id,assignment_role_id,created_at,updated_at,deleted_at
```

#### MTD-05 · H · QRY-03 — the Substitutions tab renders lessons with no period label and no clock time

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M) — *select only the columns you use*; here the substitution query selects **too few** (the period fields are omitted), so the serializer reads absent properties. Raised to **H**: it is a silent wrong result on a real screen, not a query-shape nicety. |
| **Where** | `Modules/TeacherPortal/app/Services/TeacherScheduleService.php:241-248` (producer), consumed by `MobileTeacherDashboardController.php:182-194` `lesson()` |
| **Root cause** | `substitutionsToday()` returns raw query rows and never calls the file's own `decorate()` helper (line 851). `decorate()` is what stamps `period_label`, `start_time` and `end_time` onto each row. The controller serializes all three lesson sources through the same `lesson()` method (`MobileTeacherDashboardController.php:105,107,110`), which reads `$l->period_label`, `$l->start_time` and `$l->end_time` — properties that exist on `my_schedule` and `class_day` rows but not on substitution rows. |
| **Consequence** | A teacher who is covering a lesson opens the Substitutions tab and sees a lesson card with the subject and room, but a blank period and blank start/end times. Verified live: teacher 81 has two cover rows on 2026-10-12 and both serialize with `period_label=NULL start=NULL`. |
| **Reproduce** | Static + service call: `php artisan tinker` → `TeacherScheduleService::substitutionsToday($ctx, Carbon::parse('2026-10-12'))` for the user of teacher 81 (user 84) returns 2 rows with keys `id,status,reason,timetable_id,day_of_week,period_ord,class_id,section_id,class_name,section_name,subject_name,room_name,absent_teacher_name` — no `period_label`/`start_time`/`end_time`. |
| **Fix approach** | Wrap the returned collection in the service's existing `decorate()` call (plan §3, MTD-05). Requires the constructor added by MTD-10. |
| **Plan item** | MTD-05 in `02-fix-plan.md` §3 |

```php
// TeacherScheduleService.php:241-248 — CURRENT (return of substitutionsToday())
            ->get([
                'sl.id', 'sl.status', 'sl.reason',
                'c.timetable_id', 'c.day_of_week', 'c.period_ord',
                'a.class_id', 'a.section_id',
                'cl.name as class_name', 'sec.name as section_name',
                'sub.name as subject_name', 'r.name as room_name',
                'au.name as absent_teacher_name',
            ]))->sortBy('period_ord')->values();
```

**Evidence**
```
$ php artisan tinker --execute '... $svc->substitutionsToday($ctx, Carbon::parse("2026-10-12")) ...'
count=2
keys: id,status,reason,timetable_id,day_of_week,period_ord,class_id,section_id,class_name,section_name,subject_name,room_name,absent_teacher_name
period_ord=2 subject=Conversation period_label=NULL start=NULL has_conflict=NULL
period_ord=8 subject=Conversation period_label=NULL start=NULL has_conflict=NULL

$ sed -n '182,194p' Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php
    private function lesson($l): array
    {
        return [
            'period'      => $l->period_ord,
            'period_label' => $l->period_label,
            'start'       => $l->start_time,
            'end'         => $l->end_time,
            ...
```

#### MTD-06 · M · MDL-02 — `OrganizationAcademicSession` does not cast its boolean flags

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` for every boolean, date/datetime, decimal, json/array, enum column* |
| **Where** | `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php:27-30`, property `$casts` |
| **Root cause** | `sch_org_academic_sessions_jnt` stores `is_current`, `is_active` and `current_flag` as `tinyint(1)` (verified live), but `$casts` declares only `start_date` and `end_date`. |
| **Consequence** | `OrganizationAcademicSession::where('is_current', true)` is handed to the DB as an integer, and any Eloquent consumer of `$session->is_current` gets `0`/`1` not `false`/`true` — a strict `=== true` check reads false. (This controller uses the raw `where('is_current', true)->value(...)` path, which is unaffected.) |
| **Reproduce** | Static only — the live schema proves the column types. |
| **Fix approach** | Add the three boolean casts (plan §5, MTD-06). |
| **Plan item** | MTD-06 in `02-fix-plan.md` §5 |

```php
// OrganizationAcademicSession.php:27-30 — CURRENT
    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date'
    ];
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-teacherportal.json Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php
M  MDL-02   Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php:16  -  OrganizationAcademicSession: no cast for is_current, is_active

$ php artisan tinker --execute '... SHOW COLUMNS FROM sch_org_academic_sessions_jnt ...'
sch_org_academic_sessions_jnt : id,academic_session_id,short_name,name,start_date,end_date,is_current,is_active,current_flag,created_at,updated_at,deleted_at
```

#### MTD-07 · H · MDL-01 — `User::$fillable` includes `is_super_admin`

| Field | Value |
|---|---|
| **Rule** | MDL-01 (H) — *`$fillable` declared; never `$guarded = []`; nothing sensitive in it* |
| **Where** | `Modules/SchoolSetup/app/Models/User.php:110` (inside the `$fillable` array at 105-123), property `$fillable` |
| **Root cause** | `is_super_admin` is listed as mass-assignable. Any controller or seeder that passes request data to `User::create()`/`->update()` (the pattern SEC-002 in `AGENTS.md` records app-wide) can set a tenant user's `is_super_admin` flag. This is a model-wide defect, not caused by this controller — this controller only reads `$user->name`, `emp_code`, `short_name`, `id`. |
| **Consequence** | A user who can reach any user-create/update form that fills from request input can grant themselves `is_super_admin` (the generated `super_admin_flag` column mirrors it), the app's highest privilege. |
| **Reproduce** | Static only — an exploit needs a specific write endpoint; the report is that the flag is reachable by mass assignment at all. |
| **Fix approach** | Remove `'is_super_admin'` from `$fillable` and set it only through an explicit, audited path. It is an app-wide model, so this is a DECISION (plan §9, MTD-07). |
| **Plan item** | MTD-07 in `02-fix-plan.md` §9 |

```php
// User.php:116-118 — CURRENT (slice of the $fillable array)
        'password',
        'is_super_admin',
        'is_active',
```

**Evidence**
```
$ sed -n '105,123p' Modules/SchoolSetup/app/Models/User.php
    protected $fillable = [
        'name',
        ...
        'password',
        'is_super_admin',
        'is_active',
        'last_login_at',
        'remember_token',
        'prefered_language',
        'is_pg_user',
    ];

$ php artisan tinker --execute '... SHOW COLUMNS FROM sys_users ...'
sys_users : ... is_super_admin, last_login_at, super_admin_flag, remember_token, ...
```

#### MTD-08 · M · MDL-04 — `OrganizationAcademicSession::organization()` guesses a foreign key that does not exist

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed*; raised to **M** because this relation is not merely untyped — it is broken: `belongsTo(Organization::class)` with no explicit key defaults to `organization_id`, and `sch_org_academic_sessions_jnt` has no such column. |
| **Where** | `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php:35-38`, method `organization()` |
| **Root cause** | The join table `sch_org_academic_sessions_jnt` (live columns: `id, academic_session_id, short_name, name, start_date, end_date, is_current, is_active, current_flag, created_at, updated_at, deleted_at`) contains no `organization_id`, so the relation would emit `where organization_id = ?` and fail with SQLSTATE 42S22 (unknown column) the first time it is ever loaded. |
| **Consequence** | Latent: no caller in the repository was found (see Evidence), so nothing fails today. The first developer who eager-loads `->with('organization')` gets a 500 with no warning that the relation was never usable. |
| **Reproduce** | Static only — the live `SHOW COLUMNS` output is the proof. |
| **Fix approach** | Remove the dead relation, or point it at the real link if one is intended. Because the intent cannot be read from the code, this is a DECISION (plan §9, MTD-08). |
| **Plan item** | MTD-08 in `02-fix-plan.md` §9 |

```php
// OrganizationAcademicSession.php:35-38 — CURRENT
    public function organization()
    {
        return $this->belongsTo(Organization::class);
    }
```

**Evidence**
```
$ php artisan tinker --execute '... SHOW COLUMNS FROM sch_org_academic_sessions_jnt ...'
sch_org_academic_sessions_jnt : id,academic_session_id,short_name,name,start_date,end_date,is_current,is_active,current_flag,created_at,updated_at,deleted_at
  # no organization_id

$ grep -rn "academicSession->organization\|OrganizationAcademicSession::.*->organization" Modules/ app/
(no output — no caller found)
```

#### MTD-09 · M · QRY-12 — the teacher photo is read from a column that does not exist, and `sch_teachers` is queried twice

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) — *identical queries repeated in one request → resolve once*. Also a silent-null attribute read (the `??` on a column that does not exist is null forever). |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php:92` (inside the `teacher` block at 87-93) |
| **Root cause** | `Teacher::where('user_id', $user->id)->first()?->photo_url` reads `sch_teachers.photo_url`, which is not a column of `sch_teachers` (live columns end at `deleted_at`; there is no `photo_url` anywhere in the schema). `TeacherContext::for()` has *already* fetched this same `sch_teachers` row (`TeacherContext.php:53-56`), so the line pays a second round-trip for a value that is always null. |
| **Consequence** | The mobile teacher header receives `photo_url: null` on every request — the avatar never renders — and each dashboard call issues one avoidable `sch_teachers` query. The value the app wants lives on the user's Spatie media (`user_img`), the pattern other mobile controllers use (`MobileChatParticipantController.php:41`). |
| **Reproduce** | Static + query count: the line is always `null` because the attribute is absent; `grep -n "Teacher::" <controller>` shows it is the only `Teacher` use. |
| **Fix approach** | Read the photo from the user's media instead: `$user->getFirstMediaUrl('user_img') ?: null`, and drop the now-unused `Teacher` import (plan §6, MTD-09). |
| **Plan item** | MTD-09 in `02-fix-plan.md` §6 |

```php
// MobileTeacherDashboardController.php:87-93 — CURRENT
            'teacher' => [
                'name'                => $user->name,
                'emp_code'            => $user->emp_code ?? $user->short_name,
                'is_class_teacher'    => $ctx->isClassTeacher(),
                'class_teacher_label' => $ctx->classTeacherLabel(),
                'photo_url'           => Teacher::where('user_id', $user->id)->first()?->photo_url ?? null,
            ],
```

**Evidence**
```
$ php artisan tinker --execute '... SHOW COLUMNS FROM sch_teachers ...'
sch_teachers : id,user_id,joining_date,total_experience_years,highest_qualification,specialization,last_institution,awards,skills,qualifications_json,certifications_json,experiences_json,notes,created_at,updated_at,deleted_at
  # no photo_url

$ grep -n "Teacher::" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php
92:                'photo_url'           => Teacher::where('user_id', $user->id)->first()?->photo_url ?? null,

$ grep -rn "getFirstMediaUrl('user_img')" Modules/ --include=*.php | head -1
Modules/CommonChat/app/Http/Controllers/Mobile/MobileChatParticipantController.php:41: 'avatar' => $p->user?->getFirstMediaUrl('user_img') ?: null,
```

### F8 — Services and jobs

#### MTD-10 · M · SVC-02 — `TeacherScheduleService` resolves its dependencies with `app()`, not constructor injection

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection — not `new FooService()` or `app(Foo::class)` mid-method* |
| **Where** | `Modules/TeacherPortal/app/Services/TeacherScheduleService.php:55-58`, methods `snapshots()`, `substitutionsToday()` (line 227) and `substitutionGrid()` (line 651) |
| **Root cause** | The service has no constructor. It fetches `SnapshotContext` through a private helper (`app(SnapshotContext::class)`, line 57) and `SubstitutionHistoryReader` through `app(...)` at the two call sites (lines 227, 651). Both are already resolved from the container, so constructor injection changes no behaviour. |
| **Consequence** | The class's dependency list is invisible from its signature, `SnapshotContext` is re-resolved from the container on each call instead of once per request, and the class cannot be constructed with a test double. This is the same module-wide pattern other reports already logged (`TimetableWorkspaceController` TWK-05, `MobileParentController` MPC-07) — here on the service the teacher dashboard actually calls. |
| **Reproduce** | Static only — it is a structural property of the class. |
| **Fix approach** | Add a constructor injecting `SnapshotContext` and `SubstitutionHistoryReader`; return the injected instance from `snapshots()`; replace the two `app(...)` reader call sites (plan §2, MTD-10). |
| **Plan item** | MTD-10 in `02-fix-plan.md` §2 |

```php
// TeacherScheduleService.php:55-58 — CURRENT
    private function snapshots(): SnapshotContext
    {
        return app(SnapshotContext::class);
    }
```

**Evidence**
```
$ grep -n "app(SnapshotContext::class)\|app(SubstitutionHistoryReader::class)" \
    Modules/TeacherPortal/app/Services/TeacherScheduleService.php
57:        return app(SnapshotContext::class);
227:        return app(SubstitutionHistoryReader::class)->eachSource(fn () => DB::table('tt_substitution_logs as sl')
651:        $rows = app(SubstitutionHistoryReader::class)->eachSource(fn () => DB::table('tt_substitution_logs as sl')

$ grep -rn "new TeacherScheduleService" Modules/ app/
(no output — safe to add a constructor; it is only resolved by the container)
```

### F9 — Queries and performance

MTD-05 and MTD-09 are recorded above under F7/F9 split: MTD-05 is the substitution under-select (listed here), MTD-09 the duplicate lookup (listed under F7 for its column root cause). Additional scanner candidates dismissed after reading the source:

- QRY-01 `TeacherScheduleService.php:74` (`cellTeachers`): the loop iterates **snapshot sources**, not result rows — one query per source (1–3 here), and a builder must be created per source because a `SnapshotContext` grammar is source-specific. Not an N+1.
- QRY-01 `TeacherScheduleService.php:725` (`periodAxis`) and `:898` (`periodMap`): the loop iterates **distinct timetables** (1–5 here; the dashboard path reaches `periodMap` through `decorate()` with typically one timetable), not rows. Bounded by config, not by data volume. Not an N+1.
- QRY-11 `TeacherDashboardService.php:68`: `DB::raw("'{$kind}' as kind")` interpolates `$kind`, but `$kind` is only ever the two hard-coded literals passed by the local closure (`'Quiz'`, `'Quest'`) at lines 71-72 — never request input. Not QRY-11.

Evidence for the dismissals: `sed -n '67,74p' Modules/TeacherPortal/app/Services/TeacherScheduleService.php` (loop over `$bySource`), `sed -n '719,739p'` (loop over `$scopes`), `sed -n '57,75p' Modules/TeacherPortal/app/Services/TeacherDashboardService.php` (literal `$kind`).

### F10 — Views

clean (not applicable) — this controller renders no Blade: `grep -oE "view\(['\"]" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php` → no output; it returns `response()->json(...)` only. VIEW-01..03 and the UI standards have no target.

### F11 — Security and tenancy

clean — `grep -n "env(" <controller> <three services>` → no output (no `env()` outside config); the controller returns mapped arrays, never a raw Eloquent model (`response()->json` bodies are literal arrays); no hard-coded ids or `?? 1`; no `Log::` calls at all; no caching layer, so no un-tenanted cache key. Every query runs on the tenant connection established by `InitializeTenancyByMobileHeader`. (The `is_super_admin` exposure is a model-level issue recorded as MTD-07, not a controller tenancy defect.)

### F12 — Style

#### MTD-11 · L · STY-02 — three in-scope files are not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php` (lines 45-46 shown), plus `Modules/SchoolSetup/app/Models/Teacher.php` and `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php` |
| **Root cause** | The files were hand-aligned and never formatted: the controller aligns `=>`/`=` with extra spaces (Pint's `binary_operator_spaces`), `Teacher.php` has `!$this`, `//begin`, a trailing-comma and an import-order issue, and `OrganizationAcademicSession.php` uses double quotes and a missing trailing comma. |
| **Consequence** | No user effect; diffs are noisy and a future `pint --dirty` reformats these files inside an unrelated change. |
| **Reproduce** | Static only. |
| **Fix approach** | Run Pint on the three files (plan §8, MTD-11). |
| **Plan item** | MTD-11 in `02-fix-plan.md` §8 |

```php
// MobileTeacherDashboardController.php:45-46 — CURRENT
        $user = Auth::user();
        $ctx  = TeacherContext::for($user);
```

**Evidence**
```
$ vendor/bin/pint --test Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherDashboardController.php \
    Modules/SchoolSetup/app/Models/Teacher.php Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php
{"tool":"pint","result":"fail","files":[
  {"path":".../MobileTeacherDashboardController.php","fixers":["concat_space","braces_position","single_line_empty_body","binary_operator_spaces"]},
  {"path":".../Teacher.php","fixers":["fully_qualified_strict_types","single_line_comment_spacing","trailing_comma_in_multiline","not_operator_with_successor_space","blank_line_before_statement","ordered_imports","single_blank_line_at_eof"]},
  {"path":".../OrganizationAcademicSession.php","fixers":["single_quote","single_line_comment_spacing","trailing_comma_in_multiline","no_extra_blank_lines"]}]}
```

#### MTD-12 · L · STY-01 — three in-scope models are missing `declare(strict_types=1);`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `Modules/SchoolSetup/app/Models/Teacher.php:1`, plus `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php:1`, `Modules/SchoolSetup/app/Models/User.php:1` |
| **Root cause** | These pre-existing model files never declared strict types; the three new TeacherPortal services and the controller do. |
| **Consequence** | None today; the module is inconsistent, and a touched file is expected to gain the declaration. ⚠ Adding strict types to an old file can surface latent type coercions, so each file should be re-checked after the change. |
| **Reproduce** | Static only. |
| **Fix approach** | Insert `declare(strict_types=1);` after the opening tag in each file (plan §8, MTD-12). |
| **Plan item** | MTD-12 in `02-fix-plan.md` §8 |

```php
// Teacher.php:1-5 — CURRENT
<?php

namespace Modules\SchoolSetup\Models;

use App\Models\BaseModel;
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-teacherportal.json \
    Modules/SchoolSetup/app/Models/Teacher.php Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php \
    Modules/SchoolSetup/app/Models/User.php | grep STY-01
L  STY-01   Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php:1  -  missing declare(strict_types=1)
L  STY-01   Modules/SchoolSetup/app/Models/Teacher.php:1  -  missing declare(strict_types=1)
L  STY-01   Modules/SchoolSetup/app/Models/User.php:1  -  missing declare(strict_types=1)
```

#### MTD-13 · L · STY-04 — emoji comment markers across the in-scope files

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers, no commented-out code* |
| **Where** | `Modules/TeacherPortal/app/Services/TeacherContext.php:18` (shown), plus `TeacherDashboardService.php`, `TeacherScheduleService.php`, `Teacher.php` and `User.php` |
| **Root cause** | The house emoji prefixes `⛔` and `⚠` were used as comment markers throughout the TeacherPortal services and the pre-assigned models. Evidence from the scanner lists 40+ such lines. |
| **Consequence** | No runtime effect; a style-rule violation that also makes the comments harder to search. |
| **Reproduce** | Static only. |
| **Fix approach** | Replace `⛔`/`⚠` with the plain prefix `NOTE:` (plan §8, MTD-13). |
| **Plan item** | MTD-13 in `02-fix-plan.md` §8 |

```php
// TeacherContext.php:16-19 — CURRENT
 * Everything the dashboard needs to know about WHO is looking at it, resolved once.
 *
 * ⛔ THREE DIFFERENT IDs IDENTIFY ONE TEACHER, AND THEY ARE NOT INTERCHANGEABLE.
 * Getting this wrong returns an empty block rather than an error, which is why it is
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-teacherportal.json Modules/TeacherPortal/app/Services/ | grep STY-04
L  STY-04   Modules/TeacherPortal/app/Services/TeacherContext.php:18  -  emoji in comment
L  STY-04   Modules/TeacherPortal/app/Services/TeacherContext.php:31  -  emoji in comment
L  STY-04   Modules/TeacherPortal/app/Services/TeacherContext.php:82  -  emoji in comment
L  STY-04   Modules/TeacherPortal/app/Services/TeacherDashboardService.php:15  -  emoji in comment
L  STY-04   Modules/TeacherPortal/app/Services/TeacherScheduleService.php:18  -  emoji in comment
L  STY-04   Modules/SchoolSetup/app/Models/Teacher.php:221  -  emoji in comment
L  STY-04   Modules/SchoolSetup/app/Models/User.php:62  -  emoji in comment
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There are **no mutating methods** in scope: the controller and both services only read. The table answers every question for the one routed method anyway (all rows `ok` because nothing is written).

| Method | 1. Write overwrites? | 2. Delete before store? | 3. Duplicate impl? | 4. Soft-delete × unique? | 5. Race? | 6. Auth hole? | 7. Message lies? | 8. Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `dashboard` (read-only) | ok — no writes | ok — nothing deleted | ok — one serialiser (`lesson()`) reused; the drift it caused is MTD-05 | ok — no create/restore | ok — no check-then-act | MTD-01 | ok — no flash/event text; the `photo_url` field is a lying contract (MTD-09) | note — MTD-05 makes the Substitutions tab mis-render, but it is reachable, not dead |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | Linked owner report [tarun/StandardTimetable/StandardTimetableController-done](../../StandardTimetable-done/StandardTimetableController-done/01-report.md). This controller reaches it only through `TeacherScheduleService`; usage is correct (every query is built inside the `partition()`/`run()` closure) and it carries no defect introduced here. | — | StandardTimetableController report |
| `Modules/SmartTimetable/app/Services/SubstitutionHistoryReader.php` | Linked owner report [tarun/SmartTimetable/SubstitutionController](../../SmartTimetable-done/SubstitutionController-done/01-report.md). `eachSource()` is called correctly at `TeacherScheduleService.php:227,651`. | — | SubstitutionController report |
| `Modules/TimetableFoundation/app/Services/PublishedTimetable.php` | Linked owner report [TimetableFoundation/TimetableFoundationController](../../../tarun/TimetableFoundation-done/TimetableFoundationController-done/01-report.md). Reached via `TeacherScheduleService::today()/classDay()`; `idFor()` is used with the session id and dates, matching its documented rule. | — | TimetableFoundationController report |
| `Modules/TimetableFoundation/app/Models/Timetable.php` | **Reconciled 2026-10-14:** the earlier registry claim (`TimetableFoundation/TimetableController`) wins, so this model is owned by [TimetableFoundation/TimetableController](../../../tarun/TimetableFoundation-done/TimetableController-done/01-report.md) and is `↗ linked` in §3. This controller uses it read-only (`published()` + `pluck('id')`); any model-level STY finding belongs to the owner report. | — | TimetableFoundationController report |
| `Modules/SchoolSetup/app/Models/User.php` | The `is_super_admin` mass-assignment exposure (MTD-07) is app-wide (SEC-002 in `AGENTS.md`), not specific to this controller. Any fix touches the tenant user model shared by every module. | MDL-01 | Tarun / whole app |

## 8. Not covered, and why

- **`TeacherScheduleService` methods not on the dashboard path** — `grid()`, `classGrids()`, `periodAxis()`, `periodRows`/`dayRows()` and `substitutionGrid()` are never called by this controller (verified: the controller calls only `today()`, `weekLoad()`, `substitutionsToday()`, `classDay()`). They were read at class level and their scanner hits are recorded in F9, but they are exercised by the web `TeacherPortalController`, not by this screen.
- **Queue jobs, listeners and events** — the module's `EventServiceProvider` was not touched by this controller; `grep -nE "dispatch\(|ShouldQueue|Job"` over the in-scope files returns nothing, so JOB-01..05 have no target.
- **Runtime rendering of the mobile client** — D4 forbids testing, so the JSON was inspected by calling the services from `tinker` (SELECT only); the phone UI itself was not run.
- **The Substitutions tab on the audit date** — on 2026-10-14 no substitution row falls on today's date (the nine rows are dated 2026-10-10/12), so the bug was reproduced by calling `substitutionsToday()` for 2026-10-12 rather than for today.
- **A live soft-deleted pivot row** — MTD-03/MTD-04 were confirmed from the schema and the scanner, not by deleting a pivot row (writes are banned).
