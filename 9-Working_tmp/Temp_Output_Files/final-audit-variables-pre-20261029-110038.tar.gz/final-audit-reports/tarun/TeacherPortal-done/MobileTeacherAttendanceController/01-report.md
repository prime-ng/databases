# Final Audit — TeacherPortal / MobileTeacherAttendanceController

**Audited:** 2026-10-14 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php` (295 lines, 5 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/api/mobile/v1/teacher/attendance` (GET register, POST save) · `/teacher/attendance/sections` · `/teacher/attendance/leaves` · `/teacher/attendance/leaves/{application}/review` |
| Menu path | PrimeAdmin mobile app → Class Attendance (a port of the web page `teacher-portal/attendance`) |
| Who uses it | The `Teacher` role. The route stack is `mobile.key` + `tenant.mobile` + `auth:sanctum`; there is **no permission** and no `role:Teacher` middleware. Access is decided inside the controller: any authenticated user who is class teacher (or assistance class teacher) of at least one section passes; everyone else gets 403. |
| What a user does here | A teacher opens the day's register for one of their class-sections, marks each student Present/Absent/Late/Half Day/Short Leave/Leave with an optional remark, and saves. The same section drives a second half: the student leave applications waiting on that teacher, which the teacher can move to Under Review, Info Requested, Doc Requested, Approved or Rejected. |
| Tables written | `std_student_attendance` (register save, and leave approval) · `std_leave_applications` (status/review fields) · `std_leave_application_remarks` (status-change + teacher request rows) · `sys_activity_logs` (via `activityLog`) |
| Tables read | `sch_class_section_jnt`, `sch_classes`, `sch_sections`, `sch_teachers`, `sch_employees`, `std_student_academic_sessions`, `std_students`, `sys_users`, `std_student_attendance`, `std_leave_applications`, `std_leave_types`, `std_leave_application_remarks`, `std_leave_application_documents` |
| Live data | tenant `00000000-0000-4000-8000-000000000001`: `std_student_attendance` 209 · `std_leave_applications` 4 · `sch_class_section_jnt` 43 · `sch_teachers` 89 |

**How to reach each bug in the browser:** each finding lists its own **Reproduce** line. All five endpoints are JSON under `/api/mobile/v1` and are called by the mobile app, not by a browser page.

## 1. Verdict

This controller is small, readable and, on the happy path, correct: the ownership rule is centralised in the services, the soft-delete/unique-index trap on `std_student_attendance` is handled explicitly in the register save, and validation covers every submitted field. It is **not** production-ready without the two High items, but the blockers are narrow rather than systemic.

The single worst finding is **MTA-09** — student-leave approval marks `std_student_attendance` with `updateOrCreate()` keys that do **not** mirror the table's real unique index `uq_std_att_student_date (student_id, attendance_date, attendance_period)`, so on a day where that key already exists with a different `academic_session_id` the whole review transaction dies with SQLSTATE 23000, and on a trashed row the write silently lands on a row the register never reads. The register save itself has the mirror-image problem (**MTA-08**): it writes one row per student with a select-then-insert, which is both an N+1 and a check-then-act race.

Rough effort: **M** overall (about a day). Two High items, six Medium, four Low, and two DECISION items to be answered by Tarun.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 6 | 4 | 2 | 12 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | MTA-01 | F8 Services/Jobs | MTA-07 |
| F2 Transactions/Audit | MTA-02, MTA-03 | F9 Queries/Perf | MTA-08, MTA-09 |
| F3 Authorization | MTA-04 | F10 Views | clean |
| F4 Validation | MTA-05 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | MTA-10, MTA-11 |
| F6 Controller shape | MTA-06, MTA-12 | F13 Deep read | MTA-09 part two |
| F7 Models | clean (all linked) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php` | controller | 295 | this report | ✅ |
| 2 | `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php` | service | 240 | this report | ✅ |
| 3 | `Modules/TeacherPortal/app/Services/TeacherStudentLeaveService.php` | service | 234 | this report | ✅ |
| 4 | `Modules/StudentProfile/app/Services/LeaveService.php` | service | 683 | ↗ [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController-done/01-report.md) — earlier registry claim wins; duplicate reconciled by main session 2026-10-14 | ↗ linked (usage checked) |
| 5 | `Modules/TeacherPortal/app/Services/TeacherContext.php` | service | 227 | ↗ [tarun/TeacherPortal-done/MobileTeacherDashboardController](../MobileTeacherDashboardController/01-report.md) | ↗ linked |
| 6 | `Modules/StudentProfile/app/Models/LeaveApplication.php` | model | 126 | ↗ [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController-done/01-report.md) | ↗ linked |
| 7 | `Modules/StudentProfile/app/Models/LeaveApplicationRemark.php` | model | — | ↗ [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController-done/01-report.md) | ↗ linked |
| 8 | `Modules/StudentProfile/app/Models/LeaveType.php` | model | — | ↗ [gaurav/StudentProfile/StudentLeaveTypeController](../../../gaurav/StudentProfile/StudentLeaveTypeController-done/01-report.md) | ↗ linked |
| 9 | `Modules/StudentProfile/app/Models/Student.php` | model | — | ↗ [gaurav/StudentProfile/StudentReportController](../../../gaurav/StudentProfile/StudentReportController-done/01-report.md) | ↗ linked |
| 10 | `Modules/StudentProfile/app/Models/LeaveApplicationDocument.php` | model | — | ↗ [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController-done/01-report.md) | ↗ linked |
| 11 | `Modules/StudentProfile/app/Models/StudentAttendance.php` | model | 63 | ↗ [gaurav/StudentProfile/AttendanceController](../../../gaurav/StudentProfile/AttendanceController-done/01-report.md) | ↗ linked |
| 12 | `Modules/SchoolSetup/app/Models/User.php` | model | — | ↗ [tarun/TeacherPortal-done/MobileTeacherDashboardController](../MobileTeacherDashboardController/01-report.md) | ↗ linked |
| 13 | `Modules/SchoolSetup/app/Models/Teacher.php` | model | — | ↗ [tarun/TeacherPortal-done/MobileTeacherDashboardController](../MobileTeacherDashboardController/01-report.md) | ↗ linked (not reached through the model) |

Note on row 4: `00-CLASS-OWNERS.md` had **two** rows for `Modules/StudentProfile/app/Services/LeaveService.php`; the duplicate was reconciled 2026-10-14 in favour of the earlier claim (gaurav/StudentProfile/StdLeaveController, registry line 87). LeaveService is therefore `↗ linked`, not owned here. This controller's use of it is checked (the `review` path calls `LeaveService::review()` / `markAttendanceOnApproval()`); the two LeaveService findings below (MTA-03, MTA-09) are recorded for that owner and their plan items are `⚠ SHARED`. Row 13 is listed for completeness only: the controller and its services read `sch_teachers` through `DB::table('sch_teachers')`, never through the `Teacher` model.

No pre-applied files (no entry for this controller or its services in any `PRE-APPLIED-2026-10-10.md`).

## 4. Routes

```
GET|HEAD api/mobile/v1/teacher/attendance                             -> MobileTeacherAttendanceController@register
POST    api/mobile/v1/teacher/attendance                             -> MobileTeacherAttendanceController@store
GET|HEAD api/mobile/v1/teacher/attendance/sections                    -> MobileTeacherAttendanceController@sections
GET|HEAD api/mobile/v1/teacher/attendance/leaves                      -> MobileTeacherAttendanceController@leaves
POST    api/mobile/v1/teacher/attendance/leaves/{application}/review  -> MobileTeacherAttendanceController@review
```

Unrouted public methods: none. All five public methods are routed (the constructor is the sixth `function` grep hit and is not a route).

Middleware (uncached `route:list --json`): every one of the five routes carries `api, ValidateMobileApiKey, InitializeTenancyByMobileHeader, Authenticate:sanctum` — i.e. HTTPS client key, tenant resolution by `X-School-Code`, and a Sanctum bearer token. There is **no** `role:Teacher` and **no** `permission:` middleware.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `sections` | 41 | GET `/api/mobile/v1/teacher/attendance/sections` | none — inline `context()` 403 when `managedSections()` empty | none | none | none | MTA-04, MTA-06, MTA-12 |
| `register` | 65 | GET `/api/mobile/v1/teacher/attendance` | none — inline `context()` 403 | none | none | none | MTA-04, MTA-07 |
| `store` | 100 | POST `/api/mobile/v1/teacher/attendance` | none — inline `canMark()` 403 | `TeacherAttendanceService::save()` | none | std_student_attendance | MTA-01, MTA-02, MTA-04, MTA-05, MTA-08 |
| `leaves` | 150 | GET `/api/mobile/v1/teacher/attendance/leaves` | none — inline `context()` 403 | none | none | none | MTA-04, MTA-07 |
| `review` | 177 | POST `/api/mobile/v1/teacher/attendance/leaves/{application}/review` | none — inline `canReview()` 403 | `TeacherStudentLeaveService::review()` (nests `LeaveService::review()`) | 'Reviewed' | std_leave_applications, std_leave_application_remarks, std_student_attendance, sys_activity_logs | MTA-01, MTA-04, MTA-05, MTA-09 |

## 6. Findings

### F1 — Errors

#### MTA-01 · M · ERR-00 (D1) + ERR-05 — `store()` and `review()` catch `\Throwable` themselves and log only the message

| Field | Value |
|---|---|
| **Rule** | ERR-00 (settled D1): the Laravel idiom is no `try/catch` in a controller — `DB::transaction()` rolls back and the central handler in `bootstrap/app.php` renders. ERR-05 (M): log the exception object, not just its message. |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php:130-140` (`store()`) and `:203-213` (`review()`) |
| **Root cause** | Both write methods wrap the service call in `try { … } catch (\Throwable $e)` and log `['error' => $e->getMessage()]`. D1 forbids a controller `try/catch` unless it is one of the D2 shapes (a `\DomainException` for a business message, the truncate-rebuild message, or a `SnapshotProtectionException`); this catch is none of them. Logging `getMessage()` alone also discards the class, file, line and stack (ERR-05). |
| **Consequence** | A save failure produces the controller's own generic 500 body (`{"status":"error","message":"Could not save attendance."}`) instead of the central handler's response, and the log line has no trace, so the actual cause (which query, which row) is hard to find after the fact. |
| **Reproduce** | Static only — no seeded failure path is exercised (D4). The two catch sites are visible at lines 130 and 203. |
| **Fix approach** | Remove both `try/catch` blocks and let the exception propagate to the central handler (`bootstrap/app.php:100-152`, which returns JSON for `api/*`); drop the now-unused `Log` import. |
| **Plan item** | MTA-01 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -nE "try \{|\} catch|Log::error|getMessage" <controller>` |

```php
// MobileTeacherAttendanceController.php:130-140 — CURRENT (store)
        try {
            $result = $this->attendance->save($ctx, $csId, $date, $validated['status'], $validated['remarks'] ?? []);
        } catch (\Throwable $e) {
            Log::error('Mobile teacher attendance save failed', [
                'user_id'       => Auth::id(),
                'class_section' => $csId,
                'error'         => $e->getMessage(),
            ]);

            return response()->json(['status' => 'error', 'message' => 'Could not save attendance.'], 500);
        }
```

**Evidence**
```
$ grep -nE "try \{|\} catch|Log::error|getMessage" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php
130:        try {
132:        } catch (\Throwable $e) {
133:            Log::error('Mobile teacher attendance save failed', [
136:                'error'         => $e->getMessage(),
203:        try {
205:        } catch (\Throwable $e) {
206:            Log::error('Mobile teacher student-leave review failed', [
209:                'error'          => $e->getMessage(),
256:        try {
258:        } catch (\Throwable) {
```

### F2 — Transactions and audit

#### MTA-02 · M · TXN-04 — the register save writes no `activityLog` row, unlike the module's other write path

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M): `activityLog()` sits inside the transaction, after the write it describes. F2's checklist expects each mutating method to record its event literal. |
| **Where** | `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php:148-214`, method `save()` |
| **Root cause** | `save()` writes `std_student_attendance` inside `DB::transaction` but never calls `activityLog()`. The module's other write path, `TeacherStudentLeaveService::review()`, does (`'Reviewed'`, line 225). So an attendance change leaves no audit row while a leave decision does. |
| **Consequence** | A disputed register ("I marked him Present") has no audit trail; the only record is the final `marked_by`, which a later save overwrites. |
| **Reproduce** | Static only — a successful POST to `/api/mobile/v1/teacher/attendance` writes rows but no `sys_activity_logs` row. |
| **Fix approach** | DECISION: the web register path (`TeacherPortalController::storeAttendance`) is also unaudited, so this is a module-wide policy choice rather than a controller bug. Options in `02-fix-plan.md` §9. |
| **Plan item** | MTA-02 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `grep -n "activityLog" Modules/TeacherPortal/app/Services/TeacherAttendanceService.php` → no output |

```php
// TeacherAttendanceService.php:171-172 — CURRENT (the transaction, no activityLog)
        DB::transaction(function () use ($marks, $remarks, $enrolled, $classSectionId, $date, $ctx, $now, &$saved, &$skipped) {
            foreach ($marks as $studentId => $status) {
```

**Evidence**
```
$ grep -n "activityLog" Modules/TeacherPortal/app/Services/TeacherAttendanceService.php
$ (no output)
$ grep -rn "activityLog" Modules/TeacherPortal/app/
Modules/TeacherPortal/app/Services/TeacherLeaveService.php:379:            activityLog($application, ...
Modules/TeacherPortal/app/Services/TeacherStudentLeaveService.php:225:            activityLog($application, 'Reviewed', [
Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php:294:        activityLog(auth()->user(), 'Viewed', [
```

#### MTA-03 · M · TXN-01 — `deleteLeaveType()` makes two writes with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (M here; rulebook default H, lowered because both writes are on the same row of the same table, one statement apart): more than one write runs inside one `DB::transaction`. |
| **Where** | `Modules/StudentProfile/app/Services/LeaveService.php:180-184`, method `deleteLeaveType()` |
| **Root cause** | It sets `is_active = false` and then soft-deletes the row as two independent statements. If the second fails, the type is left inactive but not deleted. |
| **Consequence** | A failed delete silently deactivates a leave type: it disappears from the create-form dropdown but still appears in admin lists, with no error shown. |
| **Reproduce** | Static only. Not reachable from this controller; recorded for the `LeaveService` owner (gaurav/StudentProfile/StdLeaveController) — see §3 note. |
| **Fix approach** | Wrap both writes in a single `DB::transaction`. |
| **Plan item** | MTA-03 in `02-fix-plan.md` §3 (⚠ SHARED — `LeaveService.php` is owned by gaurav/StudentProfile/StdLeaveController) |
| **Evidence** | `sed -n '180,184p' Modules/StudentProfile/app/Services/LeaveService.php` |

```php
// LeaveService.php:180-184 — CURRENT
    public function deleteLeaveType(LeaveType $leaveType): void
    {
        $leaveType->update(['is_active' => false]);
        $leaveType->delete();
    }
```

**Evidence**
```
$ sed -n '180,184p' Modules/StudentProfile/app/Services/LeaveService.php
    public function deleteLeaveType(LeaveType $leaveType): void
    {
        $leaveType->update(['is_active' => false]);
        $leaveType->delete();
    }
```

### F3 — Authorization

#### MTA-04 · M · AUTH-01 + AUTH-02 — no gate before the record is loaded; authorization is inline ownership only

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (rulebook default B, lowered to M — the inline ownership check does deny access, so this is defence-in-depth, not an open door): every routed method authorizes. AUTH-02 (H): authorize before loading records — loading first leaks whether an id exists (404 vs 403). |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php:177-183` (`review()`, the binding before the check), plus the route group `Modules/TeacherPortal/routes/mobile_api.php:22-30`, which applies to all five routed methods |
| **Root cause** | The mobile routes carry only `auth:sanctum` (measured: `api, ValidateMobileApiKey, InitializeTenancyByMobileHeader, Authenticate:sanctum`) — no `role:Teacher` and no permission. Each method instead calls `$this->context()` / `canMark()` / `canReview()` inline, and all of these resolve to "does `managedSections()` contain this section". `review()` is worse: `LeaveApplication $application` is route-model-bound **before** `canReview()` runs, so a caller can tell a nonexistent application (404) from someone else's (403). Note also that the route-file comment (`MobileTeacherAttendanceController.php` companion `Modules/TeacherPortal/routes/mobile_api.php:8-10`) claims the gate is "having a `sch_teachers` record", but `managedSections()` never reads `sch_teachers` — it matches `sch_class_section_jnt.class_teacher_id`, a `sys_users.id` — so the comment describes a check that is not performed. |
| **Consequence** | Any authenticated user (student, parent, admin token) can reach the endpoints and receives 403 rather than being stopped at the middleware; and a caller can enumerate valid `std_leave_applications` ids by probing `review`. No record content is returned to a non-owner, so the exposure is id-existence only. |
| **Reproduce** | `POST /api/mobile/v1/teacher/attendance/leaves/1/review` with a student token → 403 "Not your class." · with id `999999` → 404. The difference reveals which ids exist. |
| **Fix approach** | DECISION: add `role:Teacher` to the `teacher/attendance` route group (matches the web stack at `RouteServiceProvider.php`), or accept the inline-ownership model. Options in `02-fix-plan.md` §9. |
| **Plan item** | MTA-04 in `02-fix-plan.md` §9 (DECISION · ⚠ SHARED route file) |
| **Evidence** | uncached `route:list --json` middleware column |

```php
// MobileTeacherAttendanceController.php:177-183 — CURRENT (review binds before it checks)
    public function review(Request $request, LeaveApplication $application): JsonResponse
    {
        $ctx = TeacherContext::for(Auth::user());

        if (! $this->studentLeave->canReview($ctx, (int) $application->class_section_id)) {
            return response()->json(['status' => 'error', 'message' => 'Not your class.'], 403);
        }
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | (filter MobileTeacherAttendanceController)
POST api/mobile/v1/teacher/attendance/leaves/{application}/review :: middleware=api,App\Http\Middleware\ValidateMobileApiKey,App\Http\Middleware\InitializeTenancyByMobileHeader,Illuminate\Auth\Middleware\Authenticate:sanctum
GET|HEAD api/mobile/v1/teacher/attendance/sections :: middleware=api,...,Authenticate:sanctum
(no role:Teacher, no permission: on any of the five routes)
```

### F4 — Validation and input

#### MTA-05 · M · VAL-02 — `store()` and `review()` validate inline instead of in Form Requests

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M): validation lives in a Form Request; inline `$request->validate()` is allowed only for a one-field AJAX toggle. |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php:107-114` (`store()`) and `:185-201` (`review()`) |
| **Root cause** | Both endpoints validate a multi-field payload with `$request->validate(...)` in the controller. `review()` also carries a cross-field `Rule::requiredIf` and a custom message, which is exactly the shape a Form Request `authorize()`/`messages()` is for. The module already ships `ApplyLeaveRequest` for the web apply path, so the convention exists. |
| **Consequence** | The rules are not reusable, cannot be unit-checked through `authorize()`, and the controller grows. Behaviour in the app is currently correct. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `MobileAttendanceStoreRequest` and `MobileLeaveReviewRequest` under `Modules/TeacherPortal/app/Http/Requests/` and type-hint them in `store()`/`review()`, replacing the inline blocks with `$request->validated()`. The `approved_days` max reads `$this->route('application')->total_days`; the `review_remarks` required-if reads `$this->input('status')`. |
| **Plan item** | MTA-05 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -n "\$request->validate" <controller>` |

```php
// MobileTeacherAttendanceController.php:107-114 — CURRENT (store)
        $validated = $request->validate([
            'class_section' => ['required', 'integer'],
            'date'          => ['required', 'date'],
            'status'        => ['required', 'array'],
            'status.*'      => ['required', 'string', Rule::in(TeacherAttendanceService::STATUSES)],
            'remarks'       => ['nullable', 'array'],
            'remarks.*'     => ['nullable', 'string', 'max:255'],
        ]);
```

**Evidence**
```
$ grep -n "request->validate" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php
107:        $validated = $request->validate([
185:        $validated = $request->validate([
```

### F5 — Routes

clean — every public method is routed, no state change sits on a GET, the `{application}` parameter name matches the `$application` argument, and tenant middleware is present. Proved with `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` (five routes, all resolved) and `grep -nE 'public function' <controller>` (five public methods, all routed).

### F6 — Controller shape

#### MTA-06 · L · CTL-05 — the 4-line `context()` guard is copy-pasted into four methods

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M default, lowered to L: the copy is idiomatic and only 4 lines): no copy-paste; shared loaders are extracted. |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php:43-46, 67-70, 102-105, 152-155` |
| **Root cause** | Four methods repeat the same three statements: destructure `context()`, test `$error`, return it. |
| **Consequence** | A change to the error shape must be made in four places. No user-visible effect today. |
| **Reproduce** | Static only. |
| **Fix approach** | No plan item — extracting it would replace four explicit early-returns with an indirection, which is not worth it while the block is this small (see `02-fix-plan.md` §10). |
| **Plan item** | none — see `02-fix-plan.md` §10 |
| **Evidence** | `grep -c "= \$this->context();" <controller>` |

```php
// MobileTeacherAttendanceController.php:43-46 — CURRENT (repeated at 67, 102, 152)
        [$ctx, $sections, $error] = $this->context();
        if ($error) {
            return $error;
        }
```

**Evidence**
```
$ grep -n "[\$ctx, \$sections, \$error] = \$this->context();" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php
43:        [$ctx, $sections, $error] = $this->context();
67:        [$ctx, $sections, $error] = $this->context();
102:        [$ctx, $sections, $error] = $this->context();
152:        [$ctx, $sections, $error] = $this->context();
```

#### MTA-12 · L · CTL-10 — `sections()` returns `primary_statuses`, which the service documents as unused

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M default, lowered to L: the service docblock explicitly says it is kept on purpose): no dead code / dead data. |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php:56` |
| **Root cause** | `TeacherAttendanceService::PRIMARY_STATUSES` is documented at `TeacherAttendanceService.php:38-45` as "NOTHING USES THIS ANY MORE — 2026-09-11 … this array reaches the view and is ignored." The controller still ships it to the API in `sections()`. |
| **Consequence** | The mobile client receives a field with no consumer; if a caller starts using it, the split it implies is not applied anywhere on the write path. |
| **Reproduce** | Static only. |
| **Fix approach** | No plan item — the service docblock says to delete the constant and the controller line together, which is a product call, not a bug-fix (see `02-fix-plan.md` §10). |
| **Plan item** | none — see `02-fix-plan.md` §10 |
| **Evidence** | `grep -n "primary_statuses\|PRIMARY_STATUSES"` |

```php
// MobileTeacherAttendanceController.php:56 — CURRENT
            'primary_statuses' => TeacherAttendanceService::PRIMARY_STATUSES,
```

**Evidence**
```
$ grep -n "primary_statuses\|PRIMARY_STATUSES" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php Modules/TeacherPortal/app/Services/TeacherAttendanceService.php
Modules/.../MobileTeacherAttendanceController.php:56:            'primary_statuses' => TeacherAttendanceService::PRIMARY_STATUSES,
Modules/.../Services/TeacherAttendanceService.php:45:    public const PRIMARY_STATUSES = ['Present', 'Absent', 'Late'];
```

### F7 — Models

clean — the controller reaches models only through already-owned classes. `LeaveApplication`'s `$fillable`/`$casts` cover the columns used (`from_date`/`to_date` date, `total_days`/`approved_days` integer, `is_half_day` boolean); `StudentAttendance` reads/writes `student_id`, `attendance_date`, `attendance_period`, `academic_session_id`, `class_section_id`, `status`, `remarks`, `marked_by`. All are marked `↗ linked` in §3 and are audited by their owner reports. The one model-level defect on this path is the unique-index mismatch recorded as **MTA-09** (it lives in `LeaveService`, not the model).

### F8 — Services and jobs

#### MTA-07 · M · SVC-05 / QRY-12 — `managedSections()` is re-queried up to three times per request

| Field | Value |
|---|---|
| **Rule** | SVC-05 (M): repeated lookups inside a request are memoised. QRY-12 (M): identical queries repeated in one request are resolved once. |
| **Where** | `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php:58-80` and its callers `:84, :95, :155` plus `TeacherStudentLeaveService.php:121, :150, :177, :205` |
| **Root cause** | `canMark()` calls `managedSections()`, and `context()` calls `managedSections()` separately. On `store()` the controller calls `context()` (1), then `canMark()` (2), then the service's `save()` calls `canMark()` again (3) — three identical joins per save. On `leaves()` the same happens via `forSection()` and `openCount()`. Nothing memoises the result for the request. |
| **Consequence** | Three identical three-table joins per write/list instead of one; on a busiest-first-period save this is measurable but small, and it grows if more callers appear. |
| **Reproduce** | Static only — count the call sites. |
| **Fix approach** | Memoise inside `TeacherAttendanceService::managedSections()` on the user id for the lifetime of the service instance. |
| **Plan item** | MTA-07 in `02-fix-plan.md` §6 |
| **Evidence** | `grep -n "managedSections\|canMark(" Modules/TeacherPortal/app/Services/TeacherAttendanceService.php` |

```php
// TeacherAttendanceService.php:58-62 — CURRENT (rebuilt on every call)
    public function managedSections(TeacherContext $ctx): Collection
    {
        $uid = $ctx->user->id;

        return collect(DB::table('sch_class_section_jnt as cs')
```

**Evidence**
```
$ grep -n "managedSections\|canMark(" Modules/TeacherPortal/app/Services/TeacherAttendanceService.php
58:    public function managedSections(TeacherContext $ctx): Collection
82:    public function canMark(TeacherContext $ctx, int $classSectionId): bool
84:        return $this->managedSections($ctx)->contains('id', $classSectionId);
95:        if (! $this->canMark($ctx, $classSectionId)) {
155:        if (! $this->canMark($ctx, $classSectionId) || ! $this->isEditable($date)) {
```

### F9 — Queries and performance

#### MTA-08 · H · QRY-01 / TXN-06 — `save()` writes one row per student with a select-then-insert (N+1 and check-then-act)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H): no queries inside loops. TXN-06 (rulebook default H; kept H — a concurrent double-submit 500s the second teacher): check-then-act needs a lock or a unique index. |
| **Where** | `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php:171-211` |
| **Root cause** | For every submitted student the loop runs `SELECT id FROM std_student_attendance WHERE student_id = ? AND attendance_date = ? AND attendance_period = 0`, then an `UPDATE` or an `INSERT`. A 40-student register is ~80 statements. The same select-then-insert is a check-then-act race: two near-simultaneous saves both see no row, both insert, and the second dies on `uq_std_att_student_date` with SQLSTATE 23000. |
| **Consequence** | Slower saves on every register, and two devices saving the same section (a class-teacher and their assistance teacher, or a double tap) can turn one of them into a 500. |
| **Reproduce** | Static only; the unique index `uq_std_att_student_date (student_id, attendance_date, attendance_period)` is defined in `database/migrations/tenant/2026_06_15_151309_create_std_student_attendance_table.php:32`. |
| **Fix approach** | Build the row array in the loop (no DB calls) and issue one `DB::table('std_student_attendance')->upsert(...)` per save, keyed on `(student_id, attendance_date, attendance_period)`, updating `deleted_at => null` so a trashed row is still revived. |
| **Plan item** | MTA-08 in `02-fix-plan.md` §6 |
| **Evidence** | `grep -n "DB::table('std_student_attendance')" Modules/TeacherPortal/app/Services/TeacherAttendanceService.php` |

```php
// TeacherAttendanceService.php:192-207 — CURRENT (per-student select + write)
                $existing = DB::table('std_student_attendance')
                    ->where('student_id', $studentId)
                    ->where('attendance_date', $date->toDateString())
                    ->where('attendance_period', self::DAILY_PERIOD)
                    ->first(['id']);

                if ($existing) {
                    DB::table('std_student_attendance')->where('id', $existing->id)->update($payload);
                } else {
                    DB::table('std_student_attendance')->insert($payload + [
                        'student_id' => $studentId,
                        'attendance_date' => $date->toDateString(),
                        'attendance_period' => self::DAILY_PERIOD,
                        'created_at' => $now,
                    ]);
                }
```

**Evidence**
```
$ grep -n "DB::table('std_student_attendance')" Modules/TeacherPortal/app/Services/TeacherAttendanceService.php
192:                $existing = DB::table('std_student_attendance')
199:                    DB::table('std_student_attendance')->where('id', $existing->id)->update($payload);
201:                    DB::table('std_student_attendance')->insert($payload + [
(three statements inside the foreach that starts at line 172)
```

#### MTA-09 · H · VAL-04 / QRY-07 — leave approval upserts attendance with keys that do not mirror the unique index

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H): uniqueness handling mirrors the DB unique index, including soft-delete semantics. QRY-07 (M): bulk writes instead of one write per row in a loop. |
| **Where** | `Modules/StudentProfile/app/Services/LeaveService.php:594-620`, method `markAttendanceOnApproval()` |
| **Root cause** | The table's real unique index is `uq_std_att_student_date (student_id, attendance_date, attendance_period)` (migration line 32; `attendance_period` defaults to 0). This method matches on `(student_id, attendance_date, academic_session_id)` and never names `attendance_period`. So (1) a day that already has a row for the same student/date with a different `academic_session_id` is not matched, a plain `insert` follows, and the unique index raises SQLSTATE 23000 — which rolls back the whole `review()` transaction and 500s the teacher's approval; and (2) a soft-deleted row (the table has `deleted_at`, and `StudentAttendance` does not use `SoftDeletes`, so the query sees it) is matched and updated while `deleted_at` stays set, so the register — which reads `whereNull('a.deleted_at')` — never shows the approved leave. It is also one `updateOrCreate` per approved day (N+1). |
| **Consequence** | Approving a leave can either fail the whole review with a 500 or silently leave the register unmarked, so the child is counted absent on the exact day the leave was approved. |
| **Reproduce** | Static only. The register's own `save()` (line 101-105) filters `attendance_period = 0` and `deleted_at IS NULL`, which is why (2) is invisible. |
| **Fix approach** | Mirror the index: build one row per day with `attendance_period => 0`, and write them with a single `DB::table('std_student_attendance')->upsert($rows, ['student_id','attendance_date','attendance_period'], [...])` that includes `deleted_at => null`. |
| **Plan item** | MTA-09 in `02-fix-plan.md` §5 (⚠ SHARED — duplicate registry claim) |
| **Evidence** | `sed -n '605,619p' Modules/StudentProfile/app/Services/LeaveService.php` |

```php
// LeaveService.php:605-619 — CURRENT
        foreach ($period as $day) {
            \Modules\StudentProfile\Models\StudentAttendance::updateOrCreate(
                [
                    'student_id'          => $application->student_id,
                    'attendance_date'     => $day->format('Y-m-d'),
                    'academic_session_id' => $application->academic_session_id,
                ],
                [
                    'class_section_id' => $application->class_section_id,
                    'status'           => 'Leave',
                    'remarks'          => "Leave approved — Application #{$application->id}",
                    'marked_by'        => auth()->id(),
                ]
            );
        }
```

**Evidence**
```
$ sed -n '605,619p' Modules/StudentProfile/app/Services/LeaveService.php
        foreach ($period as $day) {
            \Modules\StudentProfile\Models\StudentAttendance::updateOrCreate(
                [
                    'student_id'          => $application->student_id,
                    'attendance_date'     => $day->format('Y-m-d'),
                    'academic_session_id' => $application->academic_session_id,
                ],
                ...
$ grep -n "uq_std_att_student_date" database/migrations/tenant/2026_06_15_151309_create_std_student_attendance_table.php
32:            $table->unique(['student_id', 'attendance_date', 'attendance_period'], 'uq_std_att_student_date');
```

### F10 — Views

clean — the controller renders no Blade. Proved with `grep -oE "view\(['\"][^'\"]+" <controller>` → no output (the `grep -c "view("` count of 3 is the substring inside `->review(`).

### F11 — Security and tenancy

clean — no `env()`, no hard-coded ids or `?? 1`, no secrets or request bodies logged, no cache, and no personal data beyond what a class teacher needs (student name/admission/roll for their own section). Tenant context is established by `tenant.mobile`. Proved with `grep -nE "env\(|?? 1|Log::(info|debug|error)\(.*request" <the four in-scope files>` → no output, and the route middleware column above.

### F12 — Style

#### MTA-10 · L · STY-04 — emoji markers in `TeacherAttendanceService.php` comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L): comments in English, no emoji markers. |
| **Where** | `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php` (11 marker lines: 17, 26, 39, 50, 55, 65, 90, 133, 142, 146, 217) |
| **Root cause** | The class and method docblocks use the `⛔` and `⚠` markers. |
| **Consequence** | None functional; inconsistent with the STY-04 rule. |
| **Reproduce** | Static only. |
| **Fix approach** | Remove the marker characters, keeping the words after them. |
| **Plan item** | MTA-10 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -cP "[\x{26D4}\x{26A0}]" <file>` → 11 |

```php
// TeacherAttendanceService.php:17 — CURRENT
 * ⛔ THREE RULES, ENFORCED HERE RATHER THAN IN THE CONTROLLER OR THE VIEW:
```

**Evidence**
```
$ grep -cP "[\x{26D4}\x{26A0}]" Modules/TeacherPortal/app/Services/TeacherAttendanceService.php
11
```

#### MTA-11 · L · STY-04 — emoji markers in `TeacherStudentLeaveService.php` comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L): comments in English, no emoji markers. |
| **Where** | `Modules/TeacherPortal/app/Services/TeacherStudentLeaveService.php` (14 marker lines: 16, 20, 26, 41, 46, 61, 74, 117, 127, 131, 135, 143, 190, 196) |
| **Root cause** | Same `⛔`/`⚠` marker convention in the class docblock. |
| **Consequence** | None functional; inconsistent with the STY-04 rule. |
| **Reproduce** | Static only. |
| **Fix approach** | Remove the marker characters, keeping the words after them. |
| **Plan item** | MTA-11 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -cP "[\x{26D4}\x{26A0}]" <file>` → 14 |

```php
// TeacherStudentLeaveService.php:16 — CURRENT
 * ⛔ THIS IS THE PORTAL'S SECOND WRITE PATH. Until 2026-09-11 the attendance register was
```

**Evidence**
```
$ grep -cP "[\x{26D4}\x{26A0}]" Modules/TeacherPortal/app/Services/TeacherStudentLeaveService.php
14
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| # | Question | `store()` → `TeacherAttendanceService::save()` | `review()` → `TeacherStudentLeaveService::review()` |
|---|---|---|---|
| 1 | Can a write overwrite data it should not? | ok — only submitted student ids are written; unsubmitted students keep their marks. | ok — it rewrites the review fields of the application under review only. |
| 2 | Is anything deleted before its replacement is stored? | ok — no deletes; a trashed row is revived. | ok — no deletes. |
| 3 | Duplicate implementations of one operation? | ok — one `save()`; the web controller calls the same service. | ok — one `LeaveService::review()`; `TeacherStudentLeaveService::review()` wraps it, it does not re-implement it. |
| 4 | Soft-delete × unique index trap? | ok — handled deliberately (`deleted_at => null`, ignores the scope). | MTA-09 — not handled: keys omit `attendance_period`, and a trashed row is written invisibly. |
| 5 | Race? | MTA-08 — select-then-insert under `uq_std_att_student_date`. | MTA-09 — same class of trap through `updateOrCreate`. |
| 6 | Authorization hole? | MTA-04 — no pre-route gate; `canMark()` denies inline. | MTA-04 — no pre-route gate; the record is bound before `canReview()`. |
| 7 | Does any message lie? | ok — the response reports real `saved`/`skipped` counts. | ok in practice — `TeacherStudentLeaveService::review()` returns `false` on a refusal and the controller ignores the value, but the controller has already checked `canReview()` and validated the status, so the 200 is truthful. |
| 8 | Dead feature? | MTA-12 — `primary_statuses` is returned with no consumer. | ok — the two request statuses create the remark the student replies to, as designed. |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/TeacherPortal/app/Services/TeacherContext.php` | 12 emoji-marker comment lines (same STY-04 convention). | STY-04 (L) | [tarun/TeacherPortal-done/MobileTeacherDashboardController](../MobileTeacherDashboardController/01-report.md) |
| `Modules/StudentProfile/app/Services/LeaveService.php` | Methods this controller does not reach still carry findings: `getLeaveTypes()`/`getApplicationReviews()` use leading-wildcard `LIKE` (QRY-08, L); `createAndSubmit()` (123 lines) and `updateApplication()` (101 lines) are long (CTL-02, M); the scanner also flags `transition()` as two writes without a transaction. | QRY-08, CTL-02, TXN-01 | Recorded here for the `LeaveService` owner; `transition()` is called only from within a caller's transaction, so it is not a live defect on the reachable paths. |

## 8. Not covered, and why

- **No runtime exercise.** Per D4 no request was sent and no test was run; every finding is static, and the SQLSTATE-23000 outcome in MTA-09 is reasoned from the DDL and the model, not reproduced. What would settle it: a seeded row whose `(student_id, attendance_date, attendance_period=0)` already exists with a different `academic_session_id`, then an approved leave covering that date.
- **`06-...`-tenant migration drift.** The audit checked the tenant migration `2026_06_15_151309_create_std_student_attendance_table.php` (which has `softDeletes()` and the unique index). It did not diff every tenant DB; if a tenant predates that migration, the trap in MTA-08/MTA-09 may not apply there.
- **`TeacherContext` internals** are the Dashboard report's scope; this audit only checked how this controller calls `TeacherContext::for()` and `academicSessionId`.
- **No Pint run** — style was read by eye and by the scanner only; `--dirty` is banned and no file was touched.
