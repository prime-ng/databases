# Final Audit — BehaviouralAssessment / BaBehaviourPointController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php` (96 lines, 2 public methods plus `__construct`)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | POST `behavioural-assessment/behaviour-points` (award) · POST `behavioural-assessment/behaviour-points/{entry}/reverse` (reverse). Both are submitted from dialogs on the **Incidents** page (`behavioural-assessment/incidents-page?tab=behaviour-points`). No GET page is rendered by this controller — it redirects back to the incidents page. |
| Menu path | Behavioural Assessment → **Incidents** page → **Behaviour Points** tab (the tab is hidden unless the viewer holds `tenant.behavioural-assessment.behaviour-points.view`, and the whole ledger is OFF until `ba_config.is_behaviour_points_enabled` is set for the current academic session) |
| Who uses it | Staff whose login is linked to an `sch_employees` row and who hold `tenant.behavioural-assessment.behaviour-points.award` (award) or `.reverse` (reverse). On the test tenant each of the three permission names is seeded and bound to 3 roles (role_id 1, 2, 3 — the bootstrap admin/principal/teacher set). |
| What a user does here | Awards a one-off merit or demerit to one currently enrolled student (±100 points, never 0, with a reason), and reverses a ledger entry with a compensating "reversal" row (same points, opposite sign). The ledger is append-only: nothing is ever edited or deleted. |
| Tables written | `ba_behaviour_points` (INSERT only), `sys_activity_logs` (via `activityLog()` inside the same transaction) |
| Tables read | `sch_org_academic_sessions_jnt`, `ba_config`, `std_students`, `std_student_academic_sessions`, `sch_employees`, `ba_behaviour_points` |
| Live data | `ba_behaviour_points`: **0 live rows** on the test tenant (`xyz_school_...`); trashed = 0 — the table has **no `deleted_at` column**, so there is nothing to trash |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

The controller is production-ready **after one error-path fix**. The write logic (transactions, row locks, unique index, activity log, permissions) is sound and well-layered: the controller is thin, the service owns every transaction, and the FormRequests gate the writes. The single worst finding is that the private `run()` helper wraps every write in a controller `try/catch` — the exact shape the settled decision D1 forbids — and its generic `catch (Throwable)` turns every unexpected failure (including DB exceptions) into a generic red flash while logging only the message, losing the stack trace. That is one focused rewrite (keep the `DomainException` catch per D2, let everything else bubble). Two low-severity nits (a misleading error-field placement, an uncast enum column) and two accepted style notes make up the rest. Rough effort: **S** — one method rewrite plus one small message change, under an hour.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 0 | 3 | 0 | 4 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | ABP-01 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | clean |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | ABP-02 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | clean |
| F6 Controller shape | ABP-03 | F13 Deep read | ABP-02 (message lie) |
| F7 Models | ABP-04 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php` | controller | 96 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Services/BaBehaviourPointService.php` | service | 339 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Models/BaBehaviourPoint.php` | model | 88 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support helper | 37 | this report | ✅ (also used by BaClassCategoryController / BehaviouralScoreService) |
| 5 | `Modules/BehaviouralAssessment/app/Http/Requests/BaBehaviourPointAwardRequest.php` | FormRequest | 53 | this report | ✅ |
| 6 | `Modules/BehaviouralAssessment/app/Http/Requests/BaBehaviourPointReverseRequest.php` | FormRequest | 39 | this report | ✅ |
| 7 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support helper | 45 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked (de-duplicated by main session 2026-10-12; BaCommentBank reached it first) |
| 8 | `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php` | service (only `currentEmployee()` is used here) | large | ↗ linked — owned by the BaIncidentController report (not yet written) | ↗ linked |
| 9 | `Modules/BehaviouralAssessment/app/Models/BaIncident.php`, `BaConfig.php` | same-module models (constants + queries only) | — | ↗ linked — owned by the BaIncidentController / BaConfigController reports | ↗ linked |
| 10 | `Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/_behaviour-points.blade.php` + `_behaviour-points-modals.blade.php` | view partials — the forms that POST to this controller's routes | 253+79 | ↗ linked — owned by the BaDashboardController (incidents page) report | ↗ linked (forms checked for name/route/permission match only) |

Other-module models (`Modules/StudentProfile/Models/Student`, `Modules/SchoolSetup/Models/Employee`, `Modules/SchoolSetup/Models/OrganizationAcademicSession`) are common per §4.2 — referenced, not audited.

No pre-applied files.

## 4. Routes

```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); foreach($r as $x){ if(str_contains($x["action"],"BaBehaviourPointController@")) printf("%-7s %-55s %-50s %s\n",$x["method"],$x["uri"],$x["name"],$x["action"]); }'
POST   behavioural-assessment/behaviour-points                  behavioural-assessment.behaviour-points.store      Modules\BehaviouralAssessment\Http\Controllers\BaBehaviourPointController@store
POST   behavioural-assessment/behaviour-points/{entry}/reverse  behavioural-assessment.behaviour-points.reverse    Modules\BehaviouralAssessment\Http\Controllers\BaBehaviourPointController@reverse
```

Both routes live in `Modules/BehaviouralAssessment/routes/web.php:150-151`, inside the module `RouteServiceProvider` group (`web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:BehaviouralAssessment`, `auth`, `verified`) with prefix `behavioural-assessment` and name prefix `behavioural-assessment.`. `{entry}` is constrained with `->whereNumber('entry')`.

Unrouted public methods: none (`store`, `reverse` are the only public methods besides `__construct`, and both are routed).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `store` | 36 | POST `behavioural-assessment/behaviour-points` | FormRequest `authorize()` → `tenant.behavioural-assessment.behaviour-points.award` | in service `award()` via `DB::transaction(fn …)` (line 149) | `'Created'` inside the txn (`write()`, service line 329) | `ba_behaviour_points`, `sys_activity_logs` | ABP-02 (requireEmployee field-attached message) |
| `reverse` | 48 | POST `behavioural-assessment/behaviour-points/{entry}/reverse` | FormRequest `authorize()` → `tenant.behavioural-assessment.behaviour-points.reverse` | in service `reverse()` via `DB::transaction(fn …)` with `lockForUpdate()` (line 224) | `'Reversed'` inside the txn (`write()`, service line 329) | `ba_behaviour_points`, `sys_activity_logs` | ABP-03 (route-model binding) |

## 6. Findings

### F1 — Errors

#### ABP-01 · H · ERR-00 (D1; sub-issue ERR-05) — `run()` is a controller try/catch, the settled-standard violation; its generic branch masks and de-traces every unexpected failure

| Field | Value |
|---|---|
| **Rule** | ERR-00 (D1) — **settled**: no try/catch in controllers; `DB::transaction()` rolls back by itself and the central handler in `bootstrap/app.php` renders errors. Only the D2 shapes are allowed, and D2 says **never catch `RuntimeException`** (and `QueryException` extends it). Sub-issue ERR-05 (M) — log the exception object, not `getMessage()`; the message alone loses the trace. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php:71-95`, private method `run()`; the imports on lines 7-20 support it |
| **Root cause** | `run()` was written under the old House rule A1 ("try/catch in every mutation"), which D1 explicitly does **not** apply to modules under final audit. The `catch (Throwable $e)` branch catches every failure — including `QueryException` (a `RuntimeException`), which D2 forbids — converts it to a generic flash `'The operation could not be completed.'`, and logs only `$e->getMessage()` (no exception object, no trace). The `BaTriggerError` look-ahead in that branch can never fire for THIS controller's writes: the module's 45000 'BA: ' triggers (migration `2026_06_16_130643`) are declared on rating scales, periods, assessments and incidents — **none** on `ba_behaviour_points` (verified by grep), so `BaTriggerError::message()` returns null and control always falls to the `Log::error` line. The rethrow catch (`ValidationException\|ModelNotFoundException\|HttpExceptionInterface`) is unnecessary: all three bubble to the central handler by themselves. |
| **Consequence** | Any unexpected DB failure on the award or reverse path (lock timeout, constraint surprise, connection drop) turns into a red flash, is logged without a trace, and never reaches the central handler — the team learns nothing from production errors. |
| **Reproduce** | Static only — would need a forced DB error on the write (e.g. a triggered constraint) and inspection of `storage/logs/laravel.log`; the branch is on the error path. |
| **Fix approach** | Rewrite `run()` to the D2 shape: keep only `catch (DomainException $e)` (business-rule messages are curated and safe to show), let validation/404/HTTP/anything-else bubble to the central handler, and drop the `BaTriggerError`, `Log::error` and rethrow branches. Remove the imports that become unused. |
| **Plan item** | ABP-01 in `02-fix-plan.md` §3 |

```php
// BaBehaviourPointController.php:71-95 — CURRENT run()
    /**
     * One success/failure path: validation, 404 and HTTP aborts pass through (Rule A1); a
     * DomainException (ledger off, already reversed, reversal of a reversal) or a trigger
     * rejection becomes a flash error; anything else is logged and reported generically.
     */
    private function run(string $method, string $success, callable $action): RedirectResponse
    {
        try {
            $action();
        } catch (ValidationException|ModelNotFoundException|HttpExceptionInterface $e) {
            throw $e;
        } catch (DomainException $e) {
            return back()->withInput()->with('error', $e->getMessage());
        } catch (Throwable $e) {
            $trigger = BaTriggerError::message($e);
            if ($trigger !== null) {
                return back()->withInput()->with('error', $trigger);
            }
            Log::error('BaBehaviourPointController::'.$method.' failed', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'The operation could not be completed.');
        }

        return redirect()->route('behavioural-assessment.incidents-page', self::BACK_TAB)->with('success', $success);
    }
```

**Evidence**
```
$ grep -n "catch (\|Log::\|BaTriggerError" Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php
80:        } catch (ValidationException|ModelNotFoundException|HttpExceptionInterface $e) {
82:        } catch (DomainException $e) {
84:        } catch (Throwable $e) {
85:            $trigger = BaTriggerError::message($e);
89:            Log::error('BaBehaviourPointController::'.$method.' failed', ['error' => $e->getMessage()]);
$ grep -n "ba_behaviour_points" database/migrations/tenant/2026_06_16_130643_create_ba_triggers.php
(no output — no 45000 trigger on ba_behaviour_points; the only backstop is the CHECK constraint chk_ba_points_nonzero, which raises 23000-class, not 45000)
```

### F2 — Transactions and audit

clean — `DB::transaction(fn () => …)` in `award()` (line 149), `awardForIncident()` (line 176) and `reverse()` (line 224); `activityLog()` sits inside the transaction after the write (`write()`, lines 328-335) with verbatim events `'Created'` and `'Reversed'`; no mail/HTTP/file-delete side effects inside any transaction; no manual `beginTransaction`/`commit`. Check-then-act is locked: `reverse()` takes `lockForUpdate()` on the entry row and is doubly protected by the unique index `uq_ba_points_reverses` (migration line "unique('reverses_id')"; confirmed `UNI` in `SHOW INDEX`); `awardForIncident()` locks the incident row. Scanner candidate TXN-01 at `write()` line 319 is a false positive — `write()` is called only from inside the three transaction closures. Proved by `grep -n "DB::transaction\|activityLog\|lockForUpdate\|unique" Modules/BehaviouralAssessment/app/Services/BaBehaviourPointService.php` and `php artisan tinker --execute '…SHOW INDEX FROM ba_behaviour_points…'` (`uq_ba_points_reverses` uniq=Y).

### F3 — Authorization

clean — both routes authorize through FormRequest `authorize()` → `Gate::allows('tenant.behavioural-assessment.behaviour-points.award' / '.reverse')` (AUTH-01/02: FormRequests run before the controller, nothing is loaded first; AUTH-04: exactly one check, no Gate double). The strings come from service constants (AUTH-06). All four surfaces match: controller (FormRequests), view (`_behaviour-points.blade.php:71` `createPermission=…award`; `_behaviour-points-modals.blade.php:18,49` `permission=…award/…reverse`; `incidents.blade.php:11,34,50` `@can('…view')`), and `config/permissionslist.php:1435` (`'behavioural-assessment.behaviour-points' => ['view', 'award', 'reverse']` — the configuration's `flatten()` prepends `tenant.` to the two-segment key, producing exactly the gated strings). Each name is seeded with an **exact-name** query in the tenant DB: `sys_permissions` has 1 row each and `sys_role_has_permissions_jnt` has 3 role bindings each (role_id 1, 2, 3 on the test tenant).

### F4 — Validation and input

clean except ABP-02 — both FormRequests are typed and `validated()` is used end-to-end (no `$request->all()`, VAL-01/05). `BaBehaviourPointAwardRequest`'s cross-field zero-points rule lives in `withValidator()` (VAL-07) and **was executed** against a real payload:

```
$ php artisan tinker --execute '…Validator::make(["student_id"=>1,"points"=>0,"reason"=>"test award"], $rq->rules()); $rq->withValidator($v); $v->validate();…' → ValidationException errors["points"] = "Points cannot be zero — use a positive number for a merit or a negative one for a demerit."
```

`points` `between:-100,100` matches the service cap `MAX_MANUAL_POINTS=100`; `reason` `max:250` + service `Str::limit(…, 252)` fits `VARCHAR(255)`; the reverse reason `max:240` + `'Reversal: '` prefix (10 chars) = 250 ≤ 255 (VAL-05). `reversal_reason` is required, so `$request->validated()['reversal_reason']` cannot be a missing key (VAL-03). Uniqueness rules: none needed — the ledger has no unique user-facing name (VAL-04 n/a).

#### ABP-02 · L · VAL-07 / F13 #7 (message lie) — the "login not linked to a staff record" error is glued to the wrong form field

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M) — cross-field/business checks belong in the FormRequest `after()` hook, but any user-facing message must be attached where the user can act on it. Raised **from M to L**: the message text is accurate, only its placement is wrong. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php:61-69`, method `requireEmployee()`; call sites at lines 41 (`'student_id'`) and 54 (`'reversal_reason'`) |
| **Root cause** | `requireEmployee()` throws `ValidationException::withMessages([$field => '…'])`. The `$field` names the form control the error appears under — `student_id` on the award dialog, `reversal_reason` on the reverse dialog — but the failure has nothing to do with that field: it means the *logged-in user* has no `sch_employees` row. The UI already hides the dialogs for unlinked users (`_behaviour-points-modals.blade.php:10` `$bpData['employeeLinked']`), so this only fires on a direct POST, where it reads as "the student I picked is invalid". |
| **Consequence** | A staff user whose login is not linked to an employee record, submitting the award dialog directly, sees "Your login is not linked to a staff (employee) record." red-under the Student dropdown instead of as a general form error. |
| **Reproduce** | Static only — needs a user with the award permission but no `sch_employees` row; the modal is hidden for them, so only a crafted POST reaches it. |
| **Fix approach** | Throw `DomainException` with the same message instead of a field ValidationException. With ABP-01's rewrite in place, `run()`'s D2 catch shows it as a top-of-page flash — accurate placement, no field involved. Drop the now-unused `$field` parameter and `ValidationException` import. |
| **Plan item** | ABP-02 in `02-fix-plan.md` §3 |

```php
// BaBehaviourPointController.php:61-69 — CURRENT requireEmployee()
    private function requireEmployee(string $field): Employee
    {
        $employee = BaBehaviourPointService::currentEmployee();
        if ($employee === null) {
            throw ValidationException::withMessages([$field => 'Your login is not linked to a staff (employee) record.']);
        }

        return $employee;
    }
```

**Evidence**
```
$ grep -n "requireEmployee\|ValidationException" Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php
9:use Illuminate\Validation\ValidationException;
41:            $employee = $this->requireEmployee('student_id');
54:            $employee = $this->requireEmployee('reversal_reason');
65:            throw ValidationException::withMessages([$field => 'Your login is not linked to a staff (employee) record.']);
```

### F5 — Routes

clean — both routes are POST (RTE-01 safe); both point at methods that exist (RTE-02, verified by `php -l` + `route:list`); every public method is routed (RTE-03); `{entry}` is `whereNumber` and the method signature is `int $entry` (RTE-03 / module-finalization §3.3.1 — no unbound-model insert risk, the id is only used for `findOrFail`); the group middleware includes tenancy + auth + verified (RTE-05, verified in `RouteServiceProvider.php:25-33`); no `Route::resource` shares this prefix so RTE-06 does not apply.

### F6 — Controller shape

clean except ABP-03 — 96 lines / 3 public methods (CTL-01 n/a); no method over 80 lines (CTL-02 n/a); return types present (CTL-04); thin controller, business logic in the service (CTL-06 clean); no `compact()`, no `dd/dump` (CTL-07/09 clean); no dead private helpers (CTL-10 clean — both `run()` and `requireEmployee()` are called).

#### ABP-03 · L · CTL-03 — `reverse(int $entry)` uses id + `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — prefer route-model binding over `$id` + `findOrFail`. **Lowered from M to L**: the route parameter is `whereNumber`, the method never mass-assigns the id (it only finds), and a binding would require editing the shared route file, which this pass does not touch. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php:48-59`, method `reverse()`; route `Modules/BehaviouralAssessment/routes/web.php:151` |
| **Root cause** | The route declares the parameter as `{entry}` (raw id) rather than `{entry:baBehaviourPoint}` (bound model), so the controller re-queries with `BaBehaviourPoint::findOrFail($entry)`. |
| **Consequence** | None today — a missing entry 404s correctly. Only a style/maintainability gap (the id type and the lookup are fine). |
| **Reproduce** | Static only. |
| **Fix approach** | Not in this pass (route file is out of bounds). If ever changed: bind `{entry:baBehaviourPoint}` and type the parameter `BaBehaviourPoint $entry` — the service already type-hints `BaBehaviourPoint $entry`. |
| **Plan item** | none — see plan §10 |

```php
// BaBehaviourPointController.php:48-59 — CURRENT reverse()
    public function reverse(BaBehaviourPointReverseRequest $request, int $entry): RedirectResponse
    {
        $model = BaBehaviourPoint::findOrFail($entry);
        $reason = (string) $request->validated()['reversal_reason'];

        return $this->run('reverse', 'Entry reversed.', function () use ($model, $reason) {
```

**Evidence**
```
$ grep -n "public function reverse\|findOrFail" Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php
48:    public function reverse(BaBehaviourPointReverseRequest $request, int $entry): RedirectResponse
50:        $model = BaBehaviourPoint::findOrFail($entry);
```

### F7 — Models

clean except ABP-04 — `$fillable` declared with nothing sensitive (MDL-01); `$table = 'ba_behaviour_points'` exists in migration `database/migrations/tenant/2026_06_16_130640` (MDL-07, verified by `SHOW COLUMNS` on the live tenant); **no `deleted_at` column and no `SoftDeletes` trait — consistent** (MDL-02/SoftDeletes rule); `UPDATED_AT = null` + `created_at` cast present (the `$timestamps=false` catalogue rule); all six relationships are return-typed and resolve:

**Evidence**
```
$ php artisan tinker --execute '…tenancy()->initialize(…); (new BaBehaviourPoint)->student()→toSql()…'
student         BelongsTo  select * from `std_students` where `std_students`.`id` is null and `std_students`.`deleted_at` is null
academicSession BelongsTo  select * from `sch_org_academic_sessions_jnt` …
incident        BelongsTo  select * from `ba_incidents` …
awardedBy       BelongsTo  select * from `sch_employees` …
reverses        BelongsTo  select * from `ba_behaviour_points` …
reversals       HasMany    select * from `ba_behaviour_points` where `ba_behaviour_points`.`reverses_id` is null and `ba_behaviour_points`.`reverses_id` is not null
UPDATED_AT=NULL  CREATED_AT=created_at
```

#### ABP-04 · L · MDL-02 — `entry_type` enum column has no cast

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — `$casts` should cover every enum column. **Lowered from M to L**: the value stays a string, the DB enum constrains it, and every comparison site uses the model constants (`ENTRY_INCIDENT`, `ENTRY_MANUAL`, `ENTRY_REVERSAL`), so runtime behavior is identical without a cast. |
| **Where** | `Modules/BehaviouralAssessment/app/Models/BaBehaviourPoint.php:44-55`, `$casts` |
| **Root cause** | The `entry_type` column is `enum('incident','manual','reversal')` in the migration, but the model's casts list has no entry for it. |
| **Consequence** | A cast to a PHP `BackedEnum` would break the view comparisons `$e->entry_type === BaBehaviourPoint::ENTRY_REVERSAL` (an enum instance never `===` a string constant), so the correct behavior today is **no cast**. No user-visible consequence. |
| **Reproduce** | Static only. |
| **Fix approach** | None recommended in this pass — a string cast changes nothing, a PHP enum cast would require updating every comparison site (a separate decision). |
| **Plan item** | none — see plan §10 |

```php
// BaBehaviourPoint.php:44-55 — CURRENT $casts
    protected $casts = [
        'student_id' => 'integer',
        'academic_session_id' => 'integer',
        'incident_id' => 'integer',
        'points' => 'integer',
        'reverses_id' => 'integer',
        'awarded_by' => 'integer',
        'awarded_at' => 'datetime',
        'is_active' => 'boolean',
        'created_by' => 'integer',
        'created_at' => 'datetime',
    ];
```

**Evidence**
```
$ grep -n "entry_type" Modules/BehaviouralAssessment/app/Models/BaBehaviourPoint.php
(no output — no cast; the column is declared in the migration as enum and used via constants)
```

### F8 — Services and jobs

clean — `BaBehaviourPointService` never touches HTTP (SVC-01, no `request()/session()/redirect()`); constructor injection in the controller (SVC-02); no writes on read paths — `standing()`/`standings()` are SELECT/aggregate only (SVC-03); one implementation per operation (`award` manual, `awardForIncident` idempotent, `reverse` guarded, `reverseIncidentAward` reuses `reverse()`) (SVC-04); repeated lookups are one query per call, no loops (SVC-05). No jobs in scope.

### F9 — Queries and performance

clean — `exists()`, `value()`, `sum()`, `pluck()`, `groupBy`+`selectRaw` used instead of `get()` (QRY-04/05, e.g. `standing()` service lines 277-280, `standings()` 297-303); no query inside a loop (QRY-01); no interpolated raw SQL (QRY-11); the controller's two lookups (`requireEmployee`, `findOrFail`) run once per request.

### F10 — Views

clean for this controller — it renders no view at all; the two partials that POST to these routes (`_behaviour-points.blade.php`, `_behaviour-points-modals.blade.php`) are owned by the BaDashboardController report and are noted in §7. They compile cleanly and the form actions/permission strings match the routes:

**Evidence**
```
$ php -r '…compileString(file_get_contents($f)); php -l …'  → both partials: No syntax errors detected
```

### F11 — Security and tenancy

clean — no `env()` (SEC-01); no JSON responses, no personal-data over-exposure (SEC-02); no hard-coded ids or `?? 1` (SEC-03 — `BaActor` resolves the system user per database instead); no secrets logged (SEC-04); cache: none used (TEN-02 n/a); central models not touched from tenant code (TEN-03 n/a). `is_active` is forced true on every write and `standing()` sums only active rows.

### F12 — Style

clean — `declare(strict_types=1);` in all six PHP files (STY-01); Pint-clean:

**Evidence**
```
$ vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php … (6 files)
{"tool":"pint","result":"passed"}
```

camelCase names (STY-03), English comments without emoji (STY-04), one import per class (STY-05).

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutation (method) | 1 wrong-data overwrite | 2 delete-before-store | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` → service `award()` (ba_behaviour_points INSERT) | ok — new row only | ok — no deletes | ok — manual award is the only manual path | ok — no soft deletes; no unique on manual rows | ok — append-only, no check-then-act | ok — FormRequest gates | ABP-02 (field placement); flash "Behaviour points recorded." accurate | ok — consumed by `store` |
| `reverse` → service `reverse()` (ba_behaviour_points INSERT) | ok — never touches the original entry | ok — no deletes | ok — one reverse path | ok — `uq_ba_points_reverses` unique handles NULLs; no `deleted_at` | ok — `lockForUpdate()` on the entry + unique index (TXN-06) | ok — FormRequest gates | ok — "Entry reversed." and DomainException texts accurate | ok — consumed by `reverse` |
| service `awardForIncident()` (event-driven, listener AwardBehaviourPointsOnIncidentCreated) | ok — idempotent, re-uses existing award | ok | ok | ok | ok — `lockForUpdate()` on the incident row (line 178) | ok — not user-routed; mirrors the incident's reporter | ok — label built from incident | ok — listener wires it (verified by grep) |
| service `reverseIncidentAward()` (event-driven, listener ReverseBehaviourPointsOnIncidentCancelled) | ok — compensating row only | ok | ok — delegates to `reverse()` | ok | ok — inherits `reverse()` lock | ok — not user-routed; cancellation itself is gated by the incident controller | ok | ok — listener wires it (verified by grep) |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `resources/views/components/backend/tab/modal.blade.php` | The component ignores the `permission="…"` attribute (verified: `grep -n "permission" …modal.blade.php` → no usage). The incidents page guards correctly via `$bpCanAwardHere`/`$bpCanReverseHere` + the parent `@if($bpData['enabled'] && $bpData['employeeLinked'])`, so there is no leak — the attribute is dead weight, like the known `:canEdit` trap. | VIEW (F10) | BaDashboardController report / TenantCore component owner |
| `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | Only maps SQLSTATE `45000` with a `'BA: '` prefix. No 45000 trigger exists on `ba_behaviour_points` (the module's triggers cover rating scales/periods/assessments/incidents), so on THIS controller's writes the branch can never fire; other BA controllers (`BaClassCategoryController`, `BehaviouralScoreService`) use the same helper on tables that DO have triggers — keep it. | ERR / informational | this report owns it; others link |
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php` (`behaviourPointsData()`) | The ledger paginates at 15 (`bpl_page`) while standings paginate at 10 (`bp_page`) — QRY-13/`list paginate at 10` default. Eager loads (`student`, `awardedBy`, `incident`, `reversals`) are present, so no N+1. | QRY-13 (L) | BaDashboardController report |

## 8. Not covered, and why

- The two blades were compiled, not rendered in a browser (no authenticated session in this run; D4 anyway).
- No end-to-end click-through of the award/reverse dialogs (no staff-role browser login available to this read-only audit).
- The permission-refusal path (403 from the FormRequest) is not exercised — no seeded role without the permission was logged in (D4).
- `awardForIncident()` and `reverseIncidentAward()` were verified statically (callers found by grep); their event flows (`AwardBehaviourPointsOnIncidentCreated`, `ReverseBehaviourPointsOnIncidentCancelled`) were not fired.
- `BaIncidentService::currentEmployee()`, `BaIncident`, `BaConfig` were checked only as used by this controller/service — their full audit belongs to their owning controllers' reports.