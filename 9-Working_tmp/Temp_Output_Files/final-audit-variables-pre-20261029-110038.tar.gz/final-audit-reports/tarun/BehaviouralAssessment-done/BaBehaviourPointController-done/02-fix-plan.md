# Fix Plan — BehaviouralAssessment / BaBehaviourPointController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/BehaviouralAssessment/routes/web.php` | Route file — changes here would be a DECISION (ABP-03 is deliberately not fixed) |
| `database/migrations/tenant/2026_06_16_130640_create_ba_behaviour_points_table.php` | Existing migration — never edit; the unique index `uq_ba_points_reverses` is load-bearing for the reversal race |
| `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php`, `app/Models/BaIncident.php`, `app/Models/BaConfig.php` | Owned by other controllers' reports |
| `Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/*` | Owned by the BaDashboardController (incidents page) report |
| `config/permissionslist.php` | Shared; permission names are already correct and seeded — nothing to change |

## 1. Blockers reachable today

(none — no B findings)

## 2. Fixes that arm a latent defect (sequenced)

(none)

## 3. Errors & transactions (F1/F2)

- [ ] **ABP-01** · H · ERR-00 (D1) — rewrite `run()` to the D2 shape: keep only the `catch (DomainException)` business-rule branch and let everything else bubble to the central handler.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php`
  - **Before** (`BaBehaviourPointController.php:71-95`):
    ```php
        /**
         * One success/failure path: validation, 404 and HTTP aborts pass through (Rule A1); a
         * DomainException (ledger off, already reversed, reversal of a reversal) or a trigger
         * rejection becomes a flash error; anything else is logged and reported generically.
         */
        private function run(string $method, string $success, callable $action): RedirectResponse
        {
            try {
                $action();
            } catch (ValidationException|ModelNotFoundException|HttpExceptionInterface $e) {
                throw $e;
            } catch (DomainException $e) {
                return back()->withInput()->with('error', $e->getMessage());
            } catch (Throwable $e) {
                $trigger = BaTriggerError::message($e);
                if ($trigger !== null) {
                    return back()->withInput()->with('error', $trigger);
                }
                Log::error('BaBehaviourPointController::'.$method.' failed', ['error' => $e->getMessage()]);

                return back()->withInput()->with('error', 'The operation could not be completed.');
            }

            return redirect()->route('behavioural-assessment.incidents-page', self::BACK_TAB)->with('success', $success);
        }
    ```
  - **After:**
    ```php
        /**
         * One success/failure path: business-rule rejections (ledger off, already reversed, reversal
         * of a reversal) surface as a flash error; everything else — validation failures, 404s,
         * HTTP aborts, unexpected exceptions — bubbles to the central handler (D1/D2, ABP-01).
         */
        private function run(string $method, string $success, callable $action): RedirectResponse
        {
            try {
                $action();
            } catch (DomainException $e) {
                // ERR-01 (D2): a DomainException message is a curated business-rule message; safe to show.
                return back()->withInput()->with('error', $e->getMessage());
            }

            return redirect()->route('behavioural-assessment.incidents-page', self::BACK_TAB)->with('success', $success);
        }
    ```
  - **Also (same file):** delete the now-unused imports from the `use` block: `use Illuminate\Database\Eloquent\ModelNotFoundException;`, `use Illuminate\Support\Facades\Log;`, `use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;`, `use Throwable;`, `use Modules\BehaviouralAssessment\Support\BaTriggerError;`. Keep `use DomainException;` and `use Illuminate\Validation\ValidationException;` (the latter is still used until ABP-02 is applied).
  - **Verify:** `grep -n "catch (\|Log::\|BaTriggerError\|ModelNotFoundException\|HttpExceptionInterface\|Throwable" Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php`
  - **Expect:** exactly one catch line (`} catch (DomainException $e) {`) and no `Log::`, no `BaTriggerError`, no unused-import hits.
  - **Effort:** S

## 4. Authorization (F3)

(none — F3 clean)

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **ABP-02** · L · VAL-07 — throw a `DomainException` (top-of-page flash) instead of a field-attached `ValidationException` when the login has no `sch_employees` row.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php`
  - **Before** (`BaBehaviourPointController.php:61-69`):
    ```php
        private function requireEmployee(string $field): Employee
        {
            $employee = BaBehaviourPointService::currentEmployee();
            if ($employee === null) {
                throw ValidationException::withMessages([$field => 'Your login is not linked to a staff (employee) record.']);
            }

            return $employee;
        }
    ```
  - **After:**
    ```php
        private function requireEmployee(): Employee
        {
            $employee = BaBehaviourPointService::currentEmployee();
            if ($employee === null) {
                throw new DomainException('Your login is not linked to a staff (employee) record.');
            }

            return $employee;
        }
    ```
  - **Also (same file, call sites 41 and 54):** change `$this->requireEmployee('student_id')` to `$this->requireEmployee()` and `$this->requireEmployee('reversal_reason')` to `$this->requireEmployee()`; then delete the now-unused import `use Illuminate\Validation\ValidationException;` (Pint does not remove it automatically).
  - **Verify:** `grep -n "requireEmployee\|ValidationException" Modules/BehaviouralAssessment/app/Http/Controllers/BaBehaviourPointController.php`
  - **Expect:** two bare `$this->requireEmployee();` calls, no `ValidationException` (import or throw), and no `->requireEmployee('…')` with an argument.
  - **Effort:** S

## 6. Queries & performance (F9)

(none — F9 clean)

## 7. Views (F10)

(none — F10 clean for this controller)

## 8. Style (F12) — one item per file

(none — the in-scope files are already Pint-clean; run `vendor/bin/pint <file> --format agent` on the controller after ABP-01/ABP-02 per standing rules)

## 9. Deferred / decisions

(none)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| ABP-03 | Route-model binding on `reverse()` would require editing `routes/web.php` (out of bounds for this pass, §0). The current shape is safe: `whereNumber('entry')` + `findOrFail()` 404s correctly and the id is never mass-assigned. Accepted as style debt. |
| ABP-04 | The `entry_type` enum column has no cast. A string cast changes nothing at runtime; a PHP `BackedEnum` cast would break every `===` comparison against the string constants (`ENTRY_INCIDENT`, `ENTRY_MANUAL`, `ENTRY_REVERSAL`) in the dashboard views. Accepted; revisit if the module standardizes on enums. |