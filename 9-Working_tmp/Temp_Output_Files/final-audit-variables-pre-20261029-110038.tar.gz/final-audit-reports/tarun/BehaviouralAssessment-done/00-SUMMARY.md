# BehaviouralAssessment — Final Audit Summary

Protocol: `.claude/rules/final-audit.md` §13.2 · Developer: `tarun` · Audited 2026-10-12 by `opencode`
Module: `Modules/BehaviouralAssessment` · 18 controllers · Read-only audit — no `prime_ai_dev/` code was changed.

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| BaAuditLogController | 188 | 0 | 0 | 2 | 3 | 3 | Leading-wildcard `LIKE '%…%'` + `SELECT DISTINCT` over the unindexed, ever-growing `ba_audit_log` on every page load. | [01-report](BaAuditLogController-done/01-report.md) |
| BaBehaviourPointController | 96 | 0 | 1 | 0 | 3 | 0 | Every write wraps in a controller try/catch (D1) whose generic `catch (Throwable)` swallows `QueryException` and loses the stack trace; the `BaTriggerError` branch can never fire. | [01-report](BaBehaviourPointController-done/01-report.md) |
| BaCommentBankController | 273 | 0 | 1 | 8 | 1 | 1 | `restore` un-trashes over a CSRF-less GET route — a prefetcher can silently restore a row. | [01-report](BaCommentBankController-done/01-report.md) |
| BaCategoryController | 537 | 0 | 2 | 8 | 5 | 1 | `forceDelete` bypasses `destroy`'s `usageReason()` guard and cascade-deletes live category mappings/criteria. | [01-report](BaCategoryController-done/01-report.md) |
| BaClassScaleController | 142 | 0 | 1 | 4 | 2 | 3 | All three writes wrap `DB::transaction` in a try/catch (D1) with `BaTriggerError` dead code. | [01-report](BaClassScaleController-done/01-report.md) |
| BaInterventionController | 308 | 0 | 1 | 7 | 4 | 4 | `restore` un-deletes over a CSRF-less GET route. | [01-report](BaInterventionController-done/01-report.md) |
| BaRatingScaleController | 584 | 0 | 1 | 9 | 5 | 4 | `restore` mutates state over GET; `storeLevel/updateLevel/destroyLevel` have no caller anywhere in the app. | [01-report](BaRatingScaleController-done/01-report.md) |
| BaNotificationController | 66 | 0 | 2 | 7 | 2 | 4 | Outbox status writes + `ba_incidents.is_notified` commit as two statements — a crash between leaves them disagreeing. | [01-report](BaNotificationController-done/01-report.md) |
| BaInterventionCaseController | 194 | 0 | 0 | 5 | 3 | 4 | Shared `run()` error helper logs only `getMessage()` — every unexpected failure loses class + trace. | [01-report](BaInterventionCaseController-done/01-report.md) |
| BaClassCategoryController | 268 | 0 | 0 | 6 | 2 | 3 | All five writes in try/catch (D1), logging only `$e->getMessage()`. | [01-report](BaClassCategoryController-done/01-report.md) |
| BaConfigController | 277 | 0 | 2 | 5 | 1 | 4 | Five writes wrap transactions in try/catch (D1) with dead `BaTriggerError` branch and (for `restore`) a live-name clash that fails with a misleading flash. | [01-report](BaConfigController-done/01-report.md) |
| BaIncidentController | 581 | 1 | 2 | 13 | 6 | 7 | `store()` uploads attachments inside `DB::transaction` — a post-file failure/rollback orphans evidence files. | [01-report](BaIncidentController-done/01-report.md) |
| BaAssessmentController | 622 | 0 | 1 | 12 | 6 | 4 | `restore` un-trashes an assessment sheet over GET with no CSRF token. | [01-report](BaAssessmentController-done/01-report.md) |
| BaIncidentAttachmentController | 112 | 0 | 0 | 2 | 2 | 1 | Transactions wrapped in try/catch (D1) with dead `BaTriggerError`; inherits BAI-01 (file written inside tx). | [01-report](BaIncidentAttachmentController-done/01-report.md) |
| BaReportExportController | 63 | 1 | 1 | 4 | 1 | 0 | Raw exception text (possibly SQL) is stored in `ba_report_exports.error_message` and shown to the user. | [01-report](BaReportExportController-done/01-report.md) |
| BaAssessmentPeriodController | 427 | 0 | 2 | 9 | 3 | 3 | Restore lacks a live-name clash check → generic flash, and restore-over-GET (RTE-01). | [01-report](BaAssessmentPeriodController-done/01-report.md) |
| BaReportController | 854 | 2 | 1 | 11 | 4 | 3 | Raw exception text reaches users twice (export flash + `ba_score_runs.error_message` tooltip). | [01-report](BaReportController-done/01-report.md) |
| BaDashboardController | 2151 | 0 | 2 | 6 | 2 | 5 | Demographics GET `?tab=…&dm_period_id=…` writes a `ba_audit_log` row — analytics runs nobody ran. | [01-report](BaDashboardController-done/01-report.md) |
| **TOTAL** | **** | **4** | **20** | **118** | **55** | **54** | **197 findings · 36 fix-plan files** | |

## Module totals

- **197 findings**: B 4 · H 20 · M 118 · L 55 · **54 DECISION items** across 18 controllers.
- **2 B-severity blockers** (reachable today): orphaned evidence files on rollback (`BaIncidentController`), raw SQL in user-facing messages (`BaReportExportController`).
- No existing module migrations — DDL lives in `pgdatabase/` / tenant migration folders; table names resolved from each model's `$table`.

## Cross-controller families (same defect in N controllers — fix as ONE change)

| # | Family | Rule | Present in | Note |
|---|---|---|---|---|
| F-A | **Controller-level `try/catch` around `DB::transaction`, logging `$e->getMessage()`, with a dead `BaTriggerError` branch** | ERR-00/D1, ERR-05, D2 | 12 controllers (BehaviourPoint, CommentBank, ClassScale, Category, Intervention, RatingScale, InterventionCase, ClassCategory, Config, IncidentAttachment, AssessmentPeriod, Assessment) | The `run()` helper with `catch (\Throwable)` is copy-pasted module-wide. The `BaTriggerError` SQL-45000 branch **can never fire** — no BA table has DB triggers. One module-wide decision: remove the helper, let `bootstrap/app.php` render. |
| F-B | **`restore` mutates state over GET** (no CSRF, prefetchable) | RTE-01 | CommentBank, Intervention, RatingScale, Assessment, AssessmentPeriod, Category, Incident, Dashboard (BH-02), Config | Fix in each plan: change route to POST/PUT or guard with CSRF + confirm. |
| F-C | **`$id` + `findOrFail` instead of route-model binding** | CTL-03 | CommentBank, Category, Intervention, RatingScale, AssessmentPeriod, Assessment | Route param name often matches method args — binding is safe except where a gate must run first (see BaNotification's deliberate CTL-03 non-finding). |
| F-D | **AUTH-04: duplicate `authorize()`** (FormRequest `authorize()` + `Gate::authorize` in controller) | AUTH-04 | CommentBank, Category, ClassScale, Config, others | Accepted in several plans (§10) when it's a belt-and-braces check — Tarun to decide per tick. |
| F-E | **N+1 in `reorder()`** (`where()` in a loop assign each order) | QRY-01 | CommentBank, Category, Intervention, RatingScale | One bulk `update`/`upsert` per reorder. |
| F-F | **CTL-01 god-controllers** | CTL-01 | Dashboard (2151), Report (854), Assessment (622) | Splits are DEFERRED per D3 — recorded as DECISION items in each plan. |

## Shared classes

53 classes registered in `final-audit-reports/00-CLASS-OWNERS.md` (models, services, jobs, exports, support helpers, shared blades). Each later report links to its owner instead of re-auditing. Owners by first-reacher:
- Models: BaAuditLog + BaAssessmentPeriod (BaAuditLog) · BaBehaviourPoint (BaBehaviourPoint) · BaCommentBank (BaCommentBank) · BaCategory + BaCriterion (BaCategory) · BaClassScaleJnt + BaAssessmentRating (BaClassScale) · BaIntervention (BaIntervention) · BaRatingScale + BaRatingLevel (BaRatingScale) · BaNotification (BaNotification) · BaIncident* + services (BaIncident) · BaAssessment + BaStudentRemark + BaAssessmentStatusHistory (BaAssessment) · BaReportExport (BaReportExport) · BaComputedScore (BaAssessmentPeriod) · BaComputedOverall (BaReport) · BaScoreRun + BaFrameworkSnapshot (BaDashboard).
- Services: BaBehaviourPointService, BaPeriodService, BaAssessmentService, BaReviewSignalService, BaNotificationService, BaInterventionCaseService, BaIncidentService, BaIncidentAttachmentService, BaWitnessService, BaReportExportService, BaFrameworkSnapshotService, BehaviouralScoreService.
- Support: BaActor (BaCommentBank) · BaTriggerError (BaBehaviourPoint) · BaDispatch (BaNotification) · BaDashboardCache (BaDashboard).

## Decisions that apply module-wide (decide once per batch of ticks)

1. **F-A** — remove the dead `BaTriggerError` branch + controller try/catch across the module (D1/D2). Touches 12 controllers.
2. **F-B** — `restore`-over-GET route shape: accept per-controller POST changes (each plan has the item; Tatun may tick all).
3. **route-model binding (F-C)** and **AUTH-04 (F-D)** — tick per controller; no module-wide tie needed since each plan is self-contained.

---
**Hand-back:** all 18 controllers `AUDITED`, 36 report files, 197 findings (B4/H20/M118/L55), 54 DECISIONs, self-check PASS 18/18. Tick items in each `02-fix-plan.md`, then run `final-audit-fixer` per controller path (developer `tarun`).
## Fix pass — 2026-10-22 (opencode)

All 18 controllers are `FIXED`; every plan item was applied with the ⭐ option for the 54 DECISIONs (most were defer/accept, so no code change). Shared route edits were applied once in `Modules/BehaviouralAssessment/routes/web.php`: the eight `restore` routes are POST, the three unused rating-scale level routes were retired, and the rating-scale resource now binds `{ratingScale}`. `BAI-13` was completed as a real AJAX type-ahead (new `GET incidents/options`, `BaIncidentController::options()`, and rewrites of the witness-picker partial plus the create/edit/dashboard forms).

One new additive tenant migration was written and **not run**: `database/migrations/tenant/2026_10_22_000001_add_field_name_index_to_ba_audit_log_table.php` (`idx_ba_audit_field`). Run `php artisan tenants:migrate` when convenient.

The controller folders and this module folder now carry the `-done` suffix; every report link in `00-INDEX.md`, `00-SUMMARY.md`, `00-CLASS-OWNERS.md` and the two portal reports that reference this module resolves.
