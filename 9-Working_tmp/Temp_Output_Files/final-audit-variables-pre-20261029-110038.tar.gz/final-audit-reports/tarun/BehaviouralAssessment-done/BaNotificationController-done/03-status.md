# Status — BehaviouralAssessment / BaNotificationController

**Fixed:** 2026-10-22 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work

none — orchestrator confirmed no route changes for this controller.

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| BNC-01 | `BaNotificationService.php:676,758,774,793,1045` (calls) · `:826-831` (helper) | Added `persistOutcome()` (one `DB::transaction` around the status write + `syncIncidentNotified`) and routed the five status writes (`retry` reset, `attempt` sent, `attempt` failure, `markFailed`, `suppress`) through it. | `grep -n "DB::transaction\|persistOutcome(" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php` | 2 × `DB::transaction` (helper + BNC-12's retry lock, see note) · 6 × `persistOutcome(` (1 declaration, 5 calls) | 2026-10-22 |
| BNC-03 | `BaNotificationService.php:749` | `Log::warning('BA notification delivery failed', …)` now logs `'exception' => $e` instead of `'error' => $e->getMessage()`. `$errors[] = $e->getMessage()` (the stored failure reason) is unchanged. Controller half was applied first, then removed with the BNC-02 catch (net: no controller log remains). | `grep -n "error.*=>.*getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php Modules/BehaviouralAssessment/app/Services/BaNotificationService.php` | no matches | 2026-10-22 |
| BNC-05 | `BaNotificationService.php:129-132` (ctor) · `:294,345,390` | Injected `private BaAssessmentService $assessments` (same namespace, no import) and replaced the three `app(BaAssessmentService::class)->configFor(...)` calls with `$this->assessments->configFor(...)`. | `grep -n "app(BaAssessmentService" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php` | no matches | 2026-10-22 |
| BNC-10 | `BaNotification.php` (former `:149-153`) | Deleted the unused `scopePending()`. Callers checked repo-wide before removal: none. | `grep -n "scopePending" Modules/BehaviouralAssessment/app/Models/BaNotification.php` | no matches | 2026-10-22 |
| BNC-04 | `BaNotificationService.php:961-982` | Parent-contact resolution now collects `$guardians` once, prefetches valid ids with one `User::whereIn(...)` query, then maps contacts — no `User::whereKey(...)` inside the map. | `grep -n "User::whereKey" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php` | no matches | 2026-10-22 |
| BNC-11 | `BaNotificationController.php:37` | Success flash changed to `Notification #<id> retry requested.` | `grep -n "queued for another attempt" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php` | no matches | 2026-10-22 |
| BNC-02 (a) | `BaNotificationController.php:30-35` · `BaNotificationService.php:666-696` | Broad `catch (Throwable)` removed; the controller keeps only `catch (\DomainException $e)` and shows `$e->getMessage()`. The `BaTriggerError` mapping moved into `BaNotificationService::retry()`: a `QueryException` with a `BA:` signal is rethrown as `\DomainException($triggerMessage, 0, $e)`; any other `QueryException` is rethrown unchanged. | `grep -n "catch (\\\\DomainException\|BaTriggerError::message" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php Modules/BehaviouralAssessment/app/Services/BaNotificationService.php` | controller `32: } catch (\DomainException $e) {`; service `690: $triggerMessage = BaTriggerError::message($e);` | 2026-10-22 |
| BNC-06 (a) | `BaNotificationService.php:669-688` · `BaNotificationController.php` (guard deleted) | Retryable-status rule now lives only in `BaNotificationService::retry()`: `\DomainException('Only a failed or suppressed notification can be retried.')` for any status other than failed/suppressed. The controller's 3-line guard was deleted; the controller only catches and shows the message. | `grep -n "STATUS_FAILED, BaNotification::STATUS_SUPPRESSED" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php Modules/BehaviouralAssessment/app/Services/BaNotificationService.php` | only `BaNotificationService.php:674` (single copy) | 2026-10-22 |
| BNC-12 (a) | `BaNotificationService.php:666-696` | `retry()` re-reads the row with `BaNotification::whereKey(...)->lockForUpdate()->firstOrFail()` inside `DB::transaction`, re-checks the status, calls `persistOutcome()` inside the lock, and dispatches **after** the transaction commits (the locked row is returned from the closure and passed to `dispatchPending()`). | `grep -n "lockForUpdate" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php` | `670: $row = BaNotification::whereKey($notification->getKey())->lockForUpdate()->firstOrFail();` | 2026-10-22 |

### Decisions recorded 2026-10-22

| DECISION | Choice | Effect |
|---|---|---|
| BNC-02 | **(a)** ⭐ | Broad catch removed; only `\DomainException` handled in the controller; `BaTriggerError` mapping moved into `BaNotificationService::retry()`. |
| BNC-06 | **(a)** ⭐ | Retryable-status rule moved into the service; controller guard deleted. |
| BNC-09 | **(a)** ⭐ | Deferred to the split pass (D3) — no code change (see §3). |
| BNC-12 | **(a)** ⭐ | Row lock + status re-check inside a transaction; dispatch after commit. |

> **BNC-01 verify-count note:** the plan expected one `DB::transaction` line (the helper). The file now has
> two: the helper's (`:828`) and the one BNC-12(a) requires in `retry()` (`:669`). The `persistOutcome(`
> count is exactly six as expected. The extra transaction is the approved BNC-12(a) change, not drift.

## 3. Not applied

| ID | Reason (not ticked / already applied / superseded / blocked) | Detail |
|---|---|---|
| BNC-09 | deferred by decision (a) | No code change. `BaNotificationService` remains 1,099 lines; the split (delivery half out, `evaluate*` kept) is deferred to the split pass per D3. |
| BNC-03 (controller half) | superseded by BNC-02(a) | The item's controller edit (`Log::error(...)` → `report($e)`) was applied in plan order, then the whole `catch (Throwable)` block was removed by BNC-02(a) as approved. The service half of BNC-03 stands. |

## 4. Needs Tarun's hand

- **Nothing to run:** no migration, no seeder, no permission key change (`tenant.behavioural-assessment.notifications.retry` already exists).
- **Folder rename / index:** not done here — `00-INDEX.md` and `00-CLASS-OWNERS.md` are centrally managed (plan §0). Main session should mark the row `FIXED` and, per protocol §10.1, `git mv` this folder to `BaNotificationController-done` and repoint links.

## 5. Unverifiable by this workflow (no tests, D4)

- The runtime Retry path: row-lock behaviour under two overlapping POSTs (BNC-12), post-commit dispatch (BNC-12), the `BA:` trigger → `\DomainException` mapping (BNC-02), and the redirect/flash text (BNC-11).
- `persistOutcome()` atomicity under a forced mid-transaction failure (BNC-01) — verified statically only.
- Guardian contact resolution output equality with the old per-guardian `exists()` check (BNC-04).

## 6. Verification log

```
$ php -l Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
$ php -l Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php
$ php -l Modules/BehaviouralAssessment/app/Models/BaNotification.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Models/BaNotification.php

$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); var_dump(class_exists(Modules\BehaviouralAssessment\Http\Controllers\BaNotificationController::class)); var_dump(class_exists(Modules\BehaviouralAssessment\Services\BaNotificationService::class)); var_dump(class_exists(Modules\BehaviouralAssessment\Models\BaNotification::class));'
bool(true)
bool(true)
bool(true)

$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json >/dev/null && echo ROUTES-OK
ROUTES-OK

$ vendor/bin/pint Modules/BehaviouralAssessment/app/Services/BaNotificationService.php Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php Modules/BehaviouralAssessment/app/Models/BaNotification.php --format agent
{"tool":"pint","result":"fixed","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Services\/BaNotificationService.php","fixers":["fully_qualified_strict_types","unary_operator_spaces","braces_position","not_operator_with_successor_space","single_line_empty_body","ordered_imports"]}]}

# post-Pint re-run (§10 requires php -l + class_exists after Pint)
$ php -l Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
$ php -l Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php
$ php -l Modules/BehaviouralAssessment/app/Models/BaNotification.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Models/BaNotification.php
$ php -r '... class_exists(...)'
bool(true)
bool(true)
bool(true)
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json >/dev/null && echo ROUTES-OK
ROUTES-OK

$ grep -n "DB::transaction\|persistOutcome(" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
669:            $row = DB::transaction(function () use ($notification): BaNotification {
676:                $this->persistOutcome($row, [
758:            $this->persistOutcome($row, [
774:        $this->persistOutcome($row, [
793:        $this->persistOutcome($row, [
826:    private function persistOutcome(BaNotification $row, array $attributes): void
828:        DB::transaction(function () use ($row, $attributes): void {
1045:        $this->persistOutcome($row, [

$ grep -n "error.*=>.*getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
(no output)

$ grep -n "app(BaAssessmentService" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
(no output)

$ grep -n "scopePending" Modules/BehaviouralAssessment/app/Models/BaNotification.php
(no output)

$ grep -n "User::whereKey" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
(no output)

$ grep -n "queued for another attempt" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php
(no output)

$ grep -n "lockForUpdate\|catch (\\DomainException" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php
Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:670:                $row = BaNotification::whereKey($notification->getKey())->lockForUpdate()->firstOrFail();
Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php:32:        } catch (\DomainException $e) {
```

## 7. Final state

Status: FIXED · Open: B 0 · H 0 · M 0 · L 0 · BNC-09 deferred by decision (a) to the split pass
