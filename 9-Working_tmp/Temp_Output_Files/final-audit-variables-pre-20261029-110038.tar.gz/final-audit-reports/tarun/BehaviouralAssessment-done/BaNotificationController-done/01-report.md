# Final Audit — BehaviouralAssessment / BaNotificationController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php` (66 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `POST /behavioural-assessment/notifications/{notification}/retry` is the only route. The button that posts it lives on the Outbox tab: `GET /behavioural-assessment/incidents-page?tab=outbox` |
| Menu path | Behavioural Assessment → Incidents page → **Outbox** tab |
| Who uses it | Roles holding `tenant.behavioural-assessment.notifications.retry`: Super Admin (role 1), School Admin (role 2), Principal (role 3) — measured in `sys_role_has_permissions_jnt` on test.localhost |
| What a user does here | The Outbox lists every notification the Behavioural Assessment module tried to send (to a parent, an employee, or a role). When one fails or is suppressed it shows in red. A user with the retry permission opens the row's action menu and clicks **Retry**; the controller puts that one row back to `pending` and asks the service to deliver it again |
| Tables written | `ba_notifications` (`status`, `failure_reason`, `suppress_reason`, `last_attempt_at`, `sent_at`, `attempt_count`, `updated_by` — and by the service during delivery), `ba_incidents` (`is_notified`) |
| Tables read | `ba_notifications`, `ba_incidents`, `std_student_guardian_jnt`, `std_guardians`, `std_students`, `std_student_academic_sessions`, `sch_class_sections`, `sch_employees`, `sys_users`, `sys_permissions`, `ntf_notifications`, `ntf_templates` |
| Live data | `ba_notifications` on test.localhost: **0 rows, 0 trashed** (pending 0, sent 0, failed 0, suppressed 0). The Retry button therefore cannot be exercised against data today — the route is reachable but has nothing to act on |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is small and thin, and its authorization, tenant middleware and route wiring are correct — but two problems follow it, one in the controller and one in the 1,065-line service it calls. The controller keeps a `try/catch (Throwable)` of its own, which D1 forbids; the service, on every status write, commits the `ba_notifications` update and the `ba_incidents.is_notified` update as two separate transactions. The single worst finding is **BNC-01**: the outbox status write and the incident flag are not atomic (two commits instead of one), so a failure between them leaves the outbox and the incident disagreeing — the outer action is reachable from the Retry button today. The rest is medium: a per-guardian N+1 query in the delivery path, `app()` calls mid-method, a duplicated retryable-status rule, and the usual shape debt. Nothing here is a Blocker; the plan is roughly a half-day, most of it in the service.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 7 | 2 | 4 | 11 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BNC-02, BNC-03 | F8 Services/Jobs | BNC-05, BNC-06 |
| F2 Transactions/Audit | BNC-01, BNC-12 | F9 Queries/Perf | BNC-04 |
| F3 Authorization | clean | F10 Views | clean (no view rendered) |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | BNC-11 |
| F6 Controller shape | BNC-07, BNC-09 | F13 Deep read | table in §6 |
| F7 Models | BNC-10 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php` | controller | 66 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Models/BaNotification.php` | model (`ba_notifications`) | 153 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php` | service | 1065 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Jobs/DispatchNotificationJob.php` | job (dispatched by the service) | 61 | this report | ✅ |
| 5 | `Modules/BehaviouralAssessment/app/Support/BaDispatch.php` | support (inline/async switch) | 32 | this report | ✅ |
| 6 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support | 37 | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |
| 7 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | 45 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 8 | `Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/_outbox.blade.php` | blade partial (renders the Retry button) | 218 | ↗ BaDashboardController (report not yet written) | ↗ linked |

No pre-applied files. The outbox partial is rendered by `BaDashboardController::outboxData()`, which already eager-loads `recipientStudent`, `recipientEmployee.user` and `incident:id,incident_no`, so it is out of this report and its own audit is clean on that point.

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | (filter BaNotificationController@)
POST    behavioural-assessment/notifications/{notification}/retry    behavioural-assessment.notifications.retry    Modules\BehaviouralAssessment\Http\Controllers\BaNotificationController@retry
```

Registered at `Modules/BehaviouralAssessment/routes/web.php:146`, inside the group built by
`Modules/BehaviouralAssessment/app/Providers/RouteServiceProvider.php:25-36` with middleware
`web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`,
`EnsureTenantHasModule:BehaviouralAssessment`, `auth`, `verified`, prefix `behavioural-assessment`,
name `behavioural-assessment.`. The route is POST (no state change over GET), the method exists,
and the parameter name `{notification}` matches the argument `$notification`.

Unrouted public methods: none. `backToOutbox()` is `private` and correctly not routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `retry` | 31 | POST `behavioural-assessment/notifications/{notification}/retry` | `tenant.behavioural-assessment.notifications.retry` | none — the service's `retry()` writes with no transaction | none | `ba_notifications`, `ba_incidents` | BNC-02, BNC-03, BNC-06, BNC-11, BNC-12 |
| `backToOutbox` (private) | 57 | — | — | — | — | none (builds a redirect) | — |
| `__construct` | 126 | — | — | — | — | none | — |
| `evaluateIncident` | 138 | not routed (event listener) | — | none | none | `ba_notifications` | — |
| `evaluateEscalation` | 220 | not routed (job) | — | none | none | `ba_notifications` | — |
| `evaluateReviewPending` | 281 | not routed (event listener) | — | none | none | `ba_notifications` | BNC-05 |
| `evaluateAssessmentDeadline` | 326 | not routed (job) | — | none | none | `ba_notifications` | BNC-05 |
| `evaluateAssessmentOverdue` | 367 | not routed (job) | — | none | none | `ba_notifications` | BNC-05 |
| `evaluateInterventionAssigned` | 431 | not routed (event listener) | — | none | none | `ba_notifications` | — |
| `evaluateInterventionOverdue` | 461 | not routed (job) | — | none | none | `ba_notifications` | — |
| `evaluateDailyDigest` | 509 | not routed (job) | — | none | none | `ba_notifications` | — |
| `evaluateExportReady` | 562 | not routed (service call) | — | none | none | `ba_notifications` | — |
| `dispatchPending` | 644 | — | — | — | — | none (dispatches the job) | — |
| `retry` (service) | 657 | reached by this controller | — | none | none | `ba_notifications`, `ba_incidents` | BNC-01, BNC-06, BNC-12 |
| `attempt` (service) | 681 | reached via the job | — | none | none | `ba_notifications`, `ba_incidents` | BNC-01, BNC-03, BNC-07 |
| `markFailed` (service) | 770 | reached via the job's `failed()` | — | none | none | `ba_notifications`, `ba_incidents` | BNC-01 |
| `syncIncidentNotified` (service) | 787 | — | — | part of BNC-01 | none | `ba_incidents` | BNC-01 |
| `obligate` (service, private) | 816 | — | — | none | none | `ba_notifications` | — |
| `suppress` (service, private) | 1008 | — | — | none | none | `ba_notifications`, `ba_incidents` | BNC-01 |
| `resolveContacts` (service, private) | 931 | — | — | — | — | none (reads) | BNC-04 |
| `draftSheets`, `assessmentPayload`, `interventionPayload`, `employeeRecipient`, `channels`, `configFor`, `setting`, `parentRecipient`, `roleRecipient`, `classTeacherRecipient`, `isEventConfigured`, `incidentPayload`, `studentPayload`, `classSectionLabel` (service, private) | 596-1063 | — | — | — | — | none (read/build helpers) | — |

**Tables each mutation SHOULD touch, vs what it does:**
- Controller `retry` — should reset one `ba_notifications` row and re-derive `ba_incidents.is_notified` for an incident row: does both, but as two separate commits (BNC-01).
- Service `attempt` — should write one outcome on `ba_notifications` plus the same incident flag: does both, as two commits (BNC-01).
- Service `markFailed` / `suppress` — same pair: two commits (BNC-01).
- Service `obligate` — creates one `ba_notifications` row per recipient per channel: single table, no audit row (see F2 note).

## 6. Findings

### F1 — Errors

#### BNC-02 · M · ERR-00 — the controller catches every Throwable from the service (D1 forbids a controller catch)

| Field | Value |
|---|---|
| **Rule** | ERR-00 (settled by D1, M) — *no try/catch in a controller; the only allowed catches are D2's `\DomainException`, the truncate-then-rebuild catch, and `SnapshotProtectionException`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php:40-51`, method `retry()` |
| **Root cause** | The controller wraps `$service->retry($row)` in a `try`, re-throws Validation/ModelNotFound/Http exceptions, then `catch (Throwable $e)` turns everything else into an error flash. D1 moves failure handling to the service and the central handler; the service's own business signal, `\DomainException` (thrown at `BaNotificationService.php:660`), is not re-thrown and not shown. |
| **Consequence** | A real programming error (a TypeError, a broken query) is hidden behind a generic "The notification could not be retried." flash instead of surfacing as a logged 500, so the defect never reaches the log with a trace. |
| **Reproduce** | static only — the catch is a code path that needs a service failure to fire; there is no browser step. |
| **Fix approach** | D1/D2: catch only `\DomainException` and show its message; let any other throwable bubble to the central handler in `bootstrap/app.php`. How far to go is BNC-02's DECISION. |
| **Plan item** | BNC-02 in `02-fix-plan.md` §9 |

```php
        try {
            $service->retry($row);
        } catch (ValidationException|ModelNotFoundException|HttpExceptionInterface $e) {
            throw $e;
        } catch (Throwable $e) {
            $triggerMessage = BaTriggerError::message($e);
            if ($triggerMessage === null) {
                Log::error('BaNotificationController::retry failed', ['id' => $row->id, 'error' => $e->getMessage()]);
            }

            return $this->backToOutbox()->with('error', $triggerMessage ?? 'The notification could not be retried.');
        }
```

**Evidence**
```
$ grep -n "try {\|catch (" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php
40:        try {
42:        } catch (ValidationException|ModelNotFoundException|HttpExceptionInterface $e) {
44:        } catch (Throwable $e) {
```

#### BNC-03 · M · ERR-05 — the failure log records only the message, never the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error(…, ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php:47`; `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:726-729` |
| **Root cause** | Both call sites pass `['error' => $e->getMessage()]` to the logger. The exception class, file, line and stack trace are discarded. |
| **Consequence** | When a retry or a delivery fails in production the operator sees a one-line message (often a bare SQL fragment) and cannot find the failing code. |
| **Reproduce** | static only — the log line is a code path; no browser step. |
| **Fix approach** | Pass the exception object: `report($e);` in the controller, and `['exception' => $e]` in the service's `Log::warning`. |
| **Plan item** | BNC-03 in `02-fix-plan.md` §3 |

```php
                Log::error('BaNotificationController::retry failed', ['id' => $row->id, 'error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "getMessage()" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php:47:                Log::error('BaNotificationController::retry failed', ['id' => $row->id, 'error' => $e->getMessage()]);
Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:725:                $errors[] = $e->getMessage();
Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:728:                    'error' => $e->getMessage(),
```

(Line 725 only builds the stored `failure_reason` text, which is correct; line 728 is the logger and is the finding.)

### F2 — Transactions and audit

#### BNC-01 · H · TXN-01 — the outbox status write and the incident flag update are two separate commits

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (two models, a model + its audit row, a model + pivot) runs inside one `DB::transaction`* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:663-672` (`retry`), and the same pair at `:737-746` and `:754-763` (`attempt`), `:777-783` (`markFailed`), `:1010-1016` (`suppress`) |
| **Root cause** | Each method runs `$row->forceFill([...])->save()` (an UPDATE of `ba_notifications`) and then `$this->syncIncidentNotified($row)` (a separate UPDATE of `ba_incidents` when `entity_type = incident`) with no wrapping `DB::transaction`, so the two writes commit independently. |
| **Consequence** | If the `ba_incidents` update fails, the `ba_notifications` status is already committed — the outbox shows a reset row while the incident's `is_notified` flag is stale. |
| **Reproduce** | static only — the two-table write is a code path; the write survives only when the second statement fails, which no browser step can force. |
| **Fix approach** | Add one private `persistOutcome()` that wraps `forceFill + save + syncIncidentNotified` in a single `DB::transaction`, and call it from all four methods. |
| **Plan item** | BNC-01 in `02-fix-plan.md` §3 |

```php
        if ($notification->status !== BaNotification::STATUS_PENDING) {
            $notification->forceFill([
                'status' => BaNotification::STATUS_PENDING,
                'failure_reason' => null,
                'suppress_reason' => null,
                'updated_by' => BaActor::id(),
            ])->save();

            $this->syncIncidentNotified($notification);
        }
```

**Evidence**
```
$ grep -n "forceFill(\|syncIncidentNotified(\|->save()\|DB::transaction" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
664:            $notification->forceFill([
669:            ])->save();
671:            $this->syncIncidentNotified($notification);
737:            $row->forceFill([
745:            ])->save();
746:            $this->syncIncidentNotified($row);
754:        $row->forceFill([
760:        ])->save();
763:            $this->syncIncidentNotified($row);
777:        $row->forceFill([
782:        ])->save();
783:        $this->syncIncidentNotified($row);
787:    public function syncIncidentNotified(BaNotification $row): void
1010:        $row->forceFill([
1015:        ])->save();
1016:        $this->syncIncidentNotified($row);
```
No `DB::transaction` line appears — the four `save()` + `syncIncidentNotified()` pairs are not wrapped.

#### BNC-12 · M · TXN-06 — concurrent Retry clicks can revert a sent row and deliver twice

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H, lowered to M — requires two overlapping requests, see Rule reason) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php:36-38`; `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:657-675` |
| **Root cause** | The controller reads the status and the service re-uses that in-memory model. Two overlapping requests both read `failed`, both pass the guard, and both call `retry()`, which resets the row without a `lockForUpdate()` or a conditional UPDATE. |
| **Consequence** | The second request can overwrite the first request's `sent` status back to `pending` and re-dispatch, so a parent can receive the same alert twice. |
| **Reproduce** | static only — needs two near-simultaneous POSTs to the retry URL; no single browser step shows it. |
| **Fix approach** | Re-read the row `lockForUpdate()` inside a transaction and re-check its status before resetting; or perform the reset as a conditional UPDATE guarded on the expected status. |
| **Plan item** | BNC-12 in `02-fix-plan.md` §9 |

```php
        if (! in_array($row->status, [BaNotification::STATUS_FAILED, BaNotification::STATUS_SUPPRESSED], true)) {
            return $this->backToOutbox()->with('error', 'Only a failed or suppressed notification can be retried.');
        }
```

**Evidence**
```
$ sed -n '657,675p' Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
    public function retry(BaNotification $notification): void
    {
        if ($notification->status === BaNotification::STATUS_SENT) {
            throw new DomainException('This notification was already sent; it cannot be retried.');
        }

        if ($notification->status !== BaNotification::STATUS_PENDING) {
            $notification->forceFill([
                'status' => BaNotification::STATUS_PENDING,
                'failure_reason' => null,
                'suppress_reason' => null,
                'updated_by' => BaActor::id(),
            ])->save();

            $this->syncIncidentNotified($notification);
        }

        $this->dispatchPending($notification);
    }
```
No `lockForUpdate` or transaction: `grep -n "lockForUpdate" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php` → no output.

### F3 — Authorization

clean — `grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php` → `33: Gate::authorize('tenant.behavioural-assessment.notifications.retry');`, called before `findOrFail` (line 34). The exact permission is seeded (read-only query on test.localhost: `sys_permissions` id 4994, `tenant.behavioural-assessment.notifications.retry`), declared in `config/permissionslist.php:1426` as `'behavioural-assessment.notifications' => ['view', 'retry']`, and used identically in `_outbox.blade.php:26`. No FormRequest and no Policy is involved, so there is no duplicate or unreachable check.

### F4 — Validation and input

clean — the method takes no request body; its only input is the route id, resolved by `BaNotification::findOrFail()` (`grep -n "validated()\|request->all\|request(" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php` → no output). Nothing is written from unvalidated input.

### F5 — Routes

clean — one route, POST only (`RTE-01` safe), the method exists (`RTE-02`), the only public method is routed (`RTE-03`), and the full tenant + auth middleware group is applied (`RTE-05`). Note: unlike the sibling `behaviour-points/{entry}/reverse` route, this route has no `->whereNumber('notification')`; a non-numeric id becomes `(int) 0` and yields a normal 404, so this is recorded as an observation, not a finding.

### F6 — Controller shape

#### BNC-07 · M · CTL-02 — `attempt()` in the service is 87 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method length: over 80 lines → extract; over 150 lines is H* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:681-767`, method `attempt()` |
| **Root cause** | One method resolves contacts, loops the delivery, and then contains two near-identical outcome-writing branches, so it exceeds the 80-line threshold. |
| **Consequence** | A reader cannot hold the whole method in view; the two outcome branches drift apart over time. |
| **Reproduce** | static only — measured with `awk`. |
| **Fix approach** | Extract the outcome write into the same `persistOutcome()` helper BNC-01 introduces. |
| **Plan item** | none — resolved by BNC-01's extraction; see `02-fix-plan.md` §10 |

```php
    public function attempt(BaNotification $row): string
    {
```

**Evidence**
```
$ awk 'NR>=681 && NR<=767 {n++} END{print "attempt lines 681-767 = " n}' Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
attempt lines 681-767 = 87
```

CTL-03 checked, not present — `findOrFail()` at `BaNotificationController.php:34` deliberately runs **after** `Gate::authorize` (line 33). Route model binding would resolve the row before the method body, i.e. before the gate, which is exactly the AUTH-02 (H) problem; the explicit load is the correct pattern here, not a defect.

#### BNC-09 · M · CTL-01 — the notification service is a 1,065-line god service

| Field | Value |
|---|---|
| **Rule** | CTL-01 (M) — *over 1,000 lines → split by responsibility* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:58` (whole file, 1,065 lines, 14 public methods) |
| **Root cause** | One class both evaluates obligations (`evaluate*`, nine methods) and performs delivery (`attempt`, `suppress`, `syncIncidentNotified`, `resolveContacts`, config helpers). |
| **Consequence** | The file mixes two responsibilities (deciding *what to notify* and *how to deliver*), so any change to one risks the other and the delivery half cannot be reused. |
| **Reproduce** | static only. |
| **Fix approach** | Split into an obligation builder and a delivery worker — DEFERRED per D3, recorded as BNC-09's DECISION. |
| **Plan item** | BNC-09 in `02-fix-plan.md` §9 |

```php
class BaNotificationService
{
```

**Evidence**
```
$ wc -l Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
1065 Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
$ grep -cE 'public function ' Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
15
```
(15 includes the constructor, so 14 behaviour methods; the line count alone crosses the 1,000-line threshold.)

### F7 — Models

#### BNC-10 · L · CTL-10 — `scopePending()` is dead code

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M, lowered to L — a three-line unused scope, no runtime effect) — *no dead code: unused private methods, unused properties, commented-out blocks* |
| **Where** | `Modules/BehaviouralAssessment/app/Models/BaNotification.php:149-152`, method `scopePending()` |
| **Root cause** | The scope is declared but no caller in the module or its views uses `pending()` or `scopePending()`; the delivery path uses explicit `where('status', STATUS_PENDING)`. |
| **Consequence** | None at runtime; a maintainer may assume the scope is the standard way to read pending rows when it is not used anywhere. |
| **Reproduce** | static only. |
| **Fix approach** | Delete the unused scope (or start using it at the two `where('status', STATUS_PENDING)` sites, which is the larger change). |
| **Plan item** | BNC-10 in `02-fix-plan.md` §5 |

```php
    public function scopePending($query)
    {
        return $query->where('status', self::STATUS_PENDING);
    }
```

**Evidence**
```
$ grep -rn "scopePending\|->pending(" Modules/BehaviouralAssessment/app Modules/BehaviouralAssessment/resources 2>/dev/null | grep -v "BaNotification.php"
(no output)
```

### F8 — Services and jobs

#### BNC-05 · M · SVC-02 — the service resolves `BaAssessmentService` with `app()` mid-method

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection, not `app(Foo::class)` mid-method* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:288`, `:339`, `:384` |
| **Root cause** | `evaluateReviewPending`, `evaluateAssessmentDeadline` and `evaluateAssessmentOverdue` each call `app(BaAssessmentService::class)->configFor(...)`, although `BaAssessmentService` has no constructor (checked) so there is no circular dependency to avoid. |
| **Consequence** | The dependency is invisible to the type system and re-resolved on each call; a future constructor change to `BaAssessmentService` cannot be seen here. |
| **Reproduce** | static only. |
| **Fix approach** | Add a `private BaAssessmentService $assessments` constructor parameter and use `$this->assessments->configFor(...)`. |
| **Plan item** | BNC-05 in `02-fix-plan.md` §5 |

```php
        $config = app(BaAssessmentService::class)->configFor($assessment->period);
```

**Evidence**
```
$ grep -n "app(" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
288:        $config = app(BaAssessmentService::class)->configFor($assessment->period);
339:        $config = app(BaAssessmentService::class)->configFor($period);
384:        $config = app(BaAssessmentService::class)->configFor($period);
```

#### BNC-06 · M · SVC-04 — the retryable-status rule is written twice and the copies disagree

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *one implementation per business operation; copies that disagree are a bug source* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:657-667` (service) and `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php:36-38` (controller) |
| **Root cause** | The controller decides "only failed or suppressed can be retried" and blocks pending, while the service treats `sent` as an error and silently re-dispatches `pending`. From the only caller (the controller) the service's `pending` and `sent` branches can never run, so the two rules describe the same operation differently. |
| **Consequence** | A future caller of `$service->retry()` gets different behaviour from the Retry button, and the controller's message ("Only a failed or suppressed notification can be retried.") contradicts the service's own pending-row handling. |
| **Reproduce** | static only. |
| **Fix approach** | Keep the rule in one place: move the status decision into the service (throw `\DomainException` with the user-facing message) and let the controller only catch and show it — which is also the shape BNC-02's DECISION needs. |
| **Plan item** | BNC-06 in `02-fix-plan.md` §9 |

```php
    public function retry(BaNotification $notification): void
    {
        if ($notification->status === BaNotification::STATUS_SENT) {
            throw new DomainException('This notification was already sent; it cannot be retried.');
        }

        if ($notification->status !== BaNotification::STATUS_PENDING) {
```

**Evidence**
```
$ grep -n "STATUS_FAILED, BaNotification::STATUS_SUPPRESSED\|STATUS_SENT\|STATUS_PENDING" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php Modules/BehaviouralAssessment/app/Services/BaNotificationService.php | grep -e "rectry\|retry\| 36:\| 37:\| 38:\|657:\|659:\|663:" 
Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php:36:        if (! in_array($row->status, [BaNotification::STATUS_FAILED, BaNotification::STATUS_SUPPRESSED], true)) {
Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:659:        if ($notification->status === BaNotification::STATUS_SENT) {
Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:663:        if ($notification->status !== BaNotification::STATUS_PENDING) {
```

Job summary (clean): `DispatchNotificationJob` declares `public int $tries = 5`, `public int $timeout = 60` and a `failed()` handler, and stores `public int $notificationId` (ids, not models) — JOB-02/JOB-05 satisfied. Tenant context is handled by `config/tenancy.php`'s `QueueTenancyBootstrapper` (documented in `BaDispatch`), and `BaDispatch::job()` defaults to `dispatch_sync`, so no queue worker is required — JOB-01 satisfied.

### F9 — Queries and performance

#### BNC-04 · H · QRY-01 — one extra query per guardian inside the parent-contact map (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; no `Model::where/find` inside `foreach`/`map`; prefetch into a keyed collection* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:942`, inside `resolveContacts()` |
| **Root cause** | The guardian map runs `User::whereKey($g->user_id)->exists()` for every accepted guardian, so one SELECT is issued per guardian in a `->map()`. |
| **Consequence** | Delivering a parent notification that has several accepted guardians multiplies DB round-trips by the guardian count; on a `ba:sweep` batch this repeats for every row. |
| **Reproduce** | static only — the loop is a code path; a large guardian list is needed to feel it. |
| **Fix approach** | Collect `user_id`s, resolve them once with `User::whereIn('id', $ids)->pluck('id')` into a set, then test membership inside the map. |
| **Plan item** | BNC-04 in `02-fix-plan.md` §6 |

```php
                    ->filter(fn ($g) => $g !== null && $g->is_active !== false)
                    ->map(fn ($g) => [
                        'user_id' => $g->user_id && User::whereKey($g->user_id)->exists() ? (int) $g->user_id : null,
                        'email' => $g->email ?: null,
                        'name' => trim(($g->first_name ?? '').' '.($g->last_name ?? '')),
                    ])->values()->all();
```

**Evidence**
```
$ grep -n "User::whereKey" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php
942:                        'user_id' => $g->user_id && User::whereKey($g->user_id)->exists() ? (int) $g->user_id : null,
```

Checked, not present: `obligate()` creates rows one at a time in a loop (`grep -n "BaNotification::create"` → `:836`), which the scanner flags as QRY-07. This is deliberate and correct: each insert sits in its own `try { } catch (UniqueConstraintViolationException)` so a duplicate dedupe key is skipped without failing the whole batch. A bulk `insert()` would lose that per-row duplicate handling, so this is not a defect.

### F10 — Views

clean — this controller renders no view (`grep -oE "view\(['\"][^'\"]+" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php` → no output); every path returns a redirect. The Outbox partial that posts to the route is rendered by `BaDashboardController` and is out of scope (see §3 row 8).

### F11 — Security and tenancy

clean — no `env()` outside `config/` (`grep -n "env("` on the controller and service → no output); no personal data returned over JSON (no JSON response at all); no hard-coded id fallback (`?? 1` absent); no request bodies logged. `BaActor::$systemIds` is keyed by the current database name (`BaActor.php:31`), so its static cache is tenant-scoped.

### F12 — Style

#### BNC-11 · L · STY-07 — the success message says "queued" when the retry has already run

| Field | Value |
|---|---|
| **Rule** | STY-07 (L) — *user-facing messages are accurate* (deep-read #7: a message that lies) |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php:53` |
| **Root cause** | `BaDispatch::job()` defaults to `dispatch_sync` (no queue worker on the target host), so the delivery runs inline before the flash is built. The message "queued for another attempt" describes an asynchronous queue that is not used by default. |
| **Consequence** | The user sees a green "queued" confirmation although the row has already been re-attempted (and may have failed again), so the outbox can immediately show `failed` again right after a "success" message. |
| **Reproduce** | Click Retry on a failed outbox row at `GET /behavioural-assessment/incidents-page?tab=outbox`; the flash says queued while the row returns to `sent`/`failed` at once. (No data on test.localhost today.) |
| **Fix approach** | Say what actually happened, for example "Notification #N retried." so the message is true in both sync and async modes. |
| **Plan item** | BNC-11 in `02-fix-plan.md` §8 |

```php
        return $this->backToOutbox()->with('success', 'Notification #'.$row->id.' queued for another attempt.');
```

**Evidence**
```
$ grep -n "queued for another attempt" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php
53:        return $this->backToOutbox()->with('success', 'Notification #'.$row->id.' queued for another attempt.');
$ grep -n "dispatch_sync\|dispatch(" Modules/BehaviouralAssessment/app/Support/BaDispatch.php
25:            dispatch($job);
30:        dispatch_sync($job);
```

The rest of the style family is clean: all three files declare `strict_types=1`, imports are one-per-class and sorted, there is no commented-out code and no debug call (`grep -n "dd(\|dump(\|var_dump(\|print_r(\|ray(" on the controller and service → no output`).

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 wrong data | Q2 delete-before-store | Q3 duplicate impl | Q4 soft-del × unique | Q5 race | Q6 auth hole | Q7 lying message | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| controller `retry` | ok | ok | BNC-06 | ok (route row only) | BNC-12 | ok | BNC-11 | ok |
| service `retry` | BNC-12 (can revert a sent row) | ok | BNC-06 | ok | BNC-12 | ok | ok | BNC-06 |
| service `attempt` | ok | ok | ok | ok | ok (guarded by `refresh()` at 683) | ok | ok | ok |
| service `markFailed` | ok | ok | ok | ok | ok | ok | ok | ok |
| service `syncIncidentNotified` | ok | ok | ok | ok | ok | ok | ok | ok |
| service `suppress` | ok | ok | ok | ok | ok | ok | ok | ok |
| service `obligate` | ok | ok | ok | ok (`uq_guard` makes the unique index soft-delete-aware) | ok (DB unique index) | ok | ok | ok |
| service `evaluateIncident` | ok | ok | ok | ok | ok | ok | ok | ok |
| service `evaluateEscalation` | ok | ok | ok | ok | ok | ok | ok | ok |
| service `evaluateReviewPending` | ok | ok | ok | ok | ok | ok | ok | ok |
| service `evaluateAssessmentDeadline` | ok | ok | ok | ok | ok | ok | ok | ok |
| service `evaluateAssessmentOverdue` | ok | ok | ok | ok | ok | ok | ok | ok |
| service `evaluateInterventionAssigned` | ok | ok | ok | ok | ok | ok | ok | ok |
| service `evaluateInterventionOverdue` | ok | ok | ok | ok | ok | ok | ok | ok |
| service `evaluateDailyDigest` | ok | ok | ok | ok | ok | ok | ok | ok |
| service `evaluateExportReady` | ok | ok | ok | ok | ok | ok | ok | ok |

Notes on the columns: **Q4** is safe because `uq_guard` is a STORED generated column `ifnull(deleted_at, '1970-01-01')` and `uq_ba_notif_dedupe` is `(dedupe_key, channel, uq_guard)` — a soft-deleted row no longer blocks a new live one, and re-creating after a soft delete works. **Q8** for service `retry` is BNC-06: its `pending` and `sent` branches can never run from the only caller. **Q1/Q5** for `retry` is BNC-12.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Notification/Services/NotificationService` + `ntf_*` models | Called inside the delivery loop of `BaNotificationService::attempt()`; not audited here (another module). No defect observed from this side. | — | Notification module's own audit |
| `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | `message()` reads `$e->getMessage()` internally, but returns a user-safe `BA:` trigger string; not shown raw. Owned elsewhere. | — | `BaBehaviourPointController` report |
| `Modules/BehaviouralAssessment/app/Support/BaActor.php` | Falls back to the lowest `sys_users` id outside a request; intentional per its docblock. Owned elsewhere. | — | `BaCommentBankController` report |

## 8. Not covered, and why

- The Outbox blade partial (`_outbox.blade.php`) and `BaDashboardController::outboxData()` are not audited here — they belong to `BaDashboardController`, which has no report yet. Only the retry button's route target was checked.
- The Notification module (`Modules/Notification/**`) is a different module and is out of scope under §4.2.
- `DispatchNotificationJob::handle()` was read but not executed (D4 — no testing); its `release()` path only runs with async jobs enabled (`behaviouralassessment.async_jobs`), which is off by default.
- The race in BNC-12 was reasoned from the code; it was not reproduced with concurrent requests (that would be a test, D4).
- `ba_notifications` on test.localhost holds 0 rows, so no finding could be reproduced against live data.
