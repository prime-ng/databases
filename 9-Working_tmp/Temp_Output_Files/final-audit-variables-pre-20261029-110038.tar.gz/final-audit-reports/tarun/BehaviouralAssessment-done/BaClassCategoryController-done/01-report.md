# Final Audit — BehaviouralAssessment / BaClassCategoryController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php` (268 lines, 7 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/behavioural-assessment/setup?tab=class-mapping` (hub: store form, mapping list, criteria modal, status switch, delete) · `/behavioural-assessment/class-categories/{id}/edit` · `/behavioural-assessment/class-categories/{id}` (show) |
| Menu path | Behavioural Assessment → Setup → Class Mapping tab |
| Who uses it | Roles holding `tenant.behavioural-assessment.class-categories.*` — measured 4 permission rows seeded by exact name, 8 rows in `sys_role_has_permissions_jnt` in the test tenant (`test.localhost`) |
| What a user does here | The school staff maps a behaviour category (and a subset of the category's criteria) to a class. A class with **no** mapping rows gets every active category on its assessment sheet (BR-BA-009); a class with at least one mapping gets only the mapped ones. Here staff add a mapping, change a mapping's class/category/criteria, switch a mapping active/inactive, or delete it. |
| Tables written | `ba_class_category_jnt` (insert/update/soft-delete/toggle), `ba_class_criteria_jnt` (deselect = delete, select = insert, via `syncCriteria`), `sys_activity_logs` (via the `activityLog()` helper) |
| Tables read | `ba_class_category_jnt`, `ba_class_criteria_jnt`, `ba_categories`, `ba_criteria`, `sch_classes`, `sys_users` (via `BaActor`) |
| Live data | `ba_class_category_jnt` 63 live, 0 trashed · `ba_class_criteria_jnt` 252 · `ba_categories` 9 · `sch_classes` 15 (test tenant, measured 2026-10-12) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not yet production-ready**, but there is no blocker and no high finding: its
authorization, transactions, validation shape and eager loading are all correct. The single worst
finding is that all five mutating methods keep a try/catch that turns every unexpected write
failure into a redirect/flash while logging only `$e->getMessage()` — the stack trace is
discarded and the settled D1 "Laravel idiom" is violated five times. Effort to fix the plan is
**M — a focused afternoon**: 5 method rewrites (remove try/catch, move the response out of the
transaction, drop the trace-losing log), one bulk-insert change, one inline-validation move to a
FormRequest, and three decisions (duplicate authorization, route model binding, orphaned junction
rows on delete).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 6 | 2 | 3 | 8 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BACC-01, BACC-02 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | BACC-03 | F9 Queries/Perf | BACC-07 |
| F3 Authorization | BACC-04 | F10 Views | clean |
| F4 Validation | BACC-05 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | clean |
| F6 Controller shape | BACC-06 | F13 Deep read | BACC-08 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php` | controller | 268 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Models/BaClassCategoryJnt.php` | model | 70 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Models/BaClassCriterionJnt.php` | model | 45 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Http/Requests/BaClassCategoryRequest.php` | FormRequest | 84 | this report | ✅ |
| 5 | `Modules/BehaviouralAssessment/resources/views/class-category/show.blade.php` | view | 140 | this report | ✅ |
| 6 | `Modules/BehaviouralAssessment/resources/views/class-category/edit.blade.php` | view | 199 | this report | ✅ |
| 7 | `Modules/BehaviouralAssessment/routes/web.php` | routes (66-72) | 167 | this report (usage only) | ✅ |
| 8 | `Modules/BehaviouralAssessment/app/Models/BaCategory.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaCategoryController-done](../BaCategoryController-done/01-report.md) | ↗ linked |
| 9 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | — | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 10 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support | — | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |

Usage-only checks on linked classes (this report's business, per §5): `BaActor::id()` is called with
the auth guard live (all mutating methods run behind `web`+`auth`), so the `systemId()` fallback is
only a seeder/queue path. `BaTriggerError::message($e)` extracts a `BA: `-prefixed trigger text and
returns null for anything else — user-safe, never raw SQL. `BaCategory` relations used here
(`criteria`, `parent_id`, `polarity`) resolve against the live schema (verified in §6 F7).

Common classes referenced, not audited here (§4.2): `App\Models\BaseModel`, `Modules\SchoolSetup\Models\SchoolClass`,
`BaCriterion`, the `activityLog()` helper (`app/Helpers/activityLog.php`), `Gate`, `DB`,
breadcrumb/table components.

No pre-applied files.

## 4. Routes

```
POST    behavioural-assessment/class-categories                 behavioural-assessment.class-categories.store      BaClassCategoryController@store
GET|HEAD behavioural-assessment/class-categories/{id}            behavioural-assessment.class-categories.show       BaClassCategoryController@show
PUT     behavioural-assessment/class-categories/{id}            behavioural-assessment.class-categories.update     BaClassCategoryController@update
DELETE  behavioural-assessment/class-categories/{id}            behavioural-assessment.class-categories.destroy    BaClassCategoryController@destroy
PUT     behavioural-assessment/class-categories/{id}/criteria   behavioural-assessment.class-categories.criteria.update BaClassCategoryController@updateCriteria
GET|HEAD behavioural-assessment/class-categories/{id}/edit       behavioural-assessment.class-categories.edit       BaClassCategoryController@edit
POST    behavioural-assessment/class-categories/{id}/toggle-status behavioural-assessment.class-categories.toggleStatus BaClassCategoryController@toggleStatus
```

Unrouted public methods: none — all 7 public methods are routed (`grep -nE 'public function' …` → 27, 65, 78, 91, 135, 206, 242; every one appears in the route list above). No state change over GET. Tenant middleware is present via `Modules/BehaviouralAssessment/app/Providers/RouteServiceProvider.php:25-33` (`web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule`, `auth`, `verified`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `store` | 27 | POST `class-categories` | `tenant.behavioural-assessment.class-categories.create` | controller, line 33 | `'Stored'` | ba_class_category_jnt, ba_class_criteria_jnt, sys_activity_logs | BACC-01, 02, 03, 04 |
| `show` | 65 | GET `class-categories/{id}` | `tenant.behavioural-assessment.class-categories.view` | none (read) | none | — | BACC-06 |
| `edit` | 78 | GET `class-categories/{id}/edit` | `tenant.behavioural-assessment.class-categories.update` | none (read) | none | — | BACC-06 |
| `update` | 91 | PUT `class-categories/{id}` | `tenant.behavioural-assessment.class-categories.update` | controller, line 97 | `'Updated'` | ba_class_category_jnt, ba_class_criteria_jnt, sys_activity_logs | BACC-01, 02, 03, 04, 06 |
| `updateCriteria` | 135 | PUT `class-categories/{id}/criteria` | `tenant.behavioural-assessment.class-categories.update` | controller, line 158 | `'Updated'` | ba_class_criteria_jnt, sys_activity_logs | BACC-01, 02, 03, 05, 06 |
| `toggleStatus` | 206 | POST `class-categories/{id}/toggle-status` | `tenant.behavioural-assessment.class-categories.update` | controller, line 211 | `'Toggled'` | ba_class_category_jnt, sys_activity_logs | BACC-01, 02, 03, 06 |
| `destroy` | 242 | DELETE `class-categories/{id}` | `tenant.behavioural-assessment.class-categories.delete` | controller, line 247 | `'Trashed'` | ba_class_category_jnt, sys_activity_logs | BACC-01, 02, 03, 06, 08 |

Private helper `syncCriteria` (line 183) is called only from `store`, `update`, `updateCriteria` — all
three inside their `DB::transaction` closures — so every write it makes (delete + insert on
`ba_class_criteria_jnt`) is inside one transaction per request. The transaction lives in the
controller, not the helper (F2 / controller-alignment §6).

## 6. Findings

### F1 — Errors

#### BACC-01 · M · ERR-00/D1 — Five mutating methods carry a try/catch the settled Laravel idiom forbids

| Field | Value |
|---|---|
| **Rule** | ERR-00/D1 (M, raised from undecided) — *the final audit settled the Laravel idiom: no try/catch in controllers; `DB::transaction` rolls back and the central handler in `bootstrap/app.php` renders* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php` — `store` 32-62, `update` 96-129, `updateCriteria` 157-176, `toggleStatus` 210-239, `destroy` 246-266 |
| **Root cause** | Each mutating method wraps the whole transaction in `try { … } catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { … }`. The rethrow is correct, so today a missing record still 404s, but the blocks exist at all, and the generic catch turns every other failure into a redirect/flash instead of letting `bootstrap/app.php` (which reports and renders, `withExceptions()`) own it. |
| **Consequence** | Every unexpected write failure (QueryException, TypeError) is swallowed into a redirect with a generic flash, so the operator never sees a 500 and the central handler's reporting path never runs for these five methods. |
| **Reproduce** | Trigger any SQL error on a BA write (e.g. drop a column of `ba_class_category_jnt` then submit the store form): you get `back()` with a red flash, not Laravel's error page — the try/catch has intercepted it. |
| **Fix approach** | Remove the try/catch from all five methods. `DB::transaction()` rolls back and rethrows; `findOrFail()` inside the closure still yields a 404 because `ModelNotFoundException` is not caught anywhere. The toggle's JSON failure shape is preserved by the central renderer (it checks `$request->expectsJson()`, `bootstrap/app.php:117`). |
| **Plan item** | BACC-01 (store, update, updateCriteria → BACC-05 item, toggleStatus, destroy) in `02-fix-plan.md` §3 and §5 |

```php
// BaClassCategoryController.php:32-62 — CURRENT, store
        try {
            return DB::transaction(function () use ($validated) {
                $record = BaClassCategoryJnt::create([
                    'class_id' => $validated['class_id'],
                    'category_id' => $validated['category_id'],
                    'is_active' => true,
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                $this->syncCriteria($record, $validated['criterion_ids']);

                activityLog($record, 'Stored', [
                    'message' => 'BaClassCategory was stored.',
                    'criterion_ids' => array_values($validated['criterion_ids']),
                ]);

                return redirect()
                    ->route('behavioural-assessment.setup', ['tab' => 'class-mapping'])
                    ->with('success', 'Category mapped to class successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaClassCategoryController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "try {\|catch (" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php
32:        try {
54:        } catch (ModelNotFoundException $e) {
58:        } catch (\Throwable $e) {
96:        try {
123:        } catch (ModelNotFoundException $e) {
125:        } catch (\Throwable $e) {
157:        try {
170:        } catch (ModelNotFoundException $e) {
172:        } catch (\Throwable $e) {
210:        try {
226:        } catch (ModelNotFoundException $e) {
230:        } catch (\Throwable $e) {
246:        try {
258:        } catch (ModelNotFoundException $e) {
262:        } catch (\Throwable $e) {
```

#### BACC-02 · M · ERR-05 — Failure logs store only the message, discarding the exception trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e]`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php` lines 59, 126, 173, 231, 263 — the `catch (\Throwable)` of `store`, `update`, `updateCriteria`, `toggleStatus`, `destroy` |
| **Root cause** | The catch bodies call `Log::error('… failed', ['error' => $e->getMessage()])`. Storing only the message string drops the class, file, line and stack of the real failure; for a `QueryException` the message is also mostly SQLSTATE boilerplate. |
| **Consequence** | When a write fails, the log says *what* failed and a fragment of the SQL, but not *where* the code failed or the trace, so an operator cannot triage without reproducing. |
| **Reproduce** | Force any write error and read the log entry: it contains `['error' => 'SQLSTATE[42S02]…']` with no backtrace. |
| **Fix approach** | This log line disappears with BACC-01's try/catch removal; the central handler (`bootstrap/app.php` `withExceptions()` report closure) logs the full exception. No separate edit needed — the fix is the same five method rewrites. |
| **Plan item** | Same items as BACC-01 (§3 and §5) |

```php
// BaClassCategoryController.php:59 — CURRENT, one of five identical lines
            Log::error('BaClassCategoryController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php
59:            Log::error('BaClassCategoryController::store failed', ['error' => $e->getMessage()]);
126:            Log::error('BaClassCategoryController::update failed', ['error' => $e->getMessage()]);
173:            Log::error('BaClassCategoryController::updateCriteria failed', ['error' => $e->getMessage()]);
231:            Log::error('BaClassCategoryController::toggleStatus failed', ['error' => $e->getMessage()]);
263:            Log::error('BaClassCategoryController::destroy failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### BACC-03 · M · TXN-05 — The HTTP response is built inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()` / `response()` after it* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php` lines 49-51, 119-121, 166-168, 219-223, 253-255 — inside the `DB::transaction` closures of `store`, `update`, `updateCriteria`, `toggleStatus`, `destroy` |
| **Root cause** | Each closure `return`s a `redirect()->…` (or `response()->json()`) instead of returning data and building the HTTP response after the transaction commits. It works because `DB::transaction` forwards the closure's return value, but it couples HTTP construction to the DB closure, which is exactly what TXN-05 forbids. |
| **Consequence** | No user-visible bug today; the cost is structural — a reader cannot see that the redirect is created only after commit, and any future `DB::afterCommit()` work would fight the shape. |
| **Reproduce** | Static only — the closure's `return redirect()` is visible at the quoted lines; no behavioural repro exists. |
| **Fix approach** | In each method, have the closure return data (`$record`, `$mapping->is_active`, nothing) and build the redirect/JSON after the transaction. Combined with the BACC-01 rewrites. |
| **Plan item** | Same items as BACC-01 (§3 and §5) |

```php
// BaClassCategoryController.php:217-225 — CURRENT, toggleStatus
                activityLog($mapping, 'Toggled', ['message' => 'BaClassCategory was toggled.']);

                return response()->json([
                    'success' => true,
                    'is_active' => $mapping->is_active,
                    'message' => $mapping->is_active ? 'Mapping activated.' : 'Mapping deactivated.',
                ]);

            });
```

**Evidence**
```
$ grep -n "return redirect\|return response" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php
49:                return redirect()
119:                return redirect()
166:                return redirect()
219:                return response()->json([
235:            return response()->json([
253:                return redirect()
```

TXN-01/02/03/04/06 clean — `grep -n "DB::transaction"` → lines 33, 97, 158, 211, 247: every multi-table write (a model + its `ba_class_criteria_jnt` rows + the `sys_activity_logs` audit row) runs in ONE closure; `activityLog()` is after the write and inside the closure (lines 44, 114, 161, 217, 251); no mail/file/HTTP side effects inside; closure form used throughout; check-then-act (`store`'s uniqueness) is backed by the DB unique index `uq_ba_class_cat` (verified `SHOW INDEX`, §6 F7).

### F3 — Authorization

#### BACC-04 · L · AUTH-04 — store and update authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (FormRequest `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php` lines 29 and 93 (`Gate::authorize`); `Modules/BehaviouralAssessment/app/Http/Requests/BaClassCategoryRequest.php:15-21` (`authorize()` via `authorizeByCrudPermission`, which maps POST→create, PUT/PATCH→update) |
| **Root cause** | `store` and `update` inject `BaClassCategoryRequest`, whose `authorize()` checks `tenant.behavioural-assessment.class-categories.{create|update}`; the controllers then run the identical `Gate::authorize` with the same literal. One of the two is redundant; the middleware-independent FormRequest check already runs first. |
| **Consequence** | Double-checking the same gate is harmless today (same permission, same user), but the duplication is a maintenance trap: a future change to one check and not the other silently widens or narrows one path. |
| **Reproduce** | Static only — both checks are visible at the quoted lines. |
| **Fix approach** | Keep one check per concern. This is a module-wide pattern (258 FormRequests use `authorizeByCrudPermission`; every BA controller pair does this), so changing only this controller would make it inconsistent — see the decision in `02-fix-plan.md` §9. |
| **Plan item** | BACC-04 in `02-fix-plan.md` §9 (DECISION) |

```php
// BaClassCategoryController.php:27-30 — CURRENT, store
    public function store(BaClassCategoryRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.class-categories.create');
        $validated = $request->validated();
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php
29:        Gate::authorize('tenant.behavioural-assessment.class-categories.create');
67:        Gate::authorize('tenant.behavioural-assessment.class-categories.view');
80:        Gate::authorize('tenant.behavioural-assessment.class-categories.update');
93:        Gate::authorize('tenant.behavioural-assessment.class-categories.update');
137:        Gate::authorize('tenant.behavioural-assessment.class-categories.update');
208:        Gate::authorize('tenant.behavioural-assessment.class-categories.update');
244:        Gate::authorize('tenant.behavioural-assessment.class-categories.delete');
```

Permission names are otherwise correct: four-segment `scope.module.feature.action`, declared in `config/permissionslist.php:1411` (`'behavioural-assessment.class-categories' => $crud`), identical on the view (`show.blade.php:129` `@can`, `_class-mapping.blade.php` `@can`/`Gate::check`), and seeded by exact name in the tenant (`sys_permissions` 4 rows, 8 `sys_role_has_permissions_jnt` rows — evidence in §7 note). `toggleStatus` (POST) and `destroy` (DELETE) authorize with the single controller gate — clean.

### F4 — Validation and input

#### BACC-05 · M · VAL-02 — updateCriteria validates inline instead of in a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a FormRequest, not inline `$request->validate()` — except one-field AJAX toggles* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php:135-155`, method `updateCriteria` |
| **Root cause** | `updateCriteria` is a partial update (only `criterion_ids`), so it does not inject the full `BaClassCategoryRequest` (whose `rules()` demands `class_id`/`category_id`) and instead inlines the criteria rule array — which duplicates the `criterion_ids.*` exists rule already in `BaClassCategoryRequest::rules()` (lines 62-70). Two copies of one business rule that can drift. |
| **Consequence** | A change to "which criteria may be selected" must be made in two places; when they drift, the criteria modal and the full edit form accept different payloads. |
| **Reproduce** | Compare `BaClassCategoryRequest.php:62-70` with `BaClassCategoryController.php:141-155` — the same `Rule::exists('ba_criteria', 'id')->where(...)` is written twice. |
| **Fix approach** | Move the criteria rules into a dedicated FormRequest (`BaClassCategoryCriteriaRequest`) that resolves the mapping and validates `criterion_ids` against `$mapping->category_id`; `updateCriteria` then injects it and uses `$request->validated()`. |
| **Plan item** | BACC-05 in `02-fix-plan.md` §5 |

```php
// BaClassCategoryController.php:139-155 — CURRENT, updateCriteria
        $mapping = BaClassCategoryJnt::findOrFail($id);

        $validated = $request->validate([
            'criterion_ids' => ['required', 'array', 'min:1'],
            'criterion_ids.*' => [
                'integer',
                Rule::exists('ba_criteria', 'id')
                    ->where(fn ($query) => $query
                        ->where('category_id', $mapping->category_id)
                        ->where('is_active', true)
                        ->whereNull('deleted_at')),
            ],
        ], [
            'criterion_ids.required' => 'Select at least one criterion for this class.',
            'criterion_ids.min' => 'Select at least one criterion for this class.',
            'criterion_ids.*.exists' => 'A selected criterion does not belong to this category.',
        ]);
```

**Evidence**
```
$ grep -n "request->validate" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php
141:        $validated = $request->validate([
```

VAL-01/03/04/05/06/07 clean — `store`/`update` use `$request->validated()` and never `$request->all()`; all fields are typed; the uniqueness rule mirrors the live unique index `uq_ba_class_cat` including soft-delete semantics (it applies `whereNull('deleted_at')`, and the index's generated `uq_guard` column makes a soft-deleted re-map legal — verified in §6 F7); the criteria-exists rule cross-checks `category_id` (VAL-07 shape) and matches every referenced column (`ba_criteria.category_id`, `is_active`, `deleted_at` — verified `SHOW COLUMNS`).

### F5 — Routes

clean — `route:list` (uncached) shows all 7 routes pointing at existing methods (evidence in §4); every public method is routed; `toggleStatus`/`destroy`/`store`/`update`/`updateCriteria` are POST/PUT/DELETE (no state change over GET); route parameter `{id}` matches every controller's `int $id` argument (no unbound-model INSERT trap — §3.3.1 passed); tenant middleware is on the group (`RouteServiceProvider.php:25-33`).

### F6 — Controller shape

#### BACC-06 · M · CTL-03 — Six methods take `$id` + `findOrFail` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`), not `$id` + `findOrFail`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php` lines 65, 78, 91, 135, 206, 242 — `show`, `edit`, `update`, `updateCriteria`, `toggleStatus`, `destroy`; `findOrFail` calls at 73, 82, 98, 139, 212, 248 |
| **Root cause** | All six methods declare `int $id` and call `BaClassCategoryJnt::findOrFail($id)`; the routes name the parameter `{id}`, so Laravel never binds the model. The estate convention (e.g. `categories/{category}`, `rating-scales/{ratingScale}` in this same `web.php`) is implicit model binding. |
| **Consequence** | No wrong behaviour today (the 404 is preserved — in five methods by the D1 rethrow, in `updateCriteria`/`show`/`edit` because the find is outside any catch). The cost is boilerplate and a missed framework guarantee. |
| **Reproduce** | Static only — signatures and findOrFail calls at the quoted lines. |
| **Fix approach** | Adopt implicit binding: rename the six route parameters `{id}` → `{mapping}`, change the signatures to `BaClassCategoryJnt $mapping`, and delete the `findOrFail` calls; `BaClassCategoryRequest`'s uniqueness `ignore()` must switch from `$this->route('id')` to `$this->route('mapping')`. Touches the shared `routes/web.php` — see the DECISION in `02-fix-plan.md` §9. |
| **Plan item** | BACC-06 in `02-fix-plan.md` §9 (DECISION) |

```php
// BaClassCategoryController.php:78-82 — CURRENT, edit
    public function edit(int $id): View
    {
        Gate::authorize('tenant.behavioural-assessment.class-categories.update');

        $mapping = BaClassCategoryJnt::with(['schoolClass', 'category', 'selectedCriteria'])->findOrFail($id);
```

**Evidence**
```
$ grep -n "findOrFail" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php
73:        ])->findOrFail($id);
82:        $mapping = BaClassCategoryJnt::with(['schoolClass', 'category', 'selectedCriteria'])->findOrFail($id);
98:                $mapping = BaClassCategoryJnt::findOrFail($id);
139:        $mapping = BaClassCategoryJnt::findOrFail($id);
212:                $mapping = BaClassCategoryJnt::findOrFail($id);
248:                $mapping = BaClassCategoryJnt::findOrFail($id);
```

CTL-01/02/04/05/07/08/09/10 clean — 268 lines and 7 public methods (CTL-01 ok); the longest method is `updateCriteria` at ~43 lines (CTL-02 ok); every public method has a return type (`: RedirectResponse`/`: View`/`: JsonResponse`); `Request` is injected, never the `request()` helper (`grep -n "request()"` → no output); `compact()` is used with ≤3 variables; no `dd/dump/var_dump/ray` (`grep` → no output); no unused private methods. The five repeated catch blocks are the same root cause as BACC-01 and are not double-reported.

### F7 — Models

clean — both owned models were checked against the tenant live schema and their migrations:

- `BaClassCategoryJnt` (`database/migrations/tenant/2026_06_16_130618_create_ba_class_category_jnt_table.php`): `$fillable` declared (lines 23-29) with no generated column; `$casts` cover `is_active` boolean, `deleted_at` datetime, ids integer (lines 31-38); `SoftDeletes` present and the table has `deleted_at` (line 30) — consistent; the `uq_guard` stored-generated column (line 31) is correctly "never fillable, never written" per the model's own docblock; relationships are return-typed (`schoolClass`, `category`, `criteriaSelection`, `selectedCriteria`).
- The scanner's MDL-03 hit on `selectedCriteria` (belongsToMany over "soft-delete pivot") is a **false positive** — `ba_class_criteria_jnt` has NO `deleted_at` column (migration `2026_09_18_141500`, no soft deletes by design; confirmed live: `SHOW COLUMNS FROM ba_class_criteria_jnt` has no `deleted_at`), so `wherePivotNull('deleted_at')` is neither needed nor possible.
- `BaClassCriterionJnt`: `$fillable`, `$casts`, return-typed relations (`classCategory`, `criterion`) all correct; no SoftDeletes matches the no-`deleted_at` table.
- Both `$table` names exist in tenant migrations (MDL-07 ok).

**Evidence**
```
$ php -l Modules/BehaviouralAssessment/app/Models/BaClassCategoryJnt.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Models/BaClassCategoryJnt.php
$ php artisan tinker --execute '... tenancy()->initialize(Tenant::first()); foreach(DB::select("SHOW COLUMNS FROM ba_class_criteria_jnt") as $r){ echo $r->Field." "; }'
id is_active created_by updated_by created_at updated_at class_category_id criterion_id
$ php artisan tinker --execute '... foreach(DB::select("SHOW INDEX FROM ba_class_category_jnt") as $r){ echo $r->Key_name." "; }'
PRIMARY uq_ba_class_cat uq_ba_class_cat uq_ba_class_cat idx_ba_cc_class idx_ba_cc_class idx_ba_cc_cat fk_ba_cc_created
```

### F8 — Services and jobs

clean — no services, jobs, events or listeners are used by this controller. The only support classes are `BaActor` and `BaTriggerError`, both linked (§3); usage is read-only correct.

### F9 — Queries and performance

#### BACC-07 · M · QRY-07 — syncCriteria inserts selection rows one `create()` per item in a loop

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *bulk writes: `insert()`, `upsert()`, `whereIn(...)->update()` instead of `create()`/`update()` per row in a loop* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php:195-203`, private `syncCriteria` |
| **Root cause** | After deleting deselected rows, the method loops `$criterionIds->diff($existing)` and calls `BaClassCriterionJnt::create()` per new criterion id — one INSERT per row, each with its own query build and dispatched model events. |
| **Consequence** | For a typical category (a handful of criteria) the extra queries are small, but the loop scales with the category's criterion count and every insert pays per-row overhead; the collection work also duplicates `$criterionIds` handling already done once. |
| **Reproduce** | Static only — the loop is at the quoted lines; measures as N inserts for N new criteria. |
| **Fix approach** | Build one array of rows (with `created_at`/`updated_at`) and call `BaClassCriterionJnt::insert($rows)` once — the same shape the backfill migration uses. |
| **Plan item** | BACC-07 in `02-fix-plan.md` §6 |

```php
// BaClassCategoryController.php:195-203 — CURRENT, syncCriteria
        foreach ($criterionIds->diff($existing) as $criterionId) {
            BaClassCriterionJnt::create([
                'class_category_id' => $mapping->id,
                'criterion_id' => $criterionId,
                'is_active' => true,
                'created_by' => BaActor::id(),
                'updated_by' => BaActor::id(),
            ]);
        }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-ba-module.json \
    Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php
M  QRY-07   Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php:196  syncCriteria — BaClassCriterionJnt::create() inside a loop — bulk insert/upsert/whereIn->update
```

QRY-01/02/03/04/05/06/08/09/10/11/12/13/14/15 clean — no query inside a loop outside the single insert loop above; the only fully-loaded collections in `edit` are the two small master dropdowns (`SchoolClass` 15 rows, `BaCategory` 9 rows — QRY-15 threshold is a *big* table); `show`/`edit` eager-load every relation the views touch (`category.criteria`, `selectedCriteria`); no raw SQL anywhere (`Rule::exists` uses bindings); no N+1 (VIEW-02 proof in §6 F10).

### F10 — Views

clean — both in-scope blades compile (`php -l` on compiled output: rc=0 for both); no queries in Blade (the `@php` blocks in `edit.blade.php` only reshape already-loaded collections); relations used in `@foreach` are eager-loaded by `show` (line 69-73 loads `category.criteria` with the active-criteria closure) and `edit` (lines 82-86); no `{!! !!}` on user text (`grep '{!!'` → no output in either blade); `@can('tenant.behavioural-assessment.class-categories.update')` (show.blade:129) matches the config literal; the store form is a modal on the hub tab (owner: BaDashboardController) and the edit page has 3 selects + checkboxes (no create-form modal violation in scope); breadcrumbs use the sanctioned `:links="[]"` shape (breadcrumb-standard rule 8).

### F11 — Security and tenancy

clean — no `env()` outside config (`grep -rn "env(" `→ no output in the four in-scope PHP files); no `?? 1` / hard-coded id fallbacks (BaActor's fallback is the lowest real `sys_users` id, not a constant); no request bodies/tokens logged inside the controller (BACC-02 removes what little remains); no media (TEN-01 N/A); no cache keys (TEN-02 N/A); tenant data flows through tenancy-initialized connections only (TEN-03 N/A — the controller never touches central models).

### F12 — Style

clean — `declare(strict_types=1);` present at the top of all four in-scope PHP files; Pint passes (`vendor/bin/pint --test '…4 files…'` → `{"tool":"pint","result":"passed"}`); variables camelCase; comments English without emoji; no commented-out code; no copy-pasted docblocks.

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 wrong data | 2 delete-before-store | 3 duplicate impls | 4 soft-delete × unique | 5 race | 6 auth hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` (27) | ok — values from `validated()` only | ok — insert + sync inside one tx | ok — single `syncCriteria` | ok — DB unique `uq_ba_class_cat` matches FormRequest rule | ok — unique index backs check-then-act | ok — gate + FormRequest | ok — 'Category mapped to class successfully.' | ok — hub tab lists/store consumed by setup |
| `update` (91) | ok — category move clears criteria by design (comment 106-111) | ok — delete+insert inside one tx | ok | ok — `ignore($this->route('id'))` mirrors index | ok | ok | ok — 'Class mapping updated successfully.' | ok |
| `updateCriteria` (135) | ok — validates against `$mapping->category_id` | ok — inside tx | BACC-05 (criteria rule duplicated) | ok — exists rule excludes trashed | ok | ok | ok — 'Criteria updated for this mapping.' | ok |
| `toggleStatus` (206) | ok — flips only `is_active` | ok | ok | ok — trashed row 404s | ok (single-user scenario; the posted `is_active` is ignored by design — see §8) | ok | ok — 'Mapping activated/deactivated.' | ok |
| `destroy` (242) | ok — soft delete only | ok | ok | ok — soft-deleted row frees the unique guard for re-map (uq_guard) | ok | ok | ok — 'Mapping removed.' (soft delete is terminal: no restore route) | BACC-08 (selection rows become permanent orphans) |

#### BACC-08 · L · F13 #8 — Trashed mappings leave their criteria-selection rows orphaned forever

| Field | Value |
|---|---|
| **Rule** | F13 deep-read #8 (L, raised as informational) — *dead features / data nobody reads; here: data nobody will ever read again* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php:247-249` (`destroy`); `Modules/BehaviouralAssessment/app/Models/BaClassCriterionJnt.php` (no SoftDeletes, no `deleted_at`) |
| **Root cause** | `destroy` soft-deletes the mapping row (`$mapping->delete()`), but `ba_class_criteria_jnt` has no soft delete and nothing deletes the mapping's selection rows on trash. There is **no** restore route (`class-categories` has no `restore`, verified in `routes/web.php:66-72`) and **no** force-delete route, so those rows survive as long as the table lives. Every re-map of the same class+category creates a NEW mapping id and NEW selection rows; the old ones are never cleaned (the FK cascade only fires on a hard delete, which never happens). |
| **Consequence** | Permanent table bloat: each trashed mapping leaves up to ~10 dead rows in `ba_class_criteria_jnt` (252 live today). All current consumers (`BaAssessmentService::criteriaForClass` line 111, `BaFrameworkSnapshotService` line 342) query through the `SoftDeletes`-scoped `BaClassCategoryJnt`, so the rows are never read — bloat only, no wrong data. |
| **Reproduce** | Toggle a mapping into the trash, then re-map the same class+category: `ba_class_criteria_jnt` gains a fresh set of rows for the new mapping id while the old id's rows remain. |
| **Fix approach** | On `destroy`, hard-delete the mapping's selection rows inside the same transaction (`BaClassCriterionJnt::where('class_category_id', $mapping->id)->delete()`), matching the junction's own no-soft-delete design — or accept the bloat. Decision in `02-fix-plan.md` §9. |
| **Plan item** | BACC-08 in `02-fix-plan.md` §9 (DECISION) |

```php
// BaClassCategoryController.php:247-251 — CURRENT, destroy
            return DB::transaction(function () use ($id) {
                $mapping = BaClassCategoryJnt::findOrFail($id);
                $mapping->delete();

                activityLog($mapping, 'Trashed', ['message' => 'BaClassCategory was trashed.']);
```

**Evidence**
```
$ grep -n "restore\|force-delete" Modules/BehaviouralAssessment/routes/web.php | grep -c "class-categories"
0
$ php artisan tinker --execute '... tenancy()->initialize(Tenant::first()); echo DB::table("ba_class_category_jnt")->count()." live, ".DB::table("ba_class_category_jnt")->whereNotNull("deleted_at")->count()." trashed, ".DB::table("ba_class_criteria_jnt")->count()." selection rows\n";'
63 live, 0 trashed, 252 selection rows
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `resources/views/pages/partials/setup/_class-mapping.blade.php` (BaDashboardController) | The `x-backend.table.action` call passes `viewPermission`/`editPermission`/`deletePermission` (lines 196-198), but the component's declared props are `canView`/`canEdit`/`canDelete` — the passed names land in `$attributes` on the `<form>` and the booleans default to `true`. The surrounding `@canany` (lines 186-190) contains it today, so the View/Edit links are only shown to roles that hold at least one of view/update/delete. | CTL-05 / component props | BaDashboardController report |
| `resources/views/components/backend/partials/footer-scripts.blade.php` + `status-switch.blade.php` | The switch posts `is_active` (the desired state) but `toggleStatus()` ignores it and flips the stored value (`BaClassCategoryController.php:213`). Single-user behaviour is consistent (the DOM already shows the new state); a stale page or concurrent admin can toggle opposite to intent. | F13 #5 | Accepted design (endpoint contract is a flip); noted here, not a finding |
| `app/Support/BaTriggerError.php` usage | With BACC-01 the controller stops using `BaTriggerError`; the helper stays alive in services and `BaBehaviourPointController` (linked) — no dead code introduced by the fix. | — | — |
| Permissions seeding | `sys_permissions` in the test tenant holds all four `tenant.behavioural-assessment.class-categories.*` rows by exact name; 8 `sys_role_has_permissions_jnt` rows grant them. | AUTH | Verified, no action |

## 8. Not covered, and why

- **No browser session** was run: the setup-tab rendering, the criteria modal's PUT and the delete confirmation were verified statically and by blade-compile only (D4: no tests; no screen automation in this workflow).
- **BA trigger rejections** (SQLSTATE 45000, the `ba_*` triggers) were not simulated. After BACC-01 lands, a trigger rejection on a write will render through the central handler instead of the current `BaTriggerError` flash — accepted consequence of D1, but the exact rendered text is unverified.
- **Per-role refusal UX** was not exercised: the 4 permissions are seeded and 8 role rows exist, but which named role can reach which button was not simulated.
- **No writes were performed** (the audit is read-only): all transaction/rollback reasoning is from code reading, not from executing a failing transaction.
- **`toggleStatus`'s ignored `is_active` payload** is documented in §7 as accepted design; it was not treated as a finding.