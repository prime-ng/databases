# Fix Plan — BehaviouralAssessment / BaClassCategoryController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/BehaviouralAssessment/routes/web.php` | shared route file — only the BACC-06 DECISION (if chosen) names it, and only then |
| `resources/views/components/**`, `resources/views/layouts/**` | shared components / layouts |
| `Modules/BehaviouralAssessment/app/Models/BaCategory.php`, `app/Support/BaActor.php`, `app/Support/BaTriggerError.php` | owned by other reports (linked in §3 of 01-report.md) |
| `database/migrations/tenant/*` | never edit an existing migration |
| `config/permissionslist.php`, `app/Helpers/activityLog.php`, `bootstrap/app.php` | common glue; permission keys already exist |
| `Modules/BehaviouralAssessment/resources/views/pages/partials/setup/_class-mapping.blade.php` | BaDashboardController's blade (see 01-report.md §7) |

## 1. Blockers reachable today

None — this audit has no B-severity findings (01-report.md §2).

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

These five items remove the try/catch (BACC-01), the `Log::error(getMessage())` lines (BACC-02) and
the response-inside-transaction shape (BACC-03) in one coherent rewrite per method. The
`updateCriteria` method is rewritten by item **BACC-05** in §5 (its rules move to a FormRequest at
the same time), so this section does not repeat it.

- [ ] **BACC-01** · M · ERR-00/D1 · `BaClassCategoryController.php:27-63` — rewrite `store` without try/catch, without `Log::error`, response after the transaction. (This item also fixes **BACC-02**/ERR-05 and **BACC-03**/TXN-05 for `store`.)
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php`
  - **Before** — imports (`BaClassCategoryController.php:7,14,22`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    ```
    ```php
    use Illuminate\Support\Facades\Log;
    ```
    ```php
    use Modules\BehaviouralAssessment\Support\BaTriggerError;
    ```
  - **After** — replace those three lines with nothing (delete the lines). Keep every other import.
  - **Before** — method (`BaClassCategoryController.php:27-63`):
    ```php
        public function store(BaClassCategoryRequest $request): RedirectResponse
        {
            Gate::authorize('tenant.behavioural-assessment.class-categories.create');
            $validated = $request->validated();

            try {
                return DB::transaction(function () use ($validated) {
                    $record = BaClassCategoryJnt::create([
                        'class_id' => $validated['class_id'],
                        'category_id' => $validated['category_id'],
                        'is_active' => true,
                        'created_by' => BaActor::id(),
                        'updated_by' => BaActor::id(),
                    ]);

                    $this->syncCriteria($record, $validated['criterion_ids']);

                    activityLog($record, 'Stored', [
                        'message' => 'BaClassCategory was stored.',
                        'criterion_ids' => array_values($validated['criterion_ids']),
                    ]);

                    return redirect()
                        ->route('behavioural-assessment.setup', ['tab' => 'class-mapping'])
                        ->with('success', 'Category mapped to class successfully.');

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('BaClassCategoryController::store failed', ['error' => $e->getMessage()]);

                return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
            }
        }
    ```
  - **After:**
    ```php
        public function store(BaClassCategoryRequest $request): RedirectResponse
        {
            Gate::authorize('tenant.behavioural-assessment.class-categories.create');
            $validated = $request->validated();

            DB::transaction(function () use ($validated) {
                $record = BaClassCategoryJnt::create([
                    'class_id' => $validated['class_id'],
                    'category_id' => $validated['category_id'],
                    'is_active' => true,
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                $this->syncCriteria($record, $validated['criterion_ids']);

                activityLog($record, 'Stored', [
                    'message' => 'BaClassCategory was stored.',
                    'criterion_ids' => array_values($validated['criterion_ids']),
                ]);
            });

            return redirect()
                ->route('behavioural-assessment.setup', ['tab' => 'class-mapping'])
                ->with('success', 'Category mapped to class successfully.');
        }
    ```
  - **Verify:** `grep -n "try {\|Log::error\|ModelNotFoundException" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BACC-01** · M · ERR-00/D1 · `BaClassCategoryController.php:91-130` — rewrite `update` without try/catch, without `Log::error`, response after the transaction. (This item also fixes **BACC-02**/ERR-05 and **BACC-03**/TXN-05 for `update`.)
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php`
  - **Before** (`BaClassCategoryController.php:91-130`):
    ```php
        public function update(BaClassCategoryRequest $request, int $id): RedirectResponse
        {
            Gate::authorize('tenant.behavioural-assessment.class-categories.update');
            $validated = $request->validated();

            try {
                return DB::transaction(function () use ($validated, $id) {
                    $mapping = BaClassCategoryJnt::findOrFail($id);

                    $mapping->update([
                        'class_id' => $validated['class_id'],
                        'category_id' => $validated['category_id'],
                        'updated_by' => BaActor::id(),
                    ]);

                    /*
                     * The selection belongs to the category, so a mapping moved to a
                     * different category cannot keep the old category's criteria —
                     * syncCriteria deletes whatever is no longer in the list, and the
                     * request has already checked every id against the new category.
                     */
                    $this->syncCriteria($mapping, $validated['criterion_ids']);

                    activityLog($mapping, 'Updated', [
                        'message' => 'BaClassCategory was updated.',
                        'criterion_ids' => array_values($validated['criterion_ids']),
                    ]);

                    return redirect()
                        ->route('behavioural-assessment.setup', ['tab' => 'class-mapping'])
                        ->with('success', 'Class mapping updated successfully.');
                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('BaClassCategoryController::update failed', ['error' => $e->getMessage()]);

                return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
            }
        }
    ```
  - **After:**
    ```php
        public function update(BaClassCategoryRequest $request, int $id): RedirectResponse
        {
            Gate::authorize('tenant.behavioural-assessment.class-categories.update');
            $validated = $request->validated();

            DB::transaction(function () use ($validated, $id) {
                $mapping = BaClassCategoryJnt::findOrFail($id);

                $mapping->update([
                    'class_id' => $validated['class_id'],
                    'category_id' => $validated['category_id'],
                    'updated_by' => BaActor::id(),
                ]);

                /*
                 * The selection belongs to the category, so a mapping moved to a
                 * different category cannot keep the old category's criteria —
                 * syncCriteria deletes whatever is no longer in the list, and the
                 * request has already checked every id against the new category.
                 */
                $this->syncCriteria($mapping, $validated['criterion_ids']);

                activityLog($mapping, 'Updated', [
                    'message' => 'BaClassCategory was updated.',
                    'criterion_ids' => array_values($validated['criterion_ids']),
                ]);
            });

            return redirect()
                ->route('behavioural-assessment.setup', ['tab' => 'class-mapping'])
                ->with('success', 'Class mapping updated successfully.');
        }
    ```
  - **Verify:** `grep -n "try {\|Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BACC-01** · M · ERR-00/D1 · `BaClassCategoryController.php:206-240` — rewrite `toggleStatus` without try/catch, without `Log::error`, JSON response built after the transaction returns the new state. (This item also fixes **BACC-02**/ERR-05 and **BACC-03**/TXN-05 for `toggleStatus`.)
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php`
  - **Before** (`BaClassCategoryController.php:206-240`):
    ```php
        public function toggleStatus(int $id): JsonResponse
        {
            Gate::authorize('tenant.behavioural-assessment.class-categories.update');

            try {
                return DB::transaction(function () use ($id) {
                    $mapping = BaClassCategoryJnt::findOrFail($id);
                    $mapping->is_active = ! $mapping->is_active;
                    $mapping->updated_by = BaActor::id();
                    $mapping->save();

                    activityLog($mapping, 'Toggled', ['message' => 'BaClassCategory was toggled.']);

                    return response()->json([
                        'success' => true,
                        'is_active' => $mapping->is_active,
                        'message' => $mapping->is_active ? 'Mapping activated.' : 'Mapping deactivated.',
                    ]);

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('BaClassCategoryController::toggleStatus failed', ['error' => $e->getMessage()]);

                // Declared `: JsonResponse` — a redirect here was a TypeError, and the fetch() caller
                // would have followed it instead of seeing the failure.
                return response()->json([
                    'success' => false,
                    'message' => 'The operation could not be completed.',
                ], 500);
            }
        }
    ```
  - **After:**
    ```php
        public function toggleStatus(int $id): JsonResponse
        {
            Gate::authorize('tenant.behavioural-assessment.class-categories.update');

            $isActive = DB::transaction(function () use ($id) {
                $mapping = BaClassCategoryJnt::findOrFail($id);
                $mapping->is_active = ! $mapping->is_active;
                $mapping->updated_by = BaActor::id();
                $mapping->save();

                activityLog($mapping, 'Toggled', ['message' => 'BaClassCategory was toggled.']);

                return $mapping->is_active;
            });

            return response()->json([
                'success' => true,
                'is_active' => $isActive,
                'message' => $isActive ? 'Mapping activated.' : 'Mapping deactivated.',
            ]);
        }
    ```
  - **Verify:** `grep -n "try {\|Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php`
  - **Expect:** no output. JSON failure responses now come from the central handler (`bootstrap/app.php` renders JSON for `expectsJson()` callers — 01-report.md §1).
  - **Effort:** S

- [ ] **BACC-01** · M · ERR-00/D1 · `BaClassCategoryController.php:242-267` — rewrite `destroy` without try/catch, without `Log::error`, response after the transaction. (This item also fixes **BACC-02**/ERR-05 and **BACC-03**/TXN-05 for `destroy`.)
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php`
  - **Before** (`BaClassCategoryController.php:242-267`):
    ```php
        public function destroy(int $id): RedirectResponse
        {
            Gate::authorize('tenant.behavioural-assessment.class-categories.delete');

            try {
                return DB::transaction(function () use ($id) {
                    $mapping = BaClassCategoryJnt::findOrFail($id);
                    $mapping->delete();

                    activityLog($mapping, 'Trashed', ['message' => 'BaClassCategory was trashed.']);

                    return redirect()
                        ->route('behavioural-assessment.setup', ['tab' => 'class-mapping'])
                        ->with('success', 'Mapping removed.');

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('BaClassCategoryController::destroy failed', ['error' => $e->getMessage()]);

                return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
            }
        }
    ```
  - **After:**
    ```php
        public function destroy(int $id): RedirectResponse
        {
            Gate::authorize('tenant.behavioural-assessment.class-categories.delete');

            DB::transaction(function () use ($id) {
                $mapping = BaClassCategoryJnt::findOrFail($id);
                $mapping->delete();

                activityLog($mapping, 'Trashed', ['message' => 'BaClassCategory was trashed.']);
            });

            return redirect()
                ->route('behavioural-assessment.setup', ['tab' => 'class-mapping'])
                ->with('success', 'Mapping removed.');
        }
    ```
  - **Verify:** `grep -n "try {\|Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

See the BACC-04 DECISION in §9 — the duplicate authorization in `store`/`update` is a module-wide
pattern (258 FormRequests use `authorizeByCrudPermission`), so a change here is a decision, not a
mechanical fix.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **BACC-05** · M · VAL-02 · `BaClassCategoryController.php:135-177` — move the criteria validation into a dedicated FormRequest; `updateCriteria` uses `validated()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php` + NEW `Modules/BehaviouralAssessment/app/Http/Requests/BaClassCategoryCriteriaRequest.php`
  - **Before** — imports (`BaClassCategoryController.php:10,15`):
    ```php
    use Illuminate\Http\Request;
    ```
    ```php
    use Illuminate\Validation\Rule;
    ```
  - **After:** — delete those two lines; add one import:
    ```php
    use Modules\BehaviouralAssessment\Http\Requests\BaClassCategoryCriteriaRequest;
    ```
  - **Before** — method (`BaClassCategoryController.php:132-177`):
    ```php
        /**
         * Replace the criteria a class is assessed on for one mapping.
         */
        public function updateCriteria(Request $request, int $id): RedirectResponse
        {
            Gate::authorize('tenant.behavioural-assessment.class-categories.update');

            $mapping = BaClassCategoryJnt::findOrFail($id);

            $validated = $request->validate([
                'criterion_ids' => ['required', 'array', 'min:1'],
                'criterion_ids.*' => [
                    'integer',
                    Rule::exists('ba_criteria', 'id')
                        ->where(fn ($query) => $query
                            ->where('category_id', $mapping->category_id)
                            ->where('is_active', true)
                            ->whereNull('deleted_at')),
                ],
            ], [
                'criterion_ids.required' => 'Select at least one criterion for this class.',
                'criterion_ids.min' => 'Select at least one criterion for this class.',
                'criterion_ids.*.exists' => 'A selected criterion does not belong to this category.',
            ]);

            try {
                return DB::transaction(function () use ($mapping, $validated) {
                    $this->syncCriteria($mapping, $validated['criterion_ids']);

                    activityLog($mapping, 'Updated', [
                        'message' => 'Criteria for this class-category mapping were updated.',
                        'criterion_ids' => array_values($validated['criterion_ids']),
                    ]);

                    return redirect()
                        ->route('behavioural-assessment.setup', ['tab' => 'class-mapping'])
                        ->with('success', 'Criteria updated for this mapping.');
                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('BaClassCategoryController::updateCriteria failed', ['error' => $e->getMessage()]);

                return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
            }
        }
    ```
  - **After:** — the new FormRequest file `Modules/BehaviouralAssessment/app/Http/Requests/BaClassCategoryCriteriaRequest.php`:
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\BehaviouralAssessment\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Validation\Rule;
    use Modules\BehaviouralAssessment\Models\BaClassCategoryJnt;

    class BaClassCategoryCriteriaRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return Gate::allows('tenant.behavioural-assessment.class-categories.update');
        }

        public function rules(): array
        {
            $mapping = BaClassCategoryJnt::findOrFail((int) $this->route('id'));

            return [
                'criterion_ids' => ['required', 'array', 'min:1'],
                'criterion_ids.*' => [
                    'integer',
                    Rule::exists('ba_criteria', 'id')
                        ->where(fn ($query) => $query
                            ->where('category_id', $mapping->category_id)
                            ->where('is_active', true)
                            ->whereNull('deleted_at')),
                ],
            ];
        }

        public function messages(): array
        {
            return [
                'criterion_ids.required' => 'Select at least one criterion for this class.',
                'criterion_ids.min' => 'Select at least one criterion for this class.',
                'criterion_ids.*.exists' => 'A selected criterion does not belong to this category.',
            ];
        }
    }
    ```
  - **After** — the method (`BaClassCategoryController.php:132-168`):
    ```php
        /**
         * Replace the criteria a class is assessed on for one mapping.
         */
        public function updateCriteria(BaClassCategoryCriteriaRequest $request, int $id): RedirectResponse
        {
            $mapping = BaClassCategoryJnt::findOrFail($id);

            $validated = $request->validated();

            DB::transaction(function () use ($mapping, $validated) {
                $this->syncCriteria($mapping, $validated['criterion_ids']);

                activityLog($mapping, 'Updated', [
                    'message' => 'Criteria for this class-category mapping were updated.',
                    'criterion_ids' => array_values($validated['criterion_ids']),
                ]);
            });

            return redirect()
                ->route('behavioural-assessment.setup', ['tab' => 'class-mapping'])
                ->with('success', 'Criteria updated for this mapping.');
        }
    ```
  - **Verify:** `php -l Modules/BehaviouralAssessment/app/Http/Requests/BaClassCategoryCriteriaRequest.php && grep -n "request->validate" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php`
  - **Expect:** `No syntax errors detected …` and no grep output (the only `$request->validate` call is gone).
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **BACC-07** · M · QRY-07 · `BaClassCategoryController.php:183-204` — bulk-insert the new criteria selection rows instead of one `create()` per row.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php`
  - **Before** (`BaClassCategoryController.php:183-204`):
    ```php
        private function syncCriteria(BaClassCategoryJnt $mapping, array $criterionIds): void
        {
            $criterionIds = collect($criterionIds)->map(fn ($id) => (int) $id)->unique();

            $existing = BaClassCriterionJnt::where('class_category_id', $mapping->id)
                ->pluck('criterion_id')
                ->map(fn ($id) => (int) $id);

            BaClassCriterionJnt::where('class_category_id', $mapping->id)
                ->whereNotIn('criterion_id', $criterionIds)
                ->delete();

            foreach ($criterionIds->diff($existing) as $criterionId) {
                BaClassCriterionJnt::create([
                    'class_category_id' => $mapping->id,
                    'criterion_id' => $criterionId,
                    'is_active' => true,
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);
            }
        }
    ```
  - **After:**
    ```php
        private function syncCriteria(BaClassCategoryJnt $mapping, array $criterionIds): void
        {
            $criterionIds = collect($criterionIds)->map(fn ($id) => (int) $id)->unique();

            $existing = BaClassCriterionJnt::where('class_category_id', $mapping->id)
                ->pluck('criterion_id')
                ->map(fn ($id) => (int) $id);

            BaClassCriterionJnt::where('class_category_id', $mapping->id)
                ->whereNotIn('criterion_id', $criterionIds)
                ->delete();

            $now = now();
            $rows = $criterionIds->diff($existing)->map(fn ($criterionId) => [
                'class_category_id' => $mapping->id,
                'criterion_id' => $criterionId,
                'is_active' => true,
                'created_by' => BaActor::id(),
                'updated_by' => BaActor::id(),
                'created_at' => $now,
                'updated_at' => $now,
            ])->all();

            if ($rows !== []) {
                BaClassCriterionJnt::insert($rows);
            }
        }
    ```
  - **Verify:** `grep -n "BaClassCriterionJnt::create" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassCategoryController.php`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

None — F10 is clean (01-report.md §6 F10).

## 8. Style (F12) — one item per file

None — the four in-scope PHP files are Pint-clean and carry `declare(strict_types=1)` (01-report.md §6 F12). Run `vendor/bin/pint <touched files> --format agent` on the files each §3/§5/§6 item touches, as the fixer's standing rule.

## 9. Deferred / decisions

- [ ] **BACC-04** · L · DECISION · AUTH-04 — keep or remove the double authorization on `store`/`update`?
  - **Why it is a decision:** both checks work; which one dies is a module-wide convention question, not a mechanical fix. 258 FormRequests across the estate use `authorizeByCrudPermission` and BA controllers pair it with `Gate::authorize` everywhere.
  - (a) ⭐ **Keep both, record as accepted.** Same permission, same user, no behavioural delta; changing only this controller would make it inconsistent with the rest of the module. Nothing to edit.
  - (b) Drop the FormRequest `authorize()` (`BaClassCategoryRequest.php:15-21` → `return true;`) and keep the controller `Gate::authorize`. Fewer checks, but diverges from the estate trait pattern and removes the "one step earlier" validation gate.
  - (c) Drop the controller `Gate::authorize` in `store`/`update` and rely on the FormRequest. Requires also removing `use Illuminate\Support\Facades\Gate;` only if no other method uses it — it does (other methods), so just the two lines.
  - ➜ Choice: ____

- [ ] **BACC-06** · M · DECISION · CTL-03 — adopt implicit route model binding for class-categories?
  - **Why it is a decision:** it renames six route parameters `{id}` → `{mapping}` in the shared `routes/web.php` (⚠ SHARED, explicit tick only) and changes six method signatures plus a FormRequest `route('id')` read. It must be applied AFTER the §3/§5 rewrites so the Before blocks there remain valid. The URL shapes and route names do not change.
  - (a) ⭐ **Adopt binding.** In `routes/web.php:67-72` rename `{id}` → `{mapping}` on the six routes. Change the six signatures to `BaClassCategoryJnt $mapping` (`show`, `edit`, `update`, `updateCriteria`, `toggleStatus`, `destroy`) and delete the six `findOrFail` calls; in `BaClassCategoryRequest.php:47` change `->ignore($this->route('id'))` to `->ignore($this->route('mapping'))`; in the new `BaClassCategoryCriteriaRequest` change `$this->route('id')` to `$this->route('mapping')`. Links built with `route('…', $id)` keep working (scalar route keys bind by primary key).
  - (b) Keep `int $id` + `findOrFail` (404s are already correct — the D1 rethrow covers five methods, and `updateCriteria`/`show`/`edit` find outside any catch). Record as accepted; revisit with the split pass (D3).
  - ➜ Choice: ____

- [ ] **BACC-08** · L · DECISION · F13 #8 — clean up a trashed mapping's criteria-selection rows?
  - **Why it is a decision:** deleting rows on `destroy` is a behaviour choice (the rows are currently never read again — every consumer queries through the `SoftDeletes`-scoped parent — but they are also never deleted, so the table grows with each trash+re-map cycle; 252 rows today).
  - (a) ⭐ **Hard-delete the junction rows on trash.** In `destroy`, inside the transaction, after `$mapping->delete();` add exactly: `BaClassCriterionJnt::where('class_category_id', $mapping->id)->delete();` (the junction has no soft delete by design — 01-report.md §6 F7). Apply after the §3 `destroy` rewrite item.
  - (b) Leave as-is — accepted table bloat; document as known.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BACC-02 | Not a separate edit — the five `Log::error('… failed', ['error' => $e->getMessage()])` lines are inside the try/catch blocks that the §3 items (BACC-01 · BACC-02 · BACC-03, one per method) remove; the central handler takes over logging. |
| BACC-03 | Not a separate edit — the response-inside-transaction shape is rewritten by the same five §3 items (BACC-01 · BACC-02 · BACC-03) that move the redirect/JSON out of the closure. |