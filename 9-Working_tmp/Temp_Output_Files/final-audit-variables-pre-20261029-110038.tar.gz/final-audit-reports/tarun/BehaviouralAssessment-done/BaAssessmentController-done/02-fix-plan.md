# Fix Plan — BehaviouralAssessment / BaAssessmentController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | shared by all modules |
| `app/Traits/AuthorizesTenantFeature.php` | common app glue |
| `resources/views/components/backend/**` | shared components; `action-trashed` already adapts to the route verb, so BASS-07 needs no component change |
| `database/migrations/tenant/**` | never edit an existing migration |
| `Modules/BehaviouralAssessment/routes/web.php` | ⚠ SHARED — named by BASS-07 and BASS-08 only; change lines 99-113 and nothing else |
| `Modules/BehaviouralAssessment/app/Models/BaAssessmentStatusHistory.php` | usage-audited only, not registered; no item touches it |
| `Modules/BehaviouralAssessment/app/Models/BaAssessmentPeriod.php`, `BaAssessmentRating.php`, `BaCommentBank.php` | owned by other reports — not edited here |
| `Modules/BehaviouralAssessment/app/Support/BaDispatch.php`, `BaTriggerError.php`, `BaActor.php` | owned by other reports — not edited here |

## 1. Blockers reachable today

- [ ] **BASS-07** · H · RTE-01 · `Modules/BehaviouralAssessment/routes/web.php:102` — change the restore route from GET to POST so it can no longer change state without a CSRF token. ⚠ SHARED
  - **Touches:** `Modules/BehaviouralAssessment/routes/web.php`
  - **Before** (`web.php:102`):
    ```php
    Route::get('assessments/{id}/restore', [BaAssessmentController::class, 'restore'])->name('assessments.restore');
    ```
  - **After:**
    ```php
    Route::post('assessments/{id}/restore', [BaAssessmentController::class, 'restore'])->name('assessments.restore');
    ```
  - **Verify:** `grep -n "assessments/{id}/restore" Modules/BehaviouralAssessment/routes/web.php`
  - **Expect:** the line begins with `Route::post(`, not `Route::get(`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

_None standing alone; the sequencing notes are inline in §3._

## 3. Errors & transactions (F1/F2)

- [ ] **BASS-01** · M · DECISION · ERR-00 (D1) — keep or remove the controller `try/catch (\Throwable)` on the ten write paths.
  - **Why it is a decision:** D1 settles the Laravel idiom (no controller try/catch); D2 lists the only allowed catches, and mapping a DB trigger rejection is not among them. The module's other reports (BAI-03) treat this as a documented module exception.
  - (a) ⭐ Keep as the module's documented ERR-01 exception: keep `failure()` and the `restore`/`forceDelete` inline catches, add a comment on each catch naming ERR-01 and the date (2026-10-12), and route `restore()`/`forceDelete()` through `failure()` too so there is one funnel. Controller file only.
  - (b) Move the BA-trigger mapping into a custom exception rendered by `bootstrap/app.php` and delete all ten controller catches (the pure D1 shape). Touches `bootstrap/app.php` (shared) plus the controller.
  - (c) Leave as is, record as accepted.
  - ➜ Choice: ____

- [ ] **BASS-02** · M · ERR-05 · `BaAssessmentController.php:215,245,581,609` and `ComputeStudentScoresJob.php:45` — log the exception object, not just the message. Touches two files; the first Before block is the controller.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`, `Modules/BehaviouralAssessment/app/Jobs/ComputeStudentScoresJob.php`
  - **Before** (`restore` catch, `BaAssessmentController.php:214-218`):
    ```php
        } catch (Throwable $e) {
            Log::error('BaAssessmentController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    ```
  - **After:**
    ```php
        } catch (Throwable $e) {
            Log::error('BaAssessmentController::restore failed', ['error' => $e->getMessage(), 'exception' => $e]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    ```
  - **Before** (`forceDelete` catch, `BaAssessmentController.php:244-248`):
    ```php
        } catch (Throwable $e) {
            Log::error('BaAssessmentController::forceDelete failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    ```
  - **After:**
    ```php
        } catch (Throwable $e) {
            Log::error('BaAssessmentController::forceDelete failed', ['error' => $e->getMessage(), 'exception' => $e]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    ```
  - **Before** (`recomputeScores` log, `BaAssessmentController.php:581-586`):
    ```php
            Log::error('BaAssessmentController: score recompute failed', [
                'assessment_id' => $item->id,
                'period_id' => $item->period_id,
                'error' => $e->getMessage(),
            ]);
    ```
  - **After:**
    ```php
            Log::error('BaAssessmentController: score recompute failed', [
                'assessment_id' => $item->id,
                'period_id' => $item->period_id,
                'error' => $e->getMessage(),
                'exception' => $e,
            ]);
    ```
  - **Before** (`failure()` log, `BaAssessmentController.php:609`):
    ```php
            Log::error("BaAssessmentController::{$action} failed", ['error' => $e->getMessage()]);
    ```
  - **After:**
    ```php
            Log::error("BaAssessmentController::{$action} failed", ['error' => $e->getMessage(), 'exception' => $e]);
    ```
  - **Before** (job `failed()`, `ComputeStudentScoresJob.php:43-50`):
    ```php
    public function failed(?Throwable $exception): void
    {
        Log::error('BA: ComputeStudentScoresJob failed', [
            'period_id' => $this->periodId,
            'class_section_id' => $this->classSectionId,
            'error' => $exception?->getMessage(),
        ]);
    }
    ```
  - **After:**
    ```php
    public function failed(?Throwable $exception): void
    {
        Log::error('BA: ComputeStudentScoresJob failed', [
            'period_id' => $this->periodId,
            'class_section_id' => $this->classSectionId,
            'error' => $exception?->getMessage(),
            'exception' => $exception,
        ]);
    }
    ```
  - **Verify:** `grep -c "'exception' => \$e" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php; grep -n "'exception' => \$exception" Modules/BehaviouralAssessment/app/Jobs/ComputeStudentScoresJob.php`
  - **Expect:** the controller prints `4` (restore, forceDelete, recomputeScores, failure) and the job prints one matching line.
  - **Effort:** S

- [ ] **BASS-03** · M · TXN-04 · `BaAssessmentController.php:79,164,436,500,530` — move each `activityLog()` inside one transaction with the write it describes, by wrapping the service call + log in the controller's own `DB::transaction` (nested with the service's savepoint — one atomic unit). The existing `try/catch` shapes are unchanged. If BASS-01 was applied first, re-measure the current text before pasting (§9.2 #3); the wrapper shape is identical under either BASS-01 option.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Before** (`store`, lines 67-92):
    ```php
    public function store(BaAssessmentRequest $request): JsonResponse|RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.assessments.create');
        $employee = Employee::where('user_id', auth()->id())->first();

        try {
            [$assessment, $created] = $this->service->create($request->validated(), $employee?->id);
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'store');
        }

        if ($created) {
            activityLog($assessment, 'Stored', ['message' => 'BaAssessment was stored.']);
        }

        $message = $created
            ? 'Assessment created successfully.'
            : 'An assessment for this teacher, class-section and period already exists ('.$assessment->status.').';
    ```
    ```php
        if ($request->expectsJson()) {
            return response()->json(['success' => true, 'created' => $created, 'id' => $assessment->id, 'message' => $message]);
        }

        return redirect()->route('behavioural-assessment.assessments-page', ['tab' => 'my-assessments'])
            ->with('success', $created ? $message.' Click "Enter Ratings" to add scores.' : $message);
    }
    ```
  - **After:** (`store` — the two blocks above become one method):
    ```php
    public function store(BaAssessmentRequest $request): JsonResponse|RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.assessments.create');
        $employee = Employee::where('user_id', auth()->id())->first();

        try {
            [$assessment, $created] = DB::transaction(function () use ($request, $employee) {
                [$assessment, $created] = $this->service->create($request->validated(), $employee?->id);

                if ($created) {
                    activityLog($assessment, 'Stored', ['message' => 'BaAssessment was stored.']);
                }

                return [$assessment, $created];
            });
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'store');
        }

        $message = $created
            ? 'Assessment created successfully.'
            : 'An assessment for this teacher, class-section and period already exists ('.$assessment->status.').';

        if ($request->expectsJson()) {
            return response()->json(['success' => true, 'created' => $created, 'id' => $assessment->id, 'message' => $message]);
        }

        return redirect()->route('behavioural-assessment.assessments-page', ['tab' => 'my-assessments'])
            ->with('success', $created ? $message.' Click "Enter Ratings" to add scores.' : $message);
    }
    ```
  - **Before** (`update`, lines 154-172):
    ```php
    public function update(BaAssessmentRequest $request, int $id): JsonResponse|RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.assessments.update');

        try {
            $assessment = $this->service->updateHeader($id, $request->validated());
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'update');
        }

        activityLog($assessment, 'Updated', ['message' => 'BaAssessment was updated.']);

        if ($request->expectsJson()) {
            return response()->json(['success' => true, 'message' => 'Assessment updated successfully.']);
        }

        return redirect()->route('behavioural-assessment.assessments-page', ['tab' => 'my-assessments'])
            ->with('success', 'Assessment updated successfully.');
    }
    ```
  - **After:** (`update`):
    ```php
    public function update(BaAssessmentRequest $request, int $id): JsonResponse|RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.assessments.update');

        try {
            $assessment = DB::transaction(function () use ($request, $id) {
                $assessment = $this->service->updateHeader($id, $request->validated());

                activityLog($assessment, 'Updated', ['message' => 'BaAssessment was updated.']);

                return $assessment;
            });
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'update');
        }

        if ($request->expectsJson()) {
            return response()->json(['success' => true, 'message' => 'Assessment updated successfully.']);
        }

        return redirect()->route('behavioural-assessment.assessments-page', ['tab' => 'my-assessments'])
            ->with('success', 'Assessment updated successfully.');
    }
    ```
  - **Before** (`submit`, lines 423-433):
    ```php
        try {
            [$item, $autoLocked] = $this->service->submit($assessment);
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'submit');
        }

        // Rule A3: the application-wide activity log records the transition too.
        activityLog($item, 'Submitted', [
            'message' => $item->isSubmitted()
                ? 'Behavioural assessment was submitted for review.'
                : 'Behavioural assessment was submitted; review is not required for this session, so it was accepted directly.',
            'period_id' => $item->period_id,
            'status' => $item->status,
        ]);
    ```
  - **After:** (`submit`):
    ```php
        try {
            [$item, $autoLocked] = DB::transaction(function () use ($assessment) {
                [$item, $autoLocked] = $this->service->submit($assessment);

                // Rule A3: the application-wide activity log records the transition too.
                activityLog($item, 'Submitted', [
                    'message' => $item->isSubmitted()
                        ? 'Behavioural assessment was submitted for review.'
                        : 'Behavioural assessment was submitted; review is not required for this session, so it was accepted directly.',
                    'period_id' => $item->period_id,
                    'status' => $item->status,
                ]);

                return [$item, $autoLocked];
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'submit');
        }
    ```
  - **Before** (`approve`, lines 492-505):
    ```php
        try {
            [$item, $autoLocked] = $this->service->approve($assessment);
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'approve');
        }

        activityLog($item, 'Approved', [
            'message' => 'Behavioural assessment was approved.',
            'period_id' => $item->period_id,
            'reviewed_by' => $item->reviewed_by,
            'auto_locked' => $autoLocked,
        ]);
    ```
  - **After:** (`approve`):
    ```php
        try {
            [$item, $autoLocked] = DB::transaction(function () use ($assessment) {
                [$item, $autoLocked] = $this->service->approve($assessment);

                activityLog($item, 'Approved', [
                    'message' => 'Behavioural assessment was approved.',
                    'period_id' => $item->period_id,
                    'reviewed_by' => $item->reviewed_by,
                    'auto_locked' => $autoLocked,
                ]);

                return [$item, $autoLocked];
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'approve');
        }
    ```
  - **Before** (`sendBack`, lines 522-534):
    ```php
        try {
            [$item, $previous] = $this->service->sendBack($assessment, $remark);
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'sendBack');
        }

        activityLog($item, 'SentBack', [
            'message' => 'Behavioural assessment was sent back to the teacher.',
            'previous_status' => $previous,
            'reviewer_remarks' => $remark,
        ]);
    ```
  - **After:** (`sendBack`):
    ```php
        try {
            [$item, $previous] = DB::transaction(function () use ($assessment, $remark) {
                [$item, $previous] = $this->service->sendBack($assessment, $remark);

                activityLog($item, 'SentBack', [
                    'message' => 'Behavioural assessment was sent back to the teacher.',
                    'previous_status' => $previous,
                    'reviewer_remarks' => $remark,
                ]);

                return [$item, $previous];
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'sendBack');
        }
    ```
  - **Verify:** `grep -c "DB::transaction(function () use" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Expect:** `8` (the five wrappers plus the existing restore/forceDelete/destroy closures).
  - **Effort:** M

- [ ] **BASS-04** · M · TXN-05 · `BaAssessmentController.php:200,207-208,230,237-238,343-357` — return the model from the transaction closure and build the redirect/JSON after it; guard refusals become `\DomainException` thrown inside the closure and caught by a new D2-sanctioned catch.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Before** (`restore`, lines 185-219):
    ```php
    public function restore(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.assessments.restore');

        try {
            return DB::transaction(function () use ($id) {
                $assessment = BaAssessment::onlyTrashed()->findOrFail($id);

                // uq_ba_assessment keys on (teacher, class-section, period, uq_guard): a live sheet for
                // the same slot makes the restored row a duplicate.
                $clash = BaAssessment::where('teacher_id', $assessment->teacher_id)
                    ->where('class_section_id', $assessment->class_section_id)
                    ->where('period_id', $assessment->period_id)
                    ->exists();
                if ($clash) {
                    return back()->with('error', 'A live assessment already exists for this teacher, class-section and period. Delete it before restoring this one.');
                }

                $assessment->restore();

                activityLog($id, 'Restored', ['message' => 'BaAssessment was restored.']);

                return redirect()->route('behavioural-assessment.assessments.trashed')
                    ->with('success', 'Assessment restored successfully.');
            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (Throwable $e) {
            Log::error('BaAssessmentController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    }
    ```
  - **After:** (`restore`):
    ```php
    public function restore(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.assessments.restore');

        try {
            $assessment = DB::transaction(function () use ($id) {
                $assessment = BaAssessment::onlyTrashed()->findOrFail($id);

                // uq_ba_assessment keys on (teacher, class-section, period, uq_guard): a live sheet for
                // the same slot makes the restored row a duplicate.
                $clash = BaAssessment::where('teacher_id', $assessment->teacher_id)
                    ->where('class_section_id', $assessment->class_section_id)
                    ->where('period_id', $assessment->period_id)
                    ->exists();
                if ($clash) {
                    throw new DomainException('A live assessment already exists for this teacher, class-section and period. Delete it before restoring this one.');
                }

                $assessment->restore();

                activityLog($assessment, 'Restored', ['message' => 'BaAssessment was restored.']);

                return $assessment;
            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (DomainException $e) {
            // ERR-01 (2026-10-12): business-rule message shown verbatim — D2 allows this catch.
            return back()->with('error', $e->getMessage());
        } catch (Throwable $e) {
            Log::error('BaAssessmentController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }

        return redirect()->route('behavioural-assessment.assessments.trashed')
            ->with('success', 'Assessment restored successfully.');
    }
    ```
  - **Before** (`forceDelete`, lines 221-249):
    ```php
    public function forceDelete(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.assessments.forceDelete');

        try {
            return DB::transaction(function () use ($id) {
                $assessment = BaAssessment::onlyTrashed()->findOrFail($id);

                if (! $assessment->isDraft()) {
                    return back()->with('error', 'Only draft assessments can be permanently deleted.');
                }

                $assessment->forceDelete();

                activityLog($id, 'Deleted', ['message' => 'BaAssessment was deleted.']);

                return redirect()->route('behavioural-assessment.assessments.trashed')
                    ->with('success', 'Assessment permanently deleted.');
            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (Throwable $e) {
            Log::error('BaAssessmentController::forceDelete failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    }
    ```
  - **After:** (`forceDelete`):
    ```php
    public function forceDelete(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.assessments.forceDelete');

        try {
            $assessment = DB::transaction(function () use ($id) {
                $assessment = BaAssessment::onlyTrashed()->findOrFail($id);

                if (! $assessment->isDraft()) {
                    throw new DomainException('Only draft assessments can be permanently deleted.');
                }

                $assessment->forceDelete();

                activityLog($assessment, 'Deleted', ['message' => 'BaAssessment was deleted.']);

                return $assessment;
            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (DomainException $e) {
            // ERR-01 (2026-10-12): business-rule message shown verbatim — D2 allows this catch.
            return back()->with('error', $e->getMessage());
        } catch (Throwable $e) {
            Log::error('BaAssessmentController::forceDelete failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }

        return redirect()->route('behavioural-assessment.assessments.trashed')
            ->with('success', 'Assessment permanently deleted.');
    }
    ```
  - **Before** (`destroy`, lines 334-366):
    ```php
    public function destroy(Request $request, int $id): JsonResponse|RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.assessments.delete');

        try {
            return DB::transaction(function () use ($request, $id) {
                $assessment = BaAssessment::findOrFail($id);

                if (! $assessment->isDraft()) {
                    return $request->expectsJson()
                        ? response()->json(['success' => false, 'message' => 'Only draft assessments can be deleted.'], 422)
                        : back()->with('error', 'Only draft assessments can be deleted.');
                }

                $assessment->delete();

                activityLog($assessment, 'Trashed', ['message' => 'BaAssessment was trashed.']);

                if ($request->expectsJson()) {
                    return response()->json(['success' => true, 'message' => 'Assessment moved to trash.']);
                }

                return redirect()->route('behavioural-assessment.assessments-page', ['tab' => 'my-assessments'])
                    ->with('success', 'Assessment moved to trash.');
            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'destroy');
        }
    }
    ```
  - **After:** (`destroy`):
    ```php
    public function destroy(Request $request, int $id): JsonResponse|RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.assessments.delete');

        try {
            DB::transaction(function () use ($id) {
                $assessment = BaAssessment::findOrFail($id);

                if (! $assessment->isDraft()) {
                    throw new DomainException('Only draft assessments can be deleted.');
                }

                $assessment->delete();

                activityLog($assessment, 'Trashed', ['message' => 'BaAssessment was trashed.']);
            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (DomainException $e) {
            // ERR-01 (2026-10-12): business-rule message shown verbatim — D2 allows this catch.
            return $request->expectsJson()
                ? response()->json(['success' => false, 'message' => $e->getMessage()], 422)
                : back()->with('error', $e->getMessage());
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'destroy');
        }

        if ($request->expectsJson()) {
            return response()->json(['success' => true, 'message' => 'Assessment moved to trash.']);
        }

        return redirect()->route('behavioural-assessment.assessments-page', ['tab' => 'my-assessments'])
            ->with('success', 'Assessment moved to trash.');
    }
    ```
  - **Verify:** `grep -n "return redirect()\|return back()\|return response()->json\|return DB::transaction" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Expect:** no `return redirect()`/`return back()`/`return response()->json` line sits between a `DB::transaction` line and its closing `});` in the three methods.
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **BASS-05** · L · AUTH-04 · `BaAssessmentController.php:69,156,373,399,519` — drop the five controller gate calls that duplicate the FormRequests' `authorize()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Before** (`store`, line 69):
    ```php
        Gate::authorize('tenant.behavioural-assessment.assessments.create');
    ```
  - **After:** (`store` — keep the line above `$employee`, replaced by a comment):
    ```php
        // Authorization enforced by BaAssessmentRequest::authorize() (AUTH-04: one check, not two).
    ```
  - **Before** (`update`, line 156):
    ```php
        Gate::authorize('tenant.behavioural-assessment.assessments.update');
    ```
  - **After:** (`update`):
    ```php
        // Authorization enforced by BaAssessmentRequest::authorize() (AUTH-04: one check, not two).
    ```
  - **Before** (`bulkRate`, line 373):
    ```php
        Gate::authorize('tenant.behavioural-assessment.assessments.update');
    ```
  - **After:** (`bulkRate`):
    ```php
        // Authorization enforced by BaAssessmentRatingsRequest::authorize() (AUTH-04: one check, not two).
    ```
  - **Before** (`autoSave`, line 399):
    ```php
        Gate::authorize('tenant.behavioural-assessment.assessments.update');
    ```
  - **After:** (`autoSave`):
    ```php
        // Authorization enforced by BaAssessmentRatingsRequest::authorize() (AUTH-04: one check, not two).
    ```
  - **Before** (`sendBack`, line 519):
    ```php
        Gate::authorize('tenant.behavioural-assessment.reviews.update');
    ```
  - **After:** (`sendBack`):
    ```php
        // Authorization enforced by BaAssessmentSendBackRequest::authorize() (AUTH-04: one check, not two).
    ```
  - **Note:** ensure the five replacements above hit the right line — `bulkRate` (373) and `autoSave` (399) share the identical gate string, so the fixer replaces by line number within each method, not by string.
  - **Verify:** `grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Expect:** 14 matches (was 19; the five FormRequest-backed methods now authorize in the request only).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7) and controller shape (F6)

- [ ] **BASS-09** · M · CTL-05 · `BaAssessmentController.php:54-57,141,147-149` — extract the shared dropdown loaders into one private helper used by `create()` and `edit()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Before** (`create` loader block, lines 54-57):
    ```php
        $employee = Employee::where('user_id', auth()->id())->first();
        $openPeriods = BaAssessmentPeriod::where('status', BaAssessmentPeriod::STATUS_OPEN)->where('is_active', true)->orderByDesc('created_at')->get();
        $classSections = ClassSection::with(['class', 'section'])->where('is_active', true)->orderBy('name')->get();
        $subjects = Subject::where('is_active', true)->orderBy('name')->get(['id', 'name']);
    ```
  - **Before** (`edit` loader block, lines 140-149):
    ```php
        $employee = Employee::where('user_id', auth()->id())->first();
        $openPeriods = BaAssessmentPeriod::where('status', BaAssessmentPeriod::STATUS_OPEN)->where('is_active', true)->orderByDesc('created_at')->get();
        // The sheet's own period stays selectable after it closes: a draft in a closed period is
        // still editable (decision 7), it just cannot move into a period that is not open.
        if ($assessment->period && ! $openPeriods->contains('id', $assessment->period_id)) {
            $openPeriods->prepend($assessment->period);
        }
        $classSections = ClassSection::with(['class', 'section'])->where('is_active', true)->orderBy('name')->get();
        $allTeachers = Employee::active()->orderBy('first_name')->get();
        $subjects = Subject::where('is_active', true)->orderBy('name')->get(['id', 'name']);
    ```
  - **After:** (add this private helper above `sheetExtras()`, after `sendBack()`):
    ```php
    /**
     * The dropdown option lists shared by the create and edit forms.
     *
     * @return array{openPeriods: \Illuminate\Database\Eloquent\Collection, classSections: \Illuminate\Database\Eloquent\Collection, subjects: \Illuminate\Database\Eloquent\Collection}
     */
    private function formOptions(): array
    {
        $openPeriods = BaAssessmentPeriod::where('status', BaAssessmentPeriod::STATUS_OPEN)->where('is_active', true)->orderByDesc('created_at')->get();
        $classSections = ClassSection::with(['class', 'section'])->where('is_active', true)->orderBy('name')->get();
        $subjects = Subject::where('is_active', true)->orderBy('name')->get(['id', 'name']);

        return compact('openPeriods', 'classSections', 'subjects');
    }
    ```
  - **After:** (`create`, the loader block becomes):
    ```php
        $employee = Employee::where('user_id', auth()->id())->first();
        $options = $this->formOptions();

        $teachers = null;
        if (! $employee) {
            $teachers = Employee::active()->orderBy('first_name')->get();
        }

        return view('behaviouralassessment::assessment.create', compact('employee', 'teachers') + $options);
    ```
  - **After:** (`edit`, the loader block becomes):
    ```php
        $employee = Employee::where('user_id', auth()->id())->first();
        $options = $this->formOptions();
        // The sheet's own period stays selectable after it closes: a draft in a closed period is
        // still editable (decision 7), it just cannot move into a period that is not open.
        if ($assessment->period && ! $options['openPeriods']->contains('id', $assessment->period_id)) {
            $options['openPeriods']->prepend($assessment->period);
        }
        $allTeachers = Employee::active()->orderBy('first_name')->get();

        return view('behaviouralassessment::assessment.edit', compact('assessment', 'employee', 'allTeachers') + $options);
    ```
  - **Verify:** `grep -n "formOptions\|BaAssessmentPeriod::where('status'" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Expect:** `formOptions` appears in the helper and two call sites; the repeated `BaAssessmentPeriod::where('status'...` query appears exactly once (inside the helper).
  - **Effort:** S

- [ ] **BASS-10** · M · SVC-01 · `BaAssessmentService.php:714-717` and the four controller call sites — pass the request IP into the service instead of reading the request inside it.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php`, `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Before** (`recordTransition`, `BaAssessmentService.php:709-717`):
    ```php
    public function recordTransition(BaAssessment $assessment, ?string $from, string $to, string $action, ?string $remark = null): void
    {
        $actor = BaActor::id();
        $ip = null;

        if (app()->bound('request') && ! app()->runningInConsole() && request()->ip() !== null) {
            $packed = @inet_pton((string) request()->ip());
            $ip = $packed === false ? null : $packed;
        }
    ```
  - **After:** (`recordTransition`):
    ```php
    public function recordTransition(BaAssessment $assessment, ?string $from, string $to, string $action, ?string $remark = null, ?string $clientIp = null): void
    {
        $actor = BaActor::id();
        $ip = null;

        if ($clientIp !== null) {
            $packed = @inet_pton($clientIp);
            $ip = $packed === false ? null : $packed;
        }
    ```
  - **After:** (forward the IP through the five service methods — each signature gains `?string $clientIp = null` and each `recordTransition(` call gains `$clientIp` as its last argument; `lockReviewed` gains it too):
    ```php
    public function create(array $data, ?int $employeeId, ?string $clientIp = null): array
    ```
    ```php
            $this->recordTransition($assessment, null, BaAssessment::STATUS_DRAFT, BaAssessmentStatusHistory::ACTION_CREATE, null, $clientIp);
    ```
    ```php
    public function submit(int $assessmentId, ?string $clientIp = null): array
    ```
    ```php
                $this->recordTransition($assessment, BaAssessment::STATUS_DRAFT, BaAssessment::STATUS_SUBMITTED, BaAssessmentStatusHistory::ACTION_SUBMIT, null, $clientIp);
    ```
    ```php
    public function approve(int $assessmentId, ?string $clientIp = null): array
    ```
    ```php
            $this->recordTransition($assessment, BaAssessment::STATUS_SUBMITTED, BaAssessment::STATUS_REVIEWED, BaAssessmentStatusHistory::ACTION_APPROVE, null, $clientIp);
    ```
    ```php
    public function sendBack(int $assessmentId, string $remark, ?string $clientIp = null): array
    ```
    ```php
            $this->recordTransition($assessment, $previous, BaAssessment::STATUS_DRAFT, BaAssessmentStatusHistory::ACTION_SEND_BACK, $remark, $clientIp);
    ```
    ```php
    public function lockReviewed(BaAssessment $assessment, ?int $employeeId, ?string $clientIp = null): void
    ```
    ```php
        $this->recordTransition($assessment, BaAssessment::STATUS_REVIEWED, BaAssessment::STATUS_LOCKED, BaAssessmentStatusHistory::ACTION_LOCK, null, $clientIp);
    ```
    and inside `submit()`/`approve()`, the `lockReviewed(...)` call gains `$clientIp`:
    ```php
                    $this->lockReviewed($assessment, $employeeId, $clientIp);
    ```
  - **After:** (the four controller call sites pass `$request->ip()`):
    ```php
            [$assessment, $created] = DB::transaction(function () use ($request, $employee) {
                [$assessment, $created] = $this->service->create($request->validated(), $employee?->id, $request->ip());
    ```
    ```php
                [$item, $autoLocked] = $this->service->submit($assessment, $request->ip());
    ```
    ```php
                [$item, $autoLocked] = $this->service->approve($assessment, $request->ip());
    ```
    ```php
                [$item, $previous] = $this->service->sendBack($assessment, $remark, $request->ip());
    ```
  - **Verify:** `grep -n "request()->ip()\|app()->bound('request')\|runningInConsole" Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php`
  - **Expect:** no output in the service; `grep -c "->ip()" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php` prints `1` (the four calls collapse to the `$request->ip()` pattern).
  - **Effort:** M

- [ ] **BASS-11** · M · SVC-02 · `BaAssessmentController.php:42,468,484` — inject `BaReviewSignalService` through the constructor instead of `app()` mid-method.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Before** (constructor + the two `app()` calls, `BaAssessmentController.php:42` and `:468,484`):
    ```php
    public function __construct(private readonly BaAssessmentService $service) {}
    ```
    ```php
        $reviewSignals = app(BaReviewSignalService::class)->forAssessments($queue->getCollection());
    ```
    ```php
            'reviewSignals' => app(BaReviewSignalService::class)->forAssessment($item),
    ```
  - **After:**
    ```php
    public function __construct(
        private readonly BaAssessmentService $service,
        private readonly BaReviewSignalService $signals,
    ) {}
    ```
    ```php
        $reviewSignals = $this->signals->forAssessments($queue->getCollection());
    ```
    ```php
            'reviewSignals' => $this->signals->forAssessment($item),
    ```
  - **Verify:** `grep -n "app(BaReviewSignalService\|private readonly BaReviewSignalService" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Expect:** no `app(BaReviewSignalService` matches; one `private readonly BaReviewSignalService` in the constructor.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **BASS-13** · M · DECISION · QRY-07 — convert the per-row writes in `saveRatings()` to bulk writes.
  - **Why it is a decision:** a bulk `upsert()` conversion changes the behaviour of the per-row validation messages and interacts with the soft-delete guard on `ba_assessment_ratings` (`uq_ba_rating`); it is entangled with the BASS-12 extraction.
  - (a) ⭐ Defer: fold the bulk conversion into the BASS-12 extraction of `saveRatings` — once the method is split into per-concern helpers, each helper can pre-validate and bulk-write. No code changes until BASS-12 is ticked.
  - (b) Do a standalone bulk conversion now: pre-validate all incoming cells (the existing `$studentSet`/`$criterionSet`/`$levels` checks), then `BaAssessmentRating::upsert(...)` for the new/changed trios and `whereIn('id', $ids)->update(...)` for the diffs, keeping the `rated_at`/`updated_by` per-row values.
  - (c) Accept, document.
  - ➜ Choice: ____

## 7. Views (F10)

- [ ] **BASS-14** · M · VIEW-02 / QRY-01 · `BaAssessmentController.php:462` — eager-load `teacher.user` in `reviewIndex()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Before** (`reviewIndex`, line 462):
    ```php
        $queue = BaAssessment::with(['period', 'teacher', 'subject', 'classSection.class', 'classSection.section'])
    ```
  - **After:**
    ```php
        $queue = BaAssessment::with(['period', 'teacher.user', 'subject', 'classSection.class', 'classSection.section'])
    ```
  - **Verify:** `grep -n "'teacher.user'" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Expect:** one match in `reviewIndex()` (line 462).
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **BASS-15** · L · STY-02 · `BaAssessmentController.php:13-28,553` — Pint-clean the controller.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php`
  - **Before** (import block, lines 7-34):
    ```php
    use DomainException;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Database\QueryException;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Http\Requests\BaAssessmentRatingsRequest;
    use Modules\BehaviouralAssessment\Http\Requests\BaAssessmentRequest;
    use Modules\BehaviouralAssessment\Http\Requests\BaAssessmentSendBackRequest;
    use Modules\BehaviouralAssessment\Models\BaAssessment;
    use Modules\BehaviouralAssessment\Models\BaAssessmentPeriod;
    use Modules\BehaviouralAssessment\Models\BaAssessmentRating;
    use Modules\BehaviouralAssessment\Models\BaCommentBank;
    use Modules\BehaviouralAssessment\Models\BaStudentRemark;
    use Modules\BehaviouralAssessment\Services\BaAssessmentService;
    use Modules\BehaviouralAssessment\Services\BaReviewSignalService;
    use Modules\BehaviouralAssessment\Jobs\ComputeStudentScoresJob;
    use Modules\BehaviouralAssessment\Support\BaDispatch;
    use Modules\BehaviouralAssessment\Support\BaTriggerError;
    use Modules\SchoolSetup\Models\ClassSection;
    use Modules\SchoolSetup\Models\Employee;
    use Modules\SchoolSetup\Models\Subject;
    use Throwable;
    ```
  - **After:** (import block, sorted — `Collection` added, `ComputeStudentScoresJob` moved before the Models imports):
    ```php
    use DomainException;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Database\QueryException;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Collection;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Http\Requests\BaAssessmentRatingsRequest;
    use Modules\BehaviouralAssessment\Http\Requests\BaAssessmentRequest;
    use Modules\BehaviouralAssessment\Http\Requests\BaAssessmentSendBackRequest;
    use Modules\BehaviouralAssessment\Jobs\ComputeStudentScoresJob;
    use Modules\BehaviouralAssessment\Models\BaAssessment;
    use Modules\BehaviouralAssessment\Models\BaAssessmentPeriod;
    use Modules\BehaviouralAssessment\Models\BaAssessmentRating;
    use Modules\BehaviouralAssessment\Models\BaCommentBank;
    use Modules\BehaviouralAssessment\Models\BaStudentRemark;
    use Modules\BehaviouralAssessment\Services\BaAssessmentService;
    use Modules\BehaviouralAssessment\Services\BaReviewSignalService;
    use Modules\BehaviouralAssessment\Support\BaDispatch;
    use Modules\BehaviouralAssessment\Support\BaTriggerError;
    use Modules\SchoolSetup\Models\ClassSection;
    use Modules\SchoolSetup\Models\Employee;
    use Modules\SchoolSetup\Models\Subject;
    use Throwable;
    ```
  - **Before** (`sheetExtras` docblock, line 553):
    ```php
     * @return array{cellMeta: \Illuminate\Support\Collection, remarkTemplateIds: \Illuminate\Support\Collection}
    ```
  - **After:**
    ```php
     * @return array{cellMeta: Collection, remarkTemplateIds: Collection}
    ```
  - **Note:** running `vendor/bin/pint Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php --format agent` produces exactly the import block and docblock shown above.
  - **Verify:** `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

- [ ] **BASS-16** · L · STY-02 · `BaAssessmentService.php:334,336` — Pint-clean the service docblock alignment.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php`
  - **Before** (`saveRatings` docblock continuation, `BaAssessmentService.php:334,336`):
    ```php
         *                                                                                (ba_assessment_ratings.remark); null = untouched
    ```
    ```php
         *                                                    (comment_template_id, analytics only); absent/empty = unchanged
    ```
  - **After:**
    ```php
         *                                                                              (ba_assessment_ratings.remark); null = untouched
    ```
    ```php
         *                                                     (comment_template_id, analytics only); absent/empty = unchanged
    ```
  - **Note:** the change is `phpdoc_align` removing two leading spaces from line 334 and adding one to line 336; running `vendor/bin/pint Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php --format agent` applies it.
  - **Verify:** `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

- [ ] **BASS-17** · L · STY-02 · `BaReviewSignalService.php:11,187` — import `BaConfig` and use the short name.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaReviewSignalService.php`
  - **Before** (import block + the FQCN call, `BaReviewSignalService.php:7-11,187`):
    ```php
    use Illuminate\Database\Query\Builder;
    use Illuminate\Support\Carbon;
    use Illuminate\Support\Facades\DB;
    use Modules\BehaviouralAssessment\Models\BaAssessment;
    use Modules\BehaviouralAssessment\Models\BaCommentBank;
    ```
    ```php
                ? \Modules\BehaviouralAssessment\Models\BaConfig::where('academic_session_id', $sessionId)->first()
    ```
  - **After:**
    ```php
    use Illuminate\Database\Query\Builder;
    use Illuminate\Support\Carbon;
    use Illuminate\Support\Facades\DB;
    use Modules\BehaviouralAssessment\Models\BaAssessment;
    use Modules\BehaviouralAssessment\Models\BaCommentBank;
    use Modules\BehaviouralAssessment\Models\BaConfig;
    ```
    ```php
                ? BaConfig::where('academic_session_id', $sessionId)->first()
    ```
  - **Note:** running `vendor/bin/pint Modules/BehaviouralAssessment/app/Services/BaReviewSignalService.php --format agent` produces exactly the import and call shown above.
  - **Verify:** `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Services/BaReviewSignalService.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

- [ ] **BASS-18** · L · STY-02 · `BaAssessmentRequest.php:26,28,35` — un-align the `=>` in `rules()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRequest.php`
  - **Before** (`rules()`, lines 26,28,35):
    ```php
                'period_id'        => ['required', 'integer', 'exists:ba_assessment_periods,id'],
    ```
    ```php
                'teacher_id'       => ['nullable', 'integer', 'exists:sch_employees,id'],
    ```
    ```php
                'subject_id'       => [
    ```
  - **After:**
    ```php
                'period_id' => ['required', 'integer', 'exists:ba_assessment_periods,id'],
    ```
    ```php
                'teacher_id' => ['nullable', 'integer', 'exists:sch_employees,id'],
    ```
    ```php
                'subject_id' => [
    ```
  - **Note:** running `vendor/bin/pint Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRequest.php --format agent` applies `binary_operator_spaces` to these three lines (and leaves the untouched `class_section_id` line as it is — it is already single-spaced).
  - **Verify:** `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRequest.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

- [ ] **BASS-19** · L · STY-02 · `BaAssessmentRatingsRequest.php:55-67` — un-align the `=>` in `rules()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRatingsRequest.php`
  - **Before** (`rules()`, lines 55-67):
    ```php
                'ratings'     => ['nullable', 'array'],
    ```
    ```php
                'ratings.*'   => ['array'],
    ```
    ```php
                'remarks'     => ['nullable', 'array'],
    ```
    ```php
                'remarks.*'   => ['nullable', 'string', 'max:1000'],
    ```
    ```php
                'criterion_remarks'     => ['nullable', 'array'],
    ```
    ```php
                'criterion_remarks.*'   => ['array'],
    ```
    ```php
                'remark_templates'   => ['nullable', 'array'],
    ```
  - **After:**
    ```php
                'ratings' => ['nullable', 'array'],
    ```
    ```php
                'ratings.*' => ['array'],
    ```
    ```php
                'remarks' => ['nullable', 'array'],
    ```
    ```php
                'remarks.*' => ['nullable', 'string', 'max:1000'],
    ```
    ```php
                'criterion_remarks' => ['nullable', 'array'],
    ```
    ```php
                'criterion_remarks.*' => ['array'],
    ```
    ```php
                'remark_templates' => ['nullable', 'array'],
    ```
  - **Note:** running `vendor/bin/pint Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRatingsRequest.php --format agent` applies `binary_operator_spaces` to these seven lines (and the already-single-spaced line 68 stays unchanged).
  - **Verify:** `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRatingsRequest.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BASS-08** · M · DECISION · CTL-03 — adopt route-model binding for the twelve `$id`/`$assessment` methods?
  - **Why it is a decision:** the trash routes use `{id}`, so binding them to `BaAssessment $assessment` requires a route-parameter rename in the shared route file (`web.php:102-103`), and D3 says this pass fixes in place. ⚠ SHARED (route file).
  - (a) ⭐ Defer to the D3 refactor pass: leave the twelve `int $id` + `findOrFail()` shapes as they are today.
  - (b) Do it now: type the `{assessment}` methods `BaAssessment $assessment`, rename `{id}` → `{assessment}` for `restore`/`forceDelete` (with `onlyTrashed()` binding), and add a `whereNumber`/scoped binding note for `remarkDetails`.
  - (c) Leave as is, record as accepted.
  - ➜ Choice: ____

- [ ] **BASS-12** · M · DECISION · CTL-02 — extract the two long service methods?
  - **Why it is a decision:** a behaviour-preserving refactor of a working 196-line transactional writer and a 108-line signal assembler; the QRY-07 bulk-write conversion (BASS-13) is folded into it.
  - (a) ⭐ Defer to the post-go-live split/refactor pass: record the length debt now.
  - (b) Extract now: split `BaAssessmentService::saveRatings()` into `saveRatingCells()`, `saveCriterionRemarks()`, `saveStudentRemarks()` private helpers (same transaction), and `BaReviewSignalService::assemble()` into per-signal builders.
  - (c) Leave as is, record as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BASS-06 | AUTH-06 — permission strings as literals is a module-wide pass (Policy/constants), not a per-controller change; the module summary tracks it. |