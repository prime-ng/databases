# Final Audit — BehaviouralAssessment / BaRatingScaleController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php` (584 lines, 14 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `xyz_school_00000000000040008000_202627` (first tenant in the central `tenants` table)

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/behavioural-assessment/rating-scales` (redirects to the Masters tab); `/behavioural-assessment/rating-scales/create`; `/behavioural-assessment/rating-scales/{id}`; `/behavioural-assessment/rating-scales/{id}/edit`; `/behavioural-assessment/rating-scales/trash` |
| Menu path | Behavioural Assessment → Masters → Rating Scales & Levels tab (`glb_menus` id 301 "Masters", tab id `rating-scales`) |
| Who uses it | School Admin, Super Admin — the only two roles holding the seven `tenant.behavioural-assessment.rating-scales.*` permissions in the tenant `sys_role_has_permissions_jnt` (School Admin=7, Super Admin=7) |
| What a user does here | Defines a rating scale (a code, a name, a grade type, a Min and Max value) together with its ordered levels. Each level has a label, a numeric value, a report-card grade and an optional description. The user can add, reorder, toggle-active, trash, restore and permanently delete scales, and toggle a scale active/inactive from the list. A scale becomes read-only ("In use") once any assessment rating references one of its levels. |
| Tables written | `ba_rating_scales` (create/update/soft-delete/restore/force-delete/is_active toggle); `ba_rating_levels` (create/update/soft-delete/restore/force-delete through the sync helpers); `sys_activity_logs` (one row per mutation through the `activityLog()` helper) |
| Tables read | `ba_rating_scales`, `ba_rating_levels`, `ba_assessment_ratings` (the "is this scale in use" check) |
| Live data | `ba_rating_scales` 1 live row, 0 trashed; `ba_rating_levels` 5 live rows, 0 trashed; `ba_assessment_ratings` 21996 rows (so the one live scale is locked "In use") on the measured tenant |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Not production-ready as-is; 0 blockers, 1 HIGH — ready after the fixes, roughly one day.** The worst finding is **BARS-08**: the `restore` route is a `GET` that changes state, so a link prefetcher, crawler or plain browser hit can un-trash a rating scale with no CSRF token. The controller is otherwise correct on the normal path and well commented, but it carries the whole of the module's House-rule-A1 error idiom: nine mutating methods wrap `DB::transaction` in a controller `try`/`catch` that D1 forbids, each logging only `$e->getMessage()` and building the HTTP response inside the transaction closure. One structural finding is controller-specific: the three per-level endpoints (`storeLevel`, `updateLevel`, `destroyLevel`) are routed but have **no caller anywhere in the app** — the create/edit form saves every level in one submit — so roughly 145 lines of dead, duplicate level-write logic sit behind live mutating routes. The remaining findings are mechanical (route-model binding, bulk writes, Pint). Effort: M (about a day), with four DECISION items needing your choice first.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 9 | 5 | 4 | 15 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BARS-01, BARS-02 | F8 Services/Jobs | clean — `grep -oE '[A-Z][A-Za-z]+(Request\|Policy\|Service\|Job\|Event\|Mail\|Notification\|Export\|Import)\b'` returns only `BaRatingScaleRequest` |
| F2 Transactions/Audit | BARS-03, BARS-04 | F9 Queries/Perf | BARS-12 |
| F3 Authorization | BARS-05 | F10 Views | clean — no query, no `{!! !!}`, relations eager-loaded (see F10) |
| F4 Validation | BARS-06, BARS-07 | F11 Security/Tenancy | clean — no `env()`, no secrets logged, grade cache keyed by database name (see F11) |
| F5 Routes | BARS-08 | F12 Style | BARS-13, BARS-14 |
| F6 Controller shape | BARS-09, BARS-10, BARS-11 | F13 Deep read | BARS-15 |
| F7 Models | clean — `$fillable`/`$casts`/`SoftDeletes`/`$table`/return-typed relations all present (see F7) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php` | controller | 584 | this report | ✅ whole class |
| 2 | `Modules/BehaviouralAssessment/app/Models/BaRatingScale.php` | model | 81 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Models/BaRatingLevel.php` | model | 142 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Http/Requests/BaRatingScaleRequest.php` | FormRequest | 179 | this report (only this controller uses it) | ✅ |
| 5 | `Modules/BehaviouralAssessment/routes/web.php` lines 26-34 | routes | — | this report (shared route file; BARS-08 touches line 28) | ✅ |
| 6 | `Modules/BehaviouralAssessment/resources/views/rating-scale/create.blade.php` | blade | 23 | this report (`create()` renders it) | ✅ |
| 7 | `Modules/BehaviouralAssessment/resources/views/rating-scale/edit.blade.php` | blade | 33 | this report (`edit()` renders it) | ✅ |
| 8 | `Modules/BehaviouralAssessment/resources/views/rating-scale/show.blade.php` | blade | 154 | this report (`show()` renders it) | ✅ |
| 9 | `Modules/BehaviouralAssessment/resources/views/rating-scale/trash.blade.php` | blade | 79 | this report (`trashed()` renders it) | ✅ |
| 10 | `Modules/BehaviouralAssessment/resources/views/rating-scale/_form.blade.php` | blade | 383 | this report (included by create + edit) | ✅ |
| 11 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | 45 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 12 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support | 50 | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |
| 13 | `Modules/BehaviouralAssessment/resources/views/rating-scale/_create-fields.blade.php` | blade | 201 | ↗ BaDashboardController report (when written) | ↗ referenced — rendered by the Masters page create dialog, posts to `store()`; not rendered by any method of this controller |
| 14 | `Modules/BehaviouralAssessment/resources/views/pages/partials/masters/_rating-scales.blade.php` | blade | 110 | ↗ BaDashboardController report (when written) | ↗ referenced — the tab list, supplies `$ratingScales` and posts to this controller |
| 15 | `Modules/BehaviouralAssessment/resources/views/pages/partials/masters/_rating-scales-create-modal.blade.php` | blade | 120 | ↗ BaDashboardController report (when written) | ↗ referenced — modal shell + level-row script |
| 16 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php` (`masters()`) | controller | — | ↗ BaDashboardController report (when written) | ↗ referenced — supplies `$ratingScales` (with `levels_count`) to the tab |
| — | `app/Traits/AuthorizesTenantFeature.php` | trait (app glue) | 60 | common | ↗ referenced — used by the FormRequest's `authorize()` |
| — | `resources/views/components/backend/**` (layout, `breadcrum`, `tab.search-bar`, `tab.modal`, `table.status-switch`, `table.action`, `table.action-trashed`) | components | — | common | ↗ referenced |

**Pre-applied 2026-10-10:** none — no file in scope appears in a module `PRE-APPLIED-*.md`.

## 4. Routes

```
GET|HEAD  behavioural-assessment/rating-scales                                 behavioural-assessment.rating-scales.index         BaRatingScaleController@index
POST      behavioural-assessment/rating-scales                                 behavioural-assessment.rating-scales.store         BaRatingScaleController@store
GET|HEAD  behavioural-assessment/rating-scales/create                          behavioural-assessment.rating-scales.create        BaRatingScaleController@create
GET|HEAD  behavioural-assessment/rating-scales/trash                           behavioural-assessment.rating-scales.trashed       BaRatingScaleController@trashed
DELETE    behavioural-assessment/rating-scales/{id}/force-delete               behavioural-assessment.rating-scales.forceDelete   BaRatingScaleController@forceDelete
GET|HEAD  behavioural-assessment/rating-scales/{id}/restore                    behavioural-assessment.rating-scales.restore       BaRatingScaleController@restore
POST      behavioural-assessment/rating-scales/{ratingScale}/levels           behavioural-assessment.rating-scales.levels.store  BaRatingScaleController@storeLevel
PUT       behavioural-assessment/rating-scales/{ratingScale}/levels/{level}    behavioural-assessment.rating-scales.levels.update BaRatingScaleController@updateLevel
DELETE    behavioural-assessment/rating-scales/{ratingScale}/levels/{level}    behavioural-assessment.rating-scales.levels.destroy BaRatingScaleController@destroyLevel
POST      behavioural-assessment/rating-scales/{ratingScale}/toggle-status     behavioural-assessment.rating-scales.toggleStatus  BaRatingScaleController@toggleStatus
GET|HEAD  behavioural-assessment/rating-scales/{rating_scale}                  behavioural-assessment.rating-scales.show          BaRatingScaleController@show
PUT|PATCH behavioural-assessment/rating-scales/{rating_scale}                  behavioural-assessment.rating-scales.update        BaRatingScaleController@update
DELETE    behavioural-assessment/rating-scales/{rating_scale}                  behavioural-assessment.rating-scales.destroy       BaRatingScaleController@destroy
GET|HEAD  behavioural-assessment/rating-scales/{rating_scale}/edit             behavioural-assessment.rating-scales.edit          BaRatingScaleController@edit
```

Middlewares on every route: `web, InitializeTenancyByDomain, PreventAccessFromCentralDomains, EnsureTenantIsActive, EnsureTenantHasModule:BehaviouralAssessment, auth, verified` (uncached `route:list --json`). The custom routes are ordered before `Route::resource` except `storeLevel` (line 34, after it); `storeLevel` is a two-segment POST that no resource route can match, so there is no capture.

Route-parameter name check (`module-finalization.md` §3.3.1): the resource routes carry `{rating_scale}` while `show`/`edit`/`update`/`destroy` take `int $id`; the custom routes carry `{id}` (`restore`/`forceDelete`, matching) and `{ratingScale}`/`{level}` (`toggleStatus`/`storeLevel`/`updateLevel`/`destroyLevel`, matching). No route names a model type-hint, so there is no unbound-model insert risk.

**Unrouted public methods:** none. All 14 public methods (`index`, `create`, `store`, `show`, `edit`, `update`, `destroy`, `trashed`, `restore`, `forceDelete`, `toggleStatus`, `storeLevel`, `updateLevel`, `destroyLevel`) appear in the route list; no D5 work is needed. (Three of them are routed but unreferenced — see BARS-11.)

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 25 | GET `rating-scales` | `tenant.behavioural-assessment.rating-scales.viewAny` | — | — | none (redirect only) | — |
| `create` | 32 | GET `rating-scales/create` | `tenant.behavioural-assessment.rating-scales.create` | — | — | none (renders view) | — |
| `store` | 39 | POST `rating-scales` | `tenant.behavioural-assessment.rating-scales.create` (also FormRequest `authorize()`) | ✅ `DB::transaction` closure | `Stored` (after write, in tx ✅) | `ba_rating_scales`, `ba_rating_levels`, `sys_activity_logs` | BARS-01, BARS-02, BARS-03, BARS-05, BARS-09 |
| `show` | 82 | GET `rating-scales/{rating_scale}` | `tenant.behavioural-assessment.rating-scales.view` | — | — | none (read only, eager-loads `levels`) | BARS-09 |
| `edit` | 90 | GET `rating-scales/{rating_scale}/edit` | `tenant.behavioural-assessment.rating-scales.update` | — | — | none (read only) | BARS-09 |
| `update` | 108 | PUT/PATCH `rating-scales/{rating_scale}` | `tenant.behavioural-assessment.rating-scales.update` (also FormRequest `authorize()`) | ✅ `DB::transaction` closure | `Updated` (after write, in tx ✅) | `ba_rating_scales`, `ba_rating_levels`, `sys_activity_logs` | BARS-01, BARS-02, BARS-03, BARS-05, BARS-09 |
| `destroy` | 152 | DELETE `rating-scales/{rating_scale}` | `tenant.behavioural-assessment.rating-scales.delete` | ✅ `DB::transaction` closure | `Trashed` (after write, in tx ✅) | `ba_rating_scales`, `sys_activity_logs` | BARS-01, BARS-02, BARS-03, BARS-09 |
| `trashed` | 187 | GET `rating-scales/trash` | `tenant.behavioural-assessment.rating-scales.restore` | — | — | none (read only, `paginate(10)`) | — |
| `restore` | 197 | GET `rating-scales/{id}/restore` | `tenant.behavioural-assessment.rating-scales.restore` | ✅ `DB::transaction` closure | `Restored` (after write, in tx ✅) | `ba_rating_scales`, `sys_activity_logs` | BARS-01, BARS-02, BARS-03, BARS-08, BARS-09 |
| `forceDelete` | 236 | DELETE `rating-scales/{id}/force-delete` | `tenant.behavioural-assessment.rating-scales.forceDelete` | ✅ `DB::transaction` closure | `Deleted` (after write, in tx ✅) | `ba_rating_scales`, `sys_activity_logs` | BARS-01, BARS-02, BARS-03, BARS-09, BARS-15 |
| `toggleStatus` | 268 | POST `rating-scales/{ratingScale}/toggle-status` | `tenant.behavioural-assessment.rating-scales.update` | ✅ `DB::transaction` closure | `Toggled` (after write, in tx ✅) | `ba_rating_scales`, `sys_activity_logs` | BARS-01, BARS-02, BARS-03 |
| `storeLevel` | 304 | POST `rating-scales/{ratingScale}/levels` | `tenant.behavioural-assessment.rating-scales.update` | ✅ `DB::transaction` closure | `Stored` (after write, in tx ✅) | `ba_rating_levels`, `sys_activity_logs` | BARS-01, BARS-02, BARS-03, BARS-04, BARS-06, BARS-11 |
| `updateLevel` | 355 | PUT `rating-scales/{ratingScale}/levels/{level}` | `tenant.behavioural-assessment.rating-scales.update` | ✅ `DB::transaction` closure | `Updated` (after write, in tx ✅) | `ba_rating_levels`, `sys_activity_logs` | BARS-01, BARS-02, BARS-03, BARS-06, BARS-11 |
| `destroyLevel` | 410 | DELETE `rating-scales/{ratingScale}/levels/{level}` | `tenant.behavioural-assessment.rating-scales.update` | ✅ `DB::transaction` closure | `Trashed` (after write, in tx ✅) | `ba_rating_levels`, `sys_activity_logs` | BARS-01, BARS-02, BARS-03, BARS-11 |
| `clearOtherDefaults` (private) | 455 | — (called by `store`/`update`) | — | inside caller's tx ✅ | `Updated` | `ba_rating_scales`, `sys_activity_logs` | BARS-12 |
| `parkLevels` (private) | 506 | — (called by `update`) | — | inside caller's tx ✅ | `Deleted` | `ba_rating_levels`, `sys_activity_logs` | BARS-10, BARS-12 |
| `writeLevels` (private) | 542 | — (called by `store`/`update`) | — | inside caller's tx ✅ | `Updated` | `ba_rating_levels`, `sys_activity_logs` | BARS-10, BARS-12 |

**Tables each mutation SHOULD touch, vs what it does:**
- `store` — one `ba_rating_scales` row, its levels, plus one audit row per write: does exactly those, in one transaction.
- `update` — one `ba_rating_scales` row, each changed/removed/added level, plus audit rows: does exactly those, in one transaction.
- `destroy` — soft-delete the scale (and set `is_active = false`) plus one audit row: does both, in one transaction.
- `restore` — un-delete the scale plus one audit row: does both, in one transaction.
- `forceDelete` — hard-delete the scale plus one audit row: does both, in one transaction.
- `toggleStatus` — flip `is_active` plus one audit row: does both, in one transaction.
- `storeLevel`/`updateLevel`/`destroyLevel` — one `ba_rating_levels` row plus one audit row: does both, in one transaction (but no UI calls them — BARS-11).

## 6. Findings

### F1 — Errors

#### BARS-01 · M · ERR-00 (D1) — nine mutating methods keep a controller `try/catch` that is not a D2 shape

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M by protocol D1) — *the Laravel idiom wins for the final audit: no `try/catch` in a controller unless it is one of the D2 shapes (`\DomainException`, the truncate-rebuild catch, `SnapshotProtectionException`, or `report($e)` in a service)* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:43-79`, methods `store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`, `storeLevel`, `updateLevel`, `destroyLevel` |
| **Root cause** | Every write method wraps its `DB::transaction` in `try { … } catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { … return back()/response() with a fixed message }`. None of these catches is a D2 shape, so D1 forbids them. The `ModelNotFoundException` rethrow (comment "Rule A1") is the only reason a 404 survives; every other `Throwable` is swallowed into a generic redirect or a 500 JSON body. |
| **Consequence** | A failed save is reported to the user as "The operation could not be completed." and the real exception is never logged with its trace, so it cannot be diagnosed from the log. The six "BA: …" trigger messages (served today through `BaTriggerError::message()`) are the only page-specific failure text. |
| **Reproduce** | static only — forcing a `QueryException` that is not a BA trigger (for example a duplicate `uq_ba_level_value` from 5.0 vs 5.00, BARS-07) yields the generic flash rather than a logged trace. |
| **Fix approach** | Migrate to D1: delete the nine `try`/`catch`/`Log::error` wrappers, keep `Gate::authorize()` and `findOrFail()` where they are, keep `DB::transaction(fn () => …)` and let it roll back, and let the central handler in `bootstrap/app.php` render. This is offered as a DECISION because the `BaTriggerError` path needs a strategy. |
| **Plan item** | BARS-01 in `02-fix-plan.md` §3 (DECISION) |

```php
// BaRatingScaleController.php:43-79, method store() — the D2-forbidden shape, repeated in 8 more methods
        try {
            return DB::transaction(function () use ($request) {
                $data = collect($request->validated())->except('levels')->all();

                // BR-BA-028: one default. Unset the others first — uq_ba_scale_default would reject
                // a second default row before this one could be saved.
                if (! empty($data['is_default'])) {
                    $this->clearOtherDefaults(null);
                }

                $record = BaRatingScale::create($data + [
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                $this->writeLevels($record, $request->validated('levels'), collect());

                activityLog($record, 'Stored', ['message' => 'BaRatingScale was stored.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'rating-scales'])
                    ->with('success', 'Rating scale created successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            if ($message = BaTriggerError::message($e)) {
                return back()->withErrors(['levels' => $message])->withInput();
            }

            Log::error('BaRatingScaleController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "try {\|} catch (" Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php
43:        try {
67:        } catch (ModelNotFoundException $e) {
71:        } catch (\Throwable $e) {
112:        try {
137:        } catch (ModelNotFoundException $e) {
141:        } catch (\Throwable $e) {
156:        try {
176:        } catch (ModelNotFoundException $e) {
180:        } catch (\Throwable $e) {
201:        try {
225:        } catch (ModelNotFoundException $e) {
229:        } catch (\Throwable $e) {
240:        try {
257:        } catch (ModelNotFoundException $e) {
261:        } catch (\Throwable $e) {
272:        try {
288:        } catch (ModelNotFoundException $e) {
292:        } catch (\Throwable $e) {
313:        try {
340:        } catch (ModelNotFoundException $e) {
344:        } catch (\Throwable $e) {
370:        try {
395:        } catch (ModelNotFoundException $e) {
399:        } catch (\Throwable $e) {
414:        try {
439:        } catch (ModelNotFoundException $e) {
443:        } catch (\Throwable $e) {
```

#### BARS-02 · M · ERR-05 — every catch logs only `$e->getMessage()`

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:76`, and the same line in the eight other catches at 146, 181, 230, 262, 293, 349, 404, 444 |
| **Root cause** | Each catch calls `Log::error('…', ['error' => $e->getMessage()])`, which stores the message string only; the exception type, stack trace and any previous exception are lost. |
| **Consequence** | A production failure in any of the nine writes leaves a one-line log entry that cannot be traced to the failing query or line. |
| **Reproduce** | static only — the log array has no `exception` or stack key. |
| **Fix approach** | Removing the catches (BARS-01) removes these log calls; if a catch is ever kept it must use `report($e)`. |
| **Plan item** | none — see plan §10 (removed by BARS-01) |

```php
// BaRatingScaleController.php:76, the store() catch — the same idiom at 146, 181, 230, 262, 293, 349, 404, 444
            Log::error('BaRatingScaleController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php
76:            Log::error('BaRatingScaleController::store failed', ['error' => $e->getMessage()]);
146:            Log::error('BaRatingScaleController::update failed', ['error' => $e->getMessage()]);
181:            Log::error('BaRatingScaleController::destroy failed', ['error' => $e->getMessage()]);
230:            Log::error('BaRatingScaleController::restore failed', ['error' => $e->getMessage()]);
262:            Log::error('BaRatingScaleController::forceDelete failed', ['error' => $e->getMessage()]);
293:            Log::error('BaRatingScaleController::toggleStatus failed', ['error' => $e->getMessage()]);
349:            Log::error('BaRatingScaleController::storeLevel failed', ['error' => $e->getMessage()]);
404:            Log::error('BaRatingScaleController::updateLevel failed', ['error' => $e->getMessage()]);
444:            Log::error('BaRatingScaleController::destroyLevel failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### BARS-03 · M · TXN-05 — the HTTP response is built inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build `redirect()` / `response()` after it* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:62-64`, and the same shape at 132, 161, 171, 207, 220, 245, 252, 281, 297, 337, 392, 421, 436 |
| **Root cause** | Each `DB::transaction(function () { … })` ends with `return redirect()…`, `return back()…` or `return response()->json(…)` instead of returning the model or void and building the response after the closure. Guard branches (`destroy:161`, `restore:207`, `forceDelete:245`, `destroyLevel:421`) also `return back()` from inside the transaction. |
| **Consequence** | The success flash or JSON payload is assembled before the commit; the response object exists in memory before the write is durable. No data corruption, but every guard branch holds an open transaction while returning a plain redirect. |
| **Reproduce** | static only — every method's last statement inside the closure is an HTTP response. |
| **Fix approach** | Move the redirect/JSON construction after `DB::transaction(...)`; make the closure return `void` (BARS-01's rewrite does this and also moves the guard branches out). |
| **Plan item** | none — see plan §10 (fixed inside BARS-01) |

```php
// BaRatingScaleController.php:62-64, the store() closure tail — the same shape at the other eight methods
                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'rating-scales'])
                    ->with('success', 'Rating scale created successfully.');
```

**Evidence**
```
$ grep -n "return DB::transaction\|return redirect()\|return back()\|return response()" Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php
44:            return DB::transaction(function () use ($request) {
62:                return redirect()
73:                return back()->withErrors(['levels' => $message])->withInput();
78:            return back()->with('error', 'The operation could not be completed.');
113:            return DB::transaction(function () use ($request, $id) {
132:                return redirect()
143:                return back()->withErrors(['levels' => $message])->withInput();
148:            return back()->with('error', 'The operation could not be completed.');
157:            return DB::transaction(function () use ($id) {
161:                    return back()->with('error', 'This rating scale is used by recorded ratings and cannot be deleted. Deactivate it instead.');
171:                return redirect()
...
```

#### BARS-04 · M · TXN-06 — `storeLevel` reads `max(sort_order)` then inserts with no lock

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M, lowered from H — the `uq_ba_level_order` index turns the race into a failed request, not a duplicate row) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:321-322` |
| **Root cause** | `storeLevel` computes `(int) BaRatingLevel::where('rating_scale_id', $scale->id)->max('sort_order') + 1` and inserts it. The insert is inside the transaction, but the aggregate read is not locked, so two concurrent submits can read the same max. The DB unique index `uq_ba_level_order` catches it, but the resulting `QueryException` is swallowed by the generic catch (BARS-01) into "The operation could not be completed.". |
| **Consequence** | Two admins adding a level to the same scale at the same instant: one gets a generic failure instead of a clear "please retry" — cosmetic, no duplicate row. |
| **Reproduce** | static only — requires two simultaneous `POST /behavioural-assessment/rating-scales/{ratingScale}/levels` requests. |
| **Fix approach** | Add `->lockForUpdate()` to the `max()` read inside the transaction, or retire the endpoint (BARS-11). |
| **Plan item** | none — see plan §10 (moot if BARS-11 retires the endpoint; otherwise lock the read) |

```php
// BaRatingScaleController.php:321-322 — read-max then insert, no lock
                    'sort_order' => $validated['sort_order']
                        ?? ((int) BaRatingLevel::where('rating_scale_id', $scale->id)->max('sort_order') + 1),
```

**Evidence**
```
$ grep -n "max('sort_order')" Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php
322:                        ?? ((int) BaRatingLevel::where('rating_scale_id', $scale->id)->max('sort_order') + 1),
$ grep -n "unique\|uq_ba_level_order" database/migrations/tenant/2026_06_16_130622_create_ba_rating_levels_table.php
38:            $table->unique(['rating_scale_id', 'sort_order', 'uq_guard'], 'uq_ba_level_order');
```

### F3 — Authorization

#### BARS-05 · L · AUTH-04 — `store` and `update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` plus `Gate::authorize`); keep one* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:41` and `:110`, methods `store` and `update`; the duplicate half is `BaRatingScaleRequest::authorize()` at lines 19-25 |
| **Root cause** | The FormRequest runs `authorizeByCrudPermission('tenant.behavioural-assessment.rating-scales')` (POST maps to `create`, PUT/PATCH to `update`), and the controller repeats `Gate::authorize(…create)` / `Gate::authorize(…update)` for the same two keys. |
| **Consequence** | No runtime effect; it is duplication that can drift — if one side's key changes, the other silently keeps the old check. |
| **Reproduce** | static only. |
| **Fix approach** | Keep the FormRequest `authorize()` (it runs first, before validation) and drop the two controller `Gate::authorize` lines. |
| **Plan item** | BARS-05 in `02-fix-plan.md` §4 |

```php
// BaRatingScaleController.php:108-110, method update() — the controller half; store() repeats it at :41
    public function update(BaRatingScaleRequest $request, int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.rating-scales.update');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php
41:        Gate::authorize('tenant.behavioural-assessment.rating-scales.create');
110:        Gate::authorize('tenant.behavioural-assessment.rating-scales.update');
$ sed -n '19,25p' Modules/BehaviouralAssessment/app/Http/Requests/BaRatingScaleRequest.php
    public function authorize(): bool
    {
        // T6b — mirrors the controller's own gate: tenant.behavioural-assessment.rating-scales.create on POST,
        // tenant.behavioural-assessment.rating-scales.update on PUT/PATCH. Same permission, checked one step
        // earlier, so this narrows nothing and widens nothing.
        return $this->authorizeByCrudPermission('tenant.behavioural-assessment.rating-scales');
    }
```

### F4 — Validation and input

#### BARS-06 · M · VAL-02 — `storeLevel`/`updateLevel` validate inline instead of using a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request; inline `$request->validate()` is allowed only for a one-field AJAX toggle* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:311` and `:362` |
| **Root cause** | Both level endpoints call `$request->validate($this->levelRules(…))` in the controller (5 keys including a nested `numeric_value` value object). The one-field toggle exception does not apply, and the scale-level payload is kept in `BaRatingScaleRequest`. |
| **Consequence** | The level contract lives apart from the scale contract, so a future field change can be made in one place and not the other; there is no single class documenting the `ba_rating_levels` input rules. |
| **Reproduce** | static only. |
| **Fix approach** | Add a `BaRatingLevelRequest` carrying the `levelRules()` array and take it as the method argument, or retire the endpoints (BARS-11). |
| **Plan item** | none — see plan §10 (lives only in the endpoints BARS-11 retires) |

```php
// BaRatingScaleController.php:311, method storeLevel() — updateLevel() repeats it at :362
        $validated = $request->validate($this->levelRules($scale));
```

**Evidence**
```
$ grep -n "validate(" Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php
311:        $validated = $request->validate($this->levelRules($scale));
362:        $validated = $request->validate($this->levelRules($scale, $levelRecord->id));
```

#### BARS-07 · L · VAL-04 — the `distinct` rule on `numeric_value` can pass a pair the DB unique index rejects

| Field | Value |
|---|---|
| **Rule** | VAL-04 (L, lowered from H — the form uses `step="0.01"` number inputs, so this is an edge case) — *uniqueness rules mirror the DB unique index, including the stored value's precision* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Requests/BaRatingScaleRequest.php:46-48` (and the same `numeric_value` rule rebuilt in `levelRules()` at controller:486) |
| **Root cause** | `levels.*.numeric_value` is validated with `'distinct'`, which compares the submitted strings ("5.0" and "5.00" are distinct), but the column is `decimal(4,2)` and `uq_ba_level_value` is `(rating_scale_id, numeric_value, uq_guard)` — both store as 5.00, so the DB rejects the pair. The rejection is a plain `QueryException`, so `BaTriggerError::message()` returns null and the user sees the generic "The operation could not be completed." instead of a validation message. |
| **Consequence** | An admin who types 5.0 and 5.00 as two level values sees a generic failure rather than "Two levels have the same value.", with no indication which row is at fault. |
| **Reproduce** | static only — submit a scale with levels `numeric_value` "5.00" and "5.0". |
| **Fix approach** | Normalise `levels.*.numeric_value` to two decimals in `prepareForValidation()`, so `distinct` compares the value as stored. |
| **Plan item** | BARS-07 in `02-fix-plan.md` §5 |

```php
// BaRatingScaleRequest.php:46-48 — `distinct` compares the raw strings, the DB compares decimal(4,2)
            'levels.*.label'         => ['required', 'string', 'max:50', 'distinct:ignore_case'],
            // BR-BA-027: a level value lies within [min_rating, max_rating] (trg_ba_level_range_* is the backstop).
            'levels.*.numeric_value' => ['required', 'numeric', 'decimal:0,2', 'distinct', 'gte:min_rating', 'lte:max_rating'],
```

**Evidence**
```
$ grep -n "numeric_value" database/migrations/tenant/2026_06_16_130622_create_ba_rating_levels_table.php
27:            $table->decimal('numeric_value', 4, 2)->comment('Must fall inside the parent scale range');
40:            $table->unique(['rating_scale_id', 'numeric_value', 'uq_guard'], 'uq_ba_level_value');
$ sed -n '44,48p' Modules/BehaviouralAssessment/app/Http/Requests/BaRatingScaleRequest.php
            'levels'                 => ['required', 'array', 'min:1', 'max:20'],
            'levels.*.id'            => ['nullable', 'integer', Rule::exists('ba_rating_levels', 'id')->where('rating_scale_id', $id ?? 0)->whereNull('deleted_at')],
            'levels.*.label'         => ['required', 'string', 'max:50', 'distinct:ignore_case'],
            // BR-BA-027: a level value lies within [min_rating, max_rating] (trg_ba_level_range_* is the backstop).
            'levels.*.numeric_value' => ['required', 'numeric', 'decimal:0,2', 'distinct', 'gte:min_rating', 'lte:max_rating'],
```

### F5 — Routes

#### BARS-08 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …): GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/BehaviouralAssessment/routes/web.php:28` (route) and `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:197` (method `restore`) |
| **Root cause** | `Route::get('rating-scales/{id}/restore', …)` runs a write (sets `updated_by`, calls `restore()`, writes `sys_activity_logs`) behind a GET. |
| **Consequence** | A link prefetcher, a crawler or a plain browser hit on `/behavioural-assessment/rating-scales/{id}/restore` un-trashes a rating scale with no CSRF token; the trash page's confirm dialog gives false confidence. |
| **Reproduce** | Open `/behavioural-assessment/rating-scales/{id}/restore` for a trashed id in a plain browser tab — the row is restored. |
| **Fix approach** | Change the route verb to POST; the shared `action-trashed` component already emits `@csrf` and a POST form whenever the route is not GET, so only the route line changes. |
| **Plan item** | BARS-08 in `02-fix-plan.md` §1 (⚠ SHARED — route file) |

```php
// routes/web.php:28
Route::get('rating-scales/{id}/restore', [BaRatingScaleController::class, 'restore'])->name('rating-scales.restore');
```

**Evidence**
```
$ grep -n "rating-scales/{id}/restore" Modules/BehaviouralAssessment/routes/web.php
28:Route::get('rating-scales/{id}/restore', [BaRatingScaleController::class, 'restore'])->name('rating-scales.restore');
$ sed -n '29,31p' resources/views/components/backend/table/action-trashed.blade.php
    <form action="{{ route($restoreRouteName, $restoreParams) }}"
          method="{{ $restoreMethod === 'GET' ? 'GET' : 'POST' }}"
          class="d-inline confirm-action-form-restore">
```

### F6 — Controller shape

#### BARS-09 · M · CTL-03 — no route-model binding; `show`/`edit`/`update`/`destroy` load by `$id` with `findOrFail()`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`, `withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:85,93,114,158` |
| **Root cause** | `show`/`edit` take `int $id`, and `update`/`destroy` take `int $id`, then call `findOrFail($id)`; the routes already carry `{rating_scale}`, so implicit binding is available and the manual load is redundant. The parameter name also differs from the route segment (`$id` vs `{rating_scale}`), which is why the load is manual. |
| **Consequence** | No user-visible defect today — the explicit `findOrFail()` is correct — so the cost is boilerplate and one more place to remember `->withTrashed()` if the parameter is ever rebound. |
| **Reproduce** | static only. |
| **Fix approach** | Bind the models: rename the `{rating_scale}` resource arguments to `BaRatingScale $ratingScale` for `show`/`edit`/`update`/`destroy`. This touches the route parameter name, so it is offered as a DECISION. |
| **Plan item** | BARS-09 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// BaRatingScaleController.php:108-114, method update() — the shape repeated by show/edit/destroy
    public function update(BaRatingScaleRequest $request, int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.rating-scales.update');

        try {
            return DB::transaction(function () use ($request, $id) {
                $ratingScale = BaRatingScale::findOrFail($id);
                $data = collect($request->validated())->except('levels')->all();
```

**Evidence**
```
$ grep -n "findOrFail" Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php
85:        $ratingScale = BaRatingScale::with(['levels' => fn ($q) => $q->orderBy('sort_order')])->findOrFail($id);
93:        $ratingScale = BaRatingScale::with(['levels' => fn ($q) => $q->orderBy('sort_order')])->findOrFail($id);
114:                $ratingScale = BaRatingScale::findOrFail($id);
158:                $ratingScale = BaRatingScale::findOrFail($id);
203:                $ratingScale = BaRatingScale::onlyTrashed()->findOrFail($id);
242:                $ratingScale = BaRatingScale::withTrashed()->findOrFail($id);
274:                $scale = BaRatingScale::findOrFail($ratingScale);
308:        $scale = BaRatingScale::findOrFail($ratingScale);
359:        $scale = BaRatingScale::findOrFail($ratingScale);
360:        $levelRecord = BaRatingLevel::where('rating_scale_id', $scale->id)->findOrFail($level);
416:                $levelRecord = BaRatingLevel::where('rating_scale_id', $ratingScale)->findOrFail($level);
```

#### BARS-10 · M · CTL-06 — the level-sync algorithm lives in the controller, not a service

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in services/actions; a controller method reads input, calls one service, returns a response* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:455-583` (`clearOtherDefaults`, `levelRules`, `parkLevels`, `writeLevels`) |
| **Root cause** | About 130 lines of the controller implement the "one default scale" rule and the two-step level sync (park kept rows out of the three unique keys, then rewrite them in form order), including a microsecond-stamp trick that mirrors `uq_guard`. That is domain logic, not request handling. |
| **Consequence** | The rule for writing levels is inseparable from the two HTTP methods that call it; a second caller (the unused level endpoints already exist) cannot reuse it without copying, and the logic is untestable without going through the controller. |
| **Reproduce** | static only. |
| **Fix approach** | Extract a `BaRatingScaleWriter` service taking validated data and returning the scale; the controller calls it once. Splitting is DEFERRED per D3, so this is a DECISION. |
| **Plan item** | BARS-10 in `02-fix-plan.md` §9 (DECISION) |

```php
// BaRatingScaleController.php:506-518 — parkLevels(), domain logic that belongs in a service
    private function parkLevels(BaRatingScale $scale, array $rows): \Illuminate\Support\Collection
    {
        $existing = BaRatingLevel::where('rating_scale_id', $scale->id)->get()->keyBy('id');
        $keptIds = collect($rows)->pluck('id')->filter()->map(fn ($v) => (int) $v)->all();

        foreach ($existing->except($keptIds) as $removed) {
            $removed->forceDelete();
            activityLog($removed, 'Deleted', [
                'message' => 'Rating level was removed.',
                'rating_scale_id' => $scale->id,
                'label' => $removed->label,
            ]);
        }
```

**Evidence**
```
$ grep -n "private function" Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php
455:    private function clearOtherDefaults(?int $exceptId): void
473:    private function levelRules(BaRatingScale $scale, ?int $ignoreId = null): array
506:    private function parkLevels(BaRatingScale $scale, array $rows): \Illuminate\Support\Collection
542:    private function writeLevels(BaRatingScale $scale, array $rows, \Illuminate\Support\Collection $kept): void
$ sed -n '455,583p' Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php | wc -l
129
```

#### BARS-11 · M · CTL-10 — `storeLevel`, `updateLevel`, `destroyLevel` are routed but have no caller anywhere in the app

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) / deep-read #8 — *no dead code; a screen whose saved data no consumer reads* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:304-448` (the three methods) and `Modules/BehaviouralAssessment/routes/web.php:31,32,34` |
| **Root cause** | The create/edit form (`_form.blade.php` and `_create-fields.blade.php`) saves every level in one submit through `store`/`update`, whose `parkLevels`/`writeLevels` do the work. Nothing in the module's views, JS or any other module references `rating-scales.levels.store`, `…levels.update` or `…levels.destroy`; the three endpoints are a second, divergent implementation of level mutation (they soft-delete, while `parkLevels` hard-deletes). |
| **Consequence** | Roughly 145 lines of unreachable mutating code stay attached to live routes: an authorized user who hits the URLs changes levels through a code path that disagrees with the screen, and every future level-rule change must be made twice. |
| **Reproduce** | static only — `grep -rn "rating-scales.levels" Modules app resources public routes config` returns only `routes/web.php`. |
| **Fix approach** | Retire the three endpoints: remove the three route lines and reduce each method body to `abort(403, '…')` with a `// NOT ROUTED` comment (D5), or wire a per-level UI and keep them. Offered as a DECISION (route file is ⚠ SHARED). |
| **Plan item** | BARS-11 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// BaRatingScaleController.php:304-311 — storeLevel(), one of the three unreferenced methods
    public function storeLevel(Request $request, int $ratingScale): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.rating-scales.update');

        $scale = BaRatingScale::findOrFail($ratingScale);

        // Validated OUTSIDE the try: the generic catch below used to swallow the ValidationException.
        $validated = $request->validate($this->levelRules($scale));
```

**Evidence**
```
$ grep -rn --include=*.php --include=*.blade.php --include=*.js "rating-scales.levels" Modules app resources public routes config
Modules/BehaviouralAssessment/routes/web.php:31:Route::put('rating-scales/{ratingScale}/levels/{level}', ...)->name('rating-scales.levels.update');
Modules/BehaviouralAssessment/routes/web.php:32:Route::delete('rating-scales/{ratingScale}/levels/{level}', ...)->name('rating-scales.levels.destroy');
Modules/BehaviouralAssessment/routes/web.php:34:Route::post('rating-scales/{ratingScale}/levels', ...)->name('rating-scales.levels.store');
```

### F7 — Models

**clean** — `Modules/BehaviouralAssessment/app/Models/BaRatingScale.php` and `.../BaRatingLevel.php` each declare `$table` (both tables exist — see the migrations below), a `$fillable` list holding nothing sensitive (`is_default_flag` and `uq_guard` are STORED generated columns and deliberately not fillable), a `$casts` entry for every boolean/date/decimal/integer column, `SoftDeletes` matching the `deleted_at` column, and return-typed relations (`levels(): HasMany`, `configs(): HasMany`, `classScales(): HasMany` / `scale(): BelongsTo`, `ratings(): HasMany`). No Spatie `InteractsWithMedia`, so MDL-05/TEN-01 do not apply. Proof: `grep -n -e 'SoftDeletes' -e '\$table' -e '\$fillable' -e '\$casts' Modules/BehaviouralAssessment/app/Models/BaRatingScale.php Modules/BehaviouralAssessment/app/Models/BaRatingLevel.php`; `ls database/migrations/tenant/2026_06_16_130616_create_ba_rating_scales_table.php database/migrations/tenant/2026_06_16_130622_create_ba_rating_levels_table.php`.

### F8 — Services and jobs

**clean** — the controller names no service, job, event, mail, notification, export or import. Proof: `grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b' Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php` returns only `BaRatingScaleRequest`. The two helpers reached are `BaActor` (linked) and `BaTriggerError` (linked); the framework-side `activityLog()` lives in `app/Helpers/activityLog.php` (common).

### F9 — Queries and performance

#### BARS-12 · L · QRY-07 — three private helpers write one row at a time inside a loop

| Field | Value |
|---|---|
| **Rule** | QRY-07 (L, lowered from M — every loop is bounded to at most one other default / 20 levels, and each row needs its own audit entry) — *bulk writes: `insert()`, `upsert()`, `whereIn(...)->update()` instead of `create()`/`update()` per row in a loop* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:457-463` (`clearOtherDefaults`), `:508-518` (`parkLevels`), `:544-580` (`writeLevels`) |
| **Root cause** | `clearOtherDefaults` runs `->get()->each(fn … ->update(…))`; `parkLevels` runs `->forceDelete()` plus `activityLog()` per removed row; `writeLevels` runs `$level->save()`/`BaRatingLevel::create()` per submitted row. Each is one statement per row instead of a bulk write. |
| **Consequence** | At most ~21 statements per save where a handful would do; each holds the transaction open for the extra round-trips. Bounded by the form's 20-level limit, so the cost is small. |
| **Reproduce** | static only. |
| **Fix approach** | Accept (each row carries its own `activityLog()` with row-specific old/new values, which a bulk write cannot produce), or bulk the level writes and insert the audit rows in one batch. |
| **Plan item** | none — see plan §10 (accepted) |

```php
// BaRatingScaleController.php:457-463 — clearOtherDefaults(); one UPDATE per default row
        BaRatingScale::where('is_default', true)
            ->when($exceptId, fn ($q) => $q->whereKeyNot($exceptId))
            ->get()
            ->each(function (BaRatingScale $other) {
                $other->update(['is_default' => false, 'updated_by' => BaActor::id()]);
                activityLog($other, 'Updated', ['message' => 'Rating scale is no longer the default.']);
            });
```

**Evidence**
```
$ grep -n -e "->update(\[" -e "->forceDelete()" -e "->save();" -e "BaRatingLevel::create(" Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php
461:                $other->update(['is_default' => false, 'updated_by' => BaActor::id()]);
512:            $removed->forceDelete();
560:                $level->save();
574:                BaRatingLevel::create($data + [
```

### F10 — Views

**clean** — none of the five in-scope blades (`create`, `edit`, `show`, `trash`, `_form`) runs a query, dumps a whole model, or uses `{!! !!}`. Relations used inside `@foreach` are eager-loaded: `show`/`edit` load with `->with(['levels' => fn ($q) => $q->orderBy('sort_order')])` and the tab list receives `levels_count` from `BaDashboardController::masters()`. Row actions use `x-backend.table.action` and trash rows use `x-backend.table.action-trashed` with the exact permission props. Proof: `grep -n -e 'Model::' -e 'DB::' -e '->get()' -e '->count()' -e 'where(' -e '{!!' Modules/BehaviouralAssessment/resources/views/rating-scale/create.blade.php Modules/BehaviouralAssessment/resources/views/rating-scale/edit.blade.php Modules/BehaviouralAssessment/resources/views/rating-scale/show.blade.php Modules/BehaviouralAssessment/resources/views/rating-scale/trash.blade.php Modules/BehaviouralAssessment/resources/views/rating-scale/_form.blade.php` returns NO MATCHES. Breadcrumb is `<x-backend.components.breadcrum title="Rating Scales" :links="[]" />` — title-only, consistent with the sibling comment-bank blades; no config read.

### F11 — Security and tenancy

**clean** — no `env()` in the controller, FormRequest or the two models (`grep -n "env(" …` returns NO MATCHES); no request body, password or token is logged (the only `Log::` calls are the BARS-02 messages); no hard-coded tenant/user id; `BaRatingLevel::$gradeCache` is keyed by `getConnection()->getDatabaseName().':'.$ratingScaleId`, so the memoised grade list cannot leak across tenants (TEN-02). Every route carries the full tenancy middleware group (see §4). `BaTriggerError::message()` surfaces only our own trigger text (SQLSTATE `45000` and a `BA: ` prefix), not SQL or column names, so ERR-01 does not apply.

### F12 — Style

#### BARS-13 · L · STY-02 — three in-scope PHP files are not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:506`, `Modules/BehaviouralAssessment/app/Models/BaRatingScale.php:7-10`, `Modules/BehaviouralAssessment/app/Http/Requests/BaRatingScaleRequest.php:32-75` |
| **Root cause** | `vendor/bin/pint --test` reports fixers on all three: the controller has an inline FQCN (`\Illuminate\Support\Collection`) that should be imported plus `fully_qualified_strict_types`/`ordered_imports`; the model has unsorted imports; the FormRequest aligns `=>` with extra spaces (`binary_operator_spaces`). |
| **Consequence** | No runtime effect; the files drift from the project's enforced style, so a later `pint` run shows unrelated diffs. |
| **Reproduce** | static only — run `vendor/bin/pint --test` on the three files. |
| **Fix approach** | Run `vendor/bin/pint` on the three files (it also removes the unused `ModelNotFoundException`/`Log` imports after BARS-01). |
| **Plan item** | BARS-13 in `02-fix-plan.md` §8 |

```php
// BaRatingScaleController.php:506 — the FQCN Pint wants imported
    private function parkLevels(BaRatingScale $scale, array $rows): \Illuminate\Support\Collection
```

**Evidence**
```
$ vendor/bin/pint --test --format json Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php Modules/BehaviouralAssessment/app/Models/BaRatingScale.php Modules/BehaviouralAssessment/app/Models/BaRatingLevel.php Modules/BehaviouralAssessment/app/Http/Requests/BaRatingScaleRequest.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Http\/Controllers\/BaRatingScaleController.php","fixers":["fully_qualified_strict_types","unary_operator_spaces","not_operator_with_successor_space","ordered_imports"]},{"path":"Modules\/BehaviouralAssessment\/app\/Models\/BaRatingScale.php","fixers":["ordered_imports"]},{"path":"Modules\/BehaviouralAssessment\/app\/Http\/Requests\/BaRatingScaleRequest.php","fixers":["unary_operator_spaces","not_operator_with_successor_space","binary_operator_spaces"]}]}
```

#### BARS-14 · L · STY-04 — `_form.blade.php` documents a `syncLevels()` method that does not exist

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *no copy-pasted docblocks that describe another resource or a method that is gone* |
| **Where** | `Modules/BehaviouralAssessment/resources/views/rating-scale/_form.blade.php:3` |
| **Root cause** | The header docblock says "BaRatingScaleController::syncLevels() updates rows that carry levels[N][id], creates the rest, and removes the scale's levels missing from the post". The controller has no `syncLevels()` method; the work is done by `parkLevels()` + `writeLevels()` (and the same stale text is copied into `_create-fields.blade.php:10`). |
| **Consequence** | A developer following the comment greps for a method that does not exist, then has to reconstruct the real flow from the body. |
| **Reproduce** | static only. |
| **Fix approach** | Point the comment at the real methods. |
| **Plan item** | BARS-14 in `02-fix-plan.md` §8 |

```php
// _form.blade.php:3 — the stale reference
    BaRatingScaleController::syncLevels() updates rows that carry levels[N][id], creates the rest,
```

**Evidence**
```
$ grep -rn "syncLevels" Modules/BehaviouralAssessment/app Modules/BehaviouralAssessment/resources
Modules/BehaviouralAssessment/resources/views/rating-scale/_form.blade.php:3:    BaRatingScaleController::syncLevels() updates rows that carry levels[N][id], creates the rest,
Modules/BehaviouralAssessment/resources/views/rating-scale/_create-fields.blade.php:10:    BaRatingScaleController::syncLevels() writes levels[0..n-1] in row order.
```

### F13 — Deep read (answer all 8 questions for every mutating method)

#### BARS-15 · M · deep-read #1 — `forceDelete` permanently deletes a live row (no trashed check)

| Field | Value |
|---|---|
| **Rule** | deep-read #1 (M) — *does any write delete data it should not? `forceDelete` is reachable for a live row, not only a trashed one* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:236-248` |
| **Root cause** | `BaRatingScale::withTrashed()->findOrFail($id)` loads live or trashed and the only guard is `scaleIsLocked()`. A `DELETE /behavioural-assessment/rating-scales/{id}/force-delete` with a live, unlocked id hard-deletes it; `fk_ba_level_scale` (`ON DELETE CASCADE`) then hard-deletes its levels. The trash UI only offers the action for trashed rows, but the route has no such precondition. |
| **Consequence** | An admin holding `.forceDelete` who hits the URL with a live id — or a stale trash page after a restore — irreversibly deletes a scale and its levels, bypassing the two-step trash safety net. Ratings are protected by `scaleIsLocked()`, and scales referenced by `ba_config`/`ba_class_scale_jnt` are protected by their `restrictOnDelete` FKs, so the loss is limited to an unused scale. |
| **Reproduce** | static only — needs the URL directly; the trash page cannot produce it for a live row. |
| **Fix approach** | Refuse unless `$ratingScale->trashed()`. |
| **Plan item** | BARS-15 in `02-fix-plan.md` §5 |

```php
// BaRatingScaleController.php:240-248
        try {
            return DB::transaction(function () use ($id) {
                $ratingScale = BaRatingScale::withTrashed()->findOrFail($id);

                if (BaRatingScaleRequest::scaleIsLocked($ratingScale)) {
                    return back()->with('error', 'This rating scale is used by recorded ratings and cannot be permanently deleted.');
                }

                $ratingScale->forceDelete();
```

**Evidence**
```
$ sed -n '236,248p' Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php
    public function forceDelete(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.rating-scales.forceDelete');

        try {
            return DB::transaction(function () use ($id) {
                $ratingScale = BaRatingScale::withTrashed()->findOrFail($id);

                if (BaRatingScaleRequest::scaleIsLocked($ratingScale)) {
                    return back()->with('error', 'This rating scale is used by recorded ratings and cannot be permanently deleted.');
                }

                $ratingScale->forceDelete();
$ grep -n "cascadeOnDelete\|restrictOnDelete" database/migrations/tenant/2026_06_16_130622_create_ba_rating_levels_table.php
43:            $table->foreign('rating_scale_id', 'fk_ba_level_scale')->references('id')->on('ba_rating_scales')->cascadeOnDelete();
```

**F13 answers — one row per mutating method, eight columns (the eight deep-read questions).**

| Method | Q1 wrong data | Q2 delete-before-store | Q3 duplicate impl | Q4 soft-delete×unique | Q5 race | Q6 auth hole | Q7 lying message | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok | BARS-04 | ok | ok | ok |
| `update` | ok | ok | ok | ok | ok | ok | ok | BARS-11 |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | BARS-15 | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |
| `storeLevel` | ok | ok | BARS-11 | ok | BARS-04 | ok | ok | BARS-11 |
| `updateLevel` | ok | ok | BARS-11 | ok | ok | ok | ok | BARS-11 |
| `destroyLevel` | ok | ok | BARS-11 | ok | ok | ok | ok | BARS-11 |

Notes on the cells: **Q4** — `store`/`update`/`restore` all match the partial unique indexes: `BaRatingScaleRequest` uses `whereNull('deleted_at')` for `code`, `parkLevels` soft-deletes kept rows out of `uq_ba_level_{label,value,order}` before rewriting them, and `restore` re-checks for a live duplicate `code` before `restore()`. **Q3** — the per-level endpoints duplicate the repeater sync (`writeLevels`) and disagree (soft-delete vs hard-delete): BARS-11. **Q7** — the only user messages are fixed strings and the `BaTriggerError` business messages; none claims a write that did not happen. **Q1** — `clearOtherDefaults`/`parkLevels` run before the scale row is saved, so the DB unique index `uq_ba_scale_default` cannot fire mid-update.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | Surfaces DB trigger text (SQLSTATE `45000`, `BA: ` prefix) to the user. It is our own fixed text, not SQL, so it is safe; it is the module-wide business-message mechanism and is owned by the BaBehaviourPointController report. | ERR-01 (informational) | BaBehaviourPointController report (linked) |
| `app/Traits/AuthorizesTenantFeature.php` | Its `authorizeByCrudPermission()` maps POST to `create` and PUT/PATCH to `update`; a controller that *also* calls `Gate::authorize()` duplicates the check (this is BARS-05). The trait itself is correct — the duplication is the caller's. | AUTH-04 | platform owners (informational) |
| `resources/views/components/backend/table/action-trashed.blade.php` | Reads the restore route's verb at render time (`$restoreRoute?->methods()`), so a GET restore renders as a GET form. Correct as written; it adapts automatically when BARS-08 changes the verb. | RTE-01 | no change needed |
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php::masters()` | Supplies `$ratingScales` (with `levels_count`) and renders the tab list + create modal that post to this controller. Already paginates at 10 and eager-loads the level count; no defect attributable to this controller's scope. | — | BaDashboardController report (when written) |
| `Modules/BehaviouralAssessment/resources/views/rating-scale/_create-fields.blade.php` | The effective create form (rendered by the Masters page modal). It also carries the stale `syncLevels()` docblock at line 10 (BARS-14 covers `_form.blade.php` only). Not rendered by any method of this controller, so it was referenced, not audited. | STY-04 | BaDashboardController report (when written) |

## 8. Not covered, and why

- **No queue jobs, listeners, commands, events, mail or notifications** are named by this controller, so F8's job/tenant-context checks have nothing in scope.
- **`BaActor` and `BaTriggerError`** are shared Support classes owned by other reports (`BaCommentBankController`, `BaBehaviourPointController`) and were linked, not re-audited. Their behaviour was read only to judge how this controller uses them.
- **The Masters tab views** (`_rating-scales.blade.php`, `_rating-scales-create-modal.blade.php`, `_create-fields.blade.php`) are rendered by `BaDashboardController::masters()`, not by this controller; they were referenced to prove BARS-11 (no per-level-endpoint caller) and are left to that report.
- **The `Db_`/`glb_menus` seeding and the tenant `sys_permissions` rows** were read only to confirm the seven permission keys exist and who holds them (`School Admin=7`, `Super Admin=7`); the seeder's exact-name queries were not audited.
- **No browser or test execution** (D4). Every finding is static/code-read evidence; BARS-04's race, BARS-08's prefetcher path and BARS-15's direct-URL path are not exercised.
- **BARS-01, BARS-09, BARS-10 and BARS-11 are DECISION items** and were not applied, so the current A1 try/catch idiom and the dead endpoints are the measured baseline.
