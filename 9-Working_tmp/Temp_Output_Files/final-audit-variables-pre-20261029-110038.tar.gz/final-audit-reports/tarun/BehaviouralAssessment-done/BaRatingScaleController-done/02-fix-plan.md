# Fix Plan — BehaviouralAssessment / BaRatingScaleController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `database/migrations/tenant/2026_06_16_130616_create_ba_rating_scales_table.php` | migration — never edit an existing migration |
| `database/migrations/tenant/2026_06_16_130622_create_ba_rating_levels_table.php` | migration — never edit an existing migration |
| `Modules/BehaviouralAssessment/app/Support/BaActor.php` | owned by the BaCommentBankController report |
| `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | owned by the BaBehaviourPointController report |
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php` | not audited by this report |
| `Modules/BehaviouralAssessment/resources/views/rating-scale/_create-fields.blade.php` | rendered by the Masters page, not by this controller (BARS-14 names `_form.blade.php` only) |
| `resources/views/components/backend/**` | shared components and layout |
| `config/permissionslist.php` | shared permission registry (no new key is proposed) |

## 1. Blockers reachable today

- [ ] **BARS-08** · H · RTE-01 · `Modules/BehaviouralAssessment/routes/web.php:28` — change the `restore` route from GET to POST so a state change is not reachable over GET. ⚠ SHARED — route file.
  - **Touches:** `Modules/BehaviouralAssessment/routes/web.php`
  - **Before** (`routes/web.php:28`):
    ```php
    Route::get('rating-scales/{id}/restore', [BaRatingScaleController::class, 'restore'])->name('rating-scales.restore');
    ```
  - **After:**
    ```php
    Route::post('rating-scales/{id}/restore', [BaRatingScaleController::class, 'restore'])->name('rating-scales.restore');
    ```
  - **Verify:** `grep -n "rating-scales/{id}/restore" Modules/BehaviouralAssessment/routes/web.php`
  - **Expect:** the line begins with `Route::post(`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

- none.

## 3. Errors & transactions (F1/F2)

- [ ] **BARS-01** · M · DECISION · ERR-00 (D1) — migrate the nine controller `try/catch` wrappers to the Laravel idiom?
  - **Why it is a decision:** the fix changes error behaviour (a DB failure that is not a `BA: ` trigger becomes the central 500 page instead of a generic flash) and the shared `BaTriggerError` business-message path needs a strategy.
  - (a) ⭐ **Migrate to D1.** Delete the `try`/`catch (ModelNotFoundException $e)`/`catch (\Throwable $e)`/`Log::error` blocks from `store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`, `storeLevel`, `updateLevel` and `destroyLevel`. Keep every `Gate::authorize()`, `findOrFail()`, `DB::transaction(fn () => …)`, `activityLog()` and flash literal. Build the redirect (or the `toggleStatus` JSON) after the transaction closure returns. Remove the now-unused `Illuminate\Database\Eloquent\ModelNotFoundException` and `Illuminate\Support\Facades\Log` imports. The FormRequest `after()` hooks and `levelRules()` already block the conditions the triggers back-stop, so only the rare `BA: ` rejection loses its page-specific text.
  - (b) Keep the current House-rule-A1 idiom and record it as an accepted deviation from D1; per D2 each of the nine catches needs a comment naming ERR-01 and the date.
  - (c) Full D2 conversion: add a `\DomainException`-throwing path (a new service, or a change to the shared `BaTriggerError`) so `BA: ` rejections still surface, then reduce each controller catch to `catch (\DomainException $e)`.
  - ➜ Choice: ____

## 4. Authorization (F3)

- [ ] **BARS-05** · L · AUTH-04 · `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:41,110` — drop the duplicate `Gate::authorize` from `store` and `update`; the FormRequest already authorizes the same permission.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php`
  - **Before** (`BaRatingScaleController.php:39-41`):
    ```php
    public function store(BaRatingScaleRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.rating-scales.create');
    ```
  - **After:**
    ```php
    public function store(BaRatingScaleRequest $request): RedirectResponse
    {
    ```
  - **Before** (`BaRatingScaleController.php:108-110`):
    ```php
    public function update(BaRatingScaleRequest $request, int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.rating-scales.update');
    ```
  - **After:**
    ```php
    public function update(BaRatingScaleRequest $request, int $id): RedirectResponse
    {
    ```
  - **Verify:** `grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php`
  - **Expect:** no line containing `rating-scales.create')` or `rating-scales.update')` from the `store`/`update` method heads.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **BARS-07** · L · VAL-04 · `Modules/BehaviouralAssessment/app/Http/Requests/BaRatingScaleRequest.php:147-152` — normalise `levels.*.numeric_value` to two decimals so `distinct` compares the value as stored.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Requests/BaRatingScaleRequest.php`
  - **Before** (`BaRatingScaleRequest.php:147-152`):
    ```php
            'levels'     => array_map(
                fn ($row) => is_array($row) && isset($row['grade_label'])
                    ? ['grade_label' => trim((string) $row['grade_label'])] + $row
                    : $row,
                array_values((array) $this->input('levels', [])),
            ),
    ```
  - **After:**
    ```php
            'levels'     => array_map(
                function ($row) {
                    if (! is_array($row)) {
                        return $row;
                    }
                    if (isset($row['numeric_value']) && is_numeric($row['numeric_value'])) {
                        // decimal(4,2) stores 5, 5.0 and 5.00 as one value; without this the `distinct`
                        // rule passes a pair that uq_ba_level_value then rejects (BARS-07).
                        $row['numeric_value'] = number_format((float) $row['numeric_value'], 2, '.', '');
                    }
                    if (isset($row['grade_label'])) {
                        $row = ['grade_label' => trim((string) $row['grade_label'])] + $row;
                    }

                    return $row;
                },
                array_values((array) $this->input('levels', [])),
            ),
    ```
  - **Verify:** `sed -n '147,164p' Modules/BehaviouralAssessment/app/Http/Requests/BaRatingScaleRequest.php`
  - **Expect:** the closure contains `number_format((float) $row['numeric_value'], 2, '.', '')`.
  - **Effort:** S

- [ ] **BARS-15** · M · deep-read #1 · `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php:242-245` — refuse a permanent delete unless the scale is already trashed.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php`
  - **Before** (`BaRatingScaleController.php:242-245`):
    ```php
                $ratingScale = BaRatingScale::withTrashed()->findOrFail($id);

                if (BaRatingScaleRequest::scaleIsLocked($ratingScale)) {
                    return back()->with('error', 'This rating scale is used by recorded ratings and cannot be permanently deleted.');
                }
    ```
  - **After:**
    ```php
                $ratingScale = BaRatingScale::withTrashed()->findOrFail($id);

                // Force-delete is a trash-only action: a live row must be trashed first (BARS-15).
                if (! $ratingScale->trashed()) {
                    return back()->with('error', 'Move the rating scale to trash before deleting it permanently.');
                }

                if (BaRatingScaleRequest::scaleIsLocked($ratingScale)) {
                    return back()->with('error', 'This rating scale is used by recorded ratings and cannot be permanently deleted.');
                }
    ```
  - **Verify:** `grep -n "trashed()" Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php`
  - **Expect:** a `! $ratingScale->trashed()` guard in `forceDelete`.
  - **Effort:** S

## 6. Queries & performance (F9)

- none. BARS-12 is accepted (see §10).

## 7. Views (F10)

- none.

## 8. Style (F12) — one item per file

- [ ] **BARS-13** · L · STY-02 · `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php`, `.../app/Models/BaRatingScale.php`, `.../app/Http/Requests/BaRatingScaleRequest.php` — run Pint on the three files.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php`, `Modules/BehaviouralAssessment/app/Models/BaRatingScale.php`, `Modules/BehaviouralAssessment/app/Http/Requests/BaRatingScaleRequest.php`
  - **Before** (`BaRatingScale.php:7-10`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Support\Collection;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **After:** (`BaRatingScale.php:7-10`, import order fixed; the controller's inline `\Illuminate\Support\Collection` becomes an import and the FormRequest's `=>` alignment is fixed by the same command):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Collection;
    ```
  - **Verify:** `vendor/bin/pint --test --format json Modules/BehaviouralAssessment/app/Http/Controllers/BaRatingScaleController.php Modules/BehaviouralAssessment/app/Models/BaRatingScale.php Modules/BehaviouralAssessment/app/Http/Requests/BaRatingScaleRequest.php`
  - **Expect:** `{"tool":"pint","result":"passed"}` for all three files.
  - **Effort:** S

- [ ] **BARS-14** · L · STY-04 · `Modules/BehaviouralAssessment/resources/views/rating-scale/_form.blade.php:2-4` — point the header docblock at the real methods.
  - **Touches:** `Modules/BehaviouralAssessment/resources/views/rating-scale/_form.blade.php`
  - **Before** (`_form.blade.php:2-4`):
    ```php
    Shared by create + edit. The scale and ALL its levels are saved in one submit:
    BaRatingScaleController::syncLevels() updates rows that carry levels[N][id], creates the rest,
    and removes the scale's levels missing from the post. Row order on screen = sort_order.
    ```
  - **After:**
    ```php
    Shared by create + edit. The scale and ALL its levels are saved in one submit:
    BaRatingScaleController::update() parks the kept levels (parkLevels()) and writes every
    submitted row in form order (writeLevels()), removing the levels missing from the post.
    Row order on screen = sort_order.
    ```
  - **Verify:** `grep -rn "syncLevels" Modules/BehaviouralAssessment/resources/views/rating-scale/_form.blade.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BARS-09** · M · DECISION · CTL-03 — bind the `{rating_scale}` resource parameter to the model?
  - **Why it is a decision:** it renames the resource route parameter and the controller arguments (route file is ⚠ SHARED), and it changes how a missing id yields a 404.
  - (a) ⭐ Bind: register the resource with `->parameters(['rating-scales' => 'ratingScale'])`, then change `show`/`edit`/`update`/`destroy` to `BaRatingScale $ratingScale` and delete their `findOrFail($id)` loads. The argument name must match the route parameter exactly (`ratingScale`), or Laravel binds nothing and passes an empty model.
  - (b) Leave the manual `findOrFail($id)`; there is no user-visible defect today.
  - (c) Bind only the read paths (`show`/`edit`) and leave the writes as they are.
  - ➜ Choice: ____

- [ ] **BARS-10** · M · DECISION · CTL-06 — extract the level-sync logic (`parkLevels`/`writeLevels`/`clearOtherDefaults`, about 130 lines) into a service?
  - **Why it is a decision:** it is a controller split (DEFERRED by D3) and needs a new class.
  - (a) ⭐ Defer to the split pass (D3). Record it now; do not extract in this pass.
  - (b) Extract a `BaRatingScaleWriter` service now and have `store`/`update` call it once.
  - (c) Leave as is, accepted (the logic has one controller caller).
  - ➜ Choice: ____

- [ ] **BARS-11** · M · DECISION · CTL-10 — retire the three unreferenced level endpoints (`storeLevel`, `updateLevel`, `destroyLevel`)?
  - **Why it is a decision:** it removes three routes (⚠ SHARED route file) and changes three public methods, and it is the fix that resolves BARS-04 and BARS-06.
  - (a) ⭐ Retire: delete `routes/web.php` lines 31, 32 and 34, and replace the body of the three methods with `abort(403, 'This endpoint is not used.');` plus a `// NOT ROUTED` comment (D5). Leave the now-unused `levelRules()` in place (D5: dead private helpers stay; that is this finding).
  - (b) Wire a per-level UI to the three routes and keep them; then also fix BARS-06 by moving the rules into a `BaRatingLevelRequest`.
  - (c) Leave untouched, accepted (only `.update`-authorized users can reach them).
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BARS-02 | Removed by BARS-01 (they are the `Log::error` calls inside the nine catches that BARS-01 deletes). |
| BARS-03 | Fixed inside BARS-01 (the rewrite builds each redirect/JSON after the transaction closure returns). |
| BARS-04 | Moot if BARS-11(a) retires `storeLevel`; if the endpoint is kept, add `->lockForUpdate()` to the `max('sort_order')` read. |
| BARS-06 | Lives only in the endpoints BARS-11(a) retires; add a `BaRatingLevelRequest` only if BARS-11(b) keeps them. |
| BARS-12 | Accepted: each loop row carries its own `activityLog()` with row-specific old/new values, which a bulk write cannot reproduce, and every loop is bounded (one other default, at most 20 levels). |
