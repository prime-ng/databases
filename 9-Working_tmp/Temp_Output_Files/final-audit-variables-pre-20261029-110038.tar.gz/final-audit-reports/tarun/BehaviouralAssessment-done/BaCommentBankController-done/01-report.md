# Final Audit — BehaviouralAssessment / BaCommentBankController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php` (273 lines, 9 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `xyz_school_00000000000040008000_202627` (first tenant in the central `tenants` table)

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/behavioural-assessment/masters?tab=comment-bank` (list + create/edit dialogs); `/behavioural-assessment/comment-bank/trash` (trash page); `GET /behavioural-assessment/comment-bank` redirects to the masters tab |
| Menu path | Behavioural Assessment → Masters → Comment Bank tab |
| Who uses it | Super Admin, School Admin, Principal — the only roles holding `tenant.behavioural-assessment.comment-bank.*` in `sys_role_has_permissions_jnt` (21 role/permission rows measured) |
| What a user does here | Creates and edits reusable narrative remark templates (a code, a sentiment, an optional behavioural domain, the template text, an active switch), drags rows to reorder them, toggles a template active/inactive, moves one to trash, and restores or permanently deletes it from the trash page. `usage_count` and `is_system` are read-only system columns. |
| Tables written | `ba_comment_bank` (create/update/soft-delete/restore/force-delete); `sys_activity_logs` (one row per mutation through the `activityLog()` helper) |
| Tables read | `ba_comment_bank`, `ba_categories` (via the `category` relation and the domain filter) |
| Live data | `ba_comment_bank` 12 live rows, 0 trashed, all 12 `is_system = true` on the measured tenant (read-only tinker: `live=12 trashed=0 system=12`) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Not production-ready as-is; 0 blockers, 1 HIGH — ready after the fixes, roughly half a day.** The worst finding is **CBNK-07**: `restore` is a `GET` route that changes state, so any link prefetcher, crawler or `<img>`-style GET can silently un-trash a template with no CSRF token. The controller is otherwise small and readable, but every one of its seven write methods wraps `DB::transaction` in a controller `try/catch` that D1 forbids (it logs only `$e->getMessage()` and swallows the trace), and the same seven methods build their HTTP response inside the transaction closure. The single highest-value change is removing those seven try/catch wrappers; a second plan item extracts the `reorder` validation, and two small items fix the bulk write and the trash-route binding. Rough effort: S–M (a few hours), with one DECISION (route-model binding) needing your choice first.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 8 | 1 | 1 | 10 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CBNK-01, CBNK-02 | F8 Services/Jobs | clean — `grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b'` on the controller returns only `BaCommentBankRequest` |
| F2 Transactions/Audit | CBNK-03, CBNK-04 | F9 Queries/Perf | CBNK-09 |
| F3 Authorization | CBNK-05 | F10 Views | clean — `grep -n -e 'Model::' -e 'DB::' -e '{!!'` on the four comment-bank blades returns no matches |
| F4 Validation | CBNK-06 | F11 Security/Tenancy | clean — no `env()`, no secrets logged; `BaActor`'s static cache is keyed by database name |
| F5 Routes | CBNK-07 | F12 Style | clean — `vendor/bin/pint --test` returned `passed` |
| F6 Controller shape | CBNK-08 | F13 Deep read | CBNK-10 |
| F7 Models | clean — `$fillable`/`$casts`/`SoftDeletes`/`$table` all present (see F7) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php` | controller | 273 | this report | ✅ whole class |
| 2 | `Modules/BehaviouralAssessment/app/Models/BaCommentBank.php` | model | 84 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | 45 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankRequest.php` | FormRequest | 85 | this report (only this controller uses it) | ✅ |
| 5 | `Modules/BehaviouralAssessment/routes/web.php` lines 58-63 | routes | — | this report | ✅ |
| 6 | `Modules/BehaviouralAssessment/resources/views/comment-bank/trash.blade.php` | blade | 66 | this report (`trashed()` renders it) | ✅ |
| 7 | `Modules/BehaviouralAssessment/resources/views/comment-bank/_fields.blade.php` | blade | 89 | this report (create/edit dialog fields) | ✅ |
| 8 | `Modules/BehaviouralAssessment/resources/views/pages/partials/masters/_comment-bank.blade.php` | blade | 204 | this report (tab list, posts to this controller) | ✅ |
| 9 | `Modules/BehaviouralAssessment/resources/views/pages/partials/masters/_comment-bank-modals.blade.php` | blade | 23 | this report (create/edit modal shells) | ✅ |
| — | `app/Traits/AuthorizesTenantFeature.php` | trait (app glue) | 60 | common | ↗ referenced — used by the FormRequest's `authorize()` |
| — | `resources/views/components/backend/**` (layout, `tab.modal`, `tab.search-bar`, `table.action`, `table.action-trashed`, `table.status-switch`) | components | — | common | ↗ referenced (the trash row action reads the route verb at render time) |
| — | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php` (`masters()`) | controller | — | BaDashboardController report (when written) | ↗ referenced — it supplies `$commentBank` and `$commentCategoryOptions` to the tab views and already eager-loads `category:id,code,name` |

**Pre-applied 2026-10-10:** none — no file in scope appears in a module `PRE-APPLIED-*.md`.

## 4. Routes

```
GET|HEAD  behavioural-assessment/comment-bank                             behavioural-assessment.comment-bank.index         BaCommentBankController@index
POST      behavioural-assessment/comment-bank                             behavioural-assessment.comment-bank.store         BaCommentBankController@store
POST      behavioural-assessment/comment-bank/reorder                     behavioural-assessment.comment-bank.reorder       BaCommentBankController@reorder
GET|HEAD  behavioural-assessment/comment-bank/trash                       behavioural-assessment.comment-bank.trashed        BaCommentBankController@trashed
PUT|PATCH behavioural-assessment/comment-bank/{comment_bank}              behavioural-assessment.comment-bank.update        BaCommentBankController@update
DELETE    behavioural-assessment/comment-bank/{comment_bank}              behavioural-assessment.comment-bank.destroy       BaCommentBankController@destroy
POST      behavioural-assessment/comment-bank/{comment_bank}/toggle-status behavioural-assessment.comment-bank.toggleStatus BaCommentBankController@toggleStatus
DELETE    behavioural-assessment/comment-bank/{id}/force-delete           behavioural-assessment.comment-bank.forceDelete   BaCommentBankController@forceDelete
GET|HEAD  behavioural-assessment/comment-bank/{id}/restore                behavioural-assessment.comment-bank.restore       BaCommentBankController@restore
```

Middlewares on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:BehaviouralAssessment, auth, verified` (uncached `route:list --json`). Custom routes are registered before `Route::resource` (web.php lines 58-62 precede line 63), so `comment-bank/trash` and `comment-bank/reorder` are not captured by the resource wildcard.

Route-parameter name check (`module-finalization.md` §3.3.1): `update`/`destroy`/`toggleStatus` take `int $comment_bank`, matching the resource parameter `{comment_bank}`; `restore`/`forceDelete` take `int $id`, matching `{id}`. No route names a model type-hint, so there is no unbound-model insert risk.

**Unrouted public methods:** none. All nine public methods (`index`, `store`, `update`, `reorder`, `destroy`, `trashed`, `restore`, `forceDelete`, `toggleStatus`) appear in the route list; no D5 work is needed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 31 | GET `comment-bank` | `tenant.behavioural-assessment.comment-bank.viewAny` | — | — | none (redirect only) | — |
| `store` | 38 | POST `comment-bank` | `tenant.behavioural-assessment.comment-bank.create` (also FormRequest `authorize()`) | ✅ `DB::transaction` closure | `Stored` (after write, in tx ✅) | `ba_comment_bank`, `sys_activity_logs` | CBNK-01, CBNK-02, CBNK-03, CBNK-05 |
| `update` | 66 | PUT/PATCH `comment-bank/{comment_bank}` | `tenant.behavioural-assessment.comment-bank.update` (also FormRequest `authorize()`) | ✅ `DB::transaction` closure | `Updated` (after write, in tx ✅) | `ba_comment_bank`, `sys_activity_logs` | CBNK-01, CBNK-02, CBNK-03, CBNK-05, CBNK-08 |
| `reorder` | 95 | POST `comment-bank/reorder` | `tenant.behavioural-assessment.comment-bank.update` | ✅ `DB::transaction` closure | `Reordered` (after writes, in tx ✅) | `ba_comment_bank`, `sys_activity_logs` | CBNK-01, CBNK-02, CBNK-03, CBNK-06, CBNK-09 |
| `destroy` | 137 | DELETE `comment-bank/{comment_bank}` | `tenant.behavioural-assessment.comment-bank.delete` | ✅ `DB::transaction` closure | `Trashed` (after write, in tx ✅) | `ba_comment_bank`, `sys_activity_logs` | CBNK-01, CBNK-02, CBNK-03, CBNK-08 |
| `trashed` | 169 | GET `comment-bank/trash` | `tenant.behavioural-assessment.comment-bank.restore` | — | — | none (read only, `paginate(10)`) | — |
| `restore` | 181 | GET `comment-bank/{id}/restore` | `tenant.behavioural-assessment.comment-bank.restore` | ✅ `DB::transaction` closure | `Restored` (after write, in tx ✅) | `ba_comment_bank`, `sys_activity_logs` | CBNK-01, CBNK-02, CBNK-03, CBNK-07, CBNK-08 |
| `forceDelete` | 212 | DELETE `comment-bank/{id}/force-delete` | `tenant.behavioural-assessment.comment-bank.forceDelete` | ✅ `DB::transaction` closure | `Deleted` (after write, in tx ✅) | `ba_comment_bank`, `sys_activity_logs` | CBNK-01, CBNK-02, CBNK-03, CBNK-08, CBNK-10 |
| `toggleStatus` | 243 | POST `comment-bank/{comment_bank}/toggle-status` | `tenant.behavioural-assessment.comment-bank.update` | ✅ `DB::transaction` closure | `Toggled` (after write, in tx ✅) | `ba_comment_bank`, `sys_activity_logs` | CBNK-01, CBNK-02, CBNK-03, CBNK-08 |

**Tables each mutation SHOULD touch, vs what it does:**
- `store` / `update` — one `ba_comment_bank` row plus its audit row: does exactly those two, in one transaction.
- `reorder` — the reordered `ba_comment_bank` rows plus one audit row (one entry per drag, not per row): does both, in one transaction.
- `destroy` — soft-delete the row (plus set `is_active = false`) and one audit row: does both, in one transaction.
- `restore` — un-delete the row plus one audit row: does both, in one transaction.
- `forceDelete` — hard-delete the row plus one audit row: does both, in one transaction.
- `toggleStatus` — flip `is_active` plus one audit row: does both, in one transaction.

## 6. Findings

### F1 — Errors

#### CBNK-01 · M · ERR-00 (D1) — seven mutating methods keep a controller `try/catch` that is not a D2 shape

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M by protocol D1) — *the Laravel idiom wins for the final audit: no `try/catch` in a controller unless it is one of the D2 shapes (`\DomainException`, the truncate-rebuild catch, `SnapshotProtectionException`, or `report($e)` in a service)* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php:42-63`, methods `store`, `update`, `reorder`, `destroy`, `restore`, `forceDelete`, `toggleStatus` |
| **Root cause** | Every write method wraps its `DB::transaction` in `try { … } catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { Log::error(…); return back()… }`. None of these catches is a D2 shape, so D1 forbids them. The `ModelNotFoundException` rethrow is the only reason a 404 survives; every other `Throwable` is swallowed into a generic redirect. |
| **Consequence** | A failed template save is reported to the user as "The operation could not be completed." and the real exception is never logged with its trace, so it cannot be diagnosed from the log. |
| **Reproduce** | static only — forcing a `QueryException` (for example a duplicate `code` firing `uq_ba_comment_code`) yields the generic flash rather than a logged trace. |
| **Fix approach** | Remove all seven `try`/`catch` wrappers; keep `findOrFail()` and `Gate::authorize()` where they are; let `DB::transaction(fn () => …)` roll back and the central handler render. |
| **Plan item** | CBNK-01 in `02-fix-plan.md` §3 |

```php
// lines 42-63, method store() — the D2-forbidden shape
        try {
            return DB::transaction(function () use ($request) {
                $record = BaCommentBank::create($request->validated() + [
                    // Appended to the end; the list's drag-and-drop reorders it.
                    'sort_order' => BaCommentBank::nextSortOrder(),
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Stored', ['message' => 'BaCommentBank was stored.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'comment-bank'])
                    ->with('success', 'Comment template created successfully.');
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCommentBankController::store failed', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "try {\|catch (\|Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
42:        try {
57:        } catch (ModelNotFoundException $e) {
59:        } catch (\Throwable $e) {
60:            Log::error('BaCommentBankController::store failed', ['error' => $e->getMessage()]);
70:        try {
81:        } catch (ModelNotFoundException $e) {
83:        } catch (\Throwable $e) {
84:            Log::error('BaCommentBankController::update failed', ['error' => $e->getMessage()]);
105:        try {
125:        } catch (ModelNotFoundException $e) {
127:        } catch (\Throwable $e) {
128:            Log::error('BaCommentBankController::reorder failed', ['error' => $e->getMessage()]);
141:        try {
160:        } catch (ModelNotFoundException $e) {
162:        } catch (\Throwable $e) {
163:            Log::error('BaCommentBankController::destroy failed', ['error' => $e->getMessage()]);
185:        try {
203:        } catch (ModelNotFoundException $e) {
205:        } catch (\Throwable $e) {
206:            Log::error('BaCommentBankController::restore failed', ['error' => $e->getMessage()]);
216:        try {
234:        } catch (ModelNotFoundException $e) {
236:        } catch (\Throwable $e) {
237:            Log::error('BaCommentBankController::forceDelete failed', ['error' => $e->getMessage()]);
247:        try {
262:        } catch (ModelNotFoundException $e) {
264:        } catch (\Throwable $e) {
265:            Log::error('BaCommentBankController::toggleStatus failed', ['error' => $e->getMessage()]);
```

#### CBNK-02 · M · ERR-05 — every catch logs only `$e->getMessage()`

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php:60,84,128,163,206,237,265` |
| **Root cause** | The catch calls `Log::error('…', ['error' => $e->getMessage()])`, which stores the message string only; the exception type, trace and previous exceptions are lost. |
| **Consequence** | A production failure in any of the seven writes leaves a one-line log entry that cannot be traced to the failing query. |
| **Reproduce** | static only — the log array has no `exception` or stack key. |
| **Fix approach** | Removing the catches (CBNK-01) removes these log calls; if a catch is ever kept it must use `report($e)`. |
| **Plan item** | none — see plan §10 (removed by CBNK-01) |

```php
// line 60, the store() catch — same idiom at 84, 128, 163, 206, 237, 265
            Log::error('BaCommentBankController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
60:            Log::error('BaCommentBankController::store failed', ['error' => $e->getMessage()]);
84:            Log::error('BaCommentBankController::update failed', ['error' => $e->getMessage()]);
128:            Log::error('BaCommentBankController::reorder failed', ['error' => $e->getMessage()]);
163:            Log::error('BaCommentBankController::destroy failed', ['error' => $e->getMessage()]);
206:            Log::error('BaCommentBankController::restore failed', ['error' => $e->getMessage()]);
237:            Log::error('BaCommentBankController::forceDelete failed', ['error' => $e->getMessage()]);
265:            Log::error('BaCommentBankController::toggleStatus failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### CBNK-03 · M · TXN-05 — the HTTP response is built inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build `redirect()` / `response()` after it* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php:53-55,77-79,123,146,156-158,191,199-201,230-232,256-260` |
| **Root cause** | Each `DB::transaction(function () { … })` ends with `return redirect()…`, `return back()…` or `return response()->json(…)` instead of returning the model or void and building the response after the closure. `destroy` and `restore` even `return back()->with('error', …)` for their guard branches from inside the transaction. |
| **Consequence** | The success flash or JSON payload is assembled before the commit; the response object exists in memory before the write is durable. No data corruption, but the guard branches also hold an open transaction while returning a plain redirect. |
| **Reproduce** | static only — every method's last statement inside the closure is an HTTP response. |
| **Fix approach** | Move the redirect/JSON construction after `DB::transaction(...)`; make the closure return `void` (CBNK-01's rewrite does this and also moves the guard branches out). |
| **Plan item** | none — see plan §10 (fixed inside CBNK-01) |

```php
// lines 53-56, the store() closure tail — the same shape at the other six methods
                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'comment-bank'])
                    ->with('success', 'Comment template created successfully.');
            });
```

**Evidence**
```
$ grep -n -e "return DB::transaction" -e "return redirect()" -e "return response()" -e "return back()" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
35:        return redirect()->route('behavioural-assessment.masters', ['tab' => 'comment-bank']);
43:            return DB::transaction(function () use ($request) {
53:                return redirect()
62:            return back()->withInput()->with('error', 'The operation could not be completed.');
71:            return DB::transaction(function () use ($request, $comment_bank) {
77:                return redirect()
86:            return back()->withInput()->with('error', 'The operation could not be completed.');
106:            return DB::transaction(function () use ($validated) {
123:                return response()->json(['success' => true, 'message' => 'Order updated.']);
130:            return response()->json([
142:            return DB::transaction(function () use ($comment_bank) {
146:                    return back()->with('error', 'System comment templates are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
156:                return redirect()
165:            return back()->with('error', 'The operation could not be completed.');
186:            return DB::transaction(function () use ($id) {
191:                    return back()->with('error', "Another comment template already uses the code {$record->code}. Change that template's code before restoring this one.");
199:                return redirect()
208:            return back()->with('error', 'The operation could not be completed.');
217:            return DB::transaction(function () use ($id) {
221:                    return back()->with('error', 'System comment templates are part of the behavioural framework and cannot be deleted.');
230:                return redirect()
239:            return back()->with('error', 'The operation could not be completed.');
248:            return DB::transaction(function () use ($comment_bank) {
256:                return response()->json([
267:            return response()->json([
```

#### CBNK-04 · M · TXN-06 — `nextSortOrder()` is a max-then-insert with no lock or unique index

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M, lowered from H — the only cost is list-ordering, not money or data loss) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/BehaviouralAssessment/app/Models/BaCommentBank.php:80-83` (called at controller `store:46`); also `restore`'s `exists()`-then-`restore()` at controller `190-195` |
| **Root cause** | `nextSortOrder()` runs `static::max('sort_order')` and the caller then `create()`s with `max + 1`; two concurrent creates can read the same max and write the same value. The `ba_comment_bank` migration declares no unique index on `sort_order` (only `uq_ba_comment_code`, `idx_ba_comment_cat`, `idx_ba_comment_sent`). `restore` has the same shape (`where('code',…)->exists()` then `restore()`), but there the DB unique index `uq_ba_comment_code` turns the race into a caught unique violation rather than a silent duplicate. |
| **Consequence** | Two templates created in the same instant can share a sort position, so their relative order in the Master list is undefined until the next drag reorder — cosmetic only. |
| **Reproduce** | static only — requires two simultaneous `POST /behavioural-assessment/comment-bank` requests. |
| **Fix approach** | Accept (cosmetic), or read the max under `lockForUpdate()`. A unique index on `sort_order` cannot be added because `reorder` writes intermediate duplicate positions mid-operation. |
| **Plan item** | none — see plan §10 (accepted) |

```php
// BaCommentBank.php:80-83 — read-max then insert, no lock
    public static function nextSortOrder(): int
    {
        return (int) (static::max('sort_order') ?? 0) + 1;
    }
```

**Evidence**
```
$ grep -n -e "nextSortOrder" -e "static::max" Modules/BehaviouralAssessment/app/Models/BaCommentBank.php
80:    public static function nextSortOrder(): int
82:        return (int) (static::max('sort_order') ?? 0) + 1;
$ grep -n "unique\|index" database/migrations/tenant/2026_06_16_130628_create_ba_comment_bank_table.php
36:            $table->unique(['code', 'uq_guard'], 'uq_ba_comment_code');
37:            $table->index(['category_id', 'is_active'], 'idx_ba_comment_cat');
38:            $table->index(['sentiment', 'applies_to'], 'idx_ba_comment_sent');
```

### F3 — Authorization

#### CBNK-05 · L · AUTH-04 — `store` and `update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` plus `Gate::authorize`); keep one* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php:40`, methods `store` and `update` (the same check repeats at `:68`); the duplicate half is `BaCommentBankRequest::authorize()` at lines 22-26 |
| **Root cause** | The FormRequest runs `authorizeByCrudPermission('tenant.behavioural-assessment.comment-bank')` (POST maps to `create`, PUT/PATCH to `update`), and the controller repeats `Gate::authorize(…create)` / `Gate::authorize(…update)` for the same two keys. |
| **Consequence** | No runtime effect; it is duplication that can drift — if one side's key changes, the other silently keeps the old check. |
| **Reproduce** | static only. |
| **Fix approach** | Keep the FormRequest `authorize()` (it runs first, before validation) and drop the two controller `Gate::authorize` lines. |
| **Plan item** | CBNK-05 in `02-fix-plan.md` §4 |

```php
// lines 38-40, method store() — the controller half of the duplicate; update() repeats it at :68
    public function store(BaCommentBankRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.create');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
40:        Gate::authorize('tenant.behavioural-assessment.comment-bank.create');
68:        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');
$ sed -n '22,26p' Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankRequest.php
    public function authorize(): bool
    {
        // Mirrors the controller's gate: .create on POST, .update on PUT/PATCH.
        return $this->authorizeByCrudPermission('tenant.behavioural-assessment.comment-bank');
    }
```

### F4 — Validation and input

#### CBNK-06 · M · VAL-02 — `reorder` validates inline instead of using a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request; inline `$request->validate()` is allowed only for a one-field AJAX toggle* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php:99-103` |
| **Root cause** | The reorder endpoint calls `$request->validate(['order' => …, 'order.*' => …, 'start' => …])` in the controller. The payload has three keys, so the one-field AJAX exception does not apply, and the project keeps all other `ba_comment_bank` validation in `BaCommentBankRequest`. |
| **Consequence** | The reorder contract lives apart from the model's other validation, so a future field change can be made in one place and not the other; there is no single place that documents the `ba_comment_bank` input rules. |
| **Reproduce** | static only. |
| **Fix approach** | Add `BaCommentBankReorderRequest` carrying the same three rules and take it as the `reorder` argument; call `$request->validated()`. |
| **Plan item** | CBNK-06 in `02-fix-plan.md` §5 |

```php
// lines 95-103
    public function reorder(Request $request): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');

        $validated = $request->validate([
            'order' => ['required', 'array'],
            'order.*' => ['integer', 'distinct', 'exists:ba_comment_bank,id'],
            'start' => ['nullable', 'integer', 'min:1'],
        ]);
```

**Evidence**
```
$ grep -n -e "validate(" -e "validated()" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
44:                $record = BaCommentBank::create($request->validated() + [
73:                $record->update($request->validated() + ['updated_by' => BaActor::id()]);
99:        $validated = $request->validate([
```

### F5 — Routes

#### CBNK-07 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …): GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/BehaviouralAssessment/routes/web.php:59` (route) and `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php:181` (method `restore`) |
| **Root cause** | `Route::get('comment-bank/{id}/restore', …)` runs a write (sets `updated_by`, calls `restore()`, writes `sys_activity_logs`) behind a GET. |
| **Consequence** | A link prefetcher, a crawler or an `<img>`-style GET with a trashed id silently un-trashes the template with no CSRF token; the trash page's confirm dialog gives false confidence. |
| **Reproduce** | Open `/behavioural-assessment/comment-bank/{id}/restore` for a trashed id in a plain browser tab — the row is restored. |
| **Fix approach** | Change the route verb to POST; the shared `action-trashed` component already emits `@csrf` and a POST form whenever the route is not GET, so only the route line changes. |
| **Plan item** | CBNK-07 in `02-fix-plan.md` §1 (⚠ SHARED — route file) |

```php
// routes/web.php:59
Route::get('comment-bank/{id}/restore', [\Modules\BehaviouralAssessment\Http\Controllers\BaCommentBankController::class, 'restore'])->name('comment-bank.restore');
```

**Evidence**
```
$ grep -n "comment-bank/{id}/restore" Modules/BehaviouralAssessment/routes/web.php
59:Route::get('comment-bank/{id}/restore', [\Modules\BehaviouralAssessment\Http\Controllers\BaCommentBankController::class, 'restore'])->name('comment-bank.restore');
$ sed -n '29,31p' resources/views/components/backend/table/action-trashed.blade.php
    <form action="{{ route($restoreRouteName, $restoreParams) }}"
          method="{{ $restoreMethod === 'GET' ? 'GET' : 'POST' }}"
          class="d-inline confirm-action-form-restore">
```

### F6 — Controller shape

#### CBNK-08 · M · CTL-03 — no route-model binding; every method loads by `$id`/`$comment_bank` with `findOrFail()`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`, `withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php:66,72,137,143,181,187,212,218,243,249` |
| **Root cause** | `update`/`destroy`/`toggleStatus` take `int $comment_bank` and `restore`/`forceDelete` take `int $id`, then call `findOrFail()`; the routes already carry `{comment_bank}` / `{id}`, so implicit binding is available and the manual load is redundant. |
| **Consequence** | No user-visible defect today — the explicit `findOrFail()` is correct — so the cost is boilerplate and one more place to remember `->withTrashed()` if the parameter is ever rebound. |
| **Reproduce** | static only. |
| **Fix approach** | Bind the models: `update`/`destroy`/`toggleStatus` on `{comment_bank}`; rename the `restore`/`forceDelete` parameters to `{comment_bank}` and add `->withTrashed()`. This touches the route file, so it is offered as a DECISION. |
| **Plan item** | CBNK-08 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// lines 66-72, method update() — the shape repeated by the other four methods
    public function update(BaCommentBankRequest $request, int $comment_bank): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');

        try {
            return DB::transaction(function () use ($request, $comment_bank) {
                $record = BaCommentBank::findOrFail($comment_bank);
```

**Evidence**
```
$ grep -n "findOrFail" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
72:                $record = BaCommentBank::findOrFail($comment_bank);
143:                $record = BaCommentBank::findOrFail($comment_bank);
187:                $record = BaCommentBank::onlyTrashed()->findOrFail($id);
218:                $record = BaCommentBank::withTrashed()->findOrFail($id);
249:                $item = BaCommentBank::findOrFail($comment_bank);
```

### F7 — Models

**clean** — `Modules/BehaviouralAssessment/app/Models/BaCommentBank.php` declares `$table = 'ba_comment_bank'` (table exists in `database/migrations/tenant/2026_06_16_130628_create_ba_comment_bank_table.php`), a `$fillable` list with nothing sensitive, a `$casts` entry for every integer/boolean/datetime column, and `SoftDeletes` matching the `deleted_at` column; both relations (`category(): BelongsTo`, `studentRemarks(): HasMany`) are return-typed. No Spatie `InteractsWithMedia`. Proof: `grep -n -e 'SoftDeletes' -e '$casts' -e '$fillable' Modules/BehaviouralAssessment/app/Models/BaCommentBank.php` shows lines 10, 17, 37, 51; `grep -rn "ba_comment_bank" database/migrations/tenant/` shows the create migration and the deferred FK migration.

### F8 — Services and jobs

**clean** — the controller names no service, job, event, mail or notification. Proof: `grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b' Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php` → only `BaCommentBankRequest`. The one helper reached is the framework-side `activityLog()` in `app/Helpers/activityLog.php` (common).

### F9 — Queries and performance

#### CBNK-09 · M · QRY-01 — `reorder` issues one UPDATE per row inside a `foreach`

| Field | Value |
|---|---|
| **Rule** | QRY-01 (M, lowered from H — the loop is bounded to one page of 10 rows by the paginator) — *no queries inside loops; bulk-write* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php:110-115` |
| **Root cause** | `BaCommentBank::where('id', $id)->update([…])` runs once per id in `foreach ($order …)`, so one drag performs N UPDATE statements (plus the later `BaCommentBank::find($order[0])` lookup) instead of a single bulk write. |
| **Consequence** | A drag on a full page runs 10 statements where 1 would do; each drag holds the transaction open for 10 round-trips, and the cost scales with page size. |
| **Reproduce** | static only — the drag posts `{order:[…],start:N}` to `POST /behavioural-assessment/comment-bank/reorder`. |
| **Fix approach** | One `UPDATE … SET sort_order = CASE id WHEN ? THEN ? … END, updated_by = ? WHERE id IN (…)` with bound parameters. |
| **Plan item** | CBNK-09 in `02-fix-plan.md` §6 |

```php
// lines 110-115
                foreach ($order as $offset => $id) {
                    BaCommentBank::where('id', $id)->update([
                        'sort_order' => $start + $offset,
                        'updated_by' => BaActor::id(),
                    ]);
                }
```

**Evidence**
```
$ grep -n "BaCommentBank::where('id'" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
111:                    BaCommentBank::where('id', $id)->update([
$ grep -n "paginate" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
176:            ->paginate(10);
```

### F10 — Views

**clean** — none of the four in-scope blades runs a query, dumps a whole model, or uses `{!! !!}`. The trash list's `category` relation is eager-loaded by `trashed()` (`->with('category:id,name')`), and the Masters tab data is supplied already-eager-loaded by `BaDashboardController::masters()` (`with('category:id,code,name')`). Proof: `grep -n -e 'Model::' -e 'DB::' -e '->get()' -e '->count()' -e 'where(' -e '{!!' Modules/BehaviouralAssessment/resources/views/comment-bank/trash.blade.php Modules/BehaviouralAssessment/resources/views/comment-bank/_fields.blade.php Modules/BehaviouralAssessment/resources/views/pages/partials/masters/_comment-bank.blade.php Modules/BehaviouralAssessment/resources/views/pages/partials/masters/_comment-bank-modals.blade.php` → `NO MATCHES`.

### F11 — Security and tenancy

**clean** — no `env()` in the controller (`grep -n "env(" … → no match`); no request body or secret is logged (the only logs are the ERR-05 messages); `BaActor`'s `private static array $systemIds` is keyed by `DB::connection()->getDatabaseName()`, so the cached bootstrap-admin id cannot leak across tenants. The one numeric fallback, `$validated['start'] ?? 1` at controller:108, is the paginator's first-position default, not a user/tenant/status id (SEC-03 does not apply). Tenant routes carry the full tenancy middleware group (see §4).

### F12 — Style

**clean** — `vendor/bin/pint --test --format json` on the controller and the three in-scope PHP classes returns `{"tool":"pint","result":"passed"}`; the controller and all three classes declare `strict_types=1`; no debug leftovers (`grep -n -e 'dd(' -e 'dump(' -e 'var_dump' -e 'print_r' -e 'ray(' -e 'phpinfo' …` → `NO MATCHES`); imports are one-per-class. Note: after CBNK-01 removes the catches, the `ModelNotFoundException` and `Log` imports become unused — the CBNK-01 item removes them.

### F13 — Deep read

#### CBNK-10 · M · deep-read #1 — `forceDelete` permanently deletes a live row (no trashed check)

| Field | Value |
|---|---|
| **Rule** | deep-read #1 (M) — *does any write delete data it should not?* `forceDelete` is reachable for a live row, not only a trashed one |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php:212-226` |
| **Root cause** | `BaCommentBank::withTrashed()->findOrFail($id)` loads live or trashed and the only guard is `is_system`. A `DELETE /behavioural-assessment/comment-bank/{id}/force-delete` with a live, non-system id hard-deletes it; the FK `fk_ba_remark_template` is `ON DELETE SET NULL`, so every `ba_student_remarks.comment_template_id` pointing at it is silently nulled. The trash UI only offers the action for trashed rows, but the route has no such precondition. |
| **Consequence** | An admin who holds `.forceDelete` (School Admin and Principal do) and hits the URL with a live id — or a stale trash page after a restore — irreversibly deletes a template still in use, bypassing the two-step trash safety net and losing the analytics link. |
| **Reproduce** | static only — needs the URL directly; the trash page cannot produce it for a live row. |
| **Fix approach** | Refuse unless `$record->trashed()`. |
| **Plan item** | CBNK-10 in `02-fix-plan.md` §5 |

```php
// lines 217-222
            return DB::transaction(function () use ($id) {
                $record = BaCommentBank::withTrashed()->findOrFail($id);

                if ($record->is_system) {
                    return back()->with('error', 'System comment templates are part of the behavioural framework and cannot be deleted.');
                }
```

**Evidence**
```
$ sed -n '212,226p' Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
    public function forceDelete(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.forceDelete');

        try {
            return DB::transaction(function () use ($id) {
                $record = BaCommentBank::withTrashed()->findOrFail($id);

                if ($record->is_system) {
                    return back()->with('error', 'System comment templates are part of the behavioural framework and cannot be deleted.');
                }

                // fk_ba_remark_template is ON DELETE SET NULL: remarks keep their text (BR-BA-038),
                // only the analytics link to this template is lost.
                $record->forceDelete();
```

**F13 answers — one row per mutating method, eight columns (the eight deep-read questions).**

| Method | Q1 wrong data | Q2 delete-before-store | Q3 duplicate impl | Q4 soft-delete×unique | Q5 race | Q6 auth hole | Q7 lying message | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok | CBNK-04 | ok | ok | ok |
| `update` | ok | ok | ok | ok | ok | ok | ok | ok |
| `reorder` | ok | ok | ok | ok | ok | ok | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | CBNK-04 | ok | ok | ok |
| `forceDelete` | CBNK-10 | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |

Notes on the cells: **Q4** — `restore` explicitly re-checks for a live duplicate `code` (controller:190-192) before restoring, matching the partial unique index `uq_ba_comment_code`; a loser of that race is turned into a caught unique violation by the DB index, so no silent duplicate. **Q7** — the only user messages are the fixed strings and the D2-style business messages ("System comment templates …", "Another comment template already uses the code …"); none claims a write that did not happen. **Q3** — no service duplicates the controller's operations.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `app/Traits/AuthorizesTenantFeature.php` | Its `authorizeByCrudPermission()` maps POST to `create` and PUT/PATCH to `update`; a controller that *also* calls `Gate::authorize()` duplicates the check (this is CBNK-05). The trait itself is correct — the duplication is the caller's. | AUTH-04 | platform owners (informational) |
| `resources/views/components/backend/table/action-trashed.blade.php` | Reads the restore route's verb at render time (`$restoreRoute?->methods()`), so a GET restore renders as a GET form. Correct as written; it will adapt automatically when CBNK-07 changes the verb. | RTE-01 | no change needed |
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php::masters()` | Supplies the Comment Bank tab's `$commentBank`/`$commentCategoryOptions`. Already eager-loads `category:id,code,name` and paginates at 10 with page name `cb_page`; no defect attributable to this controller's scope. | — | BaDashboardController report (when written) |

## 8. Not covered, and why

- **No queue jobs, listeners, commands, events, mail or notifications** are named by this controller, so F8's job/tenant-context checks have nothing in scope.
- **`usage_count` is never written by this controller.** The model lists `usage_count` and `is_system` in `$fillable` even though its docblock calls them system-managed; that is safe *here* because `BaCommentBankRequest` never supplies either key, but the write path that bumps `usage_count` (saving a remark) lives elsewhere and was not audited.
- **The remark-consuming screens** (`Modules/BehaviouralAssessment/resources/views/pages/partials/assessments/_remarks.blade.php`, `assessment/show.blade.php`) that read comment-bank templates are outside this controller's scope.
- **The seeder** `BaCommentBankSeeder.php` and the `config/permissionslist.php` key seeding were checked only to confirm the permission keys exist (`'behavioural-assessment.comment-bank' => $crud` at line 1410, `$crud` containing `viewAny/create/update/delete/restore/forceDelete` at lines 176-184) and the roles holding them; the seeder's exact-name queries were not audited as part of this controller.
- **No browser or test execution** (D4). Every finding is static/code-read evidence; CBNK-04, CBNK-07's real-world trigger and CBNK-10's direct-URL path are not exercised.
- **Route-model binding (CBNK-08)** was left as a DECISION and not applied, so the current `findOrFail` behaviour is the measured baseline.
