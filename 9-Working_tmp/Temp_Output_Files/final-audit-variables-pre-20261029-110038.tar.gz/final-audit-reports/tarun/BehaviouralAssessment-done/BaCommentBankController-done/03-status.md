# Status — BehaviouralAssessment / BaCommentBankController

**Fixed:** 2026-10-22 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work

| ID | File | What was already done | By / when |
|---|---|---|---|
| CBNK-07 | `Modules/BehaviouralAssessment/routes/web.php:56` | `comment-bank/{id}/restore` is `Route::post(...)`, not `Route::get(...)`. Route name and action unchanged. | Orchestrator, 2026-10-22 |

No `PRE-APPLIED-*.md` exists for the BehaviouralAssessment module.

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| CBNK-01 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php:1-221` | Removed all seven controller `try/catch` wrappers (`store`, `update`, `reorder`, `destroy`, `restore`, `forceDelete`, `toggleStatus`); moved each response out of its `DB::transaction` closure; dropped the now-unused `ModelNotFoundException` and `Log` imports. `findOrFail()` stays outside any remaining catch. Carries CBNK-02 (no `getMessage()` logs) and CBNK-03 (response built after commit). | `grep -n -e "try {" -e "catch (" -e "Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php` | no output (exit 1) | 2026-10-22 |
| CBNK-05 | `BaCommentBankController.php:38,58` | Dropped the two controller gate calls in `store`/`update` that duplicated `BaCommentBankRequest::authorize()`; replaced each with the AUTH-04 explanatory comment. `reorder`/`toggleStatus` keep their `.update` gate. | `grep -n "comment-bank.create" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php` | no output (exit 1) | 2026-10-22 |
| CBNK-06 | `BaCommentBankController.php:78-82` + `Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankReorderRequest.php` (new) | `reorder()` now takes `BaCommentBankReorderRequest`, uses `$request->validated()`; added the new FormRequest with the original `order`/`order.*`/`start` rules and open `authorize()`; removed the inline `validate()` call and the unused `Illuminate\Http\Request` import. | `grep -n "request->validate(" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php` · `php -l Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankReorderRequest.php` | no output (exit 1) · `No syntax errors detected` | 2026-10-22 |
| CBNK-10 | `BaCommentBankController.php:181-183` | `forceDelete()` now refuses a row that is not already trashed (`Only a trashed comment template can be permanently deleted.`) before the `is_system` guard. | `grep -n "Only a trashed comment template" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php` | `182: return back()->with('error', 'Only a trashed comment template can be permanently deleted.');` | 2026-10-22 |
| CBNK-09 | `BaCommentBankController.php:88-104` | Replaced the per-row `UPDATE` loop with one bulk `DB::update()` using `CASE id WHEN ? THEN ? … END` plus `WHERE id IN (…)`, binding `updated_by` = `BaActor::id()`. One audit entry per drag is kept. | `grep -n "where('id', \$id)->update" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php` | no output (exit 1) | 2026-10-22 |

## 3. Not applied

| ID | Reason (not ticked / already applied / superseded / blocked) | Detail |
|---|---|---|
| CBNK-07 | Applied by the orchestrator before this fixer run (verified, not re-edited) | `routes/web.php:56` already `Route::post`. No code change made by this run. |
| CBNK-08 | Deferred — decision choice **(a) ⭐** | Keep `findOrFail()` as it is; no controller or route change. `CTL-03` recorded as accepted. No code change. |

## 4. Needs Tarun's hand

- Nothing for this controller's items. No migration, seeder or permission key was added.
- Observation (not changed by this run): `git diff` on `Modules/BehaviouralAssessment/routes/web.php` also shows unrelated restore-verb/route-parameter edits for other BA controllers (rating scales, categories, interventions, assessment periods, configs, assessments, incidents). Those were already in the working tree and are outside this plan item's scope.
- Index row `00-INDEX.md` updated to `FIXED` for this controller.

## 5. Unverifiable by this workflow (no tests, D4)

- Transaction rollback behaviour of the seven writes after removing the catches (central handler rendering).
- The bulk `CASE id` update against MySQL with a real `order` array (SQL generation verified only by static inspection and Pint).
- CSRF-protected restore over POST end-to-end from the trash page (the shared `action-trashed` component reads the route verb and emits `@csrf`; not exercised in a browser).
- Exact `sys_activity_logs` row payloads and the flash/JSON texts at runtime.
- Empty-`order` edge case for the bulk update (validation allows an empty array; unchanged by the plan).

## 6. Verification log

```
$ php -l Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php

$ php -l Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankReorderRequest.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankReorderRequest.php

$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); var_dump(class_exists(Modules\BehaviouralAssessment\Http\Controllers\BaCommentBankController::class));'
bool(true)

$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json >/dev/null && echo ROUTES-OK
ROUTES-OK

$ vendor/bin/pint Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankReorderRequest.php --format agent
{"tool":"pint","result":"passed"}

$ grep -n "comment-bank/{id}/restore" Modules/BehaviouralAssessment/routes/web.php
56:Route::post('comment-bank/{id}/restore', [\Modules\BehaviouralAssessment\Http\Controllers\BaCommentBankController::class, 'restore'])->name('comment-bank.restore');

$ grep -n -e "try {" -e "catch (" -e "Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
(no output, exit 1)

$ grep -n "comment-bank.create" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
(no output, exit 1)

$ grep -n "request->validate(" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
(no output, exit 1)

$ php -l Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankReorderRequest.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankReorderRequest.php

$ grep -n "Only a trashed comment template" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
182:            return back()->with('error', 'Only a trashed comment template can be permanently deleted.');

$ grep -n "where('id', \$id)->update" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php
(no output, exit 1)
```

## 7. Final state

Status: FIXED · Open: B 0 · H 0 · M 0 · L 0
