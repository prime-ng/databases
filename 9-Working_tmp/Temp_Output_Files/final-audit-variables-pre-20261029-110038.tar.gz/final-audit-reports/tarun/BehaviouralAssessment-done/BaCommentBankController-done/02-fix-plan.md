# Fix Plan — BehaviouralAssessment / BaCommentBankController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` to `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | shared by all modules |
| `app/Traits/AuthorizesTenantFeature.php` | common app glue |
| `resources/views/components/backend/**` | shared components; `action-trashed` already adapts to the route verb, so CBNK-07 needs no component change |
| `Modules/BehaviouralAssessment/resources/views/comment-bank/**`, `.../pages/partials/masters/_comment-bank*.blade.php` | blades are clean — no plan item touches them |
| `database/migrations/tenant/**` | never edit an existing migration |
| `Modules/BehaviouralAssessment/routes/web.php` | ⚠ SHARED — named by CBNK-07 only; change line 59 and nothing else |

## 1. Blockers reachable today

- [ ] **CBNK-07** · H · RTE-01 · `Modules/BehaviouralAssessment/routes/web.php:59` — change the restore route from GET to POST so it can no longer change state without a CSRF token. ⚠ SHARED
  - **Touches:** `Modules/BehaviouralAssessment/routes/web.php`
  - **Before** (`web.php:59`):
    ```php
    Route::get('comment-bank/{id}/restore', [\Modules\BehaviouralAssessment\Http\Controllers\BaCommentBankController::class, 'restore'])->name('comment-bank.restore');
    ```
  - **After:**
    ```php
    Route::post('comment-bank/{id}/restore', [\Modules\BehaviouralAssessment\Http\Controllers\BaCommentBankController::class, 'restore'])->name('comment-bank.restore');
    ```
  - **Verify:** `grep -n "comment-bank/{id}/restore" Modules/BehaviouralAssessment/routes/web.php`
  - **Expect:** the line begins with `Route::post(`, not `Route::get(`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

_None._

## 3. Errors & transactions (F1/F2)

- [ ] **CBNK-01** · M · ERR-00 (D1) · `BaCommentBankController.php:42-272` — remove the seven controller `try/catch` wrappers and move each response out of its `DB::transaction` closure. This one item also carries CBNK-02 (the `getMessage()` logs go with the catches) and CBNK-03 (the response is no longer built inside the transaction).
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php`
  - **Before** (imports, lines 7-18):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Http\Requests\BaCommentBankRequest;
    use Modules\BehaviouralAssessment\Models\BaCommentBank;
    use Modules\BehaviouralAssessment\Support\BaActor;
    ```
  - **After:**
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Http\Requests\BaCommentBankRequest;
    use Modules\BehaviouralAssessment\Models\BaCommentBank;
    use Modules\BehaviouralAssessment\Support\BaActor;
    ```
  - **Before** (`store`, lines 38-64):
    ```php
    public function store(BaCommentBankRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.create');

        try {
            return DB::transaction(function () use ($request) {
                $record = BaCommentBank::create($request->validated() + [
                    // Appended to the end; the list's drag-and-drop reorders it.
                    'sort_order' => BaCommentBank::nextSortOrder(),
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Stored', ['message' => 'BaCommentBank was stored.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'comment-bank'])
                    ->with('success', 'Comment template created successfully.');
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCommentBankController::store failed', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function store(BaCommentBankRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.create');

        DB::transaction(function () use ($request): void {
            $record = BaCommentBank::create($request->validated() + [
                // Appended to the end; the list's drag-and-drop reorders it.
                'sort_order' => BaCommentBank::nextSortOrder(),
                'created_by' => BaActor::id(),
                'updated_by' => BaActor::id(),
            ]);

            activityLog($record, 'Stored', ['message' => 'BaCommentBank was stored.']);
        });

        return redirect()
            ->route('behavioural-assessment.masters', ['tab' => 'comment-bank'])
            ->with('success', 'Comment template created successfully.');
    }
    ```
  - **Before** (`update`, lines 66-88):
    ```php
    public function update(BaCommentBankRequest $request, int $comment_bank): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');

        try {
            return DB::transaction(function () use ($request, $comment_bank) {
                $record = BaCommentBank::findOrFail($comment_bank);
                $record->update($request->validated() + ['updated_by' => BaActor::id()]);

                activityLog($record, 'Updated', ['message' => 'BaCommentBank was updated.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'comment-bank'])
                    ->with('success', 'Comment template updated successfully.');
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCommentBankController::update failed', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function update(BaCommentBankRequest $request, int $comment_bank): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');

        $record = BaCommentBank::findOrFail($comment_bank);

        DB::transaction(function () use ($request, $record): void {
            $record->update($request->validated() + ['updated_by' => BaActor::id()]);

            activityLog($record, 'Updated', ['message' => 'BaCommentBank was updated.']);
        });

        return redirect()
            ->route('behavioural-assessment.masters', ['tab' => 'comment-bank'])
            ->with('success', 'Comment template updated successfully.');
    }
    ```
  - **Before** (`reorder`, lines 95-135):
    ```php
    public function reorder(Request $request): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');

        $validated = $request->validate([
            'order' => ['required', 'array'],
            'order.*' => ['integer', 'distinct', 'exists:ba_comment_bank,id'],
            'start' => ['nullable', 'integer', 'min:1'],
        ]);

        try {
            return DB::transaction(function () use ($validated) {
                $order = array_map('intval', $validated['order']);
                $start = $validated['start'] ?? 1;

                foreach ($order as $offset => $id) {
                    BaCommentBank::where('id', $id)->update([
                        'sort_order' => $start + $offset,
                        'updated_by' => BaActor::id(),
                    ]);
                }

                // One entry for the drag, not one per row moved.
                activityLog(BaCommentBank::find($order[0]), 'Reordered', [
                    'message' => 'Comment templates were reordered.',
                    'comment_ids' => $order,
                ]);

                return response()->json(['success' => true, 'message' => 'Order updated.']);
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCommentBankController::reorder failed', ['error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'The operation could not be completed.',
            ], 500);
        }
    }
    ```
  - **After:**
    ```php
    public function reorder(Request $request): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');

        $validated = $request->validate([
            'order' => ['required', 'array'],
            'order.*' => ['integer', 'distinct', 'exists:ba_comment_bank,id'],
            'start' => ['nullable', 'integer', 'min:1'],
        ]);

        DB::transaction(function () use ($validated): void {
            $order = array_map('intval', $validated['order']);
            $start = $validated['start'] ?? 1;

            foreach ($order as $offset => $id) {
                BaCommentBank::where('id', $id)->update([
                    'sort_order' => $start + $offset,
                    'updated_by' => BaActor::id(),
                ]);
            }

            // One entry for the drag, not one per row moved.
            activityLog(BaCommentBank::find($order[0]), 'Reordered', [
                'message' => 'Comment templates were reordered.',
                'comment_ids' => $order,
            ]);
        });

        return response()->json(['success' => true, 'message' => 'Order updated.']);
    }
    ```
  - **Before** (`destroy`, lines 137-167):
    ```php
    public function destroy(int $comment_bank): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.delete');

        try {
            return DB::transaction(function () use ($comment_bank) {
                $record = BaCommentBank::findOrFail($comment_bank);

                if ($record->is_system) {
                    return back()->with('error', 'System comment templates are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
                }

                $record->is_active = false;
                $record->updated_by = BaActor::id();
                $record->save();
                $record->delete();

                activityLog($record, 'Trashed', ['message' => 'BaCommentBank was trashed.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'comment-bank'])
                    ->with('success', 'Comment template moved to trash.');
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCommentBankController::destroy failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function destroy(int $comment_bank): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.delete');

        $record = BaCommentBank::findOrFail($comment_bank);

        if ($record->is_system) {
            return back()->with('error', 'System comment templates are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
        }

        DB::transaction(function () use ($record): void {
            $record->is_active = false;
            $record->updated_by = BaActor::id();
            $record->save();
            $record->delete();

            activityLog($record, 'Trashed', ['message' => 'BaCommentBank was trashed.']);
        });

        return redirect()
            ->route('behavioural-assessment.masters', ['tab' => 'comment-bank'])
            ->with('success', 'Comment template moved to trash.');
    }
    ```
  - **Before** (`restore`, lines 181-210):
    ```php
    public function restore(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.restore');

        try {
            return DB::transaction(function () use ($id) {
                $record = BaCommentBank::onlyTrashed()->findOrFail($id);

                // uq_ba_comment_code only covers live rows, so a newer template may have taken this code.
                if (BaCommentBank::where('code', $record->code)->exists()) {
                    return back()->with('error', "Another comment template already uses the code {$record->code}. Change that template's code before restoring this one.");
                }

                $record->updated_by = BaActor::id();
                $record->restore();

                activityLog($record, 'Restored', ['message' => 'BaCommentBank was restored.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'comment-bank'])
                    ->with('success', 'Comment template restored successfully.');
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCommentBankController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function restore(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.restore');

        $record = BaCommentBank::onlyTrashed()->findOrFail($id);

        // uq_ba_comment_code only covers live rows, so a newer template may have taken this code.
        if (BaCommentBank::where('code', $record->code)->exists()) {
            return back()->with('error', "Another comment template already uses the code {$record->code}. Change that template's code before restoring this one.");
        }

        DB::transaction(function () use ($record): void {
            $record->updated_by = BaActor::id();
            $record->restore();

            activityLog($record, 'Restored', ['message' => 'BaCommentBank was restored.']);
        });

        return redirect()
            ->route('behavioural-assessment.masters', ['tab' => 'comment-bank'])
            ->with('success', 'Comment template restored successfully.');
    }
    ```
  - **Before** (`forceDelete`, lines 212-241):
    ```php
    public function forceDelete(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.forceDelete');

        try {
            return DB::transaction(function () use ($id) {
                $record = BaCommentBank::withTrashed()->findOrFail($id);

                if ($record->is_system) {
                    return back()->with('error', 'System comment templates are part of the behavioural framework and cannot be deleted.');
                }

                // fk_ba_remark_template is ON DELETE SET NULL: remarks keep their text (BR-BA-038),
                // only the analytics link to this template is lost.
                $record->forceDelete();

                activityLog($record, 'Deleted', ['message' => 'BaCommentBank was deleted.']);

                return redirect()
                    ->route('behavioural-assessment.comment-bank.trashed')
                    ->with('success', 'Comment template permanently deleted.');
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCommentBankController::forceDelete failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function forceDelete(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.forceDelete');

        $record = BaCommentBank::withTrashed()->findOrFail($id);

        if ($record->is_system) {
            return back()->with('error', 'System comment templates are part of the behavioural framework and cannot be deleted.');
        }

        DB::transaction(function () use ($record): void {
            // fk_ba_remark_template is ON DELETE SET NULL: remarks keep their text (BR-BA-038),
            // only the analytics link to this template is lost.
            $record->forceDelete();

            activityLog($record, 'Deleted', ['message' => 'BaCommentBank was deleted.']);
        });

        return redirect()
            ->route('behavioural-assessment.comment-bank.trashed')
            ->with('success', 'Comment template permanently deleted.');
    }
    ```
  - **Before** (`toggleStatus`, lines 243-272):
    ```php
    public function toggleStatus(int $comment_bank): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');

        try {
            return DB::transaction(function () use ($comment_bank) {
                $item = BaCommentBank::findOrFail($comment_bank);
                $item->is_active = ! $item->is_active;
                $item->updated_by = BaActor::id();
                $item->save();

                activityLog($item, 'Toggled', ['message' => 'BaCommentBank was toggled.']);

                return response()->json([
                    'success' => true,
                    'is_active' => $item->is_active,
                    'message' => $item->is_active ? 'Comment template activated.' : 'Comment template deactivated.',
                ]);
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCommentBankController::toggleStatus failed', ['error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'The operation could not be completed.',
            ], 500);
        }
    }
    ```
  - **After:**
    ```php
    public function toggleStatus(int $comment_bank): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');

        $item = BaCommentBank::findOrFail($comment_bank);

        DB::transaction(function () use ($item): void {
            $item->is_active = ! $item->is_active;
            $item->updated_by = BaActor::id();
            $item->save();

            activityLog($item, 'Toggled', ['message' => 'BaCommentBank was toggled.']);
        });

        return response()->json([
            'success' => true,
            'is_active' => $item->is_active,
            'message' => $item->is_active ? 'Comment template activated.' : 'Comment template deactivated.',
        ]);
    }
    ```
  - **Verify:** `grep -n -e "try {" -e "catch (" -e "Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php`
  - **Expect:** no output.
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **CBNK-05** · L · AUTH-04 · `BaCommentBankController.php:40,68` — drop the two controller gate calls that duplicate `BaCommentBankRequest::authorize()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php`
  - **Before** (`store`, line 40):
    ```php
        Gate::authorize('tenant.behavioural-assessment.comment-bank.create');
    ```
  - **After:**
    ```php
        // Authorization enforced by BaCommentBankRequest::authorize() (AUTH-04: one check, not two).
    ```
  - **Before** (`update`, line 68):
    ```php
        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');
    ```
  - **After:**
    ```php
        // Authorization enforced by BaCommentBankRequest::authorize() (AUTH-04: one check, not two).
    ```
  - **Verify:** `grep -n "comment-bank.create" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php`
  - **Expect:** no output (only `reorder` and `toggleStatus` keep a `.update` gate).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **CBNK-06** · M · VAL-02 · `BaCommentBankController.php:95-103` — move the `reorder` validation into a FormRequest.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php`, `Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankReorderRequest.php`
  - **Before** (`reorder` signature and validate block, lines 95-103):
    ```php
    public function reorder(Request $request): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');

        $validated = $request->validate([
            'order' => ['required', 'array'],
            'order.*' => ['integer', 'distinct', 'exists:ba_comment_bank,id'],
            'start' => ['nullable', 'integer', 'min:1'],
        ]);
    ```
  - **After:**
    ```php
    public function reorder(BaCommentBankReorderRequest $request): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.comment-bank.update');

        $validated = $request->validated();
    ```
  - **Before** (import block, lines 8-19):
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Http\Requests\BaCommentBankRequest;
    use Modules\BehaviouralAssessment\Models\BaCommentBank;
    use Modules\BehaviouralAssessment\Support\BaActor;
    ```
  - **After:**
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Http\Requests\BaCommentBankReorderRequest;
    use Modules\BehaviouralAssessment\Http\Requests\BaCommentBankRequest;
    use Modules\BehaviouralAssessment\Models\BaCommentBank;
    use Modules\BehaviouralAssessment\Support\BaActor;
    ```
  - **After** (new file `Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankReorderRequest.php`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\BehaviouralAssessment\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;

    /**
     * Drag-and-drop reorder payload for ba_comment_bank (REQ-BA-020). Authorization is enforced by
     * the controller's Gate::authorize call, so authorize() stays open here.
     */
    class BaCommentBankReorderRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }

        public function rules(): array
        {
            return [
                'order' => ['required', 'array'],
                'order.*' => ['integer', 'distinct', 'exists:ba_comment_bank,id'],
                'start' => ['nullable', 'integer', 'min:1'],
            ];
        }
    }
    ```
  - **Verify:** `grep -n "request->validate(" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php`
  - **Expect:** no output; `php -l Modules/BehaviouralAssessment/app/Http/Requests/BaCommentBankReorderRequest.php` reports no syntax errors.
  - **Effort:** S

- [ ] **CBNK-10** · M · deep-read #1 · `BaCommentBankController.php:218-222` — refuse a permanent delete unless the row is already trashed.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php`
  - **Before** (`forceDelete` guard, lines 218-222):
    ```php
    $record = BaCommentBank::withTrashed()->findOrFail($id);

    if ($record->is_system) {
        return back()->with('error', 'System comment templates are part of the behavioural framework and cannot be deleted.');
    }
    ```
  - **After:**
    ```php
    $record = BaCommentBank::withTrashed()->findOrFail($id);

    if (! $record->trashed()) {
        return back()->with('error', 'Only a trashed comment template can be permanently deleted.');
    }

    if ($record->is_system) {
        return back()->with('error', 'System comment templates are part of the behavioural framework and cannot be deleted.');
    }
    ```
  - **Verify:** `grep -n "Only a trashed comment template" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php`
  - **Expect:** one match in `forceDelete`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **CBNK-09** · M · QRY-01 · `BaCommentBankController.php:110-115` — replace the per-row UPDATE loop with one bulk CASE update.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php`
  - **Before** (`reorder` loop, lines 110-115):
    ```php
    foreach ($order as $offset => $id) {
        BaCommentBank::where('id', $id)->update([
            'sort_order' => $start + $offset,
            'updated_by' => BaActor::id(),
        ]);
    }
    ```
  - **After:**
    ```php
    $caseBindings = [];
    $idBindings = [];
    $idPlaceholders = [];

    foreach ($order as $offset => $id) {
        $caseBindings[] = (int) $id;
        $caseBindings[] = $start + $offset;
        $idBindings[] = (int) $id;
        $idPlaceholders[] = '?';
    }

    DB::update(
        'UPDATE ba_comment_bank SET sort_order = CASE id '
            .implode(' ', array_fill(0, count($order), 'WHEN ? THEN ?')).' END, updated_by = ? '
            .'WHERE id IN ('.implode(',', $idPlaceholders).')',
        array_merge($caseBindings, [BaActor::id()], $idBindings)
    );
    ```
  - **Verify:** `grep -n "where('id', \$id)->update" Modules/BehaviouralAssessment/app/Http/Controllers/BaCommentBankController.php`
  - **Expect:** no output.
  - **Effort:** M

## 7. Views (F10)

_None._

## 8. Style (F12) — one item per file

_None — Pint passes; the unused imports are removed inside CBNK-01 (the two catch-only imports) and CBNK-06 (the `Request` import)._

## 9. Deferred / decisions

- [ ] **CBNK-08** · M · DECISION · CTL-03 — switch the routes to model binding instead of `$id`/`$comment_bank` plus `findOrFail()`?
  - **Why it is a decision:** it changes the shared route file and re-scopes two routes (`{id}` becomes `{comment_bank}` with `->withTrashed()`). The current `findOrFail()` is correct, so this is a consistency choice, not a behaviour bug.
  - (a) ⭐ defer — keep `findOrFail()` as it is; it is explicit, correct, and needs no route change. Record `CTL-03` as accepted.
  - (b) apply binding now — `update`/`destroy`/`toggleStatus` take `BaCommentBank $comment_bank`; the `restore`/`forceDelete` routes are renamed to `{comment_bank}` and gain `->withTrashed()`; the five `findOrFail()` calls are dropped. Touches the controller and `routes/web.php`.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CBNK-02 | The `Log::error(..., $e->getMessage())` calls are deleted by CBNK-01; no separate edit is needed. |
| CBNK-03 | The response is moved out of the transaction by CBNK-01's rewrite; no separate edit is needed. |
| CBNK-04 | Accepted: the max-then-insert race only affects list ordering, and a unique index on `sort_order` is impossible because `reorder` writes intermediate duplicates. |
