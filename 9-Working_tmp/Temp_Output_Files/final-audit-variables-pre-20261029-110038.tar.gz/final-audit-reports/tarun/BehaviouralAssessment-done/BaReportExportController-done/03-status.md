# Status — BehaviouralAssessment / BaReportExportController

**Fixed:** 2026-10-22 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work

none — no module `PRE-APPLIED-*.md` lists files in this controller's scope, and the orchestrator
confirmed no route change for this controller (pre-applied by the orchestrator: nothing to log).

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| BAEXP-01 | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:197` | `generate()` now passes the fixed sentence `'The export could not be generated.'` to `markFailed()` instead of `$e->getMessage()`, so raw exception text no longer reaches the user-visible `error_message` column. | `grep -rn "markFailed(\$export, \$e->getMessage())\|markFailed(\$export, 'Export job failed" <service> <job>` | no output (exit 1) | 2026-10-22 |
| BAEXP-01 | `Modules/BehaviouralAssessment/app/Jobs/GenerateReportExportJob.php:48` | `failed()` writes the same fixed sentence; the `'Export job failed: '…` concatenation is gone. | same as above | no output (exit 1) | 2026-10-22 |
| BAEXP-03 | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:128` | `request()`'s `BaReportExport::create()` + `BaAuditLog::log(…, 'requested', …)` are wrapped in one `DB::transaction()`, which returns the export row. | `grep -n "DB::transaction" <service>` | 2 hits: line 128 (`request()`) and line 225 (`expireDue()`) | 2026-10-22 |
| BAEXP-03 | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:225` | `expireDue()` wraps the per-row status UPDATE + `status` audit INSERT in one `DB::transaction()`; the file delete stays OUTSIDE the transaction (TXN-03). | same as above | as above | 2026-10-22 |
| BAEXP-02 | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:196` | The `Log::error('BA report export failed', …)` call is replaced by `report($e)` so the trace survives; the unused `use Illuminate\Support\Facades\Log;` import is deleted (line 14 before, absent after). | `grep -n "Log::\|use Illuminate\\Support\\Facades\\Log" <service>` | the literal pattern also matches `BaAuditLog::` (see §6 note) — precise check `grep -nE '(^|[^A-Za-z])Log::'` → no output; import grep → no output | 2026-10-22 |
| BAEXP-04 | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:108,125-126` | `request()` takes `?string $ipAddress = null` as a 5th parameter and packs it itself; the `app()->bound('request')` / `runningInConsole()` / `request()->ip()` block is deleted, so the service no longer reads the HTTP request. | `grep -n "request()->ip\|runningInConsole\|bound('request')" <service>` | no output (exit 1) | 2026-10-22 |
| BAEXP-04 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:833` | `export()` passes `request()->ip()` as the 5th argument. ⚠ SHARED file — re-read before editing; the plan's `822-827` had drifted to `828-833` (+6) because of the other fixer's edits in the same file. The Before block text matched exactly. | `grep -rn -e '->request(' Modules/BehaviouralAssessment --include=*.php` | one caller only: `BaReportController.php:828` | 2026-10-22 |
| BAEXP-05 | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:84-88` | Constructor now injects `private BaFrameworkSnapshotService $snapshots` alongside `BaNotificationService`. | `grep -n "app(BaFrameworkSnapshotService\|private BaFrameworkSnapshotService" <service>` | exactly one hit: `87: private BaFrameworkSnapshotService $snapshots,` | 2026-10-22 |
| BAEXP-05 | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:468,548,640` | All three `app(BaFrameworkSnapshotService::class)->lockedFramework($period)` call sites (`classDataset`, `categoryDataset`, `overlayFrozen`) now use `$this->snapshots->lockedFramework($period)`. Static `::categoryModels()` / `::overlay()` calls are unchanged (out of scope). | same as above | as above (no `app(BaFrameworkSnapshotService` hit) | 2026-10-22 |
| BAEXP-06 | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:260,277-293` | Added `private array $filterLabels = []` and `filterLabel(string $key, mixed $value)`; `describeFilters()` now delegates to it, so a listing render resolves each period/class/student/category label once instead of once per row. | `grep -n "private array \$filterLabels\|private function filterLabel" <service>` | 2 hits: `260` and `277` | 2026-10-22 |

## 3. Not applied

| ID | Reason (not ticked / already applied / superseded / blocked) | Detail |
|---|---|---|
| BAEXP-07 | no plan item (accepted in plan §10) | `download()` loads the row before the authorization decision; the 403-vs-404 existence difference is accepted as low, tenant-scoped and id-bounded. Nothing to apply. |

All six ticked items were applied in plan order (BAEXP-01 → BAEXP-03 → BAEXP-02 → BAEXP-04 →
BAEXP-05 → BAEXP-06). No item was skipped, blocked, superseded or already applied.

## 4. Needs Tarun's hand

nothing — no migration, no `tenants:migrate`, no seeder, no `/system-config/sync-permissions`, no
route change, no permission key. Behavioural check of a real export download is a browser action
(see §5).

## 5. Unverifiable by this workflow (no tests, D4)

- The client-IP path (BAEXP-04) is only exercised by a real HTTP export request: the controller now
  supplies `request()->ip()` and the service packs it. No test was written or run (D4).
- The transaction rollback paths (BAEXP-03) are reasoned from `DB::transaction()` semantics, not
  exercised: proving a rollback needs a fault injection, which is a test.
- The memoisation benefit (BAEXP-06) is reasoned from the blade resolving `$exSvc` once per listing
  render (`_exports.blade.php:20`) and calling `describeFilters()` per row (`:92`); no query-count
  measurement was run.

## 6. Verification log

```
$ php -l Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
$ php -l Modules/BehaviouralAssessment/app/Jobs/GenerateReportExportJob.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Jobs/GenerateReportExportJob.php
$ php -l Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php

$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); var_dump(class_exists(Modules\BehaviouralAssessment\Http\Controllers\BaReportExportController::class));'
bool(true)

$ php -r '... class_exists(service), class_exists(job), class_exists(BaReportController) ...'
bool(true)
bool(true)
bool(true)

$ php -r '... $a->make(Modules\BehaviouralAssessment\Services\BaReportExportService::class) ...'
Modules\BehaviouralAssessment\Services\BaReportExportService        # new constructor arg resolves

$ php -r '... (new ReflectionMethod(BaReportExportService::class, "request"))->getNumberOfParameters() ...'
int(5)

$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json >/dev/null && echo ROUTES-OK
ROUTES-OK

$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json > /tmp/fa-routes.json && echo ROUTES-JSON-OK
ROUTES-JSON-OK

$ php final-audit-reports/_tools/scan.php . /tmp/fa-routes.json /tmp/fa-baexport-after.json
files 4427, findings 32545, parse errors 1

$ vendor/bin/pint <the three touched files> --format agent
{"tool":"pint","result":"passed"}

# --- item Verify commands, real output ---

$ grep -rn "markFailed(\$export, \$e->getMessage())\|markFailed(\$export, 'Export job failed" \
    Modules/BehaviouralAssessment/app/Services/BaReportExportService.php \
    Modules/BehaviouralAssessment/app/Jobs/GenerateReportExportJob.php
(no output; exit 1)                                                  # BAEXP-01 ✓

$ grep -n "DB::transaction" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
128:        $export = DB::transaction(function () use ($reportCode, $filters, $format, $anonymised, $rowCount, $async, $actorId, $ip) {
225:                DB::transaction(function () use ($export) {
                                                                     # BAEXP-03 ✓ two hits

$ grep -n "Log::\|use Illuminate\\Support\\Facades\\Log" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
146:            BaAuditLog::log(BaAuditLog::ENTITY_EXPORT, (int) $export->id, 'requested', null,
227:                    BaAuditLog::log(BaAuditLog::ENTITY_EXPORT, (int) $export->id, 'status',
# NOTE: the plan's literal pattern also matches `BaAuditLog::` (the 'Log::' substring), so this
# exact command can never print nothing. Precise equivalent, run for real:
$ grep -nE '(^|[^A-Za-z])Log::' Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
(no output; exit 1)
$ grep -n 'use Illuminate\Support\Facades\Log;' Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
(no output; exit 1)                                                  # BAEXP-02 ✓

$ grep -n "request()->ip\|runningInConsole\|bound('request')" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
(no output; exit 1)                                                  # BAEXP-04 ✓

$ grep -n "app(BaFrameworkSnapshotService\|private BaFrameworkSnapshotService" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
87:        private BaFrameworkSnapshotService $snapshots,            # BAEXP-05 ✓ one hit

$ grep -n "private array \$filterLabels\|private function filterLabel" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
260:    private array $filterLabels = [];
277:    private function filterLabel(string $key, mixed $value): string
                                                                     # BAEXP-06 ✓ two hits

$ grep -rn -e '->request(' Modules/BehaviouralAssessment --include=*.php
Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:828:        $export = $exports->request(
                                                                     # BAEXP-04 caller ✓ single

$ grep -rn -e 'BaReportExportService' --include=*.php . | grep -v '^./Modules/BehaviouralAssessment' | grep -v '^./vendor'
(no output)                                                          # no caller outside the module

$ git diff --stat -- <the three touched files>
 .../app/Http/Controllers/BaReportController.php    |  92 +++++++++---------
 .../app/Jobs/GenerateReportExportJob.php           |   2 +-
 .../app/Services/BaReportExportService.php         | 106 ++++++++++++---------
 3 files changed, 110 insertions(+), 90 deletions(-)
# BaReportController's 92 lines are the other fixer's uncommitted edits in the same file; this
# session's only change there is the single added line `request()->ip(),` (line 833).
```

## 7. Final state

Status: FIXED · Open: B 0 · H 0 · M 0 · L 1
