# Fix Plan — BehaviouralAssessment / BaReportExportController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportExportController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/BehaviouralAssessment/routes/web.php` | Route file — no route change is part of this plan |
| `database/migrations/tenant/2026_06_16_130639_create_ba_report_exports_table.php` | Existing migration — never edit |
| `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` | Owned by the BaAuditLogController report |
| `Modules/BehaviouralAssessment/app/Support/BaActor.php` | Owned by the BaCommentBankController report |
| `Modules/BehaviouralAssessment/app/Support/BaDispatch.php` | Owned by the BaNotificationController report |
| `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php` | Owned by the BaNotificationController report |
| `Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php` | Shared BA service — ownership for the main session to assign (only its call sites in the export service are edited here) |
| `Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_exports.blade.php` | Rendered by BaReportController — BAEXP-06 is fixed in the service, not the view |
| `config/permissionslist.php` | Shared; permission names are already correct and seeded — nothing to change |

## 1. Blockers reachable today

- [ ] **BAEXP-01** · B · ERR-01 · `BaReportExportService.php:194` + `GenerateReportExportJob.php:48` — stop writing raw exception text into the user-visible `error_message` column; write a fixed sentence and keep the reason for the log.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php`, `Modules/BehaviouralAssessment/app/Jobs/GenerateReportExportJob.php`
  - **Before** (`BaReportExportService.php:192-195`):
    ```php
            } catch (Throwable $e) {
                Log::error('BA report export failed', ['export_id' => $export->id, 'error' => $e->getMessage()]);
                $this->markFailed($export, $e->getMessage());
            }
    ```
  - **After:**
    ```php
            } catch (Throwable $e) {
                Log::error('BA report export failed', ['export_id' => $export->id, 'error' => $e->getMessage()]);
                $this->markFailed($export, 'The export could not be generated.');
            }
    ```
  - **Also — same fix in the job** (`GenerateReportExportJob.php:48`):
    - **Before:**
      ```php
              app(BaReportExportService::class)->markFailed($export, 'Export job failed: '.($exception?->getMessage() ?? 'unknown error'));
      ```
    - **After:**
      ```php
              app(BaReportExportService::class)->markFailed($export, 'The export could not be generated.');
      ```
  - **Verify:** `grep -rn "markFailed(\$export, \$e->getMessage())\|markFailed(\$export, 'Export job failed" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php Modules/BehaviouralAssessment/app/Jobs/GenerateReportExportJob.php`
  - **Expect:** no output.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

(none)

## 3. Errors, transactions & services (F1/F2/F8)

- [ ] **BAEXP-03** · H · TXN-01 · `BaReportExportService.php:129-150, 219-224` — make each two-table write atomic: wrap `request()`'s create + its audit in one transaction, and each swept row's update + its audit in one transaction.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php`
  - **Before** (`BaReportExportService.php:129-150`):
    ```php
            $export = BaReportExport::create([
                'report_code' => $reportCode,
                'report_name' => self::REPORTS[$reportCode]['name'],
                'filters_json' => $filters,
                'format' => $format,
                'is_anonymised' => $anonymised,
                'row_count' => $rowCount,
                'mode' => $async ? BaReportExport::MODE_ASYNC : BaReportExport::MODE_SYNC,
                'status' => $async ? BaReportExport::STATUS_QUEUED : BaReportExport::STATUS_GENERATING,
                'requested_by' => $actorId,
                'requested_at' => now(),
                'ip_address' => $ip,
                'is_active' => true,
                'created_by' => $actorId,
                'updated_by' => $actorId,
            ]);

            BaAuditLog::log(BaAuditLog::ENTITY_EXPORT, (int) $export->id, 'requested', null,
                $reportCode.' '.$format.($anonymised ? ' anonymised' : '').' ('.$rowCount.' rows, '.$export->mode.')');

            if ($async) {
    ```
  - **After:**
    ```php
            $export = DB::transaction(function () use ($reportCode, $filters, $format, $anonymised, $rowCount, $async, $actorId, $ip) {
                $export = BaReportExport::create([
                    'report_code' => $reportCode,
                    'report_name' => self::REPORTS[$reportCode]['name'],
                    'filters_json' => $filters,
                    'format' => $format,
                    'is_anonymised' => $anonymised,
                    'row_count' => $rowCount,
                    'mode' => $async ? BaReportExport::MODE_ASYNC : BaReportExport::MODE_SYNC,
                    'status' => $async ? BaReportExport::STATUS_QUEUED : BaReportExport::STATUS_GENERATING,
                    'requested_by' => $actorId,
                    'requested_at' => now(),
                    'ip_address' => $ip,
                    'is_active' => true,
                    'created_by' => $actorId,
                    'updated_by' => $actorId,
                ]);

                BaAuditLog::log(BaAuditLog::ENTITY_EXPORT, (int) $export->id, 'requested', null,
                    $reportCode.' '.$format.($anonymised ? ' anonymised' : '').' ('.$rowCount.' rows, '.$export->mode.')');

                return $export;
            });

            if ($async) {
    ```
  - **Also — `expireDue()`** (`BaReportExportService.php:219-224`, leave the file delete outside the transaction per TXN-03):
    - **Before:**
      ```php
                      if ($export->file_path && $this->disk()->exists($export->file_path)) {
                          $this->disk()->delete($export->file_path);
                      }
                      $export->forceFill(['status' => BaReportExport::STATUS_EXPIRED, 'updated_by' => BaActor::id()])->save();
                      BaAuditLog::log(BaAuditLog::ENTITY_EXPORT, (int) $export->id, 'status',
                          BaReportExport::STATUS_READY, BaReportExport::STATUS_EXPIRED, 'File removed after export_expiry_days (BR-BA-096).');
      ```
    - **After:**
      ```php
                      if ($export->file_path && $this->disk()->exists($export->file_path)) {
                          $this->disk()->delete($export->file_path);
                      }
                      DB::transaction(function () use ($export) {
                          $export->forceFill(['status' => BaReportExport::STATUS_EXPIRED, 'updated_by' => BaActor::id()])->save();
                          BaAuditLog::log(BaAuditLog::ENTITY_EXPORT, (int) $export->id, 'status',
                              BaReportExport::STATUS_READY, BaReportExport::STATUS_EXPIRED, 'File removed after export_expiry_days (BR-BA-096).');
                      });
      ```
  - **Verify:** `grep -n "DB::transaction" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php`
  - **Expect:** two hits (around lines 129 and 222).
  - **Effort:** M

- [ ] **BAEXP-02** · M · ERR-05 · `BaReportExportService.php:193` — log the exception object so the trace survives.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php`
  - **Before** (`BaReportExportService.php:193`):
    ```php
                Log::error('BA report export failed', ['export_id' => $export->id, 'error' => $e->getMessage()]);
    ```
  - **After:**
    ```php
                report($e);
    ```
  - **Also (same file):** delete the now-unused import `use Illuminate\Support\Facades\Log;` (line 14 — it is the only `Log::` use in the file).
  - **Verify:** `grep -n "Log::\|use Illuminate\\\\Support\\\\Facades\\\\Log" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BAEXP-04** · M · SVC-01 · ⚠ SHARED · `BaReportExportService.php:106,123-127` + `BaReportController.php:822-827` — stop reading the HTTP request inside the service; pass the client IP in from the controller.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php`, `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Before** (`BaReportExportService.php:123-127`):
    ```php
            $ip = null;
            if (app()->bound('request') && ! app()->runningInConsole() && request()->ip() !== null) {
                $packed = @inet_pton(request()->ip());
                $ip = $packed === false ? null : $packed;
            }
    ```
  - **After:**
    ```php
            $packed = $ipAddress !== null ? @inet_pton($ipAddress) : false;
            $ip = $packed === false ? null : $packed;
    ```
  - **Also — the signature** (`BaReportExportService.php:106`):
    - **Before:**
      ```php
          public function request(string $reportCode, array $filters, string $format, bool $anonymised): BaReportExport
      ```
    - **After:**
      ```php
          public function request(string $reportCode, array $filters, string $format, bool $anonymised, ?string $ipAddress = null): BaReportExport
      ```
  - **Also — the caller** (`BaReportController.php:822-827`):
    - **Before:**
      ```php
                  $export = $exports->request(
                      $data['report_code'],
                      (array) ($data['filters'] ?? []),
                      $data['format'],
                      (bool) ($data['anonymised'] ?? false),
                  );
      ```
    - **After:**
      ```php
                  $export = $exports->request(
                      $data['report_code'],
                      (array) ($data['filters'] ?? []),
                      $data['format'],
                      (bool) ($data['anonymised'] ?? false),
                      request()->ip(),
                  );
      ```
  - **Verify:** `grep -n "request()->ip\|runningInConsole\|bound('request')" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BAEXP-05** · M · SVC-02 · `BaReportExportService.php:86,450,530,622` — inject `BaFrameworkSnapshotService` instead of pulling it with `app()` mid-method.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php`
  - **Before** (`BaReportExportService.php:450` — the same line appears at 530 and 622):
    ```php
            $frozen = app(BaFrameworkSnapshotService::class)->lockedFramework($period);
    ```
  - **After:**
    ```php
            $frozen = $this->snapshots->lockedFramework($period);
    ```
  - **Also — the constructor** (`BaReportExportService.php:86`):
    - **Before:**
      ```php
          public function __construct(private BaNotificationService $notifications) {}
      ```
    - **After:**
      ```php
          public function __construct(
              private BaNotificationService $notifications,
              private BaFrameworkSnapshotService $snapshots,
          ) {}
      ```
  - **Also (same file):** replace the identical line at 530 and at 622 the same way (three call sites total).
  - **Verify:** `grep -n "app(BaFrameworkSnapshotService\|private BaFrameworkSnapshotService" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php`
  - **Expect:** exactly one hit — the constructor property `private BaFrameworkSnapshotService $snapshots`.
  - **Effort:** S

## 4. Authorization (F3)

(none — the controller's own authorization is correct; BAEXP-07 is accepted in §10)

## 5. Validation, routes, models (F4/F5/F7)

(none — all clean)

## 6. Queries & performance (F9)

- [ ] **BAEXP-06** · M · QRY-01 · `BaReportExportService.php:255-272` — memoise the filter-label lookups so a listing row does not re-query the same period/class/category.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php`
  - **Before** (`BaReportExportService.php:255-272`):
    ```php
        public function describeFilters(BaReportExport $export): string
        {
            $parts = [];
            foreach ((array) $export->filters_json as $key => $value) {
                if ($value === null || $value === '') {
                    continue;
                }
                $label = match ($key) {
                    'period_id' => 'Period: '.(BaAssessmentPeriod::whereKey($value)->value('name') ?? '#'.$value),
                    'class_section_id' => 'Class: '.$this->classSectionLabel((int) $value),
                    'student_id' => 'Student: '.(Student::find($value)?->full_name ?? '#'.$value),
                    'category_id' => 'Category: '.(BaCategory::whereKey($value)->value('name') ?? '#'.$value),
                    default => ucwords(str_replace('_', ' ', (string) $key)).': '.ucwords(str_replace('_', ' ', (string) $value)),
                };
                $parts[] = $label;
            }

            return $parts === [] ? 'All' : implode(' · ', $parts);
        }
    ```
  - **After:**
    ```php
        /** @var array<string, string> Filter-value labels memoised for this instance. */
        private array $filterLabels = [];

        public function describeFilters(BaReportExport $export): string
        {
            $parts = [];
            foreach ((array) $export->filters_json as $key => $value) {
                if ($value === null || $value === '') {
                    continue;
                }
                $parts[] = $this->filterLabel((string) $key, $value);
            }

            return $parts === [] ? 'All' : implode(' · ', $parts);
        }

        /** Resolve one filter key to a label; memoised so listing rows reuse one lookup per value. */
        private function filterLabel(string $key, mixed $value): string
        {
            $cacheKey = $key.':'.(is_scalar($value) ? (string) $value : json_encode($value));
            if (array_key_exists($cacheKey, $this->filterLabels)) {
                return $this->filterLabels[$cacheKey];
            }

            return $this->filterLabels[$cacheKey] = match ($key) {
                'period_id' => 'Period: '.(BaAssessmentPeriod::whereKey($value)->value('name') ?? '#'.$value),
                'class_section_id' => 'Class: '.$this->classSectionLabel((int) $value),
                'student_id' => 'Student: '.(Student::find($value)?->full_name ?? '#'.$value),
                'category_id' => 'Category: '.(BaCategory::whereKey($value)->value('name') ?? '#'.$value),
                default => ucwords(str_replace('_', ' ', $key)).': '.ucwords(str_replace('_', ' ', (string) $value)),
            };
        }
    ```
  - **Verify:** `grep -n "private array \$filterLabels\|private function filterLabel" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php`
  - **Expect:** two hits — the property declaration and the `filterLabel()` method.
  - **Effort:** S

## 7. Views (F10)

(none — this controller renders no view)

## 8. Style (F12) — one item per file

(none — the in-scope files are already Pint-clean; the fixer runs `vendor/bin/pint <touched file> --format agent` after each item per standing rules)

## 9. Deferred / decisions

(none)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BAEXP-07 | `download()` loads the export before the authorization decision, so a non-owner sees 403 (id exists) vs 404 (id absent). The owner half of the check inherently needs the row, the route is tenant-scoped and `whereNumber`-bounded, and only the existence of an id inside the viewer's own tenant is revealed — accepted as low. Restructuring would add no security value. |
