# Final Audit — BehaviouralAssessment / BaReportExportController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportExportController.php` (63 lines, 1 public method `download` plus `__construct`)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | GET `behavioural-assessment/report-exports/{export}/download` — the file download. This controller renders no page: it either streams the stored file or redirects to the Reports page Exports tab. |
| Menu path | Behavioural Assessment → **Reports** page → **Exports** tab (`behavioural-assessment/reports-page?tab=exports`) → the per-row Download icon. |
| Who uses it | The user who requested the export, or anyone holding `tenant.behavioural-assessment.report-exports.viewAny` (seeded on the test tenant, permission id 5011, to roles 1 Super Admin, 2 School Admin, 3 Principal). The export request itself needs `tenant.behavioural-assessment.reports.export` (permission id 5010, roles 1–2). |
| What a user does here | Clicks Download on an export row in the register. The controller loads the export, checks the viewer owns it or holds the "all exports" permission, confirms the row is `ready` and unexpired with its file still on disk, writes one `downloaded` audit row, then streams the private file. |
| Tables written | `ba_audit_log` (one INSERT per successful download, via `BaAuditLog::log`). The `ba_report_exports` row is read-only in this controller. |
| Tables read | `ba_report_exports` (the row being downloaded, through `findOrFail`). |
| Live data | `ba_report_exports`: **0 live / 0 trashed**; `ba_audit_log`: 0 rows — measured on the single test tenant `00000000-0000-4000-8000-000000000001`. The register is empty today, so the download path is only exercised by newly requested exports. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

The controller itself is **production-ready** — it is thin, correctly tenanted, correctly authorises (owner or `report-exports.viewAny`), uses a `whereNumber` route parameter, and does the one GET write (the download audit) that BR-BA-096 requires. The single worst finding is not in the controller but in the 671-line service it drives: on a failed generation the raw exception text is written to the user-visible `ba_report_exports.error_message` column and rendered in the Exports register (and echoed in a flash by the export POST), which leaks SQL/table/path detail — a Blocker. The service also writes two tables per logical operation without a transaction and reaches the HTTP layer for the client IP. Rough effort: **M** — one focused service-doc pass (error text, two transactions, IP pass-in, memoise the filter labels); no controller rewrite.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 1 | 4 | 1 | 0 | 7 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BAEXP-01, BAEXP-02 | F8 Services/Jobs | BAEXP-04, BAEXP-05 |
| F2 Transactions/Audit | BAEXP-03 | F9 Queries/Perf | BAEXP-06 |
| F3 Authorization | BAEXP-07 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | clean |
| F6 Controller shape | clean | F13 Deep read | BAEXP-03 (race/order) |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportExportController.php` | controller | 63 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php` | service | 671 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Models/BaReportExport.php` | model | 96 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Jobs/GenerateReportExportJob.php` | job | 51 | this report | ✅ (dispatched by the service; second ERR-01 site) |
| 5 | `Modules/BehaviouralAssessment/app/Exports/BaReportDatasetExport.php` | export | 50 | this report | ✅ (clean) |
| 6 | `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` | model | 203 | ↗ [tarun/BehaviouralAssessment-done/BaAuditLogController-done](../BaAuditLogController-done/01-report.md) | ↗ linked (usage checked) |
| 7 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support helper | 45 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked (usage checked) |
| 8 | `Modules/BehaviouralAssessment/app/Support/BaDispatch.php` | support helper | 32 | ↗ [tarun/BehaviouralAssessment-done/BaNotificationController-done](../BaNotificationController-done/01-report.md) | ↗ linked (usage checked) |
| 9 | `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php` | service (only `evaluateExportReady()` reached) | 1065 | ↗ [tarun/BehaviouralAssessment-done/BaNotificationController-done](../BaNotificationController-done/01-report.md) | ↗ linked (usage checked) |
| 10 | `Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php` | service | 443 | ❌ not audited — a shared BA service reached by 3 controllers and 3 other services; its ownership belongs to the main session | ❌ |
| 11 | `Modules/BehaviouralAssessment/app/Http/Requests/BaReportExportRequest.php` | FormRequest | 53 | ❌ **not used by this controller** (its only caller is `BaReportController::export()`); not registered here | ❌ |
| 12 | `Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_exports.blade.php` | view partial | 136 | ❌ rendered by `BaReportController` (reports-page), not by this controller | ❌ (referenced only as the `error_message` render site) |

Other-module classes (`Modules\StudentProfile\Models\Student`, `Modules\SchoolSetup\Models\ClassSection`/`User`, `Illuminate\Support\Facades\Storage`, `Maatwebsite\Excel`, `Barryvdh\DomPdf`) are common per §4.2 — referenced, not audited.

No pre-applied files.

## 4. Routes

```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); foreach($r as $x){ if(str_contains($x["action"],"BaReportExportController@")) printf("%-7s %-60s %-50s %s\n",$x["method"],$x["uri"],$x["name"],$x["action"]); }'
GET|HEAD behavioural-assessment/report-exports/{export}/download      behavioural-assessment.report-exports.download     Modules\BehaviouralAssessment\Http\Controllers\BaReportExportController@download
```

The route lives in `Modules/BehaviouralAssessment/routes/web.php:164`, inside the module `RouteServiceProvider` group (`web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:BehaviouralAssessment`, `auth`, `verified`) with prefix `behavioural-assessment` and name prefix `behavioural-assessment.`. `{export}` is constrained with `->whereNumber('export')` and the handler argument is `int $export` (numeric strings coerce; a non-numeric segment 404s at the constraint).

Unrouted public methods: none (`download` is the only public method besides the promoted-property constructor, and it is routed).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `download` | 35 | GET `behavioural-assessment/report-exports/{export}/download` | owner OR `Gate::allows('tenant.behavioural-assessment.report-exports.viewAny')` | none — a single INSERT needs no transaction | `BaAuditLog::log(..., 'downloaded', ...)` at line 59 (not the `activityLog()` helper) | `ba_audit_log` | BAEXP-07 |
| `__construct` | 29 | — (constructor injects `BaReportExportService`) | — | — | — | — | — |

## 6. Findings

### F1 — Errors

#### BAEXP-01 · B · ERR-01 — raw exception text is stored in the user-visible `error_message` column

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak.* (Secondary ERR-05 (M): log the exception object, not `getMessage()`.) |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:192-195`, method `generate()`; also `Modules/BehaviouralAssessment/app/Jobs/GenerateReportExportJob.php:48` (`failed()`); rendered at `Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_exports.blade.php:100-101`; echoed in a flash at `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:844`. |
| **Root cause** | `generate()` catches every `Throwable` and passes `$e->getMessage()` into `markFailed()`, which writes it into `ba_report_exports.error_message`. The Exports tab renders that column (`title="{{ $ex->error_message }}"` plus a 60-char snippet) and the export POST flash echoes it. A `QueryException` from `dataset()` carries the SQL statement and the table/column names; a storage failure carries the private path. The message is not a curated business message — it is raw infrastructure text. |
| **Consequence** | When any export fails (schema drift, a bad filter, a disk error) the user sees database/SQL or file-path text in the Exports register and in the red flash instead of "the export could not be generated". |
| **Reproduce** | Request any report export whose generation throws (e.g. a report query that fails), then open `behavioural-assessment/reports-page?tab=exports` — the failed row shows the raw reason under its status badge. |
| **Fix approach** | Keep the reason for the log, not for the column: in `generate()` call `report($e)` and `markFailed($export, 'The export could not be generated.')`; in the job's `failed()` write the same fixed sentence. |
| **Plan item** | BAEXP-01 in `02-fix-plan.md` §1 |

```php
// BaReportExportService.php:192-195 — CURRENT
        } catch (Throwable $e) {
            Log::error('BA report export failed', ['export_id' => $export->id, 'error' => $e->getMessage()]);
            $this->markFailed($export, $e->getMessage());
        }
```

**Evidence**
```
$ grep -n "getMessage\|markFailed" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php Modules/BehaviouralAssessment/app/Jobs/GenerateReportExportJob.php Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:193:            Log::error('BA report export failed', ['export_id' => $export->id, 'error' => $e->getMessage()]);
Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:194:            $this->markFailed($export, $e->getMessage());
Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:198:    public function markFailed(BaReportExport $export, string $reason): void
Modules/BehaviouralAssessment/app/Jobs/GenerateReportExportJob.php:48:            app(BaReportExportService::class)->markFailed($export, 'Export job failed: '.($exception?->getMessage() ?? 'unknown error'));
Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:829:            Log::error('BA report export request failed', ['report' => $data['report_code'], 'error' => $e->getMessage()]);
$ grep -n "error_message" Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_exports.blade.php
100:                            @if($ex->status === 'failed' && $ex->error_message)
101:                                <div class="text-danger" style="font-size:10px" title="{{ $ex->error_message }}">{{ \Illuminate\Support\Str::limit($ex->error_message, 60) }}</div>
```

#### BAEXP-02 · M · ERR-05 — the failure log keeps only the message, losing the trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace.* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:193`, method `generate()` |
| **Root cause** | The catch hand-builds a log context array with only `error => $e->getMessage()`. Laravel's `report($e)`/`Log::error('…', ['exception' => $e])` records the class, trace and previous exceptions; the message alone records none of them, so a production failure cannot be debugged from the log. |
| **Consequence** | When an export fails in production the log line shows the sentence but not which query, class or line raised it; the team cannot reproduce or fix it from the log. |
| **Reproduce** | Static only — the branch is on the failure path; would need a forced export failure and a look at `storage/logs/laravel.log`. |
| **Fix approach** | Replace the hand-built log line with `report($e)` and drop the now-unused `Log` import. |
| **Plan item** | BAEXP-02 in `02-fix-plan.md` §3 |

```php
// BaReportExportService.php:193 — CURRENT
            Log::error('BA report export failed', ['export_id' => $export->id, 'error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "Log::" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
193:            Log::error('BA report export failed', ['export_id' => $export->id, 'error' => $e->getMessage()]);
$ grep -n "use Illuminate\\\\Support\\\\Facades\\\\Log" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
14:use Illuminate\Support\Facades\Log;
```

### F2 — Transactions and audit

#### BAEXP-03 · H · TXN-01 — `request()` and `expireDue()` each write two tables without a transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (two models, a model + its audit row, a model + pivot) runs inside one `DB::transaction`; every mutation that calls the audit log counts as multi-table.* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:129-147`, method `request()` (INSERT `ba_report_exports` + INSERT `ba_audit_log`); and `:214-226`, method `expireDue()` (UPDATE `ba_report_exports` + INSERT `ba_audit_log` per row). |
| **Root cause** | Neither method uses a transaction, and the whole service contains none (`grep` finds no `DB::transaction` anywhere). In `request()` the disclosure row is created (line 129) and its `requested` audit row written (line 146) as two separate commits: if the audit insert fails, an export exists with no disclosure record. In `expireDue()` each swept row is updated (line 222) and audited (line 223) as two commits, so a mid-run failure leaves rows marked `expired` with no `status` audit row. |
| **Consequence** | A failure between the two writes breaks the BR-BA-096 disclosure guarantee: the register shows an export (or an expiry) that the audit trail never recorded, and no rollback restores it. |
| **Reproduce** | Static only — needs a forced failure between the two writes (e.g. an audit-table write error); both are on the write path. |
| **Fix approach** | Wrap the create + its audit in one `DB::transaction` in `request()` (generation stays outside, since it writes a file — TXN-03); wrap the row update + its audit in one `DB::transaction` per row in `expireDue()`, leaving the file delete outside the transaction. |
| **Plan item** | BAEXP-03 in `02-fix-plan.md` §3 |

```php
// BaReportExportService.php:129-150 — CURRENT request() writes
        $export = BaReportExport::create([
            'report_code' => $reportCode,
            'report_name' => self::REPORTS[$reportCode]['name'],
            'filters_json' => $filters,
            'format' => $format,
            'is_anonymised' => $anonymised,
            'row_count' => $rowCount,
            'mode' => $async ? BaReportExport::MODE_ASYNC : BaReportExport::MODE_SYNC,
            'status' => $async ? BaReportExport::STATUS_QUEUED : BaReportExport::STATUS_GENERATING,
            'requested_by' => $actorId,
            'requested_at' => now(),
            'ip_address' => $ip,
            'is_active' => true,
            'created_by' => $actorId,
            'updated_by' => $actorId,
        ]);

        BaAuditLog::log(BaAuditLog::ENTITY_EXPORT, (int) $export->id, 'requested', null,
            $reportCode.' '.$format.($anonymised ? ' anonymised' : '').' ('.$rowCount.' rows, '.$export->mode.')');

        if ($async) {
```

**Evidence**
```
$ grep -n "DB::transaction\|beginTransaction" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
(no output — the service has no transaction at all)
$ grep -n "BaReportExport::create\|BaAuditLog::log\|->save()\|->delete(" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
129:        $export = BaReportExport::create([
146:        BaAuditLog::log(BaAuditLog::ENTITY_EXPORT, (int) $export->id, 'requested', null,
165:        $export->forceFill(['status' => BaReportExport::STATUS_GENERATING, 'updated_by' => BaActor::id()])->save();
191:            ])->save();
205:        ])->save();
220:                    $this->disk()->delete($export->file_path);
222:                $export->forceFill(['status' => BaReportExport::STATUS_EXPIRED, 'updated_by' => BaActor::id()])->save();
223:                BaAuditLog::log(BaAuditLog::ENTITY_EXPORT, (int) $export->id, 'status',
```

### F3 — Authorization

clean for the controller's own routing — `download()` authorises with `abort_unless($isOwner || Gate::allows(...), 403)` before streaming, the string is the service constant `BaReportExportService::VIEW_ALL_PERMISSION`, it matches `config/permissionslist.php:1442` (`'behavioural-assessment.report-exports' => ['viewAny']`, flattened to `tenant.behavioural-assessment.report-exports.viewAny`), and it is seeded with an exact-name query (1 `sys_permissions` row id 5011, 3 role bindings). The only AUTH-02 nuance is BAEXP-07 below.

#### BAEXP-07 · L · AUTH-02 — the export row is loaded before the authorization decision (404/403 existence leak)

| Field | Value |
|---|---|
| **Rule** | AUTH-02 (H) — *authorize before loading records; loading first leaks whether an id exists (404 vs 403).* **Lowered to L**: the route is tenant-scoped, `whereNumber`-bounded and behind `auth`; only the existence of an export id inside the viewer's own tenant is revealed, never another tenant's. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportExportController.php:37-44`, method `download()` |
| **Root cause** | `BaReportExport::findOrFail($export)` runs first; a missing id 404s and an id that exists but belongs to another user 403s. The coarse permission (`Gate::allows(VIEW_ALL_PERMISSION)`) could be evaluated before the load, but the owner half of the check inherently needs the row, so this is a design trade-off rather than an oversight. |
| **Consequence** | An authenticated user can tell that an export id exists (403) versus does not (404) within their own tenant — a minor existence oracle, no data exposure. |
| **Reproduce** | As a user without `report-exports.viewAny`, GET `behavioural-assessment/report-exports/1/download` (401/404 for an absent id) versus `/2/download` for an id that exists but is not yours (403). |
| **Fix approach** | Accept as-is (tenant-scoped, owner model needs the row) or, if strict, gate the `viewAny` half before the load and keep a single `findOrFail` after it. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// BaReportExportController.php:37-44 — CURRENT
        $row = BaReportExport::findOrFail($export);

        $isOwner = (int) $row->requested_by === (int) Auth::id();
        abort_unless(
            $isOwner || Gate::allows(BaReportExportService::VIEW_ALL_PERMISSION),
            403,
            'You can only download exports you requested.'
        );
```

**Evidence**
```
$ grep -n "findOrFail\|abort_unless\|Gate::allows\|requested_by" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportExportController.php
37:        $row = BaReportExport::findOrFail($export);
39:        $isOwner = (int) $row->requested_by === (int) Auth::id();
40:        abort_unless(
41:            $isOwner || Gate::allows(BaReportExportService::VIEW_ALL_PERMISSION),
```

### F4 — Validation and input

clean — this controller takes no request body, only the `whereNumber` route parameter typed as `int $export`; there is no FormRequest to run and no field to type (VAL-01..07 n/a). The export POST is validated by `BaReportExportRequest` (owned by the `BaReportController` report).

### F5 — Routes

clean — the route is GET with no state-changing verb (RTE-01: the only side effect is the append-only `downloaded` audit row the regulation requires; no restore/delete/toggle). It points at a method that exists (RTE-02, `php -l` + `route:list`); every public method is routed (RTE-03); the parameter name `{export}` matches the argument and is `whereNumber`-constrained, so no unbound-model INSERT risk (RTE-03 / module-finalization §3.3.1); reads are GET (RTE-04); the tenant middleware group is present (RTE-05, `RouteServiceProvider.php:25-33`); no `Route::resource` shares the prefix (RTE-06 n/a). Proved by the §4 route probe.

### F6 — Controller shape

clean — 63 lines / 2 public methods (CTL-01 n/a); no method over 80 lines (CTL-02 n/a); return type `StreamedResponse|RedirectResponse` present (CTL-04); no copy-paste (CTL-05); business logic lives in the service — the controller loads, authorises and delegates (CTL-06); no `compact()`, no `request()` helper, no `dd/dump` (CTL-07/08/09); no dead code (CTL-10).

### F7 — Models

clean — `BaReportExport` declares `$fillable` with nothing sensitive (MDL-01); `$casts` cover every boolean (`is_anonymised`, `is_active`), datetime (`requested_at`, `completed_at`, `expires_at`, `deleted_at`), integer (`row_count`, `file_size_bytes`, `requested_by`, `created_by`, `updated_by`) and json (`filters_json`) column (MDL-02); `$table = 'ba_report_exports'` exists in migration `database/migrations/tenant/2026_06_16_130639_create_ba_report_exports_table.php` (MDL-07); the table has `deleted_at` and the model uses `SoftDeletes` — consistent, and there is no unique index to collide with (no soft-delete × unique trap, VAL-04 n/a); no `InteractsWithMedia` (MDL-05 n/a); `requestedBy()`/`createdBy()` are return-typed and resolve. Proved in tinker:

**Evidence**
```
$ php artisan tinker --execute '…tenancy()->initialize(…); (new BaReportExport)->requestedBy()->getRelated()/toSql()…'
requestedBy related: Modules\SchoolSetup\Models\User
requestedBy sql: select * from `sys_users` where `sys_users`.`id` is null and `sys_users`.`deleted_at` is null
createdBy related: Modules\SchoolSetup\Models\User
table ba_report_exports exists: yes
$ php artisan tinker --execute '…BaReportExport::withTrashed()->count()…'
ba_report_exports total_trashed: 0   active: 0   onlyTrashed: 0
```

### F8 — Services and jobs

clean except BAEXP-04 and BAEXP-05. The service does not write on a read path other than the intentional audit (`request`/`generate`/`expireDue` are the write methods; `dataset`, `listing`, `describeFilters`, `countRows`, `normaliseFilters`, `isDownloadable`, `downloadName`, `classPseudonym*`, `*Pseudonym` are reads). No duplicated operation (SVC-04). The job declares `$tries = 1` and `$timeout = 600` and stores only `exportId` (JOB-02/JOB-05); it runs through `BaDispatch`, which is `dispatchSync` by default and carries tenancy via `QueueTenancyBootstrapper` when async (JOB-01).

#### BAEXP-04 · M · SVC-01 — the export service reads the current HTTP request to capture the client IP

| Field | Value |
|---|---|
| **Rule** | SVC-01 (M) — *services don't touch HTTP: no `request()`, `session()`, `redirect()`, `response()`, `back()`.* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:123-127`, method `request()` |
| **Root cause** | The service reaches into the HTTP layer (`app()->bound('request')`, `request()->ip()`) to fill `ba_report_exports.ip_address`. A service should be given its inputs; the caller (the controller) is the layer that knows the request. |
| **Consequence** | The service cannot be used cleanly from a console command or a differently-sourced caller, and the IP silently becomes `null` when `runningInConsole()` is true — the audit column loses data without any signal. |
| **Reproduce** | Static only — the HTTP read is at the top of `request()`; behaviour is differential (web vs console). |
| **Fix approach** | Add `?string $ipAddress = null` to `request()`, build the packed binary from it, and have `BaReportController::export()` pass `request()->ip()`. |
| **Plan item** | BAEXP-04 in `02-fix-plan.md` §3 |

```php
// BaReportExportService.php:123-127 — CURRENT
        $ip = null;
        if (app()->bound('request') && ! app()->runningInConsole() && request()->ip() !== null) {
            $packed = @inet_pton(request()->ip());
            $ip = $packed === false ? null : $packed;
        }
```

**Evidence**
```
$ grep -n "request()->ip\|runningInConsole\|bound('request')" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
124:        if (app()->bound('request') && ! app()->runningInConsole() && request()->ip() !== null) {
125:            $packed = @inet_pton(request()->ip());
```

#### BAEXP-05 · M · SVC-02 — `BaFrameworkSnapshotService` is pulled with `app()` mid-method instead of constructor injection

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection — not `new FooService()` or `app(Foo::class)` mid-method.* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:450`, `:530`, `:622` (methods `classDataset()`, `categoryDataset()`, `overlayFrozen()`) |
| **Root cause** | The service already injects `BaNotificationService` through its constructor, but resolves `BaFrameworkSnapshotService` with the `app()` helper at three call sites. `BaFrameworkSnapshotService` has no constructor of its own, so injecting it is safe and would not create a cycle. |
| **Consequence** | The dependency is invisible in the class signature, cannot be swapped in a test, and is re-resolved at each call site rather than once per instance. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `private BaFrameworkSnapshotService $snapshots` to the constructor and replace the three `app(BaFrameworkSnapshotService::class)->lockedFramework($period)` calls with `$this->snapshots->lockedFramework($period)` (the static `categoryModels`/`overlay` calls are unchanged). |
| **Plan item** | BAEXP-05 in `02-fix-plan.md` §3 |

```php
// BaReportExportService.php:450 — CURRENT (also at 530, 622)
        $frozen = app(BaFrameworkSnapshotService::class)->lockedFramework($period);
```

**Evidence**
```
$ grep -n "app(BaFrameworkSnapshotService" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
450:        $frozen = app(BaFrameworkSnapshotService::class)->lockedFramework($period);
530:        $frozen = app(BaFrameworkSnapshotService::class)->lockedFramework($period);
622:        $frozen = app(BaFrameworkSnapshotService::class)->lockedFramework($period);
```

### F9 — Queries and performance

clean except BAEXP-06. `listing()` paginates at 10 with a distinct page name `ex_page` and `withQueryString()` (QRY-02/13); aggregates use `selectRaw(...)` with `groupBy`/`withCount` (QRY-05); no interpolated raw SQL (QRY-11). Scanner candidate QRY-07 in `expireDue()` (`->delete()`/`->save()` per row) is rejected: the per-row file delete and per-row audit INSERT are inherent to a per-row sweep with a preserved audit trail, not a bulk-write opportunity.

#### BAEXP-06 · M · QRY-01 — `describeFilters()` re-resolves a label per filter key on every listing row

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops.* **Lowered to M**: the loop is bounded by the ≤7 filter keys of one report and the listing shows ≤10 rows, so up to ~70 small indexed lookups per page — a genuine N+1, but not an unbounded scan. |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:258-269`, method `describeFilters()` |
| **Root cause** | The method `match`es each filter key to a `Student::find()`, `BaAssessmentPeriod::whereKey()`, `BaCategory::whereKey()` or `classSectionLabel()` lookup, and the Exports partial calls `describeFilters($ex)` once per row (`_exports.blade.php:92`). The same period/class/category id repeats across rows, so the identical lookup runs again for every row. |
| **Consequence** | The Exports tab issues a burst of small queries proportional to rows × filters; on a full page of 10 exports up to ~70 extra queries where a handful would do. |
| **Reproduce** | Open `behavioural-assessment/reports-page?tab=exports` with several exports sharing a period; inspect the query log. |
| **Fix approach** | Extract the per-key resolution into a `filterLabel()` helper and memoise labels in a per-instance array. The blade resolves one service instance for the whole page (`_exports.blade.php:20`), so the memo is shared across the rows; the service is not a singleton, so the memo cannot leak across tenants. |
| **Plan item** | BAEXP-06 in `02-fix-plan.md` §6 |

```php
// BaReportExportService.php:258-272 — CURRENT
        foreach ((array) $export->filters_json as $key => $value) {
            if ($value === null || $value === '') {
                continue;
            }
            $label = match ($key) {
                'period_id' => 'Period: '.(BaAssessmentPeriod::whereKey($value)->value('name') ?? '#'.$value),
                'class_section_id' => 'Class: '.$this->classSectionLabel((int) $value),
                'student_id' => 'Student: '.(Student::find($value)?->full_name ?? '#'.$value),
                'category_id' => 'Category: '.(BaCategory::whereKey($value)->value('name') ?? '#'.$value),
                default => ucwords(str_replace('_', ' ', (string) $key)).': '.ucwords(str_replace('_', ' ', (string) $value)),
            };
            $parts[] = $label;
        }

        return $parts === [] ? 'All' : implode(' · ', $parts);
```

**Evidence**
```
$ grep -n "Student::find\|BaAssessmentPeriod::whereKey\|BaCategory::whereKey\|describeFilters" Modules/BehaviouralAssessment/app/Services/BaReportExportService.php
255:    public function describeFilters(BaReportExport $export): string
263:                'period_id' => 'Period: '.(BaAssessmentPeriod::whereKey($value)->value('name') ?? '#'.$value),
265:                'student_id' => 'Student: '.(Student::find($value)?->full_name ?? '#'.$value),
266:                'category_id' => 'Category: '.(BaCategory::whereKey($value)->value('name') ?? '#'.$value),
$ grep -n "describeFilters" Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_exports.blade.php
92:                        <td class="small text-muted" style="max-width:260px">{{ $exSvc->describeFilters($ex) }}</td>
```

### F10 — Views

clean for this controller — it renders no view; it streams a file or redirects. The `_exports.blade.php` partial is rendered by `BaReportController` (reports-page) and is named in §3/§8 as the render site of the BAEXP-01 leak.

### F11 — Security and tenancy

clean — `env()` is not used (SEC-01); the download streams a private file from the tenant `local` disk through an authorised, audited route (SEC-05), with the path built from `TenantPathPrefix::get()` (TEN-04); the model hides `ip_address` and stores it packed via `inet_pton` (SEC-02); no hard-coded ids (SEC-03). Tenancy isolation is provided by the `InitializeTenancyByDomain` middleware group (the model has no cross-tenant reach), and there is no cache/static cache to key (TEN-02 n/a).

### F12 — Style

clean — `declare(strict_types=1);` in the controller, model, service, job and export class (STY-01); Pint-clean:

**Evidence**
```
$ vendor/bin/pint --test --format agent Modules/BehaviouralAssessment/app/Http/Controllers/BaReportExportController.php
{"tool":"pint","result":"passed"}
```

One import per class (STY-05), camelCase names (STY-03), English comments without emoji (STY-04). The five new plan items add no style debt; the fixer runs Pint on each touched file.

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutation (method) | 1 wrong-data overwrite | 2 delete-before-store | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `download()` (INSERT `ba_audit_log`) | ok — append-only, never touches the row | ok — no deletes | ok — the only `downloaded` writer | ok — no soft-delete on `ba_audit_log` | ok — idempotent read; audit row per click is intended | ok — owner OR `viewAny`; tenant middleware | ok — redirect text matches `expired`/`failed`/`generating` | ok — read by the audit-log screen |
| service `request()` (INSERT `ba_report_exports` + `ba_audit_log`) | ok — one new row, no update | ok — nothing deleted | ok — the only export-request path | ok — no unique index on the table | ok — one row per POST; no check-then-act | ok — gated by `BaReportExportRequest` in the caller | ok — `requested` event literal accurate | ok — consumed by `listing()`/`download()` |
| service `generate()` (UPDATE `ba_report_exports` ×2 + file) | ok — status→generating→ready, guarded by the status check at line 161 | ok — no deletes | ok — one builder | ok — n/a | ok — status guard prevents a double generate | ok — called by `request()`/job after authorisation | BAEXP-01 (raw error text); success row accurate | ok — file consumed by `download()` |
| service `markFailed()` (UPDATE `ba_report_exports`) | ok — sets `failed` only | ok — no deletes | ok — one failure writer | ok — n/a | ok — last writer wins, acceptable for a terminal state | ok — not user-routed | BAEXP-01 (raw reason persisted) | ok — read by the register |
| service `expireDue()` (UPDATE `ba_report_exports` + INSERT `ba_audit_log`) | ok — ready→expired only | ok — file deleted before the status update, and the row is kept | ok — one sweeper | ok — n/a | BAEXP-03 (row/audit not atomic); file-delete vs `isDownloadable` TOCTOU is a low race (see §8) | ok — console sweep, not user-routed | ok — `status` event literal accurate | ok — consumed by the register |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:817-845` | `export()` wraps `$exports->request()` in a controller `try/catch (\Throwable)` and, on the failed branch (line 844), echoes `error_message` into a flash (`'The export failed: '.($export->error_message ?: 'unknown error').'.'`). The catch is a D1 violation and the flash is a third surface of the BAEXP-01 leak. | ERR-00 (D1), ERR-01 | BaReportController report |
| `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php:131-164` | `BaAuditLog::log()` itself reads `request()->ip()`/`request()->userAgent()` (an HTTP touch inside a model). Owned by the BaAuditLogController report; flagged here because the export service and controller rely on it. | SVC-01 (paradigm) | BaAuditLogController report |
| `Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php` | Shared BA service pulled via `app()` in this service and used by 3 controllers + 3 other services; not yet claimed in `00-CLASS-OWNERS.md`. | SVC-02 | main session (assign one owner) |
| `Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_exports.blade.php:20,92,100-101` | Resolves the service and renders `error_message`; it re-queries via `describeFilters` per row (BAEXP-06) and is the render site of BAEXP-01. Owned by the BaReportController report. | VIEW/F9 | BaReportController report |

## 8. Not covered, and why

- `Modules/BehaviouralAssessment/app/Http/Requests/BaReportExportRequest.php` was **not** audited: it is used only by `BaReportController::export()` (grep), not by this controller. It is not registered in `00-CLASS-OWNERS.md` (per the brief).
- `Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php` (443 lines) was not audited in full: it is a shared BA service reached through the export service; its ownership is for the main session to assign. Only its usage from `BaReportExportService` (the `app()` calls) was checked.
- `Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_exports.blade.php` was read for the `error_message`/`describeFilters` sites but is rendered by `BaReportController`, so its full view audit belongs to that controller's report.
- The `expireDue()` file-delete vs `isDownloadable()` existence check is a low TOCTOU (the sweep could delete the file between the check and the stream); it was not raised as a finding because the only effect is a one-off `FileNotFoundException` on an already-expired export, and the file-delete-in-transaction rule (TXN-03) constrains the fix.
- No browser click-through of the download (no authenticated session in this read-only audit; D4 anyway). The 403/404 existence behaviour in BAEXP-07 was reasoned from the code, not exercised.
- Queue behaviour (`GenerateReportExportJob` under `BA_ASYNC_JOBS`) was verified statically; the async path was not run.
