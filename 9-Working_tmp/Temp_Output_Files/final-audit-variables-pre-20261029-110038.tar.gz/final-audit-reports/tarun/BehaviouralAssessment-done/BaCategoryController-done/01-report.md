# Final Audit — BehaviouralAssessment / BaCategoryController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php` (537 lines, 15 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `xyz_school_00000000000040008000_202627` (the only tenant in the central `tenants` table, key `00000000-0000-4000-8000-000000000001`)

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | List + create dialog: `/behavioural-assessment/masters?tab=categories` (rendered by `BaDashboardController::masters`). `GET /behavioural-assessment/categories` redirects there. Direct create page: `/behavioural-assessment/categories/create`; edit: `/behavioural-assessment/categories/{id}/edit`; view: `/behavioural-assessment/categories/{id}`; trash: `/behavioural-assessment/categories/trash`. |
| Menu path | Behavioural Assessment → Masters → Categories tab |
| Who uses it | Super Admin and School Admin — the only two roles holding `tenant.behavioural-assessment.categories.*` (measured 2 role rows per verb in `sys_role_has_permissions_jnt`) |
| What a user does here | Defines the behavioural framework's categories (a code, a name, a positive/negative polarity, a weight and an optional parent category) and, inside each category, its criteria (the observable behaviours). Category and criteria are saved together from one form; the list is drag-reordered, rows are toggled active/inactive, deleted to trash, restored, or permanently deleted. |
| Tables written | `ba_categories` (INSERT/UPDATE/soft-delete/restore/force-delete), `ba_criteria` (INSERT/UPDATE/soft-delete), `sys_activity_logs` (one row per mutation through `activityLog()`) |
| Tables read | `ba_categories`, `ba_criteria`, `ba_assessment_ratings`, `ba_incidents`, `ba_class_category_jnt`, `ba_computed_scores`, `ba_comment_bank`, `sys_users` (via `BaActor`), `sys_permissions` / `sys_role_has_permissions_jnt` (gates) |
| Live data | `ba_categories` 9 live, 0 trashed; `ba_criteria` 58 live, 0 trashed (read-only tinker on the measured tenant) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Not production-ready as-is; 0 blockers, 2 HIGH — ready after the fixes, roughly a day.** The single worst finding is **BCAT-15**: `forceDelete` loads with `withTrashed()` and guards only `is_system`, so a `.forceDelete` holder (Super Admin / School Admin) who calls `DELETE /behavioural-assessment/categories/{id}/force-delete` with a **live** id bypasses the whole `usageReason()` guard that `destroy` enforces — and because `fk_ba_cc_cat` and `fk_ba_criteria_cat` are `ON DELETE CASCADE`, that call silently hard-deletes the category's class mappings and its criteria. The second HIGH is **BCAT-06**: `restore` is a `GET` that changes state, so a prefetcher or crawler can un-trash a category with no CSRF token. The controller is otherwise well-structured — every mutation already runs in a `DB::transaction` with `activityLog()` after the write, authorization is present and its permission keys exist, and the models and views are sound. The largest mechanical debt is that all ten write methods carry a controller `try/catch` that D1 forbids (**BCAT-01**). Rough effort: M (about a day), with one DECISION (route model binding).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 8 | 5 | 1 | 15 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BCAT-01, BCAT-02 | F8 Services/Jobs | clean — `grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b'` on the controller returns only `BaCategoryRequest` |
| F2 Transactions/Audit | BCAT-03, BCAT-11 | F9 Queries/Perf | BCAT-08, BCAT-09, BCAT-10 |
| F3 Authorization | BCAT-04 | F10 Views | clean — `grep -nE "Model::|DB::|->get\(\)|->count\(\)|where\(|{!!"` on the six in-scope blades returns only `$category->criteria->count()` on an eager-loaded collection |
| F4 Validation | BCAT-05 | F11 Security/Tenancy | clean — no `env()`, no secrets logged; `BaActor`'s static cache is keyed by database name (see F11) |
| F5 Routes | BCAT-06 | F12 Style | BCAT-12, BCAT-13, BCAT-14 |
| F6 Controller shape | BCAT-07 | F13 Deep read | BCAT-15 |
| F7 Models | clean — see F7 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php` | controller | 537 | this report | ✅ whole class |
| 2 | `Modules/BehaviouralAssessment/app/Models/BaCategory.php` | model | 131 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Models/BaCriterion.php` | model | 95 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryRequest.php` | FormRequest | 137 | this report (only this controller uses it) | ✅ |
| 5 | `Modules/BehaviouralAssessment/routes/web.php` lines 39-47 | routes | — | this report | ✅ |
| 6 | `Modules/BehaviouralAssessment/resources/views/category/create.blade.php` | blade | 138 | this report (`create()` renders it) | ✅ |
| 7 | `Modules/BehaviouralAssessment/resources/views/category/edit.blade.php` | blade | 176 | this report (`edit()` renders it) | ✅ |
| 8 | `Modules/BehaviouralAssessment/resources/views/category/show.blade.php` | blade | 155 | this report (`show()` renders it) | ✅ |
| 9 | `Modules/BehaviouralAssessment/resources/views/category/trash.blade.php` | blade | 76 | this report (`trashed()` renders it) | ✅ |
| 10 | `Modules/BehaviouralAssessment/resources/views/category/_criteria-grid.blade.php` | blade partial | 113 | this report (included by `edit`) | ✅ |
| 11 | `Modules/BehaviouralAssessment/resources/views/category/_criteria-row.blade.php` | blade partial | 61 | this report (included by `_criteria-grid`) | ✅ |
| 12 | `Modules/BehaviouralAssessment/resources/views/category/_create-fields.blade.php` | blade partial | 84 | BaDashboardController report (not yet written) | ↗ referenced (rendered by the masters create dialog, not by this controller) |
| 13 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | 45 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| — | `app/Traits/AuthorizesTenantFeature.php` | trait (app glue) | — | common | ↗ referenced — `BaCategoryRequest::authorize()` |
| — | `resources/views/components/backend/**` (layout, `breadcrum`, `form.input-text`, `form.status-switch`, `form.button-submit`, `table.action-trashed`) | components | — | common | ↗ referenced |

**Pre-applied 2026-10-10:** none — no file in scope appears in a module `PRE-APPLIED-*.md`.

## 4. Routes

```
GET|HEAD  behavioural-assessment/categories                              behavioural-assessment.categories.index      Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@index
POST      behavioural-assessment/categories                              behavioural-assessment.categories.store      Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@store
GET|HEAD  behavioural-assessment/categories/create                       behavioural-assessment.categories.create     Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@create
POST      behavioural-assessment/categories/reorder                      behavioural-assessment.categories.reorder    Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@reorder
GET|HEAD  behavioural-assessment/categories/trash                        behavioural-assessment.categories.trashed    Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@trashed
GET|HEAD  behavioural-assessment/categories/{category}                   behavioural-assessment.categories.show       Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@show
PUT|PATCH behavioural-assessment/categories/{category}                   behavioural-assessment.categories.update     Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@update
DELETE    behavioural-assessment/categories/{category}                   behavioural-assessment.categories.destroy    Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@destroy
POST      behavioural-assessment/categories/{category}/criteria          behavioural-assessment.categories.criteria.store   Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@storeCriterion
PUT       behavioural-assessment/categories/{category}/criteria/{criterion} behavioural-assessment.categories.criteria.update Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@updateCriterion
DELETE    behavioural-assessment/categories/{category}/criteria/{criterion} behavioural-assessment.categories.criteria.destroy Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@destroyCriterion
GET|HEAD  behavioural-assessment/categories/{category}/edit              behavioural-assessment.categories.edit       Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@edit
POST      behavioural-assessment/categories/{category}/toggle-status     behavioural-assessment.categories.toggleStatus Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@toggleStatus
DELETE    behavioural-assessment/categories/{id}/force-delete            behavioural-assessment.categories.forceDelete Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@forceDelete
GET|HEAD  behavioural-assessment/categories/{id}/restore                 behavioural-assessment.categories.restore    Modules\BehaviouralAssessment\Http\Controllers\BaCategoryController@restore
```

Middlewares on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:BehaviouralAssessment, auth, verified` (uncached `route:list --json`). Custom routes are registered before `Route::resource` (web.php lines 39-43 precede line 44), so `categories/trash` and `categories/reorder` are not captured by the resource wildcard.

Route-parameter name check (`module-finalization.md` §3.3.1): `toggleStatus`, `storeCriterion`, `updateCriterion`, `destroyCriterion` take `int $category`, matching `{category}`; `restore`/`forceDelete` take `int $id`, matching `{id}`. The resource routes name `{category}` while `show`/`update`/`destroy` take `$id` — a positional scalar binding, no model type-hint, so there is no unbound-model INSERT risk.

**Unrouted public methods:** none. All fifteen public methods (`index`, `create`, `store`, `show`, `edit`, `update`, `destroy`, `trashed`, `restore`, `forceDelete`, `toggleStatus`, `reorder`, `storeCriterion`, `updateCriterion`, `destroyCriterion`) appear in the route list; no D5 work is needed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 24 | GET `categories` | `tenant.behavioural-assessment.categories.viewAny` | — | — | none (redirect only) | — |
| `create` | 31 | GET `categories/create` | `tenant.behavioural-assessment.categories.create` | — | — | none (read only) | — |
| `store` | 39 | POST `categories` | `tenant.behavioural-assessment.categories.create` (also FormRequest `authorize()`) | ✅ `DB::transaction` closure | `Stored` (after write, in tx ✅) | `ba_categories`, `ba_criteria`, `sys_activity_logs` | BCAT-01, BCAT-02, BCAT-03, BCAT-04, BCAT-11 |
| `show` | 72 | GET `categories/{category}` | `tenant.behavioural-assessment.categories.view` | — | — | none (read only) | BCAT-07, BCAT-10 |
| `edit` | 80 | GET `categories/{category}/edit` | `tenant.behavioural-assessment.categories.update` | — | — | none (read only) | BCAT-07, BCAT-10 |
| `update` | 91 | PUT/PATCH `categories/{category}` | `tenant.behavioural-assessment.categories.update` (also FormRequest `authorize()`) | ✅ `DB::transaction` closure | `Updated` (after write, in tx ✅) | `ba_categories`, `ba_criteria`, `sys_activity_logs` | BCAT-01, BCAT-02, BCAT-03, BCAT-04, BCAT-07, BCAT-11 |
| `destroy` | 128 | DELETE `categories/{category}` | `tenant.behavioural-assessment.categories.delete` | ✅ `DB::transaction` closure | `Trashed` (after write, in tx ✅) | `ba_categories`, `sys_activity_logs` | BCAT-01, BCAT-02, BCAT-03, BCAT-07 |
| `trashed` | 167 | GET `categories/trash` | `tenant.behavioural-assessment.categories.restore` | — | — | none (read only, `paginate(10)`) | — |
| `restore` | 177 | GET `categories/{id}/restore` | `tenant.behavioural-assessment.categories.restore` | ✅ `DB::transaction` closure | `Restored` (after write, in tx ✅) | `ba_categories`, `sys_activity_logs` | BCAT-01, BCAT-02, BCAT-03, BCAT-06, BCAT-07 |
| `forceDelete` | 211 | DELETE `categories/{id}/force-delete` | `tenant.behavioural-assessment.categories.forceDelete` | ✅ `DB::transaction` closure | `Deleted` (after write, in tx ✅) | `ba_categories`, `ba_criteria`, `ba_class_category_jnt`, `sys_activity_logs` | BCAT-01, BCAT-02, BCAT-03, BCAT-07, BCAT-15 |
| `toggleStatus` | 243 | POST `categories/{category}/toggle-status` | `tenant.behavioural-assessment.categories.update` | ✅ `DB::transaction` closure | `Toggled` (after write, in tx ✅) | `ba_categories`, `sys_activity_logs` | BCAT-01, BCAT-02, BCAT-03, BCAT-07 |
| `reorder` | 286 | POST `categories/reorder` | `tenant.behavioural-assessment.categories.update` | ✅ `DB::transaction` closure | `Reordered` (after writes, in tx ✅) | `ba_categories`, `sys_activity_logs` | BCAT-01, BCAT-02, BCAT-03, BCAT-05, BCAT-08 |
| `storeCriterion` | 340 | POST `categories/{category}/criteria` | `tenant.behavioural-assessment.categories.update` | ✅ `DB::transaction` closure | `Stored` (after write, in tx ✅) | `ba_criteria`, `sys_activity_logs` | BCAT-01, BCAT-02, BCAT-03, BCAT-05, BCAT-07, BCAT-11 |
| `updateCriterion` | 384 | PUT `categories/{category}/criteria/{criterion}` | `tenant.behavioural-assessment.categories.update` | ✅ `DB::transaction` closure | `Updated` (after write, in tx ✅) | `ba_criteria`, `sys_activity_logs` | BCAT-01, BCAT-02, BCAT-03, BCAT-05, BCAT-07 |
| `destroyCriterion` | 430 | DELETE `categories/{category}/criteria/{criterion}` | `tenant.behavioural-assessment.categories.delete` | ✅ `DB::transaction` closure | `Trashed` (after write, in tx ✅) | `ba_criteria`, `sys_activity_logs` | BCAT-01, BCAT-02, BCAT-03, BCAT-07 |

**Tables each mutation SHOULD touch, vs what it does:**
- `store` / `update` — one `ba_categories` row, its `ba_criteria` rows and one audit row: does all three (the criteria sync runs inside the same transaction), in one transaction.
- `destroy` — soft-delete the row (plus set `is_active = false`) and one audit row: does both, in one transaction.
- `restore` — un-delete the row plus one audit row: does both, in one transaction.
- `forceDelete` — hard-delete the row (the DB then cascades to `ba_criteria` and `ba_class_category_jnt`, and nulls `ba_incidents`/`ba_comment_bank` links) plus one audit row: does so, in one transaction.
- `toggleStatus` — flip `is_active` plus one audit row: does both, in one transaction.
- `reorder` — the reordered rows plus one audit row (one entry per drag): does both, in one transaction.
- `storeCriterion` / `updateCriterion` / `destroyCriterion` — one `ba_criteria` row plus one audit row: does both, in one transaction.
- Scanner candidate **TXN-01** at `syncCriteria` (line 477, "4 writes + activityLog with no transaction") is a **false positive**: `syncCriteria()` is `private` and is called only from inside the `store` and `update` transaction closures (lines 52 and 107), so its writes are already transactional.

## 6. Findings

### F1 — Errors

#### BCAT-01 · M · ERR-00 (D1) — ten mutating methods keep a controller `try/catch` that is not a D2 shape

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M by protocol D1) — *the Laravel idiom wins for the final audit: no `try/catch` in a controller unless it is one of the D2 shapes (`\DomainException`, the truncate-rebuild catch, `SnapshotProtectionException`, or `report($e)` in a service)* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php:43-69, 95-125, 132-164, 181-208, 215-240, 247-276, 295-337, 350-381, 398-427, 434-466` |
| **Root cause** | Every write method wraps its `DB::transaction` in `try { … } catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { Log::error(…); return back()… }`. None of these catches is a D2 shape, so D1 forbids them. Each `ModelNotFoundException` rethrow exists only to keep the 404 alive under the generic catch. The comments say "Rule A1" — but D1 supersedes A1 for modules under final audit. |
| **Consequence** | A failed save is reported to the user as "The operation could not be completed." and the real exception is never logged with its trace, so it cannot be diagnosed from the log. |
| **Reproduce** | static only — any `QueryException` (for example a duplicate `code` firing `uq_ba_cat_code`) yields the generic flash instead of a logged trace. |
| **Fix approach** | Remove all ten `try`/`catch` wrappers; keep `findOrFail()` and `Gate::authorize()` where they are; let `DB::transaction(fn () => …)` roll back and the central handler in `bootstrap/app.php` render. This also drops the `ModelNotFoundException` and `Log` imports. |
| **Plan item** | BCAT-01 in `02-fix-plan.md` §3 |

```php
// lines 43-69, method store() — the D2-forbidden shape; the same shape repeats in the nine other methods
        try {
            return DB::transaction(function () use ($request) {
                $record = BaCategory::create($request->safe()->except(['criteria', 'criteria_submitted']) + [
                    // Appended to the end of its sibling group; the list's drag-and-drop reorders it.
                    'sort_order' => BaCategory::nextSortOrder($request->validated('parent_id')),
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                $this->syncCriteria($record, (array) $request->validated('criteria', []));

                activityLog($record, 'Stored', ['message' => 'BaCategory was stored.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'categories'])
                    ->with('success', 'Category created successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCategoryController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "try {\|catch (\|Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
43:        try {
61:        } catch (ModelNotFoundException $e) {
65:        } catch (\Throwable $e) {
66:            Log::error('BaCategoryController::store failed', ['error' => $e->getMessage()]);
95:        try {
117:        } catch (ModelNotFoundException $e) {
121:        } catch (\Throwable $e) {
122:            Log::error('BaCategoryController::update failed', ['error' => $e->getMessage()]);
132:        try {
156:        } catch (ModelNotFoundException $e) {
160:        } catch (\Throwable $e) {
161:            Log::error('BaCategoryController::destroy failed', ['error' => $e->getMessage()]);
181:        try {
200:        } catch (ModelNotFoundException $e) {
204:        } catch (\Throwable $e) {
205:            Log::error('BaCategoryController::restore failed', ['error' => $e->getMessage()]);
215:        try {
232:        } catch (ModelNotFoundException $e) {
236:        } catch (\Throwable $e) {
237:            Log::error('BaCategoryController::forceDelete failed', ['error' => $e->getMessage()]);
247:        try {
263:        } catch (ModelNotFoundException $e) {
267:        } catch (\Throwable $e) {
268:            Log::error('BaCategoryController::toggleStatus failed', ['error' => $e->getMessage()]);
295:        try {
328:        } catch (ModelNotFoundException $e) {
330:        } catch (\Throwable $e) {
331:            Log::error('BaCategoryController::reorder failed', ['error' => $e->getMessage()]);
350:        try {
373:        } catch (ModelNotFoundException $e) {
377:        } catch (\Throwable $e) {
378:            Log::error('BaCategoryController::storeCriterion failed', ['error' => $e->getMessage()]);
398:        try {
419:        } catch (ModelNotFoundException $e) {
423:        } catch (\Throwable $e) {
424:            Log::error('BaCategoryController::updateCriterion failed', ['error' => $e->getMessage()]);
434:        try {
458:        } catch (ModelNotFoundException $e) {
462:        } catch (\Throwable $e) {
463:            Log::error('BaCategoryController::destroyCriterion failed', ['error' => $e->getMessage()]);
```

#### BCAT-02 · M · ERR-05 — every catch logs only `$e->getMessage()`

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php:66,122,161,205,237,268,331,378,424,463` |
| **Root cause** | Each catch calls `Log::error('…', ['error' => $e->getMessage()])`, which stores the message string only; the exception type, trace and previous exceptions are lost. |
| **Consequence** | A production failure in any of the ten writes leaves a one-line log entry that cannot be traced to the failing query. |
| **Reproduce** | static only — the log array has no `exception` or stack key. |
| **Fix approach** | Removing the catches (BCAT-01) removes these log calls; if a catch is ever kept it must use `report($e)`. |
| **Plan item** | none — see plan §10 (removed by BCAT-01) |

```php
// line 66, the store() catch — the same idiom at 122, 161, 205, 237, 268, 331, 378, 424, 463
            Log::error('BaCategoryController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
66:            Log::error('BaCategoryController::store failed', ['error' => $e->getMessage()]);
122:            Log::error('BaCategoryController::update failed', ['error' => $e->getMessage()]);
161:            Log::error('BaCategoryController::destroy failed', ['error' => $e->getMessage()]);
205:            Log::error('BaCategoryController::restore failed', ['error' => $e->getMessage()]);
237:            Log::error('BaCategoryController::forceDelete failed', ['error' => $e->getMessage()]);
268:            Log::error('BaCategoryController::toggleStatus failed', ['error' => $e->getMessage()]);
331:            Log::error('BaCategoryController::reorder failed', ['error' => $e->getMessage()]);
378:            Log::error('BaCategoryController::storeCriterion failed', ['error' => $e->getMessage()]);
424:            Log::error('BaCategoryController::updateCriterion failed', ['error' => $e->getMessage()]);
463:            Log::error('BaCategoryController::destroyCriterion failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### BCAT-03 · M · TXN-05 — the HTTP response is built inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build `redirect()` / `response()` after it* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php:56-58, 112-114, 136-138, 151-153, 186-187, 195-197, 219-220, 227-229, 256-260, 301-306, 326, 370, 416, 437, 455` |
| **Root cause** | Each `DB::transaction(function () { … })` ends with `return redirect()…`, `return back()…` or `return response()->json(…)` instead of returning the model or void and building the response after the closure. `destroy`, `restore`, `forceDelete` and `destroyCriterion` even `return back()->with('error', …)` for their guard branches from inside the transaction. |
| **Consequence** | The success flash or JSON payload is assembled before the commit; the guard branches also hold an open transaction while returning a plain redirect. No data corruption. |
| **Reproduce** | static only — every method's last statement inside the closure is an HTTP response. |
| **Fix approach** | Move the redirect/JSON construction after `DB::transaction(...)`; make the closure return `void`. BCAT-01's rewrite does this and also moves the guard branches out. |
| **Plan item** | none — see plan §10 (fixed inside BCAT-01) |

```php
// lines 56-60, the store() closure tail — the same shape in the other nine methods
                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'categories'])
                    ->with('success', 'Category created successfully.');

            });
```

**Evidence**
```
$ grep -nE "return DB::transaction|return redirect\(\)|return response\(\)|return back\(\)" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
28:        return redirect()->route('behavioural-assessment.masters', ['tab' => 'categories']);
44:            return DB::transaction(function () use ($request) {
56:                return redirect()
68:            return back()->with('error', 'The operation could not be completed.');
96:            return DB::transaction(function () use ($request, $id) {
112:                return redirect()
124:            return back()->with('error', 'The operation could not be completed.');
133:            return DB::transaction(function () use ($id) {
137:                    return back()->with('error', 'System categories are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
141:                    return back()->with('error', "This category cannot be deleted because {$reason}. Deactivate it instead.");
151:                return redirect()
163:            return back()->with('error', 'The operation could not be completed.');
182:            return DB::transaction(function () use ($id) {
187:                    return back()->with('error', "Another category already uses the code {$category->code}. Change that category's code before restoring this one.");
195:                return redirect()
207:            return back()->with('error', 'The operation could not be completed.');
216:            return DB::transaction(function () use ($id) {
220:                    return back()->with('error', 'System categories are part of the behavioural framework and cannot be deleted.');
227:                return redirect()
239:            return back()->with('error', 'The operation could not be completed.');
248:            return DB::transaction(function () use ($category) {
256:                return response()->json([
272:            return response()->json([
296:            return DB::transaction(function () use ($validated) {
302:                    return response()->json([
326:                return response()->json(['success' => true, 'message' => 'Order updated.']);
333:            return response()->json([
351:            return DB::transaction(function () use ($request, $validated, $category) {
370:                return back()->with('success', 'Criterion added.');
380:            return back()->with('error', 'The operation could not be completed.');
395:            return back()->withErrors(['code' => 'This is a system criterion; its code cannot be changed.'])->withInput();
399:            return DB::transaction(function () use ($request, $validated, $record, $category) {
416:                return back()->with('success', 'Criterion updated.');
426:            return back()->with('error', 'The operation could not be completed.');
435:            return DB::transaction(function () use ($category, $criterion) {
437:                    return back()->with('error', 'Cannot delete this criterion because ratings or incidents have been recorded against it. Deactivate it instead.');
443:                    return back()->with('error', 'System criteria are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
455:                return back()->with('success', 'Criterion removed.');
465:            return back()->with('error', 'The operation could not be completed.');
```

#### BCAT-11 · M · TXN-06 — `nextSortOrder()` is a max-then-insert with no lock or unique index

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M, lowered from H — the only cost is list-ordering, not money or data loss) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/BehaviouralAssessment/app/Models/BaCategory.php:105-108` (called at controller:47,101); `Modules/BehaviouralAssessment/app/Models/BaCriterion.php:71-74` (called at controller:358) |
| **Root cause** | `nextSortOrder()` runs `static::max('sort_order')` and the caller then `create()`s with `max + 1`; two concurrent creates can read the same max and write the same value. Neither `ba_categories` (`uq_ba_cat_code`, `idx_ba_cat_parent`, `idx_ba_cat_polarity`, `idx_ba_cat_active`) nor `ba_criteria` (`uq_ba_criteria_code`, `idx_ba_criteria_cat`) declares a unique index on `sort_order`, so the duplicate is written silently. |
| **Consequence** | Two categories (or criteria) created in the same instant can share a sort position, so their relative order in the list is undefined until the next drag reorder — cosmetic only. |
| **Reproduce** | static only — requires two simultaneous `POST /behavioural-assessment/categories` (or criteria) requests. |
| **Fix approach** | Accept (cosmetic), or read the max under `lockForUpdate()`. A unique index on `sort_order` cannot be added because `reorder` writes intermediate duplicate positions mid-operation. |
| **Plan item** | none — see plan §10 (accepted) |

```php
// BaCategory.php:105-108 — read-max then insert, no lock
    public static function nextSortOrder(?int $parentId): int
    {
        return (int) (static::where('parent_id', $parentId)->max('sort_order') ?? 0) + 1;
    }
```

**Evidence**
```
$ grep -n "nextSortOrder" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
47:                    'sort_order' => BaCategory::nextSortOrder($request->validated('parent_id')),
101:                    $data['sort_order'] = BaCategory::nextSortOrder($data['parent_id']);
358:                    'sort_order' => BaCriterion::nextSortOrder($category),
$ grep -n "unique\|index" database/migrations/tenant/2026_06_16_130614_create_ba_categories_table.php database/migrations/tenant/2026_06_16_130620_create_ba_criteria_table.php
2026_06_16_130614_create_ba_categories_table.php:38:            $table->unique(['code', 'uq_guard'], 'uq_ba_cat_code');
2026_06_16_130614_create_ba_categories_table.php:39:            $table->index('parent_id', 'idx_ba_cat_parent');
2026_06_16_130614_create_ba_categories_table.php:40:            $table->index('polarity', 'idx_ba_cat_polarity');
2026_06_16_130614_create_ba_categories_table.php:41:            $table->index(['is_active', 'sort_order'], 'idx_ba_cat_active');
2026_06_16_130620_create_ba_criteria_table.php:37:            $table->unique(['category_id', 'code', 'uq_guard'], 'uq_ba_criteria_code');
2026_06_16_130620_create_ba_criteria_table.php:38:            $table->index(['category_id', 'is_active', 'sort_order'], 'idx_ba_criteria_cat');
```

### F3 — Authorization

#### BCAT-04 · L · AUTH-04 — `store` and `update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` plus `Gate::authorize`); keep one* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php:41,93`; the duplicate half is `BaCategoryRequest::authorize()` at lines 18-24 |
| **Root cause** | The FormRequest runs `authorizeByCrudPermission('tenant.behavioural-assessment.categories')` (POST maps to `create`, PUT/PATCH to `update`), and the controller repeats `Gate::authorize(…create)` / `Gate::authorize(…update)` for the same two keys. |
| **Consequence** | No runtime effect; it is duplication that can drift — if one side's key changes the other silently keeps the old check. |
| **Reproduce** | static only. |
| **Fix approach** | Keep the FormRequest `authorize()` (it runs first, before validation) and drop the two controller `Gate::authorize` lines. |
| **Plan item** | BCAT-04 in `02-fix-plan.md` §4 |

```php
// line 41, method store() — the controller half of the duplicate; update() repeats it at :93
        Gate::authorize('tenant.behavioural-assessment.categories.create');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
26:        Gate::authorize('tenant.behavioural-assessment.categories.viewAny');
33:        Gate::authorize('tenant.behavioural-assessment.categories.create');
41:        Gate::authorize('tenant.behavioural-assessment.categories.create');
74:        Gate::authorize('tenant.behavioural-assessment.categories.view');
82:        Gate::authorize('tenant.behavioural-assessment.categories.update');
93:        Gate::authorize('tenant.behavioural-assessment.categories.update');
$ sed -n '18,24p' Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryRequest.php
    public function authorize(): bool
    {
        // T6b — mirrors the controller's own gate: tenant.behavioural-assessment.categories.create on POST,
        // tenant.behavioural-assessment.categories.update on PUT/PATCH. Same permission, checked one step
        // earlier, so this narrows nothing and widens nothing.
        return $this->authorizeByCrudPermission('tenant.behavioural-assessment.categories');
    }
```

### F4 — Validation and input

#### BCAT-05 · M · VAL-02 — the criteria and reorder payloads are validated inline instead of in a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request; inline `$request->validate()` is allowed only for a one-field AJAX toggle* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php:290-293` (`reorder`), `:348` (`storeCriterion`), `:391` (`updateCriterion`), and the shared `criterionRules()` at `:521-536` |
| **Root cause** | `reorder` calls `$request->validate([...])` in the controller, and the two criterion write methods call `$request->validate($this->criterionRules(...))`. Each payload has multiple fields, so the one-field AJAX exception does not apply, and the resource's other validation (category fields) already lives in `BaCategoryRequest`. |
| **Consequence** | The reorder and criterion contracts live apart from the resource's FormRequest, so a future field change can be made in one place and not the other; there is no single place that documents the criteria and reorder input rules. |
| **Reproduce** | static only. |
| **Fix approach** | Add `BaCategoryCriterionRequest` (rules from `criterionRules()`) and `BaCategoryReorderRequest` (the `order`/`order.*` rules) and take them as the method arguments; call `$request->validated()`. |
| **Plan item** | BCAT-05 in `02-fix-plan.md` §5 |

```php
// lines 290-293, method reorder()
        $validated = $request->validate([
            'order' => ['required', 'array'],
            'order.*' => ['integer', 'distinct', 'exists:ba_categories,id'],
        ]);
```

**Evidence**
```
$ grep -n -e "validate(" -e "validated()" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
290:        $validated = $request->validate([
348:        $validated = $request->validate($this->criterionRules($category));
391:        $validated = $request->validate($this->criterionRules($category, $criterion));
```

### F5 — Routes

#### BCAT-06 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …): GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/BehaviouralAssessment/routes/web.php:40` (route) and `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php:177` (method `restore`) |
| **Root cause** | `Route::get('categories/{id}/restore', …)` runs a write (sets `updated_by`, calls `restore()`, writes `sys_activity_logs`) behind a GET. |
| **Consequence** | A link prefetcher, a crawler or an `<img>`-style GET with a trashed id silently un-trashes the category with no CSRF token; the trash page's confirm dialog gives false confidence. |
| **Reproduce** | Open `/behavioural-assessment/categories/{id}/restore` for a trashed id in a plain browser tab — the row is restored. |
| **Fix approach** | Change the route verb to POST; the shared `action-trashed` component already emits `@csrf` and a POST form whenever the route is not GET, so only the route line changes. |
| **Plan item** | BCAT-06 in `02-fix-plan.md` §1 (⚠ SHARED — route file) |

```php
// routes/web.php:40
Route::get('categories/{id}/restore', [BaCategoryController::class, 'restore'])->name('categories.restore');
```

**Evidence**
```
$ grep -n "categories/{id}/restore" Modules/BehaviouralAssessment/routes/web.php
40:Route::get('categories/{id}/restore', [BaCategoryController::class, 'restore'])->name('categories.restore');
```

### F6 — Controller shape

#### BCAT-07 · M · CTL-03 — no route-model binding; every method loads by `$id`/`$category` with `findOrFail()`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`, `withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php:75,83,97,134,183,217,249,343,388,440` |
| **Root cause** | `show`/`update`/`destroy`/`toggleStatus` take `int $id`/`int $category` and `restore`/`forceDelete` take `int $id`, then call `findOrFail()`; the routes already carry `{category}` / `{id}` / `{criterion}`, so implicit binding is available and the manual load is redundant. |
| **Consequence** | No user-visible defect today — the explicit `findOrFail()` is correct — so the cost is boilerplate and one more place to remember `->withTrashed()` if the parameter is ever rebound. |
| **Reproduce** | static only. |
| **Fix approach** | Bind the models: `show`/`update`/`destroy`/`toggleStatus` on `BaCategory $category`; `storeCriterion`/`updateCriterion`/`destroyCriterion` on `BaCategory $category` (the `{criterion}` load stays a scoped query); rename the `restore`/`forceDelete` parameters to `{category}` with `->withTrashed()`. This touches the route file, so it is offered as a DECISION. |
| **Plan item** | BCAT-07 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// lines 72-75, method show() — the shape repeated by the other nine loads
    public function show(int $id): View
    {
        Gate::authorize('tenant.behavioural-assessment.categories.view');
        $category = BaCategory::with(['parent', 'criteria' => fn ($q) => $q->orderBy('sort_order')])->findOrFail($id);
```

**Evidence**
```
$ grep -n "findOrFail" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
75:        $category = BaCategory::with(['parent', 'criteria' => fn ($q) => $q->orderBy('sort_order')])->findOrFail($id);
83:        $category = BaCategory::with(['criteria' => fn ($q) => $q->orderBy('sort_order')])->findOrFail($id);
97:                $category = BaCategory::findOrFail($id);
134:                $category = BaCategory::findOrFail($id);
183:                $category = BaCategory::onlyTrashed()->findOrFail($id);
217:                $category = BaCategory::withTrashed()->findOrFail($id);
249:                $cat = BaCategory::findOrFail($category);
343:        BaCategory::findOrFail($category);
388:        $record = BaCriterion::where('category_id', $category)->findOrFail($criterion);
440:                $record = BaCriterion::where('category_id', $category)->findOrFail($criterion);
```

### F7 — Models

**clean** — both models declare `$table` on a real migration, a `$fillable` list with nothing sensitive, a `$casts` entry for every integer/boolean/decimal/datetime column, and `SoftDeletes` matching the `deleted_at` column. Neither uses Spatie `InteractsWithMedia`. Relationships are return-typed and resolve. Proof: `grep -n "SoftDeletes|\$casts|\$fillable|protected \$table" Modules/BehaviouralAssessment/app/Models/BaCategory.php Modules/BehaviouralAssessment/app/Models/BaCriterion.php` shows the declarations at `BaCategory.php:11,15,17,19,33` and `BaCriterion.php:10,14,16,18,31`; both tables exist (`2026_06_16_130614_create_ba_categories_table.php`, `2026_06_16_130620_create_ba_criteria_table.php`); and tinker `toSql()` on `parent()`, `children()`, `criteria()`, `category()`, `ratings()` each returned a well-formed query (`select * from ba_criteria where category_id = ? and deleted_at is null`, etc.). No pivot with `deleted_at` is used (`classMappings()` is a `HasMany` over a model, not `belongsToMany`).

**Evidence**
```
$ grep -n "SoftDeletes\|\$casts\|\$fillable\|protected \$table" Modules/BehaviouralAssessment/app/Models/BaCategory.php Modules/BehaviouralAssessment/app/Models/BaCriterion.php
Modules/BehaviouralAssessment/app/Models/BaCategory.php:11:use Illuminate\Database\Eloquent\SoftDeletes;
Modules/BehaviouralAssessment/app/Models/BaCategory.php:15:    use SoftDeletes;
Modules/BehaviouralAssessment/app/Models/BaCategory.php:17:    protected $table = 'ba_categories';
Modules/BehaviouralAssessment/app/Models/BaCategory.php:19:    protected $fillable = [
Modules/BehaviouralAssessment/app/Models/BaCategory.php:33:    protected $casts = [
Modules/BehaviouralAssessment/app/Models/BaCriterion.php:10:use Illuminate\Database\Eloquent\SoftDeletes;
Modules/BehaviouralAssessment/app/Models/BaCriterion.php:14:    use SoftDeletes;
Modules/BehaviouralAssessment/app/Models/BaCriterion.php:16:    protected $table = 'ba_criteria';
Modules/BehaviouralAssessment/app/Models/BaCriterion.php:18:    protected $fillable = [
Modules/BehaviouralAssessment/app/Models/BaCriterion.php:31:    protected $casts = [
```

### F8 — Services and jobs

**clean** — the controller names no service, job, event, mail or notification. Proof: `grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b' Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php` → only `BaCategoryRequest`. The one helper reached is the framework-side `activityLog()` in `app/Helpers/activityLog.php` (common).

### F9 — Queries and performance

#### BCAT-08 · M · QRY-01 — `reorder` issues one UPDATE per row inside a `foreach`

| Field | Value |
|---|---|
| **Rule** | QRY-01 (M, lowered from H — the loop is bounded to one page of 10 rows by the paginator) — *no queries inside loops; bulk-write* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php:313-318` |
| **Root cause** | `BaCategory::where('id', $id)->update([…])` runs once per id in `foreach ($order …)`, so one drag performs N UPDATE statements instead of a single bulk write. |
| **Consequence** | A drag on a full page runs 10 statements where 1 would do; each drag holds the transaction open for 10 round-trips, and the cost scales with page size. |
| **Reproduce** | static only — the drag posts `{order:[…]}` to `POST /behavioural-assessment/categories/reorder`. |
| **Fix approach** | One `UPDATE … SET sort_order = CASE id WHEN ? THEN ? … END, updated_by = ? WHERE id IN (…)` with bound parameters. |
| **Plan item** | BCAT-08 in `02-fix-plan.md` §6 |

```php
// lines 313-318
                foreach ($order as $i => $id) {
                    BaCategory::where('id', $id)->update([
                        'sort_order' => $positions[$i],
                        'updated_by' => BaActor::id(),
                    ]);
                }
```

**Evidence**
```
$ grep -n "BaCategory::where('id'" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
314:                    BaCategory::where('id', $id)->update([
$ grep -n "paginate" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
172:            ->paginate(10);
```

#### BCAT-09 · M · QRY-07 — `syncCriteria` writes one row at a time in two loops

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *bulk writes: `insert()`, `upsert()`, `whereIn(...)->update()` instead of `create()`/`update()` per row in a loop* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php:482-490` (delete loop) and `:492-512` (update/create loop) |
| **Root cause** | `syncCriteria()` issues one `->update()` + `->delete()` per removed criterion and one `->update()` / `create()` per kept/new row. A 100-row grid (the request caps `criteria` at `max:100`) performs up to 200 statements. |
| **Consequence** | Saving a category with a full criteria grid is slower than it needs to be and holds the transaction open across many round-trips; the cost scales with the grid size. |
| **Reproduce** | static only — save a category whose criteria grid has many rows. |
| **Fix approach** | Bulk the deleted rows into one `whereIn('id',$ids)->update(['is_active'=>false,…])` plus one soft-delete, and upsert the kept/new rows with `upsert()` (or a `CASE` update plus `insert`). Requires care to keep the per-row `activityLog`. |
| **Plan item** | BCAT-09 in `02-fix-plan.md` §6 |

```php
// lines 482-490, the removal loop inside syncCriteria()
        foreach ($existing->except($keptIds) as $removed) {
            $removed->update(['is_active' => false, 'updated_by' => BaActor::id()]);
            $removed->delete();
            activityLog($removed, 'Trashed', [
                'message' => 'Behaviour criterion was removed.',
                'category_id' => $category->id,
                'name' => $removed->name,
            ]);
        }
```

**Evidence**
```
$ grep -n "BaCriterion::create\|->update(\|->delete()" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
103:                $category->update($data);
147:                $category->delete();
223:                $category->forceDelete();
314:                    BaCategory::where('id', $id)->update([
400:                $record->update([
446:                $record->delete();
483:            $removed->update(['is_active' => false, 'updated_by' => BaActor::id()]);
484:            $removed->delete();
505:                $crit->update($data);
```

#### BCAT-10 · L · QRY-03 — `parentOptions()` selects whole models for a dropdown

| Field | Value |
|---|---|
| **Rule** | QRY-03 (L, lowered from M — the table is 9 rows, and the `id`+`name` it uses are the only non-null display columns) — *select only what you use; dropdowns use `pluck('name', 'id')` / `get(['id', 'name'])`* |
| **Where** | `Modules/BehaviouralAssessment/app/Models/BaCategory.php:92-99`, called at `BaCategoryController.php:34,86`; also `show`'s `->with('parent')` at controller:75 (the view uses only `parent->name`) |
| **Root cause** | `parentOptions()` runs `static::whereNull('parent_id')->where('is_active', true)…->get()` with no column list, returning every column of every top-level category to a `<select>`. |
| **Consequence** | The create/edit pages hydrate full models where two columns are used; harmless at 9 rows but the pattern does not scale if the framework grows. |
| **Reproduce** | static only. |
| **Fix approach** | `->get(['id', 'name'])` in `parentOptions()`, and `->with('parent:id,name')` in `show()`. |
| **Plan item** | BCAT-10 in `02-fix-plan.md` §6 |

```php
// BaCategory.php:94-98, inside parentOptions()
        return static::whereNull('parent_id')
            ->where('is_active', true)
            ->when($exceptId, fn ($q) => $q->where('id', '!=', $exceptId))
            ->orderBy('name')
            ->get();
```

**Evidence**
```
$ grep -n "parentOptions" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
34:        $parents = BaCategory::parentOptions();
86:        $parents = BaCategory::parentOptions($id);
$ sed -n '94,98p' Modules/BehaviouralAssessment/app/Models/BaCategory.php
        return static::whereNull('parent_id')
            ->where('is_active', true)
            ->when($exceptId, fn ($q) => $q->where('id', '!=', $exceptId))
            ->orderBy('name')
            ->get();
```

### F10 — Views

**clean** — none of the six in-scope blades runs a query, dumps a whole model, or uses `{!! !!}`. The only `->count()` calls are on the eager-loaded `$category->criteria` collection (`edit.blade.php:155`, `show.blade.php:106`), which is loaded by `edit()`/`show()` (`->with(['criteria' => fn ($q) => $q->orderBy('sort_order')])`), so no query runs in the loop. The trash page's `@canany`/`Gate::any` are authorization reads, not data queries. `:links="[]"` on the breadcrumb is what the breadcrumb standard requires (§1.2 rule 8). Proof: `grep -nE "Model::|DB::|->get\(\)|->count\(\)|where\(|{!!"` on the six files returns only `edit.blade.php:155` and `show.blade.php:106`.

**Evidence**
```
$ grep -nE "Model::|DB::|->get\(\)|->count\(\)|where\(|{!!" Modules/BehaviouralAssessment/resources/views/category/create.blade.php Modules/BehaviouralAssessment/resources/views/category/edit.blade.php Modules/BehaviouralAssessment/resources/views/category/show.blade.php Modules/BehaviouralAssessment/resources/views/category/trash.blade.php Modules/BehaviouralAssessment/resources/views/category/_criteria-grid.blade.php Modules/BehaviouralAssessment/resources/views/category/_criteria-row.blade.php
Modules/BehaviouralAssessment/resources/views/category/edit.blade.php:155:                                    <span class="badge bg-secondary ms-2">{{ $category->criteria->count() }}</span>
Modules/BehaviouralAssessment/resources/views/category/show.blade.php:106:                        <span class="badge bg-secondary rounded-pill px-3">{{ $category->criteria->count() }} criteria</span>
```

### F11 — Security and tenancy

**clean** — no `env()` in scope (`grep -n "env(" … → no match`); no request body or secret is logged (the only logs are the ERR-05 catch messages); `BaActor`'s `private static array $systemIds` is keyed by `DB::connection()->getDatabaseName()`, so the cached bootstrap-admin id cannot leak across tenants. The only numeric fallbacks are `'weight' => 100.00` and `'sort_order' => i + 1`, not user/tenant/status ids (SEC-03 does not apply). Tenant routes carry the full tenancy middleware group (see §4).

### F12 — Style

#### BCAT-12 · L · STY-02 — `BaCategory.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, FQCN imports, no stray blank lines* |
| **Where** | `Modules/BehaviouralAssessment/app/Models/BaCategory.php:7-10` (import order) and `:117` (inline FQCN) |
| **Root cause** | `use Illuminate\Support\Collection;` sits before the `Eloquent\Relations` imports, and `usageReason()` writes `\Illuminate\Support\Facades\DB::class` inline instead of importing `DB`. |
| **Consequence** | The file fails the project's formatter gate; a later `pint --dirty` run would rewrite it under another developer's commit. |
| **Reproduce** | `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Models/BaCategory.php` → `fail`. |
| **Fix approach** | Import `DB`, move `Collection` into sorted order; or run Pint on the file (the plan gives the exact hunks). |
| **Plan item** | BCAT-12 in `02-fix-plan.md` §8 |

```php
// lines 7-11 and 117 — current
use App\Models\BaseModel;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
```
```php
// line 117
        $db = \Illuminate\Support\Facades\DB::class;
```

**Evidence**
```
$ vendor/bin/pint --test --format json Modules/BehaviouralAssessment/app/Models/BaCategory.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Models\/BaCategory.php","fixers":["fully_qualified_strict_types","ordered_imports"]}]}
```

#### BCAT-13 · L · STY-02 — `BaCriterion.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/BehaviouralAssessment/app/Models/BaCriterion.php:89,91` |
| **Root cause** | `usedIds()` writes `\Illuminate\Support\Facades\DB::table(...)` inline twice instead of importing `DB`. |
| **Consequence** | The file fails the project's formatter gate. |
| **Reproduce** | `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Models/BaCriterion.php` → `fail`. |
| **Fix approach** | Import `DB` and use `DB::table(...)`. |
| **Plan item** | BCAT-13 in `02-fix-plan.md` §8 |

```php
// lines 89-92, inside usedIds()
        return \Illuminate\Support\Facades\DB::table('ba_assessment_ratings')
            ->whereIn('criterion_id', $ids)->whereNull('deleted_at')->distinct()->pluck('criterion_id')
            ->merge(\Illuminate\Support\Facades\DB::table('ba_incidents')
                ->whereIn('criterion_id', $ids)->whereNull('deleted_at')->distinct()->pluck('criterion_id'))
```

**Evidence**
```
$ vendor/bin/pint --test --format json Modules/BehaviouralAssessment/app/Models/BaCriterion.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Models\/BaCriterion.php","fixers":["fully_qualified_strict_types"]}]}
```

#### BCAT-14 · L · STY-02 — `BaCategoryRequest.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryRequest.php:33-50,58-61,70-73,117` |
| **Root cause** | The `rules()` / `prepareForValidation()` / `messages()` arrays align their `=>` with extra spaces; the Laravel preset collapses that to a single space, and one blank line is added before the `after()` return. |
| **Consequence** | The file fails the project's formatter gate. |
| **Reproduce** | `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryRequest.php` → `fail`. |
| **Fix approach** | Run Pint on the file; the plan gives the representative hunks and the command. |
| **Plan item** | BCAT-14 in `02-fix-plan.md` §8 |

```php
// lines 33-37 — current (aligned); the same alignment repeats through line 50
            'code'        => ['required', 'string', 'max:30', 'regex:/^[A-Z0-9_\-]+$/', Rule::unique('ba_categories', 'code')->ignore($id)->whereNull('deleted_at')],
            'name'        => ['required', 'string', 'max:100'],
            'parent_id'   => ['nullable', 'exists:ba_categories,id'],
            'polarity'    => ['required', Rule::in(['positive', 'negative'])],
            'weight'      => ['required', 'numeric', 'min:0', 'max:100'],
```

**Evidence**
```
$ vendor/bin/pint --test --format json Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryRequest.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Http\/Requests\/BaCategoryRequest.php","fixers":["unary_operator_spaces","not_operator_with_successor_space","blank_line_before_statement","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

#### BCAT-15 · H · deep-read #1/#6 — `forceDelete` permanently deletes a live, in-use category, bypassing the guard `destroy` enforces

| Field | Value |
|---|---|
| **Rule** | deep-read #1 (H, raised from M — the FKs cascade, so this destroys dependent rows rather than only unlinking them; sibling `CBNK-10` rated M because its FK is `ON DELETE SET NULL`) — *does any write delete data it should not?* / #6 *authorization hole — a guard bypassed by another route* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php:211-241` (specifically the guard at `:217-223`) |
| **Root cause** | `BaCategory::withTrashed()->findOrFail($id)` loads a live **or** trashed row and the only guard is `is_system`. `destroy` (line 140) refuses to trash a category when `usageReason()` is non-null (live sub-categories, class mappings, incidents, computed scores, comment templates, or in-use criteria); `forceDelete` never calls `usageReason()`. A `DELETE /behavioural-assessment/categories/{id}/force-delete` with a live id therefore hard-deletes it, and the DB FKs then act: `fk_ba_cc_cat` (`ba_class_category_jnt.category_id`) and `fk_ba_criteria_cat` (`ba_criteria.category_id`) are `ON DELETE CASCADE` — those rows are silently destroyed; `fk_ba_incident_cat` and `fk_ba_comment_cat` are `ON DELETE SET NULL` — incidents and comment templates silently lose their category link; `fk_ba_score_cat` (`ba_computed_scores.category_id`) is `ON DELETE RESTRICT` — a category with computed scores makes the statement throw, which the generic catch reports as "The operation could not be completed." |
| **Consequence** | An admin who holds `.forceDelete` (Super Admin and School Admin do) and calls the URL with a live id — or uses a stale trash page after a restore — irreversibly deletes a category that is still in use, destroying its class mappings and criteria and detaching incidents and comment templates, without the two-step trash safety net. |
| **Reproduce** | static only — needs the URL directly; the trash page cannot produce it for a live row. |
| **Fix approach** | Refuse unless `$category->trashed()` (matches the sibling `CBNK-10` fix). Because a category is only trashed while `usageReason()` is null, this closes the live-row path without changing the trashed-row behaviour. |
| **Plan item** | BCAT-15 in `02-fix-plan.md` §1 |

```php
// lines 215-223
        try {
            return DB::transaction(function () use ($id) {
                $category = BaCategory::withTrashed()->findOrFail($id);

                if ($category->is_system) {
                    return back()->with('error', 'System categories are part of the behavioural framework and cannot be deleted.');
                }
```

**Evidence**
```
$ sed -n '215,223p' Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
        try {
            return DB::transaction(function () use ($id) {
                $category = BaCategory::withTrashed()->findOrFail($id);

                if ($category->is_system) {
                    return back()->with('error', 'System categories are part of the behavioural framework and cannot be deleted.');
                }
$ grep -rn "references('id')->on('ba_categories')" database/migrations/tenant/
database/migrations/tenant/2026_06_16_130619_create_ba_computed_scores_table.php:50:            $table->foreign('category_id', 'fk_ba_score_cat')->references('id')->on('ba_categories')->restrictOnDelete();
database/migrations/tenant/2026_06_16_130618_create_ba_class_category_jnt_table.php:38:            $table->foreign('category_id', 'fk_ba_cc_cat')->references('id')->on('ba_categories')->cascadeOnDelete();
database/migrations/tenant/2026_06_16_130620_create_ba_criteria_table.php:40:            $table->foreign('category_id', 'fk_ba_criteria_cat')->references('id')->on('ba_categories')->cascadeOnDelete();
database/migrations/tenant/2026_06_16_130624_create_ba_incidents_table.php:76:            $table->foreign('category_id', 'fk_ba_incident_cat')->references('id')->on('ba_categories')->nullOnDelete();
database/migrations/tenant/2026_06_16_130628_create_ba_comment_bank_table.php:43:            $table->foreign('category_id', 'fk_ba_comment_cat')->references('id')->on('ba_categories')->nullOnDelete();
$ sed -n '136,142p' Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php
                if ($category->is_system) {
                    return back()->with('error', 'System categories are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
                }

                if ($reason = $category->usageReason()) {
                    return back()->with('error', "This category cannot be deleted because {$reason}. Deactivate it instead.");
                }
```

**F13 answers — one row per mutating method, eight columns (the eight deep-read questions).**

| Method | Q1 wrong data | Q2 delete-before-store | Q3 duplicate impl | Q4 soft-delete×unique | Q5 race | Q6 auth hole | Q7 lying message | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok | BCAT-11 | ok | ok | ok |
| `update` | ok | ok | ok | ok | BCAT-11 | ok | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | BCAT-15 | ok | ok | ok | ok | BCAT-15 | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |
| `reorder` | ok | ok | ok | ok | ok | ok | ok | ok |
| `storeCriterion` | ok | ok | ok | ok | BCAT-11 | ok | ok | ok |
| `updateCriterion` | ok | ok | ok | ok | ok | ok | ok | ok |
| `destroyCriterion` | ok | ok | ok | ok | ok | ok | ok | ok |

Notes on the cells: **Q4** — the partial unique indexes `uq_ba_cat_code` (`code`, `uq_guard`) and `uq_ba_criteria_code` (`category_id`, `code`, `uq_guard`) only cover non-deleted rows. `BaCategoryRequest` matches that with `->whereNull('deleted_at')`, `restore` re-checks for a live duplicate `code` before restoring (controller:186), and `syncCriteria` deletes removed rows before inserting new ones so a freed code can be reused — so a soft-delete × unique mismatch is not present. **Q5** — `restore` and `storeCriterion` rely on the DB unique index to turn a losing race into a caught violation. **Q2** — `syncCriteria` deletes first by design (a removed row's `code` must be free for a new row under `uq_ba_criteria_code`); the deleted rows are the user's removals, not a replacement. **Q7** — the only user messages are the fixed strings and the business messages ("System categories …", "This category cannot be deleted because …"); each matches what happened. `restore` leaves `is_active = false` (set by `destroy`) and its message "Category restored successfully." is still true; the user re-activates with the toggle. **Q8** — every stored field is read by `show`/`edit` or by `usageReason()`/the computation; no dead feature.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `app/Traits/AuthorizesTenantFeature.php` | Its `authorizeByCrudPermission()` maps POST to `create` and PUT/PATCH to `update`; a controller that *also* calls `Gate::authorize()` duplicates the check (this is BCAT-04). The trait is correct — the duplication is the caller's. | AUTH-04 | platform owners (informational) |
| `resources/views/components/backend/table/action-trashed.blade.php` | Reads the restore route's verb at render time, so a GET restore renders as a GET form. Correct as written; it adapts automatically when BCAT-06 changes the verb. | RTE-01 | no change needed |
| `resources/views/category/_create-fields.blade.php` + `pages/partials/masters/_categories-create-modal.blade.php` | The create **dialog** fields (rendered by `BaDashboardController::masters`) include the criteria grid, while the direct `/categories/create` page (`create.blade.php`, in scope) does not. A user who creates via the direct URL saves a category with no criteria. Deliberate (the file comment says the page "still exists and still works by direct URL"), so it is recorded, not fixed. | VIEW-01 | BaDashboardController report (not yet written) — decide whether the direct page stays |

## 8. Not covered, and why

- **No queue jobs, listeners, commands, events, mail or notifications** are named by this controller, so F8's job/tenant-context checks have nothing in scope.
- **The Masters tab list and create dialog** (`pages/partials/masters/_categories.blade.php`, `_categories-create-modal.blade.php`, `category/_create-fields.blade.php`) are rendered by `BaDashboardController::masters()`, not by this controller; they are referenced here only where they post to this controller's routes. `_categories.blade.php` was grepped for queries and returned none.
- **The `BaCategorySeeder`** and `config/permissionslist.php` seeding were checked only to confirm the permission keys exist (`'behavioural-assessment.categories' => $crud` at line 1407, `$crud` = `create/view/viewAny/update/delete/restore/forceDelete` at lines 176-184) and the roles holding them (Super Admin, School Admin); the seeder's exact-name queries were not audited as part of this controller.
- **No browser or test execution** (D4). Every finding is static/code-read evidence; BCAT-06's real-world trigger, BCAT-11's concurrency and BCAT-15's direct-URL path are not exercised.
- **Route-model binding (BCAT-07)** was left as a DECISION and not applied, so the current `findOrFail` behaviour is the measured baseline.
- **`BaActor`** (in scope but owned by the `BaCommentBankController` report) was read only for how this controller uses it (`created_by`/`updated_by`/`actor` ids); its full audit lives in that report.
