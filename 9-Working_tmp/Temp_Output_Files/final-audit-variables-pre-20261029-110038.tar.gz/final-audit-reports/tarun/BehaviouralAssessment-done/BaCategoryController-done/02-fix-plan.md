# Fix Plan — BehaviouralAssessment / BaCategoryController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` to `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | shared by all modules |
| `app/Traits/AuthorizesTenantFeature.php` | common app glue |
| `resources/views/components/backend/**` | shared components; `action-trashed` already adapts to the route verb, so BCAT-06 needs no component change |
| `Modules/BehaviouralAssessment/resources/views/category/**` | blades are clean — no plan item touches them |
| `database/migrations/tenant/**` | never edit an existing migration |
| `Modules/BehaviouralAssessment/routes/web.php` | ⚠ SHARED — named by BCAT-06 only; change line 40 and nothing else |
| `Modules/BehaviouralAssessment/app/Support/BaActor.php` | owned by the `BaCommentBankController` report; not edited here |

## 1. Blockers reachable today

- [ ] **BCAT-06** · H · RTE-01 · `Modules/BehaviouralAssessment/routes/web.php:40` — change the restore route from GET to POST so it can no longer change state without a CSRF token. ⚠ SHARED
  - **Touches:** `Modules/BehaviouralAssessment/routes/web.php`
  - **Before** (`web.php:40`):
    ```php
    Route::get('categories/{id}/restore', [BaCategoryController::class, 'restore'])->name('categories.restore');
    ```
  - **After:**
    ```php
    Route::post('categories/{id}/restore', [BaCategoryController::class, 'restore'])->name('categories.restore');
    ```
  - **Verify:** `grep -n "categories/{id}/restore" Modules/BehaviouralAssessment/routes/web.php`
  - **Expect:** the line begins with `Route::post(`, not `Route::get(`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

_None._

## 3. Errors & transactions (F1/F2)

- [ ] **BCAT-01** · M · ERR-00 (D1) · `BaCategoryController.php:7-467` — remove the ten controller `try/catch` wrappers and move each response out of its `DB::transaction` closure. This one item also carries BCAT-02 (the `getMessage()` logs go with the catches) and BCAT-03 (the response is no longer built inside the transaction).
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`
  - **Before** (imports, lines 7-20):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\Validation\Rule;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Http\Requests\BaCategoryRequest;
    use Modules\BehaviouralAssessment\Models\BaCategory;
    use Modules\BehaviouralAssessment\Models\BaCriterion;
    use Modules\BehaviouralAssessment\Support\BaActor;
    ```
  - **After:**
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Validation\Rule;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Http\Requests\BaCategoryRequest;
    use Modules\BehaviouralAssessment\Models\BaCategory;
    use Modules\BehaviouralAssessment\Models\BaCriterion;
    use Modules\BehaviouralAssessment\Support\BaActor;
    ```
  - **Before** (`store`, lines 39-70):
    ```php
    public function store(BaCategoryRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.create');

        try {
            return DB::transaction(function () use ($request) {
                $record = BaCategory::create($request->safe()->except(['criteria', 'criteria_submitted']) + [
                    // Appended to the end of its sibling group; the list's drag-and-drop reorders it.
                    'sort_order' => BaCategory::nextSortOrder($request->validated('parent_id')),
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                $this->syncCriteria($record, (array) $request->validated('criteria', []));

                activityLog($record, 'Stored', ['message' => 'BaCategory was stored.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'categories'])
                    ->with('success', 'Category created successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCategoryController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function store(BaCategoryRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.create');

        DB::transaction(function () use ($request): void {
            $record = BaCategory::create($request->safe()->except(['criteria', 'criteria_submitted']) + [
                // Appended to the end of its sibling group; the list's drag-and-drop reorders it.
                'sort_order' => BaCategory::nextSortOrder($request->validated('parent_id')),
                'created_by' => BaActor::id(),
                'updated_by' => BaActor::id(),
            ]);

            $this->syncCriteria($record, (array) $request->validated('criteria', []));

            activityLog($record, 'Stored', ['message' => 'BaCategory was stored.']);
        });

        return redirect()
            ->route('behavioural-assessment.masters', ['tab' => 'categories'])
            ->with('success', 'Category created successfully.');
    }
    ```
  - **Before** (`update`, lines 91-126):
    ```php
    public function update(BaCategoryRequest $request, int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');

        try {
            return DB::transaction(function () use ($request, $id) {
                $category = BaCategory::findOrFail($id);
                $data = $request->safe()->except(['criteria', 'criteria_submitted']) + ['updated_by' => BaActor::id()];
                // sort_order is per parent: a category moved under another parent goes to the end there.
                if ($data['parent_id'] != $category->parent_id) {
                    $data['sort_order'] = BaCategory::nextSortOrder($data['parent_id']);
                }
                $category->update($data);

                // Only when the grid was on the form: an emptied grid posts no criteria[] at all.
                if ($request->boolean('criteria_submitted')) {
                    $this->syncCriteria($category, (array) $request->validated('criteria', []));
                }

                activityLog($category, 'Updated', ['message' => 'BaCategory was updated.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'categories'])
                    ->with('success', 'Category updated successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCategoryController::update failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function update(BaCategoryRequest $request, int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');

        DB::transaction(function () use ($request, $id): void {
            $category = BaCategory::findOrFail($id);
            $data = $request->safe()->except(['criteria', 'criteria_submitted']) + ['updated_by' => BaActor::id()];
            // sort_order is per parent: a category moved under another parent goes to the end there.
            if ($data['parent_id'] != $category->parent_id) {
                $data['sort_order'] = BaCategory::nextSortOrder($data['parent_id']);
            }
            $category->update($data);

            // Only when the grid was on the form: an emptied grid posts no criteria[] at all.
            if ($request->boolean('criteria_submitted')) {
                $this->syncCriteria($category, (array) $request->validated('criteria', []));
            }

            activityLog($category, 'Updated', ['message' => 'BaCategory was updated.']);
        });

        return redirect()
            ->route('behavioural-assessment.masters', ['tab' => 'categories'])
            ->with('success', 'Category updated successfully.');
    }
    ```
  - **Before** (`destroy`, lines 128-165):
    ```php
    public function destroy(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.delete');

        try {
            return DB::transaction(function () use ($id) {
                $category = BaCategory::findOrFail($id);

                if ($category->is_system) {
                    return back()->with('error', 'System categories are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
                }

                if ($reason = $category->usageReason()) {
                    return back()->with('error', "This category cannot be deleted because {$reason}. Deactivate it instead.");
                }

                $category->is_active = false;
                $category->updated_by = BaActor::id();
                $category->save();
                $category->delete();

                activityLog($category, 'Trashed', ['message' => 'BaCategory was trashed.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'categories'])
                    ->with('success', 'Category moved to trash.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCategoryController::destroy failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function destroy(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.delete');

        $category = BaCategory::findOrFail($id);

        if ($category->is_system) {
            return back()->with('error', 'System categories are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
        }

        if ($reason = $category->usageReason()) {
            return back()->with('error', "This category cannot be deleted because {$reason}. Deactivate it instead.");
        }

        DB::transaction(function () use ($category): void {
            $category->is_active = false;
            $category->updated_by = BaActor::id();
            $category->save();
            $category->delete();

            activityLog($category, 'Trashed', ['message' => 'BaCategory was trashed.']);
        });

        return redirect()
            ->route('behavioural-assessment.masters', ['tab' => 'categories'])
            ->with('success', 'Category moved to trash.');
    }
    ```
  - **Before** (`restore`, lines 177-209):
    ```php
    public function restore(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.restore');

        try {
            return DB::transaction(function () use ($id) {
                $category = BaCategory::onlyTrashed()->findOrFail($id);

                // The code key only covers live rows, so a newer category may have taken this code.
                if (BaCategory::where('code', $category->code)->exists()) {
                    return back()->with('error', "Another category already uses the code {$category->code}. Change that category's code before restoring this one.");
                }

                $category->updated_by = BaActor::id();
                $category->restore();

                activityLog($category, 'Restored', ['message' => 'BaCategory was restored.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'categories'])
                    ->with('success', 'Category restored successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCategoryController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function restore(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.restore');

        $category = BaCategory::onlyTrashed()->findOrFail($id);

        // The code key only covers live rows, so a newer category may have taken this code.
        if (BaCategory::where('code', $category->code)->exists()) {
            return back()->with('error', "Another category already uses the code {$category->code}. Change that category's code before restoring this one.");
        }

        DB::transaction(function () use ($category): void {
            $category->updated_by = BaActor::id();
            $category->restore();

            activityLog($category, 'Restored', ['message' => 'BaCategory was restored.']);
        });

        return redirect()
            ->route('behavioural-assessment.masters', ['tab' => 'categories'])
            ->with('success', 'Category restored successfully.');
    }
    ```
  - **Before** (`forceDelete`, lines 211-241):
    ```php
    public function forceDelete(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.forceDelete');

        try {
            return DB::transaction(function () use ($id) {
                $category = BaCategory::withTrashed()->findOrFail($id);

                if ($category->is_system) {
                    return back()->with('error', 'System categories are part of the behavioural framework and cannot be deleted.');
                }

                $category->forceDelete();

                activityLog($category, 'Deleted', ['message' => 'BaCategory was deleted.']);

                return redirect()
                    ->route('behavioural-assessment.categories.trashed')
                    ->with('success', 'Category permanently deleted.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCategoryController::forceDelete failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function forceDelete(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.forceDelete');

        $category = BaCategory::withTrashed()->findOrFail($id);

        if ($category->is_system) {
            return back()->with('error', 'System categories are part of the behavioural framework and cannot be deleted.');
        }

        DB::transaction(function () use ($category): void {
            $category->forceDelete();

            activityLog($category, 'Deleted', ['message' => 'BaCategory was deleted.']);
        });

        return redirect()
            ->route('behavioural-assessment.categories.trashed')
            ->with('success', 'Category permanently deleted.');
    }
    ```
  - **Before** (`toggleStatus`, lines 243-277):
    ```php
    public function toggleStatus(int $category): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');

        try {
            return DB::transaction(function () use ($category) {
                $cat = BaCategory::findOrFail($category);
                $cat->is_active = ! $cat->is_active;
                $cat->updated_by = BaActor::id();
                $cat->save();

                activityLog($cat, 'Toggled', ['message' => 'BaCategory was toggled.']);

                return response()->json([
                    'success' => true,
                    'is_active' => $cat->is_active,
                    'message' => $cat->is_active ? 'Category activated.' : 'Category deactivated.',
                ]);

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCategoryController::toggleStatus failed', ['error' => $e->getMessage()]);

            // Declared `: JsonResponse` — a redirect here was a TypeError, and the fetch() caller
            // would have followed it instead of seeing the failure.
            return response()->json([
                'success' => false,
                'message' => 'The operation could not be completed.',
            ], 500);
        }
    }
    ```
  - **After:**
    ```php
    public function toggleStatus(int $category): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');

        $cat = BaCategory::findOrFail($category);

        DB::transaction(function () use ($cat): void {
            $cat->is_active = ! $cat->is_active;
            $cat->updated_by = BaActor::id();
            $cat->save();

            activityLog($cat, 'Toggled', ['message' => 'BaCategory was toggled.']);
        });

        return response()->json([
            'success' => true,
            'is_active' => $cat->is_active,
            'message' => $cat->is_active ? 'Category activated.' : 'Category deactivated.',
        ]);
    }
    ```
  - **Before** (`reorder`, lines 286-338):
    ```php
    public function reorder(Request $request): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');

        $validated = $request->validate([
            'order' => ['required', 'array'],
            'order.*' => ['integer', 'distinct', 'exists:ba_categories,id'],
        ]);

        try {
            return DB::transaction(function () use ($validated) {
                $order = array_map('intval', $validated['order']);
                $rows = BaCategory::whereIn('id', $order)->get(['id', 'parent_id', 'sort_order'])->keyBy('id');

                // The screen only lets a row move among its siblings; refuse a mixed post outright.
                if ($rows->pluck('parent_id')->unique()->count() > 1) {
                    return response()->json([
                        'success' => false,
                        'message' => 'A category can only be reordered among categories with the same parent.',
                    ], 422);
                }

                $positions = $rows->pluck('sort_order')->map(fn ($v) => (int) $v)->sort()->values()->all();
                for ($i = 1; $i < count($positions); $i++) {
                    $positions[$i] = max($positions[$i], $positions[$i - 1] + 1);
                }

                foreach ($order as $i => $id) {
                    BaCategory::where('id', $id)->update([
                        'sort_order' => $positions[$i],
                        'updated_by' => BaActor::id(),
                    ]);
                }

                // One entry for the drag, not one per row moved.
                activityLog(BaCategory::find($order[0]), 'Reordered', [
                    'message' => 'Behaviour categories were reordered.',
                    'category_ids' => $order,
                ]);

                return response()->json(['success' => true, 'message' => 'Order updated.']);
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCategoryController::reorder failed', ['error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'The operation could not be completed.',
            ], 500);
        }
    }
    ```
  - **After:**
    ```php
    public function reorder(Request $request): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');

        $validated = $request->validate([
            'order' => ['required', 'array'],
            'order.*' => ['integer', 'distinct', 'exists:ba_categories,id'],
        ]);

        $order = array_map('intval', $validated['order']);
        $rows = BaCategory::whereIn('id', $order)->get(['id', 'parent_id', 'sort_order'])->keyBy('id');

        // The screen only lets a row move among its siblings; refuse a mixed post outright.
        if ($rows->pluck('parent_id')->unique()->count() > 1) {
            return response()->json([
                'success' => false,
                'message' => 'A category can only be reordered among categories with the same parent.',
            ], 422);
        }

        $positions = $rows->pluck('sort_order')->map(fn ($v) => (int) $v)->sort()->values()->all();
        for ($i = 1; $i < count($positions); $i++) {
            $positions[$i] = max($positions[$i], $positions[$i - 1] + 1);
        }

        DB::transaction(function () use ($order, $positions): void {
            foreach ($order as $i => $id) {
                BaCategory::where('id', $id)->update([
                    'sort_order' => $positions[$i],
                    'updated_by' => BaActor::id(),
                ]);
            }

            // One entry for the drag, not one per row moved.
            activityLog(BaCategory::find($order[0]), 'Reordered', [
                'message' => 'Behaviour categories were reordered.',
                'category_ids' => $order,
            ]);
        });

        return response()->json(['success' => true, 'message' => 'Order updated.']);
    }
    ```
  - **Before** (`storeCriterion`, lines 340-382):
    ```php
    public function storeCriterion(Request $request, int $category): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');
        BaCategory::findOrFail($category);

        // Validated OUTSIDE the try: the generic catch below used to swallow the
        // ValidationException, so a bad criterion showed "could not be completed" instead of the error.
        $request->merge(['code' => strtoupper(trim((string) $request->input('code')))]);
        $validated = $request->validate($this->criterionRules($category));

        try {
            return DB::transaction(function () use ($request, $validated, $category) {
                $criterion = BaCriterion::create([
                    'category_id' => $category,
                    'code' => $validated['code'],
                    'name' => $validated['name'],
                    'description' => $request->description,
                    'weight' => $validated['weight'] ?? 1.00,
                    'sort_order' => BaCriterion::nextSortOrder($category),
                    'is_active' => true,
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($criterion, 'Stored', [
                    'message' => 'Behaviour criterion was created.',
                    'category_id' => $category,
                    'name' => $criterion->name,
                ]);

                return back()->with('success', 'Criterion added.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCategoryController::storeCriterion failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function storeCriterion(Request $request, int $category): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');
        BaCategory::findOrFail($category);

        $request->merge(['code' => strtoupper(trim((string) $request->input('code')))]);
        $validated = $request->validate($this->criterionRules($category));

        DB::transaction(function () use ($request, $validated, $category): void {
            $criterion = BaCriterion::create([
                'category_id' => $category,
                'code' => $validated['code'],
                'name' => $validated['name'],
                'description' => $request->description,
                'weight' => $validated['weight'] ?? 1.00,
                'sort_order' => BaCriterion::nextSortOrder($category),
                'is_active' => true,
                'created_by' => BaActor::id(),
                'updated_by' => BaActor::id(),
            ]);

            activityLog($criterion, 'Stored', [
                'message' => 'Behaviour criterion was created.',
                'category_id' => $category,
                'name' => $criterion->name,
            ]);
        });

        return back()->with('success', 'Criterion added.');
    }
    ```
  - **Before** (`updateCriterion`, lines 384-428):
    ```php
    public function updateCriterion(Request $request, int $category, int $criterion): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');

        $record = BaCriterion::where('category_id', $category)->findOrFail($criterion);

        $request->merge(['code' => strtoupper(trim((string) $request->input('code')))]);
        $validated = $request->validate($this->criterionRules($category, $criterion));

        // A seeded criterion keeps its code: the framework seeder finds it by code.
        if ($record->is_system && $validated['code'] !== $record->code) {
            return back()->withErrors(['code' => 'This is a system criterion; its code cannot be changed.'])->withInput();
        }

        try {
            return DB::transaction(function () use ($request, $validated, $record, $category) {
                $record->update([
                    'code' => $validated['code'],
                    'name' => $validated['name'],
                    // The inline row form carries no description; only overwrite it when one is sent.
                    'description' => $request->has('description') ? $request->description : $record->description,
                    'weight' => $validated['weight'] ?? $record->weight,
                    // Only the row form sends is_active (hidden 0 + checkbox); keep the value when absent.
                    'is_active' => $request->has('is_active') ? $request->boolean('is_active') : $record->is_active,
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Updated', [
                    'message' => 'Behaviour criterion was updated.',
                    'category_id' => $category,
                ]);

                return back()->with('success', 'Criterion updated.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCategoryController::updateCriterion failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function updateCriterion(Request $request, int $category, int $criterion): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');

        $record = BaCriterion::where('category_id', $category)->findOrFail($criterion);

        $request->merge(['code' => strtoupper(trim((string) $request->input('code')))]);
        $validated = $request->validate($this->criterionRules($category, $criterion));

        // A seeded criterion keeps its code: the framework seeder finds it by code.
        if ($record->is_system && $validated['code'] !== $record->code) {
            return back()->withErrors(['code' => 'This is a system criterion; its code cannot be changed.'])->withInput();
        }

        DB::transaction(function () use ($request, $validated, $record, $category): void {
            $record->update([
                'code' => $validated['code'],
                'name' => $validated['name'],
                // The inline row form carries no description; only overwrite it when one is sent.
                'description' => $request->has('description') ? $request->description : $record->description,
                'weight' => $validated['weight'] ?? $record->weight,
                // Only the row form sends is_active (hidden 0 + checkbox); keep the value when absent.
                'is_active' => $request->has('is_active') ? $request->boolean('is_active') : $record->is_active,
                'updated_by' => BaActor::id(),
            ]);

            activityLog($record, 'Updated', [
                'message' => 'Behaviour criterion was updated.',
                'category_id' => $category,
            ]);
        });

        return back()->with('success', 'Criterion updated.');
    }
    ```
  - **Before** (`destroyCriterion`, lines 430-467):
    ```php
    public function destroyCriterion(int $category, int $criterion): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.delete');

        try {
            return DB::transaction(function () use ($category, $criterion) {
                if (BaCriterion::usedIds([$criterion]) !== []) {
                    return back()->with('error', 'Cannot delete this criterion because ratings or incidents have been recorded against it. Deactivate it instead.');
                }

                $record = BaCriterion::where('category_id', $category)->findOrFail($criterion);

                if ($record->is_system) {
                    return back()->with('error', 'System criteria are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
                }

                $record->delete();

                // The guard above returns before this line, so a criterion that already has
                // ratings against it writes no delete and no log (§4).
                activityLog($record, 'Trashed', [
                    'message' => 'Behaviour criterion was removed.',
                    'category_id' => $category,
                ]);

                return back()->with('success', 'Criterion removed.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaCategoryController::destroyCriterion failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function destroyCriterion(int $category, int $criterion): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.delete');

        if (BaCriterion::usedIds([$criterion]) !== []) {
            return back()->with('error', 'Cannot delete this criterion because ratings or incidents have been recorded against it. Deactivate it instead.');
        }

        $record = BaCriterion::where('category_id', $category)->findOrFail($criterion);

        if ($record->is_system) {
            return back()->with('error', 'System criteria are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
        }

        DB::transaction(function () use ($record, $category): void {
            $record->delete();

            activityLog($record, 'Trashed', [
                'message' => 'Behaviour criterion was removed.',
                'category_id' => $category,
            ]);
        });

        return back()->with('success', 'Criterion removed.');
    }
    ```
  - **Verify:** `grep -n -e "try {" -e "catch (" -e "Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`
  - **Expect:** no output.
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **BCAT-04** · L · AUTH-04 · `BaCategoryController.php:41,93` — drop the two controller gate calls that duplicate `BaCategoryRequest::authorize()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`
  - **Before** (`store`, line 41):
    ```php
        Gate::authorize('tenant.behavioural-assessment.categories.create');
    ```
  - **After:**
    ```php
        // Authorization enforced by BaCategoryRequest::authorize() (AUTH-04: one check, not two).
    ```
  - **Before** (`update`, line 93):
    ```php
        Gate::authorize('tenant.behavioural-assessment.categories.update');
    ```
  - **After:**
    ```php
        // Authorization enforced by BaCategoryRequest::authorize() (AUTH-04: one check, not two).
    ```
  - **Verify:** `grep -c "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`
  - **Expect:** `13` (was 15; the `store` and `update` duplicates were removed, while `create()` at line 33 keeps its `.create` gate).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **BCAT-05** · M · VAL-02 · `BaCategoryController.php:290-293,348,391,521-536` — move the reorder and criterion validation out of the controller into FormRequests, and delete the now-unused `criterionRules()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`, `Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryReorderRequest.php`, `Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryCriterionRequest.php`
  - **Before** (`reorder` signature and validate block, lines 286-293):
    ```php
    public function reorder(Request $request): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');

        $validated = $request->validate([
            'order' => ['required', 'array'],
            'order.*' => ['integer', 'distinct', 'exists:ba_categories,id'],
        ]);
    ```
  - **After:**
    ```php
    public function reorder(BaCategoryReorderRequest $request): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.categories.update');

        $validated = $request->validated();
    ```
  - **Before** (`storeCriterion`/`updateCriterion` validate lines, 348 and 391):
    ```php
        $request->merge(['code' => strtoupper(trim((string) $request->input('code')))]);
        $validated = $request->validate($this->criterionRules($category));
    ```
  - **After:**
    ```php
        $validated = $request->validated();
    ```
  - **Before** (`updateCriterion`, lines 390-391):
    ```php
        $request->merge(['code' => strtoupper(trim((string) $request->input('code')))]);
        $validated = $request->validate($this->criterionRules($category, $criterion));
    ```
  - **After:**
    ```php
        $validated = $request->validated();
    ```
  - **After** (change the two signatures):
    ```php
    public function storeCriterion(BaCategoryCriterionRequest $request, int $category): RedirectResponse
    ```
    ```php
    public function updateCriterion(BaCategoryCriterionRequest $request, int $category, int $criterion): RedirectResponse
    ```
  - **After** (new file `Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryReorderRequest.php`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\BehaviouralAssessment\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;

    /**
     * Drag-and-drop reorder payload for ba_categories. Authorization is enforced by the
     * controller's Gate::authorize call, so authorize() stays open here.
     */
    class BaCategoryReorderRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }

        public function rules(): array
        {
            return [
                'order' => ['required', 'array'],
                'order.*' => ['integer', 'distinct', 'exists:ba_categories,id'],
            ];
        }
    }
    ```
  - **After** (new file `Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryCriterionRequest.php`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\BehaviouralAssessment\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;

    /**
     * Add/update one ba_criteria row. uq_ba_criteria_code is (category_id, code, uq_guard):
     * a code is unique within its category among NON-deleted criteria only.
     */
    class BaCategoryCriterionRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }

        protected function prepareForValidation(): void
        {
            $this->merge(['code' => strtoupper(trim((string) $this->input('code')))]);
        }

        public function rules(): array
        {
            $category = (int) ($this->route('category') ?? 0);
            $ignore = $this->route('criterion');

            return [
                'code' => [
                    'required', 'string', 'max:30', 'regex:/^[A-Z0-9_\-]+$/',
                    Rule::unique('ba_criteria', 'code')
                        ->where('category_id', $category)
                        ->whereNull('deleted_at')
                        ->ignore($ignore),
                ],
                'name' => ['required', 'string', 'max:255'],
                'description' => ['nullable', 'string'],
                'weight' => ['nullable', 'numeric', 'min:0', 'max:100'],
                'is_active' => ['nullable', 'boolean'],
            ];
        }
    }
    ```
  - **Note:** after this item, delete the private `criterionRules()` method (lines 515-536) — it becomes dead code (CTL-10) — and remove the now-unused `use Illuminate\Validation\Rule;` from the controller; add the two new `use` lines for the FormRequests. The fixer greps for `criterionRules` callers first.
  - **Verify:** `grep -n "criterionRules\|request->validate(" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`
  - **Expect:** no output; `php -l` reports no syntax errors on both new request files.
  - **Effort:** M

- [ ] **BCAT-15** · H · deep-read #1/#6 · `BaCategoryController.php:211-241` — refuse a permanent delete unless the category is already trashed, closing the live-row cascade-delete path. **Apply after BCAT-01** (which rewrites this method; the Before below is the current text).
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`
  - **Before** (`forceDelete` guard):
    ```php
        $category = BaCategory::withTrashed()->findOrFail($id);

        if ($category->is_system) {
            return back()->with('error', 'System categories are part of the behavioural framework and cannot be deleted.');
        }
    ```
  - **After:**
    ```php
        $category = BaCategory::withTrashed()->findOrFail($id);

        if (! $category->trashed()) {
            return back()->with('error', 'Only a trashed category can be permanently deleted.');
        }

        if ($category->is_system) {
            return back()->with('error', 'System categories are part of the behavioural framework and cannot be deleted.');
        }
    ```
  - **Verify:** `grep -n "Only a trashed category" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`
  - **Expect:** one match in `forceDelete`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **BCAT-08** · M · QRY-01 · `BaCategoryController.php:313-318` — replace the per-row UPDATE loop in `reorder` with one bulk CASE update. Applicable after BCAT-01 (the loop text is unchanged by it).
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`
  - **Before** (`reorder` loop, lines 313-318):
    ```php
                foreach ($order as $i => $id) {
                    BaCategory::where('id', $id)->update([
                        'sort_order' => $positions[$i],
                        'updated_by' => BaActor::id(),
                    ]);
                }
    ```
  - **After:**
    ```php
                $caseBindings = [];
                $idBindings = [];
                $idPlaceholders = [];

                foreach ($order as $i => $id) {
                    $caseBindings[] = (int) $id;
                    $caseBindings[] = $positions[$i];
                    $idBindings[] = (int) $id;
                    $idPlaceholders[] = '?';
                }

                DB::update(
                    'UPDATE ba_categories SET sort_order = CASE id '
                        .implode(' ', array_fill(0, count($order), 'WHEN ? THEN ?')).' END, updated_by = ? '
                        .'WHERE id IN ('.implode(',', $idPlaceholders).')',
                    array_merge($caseBindings, [BaActor::id()], $idBindings)
                );
    ```
  - **Verify:** `grep -n "BaCategory::where('id', \$id)->update" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **BCAT-09** · M · QRY-07 · `BaCategoryController.php:482-490` — bulk the removed-criterion writes in `syncCriteria` into one update plus one soft-delete. Applicable after BCAT-01.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`
  - **Before** (`syncCriteria` removal loop, lines 482-490):
    ```php
        foreach ($existing->except($keptIds) as $removed) {
            $removed->update(['is_active' => false, 'updated_by' => BaActor::id()]);
            $removed->delete();
            activityLog($removed, 'Trashed', [
                'message' => 'Behaviour criterion was removed.',
                'category_id' => $category->id,
                'name' => $removed->name,
            ]);
        }
    ```
  - **After:**
    ```php
        $removedCriteria = $existing->except($keptIds);
        if ($removedCriteria->isNotEmpty()) {
            $removedIds = $removedCriteria->keys()->all();
            BaCriterion::whereIn('id', $removedIds)->update(['is_active' => false, 'updated_by' => BaActor::id()]);

            foreach ($removedCriteria as $removed) {
                $removed->delete();
                activityLog($removed, 'Trashed', [
                    'message' => 'Behaviour criterion was removed.',
                    'category_id' => $category->id,
                    'name' => $removed->name,
                ]);
            }
        }
    ```
  - **Verify:** `grep -n "foreach (\$existing->except" Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BCAT-10** · L · QRY-03 · `Modules/BehaviouralAssessment/app/Models/BaCategory.php:94-98` — select only the two columns the parent dropdown uses.
  - **Touches:** `Modules/BehaviouralAssessment/app/Models/BaCategory.php`
  - **Before** (`parentOptions`, lines 94-98):
    ```php
        return static::whereNull('parent_id')
            ->where('is_active', true)
            ->when($exceptId, fn ($q) => $q->where('id', '!=', $exceptId))
            ->orderBy('name')
            ->get();
    ```
  - **After:**
    ```php
        return static::whereNull('parent_id')
            ->where('is_active', true)
            ->when($exceptId, fn ($q) => $q->where('id', '!=', $exceptId))
            ->orderBy('name')
            ->get(['id', 'name']);
    ```
  - **Verify:** `grep -n "->get(\['id', 'name'\]);" Modules/BehaviouralAssessment/app/Models/BaCategory.php`
  - **Expect:** one match inside `parentOptions()`.
  - **Effort:** S

## 7. Views (F10)

_None._

## 8. Style (F12) — one item per file

- [ ] **BCAT-12** · L · STY-02 · `Modules/BehaviouralAssessment/app/Models/BaCategory.php:8-11,117` — import `DB`, move `Collection` into sorted order.
  - **Touches:** `Modules/BehaviouralAssessment/app/Models/BaCategory.php`
  - **Before** (`BaCategory.php:7-11`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Support\Collection;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **After:**
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Collection;
    use Illuminate\Support\Facades\DB;
    ```
  - **Before** (`BaCategory.php:117`):
    ```php
            $db = \Illuminate\Support\Facades\DB::class;
    ```
  - **After:**
    ```php
            $db = DB::class;
    ```
  - **Note:** running `vendor/bin/pint Modules/BehaviouralAssessment/app/Models/BaCategory.php --format agent` produces exactly the import order and `DB::class` shown above.
  - **Verify:** `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Models/BaCategory.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

- [ ] **BCAT-13** · L · STY-02 · `Modules/BehaviouralAssessment/app/Models/BaCriterion.php:89,91` — import `DB` and use it in `usedIds()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Models/BaCriterion.php`
  - **Before** (`BaCriterion.php:88-93`):
    ```php
        return \Illuminate\Support\Facades\DB::table('ba_assessment_ratings')
            ->whereIn('criterion_id', $ids)->whereNull('deleted_at')->distinct()->pluck('criterion_id')
            ->merge(\Illuminate\Support\Facades\DB::table('ba_incidents')
                ->whereIn('criterion_id', $ids)->whereNull('deleted_at')->distinct()->pluck('criterion_id'))
            ->map(fn ($v) => (int) $v)->unique()->values()->all();
    ```
  - **After:**
    ```php
        return DB::table('ba_assessment_ratings')
            ->whereIn('criterion_id', $ids)->whereNull('deleted_at')->distinct()->pluck('criterion_id')
            ->merge(DB::table('ba_incidents')
                ->whereIn('criterion_id', $ids)->whereNull('deleted_at')->distinct()->pluck('criterion_id'))
            ->map(fn ($v) => (int) $v)->unique()->values()->all();
    ```
  - **Before** (import block, `BaCriterion.php:7-10`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **After:**
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Facades\DB;
    ```
  - **Verify:** `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Models/BaCriterion.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

- [ ] **BCAT-14** · L · STY-02 · `Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryRequest.php:33-50,58-61,70-73` — un-align the array `=>` so the file is Pint-clean.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryRequest.php`
  - **Before** (`BaCategoryRequest.php:33-37`):
    ```php
            'code'        => ['required', 'string', 'max:30', 'regex:/^[A-Z0-9_\-]+$/', Rule::unique('ba_categories', 'code')->ignore($id)->whereNull('deleted_at')],
            'name'        => ['required', 'string', 'max:100'],
            'parent_id'   => ['nullable', 'exists:ba_categories,id'],
            'polarity'    => ['required', Rule::in(['positive', 'negative'])],
            'weight'      => ['required', 'numeric', 'min:0', 'max:100'],
    ```
  - **After:**
    ```php
            'code' => ['required', 'string', 'max:30', 'regex:/^[A-Z0-9_\-]+$/', Rule::unique('ba_categories', 'code')->ignore($id)->whereNull('deleted_at')],
            'name' => ['required', 'string', 'max:100'],
            'parent_id' => ['nullable', 'exists:ba_categories,id'],
            'polarity' => ['required', Rule::in(['positive', 'negative'])],
            'weight' => ['required', 'numeric', 'min:0', 'max:100'],
    ```
  - **Note:** the same alignment fixer applies to the `criteria_*` keys (`:43-50`), `prepareForValidation()` (`:58-61`) and `messages()` (`:70-73`); running `vendor/bin/pint Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryRequest.php --format agent` fixes all of them at once.
  - **Verify:** `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaCategoryRequest.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BCAT-07** · M · DECISION · CTL-03 — switch the controller to route model binding instead of `$id`/`$category` plus `findOrFail()`?
  - **Why it is a decision:** binding `update`/`destroy`/`toggleStatus` needs no route change (their parameter is already `{category}`), but binding `restore`/`forceDelete` requires renaming their `{id}` route parameters to `{category}` with `->withTrashed()` — a shared route-file change. The current `findOrFail()` is correct, so this is a consistency choice, not a behaviour bug.
  - (a) ⭐ defer — keep `findOrFail()` as it is; it is explicit, correct, and needs no route change. Record `CTL-03` as accepted.
  - (b) apply binding now — `show`/`update`/`destroy`/`toggleStatus` take `BaCategory $category`; the `restore`/`forceDelete` routes are renamed to `{category}` and gain `->withTrashed()`; the `findOrFail()` calls for the category are dropped (the scoped `{criterion}` lookups stay). Touches the controller and `routes/web.php`.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BCAT-02 | The `Log::error(..., $e->getMessage())` calls are deleted by BCAT-01; no separate edit is needed. |
| BCAT-03 | The response is moved out of the transaction by BCAT-01's rewrite; no separate edit is needed. |
| BCAT-11 | Accepted: the max-then-insert race only affects list ordering, and a unique index on `sort_order` is impossible because `reorder` writes intermediate duplicate positions mid-operation. |
