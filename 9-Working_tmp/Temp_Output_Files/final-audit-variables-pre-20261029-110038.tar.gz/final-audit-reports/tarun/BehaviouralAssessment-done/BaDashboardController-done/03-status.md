# Status — BehaviouralAssessment / BaDashboardController

**Fixed:** 2026-10-22 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work

none — no `PRE-APPLIED-*.md` lists files in this controller's scope, and the orchestrator pre-applied no route changes for this controller.

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| BH-01 | `…/BaDashboardController.php:609-616` | `snapshotIntegrity()` catch now calls `report($e)` after the ERR-01 comment instead of `Log::warning(… $e->getMessage())`; the per-row catch itself stays. | `grep -n "getMessage" …/BaDashboardController.php` | no output | 2026-10-22 |
| BH-05 | `…/BaDashboardController.php:1911-1937` | The 26-variable `compact()` in `reportsPage()` replaced by the explicit keyed array from the plan. | `grep -n "compact(" …/BaDashboardController.php` | only dashboard 198, masters 458, setup 534, incidents 1497 and the 4-key `filters` compact at 2035 remain; the reports-page `compact(` is gone | 2026-10-22 |
| BH-10 | `…/BaDashboardController.php:1439-1444`, `:1497-1502`; `…/incidents/_witnesses.blade.php:122-126` | `incidentsPage()` now builds `witnessStudentMap` / `witnessStaffMap` from the page's own `$witnesses` collection and passes them; the blade `@php` block only aliases them (`$wStudents` / `$wStaff`) and runs no query. | `grep -n "Student::whereIn\|Employee::with" …/_witnesses.blade.php` | no output | 2026-10-22 |
| BH-11 | `…/BaDashboardController.php:1696-1702`, `:741`, `:869`, `:894`, `:1085`, `:1990` | The orphaned `outboxData()` docblock was removed from above `interventionCaseData()` and placed above `outboxData()`; the five `⚠ ` prefixes were deleted (rest of each line byte-for-byte unchanged). | `grep -n "⚠" …/BaDashboardController.php` · `grep -c "Notification Outbox list" …/BaDashboardController.php` | no output · `1` | 2026-10-22 |
| BH-02 (a) | `…/routes/web.php:31-33`; `…/BaDashboardController.php:1906-1910`, `:1938-1958`, `:2134-2136`, `:2195-2205`; `…/reports/_demographics.blade.php:6`, `:42-43` | Demographics run converted to POST: new `POST behavioural-assessment/reports-page/demographics` → `demographicsRun()` (name `behavioural-assessment.reports-page.demographics`) added in the Page routes block. `demographicsRun()` authorizes `reports-page.viewAny` + `demographic-analytics.view`, calls `demographicAnalytics(true)`, and redirects back to `tab=demographics` with `dm_period_id` / `dm_dimension`. `demographicAnalytics()` gained `bool $audit = true`; the `BaAuditLog::log(...)` row stays but runs only when `$audit` is true. The GET path in `reportsPage()` now passes `false`, so a GET never writes. The tab form is `method="POST"`, posts to the new route with `@csrf`, and keeps the hidden `tab` field. | route probe + `php -l` | `POST behavioural-assessment/reports-page/demographics behavioural-assessment.reports-page.demographics` present; `ROUTES-OK` | 2026-10-22 |

## 3. Not applied

| ID | Reason (not ticked / already applied / superseded / blocked) | Detail |
|---|---|---|
| BH-03 | deferred — approved choice (a) ⭐ | God-controller split deferred to the split pass (D3); no code change. |
| BH-04 | deferred — approved choice (a) ⭐ | Method extraction / per-tab gating deferred to the split pass (D3); no code change. |
| BH-07 | deferred — approved choice (a) ⭐ | Constructor injection of the three services deferred to the split pass; no code change. |
| BH-08 | deferred — approved choice (a) ⭐ | Ratings-tab map scoping deferred to the split pass (with production re-measurement first); no code change. |
| BH-06 | no plan item — accepted | Plan §10: 98 `request()` helper uses accepted as low-severity debt; the split pass will do the codemod. No code change. |

### Decisions recorded (2026-10-22)

| Decision | Choice | Effect |
|---|---|---|
| BH-02 · RTE-01 | **(a) ⭐ convert the analytics run to POST** | Applied in full — see §2. |
| BH-03 · CTL-01 | **(a) ⭐ defer to the split pass (D3)** | Recorded only. |
| BH-04 · CTL-02 | **(a) ⭐ defer extraction to the split pass (D3)** | Recorded only. |
| BH-07 · SVC-02 | **(a) ⭐ defer constructor injection to the split pass** | Recorded only. |
| BH-08 · QRY-05 | **(a) ⭐ defer to the split pass; re-measure on a production tenant first** | Recorded only. |

## 4. Needs Tarun's hand

- **Browser check of the Demographics tab (BH-02):** confirm the form submits (CSRF + POST), the redirect returns to `?tab=demographics` with the filters, the table renders, and exactly one `ba_audit_log` row (`field_name = demographic_analytics`) appears per Run click. Not executed here (D4).
- **Folder rename to `BaDashboardController-done/` (§10.1):** not done — this task specified the non-suffixed `BaDashboardController/` path. Rename and rewrite the links when Tarun wants it.
- No migration, seeder or permission sync needed.

## 5. Unverifiable by this workflow (no tests, D4)

- The POST → redirect → GET round-trip, CSRF rejection, and the single-audit-row guarantee are proven statically only; no HTTP request was executed.
- Blade behaviour of the converted form in a browser (button submit, selected option retention after redirect) was not exercised.
- Pint ran with `fully_qualified_strict_types` on the touched PHP files, so it also shortened fully-qualified class references and added their imports across `BaDashboardController.php` and `routes/web.php`. These are style-only (Pint-clean); no behaviour was inspected beyond `php -l` + `class_exists` + the route list.

## 6. Verification log

```
$ php -l Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
$ php -l Modules/BehaviouralAssessment/routes/web.php
No syntax errors detected in Modules/BehaviouralAssessment/routes/web.php
$ php -r class_exists probe
bool(true)
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json >/dev/null && echo ROUTES-OK
ROUTES-OK
$ vendor/bin/pint Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php Modules/BehaviouralAssessment/routes/web.php --format agent
{"tool":"pint","result":"fixed","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Http\/Controllers\/BaDashboardController.php","fixers":["fully_qualified_strict_types","unary_operator_spaces","not_operator_with_successor_space","ordered_imports","phpdoc_align"]},{"path":"Modules\/BehaviouralAssessment\/routes\/web.php","fixers":["fully_qualified_strict_types","ordered_imports"]}]}
$ php -l (again, after Pint)
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
No syntax errors detected in Modules/BehaviouralAssessment/routes/web.php
$ class_exists (again, after Pint)
bool(true)
$ vendor/bin/pint <same files> --format agent   (final state)
{"tool":"pint","result":"passed"}
$ blade compile + @push count + php -l (touched blades)
Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/_witnesses.blade.php | @push(src)=0 startPush(out)=0 | No syntax errors detected in /tmp/bladeedtqrm0r8ugjebN5tfF.php
Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_demographics.blade.php | @push(src)=0 startPush(out)=0 | No syntax errors detected in /tmp/blade1935it18ec2h0V5BfGH.php
$ BH-01: grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
(no output)
$ BH-05: grep -n "compact(" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
198:        return view('behaviouralassessment::pages.dashboard', compact(
458:        return view('behaviouralassessment::pages.masters', compact(
534:        return view('behaviouralassessment::pages.setup', array_merge(compact(
1497:        return view('behaviouralassessment::pages.incidents', compact(
2035:            'filters' => compact('periodId', 'classSectionId', 'reason', 'search'),
$ BH-10: grep -n "Student::whereIn\|Employee::with" Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/_witnesses.blade.php
(no output)
$ BH-11: grep -n "⚠" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
(no output)
$ BH-11: grep -c "Notification Outbox list" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
1
$ BH-02: route probe for BaDashboardController
GET|HEAD  behavioural-assessment                               behavioural-assessment.dashboard
GET|HEAD  behavioural-assessment/assessments-page              behavioural-assessment.assessments-page
GET|HEAD  behavioural-assessment/incidents-page                behavioural-assessment.incidents-page
GET|HEAD  behavioural-assessment/masters                       behavioural-assessment.masters
GET|HEAD  behavioural-assessment/reports-page                  behavioural-assessment.reports-page
POST      behavioural-assessment/reports-page/demographics     behavioural-assessment.reports-page.demographics
GET|HEAD  behavioural-assessment/setup                         behavioural-assessment.setup
$ grep -n "demographicsRun" (controller + routes)
Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php:1945:    public function demographicsRun(): RedirectResponse
Modules/BehaviouralAssessment/routes/web.php:33:Route::post('/reports-page/demographics', [BaDashboardController::class, 'demographicsRun'])->name('reports-page.demographics');
```

## 7. Final state

Status: FIXED · Open: B 0 · H 1 (BH-04, deferred) · M 3 (BH-03, BH-07, BH-08, deferred) · L 1 (BH-06, accepted)
