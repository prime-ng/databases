# Fix Plan — BehaviouralAssessment / BaDashboardController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/BehaviouralAssessment/routes/web.php` | route file, shared by the whole module — a normal fix never adds or changes a route. Only a ticked BH-02 decision may propose a route change, and that change itself is a separate shared decision |
| `config/permissionslist.php` | shared permission registry; no finding needs a permission change |
| `Modules/BehaviouralAssessment/app/Models/*` and `app/Services/*` | owned by other reports (see 01-report §3 links) — do not edit |
| `Modules/BehaviouralAssessment/resources/views/pages/partials/masters/_comment-bank*.blade.php`, `…/reports/_exports.blade.php` | owned by BaCommentBankController / BaReportController |
| `resources/views/components/**`, the layouts, `Modules/TenantCore/**` | common/shared components |
| `database/migrations/**` | never edit an existing migration (standing rule) |

## 1. Blockers reachable today

None without a DECISION (the only state-change over GET, BH-02, is a decision below).

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **BH-01** · M · ERR-05 · `BaDashboardController.php:602-608` — log the exception object, not the message, in `snapshotIntegrity()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php`
  - **Before** (`BaDashboardController.php:602-608`):
    ```php
            try {
                return [$snapshot->id => (bool) $service->verify($snapshot)];
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('BA snapshot verify failed', ['snapshot_id' => $snapshot->id, 'error' => $e->getMessage()]);

                return [$snapshot->id => null];
            }
    ```
  - **After:**
    ```php
            try {
                return [$snapshot->id => (bool) $service->verify($snapshot)];
            } catch (\Throwable $e) {
                // ERR-01 2026-10-12: log the exception object, never its message alone.
                report($e);

                return [$snapshot->id => null];
            }
    ```
  - **Verify:** `grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

None found.

## 5. Validation, routes, models (F4/F5/F7)

None found.

## 6. Queries, performance & view payload (F9/CTL)

- [ ] **BH-05** · M · CTL-07 · `BaDashboardController.php:1895-1905` — replace the 26-variable `compact()` with an explicit array.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php`
  - **Before** (`BaDashboardController.php:1895-1905`):
    ```php
        return view('behaviouralassessment::pages.reports', compact(
            'totalAssessments', 'studentsRated', 'totalIncidents', 'openPeriods',
            'hubStatusCounts', 'recentPeriods', 'incidentTrend',
            'allPeriods', 'allClassSections', 'allCategories',
            'assessmentScores', 'categoryRatingTotals', 'categoryCriteriaDetail', 'ratingScaleMax',
            'categoryScoreStats', 'csFrozen',
            'periodReport', 'selectedPeriod', 'periodSectionBreakdown', 'periodStudents',
            'auditStats', 'auditFacets',
            'auditLog',
            'atRisk', 'consistency', 'demographics'
        ));
    ```
  - **After:**
    ```php
        return view('behaviouralassessment::pages.reports', [
            'totalAssessments' => $totalAssessments,
            'studentsRated' => $studentsRated,
            'totalIncidents' => $totalIncidents,
            'openPeriods' => $openPeriods,
            'hubStatusCounts' => $hubStatusCounts,
            'recentPeriods' => $recentPeriods,
            'incidentTrend' => $incidentTrend,
            'allPeriods' => $allPeriods,
            'allClassSections' => $allClassSections,
            'allCategories' => $allCategories,
            'assessmentScores' => $assessmentScores,
            'categoryRatingTotals' => $categoryRatingTotals,
            'categoryCriteriaDetail' => $categoryCriteriaDetail,
            'ratingScaleMax' => $ratingScaleMax,
            'categoryScoreStats' => $categoryScoreStats,
            'csFrozen' => $csFrozen,
            'periodReport' => $periodReport,
            'selectedPeriod' => $selectedPeriod,
            'periodSectionBreakdown' => $periodSectionBreakdown,
            'periodStudents' => $periodStudents,
            'auditStats' => $auditStats,
            'auditFacets' => $auditFacets,
            'auditLog' => $auditLog,
            'atRisk' => $atRisk,
            'consistency' => $consistency,
            'demographics' => $demographics,
        ]);
    ```
  - **Verify:** `grep -n "compact(" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php`
  - **Expect:** line 1896 (the reports-page `compact(`) is gone; the other `compact(` calls (dashboard 191, masters 451, setup 527, incidents 1482) remain.
  - **Effort:** S

## 7. Views (F10)

- [ ] **BH-10** · M · VIEW-01 · `_witnesses.blade.php:122-131` — move the two witness-name queries out of the blade into `incidentsPage()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php`, `Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/_witnesses.blade.php`
  - **Before** (`BaDashboardController.php:1424-1429`):
    ```php
        $witnesses = BaIncidentWitnessJnt::with(['incident.student'])
            ->when(request('witness_type'), fn ($q) => $q->where('witness_type', request('witness_type')))
            ->when(request('from_date'), fn ($q) => $q->whereHas('incident', fn ($iq) => $iq->whereDate('incident_date', '>=', request('from_date'))))
            ->when(request('to_date'), fn ($q) => $q->whereHas('incident', fn ($iq) => $iq->whereDate('incident_date', '<=', request('to_date'))))
            ->orderByDesc('created_at')
            ->paginate(10, ['*'], 'wi_page');
    ```
  - **After:**
    ```php
        $witnesses = BaIncidentWitnessJnt::with(['incident.student'])
            ->when(request('witness_type'), fn ($q) => $q->where('witness_type', request('witness_type')))
            ->when(request('from_date'), fn ($q) => $q->whereHas('incident', fn ($iq) => $iq->whereDate('incident_date', '>=', request('from_date'))))
            ->when(request('to_date'), fn ($q) => $q->whereHas('incident', fn ($iq) => $iq->whereDate('incident_date', '<=', request('to_date'))))
            ->orderByDesc('created_at')
            ->paginate(10, ['*'], 'wi_page');

        // VIEW-01 2026-10-12: witness names are resolved here, not in the blade.
        $witnessRows = $witnesses->getCollection();
        $witnessStudentIds = $witnessRows->where('witness_type', 'student')->pluck('witness_id')->filter()->values()->all();
        $witnessStaffIds = $witnessRows->where('witness_type', '!=', 'student')->pluck('witness_id')->filter()->values()->all();
        $witnessStudentMap = $witnessStudentIds === [] ? collect() : \Modules\StudentProfile\Models\Student::whereIn('id', $witnessStudentIds)->get()->keyBy('id');
        $witnessStaffMap = $witnessStaffIds === [] ? collect() : \Modules\SchoolSetup\Models\Employee::with('user')->whereIn('id', $witnessStaffIds)->get()->keyBy('id');
    ```
  - **Before** (`BaDashboardController.php:1482-1486`):
    ```php
        return view('behaviouralassessment::pages.incidents', compact(
            'incidentLog', 'witnesses', 'interventionsApplied', 'categories', 'allPeriods', 'employee',
            'incidentStudents', 'incidentStaff', 'incidentInterventions',
            'outbox', 'outboxStatusCounts', 'caseData', 'bpData'
        ));
    ```
  - **After:**
    ```php
        return view('behaviouralassessment::pages.incidents', compact(
            'incidentLog', 'witnesses', 'interventionsApplied', 'categories', 'allPeriods', 'employee',
            'incidentStudents', 'incidentStaff', 'incidentInterventions',
            'outbox', 'outboxStatusCounts', 'caseData', 'bpData',
            'witnessStudentMap', 'witnessStaffMap'
        ));
    ```
  - **Before** (`_witnesses.blade.php:122-131`):
    ```php
    @php
        // Witness names in two queries for the whole page, not one per row. The controller that
        // builds $witnesses is shared with other tabs, so the lookup lives here.
        $wRows = $witnesses->getCollection();
        $wStudents = \Modules\StudentProfile\Models\Student::whereIn('id', $wRows->where('witness_type', 'student')->pluck('witness_id')->all())
            ->get()->keyBy('id');
        $wStaff = \Modules\SchoolSetup\Models\Employee::with('user')
            ->whereIn('id', $wRows->where('witness_type', '!=', 'student')->pluck('witness_id')->all())
            ->get()->keyBy('id');
    @endphp
    ```
  - **After:**
    ```php
    @php
        // VIEW-01 2026-10-12: names come from the controller; keep the local aliases the rows use.
        $wStudents = $witnessStudentMap;
        $wStaff = $witnessStaffMap;
    @endphp
    ```
  - **Verify:** `grep -n "Student::whereIn\|Employee::with" Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/_witnesses.blade.php`
  - **Expect:** no output (the blade no longer queries).
  - **Effort:** M

## 8. Style (F12) — one item per file

- [ ] **BH-11** · L · STY-04 · `BaDashboardController.php` — strip the `⚠` glyphs from five comments and move the orphaned docblock to `outboxData()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php`
  - **Before** (`BaDashboardController.php:1608-1614`):
    ```php
    /**
     * Notification Outbox list + per-status counts for incidentsPage(). Returns an empty
     * paginator and zero counts when the viewer lacks notifications.view (the tab is hidden then).
     *
     * @return array{0: LengthAwarePaginator, 1: array<string, int>}
     */
    /**
     * Case-management data for the Incidents page (BA v3 P4, BRD screen 27, BR-BA-080).
    ```
  - **After:**
    ```php
    /**
     * Case-management data for the Incidents page (BA v3 P4, BRD screen 27, BR-BA-080).
    ```
  - **Before** (`BaDashboardController.php:1686-1688`):
    ```php
    private function outboxData(): array
    {
        $statuses = [
    ```
  - **After:**
    ```php
    /**
     * Notification Outbox list + per-status counts for incidentsPage(). Returns an empty
     * paginator and zero counts when the viewer lacks notifications.view (the tab is hidden then).
     *
     * @return array{0: LengthAwarePaginator, 1: array<string, int>}
     */
    private function outboxData(): array
    {
        $statuses = [
    ```
  - **Also:** on the five comment lines below, delete the `⚠ ` prefix exactly as shown (the rest of each line stays byte-for-byte):
    | Line | Current | Becomes |
    |---|---|---|
    | 736 | `     * ⚠ A SECTION ID IS NOT UNIQUE TO A CLASS. sch_sections id 1 is "A" in every` | `     * A SECTION ID IS NOT UNIQUE TO A CLASS. sch_sections id 1 is "A" in every` |
    | 864 | `             * ⚠ Projected to the SAME shape the on-the-fly fallback below returns:` | `             * Projected to the SAME shape the on-the-fly fallback below returns:` |
    | 889 | `         * ⚠ The grade here used its own ladder — A+/A/B/C/D at 4.5/3.5/2.5/1.5 —` | `         * The grade here used its own ladder — A+/A/B/C/D at 4.5/3.5/2.5/1.5 —` |
    | 1080 | `     * ⚠ THIS DELIBERATELY COMPUTES NO BEHAVIOURAL SCORE OF ITS OWN.` | `     * THIS DELIBERATELY COMPUTES NO BEHAVIOURAL SCORE OF ITS OWN.` |
    | 1932 | `     * ⚠ The view's incident counts come from v_ba_incident_summary, which is ALL-TIME, not` | `     * The view's incident counts come from v_ba_incident_summary, which is ALL-TIME, not` |
  - **Verify:** `grep -n "⚠" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php` and `grep -c "Notification Outbox list" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php`
  - **Expect:** no `⚠` output; the second grep prints `1` (the docblock now sits on `outboxData` once).
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BH-02** · H · DECISION · RTE-01 — the Demographics tab writes a `ba_audit_log` row on a GET (`reportsPage`). Move the write off GET? ⚠ SHARED (a route file is involved in every option).
  - **Why it is a decision:** moving the audit off the GET path means adding a route (shared `routes/web.php`) and/or changing the tab's UX, which the workflow treats as behavioural changes.
  - (a) ⭐ Convert the analytics run to a POST: add `Route::post('reports-page/demographics', …)` (or reuse a `reports.*` POST) that reads `dm_period_id`/`dm_dimension`, runs `demographicAnalytics(true)` and redirects back to the tab. The tab's button submits a form instead of a plain link. Audit row stays; GET never writes. Touches `routes/web.php` (⚠ SHARED), the controller, `_demographics.blade.php`.
  - (b) Keep the GET but require an explicit opt-in param the UI only sends on a button click (e.g. `dm_run=1`), so prefetchers and link-scanners cannot trigger it.
  - (c) Accept as-is and document that the audit row records a permitted analytics view.
  - ➜ Choice: ____

- [ ] **BH-03** · M · DECISION · CTL-01 — split the 2,151-line god controller (6 pages, 31 private helpers)?
  - **Why it is a decision:** a split is deferred by D3 and changes file layout, routes stay the same.
  - (a) ⭐ Defer to the split pass (D3) — record the finding, fix nothing now.
  - (b) Split now into per-page controllers (six controllers, shared dashboard helpers moved to a service).
  - (c) Leave as-is and record as accepted.
  - ➜ Choice: ____

- [ ] **BH-04** · H · DECISION · CTL-02 — six methods exceed the length limit (`reportsPage` 209, `periodReportDetail` 167, `behaviourPointsData` 121, `incidentsPage` 104, `setup` 85, `teacherConsistency` 84); `reportsPage` also builds several tabs' data unconditionally.
  - **Why it is a decision:** extraction and per-tab gating are restructuring; they overlap the split pass.
  - (a) ⭐ Defer extraction to the split pass (D3); when splitting, gate each tab's data builder by the active tab (same permission guards that already exist for the P5 analytics).
  - (b) Extract now: pull the unconditional blocks in `reportsPage` into per-tab private methods and gate them by `$activeTab` (touches only the controller, but churns the file the split will rewrite).
  - (c) Accept as-is.
  - ➜ Choice: ____

- [ ] **BH-07** · M · DECISION · SVC-02 — services resolved per call with `app(...)` at nine sites; each `app()` call loses the services' per-instance memo.
  - **Why it is a decision:** constructor injection changes the class shape and every call site; doing it now is churn the deferred split will partly undo.
  - (a) ⭐ Defer to the split pass — the new per-page controllers will receive `BehaviouralScoreService`, `BaFrameworkSnapshotService` and `BaReviewSignalService` by constructor injection.
  - (b) Inject now: add a constructor with the three services as promoted properties and replace the nine call sites (lines 80, 84, 329, 357, 675, 902, 1176, 1847, 2004).
  - (c) Accept as-is (the per-request cost is a few extra primary-key lookups).
  - ➜ Choice: ____

- [ ] **BH-08** · M · DECISION · QRY-05 — the Ratings tab loads every student's ratings/computed scores to build maps for a 10-row page (21,996 rating rows on the audited tenant when no class filter is set).
  - **Why it is a decision:** scoping the maps to the visible page changes method signatures and the `@json($ratingDetailMap)` payload; it belongs with the ratings-tab rebuild in the split pass (or needs production-scale measurement first).
  - (a) ⭐ Defer to the split pass; before deciding, re-measure on a production tenant (the real cost depends on rating volume vs the tab's default scope).
  - (b) Implement now: build the paginator first in `assessmentsPage()` and pass its student ids into `ratingScoreMapQuery` / `ratingDetailMapQuery` / `ratingStudentMapQuery` (the blade and JS look-ups are already keyed by student id, so visible rows keep working).
  - (c) Accept as perf debt.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BH-06 | CTL-08 (L) — 98 uses of the `request()` helper. Injecting `Request` into the 6 public methods and threading it through 31 private helpers is a whole-file mechanical codemod that the split pass (BH-03) will do naturally; doing it now doubles the churn on lines the split will rewrite. Accepted, low severity. |