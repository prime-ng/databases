# Final Audit — BehaviouralAssessment / BaConfigController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php` (277 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/behavioural-assessment/setup?tab=configuration` (the panel); `POST /behavioural-assessment/configs` (create), `GET /behavioural-assessment/configs/{config}` (show), `GET /behavioural-assessment/configs/{config}/edit` (edit), `PUT /behavioural-assessment/configs/{config}` (update), `DELETE /behavioural-assessment/configs/{config}` (trash), `GET /behavioural-assessment/configs/trash` (trash list), `GET /behavioural-assessment/configs/{id}/restore`, `DELETE /behavioural-assessment/configs/{id}/force-delete`, `POST /behavioural-assessment/configs/{config}/toggle-status` |
| Menu path | Behavioural Assessment → Setup → Configuration tab |
| Who uses it | `Super Admin` and `School Admin` — the only two roles holding `tenant.behavioural-assessment.configs.*` (measured: 7 configs permission rows, each held by 2 roles = 14 rows in `sys_role_has_permissions_jnt`) |
| What a user does here | An admin maintains the one policy record for an academic session: workflow flags, the scoring aggregation method, result-integration weightage, notification recipients, incident escalation thresholds, privacy and retention limits, and feature toggles. `store` creates it, `update` changes it, `destroy` soft-deletes it, `trashed`/`restore`/`forceDelete` manage the trash, and `toggleStatus` flips active/inactive. The create/edit screens are the full v3 policy form (BRD §22). |
| Tables written | `ba_config` (create / update / soft-delete / restore / hard-delete) and `sys_activity_logs` (one row per write via the `activityLog()` helper); `update` also appends one `ba_audit_log` row per changed field |
| Tables read | `ba_config`, `ba_rating_scales` (`activeOptions`), `sch_org_academic_sessions_jnt` (session dropdown), and `ba_assessment_ratings` → `ba_assessments` → `ba_assessment_periods` (the "ratings already recorded?" guard) |
| Live data | On tenant `00000000-0000-4000-8000-000000000001` (db `xyz_school_00000000000040008000_202627`): `ba_config` **1 live, 0 trashed**; `ba_assessment_ratings` 21996 live; `ba_rating_scales` 1; `sch_org_academic_sessions_jnt` 10 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **close to production-ready**. It validates through a 389-line FormRequest that mirrors the migration's CHECK constraints (executed against real payloads below and it behaved correctly), authorizes on every route, and wraps every multi-table write in one `DB::transaction` with `activityLog()` after the write. Its worst problems are the binding-decision violation **BCF-01** — five mutating methods wrap the transaction in a `try/catch (\Throwable)` that D1 forbids, log `getMessage()` instead of the exception, and build the redirect before commit — and **BCF-07**, `restore` mutating state over an unprotected GET. The rest are a non-atomic check-then-act (BCF-02), a soft-delete × unique trap in `restore` (BCF-03), a duplicated authorization check (BCF-04), a module-wide permission-literal pattern (BCF-05), a business rule that belongs in the FormRequest (BCF-06), and route-model-binding style (BCF-08, deferred by D3). Effort: **S–M (roughly 2–3 hours)** once Tarun ticks the items.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 5 | 1 | 4 | 8 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BCF-01 | F8 Services/Jobs | clean — no service, job, event or mail reaches this controller |
| F2 Transactions/Audit | BCF-02, BCF-03 | F9 Queries/Perf | clean — single `exists()`, one eager-loaded `show`, lists paginate at 10 |
| F3 Authorization | BCF-04, BCF-05 | F10 Views | clean — no query in Blade, no `{!! !!}`, eager-loaded relations |
| F4 Validation | BCF-06 | F11 Security/Tenancy | clean — no `env()`, no hard-coded id, tenant middleware present |
| F5 Routes | BCF-07 | F12 Style | clean — Pint passes on all four in-scope PHP files |
| F6 Controller shape | BCF-08 | F13 Deep read | see the F13 table |
| F7 Models | clean — fillable, casts, SoftDeletes and relations proven | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php` | controller | 277 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Http/Requests/BaConfigRequest.php` | FormRequest | 389 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Models/BaConfig.php` | model (`ba_config`) | 143 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Http/Requests/LocksAcademicSession.php` | trait (used by this FormRequest) | 32 | ↗ [tarun/BehaviouralAssessment-done/BaClassScaleController-done](../BaClassScaleController-done/01-report.md) | ↗ linked |
| 5 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | 45 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 6 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support | 37 | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |
| 7 | `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` | model (`ba_audit_log`) | 203 | ↗ [tarun/BehaviouralAssessment-done/BaAuditLogController-done](../BaAuditLogController-done/01-report.md) | ↗ linked |
| 8 | `Modules/BehaviouralAssessment/app/Models/BaRatingScale.php` | model (`ba_rating_scales`) | 81 | ↗ [tarun/BehaviouralAssessment-done/BaRatingScaleController-done](../BaRatingScaleController-done/01-report.md) | ↗ linked |
| 9 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentRating.php` | model (`ba_assessment_ratings`) | 67 | ↗ [tarun/BehaviouralAssessment-done/BaClassScaleController-done](../BaClassScaleController-done/01-report.md) | ↗ linked |
| 10 | `Modules/BehaviouralAssessment/resources/views/config/create.blade.php` | blade | 43 | this report | ✅ |
| 11 | `Modules/BehaviouralAssessment/resources/views/config/edit.blade.php` | blade | 46 | this report | ✅ |
| 12 | `Modules/BehaviouralAssessment/resources/views/config/show.blade.php` | blade | 101 | this report | ✅ |
| 13 | `Modules/BehaviouralAssessment/resources/views/config/trash.blade.php` | blade | 62 | this report | ✅ |
| 14 | `Modules/BehaviouralAssessment/resources/views/config/_fields.blade.php` | blade partial (included by create and edit) | 162 | this report | ✅ |
| 15 | `Modules/BehaviouralAssessment/resources/views/config/_create-fields.blade.php` | blade partial | 16 | this report | ❌ rendered by `BaDashboardController::setup()`, not by this controller (see §8) |

No pre-applied files: no `Modules/BehaviouralAssessment/**` file is listed in a `PRE-APPLIED-*.md`.

## 4. Routes

```
GET|HEAD behavioural-assessment/configs                          behavioural-assessment.configs.index                    Modules\BehaviouralAssessment\Http\Controllers\BaConfigController@index
POST    behavioural-assessment/configs                           behavioural-assessment.configs.store                    Modules\BehaviouralAssessment\Http\Controllers\BaConfigController@store
GET|HEAD behavioural-assessment/configs/create                   behavioural-assessment.configs.create                   Modules\BehaviouralAssessment\Http\Controllers\BaConfigController@create
GET|HEAD behavioural-assessment/configs/trash                    behavioural-assessment.configs.trashed                  Modules\BehaviouralAssessment\Http\Controllers\BaConfigController@trashed
GET|HEAD behavioural-assessment/configs/{config}                 behavioural-assessment.configs.show                     Modules\BehaviouralAssessment\Http\Controllers\BaConfigController@show
PUT|PATCH behavioural-assessment/configs/{config}                behavioural-assessment.configs.update                   Modules\BehaviouralAssessment\Http\Controllers\BaConfigController@update
DELETE  behavioural-assessment/configs/{config}                  behavioural-assessment.configs.destroy                  Modules\BehaviouralAssessment\Http\Controllers\BaConfigController@destroy
GET|HEAD behavioural-assessment/configs/{config}/edit            behavioural-assessment.configs.edit                     Modules\BehaviouralAssessment\Http\Controllers\BaConfigController@edit
POST    behavioural-assessment/configs/{config}/toggle-status    behavioural-assessment.configs.toggleStatus             Modules\BehaviouralAssessment\Http\Controllers\BaConfigController@toggleStatus
DELETE  behavioural-assessment/configs/{id}/force-delete         behavioural-assessment.configs.forceDelete              Modules\BehaviouralAssessment\Http\Controllers\BaConfigController@forceDelete
GET|HEAD behavioural-assessment/configs/{id}/restore             behavioural-assessment.configs.restore                  Modules\BehaviouralAssessment\Http\Controllers\BaConfigController@restore
```

Unrouted public methods: none — the 11 public methods are exactly the 11 routes above.

Route parameter note: `Route::resource('configs')` names the parameter `{config}` while the custom `restore` and `force-delete` routes name it `{id}`. The controller methods type the argument as a scalar (`int $id` / `int $config`), which Laravel resolves positionally from `parametersWithoutNulls()`, so all 11 routes dispatch correctly. Route-model binding is discussed under BCF-08.

Tenant middleware: the module's `RouteServiceProvider::map()` wraps the group in `['web', InitializeTenancyByDomain, PreventAccessFromCentralDomains, EnsureTenantIsActive, EnsureTenantHasModule:BehaviouralAssessment, 'auth', 'verified']` with prefix `behavioural-assessment` and name `behavioural-assessment.` (verified in `Modules/BehaviouralAssessment/app/Providers/RouteServiceProvider.php:24-38`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 26 | GET `configs` | `tenant.behavioural-assessment.configs.viewAny` | none (redirect only) | none | none | none |
| `create` | 33 | GET `configs/create` | `tenant.behavioural-assessment.configs.create` | none | none | none | none |
| `store` | 42 | POST `configs` | `tenant.behavioural-assessment.configs.create` (controller) + same via FormRequest | controller `DB::transaction` (47) | `'Stored'` | `ba_config`, `sys_activity_logs` | BCF-01, BCF-04, BCF-05 |
| `show` | 71 | GET `configs/{config}` | `tenant.behavioural-assessment.configs.view` | none | none | none | BCF-08 |
| `edit` | 79 | GET `configs/{config}/edit` | `tenant.behavioural-assessment.configs.update` | none | none | none | BCF-06, BCF-08 |
| `update` | 93 | PUT `configs/{config}` | `tenant.behavioural-assessment.configs.update` (controller) + same via FormRequest | controller `DB::transaction` (111) | `'Updated'` | `ba_config`, `ba_audit_log`, `sys_activity_logs` | BCF-01, BCF-02, BCF-04, BCF-05, BCF-06, BCF-08 |
| `destroy` | 147 | DELETE `configs/{config}` | `tenant.behavioural-assessment.configs.delete` | controller `DB::transaction` (152) | `'Trashed'` | `ba_config`, `sys_activity_logs` | BCF-01, BCF-05, BCF-08 |
| `trashed` | 177 | GET `configs/trash` | `tenant.behavioural-assessment.configs.restore` | none (`paginate(10)`) | none | none | none |
| `restore` | 188 | GET `configs/{id}/restore` | `tenant.behavioural-assessment.configs.restore` | controller `DB::transaction` (193) | `'Restored'` | `ba_config`, `sys_activity_logs` | BCF-03, BCF-05, BCF-07, BCF-08 |
| `forceDelete` | 215 | DELETE `configs/{id}/force-delete` | `tenant.behavioural-assessment.configs.forceDelete` | controller `DB::transaction` (220) | `'Deleted'` | `ba_config`, `sys_activity_logs` | BCF-01, BCF-05, BCF-08 |
| `toggleStatus` | 242 | POST `configs/{config}/toggle-status` | `tenant.behavioural-assessment.configs.update` | controller `DB::transaction` (247) | `'Toggled'` | `ba_config`, `sys_activity_logs` | BCF-01, BCF-05 |

## 6. Findings

### F1 — Errors

#### BCF-01 · H · ERR-00 — five mutating methods wrap the transaction in a `try/catch` that D1 forbids and log the message instead of the exception

| Field | Value |
|---|---|
| **Rule** | ERR-00 (H, raised from the rulebook's undecided default because D1 settled it: *no `try/catch` in controllers; the central handler in `bootstrap/app.php` renders errors*). Co-cited: ERR-05 (M) — *log the exception, not the message*; TXN-05 (M) — *the transaction closure returns data; build `redirect()` after it*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:46-68` (`store`), `:110-144` (`update`), `:151-174` (`destroy`), `:219-239` (`forceDelete`), `:246-275` (`toggleStatus`). `restore` has the same shape and is rewritten by BCF-03. |
| **Root cause** | Each of the five methods uses `try { return DB::transaction(closure) } catch (\Throwable $e) { Log::error('...', ['error' => $e->getMessage()]); return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.'); }`. D1 makes a controller `try/catch` a finding; no D2 shape applies (no `\DomainException`, no truncate-then-rebuild, no `SnapshotProtectionException`). The catch (a) logs only `getMessage()`, losing the stack trace (ERR-05); (b) calls `BaTriggerError::message()`, which returns text only for a `SQLSTATE 45000` error containing `BA: ` — `ba_config` has **zero** triggers, so that friendly branch can never fire and the user always gets the generic fallback; and (c) builds the `redirect()` / `response()` inside the closure before commit (TXN-05). |
| **Consequence** | A genuine failure on a write path (DB down, deadlock) is swallowed into a red "The operation could not be completed." flash and bypasses the central 500 handler; the log line carries no trace, so the failure cannot be diagnosed from the log. |
| **Reproduce** | static only — the catch needs an infrastructure failure (DB error or deadlock) that cannot be triggered from the browser. The D1 violation itself is visible at the five line ranges above. |
| **Fix approach** | Remove the `try/catch` from the five methods, run `DB::transaction(closure)` for its side effect, and build the `redirect()` / `response()` after it. Remove the now-unused imports once BCF-03 is also applied. |
| **Plan item** | BCF-01 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n "try {\|catch (\|Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php` and `grep -c "ba_config" database/migrations/tenant/2026_06_16_130643_create_ba_triggers.php` |

Quoted current lines (`store`, `BaConfigController.php:42-68`):

```php
    public function store(BaConfigRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.create');

        try {
            return DB::transaction(function () use ($request) {
                $record = BaConfig::create($request->validated() + [
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Stored', ['message' => 'BaConfig was stored.']);

                return redirect()
                    ->route('behavioural-assessment.setup', ['tab' => 'configuration'])
                    ->with('success', 'Configuration created successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaConfigController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    }
```

**Evidence**

```
$ grep -n "try {\|catch (\|Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php
46:        try {
60:        } catch (ModelNotFoundException $e) {
64:        } catch (\Throwable $e) {
65:            Log::error('BaConfigController::store failed', ['error' => $e->getMessage()]);
110:        try {
137:        } catch (\Throwable $e) {
138:            Log::error('BaConfigController::update failed', [
151:        try {
166:        } catch (ModelNotFoundException $e) {
170:        } catch (\Throwable $e) {
171:            Log::error('BaConfigController::destroy failed', ['error' => $e->getMessage()]);
192:        try {
204:        } catch (ModelNotFoundException $e) {
208:        } catch (\Throwable $e) {
209:            Log::error('BaConfigController::restore failed', ['error' => $e->getMessage()]);
219:        try {
231:        } catch (ModelNotFoundException $e) {
235:        } catch (\Throwable $e) {
236:            Log::error('BaConfigController::forceDelete failed', ['error' => $e->getMessage()]);
246:        try {
262:        } catch (ModelNotFoundException $e) {
266:        } catch (\Throwable $e) {
267:            Log::error('BaConfigController::toggleStatus failed', ['error' => $e->getMessage()]);

$ grep -c "ba_config" database/migrations/tenant/2026_06_16_130643_create_ba_triggers.php
0
```

### F2 — Transactions and audit

#### BCF-02 · M · TXN-06 — the rating-scale change guard is a check-then-act with no lock

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M, lowered from the rulebook's H — a single-admin configuration screen, a sub-second window, and no DB constraint can express the guard, so the fix is a policy choice). |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:100-108` (`update`) |
| **Root cause** | The guard `BaAssessmentRating::whereHas('assessment.period', ...)->exists()` runs **before** the write's transaction, and the write takes no lock on anything the guard looked at. A teacher inserting a `ba_assessment_ratings` row for that session at the same moment is not blocked, so the scale can still change while ratings exist — the exact state the guard exists to prevent. |
| **Consequence** | In a rare concurrent write, the session's rating scale can move underneath ratings that were recorded on the old scale, so those ratings are later banded against a scale they were not given on. |
| **Reproduce** | static only — requires two simultaneous requests (an admin saving the config while a teacher saves ratings); not reproducible from a single browser session. |
| **Fix approach** | Decide the policy: accept and document, harden with `lockForUpdate()`, or add a ratings-side constraint. Options are in the plan item. |
| **Plan item** | BCF-02 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `grep -n "whereHas\|DB::transaction" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php` |

Quoted current lines (`update`, `BaConfigController.php:100-108`):

```php
        if (isset($validated['rating_scale_id']) && (int) $validated['rating_scale_id'] !== $config->rating_scale_id) {
            $hasRatings = BaAssessmentRating::whereHas('assessment.period', function ($q) use ($config) {
                $q->where('academic_session_id', $config->academic_session_id);
            })->exists();

            if ($hasRatings) {
                return back()->withInput()->with('error', 'Cannot change rating scale because ratings have already been recorded for this academic session.');
            }
        }
```

**Evidence**

```
$ grep -n "whereHas\|DB::transaction" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php
86:        $hasRatings = BaAssessmentRating::whereHas('assessment.period', function ($q) use ($config) {
101:            $hasRatings = BaAssessmentRating::whereHas('assessment.period', function ($q) use ($config) {
111:            return DB::transaction(function () use ($config, $validated) {
```

#### BCF-03 · M · VAL-04 — restoring a trashed config can collide with the live-row unique index

| Field | Value |
|---|---|
| **Rule** | VAL-04 (M, lowered from the rulebook's H — the DB unique index prevents corruption, so the only visible effect is a generic error message). Co-cited: ERR-00 (the method's own `try/catch`, D1). |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:188-213` (`restore`); the index is `database/migrations/tenant/2026_06_16_130621_create_ba_config_table.php:96-98` |
| **Root cause** | `uq_ba_config_session` is `UNIQUE(academic_session_id, uq_guard)` where `uq_guard = IFNULL(deleted_at,'1970-01-01')`. The create-time validation uses `->whereNull('deleted_at')`, so a **trashed** config for session S is ignored and a new **live** config for S can be created. Restoring the trashed row then sets `deleted_at = NULL`, so both rows share `uq_guard = '1970-01-01'` and the restore raises a duplicate-key `QueryException`. The controller's generic `catch (\Throwable)` swallows it into "The operation could not be completed." `restore` has no live-row guard of its own. |
| **Consequence** | An admin who trashes a config, creates a replacement for the same session, and later restores the old one sees a generic red flash with no explanation of why the restore failed. |
| **Reproduce** | On `/behavioural-assessment/configs/trash`, restore a config whose academic session already has a live config (trash the current one, create a new one for the same session, then restore the trashed one). Expected: an explicit refusal; actual: "The operation could not be completed." |
| **Fix approach** | Rewrite `restore` to check for a live config in the same session and return an explicit message, and drop the D1-forbidden `try/catch` in the same rewrite. |
| **Plan item** | BCF-03 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n "uq_ba_config_session\|uq_guard\|unique(" <migration>` and `grep -n "onlyTrashed" <controller>` |

Quoted current lines (`restore`, `BaConfigController.php:188-213`):

```php
    public function restore(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.restore');

        try {
            return DB::transaction(function () use ($id) {
                $config = BaConfig::onlyTrashed()->findOrFail($id);
                $config->restore();

                activityLog($config, 'Restored', ['message' => 'BaConfig was restored.']);

                return redirect()
                    ->route('behavioural-assessment.setup', ['tab' => 'configuration'])
                    ->with('success', 'Configuration restored successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaConfigController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    }
```

**Evidence**

```
$ grep -n "uq_ba_config_session\|uq_guard\|unique(" database/migrations/tenant/2026_06_16_130621_create_ba_config_table.php
96:            $table->dateTime('uq_guard', 6)->storedAs("IFNULL(`deleted_at`,'1970-01-01 00:00:00.000000')");
98:            $table->unique(['academic_session_id', 'uq_guard'], 'uq_ba_config_session');

$ grep -n "onlyTrashed" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php
194:                $config = BaConfig::onlyTrashed()->findOrFail($id);
```

### F3 — Authorization

#### BCF-04 · L · AUTH-04 — `store` and `update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:44` (`store`), `:95` (`update`); `Modules/BehaviouralAssessment/app/Http/Requests/BaConfigRequest.php:211-215` |
| **Root cause** | The FormRequest's `authorize()` calls `authorizeByCrudPermission('tenant.behavioural-assessment.configs')`, which maps POST to `configs.create` and PUT to `configs.update`. The controller then calls `Gate::authorize('tenant.behavioural-assessment.configs.create')` / `…update` for the same verbs — two checks, one concern. |
| **Consequence** | No user-visible effect; it is duplicated logic that can drift (one surface changed, the other forgotten) and makes the permission harder to grep as a single source. |
| **Reproduce** | static only — both checks pass or fail together today. |
| **Fix approach** | Keep the FormRequest check and remove the two redundant `Gate::authorize` lines in `store` and `update`. `create`, `edit`, `destroy`, `trashed`, `restore`, `forceDelete` and `toggleStatus` have no FormRequest and keep their `Gate::authorize`. |
| **Plan item** | BCF-04 in `02-fix-plan.md` §4 |
| **Evidence** | `grep -n "Gate::authorize" <controller>` and `grep -n "authorizeByCrudPermission" <request>` |

Quoted current lines (`store`, `BaConfigController.php:42-44`):

```php
    public function store(BaConfigRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.create');
```

**Evidence**

```
$ grep -n "authorizeByCrudPermission" Modules/BehaviouralAssessment/app/Http/Requests/BaConfigRequest.php
214:        return $this->authorizeByCrudPermission('tenant.behavioural-assessment.configs');

$ grep -n "Gate::authorize('tenant.behavioural-assessment.configs.create')\|Gate::authorize('tenant.behavioural-assessment.configs.update')" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php
44:        Gate::authorize('tenant.behavioural-assessment.configs.create');
95:        Gate::authorize('tenant.behavioural-assessment.configs.update');
```

#### BCF-05 · M · AUTH-06 — permission strings are repeated as literals

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy, or constants — not repeated as literals in every method*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:28` (also lines 35, 44, 73, 81, 95, 149, 179, 190, 217, 244); also `Modules/BehaviouralAssessment/app/Http/Requests/BaConfigRequest.php:214` and the blade `trash.blade.php:40-41` |
| **Root cause** | The base string `tenant.behavioural-assessment.configs` and its seven verbs are written out 12 times in PHP and again in Blade. Nothing binds them, so a rename is a search-and-replace across many files. The same base is also used by `BaClassScaleController`, so the literals are module-wide. |
| **Consequence** | No current user-visible effect. It is maintenance risk: one surface can be renamed while another is missed, producing a silently un-guarded or always-denied action. |
| **Reproduce** | static only — the strings are consistent today. |
| **Fix approach** | A module-wide permission-constant or Policy pass. Not fixed per-controller here; no plan item (see §10). |
| **Plan item** | none — see plan §10 |
| **Evidence** | `grep -rn "tenant.behavioural-assessment.configs" Modules/BehaviouralAssessment/app/Http` |

Quoted current lines (`index`, `BaConfigController.php:28`):

```php
        Gate::authorize('tenant.behavioural-assessment.configs.viewAny');
```

**Evidence**

```
$ grep -rn "tenant.behavioural-assessment.configs" Modules/BehaviouralAssessment/app/Http
Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:28:        Gate::authorize('tenant.behavioural-assessment.configs.viewAny');
Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:35:        Gate::authorize('tenant.behavioural-assessment.configs.create');
Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:44:        Gate::authorize('tenant.behavioural-assessment.configs.create');
Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:73:        Gate::authorize('tenant.behavioural-assessment.configs.view');
Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:81:        Gate::authorize('tenant.behavioural-assessment.configs.update');
Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:95:        Gate::authorize('tenant.behavioural-assessment.configs.update');
Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:149:        Gate::authorize('tenant.behavioural-assessment.configs.delete');
Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:179:        Gate::authorize('tenant.behavioural-assessment.configs.restore');
Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:190:        Gate::authorize('tenant.behavioural-assessment.configs.restore');
Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:217:        Gate::authorize('tenant.behavioural-assessment.configs.forceDelete');
Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:244:        Gate::authorize('tenant.behavioural-assessment.configs.update');
Modules/BehaviouralAssessment/app/Http/Requests/BaConfigRequest.php:214:        return $this->authorizeByCrudPermission('tenant.behavioural-assessment.configs');
```

### F4 — Validation and input

#### BCF-06 · M · VAL-07 — the rating-scale-in-use rule is hand-written in the controller, not in the FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M) — *cross-field / business checks go in the Form Request's `after()` hook, not hand-written in the controller*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:100-108` (`update`), `:86-88` (`edit`) |
| **Root cause** | The rule "a session that already has ratings may not change the rating scale" is implemented as an inline `if` returning `back()->withInput()->with('error', …)` in `update`, and the same `BaAssessmentRating::whereHas(…)->exists()` query is repeated in `edit` only to lock the select. It is business validation with no other home, so it cannot be reused by a service or a command, and it returns a page-level flash instead of a validation error. |
| **Consequence** | The same rule cannot be enforced when the config is changed by any path other than this controller, and the user sees a page-level red flash rather than an inline field message next to the rating scale. |
| **Reproduce** | Open `/behavioural-assessment/configs/{config}/edit` for a config whose session already has ratings, change the rating scale, and save. Expected: a field-level message; actual: a red flash at the top of the page. |
| **Fix approach** | Move the rule into `BaConfigRequest::after()` (returning a 422 field error). A behaviour change, so it is a DECISION. |
| **Plan item** | BCF-06 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `grep -n "whereHas" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php` |

Quoted current lines (`update`, `BaConfigController.php:100-108`):

```php
        if (isset($validated['rating_scale_id']) && (int) $validated['rating_scale_id'] !== $config->rating_scale_id) {
            $hasRatings = BaAssessmentRating::whereHas('assessment.period', function ($q) use ($config) {
                $q->where('academic_session_id', $config->academic_session_id);
            })->exists();

            if ($hasRatings) {
                return back()->withInput()->with('error', 'Cannot change rating scale because ratings have already been recorded for this academic session.');
            }
        }
```

**Evidence**

```
$ grep -n "whereHas" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php
86:        $hasRatings = BaAssessmentRating::whereHas('assessment.period', function ($q) use ($config) {
101:            $hasRatings = BaAssessmentRating::whereHas('assessment.period', function ($q) use ($config) {
```

Family note (remainder is clean): the FormRequest was **executed** against realistic payloads (final-audit §3.5.1) and behaved correctly. Valid create on an unused session **PASSES**; `integration ON + weightage 25` fails `between:5,20`; `trend_stable_percent 10 > trend_improve_percent 5` fails `lte`; `desc max 50 <= min 100` fails `gt`; a bad channel fails `in`; `escalation_count 0` fails `min:1`; a nonexistent scale fails `exists`; a duplicate live session fails `unique`. `validated()` is used (no `all()`), every field is typed, there are no uploads, and the `academic_session_id` uniqueness rule (`->whereNull('deleted_at')`) agrees with the DB index semantics (proof under BCF-03).

```
$ php artisan tinker --execute '... BaConfigRequest::rules() ...'
G valid create on FREE session -> PASSES
H integration ON weightage 25 -> FAILS
    weightage_percent              The weightage percent field must be between 5 and 20.
D stable(10) > improve(5) -> FAILS
    trend_stable_percent           The trend stable percent field must be less than or equal to 5.
E desc max(50) <= min(100) -> FAILS
    incident_desc_max_length       The incident desc max length field must be greater than 100.
J bad channel -> FAILS
    notification_channels_json.1   The selected notification_channels_json.1 is invalid.
K escalation_count 0 -> FAILS
    incident_escalation_count      The incident escalation count field must be at least 1.
L nonexistent rating_scale -> FAILS
    rating_scale_id                The selected rating scale id is invalid.
M duplicate live session -> FAILS
    academic_session_id            The academic session id has already been taken.
```

### F5 — Routes

#### BCF-07 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, `publish`, `approve`, `sync`, `generate`)*. |
| **Where** | `Modules/BehaviouralAssessment/routes/web.php:88` (route) and `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:188` (method) |
| **Root cause** | The route is declared `Route::get('configs/{id}/restore', …)`. A GET has no CSRF protection, and a link prefetcher, crawler or browser preload can follow the URL and restore a trashed configuration without any user intent. |
| **Consequence** | A trashed configuration can be silently restored by a prefetch or a crawler, re-activating an old policy for a session. |
| **Reproduce** | While logged in, open `/behavioural-assessment/configs/{id}/restore` in the address bar for a trashed id — the config is restored with no confirmation and no CSRF token. |
| **Fix approach** | Change the verb to POST or DELETE. This edits a route file shared by the module, so it is a DECISION and the item is marked `⚠ SHARED`. The trash action component already reads the route verb and renders the matching form method, so no component change is needed. |
| **Plan item** | BCF-07 in `02-fix-plan.md` §9 (DECISION, `⚠ SHARED`) |
| **Evidence** | `grep -n "configs/{id}/restore" Modules/BehaviouralAssessment/routes/web.php` |

Quoted current line (`web.php:88`):

```php
Route::get('configs/{id}/restore', [BaConfigController::class, 'restore'])->name('configs.restore');
```

**Evidence**

```
$ grep -n "configs/{id}/restore\|configs/{id}/force-delete\|configs/trash" Modules/BehaviouralAssessment/routes/web.php
87:Route::get('configs/trash', [BaConfigController::class, 'trashed'])->name('configs.trashed');
88:Route::get('configs/{id}/restore', [BaConfigController::class, 'restore'])->name('configs.restore');
89:Route::delete('configs/{id}/force-delete', [BaConfigController::class, 'forceDelete'])->name('configs.forceDelete');
```

Family note (remainder is clean): all 11 routes point at existing public methods (RTE-02); all 11 public methods are routed (RTE-03); the custom `configs/trash` route is registered before `Route::resource('configs')`, so `/trash` is not captured by `{config}` (RTE-06); the tenant/auth middleware group is present (RTE-05); no read is a POST lookup (RTE-04).

### F6 — Controller shape

#### BCF-08 · M · CTL-03 — `show`/`edit`/`update`/`destroy`/`restore`/`forceDelete`/`toggleStatus` use a raw id + `findOrFail` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:71-74` (`show`), `:79-82` (`edit`), `:93-96` (`update`), `:147-153` (`destroy`), `:188-194` (`restore`), `:215-221` (`forceDelete`), `:242-248` (`toggleStatus`) |
| **Root cause** | The resource routes declare `{config}` and the custom routes declare `{id}`; every method accepts a raw scalar (`int $id` / `int $config`) and resolves the model by hand with `findOrFail`. |
| **Consequence** | No user-visible bug today. It is style and consistency: manual resolution duplicates the 404 behaviour and forces the `LocksAcademicSession` trait to resolve the model again from an id. |
| **Reproduce** | static only. |
| **Fix approach** | Route model binding needs a route-parameter rename to `{config}` on the custom routes (a route-file edit, out of scope for this pass per D3) or an argument typed `BaConfig $config`, which reads oddly on the resource route. Recommend deferring to the D3 refactor pass; a DECISION. |
| **Plan item** | BCF-08 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `grep -n "findOrFail\|int \$id\|int \$config" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php` |

Quoted current lines (`show`, `BaConfigController.php:71-74`):

```php
    public function show(int $id): View
    {
        Gate::authorize('tenant.behavioural-assessment.configs.view');
        $config = BaConfig::with(['academicSession', 'ratingScale'])->findOrFail($id);
```

**Evidence**

```
$ grep -n "findOrFail\|int \$id\|int \$config" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php
71:    public function show(int $id): View
74:        $config = BaConfig::with(['academicSession', 'ratingScale'])->findOrFail($id);
79:    public function edit(int $id): View
82:        $config = BaConfig::findOrFail($id);
93:    public function update(BaConfigRequest $request, int $id): RedirectResponse
96:        $config = BaConfig::findOrFail($id);
147:    public function destroy(int $id): RedirectResponse
153:                $config = BaConfig::findOrFail($id);
188:    public function restore(int $id): RedirectResponse
194:                $config = BaConfig::onlyTrashed()->findOrFail($id);
215:    public function forceDelete(int $id): RedirectResponse
221:                $config = BaConfig::withTrashed()->findOrFail($id);
242:    public function toggleStatus(int $config): JsonResponse
248:                $item = BaConfig::findOrFail($config);
```

Clean sub-checks in this family: the controller is 277 lines and 11 public methods (well under the CTL-01 thresholds of 1,000 lines / 25 methods); the longest method (`update`) is 53 lines, under the 80-line CTL-02 limit; every public method carries a return type (CTL-04); no `request()` helper, no `extract()`, no `compact()` (CTL-08/07); no `dd()`/`dump()`/`var_dump()` (CTL-09); no dead private methods or commented-out blocks (CTL-10). The near-identical catch blocks are handle by BCF-01.

### F7 — Models

clean — `BaConfig` (`ba_config`): `$fillable` is declared and the generated `uq_guard` column is correctly omitted; `$casts` cover every boolean, integer, decimal, array and datetime column (`BaConfig.php:83-127`); `SoftDeletes` matches the real `deleted_at` column; `$table = 'ba_config'` exists in `database/migrations/tenant/2026_06_16_130621_create_ba_config_table.php`. Both relationships are return-typed and resolve in tinker. Evidence:

```
$ php artisan tinker --execute '... BaConfig::with(["academicSession","ratingScale"])->first() ...'
ratingScale rel=Modules\BehaviouralAssessment\Models\BaRatingScale
academicSession rel=Modules\SchoolSetup\Models\OrganizationAcademicSession
```

Informational (no ID): `scopeActive($query)` on `BaConfig:139` has no return type (MDL-04, L). Every `scope*` method in the module omits it (BaCriterion, BaCommentBank, BaIntervention, BaCategory, BaRatingScale, BaRatingLevel, BaAssessmentPeriod, BaComputedOverall and others), so it is a module-wide convention, not a defect introduced here; reporting it as one plan item per file would be noise.

### F8 — Services and jobs

clean — this controller calls no Service, Job, Event, Mail or Notification. Evidence: `grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b' Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php` prints nothing. The only collaborators are the `activityLog()` helper and the linked `BaActor` / `BaAuditLog` classes.

### F9 — Queries and performance

clean — the only repeated lookup on a write path is the single `BaAssessmentRating::whereHas(...)->exists()` guard (one query, no `->get()`); `show` eager-loads `academicSession` and `ratingScale`; `trashed` paginates at 10; `create`/`edit` load the session dropdown and `BaRatingScale::activeOptions()`, both small tables (10 sessions, 1 scale on the test tenant). There is no query inside a loop and no interpolated raw SQL. Evidence: `grep -n "get()\|paginate\|exists()\|whereHas" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php` shows `->exists()` at :88 and :103, `->paginate(10)` at :183, and `->get()` only on the two small dropdowns at :36 and :83.

### F10 — Views

clean — create, edit, show and trash (plus the `_fields` partial) contain no `Model::`/`DB::` query, no `{!! !!}`, and every relation they print (`$config->academicSession`, `$config->ratingScale`, `$item->academicSession`, `$item->ratingScale`) is eager-loaded by the controller. The trash row action passes `restorePermission` / `forceDeletePermission` to `x-backend.table.action-trashed`, whose constructor does accept them (`app/View/Components/Backend/Table/ActionTrashed.php:33-45`); no `:canEdit` no-op is present. Evidence: all six blades compile —

```
$ php artisan tinker --execute '... compileString() + php -l ...'
behaviouralassessment::config.create               COMPILES
behaviouralassessment::config.edit                 COMPILES
behaviouralassessment::config.show                 COMPILES
behaviouralassessment::config.trash                COMPILES
behaviouralassessment::config._fields              COMPILES
behaviouralassessment::config._create-fields       COMPILES
```

### F11 — Security and tenancy

clean — no `env()` outside config, no hard-coded id or `?? 1`, no personal data in JSON, no request/token logging (`Log::error` carries only the method name and the message), no cache. The `BaActor::systemId()` fallback lives in the linked `BaActor` class, not here. Evidence: `grep -nE "env\(|->all\(\)|Log::(info|debug)" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php` prints nothing.

### F12 — Style

clean — Pint passes on all four in-scope PHP files, and every one of them declares `strict_types=1`. Evidence:

```
$ vendor/bin/pint --test --format agent Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php Modules/BehaviouralAssessment/app/Http/Requests/BaConfigRequest.php Modules/BehaviouralAssessment/app/Models/BaConfig.php Modules/BehaviouralAssessment/app/Http/Requests/LocksAcademicSession.php
{"tool":"pint","result":"passed"}
```

Informational (no ID): STY-07 (user-facing strings hard-coded rather than via `__()` keys) is present, as it is module-wide; accepted, not planned.

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong overwrite | 2 Delete-before-store | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Lying message | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok | ok | ok | ok | ok |
| `update` | ok | ok | BCF-06 | ok | BCF-02 | BCF-04 | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | BCF-03 | ok | ok | BCF-03 | ok |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | BCF-02 | ok | ok | ok |

Notes. (1) `update` writes only via `$validated + ['updated_by' => …]`; `is_active`, `academic_session_id` and `rating_scale_id` are all validated, and the trait forces `academic_session_id` to the record's own session, so no column is silently reset. (2) `destroy` soft-deletes and `forceDelete` hard-deletes with no replacement to store first; both log after the write inside the transaction. (3) `edit` and `update` repeat the same `whereHas(...)->exists()` query and the same rule — BCF-06. (4) BCF-03: the restore path has no live-row guard against `uq_ba_config_session`. (5) BCF-02: the `update` guard is check-then-act; `toggleStatus` performs a read-modify-write of `is_active` with no lock (last write wins between two admins, which is acceptable for a boolean toggle and is not filed separately). (6) Every routed method calls `Gate::authorize` before loading its record; the only authorization issue is the duplicate check, BCF-04. (7) No message lies: the success flashes match the action, and the `BaTriggerError` branch is dead rather than wrong (part of BCF-01). (8) No dead feature: `ba_config` is read by the dashboard and the assessment/scoring services for the session's policy; the controller is the only writer.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` (owner: BaBehaviourPointController) | `message()` returns text only for a `QueryException` whose SQLSTATE is `45000` and whose text contains `BA: `. `ba_config` has no trigger, so its call in every catch of this controller can never return text — the argument is dead here. | informational | the report that owns `BaTriggerError` |
| `Modules/BehaviouralAssessment/app/Http/Requests/LocksAcademicSession.php` (owner: BaClassScaleController) | Used by this FormRequest to force `academic_session_id`. Its behaviour is correct here (create = current session, update = the record's own session), but it is owned and fully audited by another report. | — | the owning report |
| `Modules/BehaviouralAssessment/app/Support/BaActor.php`, `Models/BaAuditLog.php`, `Models/BaRatingScale.php`, `Models/BaAssessmentRating.php` | Linked, not re-audited. Usage checked: `BaActor::id()` for actor columns, `BaAuditLog::log()` with the exact six-argument signature and `ENTITY_CONFIG`, `BaRatingScale::activeOptions()` for the dropdown, and the rating `whereHas` chain — all correct. | D7 | their owning reports |
| `app/Traits/AuthorizesTenantFeature.php` | Common app glue (`app/` is common, §4.2). Maps POST to `create` and PUT/PATCH to `update`; used by `BaConfigRequest::authorize()`. | AUTH-04 | platform (`app/`) |
| `app/View/Components/Backend/Table/ActionTrashed.php`, `resources/views/components/backend/form/status-switch.blade.php`, `resources/views/components/backend/components/breadcrum.blade.php`, the `x-backend.layouts.app` layout | Common components and layout; the trash action and status-switch are called correctly with their supported props (`restorePermission` / `forceDeletePermission`, unique `id`). The breadcrumb resolves its own hub/tabs trail. | — | platform |
| `Modules/SchoolSetup/Models/OrganizationAcademicSession.php` | Different-module model (common, §4.2); used for the session dropdown and the `exists` FK target. | — | SchoolSetup |

## 8. Not covered, and why

- **`config/_create-fields.blade.php` and the Setup-page partials** (`pages/partials/setup/_configuration.blade.php`, `_configuration-create-modal.blade.php`, `_class-scale-modals.blade.php`): the create dialog on the Configuration tab is rendered by `BaDashboardController::setup()`, which supplies its own variables, so those blades belong to that controller's audit. Only the blades this controller renders (`create`, `edit`, `show`, `trash`, `_fields`) were audited here.
- **Linked classes** (`BaActor`, `BaTriggerError`, `BaAuditLog`, `BaRatingScale`, `BaAssessmentRating`, `LocksAcademicSession`): marked `↗ linked`; only how this controller uses them was checked, per D7.
- **Route model binding conversion**: reviewed under BCF-08 but deferred by D3 (it needs a route-parameter rename in a shared route file).
- **Runtime behaviour**: per D4 no tests were run; every finding is source-, tinker- or scanner-verified only.
- **Live DB row counts** are from the single tenant `00000000-0000-4000-8000-000000000001` (db `xyz_school_00000000000040008000_202627`); other tenants were not queried.
