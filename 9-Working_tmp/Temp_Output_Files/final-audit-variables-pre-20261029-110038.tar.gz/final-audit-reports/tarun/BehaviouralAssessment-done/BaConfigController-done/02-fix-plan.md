# Fix Plan — BehaviouralAssessment / BaConfigController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/BehaviouralAssessment/routes/web.php` | Shared route file — only the ticked BCF-07 item may edit it |
| `config/permissionslist.php` | Shared permission source (single producer) |
| `app/Traits/AuthorizesTenantFeature.php` | Common app glue (`app/`) |
| `app/View/Components/Backend/Table/ActionTrashed.php` | Shared component |
| `resources/views/components/backend/**` | Shared components and layout |
| `Modules/BehaviouralAssessment/app/Http/Requests/LocksAcademicSession.php` | Owned by `tarun/BehaviouralAssessment-done/BaClassScaleController-done` |
| `Modules/BehaviouralAssessment/app/Support/BaActor.php` | Owned by `tarun/BehaviouralAssessment-done/BaCommentBankController-done` |
| `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | Owned by `tarun/BehaviouralAssessment-done/BaBehaviourPointController-done` |
| `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` | Owned by `tarun/BehaviouralAssessment-done/BaAuditLogController-done` |
| `Modules/BehaviouralAssessment/app/Models/BaRatingScale.php` | Owned by `tarun/BehaviouralAssessment-done/BaRatingScaleController-done` |
| `Modules/BehaviouralAssessment/app/Models/BaAssessmentRating.php` | Owned by `tarun/BehaviouralAssessment-done/BaClassScaleController-done` |
| `database/migrations/tenant/2026_06_16_130621_create_ba_config_table.php` | Existing migration — never edited |

## 1. Blockers reachable today

None. This audit found no B-severity finding (no data loss, no security hole, no crash on a normal path). The highest-severity items (BCF-01 and BCF-07) are H and appear in §3 and §9.

## 2. Fixes that arm a latent defect (sequenced)

None. No fix here arms another; BCF-01 and BCF-03 are independent (BCF-01 rewrites five methods, BCF-03 rewrites `restore`).

## 3. Errors & transactions (F1/F2)

- [ ] **BCF-01** · H · ERR-00 · `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:46-68` — remove the D1-forbidden `try/catch` from the five mutating methods and build the redirect/response after the transaction.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php`
  - **Before** (`BaConfigController.php:42-68`, `store`):
    ```php
    public function store(BaConfigRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.create');

        try {
            return DB::transaction(function () use ($request) {
                $record = BaConfig::create($request->validated() + [
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Stored', ['message' => 'BaConfig was stored.']);

                return redirect()
                    ->route('behavioural-assessment.setup', ['tab' => 'configuration'])
                    ->with('success', 'Configuration created successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaConfigController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function store(BaConfigRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.create');

        DB::transaction(function () use ($request) {
            $record = BaConfig::create($request->validated() + [
                'created_by' => BaActor::id(),
                'updated_by' => BaActor::id(),
            ]);

            activityLog($record, 'Stored', ['message' => 'BaConfig was stored.']);
        });

        return redirect()
            ->route('behavioural-assessment.setup', ['tab' => 'configuration'])
            ->with('success', 'Configuration created successfully.');
    }
    ```
    `update` — replace `BaConfigController.php:93-145` with:
    ```php
    public function update(BaConfigRequest $request, int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.update');
        $config = BaConfig::findOrFail($id);

        $validated = $request->validated();

        if (isset($validated['rating_scale_id']) && (int) $validated['rating_scale_id'] !== $config->rating_scale_id) {
            $hasRatings = BaAssessmentRating::whereHas('assessment.period', function ($q) use ($config) {
                $q->where('academic_session_id', $config->academic_session_id);
            })->exists();

            if ($hasRatings) {
                return back()->withInput()->with('error', 'Cannot change rating scale because ratings have already been recorded for this academic session.');
            }
        }

        DB::transaction(function () use ($config, $validated) {
            $original = $config->getOriginal();
            $config->update($validated + ['updated_by' => BaActor::id()]);

            // Policy changes re-base published results: one ba_audit_log row per changed field.
            foreach ($config->getChanges() as $field => $newValue) {
                if (in_array($field, ['updated_by', 'updated_at'], true)) {
                    continue;
                }
                $oldValue = $original[$field] ?? null;
                BaAuditLog::log(BaAuditLog::ENTITY_CONFIG, $config->id, $field,
                    $oldValue === null ? null : (string) $oldValue,
                    $newValue === null ? null : (string) $newValue);
            }

            // The rating scale and weighting here drive every behavioural score in the
            // session, so a config change re-bases results that are already published.
            activityLog($config, 'Updated', [
                'message' => 'Behavioural assessment configuration was updated.',
                'changes' => array_keys($validated),
            ]);
        });

        return redirect()
            ->route('behavioural-assessment.setup', ['tab' => 'configuration'])
            ->with('success', 'Configuration updated successfully.');
    }
    ```
    `destroy` — replace `BaConfigController.php:147-175` with:
    ```php
    public function destroy(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.delete');

        DB::transaction(function () use ($id) {
            $config = BaConfig::findOrFail($id);
            $config->is_active = false;
            $config->updated_by = BaActor::id();
            $config->save();
            $config->delete();

            activityLog($config, 'Trashed', ['message' => 'BaConfig was trashed.']);
        });

        return redirect()
            ->route('behavioural-assessment.setup', ['tab' => 'configuration'])
            ->with('success', 'Configuration moved to trash.');
    }
    ```
    `forceDelete` — replace `BaConfigController.php:215-240` with:
    ```php
    public function forceDelete(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.forceDelete');

        DB::transaction(function () use ($id) {
            $config = BaConfig::withTrashed()->findOrFail($id);
            $config->forceDelete();

            activityLog($config, 'Deleted', ['message' => 'BaConfig was deleted.']);
        });

        return redirect()
            ->route('behavioural-assessment.configs.trashed')
            ->with('success', 'Configuration permanently deleted.');
    }
    ```
    `toggleStatus` — replace `BaConfigController.php:242-276` with:
    ```php
    public function toggleStatus(int $config): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.update');

        $item = DB::transaction(function () use ($config) {
            $item = BaConfig::findOrFail($config);
            $item->is_active = ! $item->is_active;
            $item->updated_by = BaActor::id();
            $item->save();

            activityLog($item, 'Toggled', ['message' => 'BaConfig was toggled.']);

            return $item;
        });

        return response()->json([
            'success' => true,
            'is_active' => $item->is_active,
            'message' => $item->is_active ? 'Configuration activated.' : 'Configuration deactivated.',
        ]);
    }
    ```
    Once BCF-03 is also applied, delete the three imports that become unused (lines `:7`, `:13`, `:21`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Support\Facades\Log;
    use Modules\BehaviouralAssessment\Support\BaTriggerError;
    ```
  - **Verify:** `grep -n "catch (\|Log::error\|BaTriggerError" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php`
  - **Expect:** after BCF-01 alone, the only `catch (` left is inside `restore`; after BCF-01 and BCF-03 together, no `catch (`, no `Log::error`, and `BaTriggerError` is present on no line.
  - **Effort:** M

- [ ] **BCF-03** · M · VAL-04 · `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:188-213` — guard `restore` against the live-row unique index `uq_ba_config_session`, and drop that method's `try/catch`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php`
  - **Before** (`BaConfigController.php:188-213`):
    ```php
    public function restore(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.restore');

        try {
            return DB::transaction(function () use ($id) {
                $config = BaConfig::onlyTrashed()->findOrFail($id);
                $config->restore();

                activityLog($config, 'Restored', ['message' => 'BaConfig was restored.']);

                return redirect()
                    ->route('behavioural-assessment.setup', ['tab' => 'configuration'])
                    ->with('success', 'Configuration restored successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaConfigController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function restore(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.restore');

        $trashed = BaConfig::onlyTrashed()->findOrFail($id);

        // uq_ba_config_session is UNIQUE(academic_session_id, IFNULL(deleted_at,'1970-01-01')).
        // Restoring while a live row exists for the same session would violate it, so refuse
        // with a clear message instead of a duplicate-key 500 (finding BCF-03, 2026-10-12).
        if (BaConfig::where('academic_session_id', $trashed->academic_session_id)->exists()) {
            return back()->with('error', 'A live configuration already exists for this academic session, so this trashed one cannot be restored.');
        }

        DB::transaction(function () use ($id) {
            $config = BaConfig::onlyTrashed()->findOrFail($id);
            $config->restore();

            activityLog($config, 'Restored', ['message' => 'BaConfig was restored.']);
        });

        return redirect()
            ->route('behavioural-assessment.setup', ['tab' => 'configuration'])
            ->with('success', 'Configuration restored successfully.');
    }
    ```
  - **Verify:** `grep -n "onlyTrashed\|cannot be restored\|catch (" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php`
  - **Expect:** two `onlyTrashed` lines with the `cannot be restored` guard between the first one and the transaction, and no `catch (` in the method.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **BCF-04** · L · AUTH-04 · `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php:44,95` — remove the two redundant `Gate::authorize` lines; `BaConfigRequest::authorize()` already enforces them.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php`
  - **Before** (`BaConfigController.php:42-44`, `store`, and `:93-96`, `update`):
    ```php
    public function store(BaConfigRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.create');
    ```
    ```php
    public function update(BaConfigRequest $request, int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.update');
        $config = BaConfig::findOrFail($id);
    ```
  - **After:**
    ```php
    public function store(BaConfigRequest $request): RedirectResponse
    {
        // Authorization is enforced by BaConfigRequest::authorize() (AUTH-04, 2026-10-12).
    ```
    ```php
    public function update(BaConfigRequest $request, int $id): RedirectResponse
    {
        // Authorization is enforced by BaConfigRequest::authorize() (AUTH-04, 2026-10-12).
        $config = BaConfig::findOrFail($id);
    ```
  - **Verify:** `grep -n "Gate::authorize('tenant.behavioural-assessment.configs.create')\|Gate::authorize('tenant.behavioural-assessment.configs.update')" Modules/BehaviouralAssessment/app/Http/Controllers/BaConfigController.php`
  - **Expect:** the `create` string is present only once (in `create`, line 35) and the `update` string only twice (in `edit`, line 81, and `toggleStatus`, line 244); neither appears in `store` or `update`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

None. The only F4/F5/F7 findings are DECISION items (BCF-06, BCF-07, BCF-08) in §9; F7 is clean.

## 6. Queries & performance (F9)

None — F9 is clean.

## 7. Views (F10)

None — F10 is clean.

## 8. Style (F12) — one item per file

None — Pint passes on all four in-scope PHP files and every one declares `strict_types=1`.

## 9. Deferred / decisions

- [ ] **BCF-02** · M · DECISION · TXN-06 — the rating-scale change guard is a check-then-act with no lock (`update`). How should the race be handled?
  - **Why it is a decision:** a policy choice; hardening changes the write path and needs a locking query.
  - (a) ⭐ Accept and document — the window is sub-second on a single-admin screen and the DB has no constraint to rely on; record it and change nothing.
  - (b) Harden — take `BaAssessmentRating::whereHas('assessment.period', ...)->lockForUpdate()->exists()` inside the existing transaction before the update.
  - (c) Add a ratings-side DB trigger that rejects a scale change while ratings exist (a new migration; Tarun's hand).
  - ➜ Choice: ____

- [ ] **BCF-06** · M · DECISION · VAL-07 — move the rating-scale-in-use rule into `BaConfigRequest::after()` so it returns a 422 field error instead of a page flash.
  - **Why it is a decision:** it changes the error surface (flash to 422) and adds an `after()` hook to the FormRequest; also a behaviour change for any future writer of `rating_scale_id`.
  - (a) ⭐ Move it — add `after()` to `BaConfigRequest` with the `whereHas` check, and delete the inline `if` in `update` (the `edit` query stays, to lock the select).
  - (b) Leave it in the controller — revisit if another path writes `rating_scale_id`.
  - (c) Leave it and accept it as the module convention.
  - ➜ Choice: ____

- [ ] **BCF-07** · H · DECISION · RTE-01 · `⚠ SHARED` — `configs/{id}/restore` mutates state over GET. Change the verb?
  - **Why it is a decision:** it edits a route file shared by the module, and route changes stop the fixer by §9.3.
  - (a) ⭐ Change `Route::get` to `Route::post` on `Modules/BehaviouralAssessment/routes/web.php:88` — the trash action component already reads the route verb and renders the matching form method and CSRF token, and the controller `restore` needs no change.
  - (b) Change it to `Route::delete` — matches the `forceDelete` verb; the component handles it too.
  - (c) Leave it as GET, accept the prefetch/crawler risk.
  - ➜ Choice: ____

- [ ] **BCF-08** · M · DECISION · CTL-03 — convert the seven id-taking methods (`show`, `edit`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`) to route model binding?
  - **Why it is a decision:** it needs a route-parameter rename on the shared route file, and D3 defers structural changes.
  - (a) ⭐ Defer to the D3 refactor pass — no change in this audit.
  - (b) Convert now — rename the custom route parameters to `{config}` in `routes/web.php` and type the arguments `BaConfig $config`.
  - (c) Accept the manual resolution as the module convention.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BCF-05 | The permission-literal pattern (AUTH-06) is module-wide (12 repeats in this controller, the same base used by `BaClassScaleController`, plus the blades). It is fixed by a module-wide constants or Policy pass, not by a per-controller plan item. |
