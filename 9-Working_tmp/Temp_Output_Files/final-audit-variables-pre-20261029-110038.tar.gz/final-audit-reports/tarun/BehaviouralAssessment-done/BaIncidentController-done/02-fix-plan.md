# Fix Plan — BehaviouralAssessment / BaIncidentController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php` for developer `tarun`. It applies **only** ticked items, in this order.

> **Sequencing (re-measure each edit against the file before applying — §9.2 #3):**
> - Apply **BAI-04 before BAI-12** and before **BAI-01** (all three touch `store()`/`removeIntervention()` regions).
> - Apply **BAI-17 before BAI-19** (both edit `show()`'s `compact()` list).
> - Apply **BAI-20 before BAI-11** (BAI-11's const already contains `resolvedBy.user`).

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `resources/views/components/backend/table/action-trashed.blade.php` | shared component — it already adapts to a POST route, so BAI-09 changes the route, not the component |
| `Modules/BehaviouralAssessment/routes/web.php` | route file — ⚠ SHARED; only BAI-09 names it, and only after Tarun ticks that DECISION |
| `config/permissionslist.php` | shared config — not edited by any item |
| `Modules/StudentProfile/app/Models/Student.php`, `Modules/SchoolSetup/app/Models/Employee.php` | other-module models, owned elsewhere |
| `Modules/BehaviouralAssessment/app/Models/BaIntervention.php`, `BaCriterion.php`, `BaAuditLog.php`, `BaCategory.php`, `BaConfig.php`, `BaIncidentInterventionJnt.php` | owned by other reports (see `00-CLASS-OWNERS.md`) |
| `database/migrations/tenant/*` | standing rule: never edit an existing migration |
| `resources/views/incident/_create-fields.blade.php` | belongs to `BaDashboardController::incidentsPage`, not this controller |

## 1. Blockers reachable today

- [ ] **BAI-01** · B · DECISION · TXN-03 · `BaIncidentController.php:100-108` — evidence files are written to disk inside the DB transaction.
  - **Why it is a decision:** it changes the atomicity contract between the incident row and its attachments (a product/architecture choice).
  - (a) ⭐ **Stage files before the transaction, delete them if it rolls back** — keeps "incident and its evidence land together". Add `stageFile(UploadedFile): array` + `persist(BaIncident, array, ?string, bool, Employee): BaIncidentAttachment` to `BaIncidentAttachmentService.php`; in `store()`, stage every file first, run `DB::transaction(...)` around `service->create` + `persist`, and `Storage::disk(BaIncidentAttachmentService::DISK)->delete($p)` in the catch. Touches `BaIncidentController.php` + `BaIncidentAttachmentService.php`.
  - (b) **Move uploads after commit** — create the incident in its own transaction, then upload each file; an upload failure shows a warning ("incident logged; some evidence failed"). Simplest diff; a failed upload leaves an incident without its evidence.
  - (c) **Accept** — keep the current behaviour and add a scheduled cleanup for files with no `ba_incident_attachments` row.
  - ➜ Choice: ____

## 2. Fixes that arm a latent defect (sequenced)

None. (BAI-01 and BAI-04 both touch `store()`; the sequencing note above handles the order.)

## 3. Errors & transactions (F1/F2)

- [ ] **BAI-02** · M · ERR-05 · `BaIncidentController.php:520` and `:238` — log the exception object, not its message.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Before** (`BaIncidentController.php:520`):
    ```php
        Log::error('BaIncidentController::'.$method.' failed', $context + ['error' => $e->getMessage()]);
    ```
  - **After:**
    ```php
        Log::error('BaIncidentController::'.$method.' failed', $context + ['exception' => $e]);
    ```
  - **Before** (`BaIncidentController.php:238`):
    ```php
                Log::error('BaIncidentController::restore failed', ['error' => $e->getMessage()]);
    ```
  - **After:**
    ```php
                Log::error('BaIncidentController::restore failed', ['exception' => $e]);
    ```
  - **Verify:** `grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BAI-04** · M · TXN-04 · `BaIncidentController.php:100-113, 158-169, 189-197, 313-321, 405-413, 469-486` — move `activityLog()` inside its transaction in six methods.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Before** (`store()`, `BaIncidentController.php:106-113`):
    ```php
                    return $incident;
                });
            } catch (Throwable $e) {
                return $this->failed($e, 'store', $request);
            }

            activityLog($incident, 'Stored', ['message' => 'BaIncident was stored.']);
    ```
  - **After:**
    ```php
                    activityLog($incident, 'Stored', ['message' => 'BaIncident was stored.']);

                    return $incident;
                });
            } catch (Throwable $e) {
                return $this->failed($e, 'store', $request);
            }
    ```
  - **Before** (`update()`, `BaIncidentController.php:158-169`):
    ```php
                $changed = DB::transaction(fn () => $this->service->update(
                    $incident, $request->validated(), BaIncidentService::currentEmployee()
                ));
            } catch (Throwable $e) {
                return $this->failed($e, 'update', $request, ['id' => $id]);
            }

            activityLog($incident, 'Updated', [
                'message' => 'Behaviour incident was updated.',
                'student_id' => $incident->student_id,
                'changed' => $changed,
            ]);
    ```
  - **After:**
    ```php
                DB::transaction(function () use ($incident, $request) {
                    $changed = $this->service->update(
                        $incident, $request->validated(), BaIncidentService::currentEmployee()
                    );

                    activityLog($incident, 'Updated', [
                        'message' => 'Behaviour incident was updated.',
                        'student_id' => $incident->student_id,
                        'changed' => $changed,
                    ]);
                });
            } catch (Throwable $e) {
                return $this->failed($e, 'update', $request, ['id' => $id]);
            }
    ```
  - **Before** (`cancel()`, `BaIncidentController.php:189-197`):
    ```php
                DB::transaction(fn () => $this->service->cancel($incident, (string) $request->validated('cancellation_reason')));
            } catch (Throwable $e) {
                return $this->failed($e, 'cancel', $request, ['id' => $id]);
            }

            activityLog($incident, 'Cancelled', [
                'message' => 'Behaviour incident was cancelled.',
                'student_id' => $incident->student_id,
            ]);
    ```
  - **After:**
    ```php
                DB::transaction(function () use ($incident, $request) {
                    $this->service->cancel($incident, (string) $request->validated('cancellation_reason'));

                    activityLog($incident, 'Cancelled', [
                        'message' => 'Behaviour incident was cancelled.',
                        'student_id' => $incident->student_id,
                    ]);
                });
            } catch (Throwable $e) {
                return $this->failed($e, 'cancel', $request, ['id' => $id]);
            }
    ```
  - **Before** (`transition()`, `BaIncidentController.php:313-321`):
    ```php
                DB::transaction(fn () => $this->service->transition($incident, $to, $request->validated('note'), $actor));
            } catch (Throwable $e) {
                return $this->failed($e, 'transition', $request, ['id' => $id, 'to' => $to]);
            }

            activityLog($incident, 'StatusChanged', [
                'message' => 'Behaviour incident moved from '.$from.' to '.$to.'.',
                'student_id' => $incident->student_id,
            ]);
    ```
  - **After:**
    ```php
                DB::transaction(function () use ($incident, $to, $request, $actor, $from) {
                    $this->service->transition($incident, $to, $request->validated('note'), $actor);

                    activityLog($incident, 'StatusChanged', [
                        'message' => 'Behaviour incident moved from '.$from.' to '.$to.'.',
                        'student_id' => $incident->student_id,
                    ]);
                });
            } catch (Throwable $e) {
                return $this->failed($e, 'transition', $request, ['id' => $id, 'to' => $to]);
            }
    ```
  - **Before** (`followUp()`, `BaIncidentController.php:405-413`):
    ```php
                DB::transaction(fn () => $this->service->addFollowup($incident, $request->validated(), $recorder));
            } catch (Throwable $e) {
                return $this->failed($e, 'followUp', $request, ['id' => $id]);
            }

            activityLog($incident, 'FollowedUp', [
                'message' => 'A follow-up was recorded on a behaviour incident.',
                'student_id' => $incident->student_id,
            ]);
    ```
  - **After:**
    ```php
                DB::transaction(function () use ($incident, $request, $recorder) {
                    $this->service->addFollowup($incident, $request->validated(), $recorder);

                    activityLog($incident, 'FollowedUp', [
                        'message' => 'A follow-up was recorded on a behaviour incident.',
                        'student_id' => $incident->student_id,
                    ]);
                });
            } catch (Throwable $e) {
                return $this->failed($e, 'followUp', $request, ['id' => $id]);
            }
    ```
  - **Before** (`removeIntervention()`, `BaIncidentController.php:469-486`):
    ```php
                $removed = DB::transaction(fn () => $this->service->removeIntervention($incident, $jntId));
            } catch (Throwable $e) {
                return $this->failed($e, 'removeIntervention', request(), ['id' => $incident->id]);
            }

            if (! $removed) {
                abort(404);
            }

            // Logged against the INCIDENT: the link row has no identity a reader would
            // recognise, and the incident is what an auditor searches by.
            activityLog($incident, 'InterventionRemoved', [
                'message' => 'An intervention was removed from a behaviour incident.',
                'link_id' => $jntId,
                'student_id' => $incident->student_id,
            ]);
    ```
  - **After:**
    ```php
                $removed = DB::transaction(function () use ($incident, $jntId) {
                    $removed = $this->service->removeIntervention($incident, $jntId);

                    if ($removed) {
                        // Logged against the INCIDENT: the link row has no identity a reader would
                        // recognise, and the incident is what an auditor searches by.
                        activityLog($incident, 'InterventionRemoved', [
                            'message' => 'An intervention was removed from a behaviour incident.',
                            'link_id' => $jntId,
                            'student_id' => $incident->student_id,
                        ]);
                    }

                    return $removed;
                });
            } catch (Throwable $e) {
                return $this->failed($e, 'removeIntervention', request(), ['id' => $incident->id]);
            }

            if (! $removed) {
                abort(404);
            }
    ```
  - **Verify:** `grep -n "activityLog" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Expect:** the `activityLog(` lines now sit between a `DB::transaction(function () use (...)` opening and its `});` in all six methods.
  - **Effort:** M

- [ ] **BAI-05** · M · TXN-04 · `BaIncidentController.php:451-461` and `:373-382` — two write paths record no activity log; add one.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Before** (`addIntervention()`, `BaIncidentController.php:452-461`):
    ```php
                $added = DB::transaction(fn () => $this->service->addIntervention(
                    $incident, (int) $validated['intervention_id'], $validated['notes'] ?? null, BaIncidentService::currentEmployee()
                ));
            } catch (Throwable $e) {
                return $this->failed($e, 'addIntervention', $request, ['id' => $id]);
            }

            return $added
                ? back()->with('success', 'Intervention added.')
                : back()->with('error', 'That intervention is already applied to this incident.');
    ```
  - **After:**
    ```php
                $added = DB::transaction(function () use ($incident, $validated) {
                    $added = $this->service->addIntervention(
                        $incident, (int) $validated['intervention_id'], $validated['notes'] ?? null, BaIncidentService::currentEmployee()
                    );

                    if ($added) {
                        activityLog($incident, 'InterventionAdded', [
                            'message' => 'An intervention was applied to a behaviour incident.',
                            'student_id' => $incident->student_id,
                        ]);
                    }

                    return $added;
                });
            } catch (Throwable $e) {
                return $this->failed($e, 'addIntervention', $request, ['id' => $id]);
            }

            return $added
                ? back()->with('success', 'Intervention added.')
                : back()->with('error', 'That intervention is already applied to this incident.');
    ```
  - **Before** (`recordWitnessStatement()`, `BaIncidentController.php:374-382`):
    ```php
                DB::transaction(fn () => $this->witnessService->record(
                    $row,
                    (string) $request->validated('statement'),
                    (bool) $request->validated('is_confidential'),
                    $recorder
                ));
            } catch (Throwable $e) {
                return $this->failed($e, 'recordWitnessStatement', $request, ['id' => $id, 'witness' => $witness]);
            }
    ```
  - **After:**
    ```php
                DB::transaction(function () use ($row, $request, $recorder) {
                    $this->witnessService->record(
                        $row,
                        (string) $request->validated('statement'),
                        (bool) $request->validated('is_confidential'),
                        $recorder
                    );

                    activityLog($row, 'WitnessStatementRecorded', [
                        'message' => 'A witness statement was recorded on a behaviour incident.',
                    ]);
                });
            } catch (Throwable $e) {
                return $this->failed($e, 'recordWitnessStatement', $request, ['id' => $id, 'witness' => $witness]);
            }
    ```
  - **Verify:** `grep -n "InterventionAdded\|WitnessStatementRecorded" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Expect:** two matches.
  - **Effort:** S

- [ ] **BAI-06** · M · TXN-05 · `BaIncidentController.php:223-241` — build the redirect after the transaction, not inside it.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Before** (`restore()`, `BaIncidentController.php:223-241`):
    ```php
            try {
                return DB::transaction(function () use ($id) {
                    $incident = BaIncident::onlyTrashed()->findOrFail($id);
                    $incident->restore();

                    activityLog($incident, 'Restored', ['message' => 'BaIncident was restored.']);

                    return redirect()
                        ->route('behavioural-assessment.incidents.trashed')
                        ->with('success', 'Incident restored successfully.');
                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404.
                throw $e;
            } catch (Throwable $e) {
                Log::error('BaIncidentController::restore failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:**
    ```php
            try {
                DB::transaction(function () use ($id) {
                    $incident = BaIncident::onlyTrashed()->findOrFail($id);
                    $incident->restore();

                    activityLog($incident, 'Restored', ['message' => 'BaIncident was restored.']);
                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404.
                throw $e;
            } catch (Throwable $e) {
                Log::error('BaIncidentController::restore failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }

            return redirect()
                ->route('behavioural-assessment.incidents.trashed')
                ->with('success', 'Incident restored successfully.');
    ```
  - **Verify:** `sed -n '223,244p' Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Expect:** the `redirect()->route('behavioural-assessment.incidents.trashed')` block now sits after the closing `}` of the last `catch`, not inside the transaction.
  - **Effort:** S

## 4. Authorization (F3)

None. The one F3 finding (BAI-07, AUTH-04) is accepted — see §10.

## 5. Validation, routes, models (F4/F5/F7) and controller shape (F6)

- [ ] **BAI-11** · M · CTL-05 · `BaIncidentController.php:123, 253-260, 421-424` — one relation list, not three.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Before** (insert the const, `BaIncidentController.php:49-53`):
    ```php
        public function __construct(
            private readonly BaIncidentService $service,
            private readonly BaWitnessService $witnessService,
            private readonly BaIncidentAttachmentService $attachmentService,
        ) {}
    ```
  - **After:**
    ```php
        /** Relations the incident detail, edit and timeline screens need. */
        private const DISPLAY_RELATIONS = [
            'student',
            'reportedBy.user',
            'category',
            'criterion',
            'interventions',
            'witnesses',
            'resolvedBy.user',
        ];

        public function __construct(
            private readonly BaIncidentService $service,
            private readonly BaWitnessService $witnessService,
            private readonly BaIncidentAttachmentService $attachmentService,
        ) {}
    ```
  - **Before** (`edit()`, `BaIncidentController.php:123`):
    ```php
            $incident = BaIncident::with(['student', 'reportedBy.user', 'category', 'criterion', 'witnesses', 'interventions'])->findOrFail($id);
    ```
  - **After:**
    ```php
            $incident = BaIncident::with(self::DISPLAY_RELATIONS)->findOrFail($id);
    ```
  - **Before** (`show()`, `BaIncidentController.php:253-260`):
    ```php
            $incident = BaIncident::with([
                'student',
                'reportedBy.user',
                'category',
                'criterion',
                'interventions',
                'witnesses',
            ])->findOrFail($id);
    ```
  - **After:**
    ```php
            $incident = BaIncident::with(self::DISPLAY_RELATIONS)->findOrFail($id);
    ```
  - **Before** (`timeline()`, `BaIncidentController.php:421-424`):
    ```php
            $incident = BaIncident::with([
                'student', 'reportedBy.user', 'category', 'criterion',
                'interventions', 'witnesses',
            ])->findOrFail($id);
    ```
  - **After:**
    ```php
            $incident = BaIncident::with(self::DISPLAY_RELATIONS)->findOrFail($id);
    ```
  - **Verify:** `grep -c "self::DISPLAY_RELATIONS" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Expect:** `4` (one const declaration use site is excluded; 1 in edit, 1 in show, 1 in timeline, and the closing brace is not a match — expected output `3`). If the count is lower, re-run the edit — re-measure with `grep -n "DISPLAY_RELATIONS"`.
  - **Effort:** S

- [ ] **BAI-12** · L · CTL-08 · `BaIncidentController.php:464, 471` — inject `Request` instead of calling the `request()` helper.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Before** (`BaIncidentController.php:464`):
    ```php
        public function removeIntervention(BaIncident $incident, int $jntId): RedirectResponse|JsonResponse
    ```
  - **After:**
    ```php
        public function removeIntervention(Request $request, BaIncident $incident, int $jntId): RedirectResponse|JsonResponse
    ```
  - **Before** (`BaIncidentController.php:471`):
    ```php
                return $this->failed($e, 'removeIntervention', request(), ['id' => $incident->id]);
    ```
  - **After:**
    ```php
                return $this->failed($e, 'removeIntervention', $request, ['id' => $incident->id]);
    ```
  - **Verify:** `grep -n "request()" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BAI-14** · M · SVC-02 · `BaIncidentService.php:37-38, 439` — inject `BaWitnessService` instead of `app()` mid-method.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php`
  - **Before** (`BaIncidentService.php:37-40`):
    ```php
    final class BaIncidentService
    {
        /** BR-BA-070 default when the current session has no ba_config row. */
        public const DEFAULT_BACKDATING_DAYS = 7;
    ```
  - **After:**
    ```php
    final class BaIncidentService
    {
        public function __construct(private readonly BaWitnessService $witnessService) {}

        /** BR-BA-070 default when the current session has no ba_config row. */
        public const DEFAULT_BACKDATING_DAYS = 7;
    ```
  - **Before** (`BaIncidentService.php:438-440`):
    ```php
            if ($to === BaIncident::STATUS_CLOSED && BaWitnessService::freezeOnClosure()) {
                app(BaWitnessService::class)->freezeForIncident($incident);
            }
    ```
  - **After:**
    ```php
            if ($to === BaIncident::STATUS_CLOSED && BaWitnessService::freezeOnClosure()) {
                $this->witnessService->freezeForIncident($incident);
            }
    ```
  - **Verify:** `grep -n "app(BaWitnessService" Modules/BehaviouralAssessment/app/Services/BaIncidentService.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **BAI-17** · M · QRY-12/CTL-10 · `BaIncidentController.php:262, 290-292, 540-555` — delete the dead `resolveWitnessPeople()` (its result is never used, and `BaWitnessService::rows()` repeats the same two queries).
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Before** (`BaIncidentController.php:262-267`):
    ```php
            [$studentWitnesses, $staffWitnesses] = $this->resolveWitnessPeople($incident);
            $followups = $this->followupLog($incident);

            // Witness rows WITHOUT statement text: the text is fetched per witness by
            // witnessStatement(), so each disclosure is a deliberate, audited read (BR-BA-031).
            $witnessRows = $this->witnessService->rows($incident);
    ```
  - **After:**
    ```php
            $followups = $this->followupLog($incident);

            // Witness rows WITHOUT statement text: the text is fetched per witness by
            // witnessStatement(), so each disclosure is a deliberate, audited read (BR-BA-031).
            $witnessRows = $this->witnessService->rows($incident);
    ```
  - **Before** (`compact()`, `BaIncidentController.php:289-292`):
    ```php
            return view('behaviouralassessment::incident.show', compact(
                'incident', 'studentWitnesses', 'staffWitnesses', 'followups',
                'witnessRows', 'canRecordStatements', 'attachments', 'currentEmployee', 'nextStates',
                'caseOwners'
            ));
    ```
  - **After:**
    ```php
            return view('behaviouralassessment::incident.show', compact(
                'incident', 'followups',
                'witnessRows', 'canRecordStatements', 'attachments', 'currentEmployee', 'nextStates',
                'caseOwners'
            ));
    ```
  - **Before** (delete the method, `BaIncidentController.php:540-555`):
    ```php
        /**
         * Student / staff people behind the live witness rows. Polymorphic (no DB FK), so they
         * are loaded in two queries rather than one find() per witness.
         *
         * @return array{0: Collection, 1: Collection}
         */
        private function resolveWitnessPeople(BaIncident $incident): array
        {
            $studentIds = $incident->witnesses->where('witness_type', 'student')->pluck('witness_id')->all();
            $staffIds = $incident->witnesses->where('witness_type', 'staff')->pluck('witness_id')->all();

            return [
                $studentIds === [] ? collect() : Student::whereIn('id', $studentIds)->get(),
                $staffIds === [] ? collect() : Employee::with('user')->whereIn('id', $staffIds)->get(),
            ];
        }

        /** A live witness row of this incident, or 404. */
    ```
  - **After:**
    ```php
        /** A live witness row of this incident, or 404. */
    ```
  - **Verify:** `grep -n "resolveWitnessPeople\|studentWitnesses\|staffWitnesses" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BAI-21** · M · TEN-02 · `BaWitnessService.php:8, 40-41, 63-67` — key the read-audit dedupe by tenant, not by witness id alone.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaWitnessService.php`
  - **Before** (`BaWitnessService.php:7-8`):
    ```php
    use Illuminate\Support\Collection;
    use Illuminate\Support\Facades\Gate;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Collection;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    ```
  - **Before** (`BaWitnessService.php:40-41`):
    ```php
        /** @var array<int, true> witness ids whose read was already audited in this request */
        private static array $auditedReads = [];
    ```
  - **After:**
    ```php
        /** @var array<string, true> tenant-qualified witness keys whose read was already audited in this request */
        private static array $auditedReads = [];
    ```
  - **Before** (`BaWitnessService.php:63-67`):
    ```php
            $id = (int) $witness->id;
            if (! isset(self::$auditedReads[$id])) {
                BaAuditLog::log(BaAuditLog::ENTITY_WITNESS_READ, $id, 'statement', null, null);
                self::$auditedReads[$id] = true;
            }
    ```
  - **After:**
    ```php
            $id = (int) $witness->id;
            $cacheKey = DB::connection()->getDatabaseName().':'.$id;
            if (! isset(self::$auditedReads[$cacheKey])) {
                BaAuditLog::log(BaAuditLog::ENTITY_WITNESS_READ, $id, 'statement', null, null);
                self::$auditedReads[$cacheKey] = true;
            }
    ```
  - **Verify:** `grep -n "getDatabaseName" Modules/BehaviouralAssessment/app/Services/BaWitnessService.php`
  - **Expect:** one match.
  - **Effort:** S

## 7. Views (F10)

- [ ] **BAI-19** · H · VIEW-01 · `BaIncidentController.php:287-293` + `show.blade.php:578-587` — move the intervention query out of the template.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`, `Modules/BehaviouralAssessment/resources/views/incident/show.blade.php`
  - **Before** (`BaIncidentController.php:287-293`):
    ```php
                ->mapWithKeys(fn (Employee $e) => [$e->id => BaInterventionCaseController::employeeName($e)]);

            return view('behaviouralassessment::incident.show', compact(
                'incident', 'studentWitnesses', 'staffWitnesses', 'followups',
                'witnessRows', 'canRecordStatements', 'attachments', 'currentEmployee', 'nextStates',
                'caseOwners'
            ));
    ```
  - **After:**
    ```php
                ->mapWithKeys(fn (Employee $e) => [$e->id => BaInterventionCaseController::employeeName($e)]);

            // BR-BA-037: the Add Intervention modal offers only interventions whose type matches
            // the incident's polarity. Computed here, not in the Blade template (VIEW-01).
            $forbiddenType = $incident->incident_type === BaIncident::TYPE_POSITIVE
                ? BaIntervention::TYPE_CORRECTIVE
                : BaIntervention::TYPE_REWARD;
            $allInterventions = BaIntervention::where('is_active', true)
                ->where('intervention_type', '!=', $forbiddenType)
                ->orderBy('sort_order')->orderBy('name')->get();

            return view('behaviouralassessment::incident.show', compact(
                'incident', 'studentWitnesses', 'staffWitnesses', 'followups',
                'witnessRows', 'canRecordStatements', 'attachments', 'currentEmployee', 'nextStates',
                'caseOwners', 'allInterventions'
            ));
    ```
  - **Before** (`show.blade.php:578-587`):
    ```php
        @php
            // BR-BA-037: rewards only on a positive incident, corrective only on a negative one.
            $forbiddenType = $incident->incident_type === \Modules\BehaviouralAssessment\Models\BaIncident::TYPE_POSITIVE
                ? \Modules\BehaviouralAssessment\Models\BaIntervention::TYPE_CORRECTIVE
                : \Modules\BehaviouralAssessment\Models\BaIntervention::TYPE_REWARD;
            $allInterventions = \Modules\BehaviouralAssessment\Models\BaIntervention::where('is_active', true)
                ->where('intervention_type', '!=', $forbiddenType)
                ->orderBy('sort_order')->orderBy('name')->get();
        @endphp
    ```
  - **After:**
    ```php
        @php
            // BR-BA-037: rewards only on a positive incident, corrective only on a negative one.
            // $allInterventions is provided by BaIncidentController::show() — no query in Blade (VIEW-01).
        @endphp
    ```
  - **Verify:** `grep -n "BaIntervention::where" Modules/BehaviouralAssessment/resources/views/incident/show.blade.php`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **BAI-20** · L · VIEW-02 · `BaIncidentController.php:253-260` — eager-load `resolvedBy.user` on the detail page.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Before** (`show()`, `BaIncidentController.php:253-260`):
    ```php
            $incident = BaIncident::with([
                'student',
                'reportedBy.user',
                'category',
                'criterion',
                'interventions',
                'witnesses',
            ])->findOrFail($id);
    ```
  - **After:**
    ```php
            $incident = BaIncident::with([
                'student',
                'reportedBy.user',
                'category',
                'criterion',
                'interventions',
                'witnesses',
                'resolvedBy.user',
            ])->findOrFail($id);
    ```
  - **Verify:** `grep -n "resolvedBy.user" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Expect:** one match.
  - **Effort:** S
  - **Note:** if **BAI-11** is also ticked, `resolvedBy.user` is already inside `DISPLAY_RELATIONS` — skip this item.

## 8. Style (F12) — one item per file

- [ ] **BAI-22** · L · STY-04 · `show.blade.php:563-566` + `BaIncidentController.php:530, 573` — delete commented-out markup; add the two missing private return types.
  - **Touches:** `Modules/BehaviouralAssessment/resources/views/incident/show.blade.php`, `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Before** (`show.blade.php:561-567`):
    ```php
                                    </tr>
                                    @endif
                                    {{-- <tr>
                                        <td class="text-muted small fw-semibold bg-light">ID</td>
                                        <td class="small">#{{ $incident->id }}</td>
                                    </tr> --}}
                                </tbody>
    ```
  - **After:**
    ```php
                                    </tr>
                                    @endif
                                </tbody>
    ```
  - **Before** (`BaIncidentController.php:530`):
    ```php
        private function followupLog(BaIncident $incident)
    ```
  - **After:**
    ```php
        private function followupLog(BaIncident $incident): Collection
    ```
  - **Before** (`BaIncidentController.php:573`):
    ```php
        private function witnessRows(BaIncident $incident)
    ```
  - **After:**
    ```php
        private function witnessRows(BaIncident $incident): Collection
    ```
  - **Verify:** `grep -n "{{-- <tr>\|private function followupLog\|private function witnessRows" Modules/BehaviouralAssessment/resources/views/incident/show.blade.php Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php`
  - **Expect:** the two `private function` lines end with `: Collection`; no `{{-- <tr>` match.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BAI-03** · M · DECISION · ERR-00 — keep the controller-level try/catch that maps DB-trigger rejections, or move it to the central handler?
  - **Why it is a decision:** D2 lists the only allowed catches and DB-trigger mapping is not among them; removing it loses the friendly `BA: …` form messages, keeping it contradicts D1.
  - (a) ⭐ **Keep, documented** — add a comment naming ERR-01 + date above `failed()` explaining the sanctioned DB-trigger mapping; no behaviour change.
  - (b) **Move to a custom exception** — add `BaTriggerException` handled in `bootstrap/app.php`; larger change, touches a shared bootstrap file.
  - (c) **Remove the catches** — delete every `try/catch` and let the central renderer show its generic error; users lose the specific trigger message.
  - ➜ Choice: ____

- [ ] **BAI-08** · M · DECISION · VAL-02 — move the inline validation in `store()` (attachments) and `addIntervention()` into FormRequests?
  - **Why it is a decision:** it adds a new FormRequest class and moves error keys the views read (`attachments.*`), a behaviour-adjacent change.
  - (a) ⭐ **Accept for now** — the rules are correct and the cross-field hooks were executed; record as accepted inline validation, revisit in a validation pass.
  - (b) **Move both** — add the attachment rules to `BaIncidentRequest` and create `BaIncidentInterventionRequest`; keep the same error keys.
  - (c) **Move only `addIntervention`** — create the new FormRequest, leave the attachment rules inline.
  - ➜ Choice: ____

- [ ] **BAI-09** · H · DECISION · RTE-01 · ⚠ SHARED — change the `restore` route from GET to POST.
  - **Why it is a decision:** it is a route-file change; the shared `action-trashed` component already renders POST + `@csrf` when the route's first verb is POST, so no component edit is needed.
  - **Touches:** `Modules/BehaviouralAssessment/routes/web.php`
  - **Before** (`web.php:117`):
    ```php
    Route::get('incidents/{id}/restore', [BaIncidentController::class, 'restore'])->name('incidents.restore');
    ```
  - **After:**
    ```php
    Route::post('incidents/{id}/restore', [BaIncidentController::class, 'restore'])->name('incidents.restore');
    ```
  - (a) ⭐ **Change to POST** — the component adapts automatically; restores become CSRF-protected.
  - (b) **Change to DELETE** — the component renders POST + `@method('DELETE')`; semantically cleaner, still CSRF-protected.
  - (c) **Leave as GET, accepted** — record the CSRF/prefetch exposure as an accepted risk.
  - ➜ Choice: ____

- [ ] **BAI-10** · M · DECISION · CTL-03 — convert the eight `int $id` + `findOrFail` methods to route model binding?
  - **Why it is a decision:** D3 defers broad mechanical refactors; the routes already name the parameter `{incident}`, so the conversion changes eight signatures at once.
  - (a) ⭐ **Defer to the split/refactor pass** — record it and keep the current working positional binding.
  - (b) **Convert now** — change `edit/update/cancel/show/transition/followUp/timeline/addIntervention` to `BaIncident $incident` and replace each `findOrFail`. `BaIncidentRequest::incident()` already accepts a bound model, so no FormRequest change.
  - (c) **Only fix `update` and `removeIntervention`** — bind those two, leave the rest.
  - ➜ Choice: ____

- [ ] **BAI-13** · M · DECISION · QRY-15 — replace the unbounded student/staff selects in `BaIncident::formOptions()`.
  - **Why it is a decision:** it changes the form UX (a searchable picker instead of a full `<select>`), and the same method feeds `BaDashboardController::incidentsPage()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Models/BaIncident.php`
  - **Context:** on test.localhost the create form loads 1,824 students and 139 employees into one dropdown.
  - (a) ⭐ **Searchable AJAX picker** — students and staff load on typing; remove the two heavy `->get()` calls from `formOptions()`.
  - (b) **Cap the list** — e.g. limit to the student's class / first N, and keep the plain select.
  - (c) **Accept** — record the load as accepted for current data sizes.
  - ➜ Choice: ____

- [ ] **BAI-15** · M · DECISION · SVC-04 — unify the two witness-statement write paths.
  - **Why it is a decision:** the two implementations currently record different audit rows and handle `is_confidential` differently, so unifying them changes what the edit form can write.
  - (a) ⭐ **Route the edit form through `BaWitnessService::record()`** — one implementation; add `is_confidential` handling to the edit path if the form should own it.
  - (b) **Keep both, align the audit semantics** — make `BaIncidentService::recordWitnessStatements()` emit the same `BaAuditLog` values as `record()`.
  - (c) **Accept** — record the divergence as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BAI-07 | AUTH-04 (L), accepted — the FormRequest `authorize()` runs first and is the real guard; the controller `Gate::authorize` only adds a redirect shape. Removing it is optional and low value. |
| BAI-16 | SVC-05 (L), accepted — the repeated lookups are single cheap `value()` statements; memoising static helpers across a request risks a cross-tenant cache bug (the same class of issue as BAI-21). Better left alone until a request-scoped cache is designed. |
| BAI-18 | QRY-07 (L), accepted — the loops are bounded by the witness/intervention count on one incident and each row needs its own audit entry; a bulk write would drop that audit. |
