# Status — BehaviouralAssessment / BaIncidentController

**Fixed:** 2026-10-22 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work

| ID | File:line | What was pre-applied | Verified | Date |
|---|---|---|---|---|
| BAI-09(a) | `Modules/BehaviouralAssessment/routes/web.php:114` | `incidents/{id}/restore` is already `Route::post(...)` (orchestrator change; this fixer did **not** edit the route file). | `route:list` shows `POST behavioural-assessment/incidents/{id}/restore`. | 2026-10-22 |

**Drift observed (recorded, not reverted):** the earlier BAIC-04 fix moved `employeeName()` to `Support\BaEmployeeName` and shifted line numbers throughout `BaIncidentController.php`; `edit()`'s `with([...])` did not contain `resolvedBy.user` before this run. Every Before block was re-measured against the live file and only the mechanical lines were adapted (notably `show()` now uses the shared `DISPLAY_RELATIONS` constant, which carries `resolvedBy.user`).

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| BAI-01(a) | `BaIncidentController.php:114-139`; `BaIncidentAttachmentService.php:53-122` | Files are staged before the transaction (`stageFile()`), persisted inside it (`persist()`), and deleted in the catch on rollback. Added `Storage` import. | `grep -n "stageFile\|persist(\|Storage::disk(BaIncidentAttachmentService::DISK)->delete" …BaIncidentController.php` | lines 119, 125, 134 (see §6) | 2026-10-22 |
| BAI-02 | `BaIncidentController.php:239, 575` | Log the exception object: `['exception' => $e]` in `restore()` and `failed()`. | `grep -n "getMessage" …BaIncidentController.php` | no output (exit 1) | 2026-10-22 |
| BAI-03(a) | `BaIncidentController.php:554-556` | Decision recorded: kept the DB-trigger catch and documented it with an ERR-01 + date comment above `failed()`. No behaviour change. | `grep -n "ERR-01 (2026-10-22)" -A 2 …BaIncidentController.php` | comment at 554-556 | 2026-10-22 |
| BAI-04 | `BaIncidentController.php:128, 188, 219, 257, 346, 446, 495, 523` | `activityLog()` moved inside its transaction in `store`, `update`, `cancel`, `restore`, `transition`, `followUp`, `addIntervention`, `removeIntervention`. | `grep -n "activityLog" …BaIncidentController.php` | 9 lines; each is inside a `DB::transaction(function () use (...))` | 2026-10-22 |
| BAI-05 | `BaIncidentController.php:414, 495` | Added `WitnessStatementRecorded` and `InterventionAdded` activity rows inside their transactions. | `grep -n "InterventionAdded\|WitnessStatementRecorded" …BaIncidentController.php` | 2 matches | 2026-10-22 |
| BAI-06 | `BaIncidentController.php:248-275` | `restore()` builds the redirect after the transaction/catch, not inside it. | `sed -n '248,275p' …BaIncidentController.php` | redirect after the last `catch` | 2026-10-22 |
| BAI-08(a) | — | Decision recorded: inline validation in `store()` and `addIntervention()` accepted for now (correct rules); revisit in a validation pass. No code change. | — | — | 2026-10-22 |
| BAI-10(a) | — | Decision recorded: route-model-binding conversion deferred to the split/refactor pass. No code change. | — | — | 2026-10-22 |
| BAI-11 | `BaIncidentController.php:50-60, 148, 282, 461` | Added `DISPLAY_RELATIONS` (includes `resolvedBy.user`) and used it in `edit()`, `show()`, `timeline()`. | `grep -c "self::DISPLAY_RELATIONS" …BaIncidentController.php` | `3` | 2026-10-22 |
| BAI-12 | `BaIncidentController.php:508, 531` | `removeIntervention()` injects `Request`; the `request()` helper is gone. | `grep -n "request()" …BaIncidentController.php` | no output (exit 1) | 2026-10-22 |
| BAI-14 | `BaIncidentService.php:40, 442` | Injected `BaWitnessService` in the constructor; `transition()` uses `$this->witnessService`. | `grep -n "app(BaWitnessService" …BaIncidentService.php` | no output (exit 1) | 2026-10-22 |
| BAI-15(a) | `BaIncidentService.php:183-231`; `BaWitnessService.php:79-120`; `BaIncidentRequest.php:70-72`; `edit.blade.php:268-281` | Edit path now delegates to `BaWitnessService::record()`; added per-row `is_confidential` (hidden 0 + checkbox 1) and `witness_confidential` validation. `record()` normalises a cleared textarea to NULL and accepts a nullable recorder to preserve the old unattributed-edit case. | `grep -n "witnessService->record\|witness_confidential" …` | see §6 | 2026-10-22 |
| BAI-17 | `BaIncidentController.php:281-...` | Deleted the dead `resolveWitnessPeople()` and its two `compact()` variables; removed the now-unused `Student` import. | `grep -n "resolveWitnessPeople\|studentWitnesses\|staffWitnesses" …BaIncidentController.php` | no output (exit 1) | 2026-10-22 |
| BAI-19 | `BaIncidentController.php:307-320`; `show.blade.php:578-581` | Intervention options are computed in `show()` as `$allInterventions`; the Blade query block is replaced by a comment. | `grep -n "BaIntervention::where" …show.blade.php` | no output (exit 1) | 2026-10-22 |
| BAI-21 | `BaWitnessService.php:9, 43, 64-69` | Read-audit dedupe key is now `databaseName:witnessId`, so two tenants cannot share a cache entry. | `grep -n "getDatabaseName" …BaWitnessService.php` | line 65, one match | 2026-10-22 |
| BAI-22 | `show.blade.php:563-566`; `BaIncidentController.php:587, 613` | Removed the commented-out ID `<tr>`; added `: Collection` to `followupLog()` and `witnessRows()`. | `grep -n "{{-- <tr>\|private function followupLog\|private function witnessRows" …` | both methods end `: Collection`; no `{{-- <tr>` | 2026-10-22 |
| BAI-13(a) | `BaIncidentController.php:80-166`; `BaIncident.php:229-238`; `BaDashboardController.php:1478-1486`; `routes/web.php:117`; `incident/create.blade.php`; `incident/edit.blade.php`; `incident/_create-fields.blade.php`; `incident/_partials/_witness-picker.blade.php`; `incident/_partials/_witness-picker-scripts.blade.php`; `incident/_partials/_student-picker-scripts.blade.php` | Searchable AJAX picker: added `GET incidents/options` → `BaIncidentController::options()` (students/staff, `q` + `ids[]`, 50-row cap); `BaIncident::formOptions()` no longer loads students/staff; create/edit/dashboard forms fetch on typing and preload selected witnesses. | `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --name=behavioural-assessment.incidents.options` | `GET behavioural-assessment/incidents/options …@options` | 2026-10-22 |

## 3. Not applied

| ID | Reason (not ticked / already applied / superseded / blocked) | Detail |
|---|---|---|
| BAI-20 | **Superseded by BAI-11** | Plan note: if BAI-11 is ticked, `resolvedBy.user` is already in `DISPLAY_RELATIONS` and this item is skipped. It is present at `BaIncidentController.php:58`, so no separate edit was made. |

## 4. Needs Tarun's hand

- No migration, seeder or permission sync is required by this run.
- Browser check (not run — D4): open `/behavioural-assessment/incidents/create` and `/incidents/{id}/edit`, type in the student search and both witness searches, and confirm the selected witness ids still submit. Also confirm the dashboard "Log Incident" dialog's student search works.

## 5. Unverifiable by this workflow (no tests, D4)

- BAI-01 rollback path (file deleted when the transaction fails) is static-only: it needs a forced DB/upload failure.
- BAI-13 type-ahead and pre-selected witnesses are static-only: they need a browser submit.
- BAI-15 edit-path statement write and confidentiality toggle are static-only: they need a browser submit.
- BAI-21 cross-tenant dedupe is static-only: it needs two tenant connections in one request.

## 6. Verification log

```
$ for f in …; do php -l "$f"; done
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Services/BaIncidentAttachmentService.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Services/BaWitnessService.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Services/BaIncidentService.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Requests/BaIncidentRequest.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Models/BaIncident.php

$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); var_dump(class_exists(Modules\BehaviouralAssessment\Http\Controllers\BaIncidentController::class));'
bool(true)

$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json >/dev/null && echo ROUTES-OK
ROUTES-OK

$ php /tmp/fa-compile-blade.php …/incident/show.blade.php …/incident/edit.blade.php
Modules/BehaviouralAssessment/resources/views/incident/show.blade.php
  @push( count: 0 | startPush count: 0
No syntax errors detected in /tmp/fa-blade-0.php
Modules/BehaviouralAssessment/resources/views/incident/edit.blade.php
  @push( count: 1 | startPush count: 1
No syntax errors detected in /tmp/fa-blade-1.php

$ vendor/bin/pint <touched php files> --format agent
{"tool":"pint","result":"fixed","files":[{"path":"Modules/BehaviouralAssessment/app/Services/BaIncidentService.php",...},{"path":"Modules/BehaviouralAssessment/app/Http/Requests/BaIncidentRequest.php",...}]}

$ php -l <5 touched php files>   # after Pint
No syntax errors detected in … (all five)

$ class_exists(BaIncidentController, BaIncidentService, BaWitnessService, BaIncidentAttachmentService)   # after Pint
bool(true) bool(true) bool(true) bool(true)

Item verifies:
$ grep -n "getMessage" …BaIncidentController.php
(no output, exit 1)
$ grep -n "request()" …BaIncidentController.php
(no output, exit 1)
$ grep -n "app(BaWitnessService" …BaIncidentService.php
(no output, exit 1)
$ grep -n "resolveWitnessPeople\|studentWitnesses\|staffWitnesses" …BaIncidentController.php
(no output, exit 1)
$ grep -c "self::DISPLAY_RELATIONS" …BaIncidentController.php
3
$ grep -n "resolvedBy.user" …BaIncidentController.php
58:        'resolvedBy.user',
$ grep -n "getDatabaseName" …BaWitnessService.php
65:        $cacheKey = DB::connection()->getDatabaseName().':'.$id;
$ grep -n "InterventionAdded\|WitnessStatementRecorded" …BaIncidentController.php
414:                activityLog($row, 'WitnessStatementRecorded', [
495:                    activityLog($incident, 'InterventionAdded', [
$ grep -n "BaIntervention::where" …/incident/show.blade.php
(no output, exit 1)
$ grep -n "{{-- <tr>\|private function followupLog\|private function witnessRows" …/show.blade.php …/BaIncidentController.php
BaIncidentController.php:587:    private function followupLog(BaIncident $incident): Collection
BaIncidentController.php:613:    private function witnessRows(BaIncident $incident): Collection
$ route:list --name=behavioural-assessment.incidents.restore
POST behavioural-assessment/incidents/{id}/restore behavioural-assessment.incidents.restore …@restore

# BAI-13 (2026-10-22)
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --name=behavioural-assessment.incidents.options
GET|HEAD behavioural-assessment/incidents/options behavioural-assessment.incidents.options …@options

$ php -l Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php
No syntax errors detected
$ php -l Modules/BehaviouralAssessment/app/Models/BaIncident.php
No syntax errors detected
$ php -l Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
No syntax errors detected
$ class_exists(BaIncidentController) → bool(true)

$ php -r '… compileString …' incident/create, incident/edit, incident/_create-fields,
  incident/_partials/_witness-picker, _witness-picker-scripts, _student-picker-scripts,
  pages/partials/incidents/_create-modal
BLADES-OK   (7/7 compile; @push counts match)

$ vendor/bin/pint <all changed BehaviouralAssessment php files> --format agent
{"tool":"pint","result":"passed"}
```

## 7. Final state

Status: **FIXED** · Open: B 0 · H 0 · M 0 · L 0
