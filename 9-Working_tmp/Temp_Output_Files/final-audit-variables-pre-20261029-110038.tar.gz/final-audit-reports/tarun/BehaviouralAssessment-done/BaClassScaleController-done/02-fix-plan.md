# Fix Plan — BehaviouralAssessment / BaClassScaleController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/BehaviouralAssessment/app/Http/Requests/LocksAcademicSession.php` | shared trait also used by `BaConfigRequest` and `BaAssessmentPeriodRequest`; no item here changes it |
| `Modules/BehaviouralAssessment/resources/views/**` (the setup / class-scale blades) | rendered by `BaDashboardController` and owned by that controller's audit |
| `database/migrations/tenant/**` | migrations are never edited; any trigger would be a NEW additive migration and Tarun's hand |
| `config/permissionslist.php` | shared; no new permission key is proposed |
| `Modules/BehaviouralAssessment/routes/web.php` | shared route file; route-model-binding would rename the `{id}` parameter (D3 defers it) |
| `Modules/BehaviouralAssessment/app/Support/BaActor.php`, `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | owned by `BaCommentBankController` / `BaBehaviourPointController` reports |

## 1. Blockers reachable today

None.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **BCS-01** · H · ERR-00 · `BaClassScaleController.php:7-17,35-132` — remove the forbidden `try/catch` from all three write methods, log/build the response correctly, and drop the now-unused imports.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php`
  - **Before** (`BaClassScaleController.php:7-17`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\BehaviouralAssessment\Http\Requests\BaClassScaleRequest;
    use Modules\BehaviouralAssessment\Models\BaAssessmentRating;
    use Modules\BehaviouralAssessment\Models\BaClassScaleJnt;
    use Modules\BehaviouralAssessment\Support\BaActor;
    use Modules\BehaviouralAssessment\Support\BaTriggerError;
    ```
  - **After:**
    ```php
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\BehaviouralAssessment\Http\Requests\BaClassScaleRequest;
    use Modules\BehaviouralAssessment\Models\BaAssessmentRating;
    use Modules\BehaviouralAssessment\Models\BaClassScaleJnt;
    use Modules\BehaviouralAssessment\Support\BaActor;
    ```
  - **Before** (`BaClassScaleController.php:35-132`):
    ```php
    public function store(BaClassScaleRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.create');
        $validated = $request->validated();

        if ($validated['is_active'] && $this->hasRatings((int) $validated['academic_session_id'], (int) $validated['class_id'])) {
            return back()->withInput()->with('error', 'Cannot add a scale override: ratings have already been recorded for this class in the selected session.');
        }

        try {
            return DB::transaction(function () use ($validated) {
                $record = BaClassScaleJnt::create($validated + [
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Stored', ['message' => 'Class scale override was stored.']);

                return redirect()->route('behavioural-assessment.setup', self::TAB)
                    ->with('success', 'Class scale override added.');
            });
        } catch (\Throwable $e) {
            Log::error('BaClassScaleController::store failed', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    }

    public function update(BaClassScaleRequest $request, int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.update');
        $override = BaClassScaleJnt::findOrFail($id);
        $validated = $request->validated();

        // Anything that changes which scale a class is rated on: a different scale, moving the
        // override to another session/class, or switching it on/off.
        $movesScale = (int) $validated['rating_scale_id'] !== (int) $override->rating_scale_id
            || (int) $validated['academic_session_id'] !== (int) $override->academic_session_id
            || (int) $validated['class_id'] !== (int) $override->class_id
            || (bool) $validated['is_active'] !== (bool) $override->is_active;

        if ($movesScale && (
            $this->hasRatings((int) $override->academic_session_id, (int) $override->class_id)
            || $this->hasRatings((int) $validated['academic_session_id'], (int) $validated['class_id'])
        )) {
            return back()->withInput()->with('error', 'Cannot change this override: ratings have already been recorded on its scale. Only the reason can still be edited.');
        }

        try {
            return DB::transaction(function () use ($override, $validated) {
                $override->update($validated + ['updated_by' => BaActor::id()]);

                activityLog($override, 'Updated', [
                    'message' => 'Class scale override was updated.',
                    'changes' => array_keys($override->getChanges()),
                ]);

                return redirect()->route('behavioural-assessment.setup', self::TAB)
                    ->with('success', 'Class scale override updated.');
            });
        } catch (\Throwable $e) {
            Log::error('BaClassScaleController::update failed', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->withInput()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    }

    public function destroy(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.delete');

        try {
            return DB::transaction(function () use ($id) {
                $override = BaClassScaleJnt::findOrFail($id);

                if ($override->is_active && $this->hasRatings((int) $override->academic_session_id, (int) $override->class_id)) {
                    return back()->with('error', 'Cannot remove this override: ratings have already been recorded on its scale.');
                }

                $override->is_active = false;
                $override->updated_by = BaActor::id();
                $override->save();
                $override->delete();

                activityLog($override, 'Trashed', ['message' => 'Class scale override was removed.']);

                return redirect()->route('behavioural-assessment.setup', self::TAB)
                    ->with('success', 'Class scale override removed.');
            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaClassScaleController::destroy failed', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function store(BaClassScaleRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.create');
        $validated = $request->validated();

        if ($validated['is_active'] && $this->hasRatings((int) $validated['academic_session_id'], (int) $validated['class_id'])) {
            return back()->withInput()->with('error', 'Cannot add a scale override: ratings have already been recorded for this class in the selected session.');
        }

        DB::transaction(function () use ($validated) {
            $record = BaClassScaleJnt::create($validated + [
                'created_by' => BaActor::id(),
                'updated_by' => BaActor::id(),
            ]);

            activityLog($record, 'Stored', ['message' => 'Class scale override was stored.']);
        });

        return redirect()->route('behavioural-assessment.setup', self::TAB)
            ->with('success', 'Class scale override added.');
    }

    public function update(BaClassScaleRequest $request, int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.update');
        $override = BaClassScaleJnt::findOrFail($id);
        $validated = $request->validated();

        // Anything that changes which scale a class is rated on: a different scale, moving the
        // override to another session/class, or switching it on/off.
        $movesScale = (int) $validated['rating_scale_id'] !== (int) $override->rating_scale_id
            || (int) $validated['academic_session_id'] !== (int) $override->academic_session_id
            || (int) $validated['class_id'] !== (int) $override->class_id
            || (bool) $validated['is_active'] !== (bool) $override->is_active;

        if ($movesScale && (
            $this->hasRatings((int) $override->academic_session_id, (int) $override->class_id)
            || $this->hasRatings((int) $validated['academic_session_id'], (int) $validated['class_id'])
        )) {
            return back()->withInput()->with('error', 'Cannot change this override: ratings have already been recorded on its scale. Only the reason can still be edited.');
        }

        DB::transaction(function () use ($override, $validated) {
            $override->update($validated + ['updated_by' => BaActor::id()]);

            activityLog($override, 'Updated', [
                'message' => 'Class scale override was updated.',
                'changes' => array_keys($override->getChanges()),
            ]);
        });

        return redirect()->route('behavioural-assessment.setup', self::TAB)
            ->with('success', 'Class scale override updated.');
    }

    public function destroy(int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.configs.delete');
        $override = BaClassScaleJnt::findOrFail($id);

        if ($override->is_active && $this->hasRatings((int) $override->academic_session_id, (int) $override->class_id)) {
            return back()->with('error', 'Cannot remove this override: ratings have already been recorded on its scale.');
        }

        DB::transaction(function () use ($override) {
            $override->is_active = false;
            $override->updated_by = BaActor::id();
            $override->save();
            $override->delete();

            activityLog($override, 'Trashed', ['message' => 'Class scale override was removed.']);
        });

        return redirect()->route('behavioural-assessment.setup', self::TAB)
            ->with('success', 'Class scale override removed.');
    }
    ```
  - **Verify:** `grep -n "try {\|catch (\|Log::error\|BaTriggerError" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **BCS-03** · L · AUTH-04 · `BaClassScaleController.php:37-38,65-66` — drop the two `Gate::authorize` calls that duplicate the FormRequest's `authorize()`. Apply after BCS-01.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php`
  - **Before** (`BaClassScaleController.php:37-38`):
    ```php
    Gate::authorize('tenant.behavioural-assessment.configs.create');
    $validated = $request->validated();
    ```
  - **After:**
    ```php
    $validated = $request->validated();
    ```
  - **Before** (`BaClassScaleController.php:65-66`):
    ```php
    Gate::authorize('tenant.behavioural-assessment.configs.update');
    $override = BaClassScaleJnt::findOrFail($id);
    ```
  - **After:**
    ```php
    $override = BaClassScaleJnt::findOrFail($id);
    ```
  - **Verify:** `grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php`
  - **Expect:** one line only — `Gate::authorize('tenant.behavioural-assessment.configs.delete');` inside `destroy`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

None.

## 6. Queries & performance (F9)

None.

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **BCS-07** · L · STY-02 · `BaClassScaleRequest.php:7-9,51` — import `BaClassScaleJnt` so Pint's `fully_qualified_strict_types` fixer passes.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php`
  - **Before** (`BaClassScaleRequest.php:7-9`):
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    ```
  - **After:**
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Modules\BehaviouralAssessment\Models\BaClassScaleJnt;
    ```
  - **Before** (`BaClassScaleRequest.php:51`):
    ```php
    $this->lockAcademicSession(\Modules\BehaviouralAssessment\Models\BaClassScaleJnt::class, $this->route('id'));
    ```
  - **After:**
    ```php
    $this->lockAcademicSession(BaClassScaleJnt::class, $this->route('id'));
    ```
  - **Verify:** `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}` with no file listed.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BCS-02** · M · DECISION · TXN-06 — the "scale in use" guard reads before the write with no lock; a concurrent rating insert can move a class's scale underneath ratings.
  - **Why it is a decision:** the complete fix is a data-integrity policy, not a mechanical edit — a guaranteed closure needs a ratings-side DB trigger (a new migration, Tarun's hand), and there is a real trade-off between accepting the narrow window and adding a constraint.
  - (a) ⭐ **Accept and document** — add one code comment above `hasRatings()` noting the guard is best-effort (single-admin config screen; no DB constraint by design) and take no code change. Cost: the race remains, sub-second, admin vs teacher.
  - (b) **Harden in place** — inside the write's transaction, re-check `hasRatings()` and take `lockForUpdate()` on the override row for `update`/`destroy`; this narrows but does not close the `store` window (there is no row to lock before the insert). Cost: an extra query per write.
  - (c) **Add a ratings-side trigger** — a new additive migration on `ba_assessment_ratings` that rejects an insert when a scale-moving override for that class/session is in flight; only this closes the hole. Cost: a migration Tarun must run.
  - ➜ Choice: ____

- [ ] **BCS-05** · M · DECISION · VAL-07 — the "class already rated may not change scale" rule is hand-written in the controller instead of `BaClassScaleRequest::after()`.
  - **Why it is a decision:** moving it into the FormRequest turns a page-level red flash into a 422 inline field error — a visible behaviour change.
  - (a) ⭐ **Defer** — leave the guard and its flash as they are; revisit when the controller/service split lands. Cost: the rule still lives only in this controller.
  - (b) **Move it into `BaClassScaleRequest::after()`** — the rule runs as validation and returns a 422 message on `class_id`; the controller's three inline branches and the private helper are deleted. Cost: an inline validation error replaces the flash for an already-rated class.
  - (c) **Extract a service** — move the guard into a `BaClassScaleService` shared by controller and any future API. Cost: a new class; more than this screen needs today.
  - ➜ Choice: ____

- [ ] **BCS-06** · M · DECISION · CTL-03 — `update`/`destroy` resolve the model with `int $id` + `findOrFail` instead of route model binding.
  - **Why it is a decision:** implicit binding needs either a route-parameter rename (`{id}` → `{classScale}`) in `routes/web.php` — a shared route file, which D3 keeps out of this pass — or an argument typed `BaClassScaleJnt $id`, which reads badly.
  - (a) ⭐ **Defer to the D3 refactor pass** — leave `int $id` + `findOrFail`; binding is style here and the 404 behaviour is already correct.
  - (b) **Rename the route parameter and bind now** — edit `routes/web.php` (⚠ SHARED) and type the arguments `BaClassScaleJnt $classScale`. Cost: a shared-file change needing its own tick.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BCS-04 | AUTH-06 — the permission strings are repeated as literals across the whole BehaviouralAssessment module (controller, FormRequest and blades); a Policy/constants pass is module-wide and deferred, not a single-file edit. |
