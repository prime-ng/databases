# Final Audit — BehaviouralAssessment / BaClassScaleController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php` (142 lines, 3 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/behavioural-assessment/setup?tab=configuration` (the panel); `POST /behavioural-assessment/class-scales`, `PUT /behavioural-assessment/class-scales/{id}`, `DELETE /behavioural-assessment/class-scales/{id}` (the writes) |
| Menu path | Behavioural Assessment → Setup → Configuration tab → "Per-class scale overrides" panel |
| Who uses it | `School Admin` and `Super Admin` — the only two roles holding `tenant.behavioural-assessment.configs.*` (measured: 7 configs permissions × 2 roles = 14 rows in `sys_role_has_permissions_jnt`) |
| What a user does here | An admin gives one class its own rating scale for the current academic session, overriding the session's configured scale. The admin opens a dialog, picks a class and a rating scale, types an optional reason, and saves; rows can be edited or removed. Once any rating has been recorded for that class in that session the scale is frozen, and the screen refuses to move or remove it. |
| Tables written | `ba_class_scale_jnt` (create / update / soft-delete) and `sys_activity_logs` (one row per write, via the `activityLog()` helper) |
| Tables read | `ba_class_scale_jnt`, `ba_assessment_ratings` → `ba_assessments` → `ba_assessment_periods` and `sch_class_sections` (the "has ratings?" guard) |
| Live data | On tenant `00000000-0000-4000-8000-000000000001` (db `xyz_school_00000000000040008000_202627`): `ba_class_scale_jnt` 0 live, 0 trashed; `ba_assessment_ratings` 21996 live, 0 trashed |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **close to production-ready**: it validates through a FormRequest, authorizes on every route, runs every multi-table write inside one `DB::transaction`, keeps `activityLog()` inside and after the write, and its `whereHas` guard resolves correctly. Its single worst problem is **BCS-01**: all three write methods wrap the transaction in a `try/catch (\Throwable)` that the binding D1 decision forbids, logs the exception message instead of the exception (ERR-05), and whose friendly-message branch is dead code because `ba_class_scale_jnt` has **no** BA trigger. The remaining items are one non-atomic check-then-act (BCS-02), a duplicated authorization check (BCS-03), an ad-hoc business rule that belongs in the FormRequest (BCS-05), route-model-binding style (BCS-06, deferred by D3), and one Pint fix (BCS-07). Effort: **S–M (~2 hours)** once Tarun ticks the items.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 4 | 2 | 3 | 7 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BCS-01 | F8 Services/Jobs | clean — no service/job reaches this controller |
| F2 Transactions/Audit | BCS-02 | F9 Queries/Perf | clean — single `exists()`, `whereHas` depth 2 |
| F3 Authorization | BCS-03, BCS-04 | F10 Views | clean — controller renders no views |
| F4 Validation | BCS-05 | F11 Security/Tenancy | clean |
| F5 Routes | clean — 3 routes, 3 methods, all bound | F12 Style | BCS-07 |
| F6 Controller shape | BCS-06 | F13 Deep read | see the F13 table |
| F7 Models | clean — casts, fillable, relations proven | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php` | controller | 142 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php` | FormRequest | 65 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Http/Requests/LocksAcademicSession.php` | trait (used by the FormRequest; also by BaConfigRequest, BaAssessmentPeriodRequest) | 32 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Models/BaClassScaleJnt.php` | model (`ba_class_scale_jnt`) | 57 | this report | ✅ |
| 5 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentRating.php` | model (`ba_assessment_ratings`) | 67 | this report (first reacher) | ✅ |
| 6 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | 45 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 7 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support | 37 | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |

No pre-applied files: no `Modules/BehaviouralAssessment/**` file appears in a `PRE-APPLIED-*.md`.

## 4. Routes

```
POST    behavioural-assessment/class-scales        behavioural-assessment.class-scales.store     Modules\BehaviouralAssessment\Http\Controllers\BaClassScaleController@store
PUT     behavioural-assessment/class-scales/{id}   behavioural-assessment.class-scales.update    Modules\BehaviouralAssessment\Http\Controllers\BaClassScaleController@update
DELETE  behavioural-assessment/class-scales/{id}   behavioural-assessment.class-scales.destroy   Modules\BehaviouralAssessment\Http\Controllers\BaClassScaleController@destroy
```

Unrouted public methods: none — the three public methods are exactly the three routes above. The only private method is `hasRatings()`.

Tenant middleware: the module's `RouteServiceProvider::map()` wraps the group in `['web', InitializeTenancyByDomain, PreventAccessFromCentralDomains, EnsureTenantIsActive, EnsureTenantHasModule:BehaviouralAssessment, 'auth', 'verified']` with prefix `behavioural-assessment` and name `behavioural-assessment.` (verified in `Modules/BehaviouralAssessment/app/Providers/RouteServiceProvider.php:25-36`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `store` | 35 | POST `behavioural-assessment/class-scales` | `tenant.behavioural-assessment.configs.create` (controller) + same via FormRequest | controller `DB::transaction` (45) | `'Stored'` | `ba_class_scale_jnt`, `sys_activity_logs` | BCS-01 |
| `update` | 63 | PUT `behavioural-assessment/class-scales/{id}` | `tenant.behavioural-assessment.configs.update` (controller) + same via FormRequest | controller `DB::transaction` (84) | `'Updated'` | `ba_class_scale_jnt`, `sys_activity_logs` | BCS-01, BCS-02, BCS-03, BCS-06 |
| `destroy` | 102 | DELETE `behavioural-assessment/class-scales/{id}` | `tenant.behavioural-assessment.configs.delete` (controller) | controller `DB::transaction` (107) | `'Trashed'` | `ba_class_scale_jnt`, `sys_activity_logs` | BCS-01, BCS-02, BCS-06 |

## 6. Findings

### F1 — Errors

#### BCS-01 · H · ERR-00 — every write method wraps its transaction in a `try/catch` (D1 forbids it), and the catch logs the message, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-00 (H, raised from the rulebook's undecided default because D1 settled it: *no `try/catch` in controllers; the central handler in `bootstrap/app.php` renders errors*). Co-cited: ERR-05 (M) — *log the exception, not the message*; TXN-05 (M) — *the transaction closure returns data; build `redirect()` after it*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:44-60` (`store`), `:83-99` (`update`), `:106-131` (`destroy`) |
| **Root cause** | All three mutating methods use `try { return DB::transaction(closure) } catch (\Throwable $e) { Log::error('…', ['error' => $e->getMessage()]); return back()->with('error', BaTriggerError::message($e) ?? '…'); }`. D1 makes a controller `try/catch` a finding; no D2 shape applies (no `\DomainException`, no truncate-then-rebuild, no `SnapshotProtectionException`). The catch also (a) logs only `getMessage()`, losing the stack trace (ERR-05), and (b) its friendly-message branch calls `BaTriggerError::message($e)`, which only returns text for a `SQLSTATE 45000` error containing `BA: `. `ba_class_scale_jnt` has **zero** triggers, so that branch can never fire and the user always sees the generic fallback. The transaction closure also builds the `redirect()` before commit (TXN-05). |
| **Consequence** | A genuine failure on this write path (DB down, deadlock) is swallowed into a red "The operation could not be completed." flash and bypasses the friendly 500 page; the log line carries no trace, so the failure cannot be diagnosed from the log alone. |
| **Reproduce** | static only — the catch needs an infrastructure failure (DB error/deadlock) that cannot be triggered from the browser. The D1 violation itself is visible in the source at the three line ranges above. |
| **Fix approach** | Remove the `try/catch` from all three methods and let the central handler render; run the `DB::transaction(closure)` for its side effect and build the `redirect()` after it. Drop the now-unused imports `ModelNotFoundException`, `Log` and `BaTriggerError`. |
| **Plan item** | BCS-01 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n "try {\|catch (\|Log::error\|return redirect()" <controller>` and `grep -c "ba_class_scale_jnt" <triggers migration>` |

Quoted current lines (`store`, `BaClassScaleController.php:44-60`):

```php
try {
    return DB::transaction(function () use ($validated) {
        $record = BaClassScaleJnt::create($validated + [
            'created_by' => BaActor::id(),
            'updated_by' => BaActor::id(),
        ]);

        activityLog($record, 'Stored', ['message' => 'Class scale override was stored.']);

        return redirect()->route('behavioural-assessment.setup', self::TAB)
            ->with('success', 'Class scale override added.');
    });
} catch (\Throwable $e) {
    Log::error('BaClassScaleController::store failed', ['error' => $e->getMessage()]);

    return back()->withInput()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
}
```

**Evidence**

```
$ grep -n "try {\|catch (\|Log::error\|return redirect()" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php
44:        try {
53:                return redirect()->route('behavioural-assessment.setup', self::TAB)
56:        } catch (\Throwable $e) {
57:            Log::error('BaClassScaleController::store failed', ['error' => $e->getMessage()]);
83:        try {
92:                return redirect()->route('behavioural-assessment.setup', self::TAB)
95:        } catch (\Throwable $e) {
96:            Log::error('BaClassScaleController::update failed', ['id' => $id, 'error' => $e->getMessage()]);
106:        try {
121:                return redirect()->route('behavioural-assessment.setup', self::TAB)
124:        } catch (ModelNotFoundException $e) {
127:        } catch (\Throwable $e) {
128:            Log::error('BaClassScaleController::destroy failed', ['id' => $id, 'error' => $e->getMessage()]);

$ grep -c "ba_class_scale_jnt" database/migrations/tenant/2026_06_16_130643_create_ba_triggers.php
0
```

### F2 — Transactions and audit

#### BCS-02 · M · TXN-06 — the "scale in use" guard is a check-then-act with no lock

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M, lowered from the rulebook's H — single-admin configuration screen, a sub-second window, and the table deliberately has no DB constraint, so the guard is best-effort by design and the fix is a policy choice). |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:40-42` (`store`), `:76-81` (`update`) |
| **Root cause** | The guard `hasRatings(...)` runs a read (`exists()`) **before** the write's transaction, and the write takes no lock on anything the guard looked at. A teacher inserting a `ba_assessment_ratings` row for that class in that session at the same moment is not blocked, so the override can still be created/moved while ratings exist — exactly the state the guard exists to prevent. |
| **Consequence** | In a rare concurrent write, a class's scale can move underneath ratings that were given on the old scale, so those ratings are later banded/graded against a scale they were not recorded on. |
| **Reproduce** | static only — requires two simultaneous requests (an admin saving this form while a teacher saves ratings); not reproducible from a single browser session. |
| **Fix approach** | Decide the policy: accept and document, harden the window, or add a ratings-side DB trigger. Options are in the plan item. |
| **Plan item** | BCS-02 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `grep -n "hasRatings\|DB::transaction" <controller>` |

Quoted current lines (`store`, `BaClassScaleController.php:40-42`):

```php
if ($validated['is_active'] && $this->hasRatings((int) $validated['academic_session_id'], (int) $validated['class_id'])) {
    return back()->withInput()->with('error', 'Cannot add a scale override: ratings have already been recorded for this class in the selected session.');
}
```

**Evidence**

```
$ grep -n "hasRatings\|DB::transaction" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php
40:        if ($validated['is_active'] && $this->hasRatings((int) $validated['academic_session_id'], (int) $validated['class_id'])) {
45:            return DB::transaction(function () use ($validated) {
77:            $this->hasRatings((int) $override->academic_session_id, (int) $override->class_id)
78:            || $this->hasRatings((int) $validated['academic_session_id'], (int) $validated['class_id'])
84:            return DB::transaction(function () use ($override, $validated) {
107:            return DB::transaction(function () use ($id) {
110:                if ($override->is_active && $this->hasRatings((int) $override->academic_session_id, (int) $override->class_id)) {
```

### F3 — Authorization

#### BCS-03 · L · AUTH-04 — the same permission is authorized twice on store and update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php:22-25` and `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:37` and `:65` |
| **Root cause** | The FormRequest's `authorize()` calls `authorizeByCrudPermission('tenant.behavioural-assessment.configs')`, which maps POST → `configs.create` and PUT → `configs.update`. The controller then calls `Gate::authorize('tenant.behavioural-assessment.configs.create' / '…update')` for the same verbs — two checks, one concern. |
| **Consequence** | No user-visible effect; it is duplicated logic that can drift (one surface changed, the other forgotten), and it makes the permission harder to grep as a single source. |
| **Reproduce** | static only — both checks pass or fail together today. |
| **Fix approach** | Keep the FormRequest check and remove the two redundant `Gate::authorize` lines in `store`/`update`. `destroy` has no FormRequest and keeps its `Gate::authorize`. |
| **Plan item** | BCS-03 in `02-fix-plan.md` §4 |
| **Evidence** | `grep -n "Gate::authorize\|authorizeByCrudPermission" <controller> <request>` |

```php
public function authorize(): bool
{
    return $this->authorizeByCrudPermission('tenant.behavioural-assessment.configs');
}
```

**Evidence**

```
$ grep -n "Gate::authorize\|authorizeByCrudPermission" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php
Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:37:        Gate::authorize('tenant.behavioural-assessment.configs.create');
Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:65:        Gate::authorize('tenant.behavioural-assessment.configs.update');
Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:104:        Gate::authorize('tenant.behavioural-assessment.configs.delete');
Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php:24:        return $this->authorizeByCrudPermission('tenant.behavioural-assessment.configs');
```

#### BCS-04 · M · AUTH-06 — permission strings are repeated as literals

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy, or constants — not repeated as literals in every method*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:37` (also `:65`, `:104`) and `Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php:24` |
| **Root cause** | The base string `tenant.behavioural-assessment.configs` and its three verbs are written out four times in two PHP files (and again in the blades). Nothing binds them, so a rename is a search-and-replace across many files. |
| **Consequence** | No current user-visible effect. It is maintenance risk: one surface can be renamed while another is missed, producing a silently un-guarded or always-denied action. |
| **Reproduce** | static only — the strings are consistent today. |
| **Fix approach** | A module-wide permission-constant / Policy pass. Not fixed per-controller here. |
| **Plan item** | none — see plan §10 (BCS-04) |
| **Evidence** | `grep -rn "tenant.behavioural-assessment.configs" Modules/BehaviouralAssessment/app/Http` |

```php
Gate::authorize('tenant.behavioural-assessment.configs.create');
```

**Evidence**

```
$ grep -rn "tenant.behavioural-assessment.configs" Modules/BehaviouralAssessment/app/Http
Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:37:        Gate::authorize('tenant.behavioural-assessment.configs.create');
Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:65:        Gate::authorize('tenant.behavioural-assessment.configs.update');
Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:104:        Gate::authorize('tenant.behavioural-assessment.configs.delete');
Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php:24:        return $this->authorizeByCrudPermission('tenant.behavioural-assessment.configs');
```

### F4 — Validation and input

#### BCS-05 · M · VAL-07 — the "scale in use" business rule is hand-written in the controller, not in the FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M) — *cross-field / business checks go in the Form Request's `after()` hook, not hand-written in the controller*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:134-141` (`hasRatings`), called at `:40`, `:76-78`, `:110` |
| **Root cause** | The rule "a class already rated in this session may not change scale" is implemented as a private controller method plus three inline `if` branches, returning `back()->with('error', …)`. It is business validation with no other home, so it cannot be reused by a service/command and it returns a flash instead of a validation error. |
| **Consequence** | The same rule cannot be enforced when the override is changed by any path other than this controller (a console command, a future API), and the user sees a page-level red flash rather than an inline field message. |
| **Reproduce** | Open `/behavioural-assessment/setup?tab=configuration`, add an override for a class that already has ratings in the current session, and save. Expected: field-level message; actual: red flash at the top of the page. |
| **Fix approach** | Move the rule into `BaClassScaleRequest::after()` (with `hasRatings` as a private helper there), which returns a 422 field error. A behaviour change, so it is a DECISION. |
| **Plan item** | BCS-05 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `grep -n "hasRatings" <controller>` |

```php
private function hasRatings(int $sessionId, int $classId): bool
{
    return BaAssessmentRating::whereHas('assessment', fn ($q) => $q
        ->whereHas('period', fn ($p) => $p->where('academic_session_id', $sessionId))
        ->whereHas('classSection', fn ($c) => $c->where('class_id', $classId)))
        ->exists();
}
```

**Evidence**

```
$ grep -n "hasRatings" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php
40:        if ($validated['is_active'] && $this->hasRatings((int) $validated['academic_session_id'], (int) $validated['class_id'])) {
77:            $this->hasRatings((int) $override->academic_session_id, (int) $override->class_id)
78:            || $this->hasRatings((int) $validated['academic_session_id'], (int) $validated['class_id'])
110:                if ($override->is_active && $this->hasRatings((int) $override->academic_session_id, (int) $override->class_id)) {
135:    private function hasRatings(int $sessionId, int $classId): bool
```

Clean sub-checks in this family: `validated()` is used (no `all()`), every field is typed, no uploads, and the `class_id` uniqueness rule mirrors the DB index — `uq_ba_class_scale (academic_session_id, class_id, uq_guard)` with `uq_guard = IFNULL(deleted_at,'1970-01-01')` plus the rule's `->whereNull('deleted_at')` are consistent (proof: `sed -n '32,34p' database/migrations/tenant/2026_06_16_130629_create_ba_class_scale_jnt_table.php`).

### F5 — Routes

clean — `route:list` (uncached) shows three routes (`class-scales.store`, `.update`, `.destroy`) and every route points at an existing public method; no GET mutates state; the tenant middleware group is present in `RouteServiceProvider::map()`. Evidence:

```
$ php -r '...route list filter for BaClassScaleController...'
POST    behavioural-assessment/class-scales        behavioural-assessment.class-scales.store     ...@store
PUT     behavioural-assessment/class-scales/{id}   behavioural-assessment.class-scales.update    ...@update
DELETE  behavioural-assessment/class-scales/{id}   behavioural-assessment.class-scales.destroy   ...@destroy
```

### F6 — Controller shape

#### BCS-06 · M · CTL-03 — `update`/`destroy` take `int $id` + `findOrFail` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php:63-66` (`update`), `:102-108` (`destroy`) |
| **Root cause** | The routes declare `{id}`, and both methods accept a raw `int $id` and resolve the model with `findOrFail`. |
| **Consequence** | No user-visible bug today. It is style/consistency: manual resolution duplicates the 404 behaviour and forces a class-string lookup in `LocksAcademicSession` too. |
| **Reproduce** | static only. |
| **Fix approach** | Route model binding requires either a route-parameter rename (`{classScale}`) — a route-file edit, which D3 says is out of scope for this pass — or an argument typed `BaClassScaleJnt $id`, which reads badly. Recommend deferring to the D3 refactor pass. |
| **Plan item** | BCS-06 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `grep -n "findOrFail\|int \$id" <controller>` |

```php
public function update(BaClassScaleRequest $request, int $id): RedirectResponse
{
    Gate::authorize('tenant.behavioural-assessment.configs.update');
    $override = BaClassScaleJnt::findOrFail($id);
```

**Evidence**

```
$ grep -n "findOrFail\|int \$id" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php
63:    public function update(BaClassScaleRequest $request, int $id): RedirectResponse
66:        $override = BaClassScaleJnt::findOrFail($id);
102:    public function destroy(int $id): RedirectResponse
108:                $override = BaClassScaleJnt::findOrFail($id);
```

Clean sub-checks in this family: the controller is 142 lines / 3 public methods (well under the CTL-01 thresholds); all three methods carry `: RedirectResponse` return types; no `request()` helper, no `extract()`, no `compact()`; no `dd()`/`dump()`; no dead code. The near-identical catch blocks are handled by BCS-01.

### F7 — Models

clean — for `BaClassScaleJnt` and `BaAssessmentRating`: `$fillable` declared (generated `uq_guard` correctly omitted), `$casts` cover every boolean/date/decimal column, `SoftDeletes` matches the real `deleted_at` column, and every relationship is return-typed and resolves. Proof (tinker, tenant `00000000-0000-4000-8000-000000000001`):

```
BaClassScaleJnt::academicSession -> Modules\SchoolSetup\Models\OrganizationAcademicSession
BaClassScaleJnt::schoolClass -> Modules\SchoolSetup\Models\SchoolClass
BaClassScaleJnt::ratingScale -> Modules\BehaviouralAssessment\Models\BaRatingScale
BaAssessmentRating::assessment -> Modules\BehaviouralAssessment\Models\BaAssessment
BaAssessmentRating::criterion -> Modules\BehaviouralAssessment\Models\BaCriterion
BaAssessmentRating::ratingLevel -> Modules\BehaviouralAssessment\Models\BaRatingLevel
BaAssessmentRating::student -> Modules\StudentProfile\Models\Student
```

### F8 — Services and jobs

clean — this controller calls no Service, Job, Event, Mail or Notification. Evidence: `grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b' Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php` prints nothing.

### F9 — Queries and performance

clean — `hasRatings()` is one `exists()` query (no `->get()`, no loop); the `whereHas` chain is 2 levels deep (`assessment` → `period`/`classSection`), under the QRY-09 threshold of 3+; there is no list and so no pagination concern. Evidence: `grep -n "hasRatings\|exists()" <controller>` shows only the single `->exists()` at line 140, and the tinker call `BaAssessmentRating::whereHas(...)->exists()` returned `false` without error.

### F10 — Views

clean — this controller renders no views; all three methods return `RedirectResponse`. Evidence: `grep -oE "view\(['\"][^'\"]+" Modules/BehaviouralAssessment/app/Http/Controllers/BaClassScaleController.php` prints nothing. The dialogs that post to these routes (`_class-scale-modals.blade.php`, `_configuration.blade.php`, `class-scale/_fields.blade.php`) are rendered by `BaDashboardController::setup()` and belong to that controller's audit.

### F11 — Security and tenancy

clean — no `env()`, no hard-coded ids or `?? 1`, no personal data in JSON, no request/token logging (`Log::error` only carries an id and the message), no cache. The `BaActor::systemId()` fallback lives in the linked `BaActor` class, not here. Evidence: `grep -nE "env\(|->all\(\)|Log::(info|debug)" <controller>` prints nothing.

### F12 — Style

#### BCS-07 · L · STY-02 — the FormRequest is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php:51` |
| **Root cause** | The trait call uses the fully-qualified class name inline (`\Modules\BehaviouralAssessment\Models\BaClassScaleJnt::class`) instead of importing it, so Pint's `fully_qualified_strict_types` fixer rewrites the file. |
| **Consequence** | No user-visible effect; it fails a `pint --test` gate and is a noise diff for the next editor. |
| **Reproduce** | Run `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php` — it reports `fail`. |
| **Fix approach** | Add `use Modules\BehaviouralAssessment\Models\BaClassScaleJnt;` and call `BaClassScaleJnt::class`. |
| **Plan item** | BCS-07 in `02-fix-plan.md` §8 |
| **Evidence** | `vendor/bin/pint --test …` and the diff from `pint --preset laravel` on a copy |

```php
$this->lockAcademicSession(\Modules\BehaviouralAssessment\Models\BaClassScaleJnt::class, $this->route('id'));
```

**Evidence**

```
$ vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php
{"tool":"pint","result":"fail","files":[{"path":"Modules/BehaviouralAssessment/app/Http/Requests/BaClassScaleRequest.php","fixers":["fully_qualified_strict_types"]}]}
```

Informational (no ID): STY-07 (user-facing strings hard-coded rather than via `__()` keys) is present here, as it is module-wide; accepted, not planned.

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong overwrite | 2 Delete-before-store | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Lying message | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | BCS-05 | ok | BCS-02 | ok | ok | ok |
| `update` | ok | ok | BCS-05 | ok | BCS-02 | BCS-03 | ok | ok |
| `destroy` | ok | ok | BCS-05 | ok | BCS-02 | ok | ok | ok |

Notes. (1) `update` writes only via `$validated + ['updated_by' => …]`; every key is validated/fillable, so no column is silently reset. (3) `hasRatings` is one shared helper (no duplicate implementation), but the rule it expresses is duplicated across three inline branches — BCS-05. (4) `destroy` soft-deletes; re-creating the same (session, class) is allowed because the DB index includes the generated `uq_guard = IFNULL(deleted_at,'1970-01-01')`, and the FormRequest rule uses `->whereNull('deleted_at')` — the two agree. (5) BCS-02. (8) The override is read by `BaAssessmentService::ratingScaleIdFor()`, `BehaviouralScoreService::resolveScale()` and `BaFrameworkSnapshotService::buildLive()`, all filtering `is_active = true`; the controller's active/inactive handling matches those consumers, so the feature is live.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` (owner: BaBehaviourPointController) | `message()` only maps a `QueryException` whose SQLSTATE is `45000` and text contains `BA: `. `ba_class_scale_jnt` has no trigger, so the call in this controller's catches can never return text — the argument is dead here. | — (informational) | the report that owns `BaTriggerError` |
| `Modules/BehaviouralAssessment/resources/views/pages/partials/setup/_class-scale-modals.blade.php`, `_configuration.blade.php`, `class-scale/_fields.blade.php` | These are the UI for these routes, but they are rendered by `BaDashboardController::setup()` (it supplies `$classScales`, `$configRatingScales`, `$classes`, `$academicSessions`); `_fields.blade.php` documents a `$scales` param while the include passes `'scales' => …` and reads `$scales` — worth a check in the `BaDashboardController` audit. | VIEW | the `BaDashboardController` audit |

## 8. Not covered, and why

- **Views**: this controller renders none (all three methods redirect); the blades that post here are audited under `BaDashboardController`.
- **`BaAssessment` and `BaAssessmentPeriod`**: reached only through the string relations in `hasRatings` (`whereHas('assessment')` → `whereHas('period')` / `whereHas('classSection')`). This controller does not import or name them, so they are not in its scope; I read them to confirm the chain resolves (`period.academic_session_id`, `classSection.class_id` exist) and leave their full audit to their owning reports.
- **`schoolClass`/`academicSession` relation targets** (`SchoolClass`, `OrganizationAcademicSession`): other-module models, common (§4.2).
- **Runtime behaviour**: per D4 no tests were run; every finding is source- or tinker-verified only.
- **The live DB row counts** are from the single tenant `00000000-0000-4000-8000-000000000001`; other tenants were not queried.
