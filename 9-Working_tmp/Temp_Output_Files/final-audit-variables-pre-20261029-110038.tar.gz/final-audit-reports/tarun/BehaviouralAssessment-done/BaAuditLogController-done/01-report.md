# Final Audit — BehaviouralAssessment / BaAuditLogController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php` (188 lines, 1 routed method + 2 unrouted public static helpers)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/behavioural-assessment/audit-log` (route name `behavioural-assessment.audit-log.index`) |
| Menu path | Reports → Audit Trail tab. The standalone page is registered in the breadcrumb registry as `behavioural-assessment.audit-log.index` with parent `behavioural-assessment.reports-page` and tab `audit-trail` (`app/Services/Breadcrumbs/registry.php:846`). |
| Who uses it | Roles holding `tenant.behavioural-assessment.audit-log.viewAny` — on the test tenant that is **Super Admin (role id 1)** and **School Admin (role id 2)**. |
| What a user does here | Reads the read-only behavioural-assessment audit trail. The user filters by period, by entity type, and by changed-field text, then pages through a table showing when each change happened, which record and field changed, the old and new value, the reason, who changed it, and the source IP/user agent. There is no create, edit or delete on this screen. |
| Tables written | none (read-only controller). |
| Tables read | `ba_audit_log`, `ba_assessment_periods`, `ba_incident_intervention_jnt`, `ba_incidents`, `ba_interventions`, `ba_incident_witnesses_jnt`, `ba_assessments`, `ba_assessment_ratings`, `sys_users`. |
| Live data | Tenant `00000000-0000-4000-8000-000000000001` (domain `test.localhost`): `ba_audit_log` **0 rows** (the table is immutable — no `deleted_at`); `ba_assessment_periods` **4 live, 0 trashed**; `sys_users` 5630. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is small, read-only, and broadly well built: it authorizes before it loads anything, paginates at 10, eager-loads every relation it renders, and has no write path at all — so there are no transaction, error-handling or tenancy risks. It is **production-ready after the medium items**. The single worst finding is **BAAL-02**: the changed-field filter runs a leading-wildcard `LIKE '%text%'` and a full-table `SELECT DISTINCT field_name` against `ba_audit_log` on every page load, even though `field_name` carries no index — on a live tenant the audit trail only grows, so this screen gets slower the longer the school uses the module. The remaining findings are a style item and two sizing/placement decisions. Rough effort to work the plan: **S (about one hour, one of it a migration decision for Tarun)**.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 2 | 3 | 3 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | BAAL-02, BAAL-05 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | BAAL-04 | F12 Style | clean |
| F6 Controller shape | BAAL-01, BAAL-03 | F13 Deep read | no mutations (table below) |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php` | controller | 188 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` | model (table `ba_audit_log`) | 203 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentPeriod.php` | model (table `ba_assessment_periods`) | 145 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/resources/views/audit-log/index.blade.php` | view | 145 | this report | ✅ |
| 5 | `Modules/BehaviouralAssessment/routes/web.php` | route file (shared) | — | shared | ❌ route resolution only, see §4 |
| 6 | `Modules/BehaviouralAssessment/app/Models/BaAssessment.php` | model reached as a relation string | — | other report | ❌ reached only via `EAGER`/relations, see §8 |
| 7 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentRating.php` | model reached as a relation string | — | other report | ❌ reached only via `EAGER`/relations, see §8 |
| 8 | `Modules/BehaviouralAssessment/app/Models/BaIncident.php` | model reached as a relation string | — | other report | ❌ reached only via `EAGER`/relations, see §8 |
| 9 | `Modules/SchoolSetup/app/Models/User.php` | model (common, other module) | — | common | ❌ §4.2 common class, see §7 |

No pre-applied files (`PRE-APPLIED-2026-10-10.md`) apply to this controller. No FormRequest, policy, service, job, event, mail or notification is named by this controller.

The view walk stops at `audit-log/index.blade.php`: its only includes are the shared components `<x-backend.layouts.app>` and `<x-backend.components.breadcrum>` (common, §4.2). The Reports-page partial `resources/views/pages/partials/reports/_audit-trail.blade.php` also calls `BaAuditLogController::describe()`, but it is part of the Reports page, not of this view, so it is recorded as a cross-cutting note in §7.

## 4. Routes

```
GET|HEAD  behavioural-assessment/audit-log   behavioural-assessment.audit-log.index   Modules\BehaviouralAssessment\Http\Controllers\BaAuditLogController@index
```

Middleware on the route (from the uncached `route:list`): `web`, `Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains`, `Stancl\Tenancy\Middleware\InitializeTenancyByDomain`, `App\Http\Middleware\EnsureTenantIsActive`, `App\Http\Middleware\EnsureTenantHasModule:BehaviouralAssessment`, `Illuminate\Auth\Middleware\Authenticate`, `Illuminate\Auth\Middleware\EnsureEmailIsVerified`. Tenancy and auth are present (RTE-05 satisfied).

Unrouted public methods:
- `contextLookups()` — `BaAuditLogController.php:68`. Public static helper, called by `index()` (line 53) and by `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php:1068`.
- `describe()` — `BaAuditLogController.php:102`. Public static helper, called by the audit-log view (line 80) and by `resources/views/pages/partials/reports/_audit-trail.blade.php:150`.

Both are intentionally shared, so D5's `abort(403)` must NOT be applied to them (see BAAL-04).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 34 | GET behavioural-assessment/audit-log | `tenant.behavioural-assessment.audit-log.viewAny` | none (read path) | none (read path) | none | BAAL-01, BAAL-02, BAAL-05 |
| `contextLookups` | 68 | not routed (public static helper) | n/a | none (read path) | none | none | BAAL-04 |
| `describe` | 102 | not routed (public static helper) | n/a | none (read path) | none | none | BAAL-03, BAAL-04 |

No method exceeds 80 lines except `describe()` (86 lines — BAAL-03). `index()` is 26 lines and `contextLookups()` is 26 lines.

## 6. Findings

### F1 — Errors

clean — `grep -nE "getMessage|catch \(|try \{" Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php` → no output. No try/catch, no exception text reaching the user (ERR-07: a read-only method needs none).

### F2 — Transactions and audit

clean — `grep -nE "DB::transaction|activityLog|->create\(|->update\(|->delete\(|->save\(" Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php` → no output. This controller only reads; there is no multi-table write, so no transaction or `activityLog()` is required.

### F3 — Authorization

clean — `grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php` → line 36 `Gate::authorize('tenant.behavioural-assessment.audit-log.viewAny');`. The gate runs before any record is loaded (AUTH-02), the permission name follows `scope.module.feature.action`, it is declared in `config/permissionslist.php:1448` (`'behavioural-assessment.audit-log' => $crud`, and `$crud` includes `viewAny` at `config/permissionslist.php:176-184`), it appears on the view surface (`resources/views/pages/reports.blade.php:358` uses `@can('tenant.behavioural-assessment.audit-log.viewAny')`), and it is seeded with an exact name (`sys_permissions` id 5016 = `tenant.behavioural-assessment.audit-log.viewAny`). No Policy is involved.

### F4 — Validation and input

clean — `grep -nE "validate\(|\\\$request->all|except\(" Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php` → no output. This is a read-only list: `entity_type` is whitelisted against `BaAuditLog::ENTITY_TYPES`, `period_id` is cast with `(int)`, and `field_name` is bound as a `LIKE` parameter (no `$request->all()` into a model, VAL-01 not reached). The only input concern is the unindexed search — recorded as BAAL-02.

### F5 — Routes

#### BAAL-04 · L · RTE-03 — two public helper methods are not routable actions

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M default; lowered to L here) — *every public controller method is routed, or is deliberately disabled*. Lowered because `contextLookups()` and `describe()` are reached by a Blade view and by `BaDashboardController`, so this is a placement concern, not dead or unreachable code; D5's `abort(403)` would break those callers. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php:68` (`contextLookups`), `:102` (`describe`) |
| **Root cause** | Presentation and lookup logic that has nothing to do with an HTTP action lives on the controller as public static methods, so the class is both a route target and a shared helper library. |
| **Consequence** | No user-visible break today; the cost is that a future D5-style clean-up pass could apply `abort(403)` to these methods and take down the audit-log page and the Reports → Audit Trail tab. |
| **Reproduce** | static only — the methods are never reached by a URL; the call sites are the view and another controller. |
| **Fix approach** | Keep them for now; if cleaned up, move both to a `Support` presenter and update the three call sites. Recorded as DECISION BAAL-04 in `02-fix-plan.md` §9. |
| **Plan item** | BAAL-04 in `02-fix-plan.md` §9 |

```php
// BaAuditLogController.php:68-70 — CURRENT
    public static function contextLookups(Collection $logs): array
    {
        $ids = fn (string ...$types) => $logs->whereIn('entity_type', $types)->pluck('entity_id')->unique()->values();
```

**Evidence**
```
$ grep -nE "public (static )?function" Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php
34:    public function index(): View
68:    public static function contextLookups(Collection $logs): array
102:    public static function describe(BaAuditLog $log, array $lookups): array
```

### F6 — Controller shape

#### BAAL-01 · L · CTL-08 — `request()` helper used instead of an injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php:38-43`, method `index()` |
| **Root cause** | `index()` takes no `Request` argument and reads three query parameters four times through the global `request()` helper. |
| **Consequence** | No runtime break; the dependency on the HTTP request is implicit, which makes the method harder to unit-reason about and inconsistent with the project's injected-`Request` convention. |
| **Reproduce** | static only — a naming/convention issue, visible with a text search for `request(`. |
| **Fix approach** | Add `use Illuminate\Http\Request;`, change the signature to `index(Request $request): View`, and replace each `request('x')` with `$request->query('x')`. |
| **Plan item** | BAAL-01 in `02-fix-plan.md` §8 |

```php
// BaAuditLogController.php:36-43 — CURRENT
        Gate::authorize('tenant.behavioural-assessment.audit-log.viewAny');
        // Filters use the model's ENTITY_TYPES (v3: ten types) — an unknown value filters nothing.
        $entityType = in_array(request('entity_type'), BaAuditLog::ENTITY_TYPES, true) ? request('entity_type') : null;

        $logs = BaAuditLog::with(self::EAGER)
            ->when($entityType, fn ($q) => $q->where('entity_type', $entityType))
            ->when(request('field_name'), fn ($q) => $q->where('field_name', 'like', '%'.request('field_name').'%'))
            ->when(request('period_id'), fn ($q) => $q->forPeriod((int) request('period_id')))
```

**Evidence**
```
$ grep -nE "request\(" Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php
38:        $entityType = in_array(request('entity_type'), BaAuditLog::ENTITY_TYPES, true) ? request('entity_type') : null;
42:            ->when(request('field_name'), fn ($q) => $q->where('field_name', 'like', '%'.request('field_name').'%'))
43:            ->when(request('period_id'), fn ($q) => $q->forPeriod((int) request('period_id')))
```

#### BAAL-03 · M · CTL-02 — `describe()` is 86 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method length: over 80 lines → extract; over 150 lines is H*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php:102-187`, method `describe()` |
| **Root cause** | One method holds a ten-case `switch` (one case per audit entity type) plus the badge map, so the body grew to 86 lines. |
| **Consequence** | No user-visible break; the method is harder to review and every new entity type lengthens it further. |
| **Reproduce** | static only — measured with `awk`/`grep`; the method spans 102-187. |
| **Fix approach** | Extract the per-entity branches into small private static helpers (or a `match` with a data map). Because the method is a flat, readable switch and D3 says fix in place, this is recorded as a DECISION so Tarun can defer it. |
| **Plan item** | BAAL-03 in `02-fix-plan.md` §9 |

```php
// BaAuditLogController.php:102-105 — CURRENT
    public static function describe(BaAuditLog $log, array $lookups): array
    {
        $badge = [
            BaAuditLog::ENTITY_ASSESSMENT_RATING => 'primary',
```

**Evidence**
```
$ grep -nE "public (static )?function" Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php
34:    public function index(): View
68:    public static function contextLookups(Collection $logs): array
102:    public static function describe(BaAuditLog $log, array $lookups): array

$ sed -n '186,188p' Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php
        return $out;
    }
}
```

`describe()` runs from line 102 to the closing brace at line 187 — 86 lines, over the 80-line CTL-02 threshold.

### F7 — Models

clean. Facts proven for the two in-scope models:

- `BaAuditLog` (`ba_audit_log`, 203 lines): `declare(strict_types=1)` present; `$table = 'ba_audit_log'` exists in `database/migrations/tenant/2026_06_16_130613_create_ba_audit_log_table.php:24`; `$fillable` declared (line 57) and contains no sensitive column; `$casts` cover `integer`/`boolean`/`datetime` (line 73). The table has **no `deleted_at`**, and the model correctly does **not** use `SoftDeletes` (MDL-03/SoftDeletes rule); the table has **no `updated_at`** and the model correctly sets `UPDATED_AT = null` (line 53). The binary `ip_address` is handled by the `ipAddressText()` accessor and hidden from serialisation (`$hidden`, line 83).
- `BaAssessmentPeriod` (`ba_assessment_periods`, 145 lines): `declare(strict_types=1)` present; `$table = 'ba_assessment_periods'` exists in `database/migrations/tenant/2026_06_16_130612_create_ba_assessment_periods_table.php:24`; `$fillable` declared and correctly omits the generated `uq_guard` column; `$casts` cover booleans, dates, datetimes, integers and `deleted_at`; `SoftDeletes` is present and the table has `deleted_at` (migration line 43). Status uses class constants (`STATUS_OPEN`/`STATUS_CLOSED`/`STATUS_LOCKED`) rather than scattered literals.

Relations resolve — proven in tenant context (new-instance SQL build):
```
$ php artisan tinker --execute '... (new BaAuditLog)->changedBy()->toSql(); ...'
audit changedBy: select * from `sys_users` where `sys_users`.`id` is null and `sys_users`.`deleted_at` is null
audit assessmentEntity: select * from `ba_assessments` where `ba_assessments`.`id` is null and `ba_assessments`.`deleted_at` is null
audit incidentEntity: select * from `ba_incidents` where `ba_incidents`.`id` is null and `ba_incidents`.`deleted_at` is null
period assessments: select * from `ba_assessments` where `ba_assessments`.`period_id` is null and `ba_assessments`.`period_id` is not null and `ba_assessments`.`deleted_at` is null
period table: ba_assessment_periods | audit table: ba_audit_log
```
`changed_by` is documented as `sys_users.id` and `Modules\SchoolSetup\Models\User` declares `protected $table = 'sys_users'` (`Modules/SchoolSetup/app/Models/User.php:44`), so the relation targets the right table. No `InteractsWithMedia` on either model (TEN-01 not triggered).

### F8 — Services and jobs

clean — `grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b' Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php` → no output. The controller names no service or job; all work is done in the controller and the two in-scope models.

### F9 — Queries and performance

#### BAAL-02 · M · QRY-08 — changed-field filter scans the whole audit table twice per load

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M) — *leading-wildcard `LIKE '%x%'` can't use an index; acceptable on small tables, on large ones use a prefix match, FULLTEXT or a search column*. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php:42` (LIKE) and `:56` (`fieldNames`), method `index()` |
| **Root cause** | `ba_audit_log` is the module's largest table (the migration itself says so at line 14-15) and `field_name` has **no index** (the only indexes are `idx_ba_audit_entity`, `idx_ba_audit_actor`, `idx_ba_audit_when`). Line 42 searches it with a leading wildcard, which can never use an index, and line 56 runs `SELECT DISTINCT field_name` — a second full-table scan — on every page load to fill the filter's datalist. |
| **Consequence** | On a tenant with a long-lived audit trail, every load of this page degrades with table size; the filter box gets slower for the very users (admins) who look at it most. Latent today: the test tenant's `ba_audit_log` holds 0 rows. |
| **Reproduce** | Open `/behavioural-assessment/audit-log`, type a value in "Search changed field", submit. The response time grows with the number of audit rows. Nothing to click on the empty test tenant. |
| **Fix approach** | Add an additive migration index on `ba_audit_log.field_name` and change the search to a prefix match (`field_name%`), which can use that index; the datalist already shows the known field names so prefix search is enough. Needs a migration, so it is a DECISION item. |
| **Plan item** | BAAL-02 in `02-fix-plan.md` §9 |

```php
// BaAuditLogController.php:40-42 — CURRENT
        $logs = BaAuditLog::with(self::EAGER)
            ->when($entityType, fn ($q) => $q->where('entity_type', $entityType))
            ->when(request('field_name'), fn ($q) => $q->where('field_name', 'like', '%'.request('field_name').'%'))
```

**Evidence**
```
$ grep -n "field_name" Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php
42:            ->when(request('field_name'), fn ($q) => $q->where('field_name', 'like', '%'.request('field_name').'%'))
56:        $fieldNames = BaAuditLog::distinct('field_name')->pluck('field_name')->filter()->sort()->values();

$ grep -n "index(" database/migrations/tenant/2026_06_16_130613_create_ba_audit_log_table.php
43:            $table->index(['entity_type', 'entity_id', 'changed_at'], 'idx_ba_audit_entity');
44:            $table->index(['changed_by', 'changed_at'], 'idx_ba_audit_actor');
45:            $table->index('changed_at', 'idx_ba_audit_when');
```

#### BAAL-05 · L · QRY-03 — the period filter loads whole models for two columns

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M default; lowered to L here) — *select only what you use; dropdowns use `pluck('name', 'id')` or `get(['id', 'name'])`*. Lowered because `ba_assessment_periods` holds only 4 rows on the test tenant, so the saving is negligible; it is recorded for consistency. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php:49`, method `index()` |
| **Root cause** | `$allPeriods` is fetched with `->get()` (every column of every active period) but the view only reads `$period->id` and `$period->name`. |
| **Consequence** | No visible break; it hydrates unused columns on each load. |
| **Reproduce** | static only — the view's only uses of `$allPeriods` are `$period->id` and `$period->name` (view lines 16-20). |
| **Fix approach** | Narrow the select to `get(['id', 'name'])`. |
| **Plan item** | BAAL-05 in `02-fix-plan.md` §6 |

```php
// BaAuditLogController.php:49 — CURRENT
        $allPeriods = BaAssessmentPeriod::where('is_active', true)->orderByDesc('created_at')->get();
```

**Evidence**
```
$ grep -n 'allPeriods' Modules/BehaviouralAssessment/resources/views/audit-log/index.blade.php
16:                                @foreach($allPeriods as $period)
17:                                    <option value="{{ $period->id }}" {{ request('period_id') == $period->id ? 'selected' : '' }}>
18:                                        {{ $period->name }}
```

### F10 — Views

clean — `grep -nE "Model::|DB::|->where\(|->get\(\)|->count\(\)|\{!!" Modules/BehaviouralAssessment/resources/views/audit-log/index.blade.php` → no output. The view issues no queries; every relation it renders (`assessmentEntity`, `assessmentRatingEntity`, `incidentEntity`, `changedBy`) is eager-loaded by `self::EAGER`, and the intervention/witness rows are supplied pre-keyed by `contextLookups()`, so there is no N+1 inside `@forelse` (VIEW-02 satisfied). No `{!! !!}` is used (VIEW-03). The list is read-only, so no row-action component applies. The breadcrumb is delegated to the shared component `<x-backend.components.breadcrum>`.

### F11 — Security and tenancy

clean — `grep -nE "env\(|\\\$request->all|getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php Modules/BehaviouralAssessment/app/Models/BaAuditLog.php Modules/BehaviouralAssessment/app/Models/BaAssessmentPeriod.php` → no output. No `env()` outside config, no request body logged, no hard-coded ids. The `ip_address` column is binary and hidden from JSON, and the raw bytes are never echoed (the view prints `ipAddressText()` only). Tenant context comes from the route middleware (`InitializeTenancyByDomain`); the models carry no central connection, so TEN-03 is not triggered.

### F12 — Style

clean — `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php Modules/BehaviouralAssessment/app/Models/BaAuditLog.php Modules/BehaviouralAssessment/app/Models/BaAssessmentPeriod.php --format agent` → `{"tool":"pint","result":"passed"}`. `declare(strict_types=1)` present in all three PHP files; comments are English and meaningful; no commented-out code; one import per class.

### F13 — Deep read (answer all 8 questions for every mutating method)

This controller has **no mutating methods** — `index()`, `contextLookups()` and `describe()` only read. The only mutating method in scope is on the audited model `BaAuditLog::log()` (`BaAuditLog.php:131-164`), which is not reached from this controller. One row per mutating method:

| Method | Q1 wrong data | Q2 delete-before-store | Q3 duplicate impl | Q4 soft-delete × unique | Q5 race | Q6 authz hole | Q7 lying message | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `BaAuditLog::log()` (model, not called here) | ok | ok | ok | ok (no soft delete, no unique index) | ok (plain insert) | ok (caller authorizes) | ok | ok |

Notes: the write is a single `static::create()` (insert-only; DB triggers `trg_ba_audit_bu`/`trg_ba_audit_bd` reject UPDATE/DELETE), so an overwrite, a delete-before-store and a count-then-insert race are all impossible; the message (an audit row) cannot lie because there is no flash on this read path.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php` | Depends on this controller's `BaAuditLogController::EAGER` (line 1012) and `::contextLookups()` (line 1068), and renders the Reports → Audit Trail tab through `_audit-trail.blade.php`, which calls `::describe()` (line 150). The coupling is why BAAL-04 must not apply D5 to the helpers. | CTL-05 | the `BaDashboardController` audit report |
| `resources/views/pages/partials/reports/_audit-trail.blade.php` | Calls `BaAuditLogController::describe()` from a Blade that belongs to the Reports page, not this controller. | VIEW-02 | the Reports-page audit report |
| `Modules/SchoolSetup/app/Models/User.php` | Common (other-module) model used as the `changedBy` target; it uses `SoftDeletes`, so a user removed since the change has no name and the view falls back to `User #<id>`. Behaviour is intentional (the id is always printed) — recorded for completeness only. | §4.2 common | no action |

## 8. Not covered, and why

- **Relation-target models** `BaAssessment`, `BaAssessmentRating`, `BaIncident` are named only as relation strings in `self::EAGER`; their own controllers' reports audit them. Their table names (`ba_assessments`, `ba_assessment_ratings`, `ba_incidents`) were confirmed via tinker relation SQL, but their `$fillable`/`$casts` were not re-audited here.
- **`Modules/SchoolSetup/app/Models/User.php`** is a common class (§4.2) — not audited.
- **No browser render.** Per D4 no tests were run. With `ba_audit_log` empty (0 rows), the row-rendering branches of `describe()` were verified statically and through relation SQL, not with live audit data. `⚠ UNVERIFIED — the label/link rendering of `describe()` with real rows would be settled by opening the page on a tenant whose `ba_audit_log` is populated (or by seeding one audit row).`
- **`scopeForPeriod()`** was inspected statically; because the audit table is empty it was not executed against data. `⚠ UNVERIFIED — the period-filter correctness with mixed entity types would be settled by running it on a populated `ba_audit_log`.`
- **No queue jobs, listeners or commands** are involved with this controller.
- **`sys_users` name resolution for deleted actors** is behaviour noted in §7; not re-audited because `User` is a common class.
