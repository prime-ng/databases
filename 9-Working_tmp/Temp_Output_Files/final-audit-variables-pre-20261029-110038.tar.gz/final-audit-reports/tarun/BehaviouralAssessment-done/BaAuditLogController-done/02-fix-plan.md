# Fix Plan — BehaviouralAssessment / BaAuditLogController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/BehaviouralAssessment/routes/web.php` | route file (shared) — no item adds, removes or re-scopes a route |
| `config/permissionslist.php` | shared — no new permission key is proposed |
| `database/migrations/tenant/2026_06_16_130613_create_ba_audit_log_table.php` | existing migration — never edit; BAAL-02 adds a NEW migration only if ticked |
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php` | owned by another report |
| `Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_audit-trail.blade.php` | owned by another report (Reports page) |
| `Modules/BehaviouralAssessment/resources/views/audit-log/index.blade.php` | in scope, but no item touches it this pass |
| `Modules/SchoolSetup/app/Models/User.php` | common class (other module) |
| `resources/views/components/**` and the app layouts | shared components |

## 1. Blockers reachable today

None. This controller is read-only; there is no B- or H-severity finding.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — no error handling or transactions apply to a read-only controller.

## 4. Authorization (F3)

None — `Gate::authorize('tenant.behavioural-assessment.audit-log.viewAny')` is correct and complete.

## 5. Validation, routes, models (F4/F5/F7)

None mechanical — the F5 route finding (BAAL-04) is a DECISION in §9; validation and models are clean.

## 6. Queries & performance (F9)

- [ ] **BAAL-05** · L · QRY-03 · `BaAuditLogController.php:49` — narrow the period dropdown query to the two columns the view reads.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php`
  - **Before** (`BaAuditLogController.php:49`):
    ```php
        $allPeriods = BaAssessmentPeriod::where('is_active', true)->orderByDesc('created_at')->get();
    ```
  - **After:**
    ```php
        $allPeriods = BaAssessmentPeriod::where('is_active', true)->orderByDesc('created_at')->get(['id', 'name']);
    ```
  - **Verify:** `grep -n "allPeriods = BaAssessmentPeriod" Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php`
  - **Expect:** the line ends with `get(['id', 'name']);`.
  - **Effort:** S

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **BAAL-01** · L · CTL-08 · `BaAuditLogController.php:34-47` — inject `Request` and stop calling the `request()` helper.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php`
  - **Before** (`BaAuditLogController.php:7-13`):
    ```php
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Collection;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Models\BaAssessmentPeriod;
    use Modules\BehaviouralAssessment\Models\BaAuditLog;
    ```
  - **After:**
    ```php
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Collection;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Models\BaAssessmentPeriod;
    use Modules\BehaviouralAssessment\Models\BaAuditLog;
    ```
  - **Before** (`BaAuditLogController.php:34-47`):
    ```php
        public function index(): View
        {
            Gate::authorize('tenant.behavioural-assessment.audit-log.viewAny');
            // Filters use the model's ENTITY_TYPES (v3: ten types) — an unknown value filters nothing.
            $entityType = in_array(request('entity_type'), BaAuditLog::ENTITY_TYPES, true) ? request('entity_type') : null;

            $logs = BaAuditLog::with(self::EAGER)
                ->when($entityType, fn ($q) => $q->where('entity_type', $entityType))
                ->when(request('field_name'), fn ($q) => $q->where('field_name', 'like', '%'.request('field_name').'%'))
                ->when(request('period_id'), fn ($q) => $q->forPeriod((int) request('period_id')))
                ->orderByDesc('changed_at')
                ->orderByDesc('id')
                ->paginate(10)
                ->withQueryString();
    ```
  - **After:**
    ```php
        public function index(Request $request): View
        {
            Gate::authorize('tenant.behavioural-assessment.audit-log.viewAny');
            // Filters use the model's ENTITY_TYPES (v3: ten types) — an unknown value filters nothing.
            $entityType = in_array($request->query('entity_type'), BaAuditLog::ENTITY_TYPES, true) ? $request->query('entity_type') : null;

            $logs = BaAuditLog::with(self::EAGER)
                ->when($entityType, fn ($q) => $q->where('entity_type', $entityType))
                ->when($request->query('field_name'), fn ($q) => $q->where('field_name', 'like', '%'.$request->query('field_name').'%'))
                ->when($request->query('period_id'), fn ($q) => $q->forPeriod((int) $request->query('period_id')))
                ->orderByDesc('changed_at')
                ->orderByDesc('id')
                ->paginate(10)
                ->withQueryString();
    ```
  - **Verify:** `grep -nE "function index\(|request\('" Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php`
  - **Expect:** `public function index(Request $request): View` appears; no line contains a bare `request('` call.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BAAL-02** · M · DECISION · QRY-08 — index `ba_audit_log.field_name` and change the changed-field search to a prefix match, so the audit-log page stops full-scanning the table twice per load.
  - **Why it is a decision:** it needs a new additive tenant migration (an existing migration must never be edited), and running it (`php artisan tenants:migrate`) is Tarun's hand.
  - (a) ⭐ Add a new additive migration that indexes `ba_audit_log.field_name`, and change the `field_name` search in `index()` so it matches a prefix (`field_name%`) instead of `%field_name%`; the datalist already lists the known field names, so prefix search is enough. After BAAL-01, the search reads `->where('field_name', 'like', $request->query('field_name').'%')`.
  - (b) Add only the index and leave the `LIKE '%x%'` as-is — the index then helps the `distinct()` on line 56 but not the search itself.
  - (c) Leave both as-is and record as accepted (today's tenants have a small audit table).
  - ➜ Choice: ____

- [ ] **BAAL-03** · M · DECISION · CTL-02 — `describe()` is 86 lines; split it?
  - **Why it is a decision:** a helper split under D3 fix-in-place; the method is a flat, readable ten-case switch.
  - (a) ⭐ Defer the extraction to the later split pass (D3) and record as accepted.
  - (b) Extract the ten entity cases into private static helpers now.
  - (c) Convert the switch to a `match (true)` over a per-entity data map now.
  - ➜ Choice: ____

- [ ] **BAAL-04** · L · DECISION · RTE-03 — two public helpers (`contextLookups()`, `describe()`) are not routes; keep them on the controller or relocate them?
  - **Why it is a decision:** moving them changes call sites owned by another report (`BaDashboardController`) and a Reports Blade partial, and D5's `abort(403)` must NOT be applied because both methods are genuinely reached.
  - (a) ⭐ Keep them on the controller and record as accepted; do NOT apply D5 (`abort(403)`) — the audit-log view and `BaDashboardController` call them.
  - (b) Move `contextLookups()` and `describe()` to `Modules/BehaviouralAssessment/Support/BaAuditLogPresenter` and update the three call sites (this controller, `audit-log/index.blade.php`, `BaDashboardController`).
  - ➜ Choice: ____

## 10. Findings with no plan item

None — every finding in `01-report.md` maps to a plan item above (BAAL-01 and BAAL-05 mechanical; BAAL-02, BAAL-03, BAAL-04 decisions).
