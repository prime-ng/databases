# Fix Plan — BehaviouralAssessment / BaInterventionCaseController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `bootstrap/app.php` | central exception handler — shared app file, would move BA trigger mapping (BAIC-02 option b) into a shared file |
| `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php` | owned by the pending `BaIncidentController` report; root cause of BAIC-05 |
| `Modules/BehaviouralAssessment/app/Listeners/NotifyInterventionAssigned.php` | owned by the pending `BaIncidentController` report |
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php` | different controller; only a DECISION that moves `employeeName()` would touch it |
| `Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/*.blade.php` | rendered by the incidents page, owned by another report |
| `config/permissionslist.php` | shared permission config; no permission key changes in this plan |
| every file under `final-audit-reports/` | reports are append-only and managed by the main session |

## 1. Blockers reachable today

None — the audit found no B or H finding.

## 2. Fixes that arm a latent defect (sequenced)

None. BAIC-01 (log the exception object) is independent of BAIC-02 (catch-all decision); if BAIC-02 chooses to remove the catch-all later, BAIC-01 becomes moot but causes no harm.

## 3. Errors & transactions (F1/F2)

- [ ] **BAIC-01** · M · ERR-05 · `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php:173-176` — log the exception object, not `getMessage()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php`
  - **Before** (`BaInterventionCaseController.php:173-176`):
    ```php
            Log::error('BaInterventionCaseController::'.$method.' failed', [
                'case' => $request->route('case'),
                'error' => $e->getMessage(),
            ]);
    ```
  - **After:**
    ```php
            Log::error('BaInterventionCaseController::'.$method.' failed', [
                'case' => $request->route('case'),
                'exception' => $e,
            ]);
    ```
  - **Verify:** `grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php`
  - **Expect:** one output line only — `166:            return $this->reject($request, $e->getMessage());` (the allowed DomainException branch); no line at 175.
  - **Effort:** S

## 4. Authorization (F3)

None. The permission names already exist and are seeded (see BAIC-03 in §9 for the one alignment decision).

## 5. Validation, routes, models (F4/F5/F7)

None. Routes are correct and tenant-scoped; both models are clean (see BAIC-04 in §9 for the one unrouted helper decision).

## 6. Queries & performance (F9)

None. The only candidate (BAIC-08, the 200-row log cap) is accepted — see §10.

## 7. Views (F10)

None — this controller renders no Blade view.

## 8. Style (F12) — one item per file

- [ ] **BAIC-06** · L · STY-03 · `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php:42-107` — rename the local `$v` to `$validated` in the five methods.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php`
  - **Before** (`BaInterventionCaseController.php:42-50`, `assign`):
    ```php
            $v = $request->validated();

            return $this->run($request, 'assign', 'Case assigned.', fn () => $this->service->assign(
                $request->interventionCase(),
                isset($v['assigned_to']) ? (int) $v['assigned_to'] : null,
                $v['scheduled_date'] ?? null,
                $v['notes'] ?? null,
                $this->requireEmployee('assigned_to'),
            ));
    ```
  - **After:**
    ```php
            $validated = $request->validated();

            return $this->run($request, 'assign', 'Case assigned.', fn () => $this->service->assign(
                $request->interventionCase(),
                isset($validated['assigned_to']) ? (int) $validated['assigned_to'] : null,
                $validated['scheduled_date'] ?? null,
                $validated['notes'] ?? null,
                $this->requireEmployee('assigned_to'),
            ));
    ```
  - **Before** (`BaInterventionCaseController.php:55-64`, `reassign`):
    ```php
            $v = $request->validated();

            return $this->run($request, 'reassign', 'Case reassigned.', fn () => $this->service->reassign(
                $request->interventionCase(),
                isset($v['assigned_to']) ? (int) $v['assigned_to'] : null,
                $v['scheduled_date'] ?? null,
                (string) $v['reason'],
                $this->requireEmployee('reason'),
            ));
    ```
  - **After:**
    ```php
            $validated = $request->validated();

            return $this->run($request, 'reassign', 'Case reassigned.', fn () => $this->service->reassign(
                $request->interventionCase(),
                isset($validated['assigned_to']) ? (int) $validated['assigned_to'] : null,
                $validated['scheduled_date'] ?? null,
                (string) $validated['reason'],
                $this->requireEmployee('reason'),
            ));
    ```
  - **Before** (`BaInterventionCaseController.php:76-84`, `addProgress`):
    ```php
            $v = $request->validated();

            return $this->run($request, 'addProgress', 'Progress note added.', fn () => $this->service->addProgress(
                $request->interventionCase(),
                (string) $v['progress_date'],
                (string) $v['note'],
                $this->requireEmployee('note'),
            ));
    ```
  - **After:**
    ```php
            $validated = $request->validated();

            return $this->run($request, 'addProgress', 'Progress note added.', fn () => $this->service->addProgress(
                $request->interventionCase(),
                (string) $validated['progress_date'],
                (string) $validated['note'],
                $this->requireEmployee('note'),
            ));
    ```
  - **Before** (`BaInterventionCaseController.php:88-98`, `complete`):
    ```php
            $v = $request->validated();
            $this->requireEmployee('completion_notes');

            return $this->run($request, 'complete', 'Case completed.', fn () => $this->service->complete(
                $request->interventionCase(),
                (string) $v['completed_on'],
                (string) $v['completion_notes'],
                (string) $v['outcome'],
                $v['parent_meeting_on'] ?? null,
            ));
    ```
  - **After:**
    ```php
            $validated = $request->validated();
            $this->requireEmployee('completion_notes');

            return $this->run($request, 'complete', 'Case completed.', fn () => $this->service->complete(
                $request->interventionCase(),
                (string) $validated['completed_on'],
                (string) $validated['completion_notes'],
                (string) $validated['outcome'],
                $validated['parent_meeting_on'] ?? null,
            ));
    ```
  - **Before** (`BaInterventionCaseController.php:102-109`, `cancel`):
    ```php
            $v = $request->validated();
            $this->requireEmployee('cancellation_reason');

            return $this->run($request, 'cancel', 'Case cancelled.', fn () => $this->service->cancel(
                $request->interventionCase(),
                (string) $v['cancellation_reason'],
            ));
    ```
  - **After:**
    ```php
            $validated = $request->validated();
            $this->requireEmployee('cancellation_reason');

            return $this->run($request, 'cancel', 'Case cancelled.', fn () => $this->service->cancel(
                $request->interventionCase(),
                (string) $validated['cancellation_reason'],
            ));
    ```
  - **Verify:** `grep -n "\$v\b" Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BAIC-07** · L · STY-02 · `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseRequest.php:7-11,45` — import `Rule` so the file is Pint-clean.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseRequest.php`
  - **Before** (`BaInterventionCaseRequest.php:7-11`):
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Modules\BehaviouralAssessment\Models\BaIncidentInterventionJnt;
    use Modules\BehaviouralAssessment\Services\BaInterventionCaseService;
    use Modules\SchoolSetup\Models\Employee;
    ```
  - **After:**
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Modules\BehaviouralAssessment\Models\BaIncidentInterventionJnt;
    use Modules\BehaviouralAssessment\Services\BaInterventionCaseService;
    use Modules\SchoolSetup\Models\Employee;
    ```
  - **Before** (`BaInterventionCaseRequest.php:44-45`):
    ```php
            return [$required ? 'required' : 'nullable', 'integer',
                \Illuminate\Validation\Rule::exists('sch_employees', 'id')->where('is_active', 1)];
    ```
  - **After:**
    ```php
            return [$required ? 'required' : 'nullable', 'integer',
                Rule::exists('sch_employees', 'id')->where('is_active', 1)];
    ```
  - **Verify:** `vendor/bin/pint --test --format agent Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseRequest.php`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BAIC-02** · M · DECISION · ERR-00 — the generic `catch (Throwable $e)` in `run()` re-implements the central error handler.
  - **Why it is a decision:** removing it changes error policy and moves the BA-trigger-to-422 mapping into `bootstrap/app.php` (a shared file), which is out of this plan's scope.
  - (a) ⭐ **Keep the catch-all for this pass and just log the exception object (BAIC-01). Move the trigger mapping to the central handler in a later pass.** No file outside this controller is touched; the six writes keep their current 422 behaviour.
  - (b) Remove the `catch (Throwable $e)` now and accept that a raw `ba_*` trigger rejection becomes a generic 500 until the central handler is updated. Touches this controller and, to fix the 500, `bootstrap/app.php`.
  - (c) Leave the catch-all unchanged and record it as accepted.
  - ➜ Choice: ____

- [ ] **BAIC-03** · M · DECISION · AUTH-03 — `start()` does not require the actor to have an `sch_employees` record, unlike the other five writes.
  - **Why it is a decision:** adding the guard changes who may start a case (a permission-holder without an employee row would be refused).
  - (a) ⭐ **Accept the current behaviour (permission or ownership is enough to start).** No code change; the class docblock claim "Every staff action needs an sch_employees record" should be softened in a later pass.
  - (b) Add `$this->requireEmployee('case');` as the first line of `start()` so the staff-record rule is uniform. Touches this controller only.
  - ➜ Choice: ____

- [ ] **BAIC-04** · M · DECISION · RTE-03 — public static `employeeName()` is not routed and lives on the controller.
  - **Why it is a decision:** moving it touches a Blade partial and `BaIncidentController` (shared callers); D5 `abort(403)` would break both callers.
  - (a) ⭐ **Move `employeeName()` to a new Support class and update the three callers.** Touches this controller, `BaIncidentController.php`, and `_interventions-applied.blade.php`.
  - (b) Leave it on the controller and record it as accepted.
  - ➜ Choice: ____

- [ ] **BAIC-05** · M · DECISION · SVC-05 — `currentEmployee()` runs twice per `addProgress` / `complete` request.
  - **Why it is a decision:** memoising needs a per-request cache; a naive static cache risks a tenant-crossing value under a long-running worker (TEN-02), and the change reaches into `BaIncidentService` (another report's class).
  - (a) ⭐ **Accept as is.** Two indexed `sch_employees` lookups on a low-traffic write path; no code change.
  - (b) Memoise in `BaInterventionCaseService::currentEmployee()` with a request-scoped store, and hand the fix to the `BaIncidentController` report for the shared root cause.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BAIC-08 | Accepted — the `limit(200)` on the progress-log JSON protects the log modal; 30 cases and 0 progress rows live today, and 200 notes on one case is implausible. Informational. |
