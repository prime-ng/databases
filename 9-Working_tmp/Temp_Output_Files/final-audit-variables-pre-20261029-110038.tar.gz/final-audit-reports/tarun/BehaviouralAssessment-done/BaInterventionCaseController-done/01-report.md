# Final Audit — BehaviouralAssessment / BaInterventionCaseController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php` (194 lines, 8 public methods + 1 public static helper)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | POST `/behavioural-assessment/intervention-cases/{case}/assign` · `/reassign` · `/start` · `/progress` · `/complete` · `/cancel`; GET `/behavioural-assessment/intervention-cases/{case}/progress` (JSON) |
| Menu path | Behavioural Assessment → Incidents page → tabs "Interventions Applied" and "Intervention Worklist" (this controller has no page of its own) |
| Who uses it | Roles that hold the three permissions, measured on the test tenant `xyz_school_00000000000040008000_202627`: **Super Admin, School Admin, Principal** — each holds all three (`view` id 4995, `update` id 4996, `assign` id 4997) |
| What a user does here | A staff member assigns an owner and a due date to an open intervention case, reassigns it to another owner, starts it, appends progress notes, completes it with an outcome, or cancels it with a reason. The page reloads with a flash message; the log modal fetches the progress log as JSON. |
| Tables written | `ba_incident_intervention_jnt`, `ba_audit_log`, `ba_intervention_progress` |
| Tables read | `ba_incident_intervention_jnt`, `ba_interventions`, `ba_incidents`, `ba_intervention_progress`, `sch_employees`, `sys_users` |
| Live data | `ba_incident_intervention_jnt`: **30 live rows**, 0 trashed · `ba_intervention_progress`: **0 live rows** (tenant `xyz_school_00000000000040008000_202627`) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Production-ready after the small set of fixes in `02-fix-plan.md`; **no blocker or high finding was found**. The lifecycle, the transaction/lock discipline, the permission wiring on all four surfaces and both models are correct and the write paths are well guarded. The single worst finding is **BAIC-01**: the shared error helper `run()` logs only `$e->getMessage()`, so every unexpected production failure is recorded as a bare sentence with no exception class and no stack trace — the one thing an operator needs to diagnose it. Effort for the mechanical items is **S**; the four DECISION items are alignment choices, not repairs.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 5 | 3 | 4 | 8 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BAIC-01, BAIC-02 | F8 Services/Jobs | BAIC-05 |
| F2 Transactions/Audit | clean | F9 Queries/Perf | BAIC-08 |
| F3 Authorization | BAIC-03 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | BAIC-04 | F12 Style | BAIC-06, BAIC-07 |
| F6 Controller shape | clean | F13 Deep read | see §6 F13 table |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php` | controller | 194 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Services/BaInterventionCaseService.php` | service | 348 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Models/BaIncidentInterventionJnt.php` | model | 144 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Models/BaInterventionProgress.php` | model | 51 | this report | ✅ |
| 5 | `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseRequest.php` | FormRequest (base) | 47 | this report | ✅ |
| 6 | `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseAssignRequest.php` | FormRequest | 36 | this report | ✅ |
| 7 | `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseReassignRequest.php` | FormRequest | 35 | this report | ✅ |
| 8 | `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseProgressRequest.php` | FormRequest | 31 | this report | ✅ |
| 9 | `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseCompleteRequest.php` | FormRequest | 44 | this report | ✅ |
| 10 | `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseCancelRequest.php` | FormRequest | 32 | this report | ✅ |
| 11 | `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` | model | 203 | ↗ [tarun/BehaviouralAssessment-done/BaAuditLogController-done](../BaAuditLogController-done/01-report.md) | ↗ linked |
| 12 | `Modules/BehaviouralAssessment/app/Models/BaIntervention.php` | model | 93 | ↗ [tarun/BehaviouralAssessment-done/BaInterventionController-done](../BaInterventionController-done/01-report.md) | ↗ linked |
| 13 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | 45 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 14 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support | 37 | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |
| 15 | `Modules/BehaviouralAssessment/app/Models/BaIncident.php` | model (other BA class) | 238 | pending `BaIncidentController` report | ❌ not this report |
| 16 | `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php` | service (other BA class) | 633 | pending `BaIncidentController` report | ❌ not this report |
| 17 | `Modules/BehaviouralAssessment/app/Events/InterventionAssigned.php` | event | 29 | pending `BaIncidentController` report | ❌ not this report |
| 18 | `Modules/BehaviouralAssessment/app/Listeners/NotifyInterventionAssigned.php` | listener | 32 | pending `BaIncidentController` report | ❌ not this report |
| 19 | `Modules/SchoolSetup/app/Models/Employee.php` | model (other module) | 968 | common, §4.2 | n/a |

Rows 15–18 are reached **through** the service (they are not imported by the controller). They are other classes of this module and are claimed by the future `BaIncidentController` report; this report only measures how the service uses them. Row 19 is a different-module model (common).

No pre-applied files (`PRE-APPLIED-2026-10-10.md`) touch this module.

## 4. Routes

```
POST    behavioural-assessment/intervention-cases/{case}/assign    behavioural-assessment.intervention-cases.assign          Modules\BehaviouralAssessment\Http\Controllers\BaInterventionCaseController@assign
POST    behavioural-assessment/intervention-cases/{case}/reassign  behavioural-assessment.intervention-cases.reassign        Modules\BehaviouralAssessment\Http\Controllers\BaInterventionCaseController@reassign
POST    behavioural-assessment/intervention-cases/{case}/start     behavioural-assessment.intervention-cases.start           Modules\BehaviouralAssessment\Http\Controllers\BaInterventionCaseController@start
POST    behavioural-assessment/intervention-cases/{case}/progress  behavioural-assessment.intervention-cases.progress.store  Modules\BehaviouralAssessment\Http\Controllers\BaInterventionCaseController@addProgress
GET|HEAD behavioural-assessment/intervention-cases/{case}/progress behavioural-assessment.intervention-cases.progress.index Modules\BehaviouralAssessment\Http\Controllers\BaInterventionCaseController@progressLog
POST    behavioural-assessment/intervention-cases/{case}/complete  behavioural-assessment.intervention-cases.complete        Modules\BehaviouralAssessment\Http\Controllers\BaInterventionCaseController@complete
POST    behavioural-assessment/intervention-cases/{case}/cancel    behavioural-assessment.intervention-cases.cancel          Modules\BehaviouralAssessment\Http\Controllers\BaInterventionCaseController@cancel
```

Produced by `php -r` over `/tmp/fa-routes.json` (uncached `route:list --json`). Every route carries the tenant group `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:BehaviouralAssessment, Authenticate, EnsureEmailIsVerified` (RTE-05 ✅).

Unrouted public methods: `employeeName` at `BaInterventionCaseController.php:135` (static helper — see BAIC-04). All other public methods are routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `__construct` | 38 | no (DI) | — | — | — | — | — |
| `assign` | 40 | POST /intervention-cases/{case}/assign | `tenant.behavioural-assessment.intervention-cases.assign` (FormRequest::authorize) | service `assign()` line 74 | none — uses `BaAuditLog::log` fields `assigned_to`, `scheduled_date` | ba_incident_intervention_jnt, ba_audit_log | BAIC-01, BAIC-02 |
| `reassign` | 53 | POST /intervention-cases/{case}/reassign | `tenant.behavioural-assessment.intervention-cases.assign` | service `reassign()` line 125 | none — `BaAuditLog::log` fields `assigned_to`, `scheduled_date` | ba_incident_intervention_jnt, ba_audit_log | BAIC-01, BAIC-02 |
| `start` | 66 | POST /intervention-cases/{case}/start | `tenant.behavioural-assessment.intervention-cases.update` OR owner (`canWork`) | service `start()` line 176 | none — `BaAuditLog::log` field `status` | ba_incident_intervention_jnt, ba_audit_log | BAIC-01, BAIC-02, BAIC-03 |
| `addProgress` | 74 | POST /intervention-cases/{case}/progress | owner OR `tenant.behavioural-assessment.intervention-cases.update` (`ownerOrUpdate`) | service `addProgress()` line 203 | none | ba_intervention_progress | BAIC-01, BAIC-02, BAIC-05 |
| `complete` | 86 | POST /intervention-cases/{case}/complete | owner OR `tenant.behavioural-assessment.intervention-cases.update` (`ownerOrUpdate`) | service `complete()` line 242 | none — `BaAuditLog::log` fields `status`, `outcome` | ba_incident_intervention_jnt, ba_audit_log | BAIC-01, BAIC-02, BAIC-05 |
| `cancel` | 100 | POST /intervention-cases/{case}/cancel | `tenant.behavioural-assessment.intervention-cases.update` | service `cancel()` line 294 | none — `BaAuditLog::log` field `status` | ba_incident_intervention_jnt, ba_audit_log | BAIC-01, BAIC-02 |
| `progressLog` | 112 | GET /intervention-cases/{case}/progress | owner OR (`tenant.behavioural-assessment.intervention-cases.view` / `.update` / `tenant.behavioural-assessment.incidents.view`) (`canViewLog`) | none (read) | none | none (reads) | BAIC-08 |
| `employeeName` | 135 | not routed | — | — | — | — | BAIC-04 |

The controller itself holds **no** write and **no** transaction; every write lives in `BaInterventionCaseService`, one `DB::transaction` per mutating method (F2). The audit mechanism in this module is `BaAuditLog::log`; the global `activityLog()` helper is not called (see §6 F2).

## 6. Findings

### F1 — Errors

#### BAIC-01 · M · ERR-05 — the shared error helper logs only the message, losing the exception class and stack trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php:173-176`, method `run()` |
| **Root cause** | The catch-all writes `$e->getMessage()` into the log context. A string message carries neither the exception class nor the stack trace, and the `case` context alone does not identify the failing statement. |
| **Consequence** | When an unexpected failure happens on any of the six writes, the operator sees one sentence in `laravel.log` and cannot find the line that threw. |
| **Reproduce** | Static only — the branch runs only on an unexpected runtime failure; the wrong call is visible at line 175 and no seeded role can force it deterministically (D4). |
| **Fix approach** | Log the exception object instead of its message string, keeping the existing context field. One line changes. |
| **Plan item** | BAIC-01 in `02-fix-plan.md` §3 |

```php
// BaInterventionCaseController.php:173-176 — CURRENT
            Log::error('BaInterventionCaseController::'.$method.' failed', [
                'case' => $request->route('case'),
                'error' => $e->getMessage(),
            ]);
```

**Evidence**
```
$ grep -n 'getMessage' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php
166:            return $this->reject($request, $e->getMessage());
175:                'error' => $e->getMessage(),
```

#### BAIC-02 · M · ERR-00 — a controller catch-all deviates from the settled Laravel idiom (DECISION)

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M, decided by D1) — *no try/catch in a controller; `DB::transaction` rolls back and the central handler in `bootstrap/app.php` renders. A controller try/catch is a finding unless D2 allows it.* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php:159-181`, method `run()` |
| **Root cause** | `run()` wraps every write in `try { $action(); }` with three catches. D2 allows only the `\DomainException` catch (line 165) for business-rule messages. The generic `catch (Throwable $e)` (line 167) re-implements the central error handler inside the controller and exists only so a BA database-trigger rejection (`BaTriggerError`) can be turned into a 422. |
| **Consequence** | Errors that the central handler would render with a full report are instead flattened to one generic flash/JSON 500 here, and there are now two places where error policy lives. No data is lost and nothing leaks to the user. |
| **Reproduce** | Static only — the branch is reachable only on a failing write; the code shape is proven below (D4). |
| **Fix approach** | Choose an option (see the plan). Recommended: keep the catch for this pass and log the exception object (BAIC-01); move the trigger-to-422 mapping into the central handler in a later pass, which is a shared file and out of this plan's scope. |
| **Plan item** | BAIC-02 in `02-fix-plan.md` §9 (DECISION) |

```php
// BaInterventionCaseController.php:159-181 — CURRENT
    private function run(Request $request, string $method, string $success, callable $action): RedirectResponse|JsonResponse
    {
        try {
            $action();
        } catch (ValidationException|ModelNotFoundException|HttpExceptionInterface $e) {
            throw $e;
        } catch (DomainException $e) {
            return $this->reject($request, $e->getMessage());
        } catch (Throwable $e) {
            $trigger = BaTriggerError::message($e);
            if ($trigger !== null) {
                return $this->reject($request, $trigger);
            }

            Log::error('BaInterventionCaseController::'.$method.' failed', [
                'case' => $request->route('case'),
                'error' => $e->getMessage(),
            ]);

            return $request->expectsJson()
                ? response()->json(['message' => 'The operation could not be completed.'], 500)
                : back()->withInput()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n 'catch (' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php
163:        } catch (ValidationException|ModelNotFoundException|HttpExceptionInterface $e) {
165:        } catch (DomainException $e) {
167:        } catch (Throwable $e) {
```

### F2 — Transactions and audit

clean — `grep -n 'DB::transaction\|lockForUpdate\|BaAuditLog::log' Modules/BehaviouralAssessment/app/Services/BaInterventionCaseService.php` returns one `DB::transaction` per mutating method (lines 74, 125, 176, 203, 242, 294), `lockForUpdate()` inside `lock()` at line 321, and `BaAuditLog::log` **after** the `save()` and **inside** each closure (106, 108, 158, 162, 193, 283, 285, 310). The only side effect, `InterventionAssigned::dispatch`, is safe: `grep -n 'ShouldDispatchAfterCommit' Modules/BehaviouralAssessment/app/Events/InterventionAssigned.php` → line 21 `class InterventionAssigned implements ShouldDispatchAfterCommit`. No `beginTransaction`/`commit()` and no mail/file/HTTP inside a transaction. Note: this module audits with `BaAuditLog::log`, not the global `activityLog()` helper, so the F2 "activityLog event" column records `BaAuditLog` field names above.

### F3 — Authorization

#### BAIC-03 · M · AUTH-03 — `start()` skips the staff-record guard that every sibling write enforces (DECISION)

| Field | Value |
|---|---|
| **Rule** | AUTH-03 (H, lowered to M — the permission already gates the action; the gap is the actor's staff record, not access) — *record-level checks where data belongs to a person* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php:66-72`, method `start()` |
| **Root cause** | The controller's own contract (class docblock line 34) says "Every staff action needs an sch_employees record (no stand-in)". `assign`, `reassign`, `addProgress`, `complete` and `cancel` all call `requireEmployee()`; `start()` authorizes with `canWork()` (a permission/ownership check) and never calls it. |
| **Consequence** | A user who holds `intervention-cases.update` but has no `sch_employees` row can start any case, unlike the other five actions, so the "staff-record required" rule is enforced inconsistently. |
| **Reproduce** | Static only — the difference is between the six call sites; the write itself succeeds, so there is no error page to observe (D4). |
| **Fix approach** | Choose an option (see the plan): add the same guard, or accept the permission-only gate for start. Adding the guard changes behaviour, so it is a DECISION. |
| **Plan item** | BAIC-03 in `02-fix-plan.md` §9 (DECISION) |

```php
// BaInterventionCaseController.php:66-72 — CURRENT
    public function start(Request $request, int $case): RedirectResponse|JsonResponse
    {
        $model = BaIncidentInterventionJnt::with('intervention')->findOrFail($case);
        abort_unless(BaInterventionCaseService::canWork($model, BaInterventionCaseService::currentEmployee()), 403);

        return $this->run($request, 'start', 'Case started.', fn () => $this->service->start($model));
    }
```

**Evidence**
```
$ grep -n 'requireEmployee\|function start' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php
49:            $this->requireEmployee('assigned_to'),
62:            $this->requireEmployee('reason'),
66:    public function start(Request $request, int $case): RedirectResponse|JsonResponse
82:            $this->requireEmployee('note'),
89:        $this->requireEmployee('completion_notes');
103:        $this->requireEmployee('cancellation_reason');
144:    private function requireEmployee(string $field): Employee
```

Scanner candidates AUTH-01 (B) at lines 74 and 86 for `addProgress`/`complete` were checked in source and are **false positives**: `BaInterventionCaseProgressRequest::authorize()` → `ownerOrUpdate()` → `BaInterventionCaseService::canWork()`, which is `Gate::allows('tenant.behavioural-assessment.intervention-cases.update') || isOwner(...)`. `Gate::allows` on a permission string resolves through Spatie's gate hook (`vendor/spatie/laravel-permission/src/PermissionRegistrar.php:123-135`, `checkPermissionTo`), and the three permission rows are seeded and held by three roles (measured, §0). No authorization hole.

### F4 — Validation and input

clean — every input goes through a FormRequest: `grep -rn '->all()\|->except(\|request()->validate' …BaInterventionCaseController.php …Http/Requests/BaInterventionCase*.php` returns no output. The controller reads `$request->validated()`, optional fields use `?? null`, and every rule is typed (`date`, `integer`, `string`, `min`, `max`, `Rule::exists`, `Rule::in`). Uniqueness is not applicable (no create).

### F5 — Routes

#### BAIC-04 · M · RTE-03 — public static `employeeName()` is not routed (DECISION)

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`, per D5)* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php:135-142`, method `employeeName()` |
| **Root cause** | `employeeName()` is a presentation helper that lives on the controller but is never a route action. It is called from a Blade partial and from another controller. D5 (turn the body into `abort(403)`) is unsuitable here: doing so would break both callers. |
| **Consequence** | The rule "every public method is routed" is not met; the helper is reachable only in PHP, not over HTTP, so there is no user-visible failure — it is a shape/consistency defect. |
| **Reproduce** | Static only — no route exists for it (the route probe over `/tmp/fa-routes.json` reports 0 actions containing `employeeName`). |
| **Fix approach** | Choose an option (see the plan): move the helper to a small Support class (recommended), or leave it and record it as accepted. Moving it touches the Blade partial and `BaIncidentController`, so it is a DECISION. |
| **Plan item** | BAIC-04 in `02-fix-plan.md` §9 (DECISION) |

```php
// BaInterventionCaseController.php:135-142 — CURRENT
    public static function employeeName(?Employee $e): string
    {
        if ($e === null) {
            return '—';
        }

        return $e->user?->name ?? trim($e->first_name.' '.$e->last_name);
    }
```

**Evidence**
```
$ grep -rn 'employeeName' Modules/BehaviouralAssessment/app Modules/BehaviouralAssessment/resources
Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php:127:                'recorded_by' => self::employeeName($p->recordedBy),
Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php:135:    public static function employeeName(?Employee $e): string
Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:286:            ->mapWithKeys(fn (Employee $e) => [$e->id => BaInterventionCaseController::employeeName($e)]);
Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/_interventions-applied.blade.php:125:                                {{ \Modules\BehaviouralAssessment\Http\Controllers\BaInterventionCaseController::employeeName($applied->assignedTo) }}
```

Routes otherwise clean: no state change over GET (`progressLog` is read-only), `{case}` matches the controller argument, custom routes are not captured by a resource, and the tenant middleware group is present (§4).

### F6 — Controller shape

clean — `php -l` passes; 194 lines and 8 methods (well under the CTL-01 1,000-line / 25-method limits); longest method `run()` is 28 lines (under the 80-line CTL-02 limit); every public method has a return type (CTL-04); `Request` is injected, never the `request()` helper inside methods (CTL-08); `grep -n 'dd(\|dump(\|var_dump(' …BaInterventionCaseController.php` returns no output (CTL-09); no dead code found (CTL-10).

### F7 — Models

clean — both models declare `$fillable` (MDL-01), the `$table` values exist in migrations `2026_06_16_130626` and `2026_06_16_130635` (MDL-07), `SoftDeletes` is present **only** on `BaIncidentInterventionJnt`, whose table has `deleted_at` and a SoftDeletes-aware unique index `uq_ba_inc_int` over the generated column `uq_guard` (MDL-03 / VAL-04 safe); `BaInterventionProgress` has no `deleted_at` and no trait, with `UPDATED_AT = null` plus a `created_at` cast; every boolean/date/datetime column is cast. All relationships are return-typed and resolve:

**Evidence**
```
$ php artisan tinker --execute '…tenancy()->initialize(...); $m=(new BaIncidentInterventionJnt); foreach(["incident","intervention","assignedTo","assignedBy","progress","progressNewestFirst"] as $r){ echo $r." ".get_class($m->$r())."\n"; }…'
incident            BelongsTo
intervention        BelongsTo
assignedTo          BelongsTo
assignedBy          BelongsTo
progress            HasMany
progressNewestFirst HasMany
```

### F8 — Services and jobs

#### BAIC-05 · M · SVC-05 — `currentEmployee()` is re-queried within one write request (DECISION)

| Field | Value |
|---|---|
| **Rule** | SVC-05 (M) — *repeated lookups inside a request are memoised or cached once* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseRequest.php:30-33` and `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php:144-152` |
| **Root cause** | `BaInterventionCaseService::currentEmployee()` delegates to `BaIncidentService::currentEmployee()`, which runs `Employee::where('user_id', auth()->id())->first()` on every call and is not memoised. On `addProgress` and `complete` the lookup runs twice per request: once in the FormRequest `authorize()` (through `ownerOrUpdate()` → `employee()`), once in the controller's `requireEmployee()`. |
| **Consequence** | Two identical employee lookups per progress/complete submit; a small cost on a low-traffic write path (30 live cases). |
| **Reproduce** | Static only — the two call sites are on the same request path and are proven below (D4). |
| **Fix approach** | Choose an option (see the plan). Recommended: accept as is (two indexed lookups). Memoising in this service with a static cache risks a tenant-crossing cache under a long-running worker (TEN-02), so it is a DECISION, not a mechanical fix. |
| **Plan item** | BAIC-05 in `02-fix-plan.md` §9 (DECISION) |

```php
// BaInterventionCaseRequest.php:30-33 — CURRENT (first lookup)
    public function employee(): ?Employee
    {
        return BaInterventionCaseService::currentEmployee();
    }
```

**Evidence**
```
$ grep -n 'currentEmployee\|function employee' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseRequest.php
…BaInterventionCaseController.php:146:        $employee = BaInterventionCaseService::currentEmployee();
…BaInterventionCaseRequest.php:32:        return BaInterventionCaseService::currentEmployee();
```

Other SVC rules clean: no HTTP in the service (`grep -n 'request()\|session()\|redirect()\|response()\|back()' …BaInterventionCaseService.php` → no output, SVC-01); dependencies arrive on the controller constructor; no writes on a read path (`progressLog` only reads, SVC-03); one implementation per operation (SVC-04). No jobs are queued from here.

### F9 — Queries and performance

#### BAIC-08 · L · QRY-02 — the progress log is silently capped at 200 rows

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H, lowered to L — a log modal of one case, and 30 case rows live) — *lists are paginated / bounded* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php:112-133`, method `progressLog()` |
| **Root cause** | The JSON log query ends with `->limit(200)` and returns no indication that older entries were dropped. |
| **Consequence** | If a case ever accumulates more than 200 notes, the modal shows the newest 200 with no "showing the latest 200" hint. |
| **Reproduce** | Static only — needs a case with more than 200 progress rows to observe; 0 progress rows exist today (D4). |
| **Fix approach** | Accepted as is (see plan §10): the cap protects the modal and 200 notes on one case is implausible. |
| **Plan item** | none — see plan §10 |

```php
// BaInterventionCaseController.php:117-122 — CURRENT
        $entries = BaInterventionProgress::with('recordedBy.user')
            ->where('incident_intervention_id', $model->id)
            ->orderByDesc('progress_date')
            ->orderByDesc('id')
            ->limit(200)
```

**Evidence**
```
$ grep -n 'limit(' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php
121:            ->limit(200)
```

Queries otherwise clean: the JSON log eager-loads `recordedBy.user` and runs no query inside the `map()`; the service `lock()` eager-loads `intervention` and `incident`; no query-in-loop anywhere (`grep -n 'foreach\|->map(' …BaInterventionCaseService.php` shows no query inside a loop).

### F10 — Views

clean — this controller renders no Blade view: it returns either a redirect with flash or `response()->json(...)`. `grep -oE "view\(['\"]" …BaInterventionCaseController.php` returns no output. The four partials that post to these routes (`_case-actions`, `_case-modals`, `_worklist`, `_interventions-applied`) are rendered by the incidents page, not here (see §8).

### F11 — Security and tenancy

clean — `grep -rn 'env(' …BaInterventionCaseController.php …BaInterventionCaseService.php …Http/Requests/BaInterventionCase*.php` returns no output (SEC-01); no hard-coded ids or `?? 1`; the JSON log returns mapped scalar fields (name, formatted dates, status text), not whole models (SEC-02); no request body or secret is logged; every route sits inside the tenancy middleware group and queries run against the tenant connection (`xyz_school_00000000000040008000_202627`).

### F12 — Style

#### BAIC-06 · L · STY-03 — the abbreviation `$v` as a local variable name

| Field | Value |
|---|---|
| **Rule** | STY-03 (L) — *variables camelCase and unabbreviated* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php:42-107` |
| **Root cause** | Five methods assign `$v = $request->validated()` and read it 18 times; `$v` is an abbreviation of "validated". |
| **Consequence** | Cosmetics only; the name is short and a reader must look up its origin. |
| **Reproduce** | Static only — style, proven by `grep` below. |
| **Fix approach** | Rename `$v` to `$validated` in the five methods; no logic changes. |
| **Plan item** | BAIC-06 in `02-fix-plan.md` §8 |

```php
// BaInterventionCaseController.php:42-48 — CURRENT (assign method)
        $v = $request->validated();

        return $this->run($request, 'assign', 'Case assigned.', fn () => $this->service->assign(
            $request->interventionCase(),
            isset($v['assigned_to']) ? (int) $v['assigned_to'] : null,
            $v['scheduled_date'] ?? null,
            $v['notes'] ?? null,
            $this->requireEmployee('assigned_to'),
        ));
```

**Evidence**
```
$ grep -n '\$v\b' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php
42:        $v = $request->validated();
46:            isset($v['assigned_to']) ? (int) $v['assigned_to'] : null,
…
107:            (string) $v['cancellation_reason'],
```

#### BAIC-07 · L · STY-02 — `BaInterventionCaseRequest.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, fully-qualified names imported* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionCaseRequest.php:7-11` and `:45` |
| **Root cause** | Line 45 uses the inline FQCN `\Illuminate\Validation\Rule`, which Pint's `fully_qualified_strict_types` wants imported, and the resulting import order then trips `ordered_imports`. |
| **Consequence** | Running `vendor/bin/pint` on this file rewrites it; a dirty diff appears for the next developer. |
| **Reproduce** | Run `vendor/bin/pint --test` on the file (output below). |
| **Fix approach** | Import `Illuminate\Validation\Rule` and use the short name at line 45. |
| **Plan item** | BAIC-07 in `02-fix-plan.md` §8 |

```php
// BaInterventionCaseRequest.php:7-11 — CURRENT
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Foundation\Http\FormRequest;
use Modules\BehaviouralAssessment\Models\BaIncidentInterventionJnt;
use Modules\BehaviouralAssessment\Services\BaInterventionCaseService;
use Modules\SchoolSetup\Models\Employee;
```

**Evidence**
```
$ vendor/bin/pint --test --format agent …BaInterventionCaseRequest.php…
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Http\/Requests\/BaInterventionCaseRequest.php","fixers":["fully_qualified_strict_types","ordered_imports"]}]}
```

`strict_types` is present on every in-scope PHP file (STY-01) and the other nine files are Pint-clean (the `--test` run reported only this one file).

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 overwrite data? | 2 delete before store? | 3 duplicate impl? | 4 soft-delete × unique? | 5 race? | 6 auth hole? | 7 message lie? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `assign` | ok | ok | ok | ok (`uq_guard`) | ok (`lockForUpdate`) | ok | ok | ok |
| `reassign` | ok | ok | ok | ok | ok (`lockForUpdate`) | ok | ok | ok |
| `start` | ok | ok | ok | ok | ok (`lockForUpdate`) | BAIC-03 | ok | ok |
| `addProgress` | ok | ok | ok | ok | ok (`lockForUpdate`) | ok | ok | ok |
| `complete` | ok | ok | ok | ok | ok (`lockForUpdate`) | ok | ok | ok |
| `cancel` | ok | ok | ok | ok | ok (`lockForUpdate`) | ok | ok | ok |

Notes: (1) each write sets only the columns its transition owns; `reassign` refreshes `assigned_by` even when only the due date changed, which is intended attribution. (2) nothing is deleted before its replacement is stored. (5) every mutating service method takes `lockForUpdate()` on the case row inside its transaction (`service line 321`), and `assign`'s "already owned" check reads the locked row. (7) the flash strings (`Case assigned.`/`Case reassigned.`/`Case started.`/`Progress note added.`/`Case completed.`/`Case cancelled.`) match their action. (8) progress rows written by `addProgress` are read back by `progressLog` — no dead feature.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php` (`currentEmployee()`, line 62) | Not memoised; re-queried per call. Root cause of BAIC-05. | SVC-05 | pending `BaIncidentController` report |
| `Modules/BehaviouralAssessment/app/Listeners/NotifyInterventionAssigned.php` | Not `ShouldQueue`; runs its `ba_notifications` write inside the post-commit request. Candidate JOB-04. | JOB-04 | pending `BaIncidentController` report |
| `Modules/SchoolSetup/app/Models/Employee.php` | Different-module model (common); used through the service, not audited here. | — | common, §4.2 |

## 8. Not covered, and why

- The four Blade partials that post to these routes (`pages/partials/incidents/_case-actions.blade.php`, `_case-modals.blade.php`, `_worklist.blade.php`, `_interventions-applied.blade.php`) are rendered by the incidents page (`BaIncidentController`/`BaDashboardController`), not by this controller; they are audited with that report (VIEW family).
- The service's out-of-scope collaborators listed in §3 rows 15–18 (`BaIncident`, `BaIncidentService`, `InterventionAssigned`, `NotifyInterventionAssigned`) were only read to measure how this controller's service uses them, and are claimed by the future `BaIncidentController` report.
- No queue worker or browser interaction was run: per D4 there is no test execution, so the trigger-to-422 branch (BAIC-02) and the progress/complete double lookup (BAIC-05) are proven statically, not by a request.
