# Fix Plan — BehaviouralAssessment / BaInterventionController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php` for developer `tarun`. It applies **only** ticked items, in this order.
> 5. No migration is needed for any item here. No new permission key is needed (all seven `tenant.behavioural-assessment.interventions.*` names already exist and are seeded).

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/BehaviouralAssessment/app/Support/BaActor.php` | owned by `tarun/BehaviouralAssessment-done/BaCommentBankController-done` |
| `Modules/BehaviouralAssessment/resources/views/**` | this controller's blades already compile and need no change (BIN-06 is fixed by the route verb alone) |
| `resources/views/components/backend/table/action-trashed.blade.php`, `action.blade.php`, `status-switch.blade.php`, `layouts/*`, `components/breadcrum*` | common components (§4.2) |
| `app/Helpers/activityLog.php`, `app/Traits/AuthorizesTenantFeature.php`, `bootstrap/app.php` | common app glue (§4.2) |
| `config/permissionslist.php` | shared file; no change is needed |
| `database/migrations/**` | never edit an existing migration |
| the six sibling BA controllers and their routes | other reports own them (module-wide RTE-01/ERR-00 patterns) |

## 1. Blockers reachable today

_None — 0 B-severity findings._ The highest finding, **BIN-06** (H, RTE-01), is a route re-scope and is therefore a DECISION in §9.

## 2. Fixes that arm a latent defect (sequenced)

_None._

## 3. Errors & transactions (F1/F2)

- [ ] **BIN-01** · M · ERR-00 (D1) + ERR-05 · `BaInterventionController.php:40-64` + the 6 sibling methods — remove the A1 `try/catch` from all seven mutating methods and drop the now-unused imports.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php`
  - **Before** (`BaInterventionController.php:7-18`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Http\Requests\BaInterventionRequest;
    use Modules\BehaviouralAssessment\Models\BaIntervention;
    use Modules\BehaviouralAssessment\Support\BaActor;
    ```
  - **After:**
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\BehaviouralAssessment\Http\Requests\BaInterventionRequest;
    use Modules\BehaviouralAssessment\Models\BaIntervention;
    use Modules\BehaviouralAssessment\Support\BaActor;
    ```
  - **Before** (`BaInterventionController.php:40-64`, inside `store`):
    ```php
        try {
            return DB::transaction(function () use ($request) {
                $record = BaIntervention::create($request->validated() + [
                    // Appended to the end; the list's drag-and-drop reorders it.
                    'sort_order' => BaIntervention::nextSortOrder(),
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Stored', ['message' => 'BaIntervention was stored.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'interventions'])
                    ->with('success', 'Intervention created successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaInterventionController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After** (`store`):
    ```php
        return DB::transaction(function () use ($request) {
            $record = BaIntervention::create($request->validated() + [
                // Appended to the end; the list's drag-and-drop reorders it.
                'sort_order' => BaIntervention::nextSortOrder(),
                'created_by' => BaActor::id(),
                'updated_by' => BaActor::id(),
            ]);

            activityLog($record, 'Stored', ['message' => 'BaIntervention was stored.']);

            return redirect()
                ->route('behavioural-assessment.masters', ['tab' => 'interventions'])
                ->with('success', 'Intervention created successfully.');
        });
    }
    ```
  - **Before** (`BaInterventionController.php:95-124`, inside `reorder`):
    ```php
        try {
            return DB::transaction(function () use ($validated) {
                $order = $validated['order'];
                $start = $validated['start'] ?? 1;

                foreach ($order as $offset => $id) {
                    BaIntervention::where('id', $id)->update([
                        'sort_order' => $start + $offset,
                        'updated_by' => BaActor::id(),
                    ]);
                }

                // One entry for the drag, not one per row moved.
                activityLog(BaIntervention::find($order[0]), 'Reordered', [
                    'message' => 'Interventions were reordered.',
                    'intervention_ids' => array_values($order),
                ]);

                return response()->json(['success' => true, 'message' => 'Order updated.']);
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaInterventionController::reorder failed', ['error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'The operation could not be completed.',
            ], 500);
        }
    ```
  - **After** (`reorder`):
    ```php
        return DB::transaction(function () use ($validated) {
            $order = $validated['order'];
            $start = $validated['start'] ?? 1;

            foreach ($order as $offset => $id) {
                BaIntervention::where('id', $id)->update([
                    'sort_order' => $start + $offset,
                    'updated_by' => BaActor::id(),
                ]);
            }

            // One entry for the drag, not one per row moved.
            activityLog(BaIntervention::find($order[0]), 'Reordered', [
                'message' => 'Interventions were reordered.',
                'intervention_ids' => array_values($order),
            ]);

            return response()->json(['success' => true, 'message' => 'Order updated.']);
        });
    }
    ```
  - **Before** (`BaInterventionController.php:139-159`, inside `update`):
    ```php
        try {
            return DB::transaction(function () use ($request, $id) {
                $intervention = BaIntervention::findOrFail($id);
                $intervention->update($request->validated() + ['updated_by' => BaActor::id()]);

                activityLog($intervention, 'Updated', ['message' => 'BaIntervention was updated.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'interventions'])
                    ->with('success', 'Intervention updated successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaInterventionController::update failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After** (`update`):
    ```php
        return DB::transaction(function () use ($request, $id) {
            $intervention = BaIntervention::findOrFail($id);
            $intervention->update($request->validated() + ['updated_by' => BaActor::id()]);

            activityLog($intervention, 'Updated', ['message' => 'BaIntervention was updated.']);

            return redirect()
                ->route('behavioural-assessment.masters', ['tab' => 'interventions'])
                ->with('success', 'Intervention updated successfully.');
        });
    }
    ```
  - **Before** (`BaInterventionController.php:166-194`, inside `destroy`):
    ```php
        try {
            return DB::transaction(function () use ($id) {
                $intervention = BaIntervention::findOrFail($id);

                if ($intervention->is_system) {
                    return back()->with('error', 'System interventions are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
                }

                $intervention->is_active = false;
                $intervention->updated_by = BaActor::id();
                $intervention->save();
                $intervention->delete();

                activityLog($intervention, 'Trashed', ['message' => 'BaIntervention was trashed.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'interventions'])
                    ->with('success', 'Intervention moved to trash.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaInterventionController::destroy failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After** (`destroy`):
    ```php
        return DB::transaction(function () use ($id) {
            $intervention = BaIntervention::findOrFail($id);

            if ($intervention->is_system) {
                return back()->with('error', 'System interventions are part of the behavioural framework and cannot be deleted. Deactivate it instead.');
            }

            $intervention->is_active = false;
            $intervention->updated_by = BaActor::id();
            $intervention->save();
            $intervention->delete();

            activityLog($intervention, 'Trashed', ['message' => 'BaIntervention was trashed.']);

            return redirect()
                ->route('behavioural-assessment.masters', ['tab' => 'interventions'])
                ->with('success', 'Intervention moved to trash.');
        });
    }
    ```
  - **Before** (`BaInterventionController.php:211-238`, inside `restore`):
    ```php
        try {
            return DB::transaction(function () use ($id) {
                $intervention = BaIntervention::onlyTrashed()->findOrFail($id);

                // The code key only covers live rows, so a newer intervention may have taken this code.
                if (BaIntervention::where('code', $intervention->code)->exists()) {
                    return back()->with('error', "Another intervention already uses the code {$intervention->code}. Change that intervention's code before restoring this one.");
                }

                $intervention->updated_by = BaActor::id();
                $intervention->restore();

                activityLog($intervention, 'Restored', ['message' => 'BaIntervention was restored.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'interventions'])
                    ->with('success', 'Intervention restored successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaInterventionController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After** (`restore`):
    ```php
        return DB::transaction(function () use ($id) {
            $intervention = BaIntervention::onlyTrashed()->findOrFail($id);

            // The code key only covers live rows, so a newer intervention may have taken this code.
            if (BaIntervention::where('code', $intervention->code)->exists()) {
                return back()->with('error', "Another intervention already uses the code {$intervention->code}. Change that intervention's code before restoring this one.");
            }

            $intervention->updated_by = BaActor::id();
            $intervention->restore();

            activityLog($intervention, 'Restored', ['message' => 'BaIntervention was restored.']);

            return redirect()
                ->route('behavioural-assessment.masters', ['tab' => 'interventions'])
                ->with('success', 'Intervention restored successfully.');
        });
    }
    ```
  - **Before** (`BaInterventionController.php:245-270`, inside `forceDelete`):
    ```php
        try {
            return DB::transaction(function () use ($id) {
                $intervention = BaIntervention::withTrashed()->findOrFail($id);

                if ($intervention->is_system) {
                    return back()->with('error', 'System interventions are part of the behavioural framework and cannot be deleted.');
                }

                $intervention->forceDelete();

                activityLog($intervention, 'Deleted', ['message' => 'BaIntervention was deleted.']);

                return redirect()
                    ->route('behavioural-assessment.interventions.trashed')
                    ->with('success', 'Intervention permanently deleted.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaInterventionController::forceDelete failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After** (`forceDelete`):
    ```php
        return DB::transaction(function () use ($id) {
            $intervention = BaIntervention::withTrashed()->findOrFail($id);

            if ($intervention->is_system) {
                return back()->with('error', 'System interventions are part of the behavioural framework and cannot be deleted.');
            }

            $intervention->forceDelete();

            activityLog($intervention, 'Deleted', ['message' => 'BaIntervention was deleted.']);

            return redirect()
                ->route('behavioural-assessment.interventions.trashed')
                ->with('success', 'Intervention permanently deleted.');
        });
    }
    ```
  - **Before** (`BaInterventionController.php:277-306`, inside `toggleStatus`):
    ```php
        try {
            return DB::transaction(function () use ($intervention) {
                $item = BaIntervention::findOrFail($intervention);
                $item->is_active = ! $item->is_active;
                $item->updated_by = BaActor::id();
                $item->save();

                activityLog($item, 'Toggled', ['message' => 'BaIntervention was toggled.']);

                return response()->json([
                    'success' => true,
                    'is_active' => $item->is_active,
                    'message' => $item->is_active ? 'Intervention activated.' : 'Intervention deactivated.',
                ]);

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaInterventionController::toggleStatus failed', ['error' => $e->getMessage()]);

            // Declared `: JsonResponse` — a redirect here was a TypeError, and the fetch() caller
            // would have followed it instead of seeing the failure.
            return response()->json([
                'success' => false,
                'message' => 'The operation could not be completed.',
            ], 500);
        }
    ```
  - **After** (`toggleStatus`):
    ```php
        return DB::transaction(function () use ($intervention) {
            $item = BaIntervention::findOrFail($intervention);
            $item->is_active = ! $item->is_active;
            $item->updated_by = BaActor::id();
            $item->save();

            activityLog($item, 'Toggled', ['message' => 'BaIntervention was toggled.']);

            return response()->json([
                'success' => true,
                'is_active' => $item->is_active,
                'message' => $item->is_active ? 'Intervention activated.' : 'Intervention deactivated.',
            ]);
        });
    }
    ```
  - **Verify:** `grep -cE 'catch \(|Log::error' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php`
  - **Expect:** `0`.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **BIN-04** · L · AUTH-04 · `BaInterventionController.php:38,137` — drop the duplicate controller `Gate::authorize` on `store` and `update`; keep the FormRequest `authorize()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php`
  - **Before** (`BaInterventionController.php:36-38`, `store`; apply after BIN-01):
    ```php
    public function store(BaInterventionRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.interventions.create');
    ```
  - **After:**
    ```php
    public function store(BaInterventionRequest $request): RedirectResponse
    {
        return DB::transaction(function () use ($request) {
    ```
  - **Before** (`BaInterventionController.php:135-138`, `update`; apply after BIN-01):
    ```php
    public function update(BaInterventionRequest $request, int $id): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.interventions.update');
    ```
  - **After:**
    ```php
    public function update(BaInterventionRequest $request, int $id): RedirectResponse
    {
        return DB::transaction(function () use ($request, $id) {
    ```
  - **Verify:** `grep -c "Gate::authorize('tenant.behavioural-assessment.interventions.create')\|Gate::authorize('tenant.behavioural-assessment.interventions.update')" Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php`
  - **Expect:** the `create` string is gone (0); the `update` string remains only in `reorder` :87 and `toggleStatus` :275.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **BIN-05** · M · VAL-02 · `BaInterventionController.php:85-93` — move `reorder()`'s inline validation into a Form Request.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionReorderRequest.php`, `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php`
  - **Before** (`BaInterventionController.php:85-93`, `reorder`; apply after BIN-01):
    ```php
    public function reorder(Request $request): JsonResponse
    {
        Gate::authorize('tenant.behavioural-assessment.interventions.update');

        $validated = $request->validate([
            'order' => ['required', 'array'],
            'order.*' => ['integer', 'distinct', 'exists:ba_interventions,id'],
            'start' => ['nullable', 'integer', 'min:1'],
        ]);
    ```
  - **After** (controller `reorder`):
    ```php
    public function reorder(BaInterventionReorderRequest $request): JsonResponse
    {
        $validated = $request->validated();
    ```
  - **Before** (`BaInterventionController.php:16`, imports):
    ```php
    use Modules\BehaviouralAssessment\Http\Requests\BaInterventionRequest;
    ```
  - **After:**
    ```php
    use Modules\BehaviouralAssessment\Http\Requests\BaInterventionReorderRequest;
    use Modules\BehaviouralAssessment\Http\Requests\BaInterventionRequest;
    ```
  - **After** (new file `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionReorderRequest.php`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\BehaviouralAssessment\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Support\Facades\Gate;

    class BaInterventionReorderRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return Gate::allows('tenant.behavioural-assessment.interventions.update');
        }

        public function rules(): array
        {
            return [
                'order' => ['required', 'array'],
                'order.*' => ['integer', 'distinct', 'exists:ba_interventions,id'],
                'start' => ['nullable', 'integer', 'min:1'],
            ];
        }
    }
    ```
  - **Verify:** `grep -n "request->validate(" Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BIN-07** · M · CTL-03 · `BaInterventionController.php:67-73,127-133` — bind the read methods to the route model instead of `$id` + `findOrFail`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php`
  - **Before** (`BaInterventionController.php:67-73`, `show`):
    ```php
    public function show(int $id): View
    {
        Gate::authorize('tenant.behavioural-assessment.interventions.view');
        $intervention = BaIntervention::findOrFail($id);

        return view('behaviouralassessment::intervention.show', compact('intervention'));
    }
    ```
  - **After:**
    ```php
    public function show(BaIntervention $intervention): View
    {
        Gate::authorize('tenant.behavioural-assessment.interventions.view');

        return view('behaviouralassessment::intervention.show', compact('intervention'));
    }
    ```
  - **Before** (`BaInterventionController.php:127-133`, `edit`):
    ```php
    public function edit(int $id): View
    {
        Gate::authorize('tenant.behavioural-assessment.interventions.update');
        $intervention = BaIntervention::findOrFail($id);

        return view('behaviouralassessment::intervention.edit', compact('intervention'));
    }
    ```
  - **After:**
    ```php
    public function edit(BaIntervention $intervention): View
    {
        Gate::authorize('tenant.behavioural-assessment.interventions.update');

        return view('behaviouralassessment::intervention.edit', compact('intervention'));
    }
    ```
  - **Also (when applying BIN-01):** in `update`, `destroy` and `toggleStatus`, change the parameter to `BaIntervention $intervention` (`update(BaInterventionRequest $request, BaIntervention $intervention)`) and delete the in-closure `BaIntervention::findOrFail(...)` line. `restore` and `forceDelete` keep `int $id` because their custom routes declare `{id}` and need `onlyTrashed()`/`withTrashed()` (changing those route parameters is out of scope).
  - **Verify:** `grep -nE 'function (show|edit)\(' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php`
  - **Expect:** both signatures read `BaIntervention $intervention`.
  - **Effort:** S

- [ ] **BIN-09** · L · MDL-01 · `BaIntervention.php:23-36` — remove `is_system` from `$fillable` (the seeder writes via the query builder, so nothing breaks).
  - **Touches:** `Modules/BehaviouralAssessment/app/Models/BaIntervention.php`
  - **Before** (`BaIntervention.php:23-36`):
    ```php
    protected $fillable = [
        'code',
        'name',
        'description',
        'intervention_type',
        'default_due_days',
        'requires_owner',
        'requires_parent_meeting',
        'sort_order',
        'is_system',
        'is_active',
        'created_by',
        'updated_by',
    ];
    ```
  - **After:**
    ```php
    protected $fillable = [
        'code',
        'name',
        'description',
        'intervention_type',
        'default_due_days',
        'requires_owner',
        'requires_parent_meeting',
        'sort_order',
        'is_active',
        'created_by',
        'updated_by',
    ];
    ```
  - **Verify:** `grep -n "'is_system'" Modules/BehaviouralAssessment/app/Models/BaIntervention.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

_None in this section — BIN-10 is a DECISION (§9) because the loop is bounded to the 10-row page._

## 7. Views (F10)

_None — the blades need no change._

## 8. Style (F12) — one item per file

- [ ] **BIN-11** · L · STY-02 · `BaIntervention.php:7-9,55` — make the model Pint-clean by importing `BelongsToMany`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Models/BaIntervention.php`
  - **Before** (`BaIntervention.php:7-9`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **After:**
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsToMany;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Before** (`BaIntervention.php:55`):
    ```php
    public function incidents(): \Illuminate\Database\Eloquent\Relations\BelongsToMany
    ```
  - **After:**
    ```php
    public function incidents(): BelongsToMany
    ```
  - **Verify:** `vendor/bin/pint Modules/BehaviouralAssessment/app/Models/BaIntervention.php --test --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}` (or no `fail` block).
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BIN-06** · H · DECISION · RTE-01 · ⚠ SHARED — `restore` changes state over GET (`routes/web.php:51`). Fix the verb?
  - **Why it is a decision:** changing an existing route's HTTP verb is a route re-scope (D3), and the same GET-restore pattern is module-wide across `BaCategory`, `BaRatingScale`, `BaCommentBank`. The `action-trashed` component already auto-detects the verb and emits `@csrf` for a non-GET route, so no view change is needed.
  - (a) ⭐ Change **this** route now: `Route::get('interventions/{id}/restore', ...)` → `Route::post('interventions/{id}/restore', ...)` (keep the name). One line in `routes/web.php`; the trash button keeps working.
  - (b) Fix the whole module's GET-restore routes in one pass (siblings too), and keep this report's line as part of it.
  - (c) Accept the risk; record it as known CSRF-susceptible.
  - ➜ Choice: ____

- [ ] **BIN-03** · M · DECISION · TXN-06 — `nextSortOrder()` = `max(sort_order) + 1` with no lock or unique index (`BaIntervention.php:89-92`).
  - **Why it is a decision:** a strict fix needs a migration (unique index on `sort_order`) or a locking query, and the impact is only a duplicate display position.
  - (a) ⭐ Accept — all 12 rows are seeded; creation is rare and a tie only affects the order of two same-moment rows.
  - (b) Add a unique index on `sort_order` via an additive migration and retry on conflict (needs `php artisan tenants:migrate` — Tarun's hand).
  - (c) Wrap the `max()` read with `lockForUpdate()` inside the `store` transaction (narrows the window; does not remove it without the index).
  - ➜ Choice: ____

- [ ] **BIN-10** · M · DECISION · QRY-01 — `reorder()` issues one UPDATE per dragged row (`BaInterventionController.php:100-105`).
  - **Why it is a decision:** a correct bulk write is a `CASE`/`upsert` statement, not a mechanical edit, and the loop is bounded by the 10-row page.
  - (a) ⭐ Accept — at most 10 UPDATEs per drag today; revisit if the page size rises.
  - (b) Replace the loop with one `BaIntervention::upsert([...], ['id'], ['sort_order', 'updated_by'])` keyed by the validated ids.
  - (c) Replace it with a single bound `DB::update('UPDATE ba_interventions SET sort_order = CASE id WHEN ? THEN ? ... END ...', $bindings)`.
  - ➜ Choice: ____

- [ ] **BIN-12** · M · DECISION · F13 (deep-read #1/#7) — `destroy()` deactivates then soft-deletes; `restore()` returns the row **inactive** while the flash says "restored successfully" (`BaInterventionController.php:174-177` vs `:220-227`).
  - **Why it is a decision:** it changes what a user sees after a restore, so Tarun must decide the intended behaviour.
  - (a) ⭐ Set `is_active = true` in `restore()` so restoring undoes the trash deactivation.
  - (b) Leave it inactive and change the flash to "Intervention restored. It is inactive — switch it on to use it."
  - (c) Accept — restoring always lands inactive by design.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BIN-02 | Accepted for this pass: `DB::transaction()` returns the closure's value unchanged, so building the response inside the closure is behaviourally identical. The non-behavioural refactor (return the model/count, build the response after) is deferred to the D3 pass. |
| BIN-08 | Informational: the standalone `create()` page duplicates the Masters create modal. Removing it is a route change (D3) and is deferred to the split pass; recorded, not applied. |
