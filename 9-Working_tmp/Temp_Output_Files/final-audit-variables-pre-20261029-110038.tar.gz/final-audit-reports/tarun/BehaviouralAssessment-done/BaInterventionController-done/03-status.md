# Status — BehaviouralAssessment / BaInterventionController

**Fixed:** 2026-10-22 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work

No `PRE-APPLIED-*.md` lists a file in this controller's scope — none copied.

Pre-applied by the orchestrator on **2026-10-22** (not edited by this fixer, per instruction):

| Item | File:line | Change | Proof |
|---|---|---|---|
| BIN-06(a) | `Modules/BehaviouralAssessment/routes/web.php:48` | `Route::get('interventions/{id}/restore', …)` → `Route::post('interventions/{id}/restore', …)` (name kept: `interventions.restore`) | `route:list` now prints `POST behavioural-assessment/interventions/{id}/restore` (see §6) |

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| BIN-01 | `BaInterventionController.php:7-12`, `36-50`, `73-92`, `103-112`, `118-134`, `150-170`, `176-191`, `197-210` | Removed the A1 `try/catch` from all seven mutating methods (`store`, `reorder`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`); dropped the now-unused `ModelNotFoundException` and `Log` imports. The transaction body is now the method's return, so the central handler in `bootstrap/app.php` renders failures (D1). | `grep -cE 'catch \(|Log::error' …BaInterventionController.php` | `0` | 2026-10-22 |
| BIN-04 | `BaInterventionController.php:34-36`, `101-103` | Dropped the duplicate controller `Gate::authorize` on `store` (`.create`) and `update` (`.update`); the FormRequest `authorize()` remains the gate for both. | `grep -c "Gate::authorize('…interventions.create')\|Gate::authorize('…interventions.update')" …` | `3` — `:29` (create page), `:96` (edit), `:195` (toggleStatus). `store`/`update` are gone (see §6 note). | 2026-10-22 |
| BIN-05 | `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionReorderRequest.php` (new), `BaInterventionController.php:13`, `69-73` | Moved `reorder()`'s inline validation into `BaInterventionReorderRequest` (same three rules, `authorize()` = `Gate::allows('tenant.behavioural-assessment.interventions.update')`), used `$request->validated()`, and removed the then-unused `Illuminate\Http\Request` import. | `grep -n "request->validate(" …BaInterventionController.php` | no output | 2026-10-22 |
| BIN-07 | `BaInterventionController.php:52-57`, `94-99`, `101-104`, `114-118`, `193-197` | Route model binding: `show`/`edit` take `BaIntervention $intervention`; per the item's **Also**, `update`, `destroy` and `toggleStatus` now take `BaIntervention $intervention` and their in-closure `findOrFail` lines are deleted. `restore`/`forceDelete` keep `int $id` (custom `{id}` routes, `onlyTrashed()`/`withTrashed()`). `toggleStatus`'s local `$item` was renamed to `$intervention` so the body compiles. | `grep -nE 'function (show\|edit)\(' …` | both signatures read `BaIntervention $intervention` | 2026-10-22 |
| BIN-09 | `Modules/BehaviouralAssessment/app/Models/BaIntervention.php:23-36` | Removed `'is_system'` from `$fillable`. Seeder writes via `DB::table('ba_interventions')->insert(...)`, so it is unaffected. | `grep -n "'is_system'" …BaIntervention.php` | `42:        'is_system' => 'boolean',` — the `$casts` entry only (see §6 note; the plan's After keeps that cast) | 2026-10-22 |
| BIN-11 | `Modules/BehaviouralAssessment/app/Models/BaIntervention.php:8,55` | Imported `Illuminate\Database\Eloquent\Relations\BelongsToMany`; `incidents()` return type is now `BelongsToMany`. | `vendor/bin/pint …BaIntervention.php --test --format agent` | `{"tool":"pint","result":"passed"}` | 2026-10-22 |
| BIN-12(a) | `BaInterventionController.php:158-162` | `restore()` now sets `is_active = true` before `restore()`, so a restored row is usable again (destroy deactivates before soft-deleting). Comment cites BIN-12 + date. | `grep -n "is_active = true" …` | `160:            $intervention->is_active = true;` | 2026-10-22 |

## 3. Not applied

| ID | Reason (not ticked / already applied / superseded / blocked) | Detail |
|---|---|---|
| BIN-06 | already applied — pre-applied by the orchestrator 2026-10-22 | Approved choice (a): the route is already `Route::post('interventions/{id}/restore', …)`. Verified, not edited (§1, §6). |
| BIN-03 | decision (a) — accept; no code change | `nextSortOrder()` keeps `max(sort_order) + 1` with no lock/unique index. All 12 rows are seeded and creation is rare; a tie only affects the display order of two same-moment rows. Recorded as accepted. |
| BIN-10 | decision (a) — accept; no code change | `reorder()` keeps one `UPDATE` per dragged row — bounded by the 10-row page. Revisit if the page size rises. Recorded as accepted. |
| BIN-02 | no plan item (§10 of the plan) | Accepted for this pass; `DB::transaction()` returns the closure value unchanged, so building the response inside the closure is behaviourally identical. Non-behavioural refactor deferred to the D3 pass. |
| BIN-08 | no plan item (§10 of the plan) | Informational: the standalone `create()` page duplicates the Masters create modal. Removing it is a route change (D3) — deferred to the split pass. |

## 4. Needs Tarun's hand

- **Browser check (screen-level, D4 forbids it here):** open `/behavioural-assessment/interventions/trash`, press **Restore** on a trashed row — the button must POST (it already emits `@csrf` because `action-trashed` detects the verb) and the restored row must come back **active** (BIN-12(a)). Also confirm drag-and-drop reorder still saves (BIN-05 moved its validation into a FormRequest).
- **No migration, no seeder, no new permission key, no `sync-permissions` run** is needed for these items.
- **Folder rename §10.1 (`BaInterventionController` → `BaInterventionController-done`) not done:** this module's other `FIXED` folders keep their plain names, and this run was asked to write `…/BaInterventionController/03-status.md`. Rename when the module convention is decided.

## 5. Unverifiable by this workflow (no tests, D4)

- The GET→POST restore fix (BIN-06) is only provable by a browser click / prefetch attempt; `route:list` proves the verb, not the CSRF behaviour of the trash button.
- BIN-12(a) re-activation after restore needs a real trashed row and a click; no test was written (D4).
- BIN-05's `authorize()` refusal path (a role without `.update` posting to `reorder`) is not exercised — no seeded role is available to prove the 403 in this workflow.

## 6. Verification log

```
$ php -l Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
$ php -l Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionReorderRequest.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionReorderRequest.php
$ php -l Modules/BehaviouralAssessment/app/Models/BaIntervention.php
No syntax errors detected in Modules/BehaviouralAssessment/app/Models/BaIntervention.php

$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); var_dump(class_exists(Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController::class)); var_dump(class_exists(Modules\BehaviouralAssessment\Http\Requests\BaInterventionReorderRequest::class)); var_dump(class_exists(Modules\BehaviouralAssessment\Models\BaIntervention::class));'
bool(true)
bool(true)
bool(true)

$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json >/dev/null && echo ROUTES-OK
ROUTES-OK

$ vendor/bin/pint Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionReorderRequest.php Modules/BehaviouralAssessment/app/Models/BaIntervention.php --format agent
{"tool":"pint","result":"passed"}

# re-run after Pint
$ php -l … (all three)  → No syntax errors detected (×3)
$ class_exists …        → bool(true) bool(true) bool(true)

# BIN-01
$ grep -cE 'catch \(|Log::error' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
0

# BIN-04
$ grep -c "Gate::authorize('tenant.behavioural-assessment.interventions.create')\|Gate::authorize('tenant.behavioural-assessment.interventions.update')" Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
3
$ grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
22:        Gate::authorize('tenant.behavioural-assessment.interventions.viewAny');
29:        Gate::authorize('tenant.behavioural-assessment.interventions.create');
54:        Gate::authorize('tenant.behavioural-assessment.interventions.view');
96:        Gate::authorize('tenant.behavioural-assessment.interventions.update');
116:        Gate::authorize('tenant.behavioural-assessment.interventions.delete');
138:        Gate::authorize('tenant.behavioural-assessment.interventions.restore');
148:        Gate::authorize('tenant.behavioural-assessment.interventions.restore');
174:        Gate::authorize('tenant.behavioural-assessment.interventions.forceDelete');
195:        Gate::authorize('tenant.behavioural-assessment.interventions.update');

# BIN-05
$ grep -n "request->validate(" Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
(no output)

# BIN-07
$ grep -nE 'function (show|edit)\(' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
52:    public function show(BaIntervention $intervention): View
94:    public function edit(BaIntervention $intervention): View

# BIN-09
$ grep -n "'is_system'" Modules/BehaviouralAssessment/app/Models/BaIntervention.php
42:        'is_system' => 'boolean',
$ sed -n '23,37p' Modules/BehaviouralAssessment/app/Models/BaIntervention.php
    protected $fillable = [
        'code',
        'name',
        'description',
        'intervention_type',
        'default_due_days',
        'requires_owner',
        'requires_parent_meeting',
        'sort_order',
        'is_active',
        'created_by',
        'updated_by',
    ];

# BIN-11
$ vendor/bin/pint Modules/BehaviouralAssessment/app/Models/BaIntervention.php --test --format agent
{"tool":"pint","result":"passed"}
$ grep -n "BelongsToMany" Modules/BehaviouralAssessment/app/Models/BaIntervention.php
8:use Illuminate\Database\Eloquent\Relations\BelongsToMany;
55:    public function incidents(): BelongsToMany

# BIN-06 (pre-applied — verified only)
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '…BaInterventionController@restore…'
POST    behavioural-assessment/interventions/{id}/restore    behavioural-assessment.interventions.restore
$ grep -n "interventions/{id}/restore" Modules/BehaviouralAssessment/routes/web.php
48:Route::post('interventions/{id}/restore', [BaInterventionController::class, 'restore'])->name('interventions.restore');

# BIN-12
$ grep -n "is_active = true" Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
160:            $intervention->is_active = true;

# scanner after (in-scope files only) — remaining rows are accepted/deferred findings
$ php final-audit-reports/_tools/scan.php . /tmp/fa-routes.json /tmp/fa-bin-after.json
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-bin-after.json <3 in-scope files>
M  TXN-05  …BaInterventionController.php:46   store — HTTP response built inside DB::transaction closure
H  QRY-01  …BaInterventionController.php:78   reorder — BaIntervention::where() inside a loop — N+1 query
M  TXN-05  …BaInterventionController.php:90   reorder — HTTP response built inside DB::transaction closure
M  TXN-05  …BaInterventionController.php:108  update — HTTP response built inside DB::transaction closure
M  TXN-05  …BaInterventionController.php:120  destroy — HTTP response built inside DB::transaction closure
M  CTL-03  …BaInterventionController.php:146  restore — restore($id) + findOrFail — use route model binding
M  TXN-05  …BaInterventionController.php:155  restore — HTTP response built inside DB::transaction closure
M  CTL-03  …BaInterventionController.php:172  forceDelete — forceDelete($id) + findOrFail — use route model binding
M  TXN-05  …BaInterventionController.php:180  forceDelete — HTTP response built inside DB::transaction closure
M  TXN-05  …BaInterventionController.php:204  toggleStatus — HTTP response built inside DB::transaction closure
10 scanner rows for 3 path(s). Candidates only — confirm each in source (§6).
```

Scan diff notes: the ERR-01/ERR-00 rows for all seven mutating methods are gone; the
`CTL-03` rows for `show`/`edit` are gone. The `TXN-05` rows are **BIN-02** (accepted, plan §10);
`QRY-01` on the reorder loop is **BIN-10(a)** (accepted); the two remaining `CTL-03` rows
(`restore`, `forceDelete`) are out of scope by the plan's BIN-07 note. Nothing new was introduced.

Two plan `Expect` lines did not match reality because the plan's expectations predate later items
in the same plan; the code matches the plan's **After** blocks, not the stale expectations:

- BIN-04 `Expect` said the count is 0 for `create` and that `update` "remains only in reorder :87
  and toggleStatus :275". Actual count is 3: `create` legitimately remains in `create()` (`:29`);
  `update` remains in `edit()` (`:96`) and `toggleStatus` (`:195`), while `reorder`'s gate moved
  into `BaInterventionReorderRequest` (BIN-05). `store`/`update` no longer carry a duplicate gate.
- BIN-09 `Expect` said `grep -n "'is_system'"` prints nothing. It prints the `$casts` line
  (`:42`), which the plan's own After block keeps. Only `$fillable` was in scope, and it is removed.

## 7. Final state

Status: **FIXED** · Open: B 0 · H 0 · M 0 · L 0

Accepted / deferred, not open work: BIN-03(a) accepted, BIN-10(a) accepted, BIN-02 and BIN-08
deferred to the D3/split pass. All 10 plan items are accounted for (§2 applied, §3 decisions and
pre-applied).
