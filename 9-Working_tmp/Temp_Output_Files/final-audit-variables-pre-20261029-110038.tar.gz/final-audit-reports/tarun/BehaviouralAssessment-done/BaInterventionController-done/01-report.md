# Final Audit — BehaviouralAssessment / BaInterventionController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php` (308 lines, 12 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/behavioural-assessment/interventions` (index → redirects to `/behavioural-assessment/masters?tab=interventions`) · `/behavioural-assessment/interventions/create` · `/behavioural-assessment/interventions/{id}` · `/behavioural-assessment/interventions/{id}/edit` · `/behavioural-assessment/interventions/trash` · `POST /behavioural-assessment/interventions/reorder` · `POST /behavioural-assessment/interventions/{id}/toggle-status` · `GET /behavioural-assessment/interventions/{id}/restore` · `DELETE /behavioural-assessment/interventions/{id}/force-delete` |
| Menu path | Behavioural Assessment → Masters → **Interventions** tab |
| Who uses it | School admins/coordinators. Every one of the seven `tenant.behavioural-assessment.interventions.*` permissions is seeded and held by **2** roles (measured in `sys_role_has_permissions_jnt`). |
| What a user does here | An "intervention" is a reusable action staff can assign to a behavioural incident (reward / corrective / counselling). The Masters tab lists them (paginated 10); a user creates one in a modal, edits one, drags rows to re-order, flips Active/Inactive, and soft-deletes to the trash, from which they can restore or permanently delete. Seeded "system" interventions cannot be deleted. |
| Tables written | `ba_interventions` (every mutation), `sys_activity_logs` (every mutation via `activityLog()`), `ba_incident_intervention_jnt` (pivot detach on permanent delete only) |
| Tables read | `ba_interventions`; `sys_users` (actor lookup by `BaActor`) |
| Live data | `ba_interventions` **12 live, 0 trashed** (all 12 are `is_system = 1`, so `destroy`/`forceDelete` are currently refused on every row) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Production-ready **only after the route fix and the medium items**. There are **0 blockers (B)** and **1 HIGH**: the restore endpoint changes state over **GET** (`BIN-06`), so any link-prefetcher, `<img>` tag or CSRF-exempt third party can restore a trashed row without a token. The controller is otherwise small, well-gated, fully transactional and cleanly paginated. The single broadest defect is `BIN-01` (M): all seven mutating methods keep the old house-rule A1 `try/catch` that D1/D2 disallow, and each catch logs only `$e->getMessage()` (trace lost). Rough effort: **S–M, half a day** for the four tickable code items plus three small decisions.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 7 | 4 | 4 | 12 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BIN-01 | F8 Services/Jobs | clean — no service/job referenced (see below) |
| F2 Transactions/Audit | BIN-02, BIN-03 | F9 Queries/Perf | BIN-10 |
| F3 Authorization | BIN-04 | F10 Views | clean — see F10 below |
| F4 Validation | BIN-05 | F11 Security/Tenancy | clean — see F11 below |
| F5 Routes | BIN-06 | F12 Style | BIN-11 |
| F6 Controller shape | BIN-07, BIN-08 | F13 Deep read | BIN-12 |
| F7 Models | BIN-09 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php` | controller | 308 | this report | ✅ whole class |
| 2 | `Modules/BehaviouralAssessment/app/Models/BaIntervention.php` | model | 93 | this report (first reacher — owns; also reached by the later BaIncidentController report) | ✅ whole class |
| 3 | `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionRequest.php` | FormRequest | 82 | this report (only this controller uses it) | ✅ whole class |
| 4 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | 45 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked (usage checked here) |
| 5 | `Modules/BehaviouralAssessment/resources/views/intervention/create.blade.php` | view | 117 | this report | ✅ |
| 6 | `Modules/BehaviouralAssessment/resources/views/intervention/edit.blade.php` | view | 125 | this report | ✅ |
| 7 | `Modules/BehaviouralAssessment/resources/views/intervention/show.blade.php` | view | 96 | this report | ✅ |
| 8 | `Modules/BehaviouralAssessment/resources/views/intervention/trash.blade.php` | view | 77 | this report | ✅ |
| 9 | `Modules/BehaviouralAssessment/resources/views/intervention/_case-fields.blade.php` | view partial (included by 5 and 6) | 38 | this report | ✅ |
| 10 | `Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionReorderRequest.php` | FormRequest | new | this report | created by plan item `BIN-05` |

Not in scope (documented, not audited): `intervention/_create-fields.blade.php` is included only by the Masters modal (`pages/partials/masters/_interventions-create-modal.blade.php`), which `BaDashboardController::masters` renders — not this controller. The layout and the `<x-backend.*>` components (`layouts.app`, `components.breadcrum`, `form.input-text`, `form.status-switch`, `form.button-submit`, `table.action-trashed`, `table.action`, `table.status-switch`) are common classes (§4.2).

No pre-applied files.

## 4. Routes

```
GET|HEAD           behavioural-assessment/interventions                       behavioural-assessment.interventions.index         Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@index
POST               behavioural-assessment/interventions                       behavioural-assessment.interventions.store         Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@store
GET|HEAD           behavioural-assessment/interventions/create                behavioural-assessment.interventions.create        Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@create
POST               behavioural-assessment/interventions/reorder               behavioural-assessment.interventions.reorder       Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@reorder
GET|HEAD           behavioural-assessment/interventions/trash                 behavioural-assessment.interventions.trashed       Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@trashed
DELETE             behavioural-assessment/interventions/{id}/force-delete     behavioural-assessment.interventions.forceDelete   Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@forceDelete
GET|HEAD           behavioural-assessment/interventions/{id}/restore          behavioural-assessment.interventions.restore       Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@restore
GET|HEAD           behavioural-assessment/interventions/{intervention}        behavioural-assessment.interventions.show          Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@show
PUT|PATCH          behavioural-assessment/interventions/{intervention}        behavioural-assessment.interventions.update        Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@update
DELETE             behavioural-assessment/interventions/{intervention}        behavioural-assessment.interventions.destroy       Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@destroy
GET|HEAD           behavioural-assessment/interventions/{intervention}/edit   behavioural-assessment.interventions.edit          Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@edit
POST               behavioural-assessment/interventions/{intervention}/toggle-status behavioural-assessment.interventions.toggleStatus  Modules\BehaviouralAssessment\Http\Controllers\BaInterventionController@toggleStatus
```

Unrouted public methods: **none** (all 12 public methods are routed). All routes carry `web` + `PreventAccessFromCentralDomains` + `InitializeTenancyByDomain` + `EnsureTenantIsActive` + `EnsureTenantHasModule:BehaviouralAssessment` + `auth` + `verified`.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 22 | GET `interventions` | `tenant.behavioural-assessment.interventions.viewAny` | — | — | — | none |
| `create` | 29 | GET `interventions/create` | `tenant.behavioural-assessment.interventions.create` | — | — | — | BIN-08 |
| `store` | 36 | POST `interventions` | `.create` (FormRequest also) | controller :41 | 'Stored' | `ba_interventions`, `sys_activity_logs` | BIN-01, BIN-02, BIN-04 |
| `show` | 67 | GET `interventions/{intervention}` | `.view` | — | — | — | BIN-07 |
| `reorder` | 85 | POST `interventions/reorder` | `.update` | controller :96 | 'Reordered' | `ba_interventions`, `sys_activity_logs` | BIN-01, BIN-02, BIN-05, BIN-10 |
| `edit` | 127 | GET `interventions/{intervention}/edit` | `.update` | — | — | — | BIN-07 |
| `update` | 135 | PUT/PATCH `interventions/{intervention}` | `.update` (FormRequest also) | controller :140 | 'Updated' | `ba_interventions`, `sys_activity_logs` | BIN-01, BIN-02, BIN-04, BIN-07 |
| `destroy` | 162 | DELETE `interventions/{intervention}` | `.delete` | controller :167 | 'Trashed' | `ba_interventions`, `sys_activity_logs` | BIN-01, BIN-02, BIN-07, BIN-12 |
| `trashed` | 197 | GET `interventions/trash` | `.restore` | — | — | — | none |
| `restore` | 207 | GET `interventions/{id}/restore` | `.restore` | controller :212 | 'Restored' | `ba_interventions`, `sys_activity_logs` | BIN-01, BIN-02, BIN-06, BIN-07, BIN-12 |
| `forceDelete` | 241 | DELETE `interventions/{id}/force-delete` | `.forceDelete` | controller :246 | 'Deleted' | `ba_interventions`, `ba_incident_intervention_jnt`, `sys_activity_logs` | BIN-01, BIN-02, BIN-07 |
| `toggleStatus` | 273 | POST `interventions/{intervention}/toggle-status` | `.update` | controller :278 | 'Toggled' | `ba_interventions`, `sys_activity_logs` | BIN-01, BIN-02 |

## 6. Findings

### F1 — Errors

#### BIN-01 · M · ERR-00 (D1) + ERR-05 — every mutation keeps a non-D2 `try/catch` that logs only the exception message

| Field | Value |
|---|---|
| **Rule** | ERR-00 (D1: the Laravel idiom — **no `try/catch` in controllers**; `DB::transaction(fn …)` rolls back and the central handler in `bootstrap/app.php` renders) + ERR-05 (M) — *log the exception, not the message* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php:40-64` (`store`); the same shape repeats in `reorder` :95-124, `update` :139-159, `destroy` :166-194, `restore` :211-238, `forceDelete` :245-270, `toggleStatus` :277-306 |
| **Root cause** | The controller predates the settled D1 decision and still carries the old house-rule A1 pattern: a `try { DB::transaction(...) } catch (ModelNotFoundException) { throw } catch (\Throwable) { Log::error(..., ['error' => $e->getMessage()]); return back()->with(...) }`. None of these catches is one of the four D2-allowed shapes. The first catch is also dead weight — `findOrFail()` is inside the `try` but the rethrow restores the 404. Each catch logs only the message string, so the stack trace is lost. |
| **Consequence** | When a write fails, the operator sees a generic flash and the log has one line with no trace, so the failure cannot be diagnosed; and the seven near-identical blocks are copy-paste debt. |
| **Reproduce** | static only — the catches only fire on a DB error; the shape is proven by `grep` (below). |
| **Fix approach** | Adopt D1: delete the `try`/both `catch` clauses from all seven methods, keep `return DB::transaction(...)`, and let the central exception handler render (it already returns JSON for the two `Accept: application/json` callers). Remove the now-unused `ModelNotFoundException` and `Log` imports. |
| **Plan item** | BIN-01 in `02-fix-plan.md` §3 |

```php
// BaInterventionController.php:40-64 — CURRENT (store); the same shape is in 6 more methods
        try {
            return DB::transaction(function () use ($request) {
                $record = BaIntervention::create($request->validated() + [
                    // Appended to the end; the list's drag-and-drop reorders it.
                    'sort_order' => BaIntervention::nextSortOrder(),
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Stored', ['message' => 'BaIntervention was stored.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'interventions'])
                    ->with('success', 'Intervention created successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaInterventionController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -nE 'try \{|catch \(|Log::error' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
40:        try {
56:        } catch (ModelNotFoundException $e) {
60:        } catch (\Throwable $e) {
61:            Log::error('BaInterventionController::store failed', ['error' => $e->getMessage()]);
95:        try {
115:        } catch (ModelNotFoundException $e) {
117:        } catch (\Throwable $e) {
118:            Log::error('BaInterventionController::reorder failed', ['error' => $e->getMessage()]);
139:        try {
151:        } catch (ModelNotFoundException $e) {
155:        } catch (\Throwable $e) {
156:            Log::error('BaInterventionController::update failed', ['error' => $e->getMessage()]);
166:        try {
186:        } catch (ModelNotFoundException $e) {
190:        } catch (\Throwable $e) {
191:            Log::error('BaInterventionController::destroy failed', ['error' => $e->getMessage()]);
211:        try {
230:        } catch (ModelNotFoundException $e) {
234:        } catch (\Throwable $e) {
235:            Log::error('BaInterventionController::restore failed', ['error' => $e->getMessage()]);
245:        try {
262:        } catch (ModelNotFoundException $e) {
266:        } catch (\Throwable $e) {
267:            Log::error('BaInterventionController::forceDelete failed', ['error' => $e->getMessage()]);
277:        try {
293:        } catch (ModelNotFoundException $e) {
297:        } catch (\Throwable $e) {
298:            Log::error('BaInterventionController::toggleStatus failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### BIN-02 · M · TXN-05 — the transaction closure builds the HTTP response itself

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()`/`response()` after it* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php:51-55` (`store`); also `reorder` :113, `update` :146-148, `destroy` :181-183, `restore` :225-227, `forceDelete` :257-259, `toggleStatus` :286-290 |
| **Root cause** | Each `DB::transaction(function () …)` closure ends with `return redirect()...` / `return response()->json(...)` instead of returning a model/count. It works because `DB::transaction` returns the closure's value, but the response is assembled before COMMIT. |
| **Consequence** | A COMMIT failure would still have produced the success payload a moment earlier; the payload is not built after the write is durable. |
| **Reproduce** | static only — no commit failure path is reachable without fault injection (D4). |
| **Fix approach** | Accepted as cosmetic for this pass: `DB::transaction()` returns the closure value unchanged, so behaviour is identical. Moving every response out is a non-behavioural refactor deferred to the D3 pass (see plan §10). |
| **Plan item** | none — see plan §10 |

```php
// BaInterventionController.php:51-55 — CURRENT
                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'interventions'])
                    ->with('success', 'Intervention created successfully.');

            });
```

**Evidence**
```
$ grep -nE 'return (redirect|response)\(\)' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
51:                return redirect()
113:                return response()->json(['success' => true, 'message' => 'Order updated.']);
146:                return redirect()
181:                return redirect()
225:                return redirect()
257:                return redirect()
286:                return response()->json([
$ grep -n 'DB::transaction' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
41:            return DB::transaction(function () use ($request) {
96:            return DB::transaction(function () use ($validated) {
140:            return DB::transaction(function () use ($request, $id) {
167:            return DB::transaction(function () use ($id) {
212:            return DB::transaction(function () use ($id) {
246:            return DB::transaction(function () use ($id) {
278:            return DB::transaction(function () use ($intervention) {
```

#### BIN-03 · M · TXN-06 — `nextSortOrder()` is a count-then-insert race with no lock or unique index

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H, lowered to **M** — the impact is a duplicate display position, not data loss) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/BehaviouralAssessment/app/Models/BaIntervention.php:89-92` (`nextSortOrder()`), called from the controller `store` at :44 |
| **Root cause** | `nextSortOrder()` runs `max(sort_order) + 1` and the controller then `create()`s the row inside the same transaction, but nothing locks the max. `ba_interventions` has no unique index on `sort_order` (only `uq_ba_interv_code` on `code`,`uq_guard` and `idx_ba_interv_type`). |
| **Consequence** | Two interventions created at the same moment get the same `sort_order`, so the list order between them becomes arbitrary until someone drags them. |
| **Reproduce** | static only — the two requests must overlap; not reproducible on a single seeded tenant. |
| **Fix approach** | Accept today (12 seeded rows, creation is rare); a stricter fix is a unique index on `sort_order` or `lockForUpdate()` on the max query — a migration, so a DECISION (plan §9). |
| **Plan item** | BIN-03 (DECISION) in `02-fix-plan.md` §9 |

```php
// BaIntervention.php:89-92 — CURRENT
    public static function nextSortOrder(): int
    {
        return (int) (static::max('sort_order') ?? 0) + 1;
    }
```

**Evidence**
```
$ grep -n 'nextSortOrder' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
44:                    'sort_order' => BaIntervention::nextSortOrder(),
$ grep -n 'unique\|index' database/migrations/tenant/2026_06_16_130615_create_ba_interventions_table.php
40:            $table->unique(['code', 'uq_guard'], 'uq_ba_interv_code');
41:            $table->index(['intervention_type', 'is_active'], 'idx_ba_interv_type');
```

### F3 — Authorization

#### BIN-04 · L · AUTH-04 — `store`/`update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php:38` (`store`) and `:137` (`update`) |
| **Root cause** | `BaInterventionRequest::authorize()` (`:22`, via `authorizeByCrudPermission`) already checks `tenant.behavioural-assessment.interventions.create` on POST and `.update` on PUT/PATCH; the controller then calls `Gate::authorize()` with the identical string. The duplicate is deliberate (the FormRequest comment says so) but still redundant — and the rest of the controller gates with `Gate::authorize`, so the permission surface is split across two mechanisms. |
| **Consequence** | No user-visible effect; one extra permission lookup and two places to keep in sync if the name ever changes. |
| **Reproduce** | static only — both checks pass or both fail identically. |
| **Fix approach** | Keep the FormRequest `authorize()` (it runs first, same permission) and drop the two controller `Gate::authorize` lines, mirroring the TimetableFoundation ActivityController fix. |
| **Plan item** | BIN-04 in `02-fix-plan.md` §4 |

```php
// BaInterventionController.php:36-38,137 — CURRENT
    public function store(BaInterventionRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.interventions.create');
```

**Evidence**
```
$ grep -nE 'Gate::authorize|authorizeByCrudPermission' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionRequest.php
Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php:38:        Gate::authorize('tenant.behavioural-assessment.interventions.create');
Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php:137:        Gate::authorize('tenant.behavioural-assessment.interventions.update');
Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionRequest.php:22:        return $this->authorizeByCrudPermission('tenant.behavioural-assessment.interventions');
```

### F4 — Validation and input

#### BIN-05 · M · VAL-02 — `reorder()` validates inline instead of in a Form Request

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request, not inline `$request->validate()` — except one-field AJAX toggles* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php:89-93` (`reorder`) |
| **Root cause** | `reorder` is a multi-field JSON endpoint (`order` array, `order.*`, `start`) and validates inline. The VAL-02 exception is only a **one-field** AJAX toggle, so this does not qualify. |
| **Consequence** | The validation rules and the permission check for `reorder` sit in the controller rather than beside the other BA requests, so a future change to the rule set has no single home. |
| **Reproduce** | static only — the rules already run; the issue is where they live. |
| **Fix approach** | Create `BaInterventionReorderRequest` (authorize `.update`, the three rules) and type the controller argument as it; use `$request->validated()`. |
| **Plan item** | BIN-05 in `02-fix-plan.md` §5 |

```php
// BaInterventionController.php:89-93 — CURRENT
        $validated = $request->validate([
            'order' => ['required', 'array'],
            'order.*' => ['integer', 'distinct', 'exists:ba_interventions,id'],
            'start' => ['nullable', 'integer', 'min:1'],
        ]);
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-ba-module.json Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
M  VAL-02   Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php:89  reorder — inline validation in controller
```

### F5 — Routes

#### BIN-06 · H · RTE-01 — `restore` changes state over GET (no CSRF, CSRF-exempt link prefetch)

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/BehaviouralAssessment/routes/web.php:51` (`interventions.restore`) |
| **Root cause** | The restore endpoint is registered with `Route::get(...)`, so un-deleting a trashed intervention is a state-changing GET. The trash button (`<x-backend.table.action-trashed>`) already reads the route's verb and renders a GET form with no `@csrf` for a GET route — so nothing in the request is token-checked. |
| **Consequence** | Any GET that reaches `/behavioural-assessment/interventions/{id}/restore` — a prefetched link, an `<img src>`, a chat-link scanner, a browser refresh after a restore — un-deletes the row without the user intending it and without a CSRF token. |
| **Reproduce** | Log in, open `/behavioural-assessment/interventions/{id}/restore` for a trashed id (or paste it into the address bar): the row is restored. There is no confirmation dialog on the URL itself. |
| **Fix approach** | Change the route to `Route::post(...)` (or `DELETE`) and keep the name. The `action-trashed` component auto-detects the verb and already emits `@csrf` for a non-GET route, so no view change is needed. This is a route re-scope → DECISION (plan §9). |
| **Plan item** | BIN-06 (DECISION) in `02-fix-plan.md` §9 |

```php
// Modules/BehaviouralAssessment/routes/web.php:50-55 — CURRENT
Route::get('interventions/trash', [BaInterventionController::class, 'trashed'])->name('interventions.trashed');
Route::get('interventions/{id}/restore', [BaInterventionController::class, 'restore'])->name('interventions.restore');
Route::delete('interventions/{id}/force-delete', [BaInterventionController::class, 'forceDelete'])->name('interventions.forceDelete');
Route::post('interventions/{intervention}/toggle-status', [BaInterventionController::class, 'toggleStatus'])->name('interventions.toggleStatus');
Route::post('interventions/reorder', [BaInterventionController::class, 'reorder'])->name('interventions.reorder');
Route::resource('interventions', BaInterventionController::class);
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-ba-module.json Modules/BehaviouralAssessment/routes/web.php
H  RTE-01   Modules/BehaviouralAssessment/routes/web.php:0  restore — GET behavioural-assessment/interventions/{id}/restore (behavioural-assessment.interventions.restore) changes state
$ grep -n 'restore' Modules/BehaviouralAssessment/routes/web.php
51:Route::get('interventions/{id}/restore', [BaInterventionController::class, 'restore'])->name('interventions.restore');
```

### F6 — Controller shape

#### BIN-07 · M · CTL-03 — no route model binding; six methods take `$id` and re-run `findOrFail`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding (`show(Homework $homework)`), not `$id` + `findOrFail`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php:67-73` (`show`); also `edit` :127-133, `update` :135, `destroy` :162, `restore` :207, `forceDelete` :241, `toggleStatus` :273 |
| **Root cause** | The resource routes bind `{intervention}`, but the controller methods typed the scalar as `int $id` (and `int $intervention` on `toggleStatus`), so no model is injected and every method does its own `BaIntervention::findOrFail()`. |
| **Consequence** | More code per method, and each method repeats the load instead of receiving the bound model; no 404-vs-403 difference today because authorization runs first. |
| **Reproduce** | static only — behaviour is correct; the finding is the shape. |
| **Fix approach** | Type the parameters as `BaIntervention $intervention` (and `: BaIntervention $intervention` on `toggleStatus`), drop the local `findOrFail`. Keep `onlyTrashed()`/`withTrashed()` behaviour on the trash routes (trash routes use `{id}`, so keep `$id` there or bind with `->withTrashed()`). |
| **Plan item** | BIN-07 in `02-fix-plan.md` §5 |

```php
// BaInterventionController.php:67-73 — CURRENT
    public function show(int $id): View
    {
        Gate::authorize('tenant.behavioural-assessment.interventions.view');
        $intervention = BaIntervention::findOrFail($id);

        return view('behaviouralassessment::intervention.show', compact('intervention'));
    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-ba-module.json Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
M  CTL-03   .../BaInterventionController.php:67  show — show($id) + findOrFail — use route model binding
M  CTL-03   .../BaInterventionController.php:127  edit — edit($id) + findOrFail — use route model binding
M  CTL-03   .../BaInterventionController.php:135  update — update($id) + findOrFail — use route model binding
M  CTL-03   .../BaInterventionController.php:162  destroy — destroy($id) + findOrFail — use route model binding
M  CTL-03   .../BaInterventionController.php:207  restore — restore($id) + findOrFail — use route model binding
M  CTL-03   .../BaInterventionController.php:241  forceDelete — forceDelete($id) + findOrFail — use route model binding
```

#### BIN-08 · L · CTL-05 — the standalone `create()` page duplicates the Masters create modal

| Field | Value |
|---|---|
| **Rule** | CTL-05 (L) — *no copy-paste / duplicate implementations of one operation* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php:29-34` (`create`) |
| **Root cause** | The create form exists twice: this resource `create()`/`create.blade.php`, and `_create-fields.blade.php` rendered inside `#createBaInterventionModal` on the Masters tab. The modal is what the UI links (`x-backend.tab.search-bar createModal="#createBaInterventionModal"`); a repo-wide search finds no link to `interventions.create` other than the modal's `store` action. |
| **Consequence** | Two forms to keep in step; a change to one silently diverges from the other. |
| **Reproduce** | Open `/behavioural-assessment/interventions/create` directly — the standalone page renders, but nothing in the app links to it. |
| **Fix approach** | Informational — removing the route/page is a route change deferred to the D3 split pass (plan §10). |
| **Plan item** | none — see plan §10 |

```php
// BaInterventionController.php:29-34 — CURRENT
    public function create(): View
    {
        Gate::authorize('tenant.behavioural-assessment.interventions.create');

        return view('behaviouralassessment::intervention.create');
    }
```

**Evidence**
```
$ grep -rn "interventions\.create\|interventions\.edit\|interventions\.show" --include=*.blade.php --include=*.php Modules/BehaviouralAssessment resources | grep -v final-audit
Modules/BehaviouralAssessment/resources/views/pages/partials/masters/_interventions-create-modal.blade.php:9:    permission="tenant.behavioural-assessment.interventions.create">
```

### F7 — Models

#### BIN-09 · L · MDL-01 — `is_system` is mass-assignable in `$fillable`

| Field | Value |
|---|---|
| **Rule** | MDL-01 (H default, lowered to **L** — not reachable through this controller's `validated()` input) — *`$fillable` declared; nothing sensitive in it* |
| **Where** | `Modules/BehaviouralAssessment/app/Models/BaIntervention.php:23-36` (`$fillable`) |
| **Root cause** | `is_system` guards deletion (`destroy`/`forceDelete` refuse it), yet it is fillable. This controller only ever mass-assigns `$request->validated()`, and `is_system` is not in the FormRequest rules, so it cannot be set from this screen. The seeded rows are written with the query builder (`DB::table(...)->insert(...)`), not Eloquent, so removing it from `$fillable` does not break the seeder. |
| **Consequence** | A future code path that passes user input through `create()`/`fill()` could mark a row as system (undeletable) or unmark a seeded row, defeating the deletion guard. |
| **Reproduce** | static only — no current route reaches it. |
| **Fix approach** | Remove `'is_system'` from `$fillable`. The same pattern exists in `BaCategory`, `BaCommentBank`, `BaCriterion` (cross-cutting, §7) — not fixed here. |
| **Plan item** | BIN-09 in `02-fix-plan.md` §5 |

```php
// BaIntervention.php:23-36 — CURRENT
    protected $fillable = [
        'code',
        'name',
        'description',
        'intervention_type',
        'default_due_days',
        'requires_owner',
        'requires_parent_meeting',
        'sort_order',
        'is_system',
        'is_active',
        'created_by',
        'updated_by',
    ];
```

**Evidence**
```
$ grep -rn "is_system" Modules/BehaviouralAssessment/app/Models/ | grep -v BaIntervention
Modules/BehaviouralAssessment/app/Models/BaCriterion.php:25:        'is_system',
Modules/BehaviouralAssessment/app/Models/BaCommentBank.php:45:        'is_system',
Modules/BehaviouralAssessment/app/Models/BaCategory.php:27:        'is_system',
$ grep -n "is_system" Modules/BehaviouralAssessment/database/seeders/BaInterventionSeeder.php
52:                    'is_system' => true,   # written via DB::table()->insert(), not Eloquent create()
```

### F8 — Services and jobs

clean — the controller references no Service, Job, Event or Notification. `grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b' BaInterventionController.php` → only `BaInterventionRequest`.

### F9 — Queries and performance

#### BIN-10 · M · QRY-01 — `reorder()` issues one `UPDATE` per row inside a loop

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H default, lowered to **M** — bounded to the 10-row page) — *no queries inside loops; bulk-write instead* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php:100-105` (`reorder`) |
| **Root cause** | The drag-drop order is saved with a `BaIntervention::where('id', $id)->update(...)` per dragged row. The Masters list paginates at 10 (`paginate(10, ['*'], 'int_page')`), so a full drag is 10 UPDATE statements. |
| **Consequence** | A drag issues 1 + N queries (N ≤ 10) where one bulk write would do; it grows if the page size ever rises. |
| **Reproduce** | Drag a row on the Interventions tab with the network tab open — up to 11 statements fire for one drag. |
| **Fix approach** | Replace the loop with one bulk write (`upsert` or a bound `CASE` update). This is optional at 10 rows → DECISION (plan §9). |
| **Plan item** | BIN-10 (DECISION) in `02-fix-plan.md` §9 |

```php
// BaInterventionController.php:100-105 — CURRENT
                foreach ($order as $offset => $id) {
                    BaIntervention::where('id', $id)->update([
                        'sort_order' => $start + $offset,
                        'updated_by' => BaActor::id(),
                    ]);
                }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-ba-module.json Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
H  QRY-01   .../BaInterventionController.php:101  reorder — BaIntervention::where() inside a loop — N+1 query
$ grep -n "paginate(10" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
425:            ->paginate(10, ['*'], 'int_page');
```

### F10 — Views

clean — the four blades render no queries and no `{!! !!}` on user text. `grep -nE '\{\!\!|::where|->get\(\)|->count\(\)' Modules/BehaviouralAssessment/resources/views/intervention/*.blade.php` → no output. Row actions use `x-backend.table.action-trashed`; trash gating uses `@canany` with the exact `restore`/`forceDelete` strings; the create form is ≤15 controls and is (also) rendered as a modal on the Masters tab.

### F11 — Security and tenancy

clean — no `env()`, no hard-coded ids or `?? 1`, no request body logged. `BaActor` memoises the fallback `sys_users.id` **keyed by the tenant database name** (`BaActor.php:19,31-40`), so it cannot cross tenants (usage verified here; class owned elsewhere). Tenant middleware is present on all 12 routes.

### F12 — Style

#### BIN-11 · L · STY-02 — `BaIntervention.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, no inline fully-qualified class names where an import exists* |
| **Where** | `Modules/BehaviouralAssessment/app/Models/BaIntervention.php:7-9` (imports) and `:55` (`incidents()` return type) |
| **Root cause** | `incidents()` is return-typed with the inline FQCN `\Illuminate\Database\Eloquent\Relations\BelongsToMany`, and `HasMany` is already imported, so Pint's `fully_qualified_strict_types` + `ordered_imports` fixers fire. |
| **Consequence** | `vendor/bin/pint --test` fails on the file; the next `pint` run reformats it. |
| **Reproduce** | `vendor/bin/pint Modules/BehaviouralAssessment/app/Models/BaIntervention.php --test` → reports the two fixers. |
| **Fix approach** | Import `BelongsToMany` and use the short name in `incidents()`. |
| **Plan item** | BIN-11 in `02-fix-plan.md` §8 |

```php
// BaIntervention.php:7-9 — CURRENT
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
```

**Evidence**
```
$ vendor/bin/pint Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php Modules/BehaviouralAssessment/app/Models/BaIntervention.php Modules/BehaviouralAssessment/app/Http/Requests/BaInterventionRequest.php --test --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Models\/BaIntervention.php","fixers":["fully_qualified_strict_types","ordered_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutating method | Q1 wrong data / overwrite | Q2 delete before replace | Q3 duplicate impl | Q4 soft-delete × unique | Q5 race | Q6 auth hole | Q7 message lies | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok (rule `whereNull('deleted_at')` matches partial index) | **BIN-03** | ok | ok | ok |
| `reorder` | accepted (writes `sort_order` for any validated id, incl. trashed) | ok | ok | ok | ok | ok | ok | ok |
| `update` | ok | ok | ok | ok | ok | ok | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | **BIN-12** (returns row inactive) | ok | ok | ok (index backstop) | ok | ok | **BIN-12** | ok |
| `forceDelete` | ok | ok (pivot detach after delete, inside txn) | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |

#### BIN-12 · M · F13 (deep-read #1/#7) — `restore()` leaves the row `is_active = false`, but the flash says it was restored

| Field | Value |
|---|---|
| **Rule** | F13 deep-read #1 ("does any write overwrite data it shouldn't — resetting statuses") + #7 ("messages that lie"); nearest rulebook ID CTL-06 (business logic correctness) |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php:174-177` (`destroy`) and `:220-227` (`restore`) |
| **Root cause** | `destroy()` force-sets `is_active = false` **before** soft-deleting, but `restore()` only clears `deleted_at` — it never undoes the deactivation. So a soft-deleted row comes back inactive while the flash reads "Intervention restored successfully." |
| **Consequence** | An admin restores an intervention, sees a success message, but it is inactive and is missing from every active list; they must toggle it on again and may think the restore failed. |
| **Reproduce** | Create an intervention (active), delete it, then restore it from the trash: after "Intervention restored successfully", the Status column shows Inactive. Not reachable on the seeded tenant today (all 12 rows are system and cannot be deleted). |
| **Fix approach** | Set `is_active = true` in `restore()` so the restoration undoes the trash deactivation, or leave it inactive and change the flash to say so — a behaviour choice → DECISION (plan §9). |
| **Plan item** | BIN-12 (DECISION) in `02-fix-plan.md` §9 |

```php
// BaInterventionController.php:174-177 — CURRENT (destroy deactivates before trashing)
                $intervention->is_active = false;
                $intervention->updated_by = BaActor::id();
                $intervention->save();
                $intervention->delete();
```

**Evidence**
```
$ sed -n '174,177p;220,227p' Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
                $intervention->is_active = false;
                $intervention->updated_by = BaActor::id();
                $intervention->save();
                $intervention->delete();
                $intervention->updated_by = BaActor::id();
                $intervention->restore();

                activityLog($intervention, 'Restored', ['message' => 'BaIntervention was restored.']);

                return redirect()
                    ->route('behavioural-assessment.masters', ['tab' => 'interventions'])
                    ->with('success', 'Intervention restored successfully.');
$ grep -n "is_active" Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionController.php
174:                $intervention->is_active = false;
280:                $item->is_active = ! $item->is_active;
288:                    'is_active' => $item->is_active,
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/BehaviouralAssessment/routes/web.php` + sibling controllers (`BaCategoryController`, `BaRatingScaleController`, `BaCommentBankController`) | the same state-changing `GET …/restore` pattern is module-wide, not unique to interventions | RTE-01 | a single module route pass (feeds BIN-06 option (a)) |
| `Modules/BehaviouralAssessment/app/Models/BaCategory.php`, `BaCommentBank.php`, `BaCriterion.php` | `is_system` is fillable in the sibling models too | MDL-01 | owners of those reports |
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaCategoryController.php` and siblings | the same A1 `try/catch` + `Log::error(..., getMessage())` shape | ERR-00/ERR-05 | owners of those reports (module-wide cleanup) |
| `app/Traits/AuthorizesTenantFeature.php` | maps POST→`create`, PUT/PATCH→`update` — if a FormRequest wraps a JSON POST action that is really an update, the mapping is wrong; correct here (reorder is an update but the FormRequest is used only for validation of the new request class, authorized explicitly) | AUTH-04 | common app glue — reference only |
| `resources/views/components/backend/table/action-trashed.blade.php` + `app/View/Components/Backend/Table/ActionTrashed.php` | correct: props `restorePermission`/`forceDeletePermission` are read; `canRestore`/`canForceDelete` are computed. No defect. | — | common component — reference only |

## 8. Not covered, and why

- The real Interventions list screen is `Modules/BehaviouralAssessment/resources/views/pages/partials/masters/_interventions.blade.php` (+ `_interventions-create-modal.blade.php`), rendered by `BaDashboardController::masters`, not by this controller — so it is outside this controller's scope. It is what consumes `reorder`/`toggleStatus`; its JS (`fetch(..., 'Accept: application/json')`) is why the D1 JSON behaviour matters.
- `intervention/_create-fields.blade.php` (117) is included only by the Masters modal, not by any blade in scope.
- No service/job/listener/command is reached, so F8 is answered by absence.
- D4: no tests were run and none were written; `reorder`/`toggleStatus` JSON error responses were reasoned from the central handler, not exercised with fault injection.
- Live row counts come from the tenant `xyz_school_00000000000040008000_202627`; a different tenant may hold non-system rows (which would make BIN-12 reachable).
