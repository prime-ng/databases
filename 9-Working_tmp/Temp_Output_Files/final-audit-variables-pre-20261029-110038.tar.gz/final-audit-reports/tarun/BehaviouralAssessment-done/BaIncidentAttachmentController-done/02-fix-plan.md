# Fix Plan — BehaviouralAssessment / BaIncidentAttachmentController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/BehaviouralAssessment/app/Services/BaIncidentAttachmentService.php` | owned by `BaIncidentController` report; BAI-01 fixes live there |
| `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php` | owned by `BaIncidentController` report |
| `Modules/BehaviouralAssessment/app/Models/BaIncident.php`, `BaIncidentAttachment.php` | owned by `BaIncidentController` report |
| `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` | owned by `BaAuditLogController` report |
| `Modules/BehaviouralAssessment/app/Support/BaActor.php` | owned by `BaCommentBankController` report |
| `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | owned by `BaBehaviourPointController` report |
| `Modules/BehaviouralAssessment/routes/web.php` | shared route file; no route change is proposed by this plan |
| `config/permissionslist.php` | shared; no new permission is proposed by this plan |
| `Modules/BehaviouralAssessment/resources/views/incident/show.blade.php` | owned by `BaIncidentController` report |
| `bootstrap/app.php` | shared bootstrap; only option (c) of BIAC-01 would touch it — treat it as out of bounds unless that decision is chosen |

## 1. Blockers reachable today

(none — no B findings)

## 2. Fixes that arm a latent defect (sequenced)

(none)

## 3. Errors & transactions (F1/F2)

- [ ] **BIAC-02** · M · ERR-05 · `BaIncidentAttachmentController.php:108` — log the exception object instead of just its message in `failed()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php`
  - **Before** (`BaIncidentAttachmentController.php:108`):
    ```php
        Log::error('BaIncidentAttachmentController::'.$method.' failed', $context + ['error' => $e->getMessage()]);
    ```
  - **After:**
    ```php
        report($e);

        Log::error('BaIncidentAttachmentController::'.$method.' failed', $context);
    ```
  - **Verify:** `grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php`
  - **Expect:** no output (the exception is now sent whole to the logger via `report($e)`; the log line keeps the method context).
  - **Effort:** S

## 4. Authorization (F3)

(none — BIAC-03 and BIAC-04 are accepted in §10)

## 5. Validation, routes, models (F4/F5/F7)

(none)

## 6. Queries & performance (F9)

(none)

## 7. Views (F10)

(none)

## 8. Style (F12) — one item per file

(none — `vendor/bin/pint --test` already passed on the controller and the in-scope files)

## 9. Deferred / decisions

- [ ] **BIAC-01** · M · DECISION · ERR-00 — keep the controller-level try/catch that maps DB-trigger rejections, or move it?
  - **Why it is a decision:** D2 lists the only allowed catches and DB-trigger mapping is not among them; removing it loses the friendly `BA: …` form messages, keeping it contradicts D1. Mirrors BAI-03 (`BaIncidentController`, already a DECISION there).
  - (a) ⭐ **Keep, documented** — add a comment above `failed()` naming ERR-01 and the date, explaining the sanctioned DB-trigger mapping; no behaviour change, touches only the controller.
  - (b) **Remove the catches** — delete the `try/catch` in `store()` and `destroy()` and let the central renderer in `bootstrap/app.php` show its generic error; users lose the specific trigger message.
  - (c) **Move to a custom exception** — add a `BaTriggerException` resolved in `bootstrap/app.php`'s `withExceptions()`; cleanest, but touches a shared bootstrap file (⚠ SHARED).
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BIAC-03 | Accepted low priority, mirroring BAI-07: the FormRequest `authorize()` runs first, so the duplicate `Gate::authorize` in `store()` is redundant but harmless; both surfaces use the correct, seeded string. |
| BIAC-04 | Accepted low priority: the service's `canDelete()` is the real authority (abort 403 before any write), so no hole exists; no single permission string can replace the gate without breaking the uploader-only delete, so the shape is left and should be documented or aligned in a later pass. |