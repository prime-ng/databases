# BehaviouralAssessment — Final Audit Index

Protocol: `.claude/rules/final-audit.md`.
⛔ Append a row to claim. Edit only your own row. Never rewrite this file.

| Controller | Status | B | H | M | L | Report | By | Updated |
|---|---|---|---|---|---|---|---|---|
| BaAuditLogController | FIXED | 0 | 0 | 2 | 3 | [01-report.md](BaAuditLogController-done/01-report.md) | opencode | 2026-10-22 |
| BaBehaviourPointController | FIXED | 0 | 1 | 0 | 3 | [01-report.md](BaBehaviourPointController-done/01-report.md) | opencode | 2026-10-22 |
| BaCommentBankController | FIXED | 0 | 1 | 8 | 1 | [01-report.md](BaCommentBankController-done/01-report.md) | opencode | 2026-10-22 |
| BaCategoryController | FIXED | 0 | 2 | 8 | 5 | [01-report.md](BaCategoryController-done/01-report.md) | opencode | 2026-10-22 |
| BaClassScaleController | FIXED | 0 | 1 | 4 | 2 | [01-report.md](BaClassScaleController-done/01-report.md) | opencode | 2026-10-22 |
| BaInterventionController | FIXED | 0 | 1 | 7 | 4 | [01-report.md](BaInterventionController-done/01-report.md) | opencode | 2026-10-22 |
| BaRatingScaleController | FIXED | 0 | 1 | 9 | 5 | [01-report.md](BaRatingScaleController-done/01-report.md) | opencode | 2026-10-22 |
| BaNotificationController | FIXED | 0 | 2 | 7 | 2 | [01-report.md](BaNotificationController-done/01-report.md) | opencode | 2026-10-22 |
| BaInterventionCaseController | FIXED | 0 | 0 | 5 | 3 | [01-report.md](BaInterventionCaseController-done/01-report.md) | opencode | 2026-10-22 |
| BaClassCategoryController | FIXED | 0 | 0 | 6 | 2 | [01-report.md](BaClassCategoryController-done/01-report.md) | opencode | 2026-10-22 |
| BaConfigController | FIXED | 0 | 2 | 5 | 1 | [01-report.md](BaConfigController-done/01-report.md) | opencode | 2026-10-22 |
| BaIncidentController | FIXED | 1 | 2 | 13 | 6 | [01-report.md](BaIncidentController-done/01-report.md) | opencode | 2026-10-22 |
| BaAssessmentController | FIXED | 0 | 1 | 12 | 6 | [01-report.md](BaAssessmentController-done/01-report.md) | opencode | 2026-10-22 |
| BaIncidentAttachmentController | FIXED | 0 | 0 | 2 | 2 | [01-report.md](BaIncidentAttachmentController-done/01-report.md) | opencode | 2026-10-22 |
| BaReportExportController | FIXED | 1 | 1 | 4 | 1 | [01-report.md](BaReportExportController-done/01-report.md) | opencode | 2026-10-22 |
| BaAssessmentPeriodController | FIXED | 0 | 2 | 9 | 3 | [01-report.md](BaAssessmentPeriodController-done/01-report.md) | opencode | 2026-10-22 |
| BaReportController | FIXED | 2 | 1 | 11 | 4 | [01-report.md](BaReportController-done/01-report.md) | opencode | 2026-10-22 |
| BaDashboardController | FIXED | 0 | 2 | 6 | 2 | [01-report.md](BaDashboardController-done/01-report.md) | opencode | 2026-10-22 |
