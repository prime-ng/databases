# Fix Plan — BehaviouralAssessment / BaAssessmentPeriodController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | shared by all modules |
| `app/Traits/AuthorizesTenantFeature.php` | common app glue |
| `resources/views/components/backend/**` | shared components; `action-trashed` already adapts to the route verb, so BAP-08 needs no component change |
| `database/migrations/tenant/**` | never edit an existing migration |
| `Modules/BehaviouralAssessment/app/Models/BaAssessmentPeriod.php`, `BaAssessment.php`, `BaFrameworkSnapshot.php`, `BaScoreRun.php` | owned by other reports — not edited here |
| `Modules/BehaviouralAssessment/app/Support/BaActor.php`, `BaTriggerError.php` | owned by other reports — not edited here |
| `Modules/BehaviouralAssessment/app/Http/Requests/LocksAcademicSession.php` | trait owned by another report — not edited here |
| `Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php`, `BaFrameworkSnapshotService.php` | owned by other reports / dependency — not edited here |
| `Modules/BehaviouralAssessment/routes/web.php` | ⚠ SHARED — named by BAP-08 only; change line 76 and nothing else |

## 1. Blockers reachable today

- [ ] **BAP-07** · H · VAL-04 · `BaAssessmentPeriodController.php:207-208` — add a live-name clash check before restoring a trashed period, so a re-used name gives a readable message instead of a duplicate-key failure.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Before** (`restore`, lines 205-210):
    ```php
        try {
            return DB::transaction(function () use ($id) {
                $period = BaAssessmentPeriod::onlyTrashed()->findOrFail($id);
                $period->restore();

                activityLog($period, 'Restored', ['message' => 'BaAssessmentPeriod was restored.']);
    ```
  - **After:**
    ```php
        try {
            return DB::transaction(function () use ($id) {
                $period = BaAssessmentPeriod::onlyTrashed()->findOrFail($id);

                // uq_ba_period_name keys on (academic_session_id, name, uq_guard); a live period with the
                // same name makes the restored row a duplicate once deleted_at clears. BAP-07, 2026-10-12.
                $clash = BaAssessmentPeriod::where('academic_session_id', $period->academic_session_id)
                    ->where('name', $period->name)
                    ->exists();
                if ($clash) {
                    return back()->with('error', 'A live assessment period with this name already exists in the selected academic session. Rename or delete it before restoring this one.');
                }

                $period->restore();

                activityLog($period, 'Restored', ['message' => 'BaAssessmentPeriod was restored.']);
    ```
  - **Verify:** `grep -n "A live assessment period with this name" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Expect:** one matching line inside `restore()`.
  - **Effort:** S

- [ ] **BAP-08** · H · RTE-01 · `Modules/BehaviouralAssessment/routes/web.php:76` — change the restore route from GET to POST so it can no longer change state without a CSRF token. ⚠ SHARED
  - **Touches:** `Modules/BehaviouralAssessment/routes/web.php`
  - **Before** (`web.php:76`):
    ```php
    Route::get('assessment-periods/{id}/restore', [BaAssessmentPeriodController::class, 'restore'])->name('assessment-periods.restore');
    ```
  - **After:**
    ```php
    Route::post('assessment-periods/{id}/restore', [BaAssessmentPeriodController::class, 'restore'])->name('assessment-periods.restore');
    ```
  - **Verify:** `grep -n "assessment-periods/{id}/restore" Modules/BehaviouralAssessment/routes/web.php`
  - **Expect:** the line begins with `Route::post(`, not `Route::get(`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

_None standing alone. BAP-04 re-measures `restore` after BAP-07; apply BAP-07 first._

## 3. Errors & transactions (F1/F2)

- [ ] **BAP-01** · M · DECISION · ERR-00 (D1) — keep or remove the controller `try/catch` on the ten write paths.
  - **Why it is a decision:** D1 settles the Laravel idiom (no controller try/catch); D2 lists the only allowed catches, and mapping a DB trigger rejection is not among them. The module's other reports treat this as a documented module exception.
  - (a) ⭐ Keep as the module's documented ERR-01 exception: keep `failure()`, route the six inline catches (`store`/`update`/`destroy`/`restore`/`forceDelete`/`toggleStatus`) through it too so there is one funnel, and add a comment on each catch naming ERR-01 and the date (2026-10-12). Controller file only.
  - (b) Move the BA-trigger mapping into a custom exception rendered by `bootstrap/app.php` and delete all controller catches (the pure D1 shape). Touches `bootstrap/app.php` (shared) plus the controller.
  - (c) Leave as is, record as accepted.
  - ➜ Choice: ____

- [ ] **BAP-02** · M · ERR-05 · `BaAssessmentPeriodController.php:77,149,184,222,254,285,421` — log the exception object, not just the message.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Before** (`store` catch, lines 76-79):
    ```php
        } catch (\Throwable $e) {
            Log::error('BaAssessmentPeriodController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    ```
  - **After:**
    ```php
        } catch (\Throwable $e) {
            Log::error('BaAssessmentPeriodController::store failed', ['error' => $e->getMessage(), 'exception' => $e]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
    ```
  - **After** (the other six log contexts — add `'exception' => $e` to each array):
    ```php
            Log::error('BaAssessmentPeriodController::update failed', ['error' => $e->getMessage(), 'exception' => $e]);
            Log::error('BaAssessmentPeriodController::destroy failed', ['error' => $e->getMessage(), 'exception' => $e]);
            Log::error('BaAssessmentPeriodController::restore failed', ['error' => $e->getMessage(), 'exception' => $e]);
            Log::error('BaAssessmentPeriodController::forceDelete failed', ['error' => $e->getMessage(), 'exception' => $e]);
            Log::error('BaAssessmentPeriodController::toggleStatus failed', ['error' => $e->getMessage(), 'exception' => $e]);
            Log::error("BaAssessmentPeriodController::{$action} failed", ['error' => $e->getMessage(), 'exception' => $e]);
    ```
  - **Verify:** `grep -c "'exception' => \$e" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Expect:** `7`.
  - **Effort:** S

- [ ] **BAP-03** · M · TXN-04 · `BaAssessmentPeriodController.php:306,327,365` — move each `activityLog()` inside one transaction with the service write it describes, by wrapping the service call plus the log in the controller's own `DB::transaction`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Before** (`close`, lines 300-313):
    ```php
        try {
            $item = $this->service->close($period);
        } catch (Throwable $e) {
            return $this->failure($e, 'close');
        }

        activityLog($item, 'Closed', [
            'message' => 'Assessment period was closed.',
            'status' => $item->status,
        ]);

        return redirect()
            ->route('behavioural-assessment.setup', ['tab' => 'periods'])
            ->with('success', 'Period closed. New assessments are blocked; existing drafts stay editable.');
    ```
  - **After:**
    ```php
        try {
            $item = DB::transaction(function () use ($period) {
                $item = $this->service->close($period);

                activityLog($item, 'Closed', [
                    'message' => 'Assessment period was closed.',
                    'status' => $item->status,
                ]);

                return $item;
            });
        } catch (Throwable $e) {
            return $this->failure($e, 'close');
        }

        return redirect()
            ->route('behavioural-assessment.setup', ['tab' => 'periods'])
            ->with('success', 'Period closed. New assessments are blocked; existing drafts stay editable.');
    ```
  - **Before** (`reopen`, lines 321-336):
    ```php
        try {
            $item = $this->service->reopen($period, $reason);
        } catch (Throwable $e) {
            return $this->failure($e, 'reopen');
        }

        activityLog($item, 'Reopened', [
            'message' => 'Assessment period was reopened.',
            'status' => $item->status,
            'reopen_count' => $item->reopen_count,
            'reason' => $reason,
        ]);

        return redirect()
            ->route('behavioural-assessment.setup', ['tab' => 'periods'])
            ->with('success', 'Period reopened.');
    ```
  - **After:**
    ```php
        try {
            $item = DB::transaction(function () use ($period, $reason) {
                $item = $this->service->reopen($period, $reason);

                activityLog($item, 'Reopened', [
                    'message' => 'Assessment period was reopened.',
                    'status' => $item->status,
                    'reopen_count' => $item->reopen_count,
                    'reason' => $reason,
                ]);

                return $item;
            });
        } catch (Throwable $e) {
            return $this->failure($e, 'reopen');
        }

        return redirect()
            ->route('behavioural-assessment.setup', ['tab' => 'periods'])
            ->with('success', 'Period reopened.');
    ```
  - **Before** (`lock`, lines 347-369):
    ```php
        try {
            $result = $this->service->lock($period);
        } catch (Throwable $e) {
            return $this->failure($e, 'lock');
        }

        if ($result['blockers']->isNotEmpty()) {
            $count = $result['blockers']->count();

            return redirect()
                ->route('behavioural-assessment.setup', ['tab' => 'periods'])
                ->with('error', "\"{$result['period']->name}\" cannot be locked: {$count} assessment(s) are still in draft or awaiting review.")
                ->with('ba_lock_blockers', [
                    'period' => $result['period']->name,
                    'items' => $result['blockers']->all(),
                ]);
        }

        activityLog($result['period'], 'Locked', [
            'message' => 'Assessment period was locked; no further edits allowed.',
            'status' => $result['period']->status,
            'assessments_locked' => $result['locked'],
        ]);
    ```
  - **After:**
    ```php
        try {
            $result = DB::transaction(function () use ($period) {
                $result = $this->service->lock($period);

                if ($result['blockers']->isEmpty()) {
                    activityLog($result['period'], 'Locked', [
                        'message' => 'Assessment period was locked; no further edits allowed.',
                        'status' => $result['period']->status,
                        'assessments_locked' => $result['locked'],
                    ]);
                }

                return $result;
            });
        } catch (Throwable $e) {
            return $this->failure($e, 'lock');
        }

        if ($result['blockers']->isNotEmpty()) {
            $count = $result['blockers']->count();

            return redirect()
                ->route('behavioural-assessment.setup', ['tab' => 'periods'])
                ->with('error', "\"{$result['period']->name}\" cannot be locked: {$count} assessment(s) are still in draft or awaiting review.")
                ->with('ba_lock_blockers', [
                    'period' => $result['period']->name,
                    'items' => $result['blockers']->all(),
                ]);
        }
    ```
  - **Verify:** `grep -c "DB::transaction" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Expect:** `9` (the six original controller transactions plus `close`, `reopen`, `lock`).
  - **Effort:** M

- [ ] **BAP-04** · M · TXN-05 · `BaAssessmentPeriodController.php:58-71,128-143,160-178,206-216,233-248,265-279` — return the model from each transaction closure and build the redirect/JSON after it; guard refusals inside the closure become `\DomainException` (D2).
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Before** (`store`, lines 57-71):
    ```php
        try {
            return DB::transaction(function () use ($request) {
                $record = BaAssessmentPeriod::create($request->validated() + [
                    'status' => BaAssessmentPeriod::STATUS_OPEN,
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Stored', ['message' => 'BaAssessmentPeriod was stored.']);

                return redirect()
                    ->route('behavioural-assessment.setup', ['tab' => 'periods'])
                    ->with('success', 'Assessment period created successfully.');

            });
    ```
  - **After:**
    ```php
        try {
            DB::transaction(function () use ($request) {
                $record = BaAssessmentPeriod::create($request->validated() + [
                    'status' => BaAssessmentPeriod::STATUS_OPEN,
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Stored', ['message' => 'BaAssessmentPeriod was stored.']);
            });

            return redirect()
                ->route('behavioural-assessment.setup', ['tab' => 'periods'])
                ->with('success', 'Assessment period created successfully.');
    ```
  - **After** (the other five methods — same transformation):
    ```php
    // update(): replace the closure's final `return redirect()` with a trailing redirect after the closure; replace the locked guard's `return back()->withInput()->with('error', 'A locked period is final and cannot be edited.');` with `throw new DomainException('A locked period is final and cannot be edited.');` keep the rest of the closure.
    // destroy(): return `$period` from the closure; replace the has-assessments guard's `return back()->with('error', 'Cannot delete this assessment period because it has active assessments or computed scores.');` with `throw new DomainException('Cannot delete this assessment period because it has active assessments or computed scores.');` build the redirect after the closure.
    // restore(): return `$period` from the closure; build the redirect after it (the BAP-07 clash guard keeps its own `return back(...)` unless BAP-01 option (a) is ticked, in which case throw a DomainException).
    // forceDelete(): return `$period` from the closure; replace the has-associations guard's `return back()->with('error', 'Cannot permanently delete this assessment period because it has associated assessments or computed scores (active or trashed).');` with `throw new DomainException('Cannot permanently delete this assessment period because it has associated assessments or computed scores (active or trashed).');` build the redirect after the closure.
    // toggleStatus(): return `$item` from the closure; build the `response()->json([...])` after it.
    ```
  - **Verify:** `grep -n "return redirect()\|return response()->json" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php | head`
  - **Expect:** every `return redirect()` / `return response()->json(` sits outside a `DB::transaction` closure (no `return` line between the `DB::transaction(function () {` and its `});`).
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **BAP-05** · L · AUTH-04 · `BaAssessmentPeriodController.php:55,125,318` — remove the three `Gate::authorize` lines that duplicate the FormRequest checks that already run first.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Before** (`store`, lines 53-55):
    ```php
        public function store(BaAssessmentPeriodRequest $request): RedirectResponse
        {
            Gate::authorize('tenant.behavioural-assessment.assessment-periods.create');
    ```
  - **After:**
    ```php
        public function store(BaAssessmentPeriodRequest $request): RedirectResponse
        {
            try {
    ```
  - **Before** (`update`, lines 123-125):
    ```php
        public function update(BaAssessmentPeriodRequest $request, int $id): RedirectResponse
        {
            Gate::authorize('tenant.behavioural-assessment.assessment-periods.update');
    ```
  - **After:**
    ```php
        public function update(BaAssessmentPeriodRequest $request, int $id): RedirectResponse
        {
            try {
    ```
  - **Before** (`reopen`, lines 316-319):
    ```php
        public function reopen(BaPeriodReopenRequest $request, int $period): RedirectResponse
        {
            Gate::authorize('tenant.behavioural-assessment.assessment-periods.reopen');
            $reason = $request->validated()['reason'];
    ```
  - **After:**
    ```php
        public function reopen(BaPeriodReopenRequest $request, int $period): RedirectResponse
        {
            $reason = $request->validated()['reason'];
    ```
  - **Verify:** `grep -n "assessment-periods.create'\|assessment-periods.update'\|assessment-periods.reopen'" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php | grep "Gate::authorize"`
  - **Expect:** no output (the `create` and `update` Gate lines remain only on `create`/`edit`/`toggleStatus`, and the store/update/reopen duplicates are gone).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7) and controller shape

- [ ] **BAP-10** · M · CTL-05 · `BaAssessmentPeriodController.php:117-120` (and `:47-50`) — extract the two dropdown loaders shared by `create` and `edit` into one private method.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Before** (`edit`, lines 117-120):
    ```php
            $academicSessions = OrganizationAcademicSession::where('is_active', true)->orderByDesc('is_current')->get();
            $academicTerms = AcademicTerm::where('is_active', true)->orderBy('term_ordinal')->get();

            return view('behaviouralassessment::assessment-period.edit', compact('period', 'academicSessions', 'academicTerms'));
    ```
  - **After:**
    ```php
            return view('behaviouralassessment::assessment-period.edit', $this->formOptions() + ['period' => $period]);
    ```
  - **Before** (`create`, lines 47-50):
    ```php
            $academicSessions = OrganizationAcademicSession::where('is_active', true)->orderByDesc('is_current')->get();
            $academicTerms = AcademicTerm::where('is_active', true)->orderBy('term_ordinal')->get();

            return view('behaviouralassessment::assessment-period.create', compact('academicSessions', 'academicTerms'));
    ```
  - **After:**
    ```php
            return view('behaviouralassessment::assessment-period.create', $this->formOptions());
    ```
  - **After** (new private method — add once, before `failure()`):
    ```php
        /**
         * The academic-session / academic-term selects shared by create() and edit().
         *
         * @return array{academicSessions: \Illuminate\Support\Collection, academicTerms: \Illuminate\Support\Collection}
         */
        private function formOptions(): array
        {
            return [
                'academicSessions' => OrganizationAcademicSession::where('is_active', true)->orderByDesc('is_current')->get(),
                'academicTerms' => AcademicTerm::where('is_active', true)->orderBy('term_ordinal')->get(),
            ];
        }
    ```
  - **Verify:** `grep -c "OrganizationAcademicSession::where" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Expect:** `1`.
  - **Effort:** S

- [ ] **BAP-11** · M · SVC-02 · `BaAssessmentPeriodController.php:389` — call the injected service instead of resolving it with `app()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Before** (`recompute`, lines 388-392):
    ```php
            try {
                app(BaPeriodService::class)->recompute($model);
            } catch (Throwable $e) {
                return $this->failure($e, 'recompute');
            }
    ```
  - **After:**
    ```php
            try {
                $this->service->recompute($model);
            } catch (Throwable $e) {
                return $this->failure($e, 'recompute');
            }
    ```
  - **Verify:** `grep -n "app(BaPeriodService" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **BAP-12** · M · DECISION · QRY-07 — reduce the per-row writes in `BaPeriodService::lock()`.
  - **Why it is a decision:** the reviewed-sheet loop cannot be fully collapsed because `lockReviewed()` appends a per-row status-history row; a behaviour change here needs Tarun's call.
  - (a) ⭐ Leave the reviewed-sheet loop as is (per-row status history is required) and record the item as accepted — the already-locked bulk update at `BaPeriodService.php:166-169` is evidence the bulk path is used where it can be.
  - (b) Replace the loop's standalone `$assessment->update(['snapshot_id' => …])` with a single `BaAssessment::where('period_id', $period->id)->where('status', STATUS_REVIEWED)->update(['snapshot_id' => $snapshot->id])` before the loop, keeping only `lockReviewed()` per row. Controller/service file only.
  - (c) Something else (state it).
  - ➜ Choice: ____

## 7. Views (F10)

_None — F10 is clean (no queries, eager loads, no `{!! !!}`)._

## 8. Style (F12) — one item per file

- [ ] **BAP-13** · L · STY-02 · `BaAssessmentPeriodController.php:76` — make the controller Pint-clean.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Before** (`store` catch, line 76):
    ```php
            } catch (\Throwable $e) {
    ```
  - **After:**
    ```php
            } catch (Throwable $e) {
    ```
  - **Verify:** `vendor/bin/pint --test --format agent Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`
  - **Expect:** `{"tool":"pint","result":"passed"...}`.
  - **Effort:** S

- [ ] **BAP-14** · L · STY-02 · `BaAssessmentPeriodRequest.php:55` — make the FormRequest Pint-clean (Pint adds the `use` import for the fully-qualified class).
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentPeriodRequest.php`
  - **Before** (`prepareForValidation`, line 55):
    ```php
            $this->lockAcademicSession(\Modules\BehaviouralAssessment\Models\BaAssessmentPeriod::class, $this->route('assessment_period') ?? $this->route('id'));
    ```
  - **After:**
    ```php
            $this->lockAcademicSession(BaAssessmentPeriod::class, $this->route('assessment_period') ?? $this->route('id'));
    ```
  - **After** (the added import, lines 7-10):
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Modules\BehaviouralAssessment\Models\BaAssessmentPeriod;
    ```
  - **Verify:** `vendor/bin/pint --test --format agent Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentPeriodRequest.php`
  - **Expect:** `{"tool":"pint","result":"passed"...}`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BAP-09** · M · DECISION · CTL-03 — adopt route-model binding for the eight `$id`/`$period` loads?
  - **Why it is a decision:** a behaviour-preserving refactor of eight methods; D3 defers broad refactors, and binding `restore`/`forceDelete` needs `->withTrashed()`.
  - (a) ⭐ Defer to a dedicated binding pass (D3) — record the parameter-name mismatch (`{assessment_period}` vs `$id`) and revisit.
  - (b) Bind `BaAssessmentPeriod $assessmentPeriod` now on `show`/`edit`/`update`/`destroy`/`toggleStatus`/`recompute`, and `BaAssessmentPeriod $period` with `->withTrashed()` on `restore`/`forceDelete`. Controller file only.
  - (c) Leave as is, record as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BAP-06 | AUTH-06 — permission strings as literals is a module-wide pass (Policy/constants), not a per-controller change; the module summary tracks it (same disposition as `BaAssessmentController` BASS-06). |
