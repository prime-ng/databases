# Fix Plan — BehaviouralAssessment / BaReportController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/BehaviouralAssessment/routes/web.php` | route file — no route changes in this plan |
| `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php` | owned by the BaReportExportController report (BAEXP-01..07) |
| `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` and every other linked model in the §3 scope table | owned by another report |
| `config/permissionslist.php` | shared permission config — no permission changes in this plan |
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php` and `Modules/BehaviouralAssessment/resources/views/pages/reports.blade.php` | the reports-page tab controller; BAR-13 is a DECISION exactly because its fix would touch these |
| `Modules/BehaviouralAssessment/app/Support/BaPseudonym.php`, `Modules/BehaviouralAssessment/app/Models/BaScoreRun.php` | referenced only; no claim exists — not to be edited here |

## 1. Blockers reachable today

- [ ] **BAR-02** · B · ERR-01 · `BaReportController.php:843-845` — stop echoing the raw `error_message` into the failed-export flash.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Before** (`BaReportController.php:842-845`):
    ```php
            $tab = route('behavioural-assessment.reports-page', ['tab' => 'exports']);
            if ($export->status === BaReportExport::STATUS_FAILED) {
                return redirect($tab)->with('error', 'The export failed: '.($export->error_message ?: 'unknown error').'.');
            }
    ```
  - **After:**
    ```php
            $tab = route('behavioural-assessment.reports-page', ['tab' => 'exports']);
            if ($export->status === BaReportExport::STATUS_FAILED) {
                return redirect($tab)->with('error', 'The export could not be generated. Try again or choose a smaller range.');
            }
    ```
  - **Verify:** `grep -n "error_message" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BAR-14** · B · ERR-01 · `BehaviouralScoreService.php:148-161` — store a fixed sentence, never the raw exception, in the score-run `error_message`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php`
  - **Before** (`BehaviouralScoreService.php:148-161`):
    ```php
            } catch (Throwable $e) {
                report($e);
                Log::error('BehaviouralAssessment: score run failed', [
                    'score_run_id' => $run->id,
                    'period_id' => $periodId,
                    'class_section_id' => $classSectionId,
                    'error' => $e->getMessage(),
                ]);

                $finish([
                    'status' => BaScoreRun::STATUS_FAILED,
                    'error_message' => BaTriggerError::message($e) ?? $e->getMessage(),
                ]);
            }
    ```
  - **After:**
    ```php
            } catch (Throwable $e) {
                report($e);

                $finish([
                    'status' => BaScoreRun::STATUS_FAILED,
                    'error_message' => BaTriggerError::message($e) ?? 'The score run failed. Check the logs for details.',
                ]);
            }
    ```
  - **Verify:** `grep -n "getMessage" Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php`
  - **Expect:** no output (the removed `Log` import is cleaned up by Pint).
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

## 3. Errors & transactions (F1/F2)

- [ ] **BAR-01** · M · ERR-00 · `BaReportController.php:821-832` — remove the controller `try/catch` from `export()` (D1).
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Before** (`BaReportController.php:819-832`):
    ```php
            $data = $request->validated();

            try {
                $export = $exports->request(
                    $data['report_code'],
                    (array) ($data['filters'] ?? []),
                    $data['format'],
                    (bool) ($data['anonymised'] ?? false),
                );
            } catch (\Throwable $e) {
                Log::error('BA report export request failed', ['report' => $data['report_code'], 'error' => $e->getMessage()]);

                return back()->with('error', 'The export could not be started. Please try again.');
            }
    ```
  - **After:**
    ```php
            $data = $request->validated();

            $export = $exports->request(
                $data['report_code'],
                (array) ($data['filters'] ?? []),
                $data['format'],
                (bool) ($data['anonymised'] ?? false),
            );
    ```
  - **Verify:** `grep -n "catch (\Throwable\|getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Expect:** no output (the now-unused `Log` import is cleaned up by Pint).
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **BAR-03** · M · AUTH-06 · `BaReportController.php:36-37,106,145,259,421,585,692` — replace the six permission literals with class constants.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Before** — pair 1 of 2 (`BaReportController.php:36-37` — the class opening):
    ```php
    class BaReportController extends Controller
    {
    ```
  - **After:**
    ```php
    class BaReportController extends Controller
    {
        public const VIEW_PERMISSION = 'tenant.behavioural-assessment.reports.view';

        public const VIEW_ANY_PERMISSION = 'tenant.behavioural-assessment.reports.viewAny';

    ```
  - **Before** — pair 2 of 2 (`BaReportController.php:106` — the first literal):
    ```php
            Gate::authorize('tenant.behavioural-assessment.reports.viewAny');
    ```
  - **After:**
    ```php
            Gate::authorize(self::VIEW_ANY_PERMISSION);
    ```
  - Then apply the same replacement to the remaining five literals: lines 145, 259, 421, 585 and 692 all read `Gate::authorize('tenant.behavioural-assessment.reports.view');` and become `Gate::authorize(self::VIEW_PERMISSION);`.
  - **Verify:** `grep -n "Gate::authorize('tenant.behavioural-assessment.reports" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Expect:** no output; `grep -c "self::VIEW" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php` prints `6`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **BAR-05** · M · CTL-03 · `BaReportController.php:143,147,257,260,583,586` — use route model binding on the three id routes.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Before** — pair 1 of 6 (`BaReportController.php:143`):
    ```php
        public function student(int $student): View
    ```
  - **After:**
    ```php
        public function student(Student $student): View
    ```
  - **Before, pair 2 of 6** (`BaReportController.php:147`):
    ```php
            $student = Student::with('currentAcademicSession')->findOrFail($student);
    ```
  - **After:**
    ```php
            $student->load('currentAcademicSession.classSection.class', 'currentAcademicSession.classSection.section');
    ```
  - **Before** — pair 3 of 6 (`BaReportController.php:257`):
    ```php
        public function byClass(int $classSection): View
    ```
  - **After:**
    ```php
        public function byClass(ClassSection $classSection): View
    ```
  - **Before, pair 4 of 6** (`BaReportController.php:260`):
    ```php
            $classSection = ClassSection::with(['class', 'section'])->findOrFail($classSection);
    ```
  - **After:**
    ```php
            $classSection->load('class', 'section');
    ```
  - **Before** — pair 5 of 6 (`BaReportController.php:583`):
    ```php
        public function period(int $period): View
    ```
  - **After:**
    ```php
        public function period(BaAssessmentPeriod $period): View
    ```
  - **Before, pair 6 of 6** (`BaReportController.php:586`):
    ```php
            $period = BaAssessmentPeriod::with('academicSession')->findOrFail($period);
    ```
  - **After:**
    ```php
            $period->load('academicSession');
    ```
  - **Verify:** `grep -nE "public function (student|byClass|period)\(" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Expect:** the three lines print `student(Student $student)`, `byClass(ClassSection $classSection)`, `period(BaAssessmentPeriod $period)`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **BAR-07** · M · SVC-02/SVC-05 · `BaReportController.php:36-37,55,87,618` — inject the two scoring services so their request-scoped memoisation works.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Before** — pair 1 of 4 (`BaReportController.php:36-37`):
    ```php
    class BaReportController extends Controller
    {
    ```
  - **After:**
    ```php
    class BaReportController extends Controller
    {
        public function __construct(
            private readonly BehaviouralScoreService $scores,
            private readonly BaFrameworkSnapshotService $frameworks,
        ) {}
    ```
  - **Before** — pair 2 of 4 (`BaReportController.php:55`):
    ```php
            $service = app(BehaviouralScoreService::class);
    ```
  - **After:**
    ```php
            $service = $this->scores;
    ```
  - **Before** — pair 3 of 4 (`BaReportController.php:87`):
    ```php
            return app(BaFrameworkSnapshotService::class)->lockedFramework($period);
    ```
  - **After:**
    ```php
            return $this->frameworks->lockedFramework($period);
    ```
  - **Before** — pair 4 of 4 (`BaReportController.php:618`):
    ```php
            $framework = app(BaFrameworkSnapshotService::class)->frameworkFor($period);
    ```
  - **After:**
    ```php
            $framework = $this->frameworks->frameworkFor($period);
    ```
  - **Verify:** `grep -nE "app\((BehaviouralScoreService|BaFrameworkSnapshotService)::class\)" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Expect:** no output; `grep -n "__construct" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php` prints line 39.
  - **Effort:** S

- [ ] **BAR-08** · M · QRY-01 · `BehaviouralScoreService.php:219-240` — hoist the ratings query out of the class-section loop.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php`
  - **Before** — pair 1 of 2 (`BehaviouralScoreService.php:219-224`):
    ```php
            $classIdBySection = ClassSection::whereIn('id', $assessments->pluck('class_section_id')->unique())
                ->pluck('class_id', 'id');

            // A student is scored in the class section of the assessments that rated them;
            // one pass per section keeps the scale and applicable criteria per class.
            foreach ($assessments->groupBy('class_section_id') as $sectionId => $sectionAssessments) {
    ```
  - **After:**
    ```php
            $classIdBySection = ClassSection::whereIn('id', $assessments->pluck('class_section_id')->unique())
                ->pluck('class_id', 'id');

            $ratingsByAssessment = BaAssessmentRating::whereIn('assessment_id', $assessments->pluck('id'))
                ->whereNotNull('rating_value')
                ->where('is_active', true)
                ->get(['id', 'assessment_id', 'student_id', 'criterion_id', 'rating_value'])
                ->groupBy('assessment_id');

            // A student is scored in the class section of the assessments that rated them;
            // one pass per section keeps the scale and applicable criteria per class.
            foreach ($assessments->groupBy('class_section_id') as $sectionId => $sectionAssessments) {
    ```
  - **Before** — pair 2 of 2 (`BehaviouralScoreService.php:237-240`):
    ```php
                $ratings = BaAssessmentRating::whereIn('assessment_id', $sectionAssessments->pluck('id'))
                    ->whereNotNull('rating_value')
                    ->where('is_active', true)
                    ->get(['id', 'assessment_id', 'student_id', 'criterion_id', 'rating_value']);
    ```
  - **After:**
    ```php
                $ratings = $sectionAssessments->pluck('id')
                    ->flatMap(fn ($assessmentId) => $ratingsByAssessment->get((int) $assessmentId, collect()))
                    ->unique('id')
                    ->sortBy('id')
                    ->values();
    ```
  - **Verify:** `grep -n "whereIn('assessment_id', \$sectionAssessments" Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **BAR-09** · M · QRY-01 · `BehaviouralScoreService.php:242-260,291-301,387,390,600-626` — batch the two per-student lookups before the student loop.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php`
  - **Before** — pair 1 of 5 (`BehaviouralScoreService.php:242-250` — inside the section loop, before the student loop):
    ```php
                $applicable = BaFrameworkSnapshotService::applicableCounts($framework, $classId);

                foreach ($ratings->groupBy('student_id') as $studentId => $studentRatings) {
                    $rows = $this->computeStudentRows(
                        (int) $studentId, $period, $studentRatings, $teacherByAssessment,
                        $applicable, $criteria, $categories, $scale, $framework['config'] ?? []
                    );
    ```
  - **After:**
    ```php
                $applicable = BaFrameworkSnapshotService::applicableCounts($framework, $classId);

                $batchStudentIds = $ratings->pluck('student_id')->unique()->values()->all();

                $previousOveralls = BaComputedOverall::query()
                    ->join('ba_assessment_periods as p', 'p.id', '=', 'ba_computed_overall.period_id')
                    ->whereIn('ba_computed_overall.student_id', $batchStudentIds)
                    ->where('ba_computed_overall.period_id', '!=', $period->id)
                    ->where('ba_computed_overall.is_active', true)
                    ->whereNotNull('ba_computed_overall.overall_score')
                    ->whereNull('p.deleted_at')
                    ->where('p.start_date', '<', $period->start_date)
                    ->orderByDesc('p.start_date')
                    ->get(['ba_computed_overall.student_id', 'ba_computed_overall.overall_score'])
                    ->groupBy('student_id')
                    ->map(fn ($rows) => $rows->first()->overall_score);

                $negativeIncidentCounts = BaIncident::whereIn('student_id', $batchStudentIds)
                    ->where('incident_type', 'negative_incident')
                    ->where('status', '!=', 'cancelled')
                    ->where('is_active', true)
                    ->whereBetween('incident_date', [$period->start_date, $period->end_date])
                    ->selectRaw('student_id, COUNT(*) as cnt')
                    ->groupBy('student_id')
                    ->pluck('cnt', 'student_id');

                foreach ($ratings->groupBy('student_id') as $studentId => $studentRatings) {
                    $rows = $this->computeStudentRows(
                        (int) $studentId, $period, $studentRatings, $teacherByAssessment,
                        $applicable, $criteria, $categories, $scale, $framework['config'] ?? [],
                        $previousOveralls, $negativeIncidentCounts
                    );
    ```
  - **Before** — pair 2 of 5 (`BehaviouralScoreService.php:291-301` — `computeStudentRows` signature):
    ```php
        protected function computeStudentRows(
            int $studentId,
            BaAssessmentPeriod $period,
            Collection $studentRatings,
            Collection $teacherByAssessment,
            array $applicable,
            array $criteria,
            array $categories,
            array $scale,
            array $config
        ): array {
    ```
  - **After:**
    ```php
        protected function computeStudentRows(
            int $studentId,
            BaAssessmentPeriod $period,
            Collection $studentRatings,
            Collection $teacherByAssessment,
            array $applicable,
            array $criteria,
            array $categories,
            array $scale,
            array $config,
            ?Collection $previousOveralls = null,
            ?Collection $negativeIncidentCounts = null
        ): array {
    ```
  - **Before** — pair 3 of 5 (`BehaviouralScoreService.php:387`):
    ```php
            $previous = $this->previousOverall($studentId, $period);
    ```
  - **After:**
    ```php
            $previous = $previousOveralls !== null ? $previousOveralls->get((int) $studentId) : $this->previousOverall($studentId, $period);
    ```
  - **Before** — pair 4 of 5 (`BehaviouralScoreService.php:390`):
    ```php
            [$isAtRisk, $atRiskReason] = $this->atRisk($studentId, $period, $overall, $scaleMin, $range, $config);
    ```
  - **After:**
    ```php
            [$isAtRisk, $atRiskReason] = $this->atRisk($studentId, $period, $overall, $scaleMin, $range, $config, $negativeIncidentCounts);
    ```
  - **Before** — pair 5 of 5 (`BehaviouralScoreService.php:600-626` — `atRisk` signature and the incident count):
    ```php
        protected function atRisk(int $studentId, BaAssessmentPeriod $period, ?float $overall, float $scaleMin, float $range, array $config): array
        {
    ```
  - **After:**
    ```php
        protected function atRisk(int $studentId, BaAssessmentPeriod $period, ?float $overall, float $scaleMin, float $range, array $config, ?Collection $negativeIncidentCounts = null): array
        {
    ```
  - Then, inside the same method, replace lines 611-619: keep the `$incidentLimit` guard but read the batched count when provided:
    - **Before** (`BehaviouralScoreService.php:611-619`):
    ```php
            $incidentLimit = (int) ($config['at_risk_incident_count'] ?? self::DEFAULT_AT_RISK_INCIDENT_COUNT);
            if ($incidentLimit > 0) {
                $negatives = BaIncident::where('student_id', $studentId)
                    ->where('incident_type', 'negative_incident')
                    ->where('status', '!=', 'cancelled')
                    ->where('is_active', true)
                    ->whereBetween('incident_date', [$period->start_date, $period->end_date])
                    ->count();
    ```
    - **After:**
    ```php
            $incidentLimit = (int) ($config['at_risk_incident_count'] ?? self::DEFAULT_AT_RISK_INCIDENT_COUNT);
            if ($incidentLimit > 0) {
                $negatives = $negativeIncidentCounts !== null
                    ? (int) ($negativeIncidentCounts[(int) $studentId] ?? 0)
                    : BaIncident::where('student_id', $studentId)
                        ->where('incident_type', 'negative_incident')
                        ->where('status', '!=', 'cancelled')
                        ->where('is_active', true)
                        ->whereBetween('incident_date', [$period->start_date, $period->end_date])
                        ->count();
    ```
  - **Verify:** `grep -n "BaIncident::where('student_id', \$studentId)" Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php`
  - **Expect:** the only occurrence is the fallback branch inside the ternary (line ~620), never executed when `$negativeIncidentCounts` is passed.
  - **Effort:** M

- [ ] **BAR-11** · M · QRY-01 · `BaFrameworkSnapshotService.php:296-315` — prefetch rating levels once instead of once per scale.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php`
  - **Before** — pair 1 of 2 (`BaFrameworkSnapshotService.php:296-298`):
    ```php
            $scaleIds = $overrides->values()->push($sessionScaleId)->push($defaultScaleId)->filter()->unique()->values();

            $scales = BaRatingScale::whereIn('id', $scaleIds)->where('is_active', true)->orderBy('id')->get()
    ```
  - **After:**
    ```php
            $scaleIds = $overrides->values()->push($sessionScaleId)->push($defaultScaleId)->filter()->unique()->values();

            $levelRows = BaRatingLevel::whereIn('rating_scale_id', $scaleIds)->where('is_active', true)->orderBy('id')->get()
                ->groupBy('rating_scale_id');

            $scales = BaRatingScale::whereIn('id', $scaleIds)->where('is_active', true)->orderBy('id')->get()
    ```
  - **Before** — pair 2 of 2 (`BaFrameworkSnapshotService.php:307-314`):
    ```php
                    'levels' => BaRatingLevel::where('rating_scale_id', $s->id)->where('is_active', true)->orderBy('id')->get()
                        ->map(fn (BaRatingLevel $l) => [
                            'id' => (int) $l->id,
                            'label' => $l->label,
                            'grade_label' => $l->grade_label,
                            'numeric_value' => self::dec($l->numeric_value),
                            'sort_order' => (int) $l->sort_order,
                        ])->values()->all(),
    ```
  - **After:**
    ```php
                    'levels' => $levelRows->get((int) $s->id, collect())
                        ->map(fn (BaRatingLevel $l) => [
                            'id' => (int) $l->id,
                            'label' => $l->label,
                            'grade_label' => $l->grade_label,
                            'numeric_value' => self::dec($l->numeric_value),
                            'sort_order' => (int) $l->sort_order,
                        ])->values()->all(),
    ```
  - **Verify:** `grep -n "BaRatingLevel::where('rating_scale_id', \$s->id)" Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **BAR-12** · M · QRY-03/QRY-15 · `BaReportController.php:155,263,587,695` — select only the dropdown columns for the period selector.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Before** (`BaReportController.php:155` — identical at 263, 587, 695):
    ```php
            $periods = BaAssessmentPeriod::orderByDesc('created_at')->get();
    ```
  - **After:**
    ```php
            $periods = BaAssessmentPeriod::orderByDesc('created_at')->get(['id', 'name', 'status', 'created_at']);
    ```
  - Apply the same replacement to all four occurrences (lines 155, 263, 587, 695).
  - **Verify:** `grep -n "BaAssessmentPeriod::orderByDesc('created_at')->get()" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Expect:** no output; `grep -c "get(\['id', 'name', 'status', 'created_at'\]" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php` prints `4`.
  - **Effort:** S

- [ ] **BAR-15** · L · TEN-02 · `BehaviouralScoreService.php:690-692` — put the tenant's database name in the scale-cache key.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php`
  - **Before** (`BehaviouralScoreService.php:690-692`):
    ```php
        public function resolveScale(int $academicSessionId, ?int $classId = null): ?BaRatingScale
        {
            $key = $academicSessionId.':'.($classId ?? '-');
    ```
  - **After:**
    ```php
        public function resolveScale(int $academicSessionId, ?int $classId = null): ?BaRatingScale
        {
            $key = DB::connection()->getDatabaseName().':'.$academicSessionId.':'.($classId ?? '-');
    ```
  - **Verify:** `grep -n "\\$key = \\$academicSessionId" Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php`
  - **Expect:** no output (the `DB` facade import already exists at line 8).
  - **Effort:** S

## 7. Views (F10)

## 8. Style (F12) — one item per file

- [ ] **BAR-16** · L · STY-02/CTL-10 · `BaReportController.php:19-27,21,25,293,304,383,703` — make the controller Pint-clean, drop the two unused imports, and remove the four `⚠` markers.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Before** — pair 1 of 2 (`BaReportController.php:19-27` — the two unused imports are 21 and 25):
    ```php
    use Modules\BehaviouralAssessment\Models\BaComputedOverall;
    use Modules\BehaviouralAssessment\Models\BaComputedScore;
    use Modules\BehaviouralAssessment\Models\BaConfig;
    use Modules\BehaviouralAssessment\Models\BaCriterion;
    use Modules\BehaviouralAssessment\Models\BaAuditLog;
    use Modules\BehaviouralAssessment\Models\BaIncident;
    use Modules\BehaviouralAssessment\Models\BaRatingScale;
    use Modules\BehaviouralAssessment\Models\BaReportExport;
    use Modules\BehaviouralAssessment\Models\BaStudentRemark;
    ```
  - **After:**
    ```php
    use Modules\BehaviouralAssessment\Models\BaComputedOverall;
    use Modules\BehaviouralAssessment\Models\BaComputedScore;
    use Modules\BehaviouralAssessment\Models\BaCriterion;
    use Modules\BehaviouralAssessment\Models\BaAuditLog;
    use Modules\BehaviouralAssessment\Models\BaIncident;
    use Modules\BehaviouralAssessment\Models\BaReportExport;
    use Modules\BehaviouralAssessment\Models\BaStudentRemark;
    ```
  - **Before** — pair 2 of 2 (`BaReportController.php:293` — representative; the same `⚠ ` prefix is at lines 304, 383, 703):
    ```php
             * ⚠ This block used to average a column named 'score'. There is no such
    ```
  - **After:**
    ```php
             * Note: this block used to average a column named 'score'. There is no such
    ```
  - Then run `vendor/bin/pint` on the file so the remaining STY-02 fixers from the report evidence (`fully_qualified_strict_types`, `unary_operator_spaces`, `not_operator_with_successor_space`, `ordered_imports`) are applied, and on lines 304, 383, 703 replace the same `⚠ ` prefix with `Note: `.
  - **Verify:** `vendor/bin/pint --test --format agent Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php` and `grep -c "⚠" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php`
  - **Expect:** Pint prints `{"tool":"pint","result":"passed"}` and the grep prints `0`.
  - **Effort:** S

- [ ] **BAR-17** · L · STY-04 · `BehaviouralScoreService.php:323` — replace the `⚠` marker in the one comment.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php`
  - **Before** (`BehaviouralScoreService.php:323`):
    ```php
                     * ⚠ This was (max + 1) - raw, which is the same thing ONLY when the
    ```
  - **After:**
    ```php
                     * Note: this was (max + 1) - raw, which is the same thing ONLY when the
    ```
  - **Verify:** `grep -c "⚠" Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php`
  - **Expect:** prints `0`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BAR-04** · H · DECISION · CTL-02 — split the five oversized report methods (`student` 108, `byClass` 159, `incidents` 158, `period` 104, `categories` 110 lines)?
  - **Why it is a decision:** the extraction is a behaviour-neutral refactor of the whole report builder; D3 settles that god-controller splits are deferred and never applied in this pass.
  - (a) ⭐ defer to the split pass (D3) — no change now; the methods stay as-is and the CTL-07 `compact()` crowding and the CTL-08 `request()` helper are converted inside that split (BAR-06).
  - (b) extract now — pull the statistic blocks into private methods in this same controller file only (no new routes, no behaviour change); larger diff, higher regression risk on report pages.
  - (c) leave as accepted and stop reporting the size.
  - ➜ Choice: ____

- [ ] **BAR-13** · M · DECISION · VIEW-01 — move the Exports-register `listing()` query out of `_exports.blade.php:23` and into the rendering controller?
  - **Why it is a decision:** the partial is owned by this report, but the controller that renders it is `BaDashboardController::reportsPage()` (a controller with no audit report yet) via `pages/reports.blade.php:364`; touching it reaches outside this plan's controller.
  - (a) ⭐ defer until the BaDashboardController report exists — the partial is one paginated query (≤10 rows) plus BAEXP-06's label lookups, so the blast radius is small until then.
  - (b) apply now with a `⚠ SHARED` tick — add `$exRows`/`$exSvc` to `BaDashboardController::reportsPage()` and change the partial to render only what it is given (touches the dashboard controller and `pages/reports.blade.php`, which are both in §0).
  - (c) leave as accepted — one bounded paginated query in a template.
  - ➜ Choice: ____

- [ ] **BAR-18** · M · DECISION · CTL-06 — the student report's "Class Rank" is computed school-wide; relabel or re-scope?
  - **Why it is a decision:** the computation (no class filter) works, but the widget's label promises a class rank; which one is the product intent is a product call, not a code bug.
  - (a) ⭐ relabel the widget to "Rank (period-wide)" in `student.blade.php:84` — no behaviour change, matches the computation and the controller comment, one-word change.
  - (b) scope `$classRankData` to the student's class-section — the rank then matches the label but excludes cross-class comparison and changes the number users see.
  - (c) leave as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BAR-06 | Low style debt on read-only GET pages: the `request()` helper works there. Every one of the 14 call sites sits inside the five oversized report methods that BAR-04 defers, so the conversion is part of that split (D3) — converting it now would touch the same bodies twice. |
| BAR-10 | Accepted performance debt: the per-category `updateOrCreate` loop is bounded by the category count per student, runs inside the single score-run transaction, and the table is at 1,737 rows today; the statement count is not the bottleneck of the run. |