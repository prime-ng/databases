# Status — GlobalMaster / StateController

**Fixed:** 2026-10-17 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
- **STAT-10** — applied by the restore-family commit `6d157fb2c` (2026-10-17): both state restore routes are POST and `x-prime.table.action-trashed` renders a CSRF form for a POST restore route. Chosen alternative to the plan's option (a) (DELETE + always-form component) because that would have changed every caller.

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| STAT-01 | `StateController.php` store/update/destroy/restore/forceDelete | All controller `try/catch` removed (D1); responses built after `DB::transaction`. `restore()` now does `findOrFail()` before the transaction. | `grep -c 'try {'` / `grep -c 'Log::'` / `grep -c getMessage` | `0` / `0` / `0` | 2026-10-17 |
| STAT-02 | `toggleStatus()` | `validate()` moved above the transaction, catch removed, every branch returns JSON. Bad payload proven to raise `ValidationException` status 422. Blocked parent-country path writes nothing. | rolled-back call with `is_active=x` | `ValidationException status=422` | 2026-10-17 |
| STAT-03/04/05 | — | Collateral of STAT-01/02 (plan §10). | — | — | 2026-10-17 |
| STAT-06 | `update()` | Duplicate generic `'Updated'` activityLog removed; the change-tracking `'updated'` entry (literal kept verbatim) is the one audit row. | `grep -c "'Updated'"` | `0` | 2026-10-17 |
| STAT-07 | `store()`/`update()` | Duplicate `Gate::authorize` removed — `StateRequest::authorize()` → `authorizeByCrudPermission('prime.global-master.state')` → `Gate::allows(...create/update)` (verified in `app/Traits/AuthorizesTenantFeature.php:21-28`). `toggleStatus` keeps its own gate. | `grep -c 'Gate::authorize'` | `9` (11 methods − store − update) | 2026-10-17 |
| STAT-08 | `StateRequest.php` short_name | `Rule::unique('glb_states')->ignore($stateId)` — mirrors live `glb_states_short_name_unique` (plain unique, so no `whereNull`). | `grep -c "Rule::unique('glb_states')"` | `2` | 2026-10-17 |
| STAT-09 | `routes/web.php` (both groups) | DECISION (a): the two `get-states/{countryId}` routes → non-existent `getStatesByCountry` removed; nothing referenced `get.states.by.country`. | `grep -n getStatesByCountry routes/web.php` | no output | 2026-10-17 |
| STAT-12 | `StateController.php` | Return types on all 11 public methods (`View` / `RedirectResponse` / `JsonResponse`). | `php -l` + `class_exists` | clean / true | 2026-10-17 |
| STAT-13 | `State.php` | `BelongsTo` / `HasMany` return types on `country()` / `districts()`. | tinker: `State::first()->districts()->withTrashed()->count()` | `26` | 2026-10-17 |
| STAT-14 / STAT-18 | `State.php` | Pint-clean rewrite; unused `HasFactory` import and commented factory line removed (no `State::factory()` caller found by grep). | `vendor/bin/pint … --format agent` | passed | 2026-10-17 |
| STAT-17 | controller, model, request | `declare(strict_types=1);` | `grep -c 'declare(strict_types=1)'` | `1` each | 2026-10-17 |
| STAT-19 | `forceDelete()` | DECISION (a): refuses early when the state still has districts (counted `withTrashed()`, because `glb_districts.state_id` is `ON DELETE RESTRICT` and sees trashed rows too). Readable flash, no write, no log. | rolled-back call on Andhra Pradesh | `302 -> State "Andhra Pradesh" still has 26 district(s). Delete or move them first.`; row count unchanged | 2026-10-17 |

## 3. Not applied
- **STAT-15** — DECISION (a): unpaginated index accepted as debt (comment on `index()`).
- **STAT-16** — DECISION (a): create/edit stay pages, deferred to the module modal pass (comment on `create()`).
- **STAT-11** — deferred per D3 (plan §10).

## 4. Needs Tarun's hand
- Browser: `/global-master/location-setup#state` — add, edit (one audit row now), toggle; trash → restore (POST); force-delete a state with districts → readable refusal.
- Nothing to migrate, seed or sync.

## 5. Unverifiable by this workflow (D4)
- STAT-07 relies on `StateRequest::authorize()`; a refusal can only be exercised by a role lacking `create`/`update`, and every test path runs as super admin.

## 6. Verification log
```
vendor/bin/pint StateController.php StateRequest.php State.php routes/web.php --format agent  → passed
php -l (4 files)                                         → No syntax errors
class_exists(controller, request, model)                 → true ×3
route:list (uncached) → 22 StateController routes, missing methods = 0 (control CountryController@index = true)
render index() / trashedState()                          → 185,907 / 105,956 bytes, OK
```

## 7. Final state
**FIXED.** Open: STAT-15, STAT-16 (accepted debt), STAT-11 (deferred).

## 8. Follow-up 2026-10-17: the transactions did not cover the record (AFC-09)

Found while fixing AppConfigController. `State` saves through `global_master_mysql`, but every `DB::transaction()` in this controller opened on the default `mysql` connection, where only `activityLog()` writes. These are two separate PDO handles, so the 6 transactions covered only the log. A failure after the save rolled back the audit row and left the record changed.

**Applied:** all 6 calls now use `WritesGlobalMaster::inGlobalMasterTransaction()` (new trait, `Http/Controllers/Concerns/`), which opens a `global_master_mysql` transaction around the default one. Tarun approved fixing all six FIXED controllers together.

**Verified:** `php -l` clean · class loads · every routed method exists · host page renders 200 · a simulated failure through this controller's helper rolls back both the record and the log · negative control: plain `DB::transaction` left the global_master write in place.
