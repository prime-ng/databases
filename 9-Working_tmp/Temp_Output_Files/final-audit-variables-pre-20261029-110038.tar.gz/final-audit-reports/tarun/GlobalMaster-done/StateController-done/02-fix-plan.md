# Fix Plan — GlobalMaster / StateController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` to `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/StateController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | Shared permission catalogue; the keys this controller needs already exist (`global-master.state`), so no edit is required |
| `Modules/GlobalMaster/app/Models/Country.php`, `Modules/GlobalMaster/app/Models/District.php` | Owned by the CountryController and DistrictController reports; used here for reads/guards only |
| `Modules/GlobalMaster/app/Policies/StatePolicy.php` | Registered but unconsulted (cross-cutting §7 of the report); converting to policy-based auth is a module-wide decision, not this plan |
| `resources/views/components/**` (including `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php`) | Shared components; the restore-anchor fix is inside the STAT-10 DECISION only |
| `app/Helpers/activityLog.php`, `app/Models/BaseModel.php`, `app/Traits/AuthorizesTenantFeature.php` | Common classes, not audited here |
| Any file under `database/migrations/` | Never edit an existing migration |
| `final-audit-reports/tarun/GlobalMaster-done/00-INDEX.md` | Update only the StateController row, never rewrite the file |

`Modules/GlobalMaster/routes/web.php` IS touched by ticked items STAT-09 and STAT-10 (marked SHARED); no other item may touch it.

## 1. Blockers reachable today

- [x] **STAT-09** · B · DECISION · RTE-02 — two routes point at `StateController@getStatesByCountry`, a method that does not exist (500 on the URL). ⚠ SHARED (route file).
  - **Why it is a decision:** removing or adding routes is a re-scope the fixer is told to stop on (final-audit.md §9.3), and the method's intended JSON shape is unknown.
  - (a) ⭐ remove the two dead routes (`web.php:62-63` and `:172-173`) — nothing in the repository references `get.states.by.country`, so the pages lose nothing
  - (b) implement `getStatesByCountry($countryId)` returning `State::where('country_id',$countryId)->get(['id','name'])` as JSON, and keep the routes
  - (c) leave as is and record as accepted (the URL stays a 500)
  - ➜ Choice: (a) — Tarun, 2026-10-17

- [x] **STAT-10** · H · DECISION · RTE-01 — `restore` is a GET route wired as a plain anchor in the shared PrimeCore trash component; a prefetch or mis-click un-trashes a state with no CSRF. ⚠ SHARED (route file + shared component).
  - **Why it is a decision:** a route-verb change plus a shared-component rewrite (anchor to a CSRF form + its JS) is a re-scope of files shared by every geography trash screen.
  - (a) ⭐ change both restore routes to `DELETE` and rebuild the restore control in `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` as a `@csrf`/`@method('DELETE')` form (mirroring the force-delete button in the same file), keeping the Swal confirm
  - (b) leave the GET route and record as accepted (no CSRF on restore stays)
  - (c) add a new POST route for restore and switch only the State trash view to a form (does not touch the shared component, but leaves two restore routes)
  - ➜ Choice: dual-mode x-prime component + POST routes (Tarun's alternative to (a)), applied in 6d157fb2c — 2026-10-17

## 2. Fixes that arm a latent defect (sequenced)

None. STAT-01 and STAT-02 must both be applied before the leftover `Log` and `ModelNotFoundException` imports are removed (the import pair lives at the end of STAT-02 and the plan order already runs STAT-01 first).

## 3. Errors & transactions (F1/F2)

- [x] **STAT-01** · H · ERR-00 · `Modules/GlobalMaster/app/Http/Controllers/StateController.php` — delete the controller `try/catch` blocks from `store`, `update`, `destroy`, `restore` and `forceDelete`, and build the redirects after the transaction. (`toggleStatus` is handled by STAT-02.)
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/StateController.php`
  - **Before** (`StateController.php:42-68`, method `store()`):
    ```php
    public function store(StateRequest $request)
    {
        Gate::authorize('prime.global-master.state.create');

        try {
            return DB::transaction(function () use ($request) {
                $state = State::create($request->validated());

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($state, 'Stored', ['message' => 'A new state was created.', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->to(route('central.global-master.location-setup.index').'#state')
                    ->with('success', flash('created.state'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('StateController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function store(StateRequest $request)
    {
        Gate::authorize('prime.global-master.state.create');

        DB::transaction(function () use ($request) {
            $state = State::create($request->validated());

            activityLog($state, 'Stored', ['message' => 'A new state was created.', 'other' => 'some other information']);
        });

        return redirect()->to(route('central.global-master.location-setup.index').'#state')
            ->with('success', flash('created.state'));
    }
    ```
  - **Before** (`StateController.php:94-151`, method `update()`):
    ```php
    public function update(StateRequest $request, State $state)
    {
        Gate::authorize('prime.global-master.state.update');

        try {
            return DB::transaction(function () use ($request, $state) {
                $original = $state->getOriginal();
                $state->update($request->validated());

                $changes = $state->getChanges();

                // Build a structured array of changes:
                $changedAttributes = [];

                foreach ($changes as $field => $newValue) {
                    // Exclude updated_at and other auto fields
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changedAttributes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                // Log only if there are changes
                if (! empty($changedAttributes)) {
                    activityLog($state, 'updated', [
                        'message' => 'State was updated.',
                        'changes' => $changedAttributes,
                        'performed_by' => Auth::user()->name,
                    ]);
                } else {
                    activityLog($state, 'updated', [
                        'message' => 'State was updated. No attributes changed.',
                        'performed_by' => Auth::user()->name,
                    ]);
                }

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($state, 'Updated', ['message' => 'A new state was updated.', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->to(route('central.global-master.location-setup.index').'#state')
                    ->with('success', flash('updated.state'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('StateController::update failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function update(StateRequest $request, State $state)
    {
        Gate::authorize('prime.global-master.state.update');

        DB::transaction(function () use ($request, $state) {
            $original = $state->getOriginal();
            $state->update($request->validated());

            $changes = $state->getChanges();

            $changedAttributes = [];

            foreach ($changes as $field => $newValue) {
                if ($field === 'updated_at') {
                    continue;
                }
                $changedAttributes[$field] = [
                    'old' => $original[$field] ?? null,
                    'new' => $newValue,
                ];
            }

            if (! empty($changedAttributes)) {
                activityLog($state, 'updated', [
                    'message' => 'State was updated.',
                    'changes' => $changedAttributes,
                    'performed_by' => Auth::user()->name,
                ]);
            } else {
                activityLog($state, 'updated', [
                    'message' => 'State was updated. No attributes changed.',
                    'performed_by' => Auth::user()->name,
                ]);
            }

            activityLog($state, 'Updated', ['message' => 'A new state was updated.', 'other' => 'some other information']);
        });

        return redirect()->to(route('central.global-master.location-setup.index').'#state')
            ->with('success', flash('updated.state'));
    }
    ```
  - **Before** (`StateController.php:156-184`, method `destroy()`):
    ```php
    public function destroy(State $state)
    {
        Gate::authorize('prime.global-master.state.delete');

        try {
            return DB::transaction(function () use ($state) {
                $state->is_active = false;
                $state->save();
                $state->delete();

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($state, 'Trashed', ['message' => 'State was deactivated and deleted', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->to(route('central.global-master.location-setup.index').'#state')
                    ->with('success', flash('trashed.state'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('StateController::destroy failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function destroy(State $state)
    {
        Gate::authorize('prime.global-master.state.delete');

        DB::transaction(function () use ($state) {
            $state->is_active = false;
            $state->save();
            $state->delete();

            activityLog($state, 'Trashed', ['message' => 'State was deactivated and deleted', 'other' => 'some other information']);
        });

        return redirect()->to(route('central.global-master.location-setup.index').'#state')
            ->with('success', flash('trashed.state'));
    }
    ```
  - **Before** (`StateController.php:196-222`, method `restore()`):
    ```php
    public function restore($id)
    {
        Gate::authorize('prime.global-master.state.restore');

        try {
            return DB::transaction(function () use ($id) {
                $state = State::withTrashed()->findOrFail($id);
                $state->restore();

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($state, 'Restored', ['message' => 'State was restored', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->route('central.global-master.state.trashed')->with('success', flash('restored.state'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('StateController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function restore($id)
    {
        Gate::authorize('prime.global-master.state.restore');

        DB::transaction(function () use ($id) {
            $state = State::withTrashed()->findOrFail($id);
            $state->restore();

            activityLog($state, 'Restored', ['message' => 'State was restored', 'other' => 'some other information']);
        });

        return redirect()->route('central.global-master.state.trashed')->with('success', flash('restored.state'));
    }
    ```
  - **Before** (`StateController.php:231-257`, method `forceDelete()`):
    ```php
    public function forceDelete($id)
    {
        Gate::authorize('prime.global-master.state.forceDelete');

        $state = State::withTrashed()->findOrFail($id);

        try {
            return DB::transaction(function () use ($state) {
                $state->forceDelete();

                activityLog($state, 'Deleted', ['message' => 'State was permanently deleted.']);

                return redirect()
                    ->route('central.global-master.state.trashed')
                    ->with('success', flash('force_deleted.state'));
            });
        } catch (\Throwable $e) {
            Log::error('StateController::forceDelete failed', [
                'id' => $id,
                'error' => $e->getMessage(),
            ]);

            return redirect()
                ->route('central.global-master.state.trashed')
                ->with('error', flash('operation_failed.state'));
        }
    }
    ```
  - **After:**
    ```php
    public function forceDelete($id)
    {
        Gate::authorize('prime.global-master.state.forceDelete');

        $state = State::withTrashed()->findOrFail($id);

        DB::transaction(function () use ($state) {
            $state->forceDelete();

            activityLog($state, 'Deleted', ['message' => 'State was permanently deleted.']);
        });

        return redirect()
            ->route('central.global-master.state.trashed')
            ->with('success', flash('force_deleted.state'));
    }
    ```
  - **Verify:** `grep -n "catch (" Modules/GlobalMaster/app/Http/Controllers/StateController.php`
  - **Expect:** no output after STAT-02 is also applied; before STAT-02, one line remains (`toggleStatus`).
  - **Effort:** M

- [x] **STAT-02** · H · ERR-02 · `Modules/GlobalMaster/app/Http/Controllers/StateController.php:262-320` — move `validate()` above the transaction, drop the try/catch, and build every JSON response after the transaction.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/StateController.php`
  - **Before** (`StateController.php:262-320`, method `toggleStatus()`):
    ```php
    public function toggleStatus(Request $request, State $state)
    {
        Gate::authorize('prime.global-master.state.update');

        try {
            return DB::transaction(function () use ($request, $state) {
                $request->validate([
                    'is_active' => 'required|boolean',
                ]);
                // get the new desired status
                $newStatus = $request->input('is_active');

                // check if parent country is acive or not
                $countryIsActive = $state->country->is_active ?? false;

                // if parent status is inactive but user try to make district active it will return error
                if (! $countryIsActive && $newStatus) {
                    // BLOCKED by the parent-country guard — no write happens, so nothing is
                    // logged. The activityLog() call used to sit ABOVE this guard and logged
                    // a 'Toggled' event for an activation this branch refuses to perform.
                    return response()->json([
                        'success' => false,
                        'is_active' => $state->is_active,
                        'message' => flash('status_switch_failed.state'),
                    ]);
                } else {
                    $state->is_active = $newStatus;

                    if ($state->save()) {
                        // begin::Activity Log
                        // Logged AFTER save() succeeds, still inside the transaction (Rule 3).
                        activityLog($state, 'Toggled', ['message' => 'A new state status was updated.', 'other' => 'some other information']);
                        // end::Activity Log

                        return response()->json([
                            'success' => true,
                            'is_active' => $state->is_active,
                            'message' => flash('status_updated.state'),
                        ]);
                    } else {
                        return response()->json([
                            'success' => false,
                            'is_active' => $state->is_active,
                            'message' => flash('status_switch_failed.state'),
                        ]);
                    }
                }

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('StateController::toggleStatus failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function toggleStatus(Request $request, State $state)
    {
        Gate::authorize('prime.global-master.state.update');

        $request->validate([
            'is_active' => 'required|boolean',
        ]);

        $newStatus = (bool) $request->input('is_active');
        $countryIsActive = $state->country->is_active ?? false;

        if (! $countryIsActive && $newStatus) {
            return response()->json([
                'success' => false,
                'is_active' => $state->is_active,
                'message' => flash('status_switch_failed.state'),
            ]);
        }

        $saved = DB::transaction(function () use ($state, $newStatus) {
            $state->is_active = $newStatus;
            $saved = $state->save();

            if ($saved) {
                activityLog($state, 'Toggled', ['message' => 'A new state status was updated.', 'other' => 'some other information']);
            }

            return $saved;
        });

        return response()->json([
            'success' => (bool) $saved,
            'is_active' => $state->is_active,
            'message' => $saved ? flash('status_updated.state') : flash('status_switch_failed.state'),
        ]);
    }
    ```
  - **Before** (`StateController.php:5-11`, imports — remove the two lines only when STAT-01 is also applied, because the other five methods use them until then):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    ```
  - **Verify:** `grep -n "validate(\|catch (\|Log::\|ModelNotFoundException" Modules/GlobalMaster/app/Http/Controllers/StateController.php`
  - **Expect:** no output (after STAT-01 is applied too).
  - **Effort:** M

- [x] **STAT-06** · M · TXN-04 · `Modules/GlobalMaster/app/Http/Controllers/StateController.php:133-136` — delete the duplicate `activityLog($state, 'Updated', …)` block so one update writes one audit row.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/StateController.php`
  - **Before** (`StateController.php:126-139`, method `update()`):
    ```php
                } else {
                    activityLog($state, 'updated', [
                        'message' => 'State was updated. No attributes changed.',
                        'performed_by' => Auth::user()->name,
                    ]);
                }

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($state, 'Updated', ['message' => 'A new state was updated.', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->to(route('central.global-master.location-setup.index').'#state')
    ```
  - **After:**
    ```php
                } else {
                    activityLog($state, 'updated', [
                        'message' => 'State was updated. No attributes changed.',
                        'performed_by' => Auth::user()->name,
                    ]);
                }

                return redirect()->to(route('central.global-master.location-setup.index').'#state')
    ```
  - **Verify:** `grep -c "activityLog(\$state, 'Updated'" Modules/GlobalMaster/app/Http/Controllers/StateController.php`
  - **Expect:** `0`
  - **Effort:** S

## 4. Authorization (F3)

- [x] **STAT-07** · L · AUTH-04 · `Modules/GlobalMaster/app/Http/Controllers/StateController.php:44,96` — drop the duplicate `Gate::authorize` in `store`/`update` (the FormRequest already authorizes). Keep `toggleStatus`'s own `Gate::authorize` — it has no FormRequest.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/StateController.php`
  - **Before** (`StateController.php:42-45`, method `store()`):
    ```php
    public function store(StateRequest $request)
    {
        Gate::authorize('prime.global-master.state.create');

        try {
    ```
  - **After:**
    ```php
    public function store(StateRequest $request)
    {
        try {
    ```
  - **Before** (`StateController.php:94-98`, method `update()`):
    ```php
    public function update(StateRequest $request, State $state)
    {
        Gate::authorize('prime.global-master.state.update');

        try {
    ```
  - **After:**
    ```php
    public function update(StateRequest $request, State $state)
    {
        try {
    ```
  - **Verify:** `grep -n "Gate::authorize" Modules/GlobalMaster/app/Http/Controllers/StateController.php`
  - **Expect:** 9 matches (one per remaining method; the `store` and `update` lines are gone).
  - **Effort:** S
  - ⚠ This item deletes only the `Gate::authorize` lines; it is independent of STAT-01 (the `try {` line is left in place by this item and removed by STAT-01).

## 5. Validation, routes, models (F4/F5/F7)

- [x] **STAT-08** · H · VAL-04 · `Modules/GlobalMaster/app/Http/Requests/StateRequest.php:31-35` — add a `short_name` uniqueness rule matching the live `glb_states_short_name_unique` index.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/StateRequest.php`
  - **Before** (`StateRequest.php:31-35`):
    ```php
            'short_name' => [
                'required',
                'string',
                'max:10',
            ],
    ```
  - **After:**
    ```php
            'short_name' => [
                'required',
                'string',
                'max:10',
                Rule::unique('glb_states')->ignore($stateId),
            ],
    ```
  - **Verify:** `grep -n "Rule::unique('glb_states')" Modules/GlobalMaster/app/Http/Requests/StateRequest.php`
  - **Expect:** two matches (one on `name`, one on `short_name`).
  - **Effort:** S
  - ⚠ The extra live global index `glb_states_name_unique (name)` is schema drift versus the DDL and is NOT fixed here — see report §7.

- [x] **STAT-12** · L · CTL-04 · `Modules/GlobalMaster/app/Http/Controllers/StateController.php` (11 signatures) — add return types to every public method.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/StateController.php`
  - **Before** (`StateController.php:21`):
    ```php
    public function index()
    ```
  - **After:** add the three imports, then give each of the 11 methods the return type shown.
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\View\View;
    ```
    ```php
    public function index(): View
    public function create(): View
    public function store(StateRequest $request): RedirectResponse
    public function show(State $state): View
    public function edit(State $state): View
    public function update(StateRequest $request, State $state): RedirectResponse
    public function destroy(State $state): RedirectResponse
    public function trashedState(): View
    public function restore($id): RedirectResponse
    public function forceDelete($id): RedirectResponse
    public function toggleStatus(Request $request, State $state): JsonResponse
    ```
  - **Verify:** `grep -cE 'public function [a-zA-Z_]+\([^)]*\): ' Modules/GlobalMaster/app/Http/Controllers/StateController.php`
  - **Expect:** `11`
  - **Effort:** S

- [x] **STAT-13** · L · MDL-04 · `Modules/GlobalMaster/app/Models/State.php:30-38` — add `BelongsTo`/`HasMany` return types to the two relationships.
  - **Touches:** `Modules/GlobalMaster/app/Models/State.php`
  - **Before** (`State.php:29-38`):
    ```php
    //begin::Eloquent Relationship
    public function country()
    {
        return $this->belongsTo(Country::class);
    }

    public function districts()
    {
        return $this->hasMany(District::class);
    }
    ```
  - **After:** also add the imports `use Illuminate\Database\Eloquent\Relations\BelongsTo;` and `use Illuminate\Database\Eloquent\Relations\HasMany;` next to the other class imports.
    ```php
    // begin::Eloquent Relationship
    public function country(): BelongsTo
    {
        return $this->belongsTo(Country::class);
    }

    public function districts(): HasMany
    {
        return $this->hasMany(District::class);
    }
    ```
  - **Verify:** `grep -n "public function country(): BelongsTo\|public function districts(): HasMany" Modules/GlobalMaster/app/Models/State.php`
  - **Expect:** two matches.
  - **Effort:** S

## 6. Queries & performance (F9)

None. STAT-15 is a DECISION (§9); no mechanical query edit is planned here.

## 7. Views (F10)

None. STAT-16 is a DECISION (§9); no mechanical view edit is planned here.

## 8. Style (F12) — one item per file

- [x] **STAT-14** · L · CTL-10 / STY-05 · `Modules/GlobalMaster/app/Models/State.php` — apply the Pint-clean rewrite (removes the unused `HasFactory` import and normalises spacing). Clears STAT-18 too.
  - **Touches:** `Modules/GlobalMaster/app/Models/State.php`
  - **Before** (`State.php:1-8`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\SoftDeletes;
    // use Modules\GlobalMaster\Database\Factories\StateFactory;
    ```
  - **After:** (the whole file, after `vendor/bin/pint`)
    ```php
    <?php

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;

    // use Modules\GlobalMaster\Database\Factories\StateFactory;

    class State extends BaseModel
    {
        use SoftDeletes;

        protected $connection = 'global_master_mysql';

        protected $table = 'glb_states';

        protected $fillable = [
            'country_id',
            'name',
            'short_name',
            'global_code',
            'is_active',
        ];

        protected $casts = [
            'is_active' => 'boolean',
        ];

        // begin::Eloquent Relationship
        public function country()
        {
            return $this->belongsTo(Country::class);
        }

        public function districts()
        {
            return $this->hasMany(District::class);
        }

        // end::Eloquent Relationship
    }
    ```
  - **Verify:** `vendor/bin/pint --test Modules/GlobalMaster/app/Models/State.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}` (or no failing files).
  - **Effort:** S

- [x] **STAT-17** · L · STY-01 · `Modules/GlobalMaster/app/Http/Controllers/StateController.php:1`, `.../Models/State.php:1`, `.../Requests/StateRequest.php:1` — add `declare(strict_types=1);` to the three files.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/StateController.php`, `Modules/GlobalMaster/app/Models/State.php`, `Modules/GlobalMaster/app/Http/Requests/StateRequest.php`
  - **Before** (`StateController.php:1-3`; the model and request open the same way):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
    Same two-line insertion, replacing only the `namespace ...;` line, in:
    ```php
    namespace Modules\GlobalMaster\Models;
    ```
    ```php
    namespace Modules\GlobalMaster\Http\Requests;
    ```
  - **Verify:** `grep -c "declare(strict_types=1);" Modules/GlobalMaster/app/Http/Controllers/StateController.php Modules/GlobalMaster/app/Models/State.php Modules/GlobalMaster/app/Http/Requests/StateRequest.php`
  - **Expect:** `1` for each of the three files.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **STAT-15** · M · DECISION · QRY-02 — the state list (`index`) loads every country and every state unpaginated; paginate it or accept the debt?
  - **Why it is a decision:** the screen groups states under their country, so pagination changes the page contract (paginate countries, or flatten to a paginated state list) — not a mechanical swap.
  - (a) ⭐ leave as is and record as accepted debt (central master, live data 1 country / 36 states)
  - (b) flatten the screen to a paginated state list (`State::with('country')->paginate(10)`) and update `index.blade.php`
  - (c) paginate countries (the outer list) and keep the nested state accordion
  - ➜ Choice: (a) — Tarun, 2026-10-17

- [x] **STAT-16** · M · DECISION · VIEW (modal-standard §2.5) — convert the state create/edit pages to the shared modal, or defer to the module-wide modal pass?
  - **Why it is a decision:** it is a UI conversion shared with Country/District/City, changes the routes' view contract, and the module has a standing modal backlog.
  - (a) ⭐ defer to the module modal-conversion pass — record it as accepted debt now
  - (b) convert `create`/`edit` for State only (touches the controller methods and both blades)
  - (c) leave as is permanently and record as accepted
  - ➜ Choice: (a) — Tarun, 2026-10-17

- [x] **STAT-19** · M · DECISION · F13 deep-read — `forceDelete` of a state that still has districts is rejected by the DB foreign key (`ON DELETE RESTRICT`); pick the behaviour.
  - **Why it is a decision:** it changes what the user sees on a real screen and needs a product answer, not a mechanical edit.
  - (a) ⭐ block early in `forceDelete` with a clear flash when `$state->districts()->exists()`
  - (b) leave the DB to reject and translate the `QueryException` into a readable message
  - (c) leave as is and record as accepted (the generic error stays)
  - ➜ Choice: (a) — Tarun, 2026-10-17

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| STAT-03 | Collateral of STAT-01 and STAT-02: removing the `try/catch` envelopes deletes the six `Log::error(… getMessage())` lines. No separate edit is needed. |
| STAT-04 | Collateral of STAT-02: with `validate()` outside the transaction and the catch gone, every branch of `toggleStatus` returns JSON. No separate edit is needed. |
| STAT-05 | Collateral of STAT-01 and STAT-02: their After blocks build the redirect/JSON after `DB::transaction(...)`, so no response is constructed inside a transaction. No separate edit is needed. |
| STAT-11 | DEFERRED per D3 (fix in place, no re-scope): converting `restore`/`forceDelete` to route model binding needs the route parameters changed from `{id}` to `{state}` with trash support. No user-visible defect; recorded as accepted debt. |
| STAT-18 | Collateral of STAT-14: the Pint-clean rewrite of `State.php` covers the `class_attributes_separation`, `single_line_comment_spacing` and `single_line_after_imports` fixers. No separate edit is needed. |
