# Final Audit — GlobalMaster / StateController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/StateController.php` (322 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/global-master/state` (list), `/global-master/state/create`, `/global-master/state/{state}` (show), `/global-master/state/{state}/edit`, `/global-master/state/trash/view`. A second copy answers on `http://test.localhost:8000/prime/state...` (route group `central.prime.state.*`). Create/update/delete redirect to `http://test.localhost:8000/global-master/location-setup#state`. |
| Menu path | System Config → Location Setup → State tab (the live tab screen is `cg-global-master.location-setup.index#state`). |
| Who uses it | Super Admin and any role holding `prime.global-master.state.*` (central db, `prime` scope). Seeded centrally by `Modules/Prime/database/seeders/RolePermissionSeeder`. |
| What a user does here | A platform operator maintains the states (provinces) under each country: adds a state under a country, edits its name / short name / global code / active flag, views one, moves it to trash, restores it, permanently deletes it, and toggles its active status from the list. A state cannot be made active while its parent country is inactive. |
| Tables written | `global_master.glb_states` (create / update / soft-delete / restore / force-delete / status toggle) and `sys_central_activity_logs` (one row per mutation through the common `activityLog()` helper). |
| Tables read | `global_master.glb_states`, `global_master.glb_countries` (list, show, edit, toggle parent guard). |
| Live data | On `global_master_mysql`: `glb_states` 36 rows (0 trashed), `glb_countries` 1 row ("India"), `glb_districts` 785 rows (26 belong to the first state). The base table carries three unique keys: `uq_state_country_name (country_id,name)`, `glb_states_name_unique (name)`, `glb_states_short_name_unique (short_name)`. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready, though the defects are few and mechanical. The single worst finding is **STAT-09**: two registered routes (`central.global-master.get.states.by.country`, `central.prime.get.states.by.country`) point at `StateController@getStatesByCountry`, and **no such method exists anywhere in the repository** — that URL is a guaranteed 500 the moment it is hit. Second is **STAT-10**: `restore` is a GET route wired through a plain anchor in the shared trash component, so a prefetcher or a mis-click un-trashes a state with no CSRF. Third, **STAT-08** blocks a normal create: the validation rules do not match the real unique indexes, so a duplicate `short_name` (or a name that already exists under another country) passes validation and then collides with the DB. The rest is the retired house "A1" try/catch pattern (which protocol D1 bans), a duplicated audit write on every update, missing pagination on the list, and style debt. Rough effort to fix the plan: S–M — mostly deleting try/catch envelopes and adding two unique rules.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 4 | 8 | 6 | 5 | 19 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | STAT-01, STAT-02, STAT-03, STAT-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | STAT-05, STAT-06 | F9 Queries/Perf | STAT-15 |
| F3 Authorization | STAT-07 | F10 Views | STAT-16 |
| F4 Validation | STAT-08 | F11 Security/Tenancy | clean |
| F5 Routes | STAT-09, STAT-10 | F12 Style | STAT-17, STAT-18 |
| F6 Controller shape | STAT-11, STAT-12 | F13 Deep read | STAT-19 |
| F7 Models | STAT-13, STAT-14 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/StateController.php` | controller | 322 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Models/State.php` | model | 41 | this report (claimed in 00-CLASS-OWNERS.md) | ✅ |
| 3 | `Modules/GlobalMaster/app/Http/Requests/StateRequest.php` | form request | 63 | this report (claimed in 00-CLASS-OWNERS.md) | ✅ |
| 4 | `Modules/GlobalMaster/app/Models/Country.php` | model | 31 | ↗ [tarun/GlobalMaster-done/CountryController](../CountryController-done/01-report.md) | ↗ linked — usage only (`has('states')`, `with('states')` in `index`) |
| 5 | `Modules/GlobalMaster/app/Models/District.php` | model | 39 | ↗ [tarun/GlobalMaster-done/DistrictController](../DistrictController-done/01-report.md) (same batch) | ↗ linked — usage only (FK guard on `forceDelete`) |
| 6 | `Modules/GlobalMaster/resources/views/state/index.blade.php` | view | 72 | this report | ✅ |
| 7 | `Modules/GlobalMaster/resources/views/state/create.blade.php` | view | 63 | this report | ✅ |
| 8 | `Modules/GlobalMaster/resources/views/state/edit.blade.php` | view | 66 | this report | ✅ |
| 9 | `Modules/GlobalMaster/resources/views/state/show.blade.php` | view | 66 | this report | ✅ |
| 10 | `Modules/GlobalMaster/resources/views/state/trash.blade.php` | view | 53 | this report | ✅ |
| 11 | `Modules/GlobalMaster/routes/web.php` (state rows 57-63 and 167-173 only) | route file | 198 | ⚠ SHARED — state rows only | ✅ usage; edits are ⚠ SHARED |
| 12 | `App\Http\Controllers\Controller`, `App\Models\BaseModel`, `App\Traits\AuthorizesTenantFeature`, `app/Helpers/activityLog.php`, `app/Helpers/helpers.php` (flash), `Modules/Prime/resources/views/components/**` (`table.action`, `table.action-trashed`, `table.status-switch`, `card.header`, `components.breadcrum`, `layouts.app`) | common | — | common (§4.2) | referenced, not owned |

No pre-applied files — no `PRE-APPLIED-2026-10-10.md` exists for GlobalMaster.

## 4. Routes

Uncached route list filtered for `StateController@` (from the fresh `/tmp/fa-routes.json`, generated with `APP_ROUTES_CACHE=/tmp/fa-nocache.php`):

```
GET|HEAD  global-master/get-states/{countryId}             central.global-master.get.states.by.country   StateController@getStatesByCountry
GET|HEAD  global-master/state                              central.global-master.state.index             StateController@index
POST      global-master/state                              central.global-master.state.store             StateController@store
GET|HEAD  global-master/state/create                       central.global-master.state.create            StateController@create
GET|HEAD  global-master/state/trash/view                   central.global-master.state.trashed           StateController@trashedState
DELETE    global-master/state/{id}/force-delete            central.global-master.state.forceDelete       StateController@forceDelete
GET|HEAD  global-master/state/{id}/restore                 central.global-master.state.restore           StateController@restore
GET|HEAD  global-master/state/{state}                      central.global-master.state.show              StateController@show
PUT|PATCH global-master/state/{state}                      central.global-master.state.update            StateController@update
DELETE    global-master/state/{state}                      central.global-master.state.destroy           StateController@destroy
GET|HEAD  global-master/state/{state}/edit                 central.global-master.state.edit              StateController@edit
POST      global-master/state/{state}/toggle-status        central.global-master.state.toggleStatus      StateController@toggleStatus
GET|HEAD  prime/get-states/{countryId}                     central.prime.get.states.by.country           StateController@getStatesByCountry
GET|HEAD  prime/state                                      central.prime.state.index                     StateController@index
POST      prime/state                                      central.prime.state.store                     StateController@store
GET|HEAD  prime/state/create                               central.prime.state.create                    StateController@create
GET|HEAD  prime/state/trash/view                           central.prime.state.trashed                   StateController@trashedState
DELETE    prime/state/{id}/force-delete                    central.prime.state.forceDelete               StateController@forceDelete
GET|HEAD  prime/state/{id}/restore                         central.prime.state.restore                   StateController@restore
GET|HEAD  prime/state/{state}                              central.prime.state.show                      StateController@show
PUT|PATCH prime/state/{state}                              central.prime.state.update                    StateController@update
DELETE    prime/state/{state}                              central.prime.state.destroy                   StateController@destroy
GET|HEAD  prime/state/{state}/edit                         central.prime.state.edit                      StateController@edit
POST      prime/state/{state}/toggle-status                central.prime.state.toggleStatus              StateController@toggleStatus
```

Unrouted public methods: none — all 11 public methods are routed. The reverse is broken: the two `get-states` routes point at `getStatesByCountry`, which does not exist (STAT-09).

Route file shape (`Modules/GlobalMaster/routes/web.php:57-63`, repeated at 167-173): `Route::resource('state', …)` comes first, then the four custom routes and the AJAX route. The custom URIs (`/state/trash/view`, `/state/{id}/restore`, `/state/{id}/force-delete`, `/state/{state}/toggle-status`, `/get-states/{countryId}`) cannot be captured by the resource's `/{state}` single segment, so RTE-06 is not triggered. Both groups sit inside `Route::domain(config('app.domain'))` (central only); the `prime` group uses `['auth','verified','2fa']` and the `global-master` group uses `['auth','verified']` — RTE-05 clean.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 21 | GET /global-master/state (+ prime/state) | `prime.global-master.state.viewAny` | none (read) | — | reads glb_countries, glb_states | STAT-15 |
| `create` | 32 | GET /global-master/state/create | `prime.global-master.state.create` | none (read) | — | — | STAT-16 |
| `store` | 42 | POST /global-master/state | `prime.global-master.state.create` (+ FormRequest) | controller `DB::transaction` | `Stored` | glb_states, sys_central_activity_logs | STAT-01, STAT-05, STAT-07, STAT-08, STAT-12 |
| `show` | 73 | GET /global-master/state/{state} | `prime.global-master.state.view` | none (read) | — | reads glb_states, glb_countries | — |
| `edit` | 84 | GET /global-master/state/{state}/edit | `prime.global-master.state.update` | none (read) | — | reads glb_states | STAT-16 |
| `update` | 94 | PUT/PATCH /global-master/state/{state} | `prime.global-master.state.update` (+ FormRequest) | controller `DB::transaction` | `updated`, `Updated` (twice) | glb_states, sys_central_activity_logs | STAT-01, STAT-05, STAT-06, STAT-07, STAT-08, STAT-12 |
| `destroy` | 156 | DELETE /global-master/state/{state} | `prime.global-master.state.delete` | controller `DB::transaction` | `Trashed` | glb_states, sys_central_activity_logs | STAT-01, STAT-05, STAT-12 |
| `trashedState` | 188 | GET /global-master/state/trash/view | `prime.global-master.state.restore` | none (read) | — | reads glb_states | — |
| `restore` | 196 | GET /global-master/state/{id}/restore | `prime.global-master.state.restore` | controller `DB::transaction` | `Restored` | glb_states, sys_central_activity_logs | STAT-01, STAT-05, STAT-10, STAT-11, STAT-12 |
| `forceDelete` | 231 | DELETE /global-master/state/{id}/force-delete | `prime.global-master.state.forceDelete` | controller `DB::transaction` | `Deleted` | glb_states, sys_central_activity_logs | STAT-01, STAT-05, STAT-11, STAT-12, STAT-19 |
| `toggleStatus` | 262 | POST /global-master/state/{state}/toggle-status | `prime.global-master.state.update` | controller `DB::transaction` | `Toggled` | glb_states, sys_central_activity_logs | STAT-01, STAT-02, STAT-04, STAT-05, STAT-12 |

## 6. Findings

### F1 — Errors

#### STAT-01 · H · ERR-00 — the five CRUD/trash methods wrap their writes in a controller try/catch (D1)

| Field | Value |
|---|---|
| **Rule** | ERR-00 (H) — *no `try`/`catch` in controllers; `DB::transaction()` rolls back by itself and the central handler in `bootstrap/app.php` renders the error* (protocol D1). The same blocks also break ERR-05 (M) — *log the exception, not the message*. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:46-67` (`store()`); identical shape at `:98-150` (`update()`), `:160-183` (`destroy()`), `:200-221` (`restore()`), `:237-256` (`forceDelete()`). The sixth block, `toggleStatus()` `:266-319`, is filed as STAT-02. |
| **Root cause** | Each mutating method wraps its `DB::transaction(...)` in `try { … } catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { Log::error(…, ['error' => $e->getMessage()]); return back()->with('error', …); }`. Protocol D1 supersedes the retired house "Rule A1" for audited modules and none of the D2 exceptions apply (no `\DomainException`, no truncate-then-rebuild, no `SnapshotProtectionException`). The `catch (ModelNotFoundException)` is unreachable in `store`/`update`/`destroy` (nothing calls `findOrFail()` on that path — the bound `State` already exists or the model is created). The generic catch turns a genuine 500 into a red flash and logs only the message, losing the stack trace the central handler would have written. |
| **Consequence** | On a real write failure the user gets the vague "The operation could not be completed." instead of the framework error page, and no trace reaches the log to diagnose it. |
| **Reproduce** | static only — exercising the failure branch needs a DB write that throws, and D4 forbids tests. The shape is visible at the five line ranges above. |
| **Fix approach** | Delete the outer `try`/`catch` in all five methods; keep `DB::transaction(...)` and build the redirect after the closure returns (this also clears STAT-05). Delete the now-unused `Log` and `ModelNotFoundException` imports after both try/catch items are applied. |
| **Plan item** | STAT-01 in `02-fix-plan.md` §3 |

```php
// StateController.php:46-67 — CURRENT (store; identical shape in update/destroy/restore/forceDelete)
        try {
            return DB::transaction(function () use ($request) {
                $state = State::create($request->validated());

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($state, 'Stored', ['message' => 'A new state was created.', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->to(route('central.global-master.location-setup.index').'#state')
                    ->with('success', flash('created.state'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('StateController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -c "try {" Modules/GlobalMaster/app/Http/Controllers/StateController.php
6
$ grep -n "catch (" Modules/GlobalMaster/app/Http/Controllers/StateController.php
59:        } catch (ModelNotFoundException $e) {
63:        } catch (\Throwable $e) {
142:        } catch (ModelNotFoundException $e) {
146:        } catch (\Throwable $e) {
175:        } catch (ModelNotFoundException $e) {
179:        } catch (\Throwable $e) {
213:        } catch (ModelNotFoundException $e) {
217:        } catch (\Throwable $e) {
247:        } catch (\Throwable $e) {
311:        } catch (ModelNotFoundException $e) {
315:        } catch (\Throwable $e) {
```

#### STAT-02 · H · ERR-02 — toggleStatus swallows a 422 and answers the AJAX caller with a redirect

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422/`abort()` into a redirect or 500.* Also breaks ERR-00 (D1) and ERR-04 (STAT-04). |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:266-319`, method `toggleStatus()` |
| **Root cause** | `$request->validate([...])` runs **inside** the `try` (line 268) and inside the transaction closure, so the `ValidationException` it throws is caught by the generic `catch (\Throwable $e)` at line 315 and turned into `back()->with('error', …)`. The endpoint is only ever called by the status-switch AJAX control, which expects JSON. |
| **Consequence** | A bogus `is_active` value from the status-switch AJAX call returns a 302 HTML redirect instead of a JSON 422; the checkbox silently flips back with no message. |
| **Reproduce** | `curl -X POST http://test.localhost:8000/global-master/state/{state}/toggle-status -d 'is_active=banana'`. Expected JSON 422; actual 302 HTML redirect. |
| **Fix approach** | Move `validate()` above the transaction and remove the try/catch (D1); build all JSON responses after the transaction closure. |
| **Plan item** | STAT-02 in `02-fix-plan.md` §3 |

```php
// StateController.php:266-319 — CURRENT (validate inside try; catch turns ValidationException into back())
        try {
            return DB::transaction(function () use ($request, $state) {
                $request->validate([
                    'is_active' => 'required|boolean',
                ]);
                // get the new desired status
                $newStatus = $request->input('is_active');
```

**Evidence**
```
$ grep -n "validate(\|catch (\\\\Throwable" Modules/GlobalMaster/app/Http/Controllers/StateController.php
268:                $request->validate([
315:        } catch (\Throwable $e) {
```

#### STAT-03 · M · ERR-05 — six log calls drop the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace.* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:64,147,180,218,248-251,316` |
| **Root cause** | The retired A1 catch template logs `['error' => $e->getMessage()]` — the exact anti-pattern the rulebook's Contradictions table bans. |
| **Consequence** | Every failure is logged without a stack trace; the message alone cannot locate the failing call, and raw SQL text leaks into the log file. |
| **Reproduce** | static only — read the six log lines. |
| **Fix approach** | The try/catch envelopes are removed by STAT-01/STAT-02, which deletes these lines; nothing must log `.getMessage()` alone. |
| **Plan item** | none — collateral of STAT-01 and STAT-02 (see plan §10) |

```php
// StateController.php:64 — CURRENT (identical at 147, 180, 218, 248-251, 316)
            Log::error('StateController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/GlobalMaster/app/Http/Controllers/StateController.php
64:            Log::error('StateController::store failed', ['error' => $e->getMessage()]);
147:            Log::error('StateController::update failed', ['error' => $e->getMessage()]);
180:            Log::error('StateController::destroy failed', ['error' => $e->getMessage()]);
218:            Log::error('StateController::restore failed', ['error' => $e->getMessage()]);
250:                'error' => $e->getMessage(),
316:            Log::error('StateController::toggleStatus failed', ['error' => $e->getMessage()]);
```

#### STAT-04 · M · ERR-04 — toggleStatus mixes JSON and HTML failure paths without expectsJson()

| Field | Value |
|---|---|
| **Rule** | ERR-04 (M) — *JSON endpoints fail with JSON; form endpoints fail with a redirect; use `$request->expectsJson()` when one method serves both.* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:282-307` (JSON success/block branches) vs `:315-318` (HTML `back()` catch) |
| **Root cause** | Every success branch returns `response()->json(...)` but the only failure branch (the catch) returns `back()->with('error', ...)`. The endpoint is only ever called by the AJAX status switch. |
| **Consequence** | Any failure (validation, DB) delivers HTML to the JSON caller; the toggle silently fails with no user message. |
| **Reproduce** | `curl -X POST http://test.localhost:8000/global-master/state/{state}/toggle-status` without `is_active` — inspect the response `Content-Type`: `text/html`, not JSON. |
| **Fix approach** | STAT-02 removes the catch and moves `validate()` outside the transaction, so the 422 the central renderer produces is JSON for AJAX. |
| **Plan item** | none — collateral of STAT-02 (see plan §10) |

```php
// StateController.php:315-318 — CURRENT (the HTML failure path)
        } catch (\Throwable $e) {
            Log::error('StateController::toggleStatus failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "response()->json\|back()" Modules/GlobalMaster/app/Http/Controllers/StateController.php
66:            return back()->with('error', 'The operation could not be completed.');
149:            return back()->with('error', 'The operation could not be completed.');
182:            return back()->with('error', 'The operation could not be completed.');
220:            return back()->with('error', 'The operation could not be completed.');
282:                    return response()->json([
296:                        return response()->json([
302:                        return response()->json([
318:            return back()->with('error', 'The operation could not be completed.');
```

### F2 — Transactions and audit

#### STAT-05 · M · TXN-05 — HTTP responses are built inside the `DB::transaction` closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()`/`response()` after it.* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:55-56` (`store`), `:138-139` (`update`), `:171-172` (`destroy`), `:210` (`restore`), `:243-245` (`forceDelete`), `:282-306` (`toggleStatus`) |
| **Root cause** | Each closure ends with `return redirect()…` / `return response()->json(…)` while the transaction is still open; the commit only happens because the closure returns the response. |
| **Consequence** | No user-visible break today, but the response object and flash session write are assembled inside the atomic block, which couples response construction to the transaction and is the reason the `try`/`catch` around it (STAT-01/STAT-02) looks necessary. |
| **Reproduce** | static only — read any of the six closures. |
| **Fix approach** | Covered by the STAT-01 and STAT-02 rewrites: each closure performs only the writes and returns nothing; the redirect/JSON is built after `DB::transaction(...)`. |
| **Plan item** | none — resolved by STAT-01 and STAT-02 (see plan §10) |

```php
// StateController.php:47-58 — CURRENT (store; same return-inside-closure shape in the other five)
            return DB::transaction(function () use ($request) {
                $state = State::create($request->validated());
                activityLog($state, 'Stored', ['message' => 'A new state was created.', 'other' => 'some other information']);
                return redirect()->to(route('central.global-master.location-setup.index').'#state')
                    ->with('success', flash('created.state'));
            });
```

**Evidence**
```
$ grep -n "return DB::transaction\|return redirect\|return response" Modules/GlobalMaster/app/Http/Controllers/StateController.php
47:            return DB::transaction(function () use ($request) {
55:                return redirect()->to(route('central.global-master.location-setup.index').'#state')
99:            return DB::transaction(function () use ($request, $state) {
138:                return redirect()->to(route('central.global-master.location-setup.index').'#state')
161:            return DB::transaction(function () use ($state) {
171:                return redirect()->to(route('central.global-master.location-setup.index').'#state')
201:            return DB::transaction(function () use ($id) {
210:                return redirect()->route('central.global-master.state.trashed')->with('success', flash('restored.state'));
238:            return DB::transaction(function () use ($state) {
243:                return redirect()
267:            return DB::transaction(function () use ($request, $state) {
282:                    return response()->json([
```

#### STAT-06 · M · TXN-04 / F13 — update() writes TWO audit rows for one update

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* (one log per mutation); F13 deep-read #3 (duplicate implementation) / #7 (a message that lies). |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:121-131` (structured `'updated'` log) and `:133-136` (the copy-pasted `'Updated'` log) |
| **Root cause** | The structured change-diff log was added, but the original boilerplate `activityLog($state, 'Updated', ['message' => 'A new state was updated.', …])` was left in place. Every update therefore writes two audit rows — the second with a generic message that describes a creation ("A new state was updated.") and the wrong event casing. |
| **Consequence** | The audit trail for a state edit shows two entries, one of which carries no details and a misleading message; an auditor counting changes double-counts every update. |
| **Reproduce** | Edit any state and open the Activity Log screen — two rows appear for the single update. |
| **Fix approach** | Delete the second `activityLog($state, 'Updated', …)` block, keeping the structured `'updated'` log. |
| **Plan item** | STAT-06 in `02-fix-plan.md` §3 |

```php
// StateController.php:120-137 — CURRENT (two logs for one update)
                if (! empty($changedAttributes)) {
                    activityLog($state, 'updated', [
                        'message' => 'State was updated.',
                        'changes' => $changedAttributes,
                        'performed_by' => Auth::user()->name,
                    ]);
                } else {
                    activityLog($state, 'updated', [
                        'message' => 'State was updated. No attributes changed.',
                        'performed_by' => Auth::user()->name,
                    ]);
                }

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($state, 'Updated', ['message' => 'A new state was updated.', 'other' => 'some other information']);
                // end::Activity Log
```

**Evidence**
```
$ grep -n "activityLog(\$state" Modules/GlobalMaster/app/Http/Controllers/StateController.php
121:                    activityLog($state, 'updated', [
127:                    activityLog($state, 'updated', [
135:                activityLog($state, 'Updated', ['message' => 'A new state was updated.', 'other' => 'some other information']);
```

### F3 — Authorization

#### STAT-07 · L · AUTH-04 — the same permission is checked twice on store and update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one.* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:42-45` (store) and `:94-98` (update); `Modules/GlobalMaster/app/Http/Requests/StateRequest.php:48-54` |
| **Root cause** | `StateRequest::authorize()` calls `authorizeByCrudPermission('prime.global-master.state')`, which maps POST→`prime.global-master.state.create` and PUT/PATCH→`prime.global-master.state.update`; the controller then calls `Gate::authorize` for the same names immediately after. The FormRequest runs first, so the controller call can never change the outcome. |
| **Consequence** | No security gap — the check is redundant; it costs one extra Gate lookup and creates a second place to keep in sync. |
| **Reproduce** | static only — read both files. |
| **Fix approach** | Keep the FormRequest `authorize()` and drop the two `Gate::authorize` calls in `store()`/`update()`. |
| **Plan item** | STAT-07 in `02-fix-plan.md` §4 |

```php
// StateController.php:42-44 (store) and :94-96 (update)
    public function store(StateRequest $request)
    {
        Gate::authorize('prime.global-master.state.create');
```

**Evidence**
```
$ grep -n "Gate::authorize\|authorizeByCrudPermission" Modules/GlobalMaster/app/Http/Controllers/StateController.php Modules/GlobalMaster/app/Http/Requests/StateRequest.php
StateController.php:23:        Gate::authorize('prime.global-master.state.viewAny');
StateController.php:34:        Gate::authorize('prime.global-master.state.create');
StateController.php:44:        Gate::authorize('prime.global-master.state.create');
StateController.php:75:        Gate::authorize('prime.global-master.state.view');
StateController.php:86:        Gate::authorize('prime.global-master.state.update');
StateController.php:96:        Gate::authorize('prime.global-master.state.update');
StateController.php:158:        Gate::authorize('prime.global-master.state.delete');
StateController.php:190:        Gate::authorize('prime.global-master.state.restore');
StateController.php:198:        Gate::authorize('prime.global-master.state.restore');
StateController.php:233:        Gate::authorize('prime.global-master.state.forceDelete');
StateController.php:264:        Gate::authorize('prime.global-master.state.update');
StateRequest.php:53:        return $this->authorizeByCrudPermission('prime.global-master.state');
```

### F4 — Validation and input

#### STAT-08 · H · VAL-04 — uniqueness rules do not mirror the real unique indexes

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the DB unique index including soft-delete semantics.* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/StateRequest.php:20-42` (`name` rule at :22-30, `short_name` rule at :31-35) |
| **Root cause** | The live `global_master.glb_states` table has three unique keys (`SHOW CREATE TABLE` below): `uq_state_country_name (country_id,name)`, `glb_states_name_unique (name)`, `glb_states_short_name_unique (short_name)`. The request validates `name` unique only **within the chosen country** and gives `short_name` **no uniqueness rule at all**. So (a) a `short_name` that already exists passes validation and then violates `glb_states_short_name_unique`, and (b) a `name` that already exists under a **different** country passes validation and then violates `glb_states_name_unique`. Both are `QueryException` on a normal create path. |
| **Consequence** | A user adding a state with an existing short name (or a name already used in another country) gets the generic "The operation could not be completed." and the state is not saved; the screen never explains which value collided. |
| **Reproduce** | `SHOW CREATE TABLE glb_states` shows `glb_states_short_name_unique`. Create two states with the same `short_name` (different names) — the second is rejected by the DB after validation passes. |
| **Fix approach** | Add `Rule::unique('glb_states')->ignore($stateId)` to `short_name` (matches `glb_states_short_name_unique` and the DDL's `uq_glb_states_shortName`). The extra global `name` index is schema drift versus the DDL — see §7 cross-cutting, it needs the schema owner's decision. |
| **Plan item** | STAT-08 in `02-fix-plan.md` §5 (short_name rule only) |

```php
// StateRequest.php:31-35 — CURRENT (short_name has no uniqueness rule)
            'short_name' => [
                'required',
                'string',
                'max:10',
            ],
```

**Evidence**
```
$ php artisan tinker --execute '$c=DB::connection("global_master_mysql"); foreach($c->select("SHOW CREATE TABLE glb_states") as $r){ echo $r->{"Create Table"}; }'
CREATE TABLE `glb_states` (
  ...
  UNIQUE KEY `uq_state_country_name` (`country_id`,`name`),
  UNIQUE KEY `glb_states_name_unique` (`name`),
  UNIQUE KEY `glb_states_short_name_unique` (`short_name`),
  ...
)
$ grep -n "Rule::unique" Modules/GlobalMaster/app/Http/Requests/StateRequest.php
27:                Rule::unique('glb_states')->where(function ($query) {
```

### F5 — Routes

#### STAT-09 · B · RTE-02 — two routes point at a method that does not exist

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *every route points to a method that exists.* |
| **Where** | `Modules/GlobalMaster/routes/web.php:63` and `:173` — `Route::get('/get-states/{countryId}', [StateController::class, 'getStatesByCountry'])` |
| **Root cause** | The route declares `StateController@getStatesByCountry`, but the controller has 11 public methods and none is `getStatesByCountry`; `method_exists` returns `false` and the name appears nowhere else in the repository. Laravel resolves the route only when it is hit, at which point the container cannot find the action and throws. |
| **Consequence** | Any request to `/global-master/get-states/{countryId}` or `/prime/get-states/{countryId}` returns a 500 instead of JSON. No current Blade references the route (the `select-state` component receives `$states` already loaded), so the break is latent until a caller is added — but the URL is live and directly reachable. |
| **Reproduce** | `curl -I http://test.localhost:8000/global-master/get-states/1` — expected JSON, actual 500 (action not found). |
| **Fix approach** | Decide whether to remove the two dead routes or implement the method; see the DECISION. |
| **Plan item** | STAT-09 in `02-fix-plan.md` §1 (DECISION, ⚠ SHARED route file) |

```php
// routes/web.php:62-63 — CURRENT (identical at :172-173)
        // AJAX to get states by country
        Route::get('/get-states/{countryId}', [StateController::class, 'getStatesByCountry'])->name('get.states.by.country');
```

**Evidence**
```
$ php artisan tinker --execute 'var_dump(method_exists("Modules\\GlobalMaster\\Http\\Controllers\\StateController", "getStatesByCountry"));'
bool(false)
$ grep -rn "function getStatesByCountry" Modules app
(no output)
$ grep -rn "get-states\|get.states.by.country" Modules resources
Modules/GlobalMaster/routes/web.php:63:        Route::get('/get-states/{countryId}', [StateController::class, 'getStatesByCountry'])->name('get.states.by.country');
Modules/GlobalMaster/routes/web.php:173:        Route::get('/get-states/{countryId}', [StateController::class, 'getStatesByCountry'])->name('get.states.by.country');
```

#### STAT-10 · H · RTE-01 — restore changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …); GET has no CSRF protection and link prefetchers trigger it.* |
| **Where** | `Modules/GlobalMaster/routes/web.php:59` and `:169` (`Route::get('/state/{id}/restore', …)`), controller `restore()` at `Modules/GlobalMaster/app/Http/Controllers/StateController.php:196-222`; the trash view calls it through `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php:5` |
| **Root cause** | `restore()` un-deletes a row (a write) but the route is `GET`. The shared PrimeCore `action-trashed` component renders restore as a plain `<a href="…restore…">` with only a JavaScript `confirm()` — unlike the backend `action-trashed` component, this one does not switch to a POST form when the route verb changes. |
| **Consequence** | Any GET that hits `/global-master/state/{id}/restore` restores the state with no CSRF check; a link prefetcher, the browser back button, or a crawler can silently un-trash a state. |
| **Reproduce** | Visit `http://test.localhost:8000/global-master/state/36/restore` (id of any trashed state) — the state is restored on GET, with no `_token`. |
| **Fix approach** | Change both restore routes to DELETE and rebuild the restore control in the shared component as a CSRF POST/DELETE form (mirroring the force-delete button beside it). Both files are shared — see the DECISION. |
| **Plan item** | STAT-10 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED route file + shared component) |

```php
// routes/web.php:59 — CURRENT (identical at :169)
        Route::get('/state/{id}/restore', [StateController::class, 'restore'])->name('state.restore');
```

**Evidence**
```
$ grep -n "state/{id}/restore" Modules/GlobalMaster/routes/web.php
59:        Route::get('/state/{id}/restore', [StateController::class, 'restore'])->name('state.restore');
169:        Route::get('/state/{id}/restore', [StateController::class, 'restore'])->name('state.restore');
$ grep -n "restore" Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php
5:        <a href="{{ route($url . '.restore', $id) }}" class="btn btn-outline-warning btn-sm confirm-action-restore">
```

### F6 — Controller shape

#### STAT-11 · M · CTL-03 — restore/forceDelete take `$id` + `findOrFail()` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(State $state)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`.* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:196-202` (`restore`), `:231-235` (`forceDelete`) |
| **Root cause** | `show`, `edit`, `update` and `toggleStatus` already type-hint `State $state` and get the 404 for free. The two trash/lifecycle methods use `$id` + `State::withTrashed()->findOrFail($id)` instead — the route params are passed positionally so it works, but it re-implements what binding gives free. |
| **Consequence** | More code per method; the resource route parameter is `{state}` while `restore`/`forceDelete` use `{id}`, a renaming trap. No user-visible defect today. |
| **Reproduce** | static only. |
| **Fix approach** | DEFERRED — converting to implicit binding needs `{id}`→`{state}` route edits with trash support, which D3 (fix in place, no re-scope) parks. Record as accepted debt. |
| **Plan item** | none — deferred per D3 (see plan §10) |

```php
// StateController.php:196-202 — CURRENT (restore; forceDelete at :231-235 identical shape)
    public function restore($id)
    {
        Gate::authorize('prime.global-master.state.restore');

        try {
            return DB::transaction(function () use ($id) {
                $state = State::withTrashed()->findOrFail($id);
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+' Modules/GlobalMaster/app/Http/Controllers/StateController.php
21:    public function index()
32:    public function create()
42:    public function store(StateRequest $request)
73:    public function show(State $state)
84:    public function edit(State $state)
94:    public function update(StateRequest $request, State $state)
156:    public function destroy(State $state)
188:    public function trashedState()
196:    public function restore($id)
231:    public function forceDelete($id)
262:    public function toggleStatus(Request $request, State $state)
```

#### STAT-12 · L · CTL-04 — public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`).* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:21,32,42,73,84,94,156,188,196,231,262` (all 11 public methods) |
| **Root cause** | None of the methods declares a return type. |
| **Consequence** | A caller (and static analysis) cannot tell a redirect method from a view method; a wrong return becomes a runtime surprise instead of a compile-time signal. |
| **Reproduce** | static only. |
| **Fix approach** | Add the matching return type to each method (see plan). |
| **Plan item** | STAT-12 in `02-fix-plan.md` §5 |

```php
// StateController.php:21 — CURRENT
    public function index()
```

**Evidence**
```
$ grep -cE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/GlobalMaster/app/Http/Controllers/StateController.php
11
```

### F7 — Models

#### STAT-13 · L · MDL-04 — State relationships have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`…).* |
| **Where** | `Modules/GlobalMaster/app/Models/State.php:30-38` (`country()`, `districts()`) |
| **Root cause** | Both relations return `$this->belongsTo(...)` / `$this->hasMany(...)` without a declared return type. |
| **Consequence** | Style/consistency only; no runtime effect. |
| **Reproduce** | static only. |
| **Fix approach** | Declare `: BelongsTo` and `: HasMany` and import the two relation classes. |
| **Plan item** | STAT-13 in `02-fix-plan.md` §5 |

```php
// State.php:29-38 — CURRENT
    //begin::Eloquent Relationship
    public function country()
    {
        return $this->belongsTo(Country::class);
    }

    public function districts()
    {
        return $this->hasMany(District::class);
    }
```

**Evidence**
```
$ grep -n "public function" Modules/GlobalMaster/app/Models/State.php
30:    public function country()
35:    public function districts()
$ php artisan tinker --execute '$s=Modules\GlobalMaster\Models\State::with("country")->first(); echo $s->name." > ".($s->country->name ?? "NULL")." districts=".$s->districts()->count().PHP_EOL;'
Andhra Pradesh > India districts=26
```

#### STAT-14 · L · CTL-10 / STY-05 — State imports `HasFactory` but never uses it

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M dead code) lowered to **L** — the import is inert; plus STY-05 (L) — *no unused imports.* |
| **Where** | `Modules/GlobalMaster/app/Models/State.php:6,12` |
| **Root cause** | The file imports `Illuminate\Database\Eloquent\Factories\HasFactory`, but the class body only applies `use SoftDeletes;`. Pint reports `no_unused_imports` on this file. |
| **Consequence** | Dead code that misleads a reader into thinking the model has a factory; `StateFactory` does not exist (the commented-out import on line 8 confirms none was written). |
| **Reproduce** | `vendor/bin/pint --test Modules/GlobalMaster/app/Models/State.php` → `fail`, fixers include `no_unused_imports`. |
| **Fix approach** | Delete the `use HasFactory;` import line (applied by the STAT-14 Pint-clean item). |
| **Plan item** | STAT-14 in `02-fix-plan.md` §8 |

```php
// State.php:5-12 — CURRENT
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
// use Modules\GlobalMaster\Database\Factories\StateFactory;

class State extends BaseModel
{
    use SoftDeletes;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/GlobalMaster/app/Models/State.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\/GlobalMaster\/app\/Models\/State.php","fixers":["class_attributes_separation","single_line_comment_spacing","no_unused_imports","single_line_after_imports"]}]}
```

### F8 — Services and jobs

clean — the controller has no constructor injection, service, job, listener, event, mail or notification. `grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b' Modules/GlobalMaster/app/Http/Controllers/StateController.php` → only `StateRequest` (a FormRequest). `activityLog()` and `flash()` are helper functions, not services.

### F9 — Queries and performance

#### STAT-15 · M · QRY-02 — the state list is not paginated

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M, lowered from the H default with reason *central master with tiny live data — 1 country / 36 states*) — *lists are paginated; no unbounded `->get()` feeding a list page.* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:24`, method `index()` |
| **Root cause** | `Country::has('states')->with('states')->get()` loads every country that has states and every one of its states into a page that renders an accordion of all of them. There is no `paginate()` (the trash list at :191 correctly paginates at 10). |
| **Consequence** | On a full global master (hundreds of countries, tens of thousands of states) the screen loads every state in one request; today it is only 36 rows, so the cost is invisible. |
| **Reproduce** | static only — live data is 36 states. |
| **Fix approach** | Paginate the list. Because the screen groups states under their country, this is a UI/contract decision, not a mechanical swap — see the DECISION. |
| **Plan item** | STAT-15 in `02-fix-plan.md` §9 (DECISION) |

```php
// StateController.php:23-24 — CURRENT
        Gate::authorize('prime.global-master.state.viewAny');
        $countriesWithStates = Country::has('states')->with('states')->get();
```

**Evidence**
```
$ grep -n "has('states')\|paginate" Modules/GlobalMaster/app/Http/Controllers/StateController.php
24:        $countriesWithStates = Country::has('states')->with('states')->get();
191:        $states = State::onlyTrashed()->paginate(10);
```

F9 rest clean: `trashedState()` paginates at 10 (QRY-02 ✓); `show()` eager-loads the country it prints (VIEW-02 ✓); `index()` eager-loads `states` so the per-row switch does not N+1; no queries inside loops; no raw SQL; no `Model::all()`.

### F10 — Views

#### STAT-16 · M · VIEW (modal-standard §2.5) — create/edit are dedicated pages where the standard wants a modal

| Field | Value |
|---|---|
| **Rule** | VIEW / `modal-standard.md` §2.5 (M) — *a create page with 15 or fewer visible controls is converted to the shared modal; over 15, do not convert.* |
| **Where** | `Modules/GlobalMaster/resources/views/state/create.blade.php:24-53` and `edit.blade.php:24-56`; controller `create`/`edit` at `:32-37`/`:84-89` |
| **Root cause** | The state form has 5 visible controls (country select, name, short name, global code, status switch) — under the 15-control ceiling — yet it renders as a full page. The list screen's tab already expects in-place add/edit. This is a module-wide pattern (shared with Country/District/City). |
| **Consequence** | A user adding a state leaves the list and reloads a page instead of getting the standard in-place modal; the UI is inconsistent with the tab screen's own "add" affordance. |
| **Reproduce** | Open `http://test.localhost:8000/global-master/state/create` — a full page, not a modal. |
| **Fix approach** | Decide whether to convert this controller's create/edit to the shared modal now or defer to the module's modal pass. |
| **Plan item** | STAT-16 in `02-fix-plan.md` §9 (DECISION) |

```php
// create.blade.php:24-25 — CURRENT (full-page form)
                        <form action="{{ route('central.global-master.state.store') }}" method="POST"
                            enctype="multipart/form-data">
```

**Evidence**
```
$ grep -c "x-backend.form.input-text\|x-backend.form.status-switch\|x-backend.form.select-country" Modules/GlobalMaster/resources/views/state/create.blade.php
5
$ grep -n "form action" Modules/GlobalMaster/resources/views/state/create.blade.php
24:                        <form action="{{ route('central.global-master.state.store') }}" method="POST"
```

F10 rest clean — no `{!! !!}` in any state blade; no queries inside the blades; the status switch is gated by `permission="prime.global-master.state.update"`; `show.blade.php` prints `$state->country->name ?? '-'` on the relation the controller eager-loads. Proven by `grep -nE '::|->where|->get\(|->count\(|\{!!' Modules/GlobalMaster/resources/views/state/*.blade.php` → only HTML comment markers (`<!--begin::…-->`), no queries or raw echo.

### F11 — Security and tenancy

clean — no `env()` outside config, no hard-coded ids or `?? 1`, no request body or password logged, no personal data emitted. Permission names use the four-part `scope.module.feature.action` form and every one exists: `global-master.state => $crud` in `config/permissionslist.php:214`, and `$crud` is `['create','view','viewAny','update','delete','restore','forceDelete']`, flattening to exactly the seven `prime.global-master.state.*` keys the controller uses. Central-only routes run against the `global_master_mysql` connection with no tenant context.

### F12 — Style

#### STAT-17 · L · STY-01 — missing `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files (new files mandatory; old files when touched).* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:1`, `Modules/GlobalMaster/app/Models/State.php:1`, `Modules/GlobalMaster/app/Http/Requests/StateRequest.php:1` |
| **Root cause** | All three owned PHP files open with `<?php` and no `declare(strict_types=1);`. |
| **Consequence** | Style/consistency only; no runtime effect. |
| **Reproduce** | static only. |
| **Fix approach** | Insert `declare(strict_types=1);` after the opening tag in each of the three files. |
| **Plan item** | STAT-17 in `02-fix-plan.md` §8 |

```php
// StateController.php:1-3 (same opening in State.php and StateRequest.php)
<?php

namespace Modules\GlobalMaster\Http\Controllers;
```

**Evidence**
```
$ grep -c "declare(strict_types=1)" Modules/GlobalMaster/app/Http/Controllers/StateController.php Modules/GlobalMaster/app/Models/State.php Modules/GlobalMaster/app/Http/Requests/StateRequest.php
Modules/GlobalMaster/app/Http/Controllers/StateController.php:0
Modules/GlobalMaster/app/Models/State.php:0
Modules/GlobalMaster/app/Http/Requests/StateRequest.php:0
```

#### STAT-18 · L · STY-02 — State.php is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines.* |
| **Where** | `Modules/GlobalMaster/app/Models/State.php:6,8,12,14,17,29,40` |
| **Root cause** | Pint flags four fixers on this file: `class_attributes_separation`, `single_line_comment_spacing` (`//begin::` → `// begin::`), `no_unused_imports` (the `HasFactory` import) and `single_line_after_imports`. The controller and request are already Pint-clean. |
| **Consequence** | Style/consistency only; no runtime effect. |
| **Reproduce** | `vendor/bin/pint --test Modules/GlobalMaster/app/Models/State.php --format agent` → `fail`. |
| **Fix approach** | Run Pint on `State.php` (or paste the corrected file from the STAT-14 plan item, which also removes the unused import). |
| **Plan item** | none — the STAT-14 Pint-clean item rewrites the whole file (see plan §10) |

```php
// State.php:6-8 — CURRENT (unused import + missing blank line after imports)
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
// use Modules\GlobalMaster\Database\Factories\StateFactory;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/GlobalMaster/app/Models/State.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\/GlobalMaster\/app\/Models\/State.php","fixers":["class_attributes_separation","single_line_comment_spacing","no_unused_imports","single_line_after_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 wrong overwrite | 2 delete before store | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | STAT-08 | ok (DB unique keys) | ok | ok | ok |
| `update` | ok | ok | STAT-06 | STAT-08 | ok | ok | STAT-06 | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | ok | ok | ok | ok | STAT-19 | ok | STAT-19 | ok |
| `toggleStatus` | ok | ok | ok (guard added) | ok | ok | ok | STAT-02 | ok |

#### STAT-19 · M · F13 deep-read (#2/#5/#7) — `forceDelete` has no guard for dependent districts

| Field | Value |
|---|---|
| **Rule** | F13 deep-read — *is anything deleted before its replacement / is there a race; does a message lie.* The DB enforces it: `glb_districts.state_id` has `FOREIGN KEY … ON DELETE RESTRICT`. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/StateController.php:231-256`, method `forceDelete()` |
| **Root cause** | `$state->forceDelete()` runs on any trashed state. Live data has 785 districts under 36 states (26 under "Andhra Pradesh"), and `glb_districts_state_id_foreign` is `ON DELETE RESTRICT`, so deleting a state that still has districts throws a `QueryException`. The generic `catch (\Throwable)` (STAT-01) turns it into the vague `flash('operation_failed.state')`. The `activityLog` write sits **after** the delete, so nothing is logged for the attempt. |
| **Consequence** | Super Admin clicks the permanent-delete icon on a trashed state that has districts, confirms, and gets a generic "operation failed" with no explanation; the state can never be force-deleted while it has districts. |
| **Reproduce** | Trash a state that has districts, open `/global-master/state/trash/view`, and click permanent delete — expected a clear "remove its districts first" message; actual is the generic error. |
| **Fix approach** | Decide the behaviour: block early with a clear message when `$state->districts()->exists()`, or translate the FK failure into a readable message. |
| **Plan item** | STAT-19 in `02-fix-plan.md` §9 (DECISION) |

```php
// StateController.php:231-245 — CURRENT
    public function forceDelete($id)
    {
        Gate::authorize('prime.global-master.state.forceDelete');

        $state = State::withTrashed()->findOrFail($id);

        try {
            return DB::transaction(function () use ($state) {
                $state->forceDelete();

                activityLog($state, 'Deleted', ['message' => 'State was permanently deleted.']);
```

**Evidence**
```
$ php artisan tinker --execute '$c=DB::connection("global_master_mysql"); foreach($c->select("SELECT CONSTRAINT_NAME, DELETE_RULE FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=DATABASE() AND TABLE_NAME=\"glb_districts\"") as $r){ echo json_encode($r).PHP_EOL; }'
{"CONSTRAINT_NAME":"glb_districts_state_id_foreign","DELETE_RULE":"RESTRICT"}
$ php artisan tinker --execute '$c=DB::connection("global_master_mysql"); echo "states=".$c->table("glb_states")->count()." districts=".$c->table("glb_districts")->count();'
states=36 districts=785
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/GlobalMaster/app/Policies/StatePolicy.php` | Registered with `Gate::policy(State::class, StatePolicy::class)` at `GlobalMasterServiceProvider.php:74`, but **nothing consults it**: the controller authorizes with dot-string abilities (`Gate::authorize('prime.global-master.state.viewAny')`), which never reach a policy. The same is true of every GlobalMaster policy (`CountryPolicy`, `CityPolicy`, `DistrictPolicy`, …). Dead authorization surface — a module-wide pattern. | AUTH-06 / AUTH-01 | GlobalMaster authorization owner (outside this controller) |
| `pgdatabase/2-DDL_Tenant_Enhanced/_Core/_global_db_v4.1.sql:40-42` vs live `global_master.glb_states` | The canonical DDL declares `uq_glb_states_countryId_name (country_id,name)`, `uq_glb_states_shortName (short_name)`, `uq_glb_states_globalCode (global_code)`. The live table instead has `glb_states_name_unique (name)` (a **global** name unique, not in the DDL) and is **missing** the `global_code` unique. So the request's country-scoped `name` rule disagrees with the real global index, and `global_code` uniqueness is unenforced live. Schema drift — needs the DDL/migration owner. | VAL-04 (latent) / MDL-07 | Schema owner (additive migration decision) |
| `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php:5` | The shared PrimeCore trash-row component renders restore as a plain `<a href>` GET link (JS `confirm()` only). It is the browser-facing half of STAT-10 and is shared by every geography trash screen. | RTE-01 | Component owner |
| `Modules/GlobalMaster/routes/web.php` | Two complete route groups (`central.prime.state.*` and `central.global-master.state.*`) point at this controller. The `prime` group is referenced only by `app/Services/Breadcrumbs/registry.php`; the live screen uses the `global-master` names. Duplicated surface and a second place to keep middleware in sync. | RTE / CTL-05 | Route-file owner (shared) |
| `config/permissionslist.php` (`global-master.state`) | Key exists at line 214 with all seven `$crud` actions; no defect. Noted so the fixer does not add a new key. | — | — |
| `Modules/GlobalMaster/tests/Unit/ArchitectureTest.php` | References `State` / `StateRequest`. Not run — D4 forbids tests. Noted only. | — | — |

## 8. Not covered, and why

- **No write or failure path was executed.** D4 forbids tests; the FK rejection (STAT-19) and the validation/unique mismatch (STAT-08) were proven from the schema and the code, not by running them.
- **No Blade was rendered in a browser.** View checks were static (`grep`) and by reading the templates; the shared layout and PrimeCore components are common classes, not audited here.
- **The `activityLog()` sink** (`Modules/Prime/Models/ActivityLog` in central context, table `sys_central_activity_logs`) and `AuthorizesTenantFeature` are common classes; only the arguments passed from this controller were checked.
- **`StatePolicy`** was read but is not in the controller's mechanical scope; its dead-ness is recorded as a cross-cutting note in §7, not audited as an owned class.
