# GlobalMaster — Final Audit Summary

> Audited 2026-10-12 by opencode (module mode, protocol `.claude/rules/final-audit.md` §13).
> Developer: `tarun`. All 17 controllers `AUDITED`. No `prime_ai_dev/` code was changed (D4).

## Per-controller

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| AcademicSessionController | 124 | 0 | 2 | 6 | 4 | 3 | Owned `AcademicSession` model (first reach) has six relationships that crash at runtime — two import classes that don't exist, four resolve against unanswerable cross-connection tables. | [AcademicSessionController](AcademicSessionController-done/01-report.md) |
| ActivityLogController | 80 | 0 | 0 | 5 | 2 | 1 | All seven public methods unrouted (resource removed 2026-09-30) — dead class with live bodies, no D5 guard. | [ActivityLogController](ActivityLogController-done/01-report.md) |
| AppConfigController | 173 | 0 | 2 | 2 | 4 | 0 | Pre-D1 try/catch in all four mutations + `updateValue`/`toggleStatus` write two tables with no transaction → failed audit-log insert leaves setting changed. | [AppConfigController](AppConfigController-done/01-report.md) |
| AppModuleController | 184 | 0 | 1 | 5 | 4 | 0 | `toggleStatus()` = two un-transacted writes (glb_app_modules + activity log) → silent unlogged status change on audit-insert failure. | [AppModuleController](AppModuleController-done/01-report.md) |
| BoardController | 250 | 1 | 3 | 6 | 8 | 1 | `Board::create($request->all())` / `update($request->all())` write raw input; dead `organizations()` relation throws `42S02 sch_organizations not found` on first use. | [BoardController](BoardController-done/01-report.md) |
| CityController | 305 | 0 | 4 | 9 | 7 | 1 | `restore` = GET route wired as plain `<a href>` on trash screen → prefetch/crawler/mis-click restores with no CSRF (GEOCRUD family). | [CityController](CityController-done/01-report.md) |
| CountryController | 303 | 0 | 2 | 5 | 6 | 2 | `restore` mutates over GET with no CSRF; two phantom imports `App\Models\V1\GlobalMaster\{State,District}` that don't exist (dead). | [CountryController](CountryController-done/01-report.md) |
| DistrictController | 302 | 0 | 6 | 8 | 8 | 1 | `restore` over GET via shared trash component, no CSRF; H-count from soft-delete×unique gaps + forceDelete FK risk. | [DistrictController](DistrictController-done/01-report.md) |
| DropdownController | 128 | 0 | 1 | 4 | 4 | 1 | Whole controller dead (0 routes since 2026-08-24 move to `Modules\Prime`) with live N+1 bodies; `show()` renders a view that doesn't exist. | [DropdownController](DropdownController-done/01-report.md) |
| GeographySetupController | 160 | 1 | 1 | 4 | 3 | 1 | GEO-02 (B): `create`/`show`/`edit` routed but return Blades that don't exist → every live URL is a guaranteed 500. | [GeographySetupController](GeographySetupController-done/01-report.md) |
| GlobalMasterController | 56 | 0 | 0 | 1 | 4 | 0 | All seven methods unrouted `module:make` scaffold, no D5 guard. | [GlobalMasterController](GlobalMasterController-done/01-report.md) |
| LanguageController | 117 | 0 | 1 | 5 | 3 | 0 | `LanguageRequest::authorize()` checks never-seeded `prime.language.*` instead of seeded `prime.prime.language.*` → live create/update 403 all non-super-admins. | [LanguageController](LanguageController-done/01-report.md) |
| ModuleController | 322 | 1 | 4 | 8 | 6 | 4 | MOD-07 (B): creating a module always fails — `glb_modules.code` NOT NULL with no default and nobody supplies it; generic catch hides it. | [ModuleController](ModuleController-done/01-report.md) |
| OrganizationController | 56 | 0 | 0 | 2 | 1 | 1 | Dead scaffold: 7 unrouted methods, store/update/destroy return success-shaped empty 200, add-route → 500 on missing views. | [OrganizationController](OrganizationController-done/01-report.md) |
| PlanController | 348 | 0 | 4 | 13 | 9 | 3 | PLN-11: restore changes state over GET with no CSRF, reachable today from trash screen (largest controller, 26 findings). | [PlanController](PlanController-done/01-report.md) |
| SessionBoardSetupController | 65 | 0 | 0 | 5 | 2 | 1 | All 7 methods unrouted dead shells — stale duplicate of live `Modules\Prime` SessionBoardSetupController. | [SessionBoardSetupController](SessionBoardSetupController-done/01-report.md) |
| StateController | 322 | 1 | 4 | 8 | 6 | 5 | STAT-09 (B): two registered routes point at `getStatesByCountry` which exists nowhere → guaranteed 500. | [StateController](StateController-done/01-report.md) |

## Module totals

**B 4 · H 35 · M 96 · L 81 = 216 findings · 26 DECISION items**

## Cross-controller families (fix as ONE change each)

1. **Geo CRUD trash `restore` over GET, no CSRF** — CityController (CIT-09), CountryController (CNTRY-05), DistrictController (DIST-10/11), StateController (STAT-10), PlanController (PLN-11). Same shape: `Route::get('/…/{id}/restore')` + plain `<a href>` in a shared trash component. Fix as one module-wide change (route→POST + `x-backend.table.action-trashed`).
2. **Dead / unrouted controllers** — ActivityLogController, DropdownController (moved to Prime), SessionBoardSetupController (stale duplicate of Prime's), GlobalMasterController, OrganizationController (scaffolds). Five controllers, all with live bodies and no D5 guard. Each has a keep-D5-disabled / delete / re-wire DECISION; check `ArchitectureTest` before any deletion (OrganizationController → `ArchitectureTest.php:27`).
3. **Pre-D1 controller `try/catch (\Throwable)`** — AppConfigController (all 4 writes), AppModuleController, plus the fixed-flash-swallow pattern in ModuleController (MOD-07 hiding the B) and PlanController.
4. **Two-table writes with no transaction + activityLog** — AppConfigController (updateValue, toggleStatus), AppModuleController (toggleStatus). Should be ONE `DB::transaction` with the activity log inside.
5. **`$request->all()` into models** — BoardController (Board::create/update), CityController, CountryController, DistrictController, StateController, PlanController. Should be `validated()`/`safe()` per VAL-04.

## Shared classes and their owner reports

| Class | Owner report |
|---|---|
| `Prime/app/Models/AcademicSession.php`, `Http/Requests/AcademicSessionRequest.php` | AcademicSessionController |
| `Prime/app/Models/Language.php`, `Http/Requests/LanguageRequest.php` | LanguageController |
| `Prime/app/Models/ActivityLog.php` | ActivityLogController |
| `GlobalMaster/app/Models/Country.php`, `Http/Requests/CountryRequest.php` | CountryController |
| `GlobalMaster/app/Models/City.php`, `Http/Requests/CityRequest.php` | CityController |
| `GlobalMaster/app/Models/State.php`, `Http/Requests/StateRequest.php` | StateController |
| `GlobalMaster/app/Models/District.php`, `Http/Requests/DistrictRequest.php` | DistrictController |
| `GlobalMaster/app/Models/Board.php`, `Http/Requests/BoardRequest.php` | BoardController |
| `GlobalMaster/app/Models/Module.php`, `Http/Requests/ModuleRequest.php` | ModuleController |
| `GlobalMaster/app/Models/AppConfig.php`, `Http/Requests/AppConfigRequest.php` | AppConfigController |
| `GlobalMaster/app/Models/AppModule.php`, `Http/Requests/AppModuleRequest.php` | AppModuleController |
| `GlobalMaster/app/Models/Dropdown.php` | DropdownController |
| `GlobalMaster/app/Models/Plan.php`, `Http/Requests/PlanRequest.php`, `Prime/app/Models/Tenant.php`, `Prime/app/Models/TenantPlan.php`, `Billing/app/Models/BillingCycle.php` | PlanController |

First-reach of Prime/Billing module classes recorded here — later audits of Modules/Prime and Modules/Billing must LINK to these reports.

## Module-wide decisions (apply to multiple reports)

- **Geo CRUD restore-over-GET** → one shared route + component change (family #1 above).
- **Dead-controller end-states** → five DECISIONs; deleted controllers must keep D5 (`abort(403)` + `NOT ROUTED` comment) unless Tarun ticks delete, and deletion must respect `ArchitectureTest`.
- **Unique-key migrations** — CityController CIT-22 (three DDL unique keys on `glb_cities`), DistrictController DIST-09 (soft-delete-aware unique keys + missing `global_code`). Both additive; measure-then-apply; data-safe today (0 duplicates measured).

## Cross-cutting notes (not fixed here)

- **Duplicate Dropdown class**: `Modules/GlobalMaster/app/Models/Dropdown.php` (winning, autoloads from `app/`) vs stray `Modules/GlobalMaster/Models/Dropdown.php` (dead, reported DROPDOWN-03). Delete the stray in the fix pass.
- **Phantom imports**: `App\Models\V1\GlobalMaster\{District,State}` in CountryController — `App/Models` does not exist at all; dead imports (CNTRY-11), remove.
- **Dual ActivityLog classes**: `Prime/app/Models/ActivityLog` (central, `sys_central_activity_logs`, owned here) vs COMMON `GlobalMaster/app/Models/ActivityLog` tenant sink (`sys_activity_logs`) — the module imports Prime's; keep them distinct in the fix pass.
- **3-segment permission drift**: LanguageController — the seeded permission is `prime.prime.language.create`, the check uses `prime.language.create`. Grep the permission config before any fix to confirm the canonical name.
- `Modules/GlobalMaster/app/Models/Media.php`, `DropdownNeed.php` exist but no GlobalMaster controller imports them — code-catalogue candidates for the fix pass.

## Cross-controller finding 2026-10-17 — AFC-09: transactions on the wrong connection

Every GlobalMaster model except Plan saves through `global_master_mysql`. `activityLog()` and a plain `DB::transaction()` use the default `mysql` connection. These are separate PDO handles, so the transactions covered only the audit row, not the record. Measured: 36 calls across Country, State, District, City, Board and Module, plus AppConfig's 4. The audits marked each one "transaction ✅" because they counted calls and never checked which database each call opened on.

**Fixed** with `Modules/GlobalMaster/app/Http/Controllers/Concerns/WritesGlobalMaster.php` (`inGlobalMasterTransaction()`, a `global_master_mysql` transaction wrapped around the default one). PlanController has its own equivalent (`inPlanTransaction()`, PLN-27), because Plan lives on `mysql` and only its pivot is on `global_master_mysql`.

⚠ **Every remaining GlobalMaster controller needs the same treatment when its turn comes.** AppModule, Language, AcademicSession, SessionBoardSetup, Dropdown and Organization: check each model's connection, and use the trait wherever the model is on `global_master_mysql`.
