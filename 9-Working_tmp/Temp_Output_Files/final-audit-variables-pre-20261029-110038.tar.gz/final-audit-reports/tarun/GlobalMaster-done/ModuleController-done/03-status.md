# Status — GlobalMaster / ModuleController

**Fixed:** 2026-10-17 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
| ID | What | Where |
|---|---|---|
| MOD-11 | Restore over GET → POST route + dual-mode `x-prime.table.action-trashed` (hidden CSRF form when the `.restore` route is POST). | commit `6d157fb2c` (restore family, all 12 GlobalMaster restore routes) |

## 2. Applied
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| MOD-07 | `ModuleController.php` store() | DECISION (a). `code` generated as `strtoupper(substr(Str::of(name)->slug(), 0, 6))`, the seeder idiom. Create used to fail on NOT NULL `code` with no default. | rolled-back `store()` with payload `name="ZZ Probe Module"` | RedirectResponse, `code=ZZ-PRO`, 1 menu attached, 0 rows after rollback | 2026-10-17 |
| MOD-01 | `ModuleController.php` (all 6 mutations) | try/catch, `ModelNotFoundException` rethrows and `Log::error(getMessage())` removed (D1). `destroy()` now binds `Module $module`. Return types `RedirectResponse` / `JsonResponse`. Unused imports dropped. Closes MOD-02/03/04. | `grep -n "catch\|Log::\|getMessage"` | only two comment hits (class docblock, toggleStatus docblock) | 2026-10-17 |
| MOD-05 | — | DECISION (a): responses stay inside the transaction closures; recorded in the class docblock. | — | — | 2026-10-17 |
| MOD-06 | `ModuleRequest.php` | `authorize()` returns `true`; `AuthorizesTenantFeature` trait removed. The controller's `Gate::authorize()` on store/update is the single check. | `grep -n AuthorizesTenantFeature` | no output | 2026-10-17 |
| MOD-08 | `ModuleRequest.php` | `name` unique rule mirrors `uq_module_key_live` (live rows, same version, `COALESCE(parent_id,0)`). | validator: existing name + same version / other version | FAILS / PASSES — as intended | 2026-10-17 |
| MOD-09 | `ModuleRequest.php` | `is_sub_module` rule removed; `version` is `required|integer|min:1|max:127` (column is `tinyint`). The text input sends `"1"`, which the integer rule accepts. | validator with `version="1"` | PASSES | 2026-10-17 |
| MOD-10 | `ModuleRequest.php` | DECISION (a). The seven `available_perm_*` rules and their `prepareForValidation` merges removed — they forced `false` on every save. | rolled-back store | `available_perm_view = true` (DDL default) | 2026-10-17 |
| MOD-12 | `ModuleController.php` edit() | `edit(Module $module): View` — route model binding. | route `method_exists` check | 11 routes, 0 missing | 2026-10-17 |
| MOD-13 | `ModuleController.php` | `: View` on `index`, `create`, `show`, `trashedModule`, `edit`. | renders | index 195,296 B · create 473,574 B · trash 107,348 B | 2026-10-17 |
| MOD-14 | `Module.php` tenantInvoices() | `->wherePivotNull('deleted_at')` + `BelongsToMany` return type. | `grep -n wherePivotNull` | 1 hit | 2026-10-17 |
| MOD-15 | `Module.php` | Return types on `parent`, `children`, `tenantPlanModules`, `plans`. | `php -l` + `class_exists` | clean / true | 2026-10-17 |
| MOD-20 | `Module.php` menus() | `->orderByPivot('sort_order')` (the order the controller writes). | `grep -n orderByPivot` | 1 hit | 2026-10-17 |
| MOD-17 | `ModuleController.php` | `strict_types`; Syntex comments, `'other' => 'some other information'` placeholders and the `⚠` characters removed by the rewrite. | `grep -n "some other\|Syntex"` | no output | 2026-10-17 |
| MOD-18 | `Module.php` | `strict_types`; commented factory import removed. | `grep -n ModuleFactory` | no output | 2026-10-17 |
| MOD-19 | `ModuleRequest.php` | `strict_types`. | head of file | line 3 | 2026-10-17 |

Activity-log messages were cleaned of the misleading "A new module was …" wording; the event literals (`Stored`, `Updated`, `Trashed`, `Restored`, `Deleted`, `Toggled`) are unchanged.

## 3. Not applied
none — every item applied or pre-applied.

## 4. Needs Tarun's hand
- Browser check: create a module from `/prime/sales-plan-mgmt#modules` (first working create), edit one, toggle status, trash → restore → force-delete.
- Nothing to migrate, seed or sync.

## 5. Unverifiable by this workflow (D4)
- `tenantInvoices()` joins a pivot on the `mysql` connection from a `global_master_mysql` model, so the relation cannot resolve as written; it has no callers today (grep), so MOD-14 is applied but not exercisable. Worth a look when Billing is audited.
- MOD-06 moves authorization to the controller only; no role exists here that differs between the two checks, so the change is behaviour-neutral by construction.

## 6. Verification log
```
vendor/bin/pint <3 files> --format agent            → fixed Module.php (spacing only)
php -l <3 files>                                     → No syntax errors
class_exists(ModuleController|ModuleRequest|Module)  → true ×3
route:list --json (uncached) + method_exists         → routes=11 missing=0
render index / create / trashedModule                → OK 195,296 / 473,574 / 107,348 bytes
validator: valid / duplicate same version / other version → PASSES / FAILS / PASSES
rolled-back store()                                  → code=ZZ-PRO, perm_view=true, menus=1; 0 rows after rollback
```

## 7. Final state
**FIXED.** Open items: none from this report.

## 8. Follow-up 2026-10-17: the transactions did not cover the record (AFC-09)

Found while fixing AppConfigController. `Module` saves through `global_master_mysql`, but every `DB::transaction()` in this controller opened on the default `mysql` connection, where only `activityLog()` writes. These are two separate PDO handles, so the 6 transactions covered only the log. A failure after the save rolled back the audit row and left the record changed.

**Applied:** all 6 calls now use `WritesGlobalMaster::inGlobalMasterTransaction()` (new trait, `Http/Controllers/Concerns/`), which opens a `global_master_mysql` transaction around the default one. Tarun approved fixing all six FIXED controllers together.

**Verified:** `php -l` clean · class loads · every routed method exists · host page renders 200 · a simulated failure through this controller's helper rolls back both the record and the log · negative control: plain `DB::transaction` left the global_master write in place.
