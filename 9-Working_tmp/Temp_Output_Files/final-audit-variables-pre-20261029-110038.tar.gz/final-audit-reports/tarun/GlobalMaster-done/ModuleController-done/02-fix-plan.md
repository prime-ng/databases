# Fix Plan — GlobalMaster / ModuleController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php` | Shared route file for the whole GlobalMaster module; only a ticked MOD-11 decision may touch it |
| `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` | Shared estate-wide component; do not edit here (see MOD-11 decision) |
| `Modules/GlobalMaster/database/migrations/*` | No migration in this plan; altering `glb_modules` needs a new additive migration, which is Tarun's hand (MOD-07 option c only) |
| `Modules/GlobalMaster/app/Models/Plan.php`, `Modules/Prime/app/Models/Tenant.php`, `Modules/Prime/app/Models/TenantPlanModule.php` | Owned by PlanController (later batch); never audit/edit here |
| `config/permissionslist.php` | No new permission keys in this plan |

## 1. Blockers reachable today

- [x] **MOD-07** · B · DECISION · VAL-05 — create always fails because `glb_modules.code` (NOT NULL, no default) is never supplied by the form or the request.
  - **Why it is a decision:** how `code` should be populated is a product call; each option changes different files.
  - (a) ⭐ Auto-generate in `store()` — `strtoupper(substr(Str::of($request->validated()['name'])->slug()->toString(), 0, 6))` (needs `use Illuminate\Support\Str;`). Touches only `ModuleController.php`. Matches the seeder idiom (`ModuleSeeder.php:169`). If two names slug to the same code, the DB has no unique index on `code`, so no crash.
  - (b) Add a required `code` input (max 6 chars) to `create.blade.php` and a `'code' => ['required','string','max:6']` rule in `ModuleRequest.php`. Touches the blade and the request.
  - (c) Add a migration to make `code` nullable or defaulted (e.g. `''`), then leave the column empty. Migration runs only with Tarun's hand; validation stays as-is.
  - ➜ Choice: (a) auto-generate in store() — Tarun 2026-10-17

- [x] **MOD-11** · H · RTE-01 · DECISION (⚠ SHARED) — restore changes state over GET with no CSRF; every GlobalMaster sibling controller has the same shape.
  - **Why it is a decision:** it touches the shared route file and the shared trash-action component, so it is estate-wide in practice.
  - (a) ⭐ Fix this controller only: change `Routes/web.php:140` to `Route::post('/module/{id}/restore', ...)` and replace `<x-prime.table.action-trashed>` in `module/trash.blade.php` with a local CSRF form posting to `module.restore` (keep the force-delete component). Verify no other caller uses the GET restore URL.
  - (b) Fix it estate-wide in one coordinated change: POST the restore route for every GlobalMaster sibling AND update the shared `action-trashed` component to emit a form. Bigger blast radius, one component fix.
  - (c) Accept for now; record as a known estate-wide pattern.
  - ➜ Choice: dual-mode shared component + POST route — applied in commit 6d157fb2c (restore family) — Tarun 2026-10-17

## 2. Fixes that arm a latent defect (sequenced)

No items here — MOD-07 (Blocker) must land before MOD-01 removes the catch that currently hides the create failure; that sequence is preserved by the plan order (§1 before §3).

## 3. Errors & transactions (F1/F2)

- [x] **MOD-01** · H · ERR-00 · `ModuleController.php:45-319` — remove the try/catch wrappers from all six mutating methods (D1). The generic catches that hide real failures, the dead `ModelNotFoundException` rethrows, and the `Log::error(...getMessage())` lines all go away; `DB::transaction` keeps atomicity. The `use Illuminate\Database\Eloquent\ModelNotFoundException;` and `use Illuminate\Support\Facades\Log;` imports become unused and are removed here too. `destroy()` also switches to route model binding (`Module $module`) and `toggleStatus()` gains `: JsonResponse`; the other five gain `: RedirectResponse`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php`
  - **Before** (imports, `ModuleController.php:5-13`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\GlobalMaster\Http\Requests\ModuleRequest;
    use Modules\GlobalMaster\Models\Module;
    ```
  - **After:** (imports):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\GlobalMaster\Http\Requests\ModuleRequest;
    use Modules\GlobalMaster\Models\Module;
    ```
  - **After:** (store, replacing `ModuleController.php:41-76`):
    ```php
        public function store(ModuleRequest $request): RedirectResponse
        {
            Gate::authorize('prime.global-master.module.create');

            return DB::transaction(function () use ($request) {
                $module = Module::create($request->validated());

                // Set sort_order based on menu_id array order
                $menuData = [];
                foreach ($request['menu_id'] as $index => $menuId) {
                    $menuData[$menuId] = ['sort_order' => $index + 1];
                }

                $module->menus()->attach($menuData);

                activityLog($module, 'Stored', ['message' => 'Module was created.', 'other' => 'some other information']);

                return redirect()
                    ->to(route('central.prime.sales-plan-mgmt.index').'#modules')
                    ->with('success', flash('created.module'));
            });
        }
    ```
  - **After:** (update, replacing `ModuleController.php:103-170`):
    ```php
        public function update(ModuleRequest $request, Module $module): RedirectResponse
        {
            Gate::authorize('prime.global-master.module.update');

            return DB::transaction(function () use ($request, $module) {
                $original = $module->getOriginal();
                $module->update($request->validated());

                $menuData = [];
                foreach ($request['menu_id'] as $index => $menuId) {
                    $menuData[$menuId] = ['sort_order' => $index + 1];
                }

                $module->menus()->sync($menuData); // Replaces all existing menus
                $changes = $module->getChanges();
                $changedAttributes = [];

                foreach ($changes as $field => $newValue) {
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changedAttributes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                /*
                 * ONE audit row per update, with the canonical 'Updated' literal.
                 * This block used to write TWO rows; the duplicate was removed and
                 * the casing aligned. 4 legacy rows carry lower-case 'updated' and
                 * are deliberately not rewritten; query module update events
                 * case-insensitively to span both sides.
                 */
                activityLog($module, 'Updated', [
                    'message' => ! empty($changedAttributes)
                        ? 'Module was updated.'
                        : 'Module was updated. No attributes changed.',
                    'changes' => $changedAttributes,
                    'performed_by' => Auth::user()->name,
                ]);

                return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#modules')->with('success', flash('updated.module'));
            });
        }
    ```
  - **After:** (destroy, replacing `ModuleController.php:175-203`):
    ```php
        public function destroy(Module $module): RedirectResponse
        {
            Gate::authorize('prime.global-master.module.delete');

            return DB::transaction(function () use ($module) {
                $module->is_active = false;
                $module->save();
                $module->delete();

                activityLog($module, 'Trashed', ['message' => 'A new module was deactivated and deleted.', 'other' => 'some other information']);

                return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#modules')->with('success', flash('trashed.module'));
            });
        }
    ```
  - **After:** (restore, replacing `ModuleController.php:215-241`):
    ```php
        public function restore($id): RedirectResponse
        {
            Gate::authorize('prime.global-master.module.restore');

            return DB::transaction(function () use ($id) {
                $module = Module::withTrashed()->findOrFail($id);
                $module->restore();

                activityLog($module, 'Restored', ['message' => 'A new module was restored.', 'other' => 'some other information']);

                return redirect()->route('central.global-master.module.trashed')->with('success', flash('restored.module'));
            });
        }
    ```
  - **After:** (forceDelete, replacing `ModuleController.php:243-271`):
    ```php
        public function forceDelete($id): RedirectResponse
        {
            Gate::authorize('prime.global-master.module.forceDelete');

            return DB::transaction(function () use ($id) {
                $module = Module::withTrashed()->findOrFail($id);
                // Detach pivot rows to avoid FK constraint failures
                $module->menus()->detach();
                $module->forceDelete();

                activityLog($module, 'Deleted', ['message' => 'A new module was permanently deleted.', 'other' => 'some other information']);

                return redirect()->route('central.global-master.module.trashed')->with('success', flash('force_deleted.module'));
            });
        }
    ```
  - **After:** (toggleStatus, replacing `ModuleController.php:275-320`):
    ```php
        public function toggleStatus(Request $request, Module $module): JsonResponse
        {
            Gate::authorize('prime.global-master.module.update');

            return DB::transaction(function () use ($request, $module) {
                $request->validate([
                    'is_active' => 'required|boolean',
                ]);
                $newStatus = $request->input('is_active');
                $module->is_active = $newStatus;

                if ($module->save()) {
                    activityLog($module, 'Toggled', ['message' => 'Module toggle was updated.', 'other' => 'some other information']);

                    return response()->json([
                        'success' => true,
                        'is_active' => $module->is_active,
                        'message' => flash('status_updated.module'),
                    ]);
                }

                return response()->json([
                    'success' => false,
                    'is_active' => $module->is_active,
                    'message' => flash('status_switch_failed.module'),
                ]);
            });
        }
    ```
  - **Verify:** `grep -n "catch (\\\\Throwable\|catch (ModelNotFoundException\|Log::error\|getMessage" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php`
  - **Expect:** no output; plus `php -l Modules/GlobalMaster/app/Http/Controllers/ModuleController.php` → `No syntax errors detected`.
  - **Effort:** M

## 4. Authorization (F3)

- [x] **MOD-06** · L · AUTH-04 · `ModuleRequest.php:71-80` — stop double-checking the permission: keep the controller's `Gate::authorize()` as the single check and return `true` from the request's `authorize()`; drop the now-unused trait.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php`
  - **Before** (authorize, `ModuleRequest.php:71-80`):
    ```php
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        // T6b — mirrors the controller's own gate: prime.module.create on POST,
        // prime.module.update on PUT/PATCH. Same permission, checked one step
        // earlier, so this narrows nothing and widens nothing.
        return $this->authorizeByCrudPermission('prime.global-master.module');
    }
    ```
  - **After:** (authorize):
    ```php
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        // MOD-06 (AUTH-04, 2026-10-12): the controller's Gate::authorize() is the
        // single authorization point for store/update. Returning true here avoids
        // checking the same permission twice.
        return true;
    }
    ```
  - **Before** (trait use, `ModuleRequest.php:5-11`):
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;

    class ModuleRequest extends FormRequest
    {
        use AuthorizesTenantFeature;
    ```
  - **After:** (trait use):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;

    class ModuleRequest extends FormRequest
    {
    ```
  - **Verify:** `grep -n "AuthorizesTenantFeature\|authorizeByCrudPermission" Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php`
  - **Expect:** no output.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [x] **MOD-08** · M · VAL-04 · `ModuleRequest.php:25-26` — make the `name` uniqueness rule mirror `uq_module_key_live` (`COALESCE(parent_id,0) | name | version`, live rows only).
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php`
  - **Before** (`ModuleRequest.php:20-27`):
    ```php
            'name' => [
                'required',
                'string',
                'max:50',
                // Unique on the correct table, ignoring current record
                Rule::unique('glb_modules')->ignore($moduleId)->whereNull('deleted_at'),
            ],
    ```
  - **After:**
    ```php
            'name' => [
                'required',
                'string',
                'max:50',
                // Mirrors uq_module_key_live: COALESCE(parent_id,0) | name | version (MOD-08, 2026-10-12)
                Rule::unique('glb_modules')
                    ->ignore($moduleId)
                    ->where(fn ($q) => $q
                        ->whereNull('deleted_at')
                        ->where('version', (int) $this->input('version'))
                        ->whereRaw('COALESCE(parent_id, 0) = ?', [(int) $this->input('parent_id')])
                    ),
            ],
    ```
  - **Verify:** `grep -n "COALESCE(parent_id" Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php`
  - **Expect:** one hit inside `Rule::unique('glb_modules')`.
  - **Effort:** S

- [x] **MOD-09** · M · VAL-05 · `ModuleRequest.php:37-38` — validate `version` as a tinyint integer and drop the mis-typed `is_sub_module` rule.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php`
  - **Before** (`ModuleRequest.php:37-38`):
    ```php
            'is_sub_module' => ['nullable', 'string', 'max:50'],
            'version' => ['required', 'string', 'max:10'],
    ```
  - **After:**
    ```php
            // is_sub_module removed (MOD-09, 2026-10-12): no input exists and the
            // column is boolean with a DB default; validated() no longer writes it.
            'version' => ['required', 'integer', 'min:1', 'max:127'],
    ```
  - **Verify:** `grep -n "is_sub_module\|'version'" Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php`
  - **Expect:** only the new `'version'` line (no `is_sub_module` line).
  - **Effort:** S

- [x] **MOD-12** · M · CTL-03 · `ModuleController.php:92-98` — let the route bind `Module` in `edit()` (route parameter is already `{module}`); destroy's binding is carried inside MOD-01's rewrite.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php`
  - **Before** (`ModuleController.php:92-98`):
    ```php
    public function edit(string $id)
    {
        Gate::authorize('prime.global-master.module.update');
        $module = Module::findOrFail($id);

        return view('globalmaster::module.edit', compact('module'));
    }
    ```
  - **After:**
    ```php
    public function edit(Module $module): View
    {
        Gate::authorize('prime.global-master.module.update');

        return view('globalmaster::module.edit', compact('module'));
    }
    ```
  - **Note:** add `use Illuminate\Contracts\View\View;` to the imports; if MOD-13 already added it, record "already applied" and continue.
  - **Verify:** `grep -n "public function edit" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php`
  - **Expect:** `public function edit(Module $module): View`.
  - **Effort:** S

- [x] **MOD-14** · H · MDL-03 · `Module.php:71-74` — filter soft-deleted pivot rows in `tenantInvoices()`.
  - **Touches:** `Modules/GlobalMaster/app/Models/Module.php`
  - **Before** (`Module.php:71-74`):
    ```php
    public function tenantInvoices()
    {
        return $this->belongsToMany(TenantInvoice::class, 'bil_tenant_invoicing_modules_jnt', 'module_id', 'tenant_invoice_id');
    }
    ```
  - **After:**
    ```php
    public function tenantInvoices(): BelongsToMany
    {
        return $this->belongsToMany(TenantInvoice::class, 'bil_tenant_invoicing_modules_jnt', 'module_id', 'tenant_invoice_id')
            ->wherePivotNull('deleted_at');
    }
    ```
  - **Note:** add `use Illuminate\Database\Eloquent\Relations\BelongsToMany;` to the imports; if MOD-15 already added it, record "already applied" and continue.
  - **Verify:** `grep -n "wherePivotNull" Modules/GlobalMaster/app/Models/Module.php`
  - **Expect:** one hit, inside `tenantInvoices()`.
  - **Effort:** S

- [x] **MOD-15** · L · MDL-04 · `Module.php:55-96` — add Eloquent return types to `parent()`, `children()`, `tenantPlanModules()`, `plans()`. (`menus()` is covered by MOD-20; `tenantInvoices()` by MOD-14.)
  - **Touches:** `Modules/GlobalMaster/app/Models/Module.php`
  - **Before** (`Module.php:3-13` imports + class):
    ```php
    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Facades\DB;
    use Modules\Prime\Models\Menu;
    use Modules\Prime\Models\TenantInvoice;
    use Modules\Prime\Models\TenantPlanModule;
    ```
  - **After:** (imports):
    ```php
    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\BelongsToMany;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Facades\DB;
    use Modules\Prime\Models\Menu;
    use Modules\Prime\Models\TenantInvoice;
    use Modules\Prime\Models\TenantPlanModule;
    ```
  - **After:** (relations, replacing `Module.php:55-96` except `tenantInvoices()` and `menus()`):
    ```php
    public function parent(): BelongsTo
    {
        return $this->belongsTo(Module::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(Module::class, 'parent_id');
    }

    public function tenantPlanModules(): HasMany
    {
        return $this->hasMany(TenantPlanModule::class, 'module_id');
    }

    // modules <-->plans

    // DB-qualified pivot name required: this model uses global_master_mysql connection,
    // so Eloquent BelongsToMany would look for the pivot in global_master without it.
    public function plans(): BelongsToMany
    {
        $primeDb = DB::connection('mysql')->getDatabaseName();

        return $this->belongsToMany(Plan::class, "{$primeDb}.glb_module_plan_jnt", 'module_id', 'plan_id')
            ->withPivot('is_active')
            ->withTimestamps();
    }
    ```
  - **Verify:** `grep -nE "public function (parent|children|tenantPlanModules|plans)\(" Modules/GlobalMaster/app/Models/Module.php`
  - **Expect:** each line ends with a return type (`: BelongsTo`, `: HasMany`, `: HasMany`, `: BelongsToMany`).
  - **Effort:** S

- [x] **MOD-20** · M · F13/SVC-04 · `Module.php:77-83` — order `menus()` by the pivot `sort_order` the controller stores, not the menu's own `sort_order`.
  - **Touches:** `Modules/GlobalMaster/app/Models/Module.php`
  - **Before** (`Module.php:77-83`):
    ```php
    // modules <--> menus
    public function menus()
    {
        return $this->belongsToMany(Menu::class, 'glb_menu_module_jnt', 'module_id', 'menu_id')
            ->withPivot('sort_order')
            ->withTimestamps()
            ->orderBy('sort_order');
    }
    ```
  - **After:**
    ```php
    // modules <--> menus
    public function menus(): BelongsToMany
    {
        return $this->belongsToMany(Menu::class, 'glb_menu_module_jnt', 'module_id', 'menu_id')
            ->withPivot('sort_order')
            ->withTimestamps()
            ->orderByPivot('sort_order');
    }
    ```
  - **Verify:** `grep -n "orderByPivot" Modules/GlobalMaster/app/Models/Module.php`
  - **Expect:** one hit with `'sort_order'`.
  - **Effort:** S

## 6. Queries & performance (F9)

No items — family clean (see report F9).

## 7. Views (F10)

No items — family clean (see report F10).

## 8. Style (F12) — one item per file

- [x] **MOD-13** · L · CTL-04 · `ModuleController.php` — add `: View` return types to the four read methods `index`, `create`, `show`, `trashedModule` and import `Illuminate\Contracts\View\View`. (The six mutation methods receive `: RedirectResponse` / `: JsonResponse` inside MOD-01; `edit` receives `: View` inside MOD-12.)
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php`
  - **Before** (`ModuleController.php:20-26`, index — representative; apply the same `): View` change to `create` (31), `show` (81), `trashedModule` (207)):
    ```php
    public function index()
    {
        Gate::authorize('prime.global-master.module.viewAny');
        $modules = Module::with('menus')->paginate(10);

        return view('globalmaster::module.index', compact('modules'));
    }
    ```
  - **After:**
    ```php
    public function index(): View
    {
        Gate::authorize('prime.global-master.module.viewAny');
        $modules = Module::with('menus')->paginate(10);

        return view('globalmaster::module.index', compact('modules'));
    }
    ```
  - **Note:** add `use Illuminate\Contracts\View\View;` to the imports; if MOD-12 already added it, record "already applied" and continue.
  - **Verify:** `grep -nE "public function (index|create|show|trashedModule)\(" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php`
  - **Expect:** each of the four lines ends with `: View`.
  - **Effort:** S

- [x] **MOD-17** · L · STY-01/STY-04 · `ModuleController.php` — add `declare(strict_types=1);`; when MOD-01 is also ticked, its rewrite already drops the duplicated `// Syntex` docblocks, the placeholder `'other' => 'some other information'` payloads and the emoji comments. If MOD-01 is not ticked, delete those lines here (58, 187, 225, 255 for the Syntex comments; the `'other'` keys on 59, 188, 226, 256, 294; replace the two `⚠` characters on 136 and 144 with plain text).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php`
  - **Before** (`ModuleController.php:1`):
    ```php
    <?php
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);
    ```
  - **Verify:** `sed -n '1,3p' Modules/GlobalMaster/app/Http/Controllers/ModuleController.php` and `grep -n "Syntex\|some other information" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php`
  - **Expect:** `strict_types` on line 3; the grep prints no output.
  - **Effort:** S

- [x] **MOD-18** · L · STY-01/STY-04 · `Module.php` — add `declare(strict_types=1);` and delete the commented-out factory import.
  - **Touches:** `Modules/GlobalMaster/app/Models/Module.php`
  - **Before** (`Module.php:1-13`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Facades\DB;
    use Modules\Prime\Models\Menu;
    use Modules\Prime\Models\TenantInvoice;
    use Modules\Prime\Models\TenantPlanModule;
    // use Modules\GlobalMaster\Database\Factories\ModuleFactory;

    class Module extends BaseModel
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Facades\DB;
    use Modules\Prime\Models\Menu;
    use Modules\Prime\Models\TenantInvoice;
    use Modules\Prime\Models\TenantPlanModule;

    class Module extends BaseModel
    ```
  - **Verify:** `grep -n "strict_types\|ModuleFactory" Modules/GlobalMaster/app/Models/Module.php`
  - **Expect:** `declare(strict_types=1);` present, `ModuleFactory` absent.
  - **Effort:** S

- [x] **MOD-19** · L · STY-01 · `ModuleRequest.php` — add `declare(strict_types=1);`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php`
  - **Before** (`ModuleRequest.php:1`):
    ```php
    <?php
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);
    ```
  - **Verify:** `sed -n '1,3p' Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php`
  - **Expect:** `strict_types` on line 3.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **MOD-05** · M · DECISION · TXN-05 — keep or refactor the transaction closures that build the HTTP response inside `DB::transaction` (6 sites: store, update, destroy, restore, forceDelete, toggleStatus)?
  - **Why it is a decision:** a 6-site structural rewrite with no user-visible gain; the responses have no side effects, so the current shape is safe.
  - (a) ⭐ Accept as-is (Laravel-legal; the closure's return value becomes the transaction's return value). Record and close.
  - (b) Refactor: each closure returns the saved model/count; the method builds the `redirect()`/`response()` after the transaction. Touches all six methods.
  - (c) Accept and fix opportunistically when the methods are next touched.
  - ➜ Choice: (a) accept as-is — Tarun 2026-10-17

- [x] **MOD-10** · M · DECISION · F13 — `available_perm_*` are forced to `false` on every create/update and nothing reads them. What should happen?
  - **Why it is a decision:** product intent for the eight `available_perm_*` columns is unknown; the create/edit forms dropped their checkboxes while the seeder still writes `true`.
  - (a) ⭐ Remove the seven `available_perm_*` rules and their `prepareForValidation` merges from `ModuleRequest.php` so the DDL default `true` applies until a reader exists (smallest change; stops the silent overwrite).
  - (b) Add the seven checkboxes back to `create.blade.php` and `edit.blade.php` so admins control the flags (restores the legacy form behaviour).
  - (c) Leave as-is; record that the columns are write-only dead data.
  - ➜ Choice: (a) remove the rules and merges — Tarun 2026-10-17

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| MOD-02 | Resolved by MOD-01: with the try removed, the `ValidationException` from `toggleStatus` propagates to the central handler and a 422 reaches the caller instead of a redirect. |
| MOD-03 | Resolved by MOD-01: the catches (and their `Log::error(...getMessage())` lines) are removed; `bootstrap/app.php` logs the full exception. |
| MOD-04 | Resolved by MOD-01: without the catch, `toggleStatus` fails as JSON for requesters that `expectsJson()`, matching its JSON happy path. |