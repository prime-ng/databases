# Fix Plan — GlobalMaster / OrganizationController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/OrganizationController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php` | route file — no `organization` resource is registered here; adding a route is out of scope for this pass (D3, fix in place) |
| `Modules/GlobalMaster/app/Http/Controllers/GlobalMasterController.php` | the sibling scaffold — a different controller, same defect, its own report |
| `Modules/GlobalMaster/resources/views/index.blade.php` | shared placeholder view used by other GlobalMaster controllers; no item edits it |
| `config/permissionslist.php` | shared permission source; no new key is proposed here |
| `Modules/SchoolSetup/**` | the LIVE Organization CRUD (different module/controller) — the `school-setup.organization.*` routes and the `Organization` model must stay |
| `Modules/GlobalMaster/tests/Unit/ArchitectureTest.php` | test file — D4: never edit tests in this workflow |
| `Modules/GlobalMaster/tests/Unit/ControllerAuthTest.php` | test file — D4: never edit tests in this workflow |

## 1. Blockers reachable today

None — the controller is unrouted, so nothing here is reachable from the browser.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — F1 and F2 are clean.

## 4. Authorization (F3)

None — F3 is clean; no routed method and no gate to correct.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **ORG-01** · M · RTE-03 · `Modules/GlobalMaster/app/Http/Controllers/OrganizationController.php:10-55` — disable all seven unrouted methods with the D5 `abort(403)` and type them `: never`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/OrganizationController.php`
  - **Before** (`OrganizationController.php:10-55`):
    ```php
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('globalmaster::index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('globalmaster::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {}

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('globalmaster::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('globalmaster::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id) {}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {}
    ```
  - **After:**
    ```php
    public function index(): never
    {
        // NOT ROUTED 2026-10-12 — no organization route is registered in Modules/GlobalMaster/routes/web.php; no route file references this class.
        abort(403, 'This endpoint is not available.');
    }

    public function create(): never
    {
        // NOT ROUTED 2026-10-12 — no organization route is registered in Modules/GlobalMaster/routes/web.php; no route file references this class.
        abort(403, 'This endpoint is not available.');
    }

    public function store(Request $request): never
    {
        // NOT ROUTED 2026-10-12 — no organization route is registered in Modules/GlobalMaster/routes/web.php; no route file references this class.
        abort(403, 'This endpoint is not available.');
    }

    public function show($id): never
    {
        // NOT ROUTED 2026-10-12 — no organization route is registered in Modules/GlobalMaster/routes/web.php; no route file references this class.
        abort(403, 'This endpoint is not available.');
    }

    public function edit($id): never
    {
        // NOT ROUTED 2026-10-12 — no organization route is registered in Modules/GlobalMaster/routes/web.php; no route file references this class.
        abort(403, 'This endpoint is not available.');
    }

    public function update(Request $request, $id): never
    {
        // NOT ROUTED 2026-10-12 — no organization route is registered in Modules/GlobalMaster/routes/web.php; no route file references this class.
        abort(403, 'This endpoint is not available.');
    }

    public function destroy($id): never
    {
        // NOT ROUTED 2026-10-12 — no organization route is registered in Modules/GlobalMaster/routes/web.php; no route file references this class.
        abort(403, 'This endpoint is not available.');
    }
    ```
  - **Verify:** `grep -c "NOT ROUTED" Modules/GlobalMaster/app/Http/Controllers/OrganizationController.php`
  - **Expect:** `7`
  - **Effort:** S

## 6. Queries & performance (F9)

None — F9 is clean.

## 7. Views (F10)

None as a plan item. The only view defect is the three missing shared placeholder views, recorded as a cross-cutting note in `01-report.md` §7 (they are not owned by this controller).

## 8. Style (F12) — one item per file

- [ ] **ORG-03** · L · STY-01 · `Modules/GlobalMaster/app/Http/Controllers/OrganizationController.php:1-9` — add `declare(strict_types=1)`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/OrganizationController.php`
  - **Before** (`OrganizationController.php:1-9`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;

    class OrganizationController extends Controller
    {
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;

    class OrganizationController extends Controller
    {
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/GlobalMaster/app/Http/Controllers/OrganizationController.php`
  - **Expect:** one hit at line 3.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **ORG-02** · M · DECISION · CTL-10 — the whole controller is an unrouted `module:make` scaffold (identical to `GlobalMasterController`). Delete it, or keep it D5-disabled?
  - **Why it is a decision:** deleting a file is outside the D5 default (D5 disables, never deletes), and it touches the project's test suite. Only Tarun may choose deletion.
  - (a) delete `Modules/GlobalMaster/app/Http/Controllers/OrganizationController.php`. No route, menu entry, breadcrumb or view references it — but `Modules/GlobalMaster/tests/Unit/ArchitectureTest.php:27` asserts `class_exists(OrganizationController::class)`, so the test row would fail until Tarun removes that row (a test edit, which D4 forbids this workflow from making). Makes ORG-01 and ORG-03 moot.
  - (b) ⭐ keep the file but apply ORG-01 and ORG-03 only (self-documenting dead code, no deletion, no test change). This is the protocol default (D5) and leaves the architecture test green.
  - (c) leave everything as is and record it as accepted technical debt.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | None — every finding in `01-report.md` has a plan item (§5, §8, §9). |
