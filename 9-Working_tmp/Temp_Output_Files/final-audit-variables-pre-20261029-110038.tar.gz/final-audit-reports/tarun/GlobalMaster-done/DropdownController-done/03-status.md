# Status — GlobalMaster / DropdownController

**Fixed:** 2026-10-21 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| DROPDOWN-01 | `DropdownController.php` | index/create/show/edit/trashedDropdown disabled per D5. Neutralises DROPDOWN-02 (N+1) and DROPDOWN-05. | `grep -c "abort(403, 'This endpoint is not available.')"` | 11 | 2026-10-21 |
| DROPDOWN-04 | `DropdownRequest.php` | `key`/`type` rules restored; `value` unique on `(key, value)` with `->ignore()` and `whereNull('deleted_at')`. | `grep -n "whereNull('deleted_at')"` | 1 hit; no `table_name` | 2026-10-21 |
| DROPDOWN-09 | `app/Models/Dropdown.php` ⚠ SHARED | `dropdownNeeds()` adds `wherePivotNull('deleted_at')`. Checked first: `sys_dropdown_need_table_jnt` has `deleted_at` on the central connection. | `dropdownNeeds()->toSql()` | contains `` `sys_dropdown_need_table_jnt`.`deleted_at` is null `` | 2026-10-21 |
| DROPDOWN-08 | `app/Models/Dropdown.php` ⚠ SHARED | Return types on all 12 relations; commented factory import and the two commented relations removed; `strict_types`. | `grep -cE ": (BelongsToMany\|HasOne\|HasMany)$"` | 12 | 2026-10-21 |
| DROPDOWN-03 | `Modules/GlobalMaster/Models/Dropdown.php` | Dead duplicate model deleted (`git rm`); the folder is now gone. | `ReflectionClass(Dropdown::class)->getFileName()` | `…/Modules/GlobalMaster/app/Models/Dropdown.php` | 2026-10-21 |
| DROPDOWN-06 | `DropdownController.php` | `strict_types`; unused `Gate`/`Str`/`Collection` imports removed. | grep the three imports | no output | 2026-10-21 |
| DROPDOWN-07 | `DropdownRequest.php` | 24-line commented rules block deleted; `strict_types`. | `grep -n "// return \["` | no output | 2026-10-21 |
| DROPDOWN-DEC-01 | — | DECISION (a) ⭐ keep disabled. | — | — | 2026-10-21 |

## 3. Not applied
- None.

## 4. Needs Tarun's hand
- DROPDOWN-09/08 touch the shared `Dropdown` model imported by Transport, Template, SyllabusBooks and Vendor. The changes are additive, but a quick look at one dropdown-driven form in each is worth doing.

## 5. Unverifiable by this workflow (D4)
- None for the dead controller. DROPDOWN-09's soft-delete filter was proven by SQL only, not by a row trashed on the pivot.

## 6. Verification log
```
vendor/bin/pint <14 touched files> --format agent     → fixed spacing/imports in 8 files
php -l <14 touched files>                              → No syntax errors
class_exists(<14 touched classes>)                     → true ×14
APP_ROUTES_CACHE=/tmp/fa-nocache.php route:list --json → 8004 routes; 0 reach the 7 GlobalMaster
                                                         controllers fixed in this pass
method_exists over every GlobalMaster/Prime route      → all present except 9 in Prime
                                                         PrimeController / DropdownMgmtController
                                                         (pre-existing since 2026-08-24, untouched here)
```


## 7. Final state
FIXED (kept, disabled). Open: none.
