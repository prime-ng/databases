# Fix Plan — GlobalMaster / DropdownController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/DropdownController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php`, `Modules/Prime/routes/web.php` | route files — shared, never edited by this workflow |
| `config/permissionslist.php` | shared permission source |
| `Modules/GlobalMaster/app/Providers/GlobalMasterServiceProvider.php` | module glue; the wrong-class `Gate::policy` binding is cross-cutting (report §7), owned by no report |
| `Modules/GlobalMaster/tests/Unit/ArchitectureTest.php`, `ControllerAuthTest.php` | tests — D4: never write or edit tests |
| `Modules/Prime/**`, `Modules/SystemConfig/**`, `Modules/Transport/**`, `Modules/Template/**`, `Modules/SyllabusBooks/**`, `Modules/Vendor/**` | other modules (Transport/Template/SyllabusBooks/Vendor import the Dropdown model) |
| `Modules/GlobalMaster/resources/views/dropdown/*.blade.php` | orphaned views — their fate is the DECISION (plan §9), not a fix item |

## 1. Blockers reachable today

None. Every method is unrouted (route:list TOTAL 0), so no finding is reachable in the browser today.

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **DROPDOWN-01** · M · RTE-03 · `DropdownController.php:18-103` — apply D5 to the five unrouted read methods (`index`, `create`, `show`, `edit`, `trashedDropdown`): replace each live body with the NOT ROUTED comment + `abort(403)`, exactly like the six already-disabled siblings.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/DropdownController.php`
  - **Before** (`DropdownController.php:18-35` — `index()`):
    ```php
        public function index()
        {
            Gate::authorize('prime.prime.dropdown.viewAny');

            // get the distinct keys
           // $keys = Dropdown::select('key')->distinct()->get();
              $keys = Dropdown::select('key')->distinct()->orderBy('key')->paginate(10);
            // for each key get the 'values' list
            $groupedDropdowns = collect();

            foreach ($keys as $item) {
                $groupedDropdowns->put(
                    $item->key,
                    Dropdown::where('key', $item->key)->get()
                );
            }
            return view('globalmaster::dropdown.index', compact('groupedDropdowns' , 'keys'));
        }
    ```
  - **After:** (`index()` — same shape for all five methods):
    ```php
        public function index()
        {
            // NOT ROUTED — no route points at this method (verified against `php artisan route:list`, 2026-10-12).
            // Disabled pending a decision to wire it up or delete it; the original body is in git history.
            abort(403, 'This endpoint is not available.');
        }
    ```
  - **Before** (`DropdownController.php:40-45` — `create()`):
    ```php
        public function create()
        {
            Gate::authorize('prime.prime.dropdown.create');

            return view('globalmaster::dropdown.create');
        }
    ```
  - **After:** (`create()`):
    ```php
        public function create()
        {
            // NOT ROUTED — no route points at this method (verified against `php artisan route:list`, 2026-10-12).
            // Disabled pending a decision to wire it up or delete it; the original body is in git history.
            abort(403, 'This endpoint is not available.');
        }
    ```
  - **Before** (`DropdownController.php:60-65` — `show()`):
    ```php
        public function show($id)
        {
            Gate::authorize('prime.prime.dropdown.view');

            return view('globalmaster::dropdown.show');
        }
    ```
  - **After:** (`show()`):
    ```php
        public function show($id)
        {
            // NOT ROUTED — no route points at this method (verified against `php artisan route:list`, 2026-10-12).
            // Disabled pending a decision to wire it up or delete it; the original body is in git history.
            abort(403, 'This endpoint is not available.');
        }
    ```
  - **Before** (`DropdownController.php:70-76` — `edit()`):
    ```php
        public function edit($id)
        {
            Gate::authorize('prime.prime.dropdown.update');

            $dropdown = Dropdown::findOrFail($id);
            return view('globalmaster::dropdown.edit', compact('dropdown'));
        }
    ```
  - **After:** (`edit()`):
    ```php
        public function edit($id)
        {
            // NOT ROUTED — no route points at this method (verified against `php artisan route:list`, 2026-10-12).
            // Disabled pending a decision to wire it up or delete it; the original body is in git history.
            abort(403, 'This endpoint is not available.');
        }
    ```
  - **Before** (`DropdownController.php:97-103` — `trashedDropdown()`):
    ```php
        public function trashedDropdown()
        {
            Gate::authorize('prime.prime.dropdown.restore');

            $dropdowns = Dropdown::onlyTrashed()->paginate(10);
            return view('globalmaster::dropdown.trash', compact('dropdowns'));
        }
    ```
  - **After:** (`trashedDropdown()`):
    ```php
        public function trashedDropdown()
        {
            // NOT ROUTED — no route points at this method (verified against `php artisan route:list`, 2026-10-12).
            // Disabled pending a decision to wire it up or delete it; the original body is in git history.
            abort(403, 'This endpoint is not available.');
        }
    ```
  - **Verify:** `grep -n "abort(403, 'This endpoint is not available.')" Modules/GlobalMaster/app/Http/Controllers/DropdownController.php | wc -l`
  - **Expect:** `11` (six already-disabled methods + these five).
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

None — there are no live writes, so there is nothing to wrap or catch (D1/D2).

## 4. Authorization (F3)

None — the gates are correct and the permission keys are declared; see report §6 F3.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **DROPDOWN-04** · M · VAL-04 · `DropdownRequest.php:44-58` — restore the `key`/`type` rules and make the `value` unique rule mirror the real index `(key, value)` with soft-delete semantics and `->ignore()`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/DropdownRequest.php`
  - **Before** (`DropdownRequest.php:44-58`):
    ```php
            return [
                // 'db_type'     => ['required', 'string'],
                // 'table_name'  => ['required', 'string'],
                // 'column_name' => ['required', 'string'],

                'value' => [
                    'required',
                    'string',
                    'max:255',
                    Rule::unique('sys_dropdown_table')
                        ->where(fn($q) => $q->where('key', $this->input('table_name') . '.' . $this->input('column_name')))
                ],

                'is_active' => ['required', 'boolean'],
            ];
    ```
  - **After:**
    ```php
            return [
                'key' => [
                    'required',
                    'string',
                    'max:50',
                ],
                'type' => [
                    'required',
                    'string',
                    Rule::in(['String', 'Integer', 'Decimal', 'Date', 'Datetime', 'Time', 'Boolean']),
                ],
                'value' => [
                    'required',
                    'string',
                    'max:255',
                    Rule::unique('sys_dropdown_table')
                        ->ignore($this->route('dropdown') ?? null)
                        ->where(fn ($q) => $q->where('key', $this->input('key'))->whereNull('deleted_at')),
                ],

                'is_active' => ['required', 'boolean'],
            ];
    ```
  - **Verify:** `grep -n "table_name\|whereNull('deleted_at')" Modules/GlobalMaster/app/Http/Requests/DropdownRequest.php`
  - **Expect:** one hit for `whereNull('deleted_at')`; no hit for `table_name`/`column_name` inside `Rule::unique`.
  - **Effort:** S

- [ ] **DROPDOWN-09** · M · MDL-03 · ⚠ SHARED · `app/Models/Dropdown.php:51-60` — add `wherePivotNull('deleted_at')` to the `dropdownNeeds()` pivot join (the pivot `sys_dropdown_need_table_jnt` is soft-deleted).
  - **Touches:** `Modules/GlobalMaster/app/Models/Dropdown.php` (shared — Transport/Template/SyllabusBooks/Vendor import this model; needs its own explicit tick)
  - **Before** (`Dropdown.php:51-60`):
    ```php
        public function dropdownNeeds()
        {
            return $this->belongsToMany(
                DropdownNeed::class,
                'sys_dropdown_need_table_jnt',
                'dropdown_table_id',
                'dropdown_needs_id'
            )->withPivot('is_active')
                ->withTimestamps();
        }
    ```
  - **After:**
    ```php
        public function dropdownNeeds()
        {
            return $this->belongsToMany(
                DropdownNeed::class,
                'sys_dropdown_need_table_jnt',
                'dropdown_table_id',
                'dropdown_needs_id'
            )->withPivot('is_active')
                ->withTimestamps()
                ->wherePivotNull('deleted_at');
        }
    ```
  - **Verify:** `php artisan tinker --execute 'echo (new \Modules\GlobalMaster\Models\Dropdown())->dropdownNeeds()->getQuery()->toSql() . PHP_EOL;'`
  - **Expect:** the SQL contains `` `sys_dropdown_need_table_jnt`.`deleted_at` is null ``.
  - **Effort:** S

- [ ] **DROPDOWN-08** · L · MDL-04 · ⚠ SHARED · `app/Models/Dropdown.php` — add return types to the twelve relation methods and delete the commented-out blocks.
  - **Touches:** `Modules/GlobalMaster/app/Models/Dropdown.php` (shared — needs its own explicit tick)
  - **Before** (imports, `Dropdown.php:5-14`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\Complaint\Models\AiInsight;
    use Modules\Complaint\Models\Complaint;
    use Modules\Complaint\Models\ComplaintAction;
    use Modules\Complaint\Models\ComplaintCategory;
    use Modules\Complaint\Models\DepartmentSla;
    use Modules\Complaint\Models\MedicalCheck;
    use Modules\Prime\Models\DropdownNeedTableJnt;
    ```
  - **After:** (imports — insert the three `Relations` imports after `SoftDeletes`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\Relations\BelongsToMany;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\Relations\HasOne;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\Complaint\Models\AiInsight;
    use Modules\Complaint\Models\Complaint;
    use Modules\Complaint\Models\ComplaintAction;
    use Modules\Complaint\Models\ComplaintCategory;
    use Modules\Complaint\Models\DepartmentSla;
    use Modules\Complaint\Models\MedicalCheck;
    use Modules\Prime\Models\DropdownNeedTableJnt;
    ```
  - **Before/After pairs** (only the signature line changes; the body of each method stays identical):
    ```php
    // line 51 — BEFORE
        public function dropdownNeeds()
    // line 51 — AFTER
        public function dropdownNeeds(): BelongsToMany
    // line 65 — BEFORE
        public function junction()
    // line 65 — AFTER
        public function junction(): HasOne
    // line 74 — BEFORE
        public function complaintCategoriesBySeverity()
    // line 74 — AFTER
        public function complaintCategoriesBySeverity(): HasMany
    // line 96 — BEFORE
        public function complaintCategoriesByPriority()
    // line 96 — AFTER
        public function complaintCategoriesByPriority(): HasMany
    // line 104 — BEFORE
        public function complaintSlasByTargetType()
    // line 104 — AFTER
        public function complaintSlasByTargetType(): HasMany
    // line 109 — BEFORE
        public function complaintsByStatus()
    // line 109 — AFTER
        public function complaintsByStatus(): HasMany
    // line 114 — BEFORE
        public function complaintsBySeverity()
    // line 114 — AFTER
        public function complaintsBySeverity(): HasMany
    // line 119 — BEFORE
        public function complaintsByPriority()
    // line 119 — AFTER
        public function complaintsByPriority(): HasMany
    // line 123 — BEFORE
        public function complaintActions()
    // line 123 — AFTER
        public function complaintActions(): HasMany
    // line 127 — BEFORE
        public function medicalChecksByType()
    // line 127 — AFTER
        public function medicalChecksByType(): HasMany
    // line 132 — BEFORE
        public function medicalChecksByResult()
    // line 132 — AFTER
        public function medicalChecksByResult(): HasMany
    // line 137 — BEFORE
        public function aiInsightsBySentiment()
    // line 137 — AFTER
        public function aiInsightsBySentiment(): HasMany
    ```
  - **Before** (commented-out blocks, `Dropdown.php:16` and `Dropdown.php:83-92`):
    ```php
    // use Modules\GlobalMaster\Database\Factories\DropdownFactory;
    ```
    and
    ```php
        // public function dropdownNeed()
        // {
        //     return $this->belongsTo(DropdownNeed::class, 'dropdown_needs_id');
        // }


        // public function need()
        // {
        //     return $this->belongsTo(DropdownNeed::class, 'dropdown_needs_id');
        // }
    ```
  - **After:** both blocks deleted (empty replacement).
  - **Verify:** `grep -n ": BelongsToMany\|: HasOne\|: HasMany\|dropdownFactory\|public function dropdownNeed" Modules/GlobalMaster/app/Models/Dropdown.php`
  - **Expect:** 12 return-type hits; no output for `dropdownFactory`/`dropdownNeed`.
  - **Effort:** M

- [ ] **DROPDOWN-03** · M · CTL-10 · `Modules/GlobalMaster/Models/Dropdown.php` — delete the dead duplicate `Dropdown` model (same FQCN as the autoloaded `app/Models/Dropdown.php`; outside every PSR-4 mapping, never autoloaded, referenced by nothing).
  - **Touches:** `Modules/GlobalMaster/Models/Dropdown.php` (delete the file)
  - **Before** (`Modules/GlobalMaster/Models/Dropdown.php:1-29`, the whole file):
    ```php
    <?php

    namespace Modules\GlobalMaster\Models;

    use Illuminate\Database\Eloquent\Model;
    use Modules\Prime\Models\DropdownNeed;

    class Dropdown extends Model
    {
        /**
         * The attributes that are mass assignable.
         *
         * @var array
         */
        protected $fillable = [
            'org_id',
            'ordinal',
            'key',
            'value',
            'type',
            'is_active',
            'dropdown_needs_id'
        ];

        public function needs()
        {
            return $this->belongsTo(DropdownNeed::class, 'dropdown_needs_id');
        }
    }
    ```
  - **After:** file removed (`git rm Modules/GlobalMaster/Models/Dropdown.php`). Do NOT touch `Modules/GlobalMaster/app/Models/Dropdown.php`.
    ```php
    // Modules/GlobalMaster/Models/Dropdown.php — DELETED. Nothing replaces it.
    // The only remaining Modules\GlobalMaster\Models\Dropdown is
    // Modules/GlobalMaster/app/Models/Dropdown.php (PSR-4: Modules\GlobalMaster\ -> app/).
    ```
  - **Verify:** `php artisan tinker --execute '$r = new ReflectionClass(\Modules\GlobalMaster\Models\Dropdown::class); echo $r->getFileName() . PHP_EOL;'`
  - **Expect:** `/Users/bkwork/Herd/prime_ai_dev/Modules/GlobalMaster/app/Models/Dropdown.php` (unchanged; class still resolves) and `ls Modules/GlobalMaster/Models/` → empty.
  - **Effort:** S

## 6. Queries & performance (F9)

No item — DROPDOWN-02 (QRY-01 N+1) is neutralised by DROPDOWN-01 (disables `index()`); see plan §10.

## 7. Views (F10)

No item — the four orphaned views and the missing `show.blade.php` are governed by the DECISION (plan §9).

## 8. Style (F12) — one item per file

- [ ] **DROPDOWN-06** · L · F12/CTL-04 · `DropdownController.php:1-13` — add `declare(strict_types=1);` and remove the three unused imports (`Gate`, `Str`, `Collection`) that remain after DROPDOWN-01.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/DropdownController.php`
  - **Before** (`DropdownController.php:1-13`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Str;
    use Illuminate\Support\Facades\Gate;
    use Modules\GlobalMaster\Http\Requests\DropdownRequest;
    use Modules\GlobalMaster\Models\Dropdown;
    use Illuminate\Support\Collection;

    class DropdownController extends Controller
    {
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Modules\GlobalMaster\Http\Requests\DropdownRequest;
    use Modules\GlobalMaster\Models\Dropdown;

    class DropdownController extends Controller
    {
    ```
  - **Verify:** `grep -n "use Illuminate\\\\Support\\\\Str;\|use Illuminate\\\\Support\\\\Collection;\|use Illuminate\\\\Support\\\\Facades\\\\Gate;" Modules/GlobalMaster/app/Http/Controllers/DropdownController.php`
  - **Expect:** no output.
  - **Effort:** S
  - Note: return types on the disabled methods are deliberately not added — the D5 siblings carry none, and the file's fate is the DECISION.

- [ ] **DROPDOWN-07** · L · STY-04 · `DropdownRequest.php:18-41` — delete the 24-line commented-out validation block (its content is superseded by DROPDOWN-04).
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/DropdownRequest.php`
  - **Before** (`DropdownRequest.php:18-41`):
    ```php
            // return [
            //     'key' => [
            //         'required',
            //         'string',
            //         'max:50'
            //     ],
            //     'type' => [
            //         'required',
            //         Rule::in(['String', 'Integer', 'Decimal', 'Date', 'Datetime', 'Time', 'Boolean'])
            //     ],
            //     'value' => [
            //         'required',
            //         'string',
            //         'max:255',
            //         Rule::unique('sys_dropdown_table')
            //             ->ignore($this->route('dropdown'))
            //             ->where(function ($query) {
            //                 return $query->where('key', $this->input('key'));
            //             })
            //     ],
            //     'is_active' => [
            //         'boolean'   
            //     ],
            // ];
    ```
  - **After:** the block deleted (empty replacement); `rules()` starts at the `return [` of DROPDOWN-04's After.
    ```php
    // DropdownRequest.php:18-41 — DELETED. Nothing replaces this block.
    // The live rules now start at the `return [` written by DROPDOWN-04.
    ```
  - **Verify:** `grep -n "Rule::in\|// return \[" Modules/GlobalMaster/app/Http/Requests/DropdownRequest.php`
  - **Expect:** one hit for `Rule::in(` (the live `type` rule); no hit for `// return [`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **DROPDOWN-DEC-01** · M · DECISION · CTL-10/RTE-03 — what is the end state of the dead `DropdownController`, its four orphaned views and `DropdownRequest`?
  - **Why it is a decision:** deleting the controller would break `Modules/GlobalMaster/tests/Unit/ArchitectureTest.php` (asserts `class_exists`) and `ControllerAuthTest.php` (gate coverage) — tests are off-limits to this workflow, so that needs Tarun's hand. Re-wiring the routes would contradict the 2026-08-24 decision that moved the dropdown feature to `Modules\Prime`.
  - (a) ⭐ **Keep disabled** — apply DROPDOWN-01, DROPDOWN-04, DROPDOWN-06, DROPDOWN-07. Zero blast radius; tests keep passing; the dead screen is parked for a later cleanup pass.
  - (b) **Delete the dead code** — remove the controller, `DropdownRequest.php` and the four views, and update the two test files by hand (Tarun's hand; D4 forbids the fixer touching tests).
  - (c) **Re-wire to a live screen** — re-create `global-master.dropdown*` routes against this controller; not recommended, the live screens are at `/system-config/dropdown*` (Prime).
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| DROPDOWN-02 (QRY-01, H) | The N+1 loop lives in `index()`, which DROPDOWN-01 disables. Fixing the loop on a dead method would be wasted churn; if the screen is ever resurrected, a single grouped query must replace the loop. |
| DROPDOWN-05 (CTL-03, L) | `edit($id)` + `findOrFail` is disabled by DROPDOWN-01. If re-wired later, the signature should become `edit(Dropdown $dropdown)` with implicit binding. |