# Fix Plan — GlobalMaster / GlobalMasterController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/GlobalMasterController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php` | route file — no route may be added, removed or re-scoped by this plan (D3/§9.3) |
| `Modules/GlobalMaster/routes/api.php` | route file — same |
| `Modules/GlobalMaster/resources/views/index.blade.php` | not edited: after GM-01 it is reached by nobody; deleting a view is out of scope |
| `Modules/GlobalMaster/resources/views/components/layouts/master.blade.php` | shared module layout, also used by sibling controllers' views |
| `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php` | owned by its own audit report |
| `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php` | owned by its own audit report |
| `Modules/GlobalMaster/app/Http/Controllers/OrganizationController.php` | owned by its own audit report |
| any file under `database/migrations/` | migrations are never edited (standing rule) |

## 1. Blockers reachable today

None — nothing is reachable (0 routes).

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None.

## 4. Authorization (F3)

None.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **GM-01** · M · RTE-03 · `Modules/GlobalMaster/app/Http/Controllers/GlobalMasterController.php:1-56` — disable the seven unrouted scaffold methods per D5 and add `strict_types`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/GlobalMasterController.php`
  - **Before** (`GlobalMasterController.php:1-56`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;

    class GlobalMasterController extends Controller
    {
        /**
         * Display a listing of the resource.
         */
        public function index()
        {
            return view('globalmaster::index');
        }

        /**
         * Show the form for creating a new resource.
         */
        public function create()
        {
            return view('globalmaster::create');
        }

        /**
         * Store a newly created resource in storage.
         */
        public function store(Request $request) {}

        /**
         * Show the specified resource.
         */
        public function show($id)
        {
            return view('globalmaster::show');
        }

        /**
         * Show the form for editing the specified resource.
         */
        public function edit($id)
        {
            return view('globalmaster::edit');
        }

        /**
         * Update the specified resource in storage.
         */
        public function update(Request $request, $id) {}

        /**
         * Remove the specified resource from storage.
         */
        public function destroy($id) {}
    }
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;

    class GlobalMasterController extends Controller
    {
        /**
         * NOT ROUTED (D5, 2026-10-12). The `module:make` scaffold was retired on 2026-09-30
         * and no route reaches this controller — see Modules/GlobalMaster/routes/web.php:35
         * and :145. The method is kept, not deleted, and disabled with abort(403).
         */
        public function index(): never
        {
            abort(403, 'This action is not available.');
        }

        // NOT ROUTED (D5, 2026-10-12) — scaffold create(); no route reaches it.
        public function create(): never
        {
            abort(403, 'This action is not available.');
        }

        // NOT ROUTED (D5, 2026-10-12) — scaffold store(); no route reaches it.
        public function store(Request $request): never
        {
            abort(403, 'This action is not available.');
        }

        // NOT ROUTED (D5, 2026-10-12) — scaffold show(); no route reaches it.
        public function show($id): never
        {
            abort(403, 'This action is not available.');
        }

        // NOT ROUTED (D5, 2026-10-12) — scaffold edit(); no route reaches it.
        public function edit($id): never
        {
            abort(403, 'This action is not available.');
        }

        // NOT ROUTED (D5, 2026-10-12) — scaffold update(); no route reaches it.
        public function update(Request $request, $id): never
        {
            abort(403, 'This action is not available.');
        }

        // NOT ROUTED (D5, 2026-10-12) — scaffold destroy(); no route reaches it.
        public function destroy($id): never
        {
            abort(403, 'This action is not available.');
        }
    }
    ```
  - **Verify:** `grep -c "NOT ROUTED" Modules/GlobalMaster/app/Http/Controllers/GlobalMasterController.php`
  - **Expect:** `7`
  - **Effort:** S

## 6. Queries & performance (F9)

None.

## 7. Views (F10)

None — GM-05 is subsumed by GM-01 (see §10).

## 8. Style (F12) — one item per file

None as separate items — GM-03 (`strict_types`) and GM-04 (scaffold docblocks) are applied by the GM-01 rewrite. See §10.

## 9. Deferred / decisions

None.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| GM-02 | CTL-04 return types — fixed inside the GM-01 full-file rewrite; every D5-stub method is declared `: never`. No separate edit needed. |
| GM-03 | STY-01 `strict_types` — the file is touched by GM-01, so the declaration is added there. |
| GM-04 | STY-04 scaffold docblocks — dropped by the GM-01 rewrite (replaced with one meaningful `NOT ROUTED` comment per method). |
| GM-05 | CTL-10 missing `create`/`show`/`edit` blades — subsumed by GM-01: once the method bodies are `abort(403)`, the `view(...)` calls (and the missing-blade risk) no longer exist. |
