# Final Audit — GlobalMaster / AppModuleController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php` (184 lines, 4 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://localhost:8000/system-config/setting?tab=app-modules` (central host only) — the mutations are `POST /system-config/app-module`, `PUT /system-config/app-module/{appModule}`, `POST /system-config/app-module/{appModule}/toggle-status` |
| Menu path | System Config → Settings → **App Modules** tab (a pane on the Settings page, no page of its own) |
| Who uses it | Roles holding `prime.global-master.app-module.*` (measured in `sys_role_has_permissions_jnt`): **Super Admin, Dev Team, App Maintenance, Support Team**. Super Admin only by DDL intent; tenants never see it. |
| What a user does here | The engineering catalogue of the platform's own modules (`glb_app_modules`, one row per `Modules/` directory with its table prefix). A user adds a module in a modal, edits its code/name/prefix/order/active flag in a per-row modal, and flips its Active switch. There is deliberately **no delete and no list URL** — the list is a pane rendered by `\Modules\Prime\Http\Controllers\SettingController`; every action redirects back to that tab. |
| Tables written | `glb_app_modules` (on `global_master_mysql`), `sys_central_activity_logs` (via the `activityLog()` helper; central context) |
| Tables read | `glb_app_modules`, `sys_permissions` + `sys_role_has_permissions_jnt` (the Gate check), `sys_roles` |
| Live data | `glb_app_modules` 49 live, 0 trashed, 9 system, 48 active; `glb_app_config` 4 rows; `sys_central_activity_logs` 1 row |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready as-is, but close: one High and five Medium findings, no Blocker. The controller is small, thin, well-commented and its authorization, routing and validation shape are correct — the permission name `prime.global-master.app-module.update` matches `config/permissionslist.php` and is seeded exactly. The single worst finding is **AMC-03**: `toggleStatus()` updates `glb_app_modules` and writes the activity-log row as two separate, un-transacted writes, so a failed audit insert leaves a silent, unlogged status change. The second theme is stylistic-architectural: two methods carry `try/catch` that D1 forbids and an `is_system` flag a crafted request can flip. Fix effort: small (S) — the whole plan is mechanical edits to three files.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 5 | 4 | 0 | 10 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | AMC-01, AMC-02 | F8 Services/Jobs | none |
| F2 Transactions/Audit | AMC-03, AMC-04 | F9 Queries/Perf | clean |
| F3 Authorization | clean | F10 Views | none (controller renders none) |
| F4 Validation | AMC-05 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | AMC-07, AMC-08, AMC-09 |
| F6 Controller shape | AMC-06 | F13 Deep read | AMC-10 |
| F7 Models | AMC-10 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php` | controller | 184 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Models/AppModule.php` | model | 82 | this report (claimed in `00-CLASS-OWNERS.md`) | ✅ |
| 3 | `Modules/GlobalMaster/app/Http/Requests/AppModuleRequest.php` | FormRequest | 80 | this report (claimed in `00-CLASS-OWNERS.md`) | ✅ |
| 4 | `Modules/GlobalMaster/routes/web.php` | route file (shared) | 198 | this report — lines 88-124 only | ✅ |
| 5 | `Modules/GlobalMaster/app/Models/AppConfig.php` | model | — | not exercised by this controller (relation target only) | ❌ see §8 |
| 6 | `Modules/GlobalMaster/resources/views/app-module/_pane.blade.php` | blade (not rendered by this controller) | 331 | `SettingController` owns the render | ❌ see §8 |

No pre-applied files (`PRE-APPLIED-2026-10-10.md` does not list any file in this scope).

## 4. Routes

```
POST    system-config/app-module                                     central.system-config.app-module.store        Modules\GlobalMaster\Http\Controllers\AppModuleController@store
PUT     system-config/app-module/{appModule}                         central.system-config.app-module.update       Modules\GlobalMaster\Http\Controllers\AppModuleController@update
POST    system-config/app-module/{appModule}/toggle-status           central.system-config.app-module.toggleStatus Modules\GlobalMaster\Http\Controllers\AppModuleController@toggleStatus
```

Unrouted public methods: `destroy()` at `AppModuleController.php:113` — deliberately unrouted and already `abort(403)` per D5; its body is compliant, so it is **not** a finding (RTE-03 is satisfied). `AppConfig.php:configs()` relation is the only outbound edge from the model, and it is unused by this controller.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `store` | 45 | POST /system-config/app-module | `prime.global-master.app-module.create` | controller, closure | `Stored` | glb_app_modules, sys_central_activity_logs | AMC-01, AMC-02, AMC-04 |
| `update` | 70 | PUT /system-config/app-module/{appModule} | `prime.global-master.app-module.update` | controller, closure | `Edited` | glb_app_modules, sys_central_activity_logs | AMC-01, AMC-02, AMC-04, AMC-10 |
| `destroy` | 113 | nowhere (by decision) | none (aborts 403) | none | none | none | AMC-06 |
| `toggleStatus` | 125 | POST /system-config/app-module/{appModule}/toggle-status | `prime.global-master.app-module.update` | **none** | `Toggled` | glb_app_modules, sys_central_activity_logs | AMC-02, AMC-03, AMC-06 |
| `toggleResponse` (private) | 170 | n/a | n/a | n/a | n/a | none | — |
| `backToTab` (private) | 40 | n/a | n/a | n/a | n/a | none | — |

## 6. Findings

### F1 — Errors

#### AMC-01 · M · ERR-00 — `store()` and `update()` carry a controller `try/catch` (D1 forbids it)

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M, lowered from the D1 architecture rule) — *D1: no `try/catch` in a controller; `DB::transaction` rolls back and the central handler in `bootstrap/app.php` renders* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php:49-67` (store) and `:83-97` (update) |
| **Root cause** | Both methods wrap the transaction in `try { ... } catch (\Throwable $e) { Log::error(...); return back()->with('error', ...); }`. D2 lists the only catches a controller may keep (`\DomainException`, one truncate-rebuild catch, `SnapshotProtectionException`); a generic `\Throwable` catch is none of them. |
| **Consequence** | Any real failure during the write is converted into the generic red flash "The operation could not be completed." instead of being rendered and logged with its trace by the central handler, so an operator cannot diagnose it. |
| **Reproduce** | static only — the catch only fires when a DB write fails, which cannot be triggered from the seeded UI. |
| **Fix approach** | Delete both `try/catch` blocks, keep the `DB::transaction`, and move the `redirect()` after the closure (see AMC-04). The sibling `toggleStatus()` catch is removed by AMC-03. |
| **Plan item** | AMC-01 in `02-fix-plan.md` §3 |

```php
// AppModuleController.php:49-67 — CURRENT (store)
        try {
            return DB::transaction(function () use ($request) {
                // `key` is mass-assignment-guarded on the model precisely so it can only
                // be set here, at creation, and never silently rewritten by an update.
                $appModule = new AppModule($request->validated());
                $appModule->key = $request->validated()['key'];
                $appModule->save();

                activityLog($appModule, 'Stored', ['message' => 'A new application module was created.']);

                return redirect()->to($this->backToTab())->with('success', flash('created.app_module'));
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('AppModuleController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "catch (" Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php
61:        } catch (ModelNotFoundException $e) {
63:        } catch (\Throwable $e) {
91:        } catch (ModelNotFoundException $e) {
93:        } catch (\Throwable $e) {
157:        } catch (ValidationException $e) {
159:        } catch (\Throwable $e) {
```

#### AMC-02 · M · ERR-05 — Failures are logged as a message string, losing the trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php:64`, `:94`, `:160` |
| **Root cause** | Each catch calls `Log::error('…', ['error' => $e->getMessage()])`, storing only the message text. The exception class, file and stack trace are discarded. |
| **Consequence** | When a store/update/toggle write fails in production, the log entry names no file and no line, so the failure cannot be traced back to its cause. |
| **Reproduce** | static only — requires a failing write. |
| **Fix approach** | Removing the catches (AMC-01 and AMC-03) lets the central handler log the exception object with its trace. |
| **Plan item** | none — see plan §10 (removed by AMC-01 and AMC-03) |

```php
// AppModuleController.php:64 — CURRENT (the same shape is repeated at :94 and :160)
            Log::error('AppModuleController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "Log::error" Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php
64:            Log::error('AppModuleController::store failed', ['error' => $e->getMessage()]);
94:            Log::error('AppModuleController::update failed', ['error' => $e->getMessage()]);
160:            Log::error('AppModuleController::toggleStatus failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### AMC-03 · H · TXN-01 — `toggleStatus()` writes two rows with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (a model + its audit row) runs inside one `DB::transaction`* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php:149-154`, method `toggleStatus()` |
| **Root cause** | `$model->update(['is_active' => ...])` and `activityLog($model, 'Toggled', ...)` are two writes (one to `glb_app_modules`, one to `sys_central_activity_logs`) executed without a `DB::transaction`, unlike `store()`/`update()`, which wrap theirs. |
| **Consequence** | If the activity-log insert fails (its `user_id` has an FK to `sys_users`, or a transient DB error), the new `is_active` value stays committed with no audit entry, so the status change is silently unaccountable. |
| **Reproduce** | static only — needs a failing activity-log insert, which cannot be forced from the seeded UI. |
| **Fix approach** | Wrap both writes in one `DB::transaction`; remove the surrounding `try/catch` at the same time (D1). |
| **Plan item** | AMC-03 in `02-fix-plan.md` §3 |

```php
// AppModuleController.php:149-154 — CURRENT
            $model->update(['is_active' => (bool) $validated['is_active']]);

            activityLog($model, 'Toggled', [
                'message' => 'Application module status was toggled.',
                'is_active' => $model->is_active,
            ]);
```

**Evidence**
```
$ sed -n '143,164p' Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php
        try {
            // Take the value the switch actually sent rather than negating what is in the
            // database: two quick clicks would otherwise resolve against a stale read and
            // leave the row in the opposite state to the control.
            $validated = $request->validate(['is_active' => 'required|boolean']);

            $model->update(['is_active' => (bool) $validated['is_active']]);

            activityLog($model, 'Toggled', [
                'message' => 'Application module status was toggled.',
                'is_active' => $model->is_active,
            ]);

            return $this->toggleResponse($request, true, $model->is_active, flash('status_updated.app_module'));
        } catch (ValidationException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('AppModuleController::toggleStatus failed', ['error' => $e->getMessage()]);

            return $this->toggleResponse($request, false, $model->is_active, flash('status_switch_failed.app_module'));
        }
    }
```

#### AMC-04 · M · TXN-05 — The HTTP response is built inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build `redirect()` / `response()` after it* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php:59` and `:89` |
| **Root cause** | `store()` and `update()` `return redirect()->to(...)` from **inside** the `DB::transaction` closure, so the response object is constructed while the transaction is still open. |
| **Consequence** | On a deadlock-retry (Laravel re-runs the closure), the response construction runs a second time and it obscures that the transaction's only job is the write; the correct shape returns the fact, not the response. |
| **Reproduce** | static only — a deadlock retry is required to observe it. |
| **Fix approach** | Build the redirect after the closure returns (applied together with AMC-01). |
| **Plan item** | none — see plan §10 (fixed by AMC-01) |

```php
// AppModuleController.php:55-59 — CURRENT
                $appModule->save();

                activityLog($appModule, 'Stored', ['message' => 'A new application module was created.']);

                return redirect()->to($this->backToTab())->with('success', flash('created.app_module'));
```

**Evidence**
```
$ grep -n "return redirect()->to" Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php
59:                return redirect()->to($this->backToTab())->with('success', flash('created.app_module'));
89:                return redirect()->to($this->backToTab())->with('success', flash('updated.app_module'));
```

### F3 — Authorization

clean — every routed method calls `Gate::authorize` before loading any record (`store:47`, `update:72`, `toggleStatus:127`), the FormRequest `authorize()` returns `true` and adds no duplicate check, and the permission names exist exactly in the config and are seeded. Evidence:

```
$ grep -n "Gate::authorize" Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php
47:        Gate::authorize('prime.global-master.app-module.create');
72:        Gate::authorize('prime.global-master.app-module.update');
127:        Gate::authorize('prime.global-master.app-module.update');

$ grep -n "global-master.app-module" config/permissionslist.php
225:        'global-master.app-module' => $crud,

# exact-name seed check (SELECT only)
PERMS: {"99":"prime.global-master.app-module.create","103":"prime.global-master.app-module.delete","102":"prime.global-master.app-module.update","100":"prime.global-master.app-module.view","101":"prime.global-master.app-module.viewAny"}
ROLES: ["Super Admin","Dev Team","App Maintenance","Support Team"]
```

### F4 — Validation and input

#### AMC-05 · M · VAL-04 — The unique-`code` rule ignores soft-deleted rows that the DB index still counts

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H default, lowered to M) — *uniqueness rules mirror the DB unique index, including soft-delete semantics*; lowered because no delete path exists today (destroy() is unrouted and no code deletes an `AppModule`), so the mismatch is latent. |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/AppModuleRequest.php:34-36` |
| **Root cause** | The migration declares a plain unique index `uq_sys_module_code` on `code`, which keeps counting soft-deleted rows, while the rule adds `->whereNull('deleted_at')`, telling Laravel to check only live rows. The two definitions disagree. |
| **Consequence** | If a module with code `ACCOUNTING` is ever soft-deleted and re-created, validation passes and the INSERT fails with MySQL error 1062 "Duplicate entry", which the surrounding catch turns into the generic red flash. |
| **Reproduce** | static only — a trashed `glb_app_modules` row is required, and none can be created from the UI (0 trashed rows live). |
| **Fix approach** | Drop `->whereNull('deleted_at')` so the rule matches the DB index exactly. |
| **Plan item** | AMC-05 in `02-fix-plan.md` §5 |

```php
// AppModuleRequest.php:34-36 — CURRENT
                Rule::unique('global_master_mysql.glb_app_modules', 'code')
                    ->ignore($currentKey, 'key')
                    ->whereNull('deleted_at'),
```

**Evidence**
```
$ grep -n "whereNull('deleted_at')" Modules/GlobalMaster/app/Http/Requests/AppModuleRequest.php
36:                    ->whereNull('deleted_at'),
$ grep -n "unique('code'" Modules/GlobalMaster/database/migrations/2026_08_31_120000_create_glb_app_modules_table.php
85:            $table->unique('code', 'uq_sys_module_code');
```

### F5 — Routes

clean — no state changes over GET (the three routes are POST, PUT, POST); every route points to an existing method; `destroy()` is unrouted and already `abort(403)` (D5); the `{appModule}` parameter name matches the `string $appModule` argument; the group is behind `auth` + `verified` on the central domain. Evidence:

```
$ grep -n "app-module" Modules/GlobalMaster/routes/web.php
107:        Route::post('app-module', [AppModuleController::class, 'store'])->name('app-module.store');
108:        Route::put('app-module/{appModule}', [AppModuleController::class, 'update'])->name('app-module.update');
114:        Route::post('app-module/{appModule}/toggle-status', [AppModuleController::class, 'toggleStatus'])->name('app-module.toggleStatus');
```

### F6 — Controller shape

#### AMC-06 · L · CTL-04 — Two public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php:113` and `:125` |
| **Root cause** | `destroy()` and `toggleStatus()` omit a return type. `toggleStatus()` can return a `JsonResponse` (AJAX) or a `RedirectResponse` (plain post); `destroy()` never returns because `abort()` always throws. |
| **Consequence** | Callers and static analysis cannot see the contract; impact is minor because both are reached only from the blade/AJAX wiring. |
| **Reproduce** | static only. |
| **Fix approach** | `destroy(): never`; `toggleStatus(): \Illuminate\Http\JsonResponse|RedirectResponse`. |
| **Plan item** | AMC-06 in `02-fix-plan.md` §5 |

```php
// AppModuleController.php:113-116 — CURRENT
    public function destroy(string $appModule)
    {
        abort(403, 'App modules cannot be deleted. Deactivate the module instead.');
    }
```

**Evidence**
```
$ grep -n "public function destroy\|public function toggleStatus" Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php
113:    public function destroy(string $appModule)
125:    public function toggleStatus(Request $request, string $appModule)
```

### F7 — Models

#### AMC-10 · M · MDL-01 — `is_system` is mass-assignable, so a crafted update can freeze a module

| Field | Value |
|---|---|
| **Rule** | MDL-01 (H default, lowered to M) — *`$fillable` declared; nothing sensitive in it*; lowered because only admin-ish roles hold the update permission and the outcome is a frozen row, not data loss. |
| **Where** | `Modules/GlobalMaster/app/Models/AppModule.php:44-51` and `Modules/GlobalMaster/app/Http/Requests/AppModuleRequest.php:45,75-77` |
| **Root cause** | `is_system` is listed in `$fillable`, the FormRequest accepts it (`'is_system' => ['sometimes','boolean']`) and `prepareForValidation()` force-merges it into **every** payload, so `$model->update($request->validated())` writes it. The controller only refuses to edit rows that are ALREADY `is_system` (AppModuleController.php:79, :134); nothing stops a request from SETTING the flag. (The seeder is unaffected — it uses `DB::table()->updateOrInsert()`.) |
| **Consequence** | A user holding `prime.global-master.app-module.update` (held by **Support Team** as well as admins) can send `is_system=1` on the update URL and permanently freeze a module: the edit form then refuses it and there is no delete route, so only a seeder or direct DB edit can undo it. |
| **Reproduce** | static only — would need an authenticated PUT carrying `is_system=1`; the blade never sends the field. |
| **Fix approach** | Remove `is_system` from `$fillable` and stop the request accepting it (drop the rule and the merge). New modules then correctly default to `is_system = 0`. |
| **Plan item** | AMC-10 in `02-fix-plan.md` §5 |

```php
// AppModule.php:44-51 — CURRENT
    protected $fillable = [
        'ordinal',
        'code',
        'name',
        'module_prefix',
        'is_system',
        'is_active',
    ];
```

**Evidence**
```
$ grep -n "is_system" Modules/GlobalMaster/app/Models/AppModule.php Modules/GlobalMaster/app/Http/Requests/AppModuleRequest.php
Modules/GlobalMaster/app/Models/AppModule.php:49:        'is_system',
Modules/GlobalMaster/app/Models/AppModule.php:54:        'is_system' => 'boolean',
Modules/GlobalMaster/app/Http/Requests/AppModuleRequest.php:45:            'is_system' => ['sometimes', 'boolean'],
Modules/GlobalMaster/app/Http/Requests/AppModuleRequest.php:76:            'is_system' => $this->boolean('is_system'),
```

### F8 — Services and jobs

none — this controller calls no service, job, event, mail or notification; the only helper it calls is the common `activityLog()` sink. Evidence: `grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b' AppModuleController.php` → `AppModuleRequest` only.

### F9 — Queries and performance

clean — the controller runs a single `findOrFail()` per action and one `update`/`save`; there is no list, no loop and no query in a loop. Evidence: `grep -n "::where\|::all\|->get()\|foreach\|paginate" AppModuleController.php` → no output.

### F10 — Views

none — the controller renders no blade (`grep -oE "view\(['\"]" AppModuleController.php` → no output). The pane `_pane.blade.php` is rendered by `SettingController` and is outside this controller's scope.

### F11 — Security and tenancy

clean — no `env()` outside config; no personal data in JSON (the JSON branch returns only `success`, `is_active`, `message`); no hard-coded ids; the model pins `$connection = 'global_master_mysql'` and every route is on the central domain; the central activity log is a central table. The `is_system` write hole is filed as AMC-10. Evidence: `grep -nE "env\(|->toArray\(|json_encode" AppModuleController.php` → no output.

### F12 — Style

#### AMC-07 · L · STY-04 — Warning-symbol markers in the controller's comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php:21`, `:30`, `:101` |
| **Root cause** | Docblock lines are prefixed with the warning symbols `⚠` and `⛔`. |
| **Consequence** | Cosmetic only; no user impact. |
| **Reproduce** | static only. |
| **Fix approach** | Remove the leading marker and keep the sentence. |
| **Plan item** | AMC-07 in `02-fix-plan.md` §8 |

```php
// AppModuleController.php:21 — CURRENT
 * ⚠ NOT ModuleController. That one manages `glb_modules`, the SALEABLE module a
```

**Evidence**
```
$ grep -nP '[\x{26A0}\x{26D4}]' Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php
21: * ⚠ NOT ModuleController. That one manages `glb_modules`, the SALEABLE module a
30: * ⚠ THE PRIMARY KEY IS A VARCHAR. Route parameters are bound by `key`, not id, so
101:     * ⛔ UNROUTED BY DECISION (2026-08-31) — there is no delete route for this catalogue.
```

#### AMC-08 · L · STY-04 — Warning-symbol marker in the model's comment

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers* |
| **Where** | `Modules/GlobalMaster/app/Models/AppModule.php:13` |
| **Root cause** | The class docblock line is prefixed with the warning symbol `⚠`. |
| **Consequence** | Cosmetic only; no user impact. |
| **Reproduce** | static only. |
| **Fix approach** | Remove the leading marker and keep the sentence. |
| **Plan item** | AMC-08 in `02-fix-plan.md` §8 |

```php
// AppModule.php:13 — CURRENT
 * ⚠ NOT \Modules\GlobalMaster\Models\Module (`glb_modules`). That one is the
```

**Evidence**
```
$ grep -nP '[\x{26A0}\x{26D4}]' Modules/GlobalMaster/app/Models/AppModule.php
13: * ⚠ NOT \Modules\GlobalMaster\Models\Module (`glb_modules`). That one is the
```

#### AMC-09 · L · STY-01 — `AppModule.php` is missing `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files (mandatory when touched)* |
| **Where** | `Modules/GlobalMaster/app/Models/AppModule.php:1` |
| **Root cause** | The file opens `<?php` then `namespace`; there is no `declare` statement. |
| **Consequence** | Cosmetic/consistency; PHP keeps coercing scalar arguments for this file. |
| **Reproduce** | static only. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag. |
| **Plan item** | AMC-09 in `02-fix-plan.md` §8 |

```php
// AppModule.php:1-3 — CURRENT
<?php

namespace Modules\GlobalMaster\Models;
```

**Evidence**
```
$ head -3 Modules/GlobalMaster/app/Models/AppModule.php
<?php

namespace Modules\GlobalMaster\Models;
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 overwrite? | 2 delete-before-store? | 3 duplicates? | 4 soft-delete×unique? | 5 race? | 6 auth hole? | 7 lying message? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | n/a (no delete) | ok | AMC-05 (latent) | ok | ok | ok | ok |
| `update` | AMC-10 (is_system flip) | n/a | ok | AMC-05 (latent) | ok | AMC-10 | ok | ok |
| `toggleStatus` | ok | n/a | AMC-03 (un-transacted audit) | n/a | ok | ok | ok | ok |
| `destroy` | n/a (aborts) | n/a | ok | n/a | n/a | ok (aborts 403) | ok | ok |

Notes: the `prepareForValidation()` merge deliberately turns an absent `is_active` checkbox into `false` (correct for a form that always posts the checkbox); no other caller updates an `AppModule`, so there is no path where that merge silently deactivates a module — recorded as a constraint, not a finding.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/GlobalMaster/routes/web.php:89` | The central `system-config` route group is behind `auth, verified` only, while the sibling `prime` group (line 34) also adds `2fa`. The App Modules action therefore does not require a second factor. | RTE-05 (analogue) | Route-file owner (shared) — not this controller |
| `app/Helpers/activityLog.php` | Central writes take a second connection's table (`sys_central_activity_logs`) outside any transaction supplied by itself; callers must wrap. Recorded because AMC-03 depends on it. | TXN-01 | shared helper owner — no change needed |

## 8. Not covered, and why

- `Modules/GlobalMaster/app/Models/AppConfig.php` — reached only as the target of `AppModule::configs()`; this controller never calls that relation (proved by `grep -n "configs(" AppModuleController.php` → no output), so it belongs to the AppConfig audit. The relation itself was proved to resolve (`AppModule::first()->configs()->count()` → 4, relation class `Illuminate\Database\Eloquent\Relations\HasMany`).
- `Modules/GlobalMaster/resources/views/app-module/_pane.blade.php` — rendered by `\Modules\Prime\Http\Controllers\SettingController`, not by this controller; VIEW-01/02/03 are therefore not this controller's to answer. It was read only to confirm the forms post `code`, `name`, `module_prefix`, `ordinal`, `is_active` (never `is_system`), which underpins AMC-10's Reproduce note.
- Live end-to-end execution of a failing write (to observe the catch and the transaction rollback) — not run, per D4 (no tests).
- Permission refusal for a role that does NOT hold the permission — no such role was exercised; the exact-name seed and the four holder roles were measured instead.
