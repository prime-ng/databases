# Status — GlobalMaster / AppModuleController

**Fixed:** 2026-10-17 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| AMC-01 | `AppModuleController.php` store/update | try/catch, the dead `ModelNotFoundException` catch and `Log::error(getMessage())` removed (D1). The write and its `activityLog` run in one transaction; the redirect is built after it closes. The `is_system` guard in `update()` and `findOrFail()` stay outside the transaction. | `grep -c "catch ("` | 1 — the docblock's "try/catch (D1)" text, not code | 2026-10-17 |
| AMC-03 | `AppModuleController.php` toggleStatus | try/catch removed; the update and `'Toggled'` log now share one transaction. `is_active` is validated BEFORE the transaction (native 422), same as AppConfig/Plan. A failed write is now a 500, which the shared switch JS reverts on its `$.ajax` error branch, not a `success:false`. | probe | toggle → `success:true`; missing `is_active` → 422; system row → `success:false` | 2026-10-17 |
| AMC-05 | `AppModuleRequest.php` | `whereNull('deleted_at')` dropped from the `code` unique rule, so it matches `uq_sys_module_code` (a plain UNIQUE). Same call as AFC-03: `destroy()` aborts 403, so no row is ever trashed (live: 49 rows, 0 trashed) and no migration is needed. | grep + probe | no output; a trashed row's code is now refused on `code` | 2026-10-17 |
| AMC-06 | `AppModuleController.php` | `destroy(): never`; `toggleStatus()` and `toggleResponse()` → `RedirectResponse\|JsonResponse` (imported `JsonResponse`, not the FQCN the plan wrote). | grep | both signatures | 2026-10-17 |
| AMC-10 | `AppModule.php`, `AppModuleRequest.php` | `is_system` removed from `$fillable`, from the rules and from `prepareForValidation()`. Its only writer, `AppModuleSeeder`, uses the query builder, so `$fillable` never applied to it; no blade posts the field. | probe | `validated()` has no `is_system`; a payload with `is_system=1` stores/updates `false` | 2026-10-17 |
| AMC-07 / AMC-08 | controller, model | ⚠/⛔ markers → `NOTE:`. | emoji grep | no output | 2026-10-17 |
| AMC-09 | `AppModule.php` | `declare(strict_types=1)`. | grep | line 3 | 2026-10-17 |

### 2.1 Applied with the AFC-09 trait
The plan wrote `DB::transaction(...)`. `AppModule` saves through `global_master_mysql`, so a plain `DB::transaction` would cover only the activity log (AFC-09). All 3 writes use `WritesGlobalMaster::inGlobalMasterTransaction()` instead.

## 3. Not applied
None. AMC-02 and AMC-04 close with AMC-01/03 (plan §10).

## 4. Needs Tarun's hand
- Browser check: `/system-config/setting?tab=app-modules`. Add a module, edit a non-system one, and toggle status. Confirm that a system row's switch still refuses.

## 5. Unverifiable by this workflow (D4)
- Every check ran as super admin. This screen is Super-Admin only by design.

## 6. Verification log
```
vendor/bin/pint <controller> <request> <model> --format agent → passed
php -l (3 files)                                  → No syntax errors
class_exists(AppModuleController)                 → true
routes store/update/toggleStatus                  → every method exists
GET setting?tab=app-modules                       → 200, 359,757 B, 0 comment leaks
rolled-back probe                                 → AMC-05 trashed code refused on [code]; store 302 + 'Stored';
                                                    update 302 (is_system stays false); toggle success:true;
                                                    system toggle success:false; missing is_active 422;
                                                    unknown key ModelNotFound; destroy 403
after rollback                                    → probe row gone, 0 trashed
simulated failure inside inGlobalMasterTransaction → name unchanged, activity logs 2 → 2
```

## 7. Final state
FIXED. No open items.
