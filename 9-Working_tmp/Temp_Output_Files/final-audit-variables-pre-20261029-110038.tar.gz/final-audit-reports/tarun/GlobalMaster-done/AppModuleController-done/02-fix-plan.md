# Fix Plan — GlobalMaster / AppModuleController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php` | shared route file; this plan adds, removes and re-scopes no route |
| `Modules/GlobalMaster/resources/views/app-module/_pane.blade.php` | shared pane, rendered by `SettingController` |
| `Modules/GlobalMaster/app/Models/AppConfig.php` | owned by another audit |
| `config/permissionslist.php` | shared; no new permission key is required |
| any file under `database/migrations/` | no migration is needed; the DDL wins |

## 1. Blockers reachable today

None — the audit found no B-severity finding.

## 2. Fixes that arm a latent defect (sequenced)

None — no item must be applied before another to avoid arming a defect.

## 3. Errors & transactions (F1/F2)

- [x] **AMC-01** · M · ERR-00 · `AppModuleController.php:49-67` and `:83-97` — remove the `try/catch` from `store()` and `update()` so the central handler renders and logs the real failure; keep `DB::transaction` and move the redirect after the closure.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php`
  - **Before** (`AppModuleController.php:49-67`, in `store()`):
    ```php
        try {
            return DB::transaction(function () use ($request) {
                // `key` is mass-assignment-guarded on the model precisely so it can only
                // be set here, at creation, and never silently rewritten by an update.
                $appModule = new AppModule($request->validated());
                $appModule->key = $request->validated()['key'];
                $appModule->save();

                activityLog($appModule, 'Stored', ['message' => 'A new application module was created.']);

                return redirect()->to($this->backToTab())->with('success', flash('created.app_module'));
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('AppModuleController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After:** (replace the block above, keeping the closing brace of `store()`):
    ```php
        $appModule = new AppModule($request->validated());
        $appModule->key = $request->validated()['key'];

        DB::transaction(function () use ($appModule) {
            $appModule->save();
            activityLog($appModule, 'Stored', ['message' => 'A new application module was created.']);
        });

        return redirect()->to($this->backToTab())->with('success', flash('created.app_module'));
    ```
  - **Before** (`AppModuleController.php:83-97`, in `update()`):
    ```php
        try {
            return DB::transaction(function () use ($request, $model) {
                $model->update($request->validated());

                activityLog($model, 'Edited', ['message' => 'An application module was updated.']);

                return redirect()->to($this->backToTab())->with('success', flash('updated.app_module'));
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('AppModuleController::update failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After:** (replace the block above, keeping the closing brace of `update()`):
    ```php
        DB::transaction(function () use ($request, $model) {
            $model->update($request->validated());
            activityLog($model, 'Edited', ['message' => 'An application module was updated.']);
        });

        return redirect()->to($this->backToTab())->with('success', flash('updated.app_module'));
    ```
  - **Verify:** `sed -n '45,98p' Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php | grep -c "catch ("`
  - **Expect:** `0`
  - **Effort:** S

- [x] **AMC-03** · H · TXN-01 · `AppModuleController.php:143-163` — wrap the `toggleStatus()` update and its activity-log write in one `DB::transaction`, and drop its `try/catch`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php`
  - **Before** (`AppModuleController.php:143-163`, in `toggleStatus()`):
    ```php
        try {
            // Take the value the switch actually sent rather than negating what is in the
            // database: two quick clicks would otherwise resolve against a stale read and
            // leave the row in the opposite state to the control.
            $validated = $request->validate(['is_active' => 'required|boolean']);

            $model->update(['is_active' => (bool) $validated['is_active']]);

            activityLog($model, 'Toggled', [
                'message' => 'Application module status was toggled.',
                'is_active' => $model->is_active,
            ]);

            return $this->toggleResponse($request, true, $model->is_active, flash('status_updated.app_module'));
        } catch (ValidationException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('AppModuleController::toggleStatus failed', ['error' => $e->getMessage()]);

            return $this->toggleResponse($request, false, $model->is_active, flash('status_switch_failed.app_module'));
        }
    ```
  - **After:** (replace the block above, keeping the closing brace of `toggleStatus()`):
    ```php
        // Take the value the switch actually sent rather than negating what is in the
        // database: two quick clicks would otherwise resolve against a stale read and
        // leave the row in the opposite state to the control.
        $validated = $request->validate(['is_active' => 'required|boolean']);

        DB::transaction(function () use ($model, $validated) {
            $model->update(['is_active' => (bool) $validated['is_active']]);
            activityLog($model, 'Toggled', [
                'message' => 'Application module status was toggled.',
                'is_active' => $model->is_active,
            ]);
        });

        return $this->toggleResponse($request, true, $model->is_active, flash('status_updated.app_module'));
    ```
  - **Verify:** `sed -n '125,165p' Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php | grep -c "DB::transaction"`
  - **Expect:** `1`
  - **Effort:** S

## 4. Authorization (F3)

None — every routed method already authorizes with an existing, seeded permission.

## 5. Validation, routes, models (F4/F5/F7)

- [x] **AMC-05** · M · VAL-04 · `AppModuleRequest.php:34-36` — drop `->whereNull('deleted_at')` so the unique-`code` rule matches the DB's plain unique index.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/AppModuleRequest.php`
  - **Before** (`AppModuleRequest.php:33-37`):
    ```php
            'code' => [
                'required', 'string', 'max:30', 'regex:/^[A-Z][A-Z0-9_]*$/',
                Rule::unique('global_master_mysql.glb_app_modules', 'code')
                    ->ignore($currentKey, 'key')
                    ->whereNull('deleted_at'),
            ],
    ```
  - **After:**
    ```php
            'code' => [
                'required', 'string', 'max:30', 'regex:/^[A-Z][A-Z0-9_]*$/',
                Rule::unique('global_master_mysql.glb_app_modules', 'code')
                    ->ignore($currentKey, 'key'),
            ],
    ```
  - **Verify:** `grep -n "whereNull('deleted_at')" Modules/GlobalMaster/app/Http/Requests/AppModuleRequest.php`
  - **Expect:** no output
  - **Effort:** S

- [x] **AMC-06** · L · CTL-04 · `AppModuleController.php:113` and `:125` — add return types to `destroy()` and `toggleStatus()`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php`
  - **Before** (`AppModuleController.php:113-116`):
    ```php
        public function destroy(string $appModule)
        {
            abort(403, 'App modules cannot be deleted. Deactivate the module instead.');
        }
    ```
  - **After:**
    ```php
        public function destroy(string $appModule): never
        {
            abort(403, 'App modules cannot be deleted. Deactivate the module instead.');
        }
    ```
  - **Before** (`AppModuleController.php:125`):
    ```php
        public function toggleStatus(Request $request, string $appModule)
    ```
  - **After:**
    ```php
        public function toggleStatus(Request $request, string $appModule): \Illuminate\Http\JsonResponse|RedirectResponse
    ```
  - **Verify:** `grep -n "public function destroy\|public function toggleStatus" Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php`
  - **Expect:** both lines end with a `: never` / `: \Illuminate\Http\JsonResponse|RedirectResponse`
  - **Effort:** S

- [x] **AMC-10** · M · MDL-01 · `AppModule.php:44-51` and `AppModuleRequest.php:45,72-78` — stop `is_system` from being mass-assignable/updatable so a crafted request cannot freeze a module.
  - **Touches:** `Modules/GlobalMaster/app/Models/AppModule.php`, `Modules/GlobalMaster/app/Http/Requests/AppModuleRequest.php`
  - **Before** (`AppModule.php:44-51`):
    ```php
        protected $fillable = [
            'ordinal',
            'code',
            'name',
            'module_prefix',
            'is_system',
            'is_active',
        ];
    ```
  - **After:**
    ```php
        protected $fillable = [
            'ordinal',
            'code',
            'name',
            'module_prefix',
            'is_active',
        ];
    ```
  - **Before** (`AppModuleRequest.php:45-46`):
    ```php
                'is_system' => ['sometimes', 'boolean'],
                'is_active' => ['sometimes', 'boolean'],
    ```
  - **After:**
    ```php
                'is_active' => ['sometimes', 'boolean'],
    ```
  - **Before** (`AppModuleRequest.php:72-78`):
    ```php
            // Unchecked checkboxes are absent from the payload, which for a boolean column
            // means "leave it alone" rather than "set false". Normalise both flags so an
            // update that clears them actually clears them.
            $this->merge([
                'is_system' => $this->boolean('is_system'),
                'is_active' => $this->boolean('is_active'),
            ]);
    ```
  - **After:**
    ```php
            // An unchecked checkbox is absent from the payload, which for a boolean column
            // means "leave it alone" rather than "set false". Normalise the flag so an
            // update that clears it actually clears it.
            $this->merge([
                'is_active' => $this->boolean('is_active'),
            ]);
    ```
  - **Verify:** `grep -n "is_system" Modules/GlobalMaster/app/Http/Requests/AppModuleRequest.php; grep -n "'is_system'," Modules/GlobalMaster/app/Models/AppModule.php`
  - **Expect:** no output from either command
  - **Effort:** S

## 6. Queries & performance (F9)

None — the controller runs no list and no query in a loop.

## 7. Views (F10)

None — this controller renders no blade.

## 8. Style (F12) — one item per file

- [x] **AMC-07** · L · STY-04 · `AppModuleController.php:21,30,101` — replace the warning-symbol markers in the docblocks with plain text.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php`
  - **Before** (`AppModuleController.php:21`):
    ```php
     * ⚠ NOT ModuleController. That one manages `glb_modules`, the SALEABLE module a
    ```
  - **After:**
    ```php
     * NOTE: NOT ModuleController. That one manages `glb_modules`, the SALEABLE module a
    ```
  - **Before** (`AppModuleController.php:30`):
    ```php
     * ⚠ THE PRIMARY KEY IS A VARCHAR. Route parameters are bound by `key`, not id, so
    ```
  - **After:**
    ```php
     * NOTE: THE PRIMARY KEY IS A VARCHAR. Route parameters are bound by `key`, not id, so
    ```
  - **Before** (`AppModuleController.php:101`):
    ```php
         * ⛔ UNROUTED BY DECISION (2026-08-31) — there is no delete route for this catalogue.
    ```
  - **After:**
    ```php
         * NOTE: UNROUTED BY DECISION (2026-08-31) — there is no delete route for this catalogue.
    ```
  - **Verify:** `grep -nP '[\x{26A0}\x{26D4}]' Modules/GlobalMaster/app/Http/Controllers/AppModuleController.php`
  - **Expect:** no output
  - **Effort:** S

- [x] **AMC-08** · L · STY-04 · `AppModule.php:13` — replace the warning-symbol marker in the class docblock with plain text.
  - **Touches:** `Modules/GlobalMaster/app/Models/AppModule.php`
  - **Before** (`AppModule.php:13`):
    ```php
     * ⚠ NOT \Modules\GlobalMaster\Models\Module (`glb_modules`). That one is the
    ```
  - **After:**
    ```php
     * NOTE: NOT \Modules\GlobalMaster\Models\Module (`glb_modules`). That one is the
    ```
  - **Verify:** `grep -nP '[\x{26A0}\x{26D4}]' Modules/GlobalMaster/app/Models/AppModule.php`
  - **Expect:** no output
  - **Effort:** S

- [x] **AMC-09** · L · STY-01 · `AppModule.php:1` — add `declare(strict_types=1);`.
  - **Touches:** `Modules/GlobalMaster/app/Models/AppModule.php`
  - **Before** (`AppModule.php:1-3`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Models;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/GlobalMaster/app/Models/AppModule.php`
  - **Expect:** `3:declare(strict_types=1);`
  - **Effort:** S

## 9. Deferred / decisions

None — no DECISION item; no migration, new permission key, `glb_menus` edit or controller split is required.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| AMC-02 | ERR-05 (log the exception, not the message). It lives inside the same catches removed by AMC-01 (`store`/`update`) and AMC-03 (`toggleStatus`); once those land, no `Log::error(... getMessage())` remains. |
| AMC-04 | TXN-05 (response built inside the transaction closure). Removed by AMC-01, whose After moves both `redirect()` calls outside the closure. |

---

**Applied 2026-10-17 (claude)** — all items ticked under Tarun's "fix all, ⭐ options" instruction for GlobalMaster. AMC-01/03 use `WritesGlobalMaster::inGlobalMasterTransaction()`, not a plain `DB::transaction`, because `glb_app_modules` is on `global_master_mysql` (AFC-09). See `03-status.md`.
