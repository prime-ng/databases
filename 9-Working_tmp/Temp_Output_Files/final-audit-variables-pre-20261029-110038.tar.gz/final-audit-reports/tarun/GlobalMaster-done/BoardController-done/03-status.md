# Status — GlobalMaster / BoardController

**Fixed:** 2026-10-17 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
| ID | What | Where |
|---|---|---|
| BOA-08 | Restore over GET → POST route + dual-mode `x-prime.table.action-trashed`. Tarun chose dual-mode/POST over the plan's DELETE. | commit `6d157fb2c` (restore family) |

## 2. Applied
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| BOA-01 (+02/03/04/05/07) | `BoardController.php` | Six try/catch blocks, `ModelNotFoundException` rethrows and `Log::error(getMessage())` removed (D1). Responses built after the transaction. `$request->all()` → `$request->validated()` in store/update (a stray `evil` field no longer reaches the model). `toggleStatus` validates before the transaction. | `grep -n "catch\|all()"` | only the class-docblock comment | 2026-10-17 |
| BOA-06 | `BoardController.php` store/update | Duplicate `Gate::authorize` removed; `BoardRequest::authorize()` already checks the same permission first. | read both methods | no gate in store/update; request authorize unchanged | 2026-10-17 |
| BOA-09 | `BoardController.php` edit/destroy | `string $id` + `findOrFail` → `Board $board` binding. | route `method_exists` check | 11 routes, 0 missing | 2026-10-17 |
| BOA-10 | `BoardController.php` | Return types on every public method. | `php -l` + `class_exists` | clean / true | 2026-10-17 |
| BOA-11 | `Board.php` | ⚠ **Partly applied.** `strict_types`, unused `HasFactory` import and commented factory import removed, Pint-clean, `BelongsToMany` return type. **The `organizations()` relation was NOT removed**: `Modules/GlobalMaster/tests/Unit/ModelStructureTest.php:195` asserts it exists, and removing it would turn a passing test red. A docblock on the method records this. | `grep -n "HasFactory\|BoardFactory"` | no output | 2026-10-17 |
| BOA-12 | `Board.php` | Applied with BOA-11 (unused imports). | — | — | 2026-10-17 |
| BOA-14 | `board/trash.blade.php`, `create.blade.php`, `edit.blade.php` | "Country" copy-paste → "Name" column header and "Enter Board Short Name" placeholder. | `grep -rn Country board/` | no output | 2026-10-17 |
| BOA-15 | `BoardController.php`, `BoardRequest.php` | `strict_types`. | head of files | present | 2026-10-17 |
| BOA-16 | `BoardRequest.php` | Comment names the real `prime.global-master.board.*` permissions. | `grep -n "prime.board"` | no output | 2026-10-17 |
| BOA-13 | — | DECISION (a): deferred to the module-wide modal pass. | — | — | 2026-10-17 |

## 3. Not applied
- **BOA-11, relation removal only** — blocked by `ModelStructureTest.php:195`. Decide whether to delete that assertion (tests are not edited by this workflow, D4), then remove `organizations()` and its `Organization` import.

## 4. Needs Tarun's hand
- Browser check: `/prime/session-board-setup#academicboard` — create, edit, toggle, trash → restore → force-delete a board.
- The BOA-11 test decision above.
- Nothing to migrate, seed or sync.

## 5. Unverifiable by this workflow (D4)
- BOA-06 relies on `BoardRequest::authorize()`; every check here runs as super admin, so a refusal is not exercised.

## 6. Verification log
```
vendor/bin/pint <3 files> --format agent           → fixed Board.php (spacing only)
php -l <3 files>                                    → No syntax errors
class_exists(BoardController|BoardRequest|Board)    → true ×3
route:list --json (uncached) + method_exists        → routes=11 missing=0
render index / create / trashedBoard / edit         → OK 142,354 / 122,350 / 107,348 / 114,696 bytes
rolled-back store → destroy → restore               → RedirectResponse, trashed=true, live=true; 0 rows after rollback
```

## 7. Final state
**FIXED.** Open: BOA-11 relation removal (blocked on a test decision, L).

## 8. Follow-up 2026-10-17: the transactions did not cover the record (AFC-09)

Found while fixing AppConfigController. `Board` saves through `global_master_mysql`, but every `DB::transaction()` in this controller opened on the default `mysql` connection, where only `activityLog()` writes. These are two separate PDO handles, so the 6 transactions covered only the log. A failure after the save rolled back the audit row and left the record changed.

**Applied:** all 6 calls now use `WritesGlobalMaster::inGlobalMasterTransaction()` (new trait, `Http/Controllers/Concerns/`), which opens a `global_master_mysql` transaction around the default one. Tarun approved fixing all six FIXED controllers together.

**Verified:** `php -l` clean · class loads · every routed method exists · host page renders 200 · a simulated failure through this controller's helper rolls back both the record and the log · negative control: plain `DB::transaction` left the global_master write in place.
