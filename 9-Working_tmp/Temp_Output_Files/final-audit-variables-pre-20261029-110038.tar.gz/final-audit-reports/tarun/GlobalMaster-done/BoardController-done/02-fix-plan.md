# Fix Plan — GlobalMaster / BoardController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/BoardController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php` lines other than the board ones | Shared route file — only the `board.restore` line may change, and only via BOA-08 (⚠ SHARED). |
| `resources/views/components/backend/table/action-trashed.blade.php` | Shared component; BOA-08 needs no change here because it already switches to DELETE when the route verb is not GET. |
| `config/permissionslist.php` | The `global-master.board` key already exists with all seven actions. |
| `Modules/SchoolSetup/app/Models/Organization.php` | Owned by `OrganizationController` (later batch). BOA-11 removes the dead relation on `Board`, it does not edit `Organization`. |
| Any migration | The audit is read-only and no schema change is proposed as a fix. |

## 1. Blockers reachable today

- [x] **BOA-01** · H · ERR-00 / TXN-05 — remove the six controller `try/catch` blocks, build responses after the transaction, and write `$request->validated()` instead of `$request->all()`. This item also applies **BOA-02** (ERR-02), **BOA-03** (ERR-05), **BOA-04** (ERR-04), **BOA-05** (TXN-05) and **BOA-07** (VAL-01).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/BoardController.php`
  - **Before** (`BoardController.php:5-13`, imports):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\GlobalMaster\Http\Requests\BoardRequest;
    use Modules\GlobalMaster\Models\Board;
    ```
  - **After:** (imports — drop the two now-unused imports):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\GlobalMaster\Http\Requests\BoardRequest;
    use Modules\GlobalMaster\Models\Board;
    ```
  - **Before** (`BoardController.php:36-53`, `store`):
    ```php
            try {
                return DB::transaction(function () use ($request) {
                    $board = Board::create($request->all());

                    activityLog($board, 'Stored', ['message' => 'A new board was created.', 'other' => 'some other information']);

                    return redirect()->to(route('central.prime.session-board-setup.index').'#academicboard')->with('success', flash('created.board'));

                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('BoardController::store failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:** (`store`):
    ```php
            $board = DB::transaction(function () use ($request) {
                $board = Board::create($request->validated());

                activityLog($board, 'Stored', ['message' => 'A new board was created.', 'other' => 'some other information']);

                return $board;
            });

            return redirect()->to(route('central.prime.session-board-setup.index').'#academicboard')->with('success', flash('created.board'));
    ```
  - **Before** (`BoardController.php:75-118`, `update`):
    ```php
            try {
                return DB::transaction(function () use ($request, $board) {
                    $original = $board->getOriginal();
                    $board->update($request->all());

                    $changes = $board->getChanges();
                    $changedAttributes = [];

                    foreach ($changes as $field => $newValue) {
                        if ($field === 'updated_at') {
                            continue;
                        }
                        $changedAttributes[$field] = [
                            'old' => $original[$field] ?? null,
                            'new' => $newValue,
                        ];
                    }

                    if (! empty($changedAttributes)) {
                        activityLog($board, 'Updated', [
                            'message' => 'A new board was updated.',
                            'changes' => $changedAttributes,
                            'performed_by' => Auth::user()->name,
                        ]);
                    } else {
                        activityLog($board, 'Updated', [
                            'message' => 'A new board was updated. No attributes changed.',
                            'performed_by' => Auth::user()->name,
                        ]);
                    }

                    return redirect()->to(route('central.prime.session-board-setup.index').'#academicboard')->with('success', flash('updated.board'));

                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('BoardController::update failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:** (`update`):
    ```php
            DB::transaction(function () use ($request, $board) {
                $original = $board->getOriginal();
                $board->update($request->validated());

                $changes = $board->getChanges();
                $changedAttributes = [];

                foreach ($changes as $field => $newValue) {
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changedAttributes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                if (! empty($changedAttributes)) {
                    activityLog($board, 'Updated', [
                        'message' => 'A new board was updated.',
                        'changes' => $changedAttributes,
                        'performed_by' => Auth::user()->name,
                    ]);
                } else {
                    activityLog($board, 'Updated', [
                        'message' => 'A new board was updated. No attributes changed.',
                        'performed_by' => Auth::user()->name,
                    ]);
                }
            });

            return redirect()->to(route('central.prime.session-board-setup.index').'#academicboard')->with('success', flash('updated.board'));
    ```
  - **Before** (`BoardController.php:124-144`, `destroy`):
    ```php
            try {
                return DB::transaction(function () use ($id) {
                    $board = Board::findOrFail($id);
                    $board->is_active = false;
                    $board->save();
                    $board->delete();

                    activityLog($board, 'Trashed', ['message' => 'A new board was deactivated and deleted.', 'other' => 'some other information']);

                    return redirect()->to(route('central.prime.session-board-setup.index').'#academicboard')->with('success', flash('trashed.board'));

                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('BoardController::destroy failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:** (`destroy`, signature preserved for BOA-09 to change):
    ```php
            DB::transaction(function () use ($id) {
                $board = Board::findOrFail($id);
                $board->is_active = false;
                $board->save();
                $board->delete();

                activityLog($board, 'Trashed', ['message' => 'A new board was deactivated and deleted.', 'other' => 'some other information']);
            });

            return redirect()->to(route('central.prime.session-board-setup.index').'#academicboard')->with('success', flash('trashed.board'));
    ```
  - **Before** (`BoardController.php:159-178`, `restore`):
    ```php
            try {
                return DB::transaction(function () use ($id) {
                    $board = Board::withTrashed()->findOrFail($id);
                    $board->restore();

                    activityLog($board, 'Restored', ['message' => 'A new board was restored.', 'other' => 'some other information']);

                    return redirect()->route('central.global-master.board.trashed')->with('success', flash('restored.board'));

                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('BoardController::restore failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:** (`restore`):
    ```php
            DB::transaction(function () use ($id) {
                $board = Board::withTrashed()->findOrFail($id);
                $board->restore();

                activityLog($board, 'Restored', ['message' => 'A new board was restored.', 'other' => 'some other information']);
            });

            return redirect()->route('central.global-master.board.trashed')->with('success', flash('restored.board'));
    ```
  - **Before** (`BoardController.php:184-203`, `forceDelete`):
    ```php
            try {
                return DB::transaction(function () use ($id) {
                    $board = Board::withTrashed()->findOrFail($id);
                    $board->forceDelete();

                    activityLog($board, 'Deleted', ['message' => 'A new board was permanently deleted.', 'other' => 'some other information']);

                    return redirect()->route('central.global-master.board.trashed')->with('success', flash('force_deleted.board'));

                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('BoardController::forceDelete failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:** (`forceDelete`):
    ```php
            DB::transaction(function () use ($id) {
                $board = Board::withTrashed()->findOrFail($id);
                $board->forceDelete();

                activityLog($board, 'Deleted', ['message' => 'A new board was permanently deleted.', 'other' => 'some other information']);
            });

            return redirect()->route('central.global-master.board.trashed')->with('success', flash('force_deleted.board'));
    ```
  - **Before** (`BoardController.php:209-248`, `toggleStatus`):
    ```php
            try {
                return DB::transaction(function () use ($request, $board) {
                    $request->validate([
                        'is_active' => 'required|boolean',
                    ]);
                    $newStatus = $request->input('is_active');
                    $board->is_active = $newStatus;

                    if ($board->save()) {
                        activityLog($board, 'Toggled', ['message' => 'A new board status was updated.', 'other' => 'some other information']);

                        return response()->json([
                            'success' => true,
                            'is_active' => $board->is_active,
                            'message' => flash('status_updated.board'),
                        ]);
                    } else {
                        return response()->json([
                            'success' => false,
                            'is_active' => $board->is_active,
                            'message' => flash('status_switch_failed.board'),
                        ]);
                    }

                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('BoardController::toggleStatus failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:** (`toggleStatus` — validate before the transaction so a 422 stays a JSON 422):
    ```php
            $request->validate([
                'is_active' => 'required|boolean',
            ]);

            $board->is_active = $request->input('is_active');

            $saved = DB::transaction(function () use ($board) {
                if (! $board->save()) {
                    return false;
                }

                activityLog($board, 'Toggled', ['message' => 'A new board status was updated.', 'other' => 'some other information']);

                return true;
            });

            if ($saved) {
                return response()->json([
                    'success' => true,
                    'is_active' => $board->is_active,
                    'message' => flash('status_updated.board'),
                ]);
            }

            return response()->json([
                'success' => false,
                'is_active' => $board->is_active,
                'message' => flash('status_switch_failed.board'),
            ]);
    ```
  - **Verify:** `grep -cE "try \{|catch \(|request->all\(\)" Modules/GlobalMaster/app/Http/Controllers/BoardController.php`
  - **Expect:** `0`.
  - **Effort:** M

- [x] **BOA-08** · H · RTE-01 · ⚠ SHARED · `Modules/GlobalMaster/routes/web.php:132` — restore over GET; change it to DELETE so no state change rides a GET.
  - **Touches:** `Modules/GlobalMaster/routes/web.php`
  - **Before** (`web.php:132`):
    ```php
            Route::get('/board/{id}/restore', [BoardController::class, 'restore'])->name('board.restore');
    ```
  - **After:**
    ```php
            Route::delete('/board/{id}/restore', [BoardController::class, 'restore'])->name('board.restore');
    ```
  - **Verify:** `grep -n "board/{id}/restore" Modules/GlobalMaster/routes/web.php`
  - **Expect:** the single line now starts `Route::delete(`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

## 3. Errors & transactions (F1/F2)

All F1/F2 fixes are applied by **BOA-01** in §1. See §10.

## 4. Authorization (F3)

- [x] **BOA-06** · L · AUTH-04 · `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:34` and `:73` — drop the duplicate `Gate::authorize` in `store` and `update`; the FormRequest already checks the same permission first.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/BoardController.php`
  - **Before** (`BoardController.php:32-35`, `store` — the `update` method has the same line at `:73`):
    ```php
        public function store(BoardRequest $request)
        {
            Gate::authorize('prime.global-master.board.create');

    ```
  - **After:** (`store`; apply the same deletion at `update` — remove the `Gate::authorize('prime.global-master.board.update');` line at `:73`):
    ```php
        public function store(BoardRequest $request)
        {

    ```
  - **Verify:** `grep -n "Gate::authorize('prime.global-master.board.create')\|Gate::authorize('prime.global-master.board.update')" Modules/GlobalMaster/app/Http/Controllers/BoardController.php`
  - **Expect:** no output (the `viewAny`, `view`, `delete`, `restore`, `forceDelete` gates stay).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [x] **BOA-09** · M · CTL-03 · `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:63-68` (`edit`) and `:120-126` (`destroy`) — use route model binding instead of `string $id` plus `findOrFail`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/BoardController.php`
  - **Before** (`BoardController.php:63-68`, `edit`):
    ```php
        public function edit(string $id)
        {
            Gate::authorize('prime.global-master.board.update');
            $board = Board::findOrFail($id);

            return view('globalmaster::board.edit', compact('board'));
        }
    ```
  - **After:** (`edit` — the route parameter is already `{board}`):
    ```php
        public function edit(Board $board)
        {
            Gate::authorize('prime.global-master.board.update');

            return view('globalmaster::board.edit', compact('board'));
        }
    ```
  - **Before** (`destroy`, **after BOA-01 has been applied** — the `try` is gone; apply this only after BOA-01):
    ```php
        public function destroy(string $id)
        {
            Gate::authorize('prime.global-master.board.delete');

            DB::transaction(function () use ($id) {
                $board = Board::findOrFail($id);
    ```
  - **After:** (`destroy`):
    ```php
        public function destroy(Board $board)
        {
            Gate::authorize('prime.global-master.board.delete');

            DB::transaction(function () use ($board) {
    ```
  - **Deferred (D3):** `restore($id)` and `forceDelete($id)` are **not** converted here. They resolve a soft-deleted row with `withTrashed()`, so binding them needs `Route::bind`/`withTrashed()` plus renaming the shared route parameters `{id}` → `{board}` — a ⚠ SHARED route change. Left as `findOrFail` on purpose.
  - **Verify:** `grep -nE "public function (edit|destroy)\(" Modules/GlobalMaster/app/Http/Controllers/BoardController.php`
  - **Expect:** `edit(Board $board)` and `destroy(Board $board)`.
  - **Effort:** S

- [x] **BOA-11** · M · MDL-04 / CTL-10 / STY-05 · `Modules/GlobalMaster/app/Models/Board.php` — remove the dead cross-connection `organizations()` relation, drop the two unused imports, add `declare(strict_types=1);`, and make the file Pint-clean (this also applies BOA-12 and the model half of BOA-15).
  - **Touches:** `Modules/GlobalMaster/app/Models/Board.php`
  - **Before** (`Board.php:1-37`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\SchoolSetup\Models\Organization;
    // use Modules\GlobalMaster\Database\Factories\BoardFactory;

    class Board extends BaseModel
    {
        use SoftDeletes;
        protected $connection = 'global_master_mysql';
        protected $table = 'glb_boards';
        protected $fillable = [
            'name',
            'short_name',
            'is_active',
        ];

        protected $casts = [
            'is_active' => 'boolean',
        ];

        //begin::Eloquent Relationship
        public function organizations()
        {
            return $this->belongsToMany(
                Organization::class,
                'sch_board_organization_jnt',
                'board_id',
                'organization_id'
            )->withPivot('academic_sessions_id'); // MANY TO MANY WITH EXTRA FILEDS
        }
        //end::Eloquent Relationship
    }
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;

    class Board extends BaseModel
    {
        use SoftDeletes;

        protected $connection = 'global_master_mysql';

        protected $table = 'glb_boards';

        protected $fillable = [
            'name',
            'short_name',
            'is_active',
        ];

        protected $casts = [
            'is_active' => 'boolean',
        ];
    }
    ```
  - **Verify:** `vendor/bin/pint --test Modules/GlobalMaster/app/Models/Board.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass",...}`.
  - **Effort:** S

## 6. Queries & performance (F9)

## 7. Views (F10)

- [x] **BOA-14** · L · VIEW / STY-04 · `Modules/GlobalMaster/resources/views/board/trash.blade.php:16`, `create.blade.php:36`, `edit.blade.php:38` — fix the copy-pasted Country wording in the board blades.
  - **Touches:** `Modules/GlobalMaster/resources/views/board/trash.blade.php`, `Modules/GlobalMaster/resources/views/board/create.blade.php`, `Modules/GlobalMaster/resources/views/board/edit.blade.php`
  - **Before** (`trash.blade.php:16`):
    ```html
                                    <th>Country</th>
    ```
  - **After:** (`trash.blade.php:16`):
    ```html
                                    <th>Name</th>
    ```
  - **Before** (`create.blade.php:36`; `edit.blade.php:38` is the same without `old()` for the second argument):
    ```html
                                            placeholder="Enter Country Short Name" id="short_name" label="Short Name"
    ```
  - **After:** (`both files`):
    ```html
                                            placeholder="Enter Board Short Name" id="short_name" label="Short Name"
    ```
  - **Verify:** `grep -rn "Country" Modules/GlobalMaster/resources/views/board/`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [x] **BOA-10** · L · CTL-04 · `Modules/GlobalMaster/app/Http/Controllers/BoardController.php` — add a return type to every public method.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/BoardController.php`
  - **Before** (`BoardController.php:17`):
    ```php
        public function index()
    ```
  - **After:**
    ```php
        public function index(): \Illuminate\Contracts\View\View
    ```
  - **Apply the same one-line change to the other ten methods** (edit and destroy already read `Board $board` after BOA-09):
    ```php
        public function create(): \Illuminate\Contracts\View\View
        public function store(BoardRequest $request): \Illuminate\Http\RedirectResponse
        public function show(Board $board): \Illuminate\Contracts\View\View
        public function edit(Board $board): \Illuminate\Contracts\View\View
        public function update(BoardRequest $request, Board $board): \Illuminate\Http\RedirectResponse
        public function destroy(Board $board): \Illuminate\Http\RedirectResponse
        public function trashedBoard(): \Illuminate\Contracts\View\View
        public function restore($id): \Illuminate\Http\RedirectResponse
        public function forceDelete($id): \Illuminate\Http\RedirectResponse
        public function toggleStatus(Request $request, Board $board): \Illuminate\Http\JsonResponse
    ```
  - **Verify:** `grep -cE 'public function [a-zA-Z_]+\([^)]*\):' Modules/GlobalMaster/app/Http/Controllers/BoardController.php`
  - **Expect:** `11`.
  - **Effort:** S

- [x] **BOA-15** · L · STY-01 · `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:1` and `Modules/GlobalMaster/app/Http/Requests/BoardRequest.php:1` — add `declare(strict_types=1);` (the model's declaration is applied by BOA-11).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/BoardController.php`, `Modules/GlobalMaster/app/Http/Requests/BoardRequest.php`
  - **Before** (`BoardController.php:1-3`; `BoardRequest.php:1-3` has the same shape with its own namespace):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **Verify:** `grep -lc "declare(strict_types=1);" Modules/GlobalMaster/app/Http/Controllers/BoardController.php Modules/GlobalMaster/app/Http/Requests/BoardRequest.php`
  - **Expect:** both files listed (one match each).
  - **Effort:** S

- [x] **BOA-16** · L · STY-04 · `Modules/GlobalMaster/app/Http/Requests/BoardRequest.php:44-45` — the comment names a permission prefix that does not exist; update it to the real names.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/BoardRequest.php`
  - **Before** (`BoardRequest.php:44-46`):
    ```php
            // T6b — mirrors the controller's own gate: prime.board.create on POST,
            // prime.board.update on PUT/PATCH. Same permission, checked one step
            // earlier, so this narrows nothing and widens nothing.
    ```
  - **After:**
    ```php
            // T6b — mirrors the controller's own gate: prime.global-master.board.create on POST,
            // prime.global-master.board.update on PUT/PATCH. Same permission, checked one step
            // earlier, so this narrows nothing and widens nothing.
    ```
  - **Verify:** `grep -n "prime.board" Modules/GlobalMaster/app/Http/Requests/BoardRequest.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **BOA-13** · M · DECISION · VIEW (modal-standard §2.5) — convert the Board create/edit from full pages to the shared modal?
  - **Why it is a decision:** it changes the UI shape of two screens and the `create`/`edit` methods' return views; it is module-wide (State/District/City/Country have the same shape), so it is a conversion pass, not a Board-only fix.
  - (a) ⭐ defer to the module-wide modal pass — record as accepted for this controller (D3)
  - (b) convert this controller's create/edit now to `x-backend.tab.modal`
  - (c) leave as dedicated pages and record the standard as not applied here
  - ➜ Choice: (a) defer to the module-wide modal pass — Tarun 2026-10-17

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BOA-02 | Applied by plan item BOA-01 (validate moved above the transaction; try removed). |
| BOA-03 | Applied by plan item BOA-01 (the six `Log::error` lines live inside the removed catches). |
| BOA-04 | Applied by plan item BOA-01 (no catch returns HTML; the central renderer produces the JSON 422). |
| BOA-05 | Applied by plan item BOA-01 (each closure returns data; the redirect/JSON is built after `DB::transaction()`). |
| BOA-07 | Applied by plan item BOA-01 (`$request->all()` → `$request->validated()` in `store` and `update`). |
| BOA-12 | Applied by plan item BOA-11 (same `Board.php` edit: dead imports removed, `strict_types` added, Pint-clean). |
| BOA-17 | Informational (F13) — `forceDelete` vs the `sch_board_organization_jnt` FK `RESTRICT`; 0 links today, no code change requested. |
| BOA-18 | Informational (F13) — `destroy` deactivates then trashes, `restore` does not re-activate; matches the sibling convention, no code change requested. |
