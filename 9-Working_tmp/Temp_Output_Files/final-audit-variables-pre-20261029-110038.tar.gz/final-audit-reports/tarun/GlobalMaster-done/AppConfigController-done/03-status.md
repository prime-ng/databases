# Status — GlobalMaster / AppConfigController

**Fixed:** 2026-10-17 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| AFC-03 | `AppConfigRequest.php` | `whereNull('deleted_at')` dropped from the `ordinal` and `key` unique rules, so they match `uq_settings_ordinal` / `uq_settings_key`. Tarun confirmed this over the District/City "unique keys include deleted_at" standard: `destroy()` aborts, so no row is ever trashed (live: 4 rows, 0 trashed) and no migration is needed. | `grep -c "whereNull('deleted_at')"` | 1 — the remaining hit is the `module_id` `exists` rule, correct and out of scope | 2026-10-17 |
| AFC-01 | `AppConfigController.php` store/update | try/catch, the dead `ModelNotFoundException` catch and the `Log::error(getMessage())` lines removed (D1); the redirect now runs after the transaction. `Log`, `ModelNotFoundException` and `ValidationException` imports dropped. | `grep -nE "catch \(\|Log::\|ModelNotFound\|ValidationException"` | no output | 2026-10-17 |
| AFC-02 | `AppConfigController.php` updateValue/toggleStatus | Both lost their try/catch, and their write and `activityLog` now share one transaction. ⚠ **Deviation:** `toggleStatus()` validates `is_active` BEFORE the transaction opens, rather than inside it as the plan wrote; same as PlanController. | probe | toggle → `success:true`, missing `is_active` → 422 | 2026-10-17 |
| AFC-04 | `AppConfigRequest.php` | The TIME value is now range-checked as well as format-checked. | rolled-back store, `TIME 25:99` / `23:59` | refused on `value` / accepted | 2026-10-17 |
| AFC-05 | `AppConfigController.php` | Return types: `destroy(): never`, `toggleStatus()` and `toggleResponse()` → `RedirectResponse\|JsonResponse`. | grep | 3 signatures + `JsonResponse` import | 2026-10-17 |
| AFC-06 | `AppConfig.php` | `declare(strict_types=1)`. | grep | 1 | 2026-10-17 |
| AFC-07 | controller + request | The ⛔ and ⚠ markers removed from two comments. | emoji grep | no output | 2026-10-17 |

### 2.1 Found during the fix — fixed (A2)
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| AFC-09 | new `Http/Controllers/Concerns/WritesGlobalMaster.php`; `AppConfigController.php` | **The planned transactions covered only the activity log.** `AppConfig` saves through `global_master_mysql`, but `activityLog()` and `DB::transaction()` use the default `mysql` connection. These are two separate PDO handles (`getPdo()` identical = false), so a failure after the save rolled back the log and left the setting changed. New trait `WritesGlobalMaster::inGlobalMasterTransaction()` opens a `global_master_mysql` transaction around the default one. All four writes use it. | negative control: plain `DB::transaction` + throw | value 0 → **1** (not rolled back, so the gap is real) | 2026-10-17 |
| | | | the same failure inside `inGlobalMasterTransaction()` | value 0 → 0, activity logs 2 → 2 (both rolled back) | 2026-10-17 |

⚠ **The same gap exists in the six controllers marked FIXED earlier today** (Country, State, District, City, Board, Module): 36 transactions across them cover only the log. Tarun chose to fix all of them now, in a separate commit that uses the same trait. See `00-SUMMARY.md`.

## 3. Not applied
- AFC-08 (L, MDL-09) — a `ValueType` enum. Deferred by the plan, accepted.

## 4. Needs Tarun's hand
- Browser check: `/system-config/setting?tab=app-config`. Add a setting, edit it, change a value inline, and toggle status. Also confirm that a failed toggle snaps the switch back (it is now a 500 handled by the switch's `$.ajax` error branch, not a `success:false`).

## 5. Unverifiable by this workflow (D4)
- Every check ran as super admin. This screen is Super-Admin only by design.

## 6. Verification log
```
vendor/bin/pint <controller> <request> <model> <trait> --format agent → passed / no_unused_imports (DB facade)
php -l (4 files)                                      → No syntax errors
route:list --json (uncached)                          → 4 routes, every method exists
render /system-config/setting?tab=app-config          → 200 · 359,751 bytes · 0 comment leaks
rolled back (both connections): validation, store (log 'Stored'), updateValue, toggle, destroy 403
after rollback                                        → probe rows 0, id 1 unchanged
```

## 7. Final state
**FIXED.** Open: AFC-08 (deferred by plan). AFC-09 added and fixed.
