# Fix Plan — GlobalMaster / AppConfigController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php` | shared route file — no route changes in this plan |
| `Modules/Prime/resources/views/setting/index.blade.php` | the Settings page, other module's view |
| `resources/views/components/backend/partials/footer-scripts.blade.php`, `resources/views/components/backend/table/status-switch.blade.php`, `app/View/Components/Backend/Table/StatusSwitch.php` | shared components — the fixer never edits them |
| `app/Helpers/activityLog.php` | common sink — referenced, never claimed |
| `Modules/GlobalMaster/app/Models/AppModule.php` | owned by the AppModuleController report (in progress) |
| `config/permissionslist.php`, `config/flash.php` | shared config — no permission/flash changes here |
| any migration | never touch an existing migration |

## 1. Blockers reachable today

None — this controller has no B-severity findings.

## 2. Fixes that arm a latent defect (sequenced)

- [x] **AFC-03** · M · VAL-04 · `AppConfigRequest.php:38-44, 64-69` — drop `whereNull('deleted_at')` from the unique rules so they mirror the DB index exactly.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php`
  - **Before** (`AppConfigRequest.php:38-44`):
    ```php
            'ordinal' => [
                'required', 'integer', 'min:0', 'max:65535',
                Rule::unique('global_master_mysql.glb_app_config', 'ordinal')
                    ->where(fn ($q) => $q->where('module_id', $moduleId))
                    ->ignore($configId)
                    ->whereNull('deleted_at'),
            ],
    ```
  - **Before** (`AppConfigRequest.php:64-69`):
    ```php
            $rules['key'] = [
                'required', 'string', 'max:150', 'regex:/^[A-Z][A-Z0-9_]*$/',
                Rule::unique('global_master_mysql.glb_app_config', 'key')
                    ->where(fn ($q) => $q->where('module_id', $moduleId))
                    ->whereNull('deleted_at'),
            ];
    ```
  - **After:**
    ```php
            'ordinal' => [
                'required', 'integer', 'min:0', 'max:65535',
                // AFC-03 2026-10-12: index uq_settings_ordinal (module_id, ordinal) includes
                // trashed rows and this screen never soft-deletes, so keep the rule aligned
                // with the index (no whereNull) or a future trashed row becomes a 500.
                Rule::unique('global_master_mysql.glb_app_config', 'ordinal')
                    ->where(fn ($q) => $q->where('module_id', $moduleId))
                    ->ignore($configId),
            ],
    ```
    and
    ```php
            $rules['key'] = [
                'required', 'string', 'max:150', 'regex:/^[A-Z][A-Z0-9_]*$/',
                // AFC-03 2026-10-12: index uq_settings_key (module_id, key) includes trashed
                // rows and this screen never soft-deletes, so keep the rule aligned with the
                // index (no whereNull). If a delete route is ever added, change the index.
                Rule::unique('global_master_mysql.glb_app_config', 'key')
                    ->where(fn ($q) => $q->where('module_id', $moduleId)),
            ];
    ```
  - **Verify:** `grep -c "whereNull('deleted_at')" Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php`
  - **Expect:** `0`
  - ➜ Confirmed by Tarun 2026-10-17 over the District/City "unique keys include deleted_at" standard: this screen never soft-deletes, so the rule follows the index and no migration is written. ⚠ Expect is **1**, not 0 — the remaining hit is the `module_id` `exists` rule against `glb_app_modules`, which is correct and out of scope.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

> Apply items 1–4 in order. Item 1 removes the now-unused imports; items 2–4 quote the file
> as it is AFTER item 1.

- [x] **AFC-01** · H · ERR-06/D1 · `AppConfigController.php:34-60` — `store()`: drop the try/catch, keep one transaction, move the redirect out of the closure; remove the dead `ModelNotFoundException` catch and the unused imports.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php`
  - **Before — file top** (`AppConfigController.php:7-16`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\Validation\ValidationException;
    use Modules\GlobalMaster\Http\Requests\AppConfigRequest;
    use Modules\GlobalMaster\Models\AppConfig;
    ```
  - **After — file top:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\GlobalMaster\Http\Requests\AppConfigRequest;
    use Modules\GlobalMaster\Models\AppConfig;
    ```
  - **Before** (`AppConfigController.php:34-60`):
    ```php
        public function store(AppConfigRequest $request): RedirectResponse
        {
            Gate::authorize('prime.global-master.app-config.create');

            try {
                return DB::transaction(function () use ($request) {
                    $data = $request->validated();

                    // `key` is guarded on the model: application code looks a setting up by
                    // (module_id, key), so it is written once here and never mass-assigned
                    // on update. key_name is the label users are free to rename.
                    $config = new AppConfig($data);
                    $config->key = $data['key'];
                    $config->save();

                    activityLog($config, 'Stored', ['message' => 'A new application setting was created.']);

                    return redirect()->to($this->backToTab())->with('success', flash('created.app_config'));
                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('AppConfigController::store failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:**
    ```php
        public function store(AppConfigRequest $request): RedirectResponse
        {
            Gate::authorize('prime.global-master.app-config.create');

            DB::transaction(function () use ($request) {
                $data = $request->validated();

                // `key` is guarded on the model: application code looks a setting up by
                // (module_id, key), so it is written once here and never mass-assigned
                // on update. key_name is the label users are free to rename.
                $config = new AppConfig($data);
                $config->key = $data['key'];
                $config->save();

                activityLog($config, 'Stored', ['message' => 'A new application setting was created.']);
            });

            return redirect()->to($this->backToTab())->with('success', flash('created.app_config'));
        }
    ```
  - **Verify:** `grep -n "AppConfigController::store failed\|catch (\|ModelNotFoundException\|Facades\\\\Log" Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php`
  - **Expect:** no output (the log string, both `catch (` lines, and the ModelNotFoundException/Log imports are gone by the end of item 4).
  - **Effort:** S

- [x] **AFC-01** · H · ERR-06/D1 · `AppConfigController.php:62-81` — `update()`: drop the try/catch, keep one transaction, move the redirect out of the closure.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php`
  - **Before** (`AppConfigController.php:62-81`):
    ```php
        public function update(AppConfigRequest $request, AppConfig $appConfig): RedirectResponse
        {
            Gate::authorize('prime.global-master.app-config.update');

            try {
                return DB::transaction(function () use ($request, $appConfig) {
                    $appConfig->update($request->validated());

                    activityLog($appConfig, 'Edited', ['message' => 'An application setting was updated.']);

                    return redirect()->to($this->backToTab())->with('success', flash('updated.app_config'));
                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('AppConfigController::update failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:**
    ```php
        public function update(AppConfigRequest $request, AppConfig $appConfig): RedirectResponse
        {
            Gate::authorize('prime.global-master.app-config.update');

            DB::transaction(function () use ($request, $appConfig) {
                $appConfig->update($request->validated());

                activityLog($appConfig, 'Edited', ['message' => 'An application setting was updated.']);
            });

            return redirect()->to($this->backToTab())->with('success', flash('updated.app_config'));
        }
    ```
  - **Verify:** `grep -n "AppConfigController::update failed" Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **AFC-02** · H · ERR-06/D1 + TXN-01 · `AppConfigController.php:88-103` — `updateValue()`: drop the try/catch (AFC-01) and wrap the write + activityLog in one transaction (AFC-02).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php`
  - **Before** (`AppConfigController.php:88-103`):
    ```php
        public function updateValue(AppConfigRequest $request, AppConfig $appConfig): RedirectResponse
        {
            Gate::authorize('prime.global-master.app-config.update');

            try {
                $appConfig->update(['value' => $request->validated()['value']]);

                activityLog($appConfig, 'Edited', ['message' => 'An application setting value was updated.']);

                return redirect()->to($this->backToTab())->with('success', flash('updated.app_config'));
            } catch (\Throwable $e) {
                Log::error('AppConfigController::updateValue failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:**
    ```php
        public function updateValue(AppConfigRequest $request, AppConfig $appConfig): RedirectResponse
        {
            Gate::authorize('prime.global-master.app-config.update');

            DB::transaction(function () use ($request, $appConfig) {
                $appConfig->update(['value' => $request->validated()['value']]);

                activityLog($appConfig, 'Edited', ['message' => 'An application setting value was updated.']);
            });

            return redirect()->to($this->backToTab())->with('success', flash('updated.app_config'));
        }
    ```
  - **Verify:** `grep -n "AppConfigController::updateValue failed" Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php`
  - **Expect:** no output — and `grep -c "DB::transaction" Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php` shows 4 (`store`, `update`, `updateValue`, `toggleStatus`).
  - **Effort:** S

- [x] **AFC-02** · H · ERR-06/D1 + TXN-01 · `AppConfigController.php:128-153` — `toggleStatus()`: drop the try/catch including the `ValidationException` rethrow (AFC-01) and wrap the write + activityLog in one transaction (AFC-02); the shared status-switch JS already snaps the checkbox back on a jQuery `error:` response.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php`
  - **Before** (`AppConfigController.php:128-153`):
    ```php
        public function toggleStatus(Request $request, AppConfig $appConfig)
        {
            Gate::authorize('prime.global-master.app-config.update');

            try {
                // The posted value, not a negation of what is in the database: two quick
                // clicks would otherwise resolve against a stale read and leave the row in
                // the opposite state to the control.
                $validated = $request->validate(['is_active' => 'required|boolean']);

                $appConfig->update(['is_active' => (bool) $validated['is_active']]);

                activityLog($appConfig, 'Toggled', [
                    'message' => 'Application setting status was toggled.',
                    'is_active' => $appConfig->is_active,
                ]);

                return $this->toggleResponse($request, true, $appConfig->is_active, flash('status_updated.app_config'));
            } catch (ValidationException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('AppConfigController::toggleStatus failed', ['error' => $e->getMessage()]);

                return $this->toggleResponse($request, false, $appConfig->is_active, flash('status_switch_failed.app_config'));
            }
        }
    ```
  - **After:**
    ```php
        public function toggleStatus(Request $request, AppConfig $appConfig)
        {
            Gate::authorize('prime.global-master.app-config.update');

            DB::transaction(function () use ($request, $appConfig) {
                // The posted value, not a negation of what is in the database: two quick
                // clicks would otherwise resolve against a stale read and leave the row in
                // the opposite state to the control.
                $validated = $request->validate(['is_active' => 'required|boolean']);

                $appConfig->update(['is_active' => (bool) $validated['is_active']]);

                activityLog($appConfig, 'Toggled', [
                    'message' => 'Application setting status was toggled.',
                    'is_active' => $appConfig->is_active,
                ]);
            });

            return $this->toggleResponse($request, true, (bool) $appConfig->is_active, flash('status_updated.app_config'));
        }
    ```
  - **Verify:** `grep -n "AppConfigController::toggleStatus failed\|catch (" Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php`
  - **Expect:** no output (catch gone; `DB::transaction` count is 4).
  - **Effort:** S

## 4. Authorization (F3)

None — every method already authorizes with the correct 4-part name declared in `config/permissionslist.php` and seeded.

## 5. Validation, routes, models (F4/F5/F7)

- [x] **AFC-04** · M · VAL-07 · `AppConfigRequest.php:95` — range-check the TIME value so `25:99` is rejected.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php`
  - **Before** (`AppConfigRequest.php:94-96`):
    ```php
                'DATE' => ! preg_match('/^\d{4}-\d{2}-\d{2}$/', $value),
                'TIME' => ! preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $value),
                'DATETIME' => strtotime($value) === false,
    ```
  - **After:**
    ```php
                'DATE' => ! preg_match('/^\d{4}-\d{2}-\d{2}$/', $value),
                // AFC-04 2026-10-12: format AND range — the old regex accepted 25:99,
                // which Carbon::parse rejects in consumers of the value.
                'TIME' => ! preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/', $value),
                'DATETIME' => strtotime($value) === false,
    ```
  - **Verify:** `grep -n "2\[0-3\]" Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php`
  - **Expect:** 1 hit (the new TIME regex).
  - **Effort:** S

## 6. Queries & performance (F9)

None.

## 7. Views (F10)

None — the pane is the Settings controller's view and was clean on the spot-check.

## 8. Style (F12) — one item per file

- [x] **AFC-05** · L · CTL-04 · `AppConfigController.php` — complete the return types: `destroy(): never`, `toggleStatus(): RedirectResponse|JsonResponse`, `toggleResponse(): RedirectResponse|JsonResponse` (add the `JsonResponse` import).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php`
  - **Before — import block, after item 1 of §3 has run** (current file, line 9):
    ```php
    use Illuminate\Http\RedirectResponse;
    ```
  - **After — import block:**
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    ```
  - **Before** (`AppConfigController.php:117-120`, `:128`, `:159`):
    ```php
        public function destroy(AppConfig $appConfig)
        {
            abort(403, 'App settings cannot be deleted. Deactivate the setting instead.');
        }
    ```
    ```php
        public function toggleStatus(Request $request, AppConfig $appConfig)
    ```
    ```php
        private function toggleResponse(Request $request, bool $ok, bool $isActive, string $message)
    ```
  - **After:**
    ```php
        public function destroy(AppConfig $appConfig): never
        {
            abort(403, 'App settings cannot be deleted. Deactivate the setting instead.');
        }
    ```
    ```php
        public function toggleStatus(Request $request, AppConfig $appConfig): RedirectResponse|JsonResponse
    ```
    ```php
        private function toggleResponse(Request $request, bool $ok, bool $isActive, string $message): RedirectResponse|JsonResponse
    ```
  - **Verify:** `grep -n ": never\|RedirectResponse|JsonResponse\|use Illuminate\\Http\\JsonResponse" Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php`
  - **Expect:** 4 hits (the import plus `destroy`, `toggleStatus`, `toggleResponse`).
  - **Effort:** S

- [x] **AFC-06** · L · STY-01 · `AppConfig.php:1-3` — add `declare(strict_types=1);` (matches the controller and request).
  - **Touches:** `Modules/GlobalMaster/app/Models/AppConfig.php`
  - **Before** (`AppConfig.php:1-4`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Models;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/GlobalMaster/app/Models/AppConfig.php`
  - **Expect:** 1 hit.
  - **Effort:** S

- [x] **AFC-07** · L · STY-04 · remove the emoji markers from two comments.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php`, `Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php`
  - **Before** (`AppConfigController.php:105-107`):
    ```php
        /**
         * ⛔ UNROUTED BY DECISION (2026-08-31) — there is no delete route for these settings.
         *
    ```
  - **After:**
    ```php
        /**
         * UNROUTED BY DECISION (2026-08-31) — there is no delete route for these settings.
         *
    ```
  - **Before** (`AppConfigRequest.php:19`):
    ```php
        // ⚠ updateValue() edits ONE column inline. Validating the full row there would
    ```
  - **After:**
    ```php
        // updateValue() edits ONE column inline. Validating the full row there would
    ```
  - **Verify:** `grep -nP '[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}\x{23CE}\x{2B00}-\x{2BFF}]' Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

None — this plan has no DECISION items (no migration, no new permission key, no `glb_menus` edit, no route change, no split).

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| AFC-08 | MDL-09 (L) — introducing a `ValueType` PHP enum/constants for the seven `value_type` literals is a refactor touching the migration-facing enum, the request and the model. Opportunistic; deferred out of this pass (accepted). |