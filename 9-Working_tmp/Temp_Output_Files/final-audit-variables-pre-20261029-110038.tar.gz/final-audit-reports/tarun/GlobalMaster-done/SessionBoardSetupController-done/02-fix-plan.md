# Fix Plan — GlobalMaster / SessionBoardSetupController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php` | route file — no `session-board-setup` resource is registered here; adding a route is out of scope for this pass (D3, fix in place) |
| `Modules/Prime/routes/web.php` | the live route file — the `session-board-setup` resource there belongs to the Prime controller and must stay |
| `Modules/Prime/app/Http/Controllers/SessionBoardSetupController.php` | the LIVE controller — different controller, owned by a later Prime-module audit |
| `Modules/Prime/resources/views/session-board-setup/index.blade.php` | the LIVE view — different controller's scope |
| `Modules/GlobalMaster/resources/views/session-board-setup/index.blade.php` | only touched if the SBS-02 deletion option (a) is ticked; no other item edits it |
| `config/permissionslist.php` | shared permission source; no new key is proposed here |
| `app/Services/Breadcrumbs/*` and `database/seeders/*` | menu/breadcrumb cleanup is a module-wide decision, not this controller's edit |

## 1. Blockers reachable today

None — the controller is unrouted, so nothing here is reachable from the browser.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — F1 and F2 are clean.

## 4. Authorization (F3)

None as a plan item. The one gate defect (SBS-05) is moot while the screen is dead; see §10.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **SBS-01** · M · RTE-03 · `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:16-64` — disable all seven unrouted methods with the D5 `abort(403)` and type them `: never`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php`
  - **Before** (`SessionBoardSetupController.php:16-64`):
    ```php
    public function index()
    {
        Gate::any([
            'prime.global-master.board.viewAny',
        ]) || abort(403);

        $academicSessions = AcademicSession::paginate(10);
        $boards = Board::paginate(10);
        return view('globalmaster::session-board-setup.index',compact('academicSessions','boards'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('globalmaster::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {}

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('globalmaster::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('globalmaster::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id) {}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {}
    ```
  - **After:**
    ```php
    public function index(): never
    {
        // NOT ROUTED 2026-10-12 — no session-board-setup route is registered in Modules/GlobalMaster/routes/web.php; the live screen is Modules\Prime\Http\Controllers\SessionBoardSetupController (Modules/Prime/routes/web.php:136).
        abort(403, 'This endpoint is not available.');
    }

    public function create(): never
    {
        // NOT ROUTED 2026-10-12 — no session-board-setup route is registered in Modules/GlobalMaster/routes/web.php; the live screen is Modules\Prime\Http\Controllers\SessionBoardSetupController (Modules/Prime/routes/web.php:136).
        abort(403, 'This endpoint is not available.');
    }

    public function store(Request $request): never
    {
        // NOT ROUTED 2026-10-12 — no session-board-setup route is registered in Modules/GlobalMaster/routes/web.php; the live screen is Modules\Prime\Http\Controllers\SessionBoardSetupController (Modules/Prime/routes/web.php:136).
        abort(403, 'This endpoint is not available.');
    }

    public function show($id): never
    {
        // NOT ROUTED 2026-10-12 — no session-board-setup route is registered in Modules/GlobalMaster/routes/web.php; the live screen is Modules\Prime\Http\Controllers\SessionBoardSetupController (Modules/Prime/routes/web.php:136).
        abort(403, 'This endpoint is not available.');
    }

    public function edit($id): never
    {
        // NOT ROUTED 2026-10-12 — no session-board-setup route is registered in Modules/GlobalMaster/routes/web.php; the live screen is Modules\Prime\Http\Controllers\SessionBoardSetupController (Modules/Prime/routes/web.php:136).
        abort(403, 'This endpoint is not available.');
    }

    public function update(Request $request, $id): never
    {
        // NOT ROUTED 2026-10-12 — no session-board-setup route is registered in Modules/GlobalMaster/routes/web.php; the live screen is Modules\Prime\Http\Controllers\SessionBoardSetupController (Modules/Prime/routes/web.php:136).
        abort(403, 'This endpoint is not available.');
    }

    public function destroy($id): never
    {
        // NOT ROUTED 2026-10-12 — no session-board-setup route is registered in Modules/GlobalMaster/routes/web.php; the live screen is Modules\Prime\Http\Controllers\SessionBoardSetupController (Modules/Prime/routes/web.php:136).
        abort(403, 'This endpoint is not available.');
    }
    ```
  - **Verify:** `grep -c "NOT ROUTED" Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php`
  - **Expect:** `7`
  - **Effort:** S

## 6. Queries & performance (F9)

None — the only query finding (SBS-03) is in the dead `index()` and is moot while the screen is dead; see §10.

## 7. Views (F10)

None as a plan item. SBS-04 and SBS-07 are recorded in §10 with the reason they are not fixed here.

## 8. Style (F12) — one item per file

- [ ] **SBS-06** · L · STY-01 · `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:1-9` — add `declare(strict_types=1)`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php`
  - **Before** (`SessionBoardSetupController.php:1-9`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\Prime\Models\AcademicSession;
    use Modules\GlobalMaster\Models\Board;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\Prime\Models\AcademicSession;
    use Modules\GlobalMaster\Models\Board;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php`
  - **Expect:** one hit at line 3.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **SBS-02** · M · DECISION · CTL-10 — the whole controller is a dead duplicate of the live Prime session-board-setup screen. Delete it, or keep it D5-disabled?
  - **Why it is a decision:** it removes a file (and its view). The protocol's default (D5) is to never delete — only Tarun may choose deletion.
  - (a) ⭐ delete `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php` and `Modules/GlobalMaster/resources/views/session-board-setup/index.blade.php`. The live screen is unaffected (the Prime controller and its view own every route and the menu entry). This makes SBS-01's D5 item and the moot view/query findings moot. The shared `globalmaster::create` / `globalmaster::show` / `globalmaster::edit` placeholders are NOT touched, and no breadcrumb entry exists for this class to clean up.
  - (b) keep the file but apply SBS-01 and SBS-06 only (self-documenting dead code, no deletion). The view stays as-is.
  - (c) leave everything as is and record it as accepted technical debt.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| SBS-03 | Two paginators on one page share the default page name (`AcademicSession::paginate(10)` / `Board::paginate(10)`). The only renderer is the dead `index()`; SBS-01 (D5-disable) or SBS-02(a) (delete) makes it unreachable. Fix it (distinct page names, as the live Prime controller uses) only if the screen is revived. |
| SBS-04 | The view's search and status controls submit filters `index()` never reads. Same reason as SBS-03 — the screen is dead; fix on revival, or delete with SBS-02(a). |
| SBS-05 | The controller gates the two-tab page on `prime.global-master.board.viewAny` while the session tab needs `prime.prime.academic-session.viewAny`. Same reason as SBS-03 — no route reaches the gate; fix on revival (use `prime.prime.session-board-setup.viewAny`), or delete with SBS-02(a). |
| SBS-07 | The Academic Board tab declares `id="academicboard-pane"` twice and leaves one `div` unclosed (`grep -o '<div'` = 8 vs `grep -o '</div>'` = 7). Same reason as SBS-03 — the view is dead; fix on revival, or delete with SBS-02(a). |
