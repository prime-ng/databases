# Final Audit — GlobalMaster / SessionBoardSetupController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php` (65 lines, 7 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | **none.** An uncached route list resolves zero routes to `Modules\GlobalMaster\...\SessionBoardSetupController@*`. The live `/prime/session-board-setup` screen is served by a different class, `Modules\Prime\Http\Controllers\SessionBoardSetupController`, under route names `central.prime.session-board-setup.*`. |
| Menu path | none — there is no route, so no menu entry can reach this copy. The menu seeder (`Modules/Prime/database/seeders/MenuSeeder.php:148`) points at `central.prime.session-board-setup.index`, the **Prime** route. |
| Who uses it | nobody. The live screen is used by super-admin roles holding `prime.prime.session-board-setup.viewAny` (seeded; the Prime policy checks it at `Modules/Prime/app/Policies/SessionBoardSetupPolicy.php:15`). |
| What a user does here | On the live screen an admin reads two tabs — Academic Session and Academic Board — that aggregate rows owned by other resources (Academic Sessions, Boards). On **this** copy nothing runs: it is an unrouted duplicate of the live Prime controller. |
| Tables written | none. No method in this controller writes anything. |
| Tables read | `glb_academic_sessions` and `glb_boards` — only inside the unrouted `index()` body. |
| Live data | `glb_academic_sessions` — **10 rows** live; `glb_boards` — **10 rows** live. Both models use `SoftDeletes`, so both also have a trashed set. |

**How to reach each bug in the browser:** you cannot. There is no route to this controller.
Every finding below is a latent defect that would become live only if a route were added.

## 1. Verdict

This controller is **not production code — it is a dead duplicate**. Its route was never registered in
`Modules/GlobalMaster/routes/web.php`; every `session-board-setup` route is owned by
`Modules\Prime\Http\Controllers\SessionBoardSetupController` (`Modules/Prime/routes/web.php:136`), and
the menu points there too. The class was left behind, so all seven public methods answer no URL and none
carries the D5 `abort(403)` guard. The single worst finding is that **all seven methods are unrouted with
live bodies** (SBS-01): anyone who copies the Prime route block back into this file silently arms a
half-working screen whose `create`/`show`/`edit` views (`globalmaster::create` / `globalmaster::show` /
`globalmaster::edit`) do not exist and whose `store`/`update`/`destroy` return an empty 200 while writing
nothing. Effort is small (S): mechanically D5-disable the seven methods and add strict types. Nothing here
executes today, so there is no blocker for go-live.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 5 | 2 | 1 | 7 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | SBS-03 |
| F3 Authorization | SBS-05 | F10 Views | SBS-04, SBS-07 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | SBS-01 | F12 Style | SBS-06 |
| F6 Controller shape | SBS-02 (and CTL-04 closed inside SBS-01) | F13 Deep read | SBS-04 (see table) |
| F7 Models | clean (linked) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php` | controller | 65 | this report | ✅ |
| 2 | `Modules/GlobalMaster/resources/views/session-board-setup/index.blade.php` | view | 162 | this report | ✅ |
| 3 | `Modules/GlobalMaster/app/Models/Board.php` | model (shared) | 37 | ↗ [tarun/GlobalMaster-done/BoardController](../BoardController-done/01-report.md) | ↗ linked |
| 4 | `Modules/Prime/app/Models/AcademicSession.php` | model (shared) | 103 | ↗ [tarun/GlobalMaster-done/AcademicSessionController](../AcademicSessionController-done/01-report.md) | ↗ linked |

Common, not claimed: `App\Http\Controllers\Controller`, `Illuminate\Http\Request`,
`Illuminate\Support\Facades\Gate`, and the shared `x-backend.*` / `x-prime.*` components the view uses.

Rendered-but-missing views (shared placeholder names used by several GlobalMaster controllers,
proved absent with `view()->exists()`): `globalmaster::create`, `globalmaster::show`, `globalmaster::edit`
— cross-cutting note, not owned here.

Models are linked, not re-audited: `Board.php` is owned by the BoardController report and
`AcademicSession.php` by the AcademicSessionController report (both claimed in `00-CLASS-OWNERS.md`).
This report checked only **how this controller uses them** (scope row 3 and 4): `index()` calls
`AcademicSession::paginate(10)` and `Board::paginate(10)`, which is correct usage apart from the
colliding page names recorded as SBS-03.

No pre-applied files.

## 4. Routes

The uncached route list (`/tmp/fa-routes.json`) resolves **zero** routes to this controller:

```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); $n=0;
          foreach($r as $x){ if(str_contains($x["action"]??"","Modules\\GlobalMaster\\Http\\Controllers\\SessionBoardSetupController")) $n++; }
          echo "GM-COUNT=$n\n";'
GM-COUNT=0
```

Every `session-board-setup` route that answers is owned by the **Prime** controller:

```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true);
          foreach($r as $x){ if(str_contains($x["uri"],"session-board-setup")) printf("%-10s %-52s %-46s %s\n",$x["method"],$x["uri"],$x["name"]??"-",$x["action"]); }'
GET|HEAD   prime/session-board-setup                               central.prime.session-board-setup.index            Modules\Prime\Http\Controllers\SessionBoardSetupController@index
POST       prime/session-board-setup                               central.prime.session-board-setup.store            Modules\Prime\Http\Controllers\SessionBoardSetupController@store
GET|HEAD   prime/session-board-setup/create                        central.prime.session-board-setup.create           Modules\Prime\Http\Controllers\SessionBoardSetupController@create
GET|HEAD   prime/session-board-setup/{session_board_setup}         central.prime.session-board-setup.show             Modules\Prime\Http\Controllers\SessionBoardSetupController@show
PUT|PATCH  prime/session-board-setup/{session_board_setup}         central.prime.session-board-setup.update           Modules\Prime\Http\Controllers\SessionBoardSetupController@update
DELETE     prime/session-board-setup/{session_board_setup}         central.prime.session-board-setup.destroy          Modules\Prime\Http\Controllers\SessionBoardSetupController@destroy
GET|HEAD   prime/session-board-setup/{session_board_setup}/edit    central.prime.session-board-setup.edit             Modules\Prime\Http\Controllers\SessionBoardSetupController@edit
```

Unrouted public methods: **all seven** — `index` (line 16), `create` (30), `store` (38), `show` (43),
`edit` (51), `update` (59), `destroy` (64). None carries the D5 `abort(403)` guard.

The only reference to this class in the codebase is an architecture test that merely lists its FQCN:

```
$ grep -rn "GlobalMaster\\\\Http\\\\Controllers\\\\SessionBoardSetupController" Modules/ routes/ app/
Modules/GlobalMaster/tests/Unit/ArchitectureTest.php:29:        'SessionBoardSetupController' => \Modules\GlobalMaster\Http\Controllers\SessionBoardSetupController::class,
```

The route file never imports the class (it imports every sibling GlobalMaster controller but not this
one), and the router directive in `routes/tenant.php:36` is a comment:
`// GlobalMaster SessionBoardSetupController → Modules/GlobalMaster/routes/web.php`.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 16 | — (unrouted) | `prime.global-master.board.viewAny` via `Gate::any` | none (read) | — | none | SBS-01, SBS-03, SBS-04, SBS-05 |
| `create` | 30 | — (unrouted) | none | none (read) | — | none | SBS-01, SBS-02 |
| `store` | 38 | — (unrouted) | none | none | — | none | SBS-01 |
| `show` | 43 | — (unrouted) | none | none (read) | — | none | SBS-01 |
| `edit` | 51 | — (unrouted) | none | none (read) | — | none | SBS-01 |
| `update` | 59 | — (unrouted) | none | none | — | none | SBS-01 |
| `destroy` | 64 | — (unrouted) | none | none | — | none | SBS-01 |

No routed method exists, so no authorization obligation is live. The one gate string that exists is
declared in `config/permissionslist.php` (exact-name check in F3).

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try ?\{|catch ?\(|getMessage|withErrors|with\(.error|back\(\)|json\(' Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php` → no output. The controller has no `try`, no catch, no `withErrors`/`back()`/`json()` and no write path that can fail. There is nothing here to leak.

### F2 — Transactions and audit

clean — `grep -nE 'DB::|transaction|activityLog' Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php` → no output. The only method with a body is `index()`, a read. `store`, `update` and `destroy` are empty, so there is no multi-table write and no audit row to place.

### F3 — Authorization

The one gate string is declared in `config/permissionslist.php`. Verified with an exact-name flatten
(the scope prefix is prepended by `PermissionHelper::flatten()`, so the key `global-master.board` under
the `prime` scope yields `prime.global-master.board.*`):

```
$ php artisan tinker --execute '$c=config("permissionslist"); $flat=[];
  foreach($c as $scope=>$keys){ foreach($keys as $k=>$v){ foreach($v as $a){ $flat[]="$scope.$k.$a"; } } }
  foreach(["prime.global-master.board.viewAny","prime.prime.academic-session.viewAny","prime.prime.session-board-setup.viewAny"] as $needle){
    $hit=array_values(array_filter($flat, fn($f)=>$f===$needle)); echo $needle." => ".(count($hit)?"EXISTS":"MISSING")."\n"; }'
prime.global-master.board.viewAny => EXISTS
prime.prime.academic-session.viewAny => EXISTS
prime.prime.session-board-setup.viewAny => EXISTS
```

There is no live routed method, so AUTH-01 has no live obligation. The one defect is that the single
gate on `index()` is the wrong permission for the two-tab page it guards — recorded as SBS-05.

#### SBS-05 · M · AUTH-06 — the page is gated on the board permission, so a user who holds only the academic-session permission is refused

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *a permission name must appear identically on all four surfaces (controller, FormRequest, view, config); a gate that names one surface's permission removes access another surface grants* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:18-20`, method `index()`; against `Modules/GlobalMaster/resources/views/session-board-setup/index.blade.php:9-10,14,84` |
| **Root cause** | `index()` admits the user only when they hold `prime.global-master.board.viewAny`. The page it guards is a two-tab aggregate: the first tab is wrapped in `@can('prime.prime.academic-session.viewAny')`. The controller's single gate is therefore narrower than the page it guards, and the feature's own permission `prime.prime.session-board-setup.viewAny` (used by the live Prime controller and its policy) is never consulted here. |
| **Consequence** | If a route were added, a super-admin holding `prime.prime.academic-session.viewAny` but not `prime.global-master.board.viewAny` would be refused the whole page (403) and could never reach the session tab they are entitled to. |
| **Reproduce** | static only — the controller is unrouted (`route:list` GM-COUNT=0), so the gate cannot be exercised in the browser. |
| **Fix approach** | If the screen is revived, gate on `prime.prime.session-board-setup.viewAny` to match the live controller and the seeded permission; otherwise leave it with the D5 disable (plan SBS-02). |
| **Plan item** | none — see `02-fix-plan.md` §10 (moot while the screen is unrouted) |

```php
// SessionBoardSetupController.php:18-20 — CURRENT
        Gate::any([
            'prime.global-master.board.viewAny',
        ]) || abort(403);
```

**Evidence**
```
$ grep -n "prime.global-master.board.viewAny" Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php
19:            'prime.global-master.board.viewAny',
$ grep -n "@can\|permission.*=>" Modules/GlobalMaster/resources/views/session-board-setup/index.blade.php
9:                ['id' => 'academicsession', 'label' => 'Academic Session', 'icon' => 'fa-solid fa-city', 'permission' => 'prime.prime.academic-session.viewAny'],
10:                ['id' => 'academicboard', 'label' => 'Academic Board', 'icon' => 'fa-solid fa-city', 'permission' => 'prime.global-master.board.viewAny'],
14:            @can('prime.prime.academic-session.viewAny')
84:            @can('prime.global-master.board.viewAny')
```

### F4 — Validation and input

clean — `grep -nE 'request\(\)->all|->all\(\)|->except\(|->fill\(|validated\(|validate\(|request\(\)' Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php` → no output. The controller reads no request input at all: `store` and `update` accept a `Request` and never touch it.

### F5 — Routes

#### SBS-01 · M · RTE-03 — all seven public methods are unrouted and still carry live bodies instead of the D5 abort

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M, D5) — *every public controller method is routed, or is deliberately disabled with `abort(403)` and a `NOT ROUTED` comment* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:16-64`, methods `index()`, `create()`, `store()`, `show()`, `edit()`, `update()`, `destroy()` |
| **Root cause** | No `session-board-setup` resource is registered in `Modules/GlobalMaster/routes/web.php`; the live routes are declared in `Modules/Prime/routes/web.php:136` against the Prime controller. The GlobalMaster class was left intact, so every method body is dead but looks callable. Sibling dead controllers in this module follow D5; this file was never converted. |
| **Consequence** | Nothing runs today, but the file is a loaded trap: copy the Prime route block back and `create`/`show`/`edit` 500 on missing views, `store`/`update`/`destroy` return an empty 200 that writes nothing (a success-shaped no-op), and `index` gates the page on the wrong permission (SBS-05). |
| **Reproduce** | static only — `route:list` proves GM-COUNT=0 for this controller. |
| **Fix approach** | Replace each of the seven bodies with the D5 pattern (`abort(403, 'This endpoint is not available.')` plus a `// NOT ROUTED` comment) and type each method `: never`, closing CTL-04. The plan's After block is paste-ready. |
| **Plan item** | SBS-01 in `02-fix-plan.md` §5 |

```php
// SessionBoardSetupController.php:16-64 — CURRENT
    public function index()
    {
        Gate::any([
            'prime.global-master.board.viewAny',
        ]) || abort(403);

        $academicSessions = AcademicSession::paginate(10);
        $boards = Board::paginate(10);
        return view('globalmaster::session-board-setup.index',compact('academicSessions','boards'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('globalmaster::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {}

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('globalmaster::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('globalmaster::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id) {}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {}
```

**Evidence**
```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); $n=0;
          foreach($r as $x){ if(str_contains($x["action"]??"","Modules\\GlobalMaster\\Http\\Controllers\\SessionBoardSetupController")) $n++; }
          echo "GM-COUNT=$n\n";'
GM-COUNT=0
$ grep -nE 'public function [a-zA-Z_]+' Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php
16:    public function index()
30:    public function create()
38:    public function store(Request $request) {}
43:    public function show($id)
51:    public function edit($id)
59:    public function update(Request $request, $id) {}
64:    public function destroy($id) {}
```

### F6 — Controller shape

#### SBS-02 · M · CTL-10 — the whole controller is a dead duplicate of the live Prime session-board-setup screen

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code; a file whose entire behaviour duplicates another class is dead weight* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:11-12`, the whole class (65 lines) |
| **Root cause** | The feature this file implements is a copy of `Modules\Prime\Http\Controllers\SessionBoardSetupController`, which owns every `central.prime.session-board-setup.*` route. This GlobalMaster copy is registered in no route file (see §4); only its dead `index` renders `globalmaster::session-board-setup.index`. |
| **Consequence** | Every line is dead weight that will drift from the live controller and mislead the next developer who greps for "SessionBoardSetupController". Its three form methods also point at views that do not exist. |
| **Reproduce** | `route:list` GM-COUNT=0 (§4); the only grep hit for the FQCN outside the class itself is the architecture test. |
| **Fix approach** | **Decision item** — delete the controller with its view, or keep the file D5-disabled (self-documenting dead code). See plan SBS-02. |
| **Plan item** | SBS-02 in `02-fix-plan.md` §9 (DECISION) |

```php
// SessionBoardSetupController.php:11-12 — CURRENT
class SessionBoardSetupController extends Controller
{
```

**Evidence**
```
$ grep -rn "SessionBoardSetupController" Modules/GlobalMaster/tests/Unit/ArchitectureTest.php
29:        'SessionBoardSetupController' => \Modules\GlobalMaster\Http\Controllers\SessionBoardSetupController::class,
$ php artisan tinker --execute 'foreach(["globalmaster::create","globalmaster::show","globalmaster::edit","globalmaster::session-board-setup.index"] as $v) printf("%-42s %s\n",$v, view()->exists($v)?"EXISTS":"MISSING");'
globalmaster::create                       MISSING
globalmaster::show                         MISSING
globalmaster::edit                         MISSING
globalmaster::session-board-setup.index    EXISTS
```

### F7 — Models

The two in-scope models are audited in their owner reports and only usage-checked here:

- `Modules/GlobalMaster/app/Models/Board.php` — ↗ owned by
  [tarun/GlobalMaster-done/BoardController](../BoardController-done/01-report.md).
- `Modules/Prime/app/Models/AcademicSession.php` — ↗ owned by
  [tarun/GlobalMaster-done/AcademicSessionController](../AcademicSessionController-done/01-report.md).

Usage in this controller is correct. `Board` declares `protected $table = 'glb_boards'` and
`protected $casts = ['is_active' => 'boolean']`; `AcademicSession` declares
`protected $table = 'glb_academic_sessions'`. `index()` calls `AcademicSession::paginate(10)` and
`Board::paginate(10)` with no filter and no relation dereference, so there is no MDL defect to record
here. No MDL finding.

### F8 — Services and jobs

clean — `grep -nE 'Service|Job|Event|Mail|Notification|dispatch\(' Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php` → no output. The controller names no service, job, event, mail or notification.

### F9 — Queries and performance

The read path (`index`) paginates at 10 for both lists, orders nothing ambiguously, and uses no raw
SQL or loop queries. One query defect remains: the two paginators on one page share the default page
name, so paging one tab resets the other.

#### SBS-03 · M · QRY-13 — two paginators on one page share the default page name, so paging one tab resets the other

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L default, raised to M — the two colliding paginators are a functional defect, not style) — *multiple paginators on one page use distinct page names* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:22-23`, method `index()` |
| **Root cause** | `index()` runs `AcademicSession::paginate(10)` and `Board::paginate(10)` with no third argument, so both read and write the same `page` query-string key. The page renders both lists with `$academicSessions->links()` and `$boards->links()`. |
| **Consequence** | If the screen were routed, clicking Next on the Academic Board tab would also move the Academic Session tab back to page 1 (and vice versa) — the two independently paginated lists interfere. |
| **Reproduce** | static only — the controller is unrouted; `grep` shows both `paginate(10)` calls take the default page name. |
| **Fix approach** | Give each paginator its own page name (`paginate(10, ['*'], 'session_page')` and `paginate(10, ['*'], 'board_page')`) and pass them to `links()`. The live Prime controller does exactly this (its names are `academicsession_page` / `academicboard_page`). Fix only if the screen is revived. |
| **Plan item** | none — see `02-fix-plan.md` §10 (moot while the screen is unrouted) |

```php
// SessionBoardSetupController.php:22-23 — CURRENT
        $academicSessions = AcademicSession::paginate(10);
        $boards = Board::paginate(10);
```

**Evidence**
```
$ grep -n "paginate(" Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php
22:        $academicSessions = AcademicSession::paginate(10);
23:        $boards = Board::paginate(10);
$ grep -n "paginate(\|pageName\|_page" Modules/Prime/app/Http/Controllers/SessionBoardSetupController.php
35:            ->paginate(10, ['*'], 'academicsession_page')
55:            ->paginate(10, ['*'], 'academicboard_page')
```

### F10 — Views

The in-scope view `globalmaster::session-board-setup.index` compiles cleanly (verified with
`Blade::compileString` + `php -l` → "No syntax errors detected"; `@can`/`@endcan` balanced at 2 each).
It contains no `{!! !!}` raw output and no model/DB query, so VIEW-01 and VIEW-03 are satisfied.
Two view defects remain: the ignored search/status controls (SBS-04) and the duplicated/unclosed
Academic Board tab pane (SBS-07).

#### SBS-04 · M · F13 — the rendered search and status controls submit filters the controller never reads

| Field | Value |
|---|---|
| **Rule** | F13 deep-read #8 (M) — *a dead feature: a control whose submitted value no consumer reads* |
| **Where** | `Modules/GlobalMaster/resources/views/session-board-setup/index.blade.php:19-31` (the form) against `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:22-23` (the query) |
| **Root cause** | The view renders a `GET` form with `<input name="search">` and `<select name="status">` in both tabs, but `index()` runs `AcademicSession::paginate(10)` and `Board::paginate(10)` with no reference to `search` or `status` (and takes no `Request`). |
| **Consequence** | A user who types a term or picks a status and submits gets the full unfiltered list back — the control appears to work and silently does nothing. |
| **Reproduce** | static only — the screen is unrouted; `grep` shows the controller never reads `search`, `status` or `request()`. |
| **Fix approach** | If the screen is revived, read the inputs in `index()` and filter each query; otherwise delete the view with the dead screen (plan SBS-02). |
| **Plan item** | none — see `02-fix-plan.md` §10 (moot while the screen is unrouted) |

```php
// index.blade.php:19-31 — CURRENT
                    <form class="d-flex align-items-center flex-grow-1 gap-2 me-3" method="GET">
                        <input type="text" name="search" value="{{ request('search') }}"
                            class="form-control form-control-sm flex-grow-1" placeholder="Search...">
                        <select name="status" class="form-select form-select-sm" style="max-width: 140px;">
                            <option value="">All</option>
                            <option value="1" {{ request('status') == '1' ? 'selected' : '' }}>Active</option>
                            <option value="0" {{ request('status') == '0' ? 'selected' : '' }}>Inactive
                            </option>
                        </select>
                        <button class="btn btn-primary btn-sm" type="submit">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </button>
                    </form>
```

**Evidence**
```
$ grep -nE "request\(\)|'search'|'status'|input\(|filled\(" Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php
(no output — the controller reads no request input)
$ grep -n "name=\"search\"\|name=\"status\"" Modules/GlobalMaster/resources/views/session-board-setup/index.blade.php
20:                        <input type="text" name="search" value="{{ request('search') }}"
22:                        <select name="status" class="form-select form-select-sm" style="max-width: 140px;">
93:                        <input type="text" name="search" value="{{ request('search') }}"
96:                        <select name="status" class="form-select form-select-sm" style="max-width: 140px;">
```

#### SBS-07 · L · F10 — the Academic Board tab declares `id="academicboard-pane"` twice, leaving a div unclosed

| Field | Value |
|---|---|
| **Rule** | F10 (L) — *blade markup standard: one element id per document; every opening tag is closed* |
| **Where** | `Modules/GlobalMaster/resources/views/session-board-setup/index.blade.php:85-89` |
| **Root cause** | The board tab's wrapper `<div ... id="academicboard-pane">` was pasted a second time immediately inside itself (lines 88-89 duplicate 85-86), so the view has 8 `<div` openers but only 7 `</div>` closers — one wrapper is never closed. |
| **Consequence** | If rendered, two nested elements share the same id and the outer tab pane is left open, which the browser auto-closes — the board tab's DOM nests incorrectly, putting layout risk on the tab component. Invisible while the view is unrouted. |
| **Reproduce** | static only — `grep -o '<div'` vs `grep -o '</div>'` on the view (8 vs 7); the screen is unrouted. |
| **Fix approach** | Delete the duplicated lines 88-89 so the board pane has one wrapper. Fix only if the view is revived; otherwise delete with the dead screen (plan SBS-02). |
| **Plan item** | none — see `02-fix-plan.md` §10 (moot while the screen is unrouted) |

```php
// index.blade.php:85-89 — CURRENT
            <div class="tab-pane fade p-4 bg-white rounded shadow-sm" id="academicboard-pane" role="tabpanel"
                aria-labelledby="academicboard-tab" tabindex="0">
                <!--begin::Search bar & Links-->
                <div class="tab-pane fade p-4 bg-white rounded shadow-sm" id="academicboard-pane" role="tabpanel"
                aria-labelledby="academicboard-tab" tabindex="0">
```

**Evidence**
```
$ grep -o '<div' Modules/GlobalMaster/resources/views/session-board-setup/index.blade.php | wc -l
8
$ grep -o '</div>' Modules/GlobalMaster/resources/views/session-board-setup/index.blade.php | wc -l
7
```

### F11 — Security and tenancy

clean — `grep -n 'env(' <controller> <view>` → no output; `{!! !!}` → none (see F10); no hard-coded ids or
`?? 1`; no request data logged. The controller reads two central (`glb_`) tables through their models'
own connections, which is correct for a central screen.

### F12 — Style

Scanner hits: `STY-01` missing `declare(strict_types=1)` on the controller, and `CTL-04` missing return
types on `index`, `create`, `show`, `edit` (the empty `store`/`update`/`destroy` one-liners were not
flagged). CTL-04 is closed by SBS-01's After (the typed `: never` bodies); STY-01 is the one style item,
SBS-06. No debug leftovers, no commented-out code longer than three lines; both imports (`Request`,
`Gate`) are used.

#### SBS-06 · L · STY-01 — the controller has no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` on files you touch* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:1-9` |
| **Root cause** | The file opens with `<?php` and no `declare(strict_types=1);` line. |
| **Consequence** | Convention drift only; scalar coercion stays loose. Invisible at runtime. |
| **Reproduce** | scanner (evidence below). |
| **Fix approach** | Insert `declare(strict_types=1);` after the opening tag. See plan SBS-06. |
| **Plan item** | SBS-06 in `02-fix-plan.md` §8 |

```php
// SessionBoardSetupController.php:1-9 — CURRENT
<?php

namespace Modules\GlobalMaster\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Modules\Prime\Models\AcademicSession;
use Modules\GlobalMaster\Models\Board;
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php
L  STY-01   Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:1  - — missing declare(strict_types=1)
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:16  index — index() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:30  create — create() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:43  show — show() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/SessionBoardSetupController.php:51  edit — edit() has no return type
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There is no reachable mutating method — `store`, `update` and `destroy` are unrouted and empty. The
table records the deep-read verdict per method:

| Method | 1 wrong data | 2 delete-before-store | 3 dup impls | 4 soft-delete×unique | 5 race | 6 auth hole | 7 lying msg | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `index` (read) | ok | ok | SBS-02 | ok | ok | SBS-05 | ok | SBS-04 |
| `create` | ok | ok | SBS-02 | ok | ok | ok | ok | SBS-02 |
| `store` | ok | ok | SBS-02 | ok | ok | ok | ok | SBS-02 |
| `show` | ok | ok | SBS-02 | ok | ok | ok | ok | SBS-02 |
| `edit` | ok | ok | SBS-02 | ok | ok | ok | ok | SBS-02 |
| `update` | ok | ok | SBS-02 | ok | ok | ok | ok | SBS-02 |
| `destroy` | ok | ok | SBS-02 | ok | ok | ok | ok | SBS-02 |

Question 3 (duplicate implementations) returns "yes" at the file level: this controller duplicates the
live Prime `SessionBoardSetupController` (SBS-02). Question 6 yields the wrong page gate (SBS-05).
Question 8 yields the ignored search/status controls (SBS-04). Questions 1, 2, 4 and 5 are "ok" because
nothing here ever writes.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `globalmaster::create` / `globalmaster::show` / `globalmaster::edit` | The three view names this controller's dead `create`/`show`/`edit` render do not exist anywhere (`view()->exists()` → MISSING). They are shared placeholder names used by several GlobalMaster controllers, so they are not owned here. | RTE-02 | GlobalMaster module pass / whoever revives those screens |
| `Modules\Prime\Http\Controllers\SessionBoardSetupController` | The live screen this file duplicates. Its `index()` gates on `prime.prime.session-board-setup.viewAny` and passes distinct page names — the behaviour the GlobalMaster copy should have had. Audited by a later Prime-module audit, not here. | — | Prime module audit |
| `Modules/GlobalMaster/routes/web.php` | This file imports every sibling GlobalMaster controller except `SessionBoardSetupController`; the only trace is a comment in `routes/tenant.php:36`. No route is registered for this class. | RTE-03 | GlobalMaster module pass |

## 8. Not covered, and why

- The **live** `Modules\Prime\Http\Controllers\SessionBoardSetupController` and its
  `Modules/Prime/resources/views/session-board-setup/index.blade.php` are another controller's scope;
  not audited here (a later Prime-module audit owns them).
- The shared components `x-backend.tab.nav-tab`, `x-backend.tab.search-bar`,
  `x-backend.table.action`, `x-prime.table.action` and `x-backend.table.status-switch` are COMMON; only
  their usage in the view was read, not their implementations.
- No browser rendering was possible: this controller has no route (D4 — no tests; §10 verification
  only). The view was compiled with `Blade::compileString` and linted instead.
