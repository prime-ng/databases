# Final Audit — GlobalMaster / AcademicSessionController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php` (124 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | **none.** `php artisan route:list` resolves zero routes to `Modules\GlobalMaster\...\AcademicSessionController@*`. The academic-session screen that exists in the app is served by `Modules\Prime\Http\Controllers\AcademicSessionController` under `central.prime.academic-session.*` (`/prime/academic-session` and friends). |
| Menu path | none — this controller is not wired to any route, so no menu entry can reach it. The live screen's menu entry is the Prime module's. |
| Who uses it | nobody. Because it is unrouted, no role can ever reach it. The *live* duplicate (Prime module) is used by super-admin roles holding `prime.prime.academic-session.*`. |
| What a user does here | This file is a leftover copy of the Academic Session CRUD (list, create, edit, trash, restore, force-delete, status toggle). On the live screen an admin manages the school years (`glb_academic_sessions`) from the platform side. On **this** copy nothing runs. |
| Tables written | none reachable. `store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus` are all `abort(403)` and unrouted. |
| Tables read | `glb_academic_sessions` (via `Modules\Prime\Models\AcademicSession`, which is on connection `global_master_mysql`) — only inside the unrouted `index`/`edit`/`trashedAcademicSession` bodies. |
| Live data | `glb_academic_sessions` — 10 rows live, 0 trashed. `glb_boards` — 10 rows, 0 trashed. |

**How to reach each bug in the browser:** you cannot. There is no route to this controller. Every finding below is a latent defect that would become live only if a route were added.

## 1. Verdict

This controller is **not production code — it is a dead duplicate**. The same feature lives, fully routed, in `Modules\Prime\Http\Controllers\AcademicSessionController`. Six of this file's eleven public methods have already been disabled with an `abort(403)` + `NOT ROUTED` comment (the D5 pattern), but the other five still carry live bodies (`index`, `create`, `show`, `edit`, `trashedAcademicSession`) that can never be reached. The single worst finding is in the shared model this controller imports: `Modules\Prime\Models\AcademicSession` has **six relationship methods, and all six crash** when called — two import classes that do not exist in that namespace, and four resolve against tables/pivots on a connection or schema that cannot answer. The model itself is used live by the Prime controller and (in a later batch) by `SessionBoardSetupController`, so these relations are a landmine for anyone who adds an eager load. Effort is small (S): the mechanical fixes are D5-disable five methods, repair/remove six dead relations, tighten one FormRequest, and fix one dead blade column. The bigger question — delete this whole dead screen or keep it D5-disabled — is a decision for Tarun.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 6 | 4 | 3 | 12 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | clean |
| F3 Authorization | clean | F10 Views | ACAD-08 |
| F4 Validation | ACAD-04, ACAD-05 | F11 Security/Tenancy | clean |
| F5 Routes | ACAD-01 | F12 Style | ACAD-09,10,11,12 |
| F6 Controller shape | ACAD-06, ACAD-07 | F13 Deep read | see table |
| F7 Models | ACAD-02, ACAD-03 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php` | controller | 124 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php` | FormRequest | 56 | this report | ✅ |
| 3 | `Modules/Prime/app/Models/AcademicSession.php` | model (shared, first reach) | 103 | this report (claimed in `00-CLASS-OWNERS.md`) | ✅ |
| 4 | `Modules/GlobalMaster/resources/views/academic-session/index.blade.php` | view | 60 | this report | ✅ |
| 5 | `Modules/GlobalMaster/resources/views/academic-session/create.blade.php` | view | 66 | this report | ✅ |
| 6 | `Modules/GlobalMaster/resources/views/academic-session/edit.blade.php` | view | 72 | this report | ✅ |
| 7 | `Modules/GlobalMaster/resources/views/academic-session/trash.blade.php` | view | 57 | this report | ✅ |
| 8 | `Modules/GlobalMaster/app/Models/Board.php` | model (reached via `AcademicSession::boards()`) | 37 | ↗ [tarun/GlobalMaster-done/BoardController](../BoardController-done/01-report.md) | ↗ linked (usage-check only) |
| 9 | `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php` | model (related target of `organizationAcademicSessions()`) | — | SchoolSetup module's own audit (not yet run) | usage-check only |

Common, not claimed: `App\Http\Controllers\Controller`, `Illuminate\Support\Facades\Auth`/`Gate`, `Illuminate\Http\Request`, `App\Traits\AuthorizesTenantFeature`, the `activityLog()` sink, shared `x-prime.*` / `x-backend.*` components.

No pre-applied files.

## 4. Routes

The uncached route list (`/tmp/fa-routes.json`) resolves **zero** routes to this controller:

```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); $n=0;
          foreach($r as $x){ if(str_contains($x["action"],"GlobalMaster\\Http\\Controllers\\AcademicSessionController@")){ $n++; printf(...); } }
          echo "COUNT=$n\n";'
COUNT=0
```

All `academic-session` routes belong to `Modules\Prime\Http\Controllers\AcademicSessionController` (verified same command — 11 routes, `central.prime.academic-session.*`). The GlobalMaster routes file (`Modules/GlobalMaster/routes/web.php`) registers no academic-session resource.

Unrouted public methods: **all 11**. Six already carry the D5 abort pattern (`store` :41, `update` :73, `destroy` :83, `restore` :99, `forceDelete` :106, `toggleStatus` :117). Five do **not**:

| Method | Line | Body status |
|---|---|---|
| `index` | 17 | live body (gate + query + view) |
| `create` | 32 | live body (gate + view) |
| `show` | 51 | empty body `//` |
| `edit` | 59 | live body (gate + findOrFail + view) |
| `trashedAcademicSession` | 92 | live body (gate + query + view) |

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | — (unrouted) | `prime.prime.academic-session.viewAny` via `Gate::any` | none (read) | — | none | ACAD-01 |
| `create` | 32 | — (unrouted) | `tenant.global-master.academic-session.create` | none (read) | — | none | ACAD-01 |
| `store` | 41 | — (unrouted) | none (abort) | — | — | none | — |
| `show` | 51 | — (unrouted) | none (empty body) | — | — | none | ACAD-01 |
| `edit` | 59 | — (unrouted) | `tenant.global-master.academic-session.update` | none (read) | — | none | ACAD-01, ACAD-07 |
| `update` | 73 | — (unrouted) | none (abort) | — | — | none | — |
| `destroy` | 83 | — (unrouted) | none (abort) | — | — | none | — |
| `trashedAcademicSession` | 92 | — (unrouted) | `tenant.global-master.academic-session.restore` | none (read) | — | none | ACAD-01 |
| `restore` | 99 | — (unrouted) | none (abort) | — | — | none | — |
| `forceDelete` | 106 | — (unrouted) | none (abort) | — | — | none | — |
| `toggleStatus` | 117 | — (unrouted) | none (abort) | — | — | none | — |

No routed method = no authorization obligation is live; the gates that exist are declared in `config/permissionslist.php` (exact-name check below, F3).

## 6. Findings

### F1 — Errors

clean — `grep -c "try\s*{" Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php` → 0; `grep -n "getMessage" Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php` → no output. The controller uses only `abort(403)` bodies, matching D1/D2, and there is no operation that can fail at runtime.

### F2 — Transactions and audit

clean — there are no reachable mutating methods. `grep -n "DB::\|transaction\|activityLog" Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php` → no output. The six mutating methods are all `abort(403)`; `index`/`create`/`edit`/`trashedAcademicSession` are reads only.

### F3 — Authorization

clean — every gate string is declared in `config/permissionslist.php`, verified exact-name:

```
$ php artisan tinker --execute '$c=config("permissionslist"); $flat=[];
  foreach($c as $scope=>$keys){ foreach($keys as $k=>$v){ foreach($v as $a){ $flat[]="$scope.$k.$a"; } } }
  $out=array_values(array_filter($flat, fn($f)=>str_contains($f,"academic-session") && (str_contains($f,"prime.prime")||str_contains($f,"global-master.academic-session"))));
  foreach($out as $f) echo $f."\n";'
prime.prime.academic-session.create
prime.prime.academic-session.view
prime.prime.academic-session.viewAny
prime.prime.academic-session.update
prime.prime.academic-session.delete
prime.prime.academic-session.restore
prime.prime.academic-session.forceDelete
tenant.global-master.academic-session.create
tenant.global-master.academic-session.view
tenant.global-master.academic-session.viewAny
tenant.global-master.academic-session.update
tenant.global-master.academic-session.delete
tenant.global-master.academic-session.restore
tenant.global-master.academic-session.forceDelete
```

`index()`'s `Gate::any([...]) || abort(403)` has the required abort (AUTH-05 no-op guard satisfied). The gates are per-method and precede the queries (AUTH-02). Mixing `prime.prime.*` (index) with `tenant.global-master.*` (create/edit/trashed) is inconsistent, but the controller is dead and the names are all producible — recorded as informational, not a finding.

### F4 — Validation and input

#### ACAD-04 · M · VAL-05 — the FormRequest drops `is_current`, `start_date`, `end_date` from `validated()`

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; a write path with no validation silently loses data* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php:16-44`, method `rules()` / `prepareForValidation()` |
| **Root cause** | `prepareForValidation()` merges `is_current` into the input, but `rules()` never lists `is_current`, `start_date` or `end_date`. Laravel's `$request->validated()` returns only keys present in `rules()`, so all three fields are silently dropped on any write that uses `validated()`. |
| **Consequence** | If this request were ever wired to a live store/update, the "current session" checkbox and both date fields would never persist, and the date columns (`NOT NULL` in DDL) would make the insert fail with a database error. |
| **Reproduce** | static only — `store`/`update` are unrouted `abort(403)`. The trap triggers the moment a route is added. |
| **Fix approach** | Add the three fields to `rules()` (type `boolean` for `is_current`, `required|date` for the dates), or delete the request with the rest of the dead screen. |
| **Plan item** | ACAD-04 in `02-fix-plan.md` §5 |

```php
// AcademicSessionRequest.php:16-44 — CURRENT
    public function rules(): array
    {

        $boardId = $this->route('academic_session') ? $this->route('academic_session')->id : null;
        return [
            'name' => [
                'required',
                'string',
                'max:50',
                // Unique, but ignore current record when updating
                Rule::unique('glb_academic_sessions')->ignore($boardId),
            ],
            'short_name' => [
                'required',
                'string',
                'max:10',
                // Unique, but ignore current record when updating
                Rule::unique('glb_academic_sessions')->ignore($boardId),
            ],
            
        ];
    }
    protected function prepareForValidation()
    {
        // Convert checkboxes from 'on' or null to boolean true/false
        $this->merge([
            'is_current' => $this->has('is_current') && $this->input('is_current') === 'on' ? true : false,
        ]);
    }
```

**Evidence**
```
$ php -l Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php
No syntax errors detected in Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php
$ grep -n "start_date\|end_date\|is_current" Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php
41:            'is_current' => $this->has('is_current') && $this->input('is_current') === 'on' ? true : false,
```

#### ACAD-05 · M · VAL-04 — uniqueness rules do not mirror the database index

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H, lowered to M) — *uniqueness rules mirror the real index including soft-delete semantics* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php:21-33`, method `rules()` |
| **Root cause** | `glb_academic_sessions` DDL has `UNIQUE KEY uq_glb_acadSessions_shortName (short_name)` and a generated `current_flag` unique; there is **no unique index on `name`**. The request enforces uniqueness on *both* `name` and `short_name` with a plain `Rule::unique(...)` that also includes soft-deleted rows, while the controller binds the model as `$academicSession` but the request reads route param `academic_session` (`$academicSession` vs `{academic_session}` — a §3.3.1 unbound-model trap if it were ever routed). |
| **Consequence** | The form would refuse to re-create a name that the database actually allows (over-constraint), and an update routed with the mismatched parameter name would silently target a fresh, empty model instead of the record. |
| **Reproduce** | static only — no route exists. |
| **Fix approach** | Drop the `name` unique rule (the DB has no such index) and match the route parameter name to the binding, or delete the request with the dead screen. |
| **Plan item** | ACAD-05 in `02-fix-plan.md` §5 |

```php
// AcademicSessionRequest.php:21-33 — CURRENT
            'name' => [
                'required',
                'string',
                'max:50',
                // Unique, but ignore current record when updating
                Rule::unique('glb_academic_sessions')->ignore($boardId),
            ],
            'short_name' => [
                'required',
                'string',
                'max:10',
                // Unique, but ignore current record when updating
                Rule::unique('glb_academic_sessions')->ignore($boardId),
            ],
```

**Evidence**
```
$ sed -n '84,96p' /Users/bkwork/WorkFolder/2-New_Primedb/pgdatabase/2-DDL_Tenant_Enhanced/_Core/_global_db_v4.1.sql
    `id` INT unsigned NOT NULL AUTO_INCREMENT,
    `short_name` varchar(20) NOT NULL,
    `name` varchar(50) NOT NULL,
    `start_date` date NOT NULL,
    `end_date` date NOT NULL,
    `is_current` tinyint(1) NOT NULL DEFAULT '1',
    `current_flag` tinyint(1) GENERATED ALWAYS AS ((case when (`is_current` = 1) then `1` else NULL end)) STORED,
    ...
    UNIQUE KEY `uq_glb_acadSessions_shortName` (`short_name`),
    UNIQUE KEY `uq_glb_acadSession_currentFlag` (`current_flag`)
```

### F5 — Routes

#### ACAD-01 · M · RTE-03 — five unrouted public methods still carry live or empty bodies instead of the D5 abort

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M, D5) — *every public controller method is routed, or is deliberately disabled with `abort(403)`* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php:17-27` (`index`), `:32-36` (`create`), `:51-54` (`show`), `:59-68` (`edit`), `:92-97` (`trashedAcademicSession`) |
| **Root cause** | Six siblings in the same file already follow D5 (`store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus` — each `abort(403, 'This endpoint is not available.')` with a `// NOT ROUTED` comment). These five were left with real bodies (gates, queries, views) or an empty `//` body (`show`), even though no route can reach them. |
| **Consequence** | Anyone adding a route to this file by habit (or copying the Prime controller's route block) silently arms a half-working CRUD with a `show()` that returns nothing. |
| **Reproduce** | static only — `route:list` proves count 0. |
| **Fix approach** | Apply the same D5 body to the five methods (see plan item; if Tarun ticks the delete decision ACAD-06 instead, this item becomes moot). |
| **Plan item** | ACAD-01 in `02-fix-plan.md` §5 |

```php
// AcademicSessionController.php:17-27 — CURRENT (index)
    public function index()
    {
        // Gate::authorize('tenant.global-master.academic-session.viewAny');

        Gate::any([
            'prime.prime.academic-session.viewAny',
        ]) || abort(403);

        $academicSessions = AcademicSession::paginate(10);
        return view('globalmaster::academic-session.index', compact('academicSessions'));
    }
```

**Evidence**
```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); $n=0;
          foreach($r as $x){ if(str_contains($x["action"],"GlobalMaster\\Http\\Controllers\\AcademicSessionController@")) $n++; }
          echo "COUNT=$n\n";'
COUNT=0
```

#### ACAD-06 · M · CTL-10 — the whole controller is a dead duplicate of the live Prime academic-session screen

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php` (whole file, 124 lines) |
| **Root cause** | The feature this file implements is a copy of `Modules\Prime\Http\Controllers\AcademicSessionController`, which owns all 11 `central.prime.academic-session.*` routes. The GlobalMaster copy is registered nowhere in any route file (`Modules/GlobalMaster/routes/web.php` has no academic-session resource), and only this file's dead methods render the `globalmaster::academic-session.*` views. |
| **Consequence** | Every line is dead weight; it will drift from the live controller and mislead the next developer who greps for "AcademicSessionController". |
| **Reproduce** | `route:list` count 0 (above); `grep -rn "central.global-master.academic-session" Modules/ routes/` only matches the *views* this dead controller would render, never a registered route. |
| **Fix approach** | **Decision item**: delete the controller + 4 views + request, or keep them D5-disabled (self-documenting dead code). |
| **Plan item** | ACAD-06 in `02-fix-plan.md` §9 (DECISION) |

```php
// AcademicSessionController.php:12-12 — CURRENT
class AcademicSessionController extends Controller
```

**Evidence**
```
$ grep -rn "central.global-master.academic-session" Modules/ routes/ 2>/dev/null
Modules/GlobalMaster/resources/views/academic-session/edit.blade.php:10: <x-prime.card.header ... url="central.global-master.academic-session" />
Modules/GlobalMaster/resources/views/academic-session/create.blade.php:25: <form action="{{ route('central.global-master.academic-session.store') }}" ...
(8 view hits, 0 route hits — the named routes do not exist anywhere)
```

### F6 — Controller shape

#### ACAD-07 · M · CTL-09 — commented-out debug dump inside `edit()`

| Field | Value |
|---|---|
| **Rule** | CTL-09 (H, lowered to M) — *no debug leftovers; commented-out `print_r` signals an untested path* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php:64-66`, method `edit()` |
| **Root cause** | `// echo "<pre>"; // print_r($academicSession); // exit();` is a commented-out debug dump left in the method body. |
| **Consequence** | Signals that the edit body has never been exercised end-to-end; on an unrouted controller it is inert, but it would surface in any review of the "working" copy. |
| **Reproduce** | static only. |
| **Fix approach** | Remove the three commented lines (or delete with ACAD-06). |
| **Plan item** | ACAD-07 in `02-fix-plan.md` §8 (grouped with the controller style item) |

```php
// AcademicSessionController.php:59-68 — CURRENT (edit, lines 64-66 commented)
    public function edit(string $id)
    {
        Gate::authorize('tenant.global-master.academic-session.update');
        $academicSession = AcademicSession::findOrFail($id);

        // echo "<pre>";
        // print_r($academicSession);
        // exit();
        return view('globalmaster::academic-session.edit', compact('academicSession'));
    }
```

**Evidence**
```
$ sed -n '64,66p' Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php
        // echo "<pre>";
        // print_r($academicSession);
        // exit();
```

### F7 — Models

#### ACAD-02 · H · MDL-04 — two relations import classes that do not exist

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L, raised to H) — *relationship methods must resolve; here any call is a fatal class-not-found* |
| **Where** | `Modules/Prime/app/Models/AcademicSession.php:11,10,70-84`, methods `classModeRules()` and `classGroupRequirements()` |
| **Root cause** | The file imports `use Modules\SmartTimetable\Models\ClassModeRule;` and `use Modules\SmartTimetable\Models\ClassGroupRequirement;`. Neither class exists in that namespace — `Modules/SmartTimetable/app/Models/` has no such files. `ClassModeRule` lives at `Modules\TimetableFoundation\Models\ClassModeRule`; `ClassGroupRequirement` exists nowhere in the repo (only a seeder and a TimetableFoundation controller reference it, both also broken). |
| **Consequence** | `$session->classModeRules` / `$session->classGroupRequirements` (or `with('classModeRules')`) throws `Class "Modules\SmartTimetable\Models\ClassModeRule" not found` — a 500 on the platform side. |
| **Reproduce** | `php artisan tinker --execute 'use Modules\Prime\Models\AcademicSession; $s=AcademicSession::first(); try{$b=$s->classModeRules()->get(); var_export($b->count());}catch(\Throwable $e){echo "ERR: ".$e->getMessage();}'` → `ERR: Class "Modules\SmartTimetable\Models\ClassModeRule" not found` |
| **Fix approach** | Repoint `classModeRules()` to the real FQCN (`Modules\TimetableFoundation\Models\ClassModeRule`) and delete `classGroupRequirements()` (the class does not exist anywhere), or remove both relations — they have no callers today (grep-proven). Decision-driven: see plan. |
| **Plan item** | ACAD-02 in `02-fix-plan.md` §2 |

```php
// AcademicSession.php:70-84 — CURRENT
    public function classModeRules()
    {
        return $this->hasMany(
            ClassModeRule::class,
            'academic_session_id'
        );
    }

    public function classGroupRequirements()
    {
        return $this->hasMany(
            ClassGroupRequirement::class,
            'academic_session_id'
        );
    }
```

**Evidence**
```
$ php artisan tinker --execute 'var_export([class_exists("Modules\\SmartTimetable\\Models\\ClassModeRule"), class_exists("Modules\\SmartTimetable\\Models\\ClassGroupRequirement"), class_exists("Modules\\TimetableFoundation\\Models\\ClassModeRule")]);'
array (
  0 => false,
  1 => false,
  2 => true,
)
$ ls Modules/SmartTimetable/app/Models/ | grep -i "classmode\|classgroup"; echo "grep exit=$? (empty = not present)"
```

#### ACAD-03 · H · MDL-03/MDL-04 — four relations resolve against tables/pivots that cannot answer from this model

| Field | Value |
|---|---|
| **Rule** | MDL-03/MDL-04 (L default, raised to H) — *belongsToMany pivot must exist; relations must resolve on the model's connection* |
| **Where** | `Modules/Prime/app/Models/AcademicSession.php:37-40` (`organizationAcademicSessions`), `:65-68` (`boards`), `:86-92` (`activities`), `:94-100` (`timetables`) |
| **Root cause** | The model pins `protected $connection = 'global_master_mysql'` (line 17). Three `hasMany` relations target tables that exist in the **tenant** database, not on `global_master_mysql` (`sch_org_academic_sessions_jnt`, `tt_activities`, `tt_timetables`) — Laravel runs the joined query on the parent's connection, so each `->get()` is `Table 'global_master.tt_activities' doesn't exist`. `boards()` is a `belongsToMany(Board::class)` with no pivot name, so Laravel uses the default `academic_session_board` — a table that exists in no DDL and in no live database. The DDL's real board↔session link is `sch_board_organization_jnt (board_id, academic_sessions_id)`, a different shape. |
| **Consequence** | Any eager load or relation access on the platform's most-shared session model 500s (wrong connection) or crashes (missing pivot). Today no caller exists (grep-proven), but the model is used live by the Prime controller and will be reached by `SessionBoardSetupController` in a later batch. |
| **Reproduce** | `php artisan tinker --execute 'use Modules\Prime\Models\AcademicSession; $s=AcademicSession::first(); try{$b=$s->boards()->get(); var_export($b->count());}catch(\Throwable $e){echo "ERR: ".$e->getMessage();}'` → `ERR: SQLSTATE[42S02]: Table 'global_master.academic_session_board' doesn't exist`. Same for `activities()` → `Table 'global_master.tt_activities' doesn't exist`; `timetables()` → `tt_timetables`; `organizationAcademicSessions()` → `sch_org_academic_sessions_jnt`. |
| **Fix approach** | **Decision item**: delete the four dead relations (recommended — no callers, wrong architecture), or re-scope them to the tenant connection with the correct pivot/FK. Do not leave them as-is. |
| **Plan item** | ACAD-03 in `02-fix-plan.md` §9 (DECISION) |

```php
// AcademicSession.php:37-100 — CURRENT (all six relations)
    public function organizationAcademicSessions()
    {
        return $this->hasMany(OrganizationAcademicSession::class);
    }

    /**
     * Scope: current academic session
     */
    public function scopeCurrent($query)
    {
        return $query->where('is_current', true);
    }

    // public function organizations()
    // {
    //     $this->belongsToMany(Organization::class, 'glb_organizations')
    //         ->withPivot([
    //             'short_name',
    //             'name',
    //             'start_date',
    //             'end_date',
    //             'is_current',
    //             'current_flag',
    //         ])
    //         ->withTimestamps();
    // }


    public function boards()
    {
        return $this->belongsToMany(Board::class);
    }

    public function classModeRules()
    {
        return $this->hasMany(
            ClassModeRule::class,
            'academic_session_id'
        );
    }

    public function classGroupRequirements()
    {
        return $this->hasMany(
            ClassGroupRequirement::class,
            'academic_session_id'
        );
    }

    public function activities()
    {
        return $this->hasMany(
            Activity::class,
            'academic_session_id'
        );
    }

    public function timetables()
    {
        return $this->hasMany(
            Timetable::class,
            'academic_session_id'
        );
    }
```

**Evidence**
```
$ php artisan tinker --execute 'use Modules\Prime\Models\AcademicSession; $s=AcademicSession::first();
  foreach(["boards","organizationAcademicSessions","activities","timetables","classModeRules","classGroupRequirements"] as $r){
    try{ $s->$r()->get(); echo "$r ok\n"; }catch(\Throwable $e){ echo "$r ERR: ".$e->getMessage()."\n"; } }'
boards ERR: SQLSTATE[42S02]: Table 'global_master.academic_session_board' doesn't exist
organizationAcademicSessions ERR: SQLSTATE[42S02]: Table 'global_master.sch_org_academic_sessions_jnt' doesn't exist
activities ERR: SQLSTATE[42S02]: Table 'global_master.tt_activities' doesn't exist
timetables ERR: SQLSTATE[42S02]: Table 'global_master.tt_timetables' doesn't exist
classModeRules ERR: Class "Modules\SmartTimetable\Models\ClassModeRule" not found
classGroupRequirements ERR: Class "Modules\SmartTimetable\Models\ClassGroupRequirement" not found
```

### F8 — Services and jobs

clean — the controller names no services, jobs, events, mails or notifications (`grep -oE '...Service|...Job'` → no output). The model has no services.

### F9 — Queries and performance

clean — the two live-body list methods paginate at 10 (`AcademicSession::paginate(10)`, `onlyTrashed()->paginate(10)`), there are no loops, no `->all()`, no raw SQL, no `get()` feeding an unbounded list. The model has no global scope.

### F10 — Views

#### ACAD-08 · M · VIEW-02 — `index` and `trash` blades read a column that does not exist on the model

| Field | Value |
|---|---|
| **Rule** | VIEW-02 (M) — *a `??`/attribute read on a column that does not exist is silent forever* |
| **Where** | `Modules/GlobalMaster/resources/views/academic-session/index.blade.php:26`, `trash.blade.php:26` |
| **Root cause** | `{{ $session->is_active ? 'table-primary' : '' }}` reads `is_active`. `glb_academic_sessions` has **no `is_active` column** (DDL: `is_current` only) and the model has no such attribute/cast, so the expression is always `null` → the row class never applies. |
| **Consequence** | The active-row highlight silently never renders; every row looks the same. Cosmetic only, but it is a lie in the markup that will confuse the next reader. |
| **Reproduce** | Render the (unreachable) index view — static only here. |
| **Fix approach** | Use `$session->is_current` (the real column) — or delete the views with ACAD-06. |
| **Plan item** | ACAD-08 in `02-fix-plan.md` §7 |

```php
// index.blade.php:26 — CURRENT
                                    <tr class="align-middle {{ $session->is_active ? 'table-primary' : '' }}">
```

**Evidence**
```
$ grep -n "is_active" Modules/Prime/app/Models/AcademicSession.php Modules/GlobalMaster/resources/views/academic-session/*.blade.php
Modules/GlobalMaster/resources/views/academic-session/index.blade.php:26: {{ $session->is_active ? 'table-primary' : '' }}
Modules/GlobalMaster/resources/views/academic-session/trash.blade.php:26: {{ $session->is_active ? 'table-primary' : '' }}
$ php artisan tinker --execute 'var_export(in_array("is_active", Modules\Prime\Models\AcademicSession::first()->getFillable())); echo "\n";'
false
```

All four blades compile (verified with `Blade::compileString` + `php -l` → "No syntax errors detected", `@push(0)/startPush(0)` balanced).

### F11 — Security and tenancy

clean — no `env()` outside config, no `{!! !!}` on user text, no `Log` of request bodies, no hard-coded ids/`?? 1`, no JSON endpoint leaking models. Tenancy: the model pins the global connection correctly for a `glb_` table; the broken cross-connection relations are ACAD-03, not a tenancy bypass.

### F12 — Style

Scanner hits: `STY-01` missing `strict_types=1` on all three PHP files; `CTL-04` missing return types on all 11 controller methods; `MDL-04` missing return types on all 6 model relations. Also `use Illuminate\Support\Facades\Auth;` at controller line 7 is never used; a commented-out `organizations()` block sits in the model (lines 50-62); a commented-out `Gate::authorize` sits at controller line 19. Grouped into three L plan items — one per file (§8).

#### ACAD-09 · L · CTL-04/STY-01 — controller style (return types, strict_types, unused import, dead comments)

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L), STY-01/STY-04 (L) — *return types on public methods; strict_types on touched files; no commented-out code, no unused imports* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php` (whole file) |
| **Root cause** | No `declare(strict_types=1)`, no return types on the 11 public methods, unused `Auth` import (line 7), dead `// Gate::authorize(...)` comment (line 19). |
| **Consequence** | Convention drift only; invisible at runtime. |
| **Reproduce** | scanner + `grep -n "Auth" Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php` → only the import line. |
| **Fix approach** | Py cleanup item: add strict_types + return types, drop the unused import and the dead comment. |
| **Plan item** | ACAD-09 in `02-fix-plan.md` §8 |

```php
// AcademicSessionController.php:1-10 — CURRENT
<?php

namespace Modules\GlobalMaster\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Modules\GlobalMaster\Http\Requests\AcademicSessionRequest;
use Modules\Prime\Models\AcademicSession;
```

**Evidence**
```
$ php final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php
L  STY-01   ...  -  — missing declare(strict_types=1)
L  CTL-04   ...  index — index() has no return type
... (11 CTL-04 rows for the 11 public methods)
```

#### ACAD-10 · L · MDL-04/STY-01 — model style (relation return types, strict_types, dead comment block)

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L), STY-01/STY-04 (L) — *relations return-typed; strict_types; no commented-out code >3 lines* |
| **Where** | `Modules/Prime/app/Models/AcademicSession.php:1,37-100` |
| **Root cause** | No `declare(strict_types=1)`; none of the six relations has a return type; lines 50-62 are a commented-out `organizations()` method. |
| **Consequence** | Convention drift; static-analysis misses. |
| **Reproduce** | scanner rows listed above. |
| **Fix approach** | Add strict_types and return types (`: HasMany`, `: BelongsToMany`, etc.) to the relations that survive ACAD-02/03; drop the commented block. |
| **Plan item** | ACAD-10 in `02-fix-plan.md` §8 |

```php
// AcademicSession.php:1-1 — CURRENT
<?php
```

**Evidence**
```
$ php final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/Prime/app/Models/AcademicSession.php
L  MDL-04   ... organizationAcademicSessions — relation organizationAcademicSessions() has no return type
L  MDL-04   ... boards — relation boards() has no return type
L  MDL-04   ... classModeRules — relation classModeRules() has no return type
L  MDL-04   ... classGroupRequirements — relation classGroupRequirements() has no return type
L  MDL-04   ... activities — relation activities() has no return type
L  MDL-04   ... timetables — relation timetables() has no return type
```

#### ACAD-11 · L · STY-01 — request style (strict_types)

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *strict_types on files you touch* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php:1` |
| **Root cause** | No `declare(strict_types=1)`. |
| **Consequence** | Convention drift. |
| **Reproduce** | scanner row. |
| **Fix approach** | Add the declare line (only if the request survives ACAD-06). |
| **Plan item** | ACAD-11 in `02-fix-plan.md` §8 |

```php
// AcademicSessionRequest.php:1-1 — CURRENT
<?php
```

**Evidence**
```
$ php final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php
L  STY-01   -  — missing declare(strict_types=1)
```

#### ACAD-12 · L · STY-04 — commented-out `organizations()` method in the model

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *no commented-out code* (folded into ACAD-10 file item; kept as its own finding because it is >3 lines) |
| **Where** | `Modules/Prime/app/Models/AcademicSession.php:50-62` |
| **Root cause** | A 13-line commented-out `organizations()` relation. |
| **Consequence** | Dead code in a shared model; suggests a relation that does not exist. |
| **Reproduce** | see code block. |
| **Fix approach** | Remove with ACAD-10's model style item. |
| **Plan item** | ACAD-12 in `02-fix-plan.md` §8 (part of ACAD-10 item) |

```php
// AcademicSession.php:50-62 — CURRENT
    // public function organizations()
    // {
    //     $this->belongsToMany(Organization::class, 'glb_organizations')
    //         ->withPivot([
    //             'short_name',
    //             'name',
    //             'start_date',
    //             'end_date',
    //             'is_current',
    //             'current_flag',
    //         ])
    //         ->withTimestamps();
    // }
```

**Evidence**
```
$ sed -n '50,62p' Modules/Prime/app/Models/AcademicSession.php
    // public function organizations()
    // {
    ...
    // }
```

### F13 — Deep read (answer all 8 questions for every mutating method)

No mutating method is reachable (all six mutation methods are `abort(403)`). The table records the deep-read verdict per method:

| Method | 1 wrong data | 2 delete-before-store | 3 dup impls | 4 soft-delete×unique | 5 race | 6 auth hole | 7 lying msg | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` (abort) | ok | ok | ok | ok | ok | ok | ok | dead (ACAD-06) |
| `update` (abort) | ok | ok | ok | ok | ok | ok | ok | dead (ACAD-06) |
| `destroy` (abort) | ok | ok | ok | ok | ok | ok | ok | dead (ACAD-06) |
| `restore` (abort) | ok | ok | ok | ok | ok | ok | ok | dead (ACAD-06) |
| `forceDelete` (abort) | ok | ok | ok | ok | ok | ok | ok | dead (ACAD-06) |
| `toggleStatus` (abort) | ok | ok | ok | ok | ok | ok | ok | dead (ACAD-06) |

The duplicate-implementation and dead-feature questions do yield a "yes" at the file level: this controller duplicates the live Prime controller (ACAD-06), and the shared model's six relations are duplicates/broken stubs of relations the tenant side owns (ACAD-02/03). Tracked there.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules\Prime\Http\Controllers\AcademicSessionController` (live duplicate) | The live controller keeps its own copy of this feature; the GlobalMaster copy should be reconciled/deleted. | CTL-10 | Prime module audit (later batch) |
| `Modules\SmartTimetable\Models\ClassGroupRequirement` (missing) | Class exists nowhere; referenced by `database/seeders/ClassGroupRequirementSeeder.php`, `RequirementConsolidationController` and this model. The seeder would fatal if run. | MDL-07 | TimetableFoundation / SmartTimetable module audit |
| `Modules\TimetableFoundation\Models\ClassModeRule` | Correct home for the class this model imports from the wrong namespace. | MDL-04 | this report (ACAD-02) repoints to it |
| `OrganizationAcademicSession` (SchoolSetup) | Its `$fillable` uses `academic_session_id` but the DDL column is `academic_sessions_id` — cross-module mismatch surfaced by the dead relation in ACAD-03. | MDL-01 | SchoolSetup module audit |
| `x-prime.card.header` / `x-backend.form.*` components | Views pass a `url`/`route()` for `central.global-master.academic-session.*` which does not exist; components would hide/throw if the dead screen were ever wired. | RTE-06 | this report (dead screen, ACAD-06) |

## 8. Not covered, and why

- The **live** Prime module's `AcademicSessionController`, its request, and its `prime::academic-session.*` views are a different controller's scope — not audited here (a later batch owns them).
- Whether the `ClassGroupRequirement` class should exist at all (it is referenced by a seeder and a TimetableFoundation controller that are themselves broken) — outside this controller's scope; captured as a cross-cutting note.
- No browser rendering was possible: this controller has no route (D4 — no tests, §10 verification only). Runtime behaviour of the six relations was proven in tinker instead of the browser.