# Fix Plan — GlobalMaster / AcademicSessionController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php` | route file — shared; no route must be added/removed (final-audit.md §9.3) |
| `Modules/Prime/app/Models/AcademicSession.php` (relation removal) | ⚠ SHARED model — owned by this report, but also used by the live Prime controller and the later `SessionBoardSetupController` batch. Removing relations is a DECISION item (ACAD-02/ACAD-03) only. |
| `config/permissionslist.php` | shared — no change needed (all gate names already exist) |
| `Modules/GlobalMaster/app/Models/Board.php` | owned by [tarun/GlobalMaster-done/BoardController](../BoardController-done/01-report.md) — do not edit |
| `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php` | another module's model — do not edit |

## 1. Blockers reachable today

None. `php artisan route:list` resolves zero routes to this controller (report §4, `COUNT=0`), so no finding here can bite a user today. The five methods still carrying live bodies are unreachable. Tick order: decide the two latent-arm items in §2 first (they protect the shared model), then decide the screen's fate in §9 (ACAD-06) — if the screen is deleted, the §5/§7/§8 request and view items become moot.

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **ACAD-02** · H · DECISION · MDL-04 — the shared `AcademicSession` model has two relations that import classes which do not exist; either fix or remove them.
  - **Why it is a decision:** removing or repointing relations on a ⚠ SHARED model changes its public surface, and the correct target class for `classGroupRequirements()` does not exist anywhere in the repo.
  - Where: `Modules/Prime/app/Models/AcademicSession.php:10-11,70-84` (imports + `classModeRules()`, `classGroupRequirements()`).
  - (a) ⭐ Repoint `classModeRules()` to the real class `Modules\TimetableFoundation\Models\ClassModeRule` (verified to exist) and **delete** `classGroupRequirements()` (its class exists nowhere; the relation can never work). Touches `Modules/Prime/app/Models/AcademicSession.php` only.
  - (b) Delete **both** relations (neither has callers today — grep-proven in the report).
  - (c) Leave both as-is and record as accepted dead code.
  - ➜ Choice: ____
  - **Verify:** `php artisan tinker --execute 'use Modules\Prime\Models\AcademicSession; $s=AcademicSession::first(); class_exists("Modules\\TimetableFoundation\\Models\\ClassModeRule") && $s->classModeRules()->count();'`
  - **Expect:** an integer (0 or more), no exception.
  - **Effort:** S

- [ ] **ACAD-03** · H · DECISION · MDL-03/MDL-04 — the shared `AcademicSession` model has four relations that resolve against tables/pivots that cannot answer from connection `global_master_mysql`; remove or re-scope them.
  - **Why it is a decision:** `boards()`, `organizationAcademicSessions()`, `activities()`, `timetables()` are ⚠ SHARED-model surface. The correct architecture (tenant-side relations vs. deletion) is a product call. They have no callers today (grep-proven).
  - Where: `Modules/Prime/app/Models/AcademicSession.php:37-40,65-68,86-100`.
  - (a) ⭐ Delete all four dead relations (they fail at runtime; the real board↔session link lives in `sch_board_organization_jnt` on the tenant side).
  - (b) Keep `boards()` and re-scope to the tenant connection with the correct pivot/FK (needs the tenant-side tables; check the SchoolSetup board-organization design first).
  - (c) Leave all four as-is and record as accepted dead code.
  - ➜ Choice: ____
  - **Verify:** `grep -n "function boards\|function organizationAcademicSessions\|function activities\|function timetables" Modules/Prime/app/Models/AcademicSession.php`
  - **Expect:** matches the chosen option (no output for (a)).
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

## 4. Authorization (F3)

## 5. Validation, routes, models (F4/F5)

- [ ] **ACAD-01** · M · RTE-03 · `AcademicSessionController.php:17-27,32-36,51-54,59-68,92-97` — D5-disable the five unrouted methods that still carry live/empty bodies.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php`
  - **Before** (`AcademicSessionController.php:17-27` — index):
    ```php
    public function index()
    {
        // Gate::authorize('tenant.global-master.academic-session.viewAny');

        Gate::any([
            'prime.prime.academic-session.viewAny',
        ]) || abort(403);

        $academicSessions = AcademicSession::paginate(10);
        return view('globalmaster::academic-session.index', compact('academicSessions'));
    }
    ```
  - **Before** (`AcademicSessionController.php:32-36` — create):
    ```php
    public function create()
    {
        Gate::authorize('tenant.global-master.academic-session.create');
        return view('globalmaster::academic-session.create');
    }
    ```
  - **Before** (`AcademicSessionController.php:51-54` — show):
    ```php
    public function show(string $id)
    {
        //
    }
    ```
  - **Before** (`AcademicSessionController.php:59-68` — edit):
    ```php
    public function edit(string $id)
    {
        Gate::authorize('tenant.global-master.academic-session.update');
        $academicSession = AcademicSession::findOrFail($id);

        // echo "<pre>";
        // print_r($academicSession);
        // exit();
        return view('globalmaster::academic-session.edit', compact('academicSession'));
    }
    ```
  - **Before** (`AcademicSessionController.php:92-97` — trashedAcademicSession):
    ```php
    public function trashedAcademicSession()
    {
        Gate::authorize('tenant.global-master.academic-session.restore');
        $academicSessions = AcademicSession::onlyTrashed()->paginate(10);
        return view('globalmaster::academic-session.trash', compact('academicSessions'));
    }
    ```
  - **After:** each of the five methods gets the same body, mirroring the existing `store` pattern at lines 41-46 (keep each method's own parameter list; `show` and `edit` keep `string $id`):
    ```php
    public function index()
    {
        // NOT ROUTED — no route points at this method (verified against `php artisan route:list`, 2026-08-20).
        // Disabled pending a decision to wire it up or delete it; the original body is in git history.
        abort(403, 'This endpoint is not available.');
    }
    ```
    (same body for `create()`, `show(string $id)`, `edit(string $id)`, `trashedAcademicSession()`.)
  - **Verify:** `grep -n "public function index\|public function create\|public function show\|public function edit\|public function trashedAcademicSession" Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php && grep -c "abort(403" Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php`
  - **Expect:** 5 method signatures found; `abort(403` count is 11 (6 existing + 5 new).
  - **Effort:** S

- [ ] **ACAD-04** · M · VAL-05 · `AcademicSessionRequest.php:16-44` — add the three fields the blades post (`is_current`, `start_date`, `end_date`) to `rules()`, so `validated()` keeps them.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php`
  - **Before** (`AcademicSessionRequest.php:16-44`):
    ```php
    public function rules(): array
    {

        $boardId = $this->route('academic_session') ? $this->route('academic_session')->id : null;
        return [
            'name' => [
                'required',
                'string',
                'max:50',
                // Unique, but ignore current record when updating
                Rule::unique('glb_academic_sessions')->ignore($boardId),
            ],
            'short_name' => [
                'required',
                'string',
                'max:10',
                // Unique, but ignore current record when updating
                Rule::unique('glb_academic_sessions')->ignore($boardId),
            ],
            
        ];
    }
    protected function prepareForValidation()
    {
        // Convert checkboxes from 'on' or null to boolean true/false
        $this->merge([
            'is_current' => $this->has('is_current') && $this->input('is_current') === 'on' ? true : false,
        ]);
    }
    ```
  - **After:**
    ```php
    public function rules(): array
    {
        $boardId = $this->route('academic_session') ? $this->route('academic_session')->id : null;

        return [
            'name' => [
                'required',
                'string',
                'max:50',
                // Unique, but ignore current record when updating
                Rule::unique('glb_academic_sessions')->ignore($boardId),
            ],
            'short_name' => [
                'required',
                'string',
                'max:10',
                // Unique, but ignore current record when updating
                Rule::unique('glb_academic_sessions')->ignore($boardId),
            ],
            'is_current' => [
                'boolean',
            ],
            'start_date' => [
                'required',
                'date',
            ],
            'end_date' => [
                'required',
                'date',
                'after:start_date',
            ],
        ];
    }

    protected function prepareForValidation()
    {
        // Convert checkboxes from 'on' or null to boolean true/false
        $this->merge([
            'is_current' => $this->has('is_current') && $this->input('is_current') === 'on' ? true : false,
        ]);
    }
    ```
  - **Verify:** `grep -n "is_current\|start_date\|end_date" Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php`
  - **Expect:** `is_current`, `start_date`, `end_date` appear in `rules()` (lines 28-40) and `is_current` still in `prepareForValidation()`.
  - **Effort:** S

- [ ] **ACAD-05** · M · VAL-04 · `AcademicSessionRequest.php:21-33` — drop the `name` unique rule (the database has no unique index on `name`; over-constraint) and align the route-param read with the binding (`academic_session` vs `$academicSession`).
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php`
  - **Before** (`AcademicSessionRequest.php:19-27`):
    ```php
        $boardId = $this->route('academic_session') ? $this->route('academic_session')->id : null;
        return [
            'name' => [
                'required',
                'string',
                'max:50',
                // Unique, but ignore current record when updating
                Rule::unique('glb_academic_sessions')->ignore($boardId),
            ],
    ```
  - **After:**
    ```php
        $sessionId = $this->route('academicSession') ? $this->route('academicSession')->id : null;
        return [
            'name' => [
                'required',
                'string',
                'max:50',
                // NOTE (ACAD-05): intentionally NOT unique — glb_academic_sessions has no unique index on name.
            ],
    ```
    and in the `short_name` block, replace `->ignore($boardId)` with `->ignore($sessionId)`.
  - **Verify:** `grep -n "sessionId\|ignore(" Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php`
  - **Expect:** `$sessionId` defined once; `ignore($sessionId)` on `short_name` only; no `Rule::unique` on `name`; no `$boardId`.
  - **Effort:** S

## 6. Queries & performance (F9)

## 7. Views (F10)

- [ ] **ACAD-08** · M · VIEW-02 · `index.blade.php:26` and `trash.blade.php:26` — read `is_current`, the column that exists, instead of `is_active`.
  - **Touches:** `Modules/GlobalMaster/resources/views/academic-session/index.blade.php`, `Modules/GlobalMaster/resources/views/academic-session/trash.blade.php`
  - **Before** (`index.blade.php:26` and `trash.blade.php:26`, identical):
    ```php
    <tr class="align-middle {{ $session->is_active ? 'table-primary' : '' }}">
    ```
  - **After:** (in both files):
    ```php
    <tr class="align-middle {{ $session->is_current ? 'table-primary' : '' }}">
    ```
  - **Verify:** `grep -rn "is_active" Modules/GlobalMaster/resources/views/academic-session/`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **ACAD-09** · L · CTL-04/STY-01 · `AcademicSessionController.php` (also removes ACAD-07's commented debug and the unused `Auth` import).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php`
  - **Before** (`AcademicSessionController.php:1-10`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\Gate;
    use Modules\GlobalMaster\Http\Requests\AcademicSessionRequest;
    use Modules\Prime\Models\AcademicSession;
    ```
  - **Before** (`AcademicSessionController.php:64-66`):
    ```php
        // echo "<pre>";
        // print_r($academicSession);
        // exit();
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\GlobalMaster\Http\Requests\AcademicSessionRequest;
    use Modules\Prime\Models\AcademicSession;
    ```
    (remove the unused `use Illuminate\Support\Facades\Auth;` line and the three commented debug lines; then run `vendor/bin/pint Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php --format agent` and add the return types it leaves missing on the public methods — apply D5 bodies from ACAD-01 first so the `abort(403)` methods get `: void`.)
  - **Verify:** `grep -n "Auth\|print_r\|declare(strict_types" Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php`
  - **Expect:** only `declare(strict_types=1);` at line 3; no `Auth` import; no `print_r`.
  - **Effort:** S

- [ ] **ACAD-10** · L · MDL-04/STY-01 · `AcademicSession.php` — strict_types, relation return types, and remove the commented `organizations()` block (ACAD-12).
  - **Touches:** `Modules/Prime/app/Models/AcademicSession.php`
  - **Before** (`AcademicSession.php:1-1`):
    ```php
    <?php
    ```
  - **Before** (`AcademicSession.php:50-62`):
    ```php
        // public function organizations()
        // {
        //     $this->belongsToMany(Organization::class, 'glb_organizations')
        //         ->withPivot([
        //             'short_name',
        //             'name',
        //             'start_date',
        //             'end_date',
        //             'is_current',
        //             'current_flag',
        //         ])
        //         ->withTimestamps();
        // }
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);
    ```
    (remove the 13 commented lines 50-62; for each relation that survives ACAD-02/ACAD-03 add its return type — `: HasMany` for `organizationAcademicSessions()`, `classModeRules()`, `classGroupRequirements()`, `activities()`, `timetables()`; `: BelongsToMany` for `boards()`; add the matching `use Illuminate\Database\Eloquent\Relations\BelongsToMany;` / `use Illuminate\Database\Eloquent\Relations\HasMany;` imports; then `vendor/bin/pint Modules/Prime/app/Models/AcademicSession.php --format agent`.)
  - **Verify:** `grep -n "declare(strict_types\|function \|public function organizations\|Relations\\\\" Modules/Prime/app/Models/AcademicSession.php`
  - **Expect:** `declare(strict_types=1);` present; each surviving relation has a `: HasMany`/`: BelongsToMany` return type; no `public function organizations`.
  - **Effort:** S

- [ ] **ACAD-11** · L · STY-01 · `AcademicSessionRequest.php` — strict_types.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php`
  - **Before** (`AcademicSessionRequest.php:1-1`):
    ```php
    <?php
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);
    ```
  - **Verify:** `grep -n "declare(strict_types" Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php`
  - **Expect:** `declare(strict_types=1);` at line 3.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **ACAD-06** · M · DECISION · CTL-10 — what should happen to this dead duplicate of the live Prime academic-session screen?
  - **Why it is a decision:** deleting a controller + its four views + its request is a file removal, not a mechanical fix; the live feature is served by `Modules\Prime\Http\Controllers\AcademicSessionController`, so nothing breaks if this copy disappears.
  - (a) ⭐ Keep the file, fully D5-disabled (tick ACAD-01) — zero risk, self-documenting dead code.
  - (b) Delete the whole dead screen now: `Modules/GlobalMaster/app/Http/Controllers/AcademicSessionController.php`, `Modules/GlobalMaster/app/Http/Requests/AcademicSessionRequest.php`, and the four `Modules/GlobalMaster/resources/views/academic-session/*.blade.php` views. Nothing references them (grep-proven). If this is ticked, ACAD-01/04/05/08/09/10/11's request+view parts become moot — the fixer should skip them.
  - (c) Wire the GlobalMaster copy to `global-master.academic-session.*` routes alongside the Prime copy — NOT recommended; creates two live CRUDs on one table.
  - ➜ Choice: ____
  - **Verify (b):** `php artisan route:list --json | grep -c "GlobalMaster\\\\Http\\\\Controllers\\\\AcademicSessionController"` and `grep -rn "globalmaster::academic-session" Modules/ | grep -v AcademicSessionController`
  - **Expect:** 0 routes; no remaining reference to the views.
  - **Effort:** S (a) / S (b) / M (c)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | none — every finding has an item above (ACAD-07 is folded into ACAD-09; ACAD-12 is folded into ACAD-10). |