# Final Audit — GlobalMaster / PlanController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php` (348 lines, 12 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://CENTRAL-DOMAIN/prime/sales-plan-mgmt#plans` — the plans tab on the Sales Plan & Module Management page, plus the plan CRUD screens it links to: `/prime/plan`, `/prime/plan/create`, `/prime/plan/{plan}`, `/prime/plan/{plan}/edit`, `/prime/plan/trash/view`. The same controller is also routed under `/global-master/plan/*` (identical route names with the `central.global-master.plan.` prefix). |
| Menu path | Prime (Super-Admin side) → Sales Plan & Module Management → Plans tab (opened from the `#plans` anchor). The `/global-master/plan/*` copies are the geography-master style URIs, still central-only. |
| Who uses it | Central-side roles holding `prime.global-master.plan.*`. Live test DB: `view` / `viewAny` / `update` are granted to 11 roles (Super Admin, School Admin, Sales Team, Support Team, CRM Team, Finance & Billing, App Maintenance, Dev Team, Demo). `create` / `delete` / `restore` / `forceDelete` are declared and seeded, but on the live DB no non-default role row holds them, so those actions are Super-Admin-default (Super Admin bypasses every gate via `Gate::before`). |
| What a user does here | Views the saleable subscription plans (each plan bundles a set of saleable modules and a billing cycle such as monthly/yearly), creates a plan, edits a plan's fields and its module set, soft-deletes (trashes) a plan, restores it from the trash, force-deletes it, and toggles its active status with an AJAX switch. |
| Tables written | `prm_plans` (create/update/soft-delete/restore/force-delete), `glb_module_plan_jnt` (module pivot sync), `sys_central_activity_logs` (the `activityLog()` sink on these central routes), plus the `tenant:*:allowed_modules` cache entries invalidated on update. |
| Tables read | `prm_plans`, `glb_modules`, `glb_module_plan_jnt`, `prm_billing_cycles`, `prm_tenant_plan_jnt`, `prm_tenant`. |
| Live data | `prm_plans` 1 live / 0 trashed; `glb_modules` 16; `prm_tenant_plan_jnt` 1; `prm_tenant` 1; `prm_billing_cycles` 4. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready yet. There is no data-loss Blocker and the CRUD screens exist and mostly work, but (a) all six mutating methods wrap the Laravel transaction idiom in `try/catch` that hides real failures behind a generic flash (D1), (b) restore is a state-changing GET with no CSRF, reachable today from the trash screen, and (c) `destroy()` trashes a plan that subscribed tenants still reference without clearing their allowed-modules cache, so the tenant module list 500s on its next cache expiry. The single worst finding is the restore-over-GET route: clicking a link (or a prefetcher) silently changes state with no CSRF. Rough effort for the whole plan: 4-6 developer-hours, plus three decisions Tarun must make (responses inside transactions, the phantom `features`/`meta_data` fields, and the restore route method).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 4 | 13 | 9 | 3 | 26 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PLN-01..04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | PLN-05, PLN-06 | F9 Queries/Perf | PLN-20 |
| F3 Authorization | PLN-07 | F10 Views | PLN-21, PLN-22 |
| F4 Validation | PLN-08..10 | F11 Security/Tenancy | clean |
| F5 Routes | PLN-11 | F12 Style | PLN-23, PLN-24 |
| F6 Controller shape | PLN-12..14 | F13 Deep read | PLN-25, PLN-26 |
| F7 Models | PLN-15..19 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php` | controller | 348 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php` | FormRequest | 68 | this report | ✅ |
| 3 | `Modules/GlobalMaster/app/Models/Plan.php` | model | 71 | this report | ✅ |
| 4 | `Modules/Prime/app/Models/Tenant.php` | model | 313 | this report | ✅ |
| 5 | `Modules/Prime/app/Models/TenantPlan.php` | model | 61 | this report | ✅ |
| 6 | `Modules/Billing/app/Models/BillingCycle.php` | model | 55 | this report | ✅ (first to reach it) |
| 7 | `Modules/GlobalMaster/app/Models/Module.php` | model | 101 | ↗ [tarun/GlobalMaster-done/ModuleController](../ModuleController-done/01-report.md) | ↗ linked (usage-only: `select('id','name','is_core')->get()`) |
| 8 | `app/Traits/AuthorizesTenantFeature.php` | trait | 56 | common (`app/` glue, §4.2) | usage-checked in PlanRequest |
| 9 | `Modules/GlobalMaster/resources/views/plan/index.blade.php` | view | 135 | this report | ✅ |
| 10 | `Modules/GlobalMaster/resources/views/plan/create.blade.php` | view | 91 | this report | ✅ |
| 11 | `Modules/GlobalMaster/resources/views/plan/edit.blade.php` | view | 97 | this report | ✅ |
| 12 | `Modules/GlobalMaster/resources/views/plan/show.blade.php` | view | 98 | this report | ✅ |
| 13 | `Modules/GlobalMaster/resources/views/plan/trash.blade.php` | view | 58 | this report | ✅ |
| 14 | `Modules/GlobalMaster/routes/web.php` | routes | 198 | common (shared route file) | usage-checked |
| 15 | `Modules/Prime/routes/web.php` | routes | — | common | usage-checked (`sales-plan-mgmt` redirect target) |

No pre-applied files (no GlobalMaster `PRE-APPLIED-*.md` exists).

## 4. Routes

From the uncached route list (`APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json`), this controller's routes:

```
GET|HEAD global-master/plan                                           central.global-master.plan.index
POST    global-master/plan                                           central.global-master.plan.store
GET|HEAD global-master/plan/create                                    central.global-master.plan.create
GET|HEAD global-master/plan/details/{plan}                            central.global-master.plan.details
GET|HEAD global-master/plan/trash/view                                central.global-master.plan.trashed
DELETE  global-master/plan/{id}/force-delete                         central.global-master.plan.forceDelete
GET|HEAD global-master/plan/{id}/restore                              central.global-master.plan.restore
GET|HEAD global-master/plan/{plan}                                    central.global-master.plan.show
PUT|PATCH global-master/plan/{plan}                                    central.global-master.plan.update
DELETE  global-master/plan/{plan}                                    central.global-master.plan.destroy
GET|HEAD global-master/plan/{plan}/edit                               central.global-master.plan.edit
POST    global-master/plan/{plan}/toggle-status                      central.global-master.plan.toggleStatus
GET|HEAD prime/plan                                                   central.prime.plan.index
POST    prime/plan                                                   central.prime.plan.store
GET|HEAD prime/plan/create                                            central.prime.plan.create
GET|HEAD prime/plan/details/{plan}                                    central.prime.plan.details
GET|HEAD prime/plan/trash/view                                        central.prime.plan.trashed
DELETE  prime/plan/{id}/force-delete                                 central.prime.plan.forceDelete
GET|HEAD prime/plan/{id}/restore                                      central.prime.plan.restore
GET|HEAD prime/plan/{plan}                                            central.prime.plan.show
PUT|PATCH prime/plan/{plan}                                            central.prime.plan.update
DELETE  prime/plan/{plan}                                            central.prime.plan.destroy
GET|HEAD prime/plan/{plan}/edit                                       central.prime.plan.edit
POST    prime/plan/{plan}/toggle-status                              central.prime.plan.toggleStatus
```

Every route points at an existing method (RTE-02 clean — confirmed by the route list resolving all 12 public methods). No public method is unrouted (RTE-03 clean). The custom `/plan/trash/view`, `/plan/{id}/restore`, `/plan/{id}/force-delete`, `/plan/{plan}/toggle-status` and `/plan/details/{plan}` routes are registered after `Route::resource('plan', …)` but have a different number of URI segments than the resource's `/{plan}` show route, so no capture conflict (RTE-06 clean, verified by the route list). All routes sit inside `Route::domain(config('app.domain'))` with `['auth', 'verified', '2fa']` — central routes, no tenant middleware needed (RTE-05 clean for this controller).

Unrouted public methods: none.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 23 | GET /plan | `prime.global-master.plan.viewAny` | none (read) | — | — | PLN-21 (via view) |
| `create` | 34 | GET /plan/create | `prime.global-master.plan.create` | none (read) | — | — | clean |
| `store` | 44 | POST /plan | `prime.global-master.plan.create` + PlanRequest | controller `DB::transaction` | 'Stored' | prm_plans, glb_module_plan_jnt, sys_central_activity_logs | PLN-01, PLN-03, PLN-05, PLN-07 |
| `show` | 75 | GET /plan/{plan} | `prime.global-master.plan.view` | none (read) | — | — | clean |
| `edit` | 86 | GET /plan/{plan}/edit | `prime.global-master.plan.update` | none (read) | — | — | PLN-12, PLN-13 |
| `update` | 103 | PUT /plan/{plan} | `prime.global-master.plan.update` + PlanRequest | controller `DB::transaction` | 'Updated' | prm_plans, glb_module_plan_jnt, sys_central_activity_logs, allowed-modules cache | PLN-01, PLN-03, PLN-05, PLN-06, PLN-07, PLN-09, PLN-14, PLN-20, PLN-25 |
| `destroy` | 185 | DELETE /plan/{plan} | `prime.global-master.plan.delete` | controller `DB::transaction` | 'Trashed' | prm_plans (soft delete), sys_central_activity_logs | PLN-01, PLN-03, PLN-05, PLN-12, PLN-13, PLN-26 |
| `trashedPlan` | 217 | GET /plan/trash/view | `prime.global-master.plan.restore` | none (read) | — | — | PLN-22 (via view) |
| `restore` | 225 | GET /plan/{id}/restore | `prime.global-master.plan.restore` | controller `DB::transaction` | 'Restored' | prm_plans, sys_central_activity_logs | PLN-01, PLN-03, PLN-05, PLN-11, PLN-13 |
| `forceDelete` | 253 | DELETE /plan/{id}/force-delete | `prime.global-master.plan.forceDelete` | controller `DB::transaction` | 'Deleted' | prm_plans (force delete), sys_central_activity_logs | PLN-01, PLN-03, PLN-05, PLN-13 |
| `toggleStatus` | 283 | POST /plan/{plan}/toggle-status | `prime.global-master.plan.update` | controller `DB::transaction` | 'Toggled' | prm_plans, sys_central_activity_logs | PLN-01, PLN-02, PLN-03, PLN-04, PLN-05, PLN-13 |
| `planDetails` | 332 | GET /plan/details/{plan} | `prime.global-master.plan.viewAny` | none (read) | — | — | clean |

## 6. Findings

### F1 — Errors

#### PLN-01 · H · ERR-00 — try/catch wraps the Laravel transaction idiom in all 6 mutating methods

| Field | Value |
|---|---|
| **Rule** | ERR-00 settled by D1 (H default) — *a controller try/catch is a finding; `DB::transaction(fn () => ...)` rolls back and rethrows, and the central handler in `bootstrap/app.php` renders* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:48-69` (store), 127-179 (update), 189-212 (destroy), 229-250 (restore), 257-278 (forceDelete), 287-327 (toggleStatus) |
| **Root cause** | Every mutation is wrapped in `try { return DB::transaction(...) } catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { Log::error(...getMessage()); return back()->with('error', '...'); }`. D1 allows no controller try/catch; D2's allowed shapes are `\DomainException`, the truncate-then-rebuild catch, and `SnapshotProtectionException` — none apply here. The `ModelNotFoundException` catch only rethrows (dead weight), and the generic catch hides every real failure behind a fixed flash string. |
| **Consequence** | Every write failure becomes a red flash "The operation could not be completed." instead of Laravel's diagnostic error page, so a real SQL or cache failure looks like a user input error and gets re-tried forever. |
| **Reproduce** | Submit the create form after pointing a tenant at a bad billing cycle; observe the generic red flash instead of the underlying error. |
| **Fix approach** | Remove the `try`/`catch` wrappers from all six methods (D1) and drop the now-unused `ModelNotFoundException` and `Log` imports. `DB::transaction` keeps its atomicity and rethrows; `findOrFail` inside the closures still 404s. |
| **Plan item** | PLN-01 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -nE "try \{|catch \(|Log::error"` — see below |

```php
// PlanController.php:44-70 — CURRENT (store; the same wrapper repeats in update/destroy/restore/forceDelete/toggleStatus)
    public function store(PlanRequest $request)
    {
        Gate::authorize('prime.global-master.plan.create');

        try {
            return DB::transaction(function () use ($request) {
                $plan = Plan::create($request->validated());
                $plan->modules()->sync($request['module_ids']);

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($plan, 'Stored', ['message' => 'A new plan was created.', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')->with('success', flash('created.plan'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('PlanController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
```

**Evidence**
```
$ grep -nE "try \{|catch \(|Log::error" Modules/GlobalMaster/app/Http/Controllers/PlanController.php
48:        try {
61:        } catch (ModelNotFoundException $e) {
65:        } catch (\Throwable $e) {
66:            Log::error('PlanController::store failed', ['error' => $e->getMessage()]);
127:        try {
172:        } catch (\Throwable $e) {
173:            Log::error('PlanController::update failed', [
189:        try {
204:        } catch (ModelNotFoundException $e) {
208:        } catch (\Throwable $e) {
209:            Log::error('PlanController::destroy failed', ['error' => $e->getMessage()]);
229:        try {
242:        } catch (ModelNotFoundException $e) {
246:        } catch (\Throwable $e) {
247:            Log::error('PlanController::restore failed', ['error' => $e->getMessage()]);
257:        try {
270:        } catch (ModelNotFoundException $e) {
274:        } catch (\Throwable $e) {
275:            Log::error('PlanController::forceDelete failed', ['error' => $e->getMessage()]);
287:        try {
319:        } catch (ModelNotFoundException $e) {
323:        } catch (\Throwable $e) {
324:            Log::error('PlanController::toggleStatus failed', ['error' => $e->getMessage()]);
```

#### PLN-02 · H · ERR-02 — `validate()` inside `toggleStatus`'s try; a 422 becomes a generic redirect

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500; validate/authorize/findOrFail belong before the try* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:287-291`, method `toggleStatus()` |
| **Root cause** | `$request->validate(['is_active' => 'required|boolean'])` (line 289, inside a `try` at 287) throws a `ValidationException`, which is a `\Throwable`, so the generic catch at 323 swallows the 422 and returns `back()->with('error', ...)`. The field error never reaches the caller. |
| **Consequence** | The status-switch AJAX call with a bad payload gets a redirect instead of a 422 JSON field error, so the front end can never show "is_active is required". |
| **Reproduce** | POST `/prime/plan/{plan}/toggle-status` with no `is_active`; the response is a redirect, not a 422. |
| **Fix approach** | Resolved by PLN-01: with the catch removed, the `ValidationException` propagates to the central handler and the caller gets a 422. |
| **Plan item** | none — see plan §10 (resolved by PLN-01) |
| **Evidence** | `grep -n "->validate(" Modules/GlobalMaster/app/Http/Controllers/PlanController.php` → `289:                $request->validate([` (quoted below) |

```php
// PlanController.php:287-295 — CURRENT (validate inside the try)
        try {
            return DB::transaction(function () use ($request, $plan) {
                $request->validate([
                    'is_active' => 'required|boolean',
                ]);
                // get the new desired status
                $newStatus = $request->input('is_active');
```

**Evidence**
```
$ grep -n "validate" Modules/GlobalMaster/app/Http/Controllers/PlanController.php
289:                $request->validate([
```

#### PLN-03 · M · ERR-05 — catches log `getMessage()` only, losing the exception and trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('...', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:66,173-175,209,247,275,324` — one per catch |
| **Root cause** | Each generic catch logs `['error' => $e->getMessage()]` (update also logs `['id' => $plan->id, 'error' => ...]`). The message text alone cannot be traced back to a stack frame, so the real failure site stays hidden. |
| **Consequence** | Support cannot tell which query failed or where; identical-looking failures are indistinguishable in the log. |
| **Reproduce** | Trigger any write failure and read `storage/logs/laravel.log`. |
| **Fix approach** | Resolved by PLN-01: the catches are removed and `bootstrap/app.php`'s central handler logs the full exception. |
| **Plan item** | none — see plan §10 (resolved by PLN-01) |
| **Evidence** | `grep -n "getMessage" Modules/GlobalMaster/app/Http/Controllers/PlanController.php` — see below |

```php
// PlanController.php:173-176 — CURRENT (one of six; store/destroy/restore/forceDelete/toggleStatus are the one-line form)
            Log::error('PlanController::update failed', [
                'id' => $plan->id,
                'error' => $e->getMessage(),
            ]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/GlobalMaster/app/Http/Controllers/PlanController.php
66:            Log::error('PlanController::store failed', ['error' => $e->getMessage()]);
175:                'error' => $e->getMessage(),
209:            Log::error('PlanController::destroy failed', ['error' => $e->getMessage()]);
247:            Log::error('PlanController::restore failed', ['error' => $e->getMessage()]);
275:            Log::error('PlanController::forceDelete failed', ['error' => $e->getMessage()]);
324:            Log::error('PlanController::toggleStatus failed', ['error' => $e->getMessage()]);
```

#### PLN-04 · M · ERR-04 — `toggleStatus` returns JSON on success but an HTML redirect on failure, with no `expectsJson()` branch

| Field | Value |
|---|---|
| **Rule** | ERR-04 (M) — *JSON endpoints fail with JSON; form endpoints fail with a redirect. Use `$request->expectsJson()` when one method serves both* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:305-316,323-327`, method `toggleStatus()` |
| **Root cause** | The happy path returns `response()->json([...])` while the generic catch returns `back()->with('error', 'The operation could not be completed.')`. The route is consumed by the AJAX status switch (`x-backend.table.status-switch`), so a failure returns a 302 HTML document the JS cannot parse. |
| **Consequence** | A failed toggle shows the browser's raw redirect/HTML or a useless parsed body instead of `{success:false}`. |
| **Reproduce** | POST `/prime/plan/{plan}/toggle-status` with an invalid payload and inspect the response — it is a redirect, not JSON. |
| **Fix approach** | Resolved by PLN-01: without the catch, a failure becomes an exception; for an AJAX requester that `expectsJson()`, Laravel renders a JSON 422/500, matching the JSON happy path. |
| **Plan item** | none — see plan §10 (resolved by PLN-01) |
| **Evidence** | `sed -n '305,327p' Modules/GlobalMaster/app/Http/Controllers/PlanController.php` — see below |

```php
// PlanController.php:305-327 — CURRENT (JSON success, redirect failure)
                    return response()->json([
                        'success' => true,
                        'is_active' => $plan->is_active,
                        'message' => flash('status_updated.plan'),
                    ]);
                } else {
                    return response()->json([
                        'success' => false,
                        'is_active' => $plan->is_active,
                        'message' => flash('status_switch_failed.plan'),
                    ]);
                }

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('PlanController::toggleStatus failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -nE "response\(\)->json|return back" Modules/GlobalMaster/app/Http/Controllers/PlanController.php
305:                    return response()->json([
311:                    return response()->json([
326:            return back()->with('error', 'The operation could not be completed.');
```

### F2 — Transactions and audit

#### PLN-05 · M · TXN-05 · DECISION — HTTP responses are built inside the transaction closures

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()` / `response()` after it* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:58,169-171,201,239,267,305-316` — store, update, destroy, restore, forceDelete, toggleStatus |
| **Root cause** | Every transaction closure returns the HTTP response (redirect or JSON) instead of data. It is Laravel-legal (the closure's return value becomes `DB::transaction`'s return), and none of these responses has a side effect, so nothing is broken today. |
| **Consequence** | Maintainability only: the method's response is built inside the transaction, so moving a side effect (mail, file delete) into one of these closures later would be a silent TXN-03 bug. |
| **Reproduce** | static only — the shape is visible in every method. |
| **Fix approach** | Accept as-is (option a) or refactor each closure to return the model/count and build the response after the transaction (option b). |
| **Plan item** | PLN-05 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `grep -n "return redirect\|return response" Modules/GlobalMaster/app/Http/Controllers/PlanController.php` → 58, 169, 201, 239, 267, 305, 311 |

```php
// PlanController.php:169-171 — CURRENT (update returns the redirect from inside the closure)
                return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')
                    ->with('success', flash('updated.plan'));
            });
```

**Evidence**
```
$ grep -n "return redirect\|return response(" Modules/GlobalMaster/app/Http/Controllers/PlanController.php
58:                return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')->with('success', flash('created.plan'));
169:                return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')
201:                return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')->with('success', flash('trashed.plan'));
239:                return redirect()->route('central.global-master.plan.trashed')->with('success', flash('restored.plan'));
267:                return redirect()->route('central.global-master.plan.trashed')->with('success', flash('force_deleted.plan'));
305:                    return response()->json([
311:                    return response()->json([
```

#### PLN-06 · L · TXN-03 — allowed-modules cache invalidation runs inside the transaction

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B, lowered to L) — *no irreversible side effect inside a transaction*; here the side effect is a `cache()->forget()` which is self-healing (the cache recomputes), so the damage is a transientally stale cache, not data loss |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:133-138`, method `update()` |
| **Root cause** | `Tenant::clearAllowedModulesCache()` calls `cache()->forget()` while the transaction is still open. If the transaction later rolls back, the cache has already been cleared and the tenants' next request recomputes from the OLD plan data and re-caches it — a transient inconsistency, no user-visible harm. |
| **Consequence** | On a rolled-back update the module cache is rebuilt early; tenants briefly see the pre-update list until the 30-minute TTL (actually the rebuilt list, so effectively nothing). |
| **Reproduce** | Static only — requires forcing a rollback after the cache clear to observe any inconsistency. |
| **Fix approach** | Move the cache invalidation after the transaction closure returns (or `DB::afterCommit(...)`). Combined with the PLN-20 batch fix on the same lines. |
| **Plan item** | none — see plan §10 (resolved by PLN-20) |
| **Evidence** | `grep -n "clearAllowedModulesCache" Modules/GlobalMaster/app/Http/Controllers/PlanController.php` → `137:                        $tenant?->clearAllowedModulesCache();` (block quoted in PLN-20) |

```php
// PlanController.php:133-138 — CURRENT (cache clear inside the transaction, and per-tenant in a loop)
                TenantPlan::where('plan_id', $plan->id)
                    ->pluck('tenant_id')
                    ->each(function ($tenantId) {
                        $tenant = Tenant::find($tenantId);
                        $tenant?->clearAllowedModulesCache();
                    });
```

**Evidence**
```
$ grep -n "clearAllowedModulesCache" Modules/GlobalMaster/app/Http/Controllers/PlanController.php
137:                        $tenant?->clearAllowedModulesCache();
```

### F3 — Authorization

#### PLN-07 · L · AUTH-04 — `PlanRequest::authorize()` duplicates the controller's Gate check on store/update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:46` (store) and `:105` (update), plus `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php:52-58` |
| **Root cause** | `store()` and `update()` call `Gate::authorize('prime.global-master.plan.create'/'update')` and the injected `PlanRequest` also authorizes the exact same permission via `authorizeByCrudPermission('prime.global-master.plan')` (POST maps to `create`, PUT maps to `update`). The FormRequest runs first, so the controller's Gate check is redundant. |
| **Consequence** | Two places to keep in sync; security is not weakened (both check the same permission) but the duplicate will drift when the permission name changes. |
| **Reproduce** | static only. |
| **Fix approach** | Remove the redundant `Gate::authorize(...)` from `store()` and `update()` and leave the FormRequest as the single check (option a), or strip the trait call and keep the controller gates (option b). |
| **Plan item** | PLN-07 in `02-fix-plan.md` §4 |
| **Evidence** | `grep -n "authorize" Modules/GlobalMaster/app/Http/Controllers/PlanController.php Modules/GlobalMaster/app/Http/Requests/PlanRequest.php` — see below |

```php
// PlanController.php:44-46 — CURRENT (store; update is the same shape at 103-105)
    public function store(PlanRequest $request)
    {
        Gate::authorize('prime.global-master.plan.create');
```

**Evidence**
```
$ grep -n "authorize" Modules/GlobalMaster/app/Http/Controllers/PlanController.php Modules/GlobalMaster/app/Http/Requests/PlanRequest.php
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:25:        Gate::authorize('prime.global-master.plan.viewAny');
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:36:        Gate::authorize('prime.global-master.plan.create');
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:46:        Gate::authorize('prime.global-master.plan.create');
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:77:        Gate::authorize('prime.global-master.plan.view');
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:88:        Gate::authorize('prime.global-master.plan.update');
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:105:        Gate::authorize('prime.global-master.plan.update');
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:187:        Gate::authorize('prime.global-master.plan.delete');
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:219:        Gate::authorize('prime.global-master.plan.restore');
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:227:        Gate::authorize('prime.global-master.plan.restore');
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:255:        Gate::authorize('prime.global-master.plan.forceDelete');
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:285:        Gate::authorize('prime.global-master.plan.update');
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:334:        Gate::authorize('prime.global-master.plan.viewAny');
Modules/GlobalMaster/app/Http/Requests/PlanRequest.php:57:        return $this->authorizeByCrudPermission('prime.global-master.plan');
```

Permissions verified against `config/permissionslist.php:263`: the `prime.global-master.plan` key uses the standard `$crud` = create, view, viewAny, update, delete, restore, forceDelete — every gate string in the controller and every `@can`/`permission=` in the views matches a declared name. Clean otherwise (AUTH-01/02, AUTH-03 not applicable — plans are not per-person records).

### F4 — Validation and input

#### PLN-08 · M · VAL-04 — the `plan_code` uniqueness rule ignores the `version` half of the real unique index

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H, lowered to M) — *uniqueness rules mirror the DB unique index including soft-delete semantics*; here the mismatch is validation-stricter-than-DB, so it refuses a legal row rather than crashing |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php:21-27` |
| **Root cause** | The request declares `plan_code` unique alone (`Rule::unique('prm_plans')->ignore($planId)->whereNull('deleted_at')`). The real unique index is `uq_plans_planKey_live` on the generated column `plan_key_live = CONCAT(plan_code, '|', version)` — i.e. the pair `(plan_code, version)`. So the DB allows two live rows with the same `plan_code` at different `version`s, but this rule refuses the second one; conversely the `name` rule (line 29-33) enforces a uniqueness the DB does not have at all. |
| **Consequence** | An operator cannot create a v2 of an existing `plan_code` even though the DB allows it: a valid create is refused with a validation error. |
| **Reproduce** | Create plan_code "BASIC" version 1, then another "BASIC" version 2 — the second is refused by validation though the index permits it. |
| **Fix approach** | Add the `version` column to the `plan_code` unique rule (`Rule::unique('prm_plans')->ignore($planId)->whereNull('deleted_at')` with `->where('version', <submitted version>)`, or a composite `with('plan_code', ...)` pattern) and document that `name` uniqueness is application-only. |
| **Plan item** | PLN-08 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -n "Rule::unique" Modules/GlobalMaster/app/Http/Requests/PlanRequest.php` + `SHOW INDEX FROM prm_plans` — see below |

```php
// PlanRequest.php:20-34 — CURRENT
        return [
            'plan_code' => [
                'required',
                'string',
                'max:15',
                // Unique, but ignore current record when updating
                Rule::unique('prm_plans')->ignore($planId)->whereNull('deleted_at'),
            ],
            'name' => [
                'required',
                'string',
                'max:30',
                Rule::unique('prm_plans')->ignore($planId)->whereNull('deleted_at'),
            ],
```

**Evidence**
```
$ php artisan tinker --execute 'foreach (DB::select("SHOW INDEX FROM prm_plans") as $r) { echo $r->Key_name." | ".$r->Column_name." | non_unique=".$r->Non_unique.PHP_EOL; }'
PRIMARY | id | non_unique=0
uq_plans_planKey_live | plan_key_live | non_unique=0
```

#### PLN-09 · M · VAL-05 — `version` is validated as a string but stored (and cast) as an integer

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; a write path with no/contradictory type validation is a finding* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php:34` and `Modules/GlobalMaster/app/Models/Plan.php:33` |
| **Root cause** | `PlanRequest` validates `'version' => ['required', 'string', 'max:10']` and the form sends a text input, but `prm_plans.version` is an `unsignedInteger` (migration) and `Plan` casts `version => integer`. "v2" or "2.5" silently becomes integer 0 or 2 on save. The `version` field is half of the unique key, so this can also collapse distinct-looking codes into one key. |
| **Consequence** | A version like "2.1" is stored as 2, and a non-numeric version is silently stored as 0, so plan versions cannot be trusted. |
| **Reproduce** | Create a plan with version "2.1"; the saved row shows version 2. |
| **Fix approach** | Validate `version` as `'required', 'integer', 'min:0'` (matching the column) or change the rule to `Rule::enum`/string and drop the integer cast. |
| **Plan item** | PLN-09 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -n "version" Modules/GlobalMaster/app/Http/Requests/PlanRequest.php Modules/GlobalMaster/app/Models/Plan.php` — see below |

```php
// PlanRequest.php:34 — CURRENT
            'version' => ['required', 'string', 'max:10'],
```

**Evidence**
```
$ grep -n "version" Modules/GlobalMaster/app/Http/Requests/PlanRequest.php Modules/GlobalMaster/app/Models/Plan.php
Modules/GlobalMaster/app/Http/Requests/PlanRequest.php:34:  'version' => ['required', 'string', 'max:10'],
Modules/GlobalMaster/app/Models/Plan.php:33:    'version' => 'integer',
```

#### PLN-10 · M · VAL-05 · DECISION — `features` and `meta_data` are validated for columns that do not exist

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; here two validated fields have no column and are not fillable, so the data the UI believes it is submitting is silently discarded* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php:41,43` |
| **Root cause** | The rules declare `'features' => ['nullable', 'array']` and `'meta_data' => ['nullable', 'array']`, but `prm_plans` has no `features` or `meta_data` column (verified: `SHOW COLUMNS FROM prm_plans`), and `Plan::$fillable` does not list them. Any submitted value passes validation and is then dropped by mass assignment — with no error. |
| **Consequence** | Nobody can notice that features/metadata are not persisted; a future "why is my plan data missing" report is guaranteed. |
| **Reproduce** | Submit `features` in the create payload; the plan is saved and the value is gone. |
| **Fix approach** | DECISION: (a) remove the two rules (they are dead — nothing sends them today), (b) add real columns + fillable + form inputs, or (c) record as accepted. |
| **Plan item** | PLN-10 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `SHOW COLUMNS FROM prm_plans` (no `features`/`meta_data`) + `grep -n "features\|meta_data" Modules/GlobalMaster/app/Http/Requests/PlanRequest.php` — see below |

```php
// PlanRequest.php:41-45 — CURRENT
            'features' => ['nullable', 'array'],
            'is_active' => ['required', 'boolean'],
            'meta_data' => ['nullable', 'array'],
            'module_ids' => ['required', 'array', 'min:1'],
```

**Evidence**
```
$ php artisan tinker --execute 'foreach (DB::select("SHOW COLUMNS FROM prm_plans") as $c) echo $c->Field.PHP_EOL;'
id
plan_code
version
name
description
billing_cycle_id
price_monthly
price_yearly
currency
trial_days
is_active
deleted_at
created_at
updated_at
plan_key_live
```

### F5 — Routes

#### PLN-11 · H · RTE-01 · DECISION — restore changes state over GET, with no CSRF

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (restore, delete, toggle...). GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/GlobalMaster/routes/web.php:50` (`central.prime.plan.restore`) and `:160` (`central.global-master.plan.restore`), method `restore()` |
| **Root cause** | The trash screen's action component renders a plain `<a href>` to `central.global-master.plan.restore` (GET `/plan/{id}/restore`), and the controller restores the plan in a transaction. A GET performs a write with no CSRF token and no confirmation; any link prefetcher (Chrome prefetch, email scanner) restores a trashed plan for an authenticated session. |
| **Consequence** | A trashed (soft-deleted, deactivated) plan can be silently restored by a prefetched link or a CSRF'd `img src`, undoing an administrator's deletion. |
| **Reproduce** | Open the trash screen URL `/plan/trash/view`, right-click a Restore link source — it is a plain GET `<a>`, not a form. |
| **Fix approach** | DECISION: (a) change both restore routes to POST and render a local CSRF form in `trash.blade.php` (keep `action-trashed` for force-delete), (b) fix the shared `action-trashed` component estate-wide, or (c) accept and record (every GlobalMaster sibling shares the shape). |
| **Plan item** | PLN-11 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |
| **Evidence** | uncached `route:list` (quoted in §4) — both restore routes are `GET|HEAD` — plus `grep -n "restore" Modules/GlobalMaster/routes/web.php` → 50, 160 |

```php
// Modules/GlobalMaster/routes/web.php:48-53 — CURRENT (route group; the /global-master copy repeats at 158-163)
        Route::resource('plan', PlanController::class);
        Route::get('/plan/trash/view', [PlanController::class, 'trashedPlan'])->name('plan.trashed');
        Route::get('/plan/{id}/restore', [PlanController::class, 'restore'])->name('plan.restore');
        Route::delete('/plan/{id}/force-delete', [PlanController::class, 'forceDelete'])->name('plan.forceDelete');
        Route::post('/plan/{plan}/toggle-status', [PlanController::class, 'toggleStatus'])->name('plan.toggleStatus');
        Route::get('/plan/details/{plan}', [PlanController::class, 'planDetails'])->name('plan.details');
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json 2>/dev/null | php -r '$r=json_decode(stream_get_contents(STDIN),true); foreach($r as $x) if(str_contains($x["action"],"PlanController@restore")) printf("%-7s %-55s %s\n",$x["method"],$x["uri"],$x["name"]);'
GET|HEAD global-master/plan/{id}/restore      central.global-master.plan.restore
GET|HEAD prime/plan/{id}/restore              central.prime.plan.restore
```

### F6 — Controller shape

#### PLN-12 · M · CTL-03 — `edit` and `destroy` look up by `$id` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:86-93` (edit), `185-194` (destroy) |
| **Root cause** | `edit(string $id)` and `destroy(string $id)` accept the raw id and call `Plan::findOrFail($id)` / `Plan::findOrFail($id)` inside, while `show`, `update`, `toggleStatus` and `planDetails` already use `Plan $plan` binding. `restore($id)` and `forceDelete($id)` need `withTrashed()->findOrFail`, which binding cannot express — they stay as-is. |
| **Consequence** | Inconsistent shape on the same class; a route-model-bound method can never receive a mismatched id because Laravel 404s first. |
| **Reproduce** | static only. |
| **Fix approach** | Change `edit(Plan $plan)` and `destroy(Plan $plan)` and drop the `findOrFail` lines. |
| **Plan item** | PLN-12 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -nE "public function (edit|destroy)" Modules/GlobalMaster/app/Http/Controllers/PlanController.php` → 86, 185; quoted lines below |

```php
// PlanController.php:86-93 — CURRENT (edit; destroy is the same shape at 185-194)
    public function edit(string $id)
    {
        Gate::authorize('prime.global-master.plan.update');

        $plan = Plan::findOrFail($id);

        return view('globalmaster::plan.edit', compact('plan'));
    }
```

**Evidence**
```
$ sed -n '185,194p' Modules/GlobalMaster/app/Http/Controllers/PlanController.php
    public function destroy(string $id)
    {
        Gate::authorize('prime.global-master.plan.delete');

        try {
            return DB::transaction(function () use ($id) {
                $plan = Plan::findOrFail($id);
                $plan->is_active = false;
                $plan->save();
                $plan->delete();
```

#### PLN-13 · L · CTL-04 — no return types on any public method

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:23-346` |
| **Root cause** | None of the 12 public methods declares a return type. The view methods should be `: View`, the mutation methods `: RedirectResponse`, and `toggleStatus`/`planDetails` `: JsonResponse`. |
| **Consequence** | The compiler cannot catch a method that returns the wrong shape (e.g. a mutation returning JSON). |
| **Reproduce** | static only. |
| **Fix approach** | Add return types to every public method. |
| **Plan item** | PLN-13 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -nE "public function [a-zA-Z_]+" Modules/GlobalMaster/app/Http/Controllers/PlanController.php` — see the §4 method list (every line has no return type) |

```php
// PlanController.php:23-28 — CURRENT (representative of all 12)
    public function index()
    {
        Gate::authorize('prime.global-master.plan.viewAny');
        $plans = Plan::paginate(10);

        return view('globalmaster::plan.index', compact('plans'));
    }
```

**Evidence**
```
$ grep -nE "public function [a-zA-Z_]+" Modules/GlobalMaster/app/Http/Controllers/PlanController.php
23:    public function index()
34:    public function create()
44:    public function store(PlanRequest $request)
75:    public function show(Plan $plan)
86:    public function edit(string $id)
103:    public function update(PlanRequest $request, Plan $plan)
185:    public function destroy(string $id)
217:    public function trashedPlan()
225:    public function restore($id)
253:    public function forceDelete($id)
283:    public function toggleStatus(Request $request, Plan $plan)
332:    public function planDetails(Plan $plan)
```
None of the 12 signatures has a `: Type` return type (verified by `grep -cE "public function [a-zA-Z_]+\([^)]*\): "` → `0`).

#### PLN-14 · M · CTL-10 — the `billing_cycle` → `billing_cycle_id` conversion is dead code

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: a branch nothing can reach* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:110-121`, method `update()` |
| **Root cause** | The block converts `$data['billing_cycle']` ('monthly'/'quarterly'/'yearly'/'one_time') into `billing_cycle_id` using a hard-coded map. But `PlanRequest` has no `billing_cycle` rule, so `$request->validated()` can never contain it — and both forms submit `billing_cycle_id` via `x-prime.form.select-billing-cycle`. The branch is unreachable, and its numeric map duplicates the billing-cycle rows' ids (a source of drift if ids change). |
| **Consequence** | Confusing maintenance surface; if a future form ever sends `billing_cycle`, validation refuses it because the rule is missing, so the map can never do its job. |
| **Reproduce** | static only — grep shows the only writer of `billing_cycle` is this dead map. |
| **Fix approach** | Delete lines 110-121. |
| **Plan item** | PLN-14 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -n "billing_cycle" Modules/GlobalMaster/app/Http/Controllers/PlanController.php Modules/GlobalMaster/app/Http/Requests/PlanRequest.php Modules/GlobalMaster/resources/views/plan/create.blade.php Modules/GlobalMaster/resources/views/plan/edit.blade.php` — see below |

```php
// PlanController.php:110-121 — CURRENT (dead branch)
        // Convert billing_cycle → billing_cycle_id
        $cycleMap = [
            'monthly' => 1,
            'quarterly' => 2,
            'yearly' => 3,
            'one_time' => 4,
        ];

        if (isset($data['billing_cycle'])) {
            $data['billing_cycle_id'] = $cycleMap[$data['billing_cycle']];
            unset($data['billing_cycle']);
        }
```

**Evidence**
```
$ grep -n "billing_cycle" Modules/GlobalMaster/app/Http/Controllers/PlanController.php Modules/GlobalMaster/app/Http/Requests/PlanRequest.php
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:110: // Convert billing_cycle → billing_cycle_id
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:111: $cycleMap = [
Modules/GlobalMaster/app/Http/Controllers/PlanController.php:118: if (isset($data['billing_cycle'])) {
Modules/GlobalMaster/app/Http/Requests/PlanRequest.php:36: 'billing_cycle_id' => ['required', 'exists:prm_billing_cycles,id'],
```
Note: `PlanRequest` line 36 is the only `billing_cycle_id` rule; there is no `billing_cycle` rule anywhere, and both forms post `billing_cycle_id`.

### F7 — Models

#### PLN-15 · M · MDL-02 — `TenantPlan` has no casts for its boolean columns

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` for every boolean, date/datetime, decimal, json/array, and enum column* |
| **Where** | `Modules/Prime/app/Models/TenantPlan.php:14-31` |
| **Root cause** | `TenantPlan` is a junction row with `is_subscribed`, `is_trial`, `auto_renew`, `automatic_billing` and `is_active` boolean columns (plus `status`), and the model declares no `$casts` at all, so every read returns raw 0/1 integers and comparisons like `== '1'` are string-vs-int. The columns are used by the Billing module's subscription logic. |
| **Consequence** | Boolean semantics must be re-derived in every caller; a strict `=== true` check in any current or future consumer silently fails. |
| **Reproduce** | static only — `grep -n "\$casts" Modules/Prime/app/Models/TenantPlan.php` returns nothing. |
| **Fix approach** | Add a `$casts` map for the five booleans (and `status` if it is an enum). |
| **Plan item** | PLN-15 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -n "casts" Modules/Prime/app/Models/TenantPlan.php` → no output; the columns are declared in the migration `Modules/Prime/database/migrations/2025_12_02_043313_create_tenant_plans_table.php` |

```php
// TenantPlan.php:14-31 — CURRENT
    protected $connection = 'mysql';
    protected $table = 'prm_tenant_plan_jnt';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'tenant_id',
        'plan_id',
        'is_subscribed',
        'is_trial',
        'auto_renew',
        'automatic_billing',
        'status',
        'is_active',
        'created_at',
        'updated_at',
    ];
```

**Evidence**
```
$ grep -n "casts" Modules/Prime/app/Models/TenantPlan.php
(no output — no $casts property or casts() method)
```

#### PLN-16 · L · MDL-04/STY-01/STY-04 — `Plan` model: relations untyped, no `strict_types`, commented-out import

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) *relationship methods return-typed*; STY-01 (L) *`declare(strict_types=1)`*; STY-04 (L) *no commented-out code* |
| **Where** | `Modules/GlobalMaster/app/Models/Plan.php:1,10,46-68` |
| **Root cause** | `modules()`, `tenantPlans()` and `billingCycle()` have no return types; the file has no `declare(strict_types=1)`; line 10 is a commented-out factory import. `$fillable` (MDL-01), `$casts` (MDL-02) and `$table` (MDL-07, `prm_plans` exists) are all sound, and `modules()` is correctly DB-qualified because it joins across connections (`mysql` pivot vs `global_master_mysql` module table). The pivot `glb_module_plan_jnt` has no `deleted_at`, so MDL-03 does not apply (checked). |
| **Consequence** | Style/maintainability only. |
| **Reproduce** | static only. |
| **Fix approach** | Add return types, `declare(strict_types=1);` on touch, delete the commented import. |
| **Plan item** | PLN-16 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -nE "public function (modules|tenantPlans|billingCycle)" Modules/GlobalMaster/app/Models/Plan.php` — see below |

```php
// Plan.php:46-68 — CURRENT (relations)
    public function modules()
    {
        $primeDb = DB::connection('mysql')->getDatabaseName();

        return $this->belongsToMany(
            Module::class,
            "{$primeDb}.glb_module_plan_jnt",
            'plan_id',
            'module_id'
        )->withPivot('is_active')
            ->withTimestamps();
    }


    public function tenantPlans()
    {
        return $this->hasMany(TenantPlan::class, 'plan_id');
    }

    public function billingCycle()
    {
        return $this->belongsTo(BillingCycle::class, 'billing_cycle_id');
    }
```

**Evidence**
```
$ grep -nE "public function (modules|tenantPlans|billingCycle)" Modules/GlobalMaster/app/Models/Plan.php
46:    public function modules()
60:    public function tenantPlans()
65:    public function billingCycle()
```

#### PLN-17 · L · MDL-04/STY-01 — `TenantPlan` model: relations untyped, no `strict_types`

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed*; STY-01 (L) — *`declare(strict_types=1)`* |
| **Where** | `Modules/Prime/app/Models/TenantPlan.php:34-55` |
| **Root cause** | `tenant()`, `plan()`, `tenantPlanRates()`, `tenantPlanModules()` and `invoices()` have no return types; no `strict_types`. The `TenantPlanRate` / `TenantPlanModule` / `TenantInvoice` models are only referenced by these relation methods — this controller never touches them, so they stay out of scope. |
| **Consequence** | Style/maintainability only. |
| **Reproduce** | static only. |
| **Fix approach** | Add return types and `declare(strict_types=1);` on touch. |
| **Plan item** | PLN-17 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -nE "public function " Modules/Prime/app/Models/TenantPlan.php` — see below |

```php
// TenantPlan.php:33-59 — CURRENT (relations)
    //begin::Eloquent Relationships
    public function tenant()
    {
        return $this->belongsTo(Tenant::class, 'tenant_id');
    }

    public function plan()
    {
        return $this->belongsTo(Plan::class, 'plan_id');
    }


    public function tenantPlanRates()
    {
        return $this->hasMany(TenantPlanRate::class, 'tenant_plan_id');
    }

    public function tenantPlanModules()
    {
        return $this->hasMany(TenantPlanModule::class, 'tenant_plan_id');
    }
    public function invoices()
    {
        return $this->hasMany(TenantInvoice::class, 'tenant_plan_id');
    }

    //end::Eloquent Relationships
```

**Evidence**
```
$ grep -nE "public function " Modules/Prime/app/Models/TenantPlan.php
34:    public function tenant()
39:    public function plan()
45:    public function tenantPlanRates()
50:    public function tenantPlanModules()
54:    public function invoices()
```

#### PLN-18 · L · MDL-04/STY-01/STY-04 — `Tenant` model: relations untyped, no `strict_types`, emoji comment

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed*; STY-01 (L) — *`declare(strict_types=1)`*; STY-04 (L) — *comments in English without emoji markers* |
| **Where** | `Modules/Prime/app/Models/Tenant.php:1,113-133,239` |
| **Root cause** | The four relations this controller can reach (`city`, `tenantPlans`, `billingSchedules`, `invoices`) have no return types; no `strict_types`; line 239 has a `⚠` emoji marker in a comment. The cache keys in `allowedModuleIds()` / `clearAllowedModulesCache()` carry the tenant id (`tenant:{id}:allowed_modules`), so TEN-02 is clean. `InteractsWithMedia` is used but this is the CENTRAL tenant model (its `tenant_img` collection is deliberately central), so the MDL-05/TEN-01 `getMediaModel()` override does not apply — checked, not a finding. Mass-assignment: the model inherits `$guarded = []` from stancl's base `Tenant`; this controller never creates/updates a `Tenant`, so that is recorded in §7 for the tenant-creation controller's audit, not fixed here. |
| **Consequence** | Style/maintainability only. |
| **Reproduce** | static only. |
| **Fix approach** | Add return types and `declare(strict_types=1);` on touch; drop the emoji marker. |
| **Plan item** | PLN-18 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -nE "public function (city|tenantPlans|billingSchedules|invoices)" Modules/Prime/app/Models/Tenant.php` — see below |

```php
// Tenant.php:113-133 — CURRENT (relations)
    public function city()
    {
        return $this->belongsTo(City::class, 'city_id');
    }

    public function tenantPlans()
    {
        return $this->hasMany(TenantPlan::class, 'tenant_id');
    }

    public function billingSchedules()
    {
        return $this->hasMany(TenantPlanBillingSchedule::class, 'tenant_id');
    }

    public function invoices()
    {
        return $this->hasMany(TenantInvoice::class, 'tenant_id');
    }
```

**Evidence**
```
$ grep -nE "public function (city|tenantPlans|billingSchedules|invoices)" Modules/Prime/app/Models/Tenant.php
113:    public function city()
118:    public function tenantPlans()
123:    public function billingSchedules()
128:    public function invoices()
```

#### PLN-19 · L · MDL-04/STY-01 — `BillingCycle` model: relations untyped, no `strict_types`

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed*; STY-01 (L) — *`declare(strict_types=1)`* |
| **Where** | `Modules/Billing/app/Models/BillingCycle.php:1,35-53` |
| **Root cause** | All five relations (`tenantPlanRates`, `billingSchedules`, `invoices`, `plans`) have no return types; no `strict_types`. `$fillable`, `$casts` and `$table` (`prm_billing_cycles`, exists) are sound; MDL-03 does not apply (no soft-delete pivot reached). First audit to reach this class, so it is claimed here. |
| **Consequence** | Style/maintainability only. |
| **Reproduce** | static only. |
| **Fix approach** | Add return types and `declare(strict_types=1);` on touch. |
| **Plan item** | PLN-19 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -nE "public function " Modules/Billing/app/Models/BillingCycle.php` — see below |

```php
// BillingCycle.php:35-53 — CURRENT (relations)
    public function tenantPlanRates()
    {
        return $this->hasMany(TenantPlanRate::class, 'billing_cycle_id');
    }

    public function billingSchedules()
    {
        return $this->hasMany(TenantPlanBillingSchedule::class, 'billing_cycle_id');
    }

    public function invoices()
    {
        return $this->hasMany(TenantInvoice::class, 'billing_cycle_id');
    }

    public function plans()
    {
        return $this->hasMany(Plan::class, 'billing_cycle_id');
    }
```

**Evidence**
```
$ grep -nE "public function " Modules/Billing/app/Models/BillingCycle.php
35:    public function tenantPlanRates()
40:    public function billingSchedules()
45:    public function invoices()
50:    public function plans()
```

### F8 — Services and jobs

clean — this controller uses no services, jobs, events, mail or notifications (imports list has none; `grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b'` → only PlanRequest, no services).

### F9 — Queries and performance

#### PLN-20 · H · QRY-01 — `Tenant::find()` inside a loop in `update()` (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:133-138`, method `update()` |
| **Root cause** | After `$plan->modules()->sync(...)`, the method loads every `tenant_id` that references the plan and then calls `Tenant::find($tenantId)` once per id inside `->each()`. For a plan with N subscribed tenants this is 1 + N queries, and every `clearAllowedModulesCache()` is a cache write on top of that. |
| **Consequence** | Updating a plan that many tenants hold fires one tenant query per tenant (plus cache clears), scaling the save time linearly with subscribers. |
| **Reproduce** | Edit a plan and watch the query log: one `select * from prm_tenant where id = ?` per tenant plan row. |
| **Fix approach** | Batch: `Tenant::whereIn('id', $tenantIds)->get()` once, then loop the batch; also move the cache clears after the transaction (PLN-06). |
| **Plan item** | PLN-20 in `02-fix-plan.md` §6 |
| **Evidence** | `grep -n "Tenant::find" Modules/GlobalMaster/app/Http/Controllers/PlanController.php` → `136:                        $tenant = Tenant::find($tenantId);` (block quoted below) |

```php
// PlanController.php:128-138 — CURRENT
            return DB::transaction(function () use ($plan, $data, $moduleIds, $original) {
                // Update plan
                $plan->update($data);
                $plan->modules()->sync($moduleIds);

                TenantPlan::where('plan_id', $plan->id)
                    ->pluck('tenant_id')
                    ->each(function ($tenantId) {
                        $tenant = Tenant::find($tenantId);
                        $tenant?->clearAllowedModulesCache();
                    });
```

**Evidence**
```
$ grep -n "Tenant::find" Modules/GlobalMaster/app/Http/Controllers/PlanController.php
136:                        $tenant = Tenant::find($tenantId);
```

### F10 — Views

#### PLN-21 · M · VIEW-02 — `index` view lazy-loads `modules` and `billingCycle` inside the row loop (N+1)

| Field | Value |
|---|---|
| **Rule** | VIEW-02 (M) — *relations used inside `@foreach` are eager-loaded by the controller (lazy loads in a loop = N+1)* |
| **Where** | `Modules/GlobalMaster/resources/views/plan/index.blade.php:41-79` (the view) and `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:26` (no eager load) |
| **Root cause** | `index()` runs `Plan::paginate(10)` with no `with([...])`, and the view iterates `@forelse($plans as $plan)` then reads `$plan->modules` (line 65) and `$plan->billingCycle->name` (line 78) inside the loop. Each page of 10 plans fires 20 extra queries (10 module-pivot joins + 10 billing-cycle lookups). |
| **Consequence** | Every load of the plans list issues 21+ queries instead of 3; the modal on each row makes it worse. |
| **Reproduce** | Open `/prime/plan` and read the query log. |
| **Fix approach** | `Plan::with(['modules:id,name,version', 'billingCycle:id,name'])->paginate(10)`. |
| **Plan item** | PLN-21 in `02-fix-plan.md` §7 |
| **Evidence** | `grep -n "plan->modules\|plan->billingCycle" Modules/GlobalMaster/resources/views/plan/index.blade.php` → 51, 65, 78 |

```php
// index.blade.php:41-49 + 65-69 + 76-79 — CURRENT (lazy relations on each row)
                                            @forelse($plans as $plan)
                                            <tr class="align-middle">
                                                <td>
                                                    <button type="button" class="btn btn-sm btn-outline-info rounded"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#planDetail-{{ $plan->id }}">
                                                        <i class="fa-solid fa-info"></i> {{ $plan->name }}
                                                    </button>
                                                    <div class="modal fade" id="planDetail-{{ $plan->id }}"
```

```php
// index.blade.php:65-69 + 76-79 — CURRENT (the lazy reads)
                                                                         @foreach($plan->modules as $module)
                                                                         <li class="list-group-item">
                                                                             {{ $module->name }}(V.{{ $module->version }})
                                                                         </li>
                                                                         @endforeach
                                                  <td>{{ Str::ucfirst($plan->billingCycle->name) }}</td>
```

**Evidence**
```
$ grep -n "plan->modules\|plan->billingCycle" Modules/GlobalMaster/resources/views/plan/index.blade.php
65:                                                                         @foreach($plan->modules as $module)
78:                                                  <td>{{ Str::ucfirst($plan->billingCycle->name) }}</td>
```

#### PLN-22 · M · F13 — the trash view prints the numeric `billing_cycle_id`, not the cycle name

| Field | Value |
|---|---|
| **Rule** | F13 deep-read Q7 (message lies) — a screen shows a value its reader cannot interpret *(reported under F10 because it is a view defect)* |
| **Where** | `Modules/GlobalMaster/resources/views/plan/trash.blade.php:28` |
| **Root cause** | The trashed-plans table prints `{{ Str::ucfirst($plan->billing_cycle_id) }}`. `billing_cycle_id` is an integer FK to `prm_billing_cycles`; `Str::ucfirst` on "2" renders "2", so the Billing Cycle column shows a bare id number while the index and show screens show the actual name ("Quarterly"). |
| **Consequence** | A user reading the trash screen cannot tell which billing cycle a trashed plan used — the column displays a meaningless id. |
| **Reproduce** | Open `/prime/plan/trash/view` with a trashed plan; the Billing Cycle column shows "2" instead of "Quarterly". |
| **Fix approach** | Load the relation and print `$plan->billingCycle?->name ?? '-'` (and eager-load it in `trashedPlan()`). |
| **Plan item** | PLN-22 in `02-fix-plan.md` §7 |
| **Evidence** | `grep -n "billing_cycle_id" Modules/GlobalMaster/resources/views/plan/trash.blade.php` → 28 |

```php
// trash.blade.php:24-29 — CURRENT
                                @forelse($plans as $plan)
                                    <tr class="align-middle">
                                        <td>{{ $plan->name }}</td>
                                        <td>{{ $plan->version }}</td>
                                        <td>{{ Str::ucfirst($plan->billing_cycle_id) }}</td>
                                        <td>{{ $plan->trial_days }}</td>
```

**Evidence**
```
$ grep -n "billing_cycle_id" Modules/GlobalMaster/resources/views/plan/trash.blade.php
28:                                        <td>{{ Str::ucfirst($plan->billing_cycle_id) }}</td>
```

### F11 — Security and tenancy

clean — no `env()` outside config (none in this controller or its in-scope classes), no hard-coded ids (the `$cycleMap` at PLN-14 is dead, not live fallback), the only JSON endpoint (`planDetails`) returns plan/module rows with no personal data, no secrets logged, cache keys are tenant-scoped (`tenant:{id}:allowed_modules`), and the `Tenant` media concern is central-by-design (recorded in PLN-18). Verified with `grep -nE "env\(|DB::raw|whereRaw" <in-scope php files>` → no output.

### F12 — Style

#### PLN-23 · L · STY-01/STY-04 — controller: no `strict_types`, emoji comments, copy-pasted activityLog docblocks

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) *`declare(strict_types=1)`*; STY-04 (L) *comments in English without emoji markers; no copy-pasted docblocks* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:1,53-56,123,142,197-200,235-238,263-266` |
| **Root cause** | No `declare(strict_types=1)`; emoji markers at lines 123 (`// 🔹 Modules`) and 142 (`// 🔹 Track changed attributes`); the 8-line "Syntex" activityLog comment is copy-pasted four times verbatim inside the controller. |
| **Consequence** | Style-only. |
| **Reproduce** | static only. |
| **Fix approach** | Add `declare(strict_types=1);`, remove the emoji markers, delete the copied "Syntex" comment blocks on touch. |
| **Plan item** | PLN-23 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -nE "declare|🔹" Modules/GlobalMaster/app/Http/Controllers/PlanController.php` → emoji at 123, 142; no declare |

```php
// PlanController.php:53-56 — CURRENT (copy-pasted docblock; repeats at 197-200, 235-238, 263-266)
                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($plan, 'Stored', ['message' => 'A new plan was created.', 'other' => 'some other information']);
                // end::Activity Log
```

**Evidence**
```
$ grep -nE "declare|🔹" Modules/GlobalMaster/app/Http/Controllers/PlanController.php
123:        // 🔹 Modules
142:                // 🔹 Track changed attributes
```

#### PLN-24 · L · STY-01 — `PlanRequest` has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (old files when touched)* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php:1` |
| **Root cause** | File starts with `<?php` directly; no `declare(strict_types=1);`. |
| **Consequence** | Style-only. |
| **Reproduce** | static only. |
| **Fix approach** | Add `declare(strict_types=1);` in the PLN-08/09/10 touch. |
| **Plan item** | PLN-24 in `02-fix-plan.md` §8 |
| **Evidence** | `sed -n '1,3p' Modules/GlobalMaster/app/Http/Requests/PlanRequest.php` |

```php
// PlanRequest.php:1-3 — CURRENT
<?php

namespace Modules\GlobalMaster\Http\Requests;
```

**Evidence**
```
$ sed -n '1,3p' Modules/GlobalMaster/app/Http/Requests/PlanRequest.php
<?php

namespace Modules\GlobalMaster\Http\Requests;
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 wrong data | 2 delete-before-store | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok | module_ids unique index (uq_modulePlan_plan_module) covers pivot; plan_key_live covers code+version | ok (FormRequest) | ok | ok |
| `update` | ok | ok | ok | ok (plan_key_live soft-delete aware) | ok | ok (FormRequest) | **PLN-25** | **PLN-14, PLN-10** |
| `destroy` | **PLN-26** | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |

#### PLN-25 · M · F13 — the audit log claims "No attributes changed" when only the module set changed

| Field | Value |
|---|---|
| **Rule** | F13 deep-read Q7 — *does any message lie?* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:140-167`, method `update()` |
| **Root cause** | `$changedAttributes` is built only from `$plan->getChanges()` — the plan row's own changed columns. When an admin changes ONLY the module selection (`$plan->modules()->sync(...)` changed the pivot) and no plan column, `$changedAttributes` is empty and the else-branch logs "A plan was updated. No attributes changed." — but the module set DID change. |
| **Consequence** | The central activity log for a module-set-only edit is actively misleading ("no attributes changed" while the plan's entitlement changed). |
| **Reproduce** | Edit a plan, change only its modules, save; open the plan's activity log row — it says "No attributes changed". |
| **Fix approach** | Track whether `sync()` detached/attached any module id and record it in the log message/payload. |
| **Plan item** | PLN-25 in `02-fix-plan.md` §3 |
| **Evidence** | `sed -n '155,167p' Modules/GlobalMaster/app/Http/Controllers/PlanController.php` — see below |

```php
// PlanController.php:155-167 — CURRENT
                // Activity log
                if (! empty($changedAttributes)) {
                    activityLog($plan, 'Updated', [
                        'message' => 'A plan was updated.',
                        'changes' => $changedAttributes,
                        'performed_by' => Auth::user()->name,
                    ]);
                } else {
                    activityLog($plan, 'Updated', [
                        'message' => 'A plan was updated. No attributes changed.',
                        'performed_by' => Auth::user()->name,
                    ]);
                }
```

**Evidence**
```
$ sed -n '155,167p' Modules/GlobalMaster/app/Http/Controllers/PlanController.php
                // Activity log
                if (! empty($changedAttributes)) {
                    activityLog($plan, 'Updated', [
                        'message' => 'A plan was updated.',
                        'changes' => $changedAttributes,
                        'performed_by' => Auth::user()->name,
                    ]);
                } else {
                    activityLog($plan, 'Updated', [
                        'message' => 'A plan was updated. No attributes changed.',
                        'performed_by' => Auth::user()->name,
                    ]);
                }
```

#### PLN-26 · M · F13 — `destroy()` trashes a plan subscribed tenants still reference, without clearing their module cache

| Field | Value |
|---|---|
| **Rule** | F13 deep-read Q1 (wrong data) + Q7 — *a write that leaves dependent data inconsistent* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:185-213`, method `destroy()` |
| **Root cause** | `destroy()` deactivates and soft-deletes the plan but never touches `prm_tenant_plan_jnt` or the tenants' `tenant:{id}:allowed_modules` cache — unlike `update()`, which explicitly clears that cache. A `TenantPlan` row with `is_active = true` keeps pointing at the trashed plan; `TenantPlan::plan()` (belongsTo, SoftDeletes default scope) then returns `null`, and `Tenant::computeAllowedModuleIds()` dereferences `$tenantPlan->plan->modules->pluck('id')` → "attempt to read property 'modules' on null" the next time each tenant's 30-minute cache expires and recomputes. |
| **Consequence** | Trashing a plan any tenant is subscribed to breaks that tenant's menu/module resolution with a 500 on the next cache expiry — a silent, delayed outage. |
| **Reproduce** | Static only — the code path is proven by the missing cache invalidation; on the live DB there is 1 `prm_tenant_plan_jnt` row, so it is reachable. ⚠ UNVERIFIED — I did not delete a subscribed plan in the browser (D4). |
| **Fix approach** | Before/after the soft delete, clear the allowed-modules cache for every tenant holding the plan (same batch shape as the PLN-20 fix), and/or leave `TenantPlan`-level handling to the decision in that method. |
| **Plan item** | PLN-26 in `02-fix-plan.md` §3 |
| **Evidence** | `sed -n '185,213p' Modules/GlobalMaster/app/Http/Controllers/PlanController.php` — see below |

```php
// PlanController.php:185-204 — CURRENT (destroy; no tenant-cache invalidation anywhere)
    public function destroy(string $id)
    {
        Gate::authorize('prime.global-master.plan.delete');

        try {
            return DB::transaction(function () use ($id) {
                $plan = Plan::findOrFail($id);
                $plan->is_active = false;
                $plan->save();
                $plan->delete();

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($plan, 'Trashed', ['message' => 'A new plan was deactivated and deleted.', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')->with('success', flash('trashed.plan'));

            });
        } catch (ModelNotFoundException $e) {
```

**Evidence**
```
$ grep -n "clearAllowedModulesCache" Modules/GlobalMaster/app/Http/Controllers/PlanController.php
137:                        $tenant?->clearAllowedModulesCache();
```
`clearAllowedModulesCache` appears only in `update()` (line 137); `destroy()` lines 185-213 never call it.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Prime/app/Models/Tenant.php` (claimed here, but the write path is elsewhere) | inherits `$guarded = []` from `stancl\tenancy\Database\Models\Tenant` with no `$fillable`; tenant creation/update code mass-assigns arbitrary columns | MDL-01 | the tenant-creation controller's audit — not reachable from this controller, flagged here for that report |
| `Modules/Prime/routes/web.php:132` (`Route::resource('sales-plan-mgmt', …)`) | the redirect target `central.prime.sales-plan-mgmt.index` is a second CRUD surface over the same plans data (`SalesPlanAndModuleMgmtController`), a duplicate implementation of the plan list | SVC-04 | whoever audits `SalesPlanAndModuleMgmtController` |
| `config/permissionslist.php:263` | `create`/`delete`/`restore`/`forceDelete` for `prime.global-master.plan` are declared but no non-default role holds them on the live test DB — those screens are Super-Admin-only by default | AUTH-06 | permission provisioning / seeder review (not a code defect) |

## 8. Not covered, and why

- **Browser execution:** D4 — no tests, no browser; every reproduce is the URL that shows it, with the code-path evidence. The `destroy()` tenant-cache finding (PLN-26) is marked ⚠ UNVERIFIED for its live-data reachability (1 tenant plan row exists; I did not delete a subscribed plan in a browser).
- **Seeder/sync of the plan permissions:** whether `create`/`delete`/`restore`/`forceDelete` roles appear after `/system-config/sync-permissions` on the live central DB was not exercised.
- **`Modules/Prime/.../SalesPlanAndModuleMgmtController`:** the sibling screen that lists the same plans (and is the redirect target) is a different controller; only its route name and tab anchor were checked.
- **Shared view components** (`x-backend.table.action-trashed`, `x-prime.form.select-billing-cycle`, `x-backend.form.status-switch`): common components, usage-checked (they render the restore `<a>` and the `billing_cycle_id` select) but not audited.
- **Queue/tenant run:** no jobs or listeners exist on this path, so JOB-01..05 were not applicable.