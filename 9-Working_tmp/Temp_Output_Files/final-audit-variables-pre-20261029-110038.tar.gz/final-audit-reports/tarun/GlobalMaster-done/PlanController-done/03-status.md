# Status — GlobalMaster / PlanController

**Fixed:** 2026-10-17 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
| ID | What | Where |
|---|---|---|
| PLN-11 | Restore over GET → **POST** route (both `/global-master` and `/prime` copies), with the dual-mode `action-trashed`. Superseded the plan's per-controller form; left unticked. | commit `6d157fb2c` (restore family) |

## 2. Applied
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| PLN-01 | `PlanController.php` | All six try/catch envelopes, the `ModelNotFoundException` rethrows and the `Log::error(getMessage())` lines removed (D1); both imports dropped. Event literals and payloads unchanged. | `grep -nE "try \{\|Log::error\|ModelNotFoundException"` | no output | 2026-10-17 |
| PLN-05 | — | DECISION (a): the transaction closures keep returning the response. | — | — | 2026-10-17 |
| PLN-07 | `PlanController.php` | Duplicate `Gate::authorize` dropped from store/update — `PlanRequest::authorize()` checks the same permission first. | `grep -c "Gate::authorize('prime.global-master.plan"` | 10 (store/update absent) | 2026-10-17 |
| PLN-08 | `PlanRequest.php` | `plan_code` uniqueness scoped to `version`, mirroring `uq_plans_planKey_live`. | rolled-back store, same code + same version / same code + v2 | refused on `plan_code` / accepted | 2026-10-17 |
| PLN-09 | `PlanRequest.php` | `version` validated as `integer`, `min:0`. | request with `version='v1.0'` | refused on `version` | 2026-10-17 |
| PLN-10 | `PlanRequest.php` | DECISION (a): `features` and `meta_data` rules removed (no columns, not fillable). | `grep -nE "features\|meta_data"` | no output | 2026-10-17 |
| PLN-12 | `PlanController.php` | Route-model binding for `edit()` and `destroy()` (`{plan}` matches `$plan`). | route:list + render edit | 200 | 2026-10-17 |
| PLN-13 | `PlanController.php` | Return types on all 12 public methods. | `grep -cE "public function …\): "` | 12 | 2026-10-17 |
| PLN-14 | `PlanController.php` | Dead `billing_cycle` → `billing_cycle_id` map removed. | `grep -n cycleMap` | no output | 2026-10-17 |
| PLN-15 | `TenantPlan.php` | Boolean casts for the five flag columns. | `var_export(TenantPlan::first()->is_active)` | `true` | 2026-10-17 |
| PLN-16 | `Plan.php` | Relation return types, `strict_types`, commented factory import removed. | grep | 3 hits | 2026-10-17 |
| PLN-17 | `TenantPlan.php` | Relation return types, `strict_types`. | grep | 5 hits | 2026-10-17 |
| PLN-18 | `Tenant.php` | Relation return types, `strict_types`, `⚠` marker removed. Strict-type risk checked: the one untyped scalar call (`str_replace` on `glb_academic_sessions.short_name`) reads a NOT NULL column. | grep + render tenant list | 4 hits / 200 | 2026-10-17 |
| PLN-19 | `BillingCycle.php` | Relation return types, `strict_types`. | grep + render billing page | 4 hits / 200 | 2026-10-17 |
| PLN-20 | `PlanController.php` update | One `Tenant::whereIn()` query replaces the per-tenant `find()` loop. | `grep -c "Tenant::whereIn"` | 2 (update + destroy) | 2026-10-17 |
| PLN-21 | `PlanController.php` index | `modules` and `billingCycle` eager-loaded. | render index | 200 | 2026-10-17 |
| PLN-22 | `PlanController.php`, `plan/trash.blade.php` | Trash shows the billing cycle name (eager-loaded) instead of the id. | rolled-back trash render | "Monthly" shown | 2026-10-17 |
| PLN-23 | `PlanController.php` | `strict_types`, emoji markers and the four `Syntex` blocks removed. | `grep -nE "🔹\|Syntex"` | no output | 2026-10-17 |
| PLN-24 | `PlanRequest.php` | `strict_types`. | grep | 1 | 2026-10-17 |
| PLN-25 | `PlanController.php` update | A module-only change now logs `modules_changed: true` instead of "No attributes changed". ⚠ **Deviation:** the plan's code called `$plan->modules()->detached()` / `->attached()`, which do not exist on `BelongsToMany` and would have thrown on every update. The attached/detached ids are read from `sync()`'s return value instead. | rolled-back update dropping one module | log `modules_changed: true` | 2026-10-17 |
| PLN-26 | `PlanController.php` destroy | Every subscribed tenant's allowed-modules cache is cleared on trash. Uses the same batched lookup as PLN-20 (deviation from the plan's per-tenant `find()` loop, for consistency). | rolled-back destroy with seeded cache keys | 1 tenant, 0 caches left | 2026-10-17 |

### 2.1 Found during verification — fixed (A2)
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| PLN-27 | `PlanController.php` store/update | **The module pivot was outside the transaction.** `Plan` is on `mysql`, but `Plan::modules()` writes `prime_db.glb_module_plan_jnt` through the related `Module` model's connection, `global_master_mysql`. `DB::transaction()` covered only the default connection, so a failure after `sync()` rolled the plan back and left the module set changed. New private `inPlanTransaction()` opens a `global_master_mysql` transaction around the `mysql` one; store and update use it. | simulated failure after `sync()` + plan update | modules 16 → 16, description unchanged | 2026-10-17 |

## 3. Not applied
- PLN-11 — superseded by the POST route (§1).

## 4. Needs Tarun's hand
- Browser check: `/prime/sales-plan-mgmt#plans` — create a plan, edit it (change modules only, then a column), toggle status, trash → restore, force-delete.
- ⚠ **Data note:** the seeded DEV plan has `trial_days = 0`, but `PlanRequest` requires 1–30, so DEV cannot be re-saved from its edit form until trial days is set. Pre-existing; not changed.

## 5. Unverifiable by this workflow (D4)
- Store/update authorization relies on `PlanRequest::authorize()`; every check here ran as super admin.

## 6. Verification log
```
vendor/bin/pint <6 files> --format agent              → fixed Plan.php, TenantPlan.php, BillingCycle.php (spacing/imports)
php -l <6 files>                                       → No syntax errors
class_exists(PlanController|PlanRequest|Plan|TenantPlan|Tenant|BillingCycle) → true ×6
route:list --json (uncached)                           → 24 GlobalMaster plan routes, every action exists
render index / create / trashed                        → 200 · 142,970 / 144,816 / 115,048 bytes, 0 comment leaks
render edit / show (after DecryptUrl redirect)         → 200 · 145,601 / 121,218 bytes
render sales-plan-mgmt / tenant list / billing         → 200 ×3, no TypeError (shared-model strict_types check)
rolled back (both connections): validation, update, destroy, trash render, restore, toggle → see §2
simulated failure inside inPlanTransaction()           → pivot and plan both rolled back
```

### 6.1 ⚠ Incident during verification — real data changed, then restored
Two early probe runs opened a transaction on `mysql` only. Because of PLN-27, the pivot detach in `update()` ran on `global_master_mysql` and was **not rolled back**: plan DEV lost modules 15 (Behavioural Assessment) and 16 (HR & Payroll) from `glb_module_plan_jnt`. Both rows were re-inserted exactly (ids 15/16, `is_active=1`, original `created_at` 2026-10-10 20:12:04 — AUTO_INCREMENT 17 confirmed they existed), and tenant `00000000-0000-4000-8000-000000000001`'s allowed-modules cache was cleared; it now recomputes 16 modules. Later probes wrap both connections.

## 7. Final state
**FIXED.** Open: none in plan. PLN-27 added and fixed.
