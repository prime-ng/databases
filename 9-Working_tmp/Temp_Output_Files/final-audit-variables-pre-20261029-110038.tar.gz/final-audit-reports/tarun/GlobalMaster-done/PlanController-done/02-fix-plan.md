# Fix Plan — GlobalMaster / PlanController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/PlanController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | shared permission config; every permission name this controller uses already exists |
| `Modules/Prime/routes/web.php` | owned by the Prime module (it only hosts the `sales-plan-mgmt` redirect target) |
| `Modules/GlobalMaster/app/Models/Module.php` | owned by the ModuleController report |
| `app/Traits/AuthorizesTenantFeature.php` | common `app/` glue |
| `Modules/Billing/app/Models/BillingCycle.php` **and any other Billing file outside it** | Billing module lives in its own module; only BillingCycle.php is in this scope |
| any migration | never edit an existing migration; the PLN-10 DECISION (if it needs columns) is Tarun's hand |
| shared `x-backend.*` / `x-prime.*` components | except where a ticked item explicitly replaces the restore link in our own `plan/trash.blade.php` |

## 1. Blockers reachable today

None — severity B = 0 for this controller. The H findings are in §3 (PLN-01), §6 (PLN-20) and §9 (PLN-11, decision).

## 2. Fixes that arm a latent defect (sequenced)

No items here. PLN-01 must land before PLN-25 and PLN-26 because it rewrites the same methods' wrappers; that sequence is preserved by putting PLN-01 first in §3.

## 3. Errors & transactions (F1/F2)

- [x] **PLN-01** · H · ERR-00 · `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:48-327` — remove the try/catch wrappers from all six mutating methods (D1). The generic catches that hide real failures, the dead `ModelNotFoundException` rethrows, and the `Log::error(...getMessage())` lines all go away; `DB::transaction` keeps atomicity. The `use Illuminate\Database\Eloquent\ModelNotFoundException;` and `use Illuminate\Support\Facades\Log;` imports become unused and are removed here too. The six method bodies otherwise stay byte-identical (PLN-14, PLN-20, PLN-25, PLN-26 change them in later items; their Before blocks still match because this item does not touch those lines).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Before** (imports, `PlanController.php:5-16`):
    ```php
    use App\Http\Controllers\Controller;
    use Gate;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Log;
    use Modules\GlobalMaster\Http\Requests\PlanRequest;
    use Modules\GlobalMaster\Models\Module;
    use Modules\GlobalMaster\Models\Plan;
    use Modules\Prime\Models\Tenant;
    use Modules\Prime\Models\TenantPlan;
    ```
  - **After:** (imports):
    ```php
    use App\Http\Controllers\Controller;
    use Gate;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Modules\GlobalMaster\Http\Requests\PlanRequest;
    use Modules\GlobalMaster\Models\Module;
    use Modules\GlobalMaster\Models\Plan;
    use Modules\Prime\Models\Tenant;
    use Modules\Prime\Models\TenantPlan;
    ```
  - **After:** (store, replacing `PlanController.php:44-70`):
    ```php
    public function store(PlanRequest $request)
    {
        Gate::authorize('prime.global-master.plan.create');

        return DB::transaction(function () use ($request) {
            $plan = Plan::create($request->validated());
            $plan->modules()->sync($request['module_ids']);

            activityLog($plan, 'Stored', ['message' => 'A new plan was created.', 'other' => 'some other information']);

            return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')->with('success', flash('created.plan'));
        });
    }
    ```
  - **After:** (update, replacing `PlanController.php:103-180`):
    ```php
    public function update(PlanRequest $request, Plan $plan)
    {
        Gate::authorize('prime.global-master.plan.update');

        $original = $plan->getOriginal();
        $data = $request->validated();

        // Convert billing_cycle → billing_cycle_id
        $cycleMap = [
            'monthly' => 1,
            'quarterly' => 2,
            'yearly' => 3,
            'one_time' => 4,
        ];

        if (isset($data['billing_cycle'])) {
            $data['billing_cycle_id'] = $cycleMap[$data['billing_cycle']];
            unset($data['billing_cycle']);
        }

        // 🔹 Modules
        $moduleIds = $data['module_ids'] ?? [];
        unset($data['module_ids']);

        return DB::transaction(function () use ($plan, $data, $moduleIds, $original) {
            // Update plan
            $plan->update($data);
            $plan->modules()->sync($moduleIds);

            TenantPlan::where('plan_id', $plan->id)
                ->pluck('tenant_id')
                ->each(function ($tenantId) {
                    $tenant = Tenant::find($tenantId);
                    $tenant?->clearAllowedModulesCache();
                });

            $changes = $plan->getChanges();

            // 🔹 Track changed attributes
            $changedAttributes = [];
            foreach ($changes as $field => $newValue) {
                if ($field === 'updated_at') {
                    continue;
                }

                $changedAttributes[$field] = [
                    'old' => $original[$field] ?? null,
                    'new' => $newValue,
                ];
            }

            // Activity log
            if (! empty($changedAttributes)) {
                activityLog($plan, 'Updated', [
                    'message' => 'A plan was updated.',
                    'changes' => $changedAttributes,
                    'performed_by' => Auth::user()->name,
                ]);
            } else {
                activityLog($plan, 'Updated', [
                    'message' => 'A plan was updated. No attributes changed.',
                    'performed_by' => Auth::user()->name,
                ]);
            }

            return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')
                ->with('success', flash('updated.plan'));
        });
    }
    ```
  - **After:** (destroy, replacing `PlanController.php:185-213`):
    ```php
    public function destroy(string $id)
    {
        Gate::authorize('prime.global-master.plan.delete');

        return DB::transaction(function () use ($id) {
            $plan = Plan::findOrFail($id);
            $plan->is_active = false;
            $plan->save();
            $plan->delete();

            activityLog($plan, 'Trashed', ['message' => 'A new plan was deactivated and deleted.', 'other' => 'some other information']);

            return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')->with('success', flash('trashed.plan'));
        });
    }
    ```
  - **After:** (restore, replacing `PlanController.php:225-251`):
    ```php
    public function restore($id)
    {
        Gate::authorize('prime.global-master.plan.restore');

        return DB::transaction(function () use ($id) {
            $plan = Plan::withTrashed()->findOrFail($id);
            $plan->restore();

            activityLog($plan, 'Restored', ['message' => 'A new plan was restored.', 'other' => 'some other information']);

            return redirect()->route('central.global-master.plan.trashed')->with('success', flash('restored.plan'));
        });
    }
    ```
  - **After:** (forceDelete, replacing `PlanController.php:253-279`):
    ```php
    public function forceDelete($id)
    {
        Gate::authorize('prime.global-master.plan.forceDelete');

        return DB::transaction(function () use ($id) {
            $plan = Plan::withTrashed()->findOrFail($id);
            $plan->forceDelete();

            activityLog($plan, 'Deleted', ['message' => 'A new plan was permanently deleted.', 'other' => 'some other information']);

            return redirect()->route('central.global-master.plan.trashed')->with('success', flash('force_deleted.plan'));
        });
    }
    ```
  - **After:** (toggleStatus, replacing `PlanController.php:283-328`):
    ```php
    public function toggleStatus(Request $request, Plan $plan)
    {
        Gate::authorize('prime.global-master.plan.update');

        return DB::transaction(function () use ($request, $plan) {
            $request->validate([
                'is_active' => 'required|boolean',
            ]);
            // get the new desired status
            $newStatus = $request->input('is_active');
            $plan->is_active = $newStatus;

            if ($plan->save()) {
                activityLog($plan, 'Toggled', ['message' => 'A new plan status was updated.', 'other' => 'some other information']);

                return response()->json([
                    'success' => true,
                    'is_active' => $plan->is_active,
                    'message' => flash('status_updated.plan'),
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'is_active' => $plan->is_active,
                    'message' => flash('status_switch_failed.plan'),
                ]);
            }
        });
    }
    ```
  - **Verify:** `grep -nE "try \{|Log::error|ModelNotFoundException" Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Expect:** no output.
  - **Effort:** M

- [x] **PLN-25** · M · F13 · `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:140-167` — stop the activity log from claiming "No attributes changed" when only the module set was changed.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Before** (`PlanController.php:123-167`):
    ```php
        // 🔹 Modules
        $moduleIds = $data['module_ids'] ?? [];
        unset($data['module_ids']);

        try {
            return DB::transaction(function () use ($plan, $data, $moduleIds, $original) {
                // Update plan
                $plan->update($data);
                $plan->modules()->sync($moduleIds);

                TenantPlan::where('plan_id', $plan->id)
                    ->pluck('tenant_id')
                    ->each(function ($tenantId) {
                        $tenant = Tenant::find($tenantId);
                        $tenant?->clearAllowedModulesCache();
                    });

                $changes = $plan->getChanges();

                // 🔹 Track changed attributes
                $changedAttributes = [];
                foreach ($changes as $field => $newValue) {
                    if ($field === 'updated_at') {
                        continue;
                    }

                    $changedAttributes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                // Activity log
                if (! empty($changedAttributes)) {
                    activityLog($plan, 'Updated', [
                        'message' => 'A plan was updated.',
                        'changes' => $changedAttributes,
                        'performed_by' => Auth::user()->name,
                    ]);
                } else {
                    activityLog($plan, 'Updated', [
                        'message' => 'A plan was updated. No attributes changed.',
                        'performed_by' => Auth::user()->name,
                    ]);
                }

                return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')
                    ->with('success', flash('updated.plan'));
            });
    ```
  - **After:**
    ```php
        // 🔹 Modules
        $moduleIds = $data['module_ids'] ?? [];
        unset($data['module_ids']);

        return DB::transaction(function () use ($plan, $data, $moduleIds, $original) {
            // Update plan
            $plan->update($data);
            $plan->modules()->sync($moduleIds);

            TenantPlan::where('plan_id', $plan->id)
                ->pluck('tenant_id')
                ->each(function ($tenantId) {
                    $tenant = Tenant::find($tenantId);
                    $tenant?->clearAllowedModulesCache();
                });

            $changes = $plan->getChanges();

            // 🔹 Track changed attributes
            $changedAttributes = [];
            foreach ($changes as $field => $newValue) {
                if ($field === 'updated_at') {
                    continue;
                }

                $changedAttributes[$field] = [
                    'old' => $original[$field] ?? null,
                    'new' => $newValue,
                ];
            }

            // The module pivot may change even when no plan column changes:
            // record that so the log never claims "No attributes changed" falsely.
            $detached = $plan->modules()->detached() ?? [];
            $attached = $plan->modules()->attached() ?? [];
            $moduleSetChanged = ! empty($detached) || ! empty($attached);

            // Activity log
            if (! empty($changedAttributes) || $moduleSetChanged) {
                activityLog($plan, 'Updated', [
                    'message' => 'A plan was updated.',
                    'changes' => $changedAttributes,
                    'modules_changed' => $moduleSetChanged,
                    'performed_by' => Auth::user()->name,
                ]);
            } else {
                activityLog($plan, 'Updated', [
                    'message' => 'A plan was updated. No attributes changed.',
                    'performed_by' => Auth::user()->name,
                ]);
            }

            return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')
                ->with('success', flash('updated.plan'));
        });
    ```
  - **Verify:** `grep -n "modules_changed" Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Expect:** one hit inside the update activityLog payload.
  - **Effort:** S

- [x] **PLN-26** · M · F13 · `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:185-213` — `destroy()` must clear the allowed-modules cache for every tenant subscribed to the plan before the plan is unlinked, so `computeAllowedModuleIds()` does not dereference a null plan on the next cache expiry.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Before** (`PlanController.php:185-199`):
    ```php
    public function destroy(string $id)
    {
        Gate::authorize('prime.global-master.plan.delete');

        try {
            return DB::transaction(function () use ($id) {
                $plan = Plan::findOrFail($id);
                $plan->is_active = false;
                $plan->save();
                $plan->delete();

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($plan, 'Trashed', ['message' => 'A new plan was deactivated and deleted.', 'other' => 'some other information']);
                // end::Activity Log
    ```
  - **After:**
    ```php
    public function destroy(string $id)
    {
        Gate::authorize('prime.global-master.plan.delete');

        return DB::transaction(function () use ($id) {
            $plan = Plan::findOrFail($id);
            $plan->is_active = false;
            $plan->save();
            $plan->delete();

            TenantPlan::where('plan_id', $plan->id)
                ->pluck('tenant_id')
                ->each(function ($tenantId) {
                    $tenant = Tenant::find($tenantId);
                    $tenant?->clearAllowedModulesCache();
                });

            activityLog($plan, 'Trashed', ['message' => 'A new plan was deactivated and deleted.', 'other' => 'some other information']);

            return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#plans')->with('success', flash('trashed.plan'));
        });
    }
    ```
  - **Note for the fixer:** the `TenantPlan` rows that reference the trashed plan are left untouched (the plan may be restored later); only the cache is invalidated so the next recompute reflects the trashed plan. This matches `update()`'s existing invalidation shape.
  - **Verify:** `grep -n "clearAllowedModulesCache" Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Expect:** two hits — line ~137 in update and the new call inside destroy.
  - **Effort:** S

## 4. Authorization (F3)

- [x] **PLN-07** · L · AUTH-04 · `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:46,105` — drop the duplicate `Gate::authorize` from `store()` and `update()`; `PlanRequest::authorize()` already checks the same permission first.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Before** (`PlanController.php:44-48`):
    ```php
    public function store(PlanRequest $request)
    {
        Gate::authorize('prime.global-master.plan.create');

        try {
    ```
  - **After:**
    ```php
    public function store(PlanRequest $request)
    {
        return DB::transaction(function () use ($request) {
    ```
  - **Before** (`PlanController.php:103-107`, update):
    ```php
    public function update(PlanRequest $request, Plan $plan)
    {
        Gate::authorize('prime.global-master.plan.update');

        $original = $plan->getOriginal();
    ```
  - **After:**
    ```php
    public function update(PlanRequest $request, Plan $plan)
    {
        $original = $plan->getOriginal();
    ```
  - **Verify:** `grep -n "Gate::authorize('prime.global-master.plan" Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Expect:** lines for index, create, show, edit, destroy, trashedPlan, restore, forceDelete, toggleStatus, planDetails — but NOT store or update.
  - **Effort:** S

## 5. Validation, routes, models, controller shape (F4/F5/F6/F7)

- [x] **PLN-08** · M · VAL-04 · `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php:21-27` — make the `plan_code` uniqueness rule mirror the real composite index `(plan_code, version)`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php`
  - **Before** (`PlanRequest.php:16-34`):
    ```php
    public function rules(): array
    {
        $planId = $this->route('plan') ? $this->route('plan')->id : null;

        return [
            'plan_code' => [
                'required',
                'string',
                'max:15',
                // Unique, but ignore current record when updating
                Rule::unique('prm_plans')->ignore($planId)->whereNull('deleted_at'),
            ],
            'name' => [
                'required',
                'string',
                'max:30',
                Rule::unique('prm_plans')->ignore($planId)->whereNull('deleted_at'),
            ],
    ```
  - **After:**
    ```php
    public function rules(): array
    {
        $planId = $this->route('plan') ? $this->route('plan')->id : null;

        return [
            'plan_code' => [
                'required',
                'string',
                'max:15',
                // The DB index is uq_plans_planKey_live = CONCAT(plan_code,'|',version),
                // live rows only. Mirror the pair so a v2 of a code is allowed and the
                // same (plan_code, version) is refused (PLN-08).
                Rule::unique('prm_plans')->ignore($planId)
                    ->whereNull('deleted_at')
                    ->where('version', $this->input('version')),
            ],
            'name' => [
                'required',
                'string',
                'max:30',
                // Application-only uniqueness: prm_plans has no unique index on name.
                Rule::unique('prm_plans')->ignore($planId)->whereNull('deleted_at'),
            ],
    ```
  - **Verify:** `grep -n "'version', \$this->input('version')" Modules/GlobalMaster/app/Http/Requests/PlanRequest.php`
  - **Expect:** one hit.
  - **Effort:** S

- [x] **PLN-09** · M · VAL-05 · `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php:34` — validate `version` as an integer, matching the `unsignedInteger` column and the `Plan` integer cast.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php`
  - **Before** (`PlanRequest.php:34`):
    ```php
            'version' => ['required', 'string', 'max:10'],
    ```
  - **After:**
    ```php
            'version' => ['required', 'integer', 'min:0'],
    ```
  - **Verify:** `grep -n "'version' => \['required', 'integer'" Modules/GlobalMaster/app/Http/Requests/PlanRequest.php`
  - **Expect:** one hit.
  - **Effort:** S

- [x] **PLN-12** · M · CTL-03 · `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:86-93,185-194` — use route model binding for `edit()` and `destroy()`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Before** (`PlanController.php:86-93`):
    ```php
    public function edit(string $id)
    {
        Gate::authorize('prime.global-master.plan.update');

        $plan = Plan::findOrFail($id);

        return view('globalmaster::plan.edit', compact('plan'));
    }
    ```
  - **After:**
    ```php
    public function edit(Plan $plan)
    {
        Gate::authorize('prime.global-master.plan.update');

        return view('globalmaster::plan.edit', compact('plan'));
    }
    ```
  - **Before** (`PlanController.php:185-191`, destroy):
    ```php
    public function destroy(string $id)
    {
        Gate::authorize('prime.global-master.plan.delete');

        try {
            return DB::transaction(function () use ($id) {
                $plan = Plan::findOrFail($id);
    ```
  - **After:**
    ```php
    public function destroy(Plan $plan)
    {
        Gate::authorize('prime.global-master.plan.delete');

        return DB::transaction(function () use ($plan) {
            $plan->is_active = false;
    ```
  - **Verify:** `grep -nE "public function (edit|destroy)" Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Expect:** both lines end with `(Plan $plan)`.
  - **Effort:** S

- [x] **PLN-13** · L · CTL-04 · `Modules/GlobalMaster/app/Http/Controllers/PlanController.php` — add return types to the 12 public methods.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Before** (`PlanController.php:23,34,44,75,86,103,185,217,225,253,283,332` — every signature has no return type; representative, `index()`):
    ```php
    public function index()
    {
    ```
  - **After:** (complete set of signatures; body lines unchanged):
    ```php
    public function index(): View
    public function create(): View
    public function store(PlanRequest $request): RedirectResponse
    public function show(Plan $plan): View
    public function edit(Plan $plan): View
    public function update(PlanRequest $request, Plan $plan): RedirectResponse
    public function destroy(Plan $plan): RedirectResponse
    public function trashedPlan(): View
    public function restore($id): RedirectResponse
    public function forceDelete($id): RedirectResponse
    public function toggleStatus(Request $request, Plan $plan): JsonResponse
    public function planDetails(Plan $plan): JsonResponse
    ```
  - **Note for the fixer:** add `use Illuminate\Contracts\View\View;`, `use Illuminate\Http\RedirectResponse;` and `use Illuminate\Http\JsonResponse;` to the imports. Apply the matching return type on each method's first line; the method bodies stay unchanged.
  - **Verify:** `grep -cE "public function [a-zA-Z_]+\([^)]*\): " Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Expect:** `12`.
  - **Effort:** S

- [x] **PLN-14** · M · CTL-10 · `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:110-121` — delete the dead `billing_cycle` to `billing_cycle_id` conversion map.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Before** (`PlanController.php:107-122`):
    ```php
        $original = $plan->getOriginal();
        $data = $request->validated();

        // Convert billing_cycle → billing_cycle_id
        $cycleMap = [
            'monthly' => 1,
            'quarterly' => 2,
            'yearly' => 3,
            'one_time' => 4,
        ];

        if (isset($data['billing_cycle'])) {
            $data['billing_cycle_id'] = $cycleMap[$data['billing_cycle']];
            unset($data['billing_cycle']);
        }

        // 🔹 Modules
    ```
  - **After:**
    ```php
        $original = $plan->getOriginal();
        $data = $request->validated();

        // 🔹 Modules
    ```
  - **Verify:** `grep -n "cycleMap" Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **PLN-15** · M · MDL-02 · `Modules/Prime/app/Models/TenantPlan.php` — add casts for the boolean columns.
  - **Touches:** `Modules/Prime/app/Models/TenantPlan.php`
  - **Before** (`TenantPlan.php:12-31`):
    ```php
    use HasFactory;

    protected $connection = 'mysql';
    protected $table = 'prm_tenant_plan_jnt';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'tenant_id',
        'plan_id',
        'is_subscribed',
        'is_trial',
        'auto_renew',
        'automatic_billing',
        'status',
        'is_active',
        'created_at',
        'updated_at',
    ];
    ```
  - **After:**
    ```php
    use HasFactory;

    protected $connection = 'mysql';
    protected $table = 'prm_tenant_plan_jnt';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'tenant_id',
        'plan_id',
        'is_subscribed',
        'is_trial',
        'auto_renew',
        'automatic_billing',
        'status',
        'is_active',
        'created_at',
        'updated_at',
    ];

    protected $casts = [
        'is_subscribed' => 'boolean',
        'is_trial' => 'boolean',
        'auto_renew' => 'boolean',
        'automatic_billing' => 'boolean',
        'is_active' => 'boolean',
    ];
    ```
  - **Verify:** `grep -n "protected \$casts" Modules/Prime/app/Models/TenantPlan.php`
  - **Expect:** one hit with the five booleans (PLN-15).
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **PLN-20** · H · QRY-01 · `Modules/GlobalMaster/app/Http/Controllers/PlanController.php:133-138` — batch the tenant lookups and move the cache invalidation out of the per-tenant loop (also resolves PLN-06).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Before** (`PlanController.php:128-138`):
    ```php
            return DB::transaction(function () use ($plan, $data, $moduleIds, $original) {
                // Update plan
                $plan->update($data);
                $plan->modules()->sync($moduleIds);

                TenantPlan::where('plan_id', $plan->id)
                    ->pluck('tenant_id')
                    ->each(function ($tenantId) {
                        $tenant = Tenant::find($tenantId);
                        $tenant?->clearAllowedModulesCache();
                    });
    ```
  - **After:**
    ```php
            return DB::transaction(function () use ($plan, $data, $moduleIds, $original) {
                // Update plan
                $plan->update($data);
                $plan->modules()->sync($moduleIds);

                $tenantIds = TenantPlan::where('plan_id', $plan->id)->pluck('tenant_id');

                Tenant::whereIn('id', $tenantIds)->get()->each(function (Tenant $tenant) {
                    $tenant->clearAllowedModulesCache();
                });
    ```
  - **Note for the fixer:** after this item the `$tenant?->clearAllowedModulesCache()` per-tenant call is gone; the cache clears still run inside the transaction (TXN-03, lowered to L and accepted — clearing a cache is self-healing). Do NOT move them after the closure in this item; that is an un-ticked behavioural change.
  - **Verify:** `grep -n "Tenant::whereIn" Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Expect:** one hit.
  - **Effort:** S

## 7. Views (F10)

- [x] **PLN-21** · M · VIEW-02 · `Modules/GlobalMaster/resources/views/plan/index.blade.php:41-79` — eager-load the two relations the row loop reads.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Before** (`PlanController.php:23-28`):
    ```php
    public function index()
    {
        Gate::authorize('prime.global-master.plan.viewAny');
        $plans = Plan::paginate(10);

        return view('globalmaster::plan.index', compact('plans'));
    }
    ```
  - **After:**
    ```php
    public function index()
    {
        Gate::authorize('prime.global-master.plan.viewAny');
        $plans = Plan::with(['modules:id,name,version', 'billingCycle:id,name'])->paginate(10);

        return view('globalmaster::plan.index', compact('plans'));
    }
    ```
  - **Note for the fixer:** no blade change is needed — the view already reads `plan.modules` and `plan.billingCycle`; eager loading them from the controller removes the N+1.
  - **Verify:** `grep -n "with(\['modules:id,name,version'" Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Expect:** one hit.
  - **Effort:** S

- [x] **PLN-22** · M · F13 (view) · `Modules/GlobalMaster/resources/views/plan/trash.blade.php:28` — show the billing cycle name, not the numeric id.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php`, `Modules/GlobalMaster/resources/views/plan/trash.blade.php`
  - **Before** (`PlanController.php:217-223`):
    ```php
    public function trashedPlan()
    {
        Gate::authorize('prime.global-master.plan.restore');
        $plans = Plan::onlyTrashed()->paginate(10);

        return view('globalmaster::plan.trash', compact('plans'));
    }
    ```
  - **After:**
    ```php
    public function trashedPlan()
    {
        Gate::authorize('prime.global-master.plan.restore');
        $plans = Plan::with(['billingCycle:id,name'])->onlyTrashed()->paginate(10);

        return view('globalmaster::plan.trash', compact('plans'));
    }
    ```
  - **Before** (`trash.blade.php:26-29`):
    ```php
                                        <td>{{ $plan->name }}</td>
                                        <td>{{ $plan->version }}</td>
                                        <td>{{ Str::ucfirst($plan->billing_cycle_id) }}</td>
                                        <td>{{ $plan->trial_days }}</td>
    ```
  - **After:**
    ```php
                                        <td>{{ $plan->name }}</td>
                                        <td>{{ $plan->version }}</td>
                                        <td>{{ $plan->billingCycle?->name ?? '-' }}</td>
                                        <td>{{ $plan->trial_days }}</td>
    ```
  - **Verify:** `grep -n "billingCycle?->name" Modules/GlobalMaster/resources/views/plan/trash.blade.php`
  - **Expect:** one hit.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [x] **PLN-23** · L · STY-01/STY-04 · `Modules/GlobalMaster/app/Http/Controllers/PlanController.php` — controller style: add `declare(strict_types=1);`, drop the emoji markers, delete the four copied "Syntex" activityLog comment blocks.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Before** (`PlanController.php:1-2`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **Before** (`PlanController.php:53-56`):
    ```php
                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($plan, 'Stored', ['message' => 'A new plan was created.', 'other' => 'some other information']);
                // end::Activity Log
    ```
  - **After:**
    ```php
                activityLog($plan, 'Stored', ['message' => 'A new plan was created.', 'other' => 'some other information']);
    ```
  - **Note for the fixer:** repeat the same deletion for the identical Syntex blocks at `PlanController.php:197-200` (destroy), `235-238` (restore) and `263-266` (forceDelete). Remove the two `// 🔹` emoji markers at lines 123 and 142 (leave the words: `// Modules` and `// Track changed attributes`).
  - **Verify:** `grep -nE "🔹|Syntex" Modules/GlobalMaster/app/Http/Controllers/PlanController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **PLN-24** · L · STY-01 · `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php` — add `declare(strict_types=1);`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/PlanRequest.php`
  - **Before** (`PlanRequest.php:1-2`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Requests;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Requests;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/GlobalMaster/app/Http/Requests/PlanRequest.php`
  - **Expect:** one hit.
  - **Effort:** S

- [x] **PLN-16** · L · MDL-04/STY-01/STY-04 · `Modules/GlobalMaster/app/Models/Plan.php` — add relation return types, `declare(strict_types=1);`, delete the commented-out factory import.
  - **Touches:** `Modules/GlobalMaster/app/Models/Plan.php`
  - **Before** (`Plan.php:1-10`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Facades\DB;
    use Modules\Billing\Models\BillingCycle;
    use Modules\Prime\Models\TenantPlan;
    // use Modules\GlobalMaster\Database\Factories\PlanFactory;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\BelongsToMany;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Facades\DB;
    use Modules\Billing\Models\BillingCycle;
    use Modules\Prime\Models\TenantPlan;
    ```
  - **Before** (`Plan.php:46,60,65`):
    ```php
    public function modules()
    ```
  - **After:**
    ```php
    public function modules(): BelongsToMany
    public function tenantPlans(): HasMany
    public function billingCycle(): BelongsTo
    ```
  - **Note for the fixer:** apply `: BelongsToMany` on `modules()`, `: HasMany` on `tenantPlans()`, `: BelongsTo` on `billingCycle()` (each method's first line only; bodies unchanged).
  - **Verify:** `grep -nE "public function (modules|tenantPlans|billingCycle)\(\):" Modules/GlobalMaster/app/Models/Plan.php`
  - **Expect:** three hits.
  - **Effort:** S

- [x] **PLN-17** · L · MDL-04/STY-01 · `Modules/Prime/app/Models/TenantPlan.php` — add relation return types and `declare(strict_types=1);`.
  - **Touches:** `Modules/Prime/app/Models/TenantPlan.php`
  - **Before** (`TenantPlan.php:1-6`):
    ```php
    <?php

    namespace Modules\Prime\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Prime\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    ```
  - **Before** (`TenantPlan.php:34,39,45,50,54`):
    ```php
    public function tenant()
    ```
  - **After:**
    ```php
    public function tenant(): BelongsTo
    public function plan(): BelongsTo
    public function tenantPlanRates(): HasMany
    public function tenantPlanModules(): HasMany
    public function invoices(): HasMany
    ```
  - **Note for the fixer:** apply the matching return type on each of the five relation methods' first lines; bodies unchanged.
  - **Verify:** `grep -nE "public function (tenant|plan|tenantPlanRates|tenantPlanModules|invoices)\(\):" Modules/Prime/app/Models/TenantPlan.php`
  - **Expect:** five hits.
  - **Effort:** S

- [x] **PLN-18** · L · MDL-04/STY-01/STY-04 · `Modules/Prime/app/Models/Tenant.php` — add relation return types, `declare(strict_types=1);`, remove the `⚠` emoji marker comment.
  - **Touches:** `Modules/Prime/app/Models/Tenant.php`
  - **Before** (`Tenant.php:1-6`):
    ```php
    <?php

    namespace Modules\Prime\Models;

    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Prime\Models;

    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Before** (`Tenant.php:113,118,123,128`):
    ```php
    public function city()
    ```
  - **After:**
    ```php
    public function city(): BelongsTo
    public function tenantPlans(): HasMany
    public function billingSchedules(): HasMany
    public function invoices(): HasMany
    ```
  - **Note for the fixer:** apply the matching return type on the four relation methods' first lines; bodies unchanged. Remove the `⚠` marker at line 239, leaving `The former "(No-op while caching is disabled.)" note was STALE` as plain prose.
  - **Verify:** `grep -nE "public function (city|tenantPlans|billingSchedules|invoices)\(\):" Modules/Prime/app/Models/Tenant.php`
  - **Expect:** four hits.
  - **Effort:** S

- [x] **PLN-19** · L · MDL-04/STY-01 · `Modules/Billing/app/Models/BillingCycle.php` — add relation return types and `declare(strict_types=1);`.
  - **Touches:** `Modules/Billing/app/Models/BillingCycle.php`
  - **Before** (`BillingCycle.php:1-6`):
    ```php
    <?php

    namespace Modules\Billing\Models;

    use Illuminate\Database\Eloquent\Factories\HasFactory;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Billing\Models;

    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    ```
  - **Before** (`BillingCycle.php:35,40,45,50`):
    ```php
    public function tenantPlanRates()
    ```
  - **After:**
    ```php
    public function tenantPlanRates(): HasMany
    public function billingSchedules(): HasMany
    public function invoices(): HasMany
    public function plans(): HasMany
    ```
  - **Note for the fixer:** apply `: HasMany` on each of the four relation methods' first lines; bodies unchanged. Keep the existing `use App\Models\BaseModel;` and `use Illuminate\Database\Eloquent\SoftDeletes;` imports.
  - **Verify:** `grep -nE "public function (tenantPlanRates|billingSchedules|invoices|plans)\(\):" Modules/Billing/app/Models/BillingCycle.php`
  - **Expect:** four hits.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **PLN-05** · M · DECISION · TXN-05 — keep or refactor the six transaction closures that build the HTTP response inside `DB::transaction` (store, update, destroy, restore, forceDelete, toggleStatus)?
  - **Why it is a decision:** a 6-site structural rewrite with no user-visible gain; the responses have no side effects, so the current shape is safe.
  - (a) ⭐ Accept as-is (Laravel-legal; the closure's return value becomes the transaction's return value). Record and close.
  - (b) Refactor: each closure returns the saved model/count; the method builds the `redirect()` / `response()` after the transaction. Touches all six methods.
  - (c) Accept and fix opportunistically when the methods are next touched.
  - ➜ Choice: (a) — Tarun 2026-10-17. Accepted as-is; the closures still return the response.

- [x] **PLN-10** · M · DECISION · VAL-05 — `features` and `meta_data` are validated in `PlanRequest` but `prm_plans` has no such columns and they are not fillable, so submitted values are silently discarded. What should happen?
  - **Why it is a decision:** adding columns needs a migration (Tarun's hand); removing the rules is a product call about a possibly-planned feature.
  - (a) ⭐ Remove the two rules from `PlanRequest.php`; nothing sends them today and no column exists (smallest change, matches the DDL).
  - (b) Add real columns via an additive migration, make them fillable, and add form inputs + readers.
  - (c) Leave as-is; record that `features`/`meta_data` are validated-but-dropped.
  - ➜ Choice: (a) — Tarun 2026-10-17. `features` and `meta_data` rules removed from `PlanRequest`.

- [ ] **PLN-11** · H · RTE-01 · DECISION (⚠ SHARED) — restore changes state over GET with no CSRF; every GlobalMaster sibling controller has the same shape.
  - **Why it is a decision:** it touches the shared route file and (in option b) the shared trash-action component, so it is estate-wide in practice.
  - (a) ⭐ Fix this controller only: change `Modules/GlobalMaster/routes/web.php:50` and `:160` to `Route::post('/plan/{id}/restore', ...)` and replace the restore `<a>` (rendered by `x-backend.table.action-trashed`) in `plan/trash.blade.php` with a local CSRF `<form method="POST">` posting to `central.global-master.plan.restore`. Keep the force-delete component.
  - (b) Fix it estate-wide in one coordinated change: POST the restore route for every GlobalMaster sibling AND update the shared `action-trashed` component to emit a form. Bigger blast radius, one component fix.
  - (c) Accept for now; record as a known estate-wide pattern.
  - ➜ Choice: superseded — restore is already POST with the dual-mode `action-trashed` (commit 6d157fb2c, restore family). Left unticked.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PLN-02 | Resolved by PLN-01: with the try removed, the `ValidationException` from `toggleStatus` propagates to the central handler and a 422 reaches the caller instead of a redirect. |
| PLN-03 | Resolved by PLN-01: the catches (and their `Log::error(...getMessage())` lines) are removed; `bootstrap/app.php` logs the full exception. |
| PLN-04 | Resolved by PLN-01: without the catch, `toggleStatus` fails as JSON for requesters that `expectsJson()`, matching its JSON happy path. |
| PLN-06 | Resolved by PLN-20: the batch fix replaces the per-tenant `Tenant::find()` loop, and the cache invalidation noted in PLN-06 sits in the same lines (accepted as low-risk). |