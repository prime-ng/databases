# Fix Plan — GlobalMaster / CityController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/CityController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/app/Models/District.php`, `Models/State.php`, `Models/Country.php` | owned by the Country/State/District reports — usage-checked only, never edited |
| `Modules/GlobalMaster/routes/web.php` — any line OUTSIDE the two city blocks (67-71 and 177-181) | shared with 10 other controllers |
| `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` — any line outside the restore control (markup 1-19, JS 21-36) | ⚠ SHARED — only item CIT-23 may touch it |
| `config/permissionslist.php`, `config/flash.php`, `app/Helpers/*`, `app/Traits/*` | shared globals; nothing here needs changing |
| Existing migrations (`database/migrations/**`, `Modules/GlobalMaster/database/migrations/**`) | never edited. A NEW additive migration only if DECISION CIT-22 is ticked — and never run by the fixer |
| `app/View/Components/Backend/Form/SelectDistrict.php` + its blade | shared component (cross-cutting note in report §7) |

Apply sequencing note: item CIT-01 (§3) rewrites the six mutating methods. Items CIT-07/10/12/16/18 quote current lines that CIT-01 also touches — the fixer re-measures each with grep before editing (final-audit.md §9.2 #3) and records "already applied"/"superseded" when the change landed via CIT-01.

## 1. Blockers reachable today

- [x] **CIT-09** · H · RTE-01 · `Modules/GlobalMaster/routes/web.php:69,179` — make restore a POST route (a GET must never mutate).
  - **Touches:** `Modules/GlobalMaster/routes/web.php` — ⚠ SHARED (route file; only the two city restore lines).
  - **Before** ( `web.php:67-71` — the global-master group; the prime group at 177-181 is byte-identical):
    ```php
        Route::resource('city', CityController::class);
        Route::get('/city/trash/view', [CityController::class, 'trashedCity'])->name('city.trashed');
        Route::get('/city/{id}/restore', [CityController::class, 'restore'])->name('city.restore');
        Route::delete('/city/{id}/force-delete', [CityController::class, 'forceDelete'])->name('city.forceDelete');
        Route::post('/city/{city}/toggle-status', [CityController::class, 'toggleStatus'])->name('city.toggleStatus');
    ```
  - **After:** apply to BOTH the 67-71 block and the 177-181 block:
    ```php
        Route::resource('city', CityController::class);
        Route::get('/city/trash/view', [CityController::class, 'trashedCity'])->name('city.trashed');
        Route::post('/city/{id}/restore', [CityController::class, 'restore'])->name('city.restore');
        Route::delete('/city/{id}/force-delete', [CityController::class, 'forceDelete'])->name('city.forceDelete');
        Route::post('/city/{city}/toggle-status', [CityController::class, 'toggleStatus'])->name('city.toggleStatus');
    ```
  - **Verify:** `grep -n "city/{id}/restore" Modules/GlobalMaster/routes/web.php`
  - **Expect:** exactly two lines, both `Route::post('/city/{id}/restore' ...`; `grep -c "Route::get('/city/{id}/restore'"` returns 0. (The trash-screen link still GETs until CIT-23 is applied — apply CIT-23 next so the screen keeps working.)
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

- [x] **CIT-23** · M · RTE-01 · `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` — turn the restore link into a POST form (mirrors the force-delete button right below it).
  - **Touches:** `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` — ⚠ SHARED (used by every geography trash screen). Apply only after CIT-09.
  - **Before** ( `action-trashed.blade.php:1-19` — current markup, restore anchor wraps inside the force-delete form):
    ```blade
    <form action="{{ route($url . '.forceDelete', $id) }}" method="POST" class="d-inline confirm-action-form-force-delete">
        @csrf
        @method('DELETE')
        <div class="btn-group" role="group" aria-label="Actions">
            <a href="{{ route($url . '.restore', $id) }}" class="btn btn-outline-warning btn-sm confirm-action-restore">
                <i class="fa-solid fa-recycle"></i>
            </a>
            <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fa-solid fa-eraser"></i></button>
        </div>
    </form>
    ```
  - **After:** split the restore anchor into its own POST form:
    ```blade
    <form action="{{ route($url . '.restore', $id) }}" method="POST" class="d-inline confirm-action-form-restore">
        @csrf
        <button type="submit" class="btn btn-outline-warning btn-sm"><i class="fa-solid fa-recycle"></i></button>
    </form>
    <form action="{{ route($url . '.forceDelete', $id) }}" method="POST" class="d-inline confirm-action-form-force-delete">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fa-solid fa-eraser"></i></button>
    </form>
    ```
  - **Before** ( `action-trashed.blade.php:21-36` — current restore JS navigates the window):
    ```js
        document.querySelectorAll('a.confirm-action-restore').forEach(function (link) {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Sure to restore?',
                    text: "Do you want to proceed to restore?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, proceed!'
                }).then(function (result) {
                    if (result.isConfirmed) {
                        window.location.href = link.getAttribute('href');
                    }
                });
            });
        });
    ```
  - **After** (submit the form like the force-delete block below it does):
    ```js
        document.querySelectorAll('form.confirm-action-form-restore').forEach(function (form) {
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Sure to restore?',
                    text: "Do you want to proceed to restore?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, proceed!'
                }).then(function (result) {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        });
    ```
  - **Verify:** `grep -c "confirm-action-form-restore" Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php`
  - **Expect:** 3 (the form class, the JS selector, nothing else); `grep -c "window.location.href = link"` returns 0.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [x] **CIT-01** · H · ERR-00 (D1) · `CityController.php` — remove the try/catch envelope from all six mutating methods; run the write in `DB::transaction`, log via the activity helper, and build the response AFTER the transaction. This one item also lands CIT-02 (validation outside the try in toggleStatus), CIT-03 (the getMessage log lines disappear), CIT-04 (no HTML failure branch for the AJAX toggle), CIT-05 (responses built after the closure), and CIT-06 (the redundant `Gate::authorize` in store/update is dropped because `CityRequest::authorize()` already checks).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/CityController.php`
  - **Before** — imports( `CityController.php:5-13`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\GlobalMaster\Http\Requests\CityRequest;
    use Modules\GlobalMaster\Models\City;
    ```
  - **After:** imports** (ModelNotFoundException and Log become unused once every catch is gone):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\GlobalMaster\Http\Requests\CityRequest;
    use Modules\GlobalMaster\Models\City;
    ```
  - **Before** — store( `CityController.php:41-67`):
    ```php
        public function store(CityRequest $request)
        {
            Gate::authorize('prime.global-master.city.create');

            try {
                return DB::transaction(function () use ($request) {
                    $city = City::create($request->validated());

                    // begin::Activity Log
                    // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                    activityLog($city, 'Stored', ['message' => 'A new city was created.', 'other' => 'some other information']);

                    // end::Activity Log
                    return redirect()->to(route('central.global-master.location-setup.index').'#city')
                        ->with('success', flash('created.city'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('CityController::store failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** store**:
    ```php
        public function store(CityRequest $request)
        {
            $city = DB::transaction(function () use ($request) {
                $city = City::create($request->validated());

                activityLog($city, 'Stored', ['message' => 'A new city was created.', 'other' => 'some other information']);

                return $city;
            });

            return redirect()->to(route('central.global-master.location-setup.index').'#city')
                ->with('success', flash('created.city'));
        }
    ```
  - **Before** — update( `CityController.php:94-145`):
    ```php
        public function update(CityRequest $request, City $city)
        {
            Gate::authorize('prime.global-master.city.update');

            try {
                return DB::transaction(function () use ($request, $city) {
                    $original = $city->getOriginal();
                    $city->update($request->validated());

                    $changes = $city->getChanges();
                    // Build a structured array of changes:
                    $changedAttributes = [];
                    foreach ($changes as $field => $newValue) {
                        // Exclude updated_at and other auto fields
                        if ($field === 'updated_at') {
                            continue;
                        }
                        $changedAttributes[$field] = [
                            'old' => $original[$field] ?? null,
                            'new' => $newValue,
                        ];
                    }

                    // Log only if there are changes
                    if (! empty($changedAttributes)) {
                        activityLog($city, 'Updated', [
                            'message' => 'A new city was updated.',
                            'changes' => $changedAttributes,
                            'performed_by' => Auth::user()->name,
                        ]);
                    } else {
                        activityLog($city, 'Updated', [
                            'message' => 'A new city was updated. No attributes changed.',
                            'performed_by' => Auth::user()->name,
                        ]);
                    }

                    return redirect()
                        ->to(route('central.global-master.location-setup.index').'#city')
                        ->with('success', flash('updated.city'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('CityController::update failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** update** (also fixes the stale "A new city was updated." wording → "City was updated."):
    ```php
        public function update(CityRequest $request, City $city)
        {
            DB::transaction(function () use ($request, $city) {
                $original = $city->getOriginal();
                $city->update($request->validated());

                $changes = $city->getChanges();
                // Build a structured array of changes:
                $changedAttributes = [];
                foreach ($changes as $field => $newValue) {
                    // Exclude updated_at and other auto fields
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changedAttributes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                // Log only if there are changes
                if (! empty($changedAttributes)) {
                    activityLog($city, 'Updated', [
                        'message' => 'City was updated.',
                        'changes' => $changedAttributes,
                        'performed_by' => Auth::user()->name,
                    ]);
                } else {
                    activityLog($city, 'Updated', [
                        'message' => 'City was updated. No attributes changed.',
                        'performed_by' => Auth::user()->name,
                    ]);
                }
            });

            return redirect()
                ->to(route('central.global-master.location-setup.index').'#city')
                ->with('success', flash('updated.city'));
        }
    ```
  - **Before** — destroy( `CityController.php:150-180`):
    ```php
        public function destroy(string $id)
        {
            Gate::authorize('prime.global-master.city.delete');

            try {
                return DB::transaction(function () use ($id) {
                    $city = City::findOrFail($id);
                    $city->is_active = false;
                    $city->save();
                    $city->delete();

                    // begin::Activity Log
                    // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                    activityLog($city, 'Trashed', ['message' => 'A new city was deactivated and deleted.', 'other' => 'some other information']);
                    // end::Activity Log

                    return redirect()
                        ->to(route('central.global-master.location-setup.index').'#city')
                        ->with('success', flash('trashed.city'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('CityController::destroy failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** destroy**:
    ```php
        public function destroy(string $id)
        {
            Gate::authorize('prime.global-master.city.delete');

            DB::transaction(function () use ($id) {
                $city = City::findOrFail($id);
                $city->is_active = false;
                $city->save();
                $city->delete();

                activityLog($city, 'Trashed', ['message' => 'A new city was deactivated and deleted.', 'other' => 'some other information']);
            });

            return redirect()
                ->to(route('central.global-master.location-setup.index').'#city')
                ->with('success', flash('trashed.city'));
        }
    ```
  - **Before** — restore( `CityController.php:192-218`):
    ```php
        public function restore($id)
        {
            Gate::authorize('prime.global-master.city.restore');

            try {
                return DB::transaction(function () use ($id) {
                    $city = City::withTrashed()->findOrFail($id);
                    $city->restore();

                    // begin::Activity Log
                    // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                    activityLog($city, 'Restored', ['message' => 'A new city was restored.', 'other' => 'some other information']);
                    // end::Activity Log

                    return redirect()->route('central.global-master.city.trashed')->with('success', flash('restored.city'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('CityController::restore failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** restore**:
    ```php
        public function restore($id)
        {
            Gate::authorize('prime.global-master.city.restore');

            DB::transaction(function () use ($id) {
                $city = City::withTrashed()->findOrFail($id);
                $city->restore();

                activityLog($city, 'Restored', ['message' => 'A new city was restored.', 'other' => 'some other information']);
            });

            return redirect()->route('central.global-master.city.trashed')->with('success', flash('restored.city'));
        }
    ```
  - **Before** — forceDelete( `CityController.php:227-253`):
    ```php
        public function forceDelete($id)
        {
            Gate::authorize('prime.global-master.city.forceDelete');

            $city = City::withTrashed()->findOrFail($id);

            try {
                return DB::transaction(function () use ($city) {
                    $city->forceDelete();

                    activityLog($city, 'Deleted', ['message' => 'City was permanently deleted.']);

                    return redirect()
                        ->route('central.global-master.city.trashed')
                        ->with('success', flash('force_deleted.city'));
                });
            } catch (\Throwable $e) {
                Log::error('CityController::forceDelete failed', [
                    'id' => $id,
                    'error' => $e->getMessage(),
                ]);

                return redirect()
                    ->route('central.global-master.city.trashed')
                    ->with('error', flash('operation_failed.city'));
            }
        }
    ```
  - **After:** forceDelete( `findOrFail` stays OUTSIDE the transaction — a missing trashed city must 404 natively):
    ```php
        public function forceDelete($id)
        {
            Gate::authorize('prime.global-master.city.forceDelete');

            $city = City::withTrashed()->findOrFail($id);

            DB::transaction(function () use ($city) {
                $city->forceDelete();

                activityLog($city, 'Deleted', ['message' => 'City was permanently deleted.']);
            });

            return redirect()
                ->route('central.global-master.city.trashed')
                ->with('success', flash('force_deleted.city'));
        }
    ```
  - **Before** — toggleStatus( `CityController.php:258-303`):
    ```php
        public function toggleStatus(Request $request, City $city)
        {
            Gate::authorize('prime.global-master.city.update');

            try {
                return DB::transaction(function () use ($request, $city) {
                    $request->validate([
                        'is_active' => 'required|boolean',
                    ]);
                    // get the new desired status
                    $newStatus = $request->input('is_active');
                    $city->is_active = $newStatus;

                    if ($city->save()) {
                        // begin::Activity Log
                        // Logged AFTER save() succeeds, still inside the transaction (Rule 3).
                        // It used to run BEFORE the save: when save() returned false the
                        // else branch reported failure, but the log entry claiming the status
                        // change had already been written in the same transaction.
                        activityLog($city, 'Toggled', ['message' => 'A new city status was updated.', 'other' => 'some other information']);
                        // end::Activity Log

                        return response()->json([
                            'success' => true,
                            'is_active' => $city->is_active,
                            'message' => flash('status_updated.city'),
                        ]);
                    } else {
                        return response()->json([
                            'success' => false,
                            'is_active' => $city->is_active,
                            'message' => flash('status_switch_failed.city'),
                        ]);
                    }

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('CityController::toggleStatus failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** toggleStatus** (validation moves OUTSIDE the transaction so a 422 is a JSON 422 via the central renderer; the `else` branch for `save() === false` is dropped — Eloquent `save()` on an existing row either succeeds or throws):
    ```php
        public function toggleStatus(Request $request, City $city)
        {
            Gate::authorize('prime.global-master.city.update');

            $validated = $request->validate([
                'is_active' => 'required|boolean',
            ]);

            $city = DB::transaction(function () use ($validated, $city) {
                $city->is_active = $validated['is_active'];
                $city->save();

                activityLog($city, 'Toggled', ['message' => 'A new city status was updated.', 'other' => 'some other information']);

                return $city;
            });

            return response()->json([
                'success' => true,
                'is_active' => $city->is_active,
                'message' => flash('status_updated.city'),
            ]);
        }
    ```
  - **Verify:** `grep -c "try {" Modules/GlobalMaster/app/Http/Controllers/CityController.php` AND `grep -c "getMessage" Modules/GlobalMaster/app/Http/Controllers/CityController.php` AND `grep -c "ModelNotFoundException" Modules/GlobalMaster/app/Http/Controllers/CityController.php`
  - **Expect:** 0 from all three greps; then `php -l Modules/GlobalMaster/app/Http/Controllers/CityController.php` prints "No syntax errors detected".
  - **Effort:** M
## 4. Authorization (F3)

No separate item — **CIT-06** (the duplicated permission check on store/update) is applied by CIT-01: the rewritten `store()` and `update()` drop the redundant `Gate::authorize` line because `CityRequest::authorize()` (via `authorizeByCrudPermission`) already rejects un-permitted users before the controller runs. All other methods keep their `Gate::authorize` (the FormRequest is not used on them).

## 5. Validation, routes, models (F4/F5/F7)

- [x] **CIT-07** · H · VAL-04 · `Modules/GlobalMaster/app/Http/Requests/CityRequest.php:22-35` — exclude soft-deleted rows from the name/short_name unique rules so a trashed city no longer blocks re-creating it.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/CityRequest.php`
  - **Before** ( `CityRequest.php:22-35`):
    ```php
            'name' => [
                'required',
                'string',
                'max:50',
                // Unique, but ignore current record when updating
                Rule::unique('glb_cities')->ignore($cityId),
            ],
            'short_name' => [
                'required',
                'string',
                'max:20',
                // Unique, but ignore current record when updating
                Rule::unique('glb_cities')->ignore($cityId),
            ],
    ```
  - **After:**
    ```php
            'name' => [
                'required',
                'string',
                'max:50',
                // Unique, but ignore current record when updating AND ignore soft-deleted rows (CIT-07)
                Rule::unique('glb_cities')->ignore($cityId)->whereNull('deleted_at'),
            ],
            'short_name' => [
                'required',
                'string',
                'max:20',
                // Unique, but ignore current record when updating AND ignore soft-deleted rows (CIT-07)
                Rule::unique('glb_cities')->ignore($cityId)->whereNull('deleted_at'),
            ],
    ```
  - **Verify:** `grep -n "whereNull('deleted_at')" Modules/GlobalMaster/app/Http/Requests/CityRequest.php`
  - **Expect:** exactly 2 lines.
  - **Effort:** S

- [x] **CIT-10** · M · CTL-03 · `Modules/GlobalMaster/app/Http/Controllers/CityController.php` — use route model binding for `edit()` and `destroy()` (their routes already carry `{city}`).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/CityController.php`
  - **Note:** apply after CIT-01 if that item is ticked — CIT-01 rewrites `destroy()` first. Re-measure with `grep -n "public function destroy"` before editing; if the method no longer matches the Before below, apply only the signature/body changes named here (drop `string $id` and the `findOrFail` line, bind `City $city`). `restore()`/`forceDelete()` keep `$id` + `withTrashed()->findOrFail()` — trashed-row binding needs a custom `Route::bind`, deferred.
  - **Before** ( `CityController.php:83-89`):
    ```php
        public function edit(string $id)
        {
            Gate::authorize('prime.global-master.city.update');
            $city = City::findOrFail($id);

            return view('globalmaster::city.edit', compact('city'));
        }
    ```
  - **After:**
    ```php
        public function edit(City $city)
        {
            Gate::authorize('prime.global-master.city.update');

            return view('globalmaster::city.edit', compact('city'));
        }
    ```
  - **Before** ( `CityController.php:150-159` — current destroy opening; if CIT-01 ran first, adapt to the rewritten method):
    ```php
        public function destroy(string $id)
        {
            Gate::authorize('prime.global-master.city.delete');

            try {
                return DB::transaction(function () use ($id) {
                    $city = City::findOrFail($id);
                    $city->is_active = false;
                    $city->save();
                    $city->delete();
    ```
  - **After** (final destroy — signature binds, `findOrFail` line gone, body as in CIT-01's After):
    ```php
        public function destroy(City $city)
        {
            Gate::authorize('prime.global-master.city.delete');

            DB::transaction(function () use ($city) {
                $city->is_active = false;
                $city->save();
                $city->delete();

                activityLog($city, 'Trashed', ['message' => 'A new city was deactivated and deleted.', 'other' => 'some other information']);
            });

            return redirect()
                ->to(route('central.global-master.location-setup.index').'#city')
                ->with('success', flash('trashed.city'));
        }
    ```
  - **Verify:** `grep -n "public function edit(City \$city)\|public function destroy(City \$city)" Modules/GlobalMaster/app/Http/Controllers/CityController.php`
  - **Expect:** 2 lines; `grep -c "findOrFail(\$id)" Modules/GlobalMaster/app/Http/Controllers/CityController.php` then counts only the restore/forceDelete calls (2).
  - **Effort:** S

- [x] **CIT-12** · M · CTL-10/MDL-04 · `Modules/GlobalMaster/app/Models/City.php:31-42` — remove the dead `studentDetails()` relation (its target class does not exist), give `district()` a return type, add `strict_types`.
  - **Touches:** `Modules/GlobalMaster/app/Models/City.php`
  - **Before** ( `City.php:11-43`):
    ```php
    class City extends BaseModel
    {
        use SoftDeletes;
        protected $connection = 'global_master_mysql';

        protected $table = 'glb_cities';

        protected $fillable = [
            'district_id',
            'name',
            'short_name',
            'global_code',
            'default_timezone',
            'is_active',
        ];

        protected $casts = [
            'is_active' => 'boolean',
        ];

        //begin::Eloquent Relationships
        public function district()
        {
            return $this->belongsTo(District::class);
        }


        public function studentDetails()
        {
            return $this->hasMany(StudentDetail::class, 'city_id');
        }
        //end::Eloquent Relationships
    }
    ```
  - **After** (also add the `BelongsTo` import — a separate Before/After at the top of the same file):
    ```php
    class City extends BaseModel
    {
        use SoftDeletes;
        protected $connection = 'global_master_mysql';

        protected $table = 'glb_cities';

        protected $fillable = [
            'district_id',
            'name',
            'short_name',
            'global_code',
            'default_timezone',
            'is_active',
        ];

        protected $casts = [
            'is_active' => 'boolean',
        ];

        //begin::Eloquent Relationships
        public function district(): BelongsTo
        {
            return $this->belongsTo(District::class);
        }
        //end::Eloquent Relationships
    }
    ```
  - **Before** ( `City.php:1-9`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\StudentProfile\Models\StudentDetail;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Verify:** `grep -n "studentDetails\|StudentDetail" Modules/GlobalMaster/app/Models/City.php`
  - **Expect:** no output. Then `grep -n "BelongsTo\|declare(strict_types=1);" Modules/GlobalMaster/app/Models/City.php` → **Expect:** 2 lines (import + return type) plus the strict_types line.
  - **Effort:** S

## 6. Queries & performance (F9)

No separate items — the only F9 finding (CIT-15) is a blade display change and lives in §7.

## 7. Views (F10)

- [x] **CIT-15** · M · QRY-03/VIEW · `Modules/GlobalMaster/resources/views/city/index.blade.php:29` + `trash.blade.php:28` — show the district name (already eager-loaded) instead of the raw `district_id` integer.
  - **Touches:** `Modules/GlobalMaster/resources/views/city/index.blade.php`, `Modules/GlobalMaster/resources/views/city/trash.blade.php`
  - **Before** (both blades share these four lines — `index.blade.php:26-29`, `trash.blade.php:25-28`):
    ```blade
                                @forelse($cities as $city)
                                    <tr class="align-middle">
                                        <td>{{ $city->name }}</td>
                                        <td>{{ $city->district_id }}</td>
    ```
  - **After:** apply the same single-line change in both blades:
    ```blade
                                @forelse($cities as $city)
                                    <tr class="align-middle">
                                        <td>{{ $city->name }}</td>
                                        <td>{{ $city->district?->name }}</td>
    ```
  - **Verify:** `grep -n "district?->name" Modules/GlobalMaster/resources/views/city/index.blade.php Modules/GlobalMaster/resources/views/city/trash.blade.php`
  - **Expect:** 2 lines; `grep -c "district_id" Modules/GlobalMaster/resources/views/city/index.blade.php Modules/GlobalMaster/resources/views/city/trash.blade.php` returns 0.
  - **Effort:** S

- [x] **CIT-16** · M · VIEW/CTL-05 · `Modules/GlobalMaster/resources/views/city/create.blade.php` + `edit.blade.php` — fix the create form's Global Code field (wrong `old()` value) and stop marking the two nullable fields as required (this item also lands CIT-17).
  - **Touches:** `Modules/GlobalMaster/resources/views/city/create.blade.php`, `Modules/GlobalMaster/resources/views/city/edit.blade.php`
  - **Before** (this 3-line snippet exists in BOTH blades — `create.blade.php:49-52`, `edit.blade.php:51-54`):
    ```blade
                                    <x-backend.form.input-text type="text" name="default_timezone"
                                        placeholder="Enter Default Timezone" id="default_timezone"
                                        label="Default Timezone" required="true"
    ```
  - **After:** apply the same in both blades — drop `required="true"`:
    ```blade
                                    <x-backend.form.input-text type="text" name="default_timezone"
                                        placeholder="Enter Default Timezone" id="default_timezone"
                                        label="Default Timezone"
    ```
  - **Before** ( `create.blade.php:41-43` — the Global Code input; wrong `old('short_name')` AND wrongly `required`):
    ```blade
                                    <x-backend.form.input-text type="text" name="global_code"
                                        placeholder="Enter City Global Code" id="global_code" label="Global Code"
                                        required="true" value="{{ old('short_name') }}" />
    ```
  - **After** (correct old value; drop `required` — `global_code` is nullable in `CityRequest`):
    ```blade
                                    <x-backend.form.input-text type="text" name="global_code"
                                        placeholder="Enter City Global Code" id="global_code" label="Global Code"
                                        value="{{ old('global_code') }}" />
    ```
  - **Before** ( `edit.blade.php:42-44` — edit's Global Code input keeps its correct old value but is wrongly `required`):
    ```blade
                                    <x-backend.form.input-text type="text" name="global_code"
                                        placeholder="Enter City Global Code" id="global_code" label="Global Code"
                                        required="true" value="{{ old('global_code', $city->global_code) }}" />
    ```
  - **After:**
    ```blade
                                    <x-backend.form.input-text type="text" name="global_code"
                                        placeholder="Enter City Global Code" id="global_code" label="Global Code"
                                        value="{{ old('global_code', $city->global_code) }}" />
    ```
  - **Verify:** `grep -n "old('short_name')\|label=\"Default Timezone\" required" Modules/GlobalMaster/resources/views/city/create.blade.php Modules/GlobalMaster/resources/views/city/edit.blade.php`
  - **Expect:** no output; `grep -c "old('global_code')" Modules/GlobalMaster/resources/views/city/create.blade.php` returns 1.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [x] **CIT-18** · L · STY-01 · `Modules/GlobalMaster/app/Http/Controllers/CityController.php` — add `declare(strict_types=1);` (the Syntex boilerplate comments are removed by CIT-01's rewrite when that item is ticked; the "A new city was updated." wording is corrected by CIT-01's update After).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/CityController.php`
  - **Before** ( `CityController.php:1-3`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **Verify:** `grep -n "declare(strict_types=1);" Modules/GlobalMaster/app/Http/Controllers/CityController.php`
  - **Expect:** line 2. If CIT-01 was applied, also `grep -n "A new city was updated" Modules/GlobalMaster/app/Http/Controllers/CityController.php` → no output.
  - **Effort:** S

- [x] **CIT-19** · L · STY-01/STY-04 · `Modules/GlobalMaster/app/Http/Requests/CityRequest.php` — add `declare(strict_types=1);` and fix the stale comment that names `prime.city.*` instead of `prime.global-master.city.*`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/CityRequest.php`
  - **Before** ( `CityRequest.php:1-3`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Requests;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Requests;
    ```
  - **Before** ( `CityRequest.php:51-57`):
    ```php
        public function authorize(): bool
        {
            // T6b — mirrors the controller's own gate: prime.city.create on POST,
            // prime.city.update on PUT/PATCH. Same permission, checked one step
            // earlier, so this narrows nothing and widens nothing.
            return $this->authorizeByCrudPermission('prime.global-master.city');
        }
    ```
  - **After:**
    ```php
        public function authorize(): bool
        {
            // Mirrors the controller's own gate: prime.global-master.city.create on POST,
            // prime.global-master.city.update on PUT/PATCH. Same permission, checked one
            // step earlier, so this narrows nothing and widens nothing (CIT-19).
            return $this->authorizeByCrudPermission('prime.global-master.city');
        }
    ```
  - **Verify:** `grep -n "declare(strict_types=1);\|prime.city" Modules/GlobalMaster/app/Http/Requests/CityRequest.php`
  - **Expect:** exactly 1 line (the strict_types declaration); no `prime.city` line.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **CIT-22** · M · DECISION · MDL-07/DDL-wins — give `glb_cities` the DDL's three unique keys in a NEW additive migration?
  - **Why it is a decision:** a new migration (the fixer never runs migrations — that is Tarun's hand), plus a product choice about soft-delete semantics.
  - (a) ⭐ add the three keys exactly as the DDL declares them — safe today (0 duplicates measured on 1592 rows); BUT the keys as written include soft-deleted rows, so a trashed city's name/short name stays blocked forever — which undoes the intent of the CIT-07 fix (re-create after trash).
  - (b) add the keys WITH `deleted_at` in each (e.g. `UNIQUE KEY uq_glb_cities_shortName_deletedAt (short_name, deleted_at)`): MySQL treats NULL as distinct, so one live row and one trashed row may share a name — this matches the CIT-07 fix exactly and still blocks live duplicates.
  - (c) no migration now — keep validation-only uniqueness (the live state today, enforced by `CityRequest` alone); revisit when a real duplicate appears.
  - ➜ Choice: (b) — Tarun 2026-10-17. Migration `2026_10_17_120100_add_soft_delete_aware_unique_keys_to_glb_cities.php` written, NOT run.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CIT-02 | Applied by CIT-01 — `toggleStatus` validation moves outside the transaction and every catch is removed, so a 422 is a JSON 422 from the central renderer, not an HTML redirect. |
| CIT-03 | Applied by CIT-01 — the six `Log::error(..., ['error' => $e->getMessage()])` lines live inside the removed catches and disappear. |
| CIT-04 | Applied by CIT-01 — the rewritten `toggleStatus` has no `back()` failure branch; every response is JSON. |
| CIT-05 | Applied by CIT-01 — every new method returns the model from the closure and builds the redirect/JSON after it. |
| CIT-06 | Applied by CIT-01 — the rewritten `store()`/`update()` drop the redundant `Gate::authorize`; `CityRequest::authorize()` checks the same permission first. |
| CIT-11 | L · deferred — return types on the 11 public methods are added opportunistically with CIT-01/CIT-10 (the rewritten methods are the first targets); a full codemod belongs to the cleanup pass. |
| CIT-14 | Applied by CIT-12 — `district()` gains its `: BelongsTo` return type and `studentDetails()` is removed. |
| CIT-17 | Applied by CIT-16 — the same blade edit removes `required="true"` from `global_code` and `default_timezone`. |
| CIT-20 | Applied by CIT-12 — `declare(strict_types=1);` is added to `City.php` in the same edit. |
| CIT-21 | Accepted, informational — `restore()` leaves `is_active=false`; identical in State/District/Country controllers (house convention), so no change here. |
