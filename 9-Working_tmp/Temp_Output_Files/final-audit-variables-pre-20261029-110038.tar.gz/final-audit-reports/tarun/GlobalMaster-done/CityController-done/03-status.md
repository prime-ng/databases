# Status — GlobalMaster / CityController

**Fixed:** 2026-10-17 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
| ID | What | Where |
|---|---|---|
| CIT-09 | Restore over GET → POST route. | commit `6d157fb2c` (restore family) |
| CIT-23 | Restore control → dual-mode `x-prime.table.action-trashed` (route-checked POST form). Tarun chose dual-mode. | commit `6d157fb2c` |

## 2. Applied
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| CIT-01 (+02/03/04/05/06) | `CityController.php` | Six try/catch envelopes and the `Log::error(getMessage())` lines removed (D1). Responses built after the transaction. `restore()`/`forceDelete()` keep `findOrFail` outside the transaction. `toggleStatus` validates first and returns JSON (`success`/`is_active`/`message`) on every branch. store/update lost their duplicate `Gate::authorize` — `CityRequest::authorize()` checks the same permission first. Update log message now "City was updated." with `changes` + `performed_by`; event literals unchanged. | `grep -n "catch\|Log::"` | no output | 2026-10-17 |
| CIT-07 | `CityRequest.php` | `short_name` unique ignores trashed rows. **Addition approved by Tarun 2026-10-17:** `name` unique is scoped to `district_id` (trashed ignored) — the global rule made the 86 cities that share a name with a city in another district uneditable, and the DDL key is per district. | validator run with real request input | same name same district → `name` error; editing a shared-name city → pass; duplicate short name → `short_name` error | 2026-10-17 |
| CIT-10 | `CityController.php` | `edit(City $city)` and `destroy(City $city)` use route model binding. | route `method_exists` check | routes=22 missing=0 | 2026-10-17 |
| CIT-12 | `City.php` | **Partly applied.** `district(): BelongsTo` typed, `strict_types` added. `studentDetails()` (target class does not exist) is **kept** with a docblock, because `Modules/GlobalMaster/tests/Unit/ModelStructureTest.php:159` asserts it — removal waits for a test decision (same as Board::organizations()). | `get_class($c->district())` | BelongsTo | 2026-10-17 |
| CIT-15 | `city/index.blade.php`, `city/trash.blade.php`, `CityController::trashedCity` | Null-safe `{{ $city->district?->name }}`; trash query adds `->with('district')` (not in the plan — needed because the trash blade now prints the district). | rolled-back trash → eager check | district loaded | 2026-10-17 |
| CIT-16 (+17) | `city/create.blade.php`, `city/edit.blade.php` | `required="true"` dropped from Default Timezone and Global Code; create Global Code uses `old('global_code')`. | `grep -n 'global_code'` | no `required`, `old('global_code')` present | 2026-10-17 |
| CIT-18 | `CityController.php` | `strict_types`, return types on all 11 methods. | `php -l` + `class_exists` | clean / true | 2026-10-17 |
| CIT-19 | `CityRequest.php` | `strict_types`; `prepareForValidation(): void`; authorize comment corrected. | head of file | present | 2026-10-17 |
| CIT-22 | new migration `2026_10_17_120100_add_soft_delete_aware_unique_keys_to_glb_cities.php` | DECISION (b). Adds `uq_glb_cities_districtId_name (district_id, name, deleted_at)`, `uq_glb_cities_shortName (short_name, deleted_at)`, `uq_glb_cities_globalCode (global_code, deleted_at)`. Measured first: 1592 rows, 0 duplicates on each key. **Written, NOT run.** | `php -l` | clean | 2026-10-17 |

## 3. Not applied
- CIT-11 — deferred in the plan; return types were added anyway under CIT-18.
- CIT-21 — accepted, informational.
- CIT-12 relation removal — blocked on the test decision above.

## 4. Needs Tarun's hand
- **Run the migration** on `global_master_mysql`: `2026_10_17_120100_add_soft_delete_aware_unique_keys_to_glb_cities.php`. Until it runs, uniqueness is enforced by `CityRequest` alone.
- **Test decision:** `ModelStructureTest.php:159` asserts `City::studentDetails()` (target class missing); `:158` already asserts a non-existent `organizationGroups` (pre-existing red).
- Browser check: `/global-master/location-setup#city` — create, edit a shared-name city, toggle, trash → restore → force-delete.

## 5. Unverifiable by this workflow (D4)
- Store/update authorization relies on `CityRequest::authorize()`; every check here ran as super admin.

## 6. Verification log
```
vendor/bin/pint <4 files> --format agent            → clean after formatting
php -l <4 files>                                     → No syntax errors
class_exists(CityController|CityRequest|City)        → true ×3
route:list --json (uncached) + method_exists         → routes=22 missing=0
render location-setup / create / trashed             → 200 · 3,554,743 / 199,387 / 114,688 bytes, 0 comment leaks
render edit / show (after DecryptUrl redirect)       → 200 · 199,510 / 116,238 bytes
validator: dup same district / edit shared-name / dup short → ["name"] / [] / ["short_name"]
rolled-back create → deactivate+delete → eager trash read → restore → trashed+eager yes / restored yes; 0 rows after rollback
```

## 7. Final state
**FIXED** (code). Open: run the CIT-22 migration; CIT-12 test decision.

## 8. Follow-up 2026-10-17: the transactions did not cover the record (AFC-09)

Found while fixing AppConfigController. `City` saves through `global_master_mysql`, but every `DB::transaction()` in this controller opened on the default `mysql` connection, where only `activityLog()` writes. These are two separate PDO handles, so the 6 transactions covered only the log. A failure after the save rolled back the audit row and left the record changed.

**Applied:** all 6 calls now use `WritesGlobalMaster::inGlobalMasterTransaction()` (new trait, `Http/Controllers/Concerns/`), which opens a `global_master_mysql` transaction around the default one. Tarun approved fixing all six FIXED controllers together.

**Verified:** `php -l` clean · class loads · every routed method exists · host page renders 200 · a simulated failure through this controller's helper rolls back both the record and the log · negative control: plain `DB::transaction` left the global_master write in place.
