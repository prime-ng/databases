# Final Audit — GlobalMaster / CityController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/CityController.php` (305 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/global-master/city` (list), `/global-master/city/create`, `/global-master/city/{city}` (show), `/global-master/city/{city}/edit`, `/global-master/city/trash/view`, plus an identical `/prime/city…` copy. Create/update/delete all redirect to `http://test.localhost:8000/global-master/location-setup#city`. |
| Menu path | Global Master → Location Setup (the city tab on the geography master screen). |
| Who uses it | Platform / super-admin side. Holders of `prime.global-master.city.{create,view,viewAny,update,delete,restore,forceDelete}` — seeded to Super Admin automatically; read-only grants to `global-master.city` holders per `Modules/Prime/database/seeders/RolePermissionSeeder.php:66,149,198`. |
| What a user does here | A school-platform operator maintains the city list used by every tenant's student/organisation records: adds a city under a district, edits its name/short name/global code/timezone/active flag, views one, trash-restores-force-deletes it, and toggles its active status from the list. |
| Tables written | `glb_cities` (via the `City` model on the `global_master_mysql` connection), `sys_activity_logs` (via the common `activityLog()` helper). |
| Tables read | `glb_cities`, `glb_districts`, `glb_states`, `glb_countries` (eager-loaded), and `glb_districts` again inside the shared `SelectDistrict` component on create/edit. |
| Live data | `glb_cities` 1592 live, 0 trashed (measured on test.localhost via tinker). The live table has ONLY `PRIMARY (id)` and `glb_cities_district_id_foreign (district_id)` — the three unique keys declared in the DDL do not exist in the live DB (see §7). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready: three H findings sit on real screens. The worst is **CIT-09**: `restore` is exposed as a plain GET route — the trash screen's "restore" button is an `<a href>` link, so a prefetcher, a crawler, or an accidental click restores a trashed city with no CSRF and no POST confirmation. **CIT-02** turns any validation failure on the status toggle (an AJAX call) into an HTML redirect the caller cannot read. **CIT-07** (soft-delete × uniqueness) blocks a normal workflow: once a city is trashed, its name/short name can never be re-created — the validation rules count soft-deleted rows as live. Everything else is the retired house "A1" try/catch pattern (which protocol D1 now bans), one business-logic display bug, and maintainability/style debt. Rough effort to fix the plan: S–M — the fixes are mechanical, mostly removing the try/catch envelope, plus one edit to the shared route file (marked ⚠ SHARED).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 4 | 9 | 7 | 1 | 21 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CIT-01, CIT-02, CIT-03, CIT-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | CIT-05 | F9 Queries/Perf | CIT-15 |
| F3 Authorization | CIT-06 | F10 Views | CIT-16, CIT-17, CIT-23 |
| F4 Validation | CIT-07 | F11 Security/Tenancy | clean |
| F5 Routes | CIT-09 | F12 Style | CIT-18, CIT-19, CIT-20 |
| F6 Controller shape | CIT-10, CIT-11 | F13 Deep read | CIT-21 |
| F7 Models | CIT-12, CIT-14, CIT-22 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/CityController.php` | controller | 305 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Models/City.php` | model | 43 | this report (claimed in 00-CLASS-OWNERS.md) | ✅ |
| 3 | `Modules/GlobalMaster/app/Http/Requests/CityRequest.php` | form request | 58 | this report (claimed in 00-CLASS-OWNERS.md) | ✅ |
| 4 | `Modules/GlobalMaster/routes/web.php` (lines 67-71 and 177-181 only) | route file | 198 | ⚠ SHARED — city rows only | ✅ usage; edits are ⚠ SHARED |
| 5 | `Modules/GlobalMaster/resources/views/city/index.blade.php` | view | 62 | this report | ✅ |
| 6 | `Modules/GlobalMaster/resources/views/city/create.blade.php` | view | 71 | this report | ✅ |
| 7 | `Modules/GlobalMaster/resources/views/city/edit.blade.php` | view | 73 | this report | ✅ |
| 8 | `Modules/GlobalMaster/resources/views/city/show.blade.php` | view | 84 | this report | ✅ |
| 9 | `Modules/GlobalMaster/resources/views/city/trash.blade.php` | view | 57 | this report | ✅ |
| 10 | `Modules/GlobalMaster/app/Models/District.php` | model | 47 | ↗ [CountryController/StateController/DistrictController](../CountryController-done/01-report.md) | ↗ linked — usage-check only (relation resolves, see F7 evidence) |
| 11 | `Modules/GlobalMaster/app/Models/State.php`, `Models/Country.php` | model | — | ↗ linked (Country/State/District controllers) | ↗ linked — usage-check only |
| 12 | `App\Http\Controllers\Controller`, `App\Traits\AuthorizesTenantFeature`, `App\Models\BaseModel`, `app/Helpers/activityLog.php`, `app/Helpers/helpers.php` (flash), `config/flash.php`, `config/permissionslist.php`, `Resources/views/components/backend/form/select-district.blade.php` + `App\View\Components\Backend\Form\SelectDistrict.php`, `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` | common | — | common (§4.2) | referenced, not owned |

No pre-applied files — no `PRE-APPLIED-2026-10-10.md` exists for GlobalMaster.

## 4. Routes

Uncached route list filtered for `CityController@` (from the fresh `/tmp/fa-routes.json`, generated with `APP_ROUTES_CACHE=/tmp/fa-nocache.php`):

```
GET|HEAD global-master/city                                           central.global-master.city.index         CityController@index
POST    global-master/city                                           central.global-master.city.store         CityController@store
GET|HEAD global-master/city/create                                    central.global-master.city.create        CityController@create
GET|HEAD global-master/city/trash/view                                central.global-master.city.trashed       CityController@trashedCity
GET|HEAD global-master/city/{city}                                    central.global-master.city.show          CityController@show
PUT|PATCH global-master/city/{city}                                   central.global-master.city.update        CityController@update
DELETE  global-master/city/{city}                                    central.global-master.city.destroy       CityController@destroy
GET|HEAD global-master/city/{city}/edit                               central.global-master.city.edit          CityController@edit
POST    global-master/city/{city}/toggle-status                       central.global-master.city.toggleStatus  CityController@toggleStatus
DELETE  global-master/city/{id}/force-delete                          central.global-master.city.forceDelete   CityController@forceDelete
GET|HEAD global-master/city/{id}/restore                              central.global-master.city.restore       CityController@restore
— identical set repeated under `prime/city…` with names `central.prime.city.*` (web.php lines 177-181)
```

All routes sit inside `Route::domain(config('app.domain'))` (central only) with `['auth','verified']` middleware — RTE-05 is clean. Unrouted public methods: none — all 11 public methods are routed (RTE-03 clean; RTE-02 clean: every route name resolves to an existing method).

Route file shape (`Modules/GlobalMaster/routes/web.php:67-71`, repeated at 177-181): `Route::resource('city', …)` comes first, then the four custom routes. The custom URIs (`/city/trash/view`, `/city/{id}/restore`, `/city/{id}/force-delete`, `/city/{city}/toggle-status`) cannot be captured by the resource's `/{city}` single segment, so RTE-06 is not triggered.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 20 | GET /global-master/city | `prime.global-master.city.viewAny` | none (read) | — | — | CIT-15 |
| `create` | 31 | GET /global-master/city/create | `prime.global-master.city.create` | none (read) | — | — | — |
| `store` | 41 | POST /global-master/city | `prime.global-master.city.create` (+ FormRequest) | controller `DB::transaction` | Stored | glb_cities, sys_activity_logs | CIT-01, CIT-03, CIT-05, CIT-06, CIT-07, CIT-21 |
| `show` | 72 | GET /global-master/city/{city} | `prime.global-master.city.view` | none (read) | — | — | — |
| `edit` | 83 | GET /global-master/city/{city}/edit | `prime.global-master.city.update` | none (read) | — | — | CIT-10 |
| `update` | 94 | PUT/PATCH /global-master/city/{city} | `prime.global-master.city.update` (+ FormRequest) | controller `DB::transaction` | Updated | glb_cities, sys_activity_logs | CIT-01, CIT-03, CIT-05, CIT-06, CIT-07, CIT-21 |
| `destroy` | 150 | DELETE /global-master/city/{city} | `prime.global-master.city.delete` | controller `DB::transaction` | Trashed | glb_cities, sys_activity_logs | CIT-01, CIT-03, CIT-05, CIT-10, CIT-21 |
| `trashedCity` | 184 | GET /global-master/city/trash/view | `prime.global-master.city.restore` | none (read) | — | — | CIT-15 |
| `restore` | 192 | GET /global-master/city/{id}/restore | `prime.global-master.city.restore` | controller `DB::transaction` | Restored | glb_cities, sys_activity_logs | CIT-01, CIT-03, CIT-05, CIT-09, CIT-10, CIT-21 |
| `forceDelete` | 227 | DELETE /global-master/city/{id}/force-delete | `prime.global-master.city.forceDelete` | controller `DB::transaction` | Deleted | glb_cities, sys_activity_logs | CIT-01, CIT-03, CIT-05, CIT-10, CIT-21 |
| `toggleStatus` | 258 | POST /global-master/city/{city}/toggle-status | `prime.global-master.city.update` | controller `DB::transaction` | Toggled | glb_cities, sys_activity_logs | CIT-01, CIT-02, CIT-03, CIT-04, CIT-05, CIT-21 |
## 6. Findings

### F1 — Errors

#### CIT-01 · H · ERR-00 (settled by D1) — controller-wide try/catch, six blocks

| Field | Value |
|---|---|
| **Rule** | ERR-00 (H, raised from "undecided" by protocol D1) — *the Laravel idiom: no try/catch in controllers; a controller try/catch is a finding unless D2 allows it* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CityController.php:45-66` (store), `:98-144` (update), `:154-179` (destroy), `:196-217` (restore), `:233-252` (forceDelete), `:262-302` (toggleStatus) |
| **Root cause** | The controller follows the retired house "Rule A1" shape (`try { DB::transaction(...) } catch (ModelNotFoundException) { throw } catch (\Throwable) { log; redirect }`). Protocol D1 supersedes A1 for audited modules; none of the D2 exceptions apply (no `\DomainException`, no truncate-then-rebuild, no `SnapshotProtectionException`). |
| **Consequence** | Every mutating method duplicates ~20 lines of error plumbing; the generic catch turns any unexpected failure (QueryException, ValidationException, …) into a generic redirect, hiding the true status the central renderer (`bootstrap/app.php`) would produce. |
| **Reproduce** | Static only — cast a DB error during store and observe the falsified "The operation could not be completed." redirect instead of a 500 that the central handler owns. |
| **Fix approach** | Remove the `try`/`catch` envelope from all six methods; keep `DB::transaction(fn () => …)` and let exceptions bubble to `bootstrap/app.php`. The `ModelNotFoundException` rethrows become unnecessary — D1 removes the swallow risk entirely. |
| **Plan item** | CIT-01 in `02-fix-plan.md` §3 |

```php
// CityController.php:45-66 — CURRENT (store; update/destroy/restore/toggleStatus identical shape; forceDelete at 233-252)
        try {
            return DB::transaction(function () use ($request) {
                $city = City::create($request->validated());

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($city, 'Stored', ['message' => 'A new city was created.', 'other' => 'some other information']);

                // end::Activity Log
                return redirect()->to(route('central.global-master.location-setup.index').'#city')
                    ->with('success', flash('created.city'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('CityController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -c "try {" Modules/GlobalMaster/app/Http/Controllers/CityController.php
6
$ grep -c "getMessage" Modules/GlobalMaster/app/Http/Controllers/CityController.php
6
```

#### CIT-02 · H · ERR-02 — toggleStatus swallows a 422 and answers an AJAX caller with a redirect

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422/`abort()` into a redirect or 500* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CityController.php:262-302`, method `toggleStatus()` |
| **Root cause** | `$request->validate([...])` runs **inside** the `try`, and the generic `catch (\Throwable $e)` catches the `ValidationException` it throws. (`findOrFail` is also inside a try in destroy/restore, but the `ModelNotFoundException` re-throw preserves the 404 there, so the broken path is the validation one.) |
| **Consequence** | A bogus `is_active` value from the status-switch AJAX call returns a `back()` HTML redirect (302 with an HTML page) instead of a JSON 422; the checkbox flips back with no message. |
| **Reproduce** | `curl -X POST http://test.localhost:8000/global-master/city/{city}/toggle-status -d 'is_active=banana'`. Expected JSON 422; actual 302 HTML redirect. |
| **Fix approach** | Move the `validate()` above the transaction and remove the try — under D1 there is no catch left to swallow it, and the central handler renders a JSON 422 for `$request->expectsJson()`. |
| **Plan item** | CIT-02 in `02-fix-plan.md` §3 |

```php
// CityController.php:262-302 — CURRENT (validate sits inside try; catch (\Throwable) swallows ValidationException)
        try {
            return DB::transaction(function () use ($request, $city) {
                $request->validate([
                    'is_active' => 'required|boolean',
                ]);
                // get the new desired status
                $newStatus = $request->input('is_active');
                $city->is_active = $newStatus;

                if ($city->save()) {
                    // begin::Activity Log
                    // Logged AFTER save() succeeds, still inside the transaction (Rule 3).
                    // It used to run BEFORE the save: when save() returned false the
                    // else branch reported failure, but the log entry claiming the status
                    // change had already been written in the same transaction.
                    activityLog($city, 'Toggled', ['message' => 'A new city status was updated.', 'other' => 'some other information']);
                    // end::Activity Log

                    return response()->json([
                        'success' => true,
                        'is_active' => $city->is_active,
                        'message' => flash('status_updated.city'),
                    ]);
                } else {
                    return response()->json([
                        'success' => false,
                        'is_active' => $city->is_active,
                        'message' => flash('status_switch_failed.city'),
                    ]);
                }

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('CityController::toggleStatus failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "validate(\|catch (\\Throwable" Modules/GlobalMaster/app/Http/Controllers/CityController.php
264:                $request->validate([
298:        } catch (\Throwable $e) {
```

#### CIT-03 · M · ERR-05 — six log calls drop the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CityController.php:63,141,176,214,244,299` (store, update, destroy, restore, forceDelete, toggleStatus) |
| **Root cause** | The retired A1 catch template logs `['error' => $e->getMessage()]` — exactly the anti-pattern the rulebook's Contradictions table bans. |
| **Consequence** | Every failure is logged without a stack trace; the message alone cannot locate the failing call, and raw SQL text leaks into the log file. |
| **Reproduce** | Static only — break a constraint while updating and read the log line: no exception class, no trace. |
| **Fix approach** | With the try removed (CIT-01) the `Log::error` lines disappear entirely; nothing must log `.getMessage()` alone. |
| **Plan item** | CIT-03 is applied by CIT-01 (the log lines live inside the removed catches); no separate item — see §10. |

```php
// CityController.php:63 — CURRENT (identical at 141, 176, 214, 244, 299)
            Log::error('CityController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "Log::error" Modules/GlobalMaster/app/Http/Controllers/CityController.php
63:            Log::error('CityController::store failed', ['error' => $e->getMessage()]);
141:            Log::error('CityController::update failed', ['error' => $e->getMessage()]);
176:            Log::error('CityController::destroy failed', ['error' => $e->getMessage()]);
214:            Log::error('CityController::restore failed', ['error' => $e->getMessage()]);
244:            Log::error('CityController::forceDelete failed', [
299:            Log::error('CityController::toggleStatus failed', ['error' => $e->getMessage()]);
```

#### CIT-04 · M · ERR-04 — toggleStatus mixes JSON and HTML failure paths without expectsJson()

| Field | Value |
|---|---|
| **Rule** | ERR-04 (M) — *JSON endpoints fail with JSON; form endpoints fail with a redirect; use `$request->expectsJson()` when one method serves both* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CityController.php:280-301`, method `toggleStatus()` |
| **Root cause** | The success branch returns `response()->json(...)` but every failure branch returns `back()->with('error', ...)` (HTML). The endpoint is only ever called by the AJAX status switch. |
| **Consequence** | Any failure (validation, DB) delivers HTML to the JSON caller; the toggle silently fails with no user message. |
| **Reproduce** | `curl -X POST http://test.localhost:8000/global-master/city/{city}/toggle-status` without `is_active` — inspect the response `Content-Type`: `text/html`, not JSON. |
| **Fix approach** | Remove the try (no catch to return HTML), keep `$request->validate()` outside the transaction so the 422 the central renderer produces is JSON for AJAX. If a catch is ever reintroduced, branch on `$request->expectsJson()`. |
| **Plan item** | CIT-04 in `02-fix-plan.md` §3 |

```php
// CityController.php:280-301 — CURRENT (JSON success, HTML failure)
                    return response()->json([
                        'success' => true,
                        'is_active' => $city->is_active,
                        'message' => flash('status_updated.city'),
                    ]);
                } else {
                    return response()->json([
                        'success' => false,
                        'is_active' => $city->is_active,
                        'message' => flash('status_switch_failed.city'),
                    ]);
                }

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('CityController::toggleStatus failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "response()->json\|back()" Modules/GlobalMaster/app/Http/Controllers/CityController.php
65:            return back()->with('error', 'The operation could not be completed.');
143:            return back()->with('error', 'The operation could not be completed.');
178:            return back()->with('error', 'The operation could not be completed.');
216:            return back()->with('error', 'The operation could not be completed.');
280:                    return response()->json([
286:                    return response()->json([
301:            return back()->with('error', 'The operation could not be completed.');
```

### F2 — Transactions and audit

#### CIT-05 · M · TXN-05 — redirects/JSON responses built inside the transaction closure in all six mutating methods

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()` / `response()` after it* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CityController.php:54-57, 131-134, 166-169, 206, 239-242, 280-291` (store, update, destroy, restore, forceDelete, toggleStatus) |
| **Root cause** | Each closure `return`s a `redirect()->to(...)` / `response()->json(...)` while the transaction is still open; the commit only happens because the closure returns the response. |
| **Consequence** | The transaction stays open while the response object and flash session write are assembled; harmless today but the wrong shape, and it forces the `return`-inside-closure that TXN-05 calls out. |
| **Reproduce** | Static only — read any of the six closures. |
| **Fix approach** | Have the closure return the model (or `true`), then build the redirect/JSON outside it: `$city = DB::transaction(fn () => ...); return redirect()->to(...);` |
| **Plan item** | CIT-05 in `02-fix-plan.md` §3 |

```php
// CityController.php:46-57 — CURRENT (store; same return-inside-closure shape at 99-134, 155-169, 197-206, 234-242, 263-291)
            return DB::transaction(function () use ($request) {
                $city = City::create($request->validated());

                // begin::Activity Log
                activityLog($city, 'Stored', ['message' => 'A new city was created.', 'other' => 'some other information']);
                // end::Activity Log
                return redirect()->to(route('central.global-master.location-setup.index').'#city')
                    ->with('success', flash('created.city'));

            });
```

**Evidence**
```
$ grep -n "return DB::transaction\|return redirect\|return response" Modules/GlobalMaster/app/Http/Controllers/CityController.php
46:            return DB::transaction(function () use ($request) {
55:                    ->with('success', flash('created.city'));
99:            return DB::transaction(function () use ($request, $city) {
131:                return redirect()
155:            return DB::transaction(function () use ($id) {
166:                return redirect()
197:            return DB::transaction(function () use ($id) {
206:                return redirect()->route('central.global-master.city.trashed')->with('success', flash('restored.city'));
234:            return DB::transaction(function () use ($city) {
239:                return redirect()
263:            return DB::transaction(function () use ($request, $city) {
280:                    return response()->json([
```

### F3 — Authorization

#### CIT-06 · L · AUTH-04 — the same permission is checked twice on store and update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CityController.php:43,96` + `Modules/GlobalMaster/app/Http/Requests/CityRequest.php:51-57` |
| **Root cause** | `CityRequest::authorize()` maps POST→`prime.global-master.city.create` and PUT/PATCH→`prime.global-master.city.update`, and the controller calls `Gate::authorize` for the same names immediately after. The FormRequest runs first, so the controller call can never change the outcome. |
| **Consequence** | Duplicated logic that drifts when one side is edited; a second place to get the permission name wrong. |
| **Reproduce** | Static only — read both files. |
| **Fix approach** | Keep the FormRequest `authorize()` (it runs first) and drop the two `Gate::authorize` calls in `store()`/`update()` — or keep the controller gates and strip the request trait. Preference: keep the request, since it is the project's FormRequest rule. |
| **Plan item** | CIT-06 in `02-fix-plan.md` §4 |

```php
// CityRequest.php:51-57 — CURRENT (the FormRequest authorize that already gates store/update)
    public function authorize(): bool
    {
        return $this->authorizeByCrudPermission('prime.global-master.city');
    }
```
```php
// CityController.php:41-43 — CURRENT (the duplicate controller gate)
    public function store(CityRequest $request)
    {
        Gate::authorize('prime.global-master.city.create');
```

**Evidence**
```
$ grep -n "Gate::authorize\|authorizeByCrudPermission" Modules/GlobalMaster/app/Http/Controllers/CityController.php Modules/GlobalMaster/app/Http/Requests/CityRequest.php
CityController.php:22:        Gate::authorize('prime.global-master.city.viewAny');
CityController.php:33:        Gate::authorize('prime.global-master.city.create');
CityController.php:43:        Gate::authorize('prime.global-master.city.create');
CityController.php:74:        Gate::authorize('prime.global-master.city.view');
CityController.php:85:        Gate::authorize('prime.global-master.city.update');
CityController.php:96:        Gate::authorize('prime.global-master.city.update');
CityController.php:152:        Gate::authorize('prime.global-master.city.delete');
CityController.php:186:        Gate::authorize('prime.global-master.city.restore');
CityController.php:194:        Gate::authorize('prime.global-master.city.restore');
CityController.php:229:        Gate::authorize('prime.global-master.city.forceDelete');
CityController.php:260:        Gate::authorize('prime.global-master.city.update');
CityRequest.php:56:        return $this->authorizeByCrudPermission('prime.global-master.city');
```

### F4 — Validation and input

#### CIT-07 · H · VAL-04 — uniqueness rules treat soft-deleted rows as live; a trashed city blocks re-use of its name/short name

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H, raised from H default with reason *false rejection, not a 500 — the live table has no unique index, see §7*) — *uniqueness rules mirror the DB unique index including soft-delete semantics* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/CityRequest.php:18-39`, rules for `name` and `short_name` |
| **Root cause** | `Rule::unique('glb_cities')->ignore($cityId)` has no `->whereNull('deleted_at')`. Laravel's unique rule counts **all** rows in `glb_cities` except the ignored id — including soft-deleted ones. `glb_cities` has a `deleted_at` column (SoftDeletes on `City`), so a trashed city's name/short_name is still counted. |
| **Consequence** | A user trashes "Delhi", then the same school district needs "Delhi" again: the create form returns "The name has already been taken." / "The short name has already been taken." until the old row is force-deleted. The same block hits `update` when any trashed row shares the value. |
| **Reproduce** | Trash any city, then create a new city with its exact `name` and `short_name` — the form rejects it. |
| **Fix approach** | Add `->whereNull('deleted_at')` to both unique rules so trashed rows are excluded. This mirrors the app's intent (the DDL declares unique keys without `deleted_at`, so the DB itself would also block a re-create — see §7 cross-cutting note; the rule change alone is not enough if the DDL unique keys are ever applied to the live DB). |
| **Plan item** | CIT-07 in `02-fix-plan.md` §5 |

```php
// CityRequest.php:22-35 — CURRENT
            'name' => [
                'required',
                'string',
                'max:50',
                // Unique, but ignore current record when updating
                Rule::unique('glb_cities')->ignore($cityId),
            ],
            'short_name' => [
                'required',
                'string',
                'max:20',
                // Unique, but ignore current record when updating
                Rule::unique('glb_cities')->ignore($cityId),
            ],
```

**Evidence**
```
$ grep -n "Rule::unique" Modules/GlobalMaster/app/Http/Requests/CityRequest.php
27:                Rule::unique('glb_cities')->ignore($cityId),
34:                Rule::unique('glb_cities')->ignore($cityId),
$ grep -n "deleted_at" Modules/GlobalMaster/database/migrations/2025_10_09_042951_create_cities_table.php
27:            $table->softDeletes();
```

### F5 — Routes

#### CIT-09 · H · RTE-01 — restore is a GET route; the trash screen wires it as a plain link

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, ...); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/GlobalMaster/routes/web.php:69` and `:179` (`Route::get('/city/{id}/restore', ...)`), controller `restore()` at `Modules/GlobalMaster/app/Http/Controllers/CityController.php:192-218` |
| **Root cause** | `restore()` un-deletes a row (a write), but the route is `GET`. The shared trash-row component renders it as `<a href="{{ route($url.'.restore', $id) }}">` — a plain link with only a JS confirm (see §7 cross-cutting note about `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php`). |
| **Consequence** | A prefetcher, a crawler, or a mis-click restores a trashed city with no CSRF token; the destructive intent is not confirmed by anything the browser cannot skip. |
| **Reproduce** | Visit `http://test.localhost:8000/global-master/city/999/restore` with the id of any trashed city — the city is restored on GET. |
| **Fix approach** | Change the route to `POST` (or `DELETE`), change the shared component to submit a small form like the force-delete button does, keep the JS confirm. This is a ⚠ SHARED change (route file + shared PrimeCore component). |
| **Plan item** | CIT-09 in `02-fix-plan.md` §1 (⚠ SHARED) |

```php
// Modules/GlobalMaster/routes/web.php:67-71 — CURRENT
        Route::resource('city', CityController::class);
        Route::get('/city/trash/view', [CityController::class, 'trashedCity'])->name('city.trashed');
        Route::get('/city/{id}/restore', [CityController::class, 'restore'])->name('city.restore');
        Route::delete('/city/{id}/force-delete', [CityController::class, 'forceDelete'])->name('city.forceDelete');
        Route::post('/city/{city}/toggle-status', [CityController::class, 'toggleStatus'])->name('city.toggleStatus');
```

**Evidence**
```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); foreach($r as $x){ if(str_contains($x["action"]??"","CityController")) printf("%-7s %-50s %s\n",$x["method"],$x["uri"],$x["name"]??"-"); }'
GET|HEAD global-master/city/{id}/restore              central.global-master.city.restore
GET|HEAD prime/city/{id}/restore                      central.prime.city.restore
```

### F6 — Controller shape

#### CIT-10 · M · CTL-03 — four methods take `string $id` + `findOrFail()` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(City $city)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CityController.php:83-89` (edit), `:150-152` (destroy), `:192-194` (restore), `:227-231` (forceDelete) |
| **Root cause** | `show`, `update` and `toggleStatus` already type-hint `City $city` and get the 404 for free. The four trash/lifecycle methods use `string $id` + `City::findOrFail($id)` / `City::withTrashed()->findOrFail($id)` instead — the route parameters are passed positionally by Laravel, so it works, but it re-implements what binding gives free. |
| **Consequence** | More code per method; `destroy`'s resource route parameter is `{city}` while `restore`/`forceDelete` use `{id}` — two parameter names for the same resource, an easy renaming trap. |
| **Reproduce** | Static only. |
| **Fix approach** | Convert `edit(City $city)`, `destroy(City $city)`, `restore(City $city)` (needs `->withTrashed()` binding), `forceDelete(City $city)`; align the custom route parameters to `{city}`. Optional — DEFERRED acceptable (D3), low risk. |
| **Plan item** | CIT-10 in `02-fix-plan.md` §5 |

```php
// CityController.php:83-89 — CURRENT (edit; destroy(string $id) + findOrFail at 150-159; restore($id) at 192-199; forceDelete($id) at 227-231)
    public function edit(string $id)
    {
        Gate::authorize('prime.global-master.city.update');
        $city = City::findOrFail($id);

        return view('globalmaster::city.edit', compact('city'));
    }
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+' Modules/GlobalMaster/app/Http/Controllers/CityController.php
20:    public function index()
31:    public function create()
41:    public function store(CityRequest $request)
72:    public function show(City $city)
83:    public function edit(string $id)
94:    public function update(CityRequest $request, City $city)
150:    public function destroy(string $id)
184:    public function trashedCity()
192:    public function restore($id)
227:    public function forceDelete($id)
258:    public function toggleStatus(Request $request, City $city)
```

#### CIT-11 · L · CTL-04 — no return types on any of the 11 public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CityController.php` — all 11 methods (lines listed in CIT-10 evidence) |
| **Root cause** | No method declares a return type. |
| **Consequence** | The PHP/IDE cannot enforce the contract; every response shape is implicit. |
| **Reproduce** | Static only. |
| **Fix approach** | Add return types when each method is touched: `index/create/edit/show`: `\Illuminate\Contracts\View\View`; `store/update/destroy/restore/forceDelete`: `\Illuminate\Http\RedirectResponse`; `toggleStatus`: `\Illuminate\Http\JsonResponse`; `trashedCity`: `\Illuminate\Contracts\View\View`. |
| **Plan item** | CIT-11 in `02-fix-plan.md` §8 (folded into the controller style item) |

```php
// CityController.php:20 — CURRENT
    public function index()
```

**Evidence**
```
$ grep -cE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/GlobalMaster/app/Http/Controllers/CityController.php
11
```

### F7 — Models (`Modules/GlobalMaster/app/Models/City.php`)

#### CIT-12 · M · CTL-10 / MDL-04 — `studentDetails()` references a class that does not exist

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M — dead code) / MDL-04 (L — relationship return types); raised to M because touching it fatals |
| **Where** | `Modules/GlobalMaster/app/Models/City.php:38-41`, relation `studentDetails()` |
| **Root cause** | The relation targets `Modules\StudentProfile\Models\StudentDetail::class`, and that class does not exist anywhere in the repo (`class_exists` returns `false`; there is no `Models/` directory under `Modules/StudentProfile`). Nothing in the codebase calls `->studentDetails` on a `City` (the `studentDetails` strings in StudentPortal/HPC are unrelated local variables). |
| **Consequence** | Dead code that would throw `Error: Class "Modules\StudentProfile\Models\StudentDetail" not found` the moment anyone uses `$city->studentDetails` or `City::with('studentDetails')`. |
| **Reproduce** | `php artisan tinker --execute 'var_dump(class_exists("Modules\\StudentProfile\\Models\\StudentDetail"));'` → `bool(false)`. |
| **Fix approach** | Remove the relation (nothing uses it), or replace it with a real relation once the StudentProfile model exists. Preference: remove it; keep `district()` with a return type. |
| **Plan item** | CIT-12 in `02-fix-plan.md` §5 |

```php
// City.php:31-42 — CURRENT
    //begin::Eloquent Relationships
    public function district()
    {
        return $this->belongsTo(District::class);
    }


    public function studentDetails()
    {
        return $this->hasMany(StudentDetail::class, 'city_id');
    }
    //end::Eloquent Relationships
```

**Evidence**
```
$ php artisan tinker --execute 'var_dump(class_exists("Modules\\StudentProfile\\Models\\StudentDetail"));'
bool(false)
$ grep -rln "class StudentDetail" . --include=*.php 2>/dev/null | grep -v vendor
(no output)
```

#### CIT-14 · L · MDL-04 — relationships lack return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`…)* |
| **Where** | `Modules/GlobalMaster/app/Models/City.php:32-35` (`district()`), `:38-41` (`studentDetails()`) |
| **Root cause** | Both relations omit the return type. |
| **Consequence** | No static guarantee the relation resolves to the declared class. |
| **Reproduce** | Static only. |
| **Fix approach** | `district()`: `: BelongsTo` (and, if `studentDetails` survives, `: HasMany`). Applied with CIT-12. |
| **Plan item** | CIT-14 in `02-fix-plan.md` §5 (folded into CIT-12 item) |

```php
// City.php:32-35 — CURRENT
    public function district()
    {
        return $this->belongsTo(District::class);
    }
```

**Evidence**
```
$ php artisan tinker --execute '$c=Modules\GlobalMaster\Models\City::with(["district","district.state","district.state.country"])->whereNotNull("district_id")->first(); echo $c->district->name." > ".$c->district->state->name." > ".$c->district->state->country->name.PHP_EOL;'
Visakhapatnam > Andhra Pradesh > India
```

#### CIT-22 · M · DECISION · MDL-07 / DDL-wins — give glb_cities the DDL's three unique keys?

| Field | Value |
|---|---|
| **Rule** | MDL-07 / DDL-wins (M) — *the DDL declares `uq_glb_cities_districtId_name`, `uq_glb_cities_shortName`, `uq_glb_cities_globalCode`; neither the migration nor the live table has them* |
| **Where** | `pgdatabase/2-DDL_Tenant_Consolidated/_global_db_v4.sql:75-77` vs `Modules/GlobalMaster/database/migrations/2025_10_09_042951_create_cities_table.php:17-28` vs live `glb_cities` |
| **Root cause** | The DDL (the project's source of truth) declares three unique keys; the migration creates none, and `SHOW INDEX` on the live table shows only PRIMARY + the FK. Uniqueness today is enforced only inside `CityRequest`. |
| **Consequence** | Any write path that does not go through `CityRequest` (imports, seeders, scripts) can create duplicate cities. If the keys are ever applied later, existing duplicates would block the migration. |
| **Reproduce** | `SHOW INDEX FROM glb_cities` — no `uq_glb_cities_*` keys. Measured duplicates today: 0 across all three key shapes (so adding the keys is data-safe **now**). |
| **Fix approach** | A product decision: add an additive migration with the three keys (safe today — 0 duplicates) or keep relying on validation-only uniqueness. |
| **Plan item** | CIT-22 in `02-fix-plan.md` §9 (DECISION) |

```php
// Migration 2025_10_09_042951_create_cities_table.php:17-28 — CURRENT (creates no unique keys)
        Schema::create('glb_cities', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('district_id');
            $table->foreign('district_id')->references('id')->on('glb_districts')->restrictOnDelete();
            $table->string('name', 100);
            $table->string('short_name', 20);
            $table->string('global_code', 20)->nullable();
            $table->string('default_timezone', 64)->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });
```
```sql
// _global_db_v4.sql:75-77 — DDL (the source of truth)
    UNIQUE KEY `uq_glb_cities_districtId_name` (`district_id`,`name`),
    UNIQUE KEY `uq_glb_cities_shortName` (`short_name`),
    UNIQUE KEY `uq_glb_cities_globalCode` (`global_code`),
```

**Evidence**
```
$ php artisan tinker --execute '$c=DB::connection("global_master_mysql"); foreach($c->select("SHOW INDEX FROM glb_cities") as $i){ echo $i->Key_name." : ".$i->Column_name.PHP_EOL; }'
PRIMARY : id
glb_cities_district_id_foreign : district_id
$ php artisan tinker --execute '...COUNT(*) FROM (SELECT district_id, name FROM glb_cities GROUP BY district_id, name HAVING COUNT(*) > 1) x...'
dup (district_id,name): 0; dup short_name: 0; dup global_code: 0
```

MDL-01 clean (`$fillable` declared, nothing sensitive — verified by read). MDL-02 clean (`is_active` cast to boolean; no other castable columns — `glb_cities` columns are id, district_id, name, short_name, global_code, default_timezone, is_active, timestamps, deleted_at). MDL-03 n/a (no belongsToMany). MDL-05/TEN-01 n/a (no `InteractsWithMedia`). MDL-07 clean (`glb_cities` exists in migration `2025_10_09_042951_create_cities_table.php` and in the live DB). SoftDeletes matches `deleted_at` (both present).

### F8 — Services and jobs

clean — the controller uses no services, jobs, events, mail or notifications (`grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b' Modules/GlobalMaster/app/Http/Controllers/CityController.php` → only `CityRequest`; `activityLog()` and `flash()` are helper functions, not services).

### F9 — Queries and performance

#### CIT-15 · M · QRY-03 / VIEW — index and trash render the raw `district_id` while the whole district chain is already eager-loaded

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M — *select only what you use*) + wrong display value on a live screen |
| **Where** | `Modules/GlobalMaster/resources/views/city/index.blade.php:29` and `Modules/GlobalMaster/resources/views/city/trash.blade.php:28`; controller `index()` eager-load at `CityController.php:23` |
| **Root cause** | `index()` runs `City::with(['district','district.state','district.state.country'])` but the blade prints `{{ $city->district_id }}` (the integer FK) instead of the district name. The eager-loaded `district` object is never used on the list — the joins are wasted work and the user sees "12" where the screen header promises "District". |
| **Consequence** | A school operator sees an id number instead of the district name on the city list, while three joins run to load data the page does not show. |
| **Reproduce** | Open `http://test.localhost:8000/global-master/city` — the District column is an integer. |
| **Fix approach** | Print `{{ $city->district?->name }}` in both blades (keep the eager load — now it is actually used). |
| **Plan item** | CIT-15 in `02-fix-plan.md` §7 |

```php
// index.blade.php:26-29 — CURRENT; trash.blade.php:25-28 identical shape
                                @forelse($cities as $city)
                                    <tr class="align-middle">
                                        <td>{{ $city->name }}</td>
                                        <td>{{ $city->district_id }}</td>
```

**Evidence**
```
$ grep -n "district_id\|district->name" Modules/GlobalMaster/resources/views/city/index.blade.php Modules/GlobalMaster/resources/views/city/trash.blade.php
index.blade.php:29:                                        <td>{{ $city->district_id }}</td>
trash.blade.php:28:                                        <td>{{ $city->district_id }}</td>
```

F9 rest clean: `index()` and `trashedCity()` paginate at 10 (QRY-02 ✓); `show()` eager-loads the chain it prints (VIEW-02 ✓); no queries inside loops in the controller; no raw SQL; no `Model::all()`.

### F10 — Views

#### CIT-16 · M · VIEW/J — create form repopulates the Global Code field with the Short Name's old value

| Field | Value |
|---|---|
| **Rule** | CTL-05 (copy-paste) applied to a view — `value="{{ old('short_name') }}"` on the `global_code` input; flagged M because it is wrong data on a screen after every failed create |
| **Where** | `Modules/GlobalMaster/resources/views/city/create.blade.php:41-43` |
| **Root cause** | The Global Code input was copied from the Short Name input and the `old()` argument was not changed. |
| **Consequence** | After any validation error on create, the Global Code field is pre-filled with the Short Name value, so the user may unknowingly save the wrong global code. |
| **Reproduce** | Submit the create form with an invalid district, then look at Global Code: it shows the short name. |
| **Fix approach** | Change `value="{{ old('short_name') }}"` → `value="{{ old('global_code') }}"`. |
| **Plan item** | CIT-16 in `02-fix-plan.md` §7 |

```php
// create.blade.php:41-43 — CURRENT
                                    <x-backend.form.input-text type="text" name="global_code"
                                        placeholder="Enter City Global Code" id="global_code" label="Global Code"
                                        required="true" value="{{ old('short_name') }}" />
```

**Evidence**
```
$ grep -n "old('short_name')\|name=\"global_code\"" Modules/GlobalMaster/resources/views/city/create.blade.php
37:                                        required="true" value="{{ old('short_name') }}" />
43:                                        required="true" value="{{ old('short_name') }}" />
```

#### CIT-17 · L · VIEW — the form marks optional fields as required; edit form disagrees with itself

| Field | Value |
|---|---|
| **Rule** | VAL-06/VIEW consistency — the form's `required="true"` must match the request's nullable |
| **Where** | `Modules/GlobalMaster/resources/views/city/create.blade.php:41-52` and `edit.blade.php:42-54` |
| **Root cause** | `CityRequest` declares `global_code` and `default_timezone` `nullable`, but both blades put `required="true"` on them. A user is forced to fill optional fields; creative blanks ("-") get stored. |
| **Consequence** | Cosmetic mismatch: the create/edit screens demand values the backend explicitly allows to be null. |
| **Reproduce** | Open the create form — the browser blocks submit until Global Code and Default Timezone are filled. |
| **Fix approach** | Remove `required="true"` from `global_code` and `default_timezone` in both blades (keep it on `name`, `short_name`). |
| **Plan item** | CIT-17 in `02-fix-plan.md` §7 |

```php
// create.blade.php:49-52 — CURRENT; edit.blade.php:51-54 identical
                                    <x-backend.form.input-text type="text" name="default_timezone"
                                        placeholder="Enter Default Timezone" id="default_timezone"
                                        label="Default Timezone" required="true"
                                        value="{{ old('default_timezone') }}" />
```

**Evidence**
```
$ grep -n "required=\"true\"" Modules/GlobalMaster/resources/views/city/create.blade.php Modules/GlobalMaster/resources/views/city/edit.blade.php
create.blade.php:33:                                        required="true" value="{{ old('name') }}" />
create.blade.php:37:                                        required="true" value="{{ old('short_name') }}" />
create.blade.php:43:                                        required="true" value="{{ old('short_name') }}" />
create.blade.php:52:                                        label="Default Timezone" required="true"
edit.blade.php:34:                                        required="true" value="{{ old('name', $city->name) }}" />
edit.blade.php:39:                                        required="true" value="{{ old('short_name', $city->short_name) }}" />
edit.blade.php:44:                                        required="true" value="{{ old('global_code', $city->global_code) }}" />
edit.blade.php:54:                                        label="Default Timezone" required="true"
```

#### CIT-23 · M · RTE-01 / VIEW — the shared trash-row component wires restore as a plain GET link

| Field | Value |
|---|---|
| **Rule** | RTE-01 (M — the shared wiring that makes CIT-09 reachable; kept M because the fix is in another module's component) — *state changes must not be GET links* |
| **Where** | `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php:3-19` (the `<a href="{ route($url . '.restore', $id) }">` line) |
| **Root cause** | The city trash screen uses the shared PrimeCore `action-trashed` component, which renders restore as an anchor link with only a JavaScript `confirm()`. Even after CIT-09 changes the route to POST, this link would 405 — the component must submit a small POST form instead. |
| **Consequence** | The restore action is one click (or one prefetch) away with no CSRF token; it is the browser-facing half of CIT-09. |
| **Reproduce** | Open `/global-master/city/trash/view` and inspect the restore control: `<a href>` with a JS confirm. |
| **Fix approach** | Rebuild the restore control as a tiny `@csrf` POST form (mirroring the force-delete form right below it in the same file), keep the Swal confirm. This component is shared by every geography trash screen — ⚠ SHARED. |
| **Plan item** | CIT-23 in `02-fix-plan.md` §2 (⚠ SHARED) |

```php
// action-trashed.blade.php:3-19 — CURRENT (restore is a GET anchor; force-delete below is already a form)
<form action="{{ route($url . '.forceDelete', $id) }}" method="POST" class="d-inline confirm-action-form-force-delete">
    @csrf
    @method('DELETE')
    <div class="btn-group" role="group" aria-label="Actions">
        <a href="{{ route($url . '.restore', $id) }}" class="btn btn-outline-warning btn-sm confirm-action-restore">
            <i class="fa-solid fa-recycle"></i>
        </a>
```

**Evidence**
```
$ grep -n "route(\$url . '.restore'" Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php
4:        <a href="{{ route($url . '.restore', $id) }}" class="btn btn-outline-warning btn-sm confirm-action-restore">
```

F10 rest clean: no `Model::`/`DB::` queries in any of the five city blades (VIEW-01 ✓, the `@php` block in show.blade only reads already-loaded relations); no `{!! !!}` on user text (VIEW-03 ✓); row actions use the standard `x-prime.table.action` / `action-trashed` components; every `<x-…>` component compiles — all five blades `compileString()` OK. Breadcrumbs and permissions in the blades match the controller gates (`@can('prime.global-master.city.update')` on show.blade ≥ controller gate).

### F11 — Security and tenancy

clean — no `env()` outside config (`grep -n "env("` on controller/model/request → no output); no hard-coded ids or `?? 1`; no personal data in JSON responses; `sys_activity_logs` written via the common helper; routes are central-domain + `['auth','verified']` and every method gates. Tenant rules n/a (this is a central master-data screen, MEDI not tenant-scoped).

### F12 — Style

#### CIT-18 · L · STY-01/STY-04 — `CityController.php` style debt

| Field | Value |
|---|---|
| **Rule** | STY-01 (L — `declare(strict_types=1);`), STY-04 (L — comments in English, no copy-pasted boilerplate) |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CityController.php:`1, 17-19, 49-51, 161-163, 201-203 |
| **Root cause** | No `strict_types`; every mutation repeats the "begin::Activity Log / Syntex : activityLog(...)" comment block (with the "Syntex" typo); the `update()` activity message "A new city was updated." is stale copy (this is an edit, not a new city). |
| **Consequence** | Consistency debt; misleading log wording. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);`; drop the boilerplate comment block (keep a single short English comment where meaningful); fix the update wording to "City was updated." |
| **Plan item** | CIT-18 in `02-fix-plan.md` §8 |

```php
// CityController.php:1-3 — CURRENT
<?php

namespace Modules\GlobalMaster\Http\Controllers;
```

**Evidence**
```
$ grep -n "Syntex\|begin::Activity Log\|A new city was updated" Modules/GlobalMaster/app/Http/Controllers/CityController.php
50:                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
120:                        'message' => 'A new city was updated.',
126:                        'message' => 'A new city was updated. No attributes changed.',
162:                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
202:                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
```

#### CIT-19 · L · STY-01/STY-04 — `CityRequest.php` style debt

| Field | Value |
|---|---|
| **Rule** | STY-01 (L), STY-04 (L — stale comment) |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/CityRequest.php:1, 52-56` |
| **Root cause** | No `strict_types`; the `authorize()` comment names `prime.city.create` / `prime.city.update` while the code checks `prime.global-master.city.*` — a stale literal. |
| **Consequence** | A reader greps `prime.city.create`, finds nothing, and distrusts the file. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);`; update the comment to the real permission names. |
| **Plan item** | CIT-19 in `02-fix-plan.md` §8 |

```php
// CityRequest.php:51-57 — CURRENT
    public function authorize(): bool
    {
        // T6b — mirrors the controller's own gate: prime.city.create on POST,
        // prime.city.update on PUT/PATCH. Same permission, checked one step
        // earlier, so this narrows nothing and widens nothing.
        return $this->authorizeByCrudPermission('prime.global-master.city');
    }
```

**Evidence**
```
$ grep -n "prime.city" Modules/GlobalMaster/app/Http/Requests/CityRequest.php
54:        // T6b — mirrors the controller's own gate: prime.city.create on POST,
55:        // prime.city.update on PUT/PATCH. Same permission, checked one step
```

#### CIT-20 · L · STY-01 — `City.php` style debt

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — `declare(strict_types=1);` |
| **Where** | `Modules/GlobalMaster/app/Models/City.php:1` |
| **Root cause** | Missing `strict_types` declaration. |
| **Consequence** | Consistency debt with files that declare it. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` (applied with the CIT-12 model item). |
| **Plan item** | CIT-20 in `02-fix-plan.md` §8 (folded into CIT-12's model edit) |

```php
// City.php:1-3 — CURRENT
<?php

namespace Modules\GlobalMaster\Models;
```

**Evidence**
```
$ head -1 Modules/GlobalMaster/app/Models/City.php
<?php
```

### F13 — Deep read (all eight questions, per mutating method)

| Method | 1 overwrite? | 2 delete before replace? | 3 duplicate impl? | 4 soft-delete×unique? | 5 race? | 6 auth hole? | 7 message lies? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok — new row | ok | ok | CIT-07 | ok — no check-then-act; duplicate names only possible via the §7 schema drift | ok — create gate + request | ok | ok |
| `update` | ok — full `validated()` row is the edit form's contract | ok | ok (change-compare is bespoke but coherent) | CIT-07 | ok | ok — update gate + request | minor — "A new city was updated." (CIT-18) | ok |
| `destroy` | ok — sets is_active=false then soft-deletes in one transaction | ok | ok | ok | ok | ok — delete gate | ok — event `Trashed`, message says "deactivated and deleted" which is what happens | ok |
| `restore` | ok — un-deletes only; `is_active` stays false (house convention, siblings identical) | ok | ok | ok | ok | ok — restore gate | ok — flash restored.city is accurate (record is back, inactive) | ok |
| `forceDelete` | ok — permanent delete + audit | ok — audit row is created fresh, not replacing data | ok | ok | ok | ok — forceDelete gate | ok | ok |
| `toggleStatus` | ok — only `is_active` from a boolean-validated input | ok | ok | ok | ok | ok — update gate | ok | ok |

Deep-read verdict: no wrong-data overwrite, no delete-before-replace, no race needing a lock, no auth hole. The soft-delete × uniqueness trap is the only deep-read defect (CIT-07). `restore()` leaving `is_active=false` matches `State/District/Country` siblings (verified by grep) — recorded as accepted convention. **CIT-21** (informational, no code change): the `destroy → restore → toggle` lifecycle keeps a trashed row inactive after restore; an operator must remember to re-activate. Not a finding to fix — see §10.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `_global_db_v4.sql` (DDL) vs live `glb_cities` | The DDL declares three unique keys (`uq_glb_cities_districtId_name`, `uq_glb_cities_shortName`, `uq_glb_cities_globalCode`); the migration `2025_10_09_042951_create_cities_table.php` creates none and the live table has none (only PRIMARY + FK). The app relies entirely on `CityRequest`'s unique rules. If the DDL keys are ever applied, deleting/trashing no longer frees a name (the index includes `deleted_at` rows) — the CIT-07 fix alone would then still hit a DB error on re-create. | MDL-07 / DDL-wins | Schema owner (Tarun) — a migration to add the DDL keys, if the product wants them, is a DECISION |
| `app/View/Components/Backend/Form/SelectDistrict.php` (+ `select-district.blade.php`) | Runs `District::where('is_active', true)->with(['state','state.country'])->get()` on every create/edit render of city/state/district/org forms — an unbounded dropdown query per page (QRY-15 / caching candidate). | QRY-15 / F9 | Shared-component owner (this report links it, does not fix) |
| `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` | Renders restore as a plain `<a href>` GET link — the wiring that makes CIT-09 reachable on every geography trash screen. | RTE-01 | Shared-component owner — CIT-23 (⚠ SHARED) fixes it |
| Sibling controllers `StateController`, `DistrictController`, `CountryController` | Same six-block try/catch, same `getMessage()` logging, same GET `restore`, same `findOrFail($id)` — the whole geography family carries CIT-01/03/09/10. | ERR-00, ERR-05, RTE-01, CTL-03 | Their own reports (CountryController report in progress) — module-level cross-controller family |

## 8. Not covered, and why

- **HTTP round-trips of the five blades** — no browser in this workflow (D4, no tests). Blades were read statically and proven to compile via `Blade::compileString()` (all five COMPILES). The JSON/HTML behaviour of `toggleStatus` was reasoned from the code (the curl repro is listed, not executed).
- **The permission deny path** — a role missing `prime.global-master.city.*` was not exercised in a browser; the gates are standard `Gate::authorize`, the renderer path is common.
- **`sys_activity_logs` write** — the common `activityLog()` helper was not audited (common class); only its call sites were checked for event literals and placement.
- **Queue/background work** — none exists in this controller's scope.
- **Sibling controllers' own defects** — only usage-level checks; each has its own report (State/District pending).
