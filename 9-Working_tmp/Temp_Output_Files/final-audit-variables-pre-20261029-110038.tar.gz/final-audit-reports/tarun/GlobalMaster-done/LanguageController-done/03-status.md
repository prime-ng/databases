# Status — GlobalMaster / LanguageController

**Fixed:** 2026-10-21 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| LANG-01 | `LanguageRequest.php` | `authorize()` now checks the seeded `prime.prime.language.{create,update}` (was `prime.language.*`, seeded nowhere). **This is live:** the Prime `LanguageController` uses this request for store/update, so every language save on `/global-master/language` was refused with 403 for every non-super-admin. | `grep -n "prime.prime.language"` | line 58 | 2026-10-21 |
| LANG-05 | `language/index.blade.php` | List gated on `@can('prime.prime.language.viewAny')` (was `tenant.global-master.language.viewAny`). | `grep -n viewAny` | line 12 | 2026-10-21 |
| LANG-03 | `LanguageController.php` | index/create/show/edit/trashedlanguage disabled per D5. Closes LANG-02 and LANG-09 (superseded). Unused `Gate` import removed. | `grep -c "abort(403, 'This endpoint is not available.')"` | 11 | 2026-10-21 |
| LANG-04 | `Modules/Prime/app/Models/Language.php` | `'is_active' => 'boolean'` cast. | `grep -n "'is_active' => 'boolean'"` | 1 hit | 2026-10-21 |
| LANG-06 | `language/index.blade.php` | Three dead, misspelled `*.permissiom="prime.langauge.*"` attributes removed. | `grep -n "permissiom\|langauge"` | no output | 2026-10-21 |
| LANG-08 | 3 files | `strict_types` on the controller, the request and the Language model. | `grep -n strict_types` | 3 files | 2026-10-21 |

## 3. Not applied
- LANG-07 — deferred by the plan (return types on stubs).

## 4. Needs Tarun's hand
- **Browser check:** log in as a non-super-admin holding `prime.prime.language.create` and save a language on `/global-master/language` — it was 403 before LANG-01.

## 5. Unverifiable by this workflow (D4)
- The LANG-01 refusal path: every check here ran as super admin (Gate::before), so the fix is proven by name only.

## 6. Verification log
```
vendor/bin/pint <14 touched files> --format agent     → fixed spacing/imports in 8 files
php -l <14 touched files>                              → No syntax errors
class_exists(<14 touched classes>)                     → true ×14
APP_ROUTES_CACHE=/tmp/fa-nocache.php route:list --json → 8004 routes; 0 reach the 7 GlobalMaster
                                                         controllers fixed in this pass
method_exists over every GlobalMaster/Prime route      → all present except 9 in Prime
                                                         PrimeController / DropdownMgmtController
                                                         (pre-existing since 2026-08-24, untouched here)
```
Blade `language/index.blade.php` compiles; `php -l` on the compiled output clean; `@push` 0/0.

## 7. Final state
FIXED. Open: LANG-07 (deferred).
