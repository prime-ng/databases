# Final Audit — GlobalMaster / LanguageController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php` (117 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | None reachable. The controller has **zero routes** (see §4). The live URLs `/global-master/language`, `/global-master/language/create`, `/global-master/language/{language}/edit`, `/global-master/language/trash/view` are served by a **different** controller — `Modules\Prime\Http\Controllers\LanguageController` (Prime module), not this one. |
| Menu path | Global Master → Language (rendered by the Prime controller) |
| Who uses it | Roles holding `prime.prime.language.viewAny` on the central test DB: Super Admin, Dev Team, App Maintenance, School Admin, Support Team, CRM Team (measured: `sys_role_has_permissions_jnt`). |
| What a user does here | On the live screen a user lists languages, creates one (code, name, native name, direction LTR/RTL, active switch), edits one, soft-deletes one, and restores/purges from the trash page. **This globalmaster controller is a duplicate of that screen and is not wired to any route**, so nothing a user does reaches it. |
| Tables written | `glb_languages` (only through the Prime controller; this controller writes nothing — its six mutating methods are already disabled). |
| Tables read | `glb_languages` (this controller's five live methods only read it). |
| Live data | `glb_languages` 10 live rows, 0 trashed (measured with `Modules\Prime\Models\Language::count()` / `onlyTrashed()->count()`). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**No — this controller is dead code and should not ship in its current shape.** It is a near-duplicate of `Modules\Prime\Http\Controllers\LanguageController`; every `/global-master/language*` route points at the Prime controller, and this globalmaster copy has **zero routes** — yet five of its methods (`index`, `create`, `show`, `edit`, `trashedlanguage`) still carry live bodies that build queries and render views (RTE-03 / D5). The **single worst finding** is `LANG-01`: the shared `LanguageRequest` authorizes against `prime.language.create` / `prime.language.update`, a three-segment name that is **never seeded** (the seeded names are `prime.prime.language.create` / `.update`), so the live create/update routes on the Prime controller return 403 for every non-super-admin who actually holds the real permission. Effort to fix the plan: **S–M** (the fixes are small and mechanical; the biggest judgement is disabling the five live methods per D5).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 5 | 3 | 0 | 9 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | clean |
| F3 Authorization | LANG-01, LANG-02, LANG-05 | F10 Views | LANG-06 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | LANG-03 | F12 Style | LANG-08 |
| F6 Controller shape | LANG-07, LANG-09 | F13 Deep read | no active mutator |
| F7 Models | LANG-04 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php` | controller | 117 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php` | form request | 64 | this report | ✅ |
| 3 | `Modules/Prime/app/Models/Language.php` | model | 25 | this report | ✅ |
| 4 | `Modules/GlobalMaster/resources/views/language/index.blade.php` | view | 73 | this report | ✅ |
| 5 | `Modules/GlobalMaster/resources/views/language/create.blade.php` | view | 71 | this report | ✅ |
| 6 | `Modules/GlobalMaster/resources/views/language/edit.blade.php` | view | 74 | this report | ✅ |
| 7 | `Modules/GlobalMaster/resources/views/language/show.blade.php` | view | 68 | this report | ✅ |
| 8 | `Modules/GlobalMaster/resources/views/language/trash.blade.php` | view | 61 | this report | ✅ |

**Shared classes — full ownership (§5).** This is the first audit to reach two non-common classes, so it claims and fully audits them; both are also used by `Modules\Prime\Http\Controllers\LanguageController`, so later reports must link here instead of re-auditing:

- `Modules/Prime/app/Models/Language.php` — claimed by this report (`00-CLASS-OWNERS.md`, appended 2026-10-12).
- `Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php` — claimed by this report (`00-CLASS-OWNERS.md`, appended 2026-10-12).

**Common, not audited (referenced only):** `App\Http\Controllers\Controller` (base class), the `activityLog()` helper (`app/Helpers/activityLog.php`), `App\Models\BaseModel`. The Blade components under `resources/views/components/**` and `Modules/PrimeCore/resources/views/components/**` are common.

No pre-applied files (`PRE-APPLIED-2026-10-10.md` does not list any file in this scope).

## 4. Routes

The controller has **no route pointing at it**. The live route names `central.global-master.language.*` resolve to the **Prime** controller:

```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); $n=0; foreach($r as $x){ if(str_contains($x["action"],"GlobalMaster\\Http\\Controllers\\LanguageController@")){$n++; echo $x["uri"]."\n";} } echo "globalmaster_language_routes=$n\n";'
globalmaster_language_routes=0

$ grep -rn "LanguageController" Modules/GlobalMaster/routes/ Modules/GlobalMaster/app/Providers/
(no output — the controller is never imported or registered)

# The live /global-master/language routes (Prime controller, Modules/Prime/routes/web.php:282-286):
GET|HEAD  global-master/language                        central.global-master.language.index      Modules\Prime\Http\Controllers\LanguageController@index
POST      global-master/language                        central.global-master.language.store      Modules\Prime\Http\Controllers\LanguageController@store
GET|HEAD  global-master/language/create                 central.global-master.language.create     Modules\Prime\Http\Controllers\LanguageController@create
GET|HEAD  global-master/language/trash/view             central.global-master.language.trashed    Modules\Prime\Http\Controllers\LanguageController@trashedLanguage
DELETE    global-master/language/{id}/force-delete      central.global-master.language.forceDelete Modules\Prime\Http\Controllers\LanguageController@forceDelete
GET|HEAD  global-master/language/{id}/restore           central.global-master.language.restore    Modules\Prime\Http\Controllers\LanguageController@restore
GET|HEAD  global-master/language/{language}             central.global-master.language.show       Modules\Prime\Http\Controllers\LanguageController@show
PUT|PATCH global-master/language/{language}             central.global-master.language.update     Modules\Prime\Http\Controllers\LanguageController@update
DELETE    global-master/language/{language}             central.global-master.language.destroy    Modules\Prime\Http\Controllers\LanguageController@destroy
GET|HEAD  global-master/language/{language}/edit        central.global-master.language.edit       Modules\Prime\Http\Controllers\LanguageController@edit
POST      global-master/language/{language}/toggle-status central.global-master.language.toggleStatus Modules\Prime\Http\Controllers\LanguageController@toggleStatus
```

Unrouted public methods (all 11 — the controller is entirely unrouted): `index` (16), `create` (29), `store` (38), `show` (48), `edit` (57), `update` (67), `destroy` (77), `trashedlanguage` (85), `restore` (92), `forceDelete` (99), `toggleStatus` (110). Six of them (`store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`) already follow D5 (body is `abort(403, 'This endpoint is not available.')` with a `NOT ROUTED` comment). The other five still carry live bodies — LANG-03.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 16 | no | `prime.prime.language.viewAny` (via `Gate::any`) | — | — | none (reads) | LANG-03 |
| `create` | 29 | no | `prime.prime.language.create` | — | — | none | LANG-03 |
| `store` | 38 | no | disabled — `abort(403)` | — | — | none | — |
| `show` | 48 | no | `prime.prime.language.view` | — | — | none (reads) | LANG-03 |
| `edit` | 57 | no | `prime.prime.language.update` | — | — | none (reads) | LANG-03, LANG-09 |
| `update` | 67 | no | disabled — `abort(403)` | — | — | none | — |
| `destroy` | 77 | no | disabled — `abort(403)` | — | — | none | — |
| `trashedlanguage` | 85 | no | `tenant.global-master.language.restore` | — | — | none (reads) | LANG-03, LANG-02 |
| `restore` | 92 | no | disabled — `abort(403)` | — | — | none | — |
| `forceDelete` | 99 | no | disabled — `abort(403)` | — | — | none | — |
| `toggleStatus` | 110 | no | disabled — `abort(403)` | — | — | none | — |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try|catch|getMessage|DB::|->save\(|->create\(|->update\(|->delete\(|->forceDelete\(' Modules/GlobalMaster/app/Http/Controllers/LanguageController.php` → no output. No try/catch, no exception text, no writes.

### F2 — Transactions and audit

clean — the same grep above returns no `DB::`, `->save(`, `->create(` or `activityLog`. No mutating method is active in this controller: the five live methods only query and render, and the six mutators are already disabled by `abort(403)`. There is no write path to wrap in a transaction.

### F3 — Authorization

#### LANG-01 · H · AUTH-01 — the shared FormRequest authorizes against a permission name that is never seeded

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (default B; lowered to H — this denies a valid user, it does not open a hole) — *every routed method authorizes against a permission that exists* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php:50-55`, method `authorize()` |
| **Root cause** | Permission names are four segments, `scope.module.feature.action` (config header, `config/permissionslist.php:10-16`). The config key `prime.language` sits under the `prime` scope, so `PermissionHelper::flatten('prime')` produces `prime.prime.language.create` and `prime.prime.language.update`. The FormRequest instead checks the three-segment literal `prime.language.create` / `prime.language.update`, which is never seeded. |
| **Consequence** | On the live `/global-master/language` routes (served by the Prime controller), any non-super-admin who holds the real `prime.prime.language.create` / `.update` permission is refused with a 403 before the controller runs. Only Super Admin passes, because `AppServiceProvider::boot()` registers `Gate::before()` that bypasses every check for `is_super_admin`/`Super Admin`. |
| **Reproduce** | Log in as a role holding `prime.prime.language.create` but not Super Admin; open `/global-master/language/create` and submit the form. Expected: language created. Actual: 403. |
| **Fix approach** | Change the checked name to the seeded four-segment form `prime.prime.language.` (LANG-01 in the plan). |
| **Plan item** | LANG-01 in `02-fix-plan.md` §1 |
| **Evidence** | Commands and outputs in the second code block. |

```php
// LanguageRequest.php:50-55 — CURRENT
    public function authorize(): bool
    {
        // T6b — used by two LanguageControllers (GlobalMaster and Prime), but BOTH gate
        // prime.language.{create,update}, so there is one permission to mirror, not two.
        return Gate::allows('prime.language.' . ($this->isMethod('POST') ? 'create' : 'update'));
    }
```

**Evidence**
```
$ grep -n "'prime.language' =>" config/permissionslist.php
212:        'prime.language' => $crud,

$ php artisan tinker --execute 'DB::table("sys_permissions")->where("name","like","%language%")->orderBy("name")->pluck("name")->all();'
prime.prime.language.create
prime.prime.language.delete
prime.prime.language.forceDelete
prime.prime.language.restore
prime.prime.language.update
prime.prime.language.view
prime.prime.language.viewAny
# no row equals prime.language.create or prime.language.update
```

#### LANG-02 · M · AUTH-06 — `trashedlanguage()` gates a tenant-scope permission while its own view checks the prime one

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place and agree across the controller, the view and the config* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:87`, method `trashedlanguage()` (against `Modules/GlobalMaster/resources/views/language/trash.blade.php:37-38`) |
| **Root cause** | The method authorizes `tenant.global-master.language.restore` — a tenant-scope name built from the `global-master.language` key under the `tenant` scope (`config/permissionslist.php:363`). The trash view's restore button and force-delete button instead check `prime.prime.language.restore` / `prime.prime.language.forceDelete`. The page gate and its row actions test two different abilities. |
| **Consequence** | A central operator who holds only `prime.prime.language.restore` is denied the trash page (403) even though the buttons on it would have allowed restore; a tenant-scope holder reaches the page but the buttons evaluate a permission they may not hold. The page and its buttons disagree about who may restore. |
| **Reproduce** | static only — the controller is unrouted (LANG-03), so no live URL reaches `trashedlanguage()`. If the method is wired up unchanged, the mismatch shows on `/global-master/language/trash/view`. |
| **Fix approach** | none — superseded. The method's body is disabled by LANG-03 (D5), which removes the divergent string. See plan §10. |
| **Plan item** | none — see plan §10 (superseded by LANG-03) |
| **Evidence** | see second code block. |

```php
// LanguageController.php:85-90 — CURRENT
    public function trashedlanguage()
    {
        Gate::authorize('tenant.global-master.language.restore');
        $languages = Language::onlyTrashed()->paginate(10);
        return view('globalmaster::language.trash', compact('languages'));
    }
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/GlobalMaster/app/Http/Controllers/LanguageController.php
87:        Gate::authorize('tenant.global-master.language.restore');

$ grep -n "restorePermission\|forceDeletePermission" Modules/GlobalMaster/resources/views/language/trash.blade.php
37:                                                restorePermission="prime.prime.language.restore"
38:                                                forceDeletePermission="prime.prime.language.forceDelete"

$ grep -n "'global-master.language' =>" config/permissionslist.php
363:        'global-master.language' => $crud,     # this key is under the 'tenant' scope (line 325)
```

#### LANG-05 · M · AUTH-06 — the index view hides the table behind a tenant-scope permission the screen never grants

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *the same permission appears identically on the controller, the view and the config* |
| **Where** | `Modules/GlobalMaster/resources/views/language/index.blade.php:12` (against `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:18-20`) |
| **Root cause** | The controller's `index()` authorizes `prime.prime.language.viewAny`, but the view wraps the entire table in `@can('tenant.global-master.language.viewAny')`. The two names differ in scope (`prime` vs `tenant`) and in shape (`prime.prime.language.viewAny` vs `tenant.global-master.language.viewAny`). |
| **Consequence** | The six central roles that hold `prime.prime.language.viewAny` (Super Admin and the five team roles above) see the page card but an empty table body — the `@can` is false. Non-super-admins are locked out of the list they are meant to manage. |
| **Reproduce** | Log in as a role holding `prime.prime.language.viewAny` but not `tenant.global-master.language.viewAny`; open `/global-master/language`. Expected: the language list. Actual: an empty card (only the header and the empty body gate evaluated false). |
| **Fix approach** | Change the view gate to the controller's `prime.prime.language.viewAny` (LANG-05 in the plan). |
| **Plan item** | LANG-05 in `02-fix-plan.md` §4 |
| **Evidence** | see second code block. |

`index.blade.php:12` — CURRENT:

```blade
                     @can('tenant.global-master.language.viewAny')
```

**Evidence**
```
$ grep -n "viewAny" Modules/GlobalMaster/resources/views/language/index.blade.php Modules/GlobalMaster/app/Http/Controllers/LanguageController.php
Modules/GlobalMaster/resources/views/language/index.blade.php:12:                     @can('tenant.global-master.language.viewAny')
Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:19:            'prime.prime.language.viewAny',
```

### F4 — Validation and input

clean — validation lives in `LanguageRequest` (a FormRequest), not inline. `store`/`update` use `$request->validated()` (Prime controller) or are disabled here. Uniqueness rules mirror the real index: `glb_languages` has plain `UNIQUE` on `code` and `name` (`Modules/GlobalMaster/database/migrations/2025_11_10_061519_create_languages_table.php:20-21`) and `Rule::unique(...)->ignore($languageId)` (`LanguageRequest.php:23,29`) does not filter `deleted_at`, so it counts trashed rows exactly as the DB index does — no soft-delete × unique trap. `Rule::in(['LTR','RTL'])` types the enum. Note: `Rule::unique` on the model's central table is fine because `glb_languages` is a central catalogue.

### F5 — Routes

#### LANG-03 · M · RTE-03 — five live public methods are unrouted; the whole controller is a dead duplicate (D5)

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`)* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:16-24, 29-33, 48-52, 57-62, 85-90` — methods `index`, `create`, `show`, `edit`, `trashedlanguage` |
| **Root cause** | The module's route group (`Modules/GlobalMaster/routes/web.php:127-196`) never registers `language`; the live `/global-master/language` routes live in `Modules/Prime/routes/web.php:281-287` and point at `Modules\Prime\Http\Controllers\LanguageController`. This globalmaster copy is a leftover duplicate. Its six mutators were already disabled under D5, but the five read/render methods were left live, so they still execute `Language::paginate()` / `findOrFail()` / `view()` when nothing can call them. |
| **Consequence** | Dead code that a later refactor or route change can silently arm: if someone adds a `language` resource to the globalmaster group, a second, subtly different controller becomes reachable. It also misleads the next developer into editing the copy that does nothing. |
| **Reproduce** | static only — `route:list` proves zero routes (see §4). No URL reaches any of these five methods. |
| **Fix approach** | Per D5, replace each of the five live bodies with the `abort(403, 'This endpoint is not available.')` stub plus the `NOT ROUTED` comment, matching the six methods already disabled. Never delete the methods. |
| **Plan item** | LANG-03 in `02-fix-plan.md` §5 |
| **Evidence** | see second code block. |

```php
// LanguageController.php:16-24 — CURRENT (index; the other four live methods are listed in the plan)
    public function index()
    {
        Gate::any([
            'prime.prime.language.viewAny',
        ]) || abort(403);
        
        $languages = Language::paginate(11);
        return view('globalmaster::language.index', compact('languages'));
    }
```

**Evidence**
```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); $n=0; foreach($r as $x){ if(str_contains($x["action"],"GlobalMaster\\Http\\Controllers\\LanguageController@")){$n++;} } echo "globalmaster_language_routes=$n\n";'
globalmaster_language_routes=0

$ grep -rn "LanguageController" Modules/GlobalMaster/routes/ Modules/GlobalMaster/app/Providers/
(no output)
```

### F6 — Controller shape

#### LANG-07 · L · CTL-04 — no return types on any public method

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *public methods declare their return type* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:16,29,38,48,57,67,77,85,92,99,110` — all 11 public methods |
| **Root cause** | The methods were generated by `module:make` without return types and never completed. |
| **Consequence** | No runtime effect; readers and static analysis cannot see what each action returns, which slows the next refactor. |
| **Reproduce** | static only. |
| **Fix approach** | none planned now — the five live methods get their final disabled shape in LANG-03; adding return types is deferred until the controller's fate (retire or wire up) is settled. See plan §10. |
| **Plan item** | none — see plan §10 |
| **Evidence** | scanner output in the second code block. |

```php
// LanguageController.php:16 — CURRENT (representative; all 11 share the shape)
    public function index()
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/GlobalMaster/app/Http/Controllers/LanguageController.php
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:16  index — index() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:29  create — create() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:38  store — store() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:48  show — show() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:57  edit — edit() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:67  update — update() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:77  destroy — destroy() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:85  trashedlanguage — trashedlanguage() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:92  restore — restore() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:99  forceDelete — forceDelete() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:110  toggleStatus — toggleStatus() has no return type
```

#### LANG-09 · M · CTL-03 — `edit($id)` uses `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:57-62`, method `edit()` |
| **Root cause** | The method takes a raw `$id` and calls `Language::findOrFail($id)` although `show()` already uses implicit binding (`show(Language $language)`). |
| **Consequence** | Inconsistent with the sibling method; a missing id raises a `ModelNotFoundException` from inside the method rather than failing binding, and the 404 happens one query later. |
| **Reproduce** | static only — the controller is unrouted (LANG-03). |
| **Fix approach** | none planned now — the method body is disabled by LANG-03 (D5), which removes the call entirely. See plan §10. |
| **Plan item** | none — see plan §10 (superseded by LANG-03) |
| **Evidence** | see second code block. |

```php
// LanguageController.php:57-62 — CURRENT
    public function edit($id)
    {
        Gate::authorize('prime.prime.language.update');
        $language = Language::findOrFail($id);
        return view('globalmaster::language.edit', compact('language'));
    }
```

**Evidence**
```
$ grep -n "findOrFail" Modules/GlobalMaster/app/Http/Controllers/LanguageController.php
60:        $language = Language::findOrFail($id);

$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/GlobalMaster/app/Http/Controllers/LanguageController.php
M  CTL-03   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:57  edit — edit($id) + findOrFail — use route model binding
```

### F7 — Models

#### LANG-04 · M · MDL-02 — the `Language` model has no boolean cast for `is_active`

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` cover every boolean, date, decimal and JSON column* |
| **Where** | `Modules/Prime/app/Models/Language.php:9-23`, class `Language` (no `$casts`) |
| **Root cause** | `glb_languages.is_active` is a `boolean` column (`.../create_languages_table.php:24`), but the model defines no `$casts`. MySQL returns the column as `0`/`1` (an int or string), not a PHP `bool`. Without a cast, any strict comparison such as `$language->is_active === true` is `false` even when the row is active, and the value JSON-encodes as `1` rather than `true`. |
| **Consequence** | The test's live data has `is_active = 1`. A strict `=== true` check (or any JSON consumer expecting a boolean) reads the wrong type, so status handling can mis-render even though the row is active. |
| **Reproduce** | static only — the type mismatch is proven by the missing cast and the boolean column; see the plan's Verify. |
| **Fix approach** | Add a `$casts` array with `'is_active' => 'boolean'` (LANG-04 in the plan). |
| **Plan item** | LANG-04 in `02-fix-plan.md` §5 |
| **Evidence** | see second code block. |

```php
// Language.php:9-23 — CURRENT (no $casts)
class Language extends BaseModel
{
    use HasFactory, SoftDeletes;
    protected $connection = 'global_master_mysql';
    protected $table = 'glb_languages';
    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'code',
        'name',
        'native_name',
        'direction',
        'is_active',
    ];

}
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/Prime/app/Models/Language.php
M  MDL-02   Modules/Prime/app/Models/Language.php:17  - — Language: no cast for is_active

$ grep -n "is_active" Modules/GlobalMaster/database/migrations/2025_11_10_061519_create_languages_table.php
24:            $table->boolean('is_active')->default(true);
```

### F8 — Services and jobs

clean — the controller injects no service and dispatches no job. `grep -nE 'Service|Job|Event|Mail|Notification|Export|Import' Modules/GlobalMaster/app/Http/Controllers/LanguageController.php` → no output. Nothing to check under SVC/JOB.

### F9 — Queries and performance

clean — both list methods paginate (`Language::paginate(11)` at line 22, `Language::onlyTrashed()->paginate(10)` at line 88); no `all()`, no query inside a loop, no raw SQL. One note, no plan item: the index paginates at **11** rows where the house standard is 10 (`final-audit.md` F9 / C12) — harmless, but it is one over.

### F10 — Views

#### LANG-06 · L · STY-04 — index view carries dead, misspelled permission attributes

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *no copy-pasted or dead code left in a template* |
| **Where** | `Modules/GlobalMaster/resources/views/language/index.blade.php:43-45` |
| **Root cause** | Three attributes are spelled `view.permissiom` / `edit.permissiom` / `delete.permissiom` (note the `permissiom` typo, and a dot instead of a hyphen) with the value typo `prime.langauge.*` (`langauge`). The component reads the correctly-named `viewPermission` / `editPermission` / `deletePermission` attributes on the lines below, so the three bad lines are inert. |
| **Consequence** | No runtime effect on the rendered component, but the template misleads: it names the wrong property and a non-existent permission, so the next developer may copy the typo. |
| **Reproduce** | static only. |
| **Fix approach** | Delete the three misspelled attribute lines, keeping the correct camelCase attributes (LANG-06 in the plan). |
| **Plan item** | LANG-06 in `02-fix-plan.md` §7 |
| **Evidence** | see second code block. |

`index.blade.php:41-49` — CURRENT:

```blade
                                            <x-backend.table.action :id="$language->id"
                                                url="central.global-master.language" 
                                                view.permissiom="prime.langauge.view"
                                                edit.permissiom="prime.langauge.update"
                                                delete.permissiom="prime.langauge.delete"
                                                viewPermission="prime.prime.language.view"
                                                editPermission="prime.prime.language.update"
                                                deletePermission="prime.prime.language.delete"
                                            />
```

**Evidence**
```
$ grep -n "permissiom\|langauge" Modules/GlobalMaster/resources/views/language/index.blade.php
43:                                                view.permissiom="prime.langauge.view"
44:                                                edit.permissiom="prime.langauge.update"
45:                                                delete.permissiom="prime.langauge.delete"
```

Other view checks: no queries in Blade (VIEW-01 clean), no `{!! !!}` (VIEW-03 clean), and no relation access inside `@foreach` (VIEW-02 clean — the loop only prints scalar columns of the single paginated `Language` collection). `show.blade.php:13` checks `prime.prime.language.update`, matching the controller's `edit()` gate.

### F11 — Security and tenancy

clean — `grep -nE "env\(|Log::|SEC-|password|token" Modules/GlobalMaster/app/Http/Controllers/LanguageController.php` → no output. No `env()` outside config, no secrets logged, no hard-coded ids, no personal data exposed. The `Language` model is a central catalogue on the `global_master_mysql` connection, reached from a central-only screen; no tenant-scoped cache is used.

### F12 — Style

#### LANG-08 · L · STY-01 — missing `declare(strict_types=1);`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:1`, `Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php:1`, `Modules/Prime/app/Models/Language.php:1` |
| **Root cause** | All three files were generated before the strict-types rule and never carried the declaration. |
| **Consequence** | Implicit type juggling stays on in these files for any future code that is added. |
| **Reproduce** | static only. |
| **Fix approach** | Insert `declare(strict_types=1);` immediately after the opening `<?php` in each of the three files (LANG-08 in the plan). |
| **Plan item** | LANG-08 in `02-fix-plan.md` §8 |
| **Evidence** | see second code block. |

```php
// LanguageController.php:1-3 — CURRENT (the request and model have the same header)
<?php

namespace Modules\GlobalMaster\Http\Controllers;
```

**Evidence**
```
$ grep -nE 'declare\(strict_types' Modules/GlobalMaster/app/Http/Controllers/LanguageController.php Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php Modules/Prime/app/Models/Language.php
(no output)

$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/GlobalMaster/app/Http/Controllers/LanguageController.php Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php Modules/Prime/app/Models/Language.php
L  STY-01   Modules/GlobalMaster/app/Http/Controllers/LanguageController.php:1  - — missing declare(strict_types=1)
L  STY-01   Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php:1  - — missing declare(strict_types=1)
L  STY-01   Modules/Prime/app/Models/Language.php:1  - — missing declare(strict_types=1)
```

Other F12 checks: Pint-clean imports (one `use` per class, no aliasing) — clean; no commented-out code; no copy-pasted docblocks that name another resource; no emoji. The lowercase type hint in `toggleStatus(Request $request, language $language)` (line 110) is unusual casing but PHP resolves it correctly; noted, not a separate finding.

### F13 — Deep read (answer all 8 questions for every mutating method)

No mutating method is active in this controller — the six `store`/`update`/`destroy`/`restore`/`forceDelete`/`toggleStatus` methods are already `abort(403)` stubs, so no write path exists here. The only write-shaped behaviour in the scope is the shared `LanguageRequest::rules()` / `prepareForValidation()`, consumed by the live Prime controller. The eight deep-read questions against it:

| Method | Q1 wrong overwrite | Q2 delete-before-store | Q3 duplicate impl | Q4 soft-delete × unique | Q5 race | Q6 auth hole | Q7 lying message | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` (disabled here) | n/a | n/a | LANG-03 (duplicate controller) | ok — rule mirrors index | n/a | ok here; LANG-01 in request | n/a | LANG-03 |
| `update` (disabled here) | n/a | n/a | LANG-03 | ok — `ignore($languageId)` | n/a | ok here; LANG-01 in request | n/a | LANG-03 |
| `destroy` (disabled here) | n/a | n/a | LANG-03 | ok | n/a | ok | n/a | LANG-03 |
| `restore` (disabled here) | n/a | n/a | LANG-03 | ok | n/a | ok | n/a | LANG-03 |
| `forceDelete` (disabled here) | n/a | n/a | LANG-03 | ok | n/a | ok | n/a | LANG-03 |
| `toggleStatus` (disabled here) | n/a | n/a | LANG-03 | ok | n/a | ok | n/a | LANG-03 |

Notes: Q7 — the FormRequest's comment claims both controllers gate `prime.language.{create,update}`, which is wrong (they gate the four-segment names); that wrong belief is the root of LANG-01. Q8 — the entire globalmaster controller is a dead feature (LANG-03).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Prime/app/Http/Controllers/LanguageController.php` | The live routes point here; it is a near-duplicate of the audited controller. It is **outside this scope** (Prime module). | RTE-03 / CTL | the Prime module audit (not run) |
| `Modules/Prime/routes/web.php:281-287` | Registers the live `/global-master/language` resource against the Prime controller, from the `Modules/Prime` module. | RTE | a routing/central-module pass |
| `app/Providers/AppServiceProvider.php:78-87` | `Gate::before()` bypasses **all** authorization for Super Admin / `is_super_admin`, which hides LANG-01 for the one role most likely to test it. | AUTH | accepted project-wide behaviour |
| `app/Helpers/activityLog.php` | The `activityLog()` sink — common, not audited here. | — | common |

## 8. Not covered, and why

- **`Modules/Prime/Http/Controllers/LanguageController.php` and `Modules/Prime/routes/web.php`** — outside the assigned scope (a different module and controller). Their defects are recorded as cross-cutting notes above; they are not measured finding-by-finding here.
- **The live browser screen.** Per D4 no request was executed end-to-end; every LANG-01/LANG-05 consequence is derived from the seeded permission set (`sys_permissions`, quoted) and the config flatten rule, not from a browser session.
- **Queue jobs / commands** — the controller dispatches none.
- **No tests were run or written** (D4).
