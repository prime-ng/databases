# Fix Plan — GlobalMaster / LanguageController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php` | route file — shared, owned by the routing pass |
| `Modules/Prime/routes/web.php` | route file — the live routes live here; not in scope |
| `Modules/Prime/app/Http/Controllers/LanguageController.php` | a different module's controller — not in this report's scope |
| `config/permissionslist.php` | shared config — no permission change is proposed |
| `app/Providers/AppServiceProvider.php` | shared provider — `Gate::before()` is accepted project behaviour |
| `app/Models/BaseModel.php`, `app/Http/Controllers/Controller.php`, `app/Helpers/activityLog.php` | common classes — referenced only |
| `resources/views/components/**`, `Modules/PrimeCore/resources/views/components/**` | shared Blade components — used, never edited here |

## 1. Blockers reachable today

- [ ] **LANG-01** · H · AUTH-01 · `Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php:53-54` — fix the FormRequest to check the seeded four-segment permission name.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php`
  - **Before** (`LanguageRequest.php:52-54`):
    ```php
        // T6b — used by two LanguageControllers (GlobalMaster and Prime), but BOTH gate
        // prime.language.{create,update}, so there is one permission to mirror, not two.
        return Gate::allows('prime.language.' . ($this->isMethod('POST') ? 'create' : 'update'));
    ```
  - **After:**
    ```php
        // T6b — used by two LanguageControllers (GlobalMaster and Prime); both gate the
        // seeded prime.prime.language.{create,update} permissions (scope.module.feature.action).
        return Gate::allows('prime.prime.language.' . ($this->isMethod('POST') ? 'create' : 'update'));
    ```
  - **Verify:** `grep -n "Gate::allows" Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php`
  - **Expect:** one line containing `prime.prime.language.` — and no line containing `'prime.language.`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

(none)

## 3. Errors & transactions (F1/F2)

(none — no try/catch and no write path exists in this controller)

## 4. Authorization (F3)

- [ ] **LANG-05** · M · AUTH-06 · `Modules/GlobalMaster/resources/views/language/index.blade.php:12` — gate the list on the permission the controller actually checks.
  - **Touches:** `Modules/GlobalMaster/resources/views/language/index.blade.php`
  - **Before** (`index.blade.php:12`):
    ```blade
                         @can('tenant.global-master.language.viewAny')
    ```
  - **After:**
    ```blade
                         @can('prime.prime.language.viewAny')
    ```
  - **Verify:** `grep -n "viewAny" Modules/GlobalMaster/resources/views/language/index.blade.php`
  - **Expect:** one line reading `@can('prime.prime.language.viewAny')` — no `tenant.global-master.language.viewAny`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **LANG-03** · M · RTE-03 · `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php` — disable the five live unrouted methods per D5 (bodies become `abort(403)`). Apply all five replacements.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php`
  - **Before** (a) (`LanguageController.php:16-24`, method `index`):
    ```php
        public function index()
        {
            Gate::any([
                'prime.prime.language.viewAny',
            ]) || abort(403);
            
            $languages = Language::paginate(11);
            return view('globalmaster::language.index', compact('languages'));
        }
    ```
  - **After:** (a)
    ```php
        public function index()
        {
            // NOT ROUTED — no route points at this method (verified against `php artisan route:list`, 2026-10-12).
            // Disabled pending a decision to wire it up or delete it; the original body is in git history.
            abort(403, 'This endpoint is not available.');
        }
    ```
  - **Before** (b) (`LanguageController.php:29-33`, method `create`):
    ```php
        public function create()
        {
            Gate::authorize('prime.prime.language.create');
            return view('globalmaster::language.create');
        }
    ```
  - **After:** (b)
    ```php
        public function create()
        {
            // NOT ROUTED — no route points at this method (verified against `php artisan route:list`, 2026-10-12).
            // Disabled pending a decision to wire it up or delete it; the original body is in git history.
            abort(403, 'This endpoint is not available.');
        }
    ```
  - **Before** (c) (`LanguageController.php:48-52`, method `show`):
    ```php
        public function show(Language $language)
        {
            Gate::authorize('prime.prime.language.view');
            return view('globalmaster::language.show', compact('language'));
        }
    ```
  - **After:** (c)
    ```php
        public function show(Language $language)
        {
            // NOT ROUTED — no route points at this method (verified against `php artisan route:list`, 2026-10-12).
            // Disabled pending a decision to wire it up or delete it; the original body is in git history.
            abort(403, 'This endpoint is not available.');
        }
    ```
  - **Before** (d) (`LanguageController.php:57-62`, method `edit`):
    ```php
        public function edit($id)
        {
            Gate::authorize('prime.prime.language.update');
            $language = Language::findOrFail($id);
            return view('globalmaster::language.edit', compact('language'));
        }
    ```
  - **After:** (d)
    ```php
        public function edit($id)
        {
            // NOT ROUTED — no route points at this method (verified against `php artisan route:list`, 2026-10-12).
            // Disabled pending a decision to wire it up or delete it; the original body is in git history.
            abort(403, 'This endpoint is not available.');
        }
    ```
  - **Before** (e) (`LanguageController.php:85-90`, method `trashedlanguage`):
    ```php
        public function trashedlanguage()
        {
            Gate::authorize('tenant.global-master.language.restore');
            $languages = Language::onlyTrashed()->paginate(10);
            return view('globalmaster::language.trash', compact('languages'));
        }
    ```
  - **After:** (e)
    ```php
        public function trashedlanguage()
        {
            // NOT ROUTED — no route points at this method (verified against `php artisan route:list`, 2026-10-12).
            // Disabled pending a decision to wire it up or delete it; the original body is in git history.
            abort(403, 'This endpoint is not available.');
        }
    ```
  - **Verify:** `grep -c "abort(403, 'This endpoint is not available.')" Modules/GlobalMaster/app/Http/Controllers/LanguageController.php`
  - **Expect:** `11` (the six already-disabled methods plus the five replaced here).
  - **Effort:** S

- [ ] **LANG-04** · M · MDL-02 · `Modules/Prime/app/Models/Language.php:9-23` — add the missing boolean cast for `is_active`.
  - **Touches:** `Modules/Prime/app/Models/Language.php`
  - **Before** (`Language.php:9-23`):
    ```php
    class Language extends BaseModel
    {
        use HasFactory, SoftDeletes;
        protected $connection = 'global_master_mysql';
        protected $table = 'glb_languages';
        /**
         * The attributes that are mass assignable.
         */
        protected $fillable = [
            'code',
            'name',
            'native_name',
            'direction',
            'is_active',
        ];

    }
    ```
  - **After:**
    ```php
    class Language extends BaseModel
    {
        use HasFactory, SoftDeletes;
        protected $connection = 'global_master_mysql';
        protected $table = 'glb_languages';
        /**
         * The attributes that are mass assignable.
         */
        protected $fillable = [
            'code',
            'name',
            'native_name',
            'direction',
            'is_active',
        ];

        /**
         * The attributes that should be cast.
         */
        protected $casts = [
            'is_active' => 'boolean',
        ];
    }
    ```
  - **Verify:** `grep -n "'is_active' => 'boolean'" Modules/Prime/app/Models/Language.php`
  - **Expect:** one line reading `'is_active' => 'boolean',`.
  - **Effort:** S

## 6. Queries & performance (F9)

(none — both list methods already paginate)

## 7. Views (F10)

- [ ] **LANG-06** · L · STY-04 · `Modules/GlobalMaster/resources/views/language/index.blade.php:43-45` — delete the three dead, misspelled permission attributes.
  - **Touches:** `Modules/GlobalMaster/resources/views/language/index.blade.php`
  - **Before** (`index.blade.php:41-49`):
    ```blade
                                                <x-backend.table.action :id="$language->id"
                                                    url="central.global-master.language" 
                                                    view.permissiom="prime.langauge.view"
                                                    edit.permissiom="prime.langauge.update"
                                                    delete.permissiom="prime.langauge.delete"
                                                    viewPermission="prime.prime.language.view"
                                                    editPermission="prime.prime.language.update"
                                                    deletePermission="prime.prime.language.delete"
                                                />
    ```
  - **After:**
    ```blade
                                                <x-backend.table.action :id="$language->id"
                                                    url="central.global-master.language" 
                                                    viewPermission="prime.prime.language.view"
                                                    editPermission="prime.prime.language.update"
                                                    deletePermission="prime.prime.language.delete"
                                                />
    ```
  - **Verify:** `grep -n "permissiom\|langauge" Modules/GlobalMaster/resources/views/language/index.blade.php`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **LANG-08** · L · STY-01 · three files — add `declare(strict_types=1);` after `<?php`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/LanguageController.php`, `Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php`, `Modules/Prime/app/Models/Language.php`
  - **Before** (a) (`LanguageController.php:1-3`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **After:** (a)
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **Before** (b) (`LanguageRequest.php:1-3`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Requests;
    ```
  - **After:** (b)
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Requests;
    ```
  - **Before** (c) (`Language.php:1-5`):
    ```php
    <?php

    namespace Modules\Prime\Models;

    use App\Models\BaseModel;
    ```
  - **After:** (c)
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Prime\Models;

    use App\Models\BaseModel;
    ```
  - **Verify:** `grep -c "declare(strict_types=1);" Modules/GlobalMaster/app/Http/Controllers/LanguageController.php Modules/GlobalMaster/app/Http/Requests/LanguageRequest.php Modules/Prime/app/Models/Language.php`
  - **Expect:** `1` beside each of the three file names.
  - **Effort:** S

## 9. Deferred / decisions

(none)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| LANG-02 | Superseded — `trashedlanguage()` (which holds the mismatched `tenant.global-master.language.restore` gate) has its whole body replaced by LANG-03 per D5, so the divergent string disappears. If LANG-03 is not ticked, this stays open. |
| LANG-07 | Deferred — the five live methods get their final disabled shape in LANG-03; adding return types before the controller's fate (retire or wire up) is settled would either mislead (`: View` on an `abort` stub) or be lost work. Re-report after LANG-03. |
| LANG-09 | Superseded — `edit()`'s `findOrFail($id)` is removed with the body by LANG-03 (D5). If LANG-03 is not ticked, this stays open. |
