# Status — GlobalMaster / CountryController

**Fixed:** 2026-10-17 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
| ID | What | Where |
|---|---|---|
| CNTRY-05 | Restore over GET → **POST** route (both `/global-master` and `/prime` copies). Tarun chose POST + dual-mode `action-trashed` over the plan's DELETE, so the plan item is superseded and left unticked. | commit `6d157fb2c` (restore family) |

## 2. Applied
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| CNTRY-01 (+03) | `CountryController.php` | All five try/catch envelopes, the `ModelNotFoundException` rethrows and `Log::error(getMessage())` lines removed (D1). Redirects built after the transaction. `restore()`/`forceDelete()` load with `findOrFail` outside the transaction. Event literals and payloads unchanged. | `grep -n "catch\|Log::"` | no output | 2026-10-17 |
| CNTRY-02 | `CountryController.php` toggleStatus | Manual begin/commit/rollBack → one `DB::transaction` closure; state + district cascade and `'Toggled'` log inside it; JSON built after. Status read with `$request->boolean()`. Imports `Modules\GlobalMaster\Models\State`/`District` replace the inline FQCNs. | rolled-back toggle | success=true, is_active=false | 2026-10-17 |
| CNTRY-04 | `CountryController.php` | Duplicate `Gate::authorize` dropped from store/update — `CountryRequest::authorize()` checks the same permission first. | `grep -n "Gate::authorize" ` | 9 of 11 methods (store/update absent) | 2026-10-17 |
| CNTRY-06 | `CountryController.php` | Return types on all 11 public methods. | `php -l` + `class_exists` | clean / true | 2026-10-17 |
| CNTRY-07 | `Country.php` | `is_active` boolean cast. | `var_export($c->is_active)` | `true` | 2026-10-17 |
| CNTRY-08 | `Country.php` | `states(): HasMany`. | `get_class($c->states())` | HasMany | 2026-10-17 |
| CNTRY-10 | controller, request, model | `declare(strict_types=1);` (+ `prepareForValidation(): void`). | grep | 1 each | 2026-10-17 |
| CNTRY-11 | `CountryController.php` | Imports of the non-existent `App\Models\V1\GlobalMaster\{State,District}` removed. | `grep -n "Models\\\\V1"` | no output | 2026-10-17 |
| CNTRY-12 | `CountryController.php` | `begin::Activity Log` / `Syntex` boilerplate removed; calls kept. | `grep -c "Syntex"` | 0 | 2026-10-17 |
| CNTRY-13 | `CountryController.php` forceDelete | DECISION (a). Refuses when `states()->withTrashed()->count() > 0` (the RESTRICT FK sees trashed states) with "Country "X" still has N state(s). Delete or move them first." — no write, no log. Same shape as StateController (STAT-19). | rolled-back forceDelete of India | refused, row kept, message shown (36 states) | 2026-10-17 |

## 3. Not applied
- CNTRY-05 — superseded by the POST route (§1).
- CNTRY-09 — DECISION (a): deferred to the module modal-conversion pass (accepted debt).

## 4. Needs Tarun's hand
- Browser check: `/global-master/location-setup#country` — create, edit, toggle (cascade to states/districts), trash → restore, force-delete of a country with states (should refuse).

## 5. Unverifiable by this workflow (D4)
- Store/update authorization relies on `CountryRequest::authorize()`; every check here ran as super admin.

## 6. Verification log
```
vendor/bin/pint <3 files> --format agent             → fixed Country.php, CountryRequest.php (spacing/imports)
php -l <3 files>                                      → No syntax errors
class_exists(CountryController|CountryRequest|Country) → true ×3
route:list --json (uncached) + method_exists          → routes=22 missing=0
render location-setup / create / trashed              → 200 · 3,554,743 / 128,645 / 114,728 bytes, 0 comment leaks
render edit / show (after DecryptUrl redirect)        → 200 · 128,869 / 115,670 bytes
rolled back: trash India → forceDelete                → refused, "still has 36 state(s)"
rolled back: create probe → toggle → trash → forceDelete → success / is_active=false / gone; 0 leftovers, India not trashed after rollback
```

## 7. Final state
**FIXED.** Open: CNTRY-09 deferred (modal pass).

## 8. Follow-up 2026-10-17: the transactions did not cover the record (AFC-09)

Found while fixing AppConfigController. `Country` saves through `global_master_mysql`, but every `DB::transaction()` in this controller opened on the default `mysql` connection, where only `activityLog()` writes. These are two separate PDO handles, so the 6 transactions covered only the log. A failure after the save rolled back the audit row and left the record changed. The country status toggle (country → its states → their districts) could stop halfway.

**Applied:** all 6 calls now use `WritesGlobalMaster::inGlobalMasterTransaction()` (new trait, `Http/Controllers/Concerns/`), which opens a `global_master_mysql` transaction around the default one. Tarun approved fixing all six FIXED controllers together.

**Verified:** `php -l` clean · class loads · every routed method exists · host page renders 200 · a simulated failure through this controller's helper rolls back both the record and the log · negative control: plain `DB::transaction` left the global_master write in place.
