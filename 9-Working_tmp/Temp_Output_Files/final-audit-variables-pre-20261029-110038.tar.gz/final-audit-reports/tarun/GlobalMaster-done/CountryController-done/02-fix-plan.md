# Fix Plan — GlobalMaster / CountryController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` to `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/CountryController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | Shared permission catalogue; the keys this controller needs already exist (`global-master.country`), so no edit is required |
| `Modules/GlobalMaster/app/Models/State.php`, `Modules/GlobalMaster/app/Models/District.php` | Owned by the State/District audit reports; the cascade in `toggleStatus` is fixed in this controller only |
| `resources/views/components/backend/table/action.blade.php`, `action-trashed.blade.php`, `status-switch.blade.php`, `partials/footer-scripts.blade.php` | Shared components; already handle GET/DELETE and AJAX errors correctly |
| `app/Helpers/activityLog.php`, `app/Models/BaseModel.php`, `app/Traits/AuthorizesTenantFeature.php` | Common classes, not audited here |
| Any file under `database/migrations/` | Never edit an existing migration |
| `final-audit-reports/tarun/GlobalMaster-done/00-INDEX.md` | Update only the CountryController row, never rewrite the file |

`Modules/GlobalMaster/routes/web.php` IS edited by ticked item CNTRY-05 (marked SHARED); no other item may touch it.

## 1. Blockers reachable today

- [x] **CNTRY-01** · H · ERR-00 · `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:47-68` (and four siblings) — delete the controller `try/catch` blocks and build the redirects after the transaction.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Before** (`CountryController.php:5-15`, imports — remove only `ModelNotFoundException` and `Log`; the two `App\Models\V1\...` lines go in CNTRY-11):
    ```php
    use App\Http\Controllers\Controller;
    use App\Models\V1\GlobalMaster\District;
    use App\Models\V1\GlobalMaster\State;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\GlobalMaster\Http\Requests\CountryRequest;
    use Modules\GlobalMaster\Models\Country;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use App\Models\V1\GlobalMaster\District;
    use App\Models\V1\GlobalMaster\State;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\GlobalMaster\Http\Requests\CountryRequest;
    use Modules\GlobalMaster\Models\Country;
    ```
  - **Before** (`CountryController.php:43-69`, method `store()`):
    ```php
    public function store(CountryRequest $request)
    {
        Gate::authorize('prime.global-master.country.create');

        try {
            return DB::transaction(function () use ($request) {
                $country = Country::create($request->validated());

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($country, 'Stored', ['message' => 'A new country was created.', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->to(route('central.global-master.location-setup.index').'#country')
                    ->with('success', flash('created.country'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('CountryController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function store(CountryRequest $request)
    {
        Gate::authorize('prime.global-master.country.create');

        DB::transaction(function () use ($request) {
            $country = Country::create($request->validated());

            activityLog($country, 'Stored', ['message' => 'A new country was created.', 'other' => 'some other information']);
        });

        return redirect()->to(route('central.global-master.location-setup.index').'#country')
            ->with('success', flash('created.country'));
    }
    ```
  - **Before** (`CountryController.php:94-145`, method `update()`):
    ```php
    public function update(CountryRequest $request, Country $country)
    {
        Gate::authorize('prime.global-master.country.update');

        try {
            return DB::transaction(function () use ($request, $country) {
                $original = $country->getOriginal();
                $country->update($request->validated());

                $changes = $country->getChanges();
                // Build a structured array of changes:
                $changedAttributes = [];

                foreach ($changes as $field => $newValue) {
                    // Exclude updated_at and other auto fields
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changedAttributes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                // Log only if there are changes
                if (! empty($changedAttributes)) {
                    activityLog($country, 'Updated', [
                        'message' => 'A new country was updated.',
                        'changes' => $changedAttributes,
                        'performed_by' => Auth::user()->name,
                    ]);
                } else {
                    activityLog($country, 'Updated', [
                        'message' => 'A new country was updated. No attributes changed.',
                        'performed_by' => Auth::user()->name,
                    ]);
                }

                return redirect()->to(route('central.global-master.location-setup.index').'#country')
                    ->with('success', flash('updated.country'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('CountryController::update failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function update(CountryRequest $request, Country $country)
    {
        Gate::authorize('prime.global-master.country.update');

        DB::transaction(function () use ($request, $country) {
            $original = $country->getOriginal();
            $country->update($request->validated());

            $changes = $country->getChanges();
            $changedAttributes = [];

            foreach ($changes as $field => $newValue) {
                if ($field === 'updated_at') {
                    continue;
                }
                $changedAttributes[$field] = [
                    'old' => $original[$field] ?? null,
                    'new' => $newValue,
                ];
            }

            if (! empty($changedAttributes)) {
                activityLog($country, 'Updated', [
                    'message' => 'A new country was updated.',
                    'changes' => $changedAttributes,
                    'performed_by' => Auth::user()->name,
                ]);
            } else {
                activityLog($country, 'Updated', [
                    'message' => 'A new country was updated. No attributes changed.',
                    'performed_by' => Auth::user()->name,
                ]);
            }
        });

        return redirect()->to(route('central.global-master.location-setup.index').'#country')
            ->with('success', flash('updated.country'));
    }
    ```
  - **Before** (`CountryController.php:150-178`, method `destroy()`):
    ```php
    public function destroy(Country $country)
    {
        Gate::authorize('prime.global-master.country.delete');

        try {
            return DB::transaction(function () use ($country) {
                $country->is_active = false;
                $country->save();
                $country->delete();

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($country, 'Trashed', ['message' => 'A new country was deactivated and deleted.', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->to(route('central.global-master.location-setup.index').'#country')
                    ->with('success', flash('trashed.country'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('CountryController::destroy failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function destroy(Country $country)
    {
        Gate::authorize('prime.global-master.country.delete');

        DB::transaction(function () use ($country) {
            $country->is_active = false;
            $country->save();
            $country->delete();

            activityLog($country, 'Trashed', ['message' => 'A new country was deactivated and deleted.', 'other' => 'some other information']);
        });

        return redirect()->to(route('central.global-master.location-setup.index').'#country')
            ->with('success', flash('trashed.country'));
    }
    ```
  - **Before** (`CountryController.php:190-216`, method `restore()`):
    ```php
    public function restore($id)
    {
        Gate::authorize('prime.global-master.country.restore');

        try {
            return DB::transaction(function () use ($id) {
                $country = Country::withTrashed()->findOrFail($id);
                $country->restore();

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($country, 'Restored', ['message' => 'A new country was restored.', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->route('central.global-master.country.trashed')->with('success', flash('restored.country'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('CountryController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function restore($id)
    {
        Gate::authorize('prime.global-master.country.restore');

        DB::transaction(function () use ($id) {
            $country = Country::withTrashed()->findOrFail($id);
            $country->restore();

            activityLog($country, 'Restored', ['message' => 'A new country was restored.', 'other' => 'some other information']);
        });

        return redirect()->route('central.global-master.country.trashed')->with('success', flash('restored.country'));
    }
    ```
  - **Before** (`CountryController.php:218-244`, method `forceDelete()`):
    ```php
    public function forceDelete($id)
    {
        Gate::authorize('prime.global-master.country.forceDelete');

        try {
            return DB::transaction(function () use ($id) {
                $country = Country::withTrashed()->findOrFail($id);
                $country->forceDelete();

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($country, 'Deleted', ['message' => 'A new country was permanently deleted.', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()->route('central.global-master.country.trashed')->with('success', flash('force_deleted.country'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('CountryController::forceDelete failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function forceDelete($id)
    {
        Gate::authorize('prime.global-master.country.forceDelete');

        DB::transaction(function () use ($id) {
            $country = Country::withTrashed()->findOrFail($id);
            $country->forceDelete();

            activityLog($country, 'Deleted', ['message' => 'A new country was permanently deleted.', 'other' => 'some other information']);
        });

        return redirect()->route('central.global-master.country.trashed')->with('success', flash('force_deleted.country'));
    }
    ```
  - **Verify:** `grep -n "catch (" Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Expect:** one line only — `290:        } catch (\Throwable $e) {` (the `toggleStatus` catch, removed by CNTRY-02). No `ModelNotFoundException` catch remains.
  - **Effort:** M

- [ ] **CNTRY-05** · H · RTE-01 · `Modules/GlobalMaster/routes/web.php:42` (and `:152`) — make the restore route DELETE instead of GET. ⚠ SHARED (route file).
  - **Touches:** `Modules/GlobalMaster/routes/web.php`
  - **Before** (`web.php:42`, identical at `:152`):
    ```php
        Route::get('/country/{id}/restore', [CountryController::class, 'restore'])->name('country.restore');
    ```
  - **After:**
    ```php
        Route::delete('/country/{id}/restore', [CountryController::class, 'restore'])->name('country.restore');
    ```
  - **Verify:** `grep -n "restore', \[CountryController::class" Modules/GlobalMaster/routes/web.php`
  - **Expect:** both lines now read `Route::delete('/country/{id}/restore', ...)`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None. CNTRY-01 (removing the catches) must be applied before CNTRY-11 (removing the `Log`/`ModelNotFoundException`-adjacent imports) — the plan order already enforces this.

## 3. Errors & transactions (F1/F2)

- [x] **CNTRY-02** · M · TXN-02 · `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:249-301` — convert `toggleStatus` to `DB::transaction(...)` and drop the manual begin/commit/rollback and its catch.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Before** (`CountryController.php:249-301`, method `toggleStatus()`):
    ```php
    public function toggleStatus(Request $request, Country $country)
    {
        Gate::authorize('prime.global-master.country.update');
        $request->validate([
            'is_active' => 'required|boolean',
        ]);

        DB::beginTransaction();

        try {
            // Change the Country status.
            $country->is_active = $request->input('is_active');
            $country->save();
            // get the current status of country
            $status = $country->is_active;
            // Update the status of all the states belongs to the current country.
            \Modules\GlobalMaster\Models\State::where('country_id', $country->id)->update([
                'is_active' => $status,
            ]);
            $stateId = \Modules\GlobalMaster\Models\State::where('country_id', $country->id)->pluck('id');

            // Update the status of all the district belongs to the state
            \Modules\GlobalMaster\Models\District::whereIn('state_id', $stateId)->update([
                'is_active' => $status,
            ]);
            // begin::Activity Log
            // Logged BEFORE the commit, so the log row is part of the same transaction
            // (Rule 3). It used to sit after DB::commit(): if the log write then failed,
            // the cascade to states and districts was already committed and the rollBack()
            // in the catch below was a no-op, leaving the change with no audit entry.
            activityLog($country, 'Toggled', ['message' => 'A new country status was updated.', 'other' => 'some other information']);
            // end::Activity Log

            // commit the changes
            DB::commit();

            return response()->json([
                'success' => true,
                'is_active' => $country->is_active,
                'message' => flash('status_updated.country'),
            ]);
        } catch (\Throwable $e) {
            // \Throwable, not \Exception: \Error subclasses (TypeError, ValueError) would
            // otherwise escape this catch and leave the transaction open (Rule 1).
            DB::rollBack();

            return response()->json([
                'success' => false,
                'is_active' => $country->is_active,
                'message' => flash('status_switch_failed.country'),
            ]);
        }
    }
    ```
  - **After:**
    ```php
    public function toggleStatus(Request $request, Country $country)
    {
        Gate::authorize('prime.global-master.country.update');
        $request->validate([
            'is_active' => 'required|boolean',
        ]);

        DB::transaction(function () use ($request, $country) {
            $country->is_active = $request->input('is_active');
            $country->save();

            $status = $country->is_active;

            \Modules\GlobalMaster\Models\State::where('country_id', $country->id)->update([
                'is_active' => $status,
            ]);
            $stateId = \Modules\GlobalMaster\Models\State::where('country_id', $country->id)->pluck('id');

            \Modules\GlobalMaster\Models\District::whereIn('state_id', $stateId)->update([
                'is_active' => $status,
            ]);

            activityLog($country, 'Toggled', ['message' => 'A new country status was updated.', 'other' => 'some other information']);
        });

        return response()->json([
            'success' => true,
            'is_active' => $country->is_active,
            'message' => flash('status_updated.country'),
        ]);
    }
    ```
  - **Verify:** `grep -n "beginTransaction\|DB::commit\|DB::rollBack" Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Expect:** no output.
  - **Effort:** M

## 4. Authorization (F3)

- [x] **CNTRY-04** · L · AUTH-04 · `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:45,96` — drop the duplicate `Gate::authorize` in `store`/`update` (the FormRequest already authorizes). Keep `toggleStatus`'s own `Gate::authorize` — it has no FormRequest.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Before** (`CountryController.php:43-45`, method `store()`):
    ```php
    public function store(CountryRequest $request)
    {
        Gate::authorize('prime.global-master.country.create');
    ```
  - **After:**
    ```php
    public function store(CountryRequest $request)
    {
    ```
  - **Before** (`CountryController.php:94-96`, method `update()`):
    ```php
    public function update(CountryRequest $request, Country $country)
    {
        Gate::authorize('prime.global-master.country.update');
    ```
  - **After:**
    ```php
    public function update(CountryRequest $request, Country $country)
    {
    ```
  - **Verify:** `grep -n "Gate::authorize" Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Expect:** 9 matches (one per remaining method; the `store` and `update` lines are gone).
  - **Effort:** S
  - ⚠ This item deletes only the `Gate::authorize` lines; it is independent of CNTRY-01 (the `try {` line, if still present, is left untouched).

## 5. Validation, routes, models (F4/F5/F7)

- [x] **CNTRY-06** · L · CTL-04 · `Modules/GlobalMaster/app/Http/Controllers/CountryController.php` (11 signatures) — add return types to every public method.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Before** (`CountryController.php:22`):
    ```php
    public function index()
    ```
  - **After:** add the three imports, then give each of the 11 methods the return type shown.
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\View\View;
    ```
    ```php
    public function index(): View
    public function create(): View
    public function store(CountryRequest $request): RedirectResponse
    public function show(Country $country): View
    public function edit(Country $country): View
    public function update(CountryRequest $request, Country $country): RedirectResponse
    public function destroy(Country $country): RedirectResponse
    public function trashedCountry(): View
    public function restore($id): RedirectResponse
    public function forceDelete($id): RedirectResponse
    public function toggleStatus(Request $request, Country $country): JsonResponse
    ```
  - **Verify:** `grep -cE 'public function [a-zA-Z_]+\([^)]*\): ' Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Expect:** `11`
  - **Effort:** S

- [x] **CNTRY-07** · M · MDL-02 · `Modules/GlobalMaster/app/Models/Country.php:9-22` — add the `is_active` boolean cast.
  - **Touches:** `Modules/GlobalMaster/app/Models/Country.php`
  - **Before** (`Country.php:9-22`):
    ```php
    class Country extends BaseModel
    {
        use SoftDeletes;

        protected $connection = 'global_master_mysql';

        protected $table = 'glb_countries';
        protected $fillable = [
            'name',
            'short_name',
            'global_code',
            'currency_code',
            'is_active',
        ];
    ```
  - **After:**
    ```php
    class Country extends BaseModel
    {
        use SoftDeletes;

        protected $connection = 'global_master_mysql';

        protected $table = 'glb_countries';
        protected $fillable = [
            'name',
            'short_name',
            'global_code',
            'currency_code',
            'is_active',
        ];

        protected $casts = [
            'is_active' => 'boolean',
        ];
    ```
  - **Verify:** `grep -n "'is_active' => 'boolean'" Modules/GlobalMaster/app/Models/Country.php`
  - **Expect:** one match.
  - **Effort:** S

- [x] **CNTRY-08** · L · MDL-04 · `Modules/GlobalMaster/app/Models/Country.php:25-28` — add the `HasMany` return type to `states()`.
  - **Touches:** `Modules/GlobalMaster/app/Models/Country.php`
  - **Before** (`Country.php:25-28`):
    ```php
    public function states()
    {
        return $this->hasMany(State::class);
    }
    ```
  - **After:** also add the import `use Illuminate\Database\Eloquent\Relations\HasMany;` next to the other class imports.
    ```php
    public function states(): HasMany
    {
        return $this->hasMany(State::class);
    }
    ```
  - **Verify:** `grep -n "public function states(): HasMany" Modules/GlobalMaster/app/Models/Country.php`
  - **Expect:** one match.
  - **Effort:** S

## 6. Queries & performance (F9)

None. F9 is clean.

## 7. Views (F10)

None. The modal conversion is a DECISION (CNTRY-09 in §9); no mechanical view edit is planned here.

## 8. Style (F12) — one item per file

- [x] **CNTRY-10** · L · STY-01 · `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:1`, `.../Http/Requests/CountryRequest.php:1`, `.../Models/Country.php:1` — add `declare(strict_types=1);` to the three files.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/CountryController.php`, `Modules/GlobalMaster/app/Http/Requests/CountryRequest.php`, `Modules/GlobalMaster/app/Models/Country.php`
  - **Before** (`CountryController.php:1-3`; the request and model open the same way):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
    Same two-line insertion, replacing only the `namespace ...;` line, in:
    ```php
    namespace Modules\GlobalMaster\Http\Requests;
    ```
    ```php
    namespace Modules\GlobalMaster\Models;
    ```
  - **Verify:** `grep -c "declare(strict_types=1);" Modules/GlobalMaster/app/Http/Controllers/CountryController.php Modules/GlobalMaster/app/Http/Requests/CountryRequest.php Modules/GlobalMaster/app/Models/Country.php`
  - **Expect:** `1` for each of the three files.
  - **Effort:** S

- [x] **CNTRY-11** · L · STY-05 · `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:6-7` — delete the two imports that name non-existent classes.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Before** (`CountryController.php:5-7`):
    ```php
    use App\Http\Controllers\Controller;
    use App\Models\V1\GlobalMaster\District;
    use App\Models\V1\GlobalMaster\State;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    ```
  - **Verify:** `grep -n "App\\\\Models\\\\V1\\\\GlobalMaster" Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **CNTRY-12** · L · STY-04 · `Modules/GlobalMaster/app/Http/Controllers/CountryController.php` (5 blocks) — remove the copy-pasted `begin::Activity Log` / `Syntex` boilerplate, keeping the `activityLog(...)` call.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Before** (`CountryController.php:51-53`, method `store()`; the same block appears in `destroy`, `restore`, `forceDelete` and `toggleStatus`):
    ```php
                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($country, 'Stored', ['message' => 'A new country was created.', 'other' => 'some other information']);
    ```
  - **After:**
    ```php
                activityLog($country, 'Stored', ['message' => 'A new country was created.', 'other' => 'some other information']);
    ```
  - **Verify:** `grep -c "Syntex : activityLog" Modules/GlobalMaster/app/Http/Controllers/CountryController.php`
  - **Expect:** `0`
  - **Effort:** S

## 9. Deferred / decisions

- [x] **CNTRY-09** · M · DECISION · VIEW (modal-standard §2.5) — convert the country create/edit pages to the shared modal, or defer to the module-wide modal pass?
  - **Why it is a decision:** it is a UI conversion shared with State/District/City, changes routes' view contract, and the module has a standing modal backlog.
  - (a) ⭐ defer to the module modal-conversion pass — record it as accepted debt now
  - (b) convert `create`/`edit` for Country only (touches the controller methods and both blades)
  - (c) leave as is permanently and record as accepted
  - ➜ Choice: (a) — Tarun 2026-10-17. Deferred to the module modal-conversion pass.

- [x] **CNTRY-13** · M · DECISION · F13 deep-read — `forceDelete` of a country that still has states is rejected by the DB foreign key (`ON DELETE RESTRICT`); pick the behaviour.
  - **Why it is a decision:** it changes what the user sees on a real screen and needs a product answer, not a mechanical edit.
  - (a) ⭐ block early in `forceDelete` with a clear flash when `$country->states()->exists()`
  - (b) leave the DB to reject and translate the `QueryException` into a readable message
  - (c) leave as is and record as accepted (the generic error stays)
  - ➜ Choice: (a) — Tarun 2026-10-17. Implemented with a withTrashed() state count (FK sees trashed states).

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CNTRY-03 | Collateral of CNTRY-01: once the transaction closures return `void` and the redirects are built after them, the response is no longer constructed inside a transaction. No separate edit is needed. |
