# Final Audit — GlobalMaster / ActivityLogController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php` (80 lines, 7 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | **none.** `route:list` resolves zero routes to `Modules\GlobalMaster\...\ActivityLogController@*`. The central activity-log screen that does exist is served by two other controllers: `Modules\Prime\Http\Controllers\ActivityLogController` under `central.prime.activity-log.*` (`/prime/activity-log`) and `Modules\TenantCore\Http\Controllers\ActivityLogController` under `system-config.activity-log.*` (`/system-config/activity-log`). |
| Menu path | none — no route exists, so no menu entry can reach it. The Breadcrumb registry still holds a dead `global-master.activity-log.index` entry (`S5_TOPLEVEL`) for a route that no longer exists. |
| Who uses it | nobody. The live central screen is used by super-admin roles holding `prime.prime.activity-log.*` (`prime.prime.activity-log.viewAny` and friends). |
| What a user does here | On the live screen an admin reads the central audit trail (`sys_central_activity_logs`): who did what, when, from which IP and user agent. On **this** copy nothing runs — it is an unrouted duplicate of the live Prime controller. |
| Tables written | none. No method in this controller writes anything. |
| Tables read | `sys_central_activity_logs` (via `Modules\Prime\Models\ActivityLog`) — only inside the unrouted `index()` body. |
| Live data | `sys_central_activity_logs` — **1 row** live. The table has no `deleted_at` column, so there is no trashed set. |

**How to reach each bug in the browser:** you cannot. There is no route to this controller.
Every finding below is a latent defect that would become live only if a route were added.

## 1. Verdict

This controller is **not production code — it is a dead duplicate**. Its routes were deliberately
removed on 2026-09-30 (`Modules/GlobalMaster/routes/web.php:26-30`) because the central screen now
belongs to `Modules\Prime\Http\Controllers\ActivityLogController`; the class itself was left behind,
so all seven public methods answer no URL and none carries the D5 `abort(403)` guard. The single
worst finding is that **all seven methods are unrouted with live bodies** (ALC-01): anyone who copies
the Prime route block back into this file silently arms a half-working screen whose `create`/`show`/
`edit` views (`globalmaster::create` / `globalmaster::show` / `globalmaster::edit`) do not exist and
whose `index` view checks the wrong permission scope. Effort is small (S): mechanically D5-disable the
seven methods, fix the model's relation style, and decide whether the dead screen is deleted or kept
D5-disabled. Nothing here executes today, so there is no blocker for go-live.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 5 | 2 | 1 | 7 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | ALC-04 |
| F3 Authorization | ALC-05 | F10 Views | ALC-04, ALC-05, ALC-06 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | ALC-01 | F12 Style | ALC-03, ALC-07 |
| F6 Controller shape | ALC-02 (and CTL-04 closed inside ALC-01) | F13 Deep read | ALC-06 (see table) |
| F7 Models | ALC-07 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php` | controller | 80 | this report | ✅ |
| 2 | `Modules/Prime/app/Models/ActivityLog.php` | model (shared, first reach) | 51 | this report (claimed in `00-CLASS-OWNERS.md`) | ✅ |
| 3 | `Modules/GlobalMaster/resources/views/activity-log/index.blade.php` | view | 127 | this report | ✅ |

Common, not claimed: `App\Http\Controllers\Controller`, `Illuminate\Http\Request`,
`Illuminate\Support\Facades\Gate`, `Modules\Prime\Models\User` (reached only through the model's
`user()` relation), `App\Models\BaseModel`, the shared `x-backend.*` components used by the view.

Rendered-but-missing views (shared placeholder names used by many controllers,
`view()->exists()` proves they are absent): `globalmaster::create`, `globalmaster::show`,
`globalmaster::edit` — cross-cutting note, not owned here.

**Difference from the other GlobalMaster audits:** the `activityLog()` helper
(`app/Helpers/activityLog.php:4-5`) treats `Modules\GlobalMaster\Models\ActivityLog` (table
`sys_activity_logs`) as the **tenant** sink and `Modules\Prime\Models\ActivityLog` (table
`sys_central_activity_logs`) as the **central** sink. Other reports treat the GlobalMaster sink as
COMMON. **This** controller imports the central model directly
(`use Modules\Prime\Models\ActivityLog;`) — correct for a central screen — so the class audited here
is the Prime one, not the GlobalMaster sink.

No pre-applied files.

## 4. Routes

The uncached route list (`/tmp/fa-routes.json`) resolves **zero** routes to this controller:

```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); $n=0;
          foreach($r as $x){ if(str_contains($x["action"],"Modules\\GlobalMaster\\Http\\Controllers\\ActivityLogController")) $n++; }
          echo "COUNT=$n\n";'
COUNT=0
```

Every `activity-log` route that answers is owned by another controller:

```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true);
          foreach($r as $x){ if(str_contains($x["uri"],"activity-log")) printf("%-15s %-45s %s\n",$x["method"],$x["uri"],$x["action"]); }'
GET|HEAD        global-master/activity-log                    Modules\Prime\Http\Controllers\ActivityLogController@index
POST            global-master/activity-log                    Modules\Prime\Http\Controllers\ActivityLogController@store
GET|HEAD        global-master/activity-log/create             Modules\Prime\Http\Controllers\ActivityLogController@create
GET|HEAD        global-master/activity-log/search             Modules\Prime\Http\Controllers\ActivityLogController@search
GET|HEAD        global-master/activity-log/{activity_log}     Modules\Prime\Http\Controllers\ActivityLogController@show
PUT|PATCH       global-master/activity-log/{activity_log}     Modules\Prime\Http\Controllers\ActivityLogController@update
DELETE          global-master/activity-log/{activity_log}     Modules\Prime\Http\Controllers\ActivityLogController@destroy
GET|HEAD        global-master/activity-log/{activity_log}/edit Modules\Prime\Http\Controllers\ActivityLogController@edit
GET|HEAD        prime/activity-log                            Modules\Prime\Http\Controllers\ActivityLogController@index
POST            prime/activity-log                            Modules\Prime\Http\Controllers\ActivityLogController@store
GET|HEAD        prime/activity-log/create                     Modules\Prime\Http\Controllers\ActivityLogController@create
GET|HEAD        prime/activity-log/search                     Modules\Prime\Http\Controllers\ActivityLogController@search
GET|HEAD        prime/activity-log/{activity_log}             Modules\Prime\Http\Controllers\ActivityLogController@show
PUT|PATCH       prime/activity-log/{activity_log}             Modules\Prime\Http\Controllers\ActivityLogController@update
DELETE          prime/activity-log/{activity_log}             Modules\Prime\Http\Controllers\ActivityLogController@destroy
GET|HEAD        prime/activity-log/{activity_log}/edit        Modules\Prime\Http\Controllers\ActivityLogController@edit
GET|HEAD        system-config/activity-log                    Modules\TenantCore\Http\Controllers\ActivityLogController@index
```

Unrouted public methods: **all seven** — `index` (line 15), `create` (30), `store` (39), `show` (47),
`edit` (57), `update` (66), `destroy` (75). None carries the D5 `abort(403)` guard.

The removal is documented in the route file itself:

```
$ sed -n '26,30p' Modules/GlobalMaster/routes/web.php
// REMOVED 2026-09-30: this file used to register Route::resource('activity-log',
// GlobalMaster\ActivityLogController) under `global-master.` with NO domain binding, so
// /global-master/activity-log answered on every tenant host. The central screen is
// central.global-master.activity-log.* (Modules\Prime\…\ActivityLogController, see
// Modules/Prime/routes/web.php).
```

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 15 | — (unrouted) | `prime.prime.activity-log.viewAny` via `Gate::any` | none (read) | — | none | ALC-01, ALC-04, ALC-05, ALC-06 |
| `create` | 30 | — (unrouted) | `prime.prime.activity-log.create` | none (read) | — | none | ALC-01 |
| `store` | 39 | — (unrouted) | `prime.prime.activity-log.create` | none | — | none | ALC-01 |
| `show` | 47 | — (unrouted) | `prime.prime.activity-log.view` | none (read) | — | none | ALC-01 |
| `edit` | 57 | — (unrouted) | `prime.prime.activity-log.update` | none (read) | — | none | ALC-01 |
| `update` | 66 | — (unrouted) | `prime.prime.activity-log.update` | none | — | none | ALC-01 |
| `destroy` | 75 | — (unrouted) | `prime.prime.activity-log.delete` | none | — | none | ALC-01 |

No routed method exists, so no authorization obligation is live. Every gate string is declared in
`config/permissionslist.php` (exact-name check in F3).

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try \{|catch ?\(' Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php` → no output; `grep -n 'getMessage' Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php` → no output. There is no `try`, no catch, no `withErrors`/`back()`/`json()` and no write path that can fail.

### F2 — Transactions and audit

clean — `grep -nE 'DB::|transaction|activityLog' Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php` → no output. The only method with a body is `index()`, a read. `store`/`update`/`destroy` contain a gate and nothing else, so there is no multi-table write and no audit row to place.

### F3 — Authorization

Every gate string is declared in `config/permissionslist.php`, verified with an exact-name flatten
(the scope prefix is prepended by `PermissionHelper::flatten()`, so the key `prime.activity-log`
under the `prime` scope yields `prime.prime.activity-log.*`):

```
$ php artisan tinker --execute '$c=config("permissionslist"); $flat=[];
  foreach($c as $scope=>$keys){ foreach($keys as $k=>$v){ foreach($v as $a){ $flat[]="$scope.$k.$a"; } } }
  foreach(array_values(array_filter($flat, fn($f)=>str_contains($f,"activity-log")&&str_starts_with($f,"prime.prime"))) as $f) echo $f."\n";'
prime.prime.activity-log.create
prime.prime.activity-log.view
prime.prime.activity-log.viewAny
prime.prime.activity-log.update
prime.prime.activity-log.delete
prime.prime.activity-log.restore
prime.prime.activity-log.forceDelete
```

The gates are declared before any record is loaded (AUTH-02). `index()`'s
`Gate::any([...]) || abort(403)` has the required abort, so the no-op guard (AUTH-05) is satisfied.
The one authorization defect is the **view**, which names a different scope — recorded as ALC-05.

#### ALC-05 · M · AUTH-06 — the view gates the page on a tenant permission while the controller gates it on the prime permission

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *a permission name must appear identically on all four surfaces (controller, FormRequest, view, config); a literal repeated with a different scope can never agree* |
| **Where** | `Modules/GlobalMaster/resources/views/activity-log/index.blade.php:1` (outer `@can`) and `:47` (inner `@can`), against `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:19-21` |
| **Root cause** | The controller admits a user who holds `prime.prime.activity-log.viewAny` (central scope). The view's **outer** wrapper is `@can('tenant.global-master.activity-log.viewAny')` — a tenant-database permission that no central super-admin holds — while the inner table wrapper correctly uses `prime.prime.activity-log.viewAny`. The two surfaces therefore disagree about which permission opens the page. |
| **Consequence** | If this screen were ever routed, a super-admin who passes the controller gate would pass the inner table gate but fail the outer wrapper, so the whole page (layout and all) would render **blank** — a silent empty page with no error. |
| **Reproduce** | static only — the controller is unrouted (`route:list` COUNT=0), so the view cannot be reached in the browser. |
| **Fix approach** | Change the outer `@can` on line 1 to `prime.prime.activity-log.viewAny` so all surfaces agree — or delete the view with the dead screen (plan ALC-02). |
| **Plan item** | none — see `02-fix-plan.md` §10 (moot while the screen is dead) |

```php
// index.blade.php:1-2 — CURRENT
@can('tenant.global-master.activity-log.viewAny')
    <x-backend.layouts.app>
```

**Evidence**
```
$ grep -n "@can\|prime.prime.activity-log.viewAny\|tenant.global-master.activity-log.viewAny" Modules/GlobalMaster/resources/views/activity-log/index.blade.php
1:@can('tenant.global-master.activity-log.viewAny')
47:                            @can('prime.prime.activity-log.viewAny')
$ grep -n "activity-log.viewAny" Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php
20:            'prime.prime.activity-log.viewAny',
```

### F4 — Validation and input

clean — `grep -nE 'request\(\)->all|->all\(\)|->except\(|->fill\(|validated\(|validate\(' Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php` → no output. The controller reads no request input at all: `store` and `update` accept a `Request` and never touch it.

### F5 — Routes

#### ALC-01 · M · RTE-03 — all seven public methods are unrouted and still carry live bodies instead of the D5 abort

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M, D5) — *every public controller method is routed, or is deliberately disabled with `abort(403)` and a `NOT ROUTED` comment* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:15-79`, methods `index()`, `create()`, `store()`, `show()`, `edit()`, `update()`, `destroy()` |
| **Root cause** | The `global-master/activity-log` resource was removed from `Modules/GlobalMaster/routes/web.php` on 2026-09-30, but every method body was left intact. Sibling dead controllers in this module (e.g. `AcademicSessionController`) already follow D5 — an `abort(403)` body with a `// NOT ROUTED` comment — but this file was never converted. |
| **Consequence** | Nothing runs today, but the file is a loaded trap: copy the Prime controller's route block back and `create`/`show`/`edit` immediately 500 on missing views, `index` silently renders blank (ALC-05), and `store`/`update`/`destroy` succeed their gate and then do nothing — a user sees a success-shaped no-op. |
| **Reproduce** | static only — `route:list` proves COUNT=0 for this controller. |
| **Fix approach** | Replace each of the seven bodies with the D5 pattern (`abort(403, 'This endpoint is not available.')` plus a `// NOT ROUTED` comment) and type each method `: never`, closing CTL-04. The plan's After block is paste-ready. |
| **Plan item** | ALC-01 in `02-fix-plan.md` §5 |

```php
// ActivityLogController.php:15-79 — CURRENT
    public function index()
    {
        // Gate::authorize('tenant.global-master.activity-log.viewAny');

        Gate::any([
            'prime.prime.activity-log.viewAny',
        ]) || abort(403);

        $activityLogs = ActivityLog::latest()->paginate(10);
        return view('globalmaster::activity-log.index', compact('activityLogs'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        Gate::authorize('prime.prime.activity-log.create');
        return view('globalmaster::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        Gate::authorize('prime.prime.activity-log.create');
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        Gate::authorize('prime.prime.activity-log.view');

        return view('globalmaster::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        Gate::authorize('prime.prime.activity-log.update');
        return view('globalmaster::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        Gate::authorize('prime.prime.activity-log.update');

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        Gate::authorize('prime.prime.activity-log.delete');

    }
```

**Evidence**
```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); $n=0;
          foreach($r as $x){ if(str_contains($x["action"],"Modules\\GlobalMaster\\Http\\Controllers\\ActivityLogController")) $n++; }
          echo "COUNT=$n\n";'
COUNT=0
$ grep -nE 'public function [a-zA-Z_]+' Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php
15:    public function index()
30:    public function create()
39:    public function store(Request $request)
47:    public function show($id)
57:    public function edit($id)
66:    public function update(Request $request, $id)
75:    public function destroy($id)
```

### F6 — Controller shape

#### ALC-02 · M · CTL-10 — the whole controller is a dead duplicate of the live Prime activity-log screen

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code; a file whose entire behaviour duplicates another class is dead weight* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:10-11`, the whole class (80 lines) |
| **Root cause** | The feature this file implements is a copy of `Modules\Prime\Http\Controllers\ActivityLogController`, which owns every `central.prime.activity-log.*` and `central.global-master.activity-log.*` route. This GlobalMaster copy is registered in no route file (see §4); only its dead `index` renders `globalmaster::activity-log.index`. |
| **Consequence** | Every line is dead weight that will drift from the live controller and mislead the next developer who greps for "ActivityLogController". Its three dead form methods also point at views that do not exist. |
| **Reproduce** | `route:list` COUNT=0 (§4); `grep -rn 'GlobalMaster.Http.Controllers.ActivityLogController' Modules/ routes/` matches only the route-file comments. |
| **Fix approach** | **Decision item** — delete the controller with its view, or keep the file D5-disabled (self-documenting dead code). See plan ALC-02. |
| **Plan item** | ALC-02 in `02-fix-plan.md` §9 (DECISION) |

```php
// ActivityLogController.php:10-11 — CURRENT
class ActivityLogController extends Controller
{
```

**Evidence**
```
$ grep -rn "GlobalMaster\\\\Http\\\\Controllers\\\\ActivityLogController" Modules/ routes/ 2>/dev/null
Modules/GlobalMaster/routes/web.php:27:// GlobalMaster\ActivityLogController) under `global-master.` with NO domain binding, so
Modules/GlobalMaster/routes/web.php:29:// central.global-master.activity-log.* (Modules\Prime\…\ActivityLogController, see
$ php artisan tinker --execute 'foreach(["globalmaster::create","globalmaster::show","globalmaster::edit","globalmaster::activity-log.index"] as $v) printf("%-40s %s\n",$v, view()->exists($v)?"EXISTS":"MISSING");'
globalmaster::create                     MISSING
globalmaster::show                       MISSING
globalmaster::edit                       MISSING
globalmaster::activity-log.index         EXISTS
```

### F7 — Models

`Modules\Prime\Models\ActivityLog` was reached for the first time by this controller and is owned
here (claimed in `00-CLASS-OWNERS.md`). Checked against the migration
`database/migrations/2026_07_08_000001_create_central_activity_logs_table.php`:

- `$table = 'sys_central_activity_logs'` — exists (MDL-07 ✅).
- `$fillable` lists all seven writable columns; nothing sensitive (MDL-01 ✅).
- `$casts` maps `properties` to `array`; the table has no boolean/date/decimal/other-json column, so
  MDL-02 is satisfied. `created_at`/`updated_at` are auto-cast.
- No `SoftDeletes`, and the table has no `deleted_at` column — correct pairing.
- Live relations resolve: `user()` and `subject()` (morphTo) both returned a `Modules\Prime\Models\User`
  for the one live row (evidence under ALC-04).
- The only model defect is the missing strict types / relation return types — ALC-07.

#### ALC-07 · L · MDL-04/STY-01 — model relations lack return types and the file has no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed*; STY-01 (L) — *`declare(strict_types=1)` on touched files* |
| **Where** | `Modules/Prime/app/Models/ActivityLog.php:1-7` (header) and `:38-51` (relations) |
| **Root cause** | The file has no `declare(strict_types=1)`, and neither `subject()` nor `user()` declares a return type (`BelongsTo` / `MorphTo`). |
| **Consequence** | Convention drift only; static analysis cannot check the relations. Invisible at runtime. |
| **Reproduce** | scanner (evidence below). |
| **Fix approach** | Add `declare(strict_types=1)` and the two return types, importing `BelongsTo` and `MorphTo`. See plan ALC-07. |
| **Plan item** | ALC-07 in `02-fix-plan.md` §8 |

```php
// ActivityLog.php:1-7 — CURRENT
<?php

namespace Modules\Prime\Models;

use Modules\Prime\Models\User;
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
```

```php
// ActivityLog.php:38-48 — CURRENT
    //begin::Eloquent Relationships
    // Polymorphic relationship to the subject model (any model this log relates to)
    public function subject()
    {
        return $this->morphTo();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/Prime/app/Models/ActivityLog.php
L  STY-01   Modules/Prime/app/Models/ActivityLog.php:1  - — missing declare(strict_types=1)
L  MDL-04   Modules/Prime/app/Models/ActivityLog.php:40  subject — relation subject() has no return type
L  MDL-04   Modules/Prime/app/Models/ActivityLog.php:45  user — relation user() has no return type
```

### F8 — Services and jobs

clean — `grep -nE 'Service|Job|Event|Mail|Notification|dispatch\(' Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php` → no output. The controller names no service, job, event, mail or notification; the model names none either.

### F9 — Queries and performance

The read path (`index`) paginates at 10 (`ActivityLog::latest()->paginate(10)`) with the default page
name and a single paginator on the page, and `latest()` orders by `created_at`, which the migration
indexes (`index(['created_at','user_id'])`). No query sits in a loop and no raw SQL is used. One query
defect remains: the per-row dereference of the `user` relation in the view (ALC-04).

#### ALC-04 · M · QRY-01/VIEW-02 — the index view dereferences the `user` relation per row with no eager load and no null guard

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H, lowered to M — the page is unrouted, so the cost is latent) — *no lazy relation access inside a loop*; VIEW-02 (M) — *relations used in a loop must be eager-loaded* |
| **Where** | `Modules/GlobalMaster/resources/views/activity-log/index.blade.php:59-65` (the loop and `user->name`) and `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:23` (the query with no `with('user')`) |
| **Root cause** | `index()` runs `ActivityLog::latest()->paginate(10)` with no eager load, then the Blade `@forelse` reads `$activityLog->user->name` for each of the 10 rows — one extra SELECT per row (an N+1 = 1 + 10 queries). Separately, `user()` is a plain `belongsTo` and `Modules\Prime\Models\User` uses `SoftDeletes`, so a soft-deleted user makes `user` null and `->name` then throws. |
| **Consequence** | On the live-equivalent screen the list issues 11 queries instead of 2, and the page 500s the moment any user who appears in a log row is soft-deleted. |
| **Reproduce** | static only — controller unrouted. Relations were proven in tinker instead (evidence below): both resolve for the current row, and the User model does use `SoftDeletes`. |
| **Fix approach** | Eager-load `->with('user')` in `index()` and read the name null-safely (`{{ $activityLog->user?->name ?? 'Deleted user' }}`), or delete the view with the dead screen (plan ALC-02). |
| **Plan item** | none — see `02-fix-plan.md` §10 (moot while the screen is dead) |

```php
// index.blade.php:59-65 — CURRENT
                                        @forelse($activityLogs as $activityLog)
                                            <tr class="">
                                                <td>{{ $activityLog->subject_type }}</td>
                                                <td>{{ $activityLog->event }}</td>
                                                <td>
                                                    {{ $activityLog->user->name }}
                                                </td>
```

**Evidence**
```
$ grep -nE 'with\(|load\(' Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php
(no output — the query has no eager load)
$ grep -n 'user->' Modules/GlobalMaster/resources/views/activity-log/index.blade.php
64:                                                    {{ $activityLog->user->name }}
$ php artisan tinker --execute 'use Modules\Prime\Models\ActivityLog; $log=ActivityLog::first();
  $x=$log->user()->first(); echo "user() -> ".($x?get_class($x):"null")."\n";
  $u=new Modules\Prime\Models\User; echo "User uses SoftDeletes: ".(in_array("Illuminate\\Database\\Eloquent\\SoftDeletes", class_uses_recursive($u))?"YES":"NO")."\n";'
user() -> Modules\Prime\Models\User
User uses SoftDeletes: YES
```

### F10 — Views

The in-scope view `globalmaster::activity-log.index` compiles cleanly (verified with
`Blade::compileString` + `php -l` → "No syntax errors detected"; `@can`/`@endcan` balanced at 2 each,
`@push`/`@startPush` balanced at 0). It contains no `{!! !!}` raw output and no model/DB query, so
VIEW-01 and VIEW-03 are satisfied. Three view findings are recorded elsewhere: ALC-04 (N+1 / null
dereference), ALC-05 (wrong `@can` scope), ALC-06 (search box ignored).

#### ALC-06 · M · F13 — the rendered search box submits a filter that the controller never reads

| Field | Value |
|---|---|
| **Rule** | F13 deep-read #8 (M) — *a dead feature: a control whose saved/submitted data no consumer reads* |
| **Where** | `Modules/GlobalMaster/resources/views/activity-log/index.blade.php:20-32` (the form) against `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:23` (the query) |
| **Root cause** | The view renders a `GET` form with `<input name="search">`, but `index()` runs `ActivityLog::latest()->paginate(10)` with no reference to `search` (and takes no `Request`). There is also no `search()` action on this controller, unlike the live Prime controller which owns a `/search` route. |
| **Consequence** | A user who types a term and submits gets the full unfiltered list back — the control appears to work and silently does nothing. |
| **Reproduce** | static only — the screen is unrouted; `grep` shows the controller never reads `search` or `request()`. |
| **Fix approach** | If the screen is revived, read `$request->input('search')` in `index()` and filter, and add `->withQueryString()`; otherwise delete the form with the dead screen (plan ALC-02). |
| **Plan item** | none — see `02-fix-plan.md` §10 (moot while the screen is dead) |

```php
// index.blade.php:20-32 — CURRENT
                                    <form class="row g-2 align-items-center w-100" method="GET">
                                        <!-- Search -->
                                        <div class="col-12 col-sm">
                                            <input type="text" name="search" value="{{ request('search') }}"
                                                class="form-control form-control-sm w-100" placeholder="Search...">
                                        </div>
                                        <!-- Search Button -->
                                        <div class="col-12 col-sm-auto">
                                            <button class="btn btn-primary btn-sm w-100 w-sm-auto" type="submit">
                                                <i class="fa-solid fa-magnifying-glass"></i>
                                            </button>
                                        </div>
                                    </form>
```

**Evidence**
```
$ grep -nE "request\(\)|'search'|->search|input\(|paginate" Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php
23:        $activityLogs = ActivityLog::latest()->paginate(10);
$ grep -n "name=\"search\"\|request('search')" Modules/GlobalMaster/resources/views/activity-log/index.blade.php
23:                                            <input type="text" name="search" value="{{ request('search') }}"
```

### F11 — Security and tenancy

clean — `grep -n 'env(' <controller> <model> <view>` → no output; no `{!! !!}` on user text; the view
renders `properties` (`old`/`new` values) as escaped `{{ }}` text, which is the intended audit-trail
content; no logging of request bodies, no passwords or tokens, no hard-coded ids or `?? 1`. The model
pins `$connection = 'mysql'` for the central table, which is correct.

### F12 — Style

Scanner hits: `STY-01` missing `declare(strict_types=1)` on the controller and the model; `CTL-04`
missing return types on the seven controller methods. CTL-04 is closed by ALC-01's After (the typed
`abort(403)` bodies); STY-01 is split into one item per file (ALC-03 controller, ALC-07 model), per
the grouping rule. No debug leftovers, no unused imports in this controller (`Request` and `Gate` are
both used), no commented-out code longer than three lines.

#### ALC-03 · L · STY-01 — the controller has no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` on files you touch* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:1-8` |
| **Root cause** | The file opens with `<?php` and no `declare(strict_types=1);` line. |
| **Consequence** | Convention drift only; scalar coercion stays loose. Invisible at runtime. |
| **Reproduce** | scanner (evidence below). |
| **Fix approach** | Insert `declare(strict_types=1);` after the opening tag. See plan ALC-03. |
| **Plan item** | ALC-03 in `02-fix-plan.md` §8 |

```php
// ActivityLogController.php:1-8 — CURRENT
<?php

namespace Modules\GlobalMaster\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Modules\Prime\Models\ActivityLog;
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php
L  STY-01   Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:1  - — missing declare(strict_types=1)
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:15  index — index() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:30  create — create() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:39  store — store() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:47  show — show() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:57  edit — edit() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:66  update — update() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:75  destroy — destroy() has no return type
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There is no reachable mutating method — `store`, `update` and `destroy` are unrouted and gate-only.
The table records the deep-read verdict per method:

| Method | 1 wrong data | 2 delete-before-store | 3 dup impls | 4 soft-delete×unique | 5 race | 6 auth hole | 7 lying msg | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ALC-02 | ok | ok | ok | ok | ALC-02 |
| `update` | ok | ok | ALC-02 | ok | ok | ok | ok | ALC-02 |
| `destroy` | ok | ok | ALC-02 | ok | ok | ok | ok | ALC-02 |
| `index` (read) | ok | ok | ALC-02 | ok | ok | ALC-05 | ok | ALC-06 |

Question 3 (duplicate implementations) returns "yes" at the file level: this controller duplicates the
live Prime `ActivityLogController` (ALC-02). Question 8 yields the dead search box (ALC-06). Questions
1, 2, 4 and 5 are "ok" because nothing here ever writes.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `globalmaster::create` / `globalmaster::show` / `globalmaster::edit` | The three form/view names this controller's dead `create`/`show`/`edit` render do not exist anywhere (`view()->exists()` → MISSING). They are shared placeholder names used by several GlobalMaster controllers, so they are not owned here. | RTE-02 | GlobalMaster module pass / whoever revives those screens |
| Dead breadcrumb entry `global-master.activity-log.index` | `app/Services/Breadcrumbs/registry.php:1558` still maps the removed route name as `S5_TOPLEVEL`; the live entry is `central.global-master.activity-log.index` at line 989. | STY-04 | App-wide breadcrumb cleanup |
| `Modules\GlobalMaster\Models\ActivityLog` (the tenant sink) | The `activityLog()` helper and several controllers use this **different** model (table `sys_activity_logs`) as COMMON. This report audits the Prime central model instead; do not confuse the two. | MDL-07 | GlobalMaster module pass (if not already covered) |
| `Modules\GlobalMaster\Policies\ActivityLogPolicy` | Registered against `Modules\GlobalMaster\Models\ActivityLog` in `GlobalMasterServiceProvider.php:84` and gated on `tenant.global-master.activity-log.*`, but nothing consults it (this controller gates with string permissions, not policies); it is also scoped to the tenant permission unlike the central controller. | AUTH-06 | GlobalMaster module pass (policy audit) |

## 8. Not covered, and why

- The **live** `Modules\Prime\Http\Controllers\ActivityLogController` and
  `Modules\TenantCore\Http\Controllers\ActivityLogController`, and their requests/views, are other
  controllers' scope — not audited here (later batches own them).
- The GlobalMaster tenant sink `Modules\GlobalMaster\Models\ActivityLog` and its policy are a
  different model/policy pair; captured as cross-cutting notes only.
- No browser rendering was possible: this controller has no route (D4 — no tests; §10 verification
  only). The blade was compiled with `Blade::compileString` and linted instead, and the model
  relations were exercised in tinker.
