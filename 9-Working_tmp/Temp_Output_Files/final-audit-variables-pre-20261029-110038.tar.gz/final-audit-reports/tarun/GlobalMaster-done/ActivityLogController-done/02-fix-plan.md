# Fix Plan — GlobalMaster / ActivityLogController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php` | route file — the `activity-log` resource was deliberately removed 2026-09-30 and must stay removed |
| `Modules/Prime/app/Http/Controllers/ActivityLogController.php` | the LIVE controller — different controller, owned by a later Prime-module audit |
| `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php` | the LIVE system-config screen — different controller |
| `Modules/GlobalMaster/routes/*` and any central route registration | adding a route is out of scope for this pass (D3, fix in place) |
| `Modules/GlobalMaster/Policies/ActivityLogPolicy.php` and `Modules/GlobalMaster/app/Models/ActivityLog.php` | tenant sink + policy, not reached by this controller (§7 cross-cutting note) |
| `config/permissionslist.php` | shared permission source; no new key is proposed here |

## 1. Blockers reachable today

None — the controller is unrouted, so nothing here is reachable from the browser.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — F1 and F2 are clean.

## 4. Authorization (F3)

None as a plan item. The one view-scope defect (ALC-05) is moot while the screen is dead; see §10.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **ALC-01** · M · RTE-03 · `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:15-79` — disable all seven unrouted methods with the D5 `abort(403)` and type them `: never`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php`
  - **Before** (`ActivityLogController.php:15-79`):
    ```php
    public function index()
    {
        // Gate::authorize('tenant.global-master.activity-log.viewAny');

        Gate::any([
            'prime.prime.activity-log.viewAny',
        ]) || abort(403);

        $activityLogs = ActivityLog::latest()->paginate(10);
        return view('globalmaster::activity-log.index', compact('activityLogs'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        Gate::authorize('prime.prime.activity-log.create');
        return view('globalmaster::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        Gate::authorize('prime.prime.activity-log.create');
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        Gate::authorize('prime.prime.activity-log.view');

        return view('globalmaster::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        Gate::authorize('prime.prime.activity-log.update');
        return view('globalmaster::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        Gate::authorize('prime.prime.activity-log.update');

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        Gate::authorize('prime.prime.activity-log.delete');

    }
    ```
  - **After:**
    ```php
    public function index(): never
    {
        // NOT ROUTED 2026-10-12 — routes removed 2026-09-30 (Modules/GlobalMaster/routes/web.php:26).
        abort(403, 'This endpoint is not available.');
    }

    public function create(): never
    {
        // NOT ROUTED 2026-10-12 — routes removed 2026-09-30 (Modules/GlobalMaster/routes/web.php:26).
        abort(403, 'This endpoint is not available.');
    }

    public function store(Request $request): never
    {
        // NOT ROUTED 2026-10-12 — routes removed 2026-09-30 (Modules/GlobalMaster/routes/web.php:26).
        abort(403, 'This endpoint is not available.');
    }

    public function show($id): never
    {
        // NOT ROUTED 2026-10-12 — routes removed 2026-09-30 (Modules/GlobalMaster/routes/web.php:26).
        abort(403, 'This endpoint is not available.');
    }

    public function edit($id): never
    {
        // NOT ROUTED 2026-10-12 — routes removed 2026-09-30 (Modules/GlobalMaster/routes/web.php:26).
        abort(403, 'This endpoint is not available.');
    }

    public function update(Request $request, $id): never
    {
        // NOT ROUTED 2026-10-12 — routes removed 2026-09-30 (Modules/GlobalMaster/routes/web.php:26).
        abort(403, 'This endpoint is not available.');
    }

    public function destroy($id): never
    {
        // NOT ROUTED 2026-10-12 — routes removed 2026-09-30 (Modules/GlobalMaster/routes/web.php:26).
        abort(403, 'This endpoint is not available.');
    }
    ```
  - **Verify:** `grep -c "NOT ROUTED" Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php`
  - **Expect:** `7`
  - **Effort:** S

## 6. Queries & performance (F9)

None — the only query finding (ALC-04) is in the dead view and is moot while the screen is dead; see §10.

## 7. Views (F10)

None as a plan item. ALC-04, ALC-05 and ALC-06 are recorded in §10 with the reason they are not fixed here.

## 8. Style (F12) — one item per file

- [ ] **ALC-03** · L · STY-01 · `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php:1-8` — add `declare(strict_types=1)`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php`
  - **Before** (`ActivityLogController.php:1-8`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\Prime\Models\ActivityLog;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\Prime\Models\ActivityLog;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php`
  - **Expect:** one hit at line 3.
  - **Effort:** S

- [ ] **ALC-07** · L · MDL-04/STY-01 · `Modules/Prime/app/Models/ActivityLog.php:1-7,38-48` — add `declare(strict_types=1)` and return types on the two relations.
  - **Touches:** `Modules/Prime/app/Models/ActivityLog.php`
  - **Before** (`ActivityLog.php:1-7`):
    ```php
    <?php

    namespace Modules\Prime\Models;

    use Modules\Prime\Models\User;
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Prime\Models;

    use Modules\Prime\Models\User;
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\MorphTo;
    ```
  - **Second pair — Before** (`ActivityLog.php:38-48`):
    ```php
    //begin::Eloquent Relationships
    // Polymorphic relationship to the subject model (any model this log relates to)
    public function subject()
    {
        return $this->morphTo();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    ```
  - **Second pair — After:**
    ```php
    //begin::Eloquent Relationships
    // Polymorphic relationship to the subject model (any model this log relates to)
    public function subject(): MorphTo
    {
        return $this->morphTo();
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
    ```
  - **Verify:** `grep -n "function subject\|function user\|declare(strict_types=1)" Modules/Prime/app/Models/ActivityLog.php`
  - **Expect:** three hits — `declare(strict_types=1)` at line 3, `: MorphTo` on `subject()`, `: BelongsTo` on `user()`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **ALC-02** · M · DECISION · CTL-10 — the whole controller is a dead duplicate of the live Prime activity-log screen. Delete it, or keep it D5-disabled?
  - **Why it is a decision:** it removes a file (and its view). The protocol's default (D5) is to never delete — only Tarun may choose deletion.
  - (a) ⭐ delete `Modules/GlobalMaster/app/Http/Controllers/ActivityLogController.php` and `Modules/GlobalMaster/resources/views/activity-log/index.blade.php`, and drop the dead `global-master.activity-log.index` breadcrumb entry in `app/Services/Breadcrumbs/registry.php:1558`. The live screens are unaffected (Prime + TenantCore own every route). The shared `globalmaster::create` / `globalmaster::show` / `globalmaster::edit` placeholders are NOT touched. This makes ALC-01's D5 item moot.
  - (b) keep the file but apply ALC-01 only (self-documenting dead code, no deletion). The view and breadcrumb stay.
  - (c) leave everything as is and record it as accepted technical debt.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| ALC-04 | N+1 / null-safe `user` in `globalmaster::activity-log.index`. The view is only ever rendered by the dead `index()`; ALC-01 (D5-disable) or ALC-02(a) (delete) makes it unreachable. Fix it (`->with('user')` + `?->name`) only if the screen is revived. |
| ALC-05 | Wrong `@can` scope on the view's outer wrapper. Same reason as ALC-04 — no route renders the view; fix with the revival, or delete with ALC-02(a). |
| ALC-06 | The view's search box submits a filter `index()` never reads. Same reason as ALC-04 — the screen is dead; fix on revival, or delete with ALC-02(a). |
