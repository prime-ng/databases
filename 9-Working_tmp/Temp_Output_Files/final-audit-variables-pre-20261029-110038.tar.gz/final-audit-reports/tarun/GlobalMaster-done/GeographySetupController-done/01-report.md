# Final Audit — GlobalMaster / GeographySetupController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php` (148 lines, 8 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/global-master/location-setup` (the list — the only URL the menu links to). A second copy answers on `http://test.localhost:8000/prime/location-setup`. Also routed on the same controller: `/location-setup/create`, `/location-setup/{location_setup}` (show), `/location-setup/{location_setup}/edit`, and `/location-setup/search` (AJAX typeahead). |
| Menu path | Core Configuration → Location Mgmt (`central.global-master.location-setup.index`), seeded in `database/seeders/MenuSeeder_9_04_2026.php:131` with `permission = prime.global-master.country.viewAny`. |
| Who uses it | Super Admin, Dev Team, App Maintenance, School Admin, Support Team and CRM Team hold `prime.global-master.country.viewAny` (measured in `sys_role_has_permissions_jnt`). |
| What a user does here | Opens ONE screen with four tabs — Country / State / District / City — and reads the central geography reference data. Each tab has a typeahead search box. The screen is read-only: there is no working add/edit/delete path (see GEO-02). |
| Tables written | none — every method is read-only; the only write-shaped methods (`store`/`update`/`destroy`) are empty and unrouted. |
| Tables read | `glb_countries`, `glb_states`, `glb_districts`, `glb_cities` (central `global_master_mysql`). |
| Live data | `glb_countries` = 1, `glb_states` = 36, `glb_districts` = 785, `glb_cities` = 1592 (measured read-only on `global_master_mysql`). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No — this controller is not production-ready, because three of its five routed pages are guaranteed 500s. `create`, `show` and `edit` are registered by `Route::resource` and each returns `view('globalmaster::create' | 'show' | 'edit')`, but none of those three Blade files exists anywhere in the module (only `location-management/index.blade.php` was ever written), so every one of those URLs dies with `View [create] not found`. The single worst finding is **GEO-02**. The list screen itself does render and every routed method authorizes before it reads, but it is wasteful: the District tab iterates `$countries` and lazy-loads each country's states and each state's districts (an N+1 query trap, **GEO-05**), and the controller additionally runs three queries — a `$districts` paginator and two unbounded `Country::has('states')->…->get()` loads — whose results the Blade never reads (**GEO-06**). The rest is a mis-scoped search permission and small style debt. The fixes are small and mostly mechanical (largely S): stub the three dead pages, delete the dead queries, cap the search, and gate the search by tab. Rough effort: **S**.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 1 | 4 | 3 | 1 | 9 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | GEO-05, GEO-06, GEO-07, GEO-08 |
| F3 Authorization | GEO-01 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | GEO-02, GEO-03 | F12 Style | GEO-09 |
| F6 Controller shape | GEO-04 | F13 Deep read | clean |
| F7 Models | clean (usage only) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php` | controller | 148 | this report | ✅ |
| 2 | `Modules/GlobalMaster/resources/views/location-management/index.blade.php` | blade | 391 | this report (rendered only by this controller) | ✅ |
| 3 | `Modules/GlobalMaster/app/Models/Country.php` | model | 31 | ↗ [tarun/GlobalMaster-done/CountryController](../CountryController-done/01-report.md) | ↗ linked (usage checked) |
| 4 | `Modules/GlobalMaster/app/Models/State.php` | model | 41 | ↗ [tarun/GlobalMaster-done/StateController](../StateController-done/01-report.md) | ↗ linked (usage checked) |
| 5 | `Modules/GlobalMaster/app/Models/District.php` | model | 39 | ↗ [tarun/GlobalMaster-done/DistrictController](../DistrictController-done/01-report.md) | ↗ linked (usage checked) |
| 6 | `Modules/GlobalMaster/app/Models/City.php` | model | 43 | ↗ [tarun/GlobalMaster-done/CityController](../CityController-done/01-report.md) | ↗ linked (usage checked) |
| 7 | `App\Http\Controllers\Controller` | common base | — | common | ❌ common |
| 8 | `resources/views/components/backend/tab/search-bar.blade.php`, `resources/views/components/backend/tab/nav-tab.blade.php` | shared components | — | common | ❌ common (usage checked) |
| 9 | `app/Helpers/activityLog.php` → `Modules/Prime/Models/ActivityLog` | common helper/sink | — | common | ❌ common (not used — no writes) |

No pre-applied files. All four models are already owned by the Country/State/District/City reports; this report only checks **how** this controller uses them (§5 step 2). The Blade in row 2 is reached only by this controller, so per §5 it is owned here and is not registered in `00-CLASS-OWNERS.md`.

## 4. Routes

```
GET|HEAD global-master/location-setup                                 central.global-master.location-setup.index                   Modules\GlobalMaster\Http\Controllers\GeographySetupController@index
GET|HEAD global-master/location-setup/create                          central.global-master.location-setup.create                  Modules\GlobalMaster\Http\Controllers\GeographySetupController@create
GET|HEAD global-master/location-setup/search                          central.global-master.location-setup.search                  Modules\GlobalMaster\Http\Controllers\GeographySetupController@search
GET|HEAD global-master/location-setup/{location_setup}                central.global-master.location-setup.show                    Modules\GlobalMaster\Http\Controllers\GeographySetupController@show
GET|HEAD global-master/location-setup/{location_setup}/edit           central.global-master.location-setup.edit                    Modules\GlobalMaster\Http\Controllers\GeographySetupController@edit
GET|HEAD prime/location-setup                                         central.prime.location-setup.index                           Modules\GlobalMaster\Http\Controllers\GeographySetupController@index
GET|HEAD prime/location-setup/create                                  central.prime.location-setup.create                          Modules\GlobalMaster\Http\Controllers\GeographySetupController@create
GET|HEAD prime/location-setup/search                                  central.prime.location-setup.search                          Modules\GlobalMaster\Http\Controllers\GeographySetupController@search
GET|HEAD prime/location-setup/{location_setup}                        central.prime.location-setup.show                            Modules\GlobalMaster\Http\Controllers\GeographySetupController@show
GET|HEAD prime/location-setup/{location_setup}/edit                   central.prime.location-setup.edit                            Modules\GlobalMaster\Http\Controllers\GeographySetupController@edit
```

The ten routes come from two identical blocks (`Modules/GlobalMaster/routes/web.php:83-84` and `:193-194`), each inside `Route::domain(config('app.domain'))` and middleware `['auth', 'verified', '2fa']` — central-only, correctly.

Unrouted public methods: `store` (`:87`), `update` (`:114`), `destroy` (`:121`) — excluded by `Route::resource(...)->except(['store', 'update', 'destroy'])` and therefore unreachable; see **GEO-03**.

Route parameter note (checked, not a finding): the resource routes bind `{location_setup}` while the methods take `$id` (`show`/`edit`). There is no type-hinted model and the methods never read the value, so Laravel passes it positionally and no unbound model is ever created — no trap here.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 20 | GET global-master/location-setup (also prime/) | `Gate::any([prime.global-master.{country,state,district,city}.viewAny]) \|\| abort(403)` | none | none | none — reads glb_* | GEO-05, GEO-06, GEO-08 |
| `create` | 77 | GET …/location-setup/create | `prime.global-master.country.create` | none | none | none | GEO-02, GEO-04 |
| `store` | 87 | unrouted | none | none | none | none (empty body) | GEO-03 |
| `show` | 94 | GET …/location-setup/{location_setup} | `prime.global-master.country.view` | none | none | none | GEO-02, GEO-04 |
| `edit` | 104 | GET …/location-setup/{location_setup}/edit | `prime.global-master.country.update` | none | none | none | GEO-02, GEO-04 |
| `update` | 114 | unrouted | none | none | none | none (empty body) | GEO-03 |
| `destroy` | 121 | unrouted | none | none | none | none (empty body) | GEO-03 |
| `search` | 126 | GET …/location-setup/search (also prime/) | `prime.global-master.country.viewAny` (used for ALL tabs) | none | none | none — reads glb_* | GEO-01, GEO-07 |

## 6. Findings

### F1 — Errors

clean — `grep -nE '\btry\b|\bcatch\b|getMessage|withErrors|\breport\(|Log::' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php` → no output (D1: no `try/catch` anywhere; nothing sends exception text to a user).

### F2 — Transactions and audit

clean — `grep -nE 'DB::transaction|beginTransaction|activityLog|->create\(|->update\(|->save\(|->delete\(' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php` → no output (no write path exists, so no transaction/`activityLog` is required).

### F3 — Authorization

#### GEO-01 · M · AUTH-05 — the typeahead search is gated by ONE country permission for all four tabs

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — *no dead or mis-scoped permission logic; every endpoint enforces the permission the action actually performs.* Closest to AUTH-01 (every routed method authorizes) — the method does authorize, but with the wrong ability for three of its four tabs. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php:128`, method `search()` |
| **Root cause** | `search()` serves four tabs (country/state/district/city, chosen by `$request->tab`) but hard-codes `Gate::authorize('prime.global-master.country.viewAny')` for all of them. The country ability is therefore the only key checked. |
| **Consequence** | A user who holds only `prime.global-master.country.viewAny` (e.g. a limited role) can type into the City tab and receive every matching city name; conversely a user who holds only `state.viewAny` gets a 403 from the State tab's own search box. The gate does not match the data returned. |
| **Reproduce** | As a role with `country.viewAny` but not `city.viewAny`, open `/global-master/location-setup?tab=city` and type in the search box → suggestions return (no 403). Expected: 403. |
| **Fix approach** | Resolve the required ability from `$tab` and call `Gate::authorize($permission)`; all four ability names already exist in `config/permissionslist.php:213-216`, so no new key is minted. |
| **Plan item** | GEO-01 in `02-fix-plan.md` §4 |

```php
// GeographySetupController.php:128-131 — CURRENT
        Gate::authorize('prime.global-master.country.viewAny');

        $tab = $request->tab; // country/state/district/city
        $search = $request->search;
```

**Evidence**
```
$ grep -n "Gate::" Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php
22:        Gate::any([
27:        ]) || abort(403);
79:        Gate::authorize('prime.global-master.country.create');
96:        Gate::authorize('prime.global-master.country.view');
106:        Gate::authorize('prime.global-master.country.update');
128:        Gate::authorize('prime.global-master.country.viewAny');
$ grep -n "global-master.country'\|global-master.state'\|global-master.district'\|global-master.city'" config/permissionslist.php
213:        'global-master.country' => $crud,
214:        'global-master.state' => $crud,
215:        'global-master.district' => $crud,
216:        'global-master.city' => $crud,
```

### F4 — Validation and input

clean — `grep -nE 'validate\(|->all\(|->except\(|FormRequest' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php` → no output. The controller writes nothing, so there is no `$request->all()` on a model; `search()` uses `$request->tab` only as a `switch` selector and `$search` inside a bound `LIKE` binding.

### F5 — Routes

#### GEO-02 · B · RTE-02 — three routed pages return Blades that do not exist (guaranteed 500)

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *every route must resolve to a working action.* The method exists, but its only `return view(...)` names a Blade that was never written, so the route dies at dispatch — the same class of guaranteed 500 as `STAT-09` in the State report. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php:81` (`create`), `:98` (`show`), `:108` (`edit`) |
| **Root cause** | This is the `module:make` stub kept as-is: `create`/`show`/`edit` return `globalmaster::create`, `globalmaster::show`, `globalmaster::edit`. The module's view namespace resolves to `Modules/GlobalMaster/resources/views/`, which contains no `create.blade.php`, `show.blade.php` or `edit.blade.php` (only `index.blade.php` and per-resource subfolders such as `country/`, `state/`). `view()->exists()` returns `false` for all three. |
| **Consequence** | Any request to `/global-master/location-setup/create`, `/global-master/location-setup/1`, `/global-master/location-setup/1/edit` (and their `/prime/…` twins) throws `InvalidArgumentException: View [create] not found` and renders the 500 page. No menu or Blade links to them, so it is only hit by a direct URL — but the URLs are live and reachable. |
| **Reproduce** | `curl -I http://test.localhost:8000/global-master/location-setup/create` → HTTP 500 (view not found). |
| **Fix approach** | Decide how to stop them being 500s (see the DECISION in the plan): stub the three methods with `abort(403)` (controller-only), or drop `create`/`show`/`edit` from the two `Route::resource` registrations (route file, ⚠ SHARED), or write the three views (product work). |
| **Plan item** | GEO-02 in `02-fix-plan.md` §1 (DECISION) |

```php
// GeographySetupController.php:77-82 — CURRENT (identical shape at :94-99 and :104-109)
    public function create()
    {
        Gate::authorize('prime.global-master.country.create');

        return view('globalmaster::create');
    }
```

**Evidence**
```
$ php artisan tinker --execute 'foreach (["globalmaster::create","globalmaster::show","globalmaster::edit","globalmaster::location-management.index"] as $v) { echo str_pad($v, 42)." => ".(view()->exists($v) ? "EXISTS" : "MISSING")."\n"; }'
globalmaster::create                       => MISSING
globalmaster::show                         => MISSING
globalmaster::edit                         => MISSING
globalmaster::location-management.index    => EXISTS
$ ls Modules/GlobalMaster/resources/views/*.blade.php
Modules/GlobalMaster/resources/views/index.blade.php
```

#### GEO-03 · M · RTE-03 — three public methods are neither routed nor disabled; their bodies are empty

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`).* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php:87` (`store`), `:114` (`update`), `:121` (`destroy`) |
| **Root cause** | The resource registration excludes these three actions (`Modules/GlobalMaster/routes/web.php:84` and `:194` both use `->except(['store', 'update', 'destroy'])`), and each method body is empty. They are dead method stubs: no route reaches them, and if one were added it would silently do nothing and return no response. |
| **Consequence** | No user-visible effect today (unrouted). It is a maintenance trap: a future developer adding a route to `store` would get a method that returns an empty 200 and writes nothing, with no error. |
| **Reproduce** | Static only — `route:list` shows no POST/PUT/DELETE for `location-setup`; the bodies are empty at the cited lines. |
| **Fix approach** | Per protocol D5, replace each empty body with `abort(403, …)` and a `// NOT ROUTED` comment. Never delete the methods. |
| **Plan item** | GEO-03 in `02-fix-plan.md` §5 |

```php
// GeographySetupController.php:87-89 — CURRENT (update :114-116 and destroy :121-123 are identical empty bodies)
    public function store(Request $request)
    {
    }
```

**Evidence**
```
$ grep -nE 'public function [a-z]+' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php
87:    public function store(Request $request)
114:    public function update(Request $request, $id)
121:    public function destroy($id)
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); foreach($r as $x){ if(str_contains($x["action"]??"","GeographySetupController@")) printf("%-7s %s\n",$x["method"],$x["uri"]); }'
GET|HEAD global-master/location-setup
GET|HEAD global-master/location-setup/create
GET|HEAD global-master/location-setup/search
GET|HEAD global-master/location-setup/{location_setup}
GET|HEAD global-master/location-setup/{location_setup}/edit
GET|HEAD prime/location-setup
GET|HEAD prime/location-setup/create
GET|HEAD prime/location-setup/search
GET|HEAD prime/location-setup/{location_setup}
GET|HEAD prime/location-setup/{location_setup}/edit
```

### F6 — Controller shape

#### GEO-04 · L · CTL-04 — public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *declare return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`).* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php:20` (`index`), `:77` (`create`), `:94` (`show`), `:104` (`edit`), `:126` (`search`) |
| **Root cause** | Every method is declared without a return type. The scanner flagged all five routed methods (`CTL-04` rows for lines 32/89/106/116/138 in the scan). |
| **Consequence** | None at runtime; a reader of the controller cannot tell a page action from a JSON action without opening the body. |
| **Reproduce** | Static only — signatures at the cited lines. |
| **Fix approach** | Add `: View` to `index`/`create`/`show`/`edit` (with the `use Illuminate\View\View;` import) and a union to `search`. `store`/`update`/`destroy` are handled by GEO-03. |
| **Plan item** | GEO-04 in `02-fix-plan.md` §8 |

```php
// GeographySetupController.php:20-21 — CURRENT
    public function index(Request $request)
    {
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php
20:    public function index(Request $request)
77:    public function create()
87:    public function store(Request $request)
94:    public function show($id)
104:    public function edit($id)
114:    public function update(Request $request, $id)
121:    public function destroy($id)
126:    public function search(Request $request)
```

### F7 — Models

clean (usage only) — every relation this controller names resolves. `District::with('State')` (capital `S`, the only inconsistency) still works because PHP method names are case-insensitive; `with('country')`, `['states','states.districts']` and `['district','district.state','district.state.country']` all resolve. Proven:
```
$ php artisan tinker --execute 'use Modules\GlobalMaster\Models\District; use Modules\GlobalMaster\Models\Country; $d = District::with("State")->first(); echo "with(State) OK; relation keys: ".implode(",", array_keys($d->getRelations()))."\n"; $c = Country::has("states")->with(["states","states.districts"])->get(); echo "nested eager OK rows=".$c->count()."\n";'
with(State) OK; relation keys: State
nested eager OK rows=1
```
The models' own defects (missing `strict_types`, no relation return types, `Country` has no `is_active` cast) are owned by the Country/State/District/City reports — see §7.

### F8 — Services and jobs

clean — the controller injects no service, dispatches no job and defines no listener: `grep -nE 'Service|Job|Event|dispatch|new ' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php` → no output.

### F9 — Queries and performance

#### GEO-05 · H · QRY-01 — the District tab lazy-loads states and districts per row (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; eager-load with `with()`.* Also VIEW-02 (a relation used inside `@foreach` must be eager-loaded by the controller). |
| **Where** | `Modules/GlobalMaster/resources/views/location-management/index.blade.php:234` and `:250` (the District tab), fed by `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php:33` |
| **Root cause** | `index()` builds `$countries = Country::orderBy('is_active','desc')->paginate(10, …)` with no eager loads. The District tab iterates `@forelse($countries as $country)` and then `@foreach($country->states …)` and `@foreach($state->districts …)`. Because `states`/`districts` were not eager-loaded, Eloquent runs one query per country and one per state. |
| **Consequence** | Opening the District tab fires 1 (paginate) + 1 (count) + N-countries + N-states queries. With the live data (1 country / 36 states) that is ~38 queries for one page; it grows linearly with the geography table, which is the opposite of what a central reference-data screen should do. |
| **Reproduce** | Open `/global-master/location-setup?tab=district` with query logging; ~38 queries execute. Expected: 4 (page + count + states + districts). |
| **Fix approach** | Eager-load `states` and `states.districts` on the paginated country query (which both the Country and District tabs share). |
| **Plan item** | GEO-05 in `02-fix-plan.md` §6 |

```php
// location-management/index.blade.php:229-234 — CURRENT
                        @forelse($countries as $country)
                            <tr class="align-middle">
                                <td>{{ $country->name }}</td>

                                <td>
                                    @foreach($country->states as $state)
```

**Evidence**
```
$ grep -n "forelse(\$countries\|country->states\|state->districts" Modules/GlobalMaster/resources/views/location-management/index.blade.php
229:                        @forelse($countries as $country)
234:                                    @foreach($country->states as $state)
250:                                                            @foreach($state->districts as $district)
$ sed -n '33p' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php
        $countriesQuery = Country::orderBy('is_active', 'desc');
```

#### GEO-06 · M · QRY-15 — three heavy queries per page load are computed and never read

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *do not load rows a page does not use.* Also CTL-10 (dead code): the results are passed to a view that never references them. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php:51` (`$districts`), `:61-62` (two unbounded `Country::…->get()`), returned in `compact(...)` at `:64-71` |
| **Root cause** | Three values are built on every `index()` call but the Blade never reads them: `$districts` (a paginated `District::with('State')` query) and `$countriesWithStates` / `$countriesWithStatesAndDistricts` (two `Country::has('states')->with(...)->get()` full-table loads with nested eager loads). The District tab is rendered from `$countries`, not from any of these. Verified by grep over the Blade. |
| **Consequence** | Every load of the list screen runs an extra paginated `glb_districts` query and two unbounded country/state/district eager-load queries (today 1 + 36 + 785 rows) for data that is discarded — wasted DB work and memory on the busiest central screen, and dead code that misleads the next reader into thinking the District tab uses them. |
| **Reproduce** | Static only — `grep -n "countriesWithStates\|countriesWithStatesAndDistricts\|\$districts" Modules/GlobalMaster/resources/views/location-management/index.blade.php` → no output, while the controller builds all three. |
| **Fix approach** | Delete the three unused queries and drop `districts`, `countriesWithStates`, `countriesWithStatesAndDistricts` from the `compact(...)`. |
| **Plan item** | GEO-06 in `02-fix-plan.md` §6 |

```php
// GeographySetupController.php:61-62 — CURRENT
        $countriesWithStates = Country::has('states')->with('states')->get();
        $countriesWithStatesAndDistricts = Country::has('states')->with(['states', 'states.districts'])->get();
```

**Evidence**
```
$ grep -n "countriesWithStates\|countriesWithStatesAndDistricts\|\$districts" Modules/GlobalMaster/resources/views/location-management/index.blade.php
(no output)
$ sed -n '61,71p' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php
        $countriesWithStates = Country::has('states')->with('states')->get();
        $countriesWithStatesAndDistricts = Country::has('states')->with(['states', 'states.districts'])->get();

        return view('globalmaster::location-management.index', compact(
            'countries',
            'states',
            'countriesWithStates',
            'countriesWithStatesAndDistricts',
            'districts',
            'cities'
        ));
```

#### GEO-07 · M · QRY-02 — the typeahead returns an unbounded result set

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M) — *no unbounded `->get()` feeding a list* (QRY-08 for the leading-wildcard `LIKE` on the 1,592-row `glb_cities`). |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php:138-144`, method `search()` |
| **Root cause** | Each `case` runs `Model::where('name','like',"%$search%")->pluck('name')` with no `limit()`. A search for a common substring (`a`, `an`, `i`) returns every matching row of `glb_cities` (1,592) or `glb_districts` (785) as a JSON array, and the leading `%` prevents an index range scan. |
| **Consequence** | A one-character search in the City tab returns ~1,000+ names in one JSON payload to the browser typeahead, which only shows a handful — wasted bandwidth and DB I/O on every keystroke. |
| **Reproduce** | `curl "http://test.localhost:8000/global-master/location-setup/search?tab=city&search=a"` → a large array instead of a capped suggestion list. |
| **Fix approach** | Add `->limit(20)` to each `case` and a `default` that returns an empty JSON array for an unknown tab (today an unknown tab falls through and returns `null`). |
| **Plan item** | GEO-07 in `02-fix-plan.md` §6 |

```php
// GeographySetupController.php:136-145 — CURRENT
        switch ($tab) {
            case 'country':
                return Country::where('name', 'like', "%$search%")->pluck('name');
            case 'state':
                return State::where('name', 'like', "%$search%")->pluck('name');
            case 'district':
                return District::where('name', 'like', "%$search%")->pluck('name');
            case 'city':
                return City::where('name', 'like', "%$search%")->pluck('name');
        }
```

**Evidence**
```
$ grep -n "pluck('name')\|limit(" Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php
138:                return Country::where('name', 'like', "%$search%")->pluck('name');
140:                return State::where('name', 'like', "%$search%")->pluck('name');
142:                return District::where('name', 'like', "%$search%")->pluck('name');
144:                return City::where('name', 'like', "%$search%")->pluck('name');
$ php artisan tinker --execute '$c = DB::connection("global_master_mysql"); echo "cities=".$c->table("glb_cities")->count()." districts=".$c->table("glb_districts")->count()."\n";'
cities=1592 districts=785
```

#### GEO-08 · L · QRY-13 — paginator links drop the `tab` query string

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L) — *filtered paginators keep their filters (`->withQueryString()`).* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php:37`, `:44`, `:51`, `:58` |
| **Root cause** | Each paginator calls `->appends(['search' => $search])`, which re-appends only `search`. The `?tab=` parameter that selected the tab is not carried onto pages 2+. |
| **Consequence** | Clicking page 2 of a tab returns a URL without `tab=`, so server-side the search filter reverts to the country tab (and the Blade always marks the country pane active), making the other tabs' pagination look broken. |
| **Reproduce** | Open `/global-master/location-setup?tab=state`, click the paginator's page 2 → the URL has no `tab=state`. |
| **Fix approach** | Replace `->appends(['search' => $search])` with `->withQueryString()` on all four paginators so every query parameter is preserved. (The Blade also hard-codes `active show` on the country pane; that is out of scope for this mechanical fix — see §8.) |
| **Plan item** | GEO-08 in `02-fix-plan.md` §6 |

```php
// GeographySetupController.php:37 — CURRENT (same call on :44, :51, :58)
        $countries = $countriesQuery->paginate(10, ['*'], 'country_page')->appends(['search' => $search])->fragment('country');
```

**Evidence**
```
$ grep -n "appends(\['search'" Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php
37:        $countries = $countriesQuery->paginate(10, ['*'], 'country_page')->appends(['search' => $search])->fragment('country');
44:        $states = $statesQuery->paginate(10, ['*'], 'state_page')->appends(['search' => $search])->fragment('state');
51:        $districts = $districtsQuery->paginate(10, ['*'], 'district_page')->appends(['search' => $search])->fragment('district');
58:        $cities = $citiesQuery->paginate(10, ['*'], 'city_page')->appends(['search' => $search])->fragment('city');
```

### F10 — Views

clean — the Blade has no queries and no raw echo: `grep -nE '\{!!|Model::|DB::|->where\(|->get\(|->count\(|@php' Modules/GlobalMaster/resources/views/location-management/index.blade.php` → no output. (The relation lazy-loading inside the District tab is a controller eager-load gap, reported as GEO-05 under F9.)

### F11 — Security and tenancy

clean — `grep -nE 'env\(|Log::|\?\? 1|asset\(' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php` → no output. Routes are central-only (`Route::domain(config('app.domain'))`) and the models are the central `GlobalMaster` models, so no `tenancy()->central()` wrapper is needed; no personal data is exposed (geography reference names only).

### F12 — Style

#### GEO-09 · L · STY-01 — no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched).* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php:1` |
| **Root cause** | The file opens with `<?php` and a namespace but no `declare(strict_types=1);`. The scanner flagged it (`STY-01`). |
| **Consequence** | No runtime effect today; the file stays inconsistent with the project's typed convention and with the plan's other edits. |
| **Reproduce** | Static only — line 1 of the file. |
| **Fix approach** | Add `declare(strict_types=1);` as the line after `<?php` and before the namespace. |
| **Plan item** | GEO-09 in `02-fix-plan.md` §8 |

```php
// GeographySetupController.php:1-3 — CURRENT
<?php

namespace Modules\GlobalMaster\Http\Controllers;
```

**Evidence**
```
$ sed -n '1,3p' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php
<?php

namespace Modules\GlobalMaster\Http\Controllers;
$ grep -c "declare(strict_types=1)" Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php
0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There is **no mutating method** to answer for: the only write-shaped methods (`store`/`update`/`destroy`) are unrouted and have empty bodies, so questions 1-8 are not applicable. `grep -nE '->create\(|->update\(|->save\(|->delete\(|->insert\(|activityLog' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php` → no output. The two usage-level answers, even though F13 does not require them: (6) authorization hole — yes, `search()`'s wrong ability, reported as GEO-01; (8) dead feature — yes, the three unused variables and the three broken routed pages, reported as GEO-06/GEO-02.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/GlobalMaster/app/Models/Country.php` | scanner `MDL-02` — no cast for `is_active`; `STY-01` no `strict_types`; `MDL-04` relation no return type | MDL-02 / STY-01 / MDL-04 | tarun/GlobalMaster-done/CountryController report |
| `Modules/GlobalMaster/app/Models/State.php` | `STY-01` no `strict_types`; `MDL-04` relation no return type | STY-01 / MDL-04 | tarun/GlobalMaster-done/StateController report |
| `Modules/GlobalMaster/app/Models/District.php` | `STY-01` no `strict_types`; `MDL-04` relations no return type | STY-01 / MDL-04 | tarun/GlobalMaster-done/DistrictController report |
| `Modules/GlobalMaster/app/Models/City.php` | `STY-01` no `strict_types`; `MDL-04` relations no return type | STY-01 / MDL-04 | tarun/GlobalMaster-done/CityController report |
| `resources/views/components/backend/tab/{search-bar,nav-tab}.blade.php` | shared tab components used by this Blade | — | common — no defect found in this controller's use |
| `resources/views/location-management/index.blade.php` | hard-codes `active show` on the country tab pane (`:18`), so URL-driven `?tab=` never marks another pane active | VIEW / tab standard | this controller (not fixed here — see §8) |

## 8. Not covered, and why

- **Rendered output**: D4 forbids running tests or a browser session. The missing-view finding (GEO-02) is proven with `view()->exists()` and the route list, not by an HTTP request; the N+1 (GEO-05) is proven by reading the Blade and the controller, not by query counting.
- **`?tab=` visual activation**: The Blade's country pane is hard-coded `active show` (`:18`), so tab switching is JavaScript-driven in a component outside this controller's scope. The GEO-08 fix restores the `tab` query parameter but does not by itself re-activate a non-country pane — that is a Blade/component change and is left to the module UI pass.
- **The three missing views** (`create`/`show`/`edit`): not written, so their intended controls and validation cannot be audited. GEO-02 is a DECISION precisely because whether to write them is a product choice.
- **DDL / index coverage** on `glb_cities`/`glb_districts` (QRY-14) was not inspected; the tables are on the central `global_master_mysql` connection and their DDL is outside this controller's scope.
