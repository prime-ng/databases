# Fix Plan — GlobalMaster / GeographySetupController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/routes/web.php` | route file — edited ONLY if GEO-02 option (b) is chosen; otherwise out of bounds |
| `config/permissionslist.php` | shared permission config. Not needed — all four `…viewAny` abilities already exist at lines 213-216 |
| `resources/views/location-management/index.blade.php` | named in GEO-05's finding, but GEO-05 is fixed controller-side (eager-load); the Blade is NOT edited by this plan |
| `Modules/GlobalMaster/app/Models/Country.php`, `State.php`, `District.php`, `City.php` | owned by other reports (linked in §3 of the report) |
| `resources/views/components/backend/tab/search-bar.blade.php`, `nav-tab.blade.php` | shared components |

## 1. Blockers reachable today

- [x] **GEO-02** · B · DECISION · RTE-02 — `create`/`show`/`edit` are routed but return Blades that do not exist (`View [create] not found` → guaranteed 500). How should the three dead pages be closed?
  - **Why it is a decision:** the fix either stubs methods (controller only), removes routes (a ⚠ SHARED route-file change), or writes three missing views (product work) — a behaviour choice Tarun must make.
  - (a) ⭐ stub the three methods with `abort(403)` + a `// NOT ROUTED`-style comment. Controller only; routes/URLs unchanged; the 500 becomes a clean 403. No shared file touched.
  - (b) drop `create`, `show`, `edit` from both `Route::resource` registrations so the URLs 404. ⚠ SHARED — edits `Modules/GlobalMaster/routes/web.php:84` and `:194`.
  - (c) write the three missing views so the pages work. Product work; their controls/validation are unaudited.
  - ➜ Choice: (a) — Tarun, 2026-10-17

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — the controller has no `try/catch` and no write path.

## 4. Authorization (F3)

- [x] **GEO-01** · M · AUTH-05 · `GeographySetupController.php:128` — gate the search by the tab's own permission instead of `country.viewAny` for all four tabs.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Before** (`GeographySetupController.php:128-131`):
    ```php
        Gate::authorize('prime.global-master.country.viewAny');

        $tab = $request->tab; // country/state/district/city
        $search = $request->search;
    ```
  - **After:**
    ```php
        $tab = $request->tab; // country/state/district/city
        $search = $request->search;

        $permission = match ($tab) {
            'state' => 'prime.global-master.state.viewAny',
            'district' => 'prime.global-master.district.viewAny',
            'city' => 'prime.global-master.city.viewAny',
            default => 'prime.global-master.country.viewAny',
        };

        Gate::authorize($permission);
    ```
  - **Verify:** `grep -n "Gate::authorize('prime.global-master.country.viewAny');" Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Expect:** no output.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [x] **GEO-03** · M · RTE-03 · `GeographySetupController.php:87,114,121` — replace the empty bodies of the three unrouted methods with `abort(403)` and a `// NOT ROUTED` comment (protocol D5; never delete the methods).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Before** (`GeographySetupController.php:87-89`):
    ```php
        public function store(Request $request)
        {
        }
    ```
  - **After:**
    ```php
        public function store(Request $request)
        {
            // NOT ROUTED (GEO-03, 2026-10-12): the location-setup resource excludes store.
            abort(403, 'Not implemented.');
        }
    ```
  - **Before** (`GeographySetupController.php:114-116`):
    ```php
        public function update(Request $request, $id)
        {
        }
    ```
  - **After:**
    ```php
        public function update(Request $request, $id)
        {
            // NOT ROUTED (GEO-03, 2026-10-12): the location-setup resource excludes update.
            abort(403, 'Not implemented.');
        }
    ```
  - **Before** (`GeographySetupController.php:121-123`):
    ```php
        public function destroy($id)
        {
        }
    ```
  - **After:**
    ```php
        public function destroy($id)
        {
            // NOT ROUTED (GEO-03, 2026-10-12): the location-setup resource excludes destroy.
            abort(403, 'Not implemented.');
        }
    ```
  - **Verify:** `grep -n "abort(403, 'Not implemented.');" Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Expect:** three lines (store, update, destroy).
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **GEO-05** · H · QRY-01 · `GeographySetupController.php:33` — eager-load `states` and `states.districts` on the paginated country query so the District tab stops lazy-loading per row.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Before** (`GeographySetupController.php:33`):
    ```php
        $countriesQuery = Country::orderBy('is_active', 'desc');
    ```
  - **After:**
    ```php
        $countriesQuery = Country::with(['states', 'states.districts'])->orderBy('is_active', 'desc');
    ```
  - **Verify:** `grep -n "Country::with(\['states', 'states.districts'\])" Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Expect:** one line (`$countriesQuery = Country::with(['states', 'states.districts'])->orderBy('is_active', 'desc');`).
  - **Effort:** S

- [x] **GEO-06** · M · QRY-15 · `GeographySetupController.php:46-51,61-62,64-71` — delete the three queries whose results the view never reads (`$districts`, `$countriesWithStates`, `$countriesWithStatesAndDistricts`) and drop them from `compact(...)`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Before** (`GeographySetupController.php:46-51`):
    ```php
        // Districts
        $districtsQuery = District::with('State');
        if ($tab === 'district' && $search) {
            $districtsQuery->where('name', 'LIKE', "%{$search}%");
        }
        $districts = $districtsQuery->paginate(10, ['*'], 'district_page')->appends(['search' => $search])->fragment('district');
    ```
  - **After:**
    ```php
        // GEO-06 (2026-10-12): the District tab renders $countries (eager-loaded in GEO-05), so the $districts paginator was removed.
    ```
  - **Before** (`GeographySetupController.php:61-62`):
    ```php
        $countriesWithStates = Country::has('states')->with('states')->get();
        $countriesWithStatesAndDistricts = Country::has('states')->with(['states', 'states.districts'])->get();
    ```
  - **After:**
    ```php
        // GEO-06 (2026-10-12): $countriesWithStates / $countriesWithStatesAndDistricts were never read by the view — removed.
    ```
  - **Before** (`GeographySetupController.php:64-71`):
    ```php
        return view('globalmaster::location-management.index', compact(
            'countries',
            'states',
            'countriesWithStates',
            'countriesWithStatesAndDistricts',
            'districts',
            'cities'
        ));
    ```
  - **After:**
    ```php
        return view('globalmaster::location-management.index', compact(
            'countries',
            'states',
            'cities'
        ));
    ```
  - **Verify:** `grep -nE 'countriesWithStates|\$districts' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **GEO-07** · M · QRY-02 · `GeographySetupController.php:136-145` — cap the typeahead result set at 20 rows per tab and return an empty JSON array for an unknown tab.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Before** (`GeographySetupController.php:136-145`):
    ```php
        switch ($tab) {
            case 'country':
                return Country::where('name', 'like', "%$search%")->pluck('name');
            case 'state':
                return State::where('name', 'like', "%$search%")->pluck('name');
            case 'district':
                return District::where('name', 'like', "%$search%")->pluck('name');
            case 'city':
                return City::where('name', 'like', "%$search%")->pluck('name');
        }
    ```
  - **After:**
    ```php
        switch ($tab) {
            case 'country':
                return Country::where('name', 'like', "%$search%")->limit(20)->pluck('name');
            case 'state':
                return State::where('name', 'like', "%$search%")->limit(20)->pluck('name');
            case 'district':
                return District::where('name', 'like', "%$search%")->limit(20)->pluck('name');
            case 'city':
                return City::where('name', 'like', "%$search%")->limit(20)->pluck('name');
            default:
                return response()->json([]);
        }
    ```
  - **Verify:** `grep -n "limit(20)" Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Expect:** four lines (one per tab).
  - **Effort:** S

- [x] **GEO-08** · L · QRY-13 · `GeographySetupController.php:37,44,58` — preserve the `tab` query string on paginator links with `withQueryString()` (the `$districts` paginator is removed by GEO-06 and is intentionally not edited here).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Before** (`GeographySetupController.php:37`):
    ```php
        $countries = $countriesQuery->paginate(10, ['*'], 'country_page')->appends(['search' => $search])->fragment('country');
    ```
  - **After:**
    ```php
        $countries = $countriesQuery->paginate(10, ['*'], 'country_page')->withQueryString()->fragment('country');
    ```
  - **Before** (`GeographySetupController.php:44`):
    ```php
        $states = $statesQuery->paginate(10, ['*'], 'state_page')->appends(['search' => $search])->fragment('state');
    ```
  - **After:**
    ```php
        $states = $statesQuery->paginate(10, ['*'], 'state_page')->withQueryString()->fragment('state');
    ```
  - **Before** (`GeographySetupController.php:58`):
    ```php
        $cities = $citiesQuery->paginate(10, ['*'], 'city_page')->appends(['search' => $search])->fragment('city');
    ```
  - **After:**
    ```php
        $cities = $citiesQuery->paginate(10, ['*'], 'city_page')->withQueryString()->fragment('city');
    ```
  - **Verify:** `grep -n "appends(\['search'" Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

None — no `{!! !!}` and no queries in the Blade.

## 8. Style (F12) — one item per file

- [x] **GEO-04** · L · CTL-04 · `GeographySetupController.php:20,77,94,104,126` — add return types to the five routed methods and the imports they need.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Before** (`GeographySetupController.php:5-11`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\GlobalMaster\Models\Country;
    use Modules\GlobalMaster\Models\State;
    use Modules\GlobalMaster\Models\District;
    use Modules\GlobalMaster\Models\City;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Collection;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\GlobalMaster\Models\Country;
    use Modules\GlobalMaster\Models\State;
    use Modules\GlobalMaster\Models\District;
    use Modules\GlobalMaster\Models\City;
    ```
  - **Before** (`GeographySetupController.php:20`):
    ```php
        public function index(Request $request)
    ```
  - **After:**
    ```php
        public function index(Request $request): View
    ```
  - **Before** (`GeographySetupController.php:77`):
    ```php
        public function create()
    ```
  - **After:**
    ```php
        public function create(): View
    ```
  - **Before** (`GeographySetupController.php:94`):
    ```php
        public function show($id)
    ```
  - **After:**
    ```php
        public function show($id): View
    ```
  - **Before** (`GeographySetupController.php:104`):
    ```php
        public function edit($id)
    ```
  - **After:**
    ```php
        public function edit($id): View
    ```
  - **Before** (`GeographySetupController.php:126`):
    ```php
        public function search(Request $request)
    ```
  - **After:**
    ```php
        public function search(Request $request): JsonResponse|Collection
    ```
  - **Verify:** `grep -nE 'public function (index|create|show|edit|search)\(.*\): ' Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Expect:** five lines, each ending with `: View` or `: JsonResponse|Collection`.
  - **Effort:** S

- [x] **GEO-09** · L · STY-01 · `GeographySetupController.php:1` — add the strict-types declaration.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Before** (`GeographySetupController.php:1-3`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **Verify:** `grep -c "declare(strict_types=1)" Modules/GlobalMaster/app/Http/Controllers/GeographySetupController.php`
  - **Expect:** `1`.
  - **Effort:** S

## 9. Deferred / decisions

- GEO-02 is the only DECISION; it sits in §1 above so the fixer applies it in blocker order once a choice is written.

## 10. Findings with no plan item

None — every finding in `01-report.md` §6 has a plan item above.
