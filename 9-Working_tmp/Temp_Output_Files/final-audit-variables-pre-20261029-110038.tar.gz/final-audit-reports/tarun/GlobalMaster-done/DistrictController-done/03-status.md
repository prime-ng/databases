# Status — GlobalMaster / DistrictController

**Fixed:** 2026-10-17 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
| ID | What | Where |
|---|---|---|
| DIST-10 | Restore over GET → POST route. | commit `6d157fb2c` (restore family) |
| DIST-11 | Restore control → dual-mode `x-prime.table.action-trashed` (route-checked POST form). Tarun chose dual-mode over the plan's single POST form. | commit `6d157fb2c` |

## 2. Applied
| ID | File | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| DIST-01 (+02/03/04/05/06) | `DistrictController.php` | Six try/catch envelopes, the `ModelNotFoundException` rethrows and the `Log::error(getMessage())` lines removed (D1). Responses built after the transaction. `restore()` moved `findOrFail` outside the transaction. `toggleStatus` validates before the transaction and returns JSON on every branch (the parent-state guard returns before any write or log). store/update lost their duplicate `Gate::authorize` — `DistrictRequest::authorize()` checks the same permission first. Log payloads and event literals unchanged. | `grep -n "catch\|Log::"` | no output | 2026-10-17 |
| DIST-07 | `DistrictRequest.php` | `name` unique scoped to `state_id`, trashed rows ignored. | validator run with real request input | same name same state → `name` error; same name other state → pass; update own row → pass | 2026-10-17 |
| DIST-08 | `DistrictRequest.php` | `short_name` unique rule added (trashed ignored). | validator run | duplicate short name → `short_name` error | 2026-10-17 |
| DIST-09 | new migration `2026_10_17_120000_alter_glb_districts_soft_delete_aware_unique_keys.php` | DECISION (b). Adds `uq_glb_districts_stateId_name (state_id, name, deleted_at)`, `uq_glb_districts_shortName (short_name, deleted_at)`, `uq_glb_districts_globalCode (global_code)`, THEN drops `uq_district_state_name` and `glb_districts_short_name_unique` (order keeps a supporting index under the state_id FK). Measured first: 785 rows, 0 duplicate non-null `global_code`. **Written, NOT run.** | `php -l` | clean | 2026-10-17 |
| DIST-15 | `DistrictController.php` edit | Unused `Country::all()` removed. | `grep -n "Country::all"` | no output | 2026-10-17 |
| DIST-17 | `DistrictController.php` trashedDistrict | `->with(['state', 'state.country'])`. | rolled-back trash → eager check | both relations loaded | 2026-10-17 |
| DIST-18 | `district/create.blade.php` | Dead `$model->state_id` fallback removed. | `grep -n 'model->state_id'` | no output | 2026-10-17 |
| DIST-19 | `district/{create,edit,trash,index}.blade.php` | Commented-out card header and `<th>` lines removed. | `grep -n "{{-- <x-prime.card.header\|<!-- <th>"` | no output | 2026-10-17 |
| DIST-20 | `DistrictController.php` | `strict_types`, imports collapsed, return types on all 11 methods. | `php -l` + `class_exists` | clean / true | 2026-10-17 |
| DIST-21 | `DistrictRequest.php` | `strict_types`; `prepareForValidation(): void`. | head of file | present | 2026-10-17 |
| DIST-22 (+14) | `District.php` | `strict_types`, `BelongsTo`/`HasMany` imports and return types. | `get_class($m->state())`, `get_class($m->cities())` | BelongsTo / HasMany | 2026-10-17 |

## 3. Not applied
- DIST-12 (route binding for restore/forceDelete) and DIST-13 (codemod) — deferred in the plan (§10), not items.
- DIST-16 — accepted as informational.

## 4. Needs Tarun's hand
- **Run the migration:** `php artisan migrate --database=global_master_mysql --path=Modules/GlobalMaster/database/migrations/2026_10_17_120000_alter_glb_districts_soft_delete_aware_unique_keys.php` (or the module migrate you normally use for global_master). Until it runs, the DB keys still count trashed rows, so trash → re-create the same name/short name raises a 1062 that validation now lets through.
- Browser check: `/global-master/location-setup#district` — create, edit, toggle (incl. under an inactive state), trash → restore → force-delete.

## 5. Unverifiable by this workflow (D4)
- DIST-06 relies on `DistrictRequest::authorize()`; every check here ran as super admin, so a refusal is not exercised.

## 6. Verification log
```
vendor/bin/pint <4 files> --format agent           → fixed DistrictRequest.php, District.php (spacing only)
php -l <4 files>                                    → No syntax errors
class_exists(DistrictController|DistrictRequest|District) → true ×3
route:list --json (uncached) + method_exists        → routes=22 missing=0
render location-setup / create / trashed            → 200 · 3,554,743 / 131,499 / 114,568 bytes, 0 comment leaks
render edit / show (after DecryptUrl redirect)      → 200 · 131,600 / 115,888 bytes, district name present
rolled-back create → deactivate+delete → eager trash read → restore → trashed / eager loaded / restored; 0 rows after rollback
live keys before migration                          → uq_district_state_name(state_id,name), glb_districts_short_name_unique(short_name)
```

## 7. Final state
**FIXED** (code). Open: run the DIST-09 migration.

## 8. Follow-up 2026-10-17: the transactions did not cover the record (AFC-09)

Found while fixing AppConfigController. `District` saves through `global_master_mysql`, but every `DB::transaction()` in this controller opened on the default `mysql` connection, where only `activityLog()` writes. These are two separate PDO handles, so the 6 transactions covered only the log. A failure after the save rolled back the audit row and left the record changed.

**Applied:** all 6 calls now use `WritesGlobalMaster::inGlobalMasterTransaction()` (new trait, `Http/Controllers/Concerns/`), which opens a `global_master_mysql` transaction around the default one. Tarun approved fixing all six FIXED controllers together.

**Verified:** `php -l` clean · class loads · every routed method exists · host page renders 200 · a simulated failure through this controller's helper rolls back both the record and the log · negative control: plain `DB::transaction` left the global_master write in place.
