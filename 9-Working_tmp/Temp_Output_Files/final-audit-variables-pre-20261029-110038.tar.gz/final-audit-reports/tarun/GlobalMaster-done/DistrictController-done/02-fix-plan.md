# Fix Plan — GlobalMaster / DistrictController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/app/Models/State.php`, `Models/Country.php` | owned by the State/Country reports — usage-checked only, never edited |
| `Modules/GlobalMaster/routes/web.php` — any line OUTSIDE the two district blocks (75-79 and 185-189) | shared with 10 other controllers |
| `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` — any line outside the restore control (markup 1-10, JS 15-32) | ⚠ SHARED — only item DIST-11 may touch it |
| `config/permissionslist.php`, `config/flash.php`, `app/Helpers/*`, `app/Traits/*` | shared globals; nothing here needs changing |
| Existing migrations (`Modules/GlobalMaster/database/migrations/**`) | never edited. A NEW additive migration only if DECISION DIST-09 is ticked — and never run by the fixer |
| `app/View/Components/Backend/Form/SelectCountry.php` + its blade | shared component (cross-cutting note in report §7) |

Apply sequencing note: item DIST-01 (§3) rewrites the six mutating methods and collapses the imports. Items DIST-20 and DIST-22 quote current lines that DIST-01 also touches — the fixer re-measures each with grep before editing (final-audit.md §9.2 #3) and records "already applied" when the change landed via DIST-01.

## 1. Blockers reachable today

- [x] **DIST-10** · H · RTE-01 · `Modules/GlobalMaster/routes/web.php:77,187` — make restore a POST route (a GET must never mutate).
  - **Touches:** `Modules/GlobalMaster/routes/web.php` — ⚠ SHARED (route file; only the two district restore lines).
  - **Before** (`web.php:75-79` — the global-master group; the prime group at 185-189 is byte-identical):
    ```php
        Route::resource('district', DistrictController::class);
        Route::get('/district/trash/view', [DistrictController::class, 'trashedDistrict'])->name('district.trashed');
        Route::get('/district/{id}/restore', [DistrictController::class, 'restore'])->name('district.restore');
        Route::delete('/district/{id}/force-delete', [DistrictController::class, 'forceDelete'])->name('district.forceDelete');
        Route::post('/district/{district}/toggle-status', [DistrictController::class, 'toggleStatus'])->name('district.toggleStatus');
    ```
  - **After:** apply to BOTH the 75-79 block and the 185-189 block:
    ```php
        Route::resource('district', DistrictController::class);
        Route::get('/district/trash/view', [DistrictController::class, 'trashedDistrict'])->name('district.trashed');
        Route::post('/district/{id}/restore', [DistrictController::class, 'restore'])->name('district.restore');
        Route::delete('/district/{id}/force-delete', [DistrictController::class, 'forceDelete'])->name('district.forceDelete');
        Route::post('/district/{district}/toggle-status', [DistrictController::class, 'toggleStatus'])->name('district.toggleStatus');
    ```
  - **Verify:** `grep -n "district/{id}/restore" Modules/GlobalMaster/routes/web.php`
  - **Expect:** exactly two lines, both `Route::post('/district/{id}/restore'`; `grep -c "Route::get('/district/{id}/restore'"` returns 0. (The trash-screen link still GETs until DIST-11 is applied — apply DIST-11 next so the screen keeps working.)
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

- [x] **DIST-11** · M · RTE-01 · `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php:1-32` — turn the restore link into a POST form (mirrors the force-delete button in the same file).
  - **Touches:** `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` — ⚠ SHARED (used by every geography trash screen). Apply only after DIST-10.
  - **Before** (`action-trashed.blade.php:1-10` — current markup, restore anchor inside the force-delete form):
    ```blade
    <form action="{{ route($url . '.forceDelete', $id) }}" method="POST" class="d-inline confirm-action-form-force-delete">
        @csrf
        @method('DELETE')
        <div class="btn-group" role="group" aria-label="Actions">
            <a href="{{ route($url . '.restore', $id) }}" class="btn btn-outline-warning btn-sm confirm-action-restore">
                <i class="fa-solid fa-recycle"></i>
            </a>
            <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fa-solid fa-eraser"></i></button>
        </div>
    </form>
    ```
  - **After:** split the restore anchor into its own POST form:
    ```blade
    <form action="{{ route($url . '.restore', $id) }}" method="POST" class="d-inline confirm-action-form-restore">
        @csrf
        <button type="submit" class="btn btn-outline-warning btn-sm"><i class="fa-solid fa-recycle"></i></button>
    </form>
    <form action="{{ route($url . '.forceDelete', $id) }}" method="POST" class="d-inline confirm-action-form-force-delete">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fa-solid fa-eraser"></i></button>
    </form>
    ```
  - **Before** (`action-trashed.blade.php:15-32` — current restore JS navigates the window):
    ```js
        document.querySelectorAll('a.confirm-action-restore').forEach(function (link) {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Sure to restore?',
                    text: "Do you want to proceed to restore?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, proceed!'
                }).then(function (result) {
                    if (result.isConfirmed) {
                        window.location.href = link.getAttribute('href');
                    }
                });
            });
        });
    ```
  - **After:** submit the form like the force-delete block does:
    ```js
        document.querySelectorAll('form.confirm-action-form-restore').forEach(function (form) {
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Sure to restore?',
                    text: "Do you want to proceed to restore?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, proceed!'
                }).then(function (result) {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        });
    ```
  - **Verify:** `grep -c "confirm-action-form-restore" Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php`
  - **Expect:** 3 (the form class, the JS selector, and the closing tag); `grep -c "window.location.href = link"` returns 0.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [x] **DIST-01** · H · ERR-00 (D1) · `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php` — remove the try/catch envelope from all six mutating methods; run the write in `DB::transaction`, log via the activity helper, and build the response AFTER the transaction. This one item also lands DIST-02 (validation outside the try in toggleStatus), DIST-03 (the getMessage log lines disappear), DIST-04 (no HTML failure branch for the AJAX toggle), DIST-05 (responses built after the closure), and DIST-06 (the redundant `Gate::authorize` in store/update is dropped because `DistrictRequest::authorize()` already checks).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php`
  - **Before** — imports (`DistrictController.php:1-16`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;

    use Illuminate\Database\Eloquent\ModelNotFoundException;

    use Illuminate\Support\Facades\Log;

    use Illuminate\Support\Facades\DB;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\GlobalMaster\Http\Requests\DistrictRequest;
    use Modules\GlobalMaster\Models\Country;
    use Modules\GlobalMaster\Models\District;
    ```
  - **After:** imports (ModelNotFoundException and Log become unused once every catch is gone; `Country` stays — `index()` still uses it):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\GlobalMaster\Http\Requests\DistrictRequest;
    use Modules\GlobalMaster\Models\Country;
    use Modules\GlobalMaster\Models\District;
    ```
  - **Before** — store (`DistrictController.php:46-78`):
    ```php
        public function store(DistrictRequest $request)
        {
            Gate::authorize('prime.global-master.district.create');
            // Only use validated data (important)

            try {
                return DB::transaction(function () use ($request) {
                    $validatedData = $request->validated();

                    // Create the district
                    $district = District::create($validatedData);

                    // Activity Log
                    activityLog($district, 'Stored', [
                        'message' => 'A new district was created.',
                        'other' => 'some other information'
                    ]);

                    return redirect()
                        ->to(route('central.global-master.location-setup.index').'#district')
                        ->with('success', flash('created.district'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('DistrictController::store failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** store:
    ```php
        public function store(DistrictRequest $request)
        {
            $district = DB::transaction(function () use ($request) {
                $district = District::create($request->validated());

                activityLog($district, 'Stored', [
                    'message' => 'A new district was created.',
                    'other' => 'some other information',
                ]);

                return $district;
            });

            return redirect()
                ->to(route('central.global-master.location-setup.index').'#district')
                ->with('success', flash('created.district'));
        }
    ```
  - **Before** — update (`DistrictController.php:106-136`):
    ```php
        public function update(DistrictRequest $request, District $district)
        {
            Gate::authorize('prime.global-master.district.update');

            try {
                return DB::transaction(function () use ($request, $district) {
                    $validatedData = $request->validated();

                    $district->update($validatedData);

                    // Activity Log
                    activityLog($district, 'Updated', [
                        'message' => 'District details updated successfully.',
                        'other' => 'some other information'
                    ]);

                    return redirect()
                        ->to(route('central.global-master.location-setup.index').'#district')
                        ->with('success', flash('updated.district'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('DistrictController::update failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** update:
    ```php
        public function update(DistrictRequest $request, District $district)
        {
            DB::transaction(function () use ($request, $district) {
                $district->update($request->validated());

                activityLog($district, 'Updated', [
                    'message' => 'District details updated successfully.',
                    'other' => 'some other information',
                ]);
            });

            return redirect()
                ->to(route('central.global-master.location-setup.index').'#district')
                ->with('success', flash('updated.district'));
        }
    ```
  - **Before** — destroy (`DistrictController.php:141-169`):
    ```php
        public function destroy(District $district)
        {
            Gate::authorize('prime.global-master.district.delete');

            try {
                return DB::transaction(function () use ($district) {
                    $district->update(['is_active' => false]);
                    $district->delete();

                    activityLog($district, 'Trashed', [
                        'message' => 'District was deactivated and deleted.',
                        'other' => 'some other information'
                    ]);

                    return redirect()
                        ->to(route('central.global-master.location-setup.index').'#district')
                        ->with('success', flash('trashed.district'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('DistrictController::destroy failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** destroy:
    ```php
        public function destroy(District $district)
        {
            Gate::authorize('prime.global-master.district.delete');

            DB::transaction(function () use ($district) {
                $district->update(['is_active' => false]);
                $district->delete();

                activityLog($district, 'Trashed', [
                    'message' => 'District was deactivated and deleted.',
                    'other' => 'some other information',
                ]);
            });

            return redirect()
                ->to(route('central.global-master.location-setup.index').'#district')
                ->with('success', flash('trashed.district'));
        }
    ```
  - **Before** — restore (`DistrictController.php:185-213`):
    ```php
        public function restore($id)
        {
            Gate::authorize('prime.global-master.district.restore');

            try {
                return DB::transaction(function () use ($id) {
                    $district = District::withTrashed()->findOrFail($id);
                    $district->restore();

                    activityLog($district, 'Restored', [
                        'message' => 'District was restored.',
                        'other' => 'some other information'
                    ]);

                    return redirect()
                        ->route('central.global-master.district.trashed')
                        ->with('success', flash('restored.district'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('DistrictController::restore failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** restore:
    ```php
        public function restore($id)
        {
            Gate::authorize('prime.global-master.district.restore');

            DB::transaction(function () use ($id) {
                $district = District::withTrashed()->findOrFail($id);
                $district->restore();

                activityLog($district, 'Restored', [
                    'message' => 'District was restored.',
                    'other' => 'some other information',
                ]);
            });

            return redirect()
                ->route('central.global-master.district.trashed')
                ->with('success', flash('restored.district'));
        }
    ```
  - **Before** — forceDelete (`DistrictController.php:225-251`):
    ```php
        public function forceDelete($id)
        {
            Gate::authorize('prime.global-master.district.forceDelete');

            $district = District::withTrashed()->findOrFail($id);

            try {
                return DB::transaction(function () use ($district) {
                    $district->forceDelete();

                    activityLog($district, 'Deleted', ['message' => 'District was permanently deleted.']);

                    return redirect()
                        ->route('central.global-master.district.trashed')
                        ->with('success', flash('force_deleted.district'));
                });
            } catch (\Throwable $e) {
                Log::error('DistrictController::forceDelete failed', [
                    'id'    => $id,
                    'error' => $e->getMessage(),
                ]);

                return redirect()
                    ->route('central.global-master.district.trashed')
                    ->with('error', flash('operation_failed.district'));
            }
        }
    ```
  - **After:** forceDelete (`findOrFail` stays OUTSIDE the transaction — a missing trashed district must 404 natively):
    ```php
        public function forceDelete($id)
        {
            Gate::authorize('prime.global-master.district.forceDelete');

            $district = District::withTrashed()->findOrFail($id);

            DB::transaction(function () use ($district) {
                $district->forceDelete();

                activityLog($district, 'Deleted', ['message' => 'District was permanently deleted.']);
            });

            return redirect()
                ->route('central.global-master.district.trashed')
                ->with('success', flash('force_deleted.district'));
        }
    ```
  - **Before** — toggleStatus (`DistrictController.php:256-301`):
    ```php
        public function toggleStatus(Request $request, District $district)
        {
            Gate::authorize('prime.global-master.district.update');

            try {
                return DB::transaction(function () use ($request, $district) {
                    $request->validate([
                        'is_active' => 'required|boolean',
                    ]);

                    $newStatus = $request->input('is_active');
                    $stateIsActive = $district->state->is_active ?? false;

                    if (!$stateIsActive && $newStatus) {
                        return response()->json([
                            'success' => false,
                            'is_active' => $district->is_active,
                            'message' => flash('status_switch_failed.district')
                        ]);
                    }


                    $district->is_active = $newStatus;
                    $district->save();

                    //begin::Activity Log
                    activityLog($district, 'Toggled', ['message' => 'A new district status was updated.', 'other' => 'some other information']);
                    //end::Activity Log

                    return response()->json([
                        'success' => true,
                        'is_active' => $district->is_active,
                        'message' => flash('status_updated.district')
                    ]);

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('DistrictController::toggleStatus failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** toggleStatus (validation moves OUTSIDE the transaction so a 422 is a JSON 422 via the central renderer; the parent-state guard returns before any write):
    ```php
        public function toggleStatus(Request $request, District $district)
        {
            Gate::authorize('prime.global-master.district.update');

            $validated = $request->validate([
                'is_active' => 'required|boolean',
            ]);

            $newStatus = (bool) $validated['is_active'];
            $stateIsActive = $district->state->is_active ?? false;

            if (!$stateIsActive && $newStatus) {
                return response()->json([
                    'success' => false,
                    'is_active' => $district->is_active,
                    'message' => flash('status_switch_failed.district'),
                ]);
            }

            DB::transaction(function () use ($district, $newStatus) {
                $district->is_active = $newStatus;
                $district->save();

                activityLog($district, 'Toggled', ['message' => 'A new district status was updated.', 'other' => 'some other information']);
            });

            return response()->json([
                'success' => true,
                'is_active' => $district->is_active,
                'message' => flash('status_updated.district'),
            ]);
        }
    ```
  - **Verify:** `grep -c "try {" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php` AND `grep -c "getMessage" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php` AND `grep -c "ModelNotFoundException" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php`
  - **Expect:** 0 from all three greps; then `php -l Modules/GlobalMaster/app/Http/Controllers/DistrictController.php` prints "No syntax errors detected".
  - **Effort:** M

## 4. Authorization (F3)

No separate item — **DIST-06** (the duplicated permission check on store/update) is applied by DIST-01: the rewritten `store()` and `update()` drop the redundant `Gate::authorize` line because `DistrictRequest::authorize()` (via `authorizeByCrudPermission`) already rejects un-permitted users before the controller runs. All other methods keep their `Gate::authorize` (the FormRequest is not used on them).

## 5. Validation, routes, models (F4/F5/F7)

- [x] **DIST-07** · H · VAL-04 · `Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php:21-26` — scope the `name` unique rule to the submitted `state_id` so the same name is allowed in another state, and exclude soft-deleted rows.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php`
  - **Before** (`DistrictRequest.php:21-26`):
    ```php
                'name' => [
                    'required',
                    'string',
                    'max:50',
                    Rule::unique('glb_districts')->ignore($districtId),
                ],
    ```
  - **After:**
    ```php
                'name' => [
                    'required',
                    'string',
                    'max:50',
                    Rule::unique('glb_districts')
                        ->where('state_id', $this->input('state_id'))
                        ->ignore($districtId)
                        ->whereNull('deleted_at'),
                ],
    ```
  - **Verify:** `grep -n "where('state_id'" Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php`
  - **Expect:** exactly 1 line.
  - **Effort:** S

- [x] **DIST-08** · H · VAL-04 · `Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php:27` — add the missing `short_name` unique rule so a duplicate short name is rejected with a field message, not a DB error.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php`
  - **Before** (`DistrictRequest.php:27`):
    ```php
                'short_name' => ['required', 'string', 'max:10'],
    ```
  - **After:**
    ```php
                'short_name' => [
                    'required',
                    'string',
                    'max:10',
                    Rule::unique('glb_districts')->ignore($districtId)->whereNull('deleted_at'),
                ],
    ```
  - **Verify:** `grep -c "Rule::unique('glb_districts')" Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php`
  - **Expect:** 2.
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **DIST-15** · M · QRY-02/CTL-10 · `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:93-100` — delete the unused `Country::all()` query from `edit()` (no blade reads `$countries`).
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php`
  - **Before** (`DistrictController.php:93-100`):
    ```php
        public function edit(District $district)
        {
            Gate::authorize('prime.global-master.district.update');
            // Fetch countries for select dropdown
            $countries = Country::all();

            // return both district + countries
            return view('globalmaster::district.edit', compact('district', 'countries'));
    ```
  - **After:**
    ```php
        public function edit(District $district)
        {
            Gate::authorize('prime.global-master.district.update');

            return view('globalmaster::district.edit', compact('district'));
    ```
  - **Verify:** `grep -n "Country::all" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **DIST-17** · H · QRY-01/VIEW-02 · `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:178` — eager-load the chain the trash blade prints, so the list does not lazy-load two relations per row.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php`
  - **Before** (`DistrictController.php:178`):
    ```php
            $districts = District::onlyTrashed()->paginate(10);
    ```
  - **After:**
    ```php
            $districts = District::onlyTrashed()->with(['state', 'state.country'])->paginate(10);
    ```
  - **Verify:** `grep -n "onlyTrashed" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php`
  - **Expect:** 1 line containing `with(['state', 'state.country'])`.
  - **Effort:** S

## 7. Views (F10)

- [x] **DIST-18** · L · CTL-05/STY-04 · `Modules/GlobalMaster/resources/views/district/create.blade.php:32` — drop the dead `$model` fallback (the create view has no model).
  - **Touches:** `Modules/GlobalMaster/resources/views/district/create.blade.php`
  - **Before** (`create.blade.php:32`):
    ```blade
                                        <x-backend.form.select-state :stateId="old('state_id', $model->state_id ?? null)" />
    ```
  - **After:**
    ```blade
                                        <x-backend.form.select-state :stateId="old('state_id')" />
    ```
  - **Verify:** `grep -n 'model->state_id' Modules/GlobalMaster/resources/views/district/create.blade.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **DIST-19** · L · STY-04 · `Modules/GlobalMaster/resources/views/district/{create,edit,trash,index}.blade.php` — delete the commented-out component and table-header lines.
  - **Touches:** `Modules/GlobalMaster/resources/views/district/create.blade.php`, `Modules/GlobalMaster/resources/views/district/edit.blade.php`, `Modules/GlobalMaster/resources/views/district/trash.blade.php`, `Modules/GlobalMaster/resources/views/district/index.blade.php`
  - **Before** (`create.blade.php:9-11`; the same block exists at `edit.blade.php:9-11` and `trash.blade.php:9-11`):
    ```blade
                    <div class="card mb-4">
                        {{-- <x-prime.card.header title="Districts" url="central.global-master.district" /> --}}
                        <!-- /.card-header -->
    ```
  - **After** (delete the middle line in all three files):
    ```blade
                    <div class="card mb-4">
                        <!-- /.card-header -->
    ```
  - **Before** (`index.blade.php:16-18`):
    ```blade
                                        <th style="width:20%">Country</th>
                                        <!-- <th>States & Districts</th> -->
                                        <th>
    ```
  - **After:**
    ```blade
                                        <th style="width:20%">Country</th>
                                        <th>
    ```
  - **Verify:** `grep -n "{{-- <x-prime.card.header\|<!-- <th>" Modules/GlobalMaster/resources/views/district/*.blade.php`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [x] **DIST-20** · L · STY-01/STY-02 · `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php` — add `declare(strict_types=1);` and let Pint collapse the blank lines between imports.
  - **Touches:** `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php`
  - **Before** (`DistrictController.php:1-3`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Controllers;
    ```
  - **Verify:** `grep -n "declare(strict_types=1);" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php`
  - **Expect:** line 2. Then `vendor/bin/pint Modules/GlobalMaster/app/Http/Controllers/DistrictController.php --format agent` and re-run `php -l`. (If DIST-01 was ticked, the import collapse it performed must be kept.)
  - **Effort:** S

- [x] **DIST-21** · L · STY-01 · `Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php` — add `declare(strict_types=1);`.
  - **Touches:** `Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php`
  - **Before** (`DistrictRequest.php:1-3`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Http\Requests;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Http\Requests;
    ```
  - **Verify:** `grep -n "declare(strict_types=1);" Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php`
  - **Expect:** line 2.
  - **Effort:** S

- [x] **DIST-22** · L · STY-01/MDL-04 · `Modules/GlobalMaster/app/Models/District.php` — add `declare(strict_types=1);`, import the relation classes, and type both relations (this also lands DIST-14).
  - **Touches:** `Modules/GlobalMaster/app/Models/District.php`
  - **Before** (`District.php:1-6`):
    ```php
    <?php

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\GlobalMaster\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Before** (`District.php:27-35`):
    ```php
        public function state()
        {
            return $this->belongsTo(State::class);
        }

        public function cities()
        {
            return $this->hasMany(City::class);
        }
    ```
  - **After:**
    ```php
        public function state(): BelongsTo
        {
            return $this->belongsTo(State::class);
        }

        public function cities(): HasMany
        {
            return $this->hasMany(City::class);
        }
    ```
  - **Verify:** `grep -n "declare(strict_types=1);\|public function state():\|public function cities():" Modules/GlobalMaster/app/Models/District.php`
  - **Expect:** 3 lines.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **DIST-09** · M · DECISION · VAL-04/MDL-07/DDL-wins — make the district unique keys soft-delete-aware and add the missing `global_code` key?
  - **Why it is a decision:** a new additive migration (the fixer never runs migrations — that is Tarun's hand), plus a product choice about soft-delete semantics.
  - (a) ⭐ keep the two indexes as they are and add the DDL's `global_code` key in a NEW additive migration (`UNIQUE KEY uq_glb_districts_globalCode (global_code)`): this makes `global_code` unique as the DDL intends, and leaves the trash-then-recreate block in place — a trashed district must be force-deleted before its name/short name can be re-used.
  - (b) change both existing keys to include `deleted_at` (for example `UNIQUE KEY uq_district_state_name (state_id, name, deleted_at)` and `UNIQUE KEY glb_districts_short_name_unique (short_name, deleted_at)`) and add the `global_code` key: MySQL treats NULL as distinct, so a trashed row and a live row may share a name — this matches the DIST-07/DIST-08 `whereNull('deleted_at')` intent.
  - (c) no migration now — keep validation-only uniqueness (the live state today) and revisit when a real duplicate or a blocked re-create appears.
  - ➜ Choice: **(b)** — Tarun 2026-10-17. Migration written (`2026_10_17_120000_alter_glb_districts_soft_delete_aware_unique_keys.php`), NOT run.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| DIST-02 | Applied by DIST-01 — `toggleStatus` validation moves outside the transaction and every catch is removed, so a 422 is a JSON 422 from the central renderer, not an HTML redirect. |
| DIST-03 | Applied by DIST-01 — the six `Log::error(..., ['error' => $e->getMessage()])` lines live inside the removed catches and disappear. |
| DIST-04 | Applied by DIST-01 — the rewritten `toggleStatus` has no `back()` failure branch; every response is JSON. |
| DIST-05 | Applied by DIST-01 — every new method returns the model from the closure and builds the redirect/JSON after it. |
| DIST-06 | Applied by DIST-01 — the rewritten `store()`/`update()` drop the redundant `Gate::authorize`; `DistrictRequest::authorize()` checks the same permission first. |
| DIST-12 | Deferred (D3) — converting `restore`/`forceDelete` to route model binding needs the route parameter renamed to `{district}` plus `->withTrashed()` on the route definitions, which is a ⚠ SHARED route-file change; the current `$id` + `findOrFail` still returns a correct 404. |
| DIST-13 | L · deferred — return types on the 11 public methods are added opportunistically with DIST-01, DIST-12 and DIST-20; a full codemod belongs to the cleanup pass. |
| DIST-14 | Applied by DIST-22 — `state()` and `cities()` gain `: BelongsTo` and `: HasMany` return types in the same model edit. |
| DIST-16 | Accepted, informational — `index()` renders the full country/state/district tree on purpose and the live master data is small (1 country, 36 states, 785 districts); revisit with pagination or lazy loading only if the dataset grows. |
