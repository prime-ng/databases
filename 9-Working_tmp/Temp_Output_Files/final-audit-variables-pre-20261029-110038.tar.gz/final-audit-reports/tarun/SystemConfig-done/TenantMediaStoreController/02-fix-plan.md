# Fix Plan — SystemConfig / TenantMediaStoreController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SystemConfig/resources/views/media-store/partials/_media-store.blade.php` | shared blade (also rendered by School Config Tab 3); the view is clean — no view fix in this plan |
| `Modules/SystemConfig/resources/views/media-store/index.blade.php` | the view is clean — no view fix in this plan |
| `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php` | owned by `tarun/SystemConfig-done/SchoolConfigController`; its own SCFG-02 item normalises its call site |
| `routes/tenant.php` | route file — no route change in this plan |
| `config/permissionslist.php` | shared config — both permission keys already exist, so no permission change is needed |
| `Modules/Prime/app/Models/Media.php` | the pinned central model; PROD-04 is deferred product-wide and is out of scope |
| `resources/views/components/**` | shared backend components — not edited by this plan |
| `database/migrations/**` | never edited by this workflow |

## 1. Blockers reachable today

None.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — the controller has no write path and no error handling.

## 4. Authorization (F3)

None — both `Gate::authorize` calls are correct, run before any load, and both permission keys exist in the tenant config and `sys_permissions`.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **TMS-01** · M · VAL-05 · `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:63-70` — normalise the three query-string values to string-or-null before they reach the typed `?string` parameters, so `?search[]=x` no longer 500s the page.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php`
  - **Before** (`TenantMediaStoreController.php:63-70`):
    ```php
        return view(
            'systemconfig::media-store.index',
            self::listPayload(
                $request->input('search'),
                $request->input('disk'),
                $request->input('type'),
            )
        );
    ```
  - **After:**
    ```php
        $search = $request->input('search');
        $disk = $request->input('disk');
        $type = $request->input('type');

        $search = is_string($search) ? $search : null;
        $disk = is_string($disk) ? $disk : null;
        $type = is_string($type) ? $type : null;

        return view(
            'systemconfig::media-store.index',
            self::listPayload($search, $disk, $type)
        );
    ```
  - **Verify:** `grep -n 'is_string' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php`
  - **Expect:** three lines, one each for `$search`, `$disk` and `$type`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **TMS-05** · M · QRY-12 · `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:102-107` — merge the three scalar stat aggregates into one query and derive `$disks` from `$diskBreakdown`, so the page scans `sys_media` twice for its tiles instead of five times.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php`
  - **Before** (`TenantMediaStoreController.php:102-107`):
    ```php
        $totalCount = TenantMedia::count();
        $totalSizeBytes = TenantMedia::sum('size');
        $collectionCount = TenantMedia::distinct('collection_name')->count('collection_name');
        $diskBreakdown = TenantMedia::selectRaw('disk, COUNT(*) as cnt, SUM(size) as total_size')
            ->groupBy('disk')->get();
        $disks = TenantMedia::distinct('disk')->pluck('disk');
    ```
  - **After:**
    ```php
        $totals = TenantMedia::selectRaw('COUNT(*) as cnt, SUM(size) as total_size, COUNT(DISTINCT collection_name) as collection_count')
            ->toBase()
            ->first();
        $totalCount = (int) $totals->cnt;
        $totalSizeBytes = (int) $totals->total_size;
        $collectionCount = (int) $totals->collection_count;
        $diskBreakdown = TenantMedia::selectRaw('disk, COUNT(*) as cnt, SUM(size) as total_size')
            ->groupBy('disk')->get();
        $disks = $diskBreakdown->pluck('disk');
    ```
  - **Verify:** `grep -nE 'toBase|distinct\(' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php`
  - **Expect:** one line containing `toBase` and NO line containing `distinct(`.
  - **Effort:** S

- [ ] **TMS-06** · L · QRY-02 · `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:74` — change the file-list page size from 25 to the estate standard of 10.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php`
  - **Before** (`TenantMediaStoreController.php:74`):
    ```php
        private const PER_PAGE = 25;
    ```
  - **After:**
    ```php
        private const PER_PAGE = 10;
    ```
  - **Verify:** `grep -n 'PER_PAGE = ' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php`
  - **Expect:** `74:    private const PER_PAGE = 10;`.
  - **Effort:** S

## 7. Views (F10)

None — the index blade only includes the partial, and the partial's one `{!! !!}` (line 242) interpolates only integers and a fixed colour, so it is safe. No view is edited by this plan.

## 8. Style (F12) — one item per file

- [ ] **TMS-03** · L · CTL-04 · `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:7-11,56,154` — give the two routed methods their return types (`: View`, `: JsonResponse`) with the matching imports.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php`
  - **Before** (`TenantMediaStoreController.php:7-11`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Storage;
    use Modules\Prime\Models\TenantMedia;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Contracts\View\View;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Storage;
    use Modules\Prime\Models\TenantMedia;
    ```
  - **Before 2** (`TenantMediaStoreController.php:56`):
    ```php
        public function index(Request $request)
    ```
  - **After 2:**
    ```php
        public function index(Request $request): View
    ```
  - **Before 3** (`TenantMediaStoreController.php:154`):
    ```php
        public function checkFile(int $id)
    ```
  - **After 3:**
    ```php
        public function checkFile(int $id): JsonResponse
    ```
  - **Verify:** `grep -nE 'index\(Request \$request\): View|checkFile\(int \$id\): JsonResponse' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php`
  - **Expect:** two lines — `56:    public function index(Request $request): View` and `154:    public function checkFile(int $id): JsonResponse`.
  - **Effort:** S

- [ ] **TMS-08** · L · STY-04 · `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:17,38,95` and `Modules/Prime/app/Models/TenantMedia.php:34,50` — drop the emoji markers from the comments; keep the sentences.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php`, `Modules/Prime/app/Models/TenantMedia.php`
  - **Before** (`TenantMediaStoreController.php:17`):
    ```php
     | ⛔ THIS SCREEN READS **TenantMedia**, NEVER Prime\Models\Media — MST-01
    ```
  - **After:**
    ```php
     | THIS SCREEN READS **TenantMedia**, NEVER Prime\Models\Media — MST-01
    ```
  - **Before 2** (`TenantMediaStoreController.php:38`):
    ```php
     | ⚠ This moves a READ only. It is NOT the PROD-04 fix: every addMediaFrom*() write in
    ```
  - **After 2:**
    ```php
     | This moves a READ only. It is NOT the PROD-04 fix: every addMediaFrom*() write in
    ```
  - **Before 3** (`TenantMediaStoreController.php:95`):
    ```php
     * ⚠ `media_page` is the paginator name on purpose: on School Config this list shares a
    ```
  - **After 3:**
    ```php
     * `media_page` is the paginator name on purpose: on School Config this list shares a
    ```
  - **Before 4** (`TenantMedia.php:34`):
    ```php
     * ⚠ This does NOT fix PROD-04. The shared {@see Media} is still pinned, and 20+ modules
    ```
  - **After 4:**
    ```php
     * This does NOT fix PROD-04. The shared {@see Media} is still pinned, and 20+ modules
    ```
  - **Before 5** (`TenantMedia.php:50`):
    ```php
     * ⛔ Do not remove — and do not assume it is inherited. `MediaLibraryServiceProvider:37`
    ```
  - **After 5:**
    ```php
     * Do not remove — and do not assume it is inherited. `MediaLibraryServiceProvider:37`
    ```
  - **Verify:** `grep -nE '⚠|⛔' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php Modules/Prime/app/Models/TenantMedia.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **TMS-02** · M · DECISION · RTE-03 — `listPayload()` is a `public static` method on the controller that no route reaches; it is shared with SchoolConfigController. What should happen to it?
  - **Why it is a decision:** RTE-03 says an unrouted public method should be `abort(403)` (D5), but doing that here would break School Config Tab 3, which calls it. It is not an authorization hole (both callers gate first and it is not reachable over HTTP). Changing it is an architecture choice.
  - (a) ⭐ accept as-is — keep the shared static helper; it is deliberate and documented, and a controller split is deferred by D3.
  - (b) extract the stats/aggregation into a small service class now — cleaner, but touches both controllers and is a refactor this pass would rather not carry.
  - (c) move `listPayload()`/`baseQuery()` into a trait or value object — largest change; same two-file blast radius as (b).
  - ➜ Choice: ____

- [ ] **TMS-07** · L · DECISION · QRY-08 — the Media Store search uses leading-wildcard `LIKE '%term%'` on four `sys_media` columns. How should this be handled?
  - **Why it is a decision:** changing `%term%` to a prefix match changes what a user's search returns (mid-word matches disappear), and a FULLTEXT index needs a migration.
  - (a) ⭐ accept as-is — the store holds one school's media (3 rows live here); substring search is what the box promises and there is no measurable cost today.
  - (b) switch to a left-anchored match (`term%`) — uses an index, but a user searching a word in the middle of a filename stops getting hits.
  - (c) add a FULLTEXT index in an additive migration — keeps substring semantics and is index-backed; needs Tarun's hand to run `php artisan tenants:migrate`.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TMS-04 | Accepted as-is. `checkFile()` authorizes before it loads (`Gate::authorize` on line 158, `findOrFail` on line 160), which is required by AUTH-02. Route model binding (CTL-03) would resolve the media row **before** the gate, leaking 404-vs-403, so the manual load is the correct order here. |
