# Final Audit — SystemConfig / TenantMediaStoreController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php` (189 lines, 3 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/system-config/media-store` (the report page) and `http://test.localhost:8000/system-config/media-store/{id}/check` (an AJAX endpoint that returns JSON — is the file still on disk?). |
| Menu path | System Config → School Config → **Media Store** tab. Measured: `glb_menus` id 30 is "School Config" (`route = system-config.school-config.index`); the Media Store is Tab 3 of that page (`school-config/index.blade.php:66`). There is **no** `glb_menus` row pointing at `system-config.media-store`, so the standalone route is reachable only by typing the URL. |
| Who uses it | The roles that hold `tenant.system-config.media-store.viewAny` — measured on tenant `xyz_school_00000000000040008000_202627`: **Super Admin** and **School Admin**. The per-row check button also needs `tenant.system-config.media-store.view`. |
| What a user does here | A media (an uploaded file) is one row in the tenant table `sys_media`. This read-only page lists every media row for the school, shows four stat tiles (total files, total storage, collections, disks), lets the user search by file/collection/model name, filter by disk and by MIME type (All / Images / PDFs / Documents / Videos / Audio / Others), and click a "check file on disk" button to test whether a row's file still exists on storage. |
| Tables written | none — the controller has no write path. |
| Tables read | `sys_media` (the tenant database). The model deliberately sets no `$connection`, so under tenancy it reads the school's database, not the central `prime_db` (see the class header of `TenantMedia`). |
| Live data | tenant `xyz_school_00000000000040008000_202627`: `sys_media` = **3 rows**, 2 PNG + 1 PDF, all on disk `public`, 3 distinct collections, 2,064,356 bytes total. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**. This audit ran no HTTP request and no test (protocol D4); the data above is from `SELECT`-only queries and from the source.

## 1. Verdict

This controller is **production-ready after a small plan**. It is a 189-line, three-method, read-only report: both routed methods authorize before they load anything, both routes are GET-only and sit inside the tenant + auth + verified middleware group, and the file contains no write, no `try/catch`, no raw SQL string, no `env()` call and no debug statement. The single worst finding is **TMS-01**: because the file declares `declare(strict_types=1)`, opening `/system-config/media-store?search[]=x` hands an **array** to the `?string $search` parameter of `listPayload()`, and the page returns a 500. A second, larger risk is recorded as a **cross-cutting note** (not fixed here): all three live rows sit on the `public` disk, so the report's file links are direct storage URLs that bypass any app authorization (SEC-05). Rough effort to clear the whole plan: **S** (five small, mechanical items).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 3 | 5 | 2 | 8 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | TMS-05, TMS-06, TMS-07 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | TMS-01 | F11 Security/Tenancy | clean (cross-cutting note in §7) |
| F5 Routes | TMS-02 | F12 Style | TMS-08 |
| F6 Controller shape | TMS-03, TMS-04 | F13 Deep read | clean (read-only; see §6) |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses (protocol §4.3)

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php` | controller | 189 | this report | ✅ |
| 2 | `Modules/Prime/app/Models/TenantMedia.php` | model (the media row; reached by `index`, `listPayload`, `checkFile`) | 68 | this report — claimed in `00-CLASS-OWNERS.md` | ✅ |
| 3 | `Modules/SystemConfig/resources/views/media-store/index.blade.php` | blade (rendered by `index`) | 8 | this report | ✅ |
| 4 | `Modules/SystemConfig/resources/views/media-store/partials/_media-store.blade.php` | blade partial — **shared** with `SchoolConfigController` Tab 3 | 318 | this report (`SchoolConfigController` report declines it and links here) | ✅ |

Common classes **referenced but not audited here** (protocol §4.2): `App\Http\Controllers\Controller` (base), `routes/tenant.php` (route file), the layout `x-backend.layouts.app`, the components `x-backend.components.breadcrum`, `x-backend.tab.search-bar`, `x-backend.tab.nav-tab`, the paginator views, and the vendor base `Spatie\MediaLibrary\MediaCollections\Models\Media`.

No in-scope file appears in a `PRE-APPLIED-*.md` (there is no such file for `SystemConfig`; the only one in the repo is `tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md`).

## 4. Routes

Uncached `route:list` (from `/tmp/fa-routes.json`):

```
GET|HEAD  system-config/media-store             system-config.media-store.index  Modules\SystemConfig\Http\Controllers\TenantMediaStoreController@index
GET|HEAD  system-config/media-store/{id}/check  system-config.media-store.check  Modules\SystemConfig\Http\Controllers\TenantMediaStoreController@checkFile
```

Both routes carry the same middleware:
`web`, `Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains`, `Stancl\Tenancy\Middleware\InitializeTenancyByDomain`, `App\Http\Middleware\SetTenantAuthGuard`, `App\Http\Middleware\EnsureTenantIsActive`, `Illuminate\Auth\Middleware\Authenticate`, `Illuminate\Auth\Middleware\EnsureEmailIsVerified`.

Registration — `routes/tenant.php:108-109`, inside `Route::middleware(['auth', 'verified'])->prefix('system-config')->name('system-config.')` (the outer group at line 89 already applies tenancy). No `Route::resource` shares this prefix, so RTE-06 is not applicable.

Unrouted public methods: **`listPayload` (`TenantMediaStoreController.php:99`)** — a `public static` view-data builder shared with `SchoolConfigController`. It is not reachable over HTTP; see TMS-02.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 56 | GET system-config/media-store | `tenant.system-config.media-store.viewAny` | none (read-only) | none | none | TMS-01, TMS-03 |
| `listPayload` | 99 | not routed — `public static`, called by `index()` and by `SchoolConfigController::index()` | none (each caller gates first) | none (read-only) | none | none | TMS-02, TMS-05 |
| `checkFile` | 154 | GET system-config/media-store/{id}/check | `tenant.system-config.media-store.view` | none (read-only) | none | none | TMS-03, TMS-04 |
| `baseQuery` (private static) | 170 | n/a (private) | n/a | none | none | none | TMS-07 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try|catch|getMessage|Log::' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php` returned no output. There is no `try/catch`, so ERR-00/D1 is satisfied by construction; no exception text can reach the user; `findOrFail()` in `checkFile()` is outside any catch and correctly yields a 404.

### F2 — Transactions and audit

clean — `grep -nE 'create\(|update\(|delete\(|save\(|insert\(|DB::|activityLog' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php` returned no output. The controller has no write path (no INSERT/UPDATE/DELETE) and no service is called, so no transaction and no `activityLog()` is required. Named the tables each mutation SHOULD touch: none — there are no mutations.

### F3 — Authorization

clean — `grep -n 'Gate::authorize' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php` gives `61: Gate::authorize('tenant.system-config.media-store.viewAny');` and `158: Gate::authorize('tenant.system-config.media-store.view');`. Both calls run **before** any record is loaded (AUTH-02: `index` loads nothing; `checkFile` calls the gate on line 158 then loads on line 160). Both names are declared in `config/permissionslist.php` (`'system-config.media-store' => ['view', 'viewAny']` under the `tenant` scope, line 345), which `PermissionHelper::flatten('tenant')` turns into exactly `tenant.system-config.media-store.view` and `tenant.system-config.media-store.viewAny`; measured in `sys_permissions` (ids 43 and 44). They are seeded with an exact-name query — `database/seeders/TenantRolePermissionSeeder.php:141`, `Permission::firstOrCreate(['name' => $permission, 'guard_name' => 'web'])` (no `LIKE`). The view re-checks `.view` — `_media-store.blade.php:256`, `@can('tenant.system-config.media-store.view')` — matching the endpoint exactly. No FormRequest and no Policy is involved, so there is no AUTH-04 duplicate and no unreachable Policy.

### F4 — Validation and input

#### TMS-01 · M · VAL-05 — a `search[]` (array) query value reaches a `?string` parameter and returns a 500

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; write paths with no validation at all are H* (this is a **read** path, so the default M stands; raised from L because it is a crash, not a cosmetic gap) |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:63-70`, method `index()` |
| **Root cause** | `$request->input('search')` returns whatever the query string carries. When the URL is `?search[]=x`, `input()` returns an **array**, and the value is passed straight into `listPayload(?string $search, ?string $disk, ?string $type = null)`. Because this file declares `strict_types=1` (line 3), PHP throws a `TypeError` instead of coercing, and nothing catches it. |
| **Consequence** | A user (or a crawler) who opens `/system-config/media-store?search[]=x` gets a 500 error page instead of the media report. |
| **Reproduce** | Open `/system-config/media-store?search[]=x` (repeat with `?disk[]=x`, `?type[]=x`). Expected: the page renders with the search ignored; actual: 500. |
| **Fix approach** | Read each query parameter once, normalise it to string-or-null with `is_string()`, and pass the normalised variables to `listPayload()`. |
| **Plan item** | TMS-01 in `02-fix-plan.md` §5 |

```php
// TenantMediaStoreController.php:63-70 — CURRENT
        return view(
            'systemconfig::media-store.index',
            self::listPayload(
                $request->input('search'),
                $request->input('disk'),
                $request->input('type'),
            )
        );
```

**Evidence**
```
$ grep -nE 'input\(|validate\(|->all\(\)|->safe\(' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php
66:                $request->input('search'),
67:                $request->input('disk'),
68:                $request->input('type'),

$ php /tmp/opencode/fa-strict-tmsc.php     # same shape: strict_types=1 file, array into ?string
PHP Fatal error:  Uncaught TypeError: listPayload(): Argument #1 ($search) must be of type ?string, array given, called in /tmp/opencode/fa-strict-tmsc.php on line 3 and defined in /tmp/opencode/fa-strict-tmsc.php:2
```

### F5 — Routes

#### TMS-02 · M · RTE-03 — the `public static` `listPayload()` is not routed (a deliberate shared helper, not a route action)

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`)*. Also CTL-06 (M) — the 54-line media aggregation lives in a controller, not a service. |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:99`, method `listPayload()` |
| **Root cause** | `listPayload()` is `public static` so that `SchoolConfigController::index()` (`SchoolConfigController.php:81`) can reuse the exact same stats/filter list for its Tab 3. It is not a route action and D5's `abort(403)` cannot be applied without breaking the School Config page. Both callers already gate before calling it (`index()` gates on line 61; the SchoolConfig page gates before line 81), and it is not reachable over HTTP, so it is not an authorization hole — it is an architecture choice the rulebook's RTE-03 was not written for. |
| **Consequence** | No user-visible defect today. The cost is maintainability: the media aggregation sits in a controller and must be kept in sync with its inputs by hand. |
| **Reproduce** | static only — no URL reaches a `public static` method; the scanner flags it because it is public and unrouted. |
| **Fix approach** | Decide whether to accept the shared static helper as-is or extract the aggregation into a small service class later. This is a DECISION, not a mechanical fix. |
| **Plan item** | TMS-02 in `02-fix-plan.md` §9 |

```php
// TenantMediaStoreController.php:99 — CURRENT
    public static function listPayload(?string $search, ?string $disk, ?string $type = null): array
```

**Evidence**
```
$ grep -rn 'listPayload' Modules/ --include=*.php
Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:81:        $media = TenantMediaStoreController::listPayload(
Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:65:            self::listPayload(
Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:99:    public static function listPayload(?string $search, ?string $disk, ?string $type = null): array
```

### F6 — Controller shape

#### TMS-03 · L · CTL-04 — the two routed methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:56` (`index`) and `:154` (`checkFile`) |
| **Root cause** | `index()` returns `view(...)` and `checkFile()` returns `response()->json(...)`, but neither signature declares the return type. (`listPayload`, line 99, already declares `: array`.) |
| **Consequence** | No user-visible defect; a reader and static analysis cannot tell what each method returns without opening the body. |
| **Reproduce** | static only — a missing return type is not user-visible. |
| **Fix approach** | Add `: View` and `: JsonResponse`, and the two corresponding `use` imports. |
| **Plan item** | TMS-03 in `02-fix-plan.md` §8 |

```php
// TenantMediaStoreController.php:56 — CURRENT
    public function index(Request $request)
```

```php
// TenantMediaStoreController.php:154 — CURRENT
    public function checkFile(int $id)
```

**Evidence**
```
$ grep -nE 'public function|public static function' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php
56:    public function index(Request $request)
99:    public static function listPayload(?string $search, ?string $disk, ?string $type = null): array
154:    public function checkFile(int $id)
```

#### TMS-04 · L · CTL-03 — `checkFile()` uses `findOrFail($id)` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M default, **lowered to L with reason**) — route model binding is the house style. Here the manual `Gate::authorize` before `findOrFail` is *required* by AUTH-02: route model binding would resolve the media row **before** the method body runs, i.e. before the gate, leaking 404-vs-403. |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:154-160`, method `checkFile()` |
| **Root cause** | The route parameter is `{id}` and the method takes `int $id`, then does `TenantMedia::findOrFail($id)`. Converting to `checkFile(TenantMedia $id)` would move the load ahead of line 158's `Gate::authorize`, which the rulebook itself forbids (AUTH-02). The current order is the correct one. |
| **Consequence** | None — behaviour is correct and deliberate. Recorded so the scanner hit is answered, not silently dropped. |
| **Reproduce** | static only — an ordering/idiom note, not a runtime bug. |
| **Fix approach** | Keep as-is. No change; AUTH-02 outranks CTL-03 here. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// TenantMediaStoreController.php:154-160 — CURRENT
    public function checkFile(int $id)
    {
        // `view`, not `viewAny`: this reads ONE media row. Both names are checked by
        // code, so neither is a name minted for nothing.
        Gate::authorize('tenant.system-config.media-store.view');

        $mediaItem = TenantMedia::findOrFail($id);
```

**Evidence**
```
$ sed -n '154,160p' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php
    public function checkFile(int $id)
    {
        // `view`, not `viewAny`: this reads ONE media row. Both names are checked by
        // code, so neither is a name minted for nothing.
        Gate::authorize('tenant.system-config.media-store.view');

        $mediaItem = TenantMedia::findOrFail($id);
```

### F7 — Models

clean — `TenantMedia` (`Modules/Prime/app/Models/TenantMedia.php`) is a thin subclass of the vendor media model over the tenant table `sys_media`. Measured facts:

- `$table = 'sys_media'` (line 45) and `sys_media` exists in `database/migrations/tenant/2026_06_15_150013_create_sys_media_table.php` (MDL-07 ✅). The table has **no `deleted_at`**, and the vendor base does not use `SoftDeletes`, so `SoftDeletes` is correctly absent (MDL-03 / soft-delete semantics not applicable).
- JSON columns are cast by the vendor base: `generated_conversions`, `manipulations`, `custom_properties`, `responsive_images` → `array` (`vendor/spatie/laravel-medialibrary/.../Media.php:81-86`). `created_at`/`updated_at` are auto-cast. No boolean/decimal/enum column is missing a cast (MDL-02 ✅).
- `getMediaModel()` override (MDL-05/TEN-01) does **not** apply: this class *is* the media model, not a model that attaches media, so it never calls `InteractsWithMedia`.
- No `$connection` is set on purpose — under tenancy the default connection is the tenant, which is the whole point (TEN-03 ✅). The class's own header documents the read-only alternative to the pinned `Media` model (MST-01).
- The `booted()` observer registration (line 61) is correct and load-bearing: the vendor provider observes only `config('media-library.media_model')`, and Eloquent dispatches events by the actual class, so this subclass needs its own `observe()`.

The vendor base declares `protected $guarded = []` (MDL-01). That is a property of `Spatie\...\Media`, inherited, not declared here, and it is required by the media library's own mass-assignment; it is recorded as a cross-cutting note in §7, not a finding against this controller.

### F8 — Services and jobs

clean — `grep -nE 'Service|Job|dispatch|ShouldQueue|::class\)' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php` returned no service or job reference. The controller calls only the model and the view. No HTTP in a service, no writes on a read path, no repeated lookups to memoise.

### F9 — Queries and performance

#### TMS-05 · M · QRY-12 — five unfiltered whole-table stat queries run on every page load; three (and a fourth) can be merged

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) — *identical queries repeated in one request → resolve once*. Also QRY-05 (M) — aggregate in SQL (it already does; the point is not to scan five times). |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:102-107`, method `listPayload()` |
| **Root cause** | The four stat tiles and the disk dropdown are produced by five separate whole-table queries over `sys_media` — `count()`, `sum('size')`, `distinct('collection_name')->count(...)`, `groupBy('disk')->get()`, and `distinct('disk')->pluck(...)`. The last one is fully derivable from the `groupBy('disk')` result (it is one row per disk), and the first three are three aggregates over the same rows. On a school with tens of thousands of media rows (the file's own comment mentions 40 000) this is five full scans to paint four tiles. |
| **Consequence** | The Media Store page and School Config Tab 3 are slower than they need to be; cost grows with the school's upload history. No wrong data. |
| **Reproduce** | Open `/system-config/media-store` on a store with many rows and watch the query count (5 stat scans + the MIME aggregate + the paginated list and its count). |
| **Fix approach** | Merge the three scalar aggregates into one `selectRaw`, and take `$disks` from the existing `$diskBreakdown` collection instead of querying again. |
| **Plan item** | TMS-05 in `02-fix-plan.md` §6 |

```php
// TenantMediaStoreController.php:102-107 — CURRENT
        $totalCount = TenantMedia::count();
        $totalSizeBytes = TenantMedia::sum('size');
        $collectionCount = TenantMedia::distinct('collection_name')->count('collection_name');
        $diskBreakdown = TenantMedia::selectRaw('disk, COUNT(*) as cnt, SUM(size) as total_size')
            ->groupBy('disk')->get();
        $disks = TenantMedia::distinct('disk')->pluck('disk');
```

**Evidence**
```
$ grep -nE 'TenantMedia::|->paginate|selectRaw|pluck|distinct|groupBy|->get\(\)' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php
102:        $totalCount = TenantMedia::count();
103:        $totalSizeBytes = TenantMedia::sum('size');
104:        $collectionCount = TenantMedia::distinct('collection_name')->count('collection_name');
105:        $diskBreakdown = TenantMedia::selectRaw('disk, COUNT(*) as cnt, SUM(size) as total_size')
106:            ->groupBy('disk')->get();
107:        $disks = TenantMedia::distinct('disk')->pluck('disk');
117:            ->selectRaw('mime_type, COUNT(*) as cnt')
118:            ->groupBy('mime_type')
119:            ->pluck('cnt', 'mime_type');
145:        $media = $query->paginate(self::PER_PAGE, ['*'], 'media_page')->withQueryString();
160:        $mediaItem = TenantMedia::findOrFail($id);
172:        $query = TenantMedia::query()->orderByDesc('created_at');
```

#### TMS-06 · L · QRY-02 — the file list paginates at 25; the estate standard is 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H — pagination is mandatory and present here) with `screen-readiness-audit.md` C12 (page size exactly **10** unless the screen documents why). Pagination itself is correct (distinct `media_page` name, `withQueryString()`, links printed), so only the size is at issue → L. |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:73-74` (the constant) and `:145` (the `paginate` call), method `listPayload()` |
| **Root cause** | `private const PER_PAGE = 25;`. The estate standard across the backend is 10 (see the sibling `TenantLocationController` audit, finding TL-02), and nothing on this screen documents a reason to differ. |
| **Consequence** | A reader comparing this screen with the rest of the backend sees a different page size for no reason; consistency only. |
| **Reproduce** | Open `/system-config/media-store`; count the rows in the table (25). |
| **Fix approach** | Change the constant to 10. |
| **Plan item** | TMS-06 in `02-fix-plan.md` §6 |

```php
// TenantMediaStoreController.php:73-74 — CURRENT
    /** Rows per page on the file table. Paginator name is `media_page` — see below. */
    private const PER_PAGE = 25;
```

**Evidence**
```
$ grep -nE 'PER_PAGE|paginate\(' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php
74:    private const PER_PAGE = 25;
145:        $media = $query->paginate(self::PER_PAGE, ['*'], 'media_page')->withQueryString();
```

#### TMS-07 · L · QRY-08 — the search uses a leading-wildcard `LIKE` on four columns

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M default, **lowered to L with reason**) — *leading-wildcard `LIKE '%x%'` cannot use an index; acceptable on small tables*. Here the table is one school's media store (3 rows live, tens of thousands at worst) and substring search is what the box promises, so the default is lowered. |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:174-180`, method `baseQuery()` |
| **Root cause** | The search builds `where('file_name', 'like', "%{$search}%")` (and `name`, `collection_name`, `model_type`), all with a leading `%`, so no index can be used. The values **are** bound (not interpolated), so this is not QRY-11/ SQL injection. |
| **Consequence** | On a very large store the search is a full scan; in practice imperceptible for a single school. |
| **Reproduce** | static only — a scan-cost concern, not a visible failure. |
| **Fix approach** | A DECISION: accept, switch to a left-anchored match, or add a FULLTEXT index (needs an additive migration). |
| **Plan item** | TMS-07 in `02-fix-plan.md` §9 |

```php
// TenantMediaStoreController.php:174-180 — CURRENT
        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('file_name', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%")
                    ->orWhere('collection_name', 'like', "%{$search}%")
                    ->orWhere('model_type', 'like', "%{$search}%");
            });
        }
```

**Evidence**
```
$ sed -n '170,181p' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php
    private static function baseQuery(?string $search, ?string $disk)
    {
        $query = TenantMedia::query()->orderByDesc('created_at');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('file_name', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%")
                    ->orWhere('collection_name', 'like', "%{$search}%")
                    ->orWhere('model_type', 'like', "%{$search}%");
            });
        }
```

### F10 — Views

clean. `index.blade.php` only includes the partial; the partial runs no query. The scanner's single hit is confirmed safe: `grep -nE '{!!'` gives one line, `_media-store.blade.php:242:

```php
                    <td>{!! conversionBadge($conversions) !!}</td>
```

The helper `conversionBadge()` (`_media-store.blade.php:46-55`) interpolates only integers (`$done`, `$total`) and a colour chosen from a fixed `success`/`warning` pair — no user text reaches `{!! !!}`, so VIEW-03 does not apply. `$disks->count()` at line 116 is an in-memory `Collection::count()`, not a query (VIEW-01 clean). The `@forelse` over `$media` reads only model columns, so no relation is lazy-loaded inside the loop (VIEW-02 clean). Row actions are plain buttons/links (no `x-backend.table.action` used on this read-only table). No `{{ $model->relation }}` JSON dump exists. The breadcrumb `<x-backend.components.breadcrum title="Media Store" :links="[]" />` matches the pattern every `SystemConfig` view uses (measured), so it is consistent, not a finding. The blades are not compiled in this workflow (D4) — see §8.

### F11 — Security and tenancy

clean within the controller — `grep -nE 'env\(|\?\? [0-9]|getMessage' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php Modules/Prime/app/Models/TenantMedia.php` returned no output. No `env()` (SEC-01), no hard-coded id fallback (SEC-03), no request body or secret logged (SEC-04). Tenancy is correct: `TenantMedia` sets no `$connection`, so it follows stancl's default connection (the tenant) — proven by the model header's own measurement and by the class design; the route group carries `InitializeTenancyByDomain` and `EnsureTenantIsActive`. `checkFile()` passes no user-controlled path to `Storage`: `getPathRelativeToRoot()` and `disk` come from the media row, not the request, so there is no path traversal. The one security concern is a configuration-level one (public disk) recorded in §7.

### F12 — Style

#### TMS-08 · L · STY-04 — emoji markers in the file comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers, no commented-out code* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:17,38,95` and `Modules/Prime/app/Models/TenantMedia.php:34,50` |
| **Root cause** | The explanatory docblocks use `⛔` and `⚠` as emphasis markers. The text itself is good and must be kept; only the emoji characters are the style defect. |
| **Consequence** | None at runtime; a consistency mismatch with the emoji-free style the audit asks for. |
| **Reproduce** | static only — comment style. |
| **Fix approach** | Delete the `⛔ ` / `⚠ ` prefixes, leaving the sentence and its indentation intact. One plan item covers both files. |
| **Plan item** | TMS-08 in `02-fix-plan.md` §8 |

```php
// TenantMediaStoreController.php:17,38,95 — CURRENT
     | ⛔ THIS SCREEN READS **TenantMedia**, NEVER Prime\Models\Media — MST-01
     | ⚠ This moves a READ only. It is NOT the PROD-04 fix: every addMediaFrom*() write in
     * ⚠ `media_page` is the paginator name on purpose: on School Config this list shares a
```

**Evidence**
```
$ grep -nE '⚠|⛔' Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php Modules/Prime/app/Models/TenantMedia.php
Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:17:     | ⛔ THIS SCREEN READS **TenantMedia**, NEVER Prime\Models\Media — MST-01
Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:38:     | ⚠ This moves a READ only. It is NOT the PROD-04 fix: every addMediaFrom*() write in
Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php:95:     * ⚠ `media_page` is the paginator name on purpose: on School Config this list shares a
Modules/Prime/app/Models/TenantMedia.php:34: * ⚠ This does NOT fix PROD-04. The shared {@see Media} is still pinned, and 20+ modules
Modules/Prime/app/Models/TenantMedia.php:50:     * ⛔ Do not remove — and do not assume it is inherited. `MediaLibraryServiceProvider:37`
```

Both files already declare `strict_types=1` (STY-01 ✅). Pint was not run — the audit changes no file (D4); no obvious Pint violation is visible.

### F13 — Deep read (answer all 8 questions for every mutating method)

There are **no mutating methods**. The three methods read `sys_media` only. The eight questions are therefore answered for each read method, to show the read was made and not skipped:

| Method | 1 wrong data | 2 delete-before-store | 3 duplicate impl. | 4 soft-delete × unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `index` | n/a (read) | n/a (read) | ok | n/a (no write) | n/a | ok — gates first | ok — no message | ok — page is live |
| `listPayload` | n/a (read) | n/a (read) | ok — one implementation, shared by two callers | n/a | n/a | n/a (not routed; caller gates) | ok | ok |
| `checkFile` | n/a (read) | n/a (read) | ok | n/a | n/a | ok — gates before load | ok — returns `exists` truthfully | ok |
| `baseQuery` (private) | n/a (read) | n/a (read) | ok — one builder for both the badges and the list | n/a | n/a | n/a (private) | ok | ok |

No write can overwrite data; nothing is deleted; the single list implementation is shared on purpose. The `media_page` paginator name is deliberate (it must not collide with `settings_page`/`configs_page` on School Config) — a correct shared-page decision, not a defect.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `config/media-library.php` (`disk_name` defaults to `public`) — affects this screen's file links | Measured on tenant `xyz_school_00000000000040008000_202627`: all 3 `sys_media` rows have `disk = 'public'`. `TenantMedia::getUrl()` therefore emits a direct `/storage/...` URL (used in `_media-store.blade.php:211,248` and returned by `checkFile()`), so the file **bytes** are served by the web server with no app authorization, even though the listing is gated. A private disk served through an authorised/signed route is the SEC-05 shape. | SEC-05 | Product-wide configuration (the same `public` disk is used by the whole media pipeline) — not a change this controller's fix plan may make. |
| `Spatie\MediaLibrary\MediaCollections\Models\Media` (vendor base of `TenantMedia`) | `protected $guarded = []` — mass assignment is open (MDL-01). Required by the media library's own internal `addMediaFrom*()` writes; adding `$fillable` here risks breaking the library. | MDL-01 | Vendor base class; inherited, not declared by `TenantMedia`. |
| `TenantMediaStoreController::listPayload()` as called by `SchoolConfigController` | The SchoolConfig audit's finding SCFG-02 already normalises the *SchoolConfig* call site's inputs for this same `?string` signature. This report's TMS-01 fixes the *`index()`* call site. Both must be ticked, or one page stays 500-able. | VAL-05 | This plan (TMS-01) + the already-written `SchoolConfigController` plan (SCFG-02). |

## 8. Not covered, and why

- **No HTTP request and no test were run** (protocol D4). The 500 in TMS-01 is proven by a standalone `strict_types=1` reproduction, not by exercising the route; confirming it end-to-end would need a browser session.
- **Blades were not compiled.** `index.blade.php` and `_media-store.blade.php` were read line by line and their scanner hits confirmed, but no `compileString()`/`php -l` was run (audit is read-only, D4).
- **The `public`-disk exposure is measured, not fully traced.** The row's `disk` value is `public` (SELECT) and `getUrl()` on a public disk is a direct URL, but whether the web server serves that path for every tenant's suffixed storage root was not executed; the note states exactly what was measured.
- **Authorization refusal was not exercised.** Confirming that a role *without* `.view` gets a 403 on `checkFile` needs a seeded role lacking the permission; no such test was run (D4).
- **No Pint run.** Because the audit edits nothing, `vendor/bin/pint` was not run; STY-02 is assessed by inspection only.
