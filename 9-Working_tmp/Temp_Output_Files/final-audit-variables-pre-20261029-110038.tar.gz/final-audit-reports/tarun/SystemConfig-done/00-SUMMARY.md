# SystemConfig — Final Audit Summary

**Audited:** 2026-10-17 · **By:** opencode (main session driving 3+3+1 auditors) · **Developer folder:** tarun
**Protocol:** `.claude/rules/final-audit.md` · **Index:** [`00-INDEX.md`](00-INDEX.md)
**Phase:** AUDIT. Read-only: no `prime_ai_dev/` application code was changed.

## Per-controller

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| SchoolConfigController | 91 | 0 | 0 | 2 | 4 | 1 | SCFG-01 — every page load runs an unbounded `Module::orderBy('name')->get()` whose result no tab reads. | [01-report](SchoolConfigController/01-report.md) |
| SettingController | 134 | 0 | 0 | 5 | 7 | 1 | SET-01 — `update()` carries the D1-forbidden controller `try/catch`, which also drops the exception trace and builds the response inside the transaction. | [01-report](SettingController/01-report.md) |
| TenantLocationController | 101 | 0 | 0 | 0 | 3 | 0 | TL-02 — the four tab lists paginate at 15 where the estate standard (C12) is exactly 10. | [01-report](TenantLocationController/01-report.md) |
| TenantActivityLogController | 140 | 0 | 1 | 5 | 5 | 1 | TAL-05 — `SchoolClass::booted()` checks the `ordinal` unique key under the SoftDeletes scope, so reusing a deleted class's ordinal throws a duplicate-key 500. | [01-report](TenantActivityLogController/01-report.md) |
| TenantDropdownController | 340 | 0 | 8 | 8 | 7 | 2 | TDC-16 — `store()` slugs the `table.column` key and drops the dot, so a UI-created dropdown is saved under a key no consumer reads (silently inert). | [01-report](TenantDropdownController/01-report.md) |
| TenantMediaStoreController | 189 | 0 | 0 | 3 | 5 | 2 | TMS-01 — `declare(strict_types=1)` makes `/system-config/media-store?search[]=x` a TypeError and a 500. | [01-report](TenantMediaStoreController/01-report.md) |
| TenantDropdownNeedController | 1292 | 2 | 6 | 20 | 8 | 2 | TDN-01 — five endpoints return raw `$e->getMessage()` (SQL, table and column names) to the browser. | [01-report](TenantDropdownNeedController/01-report.md) |
| **Module totals** | **2287** | **2** | **15** | **43** | **39** | **9** | | |

**Total findings: 99** (67 plan items) · self-check PASS on all seven (`SELF-CHECK PASS — …`, re-run independently by the main session).

## Cross-controller families (fix once, module-wide)

| Family | Rule | Instances | Note |
|---|---|---|---|
| Controller `try/catch` forbidden by D1 | ERR-00 | SET-01 (Setting), TenantDropdown (all mutating methods), TenantDropdownNeed (all read/write) | Three controllers. Remove the wrapper; let `DB::transaction` + the central handler render (D1). |
| Raw `$e->getMessage()` reaching the user or logged instead of `report($e)` | ERR-01, ERR-05 | TDN-01 (B), TenantDropdown, SET-01 | The blocker is TenantDropdownNeed; Setting/Dropdown leak or drop the trace in the same shape. |
| `strict_types` + raw query-string into a `?string` parameter → 500 | VAL-02 | SCFG-02 (SchoolConfig), TMS-01 (MediaStore) | Same edit shape: cast/validate the query-string before the typed parameter. |
| Leading-wildcard `LIKE '%x%'` search on a big table | QRY-08 | SCFG-03 (DECISION), TMS-07 (DECISION) | Both flagged as DECISION (indexing/no-leading-wildcard), not mechanical fixes. |
| `is_active` switch compares `"1"` against `'on'` | VAL-06 | TenantDropdown | Every dropdown created/edited is saved inactive. |
| Pagination at 15 instead of the standard 10 | C12 | TL-02 (TenantLocation) | Cosmetic consistency; four identical tokens. |
| Oversized methods / god controller | CTL-01/CTL-02 | TDN-19 (1292-line, 24-method controller — DEFERRED, D3), TenantDropdown | Splits are DEFERRED decisions per D3; never applied in this pass. |

## Shared classes registered (owner reports)

`SystemConfig` model/request/blade classes had no owner; this audit registered them in
[`00-CLASS-OWNERS.md`](../../00-CLASS-OWNERS.md) (root), so later reports link here instead of re-auditing:

- `Modules/SystemConfig/app/Models/Setting.php` → [SettingController](SettingController/01-report.md)
- `Modules/SystemConfig/app/Models/Dropdown.php` + `app/Http/Requests/TenantDropdownRequest.php` → [TenantDropdownController](TenantDropdownController/01-report.md) (Dropdown pre-assigned by the main session to avoid a race)
- `Modules/SystemConfig/app/Models/DropdownNeed.php`, `DropdownNeedDropdown.php` + the seven `resources/views/dropdown/dropdown-need*/*.blade.php` → [TenantDropdownNeedController](TenantDropdownNeedController/01-report.md)
- `Modules/SchoolSetup/app/Models/SchConfig.php` → [SchoolConfigController](SchoolConfigController/01-report.md)
- `Modules/SchoolSetup/app/Models/SchoolClass.php`, `Section.php`, `ClassSection.php` → [TenantActivityLogController](TenantActivityLogController/01-report.md)
- `Modules/Prime/app/Models/TenantMedia.php` → [TenantMediaStoreController](TenantMediaStoreController/01-report.md)

**Linked, not owned here** (classes of other modules, `↗ linked`): `GlobalMaster` `Module`, `ActivityLog`,
`City`, `Country`, `District`, `State`; `StudentProfile` `Student`.

## Cross-cutting / wiring notes (not fixed here)

- **`TenantActivityLogController` is unrouted.** The live `system-config/activity-log` route
  (`routes/tenant.php:105`) points at `Modules\TenantCore\Http\Controllers\ActivityLogController`, not
  this SystemConfig controller. D5 applies: its methods get `abort(403)` + a `// NOT ROUTED` comment.
- **The `/system-config/dropdown` index route points at `TenantDropdownNeedController@index`**
  (`routes/tenant.php:140`), not `TenantDropdownController`. `TenantDropdownController` keeps the CRUD
  routes but no `index` route; its `index.blade.php`/`dropdown-list.blade.php` are owned by the Need report.
- **Media-store files are served from the `public` disk** (SEC-05, cross-cutting note in TMS): links bypass
  app authorization. Belongs to the shared media component / storage owner.
- **`SchoolClass`/`Section`/`ClassSection` defects** (TAL-05, plus the broken `Section` relation noted in
  TenantCore) belong to the SchoolSetup owner.

## Module-wide decisions (for Tarun)

- **TDN-19** — defer the 1,292-line god-controller split (D3).
- **TDC-10** — `/dropdown/{id}/restore` changes state over GET; change the verb?
- **TDC-14** — the create form offers 827 tenant tables but `getColumns()` whitelists only three; which side changes?
- **TDN-34** — convert the 11-control create/edit pages to modals (`modal-standard.md` §2.5)?
- **TAL-04** — what happens to the orphaned SystemConfig activity-log view (now that TenantCore serves it)?
- **TMS-02** — public static `listPayload()` (RTE-03); keep, make private, or route it?
- **SCFG-03 / TMS-07** — leading-wildcard search handling (no leading `%`, or a search index)?
- **SET-12** — orphaned `/system-config/setting/{setting}/edit` page; nothing links to it.

## Next step

Tick items in each controller's `02-fix-plan.md`, fill every `➜ Choice:` on the ticked DECISION items,
then run `final-audit-fixer` on that controller path for developer `tarun`.
