# Fix Plan — SystemConfig / TenantDropdownNeedController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SystemConfig/app/Models/Dropdown.php` | owned by `tarun/SystemConfig-done/TenantDropdownController` |
| `Modules/SystemConfig/resources/views/dropdown/index.blade.php` | shared blade, owned by `tarun/SystemConfig-done/TenantDropdownController` |
| `Modules/SystemConfig/resources/views/dropdown/dropdown-list.blade.php` | shared blade, owned by `tarun/SystemConfig-done/TenantDropdownController` |
| `resources/views/components/backend/table/action-trashed.blade.php` | common component (it already adapts to the route verb, so TDN-16 needs no edit here) |
| `config/permissionslist.php` | shared config; all seven keys already exist |
| `database/migrations/**` | never edit an existing migration |
| `routes/tenant.php` | ⚠ SHARED route file — only TDN-16 and TDN-17 may touch it, and only their exact line |

## 1. Blockers reachable today

- [ ] **TDN-01** · B · ERR-01 · `TenantDropdownNeedController.php:987` — stop returning raw exception text to the browser.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:987`):
    ```php
                'message' => 'Error saving dropdown: ' . $e->getMessage(),
    ```
  - **After:** (replace each site exactly; keep the JSON keys as they are):
    ```php
    // saveDropdownOption, line 987
                'message' => 'The dropdown option could not be saved.',

    // updateBulk, line 1044
                'message' => 'The dropdown options could not be updated.',

    // deleteBulk, line 1090
                'message' => 'The dropdown options could not be deleted.',

    // getTenantTables, line 1266
            return response()->json(['error' => 'The table list could not be loaded.']);

    // getTenantColumns, line 1289
            return response()->json(['error' => 'The column list could not be loaded.']);
    ```
  - **Verify:** `grep -n "getMessage" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** only `Log::error(... getMessage())` lines remain; no line inside a `response()->json` or a `'message' =>` uses `getMessage()`.
  - **Effort:** S

- [ ] **TDN-09** · B · AUTH-01 · `TenantDropdownNeedController.php:1270-1273` — authorize the unguarded column-listing endpoint.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:1270-1273`):
    ```php
        public function getTenantColumns(Request $request)
        {
            $tableName = $request->query('table_name');
            $dbType = $request->query('db_type', 'Tenant');
    ```
  - **After:**
    ```php
        public function getTenantColumns(Request $request)
        {
            Gate::authorize('tenant.system-config.dropdown.viewAny');

            $tableName = $request->query('table_name');
            $dbType = $request->query('db_type', 'Tenant');
    ```
  - **Verify:** `grep -n "Gate::authorize" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** the list now contains a line near 1272 (the `getTenantColumns` method).
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

## 3. Errors & transactions (F1/F2)

- [ ] **TDN-02** · H · ERR-02 · `TenantDropdownNeedController.php:508-510` — hoist `validate()` above the `try` in `store`, `update`, `toggleStatus`, `updateBulk` so a 422 is not swallowed.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:508-510`):
    ```php
            try {
                return DB::transaction(function () use ($request) {
                    $data = $request->validate([
    ```
  - **After:** (shown for `store`; apply the same hoist to `update` at 604, `toggleStatus` at 771 and `updateBulk` at 1003 — move the `validate(...)` call to the first line of the method body, above `try`):
    ```php
            $data = $request->validate([
                'db_type' => 'required|in:Prime,Tenant,Global',
                'table_name' => 'required|string|max:150',
                'column_name' => 'required|string|max:150',
                'tenant_creation_allowed' => 'required|boolean',
                'menu_category' => 'nullable|string|max:150',
                'main_menu' => 'nullable|string|max:150',
                'sub_menu' => 'nullable|string|max:150',
                'tab_name' => 'nullable|string|max:100',
                'field_name' => 'nullable|string|max:100',
                'is_system' => 'required|boolean',
                'compulsory' => 'required|boolean',
                'dropdown_table_record_exist' => 'nullable|boolean',
                'is_active' => 'nullable|boolean',
            ]);

            try {
                return DB::transaction(function () use ($data) {
    ```
  - **Verify:** `sed -n '504,512p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** `$request->validate(` appears before `try {` in all four methods.
  - **Effort:** M

- [ ] **TDN-03** · M · ERR-05 · `TenantDropdownNeedController.php:560` — log the exception object, not its message.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:560`):
    ```php
                Log::error('TenantDropdownNeedController::store failed', ['error' => $e->getMessage()]);
    ```
  - **After:** (change every `Log::error(..., ['error' => $e->getMessage()])` to pass the exception object; the eight sites are the `store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`, `updateBulk`, `deleteBulk` catches):
    ```php
                Log::error('TenantDropdownNeedController::store failed', ['exception' => $e]);

                Log::error('TenantDropdownNeedController::update failed', ['exception' => $e]);

                Log::error('TenantDropdownNeedController::destroy failed', ['exception' => $e]);

                Log::error('TenantDropdownNeedController::restore failed', ['exception' => $e]);

                Log::error('TenantDropdownNeedController::forceDelete failed', ['exception' => $e]);

                Log::error('TenantDropdownNeedController::toggleStatus failed', ['exception' => $e]);

                Log::error('TenantDropdownNeedController::updateBulk failed', ['exception' => $e]);
    ```
  - **Verify:** `grep -n "Log::error" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** every remaining `Log::error` line ends with `['exception' => $e]);` and none logs `getMessage()`.
  - **Effort:** S

- [ ] **TDN-04** · M · ERR-04 · `TenantDropdownNeedController.php:802-805` — make `toggleStatus` fail with JSON, not a redirect.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:802-805`):
    ```php
            } catch (\Throwable $e) {
                Log::error('TenantDropdownNeedController::toggleStatus failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
    ```
  - **After:**
    ```php
            } catch (\Throwable $e) {
                report($e);

                return response()->json([
                    'success' => false,
                    'message' => 'The dropdown need status could not be updated.',
                ], 500);
    ```
  - **Verify:** `grep -n "return back()->with('error'" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** no line at or near 805 (the `toggleStatus` catch no longer redirects).
  - **Effort:** S

- [ ] **TDN-05** · M · ERR-07 · `TenantDropdownNeedController.php:65-76` — remove the read-path `try/catch` (D1).
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:65-76`):
    ```php
            try {
                $rawTables = DB::connection($connection)->select('SHOW TABLES');
                $tablesList = [];
                foreach ($rawTables as $t) {
                    $obj = (array) $t;
                    $tablesList[] = reset($obj);
                }
                sort($tablesList);
                $tables = collect($tablesList);
            } catch (\Exception $e) {
                $tables = DropdownNeed::where('is_active', true)->whereNotNull('table_name')->distinct()->orderBy('table_name')->pluck('table_name');
            }
    ```
  - **After:** (apply the same removal to the other four `index` read catches at 79-83, 89-99, 103-124 and 129-148, and to the read catches at `getMenuData` 813-856, `getMainMenus` 863-891, `getSubMenus` 898-924, `getTenantTables` 1249-1267 and `getTenantColumns` 1279-1290; remove the `try {` and the matching `} catch (...) { … }`, keeping the try-body):
    ```php
            $rawTables = DB::connection($connection)->select('SHOW TABLES');
            $tablesList = [];
            foreach ($rawTables as $t) {
                $obj = (array) $t;
                $tablesList[] = reset($obj);
            }
            sort($tablesList);
            $tables = collect($tablesList);
    ```
  - **Verify:** `grep -n "catch (\\\\Exception" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** no output (all generic `\Exception` read catches removed).
  - **Effort:** M

- [ ] **TDN-06** · M · TXN-04 · `TenantDropdownNeedController.php:782-796` — move the `Toggled` audit before the success return so it runs.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:782-796`):
    ```php
                    if ($dropdownNeed->save()) {
                        return response()->json([
                            'success' => true,
                            'is_active' => $dropdownNeed->is_active,
                            'message' => 'Dropdown need status updated successfully',
                        ]);
                    }

                    activityLog($dropdownNeed, 'Toggled', ['message' => 'TenantDropdownNeed was toggled.']);

                    return response()->json([
                        'success' => false,
                        'is_active' => $dropdownNeed->is_active,
                        'message' => 'Failed to update dropdown need status',
                    ]);
    ```
  - **After:**
    ```php
                    if ($dropdownNeed->save()) {
                        activityLog($dropdownNeed, 'Toggled', ['message' => 'TenantDropdownNeed was toggled.']);

                        return response()->json([
                            'success' => true,
                            'is_active' => $dropdownNeed->is_active,
                            'message' => 'Dropdown need status updated successfully',
                        ]);
                    }

                    return response()->json([
                        'success' => false,
                        'is_active' => $dropdownNeed->is_active,
                        'message' => 'Failed to update dropdown need status',
                    ]);
    ```
  - **Verify:** `sed -n '782,792p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** `activityLog(... 'Toggled' ...)` appears before the success `return response()->json`.
  - **Effort:** S

- [ ] **TDN-07** · M · TXN-05 · `TenantDropdownNeedController.php:551-553` — build the redirect after the transaction, not inside it.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:551-553`):
    ```php
                    return redirect()
                        ->route('system-config.dropdown-need.index')
                        ->with('success', 'Dropdown need created successfully');
    ```
  - **After:** (return the model from the closure, then redirect after `DB::transaction(...)`; apply the same shape in `update` 634-636, `destroy` 674-676, `restore` 717-719, `forceDelete` 750-752 and `toggleStatus` 783-787):
    ```php
                    return $dropdownNeed;
                });

                return redirect()
                    ->route('system-config.dropdown-need.index')
                    ->with('success', 'Dropdown need created successfully');
    ```
  - **Verify:** `grep -n "return redirect()" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** no `return redirect()` line sits between a `DB::transaction(function () {` and its closing `});`.
  - **Effort:** M

- [ ] **TDN-08** · M · TXN-06 · `TenantDropdownNeedController.php:947-948` — compute the next ordinal under a row lock.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:947-948`):
    ```php
                    $maxOrdinal = Dropdown::where('key', $request->key)->max('ordinal');
                    $nextOrdinal = $maxOrdinal ? $maxOrdinal + 1 : 1;
    ```
  - **After:**
    ```php
                    $maxOrdinal = Dropdown::where('key', $request->key)->lockForUpdate()->max('ordinal');
                    $nextOrdinal = $maxOrdinal ? $maxOrdinal + 1 : 1;
    ```
  - **Verify:** `grep -n "lockForUpdate" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** one hit at line 947.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **TDN-10** · M · AUTH-06 · `TenantDropdownNeedController.php:23` — centralise the seven permission literals.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:23`):
    ```php
            Gate::authorize('tenant.system-config.dropdown.viewAny');
    ```
  - **After:** (add the constants just below the class opening brace, then replace each of the 22 literals with its constant):
    ```php
    class TenantDropdownNeedController extends Controller
    {
        private const PERM_VIEW_ANY = 'tenant.system-config.dropdown.viewAny';

        private const PERM_VIEW = 'tenant.system-config.dropdown.view';

        private const PERM_CREATE = 'tenant.system-config.dropdown.create';

        private const PERM_UPDATE = 'tenant.system-config.dropdown.update';

        private const PERM_DELETE = 'tenant.system-config.dropdown.delete';

        private const PERM_RESTORE = 'tenant.system-config.dropdown.restore';

        private const PERM_FORCE_DELETE = 'tenant.system-config.dropdown.forceDelete';

        public function index(Request $request)
        {
            Gate::authorize(self::PERM_VIEW_ANY);
    ```
  - **Verify:** `grep -c "Gate::authorize('tenant.system-config" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** `0` (no literal permission string remains in a `Gate::authorize` call).
  - **Effort:** M

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **TDN-11** · H · VAL-04 · `TenantDropdownNeedController.php:510-524` — add uniqueness rules that mirror the two unique indexes, including trashed rows.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:510-524`):
    ```php
                    $data = $request->validate([
                        'db_type' => 'required|in:Prime,Tenant,Global',
                        'table_name' => 'required|string|max:150',
                        'column_name' => 'required|string|max:150',
                        'tenant_creation_allowed' => 'required|boolean',
                        'menu_category' => 'nullable|string|max:150',
                        'main_menu' => 'nullable|string|max:150',
                        'sub_menu' => 'nullable|string|max:150',
                        'tab_name' => 'nullable|string|max:100',
                        'field_name' => 'nullable|string|max:100',
                        'is_system' => 'required|boolean',
                        'compulsory' => 'required|boolean',
                        'dropdown_table_record_exist' => 'nullable|boolean',
                        'is_active' => 'nullable|boolean',
                    ]);
    ```
  - **After:**
    ```php
                    $uniqueRule = Rule::unique('sys_dropdown_needs', 'column_name')
                        ->where(fn ($q) => $q
                            ->where('db_type', $request->input('db_type'))
                            ->where('table_name', $request->input('table_name')));

                    $data = $request->validate([
                        'db_type' => 'required|in:Prime,Tenant,Global',
                        'table_name' => 'required|string|max:150',
                        'column_name' => ['required', 'string', 'max:150', $uniqueRule],
                        'tenant_creation_allowed' => 'required|boolean',
                        'menu_category' => 'nullable|string|max:150',
                        'main_menu' => 'nullable|string|max:150',
                        'sub_menu' => 'nullable|string|max:150',
                        'tab_name' => 'nullable|string|max:100',
                        'field_name' => 'nullable|string|max:100',
                        'is_system' => 'required|boolean',
                        'compulsory' => 'required|boolean',
                        'dropdown_table_record_exist' => 'nullable|boolean',
                        'is_active' => 'nullable|boolean',
                    ]);
    ```
    Note for the fixer: on `update` (line 604) add `->ignore($id)` to `$uniqueRule`. The soft-delete semantics are intentional: the rule must see trashed rows (no `whereNull('deleted_at')`), matching the DB index.
  - **Verify:** `grep -n "Rule::unique" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** at least one hit before the `store` validate block.
  - **Effort:** M

- [ ] **TDN-12** · H · VAL-05 · `TenantDropdownNeedController.php:1059-1063` — validate `ids` before the bulk delete.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:1059-1063`):
    ```php
            try {
                DB::transaction(function () use ($request) {
                    DB::table('sys_dropdown_need_dropdowns_jnt')
                        ->whereIn('dropdown_table_id', $request->ids)
                        ->update(['is_active' => false]);
    ```
  - **After:**
    ```php
            $validated = $request->validate([
                'ids' => 'required|array',
                'ids.*' => ['integer', Rule::exists('sys_dropdown_table', 'id')],
            ]);

            try {
                DB::transaction(function () use ($validated) {
                    DB::table('sys_dropdown_need_dropdowns_jnt')
                        ->whereIn('dropdown_table_id', $validated['ids'])
                        ->update(['is_active' => false]);
    ```
  - **Verify:** `grep -n "ids.*=>.*required|array" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** one hit in `deleteBulk`.
  - **Effort:** S

- [ ] **TDN-13** · M · VAL-05 · `TenantDropdownNeedController.php:526-532` — replace the dead `$rules` block with real conditional rules.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:526-532`):
    ```php
                    if ($request->boolean('tenant_creation_allowed')) {
                        $rules['menu_category'] = 'required|string|max:150';
                        $rules['main_menu'] = 'required|string|max:150';
                        $rules['sub_menu'] = 'required|string|max:150';
                        $rules['tab_name'] = 'required|string|max:100';
                        $rules['field_name'] = 'required|string|max:100';
                    }
    ```
  - **After:** (delete this block, and change the five menu rules in the `store` validate array to the following; do the same in `update`):
    ```php
                    'menu_category' => ['nullable', 'string', 'max:150', Rule::requiredIf($request->boolean('tenant_creation_allowed'))],
                    'main_menu' => ['nullable', 'string', 'max:150', Rule::requiredIf($request->boolean('tenant_creation_allowed'))],
                    'sub_menu' => ['nullable', 'string', 'max:150', Rule::requiredIf($request->boolean('tenant_creation_allowed'))],
                    'tab_name' => ['nullable', 'string', 'max:100', Rule::requiredIf($request->boolean('tenant_creation_allowed'))],
                    'field_name' => ['nullable', 'string', 'max:100', Rule::requiredIf($request->boolean('tenant_creation_allowed'))],
    ```
  - **Verify:** `grep -n '\$rules' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **TDN-14** · M · VAL-02 · `TenantDropdownNeedController.php:1003-1010` — move inline validation into FormRequests.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`, `Modules/SystemConfig/app/Http/Requests/UpdateBulkDropdownRequest.php`
  - **Before** (`TenantDropdownNeedController.php:1003-1010`):
    ```php
                $validated = $request->validate([
                    'rows' => 'required|array',
                    'rows.*.id' => ['required', 'integer', Rule::exists('sys_dropdown_table', 'id')],
                    'rows.*.ordinal' => 'nullable|integer',
                    'rows.*.value' => 'required|string|max:255',
                    'rows.*.type' => 'nullable|string|max:255',
                    'rows.*.additional_info' => 'nullable|string|max:1000',
                ]);
    ```
  - **After:** (create the FormRequest below; change the controller method signature to inject it and read `$request->validated()`; repeat the pattern for `saveDropdownOption`, `mapDropdownsToNeed` and `removeMapping`):
    ```php
    // Modules/SystemConfig/app/Http/Requests/UpdateBulkDropdownRequest.php
    <?php

    declare(strict_types=1);

    namespace Modules\SystemConfig\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;

    class UpdateBulkDropdownRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return $this->user()?->can('tenant.system-config.dropdown.update') ?? false;
        }

        public function rules(): array
        {
            return [
                'rows' => 'required|array',
                'rows.*.id' => ['required', 'integer', Rule::exists('sys_dropdown_table', 'id')],
                'rows.*.ordinal' => 'nullable|integer',
                'rows.*.value' => 'required|string|max:100',
                'rows.*.type' => 'nullable|string|max:255',
                'rows.*.additional_info' => 'nullable|string|max:1000',
            ];
        }
    }
    ```
  - **Verify:** `test -f Modules/SystemConfig/app/Http/Requests/UpdateBulkDropdownRequest.php && echo CREATED`
  - **Expect:** `CREATED`.
  - **Effort:** M

- [ ] **TDN-15** · M · VAL-05 · `TenantDropdownNeedController.php:940` — match the `value` rule to the column length (100).
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:940`):
    ```php
                'value' => 'required|string|max:255',
    ```
  - **After:** (replace both occurrences — `saveDropdownOption` at 940 and `updateBulk` at 1007):
    ```php
                'value' => 'required|string|max:100',
    ```
  - **Verify:** `grep -n "value' => 'required|string|max:255'" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **TDN-16** · H · RTE-01 · `routes/tenant.php:153` — restore must be POST, not GET.
  - **Touches:** `routes/tenant.php`
  - ⚠ **SHARED** — `routes/tenant.php` is used by every tenant controller.
  - **Before** (`routes/tenant.php:153`):
    ```php
                Route::get('/{id}/restore', [TenantDropdownNeedController::class, 'restore'])->name('restore');
    ```
  - **After:**
    ```php
                Route::post('/{id}/restore', [TenantDropdownNeedController::class, 'restore'])->name('restore');
    ```
  - **Verify:** `grep -n "restore', \[TenantDropdownNeedController" routes/tenant.php`
  - **Expect:** the line starts with `Route::post(`. The `x-backend.table.action-trashed` component reads the route verb and emits a CSRF POST automatically, so no blade change is needed.
  - **Effort:** S

- [ ] **TDN-17** · L · RTE-06 · `routes/tenant.php:161` — rename the route parameter to match the argument.
  - **Touches:** `routes/tenant.php`
  - ⚠ **SHARED** — `routes/tenant.php` is used by every tenant controller.
  - **Before** (`routes/tenant.php:161`):
    ```php
            Route::get('/dropdown-need-api/sub-menus/{main}', [TenantDropdownNeedController::class, 'getSubMenus'])->name('dropdown-need.sub-menus');
    ```
  - **After:**
    ```php
            Route::get('/dropdown-need-api/sub-menus/{mainMenu}', [TenantDropdownNeedController::class, 'getSubMenus'])->name('dropdown-need.sub-menus');
    ```
  - **Verify:** `grep -n "sub-menus/" routes/tenant.php`
  - **Expect:** the parameter is `{mainMenu}`.
  - **Effort:** S

- [ ] **TDN-20** · M · CTL-03 · `TenantDropdownNeedController.php:566-570` — use route model binding instead of `$id` + `findOrFail`.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`, `routes/tenant.php`
  - ⚠ **SHARED** — the `routes/tenant.php` part is shared.
  - **Before** (`TenantDropdownNeedController.php:566-570`):
    ```php
        public function show($id)
        {
            Gate::authorize('tenant.system-config.dropdown.view');

            $dropdownNeed = DropdownNeed::findOrFail($id);
    ```
  - **After:** (repeat for `edit`, `update`, `destroy` and `toggleStatus`; `restore`/`forceDelete` use `->withTrashed()` binding declared on the route with `->withTrashed()`):
    ```php
        public function show(DropdownNeed $dropdownNeed)
        {
            Gate::authorize('tenant.system-config.dropdown.view');
    ```
    In `routes/tenant.php`, rename the `{id}` parameter to `{dropdownNeed}` on the `show`, `edit`, `update`, `destroy`, `restore`, `force-delete` and `toggle-status` routes (no other line changes).
  - **Verify:** `grep -n "DropdownNeed \$dropdownNeed" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** the bound signature appears for the record methods.
  - **Effort:** M

- [ ] **TDN-27** · L · MDL-04 · `DropdownNeed.php:39` — type the relationship and scope return values.
  - **Touches:** `Modules/SystemConfig/app/Models/DropdownNeed.php`
  - **Before** (`DropdownNeed.php:39-48`):
    ```php
        public function dropdowns()
        {
            return $this->belongsToMany(
                Dropdown::class,
                'sys_dropdown_need_dropdowns_jnt',
                'dropdown_needs_id',
                'dropdown_table_id'
            )->wherePivot('is_active', true)
                ->withPivot('is_active');
        }
    ```
  - **After:** (add `use Illuminate\Database\Eloquent\Relations\BelongsToMany;` and `use Illuminate\Database\Eloquent\Builder;` at the top of the file):
    ```php
        public function dropdowns(): BelongsToMany
        {
            return $this->belongsToMany(
                Dropdown::class,
                'sys_dropdown_need_dropdowns_jnt',
                'dropdown_needs_id',
                'dropdown_table_id'
            )->wherePivot('is_active', true)
                ->withPivot('is_active');
        }
    ```
  - **Verify:** `grep -n "public function dropdowns()" Modules/SystemConfig/app/Models/DropdownNeed.php`
  - **Expect:** no output (the method now declares `: BelongsToMany`).
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **TDN-29** · H · QRY-01 · `TenantDropdownNeedController.php:407-411` — remove the query inside the loop.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:406-412`):
    ```php
            $groupedDropdowns = collect();
            foreach ($dropdowns as $item) {
                $groupedDropdowns->put(
                    $item->key,
                    (clone $listBaseQuery)->where('key', $item->key)->orderBy('ordinal')->get()
                );
            }
    ```
  - **After:**
    ```php
            $groupedDropdowns = (clone $listBaseQuery)
                ->whereIn('key', $dropdowns->pluck('key'))
                ->orderBy('ordinal')
                ->get()
                ->groupBy('key');
    ```
  - **Verify:** `grep -n "groupedDropdowns->put" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** no output. Also apply the same de-looping to `updateBulk` (line 1014) and `mapDropdownsToNeed` (1117, 1124, 1130) and `deleteBulk` (1065).
  - **Effort:** M

- [ ] **TDN-30** · M · QRY-02 · `TenantDropdownNeedController.php:484-487` — stop loading every need row in `filterOptions`.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:484-487`):
    ```php
            $results = $query->get();

            return response()->json([
                'categories' => $results->whereNotNull('menu_category')->pluck('menu_category')->unique()->sort()->values(),
    ```
  - **After:**
    ```php
            $results = (clone $query)
                ->select('menu_category', 'main_menu', 'sub_menu', 'tab_name', 'field_name', 'table_name', 'column_name', 'db_type')
                ->get();

            return response()->json([
                'categories' => $results->whereNotNull('menu_category')->pluck('menu_category')->unique()->sort()->values(),
    ```
  - **Verify:** `grep -n "select('menu_category'" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** one hit in `filterOptions`.
  - **Effort:** S

- [ ] **TDN-31** · M · QRY-07 · `TenantDropdownNeedController.php:1013-1022` — preload the rows and bulk-write them.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:1013-1022`):
    ```php
                    foreach ($validated['rows'] as $rowData) {
                        $dropdown = Dropdown::find($rowData['id']);
                        if ($dropdown) {
                            $updateData = [
                                'ordinal' => $rowData['ordinal'] ?? $dropdown->ordinal,
                                'value' => $rowData['value'],
                                'type' => $rowData['type'] ?? $dropdown->type,
                                'additional_info' => $rowData['additional_info'] ?? $dropdown->getRawOriginal('additional_info'),
                            ];
                            $dropdown->update($updateData);
    ```
  - **After:**
    ```php
                    $ids = array_column($validated['rows'], 'id');
                    $existing = Dropdown::whereIn('id', $ids)->get()->keyBy('id');

                    foreach ($validated['rows'] as $rowData) {
                        $dropdown = $existing->get($rowData['id']);
                        if ($dropdown) {
                            $updateData = [
                                'ordinal' => $rowData['ordinal'] ?? $dropdown->ordinal,
                                'value' => $rowData['value'],
                                'type' => $rowData['type'] ?? $dropdown->type,
                                'additional_info' => $rowData['additional_info'] ?? $dropdown->getRawOriginal('additional_info'),
                            ];
                            $dropdown->update($updateData);
    ```
  - **Verify:** `grep -n "Dropdown::whereIn('id', \$ids)->get()->keyBy" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** one hit in `updateBulk` (the `Dropdown::find()` inside the loop is gone).
  - **Effort:** M

- [ ] **TDN-32** · M · QRY-11 · `TenantDropdownNeedController.php:310-315` — bind the id instead of interpolating it.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:310-315`):
    ```php
                    DB::raw("EXISTS (
                        SELECT 1 FROM sys_dropdown_need_dropdowns_jnt jnt
                        WHERE jnt.dropdown_table_id = sys_dropdown_table.id
                        AND jnt.dropdown_needs_id = {$selectedDropdownNeed->id}
                        AND jnt.is_active = true
                    ) as is_mapped")
    ```
  - **After:**
    ```php
                    DB::raw("EXISTS (
                        SELECT 1 FROM sys_dropdown_need_dropdowns_jnt jnt
                        WHERE jnt.dropdown_table_id = sys_dropdown_table.id
                        AND jnt.dropdown_needs_id = " . (int) $selectedDropdownNeed->id . "
                        AND jnt.is_active = true
                    ) as is_mapped")
    ```
  - **Verify:** `grep -n 'dropdown_needs_id = " .' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** one hit (the value is now cast to `int` at the interpolation point).
  - **Effort:** S

## 7. Views (F10)

- [ ] **TDN-35** · M · VIEW · `dropdown-need/index.blade.php:200-207` — use `x-backend.table.action` for row actions.
  - **Touches:** `Modules/SystemConfig/resources/views/dropdown/dropdown-need/index.blade.php`
  - **Before** (`dropdown-need/index.blade.php:200-207`):
    ```blade
                                <div class="btn-group" role="group" aria-label="Actions">
                                    @can('tenant.system-config.dropdown.view')
                                        <a href="{{ route('system-config.dropdown-need.show', $need->id) }}"
                                            class="btn btn-outline-primary btn-sm"><i class="fa-solid fa-eye"></i></a>
                                    @endcan
                                    @can('tenant.system-config.dropdown.update')
                                        <a href="{{ route('system-config.dropdown-need.edit', $need->id) }}"
                                            class="btn btn-outline-warning btn-sm confirm-action"><i class="fa-solid fa-pen-to-square"></i></a>
                                    @endcan
    ```
  - **After:**
    ```blade
                                <x-backend.table.action :model="$need"
                                    url="system-config.dropdown-need"
                                    :canView="true"
                                    :canEdit="true"
                                    :canDelete="true"
                                />
    ```
  - **Verify:** `grep -n "x-backend.table.action" Modules/SystemConfig/resources/views/dropdown/dropdown-need/index.blade.php`
  - **Expect:** one hit; the hand-written `btn-outline-primary btn-sm` action links are gone.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **TDN-23** · L · CTL-04 · `TenantDropdownNeedController.php:21` — add return types to the public methods.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:21`):
    ```php
        public function index(Request $request)
    ```
  - **After:** (add the import `use Illuminate\View\View;` and `use Illuminate\Http\RedirectResponse;` and `use Illuminate\Http\JsonResponse;`, then type each method; shown for the four shapes):
    ```php
        public function index(Request $request): View

        public function store(Request $request): RedirectResponse

        public function show(DropdownNeed $dropdownNeed): View

        public function saveDropdownOption(Request $request): JsonResponse
    ```
  - **Verify:** `grep -cE "public function [a-zA-Z_]+\([^)]*\):" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** `24`.
  - **Effort:** M

- [ ] **TDN-24** · L · CTL-07 · `TenantDropdownNeedController.php:414-417` — replace the 34-variable `compact()` with a `$data` array.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:414-417`):
    ```php
            return view('systemconfig::dropdown.index', compact(
                'activeTab',
                'dropdownNeeds',
                'mappedDropdowns',
    ```
  - **After:** (build one array and pass it; keep every variable the blades use):
    ```php
            $data = [
                'activeTab' => $activeTab,
                'dropdownNeeds' => $dropdownNeeds,
                'mappedDropdowns' => $mappedDropdowns,
                'dropdowns' => $dropdowns,
                'unmappedDropdowns' => $unmappedDropdowns,
                'dropdownsForMapping' => $dropdownsForMapping,
                'groupedDropdowns' => $groupedDropdowns,
                'listKeys' => $listKeys,
                'selectedDropdownNeed' => $selectedDropdownNeed,
                'categories' => $categories,
                'mainMenus' => $mainMenus,
                'subMenus' => $subMenus,
                'tabs' => $tabs,
                'tabNames' => $tabNames,
                'fields' => $fields,
                'dbTypes' => $dbTypes,
                'tables' => $tables,
                'columns' => $columns,
                'columnsFilter' => $columnsFilter,
                'dbType' => $dbType,
                'tableName' => $tableName,
                'columnName' => $columnName,
                'category' => $category,
                'mainMenu' => $mainMenu,
                'subMenu' => $subMenu,
                'tabName' => $tabName,
                'fieldName' => $fieldName,
                'dropdownDbType' => $dropdownDbType,
                'dropdownTableName' => $dropdownTableName,
                'dropdownColumnName' => $dropdownColumnName,
                'searchKey' => $searchKey,
                'searchValue' => $searchValue,
                'searchType' => $searchType,
                'mappingStatus' => $mappingStatus,
            ];

            return view('systemconfig::dropdown.index', $data);
    ```
  - **Verify:** `grep -n "compact(" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **TDN-25** · L · CTL-08 · `TenantDropdownNeedController.php:864` — inject `Request` instead of the helper.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:864`):
    ```php
                $menuFor = request()->get('db_type', 'Prime') === 'Tenant' ? 'tenant' : 'prime';
    ```
  - **After:** (add `Request $request` to the signature of `getMainMenus` and `getSubMenus`, and change both lines):
    ```php
        public function getMainMenus(Request $request, $category)
        {
            Gate::authorize('tenant.system-config.dropdown.viewAny');

            try {
                $menuFor = $request->get('db_type', 'Prime') === 'Tenant' ? 'tenant' : 'prime';
    ```
  - **Verify:** `grep -nE "request\(\)" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **TDN-28** · L · STY-01 · `DropdownNeed.php:1` — add `declare(strict_types=1)`.
  - **Touches:** `Modules/SystemConfig/app/Models/DropdownNeed.php`, `Modules/SystemConfig/app/Models/DropdownNeedDropdown.php`
  - **Before** (`DropdownNeed.php:1-3`):
    ```php
    <?php

    namespace Modules\SystemConfig\Models;
    ```
  - **After:** (apply to both model files):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SystemConfig\Models;
    ```
  - **Verify:** `grep -c "declare(strict_types=1)" Modules/SystemConfig/app/Models/DropdownNeed.php Modules/SystemConfig/app/Models/DropdownNeedDropdown.php`
  - **Expect:** `1` for each file.
  - **Effort:** S

- [ ] **TDN-36** · L · STY-02 · `TenantDropdownNeedController.php:7-11` — let Pint fix the import block.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php`
  - **Before** (`TenantDropdownNeedController.php:7-11`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;

    use Illuminate\Support\Facades\Log;

    use App\Http\Controllers\Controller;
    ```
  - **After:** (Pint `ordered_imports` + `no_extra_blank_lines` produce):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\Validation\Rule;
    use Modules\SystemConfig\Models\Dropdown;
    use Modules\SystemConfig\Models\DropdownNeed;
    ```
  - **Verify:** `vendor/bin/pint Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php --format agent`
  - **Expect:** no fixer listed for this file.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **TDN-19** · M · DECISION · CTL-01 — split the 1,292-line, 24-method god controller?
  - **Why it is a decision:** a god-controller split is a DEFERRED decision (D3) and changes file layout, not behaviour.
  - (a) ⭐ defer to the dedicated split pass (D3): keep this controller as is; record it in the module summary as accepted debt
  - (b) extract the lookup/AJAX endpoints (`getMenuData`, `getMainMenus`, `getSubMenus`, `getTenantTables`, `getTenantColumns`, `search`, `filterOptions`) into a `DropdownLookupController` now
  - (c) extract a `DropdownNeedService` for the per-tab data and mapping logic now
  - ➜ Choice: ____

- [ ] **TDN-34** · M · DECISION · VIEW — convert the 11-control create/edit pages to modals?
  - **Why it is a decision:** it changes the UX and how the create/edit routes are reached (modal-standard §2.5); it also touches shared layout/JS.
  - (a) ⭐ convert `create`/`edit` to modals on the list page per `modal-standard.md` §2.5
  - (b) keep them as dedicated pages and record the deviation from §2.5 as accepted
  - (c) convert only `create` (11 controls) and leave `edit` as a page
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TDN-18 | `index()` being 430 lines is a CTL-02 symptom of the same god controller; extracting it is part of the deferred split (TDN-19). |
| TDN-21 | The three copy-pasted filter blocks are removed by the same extraction (TDN-19); a standalone edit would conflict with it. |
| TDN-22 | Moving the menu-tree/mapping logic to a service is the TDN-19 split; not applied in this pass. |
| TDN-26 | The dead `$rules` array is deleted by TDN-13 and the unreachable `Toggled` log is repaired by TDN-06; no separate edit. |
| TDN-33 | Leading-wildcard `LIKE` on a 716-row table is acceptable at current size; revisit only if `sys_dropdown_table` grows large. |
