# Final Audit — SystemConfig / TenantDropdownNeedController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php` (1292 lines, 24 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/system-config/dropdown` (the 4-tab management page); `/system-config/dropdown-need` (list); `/system-config/dropdown-need/create`; `/system-config/dropdown-need/{id}` (show); `/system-config/dropdown-need/{id}/edit`; `/system-config/dropdown-need/trash/view` (trashed); the AJAX endpoints `/system-config/dropdown-need-api/*` and `/system-config/dropdowns/*` |
| Menu path | System Config → Dropdown Management |
| Who uses it | Two roles hold each `tenant.system-config.dropdown.*` permission (measured on the tenant DB `xyz_school_00000000000040008000_202627`: `sys_role_has_permissions_jnt` joins 2 roles per permission for all 7 abilities). |
| What a user does here | Maps a **dropdown need** (a `table.column` that must be offered as a dropdown) to the concrete **dropdown options** that satisfy it. Tab 1 lists/creates needs; Tab 2 lists the option groups; Tab 3 maps/unmaps options to a need; Tab 4 creates an option and maps it in one step. |
| Tables written | `sys_dropdown_needs` (soft-deleted, tenant-scoped), `sys_dropdown_table` (the options), `sys_dropdown_need_dropdowns_jnt` (the need↔option junction), `sys_activity_logs` (via `activityLog()`). |
| Tables read | `sys_dropdown_needs`, `sys_dropdown_table`, `sys_dropdown_need_dropdowns_jnt`; central `global_master.glb_menus`; table/column metadata via `SHOW TABLES` and `Schema::getColumnListing()` on the `tenant`, `mysql` and `global_master_mysql` connections. |
| Live data | On tenant `xyz_school_00000000000040008000_202627`: `sys_dropdown_needs` 151 rows (0 trashed), `sys_dropdown_table` 716 rows (0 trashed), `sys_dropdown_need_dropdowns_jnt` 776 rows. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

⚠ In-scope files that appear in a module `PRE-APPLIED-*.md`: none — no pre-applied files for this controller.

## 1. Verdict

No, this controller is not production-ready. It is a 1,292-line god controller that wraps every read and every write in a controller `try/catch` that the settled decision D1 forbids; the same catch blocks send raw database exception text to the browser (a security blocker, TDN-01) and swallow `ValidationException` so a bad form field becomes a generic "operation could not be completed" (TDN-02). The single worst finding is **TDN-01**: five write/read endpoints put `$e->getMessage()` straight into a JSON response, leaking SQL, table and column names to any user who holds the matching permission. Two written endpoints have no authorization at all in one case (TDN-09) and validation that contradicts the database in several (TDN-11, TDN-13, TDN-15). The database writes themselves are mostly correct — every mutating method has one `DB::transaction` and an `activityLog()` after the write — with two exceptions (TDN-06, TDN-07). Rough effort: **M–L** (a day or two) for the blocker/high items; the god-controller split is deferred by D3.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 6 | 20 | 8 | 2 | 36 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TDN-01, TDN-02, TDN-03, TDN-04, TDN-05 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | TDN-06, TDN-07, TDN-08 | F9 Queries/Perf | TDN-29, TDN-30, TDN-31, TDN-32, TDN-33 |
| F3 Authorization | TDN-09, TDN-10 | F10 Views | TDN-34, TDN-35 |
| F4 Validation | TDN-11, TDN-12, TDN-13, TDN-14, TDN-15 | F11 Security/Tenancy | (covered by TDN-01, TDN-09) |
| F5 Routes | TDN-16, TDN-17 | F12 Style | TDN-36 (plus model STY in TDN-28) |
| F6 Controller shape | TDN-18, TDN-19, TDN-20, TDN-21, TDN-22, TDN-23, TDN-24, TDN-25, TDN-26 | F13 Deep read | table only — no new IDs |
| F7 Models | TDN-27, TDN-28 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php` | controller | 1292 | this report | ✅ |
| 2 | `Modules/SystemConfig/app/Models/DropdownNeed.php` | model | 146 | this report | ✅ |
| 3 | `Modules/SystemConfig/app/Models/DropdownNeedDropdown.php` | model | 37 | this report | ✅ |
| 4 | `Modules/SystemConfig/app/Models/Dropdown.php` | model | 64 | ↗ [tarun/SystemConfig-done/TenantDropdownController](../TenantDropdownController/01-report.md) | ↗ linked |
| 5 | `Modules/SystemConfig/resources/views/dropdown/index.blade.php` | blade | 224 | ↗ shared with [tarun/SystemConfig-done/TenantDropdownController](../TenantDropdownController/01-report.md) | ↗ linked |
| 6 | `Modules/SystemConfig/resources/views/dropdown/dropdown-list.blade.php` | blade | 113 | ↗ shared with [tarun/SystemConfig-done/TenantDropdownController](../TenantDropdownController/01-report.md) | ↗ linked |
| 7 | `Modules/SystemConfig/resources/views/dropdown/dropdown-need/index.blade.php` | blade | 236 | this report | ✅ |
| 8 | `Modules/SystemConfig/resources/views/dropdown/dropdown-need/create.blade.php` | blade | 372 | this report | ✅ |
| 9 | `Modules/SystemConfig/resources/views/dropdown/dropdown-need/edit.blade.php` | blade | 302 | this report | ✅ |
| 10 | `Modules/SystemConfig/resources/views/dropdown/dropdown-need/show.blade.php` | blade | 104 | this report | ✅ |
| 11 | `Modules/SystemConfig/resources/views/dropdown/dropdown-need/trash.blade.php` | blade | 54 | this report | ✅ |
| 12 | `Modules/SystemConfig/resources/views/dropdown/dropdown-need-mgmt/create.blade.php` | blade | 500 | this report | ✅ |
| 13 | `Modules/SystemConfig/resources/views/dropdown/dropdown-need-mgmt/create-dropdown-jnt.blade.php` | blade | 660 | this report | ✅ |
| 14 | `routes/tenant.php` (the `system-config` group) | route file | — | common (route file — not edited here) | ❌ common |
| 15 | `config/permissionslist.php` | config | — | common (config — referenced, not audited) | ❌ common |

`Dropdown.php` and the two shared blades 5-6 are owned by the TenantDropdownController report; this report checks only how they are *used* here. Classes 2-3 and blades 7-13 were claimed in `final-audit-reports/00-CLASS-OWNERS.md` (opencode 2026-10-17).

## 4. Routes

```
GET|HEAD system-config/dropdown                                       system-config.dropdown.index                            TenantDropdownNeedController@index
GET|HEAD system-config/dropdown-need                                  system-config.dropdown-need.index                       TenantDropdownNeedController@index
POST     system-config/dropdown-need                                  system-config.dropdown-need.store                       TenantDropdownNeedController@store
GET|HEAD system-config/dropdown-need-api/columns                      system-config.dropdown-need.columns                     TenantDropdownNeedController@getTenantColumns
GET|HEAD system-config/dropdown-need-api/filter-options               system-config.dropdown-need.filter-options              TenantDropdownNeedController@getFilterOptions
GET|HEAD system-config/dropdown-need-api/main-menus/{category}        system-config.dropdown-need.main-menus                  TenantDropdownNeedController@getMainMenus
GET|HEAD system-config/dropdown-need-api/menu-data                    system-config.dropdown-need.menu-data                   TenantDropdownNeedController@getMenuData
GET|HEAD system-config/dropdown-need-api/search                       system-config.dropdown-need.search                      TenantDropdownNeedController@search
GET|HEAD system-config/dropdown-need-api/sub-menus/{main}             system-config.dropdown-need.sub-menus                   TenantDropdownNeedController@getSubMenus
GET|HEAD system-config/dropdown-need-api/tables                       system-config.dropdown-need.tables                      TenantDropdownNeedController@getTenantTables
GET|HEAD system-config/dropdown-need/create                           system-config.dropdown-need.create                      TenantDropdownNeedController@create
GET|HEAD system-config/dropdown-need/filter-options                   system-config.dropdown-need.filterOptions               TenantDropdownNeedController@filterOptions
GET|HEAD system-config/dropdown-need/trash/view                       system-config.dropdown-need.trashed                     TenantDropdownNeedController@trashed
GET|HEAD system-config/dropdown-need/{id}                             system-config.dropdown-need.show                        TenantDropdownNeedController@show
PUT      system-config/dropdown-need/{id}                             system-config.dropdown-need.update                      TenantDropdownNeedController@update
DELETE   system-config/dropdown-need/{id}                             system-config.dropdown-need.destroy                     TenantDropdownNeedController@destroy
GET|HEAD system-config/dropdown-need/{id}/edit                        system-config.dropdown-need.edit                        TenantDropdownNeedController@edit
DELETE   system-config/dropdown-need/{id}/force-delete                system-config.dropdown-need.forceDelete                 TenantDropdownNeedController@forceDelete
GET|HEAD system-config/dropdown-need/{id}/restore                     system-config.dropdown-need.restore                     TenantDropdownNeedController@restore
POST     system-config/dropdown-need/{id}/toggle-status               system-config.dropdown-need.toggleStatus                TenantDropdownNeedController@toggleStatus
POST     system-config/dropdowns/delete-bulk                          system-config.dropdowns.delete.bulk                     TenantDropdownNeedController@deleteBulk
POST     system-config/dropdowns/map-to-need                          system-config.dropdowns.mapToNeed                       TenantDropdownNeedController@mapDropdownsToNeed
POST     system-config/dropdowns/remove-mapping                       system-config.dropdowns.removeMapping                   TenantDropdownNeedController@removeMapping
POST     system-config/dropdowns/save-option                          system-config.dropdowns.saveOption                      TenantDropdownNeedController@saveDropdownOption
POST     system-config/dropdowns/update-bulk                          system-config.dropdowns.update.bulk                     TenantDropdownNeedController@updateBulk
```

Unrouted public methods: none — all 24 public methods are routed (`getFilterOptions` is routed and delegates to `filterOptions`). The tenant middleware is present: the whole block sits under `Route::middleware(['web', InitializeTenancyByDomain, SetTenantAuthGuard, PreventAccessFromCentralDomains, EnsureTenantIsActive])` then `['auth','verified']` with prefix `system-config` (`routes/tenant.php:89,103`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 21 | GET system-config/dropdown | `tenant.system-config.dropdown.viewAny` | none (read) | — | none | TDN-05, TDN-18, TDN-29, TDN-32, TDN-34 |
| `filterOptions` | 452 | GET dropdown-need/filter-options | `tenant.system-config.dropdown.viewAny` | none (read) | — | none | TDN-30 |
| `create` | 498 | GET dropdown-need/create | `tenant.system-config.dropdown.create` | none | — | none | TDN-34 |
| `store` | 504 | POST dropdown-need | `tenant.system-config.dropdown.create` | controller:509 | 'Created' (547) | sys_dropdown_needs, sys_activity_logs | TDN-02, TDN-07, TDN-11, TDN-13, TDN-14, TDN-26 |
| `show` | 566 | GET dropdown-need/{id} | `tenant.system-config.dropdown.view` | none (read) | — | none | TDN-20 |
| `edit` | 575 | GET dropdown-need/{id}/edit | `tenant.system-config.dropdown.update` | none | — | none | TDN-20, TDN-34 |
| `update` | 590 | PUT dropdown-need/{id} | `tenant.system-config.dropdown.update` | controller:595 | 'Updated' (630) | sys_dropdown_needs, sys_activity_logs | TDN-02, TDN-07, TDN-11, TDN-14, TDN-20 |
| `destroy` | 649 | DELETE dropdown-need/{id} | `tenant.system-config.dropdown.delete` | controller:654 | 'Trashed' (670) | sys_dropdown_needs, jnt, sys_activity_logs | TDN-07, TDN-20 |
| `trashed` | 689 | GET dropdown-need/trash/view | `tenant.system-config.dropdown.restore` | none (read) | — | none | — |
| `restore` | 698 | GET dropdown-need/{id}/restore | `tenant.system-config.dropdown.restore` | controller:703 | 'Restored' (713) | sys_dropdown_needs, jnt, sys_activity_logs | TDN-07, TDN-16, TDN-20 |
| `forceDelete` | 732 | DELETE dropdown-need/{id}/force-delete | `tenant.system-config.dropdown.forceDelete` | controller:737 | 'Deleted' (746) | sys_dropdown_needs, jnt, sys_activity_logs | TDN-07, TDN-20 |
| `toggleStatus` | 765 | POST dropdown-need/{id}/toggle-status | `tenant.system-config.dropdown.update` | controller:770 | 'Toggled' (790, unreachable) | sys_dropdown_needs, jnt | TDN-02, TDN-04, TDN-06, TDN-07, TDN-20, TDN-26 |
| `getMenuData` | 809 | GET dropdown-need-api/menu-data | `tenant.system-config.dropdown.viewAny` | none (read) | — | none | TDN-05 |
| `getMainMenus` | 859 | GET dropdown-need-api/main-menus/{category} | `tenant.system-config.dropdown.viewAny` | none (read) | — | none | TDN-05, TDN-25 |
| `getSubMenus` | 894 | GET dropdown-need-api/sub-menus/{main} | `tenant.system-config.dropdown.viewAny` | none (read) | — | none | TDN-05, TDN-17, TDN-25 |
| `saveDropdownOption` | 933 | POST dropdowns/save-option | `tenant.system-config.dropdown.create` | controller:946 | 'Stored' (967) | sys_dropdown_table, jnt, sys_activity_logs | TDN-01, TDN-08, TDN-14, TDN-15 |
| `updateBulk` | 998 | POST dropdowns/update-bulk | `tenant.system-config.dropdown.update` | controller:1012 | 'Updated' (1026) | sys_dropdown_table, sys_activity_logs | TDN-01, TDN-02, TDN-14, TDN-15, TDN-29, TDN-31 |
| `deleteBulk` | 1055 | POST dropdowns/delete-bulk | `tenant.system-config.dropdown.delete` | controller:1060 | 'Trashed' (1070) | sys_dropdown_table, jnt, sys_activity_logs | TDN-01, TDN-12, TDN-29, TDN-31 |
| `mapDropdownsToNeed` | 1102 | POST dropdowns/map-to-need | `tenant.system-config.dropdown.update` | controller:1113 | 'Mapped' (1145) | jnt, sys_activity_logs | TDN-14, TDN-29 |
| `removeMapping` | 1178 | POST dropdowns/remove-mapping | `tenant.system-config.dropdown.update` | controller:1189 | 'Unmapped' (1198) | jnt, sys_activity_logs | TDN-14 |
| `getFilterOptions` | 1225 | GET dropdown-need-api/filter-options | none directly (delegates to `filterOptions`, which gates `viewAny`) | none (read) | — | none | — |
| `search` | 1230 | GET dropdown-need-api/search | `tenant.system-config.dropdown.viewAny` | none (read) | — | none | TDN-33 |
| `getTenantTables` | 1245 | GET dropdown-need-api/tables | `tenant.system-config.dropdown.viewAny` | none (read) | — | none | TDN-01, TDN-05 |
| `getTenantColumns` | 1270 | GET dropdown-need-api/columns | **none** | none (read) | — | none | TDN-01, TDN-05, TDN-09 |

## 6. Findings

### F1 — Errors

#### TDN-01 · B · ERR-01 — Raw database exception text is returned to the browser

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:987, 1044, 1090, 1266, 1289` — methods `saveDropdownOption`, `updateBulk`, `deleteBulk`, `getTenantTables`, `getTenantColumns` |
| **Root cause** | Five catch blocks build the user-facing payload from `$e->getMessage()` (a `QueryException` message contains the SQL statement and the table/column names). Three concatenate it into a `message` string; two return `['error' => $e->getMessage()]` verbatim. |
| **Consequence** | Any user who holds the matching permission and triggers a DB error sees the raw SQL/table name in the browser — a schema-disclosure blocker. |
| **Reproduce** | POST `/system-config/dropdowns/save-option` with a `value` longer than 100 chars (the column is `varchar(100)`); the 500 JSON body contains the MySQL error text. |
| **Fix approach** | Replace every `getMessage()` in a response with a fixed message; log the exception object instead (see TDN-03). Remove the surrounding `try/catch` per D1 where possible. |
| **Plan item** | TDN-01 in `02-fix-plan.md` §1 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:985-988 — CURRENT
            return response()->json([
                'status' => false,
                'message' => 'Error saving dropdown: ' . $e->getMessage(),
            ], 500);
```

**Evidence**
```
$ grep -n "getMessage" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
560:            Log::error('TenantDropdownNeedController::store failed', ['error' => $e->getMessage()]);
...
987:                'message' => 'Error saving dropdown: ' . $e->getMessage(),
1044:                'message' => $e->getMessage(),
1090:                'message' => 'Error deleting dropdowns: ' . $e->getMessage(),
1266:            return response()->json(['error' => $e->getMessage()]);
1289:            return response()->json(['error' => $e->getMessage()]);
```

#### TDN-02 · H · ERR-02 — Validation runs inside the try, so a bad field becomes a generic error

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:508-563` (`store`), `:594-646` (`update`), `:769-806` (`toggleStatus`), `:1002-1046` (`updateBulk`) |
| **Root cause** | `$request->validate(...)` is called inside the `try`/`DB::transaction` closure. `ValidationException` is a `Throwable`/`Exception`, so the generic catch swallows the 422 and returns "The operation could not be completed." (or a 500 JSON) instead of the field errors. |
| **Consequence** | A user who mistypes a field sees a red "could not be completed" flash and loses the field-level error; on the bulk endpoint the client gets a 500. |
| **Reproduce** | Submit `/system-config/dropdown-need/create` with an empty `table_name`. Expected: a "table_name is required" message. Actual: the generic error flash. |
| **Fix approach** | Move `validate()` (or a FormRequest) above the `try`; per D1 remove the controller `try/catch` entirely. |
| **Plan item** | TDN-02 in `02-fix-plan.md` §3 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:508-510 — CURRENT (store)
        try {
            return DB::transaction(function () use ($request) {
                $data = $request->validate([
```

**Evidence**
```
$ grep -n "validate(\|catch (\\Throwable" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
510:                $data = $request->validate([
559:        } catch (\Throwable $e) {
604:                $data = $request->validate([
642:        } catch (\Throwable $e) {
771:                $request->validate([
802:        } catch (\Throwable $e) {
1003:            $validated = $request->validate([
```

#### TDN-03 · M · ERR-05 — Exceptions are logged as a message string, losing the trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception object (`report($e)`), not the message* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:560, 643, 683, 726, 759, 803, 1040, 1083` — the eight mutation catch blocks |
| **Root cause** | Every catch calls `Log::error('…', ['error' => $e->getMessage()])`. `getMessage()` alone has no stack trace, so the log cannot say which query or call site failed. |
| **Consequence** | When a write fails in production the log line names the controller method but not the failing statement, making diagnosis slower. |
| **Reproduce** | static only — the log payload is written on any caught failure. |
| **Fix approach** | Log the exception object (`['exception' => $e]`) or `report($e)`; per D1 remove the catch where it is not a D2 shape. |
| **Plan item** | TDN-03 in `02-fix-plan.md` §3 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:559-562 — CURRENT (store)
        } catch (\Throwable $e) {
            Log::error('TenantDropdownNeedController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
```

**Evidence**
```
$ grep -n "Log::error" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
560:            Log::error('TenantDropdownNeedController::store failed', ['error' => $e->getMessage()]);
643:            Log::error('TenantDropdownNeedController::update failed', ['error' => $e->getMessage()]);
683:            Log::error('TenantDropdownNeedController::destroy failed', ['error' => $e->getMessage()]);
726:            Log::error('TenantDropdownNeedController::restore failed', ['error' => $e->getMessage()]);
759:            Log::error('TenantDropdownNeedController::forceDelete failed', ['error' => $e->getMessage()]);
803:            Log::error('TenantDropdownNeedController::toggleStatus failed', ['error' => $e->getMessage()]);
1040:            Log::error('TenantDropdownNeedController::updateBulk failed', ['error' => $e->getMessage()]);
1083:            Log::error('TenantDropdownNeedController::deleteBulk failed', [
```

#### TDN-04 · M · ERR-04 — `toggleStatus` answers a JSON caller with an HTML redirect on failure

| Field | Value |
|---|---|
| **Rule** | ERR-04 (M) — *JSON endpoints fail with JSON; use `$request->expectsJson()` when one method serves both* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:782-788` (success JSON) vs `:802-805` (failure redirect), method `toggleStatus` |
| **Root cause** | The happy path returns `response()->json(...)` but the generic catch returns `back()->with('error', ...)` (a 302). The route is called by `fetch` from the bulk-edit blade, which reads JSON. |
| **Consequence** | On a failure the fetch handler receives a redirect/HTML instead of JSON and the status switch silently does nothing. |
| **Reproduce** | Call `POST /system-config/dropdown-need/999999/toggle-status` while authenticated; expected a JSON error, actual a 302. |
| **Fix approach** | Return a JSON error from this endpoint (or branch on `expectsJson()`); per D1 remove the catch. |
| **Plan item** | TDN-04 in `02-fix-plan.md` §3 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:802-806 — CURRENT
        } catch (\Throwable $e) {
            Log::error('TenantDropdownNeedController::toggleStatus failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ sed -n '782,788p;802,805p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
                if ($dropdownNeed->save()) {
                    return response()->json([
                        'success' => true,
                        'is_active' => $dropdownNeed->is_active,
                        'message' => 'Dropdown need status updated successfully',
                    ]);
                }
        } catch (\Throwable $e) {
            Log::error('TenantDropdownNeedController::toggleStatus failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
```

#### TDN-05 · M · ERR-07 — Read-only methods are wrapped in try/catch (D1 violation)

| Field | Value |
|---|---|
| **Rule** | ERR-07 (M) — *read-only methods (`index`, `show`, lookups) need no try/catch*; D1 forbids controller try/catch unless it is a D2 shape |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:65, 79, 89, 103, 129` (`index`), `:813` (`getMenuData`), `:863` (`getMainMenus`), `:898` (`getSubMenus`), `:1249` (`getTenantTables`), `:1279` (`getTenantColumns`) |
| **Root cause** | Every read path wraps lookups in `try { … } catch (\Exception $e) { fallback }`. No D2 exception applies: these are not `\DomainException`, not truncate-then-rebuild, and not `SnapshotProtectionException`. |
| **Consequence** | A real failure (e.g. the central DB being down) is silently turned into an empty list, so the page renders "no data" instead of an error — the operator never learns the query failed. |
| **Reproduce** | static only — requires the failing connection to observe. |
| **Fix approach** | Remove the read-path catches; let the central handler render. Keep a fallback only where a D2 shape is explicitly chosen. |
| **Plan item** | TDN-05 in `02-fix-plan.md` §3 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:65-76 — CURRENT (index)
        try {
            $rawTables = DB::connection($connection)->select('SHOW TABLES');
            $tablesList = [];
            foreach ($rawTables as $t) {
                $obj = (array) $t;
                $tablesList[] = reset($obj);
            }
            sort($tablesList);
            $tables = collect($tablesList);
        } catch (\Exception $e) {
            $tables = DropdownNeed::where('is_active', true)->whereNotNull('table_name')->distinct()->orderBy('table_name')->pluck('table_name');
        }
```

**Evidence**
```
$ grep -n "try {\|catch (" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
65:        try {
74:        } catch (\Exception $e) {
79:            try {
81:            } catch (\Exception $e) {
89:        try {
...
1249:        try {
1265:        } catch (\Exception $e) {
1279:        try {
1288:        } catch (\Exception $e) {
```

### F2 — Transactions and audit

Tables each mutation SHOULD touch (named before counting, per `controller-alignment.md` §0.1):
`store`/`update` → `sys_dropdown_needs` + `sys_activity_logs`; `destroy`/`restore`/`forceDelete`/`toggleStatus` → `sys_dropdown_needs` + `sys_dropdown_need_dropdowns_jnt` + `sys_activity_logs`; `saveDropdownOption` → `sys_dropdown_table` + `sys_dropdown_need_dropdowns_jnt` + `sys_activity_logs`; `updateBulk` → `sys_dropdown_table` + `sys_activity_logs`; `deleteBulk` → `sys_dropdown_table` + `sys_dropdown_need_dropdowns_jnt` + `sys_activity_logs`; `mapDropdownsToNeed`/`removeMapping` → `sys_dropdown_need_dropdowns_jnt` + `sys_activity_logs`.

Good news: all **11** mutating methods run inside exactly ONE `DB::transaction` (`grep -n "DB::transaction"` → 11 hits at 509, 595, 654, 703, 737, 770, 946, 1012, 1060, 1113, 1189) and 10 of 11 call `activityLog()` after the write and inside the closure. The three findings below are the exceptions.

#### TDN-06 · M · TXN-04 — `toggleStatus` never writes its audit entry on success

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:782-790`, method `toggleStatus` |
| **Root cause** | `activityLog($dropdownNeed, 'Toggled', …)` is placed **after** an unconditional `return response()->json(...)` in the `if ($dropdownNeed->save())` branch, so it is unreachable on every successful save; the only reachable branch is the `false` return which `save()` never produces for a valid model. |
| **Consequence** | Toggling a need's status leaves no audit record — the trail silently misses every status change. |
| **Reproduce** | Toggle any need on `/system-config/dropdown` and query `sys_activity_logs` for the event `Toggled` — none is written. |
| **Fix approach** | Move `activityLog(...)` before the success `return`, inside the transaction. |
| **Plan item** | TDN-06 in `02-fix-plan.md` §3 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:782-796 — CURRENT
                if ($dropdownNeed->save()) {
                    return response()->json([
                        'success' => true,
                        'is_active' => $dropdownNeed->is_active,
                        'message' => 'Dropdown need status updated successfully',
                    ]);
                }

                activityLog($dropdownNeed, 'Toggled', ['message' => 'TenantDropdownNeed was toggled.']);

                return response()->json([
                    'success' => false,
                    'is_active' => $dropdownNeed->is_active,
                    'message' => 'Failed to update dropdown need status',
                ]);
```

**Evidence**
```
$ sed -n '782,796p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
                if ($dropdownNeed->save()) {
                    return response()->json([
                        'success' => true,
                        'is_active' => $dropdownNeed->is_active,
                        'message' => 'Dropdown need status updated successfully',
                    ]);
                }

                activityLog($dropdownNeed, 'Toggled', ['message' => 'TenantDropdownNeed was toggled.']);
```

#### TDN-07 · M · TXN-05 — HTTP responses are built inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build `redirect()`/`response()` after it* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:551-553` (`store`), `:634-636` (`update`), `:674-676` (`destroy`), `:717-719` (`restore`), `:750-752` (`forceDelete`), `:783-787` (`toggleStatus`) |
| **Root cause** | `return redirect(...)->with(...)` / `return response()->json(...)` are the closure's return value. The redirect object is constructed while the transaction is still open. |
| **Consequence** | Harder to reason about and inconsistent with the rest of the codebase; no user-visible failure today but it couples the response to the transaction. |
| **Reproduce** | static only — no observable browser effect. |
| **Fix approach** | Have the closure return the model/count, then build the redirect/JSON after `DB::transaction(...)` returns. |
| **Plan item** | TDN-07 in `02-fix-plan.md` §3 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:551-553 — CURRENT (store)
                return redirect()
                    ->route('system-config.dropdown-need.index')
                    ->with('success', 'Dropdown need created successfully');
```

**Evidence**
```
$ grep -n "DB::transaction" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
509:            return DB::transaction(function () use ($request) {
595:            return DB::transaction(function () use ($request, $id) {
654:            return DB::transaction(function () use ($id) {
703:            return DB::transaction(function () use ($id) {
737:            return DB::transaction(function () use ($id) {
770:            return DB::transaction(function () use ($request, $id) {
```

#### TDN-08 · M · TXN-06 — `saveDropdownOption` picks the next ordinal with a read-then-insert race

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H, lowered to M) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:947-957`, method `saveDropdownOption` |
| **Root cause** | `Dropdown::where('key', …)->max('ordinal')` then `+1` then `create()`. Two concurrent saves for the same `key` read the same max and insert the same ordinal. `sys_dropdown_table` has no unique index on `(key, ordinal)`, so the duplicate is accepted silently. |
| **Consequence** | Two options can share an ordinal, so their display order becomes non-deterministic. |
| **Reproduce** | static only — a concurrent write is required. |
| **Fix approach** | Compute the ordinal inside a locked transaction (`lockForUpdate`) or add a unique index on `(key, ordinal)` (a DECISION — migration). |
| **Plan item** | TDN-08 in `02-fix-plan.md` §3 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:947-957 — CURRENT
                $maxOrdinal = Dropdown::where('key', $request->key)->max('ordinal');
                $nextOrdinal = $maxOrdinal ? $maxOrdinal + 1 : 1;

                $dropdown = Dropdown::create([
                    'ordinal' => $nextOrdinal,
                    'key' => $request->key,
                    'value' => $request->value,
                    'type' => $request->type ?? 'String',
                    'additional_info' => $request->additional_info,
                    'is_active' => true,
                ]);
```

**Evidence**
```
$ sed -n '947,948p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
                $maxOrdinal = Dropdown::where('key', $request->key)->max('ordinal');
                $nextOrdinal = $maxOrdinal ? $maxOrdinal + 1 : 1;
```

### F3 — Authorization

#### TDN-09 · B · AUTH-01 — `getTenantColumns` has no authorization and lists any connection's columns

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B) — *every routed controller method authorizes before doing its work* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:1270-1291`, method `getTenantColumns` (route `system-config.dropdown-need.columns`) |
| **Root cause** | The method has no `Gate::authorize` (every sibling AJAX method has one) and no `can:` middleware on the route. It reads `table_name` and `db_type` from the query string and calls `Schema::connection($connection)->getColumnListing($tableName)`, where `db_type` may be `Prime` (`mysql`) or `Global` (`global_master_mysql`). |
| **Consequence** | Any authenticated tenant user — even one with no dropdown permission — can enumerate the column names of any table on the central tenant, prime or global-master database. |
| **Reproduce** | As a logged-in tenant user, open `/system-config/dropdown-need-api/columns?db_type=Global&table_name=prm_tenant`; the response lists the columns although the user holds no dropdown permission. |
| **Fix approach** | Add `Gate::authorize('tenant.system-config.dropdown.viewAny')` (or `…view`) at the top of the method, matching `getTenantTables`. |
| **Plan item** | TDN-09 in `02-fix-plan.md` §1 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:1270-1285 — CURRENT
    public function getTenantColumns(Request $request)
    {
        $tableName = $request->query('table_name');
        $dbType = $request->query('db_type', 'Tenant');

        if (!$tableName) {
            return response()->json([]);
        }

        try {
            $connection = match ($dbType) {
                'Prime' => 'mysql',
                'Global' => 'global_master_mysql',
                default => 'tenant',
            };
            $columns = \Illuminate\Support\Facades\Schema::connection($connection)->getColumnListing($tableName);
```

**Evidence**
```
$ grep -n "public function getTenantColumns" -A 3 Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
1270:    public function getTenantColumns(Request $request)
1271:    {
1272:        $tableName = $request->query('table_name');
1273:        $dbType = $request->query('db_type', 'Tenant');
(no Gate::authorize in 1270-1291)

$ grep -n "Gate::authorize" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
...
1247:        Gate::authorize('tenant.system-config.dropdown.viewAny');
1270 is absent from the list
```

#### TDN-10 · M · AUTH-06 — Permission strings are repeated as literals in 22 places

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place, not repeated as literals in every method* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:23, 454, 500, 506, 568, 577, 592, 651, 691, 700, 734, 767, 811, 861, 896, 935, 1000, 1057, 1104, 1180, 1232, 1247` |
| **Root cause** | The seven `tenant.system-config.dropdown.*` strings are typed out at 22 call sites. There is no constants class or Policy. |
| **Consequence** | A permission rename requires a find-and-replace across the controller, and a typo in one literal silently disables that check. |
| **Reproduce** | static only. |
| **Fix approach** | Keep the literals but centralise them (constants or a Policy). All seven names already exist in `config/permissionslist.php` under `system-config.dropdown` and are seeded, so no new key is needed. |
| **Plan item** | TDN-10 in `02-fix-plan.md` §4 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:23 — CURRENT (one of 22)
        Gate::authorize('tenant.system-config.dropdown.viewAny');
```

**Evidence**
```
$ grep -c "Gate::authorize" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
22
```

### F4 — Validation and input

#### TDN-11 · H · VAL-04 — Uniqueness rules do not mirror the two unique indexes (soft-delete trap)

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the DB unique index including soft-delete semantics* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:510-524` (`store`), `:604-617` (`update`) |
| **Root cause** | `sys_dropdown_needs` has `uq_dropdownNeeds_db_table_column_key (db_type, table_name, column_name)` and `uq_dropdownNeeds_menu_path_key (menu_category, main_menu, sub_menu, tab_name, field_name)`, and it is soft-deleted. The controller validates neither, and because the index does not include `deleted_at`, a soft-deleted row still occupies the key. |
| **Consequence** | Creating (or restoring) a need that matches a live OR a soft-deleted row fails with a DB unique violation, which the generic catch turns into "The operation could not be completed." — the user is told nothing about the duplicate. |
| **Reproduce** | Create a need for an existing `db_type`/`table_name`/`column_name`, or re-create one whose earlier row is in `/system-config/dropdown-need/trash/view`. |
| **Fix approach** | Add `Rule::unique('sys_dropdown_needs', 'table_name')->where(...)` mirroring the index (including trashed rows), or a `withTrashed` existence check in a FormRequest. |
| **Plan item** | TDN-11 in `02-fix-plan.md` §5 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:510-524 — CURRENT (store; no unique rule)
                $data = $request->validate([
                    'db_type' => 'required|in:Prime,Tenant,Global',
                    'table_name' => 'required|string|max:150',
                    'column_name' => 'required|string|max:150',
                    'tenant_creation_allowed' => 'required|boolean',
                    'menu_category' => 'nullable|string|max:150',
                    'main_menu' => 'nullable|string|max:150',
                    'sub_menu' => 'nullable|string|max:150',
                    'tab_name' => 'nullable|string|max:100',
                    'field_name' => 'nullable|string|max:100',
                    'is_system' => 'required|boolean',
                    'compulsory' => 'required|boolean',
                    'dropdown_table_record_exist' => 'nullable|boolean',
                    'is_active' => 'nullable|boolean',
                ]);
```

**Evidence**
```
$ mysql -uroot -p'***' -e "SHOW CREATE TABLE xyz_school_00000000000040008000_202627.sys_dropdown_needs\G" | grep -i "unique"
  UNIQUE KEY `uq_dropdownNeeds_db_table_column_key` (`db_type`,`table_name`,`column_name`),
  UNIQUE KEY `uq_dropdownNeeds_menu_path_key` (`menu_category`,`main_menu`,`sub_menu`,`tab_name`,`field_name`),
```

#### TDN-12 · H · VAL-05 — `deleteBulk` writes from an unvalidated `ids` array

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M, raised to H) — *write paths with no validation at all are H* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:1059-1076`, method `deleteBulk` |
| **Root cause** | The method never validates `$request->ids`. It passes it straight to `whereIn('dropdown_table_id', $request->ids)` and `Dropdown::whereIn('id', $request->ids)`. A missing/`null` value makes `whereIn(null)` behave unpredictably, and there is no `Rule::exists` to confirm the ids are real options. |
| **Consequence** | A malformed request (or a stale form) can pass arbitrary ids; the user sees a 500 or a partial deactivation. |
| **Reproduce** | POST `/system-config/dropdowns/delete-bulk` with no `ids` field. |
| **Fix approach** | Validate `'ids' => 'required|array'` and `'ids.*' => 'integer|exists:sys_dropdown_table,id'` before the transaction. |
| **Plan item** | TDN-12 in `02-fix-plan.md` §5 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:1059-1063 — CURRENT
        try {
            DB::transaction(function () use ($request) {
                DB::table('sys_dropdown_need_dropdowns_jnt')
                    ->whereIn('dropdown_table_id', $request->ids)
                    ->update(['is_active' => false]);
```

**Evidence**
```
$ grep -n "request->ids" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
1062:                    ->whereIn('dropdown_table_id', $request->ids)
1065:                Dropdown::whereIn('id', $request->ids)->each(function ($dropdown) {
1084:                'ids'   => $request->ids,
```

#### TDN-13 · M · VAL-05 — Conditional "required" rules are built but never applied (dead `$rules`)

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed and its conditional requirements enforced; a rule array built and discarded enforces nothing* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:526-532`, method `store` |
| **Root cause** | When `tenant_creation_allowed` is true the code writes `$rules['menu_category'] = 'required|…'` etc. into a `$rules` variable that is never passed to a validator (the validation call happened earlier at line 510). The database enforces the same rule with `chk_dropdown_needs_valid`, so a blank menu field with `tenant_creation_allowed=1` passes PHP validation and then violates the CHECK constraint. |
| **Consequence** | The user submits a need with a blank menu field, gets a generic "operation could not be completed" (TDN-02) instead of a field error, and never learns which field is missing. |
| **Reproduce** | Submit `/system-config/dropdown-need/create` with `tenant_creation_allowed=1` and an empty `main_menu`. |
| **Fix approach** | Delete the `$rules` block and put the conditional rules in a FormRequest using `Rule::requiredIf(...)`. |
| **Plan item** | TDN-13 in `02-fix-plan.md` §5 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:526-532 — CURRENT
                if ($request->boolean('tenant_creation_allowed')) {
                    $rules['menu_category'] = 'required|string|max:150';
                    $rules['main_menu'] = 'required|string|max:150';
                    $rules['sub_menu'] = 'required|string|max:150';
                    $rules['tab_name'] = 'required|string|max:100';
                    $rules['field_name'] = 'required|string|max:100';
                }
```

**Evidence**
```
$ grep -n '\$rules' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
527:                    $rules['menu_category'] = 'required|string|max:150';
528:                    $rules['main_menu'] = 'required|string|max:150';
529:                    $rules['sub_menu'] = 'required|string|max:150';
530:                    $rules['tab_name'] = 'required|string|max:100';
531:                    $rules['field_name'] = 'required|string|max:100';
```

#### TDN-14 · M · VAL-02 — Validation lives inline in the controller, not in a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request, not inline `$request->validate()`* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:510` (`store`), `:604` (`update`), `:771` (`toggleStatus`), `:937` (`saveDropdownOption`), `:1003` (`updateBulk`), `:1106` (`mapDropdownsToNeed`), `:1182` (`removeMapping`) |
| **Root cause** | Seven methods call `$request->validate([...])` inline. Only `toggleStatus` (a one-field AJAX toggle) is an allowed exception. |
| **Consequence** | The rules cannot be reused or unit-tested, and the same fields are validated twice with slightly different rule sets (store vs update). |
| **Reproduce** | static only. |
| **Fix approach** | Extract FormRequests for `store`/`update` and the four bulk endpoints; keep the inline rule only for the one-field toggle. |
| **Plan item** | TDN-14 in `02-fix-plan.md` §5 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:1003-1010 — CURRENT (updateBulk)
            $validated = $request->validate([
                'rows' => 'required|array',
                'rows.*.id' => ['required', 'integer', Rule::exists('sys_dropdown_table', 'id')],
                'rows.*.ordinal' => 'nullable|integer',
                'rows.*.value' => 'required|string|max:255',
                'rows.*.type' => 'nullable|string|max:255',
                'rows.*.additional_info' => 'nullable|string|max:1000',
            ]);
```

**Evidence**
```
$ grep -n "request->validate(" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
510:                $data = $request->validate([
604:                $data = $request->validate([
771:                $request->validate([
937:        $request->validate([
1003:            $validated = $request->validate([
1106:        $request->validate([
1182:        $request->validate([
```

#### TDN-15 · M · VAL-05 — `value` is validated at max:255 but the DB column holds only 100 chars

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field's rule must match the storage it writes to* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:940` (`saveDropdownOption`), `:1007` (`updateBulk`) |
| **Root cause** | Both rules say `'value' => 'required|string|max:255'`, but `sys_dropdown_table.value` is `varchar(100)`. A 101–255 char value passes validation and then fails (or is truncated in non-strict mode) at the database. |
| **Consequence** | A user typing a long option value gets a generic DB error flash instead of "value may not be greater than 100 characters". |
| **Reproduce** | POST `/system-config/dropdowns/save-option` with a 150-char `value`; the row is rejected by MySQL. |
| **Fix approach** | Change both rules to `max:100` to match the column. |
| **Plan item** | TDN-15 in `02-fix-plan.md` §5 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:937-943 — CURRENT (saveDropdownOption)
        $request->validate([
            'dropdown_need_id' => 'required|exists:sys_dropdown_needs,id',
            'key' => 'required|string|max:160',
            'value' => 'required|string|max:255',
            'additional_info' => 'nullable|string',
            'type' => 'nullable|string|in:String,Integer,Decimal,Date,Boolean',
        ]);
```

**Evidence**
```
$ mysql -uroot -p'***' -e "SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='xyz_school_00000000000040008000_202627' AND TABLE_NAME='sys_dropdown_table' AND COLUMN_NAME IN ('key','value');"
COLUMN_NAME	DATA_TYPE	CHARACTER_MAXIMUM_LENGTH
key	varchar	160
value	varchar	100
```

### F5 — Routes

#### TDN-16 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `routes/tenant.php:153` → `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:698-730`, method `restore` |
| **Root cause** | The restore endpoint is registered with `Route::get('/{id}/restore', ...)`, and the body performs three writes (`restore()`, `update(is_active)`, junction `update`). |
| **Consequence** | A link prefetcher, browser prefetch or an `<img src>` can restore a trashed need with no CSRF token and no user intent. |
| **Reproduce** | Open `/system-config/dropdown-need/123/restore` directly (or let the browser prefetch it); the record is restored. |
| **Fix approach** | Change the route to `Route::post(...)` (or PATCH) and update the trash blade's restore control to a form with `@csrf`; route name stays `system-config.dropdown-need.restore`. |
| **Plan item** | TDN-16 in `02-fix-plan.md` §5 |

```php
// routes/tenant.php:153 — CURRENT
            Route::get('/{id}/restore', [TenantDropdownNeedController::class, 'restore'])->name('restore');
```

**Evidence**
```
$ grep -n "'/{id}/restore'" routes/tenant.php
153:            Route::get('/{id}/restore', [TenantDropdownNeedController::class, 'restore'])->name('restore');
```

#### TDN-17 · L · RTE-06 — Route parameter `{main}` does not match the argument `$mainMenu`

| Field | Value |
|---|---|
| **Rule** | RTE-06 (L) — *the route parameter name matches the controller argument* (`module-finalization.md` §3.3.1) |
| **Where** | `routes/tenant.php:161` → `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:894`, method `getSubMenus` |
| **Root cause** | The route declares `{main}` but the method signature is `getSubMenus($mainMenu)`. There is no model type-hint, so Laravel binds positionally and it works today — but the name mismatch is a trap if anyone later adds a `DropdownNeed $mainMenu` type-hint or reorders the parameters. |
| **Consequence** | No user-visible failure today; a future refactor silently breaks the sub-menu AJAX endpoint. |
| **Reproduce** | static only. |
| **Fix approach** | Rename the route parameter to `{mainMenu}` (the sibling `{category}` already matches its argument). |
| **Plan item** | TDN-17 in `02-fix-plan.md` §5 |

```php
// routes/tenant.php:161 — CURRENT
        Route::get('/dropdown-need-api/sub-menus/{main}', [TenantDropdownNeedController::class, 'getSubMenus'])->name('dropdown-need.sub-menus');
```

**Evidence**
```
$ sed -n '161p' routes/tenant.php
        Route::get('/dropdown-need-api/sub-menus/{main}', [TenantDropdownNeedController::class, 'getSubMenus'])->name('dropdown-need.sub-menus');
$ sed -n '894p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
    public function getSubMenus($mainMenu)
```

### F6 — Controller shape

#### TDN-18 · H · CTL-02 — `index()` is 430 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — *a method over 150 lines is H (over 80 is M)* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:21-450`, method `index` |
| **Root cause** | One method loads five independent lists, the filter cascade for four tabs, the menu tree from `glb_menus`, and renders a single view. |
| **Consequence** | Any change to one tab risks the other three; the method cannot be read or reasoned about in one pass. |
| **Reproduce** | static only. |
| **Fix approach** | Extract the per-tab data loading into private methods or a service; treat as part of the deferred split (TDN-19). |
| **Plan item** | none — see `02-fix-plan.md` §10 (part of TDN-19) |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:21-27 — CURRENT
    public function index(Request $request)
    {
        Gate::authorize('tenant.system-config.dropdown.viewAny');

        $activeTab = $request->get('tab', $request->get('active_tab', 'dropdown-need'));
```

**Evidence**
```
$ grep -n "public function index\|public function filterOptions" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
21:    public function index(Request $request)
452:    public function filterOptions(Request $request)
(21 → 450 is 430 lines)
```

#### TDN-19 · M · CTL-01 — 1,292-line, 24-method god controller

| Field | Value |
|---|---|
| **Rule** | CTL-01 (M) — *over 1,000 lines or 25 public methods → split; over 2,500 is H* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php` (whole file, 1292 lines, 24 public methods) |
| **Root cause** | Four responsibilities share one class: needs CRUD, option bulk CRUD, need↔option mapping, and the AJAX/table-metadata lookups. |
| **Consequence** | Every change carries regression risk across four unrelated screens; merge conflicts are frequent. |
| **Reproduce** | static only. |
| **Fix approach** | Deferred by D3 — recorded as a DECISION, not applied in this pass. |
| **Plan item** | TDN-19 in `02-fix-plan.md` §9 (DECISION) |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:19-21 — CURRENT
class TenantDropdownNeedController extends Controller
{
    public function index(Request $request)
```

**Evidence**
```
$ wc -l Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
1292 Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
$ grep -c "public function " Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
24
```

#### TDN-20 · M · CTL-03 — No route model binding (seven methods use `$id` + `findOrFail`)

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:566` (`show`), `:575` (`edit`), `:590` (`update`), `:649` (`destroy`), `:698` (`restore`), `:732` (`forceDelete`), `:765` (`toggleStatus`) |
| **Root cause** | Every record method accepts a raw `$id` and resolves the model by hand; the routes declare `{id}`. |
| **Consequence** | 404/403 ordering and `withTrashed()` handling are hand-written in each method and can drift; more code to maintain. |
| **Reproduce** | static only. |
| **Fix approach** | Type-hint `DropdownNeed $dropdownNeed` and rename the route parameter; the trash endpoints use `->withTrashed()`. Deferred with the split if the plan chooses. |
| **Plan item** | TDN-20 in `02-fix-plan.md` §5 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:566-570 — CURRENT (show)
    public function show($id)
    {
        Gate::authorize('tenant.system-config.dropdown.view');

        $dropdownNeed = DropdownNeed::findOrFail($id);
```

**Evidence**
```
$ grep -n "findOrFail(\$id)\|withTrashed()->findOrFail(\$id)" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
570:        $dropdownNeed = DropdownNeed::findOrFail($id);
579:        $dropdownNeed = DropdownNeed::findOrFail($id);
596:                $dropdownNeed = DropdownNeed::findOrFail($id);
655:                $dropdownNeed = DropdownNeed::findOrFail($id);
704:                $dropdownNeed = DropdownNeed::withTrashed()->findOrFail($id);
738:                $dropdownNeed = DropdownNeed::withTrashed()->findOrFail($id);
775:                $dropdownNeed = DropdownNeed::findOrFail($id);
```

#### TDN-21 · M · CTL-05 — The same eight-field filter block is copy-pasted three times

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste; shared filter blocks are extracted* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:159-184`, `:197-228`, `:458-482` (`index` Tab 1, `index` Tab 3, `filterOptions`) |
| **Root cause** | The identical `db_type`/`table_name`/`column_name`/`menu_category`/`main_menu`/`sub_menu`/`tab_name`/`field_name` `if ($x) { $q->where(…) }` block is written three times. |
| **Consequence** | A filter added to one copy is forgotten in the other two, so the tabs disagree about what the filter means. |
| **Reproduce** | static only. |
| **Fix approach** | Use the model's existing `scopeFilterBy*` methods (`DropdownNeed.php:66-118`) or a private `applyNeedFilters($query, $request)`. |
| **Plan item** | none — see `02-fix-plan.md` §10 (folded into the deferred split TDN-19) |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:159-184 — CURRENT (one of three copies)
        if ($isTab1) {
            if ($dbType) {
                $dropdownNeedsQuery->where('db_type', $dbType);
            }
            if ($tableName) {
                $dropdownNeedsQuery->where('table_name', $tableName);
            }
            if ($columnName) {
                $dropdownNeedsQuery->where('column_name', $columnName);
            }
```

**Evidence**
```
$ grep -n "->where('db_type', \$dbType)" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
161:                $dropdownNeedsQuery->where('db_type', $dbType);
198:                $selectedNeedQuery->where('db_type', $dbType);
```

#### TDN-22 · M · CTL-06 — Business logic (menu-tree assembly and mapping) lives in the controller

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in services/actions; the controller reads input and calls one service* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:809-857` (`getMenuData` builds the category/main/sub tree), `:1102-1170` (`mapDropdownsToNeed`) |
| **Root cause** | The category/main/sub-menu classification loop and the map/revive logic are written directly in controller methods. |
| **Consequence** | The menu-classification rule cannot be reused or changed in one place; it is duplicated with the near-identical `index()` logic at lines 101-149. |
| **Reproduce** | static only. |
| **Fix approach** | Extract a `DropdownNeedService` (menu tree) and a mapping action; deferred with the split. |
| **Plan item** | none — see `02-fix-plan.md` §10 (folded into the deferred split TDN-19) |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:829-843 — CURRENT (getMenuData)
            foreach ($menus as $menu) {
                $entry = [
                    'id' => $menu->id,
                    'title' => $menu->title,
                    'parent_id' => $menu->parent_id,
                ];

                if ($menu->is_category == 1) {
                    $categories[] = $entry;
                } elseif (in_array($menu->parent_id, $categoryIds)) {
                    $mainMenus[] = $entry;
                } else {
                    $subMenus[] = $entry;
                }
            }
```

**Evidence**
```
$ grep -n "foreach (\$menus as \$menu)" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
829:            foreach ($menus as $menu) {
```

#### TDN-23 · L · CTL-04 — Public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | all 24 public methods in `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php` |
| **Root cause** | No method declares a return type. |
| **Consequence** | The contract of each endpoint is implicit; a wrong return (e.g. a redirect from a JSON endpoint) is not caught by static analysis. |
| **Reproduce** | static only. |
| **Fix approach** | Add `: View` / `: RedirectResponse` / `: JsonResponse` to the public methods. |
| **Plan item** | TDN-23 in `02-fix-plan.md` §8 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:21 — CURRENT
    public function index(Request $request)
```

**Evidence**
```
$ grep -cE "public function [a-zA-Z_]+\([^)]*\):" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
0
```

#### TDN-24 · L · CTL-07 — `compact()` of 34 variables

| Field | Value |
|---|---|
| **Rule** | CTL-07 (L) — *no `compact()` of more than ~15 variables* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:414-449`, method `index` |
| **Root cause** | One `compact(...)` lists 34 view variables. |
| **Consequence** | It is impossible to tell which variables the view actually uses; unused ones are shipped silently. |
| **Reproduce** | static only. |
| **Fix approach** | Build one `$data` array per tab or a view-model object; deferred with the split. |
| **Plan item** | TDN-24 in `02-fix-plan.md` §8 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:414-417 — CURRENT
        return view('systemconfig::dropdown.index', compact(
            'activeTab',
            'dropdownNeeds',
            'mappedDropdowns',
```

**Evidence**
```
$ sed -n '414,449p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php | grep -c ","
34
```

#### TDN-25 · L · CTL-08 — `request()` helper used instead of the injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:864` (`getMainMenus`), `:899` (`getSubMenus`) |
| **Root cause** | Both methods use `request()->get('db_type', 'Prime')` even though a `Request` could be injected. |
| **Consequence** | The methods are harder to test and rely on the global container. |
| **Reproduce** | static only. |
| **Fix approach** | Add a `Request $request` parameter and use `$request->get(...)`. |
| **Plan item** | TDN-25 in `02-fix-plan.md` §8 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:864 — CURRENT
            $menuFor = request()->get('db_type', 'Prime') === 'Tenant' ? 'tenant' : 'prime';
```

**Evidence**
```
$ grep -nE "request\(\)" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
864:            $menuFor = request()->get('db_type', 'Prime') === 'Tenant' ? 'tenant' : 'prime';
899:            $menuFor = request()->get('db_type', 'Prime') === 'Tenant' ? 'tenant' : 'prime';
```

#### TDN-26 · M · CTL-10 — Dead code: the unused `$rules` array and the unreachable `Toggled` log

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:526-532` (`$rules` built, never used — see TDN-13), `:790` (`activityLog(... 'Toggled' ...)` after an early return — see TDN-06) |
| **Root cause** | A rules array and an audit call that no execution path reaches. |
| **Consequence** | A reader believes the conditional validation and the toggle audit exist; they do not. |
| **Reproduce** | static only. |
| **Fix approach** | Covered by TDN-13 (delete `$rules`) and TDN-06 (move the log before the return). |
| **Plan item** | none — see `02-fix-plan.md` §10 (resolved by TDN-13 and TDN-06) |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:790 — CURRENT
                activityLog($dropdownNeed, 'Toggled', ['message' => 'TenantDropdownNeed was toggled.']);
```

**Evidence**
```
$ sed -n '789,790p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
                }

                activityLog($dropdownNeed, 'Toggled', ['message' => 'TenantDropdownNeed was toggled.']);
```

### F7 — Models

#### TDN-27 · L · MDL-04 — `DropdownNeed` relationship/scope methods have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`…)* |
| **Where** | `Modules/SystemConfig/app/Models/DropdownNeed.php:39` (`dropdowns()`), `:49` (`activeDropdowns()`) |
| **Root cause** | Both relationship methods omit a return type; the eight `scopeFilterBy*` methods also have no return type. `DropdownNeedDropdown.php` is correct here (it declares `: BelongsTo`). |
| **Consequence** | No runtime effect; static analysis cannot verify the relation type. |
| **Reproduce** | static only. |
| **Fix approach** | Add `: BelongsToMany` to the two relation methods and `: Builder` to the scopes. |
| **Plan item** | TDN-27 in `02-fix-plan.md` §5 |

```php
// DropdownNeed.php:39-48 — CURRENT
    public function dropdowns()
    {
        return $this->belongsToMany(
            Dropdown::class,
            'sys_dropdown_need_dropdowns_jnt',
            'dropdown_needs_id',
            'dropdown_table_id'
        )->wherePivot('is_active', true)
            ->withPivot('is_active');
    }
```

**Evidence**
```
$ grep -nE "public function (dropdowns|activeDropdowns)\(\)" Modules/SystemConfig/app/Models/DropdownNeed.php
39:    public function dropdowns()
49:    public function activeDropdowns()
```

#### TDN-28 · L · STY-01 — Both owned models omit `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `Modules/SystemConfig/app/Models/DropdownNeed.php:1`, `Modules/SystemConfig/app/Models/DropdownNeedDropdown.php:1` |
| **Root cause** | Neither model declares strict types. |
| **Consequence** | Weak-mode coercion is allowed in a codebase that otherwise uses strict types. |
| **Reproduce** | static only. |
| **Fix approach** | Add `declare(strict_types=1);` after `<?php` in both files. |
| **Plan item** | TDN-28 in `02-fix-plan.md` §8 |

```php
// DropdownNeedDropdown.php:1-3 — CURRENT
<?php

namespace Modules\SystemConfig\Models;
```

**Evidence**
```
$ grep -n "declare(strict_types" Modules/SystemConfig/app/Models/DropdownNeed.php Modules/SystemConfig/app/Models/DropdownNeedDropdown.php
(no output)
```

### F8 — Services and jobs

clean — this controller names no service, job, event, mail or notification; `grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b' TenantDropdownNeedController.php` → no output.

### F9 — Queries and performance

#### TDN-29 · H · QRY-01 — Queries run inside loops in three methods

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; eager-load, key a collection, or bulk-write* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:407-411` (`index`), `:1014` (`updateBulk`), `:1117, 1124, 1130` (`mapDropdownsToNeed`), `:1065-1074` (`deleteBulk`) |
| **Root cause** | `index()` runs one `get()` per key in a `foreach`; `updateBulk` does `Dropdown::find()` per row; `mapDropdownsToNeed` does a `DB::table(...)->first()` and an `insert()`/`update()` per id; `deleteBulk` does `save()`+`delete()`+`activityLog()` per row via `each()`. |
| **Consequence** | A mapping page with 10 keys issues 11 queries; a bulk update of N rows issues 2N+ queries and a bulk delete of N rows issues 3N+ — a page that should be 2 queries becomes dozens. |
| **Reproduce** | Open `/system-config/dropdown?tab=dropdown-list` with a debug bar; count `select … from sys_dropdown_table where key = ?` repeated per visible key. |
| **Fix approach** | Pre-load with `whereIn(...)->get()->groupBy('key')`; bulk-write with `upsert()`/`whereIn()->update()`. |
| **Plan item** | TDN-29 in `02-fix-plan.md` §6 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:406-412 — CURRENT (index)
        $groupedDropdowns = collect();
        foreach ($dropdowns as $item) {
            $groupedDropdowns->put(
                $item->key,
                (clone $listBaseQuery)->where('key', $item->key)->orderBy('ordinal')->get()
            );
        }
```

**Evidence**
```
$ sed -n '407,411p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
        foreach ($dropdowns as $item) {
            $groupedDropdowns->put(
                $item->key,
                (clone $listBaseQuery)->where('key', $item->key)->orderBy('ordinal')->get()
            );
        }
```

#### TDN-30 · M · QRY-02 — `filterOptions` loads every matching need with `->get()`

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M) — *no unbounded `->get()` feeding a list/JSON endpoint; paginate or aggregate in SQL* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:484-495`, method `filterOptions` |
| **Root cause** | `$results = $query->get();` loads every matching `sys_dropdown_needs` row (the table has 151 rows on the measured tenant, and grows), then computes the distinct values in PHP. |
| **Consequence** | As the needs table grows the AJAX filter endpoint transfers every row and filters in memory; the response payload grows with the table. |
| **Reproduce** | GET `/system-config/dropdown-need/filter-options` with no filters. |
| **Fix approach** | Return `pluck(...)->unique()` per column, or run a `selectDistinct` / `groupBy` aggregate in SQL. |
| **Plan item** | TDN-30 in `02-fix-plan.md` §6 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:484-487 — CURRENT
        $results = $query->get();

        return response()->json([
            'categories' => $results->whereNotNull('menu_category')->pluck('menu_category')->unique()->sort()->values(),
```

**Evidence**
```
$ sed -n '484,485p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
        $results = $query->get();

        return response()->json([
```

#### TDN-31 · M · QRY-07 — Per-row `update()`/`save()`/`delete()` instead of bulk writes

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *bulk-write with `insert()`/`upsert()`/`whereIn()->update()` instead of `create()`/`update()` per row* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:1014-1030` (`updateBulk`), `:1065-1074` (`deleteBulk`) |
| **Root cause** | `updateBulk` calls `Dropdown::find()` + `update()` + `activityLog()` per row; `deleteBulk` calls `save()` + `delete()` + `activityLog()` per row. (The per-row `activityLog()` is intended — see TDN-29 — but the option writes themselves could be batched.) |
| **Consequence** | A 50-row bulk edit performs 100+ statements instead of ~2, a visible slowdown on the dropdown management page. |
| **Reproduce** | Submit a large bulk edit on the "manage" tab and watch the query count. |
| **Fix approach** | Pre-fetch all rows in one `whereIn(...)->get()->keyBy('id')`, then `whereIn(...)->update()` in bulk; keep one audit line per changed row only if the per-row trail is required. |
| **Plan item** | TDN-31 in `02-fix-plan.md` §6 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:1013-1022 — CURRENT (updateBulk)
                foreach ($validated['rows'] as $rowData) {
                    $dropdown = Dropdown::find($rowData['id']);
                    if ($dropdown) {
                        $updateData = [
                            'ordinal' => $rowData['ordinal'] ?? $dropdown->ordinal,
                            'value' => $rowData['value'],
                            'type' => $rowData['type'] ?? $dropdown->type,
                            'additional_info' => $rowData['additional_info'] ?? $dropdown->getRawOriginal('additional_info'),
                        ];
                        $dropdown->update($updateData);
```

**Evidence**
```
$ sed -n '1013,1015p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
                foreach ($validated['rows'] as $rowData) {
                    $dropdown = Dropdown::find($rowData['id']);
                    if ($dropdown) {
```

#### TDN-32 · M · QRY-11 — Interpolated raw SQL in the mapping `EXISTS` subquery

| Field | Value |
|---|---|
| **Rule** | QRY-11 (B, lowered to M) — *no interpolated raw SQL (`DB::raw("…$var")`); use bindings* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:309-316`, method `index` |
| **Root cause** | `DB::raw("… AND jnt.dropdown_needs_id = {$selectedDropdownNeed->id} …")` interpolates the id directly. The value is an integer primary key read from the database (not user input), so it is not currently injectable — hence M not B — but it is raw SQL that must use bindings. |
| **Consequence** | Any future change that makes the interpolated value non-integer (or a different source) becomes a live SQL-injection path. |
| **Reproduce** | static only — the value is a DB-sourced integer today. |
| **Fix approach** | Use `DB::raw('… = ?')` with `addSelect`/`selectRaw` bindings, or a `whereExists()` closure. |
| **Plan item** | TDN-32 in `02-fix-plan.md` §6 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:310-315 — CURRENT
                DB::raw("EXISTS (
                    SELECT 1 FROM sys_dropdown_need_dropdowns_jnt jnt
                    WHERE jnt.dropdown_table_id = sys_dropdown_table.id
                    AND jnt.dropdown_needs_id = {$selectedDropdownNeed->id}
                    AND jnt.is_active = true
                ) as is_mapped")
```

**Evidence**
```
$ grep -n 'DB::raw("EXISTS' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
310:                DB::raw("EXISTS (
```

#### TDN-33 · L · QRY-08 — Leading-wildcard `LIKE` search on the options list

| Field | Value |
|---|---|
| **Rule** | QRY-08 (L) — *leading-wildcard `LIKE '%x%'` cannot use an index; acceptable on small tables* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:270` (`list_value`), `:371, 374` (`searchKey`, `searchValue`), `:1238-1240` (`search`) |
| **Root cause** | User-supplied text filters use `where('value', 'like', '%'.$v.'%')` and the `search` endpoint uses `orWhere(... 'LIKE', "%{$request->search}%")`. |
| **Consequence** | On the measured tenant `sys_dropdown_table` has 716 rows (small), so the cost is negligible today; it would matter if the table grows large. |
| **Reproduce** | static only (performance-only). |
| **Fix approach** | Acceptable at current size; add a FULLTEXT/prefix search column only if the table grows. |
| **Plan item** | none — see `02-fix-plan.md` §10 (accepted, small table) |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:1238-1242 — CURRENT (search)
        return DropdownNeed::where('table_name', 'LIKE', "%{$request->search}%")
            ->orWhere('column_name', 'LIKE', "%{$request->search}%")
            ->orWhere('field_name', 'LIKE', "%{$request->search}%")
            ->limit(10)
            ->get(['table_name', 'column_name', 'field_name']);
```

**Evidence**
```
$ grep -n "like', '%'\|LIKE', \"%" Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
270:                $listBaseQuery->where('value', 'like', '%' . $listValue . '%');
371:                $dropdownsForMappingQuery->where('sys_dropdown_table.key', 'like', '%' . $searchKey . '%');
374:                $dropdownsForMappingQuery->where('sys_dropdown_table.value', 'like', '%' . $searchValue . '%');
1238:        return DropdownNeed::where('table_name', 'LIKE', "%{$request->search}%")
```

### F10 — Views

No queries in Blade and no raw output: `grep -nE "DB::|Model::|::where|->get\(\)|->count\(\)|\{!!"` over the seven owned/linked blades returns only collection `->count()` calls on data already passed in. Proved:
```
$ grep -rn "{!!\|DB::\|::where\|Models\\\\" Modules/SystemConfig/resources/views/dropdown/dropdown-need/ Modules/SystemConfig/resources/views/dropdown/dropdown-need-mgmt/
(no output)
```

#### TDN-34 · M · VIEW — The create/edit forms are full pages, not modals (modal-standard §2.5)

| Field | Value |
|---|---|
| **Rule** | VIEW (F10) — *a create form with 15 or fewer controls is a modal (`modal-standard.md` §2.5)* |
| **Where** | `Modules/SystemConfig/resources/views/dropdown/dropdown-need/create.blade.php`, `.../edit.blade.php`; routes `system-config.dropdown-need.create/edit` |
| **Root cause** | Both forms carry 11 visible controls, below the 15-control threshold, yet they are dedicated full pages with their own route, layout and `@push('scripts')` block instead of a modal on the list page. |
| **Consequence** | Creating an option leaves the list page, breaking the "add then see it in the list" flow; the standard's expected pattern is a dialog. |
| **Reproduce** | Click `[+]` on `/system-config/dropdown-need`; a whole page loads instead of a dialog. |
| **Fix approach** | Convert both to a modal on the list page per `modal-standard.md` §2.5 (DECISION-grade because it changes the UX and the route usage). |
| **Plan item** | TDN-34 in `02-fix-plan.md` §9 (DECISION) |

```blade
// dropdown-need/create.blade.php:20 — CURRENT
                        <form action="{{ route('system-config.dropdown-need.store') }}" method="POST">
```

**Evidence**
```
$ B=Modules/SystemConfig/resources/views/dropdown/dropdown-need/create.blade.php; t=$(grep -coE '<(input|select|textarea)\b' $B); h=$(grep -coE '<input[^>]*type="hidden"' $B); echo "visible=$((t-h))"
visible=11
```

#### TDN-35 · M · VIEW — Row actions use raw buttons instead of `x-backend.table.action`

| Field | Value |
|---|---|
| **Rule** | VIEW (F10) — *row actions use `x-backend.table.action`; trash rows use `action-trashed`* |
| **Where** | `Modules/SystemConfig/resources/views/dropdown/dropdown-need/index.blade.php:199-215` |
| **Root cause** | The show/edit/delete controls are hand-written `<a class="btn …">` and a `<form class="d-inline confirm-action-form">`, not the shared `x-backend.table.action` component. |
| **Consequence** | The actions drift from the app-wide table style; `:canEdit` semantics and the trash variant are not reused, so permission display can diverge from other tables. |
| **Reproduce** | Open `/system-config/dropdown-need` and compare the action column with any table using `x-backend.table.action`. |
| **Fix approach** | Replace the hand-written controls with `x-backend.table.action` (and `action-trashed` on the trash blade). |
| **Plan item** | TDN-35 in `02-fix-plan.md` §7 |

```blade
// dropdown-need/index.blade.php:200-207 — CURRENT
                            <div class="btn-group" role="group" aria-label="Actions">
                                @can('tenant.system-config.dropdown.view')
                                    <a href="{{ route('system-config.dropdown-need.show', $need->id) }}"
                                        class="btn btn-outline-primary btn-sm"><i class="fa-solid fa-eye"></i></a>
                                @endcan
                                @can('tenant.system-config.dropdown.update')
                                    <a href="{{ route('system-config.dropdown-need.edit', $need->id) }}"
                                        class="btn btn-outline-warning btn-sm confirm-action"><i class="fa-solid fa-pen-to-square"></i></a>
                                @endcan
```

**Evidence**
```
$ grep -nE "x-backend.table.action|action-trashed" Modules/SystemConfig/resources/views/dropdown/dropdown-need/index.blade.php
(no output)
$ grep -nE "btn-outline-primary btn-sm" Modules/SystemConfig/resources/views/dropdown/dropdown-need/index.blade.php
202:                                        class="btn btn-outline-primary btn-sm"><i class="fa-solid fa-eye"></i></a>
```

### F11 — Security and tenancy

No `env()` in the controller (`grep -nE "env\("` → no output). Tenant middleware is present on all routes. The two real security findings are recorded under F1 (TDN-01, raw DB text) and F3 (TDN-09, unguarded schema endpoint); no additional F11 finding.

### F12 — Style

#### TDN-36 · L · STY-02 — Controller is not Pint-clean (stray blank lines between imports)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:7-9` |
| **Root cause** | Blank lines separate the first three `use` statements (`ModelNotFoundException`, `Log`, then the class imports), which Pint's `no_extra_blank_lines` / `ordered_imports` fixers remove. |
| **Consequence** | No runtime effect; inconsistent with the rest of the module. |
| **Reproduce** | `vendor/bin/pint --test` on the file shows the fixers. |
| **Fix approach** | Run Pint on the touched file (only at fix time). |
| **Plan item** | TDN-36 in `02-fix-plan.md` §8 |

```php
// Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php:7-11 — CURRENT
use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use App\Http\Controllers\Controller;
```

**Evidence**
```
$ sed -n '7,11p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php
use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use App\Http\Controllers\Controller;
```

### F13 — Deep read (answer all 8 questions for every mutating method)

8 questions: (1) wrong-data overwrite · (2) delete-before-store order · (3) duplicate implementations · (4) soft-delete × unique index · (5) race · (6) authorization hole · (7) message that lies · (8) dead feature. Each cell is `ok` or a finding ID.

| Mutation | 1 Wrong data | 2 Order | 3 Duplicate impl | 4 Soft-del × unique | 5 Race | 6 Auth hole | 7 Lie | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | TDN-11 | ok | ok | TDN-13 | TDN-13 |
| `update` | ok | ok | ok | TDN-11 | ok | ok | ok | ok |
| `destroy` | ok | ok | ok | TDN-11 | ok | ok | ok | ok |
| `restore` | ok | ok | ok | TDN-11 | ok | ok | ok | ok |
| `forceDelete` | ok | ok | ok | TDN-11 | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | TDN-06 | TDN-06 |
| `saveDropdownOption` | ok | ok | ok | ok | TDN-08 | ok | ok | ok |
| `updateBulk` | ok | ok | TDN-31 | ok | ok | ok | ok | ok |
| `deleteBulk` | ok | ok | TDN-31 | ok | ok | TDN-12 | ok | ok |
| `mapDropdownsToNeed` | ok | ok | ok | ok | ok (unique index backs the insert) | ok | ok | ok |
| `removeMapping` | ok | ok | ok | ok | ok | ok | ok | ok |

Notes on the `ok` verdicts that a reader would otherwise question:

- **`update` Q1** — `is_active` is set from `$request->boolean('is_active')`; the edit blade posts `is_active="1"` when checked and omits it when unchecked (`resources/views/components/backend/form/status-switch.blade.php:26`), so the coercion is correct and does not silently deactivate.
- **`destroy`/`restore`/`forceDelete` Q2** — the delete of a replacement never precedes a store; the junction is deactivated then the row soft-deleted (destroy), and reactivated after the row is restored (restore).
- **`mapDropdownsToNeed` Q5** — the `exists`-then-`insert` check is guarded by the unique index `uq_ddNDJ_dropdownNeedsId_dropdownTableId` on `(dropdown_needs_id, dropdown_table_id)`, so a duplicate would fail the insert rather than corrupt the mapping.
- **`destroy`/`restore` Q4** — the junction has no `deleted_at` column, so there is no soft-delete × pivot trap.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `resources/views/components/backend/form/status-switch.blade.php` | Posts the checkbox as `value="1"`; the sibling `TenantDropdownController` normaliser expects `'on'` (TDC-09). This controller reads the posted value with `$request->boolean()` / `nullable|boolean`, so it is unaffected. | — | the controller's own fix (TDC-09) |
| `Modules/SystemConfig/app/Models/Dropdown.php` | Owned by the TenantDropdownController report (soft-delete + `$table` verified correct here: `sys_dropdown_table`); this controller uses it read/write through the model and `DB::table`. | — | [tarun/SystemConfig-done/TenantDropdownController](../TenantDropdownController/01-report.md) |

## 8. Not covered, and why

- The rendered HTML of the four-tab page was not inspected in a browser; only the Blade source was read. A runtime layout issue would not appear here.
- `getMainMenus`/`getSubMenus`/`getMenuData` were not executed against `global_master.glb_menus`; the query shape was read statically.
- The `reflection`/runtime behaviour of `DB::connection('tenant')` under a live tenant request was not exercised (no tests, D4); the connection name is the stancl/tenancy reserved connection and is used elsewhere in the codebase.
- No queue jobs, listeners, policies or FormRequests exist for this controller, so F8 is reported clean rather than unverified.
