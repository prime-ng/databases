# Fix Plan — SystemConfig / TenantLocationController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/app/Models/Country.php` | owned by another report (`tarun/GlobalMaster-done/CountryController`) |
| `Modules/GlobalMaster/app/Models/State.php` | owned by another report (`tarun/GlobalMaster-done/StateController`) |
| `Modules/GlobalMaster/app/Models/District.php` | owned by another report (`tarun/GlobalMaster-done/DistrictController`) |
| `Modules/GlobalMaster/app/Models/City.php` | owned by another report (`tarun/GlobalMaster-done/CityController`) |
| `resources/views/components/backend/tab/nav-tab.blade.php` | shared component |
| `resources/views/components/backend/tab/search-bar.blade.php` | shared component |
| `resources/views/components/backend/components/breadcrum.blade.php` | shared component |
| `app/View/Components/Backend/Components/Breadcrum.php` | shared component class |
| `routes/tenant.php` | route file |
| `config/permissionslist.php` | shared permission config |

## 1. Blockers reachable today

None.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None.

## 4. Authorization (F3)

None.

## 5. Validation, routes, models (F4/F5/F7)

None.

## 6. Queries & performance (F9)

- [ ] **TL-02** · L · QRY-02 · `Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php:46, :53, :60, :67` — set the four tab page sizes to the estate standard of 10.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php`
  - **Before** (`TenantLocationController.php:42-68`):
    ```php
        $countriesQuery = Country::orderBy('name');
        if ($tab === 'country' && $search) {
            $countriesQuery->where('name', 'LIKE', "%{$search}%");
        }
        $countries = $countriesQuery->paginate(15, ['*'], 'country_page')
            ->appends(['tab' => $tab, 'search' => $search]);

        $statesQuery = State::with('country')->orderBy('name');
        if ($tab === 'state' && $search) {
            $statesQuery->where('name', 'LIKE', "%{$search}%");
        }
        $states = $statesQuery->paginate(15, ['*'], 'state_page')
            ->appends(['tab' => $tab, 'search' => $search]);

        $districtsQuery = District::with('state')->orderBy('name');
        if ($tab === 'district' && $search) {
            $districtsQuery->where('name', 'LIKE', "%{$search}%");
        }
        $districts = $districtsQuery->paginate(15, ['*'], 'district_page')
            ->appends(['tab' => $tab, 'search' => $search]);

        $citiesQuery = City::with(['district', 'district.state'])->orderBy('name');
        if ($tab === 'city' && $search) {
            $citiesQuery->where('name', 'LIKE', "%{$search}%");
        }
        $cities = $citiesQuery->paginate(15, ['*'], 'city_page')
            ->appends(['tab' => $tab, 'search' => $search]);
    ```
  - **After:**
    ```php
        $countriesQuery = Country::orderBy('name');
        if ($tab === 'country' && $search) {
            $countriesQuery->where('name', 'LIKE', "%{$search}%");
        }
        $countries = $countriesQuery->paginate(10, ['*'], 'country_page')
            ->appends(['tab' => $tab, 'search' => $search]);

        $statesQuery = State::with('country')->orderBy('name');
        if ($tab === 'state' && $search) {
            $statesQuery->where('name', 'LIKE', "%{$search}%");
        }
        $states = $statesQuery->paginate(10, ['*'], 'state_page')
            ->appends(['tab' => $tab, 'search' => $search]);

        $districtsQuery = District::with('state')->orderBy('name');
        if ($tab === 'district' && $search) {
            $districtsQuery->where('name', 'LIKE', "%{$search}%");
        }
        $districts = $districtsQuery->paginate(10, ['*'], 'district_page')
            ->appends(['tab' => $tab, 'search' => $search]);

        $citiesQuery = City::with(['district', 'district.state'])->orderBy('name');
        if ($tab === 'city' && $search) {
            $citiesQuery->where('name', 'LIKE', "%{$search}%");
        }
        $cities = $citiesQuery->paginate(10, ['*'], 'city_page')
            ->appends(['tab' => $tab, 'search' => $search]);
    ```
  - **Verify:** `grep -nE "paginate\(" Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php`
  - **Expect:** four lines, each of the form `paginate(10, ['*'], 'country_page')`, `'state_page'`, `'district_page'` and `'city_page'`; no `paginate(15` remains.
  - **Effort:** S

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

None.

## 9. Deferred / decisions

None.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TL-01 | Accepted — leading-wildcard `LIKE '%x%'` on central tables measured at 1/36/785/1592 rows; QRY-08 allows a leading wildcard on small tables. Switching to FULLTEXT or a search column is a central-schema decision, not this controller's. |
| TL-03 | Accepted — the four copy-paste tab blocks are in a 101-line read-only controller; the refactor is deferred (D3) with no behavioural gain. |
