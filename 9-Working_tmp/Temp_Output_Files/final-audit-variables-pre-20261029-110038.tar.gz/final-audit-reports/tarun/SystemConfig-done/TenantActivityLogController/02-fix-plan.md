# Fix Plan — SystemConfig / TenantActivityLogController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `routes/tenant.php` | route file — the live `system-config/activity-log` route must keep pointing at the TenantCore controller |
| `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php` | the live implementation; owned by `tarun/TenantCore-done/ActivityLogController` |
| `Modules/TenantCore/resources/views/activity-log/index.blade.php` | the live view; owned by `tarun/TenantCore-done/ActivityLogController` |
| `config/permissionslist.php` | shared config — the permission key is already declared and correct |
| `Modules/GlobalMaster/app/Models/ActivityLog.php` | owned by `tarun/GlobalMaster-done/ActivityLogController` |
| `Modules/StudentProfile/app/Models/Student.php` | owned by `gaurav/StudentProfile/StudentReportController` |
| any file under `database/migrations/` | never edit an existing migration |

## 1. Blockers reachable today

None — no B-severity finding in this controller. The controller is not routed, so nothing here is reachable by a user.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — F1 and F2 are clean.

## 4. Authorization (F3)

None — F3 is clean.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **TAL-01** · M · RTE-03 · `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:23-139` — disable the unrouted method per D5.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php`
  - **Before** (`TenantActivityLogController.php:23-139`):
    ```php
    public function index(Request $request)
    {
        Gate::authorize('tenant.system-config.activity-log.viewAny');

        $activeTab = $request->input('tab', 'all');
        $isStudentParentTab = $activeTab === 'student-parent';

        $query = ActivityLog::with('user')->latest();

        // Global search
        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('subject_type', 'like', "%{$search}%")
                  ->orWhere('event', 'like', "%{$search}%")
                  ->orWhere('ip_address', 'like', "%{$search}%");
            });
        }

        // Event filter
        if ($event = $request->input('event')) {
            $query->where('event', $event);
        }

        // Student / Parent tab filters
        $selectedClassId = null;
        $selectedSectionId = null;

        if ($isStudentParentTab) {
            $query->where(function ($q) {
                $q->whereJsonContains('properties->context->module', 'StudentPortal')
                  ->orWhereJsonContains('properties->context->module', 'ParentPortal');
            });

            $selectedClassId = $request->input('class_id');
            $selectedSectionId = $request->input('section_id');

            $classSectionId = null;
            if ($selectedClassId && $selectedSectionId) {
                $classSection = ClassSection::where('class_id', $selectedClassId)
                    ->where('section_id', $selectedSectionId)
                    ->where('is_active', true)
                    ->first();

                if ($classSection) {
                    $classSectionId = $classSection->id;
                }
            }

            // Filter logs by students currently in the selected class-section
            if ($classSectionId) {
                $studentIds = Student::whereHas('currentAcademicSession', function ($q) use ($classSectionId) {
                    $q->where('class_section_id', $classSectionId)
                      ->where('is_current', 1);
                })->pluck('id')->all();

                if (!empty($studentIds)) {
                    $query->where(function ($q) use ($studentIds) {
                        $q->whereIn(
                            DB::raw("JSON_UNQUOTE(JSON_EXTRACT(properties, '$.context.student_id'))"),
                            $studentIds
                        )->orWhere(function ($sq) {
                            // Include parent-only actions (no child context) so they still appear
                            // under the "Parent Account Activity" accordion.
                            $sq->whereJsonContains('properties->context->module', 'ParentPortal')
                               ->where(function ($ssq) {
                                   $ssq->whereNull(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(properties, '$.context.student_id'))"))
                                       ->orWhere(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(properties, '$.context.student_id'))"), '');
                               });
                        });
                    });
                } else {
                    // Class-section exists but has no current students.
                    // Still show parent-only logs if any.
                    $query->whereJsonContains('properties->context->module', 'ParentPortal')
                          ->where(function ($q) {
                              $q->whereNull(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(properties, '$.context.student_id'))"))
                                ->orWhere(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(properties, '$.context.student_id'))"), '');
                          });
                }
            }
        }

        $activityLogs = $query->paginate(25)->withQueryString();

        // Lookup maps for display
        $studentIds = $activityLogs->pluck('properties.context.student_id')
            ->filter()
            ->unique()
            ->map(fn ($id) => (int) $id)
            ->all();

        $students = $studentIds
            ? Student::whereIn('id', $studentIds)
                ->with(['currentAcademicSession.classSection.class', 'currentAcademicSession.classSection.section', 'user'])
                ->get()
                ->keyBy('id')
            : collect();

        // Dropdown data for filters
        $classes = SchoolClass::where('is_active', true)
            ->orderBy('ordinal')
            ->pluck('name', 'id');

        $sections = Section::where('is_active', true)
            ->orderBy('ordinal')
            ->pluck('name', 'id');

        return view('systemconfig::activity-log.index', compact(
            'activityLogs',
            'activeTab',
            'classes',
            'sections',
            'selectedClassId',
            'selectedSectionId',
            'students',
        ));
    }
    ```
  - **After:**
    ```php
        public function index(Request $request)
        {
            // NOT ROUTED (final-audit.md D5). No route references this controller; the live
            // `system-config/activity-log` route is served by
            // Modules\TenantCore\Http\Controllers\ActivityLogController@index (routes/tenant.php:105).
            abort(403, 'This action is not available.');
        }
    ```
  - **Verify:** `grep -n "abort(403" Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php`
  - **Expect:** one match, inside `index()`, on the abort line.
  - **Effort:** S

- [ ] **TAL-05** · H · VAL-04 · `Modules/SchoolSetup/app/Models/SchoolClass.php:41-45` — stop re-using a soft-deleted class's ordinal. ⚠ SHARED
  - **Touches:** `Modules/SchoolSetup/app/Models/SchoolClass.php`
  - **Before** (`SchoolClass.php:41-45`):
    ```php
                // Auto-adjust ordinal if it is already taken to prevent UniqueConstraintViolationException
                $existingOrdinal = static::where('ordinal', $schoolClass->ordinal)->exists();
                if ($existingOrdinal) {
                    $schoolClass->ordinal = (int) static::max('ordinal') + 1;
                }
    ```
  - **After:**
    ```php
                // VAL-04 (2026-10-17): the unique index uq_classes_ordinal is not partial, so a
                // soft-deleted class still owns its ordinal. Include trashed rows in both lookups.
                $existingOrdinal = static::withTrashed()
                    ->where('ordinal', $schoolClass->ordinal)
                    ->exists();
                if ($existingOrdinal) {
                    $schoolClass->ordinal = (int) static::withTrashed()->max('ordinal') + 1;
                }
    ```
  - **Verify:** `grep -n "withTrashed" Modules/SchoolSetup/app/Models/SchoolClass.php`
  - **Expect:** two matches, both inside `booted()`.
  - **Effort:** S

- [ ] **TAL-07** · M · CTL-10 · `Modules/SchoolSetup/app/Models/Section.php:43-46` — repair the broken `studentAcademicAessions()` relation. ⚠ SHARED
  - **Touches:** `Modules/SchoolSetup/app/Models/Section.php`
  - **Before** (`Section.php:5-8`, the imports):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\SmartTimetable\Models\ClassSubgroupMember;
    ```
  - **After:**
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\SmartTimetable\Models\ClassSubgroupMember;
    use Modules\StudentProfile\Models\StudentAcademicSession;
    ```
  - **Before** (`Section.php:43-46`, the method):
    ```php
        public function studentAcademicAessions()
        {
            return $this->hasMany(StudentAcademicSession::class, 'section_id');
        }
    ```
  - **After:**
    ```php
        public function studentAcademicSessions()
        {
            return $this->hasMany(StudentAcademicSession::class, 'section_id');
        }
    ```
  - **Verify:** `grep -n "studentAcademic\|StudentAcademicSession" Modules/SchoolSetup/app/Models/Section.php`
  - **Expect:** an import line for `StudentAcademicSession` and a method line `studentAcademicSessions()`; no line contains `Aessions`.
  - **Effort:** S

## 6. Queries & performance (F9)

None — TAL-10 and TAL-11 are removed by TAL-01 (see §10).

## 7. Views (F10)

None — F10 is clean.

## 8. Style (F12) — one item per file

None — the controller is Pint-clean and already declares `strict_types`. Model style (TAL-09) is deferred in §10.

## 9. Deferred / decisions

- [ ] **TAL-04** · L · DECISION · CTL-10 — what should happen to the orphaned SystemConfig activity-log view?
  - **Why it is a decision:** the view is used only by this unrouted controller; deleting a file is a change the protocol does not force, so Tarun chooses.
  - `Modules/SystemConfig/resources/views/activity-log/index.blade.php` is referenced only from `TenantActivityLogController.php:130`. After TAL-01 the blade can never render.
  - (a) ⭐ leave the view in place and only disable the controller (TAL-01); schedule a dead-file cleanup in a separate pass
  - (b) delete `Modules/SystemConfig/resources/views/activity-log/index.blade.php` in this pass
  - (c) keep the file and add a `{{-- DEPRECATED 2026-10-17 — orphaned by TAL-04; the live view is tenantcore::activity-log.index --}}` header
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TAL-02 | `index()` is 117 lines, but TAL-01 replaces the whole body, so the length finding disappears with it |
| TAL-03 | `index()` has no return type, but TAL-01 replaces the method; a covered method needs no return type |
| TAL-06 | `ClassSection::withTrashed()` is called by `SchoolClassController.php:1268`; removing the stubs would fatal that screen, so they stay until the schema adds `deleted_at` |
| TAL-08 | Missing relation return types across three shared models — deferred model polish, out of this controller's path |
| TAL-09 | Missing `strict_types` plus an emoji comment and a commented-out import across three shared models — deferred model polish |
| TAL-10 | Leading-wildcard `LIKE` queries live inside `index()`, which TAL-01 removes |
| TAL-11 | The shared 25-row paginator lives inside `index()`, which TAL-01 removes; a revived controller would mirror the TenantCore two-paginator fix |
