# Final Audit — SystemConfig / TenantActivityLogController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php` (140 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | This controller owns **no** URL. It is not routed. The live screen is `http://test.localhost:8000/system-config/activity-log?tab=all` and `http://test.localhost:8000/system-config/activity-log?tab=student-parent`, served by `Modules\TenantCore\Http\Controllers\ActivityLogController@index`. |
| Menu path | System Config → Activity Log (breadcrumb registry key `system-config.activity-log.index`) |
| Who uses it | Roles holding `tenant.system-config.activity-log.viewAny`. Measured in the tenant DB: **Super Admin, School Admin** (only these two). |
| What a user does here | The screen lists who did what. The "All Logs" tab shows every activity row with subject, event, user, IP and property details. The "Student & Parent" tab groups student-portal and parent-portal activity by student, with class and section filters. The page is read-only: it has no create, edit or delete. |
| Tables written | none — the controller is read-only |
| Tables read | `sys_activity_logs`, `sch_classes`, `sch_sections`, `sch_class_section_jnt`, `std_students`, `std_student_academic_sessions`, `sys_users` |
| Live data | `sys_activity_logs` 1986 rows · `sch_classes` 15 · `sch_sections` 8 · `sch_class_section_jnt` 43 · `std_students` 1824 |

**This controller is dead code.** `TenantActivityLogController` is an older copy of the screen. The live route
`system-config/activity-log` (`routes/tenant.php:105`) is wired to `Modules\TenantCore\Http\Controllers\ActivityLogController@index`,
which renders the newer view `tenantcore::activity-log.index`. Nothing references this file. Protocol decision **D5**
therefore governs the single public method: its body becomes `abort(403, ...)` with a `// NOT ROUTED` comment, and it
is not deleted.

**How to reach each bug in the browser:** listed per finding under **Reproduce**. Because the controller is unrouted,
most findings are static-only (proven with commands, not by loading the page).

## 1. Verdict

This controller is **not production code** — it is an unrouted, stale duplicate of the live TenantCore activity-log
screen, and it should be disabled with `abort(403)` (D5) rather than edited. The single worst finding is **TAL-05**:
`SchoolClass::booted()` hides soft-deleted classes when it checks the `ordinal` unique key, so re-using the ordinal of
a deleted class throws a duplicate-key 500 on a real School Setup screen. Everything the controller itself does is
read-only and clean on errors, transactions, authorization and Blade. The plan is small: one D5 disable, one model
race fix, one dead-relation fix, and one decision about the orphaned view. **Effort: S to M (under half a day).**

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 5 | 5 | 1 | 11 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | TAL-10, TAL-11 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | TAL-01 | F12 Style | TAL-09 |
| F6 Controller shape | TAL-02, TAL-03, TAL-04 | F13 Deep read | no mutating methods |
| F7 Models | TAL-05, TAL-06, TAL-07, TAL-08, TAL-09 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php` | controller | 140 | this report | ✅ |
| 2 | `Modules/SystemConfig/resources/views/activity-log/index.blade.php` | view | 393 | this report (used only by this controller) | ✅ |
| 3 | `Modules/GlobalMaster/app/Models/ActivityLog.php` | model | 50 | ↗ [tarun/GlobalMaster-done/ActivityLogController](../../GlobalMaster-done/ActivityLogController-done/01-report.md) | ↗ linked |
| 4 | `Modules/StudentProfile/app/Models/Student.php` | model | 475 | ↗ [gaurav/StudentProfile/StudentReportController](../../../gaurav/StudentProfile/StudentReportController-done/01-report.md) | ↗ linked |
| 5 | `Modules/SchoolSetup/app/Models/SchoolClass.php` | model | 94 | this report (claimed 2026-10-17) | ✅ |
| 6 | `Modules/SchoolSetup/app/Models/Section.php` | model | 60 | this report (claimed 2026-10-17) | ✅ |
| 7 | `Modules/SchoolSetup/app/Models/ClassSection.php` | model | 162 | this report (claimed 2026-10-17) | ✅ |

The view at row 2 is reachable only from this controller, so it is owned by this report. Rows 3 and 4 are owned by
other reports and only their **use** here is checked (eager loads, guard bypass). No in-scope file appears in a
module `PRE-APPLIED-*.md`.

⚠ Registry note: `00-CLASS-OWNERS.md` claims `Modules/Prime/app/Models/ActivityLog.php` under
`tarun/GlobalMaster-done/ActivityLogController`; this controller imports the different file
`Modules/GlobalMaster/app/Models/ActivityLog.php`, which has no registry row. The link above follows the
pre-decided ownership; the owner report is in progress and its scope table names only the Prime file. Recorded as a
cross-cutting note (§7).

## 4. Routes

Command (uncached, real output):

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list 2>/dev/null | grep -i TenantActivityLog
(no output — this controller has ZERO routes)

$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list 2>/dev/null | grep "system-config/activity-log"
  GET|HEAD        system-config/activity-log system-config.activity-log.index   Modules\TenantCore\Http\Controllers\ActivityLogController@index
```

The route file that registers the live screen:

```
$ grep -n "system-config/activity-log" routes/tenant.php
105:        Route::get('/activity-log', [ActivityLogController::class, 'index'])->name('activity-log.index');
```

At `routes/tenant.php` the `ActivityLogController` symbol is imported from `Modules\TenantCore\Http\Controllers`, not
from `Modules\SystemConfig`. So `system-config/activity-log` is served by the TenantCore controller and this file has
no route.

Unrouted public methods: `index()` at `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:23` (D5).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 23 | not routed (0 routes; the live route is served by TenantCore ActivityLogController) | `tenant.system-config.activity-log.viewAny` (line 25, before any load) | none — read-only | none | none (reads `sys_activity_logs`, `sch_classes`, `sch_sections`, `sch_class_section_jnt`, `std_students`) | TAL-01, TAL-02, TAL-03, TAL-10, TAL-11 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try|catch|getMessage|Log::|dd\(|dump\(|var_dump|print_r|env\(' Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php` → no output. There is no try/catch (D1 satisfied) and no exception text reaches a user.

### F2 — Transactions and audit

clean — `grep -nE '->save\(|::create\(|->update\(|->delete\(|->insert\(|updateOrCreate|firstOrCreate|activityLog' Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php` → no output. The controller performs no writes, so there is no transaction or audit row to place.

### F3 — Authorization

clean — `grep -nE 'Gate::|authorize' Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php` →

```
25:        Gate::authorize('tenant.system-config.activity-log.viewAny');
```

The gate runs on line 25, before any record is loaded (AUTH-02 satisfied). The key is declared in
`config/permissionslist.php:1703` (`'system-config.activity-log' => array_merge($crud, ['export'])`, where `$crud`
at line 176 contains `viewAny`), and it is seeded by exact name (`TenantRolePermissionSeeder` uses
`Permission::firstOrCreate(['name' => $permission, ...])`), not `LIKE`. The four-part name
`tenant.system-config.activity-log.viewAny` matches the view surfaces (view lines 6 and 7). AUTH-06 (the name
repeated as a literal) is a cross-cutting note already reported as ALC-01 in `tarun/TenantCore-done/ActivityLogController`.

### F4 — Validation and input

clean — `grep -nE 'validate\(|->all\(\)|->except\(|fill\(' Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php` → no output. There is no write path and no model input; the method only reads query-string filters with `$request->input()`, which is correct for a read-only list.

### F5 — Routes

#### TAL-01 · M · RTE-03 — the only public method is not routed; the live route is wired to a different controller

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`)* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:23`, method `index()`; wiring at `routes/tenant.php:105` |
| **Root cause** | `routes/tenant.php:105` binds the URI `system-config/activity-log` to `Modules\TenantCore\Http\Controllers\ActivityLogController@index`. This SystemConfig file is a stale duplicate that no route, config or view references, so `index()` can never be reached. |
| **Consequence** | The class is unreachable dead code today; a future developer who points the route back at it would revive the stale behaviour described in TAL-11. |
| **Reproduce** | static only — `route:list` shows zero routes for this controller (see §4). |
| **Fix approach** | Protocol D5: replace the body of `index()` with `abort(403, ...)` and a `// NOT ROUTED` comment. Do not delete the method, its imports or its now-dead private helpers. |
| **Plan item** | TAL-01 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -i TenantActivityLog` over the uncached route:list → no output; `grep -n "system-config/activity-log" routes/tenant.php` → line 105 points at TenantCore |

```php
// TenantActivityLogController.php:23-25 — CURRENT
    public function index(Request $request)
    {
        Gate::authorize('tenant.system-config.activity-log.viewAny');
```

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list 2>/dev/null | grep -i TenantActivityLog
(no output)

$ grep -n "system-config/activity-log" routes/tenant.php
105:        Route::get('/activity-log', [ActivityLogController::class, 'index'])->name('activity-log.index');
```

### F6 — Controller shape

#### TAL-02 · M · CTL-02 — `index()` is a 117-line method

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *a method over 80 lines should be extracted; over 150 lines is H* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:23-139`, method `index()` |
| **Root cause** | All search/filter building, the Student/Parent JSON filtering, the lookup maps, the dropdown queries and the view assembly live in one method with no extraction. |
| **Consequence** | A maintainer cannot read the list end-to-end; but the method is unreachable dead code and TAL-01 removes the body, so it is not fixed separately. |
| **Reproduce** | static only — `awk` line span 23 to 139 is 117 lines. |
| **Fix approach** | No separate fix: TAL-01 replaces the whole body, which removes the length. |
| **Plan item** | none — see plan §10 |
| **Evidence** | scanner reported `CTL-02 … index — index() is 117 lines`; line span confirmed by §5 | 

```php
// TenantActivityLogController.php:130-138 — CURRENT (the end of the 117-line method)
        return view('systemconfig::activity-log.index', compact(
            'activityLogs',
            'activeTab',
            'classes',
            'sections',
            'selectedClassId',
            'selectedSectionId',
            'students',
        ));
```

```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-systemconfig-scan.json Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php
M  CTL-02   Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:23  index — index() is 117 lines
```

#### TAL-03 · L · CTL-04 — `index()` has no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:23`, method `index()` |
| **Root cause** | The signature is `public function index(Request $request)` with no `: View` (the method returns `view(...)` on line 130). |
| **Consequence** | Static analysis and IDE support lose the contract; but the body is replaced by TAL-01. |
| **Reproduce** | static only — see the quoted line. |
| **Fix approach** | No separate fix: TAL-01 replaces the body; if a return type is added it would be `: never` because `abort()` never returns. Left to TAL-01. |
| **Plan item** | none — see plan §10 |
| **Evidence** | scanner reported `CTL-04 … index — index() has no return type` |

```php
// TenantActivityLogController.php:23 — CURRENT
    public function index(Request $request)
```

```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-systemconfig-scan.json Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php
L  CTL-04   Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:23  index — index() has no return type
```

#### TAL-04 · L · CTL-10 — the SystemConfig activity-log view is orphaned dead code

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M for dead code; graded L here because the file is inert and cannot render) |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:130` renders `systemconfig::activity-log.index`; the file is `Modules/SystemConfig/resources/views/activity-log/index.blade.php` |
| **Root cause** | The view is referenced only from the unrouted controller on line 130. The live TenantCore controller renders its own `tenantcore::activity-log.index`, so this SystemConfig view has no other consumer. After TAL-01 disables the controller, the blade can never render. |
| **Consequence** | A duplicate 393-line view stays in the tree and can drift from the live one; no user is affected. |
| **Reproduce** | static only — `grep -rn "systemconfig::activity-log"` finds only this controller. |
| **Fix approach** | Decision item TAL-04 in `02-fix-plan.md` §9 (leave, delete, or mark deprecated). |
| **Plan item** | TAL-04 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `grep -rn "systemconfig::activity-log"` → only `TenantActivityLogController.php:130` |

```php
// TenantActivityLogController.php:130 — the only consumer of the view
        return view('systemconfig::activity-log.index', compact(
```

```
$ grep -rn "systemconfig::activity-log" Modules app routes
Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:130:        return view('systemconfig::activity-log.index', compact(
```

### F7 — Models

#### TAL-05 · H · VAL-04 — `SchoolClass` hides soft-deleted rows when it checks the unique `ordinal`, so re-using a deleted class's ordinal throws a duplicate-key 500

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness logic must mirror the DB unique index including soft-delete semantics* |
| **Where** | `Modules/SchoolSetup/app/Models/SchoolClass.php:41-45`, inside `booted()`; index at `database/migrations/tenant/2026_06_15_145401_create_sch_classes_table.php:32` |
| **Root cause** | `static::where('ordinal', ...)->exists()` and `static::max('ordinal')` run under the `SoftDeletes` global scope, which excludes trashed rows. The unique index `uq_classes_ordinal` is not partial and covers trashed rows too. A trashed class still owns its ordinal, but the guard cannot see it, so the adjust never fires and the INSERT collides. |
| **Consequence** | An admin who deletes a class and then adds a new one with that ordinal gets a 500 (duplicate key) instead of a saved class. |
| **Reproduce** | static only — requires a create through the School Setup screen, which is outside this controller; the collision is proven by the migration's non-partial unique index at line 32. |
| **Fix approach** | Include trashed rows with `withTrashed()` in both the `exists()` check and the `max()` lookup. |
| **Plan item** | TAL-05 in `02-fix-plan.md` §5 |
| **Evidence** | migration line 26 `softDeletes()` + line 32 `unique('ordinal', 'uq_classes_ordinal')`; model lines 41-45 use the default scoped query |

```php
// SchoolClass.php:41-45 — CURRENT
            // Auto-adjust ordinal if it is already taken to prevent UniqueConstraintViolationException
            $existingOrdinal = static::where('ordinal', $schoolClass->ordinal)->exists();
            if ($existingOrdinal) {
                $schoolClass->ordinal = (int) static::max('ordinal') + 1;
            }
```

```
$ grep -n "uq_classes_ordinal\|softDeletes" database/migrations/tenant/2026_06_15_145401_create_sch_classes_table.php
26:            $table->softDeletes();
32:            $table->unique('ordinal', 'uq_classes_ordinal');
```

#### TAL-06 · L · CTL-10 — `ClassSection` carries hand-written `withTrashed()` / `onlyTrashed()` stubs

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M for dead code; graded L here because callers depend on one of the two) |
| **Where** | `Modules/SchoolSetup/app/Models/ClassSection.php:133-147` |
| **Root cause** | The table `sch_class_section_jnt` has no `deleted_at` column and the model has no `SoftDeletes` trait (imports at lines 3-7, class `use HasFactory;` at line 11). The two static methods are hand-written stand-ins: `onlyTrashed()` always returns zero rows and `withTrashed()` behaves as an ordinary query. |
| **Consequence** | The API is misleading, but `Modules/SchoolSetup/app/Http/Controllers/SchoolClassController.php:1268` calls `ClassSection::withTrashed()`, so deleting the stubs would fatal that screen. They must stay until the schema changes. |
| **Reproduce** | static only — the caller at `SchoolClassController.php:1268` is quoted in the evidence. |
| **Fix approach** | Leave in place; removing them needs a schema-level decision (add `deleted_at` or change the caller first). |
| **Plan item** | none — see plan §10 |
| **Evidence** | caller grep: `ClassSection::withTrashed()` used at `SchoolClassController.php:1268`; no `deleted_at` in the migration |

```php
// ClassSection.php:133-147 — CURRENT
    /**
     * Fake withTrashed to prevent BadMethodCallException in tests.
     */
    public static function withTrashed()
    {
        return static::query();
    }

    /**
     * Fake onlyTrashed to prevent BadMethodCallException in tests.
     */
    public static function onlyTrashed()
    {
        return static::query()->whereRaw('1 = 0');
    }
```

```
$ grep -rn "ClassSection::withTrashed\|ClassSection::onlyTrashed" Modules app
Modules/SchoolSetup/app/Http/Controllers/SchoolClassController.php:1268:        $sectionIds = ClassSection::withTrashed()->where('class_id', $classId)->pluck('id')->all();
```

#### TAL-07 · M · CTL-10 — `Section`'s `studentAcademicAessions()` relation is misspelled and references a class that does not exist

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: the method cannot run and no consumer reads it* |
| **Where** | `Modules/SchoolSetup/app/Models/Section.php:43-46`, method `studentAcademicAessions()` |
| **Root cause** | The method name is misspelled (`Aessions`) and the class `StudentAcademicSession` is not imported, so it resolves to `Modules\SchoolSetup\Models\StudentAcademicSession`, which does not exist (`class_exists` returned `false`; the real class is `Modules\StudentProfile\Models\StudentAcademicSession`). |
| **Consequence** | Any future call to `$section->studentAcademicAessions` throws "Class not found"; today no screen calls it, so the fault is latent. A developer who reads the method believes a working relation exists. |
| **Reproduce** | static only — `class_exists("Modules\\SchoolSetup\\Models\\StudentAcademicSession")` prints `bool(false)`. |
| **Fix approach** | Add the `StudentAcademicSession` import and rename the method to `studentAcademicSessions()` (no callers exist, so the rename is safe). |
| **Plan item** | TAL-07 in `02-fix-plan.md` §5 |
| **Evidence** | `class_exists` false; `grep -rn "studentAcademicAessions"` finds only the definition; `Section.php` imports list lacks the class |

```php
// Section.php:43-46 — CURRENT
    public function studentAcademicAessions()
    {
        return $this->hasMany(StudentAcademicSession::class, 'section_id');
    }
```

```
$ php artisan tinker --execute 'var_dump(class_exists("Modules\\SchoolSetup\\Models\\StudentAcademicSession"));'
bool(false)

$ grep -rn "studentAcademicAessions" Modules app | grep -v final-audit-reports
Modules/SchoolSetup/app/Models/Section.php:43:    public function studentAcademicAessions()
```

#### TAL-08 · L · MDL-04 — relation methods on the three claimed models have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods are return-typed (`: BelongsTo`, `: HasMany`)* |
| **Where** | `Modules/SchoolSetup/app/Models/SchoolClass.php:57-90`, `Modules/SchoolSetup/app/Models/Section.php:38-54`, `Modules/SchoolSetup/app/Models/ClassSection.php:49-82` |
| **Root cause** | Every `hasMany` / `belongsTo` / `hasManyThrough` in the three models returns without a declared type. |
| **Consequence** | Static analysis and IDE completion lose the contract on shared models; runtime behaviour is unaffected. |
| **Reproduce** | static only — scanner lines below. |
| **Fix approach** | Add return types when the models are next touched; deferred here because it touches three shared files and the controller is dead. |
| **Plan item** | none — see plan §10 |
| **Evidence** | scanner reported 16 `MDL-04` rows across the three models |

```php
// SchoolClass.php:57-60 — CURRENT (one representative relation)
    public function classSections()
    {
        return $this->hasMany(ClassSection::class, 'class_id');
    }
```

```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-systemconfig-scan.json Modules/SchoolSetup/app/Models/SchoolClass.php
L  MDL-04   Modules/SchoolSetup/app/Models/SchoolClass.php:57  classSections — relation classSections() has no return type
L  MDL-04   Modules/SchoolSetup/app/Models/SchoolClass.php:62  subjectGroups — relation subjectGroups() has no return type
L  MDL-04   Modules/SchoolSetup/app/Models/SchoolClass.php:67  subjectStudyFormatClasses — relation subjectStudyFormatClasses() has no return type
L  MDL-04   Modules/SchoolSetup/app/Models/SchoolClass.php:72  studentAcademicSessions — relation studentAcademicSessions() has no return type
L  MDL-04   Modules/SchoolSetup/app/Models/SchoolClass.php:84  classSubgroupMembers — relation classSubgroupMembers() has no return type
```

#### TAL-09 · L · STY-01 — the three claimed models miss `strict_types`; `ClassSection` carries an emoji comment and `SchoolClass` a commented-out import

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files*, and STY-04 (L) — *no emoji markers, no commented-out code* |
| **Where** | `Modules/SchoolSetup/app/Models/ClassSection.php:1` (strict_types) and `:74` (emoji comment); `Modules/SchoolSetup/app/Models/SchoolClass.php:1` (strict_types) and `:9` (commented-out import); `Modules/SchoolSetup/app/Models/Section.php:1` (strict_types) |
| **Root cause** | None of the three models declares `strict_types`; `ClassSection.php:74` has the comment `// ✅ fixed method name`; `SchoolClass.php:9` has the commented-out factory import `// use Modules\SchoolSetup\Database\Factories\SchoolClassFactory;`. |
| **Consequence** | Style inconsistency on shared models; no runtime effect. |
| **Reproduce** | static only — scanner rows below. |
| **Fix approach** | Add `declare(strict_types=1);` and remove the emoji and commented-out line when the models are next touched; deferred (three shared files). |
| **Plan item** | none — see plan §10 |
| **Evidence** | scanner reported `STY-01` for all three headers and `STY-04` for `ClassSection.php:74` |

```php
// ClassSection.php:74 — CURRENT
    public function classHouseRoom()   // ✅ fixed method name
```

```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-systemconfig-scan.json Modules/SchoolSetup/app/Models/ClassSection.php
L  STY-01   Modules/SchoolSetup/app/Models/ClassSection.php:1  - — missing declare(strict_types=1)
L  STY-04   Modules/SchoolSetup/app/Models/ClassSection.php:74  - — emoji in comment
```

### F8 — Services and jobs

clean — `grep -nE 'Service|Job|Event|dispatch|queue' Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php` → no output. The controller injects no service and dispatches nothing.

### F9 — Queries and performance

#### TAL-10 · M · QRY-08 — three leading-wildcard `LIKE` searches on the activity-log table

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M) — *leading-wildcard `LIKE '%x%'` cannot use an index* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:34-38`, method `index()` |
| **Root cause** | The global search builds `where('subject_type', 'like', "%{$search}%")` and two siblings, each scanning the whole `sys_activity_logs` table. |
| **Consequence** | Search on a table of 1986 rows (growing) does a full scan in the dead copy; the live TenantCore screen uses its own query, so no user sees this. |
| **Reproduce** | static only — the code is unreachable (TAL-01). |
| **Fix approach** | No separate fix: TAL-01 replaces the body, removing these queries. |
| **Plan item** | none — see plan §10 |
| **Evidence** | scanner reported `QRY-08 … 3 leading-wildcard LIKE search(es)` at line 35 |

```php
// TenantActivityLogController.php:34-38 — CURRENT
            $query->where(function ($q) use ($search) {
                $q->where('subject_type', 'like', "%{$search}%")
                  ->orWhere('event', 'like', "%{$search}%")
                  ->orWhere('ip_address', 'like', "%{$search}%");
            });
```

```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-systemconfig-scan.json Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php
L  QRY-08   Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:35  index — 3 leading-wildcard LIKE search(es)
```

#### TAL-11 · M · QRY-13 — one 25-row paginator feeds both client-side tabs

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L, raised to M because it shows wrong rows, not just a style gap) — *filtered paginators keep filters; each list has a distinct page name* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php:105`, method `index()` |
| **Root cause** | `$query->paginate(25)` builds a single paginator used by both the All Logs pane and the Student & Parent pane. The tab strip switches client-side, so neither pane re-runs the controller. The page size is 25, not the house 10. |
| **Consequence** | Landing on `?tab=all` and clicking "Student & Parent" shows only the student/parent rows that happen to sit on the current all-logs page (frequently empty). The live TenantCore controller already fixed exactly this with two paginators and page keys. |
| **Reproduce** | static only — the page is served by the TenantCore controller, not this one. |
| **Fix approach** | No separate fix: TAL-01 replaces the body. If the controller were ever revived, it would need two paginators with distinct page names, mirroring TenantCore. |
| **Plan item** | none — see plan §10 |
| **Evidence** | source line 105 quoted below; the TenantCore fix is documented in `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php` header (AL-01) |

```php
// TenantActivityLogController.php:105 — CURRENT
        $activityLogs = $query->paginate(25)->withQueryString();
```

```
$ grep -n "paginate(25)" Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php
105:        $activityLogs = $query->paginate(25)->withQueryString();
```

### F10 — Views

clean — `grep -nE '\{!!|Model::|DB::|->where\(|->get\(\)' Modules/SystemConfig/resources/views/activity-log/index.blade.php` → no output. The only dynamic calls are `->count()` on already-loaded collections (lines 227 and 332), not queries. The nested relations `currentAcademicSession.classSection.class` and `.section` used inside the accordion are eager-loaded by the controller (`with([...])` on line 116), so there is no N+1 (VIEW-02). No `{!! !!}` is used (VIEW-03 clean). See TAL-04 for the view being orphaned.

### F11 — Security and tenancy

clean — `grep -nE 'env\(|Log::|\?\? 1|tenant_asset|asset\(' Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php` → no output. No `env()` outside config, no hard-coded ids, no secrets logged, no file URLs. The queries run through the tenant connection because the controller is tenant-scoped.

### F12 — Style

The controller is clean — `grep -n "declare(strict_types=1)" Modules/SystemConfig/app/Http/Controllers/TenantActivityLogController.php` → `3:declare(strict_types=1);`. Model-level style is captured in TAL-09.

### F13 — Deep read (answer all 8 questions for every mutating method)

There are **no mutating methods** in this controller, so the eight-question table has no rows. `index()` is read-only: it reads `sys_activity_logs`, `sch_classes`, `sch_sections`, `sch_class_section_jnt` and `std_students` and writes nothing.

| Mutating method | 1 wrong data | 2 delete-before-store | 3 duplicate impl | 4 soft-delete×unique | 5 race | 6 authz hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| (none — read-only) | — | — | TAL-01/TAL-04 | TAL-05 | TAL-05 | ok | — | TAL-11 |

Note: question 3 (duplicate implementation) and question 8 (dead feature) are answered by the class-level findings TAL-01/TAL-04 and TAL-11 even though there is no mutation.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/GlobalMaster/app/Models/ActivityLog.php` | Registry row claims `Modules/Prime/app/Models/ActivityLog.php` under `tarun/GlobalMaster-done/ActivityLogController`, but this controller uses the GlobalMaster file, which has no registry row. The relation `user()` picks `Modules\SchoolSetup\Models\User` or `Modules\Prime\Models\User` by `tenancy()->initialized` with no return type. | MDL-04, registry | `tarun/GlobalMaster-done/ActivityLogController` (in progress) |
| `Modules/StudentProfile/app/Models/Student.php` | Scanner rows in the linked class, including `TEN-04` at line 403 (`asset('storage/…')` instead of `tenant_asset()`). | TEN-04, MDL-04 | `gaurav/StudentProfile/StudentReportController` (linked) |
| permission literal `tenant.system-config.activity-log.viewAny` | Repeated as a raw string in the controller and both views (this file and the live TenantCore one) with no constant or policy. | AUTH-06 | `tarun/TenantCore-done/ActivityLogController` (already reported as ALC-01) |
| duplicate screen controller | `Modules/TenantCore/Http/Controllers/ActivityLogController` serves the same screen and is the live one; this is the stale twin. | SVC-04 | this report (TAL-01/TAL-04) |
| `SchoolClass` / `Section` | Both tables carry a non-partial unique index on `ordinal`; `SchoolClass::booted()` is the only place that tries to guard it, and it does so against the soft-deleted set. `Section` has no such guard at all. | VAL-04 | this report (TAL-05) |

## 8. Not covered, and why

- **The live screen was not loaded.** The route is served by the TenantCore controller, which is a different audit
  (`tarun/TenantCore-done/ActivityLogController`). This report checks only the dead SystemConfig copy.
- **The three claimed models were not exercised at runtime** beyond `class_exists` and a read-only `SELECT` count.
  TAL-05 is proven from the migration index plus the model's scoped query, not by performing a create (D4).
- **Per-role permission rows** were read as a `SELECT` (`Super Admin`, `School Admin`); the tenant DB held the
  expected two roles.
- **The blade was not rendered** (it cannot be, because the controller is unrouted). VIEW checks are static.
