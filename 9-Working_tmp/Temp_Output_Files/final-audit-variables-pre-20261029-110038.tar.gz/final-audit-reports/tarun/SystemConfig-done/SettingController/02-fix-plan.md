# Fix Plan — SystemConfig / SettingController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SystemConfig/app/Http/Controllers/SettingController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SystemConfig/resources/views/setting/partials/_settings.blade.php` | shared blade (rendered by the standalone page and the School Config tab); no item edits it |
| `Modules/SystemConfig/resources/views/setting/index.blade.php` | view; no item edits it |
| `Modules/SystemConfig/resources/views/setting/edit.blade.php` | view; only the SET-12 decision may remove it |
| `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php` | separate controller, separate report |
| `Modules/Prime/app/Policies/PrimeSettingPolicy.php` | another module |
| `config/permissionslist.php` | shared; no change required |
| `database/migrations/tenant/2026_06_17_150000_create_sys_settings_table.php` | existing migration — never edited |

## 1. Blockers reachable today

_None — there are no B-severity findings._

## 2. Fixes that arm a latent defect (sequenced)

_None._

## 3. Errors & transactions (F1/F2)

- [ ] **SET-01** · M · ERR-00 (D1) · `Modules/SystemConfig/app/Http/Controllers/SettingController.php:82-132` — remove the controller `try/catch`, move the row load and validation out of the transaction, and build the response after the transaction commits.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/SettingController.php`
  - **Before** (`SettingController.php:82-132`):
    ```php
            try {
                return DB::transaction(function () use ($request, $id) {
                    $setting = Setting::findOrFail($id);

                    $validated = $request->validate([
                        'value' => ['required', 'string', 'max:1000'],
                    ]);

                    $setting->update(['value' => $validated['value']]);

                    activityLog($setting, 'updated', ['key' => $setting->key]);

                    // The App Level Settings tab edits a value in place and posts here with
                    // Accept: application/json. Answering with a redirect would make fetch()
                    // follow it and re-issue the PUT against a GET-only index — a 405 the
                    // caller reads as "the save failed" (test-creation.md §15 #14).
                    if ($request->wantsJson()) {
                        return response()->json([
                            'success' => true,
                            'message' => 'Setting updated successfully.',
                            'value'   => $setting->value,
                        ]);
                    }

                    return redirect()->route('system-config.setting.index')
                        ->with('success', 'Setting updated successfully.');

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (ValidationException $e) {
                // Same reasoning, second instance: ValidationException is a Throwable, so the
                // generic catch below was turning "the value field is required" into the
                // catch-all "The operation could not be completed." — for every caller, since
                // this was here before the inline editor. Re-thrown, bootstrap/app.php renders
                // it as 422 {"errors":{...}} for JSON and as a normal error bag for the form.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('SettingController::update failed', ['error' => $e->getMessage()]);

                if ($request->wantsJson()) {
                    return response()->json([
                        'success' => false,
                        'message' => 'The operation could not be completed.',
                    ], 500);
                }

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
    Note: the lines above are the body of `update()` from the first `try {` to the closing `}` of the last catch. Replace the whole span; do not keep any `try`, `catch` or `Log::error`.
  - **After:**
    ```php
        Gate::authorize('tenant.system-config.setting.update');

        $setting = Setting::findOrFail($id);

        $validated = $request->validate([
            'value' => ['required', 'string', 'max:1000'],
        ]);

        DB::transaction(function () use ($setting, $validated) {
            $setting->update(['value' => $validated['value']]);

            activityLog($setting, 'updated', ['key' => $setting->key]);
        });

        // The App Level Settings tab edits a value in place and posts here with
        // Accept: application/json. Answering with a redirect would make fetch()
        // follow it and re-issue the PUT against a GET-only index — a 405 the
        // caller reads as "the save failed" (test-creation.md §15 #14).
        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Setting updated successfully.',
                'value'   => $setting->value,
            ]);
        }

        return redirect()->route('system-config.setting.index')
            ->with('success', 'Setting updated successfully.');
    ```
    The `Gate::authorize` line above replaces the `try {` line; the final `}` of the method closes after the redirect. `DB::transaction` no longer `return`s anything, so the `ModelNotFoundException`/`ValidationException` re-throws are no longer needed — the central handler renders them.
  - **Imports to delete** (`SettingController.php:7-10`) — after the change these classes are no longer referenced anywhere in the file:
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;

    use Illuminate\Validation\ValidationException;

    use Illuminate\Support\Facades\Log;
    ```
  - **Verify:** `grep -n "try {\|catch (\|Log::error" Modules/SystemConfig/app/Http/Controllers/SettingController.php`
  - **Expect:** no output.
  - **Effort:** M

## 4. Authorization (F3)

_No item — see SET-04 in §10 (accepted)._

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **SET-06** · M · VAL-05 · `Modules/SystemConfig/app/Http/Controllers/SettingController.php:28` — stop an array query value from reaching the typed `listQuery()` arguments.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/SettingController.php`
  - **Before** (`SettingController.php:24-33`):
    ```php
        public function index(Request $request)
        {
            Gate::authorize('tenant.system-config.setting.viewAny');

            $settings = self::listQuery($request->input('search'), $request->input('type'))
                ->paginate(20)
                ->withQueryString();

            return view('systemconfig::setting.index', compact('settings'));
        }
    ```
  - **After:**
    ```php
        public function index(Request $request)
        {
            Gate::authorize('tenant.system-config.setting.viewAny');

            $search = $request->input('search');
            $type = $request->input('type');

            $settings = self::listQuery(
                is_string($search) ? $search : null,
                is_string($type) ? $type : null,
            )->paginate(20)->withQueryString();

            return view('systemconfig::setting.index', compact('settings'));
        }
    ```
  - **Verify:** `grep -n "is_string(\$search)" Modules/SystemConfig/app/Http/Controllers/SettingController.php`
  - **Expect:** one line: `is_string($search) ? $search : null,`
  - **Effort:** S

- [ ] **SET-09** · M · MDL-02 · `Modules/SystemConfig/app/Models/Setting.php:13-22` — cast `is_public` to boolean.
  - **Touches:** `Modules/SystemConfig/app/Models/Setting.php`
  - **Before** (`Setting.php:13-22`):
    ```php
        protected $table = 'sys_settings';
        /**
         * The attributes that are mass assignable.
         */
        protected $fillable = [
            'key',
            'value',
            'type',
            'is_public',
        ];
    ```
  - **After:**
    ```php
        protected $table = 'sys_settings';

        /**
         * The attributes that should be cast.
         *
         * @var array<string, string>
         */
        protected $casts = [
            'is_public' => 'boolean',
        ];

        /**
         * The attributes that are mass assignable.
         */
        protected $fillable = [
            'key',
            'value',
            'type',
            'is_public',
        ];
    ```
  - **Verify:** `grep -n "'is_public' => 'boolean'" Modules/SystemConfig/app/Models/Setting.php`
  - **Expect:** one line: `'is_public' => 'boolean',`
  - **Effort:** S

## 6. Queries & performance (F9)

_No item — see SET-10 in §10 (accepted)._

## 7. Views (F10)

_No findings._

## 8. Style (F12) — one item per file

- [ ] **SET-11** · L · STY-01 / STY-02 · `Modules/SystemConfig/app/Models/Setting.php:1` — add `strict_types` and run Pint on both files.
  - **Touches:** `Modules/SystemConfig/app/Models/Setting.php`, `Modules/SystemConfig/app/Http/Controllers/SettingController.php`
  - **Before** (`Setting.php:1-3`):
    ```php
    <?php

    namespace Modules\SystemConfig\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SystemConfig\Models;
    ```
    Then run `vendor/bin/pint Modules/SystemConfig/app/Models/Setting.php Modules/SystemConfig/app/Http/Controllers/SettingController.php --format agent` and accept its formatting changes to these two files only.
  - **Verify:** `vendor/bin/pint --test Modules/SystemConfig/app/Models/Setting.php Modules/SystemConfig/app/Http/Controllers/SettingController.php`
  - **Expect:** no files listed (pint passes). Run the Pint command AFTER the SET-01/SET-06 method items so their new code is reformatted too.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **SET-12** · L · DECISION · CTL-10 — the `/system-config/setting/{setting}/edit` page is reachable only by typing its URL; nothing in the UI links to it since the inline double-click editor replaced the per-row Edit button (2026-08-24). What should happen to it?
  - **Why it is a decision:** removing it changes routes (and D3 keeps routes/URLs in place), and keeping it leaves dead surface.
  - (a) ⭐ **Keep as is** — the route and page stay available for direct/bookmarked access; record CTL-10 as accepted. No file changes.
  - (b) **Remove it** — drop `'edit'` from the resource's `only()` list in `routes/tenant.php`, remove `edit()` from the controller, and delete `resources/views/setting/edit.blade.php`. Touches a shared route file.
  - (c) **Re-link it** — add an Edit action back to the list so the page is used again (touches the shared partial `_settings.blade.php`).
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| SET-02 | Removed by the SET-01 item — deleting the catch deletes this `Log::error` line, and the central handler then logs the exception object with its trace. |
| SET-03 | Resolved by the SET-01 item — the response is built after the `DB::transaction` closure. |
| SET-04 | Accepted — the permission literal is repeated as house convention across the module; extracting a constant would also touch the shared Blade partial. |
| SET-05 | Accepted — the endpoint's only writable field is `value` and it has an AJAX path, which is the documented one-field exception to VAL-02. |
| SET-07 | Accepted — the controller authorizes before loading the row (AUTH-02-safe); switching to route model binding would load the row first, and the name mismatch is cosmetic for a single-parameter route. |
| SET-08 | Deferred — optional return types; adding them needs new imports that would overlap the SET-01 import edit, so it is left out of this pass. |
| SET-10 | Accepted — `sys_settings` holds 6 rows, so the leading-wildcard `LIKE` has no measurable cost. |
