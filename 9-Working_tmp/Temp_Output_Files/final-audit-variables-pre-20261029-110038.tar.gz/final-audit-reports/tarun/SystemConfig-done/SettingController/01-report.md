# Final Audit — SystemConfig / SettingController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SystemConfig/app/Http/Controllers/SettingController.php` (134 lines, 4 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /system-config/setting` (list) · `GET /system-config/setting/{setting}/edit` (edit form) · `PUT /system-config/setting/{setting}` (save; the inline editor sends `Accept: application/json`) |
| Menu path | System Config → School Config → **App Level Settings** tab; the same list is also its own page at `/system-config/setting` |
| Who uses it | Roles that hold the permission, measured on the test tenant: **Super Admin** and **School Admin** (both hold `tenant.system-config.setting.viewAny` and `tenant.system-config.setting.update`) |
| What a user does here | A school admin opens App Level Settings and changes the stored value of a seeded setting — Default Language, Default Theme, School Logo URL, Contact Email, Maintenance Mode. They either double-click a value cell (inline save over `fetch`) or open the edit page and submit the form. Settings are seeded; users never create or delete them. |
| Tables written | `sys_settings` (the value) and `sys_activity_logs` (the audit row written by the `activityLog()` helper) |
| Tables read | `sys_settings`; the permission tables `sys_permissions` and `sys_role_has_permissions_jnt` are read by the `Gate::authorize` calls |
| Live data | `sys_settings` — **6 rows** (test tenant `xyz_school_00000000000040008000_202627`). The table has no `deleted_at`, so there are no trashed rows. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **close to production-ready**, but not yet: it carries a Variant-H `try/catch` in `update()` that D1 forbids, and the catch logs only `$e->getMessage()` so a real server failure leaves no stack trace. There are no Blockers and no High findings — no data loss, no security hole, and no crash on a normal path. The worst finding is **SET-01** (the controller `try/catch` wrapper, D1/ERR-00), which also hides two smaller issues (the lost trace and the HTTP response built inside the transaction). Fixing the plan is small: two code items, one model item and one style item, roughly **2–3 hours** for a developer who has not seen the file.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 5 | 7 | 1 | 12 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | SET-01, SET-02 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | SET-03 | F9 Queries/Perf | SET-10 |
| F3 Authorization | SET-04 | F10 Views | clean |
| F4 Validation | SET-05, SET-06 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | SET-11 |
| F6 Controller shape | SET-07, SET-08 | F13 Deep read | SET-12 |
| F7 Models | SET-09 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SystemConfig/app/Http/Controllers/SettingController.php` | controller | 134 | this report | ✅ |
| 2 | `Modules/SystemConfig/app/Models/Setting.php` | model | 38 | this report | ✅ |
| 3 | `Modules/SystemConfig/resources/views/setting/index.blade.php` | blade | 8 | this report | ✅ |
| 4 | `Modules/SystemConfig/resources/views/setting/edit.blade.php` | blade | 47 | this report | ✅ |
| 5 | `Modules/SystemConfig/resources/views/setting/partials/_settings.blade.php` | blade | 292 | this report | ✅ |
| 6 | `routes/tenant.php` (the `setting` resource at lines 118-120) | route file | — | shared | ❌ not a class |
| 7 | `app/Helpers/activityLog.php` | app helper | 51 | common (§4.2) | ❌ common |
| 8 | `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php` | controller (second caller of `listQuery`) | 91 | ↗ its own report | ↗ linked |

No pre-applied files: there is no `PRE-APPLIED-*.md` for SystemConfig.

## 4. Routes

```
GET|HEAD   system-config/setting                  system-config.setting.index    Modules\SystemConfig\Http\Controllers\SettingController@index
PUT|PATCH  system-config/setting/{setting}        system-config.setting.update   Modules\SystemConfig\Http\Controllers\SettingController@update
GET|HEAD   system-config/setting/{setting}/edit   system-config.setting.edit     Modules\SystemConfig\Http\Controllers\SettingController@edit
```

The three routes come from `Route::resource('setting', SettingController::class)->only(['index', 'edit', 'update'])` inside the tenant middleware group (`web`, `InitializeTenancyByDomain`, `SetTenantAuthGuard`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, then `auth`, `verified`).

Unrouted public methods: `listQuery` at `SettingController.php:44` — a `public static` query-builder helper, not an HTTP action. It is called by this controller's `index` (`SettingController.php:28`) and by `SchoolConfigController.php:62`, so it is deliberate and D5 does not apply (turning it into `abort(403)` would break School Config). Not a finding.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 24 | GET /system-config/setting | `tenant.system-config.setting.viewAny` | none (read) | none | none | SET-06, SET-08 |
| `listQuery` | 44 | not routed — shared helper | n/a | none | none | none | SET-08 |
| `edit` | 66 | GET /system-config/setting/{setting}/edit | `tenant.system-config.setting.update` | none | none | none | SET-07, SET-08 |
| `update` | 78 | PUT /system-config/setting/{setting} | `tenant.system-config.setting.update` | controller (`DB::transaction`) | `'updated'` | `sys_settings`, `sys_activity_logs` | SET-01, SET-02, SET-03, SET-08 |

## 6. Findings

### F1 — Errors

#### SET-01 · M · ERR-00 (D1) — the controller wraps `update()` in a Variant-H try/catch

| Field | Value |
|---|---|
| **Rule** | ERR-00 (D1) — *the Laravel idiom: no try/catch in controllers; a controller try/catch is a finding unless D2 allows it* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SettingController.php:82-132`, method `update()` |
| **Root cause** | The method was written to house rule A1 (Variant H: catch everything and render a page-specific message). D1 settled the Laravel idiom instead. The two re-throw catches (`ModelNotFoundException`, `ValidationException`) are not one of the D2 allowed shapes either — D2 allows `\DomainException`, a truncate-rebuild catch, `SnapshotProtectionException`, and services using `report($e)`. |
| **Consequence** | A real server failure inside the write is caught and turned into a redirect (`back()->with('error', ...)`) or a fixed 500 JSON body, instead of the central handler in `bootstrap/app.php` logging the exception with its trace and rendering the standard error page. The extra catch-all is also the place the trace is lost (SET-02). |
| **Reproduce** | static only — the catch only runs when the write fails; the effect is on the error path, not a normal click. |
| **Fix approach** | Delete the whole `try/catch`. Keep `Gate::authorize`, then `findOrFail`, then `validate`, then one `DB::transaction` for the write and the audit row, and build the response **after** the transaction. See the SET-01 item in `02-fix-plan.md` §3. |
| **Plan item** | SET-01 in `02-fix-plan.md` §3 |

```php
// SettingController.php:82-132 — CURRENT
        try {
            return DB::transaction(function () use ($request, $id) {
                $setting = Setting::findOrFail($id);

                $validated = $request->validate([
                    'value' => ['required', 'string', 'max:1000'],
                ]);

                $setting->update(['value' => $validated['value']]);

                activityLog($setting, 'updated', ['key' => $setting->key]);

                // The App Level Settings tab edits a value in place and posts here with
                // Accept: application/json. Answering with a redirect would make fetch()
                // follow it and re-issue the PUT against a GET-only index — a 405 the
                // caller reads as "the save failed" (test-creation.md §15 #14).
                if ($request->wantsJson()) {
                    return response()->json([
                        'success' => true,
                        'message' => 'Setting updated successfully.',
                        'value'   => $setting->value,
                    ]);
                }

                return redirect()->route('system-config.setting.index')
                    ->with('success', 'Setting updated successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (ValidationException $e) {
            // Same reasoning, second instance: ValidationException is a Throwable, so the
            // generic catch below was turning "the value field is required" into the
            // catch-all "The operation could not be completed." — for every caller, since
            // this was here before the inline editor. Re-thrown, bootstrap/app.php renders
            // it as 422 {"errors":{...}} for JSON and as a normal error bag for the form.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('SettingController::update failed', ['error' => $e->getMessage()]);

            if ($request->wantsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'The operation could not be completed.',
                ], 500);
            }

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "try {\|catch (\|Log::error" Modules/SystemConfig/app/Http/Controllers/SettingController.php
82:        try {
110:        } catch (ModelNotFoundException $e) {
114:        } catch (ValidationException $e) {
121:        } catch (\Throwable $e) {
122:            Log::error('SettingController::update failed', ['error' => $e->getMessage()]);
```

#### SET-02 · M · ERR-05 — the catch logs only the message, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception object (`report($e)` / `Log::error('…', ['exception' => $e])`); `getMessage()` alone loses the trace* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SettingController.php:122`, method `update()` |
| **Root cause** | The generic catch calls `Log::error(..., ['error' => $e->getMessage()])`, which stores only the text. The stack trace, the exception class and the file/line are not recorded. |
| **Consequence** | When a save fails on the JSON path (500) an operator finds one line in the log with a message but no trace, so the failure cannot be diagnosed without reproducing it. |
| **Reproduce** | static only — visible by reading the log line; the log entry is produced only on a failed write. |
| **Fix approach** | This line is deleted together with the catch in SET-01; the central handler logs the exception object. No separate edit. |
| **Plan item** | none — the SET-01 item deletes this catch and its log line (see `02-fix-plan.md` §10) |

```php
// SettingController.php:122 — CURRENT
            Log::error('SettingController::update failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/SystemConfig/app/Http/Controllers/SettingController.php
122:            Log::error('SettingController::update failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### SET-03 · M · TXN-05 — the HTTP response is built inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build `redirect()` / `response()` after it* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SettingController.php:83-107`, method `update()` |
| **Root cause** | The `DB::transaction` closure `return`s the `response()->json(...)` or `redirect()->route(...)` directly. The closure is meant to return data; the response should be built after the transaction has committed. |
| **Consequence** | The database transaction stays open while the response object — including the JSON serialisation of the value — is built, holding the connection longer than needed. It is also the shape D1 removes. |
| **Reproduce** | static only — a transaction-scope issue, not visible in the browser. |
| **Fix approach** | The closure returns nothing (it writes and audits); the `if ($request->wantsJson())` block moves after the `DB::transaction` call. Done as part of the SET-01 rewrite. |
| **Plan item** | none — resolved by the SET-01 item (see `02-fix-plan.md` §10) |

```php
// SettingController.php:94-107 — CURRENT (inside the transaction closure)
                // The App Level Settings tab edits a value in place and posts here with
                // Accept: application/json. Answering with a redirect would make fetch()
                // follow it and re-issue the PUT against a GET-only index — a 405 the
                // caller reads as "the save failed" (test-creation.md §15 #14).
                if ($request->wantsJson()) {
                    return response()->json([
                        'success' => true,
                        'message' => 'Setting updated successfully.',
                        'value'   => $setting->value,
                    ]);
                }

                return redirect()->route('system-config.setting.index')
                    ->with('success', 'Setting updated successfully.');
```

**Evidence**
```
$ grep -n "DB::transaction\|wantsJson\|redirect()->route" Modules/SystemConfig/app/Http/Controllers/SettingController.php
83:            return DB::transaction(function () use ($request, $id) {
98:                if ($request->wantsJson()) {
106:                return redirect()->route('system-config.setting.index')
124:            if ($request->wantsJson()) {
```

### F3 — Authorization

The gate names match `config/permissionslist.php` (tenant scope key `system-config.setting` with `$crud`), are seeded in the tenant database, and the shared partial checks the same string. One minor finding:

#### SET-04 · L · AUTH-06 — the permission literal is repeated in two methods and the partial

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M, lowered to L) — *permission strings live in one place, not repeated as literals; lowered because the whole module and codebase use string gates and moving to constants is a wider refactor* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SettingController.php:68` (also line 80, and `_settings.blade.php:19`) |
| **Root cause** | `'tenant.system-config.setting.update'` is written literally in `edit()`, in `update()`, and in the shared Blade partial, with no shared constant. |
| **Consequence** | A rename of the permission must be made in three places or one surface silently drifts from the others; no user-visible symptom today. |
| **Reproduce** | static only — a maintainability issue. |
| **Fix approach** | Accepted as house convention; not changed in this pass (extracting a constant would also require touching the shared Blade partial). Recorded in `02-fix-plan.md` §10. |
| **Plan item** | none — accepted (see `02-fix-plan.md` §10) |

```php
// SettingController.php:66-80 — CURRENT
    public function edit(int $id)
    {
        Gate::authorize('tenant.system-config.setting.update');

        $setting = Setting::findOrFail($id);

        return view('systemconfig::setting.edit', compact('setting'));
    }

    /**
     * Update the setting value.
     */
    public function update(Request $request, int $id)
    {
        Gate::authorize('tenant.system-config.setting.update');
```

**Evidence**
```
$ grep -n "tenant.system-config.setting.update" Modules/SystemConfig/app/Http/Controllers/SettingController.php Modules/SystemConfig/resources/views/setting/partials/_settings.blade.php
Modules/SystemConfig/app/Http/Controllers/SettingController.php:68:        Gate::authorize('tenant.system-config.setting.update');
Modules/SystemConfig/app/Http/Controllers/SettingController.php:80:        Gate::authorize('tenant.system-config.setting.update');
Modules/SystemConfig/resources/views/setting/partials/_settings.blade.php:19:    $canEditSettings = \Illuminate\Support\Facades\Gate::allows('tenant.system-config.setting.update');
```

Authorization is otherwise clean: every routed method authorizes before it loads a record (`index` → viewAny; `edit` and `update` → update, both before `findOrFail`). The declared permissions `tenant.system-config.setting.viewAny` and `tenant.system-config.setting.update` are seeded as exact names (see §7 note on unused declared verbs).

### F4 — Validation and input

#### SET-05 · L · VAL-02 — inline `$request->validate()` instead of a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M, lowered to L) — *validation lives in a FormRequest; inline `validate()` is allowed only for a one-field AJAX toggle; lowered because this endpoint updates a single field and has an AJAX path* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SettingController.php:86-88`, method `update()` |
| **Root cause** | The rule set `['value' => ['required', 'string', 'max:1000']]` is written inline. There is no `SettingUpdateRequest`; the only request class in the module is `TenantDropdownRequest`. |
| **Consequence** | No user-visible defect. The rule is not reusable or injectable and cannot be unit-tested in isolation. |
| **Reproduce** | static only — a structure issue. |
| **Fix approach** | Accepted as the documented one-field exception (the only writable field is `value`, and the inline editor is an AJAX call). Recorded in `02-fix-plan.md` §10; extracting a `SettingUpdateRequest` is optional hygiene. |
| **Plan item** | none — accepted (see `02-fix-plan.md` §10) |

```php
// SettingController.php:86-88 — CURRENT
                $validated = $request->validate([
                    'value' => ['required', 'string', 'max:1000'],
                ]);
```

**Evidence**
```
$ grep -n "validate(" Modules/SystemConfig/app/Http/Controllers/SettingController.php
86:                $validated = $request->validate([
```

#### SET-06 · M · VAL-05 — an array `search[]` / `type[]` query value becomes a 500

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; unvalidated input on a write/read path is a defect* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SettingController.php:28`, method `index()` |
| **Root cause** | `index()` passes `$request->input('search')` and `$request->input('type')` straight into `listQuery(?string $search, ?string $type)` (`:44`). Laravel returns the raw query value, so `?search[]=x` yields an array. The controller file declares `declare(strict_types=1)`, so passing an array to a `?string` parameter throws a `TypeError` and the page returns HTTP 500. |
| **Consequence** | A crafted link such as `/system-config/setting?search[]=x` crashes the list page with a 500 instead of ignoring the malformed value. |
| **Reproduce** | static only — the array is typed into the URL; a live check needs an authenticated tenant session (D4 forbids a test). The strict-types behaviour is proven below. |
| **Fix approach** | Coerce each input to string or null before the call in `index()` (see the SET-06 item in `02-fix-plan.md` §5). |
| **Plan item** | SET-06 in `02-fix-plan.md` §5 |

```php
// SettingController.php:28 — CURRENT
        $settings = self::listQuery($request->input('search'), $request->input('type'))
```

**Evidence**
```
$ grep -n "self::listQuery\|public static function listQuery\|request->input" Modules/SystemConfig/app/Http/Controllers/SettingController.php
28:        $settings = self::listQuery($request->input('search'), $request->input('type'))
44:    public static function listQuery(?string $search, ?string $type)

$ php -r 'declare(strict_types=1); function f(?string $s){ return $s; } try { f(["x"]); echo "no error"; } catch (\TypeError $e) { echo "TypeError: ".$e->getMessage()."\n"; }'
TypeError: f(): Argument #1 ($s) must be of type ?string, array given, called in Command line code on line 1
```

### F5 — Routes

clean — no state change over GET (the only write is `PUT|PATCH`), every route points at an existing method, and every tenant route is inside the tenancy middleware group. Proved by:
```
$ python3 -c "import json;r=json.load(open('/tmp/fa-routes.json'));[print(x['method'],'|',x['uri'],'|',x['action']) for x in r if 'SystemConfig' in x['action'] and 'SettingController' in x['action']]"
GET|HEAD | system-config/setting | Modules\SystemConfig\Http\Controllers\SettingController@index
PUT|PATCH | system-config/setting/{setting} | Modules\SystemConfig\Http\Controllers\SettingController@update
GET|HEAD | system-config/setting/{setting}/edit | Modules\SystemConfig\Http\Controllers\SettingController@edit
```
The scanner's RTE-03 candidate on `listQuery` was confirmed as the intentional shared helper described in §4 — not a finding.

### F6 — Controller shape

#### SET-07 · L · CTL-03 — the route parameter `{setting}` is not bound to the model

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M, lowered to L) — *use route model binding; lowered because the id is still passed correctly and switching to binding would move the row load ahead of the authorization check (AUTH-02)* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SettingController.php:66`, method `edit()` (and `:78`, `update()`) |
| **Root cause** | The resource route names its parameter `{setting}` (from `Route::resource('setting', ...)`) but the methods are typed `int $id` and load the row with `Setting::findOrFail($id)`. Laravel binds a model only when a method argument is class-typed with the matching name, so no binding happens; the raw id is passed positionally. The controller deliberately authorizes first and loads second, which preserves AUTH-02. |
| **Consequence** | No user-visible defect for a single route parameter. The mismatch is fragile: it works only because there is exactly one parameter, and it silently disables implicit binding. |
| **Reproduce** | static only — a routing-intent issue. |
| **Fix approach** | Accepted: keep the authorize-first load and treat the name mismatch as cosmetic. Switching to `Setting $setting` binding is a behaviour decision, not a mechanical fix, and is recorded in `02-fix-plan.md` §10. |
| **Plan item** | none — accepted (see `02-fix-plan.md` §10) |

```php
// SettingController.php:66-70 — CURRENT
    public function edit(int $id)
    {
        Gate::authorize('tenant.system-config.setting.update');

        $setting = Setting::findOrFail($id);
```

**Evidence**
```
$ grep -n "public function edit\|public function update" Modules/SystemConfig/app/Http/Controllers/SettingController.php
66:    public function edit(int $id)
78:    public function update(Request $request, int $id)

route uri: system-config/setting/{setting}   (route:list — parameter name is "setting")
```

#### SET-08 · L · CTL-04 — public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SettingController.php:24`, method `index()` (also `listQuery` :44, `edit` :66, `update` :78) |
| **Root cause** | None of the four public methods declares a return type. |
| **Consequence** | No user-visible defect; the contract of each method is not expressed in the signature. |
| **Reproduce** | static only — a style issue. |
| **Fix approach** | Deferred this pass. Adding types needs new imports (`View`, `Builder`, `JsonResponse`, `RedirectResponse`) that would overlap the SET-01 import edit; recorded in `02-fix-plan.md` §10. |
| **Plan item** | none — deferred (see `02-fix-plan.md` §10) |

```php
// SettingController.php:24 — CURRENT
    public function index(Request $request)
```

**Evidence**
```
$ grep -nE "public (static )?function" Modules/SystemConfig/app/Http/Controllers/SettingController.php
24:    public function index(Request $request)
44:    public static function listQuery(?string $search, ?string $type)
66:    public function edit(int $id)
78:    public function update(Request $request, int $id)
```

Not present: god-controller size (134 lines, 4 methods), long methods (all under 80 lines), `extract()`/large `compact()`, `request()` helper in the controller, debug leftovers, dead private methods, copy-pasted payloads.

### F7 — Models

#### SET-09 · M · MDL-02 — `is_public` has no boolean cast

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` for every boolean, date, decimal, json/array and enum column* |
| **Where** | `Modules/SystemConfig/app/Models/Setting.php:13-22`, class `Setting` |
| **Root cause** | The model declares `$fillable` but no `$casts`. The `sys_settings.is_public` column is a boolean (TINYINT(1)) and is read as a raw value in the partial (`@if($setting->is_public)`). |
| **Consequence** | The value is returned as the driver's raw `'0'`/`'1'` string rather than a PHP bool; today `'0'` is truthy-false so the badge happens to render correctly, but any strict comparison (`=== true`) or JSON output elsewhere sees a string. |
| **Reproduce** | static only — a model-cast issue. |
| **Fix approach** | Add `protected $casts = ['is_public' => 'boolean'];` (see the SET-09 item in `02-fix-plan.md` §5). |
| **Plan item** | SET-09 in `02-fix-plan.md` §5 |

```php
// Setting.php:13-22 — CURRENT
    protected $table = 'sys_settings';
    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'key',
        'value',
        'type',
        'is_public',
    ];
```

**Evidence**
```
$ grep -n "casts\|is_public" Modules/SystemConfig/app/Models/Setting.php
21:        'is_public',
```

Checked, not present: `$guarded = []` (a `$fillable` is declared and holds no sensitive column), `SoftDeletes` (the model uses none and `sys_settings` has no `deleted_at`), `$table` missing from a migration (it exists in `database/migrations/tenant/2026_06_17_150000_create_sys_settings_table.php`), pivots, global scopes, `InteractsWithMedia`. The `key` column has a non-unique index only, so there is no soft-delete × unique-index trap.

### F8 — Services and jobs

clean — the controller uses no service or job. Proved by:
```
$ grep -nE "[A-Z][A-Za-z]+(Service|Job)\b" Modules/SystemConfig/app/Http/Controllers/SettingController.php
(no output)
```

### F9 — Queries and performance

#### SET-10 · L · QRY-08 — three leading-wildcard `LIKE` searches

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M, lowered to L) — *leading-wildcard `LIKE '%x%'` cannot use an index; acceptable on small tables; lowered because `sys_settings` holds 6 rows* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SettingController.php:48-53`, method `listQuery()` |
| **Root cause** | The search wraps the term as `"%{$search}%"` on `key`, `description` and `value`, so no index can be used. |
| **Consequence** | No user-visible impact at 6 rows; on a very large settings table the search would be a full scan. |
| **Reproduce** | static only — a performance concern. |
| **Fix approach** | Accepted for a 6-row table; recorded in `02-fix-plan.md` §10. |
| **Plan item** | none — accepted (see `02-fix-plan.md` §10) |

```php
// SettingController.php:48-53 — CURRENT
        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('key', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%")
                  ->orWhere('value', 'like', "%{$search}%");
            });
```

**Evidence**
```
$ grep -n "like" Modules/SystemConfig/app/Http/Controllers/SettingController.php
50:                $q->where('key', 'like', "%{$search}%")
51:                  ->orWhere('description', 'like', "%{$search}%")
52:                  ->orWhere('value', 'like', "%{$search}%");
```

Otherwise clean: the list is paginated (`->paginate(20)->withQueryString()`), there are no loops or lazy relation loads, and no interpolated raw SQL. `paginate(20)` differs from the C12 default of 10 — the standalone page holds one paginator and the second caller (`SchoolConfigController`) already uses distinct page names (`settings_page`), so this is not raised as a finding.

### F10 — Views

clean — no `{!! !!}` in any of the three blades (nothing is rendered unescaped), no queries in Blade, and the row values are escaped (`{{ $setting->value }}`). The partial's `$setting->description` refers to a real column (`sys_settings.description` exists). Proved by:
```
$ grep -n '{!!' Modules/SystemConfig/resources/views/setting/index.blade.php Modules/SystemConfig/resources/views/setting/edit.blade.php Modules/SystemConfig/resources/views/setting/partials/_settings.blade.php
(no output)
```
The list uses an inline double-click editor instead of `x-backend.table.action`; the comment at `_settings.blade.php:133-138` records that this replaced the per-row Edit button on 2026-08-24, so the custom table is intentional. The row-action standard is therefore not applicable to this list.

### F11 — Security and tenancy

clean — no `env()` outside config, no over-exposed personal data (the JSON response returns only `success`, `message` and the setting `value`), no hard-coded ids or `?? 1`, no request bodies in logs, no central models, and no file URLs. Proved by:
```
$ grep -n "env(\|->all()\|Log::" Modules/SystemConfig/app/Http/Controllers/SettingController.php
122:            Log::error('SettingController::update failed', ['error' => $e->getMessage()]);
```
(the single `Log::` line is the ERR-05 finding SET-02; it logs no request data).

### F12 — Style

#### SET-11 · L · STY-01 / STY-02 — `Setting.php` has no `strict_types`, and both files fail Pint

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files; STY-02 (L) — Pint-clean* |
| **Where** | `Modules/SystemConfig/app/Models/Setting.php:1` (also the controller for Pint) |
| **Root cause** | `Setting.php` omits `declare(strict_types=1)`; neither file matches the project's Pint style (the controller has blank lines between imports plus ordering/indentation fixes). |
| **Consequence** | No runtime effect in production; inconsistent formatting and no strict typing in the model. |
| **Reproduce** | static only — a style issue. |
| **Fix approach** | Add `declare(strict_types=1);` to the model and run Pint on both files (see the SET-11 item in `02-fix-plan.md` §8). |
| **Plan item** | SET-11 in `02-fix-plan.md` §8 |

```php
// Setting.php:1-3 — CURRENT
<?php

namespace Modules\SystemConfig\Models;
```

**Evidence**
```
$ grep -n "declare(strict_types" Modules/SystemConfig/app/Models/Setting.php
(no output)

$ vendor/bin/pint --test Modules/SystemConfig/app/Http/Controllers/SettingController.php Modules/SystemConfig/app/Models/Setting.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SystemConfig\/app\/Http\/Controllers\/SettingController.php","fixers":["method_chaining_indentation","no_extra_blank_lines","ordered_imports","binary_operator_spaces"]},{"path":"Modules\/SystemConfig\/app\/Models\/Setting.php","fixers":["class_attributes_separation","single_line_comment_spacing"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

Only `update()` mutates. The eight questions, one row:

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicates | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `update()` | ok — writes only `value` for one row | ok — no delete | ok — the form and the inline editor call the same method | ok — no soft delete, no unique key | ok — last-write-wins on a settings value; acceptable | ok — `Gate::authorize` runs first | ok — "Setting updated successfully." follows a committed write | SET-12 |

#### SET-12 · L · CTL-10 — the edit page is orphaned (dead feature)

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *dead code / a dead feature; the UI no longer links to the edit screen* |
| **Where** | `routes/tenant.php:118-120` (the `setting` resource) and `Modules/SystemConfig/resources/views/setting/edit.blade.php` |
| **Root cause** | The inline double-click editor in `_settings.blade.php` replaced the per-row Edit button (removed 2026-08-24, see `SchoolConfigController.php:27-30`), but the `edit` route, the `edit()` controller method and `edit.blade.php` were left in place. Nothing links to `system-config.setting.edit`. |
| **Consequence** | The page still works if its URL is typed directly, but no user can reach it from the UI, so it is dead surface kept alive by its own report. |
| **Reproduce** | Open `/system-config/settings` and look for an Edit button — there is none; the only edit control is the inline cell editor. |
| **Fix approach** | A behaviour decision: keep the route for direct/bookmarked access, or remove the route, method and view. Recorded as DECISION SET-12 in `02-fix-plan.md` §9. |
| **Plan item** | SET-12 (DECISION) in `02-fix-plan.md` §9 |

```php
// routes/tenant.php:118-120 — CURRENT
        // Tenant Settings (index + edit/update only — settings are seeded, not user-created)
        Route::resource('setting', SettingController::class)
            ->only(['index', 'edit', 'update']);
```

**Evidence**
```
$ grep -rn "route('system-config.setting.edit'\|setting.edit" Modules/ resources/ app/ --include=*.blade.php --include=*.php | grep -v "Controller.php"
(no output)
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php` | Passes `$request->input('search')` and `type` into `SettingController::listQuery(?string …)` — the same array-input 500 as SET-06 also affects the School Config page | VAL-05 | SchoolConfigController's own report |
| `Modules/Prime/app/Policies/PrimeSettingPolicy.php` | Registered in `PrimeServiceProvider.php:90` for the deprecated `Modules\Prime\Models\Setting` and gates on `prime.prime.setting.*`; the tenant `SettingController` uses string gates instead, so this policy is not consulted for tenant settings | AUTH-03 / AUTH-06 | Modules/Prime report (different module) |
| `app/Helpers/activityLog.php` | Common helper that writes `sys_activity_logs`; referenced by the controller, not audited here | TXN-01 | common (app/ glue) |
| `config/permissionslist.php` | Declares 7 verbs for `system-config.setting`; the code checks only `viewAny` and `update`, so `create`/`view`/`delete`/`restore`/`forceDelete` are seeded but never checked | AUTH-06 | app-wide permissions cleanup |

## 8. Not covered, and why

- **No HTTP request was dispatched.** D4 forbids tests, so the routes, model binding and the array-input crash (SET-06) were established from `route:list`, reflection and static evidence, not by calling the endpoints with an authenticated tenant session.
- **The inline-editor JavaScript was read, not executed.** The `fetch`/422 handling in `_settings.blade.php:146-291` was reviewed statically; no browser run.
- **The edit Blade was read, not rendered.** `edit.blade.php` compiles from inspection; the SET-12 decision may remove it.
- **Queue jobs, events and mail:** none are used by this controller.
