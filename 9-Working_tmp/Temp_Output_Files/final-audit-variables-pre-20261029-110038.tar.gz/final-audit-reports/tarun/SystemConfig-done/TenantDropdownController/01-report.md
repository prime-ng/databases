# Final Audit — SystemConfig / TenantDropdownController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php` (340 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /system-config/dropdown/create` · `POST /system-config/dropdown` · `GET /system-config/dropdown/{dropdown}/edit` · `PUT /system-config/dropdown/{dropdown}` · `DELETE /system-config/dropdown/{dropdown}` · `GET /system-config/dropdown/trash` · `GET /system-config/dropdown/{id}/restore` · `DELETE /system-config/dropdown/{id}/force-delete` · `POST /system-config/dropdown/{dropdown}/toggle-status` · `GET /system-config/dropdown/columns` |
| Menu path | System Config → Dropdown Management (the list page is the `dropdown-list` tab of the shared blade `systemconfig::dropdown.index`) |
| Who uses it | Roles that hold the permission, measured on the test tenant `xyz_school_00000000000040008000_202627`: **Super Admin** and **School Admin** (both hold all seven `tenant.system-config.dropdown.*` names) |
| What a user does here | A school admin maintains the reference lists ("dropdowns") that the rest of the ERP reads by key — a table/column pair such as `msh_marksheet_schedules.status_id`. They add a value, edit a value, switch a value active/inactive, soft-delete a value, restore it, or permanently delete it. The values themselves are grouped by `key` on the shared Dropdown Management page. |
| Tables written | `sys_dropdown_table` (create/update/soft-delete/restore/force-delete), `sys_dropdown_need_dropdowns_jnt` (force-delete only), `sys_activity_logs` (audit rows via `activityLog()`) |
| Tables read | `sys_dropdown_table`, `sys_dropdown_need_dropdowns_jnt`; permission tables `sys_permissions` and `sys_role_has_permissions_jnt` via `Gate::authorize` |
| Live data | `sys_dropdown_table` — **716 rows live, 0 trashed**; `sys_dropdown_need_dropdowns_jnt` — **776 rows**; `sys_activity_logs` — **1,986 rows** (test tenant `xyz_school_00000000000040008000_202627`) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready**. Every mutating method carries the Variant-H `try/catch` that D1 forbids, and — the one that hurts a real user — a dropdown created through the UI is stored under a **mangled key**: `store()` runs `Str::slug()` over a key that the create form builds as `table.column`, so `msh_marksheet_schedules.status_id` becomes `msh_marksheet_schedulesstatus_id` (the dot is dropped) and no consumer that reads the dotted key ever sees it. A second high-impact bug: the `is_active` normaliser compares the switch's posted value `"1"` against the literal `'on'`, so **every dropdown created or edited is saved inactive**. There are no B-severity findings (no data loss, no security hole, no crash on a normal path), but there are 8 H findings. Rough effort to apply the plan: **M — about half a day** for a developer who has not opened the file.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 8 | 8 | 7 | 2 | 23 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TDC-01, TDC-02, TDC-03, TDC-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | TDC-05, TDC-06, TDC-07 | F9 Queries/Perf | TDC-18, TDC-19, TDC-20, TDC-21 |
| F3 Authorization | TDC-08 | F10 Views | clean |
| F4 Validation | TDC-09 | F11 Security/Tenancy | clean |
| F5 Routes | TDC-10, TDC-11 | F12 Style | TDC-22, TDC-23 |
| F6 Controller shape | TDC-12, TDC-13, TDC-14 | F13 Deep read | table + TDC-14 |
| F7 Models | TDC-15, TDC-16, TDC-17 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php` | controller | 340 | this report | ✅ |
| 2 | `Modules/SystemConfig/app/Models/Dropdown.php` | model | 49 | this report (pre-assigned) | ✅ |
| 3 | `Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php` | form request | 44 | this report | ✅ |
| 4 | `Modules/SystemConfig/resources/views/dropdown/create.blade.php` | blade | 124 | this report | ✅ |
| 5 | `Modules/SystemConfig/resources/views/dropdown/edit.blade.php` | blade | 79 | this report | ✅ |
| 6 | `Modules/SystemConfig/resources/views/dropdown/trash.blade.php` | blade | 46 | this report | ✅ |
| 7 | `Modules/SystemConfig/resources/views/dropdown/index.blade.php` | blade | 224 | ↗ shared with `TenantDropdownNeedController` (renders it live; this controller's `index()` is unrouted) | ↗ linked |
| 8 | `Modules/SystemConfig/resources/views/dropdown/dropdown-list.blade.php` | blade | 113 | ↗ shared with `TenantDropdownNeedController` | ↗ linked |
| 9 | `routes/tenant.php` (lines 128-137) | route file | — | shared | ❌ not a class |
| 10 | `app/Helpers/activityLog.php` | app helper | 51 | common (§4.2) | ❌ common |
| 11 | `resources/views/components/backend/form/status-switch.blade.php` | blade component | 33 | common (§4.2) | ❌ common |
| 12 | `resources/views/components/backend/table/status-switch.blade.php` | blade component | 58 | common (§4.2) | ❌ common |
| 13 | `resources/views/components/backend/table/action-trashed.blade.php` | blade component | 99 | common (§4.2) | ❌ common |
| 14 | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php` | controller — owns the live `system-config.dropdown.index` route | — | ↗ its own report (audited later) | ↗ linked |
| 15 | `config/permissionslist.php` (key `system-config.dropdown`, line 346) | config | — | shared | ❌ not a class |

No pre-applied files: there is no `PRE-APPLIED-*.md` for SystemConfig.

## 4. Routes

```
POST     system-config/dropdown                                  system-config.dropdown.store        Modules\SystemConfig\Http\Controllers\TenantDropdownController@store
GET|HEAD system-config/dropdown/columns                          system-config.dropdown.columns      Modules\SystemConfig\Http\Controllers\TenantDropdownController@getColumns
GET|HEAD system-config/dropdown/create                           system-config.dropdown.create       Modules\SystemConfig\Http\Controllers\TenantDropdownController@create
GET|HEAD system-config/dropdown/trash                            system-config.dropdown.trashed      Modules\SystemConfig\Http\Controllers\TenantDropdownController@trashed
PUT      system-config/dropdown/{dropdown}                       system-config.dropdown.update       Modules\SystemConfig\Http\Controllers\TenantDropdownController@update
DELETE   system-config/dropdown/{dropdown}                       system-config.dropdown.destroy      Modules\SystemConfig\Http\Controllers\TenantDropdownController@destroy
GET|HEAD system-config/dropdown/{dropdown}/edit                  system-config.dropdown.edit         Modules\SystemConfig\Http\Controllers\TenantDropdownController@edit
POST     system-config/dropdown/{dropdown}/toggle-status         system-config.dropdown.toggleStatus Modules\SystemConfig\Http\Controllers\TenantDropdownController@toggleStatus
DELETE   system-config/dropdown/{id}/force-delete                system-config.dropdown.forceDelete  Modules\SystemConfig\Http\Controllers\TenantDropdownController@forceDelete
GET|HEAD system-config/dropdown/{id}/restore                     system-config.dropdown.restore      Modules\SystemConfig\Http\Controllers\TenantDropdownController@restore
```

The routes are registered in `routes/tenant.php:128-137`, inside `Route::middleware(['auth', 'verified'])->prefix('system-config')->name('system-config.')`, i.e. the tenant tenancy group. The route name `system-config.dropdown.index` (the list page this controller's `store`/`update`/`destroy`/`restore`/`forceDelete` all redirect to) is **not** owned by this controller — it is registered on `TenantDropdownNeedController@index` (`routes/tenant.php:140`).

Unrouted public methods: **`index`** at `TenantDropdownController.php:25` — no route in `/tmp/fa-routes.json` points at `TenantDropdownController@index`. See TDC-11.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 25 | not routed | `tenant.system-config.dropdown.viewAny` | none (read) | none | none | TDC-11, TDC-13, TDC-18, TDC-20 |
| `create` | 74 | GET /system-config/dropdown/create | `tenant.system-config.dropdown.create` | none (read) | none | none | TDC-04, TDC-13 |
| `store` | 94 | POST /system-config/dropdown | `tenant.system-config.dropdown.create` | controller | 'Stored' | `sys_dropdown_table`, `sys_activity_logs` | TDC-01, TDC-02, TDC-05, TDC-07, TDC-13, TDC-15, TDC-16, TDC-19 |
| `edit` | 137 | GET /system-config/dropdown/{dropdown}/edit | `tenant.system-config.dropdown.update` | none (read) | none | none | TDC-12, TDC-13 |
| `update` | 149 | PUT /system-config/dropdown/{dropdown} | `tenant.system-config.dropdown.update` | controller | 'Updated' | `sys_dropdown_table`, `sys_activity_logs` | TDC-01, TDC-02, TDC-05, TDC-13, TDC-15 |
| `destroy` | 188 | DELETE /system-config/dropdown/{dropdown} | `tenant.system-config.dropdown.delete` | controller | 'Trashed' | `sys_dropdown_table`, `sys_activity_logs` | TDC-01, TDC-02, TDC-05, TDC-13 |
| `trashed` | 218 | GET /system-config/dropdown/trash | `tenant.system-config.dropdown.restore` | none (read) | none | none | TDC-13, TDC-21 |
| `restore` | 230 | GET /system-config/dropdown/{id}/restore | `tenant.system-config.dropdown.restore` | controller | 'Restored' | `sys_dropdown_table`, `sys_activity_logs` | TDC-01, TDC-02, TDC-05, TDC-10, TDC-13 |
| `forceDelete` | 260 | DELETE /system-config/dropdown/{id}/force-delete | `tenant.system-config.dropdown.forceDelete` | controller | 'Deleted' | `sys_dropdown_need_dropdowns_jnt`, `sys_dropdown_table`, `sys_activity_logs` | TDC-01, TDC-02, TDC-05, TDC-06, TDC-13 |
| `getColumns` | 289 | GET /system-config/dropdown/columns | `tenant.system-config.dropdown.viewAny` | none (read) | none | none | TDC-04, TDC-13, TDC-14 |
| `toggleStatus` | 314 | POST /system-config/dropdown/{dropdown}/toggle-status | `tenant.system-config.dropdown.update` | controller | 'Toggled' | `sys_dropdown_table`, `sys_activity_logs` | TDC-01, TDC-02, TDC-03, TDC-05, TDC-06, TDC-08, TDC-13 |

## 6. Findings

### F1 — Errors

#### TDC-01 · H · ERR-00 (D1) — eight methods wrap their body in the Variant-H `try/catch`

| Field | Value |
|---|---|
| **Rule** | ERR-00 (D1) — *the Laravel idiom: no try/catch in controllers; a controller try/catch is a finding unless D2 allows it* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:98-131`, method `store()` (also `create` :79-86, `update` :154-182, `destroy` :192-212, `restore` :234-254, `forceDelete` :264-286, `getColumns` :302-308, `toggleStatus` :318-338) |
| **Root cause** | All eight methods are written to house rule A1 (Variant H: catch everything and render a page-specific message). D1 settled the Laravel idiom instead. The two catches — `catch (ModelNotFoundException $e) { throw $e; }` then `catch (\Throwable $e)` — are not one of the D2 allowed shapes (D2 allows `\DomainException`, a truncate-rebuild catch, `SnapshotProtectionException`, and services using `report($e)`). In `store`, `update` and `toggleStatus` the `ModelNotFoundException` re-throw is also **dead**: those methods use route model binding or no `findOrFail()`, so the exception cannot be thrown there. |
| **Consequence** | A real server failure inside a write is caught locally and turned into `back()->with('error', 'The operation could not be completed.')` (or, in `toggleStatus`, an HTML redirect at a JSON endpoint — TDC-03), instead of the central handler in `bootstrap/app.php` logging the exception with its trace and rendering the standard error page. |
| **Reproduce** | static only — the catch only runs when a write fails; the effect is on the error path, not on a normal click. |
| **Fix approach** | Delete every `try`/`catch`. Keep `Gate::authorize`, then the load, then one `DB::transaction` for the write and its audit row, and build the response after the transaction. Handled per method by plan items TDC-01 (`store`), TDC-03 (`toggleStatus`), TDC-04 (`create`/`getColumns`) and TDC-12 (`update`/`destroy`/`restore`/`forceDelete`). |
| **Plan item** | TDC-01 in `02-fix-plan.md` §3 (the other methods by TDC-03/TDC-04/TDC-12) |

```php
// TenantDropdownController.php:98-131 — CURRENT (store())
        try {
            return DB::transaction(function () use ($request) {
                $data   = $request->validated();
                $values = array_unique(array_filter(array_map('trim', explode(',', $data['value']))));

                $maxOrdinal = Dropdown::where('key', Str::slug($data['key'], '_'))->max('ordinal') ?? 0;
                $ordinal    = $maxOrdinal + 1;

                $additionalInfo = !empty($data['additional_info']) ? $data['additional_info'] : null;

                foreach ($values as $value) {
                    $dropdown = Dropdown::create([
                        'ordinal'  => $ordinal++,
                        'key'      => Str::slug($data['key'], '_'),
                        'value'    => $value,
                        'type'     => $data['type'] ?? 'String',
                        'additional_info' => $additionalInfo,
                        'is_active' => $data['is_active'] ?? true,
                    ]);
                    activityLog($dropdown, 'Stored', ['message' => "Tenant dropdown '{$dropdown->key}' value '{$value}' created."]);
                }

                return redirect()->route('system-config.dropdown.index')->with('success', flash('created.dropdown'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('TenantDropdownController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -nE "try \{|catch \(|Log::error" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
79:        try {
84:        } catch (\Exception $e) {
98:        try {
123:        } catch (ModelNotFoundException $e) {
127:        } catch (\Throwable $e) {
128:            Log::error('TenantDropdownController::store failed', ['error' => $e->getMessage()]);
154:        try {
174:        } catch (ModelNotFoundException $e) {
178:        } catch (\Throwable $e) {
179:            Log::error('TenantDropdownController::update failed', ['error' => $e->getMessage()]);
192:        try {
204:        } catch (ModelNotFoundException $e) {
208:        } catch (\Throwable $e) {
209:            Log::error('TenantDropdownController::destroy failed', ['error' => $e->getMessage()]);
234:        try {
246:        } catch (ModelNotFoundException $e) {
250:        } catch (\Throwable $e) {
251:            Log::error('TenantDropdownController::restore failed', ['error' => $e->getMessage()]);
264:        try {
278:        } catch (ModelNotFoundException $e) {
282:        } catch (\Throwable $e) {
283:            Log::error('TenantDropdownController::forceDelete failed', ['error' => $e->getMessage()]);
302:        try {
306:        } catch (\Exception $e) {
318:        try {
330:        } catch (ModelNotFoundException $e) {
334:        } catch (\Throwable $e) {
335:            Log::error('TenantDropdownController::toggleStatus failed', ['error' => $e->getMessage()]);
```

#### TDC-02 · M · ERR-05 — the catches log only `getMessage()`, never the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception object (`report($e)` / `Log::error('…', ['exception' => $e])`); `getMessage()` alone loses the trace* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:128`, method `store()` (also :179, :209, :251, :283, :335) |
| **Root cause** | Each generic catch calls `Log::error(..., ['error' => $e->getMessage()])`, storing only the text. The stack trace, exception class and file/line are not recorded. |
| **Consequence** | When a write fails an operator finds one line in the log with a message and no trace, so the failure cannot be diagnosed without reproducing it. |
| **Reproduce** | static only — the log entry is produced only when a write fails. |
| **Fix approach** | These lines are deleted together with the catches in TDC-01/TDC-03/TDC-12; the central handler then logs the exception object with its trace. No separate edit. |
| **Plan item** | none — resolved by the TDC-01, TDC-03 and TDC-12 items (see `02-fix-plan.md` §10) |

```php
// TenantDropdownController.php:128 — CURRENT
            Log::error('TenantDropdownController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
128:            Log::error('TenantDropdownController::store failed', ['error' => $e->getMessage()]);
179:            Log::error('TenantDropdownController::update failed', ['error' => $e->getMessage()]);
209:            Log::error('TenantDropdownController::destroy failed', ['error' => $e->getMessage()]);
251:            Log::error('TenantDropdownController::restore failed', ['error' => $e->getMessage()]);
283:            Log::error('TenantDropdownController::forceDelete failed', ['error' => $e->getMessage()]);
335:            Log::error('TenantDropdownController::toggleStatus failed', ['error' => $e->getMessage()]);
```

#### TDC-03 · H · ERR-04 — `toggleStatus` answers a failure with an HTML redirect at a JSON endpoint

| Field | Value |
|---|---|
| **Rule** | ERR-04 (M, raised to H because this endpoint is JSON-only and the failure is what the AJAX caller sees) — *JSON endpoints fail with JSON; form endpoints fail with a redirect; use `$request->expectsJson()` when one method serves both* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:334-338`, method `toggleStatus()` |
| **Root cause** | The method always returns `response()->json(...)` on the happy paths (lines 324, 327) but the generic catch returns `back()->with('error', ...)`, a `302` redirect. The row-action slider (`x-backend.table.status-switch`, rendered by `dropdown-list.blade.php`) calls this route with `fetch` and reads JSON, so a failure returns an HTML redirect instead. |
| **Consequence** | A user toggling a status switch sees the switch stay in the wrong state with no error message; the JavaScript's JSON parse fails silently. |
| **Reproduce** | Open `/system-config/dropdown`, open the `dropdown-list` tab, and toggle a value while the write is forced to fail (e.g. a deadlock). Expected: `{"success":false,…}`; actual: a `302` whose body is the list page. |
| **Fix approach** | Remove the `try/catch`; return `response()->json(['success' => false, 'message' => '…'], 500)` on failure, or let the central handler render JSON because the request's `Accept` is `application/json`. See the TDC-03 item in `02-fix-plan.md` §1. |
| **Plan item** | TDC-03 in `02-fix-plan.md` §1 |

```php
// TenantDropdownController.php:334-338 — CURRENT
        } catch (\Throwable $e) {
            Log::error('TenantDropdownController::toggleStatus failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -nE "response\(\)->json|back\(\)->with" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
324:                    return response()->json(['success' => true, 'is_active' => $dropdown->is_active, 'message' => flash('status_updated.dropdown')]);
327:                    return response()->json(['success' => false, 'is_active' => $dropdown->is_active, 'message' => flash('status_switch_failed.dropdown')]);
337:            return back()->with('error', 'The operation could not be completed.');
```

#### TDC-04 · M · ERR-07 — the two read methods are wrapped in a `try/catch`

| Field | Value |
|---|---|
| **Rule** | ERR-07 (M) — *read-only methods (`index`, `show`, `create`, `edit`, lookups) need no try/catch* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:79-86`, method `create()` (also `getColumns` :302-308) |
| **Root cause** | `create()` wraps `SHOW TABLES` and swallows the exception into `$tables = []`. `getColumns()` wraps `getColumnListing()` and returns a `422`. `create()` is a read-only form; D1 says no try/catch in controllers, and this catch only hides a real database error from the log. |
| **Consequence** | If the tenant connection is momentarily unavailable, `create()` silently shows an empty table list with no error and no log entry, so the admin cannot tell a permissions problem from an outage. |
| **Reproduce** | static only — the catch only runs when `SHOW TABLES` fails. |
| **Fix approach** | Delete both `try/catch` blocks; let a real failure reach the central handler. See the TDC-04 item in `02-fix-plan.md` §3. |
| **Plan item** | TDC-04 in `02-fix-plan.md` §3 |

```php
// TenantDropdownController.php:79-86 — CURRENT (create())
        try {
            $result = DB::connection('tenant')->select('SHOW TABLES');
            $key = 'Tables_in_' . DB::connection('tenant')->getDatabaseName();
            $tables = array_map(fn($t) => $t->$key, $result);
            sort($tables);
        } catch (\Exception $e) {
            $tables = [];
        }
```

**Evidence**
```
$ grep -nE "catch \(\\\\Exception" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
84:        } catch (\Exception $e) {
306:        } catch (\Exception $e) {
```

### F2 — Transactions and audit

#### TDC-05 · M · TXN-05 — the HTTP response is built inside the `DB::transaction` closure (six methods)

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build `redirect()` / `response()` after it* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:120-122`, method `store()` (also `update` :171, `destroy` :201, `restore` :243, `forceDelete` :275, `toggleStatus` :324) |
| **Root cause** | Each `DB::transaction` closure `return`s the `redirect()`/`response()->json()` directly, so the response is built while the transaction is still open. |
| **Consequence** | The database transaction stays open while the response object is serialised, holding the connection longer than needed on every write. |
| **Reproduce** | static only — a transaction-scope issue, not visible in the browser. |
| **Fix approach** | The closure writes and audits only; the response is built after the `DB::transaction` call. Done in the TDC-01/TDC-03/TDC-12 method rewrites. |
| **Plan item** | none — resolved by the TDC-01, TDC-03 and TDC-12 items (see `02-fix-plan.md` §10) |

```php
// TenantDropdownController.php:120-122 — CURRENT (store())
                return redirect()->route('system-config.dropdown.index')->with('success', flash('created.dropdown'));

            });
```

**Evidence**
```
$ grep -n "return DB::transaction" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
99:            return DB::transaction(function () use ($request) {
155:            return DB::transaction(function () use ($dropdown, $validated) {
193:            return DB::transaction(function () use ($id) {
235:            return DB::transaction(function () use ($id) {
265:            return DB::transaction(function () use ($id) {
319:            return DB::transaction(function () use ($dropdown) {
```

#### TDC-06 · M · TXN-04 — `activityLog()` runs before the write it describes

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:320-323`, method `toggleStatus()` (also `forceDelete` :272-273) |
| **Root cause** | In `toggleStatus` the audit row is written at line 321 before `$dropdown->save()` at line 323, so the log records a toggle that may not commit. In `forceDelete` the audit row is written at line 272 before `$dropdown->forceDelete()` at line 273. |
| **Consequence** | An audit entry can claim a status change or a permanent delete that never happened if the write fails, misleading anyone reading the activity log. |
| **Reproduce** | static only — the order is wrong only on a failed write. |
| **Fix approach** | Move `activityLog(...)` after the `save()`/`forceDelete()` call, still inside the transaction. Done in the TDC-03 and TDC-12 method rewrites. |
| **Plan item** | none — resolved by the TDC-03 and TDC-12 items (see `02-fix-plan.md` §10) |

```php
// TenantDropdownController.php:320-323 — CURRENT (toggleStatus())
                $dropdown->is_active = !$dropdown->is_active;
                activityLog($dropdown, 'Toggled', ['message' => "Tenant dropdown status toggled.", 'new_status' => $dropdown->is_active ? 'Active' : 'Inactive']);

                if ($dropdown->save()) {
```

**Evidence**
```
$ sed -n '270,273p;320,323p' Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
                    ->delete();

                activityLog($dropdown, 'Deleted', ['message' => "Tenant dropdown '{$dropdown->key}' permanently deleted."]);
                $dropdown->forceDelete();
                $dropdown->is_active = !$dropdown->is_active;
                activityLog($dropdown, 'Toggled', ['message' => "Tenant dropdown status toggled.", 'new_status' => $dropdown->is_active ? 'Active' : 'Inactive']);

                if ($dropdown->save()) {
```

#### TDC-07 · M · TXN-06 — `store()` computes `max(ordinal) + 1` then inserts, with no lock

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M) — *check-then-act needs a lock or a unique index: `count()` then insert, `exists()` then `create()`; use `lockForUpdate()` inside the transaction, or rely on a DB unique index* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:103-104`, method `store()` |
| **Root cause** | `$maxOrdinal = Dropdown::where('key', …)->max('ordinal') ?? 0;` reads the current maximum and the loop inserts `max+1`, `max+2`, … with no `lockForUpdate()`. Two admins saving the same key at once both read the same max. The table does carry a unique index `uq_dropdownTable_key_ordinal` (`key`,`ordinal`), so an accidental collision is rejected rather than corrupting data — but it becomes a caught 500. The soft-delete scope also hides trashed rows from the `max()`, so the ordinal of a trashed row can be reused. |
| **Consequence** | Two simultaneous saves of the same dropdown key make the second fail with "The operation could not be completed." instead of appending. |
| **Reproduce** | static only — a race; a live check needs two concurrent authenticated sessions (D4 forbids a test). |
| **Fix approach** | Re-read the max inside a `lockForUpdate()` on the key's rows, or select the next ordinal inside the transaction with a row lock. Done as part of the TDC-01 `store()` rewrite. |
| **Plan item** | none — resolved by the TDC-01 item (see `02-fix-plan.md` §10) |

```php
// TenantDropdownController.php:103-104 — CURRENT
                $maxOrdinal = Dropdown::where('key', Str::slug($data['key'], '_'))->max('ordinal') ?? 0;
                $ordinal    = $maxOrdinal + 1;
```

**Evidence**
```
$ grep -n "uq_dropdownTable_key_ordinal" database/migrations/tenant/2026_06_15_145406_create_sys_dropdown_table.php
32:            $table->unique(['key', 'ordinal'], 'uq_dropdownTable_key_ordinal');
```

### F3 — Authorization

The gate names match `config/permissionslist.php` (tenant scope key `system-config.dropdown`, line 346) and are seeded in the tenant database as exact names (`Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php` is the only other check). Every routed method authorizes before it loads a record. One minor finding:

#### TDC-08 · L · AUTH-04 — the FormRequest `authorize()` and the controller `Gate::authorize` check the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (FormRequest `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:94-96`, method `store()` (also `update` :149-151) |
| **Root cause** | `TenantDropdownRequest::authorize()` already checks `tenant.system-config.dropdown.create` for POST and `…update` otherwise, and `store()`/`update()` then call `Gate::authorize()` for the same permission. |
| **Consequence** | No user-visible defect; the permission is evaluated twice per request. |
| **Reproduce** | static only — a structure issue. |
| **Fix approach** | Accepted for this pass: the controller gate is the module's house convention, and removing it would leave `store`/`update` authorized only by the FormRequest (still AUTH-01-safe). Recorded in `02-fix-plan.md` §10. |
| **Plan item** | none — accepted (see `02-fix-plan.md` §10) |

```php
// TenantDropdownController.php:94-96 — CURRENT (store())
    public function store(TenantDropdownRequest $request)
    {
        Gate::authorize('tenant.system-config.dropdown.create');
```

**Evidence**
```
$ grep -n "can(\|Gate::authorize" Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php:15:            return auth()->user()->can('tenant.system-config.dropdown.create');
Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php:17:        return auth()->user()->can('tenant.system-config.dropdown.update');
Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:96:        Gate::authorize('tenant.system-config.dropdown.create');
Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:151:        Gate::authorize('tenant.system-config.dropdown.update');
```

### F4 — Validation and input

#### TDC-09 · H · VAL-05 — the `is_active` normaliser compares `"1"` to `'on'`, so every dropdown is saved inactive

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M, raised to H because the write path stores the wrong value on every create and edit) — *every field is typed; a write path whose normalisation stores the wrong value is a defect* |
| **Where** | `Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php:38-43`, method `prepareForValidation()` |
| **Root cause** | The status switch component posts the checkbox as `name="is_active" value="1"` (`resources/views/components/backend/form/status-switch.blade.php:26`). `prepareForValidation()` merges `is_active` to `true` only when the input is exactly `'on'`; the actual value `"1"` never matches, so the merged value is always `false`. `store()` then writes `'is_active' => $data['is_active'] ?? true`, which is `false`, overriding the column default of `1`. |
| **Consequence** | Every dropdown value created through the UI is stored inactive, and every value opened and saved through the edit form is switched inactive — the switch appears to do nothing. Roles/forms that read only active dropdowns never see the new value. |
| **Reproduce** | Open `/system-config/dropdown/create`, tick "Is Active", save; the new rows are written with `is_active = 0`. |
| **Fix approach** | Treat any truthy posted value as active: `$this->boolean('is_active')` (or compare against `'1'`), instead of `=== 'on'`. See the TDC-09 item in `02-fix-plan.md` §1. |
| **Plan item** | TDC-09 in `02-fix-plan.md` §1 |

```php
// TenantDropdownRequest.php:38-43 — CURRENT
    protected function prepareForValidation(): void
    {
        $this->merge([
            'is_active' => $this->has('is_active') && $this->input('is_active') === 'on' ? true : false,
        ]);
    }
```

**Evidence**
```
$ grep -n 'value="1"' resources/views/components/backend/form/status-switch.blade.php
26:            value="1"

$ grep -n "=== 'on'" Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php
41:            'is_active' => $this->has('is_active') && $this->input('is_active') === 'on' ? true : false,
```

### F5 — Routes

#### TDC-10 · H · RTE-01 — restoring a dropdown changes state over a GET request

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, `publish`, `approve`, `sync`, `generate`); GET has no CSRF protection, and link prefetchers trigger it* |
| **Where** | `routes/tenant.php:128-131` (the `dropdown.restore` route), method `restore()` at `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:230` |
| **Root cause** | `restore()` writes (`$dropdown->restore(); $dropdown->is_active = true; $dropdown->save();`) but the route is registered `Route::get('/dropdown/{id}/restore', …)`. The shared `x-backend.table.action-trashed` component renders the restore control as a GET form because it reads the route's own methods. |
| **Consequence** | A restore can be triggered by a link prefetcher, a crawler, or an `<img src>` with no CSRF token; the delete counterpart already uses `DELETE`, so the pair is inconsistent. |
| **Reproduce** | Open `/system-config/dropdown/trash`, hover/click the restore icon while viewing the network tab — the request is `GET /system-config/dropdown/{id}/restore` with no CSRF token. |
| **Fix approach** | Change the route to `Route::delete(...)`; the `action-trashed` component already adapts to the route verb and will render the `@method('DELETE')` form. This changes a shared route file, so it is a DECISION. See TDC-10 in `02-fix-plan.md` §9. |
| **Plan item** | TDC-10 (DECISION) in `02-fix-plan.md` §9 |

```php
// routes/tenant.php:128-131 — CURRENT
        Route::get('/dropdown/trash', [TenantDropdownController::class, 'trashed'])->name('dropdown.trashed');
        Route::get('/dropdown/{id}/restore', [TenantDropdownController::class, 'restore'])->name('dropdown.restore');
        Route::delete('/dropdown/{id}/force-delete', [TenantDropdownController::class, 'forceDelete'])->name('dropdown.forceDelete');
        Route::post('/dropdown/{dropdown}/toggle-status', [TenantDropdownController::class, 'toggleStatus'])->name('dropdown.toggleStatus');
```

**Evidence**
```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); foreach($r as $x){ if(($x["name"]??"")==="system-config.dropdown.restore") printf("%-8s %-55s %s\n",$x["method"],$x["uri"],$x["action"]); }'
GET|HEAD system-config/dropdown/{id}/restore                     Modules\SystemConfig\Http\Controllers\TenantDropdownController@restore
```

#### TDC-11 · M · RTE-03 — `index()` is not routed

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`)* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:25-68`, method `index()` |
| **Root cause** | The list route `system-config.dropdown.index` is registered on `TenantDropdownNeedController@index` (`routes/tenant.php:140`). No route in `/tmp/fa-routes.json` points at `TenantDropdownController@index`, so the whole 44-line grouped-list builder (including its N+1 loop, TDC-18) is dead. |
| **Consequence** | No user-visible defect today, but the method is dead surface: a maintainer reading it will believe it serves the Dropdown List tab. |
| **Reproduce** | static only — `route:list` shows no route for `TenantDropdownController@index`. |
| **Fix approach** | Per D5, replace the body with `abort(403, '…')` and a `NOT ROUTED` comment; never delete it. See the TDC-11 item in `02-fix-plan.md` §5. |
| **Plan item** | TDC-11 in `02-fix-plan.md` §5 |

```php
// TenantDropdownController.php:25-29 — CURRENT
    public function index(Request $request)
    {
        Gate::authorize('tenant.system-config.dropdown.viewAny');

        $types = Dropdown::whereNotNull('type')->distinct()->orderBy('type')->pluck('type');
```

**Evidence**
```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); $n=0; foreach($r as $x){ if(str_contains($x["action"]??"","TenantDropdownController@index")){ $n++; echo $x["uri"],"\n"; } } echo "routes-to-index: $n\n";'
routes-to-index: 0
```

### F6 — Controller shape

#### TDC-12 · M · CTL-03 — four methods take a raw `$id` and call `findOrFail()` instead of using route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:137-143`, method `edit()` (also `destroy` :188, `restore` :230, `forceDelete` :260) |
| **Root cause** | The routes name their parameters `{dropdown}` (edit/destroy) and `{id}` (restore/force-delete), but these methods are typed `string $id` and load the row with `Dropdown::findOrFail($id)` / `Dropdown::withTrashed()->findOrFail($id)`. Laravel only binds a model when the argument is class-typed with the matching name, so no binding happens. |
| **Consequence** | No user-visible defect for a single parameter, but the white-list of soft-deleted rows is re-implemented by hand and the name mismatch silently disables implicit binding and its automatic 404. |
| **Reproduce** | static only — a routing-intent issue. |
| **Fix approach** | Type the parameters `Dropdown $dropdown` (and `Dropdown $dropdown` with `->withTrashed()` on the trash routes), removing the manual load. Done as part of the TDC-12 item in `02-fix-plan.md` §5. |
| **Plan item** | TDC-12 in `02-fix-plan.md` §5 |

```php
// TenantDropdownController.php:137-143 — CURRENT (edit())
    public function edit(string $id)
    {
        Gate::authorize('tenant.system-config.dropdown.update');

        $dropdown = Dropdown::findOrFail($id);

        return view('systemconfig::dropdown.edit', compact('dropdown'));
    }
```

**Evidence**
```
$ grep -nE "public function (edit|destroy|restore|forceDelete)|findOrFail" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
137:    public function edit(string $id)
141:        $dropdown = Dropdown::findOrFail($id);
188:    public function destroy(string $id)
194:                $dropdown = Dropdown::findOrFail($id);
230:    public function restore(string $id)
236:                $dropdown = Dropdown::withTrashed()->findOrFail($id);
260:    public function forceDelete(string $id)
266:                $dropdown = Dropdown::withTrashed()->findOrFail($id);
```

#### TDC-13 · L · CTL-04 — public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:25`, method `index()` (all 11 public methods) |
| **Root cause** | None of the 11 public methods declares a return type. |
| **Consequence** | No user-visible defect; the contract of each method is not expressed in the signature. |
| **Reproduce** | static only — a style issue. |
| **Fix approach** | Deferred this pass. Adding types requires new imports (`View`, `RedirectResponse`, `JsonResponse`) that would overlap the TDC-01/TDC-03/TDC-12 method rewrites; recorded in `02-fix-plan.md` §10. |
| **Plan item** | none — deferred (see `02-fix-plan.md` §10) |

```php
// TenantDropdownController.php:25 — CURRENT
    public function index(Request $request)
```

**Evidence**
```
$ grep -nE "public function [a-zA-Z_]+" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
25:    public function index(Request $request)
74:    public function create()
94:    public function store(TenantDropdownRequest $request)
137:    public function edit(string $id)
149:    public function update(TenantDropdownRequest $request, Dropdown $dropdown)
188:    public function destroy(string $id)
218:    public function trashed()
230:    public function restore(string $id)
260:    public function forceDelete(string $id)
289:    public function getColumns(Request $request)
314:    public function toggleStatus(Request $request, Dropdown $dropdown)
```

#### TDC-14 · H · CTL-06 — `create()` offers all 827 tenant tables but `getColumns()` accepts only three

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M, raised to H because a normal admin path cannot be completed) — *business logic lives in one place; here the table list the form offers and the whitelist the endpoint enforces are split and disagree* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:297-303`, method `getColumns()` (the table list comes from `create()` :80-83) |
| **Root cause** | `create()` runs `SHOW TABLES` on the tenant connection and passes **827** table names to the view. The view's Table dropdown lists them all, then calls `GET /system-config/dropdown/columns?table_name=…`. `getColumns()` whitelists only `['sys_dropdown_table', 'sys_settings', 'sys_users']`, so every other table returns `422 {"error":"Invalid table"}` and the Column dropdown never loads. |
| **Consequence** | A school admin can pick 824 of the 827 tables offered and the Column list always fails; only the three whitelisted tables can build a key. The create screen looks broken. |
| **Reproduce** | Open `/system-config/dropdown/create`, choose any table other than `sys_dropdown_table`, `sys_settings` or `sys_users` — the Column dropdown stays on "Loading…" / "Error loading columns". |
| **Fix approach** | A product decision: either narrow `create()`'s table list to the same whitelist, or widen the whitelist to the tables the form is meant to support. Recorded as DECISION TDC-14 in `02-fix-plan.md` §9. |
| **Plan item** | TDC-14 (DECISION) in `02-fix-plan.md` §9 |

```php
// TenantDropdownController.php:297-303 — CURRENT (getColumns())
        $allowedTables = ['sys_dropdown_table', 'sys_settings', 'sys_users'];
        if (!in_array($request->table_name, $allowedTables, true)) {
            return response()->json(['error' => 'Invalid table'], 422);
        }

        try {
            $columns = Schema::connection('tenant')->getColumnListing($request->table_name);
```

**Evidence**
```
$ DB=xyz_school_00000000000040008000_202627; mysql -uroot -p'***' -N -e "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA='$DB';"
827

$ grep -n "allowedTables" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
297:        $allowedTables = ['sys_dropdown_table', 'sys_settings', 'sys_users'];
```

### F7 — Models

#### TDC-15 · H · MDL-02 — the `additional_info` JSON column has no cast, so `store()` writes invalid JSON

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M, raised to H because the missing cast makes the create write path fail) — *`$casts` for every boolean, date, decimal, json/array and enum column* |
| **Where** | `Modules/SystemConfig/app/Models/Dropdown.php:23-27`, class `Dropdown` |
| **Root cause** | `sys_dropdown_table.additional_info` is a **JSON** column, but `Dropdown::$casts` lists only `ordinal`, `is_active` and `deleted_at`. `store()` and `update()` assign the raw form string (e.g. `A+`) to `additional_info`; without an `array`/`json` cast Eloquent sends the bare string, which MySQL rejects as invalid JSON. The edit view confirms the intended shape by calling `json_decode($dropdown->getRawOriginal('additional_info'))` by hand. |
| **Consequence** | Whenever a school admin fills the "Additional Info" field (the create form's `additional_info` input, or the edit form's textarea), the write fails and the admin sees "The operation could not be completed."; leaving it blank works, which makes the failure look random. |
| **Reproduce** | Open `/system-config/dropdown/create`, fill "Additional Info", save — the request fails; MySQL returns error 3140 (invalid JSON text). |
| **Fix approach** | Add `'additional_info' => 'array'` to `$casts` so Eloquent JSON-encodes the value on write. See the TDC-15 item in `02-fix-plan.md` §5. |
| **Plan item** | TDC-15 in `02-fix-plan.md` §5 |

```php
// Dropdown.php:23-27 — CURRENT
    protected $casts = [
        'ordinal' => 'integer',
        'is_active' => 'boolean',
        'deleted_at' => 'datetime',
    ];
```

**Evidence**
```
$ grep -n "additional_info" database/migrations/tenant/2026_06_15_145406_create_sys_dropdown_table.php
24:            $table->json('additional_info')->nullable();

$ DB=xyz_school_00000000000040008000_202627; mysql -uroot -p'***' -e "SHOW COLUMNS FROM $DB.sys_dropdown_table;" | grep additional_info
additional_info	json	YES		NULL

$ mysql -uroot -p'***' -N -e "SELECT CAST('hello' AS JSON);"
ERROR 3141 (22032) at line 1: Invalid JSON text in argument 1 to function cast_as_json: "Invalid value." at position 0.
```

#### TDC-16 · H · MDL-06 — `store()` slugs the key, turning `table.column` into `tablecolumn`, so consumers never see it

| Field | Value |
|---|---|
| **Rule** | MDL-06 (M, raised to H because the wrong value silently makes the created dropdown unusable) — *data normalisation belongs in mutators/`Attribute` casts, and here the normalisation is wrong* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:103-111`, method `store()` |
| **Root cause** | The create form builds the key as `table.column` (create.blade.php `keyEl.value = tableEl.value + '.' + this.value`). `store()` then passes that key through `Str::slug($data['key'], '_')`, which **drops the dot**: `Str::slug('msh_marksheet_schedules.status_id', '_')` returns `msh_marksheet_schedulesstatus_id`. Every existing row and every consumer use the dotted form (`EntityGroupMemberResolver::TYPE_KEY = 'sch_entity_groups_members.entity_type_id'`; `MarksheetGeneration` seeds and queries `'msh_marksheet_schedules.status_id'`). |
| **Consequence** | A dropdown value added through the UI is stored under a key no reader checks — the dropdown is created and listed under a mangled group, but the forms that should use it keep finding nothing. The failure is silent (the save reports success). |
| **Reproduce** | Open `/system-config/dropdown/create`, pick `sys_dropdown_table` + `status_id`, save, then open `/system-config/dropdown?tab=dropdown-list`: the new value is grouped under `sys_dropdown_tablestatus_id`, not `sys_dropdown_table.status_id`. |
| **Fix approach** | Stop slugging the key; store it as submitted (the column is `varchar(160)` and the dotted form is what the schema and consumers use). Done as part of the TDC-01 `store()` rewrite. |
| **Plan item** | none — resolved by the TDC-01 item (see `02-fix-plan.md` §10) |

```php
// TenantDropdownController.php:103-111 — CURRENT
                $maxOrdinal = Dropdown::where('key', Str::slug($data['key'], '_'))->max('ordinal') ?? 0;
                $ordinal    = $maxOrdinal + 1;

                $additionalInfo = !empty($data['additional_info']) ? $data['additional_info'] : null;

                foreach ($values as $value) {
                    $dropdown = Dropdown::create([
                        'ordinal'  => $ordinal++,
                        'key'      => Str::slug($data['key'], '_'),
```

**Evidence**
```
$ php -r 'require "vendor/autoload.php"; use Illuminate\Support\Str; echo Str::slug("msh_marksheet_schedules.status_id","_"),PHP_EOL;'
msh_marksheet_schedulesstatus_id

$ grep -rn "sch_entity_groups_members.entity_type_id" Modules/SchoolSetup/app/Services/EntityGroupMemberResolver.php
24:    public const TYPE_KEY = 'sch_entity_groups_members.entity_type_id';

$ DB=xyz_school_00000000000040008000_202627; mysql -uroot -p'***' -N -e "SELECT DISTINCT \`key\` FROM $DB.sys_dropdown_table LIMIT 4;"
msh_marksheet_schedules.status_id
lmsexam.allocation_type
lmsexam.offline_entry_mode
vnd_agreement_items_jnt.related_entity_type
```

#### TDC-17 · L · MDL-04 — relationship methods have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany` …)* |
| **Where** | `Modules/SystemConfig/app/Models/Dropdown.php:33-48`, class `Dropdown` |
| **Root cause** | `dropdownNeeds()` and `junction()` declare no return type. |
| **Consequence** | No user-visible defect; the relation type is not expressed and static analysis cannot check the call sites. |
| **Reproduce** | static only — a style issue. |
| **Fix approach** | Add `: BelongsToMany` and `: HasOne` (see the TDC-17 item in `02-fix-plan.md` §5). |
| **Plan item** | TDC-17 in `02-fix-plan.md` §5 |

```php
// Dropdown.php:33-48 — CURRENT
    public function dropdownNeeds()
    {
        return $this->belongsToMany(
            DropdownNeed::class,
            'sys_dropdown_need_dropdowns_jnt',
            'dropdown_table_id',
            'dropdown_needs_id'
        )->wherePivot('is_active', true)
            ->withPivot('is_active');
    }

    public function junction()
    {
        return $this->hasOne(DropdownNeedDropdown::class, 'dropdown_table_id');
    }
```

**Evidence**
```
$ grep -nE "public function (dropdownNeeds|junction)" Modules/SystemConfig/app/Models/Dropdown.php
34:    public function dropdownNeeds()
45:    public function junction()
```

Checked, not present: `$guarded = []` (a `$fillable` is declared and holds no sensitive column), a missing `$table` (the rename migration `2026_06_15_145407_rename_sys_dropdown_table_to_sys_dropdowns.php` is a self-rename — `sys_dropdown_table` → `sys_dropdown_table` — and the table exists), `SoftDeletes` without a `deleted_at` column (`sys_dropdown_table` has `deleted_at`), `InteractsWithMedia` (not used). The scanner's **MDL-03** candidate on `dropdownNeeds()` was checked and is a **false positive**: the pivot table `sys_dropdown_need_dropdowns_jnt` has no `deleted_at` column, so `wherePivotNull('deleted_at')` is not applicable.

**Evidence**
```
$ DB=xyz_school_00000000000040008000_202627; mysql -uroot -p'***' -N -e "SHOW COLUMNS FROM $DB.sys_dropdown_need_dropdowns_jnt;"
id	int unsigned	NO	PRI	NULL	auto_increment
dropdown_needs_id	int unsigned	NO	MUL	NULL	
dropdown_table_id	int unsigned	NO	MUL	NULL	
is_active	tinyint(1)	NO		1	
created_at	timestamp	YES		NULL	
updated_at	timestamp	YES		NULL	
```

### F8 — Services and jobs

clean — the controller uses no service, job, event or listener. Proved by:
```
$ grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b' Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php | sort -u
(no output)
```

### F9 — Queries and performance

#### TDC-18 · H · QRY-01 — `index()` runs one query per key inside a loop (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; eager-load with `with()`, pre-fetch into a keyed collection (`->keyBy('id')`), or bulk-write* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:46-66`, method `index()` |
| **Root cause** | The method paginates 10 keys, then for each key builds `Dropdown::where('key', $item->key)` and calls `->get()` inside the `foreach`, so the page runs 1 + 10 queries (plus up to 2 more per key for the status/type filters). |
| **Consequence** | The Dropdown List page issues at least 11 queries per load where one grouped query would do. Because `index()` is unrouted (TDC-11), it does not hit users today, but the same grouping is what the live `dropdown-list` tab needs. |
| **Reproduce** | static only — the loop is measurable in the query log of one load; the route is unrouted so no browser path reaches it. |
| **Fix approach** | Deleted with the TDC-11 item, which disables `index()` per D5. If the method is ever re-routed, replace the loop with one `Dropdown::whereIn('key', $keys->pluck('key'))->get()->groupBy('key')`. Recorded in `02-fix-plan.md` §10. |
| **Plan item** | none — the TDC-11 item disables the method (see `02-fix-plan.md` §10) |

```php
// TenantDropdownController.php:46-66 — CURRENT
        $groupedDropdowns = collect();
        foreach ($keys as $item) {
            $dropdownQuery = Dropdown::where('key', $item->key);

            if ($request->input('status') !== null && $request->input('status') !== '') {
                $dropdownQuery->where('is_active', (bool) $request->input('status'));
            }

            if ($typeFilter) {
                $dropdownQuery->where('type', $typeFilter);
            }

            if ($search) {
                $dropdownQuery->where(function ($q) use ($search) {
                    $q->where('key', 'like', "%{$search}%")
                      ->orWhere('value', 'like', "%{$search}%");
                });
            }

            $groupedDropdowns->put($item->key, $dropdownQuery->get());
        }
```

**Evidence**
```
$ grep -n "foreach (\$keys as \$item)\|->get()" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
47:        foreach ($keys as $item) {
65:            $groupedDropdowns->put($item->key, $dropdownQuery->get());
```

#### TDC-19 · M · QRY-07 — `store()` inserts one row per value in a loop

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *bulk writes: `insert()`, `upsert()`, `whereIn(...)->update()` instead of `create()` per row in a loop* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:108-118`, method `store()` |
| **Root cause** | A comma-separated `value` is split into N values and each is inserted with a separate `Dropdown::create()` call, each followed by an `activityLog()` insert. A 20-value paste is 40 statements. |
| **Consequence** | No correctness defect; a large comma-separated list creates many round-trips inside one transaction. |
| **Reproduce** | static only — a performance concern. |
| **Fix approach** | Build the rows and use `Dropdown::insert()` (or `upsert()`), then write the audit entries after. Done as part of the TDC-01 `store()` rewrite. |
| **Plan item** | none — resolved by the TDC-01 item (see `02-fix-plan.md` §10) |

```php
// TenantDropdownController.php:108-118 — CURRENT
                foreach ($values as $value) {
                    $dropdown = Dropdown::create([
                        'ordinal'  => $ordinal++,
                        'key'      => Str::slug($data['key'], '_'),
                        'value'    => $value,
                        'type'     => $data['type'] ?? 'String',
                        'additional_info' => $additionalInfo,
                        'is_active' => $data['is_active'] ?? true,
                    ]);
                    activityLog($dropdown, 'Stored', ['message' => "Tenant dropdown '{$dropdown->key}' value '{$value}' created."]);
                }
```

**Evidence**
```
$ grep -n "Dropdown::create" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
109:                    $dropdown = Dropdown::create([
```

#### TDC-20 · L · QRY-08 — leading-wildcard `LIKE` searches in `index()`

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M, lowered to L because `sys_dropdown_table` holds 716 rows and the route is unrouted) — *leading-wildcard `LIKE '%x%'` cannot use an index* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:33-38`, method `index()` (also :59-62) |
| **Root cause** | The search wraps the term as `"%{$search}%"` on `key` and `value`, so no index can be used. |
| **Consequence** | No user-visible impact at 716 rows, and the method is unrouted today. |
| **Reproduce** | static only — a performance concern. |
| **Fix approach** | Accepted for this size and because TDC-11 disables the method; recorded in `02-fix-plan.md` §10. |
| **Plan item** | none — accepted (see `02-fix-plan.md` §10) |

```php
// TenantDropdownController.php:33-38 — CURRENT
        if ($search = $request->input('search')) {
            $keysQuery->where(function ($q) use ($search) {
                $q->where('key', 'like', "%{$search}%")
                  ->orWhere('value', 'like', "%{$search}%");
            });
        }
```

**Evidence**
```
$ grep -c "like', \"%{" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
4
```

#### TDC-21 · L · QRY-13 — `trashed()` paginates 15, not the house default 10

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L) — *filtered paginators keep filters; multiple paginators on one page use distinct page names; the house list size is 10* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:222`, method `trashed()` |
| **Root cause** | The trash list uses `->paginate(15)` while every other list in the module uses 10. |
| **Consequence** | No user-visible defect; the trash page shows a different page size from the rest of the module. |
| **Reproduce** | static only — a consistency issue. |
| **Fix approach** | Change `paginate(15)` to `paginate(10)`. See the TDC-21 item in `02-fix-plan.md` §6. |
| **Plan item** | TDC-21 in `02-fix-plan.md` §6 |

```php
// TenantDropdownController.php:222 — CURRENT
        $dropdowns = Dropdown::onlyTrashed()->orderBy('key')->paginate(15);
```

**Evidence**
```
$ grep -n "paginate(" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
44:        $keys = $keysQuery->paginate(10)->withQueryString();
222:        $dropdowns = Dropdown::onlyTrashed()->orderBy('key')->paginate(15);
```

### F10 — Views

clean — no `{!! !!}` in any of the five blades (nothing is rendered unescaped), no `Model::`/`DB::`/`->where(`/`->get()` query in Blade, and row values are escaped (`{{ $dropdown->value }}`). The row status switch uses the shared `x-backend.table.status-switch`, which addresses rows with `statusSwitch-{id}` and posts to `data-url`. Proved by:
```
$ grep -n '{!!' Modules/SystemConfig/resources/views/dropdown/index.blade.php Modules/SystemConfig/resources/views/dropdown/create.blade.php Modules/SystemConfig/resources/views/dropdown/edit.blade.php Modules/SystemConfig/resources/views/dropdown/trash.blade.php Modules/SystemConfig/resources/views/dropdown/dropdown-list.blade.php
(no output)

$ grep -nE "Model::|DB::|->where\(|->get\(\)|->count\(\)" Modules/SystemConfig/resources/views/dropdown/dropdown-list.blade.php Modules/SystemConfig/resources/views/dropdown/index.blade.php
(no output)
```
The trash view's row actions use `x-backend.table.action-trashed`; it is the shared component that renders restore as a GET form (the cause noted in TDC-10), which is why the route fix is the correct place to change the verb.

### F11 — Security and tenancy

clean — no `env()` outside config, no `$request->all()`/`except()` into a model, no hard-coded ids or `?? 1`, no request bodies or secrets in logs, no central models reached from tenant context, no file URLs. The `getColumns()` whitelist is a real control (it limits `getColumnListing` to three tables); its mismatch with `create()` is TDC-14, a functional defect, not a leak. Proved by:
```
$ grep -nE "env\(|->all\(\)|except\(|\\?\\? 1" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php
(no output)
```

### F12 — Style

#### TDC-22 · L · STY-02 / STY-04 — the controller is not Pint-clean and repeats a copied comment

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, no stray blank lines between imports*; STY-04 (L) — *no copy-pasted comments* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:7-18` |
| **Root cause** | The imports are out of order with blank lines between them (`use App\Http\Controllers\Controller;` after `use Illuminate\Support\Facades\Log;`), and the three-line "Rule A1: a missing record must stay a 404…" comment is copy-pasted into all six mutating methods. |
| **Consequence** | No runtime effect; the file drifts from the project's formatting and the repeated comment adds noise to a change that removes those catches. |
| **Reproduce** | static only — a style issue. |
| **Fix approach** | Run Pint on the controller, model and request after the method rewrites (see the TDC-22 item in `02-fix-plan.md` §8); the copied comments are removed with the catches. |
| **Plan item** | TDC-22 in `02-fix-plan.md` §8 |

```php
// TenantDropdownController.php:7-18 — CURRENT
use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Modules\SystemConfig\Models\Dropdown;
use Modules\SystemConfig\Http\Requests\TenantDropdownRequest;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php Modules/SystemConfig/app/Models/Dropdown.php Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SystemConfig\/app\/Http\/Controllers\/TenantDropdownController.php","fixers":["function_declaration","single_quote","control_structure_braces","concat_space","method_chaining_indentation","braces_position","statement_indentation","not_operator_with_successor_space","no_extra_blank_lines","ordered_imports","binary_operator_spaces"]},{"path":"Modules\/SystemConfig\/app\/Models\/Dropdown.php","fixers":["trailing_comma_in_multiline"]},{"path":"Modules\/SystemConfig\/app\/Http\/Requests\/TenantDropdownRequest.php","fixers":["blank_line_before_statement"]}]}
```

#### TDC-23 · L · STY-01 — the `Dropdown` model has no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `Modules/SystemConfig/app/Models/Dropdown.php:1-3`, class `Dropdown` |
| **Root cause** | The model omits `declare(strict_types=1)`. |
| **Consequence** | No runtime effect; the model does not get strict parameter checking when it is next touched. |
| **Reproduce** | static only — a style issue. |
| **Fix approach** | Add `declare(strict_types=1);` (folded into the TDC-17 model item in `02-fix-plan.md` §5). |
| **Plan item** | none — folded into the TDC-17 item (see `02-fix-plan.md` §10) |

```php
// Dropdown.php:1-3 — CURRENT
<?php

namespace Modules\SystemConfig\Models;
```

**Evidence**
```
$ grep -n "declare(strict_types" Modules/SystemConfig/app/Models/Dropdown.php
(no output)
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicates | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store()` | TDC-16 (mangled key), TDC-09 (inactive) | ok — inserts only | ok — the one create path | TDC-07 (trashed ordinals hidden from `max()`) | TDC-07 | ok — `Gate::authorize` first | ok — `created.dropdown` follows the write | TDC-19 (per-row inserts) |
| `update()` | TDC-09 (edit resets active) | ok — updates in place | ok — the edit form and the list both call this | ok — no key/ordinal rewrite | ok — last-write-wins | ok — gate first, binding 404s | ok — `updated.dropdown` | ok |
| `destroy()` | ok — sets `is_active=0` then soft-deletes | ok — soft delete, restorable | ok | ok | ok | ok — gate first | ok — `trashed.dropdown` | ok |
| `restore()` | ok — restores and re-activates | ok | ok | ok | ok | ok — gate first | ok — `restored.dropdown` | TDC-10 (GET) |
| `forceDelete()` | ok — removes the junction row then the row | ok — junction removed with the row | ok | ok | ok | ok — gate first | TDC-06 (audit before delete) | ok |
| `toggleStatus()` | ok — flips one flag | ok | ok | ok | ok | ok — gate first | TDC-06 (audit before save) | TDC-03 (failure is a redirect) |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php` | Owns the live `system-config.dropdown.index` route and renders the shared `index.blade.php` + `dropdown-list.blade.php`; its own audit will cover the live list path | RTE-03 | its own report (audited later) |
| `app/Helpers/activityLog.php` | Common helper that writes `sys_activity_logs`; referenced by the controller, not audited here | TXN-01 | common (`app/` glue) |
| `resources/views/components/backend/form/status-switch.blade.php` | Posts the switch as `value="1"`; the controller's normaliser expects `'on'` (TDC-09). The component is shared by the whole app, so changing it would move the bug, not fix it | — | the controller fix (TDC-09) owns the correct side |
| `resources/views/components/backend/table/action-trashed.blade.php` | Renders restore as a GET form because the route is GET; after TDC-10's route fix it renders `@method('DELETE')` with no component change | RTE-01 | resolved by TDC-10 |
| `config/permissionslist.php` | Declares seven verbs for `system-config.dropdown` at line 346; `index`/`getColumns` check `viewAny`, and `.view` is seeded but never checked | AUTH-06 | app-wide permissions cleanup |

## 8. Not covered, and why

- **No HTTP request was dispatched.** D4 forbids tests, so the routes, the model binding, the `is_active` result and the invalid-JSON write were established from `route:list`, the schema and static evidence, plus a read-only `SELECT CAST('hello' AS JSON)` to prove MySQL rejects a bare string. No authenticated tenant request was made.
- **The create page's JavaScript was read, not executed.** The `fetch(.../columns?table_name=…)` flow in `create.blade.php` was reviewed statically; the 827-vs-3 mismatch (TDC-14) is proven from the table count and the whitelist, not from a browser run.
- **The index Blade was read, not rendered.** `index.blade.php` and `dropdown-list.blade.php` are shared with `TenantDropdownNeedController`, which renders them live; they are linked here rather than audited fully.
- **Queue jobs, events and mail:** none are used by this controller.
