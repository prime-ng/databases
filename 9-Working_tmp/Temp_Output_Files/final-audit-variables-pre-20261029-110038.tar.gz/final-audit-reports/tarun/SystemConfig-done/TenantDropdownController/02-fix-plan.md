# Fix Plan — SystemConfig / TenantDropdownController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `routes/tenant.php` | shared route file; only the TDC-10 DECISION may edit it |
| `config/permissionslist.php` | shared; no change required |
| `database/migrations/tenant/2026_06_15_145406_create_sys_dropdown_table.php` | existing migration — never edited |
| `database/migrations/tenant/2026_06_15_145408_create_sys_dropdown_need_dropdowns_jnt_table.php` | existing migration — never edited |
| `resources/views/components/backend/form/status-switch.blade.php` | shared component used across the app; TDC-09 fixes the controller side |
| `resources/views/components/backend/table/status-switch.blade.php` | shared component |
| `resources/views/components/backend/table/action-trashed.blade.php` | shared component; it adapts to the TDC-10 route verb on its own |
| `Modules/SystemConfig/resources/views/dropdown/index.blade.php` | shared blade, rendered live by `TenantDropdownNeedController` |
| `Modules/SystemConfig/resources/views/dropdown/dropdown-list.blade.php` | shared blade, rendered live by `TenantDropdownNeedController` |
| `Modules/SystemConfig/app/Http/Controllers/TenantDropdownNeedController.php` | separate controller, separate report |

## 1. Blockers reachable today

- [ ] **TDC-09** · H · VAL-05 · `Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php:38-43` — stop forcing `is_active` to `false`; the switch posts `"1"`, not `"on"`.
  - **Touches:** `Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php`
  - **Before** (`TenantDropdownRequest.php:38-43`):
    ```php
    protected function prepareForValidation(): void
    {
        $this->merge([
            'is_active' => $this->has('is_active') && $this->input('is_active') === 'on' ? true : false,
        ]);
    }
    ```
  - **After:**
    ```php
    protected function prepareForValidation(): void
    {
        $this->merge([
            'is_active' => $this->boolean('is_active'),
        ]);
    }
    ```
    `$this->boolean('is_active')` returns `true` for `"1"`, `"on"`, `1` and `true`, and `false` when the field is absent. The rest of `rules()` and `authorize()` is unchanged.
  - **Verify:** `grep -n "boolean('is_active')" Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php`
  - **Expect:** one line: `'is_active' => $this->boolean('is_active'),`
  - **Effort:** S

- [ ] **TDC-03** · H · ERR-04 · `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:318-338` — make the toggle endpoint fail with JSON, not an HTML redirect, and audit after the write.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Before** (`TenantDropdownController.php:318-338`):
    ```php
        try {
            return DB::transaction(function () use ($dropdown) {
                $dropdown->is_active = !$dropdown->is_active;
                activityLog($dropdown, 'Toggled', ['message' => "Tenant dropdown status toggled.", 'new_status' => $dropdown->is_active ? 'Active' : 'Inactive']);

                if ($dropdown->save()) {
                    return response()->json(['success' => true, 'is_active' => $dropdown->is_active, 'message' => flash('status_updated.dropdown')]);
                }

                return response()->json(['success' => false, 'is_active' => $dropdown->is_active, 'message' => flash('status_switch_failed.dropdown')]);

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('TenantDropdownController::toggleStatus failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($dropdown) {
            $dropdown->is_active = !$dropdown->is_active;
            $dropdown->save();

            activityLog($dropdown, 'Toggled', [
                'message' => 'Tenant dropdown status toggled.',
                'new_status' => $dropdown->is_active ? 'Active' : 'Inactive',
            ]);
        });

        return response()->json([
            'success' => true,
            'is_active' => $dropdown->is_active,
            'message' => flash('status_updated.dropdown'),
        ]);
    ```
    This replaces the whole body from the first `try {` to the last closing brace of the method; the method's final `}` stays after the `return`. `$dropdown->save()` on a bound model cannot return `false` on a normal row, so the `status_switch_failed.dropdown` branch is dropped.
  - **Verify:** `grep -nE "try \{|catch \(|back\(\)->with" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Expect:** after all ticked items, no output.
  - **Effort:** S

- [ ] **TDC-14** · H · DECISION · CTL-06 — the create form offers 827 tenant tables but `getColumns()` allows only three. Which side changes?
  - **Why it is a decision:** it changes what tables the client may list columns for — a product/security choice, not a mechanical fix.
  - (a) ⭐ **Narrow `create()`'s table list to the three whitelisted tables** (`sys_dropdown_table`, `sys_settings`, `sys_users`) — the Column dropdown then works for every table the form shows; no `getColumns()` change and no new exposure.
  - (b) **Widen the `getColumns()` whitelist** to the tables the dropdown feature is meant to support — re-opens schema probing for those tables.
  - (c) **Leave as is** and record TDC-14 as accepted — the create screen keeps failing for 824 of 827 tables.
  - ➜ Choice: ____

## 2. Fixes that arm a latent defect (sequenced)

_None._

## 3. Errors & transactions (F1/F2)

- [ ] **TDC-01** · H · ERR-00 (D1) · `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:98-131` and `:154-182` — rewrite `store()` and `update()`: remove the Variant-H `try/catch`, store the key as submitted (not slugged), lock the ordinal read, and build the response after the transaction.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Before** (`TenantDropdownController.php:98-131`, `store()`):
    ```php
            try {
                return DB::transaction(function () use ($request) {
                    $data   = $request->validated();
                    $values = array_unique(array_filter(array_map('trim', explode(',', $data['value']))));

                    $maxOrdinal = Dropdown::where('key', Str::slug($data['key'], '_'))->max('ordinal') ?? 0;
                    $ordinal    = $maxOrdinal + 1;

                    $additionalInfo = !empty($data['additional_info']) ? $data['additional_info'] : null;

                    foreach ($values as $value) {
                        $dropdown = Dropdown::create([
                            'ordinal'  => $ordinal++,
                            'key'      => Str::slug($data['key'], '_'),
                            'value'    => $value,
                            'type'     => $data['type'] ?? 'String',
                            'additional_info' => $additionalInfo,
                            'is_active' => $data['is_active'] ?? true,
                        ]);
                        activityLog($dropdown, 'Stored', ['message' => "Tenant dropdown '{$dropdown->key}' value '{$value}' created."]);
                    }

                    return redirect()->route('system-config.dropdown.index')->with('success', flash('created.dropdown'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('TenantDropdownController::store failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **Before** (`TenantDropdownController.php:154-182`, `update()`):
    ```php
            try {
                return DB::transaction(function () use ($dropdown, $validated) {
                    if (!isset($validated['additional_info']) || empty($validated['additional_info'])) {
                        $validated['additional_info'] = $dropdown->additional_info;
                    }

                    $original = $dropdown->getOriginal();
                    $dropdown->update($validated);

                    $changes = [];
                    foreach ($dropdown->getChanges() as $field => $new) {
                        if ($field === 'updated_at') continue;
                        $changes[$field] = ['old' => $original[$field] ?? null, 'new' => $new];
                    }

                    activityLog($dropdown, 'Updated', ['message' => "Tenant dropdown updated.", 'changes' => $changes]);

                    return redirect()->route('system-config.dropdown.index')->with('success', flash('updated.dropdown'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('TenantDropdownController::update failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:** `store()`
    ```php
        public function store(TenantDropdownRequest $request)
        {
            Gate::authorize('tenant.system-config.dropdown.create');

            $data = $request->validated();
            $values = array_unique(array_filter(array_map('trim', explode(',', $data['value']))));

            DB::transaction(function () use ($data, $values) {
                $ordinal = ((int) Dropdown::where('key', $data['key'])->orderByDesc('ordinal')->lockForUpdate()->value('ordinal')) + 1;
                $additionalInfo = !empty($data['additional_info']) ? $data['additional_info'] : null;

                foreach ($values as $value) {
                    $dropdown = Dropdown::create([
                        'ordinal' => $ordinal++,
                        'key' => $data['key'],
                        'value' => $value,
                        'type' => $data['type'] ?? 'String',
                        'additional_info' => $additionalInfo,
                        'is_active' => $data['is_active'] ?? true,
                    ]);

                    activityLog($dropdown, 'Stored', ['message' => "Tenant dropdown '{$dropdown->key}' value '{$value}' created."]);
                }
            });

            return redirect()->route('system-config.dropdown.index')->with('success', flash('created.dropdown'));
        }
    ```
  - **After:** `update()`
    ```php
        public function update(TenantDropdownRequest $request, Dropdown $dropdown)
        {
            Gate::authorize('tenant.system-config.dropdown.update');
            $validated = $request->validated();

            if (!isset($validated['additional_info']) || empty($validated['additional_info'])) {
                $validated['additional_info'] = $dropdown->additional_info;
            }

            DB::transaction(function () use ($dropdown, $validated) {
                $original = $dropdown->getOriginal();
                $dropdown->update($validated);

                $changes = [];
                foreach ($dropdown->getChanges() as $field => $new) {
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changes[$field] = ['old' => $original[$field] ?? null, 'new' => $new];
                }

                activityLog($dropdown, 'Updated', ['message' => 'Tenant dropdown updated.', 'changes' => $changes]);
            });

            return redirect()->route('system-config.dropdown.index')->with('success', flash('updated.dropdown'));
        }
    ```
    The key is stored as submitted (the dot is kept), fixing TDC-16; the ordinal read is locked, fixing TDC-07; the response is built after the transaction, fixing TDC-05 for these two methods.
  - **Verify:** `grep -nE "try \{|catch \(|Log::error|Str::slug" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Expect:** after all ticked items, no output.
  - **Effort:** M

- [ ] **TDC-04** · M · ERR-07 · `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:79-86` and `:302-308` — remove the `try/catch` from the two read methods.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Before** (`TenantDropdownController.php:79-86`, `create()`):
    ```php
            try {
                $result = DB::connection('tenant')->select('SHOW TABLES');
                $key = 'Tables_in_' . DB::connection('tenant')->getDatabaseName();
                $tables = array_map(fn($t) => $t->$key, $result);
                sort($tables);
            } catch (\Exception $e) {
                $tables = [];
            }
    ```
  - **Before** (`TenantDropdownController.php:302-308`, `getColumns()`):
    ```php
            try {
                $columns = Schema::connection('tenant')->getColumnListing($request->table_name);

                return response()->json($columns);
            } catch (\Exception $e) {
                return response()->json(['error' => 'Invalid table'], 422);
            }
    ```
  - **After:** `create()`
    ```php
            $result = DB::connection('tenant')->select('SHOW TABLES');
            $key = 'Tables_in_' . DB::connection('tenant')->getDatabaseName();
            $tables = array_map(fn($t) => $t->$key, $result);
            sort($tables);
    ```
  - **After:** `getColumns()`
    ```php
            $columns = Schema::connection('tenant')->getColumnListing($request->table_name);

            return response()->json($columns);
    ```
    A real database failure now reaches the central handler in `bootstrap/app.php`, which logs it with its trace.
  - **Verify:** `grep -nE "catch \(\\\\Exception" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

_No item — TDC-08 is recorded as accepted in §10._

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **TDC-11** · M · RTE-03 · `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:25-68` — disable the unrouted `index()` per D5.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Before** (`TenantDropdownController.php:25-68`):
    ```php
        public function index(Request $request)
        {
            Gate::authorize('tenant.system-config.dropdown.viewAny');

            $types = Dropdown::whereNotNull('type')->distinct()->orderBy('type')->pluck('type');

            $keysQuery = Dropdown::select('key')->groupBy('key')->orderBy('key');

            if ($search = $request->input('search')) {
                $keysQuery->where(function ($q) use ($search) {
                    $q->where('key', 'like', "%{$search}%")
                      ->orWhere('value', 'like', "%{$search}%");
                });
            }

            if ($typeFilter = $request->input('type')) {
                $keysQuery->where('type', $typeFilter);
            }

            $keys = $keysQuery->paginate(10)->withQueryString();

            $groupedDropdowns = collect();
            foreach ($keys as $item) {
                $dropdownQuery = Dropdown::where('key', $item->key);

                if ($request->input('status') !== null && $request->input('status') !== '') {
                    $dropdownQuery->where('is_active', (bool) $request->input('status'));
                }

                if ($typeFilter) {
                    $dropdownQuery->where('type', $typeFilter);
                }

                if ($search) {
                    $dropdownQuery->where(function ($q) use ($search) {
                        $q->where('key', 'like', "%{$search}%")
                          ->orWhere('value', 'like', "%{$search}%");
                    });
                }

                $groupedDropdowns->put($item->key, $dropdownQuery->get());
            }

            return view('systemconfig::dropdown.index', compact('groupedDropdowns', 'keys', 'types'));
    ```
  - **After:**
    ```php
        public function index(Request $request)
        {
            // NOT ROUTED — no route points at TenantDropdownController@index. The live
            // /system-config/dropdown list is served by TenantDropdownNeedController@index
            // (routes/tenant.php:140). Kept per D5; never reachable.
            abort(403, 'This screen is not available.');
        }
    ```
    This replaces the whole method body through its closing `}` at line 68; the `Request $request` argument stays so the signature is unchanged.
  - **Verify:** `grep -n "NOT ROUTED" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Expect:** one line.
  - **Effort:** S

- [ ] **TDC-12** · M · CTL-03 · `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:137-143`, `:192-212`, `:234-254`, `:264-286` — use route model binding in `edit()`/`destroy()`, and remove the `try/catch` from the trash methods, auditing after the write.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Before** (`TenantDropdownController.php:137-143`, `edit()`):
    ```php
        public function edit(string $id)
        {
            Gate::authorize('tenant.system-config.dropdown.update');

            $dropdown = Dropdown::findOrFail($id);

            return view('systemconfig::dropdown.edit', compact('dropdown'));
        }
    ```
  - **After:** `edit()`
    ```php
        public function edit(Dropdown $dropdown)
        {
            Gate::authorize('tenant.system-config.dropdown.update');

            return view('systemconfig::dropdown.edit', compact('dropdown'));
        }
    ```
  - **Before** (`TenantDropdownController.php:192-212`, `destroy()`):
    ```php
            try {
                return DB::transaction(function () use ($id) {
                    $dropdown = Dropdown::findOrFail($id);
                    $dropdown->is_active = false;
                    $dropdown->save();
                    $dropdown->delete();

                    activityLog($dropdown, 'Trashed', ['message' => "Tenant dropdown '{$dropdown->key}' value '{$dropdown->value}' trashed."]);

                    return redirect()->route('system-config.dropdown.index')->with('success', flash('trashed.dropdown'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('TenantDropdownController::destroy failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:** `destroy()`
    ```php
        public function destroy(Dropdown $dropdown)
        {
            Gate::authorize('tenant.system-config.dropdown.delete');

            DB::transaction(function () use ($dropdown) {
                $dropdown->is_active = false;
                $dropdown->save();
                $dropdown->delete();

                activityLog($dropdown, 'Trashed', ['message' => "Tenant dropdown '{$dropdown->key}' value '{$dropdown->value}' trashed."]);
            });

            return redirect()->route('system-config.dropdown.index')->with('success', flash('trashed.dropdown'));
        }
    ```
  - **Before** (`TenantDropdownController.php:234-254`, `restore()`):
    ```php
            try {
                return DB::transaction(function () use ($id) {
                    $dropdown = Dropdown::withTrashed()->findOrFail($id);
                    $dropdown->restore();
                    $dropdown->is_active = true;
                    $dropdown->save();

                    activityLog($dropdown, 'Restored', ['message' => "Tenant dropdown '{$dropdown->key}' value '{$dropdown->value}' restored."]);

                    return redirect()->route('system-config.dropdown.trashed')->with('success', flash('restored.dropdown'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('TenantDropdownController::restore failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:** `restore()`
    ```php
        public function restore(string $id)
        {
            Gate::authorize('tenant.system-config.dropdown.restore');

            DB::transaction(function () use ($id) {
                $dropdown = Dropdown::withTrashed()->findOrFail($id);
                $dropdown->restore();
                $dropdown->is_active = true;
                $dropdown->save();

                activityLog($dropdown, 'Restored', ['message' => "Tenant dropdown '{$dropdown->key}' value '{$dropdown->value}' restored."]);
            });

            return redirect()->route('system-config.dropdown.trashed')->with('success', flash('restored.dropdown'));
        }
    ```
  - **Before** (`TenantDropdownController.php:264-286`, `forceDelete()`):
    ```php
            try {
                return DB::transaction(function () use ($id) {
                    $dropdown = Dropdown::withTrashed()->findOrFail($id);

                    DB::table('sys_dropdown_need_dropdowns_jnt')
                        ->where('dropdown_table_id', $dropdown->id)
                        ->delete();

                    activityLog($dropdown, 'Deleted', ['message' => "Tenant dropdown '{$dropdown->key}' permanently deleted."]);
                    $dropdown->forceDelete();

                    return redirect()->route('system-config.dropdown.trashed')->with('success', flash('force_deleted.dropdown'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('TenantDropdownController::forceDelete failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:** `forceDelete()`
    ```php
        public function forceDelete(string $id)
        {
            Gate::authorize('tenant.system-config.dropdown.forceDelete');

            DB::transaction(function () use ($id) {
                $dropdown = Dropdown::withTrashed()->findOrFail($id);

                DB::table('sys_dropdown_need_dropdowns_jnt')
                    ->where('dropdown_table_id', $dropdown->id)
                    ->delete();

                $dropdown->forceDelete();

                activityLog($dropdown, 'Deleted', ['message' => "Tenant dropdown '{$dropdown->key}' permanently deleted."]);
            });

            return redirect()->route('system-config.dropdown.trashed')->with('success', flash('force_deleted.dropdown'));
        }
    ```
    `edit()` and `destroy()` can take binding because their routes name the parameter `{dropdown}`. `restore()` and `forceDelete()` keep `withTrashed()->findOrFail($id)` because their route parameter is `{id}`; implicit binding of a trashed row needs `->withTrashed()` on the route, which is part of the TDC-10 DECISION.
  - **Verify:** `grep -nE "try \{|catch \(|findOrFail|activityLog" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Expect:** after all ticked items, no `try {`, no `catch (`, and `activityLog` after each write.
  - **Effort:** M

- [ ] **TDC-15** · H · MDL-02 · `Modules/SystemConfig/app/Models/Dropdown.php:23-27` — cast the `additional_info` JSON column so the create write path stops failing.
  - **Touches:** `Modules/SystemConfig/app/Models/Dropdown.php`
  - **Before** (`Dropdown.php:23-27`):
    ```php
        protected $casts = [
            'ordinal' => 'integer',
            'is_active' => 'boolean',
            'deleted_at' => 'datetime',
        ];
    ```
  - **After:**
    ```php
        protected $casts = [
            'ordinal' => 'integer',
            'is_active' => 'boolean',
            'additional_info' => 'array',
            'deleted_at' => 'datetime',
        ];
    ```
    With the `array` cast Eloquent JSON-encodes the value on write, so `additional_info = 'A+'` is stored as the valid JSON string `"A+"` instead of failing with MySQL error 3140.
  - **Verify:** `grep -n "'additional_info' => 'array'" Modules/SystemConfig/app/Models/Dropdown.php`
  - **Expect:** one line: `'additional_info' => 'array',`
  - **Effort:** S

- [ ] **TDC-17** · L · MDL-04 · `Modules/SystemConfig/app/Models/Dropdown.php:1-3` and `:33-48` — add `strict_types` and return-type the relationships.
  - **Touches:** `Modules/SystemConfig/app/Models/Dropdown.php`
  - **Before** (`Dropdown.php:1-3`):
    ```php
    <?php

    namespace Modules\SystemConfig\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SystemConfig\Models;
    ```
  - **Before** (`Dropdown.php:33-48`):
    ```php
        public function dropdownNeeds()
        {
            return $this->belongsToMany(
                DropdownNeed::class,
                'sys_dropdown_need_dropdowns_jnt',
                'dropdown_table_id',
                'dropdown_needs_id'
            )->wherePivot('is_active', true)
                ->withPivot('is_active');
        }

        public function junction()
        {
            return $this->hasOne(DropdownNeedDropdown::class, 'dropdown_table_id');
        }
    ```
  - **After:**
    ```php
        public function dropdownNeeds(): BelongsToMany
        {
            return $this->belongsToMany(
                DropdownNeed::class,
                'sys_dropdown_need_dropdowns_jnt',
                'dropdown_table_id',
                'dropdown_needs_id'
            )->wherePivot('is_active', true)
                ->withPivot('is_active');
        }

        public function junction(): HasOne
        {
            return $this->hasOne(DropdownNeedDropdown::class, 'dropdown_table_id');
        }
    ```
    Add these two imports after the existing `use Illuminate\Database\Eloquent\SoftDeletes;` line:
    ```php
    use Illuminate\Database\Eloquent\Relations\BelongsToMany;
    use Illuminate\Database\Eloquent\Relations\HasOne;
    ```
  - **Verify:** `grep -nE "declare\(strict_types|: BelongsToMany|: HasOne" Modules/SystemConfig/app/Models/Dropdown.php`
  - **Expect:** three lines.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **TDC-21** · L · QRY-13 · `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:222` — use the house page size of 10 for the trash list.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Before** (`TenantDropdownController.php:222`):
    ```php
            $dropdowns = Dropdown::onlyTrashed()->orderBy('key')->paginate(15);
    ```
  - **After:**
    ```php
            $dropdowns = Dropdown::onlyTrashed()->orderBy('key')->paginate(10);
    ```
  - **Verify:** `grep -n "onlyTrashed()->orderBy('key')->paginate(10)" Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`
  - **Expect:** one line.
  - **Effort:** S

## 7. Views (F10)

_No findings._

## 8. Style (F12) — one item per file

- [ ] **TDC-22** · L · STY-02 / STY-04 · `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php:7-18` — run Pint; the copied "Rule A1" comments are removed with the TDC-01/TDC-12 catches.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php`, `Modules/SystemConfig/app/Models/Dropdown.php`, `Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php`
  - **Before** (`TenantDropdownController.php:7-18`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;

    use Illuminate\Support\Facades\Log;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Schema;
    use Illuminate\Support\Str;
    use Modules\SystemConfig\Models\Dropdown;
    use Modules\SystemConfig\Http\Requests\TenantDropdownRequest;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Schema;
    use Illuminate\Support\Str;
    use Modules\SystemConfig\Http\Requests\TenantDropdownRequest;
    use Modules\SystemConfig\Models\Dropdown;
    ```
    The `ModelNotFoundException` and `Log` imports are removed entirely — no ticked item references them once the catches are gone. Then run, after all other items, `vendor/bin/pint Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php Modules/SystemConfig/app/Models/Dropdown.php Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php --format agent` and accept its formatting changes to these three files only.
  - **Verify:** `vendor/bin/pint --test Modules/SystemConfig/app/Http/Controllers/TenantDropdownController.php Modules/SystemConfig/app/Models/Dropdown.php Modules/SystemConfig/app/Http/Requests/TenantDropdownRequest.php`
  - **Expect:** no files listed (Pint passes).
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **TDC-10** · H · DECISION · RTE-01 — `/system-config/dropdown/{id}/restore` changes state over a GET request. Change the verb?
      ⚠ SHARED — `routes/tenant.php` is used by every controller.
  - **Why it is a decision:** it re-scopes a shared route and the fixer must not change the URL family without an explicit tick.
  - (a) ⭐ **Change it to `Route::delete('/dropdown/{id}/restore', …)`** — the shared `x-backend.table.action-trashed` component reads the route's methods and already renders a `POST` plus `@method('DELETE')` form, so no view change is needed. The method then needs a `Dropdown $dropdown` binding with `->withTrashed()`, which also lets TDC-12 drop the manual `findOrFail` in `restore()` and `forceDelete()`.
  - (b) **Keep GET** and accept the CSRF/prefetch exposure — record RTE-01 as accepted.
  - (c) **Move restore into a POST endpoint** already used elsewhere — more churn.
  - ➜ Choice: ____

- [ ] **TDC-14** · H · DECISION · CTL-06 — the create-screen table list vs the `getColumns()` whitelist (fully described in §1).
  - **Why it is a decision:** not mechanical; it changes what tables the client may list columns for.
  - (a) ⭐ Narrow `create()`'s table list to `sys_dropdown_table`, `sys_settings`, `sys_users`.
  - (b) Widen the `getColumns()` whitelist.
  - (c) Leave as is and accept.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TDC-02 | Resolved by the TDC-01, TDC-03 and TDC-12 items — deleting the catches deletes every `Log::error(...getMessage())` line, and the central handler then logs the exception object with its trace. |
| TDC-05 | Resolved by the TDC-01, TDC-03 and TDC-12 items — each rewritten method builds its response after the `DB::transaction` call. |
| TDC-06 | Resolved by the TDC-03 and TDC-12 items — `activityLog()` is moved after `save()` and after `forceDelete()`. |
| TDC-07 | Resolved by the TDC-01 item — the ordinal read is locked with `orderByDesc('ordinal')->lockForUpdate()->value('ordinal')`. |
| TDC-08 | Accepted — `Gate::authorize` plus a FormRequest `authorize()` is the module's house convention; removing the controller gate would leave the methods authorized by the FormRequest alone. |
| TDC-13 | Deferred — adding return types needs new imports (`View`, `RedirectResponse`, `JsonResponse`) that would overlap the TDC-01/TDC-03/TDC-12 method rewrites, so it is left out of this pass. |
| TDC-16 | Resolved by the TDC-01 item — `store()` no longer calls `Str::slug()` on the key, so the dotted `table.column` key is stored as submitted. |
| TDC-18 | Resolved indirectly by the TDC-11 item — the unrouted `index()` is replaced with `abort(403)`, so the N+1 loop no longer runs. If the method is ever re-routed, replace the loop with one `Dropdown::whereIn('key', $keys->pluck('key'))->get()->groupBy('key')`. |
| TDC-19 | Accepted — a comma-separated dropdown value is a short list and the per-row `create()` runs inside one transaction; a bulk `insert()` would need the audit rows to be built separately for little gain. |
| TDC-20 | Accepted — `sys_dropdown_table` holds 716 rows and the method is unrouted; a leading-wildcard `LIKE` has no measurable cost here. |
| TDC-23 | Folded into the TDC-17 item — `declare(strict_types=1);` is added to the model in the same edit. |
