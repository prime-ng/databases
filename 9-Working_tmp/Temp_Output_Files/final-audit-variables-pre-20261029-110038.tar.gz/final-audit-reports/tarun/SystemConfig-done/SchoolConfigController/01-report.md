# Final Audit — SystemConfig / SchoolConfigController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php` (91 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/system-config/school-config` (with `?tab=app_level_settings` / `?tab=system_config` / `?tab=media_store`, and `?search=`, `?type=`, `?status=`, `?disk=`) |
| Menu path | School Config (single tenant menu item, `slug` `school-config`, `route` `system-config.school-config.index`) |
| Who uses it | Roles holding either permission, measured on tenant `xyz_school`: **Super Admin** and **School Admin** both hold `tenant.system-config.setting.viewAny` and `tenant.school-setup.system-config.view` |
| What a user does here | One read-only page with three tabs: App Level Settings (a paginated, searchable list of `sys_settings` rows with inline value editing that posts to the standalone Setting controller), Threshold Setups (a paginated, searchable list of `sch_configs` rows), and Media Store (stat tiles plus a paginated, filterable list of `sys_media` files). This page only READS and renders; every write it can trigger posts to a different controller. |
| Tables written | none — the controller has no write path |
| Tables read | `sys_settings`, `sch_configs`, `glb_modules`, `sys_media` |
| Live data | tenant `xyz_school`: `sys_settings` 6, `sch_configs` 10, `sys_media` 3; central `glb_modules` 16 (15 active) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

The controller is **production-ready after the two medium fixes**. It is a thin, read-only,
single-method page; authorization, routes, tenancy, transactions and views are all clean. The
single worst finding is that the page runs an **unbounded `Module::orderBy('name')->get()` whose
result (`$modules`) is never used by the view or by any of the three included partials** — a query
paid on every page load for data no tab reads. The second is that raw query-string values are
passed straight into `?string` parameters, so a crafted URL such as `?search[]=x` throws a
`TypeError` and returns a 500. The remaining findings are low-severity model/style cleanups. Rough
effort: **S** (under an hour) for the whole plan.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 2 | 4 | 1 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean (no writes) | F9 Queries/Perf | SCFG-01, SCFG-03 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | SCFG-02 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | SCFG-04, SCFG-06 |
| F6 Controller shape | clean | F13 Deep read | no mutating methods |
| F7 Models | SCFG-05 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php` | controller | 91 | this report | ✅ |
| 2 | `Modules/SchoolSetup/app/Models/SchConfig.php` | model | 77 | this report | ✅ |
| 3 | `Modules/SystemConfig/resources/views/school-config/index.blade.php` | view | 71 | this report | ✅ |
| 4 | `Modules/GlobalMaster/app/Models/Module.php` | model | 98 | ↗ [tarun/GlobalMaster-done/ModuleController](../../GlobalMaster-done/ModuleController-done/01-report.md) | ↗ linked |
| 5 | `Modules/SystemConfig/app/Http/Controllers/SettingController.php` | controller (only static `listQuery()` is used) | 134 | ↗ [tarun/SystemConfig-done/SettingController](../SettingController/01-report.md) (CLAIMED, may not be finished) | ↗ linked |
| 6 | `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php` | controller (only static `listPayload()` is used) | 189 | no separate report exists yet — its other methods are out of scope here (see §8) | partial — called methods only |
| 7 | `Modules/SystemConfig/app/Models/Setting.php` | model (reached via `SettingController::listQuery`) | 38 | ↗ [tarun/SystemConfig-done/SettingController](../SettingController/01-report.md) | ↗ linked |
| 8 | `Modules/Prime/app/Models/TenantMedia.php` | model (reached via `TenantMediaStoreController::listPayload`) | 68 | no owner report yet — not registered here (see §7) | ↗ linked (used, not audited) |
| 9 | `Modules/SystemConfig/resources/views/setting/partials/_settings.blade.php` | blade partial (shared: rendered by `systemconfig::setting.index` too) | 292 | shared — not claimed here (see §7) | ↗ linked |
| 10 | `Modules/SchoolSetup/resources/views/system-config/partials/_system_config.blade.php` | blade partial (shared: rendered by `schoolsetup::system-config.index` too) | 357 | shared — not claimed here (see §7) | ↗ linked |
| 11 | `Modules/SystemConfig/resources/views/media-store/partials/_media-store.blade.php` | blade partial (shared: rendered by `systemconfig::media-store.index` too) | 318 | shared — not claimed here (see §7) | ↗ linked |

No pre-applied files (no `PRE-APPLIED-*.md` names any in-scope file for SystemConfig).

## 4. Routes

```
$ php -r '...route list filter for SchoolConfigController@...'
GET|HEAD system-config/school-config                             system-config.school-config.index                  Modules\SystemConfig\Http\Controllers\SchoolConfigController@index
```

Middleware on the route (from `/tmp/fa-routes.json`): `web`,
`Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains`,
`Stancl\Tenancy\Middleware\InitializeTenancyByDomain`,
`App\Http\Middleware\SetTenantAuthGuard`, `App\Http\Middleware\EnsureTenantIsActive`,
`Illuminate\Auth\Middleware\Authenticate`, `Illuminate\Auth\Middleware\EnsureEmailIsVerified`.
Registered in `routes/tenant.php:115-116`, inside the group opened at line 89 and the
`auth`+`verified` group at line 103.

Registered route (custom, no resource conflict — it is declared before `Route::resource('setting')`):

```php
// routes/tenant.php:115-116
        Route::get('/school-config', [SchoolConfigController::class, 'index'])
            ->name('school-config.index');
```

Unrouted public methods: none. The controller declares exactly one public method, `index` (line 47), and it is routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 47 | GET system-config/school-config | `tenant.system-config.setting.viewAny` OR `tenant.school-setup.system-config.view` | none (read-only) | none | none | SCFG-01, SCFG-02 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try|catch|getMessage|Log::' Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php` returned no output (no error handling is present, and the only failure path is `abort(403)`).

### F2 — Transactions and audit

clean — the controller has no write path: `grep -nE 'create\(|update\(|delete\(|save\(|insert\(|DB::' Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php` returned no output. Nothing to wrap in a transaction and no `activityLog()` is required.

### F3 — Authorization

clean — `Gate::any([...]) || abort(403);` is present before any record is loaded (`SchoolConfigController.php:49-52`); the `|| abort(403)` makes it a real check, not a no-op. Both permission literals exist in `config/permissionslist.php` (`system-config.setting` line 337 and `school-setup.system-config` line 488, both `$crud`). The view re-checks the same two names with `@can` (`index.blade.php:50`, `:58`, `:63`). No FormRequest and no Policy is involved.

### F4 — Validation and input

#### SCFG-02 · M · VAL-05 — raw query-string values reach typed string parameters, so an array input returns a 500

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; write paths with no validation at all are H* (here a READ path, so the default M stands) |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:59-85`, method `index()` |
| **Root cause** | `$request->input('search')` (and `type`, `status`, `disk`) return whatever the query string carries. When the query string is `?search[]=x`, `input()` returns an **array**, and the value is passed to parameters declared `?string` (`SettingController::listQuery(?string $search, ?string $type)`, `SchConfig::listQuery(?string $search, ...)`, `TenantMediaStoreController::listPayload(?string $search, ?string $disk, ?string $type)`). Because this controller file declares `strict_types=1`, PHP throws a `TypeError` instead of coercing. |
| **Consequence** | A crafted URL such as `/system-config/school-config?search[]=x` makes the whole page return a 500 error response. |
| **Reproduce** | Open `/system-config/school-config?search[]=x` (repeat with `?type[]=x`, `?disk[]=x`). Expected: page renders; actual: 500 |
| **Fix approach** | Read each query parameter once, normalise it to string-or-null with `is_string()`, and use the normalised variables at the three call sites. |
| **Plan item** | SCFG-02 in `02-fix-plan.md` §5 |

```php
// SchoolConfigController.php:62-65 — CURRENT (one of the four call sites)
        $settings = SettingController::listQuery(
            $activeTab === 'app_level_settings' ? $search : null,
            $activeTab === 'app_level_settings' ? $request->input('type') : null,
        )->paginate(20, ['*'], 'settings_page')->withQueryString();
```

**Evidence**
```
$ grep -n "request->input('search')\|request->input('type')\|request->input('status')\|request->input('disk')" Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php
59:        $search = $request->input('search');
64:            $activeTab === 'app_level_settings' ? $request->input('type') : null,
74:            $activeTab === 'system_config' ? $request->input('status') : null,
83:            $activeTab === 'media_store' ? $request->input('disk') : null,
84:            $activeTab === 'media_store' ? $request->input('type') : null;

$ cat /tmp/opencode/strict_test.php
<?php declare(strict_types=1);
function typed(?string $s){ return $s; }
try { typed(["a"]); echo "NO ERROR\n"; } catch (\TypeError $e) { echo "TypeError: ".$e->getMessage()."\n"; }
$ php /tmp/opencode/strict_test.php
TypeError: typed(): Argument #1 ($s) must be of type ?string, array given, called in /tmp/opencode/strict_test.php on line 3
```

### F5 — Routes

clean — `php -r '...filter /tmp/fa-routes.json for SchoolConfigController@...'` printed exactly the one row shown in §4; the method exists (`php -l` passed), the route is GET (no state change), and it sits inside the auth+verified+tenancy middleware group. No unrouted public method.

### F6 — Controller shape

clean — 91 lines and 1 public method (well under the 1,000-line / 25-method thresholds); no method over 80 lines; no `dd()`/`dump()`/`var_dump()`; no `compact()` over 15 variables (`compact()` carries 5). The unused `$modules` variable is a dead query and is reported under F9 as SCFG-01, not duplicated here.

### F7 — Models

#### SCFG-05 · L · MDL-04 — `SchConfig::module()` has no return type

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods are return-typed (`: BelongsTo`, `: HasMany`)* |
| **Where** | `Modules/SchoolSetup/app/Models/SchConfig.php:40-43`, method `module()` |
| **Root cause** | The `belongsTo(Module::class, 'module_id')` relation is declared without a return type, unlike the newer models in the same module (for example `ClassStream.php:32` uses `: BelongsTo`). |
| **Consequence** | No user-visible effect; it costs IDE and static-analysis support, and makes the relation's kind invisible to a reader. |
| **Reproduce** | static only — a missing return type produces no runtime behaviour. |
| **Fix approach** | Add `: BelongsTo` and import `Illuminate\Database\Eloquent\Relations\BelongsTo`. |
| **Plan item** | SCFG-05 in `02-fix-plan.md` §5 |

```php
// SchConfig.php:40-43 — CURRENT
    public function module()
    {
        return $this->belongsTo(Module::class, 'module_id');
    }
```

**Evidence**
```
$ grep -n 'public function module()' Modules/SchoolSetup/app/Models/SchConfig.php
40:    public function module()
```

### F8 — Services and jobs

clean — the controller uses no service, no job, no event and no mail. The two helpers it calls are static controller methods that return data (no HTTP, no writes on their read path): `SettingController::listQuery()` and `TenantMediaStoreController::listPayload()`.

### F9 — Queries and performance

#### SCFG-01 · M · QRY-15 — `Module::orderBy('name')->get()` loads every module row and nothing reads the result

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *don't load every row of a big table for a form with no filter* (also CTL-10, dead variable) |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:76`, method `index()` |
| **Root cause** | Line 76 assigns `$modules` from an unbounded `get()`, line 88 passes it into the view via `compact()`, but neither `index.blade.php` nor any of the three partials it includes references `$modules`. The query is paid on every page load and its data is discarded. |
| **Consequence** | Every load of School Config issues one extra `SELECT * FROM glb_modules ORDER BY name` that no tab uses; the cost grows with the central module list. |
| **Reproduce** | Open `/system-config/school-config` with the query log on (or Debugbar); the `glb_modules` select appears although no module picker is rendered. |
| **Fix approach** | Delete line 76 and remove `'modules'` from the `compact()` call. |
| **Plan item** | SCFG-01 in `02-fix-plan.md` §6 |

```php
// SchoolConfigController.php:76 — CURRENT
        $modules = Module::orderBy('name')->get();
```

**Evidence**
```
$ grep -rn '\$modules' Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php Modules/SystemConfig/resources/views/ Modules/SchoolSetup/resources/views/system-config/
Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:76:        $modules = Module::orderBy('name')->get();

$ grep -rn '\$modules' Modules/SystemConfig/resources/views/ Modules/SchoolSetup/resources/views/system-config/
(no output — exit 1)
```

#### SCFG-03 · L · QRY-08 — leading-wildcard `LIKE` on four `sch_configs` columns in the shared list query

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M default, lowered to L — `sch_configs` holds 10 rows on the audited tenant, so the scan cost is trivial today; the default M is for large tables) |
| **Where** | `Modules/SchoolSetup/app/Models/SchConfig.php:69-72`, method `listQuery()` |
| **Root cause** | The Threshold Setups search wraps the term in `%...%` on `key_name`, `key`, `value` and `description`. A leading `%` prevents MySQL from using the `uq_settings_key` unique index, so the server must scan the whole (currently tiny) table for every search. |
| **Consequence** | No measurable effect at the current row count; it becomes a full-table scan if `sch_configs` ever grows large. |
| **Reproduce** | Open `/system-config/school-config?tab=system_config&search=th` and inspect the generated query. |
| **Fix approach** | A behaviour change (prefix vs substring match) or a FULLTEXT index — see the SCFG-03 DECISION. |
| **Plan item** | SCFG-03 in `02-fix-plan.md` §9 (DECISION) |

```php
// SchConfig.php:67-73 — CURRENT
        return static::with('module')
            ->when($search, fn ($q) => $q->where(function ($w) use ($search) {
                $w->where('key_name', 'like', "%{$search}%")
                    ->orWhere('key', 'like', "%{$search}%")
                    ->orWhere('value', 'like', "%{$search}%")
                    ->orWhere('description', 'like', "%{$search}%");
            }))
```

**Evidence**
```
$ grep -n "like" Modules/SchoolSetup/app/Models/SchConfig.php
69:                $w->where('key_name', 'like', "%{$search}%")
70:                    ->orWhere('key', 'like', "%{$search}%")
71:                    ->orWhere('value', 'like', "%{$search}%")
72:                    ->orWhere('description', 'like', "%{$search}%");
```

### F10 — Views

clean — `grep -nE '::|DB::|->get\(|->where\(|->count\(' Modules/SystemConfig/resources/views/school-config/index.blade.php` returned no query, only `@include`/`@can`. The one `{!! !!}` in scope (none here) is absent; the `{!! conversionBadge(...) !!}` at `_media-store.blade.php:242` is inside the shared partial and calls a helper defined in that same partial (line 47), not user text. `$config->module->name` (`_system_config.blade.php:124`) is eager-loaded by `SchConfig::listQuery`'s `with('module')`, so the `@forelse` over `$configs` is not an N+1.

### F11 — Security and tenancy

clean — no `env()` (`grep -n 'env(' ...` returned no output); no hard-coded ids or `?? 1`; no secrets logged; no cache in use. `Module` pins `protected $connection = 'global_master_mysql'` so the central read is explicit; the tenant lists read through the default (tenant) connection.

### F12 — Style

#### SCFG-04 · L · STY-01 — `SchConfig.php` has no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `Modules/SchoolSetup/app/Models/SchConfig.php:1-3` |
| **Root cause** | The file opens with `<?php` and goes straight to the namespace. The controller that uses it already declares strict types, so the two files of the same feature disagree. |
| **Consequence** | No runtime effect today; it is a consistency gap with the rest of the feature and with the controller that calls this model. |
| **Reproduce** | static only. |
| **Fix approach** | Add the declare after the opening tag. |
| **Plan item** | SCFG-04 in `02-fix-plan.md` §8 |

```php
// SchConfig.php:1-3 — CURRENT
<?php

namespace Modules\SchoolSetup\Models;
```

**Evidence**
```
$ grep -n 'declare(strict_types' Modules/SchoolSetup/app/Models/SchConfig.php
(no output — exit 1)
```

#### SCFG-06 · L · STY-04 — emoji markers in comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:22` (also lines 27, 34, 39), and `Modules/SchoolSetup/app/Models/SchConfig.php:57` |
| **Root cause** | Five docblock lines begin with the warning-sign emoji `⚠` as a visual marker. The scanner flags the character; the rulebook bars emoji in comments. |
| **Consequence** | Cosmetic only — no user-visible effect; it is a house-style breach. |
| **Reproduce** | static only. |
| **Fix approach** | Remove the `⚠ ` prefix from each of the five lines, keeping the sentence. |
| **Plan item** | SCFG-06 in `02-fix-plan.md` §8 |

```php
// SchoolConfigController.php:22 — CURRENT (first of five lines)
 * ⚠ THE TAB BODIES ARE SHARED, NOT COPIED. Each partial is still rendered by its
```

**Evidence**
```
$ grep -n '⚠' Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php Modules/SchoolSetup/app/Models/SchConfig.php
Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:22: * ⚠ THE TAB BODIES ARE SHARED, NOT COPIED. Each partial is still rendered by its
Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:27: *   ⚠ Corrected 2026-09-09 (health check SCFG-11): this line used to say "edit/delete/trash
Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:34: * ⚠ ONE `search` BOX PER TAB, ONE `search` PARAM. Same shape as TenantLocationController:
Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:39: * ⚠ PAGE NAMES MUST DIFFER. Two paginators now share one page, so both cannot use the
Modules/SchoolSetup/app/Models/SchConfig.php:57:     * ⚠ IT LIVES HERE BECAUSE IT WAS ONLY EVER RIGHT IN ONE OF THEM. Both pages render the
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There is **no mutating method** in this controller: `index` only reads and renders (it calls
`SettingController::listQuery()`, `SchConfig::listQuery()` and `TenantMediaStoreController::listPayload()`,
all of which are read-only, and `Module::orderBy('name')->get()`). The eight questions therefore do
not apply; the one read-path data question (a write overwriting data) cannot occur. The table below
records the single method for completeness.

| Method | 1 overwrite | 2 delete-before-store | 3 duplicate impl | 4 soft-delete×unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `index` | n/a (read) | n/a (read) | ok | ok | ok | ok | ok | SCFG-01 |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/GlobalMaster/app/Models/Module.php` | `tenantInvoices()` is a `belongsToMany` over soft-delete pivot `bil_tenant_invoicing_modules_jnt` without `->wherePivotNull('deleted_at')`; also missing `strict_types` and relation return types | MDL-03, MDL-04, STY-01 | [tarun/GlobalMaster-done/ModuleController](../../GlobalMaster-done/ModuleController-done/01-report.md) (this report links, does not re-audit) |
| `Modules/SystemConfig/app/Http/Controllers/SettingController.php` | `listQuery()` uses leading-wildcard `LIKE` on three `sys_settings` columns (QRY-08); the controller's `update()` also has `TXN-05`/`ERR-05` hits | QRY-08, TXN-05, ERR-05 | [tarun/SystemConfig-done/SettingController](../SettingController/01-report.md) (CLAIMED) |
| `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php` | its own methods (`index`, `checkFile`, `baseQuery`) carry `CTL-03`/`RTE-03`/`QRY-08` scanner hits | CTL-03, RTE-03, QRY-08 | a future `tarun/SystemConfig-done/TenantMediaStoreController` report (not yet claimed) |
| `Modules/SystemConfig/resources/views/setting/partials/_settings.blade.php` | shared blade (also rendered by `systemconfig::setting.index`) | — | its own page's report (not yet written) |
| `Modules/SchoolSetup/resources/views/system-config/partials/_system_config.blade.php` | shared blade (also rendered by `schoolsetup::system-config.index`) | — | the SchoolSetup module's report (not yet written) |
| `Modules/SystemConfig/resources/views/media-store/partials/_media-store.blade.php` | shared blade (also rendered by `systemconfig::media-store.index`) | — | `tarun/SystemConfig-done/TenantMediaStoreController` report (not yet written) |
| `Modules/Prime/app/Models/TenantMedia.php` | reached through `TenantMediaStoreController::listPayload`; not registered as owned because its owner controller has no report yet | — | that controller's future report |

## 8. Not covered, and why

- **`Module.php`** — owned by another report (`tarun/GlobalMaster-done/ModuleController`). This report only checked how `index` uses it (an unused `get()` — SCFG-01).
- **`SettingController.php` and `TenantMediaStoreController.php`** — separate controllers claimed by (or awaiting) their own audits. This report audited only the two static methods the page calls (`listQuery()`, `listPayload()`); their other methods (`update`, `checkFile`, `baseQuery`, etc.) are out of scope here.
- **The three shared partials and the `x-backend.tab.nav-tab` component** — common/shared UI rendered by more than one page. Only the variables this controller must supply were checked (all supplied: `settings`, `configs`, `tabCounts`/`media`/`disks`/`totalCount` and the tab/filter scalars). Their internals belong to the reports named in §7.
- **Live rendering** — no screen was opened in a browser and no automated test was run (D4: no testing of any kind). The 500 in SCFG-02 is proven by PHP's `strict_types` semantics, not by an HTTP call.
- **Writes** — none exist in this controller, so no transaction/audit path was exercised.
