# Fix Plan — SystemConfig / SchoolConfigController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/GlobalMaster/app/Models/Module.php` | owned by another report — `tarun/GlobalMaster-done/ModuleController` |
| `Modules/SystemConfig/app/Http/Controllers/SettingController.php` | owned by `tarun/SystemConfig-done/SettingController` |
| `Modules/SystemConfig/app/Http/Controllers/TenantMediaStoreController.php` | separate controller audit; not this report |
| `Modules/SystemConfig/resources/views/setting/partials/_settings.blade.php` | shared blade — rendered by two pages |
| `Modules/SchoolSetup/resources/views/system-config/partials/_system_config.blade.php` | shared blade — rendered by two pages |
| `Modules/SystemConfig/resources/views/media-store/partials/_media-store.blade.php` | shared blade — rendered by two pages |
| `Modules/SystemConfig/resources/views/school-config/index.blade.php` | the view is clean — no view fix in this plan |
| `routes/tenant.php` | route file — no route change in this plan |
| `config/permissionslist.php` | shared config — no permission change in this plan |

## 1. Blockers reachable today

None.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — the controller has no write path and no error handling.

## 4. Authorization (F3)

None — `Gate::any([...]) || abort(403)` is correct and both permission keys exist.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **SCFG-02** · M · VAL-05 · `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:59-85` — normalise the four query-string values to string-or-null before they reach typed `?string` parameters.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php`
  - **Before** (`SchoolConfigController.php:59`):
    ```php
            $search = $request->input('search');
    ```
  - **After:**
    ```php
            $search = $request->input('search');
            $type = $request->input('type');
            $status = $request->input('status');
            $disk = $request->input('disk');

            $search = is_string($search) ? $search : null;
            $type = is_string($type) ? $type : null;
            $status = is_string($status) ? $status : null;
            $disk = is_string($disk) ? $disk : null;
    ```
  - **Before 2** (`SchoolConfigController.php:62-65`):
    ```php
            $settings = SettingController::listQuery(
                $activeTab === 'app_level_settings' ? $search : null,
                $activeTab === 'app_level_settings' ? $request->input('type') : null,
            )->paginate(20, ['*'], 'settings_page')->withQueryString();
    ```
  - **After 2:**
    ```php
            $settings = SettingController::listQuery(
                $activeTab === 'app_level_settings' ? $search : null,
                $activeTab === 'app_level_settings' ? $type : null,
            )->paginate(20, ['*'], 'settings_page')->withQueryString();
    ```
  - **Before 3** (`SchoolConfigController.php:72-75`):
    ```php
            $configs = SchConfig::listQuery(
                $activeTab === 'system_config' ? $search : null,
                $activeTab === 'system_config' ? $request->input('status') : null,
            )->paginate(10, ['*'], 'configs_page')->withQueryString();
    ```
  - **After 3:**
    ```php
            $configs = SchConfig::listQuery(
                $activeTab === 'system_config' ? $search : null,
                $activeTab === 'system_config' ? $status : null,
            )->paginate(10, ['*'], 'configs_page')->withQueryString();
    ```
  - **Before 4** (`SchoolConfigController.php:81-85`):
    ```php
            $media = TenantMediaStoreController::listPayload(
                $activeTab === 'media_store' ? $search : null,
                $activeTab === 'media_store' ? $request->input('disk') : null,
                $activeTab === 'media_store' ? $request->input('type') : null,
            );
    ```
  - **After 4:**
    ```php
            $media = TenantMediaStoreController::listPayload(
                $activeTab === 'media_store' ? $search : null,
                $activeTab === 'media_store' ? $disk : null,
                $activeTab === 'media_store' ? $type : null,
            );
    ```
  - **Verify:** `grep -n 'is_string' Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php`
  - **Expect:** four lines, one each for `$search`, `$type`, `$status`, `$disk`.
  - **Effort:** S

- [ ] **SCFG-05** · L · MDL-04 · `Modules/SchoolSetup/app/Models/SchConfig.php:40-43` — give the `module()` relation its `: BelongsTo` return type.
  - **Touches:** `Modules/SchoolSetup/app/Models/SchConfig.php`
  - **Before** (`SchConfig.php:40-43`):
    ```php
        public function module()
        {
            return $this->belongsTo(Module::class, 'module_id');
        }
    ```
  - **After:**
    ```php
        public function module(): BelongsTo
        {
            return $this->belongsTo(Module::class, 'module_id');
        }
    ```
  - **Before 2** (`SchConfig.php:5-8`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\GlobalMaster\Models\Module;
    ```
  - **After 2:**
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\GlobalMaster\Models\Module;
    ```
  - **Verify:** `grep -n 'BelongsTo' Modules/SchoolSetup/app/Models/SchConfig.php`
  - **Expect:** two lines — the `use` import and `public function module(): BelongsTo`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **SCFG-01** · M · QRY-15 · `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:76` — delete the `$modules` query that nothing reads.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php`
  - **Before** (`SchoolConfigController.php:76`):
    ```php
            $modules = Module::orderBy('name')->get();
    ```
  - **After:**
    ```php
            // SCFG-01 (2026-10-17): the unused $modules query was removed here.
    ```
  - **Before 2** (`SchoolConfigController.php:87-89`):
    ```php
            return view('systemconfig::school-config.index', array_merge($media, compact(
                'activeTab', 'search', 'settings', 'configs', 'modules'
            )));
    ```
  - **After 2:**
    ```php
            return view('systemconfig::school-config.index', array_merge($media, compact(
                'activeTab', 'search', 'settings', 'configs'
            )));
    ```
  - **Verify:** `grep -rn '\$modules' Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php Modules/SystemConfig/resources/views/ Modules/SchoolSetup/resources/views/system-config/`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

None — the view and the three partials are clean; the shared partials are not edited here.

## 8. Style (F12) — one item per file

- [ ] **SCFG-04** · L · STY-01 · `Modules/SchoolSetup/app/Models/SchConfig.php:1-3` — add `declare(strict_types=1)`.
  - **Touches:** `Modules/SchoolSetup/app/Models/SchConfig.php`
  - **Before** (`SchConfig.php:1-3`):
    ```php
    <?php

    namespace Modules\SchoolSetup\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SchoolSetup\Models;
    ```
  - **Verify:** `grep -n 'declare(strict_types' Modules/SchoolSetup/app/Models/SchConfig.php`
  - **Expect:** one line, `2:declare(strict_types=1);`.
  - **Effort:** S

- [ ] **SCFG-06** · L · STY-04 · `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php:22,27,34,39` and `Modules/SchoolSetup/app/Models/SchConfig.php:57` — drop the emoji markers from the comments.
  - **Touches:** `Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php`, `Modules/SchoolSetup/app/Models/SchConfig.php`
  - **Before** (`SchoolConfigController.php:22`):
    ```php
     * ⚠ THE TAB BODIES ARE SHARED, NOT COPIED. Each partial is still rendered by its
    ```
  - **After:**
    ```php
     * THE TAB BODIES ARE SHARED, NOT COPIED. Each partial is still rendered by its
    ```
  - **Before 2** (`SchoolConfigController.php:27`):
    ```php
     *   ⚠ Corrected 2026-09-09 (health check SCFG-11): this line used to say "edit/delete/trash
    ```
  - **After 2:**
    ```php
     *   Corrected 2026-09-09 (health check SCFG-11): this line used to say "edit/delete/trash
    ```
  - **Before 3** (`SchoolConfigController.php:34`):
    ```php
     * ⚠ ONE `search` BOX PER TAB, ONE `search` PARAM. Same shape as TenantLocationController:
    ```
  - **After 3:**
    ```php
     * ONE `search` BOX PER TAB, ONE `search` PARAM. Same shape as TenantLocationController:
    ```
  - **Before 4** (`SchoolConfigController.php:39`):
    ```php
     * ⚠ PAGE NAMES MUST DIFFER. Two paginators now share one page, so both cannot use the
    ```
  - **After 4:**
    ```php
     * PAGE NAMES MUST DIFFER. Two paginators now share one page, so both cannot use the
    ```
  - **Before 5** (`SchConfig.php:57`):
    ```php
         * ⚠ IT LIVES HERE BECAUSE IT WAS ONLY EVER RIGHT IN ONE OF THEM. Both pages render the
    ```
  - **After 5:**
    ```php
         * IT LIVES HERE BECAUSE IT WAS ONLY EVER RIGHT IN ONE OF THEM. Both pages render the
    ```
  - **Verify:** `grep -rn '⚠' Modules/SystemConfig/app/Http/Controllers/SchoolConfigController.php Modules/SchoolSetup/app/Models/SchConfig.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **SCFG-03** · L · DECISION · QRY-08 — the Threshold Setups search uses leading-wildcard `LIKE` on four `sch_configs` columns; how should this be handled?
  - **Why it is a decision:** changing `%term%` to a prefix match changes what a user's search returns (substring matches disappear), and a FULLTEXT index needs a migration.
  - (a) ⭐ accept as-is — `sch_configs` holds 10 rows; the leading `%` cannot use `uq_settings_key`, but there is no measurable cost and substring search is what the search box promises.
  - (b) switch to a left-anchored match (`term%`) — uses the unique index, but a user searching a word in the middle of a value stops getting hits.
  - (c) add a FULLTEXT index in an additive migration — keeps substring semantics and is index-backed; needs Tarun's hand to run `php artisan tenants:migrate`.
  - ➜ Choice: ____

## 10. Findings with no plan item

None — every finding (SCFG-01, SCFG-02, SCFG-03, SCFG-04, SCFG-05, SCFG-06) has a plan item above.
