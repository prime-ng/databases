# Final Audit — ParentPortal / ParentHomeworkController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php` (121 lines, 2 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/parent-portal/homework` (list with 5 client-side tabs) · `http://test.localhost:8000/parent-portal/homework/{id}` (detail page) |
| Menu path | Parent Portal → sidebar → Homework (`Modules/ParentPortal/resources/views/layouts/_sidebar.blade.php:107-108`) |
| Who uses it | Authenticated `user_type = PARENT` accounts that have a `std_guardians` row and at least one child link with `can_access_parent_portal = 1`. The portal has NO permission keys — access is the role gate in `ParentPortalMiddleware` (`Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php`). |
| What a user does here | Reads the active child's homework list, split into Pending / Overdue / Submitted / Graded / All tabs that switch client-side, then opens a single assignment to read the homework title, description, teacher attachments, due date, and (when graded) the marks, percentage, pass/fail state and teacher feedback. No business writes: the only write is one `activityLog` audit row per page view. |
| Tables written | `sys_activity_logs` (one audit row via the `activityLog()` helper) |
| Tables read | `std_guardians`, `std_student_guardian_jnt`, `std_students` (via `ParentContextService`), `lms_homework_assignment`, `lms_homework`, `lms_homework_submissions`, `sys_dropdown_table`, `sch_subjects`, `sch_classes`, `sch_sections`, `syllabus` related tables (`lesson`, `topic`, `complexity_level`) through the eager loads, and `sys_media` (attachments, Spatie) |
| Live data | ⚠ UNVERIFIED — no tenant database is reachable from this host (the default `prime_db` connection has 0 tenant tables), so live row counts were not measured. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**. No pre-applied files: `final-audit-reports/tarun/ParentPortal/` has no `PRE-APPLIED-*.md`, and none of the in-scope files appear in `final-audit-reports/tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md`.

## 1. Verdict

The controller is **NOT production-ready**: opening the detail page 500s because the view expects `$homework`/`$submission` variables the controller never passes (PHW-05, B), and both of the module's media models write their Spatie media rows to the central database instead of the tenant's (PHW-09, B). The single worst finding is **PHW-05**: `parent-portal/homework/{id}` always throws "Attempt to read property on null" at render time because `show()` passes `assignment`/`attachments` to a blade written for `homework`/`submission` — and the index page never links to the detail page, so the broken screen is only reachable by typing the URL. The `show()` method also wraps its whole read in `DB::transaction` + try/catch (PHW-02/PHW-04), which is the D1 anti-shape and swallows the child-context no-access redirect. Effort to apply the whole plan: **M** — one method rewrite, two one-line model additions, two model import/cast edits, and three mechanical model clean-ups; no migrations, no route files, no permission keys.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 1 | 5 | 5 | 1 | 13 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PHW-01, PHW-02, PHW-03 | F8 Services/Jobs | clean — linked |
| F2 Transactions/Audit | PHW-04 | F9 Queries/Perf | PHW-06, PHW-07, PHW-08 |
| F3 Authorization | clean | F10 Views | PHW-05 |
| F4 Validation | clean | F11 Security/Tenancy | clean (model media = PHW-09 F7) |
| F5 Routes | clean | F12 Style | PHW-13 |
| F6 Controller shape | clean (CTL-08 folded into PHW-01/PHW-05) | F13 Deep read | PHW-02, PHW-04, PHW-05 |
| F7 Models | PHW-09, PHW-10, PHW-11, PHW-12 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php` | controller | 121 | this report | ✅ |
| 2 | `Modules/ParentPortal/resources/views/homework/index.blade.php` | view | 189 | this report | ✅ |
| 3 | `Modules/ParentPortal/resources/views/homework/show.blade.php` | view | 293 | this report | ✅ |
| 4 | `Modules/LmsHomework/app/Models/Homework.php` | model | 308 | this report (pre-assigned 2026-10-13) | ✅ |
| 5 | `Modules/LmsHomework/app/Models/HomeworkAssignment.php` | model | 170 | this report (pre-assigned 2026-10-13) | ✅ |
| 6 | `Modules/LmsHomework/app/Models/HomeworkSubmission.php` | model | 242 | this report (pre-assigned 2026-10-13) | ✅ |
| 7 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) | ↗ linked (pre-assigned by main session 2026-10-13) |
| 8 | `Modules/ParentPortal/routes/web.php` | routes (module, shared) | 199 | this report — evidence for the two homework rows only | ✅ (rows 67-70) |
| 9 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware | 62 | ↗ [tarun/ParentPortal-done/ParentHealthController](../ParentHealthController-done/01-report.md) | ↗ linked (claimed by opencode 2026-10-13) |

No pre-applied files.

**Common classes referenced, never audited here** (§4.2): `App\Http\Controllers\Controller`, `App\Models\BaseModel`, `app/Helpers/activityLog.php`, `Modules/ParentPortal/resources/views/layouts/**` (app, _header, _sidebar), the `DB`/`Log` facades, and the other-module models reached through the eager loads — `Subject`, `ComplexityLevel`, `Lesson`, `Topic`, `SchoolClass`, `Section`, `Dropdown`, `Student` — which belong to their own modules' audits. Only their use by THIS controller was checked.

## 4. Routes

Uncached `route:list` (export of 2026-10-13 09:45):

```
GET|HEAD parent-portal/homework                                  parent-portal.homework.index                       Modules\ParentPortal\Http\Controllers\ParentHomeworkController@index
GET|HEAD parent-portal/homework/{id}                             parent-portal.homework.show                        Modules\ParentPortal\Http\Controllers\ParentHomeworkController@show
```

Declared in `Modules/ParentPortal/routes/web.php:67-70` inside the group that applies:
`web → InitializeTenancyByDomain → PreventAccessFromCentralDomains → EnsureTenantIsActive → EnsureTenantHasModule:ParentPortal → auth → ParentPortalMiddleware`, prefix `/parent-portal`, name prefix `parent-portal.` (`Modules/ParentPortal/app/Providers/RouteServiceProvider.php:66-80`).

Unrouted public methods: none — `index` and `show` are the only public methods (besides `__construct`) and both are routed. No state change rides a GET (all writes on both pages are the audit row produced by the read itself).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 26 | GET /parent-portal/homework (`parent-portal.homework.index`) | none in the controller — role gate `ParentPortalMiddleware` (user_type=PARENT + guardian + child), no permission key | none — single-row audit write, no business write | `'Viewed'` at line 60, inside try/catch | sys_activity_logs (via `activityLog()` helper) | PHW-01, PHW-03, PHW-06, PHW-07 |
| `show` | 78 | GET /parent-portal/homework/{id} (`parent-portal.homework.show`) | none in the controller — role gate + query scoped by `student_id = $child->id` | `DB::transaction` in the controller (line 81) around a read + the audit write | `'Viewed'` at line 94, inside the transaction | sys_activity_logs (via `activityLog()` helper) | PHW-02, PHW-03, PHW-04, PHW-05, PHW-08 |

## 6. Findings

### F1 — Errors

#### PHW-01 · M · ERR-07 / ERR-00 — `index()` is a read method wrapped in a controller try/catch that is not a D2 shape

| Field | Value |
|---|---|
| **Rule** | ERR-07 (M) — *read-only methods need no try/catch under either variant*; ERR-00 / protocol D1 — *no try/catch in controllers except the D2 shapes (`\DomainException`, truncate-then-rebuild fixed message, `SnapshotProtectionException`, service `report($e)`)*. This catch of `\Throwable` is not one of them. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php:55-71`, method `index()` |
| **Root cause** | The method isolates the audit write so a log failure cannot take the list page down (comment at lines 55-58 cites the old house-rule A1, which D1 supersedes for modules under final audit). The `try { activityLog(...) } catch (\Throwable) { Log::error(...) }` shape is neither the D1 Laravel idiom nor one of the D2-permitted catches. |
| **Consequence** | When the audit write fails, the failure is swallowed and the page renders as if nothing happened — no audit trail for that view, and a reviewer cannot tell the audit write ever fails. |
| **Reproduce** | Not browser-reproducible without inducing a write failure; static only — the catch is visible at lines 59-71. |
| **Fix approach** | DECISION (plan §9): either keep ONE isolated catch that preserves the page and the trace into the audit system (recommended), or delete the try/catch for strict D1 and let the central handler render. Either way replace the `request()` helper with the injected `$request` (CTL-08). |
| **Plan item** | PHW-01 in `02-fix-plan.md` §9 (DECISION) |

```php
// ParentHomeworkController.php:59-71 — CURRENT
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed homework list',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
```

**Evidence**
```
$ sed -n '59,71p' Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed homework list',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
```

#### PHW-02 · H · ERR-02 — `show()`'s generic catch swallows the child-context no-access redirect and hides every 4xx/5xx

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422/`abort()` into a redirect or 500*. Raised from the D1 default because the wrong-response path is a real one on this screen. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php:80-119`, method `show()` |
| **Root cause** | The whole read runs inside `try { ... } catch (ModelNotFoundException ...) { throw } catch (\Throwable $e) { Log::error(...); return back()->with('error', ...); }`. `ParentContextService::resolveChild()` aborts with `abort(redirect()->route('parent-portal.no-access'))` when the parent has no accessible child (`ParentContextService.php:103-105`). Because `resolveChild()` is called INSIDE the try (line 82), that intended redirect — an `HttpException` carrying a Response — is caught by `catch (\Throwable)` and converted into `back()->with('error', 'The operation could not be completed.')`. Any other abort, and any DB QueryException, is likewise hidden behind the generic flash. |
| **Consequence** | A parent whose child link was revoked between the middleware check and this request, or who hits the deep link from a stale tab, gets a generic "The operation could not be completed." flash on whatever page they came from instead of the no-access page; a genuine DB error is also silently turned into the same flash. |
| **Reproduce** | ⚠ UNVERIFIED in a browser without inducing the child-link race; static only — the abort in `ParentContextService::resolveChild()` (lines 103-105) sits inside `show()`'s try at line 82. |
| **Fix approach** | Remove the try/catch and the transaction entirely (the method is a read + one-row audit write): `resolveChild()` and `firstOrFail()` then surface their own 302/404 through the central handler. Folded into the PHW-05 rewrite of `show()`. |
| **Plan item** | PHW-05 in `02-fix-plan.md` §1 (PHW-02 is fixed by the same rewrite — see plan §10) |

```php
// ParentHomeworkController.php:108-119 — CURRENT
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('ParentHomeworkController::show failed', ['error' => $e->getMessage()]);

            // The declared return type is widened to View|RedirectResponse rather than
            // forcing a JSON body here: this renders a page, and its error path has always
            // been a redirect. Declared `: View` alone, that redirect was a TypeError.
            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ sed -n '78,82p' Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php
    public function show(Request $request, int $id): View|RedirectResponse
    {
        try {
            return DB::transaction(function () use ($request, $id) {
                $child      = $this->context->resolveChild($request);
$ sed -n '103,105p' Modules/ParentPortal/app/Services/ParentContextService.php
        if ($children->isEmpty()) {
            abort(redirect()->route('parent-portal.no-access'));
        }
```

#### PHW-03 · M · ERR-05 — both catch blocks log `getMessage()` instead of the exception object, losing the trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php:70` (`index`) and `:113` (`show`) |
| **Root cause** | Both catches were written with the older `Log::error('<label>', ['error' => $e->getMessage()])` shape; the message alone carries no stack trace, and SQL/table wording can leak into the log format. |
| **Consequence** | A failure in either page's audit write (or, in `show`, any DB error) leaves a log line with no trace, so the operator cannot tell what broke or where. |
| **Reproduce** | Static only — the two `Log::error` lines are at 70 and 113. |
| **Fix approach** | Folded into PHW-01 (index) and PHW-05 (show): both rewrites replace the `Log::error(... getMessage())` with `report($e)` / removal of the catch. |
| **Plan item** | PHW-01 in `02-fix-plan.md` §9, PHW-05 in §1 (see plan §10) |

```php
// ParentHomeworkController.php:69-71 — CURRENT
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
```

**Evidence**
```
$ grep -n "Log::error" Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php
70:            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
113:            Log::error('ParentHomeworkController::show failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### PHW-04 · M · TXN-05 / TXN-01 — `show()` builds the HTTP response inside a `DB::transaction` around a read plus a single-row audit write

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build `redirect()`/`response()` after it*. TXN-01 (H, lowered to M): more than one write needs one transaction — here there is only ONE write (the audit row), so no transaction is needed at all; `index()`'s own comment (lines 57-58) says exactly this. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php:81-107`, method `show()` |
| **Root cause** | `show()` wraps the whole read + the single `activityLog()` call in `DB::transaction(fn () => ...)` and returns `view(...)` from inside the closure. A transaction around one one-row insert is unnecessary, and returning an HTTP/View payload from inside the closure mixes the response build into the write scope. This is also why the generic catch exists and why the audit write's failure hides the page (PHW-02 aftermath: the method is written as if it were a mutator). |
| **Consequence** | Unnecessary transaction overhead on every detail view and an error-shaped method around a read-only screen; the transaction also gives the false impression the audit row and a business write are atomic. |
| **Reproduce** | Static only — line 81 opens `DB::transaction`, line 105 `return view(...)` inside the closure. |
| **Fix approach** | Remove the transaction as part of the PHW-05 rewrite; call `activityLog()` after the read, outside any transaction block. |
| **Plan item** | PHW-05 in `02-fix-plan.md` §1 (PHW-04 is fixed by the same rewrite — see plan §10) |

```php
// ParentHomeworkController.php:80-107 — CURRENT
        try {
            return DB::transaction(function () use ($request, $id) {
                $child      = $this->context->resolveChild($request);
                $assignment = HomeworkAssignment::where('student_id', $child->id)
                    ->where('id', $id)
                    ->with([
                        'homework.subject',
                        'homework.difficultyLevel',
                        'submission',
                    ])
                    ->firstOrFail();

                $attachments = $assignment->homework->getMedia('homework_files');

                activityLog(auth()->user(), 'Viewed', [
                    'message' => 'Viewed homework assignment',
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                    'homework_assignment_id' => $assignment->id,
                ]);

                return view('parentportal::homework.show', compact('child', 'assignment', 'attachments'));

            });
        } catch (ModelNotFoundException $e) {
```

**Evidence**
```
$ sed -n '81p;105p' Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php
            return DB::transaction(function () use ($request, $id) {
                return view('parentportal::homework.show', compact('child', 'assignment', 'attachments'));
```

### F3 — Authorization

clean — both routes sit behind `auth` + `ParentPortalMiddleware` (role gate: `user_type = PARENT`, guardian exists, ≥1 child with `can_access_parent_portal = 1`), and both methods follow AUTH-03: the assignment rows are filtered by `student_id = $child->id` where `$child` comes from `ParentContextService::resolveChild()`, which only ever returns children the parent may see (or aborts 403/redirect). Proved by `grep -n "Gate::\|authorize\|permission" Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php` → no output; the gate is entirely middleware. Cross-cutting note: the parent portal has no permission keys at all — this is module-wide, not this controller's defect (§7).

### F4 — Validation and input

clean — `index()` reads `$request->query('tab', 'pending')` but never writes it anywhere unsafe (the view only compares it against the five known tab keys), and `show(int $id)` relies on the typed route parameter, scoped to the child. No `$request->all()`, no inline validation needed for a read-only screen. Proved by `grep -n "validate\|validated\|->all()\|except(" Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php` → no output.

### F5 — Routes

clean — RTE-01: the only verbs are GET and nothing mutates besides the audit row; RTE-02: both `@index` and `@show` exist (`php -l` passes and both routes resolve in `route:list`); RTE-03: every public method is routed; RTE-05: tenant + auth + role middleware present (see §4). The `{id}` parameter name matches the `int $id` argument exactly, so there is no unbound-route-model trap (`module-finalization.md` §3.3.1: a mismatch would make `show` receive the id but Eloquent would insert). Proved by the §4 route output and `grep -n "public function" Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php`.

### F6 — Controller shape

clean, with two notes: the controller is 121 lines / 2 public methods (CTL-01 fine); return types are present on both methods (CTL-04 ✓, `show()` widens to `View|RedirectResponse` only because of the removed catch — after PHW-05 it returns `: View`). CTL-08 (`request()` helper at lines 66 and 100 while `Request $request` is injected) is folded into PHW-01 (line 66) and PHW-05 (line 100). CTL-03 checked: `show(int $id)` uses `firstOrFail()` instead of route model binding — justified because the record must additionally be scoped by `student_id = $child->id`, so binding would not remove the query; no finding.

### F7 — Models

#### PHW-09 · B · MDL-05 / TEN-01 — both media models fail to override `getMediaModel()`, so homework files are written to the CENTRAL database

| Field | Value |
|---|---|
| **Rule** | MDL-05 / TEN-01 (B) — *every model using Spatie `InteractsWithMedia` in tenant context overrides `getMediaModel()` — otherwise media rows go to the central DB (cross-tenant leak)*. Lowered-from/consistent with SEC: the central `sys_media` is shared by every tenant, so a tenant's row id can collide with another tenant's row. |
| **Where** | `Modules/LmsHomework/app/Models/Homework.php:28-31` and `Modules/LmsHomework/app/Models/HomeworkSubmission.php:16-19` |
| **Root cause** | `config('media-library.media_model')` is `Modules\Prime\Models\Media` (config/media-library.php:73), which pins `protected $connection = 'mysql'` — the CENTRAL database (`Modules/Prime/app/Models/Media.php`). `Homework` and `HomeworkSubmission` both `use InteractsWithMedia` without defining `getMediaModel()`, so Spatie falls back to the central model for both the read and write paths. Every tenant model that stores uploads is expected to override it (`App/Models/TenantMedia.php`'s docstring, and `Modules/SchoolSetup/app/Models/User.php:214`, `Organization`, `Employee` all do). |
| **Consequence** | Teacher-uploaded homework files and student submissions are recorded in `prime_db.sys_media` (shared by ALL tenants) instead of the tenant's `sys_media`; two tenants with id `1` can point at each other's rows — a cross-tenant data leak and a fixture for wrong-file downloads. |
| **Reproduce** | Static only — `grep -rn "function getMediaModel" Modules/LmsHomework/app/Models/` returns nothing, while `config('media-library.media_model')` is the central `Modules\Prime\Models\Media` (pinned to `mysql`). |
| **Fix approach** | Add `public function getMediaModel(): string { return \App\Models\TenantMedia::class; }` to both models (same pattern as `Modules/SchoolSetup/app/Models/User.php:214-218`). |
| **Plan item** | PHW-09 in `02-fix-plan.md` §5 |

```php
// Homework.php:28-31 — CURRENT
class Homework extends BaseModel implements HasMedia
{
    use HasFactory, InteractsWithMedia, SoftDeletes;
    use SanitizesRichText;
```

**Evidence**
```
$ grep -rn "function getMediaModel" Modules/LmsHomework/app/Models/
(no output)
$ grep -n "media_model" config/media-library.php
73:    'media_model' => Media::class,
$ grep -n "connection" Modules/Prime/app/Models/Media.php
12:    protected $connection = 'mysql';
```

#### PHW-10 · L · MDL-04 — 20 relationship methods across the three models have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`…)* |
| **Where** | `Modules/LmsHomework/app/Models/Homework.php:83-154` (14 relations), `Modules/LmsHomework/app/Models/HomeworkSubmission.php:62-85` (4 relations), `Modules/LmsHomework/app/Models/HomeworkAssignment.php:99-102` (`submission()`) |
| **Root cause** | The three classes predate the project's return-type convention: `Homework` (14 relations), `HomeworkSubmission` (`homework`, `assignment`, `gradedBy`, `status`) and `HomeworkAssignment::submission()` all omit the return type, so static analysis and IDE autocomplete cannot see the relation shape. `HomeworkAssignment`'s other 9 relations already have `: BelongsTo`. |
| **Consequence** | Maintainability only — no runtime effect on these pages, but the inconsistency hides relation types from tooling and the next developer. |
| **Reproduce** | Static only — `grep -n "public function "` on the three files shows the untyped methods; see evidence. |
| **Fix approach** | Add `: BelongsTo` / `: HasMany` / `: HasOne` return types; add the `Illuminate\Database\Eloquent\Relations\*` imports (`BelongsTo`, `HasMany` are already imported in `HomeworkAssignment`). |
| **Plan item** | PHW-10 in `02-fix-plan.md` §5 |

```php
// Homework.php:83-86 — CURRENT
    public function academicSession()
    {
        return $this->belongsTo(OrganizationAcademicSession::class, 'academic_session_id');
    }
```

**Evidence**
```
$ grep -n "public function " Modules/LmsHomework/app/Models/Homework.php | grep -v "scope\|Attribute\|Media\|Sanitiz\|Editable\|Deletable" | wc -l
14
$ grep -n "public function " Modules/LmsHomework/app/Models/HomeworkSubmission.php
62:    public function homework()
67:    public function assignment()
72:    public function student(): BelongsTo
77:    public function gradedBy()
82:    public function status()
$ sed -n '99,102p' Modules/LmsHomework/app/Models/HomeworkAssignment.php
    public function submission()
    {
        return $this->hasOne(HomeworkSubmission::class, 'assignment_id');
    }
```

#### PHW-11 · L · STY-01 — the three model files have no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `Modules/LmsHomework/app/Models/Homework.php:1-3`, `Modules/LmsHomework/app/Models/HomeworkAssignment.php:1-3`, `Modules/LmsHomework/app/Models/HomeworkSubmission.php:1-3` |
| **Root cause** | All three files start with `<?php` followed directly by a comment/namespace, without the declaration. The controller itself has it (line 3), so the module convention is mixed. |
| **Consequence** | Style only; scalar coercion semantics stay loose until the declaration is added. |
| **Reproduce** | Static only — `head -3` of each file shows the missing declaration. |
| **Fix approach** | Insert `declare(strict_types=1);` between the PHP tag and the namespace in each file. |
| **Plan item** | PHW-11 in `02-fix-plan.md` §8 |

```php
// HomeworkAssignment.php:1-3 — CURRENT
<?php

namespace Modules\LmsHomework\Models;
```

**Evidence**
```
$ head -3 Modules/LmsHomework/app/Models/HomeworkAssignment.php
<?php
(blank)
namespace Modules\LmsHomework\Models;
$ head -3 Modules/LmsHomework/app/Models/HomeworkSubmission.php
<?php
(blank)
namespace Modules\LmsHomework\Models;
```

#### PHW-12 · M · MDL-02 — `is_active` (and `view_count`) columns are not cast on the models

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` for every boolean, date/datetime, decimal, json/array, and enum column* |
| **Where** | `Modules/LmsHomework/app/Models/HomeworkSubmission.php:48-56` (missing `is_active`), `Modules/LmsHomework/app/Models/HomeworkAssignment.php:50-62` (missing `view_count` int) |
| **Root cause** | The submissions migration creates `is_active` as `boolean` (line 30 of `2026_06_16_122813_create_lms_homework_submissions_table.php`) but `$casts` omits it; the assignment migration creates `view_count` as `unsignedSmallInteger` but `$casts` omits it. `is_active` is in `$fillable` on both models, so one is a plain int/string on every read. |
| **Consequence** | Booleans come back as `0/1` ints instead of `true/false`, so a future `where('is_active', true)` in PHP or a `@if($row->is_active)` in a blade can mis-read; purely a correctness trap waiting for a caller. |
| **Reproduce** | Static only — the two columns exist in the migrations and are absent from the models' casts. |
| **Fix approach** | Add `'is_active' => 'boolean'` to `HomeworkSubmission::$casts` and `'view_count' => 'integer'` to `HomeworkAssignment::$casts`. |
| **Plan item** | PHW-12 in `02-fix-plan.md` §5 |

```php
// HomeworkSubmission.php:48-56 — CURRENT
    protected $casts = [
        'submitted_at'   => 'datetime',
        'graded_at'      => 'datetime',
        'is_late'        => 'boolean',
        'marks_obtained' => 'decimal:2',
        'sub_attachment_media_id'      => 'array',
        'is_resubmission_requested' => 'boolean',
        'score_published_at' => 'datetime',
    ];
```

**Evidence**
```
$ sed -n '30p' database/migrations/tenant/2026_06_16_122813_create_lms_homework_submissions_table.php
            $table->boolean('is_active')->default(true);
$ grep -n "is_active" Modules/LmsHomework/app/Models/HomeworkSubmission.php
43:        'is_active',
$ grep -n "view_count" Modules/LmsHomework/app/Models/HomeworkAssignment.php
39:        'view_count',
```

### F8 — Services and jobs

clean for this controller — it injects `ParentContextService` via the constructor and calls it exactly once per method (`resolveChild`), with no service-side writes opened by these calls. The service itself is owned by the ParentDashboardController report (pre-assigned 2026-10-13); its scanner hits (SVC-01 redirect at line 104, TXN-01 two-write `getOrCreateSession` at line 202, emoji comments at lines 26/32/144) belong to that report — see §7. The `getMediaModel` media concern is PHW-09 (models, F7).

### F9 — Queries and performance

#### PHW-06 · M · QRY-02 — `index()` loads the whole assignment list with `->get()` and never paginates

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H, lowered to M) — *lists are paginated: no `Model::all()` or unbounded `->get()` feeding a list page*. Lowered because the list is bounded by one student's released assignments (typically single digits to a few dozen rows), and the 5-tab client-side switching needs the full set in memory. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php:32-41`, method `index()` |
| **Root cause** | The query filters by `student_id` (a single child) and then `->get()` loads every released, active assignment for that child, plus two eager-load branches, in one pass. With a multi-year history the `'all'` tab could grow, but the pending/overdue/submitted/graded buckets are inherently small windows. |
| **Consequence** | Bounded today; would become a slow page only if a child accumulated hundreds of released assignments. Accepted as a product shape — see plan §10. |
| **Reproduce** | Static only — line 40 is `->get()`. |
| **Fix approach** | Accepted (see §10): pagination would force a redesign of the client-side tab switching for a list that is bounded per child. No plan item. |
| **Plan item** | none — see plan §10 |

```php
// ParentHomeworkController.php:32-41 — CURRENT
        $allAssignments = HomeworkAssignment::where('student_id', $child->id)
            ->where('is_released', true)
            ->where('is_active', true)
            ->with([
                'homework' => fn ($q) => $q->with(['subject', 'difficultyLevel']),
                'submission',
            ])
            ->orderBy('due_date')
            ->get()
            ->filter(fn ($a) => $a->homework !== null)
            ->values();
```

**Evidence**
```
$ sed -n '40p' Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php
            ->get()
```

#### PHW-07 · L · QRY-05 — bucketing and counts are computed in PHP instead of SQL

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M, lowered to L) — *aggregate in SQL, not `->get()->filter()` over whole rows*. Lowered because the source collection is ONE bounded query whose rows are needed whole by four of the five buckets, so SQL aggregation would not save the row load. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php:44-53`, method `index()` |
| **Root cause** | The five buckets are produced by five `$allAssignments->filter(...)` passes and `$counts` by mapping `->count()` over them — all in PHP. This is a deliberate read-once/bucket-often design for client-side tabs. |
| **Consequence** | A handful of extra in-memory passes over a small collection; no measurable cost on the real screen. |
| **Reproduce** | Static only — the `filter` calls at lines 46-50. |
| **Fix approach** | Accepted (see §10): the one-query design is right for the tab switch; SQL versions would either repeat the query 5 times or still load all rows. No plan item. |
| **Plan item** | none — see plan §10 |

```php
// ParentHomeworkController.php:45-53 — CURRENT
        $buckets = [
            'pending'   => $allAssignments->filter(fn ($a) => $a->submission === null && $a->due_date >= now())->values(),
            'overdue'   => $allAssignments->filter(fn ($a) => $a->submission === null && $a->due_date < now())->values(),
            'submitted' => $allAssignments->filter(fn ($a) => $a->submission !== null)->values(),
            'graded'    => $allAssignments->filter(fn ($a) => $a->submission !== null && $a->submission->marks_obtained !== null)->values(),
            'all'       => $allAssignments,
        ];

        $counts = collect($buckets)->map(fn ($b) => $b->count())->toArray();
```

**Evidence**
```
$ sed -n '46,50p' Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php
            'pending'   => $allAssignments->filter(fn ($a) => $a->submission === null && $a->due_date >= now())->values(),
            'overdue'   => $allAssignments->filter(fn ($a) => $a->submission === null && $a->due_date < now())->values(),
            'submitted' => $allAssignments->filter(fn ($a) => $a->submission !== null)->values(),
            'graded'    => $allAssignments->filter(fn ($a) => $a->submission !== null && $a->submission->marks_obtained !== null)->values(),
            'all'       => $allAssignments,
```

#### PHW-08 · L · QRY-03 — `show()` does not eager-load the homework relations the detail view renders

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M, lowered to L) — *select only what you use / eager-load what you render*. With one record, the lazy loads are 4 extra queries, not N+1. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php:85-90`, method `show()`, feeding `Modules/ParentPortal/resources/views/homework/show.blade.php` |
| **Root cause** | The `->with([...])` list loads `homework.subject`, `homework.difficultyLevel` and `submission`, but the view also renders `$homework->topic` (line 196-201), `$homework->lesson` (202-207), `$homework->class` and `$homework->section` (221-222) — each a lazy query fired after the controller returns. |
| **Consequence** | Four small extra queries per detail view; negligible on a single record, wrong discipline for the model. |
| **Reproduce** | Static only — the with-array (lines 85-89) lacks `homework.topic/lesson/class/section`; the blade uses them. |
| **Fix approach** | Add the four keys to the eager-load array in the PHW-05 rewrite of `show()`. |
| **Plan item** | PHW-05 in `02-fix-plan.md` §1 (PHW-08 is fixed by the same rewrite — see plan §10) |

```php
// ParentHomeworkController.php:85-89 — CURRENT
                    ->with([
                        'homework.subject',
                        'homework.difficultyLevel',
                        'submission',
                    ])
```

**Evidence**
```
$ grep -n "homework->topic\|homework->lesson\|homework->class\|homework->section" Modules/ParentPortal/resources/views/homework/show.blade.php
196:                        @if($homework->topic)
202:                        @if($homework->lesson)
221:                                {{ $homework->class?->name ?? '' }}
222:                                {{ $homework->section?->name ?? '' }}
```

### F10 — Views

#### PHW-05 · B · VIEW / ERR — the `show` view references `$homework` and `$submission`, which the controller never passes — the detail page 500s

| Field | Value |
|---|---|
| **Rule** | VIEW (Blade contract) / F13 deep-read #7 — a view must receive every variable it reads. Severity B: a fatal on a routed page. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php:105` (passes `child, assignment, attachments`) and `Modules/ParentPortal/resources/views/homework/show.blade.php:3-11` (reads `$homework`, `$submission`) |
| **Root cause** | `show()` returns `view('parentportal::homework.show', compact('child', 'assignment', 'attachments'))`, but the blade was written for a different controller's payload: line 4 `$pageTitle = $homework->title;`, line 5 `$sub = $submission;`. There is no view composer that shares `$homework`/`$submission` (the only composer in the module is for `parentportal::layouts.app` and shares `pptActiveChild`/`pptChildren`/`pptUnreadCount` — `ParentPortalServiceProvider.php:159-182`). Undefined `$homework` renders null, and the first method call (`$homework->assign_date->format(...)` at blade line 188, or `$homework->due_date->format(...)` at 51/193 in other branches) throws `Error: Call to a member function format() on null` → HTTP 500. The list page never links to the detail page (grep for `parent-portal.homework.show` in the module returns only this blade's own back-link), so the broken screen is reachable only by typing the URL. |
| **Consequence** | Opening `/parent-portal/homework/{id}` always renders a 500 instead of the assignment detail — no parent can read homework instructions, attachments, marks or feedback, even though the index page invites "View" expectations from the dashboard cards. |
| **Reproduce** | Browse to `http://test.localhost:8000/parent-portal/homework/1` as a parent: Laravel renders `Undefined variable $homework` / `Attempt to read property on null` (Blade, `show.blade.php:4`). Static proof: controller line 105 vs blade lines 4-5. |
| **Fix approach** | In `show()`, pass `homework` and `submission` (from `$assignment->homework` / `$assignment->submission`) to the view, guard against a soft-deleted homework (the index filter at line 41 proves homework can be null), and drop the try/catch + transaction in the same rewrite (fixes PHW-02, PHW-04, PHW-08). |
| **Plan item** | PHW-05 in `02-fix-plan.md` §1 |

```php
// ParentHomeworkController.php:105 — CURRENT
                return view('parentportal::homework.show', compact('child', 'assignment', 'attachments'));
```

**Evidence**
```
$ sed -n '105p' Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php
                return view('parentportal::homework.show', compact('child', 'assignment', 'attachments'));
$ sed -n '4,6p' Modules/ParentPortal/resources/views/homework/show.blade.php
    $pageTitle = $homework->title;
    $sub       = $submission;
    $isOverdue = !$sub && $homework->due_date < now();
$ grep -rn "homework.show" Modules/ParentPortal/resources/views/ | grep -v "show.blade"
(no output — no view links to the detail page)
```

### F11 — Security and tenancy

clean — no `env()` (SEC-01); no hard-coded ids or `?? 1` fallbacks (SEC-03); no personal data over-exposed (both pages show only the parent's own child's homework; the audit context logs the student id/name — deliberate, parent-facing); the `{!! nl2br(e($homework->description)) !!}` in the show view double-escapes before outputting (VIEW-03 safe). The tenant-media leak is PHW-09 (F7). Proved by `grep -n "env(\|?? 1" Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php` → no output.

### F12 — Style

clean for the controller apart from the import list — `declare(strict_types=1)` present at line 3, camelCase names, English comments (box-drawing `──` decoration not flagged). After PHW-01 and PHW-05 are applied, four imports become unused: `ModelNotFoundException`, `Log`, `DB`, `RedirectResponse` (the last two only via the old catch/transaction shapes) — reported as PHW-13. The models' missing `strict_types` is PHW-11.

#### PHW-13 · L · CTL-10 / STY-05 — four imports become dead once the try/catch and transaction are removed

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M, lowered to L) / STY-05 — *no dead code: unused imports; one import per class*. Lowered because the dead imports only exist after PHW-01/PHW-05 are applied. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php:7-18` |
| **Root cause** | `ModelNotFoundException` is used only by the rethrow in the catch being removed; `Log` only by the two `Log::error` lines being replaced by `report($e)`/removal; `DB` only by the `DB::transaction` being removed; `RedirectResponse` only by the `View|RedirectResponse` return type being narrowed to `View`. |
| **Consequence** | Dead imports confuse the next reader and Triplicate-style tooling; `php -l` stays green so nothing flags them. |
| **Reproduce** | Static only — after the PHW-01/PHW-05 rewrites, `grep -nE "\bLog\b|\bDB\b|ModelNotFoundException|RedirectResponse"` on the file finds only the imports. |
| **Fix approach** | Delete the four imports once PHW-01 and PHW-05 are applied (item sits in §8 so it applies last). |
| **Plan item** | PHW-13 in `02-fix-plan.md` §8 |

```php
// ParentHomeworkController.php:7-18 — CURRENT
use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\DB;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Modules\LmsHomework\Models\HomeworkAssignment;
use Modules\ParentPortal\Services\ParentContextService;
use Illuminate\Http\RedirectResponse;
```

**Evidence**
```
$ sed -n '7,18p' Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php
use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\DB;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Modules\LmsHomework\Models\HomeworkAssignment;
use Modules\ParentPortal\Services\ParentContextService;
use Illuminate\Http\RedirectResponse;
```

### F13 — Deep read (answer all 8 questions for the two mutating writes)

The only mutations on this page are the two `activityLog()` audit inserts (`index` line 60, `show` line 94). All business reads happen before them.

| # | Question | Answer |
|---|---|---|
| 1 | Can a write overwrite data it should not? | ok — the audit inserts create new rows; they never update or delete anything. |
| 2 | Is anything deleted before its replacement is stored? | ok — nothing is deleted anywhere on these pages. |
| 3 | Duplicate implementations of one operation? | ok for this controller — both pages use the same `activityLog` helper and the same `ParentContextService::resolveChild`. (The `index` comment says it "mirrors StudentLmsController"; the bucketing logic is duplicated with the student portal but that is cross-module, not this controller's defect.) |
| 4 | Soft-delete × unique index trap? | ok — assignments/submissions both soft-delete and the queries filter `is_active`/`HomeWorkAssignment` default scope; no unique-index re-create path on these read pages. |
| 5 | Race? | ok for this controller — reads only. (`ParentContextService::getOrCreateSession` has the create race, owned by the dashboard report — §7.) |
| 6 | Authorization hole? | ok — rows are filtered by the guardian-resolved child; the route is role-gated. |
| 7 | Does any message lie? | PHW-05 — the detail page's variables do not exist (no message; a blank 500). PHW-02's error flash "The operation could not be completed." lies about cause when the page failed on render. |
| 8 | Dead feature? | PHW-05 — the detail route is never linked from the list page, so the broken view is only reachable by direct URL; the `child` variable passed to the show view is unused by the blade. |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` | `resolveChild()` touches HTTP (`abort(redirect(...))`, SVC-01 line 104) and `getOrCreateSession()` does 2 writes with no transaction (TXN-01 line 202) + has the check-then-act create race (TXN-06); emoji comments (STY-04 lines 26/32/144). This controller calls `resolveChild()` once per method. | SVC-01, TXN-01, TXN-06 | tarun/ParentPortal-done/ParentDashboardController report |
| `Modules/StudentProfile/app/Models/Student.php` | No `full_name` accessor exists, so the `?? $child?->full_name ?? null` fallback in both audit contexts is always null; harmless, but the fallback is misleading. Also `Student` itself is owned by gaurav/StudentProfile/StudentController. | — | gaurav (when the Student report is fixed) |
| ParentPortal module-wide | The whole portal authorizes by role middleware (`ParentPortalMiddleware`) with no permission keys at all; consistent module-wide, not a per-controller defect. | AUTH | module-level decision, not this plan |
| `config/media-library.php` | `'media_model' => Media::class` points every un-opted-in tenant model at the central `sys_media`; PHW-09 fixes the two homework models, the same defect pattern is documented for the whole app in `Modules/Prime/app/Models/TenantMedia.php`. | MDL-05 / TEN-01 | app-wide — other media models audited by their own modules |
| `Modules/ParentPortal/resources/views/homework/show.blade.php` | The view itself is only reached from this one controller; after PHW-05 it renders with the correct variables. No separate fix on the blade is needed. | VIEW | this plan (via PHW-05) |

## 8. Not covered, and why

- **Live relationship resolution (MDL-04 "resolve", F7) and live row counts** — no tenant database is reachable from this host (default `prime_db` connection returned 0 tenant tables); the models' relations were verified structurally against the related models and the migrations, and live counts are marked ⚠ UNVERIFIED.
- **The other LmsHomework module classes** (`LmsStorageService`, seeders, the teacher-side factory controllers) — out of scope; only the three models the parent portal reaches were audited here (they are pre-assigned to this report).
- **`Modules/ParentPortal/routes/web.php`** — the whole file is shared by ~30 ParentPortal controllers; only the two homework route rows (lines 67-70) were audited here.
- **`Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php`** — common to the module; owned by the ParentHealthController report (claimed 2026-10-13). Only its effect on these two routes was checked.
- **Browser rendering** — no browser session was run; blades were checked by grep/read only. The PHW-05 500 is proven statically (missing variables), not by clicking.
- **No Pint run** — the audit is read-only (D4); the plan's verification step runs Pint on touched files.