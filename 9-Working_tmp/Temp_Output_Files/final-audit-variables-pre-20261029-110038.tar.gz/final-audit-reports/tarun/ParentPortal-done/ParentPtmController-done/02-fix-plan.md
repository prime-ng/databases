# Fix Plan — ParentPortal / ParentPtmController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `database/migrations/tenant/2026_06_16_0943*.php` | existing tenant migrations — never edited (§1 standing rule) |
| `Modules/Notification/app/Models/Notification.php` | owned by the Notification module |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | ⚠ SHARED — owned by [tarun/ParentPortal-done/ParentHealthController](../ParentHealthController-done/01-report.md) |
| `Modules/ParentPortal/app/Services/ParentContextService.php` | ⚠ SHARED — owned by [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) |
| `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` | ⚠ SHARED — owned by [tarun/ParentPortal-done/ParentComplaintController](../ParentComplaintController-done/01-report.md) |
| `Modules/ParentPortal/routes/web.php` | ⚠ SHARED — no route change is needed for this plan |
| `Modules/Prime/app/Models/Dropdown.php` | owned by [tarun/GlobalMaster-done/DropdownController](../../GlobalMaster-done/DropdownController-done/01-report.md) |

## 1. Blockers reachable today

- [x] **PPTC-01** · B · ERR-01 · `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:277-279,438-440` — stop flashing the raw exception text; throw and catch `\DomainException` only.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`ParentPtmController.php:277-279`, `book`):
    ```php
        } catch (\Throwable $e) {
            return back()->with('error', $e->getMessage());
        }
    ```
  - **After:** (`book`)
    ```php
        } catch (\DomainException $e) {
            return back()->with('error', $e->getMessage());
        }
    ```
  - **Before** (`ParentPtmController.php:438-440`, `reschedule`):
    ```php
        } catch (\Throwable $e) {
            return back()->with('error', $e->getMessage());
        }
    ```
  - **After:** (`reschedule`)
    ```php
        } catch (\DomainException $e) {
            return back()->with('error', $e->getMessage());
        }
    ```
  - **Also change** every business-rule throw inside `book()` and `reschedule()` from `\Exception` to `\DomainException`. The exact current lines (verified with `grep -n 'throw new \\Exception'`):
    - `ParentPtmController.php:159` — `throw new \Exception('This slot is no longer available.');`
    - `ParentPtmController.php:163` — `throw new \Exception('This slot is already fully booked.');`
    - `ParentPtmController.php:167` — `throw new \Exception('This slot is blocked and cannot be booked.');`
    - `ParentPtmController.php:172` — `throw new \Exception('This slot has been blocked due to a blockout.');`
    - `ParentPtmController.php:180` — `throw new \Exception('Booking window is closed for this event.');`
    - `ParentPtmController.php:191` — `throw new \Exception('You have already booked this slot.');`
    - `ParentPtmController.php:203` — `throw new \Exception('You already have a booking for this PTM event.');`
    - `ParentPtmController.php:218` — `throw new \Exception('You already have another booking at this time.');`
    - `ParentPtmController.php:393` — `throw new \Exception('The target slot is no longer available.');`
    - `ParentPtmController.php:397` — `throw new \Exception('The target slot is already full.');`
    - `ParentPtmController.php:401` — `throw new \Exception('The target slot is blocked.');`
    In each, replace only `new \Exception(` with `new \DomainException(`; keep the message text exactly.
  - **Verify:** `grep -n 'throw new .Exception' Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php; grep -n 'catch (.Throwable' Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Expect:** the first grep prints no `throw new \Exception` lines between 159 and 218 / 393 and 401 (all are now `\DomainException`); the second prints nothing once PPTC-02 and PPTC-01 are both applied.
  - **Effort:** S

- [x] **PPTC-08** · H · VAL-04 · `Modules/ParentPortal/app/Http/Requests/RescheduleParentPtmRequest.php:15` + `ParentPtmController.php:389-394` — a soft-deleted target slot passes validation, then `reschedule()` passes null into a typed parameter.
  - **Touches:** `Modules/ParentPortal/app/Http/Requests/RescheduleParentPtmRequest.php`, `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`RescheduleParentPtmRequest.php:1-5`):
    ```php
    <?php

    namespace Modules\ParentPortal\Http\Requests;

    class RescheduleParentPtmRequest extends ParentPortalBaseRequest
    ```
  - **After** (add the `Rule` import and `strict_types`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\ParentPortal\Http\Requests;

    use Illuminate\Validation\Rule;

    class RescheduleParentPtmRequest extends ParentPortalBaseRequest
    ```
  - **Before** (`RescheduleParentPtmRequest.php:14-16`):
    ```php
        return [
            'new_slot_id' => 'required|integer|exists:ptm_slots,id',
        ];
    ```
  - **After:**
    ```php
        return [
            'new_slot_id' => [
                'required',
                'integer',
                Rule::exists('ptm_slots', 'id')->whereNull('deleted_at'),
            ],
        ];
    ```
  - **Before** (`ParentPtmController.php:389-394`, `reschedule`):
    ```php
                    $newSlot = PtmSlot::where('id', $newSlotId)->lockForUpdate()->first();
                    $this->assertSlotBelongsToChildClassSection($newSlot, $child);

                    if (!$newSlot || !$newSlot->is_active) {
                        throw new \Exception('The target slot is no longer available.');
                    }
    ```
  - **After** (guard first, then the typed helper):
    ```php
                    $newSlot = PtmSlot::where('id', $newSlotId)->lockForUpdate()->first();

                    if (! $newSlot || ! $newSlot->is_active) {
                        throw new \DomainException('The target slot is no longer available.');
                    }

                    $this->assertSlotBelongsToChildClassSection($newSlot, $child);
    ```
  - **Verify:** `grep -n "whereNull('deleted_at')\|assertSlotBelongsToChildClassSection(\$newSlot" Modules/ParentPortal/app/Http/Requests/RescheduleParentPtmRequest.php Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Expect:** one hit for `whereNull('deleted_at')` in the request; in the controller the `assertSlotBelongsToChildClassSection($newSlot` line now appears after the `! $newSlot` guard.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

Apply PPTC-01 first: once the blanket `catch (\Throwable)` is gone, any SQL/duplicate-key failure reaches the central renderer (a 500) instead of being flashed. Fix these races so that 500 does not happen.

- [x] **PPTC-04** · H · TXN-06 · `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:299-328` — `cancel()` must re-read the booking under a lock inside the transaction.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`ParentPtmController.php:299-314`):
    ```php
        DB::transaction(function () use ($booking, $child) {
            $booking->update([
                'status'       => 'CANCELLED',
                'cancelled_at' => now(),
            ]);

            $slot = PtmSlot::where('id', $booking->slot_id)->lockForUpdate()->first();
            if ($slot && $slot->booked_count > 0) {
                $slot->decrement('booked_count');

                if ($slot->booked_count == 0) {
                    $slot->update(['status' => 'AVAILABLE']);
                } else {
                    $slot->update(['status' => 'BOOKED']);
                }
            }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($booking, $child) {
            $locked = PtmBooking::where('id', $booking->id)->lockForUpdate()->first();

            if (! $locked || $locked->status !== 'CONFIRMED') {
                throw new \DomainException('This booking can no longer be cancelled.');
            }

            $locked->update([
                'status'       => 'CANCELLED',
                'cancelled_at' => now(),
            ]);

            $slot = PtmSlot::where('id', $locked->slot_id)->lockForUpdate()->first();
            if ($slot && $slot->booked_count > 0) {
                $slot->decrement('booked_count');

                if ($slot->booked_count == 0) {
                    $slot->update(['status' => 'AVAILABLE']);
                } else {
                    $slot->update(['status' => 'BOOKED']);
                }
            }
    ```
  - Leave the `activityLog(...)` block that follows unchanged.
  - **Verify:** `sed -n '299,320p' Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Expect:** the transaction opens with `$locked = PtmBooking::where('id', $booking->id)->lockForUpdate()->first();` and a status guard.
  - **Effort:** S

- [x] **PPTC-05** · H · TXN-06 · `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:373-386` — `reschedule()` must lock and re-check the booking before cancelling it.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`ParentPtmController.php:373-386`):
    ```php
                $newBookingId = DB::transaction(function () use ($booking, $newSlotId, $child) {
                    // Cancel old booking
                    $booking->update([
                        'status'        => 'CANCELLED',
                        'cancelled_at'  => now(),
                        'cancel_reason' => 'Rescheduled to another slot',
                    ]);
    ```
  - **After:**
    ```php
                $newBookingId = DB::transaction(function () use ($booking, $newSlotId, $child) {
                    $lockedBooking = PtmBooking::where('id', $booking->id)->lockForUpdate()->first();

                    if (! $lockedBooking || $lockedBooking->status !== 'CONFIRMED') {
                        throw new \DomainException('This booking can no longer be rescheduled.');
                    }

                    // Cancel old booking
                    $lockedBooking->update([
                        'status'        => 'CANCELLED',
                        'cancelled_at'  => now(),
                        'cancel_reason' => 'Rescheduled to another slot',
                    ]);
    ```
  - **Verify:** `sed -n '373,384p' Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Expect:** the transaction opens with a `lockForUpdate()` fetch of the booking and a `status !== 'CONFIRMED'` guard.
  - **Effort:** S

- [x] **PPTC-06** · H · TXN-06 · `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:206-219` — lock the child's existing bookings so two cross-event bookings cannot both pass the overlap check.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`ParentPtmController.php:206-219`):
    ```php
                    // Prevent student time overlap with any other confirmed booking
                    $slotStart = $locked->slot_start;
                    $slotEnd = $locked->slot_end;
                    $timeOverlap = PtmBooking::where('student_id', $child->id)
                        ->where('status', 'CONFIRMED')
                        ->whereHas('slot', function ($q) use ($slotStart, $slotEnd) {
                            $q->where('slot_start', '<', $slotEnd)
                              ->where('slot_end', '>', $slotStart);
                        })
                        ->exists();

                    if ($timeOverlap) {
                        throw new \Exception('You already have another booking at this time.');
                    }
    ```
  - **After:**
    ```php
                    // Prevent student time overlap with any other confirmed booking
                    $slotStart = $locked->slot_start;
                    $slotEnd = $locked->slot_end;
                    $timeOverlap = PtmBooking::where('student_id', $child->id)
                        ->where('status', 'CONFIRMED')
                        ->with('slot')
                        ->lockForUpdate()
                        ->get()
                        ->contains(function ($existing) use ($slotStart, $slotEnd) {
                            $slot = $existing->slot;

                            return $slot && $slot->slot_start < $slotEnd && $slot->slot_end > $slotStart;
                        });

                    if ($timeOverlap) {
                        throw new \DomainException('You already have another booking at this time.');
                    }
    ```
  - **Verify:** `sed -n '209,222p' Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Expect:** the overlap check now has `->lockForUpdate()->get()->contains(...)` instead of `->exists()`.
  - **Effort:** M

## 3. Errors & transactions (F1/F2)

- [x] **PPTC-02** · M · ERR-07 · `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:58-70,125-138` — remove the read-path try/catch so the central handler is the single error renderer.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`ParentPtmController.php:58-70`, `index`):
    ```php
            try {
                activityLog(auth()->user(), 'Viewed', [
                    'message' => 'Viewed PTM events',
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                ]);
            } catch (\Throwable $e) {
                Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
            }
    ```
  - **After:**
    ```php
        activityLog(auth()->user(), 'Viewed', [
            'message' => 'Viewed PTM events',
            'context' => [
                'student_id' => $child?->id,
                'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                'module' => 'ParentPortal',
                'route' => request()->route()?->getName(),
            ],
        ]);
    ```
  - **Before** (`ParentPtmController.php:125-138`, `show`):
    ```php
            try {
                activityLog(auth()->user(), 'Viewed', [
                    'message' => 'Viewed PTM event details',
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                    'ptm_event_id' => $ptmEvent->id,
                ]);
            } catch (\Throwable $e) {
                Log::error('view log failed', ['method' => 'show', 'error' => $e->getMessage()]);
            }
    ```
  - **After:**
    ```php
        activityLog(auth()->user(), 'Viewed', [
            'message' => 'Viewed PTM event details',
            'context' => [
                'student_id' => $child?->id,
                'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                'module' => 'ParentPortal',
                'route' => request()->route()?->getName(),
            ],
            'ptm_event_id' => $ptmEvent->id,
        ]);
    ```
  - Delete the four comment lines that begin `// Rule A1, scoped to the audit write.` above each block (they cite a rule superseded by D1).
  - **Verify:** `grep -n 'view log failed' Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **PPTC-03** · M · ERR-05 · `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:257-259,345-347` — log the exception (with its trace), not the message string.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`ParentPtmController.php:257-259`, `book`):
    ```php
                        } catch (\Exception $e) {
                            \Log::error('Error creating PTM booking notification: ' . $e->getMessage());
                        }
    ```
  - **After:**
    ```php
                        } catch (\Exception $e) {
                            report($e);
                        }
    ```
  - **Before** (`ParentPtmController.php:345-347`, `cancel`):
    ```php
                } catch (\Exception $e) {
                    \Log::error('Error creating PTM cancellation notification: ' . $e->getMessage());
                }
    ```
  - **After:**
    ```php
                } catch (\Exception $e) {
                    report($e);
                }
    ```
  - **Verify:** `grep -n 'Error creating PTM' Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

- [x] **PPTC-07** · L · AUTH-04 · `Modules/ParentPortal/app/Http/Requests/BookParentPtmRequest.php:7-33` — the slot/class-section check runs in both the FormRequest and the controller; keep one.
  - **Touches:** `Modules/ParentPortal/app/Http/Requests/BookParentPtmRequest.php`
  - **Before** (`BookParentPtmRequest.php:7-33`):
    ```php
        public function authorize(): bool
        {
            if (!parent::authorize()) {
                return false;
            }

            try {
                $child = app(\Modules\ParentPortal\Services\ParentContextService::class)->resolveChild($this);
                $session = $child->currentSession()->first();
                $classSectionId = $session?->class_section_id;

                $slot = $this->route('slot');
                if (!$slot instanceof \Modules\Ptm\Models\PtmSlot) {
                    $slot = \Modules\Ptm\Models\PtmSlot::find($slot);
                }

                if (!$slot || !$classSectionId) {
                    return false;
                }

                $slotClassSectionId = $slot->assignment?->eventClassSection?->class_section_id;

                return $slotClassSectionId === $classSectionId;
            } catch (\Exception $e) {
                return false;
            }
        }
    ```
  - **After:** (the controller keeps the authoritative check via `assertSlotBelongsToChildClassSection()`)
    ```php
        public function authorize(): bool
        {
            return parent::authorize();
        }
    ```
  - **Verify:** `sed -n '7,13p' Modules/ParentPortal/app/Http/Requests/BookParentPtmRequest.php`
  - **Expect:** `authorize()` is a one-line `return parent::authorize();`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [x] **PPTC-14** · M · MDL-02 · `Modules/Ptm/app/Models/PtmBlockout.php:30-31` — cast the TIME columns as strings, not datetimes.
  - **Touches:** `Modules/Ptm/app/Models/PtmBlockout.php`
  - **Before** (`PtmBlockout.php:28-36`):
    ```php
        protected $casts = [
            'blockout_date' => 'date',
            'start_time' => 'datetime',
            'end_time' => 'datetime',
            'is_active' => 'boolean',
            'created_at' => 'datetime',
            'updated_at' => 'datetime',
            'deleted_at' => 'datetime',
        ];
    ```
  - **After:**
    ```php
        protected $casts = [
            'blockout_date' => 'date',
            'start_time' => 'string',
            'end_time' => 'string',
            'is_active' => 'boolean',
            'created_at' => 'datetime',
            'updated_at' => 'datetime',
            'deleted_at' => 'datetime',
        ];
    ```
  - **Verify:** `grep -n "start_time\|end_time" Modules/Ptm/app/Models/PtmBlockout.php`
  - **Expect:** both cast to `'string'`.
  - **Effort:** S

- [x] **PPTC-21** · M · SEC-03 · `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:254,342` — drop the `auth()->id() ?? 1` fallback in both notification writes.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`ParentPtmController.php:252-255`, `book`):
    ```php
                                'notification_status_id'=> 'SENT',
                                'created_by'            => auth()->id() ?? 1,
                                'is_active'             => true,
    ```
  - **After:**
    ```php
                                'notification_status_id'=> 'SENT',
                                'created_by'            => auth()->id(),
                                'is_active'             => true,
    ```
  - **Before** (`ParentPtmController.php:340-343`, `cancel`):
    ```php
                        'notification_status_id'=> 'SENT',
                        'created_by'            => auth()->id() ?? 1,
                        'is_active'             => true,
    ```
  - **After:**
    ```php
                        'notification_status_id'=> 'SENT',
                        'created_by'            => auth()->id(),
                        'is_active'             => true,
    ```
  - **Verify:** `grep -n 'auth()->id() ?? 1' Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **PPTC-17** · H · QRY-01 · `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:51` — eager-load the relation the view reads.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`ParentPtmController.php:47-52`):
    ```php
            $myBookings = PtmBooking::where('booked_by_user_id', auth()->id())
                ->where('student_id', $child->id)
                ->where('status', 'CONFIRMED')
                ->whereIn('ptm_event_id', $events->pluck('id'))
                ->with(['slot.assignment.ptmEvent', 'slot.teacher'])
                ->get();
    ```
  - **After:** (the view reads `$b->slot->event`, line 41 of `index.blade.php`)
    ```php
            $myBookings = PtmBooking::where('booked_by_user_id', auth()->id())
                ->where('student_id', $child->id)
                ->where('status', 'CONFIRMED')
                ->whereIn('ptm_event_id', $events->pluck('id'))
                ->with(['slot.event', 'slot.teacher'])
                ->get();
    ```
  - **Verify:** `grep -n "with(\['slot" Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Expect:** one line containing `->with(['slot.event', 'slot.teacher'])`.
  - **Effort:** S

## 7. Views (F10)

- [x] **PPTC-19** · L · VIEW-03 · `Modules/ParentPortal/resources/views/ptm/show.blade.php:267-269` — render the confirm dialog as plain text, not raw HTML.
  - **Touches:** `Modules/ParentPortal/resources/views/ptm/show.blade.php`
  - **Before** (`show.blade.php:267-269`):
    ```js
                    Swal.fire({
                        title: 'Confirm Booking',
                        html: `Book slot <strong>${slotTime}</strong> with <strong>${teacherName}</strong>?`,
    ```
  - **After:**
    ```js
                    Swal.fire({
                        title: 'Confirm Booking',
                        text: `Book slot ${slotTime} with ${teacherName}?`,
    ```
  - **Verify:** `grep -n 'html: .Book slot' Modules/ParentPortal/resources/views/ptm/show.blade.php`
  - **Expect:** no output (the option is now `text:`).
  - **Effort:** S

## 8. Style (F12) — one item per file group

- [x] **PPTC-11** · M · CTL-05 · `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:61-66,128-133,264-269,318-323,424-429` — extract the copy-pasted audit context into one helper.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`ParentPtmController.php:62-66`, one of five identical blocks):
    ```php
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
    ```
  - **After** (replace the `'context' => [ ... ]` block at all five sites with this single line):
    ```php
                    'context' => $this->activityContext($request, $child),
    ```
  - **Before** (there is now no call to the helper; add the method immediately above `assertSlotBelongsToChildClassSection`, currently line 467):
    ```php
        private function assertSlotBelongsToChildClassSection(PtmSlot $slot, $child): void
    ```
  - **After:**
    ```php
        /**
         * Build the shared audit context for a PTM action.
         */
        private function activityContext(Request $request, $child): array
        {
            return [
                'student_id' => $child?->id,
                'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                'module' => 'ParentPortal',
                'route' => $request->route()?->getName(),
            ];
        }

        private function assertSlotBelongsToChildClassSection(PtmSlot $slot, $child): void
    ```
  - **Verify:** `grep -c "activityContext" Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Expect:** `6` (one method definition plus five call sites).
  - **Effort:** S

- [x] **PPTC-13** · L · STY-04 · `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:447-449` — delete the orphan docblock.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`ParentPtmController.php:447-450`):
    ```php
        /**
         * Ensure the PTM slot is assigned to the child's class-section.
         */
        /**
    ```
  - **After:**
    ```php
        /**
    ```
  - **Verify:** `grep -c "Ensure the PTM slot is assigned" Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Expect:** `0`.
  - **Effort:** S

- [x] **PPTC-15** · L · MDL-04 · `Modules/Ptm/app/Models/PtmEvent.php`, `PtmSlot.php`, `PtmSlotBooking.php`, `PtmBlockout.php` — add `declare(strict_types=1)` and relation/accessor return types; run Pint.
  - **Touches:** `Modules/Ptm/app/Models/PtmEvent.php`, `Modules/Ptm/app/Models/PtmSlot.php`, `Modules/Ptm/app/Models/PtmSlotBooking.php`, `Modules/Ptm/app/Models/PtmBlockout.php`
  - **Before** (`PtmEvent.php:1-5` — the same missing `strict_types` applies to all four models):
    ```php
    <?php

    namespace Modules\Ptm\Models;

    use Modules\SchoolSetup\Models\User;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Ptm\Models;

    use Modules\SchoolSetup\Models\User;
    ```
  - **Before** (`PtmSlot.php:118-128`):
    ```php
        public function event()
        {
            return $this->hasOneThrough(
                PtmEvent::class,
                PtmAssignment::class,
                'id', // Foreign key on assignments table...
                'id', // Foreign key on events table...
                'assignment_id', // Local key on slots table...
                'ptm_event_id' // Local key on assignments table...
            );
        }
    ```
  - **After:**
    ```php
        public function event(): \Illuminate\Database\Eloquent\Relations\HasOneThrough
        {
            return $this->hasOneThrough(
                PtmEvent::class,
                PtmAssignment::class,
                'id',
                'id',
                'assignment_id',
                'ptm_event_id'
            );
        }
    ```
  - Then run `vendor/bin/pint Modules/Ptm/app/Models/PtmEvent.php Modules/Ptm/app/Models/PtmSlot.php Modules/Ptm/app/Models/PtmSlotBooking.php Modules/Ptm/app/Models/PtmBlockout.php --format agent`.
  - **Verify:** `grep -c "declare(strict_types=1)" Modules/Ptm/app/Models/PtmEvent.php Modules/Ptm/app/Models/PtmSlot.php Modules/Ptm/app/Models/PtmSlotBooking.php Modules/Ptm/app/Models/PtmBlockout.php`
  - **Expect:** `1` for each file.
  - **Effort:** S

- [x] **PPTC-22** · L · STY-01 · `Modules/ParentPortal/app/Http/Requests/BookParentPtmRequest.php`, `CancelParentPtmRequest.php`, `RescheduleParentPtmRequest.php` — add `declare(strict_types=1)` and run Pint.
  - **Touches:** `Modules/ParentPortal/app/Http/Requests/BookParentPtmRequest.php`, `Modules/ParentPortal/app/Http/Requests/CancelParentPtmRequest.php`, `Modules/ParentPortal/app/Http/Requests/RescheduleParentPtmRequest.php`
  - **Before** (`BookParentPtmRequest.php:1-4`):
    ```php
    <?php

    namespace Modules\ParentPortal\Http\Requests;

    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\ParentPortal\Http\Requests;

    ```
  - Apply the same insertion to `CancelParentPtmRequest.php` and `RescheduleParentPtmRequest.php` (note PPTC-08 already adds it to `RescheduleParentPtmRequest`; skip that file if PPTC-08 is ticked).
  - Then run `vendor/bin/pint Modules/ParentPortal/app/Http/Requests/BookParentPtmRequest.php Modules/ParentPortal/app/Http/Requests/CancelParentPtmRequest.php Modules/ParentPortal/app/Http/Requests/RescheduleParentPtmRequest.php --format agent`.
  - **Verify:** `grep -c "declare(strict_types=1)" Modules/ParentPortal/app/Http/Requests/BookParentPtmRequest.php Modules/ParentPortal/app/Http/Requests/CancelParentPtmRequest.php`
  - **Expect:** `1` for each file.
  - **Effort:** S

- [x] **PPTC-23** · L · STY-02 · `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:7-20` — sort the imports and run Pint on the one file.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php`
  - **Before** (`ParentPtmController.php:7-20`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Modules\ParentPortal\Http\Requests\RescheduleParentPtmRequest;
    use Modules\ParentPortal\Http\Requests\CancelParentPtmRequest;
    use Modules\ParentPortal\Http\Requests\BookParentPtmRequest;
    use Illuminate\Support\Facades\DB;
    use Illuminate\View\View;
    use Modules\Ptm\Models\PtmBlockout;
    use Modules\Ptm\Models\PtmSlotBooking as PtmBooking;
    use Modules\Ptm\Models\PtmEvent;
    use Modules\Ptm\Models\PtmSlot;
    use Modules\ParentPortal\Services\ParentContextService;
    use Illuminate\Support\Facades\Log;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    use Modules\ParentPortal\Http\Requests\BookParentPtmRequest;
    use Modules\ParentPortal\Http\Requests\CancelParentPtmRequest;
    use Modules\ParentPortal\Http\Requests\RescheduleParentPtmRequest;
    use Modules\ParentPortal\Services\ParentContextService;
    use Modules\Ptm\Models\PtmBlockout;
    use Modules\Ptm\Models\PtmEvent;
    use Modules\Ptm\Models\PtmSlot;
    use Modules\Ptm\Models\PtmSlotBooking as PtmBooking;
    ```
  - Then run `vendor/bin/pint Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php --format agent`.
  - **Verify:** `vendor/bin/pint --test Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php 2>&1 | tail -1`
  - **Expect:** `{"tool":"pint","result":"pass",...}` (no fixers listed).
  - **Effort:** S

## 9. Deferred / decisions

- [x] **PPTC-10** · M · DECISION · CTL-02 — `book()` (137 lines) and `reschedule()` (90 lines) are over the 80-line limit. Extract the write-and-log step into a private helper now, and/or fold it into the shared booking service?
  - **Why it is a decision:** D3 forbids a god-controller split in this pass; a method extraction is behaviour-preserving but overlaps the shared-service question raised by the API report (`../ParentPtmApiController-done/01-report.md` PPTM-09).
  - (a) ⭐ defer to the split/service pass (D3) — no code change now
  - (b) extract a `private function persistBooking(...)` helper per method now, keeping the shared service question open
  - (c) leave as is, record as accepted
  - ➜ Choice: (a) — defer the split (D3) 2026-10-22

- [x] **PPTC-20** · L · DECISION · F13-8 — the teacher's subject in `show.blade.php` never renders (`User` has no `subjects` relation).
  - **Why it is a decision:** it is a behaviour/UI choice — remove the dead feature or repair it with the correct model — and repairing needs a product answer on which relation is authoritative.
  - (a) ⭐ remove the dead `$subject` read and its `@if($subject)` block now (lines 101 and 117-119)
  - (b) repair it: resolve the subject from the teacher's `Teacher`/`SubjectGroup` record and keep the display
  - (c) leave as is, record as accepted
  - ➜ Choice: (a) — remove the dead subject read and block 2026-10-22

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PPTC-12 | L · CTL-08 — the five `request()->route()` calls are replaced by PPTC-11's `activityContext($request, $child)` helper, which uses `$request->route()`. No separate item. |
| PPTC-16 | L · SVC-05 — memoising `PptDropdownResolver` is a cross-cutting change to a service used by six other classes and needs a caching/tenant decision; recorded here, not fixed in this pass. |
| PPTC-18 | L · QRY-02/QRY-03 — the PTM lists are naturally bounded (one class-section's upcoming events; one event's slots); adding `select()`/pagination is optional and left to the performance pass. |
