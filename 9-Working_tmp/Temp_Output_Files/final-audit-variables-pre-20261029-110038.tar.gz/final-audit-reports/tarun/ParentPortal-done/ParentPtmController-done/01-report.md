# Final Audit — ParentPortal / ParentPtmController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php` (495 lines, 5 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /parent-portal/ptm` (list upcoming PTM events), `GET /parent-portal/ptm/{ptmEvent}` (teachers + slots), `POST /parent-portal/ptm/slot/{slot}/book`, `POST /parent-portal/ptm/booking/{booking}/cancel`, `POST /parent-portal/ptm/booking/{booking}/reschedule` |
| Menu path | Parent Portal → PTM Scheduling |
| Who uses it | Parents only. `ParentPortalMiddleware` requires a logged-in user with `user_type = 'PARENT'`, a `std_guardians` row, and at least one child with `can_access_parent_portal = 1`. There is no `Gate`/permission string; the middleware is the role gate, matching the module's Pattern B. |
| What a user does here | A parent opens the PTM list, picks an upcoming Parent-Teacher Meeting for their child's class-section, sees the teachers with free time slots, books one slot, and can later cancel or move it to another slot. Booking writes a booking row, bumps the slot's `booked_count`, writes an audit row, and (when the event flag is on) writes a notification row. |
| Tables written | `ptm_slot_bookings`, `ptm_slots` (`booked_count`, `status`), `sys_activity_logs` (via `activityLog()`), `ntf_notifications` (best effort, behind a flag) |
| Tables read | `ptm_events`, `ptm_event_class_section_jnt`, `ptm_assignments`, `ptm_slots`, `ptm_slot_bookings`, `ptm_blockouts`, `std_students`, `std_guardians`, `std_student_guardian_jnt`, `sys_users`, `sch_class_sections` |
| Live data | ⚠ UNVERIFIED — no tenant DB is attached in this workspace (`prime_db` has no `ptm_*` tables). Columns and unique keys were verified against `database/migrations/tenant/2026_06_16_0943*.php`. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. The transaction shape is mostly right (each mutation runs inside one `DB::transaction` with `activityLog` inside), and the authorization is consistent with the module. But there are two blockers-class defects: the web `book()` and `reschedule()` send the raw exception message to the parent (`$e->getMessage()`), so a database error or duplicate-key violation is displayed verbatim, and `reschedule()` calls a method typed `PtmSlot $slot` before checking that the slot was actually found, so a soft-deleted target slot becomes a `TypeError` that the same leak then shows. On top of that, three check-then-act writes (`cancel`, `reschedule`, and the booking overlap rule) have no lock or unique-index backstop and can corrupt `ptm_slots.booked_count` or create double bookings under a double-tap. The single worst finding is **PPTC-01** (raw exception text to the user). Fixing the plan is roughly **M — about half a day**, plus Tarun's decisions on method extraction and the shared booking service.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 5 | 6 | 10 | 2 | 22 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PPTC-01, PPTC-02, PPTC-03 | F8 Services/Jobs | PPTC-16 (clean, linked) |
| F2 Transactions/Audit | PPTC-04, PPTC-05, PPTC-06 | F9 Queries/Perf | PPTC-17, PPTC-18 |
| F3 Authorization | PPTC-07 | F10 Views | PPTC-19, PPTC-20 |
| F4 Validation | PPTC-08 | F11 Security/Tenancy | PPTC-21 |
| F5 Routes | clean | F12 Style | PPTC-22, PPTC-23 |
| F6 Controller shape | PPTC-10, PPTC-11, PPTC-12, PPTC-13 | F13 Deep read | see §6 table |
| F7 Models | PPTC-14, PPTC-15 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php` | controller | 495 | this report | ✅ |
| 2 | `Modules/ParentPortal/routes/web.php` (the `ptm` group, lines 118-125) | route file | 199 | this report (group audited; whole file shared by 20 controllers) | ✅ |
| 3 | `Modules/ParentPortal/app/Providers/RouteServiceProvider.php` | provider | 100 | common (module infrastructure) | referenced |
| 4 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware | 65 | ↗ [tarun/ParentPortal-done/ParentHealthController](../ParentHealthController-done/01-report.md) (claimed) | ↗ linked — F3 evidence |
| 5 | `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` | FormRequest base | 26 | ↗ [tarun/ParentPortal-done/ParentComplaintController](../ParentComplaintController-done/01-report.md) (claimed) | ↗ linked — usage only |
| 6 | `Modules/ParentPortal/app/Http/Requests/BookParentPtmRequest.php` | FormRequest | 41 | this report | ✅ |
| 7 | `Modules/ParentPortal/app/Http/Requests/CancelParentPtmRequest.php` | FormRequest | 18 | this report | ✅ |
| 8 | `Modules/ParentPortal/app/Http/Requests/RescheduleParentPtmRequest.php` | FormRequest | 18 | this report | ✅ |
| 9 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) (pre-assigned) | ↗ linked — usage only |
| 10 | `Modules/ParentPortal/app/Services/PptDropdownResolver.php` | service | 41 | this report (pre-assigned; NOT reached by this controller — see §8) | ✅ |
| 11 | `Modules/Ptm/app/Models/PtmEvent.php` | model | 119 | this report | ✅ |
| 12 | `Modules/Ptm/app/Models/PtmSlot.php` | model | 129 | this report | ✅ |
| 13 | `Modules/Ptm/app/Models/PtmSlotBooking.php` | model | 98 | this report | ✅ |
| 14 | `Modules/Ptm/app/Models/PtmBlockout.php` | model | 57 | this report | ✅ |
| 15 | `Modules/Ptm/app/Models/PtmAssignment.php` | model (relation path) | 94 | this report (claimed 2026-10-13) | ✅ usage |
| 16 | `Modules/Ptm/app/Models/PtmEventClassSection.php` | model (relation path) | 77 | this report (claimed 2026-10-13) | ✅ usage |
| 17 | `Modules/ParentPortal/resources/views/ptm/index.blade.php` | blade | 118 | this report | ✅ |
| 18 | `Modules/ParentPortal/resources/views/ptm/show.blade.php` | blade | 286 | this report | ✅ |
| 19 | `database/migrations/tenant/2026_06_16_0943{08,10,12,14,15}_*.php` | migrations | — | common (tenant migrations — never edited) | referenced as column/constraint evidence |

No pre-applied files: `final-audit-reports/tarun/ParentPortal/` has no `PRE-APPLIED-2026-10-10.md`.

**Cross-report link:** `Api/ParentPtmApiController` (audited in batch 7, `../ParentPtmApiController-done/01-report.md`) links to THIS report for the four shared `Ptm*` models and `PptDropdownResolver`. Its `PPTM-04`/`PPTM-05` races are the API-side twins of this report's `PPTC-04`/`PPTC-05`; the root cause is controller-level (checks outside the transaction), not in the models. `PPTM-01` (raw `getMessage()`) is the API twin of `PPTC-01` here. Its `PtmBlockout` TIME-cast cross-note is owned and fixed by THIS report as `PPTC-14`.

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '...ParentPtmController@...'
GET|HEAD  parent-portal/ptm                              parent-portal.ptm.index       Modules\ParentPortal\Http\Controllers\ParentPtmController@index
GET|HEAD  parent-portal/ptm/{ptmEvent}                   parent-portal.ptm.show        Modules\ParentPortal\Http\Controllers\ParentPtmController@show
POST      parent-portal/ptm/slot/{slot}/book             parent-portal.ptm.book        Modules\ParentPortal\Http\Controllers\ParentPtmController@book
POST      parent-portal/ptm/booking/{booking}/cancel     parent-portal.ptm.cancel      Modules\ParentPortal\Http\Controllers\ParentPtmController@cancel
POST      parent-portal/ptm/booking/{booking}/reschedule parent-portal.ptm.reschedule  Modules\ParentPortal\Http\Controllers\ParentPtmController@reschedule
```

Middleware stack (`RouteServiceProvider::mapWebRoutes`, lines 66-80): `web` + `InitializeTenancyByDomain` + `PreventAccessFromCentralDomains` + `EnsureTenantIsActive` + `EnsureTenantHasModule:ParentPortal` + `auth` + `ParentPortalMiddleware`.

Unrouted public methods: none (all five public methods are routed; the three private helpers are not).

Route parameter names match the controller arguments (`{ptmEvent}` → `PtmEvent $ptmEvent`, `{slot}` → `PtmSlot $slot`, `{booking}` → `PtmBooking $booking`), so route model binding resolves all three; there is no unbound-model INSERT risk.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 31 | GET parent-portal/ptm | route middleware (`auth` + `ParentPortalMiddleware`) | none (read) | `'Viewed'` (59) | sys_activity_logs | PPTC-02, PPTC-11, PPTC-12, PPTC-17, PPTC-18 |
| `show` | 78 | GET parent-portal/ptm/{ptmEvent} | route middleware + `isEventEligible()` 403 | none (read) | `'Viewed'` (126) | sys_activity_logs | PPTC-02, PPTC-11, PPTC-12, PPTC-19, PPTC-20 |
| `book` | 148 | POST parent-portal/ptm/slot/{slot}/book | route middleware + FormRequest + `assertSlotBelongsToChildClassSection()` | controller (153) | `'Booked'` (262, inside tx after write) | ptm_slot_bookings, ptm_slots, sys_activity_logs, ntf_notifications | PPTC-01, PPTC-03, PPTC-06, PPTC-07, PPTC-10, PPTC-11, PPTC-12, PPTC-21 |
| `cancel` | 289 | POST parent-portal/ptm/booking/{booking}/cancel | ownership 403 (`booked_by_user_id` + `student_id`) + `isCancellable()` 422 | controller (299) | `'Cancelled'` (316, inside tx after write) | ptm_slot_bookings, ptm_slots, sys_activity_logs, ntf_notifications | PPTC-03, PPTC-04, PPTC-11, PPTC-12, PPTC-21 |
| `reschedule` | 356 | POST parent-portal/ptm/booking/{booking}/reschedule | ownership 403 + `allow_reschedule` + `assertSlotBelongsToChildClassSection()` | controller (372) | `'Rescheduled'` (422, inside tx after write) | ptm_slot_bookings, ptm_slots, sys_activity_logs | PPTC-01, PPTC-05, PPTC-08, PPTC-10, PPTC-11, PPTC-12 |

Tables each mutation SHOULD touch, compared with what it DOES (`controller-alignment.md` §0.1): `book` writes `ptm_slot_bookings` + `ptm_slots` + `sys_activity_logs` and `ntf_notifications` when the flag is on; `cancel` and `reschedule` write `ptm_slot_bookings` + `ptm_slots` + `sys_activity_logs` (`cancel` also `ntf_notifications`). All matches — no missing write.

## 6. Findings

### F1 — Errors

#### PPTC-01 · B · ERR-01 — `book()` and `reschedule()` send the raw exception text to the parent

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak*; also D1 (no try/catch in a controller — the only allowed catch is `\DomainException`) |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:277-279` (`book`) and `:438-440` (`reschedule`) |
| **Root cause** | Both mutations wrap the `DB::transaction` in `try { ... } catch (\Throwable $e) { return back()->with('error', $e->getMessage()); }`. `\Throwable` also catches `QueryException`, so a duplicate-key error or any other SQL failure is flashed to the parent's browser verbatim. The business-rule texts are thrown as `\Exception` (not `\DomainException`), so the only way to surface them is the forbidden catch. |
| **Consequence** | A parent who double-submits a booking sees raw SQL (`SQLSTATE[23000] ... Duplicate entry ... for key 'uq_ptmBooking_event_teacher_studentActive'`) instead of a friendly message — a data leak and a page-killer. |
| **Reproduce** | Open a PTM event, book a slot, then submit the same booking form again fast enough to beat the "already booked" check — the error banner shows the SQL text. |
| **Fix approach** | Per D1/D2: remove the `catch (\Throwable)`; throw `\DomainException` for the business rules and catch only `\DomainException` to flash its (user-safe) message; let any other exception reach the central renderer in `bootstrap/app.php`. |
| **Plan item** | PPTC-01 in `02-fix-plan.md` §1 |

```php
// ParentPtmController.php:277-279 — CURRENT (book)
        } catch (\Throwable $e) {
            return back()->with('error', $e->getMessage());
        }
```
```php
// ParentPtmController.php:438-440 — CURRENT (reschedule)
        } catch (\Throwable $e) {
            return back()->with('error', $e->getMessage());
        }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
B  ERR-01   ParentPtmController.php:278  book — raw exception message (Throwable) returned to the user
B  ERR-01   ParentPtmController.php:439  reschedule — raw exception message (Throwable) returned to the user
```

#### PPTC-02 · M · ERR-07 — `index()` and `show()` wrap the audit write in a controller try/catch that logs `getMessage()`

| Field | Value |
|---|---|
| **Rule** | ERR-07 (M) — *read-only methods need no try/catch*; also D1 (a controller try/catch is a finding) and ERR-05 (M) — *log the exception, not the message*. Severity M: the catch swallows nothing and shows the user nothing, so no user-visible harm. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:58-70` (`index`) and `:125-138` (`show`) |
| **Root cause** | Both read methods wrap the `activityLog(...)` call in `try { ... } catch (\Throwable $e) { Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]); }`. The inline comment cites the superseded "Rule A1"; under D1 a controller must not catch, and a read path (ERR-07) needs no catch at all. The `getMessage()`-only log (ERR-05) also loses the stack trace. |
| **Consequence** | When the audit write fails, ops get a one-line string with no trace, class or line — hard to debug; and the pattern keeps the forbidden controller try/catch alive for the next editor to copy. |
| **Reproduce** | Static only — the catch runs only when the `sys_activity_logs` insert fails. |
| **Fix approach** | Remove the try/catch and call `activityLog(...)` directly; the central handler is the single error renderer (D1). If a failure must not page the parent, that is a service concern, not a controller catch. |
| **Plan item** | PPTC-02 in `02-fix-plan.md` §3 |

```php
// ParentPtmController.php:58-70 — CURRENT (index)
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed PTM events',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
M  ERR-07   ParentPtmController.php:58   index — read method index() wrapped in try/catch
M  ERR-05   ParentPtmController.php:69   index — logs getMessage() without the exception/trace
M  ERR-07   ParentPtmController.php:125  show — read method show() wrapped in try/catch
M  ERR-05   ParentPtmController.php:137  show — logs getMessage() without the exception/trace
```

#### PPTC-03 · M · ERR-05 — notification catches log the message only, losing the trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:257-259` (`book`) and `:345-347` (`cancel`) |
| **Root cause** | The best-effort `Notification::create` is wrapped in `catch (\Exception $e) { \Log::error('...: ' . $e->getMessage()); }`. Only the message string is logged; the exception class, file, line and trace are lost. The catch is expected here (a notification failure must not fail the booking), so the shape stays — only the logging is fixed. |
| **Consequence** | When a notification write fails, the ops log shows a bare string with no trace, so the failure cannot be located. The API twin is `PPTM-02`. |
| **Reproduce** | Static only — break the `ntf_notifications` insert and inspect `storage/logs/laravel.log`. |
| **Fix approach** | Replace the string concatenation with `report($e)` (keeps the trace) and drop the fully-qualified `\Log`. |
| **Plan item** | PPTC-03 in `02-fix-plan.md` §3 |

```php
// ParentPtmController.php:257-259 — CURRENT (book notification catch)
                    } catch (\Exception $e) {
                        \Log::error('Error creating PTM booking notification: ' . $e->getMessage());
                    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
M  ERR-05   ParentPtmController.php:258  book — logs getMessage() without the exception/trace
L  STY-06   ParentPtmController.php:258  - — \Log:: instead of imported Log
M  ERR-05   ParentPtmController.php:346  cancel — logs getMessage() without the exception/trace
L  STY-06   ParentPtmController.php:346  - — \Log:: instead of imported Log
```

### F2 — Transactions and audit

#### PPTC-04 · H · TXN-06 — `cancel()` re-checks status outside the transaction, so a double-cancel double-decrements the slot

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:295` (`isCancellable()` before the tx) and the `DB::transaction` at `:299-328` |
| **Root cause** | `abort_unless($booking->isCancellable(), 422, ...)` runs before the transaction, and inside the transaction the booking row is never locked nor re-read. Two concurrent cancels both pass the pre-check while the booking is still `CONFIRMED`; both then set `CANCELLED` and both decrement the slot. The `booked_count > 0` guard only stops a negative value, not a double count. |
| **Consequence** | A double-tap on Cancel leaves `ptm_slots.booked_count` one too low and can mark the slot `AVAILABLE` while a confirmed booking still exists. The API twin is `PPTM-04`. |
| **Reproduce** | Send two identical `POST /parent-portal/ptm/booking/{booking}/cancel` at the same time for a confirmed booking on a slot with `booked_count >= 2`. |
| **Fix approach** | Inside the transaction, re-read the booking with `lockForUpdate()` and bail unless `status === 'CONFIRMED'`; only then set `CANCELLED` and decrement. |
| **Plan item** | PPTC-04 in `02-fix-plan.md` §2 |

```php
// ParentPtmController.php:299-328 — CURRENT (cancel transaction)
        DB::transaction(function () use ($booking, $child) {
            $booking->update([
                'status'       => 'CANCELLED',
                'cancelled_at' => now(),
            ]);

            $slot = PtmSlot::where('id', $booking->slot_id)->lockForUpdate()->first();
            if ($slot && $slot->booked_count > 0) {
                $slot->decrement('booked_count');

                if ($slot->booked_count == 0) {
                    $slot->update(['status' => 'AVAILABLE']);
                } else {
                    $slot->update(['status' => 'BOOKED']);
                }
            }

            activityLog(auth()->user(), 'Cancelled', [
                'message' => 'Cancelled PTM booking',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
                'booking_id' => $booking->id,
                'slot_id' => $booking->slot_id,
                'ptm_event_id' => $booking->ptm_event_id,
            ]);
        });
```

**Evidence**
```
$ grep -n "isCancellable\|lockForUpdate\|DB::transaction" Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
295:        abort_unless($booking->isCancellable(), 422, 'This booking can no longer be cancelled.');
299:        DB::transaction(function () use ($booking, $child) {
305:            $slot = PtmSlot::where('id', $booking->slot_id)->lockForUpdate()->first();
# the booking row itself is never locked and its status is never re-read inside the tx
```

#### PPTC-05 · H · TXN-06 — `reschedule()` never re-checks the booking is still CONFIRMED inside the transaction

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:372-437` (`reschedule` transaction) |
| **Root cause** | The method checks ownership before the transaction but never verifies the booking is still `CONFIRMED` inside it, and never locks the booking row. Two concurrent reschedules of the same booking both cancel the old row (decrementing the old slot twice) and both insert a new CONFIRMED booking (incrementing the new slot twice). The unique key `uq_ptmBooking_event_teacher_studentActive` only backstops a move inside the same event, not a move to a different event. |
| **Consequence** | A double-submit of Reschedule creates two new bookings and corrupts both slots' `booked_count`. The API twin is `PPTM-05`. |
| **Reproduce** | Send two identical `POST /parent-portal/ptm/booking/{booking}/reschedule` with the same target slot concurrently. |
| **Fix approach** | Inside the transaction, re-read the booking with `lockForUpdate()` and throw `\DomainException` unless its status is `CONFIRMED`; only then cancel the old row and create the new one. |
| **Plan item** | PPTC-05 in `02-fix-plan.md` §2 |

```php
// ParentPtmController.php:373-386 — CURRENT (start of the reschedule transaction)
            $newBookingId = DB::transaction(function () use ($booking, $newSlotId, $child) {
                // Cancel old booking
                $booking->update([
                    'status'        => 'CANCELLED',
                    'cancelled_at'  => now(),
                    'cancel_reason' => 'Rescheduled to another slot',
                ]);

                $oldSlot = PtmSlot::where('id', $booking->slot_id)->lockForUpdate()->first();
                if ($oldSlot && $oldSlot->booked_count > 0) {
                    $oldSlot->decrement('booked_count');
                    $oldSlot->status = $oldSlot->booked_count === 0 ? 'AVAILABLE' : 'BOOKED';
                    $oldSlot->save();
                }
```

**Evidence**
```
$ sed -n '372,437p' Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
# no ->lockForUpdate() on the booking row and no status re-check anywhere in the tx
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
(no race rule emitted by the static scanner — this is a deep-read finding, TXN-06)
```

#### PPTC-06 · H · TXN-06 — `book()`'s time-overlap guard has no lock or unique-index backstop

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:206-219` (overlap guard) inside `book()`'s transaction at `:153-279` |
| **Root cause** | Three `exists()` guards run before the insert. The slot row is locked (`lockForUpdate()`, line 156), which serialises requests for the SAME slot, and the DB unique keys `uq_ptmBooking_slot_studentActive` and `uq_ptmBooking_event_teacher_studentActive` backstop the same-slot and same-event cases. But the time-overlap rule (lines 209-215) spans slots in different events — different rows — so two parallel requests from the same child both pass it and both insert. |
| **Consequence** | A child can hold two CONFIRMED bookings at the same time in two different PTM events; the teacher is double-booked and the parent sees conflicting meeting times. The API twin is `PPTM-03`. |
| **Reproduce** | Fire `book()` on two overlapping slots in different events for the same child concurrently (two tabs or a script). |
| **Fix approach** | Run the overlap query with `->lockForUpdate()` so concurrent transactions serialise on the child's intersecting rows, and treat a unique-key violation as a `\DomainException` rather than letting `QueryException` surface (PPTC-01). |
| **Plan item** | PPTC-06 in `02-fix-plan.md` §2 |

```php
// ParentPtmController.php:206-219 — CURRENT (overlap guard inside book's transaction)
                // Prevent student time overlap with any other confirmed booking
                $slotStart = $locked->slot_start;
                $slotEnd = $locked->slot_end;
                $timeOverlap = PtmBooking::where('student_id', $child->id)
                    ->where('status', 'CONFIRMED')
                    ->whereHas('slot', function ($q) use ($slotStart, $slotEnd) {
                        $q->where('slot_start', '<', $slotEnd)
                          ->where('slot_end', '>', $slotStart);
                    })
                    ->exists();

                if ($timeOverlap) {
                    throw new \Exception('You already have another booking at this time.');
                }
```

**Evidence**
```
$ grep -n "unique(" database/migrations/tenant/2026_06_16_094315_create_ptm_slot_bookings_table.php
54:            $table->unique(['ptm_event_id', 'active_booking_key'], 'uq_ptmBooking_event_teacher_studentActive');
55:            $table->unique(['slot_id', 'active_booking_key'], 'uq_ptmBooking_slot_studentActive');
# both unique keys are per-slot / per-event; neither constrains a cross-event time overlap
```

### F3 — Authorization

#### PPTC-07 · L · AUTH-04 — the slot/class-section check runs twice (FormRequest then controller)

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission/check twice* |
| **Where** | `Modules/ParentPortal/app/Http/Requests/BookParentPtmRequest.php:7-33` (`authorize`) and `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:150-151` (`book`) |
| **Root cause** | `BookParentPtmRequest::authorize()` resolves the child and asserts the slot's class-section matches; `book()` then repeats the identical check via `assertSlotBelongsToChildClassSection($slot, $child)`. The two implementations disagree slightly (the FormRequest uses `currentSession()->first()`, the helper uses the `currentSession` relation), so they can drift. |
| **Consequence** | No user-visible failure today, but two copies of one rule mean a future change to one silently weakens or breaks the other. |
| **Reproduce** | Static only — read both authorize paths. |
| **Fix approach** | Keep one: the controller helper is the one that also guards `reschedule`, so the FormRequest can keep only the base child gate. |
| **Plan item** | PPTC-07 in `02-fix-plan.md` §4 |

```php
// BookParentPtmRequest.php:7-33 — CURRENT (authorize duplicates the slot check)
    public function authorize(): bool
    {
        if (!parent::authorize()) {
            return false;
        }

        try {
            $child = app(\Modules\ParentPortal\Services\ParentContextService::class)->resolveChild($this);
            $session = $child->currentSession()->first();
            $classSectionId = $session?->class_section_id;

            $slot = $this->route('slot');
            if (!$slot instanceof \Modules\Ptm\Models\PtmSlot) {
                $slot = \Modules\Ptm\Models\PtmSlot::find($slot);
            }

            if (!$slot || !$classSectionId) {
                return false;
            }

            $slotClassSectionId = $slot->assignment?->eventClassSection?->class_section_id;

            return $slotClassSectionId === $classSectionId;
        } catch (\Exception $e) {
            return false;
        }
    }
```

**Evidence**
```
$ grep -n "assertSlotBelongsToChildClassSection\|class SectionId" Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
151:        $this->assertSlotBelongsToChildClassSection($slot, $child);
362:        $this->assertSlotBelongsToChildClassSection($booking->slot, $child);
390:                $this->assertSlotBelongsToChildClassSection($newSlot, $child);
# the same class-section rule is enforced by the FormRequest AND by book()'s helper
```

### F4 — Validation and input

#### PPTC-08 · H · VAL-04 — `RescheduleParentPtmRequest`'s `exists` rule ignores soft-deleted slots; `reschedule()` then dereferences null

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness/exists rules must mirror the DB including soft-delete semantics*; plus ERR-03-adjacent TypeError. Raised to H: it combines a validation hole with a crash on a normal user path. |
| **Where** | `Modules/ParentPortal/app/Http/Requests/RescheduleParentPtmRequest.php:15` and `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:389-392` |
| **Root cause** | The rule `new_slot_id => required|integer|exists:ptm_slots,id` queries the raw table, which still contains soft-deleted slots (`ptm_slots` has `deleted_at`). A trashed slot passes validation. In the transaction, `PtmSlot::where('id', $newSlotId)->lockForUpdate()->first()` returns `null` because of the model's `SoftDeletes` global scope, and the very next line calls `assertSlotBelongsToChildClassSection($newSlot, $child)` whose parameter is typed `PtmSlot` — null under `strict_types` throws a `TypeError`, which `catch (\Throwable)` (PPTC-01) then flashes to the parent. |
| **Consequence** | A parent who reschedules to a slot the school deleted sees a raw type-error string instead of a friendly "that slot is no longer available". |
| **Reproduce** | Soft-delete a `ptm_slots` row, then POST its id as `new_slot_id` to the reschedule route. |
| **Fix approach** | Exclude trashed rows in the rule (`Rule::exists('ptm_slots', 'id')->whereNull('deleted_at')`) AND move the null guard above the typed helper call so `assertSlotBelongsToChildClassSection` runs only when the slot exists. |
| **Plan item** | PPTC-08 in `02-fix-plan.md` §2 |

```php
// RescheduleParentPtmRequest.php:12-17 — CURRENT
    public function rules(): array
    {
        return [
            'new_slot_id' => 'required|integer|exists:ptm_slots,id',
        ];
    }
```

**Evidence**
```
$ sed -n '388,393p' Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
                // Lock and validate new slot
                $newSlot = PtmSlot::where('id', $newSlotId)->lockForUpdate()->first();
                $this->assertSlotBelongsToChildClassSection($newSlot, $child);

                if (!$newSlot || !$newSlot->is_active) {
                    throw new \Exception('The target slot is no longer available.');
$ grep -n "softDeletes" database/migrations/tenant/2026_06_16_094314_create_ptm_slots_table.php
45:            $table->softDeletes();
```

### F5 — Routes

clean — the five routes in `Modules/ParentPortal/routes/web.php:118-125` all point at existing methods (verified in §4); state changes are POST only (RTE-01); every public method is routed (RTE-03); the whole group is inside the tenancy + `auth` + `ParentPortalMiddleware` stack (RTE-05, proven in `RouteServiceProvider.php:66-80`); the route params match the typed arguments, so no unbound model (RTE, §3.3.1). No `Route::resource` in this group, so no custom-before-resource ordering issue (RTE-06).
Evidence: `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | grep ParentPtmController@` → the five lines shown in §4.

### F6 — Controller shape

#### PPTC-10 · M · CTL-02 — `book()` is 137 lines and `reschedule()` is 90 lines (over the 80-line limit)

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *a method over 80 lines should be extracted; over 150 is H* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:148-284` (`book`, 137 lines) and `:356-445` (`reschedule`, 90 lines) |
| **Root cause** | Each method inlines the lock, the business guards, the insert, the counter/status updates, the audit write and (in `book`) the notification block. |
| **Consequence** | Hard to follow, and it hides divergence — `reschedule` is missing guards that `book` has (PPTC-08), which is easy to miss in a long method. |
| **Reproduce** | Static only — count the lines. |
| **Fix approach** | Extract the write-and-log step of each method into a private helper (or fold into the shared booking service of the DECISION item). Per D3 this is deferred. |
| **Plan item** | PPTC-10 (DECISION) in `02-fix-plan.md` §9 |

```php
// ParentPtmController.php:148-150 — CURRENT (book entry point)
    public function book(BookParentPtmRequest $request, PtmSlot $slot): RedirectResponse
    {
        $child = $this->context->resolveChild($request);
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
M  CTL-02   ParentPtmController.php:148  book — book() is 137 lines
M  CTL-02   ParentPtmController.php:356  reschedule — reschedule() is 90 lines
```

#### PPTC-11 · M · CTL-05 — the same 4-item audit-context array is copy-pasted five times

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste; extract the repeated block* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:61-66`, `:128-133`, `:264-269`, `:318-323`, `:424-429` |
| **Root cause** | The `'context' => [ 'student_id' => ..., 'student_name' => ..., 'module' => 'ParentPortal', 'route' => ... ]` block is written out in full in all five `activityLog()` calls. |
| **Consequence** | A change to the audit context (e.g. a new field) must be made in five places; missing one produces inconsistent audit rows. |
| **Reproduce** | Static only. |
| **Fix approach** | Add one private helper `activityContext($child): array` and call it from all five sites. |
| **Plan item** | PPTC-11 in `02-fix-plan.md` §8 |

```php
// ParentPtmController.php:62-66 — CURRENT (repeated five times)
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
M  CTL-05   ParentPtmController.php:61  - — identical 4-item array literal repeated 5× (lines 61,128,264,318,424)
```

#### PPTC-12 · L · CTL-08 — `request()` helper used instead of the injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:65`, `:132`, `:268`, `:322`, `:428` |
| **Root cause** | Every method already receives `$request` (or a FormRequest that extends it), yet the audit context calls the global `request()` helper. |
| **Consequence** | No functional impact; style/side-effect debt. |
| **Reproduce** | Static only. |
| **Fix approach** | Use `$request->route()?->getName()` (fold into the PPTC-11 helper, which can take `$request`). |
| **Plan item** | PPTC-12 in `02-fix-plan.md` §8 |

```php
// ParentPtmController.php:63-66 — CURRENT
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
L  CTL-08   ParentPtmController.php:65   index — request() helper in controller
L  CTL-08   ParentPtmController.php:132  show — request() helper in controller
L  CTL-08   ParentPtmController.php:268  book — request() helper in controller
L  CTL-08   ParentPtmController.php:322  cancel — request() helper in controller
L  CTL-08   ParentPtmController.php:428  reschedule — request() helper in controller
```

#### PPTC-13 · L · STY-04 — a stray docblock describes a different method

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *no copy-pasted docblocks that describe another resource* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:447-449` |
| **Root cause** | The docblock "Ensure the PTM slot is assigned to the child's class-section." sits immediately above the docblock for `isEventEligible()`; it was left behind when `assertSlotBelongsToChildClassSection` was moved lower (line 467). |
| **Consequence** | A reader attributes the slot-check description to `isEventEligible`, which does something else. |
| **Reproduce** | Static only. |
| **Fix approach** | Delete the orphan docblock (lines 447-449), or move it onto `assertSlotBelongsToChildClassSection`. |
| **Plan item** | PPTC-13 in `02-fix-plan.md` §8 |

```php
// ParentPtmController.php:447-450 — CURRENT
    /**
     * Ensure the PTM slot is assigned to the child's class-section.
     */
    /**
```

**Evidence**
```
$ sed -n '447,452p' Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
    /**
     * Ensure the PTM slot is assigned to the child's class-section.
     */
    /**
     * Is this PTM event visible to a child in the given class-section?
```

### F7 — Models

#### PPTC-14 · M · MDL-02 — `PtmBlockout` casts `start_time`/`end_time` as `datetime`, but the columns are `time`

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` must cover the real column type* |
| **Where** | `Modules/Ptm/app/Models/PtmBlockout.php:30-31` |
| **Root cause** | `ptm_blockouts.start_time` and `end_time` are `time` columns (migration line 17-18), but the model casts them to `datetime`. Reads return a full Carbon (date today + time) and any write through the model sends a full date-time string that MySQL truncates to the time part. |
| **Consequence** | A blockout saved through the model can lose its intended time semantics, and comparisons elsewhere must rely on `->format('H:i:s')` rather than Carbon. Flagged by the API report as a cross-note to this owner. |
| **Reproduce** | Static only — compare the cast with the migration column. |
| **Fix approach** | Cast both to `string` (the TIME value as stored). The controller's `isSlotBlockedByBlockout()` compares them with `->format('H:i:s')` in SQL, which keeps working. |
| **Plan item** | PPTC-14 in `02-fix-plan.md` §5 |

```php
// PtmBlockout.php:30-31 — CURRENT
        'start_time' => 'datetime',
        'end_time' => 'datetime',
```

**Evidence**
```
$ grep -n "start_time\|end_time" database/migrations/tenant/2026_06_16_094310_create_ptm_blockouts_table.php
17:            $table->time('start_time');
18:            $table->time('end_time');
$ grep -n "start_time\|end_time" Modules/Ptm/app/Models/PtmBlockout.php
30:        'start_time' => 'datetime',
31:        'end_time' => 'datetime',
```

#### PPTC-15 · L · MDL-04 — Ptm models miss relation return types and `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed*; STY-01 (L) — *`declare(strict_types=1)`*; STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/Ptm/app/Models/PtmEvent.php:1` and `:85-118`; `Modules/Ptm/app/Models/PtmSlot.php:1` and `:118-128`; `Modules/Ptm/app/Models/PtmSlotBooking.php:1`; `Modules/Ptm/app/Models/PtmBlockout.php:1` |
| **Root cause** | All four models lack `declare(strict_types=1)`; `PtmSlot::event()` and the accessors on `PtmEvent` have no return type; import order is not Pint-sorted. |
| **Consequence** | Style/consistency only; no functional impact. |
| **Reproduce** | `vendor/bin/pint --test` on the four files. |
| **Fix approach** | One style pass over the four model files (strict_types, relation/accessor return types, Pint). |
| **Plan item** | PPTC-15 in `02-fix-plan.md` §8 |

```php
// PtmEvent.php:1-5 — CURRENT (first lines; all four models start this way)
<?php

namespace Modules\Ptm\Models;

use Modules\SchoolSetup\Models\User;
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/Ptm/app/Models/PtmEvent.php Modules/Ptm/app/Models/PtmSlot.php \
    Modules/Ptm/app/Models/PtmSlotBooking.php Modules/Ptm/app/Models/PtmBlockout.php
L  STY-01   PtmBlockout.php:1   - — missing declare(strict_types=1)
L  STY-01   PtmEvent.php:1      - — missing declare(strict_types=1)
L  STY-01   PtmSlot.php:1       - — missing declare(strict_types=1)
L  MDL-04   PtmSlot.php:118     event — relation event() has no return type
L  STY-01   PtmSlotBooking.php:1 - — missing declare(strict_types=1)
$ vendor/bin/pint --test Modules/Ptm/app/Models/PtmEvent.php ... 2>&1 | tail -1
... ordered_imports ... (PtmEvent, PtmSlot, PtmSlotBooking, PtmBlockout)
```

### F8 — Services and jobs

#### PPTC-16 · L · SVC-05 — `PptDropdownResolver` re-queries the dropdown table on every call, with no memo

| Field | Value |
|---|---|
| **Rule** | SVC-05 (L) — *repeated lookups inside a request are memoised or cached once*; QRY-12 (M) lowered to L because these are small lookup tables and the resolver is called once per attribute read. |
| **Where** | `Modules/ParentPortal/app/Services/PptDropdownResolver.php:16-40` |
| **Root cause** | `id()` runs a `WHERE key+value+is_active` query and `value()` runs `Dropdown::find($id)` on every call. Models such as `ParentSession`, `ConsentForm`, `ParentDocumentRequest` call these in accessors, so one model hydrated N times issues N lookups. NOTE: this controller does NOT call the resolver (see §8); it is audited here only because the main session pre-assigned it to this report. |
| **Consequence** | Extra identical queries on list screens of other controllers (e.g. the account/session pages). No user-visible wrong result. |
| **Reproduce** | Static only — count the lookups per accessor call. |
| **Fix approach** | Memoise per key/value inside the request (be careful: a static memo persists in a long-running worker, so prefer an instance memo injected as a scoped singleton — that is a DECISION, so it is left in §10 for now). |
| **Plan item** | none — see plan §10 |

```php
// PptDropdownResolver.php:16-24 — CURRENT
    public static function id(string $key, string $value): ?int
    {
        $row = Dropdown::where('key', $key)
            ->where('value', $value)
            ->where('is_active', true)
            ->first();

        return $row?->id;
    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Services/PptDropdownResolver.php
(no static-scanner row — deep-read finding, SVC-05)
$ grep -rln "PptDropdownResolver" Modules/ParentPortal/app/Models | wc -l
6
```
`ParentContextService` (linked, owned by `../ParentDashboardController-done/01-report.md`) usage is clean: constructor-injected, `resolveChild($request)` called once per method, per-parent memo in the service.

### F9 — Queries and performance

#### PPTC-17 · H · QRY-01 — `index()` eager-loads `slot.assignment.ptmEvent` but the view reads `slot->event` (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops*; VIEW-02 (M) — *relations used in a loop are eager-loaded* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:47-52` and `Modules/ParentPortal/resources/views/ptm/index.blade.php:41`, `:44`, `:48`, `:52`, `:54` |
| **Root cause** | The controller loads `->with(['slot.assignment.ptmEvent', 'slot.teacher'])`, but the Blade reads `$b->slot->event` — where `event` is a separate `hasOneThrough` relation on `PtmSlot` (line 118). That relation is never eager-loaded, so one query runs per booking in the `@foreach`. |
| **Consequence** | On a page with many bookings the PTM list issues one extra query per booking (an N+1), slowing the page as bookings grow. |
| **Reproduce** | Open `/parent-portal/ptm` as a parent with several confirmed bookings and count the queries (or read `slot->event` in the view). |
| **Fix approach** | Either eager-load the relation the view actually uses (`slot.event`) instead of `slot.assignment.ptmEvent`, or change the view to read `$b->slot->assignment->ptmEvent` with the matching `with()`. |
| **Plan item** | PPTC-17 in `02-fix-plan.md` §6 |

```php
// ParentPtmController.php:47-52 — CURRENT (eager load does not match the view)
        $myBookings = PtmBooking::where('booked_by_user_id', auth()->id())
            ->where('student_id', $child->id)
            ->where('status', 'CONFIRMED')
            ->whereIn('ptm_event_id', $events->pluck('id'))
            ->with(['slot.assignment.ptmEvent', 'slot.teacher'])
            ->get();
```

**Evidence**
```
$ grep -n "slot->event\|with(\['slot" Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php \
    Modules/ParentPortal/resources/views/ptm/index.blade.php
Modules/ParentPortal/resources/views/ptm/index.blade.php:41:  <div class="fw-bold">{{ $b->slot->event->title ?? '' }}</div>
Modules/ParentPortal/resources/views/ptm/index.blade.php:48:  {{ $b->slot->event->ptm_date?->format('d M Y') }}
Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:51:  ->with(['slot.assignment.ptmEvent', 'slot.teacher'])
$ grep -n "function event" Modules/Ptm/app/Models/PtmSlot.php
118:    public function event()
```

#### PPTC-18 · L · QRY-02 — `index()` and `show()` return unbounded, all-column lists

| Field | Value |
|---|---|
| **Rule** | QRY-02 (default H, lowered to L) — *lists are paginated*; QRY-03 (M) — *select only the columns used*. Lowered because these datasets are naturally bounded (upcoming events for one class-section; slots for one event). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:38-44` (`index`) and `:92-102` (`show`) |
| **Root cause** | `PtmEvent::active()->upcoming()->...->get()` and `PtmSlot::...->get()` have no `paginate()` and select every column, while the views use only a handful. |
| **Consequence** | Growing payload/columns as a school creates more events; no wrong result. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `->select([...])` for the columns the view uses; pagination is optional for these bounded lists. |
| **Plan item** | none — see plan §10 |

```php
// ParentPtmController.php:38-44 — CURRENT
        $events = PtmEvent::active()
            ->upcoming()
            ->whereHas('eventClassSections', function ($q) use ($classSectionId) {
                $q->where('class_section_id', $classSectionId);
            })
            ->orderBy('event_start_date')
            ->get();
```

**Evidence**
```
$ grep -n "paginate\|select(" Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
(no output — no pagination and no explicit select on the lists)
```

### F10 — Views

#### PPTC-19 · L · VIEW-03 — SweetAlert injects the teacher name as HTML (potential stored XSS)

| Field | Value |
|---|---|
| **Rule** | VIEW-03 (default H, lowered to L) — *`{!! !!}`/raw HTML only for trusted content*. Lowered: the value is admin-entered (teacher name), not parent-supplied. |
| **Where** | `Modules/ParentPortal/resources/views/ptm/show.blade.php:264-269` (JS) and `:169-170` (data attributes) |
| **Root cause** | The booking form sets `data-teacher-name="{{ $teacher->name ?? '' }}"`; Blade escapes the attribute, but the DOM decodes it when JS reads `this.dataset.teacherName`, and the value is then interpolated into SweetAlert's `html:` option via a template literal. A teacher name containing markup would be rendered as HTML. |
| **Consequence** | If a teacher name contains a script/onerror payload, it executes in the parent's browser when they open the booking confirmation. Low likelihood (admin-only input), real impact. |
| **Reproduce** | Set a teacher's name to a markup payload, open an available slot, click Book. |
| **Fix approach** | Use SweetAlert's `text:` option (plain text) instead of `html:`, or escape the interpolated values. |
| **Plan item** | PPTC-19 in `02-fix-plan.md` §7 |

```php
// show.blade.php:264-269 — CURRENT (JS)
                const teacherName = this.dataset.teacherName;
                const slotTime = this.dataset.slotTime;

                Swal.fire({
                    title: 'Confirm Booking',
                    html: `Book slot <strong>${slotTime}</strong> with <strong>${teacherName}</strong>?`,
```

**Evidence**
```
$ sed -n '169,171p;267,269p' Modules/ParentPortal/resources/views/ptm/show.blade.php
                    <form method="POST" action="{{ route('parent-portal.ptm.book', $slot->id) }}" class="booking-form h-100"
                          data-teacher-name="{{ $teacher->name ?? '' }}"
                          data-slot-time="{{ $startFmt }}">
                    title: 'Confirm Booking',
                    html: `Book slot <strong>${slotTime}</strong> with <strong>${teacherName}</strong>?`,
```

#### PPTC-20 · L · F13-8 — the teacher's subject never renders (dead feature)

| Field | Value |
|---|---|
| **Rule** | F13 #8 (L) — *dead feature: a screen reads data no code supplies*. |
| **Where** | `Modules/ParentPortal/resources/views/ptm/show.blade.php:100-101` and `:117-119` |
| **Root cause** | The view does `$subject = $teacher?->subjects?->first()?->name ?? '';`, but `$teacher` is a `Modules\SchoolSetup\Models\User`, which has no `subjects` relation (the `subjects()` relation lives on `Teacher`, `SubjectGroup` and `Organization`). The undefined attribute resolves to null, so `$subject` is always empty and the `@if($subject)` block never renders. |
| **Consequence** | The subject line under each teacher is silently never shown — a dead feature that looks implemented. |
| **Reproduce** | Open a PTM event with slots; no teacher shows a subject. |
| **Fix approach** | Either remove the dead `$subject` read and its `@if` block, or resolve the subject through the correct model. This is a behaviour choice, so it is a DECISION. |
| **Plan item** | PPTC-20 (DECISION) in `02-fix-plan.md` §9 |

```php
// show.blade.php:99-106 — CURRENT
    @php
        $teacher = $slots->first()->teacher;
        $subject = $teacher?->subjects?->first()?->name ?? '';
        $teacherInitial = strtoupper(substr($teacher->name ?? '?', 0, 1));
        $colors = ['#667eea','#e74c3c','#2ecc71','#f39c12','#9b59b6','#1abc9c','#e67e22','#3498db'];
        $colorIndex = $loop->index % count($colors);
        $avatarColor = $colors[$colorIndex];
    @endphp
```

**Evidence**
```
$ grep -rln "function subjects" Modules/SchoolSetup/app/Models
Modules/SchoolSetup/app/Models/SubjectGroup.php
Modules/SchoolSetup/app/Models/Teacher.php
Modules/SchoolSetup/app/Models/Organization.php
$ grep -n "function subjects" Modules/SchoolSetup/app/Models/User.php
(no output — User has no subjects relation, so $subject is always empty)
```

### F11 — Security and tenancy

#### PPTC-21 · M · SEC-03 — notification writes use the `auth()->id() ?? 1` hard-coded fallback

| Field | Value |
|---|---|
| **Rule** | SEC-03 (M) — *no hard-coded ids or fallbacks such as `?? 1`* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:254` (`book`) and `:342` (`cancel`) |
| **Root cause** | Both notification inserts set `'created_by' => auth()->id() ?? 1`. The `?? 1` cannot fire on these routes (the `auth` middleware guarantees a user), but it is dead code that writes `created_by = 1` if it ever did — mislabelling an audit field. Note `tenant_id` is correctly `tenant()->id` here (unlike the API twin, which used `session('tenant_id') ?? 1`). |
| **Consequence** | A notification row could be attributed to user 1 instead of the real author, corrupting the audit trail. |
| **Reproduce** | Static only. |
| **Fix approach** | Drop the `?? 1`; `auth()->id()` is always populated behind the `auth` middleware. |
| **Plan item** | PPTC-21 in `02-fix-plan.md` §5 |

```php
// ParentPtmController.php:253-255 — CURRENT (book notification)
                            'notification_status_id'=> 'SENT',
                            'created_by'            => auth()->id() ?? 1,
                            'is_active'             => true,
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
M  SEC-03   ParentPtmController.php:254  book — hard-coded id fallback: auth()->id() ?? 1
M  SEC-03   ParentPtmController.php:342  cancel — hard-coded id fallback: auth()->id() ?? 1
```

### F12 — Style

#### PPTC-22 · L · STY-01 — the three FormRequests lack `declare(strict_types=1)` and are not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)`*; STY-02 (L) — *Pint-clean* |
| **Where** | `Modules/ParentPortal/app/Http/Requests/BookParentPtmRequest.php:1`, `CancelParentPtmRequest.php:1`, `RescheduleParentPtmRequest.php:1` |
| **Root cause** | The three requests start with `<?php` then `namespace`; no `strict_types`, and Pint reports fixers on all three. |
| **Consequence** | Style/consistency only. |
| **Reproduce** | `vendor/bin/pint --test` on the three files. |
| **Fix approach** | One style pass over the three request files. |
| **Plan item** | PPTC-22 in `02-fix-plan.md` §8 |

```php
// BookParentPtmRequest.php:1-5 — CURRENT
<?php

namespace Modules\ParentPortal\Http\Requests;

class BookParentPtmRequest extends ParentPortalBaseRequest
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Requests/BookParentPtmRequest.php \
    Modules/ParentPortal/app/Http/Requests/CancelParentPtmRequest.php \
    Modules/ParentPortal/app/Http/Requests/RescheduleParentPtmRequest.php
L  STY-01   BookParentPtmRequest.php:1       - — missing declare(strict_types=1)
L  STY-01   CancelParentPtmRequest.php:1     - — missing declare(strict_types=1)
L  STY-01   RescheduleParentPtmRequest.php:1 - — missing declare(strict_types=1)
```

#### PPTC-23 · L · STY-02 — the controller is not Pint-clean and imports `Log` but also uses `\Log::`

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean*; STY-06 (L) — *one style per concern* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:20` (import) and `:258`, `:346` (`\Log::error`) |
| **Root cause** | The file imports `Illuminate\Support\Facades\Log` (line 20) but the two notification catches call the fully-qualified `\Log::error`. Pint also reports fixers (`fully_qualified_strict_types`, `ordered_imports`, `binary_operator_spaces`, ...). |
| **Consequence** | Formatting/consistency debt; the next editor pays. |
| **Reproduce** | `vendor/bin/pint --test` on the controller. |
| **Fix approach** | Use the imported `Log` (the PPTC-03 fix does this) and run Pint on the one file after the code fixes. |
| **Plan item** | PPTC-23 in `02-fix-plan.md` §8 |

```php
// ParentPtmController.php:257-259 — CURRENT
                    } catch (\Exception $e) {
                        \Log::error('Error creating PTM booking notification: ' . $e->getMessage());
                    }
```

**Evidence**
```
$ vendor/bin/pint --test Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php 2>&1 | tail -1
{"tool":"pint","result":"fail","files":[{"path":"Modules\/ParentPortal\/app\/Http\/Controllers\/ParentPtmController.php","fixers":["fully_qualified_strict_types","concat_space","method_chaining_indentation","unary_operator_spaces","braces_position","not_operator_with_successor_space","single_line_empty_body","ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Question | book() | cancel() | reschedule() |
|---|---|---|---|
| 1. Can a write overwrite data it should not? | ok — only its own slot counters | ok — only the booking's own status | ok — old set CANCELLED and new inserted in one tx |
| 2. Is anything deleted before its replacement is stored? | ok | ok | ok — one tx, no deletes |
| 3. Duplicate implementations of one operation? | **PPTC-10** (the API twin duplicates this whole workflow — see `../ParentPtmApiController-done/01-report.md` PPTM-09) | **PPTC-10** | **PPTC-10** |
| 4. Soft-delete × unique-index trap? | ok — `active_booking_key` is NULL unless CONFIRMED, so re-booking works | ok | **PPTC-08** (a soft-deleted target slot passes `exists` then nulls) |
| 5. Is there a race? | **PPTC-06** (cross-event time overlap) | **PPTC-04** (double-cancel) | **PPTC-05** (double-run) |
| 6. Is there an authorization hole? | ok — class-section guard + middleware | ok — ownership 403 + `isCancellable` 422 | ok for the booking itself; the target event's window/duplicate rules are missing → **PPTC-08** area |
| 7. Does any message lie? | ok — "Slot booked successfully." | ok — "Booking cancelled..." | ok — "Booking rescheduled successfully." |
| 8. Is there a dead feature? | ok | ok | **PPTC-20** (teacher subject never renders) |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Ptm/app/Models/PtmSlot` + migration `2026_06_16_094314` | `unique(['teacher_id','slot_start'])` does not include `deleted_at`, while the table uses soft deletes — re-creating a slot at the same teacher/time after a soft delete raises a duplicate-key error. The migration is common (never edited by this workflow); a partial/soft-delete-aware unique index would need a new additive migration (a DECISION for the Ptm module owner). | VAL-04/MDL-03 | Ptm module owner (schema-level) |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | Returns web redirects (`redirect()->route('parent-portal.no-access')`) on a failed gate; harmless for these web routes but it is also mounted on the JSON API group (`RouteServiceProvider.php:94`), where a redirect is the wrong shape. Module-wide, not this controller. | ERR-04 | ParentPortal module owner |
| `Modules/Notification/app/Models/Notification.php` | Write-only usage; the controller creates an `ntf_notifications` row without dispatching through the notification pipeline. Whether the row reaches the parent is the Notification module's business. | JOB-04/SVC | Notification module owner |
| Shared booking workflow | `book`/`cancel`/`reschedule` are duplicated between this controller and `Api/ParentPtmApiController`, and the two copies already enforce different guard sets. Extract one shared service (deferred per D3). | SVC-04/CTL-06 | team — see `../ParentPtmApiController-done/01-report.md` PPTM-09 |

## 8. Not covered, and why

- **Live row counts / a real tenant** — no tenant DB is attached here (`prime_db` has no `ptm_*` tables); column types and unique keys were verified from the tenant migrations instead.
- **Behavioural proof of the races** (`PPTC-04`, `PPTC-05`, `PPTC-06`) — deliberately not reproduced with a test (D4: no testing). Evidence is static (lock scope + unique constraints).
- **`PptDropdownResolver` is not reached by this controller.** `grep` shows it is used only by `ParentSession`, `ConsentForm`, `ConsentFormResponse`, `ParentDocumentRequest`, `EventRsvp`, `ParentConsentFormController` and `Modules/Feedback/ConsentFormController`. It is audited here only because the main session pre-assigned it to this report (PPTC-16); its fixes are cross-cutting for those other controllers.
- **Notification delivery pipeline** — whether a created `ntf_notifications` row reaches the parent is the Notification module's business.
- **`/tmp/fa-parentportal.json`** was provided pre-generated and reused as instructed; the route list was regenerated fresh (`APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list`).
