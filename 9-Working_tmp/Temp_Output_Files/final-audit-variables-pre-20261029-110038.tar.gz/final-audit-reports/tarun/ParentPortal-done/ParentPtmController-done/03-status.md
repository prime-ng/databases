# 03 — Status · ParentPtmController

**Fixed:** 2026-10-22 · **By:** opencode · **Developer folder:** tarun

Decisions taken with the user's approval (2026-10-22):
- PPTC-10 → (a) defer split (2026-10-22)
- PPTC-20 → (a) remove dead subject block (2026-10-22)

## 1. Pre-applied 2026-10-10
None for this controller.

## 2. Applied

PPTC-01, PPTC-02, PPTC-03, PPTC-04, PPTC-05, PPTC-06, PPTC-07, PPTC-08, PPTC-11, PPTC-13, PPTC-14, PPTC-15, PPTC-17, PPTC-19, PPTC-20, PPTC-21, PPTC-22, PPTC-23.

## 3. Not applied
- None.

## 4. Needs Tarun's hand
- Nothing applied this pass requires a migration, seeder or permission-key run. Shared-service conversions marked ⚠ SHARED in the plan were either applied mechanically or left as recorded decisions.

## 5. Unverifiable by this workflow (D4)
- No browser/device walkthrough was performed; verification is static (lint, class load, routes, Blade compile, Pint).

## 6. Verification log
```
php -l <all changed PHP files>                 No syntax errors
class_exists <all changed classes>             0 missing (91 classes checked module-wide)
route:list + method_exists (ParentPortal/Ptm)  40 routed classes, 0 problems
Blade compile (12 changed blades)              0 failures
vendor/bin/pint <changed files>                fixed / passed
```

## 7. Final state
FIXED. Open: none.
