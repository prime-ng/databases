# Fix Plan — ParentPortal / ParentPortalController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentPortalController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/routes/web.php` | shared route file; routing this scaffold (or deleting it) is a product decision, not a D5 fix |
| `Modules/ParentPortal/resources/views/index.blade.php` | only consumer is this unrouted controller; kept as-is |
| `Modules/ParentPortal/app/Http/Requests/StoreParentPortalRequest.php` | stays as the method-signature type; dead-stub status is noted, not changed |
| `Modules/ParentPortal/app/Http/Requests/UpdateParentPortalRequest.php` | stays as the method-signature type; dead-stub status is noted, not changed |
| `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` | owned by `tarun/ParentPortal-done/ParentComplaintController` (see report §7) |

## 1. Blockers reachable today

- [x] **PPC-01** · M · RTE-03 · `ParentPortalController.php:15-57` — D5: the whole scaffold controller is unrouted; replace every method body with `abort(403, 'Not routed.')` under a `NOT ROUTED` docblock, add `: never` return types (resolves PPC-02, PPC-03 and PPC-04 in the same rewrite), drop the unused `Illuminate\Http\Request` import, add `declare(strict_types=1);`, keep the method signatures so nothing is deleted.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentPortalController.php`
  - **Before** (`ParentPortalController.php:1-58`):
    ```php
    <?php

    namespace Modules\ParentPortal\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Modules\ParentPortal\Http\Requests\UpdateParentPortalRequest;
    use Modules\ParentPortal\Http\Requests\StoreParentPortalRequest;

    class ParentPortalController extends Controller
    {
        /**
         * Display a listing of the resource.
         */
        public function index()
        {
            return view('parentportal::index');
        }

        /**
         * Show the form for creating a new resource.
         */
        public function create()
        {
            return view('parentportal::create');
        }

        /**
         * Store a newly created resource in storage.
         */
        public function store(StoreParentPortalRequest $request) {}

        /**
         * Show the specified resource.
         */
        public function show($id)
        {
            return view('parentportal::show');
        }

        /**
         * Show the form for editing the specified resource.
         */
        public function edit($id)
        {
            return view('parentportal::edit');
        }

        /**
         * Update the specified resource in storage.
         */
        public function update(UpdateParentPortalRequest $request, $id) {}

        /**
         * Remove the specified resource from storage.
         */
        public function destroy($id) {}
    }
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\ParentPortal\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Modules\ParentPortal\Http\Requests\StoreParentPortalRequest;
    use Modules\ParentPortal\Http\Requests\UpdateParentPortalRequest;

    class ParentPortalController extends Controller
    {
        /**
         * NOT ROUTED — no route points at this controller (verified 2026-10-13;
         * final-audit PPC-01, D5). Kept, not deleted.
         */
        public function index(): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (PPC-01, D5).
         */
        public function create(): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (PPC-01, D5).
         */
        public function store(StoreParentPortalRequest $request): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (PPC-01, D5).
         */
        public function show($id): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (PPC-01, D5).
         */
        public function edit($id): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (PPC-01, D5).
         */
        public function update(UpdateParentPortalRequest $request, $id): never
        {
            abort(403, 'Not routed.');
        }

        /**
         * NOT ROUTED — no route points at this controller (PPC-01, D5).
         */
        public function destroy($id): never
        {
            abort(403, 'Not routed.');
        }
    }
    ```
  - **Verify:** `grep -c "NOT ROUTED" Modules/ParentPortal/app/Http/Controllers/ParentPortalController.php`
  - **Expect:** `7` (one docblock per method), then `php -l` on the file reports no syntax errors, then `vendor/bin/pint Modules/ParentPortal/app/Http/Controllers/ParentPortalController.php --format agent` reformats nothing.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

## 3. Errors & transactions (F1/F2)

## 4. Authorization (F3)

## 5. Validation, routes, models (F4/F5/F7)

## 6. Queries & performance (F9)

## 7. Views (F10)

## 8. Style (F12) — one item per file

## 9. Deferred / decisions

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PPC-02 | Dead scaffold (missing views, empty stubs, unused import): no separate item because the single PPC-01 rewrite removes all three `view()` calls and empties every stub body in one paste-ready file replacement. The two stub FormRequests stay as signature types. |
| PPC-03 | Missing return types: no separate item because the PPC-01 rewrite declares `: never` on every method (the settled `abort()` shape, `PeriodTypeController::create()` precedent). |
| PPC-04 | Missing `strict_types` and scaffold docblocks: no separate item because the PPC-01 rewrite adds `declare(strict_types=1);` and replaces the copy-pasted docblocks with `NOT ROUTED (PPC-01, D5)` docblocks. |