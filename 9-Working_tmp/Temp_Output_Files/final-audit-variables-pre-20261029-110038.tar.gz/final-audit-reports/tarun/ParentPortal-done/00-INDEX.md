# ParentPortal — Final Audit Index

Protocol: `.claude/rules/final-audit.md`.
⛔ Append a row to claim. Edit only your own row. Never rewrite this file.

| Controller | Status | B | H | M | L | Report | By | Updated |
|---|---|---|---|---|---|---|---|---|
| ParentHealthController | FIXED | 0 | 2 | 0 | 2 | [ParentHealthController-done/01-report.md](ParentHealthController-done/01-report.md) | opencode | 2026-10-22 |
| ParentTransportController | FIXED | 0 | 0 | 4 | 6 | [ParentTransportController-done/01-report.md](ParentTransportController-done/01-report.md) | opencode | 2026-10-22 |
| ParentNotificationController | FIXED | 0 | 0 | 4 | 1 | [ParentNotificationController-done/01-report.md](ParentNotificationController-done/01-report.md) | opencode | 2026-10-22 |
| ParentBehaviourController | FIXED | 0 | 1 | 2 | 2 | [ParentBehaviourController-done/01-report.md](ParentBehaviourController-done/01-report.md) | opencode | 2026-10-22 |
| ParentHostelController | FIXED | 1 | 2 | 3 | 1 | [ParentHostelController-done/01-report.md](ParentHostelController-done/01-report.md) | opencode | 2026-10-22 |
| ParentTeacherController | FIXED | 0 | 0 | 4 | 1 | [ParentTeacherController-done/01-report.md](ParentTeacherController-done/01-report.md) | opencode | 2026-10-22 |
| ParentLearningController | FIXED | 1 | 0 | 4 | 7 | [ParentLearningController-done/01-report.md](ParentLearningController-done/01-report.md) | opencode | 2026-10-22 |
| ParentHomeworkController | FIXED | 2 | 1 | 5 | 5 | [ParentHomeworkController-done/01-report.md](ParentHomeworkController-done/01-report.md) | opencode | 2026-10-22 |
| ParentOtpAuthController | FIXED | 1 | 2 | 7 | 1 | [ParentOtpAuthController-done/01-report.md](ParentOtpAuthController-done/01-report.md) | opencode | 2026-10-22 |
| ParentAttendanceController | FIXED | 0 | 1 | 2 | 3 | [ParentAttendanceController-done/01-report.md](ParentAttendanceController-done/01-report.md) | opencode | 2026-10-22 |
| ParentComplaintController | FIXED | 2 | 6 | 4 | 3 | [ParentComplaintController-done/01-report.md](ParentComplaintController-done/01-report.md) | opencode | 2026-10-22 |
| ParentEventController | FIXED | 1 | 2 | 5 | 5 | [ParentEventController-done/01-report.md](ParentEventController-done/01-report.md) | opencode | 2026-10-22 |
| ParentConsentFormController | FIXED | 1 | 2 | 9 | 3 | [ParentConsentFormController-done/01-report.md](ParentConsentFormController-done/01-report.md) | opencode | 2026-10-22 |
| ParentResultController | FIXED | 1 | 1 | 4 | 8 | [ParentResultController-done/01-report.md](ParentResultController-done/01-report.md) | opencode | 2026-10-22 |
| ParentFeePaymentController | FIXED | 1 | 3 | 8 | 2 | [ParentFeePaymentController-done/01-report.md](ParentFeePaymentController-done/01-report.md) | opencode | 2026-10-22 |
| ParentAttendanceApiController | FIXED | 0 | 1 | 1 | 2 | [ParentAttendanceApiController-done/01-report.md](ParentAttendanceApiController-done/01-report.md) | opencode | 2026-10-22 |
| ParentDashboardApiController | FIXED | 0 | 2 | 3 | 1 | [ParentDashboardApiController-done/01-report.md](ParentDashboardApiController-done/01-report.md) | opencode | 2026-10-22 |
| ParentLeaveApiController | FIXED | 0 | 2 | 4 | 3 | [ParentLeaveApiController-done/01-report.md](ParentLeaveApiController-done/01-report.md) | opencode | 2026-10-22 |
| ParentPtmApiController | FIXED | 1 | 6 | 3 | 2 | [ParentPtmApiController-done/01-report.md](ParentPtmApiController-done/01-report.md) | opencode | 2026-10-22 |
| ParentSessionApiController | FIXED | 1 | 2 | 2 | 1 | [ParentSessionApiController-done/01-report.md](ParentSessionApiController-done/01-report.md) | opencode | 2026-10-22 |
| MobileParentSessionController | FIXED | 1 | 1 | 0 | 1 | [MobileParentSessionController-done/01-report.md](MobileParentSessionController-done/01-report.md) | opencode | 2026-10-22 |
| ParentAccountController | FIXED | 1 | 2 | 5 | 5 | [ParentAccountController-done/01-report.md](ParentAccountController-done/01-report.md) | opencode | 2026-10-22 |
| MobileParentController | FIXED | 0 | 3 | 7 | 2 | [MobileParentController-done/01-report.md](MobileParentController-done/01-report.md) | opencode | 2026-10-22 |
| ParentDocumentController | FIXED | 3 | 2 | 8 | 3 | [ParentDocumentController-done/01-report.md](ParentDocumentController-done/01-report.md) | opencode | 2026-10-22 |
| ParentFeeController | FIXED | 0 | 2 | 8 | 5 | [ParentFeeController-done/01-report.md](ParentFeeController-done/01-report.md) | opencode | 2026-10-22 |
| ParentDashboardController | FIXED | 2 | 5 | 9 | 3 | [ParentDashboardController-done/01-report.md](ParentDashboardController-done/01-report.md) | opencode | 2026-10-22 |
| ParentLeaveController | FIXED | 0 | 2 | 9 | 3 | [ParentLeaveController-done/01-report.md](ParentLeaveController-done/01-report.md) | opencode | 2026-10-22 |
| ParentPtmController | FIXED | 1 | 5 | 6 | 10 | [ParentPtmController-done/01-report.md](ParentPtmController-done/01-report.md) | opencode | 2026-10-22 |
| ParentTimetableController | FIXED | 0 | 1 | 6 | 3 | [ParentTimetableController-done/01-report.md](ParentTimetableController-done/01-report.md) | opencode | 2026-10-22 |
| ParentPortalController | FIXED | 0 | 0 | 2 | 2 | [ParentPortalController-done/01-report.md](ParentPortalController-done/01-report.md) | opencode | 2026-10-22 |