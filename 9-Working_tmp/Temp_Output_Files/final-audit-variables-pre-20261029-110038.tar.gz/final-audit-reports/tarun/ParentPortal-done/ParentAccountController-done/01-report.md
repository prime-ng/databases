# Final Audit — ParentPortal / ParentAccountController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php` (390 lines, 7 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/parent-portal/account?tab=profile` (tabs: profile, password, notifications, devices, language) |
| Menu path | Parent Portal → sidebar → Account Settings |
| Who uses it | Authenticated `user_type = PARENT` accounts that have a `std_guardians` row and at least one child link with `can_access_parent_portal = 1`. The portal has NO permission keys — access is the role gate in `ParentPortalMiddleware` (`Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php`). |
| What a user does here | A single page with five tabs. Profile: edit own display name/email/mobile/phone plus the linked guardian's first/last name, occupation, mobile and email. Password: change the password after checking the current one. Notifications: toggle each ntf_channel per-channel preference (one checkbox per channel). Quiet hours: set a daily do-not-disturb window applied to all preference rows. Devices (FR-18 REQ-18.5): list this guardian's device sessions and log one out. Language (FR-18 REQ-18.6): pick a portal language from seven options. Every action writes one `sys_activity_logs` row via the `activityLog()` helper. |
| Tables written | `sys_users` (profile/password), `std_guardians` (profile), `ntf_user_preferences` (notifications + quiet hours), `ppt_parent_sessions` (device logout; also the linked `ParentContextService::resolveChild()` may write `active_student_id`/`last_active_at`), `ppt_parent_sessions.active_student_id` via switch-child, `sys_activity_logs` (one row per method) |
| Tables read | `sys_users`, `std_guardians`, `ntf_channel_master`, `ntf_user_preferences`, `ppt_parent_sessions`, `sys_dropdown_table` (device-type label, one query per access via `PptDropdownResolver`), plus the linked service's `std_student_guardian_jnt`, `std_students`, `std_class_sections`, `sch_classes`, `sch_sections` |
| Live data | ⚠ UNVERIFIED — no tenant database is reachable from this host (the default `prime_db` connection has 0 tenant tables). Live row counts were not measured. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**. No pre-applied files: `final-audit-reports/tarun/ParentPortal/` has no `PRE-APPLIED-*.md`, and none of the in-scope files appear in `final-audit-reports/tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md`.

## 1. Verdict

The screen mostly works today: every route resolves, every mutation runs inside one `DB::transaction`, validation lives in FormRequests, and record ownership on the device-logout path is checked. It is **not production-ready yet** — there is one B (PAC-04): the `ParentSession` model writes and casts a column named `device_token_webpush_json`, but `ppt_parent_sessions` has `device_token_webpush`, so any web-push registration throws "Unknown column" and the Devices tab can never show the webpush row as push-enabled. The single worst finding is **PAC-01**: five of the seven methods still use the old house-rule A1 try/catch shape that D1 settled against — a generic `catch (\Throwable)` swallows the real exception trace, logs only `$e->getMessage()`, and can convert an intended `abort()`/redirect into a misleading "The operation could not be completed." redirect. Two decisions need Tarun's hand: how to persist the portal language (the `sys_users` column is `prefered_language`, an integer FK — today the write is a silent no-op behind an empty catch), and how to put the device-type string back into a table that the migration and the DDL disagree on. Rough effort to apply the whole plan: **M** — one controller restructure (S), two model edits, one shared service touch, one view one-liner, three decisions.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 2 | 5 | 5 | 3 | 13 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PAC-01, PAC-02 | F8 Services/Jobs | clean — linked |
| F2 Transactions/Audit | PAC-03 | F9 Queries/Perf | PAC-08 |
| F3 Authorization | clean | F10 Views | clean (N+1 lives in the model accessor, PAC-08) |
| F4 Validation | PAC-14 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | PAC-10, PAC-11, PAC-12, PAC-13 |
| F6 Controller shape | PAC-06, PAC-07 | F13 Deep read | table in §6 F13 |
| F7 Models | PAC-04, PAC-05 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php` | controller | 390 | this report | ✅ |
| 2 | `Modules/ParentPortal/resources/views/account/index.blade.php` | view | 550 | this report | ✅ |
| 3 | `Modules/ParentPortal/app/Models/ParentSession.php` | model | 126 | this report (pre-assigned) | ✅ |
| 4 | `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` | base request | 26 | shared — 21 FormRequests extend it; referenced, common | ✅ (used here via every account FormRequest) |
| 5 | `Modules/ParentPortal/app/Http/Requests/UpdateProfileParentAccountRequest.php` | FormRequest | 26 | this report | ✅ |
| 6 | `Modules/ParentPortal/app/Http/Requests/UpdatePasswordParentAccountRequest.php` | FormRequest | 19 | this report | ✅ |
| 7 | `Modules/ParentPortal/app/Http/Requests/UpdateNotificationPreferencesParentAccountRequest.php` | FormRequest | 19 | this report | ✅ |
| 8 | `Modules/ParentPortal/app/Http/Requests/UpdateQuietHoursParentAccountRequest.php` | FormRequest | 19 | this report | ✅ |
| 9 | `Modules/ParentPortal/app/Http/Requests/LogoutDeviceParentAccountRequest.php` | FormRequest | 18 | this report | ✅ |
| 10 | `Modules/ParentPortal/app/Http/Requests/UpdateLanguageParentAccountRequest.php` | FormRequest | 18 | this report | ✅ |
| 11 | `Modules/Notification/app/Models/ChannelMaster.php` | model | 180 | this report (claimed 2026-10-13) | ✅ |
| 12 | `Modules/Notification/app/Models/UserPreference.php` | model | 169 | this report (claimed 2026-10-13) | ✅ |
| 13 | `Modules/ParentPortal/app/Services/PptDropdownResolver.php` | service | 41 | ↗ [tarun/ParentPortal-done/ParentPtmController](../ParentPtmController-done/01-report.md) | ↗ linked (pre-assigned 2026-10-13) |
| 14 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) | ↗ linked (pre-assigned 2026-10-13; that report is still CLAIMED — service may not be finished) |
| 15 | `Modules/StudentProfile/app/Models/Guardian.php` | model | — | ↗ [gaurav/StudentProfile/StudentController](../../../gaurav/StudentProfile/StudentController-done/01-report.md) | ↗ linked — usage-only checked |
| 16 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware (module, common) | 65 | ↗ [tarun/ParentPortal-done/ParentHealthController](../ParentHealthController-done/01-report.md) | ↗ linked |
| 17 | `Modules/ParentPortal/routes/web.php` | routes (module, shared) | 199 | this report — evidence for the 7 account routes only | ✅ (one block, lines 188-199) |

**Common classes referenced, never audited here** (§4.2): `App\Http\Controllers\Controller`, `App\Models\BaseModel`, `app/Helpers/activityLog.php`, `Modules/SchoolSetup/Models/User` (`sys_users` — probed for the `language`/`prefered_language` columns, §6 PAC-02), `Modules/ParentPortal/resources/views/layouts/**`, the `DB`/`Log`/`Hash`/`Session` facades.

No pre-applied files.

## 4. Routes

Uncached `route:list` (re-exported live for this audit, identical to `/tmp/fa-routes.json`):

```
GET|HEAD parent-portal/account                                   parent-portal.account.index            Modules\ParentPortal\Http\Controllers\ParentAccountController@index
POST    parent-portal/account/devices/{device}/logout            parent-portal.account.devices.logout    Modules\ParentPortal\Http\Controllers\ParentAccountController@logoutDevice
PUT     parent-portal/account/language                           parent-portal.account.language.update   Modules\ParentPortal\Http\Controllers\ParentAccountController@updateLanguage
PUT     parent-portal/account/notifications                      parent-portal.account.notifications.update Modules\ParentPortal\Http\Controllers\ParentAccountController@updateNotificationPreferences
PUT     parent-portal/account/password                           parent-portal.account.password.update    Modules\ParentPortal\Http\Controllers\ParentAccountController@updatePassword
PUT     parent-portal/account/profile                            parent-portal.account.profile.update     Modules\ParentPortal\Http\Controllers\ParentAccountController@updateProfile
PUT     parent-portal/account/quiet-hours                        parent-portal.account.quiet-hours.update Modules\ParentPortal\Http\Controllers\ParentAccountController@updateQuietHours
```

Declared in `Modules/ParentPortal/routes/web.php:188-199` inside the group applied by `Modules/ParentPortal/app/Providers/RouteServiceProvider.php:66-80`:
`web → InitializeTenancyByDomain → PreventAccessFromCentralDomains → EnsureTenantIsActive → EnsureTenantHasModule:ParentPortal → auth → ParentPortalMiddleware`, prefix `/parent-portal`, name prefix `parent-portal.`.

Unrouted public methods: none. The constructor is injected, not routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 42 | GET /parent-portal/account (`parent-portal.account.index`) | none in controller — role gate `ParentPortalMiddleware`; no permission key | `DB::transaction` wraps the whole read + audit write (controller) | `'Viewed'` at line 77, inside the tx | sys_activity_logs; ppt_parent_sessions via linked resolveChild | PAC-01, PAC-03, PAC-06, PAC-07 |
| `logoutDevice` | 110 | POST /parent-portal/account/devices/{device}/logout | FormRequest authorize (resolveChild) + `abort_unless(device->guardian_id === $guardian->id, 403)` line 117 | `DB::transaction` (controller) | `'DeviceLoggedOut'` at line 121, inside the tx | ppt_parent_sessions, sys_activity_logs | PAC-01, PAC-03, PAC-06, PAC-07 |
| `updateLanguage` | 157 | PUT /parent-portal/account/language | FormRequest authorize (resolveChild) | `DB::transaction` (controller) | `'LanguageUpdated'` at line 176, inside the tx | sys_users (silent no-op — PAC-02), sys_activity_logs | PAC-02 |
| `updateProfile` | 195 | PUT /parent-portal/account/profile | FormRequest authorize (resolveChild) | `DB::transaction` (controller) | `'Updated'` at line 221, inside the tx | sys_users, std_guardians, sys_activity_logs | PAC-01, PAC-03, PAC-06, PAC-07 |
| `updatePassword` | 250 | PUT /parent-portal/account/password | FormRequest authorize (resolveChild) | `DB::transaction` (controller) | `'PasswordChanged'` at line 266, inside the tx | sys_users, sys_activity_logs | PAC-01, PAC-03, PAC-06, PAC-07 |
| `updateNotificationPreferences` | 296 | PUT /parent-portal/account/notifications | FormRequest authorize (resolveChild) | `DB::transaction` (controller) | `'PreferencesUpdated'` at line 327, inside the tx | ntf_user_preferences (upsert), sys_activity_logs | PAC-06, PAC-07, PAC-14 |
| `updateQuietHours` | 346 | PUT /parent-portal/account/quiet-hours | FormRequest authorize (resolveChild) | `DB::transaction` (controller) | `'QuietHoursUpdated'` at line 363, inside the tx | ntf_user_preferences, sys_activity_logs | PAC-01, PAC-03, PAC-06, PAC-07 |
| `__construct` | 35 | — (injected) | — | — | — | — | — |

**Tables each mutation SHOULD touch** (controller-alignment §0.1): profile → sys_users + std_guardians (+ audit); password → sys_users (+ audit); notifications → ntf_user_preferences (+ audit); quiet hours → ntf_user_preferences (+ audit); language → sys_users (+ audit); device logout → ppt_parent_sessions (+ audit). All six match what the controller CAN touch; only the language write never lands (PAC-02).

## 6. Findings

### F1 — Errors

#### PAC-01 · H · D1 / ERR-07 / ERR-05 — five methods still use the pre-D1 try/catch shape; the generic catch swallows the trace and can convert an intended abort/redirect

| Field | Value |
|---|---|
| **Rule** | D1 (settled — no try/catch in controllers; `DB::transaction()` rolls back by itself and `bootstrap/app.php` renders) + ERR-07 (M — read/error paths need no try/catch under either variant) + ERR-05 (M — log the exception object, not only `getMessage()`). Severity H because the generic catch swallows the trace for every failure and can mis-route an intended redirect. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php:42-105` method `index()`; same shape in `logoutDevice` 110-152, `updateProfile` 195-245, `updatePassword` 250-290, `updateQuietHours` 346-389. The `updateLanguage` inner catch is PAC-02. |
| **Root cause** | The methods were written to house rule A1: `try { return DB::transaction(fn () => …); } catch (ModelNotFoundException $e) { throw $e; } catch (HttpExceptionInterface $e) { throw $e; } catch (\Throwable $e) { Log::error('…', ['error' => $e->getMessage()]); return back()->with('error', 'The operation could not be completed.'); }`. D1 supersedes A1 for modules under final audit: the closure already rolls back and rethrows, and the central handler renders. The `\Throwable` catch also swallows `HttpResponseException` from `abort()`/`abort_unless()`/`resolveChild()`'s no-access `abort(redirect(...))`, converting an intended jump into a generic error redirect; the `ModelNotFoundException`/`HttpExceptionInterface` pre-catches exist only because of that swallow. Each catch logs only `$e->getMessage()`, losing the trace. |
| **Consequence** | On any failure on these five methods the user sees "The operation could not be completed." instead of the true 404/403/redirect, the exception trace is dropped from the log, and the central exception handler never runs; when the parent's only linked child is deactivated (`is_active = false`), the linked `resolveChild()` no-access redirect is turned into that same misleading message. |
| **Reproduce** | Static only — the swallow is visible in the catch. The no-access conversion needs a parent whose only linked child is deactivated: the service aborts with the no-access redirect, the `\Throwable` catch converts it to `back()->with('error', …)`. |
| **Fix approach** | Remove the outer `try`/catches in all five methods; keep the `DB::transaction(...)` closures (D1) and move every `redirect()`/`back()` response after the closure returns (TXN-05); tighten `index()` to `: View`; replace the `request()` helper with the injected `$request`; drop the imports that become unused (`ModelNotFoundException`, `HttpExceptionInterface`, `Log`); leave `updateLanguage` for PAC-02. Plan item PAC-01 carries the complete rewritten controller. |
| **Plan item** | PAC-01 in `02-fix-plan.md` §1 (also covers PAC-03, PAC-06, PAC-07, PAC-11 — see plan §10) |

```php
// ParentAccountController.php:42-105 — index() CURRENT (one of the five)
    public function index(Request $request): View|RedirectResponse
    {
        try {
            return DB::transaction(function () use ($request) {
                $user     = $request->user();
                $child    = $this->context->resolveChild($request);
                $guardian = Guardian::where('user_id', $user->id)->first();
```

**Evidence**
```
$ grep -n 'try {\|catch (' Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php
44:        try {
93:        } catch (ModelNotFoundException $e) {
97:        } catch (\Throwable $e) {
112:        try {
135:        } catch (ModelNotFoundException $e) {
139:        } catch (HttpExceptionInterface $e) {
147:        } catch (\Throwable $e) {
170:            try {
172:            } catch (\Throwable) {
197:        try {
236:        } catch (ModelNotFoundException $e) {
240:        } catch (\Throwable $e) {
252:        try {
281:        } catch (ModelNotFoundException $e) {
285:        } catch (\Throwable $e) {
348:        try {
380:        } catch (ModelNotFoundException $e) {
384:        } catch (\Throwable $e) {
```

#### PAC-02 · H · ERR-06 / ERR-05 / VAL-05 — updateLanguage swallows a failed write and the audit row claims success that never happened

| Field | Value |
|---|---|
| **Rule** | ERR-06 (H — no swallowed failures in write paths) + ERR-05 (M — log the exception object) + VAL-05 (M — write paths with no effective validation). Default H kept: the write is a silent no-op every time. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php:168-186`, method `updateLanguage()` |
| **Root cause** | The method calls `$request->user()->update(['language' => $validated['language']])`. `sys_users` has no `language` column — the real column is `prefered_language`, an `unsignedInteger` FK to `glb_languages` (`database/migrations/tenant/2026_06_15_145405_create_sys_users_table.php:36,44`), and `Modules/SchoolSetup/app/Models/User.php` `$fillable` has `prefered_language` (line 121), never `language`. Mass assignment therefore filters `language` out and the update is a no-op without throwing. The surrounding `catch (\Throwable) { /* Silent fail */ }` was written for a "column may not exist" case that never throws; between the two, the write never lands, and the `activityLog(..., 'LanguageUpdated', ...)` at line 176 records a change the row never took. |
| **Consequence** | Every parent who saves a language gets "Language preference updated." and an audit row claiming the change, but nothing is persisted — the preference exists only in the PHP session, and the audit trail lies. |
| **Reproduce** | Static only — `grep -n "'language'" Modules/SchoolSetup/app/Models/User.php` returns nothing while the fillable contains `prefered_language`; the update therefore no-ops on every request. |
| **Fix approach** | Stop swallowing: remove the inner `try/catch` (D1) and decide how to persist (the correct column is `prefered_language`, which stores an id from `glb_languages`, not a code string — the mapping code→id is unknown here). If persistence is dropped, remove the DB write and the audit context's `'language'` claim. |
| **Plan item** | PAC-02 in `02-fix-plan.md` §9 (DECISION — the exact persistence shape is Tarun's choice) |

```php
// ParentAccountController.php:170-174 — CURRENT
            try {
                $request->user()->update(['language' => $validated['language']]);
            } catch (\Throwable) {
                // Silent fail if users table doesn't have a language column
            }
```

**Evidence**
```
$ sed -n '168,174p' Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php
        DB::transaction(function () use ($request, $validated) {
            // Persist to user if the column exists
            try {
                $request->user()->update(['language' => $validated['language']]);
            } catch (\Throwable) {
                // Silent fail if users table doesn't have a language column
            }
$ grep -n "'language'" Modules/SchoolSetup/app/Models/User.php
(no output)
$ grep -n "prefered_language" Modules/SchoolSetup/app/Models/User.php database/migrations/tenant/2026_06_15_145405_create_sys_users_table.php
Modules/SchoolSetup/app/Models/User.php:121:        'prefered_language',
database/migrations/tenant/2026_06_15_145405_create_sys_users_table.php:36:            $table->unsignedInteger('prefered_language');
database/migrations/tenant/2026_06_15_145405_create_sys_users_table.php:44:            $table->foreign('prefered_language', 'fk_users_language')
```

### F2 — Transactions and audit

#### PAC-03 · M · TXN-05 — the HTTP response is built inside the DB::transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M — the closure returns data; build `redirect()`/`response()` after it). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php:231-233` (updateProfile — the example); same pattern in `index` 87-91, `logoutDevice` 132, `updatePassword` 276-278, `updateQuietHours` 375-377. Only `updateLanguage` (188) and `updateNotificationPreferences` (338) already build their response after the closure. |
| **Root cause** | `return redirect()/back()` is written inside the `DB::transaction(fn () => ...)` closure, so the response object is assembled while the transaction is still open. |
| **Consequence** | Cosmetic today — the closure commits before the response is returned — but it keeps the redirect/back construction coupled to the write, which is exactly what TXN-05 forbids, and made `index()`'s return type have to be widened to `View\|RedirectResponse`. |
| **Reproduce** | Static only — the `return redirect()` lines sit inside the closure bodies. |
| **Fix approach** | Move every `redirect()`/`back()` after the `DB::transaction(...)` call. This is done inside plan item PAC-01's rewrite. |
| **Plan item** | none — covered by PAC-01 (see plan §10) |

```php
// ParentAccountController.php:231-233 — CURRENT (inside the closure)
                return redirect()
                    ->route('parent-portal.account.index', ['tab' => 'profile'])
                    ->with('success', 'Profile updated successfully.');
```

**Evidence**
```
$ grep -n 'DB::transaction\|return back()\|return redirect()' Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php
45:            return DB::transaction(function () use ($request) {
103:            return back()->with('error', 'The operation could not be completed.');
113:            return DB::transaction(function () use ($request, $device) {
132:                return back()->with('success', 'Device logged out successfully.');
150:            return back()->with('error', 'The operation could not be completed.');
168:        DB::transaction(function () use ($request, $validated) {
188:        return back()->with('success', 'Language preference updated.');
198:            return DB::transaction(function () use ($request) {
231:                return redirect()
243:            return back()->with('error', 'The operation could not be completed.');
253:            return DB::transaction(function () use ($request) {
259:                    return back()
276:                return redirect()
288:            return back()->with('error', 'The operation could not be completed.');
320:        DB::transaction(function () use ($rows) {
338:        return redirect()
349:            return DB::transaction(function () use ($request) {
375:                return redirect()
387:            return back()->with('error', 'The operation could not be completed.');
```

### F3 — Authorization

clean — every routed method sits behind `ParentPortalMiddleware` (route-level, role gate checked in `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php`), every mutation also passes a FormRequest whose `authorize()` calls `ParentPortalBaseRequest::authorize()` (resolves an accessible child), and `logoutDevice` adds the record-level ownership check `abort_unless($guardian && $device->guardian_id === $guardian->id, 403)` at line 117. All authorization happens before any record is loaded or written (AUTH-02). No permission strings exist in this module — the middleware is the single gate (AUTH-06 n/a). Proof: `grep -n 'authorize\|abort_unless' Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php` → the `abort_unless` line and no other statement; FormRequest `authorize()` methods all `return parent::authorize();`.

### F4 — Validation and input

#### PAC-14 · M · MDL-03 / VAL-04 — the preferences upsert collides with a soft-delete × unique-index trap on ntf_user_preferences

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H — uniqueness rules/upserts must mirror the DB index including soft-delete semantics) + MDL-03 (M — soft-deletable pivot/preference rows must not silently count). Lowered to M: nothing in this controller's scope soft-deletes a preference row, so the trap is latent. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php:320-325`, method `updateNotificationPreferences()`; table `ntf_user_preferences` |
| **Root cause** | `ntf_user_preferences` has `deleted_at` (`database/migrations/tenant/2026_06_16_111141_create_ntf_user_preferences_table.php:41`) AND a hard `unique(['user_id','channel_id'])` (line 37). `UserPreference::upsert($rows, ['user_id','channel_id'], [...])` (lines 321-325) runs `INSERT … ON DUPLICATE KEY UPDATE`: if a row for the pair exists but is soft-deleted, MySQL treats it as the duplicate and updates it, leaving `deleted_at` set — the row stays invisible to every normal query. The parent saves preferences, gets the success flash, and the page still shows the defaults. |
| **Consequence** | ⚠ UNVERIFIED — a caller that soft-deletes a preference row would need to exist (e.g. the Notification module's preference reset). None is known in this scope, so today the screen works. If one appears, the parent's saved toggles silently vanish. |
| **Reproduce** | Static only — soft-delete a row for `(user_id, channel_id)` then re-save; the upsert updates the trashed row. Not run (no tenant DB, D4). |
| **Fix approach** | When a trashed row is found, resurrect it (clear `deleted_at`) before/with the upsert, or scope updates to non-trashed rows — exact choice below. |
| **Plan item** | PAC-14 in `02-fix-plan.md` §9 (DECISION) |

```php
// ParentAccountController.php:320-325 — CURRENT
        DB::transaction(function () use ($rows) {
            UserPreference::upsert(
                $rows,
                ['user_id', 'channel_id'],
                ['is_enabled', 'is_active', 'updated_at']
            );
```

**Evidence**
```
$ sed -n '37,41p' database/migrations/tenant/2026_06_16_111141_create_ntf_user_preferences_table.php
            $table->unique(['user_id', 'channel_id'], 'uq_user_channel');
38:
39:            // Indexes
40:            $table->index(['user_id', 'is_enabled'], 'idx_pref_user');
41:            $table->softDeletes();
```

F4 otherwise clean — validation lives in FormRequests (VAL-02): `UpdateProfileParentAccountRequest` enforces unique email with `Rule::unique('sys_users','email')->ignore($user->id)` (consistent with the plain unique index that includes soft-deleted rows, so no 500 on re-create); `UpdatePasswordParentAccountRequest` uses `Password::min(8)->mixedCase()->numbers()` and `confirmed`; `UpdateNotificationPreferencesParentAccountRequest` types `notifications.*` as `boolean`; `UpdateQuietHoursParentAccountRequest` uses `date_format:H:i`; `UpdateLanguageParentAccountRequest` restricts to `in:en,hi,ta,te,bn,mr,gu`. Optional values are read with `??` (VAL-03) in `updateProfile` and `updateNotificationPreferences`.

### F5 — Routes

clean — every route points to an existing method (route:list above, RTE-02); every public method is routed (RTE-03); state changes use PUT/POST, never GET (RTE-01; the only GET here, `index`, writes one audit row as the module convention, which the sibling reports accept); the `{device}` parameter is an implicit `ParentSession` model binding whose name matches the method argument (RTE-06 / §3.3.1 of module-finalization — `$device` is a bound `ParentSession`, not an unbound id); the group carries tenancy + auth + `ParentPortalMiddleware` (RTE-05). No custom routes collide with `Route::resource` (there is none in these lines).

### F6 — Controller shape

#### PAC-06 · M · CTL-05 — the activityLog context block is copy-pasted six times

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M — no copy-paste blocks). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php:123-129` (logoutDevice — the example); identical blocks at 178-185, 223-229, 268-274, 329-335, 365-372. |
| **Root cause** | Six of the seven methods repeat the same `'context' => ['student_id' => null, 'student_name' => null, 'module' => 'ParentPortal', 'route' => request()->route()?->getName()]` array (with the same fixed message style), and the four `\Throwable` catches repeat the same log line and the same flash text. A change to the context (e.g. adding the tenant id) must be made six times. |
| **Consequence** | Maintenance debt: the six blocks have already drifted in whitespace between tabs, and a future context change is certain to be applied in one method and missed in five. |
| **Reproduce** | Static only — `grep -n "'student_id' => null"` returns six lines. |
| **Fix approach** | Extract one private helper that returns the standard context array (and take `Request $request` so the helper uses the injected request). Done inside plan item PAC-01's rewrite. |
| **Plan item** | none — covered by PAC-01 (see plan §10) |

```php
// ParentAccountController.php:123-129 — CURRENT (one of the six)
                'context' => [
                    'student_id' => null,
                    'student_name' => null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
```

**Evidence**
```
$ grep -n "'student_id' => null" Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php
124:                        'student_id' => null,
179:                    'student_id' => null,
224:                        'student_id' => null,
269:                        'student_id' => null,
330:                    'student_id' => null,
366:                        'student_id' => null,
```

#### PAC-07 · L · CTL-08 — the `request()` helper is used instead of the injected Request

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L — inject `Request`; don't call the `request()` helper inside controller methods). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php:83,127,182,227,272,333,369` (all `'route' => request()->route()?->getName()` inside activityLog context). |
| **Root cause** | The `activityLog` context uses the global `request()` helper rather than the `$request` already injected into every method. It works, but it bypasses the injected dependency and makes the helper call impossible to mock or see in the signature. |
| **Consequence** | Style/consistency only — in a callable/test context the helper is a hidden global. |
| **Reproduce** | Static only — `grep -n 'request()->route'` returns seven lines. |
| **Fix approach** | Replace with `$request->route()?->getName()` in every activityLog context (the transaction closures capture `$request` already). Done inside plan item PAC-01's rewrite. |
| **Plan item** | none — covered by PAC-01 (see plan §10) |

```php
// ParentAccountController.php:83 — CURRENT
                        'route' => request()->route()?->getName(),
```

**Evidence**
```
$ grep -n 'request()->route' Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php
83:                        'route' => request()->route()?->getName(),
127:                        'route' => request()->route()?->getName(),
182:                    'route' => request()->route()?->getName(),
227:                        'route' => request()->route()?->getName(),
272:                        'route' => request()->route()?->getName(),
333:                    'route' => request()->route()?->getName(),
369:                        'route' => request()->route()?->getName(),
```

F6 otherwise clean — 390 lines / 7 public methods (under the 1,000/25 CTL-01 thresholds), every method under 150 lines (CTL-02), return types present (CTL-04), no `dd`/`dump`/debug leftovers (CTL-09).

### F7 — Models

#### PAC-04 · B · MDL-07 — ParentSession addresses a column that does not exist: `device_token_webpush_json` vs `device_token_webpush`

| Field | Value |
|---|---|
| **Rule** | MDL-07 (B — every model's columns must match the table; a write to a missing column 500s on first use). Severity kept B: a normal API registration path throws a SQL error. |
| **Where** | `Modules/ParentPortal/app/Models/ParentSession.php` lines 26 and 38 (`$fillable`/`$casts` list `device_token_webpush_json`); the migration defines `device_token_webpush` (`database/migrations/tenant/2026_06_16_105227_create_ppt_parent_sessions_table.php:18`), as does the canonical DDL. The error is written by `ParentContextService::registerDeviceToken()` (lines 166-168, owned by the dashboard report) and read in the view at `index.blade.php:431`. |
| **Root cause** | The model was written against a column name that no migration ever created. Any mass assignment of `device_token_webpush_json` (fillable) is emitted as `INSERT/UPDATE ... device_token_webpush_json` → `SQLSTATE[42S22]: Column not found`. The view at line 431 checks the same wrong name, so the "Push notifications enabled" hint can never be true for a web-push row even if the column were fixed. |
| **Consequence** | A parent who registers a PWA web-push subscription gets a 500 on the registration call (a crash on a normal registration path), and the Devices tab never shows web-push as enabled. |
| **Reproduce** | Static only — `grep -n "device_token_webpush"` on the model (lines 26,38) vs the migration (line 18 `$table->text('device_token_webpush')`). A live reproduce needs a tenant DB and a PWA registration call (D4: no writes). |
| **Fix approach** | Rename to `device_token_webpush` in the model's `$fillable`/`$casts` and in the view line 431; the shared `ParentContextService` write must be renamed in the same change, then its `json_encode` into an array-cast also stops double-encoding. The cast `'array'` matches the `json`/`text` JSON payload. |
| **Plan item** | PAC-04 in `02-fix-plan.md` §1 — ⚠ SHARED (touches `ParentContextService.php`, owned by the ParentDashboardController report) |

```php
// ParentSession.php:21-43 — CURRENT ($fillable + $casts)
    protected $fillable = [
        'guardian_id',
        'active_student_id',
        'device_token_fcm',
        'device_token_apns',
        'device_token_webpush_json',
        'device_type_option_id',
        'notification_preferences_json',
        'quiet_hours_start',
        'quiet_hours_end',
        'last_active_at',
        'is_active',
        'created_by',
    ];

    protected $casts = [
        'notification_preferences_json' => 'array',
        'device_token_webpush_json'     => 'array',
        'quiet_hours_start'             => 'string',
        'quiet_hours_end'               => 'string',
        'last_active_at'                => 'datetime',
        'is_active'                     => 'boolean',
    ];
```

**Evidence**
```
$ grep -n "device_token_webpush" Modules/ParentPortal/app/Models/ParentSession.php database/migrations/tenant/2026_06_16_105227_create_ppt_parent_sessions_table.php
Modules/ParentPortal/app/Models/ParentSession.php:26:        'device_token_webpush_json',
Modules/ParentPortal/app/Models/ParentSession.php:38:        'device_token_webpush_json'     => 'array',
database/migrations/tenant/2026_06_16_105227_create_ppt_parent_sessions_table.php:18:            $table->text('device_token_webpush')->nullable();
```

#### PAC-05 · M · MDL-01 / MDL-02 — ParentSession's `device_type` virtual attribute is unreachable by mass assignment, and the real column has no cast

| Field | Value |
|---|---|
| **Rule** | MDL-01 (H — `$fillable` must be deliberate) + MDL-02 (M — casts for every boolean/date/decimal/JSON column). Lowered to M: the crash consequence lives in the linked service, not in the model itself. |
| **Where** | `Modules/ParentPortal/app/Models/ParentSession.php` lines 21-43 ($fillable/$casts), lines 67-73 (accessor), lines 78-83 (mutator), lines 87-90 (scope). |
| **Root cause** | The model exposes a virtual `device_type` string (accessor `getDeviceTypeAttribute` → `PptDropdownResolver::value(device_type_option_id)`, mutator `setDeviceTypeAttribute` → `PptDropdownResolver::id(...)`), but `device_type` is NOT in `$fillable`, so `ParentSession::create(['device_type' => 'Web'])` / `->update(['device_type' => ...])` silently drops the key and the mutator never runs. The linked `ParentContextService::getOrCreateSession()` passes `device_type` (line 217) — ignored — while the migration makes `device_type_option_id` `unsignedInteger` NOT NULL with no default (`2026_06_16_105227...:19`), so the session insert can fail with "Field 'device_type_option_id' doesn't have a default value". The canonical DDL instead declares `device_type ENUM('Android','iOS','Web','Unknown') NOT NULL DEFAULT 'Unknown'` — migration and DDL disagree, which is the decision. The model also shows `device_type_option_id` (line 27) with no integer cast (MDL-02). |
| **Consequence** | Today the session-creation path in the linked service can fail (or, if the DB is lenient, create rows with a NULL device type), and the `isQuietHour`/view logic that reads `device_type` can get `'Unknown'` for everything. |
| **Reproduce** | Static only — `grep -n "device_type" ParentSession.php` shows the virtual attribute in fillable/casts is absent; the migration's NOT NULL `device_type_option_id` forces the value the mutator would provide. |
| **Fix approach** | Tarun picks between (a) keep the dropdown-FK design and add `device_type` to `$fillable` (the mutator then fills `device_type_option_id`) — requires `PptDropdownResolver::id()` to return a real row for every device-type value; (b) align to the DDL and replace the dropdown FK with a `device_type` ENUM column (a migration, DECISION) and drop the accessor/mutator indirection. Either way, add `'device_type_option_id' => 'integer'` to `$casts`. |
| **Plan item** | PAC-05 in `02-fix-plan.md` §9 (DECISION — migration or fillable change; DDL vs migration disagreement) |

```php
// ParentSession.php:67-73 — CURRENT (accessor; the mutator at 78-83 sets the same attribute)
    public function getDeviceTypeAttribute(): ?string
    {
        return PptDropdownResolver::value($this->attributes['device_type_option_id'] ?? null) ?? 'Unknown';
    }
```

**Evidence**
```
$ grep -n "device_type" Modules/ParentPortal/app/Models/ParentSession.php
27:        'device_type_option_id',
64:        return $this->belongsTo(Dropdown::class, 'device_type_option_id');
72:        return PptDropdownResolver::value($this->attributes['device_type_option_id'] ?? null) ?? 'Unknown';
80:        $this->attributes['device_type_option_id'] = $value
81:            ? PptDropdownResolver::id('ppt_parent_sessions.device_type', $value)
82:            : PptDropdownResolver::id('ppt_parent_sessions.device_type', 'Unknown');
$ sed -n '19p' database/migrations/tenant/2026_06_16_105227_create_ppt_parent_sessions_table.php
            $table->unsignedInteger('device_type_option_id');
```

### F8 — Services and jobs

clean — the only in-scope service of my own claim is none (PptDropdownResolver is linked to the ParentPtmController report); `ParentContextService` is linked to the ParentDashboardController report, with these cross-cutting notes recorded in §7: `registerDeviceToken()` writes `device_token_webpush_json` (PAC-04's wrong name) with `json_encode` into an array cast (double-encode once the name is right), and both `registerDeviceToken()`/`getOrCreateSession()` pass a non-fillable `device_type` (PAC-05). No jobs, events, mail or notifications in this controller.

### F9 — Queries and performance

#### PAC-08 · M · VIEW-02 / QRY-01 — the device list runs a dropdown query per device, twice per row, through the model accessor

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H — no queries inside loops) + VIEW-02 (M — relations used inside `@foreach` must be eager-loaded). Lowered to M: the loop is the guardian's own device list — a handful of rows — so the blast radius is small, but the fix is one line. |
| **Where** | `Modules/ParentPortal/resources/views/account/index.blade.php` lines 398-416 (the `@foreach($devices as $device)` using `$device->device_type` at lines 407 and 416) driving `Modules/ParentPortal/app/Models/ParentSession.php` lines 67-73 (`getDeviceTypeAttribute()` → `PptDropdownResolver::value()` → `Dropdown::find($id)`). |
| **Root cause** | The `@foreach` calls `$device->device_type` twice per row (the `@switch` icon at 407 and the label at 416). Each call hits the accessor, which calls `PptDropdownResolver::value()` → `Dropdown::find($id)` — one SQL query per row, twice. The controller's `index()` (lines 59-62) loads `ParentSession` rows without eager-loading `deviceTypeOption`. |
| **Consequence** | A parent with N devices pays 2N tiny `sys_dropdown_table` lookups on every Account load; on the mobile-heavy devices tab this is the classic N+1 the portal set out to avoid. |
| **Reproduce** | Static only — count the accessor calls in the view (two per row) and the `Dropdown::find` in `PptDropdownResolver::value()`. A query log on a live tenant would show 2N queries. |
| **Fix approach** | Memoise in `getDeviceTypeAttribute()` (a static array keyed by `device_type_option_id`) so both view calls resolve from memory after one lookup, and optionally eager-load `deviceTypeOption` in `index()`. The memo-only fix keeps this item independent of PAC-01. |
| **Plan item** | PAC-08 in `02-fix-plan.md` §6 (touches `ParentSession.php` only) |

```php
// index.blade.php:398-416 — CURRENT (device row; $device->device_type triggers a query per call)
                        @foreach($devices as $device)
                        <div class="list-group-item border-0 px-0 py-3"
                             style="border-bottom:1px solid #f1f2f6 !important;">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="d-flex gap-3">
                                    <div style="width:44px;height:44px;border-radius:10px;
                                                background:{{ $device->is_active ? '#e8f4ff' : '#f1f2f6' }};
                                                display:flex;align-items:center;justify-content:center;
                                                color:{{ $device->is_active ? '#667eea' : '#b2bec3' }};">
                                        @switch($device->device_type)
                                            @case('Android') <i class="fa fa-android fa-lg"></i> @break
                                            @case('iOS')     <i class="fa fa-apple fa-lg"></i> @break
                                            @case('Web')     <i class="fa fa-desktop fa-lg"></i> @break
                                            @default         <i class="fa fa-mobile fa-lg"></i>
                                        @endswitch
                                    </div>
                                    <div>
                                        <div class="fw-semibold" style="font-size:13px;">
                                            {{ $device->device_type ?: 'Unknown device' }}
```

```php
// ParentSession.php:67-73 — CURRENT (the accessor behind each call)
    public function getDeviceTypeAttribute(): ?string
    {
        return PptDropdownResolver::value($this->attributes['device_type_option_id'] ?? null) ?? 'Unknown';
    }
```

**Evidence**
```
$ grep -n 'device_type' Modules/ParentPortal/resources/views/account/index.blade.php
407:                                        @switch($device->device_type)
416:                                            {{ $device->device_type ?: 'Unknown device' }}
$ sed -n '33,39p' Modules/ParentPortal/app/Services/PptDropdownResolver.php
    public static function value(?int $id): ?string
    {
        if ($id === null) {
            return null;
        }
        $row = Dropdown::find($id);
```

F9 otherwise clean — `ChannelMaster::orderBy('name')->get()` (index:51) and `ChannelMaster::all()` (updateNotificationPreferences:303) are small reference tables where every channel row is genuinely needed (each becomes a preference row), so QRY-15/QRY-02 do not apply; no query appears inside any other loop; the controller never paginates a list that can grow (the device list is the guardian's own sessions, bounded).

### F10 — Views

clean — no `Model::`/`DB::` queries in the blade (VIEW-01); success/error flashes use `session('success')`; no `{!! !!}` on user text (VIEW-03); the passwords tab matches the FormRequest rules (8+ chars, mixed case, a number); the quiet-hours inputs are `type="time"` matching `date_format:H:i`; blades compile (`@php` blocks use valid syntax; no `{{-- --}}` inside `@php`). The one N+1 the view triggers is reported as PAC-08 because the query lives in the model accessor.

### F11 — Security and tenancy

clean — no `env()` calls (all config comes through the app); no JSON endpoints (SEC-02 n/a); no hard-coded ids or `?? 1` fallbacks (SEC-03); the only logs are the five `Log::error(..., ['error' => $e->getMessage()])` lines which log the message, not the request body or secrets (SEC-04; the message-only logging is ERR-05 in PAC-01); no files served; no cache keys (TEN-02 n/a); every query runs on the tenant connection inside the tenancy middleware stack.

### F12 — Style

#### PAC-10 · L · STY-01 — missing `declare(strict_types=1)` in the six account FormRequests and the two notified models

| Field | Value |
|---|---|
| **Rule** | STY-01 (L — `declare(strict_types=1);` in PHP files; old files when touched). |
| **Where** | `Modules/Notification/app/Models/ChannelMaster.php` and `Modules/Notification/app/Models/UserPreference.php` (lines 1-3, no `declare(strict_types=1);`), and the six account FormRequests (`Modules/ParentPortal/app/Http/Requests/UpdateProfileParentAccountRequest.php` etc., lines 1-3). |
| **Root cause** | The files open `<?php` + `namespace` with no strict_types declaration, unlike `ParentSession.php` and the controller. |
| **Consequence** | Style only — scalar type hints outside strict mode coerce silently. |
| **Reproduce** | Static only — `sed -n '1,2p'` on any of the files. |
| **Fix approach** | Insert `declare(strict_types=1);` after `<?php` in each file. |
| **Plan item** | PAC-10 in `02-fix-plan.md` §8 — one item, eight files |

```php
// ChannelMaster.php:1-3 — CURRENT (representative of the eight)
<?php

namespace Modules\Notification\Models;
```

**Evidence**
```
$ for f in Modules/ParentPortal/app/Http/Requests/UpdateProfileParentAccountRequest.php Modules/Notification/app/Models/ChannelMaster.php Modules/Notification/app/Models/UserPreference.php; do echo "$f"; sed -n '1,4p' "$f"; done
Modules/ParentPortal/app/Http/Requests/UpdateProfileParentAccountRequest.php
<?php

namespace Modules\ParentPortal\Http\Requests;
...
Modules/Notification/app/Models/ChannelMaster.php
<?php

namespace Modules\Notification\Models;
...
```

#### PAC-11 · L · STY-02 / CTL-10 — controller imports are unordered with stray blank lines, and `Password` is imported but unused

| Field | Value |
|---|---|
| **Rule** | STY-02 (L — Pint-clean imports, sorted, no stray blank lines) + CTL-10 (M — no unused imports; lowered to L with STY-02: it is one unused symbol). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php:5-31`. |
| **Root cause** | The import block has blank lines separating groups (`ModelNotFoundException` then blank then `Log` then blank then `DB`), the ordering is not alphabetical, and `use Illuminate\Validation\Rules\Password;` (line 24) is never referenced — the password rules live in `UpdatePasswordParentAccountRequest.php`. |
| **Consequence** | Style only; Pint would reformat on the next touch. |
| **Reproduce** | Static only — `grep -n 'Password\|^use '` on the controller shows the unused import at line 24 and the blank-line groups. |
| **Fix approach** | Sort imports alphabetically, drop the blank lines between them, remove the `Password` import. This is part of plan item PAC-01's full-file After. |
| **Plan item** | none — covered by PAC-01 (see plan §10) |

```php
// ParentAccountController.php:5-13 — CURRENT
namespace Modules\ParentPortal\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\DB;

use App\Http\Controllers\Controller;
```

**Evidence**
```
$ sed -n '5,24p' Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php
namespace Modules\ParentPortal\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\DB;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Modules\ParentPortal\Http\Requests\LogoutDeviceParentAccountRequest;
use Modules\ParentPortal\Http\Requests\UpdateNotificationPreferencesParentAccountRequest;
use Modules\ParentPortal\Http\Requests\UpdateQuietHoursParentAccountRequest;
use Modules\ParentPortal\Http\Requests\UpdateLanguageParentAccountRequest;
use Modules\ParentPortal\Http\Requests\UpdatePasswordParentAccountRequest;
use Modules\ParentPortal\Http\Requests\UpdateProfileParentAccountRequest;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\Rules\Password;
```

#### PAC-12 · L · STY-04 — emoji and box-drawing characters in comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L — English comments, no emoji markers, no box-drawing separators). |
| **Where** | `Modules/Notification/app/Models/UserPreference.php:133` (`⚠ Timezone:` inside the `isWithinQuietHours` docblock); `Modules/ParentPortal/app/Models/ParentSession.php:45,85,92` and `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php:56,65` (`──` separator comments). |
| **Root cause** | The project style (STY-04) calls for plain English comments; `⚠` and `──` come from the comment style of earlier modules. |
| **Consequence** | Style only; these characters render inconsistently across consoles/editors. |
| **Reproduce** | Static only — `grep -n '──\|⚠'` on the three files. |
| **Fix approach** | Replace `⚠` with a plain "Note:" wording and the `──` separators with `---` or plain text. |
| **Plan item** | PAC-12 in `02-fix-plan.md` §8 (touches `UserPreference.php` and `ParentSession.php`; controller separators are handled by PAC-01's rewrite) |

```php
// UserPreference.php:133 — CURRENT
     * ⚠ Timezone: this compares against the application's current time, NOT
```

**Evidence**
```
$ grep -n '──\|⚠' Modules/ParentPortal/app/Models/ParentSession.php Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php Modules/Notification/app/Models/UserPreference.php
Modules/ParentPortal/app/Models/ParentSession.php:45:    // ── Relationships ────────────────────────────────────────────────────────
Modules/ParentPortal/app/Models/ParentSession.php:85:    // ── Scopes ───────────────────────────────────────────────────────────────
Modules/ParentPortal/app/Models/ParentSession.php:92:    // ── Helpers ──────────────────────────────────────────────────────────────
Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php:56:                // ── FR-18: Device sessions for this guardian ───────────────────────
Modules/Notification/app/Models/UserPreference.php:133:     * ⚠ Timezone: this compares against the application's current time, NOT
```

#### PAC-13 · L · MDL-04 — ChannelMaster and UserPreference relationship methods lack return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L — relationship methods return-typed). |
| **Where** | `Modules/Notification/app/Models/ChannelMaster.php` lines 88-98 and 124-157 (12 relations) and `Modules/Notification/app/Models/UserPreference.php` lines 73-86 (3 relations). |
| **Root cause** | The relation methods declare no return type, unlike `ParentSession`'s relations which do. |
| **Consequence** | Style/maintenance only — the IDE and static analysis lose the relation return type. |
| **Reproduce** | Static only — `grep -nE 'public function [a-zA-Z]+\(\)'` on both models lists the untyped relations. |
| **Fix approach** | Add `: \Illuminate\Database\Eloquent\Relations\HasMany` / `BelongsTo` return types to the fifteen methods (inline FQCN keeps the diff import-free, same pattern as `ParentSession`). |
| **Plan item** | PAC-13 in `02-fix-plan.md` §8 |

```php
// ChannelMaster.php:88-91 — CURRENT
    public function notificationChannels()
    {
        return $this->hasMany(NotificationChannel::class, 'channel_id');
    }
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z]+\(\)' Modules/Notification/app/Models/ChannelMaster.php Modules/Notification/app/Models/UserPreference.php
Modules/Notification/app/Models/ChannelMaster.php:88:    public function notificationChannels()
Modules/Notification/app/Models/ChannelMaster.php:93:    public function channelsUsingAsFallback()
Modules/Notification/app/Models/ChannelMaster.php:98:    public function fallbackChannel()
Modules/Notification/app/Models/ChannelMaster.php:124:    public function providers()
Modules/Notification/app/Models/ChannelMaster.php:130:    public function templates()
Modules/Notification/app/Models/ChannelMaster.php:136:    public function userPreferences()
Modules/Notification/app/Models/ChannelMaster.php:142:    public function resolvedRecipients()
Modules/Notification/app/Models/ChannelMaster.php:148:    public function deliveryQueue()
Modules/Notification/app/Models/ChannelMaster.php:154:    public function deliveryLogs()
Modules/Notification/app/Models/UserPreference.php:73:    public function user()
Modules/Notification/app/Models/UserPreference.php:78:    public function channel()
Modules/Notification/app/Models/UserPreference.php:83:    public function priorityThreshold()
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Question | index | logoutDevice | updateLanguage | updateProfile | updatePassword | updateNotificationPreferences | updateQuietHours |
|---|---|---|---|---|---|---|---|
| 1. Can a write overwrite data it should not? | ok — audit row only | ok — flags one session inactive | ok (nothing is written — PAC-02) | ok — validated fields only, guardian fields fall back to existing | ok — new hash of validated password | ok — replaces the whole set per channel, deliberate | ok — applies to all channels, deliberate per the method comment |
| 2. Anything deleted before its replacement is stored? | ok | ok | ok | ok | ok | ok (upsert, no delete) | ok |
| 3. Duplicate implementations? | ok — one path per op | ok | ok | ok | ok | ok | ok |
| 4. Soft-delete × unique trap? | ok | ok | ok | ok | ok | PAC-14 (ntf_user_preferences) | ok — `where(user_id)->update` touches only live rows |
| 5. Race? | ok | ok | ok | ok | ok | ok — upsert is a single atomic statement | ok |
| 6. Authorization hole? | ok — middleware | ok — middleware + ownership check (line 117) | ok — middleware + FormRequest | ok | ok | ok | ok |
| 7. Does any message lie? | ok | ok | PAC-02 — success flash + audit claim a persisted change that never happened | ok | ok — incorrect current password returns real error | ok | ok |
| 8. Dead feature? | ok — no | ok | ok — but persistence is a no-op (PAC-02) | ok | ok | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` (owner: ParentDashboardController) | `registerDeviceToken()` passes `device_token_webpush_json` (renamed by PAC-04) and `json_encode($webPushSubscription)` into the array-cast attribute (double-encodes when the name is right); both `registerDeviceToken()` (169) and `getOrCreateSession()` (217) pass `device_type` which is not fillable — silently dropped, can leave `device_type_option_id` NOT NULL unfilled (PAC-05). | MDL-07 / MDL-01 | dashboard report (its report is still CLAIMED) |
| `Modules/ParentPortal/app/Services/PptDropdownResolver.php` (owner: ParentPtmController) | `value()`/`id()` run an uncached `Dropdown` query per call; the ParentSession accessor multiplies this into the device-list N+1 (PAC-08 fixes the model side; memoising here would fix all callers). | SVC-05 / QRY-12 | ParentPtmController report |
| `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` (shared — 21 FormRequests) | `authorize()` catches `\Exception` and returns false, so the linked `resolveChild()` no-access redirect (`abort(redirect(...))`, an `HttpResponseException`) becomes a bare 403 instead of the intended redirect; real service errors are also masked as 403. | AUTH-02 / ERR-02 | first ParentPortal controller that audits the request base (not claimed yet) |
| `Modules/StudentProfile/app/Models/Guardian.php` (owner: gaurav/StudentProfile/StudentController) | Used only as a lookup table by this controller — no defect observed in this usage. | — | — |
| `Modules/SchoolSetup/app/Models/User.php` (common) | `sys_users` has `prefered_language` (FK id) and no `language`, which is the root cause of PAC-02; the controller's fix must respect the real column. | VAL-05 | this report (PAC-02) |

## 8. Not covered, and why

- **No tenant database was reachable** from this host (the default connection has 0 tenant tables), so live row counts, the `prefered_language` language table's id mapping, and any real upsert behaviour on `ntf_user_preferences` were **not measured** — PAC-14 is explicitly marked UNVERIFIED.
- **`ParentContextService` was not re-audited** — it is pre-assigned to the ParentDashboardController report (still CLAIMED); this report only checked how ParentAccountController uses it and recorded cross-cutting defects.
- **`PptDropdownResolver` was not re-audited** — it is pre-assigned to the ParentPtmController report; PAC-08 fixes the call site (the model accessor) only.
- **The blade was not rendered in a browser** — compile was verified by reading (no synthetic render per D4).
- **FormRequest cross-field execution** (§6 F4) was not run against a live payload because there is no tenant DB; the one cross-field rule (`email` unique) is structurally consistent with the index, and the quiet-hours rules are single-field.