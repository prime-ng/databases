# Fix Plan — ParentPortal / ParentAccountController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` | owned by `tarun/ParentPortal-done/ParentDashboardController` — EXCEPT the exact `device_token_webpush_json` line named in the ⚠ SHARED item PAC-04 |
| `Modules/StudentProfile/app/Models/Guardian.php` | owned by `gaurav/StudentProfile/StudentController` |
| `Modules/SchoolSetup/app/Models/User.php` | common app class (§4.2) — the `prefered_language` column is read, never edited here |
| `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` | shared base for 21 FormRequests |
| `Modules/ParentPortal/app/Services/PptDropdownResolver.php` | owned by `tarun/ParentPortal-done/ParentPtmController` |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | owned by the ParentHealthController report |
| `Modules/ParentPortal/routes/web.php` | route file — no route change is needed |
| `database/migrations/**` | never edit an existing migration; a migration only appears when a ticked DECISION says so, and is never run |
| `Modules/ParentPortal/resources/views/layouts/**`, `resources/views/components/**` | shared layouts/components |

## 1. Blockers reachable today

- [x] **PAC-04** · B · MDL-07 · ⚠ SHARED — rename `device_token_webpush_json` to the real column `device_token_webpush` in the model, the view, and the shared service.
  - **Why SHARED:** `Modules/ParentPortal/app/Services/ParentContextService.php` is owned by the ParentDashboardController report; this item touches exactly one of its lines.
  - **Touches:** `Modules/ParentPortal/app/Models/ParentSession.php`, `Modules/ParentPortal/resources/views/account/index.blade.php`, `Modules/ParentPortal/app/Services/ParentContextService.php`
  - **Before** (model, `ParentSession.php:21-43`):
    ```php
        'device_token_fcm',
        'device_token_apns',
        'device_token_webpush_json',
        'device_type_option_id',
        'notification_preferences_json',
        'quiet_hours_start',
        'quiet_hours_end',
        'last_active_at',
        'is_active',
        'created_by',
    ];

    protected $casts = [
        'notification_preferences_json' => 'array',
        'device_token_webpush_json'     => 'array',
        'quiet_hours_start'             => 'string',
        'quiet_hours_end'               => 'string',
        'last_active_at'                => 'datetime',
        'is_active'                     => 'boolean',
    ];
    ```
  - **After:** (model)
    ```php
        'device_token_fcm',
        'device_token_apns',
        'device_token_webpush',
        'device_type_option_id',
        'notification_preferences_json',
        'quiet_hours_start',
        'quiet_hours_end',
        'last_active_at',
        'is_active',
        'created_by',
    ];

    protected $casts = [
        'notification_preferences_json' => 'array',
        'device_token_webpush'          => 'array',
        'quiet_hours_start'             => 'string',
        'quiet_hours_end'               => 'string',
        'last_active_at'                => 'datetime',
        'is_active'                     => 'boolean',
    ];
    ```
  - **Before** (view, `index.blade.php:431`):
    ```php
    @if($device->device_token_fcm || $device->device_token_apns || $device->device_token_webpush_json)
    ```
  - **After:** (view)
    ```php
    @if($device->device_token_fcm || $device->device_token_apns || $device->device_token_webpush)
    ```
  - **Before** (service, `ParentContextService.php:163-171`):
    ```php
        $session->update(array_filter([
            'device_token_fcm'          => $fcmToken,
            'device_token_apns'         => $apnsToken,
            'device_token_webpush_json' => $webPushSubscription
                ? json_encode($webPushSubscription)
                : null,
            'device_type'               => $deviceType,
            'last_active_at'            => now(),
        ], fn ($v) => $v !== null));
    ```
  - **After:** (service — pass the array, the model's `array` cast encodes it once)
    ```php
        $session->update(array_filter([
            'device_token_fcm'          => $fcmToken,
            'device_token_apns'         => $apnsToken,
            'device_token_webpush'      => $webPushSubscription,
            'device_type'               => $deviceType,
            'last_active_at'            => now(),
        ], fn ($v) => $v !== null));
    ```
  - **Verify:** `grep -n 'device_token_webpush' Modules/ParentPortal/app/Models/ParentSession.php Modules/ParentPortal/app/Services/ParentContextService.php Modules/ParentPortal/resources/views/account/index.blade.php`
  - **Expect:** every hit is `device_token_webpush`, none is `device_token_webpush_json`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

(none — the latent soft-delete trap is a DECISION, PAC-14 in §9)

## 3. Errors & transactions (F1/F2)

- [x] **PAC-01** · H · D1 / ERR-07 / ERR-05 — replace the whole controller file with the D1 shape: no try/catch, responses built after the transaction, injected `$request` in every audit context, one `logContext()` helper for the repeated context block, and sorted imports without the unused `Password`/`ModelNotFoundException`/`HttpExceptionInterface`/`Log` imports.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php`
  - **Before** (the entire current file, 390 lines — replace it wholesale):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\ParentPortal\Http\Controllers;

    use Illuminate\Database\Eloquent\ModelNotFoundException;

    use Illuminate\Support\Facades\Log;

    use Illuminate\Support\Facades\DB;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Modules\ParentPortal\Http\Requests\LogoutDeviceParentAccountRequest;
    use Modules\ParentPortal\Http\Requests\UpdateNotificationPreferencesParentAccountRequest;
    use Modules\ParentPortal\Http\Requests\UpdateQuietHoursParentAccountRequest;
    use Modules\ParentPortal\Http\Requests\UpdateLanguageParentAccountRequest;
    use Modules\ParentPortal\Http\Requests\UpdatePasswordParentAccountRequest;
    use Modules\ParentPortal\Http\Requests\UpdateProfileParentAccountRequest;
    use Illuminate\Support\Facades\Hash;
    use Illuminate\Support\Facades\Session;
    use Illuminate\Validation\Rules\Password;
    use Illuminate\View\View;
    use Modules\Notification\Models\ChannelMaster;
    use Modules\Notification\Models\UserPreference;
    use Modules\ParentPortal\Models\ParentSession;
    use Modules\ParentPortal\Services\ParentContextService;
    use Modules\StudentProfile\Models\Guardian;
    use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;

    class ParentAccountController extends Controller
    {
        public function __construct(
            private readonly ParentContextService $context,
        ) {}

        /**
         * Account settings page — all tabs in one view.
         */
        public function index(Request $request): View|RedirectResponse
        {
            try {
                return DB::transaction(function () use ($request) {
                    $user     = $request->user();
                    $child    = $this->context->resolveChild($request);
                    $guardian = Guardian::where('user_id', $user->id)->first();

                    // Notification channels + user preferences keyed by channel_id
                    $channels    = ChannelMaster::orderBy('name')->get();
                    $preferences = UserPreference::where('user_id', $user->id)
                        ->get()
                        ->keyBy('channel_id');

                    // ── FR-18: Device sessions for this guardian ───────────────────────
                    $devices = collect();
                    if ($guardian) {
                        $devices = ParentSession::where('guardian_id', $guardian->id)
                            ->orderByDesc('last_active_at')
                            ->orderByDesc('updated_at')
                            ->get();
                    }

                    // ── FR-18: Available portal languages ──────────────────────────────
                    $languages = [
                        'en' => 'English',
                        'hi' => 'हिन्दी (Hindi)',
                        'ta' => 'தமிழ் (Tamil)',
                        'te' => 'తెలుగు (Telugu)',
                        'bn' => 'বাংলা (Bengali)',
                        'mr' => 'मराठी (Marathi)',
                        'gu' => 'ગુજરાતી (Gujarati)',
                    ];
                    $currentLanguage = Session::get('ppt_language', $user->language ?? 'en');

                    activityLog(auth()->user(), 'Viewed', [
                        'message' => 'Viewed account settings',
                        'context' => [
                            'student_id' => $child?->id,
                            'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                            'module' => 'ParentPortal',
                            'route' => request()->route()?->getName(),
                        ],
                    ]);

                    return view('parentportal::account.index', compact(
                        'user', 'child', 'guardian', 'channels', 'preferences',
                        'devices', 'languages', 'currentLanguage',
                    ));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParentAccountController::index failed', ['error' => $e->getMessage()]);

                // The declared return type is widened to View|RedirectResponse rather than
                // forcing a JSON body here: this renders a page, and its error path has always
                // been a redirect. Declared `: View` alone, that redirect was a TypeError.
                return back()->with('error', 'The operation could not be completed.');
            }
        }

        /**
         * FR-18 REQ-18.5 — Logout a specific device session.
         */
        public function logoutDevice(LogoutDeviceParentAccountRequest $request, ParentSession $device): RedirectResponse
        {
            try {
                return DB::transaction(function () use ($request, $device) {
                    $user     = $request->user();
                    $guardian = Guardian::where('user_id', $user->id)->first();

                    abort_unless($guardian && $device->guardian_id === $guardian->id, 403);

                    $device->update(['is_active' => false]);

                    activityLog(auth()->user(), 'DeviceLoggedOut', [
                        'message' => 'Logged out a device session',
                        'context' => [
                            'student_id' => null,
                            'student_name' => null,
                            'module' => 'ParentPortal',
                            'route' => request()->route()?->getName(),
                        ],
                        'device_session_id' => $device->id,
                    ]);

                    return back()->with('success', 'Device logged out successfully.');

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (HttpExceptionInterface $e) {
                // abort()/abort_unless() throw an HttpException. Without this the generic
                // catch below swallows it and a deliberate 403 becomes a redirect reading
                // "The operation could not be completed." — the guard still refuses, but the
                // parent is told the wrong thing and the log records an application failure
                // instead of an access denial. Matches the AuthorizationException|Validation
                // Exception|HttpExceptionInterface pattern already used in ParentLeaveController.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParentAccountController::logoutDevice failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }

        /**
         * FR-18 REQ-18.6 — Update preferred portal language.
         */
        public function updateLanguage(UpdateLanguageParentAccountRequest $request): RedirectResponse
        {
            $validated = $request->validated();

            Session::put('ppt_language', $validated['language']);

            // Rule A2 — the user row and the audit entry commit together. The empty catch below is
            // deliberate and predates this change: the column may not exist, and a language
            // preference is not worth failing a request over. It stays INSIDE the transaction so a
            // swallowed failure still rolls back cleanly rather than leaving a log claiming a
            // change the row never took.
            DB::transaction(function () use ($request, $validated) {
                // Persist to user if the column exists
                try {
                    $request->user()->update(['language' => $validated['language']]);
                } catch (\Throwable) {
                    // Silent fail if users table doesn't have a language column
                }

                activityLog(auth()->user(), 'LanguageUpdated', [
                    'message' => 'Updated language preference',
                    'context' => [
                        'student_id' => null,
                        'student_name' => null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                    'language' => $validated['language'],
                ]);
            });

            return back()->with('success', 'Language preference updated.');
        }

        /**
         * Update display name, email, phone on the User record.
         * Also updates guardian first/last name, mobile, occupation if guardian exists.
         */
        public function updateProfile(UpdateProfileParentAccountRequest $request): RedirectResponse
        {
            try {
                return DB::transaction(function () use ($request) {
                    $user = $request->user();

                    $data = $request->validated();

                    $user->update([
                        'name'      => $data['name'],
                        'email'     => $data['email'],
                        'mobile_no' => $data['mobile_no'] ?? $user->mobile_no,
                        'phone_no'  => $data['phone_no']  ?? $user->phone_no,
                    ]);

                    $guardian = Guardian::where('user_id', $user->id)->first();
                    if ($guardian) {
                        $guardian->update([
                            'first_name' => $data['first_name'] ?? $guardian->first_name,
                            'last_name'  => $data['last_name']  ?? $guardian->last_name,
                            'occupation' => $data['occupation']  ?? $guardian->occupation,
                            'mobile_no'  => $data['mobile_no']   ?? $guardian->mobile_no,
                            'email'      => $data['email'],
                        ]);
                    }

                    activityLog(auth()->user(), 'Updated', [
                        'message' => 'Updated profile',
                        'context' => [
                            'student_id' => null,
                            'student_name' => null,
                            'module' => 'ParentPortal',
                            'route' => request()->route()?->getName(),
                        ],
                    ]);

                    return redirect()
                        ->route('parent-portal.account.index', ['tab' => 'profile'])
                        ->with('success', 'Profile updated successfully.');

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParentAccountController::updateProfile failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }

        /**
         * Change password — requires current password verification.
         */
        public function updatePassword(UpdatePasswordParentAccountRequest $request): RedirectResponse
        {
            try {
                return DB::transaction(function () use ($request) {
                    $user = $request->user();

                    $data = $request->validated();

                    if (! Hash::check($data['current_password'], $user->password)) {
                        return back()
                            ->withErrors(['current_password' => 'The current password is incorrect.'])
                            ->with('active_tab', 'password');
                    }

                    $user->update(['password' => Hash::make($data['password'])]);

                    activityLog(auth()->user(), 'PasswordChanged', [
                        'message' => 'Changed password',
                        'context' => [
                            'student_id' => null,
                            'student_name' => null,
                            'module' => 'ParentPortal',
                            'route' => request()->route()?->getName(),
                        ],
                    ]);

                    return redirect()
                        ->route('parent-portal.account.index', ['tab' => 'password'])
                        ->with('success', 'Password changed successfully.');

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParentAccountController::updatePassword failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }

        /**
         * Toggle per-channel notification preferences.
         * Accepts: notifications[{channel_id}] = 1|0
         */
        public function updateNotificationPreferences(UpdateNotificationPreferencesParentAccountRequest $request): RedirectResponse
        {
            $user = $request->user();
            $data = $request->validated();

            $selected = $data['notifications'] ?? [];

            $channels = ChannelMaster::all();
            $now = now();
            $rows = $channels->map(function ($channel) use ($user, $selected, $now) {
                return [
                    'user_id'    => $user->id,
                    'channel_id' => $channel->id,
                    'is_enabled' => isset($selected[$channel->id]) && (bool) $selected[$channel->id],
                    'is_active'  => true,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];
            })->toArray();

            // Rule A2: the upsert writes one row PER CHANNEL plus one sys_activity_logs
            // row. Unwrapped, a failure part-way leaves the parent with some channels
            // saved and some not, and no way to tell which — on the screen that decides
            // whether they are told their child is absent.
            DB::transaction(function () use ($rows) {
                UserPreference::upsert(
                    $rows,
                    ['user_id', 'channel_id'],
                    ['is_enabled', 'is_active', 'updated_at']
                );

                activityLog(auth()->user(), 'PreferencesUpdated', [
                    'message' => 'Updated notification preferences',
                    'context' => [
                        'student_id' => null,
                        'student_name' => null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                ]);
            });

            return redirect()
                ->route('parent-portal.account.index', ['tab' => 'notifications'])
                ->with('success', 'Notification preferences saved.');
        }

        /**
         * Set quiet-hours window (applies to all channels for simplicity).
         */
        public function updateQuietHours(UpdateQuietHoursParentAccountRequest $request): RedirectResponse
        {
            try {
                return DB::transaction(function () use ($request) {
                    $user = $request->user();

                    $data = $request->validated();

                    $start = $data['quiet_hours_start'] ? $data['quiet_hours_start'] . ':00' : null;
                    $end   = $data['quiet_hours_end']   ? $data['quiet_hours_end']   . ':00' : null;

                    // Apply quiet hours to all existing preference rows for this user
                    UserPreference::where('user_id', $user->id)->update([
                        'quiet_hours_start' => $start,
                        'quiet_hours_end'   => $end,
                    ]);

                    activityLog(auth()->user(), 'QuietHoursUpdated', [
                        'message' => 'Updated quiet hours',
                        'context' => [
                            'student_id' => null,
                            'student_name' => null,
                            'module' => 'ParentPortal',
                            'route' => request()->route()?->getName(),
                        ],
                        'quiet_hours_start' => $start,
                        'quiet_hours_end' => $end,
                    ]);

                    return redirect()
                        ->route('parent-portal.account.index', ['tab' => 'notifications'])
                        ->with('success', 'Quiet hours updated.');

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParentAccountController::updateQuietHours failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    }
    ```
  - **After:** (replace the entire file with the D1 shape below; `updateLanguage` is rewritten to the D1 shape too, but the persistence choice stays a placeholder — PAC-02 decides it, so keep `prefered_language` write only if PAC-02's choice (a) is taken; otherwise revert the write to a comment)
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\ParentPortal\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Hash;
    use Illuminate\Support\Facades\Session;
    use Illuminate\View\View;
    use Modules\Notification\Models\ChannelMaster;
    use Modules\Notification\Models\UserPreference;
    use Modules\ParentPortal\Http\Requests\LogoutDeviceParentAccountRequest;
    use Modules\ParentPortal\Http\Requests\UpdateLanguageParentAccountRequest;
    use Modules\ParentPortal\Http\Requests\UpdateNotificationPreferencesParentAccountRequest;
    use Modules\ParentPortal\Http\Requests\UpdatePasswordParentAccountRequest;
    use Modules\ParentPortal\Http\Requests\UpdateProfileParentAccountRequest;
    use Modules\ParentPortal\Http\Requests\UpdateQuietHoursParentAccountRequest;
    use Modules\ParentPortal\Models\ParentSession;
    use Modules\ParentPortal\Services\ParentContextService;
    use Modules\StudentProfile\Models\Guardian;

    class ParentAccountController extends Controller
    {
        public function __construct(
            private readonly ParentContextService $context,
        ) {}

        /**
         * Account settings page — all tabs in one view.
         *
         * D1/D2: no try/catch in a controller. DB::transaction() rolls back by itself
         * and the central handler in bootstrap/app.php renders errors. (PAC-01, 2026-10-13)
         */
        public function index(Request $request): View
        {
            $user     = $request->user();
            $child    = $this->context->resolveChild($request);
            $guardian = Guardian::where('user_id', $user->id)->first();

            // Notification channels + user preferences keyed by channel_id
            $channels    = ChannelMaster::orderBy('name')->get();
            $preferences = UserPreference::where('user_id', $user->id)
                ->get()
                ->keyBy('channel_id');

            // FR-18: Device sessions for this guardian
            $devices = collect();
            if ($guardian) {
                $devices = ParentSession::where('guardian_id', $guardian->id)
                    ->orderByDesc('last_active_at')
                    ->orderByDesc('updated_at')
                    ->get();
            }

            // FR-18: Available portal languages
            $languages = [
                'en' => 'English',
                'hi' => 'हिन्दी (Hindi)',
                'ta' => 'தமிழ் (Tamil)',
                'te' => 'తెలుగు (Telugu)',
                'bn' => 'বাংলা (Bengali)',
                'mr' => 'मराठी (Marathi)',
                'gu' => 'ગુજરાતી (Gujarati)',
            ];
            $currentLanguage = Session::get('ppt_language', $user->language ?? 'en');

            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed account settings',
                'context' => $this->logContext(
                    $request,
                    $child?->id,
                    $child?->user?->name ?? $child?->full_name ?? null,
                ),
            ]);

            return view('parentportal::account.index', compact(
                'user', 'child', 'guardian', 'channels', 'preferences',
                'devices', 'languages', 'currentLanguage',
            ));
        }

        /**
         * FR-18 REQ-18.5 — Logout a specific device session.
         */
        public function logoutDevice(LogoutDeviceParentAccountRequest $request, ParentSession $device): RedirectResponse
        {
            $user     = $request->user();
            $guardian = Guardian::where('user_id', $user->id)->first();

            abort_unless($guardian && $device->guardian_id === $guardian->id, 403);

            DB::transaction(function () use ($request, $device) {
                $device->update(['is_active' => false]);

                activityLog(auth()->user(), 'DeviceLoggedOut', [
                    'message' => 'Logged out a device session',
                    'context' => $this->logContext($request, null, null),
                    'device_session_id' => $device->id,
                ]);
            });

            return back()->with('success', 'Device logged out successfully.');
        }

        /**
         * FR-18 REQ-18.6 — Update preferred portal language.
         *
         * PAC-02 decides how (or whether) the preference is persisted on sys_users:
         * the real column is `prefered_language` (FK to glb_languages), not a `language`
         * code column. Choice (a) maps the code to an id; the write below is a placeholder
         * that must be replaced per the ticked choice. (PAC-02, 2026-10-13)
         */
        public function updateLanguage(UpdateLanguageParentAccountRequest $request): RedirectResponse
        {
            $validated = $request->validated();

            Session::put('ppt_language', $validated['language']);

            DB::transaction(function () use ($request, $validated) {
                // PAC-02 (a): map $validated['language'] to a glb_languages id and write it here.

                activityLog(auth()->user(), 'LanguageUpdated', [
                    'message' => 'Updated language preference',
                    'context' => $this->logContext($request, null, null),
                    'language' => $validated['language'],
                ]);
            });

            return back()->with('success', 'Language preference updated.');
        }

        /**
         * Update display name, email, phone on the User record.
         * Also updates guardian first/last name, mobile, occupation if guardian exists.
         */
        public function updateProfile(UpdateProfileParentAccountRequest $request): RedirectResponse
        {
            $data = $request->validated();

            DB::transaction(function () use ($request, $data) {
                $user = $request->user();

                $user->update([
                    'name'      => $data['name'],
                    'email'     => $data['email'],
                    'mobile_no' => $data['mobile_no'] ?? $user->mobile_no,
                    'phone_no'  => $data['phone_no']  ?? $user->phone_no,
                ]);

                $guardian = Guardian::where('user_id', $user->id)->first();
                if ($guardian) {
                    $guardian->update([
                        'first_name' => $data['first_name'] ?? $guardian->first_name,
                        'last_name'  => $data['last_name']  ?? $guardian->last_name,
                        'occupation' => $data['occupation']  ?? $guardian->occupation,
                        'mobile_no'  => $data['mobile_no']   ?? $guardian->mobile_no,
                        'email'      => $data['email'],
                    ]);
                }

                activityLog(auth()->user(), 'Updated', [
                    'message' => 'Updated profile',
                    'context' => $this->logContext($request, null, null),
                ]);
            });

            return redirect()
                ->route('parent-portal.account.index', ['tab' => 'profile'])
                ->with('success', 'Profile updated successfully.');
        }

        /**
         * Change password — requires current password verification.
         */
        public function updatePassword(UpdatePasswordParentAccountRequest $request): RedirectResponse
        {
            $data = $request->validated();

            if (! Hash::check($data['current_password'], $request->user()->password)) {
                return back()
                    ->withErrors(['current_password' => 'The current password is incorrect.'])
                    ->with('active_tab', 'password');
            }

            DB::transaction(function () use ($request, $data) {
                $request->user()->update(['password' => Hash::make($data['password'])]);

                activityLog(auth()->user(), 'PasswordChanged', [
                    'message' => 'Changed password',
                    'context' => $this->logContext($request, null, null),
                ]);
            });

            return redirect()
                ->route('parent-portal.account.index', ['tab' => 'password'])
                ->with('success', 'Password changed successfully.');
        }

        /**
         * Toggle per-channel notification preferences.
         * Accepts: notifications[{channel_id}] = 1|0
         */
        public function updateNotificationPreferences(UpdateNotificationPreferencesParentAccountRequest $request): RedirectResponse
        {
            $user = $request->user();
            $data = $request->validated();

            $selected = $data['notifications'] ?? [];

            $channels = ChannelMaster::all();
            $now = now();
            $rows = $channels->map(function ($channel) use ($user, $selected, $now) {
                return [
                    'user_id'    => $user->id,
                    'channel_id' => $channel->id,
                    'is_enabled' => isset($selected[$channel->id]) && (bool) $selected[$channel->id],
                    'is_active'  => true,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];
            })->toArray();

            // Rule A2 (PAC-14): the upsert writes one row PER CHANNEL plus one
            // sys_activity_logs row. Unwrapped, a failure part-way leaves the parent
            // with some channels saved and some not, and no way to tell which.
            DB::transaction(function () use ($request, $rows) {
                UserPreference::upsert(
                    $rows,
                    ['user_id', 'channel_id'],
                    ['is_enabled', 'is_active', 'updated_at']
                );

                activityLog(auth()->user(), 'PreferencesUpdated', [
                    'message' => 'Updated notification preferences',
                    'context' => $this->logContext($request, null, null),
                ]);
            });

            return redirect()
                ->route('parent-portal.account.index', ['tab' => 'notifications'])
                ->with('success', 'Notification preferences saved.');
        }

        /**
         * Set quiet-hours window (applies to all channels for simplicity).
         */
        public function updateQuietHours(UpdateQuietHoursParentAccountRequest $request): RedirectResponse
        {
            $user = $request->user();
            $data = $request->validated();

            $start = $data['quiet_hours_start'] ? $data['quiet_hours_start'] . ':00' : null;
            $end   = $data['quiet_hours_end']   ? $data['quiet_hours_end']   . ':00' : null;

            DB::transaction(function () use ($user, $request, $start, $end) {
                // Apply quiet hours to all existing preference rows for this user
                UserPreference::where('user_id', $user->id)->update([
                    'quiet_hours_start' => $start,
                    'quiet_hours_end'   => $end,
                ]);

                activityLog(auth()->user(), 'QuietHoursUpdated', [
                    'message' => 'Updated quiet hours',
                    'context' => $this->logContext($request, null, null),
                    'quiet_hours_start' => $start,
                    'quiet_hours_end' => $end,
                ]);
            });

            return redirect()
                ->route('parent-portal.account.index', ['tab' => 'notifications'])
                ->with('success', 'Quiet hours updated.');
        }

        /**
         * Standard audit context shared by every method of this controller.
         */
        private function logContext(Request $request, ?int $studentId, ?string $studentName): array
        {
            return [
                'student_id'   => $studentId,
                'student_name' => $studentName,
                'module'       => 'ParentPortal',
                'route'        => $request->route()?->getName(),
            ];
        }
    }
    ```
  - **Verify:** `php -l Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php` then `grep -n 'try {\|catch (\|getMessage\|request()->route\|Password' Modules/ParentPortal/app/Http/Controllers/ParentAccountController.php`
  - **Expect:** `php -l` has no syntax errors; the greps return nothing (no try/catch, no getMessage, no request() helper, no unused Password import).
  - **Effort:** S

## 4. Authorization (F3)

(none — see report §6 F3: middleware + FormRequest + record-ownership check are clean)

## 5. Validation, routes, models (F4/F5/F7)

(none — the validation/routes are clean; the model defects are PAC-04 §1 and PAC-05 §9)

## 6. Queries & performance (F9)

- [x] **PAC-08** · M · VIEW-02 / QRY-01 — memoise the device-type dropdown lookup inside the accessor so the two view calls per row stop querying the DB twice.
  - **Touches:** `Modules/ParentPortal/app/Models/ParentSession.php`
  - **Before** (`ParentSession.php:67-73`):
    ```php
    public function getDeviceTypeAttribute(): ?string
    {
        return PptDropdownResolver::value($this->attributes['device_type_option_id'] ?? null) ?? 'Unknown';
    }
    ```
  - **After:**
    ```php
    public function getDeviceTypeAttribute(): ?string
    {
        static $values = [];

        $id = $this->attributes['device_type_option_id'] ?? null;
        if ($id === null) {
            return 'Unknown';
        }
        if (array_key_exists($id, $values)) {
            return $values[$id];
        }

        return $values[$id] = PptDropdownResolver::value($id) ?? 'Unknown';
    }
    ```
  - **Verify:** `grep -n 'static $values\|array_key_exists' Modules/ParentPortal/app/Models/ParentSession.php`
  - **Expect:** both lines present; the accessor no longer calls `Dropdown::find` per invocation.
  - **Effort:** S

## 7. Views (F10)

(none — the view is clean; the one N+1 is fixed by PAC-08, and the column rename by PAC-04)

## 8. Style (F12) — one item per file

- [x] **PAC-10** · L · STY-01 — add `declare(strict_types=1);` after `<?php` in eight files (the six account FormRequests, `ChannelMaster`, `UserPreference`).
  - **Touches:** `Modules/ParentPortal/app/Http/Requests/LogoutDeviceParentAccountRequest.php`, `Modules/ParentPortal/app/Http/Requests/UpdateLanguageParentAccountRequest.php`, `Modules/ParentPortal/app/Http/Requests/UpdateNotificationPreferencesParentAccountRequest.php`, `Modules/ParentPortal/app/Http/Requests/UpdatePasswordParentAccountRequest.php`, `Modules/ParentPortal/app/Http/Requests/UpdateProfileParentAccountRequest.php`, `Modules/ParentPortal/app/Http/Requests/UpdateQuietHoursParentAccountRequest.php`, `Modules/Notification/app/Models/ChannelMaster.php`, `Modules/Notification/app/Models/UserPreference.php`
  - **Before** (representative — `LogoutDeviceParentAccountRequest.php:1-4`, identical in the other seven):
    ```php
    <?php

    namespace Modules\ParentPortal\Http\Requests;
    ```
  - **After:** (apply this two-line insert to all eight files; `ChannelMaster.php` and `UserPreference.php` open with `<?php` + blank + `namespace Modules\Notification\Models;`)
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\ParentPortal\Http\Requests;
    ```
  - **Verify:** `grep -rn 'declare(strict_types=1)' Modules/ParentPortal/app/Http/Requests/ Modules/Notification/app/Models/ChannelMaster.php Modules/Notification/app/Models/UserPreference.php`
  - **Expect:** all eight files listed in the grep output.
  - **Effort:** S

- [x] **PAC-12** · L · STY-04 — strip emoji/box-drawing from comments in the two claimed models.
  - **Touches:** `Modules/Notification/app/Models/UserPreference.php`, `Modules/ParentPortal/app/Models/ParentSession.php`
  - **Before** (`UserPreference.php:133`):
    ```php
     * ⚠ Timezone: this compares against the application's current time, NOT
    ```
  - **After:**
    ```php
     * Note: this compares against the application's current time, NOT
    ```
  - **Before** (`ParentSession.php:45`, same pattern at 85 and 92):
    ```php
    // ── Relationships ────────────────────────────────────────────────────────
    ```
  - **After:**
    ```php
    // Relationships
    ```
  - **Verify:** `grep -n '──\|⚠' Modules/Notification/app/Models/UserPreference.php Modules/ParentPortal/app/Models/ParentSession.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **PAC-13** · L · MDL-04 — add return types to the fifteen relationship methods in `ChannelMaster` and `UserPreference`.
  - **Touches:** `Modules/Notification/app/Models/ChannelMaster.php`, `Modules/Notification/app/Models/UserPreference.php`
  - **Before** (`ChannelMaster.php:88-98`):
    ```php
    public function notificationChannels()
    {
        return $this->hasMany(NotificationChannel::class, 'channel_id');
    }

    public function channelsUsingAsFallback()
    {
        return $this->hasMany(self::class, 'fallback_channel_id');
    }

    public function fallbackChannel()
    {
        return $this->belongsTo(self::class, 'fallback_channel_id');
    }
    ```
  - **After:**
    ```php
    public function notificationChannels(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(NotificationChannel::class, 'channel_id');
    }

    public function channelsUsingAsFallback(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(self::class, 'fallback_channel_id');
    }

    public function fallbackChannel(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(self::class, 'fallback_channel_id');
    }
    ```
  - **After:** (Block 2 — the six doc-commented relations at `ChannelMaster.php:124-157`; add the same return types)
    ```php
    public function providers(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(ProviderMaster::class, 'channel_id');
    }

    public function templates(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(NotificationTemplate::class, 'channel_id');
    }

    public function userPreferences(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(UserPreference::class, 'channel_id');
    }

    public function resolvedRecipients(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(ResolvedRecipient::class, 'channel_id');
    }

    public function deliveryQueue(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(DeliveryQueue::class, 'channel_id');
    }

    public function deliveryLogs(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(NotificationDeliveryLog::class, 'channel_id');
    }
    ```
  - **Before** (`UserPreference.php:73-86`):
    ```php
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function channel()
    {
        return $this->belongsTo(ChannelMaster::class, 'channel_id');
    }

    public function priorityThreshold()
    {
        return $this->belongsTo(Dropdown::class, 'priority_threshold_id');
    }
    ```
  - **After:**
    ```php
    public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function channel(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(ChannelMaster::class, 'channel_id');
    }

    public function priorityThreshold(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Dropdown::class, 'priority_threshold_id');
    }
    ```
  - **Verify:** `grep -nE 'public function (notificationChannels|channelsUsingAsFallback|fallbackChannel|providers|templates|userPreferences|resolvedRecipients|deliveryQueue|deliveryLogs|user|channel|priorityThreshold)\(' Modules/Notification/app/Models/ChannelMaster.php Modules/Notification/app/Models/UserPreference.php`
  - **Expect:** every line ends with a `: \Illuminate\Database\Eloquent\Relations\...` return type.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **PAC-02** · H · DECISION · ERR-06 — how should the portal language preference be persisted on `sys_users`?
  - **Why it is a decision:** the real column is `prefered_language` (an `unsignedInteger` FK to `glb_languages`); the controller stores a code string (`'en'`). Mapping code → id needs a loader Tarun confirms, and today's write is a silent no-op behind an empty catch.
  - (a) ⭐ Persist properly: map the language code to a `glb_languages` id, remove the inner `try/catch`, and write `['prefered_language' => $id]`. Needs a small lookup (dropdown/global language table) that the fixer cannot guess — Tarun names the source, or approves the `glb_languages` view-based lookup by code.
  - (b) Keep the preference session-only: delete the `DB::transaction` user write and the audit `'language'` context key so the audit stops claiming a persisted change.
  - (c) Add a new additive migration that introduces a `language` varchar column on `sys_users` (migration never run here; diverges from the DDL).
  - ➜ Choice: (b) — session-only language preference 2026-10-22

- [x] **PAC-05** · M · DECISION · MDL-01 / MDL-02 — how should `device_type` map to the table?
  - **Why it is a decision:** the tenant migration created `device_type_option_id` (NOT NULL FK to `sys_dropdown_table`), the canonical DDL declares `device_type ENUM('Android','iOS','Web','Unknown')`, and the model's virtual `device_type` mutator is unreachable because the key is not in `$fillable`.
  - (a) ⭐ Keep the dropdown-FK design: add `'device_type'` to `ParentSession::$fillable` (the existing mutator then resolves `device_type_option_id`) and add `'device_type_option_id' => 'integer'` to `$casts`. Requires `PptDropdownResolver::id('ppt_parent_sessions.device_type', ...)` to return a real row for every value; the ParentContextService must keep passing `device_type`. No migration.
  - (b) Align to the DDL: write a new additive migration converting `device_type_option_id` to `device_type ENUM` (migration never run here), drop the accessor/mutator indirection, and update the service to pass the enum string directly.
  - (c) Leave as-is; record as accepted (the session-create path can fail in the linked service).
  - ➜ Choice: (a) — keep the dropdown-FK device type 2026-10-22

- [x] **PAC-14** · M · DECISION · MDL-03 / VAL-04 — what should `updateNotificationPreferences()` do about soft-deleted preference rows?
  - **Why it is a decision:** `ntf_user_preferences` has `deleted_at` plus a hard unique `(user_id, channel_id)`; an upsert updates a trashed row and the parent's save silently stays invisible. No in-scope caller soft-deletes preferences today (UNVERIFIED).
  - (a) ⭐ Resurrect before upserting: inside the existing transaction, add `UserPreference::onlyTrashed()->where('user_id', $user->id)->restore();` just before the `upsert` (restore clears `deleted_at` on the same row that already holds the unique key, so no duplicate is created).
  - (b) Remove the trap at the schema level: a DECISION for the Notification module to stop soft-deleting preferences (out of this plan's file list).
  - (c) Leave as-is; record as accepted if the team confirms no preference row is ever soft-deleted.
  - ➜ Choice: (a) — restore soft-deleted rows before upsert 2026-10-22

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PAC-03 | Covered by plan item PAC-01: the rewrite moves every `redirect()`/`back()` response after the `DB::transaction(...)` closure (TXN-05). |
| PAC-06 | Covered by plan item PAC-01: the six copy-pasted activityLog context arrays become the single `logContext()` helper (CTL-05). |
| PAC-07 | Covered by plan item PAC-01: every `request()->route()` becomes the injected `$request->route()` (CTL-08). |
| PAC-11 | Covered by plan item PAC-01: the After block carries sorted, single-line imports without the unused `Password`/`ModelNotFoundException`/`HttpExceptionInterface`/`Log` imports (STY-02 / CTL-10). |