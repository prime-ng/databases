# ParentPortal — Module Summary

Protocol: `.claude/rules/final-audit.md` §13.2 · Audited 2026-10-13 · Developer folder: `tarun/` · By: opencode

## Table

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| ParentDashboardController | 286 | 2 | 5 | 9 | 3 | 4 | switch-child leaks raw exception text; shared `ParentContextService` has a device_type NOT-NULL crash. | [01-report](ParentDashboardController-done/01-report.md) |
| ParentDashboardApiController | 112 | 0 | 2 | 3 | 1 | 1 | `roll_number` reads a column that does not exist; attendance % excludes Half Day/Short Leave. | [01-report](ParentDashboardApiController-done/01-report.md) |
| ParentPtmController | 495 | 1 | 5 | 6 | 10 | 2 | `book()`/`reschedule()` flash `$e->getMessage()` — raw SQL to the parent. | [01-report](ParentPtmController-done/01-report.md) |
| ParentPtmApiController | 319 | 1 | 6 | 3 | 2 | 1 | `book()`/`reschedule()` return `$e->getMessage()` — raw SQL to the mobile client. | [01-report](ParentPtmApiController-done/01-report.md) |
| ParentTimetableController | 523 | 0 | 1 | 6 | 3 | 2 | 476-line `index()` method — every timetable edit is risky. | [01-report](ParentTimetableController-done/01-report.md) |
| ParentDocumentController | 516 | 3 | 2 | 8 | 3 | 2 | `store()` mass-assigns keys not in `$fillable` — every duplicate-doc request fails. | [01-report](ParentDocumentController-done/01-report.md) |
| ParentLeaveController | 462 | 0 | 2 | 9 | 3 | 3 | `activityLog()` outside every `LeaveService` transaction — writes can silently diverge. | [01-report](ParentLeaveController-done/01-report.md) |
| ParentLeaveApiController | 141 | 0 | 2 | 4 | 3 | 1 | `activityLog()` outside the `LeaveService` transaction (same as web). | [01-report](ParentLeaveApiController-done/01-report.md) |
| ParentAccountController | 390 | 1 | 2 | 5 | 5 | 3 | `device_token_webpush_json` vs `device_token_webpush` column — web-push can never enable. | [01-report](ParentAccountController-done/01-report.md) |
| ParentComplaintController | 381 | 2 | 6 | 4 | 3 | 2 | `store()` uses undefined `$child` — every complaint submission fails. | [01-report](ParentComplaintController-done/01-report.md) |
| ParentEventController | 343 | 1 | 2 | 5 | 5 | 1 | `rsvp_status` not in `$fillable` — every RSVP fails the NOT NULL column. | [01-report](ParentEventController-done/01-report.md) |
| ParentFeeController | 303 | 0 | 2 | 8 | 5 | 2 | N+1 receipt lookup per transaction over 3,833 rows. | [01-report](ParentFeeController-done/01-report.md) |
| ParentFeePaymentController | 210 | 1 | 3 | 8 | 2 | 2 | `initiate()` returns `$e->getMessage()` — raw exception text to the parent's app. | [01-report](ParentFeePaymentController-done/01-report.md) |
| ParentConsentFormController | 259 | 1 | 2 | 9 | 3 | 2 | `ConsentFormResponse::$fillable` omits `response` — no consent form can ever be signed. | [01-report](ParentConsentFormController-done/01-report.md) |
| ParentResultController | 257 | 1 | 1 | 4 | 8 | 3 | Report-card PDF can serve the school's **unpublished** result. | [01-report](ParentResultController-done/01-report.md) |
| ParentAttendanceController | 226 | 0 | 1 | 2 | 3 | 1 | Attendance % counts Half Day/Short Leave in no bucket. | [01-report](ParentAttendanceController-done/01-report.md) |
| ParentAttendanceApiController | 84 | 0 | 1 | 1 | 2 | 1 | Same Half Day/Short Leave defect in the API summary. | [01-report](ParentAttendanceApiController-done/01-report.md) |
| ParentHostelController | 131 | 1 | 2 | 3 | 1 | 3 | Whole page in a non-D1 try/transaction; InteractsWithMedia without getMediaModel. | [01-report](ParentHostelController-done/01-report.md) |
| ParentLearningController | 146 | 1 | 0 | 4 | 7 | 0 | Quiz/quest attempt lookup queries dropped column `assessment_id` — page 500s. | [01-report](ParentLearningController-done/01-report.md) |
| ParentTeacherController | 122 | 0 | 0 | 4 | 1 | 1 | audit catch pre-D1; header term reads nonexistent `academicTerm` relation. | [01-report](ParentTeacherController-done/01-report.md) |
| ParentHomeworkController | 121 | 2 | 1 | 5 | 5 | 1 | show view reads `$homework` never passed — page always 500s; media leak. | [01-report](ParentHomeworkController-done/01-report.md) |
| ParentNotificationController | 110 | 0 | 0 | 4 | 1 | 0 | mark-all-read issues one UPDATE per notification instead of a bulk UPDATE. | [01-report](ParentNotificationController-done/01-report.md) |
| ParentBehaviourController | 98 | 0 | 1 | 2 | 2 | 0 | read-only page wraps body in try/catch → silent redirect, trace lost. | [01-report](ParentBehaviourController-done/01-report.md) |
| ParentTransportController | 89 | 0 | 0 | 4 | 6 | 2 | audit write in non-D2 try/catch — failure swallowed, trace lost. | [01-report](ParentTransportController-done/01-report.md) |
| ParentSessionApiController | 96 | 1 | 2 | 2 | 1 | 0 | `catch (\Throwable)` returns `$e->getMessage()` with 422 — leaks SQL. | [01-report](ParentSessionApiController-done/01-report.md) |
| MobileParentController | 284 | 0 | 3 | 7 | 2 | 2 | mobile group has NO parent gate — any authenticated user reaches it. | [01-report](MobileParentController-done/01-report.md) |
| MobileParentSessionController | 49 | 1 | 1 | 0 | 1 | 0 | catch returns `$e->getMessage()`; two writes with no transaction. | [01-report](MobileParentSessionController-done/01-report.md) |
| ParentOtpAuthController | 197 | 1 | 2 | 7 | 1 | 3 | OTP SMS dispatch inside open transaction; public OTP routes unthrottled. | [01-report](ParentOtpAuthController-done/01-report.md) |
| ParentPortalController | 58 | 0 | 0 | 2 | 2 | 0 | Whole controller is unrouted dead scaffold (D5 rewrite). | [01-report](ParentPortalController-done/01-report.md) |
| **Module total** | **5,814** | **21** | **59** | **138** | **96** | **45** | 314 findings · 30 controllers | |

## Module totals

- **30 controllers, 5,814 lines.** Findings: **B 21 · H 59 · M 138 · L 96** = 314, plus **45 DECISION items**.
- No application code was changed by this audit (D4: read-only).

## Cross-controller families — the same defect in N controllers (fix once)

| # | Defect | N | Controllers | Rule |
|---|---|---|---|---|
| 1 | **`$e->getMessage()` reaches the user / client** — raw SQL or model text on any DB error (ERR-01) | 9 | Dashboard, Ptm(web+api), FeePayment, SessionApi, MobileParentSession, Document, Leave(web+api) | ERR-01 (B) — fix as ONE sweep: fixed message + `report($e)` per D2 |
| 1b | **Failures logged as bare `getMessage()` only — stack trace lost** (ERR-05) | ~18 | Teacher, Transport, Behaviour, Hostel, Tt, Fee, Homework, Result, Event, Consent, Dashboard, Complaints, OtpAuth, Ptm(web+api), Leave(web+api) | ERR-05 (M) — include with the same sweep (same file, same lines) |
| 2 | **Pre-D1 `try/catch (\Throwable)` wrapping a read or write** — swallows trace, can mis-route an intended abort | 18 | Health, Transport, Behaviour, Hostel, Teacher, Account, Attendance, Dashboard, Ptm, Fee, Document, Result, Homework, Event, Complaint, SessionApi, Leave(web+api) | D1 / ERR-07 — remove or narrow to D2 shapes |
| 3 | **`activityLog()` / audit row committed OUTSIDE the write transaction** | 4 | Leave(web+api), Transport, FeePayment | TXN-01 — put audit inside the transaction |
| 4 | **`InteractsWithMedia` model without `getMediaModel()`** — media rows go to the **central** DB | 6 | Hostel models, Homework, HomeworkSubmission, HpcReport, ParentDocumentRequest, Guardian(cross-module) | TEN-01 (latent cross-tenant leak) |
| 5 | **Mass assignment omits a key the create path needs** — silent drop → NOT NULL violation → feature fully broken | 4 | ConsentFormResponse (`response`), EventRsvp (`rsvp_status`), ParentDocumentRequest (`document_type/urgency/status`), ParentSession (`device_type`) | VAL-01/MDL-01 (B, feature-killer) |
| 6 | **Attendance % counts wrong status literals** (`P`/`A`/`L`) and excludes `Half Day`/`Short Leave` | 5 | Attendance(web+api), Dashboard(web+api), MobileParent | QRY/VAL — one DECISION to standardise, apply on all five surfaces |
| 7 | **`device_token_webpush_json` vs `device_token_webpush` column** | 3 | Account, SessionApi, Dashboard (via ParentSession) | MDL-02 — one model fix covers all |
| 8 | **Unrouted / dead code** | 2 | ParentPortalController (all methods), Dashboard `children` vs API dupes | D5 / CTL-10 |

## Shared classes and their owner reports

| Class | Owner report |
|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` (26 users — the module's context spine) | [ParentDashboardController](ParentDashboardController-done/01-report.md) |
| `Modules/ParentPortal/app/Models/ParentSession.php` | [ParentAccountController](ParentAccountController-done/01-report.md) |
| `Modules/ParentPortal/app/Services/ParentOtpService.php`, `Models/ParentOtpAttempt.php` | [ParentOtpAuthController](ParentOtpAuthController-done/01-report.md) |
| `Models/ConsentForm.php`, `ConsentFormResponse.php`, `Policies/ConsentFormPolicy.php` | [ParentConsentFormController](ParentConsentFormController-done/01-report.md) |
| `Models/Event.php`, `EventRsvp.php` | [ParentEventController](ParentEventController-done/01-report.md) |
| `Models/ParentDocumentRequest.php` | [ParentDocumentController](ParentDocumentController-done/01-report.md) |
| `Services/PptDropdownResolver.php`, `Modules/Ptm/*` (PtmEvent/PtmSlot/PtmSlotBooking/PtmBlockout [+PtmAssignment, PtmEventClassSection]) | [ParentPtmController](ParentPtmController-done/01-report.md) |
| `Modules/Payment/*` (Payment, PaymentService, GatewayManager, gateways, listeners, events) | [ParentFeePaymentController](ParentFeePaymentController-done/01-report.md) |
| `Modules/StudentFee/*` (FeeInvoice, FeeReceipt, FeeStudentAssignment, FeeInvoiceService) | [ParentFeeController](ParentFeeController-done/01-report.md) |
| `Modules/Hpc/Models/HpcReport.php`, `Modules/StudentPortal/Models/ExamResult.php` | [ParentResultController](ParentResultController-done/01-report.md) |
| `Modules/LmsHomework/*` (Homework, HomeworkSubmission, HomeworkAssignment) | [ParentHomeworkController](ParentHomeworkController-done/01-report.md) |
| `Modules/Complaint/*`, `ParentPortalBaseRequest` | [ParentComplaintController](ParentComplaintController-done/01-report.md) |
| `Modules/Hostel/*` (8 models), `BaPortalService` | [ParentHostelController](ParentHostelController-done/01-report.md) / [ParentBehaviourController](ParentBehaviourController-done/01-report.md) |
| `Modules/Transport/Models/TptStudentAllocationJnt.php` | [ParentTransportController](ParentTransportController-done/01-report.md) |
| `Modules/LmsQuiz`/`LmsQuests` allocations; `Store/WithdrawParentLeaveRequest` | [ParentLearningController](ParentLearningController-done/01-report.md) / [ParentLeaveApiController](ParentLeaveApiController-done/01-report.md) |
| Cross-module already owned (linked, not re-audited): `StudentProfile/*` → gaurav/StudentProfile reports; `LmsExam/*`, `ExamAllocation` → shailesh/LmsExam reports; `TimetableFoundation/*` → TimetableFoundation reports; `Notification::*` → ParentAccountController. | |

## Module-wide decisions (need Tarun's choice before the fixer runs)

1. **Half Day / Short Leave attendance rule** — the same DECISION appears in PAT-05, PDAS-02, PAA-02, MPC-10, and Dashboard. Pick ONE answer; apply it on all five surfaces.
2. **ParentContextService `resolveChild()` shape** — PCS-01 (read-only?), PCS-03 (no-children redirect) in the Dashboard report affect all 26 consumers.
3. **`ParentSession` model halves** — PAC-04/PAC-05 vs the SessionApi/MobileParentSession reports; fix once in the Account model.
4. **PTM booking duplication** — web vs API book/reschedule logic (PPTM-09 / PPTC): extract a shared service now, or accept divergence (deferred split per D3).
5. **Media-model sweep (TEN-01)** — the 6 models listed in family 4 fix as one change; each needs `getMediaModel()`.

## Hand-back

Reports live at `final-audit-reports/tarun/ParentPortal/<Controller>/`. Tick items in each `02-fix-plan.md` (45 DECISIONs need a `➜ Choice:`), then run the fixer per controller.
## Fix pass — 2026-10-22

All 30 controllers were applied against their `02-fix-plan.md` and moved to `<Controller>-done/`
with a `03-status.md` ledger (protocol §10.1). No tests were run (D4).

- **Applied:** all mechanical items across errors/D1, transactions, validation, routes/models, queries, views and style, plus the module-wide attendance rule (Present + Late + Half Day + Short Leave count as present).
- **Shared fixes landed:** `ParentContextService` (device token column, read-only child resolution), `ParentSession`, LmsHomework/Ptm/Hpc/Hostel/Transport/Fee/Payment/Notification models, `ParentPortalBaseRequest`, and the Hpc Published-report filter.
- **Accepted/deferred by decision:** shared `ChatService`-style exception conversions were kept as-is where they cross report ownership; PTM/ParentTimetable/ParentLeave structural splits remain deferred (D3); the volunteer-capacity race and duplicate payment-credit path are accepted.
- **Needs Tarun:** no migration or seeder was added. Two Ptm admin blades were adjusted for the new string time casts (regression guard), outside the audit's original file list.
- **Caveat:** no browser/device check was run; verification is `php -l`, `class_exists`, `route:list` + `method_exists`, Blade compile and Pint.
