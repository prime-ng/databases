# Final Audit — ParentPortal / ParentFeeController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php` (303 lines, 5 public methods plus the constructor)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/parent-portal/fees` (fee summary) · `.../fees/history` (payment history) · `.../fees/invoice/{invoice}` (one invoice) · `.../fees/receipt/{receipt}` (one receipt) · `.../fees/invoice/{invoice}/download` (invoice PDF) |
| Menu path | Parent Portal → Fees → (Fee Summary / Payment History / Invoice / Receipt) |
| Who uses it | A logged-in parent: `user_type = PARENT`, with a `std_guardians` row and at least one linked child whose `can_access_parent_portal = 1` (enforced by `ParentPortalMiddleware`, not by a permission key). |
| What a user does here | A parent picks one of their children and reads that child's fee position: how much was billed, how much is paid, how much is due, and whether anything is overdue. They open a single invoice or a receipt, and they can download a single invoice as a PDF. Nothing on this controller creates or changes fee data — it is a read-only portal, plus an audit row in `sys_activity_logs` each time a page is viewed. |
| Tables written | `sys_activity_logs` (through the global `activityLog()` helper) — every method. No fee table is written. |
| Tables read | `fee_student_assignments`, `fee_invoices`, `fee_installments`, `fee_transactions`, `fee_receipts`, `fee_payment_gateway_logs`, `fee_fine_transactions`, `fee_structure_masters`, `fee_structure_details`, `fee_head_masters`, `sch_organizations`, `std_students`, `sys_users`, `glb_academic_sessions` (central) |
| Live data | test tenant `xyz_school_00000000000040008000_202627`: `fee_invoices` 7,296 · `fee_transactions` 3,833 · `fee_receipts` 3,833 · `fee_student_assignments` 1,824 · `sch_organizations` 1 · `fee_installments` 60 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Production-ready after the two High findings, but not as written. The security spine of this controller is correct: every child-scoped page resolves the parent's own child through `ParentContextService`, and the three record pages (`invoice`, `receipt`, `downloadInvoice`) each carry an explicit ownership guard (`abort_unless(... student_id === $child->id, 403)`) before any data is shown, so a parent cannot read another family's invoice or receipt by guessing an id. That part I could not break.

The single worst finding is **FEE-14**: two Blade templates run `FeeReceipt::where('transaction_id', $txn->id)->first()` inside a `@foreach` — one query per transaction on the fee summary and the invoice page, on a tenant that already has 3,833 transactions. The runner-up is **FEE-07**: `Organization::academicSession()` pivots on `glb_academic_sessions`, a central table that has none of the pivot columns the relation joins on, so any caller of that relation gets a SQL error.

The controller is 303 lines with no method over 80 lines, so there is no split to defer. The controller-level error handling, however, contradicts settled decision **D1** in five methods (a `try/catch` in a controller). Rough effort: the two High fixes and the mechanical items are a half-day; the two DECISION items need one product/design choice each.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 8 | 5 | 2 | 15 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | FEE-01, FEE-02, FEE-13 | F8 Services/Jobs | FEE-11, FEE-12, FEE-13 |
| F2 Transactions/Audit | FEE-02 | F9 Queries/Perf | FEE-14 (also F10) |
| F3 Authorization | clean | F10 Views | FEE-14, FEE-15 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | FEE-09, FEE-10 |
| F6 Controller shape | FEE-03, FEE-04, FEE-05 | F13 Deep read | table in §6 F13 |
| F7 Models | FEE-06, FEE-07, FEE-08 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php` | controller | 303 | this report | ✅ |
| 2 | `Modules/ParentPortal/routes/web.php` | route file (lines 82-98: the five fee routes) | 199 | this report (routes only) | ✅ |
| 3 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware | 65 | ↗ [tarun/ParentPortal-done/ParentHealthController](../ParentHealthController-done/01-report.md) | ↗ linked (usage checked, §7) |
| 4 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) | ↗ linked (usage checked, §7) |
| 5 | `Modules/SchoolSetup/app/Models/Organization.php` | model | 320 | this report (claimed 2026-10-13) | ✅ |
| 6 | `Modules/StudentFee/app/Models/FeeInvoice.php` | model | 474 | this report (pre-assigned) | ✅ |
| 7 | `Modules/StudentFee/app/Models/FeeReceipt.php` | model | 116 | this report (pre-assigned) | ✅ |
| 8 | `Modules/StudentFee/app/Models/FeeStudentAssignment.php` | model | 226 | this report (pre-assigned) | ✅ |
| 9 | `Modules/StudentFee/app/Models/FeeTransaction.php` | model | 239 | this report (claimed; linked here by ParentFeePaymentController) | ✅ |
| 10 | `Modules/StudentFee/app/Services/FeeInvoiceService.php` | service | 382 | this report (pre-assigned) | ✅ |
| 11 | `Modules/ParentPortal/resources/views/fees/index.blade.php` | view | 560 | this report | ✅ |
| 12 | `Modules/ParentPortal/resources/views/fees/history.blade.php` | view | 379 | this report | ✅ |
| 13 | `Modules/ParentPortal/resources/views/fees/invoice.blade.php` | view | 258 | this report | ✅ |
| 14 | `Modules/ParentPortal/resources/views/fees/receipt.blade.php` | view | 148 | this report | ✅ |
| 15 | `Modules/ParentPortal/resources/views/fees/invoice-pdf.blade.php` | view (PDF) | 359 | this report | ✅ |
| 16 | `Modules/StudentFee/app/Models/FeeInstallment.php`, `FeeStructureMaster.php`, `FeeStructureDetail.php`, `FeeHeadMaster.php`, `FeePaymentGatewayLog.php`, `FeeFineTransaction.php` | models | — | none claimed | ❌ not audited — reached only through relations this controller reads; not in the pre-assigned set (see §8) |

No in-scope file appears in a `PRE-APPLIED-2026-10-10.md` (the only such file is for TimetableFoundation).

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '...ParentFeeController@...'
GET|HEAD  parent-portal/fees                             parent-portal.fees.index               Modules\ParentPortal\Http\Controllers\ParentFeeController@index
GET|HEAD  parent-portal/fees/history                     parent-portal.fees.history             Modules\ParentPortal\Http\Controllers\ParentFeeController@history
GET|HEAD  parent-portal/fees/invoice/{invoice}           parent-portal.fees.invoice             Modules\ParentPortal\Http\Controllers\ParentFeeController@invoice
GET|HEAD  parent-portal/fees/invoice/{invoice}/download  parent-portal.fees.invoice.download    Modules\ParentPortal\Http\Controllers\ParentFeeController@downloadInvoice
GET|HEAD  parent-portal/fees/receipt/{receipt}           parent-portal.fees.receipt             Modules\ParentPortal\Http\Controllers\ParentFeeController@receipt
```

All five sit in `Route::prefix('fees')` in `Modules/ParentPortal/routes/web.php:83-98`. The group is mounted behind `web → PreventAccessFromCentralDomains → InitializeTenancyByDomain → EnsureTenantIsActive → EnsureTenantHasModule:ParentPortal → Authenticate → ParentPortalMiddleware`. The route parameters `{invoice}` and `{receipt}` match the implicit-bound method arguments `FeeInvoice $invoice` and `FeeReceipt $receipt` (verified against `route:list`). All five are GET; the only write any of them performs is the `sys_activity_logs` audit row, which is the portal's normal view logging and not the state change RTE-01 forbids.

Unrouted public methods: none — all five public methods are routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 35 | GET fees | none (route middleware `ParentPortalMiddleware`; child from `ParentContextService`) | none | 'Viewed' (line 68, after the reads) | sys_activity_logs | FEE-01, FEE-04, FEE-05 |
| `history` | 92 | GET fees/history | none (route middleware) | none | 'Viewed' (line 124) | sys_activity_logs | FEE-01, FEE-04 |
| `invoice` | 146 | GET fees/invoice/{invoice} | none (route middleware) plus record guard `student_id === $child->id` at line 156 | controller — `DB::transaction` at line 149 (read path) | 'Viewed' (line 166, inside the transaction) | sys_activity_logs | FEE-02, FEE-04, FEE-14 |
| `downloadInvoice` | 205 | GET fees/invoice/{invoice}/download | none (route middleware) plus record guard `student_id === $child->id` at line 217 | none | 'Downloaded' (line 232) | sys_activity_logs | FEE-01, FEE-04 |
| `receipt` | 252 | GET fees/receipt/{receipt} | none (route middleware) plus record guard traced to `student_id === $child->id` at line 264 | controller — `DB::transaction` at line 255 (read path) | 'Viewed' (line 268, inside the transaction) | sys_activity_logs | FEE-02, FEE-04 |

## 6. Findings

### F1 — Errors

#### FEE-01 · M · ERR-07 — `index()`, `history()` and `downloadInvoice()` wrap the audit write in a controller `try/catch` (D1)

| Field | Value |
|---|---|
| **Rule** | ERR-07 (M) — *read-only methods need no try/catch*; D1 — *the Laravel idiom: no try/catch in a controller; `DB::transaction` and the central handler in `bootstrap/app.php` do the work*; also ERR-05 — *log the exception object, not its message*. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php:67-79`, method `index()` — repeated at `:123-135` (`history()`) and `:231-244` (`downloadInvoice()`) |
| **Root cause** | These are read pages whose only write is one `activityLog()` row. The code wraps that single call in `try { … } catch (\Throwable $e) { Log::error(…); }`. D1 settled that a controller carries no try/catch; the audit helper already writes one row and cannot take the page down. |
| **Consequence** | A reviewer-approved error path exists where none is needed; the catch hides the exception object (only `$e->getMessage()` is logged), so a real failure in the audit helper is logged without its trace. |
| **Reproduce** | static only — the catch is exercised only when `activityLog()` throws. |
| **Fix approach** | Delete the `try` and the `catch` in all three methods and let `activityLog()` run directly; if `$request` is used for the route name, take it from the injected `Request`. |
| **Plan item** | FEE-01 in `02-fix-plan.md` §3 |

```php
// ParentFeeController.php:67-79 — CURRENT
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed fee summary',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
```

**Evidence**
```
$ grep -n "view log failed" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php
78:            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
134:            Log::error('view log failed', ['method' => 'history', 'error' => $e->getMessage()]);
243:            Log::error('view log failed', ['method' => 'downloadInvoice', 'error' => $e->getMessage()]);
```

#### FEE-02 · M · ERR-07 — `invoice()` and `receipt()` wrap a read page in `DB::transaction` and a controller `try/catch` (D1, TXN-05)

| Field | Value |
|---|---|
| **Rule** | ERR-07 (M) / D1 — *read methods need no try/catch, and a controller carries none*; TXN-05 (M) — *the transaction closure returns data; build the response after it*; also ERR-05 — *log the exception object*. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php:148-199`, method `invoice()` — repeated at `:254-301` (`receipt()`) |
| **Root cause** | Both methods treat a read page as a write. `DB::transaction(function () { … return view(…) })` wraps record loads, the ownership guard and the audit write, and builds the `View` inside the closure. A generic `catch (\Throwable)` then returns `back()` with a red flash. The two earlier catches (`ModelNotFoundException`, `HttpExceptionInterface`) are the D2 rethrow shape and are correct, but the wrapper they sit in is the D1 violation. |
| **Consequence** | When anything unexpected fails while rendering an invoice, the parent is redirected to the previous page with "The operation could not be completed." instead of getting the standard 500 page, and a read holds an open database transaction for its duration. |
| **Reproduce** | static only — the generic catch fires only on an unexpected exception; open `/parent-portal/fees/invoice/{id}` for an invoice the parent owns after forcing a load error. |
| **Fix approach** | Remove `DB::transaction` and the outer `try/catch`; run `resolveChild()`, the eager `load()`, the ownership `abort_unless()`, the `activityLog()` and the `view()` as a plain read. Let `ModelNotFoundException` and the `abort()` exceptions reach the central handler. |
| **Plan item** | FEE-02 in `02-fix-plan.md` §3 |

```php
// ParentFeeController.php:148-199 — CURRENT
        try {
            return DB::transaction(function () use ($request, $invoice) {
                $child = $this->context->resolveChild($request);

                // IDOR guard — invoice must belong to this child
                $invoice->load(['studentAssignment.student', 'studentAssignment.feeStructure',
                                'installment', 'transactions.collector', 'fineTransactions']);

                abort_unless(
                    $invoice->studentAssignment?->student_id === $child->id,
                    403
                );

                $transactions = $invoice->transactions()
                    ->where('status', 'Success')
                    ->orderByDesc('payment_date')
                    ->get();

                activityLog(auth()->user(), 'Viewed', [
                    'message' => 'Viewed invoice',
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                    'invoice_id' => $invoice->id,
                ]);

                return view('parentportal::fees.invoice', compact('child', 'invoice', 'transactions'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (HttpExceptionInterface $e) {
            // abort()/abort_unless() throw an HttpException. Without this the generic
            // catch below swallows it and a deliberate 403 becomes a redirect reading
            // "The operation could not be completed." — the guard still refuses, but the
            // parent is told the wrong thing and the log records an application failure
            // instead of an access denial. Matches the AuthorizationException|Validation
            // Exception|HttpExceptionInterface pattern already used in ParentLeaveController.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('ParentFeeController::invoice failed', ['error' => $e->getMessage()]);

            // The declared return type is widened to View|RedirectResponse rather than
            // forcing a JSON body here: this renders a page, and its error path has always
            // been a redirect. Declared `: View` alone, that redirect was a TypeError.
            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "DB::transaction\|catch (" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php
149:            return DB::transaction(function () use ($request, $invoice) {
180:        } catch (ModelNotFoundException $e) {
184:        } catch (HttpExceptionInterface $e) {
192:        } catch (\Throwable $e) {
255:            return DB::transaction(function () use ($request, $receipt) {
282:        } catch (ModelNotFoundException $e) {
286:        } catch (HttpExceptionInterface $e) {
294:        } catch (\Throwable $e) {
```

#### FEE-13 · M · ERR-05 — `FeeInvoiceService::recordGatewayPayment()` logs the message, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace*; D2 — *a service catch uses `report($e)` plus a fixed message*. |
| **Where** | `Modules/StudentFee/app/Services/FeeInvoiceService.php:192-197`, method `recordGatewayPayment()` |
| **Root cause** | The catch is deliberate (D2: a receipt must never roll back a recorded payment), but it logs `'error' => $e->getMessage()`, which discards the stack trace and any exception context. |
| **Consequence** | If receipt generation breaks, the log holds only the message text; there is no trace to find the failing query or call site. The money is still recorded correctly. |
| **Reproduce** | static only — the catch fires only when `FeeReceipt::create()` throws. |
| **Fix approach** | Call `report($e)` to log the exception object, and keep a fixed `Log::warning()` message for the receipt-specific context. |
| **Plan item** | FEE-13 in `02-fix-plan.md` §3 |

```php
// FeeInvoiceService.php:192-197 — CURRENT
            } catch (\Throwable $e) {
                Log::error('Receipt generation failed; the payment WAS recorded.', [
                    'transaction_id' => $transaction->id,
                    'invoice_id'     => $invoice->id,
                    'error'          => $e->getMessage(),
                ]);
            }
```

**Evidence**
```
$ grep -n "getMessage" Modules/StudentFee/app/Services/FeeInvoiceService.php
196:                    'error'          => $e->getMessage(),
```

### F2 — Transactions and audit

Covered by FEE-02 (the `DB::transaction` on the two read pages, TXN-05). The controller performs no multi-table business write, so TXN-01/TXN-04 do not arise here. `activityLog()` is called after the reads it describes in every method.

```
$ grep -n "beginTransaction\|->commit()\|->rollBack()" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php
(no output)
```

### F3 — Authorization

clean — route middleware `ParentPortalMiddleware` restricts every route to `user_type = PARENT` with a linked child, and each record page carries a per-record ownership guard before rendering. Proven:

```
$ grep -n "abort_unless" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php
156:                abort_unless(
217:        abort_unless(
263:                abort_unless(
```

`invoice()` line 157 checks `$invoice->studentAssignment?->student_id === $child->id`; `downloadInvoice()` line 218 checks the same; `receipt()` line 264 checks `$receipt->transaction?->invoice?->studentAssignment?->student_id === $child->id`. A null chain fails closed to 403.

### F4 — Validation and input

clean — no user input is accepted; all parameters are implicitly route-model bound (`FeeInvoice $invoice`, `FeeReceipt $receipt`) and there is no `$request->all()`, `create()` or `update()` anywhere in the controller.

```
$ grep -n "request()->validate\|\$request->all()\|->create(\|->update(" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php
(no output)
```

### F5 — Routes

clean — five GET routes, each pointing at an existing method; route parameters match the bound arguments; the tenant middleware group is present. The `activityLog()` write on GET is ordinary portal view-logging, not the state change RTE-01 forbids.

```
$ grep -n "Route::get('/\|Route::get('/history\|Route::get('/invoice\|Route::get('/receipt" Modules/ParentPortal/routes/web.php
84:    Route::get('/', [ParentFeeController::class, 'index'])->name('index');
85:    Route::get('/history', [ParentFeeController::class, 'history'])->name('history');
86:    Route::get('/invoice/{invoice}', [ParentFeeController::class, 'invoice'])->name('invoice');
87:    Route::get('/receipt/{receipt}', [ParentFeeController::class, 'receipt'])->name('receipt');
90:    Route::get('/invoice/{invoice}/download', [ParentFeeController::class, 'downloadInvoice'])
```

### F6 — Controller shape

#### FEE-03 · M · CTL-05 — the `activityLog()` context array is copy-pasted five times

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same payload repeated ten times belongs in one method*. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php:68-75`, method `index()` — repeated at `:126-131`, `:168-173`, `:234-239`, `:270-275` |
| **Root cause** | The same five-key `context` array (`student_id`, `student_name`, `module`, `route`) is written out in all five methods. |
| **Consequence** | A change to the audit context (a new key, a renamed route) has to be made in five places; one is guaranteed to be missed. |
| **Reproduce** | static only. |
| **Fix approach** | Extract one private `feeLogContext(Request $request, $child): array` and call it from all five sites. Because the five call sites are also edited by FEE-01/FEE-02, this is deferred (see §10). |
| **Plan item** | none — see plan §10 |

```php
// ParentFeeController.php:68-75 — CURRENT
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed fee summary',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
```

**Evidence**
```
$ grep -c "'module' => 'ParentPortal'" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php
5
```

#### FEE-04 · L · CTL-08 — the `request()` helper is used instead of the injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods*. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php:74`, method `index()` — also `:130`, `:172`, `:238`, `:274` |
| **Root cause** | Each method already receives `Request $request`, but the audit context calls the global `request()` helper for the route name. |
| **Consequence** | Style only — the helper and the injected object resolve to the same request, but the controller is inconsistent. |
| **Reproduce** | static only. |
| **Fix approach** | Use `$request->route()?->getName()` at all five sites. This is folded into the FEE-03 helper, so it is deferred with it (see §10). |
| **Plan item** | none — see plan §10 |

```php
// ParentFeeController.php:74 — CURRENT
                    'route' => request()->route()?->getName(),
```

**Evidence**
```
$ grep -n "request()->route()" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php
74:                    'route' => request()->route()?->getName(),
130:                    'route' => request()->route()?->getName(),
172:                        'route' => request()->route()?->getName(),
238:                    'route' => request()->route()?->getName(),
274:                    'route' => request()->route()?->getName(),
```

#### FEE-05 · L · CTL-10 — `index()` computes and passes three totals the view never reads

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *no dead code: unused variables* (severity lowered from M to L: the variables are harmless reads with no query cost and no user effect). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php:51-54`, method `index()` — passed at `:81-85` |
| **Root cause** | The controller computes `$totalAmount`, `$paidAmount`, `$balanceAmount` and `$overdueCount` and passes them to the view, but `index.blade.php` recomputes all four from `$invoices` in its own `@php` block (`index.blade.php:76-85`) and reads none of the controller's copies. |
| **Consequence** | A future maintainer sees two sources for the same number; changing the controller value has no effect on the page. |
| **Reproduce** | static only. |
| **Fix approach** | Delete the four variables and drop them from the `compact()` call, leaving the view's own computation as the single source. |
| **Plan item** | FEE-05 in `02-fix-plan.md` §5 |

```php
// ParentFeeController.php:51-54 — CURRENT
        $totalAmount  = $invoices->sum('total_amount');
        $paidAmount   = $invoices->sum('paid_amount');
        $balanceAmount = $invoices->sum('balance_amount');
        $overdueCount  = $invoices->filter(fn ($inv) => $inv->isOverdue())->count();
```

**Evidence**
```
$ grep -n "totalAmount\|overdueCount" Modules/ParentPortal/resources/views/fees/index.blade.php
(no output — the view recomputes its own $totalAnnualFee / $overdueCount)
$ grep -n "'totalAmount'\|'overdueCount'" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php
83:            'totalAmount', 'paidAmount', 'balanceAmount', 'overdueCount',
```

### F7 — Models

#### FEE-06 · M · MDL-02 — `Organization` has no casts for `established_date` or `is_active`

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` for every boolean, date/datetime, decimal, json/array and enum column*. |
| **Where** | `Modules/SchoolSetup/app/Models/Organization.php:29-32`, class `Organization` |
| **Root cause** | The model declares `$fillable` and `$mediaCollections` but no `$casts` (nor a `casts()` method). The table has `established_date` (`DATE`) and `is_active` (`TINYINT`), plus `flg_single_record`. |
| **Consequence** | `$org->established_date` returns a raw string and `$org->is_active` returns `0`/`1` rather than `false`/`true`, so any truthiness test compares an integer. |
| **Reproduce** | static only. |
| **Fix approach** | Add a `$casts` property mapping `established_date` to `date` and `is_active` (and `flg_single_record`) to `boolean`. |
| **Plan item** | FEE-06 in `02-fix-plan.md` §5 |

```php
// Organization.php:29-32 — CURRENT
    protected $fillable = [
        'tenant_id',
        'group_code',
```

**Evidence**
```
$ grep -n "casts" Modules/SchoolSetup/app/Models/Organization.php
(no output)
$ php artisan tinker --execute '...SHOW COLUMNS... sch_organizations...'
sch_organizations: id,...,established_date,flg_single_record,is_active,created_at,updated_at,city_id,deleted_at
```

#### FEE-07 · H · MDL-03 — `Organization::academicSession()` pivots on `glb_academic_sessions` without `wherePivotNull`, and that table has no pivot columns

| Field | Value |
|---|---|
| **Rule** | MDL-03 (H) — *a `belongsToMany` over a pivot table that has `deleted_at` must add `->wherePivotNull('deleted_at')`, or removed rows still count as members*. |
| **Where** | `Modules/SchoolSetup/app/Models/Organization.php:139-152`, method `academicSession()` |
| **Root cause** | The relation names `glb_academic_sessions` as its pivot. That table exists only in `global_master`, has `deleted_at`, and has columns `id, short_name, name, start_date, end_date, is_current, deleted_at, created_at, updated_at, current_flag` — none named `organization_id` or `academic_session_id`. The real join table on the tenant is `sch_org_academic_sessions_jnt`. The relation therefore cannot resolve, and it also omits `wherePivotNull('deleted_at')`. |
| **Consequence** | Any caller of `$organization->academicSession` gets a SQL "unknown column" error rather than sessions. Not reached by this controller, but reachable from every Organization consumer. |
| **Reproduce** | static only for this controller — prove with the schema query in Evidence. |
| **Fix approach** | Point the relation at `sch_org_academic_sessions_jnt` and add `->wherePivotNull('deleted_at')`, or delete the unused relation. This is a DECISION (see FEE-07 item). |
| **Plan item** | FEE-07 in `02-fix-plan.md` §9 |

```php
// Organization.php:139-152 — CURRENT
    public function academicSession()
    {
        return $this->belongsToMany(AcademicSession::class, 'glb_academic_sessions')
            ->withPivot([
                'short_name',
                'name',
                'start_date',
                'end_date',
                'is_current',
                'is_active',
                'current_flag',
            ])
            ->withTimestamps();
    }
```

**Evidence**
```
$ php artisan tinker --execute '...SHOW COLUMNS FROM global_master.glb_academic_sessions...'
glb_academic_sessions: id,short_name,name,start_date,end_date,is_current,deleted_at,created_at,updated_at,current_flag
$ php artisan tinker --execute '...SHOW TABLES LIKE %academic_session%...'
xyz_school_00000000000040008000_202627: sch_org_academic_sessions_jnt
```

#### FEE-08 · L · MDL-04 — relationship methods without return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`)*. |
| **Where** | `Modules/StudentFee/app/Models/FeeInvoice.php:157-165`, class `FeeInvoice` — also `FeeStudentAssignment.php:83-91` (`invoices`, `concessions`) and `Organization.php:82-254` (24 relations) |
| **Root cause** | Some relations were written with `: BelongsTo` (the newer style) and others were left untyped. `FeeInvoice::transactions()`/`fineTransactions()` and `FeeStudentAssignment::invoices()`/`concessions()` return `$this->hasMany(...)` with no return type, and almost every `Organization` relation has none. |
| **Consequence** | Static analysis and IDE navigation lose the return type; a wrong relation class is not caught. |
| **Reproduce** | static only. |
| **Fix approach** | Add the matching `: HasMany` / `: BelongsTo` / `: BelongsToMany` return types. Deferred as a low-value codemod because `Organization` alone has 24 relations (see §10). |
| **Plan item** | none — see plan §10 |

```php
// FeeInvoice.php:157-165 — CURRENT
    public function transactions()
    {
        return $this->hasMany(FeeTransaction::class, 'invoice_id');
    }

    public function fineTransactions()
    {
        return $this->hasMany(FeeFineTransaction::class, 'invoice_id');
    }
```

**Evidence**
```
$ grep -rn "public function transactions()\|public function invoices()\|public function concessions()" Modules/StudentFee/app/Models/
Modules/StudentFee/app/Models/FeeInvoice.php:157:    public function transactions()
Modules/StudentFee/app/Models/FeeInvoice.php:162:    public function fineTransactions()
Modules/StudentFee/app/Models/FeeStudentAssignment.php:83:    public function invoices()
Modules/StudentFee/app/Models/FeeStudentAssignment.php:88:    public function concessions()
```

### F8 — Services and jobs

Covered by FEE-11 (dead private method), FEE-12 (over-long method) and FEE-13 (ERR-05). `FeeInvoiceService` has no HTTP calls and uses no constructor injection need; `FeeReceipt::nextReceiptNo()` is `lockForUpdate()`-based and is called inside a transaction by both callers. No jobs.

#### FEE-11 · M · CTL-10 — `FeeInvoiceService::resolvePayerUserId()` has no caller

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: unused private methods*. |
| **Where** | `Modules/StudentFee/app/Services/FeeInvoiceService.php:368-381`, method `resolvePayerUserId()` |
| **Root cause** | The method duplicates `FeeInvoice::resolveCollectedBy()` (which `recordPayment()` actually uses at line 123). It was superseded when that rule moved onto the model, but the private copy was left behind. |
| **Consequence** | Two implementations of one rule; a future reader may call the wrong one and re-introduce the drift the model comment warns about. |
| **Reproduce** | static only. |
| **Fix approach** | Delete the method (and its docblock). |
| **Plan item** | FEE-11 in `02-fix-plan.md` §5 |

```php
// FeeInvoiceService.php:368-381 — CURRENT
    private function resolvePayerUserId(FeeInvoice $invoice): int
    {
        $userId = $invoice->studentAssignment?->student?->user_id
            ?? $invoice->generated_by;

        throw_unless(
            $userId,
            \RuntimeException::class,
            "Cannot record payment for invoice {$invoice->id}: no authenticated user, and "
            . 'neither the student nor generated_by resolves to a sys_users id for collected_by.'
        );

        return (int) $userId;
    }
```

**Evidence**
```
$ grep -rn "resolvePayerUserId" Modules/ app/
Modules/StudentFee/app/Services/FeeInvoiceService.php:368:    private function resolvePayerUserId(FeeInvoice $invoice): int
```

#### FEE-12 · M · CTL-02 — `FeeInvoiceService::recordPayment()` is 82 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *a method over 80 lines should be extracted*. |
| **Where** | `Modules/StudentFee/app/Services/FeeInvoiceService.php:66`, method `recordPayment()` (lines 66-147) |
| **Root cause** | Status derivation, the invoice update, the full `FeeTransaction::create()` payload and the audit call sit in one method. |
| **Consequence** | Money-rule code is hard to review; the transaction payload is 38 lines of one call. |
| **Reproduce** | static only. |
| **Fix approach** | Extract the transaction-row build into a private helper. Deferred because it refactors the module's payment write path and is not a correctness fix (see §10). |
| **Plan item** | none — see plan §10 |

```php
// FeeInvoiceService.php:66-68 — CURRENT
    public function recordPayment(FeeInvoice $invoice, array $paymentData): FeeTransaction
    {
        return DB::transaction(function () use ($invoice, $paymentData) {
```

**Evidence**
```
$ sed -n '66,147p' Modules/StudentFee/app/Services/FeeInvoiceService.php | wc -l
82
```

### F9 — Queries and performance

The one query-in-a-loop defect is in Blade, so it is reported under F10 as FEE-14. The controller's own reads are bounded to one child; the assignment and invoice lists are not paginated but are naturally small per child.

```
$ grep -n "->get()\|->paginate(\|->all()" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php
46:            ->get();
164:                    ->get();
```
Both are single-child collections, not whole-table lists.

### F10 — Views

#### FEE-14 · H · VIEW-01 — `FeeReceipt` is queried once per transaction inside a `@foreach`

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H) — *no queries in Blade, especially inside `@foreach`*; the same defect is QRY-01 (no queries in loops). |
| **Where** | `Modules/ParentPortal/resources/views/fees/index.blade.php:415-417` — also `Modules/ParentPortal/resources/views/fees/invoice.blade.php:151-154` |
| **Root cause** | Both views fetch each row's receipt with `\Modules\StudentFee\Models\FeeReceipt::where('transaction_id', $txn->id)->first()` inside the transaction loop. The controller already eager-loads `transactions`, but there is no `receipt` relation and no keyed receipt map is passed. |
| **Consequence** | On the fee summary a parent with N successful transactions pays N extra receipt queries; on an invoice page, one query per transaction on that invoice. The tenant already holds 3,833 transactions. |
| **Reproduce** | Open `/parent-portal/fees` as a parent with several receipted payments and watch the query count grow with the number of transactions. |
| **Fix approach** | Load all receipts for the listed transaction ids once and pass a keyed collection, then look it up in the loop — or add a `receipt()` `HasOne` to `FeeTransaction` and eager-load `transactions.receipt`. This is a DECISION (see FEE-14 item). |
| **Plan item** | FEE-14 in `02-fix-plan.md` §9 |

```php
// index.blade.php:415-417 — CURRENT
                    @php
                        $receipt = \Modules\StudentFee\Models\FeeReceipt::where('transaction_id', $txn->id)->first();
                    @endphp
```

**Evidence**
```
$ grep -rn "FeeReceipt::where('transaction_id'" Modules/ParentPortal/resources/views/fees/
Modules/ParentPortal/resources/views/fees/index.blade.php:416:                        $receipt = \Modules\StudentFee\Models\FeeReceipt::where('transaction_id', $txn->id)->first();
Modules/ParentPortal/resources/views/fees/invoice.blade.php:153:                                $receipt = \Modules\StudentFee\Models\FeeReceipt::where('transaction_id', $txn->id)->first();
```

#### FEE-15 · M · MDL-09 — the invoice PDF looks up media collection `logo`, but the model registers `school_logo`

| Field | Value |
|---|---|
| **Rule** | MDL-09 (M) — *strings are constants, not literals repeated across files* (raised from L to M: the mismatch silently disables the school logo on every generated invoice). |
| **Where** | `Modules/ParentPortal/resources/views/fees/invoice-pdf.blade.php:19`, template `invoice-pdf` |
| **Root cause** | `Organization::registerMediaCollections()` registers `school_logo` and `cover_photo`. The PDF asks for `getFirstMedia('logo')`, a collection that is never registered, so `$media` is always null and the logo block is skipped. The surrounding `try { … } catch (\Throwable) {}` (lines 18-26) also swallows any error silently. |
| **Consequence** | Every downloaded invoice PDF renders without the school logo, against the template's intent; the empty catch hides the reason. |
| **Reproduce** | Upload a logo to an organization and download any invoice PDF — the header shows the school name without the logo. |
| **Fix approach** | Use the registered collection name: `$org->getFirstMedia('school_logo')`. |
| **Plan item** | FEE-15 in `02-fix-plan.md` §7 |

```php
// invoice-pdf.blade.php:19 — CURRENT
            $media = $org->getFirstMedia('logo');
```

**Evidence**
```
$ grep -n "getFirstMedia\|addMediaCollection" Modules/ParentPortal/resources/views/fees/invoice-pdf.blade.php Modules/SchoolSetup/app/Models/Organization.php
Modules/ParentPortal/resources/views/fees/invoice-pdf.blade.php:19:            $media = $org->getFirstMedia('logo');
Modules/SchoolSetup/app/Models/Organization.php:284:        $this->addMediaCollection('school_logo')
Modules/SchoolSetup/app/Models/Organization.php:288:        $this->addMediaCollection('cover_photo')
```

### F11 — Security and tenancy

clean — no `env()` outside config, no hard-coded ids or `?? 1`, no secrets or request bodies logged, files served through an authorised route (the PDF is generated on the fly, not served from storage), and `Organization::first()` runs in tenant context because the whole route sits behind `InitializeTenancyByDomain`.

```
$ grep -n "env(\|\?\? 1\|asset('storage" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php
(no output)
```

### F12 — Style

#### FEE-09 · L · STY-01 — four class files lack `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files; mandatory for new files, on touch for old*. |
| **Where** | `Modules/StudentFee/app/Models/FeeReceipt.php:1-3`, class `FeeReceipt` — also `Organization.php:1-3`, `FeeStudentAssignment.php:1-3`, `FeeTransaction.php:1-3` |
| **Root cause** | Each file opens with `<?php` + blank + `namespace` with no strict-types declaration. (`FeeInvoice.php`, `FeeInvoiceService.php` and the controller already declare it.) |
| **Consequence** | Scalar arguments are coerced silently in these models; typing is inconsistent across the same module. |
| **Reproduce** | static only. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening `<?php` in all four files. |
| **Plan item** | FEE-09 in `02-fix-plan.md` §8 |

```php
// FeeReceipt.php:1-3 — CURRENT
<?php

namespace Modules\StudentFee\Models;
```

**Evidence**
```
$ grep -Ln "declare(strict_types=1)" Modules/SchoolSetup/app/Models/Organization.php Modules/StudentFee/app/Models/FeeReceipt.php Modules/StudentFee/app/Models/FeeStudentAssignment.php Modules/StudentFee/app/Models/FeeTransaction.php
Modules/SchoolSetup/app/Models/Organization.php
Modules/StudentFee/app/Models/FeeReceipt.php
Modules/StudentFee/app/Models/FeeStudentAssignment.php
Modules/StudentFee/app/Models/FeeTransaction.php
```

#### FEE-10 · L · STY-04 — emoji markers in comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers*. |
| **Where** | `Modules/StudentFee/app/Models/FeeInvoice.php:310-312`, class `FeeInvoice` — also `FeeReceipt.php:72,88,106`, `FeeStudentAssignment.php:215`, `FeeTransaction.php:145,151,204,208`, `FeeInvoiceService.php:105,120,177,322,325,338,342`, `Organization.php:261` |
| **Root cause** | The module's docblocks use `⚠` / `⛔` markers as severity signals. They are informative but are emoji, which STY-04 disallows. |
| **Consequence** | Inconsistent with the project style rule; no runtime effect. |
| **Reproduce** | static only. |
| **Fix approach** | Deferred: the markers encode real warnings (a lost-payment history, the generated-column rule) and removing them is a comment-only codemod with review cost (see §10). |
| **Plan item** | none — see plan §10 |

```php
// FeeInvoice.php:310-312 — CURRENT
     * ⚠ collected_by is INT UNSIGNED NOT NULL with an FK to sys_users, and NOTHING
     * defaults it — so any insert that omits it dies with SQL 1364 and takes the whole
     * payment transaction down with it. Measured 2026-09-05: a real Razorpay payment
```

**Evidence**
```
$ grep -n "⚠\|⛔" Modules/StudentFee/app/Models/FeeInvoice.php
310:     * ⚠ collected_by is INT UNSIGNED NOT NULL with an FK to sys_users, and NOTHING
316:     * ⛔ auth()->id() ALONE IS NOT ENOUGH. Both callers below are reached from
429:     * ⚠ The option markup carries data-base="{{ total_fee_amount }}", which the dialog's
450:     * ⛔ THIS IS THE ONLY DEFINITION. It was duplicated in three places — the generator's
```

### F13 — Deep read (answers for every mutating method)

The controller has no business mutation. The only writes are the `activityLog()` audit rows. The table below answers the eight questions for each method; `n/a` marks a question that cannot apply to a read-only portal page.

| Method | 1 Overwrite? | 2 Delete before store? | 3 Duplicate impl? | 4 Soft-delete x unique? | 5 Race? | 6 Auth hole? | 7 Message lies? | 8 Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `index` | n/a | n/a | n/a | n/a | n/a | ok (middleware + child from resolver) | ok ('Viewed fee summary') | FEE-05, FEE-14 |
| `history` | n/a | n/a | n/a | n/a | n/a | ok | ok ('Viewed payment history') | FEE-14 |
| `invoice` | n/a | n/a | n/a | n/a | n/a | ok (record guard line 156) | ok ('Viewed invoice') | FEE-02, FEE-14 |
| `downloadInvoice` | n/a | n/a | n/a | n/a | n/a | ok (record guard line 217) | ok ('Downloaded invoice PDF') | FEE-01, FEE-15 |
| `receipt` | n/a | n/a | n/a | n/a | n/a | ok (record guard line 263) | ok ('Viewed receipt') | FEE-02 |

Because the controller performs no fee write, questions 1, 2, 4 and 5 cannot fire. The one model write path reachable from this audit's scope (`FeeInvoiceService`, owned here) is `recordPayment()`/`recordGatewayPayment()`, and it is idempotency-guarded by `lockForUpdate()` plus the callers' unique index; that is reported in FEE-12/FEE-13, not repeated here because the controller does not call it.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php:104` | `resolveChild()` calls `abort(redirect()->route('parent-portal.no-access'))` — a service doing an HTTP redirect. Owned by ParentDashboardController. | SVC-01 (M) | the ParentDashboardController report's owner |
| `Modules/ParentPortal/app/Services/ParentContextService.php:202-221` | `getOrCreateSession()` performs a `update()` then a `create()` with no transaction (TXN-01, H). Owned by ParentDashboardController. | TXN-01 (H) | the ParentDashboardController report's owner |
| `Modules/ParentPortal/app/Services/ParentContextService.php:26,32,144` | `⚠` / `⛔` emoji markers in comments. Owned by ParentDashboardController. | STY-04 (L) | the ParentDashboardController report's owner |
| `Modules/StudentFee/app/Models/FeeInvoice.php:139` / `FeeStudentAssignment` / `FeeTransaction` | Usage check: this controller relies on `studentAssignment` -> `student_id` and the `transactions` relation exactly as declared; no wrong-argument, missing-eager-load or bypassed-guard issue found in the controller's use of the linked classes. | — | none |

## 8. Not covered, and why

- The six relation-only models (`FeeInstallment`, `FeeStructureMaster`, `FeeStructureDetail`, `FeeHeadMaster`, `FeePaymentGatewayLog`, `FeeFineTransaction`) are read through the controller's eager loads but are not in the pre-assigned ownership set, so they are not audited here. Their columns used by the views (`installment_name`, `head_name`, `amount`, `is_optional`, the gateway-log fields) were confirmed against the live schema, but their own models were not reviewed.
- The PDF is generated with DomPDF through `Pdf::loadView()`; I did not render a PDF (D4, no tests), so `invoice-pdf.blade.php` is checked statically only. The logo finding FEE-15 is proven by the collection-name mismatch, not by a rendered output.
- `ParentContextService` is owned by the ParentDashboardController report; its two High/Medium defects (SVC-01, TXN-01) are recorded in §7 for that report, not fixed here.
- No queue job, listener, event, command or middleware execution was run; `ParentPortalMiddleware` was read, not exercised.
- The page counters in §0 were read from the test tenant `xyz_school_00000000000040008000_202627`; other tenants may differ.
