# Fix Plan — ParentPortal / ParentFeeController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` to `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/routes/web.php` | route file shared by every ParentPortal controller |
| `Modules/ParentPortal/app/Services/ParentContextService.php` | owned by the ParentDashboardController report; its SVC-01/TXN-01 defects are cross-cutting notes in the report |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | owned by the ParentHealthController report |
| `Modules/ParentPortal/resources/views/layouts/**` and `resources/views/components/**` | shared layouts and components |
| `database/migrations/**` | never edit an existing migration |
| `config/permissionslist.php` | shared config; no new permission key is proposed here |
| any `Modules/StudentProfile/**`, `Modules/Payment/**` file | different module, owned elsewhere |

## 1. Blockers reachable today

None — the report has no B-severity finding.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [x] **FEE-01** · M · ERR-07 · `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php:67-79` — remove the controller try/catch around the audit write in `index()`, `history()` and `downloadInvoice()` (D1).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php`
  - **Before** (`ParentFeeController.php:67-79`, `index()`):
    ```php
            try {
                activityLog(auth()->user(), 'Viewed', [
                    'message' => 'Viewed fee summary',
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                ]);
            } catch (\Throwable $e) {
                Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
            }
    ```
  - **After:** (`index()`):
    ```php
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed fee summary',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
            ]);
    ```
  - **Before** (`ParentFeeController.php:123-135`, `history()`):
    ```php
            try {
                activityLog(auth()->user(), 'Viewed', [
                    'message' => 'Viewed payment history',
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                ]);
            } catch (\Throwable $e) {
                Log::error('view log failed', ['method' => 'history', 'error' => $e->getMessage()]);
            }
    ```
  - **After** (`history()`):
    ```php
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed payment history',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
            ]);
    ```
  - **Before** (`ParentFeeController.php:231-244`, `downloadInvoice()`):
    ```php
            try {
                activityLog(auth()->user(), 'Downloaded', [
                    'message' => 'Downloaded invoice PDF',
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                    'invoice_id' => $invoice->id,
                ]);
            } catch (\Throwable $e) {
                Log::error('view log failed', ['method' => 'downloadInvoice', 'error' => $e->getMessage()]);
            }
    ```
  - **After** (`downloadInvoice()`):
    ```php
            activityLog(auth()->user(), 'Downloaded', [
                'message' => 'Downloaded invoice PDF',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
                'invoice_id' => $invoice->id,
            ]);
    ```
  - **Verify:** `grep -n "view log failed" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **FEE-02** · M · ERR-07 · `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php:148-199` — remove `DB::transaction` and the controller try/catch from `invoice()` and `receipt()` (D1, TXN-05).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php`
  - **Before** (`ParentFeeController.php:148-199`, `invoice()`):
    ```php
            try {
                return DB::transaction(function () use ($request, $invoice) {
                    $child = $this->context->resolveChild($request);

                    // IDOR guard — invoice must belong to this child
                    $invoice->load(['studentAssignment.student', 'studentAssignment.feeStructure',
                                    'installment', 'transactions.collector', 'fineTransactions']);

                    abort_unless(
                        $invoice->studentAssignment?->student_id === $child->id,
                        403
                    );

                    $transactions = $invoice->transactions()
                        ->where('status', 'Success')
                        ->orderByDesc('payment_date')
                        ->get();

                    activityLog(auth()->user(), 'Viewed', [
                        'message' => 'Viewed invoice',
                        'context' => [
                            'student_id' => $child?->id,
                            'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                            'module' => 'ParentPortal',
                            'route' => request()->route()?->getName(),
                        ],
                        'invoice_id' => $invoice->id,
                    ]);

                    return view('parentportal::fees.invoice', compact('child', 'invoice', 'transactions'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (HttpExceptionInterface $e) {
                // abort()/abort_unless() throw an HttpException. Without this the generic
                // catch below swallows it and a deliberate 403 becomes a redirect reading
                // "The operation could not be completed." — the guard still refuses, but the
                // parent is told the wrong thing and the log records an application failure
                // instead of an access denial. Matches the AuthorizationException|Validation
                // Exception|HttpExceptionInterface pattern already used in ParentLeaveController.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParentFeeController::invoice failed', ['error' => $e->getMessage()]);

                // The declared return type is widened to View|RedirectResponse rather than
                // forcing a JSON body here: this renders a page, and its error path has always
                // been a redirect. Declared `: View` alone, that redirect was a TypeError.
                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:** (`invoice()`):
    ```php
            $child = $this->context->resolveChild($request);

            // IDOR guard — invoice must belong to this child
            $invoice->load(['studentAssignment.student', 'studentAssignment.feeStructure',
                            'installment', 'transactions.collector', 'fineTransactions']);

            abort_unless(
                $invoice->studentAssignment?->student_id === $child->id,
                403
            );

            $transactions = $invoice->transactions()
                ->where('status', 'Success')
                ->orderByDesc('payment_date')
                ->get();

            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed invoice',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
                'invoice_id' => $invoice->id,
            ]);

            return view('parentportal::fees.invoice', compact('child', 'invoice', 'transactions'));
    ```
  - **Before** (`ParentFeeController.php:254-301`, `receipt()`):
    ```php
            try {
                return DB::transaction(function () use ($request, $receipt) {
                    $child = $this->context->resolveChild($request);

                    $receipt->load(['transaction.invoice.studentAssignment.student',
                                    'transaction.invoice.installment',
                                    'transaction.collector']);

                    // IDOR guard — receipt must trace back to this child
                    abort_unless(
                        $receipt->transaction?->invoice?->studentAssignment?->student_id === $child->id,
                        403
                    );

                    activityLog(auth()->user(), 'Viewed', [
                        'message' => 'Viewed receipt',
                        'context' => [
                            'student_id' => $child?->id,
                            'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                            'module' => 'ParentPortal',
                            'route' => request()->route()?->getName(),
                        ],
                        'receipt_id' => $receipt->id,
                    ]);

                    return view('parentportal::fees.receipt', compact('child', 'receipt'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (HttpExceptionInterface $e) {
                // abort()/abort_unless() throw an HttpException. Without this the generic
                // catch below swallows it and a deliberate 403 becomes a redirect reading
                // "The operation could not be completed." — the guard still refuses, but the
                // parent is told the wrong thing and the log records an application failure
                // instead of an access denial. Matches the AuthorizationException|Validation
                // Exception|HttpExceptionInterface pattern already used in ParentLeaveController.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParentFeeController::receipt failed', ['error' => $e->getMessage()]);

                // The declared return type is widened to View|RedirectResponse rather than
                // forcing a JSON body here: this renders a page, and its error path has always
                // been a redirect. Declared `: View` alone, that redirect was a TypeError.
                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After** (`receipt()`):
    ```php
            $child = $this->context->resolveChild($request);

            $receipt->load(['transaction.invoice.studentAssignment.student',
                            'transaction.invoice.installment',
                            'transaction.collector']);

            // IDOR guard — receipt must trace back to this child
            abort_unless(
                $receipt->transaction?->invoice?->studentAssignment?->student_id === $child->id,
                403
            );

            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed receipt',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
                'receipt_id' => $receipt->id,
            ]);

            return view('parentportal::fees.receipt', compact('child', 'receipt'));
    ```
  - **Before** (`ParentFeeController.php:7-24`, the import block):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Support\Facades\Log;
    use Illuminate\Support\Facades\DB;
    use App\Http\Controllers\Controller;
    use Barryvdh\DomPDF\Facade\Pdf;
    use Illuminate\Http\Request;
    use Illuminate\Http\Response;
    use Illuminate\View\View;
    use Modules\ParentPortal\Services\ParentContextService;
    use Modules\SchoolSetup\Models\Organization;
    use Modules\StudentFee\Models\FeeInvoice;
    use Modules\StudentFee\Models\FeeReceipt;
    use Modules\StudentFee\Models\FeeStudentAssignment;
    use Illuminate\Http\RedirectResponse;
    use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
    ```
  - **After** (the import block; remove the two imports this item makes unused):
    ```php
    use Illuminate\Support\Facades\Log;
    use Illuminate\Support\Facades\DB;
    use App\Http\Controllers\Controller;
    use Barryvdh\DomPDF\Facade\Pdf;
    use Illuminate\Http\Request;
    use Illuminate\Http\Response;
    use Illuminate\View\View;
    use Modules\ParentPortal\Services\ParentContextService;
    use Modules\SchoolSetup\Models\Organization;
    use Modules\StudentFee\Models\FeeInvoice;
    use Modules\StudentFee\Models\FeeReceipt;
    use Modules\StudentFee\Models\FeeStudentAssignment;
    use Illuminate\Http\RedirectResponse;
    ```
    If FEE-01 is ticked as well, `Illuminate\Support\Facades\Log` also becomes unused and may be removed in the same edit; leave the other imports.
  - **Verify:** `grep -n "DB::transaction\|ParentFeeController::invoice failed\|ParentFeeController::receipt failed" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **FEE-13** · M · ERR-05 · `Modules/StudentFee/app/Services/FeeInvoiceService.php:192-197` — log the exception object, not its message.
  - **Touches:** `Modules/StudentFee/app/Services/FeeInvoiceService.php`
  - **Before** (`FeeInvoiceService.php:192-197`):
    ```php
                } catch (\Throwable $e) {
                    Log::error('Receipt generation failed; the payment WAS recorded.', [
                        'transaction_id' => $transaction->id,
                        'invoice_id'     => $invoice->id,
                        'error'          => $e->getMessage(),
                    ]);
                }
    ```
  - **After:**
    ```php
                } catch (\Throwable $e) {
                    report($e);
                    Log::warning('Receipt generation failed; the payment WAS recorded.', [
                        'transaction_id' => $transaction->id,
                        'invoice_id'     => $invoice->id,
                    ]);
                }
    ```
  - **Verify:** `grep -n "getMessage" Modules/StudentFee/app/Services/FeeInvoiceService.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

None — every record page already carries a per-record ownership guard. No change.

## 5. Validation, routes, models, controller shape (F4/F5/F6/F7)

- [x] **FEE-05** · L · CTL-10 · `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php:51-54` — drop the three totals the view recomputes.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php`
  - **Before** (`ParentFeeController.php:50-54`, `index()`):
    ```php
            // Totals
            $totalAmount  = $invoices->sum('total_amount');
            $paidAmount   = $invoices->sum('paid_amount');
            $balanceAmount = $invoices->sum('balance_amount');
            $overdueCount  = $invoices->filter(fn ($inv) => $inv->isOverdue())->count();
    ```
  - **After** (`index()`; the view computes these itself):
    ```php
            // Totals are computed in the view from $invoices (audit FEE-05, 2026-10-13).
    ```
  - **Before** (`ParentFeeController.php:81-85`, the `compact()` call):
    ```php
            return view('parentportal::fees.index', compact(
                'child', 'session', 'assignments', 'invoices',
                'totalAmount', 'paidAmount', 'balanceAmount', 'overdueCount',
                'transactions',
            ));
    ```
  - **After:**
    ```php
            return view('parentportal::fees.index', compact(
                'child', 'session', 'assignments', 'invoices', 'transactions',
            ));
    ```
  - **Verify:** `grep -n "totalAmount\|overdueCount" Modules/ParentPortal/app/Http/Controllers/ParentFeeController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **FEE-06** · M · MDL-02 · `Modules/SchoolSetup/app/Models/Organization.php:29-32` — add casts for `established_date` and `is_active`.
  - **Touches:** `Modules/SchoolSetup/app/Models/Organization.php`
  - **Before** (`Organization.php:27-31`):
    ```php
        protected $table = 'sch_organizations';

        protected $fillable = [
            'tenant_id',
            'group_code',
    ```
  - **After:**
    ```php
        protected $table = 'sch_organizations';

        protected $casts = [
            'established_date' => 'date',
            'is_active' => 'boolean',
        ];

        protected $fillable = [
            'tenant_id',
            'group_code',
    ```
  - **Verify:** `grep -n "'established_date' => 'date'" Modules/SchoolSetup/app/Models/Organization.php`
  - **Expect:** one match on the `$casts` line.
  - **Effort:** S

- [x] **FEE-11** · M · CTL-10 · `Modules/StudentFee/app/Services/FeeInvoiceService.php:368-381` — delete the uncalled private `resolvePayerUserId()`.
  - **Touches:** `Modules/StudentFee/app/Services/FeeInvoiceService.php`
  - **Before** (`FeeInvoiceService.php:355-381`, the docblock plus the method):
    ```php
        /**
         * Resolve a non-null sys_users id to record as `collected_by` when there is no
         * authenticated user — i.e. on the gateway WEBHOOK path (FRCPT-13).
         *
         * Order, most to least truthful:
         *   1. the student the invoice belongs to (the person whose money it is)
         *   2. whoever generated the invoice
         *
         * Both were measured on 2026-08-12: 0 of 1,933 invoices have a student with a NULL
         * user_id, and 1,933 of 1,933 have generated_by set — so in practice step 1 always
         * answers. The explicit throw exists so that if a future tenant breaks both, the
         * failure names the real cause instead of surfacing as a bare SQL 1048 on an INSERT.
         */
        private function resolvePayerUserId(FeeInvoice $invoice): int
        {
            $userId = $invoice->studentAssignment?->student?->user_id
                ?? $invoice->generated_by;

            throw_unless(
                $userId,
                \RuntimeException::class,
                "Cannot record payment for invoice {$invoice->id}: no authenticated user, and "
                . 'neither the student nor generated_by resolves to a sys_users id for collected_by.'
            );

            return (int) $userId;
        }
    ```
  - **After:** (the method is gone; the file ends with the previous method's closing brace and the class brace):
    ```php
        // resolvePayerUserId() removed 2026-10-13 (audit FEE-11): no caller; its rule now
        // lives only in FeeInvoice::resolveCollectedBy().
    ```
  - **Verify:** `grep -rn "resolvePayerUserId" Modules/`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

None — the only query-in-a-loop is in Blade and is handled under §7 (FEE-14 is a DECISION item).

## 7. Views (F10)

- [x] **FEE-15** · M · MDL-09 · `Modules/ParentPortal/resources/views/fees/invoice-pdf.blade.php:19` — look up the registered media collection.
  - **Touches:** `Modules/ParentPortal/resources/views/fees/invoice-pdf.blade.php`
  - **Before** (`invoice-pdf.blade.php:19`):
    ```php
                $media = $org->getFirstMedia('logo');
    ```
  - **After:**
    ```php
                $media = $org->getFirstMedia('school_logo');
    ```
  - **Verify:** `grep -n "getFirstMedia" Modules/ParentPortal/resources/views/fees/invoice-pdf.blade.php`
  - **Expect:** one match containing `school_logo`.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [x] **FEE-09** · L · STY-01 · four class files — add `declare(strict_types=1)`.
  - **Touches:** `Modules/SchoolSetup/app/Models/Organization.php`, `Modules/StudentFee/app/Models/FeeReceipt.php`, `Modules/StudentFee/app/Models/FeeStudentAssignment.php`, `Modules/StudentFee/app/Models/FeeTransaction.php`
  - **Before** (`Modules/StudentFee/app/Models/FeeReceipt.php:1-3`; the same three lines open `FeeStudentAssignment.php` and `FeeTransaction.php`):
    ```php
    <?php

    namespace Modules\StudentFee\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentFee\Models;
    ```
  - **Before** (`Modules/SchoolSetup/app/Models/Organization.php:1-3`):
    ```php
    <?php

    namespace Modules\SchoolSetup\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SchoolSetup\Models;
    ```
  - **Verify:** `grep -Ln "declare(strict_types=1)" Modules/SchoolSetup/app/Models/Organization.php Modules/StudentFee/app/Models/FeeReceipt.php Modules/StudentFee/app/Models/FeeStudentAssignment.php Modules/StudentFee/app/Models/FeeTransaction.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **FEE-07** · H · DECISION · MDL-03 — repair or remove `Organization::academicSession()`?
  - **Why it is a decision:** the relation pivots on `glb_academic_sessions`, a central table that has `deleted_at` but none of the pivot columns the relation joins on; repairing it changes which sessions an organization reports, and removing it removes a method other code could call. A behaviour and surface choice, not a mechanical fix.
  - (a) ⭐ repair it: point the pivot at the existing tenant table `sch_org_academic_sessions_jnt` and add `->wherePivotNull('deleted_at')`
  - (b) delete the relation, since no caller exists today
  - (c) leave as is and record it as accepted
  - ➜ Choice: (c) — leave the Organization relation as accepted 2026-10-22

- [x] **FEE-14** · H · DECISION · VIEW-01 — how should the per-transaction receipt lookup be fixed?
  - **Why it is a decision:** it either adds a model relation or a controller-side map, and it changes two Blade views. The direction affects the `FeeTransaction` model surface.
  - (a) ⭐ add a `receipt(): HasOne` to `Modules/StudentFee/app/Models/FeeTransaction.php`, eager-load `transactions.receipt` in `index()` and `invoice()`, and render `$txn->receipt`
  - (b) pre-fetch `FeeReceipt::whereIn('transaction_id', $ids)->get()->keyBy('transaction_id')` in `index()` and `invoice()`, pass it to the views, and replace the inline query with a keyed lookup
  - (c) leave as is and record it as accepted
  - ➜ Choice: (c) — accept the per-transaction receipt lookup 2026-10-22

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| FEE-03 | Deferred: extracting the CTL-05 helper edits the same five lines that FEE-01/FEE-02 rewrite, so a separate item would leave its Before block stale. Fold it into the FEE-01/FEE-02 work if wanted. |
| FEE-04 | Folded into FEE-03: the extracted helper takes the injected `Request` and uses `$request->route()`, so no separate change is needed. |
| FEE-08 | Deferred codemod: MDL-04 return types are style-only and `Organization` alone has 24 relations; a repo-wide pass is the right place. |
| FEE-10 | Deferred: STY-04 emoji removal is comment-only and the `⚠`/`⛔` markers encode real warnings, so removing them needs a review pass rather than a blind codemod. |
| FEE-12 | Deferred: splitting `recordPayment()` refactors the module's money write path with no correctness gain; it belongs in a separate refactor task. |
