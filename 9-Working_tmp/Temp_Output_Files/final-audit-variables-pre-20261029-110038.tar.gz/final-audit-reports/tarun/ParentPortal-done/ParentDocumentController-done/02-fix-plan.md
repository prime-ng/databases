# Fix Plan — ParentPortal / ParentDocumentController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/routes/web.php` | shared route file; the PDOC-07 DECISION may touch it, and only if Tarun picks an option that needs a route change |
| `Modules/Payment/**` | owned by tarun/ParentPortal-done/ParentFeePaymentController report |
| `Modules/Hpc/**` | owned by tarun/ParentPortal-done/ParentResultController report |
| `Modules/ParentPortal/app/Services/ParentContextService.php` | owned by tarun/ParentPortal-done/ParentDashboardController report |
| `Modules/ParentPortal/app/Services/PptDropdownResolver.php` | owned by tarun/ParentPortal-done/ParentPtmController report |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | owned by tarun/ParentPortal-done/ParentHealthController report |
| `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` | owned by tarun/ParentPortal-done/ParentComplaintController report |
| `database/migrations/**` | never edit an existing migration; a new additive migration is Tarun's hand only |
| `config/permissionslist.php` | no permission changes in this plan |

## 1. Blockers reachable today

- [x] **PDOC-01** · B · VAL-01 · `Modules/ParentPortal/app/Models/ParentDocumentRequest.php:47-63` — add the accessor keys `document_type`, `urgency`, `status` to `$fillable` so the mutators map the validated strings to the NOT NULL `*_option_id` columns, making `store()` able to create a request at all.
  - **Touches:** `Modules/ParentPortal/app/Models/ParentDocumentRequest.php`
  - **Before** (`ParentDocumentRequest.php:47-63`):
    ```php
    protected $fillable = [
        'request_number',
        'student_id',
        'guardian_id',
        'document_type_option_id',
        'reason',
        'urgency_option_id',
        'status_option_id',
        'admin_notes',
        'fee_required',
        'fee_paid',
        'payment_reference',
        'fulfilled_media_id',
        'fulfilled_at',
        'is_active',
        'created_by',
    ];
    ```
  - **After:**
    ```php
    protected $fillable = [
        'request_number',
        'student_id',
        'guardian_id',
        'document_type',
        'document_type_option_id',
        'reason',
        'urgency',
        'urgency_option_id',
        'status',
        'status_option_id',
        'admin_notes',
        'fee_required',
        'fee_paid',
        'payment_reference',
        'fulfilled_media_id',
        'fulfilled_at',
        'is_active',
        'created_by',
    ];
    ```
    The `setDocumentTypeAttribute` / `setUrgencyAttribute` / `setStatusAttribute` mutators (lines 109-138) already resolve the strings to dropdown ids via `PptDropdownResolver::id(...)`; they were never reached because the keys were dropped before `setAttribute`. The `*_option_id` keys stay in the list so admin-side direct-id writes still work. This matches the module's dropdown-column pattern (`ConsentFormResponse`, `EventRsvp`).
  - **Verify:** `php artisan tinker --execute '$m = new \Modules\ParentPortal\Models\ParentDocumentRequest; $m->fill(["document_type" => "TC", "urgency" => "Normal", "status" => "Pending"]); var_export($m->getAttributes());'`
  - **Expect:** the attributes array contains `document_type_option_id`, `urgency_option_id` and `status_option_id` (resolved dropdown ids), not null for the three keys.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None — the payment race (PDOC-08) and the payment-path error shape (PDOC-06) are fixed together in the controller rewrite in §3, which ships before the style-only items.

## 3. Errors & transactions (F1/F2)

- [x] **PDOC-02** · M · D1 (with PDOC-03, PDOC-04, PDOC-05, PDOC-06, PDOC-08, PDOC-10, PDOC-11, PDOC-12) · `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php` — rewrite the controller per D1/D2: remove every try/catch, remove `DB::transaction` from the read methods, keep one transaction on the write methods with the activity log inside it, build responses after the closure, add the `logContext()` helper, narrow return types, and add the missing return type on `download()`. The After block below is the **complete new file** — paste it whole.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php`
  - **Before** — representative slice of the current shape; the fixer replaces the whole class body with the After block below. The other seven methods sit at the line ranges in report §5 (`create` 94-126, `store` 131-207, `show` 212-256, `withdraw` 261-308, `payInitiate` 315-354, `payCallback` 359-456, `download` 462-515) and all carry the same `try { return DB::transaction(...) } catch (...) { Log::error(... $e->getMessage()); return back()->with('error', ...) }` shape:
    ```php
        try {
            return DB::transaction(function () use ($request) {
    ```
  - **After:** the **complete new file** — replace the entire file content below the `<?php` line with this (imports included, `Log`/`ModelNotFoundException`/`HttpExceptionInterface` imports removed, `BinaryFileResponse` and `Student` added):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\ParentPortal\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\View\View;
    use Modules\Hpc\Models\HpcReport;
    use Modules\ParentPortal\Http\Requests\PayCallbackParentDocumentRequest;
    use Modules\ParentPortal\Http\Requests\PayInitiateParentDocumentRequest;
    use Modules\ParentPortal\Http\Requests\StoreParentDocumentRequest;
    use Modules\ParentPortal\Http\Requests\WithdrawParentDocumentRequest;
    use Modules\ParentPortal\Models\ParentDocumentRequest;
    use Modules\ParentPortal\Services\ParentContextService;
    use Modules\Payment\Services\GatewayManager;
    use Modules\Payment\Services\PaymentService;
    use Modules\StudentProfile\Models\Student;
    use Symfony\Component\HttpFoundation\BinaryFileResponse;

    class ParentDocumentController extends Controller
    {
        public function __construct(
            private readonly ParentContextService $context,
            private readonly PaymentService $paymentService,
            private readonly GatewayManager $gatewayManager,
        ) {}

        // Shared activity-log context for the active child (PDOC-11).
        private function logContext(Request $request, ?Student $child): array
        {
            return [
                'student_id'   => $child?->id,
                'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                'module'       => 'ParentPortal',
                'route'        => $request->route()?->getName(),
            ];
        }

        /**
         * Vault + request list (tabbed).
         */
        public function index(Request $request): View
        {
            $child = $this->context->resolveChild($request);

            // Vault: Published HPC report cards for this child.
            $reportCards = HpcReport::where('student_id', $child->id)
                ->where('status', 'Published')
                ->with(['academicSession', 'template', 'term'])
                ->orderByDesc('report_date')
                ->get();

            // Document requests raised by this parent for this child.
            $documentRequests = ParentDocumentRequest::forStudent($child->id)
                ->active()
                ->with(['statusOption', 'urgencyOption', 'documentTypeOption'])
                ->orderByDesc('created_at')
                ->get();

            $documentTypes = ParentDocumentRequest::DOCUMENT_TYPES;

            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed documents',
                'context' => $this->logContext($request, $child),
            ]);

            return view('parentportal::documents.index', compact(
                'child', 'reportCards', 'documentRequests', 'documentTypes',
            ));
        }

        /**
         * Show new document request form.
         */
        public function create(Request $request): View
        {
            $child         = $this->context->resolveChild($request);
            $documentTypes = ParentDocumentRequest::DOCUMENT_TYPES;

            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed document request form',
                'context' => $this->logContext($request, $child),
            ]);

            return view('parentportal::documents.create', compact('child', 'documentTypes'));
        }

        /**
         * Store a new document request.
         */
        public function store(StoreParentDocumentRequest $request): RedirectResponse
        {
            $child = $this->context->resolveChild($request);

            $validated = $request->validated();

            $guardianId = auth()->user()->guardian?->id
                ?? \Modules\StudentProfile\Models\Guardian::where('user_id', auth()->id())->value('id');

            abort_if($guardianId === null, 403, 'Parent guardian record not found.');

            $documentRequest = DB::transaction(function () use ($request, $child, $validated, $guardianId): ParentDocumentRequest {
                // Generate request number: PPT-DR-YYYY + 8-digit sequence
                $year       = now()->year;
                $lastNumber = ParentDocumentRequest::withTrashed()
                    ->where('request_number', 'like', "PPT-DR-{$year}%")
                    ->orderByDesc('request_number')
                    ->lockForUpdate()
                    ->value('request_number');

                $nextSeq = $lastNumber
                    ? ((int) substr($lastNumber, -8)) + 1
                    : 1;

                $requestNumber = 'PPT-DR-'.$year.str_pad((string) $nextSeq, 8, '0', STR_PAD_LEFT);

                $documentRequest = ParentDocumentRequest::create([
                    'request_number' => $requestNumber,
                    'student_id'     => $child->id,
                    'guardian_id'    => $guardianId,
                    'document_type'  => $validated['document_type'],
                    'reason'         => $validated['reason'],
                    'urgency'        => $validated['urgency'],
                    'status'         => ParentDocumentRequest::STATUS_PENDING,
                    'fee_required'   => 0.00,
                    'fee_paid'       => false,
                    'is_active'      => true,
                    'created_by'     => auth()->id(),
                ]);

                activityLog(auth()->user(), 'Requested', [
                    'message' => 'Requested duplicate document',
                    'context' => $this->logContext($request, $child),
                    'document_request_id' => $documentRequest->id,
                    'request_number' => $documentRequest->request_number,
                    'document_type' => $documentRequest->document_type,
                ]);

                return $documentRequest;
            });

            return redirect()
                ->route('parent-portal.documents.index')
                ->with('success', "Document request submitted. Request No: {$documentRequest->request_number}");
        }

        /**
         * Show a single document request.
         */
        public function show(Request $request, ParentDocumentRequest $documentRequest): View
        {
            $child = $this->context->resolveChild($request);

            abort_unless($documentRequest->student_id === $child->id, 403);

            $documentRequest->load([
                'student', 'guardian.user', 'createdBy',
                'statusOption', 'urgencyOption', 'documentTypeOption',
            ]);

            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed document request',
                'context' => $this->logContext($request, $child),
                'document_request_id' => $documentRequest->id,
            ]);

            return view('parentportal::documents.show', compact('child', 'documentRequest'));
        }

        /**
         * Withdraw a pending document request.
         */
        public function withdraw(WithdrawParentDocumentRequest $request, ParentDocumentRequest $documentRequest): RedirectResponse
        {
            $child = $this->context->resolveChild($request);

            abort_unless($documentRequest->student_id === $child->id, 403);
            abort_unless($documentRequest->isWithdrawable(), 422, 'This request can no longer be withdrawn.');

            DB::transaction(function () use ($request, $child, $documentRequest): void {
                $documentRequest->update(['is_active' => false]);
                $documentRequest->delete();

                activityLog(auth()->user(), 'Withdrawn', [
                    'message' => 'Withdrew document request',
                    'context' => $this->logContext($request, $child),
                    'document_request_id' => $documentRequest->id,
                    'request_number' => $documentRequest->request_number,
                    'document_type' => $documentRequest->document_type,
                ]);
            });

            return redirect()
                ->route('parent-portal.documents.index')
                ->with('success', 'Document request withdrawn.');
        }

        // ── Razorpay payment for duplicate-doc fee ───────────────────────────────

        /**
         * Initiate Razorpay order for duplicate-doc fee.
         */
        public function payInitiate(PayInitiateParentDocumentRequest $request, ParentDocumentRequest $documentRequest): JsonResponse
        {
            $child = $this->context->resolveChild($request);

            abort_unless($documentRequest->student_id === $child->id, 403);
            abort_unless($documentRequest->requiresPayment(), 422, 'No payment required for this request.');

            $result = $this->paymentService->initiate($documentRequest, 'razorpay');

            activityLog(auth()->user(), 'PaymentInitiated', [
                'message' => 'Initiated duplicate-document payment',
                'context' => $this->logContext($request, $child),
                'document_request_id' => $documentRequest->id,
                'amount' => $result['payment']->amount ?? null,
                'payment_ulid' => $result['payment']->ulid ?? null,
            ]);

            return response()->json([
                'success'      => true,
                'payment_ulid' => $result['payment']->ulid,
                'checkout'     => $result['checkout'],
            ]);
        }

        /**
         * Verify Razorpay signature and mark the doc-request fee as paid.
         */
        public function payCallback(PayCallbackParentDocumentRequest $request, ParentDocumentRequest $documentRequest): JsonResponse
        {
            $validated = $request->validated();

            $child = $this->context->resolveChild($request);
            abort_unless($documentRequest->student_id === $child->id, 403);

            $payment = $this->paymentService->getByUlid($request->input('payment_ulid'));

            abort_if(
                $payment->payable_type !== ParentDocumentRequest::class
                || $payment->payable_id !== $documentRequest->getKey(),
                403
            );

            /** @var \Modules\Payment\Gateways\RazorpayGateway $driver */
            $driver = $this->gatewayManager->resolve('razorpay');

            $verified = $driver->verify([
                'razorpay_order_id'   => $request->input('razorpay_order_id'),
                'razorpay_payment_id' => $request->input('razorpay_payment_id'),
                'razorpay_signature'  => $request->input('razorpay_signature'),
            ]);

            if (! $verified) {
                DB::transaction(function () use ($request, $child, $payment): void {
                    $this->paymentService->markFailed($payment, 'Signature verification failed', [
                        'razorpay_order_id'   => $request->input('razorpay_order_id'),
                        'razorpay_payment_id' => $request->input('razorpay_payment_id'),
                    ]);

                    activityLog(auth()->user(), 'PaymentFailed', [
                        'message' => 'Duplicate-document payment failed: signature verification failed',
                        'context' => $this->logContext($request, $child),
                        'document_request_id' => $payment->payable_id,
                        'reason' => 'Signature verification failed',
                    ]);
                });

                return response()->json([
                    'success' => false,
                    'message' => 'Payment signature verification failed.',
                ], 422);
            }

            $confirmed = DB::transaction(function () use ($request, $child, $payment, $documentRequest): bool {
                // Lock the request row so two simultaneous callbacks cannot both pass
                // the fee_paid check (TXN-06, PDOC-08).
                $locked = ParentDocumentRequest::whereKey($documentRequest->getKey())->lockForUpdate()->firstOrFail();

                if ($locked->fee_paid) {
                    return false;
                }

                $this->paymentService->markSuccess($payment, [
                    'payment_id' => $request->input('razorpay_payment_id'),
                    'signature'  => $request->input('razorpay_signature'),
                ]);

                $locked->update([
                    'fee_paid'          => true,
                    'payment_reference' => $request->input('razorpay_payment_id'),
                ]);

                activityLog(auth()->user(), 'Paid', [
                    'message' => 'Paid duplicate-document fee',
                    'context' => $this->logContext($request, $child),
                    'document_request_id' => $documentRequest->id,
                    'amount' => $payment->amount ?? null,
                    'payment_reference' => $request->input('razorpay_payment_id'),
                ]);

                return true;
            });

            if (! $confirmed) {
                return response()->json(['success' => false, 'message' => 'Fee already paid.'], 422);
            }

            return response()->json([
                'success'    => true,
                'new_status' => $documentRequest->fresh()->status,
            ]);
        }

        /**
         * Secure download of the fulfilled document.
         * Only accessible when status is Ready/Completed AND fee is paid (if applicable).
         */
        public function download(Request $request, ParentDocumentRequest $documentRequest): BinaryFileResponse
        {
            $child = $this->context->resolveChild($request);
            abort_unless($documentRequest->student_id === $child->id, 403);
            abort_unless($documentRequest->isDownloadable(), 422, 'Document is not yet available for download.');

            DB::transaction(function () use ($request, $child, $documentRequest): void {
                // Mark as Completed on first download. PDOC-07: this write-on-GET is a
                // DECISION item — behaviour unchanged until Tarun picks an option.
                if ($documentRequest->status === ParentDocumentRequest::STATUS_READY) {
                    $documentRequest->update([
                        'status'       => ParentDocumentRequest::STATUS_COMPLETED,
                        'fulfilled_at' => $documentRequest->fulfilled_at ?? now(),
                    ]);
                }

                activityLog(auth()->user(), 'Downloaded', [
                    'message' => 'Downloaded fulfilled document',
                    'context' => $this->logContext($request, $child),
                    'document_request_id' => $documentRequest->id,
                    'request_number' => $documentRequest->request_number,
                    'document_type' => $documentRequest->document_type,
                ]);
            });

            // Cross-DB sys_media — fulfilled document lives in the central media library.
            $media = \Modules\Prime\Models\Media::find($documentRequest->fulfilled_media_id);
            abort_if($media === null, 404, 'Fulfilled document not found.');

            return response()->download($media->getPath(), $media->file_name);
        }
    }
    ```
  - **Verify:** `php -l Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php && grep -c "catch (\|try {" Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php`
  - **Expect:** `No syntax errors detected`; grep count `0` (no `try {` / `catch (` left).
  - **Effort:** M

## 4. Authorization (F3)

None — record-level ownership checks are present on every routed method; the module-wide parent gate (`ParentPortalMiddleware`) is owned by the ParentHealthController report.

## 5. Validation, routes, models (F4/F5/F7)

- [x] **PDOC-13** · B · MDL-05/TEN-01 · `Modules/ParentPortal/app/Models/ParentDocumentRequest.php:18-23` — override `getMediaModel()` so any media-collection call on this tenant model targets the central `sys_media` table instead of the tenant DB.
  - **Touches:** `Modules/ParentPortal/app/Models/ParentDocumentRequest.php`
  - **Before** (`ParentDocumentRequest.php:18-23`):
    ```php
    use Spatie\MediaLibrary\HasMedia;
    use Spatie\MediaLibrary\InteractsWithMedia;

    class ParentDocumentRequest extends BaseModel implements Payable, HasMedia
    {
        use HasFactory, SoftDeletes, InteractsWithMedia;
    ```
  - **After:**
    ```php
    use Spatie\MediaLibrary\HasMedia;
    use Spatie\MediaLibrary\InteractsWithMedia;

    class ParentDocumentRequest extends BaseModel implements Payable, HasMedia
    {
        use HasFactory, SoftDeletes, InteractsWithMedia;

        /**
         * Media rows for this tenant model must land in the central sys_media
         * table (Modules\Prime\Models\Media pins connection 'mysql') — the fulfilled
         * document is referenced by fulfilled_media_id. Without this override any
         * collection call in tenant context writes to the tenant DB (MDL-05, PDOC-13).
         */
        public function getMediaModel(): string
        {
            return \Modules\Prime\Models\Media::class;
        }
    ```
  - **Verify:** `grep -n "getMediaModel" Modules/ParentPortal/app/Models/ParentDocumentRequest.php`
  - **Expect:** one hit.
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **PDOC-17** · M · QRY-12/VIEW-02 · `Modules/ParentPortal/app/Models/ParentDocumentRequest.php:104-138` — make the three dropdown accessors prefer the loaded `*Option` relation, so eager-loaded lists stop running `Dropdown::find` per attribute.
  - **Touches:** `Modules/ParentPortal/app/Models/ParentDocumentRequest.php`
  - The eager loads themselves (`->with(['statusOption', 'urgencyOption', 'documentTypeOption'])` in `index()` and in `show()`'s `load()`) are already part of the §3 controller rewrite — do not re-add them if that item was also ticked.
  - **Before** (`ParentDocumentRequest.php:104-138` — the three accessor/setter pairs; the setters stay unchanged):
    ```php
    public function getDocumentTypeAttribute(): ?string
    {
        return PptDropdownResolver::value($this->attributes['document_type_option_id'] ?? null);
    }

    public function setDocumentTypeAttribute(?string $value): void
    {
        $this->attributes['document_type_option_id'] = $value
            ? PptDropdownResolver::id('ppt_document_requests.document_type', $value)
            : null;
    }

    public function getUrgencyAttribute(): ?string
    {
        return PptDropdownResolver::value($this->attributes['urgency_option_id'] ?? null);
    }

    public function setUrgencyAttribute(?string $value): void
    {
        $this->attributes['urgency_option_id'] = $value
            ? PptDropdownResolver::id('ppt_document_requests.urgency', $value)
            : null;
    }

    public function getStatusAttribute(): ?string
    {
        return PptDropdownResolver::value($this->attributes['status_option_id'] ?? null);
    }

    public function setStatusAttribute(?string $value): void
    {
        $this->attributes['status_option_id'] = $value
            ? PptDropdownResolver::id('ppt_document_requests.status', $value)
            : null;
    }
    ```
  - **After:**
    ```php
    public function getDocumentTypeAttribute(): ?string
    {
        return $this->documentTypeOption?->value
            ?? PptDropdownResolver::value($this->attributes['document_type_option_id'] ?? null);
    }

    public function setDocumentTypeAttribute(?string $value): void
    {
        $this->attributes['document_type_option_id'] = $value
            ? PptDropdownResolver::id('ppt_document_requests.document_type', $value)
            : null;
    }

    public function getUrgencyAttribute(): ?string
    {
        return $this->urgencyOption?->value
            ?? PptDropdownResolver::value($this->attributes['urgency_option_id'] ?? null);
    }

    public function setUrgencyAttribute(?string $value): void
    {
        $this->attributes['urgency_option_id'] = $value
            ? PptDropdownResolver::id('ppt_document_requests.urgency', $value)
            : null;
    }

    public function getStatusAttribute(): ?string
    {
        return $this->statusOption?->value
            ?? PptDropdownResolver::value($this->attributes['status_option_id'] ?? null);
    }

    public function setStatusAttribute(?string $value): void
    {
        $this->attributes['status_option_id'] = $value
            ? PptDropdownResolver::id('ppt_document_requests.status', $value)
            : null;
    }
    ```
  - **Verify:** `grep -n "statusOption?->value\|urgencyOption?->value\|documentTypeOption?->value" Modules/ParentPortal/app/Models/ParentDocumentRequest.php`
  - **Expect:** three hits.
  - **Effort:** S

## 7. Views (F10)

None — no `{!! !!}`, no Blade queries; the accessor N+1 that the views trigger is fixed in §3/§6.

## 8. Style (F12) — one item per file

- [x] **PDOC-16** · L · STY-01 · six files — add `declare(strict_types=1);` after `<?php`.
  - **Touches:** `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php`, `Modules/ParentPortal/app/Http/Requests/StoreParentDocumentRequest.php`, `Modules/ParentPortal/app/Http/Requests/WithdrawParentDocumentRequest.php`, `Modules/ParentPortal/app/Http/Requests/PayInitiateParentDocumentRequest.php`, `Modules/ParentPortal/app/Http/Requests/PayCallbackParentDocumentRequest.php`, `Modules/Prime/app/Models/Media.php`
  - **Before** (`ParentPortalBaseRequest.php:1-3` — identical first lines in all six files):
    ```php
    <?php

    namespace Modules\ParentPortal\Http\Requests;
    ```
  - **After:** (for Media.php the namespace line is `namespace Modules\Prime\Models;`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\ParentPortal\Http\Requests;
    ```
  - **Verify:** `for f in Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php Modules/ParentPortal/app/Http/Requests/StoreParentDocumentRequest.php Modules/ParentPortal/app/Http/Requests/WithdrawParentDocumentRequest.php Modules/ParentPortal/app/Http/Requests/PayInitiateParentDocumentRequest.php Modules/ParentPortal/app/Http/Requests/PayCallbackParentDocumentRequest.php Modules/Prime/app/Models/Media.php; do head -1 "$f" | grep -q "strict_types" || echo "missing: $f"; done`
  - **Expect:** no `missing:` output.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **PDOC-07** · H · DECISION · RTE-01 — the GET `download` route performs a state change (Ready → Completed + audit row). What should a download click do?
  - **Why it is a decision:** any real fix changes a route (verb or a new route) or the status behaviour; §9.3 requires stopping for route changes, and Tarun owns the product semantics.
  - (a) ⭐ **Change the download route to POST.** Make `Route::post('/{documentRequest}/download')` and submit it as a small `<form>` button (same pattern as the withdraw button in `index.blade.php:219-227` / `show.blade.php:372-377`). GET stays pure; the Ready→Completed transition and the audit row only happen on a deliberate POST with CSRF. Touches: `Modules/ParentPortal/routes/web.php` (⚠ SHARED) + the two blades + the controller's `download()` signature/route comment.
  - (b) **Keep GET + write as-is** and record it as accepted risk (a prefetcher/refresh can flip a Ready request to Completed and log "Downloaded" without delivery).
  - (c) **Keep GET for the file only** and let the school mark the request Completed on the admin side when they see the `Downloaded` log; removes the auto-transition from the controller.
  - ➜ Choice: (b) — keep GET download + write, accepted risk 2026-10-22

- [x] **PDOC-09** · H · DECISION · VAL-07 — a parent can withdraw a request whose fee was already paid, and there is no refund path (money collected, request deleted). What should happen?
  - **Why it is a decision:** it changes parent-facing behaviour and touches the model + a FormRequest + both blades (the buttons render from `isWithdrawable()`).
  - (a) ⭐ **Block withdrawal once the fee is paid.** Add `&& ! $this->fee_paid` to `ParentDocumentRequest::isWithdrawable()` and add a `withValidator()` to `WithdrawParentDocumentRequest` with the fixed message "Fee already paid — contact the school office for a refund." The withdraw buttons disappear automatically because they already call `isWithdrawable()`. Touches: `Modules/ParentPortal/app/Models/ParentDocumentRequest.php` + `Modules/ParentPortal/app/Http/Requests/WithdrawParentDocumentRequest.php`.
  - (b) **Build a refund flow** (Razorpay refund API + a new admin/reversal route). Out of scope for this pass; needs a migration-free additive feature and a new route.
  - (c) **Keep as-is** and record it as accepted risk (a parent who pays then withdraws forfeits the fee by design).
  - ➜ Choice: (a) — block withdrawal once the fee is paid 2026-10-22

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PDOC-03 | Fixed by the PDOC-02 controller rewrite (§3): the `payInitiate` catch disappears, so no exception text can reach the user; the central handler renders the JSON 500. |
| PDOC-04 | Fixed by the PDOC-02 controller rewrite (§3): all eight message-only `Log::error(... getMessage())` lines disappear with the catches; the central handler in `bootstrap/app.php` reports the exception with class/file/line. |
| PDOC-05 | Fixed by the PDOC-02 controller rewrite (§3): responses are built after the transaction closure in every method. |
| PDOC-06 | Fixed by the PDOC-02 controller rewrite (§3): the `markFailed` + `PaymentFailed` log pair and the `initiate` + `PaymentInitiated` log pair run inside one transaction. |
| PDOC-08 | Fixed by the PDOC-02 controller rewrite (§3): the `fee_paid` re-check is moved inside the transaction behind `lockForUpdate()`. |
| PDOC-10 | Fixed by the PDOC-02 controller rewrite (§3): `payCallback` shrinks below 80 lines when the try/catch and duplicate context arrays are removed. |
| PDOC-11 | Fixed by the PDOC-02 controller rewrite (§3): the `logContext()` helper replaces the nine copies and the `request()` helper calls. |
| PDOC-12 | Fixed by the PDOC-02 controller rewrite (§3): `download()` gains `: BinaryFileResponse`. |
| PDOC-15 | QRY-02 on the two per-child lists, lowered to L and accepted: both lists are bounded by one child (5 rows live), and pagination would fight the blade's in-memory stats. Consistent with ParentEventController PEC-07. |