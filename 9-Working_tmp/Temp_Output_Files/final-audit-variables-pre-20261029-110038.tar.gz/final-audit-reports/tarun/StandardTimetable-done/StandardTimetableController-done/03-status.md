# Status — StandardTimetable / StandardTimetableController

**Fixed:** 2026-10-15 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
none

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| STT-01 | `StandardTimetableController.php` (15 methods) | The raw exception text is no longer sent to the browser. The central handler logs and renders errors (D1). | `grep -c 'getMessage()' <controller>` | `0` | 2026-10-15 |
| STT-02 | `StandardTimetableController.php` (all mutations) | Removed the controller try/catch. Every write now runs inside a `DB::transaction` closure (D1). | `grep -c 'catch (' <controller>` | `0` | 2026-10-15 |
| STT-03 | `StandardTimetableController.php`, `ManualTimetableService.php` | Manual `beginTransaction`/`commit` replaced with `DB::transaction` closures. | `grep -c beginTransaction` on both files | `0` / `0` | 2026-10-15 |
| STT-04 | `showTimetable()`, `editTimetable()` | Authorization runs before the record is loaded (`viewClass` / `manualPlace`). | read the method heads | gate is the first statement | 2026-10-15 |
| STT-05 | `StandardTimetableController.php` | Removed duplicated `manualPlace` gates where the FormRequest `authorize()` already runs. | `grep -n "manualPlace')" <controller>` | 3 left (99, 2900, 4374). The plan expected 4; `showTimetable` uses `viewClass` | 2026-10-15 |
| STT-07 | `routes/api.php` | Removed the `Route::apiResource('standardtimetables', …)` line. Its four methods never existed. The file now holds only a comment explaining the removal. | router probe | no `standardtimetables` route | 2026-10-15 |
| STT-08 | `routes/web.php:28` | `timetable/{id}/restore` changed from GET to **PUT**. `x-backend.table.action-trashed` takes its form verb from the route, so the blade did not need changing. | router probe | `restore=PUT` | 2026-10-15 |
| STT-12 | `index`, `classView`, `teacherView`, `roomView` | Added the `: View` return type and the `Illuminate\View\View` import. | `grep -c '): View' <controller>` | `4` | 2026-10-15 |
| STT-14 | `StandardTimetableController.php` | Deleted the unused `periodIsPlaceable()`. Its notes were merged into the `periodBlockReason()` docblock. | `grep -c periodIsPlaceable` | `0` | 2026-10-15 |
| STT-16 | `ManualTimetableService.php` (now 90 lines) | Deleted the unreachable `placeCell()`, `removeCell()`, `checkConflicts()` and `persistConflicts()`, plus the `ConflictDetection`/`Activity` imports. Kept `copyTimetable()` and `uniqueCopyName()`. | `class_exists` + `php -l` | OK | 2026-10-15 |
| STT-17 | `manualPlacement()` card map (~354/410) and `buildInsights()` (~1720/1728) | Both per-group queries are gone. A new private helper, `placedSlotsBySubActivity()` (~3816), does one grouped query on `tt_timetable_cells` and returns the unique `day-period` slots per `sub_activity_id`. Both callers read from that map. | `grep -c "DB::table('tt_timetable_cells')" <controller>` | `1` (only the helper itself) | 2026-10-15 |
| STT-19 | lines ~174 and ~2965 | Page size changed from 15 to 10. | `grep -c 'paginate(15'` | `0` | 2026-10-15 |
| STT-20 | `dayLabels()`, `classGroupIdsFor()` | Both static caches are now keyed by `DB::connection()->getDatabaseName()`. The class-group key also includes the snapshot id. | `grep -n getDatabaseName <controller>` | 2 cache keys | 2026-10-15 |
| STT-21 | policy + 5 FormRequests + service | Added `declare(strict_types=1);` to the 7 files that lacked it. | `grep -c '^declare(strict_types=1)'` on each file | `1` each | 2026-10-15 |
| STT-22 | controller + 4 requests | Removed the ⚠/⛔ glyphs. The displaced "Every sch_class_groups_jnt id…" docblock now sits above `classGroupIdsFor()`. | `grep -cP '[⚠⛔]' <controller>` | `0` | 2026-10-15 |
| STT-23 | all touched PHP files | Ran Pint on the touched files only, then re-ran `php -l` on each. | `vendor/bin/pint <files> --format agent` | pass | 2026-10-15 |
| STT-24 | `approve()`, `publish()` | Extracted a private `performPublish(Timetable $timetable): void`. Both methods call it. Both routes and both permissions are unchanged. | read the methods | one implementation | 2026-10-15 |
| — (follow-on) | `deleteTimetable`, `unpublish`, `copyTimetable` | TXN-05: these methods now build their response after the `DB::transaction` closure, not inside it. `copyTimetable` returns `$copy` from the closure. This fixes a pattern my own STT-01/02 conversion had introduced. | read the methods | response built after the closure | 2026-10-15 |
| — (follow-on) | controller comments | Rewrote stale comments ("OUTSIDE the try", "Rule A1 + A2", "generic catch") so they describe the D1 shape. | grep the old phrases | 0 | 2026-10-15 |

## 3. Not applied
| ID | Reason (not ticked / already applied / superseded / blocked) | Detail |
|---|---|---|
| STT-06 | decision (c): accepted dead code | `StandardTimetablePolicy` stays registered and unconsulted. It is now recorded as accepted. |
| STT-09 | decision (a): deferred to the split pass (D3) | 4,842 lines, 27 methods. |
| STT-10, STT-11, STT-13, STT-15 | no plan item | These belong to the deferred CTL-01 split (plan §10). |
| STT-18 | no plan item | Bounded per-row writes. `ManualTimetableService::copyTimetable()` still queries per row at lines ~71/74. That was STT-17's optional service sub-part and was not done. |
| TXN-05 (3 sites) | accepted | `placeCell`, `removeCell` and `moveCell` return a `JsonResponse` refusal from inside the closure. These are locked-state checks that run before any write, and the caller re-checks with `instanceof JsonResponse`. |

## 4. Needs Tarun's hand
- Browser check of **Restore** on the timetable trash page. The route is now PUT. The shared component should emit `@method('PUT')`; confirm one restore works.
- Browser check of `/standard-timetable/manual-placement?timetable_id=12&class_section_id=1`: the shared-group cards and the insights panel should show the same placed counts as before.
- No migrations to run, no seeders to run, no permission sync needed.

## 5. Unverifiable by this workflow (no tests, D4)
- STT-04/05 gate placement: proven only by reading the code. Every check here ran as super-admin, and `Gate::before` bypasses the gates.
- The PUT restore flowing through `x-backend.table.action-trashed`: not exercised.
- Test artefact: `tests/Unit/Architecture/missing-controller-methods.txt` lines 65-68 still list the four removed API routes. Not edited (D4).
- Doc drift: `prime_testing/Doc_Analysis/.../tts_DragAndDropGrid_*` may still describe the deleted service methods. Not edited.

## 6. Verification log
```
php -l  controller, service, policy, 5 requests, routes/*.php   -> no syntax errors (re-run after Pint)
class_exists StandardTimetableController / ManualTimetableService / StandardTimetablePolicy -> OK OK OK
router probe (app bootstrapped): routes=27 missing=0 restore=PUT ; no 'standardtimetables' route
controller greps: getMessage=0 catch=0 beginTransaction=0 paginate(15=0 glyphs=0 lines=4842
DB::table('tt_timetable_cells') in controller -> 1 (the placedSlotsBySubActivity helper)
'): View' -> 4 ; periodIsPlaceable -> 0 ; manualPlace gates -> 3 (99, 2900, 4374)
^declare(strict_types=1) -> 1 in each of the 7 files
scan.php (in-scope rows): only the deferred CTL-01/02/03/05/07, QRY-05/07/08/15 and
  TXN-01 (writeCellTeachers) rows remain, plus the 3 accepted TXN-05 refusal returns
vendor/bin/pint <touched files> --format agent -> pass
```

## 7. Final state
Status: FIXED · Open: B 0 · H 2 · M 3 · L 2
(H: STT-09, STT-10 · M: STT-06 accepted, STT-11, STT-15 · L: STT-13, STT-18. All of these are deferred to the split pass except STT-06, which is accepted.)
