# Fix Plan — StandardTimetable / StandardTimetableController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | shared registry — no permission change is planned |
| `Modules/StandardTimetable/routes/api.php` | route file; only a ticked DECISION may change it (STT-07) |
| `Modules/StandardTimetable/routes/web.php` | route file; only a ticked DECISION may change it (STT-08) |
| `resources/views/components/**` | shared Blade components (table.action, tab.search-bar, layouts) |
| `Modules/TimetableFoundation/app/Models/*` | owned by the TimetableFoundation reports (§5 of the report) |
| `Modules/TimetableFoundation/app/Support/Snapshot/*` except `SnapshotContext.php` | owned by the TimetableFoundation snapshot reports |
| any migration | never edit an existing migration |
| `Modules/StandardTimetable/tests/**` | D4 — no tests |

## 1. Blockers reachable today

- [x] **STT-01** · B · ERR-01 · `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:2288-2292` — stop returning the raw exception text to the browser (15 methods).
  - **Touches:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Before** (`StandardTimetableController.php:2288-2292`):
    ```php
            } catch (\Exception $e) {
                DB::rollBack();

                return response()->json(['success' => false, 'message' => 'Failed to place cell: '.$e->getMessage()], 500);
            }
    ```
  - **After:**
    ```php
            } catch (\Exception $e) {
                DB::rollBack();
                report($e);

                return response()->json(['success' => false, 'message' => 'The cell could not be placed. The error has been logged.'], 500);
            }
    ```
  - Apply the same replacement in the other fourteen catches, changing the fixed message and keeping `report($e)`:
    `moveCell` 2751, `createTimetable` 2838, `deleteTimetable` 2883, `assignTeacher` 3264, `assignRoom` 3531, `copyTimetable` 4424, `lockCell` 4465, `unlockCell` 4504, `lockAll` 4540, `unlockAll` 4587, `submitForApproval` 4627, `approve` 4685, `publish` 4740, `unpublish` 4788.
    Delete the `'.'.$e->getMessage()` concatenation and each method's own prefix; use these fixed texts: `'The cell could not be moved. The error has been logged.'`, `'The timetable could not be created. The error has been logged.'`, `'The timetable could not be deleted. The error has been logged.'`, `'The teacher could not be assigned. The error has been logged.'`, `'The room could not be assigned. The error has been logged.'`, `'The timetable could not be copied. The error has been logged.'`, `'The cell could not be locked. The error has been logged.'`, `'The cell could not be unlocked. The error has been logged.'`, `'The cells could not be locked. The error has been logged.'`, `'The cells could not be unlocked. The error has been logged.'`, `'The timetable could not be submitted. The error has been logged.'`, `'The timetable could not be approved. The error has been logged.'`, `'The timetable could not be published. The error has been logged.'`, `'The timetable could not be unpublished. The error has been logged.'`.
  - **Verify:** `grep -n "getMessage()" Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Expect:** no output.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [x] **STT-02** · M · ERR-00 · `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:2964-2977` — remove the controller try/catch (D1); let it be reported and rendered centrally.
  - **Touches:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Before** (`StandardTimetableController.php:2964-2977`):
    ```php
            try {
                DB::transaction(function () use ($timetable) {
                    $timetable->is_active = false;
                    $timetable->save();
                    $timetable->delete();

                    activityLog($timetable, 'Trashed', [
                        'message' => "Timetable '{$timetable->name}' was moved to trash.",
                        'performed_by' => auth()->user()?->name,
                    ]);
                });
            } catch (\Throwable $e) {
                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($timetable) {
                $timetable->is_active = false;
                $timetable->save();
                $timetable->delete();

                activityLog($timetable, 'Trashed', [
                    'message' => "Timetable '{$timetable->name}' was moved to trash.",
                    'performed_by' => auth()->user()?->name,
                ]);
            });
    ```
  - Apply the same `try`/`catch` removal to `restoreTimetable` 3019-3032 and `forceDeleteTimetable` 3057-3076, and, together with STT-03, to the sixteen manual-transaction methods.
  - **Verify:** `grep -cE '^\s*\} catch \(' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Expect:** `0`.
  - **Effort:** M

- [x] **STT-03** · M · TXN-02 · `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:4446-4461` — replace manual `beginTransaction`/`commit` with a `DB::transaction` closure.
  - **Touches:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`, `Modules/StandardTimetable/app/Services/ManualTimetableService.php`
  - **Before** (`StandardTimetableController.php:4446-4461`):
    ```php
            DB::beginTransaction();
            try {
                $cell->update([
                    'is_locked' => true,
                    'locked_at' => now(),
                    'locked_by' => auth()->id(),
                ]);

                activityLog($cell, 'Locked', [
                    'message' => "Cell locked at day {$cell->day_of_week}, period {$cell->period_ord}.",
                    'performed_by' => auth()->user()?->name,
                ]);

                DB::commit();
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($cell) {
                $cell->update([
                    'is_locked' => true,
                    'locked_at' => now(),
                    'locked_by' => auth()->id(),
                ]);

                activityLog($cell, 'Locked', [
                    'message' => "Cell locked at day {$cell->day_of_week}, period {$cell->period_ord}.",
                    'performed_by' => auth()->user()?->name,
                ]);
            });
    ```
  - Apply the same conversion in `placeCell` 2132, `removeCell` 2437, `moveCell` 2607, `createTimetable` 2805, `deleteTimetable` 2856, `assignTeacher` 3230, `assignRoom` 3496, `copyTimetable` 4409, `unlockCell` 4485, `lockAll` 4523, `unlockAll` 4568, `submitForApproval` 4614, `approve` 4649, `publish` 4704, `unpublish` 4770. Build every JSON/redirect response AFTER the closure returns. In `ManualTimetableService.php`, convert `placeCell()` (22-62) and `removeCell()` (67-75) the same way (or delete them with STT-16, whichever is ticked).
  - **Verify:** `grep -c 'DB::beginTransaction()' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Expect:** `0`.
  - **Effort:** M

## 4. Authorization (F3)

- [x] **STT-04** · M · AUTH-02 · `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:2931-2939` — authorize before loading the record.
  - **Touches:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Before** (`StandardTimetableController.php:2933-2939`):
    ```php
            // Scoped to MANUAL and not withTrashed(): a generated or soft-deleted timetable
            // has no business opening in the manual editor, and 404 is the honest answer.
            Timetable::where('generation_method', 'MANUAL')->findOrFail($id);

            $request->merge(['timetable_id' => $id]);

            return $this->manualPlacement($request);
    ```
  - **After:**
    ```php
            Gate::authorize('tenant.standard-timetable.timetable.manualPlace');

            // Scoped to MANUAL and not withTrashed(): a generated or soft-deleted timetable
            // has no business opening in the manual editor, and 404 is the honest answer.
            Timetable::where('generation_method', 'MANUAL')->findOrFail($id);

            $request->merge(['timetable_id' => $id]);

            return $this->manualPlacement($request);
    ```
  - Also in `showTimetable` (2898-2911): add `Gate::authorize('tenant.standard-timetable.timetable.viewClass');` as the first statement, before the `ClassSection` query.
  - **Verify:** `sed -n '2898,2905p;2931,2936p' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php | grep -n 'Gate::authorize'`
  - **Expect:** two `Gate::authorize` lines, one in each method's head.
  - **Effort:** S

- [x] **STT-05** · L · AUTH-04 · `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:1984-1986` — remove the duplicated authorization; keep the FormRequest `authorize()` (it runs first).
  - **Touches:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Before** (`StandardTimetableController.php:1984-1986`):
    ```php
            Gate::authorize('tenant.standard-timetable.timetable.manualPlace');

            $validated = $request->validated();
    ```
  - **After:**
    ```php
            $validated = $request->validated();
    ```
  - Delete the same `Gate::authorize('tenant.standard-timetable.timetable.manualPlace');` line (and its trailing blank) in `removeCell` 2361, `moveCell` 2553, `createTimetable` 2776, `assignTeacher` 3179 and `assignRoom` 3425. Those six methods all receive a FormRequest whose `authorize()` checks the same permission.
  - **Verify:** `grep -c "Gate::authorize('tenant.standard-timetable.timetable.manualPlace')" Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Expect:** `4` (the four remaining callers without a FormRequest: `manualPlacement`, `copyTimetable`, and the two delegated-through methods `showTimetable`/`editTimetable` if STT-04 was applied — recount after both items are applied).
  - **Effort:** S

## 5. Validation, routes, models and controller shape (F4/F5/F6/F7)

- [x] **STT-12** · L · CTL-04 · `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:42` — add return types to four view methods.
  - **Touches:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Before** (`StandardTimetableController.php:42-43`):
    ```php
        public function index()
        {
    ```
  - **After:**
    ```php
        public function index(): View
        {
    ```
  - Add `use Illuminate\View\View;` to the import block, and add `: View` to `classView` (4792), `teacherView` (4861) and `roomView` (4911).
  - **Verify:** `grep -nE 'public function (index|classView|teacherView|roomView)\(' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Expect:** four lines ending in `: View`.
  - **Effort:** S

- [x] **STT-14** · M · CTL-10 · `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:1338-1341` — delete the unused private method.
  - **Touches:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Before** (`StandardTimetableController.php:1338-1341`):
    ```php
        private function periodIsPlaceable(?object $period): bool
        {
            return $this->periodBlockReason($period) === null;
        }
    ```
  - **After:**
    ```php
        // periodIsPlaceable() was removed (CTL-10): no call sites, periodBlockReason() is the live API.
    ```
  - Delete the method's own docblock (lines 1314-1337) as well.
  - **Verify:** `grep -n 'periodIsPlaceable' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **STT-17** · H · QRY-01 · `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:407-417` — remove the per-group query in the card map.
  - **Touches:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Before** (`StandardTimetableController.php:407-417`):
    ```php
                        $placedSlots = $selectedTimetableId
                            ? DB::table('tt_timetable_cells')
                                ->where('timetable_id', $selectedTimetableId)
                                ->where('sub_activity_id', $group->id)
                                ->whereNull('deleted_at')
                                ->where('is_active', true)
                                ->selectRaw('DISTINCT day_of_week, period_ord')
                                ->get()
                                ->map(fn ($c) => $c->day_of_week.'-'.$c->period_ord)
                                ->values()
                            : collect();
    ```
  - **After:**
    ```php
                        $placedSlots = $placedSlotsByGroup[$group->id] ?? collect();
    ```
  - Then make two further edits in the same method: (1) immediately before `$groupCards = SubActivity::query()` (line 353) insert `$placedSlotsByGroup = $this->placedSlotsBySubActivity($selectedTimetableId);`; (2) change that map's closure header `->map(function ($group) use ($selectedTimetableId) {` (line 373) to `->map(function ($group) use ($selectedTimetableId, $placedSlotsByGroup) {`.
  - **Before** (new helper anchor): insert this method immediately after `classGroupIdsFor()` (ends line 3864):
    ```php
        private function classGroupIdsFor(int $classId, int $sectionId): array
        {
            static $cache = [];
            // Snapshot id in the key: inside a snapshot the table is a tt_snap_* mirror
            // with ENCODED ids, and a long-lived process (queue worker) can serve both a
            // live and a snapshot read. A class:section-only key leaked live ids into a
            // snapshot read and would drop shared cells (Phase 2, 2026-10-08).
            $key = (app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
    ```
  - **After:**
    ```php
        private function classGroupIdsFor(int $classId, int $sectionId): array
        {
            static $cache = [];
            // Snapshot id in the key: inside a snapshot the table is a tt_snap_* mirror
            // with ENCODED ids, and a long-lived process (queue worker) can serve both a
            // live and a snapshot read. A class:section-only key leaked live ids into a
            // snapshot read and would drop shared cells (Phase 2, 2026-10-08).
            $key = (app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
    ```
    Insert the helper immediately after this method:
    ```php
        /**
         * Every shared group's placed slots in one timetable, keyed by sub_activity_id.
         *
         * @return array<int, \Illuminate\Support\Collection<int, string>>
         */
        private function placedSlotsBySubActivity(?int $timetableId): array
        {
            if (! $timetableId) {
                return [];
            }

            return DB::table('tt_timetable_cells')
                ->where('timetable_id', $timetableId)
                ->whereNotNull('sub_activity_id')
                ->whereNull('deleted_at')
                ->where('is_active', true)
                ->select('sub_activity_id', 'day_of_week', 'period_ord')
                ->get()
                ->groupBy('sub_activity_id')
                ->map(fn ($rows) => $rows
                    ->map(fn ($c) => $c->day_of_week.'-'.$c->period_ord)
                    ->unique()
                    ->values())
                ->all();
        }
    ```
  - The same pre-fetch pattern applies to `buildInsights()` at 1737-1746 (one query per shared group) and the service loops in `ManualTimetableService.php` 44-53 and 128-142; apply it there too if time permits.
  - **Verify:** `grep -n "placedSlotsBySubActivity" Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Expect:** three lines (declaration plus two call sites).
  - **Effort:** M

- [x] **STT-19** · L · QRY-02 · `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:171-174` — page size 15 → 10.
  - **Touches:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Before** (`StandardTimetableController.php:171-174`):
    ```php
                ->when($listStatus !== '', fn ($q) => $q->where('status', $listStatus))
                ->orderByDesc('created_at')
                ->paginate(15)
                ->withQueryString();
    ```
  - **After:**
    ```php
                ->when($listStatus !== '', fn ($q) => $q->where('status', $listStatus))
                ->orderByDesc('created_at')
                ->paginate(10)
                ->withQueryString();
    ```
  - Change the second `->paginate(15)` in `trashedTimetables()` (line 3001) to `->paginate(10)`.
  - **Verify:** `grep -n 'paginate(15)' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **STT-20** · M · TEN-02 · `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:3845-3852` — key both static caches on the tenant.
  - **Touches:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Before** (`StandardTimetableController.php:3845-3852`):
    ```php
        private function classGroupIdsFor(int $classId, int $sectionId): array
        {
            static $cache = [];
            // Snapshot id in the key: inside a snapshot the table is a tt_snap_* mirror
            // with ENCODED ids, and a long-lived process (queue worker) can serve both a
            // live and a snapshot read. A class:section-only key leaked live ids into a
            // snapshot read and would drop shared cells (Phase 2, 2026-10-08).
            $key = (app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
    ```
  - **After:**
    ```php
        private function classGroupIdsFor(int $classId, int $sectionId): array
        {
            static $cache = [];
            // Tenant + snapshot id in the key: inside a snapshot the table is a tt_snap_*
            // mirror with ENCODED ids, and a long-lived process (Octane, queue worker) can
            // serve more than one tenant. A key without the tenant leaked ids across schools.
            $key = DB::connection()->getDatabaseName().':'
                .(app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
    ```
  - **Before** (`StandardTimetableController.php:3756-3765`, method `dayLabels()`):
    ```php
        private function dayLabels(): array
        {
            static $labels = null;

            if ($labels === null) {
                $labels = SchoolDay::where('is_active', true)->pluck('short_name', 'day_of_week')->all();
            }

            return $labels;
        }
    ```
  - **After:**
    ```php
        private function dayLabels(): array
        {
            static $labels = [];

            $tenantKey = DB::connection()->getDatabaseName();

            if (! array_key_exists($tenantKey, $labels)) {
                $labels[$tenantKey] = SchoolDay::where('is_active', true)->pluck('short_name', 'day_of_week')->all();
            }

            return $labels[$tenantKey];
        }
    ```
  - **Verify:** `grep -n 'getDatabaseName' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Expect:** two lines.
  - **Effort:** S

## 7. Views (F10)

None — the view family is clean (see report §6 F10).

## 8. Style (F12) — one item per file

- [x] **STT-21** · L · STY-01 · `Modules/StandardTimetable/app/Policies/StandardTimetablePolicy.php:1` — add strict types to seven files.
  - **Touches:** `Modules/StandardTimetable/app/Policies/StandardTimetablePolicy.php`, `Modules/StandardTimetable/app/Services/ManualTimetableService.php`, `Modules/StandardTimetable/app/Http/Requests/AssignRoomRequest.php`, `Modules/StandardTimetable/app/Http/Requests/AssignTeacherRequest.php`, `Modules/StandardTimetable/app/Http/Requests/CreateTimetableRequest.php`, `Modules/StandardTimetable/app/Http/Requests/PlaceCellRequest.php`, `Modules/StandardTimetable/app/Http/Requests/RemoveCellRequest.php`
  - **Before** (`StandardTimetablePolicy.php:1-3`):
    ```php
    <?php

    namespace Modules\StandardTimetable\Policies;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StandardTimetable\Policies;
    ```
  - Insert the same `declare(strict_types=1);` line (with its blank line) after `<?php` in the other six files.
  - **Verify:** `for f in Modules/StandardTimetable/app/Policies/StandardTimetablePolicy.php Modules/StandardTimetable/app/Services/ManualTimetableService.php Modules/StandardTimetable/app/Http/Requests/AssignRoomRequest.php Modules/StandardTimetable/app/Http/Requests/AssignTeacherRequest.php Modules/StandardTimetable/app/Http/Requests/CreateTimetableRequest.php Modules/StandardTimetable/app/Http/Requests/PlaceCellRequest.php Modules/StandardTimetable/app/Http/Requests/RemoveCellRequest.php; do printf "%s: " "$f"; grep -c 'declare(strict_types' "$f"; done`
  - **Expect:** seven lines, each ending `: 1`.
  - **Effort:** S

- [x] **STT-22** · L · STY-04 · `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:114` — remove the emoji markers and fix the displaced docblock.
  - **Touches:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`, `Modules/StandardTimetable/app/Http/Requests/AssignRoomRequest.php`, `Modules/StandardTimetable/app/Http/Requests/AssignTeacherRequest.php`, `Modules/StandardTimetable/app/Http/Requests/CreateTimetableRequest.php`, `Modules/StandardTimetable/app/Http/Requests/PlaceCellRequest.php`, `Modules/StandardTimetable/app/Services/ManualTimetableService.php`
  - **Before** (`StandardTimetableController.php:114-121`):
    ```php
            // ⚠ CAST AT THE BOUNDARY. A query string is always STRINGS, and this class
            // declares strict_types=1, so handing "13" to a typed ?int helper is a TypeError
            // and a 500 on a page that is otherwise fine. Kept as null (not 0) when absent, so
            // `if ($selectedTimetableId)` and every route() that echoes it back behave as
            // before. Same family as the form-encoded-int trap in placeCell.
            $selectedTimetableId = $request->filled('timetable_id')
                ? (int) $request->input('timetable_id')
                : null;
    ```
  - **After:**
    ```php
            // CAST AT THE BOUNDARY. A query string is always STRINGS, and this class
            // declares strict_types=1, so handing "13" to a typed ?int helper is a TypeError
            // and a 500 on a page that is otherwise fine. Kept as null (not 0) when absent, so
            // `if ($selectedTimetableId)` and every route() that echoes it back behave as
            // before. Same family as the form-encoded-int trap in placeCell.
            $selectedTimetableId = $request->filled('timetable_id')
                ? (int) $request->input('timetable_id')
                : null;
    ```
  - Remove the leading glyph from every marked comment in the six named files with: `perl -CSD -i -pe 's/^(\s*\/\/\s*)\x{26A0}\x{FE0F}?\s*/$1/; s/^(\s*\/\/\s*)\x{26D4}\s*/$1/' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php Modules/StandardTimetable/app/Http/Requests/AssignRoomRequest.php Modules/StandardTimetable/app/Http/Requests/AssignTeacherRequest.php Modules/StandardTimetable/app/Http/Requests/CreateTimetableRequest.php Modules/StandardTimetable/app/Http/Requests/PlaceCellRequest.php Modules/StandardTimetable/app/Services/ManualTimetableService.php`. Then move the docblock at lines 3596-3604 so it sits immediately above `classGroupIdsFor()` (line 3845) instead of above `companionGrid()`.
  - **Verify:** `grep -c '⚠\|⛔' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php`
  - **Expect:** `0`.
  - **Effort:** M

## 9. Deferred / decisions

- [x] **STT-06** · M · DECISION · AUTH-06 — the registered StandardTimetablePolicy is never consulted; what should happen to it?
  - **Why it is a decision:** removing a policy registration and class, or wiring model-ability checks, is an architecture choice.
  - (a) ⭐ delete `Modules/StandardTimetable/app/Policies/StandardTimetablePolicy.php` and the `registerPolicies()` call in `StandardTimetableServiceProvider.php` — dead code removed, no behaviour change.
  - (b) wire the policy: replace the string `Gate::authorize('…')` calls with `$this->authorize('<ability>', $timetable)`.
  - (c) leave it and record it as accepted dead code.
  - ➜ Choice: (c) — keep as accepted dead code (Tarun, 2026-10-15)

- [x] **STT-07** · B · DECISION · RTE-02 — four API routes point at methods that do not exist.
  - **Why it is a decision:** it adds or removes routes (`Modules/StandardTimetable/routes/api.php`).
  - (a) ⭐ remove the `Route::apiResource('standardtimetables', …)` line — the module has no JSON API and nothing calls it.
  - (b) implement `store`/`show`/`update`/`destroy` as JSON methods on the controller.
  - (c) leave the routes and accept the 500s.
  - ➜ Choice: (a) — removed the apiResource line (2026-10-15)

- [x] **STT-08** · H · DECISION · RTE-01 — restoreTimetable changes state over GET.
  - **Why it is a decision:** it re-scopes a route (`Modules/StandardTimetable/routes/web.php`) and needs the trash action component to POST.
  - (a) ⭐ change the route to `Route::post(...)` and have `x-backend.table.action-trashed` submit a form for Restore.
  - (b) keep GET and accept the prefetch risk.
  - (c) add a signed-URL GET that expires.
  - ➜ Choice: (a) — but changed to **PUT**, not POST, to match the house restore verb (2026-10-15)

- [x] **STT-09** · H · DECISION · CTL-01 — split the 4,950-line, 27-method god controller?
  - **Why it is a decision:** D3 defers the god-controller split.
  - (a) ⭐ defer to the split pass (D3) — this audit does not split it.
  - (b) split now into CRUD / workflow / grid-read / grid-write controllers.
  - (c) accept as-is and record.
  - ➜ Choice: (a) — deferred to the split pass, D3 (2026-10-15)

- [x] **STT-16** · M · DECISION · SVC-04 — ManualTimetableService holds an unreachable second implementation of place/remove/conflicts.
  - **Why it is a decision:** deleting public service methods is a separate call.
  - (a) ⭐ delete the unreachable `placeCell()`, `removeCell()`, `checkConflicts()` and `persistConflicts()` (and the unused `ConflictDetection` import); keep only `copyTimetable()` and `uniqueCopyName()`.
  - (b) keep them and mark `@deprecated` with the reason.
  - (c) leave as-is.
  - ➜ Choice: (a) — deleted the four unreachable methods (2026-10-15)

- [x] **STT-24** · M · DECISION · SVC-04 — approve() and publish() duplicate the publish operation.
  - **Why it is a decision:** it changes who can reach the published state (`publish` currently bypasses the `approve` permission).
  - (a) ⭐ extract one private `performPublish(Timetable $timetable): void` and have both `approve()` and `publish()` call it, so there is one implementation; keep both routes and permissions.
  - (b) keep both bodies and add a comment documenting the deliberate shortcut.
  - (c) remove the `publish()` shortcut so only `approve()` can publish.
  - ➜ Choice: (a) — extracted performPublish() (2026-10-15)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| STT-10 | CTL-02 method length — extracted only as part of the deferred CTL-01 split (D3). |
| STT-11 | CTL-03 route model binding — must move with the split so the `MANUAL`/`onlyTrashed` scope is preserved. |
| STT-13 | CTL-07 compact() — the view-model rework belongs to the deferred split. |
| STT-15 | CTL-05 duplicated eager-load — extract a shared helper during the split. |
| STT-18 | QRY-07 per-row writes — every loop is bounded to 1-2 rows; batch it only if STT-17 is applied. |
| STT-23 | STY-02 — the fix is a formatter run (`vendor/bin/pint <file> --format agent`); do it last, after the STT-21/STT-22 hand edits. |
