# Status — SmartTimetable / TimetablePublishController

**Fixed:** 2026-10-15 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

Decisions (Tarun, 2026-10-15):
- TPB-04: lock the publish (option a).
- TPB-05: declined. Keep Gate → `findOrFail()` so a user without permission gets the same 403 for real and missing ids.
- TPB-06: deferred (option a).

## 1. Pre-applied work
none

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| TPB-01 | TimetablePublishController.php (publishTimetable, unpublishTimetable) | Both controller try/catch blocks removed (D1). The `Log` and `Throwable` imports are gone. A failure now goes to the central handler, which logs it and returns `{success:false, message}` (500); in production the message is generic. The JS failure branch reads the same shape. | `grep -nE "try \{\|catch \(Throwable\|getMessage\|Log::error"` | no output | 2026-10-15 |
| TPB-02 | — | Closed by TPB-01: the `Log::error` that recorded only `getMessage()` is deleted. The handler reports the full exception. | same grep | no output | 2026-10-15 |
| TPB-03 | — | Closed by TPB-01. | same grep | no output | 2026-10-15 |
| TPB-04 | TimetablePublishController.php:55-152 | Readiness check, write, archive and log now all run inside one `DB::transaction`. The transaction first locks **every timetable in the scope** (session, term, type, period set), ordered by id, with `lockForUpdate()`, then re-runs `TimetableReadiness::check()` on the locked row. The response is built after the closure. ⚠ This deliberately goes further than the plan's literal "lock the publish row": locking one row cannot serialise two *different* timetables of the same scope. Each transaction would hold its own row and wait on the other inside `archiveOthersInScope()`, and MySQL would kill one with a deadlock 500. The scope lock makes the second publish wait, then archive the first: last publish wins. | `grep -n "lockForUpdate\|readiness->check"` | 73, 80 | 2026-10-15 |
| TPB-07 | TimetablePublishController.php, TimetableReadiness.php | `⛔` → `IMPORTANT:`, `⚠` → `NOTE:` (controller 6 markers, service 5) | `grep -nE "⛔\|⚠"` both files | no output | 2026-10-15 |
| TPB-08 | TimetableReadiness.php:7,60,70 | `assert()` throws `DomainException`, and the import and `@throws` match. The only caller is the dead `TimetableStorageService::publishTimetable()` (no route reaches it), so no live path changes. | `grep -n RuntimeException` | no output | 2026-10-15 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| TPB-05 | blocked by decision | Route-model binding resolves the record **before** the Gate, which would answer 404 vs 403 depending on whether the id exists (an existence oracle). Both methods keep `int $id` with Gate → `findOrFail()`. The reason is recorded in the controller docblock. Under TPB-04 the record is re-loaded under the lock anyway. |
| TPB-06 | deferred (choice a) | `publishTimetable()` is longer now, but most of its length is the explanatory comments, kept on purpose. Splitting it waits for the D3 split pass. |

## 4. Needs Tarun's hand
- **Browser check:** on View & Refinement → Publish Timetable:
  - Publish a complete timetable. Expect success.
  - Publish an incomplete one. Expect the confirmation dialog listing the reasons; confirming publishes it and logs `readiness_bypassed`.
  - Unpublish one. Expect it to revert to Draft.
- **Behaviour change:** a failed publish/unpublish used to show `Failed to publish timetable: <raw SQL text>`. It now shows the central handler's message, which is generic in production (D1).
- No migration, seeder or permission sync is needed.

## 5. Unverifiable by this workflow (no tests, D4)
- TPB-04's serialisation of two simultaneous publishes in the same scope. Proving it needs two concurrent requests, which static checks cannot do.

## 6. Verification log
```
$ vendor/bin/pint TimetablePublishController.php TimetableReadiness.php --format agent
{"tool":"pint","result":"passed"}
$ php -l (both files)
No syntax errors detected (×2)
$ class_exists(TimetablePublishController), class_exists(TimetableReadiness)
bool(true) bool(true)
$ router probe
smart-timetable.timetable.publish   smart-timetable/timetable/{id}/publish   OK
smart-timetable.timetable.unpublish smart-timetable/timetable/{id}/unpublish OK
$ grep TPB-01 / TPB-08 / TPB-07 checks → no output (all three)
$ grep lockForUpdate|readiness->check → 73, 80
```

## 7. Final state
Status: FIXED · Open: B 0 · H 0 · M 2 · L 0 (TPB-05 declined, TPB-06 deferred)
