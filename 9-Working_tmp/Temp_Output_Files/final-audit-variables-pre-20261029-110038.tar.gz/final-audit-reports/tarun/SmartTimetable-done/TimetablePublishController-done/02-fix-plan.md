# Fix Plan — SmartTimetable / TimetablePublishController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each item that touches a file other controllers use is marked `⚠ SHARED`. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php` | route file — shared; no item here edits it |
| `Modules/TimetableFoundation/app/Models/Timetable.php` | owned by `TimetableFoundation/TimetableController`, linked only |
| `app/Helpers/activityLog.php` | common app helper |
| `Modules/SmartTimetable/resources/views/pages/partials/view-and-refinement/publish-timetable/_list.blade.php` | owned by TimetableMenuController; recorded as a cross-cutting note only |
| `Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php` | dead method noted in §7 of the report; not this controller's class |

## 1. Blockers reachable today

- [x] **TPB-01** · B · ERR-01 · `TimetablePublishController.php:82-137` — remove the two controller try/catch blocks so a failure renders through the central handler instead of leaking the raw exception text.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php`
  - **Before** (`TimetablePublishController.php:12-15` — the imports that exist only for the catch):
    ```php
    use Illuminate\Support\Facades\Log;
    use Modules\SmartTimetable\Services\Publishing\TimetableReadiness;
    use Modules\TimetableFoundation\Models\Timetable;
    use Throwable;
    ```
  - **After:**
    ```php
    use Modules\SmartTimetable\Services\Publishing\TimetableReadiness;
    use Modules\TimetableFoundation\Models\Timetable;
    ```
  - **Before** (`TimetablePublishController.php:82-137` — `publishTimetable()`):
    ```php
        try {
            DB::transaction(function () use ($timetable, $readiness, $bypassed) {
                $timetable->update([
                    'published_at' => now(),
                    'published_by' => auth()->id(),
                    'status' => 'PUBLISHED',
                    'is_active' => true,   // is_active mirrors status — Timetable::booted() enforces it too
                ]);

                // One published timetable per scope (snapshot v5, T3.3) — the same
                // rule TimetableStorageService::publishTimetable() applies.
                $timetable->archiveOthersInScope();

                /*
                 * ⛔ PUBLISHING CHANGES THE STATUS ONLY — it writes NO tt_timetable_assignments row.
                 * Reverses the 2026-09-08 D5 behaviour on 2026-09-11, on instruction.
                 *
                 * makeSchoolDefault() repointed the school's default on EVERY publish, so re-publishing
                 * any timetable silently took over the default and overwrote whatever the administrator
                 * had attached by hand. Which timetable is in force is now a deliberate, manual act:
                 * View & Refinement → Class Assignment.
                 *
                 * ⛔ AND SINCE 2026-09-11 THERE IS NOTHING BEHIND IT. PublishedTimetable's
                 * "most recently published" fallback was removed the same day, so a class with no
                 * assignment row covering today sees NO timetable at all — the student, parent and
                 * teacher portals render their empty state. That is the rule now, not a regression:
                 * publishing sets a status; attaching is a separate, deliberate act on
                 * View & Refinement → Class Assignment.
                 *
                 * ⛔ DO NOT RE-ADD THE CALL HERE. TimetableAssignment::makeSchoolDefault() is kept,
                 * uncalled, for a future explicit "make this the default" button — not for publish.
                 */

                // Rule A3 — logged AFTER the write so a failed update cannot leave
                // behind a row claiming a publish that never happened.
                /* The message records the bypass. An audit row claiming a clean publish
                   when 30 periods were missing would be a false trail, and this log is the
                   only place that difference survives. */
                activityLog($timetable, 'Published', [
                    'message' => $bypassed
                        ? "Timetable '{$timetable->name}' was published with "
                          ."{$readiness['unplaced_periods']} period(s) still unplaced, confirmed by the user."
                        : "Timetable '{$timetable->name}' was published.",
                    'status' => 'PUBLISHED',
                    'unplaced_periods' => $readiness['unplaced_periods'],
                    'readiness_bypassed' => $bypassed,
                ]);
            });
        } catch (Throwable $e) {
            Log::error('Timetable publish failed', ['timetable_id' => $id, 'error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to publish timetable: '.$e->getMessage(),
            ], 500);
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($timetable, $readiness, $bypassed) {
            $timetable->update([
                'published_at' => now(),
                'published_by' => auth()->id(),
                'status' => 'PUBLISHED',
                'is_active' => true,   // is_active mirrors status — Timetable::booted() enforces it too
            ]);

            // One published timetable per scope (snapshot v5, T3.3) — the same
            // rule TimetableStorageService::publishTimetable() applies.
            $timetable->archiveOthersInScope();

            /*
             * ⛔ PUBLISHING CHANGES THE STATUS ONLY — it writes NO tt_timetable_assignments row.
             * Reverses the 2026-09-08 D5 behaviour on 2026-09-11, on instruction.
             *
             * makeSchoolDefault() repointed the school's default on EVERY publish, so re-publishing
             * any timetable silently took over the default and overwrote whatever the administrator
             * had attached by hand. Which timetable is in force is now a deliberate, manual act:
             * View & Refinement → Class Assignment.
             *
             * ⛔ AND SINCE 2026-09-11 THERE IS NOTHING BEHIND IT. PublishedTimetable's
             * "most recently published" fallback was removed the same day, so a class with no
             * assignment row covering today sees NO timetable at all — the student, parent and
             * teacher portals render their empty state. That is the rule now, not a regression:
             * publishing sets a status; attaching is a separate, deliberate act on
             * View & Refinement → Class Assignment.
             *
             * ⛔ DO NOT RE-ADD THE CALL HERE. TimetableAssignment::makeSchoolDefault() is kept,
             * uncalled, for a future explicit "make this the default" button — not for publish.
             */

            // Rule A3 — logged AFTER the write so a failed update cannot leave
            // behind a row claiming a publish that never happened.
            /* The message records the bypass. An audit row claiming a clean publish
               when 30 periods were missing would be a false trail, and this log is the
               only place that difference survives. */
            activityLog($timetable, 'Published', [
                'message' => $bypassed
                    ? "Timetable '{$timetable->name}' was published with "
                      ."{$readiness['unplaced_periods']} period(s) still unplaced, confirmed by the user."
                    : "Timetable '{$timetable->name}' was published.",
                'status' => 'PUBLISHED',
                'unplaced_periods' => $readiness['unplaced_periods'],
                'readiness_bypassed' => $bypassed,
            ]);
        });
    ```
  - **Before** (`TimetablePublishController.php:159-180` — `unpublishTimetable()`):
    ```php
        try {
            DB::transaction(function () use ($timetable) {
                $timetable->update([
                    'published_at' => null,
                    'published_by' => null,
                    'status' => 'DRAFT',
                    'is_active' => false,  // no longer published ⇒ not active
                ]);

                activityLog($timetable, 'Unpublished', [
                    'message' => "Timetable '{$timetable->name}' was reverted to draft.",
                    'status' => 'DRAFT',
                ]);
            });
        } catch (Throwable $e) {
            Log::error('Timetable unpublish failed', ['timetable_id' => $id, 'error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to unpublish timetable: '.$e->getMessage(),
            ], 500);
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($timetable) {
            $timetable->update([
                'published_at' => null,
                'published_by' => null,
                'status' => 'DRAFT',
                'is_active' => false,  // no longer published ⇒ not active
            ]);

            activityLog($timetable, 'Unpublished', [
                'message' => "Timetable '{$timetable->name}' was reverted to draft.",
                'status' => 'DRAFT',
            ]);
        });
    ```
  - **Verify:** `grep -nE "try \{|catch \(Throwable|getMessage|Log::error" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php`
  - **Expect:** no output.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

## 3. Errors & transactions (F1/F2)

- [x] **TPB-08** · M · ERR-01 · `TimetableReadiness.php:70-73` — throw `\DomainException` for the business refusal so no caller catches a `RuntimeException` (which `QueryException` extends).
  - **Touches:** `Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php`
  - **Before** (`TimetableReadiness.php:7-9`):
    ```php
    use Illuminate\Support\Facades\DB;
    use Modules\TimetableFoundation\Models\Timetable;
    use RuntimeException;
    ```
  - **After:**
    ```php
    use DomainException;
    use Illuminate\Support\Facades\DB;
    use Modules\TimetableFoundation\Models\Timetable;
    ```
  - **Before** (`TimetableReadiness.php:60`):
    ```php
         * @throws RuntimeException when the timetable is not ready
    ```
  - **After:**
    ```php
         * @throws DomainException when the timetable is not ready
    ```
  - **Before** (`TimetableReadiness.php:70-73`):
    ```php
            throw new RuntimeException(
                'This timetable cannot be published yet. '.implode(' ', $result['reasons'])
                .' Finish it on the editing screen, then publish.'
            );
    ```
  - **After:**
    ```php
            throw new DomainException(
                'This timetable cannot be published yet. '.implode(' ', $result['reasons'])
                .' Finish it on the editing screen, then publish.'
            );
    ```
  - **Verify:** `grep -n "RuntimeException" Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **TPB-05** (NOT APPLIED — declined 2026-10-15: binding runs before the Gate and would leak 404 vs 403; see 03-status §3) · M · CTL-03 · `TimetablePublishController.php:34,38,153,157` — type-hint the existing route parameter so the model is bound by the router instead of resolved by hand.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php`
  - **Before** (`TimetablePublishController.php:34-38`):
    ```php
        public function publishTimetable(int $id, Request $request): JsonResponse
        {
            Gate::authorize('tenant.smart-timetable.timetable.update');

            $timetable = Timetable::findOrFail($id);
    ```
  - **After:**
    ```php
        public function publishTimetable(Timetable $id, Request $request): JsonResponse
        {
            Gate::authorize('tenant.smart-timetable.timetable.update');

            $timetable = $id;
    ```
  - **Before** (`TimetablePublishController.php:153-157`):
    ```php
        public function unpublishTimetable(int $id): JsonResponse
        {
            Gate::authorize('tenant.smart-timetable.timetable.update');

            $timetable = Timetable::findOrFail($id);
    ```
  - **After:**
    ```php
        public function unpublishTimetable(Timetable $id): JsonResponse
        {
            Gate::authorize('tenant.smart-timetable.timetable.update');

            $timetable = $id;
    ```
  - **Verify:** `grep -n "findOrFail" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

## 7. Views (F10)

## 8. Style (F12) — one item per file

- [x] **TPB-07** · L · STY-04 · `TimetablePublishController.php:41,52,64,96,104,111` and `TimetableReadiness.php:18,23,79,85,112` — replace the pictograph comment markers with plain words.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php`, `Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php`
  - **Before** (`TimetablePublishController.php:40-42`):
    ```php
            /*
            | ⛔ COMPLETE AND CLASH-FREE, OR NOT AT ALL.
            |
    ```
  - **After:** (every controller marker line, replaced by the rule `⛔ ` → `IMPORTANT: ` and `⚠ ` → `NOTE: `)
    ```php
    // line 41
    | IMPORTANT: COMPLETE AND CLASH-FREE, OR NOT AT ALL.
    // line 52
    /* NOTE: AN INCOMPLETE TIMETABLE IS A WARNING TO CONFIRM, NOT AN ERROR TO REFUSE.
    // line 64
     * IMPORTANT: The gate is NOT gone. Without confirm=1 this still refuses, so nothing
    // line 96
     * IMPORTANT: PUBLISHING CHANGES THE STATUS ONLY — it writes NO tt_timetable_assignments row.
    // line 104
     * IMPORTANT: AND SINCE 2026-09-11 THERE IS NOTHING BEHIND IT. PublishedTimetable's
    // line 111
     * IMPORTANT: DO NOT RE-ADD THE CALL HERE. TimetableAssignment::makeSchoolDefault() is kept,
    ```
  - **Before** (`TimetableReadiness.php:18`):
    ```php
     * ⛔ ONE DEFINITION, SHARED BY EVERY PUBLISH PATH. There are three ways to publish
    ```
  - **After:** (every service marker line)
    ```php
    // line 18
     * IMPORTANT: ONE DEFINITION, SHARED BY EVERY PUBLISH PATH. There are three ways to publish
    // line 23
     * NOTE: NOT A UI CONCERN. The screens should of course say why the button is refused,
    // line 79
     * NOTE: SUMMED PER ACTIVITY as max(0, required - placed), never as
    // line 85
     * NOTE: Counts cells through the ACTIVITY. A shared group's cell reaches its class
    // line 112
     * NOTE: is_active IS NOT FILTERED, and that is the point. The generator writes
    ```
  - **Verify:** `grep -nE "⛔|⚠" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **TPB-04** · H · DECISION · TXN-06 — lock the publish row (or add a unique index) so two concurrent publishes cannot archive the live timetable.
  - **Why it is a decision:** the recommended fix changes concurrency behaviour on a write path; the index option needs an additive migration on `tt_timetables`.
  - (a) ⭐ resolve the timetable with `lockForUpdate()` inside `DB::transaction` and re-run the readiness check there, matching the lock the now-dead `TimetableStorageService::publishTimetable()` used.
  - (b) leave the code as is and record the race as accepted — publishing is a rare manual admin action.
  - (c) add a unique index allowing one PUBLISHED row per (`academic_session_id`, `academic_term_id`, `timetable_type_id`, `period_set_id`) and catch the duplicate — needs an additive migration.
  - ➜ Choice: (a) — applied 2026-10-15 as a lock on every timetable in the scope, ordered by id (one row cannot serialise two different timetables of the same scope); readiness re-checked under the lock.

- [x] **TPB-06** · M · DECISION · CTL-02 — `publishTimetable()` is 113 lines; extract it?
  - **Why it is a decision:** it refactors a live write path; the method is mostly explanatory comments.
  - (a) ⭐ defer — the excess is comments, the executable body is about 40 lines, and D3 defers structural work.
  - (b) extract the "not ready" JSON response and the success response into private methods now.
  - (c) accept and record.
  - ➜ Choice: (a) defer — 2026-10-15.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TPB-02 | No separate item: plan item TPB-01 deletes the catch that logs `$e->getMessage()`. |
| TPB-03 | No separate item: plan item TPB-01 deletes both controller try/catch blocks. |
