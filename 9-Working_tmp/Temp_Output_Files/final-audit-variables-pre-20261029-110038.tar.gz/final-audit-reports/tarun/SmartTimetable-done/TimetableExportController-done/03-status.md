# Status — SmartTimetable / TimetableExportController

**Fixed:** 2026-10-16 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md` + the decisions in `../00-USAGE-AND-FIX-PLAN-2026-10-16.md` §5.1

## 1. Pre-applied work
None.

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| **TEX-01** | `config/permissionslist.php` ⚠ SHARED (decision (a), approved 2026-10-16) | `'smart-timetable.timetable' => array_merge($crud, ['generate', 'export'])`, with a comment saying the name still has to be seeded | `grep -n "'smart-timetable.timetable' =>" config/permissionslist.php` | one line, `['generate', 'export']` | 2026-10-16 |
| **TEX-01** | `TimetableExportController.php` | All 5 export methods now gate `tenant.smart-timetable.timetable.export` instead of `.view` | `grep -c "timetable.export'" …` | 5 | 2026-10-16 |
| **TEX-01** | `preview/index.blade.php` | The Export button and the `_export-modal` include are both wrapped in `@can('tenant.smart-timetable.timetable.export')` | render of `timetable.preview.allClasses` for timetable 5 as super-admin | modal 1 · trigger 1 · `{{--` leaks 0 | 2026-10-16 |
| **TEX-03** | `TimetableExportController.php` | New private `loadExportContext()`; both builders call it instead of carrying their own copy of the timetable/day/period loader | `grep -n loadExportContext …` | 3 hits (1 definition, 2 calls) | 2026-10-16 |
| **TEX-07** | `Exports/TimetableExport.php` | `fn ($t)` spacing, `Fill` imported; Pint also imported `Alignment` and fixed brace style | `grep -n 'fn(\$t)\|\\PhpOffice' …` | no output | 2026-10-16 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| TEX-02 (H) | deferred (D3) | split of the two builders waits for the split pass |
| TEX-04 (M) | accepted debt (decision 2026-10-16) | route model binding not applied |
| TEX-05 (M) | accepted debt (decision 2026-10-16) | no record cap or chunking |
| TEX-06, TEX-08 (L) | no plan item | see plan §10 |

## 4. Needs Tarun's hand
- **Run `/system-config/sync-permissions`.** It mints `tenant.smart-timetable.timetable.export`. Until you run it, the name exists only in config, so every non-super-admin role loses the export button and gets 403 on the export URLs. Super-admin is not affected, because `Gate::before` bypasses the check. After the sync, grant the ability to the roles that should export.
- The two substitute-management lists (`substitute-assignment/_list`, `substitute-duty/_list`) gate their export on `tenant.smart-timetable.report.export`. Their comments say `timetable.export` is unseeded. They are left as they are. Once the sync has run, you can decide whether they should move to the new name.

## 5. Unverifiable by this workflow (no tests, D4)
- That a role **without** `.export` is refused. The render ran as super-admin, who bypasses `Gate::before`, and the name is not seeded yet, so no role can be granted it or refused it (`module-finalization.md` §7.4.1).

## 6. Verification log
```
php -l TimetableExportController.php, Exports/TimetableExport.php, config/permissionslist.php -> No syntax errors detected (re-run after Pint)
vendor/bin/pint <the two PHP files> --format agent   -> fixed (ordered_imports, fully_qualified_strict_types, braces_position, …)
class_exists(TimetableExportController), class_exists(TimetableExport) -> true, true
render timetable.preview.allClasses (timetable 5)    -> id="exportTimetableModal" 1, data-bs-target 1, editToggleBtn 1, {{-- 0
```
⚠ `smart-timetable.timetable.preview` now goes to the Workspace and not to the preview blade. The export modal only renders on the `/all-classes` route, so that is the route checked above.

## 7. Final state
Status: FIXED · Open: B 0 · H 1 (TEX-02, deferred) · M 2 (TEX-04, TEX-05 accepted) · L 2 (TEX-06, TEX-08)
