# Fix Plan — SmartTimetable / TimetableExportController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php` | shared route file for the whole module; every export route must keep its exact path, name and middleware |
| `config/permissionslist.php` | shared config (⚠ SHARED); only TEX-01 may touch it, and only as a ticked DECISION |
| `Modules/TimetableFoundation/app/Models/*` | classes owned by `tarun/TimetableFoundation/*` reports; defects noted in §7 of the report |
| `database/migrations/*` | never edit an existing migration; TEX-01's seeding is Tarun's hand (`/system-config/sync-permissions`) |
| `Modules/SmartTimetable/app/Models/{SchoolDay,PeriodSetPeriod,TimetableCell}.php` | aliases scheduled for Phase 6 removal; TEX-08 is deliberately not fixed |
| `Modules/TimetableFoundation/resources/views/**` and shared components | common |

## 1. Blockers reachable today

None — this controller has no B-severity findings.

## 2. Fixes that arm a latent defect (sequenced)

- [x] **TEX-03** · M · CTL-05 · `Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:121-139,302-320` — extract the duplicated timetable/day/period loader into one private method.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php`
  - **Before** (`TimetableExportController.php:121-139`):
    ```php
        $timetable = Timetable::with(['timetableType', 'academicTerm', 'academicSession', 'periodSet'])
            ->findOrFail($timetableId);

        $days = SchoolDay::schoolDays()->get();

        $periods = PeriodSetPeriod::with('periodType')
            ->where('is_active', true)
            ->when($timetable->period_set_id, fn ($q) => $q->where('period_set_id', $timetable->period_set_id))
            ->orderBy('period_ord')
            ->get()
            ->each(function ($period) {
                $period->is_teaching = (bool) ($period->periodType?->counts_as_teaching ?? true);
                $period->is_break = (bool) ($period->periodType?->is_break ?? false);
            });
    ```
    The identical block sits at lines 302-320 with the same lines minus indentation differences.
  - **After:** Add this private method immediately before `buildExportData()` (after line 117), keeping the explanatory comments from the current block:
    ```php
    private function loadExportContext(int $timetableId): array
    {
        $timetable = Timetable::with(['timetableType', 'academicTerm', 'academicSession', 'periodSet'])
            ->findOrFail($timetableId);

        $days = SchoolDay::schoolDays()->get();

        $periods = PeriodSetPeriod::with('periodType')
            ->where('is_active', true)
            ->when($timetable->period_set_id, fn ($q) => $q->where('period_set_id', $timetable->period_set_id))
            ->orderBy('period_ord')
            ->get()
            // Stamp the teaching/break flags every export template reads as
            // `$period->is_teaching ?? ! ($period->is_break ?? false)`. They were never
            // set here, so that expression was TRUE for every period and the Break /
            // Lunch columns rendered as ordinary empty lesson cells instead of break
            // columns. Same source of truth as TimetablePreviewController::preview().
            ->each(function ($period) {
                $period->is_teaching = (bool) ($period->periodType?->counts_as_teaching ?? true);
                $period->is_break = (bool) ($period->periodType?->is_break ?? false);
            });

        return [$timetable, $days, $periods];
    }
    ```
    Then replace the full block at BOTH call sites — lines 121-139 in `buildExportData()` and lines 302-320 in `buildTeacherExportData()` — with this single line:
    ```php
        [$timetable, $days, $periods] = $this->loadExportContext($timetableId);
    ```
  - **Verify:** `grep -n "loadExportContext" Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php`
  - **Expect:** 3 hits — one private-method declaration and two call sites.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

None — the controller is read-only (F1/F2 clean in the report).

## 4. Authorization (F3)

None in this group — TEX-01 needs a new permission key and is a DECISION in §9.

## 5. Validation, routes, models (F4/F5/F7)

None — validation, routes and the in-scope models are clean.

## 6. Queries & performance (F9)

None as plain items — TEX-05 (record cap) is a DECISION in §9; TEX-06 has no mechanical fix and sits in §10.

## 7. Views (F10)

None — the four export blades and two partials are clean.

## 8. Style (F12) — one item per file

- [x] **TEX-07** · L · STY-02 · `Modules/SmartTimetable/app/Exports/TimetableExport.php:54,117-118` — make the file Pint-clean: `fn ($t)` spacing and the `Fill` import.
  - **Touches:** `Modules/SmartTimetable/app/Exports/TimetableExport.php`
  - **Before** (`TimetableExport.php:54` and import block `:7-15`):
    ```php
            $teacherNames = $cell->teachers->map(fn($t) => $t->user->name ?? 'N/A')->implode(', ');
    ```
    and the fully-qualified fill type at `:118`:
    ```php
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
    ```
  - **After:** Add the import (alphabetically between the Foundation imports and `Worksheet`) and fix both lines:
    ```php
    use Modules\TimetableFoundation\Models\Timetable;
    use Modules\TimetableFoundation\Models\TimetableCell;
    use PhpOffice\PhpSpreadsheet\Style\Fill;
    use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
    ```
    ```php
            $teacherNames = $cell->teachers->map(fn ($t) => $t->user->name ?? 'N/A')->implode(', ');
    ```
    ```php
                    'fillType' => Fill::FILL_SOLID,
    ```
  - **Verify:** `grep -n "fn(\$t)\|\\\\PhpOffice" Modules/SmartTimetable/app/Exports/TimetableExport.php`
  - **Expect:** no output — both patterns gone.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **TEX-01** · H · DECISION · AUTH-01 — give timetable exports their own `.export` ability instead of `.view`?
  - **Why it is a decision:** adds a new permission key to `config/permissionslist.php` (⚠ SHARED) and needs seeding via Tarun's hand (`/system-config/sync-permissions`); changing the gate changes who can download files.
  - (a) ⭐ add `export` to `smart-timetable.timetable` + gate all five methods on `tenant.smart-timetable.timetable.export`, and mirror the same name on the preview's export buttons — matches the module's own standard (`permissionslist.php:720-724`) and the sibling Analytics export
  - (b) keep `.view` and only document that view implies export
  - (c) leave as is and record as accepted risk
  - ➜ Choice: (a) — applied 2026-10-16; seeding is Tarun's hand (/system-config/sync-permissions)

- [x] **TEX-02** · H · DECISION · CTL-02 — split the two oversized private builders (`buildExportData` 173 lines, `buildTeacherExportData` 122 lines)?
  - **Why it is a decision:** D3 defers god-controller/split work out of this pass; a split changes class structure and duplicating the grid logic with `TimetablePreviewController`.
  - (a) ⭐ defer to the split pass (D3) — record the sizes now
  - (b) extract both builders into a `TimetableExportData` service now (larger change, touches the export controller only)
  - (c) leave as is and record as accepted
  - ➜ Choice: (a) defer to the split pass (D3)

- [x] **TEX-04** · M · DECISION · CTL-03 — apply route model binding to the five export methods?
  - **Why it is a decision:** binding changes five method signatures (parameter name must keep matching the route parameter `{timetableId}`) and both private builders; done wrongly it makes the 404 fire before the gate.
  - (a) ⭐ defer to the alignment pass — record the call sites now
  - (b) bind now, keeping the argument name `$timetableId` and the route file untouched, and pass `$timetableId->id` into the builders
  - (c) leave as is and record as accepted
  - ➜ Choice: (c) accepted as debt (2026-10-16)

- [x] **TEX-05** · M · DECISION · QRY-06 — add a record cap or chunking to the exports?
  - **Why it is a decision:** changes export behaviour (a cap refuses large exports until filters are applied) or the builder shape (streaming cells); the live table has 0 rows today.
  - (a) ⭐ keep current behaviour for now — no cap, no chunk — and revisit when a tenant generates a large timetable; the grid builders need the full cell set in memory by design
  - (b) add the TenantCore-style 3,000-record cap (limit + user message) on the cell queries
  - (c) stream cells with `lazyById` into both builders and the Excel export (largest change)
  - ➜ Choice: (a) keep current behaviour — accepted as debt (2026-10-16)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TEX-06 | QRY-05 L — the PHP-side filter over `ClassSection` (43 live rows) has no clean mechanical SQL equivalent (the grid keys are derived from cell ownership, not ids); not a live cost. Accepted. |
| TEX-08 | STY-01 L — the three alias models are marked for Phase 6 removal; adding `strict_types` now would churn files about to be deleted. Fix when the aliases are touched by that cleanup. |