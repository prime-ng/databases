# Status — SmartTimetable / SubstitutionController

**Fixed:** 2026-10-16 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

Decisions (Tarun, 2026-10-16):
- **SBS-08:** replace in ONE transaction and undo the removal if the add fails. The plan's option (a), "attach the new substitute first", cannot work as written: a lesson holds one substitute, so the old one has to go before the new one is added. This is the plan's option (b) intent, done with a rollback instead of a re-add.
- **SBS-11:** option (a). All three inline validations move to FormRequests with identical rules.
- **SBS-13:** option (a). Deferred to the split pass (D3).
- **SBS-15:** declined. Keep Gate → `findOrFail($id)`. Route-model binding loads the record before the Gate, so a user without permission could tell which ids exist (404 vs 403). Same decision as TPB-05 and PGX-06. The route file is not touched.

## 1. Pre-applied work
none

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| SBS-01 | SubstitutionController.php:132/139, 209/212, 258/261, 410 | The four write methods return fixed messages: "The absence could not be reported. / The substitute could not be assigned. / Auto-assign failed. / The substitute grid could not be saved. — The error has been logged." The raw exception text stays in the log only. The try/catch blocks themselves stay, because SBS-04 is deferred. | `grep -n getMessage SubstitutionController.php` | 5 hits, all `'error' =>` log lines (129, 207, 256, 349, 407) | 2026-10-16 |
| SBS-02 | SubstitutionService.php:1070, 1626 | `assignInSource()` and `removeInSource()` call `report($e)` and return `'Failed to assign substitute.'` / `'Failed to remove substitute.'`. | `grep -n getMessage SubstitutionService.php` | no output | 2026-10-16 |
| SBS-05 | TeacherAbsences.php:221, 241 | `approve()` and `reject()` run the status update and the `AbsenceApproved`/`AbsenceRejected` audit row in one `DB::transaction`. `DB` facade imported. | `grep -n "DB::transaction" TeacherAbsences.php` | 2 hits (approve, reject) | 2026-10-16 |
| SBS-06 | SubstitutionLog.php:213 | `markNotified()` runs `notified_at` and its `SubstituteNotified` audit row in one `DB::transaction`. `DB` facade imported. | `grep -n "DB::transaction" SubstitutionLog.php` | 1 hit | 2026-10-16 |
| SBS-07 | SubstitutionService.php:455-465 | Inside the `reportAbsenceRange` transaction, the teacher's absences in the range are re-read `withTrashed()->lockForUpdate()` before any insert. The read outside the transaction stays as a snapshot only. | `grep -n lockForUpdate SubstitutionService.php` | 1 hit (462) | 2026-10-16 |
| SBS-08 | SubstitutionService.php:1485-1525 (`saveTeacherGrid`) | A replace (old substitute → new substitute) runs `removeSubstitute()` + `assignSubstitute()` in one transaction. If either returns `success:false` the transaction rolls back, so the old substitute and its audit rows stay, and the period is reported under `failures`. A thrown exception also rolls back and is re-thrown. A plain remove and a plain assign are unchanged. Snapshot cells write through the same connection (SnapshotContext swaps the grammar, not the connection), so the rollback covers them too. | rolled-back replay with a forced add failure (§6) | failed replace: substitute stays `[83]`, 0 audit rows; good replace: `[73]` | 2026-10-16 |
| SBS-09 | SubstitutionService.php:1608-1617 | `$log->delete()` runs before `activityLog($log, 'SubstituteRemoved', …)`. | `sed -n 1605,1620p` | delete precedes activityLog | 2026-10-16 |
| SBS-11 | new `Http/Requests/ReportAbsenceRequest.php`, `AssignSubstituteRequest.php`, `AutoAssignRequest.php`; controller 68, 163, 230 | The rules moved unchanged, including `CellExistsInSource` for snapshot cell ids. Each `authorize()` repeats `tenant.smart-timetable.timetable.update`, the same as `SaveSubstituteGridRequest`. The controller Gate stays. | `grep -n "request->validate(" SubstitutionController.php` | no output | 2026-10-16 |
| SBS-19 | SubstitutionService.php:163 | Constructor injects `SnapshotContext`, `SnapshotWriteGuard`, `SubstitutionHistoryReader`. Both snapshot classes are bound `scoped`, so these are the same per-request instances `app()` returned before. The `historyMemo` property is gone. | `grep -n "app(SnapshotContext::class)\|app(SnapshotWriteGuard::class)\|app(SubstitutionHistoryReader::class)"` | no output | 2026-10-16 |
| SBS-20 | SubstitutionService.php:536-552 | The affected-cells count loads every reported date's absence in ONE `whereIn('absence_date', …)` query keyed by date (a 90-day range used to be 90 queries). `absence_date` is a DATE column, so the strings match exactly. The plan's verify grep also matches lines 1496/1541. Those are the `saveTeacherGrid` per-row lookups, which the plan itself leaves as a follow-up. | `grep -n "absenceByDate"` | 541 | 2026-10-16 |
| SBS-22 | SubstitutionController.php:3, 11 | `declare(strict_types=1)`. `Log` facade imported; all five `\Log::error` calls are now `Log::error`. Unused `Request` and `CellExistsInSource` imports removed. ⚠ Because of `strict_types`, values passed to the service's `int` parameters are now cast `(int)`. A form post delivers strings, and without the cast every form-encoded write would throw a TypeError. | `grep -n "declare(strict_types\|\\\\Log::"` | declare only | 2026-10-16 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| SBS-15 | declined (decision) | Gate → `findOrFail($id)` kept on `approveAbsence`/`rejectAbsence`/`markNotified`; `routes/web.php` untouched. |
| SBS-13 | deferred (decision, D3) | Service split goes to the split pass. Also covers SBS-14 (long methods) and SBS-16 (return types). |
| SBS-03 | partly closed | Service half closed by SBS-02 (`report($e)`). Controller half accepted (plan §10). |
| SBS-04 | deferred (plan §10) | Controller try/catch removal is a behaviour change across five endpoints. Messages are fixed (SBS-01); the catches stay. |
| SBS-10, 12, 16, 17, 18, 21, 23 | accepted (plan §10) | No plan item. |
| SBS-14 | deferred (plan §10) | Covered by the SBS-13 split. |

## 4. Needs Tarun's hand
- **Browser check:** `/smart-timetable/substitute-management?tab=substitute-requirement`
  - Report an absence (single day and a range): the confirmation message is unchanged.
  - On the Substitute Assignment grid, replace one substitute with another: it saves as before.
  - Approve and reject an absence; mark a substitute notified.
- **Behaviour change:** a failure that used to print the database error now shows "… could not be … The error has been logged." The full error is in `storage/logs`.
- No migration, seeder or permission sync is needed.

## 5. Unverifiable by this workflow (no tests, D4)
- `lockForUpdate()` in `reportAbsenceRange` serialising two truly concurrent reports. It needs two parallel sessions.
- The `authorize()` refusal in the three new FormRequests for a role without `.update`. The checks here ran as super-admin, which bypasses `Gate::before`.

**Found on the way, not fixed:**
- `CellExistsInSource` (TimetableFoundation, shared) passes `cell_id <= 0`. Validation accepts `0`, and the request then ends in a `findOrFail` 404. The behaviour is unchanged from the old inline rule.
- ⚠ UNVERIFIED: in a replay, the absent teacher could be saved as his own substitute (`assignSubstitute` accepted it). Worth a look in the next SubstitutionService pass.

## 6. Verification log
```
$ vendor/bin/pint <7 files> --format agent → {"result":"passed"}
$ php -l (controller, service, 2 models, 3 requests) → No syntax errors detected
$ class_exists × 7 → OK (controller, service, TeacherAbsences, SubstitutionLog, 3 requests)
$ router probe → 10 SubstitutionController routes, 0 missing methods
$ container resolve → controller + service resolve (constructor injection works)
$ grep getMessage SubstitutionController.php → 5, all log lines; SubstitutionService.php → none
$ rolled-back replay (report / approve / reject):
  ReportAbsenceRequest  passes=no errors=["end_period"]   (end 2 < start 3 — refused, as intended)
  AutoAssignRequest     passes=yes · AssignSubstituteRequest passes=yes
  report: created=1 revived=0 skipped_existing=0 affected_cells=7
  report again: created=0 skipped_existing=1   (locked re-read sees the row)
  approve: status=APPROVED · reject: status=REJECTED · logs written in tx: 3
  after rollback: absences +0, logs +0
$ rolled-back replay (SBS-08, add half forced to fail via a test-only subclass):
  A=83 assigned, substitute now [83]
  failed replace A->B: replaced=0 failures=1 msg="forced failure"
  substitute after failed replace: [83]   audit rows added: 0
  good replace A->B: replaced=1 failures=0 substitute now [73]
  after rollback: logs +0
```

## 7. Final state
Status: FIXED · Open: B 0 · H 1 · M 5 · L 6 (H: SBS-14 deferred with the split · M: SBS-03 partly, SBS-04 deferred, SBS-13 deferred, SBS-15 declined, SBS-17 accepted · L: SBS-10, 12, 16, 18, 21, 23 accepted)
