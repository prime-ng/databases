# Fix Plan — SmartTimetable / SubstitutionController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | owned by the StandardTimetableController report |
| `Modules/TimetableFoundation/app/Models/Timetable.php` | owned by the TimetableFoundation/TimetableController report |
| `Modules/TimetableFoundation/app/Models/TimetableCell.php` | owned by the TimetableFoundation/TimetableController report |
| `Modules/TimetableFoundation/app/Services/OptionCellResolver.php` | owned by the TimetableFoundation/TimetableFoundationController report |
| `Modules/TimetableFoundation/app/Services/PublishedTimetable.php` | owned by the TimetableFoundation/TimetableFoundationController report |
| `config/permissionslist.php` | shared config; no new key is added by this plan |
| any migration file | never edited by the audit workflow |

## 1. Blockers reachable today

- [x] **SBS-01** · B · ERR-01 · `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:134-140` — stop echoing the database's error text to the user in the four write methods.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php`
  - **Before** (`SubstitutionController.php:134-140`):
    ```php
            if ($request->expectsJson()) {
                return response()->json(['success' => false, 'message' => 'Failed to report absence: '.$e->getMessage()], 500);
            }

            return back()
                ->withInput()
                ->with('error', 'Failed to report absence: '.$e->getMessage());
    ```
  - **After:**
    ```php
            if ($request->expectsJson()) {
                return response()->json(['success' => false, 'message' => 'The absence could not be reported. The error has been logged.'], 500);
            }

            return back()
                ->withInput()
                ->with('error', 'The absence could not be reported. The error has been logged.');
    ```
  - **Before** (`SubstitutionController.php:215-219`, method `assign()`):
    ```php
            if ($request->expectsJson()) {
                return response()->json(['success' => false, 'message' => 'Failed to assign substitute: '.$e->getMessage()], 500);
            }

            return back()->with('error', 'Failed to assign substitute: '.$e->getMessage());
    ```
  - **After:**
    ```php
            if ($request->expectsJson()) {
                return response()->json(['success' => false, 'message' => 'The substitute could not be assigned. The error has been logged.'], 500);
            }

            return back()->with('error', 'The substitute could not be assigned. The error has been logged.');
    ```
  - **Before** (`SubstitutionController.php:266-270`, method `autoAssign()`):
    ```php
            if ($request->expectsJson()) {
                return response()->json(['success' => false, 'message' => 'Auto-assign failed: '.$e->getMessage()], 500);
            }

            return back()->with('error', 'Auto-assign failed: '.$e->getMessage());
    ```
  - **After:**
    ```php
            if ($request->expectsJson()) {
                return response()->json(['success' => false, 'message' => 'Auto-assign failed. The error has been logged.'], 500);
            }

            return back()->with('error', 'Auto-assign failed. The error has been logged.');
    ```
  - **Before** (`SubstitutionController.php:413-416`, method `saveTeacherGrid()`):
    ```php
            return response()->json([
                'success' => false,
                'message' => 'Failed to save the substitute grid: '.$e->getMessage(),
            ], 500);
    ```
  - **After:**
    ```php
            return response()->json([
                'success' => false,
                'message' => 'The substitute grid could not be saved. The error has been logged.',
            ], 500);
    ```
  - **Verify:** `grep -n "getMessage" Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php`
  - **Expect:** only the five log lines remain (130, 212, 263, 356, 410); no flash or JSON string still contains getMessage.
  - **Effort:** S

- [x] **SBS-02** · B · ERR-01 · `Modules/SmartTimetable/app/Services/SubstitutionService.php:1036-1047` — the service must report the exception and return a fixed message.
  - **Touches:** `Modules/SmartTimetable/app/Services/SubstitutionService.php`
  - **Before** (`SubstitutionService.php:1036-1047`):
    ```php
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            \Log::error('Substitution assignSubstitute failed', [
                'cell_id' => $cellId,
                'substitute_teacher_id' => $substituteTeacherId,
                'date' => $date,
                'error' => $e->getMessage(),
            ]);

            return ['success' => false, 'message' => 'Failed to assign substitute: '.$e->getMessage()];
        }
    ```
  - **After:**
    ```php
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            report($e);

            return ['success' => false, 'message' => 'Failed to assign substitute.'];
        }
    ```
  - **Before** (`SubstitutionService.php:1557-1565`, method `removeInSource()`):
    ```php
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            \Log::error('Substitution removeSubstitute failed', [
                'cell_id' => $cellId, 'date' => $date, 'error' => $e->getMessage(),
            ]);

            return ['success' => false, 'message' => 'Failed to remove substitute: '.$e->getMessage()];
        }
    ```
  - **After:**
    ```php
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            report($e);

            return ['success' => false, 'message' => 'Failed to remove substitute.'];
        }
    ```
  - **Verify:** `grep -n "getMessage" Modules/SmartTimetable/app/Services/SubstitutionService.php`
  - **Expect:** no output.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

(none — no latent defect becomes reachable only after another item)

## 3. Errors & transactions (F1/F2)

- [x] **SBS-05** · H · TXN-01 · `Modules/SmartTimetable/app/Models/TeacherAbsences.php:216-246` — write the absence decision and its audit row in one transaction.
  - **Touches:** `Modules/SmartTimetable/app/Models/TeacherAbsences.php`
  - **Before** (`TeacherAbsences.php:216-246`):
    ```php
    public function approve(int $userId): void
    {
        $this->update([
            'status' => self::STATUS_APPROVED,
            'approved_by' => $userId,
            'approved_at' => now(),
        ]);

        activityLog($this, 'AbsenceApproved', [
            'message' => 'Teacher absence was approved.',
            'teacher_id' => $this->teacher_id,
            'date' => $this->absence_date?->toDateString(),
            'approved_by' => $userId,
        ]);
    }

    public function reject(int $userId): void
    {
        $this->update([
            'status' => self::STATUS_REJECTED,
            'approved_by' => $userId,
            'approved_at' => now(),
        ]);

        activityLog($this, 'AbsenceRejected', [
            'message' => 'Teacher absence was rejected.',
            'teacher_id' => $this->teacher_id,
            'date' => $this->absence_date?->toDateString(),
            'rejected_by' => $userId,
        ]);
    }
    ```
  - **After:**
    ```php
    public function approve(int $userId): void
    {
        DB::transaction(function () use ($userId) {
            $this->update([
                'status' => self::STATUS_APPROVED,
                'approved_by' => $userId,
                'approved_at' => now(),
            ]);

            activityLog($this, 'AbsenceApproved', [
                'message' => 'Teacher absence was approved.',
                'teacher_id' => $this->teacher_id,
                'date' => $this->absence_date?->toDateString(),
                'approved_by' => $userId,
            ]);
        });
    }

    public function reject(int $userId): void
    {
        DB::transaction(function () use ($userId) {
            $this->update([
                'status' => self::STATUS_REJECTED,
                'approved_by' => $userId,
                'approved_at' => now(),
            ]);

            activityLog($this, 'AbsenceRejected', [
                'message' => 'Teacher absence was rejected.',
                'teacher_id' => $this->teacher_id,
                'date' => $this->absence_date?->toDateString(),
                'rejected_by' => $userId,
            ]);
        });
    }
    ```
  - **Note:** `TeacherAbsences.php` currently imports `SoftDeletes` and the SchoolSetup models; add `use Illuminate\Support\Facades\DB;` beside them.
  - **Verify:** `grep -n "DB::transaction" Modules/SmartTimetable/app/Models/TeacherAbsences.php`
  - **Expect:** two lines, one inside `approve()` and one inside `reject()`.
  - **Effort:** S

- [x] **SBS-06** · H · TXN-01 · `Modules/SmartTimetable/app/Models/SubstitutionLog.php:208-219` — write the notified flag and its audit row in one transaction.
  - **Touches:** `Modules/SmartTimetable/app/Models/SubstitutionLog.php`
  - **Before** (`SubstitutionLog.php:208-219`):
    ```php
    public function markNotified(): void
    {
        $this->update([
            'notified_at' => now(),
        ]);

        activityLog($this, 'SubstituteNotified', [
            'message' => 'Substitute teacher was marked as notified.',
            'substitution_log_id' => $this->id,
            'notified_at' => $this->notified_at?->toDateTimeString(),
        ]);
    }
    ```
  - **After:**
    ```php
    public function markNotified(): void
    {
        DB::transaction(function () {
            $this->update([
                'notified_at' => now(),
            ]);

            activityLog($this, 'SubstituteNotified', [
                'message' => 'Substitute teacher was marked as notified.',
                'substitution_log_id' => $this->id,
                'notified_at' => $this->notified_at?->toDateTimeString(),
            ]);
        });
    }
    ```
  - **Note:** add `use Illuminate\Support\Facades\DB;` to the imports of `SubstitutionLog.php`.
  - **Verify:** `grep -n "DB::transaction" Modules/SmartTimetable/app/Models/SubstitutionLog.php`
  - **Expect:** one line inside `markNotified()`.
  - **Effort:** S

- [x] **SBS-07** · H · TXN-06 · `Modules/SmartTimetable/app/Services/SubstitutionService.php:440-444` — re-read the day's absences under a row lock inside the reporting transaction.
  - **Touches:** `Modules/SmartTimetable/app/Services/SubstitutionService.php`
  - **Before** (`SubstitutionService.php:440-444`):
    ```php
        DB::transaction(function () use (
            $start, $end, $schoolDows, $holidayDates, $existing, $teacherId, $type,
            $startPeriod, $endPeriod, $reason,
            &$created, &$revived, &$skippedExisting, &$skippedNonSchool, &$skippedHoliday
        ) {
    ```
  - **After:**
    ```php
        DB::transaction(function () use (
            $start, $end, $schoolDows, $holidayDates, $existing, $teacherId, $type,
            $startPeriod, $endPeriod, $reason,
            &$created, &$revived, &$skippedExisting, &$skippedNonSchool, &$skippedHoliday
        ) {
            // Re-read under a row lock so two concurrent reports for the same teacher
            // and date cannot both decide the row is missing and then collide on
            // uq_ta_teacher_date.
            $existing = TeacherAbsences::withTrashed()
                ->where('teacher_id', $teacherId)
                ->whereBetween('absence_date', [$start->toDateString(), $end->toDateString()])
                ->lockForUpdate()
                ->get()
                ->keyBy(fn ($a) => $a->absence_date->toDateString());
    ```
  - **Verify:** `grep -n "lockForUpdate" Modules/SmartTimetable/app/Services/SubstitutionService.php`
  - **Expect:** one line, inside the `reportAbsenceRange` transaction.
  - **Effort:** M

- [x] **SBS-09** · M · TXN-04 · `Modules/SmartTimetable/app/Services/SubstitutionService.php:1545-1553` — delete the log before writing the audit row that describes the deletion.
  - **Touches:** `Modules/SmartTimetable/app/Services/SubstitutionService.php`
  - **Before** (`SubstitutionService.php:1545-1553`):
    ```php
                foreach ($logs as $log) {
                    activityLog($log, 'SubstituteRemoved', [
                        'message' => 'A substitute teacher was removed from a cell.',
                        'cell_id' => $cellId,
                        'substitute_teacher_id' => $substitute->id,
                        'date' => $date,
                    ]);
                    $log->delete();
                }
    ```
  - **After:**
    ```php
                foreach ($logs as $log) {
                    $log->delete();

                    activityLog($log, 'SubstituteRemoved', [
                        'message' => 'A substitute teacher was removed from a cell.',
                        'cell_id' => $cellId,
                        'substitute_teacher_id' => $substitute->id,
                        'date' => $date,
                    ]);
                }
    ```
  - **Verify:** `sed -n '1545,1555p' Modules/SmartTimetable/app/Services/SubstitutionService.php`
  - **Expect:** `$log->delete();` appears before the `activityLog` call in the loop.
  - **Effort:** S

## 4. Authorization (F3)

(none — every routed method already authorizes with an existing permission key)

## 5. Validation, routes, models (F4/F5/F7)

- [x] **SBS-19** · M · SVC-02 · `Modules/SmartTimetable/app/Services/SubstitutionService.php:157-172` — inject the snapshot collaborators through the constructor instead of `app()`.
  - **Touches:** `Modules/SmartTimetable/app/Services/SubstitutionService.php`
  - **Before** (`SubstitutionService.php:157-172`):
    ```php
    private function snapshots(): SnapshotContext
    {
        return app(SnapshotContext::class);
    }

    private function writeGuard(): SnapshotWriteGuard
    {
        return app(SnapshotWriteGuard::class);
    }

    private ?SubstitutionHistoryReader $historyMemo = null;

    private function history(): SubstitutionHistoryReader
    {
        return $this->historyMemo ??= app(SubstitutionHistoryReader::class);
    }
    ```
  - **After:**
    ```php
    public function __construct(
        private SnapshotContext $context,
        private SnapshotWriteGuard $guard,
        private SubstitutionHistoryReader $reader,
    ) {}

    private function snapshots(): SnapshotContext
    {
        return $this->context;
    }

    private function writeGuard(): SnapshotWriteGuard
    {
        return $this->guard;
    }

    private function history(): SubstitutionHistoryReader
    {
        return $this->reader;
    }
    ```
  - **Verify:** `grep -n "app(SnapshotContext::class)\|app(SnapshotWriteGuard::class)\|app(SubstitutionHistoryReader::class)" Modules/SmartTimetable/app/Services/SubstitutionService.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **SBS-15** — ❌ DECLINED 2026-10-16 (keep Gate → findOrFail; existence oracle, same as TPB-05/PGX-06) — · M · CTL-03 · `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:289-296` — use route model binding for the three record-decision endpoints. ⚠ SHARED (touches a route file)
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php`, `Modules/SmartTimetable/routes/web.php`
  - **Before** (`SubstitutionController.php:289-296`):
    ```php
    public function approveAbsence(int $id): JsonResponse
    {
        Gate::authorize('tenant.smart-timetable.timetable.update');

        $absence = TeacherAbsences::findOrFail($id);
        $absence->approve(auth()->id());

        return response()->json(['success' => true, 'message' => 'Absence approved.']);
    }
    ```
  - **After:**
    ```php
    public function approveAbsence(TeacherAbsences $absence): JsonResponse
    {
        Gate::authorize('tenant.smart-timetable.timetable.update');

        $absence->approve(auth()->id());

        return response()->json(['success' => true, 'message' => 'Absence approved.']);
    }
    ```
  - **Before** (`SubstitutionController.php:302-309`, method `rejectAbsence()`):
    ```php
    public function rejectAbsence(int $id): JsonResponse
    {
        Gate::authorize('tenant.smart-timetable.timetable.update');

        $absence = TeacherAbsences::findOrFail($id);
        $absence->reject(auth()->id());

        return response()->json(['success' => true, 'message' => 'Absence rejected.']);
    }
    ```
  - **After:**
    ```php
    public function rejectAbsence(TeacherAbsences $absence): JsonResponse
    {
        Gate::authorize('tenant.smart-timetable.timetable.update');

        $absence->reject(auth()->id());

        return response()->json(['success' => true, 'message' => 'Absence rejected.']);
    }
    ```
  - **Before** (`SubstitutionController.php:315-331`, method `markNotified()`):
    ```php
    public function markNotified(int $id): JsonResponse
    {
        Gate::authorize('tenant.smart-timetable.timetable.update');

        $refusal = $this->writeGuard->refusalForLog($id);
        if ($refusal !== null) {
            return response()->json(['success' => false, 'code' => 'TIMETABLE_SNAPSHOT', 'message' => $refusal], 403);
        }

        $this->snapshots->runSnapshot(
            $this->snapshots->sourceOfRow('tt_substitution_logs', $id),
            fn () => SubstitutionLog::findOrFail($id)->markNotified()
        );

        return response()->json(['success' => true, 'message' => 'Notification sent.']);
    }
    ```
  - **After:**
    ```php
    public function markNotified(SubstitutionLog $substitutionLog): JsonResponse
    {
        Gate::authorize('tenant.smart-timetable.timetable.update');

        $id = (int) $substitutionLog->id;
        $refusal = $this->writeGuard->refusalForLog($id);
        if ($refusal !== null) {
            return response()->json(['success' => false, 'code' => 'TIMETABLE_SNAPSHOT', 'message' => $refusal], 403);
        }

        $this->snapshots->runSnapshot(
            $this->snapshots->sourceOfRow('tt_substitution_logs', $id),
            fn () => $substitutionLog->markNotified()
        );

        return response()->json(['success' => true, 'message' => 'Notification sent.']);
    }
    ```
  - **Before** (`Modules/SmartTimetable/routes/web.php:225-227`):
    ```php
        Route::post('/teacher-absence/{id}/approve', [SubstitutionController::class, 'approveAbsence'])->name('teacher-absence.approve');
        Route::post('/teacher-absence/{id}/reject', [SubstitutionController::class, 'rejectAbsence'])->name('teacher-absence.reject');
        Route::post('/substitution-log/{id}/notify', [SubstitutionController::class, 'markNotified'])->name('substitution-log.notify');
    ```
  - **After:**
    ```php
        Route::post('/teacher-absence/{absence}/approve', [SubstitutionController::class, 'approveAbsence'])->name('teacher-absence.approve');
        Route::post('/teacher-absence/{absence}/reject', [SubstitutionController::class, 'rejectAbsence'])->name('teacher-absence.reject');
        Route::post('/substitution-log/{substitutionLog}/notify', [SubstitutionController::class, 'markNotified'])->name('substitution-log.notify');
    ```
  - **Verify:** `grep -n "findOrFail" Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php`
  - **Expect:** no output.
  - **Effort:** M

## 6. Queries & performance (F9)

- [x] **SBS-20** · H · QRY-01 · `Modules/SmartTimetable/app/Services/SubstitutionService.php:516-525` — fetch the affected-count absences in one query instead of one per date.
  - **Touches:** `Modules/SmartTimetable/app/Services/SubstitutionService.php`
  - **Before** (`SubstitutionService.php:516-525`):
    ```php
        $affectedCells = 0;
        foreach (array_merge($created, $revived) as $date) {
            $absence = TeacherAbsences::where('teacher_id', $teacherId)
                ->whereDate('absence_date', $date)
                ->first();

            if ($absence) {
                $affectedCells += $this->uncoveredCellsForAbsence($absence, $date)->count();
            }
        }
    ```
  - **After:**
    ```php
        $reportDates = array_merge($created, $revived);
        $absenceByDate = TeacherAbsences::where('teacher_id', $teacherId)
            ->whereIn('absence_date', $reportDates)
            ->get()
            ->keyBy(fn ($a) => $a->absence_date->toDateString());

        $affectedCells = 0;
        foreach ($reportDates as $date) {
            $absence = $absenceByDate->get($date);

            if ($absence) {
                $affectedCells += $this->uncoveredCellsForAbsence($absence, $date)->count();
            }
        }
    ```
  - **Note:** the same N+1 shape remains at `SubstitutionService.php:1000` (`assignInSource`), `:1437` and `:1477` (`saveTeacherGrid`) and `:1602` (`getSubstituteDutyRecords`). Fix them with the same keyed-collection approach in a follow-up; this item covers the loop the scanner flags first.
  - **Verify:** `grep -n "whereDate('absence_date', \$date)" Modules/SmartTimetable/app/Services/SubstitutionService.php`
  - **Expect:** no output.
  - **Effort:** M

## 7. Views (F10)

(none — the history blade is clean)

## 8. Style (F12) — one item per file

- [x] **SBS-22** · L · STY-01 / STY-06 · `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:1-16` — add `strict_types` and import the `Log` facade.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php`
  - **Before** (`SubstitutionController.php:1-16`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\SmartTimetable\Http\Requests\SaveSubstituteGridRequest;
    use Modules\SmartTimetable\Models\SubstitutionLog;
    use Modules\SmartTimetable\Models\TeacherAbsences;
    use Modules\SmartTimetable\Services\SubstitutionService;
    use Modules\TimetableFoundation\Support\Snapshot\CellExistsInSource;
    use Modules\TimetableFoundation\Support\Snapshot\SnapshotContext;
    use Modules\TimetableFoundation\Support\Snapshot\SnapshotWriteGuard;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Controllers;

    use App\Http\Controllers\Controller;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\SmartTimetable\Http\Requests\SaveSubstituteGridRequest;
    use Modules\SmartTimetable\Models\SubstitutionLog;
    use Modules\SmartTimetable\Models\TeacherAbsences;
    use Modules\SmartTimetable\Services\SubstitutionService;
    use Modules\TimetableFoundation\Support\Snapshot\CellExistsInSource;
    use Modules\TimetableFoundation\Support\Snapshot\SnapshotContext;
    use Modules\TimetableFoundation\Support\Snapshot\SnapshotWriteGuard;
    ```
  - **Note:** after the imports, replace the five `\Log::error` calls (lines 127, 209, 260, 354, 408) with `Log::error`.
  - **Verify:** `grep -n "declare(strict_types\|\\\\Log::" Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php`
  - **Expect:** one `declare(strict_types=1);` line and no `\Log::` lines.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **SBS-08** · H · DECISION · TXN-03 — on a grid "replace", should the new substitute be attached before the old one is removed?
  - **Why it is a decision:** behaviour change to a live write path (`saveTeacherGrid`); the current order can leave a period uncovered.
  - (a) ⭐ attach the new substitute first, then remove the old one (one transaction per cell), so a failed attach changes nothing
  - (b) keep the current clear-then-assign order but restore the removed substitute when the assign fails
  - (c) leave as is, record as accepted risk
  - ➜ Choice: (b) — replace in ONE transaction, roll back the removal if the add fails (Tarun 2026-10-16; option (a) is impossible: a lesson holds one substitute)

- [x] **SBS-11** · M · DECISION · VAL-02 — extract the three inline validations into FormRequests?
  - **Why it is a decision:** adds three new files (`ReportAbsenceRequest`, `AssignSubstituteRequest`, `AutoAssignRequest`); no behaviour change.
  - (a) ⭐ extract all three now, keeping the exact rules
  - (b) extract only `ReportAbsenceRequest` (the widest rule set)
  - (c) leave inline, record as accepted
  - ➜ Choice: (a) — all three, identical rules (Tarun 2026-10-16)

- [x] **SBS-13** · M · DECISION · CTL-01 — split the 1,698-line `SubstitutionService`?
  - **Why it is a decision:** a god-class split (D3 — deferred to the split pass); it also resolves SBS-14's long methods.
  - (a) ⭐ defer to the split pass (D3) and keep this report as the record
  - (b) extract the reporting methods (`getSubstitutionDutyRecords`, `getTeacherSubstitutionPlan`, `getDashboard`) into a reader service now
  - (c) leave as is, record as accepted
  - ➜ Choice: (a) — defer to the split pass, D3 (Tarun 2026-10-16)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| SBS-03 | The service half is fixed by SBS-02 (`report($e)`); the controller half is accepted because it also logs the trace and no message reaches the user. |
| SBS-04 | Removing the controller try/catch is a behaviour change across five endpoints; deferred, tracked here, not applied in this pass. |
| SBS-10 | AUTH-04 duplicate: accepted; both checks name the same existing permission and the FormRequest is an intentional enforcement surface. |
| SBS-12 | VAL-05 `absence_id`: accepted; optional field set only by the AJAX caller. |
| SBS-14 | CTL-02 long methods: covered by the SBS-13 split decision. |
| SBS-16 | CTL-04 return types: accepted for now; add when the methods move in the SBS-13 split. |
| SBS-17 | CTL-10 dead code: accepted; `getDashboard()` is deliberately retained for a future date-first API. Informational. |
| SBS-18 | MDL-04 relation return types: accepted; no runtime effect on either model. |
| SBS-21 | QRY-05 `->get()->filter()`: accepted; the filter encodes a PHP period rule, not a SQL aggregate. |
| SBS-23 | STY-04 emoji comments: accepted as a module-wide convention awaiting a codemod pass. |
