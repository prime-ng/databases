# Fix Plan — SmartTimetable / TeacherUnavailableController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php` for developer `tarun`. It applies **only** ticked items, in this order.
> 5. Apply TUA-01 before TUA-06: TUA-01 rewrites the same six method bodies that TUA-06 adds return types to.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php` | shared route file — touched only by the TUA-04 and TUA-05 DECISIONs, and only if ticked |
| `resources/views/components/backend/table/action-trashed.blade.php` | shared component — TUA-04 needs no edit here |
| `Modules/SmartTimetable/app/Models/Constraint.php` | owned by [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) |
| `Modules/SchoolSetup/app/Models/Teacher.php` | common, different module |
| `config/permissionslist.php` | shared config; this plan needs no new permission |
| `database/migrations/**` | existing migrations are never edited; a new one is needed only if TUA-11 option (c) is chosen |

## 1. Blockers reachable today

_None._

## 2. Fixes that arm a latent defect (sequenced)

_None._

## 3. Errors & transactions (F1/F2)

- [x] **TUA-01** · M · ERR-00 (D1) + ERR-05 · `TeacherUnavailableController.php:233-255` — delete the controller `try`/`catch` in all six mutating actions, return the model from the closure, and build the response after the closure.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php`
  - **Before** (`TeacherUnavailableController.php:233-255`):
    ```php
        try {
            return DB::transaction(function () use ($validated) {
                $teacherUnavailable = TeacherUnavailable::create($this->attributesFrom($validated));

                activityLog(
                    $teacherUnavailable,
                    'Stored',
                    ['message' => 'Teacher unavailability was created.']
                );

                return $this->backToTab()
                    ->with('success', flash('created.teacher_unavailable'));
            });
        } catch (Throwable $e) {
            Log::error('TeacherUnavailable store failed', [
                'teacher_id' => $validated['teacher_id'] ?? null,
                'error' => $e->getMessage(),
            ]);

            return back()
                ->withInput()
                ->with('error', flash('operation_failed.teacher_unavailable'));
        }
    ```
  - **After:**
    ```php
        $teacherUnavailable = DB::transaction(function () use ($validated) {
            $teacherUnavailable = TeacherUnavailable::create($this->attributesFrom($validated));

            activityLog(
                $teacherUnavailable,
                'Stored',
                ['message' => 'Teacher unavailability was created.']
            );

            return $teacherUnavailable;
        });

        return $this->backToTab()
            ->with('success', flash('created.teacher_unavailable'));
    ```
    Apply the same de-wrap to the other five actions, keeping each `DB::transaction()` closure and its `activityLog()` call exactly as written:
    - `update()` lines 328-363 — delete `try {` and the whole following `catch` block; inside the closure replace the trailing `return $this->backToTab()->with('success', flash('updated.teacher_unavailable'));` with `return $teacherUnavailable;`; after the closure add:
      ```php
      return $this->backToTab()
          ->with('success', flash('updated.teacher_unavailable'));
      ```
    - `destroy()` lines 385-408 — delete `try {` and the following `catch` block; inside the closure replace the trailing `return $this->backToTab()->with('success', flash('trashed.teacher_unavailable'));` with `return $teacherUnavailable;`; after the closure add:
      ```php
      return $this->backToTab()
          ->with('success', flash('trashed.teacher_unavailable'));
      ```
    - `forceDelete()` lines 447-468 — delete `try {` and the following `catch` block; inside the closure replace the trailing `return redirect()->route('smart-timetable.teacher-unavailable.trashed')->with('success', flash('force_deleted.teacher_unavailable'));` with `return $teacherUnavailable;`; after the closure add:
      ```php
      return redirect()
          ->route('smart-timetable.teacher-unavailable.trashed')
          ->with('success', flash('force_deleted.teacher_unavailable'));
      ```
    - `restore()` lines 489-513 — delete `try {` and the following `catch` block; inside the closure replace the trailing `return redirect()->route('smart-timetable.teacher-unavailable.trashed')->with('success', flash('restored.teacher_unavailable'));` with `return $teacherUnavailable;`; after the closure add:
      ```php
      return redirect()
          ->route('smart-timetable.teacher-unavailable.trashed')
          ->with('success', flash('restored.teacher_unavailable'));
      ```
    - `toggleStatus()` lines 548-582 — delete `try {` and the following `catch` block; keep the `if (! $teacherUnavailable->save()) { throw new RuntimeException('Failed to persist the status change.'); }` guard; replace the trailing success-JSON return inside the closure with `return $teacherUnavailable;`; after the closure add:
      ```php
      return response()->json([
          'success' => true,
          'is_active' => $teacherUnavailable->is_active,
          'message' => flash('status_updated.teacher_unavailability'),
      ]);
      ```
    Finally delete the now-unused `use Illuminate\Support\Facades\Log;` (line 9) and `use Throwable;` (line 16) imports; keep `use RuntimeException;` (line 15) because `toggleStatus()` still throws it.
  - **Verify:** `grep -nE 'try \{|catch \(|Log::error' Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php`
  - **Expect:** no output.
  - **Effort:** M

## 4. Authorization (F3)

- [x] **TUA-03** · L · AUTH-04 · `TeacherUnavailableController.php:223` — drop the duplicate `Gate::authorize` in `store`/`update`; the FormRequests already check the same permission and run first.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php`
  - **Before** (`TeacherUnavailableController.php:221-225`):
    ```php
        public function store(StoreTeacherUnavailableRequest $request)
        {
            Gate::authorize('tenant.smart-timetable.teacher-unavailable.create');

            $validated = $request->validated();
    ```
  - **After:**
    ```php
        public function store(StoreTeacherUnavailableRequest $request)
        {
            $validated = $request->validated();
    ```
    Do the same in `update()`: delete only line 318, `Gate::authorize('tenant.smart-timetable.teacher-unavailable.update');`. Leave every other `Gate::authorize()` untouched.
  - **Verify:** `grep -n "Gate::authorize('tenant.smart-timetable.teacher-unavailable.create')" Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php`
  - **Expect:** no output.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [x] **TUA-04** · H · DECISION · RTE-01 · `Modules/SmartTimetable/routes/web.php:274` ⚠ SHARED — Restore runs over a GET request, so a prefetcher can restore a trashed rule with no CSRF token.
  - **Why it is a decision:** it changes a route verb, and the rule file says a route re-scope stops and asks.
  - (a) ⭐ Change it to `Route::patch('/teacher-unavailable/{id}/restore', [TeacherUnavailableController::class, 'restore'])->name('teacher-unavailable.restore');`. The only UI caller is `trash.blade.php:85` through `x-backend.table.action-trashed`, which reads the verb from the route itself, so no blade edit is needed.
  - (b) Change it to `Route::post(...)` instead of `patch` (same effect; `action-trashed` already emits `@method('PATCH')` for non-GET/POST verbs).
  - (c) Leave it as GET and record the risk as accepted.
  - ➜ Choice: PUT, not PATCH (Tarun 2026-10-15, same as CTY-05).

- [x] **TUA-05** · M · DECISION · CTL-03 · `TeacherUnavailableController.php:264,286,379,441,483` + `routes/web.php:272` ⚠ SHARED — five methods take a raw `$id` and call `findOrFail` instead of route-model binding.
  - **Why it is a decision:** a clean conversion renames the route parameter, which is a route re-scope.
  - (a) ⭐ Add `->parameters(['teacher-unavailable' => 'teacherUnavailable'])` to `Route::resource('teacher-unavailable', …)` and bind `TeacherUnavailable $teacherUnavailable` in `show`/`edit`/`destroy`; leave the custom `{id}` routes (`forceDelete`, `restore`) on `findOrFail`. A missing id still 404s.
  - (b) Bind only `show`/`edit`/`destroy` and keep `forceDelete`/`restore` as they are.
  - (c) Accept `findOrFail` as-is (no route change); record as low debt.
  - ➜ Choice: (a) without the rename — snake-case fallback binds `{teacher_unavailable}`. `show`/`edit`/`update`/`destroy`/`toggleStatus` bound; `restore`/`forceDelete` stay on `$id`.

- [x] **TUA-06** · L · CTL-04 · `TeacherUnavailableController.php:175` — add a return type to every public method.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php`
  - **Before** (`TeacherUnavailableController.php:175-181`):
    ```php
        public function index()
        {
            Gate::authorize('tenant.smart-timetable.teacher-unavailable.viewAny');

            $teacherUnavailables = TeacherUnavailable::with(['teacher.user', 'constraint'])
                ->latest()
                ->paginate(15);
    ```
  - **After:**
    ```php
    use Illuminate\Contracts\View\View;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;

    class TeacherUnavailableController extends Controller
    ```
    ```php
        public function index(): View
        {
            Gate::authorize('tenant.smart-timetable.teacher-unavailable.viewAny');

            $teacherUnavailables = TeacherUnavailable::with(['teacher.user', 'constraint'])
                ->latest()
                ->paginate(10);
    ```
    Add the three imports at the top of the file (after line 5) and declare these return types on the remaining methods: `create(): never`, `store(): RedirectResponse`, `show(): View`, `edit(): View`, `update(): RedirectResponse`, `destroy(): RedirectResponse`, `trashedTeacherUnavailable(): View`, `forceDelete(): RedirectResponse`, `restore(): RedirectResponse`, `toggleStatus(): JsonResponse`.
  - **Verify:** `grep -cE 'public function [a-zA-Z_]+\([^)]*\)\s*:' Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php`
  - **Expect:** `11`.
  - **Effort:** M

- [x] **TUA-08** · M · DECISION · MDL-02 · `TeacherUnavailable.php:44` — `period_no` is a JSON column (the DDL says "more then 1 or More Periods") but the model casts it to `integer`, so multi-period is unreachable.
  - **Why it is a decision:** making it a true multi-period field is a feature change touching the model cast, the FormRequest, the blade and the solver readers — not a bug fix; the class docblock records it as BUG-TU-2, deliberately deferred.
  - (a) ⭐ Keep the single-period behaviour for now and record it as accepted (leave the `integer` cast); the write path works today because an HTML form posts a scalar string.
  - (b) Fix it fully now: cast `'period_no' => 'array'`, validate `['nullable', 'array']`, change the blade to a multi-select, and update the solver readers (`AvailabilityCanvasService`, the `TEACHER_UNAVAILABLE_PERIODS` constraint).
  - (c) Revert the DDL intent instead: keep `integer` and add a migration narrowing the column (destructive; not recommended).
  - ➜ Choice: (a) — keep the `integer` cast; single-period behaviour accepted (BUG-TU-2).

- [x] **TUA-09** · L · MDL-04 · `TeacherUnavailable.php:69-77` — return-type the two relationships.
  - **Touches:** `Modules/SmartTimetable/app/Models/TeacherUnavailable.php`
  - **Before** (`TeacherUnavailable.php:69-77`):
    ```php
        public function teacher()
        {
            return $this->belongsTo(Teacher::class, 'teacher_id');
        }

        public function constraint()
        {
            return $this->belongsTo(Constraint::class, 'constraint_id');
        }
    ```
  - **After:**
    ```php
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    ```
    ```php
        public function teacher(): BelongsTo
        {
            return $this->belongsTo(Teacher::class, 'teacher_id');
        }

        public function constraint(): BelongsTo
        {
            return $this->belongsTo(Constraint::class, 'constraint_id');
        }
    ```
    Add the `BelongsTo` import after the existing `use Illuminate\Database\Eloquent\SoftDeletes;` line.
  - **Verify:** `grep -nE 'public function (teacher|constraint)\(\): BelongsTo' Modules/SmartTimetable/app/Models/TeacherUnavailable.php`
  - **Expect:** two hits.
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **TUA-10** · L · QRY-02 · `TeacherUnavailableController.php:181` — paginate the index list at 10, the house standard, matching the trash list.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php`
  - **Before** (`TeacherUnavailableController.php:179-181`):
    ```php
        $teacherUnavailables = TeacherUnavailable::with(['teacher.user', 'constraint'])
            ->latest()
            ->paginate(15);
    ```
  - **After:**
    ```php
        $teacherUnavailables = TeacherUnavailable::with(['teacher.user', 'constraint'])
            ->latest()
            ->paginate(10);
    ```
  - **Verify:** `grep -n "paginate(" Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php`
  - **Expect:** two hits, both `->paginate(10);`.
  - **Effort:** S

## 7. Views (F10)

_None._

## 8. Style (F12) — one item per file

- [x] **TUA-12** · L · STY-01 + STY-04 · `TeacherUnavailableController.php:1` — add `declare(strict_types=1)` and remove the emoji markers from the comments.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php`
  - **Before** (`TeacherUnavailableController.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
    Replace the `⚠ ` marker at the start of the docblock lines 40, 139, 279, 521 and 532 with the plain word `Note:`; keep the rest of each sentence unchanged.
  - **Verify:** `grep -c "declare(strict_types" Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php`
  - **Expect:** `1`.
  - **Effort:** S

- [x] **TUA-13** · L · STY-01 · `Modules/SmartTimetable/app/Models/TeacherUnavailable.php:1` — add `declare(strict_types=1)`.
  - **Touches:** `Modules/SmartTimetable/app/Models/TeacherUnavailable.php`
  - **Before** (`TeacherUnavailable.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Models;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/SmartTimetable/app/Models/TeacherUnavailable.php`
  - **Expect:** one hit on line 3.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **TUA-11** · M · DECISION · TXN-06 — the duplicate-overlap guard (`overlapExists()`) is a check-then-act with no lock and no unique index; two concurrent writes can insert overlapping rules.
  - **Why it is a decision:** a true fix either adds a unique index (a migration, Tarun's hand) or changes the concurrency contract, and it must not be applied in the same pass as TUA-01, which rewrites the surrounding methods.
  - (a) ⭐ Accept for now: the screen is a low-traffic admin config page with two writers at most, and the class docblock already documents the absence of a unique index; record the race as accepted.
  - (b) Move the guard inside the `DB::transaction` (after TUA-01) and wrap the read in `lockForUpdate()`; keep the same friendly `withErrors` response.
  - (c) Add an additive migration with a unique index over the overlap key plus a duplicate-catch; requires a data check and `php artisan tenants:migrate` by Tarun.
  - ➜ Choice: (a) — accepted; TUA-11 note in the `overlapExists()` docblock.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TUA-02 | Folded into TUA-01: that item's `After` returns the model from the closure and builds the response after `DB::transaction()` returns, which is the whole of TXN-05 for all six methods. |
| TUA-07 | Dead-view cleanup (`teacher-unavailable/create.blade.php`) — deleting an unreferenced file is a views cleanup, not a code fix; re-prove `routed=0 refs=0` at fix time before removing it. |
