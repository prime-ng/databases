# Status — SmartTimetable / TeacherUnavailableController

**Fixed:** 2026-10-15 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

Decisions (Tarun, 2026-10-15): restore becomes PUT; bind the resource methods; accept the save race with a comment. TUA-08 took the recommended (a), keep the integer cast.

## 1. Pre-applied work
none

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| TUA-01 | TeacherUnavailableController.php (6 mutations) | try/catch removed (D1), writes in transactions, response after the closure | `grep -c "try {"` | 0 | 2026-10-15 |
| TUA-03 | Controller store/update | duplicate gate dropped; the Store/Update FormRequests authorize | grep | no Gate in store/update | 2026-10-15 |
| TUA-04 | routes/web.php:278 | restore is `Route::put` | router probe | `PUT …teacher-unavailable.restore` | 2026-10-15 |
| TUA-05 | Controller show/edit/update/destroy/toggleStatus | bound to `TeacherUnavailable $teacherUnavailable` via the snake-case fallback; restore/forceDelete stay on `$id` | reflection | `{teacher_unavailable}` ↔ typed arg | 2026-10-15 |
| TUA-06 | Controller | return types on all 11 public methods | grep | 11/11 | 2026-10-15 |
| TUA-08 | Models/TeacherUnavailable.php:46 | accepted (choice a) — `'period_no' => 'integer'` kept | grep | line 46 | 2026-10-15 |
| TUA-09 | Models/TeacherUnavailable.php:71,76 | `teacher(): BelongsTo`, `constraint(): BelongsTo` | grep | 2 hits | 2026-10-15 |
| TUA-10 | Controller:189 | index paginates at 10 | grep | `->paginate(10)` | 2026-10-15 |
| TUA-11 | Controller:108 | accepted (choice a); TUA-11 note in the `overlapExists()` docblock | grep | 1 hit | 2026-10-15 |
| TUA-12 | Controller | `strict_types`, emoji markers removed | grep strict / emoji | 1 / 0 | 2026-10-15 |
| TUA-13 | Models/TeacherUnavailable.php | `strict_types` | grep | 1 | 2026-10-15 |

## 3. Not applied
None — every item was ticked and applied.

## 4. Needs Tarun's hand
- **Run the Dusk suites yourself.** Restore is now PUT on all five resources, so the "GET /{missing}/restore expects 404" tests will fail: `TtConstraintsTest:1528`, `TtConstraintTypeTest:1465`, `TtRoomUnavailableTest:1440` and the matching test in `TtTeacherUnavailableTest`. A GET on those URLs is now a 405 (or the DecryptUrl redirect). Not edited — tests are out of scope (D4).
- A browser check of the trash page Restore button on each of the five tabs of `/smart-timetable/constraint-engine` (it should submit `_method=PUT`).
- No migration, seeder or permission sync is needed.

## 5. Unverifiable by this workflow (no tests, D4)
- The failure path of every mutation now relies on the central handler (D1).
- The overlap race (TUA-11) and the single-period cast (TUA-08) are accepted, not fixed.

## 6. Verification log
```
php -l   (all touched PHP files)                      -> No syntax errors
class_exists (22 classes: 5 controllers, 6 requests,
  5 models, ConstraintManager/Evaluator/Factory,
  DatabaseConstraintService, 2 constraint classes)     -> all true
vendor/bin/pint <touched files> --format agent         -> fixed; php -l + class_exists re-run after
router probe (uncached)                                -> PUT smart-timetable.{constraint,constraint-category-scope,
                                                          constraint-type,teacher-unavailable,room-unavailable}.restore
                                                          every routed action: method_exists ok
grep "getMessage" / "^use ...Facades\\Log;" in the 5 controllers -> 0 / 0
```

## 7. Final state
Status: FIXED · Open: B 0 · H 0 · M 2 · L 0
(M: TUA-08 accepted, TUA-11 accepted race.)
