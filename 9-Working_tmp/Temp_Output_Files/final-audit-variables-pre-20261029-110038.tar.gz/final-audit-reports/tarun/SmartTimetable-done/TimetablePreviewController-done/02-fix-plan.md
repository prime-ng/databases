# Fix Plan — SmartTimetable / TimetablePreviewController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` to `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php` | route file; no route change is proposed by this plan |
| `Modules/SmartTimetable/app/Services/Preview/PreviewGridState.php` | owned by the TimetableGenerationController report |
| `Modules/SmartTimetable/app/Services/Preview/SlotOwnerResolver.php` | owned by the TimetableExportController report |
| `Modules/SmartTimetable/app/Services/TimetableGenerationService.php` | owned by the TimetableGenerationController report |
| `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php` | owned by the TimetableWorkspaceController report |
| `Modules/TimetableFoundation/app/Services/OptionCellResolver.php` | owned by the TimetableFoundationController report |
| `Modules/SmartTimetable/resources/views/preview/index.blade.php` | shared with the generate path; owned by the TimetableGenerationController report |
| `config/permissionslist.php` | shared registry; no permission key is added or renamed here |

## 1. Blockers reachable today

None. The audit found no B-severity item: every routed method gates first, every multi-table write is inside one transaction, and no exception text reaches a user.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [x] **TPV-01** · H · ERR-00 · `TimetablePreviewController.php:681-930` — remove the four write-method try/catch wrappers so D1 (the Laravel idiom) holds and the central handler logs the exception object.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php`
  - **Before** (`TimetablePreviewController.php:681-682`, `placeCell` opening):
    ```php
            try {
                $timetable = Timetable::findOrFail($validated['timetable_id']);
    ```
  - **After:**
    ```php
            $timetable = Timetable::findOrFail($validated['timetable_id']);
    ```
  - **Before** (`TimetablePreviewController.php:915-930`, `placeCell` tail):
    ```php
                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic catch
                // below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('TimetablePreviewController::placeCell failed', ['error' => $e->getMessage()]);

                // Declared `: JsonResponse` and called by the grid — a redirect here was a
                // TypeError, and fetch() would have followed it as success.
                return response()->json([
                    'success' => false,
                    'message' => 'The operation could not be completed.',
                ], 500);
            }
        }
    ```
  - **After:**
    ```php
                });
        }
    ```
  - **Before** (`TimetablePreviewController.php:955-956`, `removeCell` opening):
    ```php
            try {
                $timetable = Timetable::findOrFail($validated['timetable_id']);
    ```
  - **After:**
    ```php
            $timetable = Timetable::findOrFail($validated['timetable_id']);
    ```
  - **Before** (`TimetablePreviewController.php:1071-1082`, `removeCell` tail):
    ```php
                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('TimetablePreviewController::removeCell failed', ['error' => $e->getMessage()]);

                return response()->json([
                    'success' => false,
                    'message' => 'The operation could not be completed.',
                ], 500);
            }
        }
    ```
  - **After:**
    ```php
                });
        }
    ```
  - **Before** (`TimetablePreviewController.php:1120-1121`, `moveCell` opening):
    ```php
            try {
                $timetable = Timetable::findOrFail($validated['timetable_id']);
    ```
  - **After:**
    ```php
            $timetable = Timetable::findOrFail($validated['timetable_id']);
    ```
  - **Before** (`TimetablePreviewController.php:1320-1331`, `moveCell` tail):
    ```php
                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('TimetablePreviewController::moveCell failed', ['error' => $e->getMessage()]);

                return response()->json([
                    'success' => false,
                    'message' => 'The operation could not be completed.',
                ], 500);
            }
        }
    ```
  - **After:**
    ```php
                });
        }
    ```
  - **Before** (`TimetablePreviewController.php:1398-1399`, `toggleLock` opening):
    ```php
            try {
                return DB::transaction(function () use ($validated) {
    ```
  - **After:**
    ```php
            return DB::transaction(function () use ($validated) {
    ```
  - **Before** (`TimetablePreviewController.php:1437-1448`, `toggleLock` tail):
    ```php
                });
            } catch (ModelNotFoundException $e) {
                throw $e;
            } catch (\Throwable $e) {
                Log::error('TimetablePreviewController::toggleLock failed', ['error' => $e->getMessage()]);

                return response()->json([
                    'success' => false,
                    'message' => 'The operation could not be completed.',
                ], 500);
            }
        }
    ```
  - **After:**
    ```php
                });
        }
    ```
  - **Verify:** `grep -nE 'try \{|catch \(' Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php`
  - **Expect:** no output.
  - **Effort:** M

- [x] **TPV-07** · L · CTL-04 · `TimetablePreviewController.php:46` — give `preview()` a return type.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php`
  - **Before** (`TimetablePreviewController.php:8`):
    ```php
    use Illuminate\Http\JsonResponse;
    ```
  - **After:**
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\View\View;
    ```
  - **Before** (`TimetablePreviewController.php:46`):
    ```php
        public function preview(Timetable $timetable)
    ```
  - **After:**
    ```php
        public function preview(Timetable $timetable): RedirectResponse|View
    ```
  - **Verify:** `grep -n 'public function preview' Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php`
  - **Expect:** `public function preview(Timetable $timetable): RedirectResponse|View`.
  - **Effort:** S

- [x] **TPV-08** · M · CTL-10 · `TimetablePreviewController.php:1602-1651` — delete the three uncalled private helpers `loadActivities()`, `loadSchoolDays()` and `loadPeriodSet()`.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php`
  - **Before** (`TimetablePreviewController.php:1602-1651`):
    ```php
        private function loadActivities(
            int $classId,
            int $sectionId
        ): Collection {
            return Activity::where('is_active', true)
                ->where('class_id', $classId)
                ->where('section_id', $sectionId)
                ->with([
                    'class',
                    'section',
                    'subject',
                    'studyFormat',
                    'subjectStudyFormat.subject',
                    'subjectStudyFormat.studyFormat',
                    'subjectType',
                    'teachers',
                    'classGroup',
                    'classSubgroup',
                ])
                ->get()
                ->keyBy('id');
        }

        private function loadClassSections(): Collection
        {
            return ClassSection::where('is_active', true)
                ->with(['class', 'section', 'classTeacher', 'assistanceClassTeacher'])
                ->get();
        }

        private function loadSchoolDays(): Collection
        {
            return SchoolDay::schoolDays()->get();
        }

        private function loadPeriodSet(): Collection
        {
            return PeriodSetPeriod::with('periodType')
                ->where('is_active', true)
                ->orderBy('period_ord', 'asc')
                ->get()
                ->each(function ($period) {
                    // Ensure break periods are properly marked
                    if (in_array($period->code, ['SBREAK', 'LUNCH'])) {
                        $period->is_break = true;
                    } else {
                        $period->is_break = false;
                    }
                });
        }
    ```
  - **After:**
    ```php
        private function loadClassSections(): Collection
        {
            return ClassSection::where('is_active', true)
                ->with(['class', 'section', 'classTeacher', 'assistanceClassTeacher'])
                ->get();
        }
    ```
  - **Verify:** `grep -nE 'private function load(Activities|SchoolDays|PeriodSet)\b' Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

No plan item. See §10.

## 5. Validation, routes, models (F4/F5/F7)

No plan item. See §9.

## 6. Queries & performance (F9)

- [x] **TPV-12** · H · TEN-02 · `PreviewPlacementService.php:190`, `:222` and `TimetablePreviewController.php:1528` — add the tenant id to every process-static cache key so a long-lived worker cannot serve one tenant's ids to another.
  - **Touches:** `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php`, `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php`
  - **Before** (`PreviewPlacementService.php:190`):
    ```php
            $key = (app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
    ```
  - **After:**
    ```php
            $key = (tenant('id') ?? 'central').':'.(app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
    ```
  - **Before** (`PreviewPlacementService.php:222`):
    ```php
            $key = (app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
    ```
  - **After:**
    ```php
            $key = (tenant('id') ?? 'central').':'.(app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
    ```
  - **Before** (`TimetablePreviewController.php:1528`):
    ```php
            $key = $classId.':'.$sectionId;
    ```
  - **After:**
    ```php
            $key = (tenant('id') ?? 'central').':'.$classId.':'.$sectionId;
    ```
  - **Verify:** `grep -nE '\\$key = ' Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php`
  - **Expect:** every `$key = ` line starts with `tenant('id')`.
  - **Effort:** S

## 7. Views (F10)

- [x] **TPV-11** · H · VIEW-03 · `_class-conflicts.blade.php:140` — escape the teacher name before it is wrapped in the intentional bold tag, so the unescaped output at line 326 cannot carry an event handler.
  - **Touches:** `Modules/SmartTimetable/resources/views/preview/partials/_class-conflicts.blade.php`
  - **Before** (`_class-conflicts.blade.php:140-141`):
    ```php
                        $detail = $assignedName
                            ? "The first period is being taught by <strong>{$assignedName}</strong> instead of the class teacher."
    ```
  - **After:**
    ```php
                        $detail = $assignedName
                            ? 'The first period is being taught by <strong>'.e($assignedName).'</strong> instead of the class teacher.'
    ```
  - **Verify:** `grep -n 'being taught by' Modules/SmartTimetable/resources/views/preview/partials/_class-conflicts.blade.php`
  - **Expect:** one line containing `e($assignedName)` inside the string concatenation.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [x] **TPV-13** · L · STY-01 · the three files — add `declare(strict_types=1);` below the opening tag.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php`, `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php`, `Modules/SmartTimetable/app/Services/Preview/PreviewDerivedData.php`
  - **Before** (`TimetablePreviewController.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **Before** (`PreviewPlacementService.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Services\Preview;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Services\Preview;
    ```
  - **Before** (`PreviewDerivedData.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Services\Preview;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Services\Preview;
    ```
  - **Verify:** `grep -c 'declare(strict_types=1);' Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php Modules/SmartTimetable/app/Services/Preview/PreviewDerivedData.php`
  - **Expect:** `1` for each of the three files.
  - **Effort:** S

- [x] **TPV-14** · L · STY-04 · the three files — remove the emoji markers from comments, and delete the commented-out return at `TimetablePreviewController.php:130`.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php`, `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php`, `Modules/SmartTimetable/app/Services/Preview/PreviewDerivedData.php`
  - **Before** (`TimetablePreviewController.php:67-70`):
    ```php
                // ⚠ These were NEVER set on this path, and the consequences were
                // visible on screen. The grid body decides a cell's treatment with
                //     $isTeaching = $period->is_teaching ?? ! ($period->is_break ?? false);
                // Both were null, so `?? ! (null ?? false)` evaluated to TRUE and
    ```
  - **After:**
    ```php
                // These were NEVER set on this path, and the consequences were
                // visible on screen. The grid body decides a cell's treatment with
                //     $isTeaching = $period->is_teaching ?? ! ($period->is_break ?? false);
                // Both were null, so `?? ! (null ?? false)` evaluated to TRUE and
    ```
  - **Before** (`PreviewPlacementService.php:16-21`):
    ```php
     *
     * ⛔ WHY THIS EXISTS AT ALL — THE BUG IT WAS BUILT TO FIX.
     *
     * TimetablePreviewController::placeCell() used to find the cell it was about to
     * replace with nothing but
     *
    ```
  - **After:**
    ```php
     *
     * WHY THIS EXISTS AT ALL — THE BUG IT WAS BUILT TO FIX.
     *
     * TimetablePreviewController::placeCell() used to find the cell it was about to
     * replace with nothing but
     *
    ```
  - **Before** (`PreviewDerivedData.php:14-19`):
    ```php
     *
     * ⛔ WHY THIS EXISTS. There are TWO routes to preview/index.blade.php:
     *
     *   generation → PreviewViewData::fromResult()  →  passes requiredByClass,
     *                                                  combinedBySlot and room_conflicts
     *                                                  straight off the solver's result
    ```
  - **After:**
    ```php
     *
     * WHY THIS EXISTS. There are TWO routes to preview/index.blade.php:
     *
     *   generation → PreviewViewData::fromResult()  →  passes requiredByClass,
     *                                                  combinedBySlot and room_conflicts
     *                                                  straight off the solver's result
    ```
  - **Note:** the same edit removes every other emoji marker in the three files; the scan rows are listed in `01-report.md` F12 (TPV-14). Delete the commented-out return at `TimetablePreviewController.php:130` as well.
  - **Verify:** `grep -rnP '[\x{2600}-\x{27BF}\x{1F300}-\x{1FAFF}\x{2B00}-\x{2BFF}]' Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php Modules/SmartTimetable/app/Services/Preview/PreviewDerivedData.php`
  - **Expect:** no output.
  - **Effort:** M

## 9. Deferred / decisions

- [x] **TPV-04** · M · DECISION · VAL-02 — should the four write methods move their inline `$request->validate()` rules into Form Requests now?
  - **Why it is a decision:** it creates new files and overlaps the CTL-01 split, which is itself deferred.
  - (a) ⭐ defer to the CTL-01 split pass (D3), where the controller is carved into resource controllers and each gets its own Form Request
  - (b) extract four Form Requests now and inject them into the four methods
  - (c) leave the inline validation and record it as accepted for this screen
  - ➜ Choice: (a) defer to the CTL-01 split pass — Tarun, 2026-10-16

- [x] **TPV-05** · M · DECISION · CTL-01 — split the 1,652-line controller?
  - **Why it is a decision:** D3 defers god-controller splits; it is not applied in this pass.
  - (a) ⭐ defer to the split pass (D3), tracked under this report
  - (b) split now into a preview controller and a cell-edit controller, keeping the routes and URLs
  - (c) leave as is, record the size as accepted
  - ➜ Choice: (a) defer to the split pass (D3) — Tarun, 2026-10-16

- [x] **TPV-06** · H · DECISION · CTL-02 — break up `preview()` (579 lines) and the write methods?
  - **Why it is a decision:** method extraction overlaps the CTL-01 split and is a behaviour-preserving refactor, not a bug fix.
  - (a) ⭐ defer with the CTL-01 split (D3), tracked under this report
  - (b) extract the `preview()` payload builders into private methods now
  - (c) leave as is, record the method lengths as accepted
  - ➜ Choice: (a) defer to the split pass — Tarun, 2026-10-16

- [x] **TPV-09** · H · DECISION · QRY-01 — rewrite `recomputeConflictsAtSlot()` to evaluate conflicts in memory?
  - **Why it is a decision:** a safe fix requires `checkConflicts()` to accept a pre-loaded collection (a second method's signature change), so it is a design change, not a one-line edit.
  - (a) ⭐ defer to a dedicated change that refactors `checkConflicts()` to take the pre-loaded slot cells
  - (b) pre-load the slot cells and duplicate the conflict logic in memory inside `recomputeConflictsAtSlot()` now
  - (c) leave as is, record the per-write query count as accepted
  - ➜ Choice: (a) defer to a dedicated checkConflicts() change — Tarun, 2026-10-16

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TPV-02 | The TXN-05 rewrite (return a payload from each closure, build the response after) is a mechanical refactor of four large closures; it is folded into the deferred CTL-01 split rather than rewritten twice. |
| TPV-03 | The repeated permission literal is project-wide; a shared constant is worth adding during the CTL-01 split, not in this pass. |
| TPV-10 | Accepted design tradeoff: the all-classes route is the secondary view and the workspace route (one class at a time) is the mitigated path; no code change planned. |
