# Status — SmartTimetable / TimetablePreviewController

**Fixed:** 2026-10-16 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
none — the only PRE-APPLIED file (`tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md`) lists no file in this controller's scope.

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| TPV-01 | `TimetablePreviewController.php` placeCell / removeCell / moveCell / toggleLock | Removed the four whole-body `try { … } catch` wrappers (D1). The inner blocks were dedented one level, not just unwrapped. The now-unused `ModelNotFoundException` and `Log` imports were dropped. | `grep -nE "try \{\|catch \(" TimetablePreviewController.php` | no output | 2026-10-16 |
| TPV-07 | `TimetablePreviewController.php:48` | `preview(Timetable $timetable): RedirectResponse\|View`. Added the `RedirectResponse` and `Illuminate\View\View` imports. Only two returns exist (`redirect()->back()` at :81, `view(...)` at :540). | `grep -n "public function preview" …` | `48: … RedirectResponse\|View` | 2026-10-16 |
| TPV-08 | `TimetablePreviewController.php` (old 1602-1651) | Deleted `loadActivities()`, `loadSchoolDays()` and `loadPeriodSet()`, which had no callers. Kept `loadClassSections()`. The `Activity`, `SchoolDay` and `PeriodSetPeriod` imports stay because `preview()` still uses them. | `grep -nE "loadActivities\|loadSchoolDays\|loadPeriodSet" …` | no output | 2026-10-16 |
| TPV-11 | `_class-conflicts.blade.php:140` | The teacher name is now wrapped in `e()` before the intentional `<strong>`: `'…<strong>'.e($assignedName).'</strong>…'` | `grep -nF 'e($assignedName)' …` | `140:` match | 2026-10-16 |
| TPV-12 | `PreviewPlacementService.php:193`, `:226`; `TimetablePreviewController.php:1483` | All three process-static memo keys now start with `(tenant('id') ?? 'central').':'`. Each has a TPV-12 comment. | `grep -n "tenant('id')" …` | 3 matches | 2026-10-16 |
| TPV-13 | all three PHP files, line 3; `TimetablePreviewController.php:698` | Added `declare(strict_types=1);` to all three. The one int-typed call fed straight from the request (`resolvePlacementTargets(?int $subActivityId)`) now casts with `(int)`. All other typed calls were audited and already receive ints (the targets are cast in the service, and `classSectionLabel` and `activityPayload` get ints). Built-in calls were checked too: `trim`, `round`, `abs` and `strtolower` all get the right types. | `grep -n "declare(strict_types=1)" …` | 3 matches | 2026-10-16 |
| TPV-14 | all three PHP files | Removed every emoji marker from the comments. Numbered keycaps became `3.`, `10.`, `10.5`, `11.`. Deleted the commented-out `// return $cells->first()->activity->activityTeachers;`. | plan's `grep -rnP '[\x{2600}-\x{27BF}\x{1F300}-\x{1FAFF}\x{2B00}-\x{2BFF}]'` (+ `\x{FE0F}\x{20E3}`) | 0 / 0 / 0 | 2026-10-16 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| TPV-02 | no plan item (§10) | Folded into the CTL-01 split. |
| TPV-03 | no plan item (§10) | A shared permission constant belongs in the split. |
| TPV-04 | DECISION (a): deferred | Form Requests will be created in the CTL-01 split pass. |
| TPV-05 | DECISION (a): deferred | God-controller split (D3). |
| TPV-06 | DECISION (a): deferred | Method break-up goes with the split. |
| TPV-09 | DECISION (a): deferred | In-memory conflict rewrite gets its own `checkConflicts()` change. |
| TPV-10 | no plan item (§10) | Accepted tradeoff: the workspace route is the mitigated path. |

## 4. Needs Tarun's hand
- A browser check of `/smart-timetable/…/preview` (all classes) and of one place, move, remove and lock action on a DRAFT timetable. Without the controller catch, a failure now surfaces through the central handler as `{success:false, message}` with a 500. Confirm the Vue island shows that message.
- Nothing to migrate, seed or sync.

## 5. Unverifiable by this workflow (no tests, D4)
- The four write endpoints' failure path (central handler rendering) was not exercised. It was verified statically only.
- The strict_types change was checked by reading every typed call site. A runtime TypeError on an untraced path cannot be ruled out without executing the screen.

## 6. Verification log
```
php -l (3 PHP files)              -> No syntax errors detected  x3
class_exists                       -> TimetablePreviewController OK · PreviewPlacementService OK · PreviewDerivedData OK
router probe (method_exists)       -> preview.allClasses->preview · placeCell · removeCell · moveCell · toggleCellLock->toggleLock · bad=0
blade compile _class-conflicts     -> push 0 / startPush 0 ; php -l compiled: No syntax errors
vendor/bin/pint <3 files> --format agent -> fixed (TimetablePreviewController: ordered_imports, braces_position, …); re-linted clean after Pint
grep try/catch in controller       -> none
grep tenant('id') keys             -> 3
grep strict_types                  -> 3
emoji grep (incl. FE0F/20E3)       -> 0 / 0 / 0
```

## 7. Final state
Status: FIXED · Open: B 0 · H 2 · M 5 · L 0
