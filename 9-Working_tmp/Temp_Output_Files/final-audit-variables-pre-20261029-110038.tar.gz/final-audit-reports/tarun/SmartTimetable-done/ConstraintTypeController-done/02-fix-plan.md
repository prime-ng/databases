# Fix Plan — SmartTimetable / ConstraintTypeController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php` for developer `tarun`. It applies **only** ticked items, in this order.
> 5. ⚠ CTY-12 must be applied **before** CTY-01: CTY-12 adds a guard before the `try` block that CTY-01 then removes.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php` | shared route file — touched only by the CTY-05 DECISION, and only if ticked |
| `resources/views/components/backend/table/action-trashed.blade.php` | shared component — CTY-05 needs no edit here |
| `Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php` | owned by [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) |
| `Modules/SmartTimetable/app/Models/Constraint.php` | owned by [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) |
| `config/permissionslist.php` | shared config; this plan needs no new permission |
| `database/migrations/**` | existing migrations are never edited; this plan needs no migration |

## 1. Blockers reachable today

_None._

## 2. Fixes that arm a latent defect (sequenced)

- [x] **CTY-12** · M · F13 deep-read · `ConstraintTypeController.php:211-218` — refuse to force-delete a non-system constraint type that constraints still reference, before the `try` CTY-01 removes.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Before** (`ConstraintTypeController.php:211-218`):
    ```php
        $constraintType = ConstraintType::withTrashed()->findOrFail($id);

        // Force-delete is irreversible and tt_constraints.constraint_type_id has NO
        // foreign key, so deleting a system type would silently orphan every
        // constraint referencing it — with no DB error to warn anyone.
        if ($constraintType->is_system) {
            return back()->with('error', $this->systemRecordMessage($constraintType, 'permanently deleted'));
        }
    ```
  - **After:**
    ```php
        $constraintType = ConstraintType::withTrashed()->findOrFail($id);

        // Force-delete is irreversible and tt_constraints.constraint_type_id has NO
        // foreign key, so deleting a system type would silently orphan every
        // constraint referencing it — with no DB error to warn anyone.
        if ($constraintType->is_system) {
            return back()->with('error', $this->systemRecordMessage($constraintType, 'permanently deleted'));
        }

        // CTY-12 (2026-10-10): tt_constraints.constraint_type_id has no foreign key, so a
        // permanent delete silently orphans every constraint that references this type.
        if ($constraintType->constraints()->exists()) {
            return back()->with('error', "Constraint type \"{$constraintType->name}\" is used by one or more constraints and cannot be permanently deleted.");
        }
    ```
  - **Verify:** `grep -n "constraints()->exists()" Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Expect:** one hit near line 220.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [x] **CTY-01** · M · ERR-00 (D1) + ERR-05 · `ConstraintTypeController.php:55-75` — delete the controller `try`/`catch` in all six mutating actions and build the response after the closure.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Before** (`ConstraintTypeController.php:55-75`):
    ```php
        try {
            // Rule A2 — the record AND sys_activity_logs are two tables, so the whole
            // sequence belongs in one transaction. Rule A3 — activityLog() runs AFTER
            // the write and INSIDE the transaction, so a failed insert cannot leave
            // behind a log row claiming a creation that never happened.
            return DB::transaction(function () use ($request, $paramSchema) {
                $constraintType = ConstraintType::create(
                    $request->payload($paramSchema) + ['is_system' => false]
                );

                activityLog($constraintType, 'Created', ['message' => 'Constraint type was created successfully.']);

                return redirect()
                    ->route('smart-timetable.menu.constraintEngine', ['tab' => 'constraint-types'])
                    ->with('success', flash('created.constraint_type'));
            });
        } catch (\Throwable $e) {
            Log::error('ConstraintType store failed', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'Failed to create constraint type.');
        }
    ```
  - **After:**
    ```php
        $constraintType = DB::transaction(function () use ($request, $paramSchema) {
            $constraintType = ConstraintType::create(
                $request->payload($paramSchema) + ['is_system' => false]
            );

            activityLog($constraintType, 'Created', ['message' => 'Constraint type was created successfully.']);

            return $constraintType;
        });

        return redirect()
            ->route('smart-timetable.menu.constraintEngine', ['tab' => 'constraint-types'])
            ->with('success', flash('created.constraint_type'));
    ```
    Apply the same de-wrap to the other five actions, keeping each `DB::transaction()` closure and its `activityLog()` call exactly as written:
    - `update()` lines 127-141 — also return the model from the closure and build the `redirect()` after it, exactly as the `store` After does.
    - `destroy()` lines 160-184 — remove `try {`/`} catch (\Throwable $e) { Log::error(...); return back()...; }` and de-indent the closure; keep the `redirect()` that already sits after the closure.
    - `forceDelete()` lines 220-240 — same, after CTY-12 has added the guard above.
    - `restore()` lines 252-273 — same.
    - `toggleStatus()` lines 287-322 — same; keep the `response()->json(...)` that already sits after the closure, and keep the `return` that follows the transaction.
    If the `Log` import becomes unused after this, remove the `use Illuminate\Support\Facades\Log;` line (line 9); the private `normalizeParamSchema()` catch at lines 356-360 stays.
  - **Verify:** `grep -nE 'try \{|catch \(' Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Expect:** only the `normalizeParamSchema()` catch remains (one `try {` and one `} catch` near lines 356-360); no other hits.
  - **Effort:** M

## 4. Authorization (F3)

- [x] **CTY-03** · L · AUTH-04 · `ConstraintTypeController.php:46` — drop the duplicate `Gate::authorize` in `store`/`update`; `ConstraintTypeRequest::authorize()` already checks the same permission and runs first.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Before** (`ConstraintTypeController.php:44-48`):
    ```php
        public function store(ConstraintTypeRequest $request)
        {
            Gate::authorize('tenant.smart-timetable.constraint-type.create');

            $paramSchema = $this->normalizeParamSchema($request->validated('param_schema'));
    ```
  - **After:**
    ```php
        public function store(ConstraintTypeRequest $request)
        {
            $paramSchema = $this->normalizeParamSchema($request->validated('param_schema'));
    ```
    Do the same in `update()`: delete only line 110, `Gate::authorize('tenant.smart-timetable.constraint-type.update');`. Leave every other `Gate::authorize()` untouched.
  - **Verify:** `grep -n "Gate::authorize('tenant.smart-timetable.constraint-type.create')\|Gate::authorize('tenant.smart-timetable.constraint-type.update')" Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Expect:** no `.create` hit; the `.update` hits remain only in `edit()` and `toggleStatus()` (two lines).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [x] **CTY-04** · M · VAL-05 · `ConstraintTypeRequest.php:60-64` — type the two untyped fields so invalid JSON and non-flag values fail validation instead of being coerced.
  - **Touches:** `Modules/SmartTimetable/app/Http/Requests/ConstraintTypeRequest.php`
  - **Before** (`ConstraintTypeRequest.php:60-64`):
    ```php
                // JSON string OR null — JSON-decoded in controller
                'param_schema' => ['nullable'],

                'is_active' => ['nullable'],
            ];
    ```
  - **After:**
    ```php
                // JSON string OR null — validated here, decoded in the controller
                'param_schema' => ['nullable', 'json'],

                'is_active' => ['nullable', 'boolean'],
            ];
    ```
  - **Verify:** `grep -nE "'param_schema'|'is_active'" Modules/SmartTimetable/app/Http/Requests/ConstraintTypeRequest.php`
  - **Expect:** `'param_schema' => ['nullable', 'json'],` and `'is_active' => ['nullable', 'boolean'],`.
  - **Effort:** S

- [x] **CTY-05** · H · DECISION · RTE-01 · `Modules/SmartTimetable/routes/web.php:267` ⚠ SHARED — Restore runs over a GET request, so a prefetcher can restore a trashed constraint type with no CSRF token.
  - **Why it is a decision:** it changes a route verb, and the rule file says a route re-scope stops and asks.
  - (a) ⭐ Change it to `Route::patch('/constraint-type/{id}/restore', [ConstraintTypeController::class, 'restore'])->name('constraint-type.restore');`. The only UI caller is `trash.blade.php:72` through `x-backend.table.action-trashed`, which reads the verb from the route itself, so no blade edit is needed.
  - (b) Change it to `Route::post(...)` instead of `patch` (same effect; `action-trashed` already emits `@method('PATCH')` for non-GET/POST verbs).
  - (c) Leave it as GET and record the risk as accepted.
  - ➜ Choice: PUT, not PATCH (Tarun 2026-10-15, same verb for all five Constraint Engine restore routes). `action-trashed` reads the verb from the route, so no blade edit.

- [x] **CTY-06** · M · DECISION · CTL-03 · `ConstraintTypeController.php:81,93,147,207,246` + `routes/web.php:265` ⚠ SHARED — five methods take a raw `$id` and call `findOrFail` instead of route-model binding.
  - **Why it is a decision:** a clean conversion renames the route parameter, which is a route re-scope.
  - (a) ⭐ Add `->parameters(['constraint-type' => 'constraintType'])` to `Route::resource('constraint-type', …)` and bind `ConstraintType $constraintType` in `show`/`edit`/`destroy`; leave the custom `{id}` routes (`forceDelete`, `restore`) on `findOrFail`. A missing id still 404s.
  - (b) Bind only `show`/`edit`/`update`/`destroy` and keep `trashedConstraintType`/`forceDelete`/`restore` as they are.
  - (c) Accept `findOrFail` as-is (no route change); record as low debt.
  - ➜ Choice: (a) without the `->parameters()` rename — Laravel's snake-case fallback already binds `{constraint_type}` to `$constraintType`. `show`/`edit`/`update`/`destroy`/`toggleStatus` bound; `restore`/`forceDelete` stay on `$id`.

- [x] **CTY-07** · L · CTL-04 · `ConstraintTypeController.php:19` — add a return type to every public method.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Before** (`ConstraintTypeController.php:19-24`):
    ```php
        public function index()
        {
            Gate::authorize('tenant.smart-timetable.constraint-type.viewAny');

            return redirect()->route('smart-timetable.menu.constraintEngine');
        }
    ```
  - **After:**
    ```php
    use Illuminate\Contracts\View\View;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;

    class ConstraintTypeController extends Controller
    ```
    ```php
        public function index(): RedirectResponse
        {
            Gate::authorize('tenant.smart-timetable.constraint-type.viewAny');

            return redirect()->route('smart-timetable.menu.constraintEngine');
        }
    ```
    Add the three imports at the top of the file (after line 5) and declare these return types on the remaining methods: `create(): never`, `store(): RedirectResponse`, `show(): View`, `edit(): View`, `update(): RedirectResponse`, `destroy(): RedirectResponse`, `trashedConstraintType(): View`, `forceDelete(): RedirectResponse`, `restore(): RedirectResponse`, `toggleStatus(): JsonResponse`.
  - **Verify:** `grep -cE 'public function [a-zA-Z_]+\([^)]*\)\s*:' Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Expect:** `11`.
  - **Effort:** M

## 6. Queries & performance (F9)

- [x] **CTY-10** · M · QRY-01 / VIEW-02 · `ConstraintTypeController.php:194-196` — eager-load the two relations the trash view reads per row, so the list runs 3 queries instead of 21.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Before** (`ConstraintTypeController.php:194-196`):
    ```php
            $constraintTypes = ConstraintType::onlyTrashed()
                ->orderBy('name')
                ->paginate(10);
    ```
  - **After:**
    ```php
            $constraintTypes = ConstraintType::onlyTrashed()
                ->with(['category', 'constraintScope'])
                ->orderBy('name')
                ->paginate(10);
    ```
  - **Verify:** `grep -n "with(\['category', 'constraintScope'\])" Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Expect:** two hits — `show()` near line 85 and `trashedConstraintType()` near line 195.
  - **Effort:** S

## 7. Views (F10)

_None._

## 8. Style (F12) — one item per file

- [x] **CTY-11** · L · STY-01 · `ConstraintTypeController.php:1` — add `declare(strict_types=1)`.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Before** (`ConstraintTypeController.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php`
  - **Expect:** one hit on line 3.
  - **Effort:** S

- [x] **CTY-13** · L · STY-01 · `Modules/SmartTimetable/app/Models/ConstraintType.php:1` — add `declare(strict_types=1)`.
  - **Touches:** `Modules/SmartTimetable/app/Models/ConstraintType.php`
  - **Before** (`ConstraintType.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Models;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/SmartTimetable/app/Models/ConstraintType.php`
  - **Expect:** one hit on line 3.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **CTY-08** · M · DECISION · CTL-05 — de-duplicate the param-schema normalise-and-guard block typed into both `store` (lines 48-53) and `update` (lines 120-125).
  - **Why it is a decision:** it must not be applied in the same pass as CTY-01, which rewrites the same two methods; a separate refactor keeps the two changes from colliding.
  - (a) ⭐ Defer to the next refactor of this controller; record the duplication as accepted for now.
  - (b) Extract one private helper now that returns the normalised schema or throws `\DomainException`, and catch that single exception shape per D2.
  - (c) Leave it and record the duplication as accepted permanently.
  - ➜ Choice: (a) — deferred to the next refactor of this controller; duplication accepted for now.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CTY-02 | Folded into CTY-01: that item's `After` already builds the `redirect()` after `DB::transaction()` returns, which is the whole of TXN-05 for `store` and `update`. |
| CTY-09 | Dead-view cleanup (`constraint-type/index.blade.php`, `constraint-type/create.blade.php`) — deleting unreferenced files is a views cleanup, not a code fix; re-prove `routed=0 refs=0` at fix time before removing either file. |
