# Final Audit — SmartTimetable / ConstraintTypeController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php` (362 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/constraint-type` (index → redirect), `/smart-timetable/constraint-type/{id}` (show), `/smart-timetable/constraint-type/{id}/edit` (edit), `/smart-timetable/constraint-type/trash/view` (trash). All writes are POST/PUT/DELETE to the same base path. |
| Menu path | Smart Timetable dashboard → "Constraint Engine" → the **Constraint Types** tab. The tab list, the Add dialog and the pager are rendered by `TimetableMenuController@constraintEngine` at `/smart-timetable/constraint-engine`; this controller only serves the CRUD the tab calls. |
| Who uses it | Roles holding the eight permissions = **Super Admin** (role 1) and **School Admin** (role 2), measured in `sys_role_has_permissions_jnt` on the tenant DB. |
| What a user does here | Seeds and maintains the catalogue of scheduling rules the timetable solver reads: code, name, category, scope, hard/soft flag, default weight and an optional JSON parameter schema. System rows are seeded by PRIME and cannot be edited or trashed; user-created rows can be edited, switched active/inactive (AJAX), soft-deleted, restored and force-deleted. |
| Tables written | `tt_constraint_types` (INSERT/UPDATE/soft-DELETE/force-DELETE); `sys_activity_logs` (one row per mutation through the `activityLog()` helper, which runs inside the same transaction). |
| Tables read | `tt_constraint_types`, `tt_constraint_category_scopes` (category/scope dropdowns and relations), `tt_constraints` (only via the model's `constraints()` relation, used by the force-delete guard planned here). |
| Live data | tenant `xyz_school_00000000000040008000_202627`: `tt_constraint_types` = 10 live, **all 10 `is_system` = 1**, 0 trashed; `tt_constraint_category_scopes` = 27; `tt_constraints` = 6 (referencing type ids 2,3,4,6,7,10); `sys_activity_logs` = 396. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is close to production-ready but not there yet. Its authorization is real and correct on every routed method, every mutating method wraps its writes in one `DB::transaction` with `activityLog()` placed correctly inside it, and the FormRequest is well-built. It is **not production-ready** because it still carries six hand-written controller `try/catch` blocks that the settled D1 decision removes, one of them converting a real failure into a fixed flash that loses the stack trace; and because the restore action still runs over a **GET** URL with no CSRF token. The single worst finding is **CTY-05** (RTE-01, H): a link prefetcher, a crawler or an image tag can restore a trashed constraint type with no user intent. The second worst is **CTY-01** (M): all six write actions hide errors from the central handler. Rough effort for the full plan: **M**, under a day, with three DECISION items (one route verb, one route-binding rename, one deferred de-duplication). No migration and no new permission is needed.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 8 | 4 | 3 | 13 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CTY-01 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | CTY-02 | F9 Queries/Perf | CTY-10 |
| F3 Authorization | CTY-03 | F10 Views | clean (cross-cutting note only) |
| F4 Validation | CTY-04 | F11 Security/Tenancy | clean |
| F5 Routes | CTY-05 | F12 Style | CTY-11, CTY-13 |
| F6 Controller shape | CTY-06, CTY-07, CTY-08, CTY-09 | F13 Deep read | CTY-12 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php` | controller | 362 | this report | ✅ whole class |
| 2 | `Modules/SmartTimetable/app/Models/ConstraintType.php` | model | 128 | this report (pre-assigned) | ✅ whole class |
| 3 | `Modules/SmartTimetable/app/Http/Requests/ConstraintTypeRequest.php` | FormRequest | 125 | this report (only this controller uses it) | ✅ whole class |
| 4 | `Modules/SmartTimetable/resources/views/constraint-type/show.blade.php` | blade | 93 | this report | ✅ |
| 5 | `Modules/SmartTimetable/resources/views/constraint-type/edit.blade.php` | blade | 144 | this report | ✅ |
| 6 | `Modules/SmartTimetable/resources/views/constraint-type/trash.blade.php` | blade | 101 | this report | ✅ |
| 7 | `Modules/SmartTimetable/resources/views/constraint-type/index.blade.php` | blade | 41 | this report | ✅ — dead, CTY-09 |
| 8 | `Modules/SmartTimetable/resources/views/constraint-type/create.blade.php` | blade | 143 | this report | ✅ — dead, CTY-09 |
| 9 | `Modules/SmartTimetable/routes/web.php` lines 265-269 | routes | 5 | this report (usage) | ✅ |
| — | `Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php` | model | 69 | ↗ [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked — usage checked: `edit()` calls `ofCategory()`/`ofScope()`/`active()`/`orderBy('code')->get()` |
| — | `Modules/SmartTimetable/app/Models/Constraint.php` | model | — | ↗ [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked — reached only by `ConstraintType::constraints()`; the relation's table is `tt_constraints` |
| — | `resources/views/components/backend/table/action-trashed.blade.php`, `resources/views/components/backend/form/status-switch.blade.php`, `app/Helpers/activityLog.php`, base `Controller`, base `BaseModel` | common | — | common | referenced only |

The FormRequest is not in `00-CLASS-OWNERS.md` and is used only by this controller, so it is audited here and not registered. `ConstraintCategoryScope` and `Constraint` were pre-assigned to `ConstraintCategoryScopeController` (still CLAIMED), so they are linked, not re-audited; only this controller's use of them is checked.

No in-scope file appears in a module `PRE-APPLIED-*.md`.

## 4. Routes

```
GET|HEAD smart-timetable/constraint-type                     smart-timetable.constraint-type.index     Modules\SmartTimetable\Http\Controllers\ConstraintTypeController@index
POST     smart-timetable/constraint-type                     smart-timetable.constraint-type.store     Modules\SmartTimetable\Http\Controllers\ConstraintTypeController@store
GET|HEAD smart-timetable/constraint-type/trash/view          smart-timetable.constraint-type.trashed   Modules\SmartTimetable\Http\Controllers\ConstraintTypeController@trashedConstraintType
GET|HEAD smart-timetable/constraint-type/{constraint_type}   smart-timetable.constraint-type.show      Modules\SmartTimetable\Http\Controllers\ConstraintTypeController@show
PUT|PATCH smart-timetable/constraint-type/{constraint_type}  smart-timetable.constraint-type.update    Modules\SmartTimetable\Http\Controllers\ConstraintTypeController@update
DELETE   smart-timetable/constraint-type/{constraint_type}   smart-timetable.constraint-type.destroy   Modules\SmartTimetable\Http\Controllers\ConstraintTypeController@destroy
GET|HEAD smart-timetable/constraint-type/{constraint_type}/edit smart-timetable.constraint-type.edit  Modules\SmartTimetable\Http\Controllers\ConstraintTypeController@edit
POST     smart-timetable/constraint-type/{constraint_type}/toggle-status smart-timetable.constraint-type.toggleStatus Modules\SmartTimetable\Http\Controllers\ConstraintTypeController@toggleStatus
DELETE   smart-timetable/constraint-type/{id}/force-delete   smart-timetable.constraint-type.forceDelete Modules\SmartTimetable\Http\Controllers\ConstraintTypeController@forceDelete
GET|HEAD smart-timetable/constraint-type/{id}/restore        smart-timetable.constraint-type.restore   Modules\SmartTimetable\Http\Controllers\ConstraintTypeController@restore
```

Unrouted public methods: `create` at line 29 — deliberately unrouted (the resource is `->except(['create'])`) and already D5-compliant: its body is `abort(403, 'The create page is retired — use the Add dialog on the Constraint Types tab.')` with a `NOT ROUTED` comment. All other public methods are routed. Every route sits inside `Route::middleware(['web', 'auth', 'verified', EnsureTenantHasModule::class.':smart-timetable'])` with prefix `smart-timetable` (`Modules/SmartTimetable/routes/web.php:46`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 19 | GET /smart-timetable/constraint-type | `tenant.smart-timetable.constraint-type.viewAny` | none — read/redirect | — | none | — |
| `create` | 29 | not routed (D5 abort 403) | none | none | — | none | — |
| `store` | 44 | POST /smart-timetable/constraint-type | `...constraint-type.create` | controller | 'Created' | tt_constraint_types, sys_activity_logs | CTY-01, CTY-02, CTY-03 |
| `show` | 81 | GET /smart-timetable/constraint-type/{constraint_type} | `...constraint-type.view` | none — read-only | — | none | CTY-06, CTY-07 |
| `edit` | 93 | GET /smart-timetable/constraint-type/{constraint_type}/edit | `...constraint-type.update` | none — read-only | — | none | CTY-06, CTY-07 |
| `update` | 108 | PUT\|PATCH /smart-timetable/constraint-type/{constraint_type} | `...constraint-type.update` | controller | 'Updated' | tt_constraint_types, sys_activity_logs | CTY-01, CTY-02, CTY-03 |
| `destroy` | 147 | DELETE /smart-timetable/constraint-type/{constraint_type} | `...constraint-type.delete` | controller | 'Trashed' | tt_constraint_types, sys_activity_logs | CTY-01, CTY-06 |
| `trashedConstraintType` | 190 | GET /smart-timetable/constraint-type/trash/view | `...constraint-type.restore` | none — read-only | — | none | CTY-10 |
| `forceDelete` | 207 | DELETE /smart-timetable/constraint-type/{id}/force-delete | `...constraint-type.forceDelete` | controller | 'Deleted' | tt_constraint_types, sys_activity_logs | CTY-01, CTY-06, CTY-12 |
| `restore` | 246 | GET /smart-timetable/constraint-type/{id}/restore | `...constraint-type.restore` | controller | 'Restored' | tt_constraint_types, sys_activity_logs | CTY-01, CTY-05, CTY-06 |
| `toggleStatus` | 279 | POST /smart-timetable/constraint-type/{constraint_type}/toggle-status | `...constraint-type.update` | controller | 'Toggled' | tt_constraint_types, sys_activity_logs | CTY-01 |

Tables each mutation SHOULD touch: every mutation writes one `tt_constraint_types` row plus one `sys_activity_logs` audit row (`activityLog()`). All six mutating methods do exactly those two, inside one `DB::transaction` — the transaction COUNT is correct (`controller-alignment.md` §6); the defects are the shape (D1) and the response placement (TXN-05), not a missing transaction.

## 6. Findings

### F1 — Errors

#### CTY-01 · M · ERR-00 (D1) + ERR-05 — six mutating actions keep a controller try/catch that logs only the message

| Field | Value |
|---|---|
| **Rule** | ERR-00 under D1 (M by project decision) — *no try/catch in controllers; `DB::transaction()` rolls back and rethrows by itself; the central handler renders errors*; ERR-05 (M) — *log the exception, not `getMessage()`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php:55-75`, method `store()` (same shape at `update()`:127-141, `destroy()`:160-184, `forceDelete()`:220-240, `restore()`:252-273, `toggleStatus()`:287-322) |
| **Root cause** | Each mutating action wraps its `DB::transaction()` in `try { … } catch (\Throwable $e)`, then logs `['error' => $e->getMessage()]` and returns a hand-written flash/JSON. D1 settled that controllers carry no try/catch except the D2 shapes; none of these six is a D2 shape (no `\DomainException`, no truncate-rebuild, no `SnapshotProtectionException`). |
| **Consequence** | Every real DB failure is reduced to a fixed sentence and the stack trace is lost, so a failing write on the Constraint Types tab cannot be diagnosed from the log; and each catch is another place the 404/403/422 class of bug can creep back in. |
| **Reproduce** | Static only — the failure needs a broken DB, which cannot be forced from the UI; the shape is verified by grep. |
| **Fix approach** | Delete the outer `try`/`catch` in all six methods, keep the `DB::transaction()` closure and its `activityLog()` call, and de-indent the body by one level. For `store`/`update` also build the `redirect()` after the closure (see CTY-02). The private `normalizeParamSchema()` catch is a local JSON-parse guard that returns `false` and never reaches the user; it is left as-is. |
| **Plan item** | CTY-01 in `02-fix-plan.md` §3 |

```php
        try {
            // Rule A2 — the record AND sys_activity_logs are two tables, so the whole
            // sequence belongs in one transaction. Rule A3 — activityLog() runs AFTER
            // the write and INSIDE the transaction, so a failed insert cannot leave
            // behind a log row claiming a creation that never happened.
            return DB::transaction(function () use ($request, $paramSchema) {
                $constraintType = ConstraintType::create(
                    $request->payload($paramSchema) + ['is_system' => false]
                );

                activityLog($constraintType, 'Created', ['message' => 'Constraint type was created successfully.']);

                return redirect()
                    ->route('smart-timetable.menu.constraintEngine', ['tab' => 'constraint-types'])
                    ->with('success', flash('created.constraint_type'));
            });
        } catch (\Throwable $e) {
            Log::error('ConstraintType store failed', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'Failed to create constraint type.');
        }
```

**Evidence**
```
$ grep -nE 'try \{|catch \(\\Throwable|Log::error\(\x27ConstraintType' Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php
55:        try {
71:        } catch (\Throwable $e) {
72:            Log::error('ConstraintType store failed', ['error' => $e->getMessage()]);
127:        try {
137:        } catch (\Throwable $e) {
138:            Log::error('ConstraintType update failed', ['id' => $constraintType->id, 'error' => $e->getMessage()]);
160:        try {
180:        } catch (\Throwable $e) {
181:            Log::error('ConstraintType destroy failed', ['id' => $id, 'error' => $e->getMessage()]);
220:        try {
236:        } catch (\Throwable $e) {
237:            Log::error('ConstraintType forceDelete failed', ['id' => $id, 'error' => $e->getMessage()]);
252:        try {
269:        } catch (\Throwable $e) {
270:            Log::error('ConstraintType restore failed', ['id' => $id, 'error' => $e->getMessage()]);
287:        try {
311:        } catch (\Throwable $e) {
312:            Log::error('ConstraintType toggleStatus failed', [
```

### F2 — Transactions and audit

#### CTY-02 · M · TXN-05 — `store()` and `update()` build the redirect inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build the `redirect()` / `response()` after it* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php:60-70`, method `store()` (identical at `update()`:128-136) |
| **Root cause** | The closure's last expression is `return redirect()->route(…)->with(…)`, so the HTTP response object is constructed before the transaction has committed. The other four mutating methods correctly build their response after the closure. |
| **Consequence** | The response is coupled to the transaction body: any later change that needs the saved model's values (for example a flash that quotes the id) cannot see committed data, and the two idioms drift within one file. |
| **Reproduce** | Static only — a returned `RedirectResponse` is not visible in the browser. |
| **Fix approach** | Return the model from the closure, then call `redirect()` after `DB::transaction()` returns. Covered by the same rewrite as CTY-01. |
| **Plan item** | none — see plan §10 (folded into CTY-01) |

```php
            return DB::transaction(function () use ($request, $paramSchema) {
                $constraintType = ConstraintType::create(
                    $request->payload($paramSchema) + ['is_system' => false]
                );

                activityLog($constraintType, 'Created', ['message' => 'Constraint type was created successfully.']);

                return redirect()
                    ->route('smart-timetable.menu.constraintEngine', ['tab' => 'constraint-types'])
                    ->with('success', flash('created.constraint_type'));
            });
```

**Evidence**
```
$ grep -nE 'return redirect\(\)|return DB::transaction' Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php
60:            return DB::transaction(function () use ($request, $paramSchema) {
67:                return redirect()
128:            return DB::transaction(function () use ($request, $constraintType, $paramSchema) {
133:                return redirect()
```
Two of the six mutating methods return a response from inside the closure; the other four (`destroy`, `forceDelete`, `restore`, `toggleStatus`) do not.

### F3 — Authorization

#### CTY-03 · L · AUTH-04 — `store()` and `update()` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice; keep one check per concern* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php:46`, method `store()` (same at `update()`:110) |
| **Root cause** | `ConstraintTypeRequest::authorize()` already checks `...constraint-type.create` for POST and `...constraint-type.update` otherwise and runs **before** the controller body, then the controller calls `Gate::authorize()` for the same permission again. |
| **Consequence** | The permission name is duplicated in two places, so a rename applied to one and not the other silently locks the action or leaves it half-guarded; no functional change today. |
| **Reproduce** | Static only — the FormRequest runs first and already denies; the second check is unreachable as a denial. |
| **Fix approach** | Drop the controller `Gate::authorize()` line in `store` and `update`; keep `ConstraintTypeRequest::authorize()`. Leave the `Gate::authorize()` calls in `index`/`show`/`edit`/`destroy`/`trashedConstraintType`/`forceDelete`/`restore`/`toggleStatus` untouched (they have no FormRequest). |
| **Plan item** | CTY-03 in `02-fix-plan.md` §4 |

```php
    public function store(ConstraintTypeRequest $request)
    {
        Gate::authorize('tenant.smart-timetable.constraint-type.create');

        $paramSchema = $this->normalizeParamSchema($request->validated('param_schema'));
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php
21:        Gate::authorize('tenant.smart-timetable.constraint-type.viewAny');
46:        Gate::authorize('tenant.smart-timetable.constraint-type.create');
83:        Gate::authorize('tenant.smart-timetable.constraint-type.view');
95:        Gate::authorize('tenant.smart-timetable.constraint-type.update');
110:        Gate::authorize('tenant.smart-timetable.constraint-type.update');
149:        Gate::authorize('tenant.smart-timetable.constraint-type.delete');
192:        Gate::authorize('tenant.smart-timetable.constraint-type.restore');
209:        Gate::authorize('tenant.smart-timetable.constraint-type.forceDelete');
248:        Gate::authorize('tenant.smart-timetable.constraint-type.restore');
281:        Gate::authorize('tenant.smart-timetable.constraint-type.update');
```

### F4 — Validation and input

#### CTY-04 · M · VAL-05 — `param_schema` and `is_active` are declared `nullable` and validate nothing

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; `'sometimes'`/`nullable` alone validates nothing* |
| **Where** | `Modules/SmartTimetable/app/Http/Requests/ConstraintTypeRequest.php:60-64` |
| **Root cause** | `'param_schema' => ['nullable']` accepts any string, so invalid JSON passes validation and is only caught later by the controller's `normalizeParamSchema()` guard; `'is_active' => ['nullable']` carries no `boolean`, so a crafted POST of `is_active=abc` passes validation and is coerced to `false` by `$request->boolean('is_active')`. The sibling flags `target_id_required` and `is_hard_constraint` are already `boolean`. |
| **Consequence** | A user pasting malformed JSON is bounced back by a controller-side error instead of a field error, and a non-flag value silently creates/updates an inactive row. |
| **Reproduce** | Static only — the edit form only ever sends a checkbox for `is_active`; the malformed-JSON path is reachable by the textarea. |
| **Fix approach** | Add `json` to the `param_schema` rule and `boolean` to the `is_active` rule. Both are native Laravel rules; no new import. |
| **Plan item** | CTY-04 in `02-fix-plan.md` §5 |

```php
            // JSON string OR null — JSON-decoded in controller
            'param_schema' => ['nullable'],

            'is_active' => ['nullable'],
        ];
```

**Evidence**
```
$ grep -nE "'param_schema'|'is_active'|'target_id_required'|'is_hard_constraint'" Modules/SmartTimetable/app/Http/Requests/ConstraintTypeRequest.php
54:            'target_id_required' => ['nullable', 'boolean'],
58:            'is_hard_constraint' => ['nullable', 'boolean'],
61:            'param_schema' => ['nullable'],
63:            'is_active' => ['nullable'],
```

**Rest of F4 — checked, clean:** the two write actions use the FormRequest, never `$request->all()` or `except()` (VAL-01); optional `description` is read through `validated()` so an absent key returns null (VAL-03); `Rule::unique('tt_constraint_types','code')` mirrors the real `uq_ctype_code` index exactly — the index has no `deleted_at` and neither does the rule, so no soft-delete × unique 1062 trap (VAL-04); no upload (VAL-06); the only inline `$request->validate()` is the single-field AJAX toggle in `toggleStatus():283-285`, which VAL-02 explicitly allows.

### F5 — Routes

#### CTY-05 · H · RTE-01 — Restore runs over a GET request

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/SmartTimetable/routes/web.php:267` |
| **Root cause** | `Route::get('/constraint-type/{id}/restore', …)` performs a write (un-soft-deletes the row and flips `is_active` back on) behind a GET verb. |
| **Consequence** | A browser prefetch, a crawler or an image tag can restore a trashed constraint type with no user intent and no CSRF token. |
| **Reproduce** | While signed in as School Admin, open `http://test.localhost:8000/smart-timetable/constraint-type/1/restore` directly — it restores type id 1. Expected: a 405 for a plain GET. |
| **Fix approach** | Change the verb. The only UI caller is `trash.blade.php:72` via the shared `x-backend.table.action-trashed` component, and that component reads the verb from the route itself, so changing the route needs no blade edit. This is a route change, so it is a DECISION (⚠ SHARED). |
| **Plan item** | CTY-05 (DECISION) in `02-fix-plan.md` §5 |

```php
        Route::get('/constraint-type/{id}/restore', [ConstraintTypeController::class, 'restore'])->name('constraint-type.restore');
```

**Evidence**
```
$ python3 -c "import json; [print(x['method'],x['uri']) for x in json.load(open('/tmp/fa-routes.json')) if 'constraint-type' in x['uri']]"
GET|HEAD smart-timetable/constraint-type
POST smart-timetable/constraint-type
GET|HEAD smart-timetable/constraint-type/trash/view
GET|HEAD smart-timetable/constraint-type/{constraint_type}
PUT|PATCH smart-timetable/constraint-type/{constraint_type}
DELETE smart-timetable/constraint-type/{constraint_type}
GET|HEAD smart-timetable/constraint-type/{constraint_type}/edit
POST smart-timetable/constraint-type/{constraint_type}/toggle-status
DELETE smart-timetable/constraint-type/{id}/force-delete
GET|HEAD smart-timetable/constraint-type/{id}/restore
```

**Rest of F5 — checked, clean:** every route points at an existing method (RTE-02); `create` is deliberately unrouted and D5-compliant (RTE-03); reads are GET and writes are POST/PUT/DELETE apart from F5's restore (RTE-04); every route carries the `web, auth, verified, EnsureTenantHasModule` group (RTE-05); custom routes are declared after `Route::resource` but no conflict occurs because each custom path has an extra segment, so `/{constraint_type}` never captures `/trash/view` or `/{id}/restore` (RTE-06, proved by the `route:list` above).

### F6 — Controller shape

#### CTY-06 · M · CTL-03 — five methods take a raw `$id` and call `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php:81`, method `show()` (same at `edit()`:93, `destroy()`:147, `forceDelete()`:207, `restore()`:246) |
| **Root cause** | These five methods accept an untyped `$id` and resolve the record by hand. `update()` and `toggleStatus()` already bind `ConstraintType $constraintType`. The resource parameter is `{constraint_type}` while the method variable is `$id`, so converting cleanly means either renaming the route parameter or the argument. |
| **Consequence** | More code, a hand-written `findOrFail` in five places, and a hard-coded id in the query; a missing id still 404s, so behaviour is correct today. |
| **Reproduce** | Static only — no user-visible difference. |
| **Fix approach** | Bind the model. Because this changes route parameter names it is a DECISION (⚠ SHARED). |
| **Plan item** | CTY-06 (DECISION) in `02-fix-plan.md` §5 |

```php
    public function show($id)
    {
        Gate::authorize('tenant.smart-timetable.constraint-type.view');

        $constraintType = ConstraintType::with(['category', 'constraintScope'])->findOrFail($id);

        return view('smarttimetable::constraint-type.show', compact('constraintType'));
    }
```

**Evidence**
```
$ grep -nE 'public function (show|edit|destroy|forceDelete|restore|update|toggleStatus)\(' Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php
81:    public function show($id)
93:    public function edit($id)
108:    public function update(ConstraintTypeRequest $request, ConstraintType $constraintType)
147:    public function destroy($id)
207:    public function forceDelete($id)
246:    public function restore($id)
279:    public function toggleStatus(Request $request, ConstraintType $constraintType)
```

#### CTY-07 · L · CTL-04 — no public method declares a return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php:19`, method `index()` (same on all 11 public methods) |
| **Root cause** | Every action omits its return type, so the response shape of each method is documented nowhere. |
| **Consequence** | A later change that returns the wrong type (for example `back()` from a `view()` method) is caught only at runtime. |
| **Reproduce** | Static only — scanner CTL-04 fires at every method. |
| **Fix approach** | Add the three response imports and type every public method. |
| **Plan item** | CTY-07 in `02-fix-plan.md` §5 |

```php
    public function index()
    {
        Gate::authorize('tenant.smart-timetable.constraint-type.viewAny');

        return redirect()->route('smart-timetable.menu.constraintEngine');
    }
```

**Evidence**
```
$ grep -cE 'public function [a-zA-Z_]+\([^)]*\)\s*:' Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php
0
```

#### CTY-08 · M · CTL-05 — the param-schema normalise-and-guard block is copy-pasted in `store` and `update`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste across methods* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php:48-53`, method `store()` (identical at `update()`:120-125) |
| **Root cause** | The same six lines — read `param_schema`, call `normalizeParamSchema()`, and return a `withErrors()->withInput()` guard on `false` — are typed into both write actions. Only the surrounding payload differs. |
| **Consequence** | A change to the guard (for example the CTY-04 validation fix) must be applied twice and will drift; the two copies already sit at different line offsets. |
| **Reproduce** | Static only — the two blocks are byte-identical. |
| **Fix approach** | Extract the guard into one private helper that returns the normalised schema or throws a `\DomainException`, or defer. Offered as a DECISION because it must not be applied in the same pass as CTY-01. |
| **Plan item** | CTY-08 (DECISION) in `02-fix-plan.md` §9 |

```php
        $paramSchema = $this->normalizeParamSchema($request->validated('param_schema'));
        if ($paramSchema === false) {
            return back()->withErrors([
                'param_schema' => 'Invalid JSON format for parameter schema.',
            ])->withInput();
        }
```

**Evidence**
```
$ grep -n "normalizeParamSchema(\$request->validated('param_schema'))" Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php
48:        $paramSchema = $this->normalizeParamSchema($request->validated('param_schema'));
120:        $paramSchema = $this->normalizeParamSchema($request->validated('param_schema'));
```

#### CTY-09 · M · CTL-10 — two dead views remain for this controller

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *dead code: unreachable code left in the tree* |
| **Where** | `Modules/SmartTimetable/resources/views/constraint-type/index.blade.php:1` |
| **Root cause** | `index()` redirects to the Constraint Engine page and never renders `constraint-type/index.blade.php`; `create()` aborts 403 and the create form now lives in `pages/partials/constraint-engine/constraint-types/_create-fields.blade.php`, so `constraint-type/create.blade.php` is also unreachable. `index.blade.php` is a copy-paste of the Day module ("Day Management", it loops `$schoolDays`, a variable this controller never passes); `create.blade.php` was superseded by the modal partial. |
| **Consequence** | Two files that no route can reach stay in the tree; `index.blade.php` would crash on an undefined `$schoolDays` if any future code rendered it, and both mislead a reader into thinking the pages still exist. |
| **Reproduce** | Static only — `route:list` shows no action renders either view; the create route is excluded. |
| **Fix approach** | Delete both files after re-proving they are unreferenced. Recorded as a cleanup, not a mechanical fix — see plan §10. |
| **Plan item** | none — see plan §10 |

```php
<x-backend.layouts.app>
    <x-backend.components.breadcrum title="Day Management" :links="[]" />
```

**Evidence**
```
$ grep -rn "constraint-type.index\|constraint-type.create'" Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php
(no output)
$ grep -rn "constraint-type/index\|constraint-type/create" Modules/SmartTimetable/resources/views Modules/SmartTimetable/app
(no output)
```

### F7 — Models

clean — `Modules/SmartTimetable/app/Models/ConstraintType.php`: `$table = 'tt_constraint_types'` exists in `database/migrations/tenant/2026_06_16_152615_create_tt_constraint_type_table.php` (MDL-07); `$fillable` is declared and holds no sensitive column (MDL-01); `$casts` covers every boolean, the JSON `param_schema` and all three timestamps (MDL-02); `SoftDeletes` matches the table's `deleted_at` (MDL-05 not applicable — no media); `category()`, `constraintScope()` and `constraints()` are return-typed and resolved in tinker (`with(['category','constraintScope'])` returned category `Teacher Constraints`, scope `Teacher`, and `constraints()->count()` ran without error). Evidence: `php artisan tinker --execute` loaded type id 1 and printed `category=Teacher Constraints scope=Teacher constraints_count=0`.

### F8 — Services and jobs

clean — this controller injects no service and dispatches no job; all work is in the controller and the model. `grep -nE 'Service|Job|dispatch|event\(' Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php` → no output.

### F9 — Queries and performance

#### CTY-10 · M · QRY-01 / VIEW-02 — the trash list loads two relations per row (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (M here, lowered from H because the list is capped at 10) — *no queries inside loops; eager-load relations used in a loop* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php:194-196`, method `trashedConstraintType()` |
| **Root cause** | The query returns trashed types without `with(['category','constraintScope'])`, but `trash.blade.php:57-62` reads `$constraintType->category?->name` and `$constraintType->constraintScope?->name` for every row, so Laravel lazy-loads both relations once per row. |
| **Consequence** | The trash tab runs 1 + (2 × rows) queries instead of 3; at the 10-row page size that is 21 queries instead of 3, and it grows with the page. |
| **Reproduce** | Static only — the tenant has 0 trashed rows today, so the extra queries do not fire; restore/trash 10 rows to see it. |
| **Fix approach** | Eager-load both relations on the paginator query, exactly as `show()` already does at line 85. |
| **Plan item** | CTY-10 in `02-fix-plan.md` §6 |

```php
        $constraintTypes = ConstraintType::onlyTrashed()
            ->orderBy('name')
            ->paginate(10);
```

**Evidence**
```
$ grep -nE 'onlyTrashed|with\(|paginate\(' Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php
85:        $constraintType = ConstraintType::with(['category', 'constraintScope'])->findOrFail($id);
194:        $constraintTypes = ConstraintType::onlyTrashed()
196:            ->paginate(10);
$ grep -n 'category?->name\|constraintScope?->name' Modules/SmartTimetable/resources/views/constraint-type/trash.blade.php
57:                                                {{ $constraintType->category?->name ?? '—' }}
61:                                                {{ $constraintType->constraintScope?->name ?? '—' }}
```

**Rest of F9 — checked, clean:** `trashedConstraintType()` paginates at 10 with the default `page` name and the view renders `$constraintTypes->links()` (`trash.blade.php:93`); `edit()` loads two bounded dropdown collections from a 27-row table (`get([...])` not used, but the table is tiny); no query inside a loop, no interpolated raw SQL, no `->get()->count()`.

### F10 — Views

clean — no queries in any rendered Blade: `grep -nE 'Model::|DB::|->where\(|->get\(|->count\(|\{!!' Modules/SmartTimetable/resources/views/constraint-type/show.blade.php Modules/SmartTimetable/resources/views/constraint-type/edit.blade.php Modules/SmartTimetable/resources/views/constraint-type/trash.blade.php` → no output. `show.blade.php` uses both relations but the controller eager-loads them (line 85). Row actions use `x-backend.table.action-trashed`; the trash row's force-delete button is disabled for system rows via `:disable-force-delete="$constraintType->is_system"`. The edit form uses the shared `x-backend.form.status-switch`, which emits `name="is_active"` only when checked and nothing when unchecked — matching the controller's `$request->boolean('is_active')` (verified in `resources/views/components/backend/form/status-switch.blade.php:16-27`). The only view-level issue is the N+1 counted as CTY-10.

### F11 — Security and tenancy

clean — no `env()`, no hard-coded ids or `?? 1`, no secrets logged (`grep -nE 'env\(|\?\? 1' Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php` → no output); every method authorizes before loading the record (AUTH-02); the eight permission names exist in `config/permissionslist.php:734` (`'smart-timetable.constraint-type' => array_merge($crud, ['export'])`) and are seeded in the tenant DB to Super Admin and School Admin with the exact names (`sys_permissions` ids 1680-1687). No cache is used, so no tenant cache-key risk.

### F12 — Style

#### CTY-11 · L · STY-01 — the controller has no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php:1` |
| **Root cause** | The file opens with `<?php` and jumps straight to the namespace. |
| **Consequence** | Silent type coercion stays on for this file, so a wrong type in an argument is not caught early. |
| **Reproduce** | Static only — `head` of the file. |
| **Fix approach** | Add the declaration after the opening tag. |
| **Plan item** | CTY-11 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SmartTimetable\Http\Controllers;
```

**Evidence**
```
$ grep -c 'declare(strict_types' Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php
0
```

#### CTY-13 · L · STY-01 — the ConstraintType model has no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files* |
| **Where** | `Modules/SmartTimetable/app/Models/ConstraintType.php:1` |
| **Root cause** | The model file opens with `<?php` and has no strict-types declaration. |
| **Consequence** | Type coercion stays silent for the model's casts and helpers; low impact but inconsistent with the FormRequest, which already declares it (`ConstraintTypeRequest.php:3`). |
| **Reproduce** | Static only — `head` of the file. |
| **Fix approach** | Add the declaration after the opening tag. |
| **Plan item** | CTY-13 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SmartTimetable\Models;
```

**Evidence**
```
$ grep -c 'declare(strict_types' Modules/SmartTimetable/app/Models/ConstraintType.php
0
```

**Rest of F12 — checked:** the controller uses camelCase variables, one import per class, English comments with no emoji, and no commented-out code; Pint has not flagged the imports. No `extract()` and no `compact()` over 15 variables (`compact('constraintType')`, `compact('constraintTypes')` only).

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Overwrite | 2 Delete-first | 3 Dup impl | 4 Soft-del × unique | 5 Race | 6 Auth hole | 7 Lying msg | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | n/a | CTY-08 | ok | ok | ok | ok | ok |
| `update` | ok | n/a | CTY-08 | ok | ok | ok | ok | ok |
| `destroy` | ok — sets `is_active=false` then soft-deletes | n/a | ok | ok | ok | ok | ok | ok |
| `forceDelete` | ok | CTY-12 | ok | n/a | ok | ok | ok | ok |
| `restore` | ok — restores then sets `is_active=true` | n/a | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | n/a | ok | n/a | ok | ok | ok | ok |

#### CTY-12 · M · F13 deep-read (question 2) — `forceDelete()` can orphan `tt_constraints` rows

| Field | Value |
|---|---|
| **Rule** | Deep-read question 2 (F13, M) — *is anything deleted before its replacement is stored / are references checked before a permanent delete*; the `tt_constraints.constraint_type_id` column has no foreign key, so the DB cannot object |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintTypeController.php:211-218`, method `forceDelete()` |
| **Root cause** | The only guard is `if ($constraintType->is_system)`. Every row in the test tenant is a system row today, so the guard happens to block all current deletions, but a user-created type (allowed by the Add dialog) that has constraints referencing it can be permanently purged — the `SHOW COLUMNS` check confirms `tt_constraints.constraint_type_id` has no foreign key, so nothing raises an error. |
| **Consequence** | Permanently deleting a user-created type that constraints reference leaves those `tt_constraints` rows pointing at a non-existent type; the solver then reads a dangling reference with no visible error. |
| **Reproduce** | Create a non-system constraint type, reference it from `tt_constraints`, then use the trash tab's force-delete button (`DELETE /smart-timetable/constraint-type/{id}/force-delete`). Expected: a refusal; actual: silent orphaning. Static proof for the missing FK is the `SHOW COLUMNS` evidence below. |
| **Fix approach** | Before deleting, refuse when `$constraintType->constraints()->exists()` with a fixed flash, mirroring the existing system-record guard. |
| **Plan item** | CTY-12 in `02-fix-plan.md` §2 |

```php
        $constraintType = ConstraintType::withTrashed()->findOrFail($id);

        // Force-delete is irreversible and tt_constraints.constraint_type_id has NO
        // foreign key, so deleting a system type would silently orphan every
        // constraint referencing it — with no DB error to warn anyone.
        if ($constraintType->is_system) {
            return back()->with('error', $this->systemRecordMessage($constraintType, 'permanently deleted'));
        }
```

**Evidence**
```
$ php artisan tinker --execute '... SHOW COLUMNS FROM tt_constraints ...'  (tenant xyz_school_00000000000040008000_202627)
constraint_type_id int unsigned          <- column exists
$ SHOW INDEX / foreign keys for tt_constraint_type_id: none reported
(no FK row for constraint_type_id in tt_constraints)
$ SELECT constraint_type_id, count(*) FROM tt_constraints GROUP BY constraint_type_id
type_id=2 constraints=1 · type_id=3 constraints=1 · type_id=4 constraints=1
type_id=6 constraints=1 · type_id=7 constraints=1 · type_id=10 constraints=1
$ SELECT count(*) FROM tt_constraint_types WHERE is_system = 0
0        <- the latent path is not reachable on this tenant until a custom type is created
```

Other deep-read answers: **wrong data** — `update()` writes only the validated payload, so `is_system` and `created_at` are preserved; **irreversible order** — no file or row is deleted before its replacement; **duplicate implementations** — CTY-08; **user-safe messages** — every flash comes from `flash()` config or a fixed literal, none carries exception text; **dead features** — CTY-09's views only.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SmartTimetable/resources/views/smart-timetable/index.blade.php:41` → `smart-timetable/partials/constraint-type/_list.blade.php:42` | The old partial still calls `route('smart-timetable.constraint-type.create')`, but the `create` route is excluded by `->except(['create'])`, so rendering it throws `RouteNotFoundException`. Both files appear dead (the live tab partial is under `pages/partials/constraint-engine/`), but they should be removed or repointed in a views cleanup. | RTE-02 / VIEW | the `TimetableMenuController` / SmartTimetable views pass |
| `resources/views/components/backend/table/action-trashed.blade.php` | Every SmartTimetable trash screen drives restore over the component; changing the restore verb in CTY-05 needs no edit here because the component reads the verb from the route (lines 19-23). | — | this report (usage checked) |
| All `constraint-type/*.blade.php` | Each passes `:links="[]"` to `x-backend.components.breadcrum`, so no page carries a breadcrumb trail. Module-wide convention, not this controller's defect. | VIEW (UI standard) | SmartTimetable views pass |
| Seed data | All 10 live `tt_constraint_types` rows are `is_system = 1`, so the edit/trash/force-delete paths are currently unreachable for seeded data; only user-created rows exercise them. Informational, not a defect. | — | product/data pass |

## 8. Not covered, and why

- The pages were not opened in a browser; no server was run for this read-only audit (D4 forbids tests).
- The AJAX `toggleStatus` response and the flash toasts were not exercised live — the test tenant's rows are all system and protected; the method's shape was read statically.
- `ConstraintCategoryScope` and `Constraint` internals are owned by `ConstraintCategoryScopeController` (still CLAIMED); this report checked only how this controller and its model use them.
- The constraint-engine page itself (`TimetableMenuController@constraintEngine`) and its tab partials are a different controller's scope and were not audited here.
- No queue job or scheduled task is dispatched by this controller, so the JOB family had nothing to check.
