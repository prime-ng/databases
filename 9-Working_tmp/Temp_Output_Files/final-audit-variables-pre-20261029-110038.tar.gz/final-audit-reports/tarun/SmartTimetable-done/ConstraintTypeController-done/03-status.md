# Status — SmartTimetable / ConstraintTypeController

**Fixed:** 2026-10-15 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

Decisions (Tarun, 2026-10-15): restore becomes PUT; bind the resource methods. CTY-08 took the recommended (a), defer — no answer was needed because it is the plan's own default.

## 1. Pre-applied work
none

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| CTY-12 | ConstraintTypeController.php forceDelete | refuses a non-system type still referenced by constraints (`$constraintType->constraints()->exists()`) | grep | line 199 | 2026-10-15 |
| CTY-01 | Controller (6 mutations) | try/catch removed (D1), response after the closure. The only `try` left is the private `normalizeJson()` JSON parse | `grep -c "try {"` | 1 (normalizeJson) | 2026-10-15 |
| CTY-03 | Controller store/update | duplicate `Gate::authorize` dropped; `ConstraintTypeRequest::authorize()` checks create/update | grep Gate in store/update | none | 2026-10-15 |
| CTY-04 | ConstraintTypeRequest.php:59-64 | `param_schema` → `json`, flags → `boolean` | grep | lines 59, 62, 64 | 2026-10-15 |
| CTY-05 | routes/web.php:271 | restore is `Route::put` | router probe | `PUT …constraint-type.restore` | 2026-10-15 |
| CTY-06 | Controller show/edit/update/destroy/toggleStatus | bound to `ConstraintType $constraintType` via the snake-case fallback — no `->parameters()` rename needed; restore/forceDelete stay on `$id` | reflection | `{constraint_type}` ↔ typed arg | 2026-10-15 |
| CTY-07 | Controller | return types on all 11 public methods | grep | 11/11 | 2026-10-15 |
| CTY-10 | Controller trash list | `->with(['category','constraintScope'])` | grep | line 171 | 2026-10-15 |
| CTY-11 | Controller | `strict_types` | grep | 1 | 2026-10-15 |
| CTY-13 | Models/ConstraintType.php | `strict_types` | grep | 1 | 2026-10-15 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| CTY-08 | deferred (choice a) | the param-schema block in store/update stays duplicated until the next refactor of this controller |

## 4. Needs Tarun's hand
- **Run the Dusk suites yourself.** Restore is now PUT on all five resources, so the "GET /{missing}/restore expects 404" tests will fail: `TtConstraintsTest:1528`, `TtConstraintTypeTest:1465`, `TtRoomUnavailableTest:1440` and the matching test in `TtTeacherUnavailableTest`. A GET on those URLs is now a 405 (or the DecryptUrl redirect). Not edited — tests are out of scope (D4).
- A browser check of the trash page Restore button on each of the five tabs of `/smart-timetable/constraint-engine` (it should submit `_method=PUT`).
- No migration, seeder or permission sync is needed.

## 5. Unverifiable by this workflow (no tests, D4)
- The failure path of every mutation now relies on the central handler (D1).

## 6. Verification log
```
php -l   (all touched PHP files)                      -> No syntax errors
class_exists (22 classes: 5 controllers, 6 requests,
  5 models, ConstraintManager/Evaluator/Factory,
  DatabaseConstraintService, 2 constraint classes)     -> all true
vendor/bin/pint <touched files> --format agent         -> fixed; php -l + class_exists re-run after
router probe (uncached)                                -> PUT smart-timetable.{constraint,constraint-category-scope,
                                                          constraint-type,teacher-unavailable,room-unavailable}.restore
                                                          every routed action: method_exists ok
grep "getMessage" / "^use ...Facades\\Log;" in the 5 controllers -> 0 / 0
```

## 7. Final state
Status: FIXED · Open: B 0 · H 0 · M 1 · L 0
(M: CTY-08 deferred.)
