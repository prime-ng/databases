# Fix Plan — SmartTimetable / TimetableMenuController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/resources/views/pages/view-and-refinement.blade.php` and every partial under `pages/partials/view-and-refinement/`, `pages/partials/constraint-engine/`, `pages/partials/substitute-management/` | shared with SmartTimetableController (own report); only TMN-12's DECISION, if ticked, may touch the substitute-management partials |
| `Modules/TimetableFoundation/resources/views/pages/timetable-configuration.blade.php` | owned by TimetableFoundationController |
| `Modules/SmartTimetable/app/Services/SubstitutionService.php`, `SubstitutionHistoryReader.php` | owned by SubstitutionController |
| `Modules/TimetableFoundation/app/Services/OptionCellResolver.php`, `PublishedTimetable.php`, `Support/Snapshot/SnapshotContext.php` | owned by TimetableFoundationController / StandardTimetableController |
| All models listed in §3 | owned by their own controller reports |
| `Modules/SmartTimetable/routes/web.php` | shared route file |
| `config/permissionslist.php` | shared config |

## 1. Blockers reachable today

- [ ] **TMN-01** · H · ERR-06 · `TimetableMenuController.php:81-114` — stop swallowing count failures in `dashboard()`: remove the `try/catch` from `$safeCount` and from the published-count block (D1).
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Before** (`TimetableMenuController.php:81-114`):
    ```php
        $safeCount = function (string $table, array $where = []): int {
            try {
                $q = DB::table($table);
                foreach ($where as $col => $val) {
                    $val === null ? $q->whereNull($col) : $q->where($col, $val);
                }
                if (in_array('deleted_at', self::SOFT_DELETE_TABLES[$table] ?? [])) {
                    $q->whereNull('deleted_at');
                }

                return $q->count();
            } catch (\Exception $e) {
                return 0;
            }
        };

        $stats = [
            'timetables' => $safeCount('tt_timetables'),
            'published' => $safeCount('tt_timetables', ['published_at' => '!null']),
            'cells' => $safeCount('tt_timetable_cells'),
            'activities' => $safeCount('tt_activities', ['is_active' => 1]),
            'class_sections' => $safeCount('sch_class_section_jnt', ['is_active' => 1]),
            'school_days' => $safeCount('tt_school_days', ['is_active' => 1]),
            'constraints' => $safeCount('tt_constraints', ['is_active' => 1]),
            'parallel_groups' => $safeCount('tt_parallel_groups', ['is_active' => 1]),
        ];

        // Fix published count (safeCount can't do whereNotNull via array)
        try {
            $stats['published'] = DB::table('tt_timetables')->whereNotNull('published_at')->whereNull('deleted_at')->count();
        } catch (\Exception $e) {
            $stats['published'] = 0;
        }
        $stats['draft'] = $stats['timetables'] - $stats['published'];
    ```
  - **After:**
    ```php
        $safeCount = function (string $table, array $where = []): int {
            $q = DB::table($table);
            foreach ($where as $col => $val) {
                $val === null ? $q->whereNull($col) : $q->where($col, $val);
            }
            if (in_array('deleted_at', self::SOFT_DELETE_TABLES[$table] ?? [], true)) {
                $q->whereNull('deleted_at');
            }

            return $q->count();
        };

        $stats = [
            'timetables' => $safeCount('tt_timetables'),
            'published' => $safeCount('tt_timetables', ['published_at' => '!null']),
            'cells' => $safeCount('tt_timetable_cells'),
            'activities' => $safeCount('tt_activities', ['is_active' => 1]),
            'class_sections' => $safeCount('sch_class_section_jnt', ['is_active' => 1]),
            'school_days' => $safeCount('tt_school_days', ['is_active' => 1]),
            'constraints' => $safeCount('tt_constraints', ['is_active' => 1]),
            'parallel_groups' => $safeCount('tt_parallel_groups', ['is_active' => 1]),
        ];
        $stats['published'] = DB::table('tt_timetables')->whereNotNull('published_at')->whereNull('deleted_at')->count();
        $stats['draft'] = $stats['timetables'] - $stats['published'];
    ```
  - **Verify:** `grep -nE 'catch \(' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Expect:** only line 1124 (`} catch (\Throwable) {`) remains — the TMN-02 case.
  - **Effort:** S

- [ ] **TMN-11** · H · QRY-01 · `TimetableMenuController.php:128-143` — replace the per-row cell count in the dashboard "Recent Timetables" map with one grouped query.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Before** (`TimetableMenuController.php:128-143`):
    ```php
        // Recent timetables
        $recentTimetables = Timetable::with(['academicTerm', 'timetableType'])
            ->orderByDesc('updated_at')
            ->limit(5)
            ->get()
            ->map(function ($tt) {
                return [
                    'name' => $tt->name ?? 'Timetable #'.$tt->id,
                    'type' => $tt->timetableType->name ?? '—',
                    'term' => $tt->academicTerm->term_name ?? '—',
                    'cells' => TimetableCell::where('timetable_id', $tt->id)->count(),
                    'status' => $tt->published_at ? 'Published' : 'Draft',
                    'updated' => $tt->updated_at?->diffForHumans() ?? '—',
                    'id' => $tt->id,
                ];
            });
    ```
  - **After:**
    ```php
        // Recent timetables
        $recentTimetables = Timetable::with(['academicTerm', 'timetableType'])
            ->orderByDesc('updated_at')
            ->limit(5)
            ->get();

        $recentCellCounts = TimetableCell::query()
            ->whereIn('timetable_id', $recentTimetables->pluck('id'))
            ->whereNull('deleted_at')
            ->selectRaw('timetable_id, count(*) as total')
            ->groupBy('timetable_id')
            ->pluck('total', 'timetable_id');

        $recentTimetables = $recentTimetables->map(function ($tt) use ($recentCellCounts) {
            return [
                'name' => $tt->name ?? 'Timetable #'.$tt->id,
                'type' => $tt->timetableType->name ?? '—',
                'term' => $tt->academicTerm->term_name ?? '—',
                'cells' => (int) ($recentCellCounts[$tt->id] ?? 0),
                'status' => $tt->published_at ? 'Published' : 'Draft',
                'updated' => $tt->updated_at?->diffForHumans() ?? '—',
                'id' => $tt->id,
            ];
        });
    ```
  - **Verify:** `grep -n 'TimetableCell::where' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Expect:** no output.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

## 3. Errors & transactions (F1/F2)

- [x] **TMN-02** · L · ERR-00 · `TimetableMenuController.php:1120-1126` — replace the `?pv_date` parse `try/catch` with an input-format check (D1).
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Before** (`TimetableMenuController.php:1120-1126`):
    ```php
        // A malformed ?pv_date= must not take the whole five-tab page down.
        try {
            $raw = (string) $r->query('pv_date', '');
            $anchor = $raw !== '' ? Carbon::createFromFormat('!Y-m-d', $raw) : Carbon::today();
        } catch (\Throwable) {
            $anchor = Carbon::today();
        }
    ```
  - **After:**
    ```php
        // A malformed ?pv_date= must not take the whole five-tab page down.
        $raw = (string) $r->query('pv_date', '');
        $anchor = $raw !== '' && Carbon::hasFormat($raw, 'Y-m-d')
            ? Carbon::createFromFormat('!Y-m-d', $raw)
            : Carbon::today();
    ```
  - **Verify:** `grep -n 'catch (' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

## 5. Validation, routes, models (F4/F5/F7)

- [x] **TMN-04** · M · RTE-03 · `TimetableMenuController.php` — six unrouted public methods become `abort(403)` stubs with a `NOT ROUTED` comment (D5). Apply all six replacements; the method names and `// MOVED to ...` comments above them stay.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Before** (`TimetableMenuController.php:164-167`):
    ```php
    public function preRequisitesSetup(): mixed
    {
        return redirect()->route('timetable-foundation.menu.preRequisitesSetup');
    }
    ```
  - **After:**
    ```php
    public function preRequisitesSetup(): mixed
    {
        // NOT ROUTED — no route points at this method (verified against route:list, 2026-10-10). Disabled per D5.
        abort(403, 'This endpoint is not available.');
    }
    ```
  - **Before** (`TimetableMenuController.php:290-293`):
    ```php
    public function timetableMasters(): mixed
    {
        return redirect()->route('timetable-foundation.menu.timetableMasters');
    }
    ```
  - **After:**
    ```php
    public function timetableMasters(): mixed
    {
        // NOT ROUTED — no route points at this method (verified against route:list, 2026-10-10). Disabled per D5.
        abort(403, 'This endpoint is not available.');
    }
    ```
  - **Before** (`TimetableMenuController.php:296-299`):
    ```php
    public function timetableRequirement(): mixed
    {
        return redirect()->route('timetable-foundation.menu.timetableRequirement');
    }
    ```
  - **After:**
    ```php
    public function timetableRequirement(): mixed
    {
        // NOT ROUTED — no route points at this method (verified against route:list, 2026-10-10). Disabled per D5.
        abort(403, 'This endpoint is not available.');
    }
    ```
  - **Before** (`TimetableMenuController.php:468-471`):
    ```php
    public function resourceAvailability(): mixed
    {
        return redirect()->route('timetable-foundation.menu.resourceAvailability');
    }
    ```
  - **After:**
    ```php
    public function resourceAvailability(): mixed
    {
        // NOT ROUTED — no route points at this method (verified against route:list, 2026-10-10). Disabled per D5.
        abort(403, 'This endpoint is not available.');
    }
    ```
  - **Before** (`TimetableMenuController.php:474-477`):
    ```php
    public function timetablePreparation(): mixed
    {
        return redirect()->route('timetable-foundation.menu.timetablePreparation');
    }
    ```
  - **After:**
    ```php
    public function timetablePreparation(): mixed
    {
        // NOT ROUTED — no route points at this method (verified against route:list, 2026-10-10). Disabled per D5.
        abort(403, 'This endpoint is not available.');
    }
    ```
  - **Before** (`TimetableMenuController.php:1637-1640`):
    ```php
    public function reportsAndLogs(): mixed
    {
        return redirect()->route('timetable-foundation.menu.reportsAndLogs');
    }
    ```
  - **After:**
    ```php
    public function reportsAndLogs(): mixed
    {
        // NOT ROUTED — no route points at this method (verified against route:list, 2026-10-10). Disabled per D5.
        abort(403, 'This endpoint is not available.');
    }
    ```
  - **Verify:** `grep -c "abort(403" Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Expect:** 6.
  - **Effort:** S

- [ ] **TMN-16** · M · MDL-03 · `TimetableMenuController.php:62-68` — add `tt_slot_requirements` to `SOFT_DELETE_TABLES` so the dashboard's Slot Req. count excludes trashed rows.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Before** (`TimetableMenuController.php:62-68`):
    ```php
        'tt_school_days' => ['deleted_at'],
        'tt_constraints' => ['deleted_at'],
        'tt_parallel_groups' => ['deleted_at'],
        'tt_requirement_consolidations' => ['deleted_at'],
        'tt_teacher_availabilities' => ['deleted_at'],
        'tt_analytics_daily_snapshots' => ['deleted_at'],
    ];
    ```
  - **After:**
    ```php
        'tt_school_days' => ['deleted_at'],
        'tt_constraints' => ['deleted_at'],
        'tt_parallel_groups' => ['deleted_at'],
        'tt_requirement_consolidations' => ['deleted_at'],
        'tt_teacher_availabilities' => ['deleted_at'],
        'tt_analytics_daily_snapshots' => ['deleted_at'],
        // 'tt_slot_requirements' soft-deletes (SHOW COLUMNS, 2026-10-10) and is counted
        // on the dashboard pipeline; without this entry the Slot Req. tile counts trashed rows.
        'tt_slot_requirements' => ['deleted_at'],
    ];
    ```
  - **Verify:** `grep -n "tt_slot_requirements" Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Expect:** the new const entry (plus the existing count at line 121).
  - **Effort:** S

## 6. Queries & performance (F9)

## 7. Views (F10)

## 8. Style (F12) — one item per file

- [x] **TMN-15** · L · STY-04 · `TimetableMenuController.php` — replace every ⛔ ⚠ ⭐ glyph in comments with plain English markers (NOTE:, WARNING:, RECOMMENDED:). Same file, one pass; the wording around the glyphs stays.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Before** (`TimetableMenuController.php:48-50`):
    ```php
         * ⛔ sch_class_section_jnt IS NOT SOFT-DELETING, AND LISTING IT HERE READ 0 FOR EVERY
         *   TENANT. It used to appear in this array, so $safeCount() appended
         *   whereNull('deleted_at'), MySQL raised 1054, and the catch below turned that into
    ```
  - **After:**
    ```php
         * WARNING: sch_class_section_jnt IS NOT SOFT-DELETING, AND LISTING IT HERE READ 0 FOR
         *   EVERY TENANT. It used to appear in this array, so $safeCount() appended
         *   whereNull('deleted_at'), MySQL raised 1054, and the catch below turned that into
    ```
  - **Verify:** `grep -cP '[\x{26A0}\x{2B50}\x{26D4}\x{1F4A1}\x{2705}]' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php`
  - **Expect:** 0. (When 0, this grep exits nonzero — expected; the count being zero is the pass condition.)
  - **Effort:** S

## 9. Deferred / decisions

- [x] **TMN-05** · M · DECISION · CTL-01 — split the 1,781-line `TimetableMenuController`?
  - **Why it is a decision:** a controller split is deferred by D3; it changes file layout, route wiring and ownership of the shared blades.
  - (a) ⭐ defer the split to the dedicated split pass (D3) — fix in place now; nothing moves.
  - (b) split now into per-tab controllers (dashboard, timetable-configuration, constraint-engine, view-and-refinement, substitute-management), each owning its blades.
  - (c) leave as is, record the size as accepted debt.
  - ➜ Choice: (a) defer to the split pass (D3) — Tarun 2026-10-16

- [x] **TMN-12** · H · DECISION · QRY-02 — paginate the Substitute Management lists?
  - **Why it is a decision:** it changes the public screen (adds `->links()` paging to the Substitute Requirement and Substitute Assignment tabs), touches two partials shared with SmartTimetableController, and changes the controller's variable contract from collections to paginators.
  - (a) ⭐ paginate `$substituteRequirements` at 10 (`page` param `sr_page`) and `$substitutionLogs` at 10 (`sl_page`), with `->withQueryString()`, and add `->links()` to the two shared `_list` partials. ⚠ SHARED — ticks explicitly.
  - (b) leave unpaginated; record as accepted until the tables grow.
  - (c) eager-limit only (e.g. `->limit(200)`) without pagination, changing no blade.
  - ➜ Choice: (a) paginate at 10, own page name — Tarun 2026-10-16. Applied to the two real row tables: sr_page and pn_page (substitutionLogs has no table; see 03-status)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TMN-03 | AUTH-06 (L) — cross-controller permission-string convention; the policy-mirroring issue belongs to the SmartTimetable module split, not a solo edit in this controller. |
| TMN-06 | CTL-02 (H) — the long-method debt is the split's job; extracting a 642-line private method before the split (TMN-05) would churn the same code twice. |
| TMN-07 | CTL-05 (M) — the duplicated `$applyStatus` closures collapse naturally when the split gives each tab its own controller. |
| TMN-08 | CTL-07 (L) — the 22-variable `compact()` is a symptom of the god method; it moves with the split. |
| TMN-09 | CTL-08 (L) — `request()` → injected `Request` is a five-method signature change that belongs with the split. |
| TMN-10 | SVC-02 (M) — the four `app()` call sites resolve stateless helpers; injecting them is safe but low-value until the split re-shapes the method signatures. |
| TMN-13 | QRY-15 (M) — accepted design: the inline comments measure these dropdown tables as small (85/69/39 rows) and the relation map was explicitly measured "cheap enough to load always" (2026-09-07); re-measure after the split. |
| TMN-14 | QRY-08 (L) — accepted: 16 leading-wildcard searches over small master tables; revisit when per-tab search endpoints exist. |

**How to approve** — tick `[x]` above and fill every `➜ Choice:`; the developer then runs `final-audit-fixer` on this controller path.