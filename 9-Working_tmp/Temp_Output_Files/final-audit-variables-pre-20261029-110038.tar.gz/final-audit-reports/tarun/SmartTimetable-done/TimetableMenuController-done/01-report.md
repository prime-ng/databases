# Final Audit — SmartTimetable / TimetableMenuController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php` (1781 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable` (dashboard) · `http://test.localhost:8000/smart-timetable/timetable-configuration` · `http://test.localhost:8000/smart-timetable/constraint-engine` · `http://test.localhost:8000/smart-timetable/view-and-refinement` · `http://test.localhost:8000/smart-timetable/substitute-management` |
| Menu path | Dashboard → Timetable Management → Smart Timetable (breadcrumb parent `dashboard.timetable-management`, `config/breadcrumbs.php:572`). The dashboard card grid links to the four sub-pages. |
| Who uses it | Roles holding `tenant.smart-timetable.timetable.viewAny` on test.localhost — measured in `sys_role_has_permissions_jnt`: **Super Admin** and **School Admin**. |
| What a user does here | Reads a status dashboard with live counts and pipeline readiness, then opens the four management sub-pages, each a tabbed screen: Timetable Configuration (config keys, academic terms, generation strategies), Constraint Engine (categories/scopes, constraint types, constraints, teacher/room unavailability — all with create dialogs), View & Refinement (timetable view, publish, class assignment, periodic view), and Substitute Management (requirements, assignment, duty, notifications). There is no write path in this controller: every tab posts its mutations to other controllers. |
| Tables written | None — this controller is read-only (verified in F2). The tabs' create/edit/delete actions call other controllers (ConstraintController, TeacherUnavailableController, etc.). |
| Tables read | `tt_timetables`, `tt_timetable_cells`, `tt_activities`, `tt_constraints`, `tt_parallel_groups`, `tt_school_days`, `tt_requirement_consolidations`, `tt_teacher_availabilities`, `tt_slot_requirements`, `tt_analytics_daily_snapshots`, `sch_class_section_jnt`, `sch_academic_term`, `sch_org_academic_sessions_jnt`, `sch_classes`, `sch_sections`, `sch_subjects`, `sch_teachers`, `sch_rooms`, `tt_constraint_category_scopes`, `tt_constraint_types`, `tt_timetable_assignment`, `tt_teacher_absences`, `tt_substitution_logs`, `tt_working_days`, `tt_class_working_days_jnt`, `tt_day_types` (plus snapshot mirrors `tt_snap_*`). |
| Live data | Measured on test.localhost 2026-10-10 (read-only tinker): `tt_timetables=0`, `tt_timetable_cells=0`, `tt_activities=0`, `tt_constraints=6`, `tt_parallel_groups=0`, `tt_school_days=7`, `tt_teacher_availabilities=0`, `tt_requirement_consolidations=0`, `tt_slot_requirements=0`, `sch_class_section_jnt=43`, `tt_timetable_assignment=0`, `tt_substitution_logs=0`, `tt_teacher_absences=0`. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is readable and heavily commented, and every routed method authorizes, but it is **not production-ready**: the dashboard hides database failures behind a swallow-and-guess zero, and several list screens page or load unbounded collections. The single worst finding is **TMN-01** — the dashboard's `$safeCount()` closure and a second `try/catch` swallow every SQL error and print a plausible zero, the exact mechanism the file's own comments say hid the "Class Section = 0" bug for weeks. The controller is 1,781 lines with a 642-line private method, so the split decision (TMN-05) must be made before any large refactor. Rough effort: M (roughly 4–6 focused hours across 8 plan items, plus 2 decisions).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 4 | 6 | 6 | 2 | 16 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TMN-01, TMN-02 | F8 Services/Jobs | TMN-10 |
| F2 Transactions/Audit | clean — no writes | F9 Queries/Perf | TMN-11, TMN-12, TMN-13, TMN-14 |
| F3 Authorization | TMN-03 | F10 Views | clean — no DB queries in menu blades |
| F4 Validation | clean — GET filters only, no write path | F11 Security/Tenancy | clean — no env(), no user-text echo |
| F5 Routes | TMN-04 | F12 Style | TMN-15 |
| F6 Controller shape | TMN-05, TMN-06, TMN-07, TMN-08, TMN-09 | F13 Deep read | TMN-16 |
| F7 Models | ↗ linked — usage checked only | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php` | controller | 1781 | this report | ✅ |
| 2 | `Modules/SmartTimetable/resources/views/dashboard.blade.php` | view | 211 | this report (rendered only here) | ✅ |
| 3 | `Modules/SmartTimetable/resources/views/pages/view-and-refinement.blade.php` | view | 36 | ↗ [tarun/SmartTimetable/SmartTimetableController](../SmartTimetableController-done/01-report.md) (CLAIMED) | ↗ linked |
| 4 | `Modules/SmartTimetable/resources/views/pages/constraint-engine.blade.php` | view | 31 | ↗ SmartTimetableController | ↗ linked |
| 5 | `Modules/SmartTimetable/resources/views/pages/substitute-management.blade.php` | view | 24 | ↗ SmartTimetableController | ↗ linked |
| 6 | `Modules/SmartTimetable/resources/views/pages/partials/view-and-refinement/timetable-view/_list.blade.php` | view | 237 | ↗ SmartTimetableController | ↗ linked |
| 7 | `Modules/SmartTimetable/resources/views/pages/partials/view-and-refinement/publish-timetable/_list.blade.php` | view | 470 | ↗ SmartTimetableController | ↗ linked |
| 8 | `Modules/SmartTimetable/resources/views/pages/partials/view-and-refinement/class-assignment/_list.blade.php` | view | 895 | ↗ SmartTimetableController | ↗ linked |
| 9 | `Modules/SmartTimetable/resources/views/pages/partials/view-and-refinement/periodic-view/_list.blade.php` | view | 750 | ↗ SmartTimetableController | ↗ linked |
| 10 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/category-scope/_list.blade.php` | view | 113 | ↗ SmartTimetableController | ↗ linked |
| 11 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/category-scope/_create-modal.blade.php` | view | 21 | ↗ SmartTimetableController | ↗ linked |
| 12 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/category-scope/_create-fields.blade.php` | view | 58 | ↗ SmartTimetableController | ↗ linked |
| 13 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/constraint-types/_list.blade.php` | view | 136 | ↗ SmartTimetableController | ↗ linked |
| 14 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/constraint-types/_create-modal.blade.php` | view | 21 | ↗ SmartTimetableController | ↗ linked |
| 15 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/constraint-types/_create-fields.blade.php` | view | 141 | ↗ SmartTimetableController | ↗ linked |
| 16 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/constraints/_list.blade.php` | view | 127 | ↗ SmartTimetableController | ↗ linked |
| 17 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/constraints/_create-modal.blade.php` | view | 21 | ↗ SmartTimetableController | ↗ linked |
| 18 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/constraints/_create-fields.blade.php` | view | 246 | ↗ SmartTimetableController | ↗ linked |
| 19 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/teacher-unavailability/_list.blade.php` | view | 136 | ↗ SmartTimetableController | ↗ linked |
| 20 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/teacher-unavailability/_create-modal.blade.php` | view | 21 | ↗ SmartTimetableController | ↗ linked |
| 21 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/teacher-unavailability/_create-fields.blade.php` | view | 168 | ↗ SmartTimetableController | ↗ linked |
| 22 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/room-unavailability/_list.blade.php` | view | 119 | ↗ SmartTimetableController | ↗ linked |
| 23 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/room-unavailability/_create-modal.blade.php` | view | 21 | ↗ SmartTimetableController | ↗ linked |
| 24 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/room-unavailability/_create-fields.blade.php` | view | 167 | ↗ SmartTimetableController | ↗ linked |
| 25 | `Modules/SmartTimetable/resources/views/pages/partials/substitute-management/substitute-requirement/_list.blade.php` | view | 558 | ↗ SmartTimetableController | ↗ linked |
| 26 | `Modules/SmartTimetable/resources/views/pages/partials/substitute-management/substitute-assignment/_list.blade.php` | view | 894 | ↗ SmartTimetableController | ↗ linked |
| 27 | `Modules/SmartTimetable/resources/views/pages/partials/substitute-management/substitute-duty/_list.blade.php` | view | 273 | ↗ SmartTimetableController | ↗ linked |
| 28 | `Modules/SmartTimetable/resources/views/pages/partials/substitute-management/substitute-notifications/_list.blade.php` | view | 332 | ↗ SmartTimetableController | ↗ linked |
| 29 | `Modules/TimetableFoundation/resources/views/pages/timetable-configuration.blade.php` | view | 47 | ↗ [TimetableFoundation/TimetableFoundationController](../../../tarun/TimetableFoundation-done/TimetableFoundationController-done/01-report.md) | ↗ linked |
| 30 | `Modules/SmartTimetable/app/Services/SubstitutionService.php` | service | 1698 | ↗ [tarun/SmartTimetable/SubstitutionController](../SubstitutionController-done/01-report.md) | ↗ linked |
| 31 | `Modules/SmartTimetable/app/Services/SubstitutionHistoryReader.php` | service | 118 | ↗ SubstitutionController | ↗ linked |
| 32 | `Modules/TimetableFoundation/app/Services/OptionCellResolver.php` | service | 533 | ↗ TimetableFoundationController | ↗ linked |
| 33 | `Modules/TimetableFoundation/app/Services/PublishedTimetable.php` | service | 255 | ↗ TimetableFoundationController | ↗ linked |
| 34 | `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | support | 342 | ↗ [tarun/StandardTimetable/StandardTimetableController-done](../../StandardTimetable-done/StandardTimetableController-done/01-report.md) | ↗ linked |
| 35 | `Modules/SmartTimetable/app/Models/Constraint.php` | model | 255 | ↗ [tarun/SmartTimetable/ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked |
| 36 | `Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php` | model | 69 | ↗ ConstraintCategoryScopeController | ↗ linked |
| 37 | `Modules/SmartTimetable/app/Models/ConstraintType.php` | model | 128 | ↗ [tarun/SmartTimetable/ConstraintTypeController](../ConstraintTypeController-done/01-report.md) | ↗ linked |
| 38 | `Modules/SmartTimetable/app/Models/RoomUnavailable.php` | model | 192 | ↗ [tarun/SmartTimetable/RoomUnavailableController](../RoomUnavailableController-done/01-report.md) | ↗ linked |
| 39 | `Modules/SmartTimetable/app/Models/TeacherUnavailable.php` | model | 124 | ↗ [tarun/SmartTimetable/TeacherUnavailableController](../TeacherUnavailableController-done/01-report.md) | ↗ linked |
| 40 | `Modules/SmartTimetable/app/Models/TtGenerationStrategy.php` | model | 320 | ↗ [tarun/SmartTimetable/TtGenerationStrategyController](../TtGenerationStrategyController-done/01-report.md) | ↗ linked |
| 41 | `Modules/SmartTimetable/app/Models/SubstitutionLog.php` | model | 244 | ↗ [tarun/SmartTimetable/SubstitutionController](../SubstitutionController-done/01-report.md) | ↗ linked |
| 42 | `Modules/SmartTimetable/app/Models/TeacherAbsences.php` | model | 267 | ↗ SubstitutionController | ↗ linked |
| 43 | `Modules/TimetableFoundation/app/Models/AcademicTerm.php` | model | 133 | ↗ [TimetableFoundation/AcademicTermController](../../../tarun/TimetableFoundation-done/AcademicTermController-done/01-report.md) | ↗ linked |
| 44 | `Modules/TimetableFoundation/app/Models/Config.php` | model | 145 | ↗ [TimetableFoundation/ConfigController](../../../tarun/TimetableFoundation-done/ConfigController-done/01-report.md) | ↗ linked |
| 45 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | 516 | ↗ [TimetableFoundation/TimetableController](../../../tarun/TimetableFoundation-done/TimetableController-done/01-report.md) | ↗ linked |
| 46 | `Modules/TimetableFoundation/app/Models/TimetableAssignment.php` | model | 529 | ↗ [TimetableFoundation/TimetableAssignmentController](../../../tarun/TimetableFoundation-done/TimetableAssignmentController-done/01-report.md) | ↗ linked |
| 47 | `Modules/TimetableFoundation/app/Models/TimetableCell.php` | model | 279 | ↗ TimetableFoundation/TimetableController | ↗ linked |
| 48 | `Modules/SchoolSetup/Models/*` (ClassSection, OrganizationAcademicSession, Room, SchoolClass, Section, Subject, Teacher) | models | - | common (§4.2) | ✅ usage checked |
| 49 | `Modules/SmartTimetable/routes/web.php` (`TimetableMenuController` routes) | route file | 286 | common — route file; this report reads it, never edits | ✅ usage checked |

No pre-applied files (none of the above appears in `final-audit-reports/TimetableFoundation/PRE-APPLIED-2026-10-10.md`).

## 4. Routes

Uncached route list (fresh `APP_ROUTES_CACHE=/tmp/fa-nocache.php`, 2026-10-10):

```
GET|HEAD  smart-timetable                                            smart-timetable.dashboard                            Modules\SmartTimetable\Http\Controllers\TimetableMenuController@dashboard
GET|HEAD  smart-timetable/constraint-engine                          smart-timetable.menu.constraintEngine                Modules\SmartTimetable\Http\Controllers\TimetableMenuController@constraintEngine
GET|HEAD  smart-timetable/substitute-management                      smart-timetable.menu.substituteManagement            Modules\SmartTimetable\Http\Controllers\TimetableMenuController@substituteManagement
GET|HEAD  smart-timetable/timetable-configuration                    smart-timetable.menu.timetableConfiguration          Modules\SmartTimetable\Http\Controllers\TimetableMenuController@timetableConfiguration
GET|HEAD  smart-timetable/view-and-refinement                        smart-timetable.menu.viewAndRefinement               Modules\SmartTimetable\Http\Controllers\TimetableMenuController@viewAndRefinement
```

All five sit inside the `web, auth, verified, EnsureTenantHasModule:smart-timetable` group in `Modules/SmartTimetable/routes/web.php:45-51` (tenant middleware present — RTE-05 ok).

Unrouted public methods: `preRequisitesSetup` (`:164`), `timetableMasters` (`:290`), `timetableRequirement` (`:296`), `resourceAvailability` (`:468`), `timetablePreparation` (`:474`), `reportsAndLogs` (`:1637`) — six methods with **no route** pointing at them anywhere (verified by the route list above and by grepping the module's `routes/web.php`). See **TMN-04** (D5).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `dashboard` | 77 | GET /smart-timetable | `tenant.smart-timetable.timetable.viewAny` | none | none | none | TMN-01, TMN-11, TMN-16 |
| `preRequisitesSetup` | 164 | NOT ROUTED | none | none | none | none | TMN-04 |
| `timetableConfiguration` | 172 | GET /smart-timetable/timetable-configuration | `Gate::any(['tenant.timetable-foundation.config.viewAny','tenant.timetable-foundation.academic-term.viewAny'])` (abort_unless 403) | none | none | none | TMN-09 |
| `timetableMasters` | 290 | NOT ROUTED | none | none | none | none | TMN-04 |
| `timetableRequirement` | 296 | NOT ROUTED | none | none | none | none | TMN-04 |
| `constraintEngine` | 301 | GET /smart-timetable/constraint-engine | `tenant.smart-timetable.constraint.viewAny` | none | none | none | TMN-06, TMN-08 |
| `resourceAvailability` | 468 | NOT ROUTED | none | none | none | none | TMN-04 |
| `timetablePreparation` | 474 | NOT ROUTED | none | none | none | none | TMN-04 |
| `viewAndRefinement` | 479 | GET /smart-timetable/view-and-refinement | `tenant.smart-timetable.timetable.viewAny` | none | none | none | TMN-06, TMN-12 |
| `reportsAndLogs` | 1637 | NOT ROUTED | none | none | none | none | TMN-04 |
| `substituteManagement` | 1642 | GET /smart-timetable/substitute-management | `tenant.smart-timetable.timetable.viewAny` | none | none | none | TMN-10, TMN-12 |
| `ownedCellIds` | 870 | private | — | — | — | — | — |
| `attachOwnerLabels` | 888 | private | — | — | — | — | — |
| `periodicCellsQuery` | 913 | private | — | — | — | — | — |
| `periodicView` | 947 | private | — | — | — | — | TMN-02, TMN-06, TMN-13, TMN-14 |
| `compressDates` | 1589 | private | — | — | — | — | — |

## 6. Findings

### F1 — Errors

#### TMN-01 · H · ERR-06 — dashboard swallows every count failure and prints a zero

| Field | Value |
|---|---|
| **Rule** | ERR-06 (H) — *no swallowed failures: a catch that logs and continues, or an empty catch, makes a write look like it succeeded; here it makes a READ look like zero.* Raised to H because D1 (final-audit.md) forbids the controller `try/catch` entirely, and this exact pattern hid the "Class Section = 0" bug the file's own comment describes. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:81-114`, method `dashboard()` |
| **Root cause** | The `$safeCount` closure wraps every count in `try { ... } catch (\Exception $e) { return 0; }` and line 109-113 repeats the same shape for the published count. When any table name, column or `deleted_at` assumption is wrong, the closure turns the exception into a plausible zero instead of letting the central handler render a real error. That is precisely how the block comment at lines 47-61 says the "Class Section" tile showed 0 against 42 real rows. |
| **Consequence** | A school admin sees a dashboard that says "0 timetables, 0 cells, 0 activities" whenever one of the counted tables disagrees with the hard-coded allowlist, with no log, no 500 and no way to know the number is a lie. |
| **Reproduce** | On any tenant where a counted table lacks a column the query assumes, open `/smart-timetable`. The tile reads 0; the underlying SQL error is never logged. |
| **Fix approach** | Remove both `try/catch` blocks (D1). The `deleted_at` allowlist is now correct, so the counts either succeed or surface as a real 500 the central handler logs. |
| **Plan item** | TMN-01 in `02-fix-plan.md` §1 |
| **Evidence** | `grep -nE 'catch \('` → lines 92, 111, 1124 (only 1124 may remain after this fix). |

```php
// TimetableMenuController.php:81-114 — CURRENT
        $safeCount = function (string $table, array $where = []): int {
            try {
                $q = DB::table($table);
                foreach ($where as $col => $val) {
                    $val === null ? $q->whereNull($col) : $q->where($col, $val);
                }
                if (in_array('deleted_at', self::SOFT_DELETE_TABLES[$table] ?? [])) {
                    $q->whereNull('deleted_at');
                }

                return $q->count();
            } catch (\Exception $e) {
                return 0;
            }
        };

        $stats = [
            'timetables' => $safeCount('tt_timetables'),
            'published' => $safeCount('tt_timetables', ['published_at' => '!null']),
            'cells' => $safeCount('tt_timetable_cells'),
            'activities' => $safeCount('tt_activities', ['is_active' => 1]),
            'class_sections' => $safeCount('sch_class_section_jnt', ['is_active' => 1]),
            'school_days' => $safeCount('tt_school_days', ['is_active' => 1]),
            'constraints' => $safeCount('tt_constraints', ['is_active' => 1]),
            'parallel_groups' => $safeCount('tt_parallel_groups', ['is_active' => 1]),
        ];

        // Fix published count (safeCount can't do whereNotNull via array)
        try {
            $stats['published'] = DB::table('tt_timetables')->whereNotNull('published_at')->whereNull('deleted_at')->count();
        } catch (\Exception $e) {
            $stats['published'] = 0;
        }
        $stats['draft'] = $stats['timetables'] - $stats['published'];
```

**Evidence**
```
$ grep -nE 'catch \(' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
92:            } catch (\Exception $e) {
111:        } catch (\Exception $e) {
1124:        } catch (\Throwable) {
```

#### TMN-02 · L · ERR-00 — controller try/catch on the pv_date parse is a D1 violation

| Field | Value |
|---|---|
| **Rule** | ERR-00 (D1 settled) — no try/catch in a controller. Lowered from the rulebook's open-decision M to L because the guard's behaviour is correct: it only normalises a malformed `?pv_date=` query string. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:1120-1126`, method `periodicView()` |
| **Root cause** | `Carbon::createFromFormat(...)` inside `try`, `catch (\Throwable)` falls back to today. D1 says the Laravel idiom: validate the input, no catch. |
| **Consequence** | A bad URL parameter is silently treated as today instead of a 422; the catch is a precedent that keeps ERR-00-style code alive in the module. |
| **Reproduce** | Open `/smart-timetable/view-and-refinement?pv_date=not-a-date&pv_class=1`. The grid shows this week instead of rejecting the value. |
| **Fix approach** | Replace the try/catch with an input-format check. |
| **Plan item** | TMN-02 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n 'catch (\Throwable)'` → line 1124. |

```php
// TimetableMenuController.php:1120-1126 — CURRENT
        // A malformed ?pv_date= must not take the whole five-tab page down.
        try {
            $raw = (string) $r->query('pv_date', '');
            $anchor = $raw !== '' ? Carbon::createFromFormat('!Y-m-d', $raw) : Carbon::today();
        } catch (\Throwable) {
            $anchor = Carbon::today();
        }
```

**Evidence**
```
$ grep -n 'catch (\\Throwable)' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
1124:        } catch (\Throwable) {
```

### F2 — Transactions and audit

clean — `grep -nE 'DB::transaction|->save\(|->create\(|->update\(|->delete\(|->insert\(|activityLog\(|beginTransaction' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php` → no output. This controller performs zero writes, so TXN-01..06 and the F2 audit checklist are not applicable.

### F3 — Authorization

#### TMN-03 · L · AUTH-06 — permission strings repeated as raw literals, no Policy consulted

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — permission strings live in one place — a Policy, or constants — not repeated as literals in every method. Lowered to L because the strings are correct and declared in `config/permissionslist.php`; this is maintainability debt, not an access hole. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:79` (and 187-193, 303, 481, 1644), methods `dashboard()`, `timetableConfiguration()`, `constraintEngine()`, `viewAndRefinement()`, `substituteManagement()` |
| **Root cause** | `tenant.smart-timetable.timetable.viewAny` appears as a literal in 4 methods, plus two `timetable-foundation.*` literals in `timetableConfiguration()`. The module's `SmartTimetablePolicy` exists (and its `viewAny()` checks the same string) but `Gate::authorize('string')` with no model never reaches a Policy, so the policy is dead for these pages. |
| **Consequence** | Renaming a permission means editing the strings in every controller and blade by hand; the policy that mirrors them silently does nothing. |
| **Reproduce** | Static only — the gate strings resolve correctly today (all four are declared in `config/permissionslist.php` under `smart-timetable.timetable`, `smart-timetable.constraint`, `timetable-foundation.config`, `timetable-foundation.academic-term`). |
| **Fix approach** | AUTH-06 is a cross-cutting convention across the module; defer to the SmartTimetable module split. Record, do not fix here. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `grep -n 'Gate::authorize\|Gate::any'` → lines 79, 188, 303, 481, 1644. |

```php
// TimetableMenuController.php:79 — CURRENT
        Gate::authorize('tenant.smart-timetable.timetable.viewAny');
```

**Evidence**
```
$ grep -n "Gate::authorize\|Gate::any" Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
79:        Gate::authorize('tenant.smart-timetable.timetable.viewAny');
188:            Gate::any([
303:        Gate::authorize('tenant.smart-timetable.constraint.viewAny');
481:        Gate::authorize('tenant.smart-timetable.timetable.viewAny');
1644:        Gate::authorize('tenant.smart-timetable.timetable.viewAny');
```

### F4 — Validation and input

clean — `grep -nE 'request->all\(|->except\(|->validate\(|->validated\(|->safe\(' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php` → no output. All input is read from GET query strings with `$r->integer()`, `$r->string()` or `$r->input()` into filter closures; there is no write path, so VAL-01/05/06 do not apply. The GET filters are deliberately unvalidated (they narrow queries only), matching the module's convention for tab filters.

### F5 — Routes

#### TMN-04 · M · RTE-03 — six public methods are not routed and must follow D5

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — every public controller method is routed, or is deliberately disabled (`abort(403)`, per the alignment-tracker rule and final-audit D5). |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:164-167, 290-293, 296-299, 468-471, 474-477, 1637-1640`, methods `preRequisitesSetup()`, `timetableMasters()`, `timetableRequirement()`, `resourceAvailability()`, `timetablePreparation()`, `reportsAndLogs()` |
| **Root cause** | These six redirect shims were left when their pages moved to `TimetableFoundationController`, but no route points at them: route:list shows only the five routed methods; grepping `Modules/SmartTimetable/routes/web.php` for `TimetableMenuController` finds only lines 49, 165-168. They are dead public methods. |
| **Consequence** | A developer greps for `preRequisitesSetup`, finds this method, and assumes the URL works; the URL 404s. The redirect target routes exist, but the shims are unreachable and misleading. |
| **Reproduce** | Try any of the old URLs the shims were meant to serve — they are not registered, so Laravel returns 404 before any controller runs. |
| **Fix approach** | Per D5: replace each body with `abort(403, 'This endpoint is not available.')` plus a `NOT ROUTED` comment. Never delete the methods. |
| **Plan item** | TMN-04 in `02-fix-plan.md` §5 |
| **Evidence** | `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` filtered for `TimetableMenuController@` → 5 routes only (see §4). |

```php
// TimetableMenuController.php:164-167 — CURRENT
    public function preRequisitesSetup(): mixed
    {
        return redirect()->route('timetable-foundation.menu.preRequisitesSetup');
    }
```

**Evidence**
```
$ grep -n "TimetableMenuController" Modules/SmartTimetable/routes/web.php
19:use Modules\SmartTimetable\Http\Controllers\TimetableMenuController;
49:        Route::get('/', [TimetableMenuController::class, 'dashboard'])->name('dashboard');
165:        Route::get('timetable-configuration', [TimetableMenuController::class, 'timetableConfiguration'])->name('menu.timetableConfiguration');
166:        Route::get('constraint-engine', [TimetableMenuController::class, 'constraintEngine'])->name('menu.constraintEngine');
167:        Route::get('view-and-refinement', [TimetableMenuController::class, 'viewAndRefinement'])->name('menu.viewAndRefinement');
168:        Route::get('substitute-management', [TimetableMenuController::class, 'substituteManagement'])->name('menu.substituteManagement');
```

### F6 — Controller shape

#### TMN-05 · M · CTL-01 — 1,781-line god controller; split deferred (D3)

| Field | Value |
|---|---|
| **Rule** | CTL-01 (M) — no god controllers: over 1,000 lines or 25 public methods → split by resource. (Over 2,500 lines would be H; at 1,781 lines this stays M.) |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:41`, class `TimetableMenuController` |
| **Root cause** | One class renders five unrelated tabs (dashboard, timetable configuration, constraint engine, view-and-refinement, substitute management) plus a 642-line private periodic-view engine. |
| **Consequence** | Any change to one tab risks the other four; the controller is far past the size a single developer can hold in mind, which is how the soft-delete allowlist bug (TMN-16) survived. |
| **Reproduce** | Static only — `wc -l` = 1781. |
| **Fix approach** | D3: fix in place now; the split is a DECISION item, never applied in this pass. |
| **Plan item** | TMN-05 (DECISION) in `02-fix-plan.md` §9 |
| **Evidence** | `wc -l` → 1781; `grep -cE 'public function'` → 11. |

```php
// TimetableMenuController.php:41 — CURRENT
class TimetableMenuController extends Controller
```

**Evidence**
```
$ wc -l Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
1781 Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
```

#### TMN-06 · H · CTL-02 — six methods exceed the length guide; periodicView is 642 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 — method length: over 80 lines → extract (M); over 150 lines is H. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:947`, method `periodicView()` (and 77 `dashboard()` 87, 172 `timetableConfiguration()` 118, 301 `constraintEngine()` 167, 479 `viewAndRefinement()` 391, 1642 `substituteManagement()` 140) |
| **Root cause** | The menu methods each build the full data contract of their tab in one method, and `periodicView()` alone contains the entire periodic-view engine (filter, date projection, grid/legend assembly). |
| **Consequence** | A 642-line method cannot be reviewed safely; its many early returns are only made safe by careful seeding (the comments show how often that went wrong). |
| **Reproduce** | Static only — see the awk span measurement in Evidence. |
| **Fix approach** | Extract step-by-step private helpers; but that is exactly the work the split decision (TMN-05) exists to bound, so it is deferred with it. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `awk` span measurement (function keyword to next function keyword), real output below. |

```php
// TimetableMenuController.php:947 — CURRENT
    private function periodicView(?OrganizationAcademicSession $currentSession): array
```

**Evidence**
```
$ awk '/^    (public|private) function /{ if(name!=""){print name": "start"-"NR-1" = "NR-start" lines"} name=$0; sub(/^ +/,"",name); sub(/\(.*/,"",name); sub(/^(public|private) function /,"",name); start=NR } END{print name": "start"-"NR" = "NR-start+1" lines"}' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
dashboard: 77-163 = 87 lines
timetableConfiguration: 172-289 = 118 lines
constraintEngine: 301-467 = 167 lines
viewAndRefinement: 479-869 = 391 lines
periodicView: 947-1588 = 642 lines
substituteManagement: 1642-1781 = 140 lines
```

#### TMN-07 · M · CTL-05 — identical `$applyStatus` and search closures duplicated across methods

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — no copy-paste: dropdown loaders and filter closures shared by `create`/`edit`, the same closure repeated. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:210-219` and `:312-321`, methods `timetableConfiguration()` and `constraintEngine()` |
| **Root cause** | The exact same `$applyStatus` closure (status filter that treats `'1'`/`'0'` and clamps `''` to no filter) is pasted twice; `$nameCodeSearch` / `$ttSearch` / `$ttSearch`-like closures are near-duplicates in `constraintEngine()` and `viewAndRefinement()`. |
| **Consequence** | A behavioural tweak to one status filter (like the 2026-09-26 "no default status" change) must be repeated in every copy, and the copies already behave slightly differently. |
| **Reproduce** | Static only — both closure definitions are byte-identical. |
| **Fix approach** | Extract one shared status/search helper after the split (TMN-05); not worth a solo refactor in a god controller. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `grep -n 'applyStatus = function'` → lines 210 and 312. |

```php
// TimetableMenuController.php:312-321 — CURRENT
        $applyStatus = function (string $key, ?string $default = null) use ($r) {
            $value = $r->input($key, $default);

            return function ($q) use ($value) {
                if ($value === null || $value === '') {
                    return;
                }
                $q->where('is_active', $value === '1' ? 1 : 0);
            };
        };
```

**Evidence**
```
$ grep -n "applyStatus = function" Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
210:        $applyStatus = function (string $key, ?string $default = null) use ($r) {
312:        $applyStatus = function (string $key, ?string $default = null) use ($r) {
```

#### TMN-08 · L · CTL-07 — compact() of 22 variables in constraintEngine

| Field | Value |
|---|---|
| **Rule** | CTL-07 (M) — no compact() of more than ~15 variables (build a view model / array). Lowered to L: the page genuinely needs most of the values and a view-model refactor only makes sense with the split. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:441-464`, method `constraintEngine()` |
| **Root cause** | The five-tab constraint page passes 22 variables, mixing the paginated tab lists, the filter dropdowns and the create-dialog data sources. |
| **Consequence** | `compact()` typing is unchecked; the two `_create-fields` partials can silently get half-populated lists when a dialog changes (the CE-02 comment documents this happened). |
| **Reproduce** | Static only — `grep -n "compact("` line 441. |
| **Fix approach** | Defer to the split; the tab partials and their data contracts move together. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `grep -n 'compact('` → 441. |

```php
// TimetableMenuController.php:441-444 — CURRENT
        return view('smarttimetable::pages.constraint-engine', compact(
            'constraintCategoryScopes',
            'constraintTypes',
            'constraints',
```

**Evidence**
```
$ grep -n "compact(" Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
156:        return view('smarttimetable::dashboard', compact('stats', 'pipeline', 'pipelinePct', 'recentTimetables', 'menuPages'));
277:        return view('timetablefoundation::pages.timetable-configuration', compact(
441:        return view('smarttimetable::pages.constraint-engine', compact(
807:        return view('smarttimetable::pages.view-and-refinement', array_merge($periodic, compact(
1772:        return view('smarttimetable::pages.substitute-management', compact(
```

#### TMN-09 · L · CTL-08 — request() helper instead of an injected Request

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — inject `Request`; don't call the `request()` helper inside controller methods. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:195`, method `timetableConfiguration()` (also 305, 483, 949, 1646) |
| **Root cause** | Every method starts `$r = request();` rather than taking `Request $request` in its signature. |
| **Consequence** | The methods are hard to unit-test and break the Laravel idiom; harmless at runtime. |
| **Reproduce** | Static only — `grep -nE '\brequest\(\)'` → 5 hits. |
| **Fix approach** | When each method is next touched (split TMN-05), add the injected parameter. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `grep -nE '\brequest\(\)'` → 195, 305, 483, 949, 1646. |

```php
// TimetableMenuController.php:195 — CURRENT
        $r = request();
```

**Evidence**
```
$ grep -nE '\brequest\(\)' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
195:        $r = request();
305:        $r = request();
483:        $r = request();
949:        $r = request();
1646:        $r = request();
```

### F7 — Models

No own findings. Every model this controller reaches is owned by another report (see §3 rows 35-47) and its specific behaviour — `$fillable`, `$casts`, `SoftDeletes`, relations used here — is audited there. This report checked usage only: the eager loads (`with([...])` on `Timetable`, `TimetableCell`, `TeacherAbsences`, `SubstitutionLog`, `ConstraintType`, `Constraint`, `TeacherUnavailable`, `RoomUnavailable`) name existing relations, and the `Timetable::assignable()`, `published()`, `latestFirst()` scopes are used consistently with the model comments.

### F8 — Services and jobs

#### TMN-10 · M · SVC-02 — services resolved via app() mid-method instead of constructor injection

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — dependencies arrive by constructor injection — not `new FooService()` or `app(Foo::class)` mid-method. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:550, 1064, 1184, 1673`, methods `viewAndRefinement()`, `periodicView()`, `substituteManagement()` |
| **Root cause** | `SnapshotContext` is pulled from the container at three call sites and `SubstitutionHistoryReader` at one, while the constructor and the only injected method (`substituteManagement(SubstitutionService $substitutionService)`) show the project's real convention. |
| **Consequence** | The four call sites are invisible to static analysis; swapping the implementation for a request-scoped one breaks silently. |
| **Reproduce** | Static only — `grep -nE '\bapp\('` → 4 hits. |
| **Fix approach** | Inject both helpers; low priority until the split, since `SnapshotContext` is designed as a stateless partitioner invoked on demand. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `grep -nE '\bapp\('` → 550, 1064, 1184, 1673. |

```php
// TimetableMenuController.php:1673 — CURRENT
        $history = app(SubstitutionHistoryReader::class);
```

**Evidence**
```
$ grep -nE '\bapp\(' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
550:        $timetableCells = new EloquentCollection(app(SnapshotContext::class)->partition(
1064:        $placed = collect(app(SnapshotContext::class)->partition(
1184:        $cells = new EloquentCollection(app(SnapshotContext::class)->partition(
1673:        $history = app(SubstitutionHistoryReader::class);
```

### F9 — Queries and performance

#### TMN-11 · H · QRY-01 — dashboard runs one count query per recent timetable (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — no queries inside loops: no `Model::where(...)` inside `foreach` / `->map()`. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:128-143`, method `dashboard()` |
| **Root cause** | `->map()` over the five recent timetables calls `TimetableCell::where('timetable_id', $tt->id)->count()` once per row — a 1+N pattern, and the count does not exclude soft-deleted cells (the dashboard's own cells tile does). |
| **Consequence** | Six queries instead of two on every dashboard load, and the per-row "Cells" badge can disagree with the "Cells Placed" hero tile when cells are trashed. |
| **Reproduce** | Open `/smart-timetable` with tenancy debug on: one count query per recent timetable row. |
| **Fix approach** | Pre-fetch all five counts in one grouped query, `whereNull('deleted_at')` to match the hero tile. |
| **Plan item** | TMN-11 in `02-fix-plan.md` §1 |
| **Evidence** | `grep -n 'TimetableCell::where'` → line 138 (inside the `->map()`). |

```php
// TimetableMenuController.php:128-143 — CURRENT
        // Recent timetables
        $recentTimetables = Timetable::with(['academicTerm', 'timetableType'])
            ->orderByDesc('updated_at')
            ->limit(5)
            ->get()
            ->map(function ($tt) {
                return [
                    'name' => $tt->name ?? 'Timetable #'.$tt->id,
                    'type' => $tt->timetableType->name ?? '—',
                    'term' => $tt->academicTerm->term_name ?? '—',
                    'cells' => TimetableCell::where('timetable_id', $tt->id)->count(),
                    'status' => $tt->published_at ? 'Published' : 'Draft',
                    'updated' => $tt->updated_at?->diffForHumans() ?? '—',
                    'id' => $tt->id,
                ];
            });
```

**Evidence**
```
$ grep -n "TimetableCell::where" Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
138:                    'cells' => TimetableCell::where('timetable_id', $tt->id)->count(),
```

#### TMN-12 · H · QRY-02 — Substitute Management lists are not paginated

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H) — lists are paginated; no `Model::all()` or unbounded `->get()` feeding a list page. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:1649-1705`, methods `viewAndRefinement()` (522-669) and `substituteManagement()` |
| **Root cause** | `$substituteRequirements` (all teacher absences), `$substitutionLogs` (all logs, live + snapshot), `$pendingNotifications`, and the View & Refinement lists (`$timetables`, `$publishedTimetables`, `$allTimetables`, `$timetableAssignments`) all end in `->get()` with no `paginate()`. The sibling tabs on the same pages (config/constraint-engine) paginate at 10 with per-tab page names — these do not. |
| **Consequence** | On a school with several years of absence and substitution history, the Substitute Management page loads every row into memory on every request and renders it all. |
| **Reproduce** | Open `/smart-timetable/substitute-management` on a tenant with a large `tt_substitution_logs`; the page issues a full-table select plus the snapshot mirror. |
| **Fix approach** | Paginate at 10 with distinct page names and add `->links()` to the two shared partials. This changes the shared blades, so it is a DECISION. |
| **Plan item** | TMN-12 (DECISION) in `02-fix-plan.md` §9 |
| **Evidence** | `grep -nE '\->get\(\);|\->get\(\)$'` → `substituteRequirements` ends at 1661, `substitutionLogs` at 1705. |

```php
// TimetableMenuController.php:1649-1661 — CURRENT
        $substituteRequirements = TeacherAbsences::with([
            'teacher.user',
            'approvedBy',
            'substitutions.substituteTeacher.user',
            'createdBy',
        ])
            ->when($r->filled('sr_teacher_id'), fn ($q) => $q->where('teacher_id', $r->input('sr_teacher_id')))
            ->when($r->filled('sr_status'), fn ($q) => $q->where('status', $r->input('sr_status')))
            ->when($r->filled('sr_absence_type'), fn ($q) => $q->where('absence_type', $r->input('sr_absence_type')))
            ->when($r->filled('sr_date_from'), fn ($q) => $q->whereDate('absence_date', '>=', $r->input('sr_date_from')))
            ->when($r->filled('sr_date_to'), fn ($q) => $q->whereDate('absence_date', '<=', $r->input('sr_date_to')))
            ->latest()
            ->get();
```

**Evidence**
```
$ grep -cE '\->get\(\)' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
28
```

#### TMN-13 · M · QRY-15 — unbounded dropdown loads on the view-and-refinement and constraint pages

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — don't load every row of a big table for a form: `Topic::get()`, `Student::get()` with no filter on a create/edit page. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:962-965`, method `periodicView()` (also 268, 396-403, 416-439, 722-727, 751, 775, 793, 1767-1770) |
| **Root cause** | Dropdown builders load full tables: `Teacher::active()->with('user')->get()`, `Room::orderBy('name')->get(['id','name'])`, `Subject::orderBy('name')->get(['id','name'])`, `SchoolClass::active()->get()`, `Section::active()->get()`, and `$filterTimetables = Timetable::query()->whereNotIn(...)->get(['id','name'])`. The inline comments claim these are small on this tenant (85 teachers, 69 rooms, 39 subjects, measured 2026-09-07) and that the relation map was "cheap enough to load always" — accepted, but it is a scaling trap. |
| **Consequence** | Every one of the four sub-pages pays these full-table selects even when the user opens a different tab, and the cost grows linearly with the school. |
| **Reproduce** | Open `/smart-timetable/view-and-refinement` with tenancy debug: 10+ unbounded selects before any filter is chosen. |
| **Fix approach** | After the split, gate the option lists behind the filter gate (the periodic view already loads them before the "nothing requested yet" return). A caching decision is separate (TEN-02). |
| **Plan item** | none — see plan §10 |
| **Evidence** | `grep -nE '\->get\(\);|\->get\(\)$'` → 27 unbounded gets. |

```php
// TimetableMenuController.php:962-965 — CURRENT
        $out = [
            'pvTeachers' => Teacher::active()->with('user')->get()
                ->sortBy(fn ($t) => $t->user->name ?? '')->values(),
            'pvRooms' => Room::orderBy('name')->get(['id', 'name']),
            'pvSubjects' => Subject::orderBy('name')->get(['id', 'name']),
```

**Evidence**
```
$ grep -nE '\->get\(\);|\->get\(\)$' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php | wc -l
27
```

#### TMN-14 · L · QRY-08 — 16 leading-wildcard LIKE searches

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M) — leading-wildcard `LIKE '%x%'` can't use an index. Lowered to L: every target table here is small (config keys, constraint masters, timetables) and search is a deliberate find-anything filter. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:224-226`, methods `timetableConfiguration()`, `constraintEngine()`, `viewAndRefinement()`, `periodicCellsQuery()` |
| **Root cause** | Filter closures wrap name/code/value with `'like', "%{$s}%"`; the count is 16 `LIKE` sites. |
| **Consequence** | Each search does a table scan — fine today on master tables, a trap the moment a searchable table (e.g. `tt_timetable_cells` search in `periodicCellsQuery`) grows. |
| **Reproduce** | Static only — measured with `grep -cE "like', \"%"`. |
| **Fix approach** | Accepted for now; revisit when the split introduces per-tab search endpoints. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `grep -cE "like', \"%"` → 16. |

```php
// TimetableMenuController.php:224-226 — CURRENT
                $q->where(fn ($qq) => $qq->where('key_name', 'like', "%{$s}%")
                    ->orWhere('value', 'like', "%{$s}%")
                    ->orWhere('description', 'like', "%{$s}%"));
```

**Evidence**
```
$ grep -cE "like', \"%" Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
16
```

### F10 — Views

clean — no DB queries in the blades this controller renders, and the relations the controller eager-loads are the ones the partials iterate. `grep -rnE "\{\{.*(Model::|DB::|::where|->count\(\)|->get\(\))" Modules/SmartTimetable/resources/views/pages/ Modules/SmartTimetable/resources/views/dashboard.blade.php` → the only `->count()` hits are on collections already fully loaded by the controller (`$ttCells->count()`, `$draftTimetables->count()`), not DB queries (VIEW-01/02/03 ok). The shared tab wrappers and partials are audited by SmartTimetableController's report (links in §3); this report verified the controller-variable contract for the periodic-view partial (every `$pv*` the blade reads is set by `periodicView()`, with locally `@php`-assigned `$pvGroupCap`/`$pvQuery`/`$pvShownGroups` inside `pages/partials/view-and-refinement/periodic-view/_list.blade.php:335-424`).

### F11 — Security and tenancy

clean — `grep -nE 'env\(|Log::.*\$request|request\(\)->all'` → no env() outside config, no body logging; no hard-coded ids (`?? 1` absent); the only `{!! !!}` in the menu partials feeds chart data built from database values, never user text; snapshot-dependent reads go through `SnapshotContext::partition()` (owned by StandardTimetableController's report); cache keys are not introduced here (TEN-02 is a DECISION class, not present).

### F12 — Style

#### TMN-15 · L · STY-04 — 69 comments carry emoji markers

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — comments in English, no emoji markers, no commented-out code. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:48-50`, comment block inside `SOFT_DELETE_TABLES` (representative; 69 lines total) |
| **Root cause** | The file's documentation style uses ⛔ ⚠ ⭐ glyphs as warning markers on 69 lines. The information is valuable; the punctuation breaks the "English comments" rule. |
| **Consequence** | Style debt only; the emoji can also be misrendered in some editors/terminals. |
| **Reproduce** | Static only — `grep -cP '[\x{26A0}\x{2B50}\x{26D4}]'` → 69 (plus 5 more with the full marker set used above). |
| **Fix approach** | Replace the glyphs with plain English markers (NOTE:, WARNING:) across the file in one pass. |
| **Plan item** | TMN-15 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -cP '[\x{26A0}\x{2B50}\x{26D4}\x{1F4A1}\x{2705}]'` → 69 matches (74 counting `\x{1F512}`-style markers). |

```php
// TimetableMenuController.php:48-50 — CURRENT
         * ⛔ sch_class_section_jnt IS NOT SOFT-DELETING, AND LISTING IT HERE READ 0 FOR EVERY
         *   TENANT. It used to appear in this array, so $safeCount() appended
         *   whereNull('deleted_at'), MySQL raised 1054, and the catch below turned that into
```

**Evidence**
```
$ grep -cP '[\x{26A0}\x{2B50}\x{26D4}\x{1F4A1}\x{2705}]' Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php
69
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There are **no mutating methods** in this controller (verified in F2: zero writes, zero transactions, zero `activityLog`), so the eight-question mutation table is empty. The one deep-read finding concerns read-side data correctness, answered here as the checklist's question 1 (wrong data) on a read path:

#### TMN-16 · M · MDL-03 — SOFT_DELETE_TABLES allowlist omits a table that actually soft-deletes

| Field | Value |
|---|---|
| **Rule** | MDL-03 (M) — soft-delete semantics must be honoured wherever rows are counted; closest rule to this read-side discovery. Raised from the rulebook's M because it is the same silent-wrong-number class the file's own comment describes for `sch_class_section_jnt` — inverted. Deep-read checklist question 1. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php:62-68`, const `SOFT_DELETE_TABLES`, consumed by `dashboard()` (`$safeCount('tt_slot_requirements', ['is_active' => 1])` at line 121) |
| **Root cause** | The allowlist names every table that the dashboard counts EXCEPT `tt_slot_requirements`. Verified on test.localhost: `SHOW COLUMNS FROM tt_slot_requirements LIKE "deleted_at"` returns a `timestamp` column, so the table soft-deletes. Because the entry is missing, `$safeCount()` never appends `whereNull('deleted_at')`, and the "Slot Req." pipeline tile counts trashed rows as real. |
| **Consequence** | The dashboard's "Slot Req." step stays green (count greater than zero) using only deleted slot requirements — a school admin believes pipeline prerequisites are met when they are not. |
| **Reproduce** | On a tenant with trashed `tt_slot_requirements` rows, open `/smart-timetable`: the Slot Req. tile includes them. On this tenant the tables are empty, so the effect is latent (static-only proof via SHOW COLUMNS). |
| **Fix approach** | Add `'tt_slot_requirements' => ['deleted_at'],` to the const, keeping the "do not restore sch_class_section_jnt" comment untouched. |
| **Plan item** | TMN-16 in `02-fix-plan.md` §5 |
| **Evidence** | `SHOW COLUMNS FROM tt_slot_requirements LIKE "deleted_at"` (tenant `xyz_school_00000000000040008000_202627`) → one row, `Field=deleted_at, Type=timestamp, Null=YES`, plus `grep -n "tt_slot_requirements"` → line 121 has the count, line 43-68 has no entry. |

```php
// TimetableMenuController.php:62-68 — CURRENT
        'tt_school_days' => ['deleted_at'],
        'tt_constraints' => ['deleted_at'],
        'tt_parallel_groups' => ['deleted_at'],
        'tt_requirement_consolidations' => ['deleted_at'],
        'tt_teacher_availabilities' => ['deleted_at'],
        'tt_analytics_daily_snapshots' => ['deleted_at'],
    ];
```

**Evidence**
```
$ php artisan tinker --execute '... DB::select("SHOW COLUMNS FROM tt_slot_requirements LIKE \"deleted_at\"") ...'
[0] => stdClass {"Field":"deleted_at","Type":"timestamp","Null":"YES","Key":"","Default":"","Extra":""}
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SmartTimetable/app/Policies/SmartTimetablePolicy.php` | `SmartTimetablePolicy::viewAny()` checks exactly the string this controller passes to `Gate::authorize()`, but a string ability with no model never reaches a Policy, so the Policy is dead for these pages. | AUTH-06 | SmartTimetable module split; the Policy itself is owned by SmartTimetableController's report |
| `Modules/SmartTimetable/resources/views/pages/view-and-refinement.blade.php` + partials | The sibling `SmartTimetableController::viewAndRefinement()` (line 1698) passes only 5 variables to a blade that needs 20+; that call would 500 today. This controller's call passes the full set. The shared blade's true owner is the full-set call. | VIEW | SmartTimetableController report (CLAIMED) |
| `config/permissionslist.php` | All four gate strings are declared there (`smart-timetable.timetable`, `smart-timetable.constraint`, `timetable-foundation.config`, `timetable-foundation.academic-term`, each with `$crud` that includes `viewAny`). No defect — recorded so a future re-audit does not re-check. | — | none |

## 8. Not covered, and why

- The 23 shared partials' full F10 walk (create-modals, field lists, JS) was not repeated here for rows that are `↗ linked` to SmartTimetableController's report — this report checked the controller's variable contract, not each partial's internals.
- `timetablefoundation::pages.timetable-configuration`'s included partials were not walked; the blade is owned by TimetableFoundationController's report and this controller only supplies paginated data for it.
- Snapshot behaviour of `SnapshotContext::partition()` and `PublishedTimetable::idFor()` was not re-verified in tinker; those are owned by StandardTimetableController and TimetableFoundationController reports (⚠ UNVERIFIED — re-run their audit evidence if the fixer touches the periodic view).
- No browser run: D4 forbids tests, and this workflow does not drive a browser; the "Reproduce" lines that say "static only" were not exercised on a rendered page.
- Live row counts on test.localhost are near-zero (measured 2026-10-10), so several findings (TMN-12, TMN-13, TMN-16) are latent rather than observed with real data; the SQL/SHOW evidence stands on its own.