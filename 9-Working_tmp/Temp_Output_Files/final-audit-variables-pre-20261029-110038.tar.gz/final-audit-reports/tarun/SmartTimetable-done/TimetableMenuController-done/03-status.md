# Status — SmartTimetable / TimetableMenuController

**Fixed:** 2026-10-16 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md` + retirement R3 from `../00-USAGE-AND-FIX-PLAN-2026-10-16.md` (§3, §5, §5.1)

## 1. Pre-applied work
None. `tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md` lists no file in this controller's scope.

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| **R3** | `TimetableMenuController.php` `dashboard()` + `routes/web.php` ⚠ SHARED (Tarun approved route removal 2026-10-16) | Removed the `smart-timetable.dashboard` route (the `/smart-timetable` landing page). It had no `glb_menus` row, and its only inbound links were breadcrumb parents of the retired TimetablePageController pages. The method body is now an `abort(403)` stub with a `NOT ROUTED` comment (D5). The blade `dashboard.blade.php` stays on disk. | router probe | `smart-timetable.dashboard` gone | 2026-10-16 |
| **R3** | `config/breadcrumbs.php` ⚠ SHARED | Removed the `smart-timetable.dashboard` entry. Its four children went with R2 (see `TimetablePageController-done/03-status.md`). | `grep -n "smart-timetable.dashboard'" config/breadcrumbs.php` | no output | 2026-10-16 |
| TMN-02 | `viewAndRefinement()` pv_date parse | `try`/`catch (\Throwable)` replaced with `Carbon::hasFormat($raw, 'Y-m-d')`. Measured: `2026-13-45`, `abc` and an empty string all fall back to today. Without the check, `createFromFormat` silently overflows `2026-13-45` to `2027-02-14`. | `grep -n "catch (" …` | only the explanatory comment | 2026-10-16 |
| TMN-04 | 6 methods | `preRequisitesSetup`, `timetableMasters`, `timetableRequirement`, `resourceAvailability`, `timetablePreparation` and `reportsAndLogs` are now `abort(403)` stubs with `NOT ROUTED` comments (D5). | `grep -c "abort(403" …` | 7 (6 + the R3 dashboard stub) | 2026-10-16 |
| TMN-12 | `substituteManagement()` + `pages/partials/substitute-management/substitute-requirement/_list.blade.php` + `…/substitute-notifications/_list.blade.php` ⚠ SHARED partials (Tarun ticked, 2026-10-16) | DECISION (a) paginate at 10, each list with its own page name. The KPI tiles and charts on these tabs are computed over the **full** collections, so those collections stay. Each row **table** now loops a 10-row page from the new `paginateCollection()` helper, which keeps the query string (`?tab=` plus every filter). Substitute Requirement pages on `sr_page`; Pending Notifications pages on `pn_page`. `->links()` was added under both tables. **Deviation from the plan:** the plan named `$substitutionLogs` / `sl_page`, but that collection has no row table: it feeds the notification tiles and an already-capped `take(10)` "recently notified" list. Pending Notifications is the second real list on the page, so it is the one paginated. | kernel render, see §6 | 200; page 2 links to 1 and 3 and keeps `tab` | 2026-10-16 |
| TMN-15 | `TimetableMenuController.php` | All 69 comment glyphs replaced with plain markers (`WARNING:`, `RECOMMENDED:`, `NOTE:`, `OK:`). | `grep -cP '[\x{26A0}\x{2B50}\x{26D4}…]' …` | 0 | 2026-10-16 |
| TMN-05 | — | DECISION (a): split deferred to the split pass (D3). | — | — | 2026-10-16 |
| **R1 tab** | `timetableConfiguration()` | Retirement R1 ("hide the tab") also lands in this file: `$showGenerationStrategy = false` and the two `TtGenerationStrategy` queries were removed. Full record in `../TtGenerationStrategyController-done/03-status.md`. | kernel render | 200, no Generation Strategy tab | 2026-10-16 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| TMN-01 | moot (R3) | The swallowed count failures lived only in `dashboard()`, which is retired |
| TMN-11 | moot (R3) | The per-row cell count lived only in `dashboard()` |
| TMN-16 | moot (R3) | `SOFT_DELETE_TABLES` is read only by `dashboard()`'s `$safeCount`. The constant stays as dead code, per D5 |
| TMN-05 | DECISION (a): deferred | 1,745-line class |
| TMN-06, TMN-07, TMN-08, TMN-09, TMN-10 | deferred with the split (plan §10) | Long methods, duplicated closures, 22-variable `compact()`, the `request()` helper, `app()` service location |
| TMN-03, TMN-13, TMN-14 | accepted (plan §10) | Permission-literal convention; small dropdown loads; leading-wildcard search |

## 4. Needs Tarun's hand
- Browser check on `/smart-timetable/substitute-management`. Substitute Requirement: 7 absences, so no pager yet. Pending Notifications tab: 22 rows, 3 pages. Page 2 should stay on the Notifications tab, and the tiles should still show the full totals.
- `/smart-timetable` now returns 404. Nothing in the menu links to it.
- Nothing needs to be migrated, seeded or synced.

## 5. Unverifiable by this workflow (no tests, D4)
- The substitute tab uses a hard-coded `active="substitute-requirement"` and relies on the nav-tab JS to select `?tab=`. The pager links keep `?tab=` (verified). That the right pane opens in a real browser is only visible there.

## 6. Verification log
```
php -l TimetableMenuController + routes/web.php + config/breadcrumbs.php  -> No syntax errors detected
vendor/bin/pint TimetableMenuController --format agent                    -> fixed (unary_operator_spaces, not_operator_with_successor_space, ordered_imports)
vendor/bin/pint routes/web.php config/breadcrumbs.php --test              -> passed
router probe (route:clear first)                                          -> 128 SmartTimetable routes; only missing method is the
                                                                             pre-existing R5 generate-for-class-section (fixed in the R5 pass)
kernel render GET /smart-timetable/substitute-management?tab=substitute-requirement   -> 200, 520,567 bytes, 0 leaked '{{--'
kernel render ...?tab=substitute-notifications&pn_page=2                              -> 200, links pn_page=1 and pn_page=3, tab kept
row counts (tenant test.localhost)                                        -> absences 7 (< 10, no pager) · pending notifications 22 (3 pages)
Carbon::hasFormat probe                                                   -> 2026-10-16 true · 2026-13-45 false · abc false · '' false
```

## 7. Final state
Status: FIXED · Open: B 0 · H 1 (TMN-06 deferred) · M 4 (TMN-05, TMN-07, TMN-10 deferred; TMN-13 accepted) · L 4 (TMN-03, TMN-14 accepted; TMN-08, TMN-09 deferred)
