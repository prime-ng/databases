# SmartTimetable — Module Audit Summary

**Protocol:** `.claude/rules/final-audit.md` §13.2 · **Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md`
**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Phase:** AUDIT. Read-only — no application code changed. Every report passed `_tools/selfcheck.py`.

All 19 top-level controllers of `Modules/SmartTimetable` are audited. One folder per controller holds
`01-report.md` + `02-fix-plan.md`. Tick items in each plan, then run `final-audit-fixer` on the path.

## 1. Per-controller results

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| PythonTimetableController | 3,227 | 4 | 2 | 8 | 4 | 5 | raw exception text (SQL/paths) flashed to the user on the save path | [01](PythonTimetableController-done/01-report.md) |
| SmartTimetableController | 1,784 | 1 | 1 | 12 | 5 | 3 | `destroy()` flashes raw `$e->getMessage()`; **SEC-009 refuted** — 14 `Gate::authorize` calls | [01](SmartTimetableController-done/01-report.md) |
| TimetableMenuController | 1,781 | 0 | 4 | 6 | 6 | 2 | dashboard `$safeCount()` swallows SQL errors and prints plausible zeros (hid the "Class Section = 0" bug) | [01](TimetableMenuController-done/01-report.md) |
| TimetablePreviewController | 1,652 | 0 | 5 | 6 | 3 | 4 | write endpoints still wrapped in controller try/catch (D1) + stored XSS | [01](TimetablePreviewController-done/01-report.md) |
| TimetablePageController | 1,073 | 2 | 1 | 6 | 4 | 4 | Operation page imports a non-existent class + missing `@include` → two 500s | [01](TimetablePageController-done/01-report.md) |
| TimetableGenerationController | 969 | 2 | 5 | 9 | 5 | 5 | dead route points at a non-existent method (500); raw leaks; state change over GET | [01](TimetableGenerationController-done/01-report.md) |
| RoomUnavailableController | 594 | 0 | 2 | 6 | 4 | 3 | restore runs over GET; 6 D1 try/catch mutations | [01](RoomUnavailableController-done/01-report.md) |
| TeacherUnavailableController | 584 | 0 | 1 | 6 | 6 | 4 | restore runs over a GET URL (no CSRF) | [01](TeacherUnavailableController-done/01-report.md) |
| ConstraintController | 540 | 4 | 4 | 12 | 3 | 5 | constraint engine silently ignores stored rules; `ConstraintManager` passes a failing hard rule | [01](ConstraintController-done/01-report.md) |
| ParallelGroupController | 493 | 0 | 3 | 5 | 7 | 1 | re-adding a removed activity fails (pivot unique index includes soft-deleted rows) | [01](ParallelGroupController-done/01-report.md) |
| TimetableExportController | 429 | 0 | 2 | 3 | 3 | 4 | exports gated on `.view`, not `.export` — view-right equals whole-schedule download | [01](TimetableExportController-done/01-report.md) |
| SubstitutionController | 419 | 2 | 6 | 8 | 7 | 3 | every failed write echoes the raw DB exception text to the user | [01](SubstitutionController-done/01-report.md) |
| TtGenerationStrategyController | 375 | 1 | 1 | 7 | 6 | 2 | the whole CRUD is unreachable — zero routes registered; views call names that throw | [01](TtGenerationStrategyController-done/01-report.md) |
| ConstraintTypeController | 362 | 0 | 1 | 8 | 4 | 3 | restore runs over GET (prefetcher can restore a trashed type) | [01](ConstraintTypeController-done/01-report.md) |
| ConstraintCategoryScopeController | 301 | 0 | 1 | 6 | 6 | 2 | restore runs over GET (prefetcher can restore a trashed record) | [01](ConstraintCategoryScopeController-done/01-report.md) |
| TimetableWorkspaceController | 255 | 0 | 1 | 5 | 3 | 3 | `grid()` swallows a `ModelNotFoundException` and returns a 500 instead of a 404 | [01](TimetableWorkspaceController-done/01-report.md) |
| TimetablePublishController | 184 | 1 | 1 | 5 | 1 | 2 | publish/unpublish return raw `$e->getMessage()` (SQL/table names) | [01](TimetablePublishController-done/01-report.md) |
| RefinementController | 158 | 1 | 2 | 5 | 3 | 2 | `swap`/`move` sync the pivot without `assignment_role_id` (NOT NULL) → insert throws | [01](RefinementController-done/01-report.md) |
| AnalyticsController | 117 | 0 | 0 | 4 | 2 | 1 | `?timetable_id=abc` reaches `int`-typed service methods → 500 | [01](AnalyticsController-done/01-report.md) |

## 2. Module totals

| B | H | M | L | DECISIONs |
|---|---|---|---|---|
| **18** | **43** | **127** | **82** | **~58** |

**Blockers (B=18):** PythonTimetableController ×4, ConstraintController ×4, TimetableGenerationController ×2,
TimetablePageController ×2, SubstitutionController ×2, SmartTimetableController, TimetablePublishController,
TtGenerationStrategyController, RefinementController.

## 3. Cross-controller families (fix as one change)

1. **Raw exception text to the user** (ERR-01) — the dominant family: Publish, Substitution, Generation,
   SmartTimetable, Python, Constraint and more. One controller-wide sweep per file + `report($e)` (ERR-05).
2. **Controller `try/catch`** (ERR-00 / D1) — TimetableWorkspace, RoomUnavailable, TimetablePreview,
   Constraint and others still catch in the controller (some swallow 404s → 500/redirect).
3. **`restore` over GET** (RTE-01) — ConstraintCategoryScope, ConstraintType, TeacherUnavailable,
   RoomUnavailable, Constraint, and others; a prefetcher can restore without CSRF.
4. **Dead routes → guaranteed 500s** (RTE-02) — TtGenerationStrategy (zero routes), TimetableGeneration
   (route to a missing method), TimetablePage (missing class/view). Run `route:list` method-exists.
5. **Swallowed failures that print false values** (ERR-06 / F13.7) — TimetableMenu's `$safeCount()`,
   TimetableWorkspace's catch: the screen shows zero/500 instead of the truth.
6. **God controllers** (CTL-01) — PythonTimetable (3,227), SmartTimetable (1,784), TimetableMenu (1,781),
   TimetablePreview (1,652), TimetablePage (1,073). Splits are **DEFERRED** (D3).
7. **Constraint engine integrity** — `ConstraintController`: stored rules fall to `Generic*` classes and
   failing hard constraints report pass (the schedule is silently wrong).

## 4. Shared classes and their owner reports

`final-audit-reports/00-CLASS-OWNERS.md` (pre-assigned by the main session). Owners: `Timetable` →
AnalyticsController; `Constraint`/`ConstraintCategoryScope` → ConstraintCategoryScopeController;
`ConstraintType` → ConstraintTypeController; `SchoolDay`/`PeriodSetPeriod`/`TimetableCell` →
TimetableExportController; `TtGenerationStrategy`/`Activity` → TtGenerationStrategyController;
`TeacherUnavailable` → TeacherUnavailableController; `RoomUnavailable` → RoomUnavailableController;
`SubActivity`/`SmartTimetablePolicy` → SmartTimetableController; `ConflictDetection`/`GenerationRun`/
`TimetableStorageService`/`PreviewViewData`/`PreviewGridState`/`GenerationService`/`GenerateTimetableJob` →
TimetableGenerationController; `SubstitutionLog`/`TeacherAbsences`/`SubstitutionService` →
SubstitutionController; `ParallelGroup`/`ParallelGroupActivity` → ParallelGroupController; `TeacherAvailablity`
→ TimetablePageController; the constraint service cluster (`Constraints/*`, `DatabaseConstraintService`) →
ConstraintController; `Python/*`, `Generator/*`, `Solver/*` → PythonTimetableController; `Preview/*`
remainder → TimetablePreviewController; `Workspace/*` → TimetableWorkspaceController; `Publishing/*` →
TimetablePublishController; `RefinementService` → RefinementController. No duplicate claims.

## 5. Module-wide decisions

1. **God-controller splits** (CTL-01) — five controllers over 1,000 lines; deferred to the split pass (D3).
2. **Unreachable policies** — `SmartTimetablePolicy` / `TimetableGenerationStrategyPolicy` are not consulted
   where gates pass permission strings (module-wide pattern).
3. **Tenant-keyed caches** — TimetablePreview uses non-tenant-keyed static caches (leak risk).

## 6. Not covered, and why

- **`Api/TimetableApiController`** (`Modules/SmartTimetable/app/Http/Controllers/Api/`, and its service
  subdirs) — out of the protocol's module scope (`ls .../Controllers/*.php`, §13.1). Audit on request.
- **Runtime behaviour** — no browser/test run (D4); every finding is static or a read-only SQL probe.

## 7. Status

- **Index:** all 19 rows `AUDITED` (`tarun/SmartTimetable/00-INDEX.md`).
- **Self-check:** every report prints `SELF-CHECK PASS`.
- **Not fixed:** read-only audit. Fixes wait on Tarun ticking `02-fix-plan.md` items and tarun running
  `final-audit-fixer`.
- **Blocked:** nothing.
