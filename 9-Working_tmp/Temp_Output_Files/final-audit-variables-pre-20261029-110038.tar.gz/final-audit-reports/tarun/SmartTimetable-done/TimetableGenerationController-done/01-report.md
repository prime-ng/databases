# Final Audit — SmartTimetable / TimetableGenerationController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php` (969 lines, 9 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /smart-timetable/timetable-generation` (page, `?tab=warnings-fixes\|timetable\|generation-history`); `GET /smart-timetable/generate/random` (legacy generate); `POST /smart-timetable/generate/generate-prime` (generate); `POST /smart-timetable/store` (save preview); `POST /smart-timetable/generate/reset-lock`; `GET /smart-timetable/timetable/trashed`; `POST /smart-timetable/timetable/{id}/restore`; `DELETE /smart-timetable/timetable/{id}/force-delete` |
| Menu path | Smart Timetable → Timetable Generation (default tab: Warnings & Fixes) |
| Who uses it | Roles holding `tenant.smart-timetable.timetable.generate` / `.create` / `.delete` / `.viewAny`. Measured on `test.localhost`: each of those permissions is held by **2 roles** (`SELECT ... sys_role_has_permissions_jnt`, output below). |
| What a user does here | A school administrator reviews pre-generation warnings, then clicks Generate. The solver builds an in-memory timetable, a skeleton draft is created, and the preview screen is shown. The user reviews the preview and clicks Save, which fills the skeleton cells with lessons and stores the timetable as a **draft** (status GENERATED, not published). From the trash screen the user can restore or permanently delete a timetable. |
| Tables written | `tt_timetables`, `tt_generation_runs`, `tt_timetable_cells`, `tt_timetable_cell_teachers`, `tt_conflict_detection`, `tt_activity_teachers` (through the solver's class-teacher auto-assign), `tt_teacher_availability_details`, `sys_activity_logs` |
| Tables read | `tt_timetables`, `tt_generation_runs`, `tt_activities`, `tt_timetable_types`, `tt_period_sets`, `tt_class_timetable_types`, `sch_academic_term`, `sch_academic_session`, `sch_classes`, `sch_subjects` |
| Live data | On tenant `xyz_school_00000000000040008000_202627` the four core tables are empty: `tt_timetables=0`, `tt_generation_runs=0`, `tt_conflict_detection=0`, `tt_timetable_cells=0`. This is a fresh test tenant, so no live timetable exists to reproduce with; the findings below are static unless a **Reproduce** field names a live action. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready in its current state. Two blockers: a routed URL points at a method (`generateForClassSection`) that does not exist, so `/smart-timetable/generate/{class_id}/{section_id}/generate` is a guaranteed 500; and five code paths show the raw exception message (often a SQL string with table and column names) to the user. The single worst finding is `TGC-08` (dead route → 500), because it is a normal, linkable URL that cannot work at all. Generation itself is a state change behind a GET (`TGC-09`), the save sequence logs its audit event outside the write's transaction (`TGC-05`), and generation silently rewrites teacher assignments through the solver's class-teacher auto-assign (`TGC-14`). Effort to clear the ticked plan: **M** (roughly half a day), dominated by wrapping the GET-generation decision and dead-code removal.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 5 | 9 | 5 | 4 | 21 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TGC-01, TGC-02, TGC-03, TGC-04 | F8 Services/Jobs | TGC-14, TGC-15, TGC-16 |
| F2 Transactions/Audit | TGC-05, TGC-06 | F9 Queries/Perf | TGC-17, TGC-18 |
| F3 Authorization | TGC-21 | F10 Views | clean |
| F4 Validation | TGC-07 | F11 Security/Tenancy | clean |
| F5 Routes | TGC-08, TGC-09 | F12 Style | TGC-19 |
| F6 Controller shape | TGC-10, TGC-11, TGC-12, TGC-13 | F13 Deep read | table — no separate findings |
| F7 Models | TGC-20 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php` | controller | 969 | this report | ✅ |
| 2 | `Modules/SmartTimetable/app/Models/ConflictDetection.php` | model | 155 | this report | ✅ |
| 3 | `Modules/SmartTimetable/app/Models/GenerationRun.php` | model | 235 | this report | ✅ |
| 4 | `Modules/SmartTimetable/app/Services/GenerationResult.php` | service (value object) | 89 | this report | ✅ |
| 5 | `Modules/SmartTimetable/app/Services/TimetableGenerationService.php` | service | 3287 | this report | ✅ reachable surface only |
| 6 | `Modules/SmartTimetable/app/Jobs/GenerateTimetableJob.php` | job | 175 | this report | ✅ |
| 7 | `Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php` | service | 1044 | this report | ✅ reachable surface only |
| 8 | `Modules/SmartTimetable/app/Services/Preview/PreviewViewData.php` | service | 87 | this report | ✅ |
| 9 | `Modules/SmartTimetable/app/Services/Preview/PreviewGridState.php` | service | 940 | this report | ✅ shallow only |
| 10 | `Modules/SmartTimetable/resources/views/smart-timetable/generation.blade.php` | blade | 44 | this report | ✅ |
| 11 | `Modules/SmartTimetable/resources/views/smart-timetable/trash.blade.php` | blade | 89 | this report | ✅ |
| 12 | `Modules/SmartTimetable/resources/views/preview/index.blade.php` | blade | 3311 | this report | ✅ shallow only |
| 13 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | 516 | ↗ [tarun/SmartTimetable/AnalyticsController](../AnalyticsController-done/01-report.md) | ↗ linked |
| 14 | `Modules/TimetableFoundation/app/Models/Activity.php` | model | — | ↗ [tarun/SmartTimetable/TtGenerationStrategyController](../TtGenerationStrategyController-done/01-report.md) | ↗ linked |
| 15 | `Modules/SmartTimetable/app/Models/Constraint.php` | model | — | ↗ [tarun/SmartTimetable/ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked |
| 16 | `Modules/SmartTimetable/app/Services/Constraints/ConstraintManager.php` | service | — | ↗ [tarun/SmartTimetable/ConstraintController](../ConstraintController-done/01-report.md) | ↗ linked |
| 17 | `Modules/SmartTimetable/app/Services/Constraints/Hard/ShortBreakConstraint.php` and `Hard/LunchBreakConstraint.php` | service | — | ↗ [tarun/SmartTimetable/ConstraintController](../ConstraintController-done/01-report.md) | ↗ linked |
| 18 | `Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php` | service | — | ↗ [tarun/SmartTimetable/TimetablePublishController](../TimetablePublishController-done/01-report.md) | ↗ linked |

**Common classes referenced but not audited here** (per `.claude/rules/final-audit.md` §4.2): `App\Http\Controllers\Controller`; `Modules/Prime/Models/AcademicSession`; `Modules/SchoolSetup/Models/SchoolClass` and `Subject`; `Modules/TimetableFoundation/Models/AcademicTerm`, `ClassTimetableType`, `PeriodSet`, `TimetableType`. No in-scope file appears in a module `PRE-APPLIED-*.md`, so **no pre-applied files**.

## 4. Routes

```
POST    smart-timetable/generate/generate-prime                 smart-timetable.smart-timetable-management.generate-prime      Modules\SmartTimetable\Http\Controllers\TimetableGenerationController@generateWithPrime
GET|HEAD smart-timetable/generate/generate-prime                 smart-timetable.smart-timetable-management.generate-prime.get  Modules\SmartTimetable\Http\Controllers\TimetableGenerationController@redirectGeneratePrime
GET|HEAD smart-timetable/generate/random                         smart-timetable.smart-timetable-management.generate            Modules\SmartTimetable\Http\Controllers\TimetableGenerationController@generate
POST    smart-timetable/generate/reset-lock                     smart-timetable.smart-timetable-management.reset-lock          Modules\SmartTimetable\Http\Controllers\TimetableGenerationController@resetGenerationLock
GET|HEAD smart-timetable/generate/{class_id}/{section_id}/generate smart-timetable.smart-timetable-management.generate-for-class-section Modules\SmartTimetable\Http\Controllers\TimetableGenerationController@generateForClassSection
POST    smart-timetable/store                                   smart-timetable.smart-timetable-management.store-timetable     Modules\SmartTimetable\Http\Controllers\TimetableGenerationController@storeTimetable
GET|HEAD smart-timetable/timetable-generation                   smart-timetable.timetable.timetableGeneration                  Modules\SmartTimetable\Http\Controllers\TimetableGenerationController@timetableGeneration
GET|HEAD smart-timetable/timetable/trashed                       smart-timetable.timetable.trashed                              Modules\SmartTimetable\Http\Controllers\TimetableGenerationController@trashedTimetable
DELETE  smart-timetable/timetable/{id}/force-delete             smart-timetable.timetable.forceDelete                          Modules\SmartTimetable\Http\Controllers\TimetableGenerationController@forceDeleteTimetable
POST    smart-timetable/timetable/{id}/restore                  smart-timetable.timetable.restore                              Modules\SmartTimetable\Http\Controllers\TimetableGenerationController@restoreTimetable
```

Unrouted public methods: **none**. Every public method is routed (`generate`, `storeTimetable`, `timetableGeneration`, `trashedTimetable`, `restoreTimetable`, `forceDeleteTimetable`, `generateWithPrime`, `resetGenerationLock`, `redirectGeneratePrime`). The reverse defect exists — the route at line 63 names `generateForClassSection`, a method the controller does not have (TGC-08).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `generate` | 43 | GET `smart-timetable/generate/random` | `tenant.smart-timetable.timetable.generate` | via `generateWithPrime` → storage `createSkeleton` | `'GenerationRun'` (in `generateWithPrime`) | tt_timetables, tt_generation_runs, tt_timetable_cells, tt_activity_teachers | TGC-08, TGC-09, TGC-21 |
| `storeTimetable` | 186 | POST `smart-timetable/store` | `tenant.smart-timetable.timetable.create` | storage `populateFromResult` + `finalizeGenerated` | `'Generated'` (outside the tx) | tt_timetable_cells, tt_timetable_cell_teachers, tt_generation_runs, tt_timetables, tt_conflict_detection | TGC-01, TGC-02, TGC-03, TGC-04, TGC-05, TGC-07, TGC-19 |
| `timetableGeneration` | 329 | GET `smart-timetable/timetable-generation` | `tenant.smart-timetable.timetable.generate` | none (read) | none | none | TGC-10, TGC-13, TGC-17, TGC-19 |
| `trashedTimetable` | 439 | GET `smart-timetable/timetable/trashed` | `tenant.smart-timetable.timetable.delete` | none (read) | none | none | TGC-13 |
| `restoreTimetable` | 461 | POST `smart-timetable/timetable/{id}/restore` | `tenant.smart-timetable.timetable.delete` | controller `DB::transaction` | `'Restored'` | tt_timetables, sys_activity_logs | TGC-01, TGC-03, TGC-12 |
| `forceDeleteTimetable` | 505 | DELETE `smart-timetable/timetable/{id}/force-delete` | `tenant.smart-timetable.timetable.delete` | controller `DB::transaction` | `'Deleted'` | tt_timetables + all FK children, sys_activity_logs | TGC-01, TGC-03, TGC-12 |
| `generateWithPrime` | 548 | POST `smart-timetable/generate/generate-prime` | `tenant.smart-timetable.timetable.generate` | storage `createSkeleton` | `'GenerationRun'` | tt_timetables, tt_generation_runs, tt_timetable_cells | TGC-01, TGC-03, TGC-05, TGC-09, TGC-10, TGC-14, TGC-15, TGC-21 |
| `resetGenerationLock` | 741 | POST `smart-timetable/generate/reset-lock` | `tenant.smart-timetable.timetable.generate` | none | `'GenerationReset'` | tt_generation_runs (+ skeleton delete) | TGC-03, TGC-06, TGC-16 |
| `redirectGeneratePrime` | 961 | GET `smart-timetable/generate/generate-prime` | `tenant.smart-timetable.timetable.viewAny` | none | none | none | TGC-12 |
| `createConstraintManager` | 79 | not routed (private) | none | none | none | none | TGC-11 |
| `createConstraintManagerFromDatabase` | 132 | not routed (private) | none | none | none | none | TGC-11 |
| `persistConflictDetection` | 901 | private | none | none | none | tt_conflict_detection | TGC-04 |
| `safelyDeleteSkeleton` | 799 | private | none | via storage `deleteSkeleton` | none | tt_timetables, tt_generation_runs, children | TGC-03 |

## 6. Findings

### F1 — Errors

#### TGC-01 · B · ERR-01 — Raw exception text is shown to the user on five paths

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *Never send exception text to the user. No `$e->getMessage()` in `withErrors`, `with('error')`, `response()->json`, or `back()`. SQL, table and column names leak.* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:274` and `:285` (method `storeTimetable()`), plus `:490` (`restoreTimetable()`), `:537` (`forceDeleteTimetable()`), `:724` (`generateWithPrime()`) |
| **Root cause** | Each mutation returns the caught exception's message straight into a flash string. A `QueryException` message carries the full SQL statement, the table and the column names, and a duplicate-index violation carries the offending value. |
| **Consequence** | A user who hits a save/restore/force-delete/generate failure reads the database's own error text (SQL, table and column names, sometimes row values) on screen. |
| **Reproduce** | Static only — the five sites are the only code between the user and the DB error; no live row exists on this tenant to force the failure. The flash is `back()->with('error', ...)`, and `storeTimetable` is reachable from the preview Save form. |
| **Fix approach** | Replace each interpolated message with a fixed, page-specific string and log the exception object with `report($e)` (under D1, remove the surrounding try/catch entirely). |
| **Plan item** | TGC-01 in `02-fix-plan.md` §1 |

```php
        } catch (\RuntimeException $e) {
            return back()->with('error', $e->getMessage());
        } catch (\Throwable $e) {
```

**Evidence**
```
$ grep -n "getMessage()" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
274:            return back()->with('error', $e->getMessage());
281:                'error' => $e->getMessage(),
285:            return back()->with('error', 'Save failed: '.$e->getMessage());
485:                'error' => $e->getMessage(),
490:                ->with('error', 'Failed to restore timetable: '.$e->getMessage());
532:                'error' => $e->getMessage(),
537:                ->with('error', 'Failed to permanently delete timetable: '.$e->getMessage());
577:                            'error' => $cleanupErr->getMessage(),
716:                'error' => $e->getMessage(),
724:                ->with('error', 'Timetable generation failed: '.$e->getMessage())
775:                    $messages[] = "skeleton #{$skeletonTimetableId} marked FAILED (delete failed: ".$cleanupErr->getMessage().')';
809:                'error' => $e->getMessage(),
956:                'error' => $e->getMessage(),
```

#### TGC-02 · H · ERR-02 — `findOrFail()` sits inside the generic catch and turns a 404 into a redirect

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *A catch must never turn a 404/403/422/`abort()` into a redirect or 500.* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:225`, method `storeTimetable()` (try opens at `:211`) |
| **Root cause** | `Timetable::findOrFail($timetableId)` is called inside the `try`, and the `catch (\Throwable $e)` at `:275` swallows the `ModelNotFoundException`. The id is validated only by `exists:tt_timetables,id`, so a row deleted between the preview and the Save click reaches here. |
| **Consequence** | A user saving a preview whose timetable row was deleted sees "Save failed" with a raw message instead of a 404, and the session is not cleared. |
| **Reproduce** | Open a preview, delete the underlying timetable from another tab, then click Save. Expected 404; actual redirect with a red flash. |
| **Fix approach** | Resolve the timetable before the `try`, or remove the controller try/catch entirely (D1) and rely on the central handler. |
| **Plan item** | TGC-02 in `02-fix-plan.md` §3 |

```php
            $timetable = Timetable::findOrFail($timetableId);
```

**Evidence**
```
$ grep -n "findOrFail\|catch (" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
225:            $timetable = Timetable::findOrFail($timetableId);
271:        } catch (\RuntimeException $e) {
275:        } catch (\Throwable $e) {
468:        $timetable = Timetable::onlyTrashed()->findOrFail($id);
510:        $timetable = Timetable::withTrashed()->findOrFail($id);
```

#### TGC-03 · M · ERR-05 — Failures are logged as `getMessage()` only, losing the exception trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *Log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`. `getMessage()` alone loses the trace.* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:279-283` (method `storeTimetable()`); the same shape repeats at `:483-486`, `:530-533`, `:575-578`, `:715-721`, `:771-774`, `:807-810`, `:954-957` |
| **Root cause** | The catch blocks pass `'error' => $e->getMessage()` (and sometimes a raw `getTraceAsString()` string) to `Log::`, instead of the exception object. |
| **Consequence** | Support cannot see the exception class, file or line for a failed generation from the log entry; only the message survives. |
| **Reproduce** | Static only — this is a logging-call shape, not a runtime screen. |
| **Fix approach** | Pass the exception object: `Log::error('…', ['exception' => $e])`, or call `report($e)`. |
| **Plan item** | TGC-03 in `02-fix-plan.md` §3 |

```php
            \Log::error('Timetable populate-and-publish failed', [
                'timetable_id' => $timetableId,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
$ grep -n "Log::error\|Log::warning" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
279:            \Log::error('Timetable populate-and-publish failed', [
483:            Log::error('Timetable restore failed', [
530:            Log::error('Timetable force-delete failed', [
575:                        \Log::warning('Failed to delete stale skeleton; falling back to FAILED mark', [
715:            \Log::error('Prime Generation Error', [
771:                    \Log::warning('Manual reset: failed to delete skeleton', [
807:            \Log::warning('Skeleton cleanup failed', [
954:                \Log::warning('ConflictDetection persist failed — timetable was saved successfully', [
```

#### TGC-04 · M · ERR-06 — A write-path failure is swallowed with no user-visible or retry signal

| Field | Value |
|---|---|
| **Rule** | ERR-06 (M) — *No swallowed failures in write paths — an empty `catch`, or a catch that logs and then continues as if the write succeeded.* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:953-958`, method `persistConflictDetection()` |
| **Root cause** | `ConflictDetection::create(...)` at `:941` is a real INSERT into `tt_conflict_detection`, but the surrounding `catch (\Throwable $e)` logs a warning and returns as if the record were stored. This is the exact shape that hid the table-name typo described in `ConflictDetection.php:14-24` for months. |
| **Consequence** | A generation can complete with no conflict-detection record and nothing on screen says so; the operator later cannot find the conflicts that the preview showed. |
| **Reproduce** | Static only — no live row exists on this tenant to force the insert to fail. |
| **Fix approach** | Narrow the catch to the intended failure (a best-effort log may still be `report($e)`), and surface a warning in the redirect so a lost record is visible. If the record is required, write it inside the save transaction instead. |
| **Plan item** | TGC-04 in `02-fix-plan.md` §3 |

```php
        } catch (\Throwable $e) {
            \Log::warning('ConflictDetection persist failed — timetable was saved successfully', [
                'timetable_id' => $timetable->id,
                'error' => $e->getMessage(),
            ]);
        }
```

**Evidence**
```
$ sed -n '941,958p' Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
            ConflictDetection::create([
                'timetable_id' => $timetable->id,
                'detection_type' => 'GENERATION',
                'detected_at' => now(),
                'conflict_count' => $totalConflicts,
                'hard_conflicts' => $hardConflicts,
                'soft_conflicts' => $softConflicts,
                'conflicts_json' => $conflictsJson,
                'resolution_suggestions_json' => empty($suggestions) ? null : $suggestions,
                'resolved_at' => $totalConflicts === 0 ? now() : null,
                'is_active' => true,
            ]);
        } catch (\Throwable $e) {
            \Log::warning('ConflictDetection persist failed — timetable was saved successfully', [
                'timetable_id' => $timetable->id,
                'error' => $e->getMessage(),
            ]);
        }
```

### F2 — Transactions and audit

#### TGC-05 · M · TXN-04 — The audit event is written after the transaction commits, not inside it

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes. Not before it, not after commit.* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:248`, method `storeTimetable()`; the same shape at `:692`, method `generateWithPrime()` |
| **Root cause** | The write lives inside `TimetableStorageService::finalizeGenerated()`'s `DB::transaction`, which returns before the controller calls `activityLog($saved, 'Generated', ...)`. The audit row is therefore a separate, non-atomic write. |
| **Consequence** | If the process dies between the commit and the `activityLog` call, the timetable is saved with no "Generated" audit entry, so the school's trace of the generation event is incomplete. |
| **Reproduce** | Static only — the gap is a process-death window, not a deterministic screen. |
| **Fix approach** | Move the audit call inside the service transaction (pass the event into `finalizeGenerated()`), or use `DB::afterCommit()` only if an audit entry outside the transaction is deliberately acceptable. |
| **Plan item** | none — see plan §10 |

```php
            activityLog($saved, 'Generated', [
```

**Evidence**
```
$ grep -n "activityLog(" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
248:            activityLog($saved, 'Generated', [
478:                activityLog($timetable, 'Restored', [
525:                activityLog($timetable, 'Deleted', [
692:            activityLog(
781:            activityLog($activeRun, 'GenerationReset', [
788:            activityLog(auth()->user(), 'GenerationReset', [
```

#### TGC-06 · M · TXN-01 — `resetGenerationLock` updates, deletes and audits in three separate transactions

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *More than one write runs inside one `DB::transaction`.* (lowered to M: the writes are a status flip plus a best-effort skeleton purge, not money or marks) |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:760-784`, method `resetGenerationLock()` |
| **Root cause** | `$activeRun->update(...)` writes `tt_generation_runs`, `deleteSkeleton()` opens its own transaction to delete the skeleton, and `activityLog()` writes `sys_activity_logs` — three independent commits. If the purge fails, the run is already FAILED and the audit already claimed a reset. |
| **Consequence** | An operator clicking Reset can leave a FAILED run with the skeleton still present, or a reset audit row for a delete that never happened. |
| **Reproduce** | Static only — requires a mid-method failure, not a deterministic screen. |
| **Fix approach** | Wrap the status update and the `activityLog` in one `DB::transaction`; let the skeleton purge be an explicit after-state (or move it inside the same transaction if the delete is idempotent). |
| **Plan item** | TGC-06 in `02-fix-plan.md` §3 |

```php
            $activeRun->update([
                'status' => 'FAILED',
                'error_message' => 'Manually reset — previous generation was interrupted (likely closed browser).',
                'finished_at' => now(),
            ]);
```

**Evidence**
```
$ sed -n '757,784p' Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
        if ($activeRun) {
            $skeletonTimetableId = $activeRun->timetable_id;

            $activeRun->update([
                'status' => 'FAILED',
                'error_message' => 'Manually reset — previous generation was interrupted (likely closed browser).',
                'finished_at' => now(),
            ]);

            if ($skeletonTimetableId) {
                try {
                    $this->storageService->deleteSkeleton($skeletonTimetableId);
                    $messages[] = "skeleton #{$skeletonTimetableId} dropped";
                } catch (\Throwable $cleanupErr) {
                    \Log::warning('Manual reset: failed to delete skeleton', [
                        'timetable_id' => $skeletonTimetableId,
                        'error' => $cleanupErr->getMessage(),
                    ]);
                    $messages[] = "skeleton #{$skeletonTimetableId} marked FAILED (delete failed: ".$cleanupErr->getMessage().')';
                }
            }

            $messages[] = "run #{$activeRun->id} marked FAILED";

            activityLog($activeRun, 'GenerationReset', [
                'message' => 'A running generation was force-reset and marked FAILED.',
                'actions' => $messages,
            ]);
```

### F3 — Authorization

Every routed method authorizes before it loads a record: `generate` (`:45`), `storeTimetable` (`:188`), `timetableGeneration` (`:331`), `trashedTimetable` (`:441`), `restoreTimetable` (`:463`), `forceDeleteTimetable` (`:507`), `generateWithPrime` (`:550`), `resetGenerationLock` (`:743`), `redirectGeneratePrime` (`:963`). The permission names resolve exactly against `config/permissionslist.php:714`, which declares the key `smart-timetable.timetable` under the `tenant` scope producing `tenant.smart-timetable.timetable.generate|create|delete|viewAny`. Database probe confirms the seeded names (2 roles each). One low finding remains.

#### TGC-21 · L · AUTH-04 — The generate permission is checked twice on the legacy GET path

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *Don't authorize the same permission twice.* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:45` (method `generate()`) and `:550` (method `generateWithPrime()`) |
| **Root cause** | `generate()` authorizes `tenant.smart-timetable.timetable.generate`, then calls `$this->generateWithPrime($request)`, which authorizes the same string again. |
| **Consequence** | One redundant gate check per generation request; no security impact. |
| **Reproduce** | Static only — the doubled call is visible in the wrapper. |
| **Fix approach** | Keep the check in each independently-routed method. Because both methods are routed (POST `generateWithPrime`, GET `generate`), the duplicate is intentional when `generate` is hit directly; record as accepted. |
| **Plan item** | none — see plan §10 |

```php
        Gate::authorize('tenant.smart-timetable.timetable.generate');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
45:        Gate::authorize('tenant.smart-timetable.timetable.generate');
188:        Gate::authorize('tenant.smart-timetable.timetable.create');
331:        Gate::authorize('tenant.smart-timetable.timetable.generate');
441:        Gate::authorize('tenant.smart-timetable.timetable.delete');
463:        Gate::authorize('tenant.smart-timetable.timetable.delete');
507:        Gate::authorize('tenant.smart-timetable.timetable.delete');
550:        Gate::authorize('tenant.smart-timetable.timetable.generate');
743:        Gate::authorize('tenant.smart-timetable.timetable.generate');
963:        Gate::authorize('tenant.smart-timetable.timetable.viewAny');
```

### F4 — Validation and input

#### TGC-07 · M · VAL-02 — Validation is inline in the controller; there is no Form Request

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *Validation lives in a Form Request, not inline `$request->validate()` — except one-field AJAX toggles.* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:190`, method `storeTimetable()`; also `:597`, method `generateWithPrime()` |
| **Root cause** | Both mutating methods call `$request->validate([...])` with 4 and 16 rules respectively. The multi-field generation payload crosses no Form Request boundary, so the `authorize()` hook cannot own the permission and the cross-field rules cannot be tested in isolation. |
| **Consequence** | The permission check and the 16-field rules are duplicated per caller and are re-checked on the legacy GET wrapper; a validation change means editing controller code. |
| **Reproduce** | Static only — the call sites are the only validators for these routes. |
| **Fix approach** | Extract `StoreTimetableRequest` and `GeneratePrimeRequest`, move the rules into `rules()` and the permission into `authorize()`. |
| **Plan item** | TGC-07 in `02-fix-plan.md` §9 (DECISION) |

```php
        $validated = $request->validate([
```

**Evidence**
```
$ grep -n "request()->validate\|->validate(\[" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
190:        $validated = $request->validate([
597:            $validated = $request->validate([
```

### F5 — Routes

#### TGC-08 · B · RTE-02 — A route points at a method that does not exist

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *Every route points to a method that exists.* |
| **Where** | `Modules/SmartTimetable/routes/web.php:63` |
| **Root cause** | The route names `[TimetableGenerationController::class, 'generateForClassSection']`, but the controller has no such method. Nothing in `Modules/`, `resources/` or `routes/` references the route name either. |
| **Consequence** | `/smart-timetable/generate/{class_id}/{section_id}/generate` throws `BadMethodCallException` (a 500) for every visitor; the URL is a dead 500 on the tenant. |
| **Reproduce** | Open `http://test.localhost:8000/smart-timetable/generate/1/1/generate`. Expected a working action or 404; actual 500. |
| **Fix approach** | Remove the dead route, or add a method that redirects (the D5 shape) if the URL must stay. A route change is a DECISION. |
| **Plan item** | TGC-08 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
        Route::get('generate/{class_id}/{section_id}/generate', [TimetableGenerationController::class, 'generateForClassSection'])->name('smart-timetable-management.generate-for-class-section');
```

**Evidence**
```
$ grep -n "generateForClassSection" Modules/SmartTimetable/routes/web.php
63:        Route::get('generate/{class_id}/{section_id}/generate', [TimetableGenerationController::class, 'generateForClassSection'])->name('smart-timetable-management.generate-for-class-section');

$ grep -E 'public function [a-zA-Z_]+' Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
43:    public function generate(Request $request)
186:    public function storeTimetable(Request $request)
329:    public function timetableGeneration()
439:    public function trashedTimetable()
461:    public function restoreTimetable($id)
505:    public function forceDeleteTimetable($id)
548:    public function generateWithPrime(Request $request)
741:    public function resetGenerationLock(Request $request)
961:    public function redirectGeneratePrime()
```

#### TGC-09 · H · RTE-01 — A GET request runs timetable generation and writes rows

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *No state change over GET (`restore`, `delete`, `toggle`, `publish`, `approve`, `sync`, `generate`). GET has no CSRF protection, and link prefetchers trigger it.* |
| **Where** | `Modules/SmartTimetable/routes/web.php:58`, which maps to `TimetableGenerationController@generate` (`TimetableGenerationController.php:43`) |
| **Root cause** | `generate()` is a wrapper that calls `generateWithPrime()`, which creates the skeleton (`tt_timetables`, `tt_generation_runs`, `tt_timetable_cells`) and runs the solver. The route is a `Route::get`. A link prefetcher, an antivirus URL scanner, or a browser refresh can start a generation run. |
| **Consequence** | An unintended GET creates a GENERATING timetable and a RUNNING generation run, consuming the per-tenant lock and CPU, with no CSRF token and no user intent. |
| **Reproduce** | While logged in, open `http://test.localhost:8000/smart-timetable/generate/random` in a new tab; a skeleton timetable appears in the list. |
| **Fix approach** | Make generation POST-only and keep a GET companion that redirects (the pattern already used for `redirectGeneratePrime` and the Python engine). A route-method change is a DECISION. |
| **Plan item** | TGC-09 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
        Route::get('generate/random', [TimetableGenerationController::class, 'generate'])->name('smart-timetable-management.generate');
```

**Evidence**
```
$ grep -n "Route::get('generate/random'\|Route::get('generate/{class_id}" Modules/SmartTimetable/routes/web.php
58:        Route::get('generate/random', [TimetableGenerationController::class, 'generate'])->name('smart-timetable-management.generate');
63:        Route::get('generate/{class_id}/{section_id}/generate', [TimetableGenerationController::class, 'generateForClassSection'])->name('smart-timetable-management.generate-for-class-section');

$ sed -n '43,45p' Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
    public function generate(Request $request)
    {
        Gate::authorize('tenant.smart-timetable.timetable.generate');
```

### F6 — Controller shape

#### TGC-10 · H · CTL-02 — Three methods are far longer than the limit; `generateWithPrime` is 182 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *Method length: over 80 lines → extract; over 150 lines is H.* (raised for the 182-line method) |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:548` (`generateWithPrime`, 548-729, 182 lines); also `:329` (`timetableGeneration`, 105 lines) and `:186` (`storeTimetable`, 102 lines) |
| **Root cause** | `generateWithPrime` holds lock acquisition and stale-lock recovery, validation, period-set resolution, session plumbing, solver invocation, preview view building and the audit call in one body. |
| **Consequence** | A developer cannot see the generation workflow's stages; a failure in any stage is buried in one long method, and any change risks the lock/cleanup paths. |
| **Reproduce** | Static only — method length is a code measurement. |
| **Fix approach** | Defer the split (D3): extract lock handling, skeleton/session handling and view-data building into private methods or the service. A god-controller split is a DECISION. |
| **Plan item** | TGC-10 in `02-fix-plan.md` §9 (DECISION) |

```php
    public function generateWithPrime(Request $request)
    {
```

**Evidence**
```
$ sed -n '548,549p' Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
    public function generateWithPrime(Request $request)
    {

$ awk 'NR>=548 && NR<=729' Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php | wc -l
182
```

#### TGC-11 · M · CTL-10 — Dead private methods and large commented-out blocks

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *No dead code: unused private methods, unused properties, commented-out blocks longer than 3 lines.* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:79`, `:132`, `:160`; commented-out blocks at `:86-124` and `:165-168` |
| **Root cause** | `createConstraintManager()` and `createConstraintManagerFromDatabase()` have no caller; `resolveConstraintClass()` is called only by the dead second method. The commented-out constraint registrations and map entries are retained in-body. |
| **Consequence** | A reader cannot tell which constraint configuration is live; the dead map retains references to classes that are not registered. |
| **Reproduce** | Static only — dead methods. |
| **Fix approach** | Delete the two dead private methods, `resolveConstraintClass` and the commented-out blocks; the constraint classes are owned by ConstraintController and are linked there. |
| **Plan item** | TGC-11 in `02-fix-plan.md` §5 |

```php
    private function createConstraintManager(Collection $activities, Collection $days, Collection $periods): ConstraintManager
    {
```

**Evidence**
```
$ grep -n "createConstraintManager\|resolveConstraintClass" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
79:    private function createConstraintManager(Collection $activities, Collection $days, Collection $periods): ConstraintManager
132:    private function createConstraintManagerFromDatabase(): ConstraintManager
140:            $constraintClass = $this->resolveConstraintClass($constraint->type);
160:    private function resolveConstraintClass(string $type): ?string
```

#### TGC-12 · L · CTL-04 — Public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *Return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`).* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:43` (`generate`), and the same at `:186`, `:329`, `:439`, `:461`, `:505`, `:548`, `:741`, `:961` |
| **Root cause** | None of the nine public methods declares a return type; the class has no `declare(strict_types=1)`. |
| **Consequence** | A method returning an unexpected type (for example `back()` from a `: View`) is not caught by the type system. |
| **Reproduce** | Static only. |
| **Fix approach** | Add return types: `View`, `RedirectResponse` as appropriate; add `declare(strict_types=1)`. |
| **Plan item** | TGC-12 in `02-fix-plan.md` §8 |

```php
    public function generate(Request $request)
    {
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+\(' Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
43:    public function generate(Request $request)
186:    public function storeTimetable(Request $request)
329:    public function timetableGeneration()
...
$ grep -n "strict_types" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
(no output)
```

#### TGC-13 · L · CTL-08 — The `request()` helper is used instead of an injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *Inject `Request`; don't call the `request()` helper inside controller methods.* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:333` (method `timetableGeneration()`); also `:443` (method `trashedTimetable()`) |
| **Root cause** | `timetableGeneration()` and `trashedTimetable()` have no `Request` parameter and reach for the global helper. |
| **Consequence** | The dependency is hidden; the methods cannot be unit-called with a controlled request. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `Request $request` to both signatures and use it. |
| **Plan item** | TGC-13 in `02-fix-plan.md` §8 |

```php
        $r = request();
```

**Evidence**
```
$ grep -n "= request()" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
333:        $r = request();
443:        $r = request();
```

### F7 — Models

#### TGC-20 · L · STY-01 — GenerationRun has no strict types and a PHP 8.4 implicit-nullable parameter

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched).* Also PHP 8.4 deprecates implicitly nullable parameters. |
| **Where** | `Modules/SmartTimetable/app/Models/GenerationRun.php:227`, method `markFailed()`; the file has no `declare(strict_types=1)` |
| **Root cause** | `public function markFailed(string $errorMessage = null): void` declares a parameter as nullable implicitly. The project runs PHP 8.5, where this emits a deprecation. `HasFactory` is imported but the trait is not used in either model. |
| **Consequence** | Deprecation notices on every call; the unused import is noise. No functional impact. |
| **Reproduce** | Static only. |
| **Fix approach** | Change to `?string $errorMessage = null`; remove the unused `HasFactory` import; add strict types when the file is next touched. |
| **Plan item** | TGC-20 in `02-fix-plan.md` §8 |

```php
    public function markFailed(string $errorMessage = null): void
```

**Evidence**
```
$ grep -n "HasFactory\|strict_types\|string \$errorMessage = null" Modules/SmartTimetable/app/Models/GenerationRun.php Modules/SmartTimetable/app/Models/ConflictDetection.php
Modules/SmartTimetable/app/Models/GenerationRun.php:7:use Illuminate\Database\Eloquent\Factories\HasFactory;
Modules/SmartTimetable/app/Models/GenerationRun.php:227:    public function markFailed(string $errorMessage = null): void
Modules/SmartTimetable/app/Models/ConflictDetection.php:6:use Illuminate\Database\Eloquent\Factories\HasFactory;
```

The two models are otherwise clean: `$fillable` declared, `$casts` cover every boolean/date/decimal/json column, `SoftDeletes` matches the `deleted_at` column in `2026_06_16_152635_create_tt_generation_run_table.php:48` and `2026_06_16_152633_create_tt_conflict_detection_table.php:25`, and `$table` exists (`tt_generation_runs`, `tt_conflict_detection`).

### F8 — Services and jobs

#### TGC-14 · H · SVC-03 — Generation rewrites teacher assignments on the so-called preview path

| Field | Value |
|---|---|
| **Rule** | SVC-03 (H) — *No writes on read paths: no `updateOrCreate`/`firstOrCreate`/seeding inside methods called by GET pages or lookups.* |
| **Where** | `Modules/SmartTimetable/app/Services/TimetableGenerationService.php:59`, method `generate()` |
| **Root cause** | Before the solver runs, `generate()` calls `(new ClassTeacherAutoAssigner)->assignAllForTerm(...)`, which mutates `tt_activity_teachers` — replacing existing primary teachers. `generate()` is reached from the controller's GET `generate/random` route and from the preview page's re-generate modal. |
| **Consequence** | Merely opening the generation URL can rewrite the school's teacher assignments, even though the user never saves the timetable; the change is idempotent but not reversible. |
| **Reproduce** | While logged in, open `http://test.localhost:8000/smart-timetable/generate/random`; the activity teacher assignments are rewritten before any timetable is saved. |
| **Fix approach** | Move the auto-assign out of the read/preview path into an explicit action the user triggers, or gate it behind a keep/confirm step. The comment records a 2026-05-02 decision to auto-run; a behaviour change is a DECISION. |
| **Plan item** | none — see plan §10 |

```php
        $autoAssignSummary = (new ClassTeacherAutoAssigner)
            ->assignAllForTerm((int) $validated['academic_term_id']);
```

**Evidence**
```
$ sed -n '51,60p' Modules/SmartTimetable/app/Services/TimetableGenerationService.php
        // Step 0: Class-teacher auto-assignment.
        // For every class-section with a class teacher, ensure she is the primary
        // teacher on a 6-9 weekly-period combination of subjects she's capable of.
        // Mutates tt_activity_teachers BEFORE the activity load so the solver sees
        // the corrected assignments. Idempotent — re-running is safe.
        // Decided 2026-05-02: auto-run during generation, replace existing primary
        // teachers, accept partial coverage (<6) with warning, accept overflow (>9)
        // when a single subject already exceeds the cap.
        $autoAssignSummary = (new ClassTeacherAutoAssigner)
            ->assignAllForTerm((int) $validated['academic_term_id']);
```

#### TGC-15 · M · SVC-04 — Two generation implementations that must stay in step

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *One implementation per business operation. Three copies of "assign students" that disagree = bug source.* (here: two copies of "generate a timetable") |
| **Where** | `Modules/SmartTimetable/app/Jobs/GenerateTimetableJob.php:31`, versus `TimetableGenerationService::generate()` called by the controller at `TimetableGenerationController.php:675` |
| **Root cause** | The synchronous web path calls `TimetableGenerationService::generate()`; the API path (`Modules/SmartTimetable/app/Http/Controllers/Api/TimetableApiController.php:139`) dispatches `GenerateTimetableJob`, which rebuilds `PrimeSolver` itself and re-implements constraint loading and room allocation. |
| **Consequence** | A fix to solver inputs, teacher locks or room allocation in one path does not reach the other; `GenerateTimetableJob.php:53-64` and `TimetableGenerationService` already resolve the period set differently. |
| **Reproduce** | Static only — comparing the two entry points. |
| **Fix approach** | Have `GenerateTimetableJob` call the same service entry point (loading only the tenant context and ids), so one implementation serves web and API. |
| **Plan item** | none — see plan §10 |

```php
    public function __construct(
        protected int $runId,
        protected array $config,
        protected int $userId,
        protected ?string $tenantId = null,
    ) {}
```

**Evidence**
```
$ grep -rn "GenerateTimetableJob" app/ Modules/ | grep -v "class GenerateTimetableJob"
Modules/SmartTimetable/app/Http/Controllers/Api/TimetableApiController.php:139:                \Modules\SmartTimetable\Jobs\GenerateTimetableJob::dispatch(
```

#### TGC-16 · M · SVC-02 — Services reached by `app()`/`new` instead of constructor injection

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *Dependencies arrive by constructor injection — not `new FooService()` or `app(Foo::class)` mid-method.* |
| **Where** | `Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php:759`; also `Modules/SmartTimetable/app/Services/TimetableGenerationService.php:59` and `:268` |
| **Root cause** | `TimetableStorageService::rebuildAvailabilityCanvas()` calls `app(AvailabilityCanvasService::class)` mid-method; `TimetableGenerationService` instantiates `new ClassTeacherAutoAssigner` and `new ActivityLockService` inline instead of taking them as constructor dependencies. |
| **Consequence** | The dependencies cannot be substituted in a test, and the class's real collaborators are invisible from the constructor. |
| **Reproduce** | Static only. |
| **Fix approach** | Inject the collaborators through the constructors. Note the project forbids testing in this workflow (D4), so this is a maintainability change only. |
| **Plan item** | none — see plan §10 |

```php
        $canvas = app(AvailabilityCanvasService::class);
```

**Evidence**
```
$ grep -n "app(AvailabilityCanvasService" Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php
759:        $canvas = app(AvailabilityCanvasService::class);

$ grep -n "new ClassTeacherAutoAssigner\|new PrimeSolver\|new ActivityLockService" Modules/SmartTimetable/app/Services/TimetableGenerationService.php
59:        $autoAssignSummary = (new ClassTeacherAutoAssigner)
268:        $lockService = new ActivityLockService;
277:        $solver = new PrimeSolver($days, $periods, $constraintManager, [
```

### F9 — Queries and performance

#### TGC-17 · H · QRY-02 — The Generation History list is not paginated

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H) — *Lists are paginated. No `Model::all()` or unbounded `->get()` feeding a list page.* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:380-384`, method `timetableGeneration()` |
| **Root cause** | `GenerationRun::with(['timetable', 'triggeredBy'])->...->get()` loads every run for the tenant into the "Timetable History" tab. The adjacent Timetable list correctly uses `paginate(10, ['*'], 'tt_page')`. |
| **Consequence** | On a school with years of generation history every page load grows without bound and can time out; the tab is the default-selectable third tab. |
| **Reproduce** | Open `/smart-timetable/timetable-generation?tab=generation-history`; the query has no `LIMIT`. |
| **Fix approach** | Add `->paginate(10, ['*'], 'gr_page')->withQueryString()` and a paginator in the history partial. |
| **Plan item** | TGC-17 in `02-fix-plan.md` §6 |

```php
        $generationRuns = GenerationRun::with(['timetable', 'triggeredBy'])
            ->when($r->filled('gr_status'), fn ($q) => $q->where('status', $r->input('gr_status')))
            ->when($r->filled('gr_timetable_id'), fn ($q) => $q->where('timetable_id', $r->input('gr_timetable_id')))
            ->latest('started_at')
            ->get();
```

**Evidence**
```
$ sed -n '380,384p' Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
        $generationRuns = GenerationRun::with(['timetable', 'triggeredBy'])
            ->when($r->filled('gr_status'), fn ($q) => $q->where('status', $r->input('gr_status')))
            ->when($r->filled('gr_timetable_id'), fn ($q) => $q->where('timetable_id', $r->input('gr_timetable_id')))
            ->latest('started_at')
            ->get();
```

#### TGC-18 · M · QRY-07 — Save writes one `UPDATE` per cell in a loop

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *Bulk writes. `insert()`, `upsert()`, `whereIn(...)->update()` instead of `create()`/`update()` per row in a loop.* |
| **Where** | `Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php:596-598`, method `populateFromResult()` |
| **Root cause** | Every placed cell is flushed with its own `UPDATE tt_timetable_cells` inside a `foreach`; skeleton inserts and teacher pivots are already chunked, but this loop is not. |
| **Consequence** | A few thousand placements mean a few thousand round trips inside the save transaction, lengthening the lock and the request. |
| **Reproduce** | Static only — the loop is the save path. |
| **Fix approach** | Batch the updates (an `upsert()` keyed on `id`, or grouped `CASE` statements). This is a mechanical performance item but touches the shared storage service, so it is recorded here for a dedicated pass. |
| **Plan item** | none — see plan §10 |

```php
            foreach ($cellUpdates as $cellId => $payload) {
                DB::table('tt_timetable_cells')->where('id', $cellId)->update($payload);
            }
```

**Evidence**
```
$ sed -n '595,598p' Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php
            // Flush cell updates (one UPDATE per row — small N, low cost; bulk-update needs CASE expr)
            foreach ($cellUpdates as $cellId => $payload) {
                DB::table('tt_timetable_cells')->where('id', $cellId)->update($payload);
            }
```

### F10 — Views

clean — `grep -nE "Model::|DB::|->where\(|->get\(\)|->count\(\)" Modules/SmartTimetable/resources/views/smart-timetable/generation.blade.php Modules/SmartTimetable/resources/views/smart-timetable/trash.blade.php` → no output. `grep -c "{!!" Modules/SmartTimetable/resources/views/preview/index.blade.php` → `0`. Both small views gate their includes with `@can` on the same permission names used by the controller (`smart-timetable/generation.blade.php:31,34,37`), and `trash.blade.php:72` uses the standard `x-backend.table.action-trashed` row action.

### F11 — Security and tenancy

clean — `grep -n "env(" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php` → no output (SEC-01); the generation lock key is tenant-keyed (TEN-02): `TimetableGenerationController.php:552` and `:745` build `'timetable-gen-'.tenant('id')`, and `Cache::lock` is used with a 300s TTL. No hard-coded ids (`?? 1`) and no request-body logging were found. Tenant context is established globally by `app/Providers/TenancyServiceProvider.php:245` (`InitializeTenancyByDomain`).

### F12 — Style

#### TGC-19 · L · STY-01/STY-06/STY-04 — Missing strict types, mixed `\Log::`, emoji and commented-out code

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) strict types; STY-06 (L) one style per concern; STY-04 (L) no emoji markers, no commented-out code |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:1` (no `declare(strict_types=1)`); `\Log::` at `:279`, `:575`, `:715`, `:771`, `:807`, `:954` while `Log` is imported at `:11`; emoji comments at `:405`, `:862`, `:888`; commented-out blocks at `:86-124`, `:165-168` |
| **Root cause** | Mixed conventions in one file. |
| **Consequence** | Pint/consistency debt only; no runtime impact. |
| **Reproduce** | Static only. |
| **Fix approach** | One style item for the file: add strict types, use the imported `Log` facade, remove emoji markers and commented-out code. |
| **Plan item** | TGC-19 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SmartTimetable\Http\Controllers;
```

**Evidence**
```
$ grep -n '\\Log::' Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
279:            \Log::error('Timetable populate-and-publish failed', [
575:                        \Log::warning('Failed to delete stale skeleton; falling back to FAILED mark', [
715:            \Log::error('Prime Generation Error', [
771:                    \Log::warning('Manual reset: failed to delete skeleton', [
807:            \Log::warning('Skeleton cleanup failed', [
954:                \Log::warning('ConflictDetection persist failed — timetable was saved successfully', [
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutating method | Q1 wrong data | Q2 delete-before-replace | Q3 duplicate impl | Q4 soft-delete unique | Q5 race | Q6 auth hole | Q7 lying message | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `generate` → `generateWithPrime` | TGC-14 (rewrites `tt_activity_teachers`) | ok | TGC-15 | ok (run number uses `withTrashed()->max()`) | TGC-06 (lock force-release) | ok | ok | ok |
| `storeTimetable` | ok (updates only the named fields) | ok | ok | ok | TGC-02 | ok | TGC-01 (raw message) | ok |
| `restoreTimetable` | ok | ok | ok | `onlyTrashed()` correct | ok | ok | ok | ok |
| `forceDeleteTimetable` | ok | `purgeChildrenOf()` runs before `forceDelete()` (TXN-03-safe) | ok | ok | ok | ok | ok | ok |
| `resetGenerationLock` | ok | deletes skeleton after marking FAILED | ok | ok | TGC-06 (forceRelease races a live run) | ok | message says "lock released" even when none held | ok |
| `persistConflictDetection` | ok | ok | ok | ok | ok | ok | TGC-04 (claims success on failure) | ok |

**Q5 race, expanded:** `resetGenerationLock` calls `Cache::lock($lockKey)->forceRelease()` unconditionally, even while another request genuinely holds the lock and is solving. A second generate can then start concurrently with the first, writing two skeletons for the same scope. This is recorded inside TGC-06.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/TimetableFoundation/app/Models/Timetable.php` | Audited by `tarun/SmartTimetable/AnalyticsController`; linked, not re-audited. Usage here (status/name/effective dates, `findOrFail`, `queueSnapshotRefresh`) is consistent with its `$fillable`. | — | AnalyticsController report |
| `Modules/SmartTimetable/app/Services/Constraints/ConstraintManager.php` and `Hard/{ShortBreak,LunchBreak}Constraint.php` | Reached only from the dead private methods TGC-11 removes. Owned by ConstraintController. | CTL-10 | ConstraintController report |
| `Modules/SmartTimetable/app/Services/AvailabilityCanvasService.php` | Reached from `TimetableStorageService::rebuildAvailabilityCanvas()` via `app()`. Not claimed by any report; its internal logic is out of this report's line-audit. | SVC-02 | first controller that reaches it |
| `Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php` | Owned by TimetablePublishController; linked. | — | TimetablePublishController report |

## 8. Not covered, and why

- **Queue runtime.** `GenerateTimetableJob` was read and its `$tries`/`$timeout`/tenant handling checked, but it was **not executed** (D4 forbids running the queue). Its agent-context behaviour at runtime is unverified.
- **`TimetableGenerationService.php` (3,287 lines).** Only the reachable entry (`generate()` and its Step-0 auto-assign) was audited. Its ~35 private helpers (capacity audits, placement units, class-teacher override) were not line-audited; they are reachable only through `generate()`.
- **`TimetableStorageService.php` and `PreviewGridState.php` / `PreviewDerivedData.php`.** The methods the controller calls (`createSkeleton`, `populateFromResult`, `finalizeGenerated`, `deleteSkeleton`, `purgeChildrenOf`) were audited; the remaining internals and the whole `PreviewGridState` (940 lines) were not line-audited.
- **Browser rendering.** The `preview/index.blade.php` Vue island (3,311 lines) was checked statically for queries and `{!! !!}` only; it was not rendered in a browser.
- **Live reproduction.** The `test.localhost` tenant has zero timetable rows, so every failure that needs a live run is marked "static only".
