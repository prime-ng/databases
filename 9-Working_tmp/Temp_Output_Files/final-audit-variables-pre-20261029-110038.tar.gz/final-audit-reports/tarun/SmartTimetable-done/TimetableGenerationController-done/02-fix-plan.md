# Fix Plan — SmartTimetable / TimetableGenerationController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php` | a route file — touched only by the TGC-08 and TGC-09 DECISION items if ticked |
| `Modules/SmartTimetable/app/Models/Timetable.php` | owned by another report (AnalyticsController) |
| `Modules/SmartTimetable/app/Services/Constraints/ConstraintManager.php` and `Constraints/Hard/*` | owned by ConstraintController |
| `Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php` | owned by TimetablePublishController |
| `Modules/SmartTimetable/app/Services/TimetableGenerationService.php` | not touched by this plan — its findings are DECISION/§10 only |
| `Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php` | not touched by this plan — its findings are §10 only |
| `database/migrations/**` | migrations are never edited |
| `config/permissionslist.php` | shared config; no new key is needed by this plan |

## 1. Blockers reachable today

- [x] **TGC-01** · B · ERR-01 · `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:271-286` — stop echoing the raw exception text to the user on all five save/restore/delete/generate paths.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Before** (`TimetableGenerationController.php:271-286`):
    ```php
        } catch (\RuntimeException $e) {
            // Business-rule violation from finalizeGenerated (e.g. status mismatch).
            // Skeleton may already be partly populated — leave for user to retry or regen.
            return back()->with('error', $e->getMessage());
        } catch (\Throwable $e) {
            // Hard failure mid-populate — drop the skeleton (per delete-on-failure policy)
            // and force user to regenerate.
            $this->safelyDeleteSkeleton(['timetable_id' => $timetableId]);
            \Log::error('Timetable populate-and-publish failed', [
                'timetable_id' => $timetableId,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->with('error', 'Save failed: '.$e->getMessage());
        }
    ```
  - **After:**
    ```php
        } catch (\RuntimeException $e) {
            report($e);

            return back()->with('error', 'This timetable could not be saved because it is not in the right state. Refresh the page and try again.');
        } catch (\Throwable $e) {
            $this->safelyDeleteSkeleton(['timetable_id' => $timetableId]);
            report($e);

            return back()->with('error', 'Save failed. The error has been logged.');
        }
    ```
  - The same change applies to these blocks (each `catch` keeps its surrounding code):
  - **Before** (`TimetableGenerationController.php:482-491`):
    ```php
        } catch (\Throwable $e) {
            Log::error('Timetable restore failed', [
                'timetable_id' => $id,
                'error' => $e->getMessage(),
            ]);

            return redirect()
                ->route('smart-timetable.timetable.trashed')
                ->with('error', 'Failed to restore timetable: '.$e->getMessage());
        }
    ```
  - **After:**
    ```php
        } catch (\Throwable $e) {
            report($e);

            return redirect()
                ->route('smart-timetable.timetable.trashed')
                ->with('error', 'Failed to restore the timetable. The error has been logged.');
        }
    ```
  - **Before** (`TimetableGenerationController.php:529-538`):
    ```php
        } catch (\Throwable $e) {
            Log::error('Timetable force-delete failed', [
                'timetable_id' => $timetableId,
                'error' => $e->getMessage(),
            ]);

            return redirect()
                ->route('smart-timetable.timetable.trashed')
                ->with('error', 'Failed to permanently delete timetable: '.$e->getMessage());
        }
    ```
  - **After:**
    ```php
        } catch (\Throwable $e) {
            report($e);

            return redirect()
                ->route('smart-timetable.timetable.trashed')
                ->with('error', 'Failed to permanently delete the timetable. The error has been logged.');
        }
    ```
  - **Before** (`TimetableGenerationController.php:713-725`):
    ```php
        } catch (\Exception $e) {
            $this->safelyDeleteSkeleton($skeletonIds);
            \Log::error('Prime Generation Error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'academic_term_id' => $request->input('academic_term_id'),
                'timetable_type_id' => $request->input('timetable_type_id'),
                'user_id' => auth()->id(),
            ]);

            return back()
                ->with('error', 'Timetable generation failed: '.$e->getMessage())
                ->withInput();
    ```
  - **After:**
    ```php
        } catch (\Exception $e) {
            $this->safelyDeleteSkeleton($skeletonIds);
            report($e);

            return back()
                ->with('error', 'Timetable generation failed. The error has been logged.')
                ->withInput();
        }
    ```
  - **Before** (`TimetableGenerationController.php:770-776`):
    ```php
                } catch (\Throwable $cleanupErr) {
                    \Log::warning('Manual reset: failed to delete skeleton', [
                        'timetable_id' => $skeletonTimetableId,
                        'error' => $cleanupErr->getMessage(),
                    ]);
                    $messages[] = "skeleton #{$skeletonTimetableId} marked FAILED (delete failed: ".$cleanupErr->getMessage().')';
                }
    ```
  - **After:**
    ```php
                } catch (\Throwable $cleanupErr) {
                    report($cleanupErr);
                    $messages[] = "skeleton #{$skeletonTimetableId} marked FAILED (skeleton delete failed; the error has been logged)";
                }
    ```
  - **Verify:** `grep -n "getMessage()" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Expect:** the only remaining `getMessage()` hits are the two logged warnings handled by TGC-03 (`:575`, `:807`); no `getMessage()` remains in a `with('error', ...)` or `with('success', ...)`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

- [x] **TGC-04** · M · ERR-06 · `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:953-958` — surface a lost conflict-detection record instead of reporting success.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Before** (`TimetableGenerationController.php:953-958`):
    ```php
        } catch (\Throwable $e) {
            \Log::warning('ConflictDetection persist failed — timetable was saved successfully', [
                'timetable_id' => $timetable->id,
                'error' => $e->getMessage(),
            ]);
        }
    ```
  - **After:**
    ```php
        } catch (\Throwable $e) {
            report($e);
            session()->flash('warning', 'The conflict-detection record could not be saved. The timetable itself was saved.');
        }
    ```
  - **Verify:** `grep -n "ConflictDetection persist failed" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Expect:** no output.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [ ] **TGC-02** · H · ERR-02 · `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:211-225` — resolve the timetable before the try so a deleted row gives a 404.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Before** (`TimetableGenerationController.php:210-212`):
    ```php

        try {
            $result = $this->reconstructGenerationResult();
    ```
  - **After:**
    ```php
        $timetable = Timetable::findOrFail($timetableId);

        try {
            $result = $this->reconstructGenerationResult();
    ```
  - **Before** (`TimetableGenerationController.php:225-226`):
    ```php
            $timetable = Timetable::findOrFail($timetableId);
            $this->persistConflictDetection(
    ```
  - **After:**
    ```php
            $this->persistConflictDetection(
    ```
  - **Verify:** `grep -n "findOrFail" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Expect:** `225` is gone; `findOrFail($timetableId)` now appears before the `try` (around line 210), and `:468`, `:510` remain.
  - **Effort:** S

- [x] **TGC-03** · M · ERR-05 · `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:575` and `:807` — log the exception object, not just its message, in the two best-effort warnings.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Before** (`TimetableGenerationController.php:575-578`):
    ```php
                        \Log::warning('Failed to delete stale skeleton; falling back to FAILED mark', [
                            'timetable_id' => $activeRun->timetable_id,
                            'error' => $cleanupErr->getMessage(),
                        ]);
    ```
  - **After:**
    ```php
                        Log::warning('Failed to delete stale skeleton; falling back to FAILED mark', [
                            'timetable_id' => $activeRun->timetable_id,
                            'exception' => $cleanupErr,
                        ]);
    ```
  - **Before** (`TimetableGenerationController.php:807-810`):
    ```php
            \Log::warning('Skeleton cleanup failed', [
                'timetable_id' => $skeletonIds['timetable_id'],
                'error' => $e->getMessage(),
            ]);
    ```
  - **After:**
    ```php
            Log::warning('Skeleton cleanup failed', [
                'timetable_id' => $skeletonIds['timetable_id'],
                'exception' => $e,
            ]);
    ```
  - **Verify:** `grep -n "'error' => \$e->getMessage()" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **TGC-06** · M · TXN-01 · `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:757-784` — make the reset write, skeleton purge and audit one transaction.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Before** (`TimetableGenerationController.php:757-784`):
    ```php
        if ($activeRun) {
            $skeletonTimetableId = $activeRun->timetable_id;

            $activeRun->update([
                'status' => 'FAILED',
                'error_message' => 'Manually reset — previous generation was interrupted (likely closed browser).',
                'finished_at' => now(),
            ]);

            if ($skeletonTimetableId) {
                try {
                    $this->storageService->deleteSkeleton($skeletonTimetableId);
                    $messages[] = "skeleton #{$skeletonTimetableId} dropped";
                } catch (\Throwable $cleanupErr) {
                    \Log::warning('Manual reset: failed to delete skeleton', [
                        'timetable_id' => $skeletonTimetableId,
                        'error' => $cleanupErr->getMessage(),
                    ]);
                    $messages[] = "skeleton #{$skeletonTimetableId} marked FAILED (delete failed: ".$cleanupErr->getMessage().')';
                }
            }

            $messages[] = "run #{$activeRun->id} marked FAILED";

            activityLog($activeRun, 'GenerationReset', [
                'message' => 'A running generation was force-reset and marked FAILED.',
                'actions' => $messages,
            ]);
    ```
  - **After:**
    ```php
        if ($activeRun) {
            $skeletonTimetableId = $activeRun->timetable_id;

            DB::transaction(function () use ($activeRun, $skeletonTimetableId, &$messages) {
                $activeRun->update([
                    'status' => 'FAILED',
                    'error_message' => 'Manually reset — previous generation was interrupted (likely closed browser).',
                    'finished_at' => now(),
                ]);

                if ($skeletonTimetableId) {
                    try {
                        $this->storageService->deleteSkeleton($skeletonTimetableId);
                        $messages[] = "skeleton #{$skeletonTimetableId} dropped";
                    } catch (\Throwable $cleanupErr) {
                        report($cleanupErr);
                        $messages[] = "skeleton #{$skeletonTimetableId} marked FAILED (skeleton delete failed; the error has been logged)";
                    }
                }

                $messages[] = "run #{$activeRun->id} marked FAILED";

                activityLog($activeRun, 'GenerationReset', [
                    'message' => 'A running generation was force-reset and marked FAILED.',
                    'actions' => $messages,
                ]);
            });
    ```
  - **Verify:** `grep -n "DB::transaction\|GenerationReset" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Expect:** `DB::transaction(function () use ($activeRun, $skeletonTimetableId, &$messages)` immediately precedes the `GenerationReset` log.
  - **Effort:** M

## 4. Authorization (F3)

No item — the only authorization finding (TGC-21) is accepted; see §10.

## 5. Validation, routes, models (F4/F5/F7)

- [x] **TGC-11** · M · CTL-10 · `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:79-172` — delete the two dead constraint-manager factories, the unused `resolveConstraintClass`, and the commented-out blocks.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Before** (`TimetableGenerationController.php:79-81`):
    ```php
    private function createConstraintManager(Collection $activities, Collection $days, Collection $periods): ConstraintManager
    {
        $constraintManager = new ConstraintManager;
    ```
  - **After:** the whole span `79-172` (the `createConstraintManager()` method, the `createConstraintManagerFromDatabase()` method, and the `resolveConstraintClass()` method, with their commented-out blocks) is deleted. Nothing replaces it. The file then runs from the closing brace of `generate()` straight into the `storeTimetable()` docblock.
    ```php
    ```
  - The `use` imports that only these methods referenced (`Illuminate\Database\Eloquent\Collection`, `Modules\SmartTimetable\Services\Constraints\ConstraintManager`, `Modules\SmartTimetable\Services\Constraints\Hard\LunchBreakConstraint`, `Modules\SmartTimetable\Services\Constraints\Hard\ShortBreakConstraint`) are also removed if the file no longer names them.
  - **Verify:** `grep -n "createConstraintManager\|resolveConstraintClass\|ConstraintManager\|ShortBreakConstraint" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

No item — TGC-17 is a DECISION (§9) and TGC-18 is §10.

## 7. Views (F10)

No item — F10 is clean.

## 8. Style (F12) — one item per file

- [x] **TGC-12** · L · CTL-04 · `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:12` and `:43` — add return types to the seven methods that TGC-13 does not already rewrite.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Before** (`TimetableGenerationController.php:12`):
    ```php
    use Illuminate\Validation\ValidationException;
    ```
  - **After:**
    ```php
    use Illuminate\Validation\ValidationException;
    use Illuminate\View\View;
    use Illuminate\Http\RedirectResponse;
    ```
  - The method signatures become:
    ```php
    public function generate(Request $request): View|RedirectResponse
    public function storeTimetable(Request $request): RedirectResponse
    public function restoreTimetable($id): RedirectResponse
    public function forceDeleteTimetable($id): RedirectResponse
    public function generateWithPrime(Request $request): View|RedirectResponse
    public function resetGenerationLock(Request $request): RedirectResponse
    public function redirectGeneratePrime(): RedirectResponse
    ```
  - `timetableGeneration()` and `trashedTimetable()` are left to TGC-13, which rewrites their signatures.
  - **Verify:** `grep -nE "public function (generate|storeTimetable|restoreTimetable|forceDeleteTimetable|generateWithPrime|resetGenerationLock|redirectGeneratePrime)\(" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Expect:** each of the seven lines ends with `: View|RedirectResponse` or `: RedirectResponse`.
  - **Effort:** S

- [x] **TGC-13** · L · CTL-08 · `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:329` and `:439` — inject `Request` into the two page methods instead of calling the helper.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Before** (`TimetableGenerationController.php:329-333`):
    ```php
    public function timetableGeneration()
    {
        Gate::authorize('tenant.smart-timetable.timetable.generate');

        $r = request();
    ```
  - **After:**
    ```php
    public function timetableGeneration(Request $request): View
    {
        Gate::authorize('tenant.smart-timetable.timetable.generate');

        $r = $request;
    ```
  - **Before** (`TimetableGenerationController.php:439-443`):
    ```php
    public function trashedTimetable()
    {
        Gate::authorize('tenant.smart-timetable.timetable.delete');

        $r = request();
    ```
  - **After:**
    ```php
    public function trashedTimetable(Request $request): View
    {
        Gate::authorize('tenant.smart-timetable.timetable.delete');

        $r = $request;
    ```
  - **Verify:** `grep -n "= request()" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **TGC-19** · L · STY-01/STY-06/STY-04 · `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php:1` — the file-level style pass.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Before** (`TimetableGenerationController.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - Also, in the same file: replace every remaining `\Log::` with the imported `Log::` (`:575` and `:807` are already changed by TGC-03; no other `\Log::` should remain), and remove the emoji markers in the comments at `:405`, `:862`, `:888` (strip the leading marker character, keep the words).
  - **Verify:** `grep -n '\\Log::' Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **TGC-20** · L · STY-01 · `Modules/SmartTimetable/app/Models/GenerationRun.php:227` — fix the implicit-nullable parameter and the unused imports.
  - **Touches:** `Modules/SmartTimetable/app/Models/GenerationRun.php`, `Modules/SmartTimetable/app/Models/ConflictDetection.php`
  - **Before** (`GenerationRun.php:227`):
    ```php
    public function markFailed(string $errorMessage = null): void
    ```
  - **After:**
    ```php
    public function markFailed(?string $errorMessage = null): void
    ```
  - In `GenerationRun.php` remove the unused line `use Illuminate\Database\Eloquent\Factories\HasFactory;` (the trait is not used). In `ConflictDetection.php` remove the same unused import. Add `declare(strict_types=1);` after the opening `<?php` in both models.
  - **Verify:** `grep -n "HasFactory" Modules/SmartTimetable/app/Models/GenerationRun.php Modules/SmartTimetable/app/Models/ConflictDetection.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **TGC-07** · M · DECISION · VAL-02 — move validation into Form Requests?
  - **Why it is a decision:** it adds two new classes and changes where the permission is checked.
  - (a) ⭐ Extract `StoreTimetableRequest` (4 rules) and `GeneratePrimeRequest` (16 rules), move `authorize()` to `tenant.smart-timetable.timetable.create` and `.generate`, and change the two methods to `$request->validated()`.
  - (b) Leave the inline validation; record it as accepted debt.
  - (c) Extract only `GeneratePrimeRequest`, leave `storeTimetable` inline.
  - ➜ Choice: moot — R5 (2026-10-16) retired storeTimetable and generateWithPrime, the only inline validators

- [x] **TGC-08** · B · DECISION · RTE-02 — the route to `generateForClassSection` has no method. ⚠ SHARED (route file)
  - **Why it is a decision:** it adds or removes a route, and route changes need an explicit choice.
  - (a) ⭐ Delete the dead route line `Modules/SmartTimetable/routes/web.php:63`; nothing references the route name (`grep -rn "generate-for-class-section" Modules resources routes` finds only this line).
  - (b) Keep the URL and add a `generateForClassSection(Request $request)` method that redirects to the generation page (the D5/`redirectGeneratePrime` shape).
  - (c) Leave it; the URL stays a 500.
  - ➜ Choice: (a) applied as part of R5 — generate-for-class-section route removed 2026-10-16

- [x] **TGC-09** · H · DECISION · RTE-01 — generation is reachable over GET. ⚠ SHARED (route file)
  - **Why it is a decision:** it changes a route verb and the front-end caller.
  - (a) ⭐ Change `Modules/SmartTimetable/routes/web.php:58` to a GET companion that redirects (the route name `smart-timetable-management.generate` stays on the POST), matching the `redirectGeneratePrime` pattern.
  - (b) Keep the GET, and add a confirmation step in the controller before the skeleton is created.
  - (c) Leave it; record the state-change-over-GET as accepted.
  - ➜ Choice: R5 (2026-10-16) — all 6 PHP-engine generation routes retired instead; methods are abort(403) stubs (D5)

- [x] **TGC-10** · H · DECISION · CTL-02 — `generateWithPrime()` is 182 lines. ⚠ SHARED only if the split moves code to a service
  - **Why it is a decision:** a controller split is deferred by D3.
  - (a) ⭐ Defer the split to the structured split pass (D3); apply the TGC-01/02/03/06 fixes here first.
  - (b) Extract lock handling, skeleton/session handling and view-data building into private methods now.
  - (c) Leave as is; record as accepted.
  - ➜ Choice: (a) defer to the split pass (D3); method is now an R5 stub

- [x] **TGC-17** · H · DECISION · QRY-02 — the Generation History list is unbounded.
  - **Why it is a decision:** the history blade computes its KPI tiles and trend chart from the full `$generationRuns` collection, so a plain `paginate()` breaks the tiles; the fix needs an aggregate query and a partial rework.
  - (a) ⭐ Keep a full-run aggregate query for the tiles (`$generationRuns->count()`, `->where(...)` moved to SQL) and paginate only the table with its own query and page name.
  - (b) Cap the list with `->limit(200)` and keep the tiles on the same capped set; accept that older runs are hidden.
  - (c) Leave unbounded; record as accepted until the tenant history grows.
  - ➜ Choice: (a) — applied 2026-10-16: paginate(10,'gr_page') + SQL-aggregated generationRunStats

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TGC-05 | The audit call must move inside `TimetableStorageService::finalizeGenerated()`'s transaction; that is a change to a large shared service, deferred to its own pass. The order it currently uses (write in service, `activityLog` after) is otherwise correct. |
| TGC-14 | The class-teacher auto-assign write on the generation path is a documented 2026-05-02 product decision ("auto-run during generation, replace existing primary teachers"). Changing it is a behaviour decision, not a mechanical fix. |
| TGC-15 | The duplicate generation implementation (synchronous web path versus `GenerateTimetableJob` on the API path) needs one of the two to delegate to the other; recorded for a dedicated service pass because it touches the job and the API controller. |
| TGC-16 | `app()`/`new` service location in `TimetableStorageService` and `TimetableGenerationService`; both are large shared services, deferred to their owning pass. |
| TGC-18 | The per-cell `UPDATE` loop in `TimetableStorageService::populateFromResult()` is marked deliberate in the code ("small N, low cost"); batching it is a performance item for the storage service's own pass. |
| TGC-21 | The doubled `Gate::authorize` is intentional: `generate()` and `generateWithPrime()` are both independently routable, so each must carry its own check. Accepted. |
