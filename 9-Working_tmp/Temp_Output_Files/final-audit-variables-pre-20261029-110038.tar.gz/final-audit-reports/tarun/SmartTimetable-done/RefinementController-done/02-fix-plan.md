# Fix Plan — SmartTimetable / RefinementController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php` | route file — no item changes a route |
| `Modules/TimetableFoundation/app/Models/TimetableCell.php` | owned by `tarun/TimetableFoundation/TimetableController` |
| `Modules/SmartTimetable/app/Models/TimetableCell.php` | alias owned by `tarun/SmartTimetable/TimetableExportController` |
| `Modules/TimetableFoundation/app/Models/TimetableCellTeacher.php` | owned by the TimetableFoundation report (cross-cutting note only) |
| `config/permissionslist.php` | shared permission config; both permission keys already exist |
| `final-audit-reports/00-CLASS-OWNERS.md` | append-only registry (this report already claimed `RefinementService`) |

## 1. Blockers reachable today

- [x] **RFN-07** · B · DEEP-01 · `Modules/SmartTimetable/app/Services/RefinementService.php:42-43, 60-61, 109` — supply `assignment_role_id` to every cell-teacher `sync()` so the pivot INSERT stops throwing.
  - **Touches:** `Modules/SmartTimetable/app/Services/RefinementService.php`
  - **Before** (`RefinementService.php:42-43`):
    ```php
            $tempTeachers1 = $cell1->teachers->pluck('id')->toArray();
            $tempTeachers2 = $cell2->teachers->pluck('id')->toArray();
    ```
  - **After:**
    ```php
            $tempTeachers1 = $cell1->teachers->mapWithKeys(fn ($t) => [$t->id => [
                'assignment_role_id' => $t->pivot->assignment_role_id,
                'is_substitute' => (bool) $t->pivot->is_substitute,
            ]])->all();
            $tempTeachers2 = $cell2->teachers->mapWithKeys(fn ($t) => [$t->id => [
                'assignment_role_id' => $t->pivot->assignment_role_id,
                'is_substitute' => (bool) $t->pivot->is_substitute,
            ]])->all();
    ```
  - **Before** (`RefinementService.php:109`):
    ```php
                $targetCell->teachers()->sync($cell->teachers->pluck('id')->toArray());
    ```
  - **After:**
    ```php
                $targetCell->teachers()->sync(
                    $cell->teachers->mapWithKeys(fn ($t) => [$t->id => [
                        'assignment_role_id' => $t->pivot->assignment_role_id,
                        'is_substitute' => (bool) $t->pivot->is_substitute,
                    ]])->all()
                );
    ```
  - **Verify:** `grep -n "pluck('id')->toArray()" Modules/SmartTimetable/app/Services/RefinementService.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **RFN-12** · B · DEEP-01 · `Modules/SmartTimetable/app/Services/RefinementService.php` (5 `source` writes) — ADDED DURING THE FIX 2026-10-16, missed by the audit. `swapActivities()` wrote `source = 'MANUAL_SWAP'` and `moveActivity()` wrote `'MANUAL_MOVE'` into `enum('AUTO','MANUAL','SWAP','LOCK')` (DDL v7.8 line 1441 agrees), so every swap and move raised SQL 1265 before reaching the RFN-07 sync.
  - **Touches:** `Modules/SmartTimetable/app/Services/RefinementService.php`
  - **After:** swap writes `'SWAP'`, move writes `'MANUAL'` (the same value `TimetablePreviewController::moveCell()` writes).
  - **Verify:** `grep -n "MANUAL_SWAP\|MANUAL_MOVE" Modules/SmartTimetable/app/Services/RefinementService.php` — only the RFN-12 comments.
  - ➜ Choice: fix with SWAP / MANUAL (Tarun, 2026-10-16)

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [x] **RFN-01** · H · ERR-02 · `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php:105-131` — remove the `toggleLock` try/catch (D1) and move validation before the transaction so a 422 stays a 422.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php`
  - **Before** (`RefinementController.php:105-131`):
    ```php
            try {
                return DB::transaction(function () use ($request) {
                    $validated = $request->validate([
                        'cell_id' => 'required|integer|exists:tt_timetable_cells,id',
                        'lock' => 'required|boolean',
                    ]);

                    $result = $validated['lock']
                        ? $this->refinementService->lockCell($validated['cell_id'])
                        : $this->refinementService->unlockCell($validated['cell_id']);

                    return response()->json($result);

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('RefinementController::toggleLock failed', ['error' => $e->getMessage()]);

                // AJAX endpoint — the caller reads JSON.
                return response()->json([
                    'success' => false,
                    'message' => 'The operation could not be completed.',
                ], 500);
            }
    ```
  - **After:**
    ```php
            $validated = $request->validate([
                'cell_id' => 'required|integer|exists:tt_timetable_cells,id',
                'lock' => 'required|boolean',
            ]);

            $result = DB::transaction(function () use ($validated) {
                return $validated['lock']
                    ? $this->refinementService->lockCell($validated['cell_id'])
                    : $this->refinementService->unlockCell($validated['cell_id']);
            });

            return response()->json($result);
    ```
  - **Verify:** `grep -n "try {\|catch (" Modules/SmartTimetable/app/Http/Controllers/RefinementController.php`
  - **Expect:** no output.
  - **Effort:** M

- [x] **RFN-02** · M · ERR-00 · `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php:32-49, 71-89` — remove the controller try/catch from `swap` and `move` (D1); keep the response tail.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php`
  - **Before** (`RefinementController.php:32-49`):
    ```php
            try {
                // Rules A2/A3 are inside RefinementService::swapActivities(), which owns the
                // transaction and now writes its SWAP audit entries inside it (§6/§4). A refusal —
                // locked cell, cross-timetable, conflict — returns success:false and writes
                // nothing, so it logs nothing.
                $result = $this->refinementService->swapActivities($validated['cell_id_1'], $validated['cell_id_2']);
            } catch (\Throwable $e) {
                Log::error('RefinementController::swap failed', [
                    'cells' => [$validated['cell_id_1'], $validated['cell_id_2']],
                    'error' => $e->getMessage(),
                ]);

                if ($request->expectsJson()) {
                    return response()->json(['success' => false, 'message' => 'The swap could not be completed.'], 500);
                }

                return back()->with('error', 'The swap could not be completed.');
            }
    ```
  - **After:**
    ```php
            $result = $this->refinementService->swapActivities($validated['cell_id_1'], $validated['cell_id_2']);
    ```
  - **Before** (`RefinementController.php:71-89`):
    ```php
            try {
                // See swap(): rules A2/A3 belong to RefinementService::moveActivity().
                $result = $this->refinementService->moveActivity(
                    $validated['cell_id'],
                    $validated['day_id'],
                    $validated['period_ord']
                );
            } catch (\Throwable $e) {
                Log::error('RefinementController::move failed', [
                    'cell_id' => $validated['cell_id'],
                    'error'   => $e->getMessage(),
                ]);

                if ($request->expectsJson()) {
                    return response()->json(['success' => false, 'message' => 'The move could not be completed.'], 500);
                }

                return back()->with('error', 'The move could not be completed.');
            }
    ```
  - **After:**
    ```php
            $result = $this->refinementService->moveActivity(
                $validated['cell_id'],
                $validated['day_id'],
                $validated['period_ord']
            );
    ```
  - **Verify:** `grep -n "catch (" Modules/SmartTimetable/app/Http/Controllers/RefinementController.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

None — every permission string already exists and is seeded.

## 5. Validation, routes, models (F4/F5/F7)

- [x] **RFN-06** · L · CTL-04 · `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php:23, 61, 101, 137, 149` — declare the response return type on the five public methods.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php`
  - **Before** (`RefinementController.php:23`):
    ```php
        public function swap(Request $request)
    ```
  - **After:**
    ```php
        public function swap(Request $request): \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
    ```
  - **Before** (`RefinementController.php:61`):
    ```php
        public function move(Request $request)
    ```
  - **After:**
    ```php
        public function move(Request $request): \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
    ```
  - **Before** (`RefinementController.php:101`):
    ```php
        public function toggleLock(Request $request)
    ```
  - **After:**
    ```php
        public function toggleLock(Request $request): \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
    ```
  - **Before** (`RefinementController.php:137`):
    ```php
        public function candidates(int $cellId)
    ```
  - **After:**
    ```php
        public function candidates(int $cellId): \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
    ```
  - **Before** (`RefinementController.php:149`):
    ```php
        public function impact(Request $request, int $cellId)
    ```
  - **After:**
    ```php
        public function impact(Request $request, int $cellId): \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse
    ```
  - **Verify:** `grep -nE "public function (swap|move|toggleLock|candidates|impact)\(" Modules/SmartTimetable/app/Http/Controllers/RefinementController.php`
  - **Expect:** five lines, each ending with a return type.
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **RFN-08** · H · QRY-01 · `Modules/SmartTimetable/app/Services/RefinementService.php:226-237, 291-304, 306-318` — replace the per-teacher loops with one join query each.
  - **Touches:** `Modules/SmartTimetable/app/Services/RefinementService.php`
  - **Before** (`RefinementService.php:226-237`):
    ```php
            // Check teacher conflicts at new slot
            foreach ($cell->teachers as $teacher) {
                $conflict = TimetableCell::where('timetable_id', $cell->timetable_id)
                    ->where('day_of_week', $newDayId)
                    ->where('period_ord', $newPeriodOrd)
                    ->where('is_active', true)
                    ->whereHas('teachers', fn($q) => $q->where('teacher_id', $teacher->id))
                    ->exists();

                if ($conflict) {
                    return ['valid' => false, 'reason' => "Teacher {$teacher->id} has a conflict at the target slot."];
                }
            }
    ```
  - **After:**
    ```php
            // Check teacher conflicts at new slot
            $teacherIds = $cell->teachers->pluck('id')->all();

            if ($teacherIds !== []) {
                $conflictingTeacherId = DB::table('tt_timetable_cells as c')
                    ->join('tt_timetable_cell_teachers as ct', 'ct.cell_id', '=', 'c.id')
                    ->where('c.timetable_id', $cell->timetable_id)
                    ->where('c.day_of_week', $newDayId)
                    ->where('c.period_ord', $newPeriodOrd)
                    ->where('c.is_active', true)
                    ->whereIn('ct.teacher_id', $teacherIds)
                    ->value('ct.teacher_id');

                if ($conflictingTeacherId !== null) {
                    return ['valid' => false, 'reason' => "Teacher {$conflictingTeacherId} has a conflict at the target slot."];
                }
            }
    ```
  - **Before** (`RefinementService.php:291-304`):
    ```php
            // Check teacher conflicts after swap
            foreach ($cell2->teachers as $teacher) {
                $conflict = TimetableCell::where('timetable_id', $cell1->timetable_id)
                    ->where('day_of_week', $cell1->day_of_week)
                    ->where('period_ord', $cell1->period_ord)
                    ->where('id', '!=', $cell1->id)
                    ->where('is_active', true)
                    ->whereHas('teachers', fn($q) => $q->where('teacher_id', $teacher->id))
                    ->exists();

                if ($conflict) {
                    return ['valid' => false, 'reason' => "Teacher conflict at cell 1 position after swap."];
                }
            }
    ```
  - **After:**
    ```php
            // Check teacher conflicts after swap
            $cell2TeacherIds = $cell2->teachers->pluck('id')->all();

            if ($cell2TeacherIds !== []) {
                $conflictCell1 = DB::table('tt_timetable_cells as c')
                    ->join('tt_timetable_cell_teachers as ct', 'ct.cell_id', '=', 'c.id')
                    ->where('c.timetable_id', $cell1->timetable_id)
                    ->where('c.day_of_week', $cell1->day_of_week)
                    ->where('c.period_ord', $cell1->period_ord)
                    ->where('c.id', '!=', $cell1->id)
                    ->where('c.is_active', true)
                    ->whereIn('ct.teacher_id', $cell2TeacherIds)
                    ->exists();

                if ($conflictCell1) {
                    return ['valid' => false, 'reason' => 'Teacher conflict at cell 1 position after swap.'];
                }
            }
    ```
  - **Before** (`RefinementService.php:306-318`):
    ```php
            foreach ($cell1->teachers as $teacher) {
                $conflict = TimetableCell::where('timetable_id', $cell2->timetable_id)
                    ->where('day_of_week', $cell2->day_of_week)
                    ->where('period_ord', $cell2->period_ord)
                    ->where('id', '!=', $cell2->id)
                    ->where('is_active', true)
                    ->whereHas('teachers', fn($q) => $q->where('teacher_id', $teacher->id))
                    ->exists();

                if ($conflict) {
                    return ['valid' => false, 'reason' => "Teacher conflict at cell 2 position after swap."];
                }
            }
    ```
  - **After:**
    ```php
            $cell1TeacherIds = $cell1->teachers->pluck('id')->all();

            if ($cell1TeacherIds !== []) {
                $conflictCell2 = DB::table('tt_timetable_cells as c')
                    ->join('tt_timetable_cell_teachers as ct', 'ct.cell_id', '=', 'c.id')
                    ->where('c.timetable_id', $cell2->timetable_id)
                    ->where('c.day_of_week', $cell2->day_of_week)
                    ->where('c.period_ord', $cell2->period_ord)
                    ->where('c.id', '!=', $cell2->id)
                    ->where('c.is_active', true)
                    ->whereIn('ct.teacher_id', $cell1TeacherIds)
                    ->exists();

                if ($conflictCell2) {
                    return ['valid' => false, 'reason' => 'Teacher conflict at cell 2 position after swap.'];
                }
            }
    ```
  - **Verify:** `grep -n "foreach" Modules/SmartTimetable/app/Services/RefinementService.php`
  - **Expect:** no output.
  - **Effort:** M

- [x] **RFN-09** · M · QRY-02 · `Modules/SmartTimetable/app/Services/RefinementService.php:193-199` — cap the candidate list.
  - **Touches:** `Modules/SmartTimetable/app/Services/RefinementService.php`
  - **Before** (`RefinementService.php:193-199`):
    ```php
            $candidates = TimetableCell::where('timetable_id', $cell->timetable_id)
                ->where('id', '!=', $cellId)
                ->where('is_locked', false)
                ->where('is_active', true)
                ->whereNotNull('activity_id')
                ->with(['activity.subject', 'teachers'])
                ->get();
    ```
  - **After:**
    ```php
            $candidates = TimetableCell::where('timetable_id', $cell->timetable_id)
                ->where('id', '!=', $cellId)
                ->where('is_locked', false)
                ->where('is_active', true)
                ->whereNotNull('activity_id')
                ->with(['activity.subject', 'teachers'])
                ->limit(200)
                ->get();
    ```
  - **Verify:** `grep -n "limit(200)" Modules/SmartTimetable/app/Services/RefinementService.php`
  - **Expect:** one line.
  - **Effort:** S

## 7. Views (F10)

None — the controller renders no view.

## 8. Style (F12) — one item per file

- [x] **RFN-10** · L · STY-01 · `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php:1-14` — add `declare(strict_types=1)` and sort the imports (Pint-clean; no unused imports removed, so it is safe regardless of which other items are ticked).
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php`
  - **Before** (`RefinementController.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **Before** (`RefinementController.php:5-14`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;

    use Illuminate\Support\Facades\Log;

    use Illuminate\Support\Facades\DB;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\SmartTimetable\Services\RefinementService;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\SmartTimetable\Services\RefinementService;
    ```
  - **Verify:** `grep -n "declare(strict_types" Modules/SmartTimetable/app/Http/Controllers/RefinementController.php`
  - **Expect:** `2:declare(strict_types=1);`
  - **Effort:** S

- [x] **RFN-11** · L · STY-01 · `Modules/SmartTimetable/app/Services/RefinementService.php:1-7` — add `declare(strict_types=1)` and drop the unused `Log` import.
  - **Touches:** `Modules/SmartTimetable/app/Services/RefinementService.php`
  - **Before** (`RefinementService.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Services;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Services;
    ```
  - **Before** (`RefinementService.php:5-7`):
    ```php
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Log;
    use Modules\TimetableFoundation\Models\TimetableCell;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Facades\DB;
    use Modules\TimetableFoundation\Models\TimetableCell;
    ```
  - **Verify:** `grep -n "declare(strict_types\|Log" Modules/SmartTimetable/app/Services/RefinementService.php`
  - **Expect:** only `2:declare(strict_types=1);`
  - **Effort:** S

## 9. Deferred / decisions

- [x] **RFN-04** · M · DECISION · TXN-06 — `move`/`swap` validate the target before opening the transaction. Fix the race or accept it?
  - **Why it is a decision:** a proper fix changes the read/write sequencing (load the cells with `lockForUpdate()` inside the transaction and re-run the checks), which is a behaviour change on an interactive screen.
  - (a) ⭐ accept for now — the refinement workspace is used by one timetabler at a time; record the risk and add a one-line code comment naming RFN-04.
  - (b) fix now — move the empty/conflict checks inside a `lockForUpdate()` transaction in `moveActivity()` and `swapActivities()`.
  - (c) guard with a unique index on the target slot instead of a lock (needs a migration — Tarun's hand).
  - ➜ Choice: (a) accept for now — RFN-04 comment added on swap()/move() (Tarun, 2026-10-16)

- [x] **RFN-05** · M · DECISION · VAL-02 — the three POST endpoints validate inline instead of in Form Requests. Extract them?
  - **Why it is a decision:** extracting Form Requests also moves the gate into `authorize()`, changing the authorization flow, and this controller's write methods are being rewritten by RFN-01/RFN-02.
  - (a) ⭐ record the inline rules as accepted for these small AJAX endpoints; `swap`/`move`/`toggleLock` keep `$request->validate()`.
  - (b) extract `RefinementSwapRequest`, `RefinementMoveRequest`, `RefinementLockRequest` now, moving each `Gate::authorize` into the request's `authorize()`.
  - (c) extract only `RefinementMoveRequest` (the one with the untyped `day_id`/`period_ord`).
  - ➜ Choice: (a) keep inline validation, recorded as accepted (Tarun, 2026-10-16)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| RFN-03 | covered by **RFN-01**: removing the try/catch and moving the response out of the `DB::transaction` closure (the RFN-01 After) is exactly this fix. |
