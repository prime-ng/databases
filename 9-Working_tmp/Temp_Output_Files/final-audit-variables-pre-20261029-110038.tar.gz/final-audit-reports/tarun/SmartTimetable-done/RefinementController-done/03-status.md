# Status — SmartTimetable / RefinementController

**Fixed:** 2026-10-16 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
none. The only PRE-APPLIED file (`tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md`) lists no file in this controller's scope.

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| RFN-07 | `RefinementService.php:45-46, 112, 349` | All three cell-teacher `sync()` calls now go through a new `teacherPivotPayload()` helper. It carries each teacher's `assignment_role_id` (NOT NULL, no default) and `is_substitute`. This is the plan's `mapWithKeys` After, written once instead of three times. | `grep -n "pluck('id')->toArray()" RefinementService.php` | no output | 2026-10-16 |
| RFN-12 (added) | `RefinementService.php:52, 59, 110, 119, 127` | **Found while proving RFN-07; the audit missed it.** `source` changed from `'MANUAL_SWAP'` to `'SWAP'`, and from `'MANUAL_MOVE'` to `'MANUAL'`. The column is `enum('AUTO','LOCK','MANUAL','SWAP')`, which matches DDL v7.8:1441, so every swap and move used to raise SQL 1265 before reaching the sync. The fix matches `TimetablePreviewController::moveCell()`. Tarun chose this option on 2026-10-16. | `grep -n "MANUAL_SWAP\|MANUAL_MOVE" RefinementService.php` | only the 5 RFN-12 comments | 2026-10-16 |
| RFN-01 | `RefinementController.php:88-106` | `toggleLock`: validation moved before the transaction, so a bad payload stays a 422. The transaction now returns only the service result. The JSON response is built outside it. The try/catch is removed (D1). This also closes RFN-03. | `grep -nE "try \{\|catch \(" RefinementController.php` | no code matches (2 docblock words) | 2026-10-16 |
| RFN-02 | `RefinementController.php:31-50, 57-79` | `swap` and `move`: the try/catch is removed (D1). The service call and the response tail are kept. | same grep | no code matches | 2026-10-16 |
| RFN-06 | `RefinementController.php:31, 57, 88, 112, 124` | All five public methods now declare `JsonResponse\|RedirectResponse`, as the plan specifies. The types are imported rather than written as FQCNs, because Pint would shorten them anyway. | `grep -nE "public function (swap\|move\|toggleLock\|candidates\|impact)\(" …` | 5 lines, all typed | 2026-10-16 |
| RFN-08 | `RefinementService.php:230-246, 303-337` | Replaced the three per-teacher `whereHas` loops with one `tt_timetable_cells ⋈ tt_timetable_cell_teachers` query each (`value()` / `exists()`). Messages are unchanged. | `grep -n "foreach" RefinementService.php` | no output | 2026-10-16 |
| RFN-09 | `RefinementService.php:202` | The swap-candidate query is capped with `->limit(200)`. | `grep -n "limit(200)" …` | `202:` | 2026-10-16 |
| RFN-10 | `RefinementController.php:3-13` | Added `declare(strict_types=1)` and sorted the imports. `ModelNotFoundException` and `Log` were dropped because nothing used them once RFN-01 and RFN-02 landed. **Added casts that strict_types requires:** `(int)` on the five validated ids passed to the `int`-typed service methods, and `(string)` on `impact()`'s `action` input. | `grep -n "declare(strict_types" …` | `3:` | 2026-10-16 |
| RFN-11 | `RefinementService.php:3-7` | Added `declare(strict_types=1)` and removed the unused `Log` import. Typed internal calls were audited and every one already receives ints (`logChange`, `validateMove`, `captureState`). | `grep -n "declare(strict_types\|Facades\\\\Log" …` | `3:` only | 2026-10-16 |
| RFN-04 | `RefinementController.php:27-29, 55` | DECISION (a): the risk is accepted, and a one-line comment naming RFN-04 is on `swap()`, with a back-reference on `move()`. | `grep -n "RFN-04" …` | 2 lines | 2026-10-16 |
| RFN-05 | `RefinementController.php` (each validate call) | DECISION (a): inline validation is kept and recorded as accepted, with an `RFN-05` comment above each of the three `validate()` calls. | `grep -c "RFN-05" …` | 3 | 2026-10-16 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| RFN-03 | covered by RFN-01 (plan §10) | Removing the catch and moving the response out of the transaction closure is exactly this fix. |

## 4. Needs Tarun's hand
- A browser check on `/smart-timetable/view-and-refinement?tab=timetable-view`: swap two cells, move a lesson into an empty slot, and lock and unlock a cell. **Swap and move have never worked on this screen before**, because two independent SQL errors (RFN-07 and RFN-12) blocked both.
- Nothing needs to be migrated, seeded or synced.

## 5. Unverifiable by this workflow (no tests, D4)
- **`moveActivity()`'s write path was not executed.** The swap path was proven end to end (below). Move shares the `teacherPivotPayload()` helper and the RFN-12 value change, but its target-cell and direct-update branches only received a static check.
- The central handler's rendering of a failure (it replaces the removed controller catch) was not exercised.
- RFN-04 remains a real but accepted race. No test proves or disproves it.

## 6. Verification log
```
php -l RefinementController.php / RefinementService.php     -> No syntax errors detected x2 (before AND after Pint)
vendor/bin/pint <2 files> --format agent                    -> service reformatted (6 fixers), controller clean; re-run: passed
class_exists(RefinementController, RefinementService)       -> true, true
router probe (method_exists per routed action)              -> swap OK · move OK · toggleLock OK · candidates OK · impact OK
plan greps                                                  -> all as in §2

Rolled-back proof (tenant test.localhost, DB::beginTransaction ... rollBack):
  before RFN-12: swap(7,621) THREW SQLSTATE 1265 Data truncated for column 'source'
  after  RFN-12: swap(7,621) -> {"success":true,"message":"Cells swapped successfully."}
                 pivot rows rewritten with assignment_role_id=1 (no SQL 1364)
  conflict path: swap(7,9)   -> {"success":false,"message":"Teacher conflict at cell 1 position after swap."}  (RFN-08 join query)
  getSwapCandidates(7)       -> 200 rows (RFN-09 cap)
  rolled back — tenant unchanged
```

## 7. Final state
Status: FIXED · Open: B 0 · H 0 · M 2 (RFN-04, RFN-05 — both accepted by decision) · L 0
