# Final Audit — SmartTimetable / TimetablePageController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php` (1073 lines, 6 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/constraints`, `.../smart-timetable/timetable-config`, `.../smart-timetable/timetable-opration` (note the route spelling, mapped to method `timetableOperation`), `.../smart-timetable/timetable-master`, `.../smart-timetable/timetable-reports` |
| Menu path | Smart Timetable module tabs: Constraint Management, Timetable Config, Timetable Operation, Timetable Master, Timetable Reports (`glb_menus` rows in `TimetableMenuController`). |
| Who uses it | Roles holding each permission, measured in `sys_role_has_permissions_jnt` on the tenant DB: **Super Admin** and **School Admin** for all four page permissions (`constraint.viewAny` id 1674, `config.viewAny` id 1698, `timetable.viewAny` id 1642, `report.viewAny` id 1705; 2 role rows each). |
| What a user does here | Reads five management/reporting pages. Constraint Management shows six category tabs of constraint records plus an activity summary. Timetable Config shows configuration records, academic terms, sessions and generation strategies. Timetable Operation groups activities into shared/normal buckets and shows subject groups, requirements, slot availabilities and teacher availability. Timetable Master lists working days, shifts, period sets, non-availability records, assignment roles, timetable types and teachers with workload buckets. Timetable Reports shows timetable summaries, teacher load, room utilization, class coverage and activity capacity for a chosen timetable. None of it writes. |
| Tables written | none — this controller never INSERT/UPDATE/DELETEs. |
| Tables read | `tt_constraints`, `tt_constraint_types`, `tt_constraint_category_scopes`, `tt_activities`, `tt_teacher_availabilities`, `tt_requirement_consolidations`, `tt_slot_requirements`, `tt_timetables`, `tt_timetable_cells`, `tt_timetable_cell_teachers`, `tt_configs`, `tt_period_sets`, `tt_periods`, `tt_school_days`, `tt_shifts`, plus the SchoolSetup master tables (`sch_classes`, `sch_sections`, `sch_teachers`, `sch_subjects`, `sch_rooms`) and `sys_users`. |
| Live data | tenant `xyz_school_00000000000040008000_202627`: `tt_constraints` 6, `tt_constraint_types` 10, `tt_activities` 0, `tt_teacher_availabilities` 0, `tt_timetables` 0, `tt_timetable_cells` 0, `sch_teachers` 89. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This is a read-only page controller, and its authorization is correct: all five routed methods call `Gate::authorize` before touching a record, and all four permission names exist in `config/permissionslist.php` and are seeded to exactly Super Admin and School Admin. It is **not production-ready**: two routed pages crash with a 500. The single worst finding is TPC-01: the import at line 39 points at `Modules\TimetableFoundation\Models\TeacherAvailablity`, a class that does not exist (the class was renamed to `TeacherAvailability` and only a misspelled alias was left behind), so `timetableOperation()` dies on a `Class not found` error before rendering — every visit to the Operation page is a 500 for both roles. TPC-02 is nearly as bad: the Timetable Config page renders a Blade that `@include`s two views that do not exist, so it throws `View not found` for the same two roles. Beyond the two blockers the controller is clean but heavy: three methods over 150 lines, a duplicated `AcademicSession::current()` lookup, and several unbounded `->get()` loads. Rough effort for the full plan: **M** (a day), mostly because TPC-02 needs a product decision about what the two missing tabs should show.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 1 | 6 | 4 | 4 | 13 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean (none used) |
| F2 Transactions/Audit | clean (read-only) | F9 Queries/Perf | TPC-09, TPC-10, TPC-11 |
| F3 Authorization | TPC-07 | F10 Views | TPC-02 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | TPC-13 (folded into TPC-13) |
| F6 Controller shape | TPC-03, TPC-04, TPC-05, TPC-06, TPC-08, TPC-12 | F13 Deep read | clean (no mutations) |
| F7 Models | TPC-01, TPC-13 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php` | controller | 1073 | this report | ✅ |
| 2 | `Modules/SmartTimetable/app/Models/TeacherAvailablity.php` | model (pre-assigned) | 11 | this report | ✅ |
| 3 | `Modules/SmartTimetable/resources/views/constraint-management/index.blade.php` | blade | 45 | this report | ✅ |
| 4 | `Modules/SmartTimetable/resources/views/index.blade.php` | blade | 26 | this report | ✅ (TPC-02) |
| 5 | `Modules/SmartTimetable/resources/views/smart-timetable/master.blade.php` | blade | 67 | this report | ✅ |
| 6 | `Modules/SmartTimetable/resources/views/smart-timetable/operation.blade.php` | blade | 34 | this report | ✅ |
| 7 | `Modules/SmartTimetable/resources/views/smart-timetable/reports.blade.php` | blade | 279 | this report | ✅ |
| 8 | `Modules/SmartTimetable/resources/views/constraint-management/partials/*/_list.blade.php` (8 files) | blade | 1185 | this report | ✅ |
| 9 | `Modules/SmartTimetable/resources/views/smart-timetable/partials/{school-days,shifts,day-types,working-days,period-types,period-set,period-set-period,teacher-unavailable,academic-term,room-unavailable,teacher-assignment-role,timetable-type,teacher}/_list.blade.php` (13 files) | blade | 3744 | this report | ✅ |
| 10 | `Modules/SmartTimetable/resources/views/smart-timetable/partials/{subject-group-subject,class-subject-requirement,requirement-consolidation,teacher-availability,activity}/_list.blade.php` (5 files) | blade | 2456 | this report | ✅ |
| 11 | `Modules/SmartTimetable/resources/views/smart-timetable/partials/reports/_*.blade.php` (6 files) | blade | 540 | this report | ✅ |
| 12 | `Modules/SmartTimetable/app/Models/Timetable.php` | model | 11 | ↗ [AnalyticsController](../AnalyticsController-done/01-report.md) | ↗ linked |
| 13 | `Modules/SmartTimetable/app/Models/Constraint.php` + `ConstraintCategoryScope.php` | model | — | ↗ [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked |
| 14 | `Modules/SmartTimetable/app/Models/ConstraintType.php` | model | — | ↗ [ConstraintTypeController](../ConstraintTypeController-done/01-report.md) | ↗ linked |
| 15 | `Modules/SmartTimetable/app/Models/TeacherUnavailable.php` | model | — | ↗ [TeacherUnavailableController](../TeacherUnavailableController-done/01-report.md) | ↗ linked |
| 16 | `Modules/SmartTimetable/app/Models/RoomUnavailable.php` | model | — | ↗ [RoomUnavailableController](../RoomUnavailableController-done/01-report.md) | ↗ linked |
| 17 | `Modules/SmartTimetable/app/Models/TtGenerationStrategy.php` + `Activity.php` | model | — | ↗ [TtGenerationStrategyController](../TtGenerationStrategyController-done/01-report.md) | ↗ linked |
| 18 | `Modules/SmartTimetable/app/Models/SchoolDay.php` + `PeriodSetPeriod.php` + `TimetableCell.php` | model | — | ↗ [TimetableExportController](../TimetableExportController-done/01-report.md) | ↗ linked |
| 19 | `Modules/TimetableFoundation/app/Models/{AcademicTerm,Activity,ClassSubjectGroup,ClassSubjectSubgroup,ClassTimetableType,Config,DayType,PeriodSet,PeriodType,RequirementConsolidation,SchoolShift,TeacherAssignmentRole,Timetable,TimetableType,WorkingDay,TeacherAvailability}.php` | models | — | ↗ [TimetableFoundation/…Controller](../../TimetableFoundation-done/00-INDEX.md) reports | ↗ linked |

SchoolSetup models (`Room`, `SchClassGroupsJnt`, `SchoolClass`, `Subject`, `SubjectGroup`, `Teacher`, `OrganizationAcademicSession`) and `Modules\Prime\Models\AcademicSession` (used by 46 controllers) are common classes — referenced, not audited here (§4.2).

No in-scope file appears in a module `PRE-APPLIED-*.md`.

## 4. Routes

```
GET|HEAD smart-timetable/constraints                                  smart-timetable.constraint-management.index Modules\SmartTimetable\Http\Controllers\TimetablePageController@constraintManagement
GET|HEAD smart-timetable/timetable-config                             smart-timetable.timetable.timetableConfig   Modules\SmartTimetable\Http\Controllers\TimetablePageController@timetableConfig
GET|HEAD smart-timetable/timetable-master                             smart-timetable.timetable.timetableMaster   Modules\SmartTimetable\Http\Controllers\TimetablePageController@timetableMaster
GET|HEAD smart-timetable/timetable-opration                           smart-timetable.timetable.timetableOperation Modules\SmartTimetable\Http\Controllers\TimetablePageController@timetableOperation
GET|HEAD smart-timetable/timetable-reports                            smart-timetable.timetable.timetableReports  Modules\SmartTimetable\Http\Controllers\TimetablePageController@timetableReports
```

From an uncached route list (`APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json`). Every route sits inside the `['web', 'auth', 'verified', EnsureTenantHasModule::class.':smart-timetable']` group (`Modules/SmartTimetable/routes/web.php`).

Unrouted public methods: `timetableValidation()` (`TimetablePageController.php:1067`) — unrouted and intentionally disabled per D5 (`abort(403)` with a `NOT ROUTED` comment). Not a finding.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `constraintManagement` | 50 | GET /smart-timetable/constraints | `tenant.smart-timetable.constraint.viewAny` | none — read-only | none | none | TPC-07, TPC-08, TPC-11 |
| `timetableConfig` | 111 | GET /smart-timetable/timetable-config | `tenant.smart-timetable.config.viewAny` | none — read-only | none | none | TPC-02, TPC-05 |
| `timetableOperation` | 137 | GET /smart-timetable/timetable-opration | `tenant.smart-timetable.timetable.viewAny` | none — read-only | none | none | TPC-01, TPC-04, TPC-05, TPC-06, TPC-08, TPC-09, TPC-10, TPC-11 |
| `timetableMaster` | 520 | GET /smart-timetable/timetable-master | `tenant.smart-timetable.timetable.viewAny` | none — read-only | none | none | TPC-04, TPC-05, TPC-06, TPC-08, TPC-11 |
| `timetableReports` | 713 | GET /smart-timetable/timetable-reports | `tenant.smart-timetable.report.viewAny` | none — read-only | none | none | TPC-04, TPC-05, TPC-09, TPC-11, TPC-12 |
| `timetableValidation` | 1067 | not routed (D5) | none | none | none | none | — |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try|catch|getMessage|RuntimeException' Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php` → no output (exit 1).

### F2 — Transactions and audit

clean — the controller has no write path. `grep -nE '->create|->update|->delete|->save|DB::transaction|activityLog|insert\(' Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php` → no output (exit 1).

### F3 — Authorization

#### TPC-07 · M · AUTH-06 — the four page permissions are string literals repeated five times

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy or constants — not repeated as literals in every method* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:52,113,139,522,715` |
| **Root cause** | `Gate::authorize` is called with a fresh string literal at all five call sites (`constraint.viewAny`, `config.viewAny`, `timetable.viewAny` twice, `report.viewAny`) instead of a class constant. |
| **Consequence** | A renamed permission means editing five call sites, and one typo turns a whole page into a 403 for School Admin while Super Admin keeps working. |
| **Reproduce** | Static only — rename the string at line 139 and re-open the Operation page. |
| **Fix approach** | Declare four private class constants on the controller and use them in the five `Gate::authorize()` calls. |
| **Plan item** | TPC-07 in `02-fix-plan.md` §4 |

```php
// TimetablePageController.php:52 — the same literal pattern repeats at 113, 139, 522, 715
        Gate::authorize('tenant.smart-timetable.constraint.viewAny');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
52:        Gate::authorize('tenant.smart-timetable.constraint.viewAny');
113:        Gate::authorize('tenant.smart-timetable.config.viewAny');
139:        Gate::authorize('tenant.smart-timetable.timetable.viewAny');
522:        Gate::authorize('tenant.smart-timetable.timetable.viewAny');
715:        Gate::authorize('tenant.smart-timetable.report.viewAny');
```

### F4 — Validation and input

clean — every method reads query parameters only on GET pages; there is no input that reaches a model.

### F5 — Routes

clean — all route targets exist (`method_exists` verified through the route list); every route is GET with no state change; `timetableValidation()` follows D5 (`abort(403)`). `grep -nE 'Route::(post|put|patch|delete)' Modules/SmartTimetable/routes/web.php` shows no write verb pointing at this controller.

### F6 — Controller shape

#### TPC-03 · M · CTL-01 — 1073-line controller with six public methods

| Field | Value |
|---|---|
| **Rule** | CTL-01 (M, raised to the top of the deferred queue because it is a page controller) — *over 1,000 lines or 25 methods → split by resource* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:44` |
| **Root cause** | Five independent report pages (constraints, config, operation, master, reports) live in one controller; each page loads a different cluster of models and partials. |
| **Consequence** | One change to the teacher table in one page requires scrolling past 1000+ lines; the shared `TeacherAvailablity` import bug (TPC-01) breaks Operation without any obvious link to the config pages. |
| **Reproduce** | Static only — `wc -l` on the file. |
| **Fix approach** | Defer to the god-controller split pass (D3). Decision TPC-03 in `02-fix-plan.md` §9. |
| **Plan item** | TPC-03 in `02-fix-plan.md` §9 |

```php
// TimetablePageController.php:44
class TimetablePageController extends Controller
```

**Evidence**
```
$ wc -l Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
1073 Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
$ php final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
M  CTL-01   Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:44  TimetablePageController: 1030 lines, 6 public methods
```

#### TPC-04 · H · CTL-02 — three methods exceed 150 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — *method length: over 150 lines is H* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:137-515` (`timetableOperation`), `520-708` (`timetableMaster`), `713-1062` (`timetableReports`) |
| **Root cause** | Each page loads its entire dataset in one method: Operation 379 lines, Master 189 lines, Reports 350 lines. |
| **Consequence** | The methods cannot be reviewed or tested as units; the TPC-01 crash hides inside a 379-line method. |
| **Reproduce** | Static only — method boundaries measured with awk. |
| **Fix approach** | Extract per-tab loaders. Extraction is a refactor of the same kind the split pass (D3) owns, so it is a DEFERRED decision. Decision TPC-04 in `02-fix-plan.md` §9. |
| **Plan item** | TPC-04 in `02-fix-plan.md` §9 |

```php
// TimetablePageController.php:137-139 — timetableOperation() opens at 137, closes at 515
    public function timetableOperation()
    {
        Gate::authorize('tenant.smart-timetable.timetable.viewAny');
```

**Evidence**
```
$ awk 'NR>=137&&NR<=515&&/^    \}/{print "operation ends "NR} NR>=520&&NR<=708&&/^    \}/{print "master ends    "NR} NR>=713&&NR<=1062&&/^    \}/{print "reports ends   "NR}' Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
operation ends 515
master ends 708
reports ends 1062
```

#### TPC-05 · L · CTL-04 — four public methods lack useful return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:111,137,713,1067` |
| **Root cause** | `timetableConfig()`, `timetableOperation()`, `timetableReports()` and `timetableValidation()` declare no return type; the other two declare `: mixed` (any type, so it types nothing). A blade-rendering method should return `\Illuminate\View\View`. |
| **Consequence** | The type system does not catch a method that accidentally returns a redirect or a string. |
| **Reproduce** | Static only — `grep -nE 'public function [a-zA-Z_]+'` on the file. |
| **Fix approach** | Add `: \Illuminate\View\View` to the four methods (or `: mixed` stays as-is where the body is `abort()`). |
| **Plan item** | TPC-05 in `02-fix-plan.md` §8 |

```php
// TimetablePageController.php:111
    public function timetableConfig()
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+' Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
50:    public function constraintManagement(): mixed
111:    public function timetableConfig()
137:    public function timetableOperation()
520:    public function timetableMaster(): mixed
713:    public function timetableReports(Request $request)
1067:    public function timetableValidation()
```

#### TPC-06 · L · CTL-07 — compact() passes 17–18 variables

| Field | Value |
|---|---|
| **Rule** | CTL-07 (L) — *no compact() of more than ~15 variables* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:496-513` (17 vars) and `688-704` (18 vars) |
| **Root cause** | Operation and Master pass their whole dataset into the view through `compact()`. |
| **Consequence** | The view contract is invisible: a missing variable only fails at render time, and every new tab adds one more name to the list. |
| **Reproduce** | Static only — count the quoted names. |
| **Fix approach** | Accept now; a view-model per tab is the split-pass change (folded with TPC-03/TPC-04). |
| **Plan item** | TPC-06 in `02-fix-plan.md` §8 |

```php
// TimetablePageController.php:688-704 — master's compact list (18 variables)
        return view('smarttimetable::smart-timetable.master', compact(
            'timetableTypes',
            'assignmentRoles',
            'roomsUnavailable',
            'teachersUnavailable',
            'schoolDays',
            'shifts',
            'dayTypes',
            'workingDays',
            'periodTypes',
            'academicSession',
            'periodSets',
            'periodSetPeriods',
            'teachers',
            'optimalWorkloadCount',
            'highWorkloadCount',
            'overloadedCount',
```

**Evidence**
```
$ grep -n "compact(" Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
95:        return view('smarttimetable::constraint-management.index', compact(
131:        return view('smarttimetable::index', compact('ttConfigs', 'academicTerms', 'academicSessions', 'algorithmTypes', 'sortingMethods', 'strategies'));
496:        return view('smarttimetable::smart-timetable.operation', compact(
688:        return view('smarttimetable::smart-timetable.master', compact(
1046:        return view('smarttimetable::smart-timetable.reports', compact(
```

#### TPC-08 · L · CTL-08 — the request() helper is used instead of the injected Request

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject Request; don't call the request() helper inside controller methods* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:54-55,141-142,524-527` |
| **Root cause** | `request('search')`, `request('status')`, `request('tab')`, `request('subject_id')` are read from the global helper in three methods; only `timetableReports()` receives the injected `Request $request`. |
| **Consequence** | The dependency on the HTTP facade is hidden, so the methods are hard to unit-call and differ in style from `timetableReports()`. |
| **Reproduce** | Static only — `grep -n "request('"` on the file. |
| **Fix approach** | Inject `Request $request` into the three methods and read the same values from `$request->query()`. |
| **Plan item** | TPC-08 in `02-fix-plan.md` §8 |

```php
// TimetablePageController.php:54-55
        $search = request('search');
        $status = request('status');
```

**Evidence**
```
$ grep -n "request('" Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
54:        $search = request('search');
55:        $status = request('status');
141:        $search = request('search');
142:        $status = request('status');
524:        $activeTab = request('tab', 'school-day');
525:        $search = request('search');
526:        $status = request('status');
527:        $subjectId = request('subject_id');
```

#### TPC-12 · M · CTL-10 — two empty if blocks that only exist to "log a warning" but log nothing

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: commented-out blocks longer than 3 lines, unused private methods … also empty statements that claim to log* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:876-878,900-902` |
| **Root cause** | Both blocks were left with empty bodies when a `Log::warning` call was removed; the comments promise a warning that is never written. |
| **Consequence** | A developer reading the code expects diagnostics that do not exist, and the empty `if` is a magnet for future dead edits. |
| **Reproduce** | Static only — `sed -n '876,878p;900,902p'` on the file (see evidence). |
| **Fix approach** | Delete both `if` blocks (or restore the `Log::warning` inside an explicit block — but deleting matches the current behavior exactly). |
| **Plan item** | TPC-12 in `02-fix-plan.md` §8 |

```php
// TimetablePageController.php:876-878 — first empty block
        // If no rooms exist at all, log a warning
        if ($rooms->isEmpty()) {
        }
```

**Evidence**
```
$ sed -n '876,878p;900,902p' Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
        // If no rooms exist at all, log a warning
        if ($rooms->isEmpty()) {
        }
        // Debug log when no usage data exists despite having rooms
        if ($rooms->isNotEmpty() && $roomUsedCounts->isEmpty() && $selectedTimetableId) {
        }
```

### F7 — Models

#### TPC-01 · B · MDL-07 — the controller imports a model class that does not exist, so the Operation page 500s

| Field | Value |
|---|---|
| **Rule** | MDL-07 (B, adapted: the model *class* is missing, not just its table) — *a model over a missing backing 500s on first use* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:39` (import) and `:471-481` (first use) |
| **Root cause** | Line 39 imports `Modules\TimetableFoundation\Models\TeacherAvailablity` — a misspelling. The real class in that namespace was renamed to `TeacherAvailability` (capital A); PSR-4 resolves the misspelled name to `Modules/TimetableFoundation/app/Models/TeacherAvailablity.php`, which does not exist. A compatibility alias `Modules\SmartTimetable\Models\TeacherAvailablity` was left behind, and it itself extends the same missing class (see TPC-13). The first call `TeacherAvailablity::with([...])` at line 471 therefore throws `Error: Class "Modules\TimetableFoundation\Models\TeacherAvailablity" not found`. `class_exists(...)` returns false. |
| **Consequence** | Every visit to `GET /smart-timetable/timetable-opration` is a 500 for Super Admin and School Admin after the gate passes. |
| **Reproduce** | Open `/smart-timetable/timetable-opration` as School Admin. Expected the Operation page; actual 500. |
| **Fix approach** | Change the import to `Modules\TimetableFoundation\Models\TeacherAvailability` and the one call site at line 471 to `TeacherAvailability::with([`. All used relations (`class`, `section`, `teacherProfile`, `subjectStudyFormat`) exist on that model, and the table `tt_teacher_availabilities` exists (verified). |
| **Plan item** | TPC-01 in `02-fix-plan.md` §1 |

```php
// TimetablePageController.php:471-481 — first use of the imported class
        $teacherAvailabilities = TeacherAvailablity::with([
            'class',
            'section',
            'teacherProfile.employee.user',
            'subjectStudyFormat',
        ])
            ->where('is_active', true)
            ->orderBy('class_id')
            ->orderBy('section_id')
            ->orderBy('subject_study_format_id')
            ->get();
```

**Evidence**
```
$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); var_dump(class_exists("Modules\\TimetableFoundation\\Models\\TeacherAvailablity")); var_dump(class_exists("Modules\\TimetableFoundation\\Models\\TeacherAvailability"));'
bool(false)
bool(true)
$ sed -n '39p' Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
use Modules\TimetableFoundation\Models\TeacherAvailablity;
```

#### TPC-13 · M · MDL-07 — the compatibility alias extends a parent class that does not exist (and lacks strict_types)

| Field | Value |
|---|---|
| **Rule** | MDL-07 (M, lowered from B because nothing calls the alias today) + STY-01 (L, folded here) — *a model whose backing is missing 500s on first use* |
| **Where** | `Modules/SmartTimetable/app/Models/TeacherAvailablity.php:9` |
| **Root cause** | The alias `Modules\SmartTimetable\Models\TeacherAvailablity` extends `\Modules\TimetableFoundation\Models\TeacherAvailablity`, the same misspelled class that does not exist; any future `use Modules\SmartTimetable\Models\TeacherAvailablity` crashes at class load. The file also misses `declare(strict_types=1)` (STY-01). |
| **Consequence** | Latent: nothing references the alias today (the controller and `ActivityScoreService` import the TimetableFoundation name directly), so the crash is not reachable — but the pre-assigned class for this audit is itself broken and every future rename is a trap. |
| **Reproduce** | `php -r '... class_exists("Modules\\SmartTimetable\\Models\\TeacherAvailablity")'` → fatal when the alias is autoloaded (verified bool(false) on the parent + the alias resolving to a class whose parent is missing). |
| **Fix approach** | Point the alias parent at the correctly spelled `\Modules\TimetableFoundation\Models\TeacherAvailability` and add `declare(strict_types=1);`. |
| **Plan item** | TPC-13 in `02-fix-plan.md` §5 |

```php
// TeacherAvailablity.php:9 — the extends target does not exist
class TeacherAvailablity extends \Modules\TimetableFoundation\Models\TeacherAvailablity
```

**Evidence**
```
$ cat Modules/SmartTimetable/app/Models/TeacherAvailablity.php
<?php

namespace Modules\SmartTimetable\Models;

/**
 * Backward-compatibility alias — model moved to TimetableFoundation.
 * Will be removed in Phase 6 cleanup.
 */
class TeacherAvailablity extends \Modules\TimetableFoundation\Models\TeacherAvailablity
{
}
$ grep -c "TeacherAvailablity" vendor/composer/autoload_classmap.php
1   # only Modules\SmartTimetable\Models\TeacherAvailablity — the TimetableFoundation name is absent
```

### F8 — Services and jobs

clean — this controller uses no service, job, event or notification (`grep -nE 'Service|Job::dispatch|event\(|Notification'` on the controller → no in-scope hits).

### F9 — Queries and performance

#### TPC-09 · M · QRY-15 — master-data and report loads pull whole tables, then group and filter in PHP

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) + QRY-05 (M) — *don't load every row of a big table for a page; filter/aggregate in SQL* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:163` (RequirementConsolidation), `:272-294` (Activity), `:296-308` (SchClassGroupsJnt), `:426-429` (AcademicTerm), `:434-451` (ClassSubjectGroup), `:452-469` (ClassSubjectSubgroup), `:788-790` (AcademicTerm, reports), `:944-960` (Activity for capacity) |
| **Root cause** | Eight unbounded `->get()` loads feed pages that then call `->groupBy()`, `->unique()` and `->map()` in PHP (e.g. lines 296-308 and 434-469). The two `AcademicTerm` loads re-run the same query on different pages. |
| **Consequence** | On a school with real data (1000+ activities, 100+ requirement rows) the Operation and Reports pages slow down linearly and the browser receives every column of every row. Today's tenant has 0 activities, so the cost is not visible yet. |
| **Reproduce** | Live in a tenant with a full timetable: open `/smart-timetable/timetable-opration` and watch the query log. |
| **Fix approach** | Paginate or `select` the columns actually used; where grouping is unavoidable, aggregate in SQL (`selectRaw` + `groupBy`) instead of `get()->groupBy()`. |
| **Plan item** | TPC-09 in `02-fix-plan.md` §6 |

```php
// TimetablePageController.php:272-294 — unbounded load of every active activity with 13 relations
        $activities = Activity::with([
            'classGroup',
            'classSubgroup',
            'class',
            'section',
            'subject',
            'studyFormat',
            'subjectType',
            'requiredRoomType',
            'preferredRoomType',
            'teachers.teacher.user',
            'teachers.assignmentRole',
            'subActivities.class',
            'subActivities.section',
        ])
            ->where('is_active', true)
            ->when($search, function ($q, $s) {
                $q->where(function ($q) use ($s) {
                    $q->where('code', 'like', "%{$s}%")
                        ->orWhere('name', 'like', "%{$s}%");
                });
            })
            ->get();
```

**Evidence**
```
$ grep -nF -- '->get()' Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
163:            ->get();
294:            ->get();
305:            ->get()
429:            ->get();
437:            ->get()
455:            ->get()
790:            ->get();
960:            ->get();
$ php final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php | grep QRY-15
M  QRY-15   Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:296  TimetablePageController — SchClassGroupsJnt::with->orderBy->orderBy->get() — no filter, loads every row
M  QRY-15   Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:427  TimetablePageController — AcademicTerm::orderByDesc->orderBy->get() — no filter, loads every row
M  QRY-15   Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:434  TimetablePageController — ClassSubjectGroup::with->orderBy->orderBy->get() — no filter, loads every row
M  QRY-15   Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:452  TimetablePageController — ClassSubjectSubgroup::with->orderBy->orderBy->get() — no filter, loads every row
M  QRY-15   Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:788  TimetablePageController — AcademicTerm::orderByDesc->orderBy->get() — no filter, loads every row
```

#### TPC-10 · M · QRY-12 — the same AcademicSession lookup runs twice and the first result is thrown away

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) — *identical queries repeated in one request resolve once* (plus dead-value: the first result is never used) |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:147` and `:426` |
| **Root cause** | `timetableOperation()` calls `AcademicSession::current()->firstOrFail()` at line 147, then overwrites the variable at line 426 with `AcademicSession::current()->first()`. The compact list at lines 496-513 never includes `academicSession`, so line 147's value is dead — and its `firstOrFail()` can turn a missing current session into a 404 that the page never needs. |
| **Consequence** | Two identical queries per request; worse, a tenant with no active session gets a 404 on Operation even though the page never displays the session. |
| **Reproduce** | Static only — `sed -n '147p;426p'` on the file (see evidence). |
| **Fix approach** | Delete line 147 (the dead `firstOrFail()`); keep the line-426 lookup if the view ever needs it, or delete both since neither is passed to the view. |
| **Plan item** | TPC-10 in `02-fix-plan.md` §6 |

```php
// TimetablePageController.php:147 — dead firstOrFail(), overwritten at 426
        $academicSession = AcademicSession::current()->firstOrFail();
```

**Evidence**
```
$ sed -n '147p;426p' Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php
        $academicSession = AcademicSession::current()->firstOrFail();
        $academicSession = AcademicSession::current()->first();
```

#### TPC-11 · L · QRY-08 — leading-wildcard LIKE searches used for the search filters

| Field | Value |
|---|---|
| **Rule** | QRY-08 (L) — *leading-wildcard LIKE '%x%' can't use an index* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:64-65,85-86,265-266,290-291,540-541,549-550,558-559,567-568,578-579,588-589,596-597,606-607,616-617,626-627,652-653` |
| **Root cause** | Every `when($search)` filter builds `where('name', 'like', "%{$s}%")` (the wildcard is bound, so it is not injection — it is an index problem). |
| **Consequence** | Free-text searches on `tt_constraints`, `tt_activities`, `sch_teachers` and the master lists scan the table; negligible on a school-sized dataset. |
| **Reproduce** | Static only — `grep -nE "'like'"` on the file. |
| **Fix approach** | Accept for now; if a tenant hits slowness, switch subject/teacher lookups to prefix `LIKE 'x%'` or a search column. |
| **Plan item** | TPC-11 in `02-fix-plan.md` §6 |

```php
// TimetablePageController.php:64-65 — one of 15+ leading-wildcard searches
                        $q->where('name', 'like', "%{$s}%")
                            ->orWhereHas('constraintType', fn ($q) => $q->where('name', 'like', "%{$s}%")->orWhere('code', 'like', "%{$s}%"));
```

**Evidence**
```
$ grep -nE "'like'" Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php | wc -l
23
$ php final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php | grep QRY-08
L  QRY-08   Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:64  constraintManagement — 5 leading-wildcard LIKE search(es)
L  QRY-08   Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:265  timetableOperation — 4 leading-wildcard LIKE search(es)
L  QRY-08   Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:540  timetableMaster — 22 leading-wildcard LIKE search(es)
```

### F10 — Views

#### TPC-02 · B · VIEW-01 — Timetable Config renders a Blade that includes two views that do not exist

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H, raised to B: the render cannot run at all) — adapted — *a Blade that cannot compile/render is a page killer* |
| **Where** | `Modules/SmartTimetable/resources/views/index.blade.php:15,18` |
| **Root cause** | `timetableConfig()` returns `view('smarttimetable::index', ...)`. That Blade `@include`s `smarttimetable::timetable-config.index` (inside `@can('tenant.smart-timetable.config.viewAny')`) and `smarttimetable::school-academic-term.index` (inside `@can('tenant.smart-timetable.report.viewAny')`). Neither file exists under `Modules/SmartTimetable/resources/views/` (`view()->exists` → false). Because the controller's own `Gate::authorize('...config.viewAny')` passes for every visitor, the first `@can` is true and the `@include` runs, throwing `InvalidArgumentException: View [timetable-config.index] not found.` |
| **Consequence** | Every visit to `GET /smart-timetable/timetable-config` is a 500 for Super Admin and School Admin. |
| **Reproduce** | Open `/smart-timetable/timetable-config` as School Admin. Expected the config tabs; actual 500 with `View [timetable-config.index] not found`. |
| **Fix approach** | Decide what each tab must show, then either create the two views under `Modules/SmartTimetable/resources/views/` or point the includes at existing views (a `school-academic-term` index already exists under TimetableFoundation). Needs a product decision. Decision TPC-02 in `02-fix-plan.md` §1. |
| **Plan item** | TPC-02 in `02-fix-plan.md` §1 |

```php
// index.blade.php:14-18 — the includes that resolve to nothing
            @can('tenant.smart-timetable.config.viewAny')
                @include('smarttimetable::timetable-config.index')
            @endcan
            @can('tenant.smart-timetable.report.viewAny')
                @include('smarttimetable::school-academic-term.index')
            @endcan
```

**Evidence**
```
$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); var_dump(view()->exists("smarttimetable::timetable-config.index")); var_dump(view()->exists("smarttimetable::school-academic-term.index")); var_dump(view()->exists("smarttimetable::timetable-generation-strategy.index"));'
bool(false)
bool(false)
bool(true)
$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); try { view()->make("smarttimetable::timetable-config.index"); echo "rendered\n"; } catch (\Throwable $e) { echo get_class($e).": ".$e->getMessage()."\n"; }'
InvalidArgumentException: View [timetable-config.index] not found.
```

The rest of the VIEW family is clean: `grep -rn '{!!'` over the five main views and their direct partials → no output; `grep -rnE 'Model::|\bDB::|->where\(|->get\(\)'` → no queries in Blade (only collection `->count()`/`->first()` on already-loaded variables); every relation used inside `@foreach` is eager-loaded by the controller (`Activity` with 13 relations, `Teacher` with `activityAssignments.activity.subject/studyFormat`, `RequirementConsolidation` with 10 relations, teacher availability with `teacherProfile.employee.user`). The `x-backend.*` components and layouts are common (`resources/views/components/**`), referenced not audited here.

### F11 — Security and tenancy

clean — no `env()` outside config, no `{!! !!}` on user text, no hard-coded ids (`?? 1` not present), no secrets logged, all routes sit inside the tenant auth group, every query runs against the initialized tenant DB (`whereRaw('0=1')` and the raw JOINs use bindings/constants only — no interpolated input).

### F12 — Style

The only STY hit in scope is STY-01 on the pre-assigned model (`Modules/SmartTimetable/app/Models/TeacherAvailablity.php:1` missing `declare(strict_types=1)`), folded into TPC-13. The controller itself declares `strict_types`, uses camelCase throughout, and has no emoji or copy-pasted docblocks.

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 wrong-data write | Q2 delete-before-store | Q3 duplicate impl | Q4 soft-delete unique trap | Q5 race | Q6 auth hole | Q7 lying message | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| none — the controller has no mutating method | — | — | — | — | — | — | — | — |

All five routed methods are read-only GET pages (`grep` for `->create|->update|->delete|->save|DB::transaction|activityLog` → no output). Q8 answers for the read surface: TPC-10 (the dead `firstOrFail()` lookup) is the closest to a dead feature, and it already has a plan item.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SmartTimetable/app/Services/ActivityScoreService.php:8,175,213` | Uses the same misspelled import `Modules\TimetableFoundation\Models\TeacherAvailablity`; calling `where('requirement_consolidation_id', ...)` on it crashes the same way as TPC-01. | MDL-07 | Owner of the service — not registered in `00-CLASS-OWNERS.md`; likely the TtGenerationStrategyController batch |
| `Modules/SmartTimetable/app/Models/TeacherAvailablity.php` | Already owned by this report (TPC-13) — listed here because the same misspelling pattern also existed in `Modules/SmartTimetable/app/Models/TeacherAvailabilityDetail.php:70` (already fixed 2026-08-26, git comment). | MDL-07 | This report |

## 8. Not covered, and why

- **Live browser renders** — the five pages need a logged-in tenant role to render; Red/Green evidence here is command-level (view existence, `class_exists`, blade greps), not a rendered DOM.
- **Other-report models** — the 27 linked models are audited in their owner reports (§3). Their *usage* here (eager loads, arguments) was checked; their internals are explicitly out of scope for this report, and some owner reports are still `CLAIMED`.
- **Row-count-driven UI pages** — with `tt_activities` = 0 rows in the demo tenant, the pagination and workload charts could not be exercised with data; the page-size deviation (constraint lists paginate at 15, `slotAvailabilities` at 30, the rest at 10) was noted but not reported because the convention is a styling standard, not a defect.
- **`timetableValidation`** — its original body is in git history per the comment; only the `abort(403)` stub was audited (D5).