# Fix Plan — SmartTimetable / TimetablePageController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php` | route file — changing routes is a separate decision |
| `config/permissionslist.php` | shared permission registry; TPC-07 reuses existing keys only, nothing here is edited |
| `database/migrations/**`, `Modules/**/Database/**` | never edit an existing migration |
| `resources/views/components/**`, `x-backend.*` components and layouts | shared components and layouts |
| `Modules/SmartTimetable/resources/views/index.blade.php` | only editable through the ticked **TPC-02** choice (options b/c name it); a default fixer run must not touch it |
| `Modules/SmartTimetable/app/Services/ActivityScoreService.php` | owned by another report (cross-cutting note, §7 of the report) |
| `Modules/SmartTimetable/app/Models/Constraint.php`, `ConstraintType.php`, `ConstraintCategoryScope.php`, `TeacherUnavailable.php`, `RoomUnavailable.php`, `TtGenerationStrategy.php`, `Activity.php`, `SchoolDay.php`, `PeriodSetPeriod.php`, `TimetableCell.php`, `Timetable.php` | each owned by another SmartTimetable report — link to those reports |
| `Modules/TimetableFoundation/**` | other module — owned by TimetableFoundation reports; only read here |

## 1. Blockers reachable today

- [ ] **TPC-01** · B · MDL-07 · `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php:39,471` — point the import and the call site at the real class `TeacherAvailability` so the Operation page stops 500ing.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Before** (`TimetablePageController.php:39`):
    ```php
    use Modules\TimetableFoundation\Models\TeacherAvailablity;
    ```
  - **After:**
    ```php
    // TimetablePageController.php:39 — replaced import
    use Modules\TimetableFoundation\Models\TeacherAvailability;

    // TimetablePageController.php:471 — replaced call site (same file):
    //   from:  $teacherAvailabilities = TeacherAvailablity::with([
    //   to:    $teacherAvailabilities = TeacherAvailability::with([
    ```
  - **Verify:** `grep -n "TeacherAvailablity" Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **TPC-02** · B · DECISION · VIEW-01 — the Timetable Config page includes two views that do not exist (`smarttimetable::timetable-config.index`, `smarttimetable::school-academic-term.index`). What should the two tabs show?
  - **Why it is a decision:** the answer defines new views or a cross-module include — product content, not a mechanical fix.
  - (a) ⭐ Create the two views under `Modules/SmartTimetable/resources/views/` (`timetable-config/index.blade.php`, `school-academic-term/index.blade.php`) with the same tab content the old TimetableFoundation pages showed; touches only new SmartTimetable files, `index.blade.php` unchanged.
  - (b) Point the includes at the existing TimetableFoundation views (`timetablefoundation::school-academic-term.index` and the TimetableFoundation timetable-configuration partials) — touches `index.blade.php` and reaches another module's views (⚠ SHARED).
  - (c) Remove the two tabs from `index.blade.php` — touches `index.blade.php`, hides deliberately-dead UI.
  - ➜ Choice: moot — page retired (R2, Tarun 2026-10-16)

## 2. Fixes that arm a latent defect (sequenced)

(TPC-13 arms the latent alias crash and is sequenced right after the blocker that uses the same name.)

## 3. Errors & transactions (F1/F2)

No findings in F1/F2 — nothing to fix.

## 4. Authorization (F3)

- [ ] **TPC-07** · M · AUTH-06 · `TimetablePageController.php:52,113,139,522,715` — replace the five permission literals with four class constants.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Before** (`TimetablePageController.php:52` — the literal repeats at 113, 139, 522, 715):
    ```php
        Gate::authorize('tenant.smart-timetable.constraint.viewAny');
    ```
  - **After:**
    ```php
    // TimetablePageController.php — add the four constants just above constraintManagement()
    private const PERM_CONSTRAINT_VIEW = 'tenant.smart-timetable.constraint.viewAny';
    private const PERM_CONFIG_VIEW = 'tenant.smart-timetable.config.viewAny';
    private const PERM_TIMETABLE_VIEW = 'tenant.smart-timetable.timetable.viewAny';
    private const PERM_REPORT_VIEW = 'tenant.smart-timetable.report.viewAny';

    // and replace the five call sites:
    Gate::authorize(self::PERM_CONSTRAINT_VIEW);   // line 52
    Gate::authorize(self::PERM_CONFIG_VIEW);       // line 113
    Gate::authorize(self::PERM_TIMETABLE_VIEW);    // lines 139 and 522
    Gate::authorize(self::PERM_REPORT_VIEW);       // line 715
    ```
  - **Verify:** `grep -n "tenant.smart-timetable" Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Expect:** only the four `private const PERM_*_VIEW = 'tenant.smart-timetable...'` lines (no literal inside `Gate::authorize`).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **TPC-13** · M · MDL-07 · `Modules/SmartTimetable/app/Models/TeacherAvailablity.php:1,9` — point the alias at the real parent `TeacherAvailability` and add `declare(strict_types=1)` (also clears the STY-01 scan hit).
  - **Touches:** `Modules/SmartTimetable/app/Models/TeacherAvailablity.php`
  - **Before** (`TeacherAvailablity.php:1-10`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Models;

    /**
     * Backward-compatibility alias — model moved to TimetableFoundation.
     * Will be removed in Phase 6 cleanup.
     */
    class TeacherAvailablity extends \Modules\TimetableFoundation\Models\TeacherAvailablity
    {
    }
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Models;

    /**
     * Backward-compatibility alias — model moved to TimetableFoundation.
     * Will be removed in Phase 6 cleanup.
     */
    class TeacherAvailablity extends \Modules\TimetableFoundation\Models\TeacherAvailability
    {
    }
    ```
  - **Verify:** `grep -n "TeacherAvailability" Modules/SmartTimetable/app/Models/TeacherAvailablity.php`
  - **Expect:** line 11 `class TeacherAvailablity extends \Modules\TimetableFoundation\Models\TeacherAvailability`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **TPC-10** · M · QRY-12 · `TimetablePageController.php:147` — delete the dead `AcademicSession::current()->firstOrFail()` so the Operation page issues one lookup instead of two and cannot 404 on a missing current session.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Before** (`TimetablePageController.php:145-148`):
    ```php
        $constraintTypes = ConstraintType::where('is_active', true)->get();
        $constraints = Constraint::paginate(10);
        $academicSession = AcademicSession::current()->firstOrFail();
        $classTimetableTypes = ClassTimetableType::paginate(10);
    ```
  - **After:**
    ```php
        $constraintTypes = ConstraintType::where('is_active', true)->get();
        $constraints = Constraint::paginate(10);
        $classTimetableTypes = ClassTimetableType::paginate(10);
    ```
  - **Verify:** `grep -n "AcademicSession::current()" Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Expect:** exactly one match, at line 426.
  - **Effort:** S

TPC-11 (QRY-08, leading-wildcard LIKE) — accepted, no change; see plan §10.

- [ ] **TPC-09** · M · DECISION · QRY-15 — eight unbounded `->get()` loads (activities, class groups, requirements, academic terms) are grouped and filtered in PHP. Defer or narrow now?
  - **Why it is a decision:** narrowing the loads (select columns / paginate) can break the grouped collections the Operation and Reports blades consume; the safe version is a behaviour-conscious refactor owned by the split pass.
  - (a) ⭐ Defer to the split pass (D3) — TPC-03/TPC-04 will paginate/aggregate per tab; record as accepted for this pass.
  - (b) Apply select-only narrowing now on the master-data loads (`AcademicTerm`, `ClassSubjectGroup`, `ClassSubjectSubgroup`, `SchClassGroupsJnt`) after checking each blade's column use — touches `TimetablePageController.php` plus re-verification of 8 blades.
  - (c) Leave as is and record as accepted debt.
  - ➜ Choice: moot — page retired (R2)

## 7. Views (F10)

TPC-02 is in §1 (blocker). No other VIEW finding.

## 8. Style & controller shape (F12/F6 — one item per change in the same file)

- [ ] **TPC-05** · L · CTL-04 · `TimetablePageController.php:111,137,713,1067` — add `: \Illuminate\View\View` return types to the three view methods (`timetableConfig`, `timetableOperation`, `timetableReports`) and leave `timetableValidation` on `: mixed` (its body is `abort()`).
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Before** (`TimetablePageController.php:111`):
    ```php
        public function timetableConfig()
    ```
  - **After:**
    ```php
        public function timetableConfig(): View
    ```
  - **Verify:** `grep -n "public function timetable" Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Expect:** `timetableConfig(): View`, `timetableOperation(): View`, `timetableReports(Request $request): View`, `timetableValidation(): mixed`. (Add `use Illuminate\Contracts\View\View;` to the imports if it is not already present.)
  - **Effort:** S

- [ ] **TPC-08** · L · CTL-08 · `TimetablePageController.php:50-55,137-142,520-527` — inject `Request $request` into `constraintManagement`, `timetableOperation` and `timetableMaster`, and read the same query values from it.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Before** (`TimetablePageController.php:50-55`):
    ```php
    public function constraintManagement(): mixed
    {
        Gate::authorize('tenant.smart-timetable.constraint.viewAny');

        $search = request('search');
        $status = request('status');
    ```
  - **After:**
    ```php
    // line 50 — add the parameter to constraintManagement
    public function constraintManagement(Request $request): mixed
    {
        Gate::authorize('tenant.smart-timetable.constraint.viewAny');

        $search = $request->query('search');
        $status = $request->query('status');

    // line 137 — add the parameter to timetableOperation
    public function timetableOperation(Request $request)
    {
        Gate::authorize('tenant.smart-timetable.timetable.viewAny');

        $search = $request->query('search');
        $status = $request->query('status');

    // line 520 — add the parameter to timetableMaster
    public function timetableMaster(Request $request): mixed
    {
        Gate::authorize('tenant.smart-timetable.timetable.viewAny');

        $activeTab = $request->query('tab', 'school-day');
        $search = $request->query('search');
        $status = $request->query('status');
        $subjectId = $request->query('subject_id');
    ```
  - **Verify:** `grep -n "request('" Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Expect:** no output — every query-string read is now `$request->query(...)`.
  - **Effort:** S

- [ ] **TPC-12** · M · CTL-10 · `TimetablePageController.php:876-878,900-902` — delete the two empty `if` blocks that promise a log warning but log nothing.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Before** (`TimetablePageController.php:876-878`):
    ```php
        // If no rooms exist at all, log a warning
        if ($rooms->isEmpty()) {
        }
    ```
  - **After:**
    ```php
    ```
  - **Verify:** `sed -n '874,880p' Modules/SmartTimetable/app/Http/Controllers/TimetablePageController.php`
  - **Expect:** no `if ($rooms->isEmpty()) {` line; the report block flows from the `->get();` of `$rooms` straight to `// Calculate utilization for ALL rooms`. Also delete the second empty block at lines 900-902.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **TPC-03** · M · DECISION · CTL-01 — this 1073-line page controller renders five independent report pages. Split it now or defer?
  - **Why it is a decision:** a controller split is deferred by D3 for the whole module; it changes routes and folder ownership.
  - (a) ⭐ Defer to the split pass (D3) — this report records the five natural controllers (`ConstraintManagementController`, `TimetableConfigController`, `TimetableOperationController`, `TimetableMasterController`, `TimetableReportsController`).
  - (b) Split just the `timetableOperation` method family into one new controller now (smaller blast radius).
  - (c) Leave as is and record as accepted.
  - ➜ Choice: moot — controller retired (R2)

- [ ] **TPC-04** · H · DECISION · CTL-02 — three methods exceed 150 lines (Operation 379, Master 189, Reports 350). Extract per-tab loaders now or defer?
  - **Why it is a decision:** the extraction is a behaviour-neutral refactor that the D3 split pass also owns.
  - (a) ⭐ Defer to the split pass — the extraction is the first step of TPC-03(b).
  - (b) Extract the tab loaders inside this controller now (no route change).
  - (c) Leave as is and record as accepted.
  - ➜ Choice: moot — controller retired (R2)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TPC-06 | Accepted debt — the 17-18 variable `compact()` list is folded into the split-pass view-model change (TPC-03/TPC-04); converting it now would duplicate that work. |
| TPC-11 | Accepted — leading-wildcard `LIKE` is a known trade-off on school-sized tables (≈89 teachers, 6 constraints live today); revisit if a tenant reports slow search. |