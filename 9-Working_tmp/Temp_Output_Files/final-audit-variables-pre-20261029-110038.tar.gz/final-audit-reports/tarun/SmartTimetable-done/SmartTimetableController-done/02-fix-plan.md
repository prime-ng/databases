# Fix Plan — SmartTimetable / SmartTimetableController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php`, `Modules/SmartTimetable/routes/api.php` | Route changes (parameter renames, route removal) are §9.3 stop conditions and belong to the split pass |
| `Modules/SmartTimetable/app/Providers/SmartTimetableServiceProvider.php` | Other controllers depend on the registrations (only a ticked STM-06 DECISION may touch line 267) |
| `Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php` | Owned by the TimetableGenerationController report |
| `Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php`, `Preview/PreviewGridState.php` | Owned by other reports |
| `Modules/SmartTimetable/app/Http/Requests/UpdateTimetableRequest.php` | Only the STM-19 style scrub would touch it; no ticked item |
| Any `Modules/TimetableFoundation/**`, `Modules/SchoolSetup/**`, `Modules/Prime/**` file | Different modules, other reports |
| Any view under `Modules/SmartTimetable/resources/views/pages/`, `preview/` | Belongs to the controllers that own those screens (STM-08) |

## 1. Blockers reachable today

- [x] **STM-01** · B · ERR-01/TXN-02 · `SmartTimetableController.php:1036-1077` — rewrite `destroy()` with the Laravel idiom: a single `DB::transaction` closure and no catch, so no raw exception text reaches the user.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php`
  - **Before** (`SmartTimetableController.php:1036-1077`):
    ```php
        try {
            DB::beginTransaction();

            // Hard-purge every FK child row (cells, teacher pivots, generation
            // runs, conflict detections, change logs, teacher workloads,
            // constraint violations). Centralised in TimetableStorageService
            // so all three delete paths stay consistent.
            TimetableStorageService::purgeChildrenOf((int) $timetable->id);

            // Soft-delete the timetable header so it appears in Trash and
            // can be force-deleted from there if needed.
            $timetable->delete();

            // Rule A3 — AFTER the write and INSIDE the transaction, so a failed
            // delete cannot leave an audit row claiming the timetable was trashed.
            activityLog($timetable, 'Trashed', [
                'message' => "Timetable '{$timetable->name}' was moved to trash.",
            ]);

            DB::commit();

            return redirect()->back()->with(
                'success',
                "Timetable '{$timetable->name}' has been deleted successfully."
            );

        } catch (\Exception $e) {
            if (DB::transactionLevel() > 0) {
                DB::rollBack();
            }

            \Log::error('Timetable deletion failed', [
                'timetable_id' => $id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return redirect()->back()->with(
                'error',
                'Failed to delete timetable: '.$e->getMessage()
            );
        }
    ```
  - **After:**
    ```php
        return DB::transaction(function () use ($timetable) {
            // Hard-purge every FK child row (cells, teacher pivots, generation
            // runs, conflict detections, change logs, teacher workloads,
            // constraint violations). Centralised in TimetableStorageService
            // so all three delete paths stay consistent. It opens its own
            // DB::transaction; as a savepoint inside this one its failure
            // rolls back the whole delete. STM-01 (ERR-01/D1/TXN-02), 2026-10-10.
            TimetableStorageService::purgeChildrenOf((int) $timetable->id);

            // Soft-delete the timetable header so it appears in Trash and
            // can be force-deleted from there if needed.
            $timetable->delete();

            // Rule A3 — AFTER the write and INSIDE the transaction.
            activityLog($timetable, 'Trashed', [
                'message' => "Timetable '{$timetable->name}' was moved to trash.",
            ]);
        });

        return redirect()->back()->with(
            'success',
            "Timetable '{$timetable->name}' has been deleted successfully."
        );
    ```
  - **Verify:** `grep -n "getMessage\|catch (\|beginTransaction" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php; php -l Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php`
  - **Expect:** the `getMessage`/`catch (`/`beginTransaction` lines are gone from `destroy()` (no output for those tokens between lines 1036 and 1078); `php -l` prints "No syntax errors detected".
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

*None in this pass — the STM-08 unrouted-body disabling is deferred to the STM-09 split decision.*

## 3. Errors & transactions (F1/F2)

- [x] **STM-05** · M · ERR-00/ERR-05/TXN-05 · `SmartTimetableController.php:916-1011` — rewrite `update()` with the Laravel idiom: no try/catch, closure returns the model, redirect built after the transaction.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php`
  - **Before** (`SmartTimetableController.php:916-1011`):
    ```php
        try {
            return DB::transaction(function () use ($request, $timetable, $isPublishing) {
                $original = $timetable->getOriginal();

                $data = $request->validated();

                // The same two stamps TimetablePublishController writes. Without them a
                // row would read as live with no record of when it went live or who did
                // it — and the new Published column on the list would show a dash.
                if ($isPublishing) {
                    $data['published_at'] = now();
                    $data['published_by'] = auth()->id();
                }

                // Status drives is_active: PUBLISHED ⇒ active, anything else ⇒ inactive.
                // Timetable::booted() enforces the same rule on every save; stated here so
                // the edit form's intent is readable without opening the model.
                if (array_key_exists('status', $data)) {
                    $data['is_active'] = $data['status'] === 'PUBLISHED';
                }

                $timetable->update($data);

                // One published timetable per scope (snapshot v5, T3.3). After the
                // update, so a scope edited in the same request is the one used.
                if ($isPublishing) {
                    $timetable->archiveOthersInScope();
                }

                $changes = [];
                foreach ($timetable->getChanges() as $field => $newValue) {
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changes[$field] = ['old' => $original[$field] ?? null, 'new' => $newValue];
                }

                /*
                 * ⛔ PUBLISHING CHANGES THE STATUS ONLY — it writes NO tt_timetable_assignments row.
                 * Reverses the 2026-09-08 D5 behaviour on 2026-09-11, on instruction.
                 *
                 * makeSchoolDefault() repointed the school's default on EVERY publish, so re-publishing
                 * any timetable silently took over the default and overwrote whatever the administrator
                 * had attached by hand. Which timetable is in force is now a deliberate, manual act:
                 * View & Refinement → Class Assignment.
                 *
                 * ⛔ AND SINCE 2026-09-11 THERE IS NOTHING BEHIND IT. PublishedTimetable's
                 * "most recently published" fallback was removed the same day, so a class with no
                 * assignment row covering today sees NO timetable at all — the student, parent and
                 * teacher portals render their empty state. That is the rule now, not a regression:
                 * publishing sets a status; attaching is a separate, deliberate act on
                 * View & Refinement → Class Assignment.
                 *
                 * ⛔ DO NOT RE-ADD THE CALL HERE. TimetableAssignment::makeSchoolDefault() is kept,
                 * uncalled, for a future explicit "make this the default" button — not for publish.
                 */

                // A publish is its own event. Logging it as 'Updated' would leave the
                // audit trail unable to answer "when did this go live?" — the question
                // the log exists for. Matches TimetablePublishController's literal.
                /* ⚠ A publish that skipped the readiness gate must SAY so. The user
                   confirmed it on the form, and this log is the only record that the
                   timetable went live incomplete — a row reading "was published" would be
                   a false trail. Matches TimetablePublishController's payload. */
                $bypassed = $isPublishing && $request->boolean('confirm_publish');
                $unplaced = $bypassed
                    ? app(TimetableReadiness::class)->unplacedPeriods($timetable)
                    : 0;

                activityLog($timetable, $isPublishing ? 'Published' : 'Updated', [
                    'message' => $isPublishing
                        ? ($bypassed
                            ? "Timetable '{$timetable->name}' was published with {$unplaced} "
                              .'period(s) still unplaced, confirmed by the user.'
                            : "Timetable '{$timetable->name}' was published.")
                        : 'Timetable details were updated.',
                    'changes' => $changes,
                    'readiness_bypassed' => $bypassed,
                ]);

                return redirect()
                    ->route('smart-timetable.timetable.timetableGeneration', ['tab' => 'timetable'])
                    ->with('success', $isPublishing
                        ? 'Timetable published successfully.'
                        : 'Timetable updated successfully.');
            });
        } catch (\Throwable $e) {
            Log::error('SmartTimetableController::update failed', [
                'timetable_id' => $timetable->id,
                'error' => $e->getMessage(),
            ]);

            return redirect()->back()->withInput()
                ->with('error', 'The operation could not be completed.');
        }
    ```
  - **After:**
    ```php
        return DB::transaction(function () use ($request, $timetable, $isPublishing) {
            $original = $timetable->getOriginal();

            $data = $request->validated();

            // The same two stamps TimetablePublishController writes. Without them a
            // row would read as live with no record of when it went live or who did
            // it — and the new Published column on the list would show a dash.
            if ($isPublishing) {
                $data['published_at'] = now();
                $data['published_by'] = auth()->id();
            }

            // Status drives is_active: PUBLISHED ⇒ active, anything else ⇒ inactive.
            // Timetable::booted() enforces the same rule on every save; stated here so
            // the edit form's intent is readable without opening the model.
            if (array_key_exists('status', $data)) {
                $data['is_active'] = $data['status'] === 'PUBLISHED';
            }

            $timetable->update($data);

            // One published timetable per scope (snapshot v5, T3.3). After the
            // update, so a scope edited in the same request is the one used.
            if ($isPublishing) {
                $timetable->archiveOthersInScope();
            }

            $changes = [];
            foreach ($timetable->getChanges() as $field => $newValue) {
                if ($field === 'updated_at') {
                    continue;
                }
                $changes[$field] = ['old' => $original[$field] ?? null, 'new' => $newValue];
            }

            $bypassed = $isPublishing && $request->boolean('confirm_publish');
            $unplaced = $bypassed
                ? app(TimetableReadiness::class)->unplacedPeriods($timetable)
                : 0;

            activityLog($timetable, $isPublishing ? 'Published' : 'Updated', [
                'message' => $isPublishing
                    ? ($bypassed
                        ? "Timetable '{$timetable->name}' was published with {$unplaced} "
                          .'period(s) still unplaced, confirmed by the user.'
                        : "Timetable '{$timetable->name}' was published.")
                    : 'Timetable details were updated.',
                'changes' => $changes,
                'readiness_bypassed' => $bypassed,
            ]);

            return $timetable;
        });

        return redirect()
            ->route('smart-timetable.timetable.timetableGeneration', ['tab' => 'timetable'])
            ->with('success', $isPublishing
                ? 'Timetable published successfully.'
                : 'Timetable updated successfully.');
    ```
  - **Verify:** `grep -n "catch (\|getMessage\|withInput" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php; php -l Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php`
  - **Expect:** no `catch (` / `getMessage` / `withInput` remains between lines 916 and 1011; `php -l` prints "No syntax errors detected".
  - **Effort:** M

## 4. Authorization (F3)

*No standalone item — STM-06 is a DECISION (§9). The redundant `Gate::authorize` in `update()` (STM-07) is covered by the STM-05 rewrite: keep the FormRequest's `authorize()` as the single check and let the controller-level line be removed there.*

## 5. Validation, routes, models (F4/F5/F7)

*None — STM-11 (route model binding) needs a route-parameter rename and is deferred to the split pass (§10).*

## 6. Queries & performance (F9)

- [ ] **STM-15** (MOOT, 2026-10-16: R4 retired `index()`, so these paginators no longer exist) · H · QRY-13 · `SmartTimetableController.php:85-90, 125-127, 139, 192` — give the 11 index-page paginators distinct page names so paging one list does not re-page the others.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php`
  - **Before** (`SmartTimetableController.php:85-90`):
    ```php
        $constraints = Constraint::paginate(10);
        $teachersUnavailable = TeacherUnavailable::paginate(10);
        $classSubgroups = ClassSubjectSubgroup::paginate(10);
        $roomsUnavailable = RoomUnavailable::paginate(10);
        $assignmentRoles = TeacherAssignmentRole::paginate(10);
        $classGroupRequirements = RequirementConsolidation::paginate(10);
    ```
  - **After:** — the same pattern applied to every `paginate(10)` call in `index()` (lines 85-90, 125-127, 139, 192):
    ```php
        $constraints = Constraint::paginate(10, ['*'], 'con_page');
        $teachersUnavailable = TeacherUnavailable::paginate(10, ['*'], 'tu_page');
        $classSubgroups = ClassSubjectSubgroup::paginate(10, ['*'], 'cs_page');
        $roomsUnavailable = RoomUnavailable::paginate(10, ['*'], 'ru_page');
        $assignmentRoles = TeacherAssignmentRole::paginate(10, ['*'], 'ar_page');
        $classGroupRequirements = RequirementConsolidation::paginate(10, ['*'], 'cg_page');

        $timetableTypes = TimetableType::paginate(10, ['*'], 'tt_page');
        $timetables = Timetable::paginate(10, ['*'], 'tm_page');
        $periodSetPeriods = PeriodSet::paginate(10, ['*'], 'psp_page');
    ```
    and for the teachers chain at line 139: `->paginate(10, ['*'], 'tch_page');` and the rooms line at 192: `$rooms = Room::with(['building', 'roomType'])->paginate(10, ['*'], 'room_page');`
  - **Verify:** `grep -n "paginate(10)" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php`
  - **Expect:** no bare `paginate(10)` remains inside `index()` (each call carries a third page-name argument).
  - **Effort:** S

## 7. Views (F10)

*None.*

## 8. Style (F12) — one item per file

*None — the style debts ride the STM-09 split pass and the STM-01/STM-05 rewrites; see §10.*

## 9. Deferred / decisions

- [x] **STM-09** · M · DECISION · CTL-01 — split the 1,784-line controller?
  - **Why it is a decision:** D3 defers god-controller splits; this is a large behaviour-preserving refactor.
  - (a) ⭐ Defer to the split pass (D3): reduce this controller to the five live resource methods, move the 16 unrouted duplicates out (which also resolves STM-08, STM-10, STM-11, STM-12, STM-13, STM-14, STM-16).
  - (b) Split now, before any other fix: highest risk of breaking the live CRUD routes.
  - (c) Leave as-is and record as accepted technical debt.
  - ➜ Choice: (a) defer the split to the split pass, D3 (Tarun, 2026-10-16)
- [x] **STM-08** · M · DECISION · RTE-03 — what to do with the 16 unrouted live methods?
  - **Why it is a decision:** D5 prescribes `abort(403)` + NOT ROUTED comment, but the copies are live in the split controllers, so the work belongs to the same pass as STM-09; touching 16 bodies now is churn the split will redo.
  - (a) ⭐ Fold into the STM-09 split pass: remove the duplicates from this controller and leave the surviving names as `abort(403)` stubs with a NOT ROUTED comment (D5).
  - (b) Apply D5 `abort(403)` to all 16 bodies now, independently of the split.
  - (c) Leave as-is, record as accepted.
  - ➜ Choice: (b) apply D5 abort(403) now. All 28 unrouted public methods are stubs, 19 converted today, after R4 also unrouted index/create/store (Tarun, 2026-10-16)
- [x] **STM-06** · M · DECISION · AUTH-06 — `SmartTimetablePolicy` is registered but never consulted.
  - **Why it is a decision:** the registration lives in `SmartTimetableServiceProvider.php` (⚠ SHARED — every SmartTimetable controller sits behind it), and removing it or wiring it changes module-wide authorization behaviour.
  - (a) ⭐ Keep the working `Gate::authorize('tenant.smart-timetable.*')` permission strings; delete the dead `Gate::policy(Timetable::class, SmartTimetablePolicy::class)` registration at provider line 267 (⚠ SHARED).
  - (b) Keep as-is and record accepted (the policy is a harmless but misleading duplicate).
  - (c) Migrate the 14 permission strings to `$this->authorize('viewAny', $timetable)` policy calls during the split pass.
  - ➜ Choice: (b) keep as-is, record as accepted. Revisit with the module-wide Policy finding (Tarun, 2026-10-16)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| STM-02 | Logging discipline is removed by the STM-01 and STM-05 rewrites (no catch remains to hold `getMessage`). |
| STM-03 | Both try/catch wrappers are removed by STM-01 and STM-05 (D1). |
| STM-04 | The manual transaction in `destroy()` is replaced by the STM-01 closure (TXN-02). |
| STM-07 | The duplicate controller-level `Gate::authorize` in `update()` is dropped by the STM-05 rewrite; the FormRequest stays as the single check (AUTH-04). |
| STM-10 | Method-length debt is deferred with STM-09: four of the methods are unresolvable here because three of them are unrouted (CTL-02). |
| STM-11 | Route model binding needs the shared route files' parameter rename (`{smart_timetable_management}`), a route change (§9.3 stop condition); deferred to STM-09 (CTL-03). |
| STM-12 | `compact()` bloat sits in unrouted pages and the live-but-split `index()`; deferred to STM-09 (CTL-07). |
| STM-13 | The 9 dead private helpers and commented blocks are only reachable from the unrouted generation/preview chain; removal belongs to STM-09 (CTL-10). |
| STM-14 | Return-type additions on dead methods would be deleted by the split; typed on the live five with STM-01/STM-05 signatures (CTL-04). |
| STM-16 | The full-table activity/requirement loads sit in `index()`, which the split moves; grouping in SQL and dropping unread data go with STM-09 (QRY-05/15). |
| STM-17 | 29 leading-wildcard LIKE searches are confined to the three unrouted search methods (STM-08/STM-09); small tables today (QRY-08). |
| STM-18 | Controller style debts — emoji comments and `\Log::` die with the rewrites; import dedupe is covered while STM-05 is applied; the rest rides STM-09 (STY). |
| STM-19 | `UpdateTimetableRequest` emoji-marker comments only; no functional impact, scrub when the file is next touched (STY-04). |