# Status — SmartTimetable / SmartTimetableController

**Fixed:** 2026-10-16 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md` + retirement R4 from `../00-USAGE-AND-FIX-PLAN-2026-10-16.md`

## 1. Pre-applied work
none. The only PRE-APPLIED file (`tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md`) lists no file in this controller's scope.

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| STM-01 | `SmartTimetableController.php` `destroy()` | Replaced manual `beginTransaction`/`commit` plus `catch (\Exception)` with one `DB::transaction` closure and no catch (D1). The `'Failed to delete timetable: '.$e->getMessage()` leak is gone. The PUBLISHED guard and the `'Trashed'` log stay, with the log inside the transaction. Also closes STM-02, STM-03 and STM-04 for this method. | `grep -n "getMessage\|beginTransaction" …` | no output | 2026-10-16 |
| STM-05 | `SmartTimetableController.php` `update()` | Removed the `try`/`catch (\Throwable)`. The closure now returns the model and the redirect is built after commit. The explanatory publish comments are kept. Closes STM-02 and STM-03 for this method. | `grep -n "withInput\|catch (" …` | no output | 2026-10-16 |
| STM-07 | `update()` | Dropped the duplicate controller `Gate::authorize`. `UpdateTimetableRequest::authorize()` checks the same `tenant.smart-timetable.timetable.update` and runs first. A comment marks this. | read `UpdateTimetableRequest.php:27-30` | `can('tenant.smart-timetable.timetable.update')` | 2026-10-16 |
| **R4** | `routes/web.php:52-60` ⚠ SHARED (Tarun approved route removal 2026-10-16) | `Route::resource('smart-timetable-management')->only(['show','edit','update','destroy'])`. Retires `index`, `create` and `store`: no menu row, and the only inbound link is on the unrendered `validation/` view. | router probe | exactly 4 routes on this controller | 2026-10-16 |
| **R4** | `routes/api.php` ⚠ SHARED | Removed `apiResource('smarttimetables', SmartTimetableController::class)` and its `use`. It pointed a JSON API at a web controller that returns redirects and views. `primeapp`, `primeadmin` and both test trees have **0** callers. | `grep -rn smarttimetables primeapp primeadmin …` | no output | 2026-10-16 |
| STM-08 | `SmartTimetableController.php`, 28 methods | Every public method without a route is now `abort(403, 'This endpoint is not available.')` with a `NOT ROUTED` comment (D5, never deleted). **19 converted today:** `index`, `create`, `store`, `generate`, `preview`, `timetableConfig`, `timetableMaster`, `timetableGeneration`, `constraintManagement`, `preRequisitesSetup`, `timetableConfiguration`, `timetableMasters`, `timetableRequirement`, `constraintEngine`, `resourceAvailability`, `timetablePreparation`, `viewAndRefinement`, `reportsAndLogs`, `substituteManagement`. **9 were already stubs:** `generateWithPrime`, `storeTimetable`, `placeCell`, `removeCell`, `timetableOperation`, `timetableReports`, `timetableValidation`, `publishTimetable`, `unpublishTimetable`. This retires the **PHP-engine copies** in this file (`generate`, `generateWithPrime`, `preview`). Also closes STM-12, STM-16 and STM-17, whose code lived only in the stubbed methods. File: 1,764 → 1,005 lines. Pint removed the now-unused imports. | reflection: public methods with a route vs without | 4 live + 28 stubs | 2026-10-16 |
| STM-06 | — | DECISION (b): recorded as accepted. `SmartTimetablePolicy` stays registered and unconsulted, to be revisited with the module-wide Policy finding. | — | — | 2026-10-16 |
| STM-09 | — | DECISION (a): split deferred to the split pass (D3). | — | — | 2026-10-16 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| STM-15 | moot (R4) | `index()` is retired, so its 11 paginators no longer run |
| STM-09 | DECISION (a): deferred | God-controller split |
| STM-06 | DECISION (b): accepted | Counted as open M |
| STM-10 | deferred with STM-09 | Three of its four long methods are now stubs. `update()` (~100 lines) is still long, so it stays open H |
| STM-11 | deferred | Route-model binding needs a parameter rename, which is a route change (§9.3) |
| STM-13 | deferred with STM-09 | The ~10 private helpers of the generation/preview chain are now unreachable. Left in place per D5. Delete them in the split pass |
| STM-14, STM-18, STM-19 | deferred | Return types on dead methods; emoji/style scrub; FormRequest comment scrub |

## 4. Needs Tarun's hand
- Browser check on `/smart-timetable/timetable-generation?tab=timetable`: a row's **View** (should redirect to the workspace), **Edit** and save, and **Delete** on a non-published timetable.
- Nothing needs to be migrated, seeded or synced.

## 5. Unverifiable by this workflow (no tests, D4)
- `show()` and `edit()` were not executed, but neither was changed.
- Found during the router probe, **not caused by this pass:** `smart-timetable.smart-timetable-management.generate-for-class-section` points at `TimetableGenerationController::generateForClassSection`, **a method that does not exist**. It is one of the R5 PHP-engine routes, scheduled for retirement in that pass.
- `resources/views/validation/partials/_actions.blade.php:17` still calls `route('…smart-timetable-management.index')`, which no longer exists. No controller renders `smarttimetable::validation.index`, so this is an orphan blade and cannot 500. It is noted for C10 orphan cleanup.

## 6. Verification log
```
php -l controller + routes/web.php + routes/api.php        -> No syntax errors detected x3 (after Pint too)
vendor/bin/pint <3 files> --format agent                   -> controller fixed (unary_operator_spaces, no_unused_imports, not_operator_with_successor_space)
class_exists(SmartTimetableController)                     -> true
router probe (route:clear first)                           -> show · edit · update · destroy only; every SmartTimetable route's method exists
                                                              EXCEPT the pre-existing TimetableGenerationController@generateForClassSection
grep removed route names outside routes/                   -> validation/_actions.blade.php (orphan) + generated breadcrumb registries only;
                                                              no breadcrumb uses …management.index as a parent

Rolled-back runtime proof (tenant test.localhost, DB::beginTransaction … rollBack):
  destroy(4) [ARCHIVED]  -> RedirectResponse, flash "Timetable '100_placed_tt_1' has been deleted successfully."
                            trashed=true, cells 29840 -> 0, one 'Trashed' log; rolled back, still live
  update(12) [DRAFT] via UpdateTimetableRequest::validateResolved()
                         -> RedirectResponse to /smart-timetable/timetable-generation?tab=timetable,
                            flash "Timetable updated successfully.", name changed, one 'Updated' log; rolled back
```

## 7. Final state
Status: FIXED · Open: B 0 · H 1 (STM-10) · M 4 (STM-06 accepted, STM-09, STM-11, STM-13 deferred) · L 3 (STM-14, STM-18, STM-19)
