# SmartTimetable — Final Audit Index

Protocol: `.claude/rules/final-audit.md`.
⛔ Append a row to claim. Edit only your own row. Never rewrite this file.

| Controller | Status | B | H | M | L | Report | By | Updated |
|---|---|---|---|---|---|---|---|---|
| AnalyticsController | FIXED | 0 | 0 | 1 | 0 | [01-report](AnalyticsController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| RefinementController | FIXED | 0 | 0 | 2 | 0 | [01-report](RefinementController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| TimetablePublishController | FIXED | 0 | 0 | 2 | 0 | [01-report](TimetablePublishController-done/01-report.md) · [03-status](TimetablePublishController-done/03-status.md) | opencode / claude (fix) | 2026-10-15 |
| TimetableWorkspaceController | FIXED | 0 | 0 | 3 | 0 | [01-report](TimetableWorkspaceController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| ConstraintCategoryScopeController | FIXED | 0 | 0 | 1 | 0 | [01-report](ConstraintCategoryScopeController-done/01-report.md) · [03-status](ConstraintCategoryScopeController-done/03-status.md) | opencode / claude (fix) | 2026-10-15 |
| ConstraintTypeController | FIXED | 0 | 0 | 1 | 0 | [01-report](ConstraintTypeController-done/01-report.md) · [03-status](ConstraintTypeController-done/03-status.md) | opencode / claude (fix) | 2026-10-15 |
| TtGenerationStrategyController | FIXED | 0 | 0 | 0 | 0 | [01-report](TtGenerationStrategyController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| SubstitutionController | FIXED | 0 | 1 | 5 | 6 | [01-report](SubstitutionController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| TimetableExportController | FIXED | 0 | 1 | 2 | 2 | [01-report](TimetableExportController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| ParallelGroupController | FIXED | 0 | 0 | 1 | 3 | [01-report](ParallelGroupController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| ConstraintController | FIXED | 0 | 1 | 2 | 0 | [01-report](ConstraintController-done/01-report.md) · [03-status](ConstraintController-done/03-status.md) | opencode / claude (fix) | 2026-10-15 |
| TeacherUnavailableController | FIXED | 0 | 0 | 2 | 0 | [01-report](TeacherUnavailableController-done/01-report.md) · [03-status](TeacherUnavailableController-done/03-status.md) | opencode / claude (fix) | 2026-10-15 |
| RoomUnavailableController | FIXED | 0 | 0 | 1 | 0 | [01-report](RoomUnavailableController-done/01-report.md) · [03-status](RoomUnavailableController-done/03-status.md) | opencode / claude (fix) | 2026-10-15 |
| TimetableGenerationController | FIXED | 0 | 2 | 4 | 1 | [01-report](TimetableGenerationController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| TimetablePageController | FIXED | 0 | 0 | 1 | 0 | [01-report](TimetablePageController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| TimetablePreviewController | FIXED | 0 | 2 | 5 | 0 | [01-report](TimetablePreviewController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| TimetableMenuController | FIXED | 0 | 1 | 4 | 4 | [01-report](TimetableMenuController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| SmartTimetableController | FIXED | 0 | 1 | 4 | 3 | [01-report](SmartTimetableController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
| PythonTimetableController | FIXED | 0 | 2 | 3 | 2 | [01-report](PythonTimetableController-done/01-report.md) | opencode / claude (fix) | 2026-10-16 |
