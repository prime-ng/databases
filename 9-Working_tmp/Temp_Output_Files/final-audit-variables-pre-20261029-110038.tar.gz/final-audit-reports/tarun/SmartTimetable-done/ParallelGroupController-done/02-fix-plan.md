# Fix Plan — SmartTimetable / ParallelGroupController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `database/migrations/tenant/2026_07_09_000005_create_tt_parallel_groups_table.php` | Existing migration — never edit (standing rule). |
| `database/migrations/tenant/2026_07_09_000006_create_tt_parallel_group_activity_table.php` | Existing migration — never edit. A schema change is PGX-01 option (b), an additive migration, and runs only if Tarun writes that choice. |
| `config/permissionslist.php` | Shared config; nothing here changes a permission key. |
| `Modules/SmartTimetable/routes/web.php` | Route file; this plan adds, removes and re-scopes no route. |
| `Modules/TimetableFoundation/app/Models/Activity.php`, `Modules/TimetableFoundation/app/Models/AcademicTerm.php` | Owned by other reports; referenced only. |
| `resources/views/components/**` (incl. `breadcrum`, `table/action`) | Shared components; this plan edits no component. |

## 1. Blockers reachable today

- [x] **PGX-02** · H · MDL-03 · `Modules/SmartTimetable/app/Models/ParallelGroup.php:59-69` — filter soft-deleted pivot rows out of the `activities()` relation so removed activities stop counting as members.
  - **Touches:** `Modules/SmartTimetable/app/Models/ParallelGroup.php`
  - **Before** (`ParallelGroup.php:59-69`):
    ```php
        public function activities(): BelongsToMany
        {
            return $this->belongsToMany(
                Activity::class,
                'tt_parallel_group_activity',
                'parallel_group_id',
                'activity_id'
            )->withPivot(['sequence_order', 'is_anchor', 'is_active'])
             ->withTimestamps()
             ->orderByPivot('sequence_order');
        }
    ```
  - **After:**
    ```php
        public function activities(): BelongsToMany
        {
            return $this->belongsToMany(
                Activity::class,
                'tt_parallel_group_activity',
                'parallel_group_id',
                'activity_id'
            )->withPivot(['sequence_order', 'is_anchor', 'is_active'])
             ->withTimestamps()
             ->wherePivotNull('deleted_at')
             ->orderByPivot('sequence_order');
        }
    ```
  - **Verify:** `grep -n "wherePivotNull" Modules/SmartTimetable/app/Models/ParallelGroup.php`
  - **Expect:** one hit, inside `activities()` (the new line before `orderByPivot`).
  - **Effort:** S

- [x] **PGX-03** · H · VAL-05 · `Modules/SmartTimetable/app/Http/Requests/StoreParallelGroupRequest.php:44-52` and `UpdateParallelGroupRequest.php:49-57` — an unticked checkbox must become `false`, not `true`.
  - **Touches:** `Modules/SmartTimetable/app/Http/Requests/StoreParallelGroupRequest.php`, `Modules/SmartTimetable/app/Http/Requests/UpdateParallelGroupRequest.php`
  - **Before** (`StoreParallelGroupRequest.php:44-52`):
    ```php
        protected function prepareForValidation(): void
        {
            $this->merge([
                'requires_same_teacher' => $this->boolean('requires_same_teacher'),
                'requires_same_room_type' => $this->boolean('requires_same_room_type'),
                'is_hard_constraint' => $this->has('is_hard_constraint') ? $this->boolean('is_hard_constraint') : true,
                'is_active' => $this->has('is_active') ? $this->boolean('is_active') : true,
            ]);
        }
    ```
  - **Before** (`UpdateParallelGroupRequest.php:49-57`, identical body):
    ```php
        protected function prepareForValidation(): void
        {
            $this->merge([
                'requires_same_teacher' => $this->boolean('requires_same_teacher'),
                'requires_same_room_type' => $this->boolean('requires_same_room_type'),
                'is_hard_constraint' => $this->has('is_hard_constraint') ? $this->boolean('is_hard_constraint') : true,
                'is_active' => $this->has('is_active') ? $this->boolean('is_active') : true,
            ]);
        }
    ```
  - **After:**
    ```php
        protected function prepareForValidation(): void
        {
            $this->merge([
                'requires_same_teacher' => $this->boolean('requires_same_teacher'),
                'requires_same_room_type' => $this->boolean('requires_same_room_type'),
                'is_hard_constraint' => $this->boolean('is_hard_constraint'),
                'is_active' => $this->boolean('is_active'),
            ]);
        }
    ```
  - **Verify:** `grep -n "has('is_hard_constraint')\|has('is_active')" Modules/SmartTimetable/app/Http/Requests/StoreParallelGroupRequest.php Modules/SmartTimetable/app/Http/Requests/UpdateParallelGroupRequest.php`
  - **Expect:** no output.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

- (none) — the one latent-ARM change is PGX-01, filed under decisions in §9; PGX-02 must land with or before it.

## 3. Errors & transactions (F1/F2)

- [x] **PGX-04** · M · ERR-00 + ERR-05 + TXN-05 · `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php` — remove the hand-rolled `try/catch` from the five methods below and build the response after the transaction.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php`
  - **Before** (`ParallelGroupController.php:102-129`, `store()`):
    ```php
        public function store(StoreParallelGroupRequest $request)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.create');

            try {
                return DB::transaction(function () use ($request) {
                    $data = $request->validated();
                    $data['created_by'] = Auth::id();

                    $parallelGroup = ParallelGroup::create($data);

                    activityLog($parallelGroup, 'Stored', ['message' => 'ParallelGroup was stored.']);

                    return redirect()
                        ->route('smart-timetable.parallel-group.show', $parallelGroup->id)
                        ->with('success', 'Parallel group created successfully.');

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParallelGroupController::store failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** (`store()`):
    ```php
        public function store(StoreParallelGroupRequest $request)
        {
            $data = $request->validated();
            $data['created_by'] = Auth::id();

            $parallelGroup = DB::transaction(function () use ($data) {
                $parallelGroup = ParallelGroup::create($data);

                activityLog($parallelGroup, 'Stored', ['message' => 'ParallelGroup was stored.']);

                return $parallelGroup;
            });

            return redirect()
                ->route('smart-timetable.parallel-group.show', $parallelGroup->id)
                ->with('success', 'Parallel group created successfully.');
        }
    ```
  - **Before** (`ParallelGroupController.php:201-226`, `update()`):
    ```php
        public function update(UpdateParallelGroupRequest $request, $id)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.update');

            try {
                return DB::transaction(function () use ($request, $id) {
                    $parallelGroup = ParallelGroup::findOrFail($id);
                    $parallelGroup->update($request->validated());

                    activityLog($parallelGroup, 'Updated', ['message' => 'ParallelGroup was updated.']);

                    return redirect()
                        ->route('smart-timetable.parallel-group.show', $parallelGroup->id)
                        ->with('success', 'Parallel group updated successfully.');

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParallelGroupController::update failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** (`update()`):
    ```php
        public function update(UpdateParallelGroupRequest $request, ParallelGroup $parallelGroup)
        {
            DB::transaction(function () use ($request, $parallelGroup) {
                $parallelGroup->update($request->validated());

                activityLog($parallelGroup, 'Updated', ['message' => 'ParallelGroup was updated.']);
            });

            return redirect()
                ->route('smart-timetable.parallel-group.show', $parallelGroup->id)
                ->with('success', 'Parallel group updated successfully.');
        }
    ```
  - **Before** (`ParallelGroupController.php:231-256`, `destroy()`):
    ```php
        public function destroy($id)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.delete');

            try {
                return DB::transaction(function () use ($id) {
                    $parallelGroup = ParallelGroup::findOrFail($id);
                    $parallelGroup->delete();

                    activityLog($parallelGroup, 'Trashed', ['message' => 'ParallelGroup was trashed.']);

                    return redirect()
                        ->route('smart-timetable.parallel-group.index')
                        ->with('success', 'Parallel group deleted successfully.');

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParallelGroupController::destroy failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** (`destroy()`):
    ```php
        public function destroy(ParallelGroup $parallelGroup)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.delete');

            DB::transaction(function () use ($parallelGroup) {
                $parallelGroup->delete();

                activityLog($parallelGroup, 'Trashed', ['message' => 'ParallelGroup was trashed.']);
            });

            return redirect()
                ->route('smart-timetable.parallel-group.index')
                ->with('success', 'Parallel group deleted successfully.');
        }
    ```
  - **Before** (`ParallelGroupController.php:336-376`, `removeActivity()`):
    ```php
        public function removeActivity($groupId, $activityId)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.update');

            try {
                return DB::transaction(function () use ($groupId, $activityId) {
                    $parallelGroup = ParallelGroup::findOrFail($groupId);

                    $record = ParallelGroupActivity::where('parallel_group_id', $parallelGroup->id)
                        ->where('activity_id', $activityId)
                        ->whereNull('deleted_at')
                        ->firstOrFail();

                    $record->delete();

                    activityLog($parallelGroup, 'ActivityRemoved', [
                        'message'     => 'Activity was removed from the parallel group.',
                        'activity_id' => (int) $activityId,
                    ]);

                    return response()->json([
                        'success' => true,
                        'message' => 'Activity removed from parallel group.',
                    ]);

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParallelGroupController::removeActivity failed', ['error' => $e->getMessage()]);

                // AJAX endpoint — the caller reads JSON. A redirect would be followed by fetch()
                // and read as success.
                return response()->json([
                    'success' => false,
                    'message' => 'The operation could not be completed.',
                ], 500);
            }
        }
    ```
  - **After:** (`removeActivity()`):
    ```php
        public function removeActivity(ParallelGroup $parallelGroup, Activity $activity)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.update');

            DB::transaction(function () use ($parallelGroup, $activity) {
                $record = ParallelGroupActivity::where('parallel_group_id', $parallelGroup->id)
                    ->where('activity_id', $activity->id)
                    ->whereNull('deleted_at')
                    ->firstOrFail();

                $record->delete();

                activityLog($parallelGroup, 'ActivityRemoved', [
                    'message'     => 'Activity was removed from the parallel group.',
                    'activity_id' => (int) $activity->id,
                ]);
            });

            return response()->json([
                'success' => true,
                'message' => 'Activity removed from parallel group.',
            ]);
        }
    ```
  - **Before** (`ParallelGroupController.php:382-430`, `setAnchor()`):
    ```php
        public function setAnchor($groupId, $activityId)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.update');

            try {
                return DB::transaction(function () use ($groupId, $activityId) {
                    $parallelGroup = ParallelGroup::findOrFail($groupId);

                    // Verify activity is in this group
                    $record = ParallelGroupActivity::where('parallel_group_id', $parallelGroup->id)
                        ->where('activity_id', $activityId)
                        ->whereNull('deleted_at')
                        ->firstOrFail();

                    // Clear all anchors in this group
                    ParallelGroupActivity::where('parallel_group_id', $parallelGroup->id)
                        ->whereNull('deleted_at')
                        ->update(['is_anchor' => false]);

                    // Set this activity as anchor
                    $record->update(['is_anchor' => true]);

                    activityLog($parallelGroup, 'AnchorSet', [
                        'message'            => 'Anchor activity was set for the parallel group.',
                        'anchor_activity_id' => (int) $activityId,
                    ]);

                    return response()->json([
                        'success' => true,
                        'message' => 'Anchor activity set successfully.',
                        'anchor_activity_id' => (int) $activityId,
                    ]);

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParallelGroupController::setAnchor failed', ['error' => $e->getMessage()]);

                // AJAX endpoint — the caller reads JSON. A redirect would be followed by fetch()
                // and read as success.
                return response()->json([
                    'success' => false,
                    'message' => 'The operation could not be completed.',
                ], 500);
            }
        }
    ```
  - **After:** (`setAnchor()`):
    ```php
        public function setAnchor(ParallelGroup $parallelGroup, Activity $activity)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.update');

            DB::transaction(function () use ($parallelGroup, $activity) {
                // Verify activity is in this group
                $record = ParallelGroupActivity::where('parallel_group_id', $parallelGroup->id)
                    ->where('activity_id', $activity->id)
                    ->whereNull('deleted_at')
                    ->firstOrFail();

                // Clear all anchors in this group
                ParallelGroupActivity::where('parallel_group_id', $parallelGroup->id)
                    ->whereNull('deleted_at')
                    ->update(['is_anchor' => false]);

                // Set this activity as anchor
                $record->update(['is_anchor' => true]);

                activityLog($parallelGroup, 'AnchorSet', [
                    'message'            => 'Anchor activity was set for the parallel group.',
                    'anchor_activity_id' => (int) $activity->id,
                ]);
            });

            return response()->json([
                'success' => true,
                'message' => 'Anchor activity set successfully.',
                'anchor_activity_id' => (int) $activity->id,
            ]);
        }
    ```
  - **Verify:** `grep -n "catch (\|getMessage" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php`
  - **Expect:** only the two catches still present in `addActivities()` remain (they are removed by PGX-01); no `getMessage` in the five methods above.
  - **Effort:** M

## 4. Authorization (F3)

- (none) — the only F3 defect (AUTH-04, PGX-10) is resolved by the Gate removals inside PGX-04 and PGX-01; see §10.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **PGX-06** *(declined 2026-10-16 — keep Gate → findOrFail, same as TPB-05)* · M · CTL-03 · `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:134-145` and `:168-172` — use route-model binding in `show()` and `edit()`.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php`
  - **Before** (`ParallelGroupController.php:134-145`, `show()`):
    ```php
        public function show($id)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.view');

            $parallelGroup = ParallelGroup::with([
                'academicTerm',
                'activities.class',
                'activities.section',
                'activities.subject',
                'activities.studyFormat',
                'activities.teachers',
            ])->findOrFail($id);
    ```
  - **After:** (`show()`):
    ```php
        public function show(ParallelGroup $parallelGroup)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.view');

            $parallelGroup->load([
                'academicTerm',
                'activities.class',
                'activities.section',
                'activities.subject',
                'activities.studyFormat',
                'activities.teachers',
            ]);
    ```
  - **Before** (`ParallelGroupController.php:168-172`, `edit()`):
    ```php
        public function edit($id)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.update');

            $parallelGroup = ParallelGroup::findOrFail($id);
    ```
  - **After:** (`edit()`):
    ```php
        public function edit(ParallelGroup $parallelGroup)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.update');
    ```
  - **Verify:** `grep -n "function show\|function edit\|findOrFail" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php`
  - **Expect:** `function show(ParallelGroup $parallelGroup)`, `function edit(ParallelGroup $parallelGroup)`, and no `findOrFail` on either.
  - **Effort:** S

- [x] **PGX-07** · M · CTL-05 · `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:52-60`, `:76-90`, `:174-188` — replace the three copy-pasted dropdown loaders with private helpers.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php`
  - **Before** (`ParallelGroupController.php:52-60`, `index()`):
    ```php
            $academicTerms = AcademicTerm::active()->orderByDesc('id')->get();

            $groupTypes = [
                'PARALLEL_SECTION' => 'Section Parallel',
                'PARALLEL_OPTIONAL' => 'Optional Subject',
                'PARALLEL_SKILL' => 'Skill Subject',
                'PARALLEL_HOBBY' => 'Hobby',
                'PARALLEL_CUSTOM' => 'Custom',
            ];
    ```
  - **After:** (`index()`):
    ```php
            $academicTerms = $this->activeAcademicTerms();
            $groupTypes = $this->groupTypes();
    ```
  - **Before** (`ParallelGroupController.php:76-90`, `create()`):
    ```php
            $academicTerms = AcademicTerm::active()->orderByDesc('id')->get();

            $groupTypes = [
                'PARALLEL_SECTION' => 'Section Parallel',
                'PARALLEL_OPTIONAL' => 'Optional Subject',
                'PARALLEL_SKILL' => 'Skill Subject',
                'PARALLEL_HOBBY' => 'Hobby',
                'PARALLEL_CUSTOM' => 'Custom',
            ];

            $coordinationTypes = [
                'SAME_TIME' => 'Same Time Slot',
                'SAME_DAY' => 'Same Day',
                'SAME_PERIOD_RANGE' => 'Same Period Range',
            ];
    ```
  - **After:** (`create()`):
    ```php
            $academicTerms = $this->activeAcademicTerms();
            $groupTypes = $this->groupTypes();
            $coordinationTypes = $this->coordinationTypes();
    ```
  - **Before** (`ParallelGroupController.php:174-188`, `edit()`):
    ```php
            $academicTerms = AcademicTerm::active()->orderByDesc('id')->get();

            $groupTypes = [
                'PARALLEL_SECTION' => 'Section Parallel',
                'PARALLEL_OPTIONAL' => 'Optional Subject',
                'PARALLEL_SKILL' => 'Skill Subject',
                'PARALLEL_HOBBY' => 'Hobby',
                'PARALLEL_CUSTOM' => 'Custom',
            ];

            $coordinationTypes = [
                'SAME_TIME' => 'Same Time Slot',
                'SAME_DAY' => 'Same Day',
                'SAME_PERIOD_RANGE' => 'Same Period Range',
            ];
    ```
  - **After:** (`edit()`):
    ```php
            $academicTerms = $this->activeAcademicTerms();
            $groupTypes = $this->groupTypes();
            $coordinationTypes = $this->coordinationTypes();
    ```
  - **After:** (append these three private methods inside the class, immediately before its closing brace):
    ```php
        private function activeAcademicTerms()
        {
            return AcademicTerm::active()->orderByDesc('id')->get();
        }

        private function groupTypes(): array
        {
            return [
                'PARALLEL_SECTION' => 'Section Parallel',
                'PARALLEL_OPTIONAL' => 'Optional Subject',
                'PARALLEL_SKILL' => 'Skill Subject',
                'PARALLEL_HOBBY' => 'Hobby',
                'PARALLEL_CUSTOM' => 'Custom',
            ];
        }

        private function coordinationTypes(): array
        {
            return [
                'SAME_TIME' => 'Same Time Slot',
                'SAME_DAY' => 'Same Day',
                'SAME_PERIOD_RANGE' => 'Same Period Range',
            ];
        }
    ```
  - **Verify:** `grep -c "PARALLEL_SECTION' =>" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php`
  - **Expect:** 1 (the single copy inside `groupTypes()`).
  - **Effort:** S

- [x] **PGX-09** · M · VAL-02 · `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:437-443` — move the `autoDetect` validation into a FormRequest.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php`, `Modules/SmartTimetable/app/Http/Requests/AutoDetectParallelGroupsRequest.php` (new file)
  - **Before** (`ParallelGroupController.php:437-445`, `autoDetect()`):
    ```php
        public function autoDetect(Request $request)
        {
            Gate::authorize('tenant.smart-timetable.parallel-group.create');

            $request->validate([
                'academic_term_id' => 'required|integer|exists:tt_academic_terms,id',
            ]);

            $termId = (int) $request->academic_term_id;
    ```
  - **After:** (`autoDetect()`):
    ```php
        public function autoDetect(AutoDetectParallelGroupsRequest $request)
        {
            $termId = (int) $request->validated()['academic_term_id'];
    ```
  - **Before** (`ParallelGroupController.php:15-17`, the request imports):
    ```php
    use Modules\SmartTimetable\Http\Requests\AddActivitiesToParallelGroupRequest;
    use Modules\SmartTimetable\Http\Requests\StoreParallelGroupRequest;
    use Modules\SmartTimetable\Http\Requests\UpdateParallelGroupRequest;
    ```
  - **After:**
    ```php
    use Modules\SmartTimetable\Http\Requests\AddActivitiesToParallelGroupRequest;
    use Modules\SmartTimetable\Http\Requests\AutoDetectParallelGroupsRequest;
    use Modules\SmartTimetable\Http\Requests\StoreParallelGroupRequest;
    use Modules\SmartTimetable\Http\Requests\UpdateParallelGroupRequest;
    ```
  - **After:** (create `Modules/SmartTimetable/app/Http/Requests/AutoDetectParallelGroupsRequest.php` with):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;

    class AutoDetectParallelGroupsRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return auth()->user()->can('tenant.smart-timetable.parallel-group.create');
        }

        public function rules(): array
        {
            return [
                'academic_term_id' => 'required|integer|exists:tt_academic_terms,id',
            ];
        }

        public function attributes(): array
        {
            return [
                'academic_term_id' => 'academic term',
            ];
        }
    }
    ```
  - **Verify:** `grep -n "request->validate" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **PGX-13** · L · QRY-02 · `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:50` — page size 10 to match the module standard.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php`
  - **Before** (`ParallelGroupController.php:50`):
    ```php
            $parallelGroups = $query->orderByDesc('created_at')->paginate(20)->withQueryString();
    ```
  - **After:**
    ```php
            $parallelGroups = $query->orderByDesc('created_at')->paginate(10)->withQueryString();
    ```
  - **Verify:** `grep -n "paginate(10)" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php`
  - **Expect:** one hit at line 50.
  - **Effort:** S

## 7. Views (F10)

- [x] **PGX-14** · L · VIEW (UI standard) · `Modules/SmartTimetable/resources/views/parallel-group/index.blade.php:10-14` and `:107-126`; `show.blade.php:26-29` — gate the action buttons with `@can`.
  - **Touches:** `Modules/SmartTimetable/resources/views/parallel-group/index.blade.php`, `Modules/SmartTimetable/resources/views/parallel-group/show.blade.php`
  - **Before** (`index.blade.php:10-14`, "New Group" link):
    ```blade
                            <div class="d-flex gap-2">
                                <a href="{{ route('smart-timetable.parallel-group.create') }}" class="btn btn-sm btn-primary">
                                    <i class="fas fa-plus"></i> New Group
                                </a>
                            </div>
    ```
  - **After:**
    ```blade
                            <div class="d-flex gap-2">
                                @can('tenant.smart-timetable.parallel-group.create')
                                    <a href="{{ route('smart-timetable.parallel-group.create') }}" class="btn btn-sm btn-primary">
                                        <i class="fas fa-plus"></i> New Group
                                    </a>
                                @endcan
                            </div>
    ```
  - **Before** (`index.blade.php:107-126`, row actions):
    ```blade
                                        <td>
                                            <div class="d-flex gap-1">
                                                <a href="{{ route('smart-timetable.parallel-group.show', $group->id) }}"
                                                    class="btn btn-xs btn-outline-info" title="View">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="{{ route('smart-timetable.parallel-group.edit', $group->id) }}"
                                                    class="btn btn-xs btn-outline-primary" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form method="POST"
                                                    action="{{ route('smart-timetable.parallel-group.destroy', $group->id) }}"
                                                    onsubmit="return confirm('Delete this parallel group?')">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-xs btn-outline-danger" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
    ```
  - **After:**
    ```blade
                                        <td>
                                            <div class="d-flex gap-1">
                                                <a href="{{ route('smart-timetable.parallel-group.show', $group->id) }}"
                                                    class="btn btn-xs btn-outline-info" title="View">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                @can('tenant.smart-timetable.parallel-group.update')
                                                    <a href="{{ route('smart-timetable.parallel-group.edit', $group->id) }}"
                                                        class="btn btn-xs btn-outline-primary" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                @endcan
                                                @can('tenant.smart-timetable.parallel-group.delete')
                                                    <form method="POST"
                                                        action="{{ route('smart-timetable.parallel-group.destroy', $group->id) }}"
                                                        onsubmit="return confirm('Delete this parallel group?')">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="btn btn-xs btn-outline-danger" title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                @endcan
                                            </div>
                                        </td>
    ```
  - **Before** (`show.blade.php:25-32`, detail header buttons):
    ```blade
                    <div class="d-flex gap-2">
                        <a href="{{ route('smart-timetable.parallel-group.edit', $parallelGroup->id) }}"
                            class="btn btn-sm btn-primary">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="{{ route('smart-timetable.parallel-group.index') }}"
                            class="btn btn-sm btn-outline-secondary">Back</a>
                    </div>
    ```
  - **After:**
    ```blade
                    <div class="d-flex gap-2">
                        @can('tenant.smart-timetable.parallel-group.update')
                            <a href="{{ route('smart-timetable.parallel-group.edit', $parallelGroup->id) }}"
                                class="btn btn-sm btn-primary">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                        @endcan
                        <a href="{{ route('smart-timetable.parallel-group.index') }}"
                            class="btn btn-sm btn-outline-secondary">Back</a>
                    </div>
    ```
  - **Verify:** `grep -c "@can" Modules/SmartTimetable/resources/views/parallel-group/index.blade.php Modules/SmartTimetable/resources/views/parallel-group/show.blade.php`
  - **Expect:** 3 in `index.blade.php`, 1 in `show.blade.php`.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [x] **PGX-15** · L · STY-01 + STY-02 · add `declare(strict_types=1);` to the six PHP files and clean the controller's import block. Apply only after PGX-04, which makes two imports dead.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php`, `Modules/SmartTimetable/app/Http/Requests/StoreParallelGroupRequest.php`, `Modules/SmartTimetable/app/Http/Requests/UpdateParallelGroupRequest.php`, `Modules/SmartTimetable/app/Http/Requests/AddActivitiesToParallelGroupRequest.php`, `Modules/SmartTimetable/app/Models/ParallelGroup.php`, `Modules/SmartTimetable/app/Models/ParallelGroupActivity.php`
  - **Before** (first line of each of the six files):
    ```php
    <?php
    ```
  - **After:** (first lines of each of the six files):
    ```php
    <?php

    declare(strict_types=1);
    ```
  - **Before** (`ParallelGroupController.php:5-13`, imports):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;

    use Illuminate\Support\Facades\Log;

    use Illuminate\Support\Facades\DB;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\Gate;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    ```
  - **Verify:** `grep -rn "^declare(strict_types=1)" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php Modules/SmartTimetable/app/Http/Requests/StoreParallelGroupRequest.php Modules/SmartTimetable/app/Http/Requests/UpdateParallelGroupRequest.php Modules/SmartTimetable/app/Http/Requests/AddActivitiesToParallelGroupRequest.php Modules/SmartTimetable/app/Models/ParallelGroup.php Modules/SmartTimetable/app/Models/ParallelGroupActivity.php | wc -l`
  - **Expect:** 6.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **PGX-01** · H · DECISION · VAL-04 — re-adding a removed activity fails against the pivot unique index `uq_pga_group_activity`. Which fix?
  - **Why it is a decision:** option (b) changes the schema (needs an additive migration); option (a) is a controller-only fix.
  - (a) ⭐ Reuse the soft-deleted pivot in `addActivities()`: pre-fetch the group's pivots with `withTrashed()->keyBy('activity_id')`; for an existing **trashed** row call `restore()` and set the new `sequence_order`/`is_anchor`; for a live row skip; only `insert()` brand-new pairs. Fixes re-add and removes the per-row query/insert loop (PGX-05) in the same rewrite. No migration.
  - (b) Add an additive tenant migration that drops and recreates `uq_pga_group_activity` as `UNIQUE (parallel_group_id, activity_id, deleted_at)`, so a new live row can coexist with the trashed one. Changes the schema; must be run by Tarun (`php artisan tenants:migrate`).
  - (c) Leave as is and document that an activity removed from a group cannot be added back.
  - ➜ Choice: **(a)** — revive the soft-deleted pivot in `addActivities()`, no migration (Tarun, 2026-10-16). Also closes PGX-05.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PGX-05 | The per-row `exists()`/`create()` loop lives in `addActivities()`, which the PGX-01 rewrite (option (a)) replaces with a pre-fetch plus bulk write. |
| PGX-08 | `autoDetect`'s `->get()->groupBy()` is bounded by one academic term; aggregating in SQL is an optional refactor, not a shipping blocker. Recorded as informational. |
| PGX-10 | The duplicate `Gate::authorize()` calls in `store`/`update`/`addActivities` are removed by the PGX-04 and PGX-01 rewrites (FormRequest `authorize()` keeps the guard). |
| PGX-11 | Return types are adopted where methods are rewritten (PGX-04, PGX-06, PGX-09); the two remaining read methods (`index`, `create`) are style-only and left to the next style pass. |
| PGX-12 | The leading-wildcard `LIKE` runs on `tt_parallel_groups`, a small table (0 live rows); accepted, revisit only if the table grows. |
