# Status — SmartTimetable / ParallelGroupController

**Fixed:** 2026-10-16 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

Decisions (Tarun, 2026-10-16):
- PGX-01: option (a). Revive the soft-deleted pivot row in `addActivities()`. No migration.
- PGX-06: declined. Keep `$id` parameters with Gate → `findOrFail()` so a user without permission gets the same 403 for real and missing ids (same as TimetablePublish TPB-05). PGX-04 was therefore applied **without** the route-model-binding part of its After blocks.

## 1. Pre-applied work
none

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| PGX-02 | ParallelGroup.php:72 | `activities()` adds `->wherePivotNull('deleted_at')`, so removed members no longer count, render or reach `getAnchorActivity()` / `getMemberActivities()` / `hasAnchor()`. | `grep -n wherePivotNull ParallelGroup.php` | 72 | 2026-10-16 |
| PGX-03 | StoreParallelGroupRequest.php:51-53, UpdateParallelGroupRequest.php:56-58 | `is_hard_constraint` / `is_active` now use `$this->boolean(...)`. An unticked box saves `false`. Both forms render both checkboxes (create.blade.php:139/152, edit.blade.php:139/151), and the create form still defaults both to checked. | `grep -n "has('is_hard_constraint')\|has('is_active')"` | no output | 2026-10-16 |
| PGX-04 | ParallelGroupController.php (store, update, destroy, addActivities, removeActivity, setAnchor) | All six try/catch blocks removed (D1). Each write runs in a `DB::transaction` closure, and the redirect/JSON is built after it. `findOrFail()` and `Gate::authorize()` stay **outside** the closure, Gate first. The `Log` and `ModelNotFoundException` imports are gone. | `grep -n "catch (\|getMessage\|Log::"` | no output | 2026-10-16 |
| PGX-01 + PGX-05 | ParallelGroupController.php addActivities() | Reads the group's pivots once with `withTrashed()->lockForUpdate()->keyBy('activity_id')`. A live row is skipped, a trashed row is `restore()`d with a new `sequence_order`, and new pairs go in one `insert()`. The log carries `added`/`restored`/`skipped`, and an all-duplicates call logs nothing. | rolled-back replay (§6) | add → dup skip → remove → re-add OK, 1 row for the pair | 2026-10-16 |
| PGX-07 | ParallelGroupController.php | `activeAcademicTerms()`, `groupTypes()`, `coordinationTypes()` private helpers; `index`/`create`/`edit` call them. | `grep -c "PARALLEL_SECTION' =>"` | 1 | 2026-10-16 |
| PGX-09 | new `Http/Requests/AutoDetectParallelGroupsRequest.php`; controller autoDetect() | Inline `validate()` moved to a FormRequest. It authorizes `.create`, and the controller Gate is kept. | `grep -n "request->validate"` | no output | 2026-10-16 |
| PGX-11 | ParallelGroupController.php | Every public method now declares its return type (`View` / `RedirectResponse` / `JsonResponse`), including `index` and `create`. | `grep -n "public function"` | all typed | 2026-10-16 |
| PGX-13 | ParallelGroupController.php index() | `paginate(20)` → `paginate(10)` | `grep -n "paginate(10)"` | 1 hit | 2026-10-16 |
| PGX-14 | index.blade.php, show.blade.php | New Group → `@can(.create)`; row Edit → `@can(.update)`; row Delete → `@can(.delete)`; show Edit → `@can(.update)`. | `grep -c "@can("` | index 3, show 1 | 2026-10-16 |
| PGX-15 | controller, 4 requests (incl. new), 2 models | `declare(strict_types=1)` on all, imports sorted, dead imports removed. | `grep -c "^declare(strict_types=1)"` | 7 files × 1 | 2026-10-16 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| PGX-06 | blocked by decision | Route-model binding resolves the record before the Gate (an existence oracle: 404 vs 403). Methods keep `$id` with Gate → `findOrFail()`, and the controller docblock records why. |
| PGX-10 | superseded by the PGX-06 decision | The plan removed the controller Gate on `store`/`update` and relied on the FormRequest. The Gate is kept instead, so every method visibly authorizes first. The duplicate check costs one cached permission lookup. |
| PGX-08 | informational (plan §10) | `autoDetect` groups in PHP. It is bounded by one term, so it is left as is. |
| PGX-12 | accepted (plan §10) | Leading-wildcard `LIKE` on a small table. |

## 4. Needs Tarun's hand
- **Browser check:** `/smart-timetable/parallel-group`:
  - Create a group with "Active" unticked. Expect it to save Inactive.
  - Add an activity, remove it, then add it back. Expect success; it used to fail with 1062.
  - The list paginates at 10.
  - A role without `.update`/`.delete` sees no Edit/Delete buttons.
- **Behaviour change:** a failed save used to redirect back with "The operation could not be completed." Page actions now get the central handler's error page; AJAX actions get `{success:false, message}` (500), which the existing JS already handles. This is the D1 standard.
- No migration, seeder or permission sync is needed.

## 5. Unverifiable by this workflow (no tests, D4)
- The `@can` gates (PGX-14): the check here ran as super-admin, which bypasses `Gate::before`.
- `lockForUpdate()` in `addActivities()` serialising two concurrent adds to the same group.

## 6. Verification log
```
$ vendor/bin/pint <7 files> --format agent → fixed (no_extra_blank_lines, method_chaining_indentation)
$ php -l (7 files) → No syntax errors detected
$ class_exists × 7 → OK (controller, 4 requests, 2 models)
$ router probe → 11 ParallelGroupController routes, every action method exists
$ blade compile → create/edit/index/show OK; @push declared/emitted 0/0, 0/0, 0/0, 1/1
$ grep "catch (\|getMessage\|Log::" ParallelGroupController.php → no output
$ rolled-back replay (throwaway group PGXTMP, activity 1):
  add1   : {"success":true,"message":"Added 1 activities. Skipped 0 duplicates.","added":1,"skipped":0}
  dup    : {"success":true,"message":"Added 0 activities. Skipped 1 duplicates.","added":0,"skipped":1}
  rem    : {"success":true,"message":"Activity removed from parallel group."}
  members after remove (PGX-02): 0
  re-add (PGX-01): {"success":true,"message":"Added 1 activities. Skipped 0 duplicates.","added":1,"skipped":0}
  rows for pair: 1
$ leftover tt_parallel_groups code=PGXTMP → 0
```

## 7. Final state
Status: FIXED · Open: B 0 · H 0 · M 1 · L 3 (PGX-06 declined; PGX-10 superseded; PGX-08, PGX-12 accepted)
