# Fix Plan — SmartTimetable / TtGenerationStrategyController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `routes/tenant.php` | shared route file — owned by the route-registration decision (TGS-07), not by this plan unless that item is ticked |
| `Modules/SmartTimetable/routes/web.php` | shared route file |
| `Modules/TimetableFoundation/routes/web.php` | shared route file |
| `config/permissionslist.php` | shared permission registry |
| `Modules/SmartTimetable/app/Providers/SmartTimetableServiceProvider.php` | shared provider (policy registration) |
| `Modules/SmartTimetable/resources/views/index.blade.php` | rendered by `TimetableMenuController` / `SmartTimetableController`, owned by their reports |
| `Modules/TimetableFoundation/resources/views/pages/partials/timetable-configuration/generation-strategy/_list.blade.php` | rendered by `TimetableMenuController`, owned by its report |
| `database/migrations/**` | never edit an existing migration |

## 1. Blockers reachable today

- [ ] **TGS-01** · B · ERR-01 · `TtGenerationStrategyController.php:39-86` — stop leaking the exception message, remove the controller try/catch and the manual transactions, and de-duplicate the store/update input.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php`
  - **Before** (`TtGenerationStrategyController.php:39-86`):
    ```php
    public function store(TimetableGenerationStrategyRequest $request)
    {
        Gate::authorize('tenant.smart-timetable.timetable-generation-strategy.create');

        DB::beginTransaction();

        try {
            $data = $request->validated();

            $data['is_default'] = $request->has('is_default') ? 1 : 0;
            $data['is_active'] = $request->has('is_active') ? 1 : 0;

            if ($request->filled('parameters_json')) {
                try {
                    $data['parameters_json'] = json_decode($request->parameters_json, true);
                } catch (\Exception $e) {
                    return redirect()->back()
                        ->withInput()
                        ->with('error', 'Invalid JSON format in parameters field.');
                }
            } else {
                $data['parameters_json'] = [];
            }

            if ($data['is_default']) {
                TtGenerationStrategy::query()->update(['is_default' => false]);
            }

            $strategy = TtGenerationStrategy::create($data);

            activityLog($strategy, 'Stored', [
                'message' => 'A new timetable generation strategy was created.',
                'algorithm' => $strategy->algorithm_type,
                'performed_by' => Auth::user()->name,
            ]);

            DB::commit();

            return redirect()
                ->route('smart-timetable.menu.timetableConfiguration')
                ->with('success', flash('created.generation-strategy'));
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()
                ->withInput()
                ->with('error', 'Failed to create generation strategy: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function store(TimetableGenerationStrategyRequest $request)
    {
        DB::transaction(function () use ($request) {
            $data = $this->strategyInput($request);

            if ($data['is_default']) {
                TtGenerationStrategy::query()->update(['is_default' => false]);
            }

            $strategy = TtGenerationStrategy::create($data);

            activityLog($strategy, 'Stored', [
                'message' => 'A new timetable generation strategy was created.',
                'algorithm' => $strategy->algorithm_type,
                'performed_by' => Auth::user()->name,
            ]);
        });

        return redirect()
            ->route('smart-timetable.menu.timetableConfiguration')
            ->with('success', flash('created.generation-strategy'));
    }
    ```
  - **Before** (`TtGenerationStrategyController.php:123-189`, method `update()`):
    ```php
    public function update(TimetableGenerationStrategyRequest $request, TtGenerationStrategy $generation_strategy)
    {
        Gate::authorize('tenant.smart-timetable.timetable-generation-strategy.update');

        DB::beginTransaction();

        try {
            $data = $request->validated();

            // Store original values for activity log
            $original = $generation_strategy->getOriginal();

            // Convert checkbox fields
            $data['is_default'] = $request->has('is_default') ? 1 : 0;
            $data['is_active'] = $request->has('is_active') ? 1 : 0;

            // Parse JSON parameters
            if ($request->filled('parameters_json')) {
                try {
                    $data['parameters_json'] = json_decode($request->parameters_json, true);
                } catch (\Exception $e) {
                    return redirect()->back()
                        ->withInput()
                        ->with('error', 'Invalid JSON format in parameters field.');
                }
            } else {
                $data['parameters_json'] = [];
            }

            // If this strategy is set as default, update other strategies
            if ($data['is_default'] && !$generation_strategy->is_default) {
                TtGenerationStrategy::where('id', '!=', $generation_strategy->id)
                    ->update(['is_default' => false]);
            }

            $generation_strategy->update($data);

            // Prepare changes for activity log
            $changes = $generation_strategy->getChanges();
            $changedAttributes = [];
            foreach ($changes as $field => $newValue) {
                if ($field === 'updated_at') continue;
                $changedAttributes[$field] = [
                    'old' => $original[$field] ?? null,
                    'new' => $newValue,
                ];
            }

            // Activity log
            activityLog($generation_strategy, 'Updated', [
                'message' => 'Timetable generation strategy was updated.',
                'changes' => $changedAttributes,
                'performed_by' => Auth::user()->name,
            ]);

            DB::commit();

            return redirect()
                ->route('smart-timetable.menu.timetableConfiguration')
                ->with('success', flash('updated.generation-strategy'));
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()
                ->withInput()
                ->with('error', 'Failed to update generation strategy: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function update(TimetableGenerationStrategyRequest $request, TtGenerationStrategy $generation_strategy)
    {
        DB::transaction(function () use ($request, $generation_strategy) {
            $data = $this->strategyInput($request);
            $original = $generation_strategy->getOriginal();

            if ($data['is_default'] && ! $generation_strategy->is_default) {
                TtGenerationStrategy::where('id', '!=', $generation_strategy->id)
                    ->update(['is_default' => false]);
            }

            $generation_strategy->update($data);

            $changedAttributes = [];
            foreach ($generation_strategy->getChanges() as $field => $newValue) {
                if ($field === 'updated_at') {
                    continue;
                }
                $changedAttributes[$field] = [
                    'old' => $original[$field] ?? null,
                    'new' => $newValue,
                ];
            }

            activityLog($generation_strategy, 'Updated', [
                'message' => 'Timetable generation strategy was updated.',
                'changes' => $changedAttributes,
                'performed_by' => Auth::user()->name,
            ]);
        });

        return redirect()
            ->route('smart-timetable.menu.timetableConfiguration')
            ->with('success', flash('updated.generation-strategy'));
    }
    ```
  - **Before** (`TtGenerationStrategyController.php:194-224`, method `destroy()`):
    ```php
    public function destroy(TtGenerationStrategy $generation_strategy)
    {
        Gate::authorize('tenant.smart-timetable.timetable-generation-strategy.delete');

        DB::beginTransaction();

        try {
            if ($generation_strategy->is_default) {
                return redirect()->back()
                    ->with('error', 'Cannot delete the default generation strategy. Please set another strategy as default first.');
            }

            $generation_strategy->update(['is_active' => false]);
            $generation_strategy->delete();

            activityLog($generation_strategy, 'Trashed', [
                'message' => 'Timetable generation strategy was deactivated and deleted.',
                'performed_by' => Auth::user()->name,
            ]);

            DB::commit();

            return redirect()
                ->route('smart-timetable.menu.timetableConfiguration')
                ->with('success', flash('trashed.generation-strategy'));
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()
                ->with('error', 'Failed to delete generation strategy: ' . $e->getMessage());
        }
    }
    ```
  - **After:**
    ```php
    public function destroy(TtGenerationStrategy $generation_strategy)
    {
        Gate::authorize('tenant.smart-timetable.timetable-generation-strategy.delete');

        if ($generation_strategy->is_default) {
            return redirect()->back()
                ->with('error', 'Cannot delete the default generation strategy. Please set another strategy as default first.');
        }

        DB::transaction(function () use ($generation_strategy) {
            $generation_strategy->update(['is_active' => false]);
            $generation_strategy->delete();

            activityLog($generation_strategy, 'Trashed', [
                'message' => 'Timetable generation strategy was deactivated and deleted.',
                'performed_by' => Auth::user()->name,
            ]);
        });

        return redirect()
            ->route('smart-timetable.menu.timetableConfiguration')
            ->with('success', flash('trashed.generation-strategy'));
    }
    ```
  - **Before** (`TtGenerationStrategyController.php:273-316`, method `toggleDefault()`):
    ```php
    public function toggleDefault(Request $request, TtGenerationStrategy $generation_strategy)
    {
        Gate::authorize('tenant.smart-timetable.timetable-generation-strategy.update');

        $request->validate([
            'is_default' => 'required|boolean',
        ]);

        $newStatus = $request->input('is_default');

        DB::beginTransaction();

        try {
            // If setting as default, unset other default strategies
            if ($newStatus) {
                TtGenerationStrategy::where('id', '!=', $generation_strategy->id)
                    ->update(['is_default' => false]);
            }

            $generation_strategy->is_default = $newStatus;
            $generation_strategy->save();

            activityLog($generation_strategy, 'Default Toggled', [
                'message' => 'Generation strategy default status was updated.',
                'status' => $newStatus ? 'Set as Default' : 'Removed as Default',
                'performed_by' => Auth::user()->name,
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'is_default' => $generation_strategy->is_default,
                'message' => flash('default_status_updated.generation-strategy')
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'is_default' => $generation_strategy->is_default,
                'message' => 'Failed to update default status: ' . $e->getMessage()
            ]);
        }
    }
    ```
  - **After:**
    ```php
    public function toggleDefault(Request $request, TtGenerationStrategy $generation_strategy)
    {
        Gate::authorize('tenant.smart-timetable.timetable-generation-strategy.update');

        $request->validate([
            'is_default' => 'required|boolean',
        ]);

        $newStatus = $request->boolean('is_default');

        DB::transaction(function () use ($newStatus, $generation_strategy) {
            if ($newStatus) {
                TtGenerationStrategy::where('id', '!=', $generation_strategy->id)
                    ->update(['is_default' => false]);
            }

            $generation_strategy->is_default = $newStatus;
            $generation_strategy->save();

            activityLog($generation_strategy, 'Default Toggled', [
                'message' => 'Generation strategy default status was updated.',
                'status' => $newStatus ? 'Set as Default' : 'Removed as Default',
                'performed_by' => Auth::user()->name,
            ]);
        });

        return response()->json([
            'success' => true,
            'is_default' => $generation_strategy->is_default,
            'message' => flash('default_status_updated.generation-strategy'),
        ]);
    }
    ```
  - **Before** (`TtGenerationStrategyController.php:373-375`, end of class):
    ```php
        return $descriptions[$algorithmType] ?? 'Algorithm description not available.';
    }
}
    ```
  - **After:**
    ```php
        return $descriptions[$algorithmType] ?? 'Algorithm description not available.';
    }

    /**
     * Normalise create and update input into model attributes.
     */
    private function strategyInput(TimetableGenerationStrategyRequest $request): array
    {
        $data = $request->validated();
        $data['is_default'] = $request->boolean('is_default');
        $data['is_active'] = $request->boolean('is_active');
        $data['parameters_json'] = $request->filled('parameters_json')
            ? json_decode($request->parameters_json, true)
            : [];

        return $data;
    }
}
    ```
  - **Verify:** `grep -n "getMessage\|beginTransaction\|DB::commit\|DB::rollBack" Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php`
  - **Expect:** no output.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **TGS-03** · M · CTL-10 · `TimetableGenerationStrategyRequest.php:66` — make invalid JSON fail validation instead of being silently nulled and discarded.
  - **Touches:** `Modules/SmartTimetable/app/Http/Requests/TimetableGenerationStrategyRequest.php`
  - **Before** (`TimetableGenerationStrategyRequest.php:66`):
    ```php
    'parameters_json' => 'nullable|string',
    ```
  - **After:**
    ```php
    'parameters_json' => 'nullable|string|json',
    ```
  - **Before** (`TimetableGenerationStrategyRequest.php:90-102`):
    ```php
    protected function prepareForValidation(): void
    {
        // Ensure JSON is properly formatted
        if ($this->has('parameters_json') && is_string($this->parameters_json)) {
            try {
                json_decode($this->parameters_json, true, 512, JSON_THROW_ON_ERROR);
            } catch (\JsonException $e) {
                $this->merge([
                    'parameters_json' => null
                ]);
            }
        }
    }
    ```
  - **After:**
    ```php
    protected function prepareForValidation(): void
    {
        if ($this->has('parameters_json') && is_string($this->parameters_json)) {
            $this->merge([
                'parameters_json' => trim($this->parameters_json),
            ]);
        }
    }
    ```
  - **Verify:** `grep -n "parameters_json" Modules/SmartTimetable/app/Http/Requests/TimetableGenerationStrategyRequest.php`
  - **Expect:** the rules line reads `'parameters_json' => 'nullable|string|json',` and `prepareForValidation()` contains only the `trim()` merge.
  - **Effort:** S

## 4. Authorization (F3)

None. (TGS-06 is folded into item TGS-01; TGS-05 is the DECISION item in §9.)

## 5. Validation, routes, models (F4/F5/F7)

None. (TGS-07 is the DECISION item in §9.)

## 6. Queries & performance (F9)

- [ ] **TGS-11** · L · QRY-13 · `TtGenerationStrategyController.php:233-235` — keep the query string on the trash paginator.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php`
  - **Before** (`TtGenerationStrategyController.php:233-235`):
    ```php
    $strategies = TtGenerationStrategy::onlyTrashed()
        ->orderBy('deleted_at', 'desc')
        ->paginate(10);
    ```
  - **After:**
    ```php
    $strategies = TtGenerationStrategy::onlyTrashed()
        ->orderBy('deleted_at', 'desc')
        ->paginate(10)
        ->withQueryString();
    ```
  - **Verify:** `grep -n "withQueryString" Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php`
  - **Expect:** one match after the `paginate(10)` chain.
  - **Effort:** S

## 7. Views (F10)

- [ ] **TGS-12** · M · AUTH-06 · `show.blade.php:15,208,214` — use the canonical permission spelling in the show view.
  - **Touches:** `Modules/SmartTimetable/resources/views/timetable-generation-strategy/show.blade.php`
  - **Before** (`show.blade.php:15-17`):
    ```php
                            @can('tenant.smart-timetable.generation-strategy.update')
                                <a href="{{ route('timetable-foundation.generation-strategies.edit', $generation_strategy->id) }}"
                                    class="btn btn-sm btn-warning">
    ```
  - **After:**
    ```php
                            @can('tenant.smart-timetable.timetable-generation-strategy.update')
                                <a href="{{ route('timetable-foundation.generation-strategies.edit', $generation_strategy->id) }}"
                                    class="btn btn-sm btn-warning">
    ```
  - **Before** (`show.blade.php:208-209`):
    ```php
                                    @can('tenant.smart-timetable.generation-strategy.update')
                                        <a href="{{ route('timetable-foundation.generation-strategies.edit', $generation_strategy->id) }}"
    ```
  - **After:**
    ```php
                                    @can('tenant.smart-timetable.timetable-generation-strategy.update')
                                        <a href="{{ route('timetable-foundation.generation-strategies.edit', $generation_strategy->id) }}"
    ```
  - **Before** (`show.blade.php:214`):
    ```php
                                    @can('tenant.smart-timetable.generation-strategy.delete')
    ```
  - **After:**
    ```php
                                    @can('tenant.smart-timetable.timetable-generation-strategy.delete')
    ```
  - **Verify:** `grep -n "smart-timetable.generation-strategy" Modules/SmartTimetable/resources/views/timetable-generation-strategy/show.blade.php`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

None in this plan. TGS-13, TGS-14 and TGS-15 are recorded in §10; a Pint run on touched files is covered by the fixer protocol (run `vendor/bin/pint` on every file an item touches).

## 9. Deferred / decisions

- [ ] **TGS-05** · M · DECISION · AUTH-06 — the registered `TimetableGenerationStrategyPolicy` is never consulted because every check uses a string ability.
  - **Why it is a decision:** making the policy live changes the shape of every authorization call; deleting it removes a registered class another surface may reference.
  - (a) ⭐ keep the policy registered as documentation and record it as accepted; revisit when the controller is re-routed (TGS-07)
  - (b) switch the controller to model-argument checks (`$this->authorize('create', TtGenerationStrategy::class)`) so the policy is the single source of truth
  - (c) delete the policy and the `Gate::policy()` registration
  - ➜ Choice: moot — controller retired (R1, Tarun 2026-10-16)

- [ ] **TGS-07** · H · DECISION · RTE-03 — the controller has no routes at all; the route files cross-reference each other. ⚠ SHARED
  - **Why it is a decision:** it needs an edit to a shared route file, and either restoring routes or D5-disabling the methods is a behaviour decision Tarun owns.
  - (a) ⭐ restore the routes the views already expect (`timetable-foundation.generation-strategies` resource plus the custom names `toggleDefault`, `trashed`, `restore`, `forceDelete`, `toggleStatus`, `getAlgorithmParameters`) in `Modules/SmartTimetable/routes/web.php`, then run the fixer again
  - (b) apply D5: turn `index`, `create`, `store`, `show`, `edit`, `update`, `destroy`, `trashed`, `toggleDefault` and `getAlgorithmParameters` into `abort(403, '…')` with a `// NOT ROUTED` comment, and delete the now-dead views
  - (c) leave the controller as-is and record the feature as intentionally disabled
  - ➜ Choice: retire — methods stubbed, tab hidden (R1, Tarun 2026-10-16)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| TGS-02 | Covered by item TGS-01, which removes the controller try/catch. |
| TGS-04 | Covered by item TGS-01, which replaces the manual transactions with `DB::transaction()` closures. |
| TGS-06 | Covered by item TGS-01, which drops the duplicate `Gate::authorize()` calls from `store()` and `update()` while keeping the FormRequest `authorize()`. |
| TGS-08 | CTL-04 return types: a cosmetic change across 13 signatures; deferred to a typing pass, no behaviour change. |
| TGS-09 | Covered by item TGS-01, which extracts `strategyInput()` and removes the duplicated block. |
| TGS-10 | CTL-06: `getAlgorithmParameters()` is unrouted (TGS-07); moving its maps to the model is deferred until the route decision is made. |
| TGS-13 | STY-01 `strict_types`: bundled into the Pint/style pass; no behaviour change alone. |
| TGS-14 | STY-02 Pint: run `vendor/bin/pint` on each file an applied item touches; enumerated here rather than as a separate item. |
| TGS-15 | STY-04 commented-out Blade blocks: cosmetic; deferred to the view cleanup that follows the TGS-07 route decision. |
