# Final Audit — SmartTimetable / TtGenerationStrategyController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php` (375 lines, 13 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/timetable-configuration?tab=generation-strategy` (the only reachable list, rendered by TimetableMenuController). The controller's own pages would be `/smart-timetable/generation-strategies`, `/smart-timetable/generation-strategies/create`, `/smart-timetable/generation-strategies/{id}`, `/smart-timetable/generation-strategies/{id}/edit`, `/smart-timetable/generation-strategies/trash` — none of these routes exist. |
| Menu path | Smart Timetable → Timetable Configuration → Generation Strategy tab |
| Who uses it | Roles holding `tenant.smart-timetable.timetable-generation-strategy.*`: Super Admin (role 1) and School Admin (role 2) on `test.localhost`. |
| What a user does here | A school admin defines "generation strategies" — named algorithm presets (Recursive, Genetic, Simulated Annealing, Tabu Search, Hybrid) with per-algorithm parameters and an activity-sorting method. One strategy can be flagged default and toggled active. |
| Tables written | `tt_generation_strategies` (create, update, soft delete, default flag), plus the audit table written by the `activityLog()` helper (`sys_activity_logs`). |
| Tables read | `tt_generation_strategies`. |
| Live data | `tt_generation_strategies`: 0 live, 0 trashed, 0 default on `test.localhost` (tenant `xyz_school_00000000000040008000_202627`). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No. This controller is **not production-ready** — it is not even reachable. `route:list` (uncached) shows **zero** routes pointing at `TtGenerationStrategyController@`, so every one of its ten non-disabled public methods is dead; the two route files that should register it cross-reference each other and both point at a route that does not exist. The single worst finding is **TGS-07** (no routes at all): the CRUD features the controller implements cannot be opened in a browser, and the views still call `route('timetable-foundation.generation-strategies.*')`, which throws when reached from another page. The second-worst is **TGS-01** (B): every failure path shows the raw Laravel/SQL exception text to the user. Effort to apply the plan: **M** (roughly 1 day, most of it the reachability decision).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 1 | 7 | 6 | 2 | 15 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TGS-01, TGS-02 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | TGS-04 | F9 Queries/Perf | TGS-11 |
| F3 Authorization | TGS-05, TGS-06 | F10 Views | TGS-12 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | TGS-07 | F12 Style | TGS-13, TGS-14, TGS-15 |
| F6 Controller shape | TGS-03, TGS-08, TGS-09, TGS-10 | F13 Deep read | table below |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php` | controller | 375 | this report | ✅ |
| 2 | `Modules/SmartTimetable/app/Http/Requests/TimetableGenerationStrategyRequest.php` | form request | 103 | this report | ✅ |
| 3 | `Modules/SmartTimetable/app/Models/TtGenerationStrategy.php` | model | 320 | this report (pre-assigned) | ✅ |
| 4 | `Modules/SmartTimetable/app/Models/Activity.php` | model alias | 12 | this report (pre-assigned) | ✅ — not referenced by this controller |
| 5 | `Modules/SmartTimetable/app/Policies/TimetableGenerationStrategyPolicy.php` | policy | 65 | this report (pre-assigned) | ✅ |
| 6 | `Modules/SmartTimetable/resources/views/timetable-generation-strategy/create.blade.php` | view | 297 | this report | ✅ |
| 7 | `Modules/SmartTimetable/resources/views/timetable-generation-strategy/show.blade.php` | view | 236 | this report | ✅ |
| 8 | `Modules/SmartTimetable/resources/views/timetable-generation-strategy/edit.blade.php` | view | 362 | this report | ✅ |
| 9 | `Modules/SmartTimetable/resources/views/timetable-generation-strategy/trash.blade.php` | view | 65 | this report | ✅ |
| 10 | `Modules/SmartTimetable/resources/views/timetable-generation-strategy/index.blade.php` | view | 232 | ↗ rendered by TimetableMenuController, not by this controller | ❌ not reached from this controller |
| 11 | `Modules/TimetableFoundation/resources/views/pages/partials/timetable-configuration/generation-strategy/_list.blade.php` | partial | 80 | ↗ rendered by TimetableMenuController | ❌ not reached from this controller |

Class ownership check: `Modules/SmartTimetable/app/Models/TtGenerationStrategy.php`, `Modules/SmartTimetable/app/Models/Activity.php` and `Modules/SmartTimetable/app/Policies/TimetableGenerationStrategyPolicy.php` are already claimed for this report in `00-CLASS-OWNERS.md` (pre-assigned by the main session). `TimetableGenerationStrategyRequest` is used only by this controller and is not registered, so this report owns it. The blade views are controller-private and are not registered.

No pre-applied files for this controller (no row in `final-audit-reports/TimetableFoundation/PRE-APPLIED-2026-10-10.md` names a file in this scope).

## 4. Routes

Command: `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` filtered for `TtGenerationStrategyController@`.

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '... TtGenerationStrategyController@ ...'
COUNT=0
```

Unrouted public methods (all 13; three already disabled per D5):

| Method | file:line | State |
|---|---|---|
| `index` | 18 | unrouted — not disabled |
| `create` | 26 | unrouted — not disabled |
| `store` | 39 | unrouted — not disabled |
| `show` | 91 | unrouted — not disabled |
| `edit` | 107 | unrouted — not disabled |
| `update` | 123 | unrouted — not disabled |
| `destroy` | 194 | unrouted — not disabled |
| `trashed` | 229 | unrouted — not disabled |
| `restore` | 243 | unrouted — already `abort(403)` + `NOT ROUTED` |
| `forceDelete` | 253 | unrouted — already `abort(403)` + `NOT ROUTED` |
| `toggleStatus` | 263 | unrouted — already `abort(403)` + `NOT ROUTED` |
| `toggleDefault` | 273 | unrouted — not disabled |
| `getAlgorithmParameters` | 321 | unrouted — not disabled |

The route files disagree about who owns this controller:

```
$ sed -n '73p' routes/tenant.php
// TtGenerationStrategyController routes are in TimetableFoundation/routes/web.php
$ sed -n '360,362p' Modules/TimetableFoundation/routes/web.php
// Generation strategy routes are in Modules/SmartTimetable/routes/web.php.
// This module does not own generation strategy controllers.
// Route::resource('generation-strategies', ...);
```

The real list screen is served by `Modules\SmartTimetable\Http\Controllers\TimetableMenuController@timetableConfiguration` (`GET smart-timetable/timetable-configuration`), which builds `$generationStrategies` itself and renders the TimetableFoundation partial. That partial uses the safe `route_or_hash()` helper, so it renders "dead" `#` links instead of crashing.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 18 | none | none | none | none | none | TGS-07 |
| `create` | 26 | none | `tenant.smart-timetable.timetable-generation-strategy.create` | none | none | none | TGS-07 |
| `store` | 39 | none | `…strategy.create` (Gate) + FormRequest `authorize()` | controller `DB::beginTransaction` | `'Stored'` | tt_generation_strategies, sys_activity_logs | TGS-01, TGS-02, TGS-03, TGS-04, TGS-09 |
| `show` | 91 | none | `…strategy.view` | none | none | none | TGS-07 |
| `edit` | 107 | none | `…strategy.update` | none | none | none | TGS-07 |
| `update` | 123 | none | `…strategy.update` (Gate) + FormRequest `authorize()` | controller `DB::beginTransaction` | `'Updated'` | tt_generation_strategies, sys_activity_logs | TGS-01, TGS-02, TGS-04, TGS-09 |
| `destroy` | 194 | none | `…strategy.delete` | controller `DB::beginTransaction` | `'Trashed'` | tt_generation_strategies, sys_activity_logs | TGS-01, TGS-02, TGS-04 |
| `trashed` | 229 | none | `…strategy.restore` | none | none | none | TGS-07, TGS-11 |
| `restore` | 243 | none | none (D5 abort) | none | none | none | TGS-07 |
| `forceDelete` | 253 | none | none (D5 abort) | none | none | none | TGS-07 |
| `toggleStatus` | 263 | none | none (D5 abort) | none | none | none | TGS-07 |
| `toggleDefault` | 273 | none | `…strategy.update` | controller `DB::beginTransaction` | `'Default Toggled'` | tt_generation_strategies, sys_activity_logs | TGS-01, TGS-02, TGS-04 |
| `getAlgorithmParameters` | 321 | none | none | none | none | none | TGS-07, TGS-10 |

Every transaction lives in the controller (no service is called). `activityLog()` is placed after the write and inside the transaction in all four mutating methods, which satisfies TXN-04.

## 6. Findings

### F1 — Errors

#### TGS-01 · B · ERR-01 — the raw exception message is sent to the user on every write failure

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:80-85`, methods `store()`, `update()` (187), `destroy()` (222), `toggleDefault()` (313) |
| **Root cause** | The four mutating methods each catch `\Exception` and concatenate `$e->getMessage()` into the flash / JSON message. The message of a `QueryException` contains the failing SQL, the connection name and often column values. |
| **Consequence** | A user who triggers a DB error (for example reusing a unique code, or a column overflow) sees raw SQL and schema detail in a red alert or in the JSON response. |
| **Reproduce** | Static only — the controller is unrouted (TGS-07), so no URL reaches it today. Once a route exists, submit the create form with a duplicate `code` on a hard-failing path and read the alert text. |
| **Fix approach** | Remove the `getMessage()` concatenation; let the global handler log the exception and return a fixed user-safe message (D1). |
| **Plan item** | TGS-01 in `02-fix-plan.md` §1 |

```php
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()
                ->withInput()
                ->with('error', 'Failed to create generation strategy: ' . $e->getMessage());
        }
```

**Evidence**
```
$ grep -n "getMessage" Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php
84:                ->with('error', 'Failed to create generation strategy: ' . $e->getMessage());
187:                ->with('error', 'Failed to update generation strategy: ' . $e->getMessage());
222:                ->with('error', 'Failed to delete generation strategy: ' . $e->getMessage());
313:                'message' => 'Failed to update default status: ' . $e->getMessage()
```

#### TGS-02 · M · ERR-00 — controller-level try/catch contradicts the settled Laravel idiom (D1)

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M, raised reason: D1 settled this — a controller try/catch is a finding unless a D2 shape applies) — *use the Laravel idiom; `DB::transaction()` rolls back and rethrows by itself* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:43-45`, method `store()` (and `update()` 127-133, `destroy()` 198-204, `toggleDefault()` 283-290) |
| **Root cause** | House rule A1 was hand-rolled with manual `beginTransaction`/`commit`/`rollBack` plus a broad `catch (\Exception)`. None of these is one of the D2 allowed shapes (this is a plain CRUD write, not a truncate-then-rebuild). |
| **Consequence** | Every failure is caught in the controller and rendered by hand, which both hides the real exception trace from the logs and is the code path that leaks `getMessage()` (TGS-01). |
| **Reproduce** | Static only — code shape; no runtime reproduction. |
| **Fix approach** | Replace each `beginTransaction`/`try`/`catch` with a single `DB::transaction(fn () => …)` closure and a fixed success response after it (D1). |
| **Plan item** | none — covered by item TGS-01 in `02-fix-plan.md` §1, see §10 |

```php
        DB::beginTransaction();

        try {
            $data = $request->validated();
```

**Evidence**
```
$ grep -n "beginTransaction\|DB::commit\|DB::rollBack" Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php
43:        DB::beginTransaction();
75:            DB::commit();
81:            DB::rollBack();
127:        DB::beginTransaction();
178:            DB::commit();
184:            DB::rollBack();
198:        DB::beginTransaction();
214:            DB::commit();
220:            DB::rollBack();
283:        DB::beginTransaction();
301:            DB::commit();
309:            DB::rollBack();
```

#### TGS-03 · M · CTL-10 — dead JSON error branch; invalid JSON is silently discarded

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code; a branch that can never run is dead code* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:51-58`, method `store()` (and `update()` 140-150) |
| **Root cause** | `json_decode()` without `JSON_THROW_ON_ERROR` returns `null` on invalid input and never throws, so the `catch (\Exception)` can never run. Worse, the FormRequest's `prepareForValidation()` already turns invalid JSON into `null`, which makes `$request->filled('parameters_json')` false, so the controller writes `[]` and the user is never told their JSON was rejected. |
| **Consequence** | A user who pastes malformed JSON sees the strategy saved with no parameters and no error — the "Invalid JSON format" message is unreachable. |
| **Reproduce** | `php -r 'var_dump(json_decode("{bad json", true));'` prints `NULL`; there is no exception to catch. |
| **Fix approach** | Validate JSON in `TimetableGenerationStrategyRequest` with the `json` rule and stop nulling it in `prepareForValidation()`; then the controller can parse without a try/catch. |
| **Plan item** | TGS-03 in `02-fix-plan.md` §1 |

```php
            if ($request->filled('parameters_json')) {
                try {
                    $data['parameters_json'] = json_decode($request->parameters_json, true);
                } catch (\Exception $e) {
                    return redirect()->back()
                        ->withInput()
                        ->with('error', 'Invalid JSON format in parameters field.');
                }
            } else {
                $data['parameters_json'] = [];
            }
```

**Evidence**
```
$ php -r 'try { var_dump(json_decode("{bad json", true)); } catch (\Throwable $e) { echo "THREW"; }'
NULL
$ sed -n '93,101p' Modules/SmartTimetable/app/Http/Requests/TimetableGenerationStrategyRequest.php
        if ($this->has('parameters_json') && is_string($this->parameters_json)) {
            try {
                json_decode($this->parameters_json, true, 512, JSON_THROW_ON_ERROR);
            } catch (\JsonException $e) {
                $this->merge([
                    'parameters_json' => null
                ]);
            }
        }
```

### F2 — Transactions and audit

#### TGS-04 · M · TXN-02 — manual transactions plus an early return leave an open transaction

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`; never `return` between `beginTransaction` and `commit`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:198-204`, method `destroy()` (same shape: `store()` 43-58, `update()` 127-150, `toggleDefault()` 283-315) |
| **Root cause** | `DB::beginTransaction()` is opened, then `destroy()` returns a redirect for the default strategy before reaching `DB::commit()`. In `store()`/`update()` the inner JSON branch can return before commit too. The connection is left inside an open transaction for the rest of the request. |
| **Consequence** | The transaction is never committed and the connection is not cleanly closed by the request; under a persistent connection (Octane) later writes can join the abandoned transaction. On a normal PHP request the work is silently rolled back at process end. |
| **Reproduce** | Static only — code shape; no URL reaches the controller while TGS-07 is open. |
| **Fix approach** | Use `DB::transaction(fn () => …)` and move the guard (`is_default`) above the closure, as the TGS-01 rewrite does. |
| **Plan item** | none — covered by item TGS-01 in `02-fix-plan.md` §1, see §10 |

```php
        DB::beginTransaction();

        try {
            if ($generation_strategy->is_default) {
                return redirect()->back()
                    ->with('error', 'Cannot delete the default generation strategy. Please set another strategy as default first.');
            }
```

**Evidence**
```
$ grep -n "beginTransaction\|DB::commit\|DB::rollBack" Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php
43:        DB::beginTransaction();
75:            DB::commit();
81:            DB::rollBack();
127:        DB::beginTransaction();
178:            DB::commit();
184:            DB::rollBack();
198:        DB::beginTransaction();
214:            DB::commit();
220:            DB::rollBack();
283:        DB::beginTransaction();
301:            DB::commit();
309:            DB::rollBack();
```

### F3 — Authorization

#### TGS-05 · M · AUTH-06 — the registered policy is never consulted; permission literals are duplicated

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy or constants — not repeated as literals* |
| **Where** | `Modules/SmartTimetable/app/Policies/TimetableGenerationStrategyPolicy.php:13-16`, policy registered at `Modules/SmartTimetable/app/Providers/SmartTimetableServiceProvider.php:268` |
| **Root cause** | The policy is registered with `Gate::policy(TtGenerationStrategy::class, …)`, but every controller check is `Gate::authorize('tenant.smart-timetable.timetable-generation-strategy.…')` with a **string ability**. A string ability is looked up directly and never routes through a model policy, so no policy method is ever called. The same seven ability strings are also repeated in the controller and the FormRequest. |
| **Consequence** | The policy looks like the authorization source of truth but is dead code. A permission typo in one of the three surfaces (see TGS-12) cannot be caught by reading the policy. |
| **Reproduce** | Static only — `grep` shows the policy is only registered, never referenced by any `authorize()`/`can()` call with a model argument. |
| **Fix approach** | Decision item: either switch the controller to model-argument checks so the policy is live, or drop the policy and centralise the literals as constants. |
| **Plan item** | TGS-05 in `02-fix-plan.md` §9 |

```php
    public function viewAny(User $user): bool
    {
        return $user->can('tenant.smart-timetable.timetable-generation-strategy.viewAny');
    }
```

**Evidence**
```
$ grep -rn "TimetableGenerationStrategyPolicy" Modules/ app/ config/ | grep -v "app/Policies/TimetableGenerationStrategyPolicy.php"
Modules/SmartTimetable/app/Providers/SmartTimetableServiceProvider.php:11:use Modules\SmartTimetable\Policies\TimetableGenerationStrategyPolicy;
Modules/SmartTimetable/app/Providers/SmartTimetableServiceProvider.php:268:        Gate::policy(TtGenerationStrategy::class, TimetableGenerationStrategyPolicy::class);
```

#### TGS-06 · L · AUTH-04 — the same permission is authorized twice on store and update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice; keep one* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:39-41`, method `store()` (and `update()` 123-125) |
| **Root cause** | `TimetableGenerationStrategyRequest::authorize()` already checks `.create` for POST and `.update` otherwise, and it runs before the controller. The controller then repeats `Gate::authorize()` with the same ability. |
| **Consequence** | Two sources of truth for one rule; future edits to one are easily missed. No security impact today (both fail closed). |
| **Reproduce** | Static only — compare the FormRequest `authorize()` with the controller `Gate::authorize()` calls. |
| **Fix approach** | Keep the FormRequest `authorize()`; drop the duplicate `Gate::authorize()` lines in `store()` and `update()`. |
| **Plan item** | none — covered by item TGS-01 in `02-fix-plan.md` §1, see §10 |

```php
    public function store(TimetableGenerationStrategyRequest $request)
    {
        Gate::authorize('tenant.smart-timetable.timetable-generation-strategy.create');
```

**Evidence**
```
$ sed -n '13,19p' Modules/SmartTimetable/app/Http/Requests/TimetableGenerationStrategyRequest.php
    public function authorize(): bool
    {
        if ($this->isMethod('POST')) {
            return auth()->user()->can('tenant.smart-timetable.timetable-generation-strategy.create');
        }
        return auth()->user()->can('tenant.smart-timetable.timetable-generation-strategy.update');
    }
```

### F4 — Validation and input

clean — the FormRequest types and constrains every field, `Rule::unique('tt_generation_strategies','code')->ignore($strategyId)` mirrors the DB unique index `uq_generation_strategy_code` (which includes soft-deleted rows because Laravel's presence verifier applies no soft-delete scope), and the only inline `validate()` (a single boolean in `toggleDefault`) is the one-field AJAX toggle allowed by VAL-02.

```
$ php artisan tinker --execute '... SHOW INDEX FROM tt_generation_strategies ...'
PRIMARY col=id non_unique=0
uq_generation_strategy_code col=code non_unique=0
$ grep -n "Rule::unique\|->ignore" Modules/SmartTimetable/app/Http/Requests/TimetableGenerationStrategyRequest.php
33:                Rule::unique('tt_generation_strategies', 'code')->ignore($strategyId)
```

### F5 — Routes

#### TGS-07 · H · RTE-03 — no route points at this controller; the feature is unreachable

| Field | Value |
|---|---|
| **Rule** | RTE-03 (H, raised reason: the whole CRUD feature is dead, and views call route names that do not exist) — *every public controller method is routed, or is deliberately disabled* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:18-21`, method `index()` |
| **Root cause** | The routes were removed and the two route files now cross-reference each other. `routes/tenant.php:73` says the routes are in `Modules/TimetableFoundation/routes/web.php`; `Modules/TimetableFoundation/routes/web.php:360` says they are in `Modules/SmartTimetable/routes/web.php`. Neither file registers them; the only trace is a commented `Route::resource`. Uncached `route:list` returns 0 routes for this controller. |
| **Consequence** | Nobody can open the create, show, edit, or trash pages. The list tab (served by TimetableMenuController) renders view/edit/delete links through `route_or_hash()`, so they silently become `#`. In the SmartTimetable management view, `index.blade.php` calls `route('timetable-foundation.generation-strategies.index')` and `.toggleDefault` directly, which throw `RouteNotFoundException` (HTTP 500) when that page renders. |
| **Reproduce** | `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` and filter for `TtGenerationStrategyController@` — COUNT=0. Then open `http://test.localhost:8000/smart-timetable/timetable-configuration?tab=generation-strategy` and note the view/edit/delete links go nowhere. |
| **Fix approach** | Decision item: register the eight resource + custom routes (the names the views already expect), or apply D5 to the ten live methods and delete the now-dead views. |
| **Plan item** | TGS-07 in `02-fix-plan.md` §9 |

```php
    public function index(Request $request)
    {
        return redirect()->route('smart-timetable.menu.timetableConfiguration');
    }
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '... TtGenerationStrategyController@ ...'
COUNT=0
$ sed -n '73p' routes/tenant.php
// TtGenerationStrategyController routes are in TimetableFoundation/routes/web.php
$ sed -n '360,362p' Modules/TimetableFoundation/routes/web.php
// Generation strategy routes are in Modules/SmartTimetable/routes/web.php.
// This module does not own generation strategy controllers.
// Route::resource('generation-strategies', ...);
```

### F6 — Controller shape

#### TGS-08 · L · CTL-04 — public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:26-34`, method `create()` (all 13 public methods lack a return type) |
| **Root cause** | No method declares `: View`, `: RedirectResponse`, or `: JsonResponse`. |
| **Consequence** | The declared contract is invisible to readers and static analysis; a method that accidentally returns the wrong shape is not caught. |
| **Reproduce** | Static only — `grep -nE 'public function'` shows no return types. |
| **Fix approach** | Add the matching return type to each method. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
    public function create()
    {
        Gate::authorize('tenant.smart-timetable.timetable-generation-strategy.create');

        $algorithmTypes = TtGenerationStrategy::getAlgorithmTypes();
        $sortingMethods = TtGenerationStrategy::getActivitySortingMethods();

        return view('smarttimetable::timetable-generation-strategy.create', compact('algorithmTypes', 'sortingMethods'));
    }
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+' Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php | head -3
18:    public function index(Request $request)
26:    public function create()
39:    public function store(TimetableGenerationStrategyRequest $request)
```

#### TGS-09 · M · CTL-05 — store and update duplicate the same input-normalisation block

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste; the same payload built in `store` and `update`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:48-61`, method `store()` (duplicated at `update()` 136-150) |
| **Root cause** | The checkbox conversion and the JSON-parse block are copied verbatim into both methods. |
| **Consequence** | A fix to one copy (for example the JSON handling in TGS-03) is easily applied to only one method, and the create and edit paths then disagree. |
| **Reproduce** | Static only — `sed -n '48,61p'` and `sed -n '136,150p'` show the same lines. |
| **Fix approach** | Extract one private `strategyInput()` helper and call it from both methods (done by the TGS-01 rewrite). |
| **Plan item** | none — covered by item TGS-01 in `02-fix-plan.md` §1, see §10 |

```php
            $data['is_default'] = $request->has('is_default') ? 1 : 0;
            $data['is_active'] = $request->has('is_active') ? 1 : 0;

            if ($request->filled('parameters_json')) {
                try {
                    $data['parameters_json'] = json_decode($request->parameters_json, true);
                } catch (\Exception $e) {
                    return redirect()->back()
                        ->withInput()
                        ->with('error', 'Invalid JSON format in parameters field.');
                }
            } else {
                $data['parameters_json'] = [];
            }
```

**Evidence**
```
$ diff <(sed -n '48,61p' Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php) <(sed -n '136,150p' Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php)
6c6
<             // Parse JSON parameters   (update only)
$ grep -c "is_default'\] = \$request->has" Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php
2
```

#### TGS-10 · M · CTL-06 — algorithm parameter/description tables live in the controller and duplicate the model

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in services/actions; the controller reads input, calls one service, returns a response* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:325-357`, method `getAlgorithmParameters()` |
| **Root cause** | The per-algorithm parameter map and the description map are hard-coded in the controller, duplicating the model's own `getAlgorithmSpecificParameters()` and `getAlgorithmTypeDisplayAttribute()`. |
| **Consequence** | Adding an algorithm requires editing both the model and the controller; the two can drift and the AJAX endpoint can advertise parameters the generator no longer reads. |
| **Reproduce** | Static only — compare `getAlgorithmParameters()` with `TtGenerationStrategy::getAlgorithmSpecificParameters()`. |
| **Fix approach** | Move both maps onto the model as static methods and have the controller call them. |
| **Plan item** | none — see `02-fix-plan.md` §10 (deferred: the method is unrouted, TGS-07) |

```php
        $parameters = [
            'RECURSIVE' => [
                'max_recursive_depth' => 'Maximum Recursive Depth',
                'max_placement_attempts' => 'Maximum Placement Attempts',
                'timeout_seconds' => 'Timeout in Seconds'
            ],
            'GENETIC' => [
                'population_size' => 'Population Size',
                'generations' => 'Number of Generations',
                'timeout_seconds' => 'Timeout in Seconds'
            ],
```

**Evidence**
```
$ grep -n "getAlgorithmSpecificParameters\|getAlgorithmTypeDisplayAttribute" Modules/SmartTimetable/app/Models/TtGenerationStrategy.php
117:    public function getAlgorithmTypeDisplayAttribute()
177:    public function getAlgorithmSpecificParameters()
$ grep -n "'RECURSIVE' =>" Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php
326:            'RECURSIVE' => [
```

### F7 — Models

clean — `TtGenerationStrategy` declares `$fillable`, casts every boolean/date/decimal/JSON column, sets `$table = 'tt_generation_strategies'` (migration `database/migrations/tenant/2026_06_16_152601_create_tt_generation_strategy_table.php`), and uses `SoftDeletes` while the table has `deleted_at`; the `Activity` alias extends the TimetableFoundation model and is not referenced by this controller.

```
$ grep -nE '\$table|\$fillable|SoftDeletes|parameters_json.*array|is_default.*boolean' Modules/SmartTimetable/app/Models/TtGenerationStrategy.php
14:    protected $table = 'tt_generation_strategies';
12:    use SoftDeletes;
53:        'parameters_json' => 'array',
54:        'is_default' => 'boolean',
$ php artisan tinker --execute '... SHOW INDEX FROM tt_generation_strategies ...'
PRIMARY col=id non_unique=0
uq_generation_strategy_code col=code non_unique=0
```

### F8 — Services and jobs

clean — this controller injects no service and dispatches no job. `grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification|Export|Import)\b'` on the controller returns only the FormRequest name.

```
$ grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b' Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php | sort -u
TimetableGenerationStrategyRequest
```

### F9 — Queries and performance

#### TGS-11 · L · QRY-13 — the trash paginator drops its query string

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L) — *filtered paginators keep filters (`->withQueryString()`)* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:233-235`, method `trashed()` |
| **Root cause** | `paginate(10)` is used without `withQueryString()`, so any filter query parameters are lost when the user moves to page 2. |
| **Consequence** | Paging the trash list drops the active filters. Low impact because the trash list has no filters today; still a latent trap if one is added. |
| **Reproduce** | Static only — method is unrouted (TGS-07). |
| **Fix approach** | Append `->withQueryString()` to the paginator chain. |
| **Plan item** | TGS-11 in `02-fix-plan.md` §6 |

```php
        $strategies = TtGenerationStrategy::onlyTrashed()
            ->orderBy('deleted_at', 'desc')
            ->paginate(10);
```

**Evidence**
```
$ grep -n "withQueryString\|paginate(10)" Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php
235:            ->paginate(10);
```

### F10 — Views

#### TGS-12 · M · AUTH-06 — the show view gates on a different permission spelling than the controller

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place; every surface uses the identical name* |
| **Where** | `Modules/SmartTimetable/resources/views/timetable-generation-strategy/show.blade.php:15`, also lines 208 and 214 |
| **Root cause** | The view checks `tenant.smart-timetable.generation-strategy.update` and `.delete`, while the controller and FormRequest check `tenant.smart-timetable.timetable-generation-strategy.update` / `.delete`. The two are different abilities in `config/permissionslist.php`. |
| **Consequence** | Edit/Delete buttons render for whoever holds the old `generation-strategy` ability and get a 403 from the controller, while a user holding only the canonical ability sees no Edit/Delete buttons even though the controller would allow them. |
| **Reproduce** | Static only — compare the two `@can` strings with `config/permissionslist.php`. |
| **Fix approach** | Change the three `@can` strings in the show view to the canonical `timetable-generation-strategy` spelling. |
| **Plan item** | TGS-12 in `02-fix-plan.md` §7 |

```php
                            @can('tenant.smart-timetable.generation-strategy.update')
                                <a href="{{ route('timetable-foundation.generation-strategies.edit', $generation_strategy->id) }}"
                                    class="btn btn-sm btn-warning">
```

**Evidence**
```
$ grep -n "generation-strategy.update\|generation-strategy.delete" Modules/SmartTimetable/resources/views/timetable-generation-strategy/show.blade.php
15:                            @can('tenant.smart-timetable.generation-strategy.update')
208:                                    @can('tenant.smart-timetable.generation-strategy.update')
214:                                    @can('tenant.smart-timetable.generation-strategy.delete')
$ grep -n "timetable-generation-strategy.update" Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php
125:        Gate::authorize('tenant.smart-timetable.timetable-generation-strategy.update');
```

### F11 — Security and tenancy

clean — no `env()` call, no personal data in the JSON response (only `success`, `is_default` and a flash string), no hard-coded ids, and no raw request body logged; all cacheable lookups are static PHP arrays.

```
$ grep -nE 'env\(|Log::|request\(\)->all|DB::raw|->getMessage\(\)' Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php
84: ... getMessage ... (already reported as TGS-01)
187: ... getMessage ...
222: ... getMessage ...
313: ... getMessage ...
```

### F12 — Style

#### TGS-13 · L · STY-01 — no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:1`, and the same in the request, both models, and the policy |
| **Root cause** | None of the five in-scope PHP files declares strict types. |
| **Consequence** | Loose scalar coercion stays in force; a wrong-typed argument is silently coerced rather than rejected. |
| **Reproduce** | `grep -L "declare(strict_types"` across the five files returns all five. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag of each file. |
| **Plan item** | none — see `02-fix-plan.md` §10 (style pass) |

```php
<?php

namespace Modules\SmartTimetable\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
```

**Evidence**
```
$ grep -L "declare(strict_types" Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php Modules/SmartTimetable/app/Http/Requests/TimetableGenerationStrategyRequest.php Modules/SmartTimetable/app/Models/TtGenerationStrategy.php Modules/SmartTimetable/app/Models/Activity.php Modules/SmartTimetable/app/Policies/TimetableGenerationStrategyPolicy.php
Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php
Modules/SmartTimetable/app/Http/Requests/TimetableGenerationStrategyRequest.php
Modules/SmartTimetable/app/Models/TtGenerationStrategy.php
Modules/SmartTimetable/app/Models/Activity.php
Modules/SmartTimetable/app/Policies/TimetableGenerationStrategyPolicy.php
```

#### TGS-14 · L · STY-02 — the in-scope PHP files are not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php:1-11`, import block |
| **Root cause** | `ordered_imports` and several spacing fixers fail; the imports put `Gate` before `DB` and the model has unused imports and trailing whitespace. |
| **Consequence** | The files differ from every other module file and produce review noise. |
| **Reproduce** | `vendor/bin/pint --test` on the three files. |
| **Fix approach** | Run `vendor/bin/pint` on each touched file (never `--dirty`). |
| **Plan item** | none — see `02-fix-plan.md` §10 (style pass) |

```php
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\DB;
use Modules\SmartTimetable\Http\Requests\TimetableGenerationStrategyRequest;
use Modules\SmartTimetable\Models\TtGenerationStrategy;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php Modules/SmartTimetable/app/Http/Requests/TimetableGenerationStrategyRequest.php Modules/SmartTimetable/app/Models/TtGenerationStrategy.php
{"tool":"pint","result":"fail","files":[{"path":"Modules/SmartTimetable/app/Http/Controllers/TtGenerationStrategyController.php","fixers":["control_structure_braces","concat_space","trailing_comma_in_multiline","braces_position","statement_indentation","not_operator_with_successor_space","blank_line_before_statement","ordered_imports"]},{"path":"Modules/SmartTimetable/app/Http/Requests/TimetableGenerationStrategyRequest.php","fixers":["trailing_comma_in_multiline","blank_line_before_statement"]},{"path":"Modules/SmartTimetable/app/Models/TtGenerationStrategy.php","fixers":["class_attributes_separation","no_trailing_whitespace","no_unused_imports","single_line_after_imports"]}]}
```

#### TGS-15 · L · STY-04 — commented-out Blade blocks left in three views

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *no commented-out code* |
| **Where** | `Modules/SmartTimetable/resources/views/timetable-generation-strategy/index.blade.php:52-56` (also `create.blade.php:212` and the large block in `show.blade.php`) |
| **Root cause** | Commented-out `@can`/`@canany` blocks and links were left in the templates. |
| **Consequence** | The real gate on the Status/Action columns is unclear; a reader cannot tell if the comment is documentation or a dead switch. |
| **Reproduce** | Static only — read the quoted lines. |
| **Fix approach** | Delete the commented-out blocks or restore them, and document the chosen gate. |
| **Plan item** | none — see `02-fix-plan.md` §10 (style pass) |

```php
                {{-- @can('tenant.smart-timetable.timetable-generation-strategy.update') --}}
                    <th>Status</th>
                {{-- @endcan --}}
```

**Evidence**
```
$ grep -n "{{-- @" Modules/SmartTimetable/resources/views/timetable-generation-strategy/index.blade.php
52:                {{-- @can('tenant.smart-timetable.timetable-generation-strategy.update') --}}
55:                {{-- @canany(['tenant.smart-timetable.timetable-generation-strategy.view', 'tenant.smart-timetable.timetable-generation-strategy.update',
56:                    'tenant.smart-timetable.timetable-generation-strategy.delete']) --}}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Overwrite | 2 Delete-before-store | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Authz hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | TGS-09 | ok | TGS-07 | ok | TGS-03 | TGS-07 |
| `update` | ok | ok | TGS-09 | ok | TGS-07 | ok | ok | TGS-07 |
| `destroy` | ok | ok | ok | ok | ok | ok | TGS-01 | TGS-07 |
| `toggleDefault` | ok | ok | ok | ok | TGS-07 | ok | TGS-01 | TGS-07 |

Notes: Q5 (race) — `store`/`update`/`toggleDefault` check and then unset the old default without a lock or unique constraint on `is_default` (TXN-06 candidate). It is recorded here as TGS-07's reachability consequence; with the screen unreachable it is not a live race, and no separate plan item is raised.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SmartTimetable/resources/views/index.blade.php` (rendered by `TimetablePageController@timetableMaster` / `SmartTimetableController@index`) | Includes `smarttimetable::timetable-generation-strategy.index`, which calls `route('timetable-foundation.generation-strategies.index')` and `.toggleDefault` directly; those route names do not exist (TGS-07), so this page throws `RouteNotFoundException` when the include runs (e.g. for a Super Admin whose `Gate::before` passes the `viewAny` check). | RTE-03 | Owner report of `TimetablePageController` / `SmartTimetableController` |
| `Modules/TimetableFoundation/resources/views/pages/partials/timetable-configuration/generation-strategy/_list.blade.php` | Renders view/edit/delete actions for routes that do not exist; uses `route_or_hash()` so it degrades to `#` rather than crashing. | RTE-03 | Owner report of `TimetableMenuController` |

## 8. Not covered, and why

- **The `TimetableMenuController@timetableConfiguration` list screen** is a different controller; its own queries (`->get()` without pagination on the strategy list) are that controller's report, not this one. The partial it renders is listed in §7.
- **Runtime behaviour of the four mutating methods** could not be exercised (D4: no tests) and the controller is unrouted (TGS-07), so all write-path findings are proven statically and from the schema, not by a live request.
- **The `sys_activity_logs` write** made by `activityLog()` was not traced into its own model/table; it is a shared helper and a common class.
- **Queue jobs, mail and notifications** — none is referenced by this controller.
