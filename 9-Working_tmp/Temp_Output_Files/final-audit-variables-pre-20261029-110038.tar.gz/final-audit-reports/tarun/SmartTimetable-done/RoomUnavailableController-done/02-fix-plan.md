# Fix Plan — SmartTimetable / RoomUnavailableController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php` for developer `tarun`. It applies **only** ticked items, in this order.
> 5. Apply RUA-01 before RUA-04 (RUA-01 rewrites four method bodies; RUA-04 rewrites `store`/`update`, including removing their `try`/`catch`), then RUA-04 before RUA-08 (RUA-08 adds the return types to signatures that RUA-04 changed). RUA-05 and RUA-07 are route re-scope DECISIONs: tick them only if that is accepted.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php` | shared route file — touched only by the RUA-05 and RUA-07 DECISIONs, and only if ticked |
| `resources/views/components/backend/table/action-trashed.blade.php` | shared component — RUA-05 needs no edit here |
| `Modules/SmartTimetable/app/Models/Constraint.php` | owned by [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) |
| `Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php` | owned by [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) |
| `Modules/SchoolSetup/app/Models/Room.php` | common, different module |
| `config/permissionslist.php` | shared config; this plan needs no new permission key |
| `database/migrations/**` | existing migrations are never edited; a new one is needed only if RUA-03 option (c) is chosen |

## 1. Blockers reachable today

_None of B severity._

## 2. Fixes that arm a latent defect (sequenced)

_None._

## 3. Errors & transactions (F1/F2)

- [x] **RUA-01** · M · ERR-00 (D1) + ERR-05 · `RoomUnavailableController.php:444-467` — delete the controller `try`/`catch` in four mutating actions (`destroy`, `restore`, `forceDelete`, `toggleStatus`), return the model from the closure, and build the response after the closure. `store`/`update` are de-wrapped by RUA-04, which rewrites both methods.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php`
  - **Before** (`RoomUnavailableController.php:444-467`):
    ```php
        try {
            return DB::transaction(function () use ($roomUnavailable) {
                // Deactivate before trashing: the solver filters on is_active, and a
                // trashed-but-active row is a trap for anything reading withTrashed().
                $roomUnavailable->is_active = false;
                $roomUnavailable->save();

                $roomUnavailable->delete();

                activityLog(
                    $roomUnavailable,
                    'Trashed',
                    ['message' => 'Room unavailability was deactivated and moved to trash.']
                );

                return redirect()
                    ->route('smart-timetable.menu.constraintEngine', ['tab' => 'room-unavailability'])
                    ->with('success', flash('deleted.room_unavailable'));
            });
        } catch (\Throwable $e) {
            Log::error('RoomUnavailable destroy failed', ['id' => $roomUnavailable->id, 'error' => $e->getMessage()]);

            return back()->with('error', flash('operation_failed.room_unavailable'));
        }
    ```
  - **After:** — `destroy()`:
    ```php
        $roomUnavailable = DB::transaction(function () use ($roomUnavailable) {
            // Deactivate before trashing: the solver filters on is_active, and a
            // trashed-but-active row is a trap for anything reading withTrashed().
            $roomUnavailable->is_active = false;
            $roomUnavailable->save();

            $roomUnavailable->delete();

            activityLog(
                $roomUnavailable,
                'Trashed',
                ['message' => 'Room unavailability was deactivated and moved to trash.']
            );

            return $roomUnavailable;
        });

        return redirect()
            ->route('smart-timetable.menu.constraintEngine', ['tab' => 'room-unavailability'])
            ->with('success', flash('deleted.room_unavailable'));
    ```
    `restore()` (Before at lines 475-498) becomes:
    ```php
        $roomUnavailable = DB::transaction(function () use ($roomUnavailable) {
            $roomUnavailable->restore();

            // Reactivate on restore — the mirror of destroy(), or a restored row
            // would come back inert and silently stop constraining the solver.
            $roomUnavailable->is_active = true;
            $roomUnavailable->save();

            activityLog(
                $roomUnavailable,
                'Restored',
                ['message' => 'Room unavailability was restored successfully.']
            );

            return $roomUnavailable;
        });

        return redirect()
            ->route('smart-timetable.room-unavailable.trashed')
            ->with('success', flash('restored.room_unavailable'));
    ```
    `forceDelete()` (Before at lines 520-541) becomes:
    ```php
        $roomUnavailable = DB::transaction(function () use ($roomUnavailable) {
            $roomUnavailable->forceDelete();

            // AFTER the delete on purpose: Eloquent leaves the attributes populated
            // on a force-deleted instance, so getKey() still returns the id the log
            // row needs.
            activityLog(
                $roomUnavailable,
                'Deleted',
                ['message' => 'Room unavailability was permanently deleted.']
            );

            return $roomUnavailable;
        });

        return redirect()
            ->route('smart-timetable.room-unavailable.trashed')
            ->with('success', flash('force_deleted.room_unavailable'));
    ```
    `toggleStatus()` (Before at lines 561-592) becomes:
    ```php
        $roomUnavailable = DB::transaction(function () use ($request, $roomUnavailable) {
            $roomUnavailable->is_active = $request->boolean('is_active');

            if (! $roomUnavailable->save()) {
                throw new \RuntimeException('Failed to persist the room unavailability status change.');
            }

            activityLog(
                $roomUnavailable,
                'Toggled',
                [
                    'message' => 'Room unavailability status was updated.',
                    'is_active' => $roomUnavailable->is_active,
                ]
            );

            return $roomUnavailable;
        });

        return response()->json([
            'success' => true,
            'is_active' => $roomUnavailable->is_active,
            'message' => flash('status_updated.room_unavailable'),
        ]);
    ```
    Finally delete the now-unused import (line 9). Before:
    ```php
    use Illuminate\Support\Facades\Log;
    ```
    After: the line is removed; nothing replaces it.
  - **Verify:** `grep -nE 'try \{|catch \(|Log::error' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php`
  - **Expect:** no output.
  - **Effort:** M

## 4. Authorization (F3)

_None — all ten `Gate::authorize` calls are correct and there is no FormRequest-until-RUA-04 double check._

## 5. Validation, routes, models (F4/F5/F7)

- [x] **RUA-04** · M · VAL-02 + VAL-07 + CTL-05 · `RoomUnavailableController.php:97-156,283-371` — extract the duplicated inline rules and the hand-written recurring/date block into `StoreRoomUnavailableRequest` and `UpdateRoomUnavailableRequest`; keep only boolean normalisation and the recurring-nulls-dates line in the controller.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php`, `Modules/SmartTimetable/app/Http/Requests/StoreRoomUnavailableRequest.php` (new), `Modules/SmartTimetable/app/Http/Requests/UpdateRoomUnavailableRequest.php` (new)
  - **Before** (`RoomUnavailableController.php:87-97`):
    ```php
        public function store(Request $request)
        {
            Gate::authorize('tenant.smart-timetable.room-unavailable.create');

            /*
        |--------------------------------------------------------------------------
        | 1. Validate Input
        |--------------------------------------------------------------------------
        */

            $validated = $request->validate([
    ```
  - **After:** — new file `Modules/SmartTimetable/app/Http/Requests/StoreRoomUnavailableRequest.php`:
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;

    class StoreRoomUnavailableRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return $this->user()->can('tenant.smart-timetable.room-unavailable.create');
        }

        public function rules(): array
        {
            return [
                'room_id' => ['required', 'integer', 'exists:sch_rooms,id'],
                'reason' => ['nullable', 'string', 'max:255'],
                'day_of_week' => ['required', 'integer', 'between:1,7'],
                'period_from' => ['nullable', 'integer', 'min:1', 'required_with:period_to'],
                'period_to' => ['nullable', 'integer', 'min:1', 'gte:period_from'],
                'is_recurring' => ['nullable', 'boolean'],
                'start_date' => ['nullable', 'date'],
                'end_date' => ['nullable', 'date', 'after_or_equal:start_date'],
                'constraint_id' => ['nullable', 'integer', Rule::exists('tt_constraints', 'id')->where('is_active', true)],
                'is_active' => ['nullable', 'boolean'],
            ];
        }

        public function after(): array
        {
            return [
                function ($validator) {
                    if (! $this->boolean('is_recurring') && ! $this->filled('start_date') && ! $this->filled('end_date')) {
                        $validator->errors()->add('start_date', 'Start or end date is required for non-recurring unavailability.');
                    }
                },
            ];
        }
    }
    ```
    New file `Modules/SmartTimetable/app/Http/Requests/UpdateRoomUnavailableRequest.php` (identical except the `authorize()` permission):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;

    class UpdateRoomUnavailableRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return $this->user()->can('tenant.smart-timetable.room-unavailable.update');
        }

        public function rules(): array
        {
            return [
                'room_id' => ['required', 'integer', 'exists:sch_rooms,id'],
                'reason' => ['nullable', 'string', 'max:255'],
                'day_of_week' => ['required', 'integer', 'between:1,7'],
                'period_from' => ['nullable', 'integer', 'min:1', 'required_with:period_to'],
                'period_to' => ['nullable', 'integer', 'min:1', 'gte:period_from'],
                'is_recurring' => ['nullable', 'boolean'],
                'start_date' => ['nullable', 'date'],
                'end_date' => ['nullable', 'date', 'after_or_equal:start_date'],
                'constraint_id' => ['nullable', 'integer', Rule::exists('tt_constraints', 'id')->where('is_active', true)],
                'is_active' => ['nullable', 'boolean'],
            ];
        }

        public function after(): array
        {
            return [
                function ($validator) {
                    if (! $this->boolean('is_recurring') && ! $this->filled('start_date') && ! $this->filled('end_date')) {
                        $validator->errors()->add('start_date', 'Start or end date is required for non-recurring unavailability.');
                    }
                },
            ];
        }
    }
    ```
    Replace the controller import block (lines 5-14) with:
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\SchoolSetup\Models\Room;
    use Modules\SmartTimetable\Http\Requests\StoreRoomUnavailableRequest;
    use Modules\SmartTimetable\Http\Requests\UpdateRoomUnavailableRequest;
    use Modules\SmartTimetable\Models\Constraint;
    use Modules\SmartTimetable\Models\ConstraintCategoryScope;
    use Modules\SmartTimetable\Models\RoomUnavailable;
    ```
    `store()` (lines 87-243) becomes:
    ```php
    public function store(StoreRoomUnavailableRequest $request)
    {
        $validated = $request->validated();
        $validated['is_recurring'] = $request->boolean('is_recurring');
        $validated['is_active']    = $request->boolean('is_active');

        // Recurring rules carry no date range — a stale range would narrow them.
        if ($validated['is_recurring']) {
            $validated['start_date'] = null;
            $validated['end_date'] = null;
        }

        $exists = RoomUnavailable::query()
            ->where('room_id', $validated['room_id'])
            ->where('day_of_week', $validated['day_of_week'])
            ->where(fn ($q) => $this->applyPeriodOverlap($q, $validated))
            ->where('is_active', true)
            ->exists();

        if ($exists) {
            return back()
                ->withErrors([
                    'day_of_week' => 'This room already has an unavailability defined for the selected day and period.',
                ])
                ->withInput();
        }

        $roomUnavailable = DB::transaction(function () use ($validated) {
            $roomUnavailable = RoomUnavailable::create($validated);

            activityLog(
                $roomUnavailable,
                'Stored',
                ['message' => 'Room unavailability was created.']
            );

            return $roomUnavailable;
        });

        return redirect()
            ->route('smart-timetable.menu.constraintEngine', ['tab' => 'room-unavailability'])
            ->with('success', flash('created.room_unavailable'));
    }
    ```
    `update()` (lines 273-431) becomes:
    ```php
    public function update(UpdateRoomUnavailableRequest $request, RoomUnavailable $roomUnavailable)
    {
        $validated = $request->validated();
        $validated['is_recurring'] = $request->boolean('is_recurring');
        $validated['is_active']    = $request->boolean('is_active');

        if ($validated['is_recurring']) {
            $validated['start_date'] = null;
            $validated['end_date'] = null;
        }

        $conflict = RoomUnavailable::query()
            ->where('id', '!=', $roomUnavailable->id)
            ->where('room_id', $validated['room_id'])
            ->where('day_of_week', $validated['day_of_week'])
            ->where(fn ($q) => $this->applyPeriodOverlap($q, $validated))
            ->where('is_active', true)
            ->exists();

        if ($conflict) {
            return back()
                ->withErrors([
                    'day_of_week' => 'Another unavailability already exists for this room, day and period.',
                ])
                ->withInput();
        }

        DB::transaction(function () use ($validated, $roomUnavailable) {
            $roomUnavailable->update($validated);

            activityLog(
                $roomUnavailable,
                'Updated',
                ['message' => 'Room unavailability was updated.']
            );
        });

        return redirect()
            ->route('smart-timetable.menu.constraintEngine', ['tab' => 'room-unavailability'])
            ->with('success', flash('updated.room_unavailable'));
    }
    ```
    The `Gate::authorize(...)` lines in `store()` and `update()` are deleted together with the old signatures (the FormRequest `authorize()` runs first and carries the same permission). `toggleStatus()` keeps its inline `$request->validate(['is_active' => 'required|boolean'])` — VAL-02 allows a one-field AJAX toggle.
  - **Verify:** `grep -n '\$request->validate(' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php`
  - **Expect:** exactly one hit, the `toggleStatus` toggle at the `is_active` line.
  - **Effort:** M

- [x] **RUA-05** · H · DECISION · RTE-01 · `Modules/SmartTimetable/routes/web.php:280` ⚠ SHARED — Restore runs over a GET request, so a prefetcher can restore a trashed rule with no CSRF token.
  - **Why it is a decision:** it changes a route verb, and the rule file says a route re-scope stops and asks.
  - (a) ⭐ Change it to `Route::patch('/room-unavailable/{id}/restore', [RoomUnavailableController::class, 'restore'])->name('room-unavailable.restore');`. The only UI caller is `trash.blade.php:70` through `x-backend.table.action-trashed`, which reads the verb from the route itself, so no blade edit is needed.
  - (b) Change it to `Route::post(...)` instead of `patch` (same effect).
  - (c) Leave it as GET and record the risk as accepted.
  - ➜ Choice: PUT, not PATCH (Tarun 2026-10-15, same as CTY-05).

- [x] **RUA-07** · M · DECISION · CTL-03 · `RoomUnavailableController.php:248,258,436` + `routes/web.php:278` ⚠ SHARED — five methods take a raw `$id` and call `findOrFail` instead of route-model binding.
  - **Why it is a decision:** a clean conversion renames the route parameter, which is a route re-scope.
  - (a) ⭐ Add `->parameters(['room-unavailable' => 'roomUnavailable'])` to `Route::resource('room-unavailable', …)` and bind `RoomUnavailable $roomUnavailable` in `show`, `edit` and `destroy`; keep the custom `{id}` routes (`restore`, `forceDelete`) on `findOrFail`. A missing id still 404s. `update` and `toggleStatus` already bind and are unaffected.
  - (b) Bind only `show`/`edit`/`destroy` and leave `restore`/`forceDelete` exactly as they are.
  - (c) Accept `findOrFail` as-is (no route change); record as low debt.
  - ➜ Choice: (a) without the rename — snake-case fallback binds `{room_unavailable}`. `show`/`edit`/`update`/`destroy`/`toggleStatus` bound; `restore`/`forceDelete` stay on `$id`.

- [x] **RUA-08** · L · CTL-04 · `RoomUnavailableController.php:21` — add a return type to every public method.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php`
  - **Before** (`RoomUnavailableController.php:21-26`):
    ```php
        public function index()
        {
            Gate::authorize('tenant.smart-timetable.room-unavailable.viewAny');

            return redirect()->route('smart-timetable.menu.constraintEngine');
        }
    ```
  - **After:**
    ```php
    use Illuminate\Contracts\View\View;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    ```
    ```php
        public function index(): RedirectResponse
        {
            Gate::authorize('tenant.smart-timetable.room-unavailable.viewAny');

            return redirect()->route('smart-timetable.menu.constraintEngine');
        }
    ```
    Add the three imports after the existing `use Illuminate\Http\Request;` line. Apply these return types to the remaining methods (their signatures as they stand after RUA-01 and RUA-04):
    - `create(): never` (the `abort(403)` body stays untouched)
    - `store(StoreRoomUnavailableRequest $request): RedirectResponse`
    - `show($id): View`
    - `edit($id): View`
    - `update(UpdateRoomUnavailableRequest $request, RoomUnavailable $roomUnavailable): RedirectResponse`
    - `destroy($id): RedirectResponse`
    - `restore($id): RedirectResponse`
    - `trashedRoomUnavailable(): View`
    - `forceDelete($id): RedirectResponse`
    - `toggleStatus(Request $request, RoomUnavailable $roomUnavailable): JsonResponse`
    If RUA-07 option (a) is also ticked and has already renamed `show`/`edit`/`destroy` to bound models, use those bound signatures with the same return types.
  - **Verify:** `grep -cE 'public function [a-zA-Z_]+\([^)]*\)\s*:' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php`
  - **Expect:** `11`.
  - **Effort:** M

- [x] **RUA-10** · L · MDL-04 · `RoomUnavailable.php:140-154` — return-type the two relationships.
  - **Touches:** `Modules/SmartTimetable/app/Models/RoomUnavailable.php`
  - **Before** (`RoomUnavailable.php:140-154`):
    ```php
        public function room()
        {
            return $this->belongsTo(
                Room::class,
                'room_id'
            );
        }

        public function constraint()
        {
            return $this->belongsTo(
                Constraint::class,
                'constraint_id'
            );
        }
    ```
  - **After:**
    ```php
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    ```
    ```php
        public function room(): BelongsTo
        {
            return $this->belongsTo(
                Room::class,
                'room_id'
            );
        }

        public function constraint(): BelongsTo
        {
            return $this->belongsTo(
                Constraint::class,
                'constraint_id'
            );
        }
    ```
    Add the `BelongsTo` import after the existing `use Illuminate\Database\Eloquent\SoftDeletes;` line.
  - **Verify:** `grep -nE 'public function (room|constraint)\(\): BelongsTo' Modules/SmartTimetable/app/Models/RoomUnavailable.php`
  - **Expect:** two hits.
  - **Effort:** S

## 6. Queries & performance (F9)

_None._

## 7. Views (F10)

_None._

## 8. Style (F12) — one item per file

- [x] **RUA-11** · L · STY-01 + STY-04 · `RoomUnavailableController.php:1` — add `declare(strict_types=1)`, remove the emoji marker, delete the stray docblock, and give `store()` its own docblock.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php`
  - **Before** (`RoomUnavailableController.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
    Delete the stray docblock at lines 43-45 (the "Store a newly created resource in storage." block above `applyPeriodOverlap()`), and add it — reworded — directly above `store()`:
    ```php
    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreRoomUnavailableRequest $request)
    ```
    Replace the `⚠ ` marker at the start of line 551 with the plain word `Note:`; keep the rest of the sentence unchanged.
  - **Verify:** `grep -c "declare(strict_types" Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php`
  - **Expect:** `1`.
  - **Effort:** S

- [x] **RUA-12** · L · STY-01 + STY-04 · `Modules/SmartTimetable/app/Models/RoomUnavailable.php:1` — add `declare(strict_types=1)` and replace the emoji marker in the `$fillable` docblock.
  - **Touches:** `Modules/SmartTimetable/app/Models/RoomUnavailable.php`
  - **Before** (`RoomUnavailable.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Models;
    ```
    Replace the `⚠ ` marker at the start of line 30 with the plain word `Note:`; keep the rest of the docblock unchanged.
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/SmartTimetable/app/Models/RoomUnavailable.php`
  - **Expect:** one hit on line 3.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **RUA-03** · M · DECISION · TXN-06 — the overlap guard (`applyPeriodOverlap`) is a pre-write `exists()` with no lock and no unique index, and the re-activation paths (`toggleStatus`, `restore`) bypass it; two concurrent writes can insert overlapping rules.
  - **Why it is a decision:** a true concurrency fix either adds a unique index (a migration, Tarun's hand) or changes the write contract, and it must not be applied in the same pass as RUA-01/RUA-04, which rewrite the surrounding methods.
  - (a) ⭐ Accept for now: the screen is a low-traffic admin config page with two writers at most; record the race and the re-activation bypass as accepted.
  - (b) After RUA-01/RUA-04, move the guard inside the `DB::transaction` and wrap the read in `lockForUpdate()`, and run the same guard before `toggleStatus`/`restore` re-activate a row; keep the same friendly `withErrors` response.
  - (c) Add an additive migration with a unique index over the overlap key plus a duplicate-catch in `store`/`update`; requires a data check and `php artisan tenants:migrate` by Tarun.
  - ➜ Choice: (a) — accepted; RUA-03 note in the `applyPeriodOverlap()` docblock.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| RUA-02 | Folded into RUA-01 (and RUA-04 for `store`/`update`): the `After` blocks return the model from the closure and build the `redirect()`/`response()` after `DB::transaction()` returns, which is the whole of TXN-05 for all six methods. |
| RUA-06 | Folded into RUA-04: extracting the validation into the FormRequests removes the inline rules array and the cross-field block, which is what pushes `store()` and `update()` over the 150-line hard limit. |
| RUA-09 | Dead-view cleanup (`room-unavailable/index.blade.php` and `create.blade.php`) — deleting unreferenced files is a views cleanup, not a code fix; re-prove `routed=0 refs=0` at fix time before removing them. |