# Final Audit — SmartTimetable / RoomUnavailableController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php` (594 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/room-unavailable` (index, redirects), `/smart-timetable/room-unavailable/{id}` (show), `/smart-timetable/room-unavailable/{id}/edit` (edit), `/smart-timetable/room-unavailable/trash/view` (trash). The Add form is a dialog on the host page `/smart-timetable/constraint-engine?tab=room-unavailability`, rendered by `TimetableMenuController@constraintEngine`; this controller only serves the store/show/edit/update/destroy/restore/force-delete/toggle-status calls that tab makes. |
| Menu path | Smart Timetable dashboard → "Constraint Engine" → the **Room Unavailability** tab. |
| Who uses it | Roles holding the eight permissions = **Super Admin** and **School Admin**, measured in `sys_role_has_permissions_jnt` on the tenant DB (16 rows = 8 permission names × 2 roles). |
| What a user does here | Records when a room cannot be used — a day, optionally a period range, either recurring or across a date range, with a reason, optionally tied to a constraint. Each rule can be switched active/inactive (AJAX), edited, soft-deleted, restored and permanently deleted. The solver consumes active rows as a hard constraint on room placement. |
| Tables written | `tt_room_unavailabilities` (INSERT/UPDATE/soft-DELETE/force-DELETE/restore); `sys_activity_logs` (one row per mutation through the `activityLog()` helper, inside the same transaction). |
| Tables read | `tt_room_unavailabilities`, `sch_rooms` (68 active), `tt_constraints` (5 active), `tt_constraint_category_scopes` (scope lookup), `sys_permissions` (gate). |
| Live data | tenant `xyz_school_00000000000040008000_202627`: `tt_room_unavailabilities` = **0 live, 0 trashed**; `sch_rooms` active = 68; `tt_constraints` active = 5; `sys_activity_logs` = 396. All eight `tenant.smart-timetable.room-unavailable.*` permissions exist in `sys_permissions`. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is close to production-ready but not there yet. Its authorization is real on every routed method, every mutating method wraps its writes in one `DB::transaction` with `activityLog()` inside it, the overlap guard is a correctly-written extraction that `store()` and `update()` share, and the flash keys all resolve. It is **not production-ready** because it still carries six hand-written controller `try/catch` blocks that the settled D1 decision removes (all logging only `$e->getMessage()`, so the trace is lost); because the **restore action runs over a GET URL** with no CSRF token; and because `store()`/`update()` (157/159 lines) duplicate a 60-line inline validation array that belongs in one FormRequest. The single worst finding is **RUA-05** (RTE-01, H): a link prefetcher, a crawler or an image tag can restore a trashed rule with no user intent. Rough effort for the full plan: **M**, under a day, with three DECISION items (one route verb, one route-binding rename, one race). No migration and no new permission key is needed unless the race DECISION picks the index option.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 6 | 4 | 3 | 12 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | RUA-01 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | RUA-02, RUA-03 | F9 Queries/Perf | clean |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | RUA-04 | F11 Security/Tenancy | clean |
| F5 Routes | RUA-05 | F12 Style | RUA-11, RUA-12 |
| F6 Controller shape | RUA-06, RUA-07, RUA-08, RUA-09 | F13 Deep read | RUA-03 (cells) |
| F7 Models | RUA-10 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php` | controller | 594 | this report | ✅ whole class |
| 2 | `Modules/SmartTimetable/app/Models/RoomUnavailable.php` | model | 192 | this report (pre-assigned) | ✅ whole class |
| 3 | `Modules/SmartTimetable/resources/views/room-unavailable/show.blade.php` | blade | 82 | this report | ✅ |
| 4 | `Modules/SmartTimetable/resources/views/room-unavailable/edit.blade.php` | blade | 159 | this report | ✅ |
| 5 | `Modules/SmartTimetable/resources/views/room-unavailable/trash.blade.php` | blade | 97 | this report | ✅ |
| 6 | `Modules/SmartTimetable/resources/views/room-unavailable/index.blade.php` | blade | 102 | this report | ✅ — dead, RUA-09 |
| 7 | `Modules/SmartTimetable/resources/views/room-unavailable/create.blade.php` | blade | 165 | this report | ✅ — dead, RUA-09 |
| 8 | `Modules/SmartTimetable/routes/web.php` lines 278-282 | routes | 5 | this report (usage) | ✅ |
| — | `Modules/SmartTimetable/app/Models/Constraint.php` | model | — | ↗ [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked — usage checked: `edit()` filters `Constraint::where('is_active', true)` and `show()` eager-loads the `constraint` relation |
| — | `Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php` | model | — | ↗ [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked — usage checked: `edit()` looks up the ROOM scope id by `code`/`type` |
| — | `Modules/SchoolSetup/app/Models/Room.php` | model | — | common (SchoolSetup) | referenced only — `edit()` calls `Room::where('is_active', true)->get()`; `show`/`trash` use the `room` relation |
| — | `resources/views/components/backend/table/action.blade.php`, `action-trashed.blade.php`, `status-switch.blade.php`, `card/header.blade.php`, `components/breadcrum.blade.php`, `app/Helpers/activityLog.php`, `app/Helpers/helpers.php` (`flash()`), base `Controller`, base `BaseModel` | common | — | common | referenced only |

`RoomUnavailable` is pre-assigned to this report (`00-CLASS-OWNERS.md`). `Constraint` and `ConstraintCategoryScope` are owned by `ConstraintCategoryScopeController`, so they are linked, not re-audited; only this controller's use of them is checked. The two services the brief suspected — `RoomAllocationPass` and `RoomChangeTrackingService` — are **not referenced anywhere** in this controller or its model (grep F returned no output), so they are unreachable from here and were neither claimed nor audited (D7).

No in-scope file appears in a module `PRE-APPLIED-*.md`.

## 4. Routes

```
GET|HEAD smart-timetable/room-unavailable                        smart-timetable.room-unavailable.index             Modules\SmartTimetable\Http\Controllers\RoomUnavailableController@index
POST    smart-timetable/room-unavailable                        smart-timetable.room-unavailable.store             Modules\SmartTimetable\Http\Controllers\RoomUnavailableController@store
GET|HEAD smart-timetable/room-unavailable/trash/view             smart-timetable.room-unavailable.trashed           Modules\SmartTimetable\Http\Controllers\RoomUnavailableController@trashedRoomUnavailable
DELETE  smart-timetable/room-unavailable/{id}/force-delete      smart-timetable.room-unavailable.forceDelete       Modules\SmartTimetable\Http\Controllers\RoomUnavailableController@forceDelete
GET|HEAD smart-timetable/room-unavailable/{id}/restore           smart-timetable.room-unavailable.restore           Modules\SmartTimetable\Http\Controllers\RoomUnavailableController@restore
GET|HEAD smart-timetable/room-unavailable/{room_unavailable}     smart-timetable.room-unavailable.show              Modules\SmartTimetable\Http\Controllers\RoomUnavailableController@show
PUT|PATCH smart-timetable/room-unavailable/{room_unavailable}     smart-timetable.room-unavailable.update            Modules\SmartTimetable\Http\Controllers\RoomUnavailableController@update
DELETE  smart-timetable/room-unavailable/{room_unavailable}     smart-timetable.room-unavailable.destroy           Modules\SmartTimetable\Http\Controllers\RoomUnavailableController@destroy
GET|HEAD smart-timetable/room-unavailable/{room_unavailable}/edit smart-timetable.room-unavailable.edit              Modules\SmartTimetable\Http\Controllers\RoomUnavailableController@edit
POST    smart-timetable/room-unavailable/{room_unavailable}/toggle-status smart-timetable.room-unavailable.toggleStatus      Modules\SmartTimetable\Http\Controllers\RoomUnavailableController@toggleStatus
```

Unrouted public methods: `create` at line 31 — deliberately unrouted (the resource is `->except(['create'])`) and D5-compliant: its body is `abort(403, 'The create page is retired — use the Add dialog on the Room Unavailability tab.')` with a `NOT ROUTED` comment. All other public methods are routed. Every route sits inside `Route::middleware(['web', 'auth', 'verified', EnsureTenantHasModule::class.':smart-timetable'])` with prefix `smart-timetable` (`Modules/SmartTimetable/routes/web.php:47-50` opening the group that closes after line 284), so the tenant middleware is present (RTE-05 clean).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 21 | GET /smart-timetable/room-unavailable | `tenant.smart-timetable.room-unavailable.viewAny` | none — read-only | — | none | RUA-08 |
| `create` | 31 | not routed (D5 abort 403) | none | none | — | none | RUA-09 |
| `store` | 87 | POST /smart-timetable/room-unavailable | `tenant.smart-timetable.room-unavailable.create` | controller | 'Stored' | tt_room_unavailabilities, sys_activity_logs | RUA-01, RUA-02, RUA-03, RUA-04, RUA-06 |
| `show` | 248 | GET /smart-timetable/room-unavailable/{room_unavailable} | `tenant.smart-timetable.room-unavailable.view` | none — read-only | — | none | RUA-07, RUA-08 |
| `edit` | 258 | GET /smart-timetable/room-unavailable/{room_unavailable}/edit | `tenant.smart-timetable.room-unavailable.update` | none — read-only | — | none | RUA-07, RUA-08 |
| `update` | 273 | PUT\|PATCH /smart-timetable/room-unavailable/{room_unavailable} | `tenant.smart-timetable.room-unavailable.update` | controller | 'Updated' | tt_room_unavailabilities, sys_activity_logs | RUA-01, RUA-02, RUA-03, RUA-04, RUA-06 |
| `destroy` | 436 | DELETE /smart-timetable/room-unavailable/{room_unavailable} | `tenant.smart-timetable.room-unavailable.delete` | controller | 'Trashed' | tt_room_unavailabilities, sys_activity_logs | RUA-01, RUA-02, RUA-07, RUA-08 |
| `restore` | 469 | GET /smart-timetable/room-unavailable/{id}/restore | `tenant.smart-timetable.room-unavailable.restore` | controller | 'Restored' | tt_room_unavailabilities, sys_activity_logs | RUA-01, RUA-02, RUA-05, RUA-07, RUA-08 |
| `trashedRoomUnavailable` | 500 | GET /smart-timetable/room-unavailable/trash/view | `tenant.smart-timetable.room-unavailable.viewAny` | none — read-only | — | none | RUA-08 |
| `forceDelete` | 514 | DELETE /smart-timetable/room-unavailable/{id}/force-delete | `tenant.smart-timetable.room-unavailable.forceDelete` | controller | 'Deleted' | tt_room_unavailabilities, sys_activity_logs | RUA-01, RUA-02, RUA-07, RUA-08 |
| `toggleStatus` | 543 | POST /smart-timetable/room-unavailable/{room_unavailable}/toggle-status | `tenant.smart-timetable.room-unavailable.update` | controller | 'Toggled' | tt_room_unavailabilities, sys_activity_logs | RUA-01, RUA-02, RUA-03, RUA-08 |

Tables each mutation SHOULD touch: every mutation writes one `tt_room_unavailabilities` row plus one `sys_activity_logs` audit row (`activityLog()`). All six mutating methods do exactly those two, inside one `DB::transaction` — the transaction COUNT is correct (`controller-alignment.md` §6); the defects are the shape (RUA-01, D1), the response placement (RUA-02, TXN-05) and the guard placement (RUA-03, TXN-06), not a missing transaction.

## 6. Findings

### F1 — Errors

#### RUA-01 · M · ERR-00 (D1) + ERR-05 — six mutating actions keep a controller try/catch that logs only the message

| Field | Value |
|---|---|
| **Rule** | ERR-00 under D1 (M by project decision) — *no try/catch in controllers; `DB::transaction()` rolls back and rethrows by itself; the central handler in `bootstrap/app.php` renders errors*; ERR-05 (M) — *log the exception, not `getMessage()`*. None of the D2 shapes (a business `\DomainException`, a truncate-then-rebuild, a `SnapshotProtectionException`) is present. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php:219-242`, method `store()` (same shape at `update()`:407-430, `destroy()`:444-467, `restore()`:475-498, `forceDelete()`:520-541, `toggleStatus()`:561-592) |
| **Root cause** | Each mutating action wraps its `DB::transaction()` in `try { … } catch (Throwable $e)`, then logs `['error' => $e->getMessage()]` and returns a hand-written flash/JSON. D1 settled that controllers carry no try/catch except the D2 shapes; none of these six is a D2 shape. |
| **Consequence** | Every real DB failure is reduced to a fixed sentence and the stack trace is lost, so a failing write on the Room Unavailability tab cannot be diagnosed from the log; and each catch is another place the 404/403/422 class of bug can creep back in. |
| **Reproduce** | Static only — the failure needs a broken DB, which cannot be forced from the UI; the shape is verified by grep. |
| **Fix approach** | Delete the outer `try`/`catch` in `destroy`, `restore`, `forceDelete`, `toggleStatus`, keep the `DB::transaction()` closure and its `activityLog()` call, and return the model from the closure. `store()`/`update()` are de-wrapped by RUA-04 (which rewrites both methods as part of the FormRequest extraction). Remove the now-unused `use Illuminate\Support\Facades\Log;` import (line 9). `toggleStatus()` keeps its `\RuntimeException` escalation so a failed `save()` still rolls the log row back. |
| **Plan item** | RUA-01 in `02-fix-plan.md` §3 |

```php
        try {
            return DB::transaction(function () use ($validated) {
                $roomUnavailable = RoomUnavailable::create($validated);

                activityLog(
                    $roomUnavailable,
                    'Stored',
                    ['message' => 'Room unavailability was created.']
                );

                return redirect()
                    ->route('smart-timetable.menu.constraintEngine', ['tab' => 'room-unavailability'])
                    ->with('success', flash('created.room_unavailable'));
            });
        } catch (\Throwable $e) {
            Log::error('RoomUnavailable store failed', [
                'room_id' => $validated['room_id'] ?? null,
                'error' => $e->getMessage(),
            ]);

            return back()
                ->withInput()
                ->with('error', flash('operation_failed.room_unavailable'));
        }
```

**Evidence**
```
$ grep -nE 'try \{|catch \(|Log::error\(' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php
219:        try {
233:        } catch (\Throwable $e) {
234:            Log::error('RoomUnavailable store failed', [
407:        try {
421:        } catch (\Throwable $e) {
422:            Log::error('RoomUnavailable update failed', [
444:        try {
463:        } catch (\Throwable $e) {
464:            Log::error('RoomUnavailable destroy failed', ['id' => $roomUnavailable->id, 'error' => $e->getMessage()]);
475:        try {
494:        } catch (\Throwable $e) {
495:            Log::error('RoomUnavailable restore failed', ['id' => $roomUnavailable->id, 'error' => $e->getMessage()]);
520:        try {
537:        } catch (\Throwable $e) {
538:            Log::error('RoomUnavailable forceDelete failed', ['id' => $roomUnavailable->id, 'error' => $e->getMessage()]);
561:        try {
584:        } catch (\Throwable $e) {
585:            Log::error('RoomUnavailable toggleStatus failed', ['id' => $roomUnavailable->id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### RUA-02 · M · TXN-05 — all six methods build the HTTP response inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build the `redirect()` / `response()` after it* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php:229-232`, method `store()` (same shape at `update()`:417-419, `destroy()`:459-461, `restore()`:490-492, `forceDelete()`:533-535, `toggleStatus()`:578-582) |
| **Root cause** | Every closure's last expression constructs the `RedirectResponse` or `JsonResponse`, so the HTTP response object is created before the transaction has committed. |
| **Consequence** | The response is coupled to the transaction body: any later change that needs the committed model's values cannot see them, and the two idioms drift within one file. No user-visible failure today. |
| **Reproduce** | Static only — a returned `RedirectResponse` is not visible in the browser. |
| **Fix approach** | Return the model from the closure, then call `redirect()` / `response()` after `DB::transaction()` returns. Covered by the same rewrite as RUA-01 (and, for `store`/`update`, RUA-04). |
| **Plan item** | none — see plan §10 (folded into RUA-01) |

```php
                return redirect()
                    ->route('smart-timetable.menu.constraintEngine', ['tab' => 'room-unavailability'])
                    ->with('success', flash('created.room_unavailable'));
            });
```

**Evidence**
```
$ grep -nE 'return DB::transaction|return redirect\(\)|return response\(\)->json' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php
220:            return DB::transaction(function () use ($validated) {
229:                return redirect()
408:            return DB::transaction(function () use ($validated, $roomUnavailable) {
417:                return redirect()
445:            return DB::transaction(function () use ($roomUnavailable) {
459:                return redirect()
476:            return DB::transaction(function () use ($roomUnavailable) {
490:                return redirect()
521:            return DB::transaction(function () use ($roomUnavailable) {
533:                return redirect()
562:            return DB::transaction(function () use ($request, $roomUnavailable) {
578:                return response()->json([
```

#### RUA-03 · M · TXN-06 — the overlap guard is a check-then-act with no lock or unique index, and the activate paths bypass it

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M, lowered from H — a single-school admin config screen with two writers at most) — *check-then-act needs a lock or a unique index: `exists()` then `create()`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php:193-198`, method `store()` (same query at `update()`:379-385); helper `applyPeriodOverlap()` at 66-85. |
| **Root cause** | The duplicate-overlap rule is an `->exists()` check that runs **before** the `DB::transaction` and is not repeated inside it with a lock. `tt_room_unavailabilities` has no unique index (verified: only `PRIMARY`, `fk_ru_constraint`, `idx_ru_room`, `idx_ru_day_period`, all non-unique). Two concurrent POSTs can both read "no overlap" and both insert. In addition, `applyPeriodOverlap()` is called only from `store()` and `update()` (lines 196, 383) — `toggleStatus()` (activating a saved inactive rule) and `restore()` (re-activating a trashed rule) flip `is_active` back on with no overlap check at all. |
| **Consequence** | A double-submit or two simultaneous School Admins can create two overlapping rules for the same room/day; more simply, a user can create an inactive rule that overlaps, then activate it (or trash then restore it) and the solver double-counts the unavailability. |
| **Reproduce** | Static only — a race cannot be forced from one browser; the missing index is proved by `SHOW INDEX` below, and the bypass by the grep that `applyPeriodOverlap` appears only at lines 66, 196, 383. |
| **Fix approach** | Either re-run the guard inside the transaction behind `lockForUpdate()` on both write paths and also before activating in `toggleStatus()`/`restore()`, or add a unique index (a migration, hence a DECISION). |
| **Plan item** | RUA-03 (DECISION) in `02-fix-plan.md` §9 |

```php
        $exists = RoomUnavailable::query()
            ->where('room_id', $validated['room_id'])
            ->where('day_of_week', $validated['day_of_week'])
            ->where(fn ($q) => $this->applyPeriodOverlap($q, $validated))
            ->where('is_active', true)
            ->exists();
```

**Evidence**
```
$ php artisan tinker --execute '... SHOW INDEX FROM tt_room_unavailabilities ...'  (tenant xyz_school_00000000000040008000_202627)
PRIMARY       id                 non_unique=0
fk_ru_constraint constraint_id   non_unique=1
idx_ru_room     room_id          non_unique=1
idx_ru_day_period day_of_week    non_unique=1
idx_ru_day_period period_from    non_unique=1
idx_ru_day_period period_to      non_unique=1
(no unique index on room_id + day_of_week + period range)
$ grep -n "applyPeriodOverlap" Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php
66:    private function applyPeriodOverlap($query, array $validated)
196:            ->where(fn ($q) => $this->applyPeriodOverlap($q, $validated))
383:            ->where(fn ($q) => $this->applyPeriodOverlap($q, $validated))
```

### F3 — Authorization

clean — every routed method calls `Gate::authorize(...)` with the exact permission name, before loading any record (AUTH-02), and all eight names (`viewAny`, `create`, `view`, `update`, `delete`, `restore`, `forceDelete` plus `export`) are declared in `config/permissionslist.php:732` (`'smart-timetable.room-unavailable' => array_merge($crud, ['export'])`) and are **seeded** in the tenant DB to Super Admin and School Admin (AUTH-06). There is no FormRequest here (that is RUA-04), so no AUTH-04 double-authorize. Evidence: `grep -n "Gate::authorize"` → ten hits at controller lines 23, 89, 250, 260, 275, 438, 471, 502, 516, 545; tenant probe `SELECT ... sys_role_has_permissions_jnt` → all eight names on `Super Admin` and `School Admin`.

### F4 — Validation and input

#### RUA-04 · M · VAL-02 + VAL-07 + CTL-05 — validation is inline and duplicated in `store()`/`update()` instead of one FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request, not inline `$request->validate()` (except a one-field AJAX toggle)*; VAL-07 (M) — *cross-field/business checks go in the Form Request's `after()` hook, not hand-written in the controller*; CTL-05 (M) — *no copy-paste: the same payload in `store` and `update`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php:97-156`, method `store()` (the identical 10-item rules array and the identical recurring/date block are repeated at `update()`:283-371) |
| **Root cause** | Both write methods call `$request->validate([...])` inline with a byte-identical 60-line rules array, and then hand-implement a cross-field rule ("recurring rules drop dates; non-recurring needs at least one date") at lines 167-185 (store) and 353-371 (update). The two copies have already drifted once historically (the `period_ord` bug comment says the old equality check was carried byte-identical in both methods). |
| **Consequence** | A rule change must be made twice or the two write paths disagree; the controller stays 157/159 lines long (RUA-06); and the cross-field date rule lives outside any validation structure, so it cannot be reasoned about as one unit. |
| **Reproduce** | Repeated static: `grep -n 'request->validate'` → the same array begins at lines 97 and 283. |
| **Fix approach** | Extract `StoreRoomUnavailableRequest` and `UpdateRoomUnavailableRequest` (both with the same `rules()` and the date rule in `after()`); the methods then use `$request->validated()` and keep only the boolean normalisation (`$request->boolean('is_recurring')`, `$request->boolean('is_active')`) and the recurring-nulls-dates line. `toggleStatus():547-549` stays inline — VAL-02 explicitly allows a one-field AJAX toggle. |
| **Plan item** | RUA-04 in `02-fix-plan.md` §5 |

```php
        $validated = $request->validate([
            'room_id' => [
                'required',
                'integer',
                'exists:sch_rooms,id',
            ],

            'reason' => [
                'nullable',
                'string',
                'max:255',
            ],

            'day_of_week' => [
                'required',
                'integer',
                'between:1,7',
            ],

            // Period RANGE, matching the schema (period_from / period_to). Both null
            // means the room is blocked for the WHOLE day. period_from is required
            // whenever period_to is supplied, or the range would have no start.
            'period_from' => [
```

**Evidence**
```
$ grep -n '\$request->validate(' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php
97:        $validated = $request->validate([
283:        $validated = $request->validate([
547:        $request->validate([
(line 547 is the single-field AJAX toggle allowed by VAL-02; lines 97 and 283 are the duplicated write-path arrays)
```

### F5 — Routes

#### RUA-05 · H · RTE-01 — Restore runs over a GET request

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/SmartTimetable/routes/web.php:280` |
| **Root cause** | `Route::get('/room-unavailable/{id}/restore', …)` performs a write (un-soft-deletes the row and flips `is_active` back on) behind a GET verb. |
| **Consequence** | A browser prefetch, a crawler or an image tag can restore a trashed rule with no user intent and no CSRF token. |
| **Reproduce** | While signed in as School Admin, open `http://test.localhost:8000/smart-timetable/room-unavailable/1/restore` directly — it restores rule id 1. Expected: a 405 for a plain GET. |
| **Fix approach** | Change the verb. The only UI caller is `trash.blade.php:70` via the shared `x-backend.table.action-trashed` component, which reads the verb from the route itself, so changing the route needs no blade edit. This is a route change, so it is a DECISION (⚠ SHARED). |
| **Plan item** | RUA-05 (DECISION) in `02-fix-plan.md` §5 |

```php
        Route::get('/room-unavailable/{id}/restore', [RoomUnavailableController::class, 'restore'])->name('room-unavailable.restore');
```

**Evidence**
```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); foreach($r as $x) if(str_contains($x["action"],"RoomUnavailableController@restore")) printf("%-7s %s\n",$x["method"],$x["uri"]);'
GET|HEAD smart-timetable/room-unavailable/{id}/restore
```

**Rest of F5 — checked, clean:** every route points at an existing method (RTE-02); `create` is deliberately unrouted and D5-compliant (RTE-03); reads are GET and the other writes are POST/PUT/DELETE apart from RUA-05 (RTE-04); every route carries the `web, auth, verified, EnsureTenantHasModule` group (RTE-05); the custom routes are declared **after** `Route::resource` but no conflict occurs because each custom path has an extra segment, so `/{room_unavailable}` never captures `/trash/view`, `/{id}/restore`, `/{id}/force-delete` or `/{room_unavailable}/toggle-status` (RTE-06, proved by the `route:list` above). The show route uses the parameter `{room_unavailable}` while the method takes `$id`; that still resolves positionally today, and RUA-07 offers the clean fix.

### F6 — Controller shape

#### RUA-06 · H · CTL-02 — `store()` and `update()` exceed the 150-line hard limit

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — *method length: over 80 lines is M; over 150 lines is H* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php:87-243`, method `store()` (157 lines); same at `update()`:273-431 (159 lines) |
| **Root cause** | Both methods carry the inline 60-line validation array, a hand-written cross-field block, the overlap guard and the transaction. Without a FormRequest (RUA-04) the validation bulk is forced inside the controller body. |
| **Consequence** | The two longest methods in the controller are also the ones most likely to be edited; every edit has to scan 150+ lines, which is exactly how the two copies of the rules array (CTL-05) drifted historically. |
| **Reproduce** | Static only — method spans measured from the `grep -nE 'public function'` start lines: store starts at 87 and the next method starts at 248; update starts at 273 and the next at 436. |
| **Fix approach** | The RUA-04 FormRequest extraction removes the validation bulk and the cross-field block from both methods, dropping them well below 150 lines. |
| **Plan item** | none — see plan §10 (folded into RUA-04) |

```php
    public function store(Request $request)
    {
        Gate::authorize('tenant.smart-timetable.room-unavailable.create');

        /*
    |--------------------------------------------------------------------------
    | 1. Validate Input
    |--------------------------------------------------------------------------
    */
```

**Evidence**
```
$ grep -nE 'public function (store|update|show|destroy)\(' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php
87:    public function store(Request $request)
248:    public function show($id)
273:    public function update(Request $request, RoomUnavailable $roomUnavailable)
436:    public function destroy($id)
(store spans 87-243 = 157 lines; update spans 273-431 = 159 lines)
```

#### RUA-07 · M · CTL-03 — five methods take a raw `$id` and call `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php:248-252`, method `show()` (same at `edit()`:258-262, `destroy()`:436-442, `restore()`:469-473, `forceDelete()`:514-518) |
| **Root cause** | These five methods accept an untyped `$id` and resolve the record by hand. `update()` (273) and `toggleStatus()` (543) already bind `RoomUnavailable $roomUnavailable`. Three of the resource routes use the parameter `{room_unavailable}` while the method variable is `$id`. |
| **Consequence** | More code, a hand-written `findOrFail` in five places, and a route-parameter name that does not match the controller argument; a missing id still 404s, so behaviour is correct today. |
| **Reproduce** | Static only — no user-visible difference. |
| **Fix approach** | Bind the model. Because this changes route parameter names it is a DECISION (⚠ SHARED). |
| **Plan item** | RUA-07 (DECISION) in `02-fix-plan.md` §5 |

```php
    public function show($id)
    {
        Gate::authorize('tenant.smart-timetable.room-unavailable.view');

        $roomUnavailable = RoomUnavailable::with(['room', 'constraint'])->findOrFail($id);
```

**Evidence**
```
$ grep -nE 'public function (show|edit|destroy|restore|forceDelete|update|toggleStatus)\(' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php
248:    public function show($id)
258:    public function edit($id)
273:    public function update(Request $request, RoomUnavailable $roomUnavailable)
436:    public function destroy($id)
469:    public function restore($id)
514:    public function forceDelete($id)
543:    public function toggleStatus(Request $request, RoomUnavailable $roomUnavailable)
```

#### RUA-08 · L · CTL-04 — no public method declares a return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php:21-26`, method `index()` (same on all 11 public methods) |
| **Root cause** | Every action omits its return type, so the response shape of each method is documented nowhere. |
| **Consequence** | A later change that returns the wrong type (for example `back()` from a `view()` method) is caught only at runtime. |
| **Reproduce** | Static only — scanner CTL-04 fires at every method. |
| **Fix approach** | Add the response imports and type every public method. |
| **Plan item** | RUA-08 in `02-fix-plan.md` §5 |

```php
    public function index()
    {
        Gate::authorize('tenant.smart-timetable.room-unavailable.viewAny');

        return redirect()->route('smart-timetable.menu.constraintEngine');
    }
```

**Evidence**
```
$ grep -cE 'public function [a-zA-Z_]+\([^)]*\)\s*:' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php
0
```

#### RUA-09 · M · CTL-10 — the `index.blade.php` and `create.blade.php` views are dead

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *dead code: unreachable code left in the tree* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php:21-26`, method `index()` (renders no view) and `:31-41`, method `create()` (aborts 403); the dead files are `Modules/SmartTimetable/resources/views/room-unavailable/index.blade.php` (102 lines) and `create.blade.php` (165 lines) |
| **Root cause** | `index()` now just redirects to the Constraint Engine host page, and `create()` aborts 403 with the route excluded by `->except(['create'])`; the actual list and create form live under `resources/views/pages/partials/constraint-engine/room-unavailability/`. No route or controller renders either legacy blade. |
| **Consequence** | Two files no route can reach stay in the tree and mislead a reader into thinking a standalone index page and create page still exist; the `_create-fields.blade.php` header already says the fields were lifted from the retired page, so the shared content has already drifted. |
| **Reproduce** | Static only — `route:list` shows `index` at `smart-timetable.room-unavailable.index` redirects and no action renders a view; `create` is unrouted. |
| **Fix approach** | Delete both files after re-proving they are unreferenced. Recorded as a cleanup, not a mechanical fix — see plan §10. |
| **Plan item** | none — see plan §10 |

```php
    public function index()
    {
        Gate::authorize('tenant.smart-timetable.room-unavailable.viewAny');

        return redirect()->route('smart-timetable.menu.constraintEngine');
    }
```

**Evidence**
```
$ grep -rn "room-unavailable.index\|room-unavailable.create'" Modules/ resources/ | grep -v 'Http/Controllers'
Modules/SmartTimetable/resources/views/smart-timetable/partials/room-unavailable/_list.blade.php:42: <a href="{{ route('smart-timetable.room-unavailable.create') }}" class="btn btn-sm btn-outline-primary">
(only the old dead partial references the retired create route; neither legacy blade is rendered by any route)
```

### F7 — Models

#### RUA-10 · L · MDL-04 — the model's two relationships have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`)* |
| **Where** | `Modules/SmartTimetable/app/Models/RoomUnavailable.php:140-154` |
| **Root cause** | `room()` and `constraint()` both lack a return type; the sibling model `TeacherUnavailable` has the same gap (TUA-09) and the module's FormRequests already declare types. |
| **Consequence** | Low: an editor cannot see the relation type, and a wrong relation class is caught only at runtime. The relations themselves resolve (`room()` → `Modules\SchoolSetup\Models\Room`, `constraint()` → `Modules\SmartTimetable\Models\Constraint`). |
| **Reproduce** | Static only. |
| **Fix approach** | Add `: BelongsTo` to both and import the relation class. |
| **Plan item** | RUA-10 in `02-fix-plan.md` §5 |

```php
    public function room()
    {
        return $this->belongsTo(
            Room::class,
            'room_id'
        );
    }

    public function constraint()
    {
        return $this->belongsTo(
            Constraint::class,
            'constraint_id'
        );
    }
```

**Evidence**
```
$ grep -nE 'public function (room|constraint)\(' Modules/SmartTimetable/app/Models/RoomUnavailable.php
140:    public function room()
148:    public function constraint()
$ php artisan tinker --execute '...' (tenant xyz_school_00000000000040008000_202627)
$m = new RoomUnavailable(); echo $m->room()->getRelated();   // Modules\SchoolSetup\Models\Room
                                                              // Modules\SmartTimetable\Models\Constraint
```

**Rest of F7 — checked, clean:** `$table = 'tt_room_unavailabilities'` exists in the live tenant schema (SHOW TABLES hit, MDL-07); `$fillable` is declared and holds no sensitive column (MDL-01); `$casts` covers every boolean, date and integer column plus all three timestamps — the DDL shows no json or decimal column that is left uncast (MDL-02); `SoftDeletes` matches the table's `deleted_at` (MDL-03 n/a — no pivot; MDL-05 n/a — no Spatie media); no global scope runs an expensive subquery (MDL-08); the `DAYS` map and the period-range helpers are model constants, not controller literals (MDL-09).

### F8 — Services and jobs

clean — this controller injects no service and dispatches no job; all work is in the controller and the model. `grep -nE 'Service|Job|dispatch|event\(' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php` → no output. `RoomAllocationPass` and `RoomChangeTrackingService` are not referenced (F, no output), so the JOB/SVC family had nothing to check.

### F9 — Queries and performance

clean — `trashedRoomUnavailable()` paginates at the house standard 10 (`->paginate(10)` at line 507, QRY-02); `show()` eager-loads `['room', 'constraint']` (line 251) and `trashedRoomUnavailable()` eager-loads `['room']` (line 505), and every relation the blades touch is loaded — no N+1 (QRY-01); `edit()` loads two bounded dropdowns (`Room::where('is_active', true)->get()` = 68 rows, `Constraint::where('is_active', true)->get()` = 5 rows); the overlap guard uses `->exists()` not `->get()->count()` (QRY-04); the single raw expression is `whereRaw('COALESCE(period_to, period_from) >= ?', [$newFrom])` at line 82 — parameterised, so QRY-11 is clean; no query sits inside a loop (`grep -nE 'foreach'` → no output). Evidence: `grep -n "paginate("` → one hit, line 507, `->paginate(10);`; `grep -n "with(\["` → lines 251 and 505.

### F10 — Views

clean — no queries, no eager-load gaps, no unescaped output: `grep -nE 'Model::|DB::|->get\(|\{!!|->count\(' Modules/SmartTimetable/resources/views/room-unavailable/show.blade.php Modules/SmartTimetable/resources/views/room-unavailable/edit.blade.php Modules/SmartTimetable/resources/views/room-unavailable/trash.blade.php` → no output (VIEW-01, VIEW-03); `show` and `trash` use the `room`/`constraint` relations that the controller eager-loads (VIEW-02); row actions use `x-backend.table.action` (list partial) and trash actions use `x-backend.table.action-trashed` with `restorePermission`/`forceDeletePermission` (trash.blade.php:70-74), and the status switch uses `x-backend.table.status-switch` with `permission="tenant.smart-timetable.room-unavailable.update"` (list partial:90-92); the create/edit forms stay under 16 controls so a modal is the right shape for create; breadcrumbs pass `:links="[]"` (module-wide convention, see §7). The dead `index.blade.php`/`create.blade.php` are counted as RUA-09.

### F11 — Security and tenancy

clean — no `env(` anywhere, no hard-coded ids or `?? 1` fallbacks (grep A → no output; SEC-01, SEC-03); no secrets logged and the only `Log::error` entries carry ids, not request bodies (SEC-04); the one raw SQL is parameterised (QRY-11); no cache is used, so there is no tenant-cache-key risk (TEN-02); no central model is touched from tenant code (TEN-03); no media, so TEN-01/MDL-05 n/a. Every method authorizes before loading the record (AUTH-02).

### F12 — Style

#### RUA-11 · L · STY-01 + STY-04 — the controller has no `declare(strict_types=1)` and carries an emoji marker and a stray copy-pasted docblock

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files*; STY-04 (L) — *English comments, no emoji markers, no copy-pasted docblocks* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php:1-3` |
| **Root cause** | The file opens with `<?php` and jumps straight to the namespace; line 551 carries a `⚠ ` marker; and lines 43-45 carry a stray docblock, "Store a newly created resource in storage.", sitting directly above the `applyPeriodOverlap()` docblock (lines 46-65) — a copy-paste left over from an earlier `store()` placement, so `store()` itself (line 87) has no docblock. |
| **Consequence** | Silent type coercion stays on; the emoji marker is inconsistent with the plain-English comment standard; the stray docblock describes a method it is not attached to, which misleads a reader of the private helper. |
| **Reproduce** | Static only — `head`/`grep` of the file. |
| **Fix approach** | Add the declaration after the opening tag, replace the `⚠ ` prefix with a plain word, delete the stray "Store a newly created resource in storage." docblock, and move that description into a docblock on `store()`. |
| **Plan item** | RUA-11 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SmartTimetable\Http\Controllers;
```

**Evidence**
```
$ grep -c "declare(strict_types" Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php
0
$ grep -nP '[\x{26A0}\x{26D4}]' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php
551:        // ⚠ Rule A3 — activityLog now runs AFTER save(), not before it.
$ sed -n '43,45p' Modules/SmartTimetable/app/Http/Controllers/RoomUnavailableController.php
    /**
     * Store a newly created resource in storage.
     */
```

#### RUA-12 · L · STY-01 + STY-04 — the model has no `declare(strict_types=1)` and carries an emoji marker in a comment

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files*; STY-04 (L) — *comments in English, no emoji markers* |
| **Where** | `Modules/SmartTimetable/app/Models/RoomUnavailable.php:1-3` |
| **Root cause** | The model file opens with `<?php` and has no strict-types declaration; the `$fillable` docblock at line 30 opens with a `⚠ ` marker. |
| **Consequence** | Type coercion stays silent for the model's casts and helpers; low impact but inconsistent with both module FormRequests, which already declare `strict_types`. |
| **Reproduce** | Static only — `head`/`grep` of the file. |
| **Fix approach** | Add the declaration after the opening tag and replace the `⚠ ` prefix with a plain word. |
| **Plan item** | RUA-12 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SmartTimetable\Models;
```

**Evidence**
```
$ grep -c "declare(strict_types" Modules/SmartTimetable/app/Models/RoomUnavailable.php
0
$ grep -nP '[\x{26A0}\x{26D4}]' Modules/SmartTimetable/app/Models/RoomUnavailable.php
30:     * ⚠ period_from / period_to, NOT period_ord.
```

**Rest of F12 — checked:** camelCase variables, one import per class, no commented-out code, no `extract()` and no `compact()` over 15 variables (`compact('roomUnavailable')`, `compact('roomUnavailables')` and a four-item `compact` in `edit()`), flash text through `flash()` keys.

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Overwrite | 2 Delete-first | 3 Dup impl | 4 Soft-del × unique | 5 Race | 6 Auth hole | 7 Lying msg | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | n/a | RUA-04 | ok | RUA-03 | ok | ok | ok |
| `update` | ok | n/a | RUA-04 | ok | RUA-03 | ok | ok | ok |
| `destroy` | ok — sets `is_active=false` then soft-deletes | n/a | ok | ok | ok | ok | ok | ok |
| `restore` | RUA-03 — restores then re-activates with no overlap check | n/a | ok | ok | RUA-03 | ok | ok | ok |
| `forceDelete` | ok | ok — no child FK references the table | ok | n/a | ok | ok | ok | ok |
| `toggleStatus` | RUA-03 — activating can create an overlap the guard skipped | n/a | ok | n/a | RUA-03 | ok | ok | ok |

Notes: **wrong data** — `update()` writes only the validated payload, and both write paths force `start_date`/`end_date` to null for a recurring rule so a stale date cannot silently narrow it (question 1 checks out); the overlap re-activation gap in `restore()`/`toggleStatus()` is RUA-03 (`applyPeriodOverlap` is called only at lines 196 and 383). **irreversible order** — no file or row is deleted before its replacement; the `forceDelete` activityLog deliberately runs after `forceDelete()` because Eloquent keeps the key populated on the instance (comment lines 524-526). **duplicate implementations** — the overlap guard is already extracted (`applyPeriodOverlap()`), but the validation rules and the recurring/date block are duplicated between `store()` and `update()` (RUA-04). **soft-delete × unique** — no unique index exists, so there is no 1062 trap, which is exactly why RUA-03 flags the missing index. **messages** — every flash resolves through `config/flash.php` (keys `created`, `updated`, `deleted`, `restored`, `force_deleted`, `status_updated`, `status_switch_failed`, `operation_failed` all exist) and no flash carries exception text. **dead feature** — the whole screen currently holds 0 live rows, but the feature is wired end to end; the genuinely dead artifacts are the two legacy blades (RUA-09).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SmartTimetable/resources/views/smart-timetable/partials/room-unavailable/_list.blade.php:42` | The old partial still calls `route('smart-timetable.room-unavailable.create')`, but the `create` route is excluded by `->except(['create'])`, so rendering it throws `RouteNotFoundException`. The live tab partial is under `pages/partials/constraint-engine/`; this file appears dead. | RTE-02 / VIEW | the SmartTimetable views pass |
| `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/room-unavailability/_list.blade.php` | The `x-tenantcore::export-buttons` component is view-gated on `tenant.smart-timetable.room-unavailable.export`, and the blade's own comment says `ExportController` has no `Gate::` call, so the endpoint is reachable by anyone who knows it. The export controller is another audit's scope. | AUTH-01 | the TenantCore export controller report |
| `Modules/SmartTimetable/app/Http/Controllers/TimetableMenuController.php` | The host page builds `$dlgRooms`, `$dlgRoomConstraints`, `$dlgRoomDays` and the filter lists for this tab; the create-dialog fields (and their validation contract) live in that controller's scope. | — | the TimetableMenuController audit |
| All `room-unavailable/*.blade.php` | Each passes `:links="[]"` to `x-backend.components.breadcrum`, so no page carries a breadcrumb trail. Module-wide convention. | VIEW (UI standard) | SmartTimetable views pass |
| `Modules/Dashboard/app/Services/TimetableManagement/TimetableSuggestionService.php:1483` | Builds a "Room unavailability" link to `smart-timetable.room-unavailable.index`, which now redirects to the Constraint Engine page; the link works but lands the user one click away from the tab. Informational. | — | Dashboard report |

## 8. Not covered, and why

- The pages were not opened in a browser; no server was run for this read-only audit (D4 forbids tests).
- The AJAX `toggleStatus` response was not exercised live — the test tenant has 0 rows, so the switch has nothing to toggle; the method's shape was read statically.
- `Modules/SmartTimetable/app/Models/Constraint.php`, `ConstraintCategoryScope.php` and `Modules/SchoolSetup/app/Models/Room.php` are owned elsewhere / common; this report checked only how this controller and its model use them.
- `Modules/SmartTimetable/app/Services/RoomAllocationPass.php` and `RoomChangeTrackingService.php` exist but are not referenced by this controller or its model (grep F returned no output), so they are out of scope (D7) and were not claimed or audited.
- The constraint-engine host page (`TimetableMenuController@constraintEngine`) and its tab partials, including `pages/partials/constraint-engine/room-unavailability/*`, are a different controller's scope and were not audited here.
- No queue job, listener or scheduled task is dispatched by this controller, so the JOB family had nothing to check.