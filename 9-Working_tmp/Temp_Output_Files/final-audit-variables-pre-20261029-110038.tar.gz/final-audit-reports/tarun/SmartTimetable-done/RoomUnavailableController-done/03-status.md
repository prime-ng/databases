# Status — SmartTimetable / RoomUnavailableController

**Fixed:** 2026-10-15 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

Decisions (Tarun, 2026-10-15): restore becomes PUT; bind the resource methods; accept the save race with a comment.

## 1. Pre-applied work
none

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| RUA-01 | RoomUnavailableController.php (destroy/restore/forceDelete/toggleStatus) | try/catch removed (D1); writes in `DB::transaction`, response after the closure. Toggle failure is escalated to an exception so the log rolls back | `grep -c "try {"` | 0 | 2026-10-15 |
| RUA-03 | Controller:66 | accepted (choice a); RUA-03 note in the `applyPeriodOverlap()` docblock | grep | 1 hit | 2026-10-15 |
| RUA-04 | new StoreRoomUnavailableRequest.php, UpdateRoomUnavailableRequest.php | inline rules moved into FormRequests; `authorize()` checks create/update; the recurring-vs-dated check lives in `after()` ("Start or end date is required for non-recurring unavailability."). Controller store/update take the requests; `Log`/`Rule` imports removed | `grep -c '$request->validate('` | 1 (toggle only) | 2026-10-15 |
| RUA-05 | routes/web.php:284 | restore is `Route::put` | router probe | `PUT …room-unavailable.restore` | 2026-10-15 |
| RUA-07 | Controller show/edit/update/destroy/toggleStatus | bound to `RoomUnavailable $roomUnavailable` via the snake-case fallback (no rename); show eager-loads `room`,`constraint`; restore/forceDelete stay on `$id` | reflection | `{room_unavailable}` ↔ typed arg | 2026-10-15 |
| RUA-08 | Controller | return types on all 11 public methods; `create(): never` | grep | 11/11 | 2026-10-15 |
| RUA-10 | Models/RoomUnavailable.php:142,150 | `room(): BelongsTo`, `constraint(): BelongsTo` | grep | 2 hits | 2026-10-15 |
| RUA-11 | Controller | `strict_types`, emoji marker replaced with "Note:", stray docblock removed | grep strict / emoji | 1 / 0 | 2026-10-15 |
| RUA-12 | Models/RoomUnavailable.php | `strict_types`, emoji replaced; Pint dropped one unused import (BelongsTo kept — verified) | grep | 1 / 0 | 2026-10-15 |

## 3. Not applied
None — every item was ticked and applied.

## 4. Needs Tarun's hand
- **Run the Dusk suites yourself.** Restore is now PUT on all five resources, so the "GET /{missing}/restore expects 404" tests will fail: `TtConstraintsTest:1528`, `TtConstraintTypeTest:1465`, `TtRoomUnavailableTest:1440` and the matching test in `TtTeacherUnavailableTest`. A GET on those URLs is now a 405 (or the DecryptUrl redirect). Not edited — tests are out of scope (D4).
- A browser check of the trash page Restore button on each of the five tabs of `/smart-timetable/constraint-engine` (it should submit `_method=PUT`).
- No migration, seeder or permission sync is needed.
- **Behaviour change:** a failed status toggle used to return 422 JSON; it is now the central handler's JSON error (D1). The switch JS still sees a non-2xx and reverts.

## 5. Unverifiable by this workflow (no tests, D4)
- The failure path of every mutation now relies on the central handler (D1).
- The overlap race and the toggle/restore re-activation bypass (RUA-03) are accepted, not fixed.

## 6. Verification log
```
php -l   (all touched PHP files)                      -> No syntax errors
class_exists (22 classes: 5 controllers, 6 requests,
  5 models, ConstraintManager/Evaluator/Factory,
  DatabaseConstraintService, 2 constraint classes)     -> all true
vendor/bin/pint <touched files> --format agent         -> fixed; php -l + class_exists re-run after
router probe (uncached)                                -> PUT smart-timetable.{constraint,constraint-category-scope,
                                                          constraint-type,teacher-unavailable,room-unavailable}.restore
                                                          every routed action: method_exists ok
grep "getMessage" / "^use ...Facades\\Log;" in the 5 controllers -> 0 / 0
```

## 7. Final state
Status: FIXED · Open: B 0 · H 0 · M 1 · L 0
(M: RUA-03 accepted race.)
