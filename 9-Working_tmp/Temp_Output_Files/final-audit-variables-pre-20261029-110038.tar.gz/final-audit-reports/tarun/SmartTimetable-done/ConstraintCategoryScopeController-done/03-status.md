# Status — SmartTimetable / ConstraintCategoryScopeController

**Fixed:** 2026-10-15 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

Decisions (Tarun, 2026-10-15): restore becomes PUT on all five Constraint Engine resources; bind the resource methods; accept the save race with a comment.

## 1. Pre-applied work
none

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| CCS-01 | ConstraintCategoryScopeController.php (all mutations) | controller try/catch removed (D1); writes in `DB::transaction` closures, response built after | `grep -c "try {" …Controller.php` | 0 | 2026-10-15 |
| CCS-04 | ConstraintCategoryScopeRequest.php:13-19 | `authorize()` returns true; the controller's `Gate::authorize` is the single gate | read `authorize()` | `return true` + comment | 2026-10-15 |
| CCS-05 | ConstraintCategoryScopeRequest.php:53 | `is_active` typed `['nullable','boolean']` | grep | line 53 | 2026-10-15 |
| CCS-06 | routes/web.php:264 | restore is `Route::put` (PUT, not POST — Tarun's verb choice for all five) | router probe | `PUT …constraint-category-scope.restore` | 2026-10-15 |
| CCS-07 | Controller show/edit/update/destroy | bound to `ConstraintCategoryScope $constraintCategoryScope`; restore/forceDelete/toggleStatus stay on `$id` (choice a) | reflection vs `parameterNames()` | `{constraint_category_scope}` ↔ typed arg | 2026-10-15 |
| CCS-08 | Controller | return type on all 11 public methods | `grep -cE 'public function …\):'` | 11/11 | 2026-10-15 |
| CCS-09 | ConstraintCategoryScopeRequest.php:41 | accepted (choice a); CCS-09 comment beside the `name` rule | grep "CCS-09" | 1 hit | 2026-10-15 |
| CCS-10 | Models/Constraint.php | `strict_types`, Model import, emoji replaced | `grep -c strict_types` / `⚠` | 1 / 0 | 2026-10-15 |
| CCS-11 | Models/ConstraintCategoryScope.php | `strict_types`, Pint | `grep -c strict_types` | 1 | 2026-10-15 |
| CCS-12 | Controller:168 | Pint spacing | pint | clean | 2026-10-15 |
| CCS-13 | ConstraintCategoryScopeRequest.php:23 | `$id` un-aligned (Pint) | pint | clean | 2026-10-15 |

## 3. Not applied
None — every item was ticked and applied.

## 4. Needs Tarun's hand
- **Run the Dusk suites yourself.** Restore is now PUT on all five resources, so the "GET /{missing}/restore expects 404" tests will fail: `TtConstraintsTest:1528`, `TtConstraintTypeTest:1465`, `TtRoomUnavailableTest:1440` and the matching test in `TtTeacherUnavailableTest`. A GET on those URLs is now a 405 (or the DecryptUrl redirect). Not edited — tests are out of scope (D4).
- A browser check of the trash page Restore button on each of the five tabs of `/smart-timetable/constraint-engine` (it should submit `_method=PUT`).
- No migration, seeder or permission sync is needed.

## 5. Unverifiable by this workflow (no tests, D4)
- The failure path of every mutation now relies on the central handler (D1). Statically confirmed; not driven in a browser.
- The save race (CCS-09) is accepted, not fixed.

## 6. Verification log
```
php -l   (all touched PHP files)                      -> No syntax errors
class_exists (22 classes: 5 controllers, 6 requests,
  5 models, ConstraintManager/Evaluator/Factory,
  DatabaseConstraintService, 2 constraint classes)     -> all true
vendor/bin/pint <touched files> --format agent         -> fixed; php -l + class_exists re-run after
router probe (uncached)                                -> PUT smart-timetable.{constraint,constraint-category-scope,
                                                          constraint-type,teacher-unavailable,room-unavailable}.restore
                                                          every routed action: method_exists ok
grep "getMessage" / "^use ...Facades\\Log;" in the 5 controllers -> 0 / 0
```

## 7. Final state
Status: FIXED · Open: B 0 · H 0 · M 1 · L 0
(M: CCS-09 accepted race.)
