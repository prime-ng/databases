# Final Audit — SmartTimetable / ConstraintCategoryScopeController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php` (301 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /smart-timetable/constraint-category-scope` (redirects) · `GET /smart-timetable/constraint-engine?tab=category-scope` (the real list) · `GET /smart-timetable/constraint-category-scope/{id}` · `GET /smart-timetable/constraint-category-scope/{id}/edit` · `POST /smart-timetable/constraint-category-scope` · `PUT /smart-timetable/constraint-category-scope/{id}` · `DELETE /smart-timetable/constraint-category-scope/{id}` · `POST /smart-timetable/constraint-category-scope/{id}/toggle-status` · `GET /smart-timetable/constraint-category-scope/trash/view` · `GET /smart-timetable/constraint-category-scope/{id}/restore` · `DELETE /smart-timetable/constraint-category-scope/{id}/force-delete` |
| Menu path | Smart Timetable → Constraint Engine → Categories & Scopes tab |
| Who uses it | Super Admin (role 1) and School Admin (role 2). Measured for the restore ability: `sys_permissions` id 1693 → `sys_role_has_permissions_jnt` role_ids 1 and 2. All eight `tenant.smart-timetable.constraint-category-scope.*` abilities are seeded in the tenant. |
| What a user does here | A timetable administrator defines the **buckets** that school rules fall into: CATEGORY rows (for example GLOBAL, TEACHER) and SCOPE rows (for example a period range). Each bucket carries a short CODE and a NAME. The code is what every constraint row stores in `tt_constraints.target_type`, so this screen is the vocabulary the rest of the Constraint Engine reads. The user adds a bucket through the dialog on the Constraint Engine page, edits it on a page, toggles it active/inactive from the list, soft-deletes it, and restores or permanently deletes it from the trash page. This controller's own `index()` does not render a list — it redirects to the Constraint Engine tab. |
| Tables written | `tt_constraint_category_scopes`, `sys_activity_logs` (through the `activityLog()` helper, tenant log) |
| Tables read | `tt_constraint_category_scopes` (this controller). The sibling `tt_constraints` table consumes the `code` values but is not read here. |
| Live data | `tt_constraint_category_scopes` 27 live, 0 trashed · `tt_constraints` 6 live. The table's unique key is `uq_constraint_category_scope (type, code)`; there is no index on `name`. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Production-ready after the one high and the medium fixes — there is no blocker.** The screen does its job today: create, update, soft-delete, restore, permanent-delete and toggle all write a row plus an audit row inside one transaction, and every method authorizes before it loads anything.

The single worst finding is **CCS-06 (high)**: the restore action is registered as a `GET`, so it changes state without a CSRF token and can be triggered by anything that merely fetches the URL (browser prefetch, a link scanner). The next most important is **CCS-01 (medium)**: all six mutating methods keep a house-A1 `try/catch` that D1 bans, and the catch in `store()` swallows every failure into a generic flash. The rest are validation, style and maintainability issues.

Rough effort: about half a day. One `H` and six `M` findings, two of which are DECISION items (route-model binding and the app-only name uniqueness); the remaining six are `L` style and typing.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 6 | 6 | 2 | 13 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CCS-01, CCS-02 | F8 Services/Jobs | clean — none referenced |
| F2 Transactions/Audit | CCS-03, CCS-09 | F9 Queries/Perf | clean — see family section |
| F3 Authorization | CCS-04 | F10 Views | clean — see family section |
| F4 Validation | CCS-05 | F11 Security/Tenancy | clean — see family section |
| F5 Routes | CCS-06 | F12 Style | CCS-10, CCS-11, CCS-12, CCS-13 |
| F6 Controller shape | CCS-07, CCS-08 | F13 Deep read | answers in the family section |
| F7 Models | clean — audited below, no model-level defect | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php` | controller | 301 | this report | ✅ whole class |
| 2 | `Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php` | model | 69 | this report (pre-assigned by main session 2026-10-10) | ✅ whole class |
| 3 | `Modules/SmartTimetable/app/Models/Constraint.php` | model | 255 | this report (pre-assigned by main session 2026-10-10) | ✅ whole class |
| 4 | `Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php` | request | 64 | this report (only this controller uses it; not registered) | ✅ whole class |
| 5 | `Modules/SmartTimetable/routes/web.php` lines 259-263 | routes | — | this report | ✅ |
| 6 | `Modules/SmartTimetable/resources/views/constraint-category-scope/form.blade.php` | view | 82 | this report | ✅ |
| 7 | `Modules/SmartTimetable/resources/views/constraint-category-scope/show.blade.php` | view | 53 | this report | ✅ |
| 8 | `Modules/SmartTimetable/resources/views/constraint-category-scope/trash.blade.php` | view | 74 | this report | ✅ |
| — | `App\Http\Controllers\Controller`, `Request`, `Gate`, `DB`, `Log`, `ModelNotFoundException`, `activityLog()`, `flash()`, `App\View\Components\Backend\Table\ActionTrashed`, `Modules\GlobalMaster\Models\ActivityLog` | common | — | common | referenced only |
| — | `Modules/SchoolSetup/**` models (`User`, `Room`, `SchoolClass`, `Teacher`), `Modules\TimetableFoundation\Models\{AcademicTerm, Activity}` | other module | — | common via `Constraint` | referenced only |

No pre-applied files for this controller.

## 4. Routes

```
GET|HEAD smart-timetable/constraint-category-scope                  smart-timetable.constraint-category-scope.index         ...@index
POST     smart-timetable/constraint-category-scope                  smart-timetable.constraint-category-scope.store         ...@store
GET|HEAD smart-timetable/constraint-category-scope/trash/view       smart-timetable.constraint-category-scope.trashed      ...@trashed
GET|HEAD smart-timetable/constraint-category-scope/{constraint_category_scope}  smart-timetable.constraint-category-scope.show     ...@show
PUT|PATCH smart-timetable/constraint-category-scope/{constraint_category_scope}  smart-timetable.constraint-category-scope.update   ...@update
DELETE  smart-timetable/constraint-category-scope/{constraint_category_scope}  smart-timetable.constraint-category-scope.destroy   ...@destroy
GET|HEAD smart-timetable/constraint-category-scope/{constraint_category_scope}/edit  smart-timetable.constraint-category-scope.edit   ...@edit
POST    smart-timetable/constraint-category-scope/{constraint_category_scope}/toggle-status  smart-timetable.constraint-category-scope.toggleStatus  ...@toggleStatus
DELETE  smart-timetable/constraint-category-scope/{id}/force-delete smart-timetable.constraint-category-scope.forceDelete ...@forceDelete
GET|HEAD smart-timetable/constraint-category-scope/{id}/restore     smart-timetable.constraint-category-scope.restore       ...@restore
```

Middlewares (uncached `route:list --json`), identical on every route above: `web, Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains, Stancl\Tenancy\Middleware\InitializeTenancyByDomain, App\Http\Middleware\EnsureTenantIsActive, Illuminate\Auth\Middleware\Authenticate, Illuminate\Auth\Middleware\EnsureEmailIsVerified, App\Http\Middleware\EnsureTenantHasModule:smart-timetable` (RTE-05 satisfied).

Unrouted public methods: `create` (`ConstraintCategoryScopeController.php:25`) — the body is `abort(403, ...)` with a `NOT ROUTED` comment, which is the D5-sanctioned shape, so it is not a finding. Everything else is routed. The two private helpers `resolveType()` and `label()` are both called, so neither is dead code.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 18 | GET /smart-timetable/constraint-category-scope | `tenant.smart-timetable.constraint-category-scope.viewAny` | none (read) | none | none | CCS-08 |
| `create` | 25 | not routed (D5 — `abort(403)`) | none | none | none | none | CCS-08 |
| `store` | 42 | POST /smart-timetable/constraint-category-scope | `tenant.smart-timetable.constraint-category-scope.create` | controller | `Stored` (inside tx) | tt_constraint_category_scopes, sys_activity_logs | CCS-01, CCS-02, CCS-03, CCS-04, CCS-08, CCS-09 |
| `show` | 71 | GET .../{constraint_category_scope} | `tenant.smart-timetable.constraint-category-scope.view` | none (read) | none | none | CCS-07, CCS-08 |
| `edit` | 80 | GET .../{constraint_category_scope}/edit | `tenant.smart-timetable.constraint-category-scope.update` | none (read) | none | none | CCS-07, CCS-08 |
| `update` | 94 | PUT|PATCH .../{constraint_category_scope} | `tenant.smart-timetable.constraint-category-scope.update` | controller | `Updated` (inside tx) | tt_constraint_category_scopes, sys_activity_logs | CCS-01, CCS-02, CCS-03, CCS-04, CCS-07, CCS-08, CCS-09 |
| `destroy` | 132 | DELETE .../{constraint_category_scope} | `tenant.smart-timetable.constraint-category-scope.delete` | controller | `Trashed` (inside tx) | tt_constraint_category_scopes, sys_activity_logs | CCS-01, CCS-02, CCS-03, CCS-07, CCS-08 |
| `trashed` | 161 | GET /.../trash/view | `tenant.smart-timetable.constraint-category-scope.restore` | none (read) | none | none | CCS-08 |
| `forceDelete` | 182 | DELETE .../{id}/force-delete | `tenant.smart-timetable.constraint-category-scope.forceDelete` | controller | `Deleted` (inside tx) | tt_constraint_category_scopes, sys_activity_logs | CCS-01, CCS-02, CCS-03, CCS-07, CCS-08 |
| `restore` | 215 | GET .../{id}/restore | `tenant.smart-timetable.constraint-category-scope.restore` | controller | `Restored` (inside tx) | tt_constraint_category_scopes, sys_activity_logs | CCS-01, CCS-02, CCS-03, CCS-06, CCS-07, CCS-08 |
| `toggleStatus` | 249 | POST .../{constraint_category_scope}/toggle-status | `tenant.smart-timetable.constraint-category-scope.update` | controller | `Toggled` (inside tx) | tt_constraint_category_scopes, sys_activity_logs | CCS-01, CCS-02, CCS-07, CCS-08, CCS-12 |
| `resolveType` (private) | 285 | — | — | none | none | none | — |
| `label` (private) | 297 | — | — | none | none | none | — |

**Tables each mutation SHOULD touch:** every mutation should write exactly one row in `tt_constraint_category_scopes` plus one audit row in `sys_activity_logs`. Counting across the controller (there is no service), each of `store`, `update`, `destroy`, `forceDelete`, `restore` and `toggleStatus` does exactly that, inside one `DB::transaction`. F2 is therefore clean on placement; CCS-03 is only about the response being built inside the closure.

## 6. Findings

### F1 — Errors

#### CCS-01 · M · ERR-00 (D1) — all six mutating methods keep a try/catch that D1 bans

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M) — the Laravel idiom: no try/catch in a controller; `DB::transaction()` rolls back and rethrows by itself and the central handler in `bootstrap/app.php` renders the error. D1 settles this for modules under final audit, and house rule A1 does not apply here. None of the D2 shapes (a business `\DomainException`, a truncate-then-rebuild, a `SnapshotProtectionException`) is present. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php:46-68` (`store`), and the same shape at `:98-124` (`update`), `:136-158` (`destroy`), `:186-207` (`forceDelete`), `:219-241` (`restore`), `:255-282` (`toggleStatus`) |
| **Root cause** | The file was written to house rule A1: every mutation is wrapped in `try { DB::transaction(...) } catch (\Throwable) { Log; friendly flash }`, with a `catch (ModelNotFoundException) { throw $e; }` re-throw on four of the six. D1 overrides A1 for this module, so each of the six catches is a place that builds a hand-made failure response instead of letting the transaction rethrow to the central renderer. |
| **Consequence** | `store()` has no `findOrFail` and therefore no 404 re-throw, so *every* failure on create — including a database error such as a unique-key collision from two admins saving the same code — is flattened into the generic "operation failed" flash and never reaches the app's central logging/rendering path. The other five catches do the same for non-404 failures while adding a redundant 404 branch. |
| **Reproduce** | Static only — the catches fire on any thrown exception; there is no deterministic browser action that throws today. |
| **Fix approach** | Delete all six `try`/`catch` blocks (D1). Keep `Gate::authorize()` and the request validation or `findOrFail()` above the `DB::transaction()`, return the record (or nothing) from the closure, and build the redirect / JSON after it. That single rewrite also removes CCS-02 (message-only logging) and CCS-03 (response built inside the transaction). |
| **Plan item** | CCS-01 in `02-fix-plan.md` §3 |

```php
        try {
            return DB::transaction(function () use ($request) {
                $record = ConstraintCategoryScope::create([
                    'type' => $request->validated('type'),
                    'code' => $request->validated('code'),
                    'name' => $request->validated('name'),
                    'description' => $request->validated('description'),
                    'is_active' => $request->boolean('is_active'),
                ]);

                activityLog($record, 'Stored', [
                    'message' => "Constraint {$this->label($record->type)} was created successfully.",
                ]);

                return redirect()
                    ->route('smart-timetable.menu.constraintEngine', ['tab' => 'category-scope'])
                    ->with('success', flash('created.constraint_category_scope'));
            });
        } catch (\Throwable $e) {
            Log::error('ConstraintCategoryScope store failed', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', flash('operation_failed.constraint_category_scope'));
        }
```

**Evidence**
```
$ grep -n "try {\|catch (" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php
46:        try {
64:        } catch (\Throwable $e) {
98:        try {
118:        } catch (ModelNotFoundException $e) {
120:        } catch (\Throwable $e) {
136:        try {
152:        } catch (ModelNotFoundException $e) {
154:        } catch (\Throwable $e) {
186:        try {
201:        } catch (ModelNotFoundException $e) {
203:        } catch (\Throwable $e) {
219:        try {
235:        } catch (ModelNotFoundException $e) {
237:        } catch (\Throwable $e) {
255:        try {
273:        } catch (ModelNotFoundException $e) {
275:        } catch (\Throwable $e) {
```

#### CCS-02 · M · ERR-05 — the catches log only `getMessage()`, losing the trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — log the exception, not the message: `report($e)` or `Log::error(..., ['exception' => $e])`. `getMessage()` alone loses the trace. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php:65`, also `:121`, `:155`, `:204`, `:238`, `:276` |
| **Root cause** | Each catch builds the log context as `['error' => $e->getMessage()]`, which serialises only the human-readable string. |
| **Consequence** | An operator reading the log after an incident sees one sentence with no file, line or stack trace, so the failing write cannot be located from the log alone. |
| **Reproduce** | Static only — every catch logs a bare message string. |
| **Fix approach** | Covered by CCS-01: the D1 rewrite deletes these six catches, so nothing logs `getMessage()` any more and the central handler records the full exception. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
        } catch (\Throwable $e) {
            Log::error('ConstraintCategoryScope store failed', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', flash('operation_failed.constraint_category_scope'));
        }
```

**Evidence**
```
$ grep -n "getMessage" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php
65:            Log::error('ConstraintCategoryScope store failed', ['error' => $e->getMessage()]);
121:            Log::error('ConstraintCategoryScope update failed', ['id' => $id, 'error' => $e->getMessage()]);
155:            Log::error('ConstraintCategoryScope destroy failed', ['id' => $id, 'error' => $e->getMessage()]);
204:            Log::error('ConstraintCategoryScope forceDelete failed', ['id' => $id, 'error' => $e->getMessage()]);
238:            Log::error('ConstraintCategoryScope restore failed', ['id' => $id, 'error' => $e->getMessage()]);
276:            Log::error('ConstraintCategoryScope toggleStatus failed', ['id' => $id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### CCS-03 · M · TXN-05 — the redirect/response is built inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — the transaction closure returns data; `redirect()` / `response()` are built after it. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php:60-62` (`store`), also `:114-116` (`update`), `:148-150` (`destroy`), `:197-199` (`forceDelete`), `:231-233` (`restore`) |
| **Root cause** | Each closure's `return` statement is the HTTP response object, so the response is assembled before the transaction commits. |
| **Consequence** | The success payload is built inside the write; if the commit failed, a success redirect/object would already have been constructed. It also mixes HTTP concerns into the data-layer closure. |
| **Reproduce** | Static only — no browser path distinguishes it today. |
| **Fix approach** | Covered by CCS-01's rewrite: return the record (or `null`) from the closure and build the redirect after it. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
                return redirect()
                    ->route('smart-timetable.menu.constraintEngine', ['tab' => 'category-scope'])
                    ->with('success', flash('created.constraint_category_scope'));
```

**Evidence**
```
$ grep -n "return redirect()\|return response()->json" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php
22:        return redirect()->route('smart-timetable.menu.constraintEngine', ['tab' => 'category-scope']);
60:                return redirect()
114:                return redirect()
148:                return redirect()
197:                return redirect()
231:                return redirect()
268:            return response()->json([
278:            return response()->json([
```

#### CCS-09 · M · TXN-06 — `name` uniqueness is enforced only in PHP; no database index guards it

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M, raised reason: it is a check-then-act on a write path; lowered from H because this is a low-traffic admin config screen) — check-then-act needs a lock or a unique index. |
| **Where** | `Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php:42-49`, method `rules()` |
| **Root cause** | The request requires `(type, name)` uniqueness, but the table's only unique key is `uq_constraint_category_scope (type, code)`; there is no index on `name`. Two concurrent creates with the same name both pass validation and both insert. |
| **Consequence** | Two buckets of one type can end up with the same display name; the form promised uniqueness the database never enforced. Codes are safe because the database does guard them. |
| **Reproduce** | Static only — `SHOW CREATE TABLE tt_constraint_category_scopes` lists only `uq_constraint_category_scope (type, code)`, and no lock is taken around the check. |
| **Fix approach** | DECISION: accept the residual concurrency risk on this single-admin screen (and add a one-line comment naming CCS-09), or add a unique index on `(type, name)` in an additive migration — which is Tarun's hand and re-opens the soft-delete interaction. |
| **Plan item** | CCS-09 in `02-fix-plan.md` §9 (DECISION) |

```php
            'name' => [
                'required',
                'string',
                'max:100',
                Rule::unique('tt_constraint_category_scopes', 'name')
                    ->where('type', $type)
                    ->ignore($id),
            ],
```

**Evidence**
```
$ php artisan tinker --execute '... SHOW CREATE TABLE tt_constraint_category_scopes ...'
  UNIQUE KEY `uq_constraint_category_scope` (`type`,`code`)
(no unique key on name)
$ grep -n "unique\|ignore" Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php
38:                Rule::unique('tt_constraint_category_scopes', 'code')
40:                    ->ignore($id),
46:                Rule::unique('tt_constraint_category_scopes', 'name')
48:                    ->ignore($id),
```

### F3 — Authorization

#### CCS-04 · L · AUTH-04 — `store` and `update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — do not authorize the same permission twice (Form Request `authorize()` plus `Gate::authorize`). Keep one. |
| **Where** | `Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php:13-19` (`authorize()`), together with `ConstraintCategoryScopeController.php:44` (`store`) and `:96` (`update`) |
| **Root cause** | The FormRequest's `authorize()` checks `tenant.smart-timetable.constraint-category-scope.create` on POST and `.update` otherwise, and the controller then calls `Gate::authorize()` with the same two strings. |
| **Consequence** | The permission is evaluated twice on every store/update, and the rule lives in two files that can drift apart. |
| **Reproduce** | Static only — both checks pass or fail together today. |
| **Fix approach** | Keep the FormRequest check (it runs first) and delete the two controller `Gate::authorize()` calls. |
| **Plan item** | CCS-04 in `02-fix-plan.md` §4 |

```php
    public function authorize(): bool
    {
        if ($this->isMethod('POST')) {
            return auth()->user()->can('tenant.smart-timetable.constraint-category-scope.create');
        }
        return auth()->user()->can('tenant.smart-timetable.constraint-category-scope.update');
    }
```

**Evidence**
```
$ grep -n "authorize" Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php
16:            return auth()->user()->can('tenant.smart-timetable.constraint-category-scope.create');
18:        return auth()->user()->can('tenant.smart-timetable.constraint-category-scope.update');
$ grep -n "Gate::authorize" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php
20:        Gate::authorize('tenant.smart-timetable.constraint-category-scope.viewAny');
44:        Gate::authorize('tenant.smart-timetable.constraint-category-scope.create');
73:        Gate::authorize('tenant.smart-timetable.constraint-category-scope.view');
82:        Gate::authorize('tenant.smart-timetable.constraint-category-scope.update');
96:        Gate::authorize('tenant.smart-timetable.constraint-category-scope.update');
134:        Gate::authorize('tenant.smart-timetable.constraint-category-scope.delete');
163:        Gate::authorize('tenant.smart-timetable.constraint-category-scope.restore');
184:        Gate::authorize('tenant.smart-timetable.constraint-category-scope.forceDelete');
217:        Gate::authorize('tenant.smart-timetable.constraint-category-scope.restore');
251:        Gate::authorize('tenant.smart-timetable.constraint-category-scope.update');
```

### F4 — Validation and input

#### CCS-05 · M · VAL-05 — `is_active` is declared `nullable` and validates nothing

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — every field is typed; `sometimes`/`nullable` alone validates nothing. |
| **Where** | `Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php:51`, method `rules()` |
| **Root cause** | The rule is the single token `['nullable']`, which accepts any value because it applies no type constraint. |
| **Consequence** | A posted `is_active=banana` passes validation and is then silently coerced to `false` by `$request->boolean('is_active')`, so the record is deactivated with no error shown — a wrong result the user cannot see. |
| **Reproduce** | Static only — submit `is_active=banana` on the edit form; validation passes and the row is stored inactive. |
| **Fix approach** | Add the `boolean` rule: `['nullable', 'boolean']`. |
| **Plan item** | CCS-05 in `02-fix-plan.md` §5 |

```php
            'description' => ['nullable', 'string', 'max:255'],
            'is_active'   => ['nullable'],
        ];
```

**Evidence**
```
$ grep -n "is_active" Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php
51:            'is_active'   => ['nullable'],
$ grep -n "boolean('is_active')" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php
53:                    'is_active' => $request->boolean('is_active'),
107:                    'is_active' => $request->boolean('is_active'),
257:            $record->is_active = $request->boolean('is_active');
```

### F5 — Routes

#### CCS-06 · H · RTE-01 — the restore action is a GET that changes state

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — no state change over GET; GET has no CSRF protection, and link prefetchers trigger it. |
| **Where** | `Modules/SmartTimetable/routes/web.php:260`, register of method `restore()` |
| **Root cause** | The restore route is registered with `Route::get(...)`, even though it mutates a row (`$record->restore()` plus an audit write). |
| **Consequence** | Anything that fetches the URL restores a trashed constraint scope with no CSRF token and no confirmation — a browser prefetch, a link scanner, or an accidental open from history. A state change requested by a safe verb is also cacheable and re-playable. |
| **Reproduce** | While logged in as Super Admin, open `GET /smart-timetable/constraint-category-scope/{id}/restore` for a trashed id; the record is restored with no confirmation. |
| **Fix approach** | Register the route as `POST` (or `DELETE`). The shared `x-backend.table.action-trashed` component already reads the route's HTTP method and renders a CSRF-protected POST form, so no component or blade change is needed — only the route-file line. |
| **Plan item** | CCS-06 in `02-fix-plan.md` §5 (flagged SHARED — route file) |

```php
        Route::get('/constraint-category-scope/{id}/restore', [ConstraintCategoryScopeController::class, 'restore'])->name('constraint-category-scope.restore');
```

**Evidence**
```
$ grep -n "restore'" Modules/SmartTimetable/routes/web.php
158:        Route::post('timetable/{id}/restore', [TimetableGenerationController::class, 'restoreTimetable'])->name('timetable.restore');
255:        Route::get('/constraint/{id}/restore', [ConstraintController::class, 'restore'])->name('constraint.restore');
260:        Route::get('/constraint-category-scope/{id}/restore', [ConstraintCategoryScopeController::class, 'restore'])->name('constraint-category-scope.restore');
267:        Route::get('/constraint-type/{id}/restore', [ConstraintTypeController::class, 'restore'])->name('constraint-type.restore');
274:        Route::get('/teacher-unavailable/{id}/restore', [TeacherUnavailableController::class, 'restore'])->name('teacher-unavailable.restore');
280:        Route::get('/room-unavailable/{id}/restore', [RoomUnavailableController::class, 'restore'])->name('room-unavailable.restore');
```

### F6 — Controller shape

#### CCS-07 · M · CTL-03 — no route model binding; `$id` plus `findOrFail()` everywhere

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — use route model binding, not `$id` plus `findOrFail()`. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php:71` (`show`), also `:80` (`edit`), `:94` (`update`), `:132` (`destroy`), `:182` (`forceDelete`), `:215` (`restore`), `:249` (`toggleStatus`) |
| **Root cause** | Every method takes a scalar `$id` and calls `findOrFail()` itself. The resource routes already name the parameter `constraint_category_scope`, which is exactly what implicit binding needs, but the methods do not type-hint the model. |
| **Consequence** | The model is resolved by hand in seven methods; a future route-parameter rename would silently stop resolving instead of failing loudly, and the duplicate `findOrFail` lines are repeated boilerplate. |
| **Reproduce** | Static only — behaviour is correct today because an untyped `$id` receives the route value positionally. |
| **Fix approach** | DECISION: bind the four resource methods (`show`, `edit`, `update`, `destroy`) with a typed `ConstraintCategoryScope $constraintCategoryScope` argument (the route parameter already matches, so no route change is needed); the trash routes use `{id}` and rely on `withTrashed()`/`onlyTrashed()`, so binding them also needs those route parameters renamed. |
| **Plan item** | CCS-07 in `02-fix-plan.md` §9 (DECISION) |

```php
    public function show($id)
    {
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.view');

        $record = ConstraintCategoryScope::findOrFail($id);

        return view('smarttimetable::constraint-category-scope.show', compact('record'));
    }
```

**Evidence**
```
$ grep -n "findOrFail" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php
75:        $record = ConstraintCategoryScope::findOrFail($id);
84:        $record = ConstraintCategoryScope::findOrFail($id);
99:            $record = ConstraintCategoryScope::findOrFail($id);
137:            $record = ConstraintCategoryScope::findOrFail($id);
187:            $record = ConstraintCategoryScope::withTrashed()->findOrFail($id);
220:            $record = ConstraintCategoryScope::onlyTrashed()->findOrFail($id);
256:            $record = ConstraintCategoryScope::findOrFail($id);
```

#### CCS-08 · L · CTL-04 — no return types on the public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — return types on public methods. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php:18` (`index`), also `:25`, `:42`, `:71`, `:80`, `:94`, `:132`, `:161`, `:182`, `:215`, `:249` |
| **Root cause** | None of the eleven public methods declares a return type, though each returns a `View`, `RedirectResponse` or `JsonResponse`. |
| **Consequence** | The response contract is invisible in the signature and static analysis cannot flag a method that returns the wrong type. |
| **Reproduce** | Static only — a typing gap. |
| **Fix approach** | Declare the union return type on each public method: `View` for `show`/`edit`, `RedirectResponse` for `store`/`update`/`destroy`/`forceDelete`/`restore`, `RedirectResponse` for `index`, `View` for `trashed`, `JsonResponse` for `toggleStatus`, and `never` for `create` (it throws). |
| **Plan item** | CCS-08 in `02-fix-plan.md` §5 |

```php
    public function index()
    {
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.viewAny');

        return redirect()->route('smart-timetable.menu.constraintEngine', ['tab' => 'category-scope']);
    }
```

**Evidence**
```
$ grep -nE "public function" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php
18:    public function index()
25:    public function create()
42:    public function store(ConstraintCategoryScopeRequest $request)
71:    public function show($id)
80:    public function edit($id)
94:    public function update(ConstraintCategoryScopeRequest $request, $id)
132:    public function destroy($id)
161:    public function trashed(Request $request)
182:    public function forceDelete($id)
215:    public function restore($id)
249:    public function toggleStatus(Request $request, $id)
```

### F7 — Models

**clean — `ConstraintCategoryScope` and `Constraint` both audited in full.** `ConstraintCategoryScope`: `$table = 'tt_constraint_category_scopes'` exists in `database/migrations/tenant/2026_06_16_152559_create_tt_constraint_category_scope_table.php`; `$fillable` is declared with no sensitive column; `$casts` covers `is_active` (boolean) and the three date columns; `SoftDeletes` is present and the table has `deleted_at`. `Constraint`: `$table = 'tt_constraints'` exists (`SHOW COLUMNS` matched every `$fillable`/`$casts` column, including `target_type varchar(50)`, `params_json json`, `applicable_days json`, and `deleted_at`); `$fillable` and `$casts` match the DDL; the `constraintType`, `target`, `academicTerm` and `creator` relations are return-typed and their morph map is registered in `AppServiceProvider.php:106`. No MDL finding. Evidence:
```
$ php -l Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php
No syntax errors detected in Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php
$ php -l Modules/SmartTimetable/app/Models/Constraint.php
No syntax errors detected in Modules/SmartTimetable/app/Models/Constraint.php
$ grep -rln "tt_constraint_category_scopes" database/migrations/tenant
database/migrations/tenant/2026_06_16_152559_create_tt_constraint_category_scope_table.php
$ php artisan tinker --execute '... SHOW COLUMNS FROM tt_constraints ...'
id, constraint_type_id, name, description, academic_term_id, target_type, target_id, is_hard, weight, params_json, effective_from, effective_to, apply_for_all_days, applicable_days, impact_score, is_active, created_by, created_at, updated_at, deleted_at
```

### F8 — Services and jobs

**clean** — this controller injects no service and dispatches no job. Evidence:
```
$ grep -nE "Service|Job|dispatch|new [A-Z]" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php
(no output)
```

### F9 — Queries and performance

**clean** — the only list (`trashed()`) paginates at 10, and the blade keeps the filter by appending the query string. No query sits in a loop and no relation is loaded per row. Evidence:
```
$ grep -n "paginate\|->get()\|::all()" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php
172:            ->paginate(10);
$ grep -n "appends(request" Modules/SmartTimetable/resources/views/constraint-category-scope/trash.blade.php
66:                                {{ $records->appends(request()->query())->links() }}
```
The scanner's QRY-13 candidate (paginated without `withQueryString()`) is answered by the blade's `appends(request()->query())`, so it is not reported.

### F10 — Views

**clean** — the three views issue no database query, use no `{!! !!}` on user text, and reference no relation inside a loop. Every row action goes through `x-backend.table.action-trashed`, which renders a confirm form. `form.blade.php` reads `$type` with `?? 'CATEGORY'`, and the controller never passes `$type`; the fallback makes it null-safe, so it is noted here, not raised as a finding. Evidence:
```
$ grep -nE "Model::|DB::|->where\(|->get\(\)|->count\(\)|\{!!" Modules/SmartTimetable/resources/views/constraint-category-scope/*.blade.php
3:$type   = strtoupper(old('type', $isEdit ? $record->type : ($type ?? 'CATEGORY')));
(only the null-safe $type fallback; no query, no raw output)
```

### F11 — Security and tenancy

**clean** — no `env()` outside config, no personal data in the one JSON response (`toggleStatus` returns `success`, `is_active` and a flash string only), no hard-coded ids, no request body or secret logged, and every route sits in the tenant + auth middleware group. Evidence:
```
$ grep -n "env(" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php
(no output)
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '... ConstraintCategoryScopeController@ ...'
every route carries: Stancl\Tenancy\Middleware\InitializeTenancyByDomain, Illuminate\Auth\Middleware\Authenticate, App\Http\Middleware\EnsureTenantHasModule:smart-timetable
```

### F12 — Style

#### CCS-10 · L · STY-01 + STY-02 + STY-04 — `Constraint.php` is not to standard

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — `declare(strict_types=1);` in PHP files you touch. STY-02 (L) — Pint-clean. STY-04 (L) — English comments without emoji. |
| **Where** | `Modules/SmartTimetable/app/Models/Constraint.php:1` (no `declare`), also `:129`, `:141`, `:177` (emoji) and the import/`$casts` blocks Pint rewrites |
| **Root cause** | The file predates the standard: no `declare(strict_types=1)`, manually aligned `=>` in `TARGET_MORPH_MAP` and `$casts`, an unsorted import block, a fully-qualified `\Illuminate\Database\Eloquent\Model`, and three `⚠` emoji markers in comments. |
| **Consequence** | `vendor/bin/pint --test` fails on the file, and the emoji markers drift from the plain-English comment standard; the next person to run Pint gets an unrelated reformat in their diff. |
| **Reproduce** | `vendor/bin/pint --test Modules/SmartTimetable/app/Models/Constraint.php --format agent` returns `"result":"fail"` with fixers `fully_qualified_strict_types`, `ordered_imports`, `binary_operator_spaces`. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag, run Pint (which sorts the imports, imports `Model` and replaces the fully-qualified reference, and un-aligns `=>`), and replace the three `⚠` markers with `Warning:`. |
| **Plan item** | CCS-10 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SmartTimetable\Models;

use Modules\SchoolSetup\Models\User;
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Modules\SchoolSetup\Models\Room;
use Modules\SchoolSetup\Models\SchoolClass;
use Modules\SchoolSetup\Models\Teacher;
use Modules\TimetableFoundation\Models\AcademicTerm;
use Modules\TimetableFoundation\Models\Activity;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SmartTimetable/app/Models/Constraint.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SmartTimetable\/app\/Models\/Constraint.php","fixers":["fully_qualified_strict_types","ordered_imports","binary_operator_spaces"]}]}
$ grep -n "declare(strict_types" Modules/SmartTimetable/app/Models/Constraint.php
(no output)
$ grep -n "⚠" Modules/SmartTimetable/app/Models/Constraint.php
129:     * ⚠ No database foreign key protects this pair, and none can: MySQL cannot
141:        // ⚠ Eloquent resolves a morph type by INSTANTIATING IT AS A CLASS. For a
177:     * ⚠ DO NOT eager-load 'target' on a collection that may contain GLOBAL rows.
```

#### CCS-11 · L · STY-01 + STY-02 — `ConstraintCategoryScope.php` is not to standard

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — `declare(strict_types=1);`. STY-02 (L) — Pint-clean. |
| **Where** | `Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php:1` (no `declare`), plus the const block at `:14-15` and `$casts` at `:26` |
| **Root cause** | The file predates the standard: no `declare(strict_types=1)`, no blank line between the two constants, and manually aligned `=` in `TYPE_SCOPE` and `is_active`. |
| **Consequence** | `vendor/bin/pint --test` fails on the file; the next Pint run reformats it. |
| **Reproduce** | `vendor/bin/pint --test Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php --format agent` returns `"result":"fail"` with fixers `class_attributes_separation`, `binary_operator_spaces`. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag and run Pint on the file. |
| **Plan item** | CCS-11 in `02-fix-plan.md` §8 |

```php
    public const TYPE_CATEGORY = 'CATEGORY';
    public const TYPE_SCOPE    = 'SCOPE';
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SmartTimetable\/app\/Models\/ConstraintCategoryScope.php","fixers":["class_attributes_separation","binary_operator_spaces"]}]}
$ grep -n "declare(strict_types" Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php
(no output)
```

#### CCS-12 · L · STY-02 — the controller is not Pint-clean on the `trashed` arrow function

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — Pint-clean (Laravel preset). |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php:168`, method `trashed()` |
| **Root cause** | The arrow function is written `fn($q)` with no space; the Laravel preset requires `fn ($q)`. |
| **Consequence** | `vendor/bin/pint --test` fails on the controller; the next Pint run changes this line inside an unrelated diff. |
| **Reproduce** | `vendor/bin/pint --test Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php --format agent` returns `"result":"fail"` with fixer `function_declaration`. |
| **Fix approach** | Add the space: `fn ($q)`, or run Pint on the file. |
| **Plan item** | CCS-12 in `02-fix-plan.md` §8 |

```php
            ->when(
                $request->filled('type'),
                fn($q) => $q->where('type', $this->resolveType($request->input('type')))
            )
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SmartTimetable\/app\/Http\/Controllers\/ConstraintCategoryScopeController.php","fixers":["function_declaration"]}]}
$ sed -n '168p' Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php
                fn($q) => $q->where('type', $this->resolveType($request->input('type')))
```

#### CCS-13 · L · STY-02 — `ConstraintCategoryScopeRequest.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — Pint-clean. |
| **Where** | `Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php:13-19`, method `authorize()` |
| **Root cause** | There is no blank line before the final `return` of `authorize()`, and `$id` is manually aligned; the Laravel preset wants a blank line before the return and single-space operators. |
| **Consequence** | `vendor/bin/pint --test` fails on the request; the next Pint run reformats it. |
| **Reproduce** | `vendor/bin/pint --test Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php --format agent` returns `"result":"fail"` with fixers `blank_line_before_statement`, `binary_operator_spaces`. |
| **Fix approach** | Run Pint on the file (adds the blank line, un-aligns `$id`). Note CCS-05 already rewrites the `is_active` line, so this item is scoped to the `authorize()` block. |
| **Plan item** | CCS-13 in `02-fix-plan.md` §8 |

```php
        if ($this->isMethod('POST')) {
            return auth()->user()->can('tenant.smart-timetable.constraint-category-scope.create');
        }
        return auth()->user()->can('tenant.smart-timetable.constraint-category-scope.update');
    }
```

**Evidence**
```
$ vendor/bin/pint --test Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SmartTimetable\/app\/Http\/Requests\/ConstraintCategoryScopeRequest.php","fixers":["blank_line_before_statement","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutating method | 1 wrong data | 2 delete-before-store | 3 duplicate impl | 4 soft-delete×unique | 5 race | 6 auth hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | CCS-09 (payload shared with `update`) | ok | CCS-09 | ok | ok | ok |
| `update` | ok | ok | CCS-09 | ok | CCS-09 | ok | ok | ok |
| `destroy` | ok | ok — soft delete, reversible | ok | ok | ok | ok | ok | ok |
| `forceDelete` | ok | ok — the audit row stores the id, not an FK | ok | ok — hard delete frees the code | ok | ok | ok | ok |
| `restore` | ok — also re-activates | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok — a boolean toggle is idempotent | ok | ok | ok |

**Wrong data (Q1):** no mutating method overwrites a value it should not. `destroy` clears `is_active` before a soft delete and `restore` sets it back; both are intentional.
**Irreversible order (Q2):** nothing irreversible happens before a commit. `forceDelete` hard-deletes, then writes the audit row inside the same transaction; the audit row keeps `subject_id`, so a later read does not need the deleted row.
**Duplicate implementations (Q3):** `store` and `update` share the same five-field payload and the same redirect; this is the CCS-09/CTL-05 style duplication, folded into the CCS-01 rewrite, not a divergent pair.
**Soft-delete × unique (Q4):** the unique key is `(type, code)` and the FormRequest's unique rules have no `whereNull('deleted_at')`, so a trashed row still counts in both the validation query and the index — the two agree, and re-adding a trashed code is refused until the row is restored. There is therefore no validation-passes-but-DB-rejects 500, so VAL-04 is checked and not present.
**Races (Q5):** CCS-09 — `name` uniqueness is app-only, no lock and no index. `code` is protected by the unique index.
**Auth holes (Q6):** none — every routed method calls `Gate::authorize()` before it loads a record, and the two store/update checks are duplicated rather than missing.
**Lying messages (Q7):** none observed. The flash keys and activity events (`Stored`, `Updated`, `Trashed`, `Deleted`, `Restored`, `Toggled`) match the action taken. CCS-01 notes that `store`'s catch reports every failure as a generic "operation failed", which does not name the cause.
**Dead features (Q8):** none. `index()` redirects to a live tab, `create()` is the D5-sanctioned retired route, and the trash page has working restore/permanent-delete actions.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SmartTimetable/routes/web.php` (other controllers' restore routes) | The same GET-state-change pattern is repeated on the `constraint`, `constraint-type`, `teacher-unavailable` and `room-unavailable` restore routes (`:255`, `:267`, `:274`, `:280`). It is one module-wide fix, not four. | RTE-01 | the reports that own those controllers; this report owns only line 260 |
| `App\View\Components\Backend\Table\ActionTrashed` | Works correctly (it reads each route's HTTP method and computes `canRestore`/`canForceDelete` from the passed permission strings), which is what makes the CCS-06 route fix safe without touching the component. No defect. | — | — |
| `Modules\GlobalMaster\Models\ActivityLog` (tenant `sys_activity_logs`) | Checked as the audit sink; `activityLog()` writes one row per call in tenant context. No defect observed. | — | — |

## 8. Not covered, and why

- **Live browser reproduction:** the tenant `test.localhost` has 27 live `tt_constraint_category_scopes` rows and 0 trashed rows, so the trash page and the restore/force-delete paths cannot be driven end-to-end without first soft-deleting a row (a write this read-only audit must not perform). Every write finding is proven statically from the source, the route list and `SHOW CREATE TABLE`.
- **Executing the write paths:** prohibited (no database writes in this workflow). CCS-09 is proven from `SHOW CREATE TABLE` (only `uq_constraint_category_scope (type, code)`) plus the absence of a lock.
- **The two DECISION items** (CCS-07 route-model binding, CCS-09 name uniqueness): options are in the plan; no choice is assumed here.
- **Blade rendering:** the three views were read and compiled by eye; this audit did not render them through the browser (no browser session for a read-only audit).
- **Jobs, events, mail, notifications, exports, imports:** none are referenced by this controller.
