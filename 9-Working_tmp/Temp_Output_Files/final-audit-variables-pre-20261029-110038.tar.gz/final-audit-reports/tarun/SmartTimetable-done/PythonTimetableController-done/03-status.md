# Status — SmartTimetable / PythonTimetableController

**Fixed:** 2026-10-16 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md` + the decisions in `../00-USAGE-AND-FIX-PLAN-2026-10-16.md` §5 (PYC-07, PYC-08, PYC-10, PYC-12/13) and the PYC-17 answer of 2026-10-16

## 1. Pre-applied work
None.

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| **PYC-01** | `PythonTimetableController.php` `grid()` | controller try/catch removed (D1); errors now reach the central handler, no raw text in the JSON | `grep -n "getMessage"` | one hit only — the deliberate `\RuntimeException` business-rule branch in `store()` | 2026-10-16 |
| **PYC-02** | `generate()` final catch | `report($e)` + fixed flash "Python generation failed. The error has been logged."; progress finishes with "Generation failed." | `grep -n "Python generation failed"` | 1 line | 2026-10-16 |
| **PYC-03** | `conflictsSummary()` catch | `report($e)` + fixed message "The conflict summary could not be built. Please try again." | `grep -n "could not be built"` | 1 line | 2026-10-16 |
| **PYC-04** | `store()` catches | generic catch logs `'exception' => $e` and flashes a fixed message. **Extra, in the same file:** a `catch (QueryException)` branch now runs before `catch (\RuntimeException)`. `QueryException` extends `RuntimeException`, so without it a DB error would have fallen into the business-rule branch and its SQL would have been flashed to the user (D2) | `grep -n "Save failed"` · `grep -n "catch (QueryException"` | none · 1 | 2026-10-16 |
| **PYC-05** | controller lockInDraft log, tail-repair log, persistPreview log; `GenerationProgress.php` claim/snapshot logs | `'error' => $e->getMessage()` (and `'trace'`) → `'exception' => $e` | `grep -n "'exception' => \$e"` | 4 controller sites + 2 GenerationProgress sites | 2026-10-16 |
| **PYC-08** | `persistPreview()` | decision (a): `$skeleton` is held before the try; if `populateFromResult()` fails, the catch calls `$this->storage->deleteSkeleton()` (cleanup failure is `report()`ed). Healthy drafts are still all kept | read | applied | 2026-10-16 |
| **PYC-10** | new `Http/Requests/PythonTimetableGridRequest.php`, `PythonTimetableGenerateRequest.php`, `PythonTimetableStoreRequest.php` | decision (a): all three inline `validate()` blocks moved into FormRequests, with rules and product-decision comments copied verbatim (emoji markers stripped). Each `authorize()` checks the same permission as the controller gate; the controller keeps its `Gate::authorize`. Named `PythonTimetable*` rather than the plan's bare `GridRequest` / `GenerateRequest` / `StoreRequest`, because the module's Requests folder is shared | kernel replay as super-admin | grid → 200 · grid `timetable_type_id=abc` → 422 · generate `seconds=9999` → 422 · store empty → 422 (no writes) | 2026-10-16 |
| **PYC-14** | signatures | `generate(): View\|RedirectResponse\|JsonResponse`, `store(): RedirectResponse` (more precise than the plan's union, since `store()` only redirects), `redirectGenerate(): RedirectResponse`, `backToTab(): RedirectResponse` | `grep -nE "public function (generate\|store\|redirectGenerate)\("` | 3 typed lines | 2026-10-16 |
| **PYC-15** | controller | dead `dropPreviousPreview()` deleted; the persistPreview comment that said it was "left in place" now says it was deleted and can be restored from git history | `grep -n "function dropPreviousPreview"` | none | 2026-10-16 |
| **PYC-16** | constructor + 2 sites | `TimetableGenerationService` and `PreviewDerivedData` are now constructor-injected; the `app()` lookups mid-method are gone | `grep -n "app(PreviewDerivedData::class)\|app(TimetableGenerationService::class)"` | none | 2026-10-16 |
| **PYC-18** | controller + all 7 Python service files | the leading ⚠/⛔/⭐ marker is stripped from every comment line; the words are kept, and code and strings are untouched | `grep -c "⛔\|⚠\|⭐"` | 0 in every file | 2026-10-16 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| PYC-17 (L) | **accepted as debt (Tarun, 2026-10-16)** | The Generate modal is an HTML form, so its integers arrive as strings. Under `strict_types`, `resolveTermId("1")` and `exportForTerm()` would throw a TypeError on every generation. There is no static analyser and there are no tests to prove the rest of the cluster is safe. The three new FormRequests do carry `strict_types` (they only declare rules) |
| PYC-07 (M) | accepted as debt | the activityLog stays controller-side, after the service transaction; the PHP engine's copy of the same pattern was retired with R5 |
| PYC-12, PYC-13 (H) | deferred (D3) | god-controller and long-method splits wait for the split pass |
| PYC-06, PYC-09, PYC-11 | no plan item | see plan §10 |

## 4. Needs Tarun's hand
- Nothing to run.
- Residual from PYC-04: `store()` still catches `\RuntimeException`, because `TimetableStorageService::finalizeGenerated()` (a shared service, out of bounds for this plan) throws it for business rules. The clean D2 fix is to make the service throw `\DomainException`. That change belongs to the storage owner's pass.

## 5. Unverifiable by this workflow (no tests, D4)
- That a full generate run still renders the preview. The solver was not run (it starts Python processes). Only the validation and grid paths were replayed through the kernel.
- That PYC-08's cleanup actually deletes a half-built skeleton. This needs a forced `populateFromResult()` failure.
- That a non-super-admin is refused by the new FormRequests' `authorize()`. The replays ran as super-admin (`Gate::before`).

## 6. Verification log
```
php -l controller, 7 Python services, 3 new FormRequests        -> No syntax errors (re-run after Pint)
vendor/bin/pint <the 11 files> --format agent                   -> passed
class_exists(controller, 3 requests, GenerationProgress, PythonRunner) -> all OK
router probe after route:clear                                  -> smart-timetable routes: 122  missing methods: 0
python-timetable routes -> methods                              -> 6 routes, 0 missing
kernel replay: grid / grid "1" / grid "abc" / generate seconds=9999 / store {} -> 200 / 200 / 422 / 422 / 422
grep -c "⛔|⚠|⭐" controller + services                           -> 0 each
wc -l controller                                                -> 3227 -> 3157
```

## 7. Final state
Status: FIXED · Open: B 0 · H 2 (PYC-12, PYC-13 deferred) · M 3 (PYC-06, PYC-09 §10; PYC-07 accepted) · L 2 (PYC-11 §10; PYC-17 accepted)
