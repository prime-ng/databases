# Fix Plan — SmartTimetable / PythonTimetableController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php` | owned by TimetableGenerationController's report; only PYC-04/PYC-07 coordination items may touch it, and only when their DECISION is ticked |
| `Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php` | another report's controller |
| `config/permissionslist.php` | module-wide permission config; PYC-09 is not fixed here |
| `Modules/SmartTimetable/routes/web.php` | route file — no route changes in this plan |
| `Modules/SmartTimetable/python/*` | Python engine — not PHP |
| `Modules/SmartTimetable/resources/views/preview/**` | owned by the preview reports |
| migrations, `glb_menus`, seeders | out of scope for this plan |

## 1. Blockers reachable today

- [x] **PYC-01** · B · ERR-01 · `PythonTimetableController.php:167-193` — stop `grid()` from returning the raw exception text; remove the controller try/catch (D1).
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Before** (`PythonTimetableController.php:167-193`, method `grid()`):
    ```php
        try {
            $termId = $this->resolveTermId($validated['academic_term_id'] ?? null);
            if ($termId === null) {
                return response()->json([
                    'success' => false,
                    'message' => 'No active activities exist for any academic term yet.',
                ], 422);
            }

            $problem = $this->exporter->exportForTerm(
                $termId,
                $validated['timetable_type_id'] ?? null
            );

            return response()->json([
                'success' => true,
                'academic_term_id' => $termId,
                'timetable_type' => $problem['timetable_type'],
                'problem' => $this->problemSummary($problem),
                // No placements yet — the same shape, with empty cells.
                'grid' => $this->buildGrid($problem, ['placements' => []]),
            ]);
        } catch (Throwable $e) {
            Log::error('Python timetable grid failed', ['error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    ```
  - **After:**
    ```php
        $termId = $this->resolveTermId($validated['academic_term_id'] ?? null);
        if ($termId === null) {
            return response()->json([
                'success' => false,
                'message' => 'No active activities exist for any academic term yet.',
            ], 422);
        }

        $problem = $this->exporter->exportForTerm(
            $termId,
            $validated['timetable_type_id'] ?? null
        );

        return response()->json([
            'success' => true,
            'academic_term_id' => $termId,
            'timetable_type' => $problem['timetable_type'],
            'problem' => $this->problemSummary($problem),
            // No placements yet — the same shape, with empty cells.
            'grid' => $this->buildGrid($problem, ['placements' => []]),
        ]);
    ```
  - **Verify:** `grep -n "getMessage\|catch (" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php | sed -n '1,3p'`
  - **Expect:** no `catch (` and no `getMessage` before line 430.
  - **Effort:** S

- [x] **PYC-02** · B · ERR-01 · `PythonTimetableController.php:540-550` — `generate()` must flash a fixed message and `report($e)` instead of the raw exception.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Before** (`PythonTimetableController.php:540-550`, method `generate()`):
    ```php
        } catch (Throwable $e) {
            $this->progress->finish(false, 'Generation failed: '.$e->getMessage());

            Log::error('Python timetable generation failed', [
                'script' => 'generate.py',
                'term_id' => $validated['academic_term_id'] ?? null,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'Python generation failed: '.$e->getMessage());
        }
    ```
  - **After:**
    ```php
        } catch (Throwable $e) {
            // ERR-01 (D2) 2026-10-10 — fixed message; the trace goes to the log only.
            $this->progress->finish(false, 'Generation failed.');
            report($e);

            return back()->with('error', 'Python generation failed. The error has been logged.');
        }
    ```
  - **Verify:** `grep -n "Python generation failed" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Expect:** exactly one line — `return back()->with('error', 'Python generation failed. The error has been logged.');`
  - **Effort:** S

- [x] **PYC-03** · B · ERR-01 · `PythonTimetableController.php:672-677` — `conflictsSummary()` returns a fixed message instead of the raw exception.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Before** (`PythonTimetableController.php:672-677`, method `conflictsSummary()`):
    ```php
        } catch (Throwable $e) {
            Log::warning('conflictsSummary failed', ['error' => $e->getMessage()]);

            return ['success' => false, 'message' => $e->getMessage(),
                'blockers' => 0, 'warnings' => 0, 'groups' => [], 'problem' => null];
        }
    ```
  - **After:**
    ```php
        } catch (Throwable $e) {
            // ERR-01 2026-10-10 — the Warnings & Fixes tab renders this message; the trace stays in the log.
            report($e);

            return ['success' => false, 'message' => 'The conflict summary could not be built. Please try again.',
                'blockers' => 0, 'warnings' => 0, 'groups' => [], 'problem' => null];
        }
    ```
  - **Verify:** `grep -n "The conflict summary could not be built" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Expect:** one line at 675.
  - **Effort:** S

- [x] **PYC-04** · B · ERR-01 · `PythonTimetableController.php:3144-3155` — `store()` must not flash a raw exception from the generic catch.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Before** (`PythonTimetableController.php:3144-3155`, method `store()`):
    ```php
        } catch (\RuntimeException $e) {
            // A business rule from finalizeGenerated — already published, or not
            // in GENERATED status. The row is fine; show the reason.
            return $this->backToTab($e->getMessage());
        } catch (Throwable $e) {
            Log::error('Python timetable publish failed', [
                'timetable_id' => $timetableId,
                'error' => $e->getMessage(),
            ]);

            return $this->backToTab('Save failed: '.$e->getMessage());
        }
    ```
  - **After:**
    ```php
        } catch (\RuntimeException $e) {
            // A business rule from finalizeGenerated — already published, or not
            // in GENERATED status. The row is fine; show the reason.
            return $this->backToTab($e->getMessage());
        } catch (Throwable $e) {
            Log::error('Python timetable publish failed', [
                'timetable_id' => $timetableId,
                'exception' => $e,
            ]);

            return $this->backToTab('The timetable could not be saved. The error has been logged.');
        }
    ```
  - **Verify:** `grep -n "Save failed" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Expect:** no output.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [x] **PYC-05** · M · ERR-05 · `PythonTimetableController.php:434-438` and the surviving log sites — log the exception object, not only its message.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`, `Modules/SmartTimetable/app/Services/Python/GenerationProgress.php`
  - **Before** (`PythonTimetableController.php:434-438`, inside `generate()`):
    ```php
                    Log::warning('Python timetable: could not lock carried-over cells', [
                        'timetable_id' => $timetableId,
                        'error' => $e->getMessage(),
                    ]);
    ```
  - **After:**
    ```php
                    Log::warning('Python timetable: could not lock carried-over cells', [
                        'timetable_id' => $timetableId,
                        'exception' => $e,
                    ]);
    ```
  - Apply the identical change (`'error' => $e->getMessage()` → `'exception' => $e`) at the surviving sites: `PythonTimetableController.php:2870` (runTailRepair), `:3052-3055` (persistPreview), `GenerationProgress.php:104` and `:443`.
  - **Verify:** `grep -n "'exception' => \$e" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php Modules/SmartTimetable/app/Services/Python/GenerationProgress.php`
  - **Expect:** hits at controller lines 2870, 3052 and 3149 (PYC-04's site), plus GenerationProgress lines 104 and 443.
  - **Effort:** S

## 4. Authorization (F3)

_No item — PYC-09 is a module-wide pattern deferred to the module pass (see §10)._

## 5. Validation, routes, models (F4/F5/F7)

_No item — PYC-10 (FormRequests) is a DECISION under §9; PYC-11 is accepted (see §10)._

## 6. Services (F8)

- [x] **PYC-16** · M · SVC-02 · `PythonTimetableController.php:70-77,466-471,494` — inject `TimetableGenerationService` and `PreviewDerivedData` instead of `app()` mid-method.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Before** (`PythonTimetableController.php:70-77`, the constructor):
    ```php
    public function __construct(
        private readonly PythonRunner $runner,
        private readonly ProblemExporter $exporter,
        private readonly SolutionAdapter $adapter,
        private readonly PreviewViewData $previewData,
        private readonly TimetableStorageService $storage,
        private readonly LockedCellPins $pins,
    ) {}
    ```
  - **After:**
    ```php
    public function __construct(
        private readonly PythonRunner $runner,
        private readonly ProblemExporter $exporter,
        private readonly SolutionAdapter $adapter,
        private readonly PreviewViewData $previewData,
        private readonly TimetableStorageService $storage,
        private readonly LockedCellPins $pins,
        private readonly TimetableGenerationService $generationService,
        private readonly PreviewDerivedData $derivedData,
    ) {}
    ```
  - **Before** (`PythonTimetableController.php:466-471`):
    ```php
            $viewData['algorithm_stats']['class_teaching_windows'] = app(TimetableGenerationService::class)
                ->loadClassTeachingWindows(
                    (int) ($problem['timetable_type_id'] ?? 0),
                    $generationResult->periods,
                );
    ```
  - **After:**
    ```php
            $viewData['algorithm_stats']['class_teaching_windows'] = $this->generationService
                ->loadClassTeachingWindows(
                    (int) ($problem['timetable_type_id'] ?? 0),
                    $generationResult->periods,
                );
    ```
  - **Before** (`PythonTimetableController.php:493-496`):
    ```php
            if ($timetableId !== null && ($savedTimetable = Timetable::find($timetableId))) {
                $derived = app(PreviewDerivedData::class);
                $viewData['placement_diagnostics_by_class'] = $derived->overlaySolverDiagnostics(
    ```
  - **After:**
    ```php
            if ($timetableId !== null && ($savedTimetable = Timetable::find($timetableId))) {
                $derived = $this->derivedData;
                $viewData['placement_diagnostics_by_class'] = $derived->overlaySolverDiagnostics(
    ```
  - **Verify:** `grep -n "app(PreviewDerivedData::class)\|app(TimetableGenerationService::class)" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [x] **PYC-14** · L · CTL-04 · `PythonTimetableController.php:202,3095,3168` — add return types to `generate()`, `store()`, `redirectGenerate()`.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Before** (`PythonTimetableController.php:5-7`, the imports):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Contracts\View\View;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    ```
  - **Before** (`PythonTimetableController.php:3095-3097`):
    ```php
    public function store(Request $request)
    {
        Gate::authorize('tenant.smart-timetable.python-timetable.create');
    ```
  - **After:**
    ```php
    public function store(Request $request): View|RedirectResponse|JsonResponse
    {
        Gate::authorize('tenant.smart-timetable.python-timetable.create');
    ```
  - Apply the same return type to `generate()` (`public function generate(Request $request): View|RedirectResponse|JsonResponse`) and `redirectGenerate()` (`public function redirectGenerate(): RedirectResponse`).
  - **Verify:** `grep -nE "public function (generate|store|redirectGenerate)\(" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Expect:** three lines, each ending with a return type.
  - **Effort:** S

- [x] **PYC-15** · M · CTL-10 · `PythonTimetableController.php:3063-3085` — delete the dead `dropPreviousPreview()` method.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Before** (`PythonTimetableController.php:3063-3085`):
    ```php
    private function dropPreviousPreview(): void
    {
        $previousId = (int) session('py_preview_timetable_id');
        if ($previousId <= 0) {
            return;
        }

        session()->forget('py_preview_timetable_id');

        try {
            $previous = Timetable::find($previousId);
            // ⛔ Never delete something the user published, or anything that has
            // gone live. Only a draft this controller made and nobody saved.
            if ($previous && in_array($previous->status, ['GENERATING', 'GENERATED'], true) && ! $previous->is_active) {
                $this->storage->deleteSkeleton($previousId);
            }
        } catch (Throwable $e) {
            Log::warning('Could not drop previous Python preview', [
                'timetable_id' => $previousId,
                'error' => $e->getMessage(),
            ]);
        }
    }
    ```
  - **After:**
    ```php
    // dropPreviousPreview() removed 2026-10-10 (PYC-15): drafts are intentionally kept; the method had no caller.
    ```
  - **Verify:** `grep -n "dropPreviousPreview" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`
  - **Expect:** no `function dropPreviousPreview` in the file.
  - **Effort:** S

- [ ] **PYC-17** · L · STY-01 · missing `declare(strict_types=1)` in the controller and six Python services.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`, `Modules/SmartTimetable/app/Services/Python/GenerationProgress.php`, `Modules/SmartTimetable/app/Services/Python/GenerationSuperseded.php`, `Modules/SmartTimetable/app/Services/Python/LockedCellPins.php`, `Modules/SmartTimetable/app/Services/Python/PythonRunner.php`, `Modules/SmartTimetable/app/Services/Python/SolverProcessReaper.php`, `Modules/SmartTimetable/app/Services/Python/UnplacedLessonAdvisor.php`
  - **Before** (`PythonRunner.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Services\Python;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Services\Python;
    ```
  - Insert the exact same two lines (`declare(strict_types=1);` + blank line) after `<?php` in each of the other six files listed in Touches.
  - **Verify:** `grep -L "declare(strict_types=1)" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php Modules/SmartTimetable/app/Services/Python/*.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **PYC-18** · L · STY-04 · emoji markers (⚠ ⛔ ⭐) in docblocks and comments across the Python cluster.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php`, `Modules/SmartTimetable/app/Services/Python/GenerationProgress.php`, `Modules/SmartTimetable/app/Services/Python/LockedCellPins.php`, `Modules/SmartTimetable/app/Services/Python/PythonRunner.php`, `Modules/SmartTimetable/app/Services/Python/SolutionAdapter.php`, `Modules/SmartTimetable/app/Services/Python/SolverProcessReaper.php`, `Modules/SmartTimetable/app/Services/Python/UnplacedLessonAdvisor.php`
  - **Before** (`PythonTimetableController.php:99-106`):
    ```php
     * ⛔ IT MUST NOT WRITE THE SESSION. Laravel saves the session at the end of every
     * request — and ages the flash data while doing it. A poll that started before
     * generate() saved its session and finished after would write the OLD session
     * back (losing py_preview_timetable_id), and a poll landing between generate()'s
     * error redirect and the next page would eat the error flash. So the handler is
     * swapped for a null one here: the request still authenticates from the session
     * it read, and saves nothing.
    ```
  - **After:**
    ```php
     * NOTE: it must not write the session. Laravel saves the session at the end of every
     * request — and ages the flash data while doing it. A poll that started before
     * generate() saved its session and finished after would write the OLD session
     * back (losing py_preview_timetable_id), and a poll landing between generate()'s
     * error redirect and the next page would eat the error flash. So the handler is
     * swapped for a null one here: the request still authenticates from the session
     * it read, and saves nothing.
    ```
  - Strip the leading ⚠/⛔/⭐ marker from every docblock line in the listed files; keep the words that follow. Do not alter code, strings, or `@` tags.
  - **Verify:** `grep -c "⛔\|⚠\|⭐" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php Modules/SmartTimetable/app/Services/Python/*.php`
  - **Expect:** each file reports 0.
  - **Effort:** M

## 9. Deferred / decisions

- [x] **PYC-07** · M · DECISION · TXN-04 — move `store()`'s `activityLog($saved, 'Generated', …)` inside the service transaction?
  - **Why it is a decision:** the transaction lives in shared `TimetableStorageService::finalizeGenerated`; `TimetableGenerationController::storeTimetable` repeats the exact same post-commit log call (lines 249-258), so moving the log in would double-log the PHP engine unless that report is coordinated too.
  - (a) ⭐ Keep the controller-side log as-is and record TXN-04 as accepted — the audit window is tiny and both engines share the pattern; note it in the storage owner's report.
  - (b) Move `activityLog` into `TimetableStorageService::finalizeGenerated` inside its `DB::transaction` (⚠ SHARED) AND remove the identical call in `TimetableGenerationController` (another report) — coordinated two-report change.
  - (c) Add `DB::afterCommit()` around the controller log — still a separate transaction, no real gain.
  - ➜ Choice: (a) keep controller-side log, accepted as debt (2026-10-16)

- [x] **PYC-08** · M · DECISION · TXN-01 — a failed `populateFromResult()` leaves an orphan GENERATED skeleton; delete it or not?
  - **Why it is a decision:** behavior change on the failure path; the "every draft is kept" rule was Tarun's 2026-10-05 decision.
  - (a) ⭐ Delete the just-created skeleton in `persistPreview()`'s catch via `$this->storage->deleteSkeleton()` (hold the skeleton id) — junk rows stop accumulating; healthy drafts still kept.
  - (b) Leave as-is — a failed draft is a visible draft the user removes from the list (current documented behavior).
  - (c) Wrap `createSkeleton` + `populateFromResult` in one service transaction (⚠ SHARED, storage owner coordination).
  - ➜ Choice: (a) — applied 2026-10-16: persistPreview catch deletes the half-built skeleton

- [x] **PYC-10** · M · DECISION · VAL-02 — extract the inline validation into FormRequests?
  - **Why it is a decision:** all three use `$request->validate()` inline; `generate()`'s 25-rule block carries product-decision comments that a FormRequest move must preserve.
  - (a) ⭐ Extract three FormRequests (`GridRequest`, `GenerateRequest`, `StoreRequest`) under `Modules/SmartTimetable/app/Http/Requests/`, copying the rules and their comments; keep `$validated` reads unchanged.
  - (b) Extract only `store()` and `grid()` (small, four/two fields); leave `generate()` inline with its documented block.
  - (c) Keep inline, record as accepted.
  - ➜ Choice: (a) — applied 2026-10-16 as PythonTimetableGridRequest / PythonTimetableGenerateRequest / PythonTimetableStoreRequest

- [x] **PYC-12** · H · DECISION · CTL-01 — split the 3,227-line god controller?
  - **Why it is a decision:** D3 defers all splits to the split pass.
  - (a) ⭐ Defer to the split pass (D3) — this plan already fixes the reachable blockers.
  - (b) Extract the conflict engine + export-warning translator into a service now (touches `conflicts()`, `exportWarningRow()`, `conflictLabels()`, `conflictGroup()`).
  - (c) Extract the portfolio-retry loop (`runUntilFullPlacement`, `runTailRepair`, straggler helpers) into the Python service cluster now.
  - ➜ Choice: (a) defer to the split pass (D3)

- [x] **PYC-13** · H · DECISION · CTL-02 — split the twelve over-long methods?
  - **Why it is a decision:** same reason as PYC-12 (D3); the over-long methods are the same code the split would move.
  - (a) ⭐ Defer all method extraction with the PYC-12 split.
  - (b) Extract `conflicts()` into a `ConflictAudit` service now (largest single method, 852 lines).
  - (c) Extract only the private helpers into the Python cluster now.
  - ➜ Choice: (a) defer with the PYC-12 split (D3)

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PYC-06 | ERR-00/D1 best-effort controller catches (lockInDraft, runTailRepair, persistPreview, dropPreviousPreview) — deliberate degrade paths, each documented; extraction belongs to the PYC-12/13 split. The ERR-01 leaks inside them are handled by PYC-02/PYC-04. |
| PYC-09 | AUTH-06 literal permission strings — the same literals repeat across every SmartTimetable controller; a controller-only fix would create a second convention. Fix as a module-wide constants pass. |
| PYC-11 | RTE-03 `conflictsSummary()` and `persistErrorMessage()` are intentional internal helpers (called by TimetableGenerationController / the preview view), not unrouted actions — D5 does not apply. |