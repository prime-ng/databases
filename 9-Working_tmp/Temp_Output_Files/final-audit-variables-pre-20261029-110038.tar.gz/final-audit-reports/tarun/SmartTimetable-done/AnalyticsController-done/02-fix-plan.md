# Fix Plan — SmartTimetable / AnalyticsController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/TimetableFoundation/app/Services/AnalyticsService.php` | owned by the TimetableFoundation/TimetableFoundationController report |
| `Modules/TimetableFoundation/app/Models/Timetable.php` | owned by the TimetableFoundation/TimetableController report |
| `Modules/SmartTimetable/routes/web.php` | shared route file; the six routes are already correct |
| `config/permissionslist.php` | shared; both permission keys are declared and already seeded, so no change is needed |
| `resources/views/components/**` and `resources/views/layouts/**` | shared common components and layouts |

## 1. Blockers reachable today

None. There is no B-severity item.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — this controller has no error handling and no write path.

## 4. Authorization (F3)

- [x] **ANL-04** · M · AUTH-06 · `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php:19,41,55,69,83,97` — declare the report permission once instead of repeating the literal six times.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php`
  - **Before** (`AnalyticsController.php:11-15`):
    ```php
    class AnalyticsController extends Controller
    {
        public function __construct(protected AnalyticsService $analyticsService)
        {
        }
    ```
  - **After:**
    ```php
    class AnalyticsController extends Controller
    {
        private const PERMISSION_VIEW = 'tenant.smart-timetable.report.viewAny';

        private const PERMISSION_EXPORT = 'tenant.smart-timetable.report.export';

        public function __construct(protected AnalyticsService $analyticsService)
        {
        }
    ```
  - **Before** (`AnalyticsController.php:19`, repeated at 41, 55, 69, 83):
    ```php
        Gate::authorize('tenant.smart-timetable.report.viewAny');
    ```
  - **After:**
    ```php
        Gate::authorize(self::PERMISSION_VIEW);
    ```
  - **Before** (`AnalyticsController.php:97`):
    ```php
        Gate::authorize('tenant.smart-timetable.report.export');
    ```
  - **After:**
    ```php
        Gate::authorize(self::PERMISSION_EXPORT);
    ```
  - **Verify:** `grep -n "tenant.smart-timetable.report" Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php`
  - **Expect:** exactly two lines, both the constant declarations (`PERMISSION_VIEW` and `PERMISSION_EXPORT`).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [x] **ANL-01** · M · VAL-05 · `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php:43,57,71,85,99,25` — read `timetable_id` as an integer so bad input cannot throw a `TypeError`.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php`
  - **Before** (`AnalyticsController.php:43`, repeated at 57, 71, 85, 99):
    ```php
        $timetableId = $request->input('timetable_id');
    ```
  - **After:**
    ```php
        $timetableId = $request->integer('timetable_id');
    ```
  - **Before** (`AnalyticsController.php:25`):
    ```php
        $timetableId = $request->input('timetable_id', $timetables->first()?->id);
    ```
  - **After:**
    ```php
        $timetableId = $request->integer('timetable_id') ?: $timetables->first()?->id;
    ```
  - **Verify:** `grep -n "input('timetable_id'" Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **ANL-02** · M · QRY-02 · `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php:21-23` and `Modules/SmartTimetable/resources/views/analytics/index.blade.php:22-25` — page the selector at 10 and render the pagination links so no timetable is unreachable.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php`, `Modules/SmartTimetable/resources/views/analytics/index.blade.php`
  - **Before** (`AnalyticsController.php:21-23`):
    ```php
            $timetables = Timetable::where('is_active', true)
                ->orderByDesc('created_at')
                ->paginate(25);
    ```
  - **After:**
    ```php
            $timetables = Timetable::where('is_active', true)
                ->orderByDesc('created_at')
                ->paginate(10);
    ```
  - **Before** (`index.blade.php:22-25`):
    ```html
                        </select>
                    </form>
                </div>
            </div>
    ```
  - **After:**
    ```html
                        </select>
                    </form>
                    <div class="mt-2">
                        {{ $timetables->links() }}
                    </div>
                </div>
            </div>
    ```
  - **Verify:** `grep -n "paginate(10)" Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php && grep -n "links()" Modules/SmartTimetable/resources/views/analytics/index.blade.php`
  - **Expect:** `23:            ->paginate(10);` then one `links()` hit in the view.
  - **Effort:** S

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [x] **ANL-05** · L · CTL-04 · `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php:5-9,17,39,53,67,81,95` — add return types to the six actions.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php`
  - **Before** (`AnalyticsController.php:5-9`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Gate;
    use Modules\TimetableFoundation\Models\Timetable;
    use Modules\TimetableFoundation\Services\AnalyticsService;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Http\Response;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\TimetableFoundation\Models\Timetable;
    use Modules\TimetableFoundation\Services\AnalyticsService;
    ```
  - **Before** (`AnalyticsController.php:17`):
    ```php
        public function index(Request $request)
    ```
  - **After:**
    ```php
        public function index(Request $request): View|RedirectResponse
    ```
  - **Before** (`AnalyticsController.php:39`):
    ```php
        public function workload(Request $request)
    ```
  - **After:**
    ```php
        public function workload(Request $request): View|RedirectResponse
    ```
  - **Before** (`AnalyticsController.php:53`):
    ```php
        public function utilization(Request $request)
    ```
  - **After:**
    ```php
        public function utilization(Request $request): View|RedirectResponse
    ```
  - **Before** (`AnalyticsController.php:67`):
    ```php
        public function violations(Request $request)
    ```
  - **After:**
    ```php
        public function violations(Request $request): View|RedirectResponse
    ```
  - **Before** (`AnalyticsController.php:81`):
    ```php
        public function distribution(Request $request)
    ```
  - **After:**
    ```php
        public function distribution(Request $request): View|RedirectResponse
    ```
  - **Before** (`AnalyticsController.php:95`):
    ```php
        public function export(Request $request, string $type)
    ```
  - **After:**
    ```php
        public function export(Request $request, string $type): Response|RedirectResponse
    ```
  - **Verify:** `grep -n "RedirectResponse" Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php`
  - **Expect:** the import line plus seven usage lines (one per method returning a view or redirect, and `export`).
  - **Effort:** S

- [x] **ANL-06** · L · STY-01 · `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php:1` — add `declare(strict_types=1)`.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php`
  - **Before** (`AnalyticsController.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php`
  - **Expect:** `3:declare(strict_types=1);`
  - **Effort:** S

## 9. Deferred / decisions

- [x] **ANL-03** · M · DECISION · CTL-05 — extract a shared helper for the four identical report methods (`workload`, `utilization`, `violations`, `distribution`)?
  - **Why it is a decision:** it is a behaviour-preserving refactor that rewrites bodies ANL-01 also edits, so applying both in one pass risks a conflict.
  - (a) ⭐ defer the extraction to a later refactor pass; apply only the mechanical fixes now.
  - (b) extract a private `resolveTimetableId()` helper in this pass and rewrite all four methods.
  - (c) leave as is, record as accepted debt.
  - ➜ Choice: (a) defer the extraction to a later refactor pass (Tarun, 2026-10-16)

## 10. Findings with no plan item

None — every finding in `01-report.md` has a plan item above.
