# Final Audit — SmartTimetable / AnalyticsController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php` (117 lines, 6 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/analytics` (index), `/smart-timetable/analytics/workload`, `/utilization`, `/violations`, `/distribution`, `/export/{type}` |
| Menu path | No `glb_menus` row for this page. Reached from the Smart Timetable dashboard tile "Analytics" (`TimetableMenuController.php:150`) and the Dashboard timetable dashboard (`dashboard.blade.php:599`). |
| Who uses it | Roles holding `tenant.smart-timetable.report.viewAny` = **Super Admin** and **School Admin** (measured in `sys_role_has_permissions_jnt`). |
| What a user does here | Picks a published timetable from a dropdown, then reads four reports: teacher workload per day/subject, room and period utilization, constraint violations by severity, and subject distribution per class. The workload, utilization and violations reports can be downloaded as CSV. |
| Tables written | none — this controller never writes. |
| Tables read | `tt_timetables`, `tt_timetable_cells`, `tt_timetable_cell_teachers`; then subjects/classes through the service (`tt_activities` and its subject/class relations). |
| Live data | tenant `xyz_school_00000000000040008000_202627`: `tt_timetables` = 0 rows, `tt_timetable_cells` = 0 rows. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is small, read-only, and its authorization is correct: every one of the six routed methods calls `Gate::authorize` before it touches a record, and both permission names exist and are seeded to Super Admin and School Admin. It is **not production-ready yet** because two normal paths are broken. The single worst finding is ANL-01: `timetable_id` is read from the query string with no validation and passed straight into methods typed `int $timetableId`, so a hand-edited URL such as `?timetable_id=abc` throws a `TypeError` and returns a 500 instead of the friendly redirect. ANL-02 is almost as bad: the timetable selector is capped at 25 rows with no pagination control, so older timetables become unselectable. Rough effort for the full plan: **S** (a few hours), no migrations and no new permissions.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 4 | 2 | 1 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean (service linked) |
| F2 Transactions/Audit | clean (read-only) | F9 Queries/Perf | ANL-02 |
| F3 Authorization | ANL-04 | F10 Views | clean |
| F4 Validation | ANL-01 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | ANL-06 |
| F6 Controller shape | ANL-03, ANL-05 | F13 Deep read | clean (no mutations) |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php` | controller | 117 | this report | ✅ |
| 2 | `Modules/SmartTimetable/resources/views/analytics/index.blade.php` | blade | 149 | this report | ✅ |
| 3 | `Modules/SmartTimetable/resources/views/analytics/workload.blade.php` | blade | 64 | this report | ✅ |
| 4 | `Modules/SmartTimetable/resources/views/analytics/utilization.blade.php` | blade | 119 | this report | ✅ |
| 5 | `Modules/SmartTimetable/resources/views/analytics/violations.blade.php` | blade | 112 | this report | ✅ |
| 6 | `Modules/SmartTimetable/resources/views/analytics/distribution.blade.php` | blade | 84 | this report | ✅ |
| 7 | `Modules/SmartTimetable/app/Models/Timetable.php` | model | 11 | this report | ✅ |
| 8 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | 516 | ↗ [TimetableFoundation/TimetableController](../../TimetableFoundation-done/TimetableController-done/01-report.md) | ↗ linked |
| 9 | `Modules/TimetableFoundation/app/Services/AnalyticsService.php` | service | 287 | ↗ [TimetableFoundation/TimetableFoundationController](../../TimetableFoundation-done/TimetableFoundationController-done/01-report.md) | ↗ linked |

Row 7 is pre-assigned to this report by the main session. The controller actually imports the **TimetableFoundation** `Timetable` (row 8), not this 11-line back-compat alias; the alias is audited here anyway because it is registered to this report, and it contains no own `$table`, `$fillable` or `$casts` (it is an empty subclass).

No in-scope file appears in a module `PRE-APPLIED-*.md`.

## 4. Routes

```
GET|HEAD smart-timetable/analytics                  smart-timetable.analytics.index         Modules\SmartTimetable\Http\Controllers\AnalyticsController@index
GET|HEAD smart-timetable/analytics/distribution     smart-timetable.analytics.distribution  Modules\SmartTimetable\Http\Controllers\AnalyticsController@distribution
GET|HEAD smart-timetable/analytics/export/{type}    smart-timetable.analytics.export        Modules\SmartTimetable\Http\Controllers\AnalyticsController@export
GET|HEAD smart-timetable/analytics/utilization      smart-timetable.analytics.utilization   Modules\SmartTimetable\Http\Controllers\AnalyticsController@utilization
GET|HEAD smart-timetable/analytics/violations       smart-timetable.analytics.violations    Modules\SmartTimetable\Http\Controllers\AnalyticsController@violations
GET|HEAD smart-timetable/analytics/workload         smart-timetable.analytics.workload      Modules\SmartTimetable\Http\Controllers\AnalyticsController@workload
```

Unrouted public methods: none. All six public actions are routed; `__construct` is not an action. Every route sits inside the group `['web', 'auth', 'verified', EnsureTenantHasModule::class.':smart-timetable']` (`Modules/SmartTimetable/routes/web.php:43`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | GET /smart-timetable/analytics | `tenant.smart-timetable.report.viewAny` | none — read-only | — | none | ANL-01, ANL-02, ANL-03, ANL-04, ANL-05, ANL-06 |
| `workload` | 39 | GET /smart-timetable/analytics/workload | `tenant.smart-timetable.report.viewAny` | none — read-only | — | none | ANL-01, ANL-03, ANL-04, ANL-05, ANL-06 |
| `utilization` | 53 | GET /smart-timetable/analytics/utilization | `tenant.smart-timetable.report.viewAny` | none — read-only | — | none | ANL-01, ANL-03, ANL-04, ANL-05, ANL-06 |
| `violations` | 67 | GET /smart-timetable/analytics/violations | `tenant.smart-timetable.report.viewAny` | none — read-only | — | none | ANL-01, ANL-03, ANL-04, ANL-05, ANL-06 |
| `distribution` | 81 | GET /smart-timetable/analytics/distribution | `tenant.smart-timetable.report.viewAny` | none — read-only | — | none | ANL-01, ANL-03, ANL-04, ANL-05, ANL-06 |
| `export` | 95 | GET /smart-timetable/analytics/export/{type} | `tenant.smart-timetable.report.export` | none — read-only | — | none | ANL-01, ANL-04, ANL-05, ANL-06 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try|catch|getMessage|RuntimeException' Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php` → no output.

### F2 — Transactions and audit

clean — this controller has no write path. `grep -nE '->create|->update|->delete|->save|DB::transaction|activityLog|insert\(' Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php` → no output.

### F3 — Authorization

#### ANL-04 · M · AUTH-06 — the report permission is a string literal repeated six times

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy or constants — not repeated as literals in every method* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php:19,41,55,69,83,97` |
| **Root cause** | `'tenant.smart-timetable.report.viewAny'` is typed five times and `'tenant.smart-timetable.report.export'` once, instead of being declared once and reused. |
| **Consequence** | Adding or renaming a report permission means editing six call sites; one missed or mistyped literal silently turns that page into a 403 for every role except Super Admin. |
| **Reproduce** | Static only — grep the file for the literal. |
| **Fix approach** | Declare two private class constants and use them in the six `Gate::authorize()` calls. |
| **Plan item** | ANL-04 in `02-fix-plan.md` §4 |

```php
// AnalyticsController.php:19 — the same literal is at 41, 55, 69, 83
        Gate::authorize('tenant.smart-timetable.report.viewAny');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php
19:        Gate::authorize('tenant.smart-timetable.report.viewAny');
41:        Gate::authorize('tenant.smart-timetable.report.viewAny');
55:        Gate::authorize('tenant.smart-timetable.report.viewAny');
69:        Gate::authorize('tenant.smart-timetable.report.viewAny');
83:        Gate::authorize('tenant.smart-timetable.report.viewAny');
97:        Gate::authorize('tenant.smart-timetable.report.export');
```

### F4 — Validation and input

#### ANL-01 · M · VAL-05 — `timetable_id` is read raw and reaches a typed `int` service parameter

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; write paths with no validation are H, read paths stay M* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php:43-48`, method `workload()` (identical at lines 57, 71, 85, 99 and at line 25 in `index()`) |
| **Root cause** | `$request->input('timetable_id')` returns whatever the query string holds — a string, an array, anything. It is passed straight to service methods declared `int $timetableId`. With no `strict_types` PHP coerces a numeric string, but a non-numeric string or an array cannot be coerced to `int`, so PHP raises a `TypeError`. |
| **Consequence** | A user who hand-edits the URL to `?timetable_id=abc` (or follows a stale link) gets a 500 error page instead of the friendly "Please select a timetable." redirect. |
| **Reproduce** | Open `http://test.localhost:8000/smart-timetable/analytics/workload?timetable_id=abc` while signed in as School Admin. Expected the index redirect; actual 500. |
| **Fix approach** | Read the id with `$request->integer('timetable_id')`, which always returns an `int` (0 when absent or non-numeric) so the existing `if (!$timetableId)` guard does its job. |
| **Plan item** | ANL-01 in `02-fix-plan.md` §5 |

```php
// AnalyticsController.php:43-48 — CURRENT (workload; identical at 57, 71, 85, 99)
        $timetableId = $request->input('timetable_id');
        if (!$timetableId) {
            return redirect()->route('smart-timetable.analytics.index')->with('error', 'Please select a timetable.');
        }

        $report = $this->analyticsService->getWorkloadReport($timetableId);
```

**Evidence**
```
$ grep -n 'int $timetableId' Modules/TimetableFoundation/app/Services/AnalyticsService.php
14:    public function getWorkloadReport(int $timetableId): array
56:    public function getUtilizationReport(int $timetableId): array
99:    public function getViolationReport(int $timetableId): array
136:    public function getDistributionReport(int $timetableId): array
$ php -r 'function f(int $x): void {} f("abc");'
PHP Fatal error:  Uncaught TypeError: f(): Argument #1 ($x) must be of type int, string given, called in Command line code on line 1 and defined in Command line code:1
```

### F5 — Routes

clean — all six actions resolve to existing methods, sit inside the `auth` + `EnsureTenantHasModule` group, and every route is a GET that only reads. Evidence: the `route:list` output in §4.

### F6 — Controller shape

#### ANL-03 · M · CTL-05 — four report methods are copy-paste twins

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same guard and redirect repeated across methods* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php:39-93`, methods `workload()`, `utilization()`, `violations()`, `distribution()` |
| **Root cause** | Each of the four methods repeats the identical five steps — guard, read `timetable_id`, empty-check redirect, one service call, one `view()` — changing only the service method name and the view name. |
| **Consequence** | Any change to the guard (for example the ANL-01 validation fix) must be repeated four times and will drift; a fix applied to one method silently misses the other three. |
| **Reproduce** | Static only — read the four methods side by side at lines 39-93. |
| **Fix approach** | Deferred. Extract a private helper that resolves the id and returns the redirect, or map a report key to its service method and view. Recommended as a separate small refactor after the mechanical fixes, so the fixer does not rewrite lines ANL-01 touches in the same pass. |
| **Plan item** | ANL-03 (DECISION) in `02-fix-plan.md` §9 |

```php
// AnalyticsController.php:48-50 (workload) — the same shape is at 62-64, 76-78, 90-92
        $report = $this->analyticsService->getWorkloadReport($timetableId);

        return view('smarttimetable::analytics.workload', compact('report', 'timetableId'));
```

**Evidence**
```
$ grep -nE 'getWorkloadReport|getUtilizationReport|getViolationReport|getDistributionReport|return view' Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php
48:        $report = $this->analyticsService->getWorkloadReport($timetableId);
50:        return view('smarttimetable::analytics.workload', compact('report', 'timetableId'));
62:        $report = $this->analyticsService->getUtilizationReport($timetableId);
64:        return view('smarttimetable::analytics.utilization', compact('report', 'timetableId'));
76:        $report = $this->analyticsService->getViolationReport($timetableId);
78:        return view('smarttimetable::analytics.violations', compact('report', 'timetableId'));
90:        $report = $this->analyticsService->getDistributionReport($timetableId);
92:        return view('smarttimetable::analytics.distribution', compact('report', 'timetableId'));
```

#### ANL-05 · L · CTL-04 — no return types on the six public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php:17,39,53,67,81,95` |
| **Root cause** | Every action omits a return type, so the shape of each response is documented nowhere. |
| **Consequence** | A later change that returns the wrong type (for example `back()` from a `view()` method) is caught only at runtime. |
| **Reproduce** | Static only — the scanner's CTL-04 rows. |
| **Fix approach** | Add `: View|RedirectResponse` to the five report actions and `: Response|RedirectResponse` to `export()`, with the three matching imports. |
| **Plan item** | ANL-05 in `02-fix-plan.md` §8 |

```php
// AnalyticsController.php:95 — the same defect is at 17, 39, 53, 67, 81
    public function export(Request $request, string $type)
```

**Evidence**
```
$ grep -nE 'public function (index|workload|utilization|violations|distribution|export)\(' Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php
17:    public function index(Request $request)
39:    public function workload(Request $request)
53:    public function utilization(Request $request)
67:    public function violations(Request $request)
81:    public function distribution(Request $request)
95:    public function export(Request $request, string $type)
```

### F7 — Models

clean for this report — `Modules/SmartTimetable/app/Models/Timetable.php` is an empty back-compat subclass that declares no own `$table`, `$fillable`, `$casts` or relations, so there is nothing here that can contradict the parent. The parent `Modules/TimetableFoundation/app/Models/Timetable.php` is linked (scope row 8) and audited by its own report. `grep -nE 'table|fillable|casts' Modules/SmartTimetable/app/Models/Timetable.php` → no output.

### F8 — Services and jobs

clean for this report — the controller defines no service and dispatches no job; all work is delegated to the injected `AnalyticsService`, which is linked (scope row 9) and audited elsewhere. This report checked only how the controller calls it: every call passes `$timetableId` (ANL-01) and `exportToCSV($report, $type)` with values it already holds.

### F9 — Queries and performance

#### ANL-02 · M · QRY-02 — the timetable selector is capped at 25 and has no pagination controls

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M, lowered from H) — *lists are paginated; the project standard is 10 per page with a distinct pageName* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php:21-23`, method `index()`; consumed at `Modules/SmartTimetable/resources/views/analytics/index.blade.php:16-21` |
| **Root cause** | `paginate(25)` returns only the newest 25 active timetables, and the Blade loop prints them with `@foreach ($timetables as $tt)` but never renders `$timetables->links()`. The paginator's later pages are unreachable from the UI. |
| **Consequence** | In a school with more than 25 timetables, a user can select and analyse only the newest 25; every older timetable is invisible with no way to page to it. |
| **Reproduce** | Static only — the test tenant has 0 `tt_timetables`, so the cap cannot be shown live. Create 26 active timetables and open `/smart-timetable/analytics`; the dropdown lists 25 and shows no pager. |
| **Fix approach** | Use the project page size (`paginate(10)`) and render `{{ $timetables->links() }}` under the selector form. |
| **Plan item** | ANL-02 in `02-fix-plan.md` §6 |

```php
// AnalyticsController.php:21-23 — CURRENT
        $timetables = Timetable::where('is_active', true)
            ->orderByDesc('created_at')
            ->paginate(25);
```

**Evidence**
```
$ grep -n 'paginate' Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php
23:            ->paginate(25);
$ grep -n 'links()' Modules/SmartTimetable/resources/views/analytics/index.blade.php
(no output)
```

### F10 — Views

clean — no queries, no `{!! !!}` in the five analytics Blades. `grep -nE 'Model::|DB::|->get\(|->count\(|->where\(|\{!!' Modules/SmartTimetable/resources/views/analytics/*.blade.php` → no output. Checked the export-button gate: the `.export` permission is enforced in the controller (`Gate::authorize`, line 97), and the views do not add a second `@can` — consistent with AUTH-04 (exactly one check per concern), so no finding.

### F11 — Security and tenancy

clean — no `env()`, no hard-coded ids or `?? 1`, and the permission names are seeded in the tenant DB. `grep -nE 'env\(|\?\? 1' Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php` → no output. The measured permission rows are `tenant.smart-timetable.report.viewAny` (id 1705) and `tenant.smart-timetable.report.export` (id 1710), both held by Super Admin and School Admin.

### F12 — Style

#### ANL-06 · L · STY-01 — missing `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php:1` |
| **Root cause** | The file opens with `<?php` and no strict-types declaration. |
| **Consequence** | Type coercion stays silent, so combined with ANL-01 a bad input travels further than it should before failing. |
| **Reproduce** | Static only — `sed -n '1,3p'` of the file. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag, to be applied after ANL-01 so every id is already an int. |
| **Plan item** | ANL-06 in `02-fix-plan.md` §8 |

```php
// AnalyticsController.php:1-3 — CURRENT
<?php

namespace Modules\SmartTimetable\Http\Controllers;
```

**Evidence**
```
$ grep -c 'declare(strict_types' Modules/SmartTimetable/app/Http/Controllers/AnalyticsController.php
0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There are no mutating methods: every action is a GET that reads or streams a CSV. The table below records the eight questions per method with `n/a` where a write would be required.

| Method | 1 Overwrite | 2 Delete-first | 3 Dup impl | 4 Soft-del×unique | 5 Race | 6 Auth hole | 7 Lying msg | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `index` | n/a | n/a | ANL-03 | n/a | n/a | ok | ok | ok |
| `workload` | n/a | n/a | ANL-03 | n/a | n/a | ok | ok | ok |
| `utilization` | n/a | n/a | ANL-03 | n/a | n/a | ok | ok | ok |
| `violations` | n/a | n/a | ANL-03 | n/a | n/a | ok | ok | ok |
| `distribution` | n/a | n/a | ANL-03 | n/a | n/a | ok | ok | ok |
| `export` | n/a | n/a | ANL-03 | n/a | n/a | ok | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/TimetableFoundation/app/Services/AnalyticsService.php` | The base query `TimetableCell::where('timetable_id', …)->where('is_active', true)` is repeated in four report methods, and `index()` triggers three of them per request (QRY-12). | QRY-12 | [TimetableFoundation/TimetableFoundationController](../../TimetableFoundation-done/TimetableFoundationController-done/01-report.md) |
| `x-backend.components.breadcrum` + all module views | Every one of the 72 SmartTimetable views passes `:links="[]"`, so no page carries a breadcrumb trail; the UI standard says resolve the trail. Module-wide convention, not this controller's defect. | VIEW (UI standard) | SmartTimetable views pass |
| `Modules/TimetableFoundation/app/Models/Timetable.php` | Parent model of the alias audited here; audited by its own report. | — | [TimetableFoundation/TimetableController](../../TimetableFoundation-done/TimetableController-done/01-report.md) |

## 8. Not covered, and why

- The pages were not opened in a browser; no server was run for this read-only audit (D4 forbids tests).
- Report output was not exercised against live data: the test tenant has 0 `tt_timetables` and 0 `tt_timetable_cells`, so ANL-02's 25-row cap is proved statically, not live.
- `AnalyticsService` internals (its queries and CSV writers) are audited by the TimetableFoundation report that owns the class; this report checked only how the controller calls it.
- Queue jobs and scheduled tasks: the controller dispatches none, so nothing to check.
