# Fix Plan — SmartTimetable / TimetableWorkspaceController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/TimetableFoundation/app/Models/Timetable.php` | owned by the tarun/TimetableFoundation/TimetableController report |
| `Modules/TimetableFoundation/app/Models/Activity.php` | owned by the tarun/TimetableFoundation/ActivityController report |
| `Modules/TimetableFoundation/app/Models/TimetableCell.php` | owned by the tarun/TimetableFoundation/TimetableController report |
| `Modules/TimetableFoundation/app/Models/SchoolDay.php` | owned by the tarun/TimetableFoundation/SchoolDayController report |
| `Modules/TimetableFoundation/app/Models/PeriodSet.php` | owned by the tarun/TimetableFoundation/PeriodSetController report |
| `Modules/TimetableFoundation/app/Models/ClassTimetableType.php` | owned by the tarun/TimetableFoundation/ClassTimetableTypeController report |
| `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php` | owned by the tarun/SmartTimetable/TimetablePreviewController report |
| `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | owned by the tarun/StandardTimetable/StandardTimetableController-done report |
| `Modules/SmartTimetable/routes/web.php` | shared route file; both routes are already correct |
| `config/permissionslist.php` | shared; the permission key already exists and is seeded |
| `resources/views/components/**` and `resources/views/layouts/**` | shared common components and layouts |

## 1. Blockers reachable today

None.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [x] **TWK-01** · H · ERR-02 · `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php:125-169` — remove the controller try/catch so a missing class-section gives a 404, not a 500.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php`
  - **Before** (`TimetableWorkspaceController.php:11-13`):
    ```php
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\SchoolSetup\Models\ClassSection;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Facades\Gate;
    use Modules\SchoolSetup\Models\ClassSection;
    ```
  - **Before** (`TimetableWorkspaceController.php:125-169`):
    ```php
        try {
            $classSection = ClassSection::with(['class', 'section'])
                ->findOrFail($validated['class_section_id']);

            $ctx = $this->context->build($timetable, $classSection);
            $gridState = $this->gridState->transform($ctx);

            return response()->json([
                'success' => true,
                'grid_state' => $gridState,

                // Refreshed on every switch so the flags stay true as work is done
                // elsewhere in the timetable — one extra ~8 ms query.
                'class_options' => $this->classOptions($this->selectableClassSections(), $timetable),

                /*
                | ⚠ SAME KEY SHAPE the client's applyInsights() already reads
                | ({ insights: { html, teacher_load } }), so the panel refreshes on a class
                | switch with no client change.
                |
                | It does NOT refresh after a drop: place / remove / move return no insights
                | key, and applyInsights() no-ops when it is absent. The toolbar's placed
                | count IS live — Vue computes that from the grid — so the number people
                | watch stays honest. Wiring live insights means changing three shared write
                | endpoints, which is deliberately out of this screen's scope.
                */
                'insights' => [
                    'html' => view('smarttimetable::workspace.partials._insights-body', [
                        'gs' => $gridState,
                    ])->render(),
                    'teacher_load' => $gridState['teacher_loads'],
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('Workspace grid load failed', [
                'timetable_id' => $timetable->id,
                'class_section_id' => $validated['class_section_id'],
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Could not load that class. Please try again.',
            ], 500);
        }
    ```
  - **After:**
    ```php
        $classSection = ClassSection::with(['class', 'section'])
            ->findOrFail($validated['class_section_id']);

        $ctx = $this->context->build($timetable, $classSection);
        $gridState = $this->gridState->transform($ctx);

        return response()->json([
            'success' => true,
            'grid_state' => $gridState,

            // Refreshed on every switch so the flags stay true as work is done
            // elsewhere in the timetable — one extra ~8 ms query.
            'class_options' => $this->classOptions($this->selectableClassSections(), $timetable),

            /*
            | ⚠ SAME KEY SHAPE the client's applyInsights() already reads
            | ({ insights: { html, teacher_load } }), so the panel refreshes on a class
            | switch with no client change.
            |
            | It does NOT refresh after a drop: place / remove / move return no insights
            | key, and applyInsights() no-ops when it is absent. The toolbar's placed
            | count IS live — Vue computes that from the grid — so the number people
            | watch stays honest. Wiring live insights means changing three shared write
            | endpoints, which is deliberately out of this screen's scope.
            */
            'insights' => [
                'html' => view('smarttimetable::workspace.partials._insights-body', [
                    'gs' => $gridState,
                ])->render(),
                'teacher_load' => $gridState['teacher_loads'],
            ],
        ]);
    ```
  - **Verify:** `grep -nE 'try \{|\} catch \(|getMessage|Facades\\Log' Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

The only authorization finding (TWK-02) is a behaviour change and is carried as a DECISION in §9.

## 5. Validation, routes, models (F4/F5/F7)

- [x] **TWK-03** · L · VAL-05 · `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php:121-123` — make the grid lookup accept only active class-sections, matching the picker.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php`
  - **Before** (`TimetableWorkspaceController.php:121-123`):
    ```php
        $validated = $request->validate([
            'class_section_id' => 'required|integer|exists:sch_class_section_jnt,id',
        ]);
    ```
  - **After:**
    ```php
        $validated = $request->validate([
            'class_section_id' => ['required', 'integer', \Illuminate\Validation\Rule::exists('sch_class_section_jnt', 'id')->where('is_active', true)],
        ]);
    ```
  - **Verify:** `grep -n "is_active', true)]]" Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php`
  - **Expect:** one hit on the `class_section_id` rule line, between the braces.
  - **Effort:** S

## 6. Queries, performance & services (F8/F9)

- [x] **TWK-05** · M · SVC-02 · `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php:61-63,435,492` — inject `SnapshotContext` instead of resolving it with `app()`.
  - **Touches:** `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php`
  - **Before** (`WorkspaceContext.php:61-63`):
    ```php
        public function __construct(
            private readonly PreviewPlacementService $placement,
        ) {}
    ```
  - **After:**
    ```php
        public function __construct(
            private readonly PreviewPlacementService $placement,
            private readonly SnapshotContext $snapshot,
        ) {}
    ```
  - **Before** (`WorkspaceContext.php:435`):
    ```php
            $snap = app(SnapshotContext::class);
    ```
  - **After:**
    ```php
            $snap = $this->snapshot;
    ```
  - **Before** (`WorkspaceContext.php:492`):
    ```php
            $snap = app(SnapshotContext::class);   // raw SQL: see outstandingByClassSection()
    ```
  - **After:**
    ```php
            $snap = $this->snapshot;   // raw SQL: see outstandingByClassSection()
    ```
  - **Verify:** `grep -n 'app(SnapshotContext::class)' Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **TWK-07** · M · QRY-05 · `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php:198-206` — order the class-sections in SQL instead of loading every row and sorting in PHP.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php`
  - **Before** (`TimetableWorkspaceController.php:198-206`):
    ```php
            return ClassSection::with(['class', 'section'])
                ->where('is_active', true)
                ->get()
                ->sortBy(fn ($cs) => sprintf(
                    '%06d-%06d',
                    (int) ($cs->class?->ordinal ?? 0),
                    (int) ($cs->section?->ordinal ?? 0),
                ))
                ->values();
    ```
  - **After:**
    ```php
            return ClassSection::with(['class', 'section'])
                ->join('sch_classes', 'sch_classes.id', '=', 'sch_class_section_jnt.class_id')
                ->join('sch_sections', 'sch_sections.id', '=', 'sch_class_section_jnt.section_id')
                ->where('sch_class_section_jnt.is_active', true)
                ->orderBy('sch_classes.ordinal')
                ->orderBy('sch_sections.ordinal')
                ->select('sch_class_section_jnt.*')
                ->get();
    ```
  - **Verify:** `grep -n "sortBy(fn (\$cs)" Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php`
  - **Expect:** no output (the `orderBy('sch_classes.ordinal')` join replaces it).
  - **Effort:** M

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [x] **TWK-08** · L · STY-04 · `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php` + both Workspace services — replace the `⛔` and `⚠` comment markers with the plain prefix `NOTE:`.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php`, `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php`, `Modules/SmartTimetable/app/Services/Workspace/WorkspaceGridState.php`
  - **Before** (`TimetableWorkspaceController.php:175`):
    ```php
         * ⛔ ONE COMPOSITE KEY, NOT sortBy([closure, closure]).
    ```
  - **After:**
    ```php
         * NOTE: ONE COMPOSITE KEY, NOT sortBy([closure, closure]).
    ```
  - **Before** (`WorkspaceContext.php:37`):
    ```php
     * ⛔ THE ALL-CLASSES SHAPE CANNOT BE USED HERE. Measured on this tenant 2026-09-03:
    ```
  - **After:**
    ```php
     * NOTE: THE ALL-CLASSES SHAPE CANNOT BE USED HERE. Measured on this tenant 2026-09-03:
    ```
  - **Before** (`WorkspaceGridState.php:15`):
    ```php
     * ⛔ THIS CLASS RUNS NO QUERIES. Everything it needs is already in $ctx. That is what makes
    ```
  - **After:**
    ```php
     * NOTE: THIS CLASS RUNS NO QUERIES. Everything it needs is already in $ctx. That is what makes
    ```
  - **Verify:** `grep -cE '⛔|⚠' Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php Modules/SmartTimetable/app/Services/Workspace/WorkspaceGridState.php`
  - **Expect:** `0` for each of the three files.
  - **Effort:** S

- [x] **TWK-09** · L · STY-02 · `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php:7-20` — run Pint on the file so it is formatter-clean.
  - **Touches:** `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php`
  - **Before** (`WorkspaceContext.php:7-20`):
    ```php
    use Illuminate\Support\Collection;
    use Illuminate\Support\Facades\DB;
    use Modules\TimetableFoundation\Support\Snapshot\SnapshotContext;
    use Modules\SchoolSetup\Models\ClassSection;
    use Modules\SchoolSetup\Models\Room;
    use Modules\SchoolSetup\Models\Teacher;
    use Modules\SchoolSetup\Models\TeacherProfile;
    use Modules\SmartTimetable\Services\Preview\PreviewPlacementService;
    use Modules\TimetableFoundation\Models\Activity;
    use Modules\TimetableFoundation\Models\ClassTimetableType;
    use Modules\TimetableFoundation\Models\PeriodSet;
    use Modules\TimetableFoundation\Models\SchoolDay;
    use Modules\TimetableFoundation\Models\Timetable;
    use Modules\TimetableFoundation\Models\TimetableCell;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Collection;
    use Illuminate\Support\Facades\DB;
    use Modules\SchoolSetup\Models\ClassSection;
    use Modules\SchoolSetup\Models\Room;
    use Modules\SchoolSetup\Models\Teacher;
    use Modules\SchoolSetup\Models\TeacherProfile;
    use Modules\SmartTimetable\Services\Preview\PreviewPlacementService;
    use Modules\TimetableFoundation\Models\Activity;
    use Modules\TimetableFoundation\Models\ClassTimetableType;
    use Modules\TimetableFoundation\Models\PeriodSet;
    use Modules\TimetableFoundation\Models\SchoolDay;
    use Modules\TimetableFoundation\Models\Timetable;
    use Modules\TimetableFoundation\Models\TimetableCell;
    use Modules\TimetableFoundation\Support\Snapshot\SnapshotContext;
    ```
  - **Note:** the remaining fixers Pint reports (`unary_operator_spaces`, `braces_position`, `not_operator_with_successor_space`, `single_line_empty_body`) are applied by running the command below on the file; the import reorder above is the diff those fixers do not own.
  - **Verify:** `vendor/bin/pint Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php --test --format agent`
  - **Expect:** `{"tool":"pint","result":"pass",...}` with no `files` entry.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **TWK-02** · M · DECISION · AUTH-02 — check the permission before the bound timetable is loaded?
  - **Why it is a decision:** fixing it means changing the method signature away from implicit route-model binding (a behaviour change on a live route) or accepting the id-existence oracle as low risk.
  - (a) ⭐ accept as is for this controller (standard Laravel binding; the permission is global and login is required), and record it as accepted debt.
  - (b) change both methods to take `int $timetableId`, call `Gate::authorize()` first, then `Timetable::findOrFail($timetableId)`; keep the route parameter name so no route edit is needed.
  - (c) add a `Timetable` policy and a `can:` route middleware and remove the in-method gate.
  - ➜ Choice: (a) accept as recorded debt — Tarun 2026-10-16

- [x] **TWK-04** · M · DECISION · CTL-02 — split the 238-line `WorkspaceContext::build()` and the 344-line `WorkspaceGridState::transform()`?
  - **Why it is a decision:** it is a large, behaviour-preserving refactor of two read-only assemblers; D3 defers controller splits, and the same discipline applies here.
  - (a) ⭐ defer the extraction to a dedicated refactor pass (D3); apply only the mechanical items now.
  - (b) extract named section methods (days, periods, activities, cells, legality maps) from both methods in this pass.
  - (c) leave as is, record as accepted debt.
  - ➜ Choice: (a) defer to the split pass (D3) — Tarun 2026-10-16

- [x] **TWK-06** · M · DECISION · SVC-04 — de-duplicate the grid loader copied from `StandardTimetableController::manualPlacement()`?
  - **Why it is a decision:** the extraction touches a working screen in another module, so it is a cross-controller refactor with its own blast radius.
  - (a) ⭐ defer the shared-loader extraction to the refactor pass the class header recommends; apply only the mechanical items now.
  - (b) extract the common loader into one service used by both `StandardTimetableController` and `WorkspaceContext` in this pass.
  - (c) leave as is, record as accepted debt.
  - ➜ Choice: (a) defer to the refactor pass — Tarun 2026-10-16

## 10. Findings with no plan item

None — every finding in `01-report.md` has a plan item above.
