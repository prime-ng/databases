# Status — SmartTimetable / TimetableWorkspaceController

**Fixed:** 2026-10-16 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md` + decisions in `../00-USAGE-AND-FIX-PLAN-2026-10-16.md` §5.1

## 1. Pre-applied work
None. `tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md` lists no file in this controller's scope.

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| TWK-01 | `TimetableWorkspaceController.php` `grid()` | Removed the controller `try`/`catch (\Throwable)` and the `Log` import (D1). A missing class-section is now a native 404 from `findOrFail()`. Any other failure reaches the central handler, which logs it and renders `{success:false, message}`. The response body is unchanged. | `grep -nE 'try \{\|\} catch \(\|getMessage\|Facades\\Log' …` | no output | 2026-10-16 |
| TWK-03 | `grid()` validation | `class_section_id` now uses `Rule::exists('sch_class_section_jnt','id')->where('is_active', true)`, the same set the picker offers. | `grep -n "Rule::exists" …` | line 124 | 2026-10-16 |
| TWK-05 | `Services/Workspace/WorkspaceContext.php` | `SnapshotContext` is injected through the constructor; both `app(SnapshotContext::class)` calls now read `$this->snapshot`. This is safe because the binding is `scoped` (`TimetableFoundationServiceProvider.php:111`) and its state is set by `enter()` on the same instance. | `grep -n 'app(SnapshotContext' …` | no output | 2026-10-16 |
| TWK-07 | `selectableClassSections()` | Ordering moved into SQL: joins on `sch_classes` and `sch_sections`, ordered by both ordinals, selecting `sch_class_section_jnt.*`. Replaces loading every row and sorting a composite key in PHP. | rolled-back probe: old order vs new order | 43 = 43, identical sequence | 2026-10-16 |
| TWK-08 | controller + `WorkspaceContext.php` + `WorkspaceGridState.php` | Every warning-sign and stop-sign comment marker replaced with `NOTE:`. | `grep -cE '⛔\|⚠' <3 files>` | 0 / 0 / 0 | 2026-10-16 |
| TWK-09 | `WorkspaceContext.php` | Pint run (ordered_imports, unary_operator_spaces, braces_position, not_operator_with_successor_space, single_line_empty_body). | `vendor/bin/pint … --format agent` | fixed, then clean | 2026-10-16 |
| TWK-02 | — | DECISION (a): accepted as recorded debt. Standard implicit route-model binding runs before the gate. The permission is global and login is required, so the only exposure is whether an id exists, visible to a logged-in user. | — | — | 2026-10-16 |
| TWK-04 | — | DECISION (a): deferred to the split pass (D3). | — | — | 2026-10-16 |
| TWK-06 | — | DECISION (a): deferred to the split pass. The shared-loader extraction touches `StandardTimetableController`. | — | — | 2026-10-16 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| TWK-02 | DECISION (a): accepted | Counted as open M |
| TWK-04 | DECISION (a): deferred | `build()` 238 lines, `transform()` 344 lines |
| TWK-06 | DECISION (a): deferred | Duplicate of `StandardTimetableController::manualPlacement()`'s loader |

## 4. Needs Tarun's hand
- Browser check on `/smart-timetable/timetable/{id}/preview`: switch classes from the dropdown. The grid, insights panel and class list should all refresh, and the picker order should still run Nursery → XII.
- Nothing needs to be migrated, seeded or synced.

## 5. Unverifiable by this workflow (no tests, D4)
- `grid()` was not executed over HTTP. The TWK-01 change only removes a wrapper, and the response array is byte-identical.

## 6. Verification log
```
php -l controller + WorkspaceContext + WorkspaceGridState   -> No syntax errors detected x3 (after Pint)
vendor/bin/pint <3 files> --format agent                    -> WorkspaceContext fixed (5 fixers incl. ordered_imports)
class resolve: app(TimetableWorkspaceController::class)     -> instance (constructor injection of WorkspaceContext + SnapshotContext OK)
TWK-07 parity probe (tenant test.localhost, read-only)      -> old PHP sort 43 ids, new SQL order 43 ids, same=true
```

## 7. Final state
Status: FIXED · Open: B 0 · H 0 · M 3 (TWK-02 accepted; TWK-04, TWK-06 deferred) · L 0
