# Status — SmartTimetable / ConstraintController

**Fixed:** 2026-10-15 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

Decisions (Tarun, 2026-10-15): restore becomes PUT on all five Constraint Engine resources; bind the resource methods; constraint engine gets **bug fixes only** — CST-16/17/18 and CST-23 (b) applied, CST-19 deferred, CST-22 (c).

⚠ **One decision departs from its recommendation.** CST-08's ⭐ (a) puts `can:` middleware on the route. Measured: `SubstituteBindings` runs BEFORE `can:` (`vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php:113-114`), so (a) would still answer 404 for a missing id before it answers 403. (b) was applied instead.

## 1. Pre-applied work
none

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| CST-01 | ConstraintController.php `store()` | try/catch removed (D1); no exception text reaches the user; write in a `DB::transaction` closure, redirect after | `grep -c getMessage` | 0 | 2026-10-15 |
| CST-02 | `update()` | same as CST-01 | `grep -c getMessage` | 0 | 2026-10-15 |
| CST-03 | `destroy()` | try/catch removed; `is_active` no longer wiped on trash | read method | transaction + log only | 2026-10-15 |
| CST-04 | `restore()` | try/catch removed; no forced `is_active = true`, so an inactive constraint comes back inactive | read method | — | 2026-10-15 |
| CST-05 | `forceDelete()` | try/catch removed, redirect after the closure | read method | — | 2026-10-15 |
| CST-06 | `toggleStatus()` | try/catch removed; failure goes to the central handler (D1); one-field inline validate kept | `grep -c "try {"` | 1 (private `normalizeJson()` JSON parse — legitimate local catch) | 2026-10-15 |
| CST-07 | routes/web.php:259 | restore is `Route::put` (PUT, not the plan's POST). No component edit — `action-trashed` reads the verb from the route | router probe | `PUT …constraint.restore` | 2026-10-15 |
| CST-08 | `editByCategory($id)`, `toggleStatus(Request, $id)` | choice (b): `Gate::authorize` first, then `Constraint::findOrFail($id)`; comments at lines 97 and 420 explain why (a) cannot work | grep "CST-08" | 2 hits | 2026-10-15 |
| CST-09 | Store/UpdateConstraintRequest `after()` | a non-GLOBAL constraint must carry `target_id` — "A target id is required for non-global constraints."; `strict_types`. ⚠ The plan applier patched only Store; Update was done by hand | grep TARGET_GLOBAL | Store:64, Update:61 | 2026-10-15 |
| CST-10 | `show`/`edit`/`update`/`destroy` | bound to `Constraint $constraint` (`{constraint}`) | reflection | typed arg matches | 2026-10-15 |
| CST-11 | private `categoryLookups()` (line ~437) | one helper for both category forms. ⚠ **Plan defect corrected:** the plan's After block narrowed the columns, which broke the blades (`$teacher->user->name`, `$room->building->name`, activity class/section). Full queries restored: `Teacher::with('user')`, `Room::with('building')`, `Activity::…->with(['class','section'])`. ⚠ **Second defect corrected:** the After block left the old lookup block inside `editByCategory()`, which reset the helper's results and re-ran every query; removed (522 → 499 lines) | probe all 5 category codes | ok — teachers 89 / classes 15 / rooms 69 / activities 614 | 2026-10-15 |
| CST-11 (bug) | `categoryLookups()` | **real 500 fixed:** the original `editByCategory` ordered terms by `start_date`, a column `sch_academic_term` does not have (SQL 1054). The merged helper would have spread it to `createByCategory`. Now `orderByDesc('term_start_date')` | grep term_start_date | 1 hit + comment | 2026-10-15 |
| CST-15 | Controller | `strict_types`; `⚠` marker removed | grep | 1 / 0 | 2026-10-15 |
| CST-16 | Services/Constraints/ConstraintManager.php | hard-constraint rejection is unconditional, no longer gated on `verbose_logging` | read | — | 2026-10-15 |
| CST-17 | ConstraintEvaluator.php | the factory is no longer called statically | read | — | 2026-10-15 |
| CST-18 | ConstraintFactory.php:62-68 | `_constraint_meta` reads attributes that exist (`id`, `name`, `description`, `target_type`, `target_id`, …) | read | — | 2026-10-15 |
| CST-20 | ConstraintEvaluator.php | soft-scoring failures are reported, no longer swallowed by an empty catch | read | — | 2026-10-15 |
| CST-21 | DatabaseConstraintService.php:44 | `report($e)` (keeps the trace) instead of logging only the message | grep report( | line 44 | 2026-10-15 |
| CST-22 | — | choice (c): both engines kept; only the landmines (CST-17, CST-20) fixed | — | — | 2026-10-15 |
| CST-23 | Soft/TeacherMaxGapsPerDayConstraint.php, Hard/GenericHardConstraint.php | choice (b): the two sampled context reads now accept an array context or an object's public property; a missing map logs one warning (`warnOnce`) and passes instead of crashing | rolled-back probe | Hard: LUNCH obj→false, array→true, missing→true · Soft: gaps over limit→false, none→true, missing→true | 2026-10-15 |

Pint run on the 9 touched files of this cluster, one by one; `php -l` and `class_exists` re-run after.

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| CST-19 | deferred (Tarun: bug fixes only) | the six live constraint types still resolve to generic classes; neither the rebuild nor (c)'s UI warning was added |

## 4. Needs Tarun's hand
- **Run the Dusk suites yourself.** Restore is now PUT on all five resources, so the "GET /{missing}/restore expects 404" tests will fail: `TtConstraintsTest:1528`, `TtConstraintTypeTest:1465`, `TtRoomUnavailableTest:1440` and the matching test in `TtTeacherUnavailableTest`. Not edited (D4).
- **Behaviour change:** a failed status toggle used to return 422 JSON; it is now the central handler's JSON error (D1).
- A browser check of the category create/edit forms (`/smart-timetable/constraint/create/{category}` and the edit-by-category page) and the trash Restore button.

## 5. Unverifiable by this workflow (no tests, D4)
- CST-16/17/20/23 change generator behaviour; proven by rolled-back probes only, not by generating a timetable.
- ⚠ **Finding left as a note, not changed:** `categoryLookups()` filters constraint types by codes like `TEACHER_AVAILABILITY`, but the live category codes are `TEACHER`, `ROOM`, …, so the type list on the category forms returns 0 rows. This was the existing behaviour before this pass (cross-cutting; belongs with CST-19).
- PrimeSolver keeps `teacherOccupied` private on `TimetableSolution`, so in production the CST-23 reads hit the "missing map" branch and pass. The contract question is CST-19/23 (a) work.

## 6. Verification log
```
php -l   (all touched PHP files)                      -> No syntax errors
class_exists (22 classes across the 5 controllers,
  requests, models, engine services, 2 constraints)    -> all true
vendor/bin/pint <touched files> --format agent         -> fixed / passed
router probe (uncached)                                -> PUT on all 5 restore routes; every routed method exists
grep getMessage / Log import in ConstraintController   -> 0 / 0
categoryLookups() probe, 5 category codes              -> all ok (see CST-11)
```

## 7. Final state
Status: FIXED · Open: B 0 · H 1 · M 2 · L 0
(H: CST-19 deferred · M: CST-22 and CST-23 partly done — two engines and the base-class refactor remain.)
