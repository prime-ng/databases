# SmartTimetable — usage check and fix plan (5 controllers)

**Date:** 2026-10-16 · **Developer folder:** tarun · **Status:** PLAN ONLY — nothing applied

Standing direction from Tarun: **only the Python engine is used. Retire the PHP engine.**

## 1. Are these controllers used? — measured, not assumed

Each verdict comes from four checks: whether the route is registered (uncached `route:list`), whether a `glb_menus` row points at it, and who links to it from blades or JS. A link only counts if the page it sits on is itself reachable.

| Controller | Routes | In the sidebar? | Verdict |
|---|---:|---|---|
| **TimetableWorkspaceController** | 2 | — | ✅ **IN USE, core.** It owns `smart-timetable.timetable.preview`. `PythonTimetableController` redirects there after saving a generated timetable (`:3141`), and 17 links point at it. This is the screen people use to read and edit a Python result. |
| **TimetableMenuController** | 5 | 3 of 5 | ✅ **IN USE, partly.** `constraintEngine` (menu 281), `viewAndRefinement` (285) and `substituteManagement` (287) are sidebar items. `timetableConfiguration` is linked from the Timetable Configuration page. ❌ **`dashboard()` (`/smart-timetable`) is unreachable**: no menu row, and its only links are breadcrumb parents of the TimetablePageController pages, which are unreachable themselves. |
| **SmartTimetableController** | 12 | — | ⚠ **PARTLY IN USE.** The Timetable Generation page's list (`partials/timetable/_list.blade.php:296`) gives every Python-generated timetable `x-backend.table.action` buttons wired to this controller, so **`show` (redirects to preview), `edit`, `update` and `destroy` are live**. ❌ Dead: `index` (its only link is on the validation page, which is unrouted), `create` and `store` (already `abort(403)`), the 5 `api/v1/smarttimetables` routes (no caller), and 20 unrouted public methods. Those include the old PHP-engine copies `generate()` and `generateWithPrime()`. |
| **TimetablePageController** | 5 | — | ❌ **NOT USED.** None of its 5 pages has a menu row. `constraints` links only to itself, `timetable-config` and `timetable-master` appear only in breadcrumb config, `timetable-reports` posts only to itself, and `timetable-opration` is linked only from the unreachable `dashboard()`. It is an island you can reach only by typing a URL. `constraints` duplicates the live Constraint Engine. |
| **TtGenerationStrategyController** | **0** | — | ❌ **NOT USED.** It has no routes. Its tab (Timetable Configuration → Generation Strategy) renders through `route_or_hash()` against `timetable-foundation.generation-strategies.*`, which is **commented out** (`TimetableFoundation/routes/web.php:386`). So every View, Edit and Delete button on that tab is a `#` link. |

### 1.1 Where the PHP engine actually lives

It is **not** in SmartTimetableController's routes. It is in **TimetableGenerationController**:

| Route | Method | UI entry point today |
|---|---|---|
| `POST smart-timetable/generate/generate-prime` | `generateWithPrime` | ❌ none. `#generatePrimeModal` is still rendered by `_wizard`, but no button opens it. The note at `_search-bar.blade.php:27-43` records this since 2026-09-04 |
| `GET smart-timetable/generate/random` | `generate` | ❌ none found |
| `GET smart-timetable/generate/{class}/{section}/generate` | `generateForClassSection` | ❌ none found |
| `POST smart-timetable/generate/reset-lock` | `resetGenerationLock` | ❌ none. The note says a stuck lock has no UI path |

The Python flow (`python-timetable.*` on PythonTimetableController, opened from `#pyt_generateModal`) is the only generator a user can reach. TimetableGenerationController is not in your list of five, but retiring the PHP engine means touching these four routes.

---

## 2. Fix plan — the controllers in use

Order follows `final-audit.md` §7: blockers first, then errors and transactions, then the rest. Items on dead code are marked **MOOT if retired**, so they are not fixed and then deleted.

### 2.1 SmartTimetableController — only the live slice (show / edit / update / destroy)

| Order | Item | Sev | What | Why it matters |
|---|---|---|---|---|
| 1 | **STM-01** | **B** | Rewrite `destroy()` the Laravel way: one `DB::transaction`, no catch, no raw exception text to the user | It is the **Delete button on every row of the Timetable Generation list** |
| 2 | **STM-05** | M | Rewrite `update()` the same way | It is the **Edit** button on the same list |
| 3 | **STM-08** | M · DECISION | The 20 unrouted public methods become `abort(403, …)` stubs with `NOT ROUTED` comments (D5). This includes `generate()` and `generateWithPrime()`, which is **the PHP-engine part of this file** | Retires the PHP copies in this file without deleting anything |
| — | STM-15 | H | 11 paginators on `index()` | **MOOT if `index` is retired** (the page is unreachable) |
| — | STM-06 | M · DECISION | `SmartTimetablePolicy` is registered and never consulted | Recommend: record it, decide with the other Policy findings module-wide |
| — | STM-09 | M · DECISION | Split the 1,784-line class | Recommend: defer (D3) |

Recommendation: apply 1-3. Decide separately whether to unroute `index`, `create`, `store` and the 5 API routes (§3).

### 2.2 TimetableWorkspaceController — fix everything

| Order | Item | Sev | What |
|---|---|---|---|
| 1 | **TWK-01** | H | Remove the controller try/catch, so a missing class-section gives a 404 instead of a 500 |
| 2 | **TWK-03** | L | The grid lookup accepts only active class-sections, matching the picker |
| 3 | **TWK-07** | M | Sort the class-sections in SQL instead of loading every row and sorting in PHP |
| 4 | **TWK-05** | M | Inject `SnapshotContext` instead of calling `app()` (`WorkspaceContext`) |
| 5 | TWK-08 / TWK-09 | L | Comment markers to `NOTE:`; Pint on `WorkspaceContext` |
| — | TWK-02 | M · DECISION | Check the permission before the timetable is loaded (route binding happens first today). Recommend (a) as the plan proposes |
| — | TWK-04 / TWK-06 | M · DECISION | Split `build()` and `transform()`; de-duplicate the loader copied from StandardTimetable. Recommend: defer both |

All three in-use controllers carry real users' daily work, but this one is the screen people land on after every generation, so it is first on the list in §4.

### 2.3 TimetableMenuController — the four live pages

| Order | Item | Sev | What | Live? |
|---|---|---|---|---|
| 1 | **TMN-02** | L | View & Refinement's `?pv_date` parse uses a format check instead of try/catch | ✅ View & Refinement |
| 2 | **TMN-04** | M | Six unrouted methods become `abort(403)` stubs (D5) | ✅ hygiene |
| 3 | **TMN-15** | L | Comment glyphs to plain words | ✅ |
| — | **TMN-12** | H · DECISION | Paginate the Substitute Management lists | ✅ **live page** — recommend paginating at 10 |
| — | TMN-01 | H | Stop swallowing count failures in `dashboard()` | **MOOT if `dashboard` is retired** |
| — | TMN-11 | H | One grouped query for the dashboard's recent-timetables cell counts | **MOOT if `dashboard` is retired** |
| — | TMN-16 | M | Dashboard's slot-requirement count excludes trashed rows | **MOOT if `dashboard` is retired** |
| — | TMN-05 | M · DECISION | Split the 1,781-line class | Recommend: defer (D3) |

---

## 3. Retirement — needs your decision (a route change is never a solo fix)

| # | Candidate | What "retire" means | Blast radius (measured) |
|---|---|---|---|
| R1 | **TtGenerationStrategyController** | Its 13 public methods become `abort(403)` stubs (D5: never deleted). Decide separately what happens to the Generation Strategy **tab**, whose buttons are all `#` | 0 routes. The tab is the only user-visible surface |
| R2 | **TimetablePageController** (5 routes) | Remove the 5 routes; the methods become `abort(403)` stubs. Remove their 4 breadcrumb entries and the `timetableOperation` link in `TimetableMenuController` (`:147`) | No menu row. Every inbound link is on a page that is itself unreachable |
| R3 | **TimetableMenuController::dashboard** | Remove the `smart-timetable.dashboard` route; the method becomes an `abort(403)` stub. Breadcrumb parents of R2 go with R2 | Closes TMN-01, TMN-11 and TMN-16 as moot |
| R4 | **SmartTimetableController** `index`, `create`, `store` + 5 API routes | Narrow the resource to `->only(['show','edit','update','destroy'])` and remove `apiResource` | The validation-page "back" link points at `index`, but that page is unrouted |
| R5 | **PHP engine in TimetableGenerationController** (4 routes, §1.1) and the inert `#generatePrimeModal` | Unroute the 4; methods become `abort(403)`; stop including `_generate-prime-modal` | No UI entry point. ⚠ `reset-lock` is the only lock-reset path, even without a button. Check whether the Python engine uses the same lock before removing it |

Each R item is a route change, which `screen-readiness-fix.md` §3.2 says needs your explicit go.

---

## 4. Suggested order of work

1. **SmartTimetableController** STM-01, STM-05, STM-08: the live Delete and Edit buttons, plus retiring the PHP copies.
2. **TimetableWorkspaceController**, the whole plan: the screen people land on after every generation.
3. **TimetableMenuController**: TMN-02, TMN-04, TMN-15, plus TMN-12 if you choose to paginate.
4. **Retirements R1-R5**, as you decide, one controller per pass. Each R item gets its own `03-status.md` row.

Each step follows the standing workflow: tick the controller's `02-fix-plan.md`, apply, verify (php -l, class_exists, router probe, blade compile, grep, Pint), write `03-status.md`, update the index row, rename to `-done`.

---

## 5. Decisions taken — Tarun, 2026-10-16

| # | Decision |
|---|---|
| R1 | ✅ **Retire** TtGenerationStrategyController. Its methods become `abort(403)` stubs. The Generation Strategy tab's fate is still open; ask when R1 is applied |
| R2 + R3 | ✅ **Retire** the TimetablePageController routes and `TimetableMenuController::dashboard`. TMN-01, TMN-11 and TMN-16 close as moot |
| R4 | ✅ **Retire** SmartTimetableController `index`/`create`/`store` and the 5 API routes. Keep `show`/`edit`/`update`/`destroy`. STM-15 closes as moot |
| R5 | ✅ **Retire** the PHP-engine routes and the inert `#generatePrimeModal`. ⚠ First check whether the Python engine uses the same generation lock as `reset-lock` |
| TMN-12 | ✅ **Paginate** the Substitute Management lists at 10, each list with its own page name |

Still to decide when each controller is applied: TWK-02 (recommend a), and STM-06 (record it). TWK-04, TWK-06, STM-09 and TMN-05 are recommended for deferral.

### 5.1 Decisions taken — Tarun, 2026-10-16 (second round, "finish all")

| # | Decision |
|---|---|
| Splits | TWK-04, TWK-06, TEX-02, TGC-10, TMN-05, PYC-12, PYC-13 → **deferred** to the split pass (D3) |
| TEX-01 | **Add** `export` to `smart-timetable.timetable` in `config/permissionslist.php`; gate all 5 export methods and the export buttons on `tenant.smart-timetable.timetable.export`. Tarun runs `/system-config/sync-permissions` |
| TGC-17 | **Paginate** Generation History at 10 with its own page name; tiles + trend from one SQL aggregate |
| R1 tab | **Hide** the Generation Strategy tab (blade stays on disk) |
| PYC-08 | **Delete** the half-written skeleton when `populateFromResult()` fails |
| PYC-10 | **Extract** `GridRequest`, `GenerateRequest`, `StoreRequest`, rules and comments copied verbatim |
| R5 scope | **Unroute all 6** PHP-engine routes (generate-prime POST+GET, random, reset-lock, generate-for-class-section, store-timetable); methods → `abort(403)` stubs; `_options` fallback → `#`; stop including `_generate-prime-modal` |
| Low-risk | TWK-02, TEX-04, TEX-05, PYC-07 → **accepted** as recorded debt |
| Moot | TGC-07, TGC-08, TGC-09 (R5 retires the methods/routes they concern) |
| PYC-17 | **Accepted as debt** (asked 2026-10-16): `strict_types` on the Python controller would TypeError every generate, because the form posts integers as strings |

## 6. Progress

| Step | Controller | Status |
|---|---|---|
| 1 | SmartTimetableController (STM-01/05/07/08 + R4) | ✅ done 2026-10-16 — `SmartTimetableController-done/03-status.md` |
| 2 | TimetableWorkspaceController | ✅ done 2026-10-16 — `TimetableWorkspaceController-done/03-status.md` |
| 3 | TimetableMenuController (+ TMN-12, R3 dashboard) | ✅ done 2026-10-16 — `TimetableMenuController-done/03-status.md` |
| 4 | Retirements R1 (TtGenerationStrategy), R2 (TimetablePage), R5 (PHP engine) | ✅ done 2026-10-16 — R1 `TtGenerationStrategyController-done/`, R2 `TimetablePageController-done/`, R5 `TimetableGenerationController-done/` (6 routes unrouted, 5 methods → `abort(403)` stubs; the broken `generate-for-class-section` route is gone) |
| 5 | TimetableExportController (TEX-01 `.export` permission) | ✅ done 2026-10-16 — ⚠ run `/system-config/sync-permissions` to mint `tenant.smart-timetable.timetable.export` |
| 6 | PythonTimetableController (PYC-01…05, 08, 10, 14…16, 18) | ✅ done 2026-10-16 — `PythonTimetableController-done/03-status.md`; PYC-17 accepted as debt (see §5.1) |

**All 19 SmartTimetable controllers are FIXED** (`00-INDEX.md`). Open items are deferred splits (D3), §10 no-plan findings, and recorded debt. No migration was written in this pass.
