# Fix Plan — Payment / PaymentReconciliationController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php` for developer `tarun`. It applies **only** ticked items, in this order.
>
> **Ordering note for the fixer:** several items touch the same `store()` / `resolve()` regions. Apply in the listed order and **re-measure before each edit** (final-audit.md §9.2 #3); if a region no longer matches its Before because an earlier item changed it, record "superseded" and apply the same intent to the current code. The `resolve()` redirect (PRC-03) and the `store()` body (PRC-01) are deliberately quoted so they do not overlap.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Payment/routes/web.php` | shared route file — this plan points the references at the registered names, it never changes a route |
| `Modules/Payment/app/Providers/RouteServiceProvider.php` | module glue (§4.2) and the source of the `payment.` name prefix |
| `Modules/Payment/app/Models/Payment.php` | owned by `tarun/ParentPortal-done/ParentFeePaymentController` |
| `Modules/Payment/app/Models/PaymentGateway.php` | owned by `tarun/ParentPortal-done/ParentFeePaymentController` |
| `resources/views/backend/layouts/master.blade.php` | shared layout — only touched if PRC-14 option (a) is chosen |
| `Modules/Prime/resources/views/**` | shared Prime views — only touched if PRC-14 option (b) is chosen |
| `config/permissionslist.php` | shared config — all four gate strings already exist (`payment.reconciliation` key); no change proposed |
| any migration | standing rule: never edit an existing migration |

## 1. Blockers reachable today

- [ ] **PRC-06** · B · RTE-02 · `Modules/Payment/resources/views/reconciliation/index.blade.php:62,80` and `show.blade.php:10,18` — point every `route()` call at the registered (double-prefixed) names so the pages stop 500-ing. The two controller redirects are corrected inside PRC-01 (store) and PRC-03 (resolve).
  - **Touches:** `Modules/Payment/resources/views/reconciliation/index.blade.php`, `Modules/Payment/resources/views/reconciliation/show.blade.php`
  - **Before** (`index.blade.php:62-63`):
    ```blade
                                        <a href="{{ route('payment.reconciliation.show', $recon->id) }}"
                                           class="btn btn-sm btn-outline-primary">View</a>
    ```
  - **After:**
    ```blade
                                        <a href="{{ route('payment.payment.reconciliation.show', $recon->id) }}"
                                           class="btn btn-sm btn-outline-primary">View</a>
    ```
  - **Before** (`index.blade.php:80`):
    ```blade
            <form method="POST" action="{{ route('payment.reconciliation.store') }}" enctype="multipart/form-data" class="modal-content">
    ```
  - **After:**
    ```blade
            <form method="POST" action="{{ route('payment.payment.reconciliation.store') }}" enctype="multipart/form-data" class="modal-content">
    ```
  - **Before** (`show.blade.php:10`):
    ```blade
                <form method="POST" action="{{ route('payment.reconciliation.resolve', $reconciliation->id) }}"
    ```
  - **After:**
    ```blade
                <form method="POST" action="{{ route('payment.payment.reconciliation.resolve', $reconciliation->id) }}"
    ```
  - **Before** (`show.blade.php:18`):
    ```blade
            <a href="{{ route('payment.reconciliation.index') }}" class="btn btn-sm btn-outline-secondary">
    ```
  - **After:**
    ```blade
            <a href="{{ route('payment.payment.reconciliation.index') }}" class="btn btn-sm btn-outline-secondary">
    ```
  - **Verify:** `grep -rnE "route\('payment\.reconciliation\." Modules/Payment/resources/views/reconciliation/`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **PRC-14** · B · DECISION · VIEW-04 — both pages extend `prime::layouts.master`, which does not resolve, so they 500 before anything renders. Which layout should they use?
  - **Why it is a decision:** the target layout is a shared file, and the same broken `@extends` sits in four other Payment views owned by other reports (`BackendPaymentController` BPA-01, `BackendRefundController` BRF-01, `BackendWebhookController`). Editing or creating a shared layout reaches outside this controller's files.
  - (a) ⭐ Point the two audited views at the existing `backend.layouts.master` (`resources/views/backend/layouts/master.blade.php`, already used by other backend views); fold each `content_header` block into `@section('content')`, because that layout yields only `content`. No new file. Matches the recommendation already recorded for BPA-01. Fixes only these two pages.
  - (b) Create the missing `Modules/Prime/resources/views/layouts/master.blade.php` (an AdminLTE-style layout with `@yield('content')` and `@yield('content_header')`) so all six Payment views and any future `prime::layouts.master` consumer resolve. One new shared file; larger blast radius; needs a follow-up look at every `prime::layouts.master` user.
  - (c) Defer to a module-wide Payment view pass (the other Payment views share the break) — leave both pages down until then.
  - ➜ Choice: ____

## 2. Fixes that arm a latent defect (sequenced)

None. PRC-14 must be fixed before PRC-06's view edits are visible to a user, but the edits are independent and any order leaves the code valid.

## 3. Errors & transactions (F1/F2)

- [ ] **PRC-01** · H · ERR-00 · `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:83-107,121-147` — remove the controller `try/catch` from `store()` and `resolve()` (D1). The central handler in `bootstrap/app.php` logs and renders; `findOrFail()` stays outside any catch.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Before** (`PaymentReconciliationController.php:83-84`, store opener):
    ```php
            try {
                $gateway = PaymentGateway::findOrFail($validated['gateway_id']);
    ```
  - **After:**
    ```php
            $gateway = PaymentGateway::findOrFail($validated['gateway_id']);
    ```
  - **Before** (`PaymentReconciliationController.php:96-107`, store catch blocks):
    ```php
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing gateway must stay a 404. Without this the generic catch
                // below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('PaymentReconciliationController::store failed', [
                    'gateway_id' => $validated['gateway_id'],
                    'error'      => $e->getMessage(),
                ]);

                return back()->with('error', 'The reconciliation could not be completed.');
            }
    ```
  - **After:**
    ```php
            // (both catch blocks are deleted — no replacement)
    ```
  - **Before** (`PaymentReconciliationController.php:121-122`, resolve opener):
    ```php
            try {
                return DB::transaction(function () use ($id) {
    ```
  - **After:**
    ```php
            return DB::transaction(function () use ($id) {
    ```
  - **Before** (`PaymentReconciliationController.php:139-147`, resolve catch blocks):
    ```php
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('PaymentReconciliationController::resolve failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
    ```
  - **After:**
    ```php
            // (both catch blocks are deleted — no replacement)
    ```
  - **Verify:** `grep -n "try {\|catch (" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **PRC-03** · M · TXN-05 · `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:135-138` — return the model from the transaction and build the redirect after it; the redirect also carries the corrected route name.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Before** (`PaymentReconciliationController.php:135-138`):
    ```php
                    return redirect()->route('payment.reconciliation.show', $recon->id)
                        ->with('success', 'Reconciliation marked as resolved.');

                });
    ```
  - **After:**
    ```php
                    return $recon;
                });

            return redirect()->route('payment.payment.reconciliation.show', $recon->id)
                ->with('success', 'Reconciliation marked as resolved.');
    ```
  - **Verify:** `grep -n "return \$recon;\|return DB::transaction" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Expect:** a `return $recon;` line inside the closure and the `redirect()->route('payment.payment.reconciliation.show'` after the `});`.
  - **Effort:** S

- [ ] **PRC-11** · M · ERR-06 · `Modules/Payment/app/Services/PaymentReconciliationService.php:160-165` — stop dropping malformed CSV rows without a trace; count them and report the count on the record.
  - **Touches:** `Modules/Payment/app/Services/PaymentReconciliationService.php`
  - **Before** (`PaymentReconciliationService.php:160-165`):
    ```php
            while (($line = fgetcsv($handle)) !== false) {
                $line = array_map('trim', $line);

                if (count($line) < count($headers)) {
                    continue; // skip malformed rows
                }
    ```
  - **After:**
    ```php
            $skippedRows = 0;

            while (($line = fgetcsv($handle)) !== false) {
                $line = array_map('trim', $line);

                if (count($line) < count($headers)) {
                    $skippedRows++;

                    continue;
                }
    ```
  - Note: `$skippedRows` must be visible to `reconcile()`. Add it to the returned payload by setting `$rows->skippedRows = $skippedRows;` just before `return $rows;` at the end of `parseCsv()`, and include `'skipped_rows' => $rows->skippedRows ?? 0,` in the `bank_statement_json` array in `reconcile()` (line 96-101). Both edits are in the same service file.
  - **Before** (`PaymentReconciliationService.php:192`):
    ```php
            return $rows;
        }
    ```
  - **After:**
    ```php
            $rows->skippedRows = $skippedRows;

            return $rows;
        }
    ```
  - **Verify:** `grep -n "skippedRows\|skip malformed rows" Modules/Payment/app/Services/PaymentReconciliationService.php`
  - **Expect:** `$skippedRows = 0;`, `$skippedRows++;`, and `$rows->skippedRows = $skippedRows;` lines.
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **PRC-04** · M · AUTH-01 · `Modules/Payment/resources/views/reconciliation/index.blade.php:8-10` and `show.blade.php:13-15` — gate the Upload and Resolve controls with `@can` so a user without the permission no longer sees a control that 403s.
  - **Touches:** `Modules/Payment/resources/views/reconciliation/index.blade.php`, `Modules/Payment/resources/views/reconciliation/show.blade.php`
  - **Before** (`index.blade.php:8-10`):
    ```blade
            <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#uploadModal">
                <i class="fas fa-upload"></i> Upload Settlement CSV
            </button>
    ```
  - **After:**
    ```blade
            @can('tenant.payment.reconciliation.create')
                <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#uploadModal">
                    <i class="fas fa-upload"></i> Upload Settlement CSV
                </button>
            @endcan
    ```
  - **Before** (`show.blade.php:13-15`):
    ```blade
                        <button class="btn btn-sm btn-info" onclick="return confirm('Mark as resolved?')">
                            <i class="fas fa-check-circle"></i> Resolve
                        </button>
    ```
  - **After:**
    ```blade
                        @can('tenant.payment.reconciliation.resolve')
                            <button class="btn btn-sm btn-info" onclick="return confirm('Mark as resolved?')">
                                <i class="fas fa-check-circle"></i> Resolve
                            </button>
                        @endcan
    ```
  - **Verify:** `grep -n "@can" Modules/Payment/resources/views/reconciliation/index.blade.php Modules/Payment/resources/views/reconciliation/show.blade.php`
  - **Expect:** two matches — one `.create` gate and one `.resolve` gate.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **PRC-05** · M · VAL-02 · `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:73-81` — move validation into a FormRequest and authorize there (AUTH-04: authorize once).
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`, `Modules/Payment/app/Http/Requests/StorePaymentReconciliationRequest.php` (new file)
  - **Before** (`PaymentReconciliationController.php:73-81`):
    ```php
        public function store(Request $request): RedirectResponse
        {
            Gate::authorize('tenant.payment.reconciliation.create');

            $validated = $request->validate([
                'gateway_id' => 'required|exists:ptm_payment_gateways,id',
                'file'       => 'required|file|mimes:csv,txt|max:10240',
                'date'       => 'required|date_format:Y-m-d',
            ]);
    ```
  - **After:**
    ```php
        public function store(StorePaymentReconciliationRequest $request): RedirectResponse
        {
            $validated = $request->validated();
    ```
  - **Before** (`PaymentReconciliationController.php:14`, the import):
    ```php
    use Illuminate\Http\Request;
    ```
  - **After:**
    ```php
    use Illuminate\Http\Request;
    use Modules\Payment\Http\Requests\StorePaymentReconciliationRequest;
    ```
  - **Before** (`Modules/Payment/app/Http/Requests/StorePaymentReconciliationRequest.php`): the file does not exist yet.
  - **After** (create `Modules/Payment/app/Http/Requests/StorePaymentReconciliationRequest.php` with exactly this content):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Payment\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;

    class StorePaymentReconciliationRequest extends FormRequest
    {
        /**
         * Authorize first; this runs before validation and before the controller body.
         */
        public function authorize(): bool
        {
            return (bool) $this->user()?->can('tenant.payment.reconciliation.create');
        }

        /**
         * @return array<string, array<int, string>>
         */
        public function rules(): array
        {
            return [
                'gateway_id' => ['required', 'integer', 'exists:ptm_payment_gateways,id'],
                'file'       => ['required', 'file', 'mimes:csv,txt', 'max:10240'],
                'date'       => ['required', 'date_format:Y-m-d'],
            ];
        }
    }
    ```
  - **Verify:** `ls Modules/Payment/app/Http/Requests/StorePaymentReconciliationRequest.php && grep -n "StorePaymentReconciliationRequest" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Expect:** the file exists and two grep matches (the `use` line and the `store()` signature).
  - **Effort:** M

## 6. Queries & performance (F9)

- [ ] **PRC-09** · H · QRY-01 · `Modules/Payment/app/Services/PaymentReconciliationService.php:54-58` (with `matchPayment` at `:198-211`) — pre-fetch the matching payments once instead of one query per CSV row.
  - **Touches:** `Modules/Payment/app/Services/PaymentReconciliationService.php`
  - **Before** (`PaymentReconciliationService.php:54-58`):
    ```php
                foreach ($rows as $row) {
                    $expectedTotal += $row['amount'];

                    $payment = $this->matchPayment($row);
                    $matchStatus = $this->determineMatchStatus($payment, $row);
    ```
  - **After:**
    ```php
                $paymentIds = $rows->pluck('gateway_payment_id')->filter()->unique()->values();
                $orderIds   = $rows->pluck('gateway_order_id')->filter()->unique()->values();

                $payments = Payment::query()
                    ->whereIn('gateway_payment_id', $paymentIds)
                    ->orWhereIn('gateway_order_id', $orderIds)
                    ->get();

                $byPaymentId = $payments->keyBy('gateway_payment_id');
                $byOrderId   = $payments->keyBy('gateway_order_id');

                foreach ($rows as $row) {
                    $expectedTotal += $row['amount'];

                    $payment = $this->matchPayment($row, $byPaymentId, $byOrderId);
                    $matchStatus = $this->determineMatchStatus($payment, $row);
    ```
  - **Before** (`PaymentReconciliationService.php:198-211`):
    ```php
        public function matchPayment(array $row): ?Payment
        {
            $query = Payment::query();

            if (! empty($row['gateway_payment_id'])) {
                $query->where('gateway_payment_id', $row['gateway_payment_id']);
            } elseif (! empty($row['gateway_order_id'])) {
                $query->where('gateway_order_id', $row['gateway_order_id']);
            } else {
                return null;
            }

            return $query->first();
        }
    ```
  - **After:**
    ```php
        public function matchPayment(array $row, Collection $byPaymentId, Collection $byOrderId): ?Payment
        {
            if (! empty($row['gateway_payment_id'])) {
                return $byPaymentId->get($row['gateway_payment_id']);
            }

            if (! empty($row['gateway_order_id'])) {
                return $byOrderId->get($row['gateway_order_id']);
            }

            return null;
        }
    ```
  - Note: `use Illuminate\Support\Collection;` is already imported (service line 8). `matchPayment()` has no caller outside this service (`grep -rn "matchPayment" Modules` shows only the definition and the call at line 57).
  - **Verify:** `grep -n "matchPayment\|byPaymentId" Modules/Payment/app/Services/PaymentReconciliationService.php`
  - **Expect:** the new `$byPaymentId`/`$byOrderId` lines and the updated signature.
  - **Effort:** M

- [ ] **PRC-10** · M · QRY-07 · `Modules/Payment/app/Services/PaymentReconciliationService.php:48-52,70-85,88-89` — buffer the line rows and bulk-insert them in batches instead of one INSERT per row.
  - **Touches:** `Modules/Payment/app/Services/PaymentReconciliationService.php`
  - **Before** (`PaymentReconciliationService.php:48-52`):
    ```php
                $expectedTotal = 0;
                $settledTotal  = 0;
                $matchedCount  = 0;
                $unmatchedCount = 0;
                $mismatchCount  = 0;
    ```
  - **After:**
    ```php
                $expectedTotal = 0;
                $settledTotal  = 0;
                $matchedCount  = 0;
                $unmatchedCount = 0;
                $mismatchCount  = 0;
                $lineRows      = [];
    ```
  - **Before** (`PaymentReconciliationService.php:70-85`):
    ```php
                    if (! $dryRun) {
                        PaymentReconciliationLine::create([
                            'reconciliation_id'  => $recon->id,
                            'gateway_payment_id' => $row['gateway_payment_id'],
                            'gateway_order_id'   => $row['gateway_order_id'],
                            'transaction_date'   => $row['transaction_date'],
                            'amount'             => $row['amount'],
                            'fee'                => $row['fee'],
                            'net_amount'         => $row['net_amount'],
                            'matched_payment_id' => $payment?->id,
                            'match_status'       => $matchStatus,
                            'notes'              => $this->buildNotes($payment, $row),
                            'is_active'          => true,
                            'created_by'         => $this->getUserId(),
                        ]);
                    }
    ```
  - **After:**
    ```php
                    if (! $dryRun) {
                        $lineRows[] = [
                            'reconciliation_id'  => $recon->id,
                            'gateway_payment_id' => $row['gateway_payment_id'],
                            'gateway_order_id'   => $row['gateway_order_id'],
                            'transaction_date'   => $row['transaction_date'],
                            'amount'             => $row['amount'],
                            'fee'                => $row['fee'],
                            'net_amount'         => $row['net_amount'],
                            'matched_payment_id' => $payment?->id,
                            'match_status'       => $matchStatus,
                            'notes'              => $this->buildNotes($payment, $row),
                            'is_active'          => true,
                            'created_by'         => $this->getUserId(),
                            'created_at'         => now(),
                            'updated_at'         => now(),
                        ];
                    }
    ```
  - **Before** (`PaymentReconciliationService.php:88-89`):
    ```php
                if (! $dryRun) {
                    $recon->update([
    ```
  - **After:**
    ```php
                if (! $dryRun && $lineRows !== []) {
                    foreach (array_chunk($lineRows, 500) as $chunk) {
                        PaymentReconciliationLine::insert($chunk);
                    }
                }

                if (! $dryRun) {
                    $recon->update([
    ```
  - **Verify:** `grep -n "PaymentReconciliationLine::insert\|lineRows" Modules/Payment/app/Services/PaymentReconciliationService.php`
  - **Expect:** `$lineRows      = [];`, `$lineRows[] = [`, and `PaymentReconciliationLine::insert($chunk);`.
  - **Effort:** M

- [ ] **PRC-12** · M · QRY-05 · `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:54-59` — let the database count the lines instead of materialising the collection and counting in PHP.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Before** (`PaymentReconciliationController.php:54-59`):
    ```php
            $summary = [
                'total'     => $reconciliation->lines->count(),
                'matched'   => $reconciliation->lines->where('match_status', 'matched')->count(),
                'unmatched' => $reconciliation->lines->where('match_status', 'unmatched')->count(),
                'mismatch'  => $reconciliation->lines->where('match_status', 'amount_mismatch')->count(),
            ];
    ```
  - **After:**
    ```php
            $statusCounts = $reconciliation->lines()
                ->selectRaw('match_status, count(*) as aggregate')
                ->groupBy('match_status')
                ->pluck('aggregate', 'match_status');

            $summary = [
                'total'     => (int) $statusCounts->sum(),
                'matched'   => (int) ($statusCounts['matched'] ?? 0),
                'unmatched' => (int) ($statusCounts['unmatched'] ?? 0),
                'mismatch'  => (int) ($statusCounts['amount_mismatch'] ?? 0),
            ];
    ```
  - **Verify:** `grep -n "statusCounts" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Expect:** the `$statusCounts = $reconciliation->lines()` assignment and four `$statusCounts[...]` reads.
  - **Effort:** S

- [ ] **PRC-13** · M · QRY-13 · `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:35-37` — paginate at the house standard of 10 with a distinct page name.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Before** (`PaymentReconciliationController.php:35-37`):
    ```php
            $reconciliations = PaymentReconciliation::with('gateway')
                ->latest()
                ->paginate(20);
    ```
  - **After:**
    ```php
            $reconciliations = PaymentReconciliation::with('gateway')
                ->latest()
                ->paginate(10, ['*'], 'reconciliationPage')
                ->withQueryString();
    ```
  - **Verify:** `grep -n "paginate" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Expect:** `->paginate(10, ['*'], 'reconciliationPage')`.
  - **Effort:** S

- [ ] **PRC-08** · M · CTL-02 · `Modules/Payment/app/Services/PaymentReconciliationService.php:27-132` — `reconcile()` is 106 lines; extract the per-row persistence and the tally so the method reads as parse → match → persist → summarise.
  - **Touches:** `Modules/Payment/app/Services/PaymentReconciliationService.php`
  - **Before** (`PaymentReconciliationService.php:70-85`):
    ```php
                    if (! $dryRun) {
                        PaymentReconciliationLine::create([
                            'reconciliation_id'  => $recon->id,
                            'gateway_payment_id' => $row['gateway_payment_id'],
                            'gateway_order_id'   => $row['gateway_order_id'],
                            'transaction_date'   => $row['transaction_date'],
                            'amount'             => $row['amount'],
                            'fee'                => $row['fee'],
                            'net_amount'         => $row['net_amount'],
                            'matched_payment_id' => $payment?->id,
                            'match_status'       => $matchStatus,
                            'notes'              => $this->buildNotes($payment, $row),
                            'is_active'          => true,
                            'created_by'         => $this->getUserId(),
                        ]);
                    }
    ```
  - **After:** (extract this block into a private helper and keep the loop body short; the helper below is the extracted form of the block above and is called from the loop):
    ```php
                    if (! $dryRun) {
                        $lineRows[] = $this->buildLineRow($recon, $row, $payment, $matchStatus);
                    }
    ```
  - And add this private method next to `buildNotes()`:
    ```php
        /**
         * Build one ptm_reconciliation_lines row for a bulk insert.
         *
         * @param  array<string, mixed>  $row
         * @return array<string, mixed>
         */
        private function buildLineRow(PaymentReconciliation $recon, array $row, ?Payment $payment, string $matchStatus): array
        {
            return [
                'reconciliation_id'  => $recon->id,
                'gateway_payment_id' => $row['gateway_payment_id'],
                'gateway_order_id'   => $row['gateway_order_id'],
                'transaction_date'   => $row['transaction_date'],
                'amount'             => $row['amount'],
                'fee'                => $row['fee'],
                'net_amount'         => $row['net_amount'],
                'matched_payment_id' => $payment?->id,
                'match_status'       => $matchStatus,
                'notes'              => $this->buildNotes($payment, $row),
                'is_active'          => true,
                'created_by'         => $this->getUserId(),
                'created_at'         => now(),
                'updated_at'         => now(),
            ];
        }
    ```
  - Note: PRC-10 and PRC-08 touch the same loop block. Apply PRC-10 first; this item then inherits the `$lineRows[] = …` form. If PRC-10 is not ticked, apply this item's Before against the current `create([…])` block and produce the same helper with `create()` replaced by the array append minus the `created_at`/`updated_at` keys.
  - **Verify:** `grep -n "buildLineRow" Modules/Payment/app/Services/PaymentReconciliationService.php`
  - **Expect:** the private method definition and one call site in the loop.
  - **Effort:** M

## 7. Views (F10)

- [ ] **PRC-15** · H · VIEW-01 · `Modules/Payment/resources/views/reconciliation/index.blade.php:91` (with `PaymentReconciliationController::index`) — move the gateway query out of the template into the controller.
  - **Touches:** `Modules/Payment/resources/views/reconciliation/index.blade.php`, `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Before** (`PaymentReconciliationController.php:38-39`):
    ```php

            return view('payment::reconciliation.index', compact('reconciliations'));
    ```
  - **After:**
    ```php

            $gateways = PaymentGateway::where('is_active', true)->pluck('name', 'id');

            return view('payment::reconciliation.index', compact('reconciliations', 'gateways'));
    ```
  - **Before** (`index.blade.php:91`):
    ```blade
                                @foreach(\Modules\Payment\Models\PaymentGateway::where('is_active', true)->get() as $gw)
    ```
  - **After:**
    ```blade
                                @foreach($gateways as $gwId => $gwName)
    ```
  - **Before** (`index.blade.php:92`):
    ```blade
                                    <option value="{{ $gw->id }}">{{ $gw->name }} ({{ $gw->code }})</option>
    ```
  - **After:**
    ```blade
                                    <option value="{{ $gwId }}">{{ $gwName }}</option>
    ```
  - **Verify:** `grep -n "PaymentGateway::" Modules/Payment/resources/views/reconciliation/index.blade.php`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **PRC-16** · M · UI-STD · `Modules/Payment/resources/views/reconciliation/index.blade.php:61-64` — replace the hand-rolled row action with the standard table-action component.
  - **Touches:** `Modules/Payment/resources/views/reconciliation/index.blade.php`
  - **Before** (`index.blade.php:61-64`):
    ```blade
                                        <td>
                                            <a href="{{ route('payment.reconciliation.show', $recon->id) }}"
                                               class="btn btn-sm btn-outline-primary">View</a>
                                        </td>
    ```
  - **After:**
    ```blade
                                        <td>
                                            <x-backend.table.action
                                                :model="$recon"
                                                :viewRoute="route('payment.payment.reconciliation.show', $recon->id)" />
                                        </td>
    ```
  - Note: PRC-06 also edits lines 62-63 of this file. Apply PRC-06 first; this item's After already carries the registered (double-prefixed) route name, so the two do not conflict — whichever runs second, the final line names `payment.payment.reconciliation.show`.
  - **Verify:** `grep -n "x-backend.table.action" Modules/Payment/resources/views/reconciliation/index.blade.php`
  - **Expect:** one match.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **PRC-17** · L · STY-02 · `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:7-20` — replace the import block with a sorted, contiguous one (Pint-clean).
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Before** (`PaymentReconciliationController.php:7-20`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;

    use Illuminate\Support\Facades\Log;

    use Illuminate\Support\Facades\DB;

    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\Payment\Models\PaymentGateway;
    use Modules\Payment\Models\PaymentReconciliation;
    use Modules\Payment\Services\PaymentReconciliationService;
    ```
  - **After:**
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    use Modules\Payment\Http\Requests\StorePaymentReconciliationRequest;
    use Modules\Payment\Models\PaymentGateway;
    use Modules\Payment\Models\PaymentReconciliation;
    use Modules\Payment\Services\PaymentReconciliationService;
    ```
  - Note: `ModelNotFoundException` and `Log` become unused if PRC-01 is ticked. Remove them in that case (`Log` is unused after PRC-01; `ModelNotFoundException` is unused after PRC-01). If PRC-05 is ticked, keep the `StorePaymentReconciliationRequest` line; otherwise drop it. Re-measure before editing.
  - **Verify:** `sed -n '1,16p' Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php`
  - **Expect:** contiguous `use` lines with no blank line between them.
  - **Effort:** S

- [ ] **PRC-18** · L · CTL-10 · `Modules/Payment/app/Models/PaymentReconciliation.php:81-84` — delete the never-called `computeDiscrepancy()` method.
  - **Touches:** `Modules/Payment/app/Models/PaymentReconciliation.php`
  - **Before** (`PaymentReconciliation.php:77-85`):
    ```php
        /**
         * Compute discrepancy in PHP — NOT a DB computed column.
         * Call this before saving to keep the column in sync.
         */
        public function computeDiscrepancy(): void
        {
            $this->discrepancy = round($this->expected_amount - $this->settled_amount, 2);
        }
    }
    ```
  - **After:**
    ```php
    }
    ```
  - **Verify:** `grep -rn "computeDiscrepancy" Modules/Payment`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **PRC-07** · M · DECISION · CTL-03 — adopt route model binding for `show()` and `resolve()`?
  - **Why it is a decision:** route model binding needs the route parameter renamed from `{id}` to `{reconciliation}` in the shared route file `Modules/Payment/routes/web.php` (lines 34 and 37), and the shared route file is out of bounds for a normal fix (final-audit.md §9.3).
  - (a) ⭐ Keep `int $id` + `findOrFail` for now (D3 fix-in-place; the 404 behaviour is already correct) and record CTL-03 as accepted.
  - (b) Rename the two route parameters to `{reconciliation}` and type-hint `PaymentReconciliation $reconciliation` in `show()`/`resolve()`; this touches the shared route file and needs its own tick.
  - (c) Defer to a module-wide Payment route pass.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PRC-02 | The two `Log::error(..., ['error' => $e->getMessage()])` calls exist only inside the try/catch that PRC-01 deletes. Applying PRC-01 removes them and the failure flows to the central handler, which logs the exception object itself. No separate edit is required. |
