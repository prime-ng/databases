# Payment — Module Audit Summary

Protocol: `.claude/rules/final-audit.md` §13.2 · Reviewer: `tarun` · Agent: `opencode`
Date: 2026-10-19 · Controllers: **9 / 9 `AUDITED`**
Reports: `final-audit-reports/tarun/Payment-done/<Controller>/01-report.md` + `02-fix-plan.md`

> Note on folder names: the four controllers under `app/Http/Controllers/Backend/` are named with a
> `Backend` prefix (`BackendPaymentController`, …) to disambiguate them from the top-level controllers
> of the same class name.

## 1. Per-controller results

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---:|---:|---:|---:|---:|---|---|---|
| PaymentController | 130 | 1 | 1 | 4 | 4 | 3 | `show()` returns the whole `Payment` graph including `gateway.credentials` (encrypted array, no `$hidden`), so merchant keys/webhook secrets are decrypted to the caller (PAY-08, SEC-02). | [01-report.md](PaymentController/01-report.md) |
| RefundController | 76 | 3 | 3 | 3 | 13 | 0 | The gateway HTTP refund call runs inside `DB::transaction`, so a post-call failure rolls back the local refund while the money has already left the gateway (RFD-02). | [01-report.md](RefundController/01-report.md) |
| WebhookController | 147 | 0 | 2 | 9 | 2 | 4 | The idempotency key uses the Razorpay *payment* id, so two different events for one payment collide on the unique index and the replay is answered HTTP 500 instead of an idempotent 200 (WHK-05/WHK-06). | [01-report.md](WebhookController/01-report.md) |
| BackendPaymentController | 52 | 2 | 1 | 3 | 3 | 3 | Both pages `@extends('prime::layouts.master')`, which does not resolve, so the list/detail 500 before rendering (BPA-01); `payment.backend.*` route names are also unregistered (BPA-02). | [01-report.md](BackendPaymentController/01-report.md) |
| BackendReceiptController | 41 | 0 | 0 | 2 | 2 | 1 | `show()` never checks payment status, so a hand-edited URL yields a "Payment Receipt / Amount Paid" PDF for a failed or pending payment (BRC-02). | [01-report.md](BackendReceiptController/01-report.md) |
| BackendRefundController | 43 | 1 | 0 | 2 | 3 | 1 | `GET /payment/refunds` 500s on every load because `refunds/index.blade.php` extends the missing `prime::layouts.master` (BRF-01, VIEW-04). | [01-report.md](BackendRefundController/01-report.md) |
| BackendWebhookController | 27 | 1 | 0 | 2 | 1 | 2 | The webhook list 500s on the missing layout (BWH-01) and is gated on the unrelated `tenant.payment.reconciliation.viewAny` permission (BWH-02). | [01-report.md](BackendWebhookController/01-report.md) |
| PaymentReconciliationController | 149 | 2 | 3 | 11 | 2 | 2 | Every `route('payment.reconciliation.*')` names an unregistered route (real names are `payment.payment.reconciliation.*`), so the modal, row links, back link, upload redirect and resolve flow all throw (PRC-06, RTE-02); both views also 500 on the missing layout (PRC-14). | [01-report.md](PaymentReconciliationController/01-report.md) |
| PaymentGatewayController | 367 | 0 | 3 | 6 | 8 | 5 | `edit.blade.php` prints the tenant's decrypted gateway API key / secret / webhook secret into the page HTML for any School Admin (PGC-15, SEC-02). | [01-report.md](PaymentGatewayController/01-report.md) |

## 2. Module totals

| B | H | M | L | Total findings | DECISIONs |
|---:|---:|---:|---:|---:|---:|
| 10 | 13 | 42 | 38 | **103** | **21** |

Rule-ID frequency across all findings:

| Rule | Count | Meaning | Rule | Count | Meaning |
|---|---:|---|---|---:|---|
| STY-02 | 14 | naming / casing style | ERR-00 | 4 | controller `try/catch` (D1 forbids) |
| STY-04 | 5 | comment hygiene / commented-out code | RTE-02 | 3 | route → method/name that does not exist (B) |
| VIEW-04 | 4 | broken view / layout that does not resolve | QRY-02 | 3 | unbounded list read |
| TXN-06 | 4 | (transaction family) | CTL-10 | 3 | dead code |
| SEC-02 | 4 | sensitive data exposed (secrets in JSON/form) | CTL-03 | 3 | no route model binding |
| QRY-13 | 4 | (query family) | AUTH-06 | 3 | Policy never consulted / wrong key |
| TXN-05 | 2 | response built inside the transaction | AUTH-01 | 2 | routed method does not authorize (B) |
| TXN-04 | 2 | `activityLog()` placement/event literal lies | AUTH-02 | 2 | authorize after loading records |
| ERR-06 | 2 | (error-handling family) | STY-01 | 2 | missing `declare(strict_types=1)` |
| ERR-05 | 2 | `getMessage()` in a log loses the trace | | | |

## 3. Cross-controller families (fix once, module-wide)

| # | Family | Rule | Controllers |
|---|---|---|---|
| P1 | **Broken shared layout `prime::layouts.master`** — it does not exist; the real name is `prime::components.layouts.master`. Six Payment views extend it and 500 on load: `payments/index`, `payments/show`, `reconciliation/index`, `reconciliation/show`, `refunds/index`, `webhooks/index`. | VIEW-04 (B) | BackendPayment (BPA-01), BackendRefund (BRF-01), BackendWebhook (BWH-01), PaymentReconciliation (PRC-14) — one DECISION each |
| P2 | **Unregistered route names** — `route('payment.backend.*')` and `route('payment.reconciliation.*')` are called but only `payment.payment.reconciliation.*` is registered; links throw and flows roll back. | RTE-02 (B) | BackendPayment (BPA-02), PaymentReconciliation (PRC-06) |
| P3 | **Controller `try/catch`** the settled D1 idiom forbids (the house "Rule A1" comments are superseded by D1). | ERR-00 | Webhook (WHK), PaymentReconciliation (PRC), PaymentGateway (PGC) |
| P4 | **`redirect()`/`response()` built inside `DB::transaction`** | TXN-05 | PaymentReconciliation (PRC), PaymentGateway (PGC) |
| P5 | **HTTP gateway call inside `DB::transaction`** — rollback after money moved at the gateway. | TXN-06 | RefundService (RFD-02); also PaymentService (already PFPC-05 in the ParentPortal report) |
| P6 | **Load-then-authorize** — `firstOrFail()`/`findOrFail()` before `Gate::authorize`, leaking 404-vs-403 and existence. | AUTH-02 | BackendPayment (BPA), BackendReceipt (BRC-01) |
| P7 | **Secrets exposed** — encrypted `credentials` on `PaymentGateway` sent in API JSON and prefilled in the edit form. | SEC-02 | Payment (PAY-08), PaymentGateway (PGC-15) |
| P8 | **List gated on an unrelated permission** — webhook list uses `reconciliation.viewAny`; refund list uses `payment.viewAny`; no dedicated keys exist. | AUTH-05/06 | BackendWebhook (BWH-02), BackendRefund (BRF) |
| P9 | **Pagination not at the house standard of 10** with a distinct `pageName` (pages use 15 or 20, some without a pageName). | QRY-02 / C12 | BackendPayment, BackendRefund, BackendWebhook, PaymentReconciliation, PaymentGateway |
| P10 | **Registered Policy bypassed by bare permission strings** (`Gate::authorize('tenant.payment.gateway.*')` never reaches `PaymentGatewayPolicy`; `PaymentPolicy` likewise). | AUTH-06 | PaymentGateway (PGC-05), Payment (PAY), plus Refund/Backend |

## 4. Shared classes and their owner reports

Canonical registry: `final-audit-reports/00-CLASS-OWNERS.md` (append-only).

| Class | Owner report |
|---|---|
| `Payment.php`, `PaymentGateway.php`, `PaymentAuditLog.php` | `tarun/ParentPortal-done/ParentFeePaymentController` |
| `PaymentService.php`, `GatewayManager.php`, `AuditService.php` | `tarun/ParentPortal-done/ParentFeePaymentController` |
| `DTO/PaymentData.php`, `Contracts/Payable.php`, `Contracts/PaymentGatewayInterface.php` | `tarun/ParentPortal-done/ParentFeePaymentController` |
| `Gateways/RazorpayGateway.php`, `Gateways/BaseGateway.php` | `tarun/ParentPortal-done/ParentFeePaymentController` |
| `Events/PaymentInitiated|Succeeded|Failed.php` + their listeners | `tarun/ParentPortal-done/ParentFeePaymentController` |

Owned **within this module audit** (first Payment-module controller to reach them):

| Class | Owner report |
|---|---|
| `Models/OfflinePaymentRecord.php`, `Policies/PaymentPolicy.php`, `Gateways/BillDesk|CCAvenue|Offline|Paytm|PhonePe.php`, `Events/PaymentCancelled.php`, `Listeners/PaymentCancelledListener.php` | PaymentController |
| `Models/PaymentRefund.php`, `Services/RefundService.php`, `Events/Refund*.php`, `Listeners/Refund*Listener.php` | RefundController |
| `Models/PaymentWebhook.php`, `Jobs/ProcessWebhookJob.php`, `Events/WebhookReceived.php`, `Listeners/WebhookReceivedListener.php`, `Http/Middleware/VerifyWebhookSignature.php` | WebhookController |
| `Models/PaymentReconciliation.php`, `Models/PaymentReconciliationLine.php`, `Services/PaymentReconciliationService.php` | PaymentReconciliationController |
| `Policies/PaymentGatewayPolicy.php` | PaymentGatewayController |
| Views under each controller's own folder | the controller that renders them |

## 5. Decisions that apply module-wide

- **The broken shared layout (P1).** One decision fixes four reports and six pages: change every
  `@extends('prime::layouts.master')` to `prime::components.layouts.master` (or the correct Payment
  layout). Marked `⚠ SHARED`; it touches files owned by four controller folders.
- **Route-name mismatches (P2).** One decision on the canonical names; the routes are registered by
  `RouteServiceProvider`/`routes/web.php`, so this is a shared route-file edit.
- **Permissions for the webhook and refund lists (P8).** Either add dedicated keys
  (`tenant.payment.webhook.viewAny`, `tenant.payment.refund.viewAny`) — a DECISION + Tarun's
  `/system-config/sync-permissions` — or accept the current keys. Do not invent keys in the fixer.
- **Policy vs. string gates (P10).** Module-wide: make `PaymentPolicy`/`PaymentGatewayPolicy`
  reachable, or delete the registrations. Editing `PaymentServiceProvider` is a shared change.
- **Secrets handling (P7).** One decision covers both leaks (API JSON and the edit form prefill):
  hide `credentials`, or send a masked sentinel. Touches the model (`$hidden`) and two views.
- **HTTP-inside-transaction (P5).** Same defect as the ParentPortal report's PFPC-05, in
  `RefundService`. Sequence so the service fix lands with or after the ParentPortal one (they touch
  sibling services in the same module).

## 6. Notes for the fixer runs

- Module mode is **complete**: all 9 index rows are `AUDITED`. The main session will not
  self-dispatch another module — Tarun picks the next one.
- Every report passed `_tools/selfcheck.py` (shape + quoted-code existence). Quoted code is real;
  reasoning still follows §1.5/§1.5.1.
- Approval is tick-boxes plus a filled `➜ Choice:` on every DECISION (D8); items marked `⚠ SHARED`
  must be ticked explicitly. Tick, then run `final-audit-fixer` on that controller path.
- When a controller reaches `FIXED`, rename its folder to `<Controller>-done` (§10.1) and repoint
  every link.
