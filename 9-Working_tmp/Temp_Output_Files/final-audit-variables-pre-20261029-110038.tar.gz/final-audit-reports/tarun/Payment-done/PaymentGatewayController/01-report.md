# Final Audit — Payment / PaymentGatewayController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php` (367 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /payment/payment-gateway?tab=payment-gateway` (list) · `GET /payment/payment-gateway?tab=payment-history` (list) · `GET /payment/payment-gateway/create` · `GET /payment/payment-gateway/{id}` (show) · `GET /payment/payment-gateway/{id}/edit` · `GET /payment/payment-gateway/trash/view` · `POST /payment/payment-gateway` · `PUT /payment/payment-gateway/{id}` · `DELETE /payment/payment-gateway/{id}` · `GET /payment/payment-gateway/{id}/restore` · `DELETE /payment/payment-gateway/{id}/force-delete` · `POST /payment/payment-gateway/{id}/toggle-status` |
| Menu path | Payment → Payment Gateways / Payment History (module-root route `payment.payment-gateway.index`). No `glb_menus` row for this route was found in the repo seeders, so the screen is reached from the Payment menu root and by direct URL. |
| Who uses it | Any role holding `tenant.payment.gateway.viewAny` (list), `.view`, `.create`, `.update`, `.delete`, `.restore`, `.forceDelete` (writes) and `tenant.payment.reconciliation.viewAny` (the History tab). By default that is Super Admin and School Admin. |
| What a user does here | A school admin keeps the list of payment gateways the school can charge through (Razorpay, PhonePe, ...): add one in a modal (name, code, driver class, API key/secret, webhook secret, test/live mode), edit one, toggle it active/inactive, soft-delete ("trash") one, restore it, or permanently delete it. The second tab lists the last payments that went through those gateways. |
| Tables written | `ptm_payment_gateways` (create/update/soft-delete/restore/force-delete/toggle) and `sys_activity_logs` (one row per mutation, via the `activityLog()` helper). |
| Tables read | `ptm_payment_gateways`, `ptm_payment_payments` (the History tab). |
| Live data | tenant `00000000-0000-4000-8000-000000000001`: `ptm_payment_gateways` 6 rows (0 trashed), of which RAZORPAY (online) and OFFLINE (offline) are the two active rows; `ptm_payment_payments` 60 rows. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**. Most findings are static-only (they need a logged-in School Admin session on a tenant domain, which this audit does not open, per D4).

## 1. Verdict

Not production-ready. The screen is fully wired and the list/edit paths work, but three defects are reachable today: the edit form prints the school's decrypted gateway secrets (API secret, webhook secret) into the page source (PGC-15, High); the "restore" action is a `GET` link, so any page that embeds an image tag to that URL can restore a trashed gateway with no CSRF token (PGC-08, High); and the "only one active gateway per type" rule is enforced only in a non-atomic form hook, so restore/toggle can silently create a second active gateway of a type while the payment router picks one by priority (PGC-04, High). On top of those, every one of the six mutating methods wraps its body in a redundant `try/catch` (ERR-00, D1) and returns its response from inside the transaction (TXN-05) — both are mechanical rewrites of the same six methods, billed once. The controller itself is small (367 lines, 11 methods), so the fix is bounded: a small-to-medium pass (roughly S/M, half a day), with five items held as decisions for Tarun. The single worst finding is PGC-15.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 3 | 6 | 8 | 5 | 17 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PGC-01 | F8 Services/Jobs | n/a — no service or job |
| F2 Transactions/Audit | PGC-02, PGC-03, PGC-04 | F9 Queries/Perf | PGC-11, PGC-12, PGC-13 |
| F3 Authorization | PGC-05, PGC-06, PGC-07 | F10 Views | PGC-14 |
| F4 Validation | clean (the one-active rule is PGC-04) | F11 Security/Tenancy | PGC-15 |
| F5 Routes | PGC-08 | F12 Style | PGC-16, PGC-17 |
| F6 Controller shape | PGC-09, PGC-10 | F13 Deep read | see the F13 table under §6 |
| F7 Models | clean — no model owned here (both linked) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php` | controller | 367 | this report | ✅ |
| 2 | `Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php` | FormRequest | 98 | this report | ✅ |
| 3 | `Modules/Payment/app/Policies/PaymentGatewayPolicy.php` | policy | 46 | this report | ✅ |
| 4 | `Modules/Payment/resources/views/index.blade.php` | view | 23 | this report | ✅ |
| 5 | `Modules/Payment/resources/views/payment-gateway/index.blade.php` | view (partial) | 235 | this report | ✅ |
| 6 | `Modules/Payment/resources/views/payment-gateway/create.blade.php` | view | 143 | this report | ✅ |
| 7 | `Modules/Payment/resources/views/payment-gateway/edit.blade.php` | view | 146 | this report | ✅ |
| 8 | `Modules/Payment/resources/views/payment-gateway/show.blade.php` | view | 86 | this report | ✅ |
| 9 | `Modules/Payment/resources/views/payment-gateway/trash.blade.php` | view | 104 | this report | ✅ |
| 10 | `Modules/Payment/resources/views/partials/payment-history.blade.php` | view (partial) | 146 | this report | ✅ |
| 11 | `Modules/Payment/routes/web.php` | route file | 40 | common (§4.2) — read to resolve the routes; any change is a SHARED decision (PGC-07, PGC-08) | ❌ not audited here |
| 12 | `Modules/Payment/app/Models/PaymentGateway.php` | model | 76 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 13 | `Modules/Payment/app/Models/Payment.php` | model | 101 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 14 | `Modules/Payment/app/Providers/PaymentServiceProvider.php` | provider | 212 | common module glue (§4.2) — inspected to confirm the policy registration at line 42 | ❌ inspected only |
| 15 | `config/permissionslist.php` | config | 1764 | common (§4.2) — read to confirm the permission keys; any change is SHARED | ❌ inspected only |
| 16 | `app/Helpers/activityLog.php`, `app/Helpers/helpers.php` | helper | — | common (app glue, §4.2) | ❌ inspected only |

The linked models are owned by `tarun/ParentPortal-done/ParentFeePaymentController` and are **not re-audited** here; this report only checks how the controller uses them. The blade files used only by this controller are claimed in `00-CLASS-OWNERS.md` (append-only). No pre-applied files.

## 4. Routes

```
GET|HEAD payment/payment-gateway                                 payment.payment-gateway.index                      Modules\Payment\Http\Controllers\PaymentGatewayController@index
POST    payment/payment-gateway                                 payment.payment-gateway.store                      Modules\Payment\Http\Controllers\PaymentGatewayController@store
GET|HEAD payment/payment-gateway/create                          payment.payment-gateway.create                     Modules\Payment\Http\Controllers\PaymentGatewayController@create
GET|HEAD payment/payment-gateway/trash/view                      payment.payment-gateway.trashed                    Modules\Payment\Http\Controllers\PaymentGatewayController@trashedPaymentGateways
DELETE  payment/payment-gateway/{id}/force-delete               payment.payment-gateway.forceDelete                Modules\Payment\Http\Controllers\PaymentGatewayController@forceDelete
GET|HEAD payment/payment-gateway/{id}/restore                    payment.payment-gateway.restore                    Modules\Payment\Http\Controllers\PaymentGatewayController@restore
GET|HEAD payment/payment-gateway/{payment_gateway}               payment.payment-gateway.show                       Modules\Payment\Http\Controllers\PaymentGatewayController@show
PUT|PATCH payment/payment-gateway/{payment_gateway}               payment.payment-gateway.update                     Modules\Payment\Http\Controllers\PaymentGatewayController@update
DELETE  payment/payment-gateway/{payment_gateway}               payment.payment-gateway.destroy                    Modules\Payment\Http\Controllers\PaymentGatewayController@destroy
GET|HEAD payment/payment-gateway/{payment_gateway}/edit          payment.payment-gateway.edit                       Modules\Payment\Http\Controllers\PaymentGatewayController@edit
POST    payment/payment-gateway/{payment_gateway}/toggle-status payment.payment-gateway.toggleStatus               Modules\Payment\Http\Controllers\PaymentGatewayController@toggleStatus
```

Unrouted public methods: none — all 11 public methods are routed. The custom routes are declared **before** `Route::resource` (RTE-06 ✅). All routes sit in the module's `mapWebRoutes()` group (`web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Payment`, `auth`, `verified`) — tenancy middleware present (RTE-05 ✅). Note the parameter-name split: `restore`/`forceDelete` use `{id}` while the resource and `toggleStatus` use `{payment_gateway}` (see PGC-09).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 32 | GET /payment/payment-gateway | `tenant.payment.gateway.viewAny` | n/a (read) | n/a | none | PGC-11, PGC-12, PGC-13 |
| `create` | 79 | GET /payment/payment-gateway/create | `tenant.payment.gateway.create` | n/a (read) | n/a | none | — |
| `store` | 88 | POST /payment/payment-gateway | `tenant.payment.gateway.create` (+ FormRequest `create`) | controller | 'Stored' (after write, inside tx) | ptm_payment_gateways, sys_activity_logs | PGC-01, PGC-02, PGC-04, PGC-07 |
| `show` | 129 | GET /payment/payment-gateway/{payment_gateway} | `tenant.payment.gateway.view` | n/a (read) | n/a | none | PGC-09, PGC-10 |
| `edit` | 138 | GET /payment/payment-gateway/{payment_gateway}/edit | `tenant.payment.gateway.update` | n/a (read) | n/a | none | PGC-09, PGC-10, PGC-15 |
| `update` | 148 | PUT /payment/payment-gateway/{payment_gateway} | `tenant.payment.gateway.update` (+ FormRequest `update`) | controller | 'Updated' (after write, inside tx) | ptm_payment_gateways, sys_activity_logs | PGC-01, PGC-02, PGC-04, PGC-07 |
| `destroy` | 205 | DELETE /payment/payment-gateway/{payment_gateway} | `tenant.payment.gateway.delete` | controller | 'Trashed' (after write, inside tx) | ptm_payment_gateways, sys_activity_logs | PGC-01, PGC-02, PGC-09 |
| `trashedPaymentGateways` | 239 | GET /payment/payment-gateway/trash/view | `tenant.payment.gateway.restore` (wrong — see PGC-06) | n/a (read) | n/a | none | PGC-06 |
| `restore` | 250 | GET /payment/payment-gateway/{id}/restore | `tenant.payment.gateway.restore` | controller | 'Restored' (after write, inside tx) | ptm_payment_gateways, sys_activity_logs | PGC-01, PGC-02, PGC-04, PGC-08, PGC-09 |
| `forceDelete` | 284 | DELETE /payment/payment-gateway/{id}/force-delete | `tenant.payment.gateway.forceDelete` | controller | 'Deleted' (after write, inside tx) | ptm_payment_gateways, sys_activity_logs | PGC-01, PGC-02, PGC-09 |
| `toggleStatus` | 315 | POST /payment/payment-gateway/{payment_gateway}/toggle-status | `tenant.payment.gateway.update` | controller | 'Toggled' (BEFORE the write — see PGC-03) | ptm_payment_gateways, sys_activity_logs | PGC-01, PGC-02, PGC-03, PGC-04, PGC-07 |

Gate resolution note: the string abilities (`tenant.payment.gateway.*`) are Spatie permission names, resolved by Spatie's `Gate::before` hook (`config/permission.php` `register_permission_check_method` is `true`; `vendor/spatie/laravel-permission/src/PermissionRegistrar.php:123`). Every name used exists: `App\Helpers\PermissionHelper::flatten('tenant')` emits all seven `tenant.payment.gateway.*` names from `config/permissionslist.php:1189` (`'payment.gateway' => $crud`, where `$crud` at line 176 is `create, view, viewAny, update, delete, restore, forceDelete`). The `PaymentGatewayPolicy` is registered (`PaymentServiceProvider.php:42`) but never consulted — see PGC-05.

## 6. Findings

### F1 — Errors

#### PGC-01 · M · ERR-00 — six mutating methods wrap their body in a redundant try/catch

| Field | Value |
|---|---|
| **Rule** | ERR-00 (under D1: **the Laravel idiom wins** — no `try/catch` in a controller; `DB::transaction()` rolls back by itself and the central handler in `bootstrap/app.php` renders) |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:92-126` (`store`), `:152-202` (`update`), `:209-236` (`destroy`), `:254-281` (`restore`), `:288-312` (`forceDelete`), `:319-353` (`toggleStatus`) |
| **Root cause** | Each mutating method wraps `DB::transaction(...)` in `try { ... } catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { Log::error(..., ['error' => $e->getMessage()]); return back()->with('error', ...); }`. Under D1 this is not allowed: the transaction already rolls back and rethrows, and the central handler already logs and renders. The `ModelNotFoundException` rethrow is dead (the transaction never throws it here — there is no `findOrFail` in `store`), and the generic catch swallows every other failure into a generic flash. The log shape is the same root cause viewed once more: ERR-05 — `$e->getMessage()` alone loses the trace. The inline `return back()` in a JSON method is also the ERR-04 symptom (the AJAX toggle caller gets an HTML redirect instead of JSON when the write fails). |
| **Consequence** | A real failure (a DB error, a unique-constraint hit) is turned into "The operation could not be completed." and only its message — not its stack — is logged, so the failure cannot be diagnosed, and the status-toggle AJAX call receives a redirect instead of JSON. |
| **Reproduce** | static only — the shape is visible in the source; triggering it needs a forced DB failure. |
| **Fix approach** | Delete all six `try/catch` blocks; keep `DB::transaction(...)` bare and let the central handler render. Remove the now-unused `ModelNotFoundException` and `Log` imports. This rewrite also builds the response outside the closure (PGC-02). |
| **Plan item** | PGC-01 in `02-fix-plan.md` §3 |

```php
// PaymentGatewayController.php:92-126 — CURRENT (store; update/destroy/restore/forceDelete/toggleStatus are identical in shape)
        try {
            return DB::transaction(function () use ($request) {
                $gateway = PaymentGateway::create([
                    'name' => $request->name,
                    'code' => $request->code,
                    'type' => $request->type,
                    'driver' => $request->driver,
                    'credentials' => $request->credentials,
                    'extra_config' => $request->extra_config ?? ['mode' => 'test'],
                    'priority' => $request->priority ?? 1,
                    'is_active' => $request->is_active ?? false,
                    'is_test_mode' => $request->is_test_mode ?? false,
                ]);

                activityLog($gateway, 'Stored', [
                    'message' => 'A new payment gateway was created.',
                    'gateway_code' => $gateway->code,
                    'gateway_name' => $gateway->name,
                    'performed_by' => Auth::user()->name,
                ]);

                return redirect()
                    ->route('payment.payment-gateway.index')
                    ->with('success', flash('created.payment_gateway'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('PaymentGatewayController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -nE 'try \{|catch \(|getMessage\(\)' Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
92:        try {
118:        } catch (ModelNotFoundException $e) {
122:        } catch (\Throwable $e) {
123:            Log::error('PaymentGatewayController::store failed', ['error' => $e->getMessage()]);
152:        try {
194:        } catch (ModelNotFoundException $e) {
198:        } catch (\Throwable $e) {
199:            Log::error('PaymentGatewayController::update failed', ['error' => $e->getMessage()]);
209:        try {
228:        } catch (ModelNotFoundException $e) {
232:        } catch (\Throwable $e) {
233:            Log::error('PaymentGatewayController::destroy failed', ['error' => $e->getMessage()]);
254:        try {
273:        } catch (ModelNotFoundException $e) {
277:        } catch (\Throwable $e) {
278:            Log::error('PaymentGatewayController::restore failed', ['error' => $e->getMessage()]);
288:        try {
304:        } catch (ModelNotFoundException $e) {
308:        } catch (\Throwable $e) {
309:            Log::error('PaymentGatewayController::forceDelete failed', ['error' => $e->getMessage()]);
319:        try {
345:        } catch (ModelNotFoundException $e) {
349:        } catch (\Throwable $e) {
350:            Log::error('PaymentGatewayController::toggleStatus failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### PGC-02 · M · TXN-05 — the response is built inside the transaction closure in all six mutating methods

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()` / `response()` after it* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:113` (`store`), `:189` (`update`), `:223` (`destroy`), `:268` (`restore`), `:299` (`forceDelete`), `:331,338` (`toggleStatus`) |
| **Root cause** | Each method returns `redirect()->route(...)->with(...)` from inside the `DB::transaction` closure, and `toggleStatus` returns `response()->json(...)` twice inside it. The closure is meant to return data; the response is meant to be built after it commits. |
| **Consequence** | Lost maintainability — the transaction boundary and the HTTP response are entangled, so a later `DB::afterCommit()` side effect or a retry cannot be added cleanly; it is the same rewrite as PGC-01 (the `try/catch` around it). |
| **Reproduce** | static only — the closures return HTTP responses, visible in the source. |
| **Fix approach** | Move each `redirect()`/`response()->json()` out of the closure; the closure performs the writes and (for the toggle) returns the boolean, and the method builds the response afterwards. Applied by the PGC-01 rewrite. |
| **Plan item** | none — fixed by the PGC-01 rewrite in `02-fix-plan.md` §3 (see §10) |

```php
// PaymentGatewayController.php:113-115 — CURRENT (store; same shape at the lines listed above)
                return redirect()
                    ->route('payment.payment-gateway.index')
                    ->with('success', flash('created.payment_gateway'));
```

**Evidence**
```
$ grep -nE 'return (redirect\(\)|response\(\)->json)' Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
113:                return redirect()
189:                return redirect()
223:                return redirect()
268:                return redirect()
299:                return redirect()
331:                    return response()->json([
338:                return response()->json([
```

#### PGC-03 · M · TXN-04 — `toggleStatus` writes the audit row before the write it describes

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, **after** the write it describes* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:319-336`, method `toggleStatus()` |
| **Root cause** | The closure flips `is_active` in memory, calls `activityLog(...)` at line 323, and only then calls `$paymentGateway->save()` at line 330. Every other method logs after its write. |
| **Consequence** | If `save()` returns false (or throws), the activity log already claims "Payment Gateway status updated." — the audit trail records a change that did not happen. |
| **Reproduce** | static only — the ordering is visible in the source. |
| **Fix approach** | Move the `activityLog(...)` call to after the `save()` succeeds, inside the same transaction. |
| **Plan item** | PGC-03 in `02-fix-plan.md` §3 |

```php
// PaymentGatewayController.php:319-336 — CURRENT
            return DB::transaction(function () use ($paymentGateway) {
                $paymentGateway->is_active = ! $paymentGateway->is_active;

                activityLog($paymentGateway, 'Toggled', [
                    'message' => 'Payment Gateway status updated.',
                    'gateway_code' => $paymentGateway->code,
                    'gateway_name' => $paymentGateway->name,
                    'new_status' => $paymentGateway->is_active ? 'Active' : 'Inactive',
                ]);

                if ($paymentGateway->save()) {
                    return response()->json([
                        'success' => true,
                        'is_active' => $paymentGateway->is_active,
                        'message' => flash('status_updated.payment_gateway'),
                    ]);
                }
```

**Evidence**
```
$ grep -n "activityLog(" Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
106:                activityLog($gateway, 'Stored', [
181:                activityLog($gateway, 'Updated', [
217:                activityLog($gateway, 'Trashed', [
262:                activityLog($gateway, 'Restored', [
293:                activityLog($gateway, 'Deleted', [
323:                activityLog($paymentGateway, 'Toggled', [
$ sed -n '319,330p' Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
            return DB::transaction(function () use ($paymentGateway) {
                $paymentGateway->is_active = ! $paymentGateway->is_active;

                activityLog($paymentGateway, 'Toggled', [
                    'message' => 'Payment Gateway status updated.',
                    'gateway_code' => $paymentGateway->code,
                    'gateway_name' => $paymentGateway->name,
                    'new_status' => $paymentGateway->is_active ? 'Active' : 'Inactive',
                ]);

                if ($paymentGateway->save()) {
```

#### PGC-04 · H · TXN-06 — the "one active gateway per type" rule is under-enforced (race and bypass)

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index* (raised reason: it silently breaks the gateway the school charges through) |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:250-266` (`restore`) and `:315-343` (`toggleStatus`), whose only guard is `Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php:45-70` |
| **Root cause** | The invariant "only one active gateway per `type`" is enforced **only** in `PaymentGatewayRequest::withValidator()`'s `after()` hook, and only on `store`/`update`. It is a plain `exists()` check with no lock and no unique index (the only index is the non-unique `index(['type','is_active'])` at `2026_07_09_000004_add_type_to_payment_gateways.php:17`). `restore()` and `toggleStatus()` do not run the request, so they can turn a second gateway of a type active unconditionally. |
| **Consequence** | Two online gateways can end up active at once (via a concurrent save, a restore, or a status toggle), and the payment router then picks one by `priority` with no link to the admin's intent — payments can be routed to the wrong gateway. |
| **Reproduce** | static only — needs concurrent requests or a restore-while-another-is-active, so it is not run here (D4). |
| **Fix approach** | A behaviour change (see the decision). Minimal: re-check the invariant inside the transaction, under `lockForUpdate()`, in `store`, `update`, `restore` and `toggleStatus`, throwing a `\DomainException` the form renders. |
| **Plan item** | PGC-04 in `02-fix-plan.md` §9 (DECISION) |

```php
// PaymentGatewayController.php:256-260 — CURRENT (restore sets is_active = true with no type check)
                $gateway = PaymentGateway::onlyTrashed()->findOrFail($id);
                $gateway->restore();

                $gateway->is_active = true;
                $gateway->save();
```

**Evidence**
```
$ sed -n '59,68p' Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php
            if ($isActive && $type) {
                $exists = PaymentGateway::where('type', $type)
                    ->where('is_active', true)
                    ->when($id, fn ($q) => $q->where('id', '!=', $id))
                    ->exists();

                if ($exists) {
                    $validator->errors()->add('is_active', "An active gateway of type [{$type}] already exists.");
                }
            }
$ grep -n "unique\|index" database/migrations/tenant/2026_06_18_100100_create_payment_gateways_table.php database/migrations/tenant/2026_07_09_000004_add_type_to_payment_gateways.php
database/migrations/tenant/2026_06_18_100100_create_payment_gateways_table.php:16:            $table->string('code')->unique();
database/migrations/tenant/2026_07_09_000004_add_type_to_payment_gateways.php:17:            $table->index(['type', 'is_active']);
```

### F3 — Authorization

#### PGC-05 · M · AUTH-06 — the registered PaymentGatewayPolicy is never consulted

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy, or constants, not repeated as literals* |
| **Where** | `Modules/Payment/app/Policies/PaymentGatewayPolicy.php:12-45` and its registration at `Modules/Payment/app/Providers/PaymentServiceProvider.php:42` |
| **Root cause** | The policy is registered with `Gate::policy(PaymentGateway::class, ...)`, but every gate call in the controller is a bare **string** (`Gate::authorize('tenant.payment.gateway.viewAny')`, ...). A string gate with no model argument never reaches a policy; it is resolved by Spatie's `Gate::before` permission hook. So the policy's seven methods are dead code, and the same seven permission literals are duplicated between the controller, the FormRequest, the policy and the blades. |
| **Consequence** | A reviewer reading the policy believes it guards the resource when it guards nothing; a future change to the policy has no effect, and the literals can drift between the four surfaces. |
| **Reproduce** | static only — no caller passes a model to the gate. |
| **Fix approach** | A design choice (see the decision): delete the unused policy and its registration, or repoint the gates at it. |
| **Plan item** | PGC-05 in `02-fix-plan.md` §9 (DECISION) |

```php
// PaymentGatewayPolicy.php:12-20 — CURRENT
    public function viewAny(User $user): bool
    {
        return $user->can('tenant.payment.gateway.viewAny');
    }

    public function view(User $user, PaymentGateway $gateway): bool
    {
        return $user->can('tenant.payment.gateway.view');
    }
```

**Evidence**
```
$ grep -rn "PaymentGateway" --include=*.php app/ Modules/ | grep -iE "authorize|policy|->can\(|@can" | grep -v final-audit
Modules/Payment/app/Policies/PaymentGatewayPolicy.php:17:    public function view(User $user, PaymentGateway $gateway): bool
Modules/Payment/app/Providers/PaymentServiceProvider.php:42:        Gate::policy(\Modules\Payment\Models\PaymentGateway::class, \Modules\Payment\Policies\PaymentGatewayPolicy::class);
$ grep -rn "Gate::authorize('viewAny'\|Gate::authorize('view'\|->can('viewAny'\|->can('update'" Modules/Payment/
(no output)
```

#### PGC-06 · M · AUTH-01 — the trash page is gated on `.restore` instead of a view permission

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B) — *every routed method authorizes*; lowered to M because the method **does** authorize, but with a write permission for a read page |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:239-248`, method `trashedPaymentGateways()` |
| **Root cause** | The read-only trash list is guarded by `Gate::authorize('tenant.payment.gateway.restore')`. Viewing a list is a `.viewAny`/`.view` act; `.restore` is the ability to put a row back. |
| **Consequence** | A user who may view gateways but not restore them cannot open the trash page (the "View Deleted" icon is also hidden by the search-bar's `.restore` default), while a user who may restore but not list sees it — the permission does not describe the action. |
| **Reproduce** | Sign in as a role holding `tenant.payment.gateway.viewAny` but not `.restore`, open `/payment/payment-gateway/trash/view` — expected the list, actual a 403. |
| **Fix approach** | Change the gate string to `tenant.payment.gateway.viewAny` (the name already exists). |
| **Plan item** | PGC-06 in `02-fix-plan.md` §4 |

```php
// PaymentGatewayController.php:239-245 — CURRENT
    public function trashedPaymentGateways()
    {
        Gate::authorize('tenant.payment.gateway.restore');

        $gateways = PaymentGateway::onlyTrashed()
            ->orderByDesc('created_at')
            ->paginate(10);
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
34:        Gate::authorize('tenant.payment.gateway.viewAny');
241:        Gate::authorize('tenant.payment.gateway.restore');
252:        Gate::authorize('tenant.payment.gateway.restore');
$ grep -n "'payment.gateway'" config/permissionslist.php
1189:        'payment.gateway' => $crud,
```

#### PGC-07 · L · AUTH-04 — store and update check the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:90` (`store`) and `:150` (`update`), against `PaymentGatewayRequest::authorize()` at `:11-20` |
| **Root cause** | `PaymentGatewayRequest::authorize()` already returns `auth()->user()->can('tenant.payment.gateway.create'\|'...update')`, and the controller calls `Gate::authorize('tenant.payment.gateway.create'\|'...update')` again right below it. The Form Request runs first, so the second check is redundant. |
| **Consequence** | Every save runs the same permission lookup twice, and a future edit to one surface silently does not apply to the other. |
| **Reproduce** | static only — the duplication is visible in the source. |
| **Fix approach** | Keep the Form Request `authorize()` and delete the two duplicate `Gate::authorize(...)` lines in `store` and `update`. |
| **Plan item** | PGC-07 in `02-fix-plan.md` §4 |

```php
// PaymentGatewayController.php:88-92 — CURRENT (store; update is the same at :148-152)
    public function store(PaymentGatewayRequest $request)
    {
        Gate::authorize('tenant.payment.gateway.create');

        try {
```

**Evidence**
```
$ grep -n "authorize" Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php
11:    public function authorize(): bool
$ grep -n "Gate::authorize" Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
81:        Gate::authorize('tenant.payment.gateway.create');
90:        Gate::authorize('tenant.payment.gateway.create');
140:        Gate::authorize('tenant.payment.gateway.update');
150:        Gate::authorize('tenant.payment.gateway.update');
```

### F4 — Validation and input

clean — validation lives entirely in `PaymentGatewayRequest` (VAL-02 ✅); every field is typed (`required|string`, `integer|min|max`, `boolean`, `array`, `in:`) (VAL-05 ✅); `credentials.*` is validated as a nested array with `key`/`secret` required and `webhook_secret` nullable (VAL-06 n/a — no uploads); the cross-field "one active per type" rule is in `withValidator()`'s `after()`, not hand-written in the controller (VAL-07 ✅), though that rule is PGC-04; the `code` uniqueness rule mirrors the DB `unique` index including trashed rows (the index at `2026_06_18_100100_create_payment_gateways_table.php:16` has no `deleted_at`, and the rule uses no `whereNull('deleted_at')`), so VAL-04 is consistent. The only note: the controller reads fields as `$request->name`, `$request->credentials`, ... rather than `$request->validated()`; the FormRequest has already validated them, so this is not a defect, but `validated()` would be stricter.
```
$ grep -n "validate(\|->all()\|->except(" Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
(no output)
$ grep -nE "unique:|credentials|boolean|integer|in:" Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php
30:            'code' => "required|string|max:50|unique:ptm_payment_gateways,code,$id,id",
33:            'credentials' => 'required|array',
34:            'credentials.key' => 'required|string',
35:            'credentials.secret' => 'required|string',
36:            'credentials.webhook_secret' => 'nullable|string',
39:            'priority' => 'nullable|integer|min:1|max:100',
40:            'is_active' => 'nullable|boolean',
41:            'is_test_mode' => 'nullable|boolean',
```

### F5 — Routes

#### PGC-08 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, `publish`, ...); GET has no CSRF protection, and link prefetchers trigger it* |
| **Where** | `Modules/Payment/routes/web.php:23` (`GET /payment-gateway/{id}/restore`), calling `PaymentGatewayController.php:250` (`restore`) |
| **Root cause** | The restore action is a `GET` route and the trash blade links it as a plain anchor (`x-backend.table.action-trashed`), so it carries no `@csrf` and no `@method`. |
| **Consequence** | A cross-site forgery silently un-trashes a gateway (which then may become the active one, see PGC-04); the audit row records it as if the admin did it. Any third-party page can embed an image whose source is the restore URL and a logged-in admin's browser will restore a row without their consent. |
| **Reproduce** | static only — the verb is visible in `route:list`; CSRF cannot be exercised without a session. |
| **Fix approach** | A route re-scope (see the decision): make restore a `POST`/`DELETE` route and submit it from a form with `@csrf`/`@method`. |
| **Plan item** | PGC-08 in `02-fix-plan.md` §9 (DECISION) |

```php
// Modules/Payment/routes/web.php:23 — CURRENT
Route::get('/payment-gateway/{id}/restore', [PaymentGatewayController::class, 'restore'])->name('payment-gateway.restore');
```

**Evidence**
```
$ grep -n "payment-gateway" Modules/Payment/routes/web.php
22:Route::get('/payment-gateway/trash/view', [PaymentGatewayController::class, 'trashedPaymentGateways'])->name('payment-gateway.trashed');
23:Route::get('/payment-gateway/{id}/restore', [PaymentGatewayController::class, 'restore'])->name('payment-gateway.restore');
24:Route::delete('/payment-gateway/{id}/force-delete', [PaymentGatewayController::class, 'forceDelete'])->name('payment-gateway.forceDelete');
25:Route::post('/payment-gateway/{payment_gateway}/toggle-status', [PaymentGatewayController::class, 'toggleStatus'])->name('payment-gateway.toggleStatus');
26:Route::resource('payment-gateway', PaymentGatewayController::class);
```

### F6 — Controller shape

#### PGC-09 · M · CTL-03 — six methods use `$id` + `findOrFail` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`), not `$id` + `findOrFail`* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php` (the methods `show`, `edit`, `update`, `destroy`, `restore`, `forceDelete` at lines 129, 138, 148, 205, 250, 284) |
| **Root cause** | The six action methods take a scalar `$id` and call `PaymentGateway::findOrFail($id)` (or `onlyTrashed()/withTrashed()->findOrFail($id)`). The resource route parameter is `{payment_gateway}`, so Laravel fills `$id` positionally rather than by name — it works, but the parameter name does not identify the model and binding is bypassed. Only `toggleStatus` binds a model (`PaymentGateway $paymentGateway`), and its route parameter `{payment_gateway}` matches. |
| **Consequence** | A reader cannot see which record the method acts on from its signature, and adding implicit binding later would silently change behaviour; it is maintainability debt, not a live failure (the positional argument is populated). |
| **Reproduce** | static only — `route:list` shows `{payment_gateway}` for the resource and `{id}` for restore/force-delete. |
| **Fix approach** | A choice (see the decision): bind `show/edit/update/destroy` (their parameter name already matches) and, if the shared route file may change, `restore`/`forceDelete` too. |
| **Plan item** | PGC-09 in `02-fix-plan.md` §9 (DECISION) |

```php
// PaymentGatewayController.php:129-135 — CURRENT
    public function show($id)
    {
        Gate::authorize('tenant.payment.gateway.view');

        $gateway = PaymentGateway::findOrFail($id);

        return view('payment::payment-gateway.show', compact('gateway'));
    }
```

**Evidence**
```
$ grep -n "findOrFail\|public function" Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
129:    public function show($id)
133:        $gateway = PaymentGateway::findOrFail($id);
138:    public function edit($id)
142:        $gateway = PaymentGateway::findOrFail($id);
148:    public function update(PaymentGatewayRequest $request, $id)
154:                $gateway = PaymentGateway::findOrFail($id);
205:    public function destroy($id)
211:                $gateway = PaymentGateway::findOrFail($id);
250:    public function restore($id)
256:                $gateway = PaymentGateway::onlyTrashed()->findOrFail($id);
284:    public function forceDelete($id)
290:                $gateway = PaymentGateway::withTrashed()->findOrFail($id);
315:    public function toggleStatus(Request $request, PaymentGateway $paymentGateway)
```

#### PGC-10 · L · CTL-04 — no return types on any public method

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php` (all 11 public methods, at lines 32, 79, 88, 129, 138, 148, 205, 239, 250, 284, 315) |
| **Root cause** | None of the public methods declares a return type, so `index`/`create`/`show`/`edit`/`trashedPaymentGateways` return `View`, the writes return `RedirectResponse` (or `JsonResponse` for the toggle) with nothing stating it. |
| **Consequence** | Cosmetic/maintainability; the reader cannot see the return contract and a refactor that returns the wrong type fails late. |
| **Reproduce** | static only — the signatures are visible. |
| **Fix approach** | Add return types when the methods are otherwise touched: `: View`, `: RedirectResponse`, `: JsonResponse`. |
| **Plan item** | PGC-10 in `02-fix-plan.md` §8 |

```php
// PaymentGatewayController.php:32 — CURRENT
    public function index(Request $request)
    {
        Gate::authorize('tenant.payment.gateway.viewAny');
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+\(' Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
32:    public function index(Request $request)
79:    public function create()
88:    public function store(PaymentGatewayRequest $request)
129:    public function show($id)
138:    public function edit($id)
148:    public function update(PaymentGatewayRequest $request, $id)
205:    public function destroy($id)
239:    public function trashedPaymentGateways()
250:    public function restore($id)
284:    public function forceDelete($id)
315:    public function toggleStatus(Request $request, PaymentGateway $paymentGateway)
```

### F7 — Models

clean — no model is owned by this report; `PaymentGateway` and `Payment` are owned by `tarun/ParentPortal-done/ParentFeePaymentController`. Usage check only: `store`/`update` write exactly the columns the model declares in `$fillable` (`is_test_mode` exists after `2026_09_09_000001_add_missing_columns_to_ptm_payment_gateways.php:36`), `credentials` is written through the model so its `encrypted:array` cast applies, and the `code` unique rule matches the table index (see F4). No misuse found.
```
$ grep -n "protected \$table\|encrypted\|is_test_mode" Modules/Payment/app/Models/PaymentGateway.php
17:    protected $table = 'ptm_payment_gateways';
29:        'is_test_mode',
34:        'credentials'       => 'encrypted:array',
```

### F8 — Services and jobs

n/a — this controller calls no service, job, event, mail or notification. The one private helper, `getAvailableDrivers()` (`:356-366`), is a static array, not a service.

### F9 — Queries and performance

#### PGC-11 · L · QRY-02 — both lists paginate at 15, the house standard is 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H) — *lists are paginated*; lowered to L because the page **is** paginated, only off the house per-page size (protocol F9/C12 wants 10) |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:48` (gateways) and `:65` (history) |
| **Root cause** | `paginate(15, ['*'], 'gateway_page')` and `paginate(15, ['*'], 'history_page')` use 15 per page; the trash list (`:245`) uses 10. The two page names are distinct (QRY-13 ✅). |
| **Consequence** | The two Payment tabs show 15 rows where every other list shows 10 — an inconsistent screen, no data risk. |
| **Reproduce** | Open `GET /payment/payment-gateway?tab=payment-gateway` — 6 seeded rows show all at once; the page size is visible in the paginator only past 15 rows. |
| **Fix approach** | Change both `paginate(15, ...)` calls to `paginate(10, ...)`. |
| **Plan item** | PGC-11 in `02-fix-plan.md` §6 |

```php
// PaymentGatewayController.php:47-49 — CURRENT (history list is the same at :64-66)
            ->orderBy('priority')
            ->paginate(15, ['*'], 'gateway_page')
            ->appends($request->query());
```

**Evidence**
```
$ grep -n "paginate(" Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
48:            ->paginate(15, ['*'], 'gateway_page')
65:            ->paginate(15, ['*'], 'history_page')
245:            ->paginate(10);
```

#### PGC-12 · L · QRY-08 — leading-wildcard `LIKE` in the gateway search (accepted on a tiny table)

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M) — *leading-wildcard `LIKE '%x%'` cannot use an index; acceptable on small tables*; lowered to L because `ptm_payment_gateways` holds 6 rows |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:40-42` |
| **Root cause** | The search builds `where('name', 'like', "%{$term}%")` (and `code`, `driver`), each with a leading wildcard. |
| **Consequence** | None at 6 rows; it would only matter if a school kept thousands of gateway rows, which it does not. |
| **Reproduce** | static only — a small config table. |
| **Fix approach** | none — accepted. Revisit only if the table ever grows. |
| **Plan item** | none — see plan §10 |

```php
// PaymentGatewayController.php:40-42 — CURRENT
                    $inner->where('name', 'like', "%{$term}%")
                        ->orWhere('code', 'like', "%{$term}%")
                        ->orWhere('driver', 'like', "%{$term}%");
```

**Evidence**
```
$ grep -n "like" Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
40:                    $inner->where('name', 'like', "%{$term}%")
41:                        ->orWhere('code', 'like', "%{$term}%")
42:                        ->orWhere('driver', 'like', "%{$term}%")
58:                    $inner->where('gateway_order_id', 'like', "%{$term}%")
59:                        ->orWhere('gateway_payment_id', 'like', "%{$term}%")
```

#### PGC-13 · L · QRY-15 — the history filter dropdown loads every gateway

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *don't load every row of a big table for a form*; lowered to L because the table holds 6 rows and only two columns are selected |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:69` |
| **Root cause** | `PaymentGateway::orderBy('name')->get(['id', 'name'])` is unbounded. |
| **Consequence** | None at 6 rows — the query already selects only `id, name` (QRY-03 ✅). |
| **Reproduce** | static only. |
| **Fix approach** | none — accepted; the config table is tiny and the column set is minimal. |
| **Plan item** | none — see plan §10 |

```php
// PaymentGatewayController.php:69 — CURRENT
        $gatewayOptions = PaymentGateway::orderBy('name')->get(['id', 'name']);
```

**Evidence**
```
$ grep -n "gatewayOptions" Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
69:        $gatewayOptions = PaymentGateway::orderBy('name')->get(['id', 'name']);
76:        return view('payment::index', compact('gateways', 'paymentHistories', 'gatewayOptions', 'drivers'));
```

### F10 — Views

#### PGC-14 · L · STY-04 — the trash view is copy-pasted from Notification's Target Groups

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *no copy-pasted docblocks/strings that describe another resource; comments in English, no leftover markers* |
| **Where** | `Modules/Payment/resources/views/payment-gateway/trash.blade.php` (lines 2, 10 and 104) |
| **Root cause** | The view opens with `@include('notification::partials.head')` (injects Summernote CSS/JS and a "wizard" stylesheet into a Payment page) and closes with `@include('notification::partials.footer')` (initialises a Summernote editor on an element this page does not have), and its card header reads `title="Trashed Targets"`. These are leftovers from Notification's Target Groups screen. |
| **Consequence** | The Payment trash page loads two Notification-module partials and a rich-text editor it never uses, and its heading says "Targets" instead of "Payment Gateways" — a visible wording bug. |
| **Reproduce** | Open `GET /payment/payment-gateway/trash/view` — the card title reads "Trashed Targets". |
| **Fix approach** | Remove the two Notification includes and set the card title to "Trashed Payment Gateways". |
| **Plan item** | PGC-14 in `02-fix-plan.md` §7 |

```php
// Modules/Payment/resources/views/payment-gateway/trash.blade.php:2-10 — CURRENT
    @include('notification::partials.head')

    <x-backend.components.breadcrum title="Payment Management" :links="[]" />

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card mb-4">
                    <x-backend.card.header title="Trashed Targets" url="payment.payment-gateway" />
```

**Evidence**
```
$ grep -n "notification::\|card.header" Modules/Payment/resources/views/payment-gateway/trash.blade.php
2:    @include('notification::partials.head')
10:                    <x-backend.card.header title="Trashed Targets" url="payment.payment-gateway" />
104:    @include('notification::partials.footer')
```

Other F10 checks, clean: the entry view uses the anonymous component `<x-backend.layouts.app>` (no `@extends('prime::layouts.master')`, which does not resolve — see §7); relations rendered in `@foreach` are eager-loaded (`Payment::with('gateway')` at `:54`); no queries in Blade (VIEW-01 ✅); no `{!! !!}` on user text (VIEW-03 ✅); row actions use `x-backend.table.action` and trash rows use `x-backend.table.action-trashed`; the create form is a modal with 11 controls, under the 15-control threshold (modal-standard §2.5 ✅); breadcrumb passes `:links="[]"` (breadcrumb-standard §2.6 ✅). The standalone `create.blade.php` still exists and is still routed (intentional per the 2026-09-09 note), so the create form exists twice (modal + page) — redundant but not a defect.

### F11 — Security and tenancy

#### PGC-15 · H · SEC-02 — the edit form prints the school's decrypted gateway secrets into the page

| Field | Value |
|---|---|
| **Rule** | SEC-02 (H) — *no secrets over-exposed; map data instead of dumping the model*; raised reason — a live merchant secret is written into the HTML source of a normal admin page |
| **Where** | `Modules/Payment/resources/views/payment-gateway/edit.blade.php` (lines 76, 83 and 90; fed by `edit()` in `PaymentGatewayController.php`) |
| **Root cause** | `credentials` is cast `encrypted:array` on `PaymentGateway`, and `edit.blade.php` reads it back into the form: `value="{{ old('credentials.key', $gateway->getCredential('key')) }}"`, and the same for `credentials.secret` and `credentials.webhook_secret`. `type="password"` hides the secret from the screen but not from the page source, the browser cache, or any proxy/log that records the response body. |
| **Consequence** | Any School Admin who opens a gateway's edit page (or anything that captures that HTML) reads the merchant secret and webhook secret in clear text — a gateway-account compromise. `show.blade.php:67` also reveals the first 8 characters of the API key (`Str::mask(..., '*', 8)`), a smaller exposure of the same column. |
| **Reproduce** | Open `GET /payment/payment-gateway/1/edit` and view the page source — the `credentials[secret]` input carries the decrypted value. static-only here (needs a session). |
| **Fix approach** | A behaviour change (see the decision): stop prefilling the secret fields and keep the stored values when the submitted ones are blank. |
| **Plan item** | PGC-15 in `02-fix-plan.md` §9 (DECISION) |

```php
// Modules/Payment/resources/views/payment-gateway/edit.blade.php:74-84 — CURRENT
                                    <label class="form-label">API Key <span class="text-danger">*</span></label>
                                    <input type="text" name="credentials[key]" class="form-control"
                                        value="{{ old('credentials.key', $gateway->getCredential('key')) }}">
                                </div>

                                {{-- API Secret --}}
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">API Secret <span class="text-danger">*</span></label>
                                    <input type="password" name="credentials[secret]" class="form-control"
                                        value="{{ old('credentials.secret', $gateway->getCredential('secret')) }}">
                                </div>
```

**Evidence**
```
$ grep -n "getCredential" Modules/Payment/resources/views/payment-gateway/edit.blade.php Modules/Payment/resources/views/payment-gateway/show.blade.php
Modules/Payment/resources/views/payment-gateway/edit.blade.php:76:                                        value="{{ old('credentials.key', $gateway->getCredential('key')) }}">
Modules/Payment/resources/views/payment-gateway/edit.blade.php:83:                                        value="{{ old('credentials.secret', $gateway->getCredential('secret')) }}">
Modules/Payment/resources/views/payment-gateway/edit.blade.php:90:                                        value="{{ old('credentials.webhook_secret', $gateway->getCredential('webhook_secret')) }}">
Modules/Payment/resources/views/payment-gateway/show.blade.php:67:                                        {{ Str::mask($gateway->getCredential('key', 'N/A'), '*', 8) }}
```

Other F11 checks, clean: no `env()` outside config (SEC-01 ✅); no hard-coded ids or `?? 1` for a user/tenant (SEC-03 ✅); no request/payment data logged (SEC-04 ✅ — the only `Log::` calls are PGC-01); credentials are encrypted at rest because they are written through the model.

### F12 — Style

#### PGC-16 · L · STY-01 — the controller has no `declare(strict_types=1);`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (old files when touched)* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:1-3` |
| **Root cause** | The file opens `<?php` then `namespace`, with no `declare`. |
| **Consequence** | Scalar argument/return coercion stays on for a file the plan is about to touch. |
| **Reproduce** | `head -3` on the file shows no `declare`. |
| **Fix approach** | Add `declare(strict_types=1);` after `<?php` when the PGC-01 rewrite touches the file, then run Pint on it. |
| **Plan item** | PGC-16 in `02-fix-plan.md` §8 |

```php
// PaymentGatewayController.php:1-5 — CURRENT
<?php

namespace Modules\Payment\Http\Controllers;

use App\Http\Controllers\Controller;
```

**Evidence**
```
$ head -3 Modules/Payment/app/Http/Controllers/PaymentGatewayController.php
<?php

namespace Modules\Payment\Http\Controllers;
```

#### PGC-17 · L · STY-01 — the FormRequest lacks `strict_types` and is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);`* and STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php:1-3` and `:6` |
| **Root cause** | The file has no `declare(strict_types=1);`, and it imports `Illuminate\Validation\Rule` at line 6 without ever using `Rule::`, so Pint reports `no_unused_imports`. |
| **Consequence** | Cosmetic; the file diverges from the project style run and carries a dead import. |
| **Reproduce** | `vendor/bin/pint Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php --test` reports `result: fail`. |
| **Fix approach** | Add `declare(strict_types=1);` and delete the unused `Rule` import, then run Pint on the file. |
| **Plan item** | PGC-17 in `02-fix-plan.md` §8 |

```php
// PaymentGatewayRequest.php:1-9 — CURRENT
<?php

namespace Modules\Payment\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Modules\Payment\Models\PaymentGateway;

class PaymentGatewayRequest extends FormRequest
```

**Evidence**
```
$ vendor/bin/pint Modules/Payment/app/Http/Controllers/PaymentGatewayController.php Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php Modules/Payment/app/Policies/PaymentGatewayPolicy.php --test --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Http\/Requests\/PaymentGatewayRequest.php","fixers":["no_unused_imports"]}]}
$ grep -n "Rule::" Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php
(no output)
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 overwrite | 2 delete-before-store | 3 duplicate impl | 4 soft-delete x unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok | PGC-04 | ok | ok | ok |
| `update` | ok | ok | ok | ok | PGC-04 | ok | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | PGC-04 | ok | ok | ok | PGC-04 | ok | ok | ok |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | PGC-04 | ok | ok | ok | PGC-04 | ok | PGC-03 | ok |

Notes: `store`/`update` share the same nine-field payload (a mild copy-paste, not filed as CTL-05 — the two payloads differ in their fallbacks); `destroy` sets `is_active = false` and soft-deletes in one transaction, which is the correct pairing (a trashed row is not active); `forceDelete` logs event `'Deleted'` **after** `forceDelete()` — the model's in-memory attributes survive a force delete, so the `?? 'N/A'` fallbacks on `code`/`name` are dead but harmless; `restore` unconditionally sets `is_active = true` (question 1 and 5, PGC-04); `toggleStatus` logs before saving (question 7, PGC-03). Question 8 (dead feature): `create()` and `create.blade.php` are reached only by direct URL (the modal replaced the button) but are still routed and work, so not dead.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Payment/resources/views/payments/index.blade.php`, `payments/show.blade.php`, `webhooks/index.blade.php`, `refunds/index.blade.php`, `reconciliation/index.blade.php`, `reconciliation/show.blade.php` | Each opens with `@extends('prime::layouts.master')`, but `Modules/Prime/resources/views/layouts/master.blade.php` does not exist (only `components/layouts/master.blade.php` does). Those backend pages render a "View not found" error. OUT OF SCOPE here — none of this controller's views use `@extends`. | VIEW-01 (broken view reference) | the reports that own those views (BackendPaymentController, BackendWebhookController, BackendRefundController, PaymentReconciliationController) |
| `config/permissionslist.php:1186` | `'payment.payment-gateway' => $crud` is a second key for the same resource. The controller gates on `payment.gateway` (line 1189), so `tenant.payment.payment-gateway.*` is emitted but referenced by nothing — a duplicate/dead permission key. SHARED file; not this report's to change. | MDL-09 (literal/config drift) | config owner / the module-wide permission prune |
| `resources/views/components/backend/tab/search-bar.blade.php:33-38` | The shared search-bar component infers `.create`/`.restore` from the `permissions` prefix when no explicit `createPermission`/`trashPermission` is passed. This controller's call passes only `permissions="tenant.payment.gateway"`, so the trash icon depends on `.restore` (consistent with PGC-06 but by coincidence). Common component; not changed here. | AUTH-06 | the shared-component owner |
| `Modules/Payment/resources/views/payment-gateway/show.blade.php:67` | `Str::mask($gateway->getCredential('key', 'N/A'), '*', 8)` reveals the first 8 characters of the API key. Folded into PGC-15 as a smaller exposure of the same topic; fixed by the same decision. | SEC-02 | this report (PGC-15) |

## 8. Not covered, and why

- **Live browser behaviour** of the 12 routes was not exercised: every write route needs a logged-in School Admin session on a tenant domain, and the restore CSRF and concurrent-save race cannot be shown without one. Per D4 (no tests) every finding above is proven from source plus the route/permission instruments.
- **The exact live permission grant** (which roles currently hold `tenant.payment.gateway.*` in the tenant's `sys_role_has_permissions_jnt`) was not queried; §0 states the permission names the screen requires, measured from the controller, the FormRequest and the blades.
- **`PaymentGatewayPolicy` method bodies** beyond the permission strings were read; because nothing invokes the policy (PGC-05) its record-level correctness cannot manifest today.
- **`Payment` (the History tab's model) and `PaymentGateway`** are owned by the ParentPortal report and were not re-audited; only this controller's usage was checked.
- **The one-active-per-type race (PGC-04)** is proven from the absence of a lock/unique index, not from a reproduced concurrent write.
