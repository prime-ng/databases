# Status — Payment / PaymentGatewayController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output |
|---|---|---|---|---|
| PGC-01/02/03/07 | `PaymentGatewayController.php` | Six mutating methods rewritten: no try/catch, responses after commit, toggle logs after save, duplicate gates removed. | `grep "try {|catch (|getMessage"` | none |
| PGC-04 | `PaymentGatewayController.php` | One-active-gateway-per-type enforced inside the transaction for store/update/restore/toggle. | `grep "assertSingleActiveGateway"` | 5 call sites |
| PGC-05 | policy + `PrimeServiceProvider.php` | Deleted the unused `PaymentGatewayPolicy` and its registration. | `grep "PaymentGatewayPolicy"` | none |
| PGC-06 | `PaymentGatewayController.php` | Trash page gated on `.viewAny`, not `.restore`. | `grep "gateway.viewAny"` | 2 hits |
| PGC-08 | `Modules/Payment/routes/web.php` | Restore changed GET → POST; shared trash component auto-submits a CSRF form. | `route:list` | POST restore |
| PGC-09 | `PaymentGatewayController.php` | `show/edit/update/destroy` use route model binding; restore/forceDelete keep `$id`. | `grep "PaymentGateway \\$paymentGateway"` | 4 hits |
| PGC-11 | `PaymentGatewayController.php` | Both lists paginate 10. | `grep "paginate("` | 3 × 10 |
| PGC-14 | `payment-gateway/trash.blade.php` | Removed Notification includes; corrected card title. | `grep "notification::|Trashed Targets"` | none |
| PGC-15 | `edit.blade.php`, `PaymentGatewayRequest.php`, controller | Secrets are no longer pre-filled; blank fields keep stored credentials; key/secret required only on create. | `grep "getCredential"` (blade) | none |
| PGC-16/17 | controller + request | `declare(strict_types=1)`, unused `Rule` import removed, Pint-clean. | `pint --test` | passed |

## 3. Not applied / deferred
- **PGC-10** — cosmetic return types deferred.
- **PGC-12/13** — accepted (small config table / bounded dropdown).
- **PGC-02/03/07** — covered by the PGC-01 rewrite.

## 4. Shared changes
- `Modules/Payment/routes/web.php` restore verb.
- `Modules/Payment/app/Providers/PaymentServiceProvider.php` policy registration removed.

## 5. Verification
- Pint passed; `php -l` clean; `route:list --path=payment` confirms POST restore; `view:cache` compiled.

## 6. Final state
FIXED. PGC-10/12/13 recorded as accepted/deferred.
