# Fix Plan — Payment / PaymentGatewayController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Payment/app/Models/PaymentGateway.php`, `Modules/Payment/app/Models/Payment.php` | owned by the ParentPortal report |
| `Modules/Payment/routes/web.php` | shared route file — only touched if the PGC-08 or PGC-09 decision (b) is chosen, and then only within that item |
| `config/permissionslist.php` | shared; the keys exist already, no change is needed by any item here |
| `resources/views/components/backend/tab/search-bar.blade.php`, `.../table/action-trashed.blade.php` | shared components |
| `Modules/Payment/app/Providers/PaymentServiceProvider.php` | module glue; only touched if the PGC-05 decision (a) is chosen |
| `database/migrations/tenant/**` | migrations are never edited |
| `Modules/Notification/resources/views/partials/**` | another module's partials — PGC-14 removes the `@include`, it does not edit them |

## 1. Blockers reachable today

none — the one data leak (PGC-15) is a behaviour change and is a DECISION in §9, not a mechanical fix here.

## 2. Fixes that arm a latent defect (sequenced)

none — PGC-15 is written as one decision (blank the form and keep the stored secrets in the same change), so no separate ordering is needed.

## 3. Errors & transactions (F1/F2)

- [ ] **PGC-01** · M · ERR-00 · `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:92-353` — rewrite the six mutating methods: no `try/catch`, build the response after the transaction, fix the toggle's log order.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php`
  - **Note:** this one rewrite also covers PGC-02 (response inside the closure), PGC-03 (toggle logs before the write) and PGC-07 (the duplicate `Gate::authorize` lines in `store`/`update`), so those three have no separate item (see §10).
  - **Before** (`PaymentGatewayController.php:5-12` — the two imports become unused):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Payment\Http\Requests\PaymentGatewayRequest;
    ```
  - **After:** (the two now-unused imports are dropped):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Payment\Http\Requests\PaymentGatewayRequest;
    ```
  - **Before** (`PaymentGatewayController.php:92-126` — `store`):
    ```php
        try {
            return DB::transaction(function () use ($request) {
                $gateway = PaymentGateway::create([
                    'name' => $request->name,
                    'code' => $request->code,
                    'type' => $request->type,
                    'driver' => $request->driver,
                    'credentials' => $request->credentials,
                    'extra_config' => $request->extra_config ?? ['mode' => 'test'],
                    'priority' => $request->priority ?? 1,
                    'is_active' => $request->is_active ?? false,
                    'is_test_mode' => $request->is_test_mode ?? false,
                ]);

                activityLog($gateway, 'Stored', [
                    'message' => 'A new payment gateway was created.',
                    'gateway_code' => $gateway->code,
                    'gateway_name' => $gateway->name,
                    'performed_by' => Auth::user()->name,
                ]);

                return redirect()
                    ->route('payment.payment-gateway.index')
                    ->with('success', flash('created.payment_gateway'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('PaymentGatewayController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After** (`store` — the duplicate `Gate::authorize` line at :90 is removed, and the response moves out of the closure):
    ```php
        DB::transaction(function () use ($request) {
            $gateway = PaymentGateway::create([
                'name' => $request->name,
                'code' => $request->code,
                'type' => $request->type,
                'driver' => $request->driver,
                'credentials' => $request->credentials,
                'extra_config' => $request->extra_config ?? ['mode' => 'test'],
                'priority' => $request->priority ?? 1,
                'is_active' => $request->is_active ?? false,
                'is_test_mode' => $request->is_test_mode ?? false,
            ]);

            activityLog($gateway, 'Stored', [
                'message' => 'A new payment gateway was created.',
                'gateway_code' => $gateway->code,
                'gateway_name' => $gateway->name,
                'performed_by' => Auth::user()->name,
            ]);
        });

        return redirect()
            ->route('payment.payment-gateway.index')
            ->with('success', flash('created.payment_gateway'));
    }
    ```
  - **Before** (`PaymentGatewayController.php:152-202` — `update`):
    ```php
        try {
            return DB::transaction(function () use ($request, $id) {
                $gateway = PaymentGateway::findOrFail($id);
                $original = $gateway->getOriginal();

                $gateway->update([
                    'name' => $request->name,
                    'code' => $request->code,
                    'type' => $request->type,
                    'driver' => $request->driver,
                    'credentials' => $request->credentials,
                    'extra_config' => $request->extra_config ?? $gateway->extra_config,
                    'priority' => $request->priority ?? $gateway->priority,
                    'is_active' => $request->is_active ?? $gateway->is_active,
                    'is_test_mode' => $request->is_test_mode ?? $gateway->is_test_mode,
                ]);

                $changes = $gateway->getChanges();
                $changedAttributes = [];
                foreach ($changes as $field => $newValue) {
                    if ($field === 'updated_at') {
                        continue;
                    }
                    $changedAttributes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                activityLog($gateway, 'Updated', [
                    'message' => 'Payment gateway updated.',
                    'gateway_code' => $gateway->code,
                    'gateway_name' => $gateway->name,
                    'changes' => $changedAttributes,
                    'performed_by' => Auth::user()->name,
                ]);

                return redirect()
                    ->route('payment.payment-gateway.index')
                    ->with('success', flash('updated.payment_gateway'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('PaymentGatewayController::update failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After** (`update` — the duplicate `Gate::authorize` line at :150 is removed):
    ```php
        DB::transaction(function () use ($request, $id) {
            $gateway = PaymentGateway::findOrFail($id);
            $original = $gateway->getOriginal();

            $gateway->update([
                'name' => $request->name,
                'code' => $request->code,
                'type' => $request->type,
                'driver' => $request->driver,
                'credentials' => $request->credentials,
                'extra_config' => $request->extra_config ?? $gateway->extra_config,
                'priority' => $request->priority ?? $gateway->priority,
                'is_active' => $request->is_active ?? $gateway->is_active,
                'is_test_mode' => $request->is_test_mode ?? $gateway->is_test_mode,
            ]);

            $changes = $gateway->getChanges();
            $changedAttributes = [];
            foreach ($changes as $field => $newValue) {
                if ($field === 'updated_at') {
                    continue;
                }
                $changedAttributes[$field] = [
                    'old' => $original[$field] ?? null,
                    'new' => $newValue,
                ];
            }

            activityLog($gateway, 'Updated', [
                'message' => 'Payment gateway updated.',
                'gateway_code' => $gateway->code,
                'gateway_name' => $gateway->name,
                'changes' => $changedAttributes,
                'performed_by' => Auth::user()->name,
            ]);
        });

        return redirect()
            ->route('payment.payment-gateway.index')
            ->with('success', flash('updated.payment_gateway'));
    }
    ```
  - **Before** (`PaymentGatewayController.php:209-236` — `destroy`):
    ```php
        try {
            return DB::transaction(function () use ($id) {
                $gateway = PaymentGateway::findOrFail($id);

                $gateway->is_active = false;
                $gateway->save();
                $gateway->delete();

                activityLog($gateway, 'Trashed', [
                    'message' => 'Payment Gateway deactivated and moved to trash.',
                    'gateway_code' => $gateway->code,
                    'gateway_name' => $gateway->name,
                ]);

                return redirect()
                    ->route('payment.payment-gateway.index')
                    ->with('success', flash('trashed.payment_gateway'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('PaymentGatewayController::destroy failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After** (`destroy`):
    ```php
        DB::transaction(function () use ($id) {
            $gateway = PaymentGateway::findOrFail($id);

            $gateway->is_active = false;
            $gateway->save();
            $gateway->delete();

            activityLog($gateway, 'Trashed', [
                'message' => 'Payment Gateway deactivated and moved to trash.',
                'gateway_code' => $gateway->code,
                'gateway_name' => $gateway->name,
            ]);
        });

        return redirect()
            ->route('payment.payment-gateway.index')
            ->with('success', flash('trashed.payment_gateway'));
    }
    ```
  - **Before** (`PaymentGatewayController.php:254-281` — `restore`):
    ```php
        try {
            return DB::transaction(function () use ($id) {
                $gateway = PaymentGateway::onlyTrashed()->findOrFail($id);
                $gateway->restore();

                $gateway->is_active = true;
                $gateway->save();

                activityLog($gateway, 'Restored', [
                    'message' => 'Payment Gateway restored from trash.',
                    'gateway_code' => $gateway->code,
                    'gateway_name' => $gateway->name,
                ]);

                return redirect()
                    ->route('payment.payment-gateway.trashed')
                    ->with('success', flash('restored.payment_gateway'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('PaymentGatewayController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After** (`restore`):
    ```php
        DB::transaction(function () use ($id) {
            $gateway = PaymentGateway::onlyTrashed()->findOrFail($id);
            $gateway->restore();

            $gateway->is_active = true;
            $gateway->save();

            activityLog($gateway, 'Restored', [
                'message' => 'Payment Gateway restored from trash.',
                'gateway_code' => $gateway->code,
                'gateway_name' => $gateway->name,
            ]);
        });

        return redirect()
            ->route('payment.payment-gateway.trashed')
            ->with('success', flash('restored.payment_gateway'));
    }
    ```
  - **Before** (`PaymentGatewayController.php:288-312` — `forceDelete`):
    ```php
        try {
            return DB::transaction(function () use ($id) {
                $gateway = PaymentGateway::withTrashed()->findOrFail($id);
                $gateway->forceDelete();

                activityLog($gateway, 'Deleted', [
                    'message' => 'Payment Gateway permanently deleted.',
                    'gateway_code' => $gateway->code ?? 'N/A',
                    'gateway_name' => $gateway->name ?? 'N/A',
                ]);

                return redirect()
                    ->route('payment.payment-gateway.trashed')
                    ->with('success', flash('force_deleted.payment_gateway'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('PaymentGatewayController::forceDelete failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After** (`forceDelete`):
    ```php
        DB::transaction(function () use ($id) {
            $gateway = PaymentGateway::withTrashed()->findOrFail($id);
            $gateway->forceDelete();

            activityLog($gateway, 'Deleted', [
                'message' => 'Payment Gateway permanently deleted.',
                'gateway_code' => $gateway->code ?? 'N/A',
                'gateway_name' => $gateway->name ?? 'N/A',
            ]);
        });

        return redirect()
            ->route('payment.payment-gateway.trashed')
            ->with('success', flash('force_deleted.payment_gateway'));
    }
    ```
  - **Before** (`PaymentGatewayController.php:319-353` — `toggleStatus`):
    ```php
        try {
            return DB::transaction(function () use ($paymentGateway) {
                $paymentGateway->is_active = ! $paymentGateway->is_active;

                activityLog($paymentGateway, 'Toggled', [
                    'message' => 'Payment Gateway status updated.',
                    'gateway_code' => $paymentGateway->code,
                    'gateway_name' => $paymentGateway->name,
                    'new_status' => $paymentGateway->is_active ? 'Active' : 'Inactive',
                ]);

                if ($paymentGateway->save()) {
                    return response()->json([
                        'success' => true,
                        'is_active' => $paymentGateway->is_active,
                        'message' => flash('status_updated.payment_gateway'),
                    ]);
                }

                return response()->json([
                    'success' => false,
                    'is_active' => $paymentGateway->is_active,
                    'message' => flash('status_switch_failed.payment_gateway'),
                ]);

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('PaymentGatewayController::toggleStatus failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    ```
  - **After** (`toggleStatus` — the log now happens only after a successful `save()`, and the JSON is built after the transaction):
    ```php
        $saved = DB::transaction(function () use ($paymentGateway) {
            $paymentGateway->is_active = ! $paymentGateway->is_active;

            if (! $paymentGateway->save()) {
                return false;
            }

            activityLog($paymentGateway, 'Toggled', [
                'message' => 'Payment Gateway status updated.',
                'gateway_code' => $paymentGateway->code,
                'gateway_name' => $paymentGateway->name,
                'new_status' => $paymentGateway->is_active ? 'Active' : 'Inactive',
            ]);

            return true;
        });

        return response()->json([
            'success' => $saved,
            'is_active' => $paymentGateway->is_active,
            'message' => $saved
                ? flash('status_updated.payment_gateway')
                : flash('status_switch_failed.payment_gateway'),
        ]);
    }
    ```
  - **Verify:** `grep -nE 'try \{|catch \(|getMessage\(\)|Log::' Modules/Payment/app/Http/Controllers/PaymentGatewayController.php`
  - **Expect:** no output.
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **PGC-06** · M · AUTH-01 · `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:241` — gate the trash page on a view permission, not `.restore`.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php`
  - **Before** (`PaymentGatewayController.php:239-243`):
    ```php
    public function trashedPaymentGateways()
    {
        Gate::authorize('tenant.payment.gateway.restore');

        $gateways = PaymentGateway::onlyTrashed()
    ```
  - **After:**
    ```php
    public function trashedPaymentGateways()
    {
        Gate::authorize('tenant.payment.gateway.viewAny');

        $gateways = PaymentGateway::onlyTrashed()
    ```
  - **Verify:** `grep -n "gateway.viewAny" Modules/Payment/app/Http/Controllers/PaymentGatewayController.php`
  - **Expect:** two output lines (index and trashedPaymentGateways).
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

none — the route change (PGC-08) and the one-active invariant (PGC-04) are decisions in §9; the FormRequest's validation itself is clean, and the `code` uniqueness rule already matches the DB index.

## 6. Queries & performance (F9)

- [ ] **PGC-11** · L · QRY-02 · `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:48,65` — paginate the two lists at 10, not 15, to match the house standard.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php`
  - **Before** (`PaymentGatewayController.php:47-49`):
    ```php
            ->orderBy('priority')
            ->paginate(15, ['*'], 'gateway_page')
            ->appends($request->query());
    ```
  - **After:**
    ```php
            ->orderBy('priority')
            ->paginate(10, ['*'], 'gateway_page')
            ->appends($request->query());
    ```
  - **Before** (`PaymentGatewayController.php:64-66`):
    ```php
            ->latest()
            ->paginate(15, ['*'], 'history_page')
            ->appends($request->query());
    ```
  - **After:**
    ```php
            ->latest()
            ->paginate(10, ['*'], 'history_page')
            ->appends($request->query());
    ```
  - **Verify:** `grep -n "paginate(" Modules/Payment/app/Http/Controllers/PaymentGatewayController.php`
  - **Expect:** three lines, each `paginate(10`.
  - **Effort:** S

## 7. Views (F10)

- [ ] **PGC-14** · L · STY-04 · `Modules/Payment/resources/views/payment-gateway/trash.blade.php:2,10,104` — drop the two Notification includes and fix the card title.
  - **Touches:** `Modules/Payment/resources/views/payment-gateway/trash.blade.php`
  - **Before** (`trash.blade.php:1-4`):
    ```blade
    <x-backend.layouts.app>
        @include('notification::partials.head')

        <x-backend.components.breadcrum title="Payment Management" :links="[]" />
    ```
  - **After:**
    ```blade
    <x-backend.layouts.app>
        <x-backend.components.breadcrum title="Payment Management" :links="[]" />
    ```
  - **Before** (`trash.blade.php:10`):
    ```blade
                        <x-backend.card.header title="Trashed Targets" url="payment.payment-gateway" />
    ```
  - **After:**
    ```blade
                        <x-backend.card.header title="Trashed Payment Gateways" url="payment.payment-gateway" />
    ```
  - **Before** (`trash.blade.php:104-105`):
    ```blade
        @include('notification::partials.footer')
    </x-backend.layouts.app>
    ```
  - **After:**
    ```blade
    </x-backend.layouts.app>
    ```
  - **Note for the fixer:** the third pair removes the Notification footer include and keeps the single layout closing tag that already follows it.
  - **Verify:** `grep -n 'notification::\|Trashed Targets' Modules/Payment/resources/views/payment-gateway/trash.blade.php`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **PGC-16** · L · STY-01 · `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:1-3` — add `declare(strict_types=1);`, then run Pint.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php`
  - **Before** (`PaymentGatewayController.php:1-3`):
    ```php
    <?php

    namespace Modules\Payment\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Payment\Http\Controllers;
    ```
  - **Verify:** `vendor/bin/pint Modules/Payment/app/Http/Controllers/PaymentGatewayController.php --test`
  - **Expect:** output contains `"result":"pass"`.
  - **Effort:** S

- [ ] **PGC-17** · L · STY-01 · `Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php:1-6` — add `declare(strict_types=1);`, drop the unused `Rule` import, then run Pint.
  - **Touches:** `Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php`
  - **Before** (`PaymentGatewayRequest.php:1-6`):
    ```php
    <?php

    namespace Modules\Payment\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Payment\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    ```
  - **Verify:** `vendor/bin/pint Modules/Payment/app/Http/Requests/PaymentGatewayRequest.php --test`
  - **Expect:** output contains `"result":"pass"`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **PGC-04** · H · DECISION · TXN-06 — enforce "one active gateway per type" on every write path, or accept the gap?
  - **Why it is a decision:** it changes behaviour (restore/toggle can now be refused) and picks the enforcement point; it needs Tarun's call.
  - (a) ⭐ Enforce the invariant inside the transaction in all four write paths. In `store`, `update`, `restore` and `toggleStatus`, before/at the write run `PaymentGateway::where('type', $type)->where('is_active', true)->when($id, fn ($q) => $q->where('id', '!=', $id))->lockForUpdate()->exists()` and throw `\DomainException('An active gateway of type ['.$type.'] already exists.')`; keep the FormRequest's `after()` check for a friendly early message. Touches `Modules/Payment/app/Http/Controllers/PaymentGatewayController.php` (and, optionally, leaves `PaymentGatewayRequest.php` unchanged).
  - (b) Add a DB-level guard: a generated `active_type` column plus a unique index (MySQL has no partial unique index, so this needs a new additive migration). Strongest guarantee, largest change, and the migration is never run by the fixer.
  - (c) Leave enforcement in the FormRequest only and document that restore/toggle bypass it.
  - ➜ Choice: ____

- [ ] **PGC-05** · M · DECISION · AUTH-06 — keep, repoint or delete the unused `PaymentGatewayPolicy`?
  - **Why it is a decision:** it changes the authorization design and touches a shared provider if the policy is deleted.
  - (a) ⭐ Delete `Modules/Payment/app/Policies/PaymentGatewayPolicy.php` and the `Gate::policy(PaymentGateway::class, ...)` line at `Modules/Payment/app/Providers/PaymentServiceProvider.php:42`; the string gates are the real authorization. (Touches a shared provider — this is why it needs an explicit tick.)
  - (b) Repoint the string gates at the policy by adding `Gate::define('tenant.payment.gateway.'.$ability, [PaymentGatewayPolicy::class, $ability])` for the model-less abilities (`viewAny`, `create`) and passing the model for the rest; changes seven controller call sites and the policy signatures stay.
  - (c) Leave as documentation and record the dead-code risk.
  - ➜ Choice: ____

- [ ] **PGC-08** · H · DECISION · RTE-01 — move `restore` off `GET`. ⚠ SHARED
  - **Why it is a decision:** changing the HTTP verb is a route re-scope, and `Modules/Payment/routes/web.php` is shared.
  - (a) ⭐ Change line 23 to `Route::post('/payment-gateway/{payment_gateway}/restore', [PaymentGatewayController::class, 'restore'])->name('payment-gateway.restore');` and, in `Modules/Payment/resources/views/payment-gateway/trash.blade.php`, replace the `x-backend.table.action-trashed` restore link with a small inline `<form method="POST" action="{{ route('payment.payment-gateway.restore', $gateway->id) }}">@csrf @method('POST')<button>...</button></form>` (the force-delete action stays a DELETE form). Touches the shared route file and this one blade.
  - (b) Keep the GET route and add a confirmation `POST` step before it — no, that does not remove the CSRF hole; not recommended.
  - (c) Leave as is and record the CSRF exposure as accepted.
  - ➜ Choice: ____

- [ ] **PGC-09** · M · DECISION · CTL-03 — convert the six `$id` methods to route model binding? ⚠ SHARED
  - **Why it is a decision:** binding `restore`/`forceDelete` requires renaming their route parameter in the shared route file.
  - (a) ⭐ Bind only the four methods whose route parameter is already `{payment_gateway}`: `show(PaymentGateway $gateway)`, `edit(PaymentGateway $gateway)`, `update(PaymentGatewayRequest $request, PaymentGateway $gateway)`, `destroy(PaymentGateway $gateway)`, and drop their `findOrFail`. Leave `restore`/`forceDelete` on `$id` (their routes use `{id}`). No route-file change.
  - (b) Bind all six and rename the route parameters `{id}` → `{payment_gateway}` in `Modules/Payment/routes/web.php:23-24` (⚠ SHARED route file).
  - (c) Leave as is.
  - ➜ Choice: ____

- [ ] **PGC-15** · H · DECISION · SEC-02 — stop printing the decrypted gateway secrets in the edit form.
  - **Why it is a decision:** it changes what the edit form submits and what `update()` does with blank secret fields; it touches three files.
  - (a) ⭐ Blank the three credential inputs in `Modules/Payment/resources/views/payment-gateway/edit.blade.php` (no `getCredential(...)` value, add a `placeholder="Leave blank to keep the current value"`), change `credentials.key` and `credentials.secret` in `PaymentGatewayRequest` to `nullable|string` (require them only on create), and in `PaymentGatewayController::update()` merge the submitted credentials over the stored ones so a blank field keeps the current secret. Touches the blade, the request and the controller.
  - (b) Keep the prefill (an admin who may edit a gateway may see its secrets) and record it as accepted risk; also mask the API key in `show.blade.php` further than the first 8 characters.
  - (c) Add a separate "Reveal secrets" action with its own permission; keep the edit form blank. Largest change.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PGC-02 | Fixed by the same six-method rewrite as PGC-01 (§3) — moving the response out of the closure is part of that rewrite. |
| PGC-03 | Fixed by the same six-method rewrite as PGC-01 (§3) — the toggle's `activityLog` moves after `save()` there. |
| PGC-07 | Fixed by the same six-method rewrite as PGC-01 (§3) — the two duplicate `Gate::authorize` lines in `store`/`update` are dropped there. |
| PGC-10 | Deferred cosmetic — add `: View` / `: RedirectResponse` / `: JsonResponse` return types when each method is next touched; not worth a standalone pass on a 367-line file. |
| PGC-12 | Accepted — leading-wildcard `LIKE` on a 6-row config table; no index benefit is lost. |
| PGC-13 | Accepted — the history filter dropdown reads all gateways (6 rows), selecting only `id, name`. |
