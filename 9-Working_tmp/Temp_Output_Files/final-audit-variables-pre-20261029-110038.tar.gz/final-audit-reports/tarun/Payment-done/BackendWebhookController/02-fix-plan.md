# Fix Plan — Payment / Backend\WebhookController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Payment/app/Http/Controllers/Backend/WebhookController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `resources/views/backend/layouts/master.blade.php` | shared layout — read-only for this plan |
| `Modules/Prime/resources/views/**` | shared Prime views — only touched if BWH-01 option (b) is chosen |
| `Modules/Payment/routes/web.php` | shared route file — the doubled route name is a cross-cutting note (§7), not a change here |
| `Modules/Payment/app/Providers/PaymentServiceProvider.php`, `Modules/Payment/app/Providers/RouteServiceProvider.php` | module glue — the gate-recursion note in §7 is recorded, not fixed here |
| `Modules/Payment/app/Models/PaymentWebhook.php` | owned by `tarun/Payment-done/WebhookController` |
| `Modules/Payment/app/Models/Payment.php` | owned by `tarun/ParentPortal-done/ParentFeePaymentController` |
| `Modules/Payment/resources/views/payments/**`, `reconciliation/**`, `refunds/index.blade.php` | owned by other Payment controller reports |
| `config/permissionslist.php` | shared config — only touched if BWH-02 option (a) is chosen (new permission key) |
| any migration | standing rule: never edit an existing migration |

## 1. Blockers reachable today

- [ ] **BWH-01** · B · DECISION · VIEW-04 — the webhook page extends `prime::layouts.master`, which does not resolve, so the page 500s before anything renders. Which layout should it use?
  - **Why it is a decision:** the target layout is a shared file (`resources/views/backend/layouts/master.blade.php` or a new `Modules/Prime/resources/views/layouts/master.blade.php`), and the same broken `@extends` sits in five other Payment views owned by other reports. Creating a layout file or editing a shared one reaches outside this controller's files. The identical decision is BPA-01 in `tarun/Payment-done/BackendPaymentController/02-fix-plan.md` and BRF-01 in `tarun/Payment-done/BackendRefundController/02-fix-plan.md` — if Tarun has already chosen there, apply the same answer here.
  - **⚠ SHARED**
  - (a) ⭐ Point this one view at the existing `backend.layouts.master` (`@extends('backend.layouts.master')`, already used by the Hpc module's backend views). No new file, smallest blast radius; fixes only the webhooks page. That layout yields `title` and `content` only, so fold the `content_header` heading into `content` (or drop it).
  - (b) Create the missing `Modules/Prime/resources/views/layouts/master.blade.php` (an AdminLTE-style layout with `@yield('content')` and `@yield('content_header')`) so all six Payment views and any future `prime::layouts.master` consumer resolve. One new shared file; larger blast radius; needs a follow-up look at every `prime::layouts.master` user.
  - (c) Defer to a module-wide Payment view pass (the five other views share the break) — leave the webhooks page down until then.
  - ➜ Choice: ____

## 2. Fixes that arm a latent defect (sequenced)

None. BWH-01 must be fixed before the view-level item (BWH-04) is visible to a user, but BWH-04 is an independent edit and any order leaves the code valid.

## 3. Errors & transactions (F1/F2)

None — the controller has no write path, no `try`/`catch` and no `activityLog` event.

## 4. Authorization (F3)

- [ ] **BWH-02** · M · DECISION · AUTH-06 — the webhook list is gated by `tenant.payment.reconciliation.viewAny`, an unrelated feature's permission; no `payment.webhook` key exists. Give webhooks their own permission, or accept the reconciliation gate?
  - **Why it is a decision:** option (a) adds a new permission key, which needs `config/permissionslist.php`, an additive reseed by Tarun (`GET /system-config/sync-permissions`) and possibly a `glb_menus` edit — all Tarun's hand, never the fixer's.
  - **⚠ SHARED**
  - (a) ⭐ Add a dedicated key. The recommended shape: add `'payment.webhook' => $crud,` next to `payment.reconciliation` in `config/permissionslist.php` (which yields `tenant.payment.webhook.viewAny`), then change the controller line to `Gate::authorize('tenant.payment.webhook.viewAny');`. Tarun reseeds. This separates webhook visibility from reconciliation rights.
  - (b) Keep the current reconciliation gate deliberately (webhooks are treated as part of reconciliation). No code change; record it as accepted in the module summary.
  - (c) Gate webhooks under the existing payment-read permission `tenant.payment.payment.viewAny` (webhooks belong to payments), which is already seeded and holds no new key. Code-only change, but it widens access to every role that can read the payment list.
  - ➜ Choice: ____

## 5. Validation, routes, models (F4/F5/F7)

None.

## 6. Queries & performance (F9)

- [ ] **BWH-03** · M · QRY-13 · `Modules/Payment/app/Http/Controllers/Backend/WebhookController.php:21-23` — paginate the list at the house standard of 10 with a distinct page name.
  - **Touches:** `Modules/Payment/app/Http/Controllers/Backend/WebhookController.php`
  - **Before** (`WebhookController.php:21-23`):
    ```php
            $webhooks = PaymentWebhook::with('payment')
                ->latest()
                ->paginate(20);
    ```
  - **After:**
    ```php
            $webhooks = PaymentWebhook::with('payment')
                ->latest()
                ->paginate(10, ['*'], 'webhooksPage');
    ```
  - **Verify:** `grep -n "paginate" Modules/Payment/app/Http/Controllers/Backend/WebhookController.php`
  - **Expect:** `->paginate(10, ['*'], 'webhooksPage');`
  - **Effort:** S

## 7. Views (F10)

- [ ] **BWH-04** · L · UI-STD · `Modules/Payment/resources/views/webhooks/index.blade.php:9` — render the page breadcrumb.
  - **Touches:** `Modules/Payment/resources/views/webhooks/index.blade.php`
  - **Before** (`webhooks/index.blade.php:9-11`):
    ```blade
    @section('content')
        <div class="card">
            <div class="card-body">
    ```
  - **After:**
    ```blade
    @section('content')
        <x-backend.components.breadcrum title="Payment Webhooks" :links="[]" />
        <div class="card">
            <div class="card-body">
    ```
  - **Verify:** `grep -n "breadcrum" Modules/Payment/resources/views/webhooks/index.blade.php`
  - **Expect:** `<x-backend.components.breadcrum title="Payment Webhooks" :links="[]" />`
  - **Effort:** S

## 8. Style (F12) — one item per file

None — the controller is already Pint-clean (`vendor/bin/pint --test` → `{"tool":"pint","result":"passed"}`).

## 9. Deferred / decisions

None beyond BWH-01 (in §1, because the page is down) and BWH-02 (in §4, because it needs a new permission key or an explicit accept).

## 10. Findings with no plan item

None — every finding has a plan item (BWH-01 in §1, BWH-02 in §4, BWH-03 in §6, BWH-04 in §7).
