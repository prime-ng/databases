# Status — Payment / Backend\WebhookController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output |
|---|---|---|---|---|
| BWH-01 | `webhooks/index.blade.php` | Switched to `backend.layouts.master`; folded header into content. | `grep "prime::layouts.master"` | none |
| BWH-02 | `config/permissionslist.php`, `Backend/WebhookController.php` | Added `payment.webhook` key and gated the list on `tenant.payment.webhook.viewAny`. | `grep "webhook.viewAny"` | 1 hit |
| BWH-03 | `Backend/WebhookController.php` | Paginates 10 with `webhooksPage`. | `grep "paginate"` | `paginate(10, ['*'], 'webhooksPage')` |
| BWH-04 | `webhooks/index.blade.php` | Breadcrumb added. | `grep "breadcrum"` | 1 hit |

## 3. Not applied / deferred
- None.

## 4. Needs Tarun's hand
- Run `/system-config/sync-permissions` (or the permission seeder) so `tenant.payment.webhook.viewAny` is created.

## 5. Verification
- Pint passed; `php -l` clean; `view:cache` compiled.

## 6. Final state
FIXED. Awaiting permission reseed.
