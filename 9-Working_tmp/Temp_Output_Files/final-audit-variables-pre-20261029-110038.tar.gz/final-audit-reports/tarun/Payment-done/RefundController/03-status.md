# Status — Payment / RefundController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output |
|---|---|---|---|---|
| RFD-19 | `Services/RefundService.php` | Refund cap counts pending + processing + success refunds. | `grep "whereIn('status'"` | present |
| RFD-03 / RFD-20 | `Services/RefundService.php` | Both webhook transitions wrapped in transactions with `lockForUpdate` and terminal-status guards. | `grep "DB::transaction|lockForUpdate"` | 3 pairs |
| RFD-21 | `Listeners/RefundSucceededListener.php` | Partial refunds deduct the refunded amount instead of closing the whole transaction. | `grep "markRefunded|deductPayment"` | both present |
| RFD-02 / RFD-22 | `Services/RefundService.php` | Gateway HTTP call moved outside the transaction; failure marks the refund failed and raises a domain error. | `grep "driver->refund|catch (\\\\Throwable"` | present |
| RFD-01 | `Services/RefundService.php`, `RefundController.php` | Business refusals are `DomainException`; controller returns 422 with the curated message. | `grep "DomainException"` | present |
| RFD-04 | `RefundController.php` | Removed the duplicate controller permission gate. | `grep "tenant.payment.payment.refund"` | none |
| RFD-05 | `Services/RefundService.php`, `Listeners/RefundInitiatedListener.php` | Single audit writer per event; initiated event name corrected. | `grep "refund.initiated|refund.failed"` | service only succeeded |
| RFD-06 | `Listeners/RefundSucceededListener.php` | `FeeInvoiceService` constructor-injected. | `grep "app(FeeInvoiceService"` | none |
| RFD-08 | `RefundController.php`, `Services/RefundService.php` | Explicit six-field refund JSON; explicit select list. | `grep "select(["` | present |
| RFD-09..17 | controller/service/model/events/listeners | Pint-clean. | `pint --test` | passed |
| RFD-18 | `RefundController.php` | Docblock URLs corrected to `/api/v1/payments/...`. | `grep "payment/{ulid}"` | none |

## 3. Not applied / deferred
- **RFD-07** — accepted: changing the list to a paginator envelope needs an API-client contract change.

## 4. Shared changes
- None outside the report's owned files.

## 5. Verification
- Pint passed; `php -l` clean.

## 6. Final state
FIXED. RFD-07 recorded as accepted.
