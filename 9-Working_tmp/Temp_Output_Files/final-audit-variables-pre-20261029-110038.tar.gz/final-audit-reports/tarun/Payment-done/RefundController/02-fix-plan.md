# Fix Plan — Payment / RefundController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Payment/app/Http/Controllers/RefundController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Payment/app/Models/Payment.php`, `PaymentAuditLog.php` | owned by the ParentFeePaymentController report |
| `Modules/Payment/app/Services/PaymentService.php`, `AuditService.php`, `GatewayManager.php` | owned by the ParentFeePaymentController report |
| `Modules/Payment/app/Policies/PaymentPolicy.php` | owned by the PaymentController report; its `refund` method was only verified, not changed |
| `Modules/Payment/app/Gateways/*`, `Jobs/ProcessWebhookJob.php`, `Providers/EventServiceProvider.php` | outside this controller's scope |
| `Modules/StudentFee/**` | owned by the StudentFee / ParentFeeController reports; RFD-21 changes only the Payment listener that calls it |
| `Modules/Payment/routes/api.php` | routes are correct; no change is planned |
| any migration | never edit an existing migration |

## 1. Blockers and their sequencing prerequisites (in application order)

> RFD-19 is High, not a Blocker. It is listed first because RFD-02's safety depends on the in-flight
> reservation it adds; applying RFD-02 before RFD-19 would widen the gap instead of closing it.

- [ ] **RFD-19** · H · TXN-06 · `Modules/Payment/app/Services/RefundService.php:42-46` — count `pending` and `processing` refunds against the refundable cap so the same money cannot be refunded twice.
  - **Touches:** `Modules/Payment/app/Services/RefundService.php`
  - **Before** (`RefundService.php:42-46`):
    ```php
            $refundedSoFar = PaymentRefund::where('payment_id', $freshPayment->id)
                ->where('status', PaymentRefund::STATUS_SUCCESS)
                ->sum('amount');

            $maxRefundable = $freshPayment->amount - $refundedSoFar;
    ```
  - **After:**
    ```php
            // TXN-06 (2026-10-19): count in-flight refunds too, otherwise a second
            // request passes the cap while the first is still pending/processing.
            $refundedSoFar = PaymentRefund::where('payment_id', $freshPayment->id)
                ->whereIn('status', [
                    PaymentRefund::STATUS_PENDING,
                    PaymentRefund::STATUS_PROCESSING,
                    PaymentRefund::STATUS_SUCCESS,
                ])
                ->sum('amount');

            $maxRefundable = $freshPayment->amount - $refundedSoFar;
    ```
  - **Verify:** `grep -n "whereIn('status'" Modules/Payment/app/Services/RefundService.php`
  - **Expect:** one hit at the `$refundedSoFar` query, listing the three statuses.
  - **Effort:** S

- [ ] **RFD-03** · H · TXN-01 · `Modules/Payment/app/Services/RefundService.php:90-132` — put both webhook transitions in one transaction each, lock the refund row, and add the terminal-status guards that also clear RFD-20.
  - **Why it is here:** the guard in the same rewrite (RFD-20) is only safe once the status update and the listener's ledger writes share one transaction.
  - **Touches:** `Modules/Payment/app/Services/RefundService.php`
  - **Before** (`RefundService.php:90-115`, `markRefundSuccess`):
    ```php
    public function markRefundSuccess(PaymentRefund $refund, array $payload = []): void
    {
        $refund->update([
            'status'      => PaymentRefund::STATUS_SUCCESS,
            'refunded_at' => now(),
        ]);

        // If fully refunded, mark payment as refunded
        $payment = $refund->payment;
        $totalRefunded = $payment->refunds()
            ->where('status', PaymentRefund::STATUS_SUCCESS)
            ->sum('amount');

        if ($totalRefunded >= $payment->amount) {
            $payment->update(['status' => Payment::STATUS_REFUNDED]);
        }

        $this->auditService->log(
            payment: $payment,
            event: 'refund.succeeded',
            payload: array_merge(['refund_ulid' => $refund->ulid], $payload),
            actorType: 'gateway',
        );

        event(new RefundSucceeded($refund->fresh()));
    }
    ```
  - **After:**
    ```php
    public function markRefundSuccess(PaymentRefund $refund, array $payload = []): void
    {
        DB::transaction(function () use ($refund, $payload): void {
            $lockedRefund = PaymentRefund::lockForUpdate()->findOrFail($refund->id);

            // TXN-06 (2026-10-19): a replayed success webhook must not re-run the ledger listener.
            if ($lockedRefund->status === PaymentRefund::STATUS_SUCCESS) {
                return;
            }

            $lockedRefund->update([
                'status'      => PaymentRefund::STATUS_SUCCESS,
                'refunded_at' => now(),
            ]);

            // If fully refunded, mark payment as refunded
            $payment = $lockedRefund->payment;
            $totalRefunded = $payment->refunds()
                ->where('status', PaymentRefund::STATUS_SUCCESS)
                ->sum('amount');

            if ($totalRefunded >= $payment->amount) {
                $payment->update(['status' => Payment::STATUS_REFUNDED]);
            }

            $this->auditService->log(
                payment: $payment,
                event: 'refund.succeeded',
                payload: array_merge(['refund_ulid' => $lockedRefund->ulid], $payload),
                actorType: 'gateway',
            );

            event(new RefundSucceeded($lockedRefund->fresh()));
        });
    }
    ```
  - **Before** (`RefundService.php:120-132`, `markRefundFailed`):
    ```php
    public function markRefundFailed(PaymentRefund $refund, string $reason, array $payload = []): void
    {
        $refund->update(['status' => PaymentRefund::STATUS_FAILED]);

        $this->auditService->log(
            payment: $refund->payment,
            event: 'refund.failed',
            payload: array_merge(['refund_ulid' => $refund->ulid, 'reason' => $reason], $payload),
            actorType: 'gateway',
        );

        event(new RefundFailed($refund->fresh(), $reason));
    }
    ```
  - **After:**
    ```php
    public function markRefundFailed(PaymentRefund $refund, string $reason, array $payload = []): void
    {
        DB::transaction(function () use ($refund, $reason, $payload): void {
            $lockedRefund = PaymentRefund::lockForUpdate()->findOrFail($refund->id);

            // TXN-06 (2026-10-19): never flip an already-successful refund to failed.
            if (in_array($lockedRefund->status, [PaymentRefund::STATUS_SUCCESS, PaymentRefund::STATUS_FAILED], true)) {
                return;
            }

            $lockedRefund->update(['status' => PaymentRefund::STATUS_FAILED]);

            $this->auditService->log(
                payment: $refund->payment,
                event: 'refund.failed',
                payload: array_merge(['refund_ulid' => $refund->ulid, 'reason' => $reason], $payload),
                actorType: 'gateway',
            );

            event(new RefundFailed($refund->fresh(), $reason));
        });
    }
    ```
  - **Verify:** `grep -n "DB::transaction\|lockForUpdate" Modules/Payment/app/Services/RefundService.php`
  - **Expect:** exactly three `DB::transaction` hits and exactly three `lockForUpdate` hits in the file (one existing pair in `initiate`, one new pair in each webhook method). Line numbers are not asserted because the file grows.
  - **Effort:** M

- [ ] **RFD-21** · B · F13 #1 · `Modules/Payment/app/Listeners/RefundSucceededListener.php:47-54` — book a partial refund as a partial deduction instead of marking the whole fee transaction refunded.
  - **Touches:** `Modules/Payment/app/Listeners/RefundSucceededListener.php`
  - **Before** (`RefundSucceededListener.php:47-54`):
    ```php
            $service->recordRefund(
                transaction: $transaction,
                amount: $refund->amount,
                reason: $refund->reason,
                refundReference: $refund->gateway_refund_id,
            );

            $transaction->markRefunded();
    ```
  - **After:**
    ```php
            $service->recordRefund(
                transaction: $transaction,
                amount: $refund->amount,
                reason: $refund->reason,
                refundReference: $refund->gateway_refund_id,
            );

            // F13 #1 (2026-10-19): markRefunded() defaults to the FULL transaction amount.
            // Only a full refund may close the transaction; a partial refund deducts exactly
            // the refunded amount and leaves the transaction in its successful state.
            if ((float) $refund->amount >= (float) $transaction->amount) {
                $transaction->markRefunded();
            } elseif ($transaction->invoice) {
                $transaction->invoice->deductPayment((float) $refund->amount);
            }
    ```
  - **Verify:** `grep -n "markRefunded\|deductPayment" Modules/Payment/app/Listeners/RefundSucceededListener.php`
  - **Expect:** one `markRefunded()` inside the full-refund branch and one `deductPayment()` in the partial branch.
  - **Effort:** S

- [ ] **RFD-02** · B · TXN-03 · `Modules/Payment/app/Services/RefundService.php:38-83` — commit the pending refund, call the gateway outside any transaction, then store the result in a second short transaction.
  - **Why it is here:** RFD-19 must be applied first, because the in-flight refund is the reservation that protects the gap opened by this move.
  - **Touches:** `Modules/Payment/app/Services/RefundService.php`
  - **Before** (`RefundService.php:38`, opening of `initiate`'s transaction):
    ```php
            return DB::transaction(function () use ($payment, $amount, $reason, $userId) {
    ```
  - **After:**
    ```php
            $refund = DB::transaction(function () use ($payment, $amount, $reason, $userId) {
    ```
  - **Before** (`RefundService.php:54-83`, create through the closing brace):
    ```php
                $refund = PaymentRefund::create([
                    'ulid'         => Str::ulid(),
                    'payment_id'   => $freshPayment->id,
                    'amount'       => $amount,
                    'reason'       => $reason,
                    'status'       => PaymentRefund::STATUS_PENDING,
                    'is_active'    => true,
                    'initiated_by' => $userId,
                    'created_by'   => $userId,
                ]);

                $driver = $this->gatewayManager->resolve($payment->gateway->code);
                $result = $driver->refund($payment, $amount);

                $refund->update([
                    'gateway_refund_id' => $result['gateway_refund_id'] ?? null,
                    'status'            => PaymentRefund::STATUS_PROCESSING,
                    'metadata'          => $result['raw'] ?? [],
                ]);

                $this->auditService->log(
                    payment: $payment,
                    event: 'refund.initiated',
                    payload: ['refund_ulid' => $refund->ulid, 'amount' => $amount, 'reason' => $reason],
                    actorType: 'system',
                );

                event(new RefundInitiated($refund));

                return $refund;
            });
    ```
  - **After:**
    ```php
                return PaymentRefund::create([
                    'ulid'         => Str::ulid(),
                    'payment_id'   => $freshPayment->id,
                    'amount'       => $amount,
                    'reason'       => $reason,
                    'status'       => PaymentRefund::STATUS_PENDING,
                    'is_active'    => true,
                    'initiated_by' => $userId,
                    'created_by'   => $userId,
                ]);
            });

            try {
                $driver = $this->gatewayManager->resolve($payment->gateway->code);
                $result = $driver->refund($payment, $amount);
            } catch (\Throwable $e) {
                // ERR-01 (2026-10-19): D2 service shape — report the exception and surface one fixed message.
                report($e);

                $this->markRefundFailed($refund, 'Gateway refund request failed.');

                throw new \DomainException('The refund could not be started. The error has been logged.');
            }

            return DB::transaction(function () use ($refund, $result, $payment, $amount, $reason) {
                $refund->update([
                    'gateway_refund_id' => $result['gateway_refund_id'] ?? null,
                    'status'            => PaymentRefund::STATUS_PROCESSING,
                    'metadata'          => $result['raw'] ?? [],
                ]);

                $this->auditService->log(
                    payment: $payment,
                    event: 'refund.initiated',
                    payload: ['refund_ulid' => $refund->ulid, 'amount' => $amount, 'reason' => $reason],
                    actorType: 'system',
                );

                event(new RefundInitiated($refund));

                return $refund;
            });
    ```
  - **Verify:** `grep -n "DB::transaction\|driver->refund\|catch (\\\\Throwable" Modules/Payment/app/Services/RefundService.php`
  - **Expect:** three `DB::transaction` hits, one `driver->refund` hit, and one `catch (\Throwable` hit; the driver line sits after the first `});` in the method, outside any open transaction.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

No additional items. RFD-19 and RFD-03 above are the two sequencing prerequisites (cap reservation before the HTTP move; transaction before the status guards).

## 3. Errors, transactions & services (F1/F2/F8)

- [ ] **RFD-01** · H · ERR-00 (D1/D2) / VAL-07 · `Modules/Payment/app/Services/RefundService.php:34-52` and `RefundController.php:44-51` — turn business refusals into `\DomainException` and return HTTP 422 from one D2-sanctioned catch.
  - **Touches:** `Modules/Payment/app/Services/RefundService.php`, `Modules/Payment/app/Http/Controllers/RefundController.php`
  - **Before** (`RefundService.php:34-36`):
    ```php
            if ($payment->status !== Payment::STATUS_SUCCESS) {
                throw new \RuntimeException("Cannot refund payment in status: {$payment->status}");
            }
    ```
  - **After:**
    ```php
            if ($payment->status !== Payment::STATUS_SUCCESS) {
                throw new \DomainException("Cannot refund payment in status: {$payment->status}");
            }
    ```
  - **Before** (`RefundService.php:48-52`):
    ```php
                if ($amount > $maxRefundable) {
                    throw new \InvalidArgumentException(
                        "Refund amount ({$amount}) exceeds max refundable amount ({$maxRefundable})"
                    );
                }
    ```
  - **After:**
    ```php
                if ($amount > $maxRefundable) {
                    throw new \DomainException(
                        "Refund amount ({$amount}) exceeds max refundable amount ({$maxRefundable})"
                    );
                }
    ```
  - **Before** (`RefundController.php:44-51`):
    ```php
            $refund = $this->refundService->initiate(
                payment: $payment,
                amount: $request->validated('amount'),
                reason: $request->validated('reason'),
                userId: auth()->id(),
            );
    ```
  - **After:**
    ```php
            try {
                $refund = $this->refundService->initiate(
                    payment: $payment,
                    amount: $request->validated('amount'),
                    reason: $request->validated('reason'),
                    userId: auth()->id(),
                );
            } catch (\DomainException $e) {
                // ERR-01 (2026-10-19): D2 allows a DomainException catch; only the
                // curated business message is shown, and the status is 422.
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage(),
                ], 422);
            }
    ```
  - **Verify:** `grep -n "RuntimeException\|InvalidArgumentException\|catch (\\\\DomainException" Modules/Payment/app/Services/RefundService.php Modules/Payment/app/Http/Controllers/RefundController.php`
  - **Expect:** no `RuntimeException`/`InvalidArgumentException` hits; one `catch (\DomainException` hit in the controller.
  - **Effort:** S

- [ ] **RFD-05** · M · SVC-04 · `Modules/Payment/app/Services/RefundService.php:74-79` and the post-RFD-03 failed log at `:124-129` — remove the service's duplicate audit rows and keep the listener as the single writer.
  - **Touches:** `Modules/Payment/app/Services/RefundService.php`, `Modules/Payment/app/Listeners/RefundInitiatedListener.php`
  - **Before** (`RefundService.php:74-79`):
    ```php
                $this->auditService->log(
                    payment: $payment,
                    event: 'refund.initiated',
                    payload: ['refund_ulid' => $refund->ulid, 'amount' => $amount, 'reason' => $reason],
                    actorType: 'system',
                );
    ```
  - **After:**
    ```php
                // Removed (RFD-05): RefundInitiatedListener writes the single refund.initiated audit row.
    ```
  - **Before** (`RefundService.php`, the `markRefundFailed` log after RFD-03 — same call, now indented one level):
    ```php
                $this->auditService->log(
                    payment: $refund->payment,
                    event: 'refund.failed',
                    payload: array_merge(['refund_ulid' => $refund->ulid, 'reason' => $reason], $payload),
                    actorType: 'gateway',
                );
    ```
  - **After:**
    ```php
                // Removed (RFD-05): RefundFailedListener writes the single refund.failed audit row.
    ```
  - **Before** (`RefundInitiatedListener.php:21-31`):
    ```php
            $this->auditService->log(
                payment: $payment,
                event: 'refund.initiated.event',
                actorType: 'system',
                payload: [
                    'refund_ulid'       => $refund->ulid,
                    'refund_amount'     => $refund->amount,
                    'refund_reason'     => $refund->reason,
                    'gateway_refund_id' => $refund->gateway_refund_id,
                ],
            );
    ```
  - **After:**
    ```php
            $this->auditService->log(
                payment: $payment,
                event: 'refund.initiated',
                actorType: 'system',
                payload: [
                    'refund_ulid'       => $refund->ulid,
                    'refund_amount'     => $refund->amount,
                    'refund_reason'     => $refund->reason,
                    'gateway_refund_id' => $refund->gateway_refund_id,
                ],
            );
    ```
  - **Verify:** `grep -n "refund.initiated\|refund.failed\|auditService->log" Modules/Payment/app/Services/RefundService.php Modules/Payment/app/Listeners/RefundInitiatedListener.php Modules/Payment/app/Listeners/RefundFailedListener.php`
  - **Expect:** the service keeps only the `refund.succeeded` log; the initiated listener uses `refund.initiated`; the failed listener still has one `refund.failed` log.
  - **Effort:** S

- [ ] **RFD-06** · M · SVC-02 · `Modules/Payment/app/Listeners/RefundSucceededListener.php:22-24,44-47` — inject `FeeInvoiceService` instead of resolving it with `app()`.
  - **Touches:** `Modules/Payment/app/Listeners/RefundSucceededListener.php`
  - **Before** (`RefundSucceededListener.php:22-24`):
    ```php
        public function __construct(
            private readonly AuditService $auditService,
        ) {}
    ```
  - **After:**
    ```php
        public function __construct(
            private readonly AuditService $auditService,
            private readonly FeeInvoiceService $feeInvoiceService,
        ) {}
    ```
  - **Before** (`RefundSucceededListener.php:44-47`):
    ```php
            /** @var FeeInvoiceService $service */
            $service = app(FeeInvoiceService::class);

            $service->recordRefund(
    ```
  - **After:**
    ```php
            $this->feeInvoiceService->recordRefund(
    ```
  - **Verify:** `grep -n "app(FeeInvoiceService\|feeInvoiceService->recordRefund" Modules/Payment/app/Listeners/RefundSucceededListener.php`
  - **Expect:** no `app(FeeInvoiceService` hit; one `feeInvoiceService->recordRefund` hit.
  - **Effort:** S

- [ ] **RFD-08** · M · SEC-02 · `Modules/Payment/app/Http/Controllers/RefundController.php:70-71` and `RefundService.php:137-140` — return an explicit six-field array instead of whole models.
  - **Touches:** `Modules/Payment/app/Http/Controllers/RefundController.php`, `Modules/Payment/app/Services/RefundService.php`
  - **Before** (`RefundController.php:70-71`):
    ```php
            $refunds = $this->refundService->getRefundsForPayment($payment);
            return response()->json($refunds);
    ```
  - **After:**
    ```php
            $refunds = $this->refundService->getRefundsForPayment($payment)
                ->map(fn ($refund): array => [
                    'ulid' => $refund->ulid,
                    'amount' => $refund->amount,
                    'status' => $refund->status,
                    'reason' => $refund->reason,
                    'gateway_refund_id' => $refund->gateway_refund_id,
                    'refunded_at' => $refund->refunded_at?->toIso8601String(),
                ]);

            return response()->json($refunds);
    ```
  - **Before** (`RefundService.php:137-140`):
    ```php
        public function getRefundsForPayment(Payment $payment)
        {
            return $payment->refunds()->latest()->get();
        }
    ```
  - **After:**
    ```php
        public function getRefundsForPayment(Payment $payment)
        {
            return $payment->refunds()
                ->select(['ulid', 'amount', 'status', 'reason', 'gateway_refund_id', 'refunded_at'])
                ->latest()
                ->get();
        }
    ```
  - **Verify:** `grep -n "json(\$refunds)\|select(\[" Modules/Payment/app/Http/Controllers/RefundController.php Modules/Payment/app/Services/RefundService.php`
  - **Expect:** the controller no longer passes the raw collection straight to `json()`; the service selects the explicit column list.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **RFD-04** · L · AUTH-04 · `Modules/Payment/app/Http/Controllers/RefundController.php:38` — drop the controller gate that repeats the FormRequest's permission check.
  - **Touches:** `Modules/Payment/app/Http/Controllers/RefundController.php`
  - **Before** (`RefundController.php:38`):
    ```php
            Gate::authorize('tenant.payment.payment.refund');
    ```
  - **After:**
    ```php
            // Removed (RFD-04): InitiateRefundRequest::authorize() checks this permission first;
            // the model-level `refund` policy check below remains.
    ```
  - **Verify:** `grep -n "tenant.payment.payment.refund" Modules/Payment/app/Http/Controllers/RefundController.php`
  - **Expect:** no output.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

No items. The only validation gap is the business cap, handled by RFD-01 and RFD-19. Routes and the model are correct.

## 6. Queries & performance (F9)

No items. RFD-07 is accepted in §10.

## 7. Views (F10)

No items. The controller renders no view.

## 8. Style (F12) — one item per file

- [ ] **RFD-09** · L · STY-02 · `Modules/Payment/app/Http/Controllers/RefundController.php:7-12` — Pint-clean the controller.
  - **Touches:** `Modules/Payment/app/Http/Controllers/RefundController.php`
  - **Before** (`RefundController.php:7-12`):
    ```php
    use Illuminate\Support\Facades\Gate;
    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Modules\Payment\Http\Requests\InitiateRefundRequest;
    use Modules\Payment\Services\PaymentService;
    use Modules\Payment\Services\RefundService;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Support\Facades\Gate;
    use Modules\Payment\Http\Requests\InitiateRefundRequest;
    use Modules\Payment\Services\PaymentService;
    use Modules\Payment\Services\RefundService;
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Payment/app/Http/Controllers/RefundController.php`
  - **Expect:** `"result":"passed"`.
  - **Effort:** S

- [ ] **RFD-10** · L · STY-02 · `Modules/Payment/app/Services/RefundService.php:68-72` — Pint-clean the service.
  - **Touches:** `Modules/Payment/app/Services/RefundService.php`
  - **Before** (`RefundService.php:68-72`):
    ```php
                $refund->update([
                    'gateway_refund_id' => $result['gateway_refund_id'] ?? null,
                    'status'            => PaymentRefund::STATUS_PROCESSING,
                    'metadata'          => $result['raw'] ?? [],
                ]);
    ```
  - **After:**
    ```php
                $refund->update([
                    'gateway_refund_id' => $result['gateway_refund_id'] ?? null,
                    'status' => PaymentRefund::STATUS_PROCESSING,
                    'metadata' => $result['raw'] ?? [],
                ]);
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Payment/app/Services/RefundService.php`
  - **Expect:** `"result":"passed"`.
  - **Effort:** S

- [ ] **RFD-11** · L · STY-02 · `Modules/Payment/app/Models/PaymentRefund.php:32-37` — Pint-clean the model.
  - **Touches:** `Modules/Payment/app/Models/PaymentRefund.php`
  - **Before** (`PaymentRefund.php:32-37`):
    ```php
        protected $casts = [
            'amount'      => 'float',
            'metadata'    => 'array',
            'refunded_at' => 'datetime',
            'is_active'   => 'boolean',
        ];
    ```
  - **After:**
    ```php
        protected $casts = [
            'amount' => 'float',
            'metadata' => 'array',
            'refunded_at' => 'datetime',
            'is_active' => 'boolean',
        ];
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Payment/app/Models/PaymentRefund.php`
  - **Expect:** `"result":"passed"`.
  - **Effort:** S

- [ ] **RFD-12** · L · STY-02 · `Modules/Payment/app/Events/RefundInitiated.php:1-3` — Pint-clean the event.
  - **Touches:** `Modules/Payment/app/Events/RefundInitiated.php`
  - **Before** (`RefundInitiated.php:1-3`):
    ```php
    <?php
    declare(strict_types=1);
    namespace Modules\Payment\Events;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Payment\Events;
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Payment/app/Events/RefundInitiated.php`
  - **Expect:** `"result":"passed"`.
  - **Effort:** S

- [ ] **RFD-13** · L · STY-02 · `Modules/Payment/app/Events/RefundSucceeded.php:1-3` — Pint-clean the event.
  - **Touches:** `Modules/Payment/app/Events/RefundSucceeded.php`
  - **Before** (`RefundSucceeded.php:1-3`):
    ```php
    <?php
    declare(strict_types=1);
    namespace Modules\Payment\Events;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Payment\Events;
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Payment/app/Events/RefundSucceeded.php`
  - **Expect:** `"result":"passed"`.
  - **Effort:** S

- [ ] **RFD-14** · L · STY-02 · `Modules/Payment/app/Events/RefundFailed.php:1-3` — Pint-clean the event.
  - **Touches:** `Modules/Payment/app/Events/RefundFailed.php`
  - **Before** (`RefundFailed.php:1-3`):
    ```php
    <?php
    declare(strict_types=1);
    namespace Modules\Payment\Events;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Payment\Events;
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Payment/app/Events/RefundFailed.php`
  - **Expect:** `"result":"passed"`.
  - **Effort:** S

- [ ] **RFD-15** · L · STY-02 · `Modules/Payment/app/Listeners/RefundInitiatedListener.php:18-19` — Pint-clean the listener.
  - **Touches:** `Modules/Payment/app/Listeners/RefundInitiatedListener.php`
  - **Before** (`RefundInitiatedListener.php:18-19`):
    ```php
            $refund  = $event->refund;
            $payment = $refund->payment;
    ```
  - **After:**
    ```php
            $refund = $event->refund;
            $payment = $refund->payment;
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Payment/app/Listeners/RefundInitiatedListener.php`
  - **Expect:** `"result":"passed"`.
  - **Effort:** S

- [ ] **RFD-16** · L · STY-02 · `Modules/Payment/app/Listeners/RefundSucceededListener.php:28-30` — Pint-clean the listener.
  - **Touches:** `Modules/Payment/app/Listeners/RefundSucceededListener.php`
  - **Before** (`RefundSucceededListener.php:28-30`):
    ```php
            $refund  = $event->refund;
            $payment = $refund->payment;
            $payable = $payment->payable;
    ```
  - **After:**
    ```php
            $refund = $event->refund;
            $payment = $refund->payment;
            $payable = $payment->payable;
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Payment/app/Listeners/RefundSucceededListener.php`
  - **Expect:** `"result":"passed"`.
  - **Effort:** S

- [ ] **RFD-17** · L · STY-02 · `Modules/Payment/app/Listeners/RefundFailedListener.php:18-19` — Pint-clean the listener.
  - **Touches:** `Modules/Payment/app/Listeners/RefundFailedListener.php`
  - **Before** (`RefundFailedListener.php:18-19`):
    ```php
            $refund  = $event->refund;
            $payment = $refund->payment;
    ```
  - **After:**
    ```php
            $refund = $event->refund;
            $payment = $refund->payment;
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Payment/app/Listeners/RefundFailedListener.php`
  - **Expect:** `"result":"passed"`.
  - **Effort:** S

- [ ] **RFD-18** · L · STY-04 · `Modules/Payment/app/Http/Controllers/RefundController.php:33-35,56-58` — correct the two docblock URLs.
  - **Touches:** `Modules/Payment/app/Http/Controllers/RefundController.php`
  - **Before** (`RefundController.php:33-35`):
    ```php
        /**
         * Initiate a refund for a payment.
         * POST /payment/{ulid}/refund
    ```
  - **After:**
    ```php
        /**
         * Initiate a refund for a payment.
         * POST /api/v1/payments/{ulid}/refund
    ```
  - **Before** (`RefundController.php:56-58`):
    ```php
        /**
         * List all refunds for a payment.
         * GET /payment/{ulid}/refunds
    ```
  - **After:**
    ```php
        /**
         * List all refunds for a payment.
         * GET /api/v1/payments/{ulid}/refunds
    ```
  - **Verify:** `grep -n "payment/{ulid}/refund" Modules/Payment/app/Http/Controllers/RefundController.php`
  - **Expect:** two hits, both on the `/api/v1/payments/` path.
  - **Effort:** S

## 9. Deferred / decisions

No DECISION items. Nothing here needs a migration, a new permission key or a `glb_menus` change.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| RFD-07 | The only fix is an API contract change (array to paginator envelope) for a list that is naturally bounded by one payment. Recorded as accepted; changing it needs the mobile/API client's agreement. |
| RFD-20 | Applied by RFD-03's rewrite (the terminal-status guards are in that item's After blocks), so no separate item is ticked. |
| RFD-22 | RFD-02's gateway-failure catch calls `markRefundFailed`, which makes the method, event and listener live; no additional code change is needed. |
