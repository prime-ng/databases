# Final Audit — Payment / RefundController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/Payment/app/Http/Controllers/RefundController.php` (76 lines, 2 public methods plus `__construct`)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `POST http://SCHOOL-HOST/api/v1/payments/{ulid}/refund` (route name `api.payment.refund.store`) · `GET http://SCHOOL-HOST/api/v1/payments/{ulid}/refunds` (route name `api.payment.refund.index`). Both are JSON-only; this controller renders no page. |
| Menu path | None. This is a mobile/API endpoint, not a menu screen. The only web page that shows refunds is `payment/refunds` (`Backend\RefundController@index`), which is a different controller. |
| Who uses it | API callers authenticated with Sanctum whose role holds `tenant.payment.payment.refund` and `tenant.payment.payment.viewAny`. Measured on tenant `xyz_school_00000000000040008000_202627`: each permission is granted to **2 roles — Super Admin and School Admin** (`sys_role_has_permissions_jnt`). |
| What a user does here | A school administrator (or the mobile app acting for one) starts a refund against a successful payment by sending an amount and a reason. The backend writes a `pending` refund row, calls the payment gateway to move the money, then stores the gateway refund id and marks the row `processing`. A second call lists every refund already recorded against that payment. The final `success`/`failed` state arrives later from the gateway webhook, not from this controller. |
| Tables written | `ptm_payment_refunds` (INSERT + UPDATE), `ptm_payment_audit_logs` (INSERT). On a successful webhook the owned listener also writes `fee_refunds`, `fee_transactions`, `fee_invoices` and `sys_activity_logs`; a full refund updates `ptm_payment_payments.status`. |
| Tables read | `ptm_payment_payments`, `ptm_payment_gateways`, `ptm_payment_refunds`, `ptm_payment_audit_logs`, `sys_permissions`, `sys_role_has_permissions_jnt`, and on the ledger path `fee_transactions`, `fee_invoices`. |
| Live data | Tenant `xyz_school_00000000000040008000_202627`: `ptm_payment_refunds` **0 rows**, `ptm_payment_audit_logs` **0 rows**, `ptm_payment_payments` **60 rows (24 success)**, `ptm_payment_gateways` **2 active**. The refund path has never been exercised on this tenant. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**. There is no browser form for these routes; every reproduction is an authenticated JSON request or a static proof.

## 1. Verdict

**Not production-ready.** The controller is thin, authorized on every method, and the permissions it names exist — but the money path it starts is not safe. The single worst finding is **RFD-02**: the gateway HTTP call runs **inside** the database transaction, so a failure after the call rolls back the local refund row while the gateway has already moved the money — a school can lose a refund with no record of it. Two data-corruption blockers sit beside it: a replayed success webhook re-runs the fee-ledger listener because the transition has **no status guard** (RFD-20), and a partial refund is booked as a **full** refund on the fee transaction (RFD-21). On top of those, the refundable cap counts only successful refunds, so a second request can reach the gateway while the first is still in flight (RFD-19, High — the gateway's own over-refund check is the only remaining guard). One High error item (business refusals return HTTP 500 instead of 422, RFD-01) and one High transaction item (RFD-03) follow; the rest is service hygiene, a dead failure path (RFD-22) and Pint debt. Rough effort to apply the whole plan: **M — about one focused day**, mostly in `RefundService` and the success listener.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 3 | 3 | 3 | 13 | 0 | 22 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | RFD-01 | F8 Services/Jobs | RFD-05, RFD-06 |
| F2 Transactions/Audit | RFD-02, RFD-03 | F9 Queries/Perf | RFD-07 |
| F3 Authorization | RFD-04 | F10 Views | clean — no views (JSON only) |
| F4 Validation | clean — see RFD-01 for the business-cap aspect | F11 Security/Tenancy | RFD-08 |
| F5 Routes | clean | F12 Style | RFD-09 … RFD-18 |
| F6 Controller shape | clean | F13 Deep read | RFD-19, RFD-20, RFD-21, RFD-22 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Payment/app/Http/Controllers/RefundController.php` | controller | 76 | this report | ✅ |
| 2 | `Modules/Payment/routes/api.php` | route file (the two refund routes) | 25 | this report (routes only) | ✅ |
| 3 | `Modules/Payment/app/Http/Requests/InitiateRefundRequest.php` | FormRequest (used only here) | 23 | this report | ✅ |
| 4 | `Modules/Payment/app/Services/RefundService.php` | service | 141 | this report (pre-assigned 00-CLASS-OWNERS line 500) | ✅ |
| 5 | `Modules/Payment/app/Models/PaymentRefund.php` | model | 49 | this report (pre-assigned line 499) | ✅ |
| 6 | `Modules/Payment/app/Events/RefundInitiated.php` | event | 12 | this report (pre-assigned line 501) | ✅ |
| 7 | `Modules/Payment/app/Events/RefundSucceeded.php` | event | 12 | this report (pre-assigned line 502) | ✅ |
| 8 | `Modules/Payment/app/Events/RefundFailed.php` | event | 15 | this report (pre-assigned line 503) | ✅ |
| 9 | `Modules/Payment/app/Listeners/RefundInitiatedListener.php` | listener | 33 | this report (pre-assigned line 504) | ✅ |
| 10 | `Modules/Payment/app/Listeners/RefundSucceededListener.php` | listener | 68 | this report (pre-assigned line 505) | ✅ |
| 11 | `Modules/Payment/app/Listeners/RefundFailedListener.php` | listener | 33 | this report (pre-assigned line 506) | ✅ |
| 12 | `Modules/Payment/app/Models/Payment.php` | model | 101 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked (usage checked) |
| 13 | `Modules/Payment/app/Models/PaymentAuditLog.php` | model | 43 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 14 | `Modules/Payment/app/Services/PaymentService.php` | service (`getByUlid` only) | 182 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked (usage checked) |
| 15 | `Modules/Payment/app/Services/AuditService.php` | service | 104 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked (usage checked) |
| 16 | `Modules/Payment/app/Services/GatewayManager.php` | service | 85 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 17 | `Modules/Payment/app/Policies/PaymentPolicy.php` | policy | 46 | ↗ [tarun/Payment-done/PaymentController](../PaymentController/01-report.md) | ↗ linked (`refund` method checked, not re-audited) |
| 18 | `Modules/Payment/app/Gateways/RazorpayGateway.php` | gateway | 275 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked (HTTP call checked) |
| 19 | `Modules/Payment/app/Gateways/BaseGateway.php`, `Contracts/Payable.php`, `DTO/PaymentData.php` | gateway base / contract / DTO | — | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 20 | `Modules/Payment/app/Events/PaymentSucceeded.php`, `PaymentFailed.php` and their listeners | events / listeners | — | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 21 | `Modules/StudentFee/app/Services/FeeInvoiceService.php`, `Models/FeeTransaction.php`, `Models/FeeInvoice.php` | other-module service/models | — | ↗ `tarun/ParentPortal-done/ParentFeeController` (used through `recordRefund`/`markRefunded`) | ↗ linked (usage checked only) |

No pre-applied files for this controller (only TimetableFoundation has a `PRE-APPLIED-2026-10-10.md`).

The Payment routes are mounted with `api`, tenancy (`InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`), `EnsureTenantIsActive`, `EnsureTenantHasModule:Payment` and `auth:sanctum` (see §4).

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '... RefundController@ ...'
POST      api/v1/payments/{ulid}/refund    api.payment.refund.store    Modules\Payment\Http\Controllers\RefundController@store
GET|HEAD  api/v1/payments/{ulid}/refunds   api.payment.refund.index    Modules\Payment\Http\Controllers\RefundController@index
middleware: api, Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,
            Stancl\Tenancy\Middleware\InitializeTenancyByDomain,
            App\Http\Middleware\EnsureTenantIsActive,
            App\Http\Middleware\EnsureTenantHasModule:Payment,
            Illuminate\Auth\Middleware\Authenticate:sanctum
```

Unrouted public methods: none. `store` and `index` are the only public methods; both are routed. The constructor is not an action.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `store` | 36 | POST `api/v1/payments/{ulid}/refund` | `tenant.payment.payment.refund` (FormRequest + Gate) then `refund` on the Payment policy | service `initiate()` line 38 | `AuditService::log('refund.initiated')` and listener `'refund.initiated.event'` | `ptm_payment_refunds`, `ptm_payment_audit_logs` | RFD-01, RFD-02, RFD-04, RFD-05, RFD-19 |
| `index` | 65 | GET `api/v1/payments/{ulid}/refunds` | `tenant.payment.payment.viewAny` then `refund` on the Payment policy | none (read) | none | none | RFD-07, RFD-08 |
| `RefundService::initiate` | 32 | via `store` | caller-gated | `DB::transaction()` at line 38 | `'refund.initiated'` (service) + `'refund.initiated.event'` (listener) | `ptm_payment_refunds`, `ptm_payment_audit_logs` | RFD-01, RFD-02, RFD-05, RFD-19 |
| `RefundService::markRefundSuccess` | 90 | no (gateway webhook) | webhook signature (outside this controller) | none | `'refund.succeeded'` (service) + `'refund.ledger_updated'` (listener) | `ptm_payment_refunds`, `ptm_payment_payments`, `ptm_payment_audit_logs`, `fee_refunds`, `fee_transactions`, `fee_invoices`, `sys_activity_logs` | RFD-03, RFD-20, RFD-21 |
| `RefundService::markRefundFailed` | 120 | no (gateway webhook) | webhook signature (outside this controller) | none | `'refund.failed'` (service and listener — duplicate) | `ptm_payment_refunds`, `ptm_payment_audit_logs` | RFD-03, RFD-05, RFD-20 |
| `RefundService::getRefundsForPayment` | 137 | via `index` | caller-gated | none (read) | none | none | RFD-07, RFD-08 |
| `RefundInitiatedListener::handle` | 16 | event only | n/a | none (runs inside `initiate`'s transaction) | `'refund.initiated.event'` | `ptm_payment_audit_logs` | RFD-05 |
| `RefundSucceededListener::handle` | 26 | event only | n/a | none (its own `recordRefund` transaction only) | `'refund.ledger_updated'` | `fee_refunds`, `fee_transactions`, `fee_invoices`, `sys_activity_logs`, `ptm_payment_audit_logs` | RFD-03, RFD-21 |
| `RefundFailedListener::handle` | 16 | event only | n/a | none | `'refund.failed'` | `ptm_payment_audit_logs` | RFD-05 |

## 6. Findings

### F1 — Errors

#### RFD-01 · H · ERR-00 (D1/D2) / VAL-07 — a normal refund refusal returns HTTP 500 instead of 422

| Field | Value |
|---|---|
| **Rule** | ERR-00 as settled by D1/D2 — *business-rule messages use `\DomainException`; only the D2 catches are allowed* — combined with VAL-07 (M default, raised to H here: *cross-field/business checks belong in the FormRequest's `after()`*). The service throws `\RuntimeException` and `\InvalidArgumentException`, which are not the D2 business exception, and no FormRequest guard exists, so Laravel's central handler renders them as 500. |
| **Where** | `Modules/Payment/app/Services/RefundService.php:34-52`, method `initiate()` (status guard at 34-36, amount guard at 48-52); caller at `Modules/Payment/app/Http/Controllers/RefundController.php:44-51`, method `store()` |
| **Root cause** | The refusal "payment is not in a refundable state" is thrown as `\RuntimeException`, and "amount exceeds max refundable" as `\InvalidArgumentException`. D2 reserves business-rule refusals for `\DomainException`, and the controller has no D2 catch; `bootstrap/app.php` maps any non-HTTP exception to a 500 JSON response. The amount check is also not in `InitiateRefundRequest`, so a user error never becomes a 422 validation response. |
| **Consequence** | A School Admin who tries to refund a payment that is already refunded, or asks for more than remains, sees "Server Error" (and, outside production, the raw internal message) instead of a readable 422 telling them why the refund was refused. |
| **Reproduce** | Send `POST /api/v1/payments/{ulid-of-a-refunded-payment}/refund` with `{"amount":100,"reason":"test"}` and a token holding `tenant.payment.payment.refund`. Expected 422 with a business message; actual 500 `{"success":false,"message":"Cannot refund payment in status: refunded"}` (non-production). |
| **Fix approach** | Throw `\DomainException` for both business refusals in the service, and add the one D2-sanctioned `catch (\DomainException $e)` around the service call in `store()` returning HTTP 422. Keep the checks inside the transaction (the race guard is RFD-19). |
| **Plan item** | RFD-01 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n "RuntimeException\|InvalidArgumentException" …` and the central handler's 500 branch (output below) |

```php
// RefundService.php:34-52 — CURRENT
        if ($payment->status !== Payment::STATUS_SUCCESS) {
            throw new \RuntimeException("Cannot refund payment in status: {$payment->status}");
        }

        return DB::transaction(function () use ($payment, $amount, $reason, $userId) {
            // Re-fetch and lock the payment row to prevent concurrent refunds.
            $freshPayment = Payment::lockForUpdate()->findOrFail($payment->id);

            $refundedSoFar = PaymentRefund::where('payment_id', $freshPayment->id)
                ->where('status', PaymentRefund::STATUS_SUCCESS)
                ->sum('amount');

            $maxRefundable = $freshPayment->amount - $refundedSoFar;

            if ($amount > $maxRefundable) {
                throw new \InvalidArgumentException(
                    "Refund amount ({$amount}) exceeds max refundable amount ({$maxRefundable})"
                );
            }
```

**Evidence**
```
$ grep -n "RuntimeException\|InvalidArgumentException" Modules/Payment/app/Services/RefundService.php
35:            throw new \RuntimeException("Cannot refund payment in status: {$payment->status}");
49:                throw new \InvalidArgumentException(

$ sed -n '138,149p' bootstrap/app.php
            if ($request->expectsJson() || $request->is('api/*')) {
                $message = app()->isProduction()
                    ? 'An unexpected error occurred.'
                    : $e->getMessage();

                return response()->json([
                    'success' => false,
                    'message' => $message,
                ], 500);
            }
```

### F2 — Transactions and audit

#### RFD-02 · B · TXN-03 — the gateway HTTP call runs inside the database transaction

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B) — *no irreversible side effect inside a transaction or before the write succeeds: file deletes, mail, SMS, push, HTTP calls* |
| **Where** | `Modules/Payment/app/Services/RefundService.php:65-66`, method `initiate()`, inside the `DB::transaction` opened at line 38 |
| **Root cause** | `$driver->refund(...)` performs a Razorpay API call (HTTP) while the transaction is open. If anything after it fails — the `update()`, the audit insert, the synchronous listener, a deadlock — the transaction rolls back and the local refund row disappears, but the gateway has already moved the money. The payment row is also locked for the whole network round-trip. |
| **Consequence** | A school can lose money with no local refund record: Razorpay reports a refund, the school's database shows none, and the payment still looks refundable. A slow gateway also blocks every other refund on that payment for the duration. |
| **Reproduce** | Static only — reproducing requires a gateway failure after the HTTP call, which this read-only audit cannot trigger (D4, no credentials). The code path is unambiguous: line 66 is inside the closure at line 38. |
| **Fix approach** | Commit the `pending` refund first (reservation), call the gateway **outside** any transaction, then open a second short transaction to store the gateway result, audit row and event. On a gateway exception, mark the refund failed and rethrow a `\DomainException` (RFD-01 returns 422). The cap fix RFD-19 must land first so the reservation is counted. |
| **Plan item** | RFD-02 in `02-fix-plan.md` §1 |
| **Evidence** | `grep -n "DB::transaction\|driver->refund\|gatewayManager->resolve" …` (output below) |

```php
// RefundService.php:63-72 — CURRENT
            ]);

            $driver = $this->gatewayManager->resolve($payment->gateway->code);
            $result = $driver->refund($payment, $amount);

            $refund->update([
                'gateway_refund_id' => $result['gateway_refund_id'] ?? null,
                'status'            => PaymentRefund::STATUS_PROCESSING,
                'metadata'          => $result['raw'] ?? [],
            ]);
```

**Evidence**
```
$ grep -n "DB::transaction\|driver->refund\|gatewayManager->resolve" Modules/Payment/app/Services/RefundService.php
38:        return DB::transaction(function () use ($payment, $amount, $reason, $userId) {
65:            $driver = $this->gatewayManager->resolve($payment->gateway->code);
66:            $result = $driver->refund($payment, $amount);
```

#### RFD-03 · H · TXN-01 — the success and failure webhook transitions write several tables with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (two models, a model + its audit row, a model + pivot) runs inside one `DB::transaction`* |
| **Where** | `Modules/Payment/app/Services/RefundService.php:90-115` (`markRefundSuccess`) and `120-132` (`markRefundFailed`) |
| **Root cause** | `markRefundSuccess` updates `ptm_payment_refunds`, may update `ptm_payment_payments`, writes `ptm_payment_audit_logs`, dispatches `RefundSucceeded` whose synchronous listener writes `fee_refunds`, `fee_transactions`, `fee_invoices` and `sys_activity_logs`, then writes another `ptm_payment_audit_logs` row — all with no transaction. `markRefundFailed` updates the refund and writes the audit row without one. If any later write fails, the earlier ones stay committed. |
| **Consequence** | A webhook can mark a refund successful and then fail to record the fee refund (or the reverse), leaving the payment module and the fee ledger permanently disagreeing. Queue retries then re-run a partially-applied transition. |
| **Reproduce** | Static only — inducing a failure between the writes needs a code change. The scanner independently flags `markRefundSuccess` at line 90: "2 writes with no transaction". |
| **Fix approach** | Wrap each method body in `DB::transaction`, re-fetch the refund with `lockForUpdate()` inside it, and dispatch the event inside the transaction so the synchronous listener's writes share the same atomic unit. RFD-20 adds the status guards afterwards. |
| **Plan item** | RFD-03 in `02-fix-plan.md` §1 |
| **Evidence** | `grep -n "function markRefund\|DB::transaction\|lockForUpdate" …` and the scanner row (output below) |

```php
// RefundService.php:90-105 — CURRENT
    public function markRefundSuccess(PaymentRefund $refund, array $payload = []): void
    {
        $refund->update([
            'status'      => PaymentRefund::STATUS_SUCCESS,
            'refunded_at' => now(),
        ]);

        // If fully refunded, mark payment as refunded
        $payment = $refund->payment;
        $totalRefunded = $payment->refunds()
            ->where('status', PaymentRefund::STATUS_SUCCESS)
            ->sum('amount');

        if ($totalRefunded >= $payment->amount) {
            $payment->update(['status' => Payment::STATUS_REFUNDED]);
        }
```

**Evidence**
```
$ grep -n "function markRefundSuccess\|function markRefundFailed\|DB::transaction\|lockForUpdate" Modules/Payment/app/Services/RefundService.php
38:        return DB::transaction(function () use ($payment, $amount, $reason, $userId) {
40:            $freshPayment = Payment::lockForUpdate()->findOrFail($payment->id);
90:    public function markRefundSuccess(PaymentRefund $refund, array $payload = []): void
120:    public function markRefundFailed(PaymentRefund $refund, string $reason, array $payload = []): void

$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-rfd.json Modules/Payment/app/Services/RefundService.php
H  TXN-01   Modules/Payment/app/Services/RefundService.php:90  markRefundSuccess — markRefundSuccess() makes 2 writes with no transaction
```

### F3 — Authorization

#### RFD-04 · L · AUTH-04 — the same refund permission is checked three times

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/Payment/app/Http/Controllers/RefundController.php:36-42`, method `store()`; also `Modules/Payment/app/Http/Requests/InitiateRefundRequest.php:13` and `Modules/Payment/app/Policies/PaymentPolicy.php:37-40` |
| **Root cause** | `InitiateRefundRequest::authorize()` checks `tenant.payment.payment.refund`, the controller repeats the same string through `Gate::authorize`, and the policy `refund` method checks it a third time. All three resolve to the same seeded permission; none adds a record-ownership rule. |
| **Consequence** | No user-visible defect today. It is three places to update when the permission changes, and it hides which check is authoritative. |
| **Reproduce** | Static only — the permission is seeded and granted to Super Admin and School Admin, so the calls all succeed together. |
| **Fix approach** | Keep the FormRequest check (it runs first, before validation and before the record load) and the model-level policy check; remove the controller's duplicate string gate on line 38. |
| **Plan item** | RFD-04 in `02-fix-plan.md` §4 |
| **Evidence** | `grep -n "Gate::authorize\|can(" …` (output below) |

```php
// RefundController.php:36-42 — CURRENT
    public function store(InitiateRefundRequest $request, string $ulid): JsonResponse
    {
        Gate::authorize('tenant.payment.payment.refund');

        $payment = $this->paymentService->getByUlid($ulid);

        Gate::authorize('refund', $payment);
```

**Evidence**
```
$ grep -n "Gate::authorize\|can(" Modules/Payment/app/Http/Controllers/RefundController.php Modules/Payment/app/Http/Requests/InitiateRefundRequest.php Modules/Payment/app/Policies/PaymentPolicy.php
Modules/Payment/app/Http/Controllers/RefundController.php:38:        Gate::authorize('tenant.payment.payment.refund');
Modules/Payment/app/Http/Controllers/RefundController.php:42:        Gate::authorize('refund', $payment);
Modules/Payment/app/Http/Requests/InitiateRefundRequest.php:13:        return auth()->check() && auth()->user()->can('tenant.payment.payment.refund');
Modules/Payment/app/Policies/PaymentPolicy.php:39:        return $user->can('tenant.payment.payment.refund');

$ php -r '... PermissionHelper::flatten("tenant") ...'
tenant.payment.payment.refund => PRESENT
tenant.payment.payment.viewAny => PRESENT
tenant.payment.payment.view => PRESENT
```

### F4 — Validation and input

Clean — `InitiateRefundRequest` validates both inputs (`required`, `numeric`, `min:0.01`, `string`, `max:500`); the controller reads only `validated('amount')` and `validated('reason')`, never `all()`/`except()`. The one validation gap — the amount-versus-refundable-balance business rule is not in the FormRequest — is tracked as RFD-01. Evidence: `grep -n "validated\|rules\|authorize" Modules/Payment/app/Http/Requests/InitiateRefundRequest.php` shows the four rules and `validated()` at the two call sites.

### F5 — Routes

Clean — both routes are POST/GET as appropriate (no state change over GET), both point at existing public methods, no unrouted public method exists, the custom routes precede the `payments/{ulid}` show route, the `{ulid}` parameter matches the `$ulid` argument, and the module RouteServiceProvider wraps the api file in tenancy + `auth:sanctum`. Evidence: the `route:list` output in §4 and `grep -nE 'public function' RefundController.php` → `store` line 36, `index` line 65.

### F6 — Controller shape

Clean — 76 lines, 2 public methods, both under 30 lines; the controller reads input, calls one service method, and returns JSON. Return types are declared (`JsonResponse`). No `dd()`/`dump()`, no dead code, no copy-paste block, no `compact()`. Evidence: `wc -l` 76 and the manual size threshold in CTL-01/CTL-02 (1,000 lines / 80 lines per method).

### F7 — Models

Clean — `PaymentRefund` declares `$fillable` (no sensitive field is exposed for mass assignment), `$table = 'ptm_payment_refunds'` exists in `2026_06_18_100103_create_ptm_payment_refunds_table.php` (first `Create` at line 15), `SoftDeletes` matches the `deleted_at` column, `payment()` is return-typed `BelongsTo`, and every boolean/date/json column is cast. The `amount` cast is `float` (matching `Payment`), which is acceptable at two decimal places but not ideal for money; it is recorded here rather than as a finding because changing it would turn the JSON `amount` into a string and break the API contract. Evidence: `grep -n "table\|fillable\|casts\|SoftDeletes\|function payment" Modules/Payment/app/Models/PaymentRefund.php` and the migration's `Schema::create`.

### F8 — Services and jobs

#### RFD-05 · M · SVC-04 — `refund.initiated` and `refund.failed` are each written to the audit trail twice

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *one implementation per business operation; copies that disagree are a bug source* |
| **Where** | `Modules/Payment/app/Services/RefundService.php:74-79` and `124-129`; duplicated in `Modules/Payment/app/Listeners/RefundInitiatedListener.php:21-31` and `Modules/Payment/app/Listeners/RefundFailedListener.php:21-31` |
| **Root cause** | The service writes its own audit row and then dispatches an event whose only listener writes a second audit row for the same business fact. For failure the event literal is even identical (`refund.failed`), so the payment timeline shows two indistinguishable entries. |
| **Consequence** | Anyone reading the payment audit timeline sees every refund start and every refund failure twice, which makes reconciliation harder and can make a single gateway event look like two attempts. |
| **Reproduce** | Open the payment detail API (`GET /api/v1/payments/{ulid}`) after a refund attempt and count the `ptm_payment_audit_logs` rows with `refund.initiated` / `refund.failed`; the live tenant has 0 refunds, so this is static on test. |
| **Fix approach** | Keep the listener as the single writer (it has the richer payload, including `gateway_refund_id`) and remove the service's two direct `auditService->log` calls; rename the initiated listener literal from `refund.initiated.event` to `refund.initiated` so it matches the event name. |
| **Plan item** | RFD-05 in `02-fix-plan.md` §3 (the failed-log removal is included in RFD-03's rewrite; see the item note) |
| **Evidence** | `grep -n "auditService->log\|event(" …` (output below) |

```php
// RefundService.php:74-81 — CURRENT
            $this->auditService->log(
                payment: $payment,
                event: 'refund.initiated',
                payload: ['refund_ulid' => $refund->ulid, 'amount' => $amount, 'reason' => $reason],
                actorType: 'system',
            );

            event(new RefundInitiated($refund));
```

**Evidence**
```
$ grep -n "auditService->log\|event(" Modules/Payment/app/Services/RefundService.php Modules/Payment/app/Listeners/RefundInitiatedListener.php Modules/Payment/app/Listeners/RefundFailedListener.php
Modules/Payment/app/Services/RefundService.php:74:            $this->auditService->log(
Modules/Payment/app/Services/RefundService.php:81:            event(new RefundInitiated($refund));
Modules/Payment/app/Services/RefundService.php:107:        $this->auditService->log(
Modules/Payment/app/Services/RefundService.php:114:        event(new RefundSucceeded($refund->fresh()));
Modules/Payment/app/Services/RefundService.php:124:        $this->auditService->log(
Modules/Payment/app/Services/RefundService.php:131:        event(new RefundFailed($refund->fresh(), $reason));
Modules/Payment/app/Listeners/RefundInitiatedListener.php:21:        $this->auditService->log(
Modules/Payment/app/Listeners/RefundFailedListener.php:21:        $this->auditService->log(
```

#### RFD-06 · M · SVC-02 — the success listener resolves `FeeInvoiceService` through the service locator

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection, not `new FooService()` or `app(Foo::class)` mid-method* |
| **Where** | `Modules/Payment/app/Listeners/RefundSucceededListener.php:44-52`, method `handle()` |
| **Root cause** | The listener already receives `AuditService` by constructor but reaches for `FeeInvoiceService` with `app()` inside `handle()`. The dependency is invisible to the container contract and harder to fake or replace. |
| **Consequence** | No user-visible defect; it is a testability and discoverability cost on the most consequential listener in the refund flow. |
| **Reproduce** | Static only — the call succeeds at runtime because the container can build the service. |
| **Fix approach** | Add `private readonly FeeInvoiceService $feeInvoiceService` to the constructor and call `$this->feeInvoiceService->recordRefund(...)`. |
| **Plan item** | RFD-06 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n "app(FeeInvoiceService" …` (output below) |

```php
// RefundSucceededListener.php:44-52 — CURRENT
        /** @var FeeInvoiceService $service */
        $service = app(FeeInvoiceService::class);

        $service->recordRefund(
            transaction: $transaction,
            amount: $refund->amount,
            reason: $refund->reason,
            refundReference: $refund->gateway_refund_id,
        );
```

**Evidence**
```
$ grep -n "app(FeeInvoiceService" Modules/Payment/app/Listeners/RefundSucceededListener.php
45:        $service = app(FeeInvoiceService::class);
```

### F9 — Queries and performance

#### RFD-07 · L · QRY-02 — the refund list is an unbounded `get()`

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H default, lowered to L — *refunds are naturally bounded by one payment and the endpoint is a single-payment detail list, not a table page; there is no cross-payment scan*) — *lists are paginated* |
| **Where** | `Modules/Payment/app/Services/RefundService.php:137-140` and `Modules/Payment/app/Http/Controllers/RefundController.php:70-71` |
| **Root cause** | `getRefundsForPayment()` returns every refund row for the payment with no `paginate()`/limit, and the controller serializes the whole collection. |
| **Consequence** | A payment refunded in many small parts returns an ever-growing JSON array in one response; for normal use (0–5 partial refunds) this is not a real problem. |
| **Reproduce** | Static only — the live tenant has 0 refunds, so there is no large list to measure. |
| **Fix approach** | This is an API contract change (array to paginator object), so it is recorded as accepted for now in §10 rather than planned. If the client already handles a paginated envelope, switch to `paginate(10, ['*'], 'refund_page')` with a distinct page name. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `grep -n "refunds()->latest()->get\|json($refunds)" …` (output below) |

```php
// RefundService.php:137-140 — CURRENT
    public function getRefundsForPayment(Payment $payment)
    {
        return $payment->refunds()->latest()->get();
    }
```

**Evidence**
```
$ grep -n "refunds()->latest()->get\|json(\$refunds)" Modules/Payment/app/Services/RefundService.php Modules/Payment/app/Http/Controllers/RefundController.php
Modules/Payment/app/Services/RefundService.php:139:        return $payment->refunds()->latest()->get();
Modules/Payment/app/Http/Controllers/RefundController.php:72:        return response()->json($refunds);
```

### F10 — Views

Clean — this controller renders no Blade view; both methods return `JsonResponse`. Evidence: `grep -n "view(" Modules/Payment/app/Http/Controllers/RefundController.php` → no output.

### F11 — Security and tenancy

#### RFD-08 · M · SEC-02 — `index` returns whole `PaymentRefund` models, including internal ids and raw gateway metadata

| Field | Value |
|---|---|
| **Rule** | SEC-02 (H default, lowered to M — *the exposed fields are internal integer ids, flags and the gateway's refund entity; no student/parent PII and no card data is written by Razorpay's refund object, so this is over-exposure rather than a personal-data leak*) — *JSON endpoints return mapped arrays / API Resources, not full models* |
| **Where** | `Modules/Payment/app/Http/Controllers/RefundController.php:70-72`, method `index()`, via `Modules/Payment/app/Services/RefundService.php:137-140` |
| **Root cause** | `getRefundsForPayment()` returns Eloquent models with every column, and `response()->json($refunds)` serializes them directly. `PaymentRefund` declares no `$hidden`, so `id`, `payment_id`, `initiated_by`, `created_by`, `is_active` and the entire `metadata` JSON (the raw gateway refund entity) are sent to the client. |
| **Consequence** | Any API consumer of the refunds list receives internal database ids and the gateway's raw response, which is more than the endpoint's documented fields (ulid, amount, status, reason, gateway id, date) and couples the client to the table shape. |
| **Reproduce** | Authenticated `GET /api/v1/payments/{ulid}/refunds`; the response contains `id`, `payment_id`, `metadata` and audit ids. The live tenant has 0 refunds, so this is proven statically from the serializer path. |
| **Fix approach** | Select only the six public columns in the service and map each row to an explicit array in the controller before `response()->json()`. |
| **Plan item** | RFD-08 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n "json($refunds)\|hidden" …` and the model's absence of `$hidden` (output below) |

```php
// RefundController.php:70-72 — CURRENT
        $refunds = $this->refundService->getRefundsForPayment($payment);
        return response()->json($refunds);
```

**Evidence**
```
$ grep -n "json(\$refunds)" Modules/Payment/app/Http/Controllers/RefundController.php
72:        return response()->json($refunds);

$ grep -n "hidden" Modules/Payment/app/Models/PaymentRefund.php
(no output — the model does not hide any column)

$ sed -n '16,30p' Modules/Payment/app/Models/PaymentRefund.php
    protected $table = 'ptm_payment_refunds';

    protected $fillable = [
        'ulid',
        'payment_id',
        'amount',
        'reason',
        'status',
        'gateway_refund_id',
        'metadata',
        'initiated_by',
        'refunded_at',
        'is_active',
        'created_by',
    ];
```

### F12 — Style

#### RFD-09 · L · STY-02 — `RefundController.php` is not Pint-clean (import order, alignment, blank line)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines between imports* |
| **Where** | `Modules/Payment/app/Http/Controllers/RefundController.php:7-12,50-53,71-72` |
| **Root cause** | Import order puts `Illuminate\Support\Facades\Gate` before `App\Http\Controllers\Controller`; the refund response array is arrow-aligned; a blank line is missing before the return in `index()`. |
| **Consequence** | No runtime effect; it fails the repository's Pint gate and makes every later diff noisier. |
| **Reproduce** | `vendor/bin/pint --test Modules/Payment/app/Http/Controllers/RefundController.php` → `result: fail`. |
| **Fix approach** | Run Pint on this file only. |
| **Plan item** | RFD-09 in `02-fix-plan.md` §8 |
| **Evidence** | Pint output below |

```php
// RefundController.php:7-12 — CURRENT
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Modules\Payment\Http\Requests\InitiateRefundRequest;
use Modules\Payment\Services\PaymentService;
use Modules\Payment\Services\RefundService;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/Payment/app/Http/Controllers/RefundController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Http\/Controllers\/RefundController.php","fixers":["braces_position","single_line_empty_body","blank_line_before_statement","ordered_imports","binary_operator_spaces"]}]}
```

#### RFD-10 · L · STY-02 — `RefundService.php` is not Pint-clean (phpdoc, alignment)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Payment/app/Services/RefundService.php:23-30,54-63,68-72` |
| **Root cause** | The docblock keeps a `@return PaymentRefund` tag Pint removes, and both write arrays use arrow alignment Pint strips. |
| **Consequence** | No runtime effect; it fails the Pint gate. |
| **Reproduce** | `vendor/bin/pint --test Modules/Payment/app/Services/RefundService.php` → `result: fail`. |
| **Fix approach** | Run Pint on this file only. |
| **Plan item** | RFD-10 in `02-fix-plan.md` §8 |
| **Evidence** | Pint output below |

```php
// RefundService.php:68-72 — CURRENT
            $refund->update([
                'gateway_refund_id' => $result['gateway_refund_id'] ?? null,
                'status'            => PaymentRefund::STATUS_PROCESSING,
                'metadata'          => $result['raw'] ?? [],
            ]);
```

**Evidence**
```
$ vendor/bin/pint --test Modules/Payment/app/Services/RefundService.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Services\/RefundService.php","fixers":["no_superfluous_phpdoc_tags","braces_position","single_line_empty_body","binary_operator_spaces","phpdoc_align"]}]}
```

#### RFD-11 · L · STY-02 — `PaymentRefund.php` is not Pint-clean (imports, casts alignment, constant spacing)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Payment/app/Models/PaymentRefund.php:7-10,32-42` |
| **Root cause** | `HasFactory` is imported before `BaseModel`, the casts array is arrow-aligned, and the status constants are aligned without the blank lines Pint requires. |
| **Consequence** | No runtime effect; it fails the Pint gate. |
| **Reproduce** | `vendor/bin/pint --test Modules/Payment/app/Models/PaymentRefund.php` → `result: fail`. |
| **Fix approach** | Run Pint on this file only. |
| **Plan item** | RFD-11 in `02-fix-plan.md` §8 |
| **Evidence** | Pint output below |

```php
// PaymentRefund.php:32-37 — CURRENT
    protected $casts = [
        'amount'      => 'float',
        'metadata'    => 'array',
        'refunded_at' => 'datetime',
        'is_active'   => 'boolean',
    ];
```

**Evidence**
```
$ vendor/bin/pint --test Modules/Payment/app/Models/PaymentRefund.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Models\/PaymentRefund.php","fixers":["class_attributes_separation","ordered_imports","binary_operator_spaces"]}]}
```

#### RFD-12 · L · STY-02 — `RefundInitiated.php` is not Pint-clean (blank lines)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Payment/app/Events/RefundInitiated.php:1-8` |
| **Root cause** | The opening tag, `declare`, namespace and imports are packed with no blank lines, and the trait/constructor are not separated. |
| **Consequence** | No runtime effect; it fails the Pint gate. |
| **Reproduce** | `vendor/bin/pint --test Modules/Payment/app/Events/RefundInitiated.php` → `result: fail`. |
| **Fix approach** | Run Pint on this file only. |
| **Plan item** | RFD-12 in `02-fix-plan.md` §8 |
| **Evidence** | Pint output below |

```php
// RefundInitiated.php:1-8 — CURRENT
<?php
declare(strict_types=1);
namespace Modules\Payment\Events;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Modules\Payment\Models\PaymentRefund;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/Payment/app/Events/RefundInitiated.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Events\/RefundInitiated.php","fixers":["class_attributes_separation","blank_line_after_opening_tag","braces_position","single_line_empty_body","blank_line_after_namespace","blank_lines_before_namespace"]}]}
```

#### RFD-13 · L · STY-02 — `RefundSucceeded.php` is not Pint-clean (blank lines)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Payment/app/Events/RefundSucceeded.php:1-8` |
| **Root cause** | Same packed layout as `RefundInitiated.php`: no blank line after the opening tag, `declare`, namespace or imports. |
| **Consequence** | No runtime effect; it fails the Pint gate. |
| **Reproduce** | `vendor/bin/pint --test Modules/Payment/app/Events/RefundSucceeded.php` → `result: fail`. |
| **Fix approach** | Run Pint on this file only. |
| **Plan item** | RFD-13 in `02-fix-plan.md` §8 |
| **Evidence** | Pint output below |

```php
// RefundSucceeded.php:1-8 — CURRENT
<?php
declare(strict_types=1);
namespace Modules\Payment\Events;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Modules\Payment\Models\PaymentRefund;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/Payment/app/Events/RefundSucceeded.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Events\/RefundSucceeded.php","fixers":["class_attributes_separation","blank_line_after_opening_tag","braces_position","single_line_empty_body","blank_line_after_namespace","blank_lines_before_namespace"]}]}
```

#### RFD-14 · L · STY-02 — `RefundFailed.php` is not Pint-clean (blank lines)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Payment/app/Events/RefundFailed.php:1-10` |
| **Root cause** | The same packed header as the other two events; the promoted properties also need the class-attribute separation. |
| **Consequence** | No runtime effect; it fails the Pint gate. |
| **Reproduce** | `vendor/bin/pint --test Modules/Payment/app/Events/RefundFailed.php` → `result: fail`. |
| **Fix approach** | Run Pint on this file only. |
| **Plan item** | RFD-14 in `02-fix-plan.md` §8 |
| **Evidence** | Pint output below |

```php
// RefundFailed.php:1-10 — CURRENT
<?php
declare(strict_types=1);
namespace Modules\Payment\Events;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Modules\Payment\Models\PaymentRefund;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/Payment/app/Events/RefundFailed.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Events\/RefundFailed.php","fixers":["class_attributes_separation","blank_line_after_opening_tag","braces_position","single_line_empty_body","blank_line_after_namespace","blank_lines_before_namespace"]}]}
```

#### RFD-15 · L · STY-02 — `RefundInitiatedListener.php` is not Pint-clean (alignment)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Payment/app/Listeners/RefundInitiatedListener.php:18-19` |
| **Root cause** | The two local assignments are aligned with two spaces; Pint uses one. |
| **Consequence** | No runtime effect; it fails the Pint gate. |
| **Reproduce** | `vendor/bin/pint --test Modules/Payment/app/Listeners/RefundInitiatedListener.php` → `result: fail`. |
| **Fix approach** | Run Pint on this file only. |
| **Plan item** | RFD-15 in `02-fix-plan.md` §8 |
| **Evidence** | Pint output below |

```php
// RefundInitiatedListener.php:18-19 — CURRENT
        $refund  = $event->refund;
        $payment = $refund->payment;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/Payment/app/Listeners/RefundInitiatedListener.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Listeners\/RefundInitiatedListener.php","fixers":["braces_position","single_line_empty_body","binary_operator_spaces"]}]}
```

#### RFD-16 · L · STY-02 — `RefundSucceededListener.php` is not Pint-clean (FQCN, alignment, imports)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Payment/app/Listeners/RefundSucceededListener.php:28-30,44-66` |
| **Root cause** | The local assignments are aligned, and the `instanceof` uses the fully-qualified `\Modules\StudentFee\Models\FeeInvoice` instead of an import (Pint's `fully_qualified_strict_types`). |
| **Consequence** | No runtime effect; it fails the Pint gate. |
| **Reproduce** | `vendor/bin/pint --test Modules/Payment/app/Listeners/RefundSucceededListener.php` → `result: fail`. |
| **Fix approach** | Run Pint on this file only. |
| **Plan item** | RFD-16 in `02-fix-plan.md` §8 |
| **Evidence** | Pint output below |

```php
// RefundSucceededListener.php:28-30 — CURRENT
        $refund  = $event->refund;
        $payment = $refund->payment;
        $payable = $payment->payable;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/Payment/app/Listeners/RefundSucceededListener.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Listeners\/RefundSucceededListener.php","fixers":["fully_qualified_strict_types","unary_operator_spaces","braces_position","not_operator_with_successor_space","single_line_empty_body","ordered_imports","binary_operator_spaces"]}]}
```

#### RFD-17 · L · STY-02 — `RefundFailedListener.php` is not Pint-clean (alignment)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Payment/app/Listeners/RefundFailedListener.php:18-19` |
| **Root cause** | The two local assignments are aligned with two spaces; Pint uses one. |
| **Consequence** | No runtime effect; it fails the Pint gate. |
| **Reproduce** | `vendor/bin/pint --test Modules/Payment/app/Listeners/RefundFailedListener.php` → `result: fail`. |
| **Fix approach** | Run Pint on this file only. |
| **Plan item** | RFD-17 in `02-fix-plan.md` §8 |
| **Evidence** | Pint output below |

```php
// RefundFailedListener.php:18-19 — CURRENT
        $refund  = $event->refund;
        $payment = $refund->payment;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/Payment/app/Listeners/RefundFailedListener.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Listeners\/RefundFailedListener.php","fixers":["braces_position","single_line_empty_body","binary_operator_spaces"]}]}
```

#### RFD-18 · L · STY-04 — the docblocks name a route that does not exist

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *English comments that describe the right resource; no copy-pasted or stale docblocks* |
| **Where** | `Modules/Payment/app/Http/Controllers/RefundController.php:33-35,56-58` |
| **Root cause** | Both docblocks document `/payment/{ulid}/...` (singular, no `api/v1`), while the registered URIs are `/api/v1/payments/{ulid}/refund` and `/api/v1/payments/{ulid}/refunds` (plural). |
| **Consequence** | A developer or API consumer reading the controller documents the wrong URL and gets 404 when they call it. |
| **Reproduce** | Compare the docblock with the route list in §4. |
| **Fix approach** | Correct both docblock URLs to the real `api/v1/payments/...` paths. |
| **Plan item** | RFD-18 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -n "payment/{ulid}" …` and the §4 route output (below) |

```php
// RefundController.php:33-35 — CURRENT
    /**
     * Initiate a refund for a payment.
     * POST /payment/{ulid}/refund
```

**Evidence**
```
$ grep -n "payment/{ulid}" Modules/Payment/app/Http/Controllers/RefundController.php
34:     * POST /payment/{ulid}/refund
57:     * GET /payment/{ulid}/refunds

$ php artisan route:list --json | grep RefundController
POST api/v1/payments/{ulid}/refund  api.payment.refund.store  RefundController@store
GET  api/v1/payments/{ulid}/refunds api.payment.refund.index  RefundController@index
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutation (method) | 1 wrong-data overwrite | 2 delete-before-store | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` → `RefundService::initiate` (`ptm_payment_refunds` INSERT) | RFD-19 (cap under-counts in-flight refunds) | ok — no deletes | ok — one initiate path | ok — `ulid` and `gateway_refund_id` unique; no user-supplied unique key | RFD-19 (second request passes while the first is pending/processing) | ok — FormRequest + policy gate (RFD-04 is duplication only) | RFD-01 (500 instead of 422); RFD-18 (wrong URL in docblock) | ⚠ UNVERIFIED — no in-repo client for these routes |
| `markRefundSuccess` (webhook → `RefundSucceededListener`) | RFD-20 (replay re-runs the ledger), RFD-21 (partial booked as full) | ok — no deletes | RFD-05 (duplicate audit rows) | ok | RFD-20 (no status guard/lock at entry) | n/a — webhook signature is checked in the gateway (outside this controller) | ok — audit literal `refund.succeeded` accurate | ok — called by `RazorpayGateway::handleRefundProcessed` |
| `markRefundFailed` (service) | RFD-20 (a late failure can flip a success, once the method is wired) | ok | RFD-05 (same `refund.failed` literal in service and listener) | ok | RFD-20 | n/a — webhook path | ok | **RFD-22 — no caller anywhere** |
| `RefundSucceededListener::handle` | RFD-21 (partial amount) | ok — no deletes | ok — single ledger writer | n/a — no soft-delete on `fee_refunds` | RFD-20 (replay) | n/a | ok — `refund.ledger_updated` accurate | ok — registered and dispatched |
| `RefundInitiatedListener::handle` (audit INSERT) | ok | ok | RFD-05 (duplicate with service) | n/a | ok | n/a | ok after RFD-05's literal rename | ok — registered and dispatched |
| `RefundFailedListener::handle` (audit INSERT) | ok | ok | RFD-05 | n/a | ok | n/a | ok | **RFD-22 — the event is never dispatched** |
| `getRefundsForPayment` (read) | n/a — read only | n/a | ok | n/a | n/a | n/a | RFD-07/RFD-08 (raw models, no paging) | ok — used by `index` |

#### RFD-19 · H · TXN-06 — the refundable cap ignores in-flight refunds, so a second refund attempt can pass the local guard

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/Payment/app/Services/RefundService.php:42-46`, method `initiate()` |
| **Root cause** | `$refundedSoFar` sums only refunds whose status is `success`. A refund that has just been created is `pending`, and becomes `processing` after the gateway call; it is not counted until the asynchronous webhook marks it `success`. The payment row lock serializes the two requests, but each one sees a refunded total of zero (or only older successes) and passes `$amount > $maxRefundable`. There is no unique idempotency key on the request either. |
| **Consequence** | A double-click or two admins refunding at once makes the second request reach the gateway even though the first has already reserved the money. Whether the school actually loses money then depends on the gateway's server-side over-refund check: Razorpay is expected to reject the second request, but that check is the only remaining guard and was not exercised here (⚠ UNVERIFIED for every driver). At minimum the user gets a gateway error (and, with RFD-01 unfixed, a 500) instead of a clean "amount already reserved" refusal, and a failed refund row is left behind. |
| **Reproduce** | Fire two `POST /api/v1/payments/{ulid}/refund` calls for ₹1,000 each against a ₹1,000 successful payment before the first webhook arrives. Both pass the local cap. Razorpay is expected to reject the second; the local guard is proven broken statically because only `STATUS_SUCCESS` is summed. |
| **Fix approach** | Count `pending`, `processing` **and** `success` refunds against the cap inside the same locked transaction (failed refunds are excluded, so a gateway failure releases the reservation). Apply before RFD-02 moves the HTTP call out, because the reservation is what protects the gap. |
| **Plan item** | RFD-19 in `02-fix-plan.md` §1 |
| **Evidence** | `sed -n '38,52p' …` and `grep -n "STATUS_SUCCESS" …` (output below) |

```php
// RefundService.php:42-46 — CURRENT
            $refundedSoFar = PaymentRefund::where('payment_id', $freshPayment->id)
                ->where('status', PaymentRefund::STATUS_SUCCESS)
                ->sum('amount');

            $maxRefundable = $freshPayment->amount - $refundedSoFar;
```

**Evidence**
```
$ sed -n '38,52p' Modules/Payment/app/Services/RefundService.php
        return DB::transaction(function () use ($payment, $amount, $reason, $userId) {
            // Re-fetch and lock the payment row to prevent concurrent refunds.
            $freshPayment = Payment::lockForUpdate()->findOrFail($payment->id);

            $refundedSoFar = PaymentRefund::where('payment_id', $freshPayment->id)
                ->where('status', PaymentRefund::STATUS_SUCCESS)
                ->sum('amount');

            $maxRefundable = $freshPayment->amount - $refundedSoFar;

            if ($amount > $maxRefundable) {
                throw new \InvalidArgumentException(
                    "Refund amount ({$amount}) exceeds max refundable amount ({$maxRefundable})"
                );
            }
```

#### RFD-20 · B · TXN-06 / F13 #1 — the webhook transitions have no status guard, so a replay duplicates the fee ledger and a late failure flips a success

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H default, raised to B — *the duplicate writes are money movements: fee refunds and invoice deductions*) and deep-read **F13 #1** (a write must not overwrite data it should not). |
| **Where** | `Modules/Payment/app/Services/RefundService.php:90-122` (success method 90-115, failure method 120-132); the replay effect lands in `Modules/Payment/app/Listeners/RefundSucceededListener.php:26-54` |
| **Root cause** | `markRefundSuccess` does not check the current refund status. `ProcessWebhookJob` retries up to 3 times and gateways resend webhooks, so it can run twice; each run dispatches `RefundSucceeded`, and the listener calls `recordRefund()` again (a second `fee_refunds` row and a second `invoice->deductPayment()`) and re-marks the transaction refunded. `markRefundFailed` has the same missing guard; once RFD-02 wires it into the gateway-failure path, a late failure could set a successful refund back to `failed` (today the method has no caller — RFD-22). |
| **Consequence** | A replayed `refund.processed` webhook subtracts the refund from the fee invoice twice, so the family appears to have paid less than they did. The local refund status still says one refund, so the two ledgers disagree. |
| **Reproduce** | Send the same Razorpay `refund.processed` webhook twice (or force a `ProcessWebhookJob` retry). The second run re-enters `markRefundSuccess`; `RefundSucceededListener::handle()` inserts another `fee_refunds` row and deducts the invoice again. Static proof: no status condition in the method. |
| **Fix approach** | After RFD-03's lock/transaction, return early when the status is already terminal: skip `markRefundSuccess` if the row is already `success`; skip `markRefundFailed` if the row is already `success` or `failed`. Keep allowing `failed → success` (a locally failed attempt can be confirmed by a later gateway event). |
| **Plan item** | none — applied by RFD-03's rewrite (§1); see `02-fix-plan.md` §10 |
| **Evidence** | `sed -n '90,132p' …` and `grep -n "if (\$refund->status\|\$refund->update" …` (output below) |

```php
// RefundService.php:90-105 — CURRENT
    public function markRefundSuccess(PaymentRefund $refund, array $payload = []): void
    {
        $refund->update([
            'status'      => PaymentRefund::STATUS_SUCCESS,
            'refunded_at' => now(),
        ]);

        // If fully refunded, mark payment as refunded
        $payment = $refund->payment;
        $totalRefunded = $payment->refunds()
            ->where('status', PaymentRefund::STATUS_SUCCESS)
            ->sum('amount');

        if ($totalRefunded >= $payment->amount) {
            $payment->update(['status' => Payment::STATUS_REFUNDED]);
        }
```

**Evidence**
```
$ grep -n "if (\$refund->status\|\$refund->update" Modules/Payment/app/Services/RefundService.php
92:        $refund->update([
122:        $refund->update(['status' => PaymentRefund::STATUS_FAILED]);

$ grep -n "function handle" Modules/Payment/app/Listeners/RefundSucceededListener.php
26:    public function handle(RefundSucceeded $event): void
(no status guard appears between line 26 and the recordRefund call at line 47)
```

#### RFD-21 · B · F13 #1 — a partial refund is booked as a full refund on the fee transaction

| Field | Value |
|---|---|
| **Rule** | Deep-read **F13 #1** (a write must not overwrite data it should not) — the listener calls `markRefunded()` with no amount, and the model's own docblock says that default is correct only for a full refund. |
| **Where** | `Modules/Payment/app/Listeners/RefundSucceededListener.php:47-54`; the called model is `Modules/StudentFee/app/Models/FeeTransaction.php:217-226` (owned by the StudentFee report, usage only here) |
| **Root cause** | `$transaction->markRefunded()` is called without the refunded amount. `FeeTransaction::markRefunded(?float $amount = null)` then deducts the **whole transaction amount** from `fee_invoices.paid_amount` and sets the transaction status to `REFUNDED`, even when `$refund->amount` is only a part of it. `recordRefund()` has already recorded the correct partial amount, so the two ledger views disagree. |
| **Consequence** | A ₹250 partial refund against a ₹1,000 paid invoice makes the school's books say the family paid ₹0 and still owes ₹1,000, while the refund ledger records only ₹250. The same invoice can then be refunded again or chased for money already refunded. |
| **Reproduce** | Refund part of a successful fee payment through the API, let `refund.processed` call the listener, then compare `fee_refunds.refund_amount` (250) with `fee_invoices.paid_amount` (reduced by the full transaction amount) and `fee_transactions.status` (`refunded`). Live tenant has 0 refunds, so this is proven statically and from the called model's docblock. |
| **Fix approach** | Mark the transaction refunded only when the refund covers the full transaction; for a partial refund, deduct exactly `$refund->amount` from the invoice and leave the transaction status as `success`. This touches only the listener; a cleaner long-term shape (a `markPartiallyRefunded()` on the model) is noted in §7 because that model is owned elsewhere. |
| **Plan item** | RFD-21 in `02-fix-plan.md` §1 |
| **Evidence** | `sed -n '47,54p' …` and the model docblock/body (output below) |

```php
// RefundSucceededListener.php:47-54 — CURRENT
        $service->recordRefund(
            transaction: $transaction,
            amount: $refund->amount,
            reason: $refund->reason,
            refundReference: $refund->gateway_refund_id,
        );

        $transaction->markRefunded();
```

**Evidence**
```
$ sed -n '47,54p' Modules/Payment/app/Listeners/RefundSucceededListener.php
        $service->recordRefund(
            transaction: $transaction,
            amount: $refund->amount,
            reason: $refund->reason,
            refundReference: $refund->gateway_refund_id,
        );

        $transaction->markRefunded();

$ sed -n '217,226p' Modules/StudentFee/app/Models/FeeTransaction.php
    public function markRefunded(?float $amount = null): void
    {
        $this->update([
            'status' => self::STATUS_REFUNDED,
        ]);

        // Reverse the paid amount on the invoice so the balance stays accurate
        if ($this->invoice) {
            $this->invoice->deductPayment($amount ?? (float) $this->amount);
        }
    }
```

#### RFD-22 · L · F13 #8 — the refund-failure path is dead: nothing calls `markRefundFailed`

| Field | Value |
|---|---|
| **Rule** | Deep-read **F13 #8** (dead features) — *a screen or code path whose saved data has no consumer, or a method nothing calls* |
| **Where** | `Modules/Payment/app/Services/RefundService.php:120-132`, method `markRefundFailed`; `Modules/Payment/app/Events/RefundFailed.php` and `Modules/Payment/app/Listeners/RefundFailedListener.php` depend on it |
| **Root cause** | A repository-wide search finds no caller of `markRefundFailed` and no `new RefundFailed` outside the method itself. The webhook gateway only calls `markRefundSuccess`; a refund that fails at the gateway is handled by the exception path in `initiate()`, which currently rolls the whole transaction back, so no `failed` refund row or failure audit is written. The event and its listener are therefore unreachable. |
| **Consequence** | When the gateway refuses a refund, the school gets an exception but no failed-refund record to reconcile against; the audit trail shows only the attempt, never the failure. This becomes reachable as soon as RFD-02's catch calls the method, which is why the dead path is worth recording now. |
| **Reproduce** | Static only — `grep -rn "markRefundFailed" app Modules` returns the method declaration and nothing else. |
| **Fix approach** | RFD-02's gateway-failure catch calls `markRefundFailed`, which wires the method, event and listener; no additional code change is planned. Confirm the listener stays registered in `PaymentServiceProvider` after the fix. |
| **Plan item** | none — wired by RFD-02 in `02-fix-plan.md` §1; see §10 |
| **Evidence** | `grep -rn "markRefundFailed\|new RefundFailed" …` (output below) |

```php
// RefundService.php:120-132 — CURRENT
    public function markRefundFailed(PaymentRefund $refund, string $reason, array $payload = []): void
    {
        $refund->update(['status' => PaymentRefund::STATUS_FAILED]);

        $this->auditService->log(
            payment: $refund->payment,
            event: 'refund.failed',
            payload: array_merge(['refund_ulid' => $refund->ulid, 'reason' => $reason], $payload),
            actorType: 'gateway',
        );

        event(new RefundFailed($refund->fresh(), $reason));
    }
```

**Evidence**
```
$ grep -rn "markRefundFailed" --include=*.php app Modules | grep -v "tests/"
Modules/Payment/app/Services/RefundService.php:120:    public function markRefundFailed(PaymentRefund $refund, string $reason, array $payload = []): void

$ grep -rn "new RefundFailed" --include=*.php app Modules | grep -v "tests/"
Modules/Payment/app/Services/RefundService.php:131:        event(new RefundFailed($refund->fresh(), $reason));
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/StudentFee/app/Models/FeeTransaction.php` | `markRefunded()` always sets `STATUS_REFUNDED`, even for a partial amount; the listener works around it in RFD-21, but a first-class `markPartiallyRefunded(float $amount)` would centralise the rule. | F13 #1 | StudentFee / ParentFeeController report owner |
| `Modules/Payment/app/Jobs/ProcessWebhookJob.php` | Stores `$e->getMessage()` in `error_message` and logs only the message text; the exception object is passed as context in one line but the message is duplicated. Not a user-facing leak here (job log), but it is the ERR-05 shape. | ERR-05 (M) | Payment WebhookController / job report |
| `Modules/Payment/app/Gateways/GatewayManager.php` | Throws a bare `\Exception` with the gateway code in the message; an unknown/inactive gateway produces a 500 on the refund path. It is shared and owned by the ParentFeePayment report. | ERR-00 / F1 | ParentFeePaymentController report |
| `Modules/Payment/app/Gateways/RazorpayGateway.php` | `handleRefundProcessed()` calls `markRefundSuccess` without its own transaction; after RFD-03 the service owns the transaction, so this becomes safe. No separate fix. | TXN-01 | ParentFeePaymentController report (verify after RFD-03) |

## 8. Not covered, and why

- **No live gateway call.** Razorpay is not called; the audit has no credentials and D4 forbids testing. The HTTP-in-transaction finding is proven from the call graph, not from an observed double refund.
- **No webhook replay.** RFD-20 is proven statically (no status guard) and from `ProcessWebhookJob`'s retry policy; the replay itself was not executed.
- **No in-repo API consumer found.** A workspace-wide search for `payment.refund.store`, `payments/.../refund` in `primeapp` and `primeadmin` returned no client call. The endpoints may be consumed by an out-of-repo integration; the "dead feature" question (F13 #8) is therefore ⚠ UNVERIFIED — a request log or the mobile app's payment screen would settle it.
- **The fee-ledger classes** (`FeeInvoiceService`, `FeeTransaction`, `FeeInvoice`) are owned by the StudentFee / ParentFeeController report. Only the calls made from this controller's listener were checked; their internals were not re-audited.
- **No browser run.** These are JSON API routes with no Blade form; every reproduction above is either an authenticated JSON call or a static proof.
