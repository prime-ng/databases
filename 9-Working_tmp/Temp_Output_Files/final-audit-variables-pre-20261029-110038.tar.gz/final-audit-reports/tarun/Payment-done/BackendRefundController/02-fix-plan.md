# Fix Plan — Payment / Backend\RefundController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Payment/app/Http/Controllers/Backend/RefundController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `resources/views/backend/layouts/master.blade.php` | shared layout — read-only for this plan |
| `Modules/Prime/resources/views/**` | shared Prime views — only touched if BRF-01 option (b) is chosen |
| `Modules/Payment/routes/web.php` | shared route file — the doubled route name is a cross-cutting note (§7), not a change here |
| `Modules/Payment/app/Policies/PaymentPolicy.php` | owned by `tarun/Payment-done/PaymentController` — this plan only *uses* it, never edits it |
| `Modules/Payment/app/Models/Payment.php`, `Modules/Payment/app/Models/PaymentGateway.php`, `Modules/Payment/app/Models/PaymentRefund.php` | owned by `tarun/ParentPortal-done/ParentFeePaymentController` / `tarun/Payment-done/RefundController` |
| `config/permissionslist.php` | shared config — no permission change is proposed here |
| `Modules/Payment/resources/views/payments/**`, `webhooks/index.blade.php`, `reconciliation/**` | owned by other Payment controller reports |
| any migration | standing rule: never edit an existing migration |

## 1. Blockers reachable today

- [ ] **BRF-01** · B · DECISION · VIEW-04 — the refund list extends `prime::layouts.master`, which does not resolve, so the page 500s before anything renders. Which layout should it use?
  - **Why it is a decision:** the target layout is a shared file (`resources/views/backend/layouts/master.blade.php` or a new `Modules/Prime/resources/views/layouts/master.blade.php`), and the same broken `@extends` sits in five other Payment/Billing views owned by other reports. Creating a layout file or editing a shared one reaches outside this controller's files. The identical decision is BPA-01 in `tarun/Payment-done/BackendPaymentController/02-fix-plan.md` — if Tarun has already chosen there, apply the same answer here.
  - **⚠ SHARED**
  - (a) ⭐ Point this one view at the existing `backend.layouts.master` (`@extends('backend.layouts.master')`, already used by 7 other views). No new file, smallest blast radius; fixes only the refunds page. The `content_header` block becomes unused (that layout yields only `content`), so fold or drop the `<h5 class="mb-0">Refunds</h5>` heading.
  - (b) Create the missing `Modules/Prime/resources/views/layouts/master.blade.php` (an AdminLTE-style layout with `@yield('content')` and `@yield('content_header')`) so all six Payment views and any future `prime::layouts.master` consumer resolve. One new shared file; larger blast radius; needs a follow-up look at every `prime::layouts.master` user.
  - (c) Defer to a module-wide Payment view pass (the five other views share the break) — leave the refunds page down until then.
  - ➜ Choice: ____

## 2. Fixes that arm a latent defect (sequenced)

None. BRF-01 must be fixed before the view-level item (BRF-04) is visible to a user, but BRF-04 is an independent edit and any order leaves the code valid.

## 3. Errors & transactions (F1/F2)

None — the controller has no write path, no `try`/`catch` and no `activityLog` event.

## 4. Authorization (F3)

- [ ] **BRF-03** · M · AUTH-06 · `Modules/Payment/app/Http/Controllers/Backend/RefundController.php:35` — authorize the refund list through the existing `PaymentPolicy` instead of a copy-pasted permission literal.
  - **Touches:** `Modules/Payment/app/Http/Controllers/Backend/RefundController.php`
  - **Before** (`RefundController.php:7-10`):
    ```php
    use Illuminate\Support\Facades\Gate;
    use App\Http\Controllers\Controller;
    use Illuminate\View\View;
    use Modules\Payment\Models\PaymentRefund;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Facades\Gate;
    use App\Http\Controllers\Controller;
    use Illuminate\View\View;
    use Modules\Payment\Models\Payment;
    use Modules\Payment\Models\PaymentRefund;
    ```
  - **Before** (`RefundController.php:35`):
    ```php
            Gate::authorize('tenant.payment.payment.viewAny');
    ```
  - **After:**
    ```php
            Gate::authorize('viewAny', Payment::class);
    ```
  - **Verify:** `grep -n "Gate::authorize" Modules/Payment/app/Http/Controllers/Backend/RefundController.php`
  - **Expect:** `Gate::authorize('viewAny', Payment::class);` and no `'tenant.payment.payment.viewAny'` literal.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

None.

## 6. Queries & performance (F9)

- [ ] **BRF-02** · M · QRY-13 · `Modules/Payment/app/Http/Controllers/Backend/RefundController.php:37-39` — paginate the list at the house standard of 10 with a distinct page name.
  - **Touches:** `Modules/Payment/app/Http/Controllers/Backend/RefundController.php`
  - **Before** (`RefundController.php:37-39`):
    ```php
            $refunds = PaymentRefund::with(['payment.gateway'])
                ->latest()
                ->paginate(20);
    ```
  - **After:**
    ```php
            $refunds = PaymentRefund::with(['payment.gateway'])
                ->latest()
                ->paginate(10, ['*'], 'refundsPage');
    ```
  - **Verify:** `grep -n "paginate" Modules/Payment/app/Http/Controllers/Backend/RefundController.php`
  - **Expect:** `->paginate(10, ['*'], 'refundsPage');`
  - **Effort:** S

## 7. Views (F10)

- [ ] **BRF-04** · L · UI-STD · `Modules/Payment/resources/views/refunds/index.blade.php:9` — render the page breadcrumb.
  - **Touches:** `Modules/Payment/resources/views/refunds/index.blade.php`
  - **Before** (`refunds/index.blade.php:5-9`):
    ```blade
    @section('content_header')
        <h5 class="mb-0">Refunds</h5>
    @endsection

    @section('content')
    ```
  - **After:**
    ```blade
    @section('content_header')
        <h5 class="mb-0">Refunds</h5>
    @endsection

    @section('content')
        <x-backend.components.breadcrum title="Refunds" :links="[]" />
    ```
  - **Verify:** `grep -n "breadcrum" Modules/Payment/resources/views/refunds/index.blade.php`
  - **Expect:** `…<x-backend.components.breadcrum title="Refunds" :links="[]" />`
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **BRF-05** · L · STY-02 · `Modules/Payment/app/Http/Controllers/Backend/RefundController.php:7-10` — sort the imports so the file is Pint-clean.
  - **Touches:** `Modules/Payment/app/Http/Controllers/Backend/RefundController.php`
  - **Note:** this item is "run Pint on the file". If BRF-03 has already been applied, the import list also contains a `Payment` line; Pint sorts whatever is present. The Before/After below show the audit-time state.
  - **Before** (`RefundController.php:7-10`):
    ```php
    use Illuminate\Support\Facades\Gate;
    use App\Http\Controllers\Controller;
    use Illuminate\View\View;
    use Modules\Payment\Models\PaymentRefund;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\Payment\Models\PaymentRefund;
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Payment/app/Http/Controllers/Backend/RefundController.php`
  - **Expect:** `{"tool":"pint","result":"pass"}`
  - **Effort:** S

- [ ] **BRF-06** · L · STY-04 · `Modules/Payment/app/Http/Controllers/Backend/RefundController.php:13,33` — remove the emoji marker and correct the permission name in the class comment.
  - **Touches:** `Modules/Payment/app/Http/Controllers/Backend/RefundController.php`
  - **Before** (`RefundController.php:13`):
    ```php
     * ⚠ Gate::authorize(...), NOT $this->authorize(...).
    ```
  - **After:**
    ```php
     * Gate::authorize(...), NOT $this->authorize(...).
    ```
  - **Before** (`RefundController.php:33`):
    ```php
     * Gate::before bypass. tenant.payment.viewAny is seeded, and it is what the module's
    ```
  - **After:**
    ```php
     * Gate::before bypass. tenant.payment.payment.viewAny is seeded, and it is what the module's
    ```
  - **Verify:** `grep -n "tenant.payment.viewAny\|⚠" Modules/Payment/app/Http/Controllers/Backend/RefundController.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

None beyond BRF-01 (in §1, because the page is down).

## 10. Findings with no plan item

None — every finding has a plan item (BRF-01 in §1, BRF-03 in §4, BRF-02 in §6, BRF-04 in §7, BRF-05 and BRF-06 in §8).
