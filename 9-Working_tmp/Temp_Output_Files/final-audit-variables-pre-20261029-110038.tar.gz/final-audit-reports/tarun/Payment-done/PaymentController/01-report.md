# Final Audit — Payment / PaymentController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/Payment/app/Http/Controllers/PaymentController.php` (130 lines, 4 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `POST /api/v1/payments/initiate` · `POST /api/v1/payments/{ulid}/callback` · `POST /api/v1/payments/{ulid}/cancel` · `GET /api/v1/payments/{ulid}` · browser callback `POST /payment/payment/{ulid}/callback` |
| Menu path | none — a JSON API consumed by the mobile apps and the web checkout pages (fees, library fines) |
| Who uses it | Any role holding `tenant.payment.payment.create`, `.viewAny`, `.view`, `.update` or `.cancel`. By default that is Super Admin and School Admin; parents/students reach the callback through their own portal permissions. |
| What a user does here | Starts a payment for a payable (a fee invoice or a library fine), the gateway sends the payer back to the callback to confirm it, a user can cancel a still-pending payment, or open one payment's detail as JSON. |
| Tables written | `ptm_payment_payments`, `ptm_payment_audit_logs`, `ptm_payment_offline_records` (the writes happen in `PaymentService`, called by this controller) |
| Tables read | `ptm_payment_payments`, `ptm_payment_gateways`, `ptm_payment_audit_logs`, `ptm_payment_refunds`, plus the payable table (e.g. the fee-invoice table) |
| Live data | tenant `00000000-0000-4000-8000-000000000001`: `ptm_payment_payments` 60 rows, `ptm_payment_gateways` 6 rows, `ptm_payment_audit_logs` 0 rows, `ptm_payment_offline_records` 0 rows |

**How to reach each bug in the browser:** each finding carries a **Reproduce** line. All four endpoints are JSON; most are static-only because they need a Sanctum token or a signed gateway payload.

## 1. Verdict

Not production-ready. The controller itself is small and free of try/catch, so it is close — but `show()` returns the full `Payment` graph including the `gateway` relation, and `PaymentGateway`'s `credentials` column is an `encrypted:array` cast with no `$hidden`, so **every merchant key and webhook secret is decrypted and sent to the caller** (PAY-08, Blocker). A second hard defect: the callback's `PaymentCallbackRequest` only accepts Razorpay's three fields, so the shared callback endpoint answers 422 for CCAvenue, Paytm, PhonePe and BillDesk redirects, and CCAvenue (which has no webhook) can therefore never be marked successful (PAY-03, High). The single worst finding is PAY-08. Rough effort to work the plan: S (roughly 3–5 hours), with three items held as decisions for Tarun.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 1 | 4 | 4 | 3 | 10 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | PAY-06 |
| F2 Transactions/Audit | clean (see §7 X1) | F9 Queries/Perf | PAY-07 |
| F3 Authorization | PAY-01, PAY-02 | F10 Views | n/a — this controller renders no Blade |
| F4 Validation | PAY-03, PAY-04 | F11 Security/Tenancy | PAY-08 |
| F5 Routes | PAY-05 | F12 Style | PAY-09, PAY-10 |
| F6 Controller shape | clean | F13 Deep read | see the F13 table under §6 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Payment/app/Http/Controllers/PaymentController.php` | controller | 130 | this report | ✅ |
| 2 | `Modules/Payment/app/Http/Requests/InitiatePaymentRequest.php` | FormRequest | 41 | this report | ✅ |
| 3 | `Modules/Payment/app/Http/Requests/PaymentCallbackRequest.php` | FormRequest | 24 | this report | ✅ |
| 4 | `Modules/Payment/app/Policies/PaymentPolicy.php` | policy | 46 | this report | ✅ |
| 5 | `Modules/Payment/app/Models/OfflinePaymentRecord.php` | model | 47 | this report | ✅ |
| 6 | `Modules/Payment/app/Events/PaymentCancelled.php` | event | 12 | this report | ✅ |
| 7 | `Modules/Payment/app/Listeners/PaymentCancelledListener.php` | listener | 32 | this report | ✅ |
| 8 | `Modules/Payment/app/Gateways/BillDeskGateway.php` | gateway | 192 | this report | ✅ |
| 9 | `Modules/Payment/app/Gateways/CCAvenueGateway.php` | gateway | 164 | this report | ✅ |
| 10 | `Modules/Payment/app/Gateways/OfflineGateway.php` | gateway | 109 | this report | ✅ |
| 11 | `Modules/Payment/app/Gateways/PaytmGateway.php` | gateway | 254 | this report | ✅ |
| 12 | `Modules/Payment/app/Gateways/PhonePeGateway.php` | gateway | 192 | this report | ✅ |
| 13 | `Modules/Payment/app/Providers/PaymentServiceProvider.php` | provider | 212 | common module glue (§4.2) | ❌ inspected only — confirms `PaymentPolicy` registration at line 41; its STY-01 defect is a §7 note, not audited here |
| 14 | `Modules/Payment/app/Models/Payment.php` | model | 101 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 15 | `Modules/Payment/app/Models/PaymentGateway.php` | model | 76 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 16 | `Modules/Payment/app/Models/PaymentAuditLog.php` | model | 43 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 17 | `Modules/Payment/app/Services/PaymentService.php` | service | 182 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 18 | `Modules/Payment/app/Services/GatewayManager.php` | service | 85 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 19 | `Modules/Payment/app/Services/AuditService.php` | service | 104 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 20 | `Modules/Payment/app/DTO/PaymentData.php` | DTO | 43 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 21 | `Modules/Payment/app/Contracts/Payable.php` | contract | 38 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 22 | `Modules/Payment/app/Contracts/PaymentGatewayInterface.php` | contract | 65 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 23 | `Modules/Payment/app/Gateways/RazorpayGateway.php` | gateway | 275 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 24 | `Modules/Payment/app/Gateways/BaseGateway.php` | gateway base | 14 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 25 | `Modules/Payment/app/Events/PaymentInitiated.php` | event | 12 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 26 | `Modules/Payment/app/Events/PaymentSucceeded.php` | event | 12 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 27 | `Modules/Payment/app/Events/PaymentFailed.php` | event | 15 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 28 | `Modules/Payment/app/Listeners/PaymentInitiatedListener.php` | listener | 32 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 29 | `Modules/Payment/app/Listeners/PaymentSucceededListener.php` | listener | 47 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 30 | `Modules/Payment/app/Listeners/PaymentFailedListener.php` | listener | 46 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |

The linked classes are owned by the `tarun/ParentPortal-done/ParentFeePaymentController` report and are **not re-audited** here; this report only checks how the controller uses them. No pre-applied files.

## 4. Routes

```
POST    api/v1/payments/initiate                      api.payment.initiate           Modules\Payment\Http\Controllers\PaymentController@initiate
POST    api/v1/payments/{ulid}/callback               api.payment.callback           Modules\Payment\Http\Controllers\PaymentController@callback
POST    api/v1/payments/{ulid}/cancel                 api.payment.cancel             Modules\Payment\Http\Controllers\PaymentController@cancel
GET|HEAD api/v1/payments/{ulid}                        api.payment.show               Modules\Payment\Http\Controllers\PaymentController@show
POST    payment/payment/{ulid}/callback               payment.payment.callback       Modules\Payment\Http\Controllers\PaymentController@callback
```

Unrouted public methods: none. All four public methods are routed. `callback` is deliberately routed twice — once in `routes/api.php` (effective name `api.payment.callback`) and once in `routes/web.php` (effective name `payment.payment.callback`); see PAY-05.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `initiate` | 37 | POST api/v1/payments/initiate | `tenant.payment.payment.create` + `create` (Payment policy) | `PaymentService::initiate()` — `DB::transaction` | none in the controller; the service writes `ptm_payment_audit_logs` event `payment.initiated` | `ptm_payment_payments`, `ptm_payment_audit_logs`, `ptm_payment_offline_records` | PAY-01, PAY-04 |
| `callback` | 74 | POST api/v1/payments/{ulid}/callback · POST payment/payment/{ulid}/callback | `tenant.payment.payment.create` + `view` (Payment policy) | none — `PaymentService::markSuccess()` / `markFailed()` run without a transaction (§7 X1) | none; listeners owned elsewhere | `ptm_payment_payments`, `ptm_payment_audit_logs` | PAY-02, PAY-03, PAY-05 |
| `cancel` | 104 | POST api/v1/payments/{ulid}/cancel | `tenant.payment.payment.update` + `cancel` (Payment policy) | none — `PaymentService::cancel()` runs without a transaction (§7 X1) | `PaymentCancelledListener` writes `ptm_payment_audit_logs` event `payment.cancelled` | `ptm_payment_payments`, `ptm_payment_audit_logs` | — (the missing status guard is §7 X2) |
| `show` | 120 | GET api/v1/payments/{ulid} | `tenant.payment.payment.viewAny` + `view` (Payment policy) | n/a (read) | n/a | none | PAY-07, PAY-08 |

Note on the Gate column: the string abilities (`tenant.payment.payment.*`) are resolved by Spatie's `Gate::before` permission hook (`config/permission.php` `register_permission_check_method` is `true`); the model-form abilities (`create`, `view`, `cancel`) resolve through `PaymentPolicy`, which is registered at `Modules/Payment/app/Providers/PaymentServiceProvider.php:41`. The permission names exist in `config/permissionslist.php:1130` (`'payment.payment' => array_merge($crud, ['cancel', 'refund'])`, where `$crud` is `create, view, viewAny, update, delete, restore, forceDelete`).

## 6. Findings

### F1 — Errors

clean — the controller has no `try/catch`, no `getMessage()` and no debug leftovers.
```
$ grep -nE "try \{|catch \(|getMessage\(\)|dd\(|dump\(" Modules/Payment/app/Http/Controllers/PaymentController.php
(no output)
```
All failure handling is central (`bootstrap/app.php`), per D1. `findOrFail()` is used in `initiate` outside any catch. The `PaymentCancelledListener` uses no catch. The gateways use `catch (\JsonException)` only (a narrow decode guard, not a user-facing catch).

### F2 — Transactions and audit

clean at the controller — this controller performs no direct write, so there is nothing to wrap in a transaction here. All mutating work happens in the linked `PaymentService`. For the cross-file count see §7 X1: `PaymentService::initiate()` wraps its writes in one `DB::transaction`, while `markSuccess()`, `markFailed()` and `cancel()` — the methods this controller's `callback` and `cancel` call — write the payment row **and** an audit row with no transaction. Those methods are owned by the ParentPortal report and are not fixed here.

### F3 — Authorization

#### PAY-01 · L · AUTH-04 — the same permission is checked twice in `initiate` and `callback`

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentController.php:37-48` (`initiate`) and `:74-81` (`callback`) |
| **Root cause** | `InitiatePaymentRequest::authorize()` and `PaymentCallbackRequest::authorize()` already check `tenant.payment.payment.create`, and so does the bare string gate at line 39 / line 76; in `initiate` the policy-form gate at line 48 (`Gate::authorize('create', Payment::class)`) checks the same permission a third time. |
| **Consequence** | Each request runs the same permission lookup two or three times, and a future edit to one surface silently does not apply to the others. |
| **Reproduce** | static only — the duplication is visible in the source; no request is needed. |
| **Fix approach** | Keep the Form Request `authorize()` (it runs first) and the policy-form gate; delete the two bare string gates at lines 39 and 76. |
| **Plan item** | PAY-01 in `02-fix-plan.md` §4 |

```php
// PaymentController.php:37-48 — CURRENT
    public function initiate(InitiatePaymentRequest $request): JsonResponse
    {
        Gate::authorize('tenant.payment.payment.create');

        $payableClass = $request->validated('payable_type');
        $payableId    = $request->validated('payable_id');
        $gatewayCode  = $request->validated('gateway');

        /** @var \Modules\Payment\Contracts\Payable $payable */
        $payable = $payableClass::findOrFail($payableId);

        Gate::authorize('create', Payment::class);
```

**Evidence**
```
$ grep -rn "Gate::authorize" Modules/Payment/app/Http/Controllers/PaymentController.php
39:        Gate::authorize('tenant.payment.payment.create');
48:        Gate::authorize('create', Payment::class);
76:        Gate::authorize('tenant.payment.payment.create');
81:        Gate::authorize('view', $payment);
...

$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-paymentcontroller.json Modules/Payment/app/Http/Controllers/PaymentController.php
L  AUTH-04  Modules/Payment/app/Http/Controllers/PaymentController.php:37  initiate — InitiatePaymentRequest::authorize() and Gate::authorize both check
L  AUTH-04  Modules/Payment/app/Http/Controllers/PaymentController.php:74  callback — PaymentCallbackRequest::authorize() and Gate::authorize both check
```

#### PAY-02 · M · AUTH-03 — the callback trusts an "offline" payment, so it can be marked paid without a collection

| Field | Value |
|---|---|
| **Rule** | AUTH-03 (H) — *record-level checks where data belongs to a person / a workflow*; lowered to M because it needs the `create` permission and only affects the counter-collection flow |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentController.php:78-83`, method `callback()` |
| **Root cause** | `callback()` loads the payment, resolves the driver from `$payment->gateway->code`, and calls `$driver->verify()` unconditionally. For the offline driver, `OfflineGateway::verify()` is hard-coded to `return true`, so any authenticated caller holding `tenant.payment.payment.create` and `view` on the payment moves a pending offline payment to `success` with no money collected. |
| **Consequence** | A staff user can flip a cash/cheque payment to paid through the public callback endpoint, bypassing the human collection step. |
| **Reproduce** | static only — posting the three Razorpay fields to `POST /payment/payment/{ulid}/callback` for an offline-created payment returns success; needs a token, so not run here. |
| **Fix approach** | Reject the callback for the offline gateway before resolving the driver. |
| **Plan item** | PAY-02 in `02-fix-plan.md` §4 |

```php
// PaymentController.php:78-83 — CURRENT
        $payment = $this->paymentService->getByUlid($ulid);
        $gateway = $payment->gateway;

        Gate::authorize('view', $payment);

        $driver = app(GatewayManager::class)->resolve($gateway->code);
```

**Evidence**
```
$ sed -n '46,52p' Modules/Payment/app/Gateways/OfflineGateway.php
    /**
     * Offline payments are always considered verified (human approval flow).
     */
    public function verify(array $payload): bool
    {
        return true;
    }
```

### F4 — Validation and input

#### PAY-03 · H · VAL-05 — the callback accepts only Razorpay fields, so four of five gateways cannot confirm

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; a write path with the wrong contract*; raised to H because a real gateway's only success path is blocked |
| **Where** | `Modules/Payment/app/Http/Requests/PaymentCallbackRequest.php:18-22`, consumed by `PaymentController.php:74` |
| **Root cause** | `PaymentCallbackRequest::rules()` requires `razorpay_payment_id`, `razorpay_order_id` and `razorpay_signature` unconditionally, and `callback()` forwards only those three keys to `$driver->verify()`. But the same callback serves every gateway: CCAvenue sends `encResp`, Paytm sends `CHECKSUMHASH`, PhonePe sends `X-VERIFY`/`response`, BillDesk sends `BD_RESPONSE`. Validation fails first, so the request never reaches the driver. |
| **Consequence** | A CCAvenue payment is charged but the redirect callback answers 422 and the payment stays pending forever (CCAvenue has no webhook); Paytm/PhonePe/BillDesk redirects 422 as well and rely solely on their webhooks. |
| **Reproduce** | `POST /payment/payment/{ulid}/callback` with a CCAvenue `encResp` body returns 422 instead of confirming the payment. |
| **Fix approach** | Generalise the request and the controller so the driver receives its own payload (see the decision options). |
| **Plan item** | PAY-03 in `02-fix-plan.md` §9 (DECISION) |

```php
// PaymentCallbackRequest.php:18-22 — CURRENT
        return [
            'razorpay_payment_id' => ['required', 'string'],
            'razorpay_order_id'   => ['required', 'string'],
            'razorpay_signature'  => ['required', 'string'],
        ];
```

**Evidence**
```
$ sed -n '85,89p' Modules/Payment/app/Http/Controllers/PaymentController.php
        $payload = $request->only([
            'razorpay_payment_id',
            'razorpay_order_id',
            'razorpay_signature',
        ]);

$ grep -rn "encResp\|CHECKSUMHASH\|X-VERIFY\|BD_RESPONSE" Modules/Payment/app/Gateways/
Modules/Payment/app/Gateways/BillDeskGateway.php:71:        $responseMsg = $payload['BD_RESPONSE'] ?? $payload['msg'] ?? '';
Modules/Payment/app/Gateways/CCAvenueGateway.php:68:        $encResponse = $payload['encResp'] ?? '';
Modules/Payment/app/Gateways/PaytmGateway.php:83:        $checksum    = $payload['CHECKSUMHASH'] ?? '';
Modules/Payment/app/Gateways/PhonePeGateway.php:77:        $xVerify = $payload['X-VERIFY'] ?? $payload['x_verify'] ?? '';
```

#### PAY-04 · L · MDL-09 — the offline method list is hard-coded in the request instead of the model constants

| Field | Value |
|---|---|
| **Rule** | MDL-09 (L) — *status/type strings are PHP enums or model constants, not literals repeated across files* |
| **Where** | `Modules/Payment/app/Http/Requests/InitiatePaymentRequest.php:36` |
| **Root cause** | The allowed offline methods are written as a literal string `cash,cheque,bank_transfer,demand_draft,upi_manual`, duplicating the `METHOD_*` constants that `OfflinePaymentRecord` already declares. |
| **Consequence** | Adding an offline method in one place silently does not reach the other; the two can drift. |
| **Reproduce** | static only — source duplication, no request needed. |
| **Fix approach** | Build the `in:` list from `OfflinePaymentRecord::METHOD_*`. |
| **Plan item** | PAY-04 in `02-fix-plan.md` §5 |

```php
// InitiatePaymentRequest.php:36 — CURRENT
            'offline_method'    => ['required_if:gateway,offline', 'string', 'in:cash,cheque,bank_transfer,demand_draft,upi_manual'],
```

**Evidence**
```
$ grep -n "METHOD_" Modules/Payment/app/Models/OfflinePaymentRecord.php
36:    const METHOD_CASH          = 'cash';
37:    const METHOD_CHEQUE        = 'cheque';
38:    const METHOD_DEMAND_DRAFT  = 'demand_draft';
39:    const METHOD_BANK_TRANSFER = 'bank_transfer';
40:    const METHOD_UPI_MANUAL    = 'upi_manual';
```

### F5 — Routes

#### PAY-05 · M · RTE-02 — the web callback route's name does not match its caller (and is declared twice)

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *every route points at a method that exists*; lowered to M because the only caller is a view that nothing renders today (latent, not live) |
| **Where** | `Modules/Payment/routes/web.php:29-31`, method `callback` |
| **Root cause** | Both `routes/web.php` and `routes/api.php` declare the literal name `payment.callback`. The module's `RouteServiceProvider` prefixes names with `payment.` (web) and `api.` (api), so the effective names are `payment.payment.callback` and `api.payment.callback` — neither is `payment.callback`. The only caller, `Modules/Payment/resources/views/razorpay/process-payment.blade.php:23`, calls `route('payment.callback')` and throws. The URL also carries the segment twice (`payment/payment/{ulid}/callback`). |
| **Consequence** | If that checkout view is ever rendered it fails with `RouteNotFoundException`; anyone copying the route name from `web.php` gets a name that does not resolve. |
| **Reproduce** | `php artisan tinker --execute 'route("payment.callback", ["ulid" => "X"]);'` throws `RouteNotFoundException: Route [payment.callback] not defined.` |
| **Fix approach** | Rename the web route so its effective name is `payment.callback` and drop the duplicated URL segment (see the decision options). |
| **Plan item** | PAY-05 in `02-fix-plan.md` §9 (DECISION) |

```php
// Modules/Payment/routes/web.php:29-31 — CURRENT
Route::post('payment/{ulid}/callback', [PaymentController::class, 'callback'])
    ->name('payment.callback');
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '... name contains "payment.callback"'
POST    api/v1/payments/{ulid}/callback               api.payment.callback           Modules\Payment\Http\Controllers\PaymentController@callback
POST    payment/payment/{ulid}/callback               payment.payment.callback       Modules\Payment\Http\Controllers\PaymentController@callback

$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan tinker --execute 'route("payment.callback",["ulid"=>"X"]);'
payment.callback THROWS Symfony\Component\Routing\Exception\RouteNotFoundException: Route [payment.callback] not defined.
```

### F6 — Controller shape

clean — 130 lines and 4 public methods (well under the 1,000-line / 25-method CTL-01 threshold); every method is short; route model binding is not used because `Payment`'s route key is `id` while the routes carry `{ulid}` (binding would need a `getRouteKeyName()` on the linked `Payment` model — noted in §8).
```
$ wc -l Modules/Payment/app/Http/Controllers/PaymentController.php
130 Modules/Payment/app/Http/Controllers/PaymentController.php
$ grep -nE "public function" Modules/Payment/app/Http/Controllers/PaymentController.php
37:    public function initiate(InitiatePaymentRequest $request): JsonResponse
74:    public function callback(PaymentCallbackRequest $request, string $ulid): JsonResponse
104:    public function cancel(string $ulid): JsonResponse
120:    public function show(string $ulid): JsonResponse
```
No `compact()` over 15 variables, no `request()` helper, no dead code, no debug leftovers.

### F7 — Models

clean — the one owned model, `OfflinePaymentRecord.php`, passes every MDL check.
```
$ grep -nE "protected \\\$table|protected \\\$fillable|protected \\\$casts|use HasFactory|SoftDeletes" Modules/Payment/app/Models/OfflinePaymentRecord.php
14:    use HasFactory, SoftDeletes;
16:    protected $table = 'ptm_payment_offline_records';
18:    protected $fillable = [
30:    protected $casts = [
```
- `$table` `ptm_payment_offline_records` exists in `database/migrations/tenant/2026_06_18_100104_create_ptm_payment_offline_records_table.php` (MDL-07 ✅).
- `$fillable` declared, no sensitive column (MDL-01 ✅).
- casts cover `collected_at`, `cheque_bounce_at` (datetime) and `is_active` (boolean) (MDL-02 ✅).
- `SoftDeletes` matches the table's `softDeletes()` column (✅).
- `payment()` returns `BelongsTo` with a type (MDL-04 ✅).
- No Spatie media (MDL-05 n/a), no `belongsToMany` pivot (MDL-03 n/a).
The literal-duplication concern in this area is PAY-04 (the request, not the model).

### F8 — Services and jobs

#### PAY-06 · M · SVC-02 — gateway drivers resolve `PaymentService` with the service locator

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection, not `app(Foo::class)` mid-method* |
| **Where** | `Modules/Payment/app/Gateways/BillDeskGateway.php:113-114` (also `PaytmGateway.php:112`, `PhonePeGateway.php:110`) |
| **Root cause** | Each gateway's `handleWebhook()` calls `app(PaymentService::class)` instead of receiving the service by injection; the same pattern is repeated in `RazorpayGateway` (owned elsewhere). This also duplicates the "find the payment, then mark success/failure" logic in three drivers (SVC-04). |
| **Consequence** | The drivers cannot be unit-constructed with a fake service, and the copy-pasted handler logic drifts between gateways. |
| **Reproduce** | static only — the drift would need a gateway webhook to observe; source shows the duplication. |
| **Fix approach** | Change `GatewayManager` to resolve drivers from the container and inject services (see the decision options). |
| **Plan item** | PAY-06 in `02-fix-plan.md` §9 (DECISION) |

```php
// BillDeskGateway.php:113-114 — CURRENT
        /** @var PaymentService $service */
        $service = app(PaymentService::class);
```

**Evidence**
```
$ grep -rn "app(PaymentService::class)" Modules/Payment/app/Gateways/
Modules/Payment/app/Gateways/PhonePeGateway.php:110:        $service = app(PaymentService::class);
Modules/Payment/app/Gateways/RazorpayGateway.php:200:        $service = app(PaymentService::class);
Modules/Payment/app/Gateways/RazorpayGateway.php:235:        $service = app(PaymentService::class);
Modules/Payment/app/Gateways/BillDeskGateway.php:114:        $service = app(PaymentService::class);
Modules/Payment/app/Gateways/PaytmGateway.php:112:        $service = app(PaymentService::class);
```

### F9 — Queries and performance

#### PAY-07 · M · QRY-02 — the detail endpoint loads refunds and audit logs with no limit

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H) — *lists are paginated; no unbounded `->get()` feeding a JSON list*; lowered to M because a single payment's child counts are usually small |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentController.php:128`, method `show()` |
| **Root cause** | `$payment->load(['gateway', 'refunds', 'auditLogs'])` loads both `HasMany` relations in full. `auditLogs` grows by one row on every status change and webhook, so a long-lived payment returns an unbounded list. |
| **Consequence** | The response grows without bound as events accumulate, slowly for one payment and heavily on the mobile list. |
| **Reproduce** | static only — the endpoint needs a token; the `HasMany` relations in `Payment.php:67-76` have no limit. |
| **Fix approach** | Bound both relations (see PAY-08, same response rewrite). |
| **Plan item** | none — see plan §10 (fixed by the PAY-08 rewrite) |

```php
// PaymentController.php:128 — CURRENT
        return response()->json($payment->load(['gateway', 'refunds', 'auditLogs']));
```

**Evidence**
```
$ sed -n '66,76p' Modules/Payment/app/Models/Payment.php
    /** Refunds against this payment. */
    public function refunds(): HasMany
    {
        return $this->hasMany(PaymentRefund::class, 'payment_id');
    }

    /** Audit log entries for this payment. */
    public function auditLogs(): HasMany
    {
        return $this->hasMany(PaymentAuditLog::class, 'payment_id');
    }
```

### F10 — Views

n/a — this controller renders no Blade; all four methods return JSON. The one Payment-module view that references the callback route name is covered by PAY-05.

### F11 — Security and tenancy

#### PAY-08 · B · SEC-02 — the detail endpoint returns the gateway's decrypted credentials

| Field | Value |
|---|---|
| **Rule** | SEC-02 (H) — *no personal/secrets over-exposure: JSON endpoints return mapped arrays, not full models*; raised to B because it leaks payment-gateway secrets |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentController.php:120-129`, method `show()` |
| **Root cause** | `show()` returns `response()->json($payment->load(['gateway', 'refunds', 'auditLogs']))`. `PaymentGateway` has no `$hidden`/`$visible` and no API Resource, and its `credentials` column is cast `encrypted:array`; `toArray()` therefore decrypts the credentials bag and includes it (with `extra_config`) in the JSON. |
| **Consequence** | Any user holding `tenant.payment.payment.viewAny` + `.view` (School Admin by default) can read the school's merchant keys, secret keys and webhook secrets by calling a payment detail URL — a full gateway-account compromise. |
| **Reproduce** | `GET /api/v1/payments/{ulid}` returns a `gateway` object containing a decrypted `credentials` object. Static only here — the endpoint needs a Sanctum token. |
| **Fix approach** | Hide `credentials`/`extra_config` on the loaded gateway (and bound the child loads) before serialising. |
| **Plan item** | PAY-08 in `02-fix-plan.md` §1 |

```php
// PaymentController.php:120-129 — CURRENT
    public function show(string $ulid): JsonResponse
    {
        Gate::authorize('tenant.payment.payment.viewAny');

        $payment = $this->paymentService->getByUlid($ulid);

        Gate::authorize('view', $payment);

        return response()->json($payment->load(['gateway', 'refunds', 'auditLogs']));
    }
```

**Evidence**
```
$ grep -n "credentials\|protected \$hidden\|'hidden'" Modules/Payment/app/Models/PaymentGateway.php
24:        'credentials',
34:        'credentials'       => 'encrypted:array',
54:     * Read a single key out of the encrypted credentials bag.
56:     * The credentials cast can be null on a partially-configured gateway, so this
62:        return data_get($this->credentials, $key, $default);
(no $hidden / $visible declared)

$ ls Modules/Payment/app/Http/Resources 2>/dev/null || echo "no Resources dir"
no Resources dir
```

### F12 — Style

#### PAY-09 · L · STY-04 — the controller header comment uses an emoji marker

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers* (the file is also not Pint-clean) |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentController.php:16-17` |
| **Root cause** | The class docblock opens with a warning-symbol emoji; the scanner flags it. `vendor/bin/pint --test` also reports the file is not Pint-clean. |
| **Consequence** | Cosmetic only; the file diverges from the project style run. |
| **Reproduce** | `grep -n '⚠' Modules/Payment/app/Http/Controllers/PaymentController.php` shows the line. |
| **Fix approach** | Replace the emoji with the word "Note", then run Pint on the file. |
| **Plan item** | PAY-09 in `02-fix-plan.md` §8 |

```php
// PaymentController.php:16-17 — CURRENT
/*
 * ⚠ Gate::authorize(...), NOT $this->authorize(...).
```

**Evidence**
```
$ grep -n '⚠' Modules/Payment/app/Http/Controllers/PaymentController.php
17: * ⚠ Gate::authorize(...), NOT $this->authorize(...).

$ vendor/bin/pint Modules/Payment/app/Http/Controllers/PaymentController.php --test
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Http\/Controllers\/PaymentController.php","fixers":["fully_qualified_strict_types","braces_position","single_line_empty_body","blank_line_before_statement","ordered_imports","binary_operator_spaces"]}]}
```

#### PAY-10 · L · STY-02 — the PaymentCancelled event file is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Payment/app/Events/PaymentCancelled.php:1-3` |
| **Root cause** | The file packs `<?php`, `declare(strict_types=1);` and `namespace` with no blank lines, and declares the class body on one line; `vendor/bin/pint --test` reports six fixers. |
| **Consequence** | Cosmetic only; the file diverges from the project style run. |
| **Reproduce** | `vendor/bin/pint Modules/Payment/app/Events/PaymentCancelled.php --test` reports `result: fail`. |
| **Fix approach** | Run Pint on the file. |
| **Plan item** | PAY-10 in `02-fix-plan.md` §8 |

```php
// PaymentCancelled.php:1-3 — CURRENT
<?php
declare(strict_types=1);
namespace Modules\Payment\Events;
```

**Evidence**
```
$ vendor/bin/pint Modules/Payment/app/Events/PaymentCancelled.php --test
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Events\/PaymentCancelled.php","fixers":["class_attributes_separation","blank_line_after_opening_tag","braces_position","single_line_empty_body","blank_line_after_namespace","blank_lines_before_namespace"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 overwrite | 2 delete-before-store | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `initiate` | ok | ok | ok | ok | ok | ok | ok | ok |
| `callback` | ok | ok | PAY-06 | ok | PAY-02 | PAY-02 | ok | ok |
| `cancel` | ok (see §7 X2) | ok | ok | ok | ok | ok | ok | ok |

Notes: `initiate` deletes nothing, uses `Str::ulid()` (collision-safe) and writes inside the service's transaction. `callback`'s status guard is missing (PAY-02) and the driver handler logic is duplicated (PAY-06). `cancel`'s overwrite risk (cancelling an already-successful payment) lives in the linked `PaymentService::cancel()` and is recorded as §7 X2, not as a finding here.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Payment/app/Services/PaymentService.php` | X1 — `markSuccess()`, `markFailed()` and `cancel()` each write `ptm_payment_payments` **and** `ptm_payment_audit_logs` with no `DB::transaction`; only `initiate()` is wrapped. | TXN-01 | [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) (owner) |
| `Modules/Payment/app/Services/PaymentService.php` | X2 — `cancel()` sets `status = cancelled` with no guard that the payment is still `initiated`/`pending`, so a `success` payment can be cancelled. | F13#1 | ParentFeePaymentController report (owner) |
| `Modules/Payment/app/Services/PaymentService.php` | X3 — `initiate()` calls the gateway driver's `initiate()`, which for Razorpay/Paytm/PhonePe performs an HTTP call, inside its `DB::transaction`. | TXN-03 | ParentFeePaymentController report (owner) |
| `Modules/Payment/app/Services/GatewayManager.php` | X4 — `resolve()` instantiates drivers with `new $driverClass($credentials, $extraConfig)`, so drivers cannot constructor-inject `PaymentService` (this is why PAY-06 exists). | SVC-02 | ParentFeePaymentController report (owner) |
| `Modules/Payment/app/Http/Requests/PaymentCallbackRequest.php` | X5 — `authorize()` checks `tenant.payment.payment.create`, a permission a parent never holds, so the parent/student callback path cannot use it. Already tracked as **PFPC-06 VAL-02** in the ParentFeePaymentController report; this file is owned here but the fix belongs to that decision. Do not re-fix here. | VAL-02 | ParentFeePaymentController report (PFPC-06) |
| `Modules/Payment/app/Providers/PaymentServiceProvider.php` | X6 — missing `declare(strict_types=1)` (STY-01) and not Pint-clean; module glue, so it is a note, not audited here. | STY-01 | Payment module owner |

## 8. Not covered, and why

- **Live HTTP behaviour** of the four endpoints was not exercised (needs a Sanctum token and a tenant session), so every finding above is proven from source plus the route/scan instruments, per D4 (no tests).
- **`Payment` route model binding (CTL-03)** was not filed as a finding: the routes carry `{ulid}` while `Payment`'s route key is `id`, so binding would require a `getRouteKeyName()` change on the linked `Payment` model — out of this report's scope.
- **Paytm checksum correctness**: `PaytmGateway::generateChecksum()` salts with a random value while `verifyChecksum()` recomputes without a salt; whether real Paytm `CHECKSUMHASH` values ever verify is ⚠ UNVERIFIED — it would be settled by a captured Paytm sandbox response. Not filed as a finding.
- **`process-payment.blade.php`** is not rendered by any controller (`grep -rn 'razorpay.process-payment'` finds no caller), which is why PAY-05 is M rather than H.
- **Queue processing** of the webhook path and the gateway `handleWebhook()` bodies were read but not run.
