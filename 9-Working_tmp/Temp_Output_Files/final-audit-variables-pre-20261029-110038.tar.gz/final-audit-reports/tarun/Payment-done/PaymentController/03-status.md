# Status — Payment / PaymentController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output |
|---|---|---|---|---|
| PAY-01 | `PaymentController.php` | Removed the duplicate string permission gates in `initiate()`/`callback()`; kept the model-level policy gates. | `grep "tenant.payment.payment.create"` | none |
| PAY-02 | `PaymentController.php` | Offline gateway callbacks now `abort(422)` before the driver runs. | `grep "=== 'offline'"` | 1 hit |
| PAY-03 | `PaymentCallbackRequest.php`, `PaymentController.php` | Generalised callback validation for Razorpay/CCAvenue/BillDesk/Paytm/PhonePe; controller passes the full payload to the driver. | `grep "@var|nullable"` / route probe | pass |
| PAY-04 | `InitiatePaymentRequest.php` | Offline methods sourced from `OfflinePaymentRecord::METHOD_*`. | `grep -c "METHOD_"` | 5 |
| PAY-05 | `Modules/Payment/routes/web.php` | Callback declared as `{ulid}/callback` named `callback`, giving `payment.callback` and `payment/{ulid}/callback`. | `route:list --path=payment` | `payment.callback` present |
| PAY-07/PAY-08 | `PaymentController.php` | `show()` limits refunds/audit logs to 50 and hides `gateway.credentials` + `extra_config`. | `grep "makeHidden"` | 1 hit |
| PAY-09 | `PaymentController.php` | Emoji marker removed from the class comment. | `grep "⚠"` | none |
| PAY-10 | `Events/PaymentCancelled.php` | Pint-clean formatting. | `pint --test` | passed |

## 3. Not applied / deferred
- **PAY-06** — accepted ⭐: gateway drivers keep the service-locator construction (stateless parsers).

## 4. Shared changes
- `Modules/Payment/routes/web.php` callback declaration/name (applied here).

## 5. Verification
- `vendor/bin/pint <touched files> --format agent` → passed.
- `php -l` → no syntax errors.
- `php artisan route:list --path=payment` → callback route present.
- `php artisan view:cache` → compiled.

## 6. Final state
FIXED. No item left open except the accepted PAY-06 deviation.
