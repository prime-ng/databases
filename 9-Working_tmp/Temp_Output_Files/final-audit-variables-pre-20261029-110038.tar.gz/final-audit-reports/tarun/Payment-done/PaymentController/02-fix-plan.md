# Fix Plan — Payment / PaymentController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Payment/app/Http/Controllers/PaymentController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Payment/app/Services/PaymentService.php` | owned by the ParentPortal report (X1, X2, X3) |
| `Modules/Payment/app/Services/GatewayManager.php` | owned by the ParentPortal report (X4) |
| `Modules/Payment/app/Models/Payment.php` | owned by the ParentPortal report |
| `Modules/Payment/app/Models/PaymentGateway.php` | owned by the ParentPortal report |
| `Modules/Payment/app/Policies/PaymentPolicy.php`, `PaymentPolicy` | owned by this report but not edited by any item below |
| `database/migrations/tenant/**` | migrations are never edited |
| `Modules/Payment/app/Providers/PaymentServiceProvider.php` | module glue; X6 note only |

## 1. Blockers reachable today

- [ ] **PAY-08** · B · SEC-02 · `Modules/Payment/app/Http/Controllers/PaymentController.php:120-129` — stop returning the gateway's decrypted credentials, and bound the child loads.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentController.php`
  - **Before** (`PaymentController.php:120-129`):
    ```php
    public function show(string $ulid): JsonResponse
    {
        Gate::authorize('tenant.payment.payment.viewAny');

        $payment = $this->paymentService->getByUlid($ulid);

        Gate::authorize('view', $payment);

        return response()->json($payment->load(['gateway', 'refunds', 'auditLogs']));
    }
    ```
  - **After:**
    ```php
    public function show(string $ulid): JsonResponse
    {
        Gate::authorize('tenant.payment.payment.viewAny');

        $payment = $this->paymentService->getByUlid($ulid);

        Gate::authorize('view', $payment);

        $payment->load([
            'gateway',
            'refunds' => fn ($query) => $query->latest('id')->limit(50),
            'auditLogs' => fn ($query) => $query->latest('id')->limit(50),
        ]);

        // The gateway 'credentials' column uses an encrypted:array cast and PaymentGateway
        // declares no $hidden, so toArray() would decrypt and return merchant keys.
        // Hiding them here closes the leak (SEC-02, PAY-08, 2026-10-19).
        $payment->gateway?->makeHidden(['credentials', 'extra_config']);

        return response()->json($payment);
    }
    ```
  - **Verify:** `grep -n "makeHidden" Modules/Payment/app/Http/Controllers/PaymentController.php`
  - **Expect:** one output line containing `makeHidden`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

none.

## 3. Errors & transactions (F1/F2)

none — the controller owns no try/catch and no transaction (the service owns them; see §7 X1 in the report).

## 4. Authorization (F3)

- [ ] **PAY-01** · L · AUTH-04 · `Modules/Payment/app/Http/Controllers/PaymentController.php:37-48,74-81` — delete the two duplicate permission gates.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentController.php`
  - **Before** (`PaymentController.php:37-48`):
    ```php
    public function initiate(InitiatePaymentRequest $request): JsonResponse
    {
        Gate::authorize('tenant.payment.payment.create');

        $payableClass = $request->validated('payable_type');
        $payableId    = $request->validated('payable_id');
        $gatewayCode  = $request->validated('gateway');

        /** @var \Modules\Payment\Contracts\Payable $payable */
        $payable = $payableClass::findOrFail($payableId);

        Gate::authorize('create', Payment::class);
    ```
  - **Before** (`PaymentController.php:74-81`):
    ```php
    public function callback(PaymentCallbackRequest $request, string $ulid): JsonResponse
    {
        Gate::authorize('tenant.payment.payment.create');

        $payment = $this->paymentService->getByUlid($ulid);
        $gateway = $payment->gateway;

        Gate::authorize('view', $payment);
    ```
  - **After:** (`initiate()`):
    ```php
    public function initiate(InitiatePaymentRequest $request): JsonResponse
    {
        $payableClass = $request->validated('payable_type');
        $payableId    = $request->validated('payable_id');
        $gatewayCode  = $request->validated('gateway');

        /** @var \Modules\Payment\Contracts\Payable $payable */
        $payable = $payableClass::findOrFail($payableId);

        Gate::authorize('create', Payment::class);
    ```
  - **After:** (`callback()`):
    ```php
    public function callback(PaymentCallbackRequest $request, string $ulid): JsonResponse
    {
        $payment = $this->paymentService->getByUlid($ulid);
        $gateway = $payment->gateway;

        Gate::authorize('view', $payment);
    ```
  - **Verify:** `grep -n "tenant.payment.payment.create" Modules/Payment/app/Http/Controllers/PaymentController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **PAY-02** · M · AUTH-03 · `Modules/Payment/app/Http/Controllers/PaymentController.php:78-83` — reject the callback for the offline gateway.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentController.php`
  - **Before** (`PaymentController.php:78-83`):
    ```php
    $payment = $this->paymentService->getByUlid($ulid);
    $gateway = $payment->gateway;

    Gate::authorize('view', $payment);

    $driver = app(GatewayManager::class)->resolve($gateway->code);
    ```
  - **After:**
    ```php
    $payment = $this->paymentService->getByUlid($ulid);
    $gateway = $payment->gateway;

    Gate::authorize('view', $payment);

    if ($gateway->code === 'offline') {
        // OfflineGateway::verify() always returns true, so without this guard any user with
        // the create + view permissions can mark a counter cash/cheque payment as paid
        // (AUTH-03, PAY-02, 2026-10-19). Offline collections are confirmed by a human.
        abort(422, 'Offline payments cannot be confirmed through the gateway callback.');
    }

    $driver = app(GatewayManager::class)->resolve($gateway->code);
    ```
  - **Verify:** `grep -n "=== 'offline'" Modules/Payment/app/Http/Controllers/PaymentController.php`
  - **Expect:** one output line containing `=== 'offline'`.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **PAY-04** · L · MDL-09 · `Modules/Payment/app/Http/Requests/InitiatePaymentRequest.php:7-9,36` — build the offline-method rule from the model constants.
  - **Touches:** `Modules/Payment/app/Http/Requests/InitiatePaymentRequest.php`
  - **Before** (`InitiatePaymentRequest.php:7-9`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Modules\Payment\Contracts\Payable;
    use Modules\Payment\Models\PaymentGateway;
    ```
  - **Before** (`InitiatePaymentRequest.php:33-39`):
    ```php
    'gateway'    => ['required', 'string', 'in:' . implode(',', $activeGateways)],

    // Offline payment fields (required when gateway is offline)
    'offline_method'    => ['required_if:gateway,offline', 'string', 'in:cash,cheque,bank_transfer,demand_draft,upi_manual'],
    'offline_reference' => ['nullable', 'string', 'max:100'],
    'offline_notes'     => ['nullable', 'string', 'max:500'],
    ];
    ```
  - **After:** (`InitiatePaymentRequest.php:7-10`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Modules\Payment\Contracts\Payable;
    use Modules\Payment\Models\OfflinePaymentRecord;
    use Modules\Payment\Models\PaymentGateway;
    ```
  - **After:** (`InitiatePaymentRequest.php:33-46`):
    ```php
    'gateway'    => ['required', 'string', 'in:' . implode(',', $activeGateways)],

    // Offline payment fields (required when gateway is offline)
    'offline_method'    => [
        'required_if:gateway,offline',
        'string',
        'in:' . implode(',', [
            OfflinePaymentRecord::METHOD_CASH,
            OfflinePaymentRecord::METHOD_CHEQUE,
            OfflinePaymentRecord::METHOD_BANK_TRANSFER,
            OfflinePaymentRecord::METHOD_DEMAND_DRAFT,
            OfflinePaymentRecord::METHOD_UPI_MANUAL,
        ]),
    ],
    'offline_reference' => ['nullable', 'string', 'max:100'],
    'offline_notes'     => ['nullable', 'string', 'max:500'],
    ];
    ```
  - **Verify:** `grep -n "OfflinePaymentRecord::METHOD_" Modules/Payment/app/Http/Requests/InitiatePaymentRequest.php`
  - **Expect:** five output lines.
  - **Effort:** S

## 6. Queries & performance (F9)

none — PAY-07 is fixed by the PAY-08 response rewrite (§1).

## 7. Views (F10)

none — this controller renders no views.

## 8. Style (F12) — one item per file

- [ ] **PAY-09** · L · STY-04 · `Modules/Payment/app/Http/Controllers/PaymentController.php:16-17` — remove the emoji marker from the header comment.
  - **Touches:** `Modules/Payment/app/Http/Controllers/PaymentController.php`
  - **Before** (`PaymentController.php:16-17`):
    ```php
    /*
     * ⚠ Gate::authorize(...), NOT $this->authorize(...).
    ```
  - **After:**
    ```php
    /*
     * Note: Gate::authorize(...), NOT $this->authorize(...).
    ```
  - **Verify:** `grep -n '⚠' Modules/Payment/app/Http/Controllers/PaymentController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **PAY-10** · L · STY-02 · `Modules/Payment/app/Events/PaymentCancelled.php:1-12` — bring the file to Pint style.
  - **Touches:** `Modules/Payment/app/Events/PaymentCancelled.php`
  - **Before** (`PaymentCancelled.php:1-12`):
    ```php
    <?php
    declare(strict_types=1);
    namespace Modules\Payment\Events;
    use Illuminate\Foundation\Events\Dispatchable;
    use Illuminate\Queue\SerializesModels;
    use Modules\Payment\Models\Payment;

    class PaymentCancelled
    {
        use Dispatchable, SerializesModels;
        public function __construct(public readonly Payment $payment) {}
    }
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Payment\Events;

    use Illuminate\Foundation\Events\Dispatchable;
    use Illuminate\Queue\SerializesModels;
    use Modules\Payment\Models\Payment;

    class PaymentCancelled
    {
        use Dispatchable, SerializesModels;

        public function __construct(public readonly Payment $payment) {}
    }
    ```
  - **Verify:** `vendor/bin/pint Modules/Payment/app/Events/PaymentCancelled.php --test`
  - **Expect:** output contains `"result":"pass"`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **PAY-03** · H · DECISION · VAL-05 — how should the shared callback validate non-Razorpay gateways?
  - **Why it is a decision:** a behaviour change to a live payment endpoint; it alters what the callback accepts and what the driver receives.
  - (a) ⭐ Generalise the callback: make `PaymentCallbackRequest` accept an optional gateway payload (for example all three Razorpay fields become `nullable`, plus `sometimes` rules for `encResp`, `CHECKSUMHASH`, `X-VERIFY` and `BD_RESPONSE`), and pass `$request->all()` to `$driver->verify()` so each driver reads its own keys. Touches `PaymentCallbackRequest.php` and `PaymentController.php`.
  - (b) Keep the callback Razorpay-only and route each other gateway's redirect to its own handler (webhooks already cover Paytm, PhonePe and BillDesk; CCAvenue needs a new endpoint). Larger change, separate controller.
  - (c) Leave as is and document that only Razorpay can confirm through this callback, and that CCAvenue remains unsupported.
  - ➜ Choice: ____

- [ ] **PAY-05** · M · DECISION · RTE-02 — fix the web callback route name and URL. ⚠ SHARED
  - **Why it is a decision:** renaming a route and changing a URL are re-scopes (final-audit.md §9.3), and `Modules/Payment/routes/web.php` is shared.
  - (a) ⭐ In `Modules/Payment/routes/web.php` declare the route as `Route::post('{ulid}/callback', ...)->name('callback')`, so the effective name becomes `payment.callback` (matching the view caller) and the URL becomes `payment/{ulid}/callback` (removing the doubled `payment` segment). Touches a shared route file.
  - (b) Keep every route name and fix the caller instead: change `Modules/Payment/resources/views/razorpay/process-payment.blade.php:23` to `route('payment.payment.callback', ...)`.
  - (c) Leave as is — the view that calls the name is not rendered anywhere today.
  - ➜ Choice: ____

- [ ] **PAY-06** · M · DECISION · SVC-02 — inject `PaymentService` into the gateway drivers. ⚠ SHARED
  - **Why it is a decision:** the fix reaches `GatewayManager` (owned by the ParentPortal report) and changes driver construction.
  - (a) ⭐ Accept the service-locator pattern for drivers (`GatewayManager::resolve()` builds them with `new $driverClass(...)` and they are stateless parsers), and record the deviation — no code change here.
  - (b) Resolve drivers from the container and constructor-inject `PaymentService` into `BillDeskGateway`, `PaytmGateway`, `PhonePeGateway` and `RazorpayGateway`; requires editing `GatewayManager` in the ParentPortal report first.
  - (c) Extract the duplicated handler logic into one shared trait or base method and keep the service locator.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PAY-07 | Fixed by the same `show()` response rewrite as PAY-08 (§1) — the one coherent change bounds the child loads and hides the credentials; not a separate item. |
