# Status — Payment / BackendReceiptController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output |
|---|---|---|---|---|
| BRC-02 | `Backend/ReceiptController.php` | Receipt only renders for `Payment::STATUS_SUCCESS`; otherwise 404. | `grep "abort_unless"` | 1 hit |
| BRC-03 | `receipts/pdf.blade.php` | Uses `payable->getPayableLabel()` with a class/id fallback instead of the internal type + raw id. | `grep "getPayableLabel"` | 1 hit |
| BRC-04 | `Backend/ReceiptController.php` | Emoji/copy-pasted header replaced with a one-line permission comment; Pint-clean. | `grep "⚠"` / `pint --test` | none / passed |

## 3. Not applied / deferred
- **BRC-01** — accepted ⭐: keep load-then-authorize; the route key is a 128-bit ULID.

## 4. Shared changes
- None.

## 5. Verification
- Pint passed; `php -l` clean; `view:cache` compiled.

## 6. Final state
FIXED. BRC-01 recorded as accepted risk.
