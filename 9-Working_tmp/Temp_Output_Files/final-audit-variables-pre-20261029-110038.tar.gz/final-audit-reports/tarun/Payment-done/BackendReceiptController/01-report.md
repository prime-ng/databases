# Final Audit — Payment / BackendReceiptController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php` (41 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET http://test.localhost:8000/payment/payments/{ulid}/receipt` — one page: it streams a PDF download |
| Menu path | Payment (backend) → Payments list → the green **Receipt** button on a row (`Modules/Payment/resources/views/payments/index.blade.php:50`) |
| Who uses it | Any tenant user holding `tenant.payment.payment.view` (the gate this controller runs). By default that is Super Admin and School Admin. |
| What a user does here | Clicks **Receipt** on one payment and downloads a one-page PDF summary of that payment: what it was for, the gateway, the gateway order/payment ids, the status, the paid date and the amount. It is a money document a parent may keep or print. |
| Tables written | none — this controller only reads. |
| Tables read | `ptm_payment_payments` (the payment), `ptm_payment_gateways` (via the eager-loaded `gateway`), and the payable table (via the eager-loaded `payable`, e.g. the fee-invoice table). |
| Live data | tenant `00000000-0000-4000-8000-000000000001`: `ptm_payment_payments` 60 rows (24 `success`, 8 `failed`), `ptm_payment_gateways` 6 rows |

**How to reach each bug in the browser:** each finding carries a **Reproduce** line. The route needs an authenticated tenant session, so several checks are static-only.

## 1. Verdict

The controller is small and close to production-ready: one read-only method, no try/catch, a real `Gate::authorize('view', $payment)`, no state change over GET, and the route sits inside the tenant middleware group. It is **not production-ready as-is** for two reasons. First, the docblock promises "a PDF receipt for a **successful** payment" but the code never checks the status, so a hand-edited URL produces a "Payment Receipt" reading "Amount Paid" for a payment that failed or was never captured (BRC-02). Second, the receipt still prints the payable's internal class path and raw database id instead of a human label — a live example shows `Modules\StudentFee\Models\FeeInvoice #42` (BRC-03). The single worst finding is **BRC-02** (a misleading money document reachable by URL). No Blocker was found: the one suspected Blocker (gateway `credentials` and webhook secrets leaking into the PDF) is **not present** — the blade prints only `gateway->name`. Rough effort to work the plan: **S** (roughly 1–2 hours), with one item held as a decision for Tarun.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 2 | 2 | 1 | 4 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | n/a — no service or job is used |
| F2 Transactions/Audit | clean — read path, no writes | F9 Queries/Perf | clean (BRC-03 folds in the unused `payable` load) |
| F3 Authorization | BRC-01 | F10 Views | BRC-03 |
| F4 Validation | clean | F11 Security/Tenancy | clean — gateway secrets NOT printed |
| F5 Routes | clean | F12 Style | BRC-04 |
| F6 Controller shape | clean | F13 Deep read | BRC-02 (see the F13 table under §6) |
| F7 Models | clean — all three models are linked, not owned here | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php` | controller | 41 | this report | ✅ |
| 2 | `Modules/Payment/resources/views/receipts/pdf.blade.php` | view (PDF) | 41 | this report | ✅ |
| 3 | `Modules/Payment/app/Models/Payment.php` | model | 101 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 4 | `Modules/Payment/app/Models/PaymentGateway.php` | model | 76 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 5 | `Modules/Payment/app/Policies/PaymentPolicy.php` | policy | 46 | ↗ [tarun/Payment-done/PaymentController](../PaymentController/01-report.md) | ↗ linked |
| 6 | `Modules/Payment/app/Contracts/Payable.php` | contract | 38 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 7 | `Modules/Payment/Providers/RouteServiceProvider.php` | provider (module glue) | 78 | common module glue (§4.2) | ❌ inspected only — confirms `auth` + `verified` + tenancy middleware |
| 8 | `Modules/Payment/resources/views/payments/index.blade.php` | view (the caller) | — | not rendered by this controller | ❌ referenced only — the row action that links here, read at line 49-50 |

The linked classes are owned by other reports and are **not re-audited** here; this report only checks how this controller uses them. The `receipts/pdf.blade.php` view is used only by this controller (`grep -rn "receipts.pdf" Modules/ app/ resources/` returns the one `loadView` call at line 37), so it is owned here and a claim was appended to `00-CLASS-OWNERS.md`. No pre-applied files.

## 4. Routes

```
GET|HEAD payment/payments/{ulid}/receipt    payment.payment.backend.receipts.show    Modules\Payment\Http\Controllers\Backend\ReceiptController@show
```

Unrouted public methods: none. The controller has exactly one public method (`show`, line 29) and it is routed.

The effective route name carries two prefixes because the route file declares `->name('payment.backend.')` inside the module group and the module's `RouteServiceProvider` adds `->name('payment.')`; the result is `payment.payment.backend.receipts.show`. The caller in `payments/index.blade.php:50` uses `route('payment.backend.receipts.show', $payment->ulid)`, and Laravel resolves that short name through the `payment.` group, so the link works.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `show` | 29 | GET payment/payments/{ulid}/receipt | `view` (Payment policy → `tenant.payment.payment.view`) | n/a — read path | n/a | none | BRC-01, BRC-02 |

Note on the Gate column: `Gate::authorize('view', $payment)` passes the **model**, so it resolves through `PaymentPolicy::view()` (`Modules/Payment/app/Policies/PaymentPolicy.php:17-20`), which returns `$user->can('tenant.payment.payment.view')`. The permission name exists in `config/permissionslist.php:1130` (`'payment.payment' => array_merge($crud, ['cancel', 'refund'])`, where `$crud` at line 176 is `create, view, viewAny, update, delete, restore, forceDelete`). The policy is registered at `Modules/Payment/app/Providers/PaymentServiceProvider.php:41`.

## 6. Findings

### F1 — Errors

clean — the controller has no `try/catch`, no `getMessage()` and no debug leftovers; `firstOrFail()` sits outside any catch (D1).
```
$ grep -nE "try \{|catch \(|getMessage\(\)|dd\(|dump\(" Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php
(no output)
```

### F2 — Transactions and audit

clean — this is a read-only method. It performs no INSERT/UPDATE/DELETE and writes no audit row, so there is nothing to wrap in a transaction and no `activityLog` event to check.
```
$ grep -nE "DB::transaction|activityLog|->save\(\)|->update\(|->create\(|->delete\(" Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php
(no output)
```

### F3 — Authorization

#### BRC-01 · M · AUTH-02 — the payment is loaded before the gate runs (404-vs-403 leak)

| Field | Value |
|---|---|
| **Rule** | AUTH-02 (H) — *authorize first, before loading records and outside any try; loading first leaks whether an id exists (404 vs 403)*. Lowered to M because the route key is a ULID: a 128-bit random identifier that cannot be enumerated, so the 404/403 difference is not practically usable. |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php:31-35`, method `show()` |
| **Root cause** | The method runs `Payment::with(...)->where('ulid', $ulid)->firstOrFail()` at lines 31-33 and only then calls `Gate::authorize('view', $payment)` at line 35. Because the route has no permission middleware, an authenticated tenant user who holds no payment permission still reaches the method: a non-existent ulid answers 404, an existing ulid answers 403. The same shape exists in the sibling `BackendPaymentController::show()` (`Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:44-48`), so the whole receipt/payment detail family shares it. |
| **Consequence** | A user with no payment rights can tell a valid payment ULID from an invalid one, and triggers a database read for every guess. Because ULIDs are random this is a low-value oracle, but it is still an authorization-before-load violation and an unnecessary read for unauthorized callers. |
| **Reproduce** | Log in as a tenant user with no payment permission, then open `GET /payment/payments/{ulid}/receipt` with (a) a random ulid → 404 and (b) a real payment's ulid copied from the database → 403. Static only here — it needs a tenant session with a restricted role. |
| **Fix approach** | Add a record-independent pre-gate before the load (`Gate::authorize('viewAny', Payment::class)`) so a user with no payment rights is refused before any query; keep the model gate. This changes the permission surface, so it is a DECISION item, not an automatic fix. |
| **Plan item** | BRC-01 in `02-fix-plan.md` §9 (DECISION) |

```php
// ReceiptController.php:29-40 — CURRENT
    public function show(string $ulid): Response
    {
        $payment = Payment::with(['gateway', 'payable'])
            ->where('ulid', $ulid)
            ->firstOrFail();

        Gate::authorize('view', $payment);

        $pdf = Pdf::loadView('payment::receipts.pdf', compact('payment'));

        return $pdf->download("receipt-{$payment->ulid}.pdf");
    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-brc.json Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php Modules/Payment/resources/views/receipts/pdf.blade.php
L  STY-04   Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php:14  - — emoji in comment
M  AUTH-02  Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php:35  show — record loaded before authorization

$ grep -n "firstOrFail\|Gate::authorize" Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php
33:            ->firstOrFail();
35:        Gate::authorize('view', $payment);
```

### F4 — Validation and input

clean — the only input is the route parameter `{ulid}`, typed as `string $ulid` (line 29) and used solely as an Eloquent `where('ulid', $ulid)` binding, never interpolated. There is no request body, so no FormRequest is required.
```
$ grep -nE "request\(|->validate\(|->all\(\)|->except\(|request->" Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php
(no output)
```

### F5 — Routes

clean — the route exists and points at a method that exists (`show`), it is a GET that changes no state, the parameter name `{ulid}` matches the method argument `$ulid`, and the route sits inside the tenant middleware group. There is no `Route::resource` in this prefix, so no ordering issue.
```
$ grep -n "receipt\|ReceiptController" Modules/Payment/routes/web.php
15:    Route::get('{ulid}/receipt', [\Modules\Payment\Http\Controllers\Backend\ReceiptController::class, 'show'])->name('receipts.show');

$ grep -nE "InitializeTenancyByDomain|EnsureTenantIsActive|EnsureTenantHasModule|'auth'|'verified'" Modules/Payment/Providers/RouteServiceProvider.php
43:                InitializeTenancyByDomain::class,
44:                PreventAccessFromCentralDomains::class,
45:                EnsureTenantIsActive::class,
46:                EnsureTenantHasModule::class.':Payment',
47:                'auth',
48:                'verified',
```

### F6 — Controller shape

clean — 41 lines and 1 public method (far under the 1,000-line / 25-method CTL-01 threshold); the one method is short; the return type `: Response` is declared; no `compact()` over 15 variables, no `request()` helper, no dead code.
```
$ wc -l Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php
41 Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php

$ grep -nE "public function|private function|protected function" Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php
29:    public function show(string $ulid): Response
```
Route model binding (CTL-03) is not used because the route carries `{ulid}` while `Payment`'s route key is `id`; binding would need a `getRouteKeyName()` change on the linked `Payment` model, which is out of scope (see §8).

### F7 — Models

clean — this controller owns no model. The three models it reaches (`Payment`, `PaymentGateway`) and the contract (`Payable`) are owned by other reports and are linked in §3; this report only checks how they are used: `gateway` and `payable` are eager-loaded (no lazy-load N+1) and `gateway->name` is a plain column. The `payment->status` comparison added by BRC-02 uses the model's own `Payment::STATUS_SUCCESS` constant, so no new literal is introduced.
```
$ grep -n "STATUS_SUCCESS\|const STATUS" Modules/Payment/app/Models/Payment.php
47:    const STATUS_INITIATED  = 'initiated';
49:    const STATUS_SUCCESS    = 'success';
```

### F8 — Services and jobs

n/a — this controller injects no service, dispatches no job and queued no listener. It calls only `Pdf::loadView()` and `->download()` (a framework facade).
```
$ grep -nE "Service|Job|dispatch\(|::dispatch|__construct" Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php
(no output)
```

### F9 — Queries and performance

clean apart from the eager-load note folded into BRC-03 — the method issues one query for the payment plus one for the eager-loaded `gateway`; there is no loop and no N+1. The second eager load, `payable`, is currently loaded but never read by the blade (which prints the raw `payable_type`/`payable_id` columns instead); BRC-03 makes the view use it, so the query stops being wasted. No pagination is needed for a single row.
```
$ grep -n "with(\|->get()\|->paginate\|foreach" Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php
31:        $payment = Payment::with(['gateway', 'payable'])
```

### F10 — Views

#### BRC-03 · L · SEC-02 — the receipt prints the payable's internal class path and raw database id

| Field | Value |
|---|---|
| **Rule** | SEC-02 (H) — *no over-exposure: show mapped/human values, not raw internals*. Lowered to L because the exposed values are the payable's class name and primary key, not personal data, and the payment ULID already identifies the row to the user. |
| **Where** | `Modules/Payment/resources/views/receipts/pdf.blade.php:24`, rendered by `ReceiptController::show()` |
| **Root cause** | The blade prints the morph columns directly: `{{ $payment->payable_type }} #{{ $payment->payable_id }}`. `payable_type` is stored as the fully-qualified class name (no morph alias is registered for `FeeInvoice`), so every receipt prints something like `Modules\StudentFee\Models\FeeInvoice #42`. The controller eagerly loads the `payable` relation for exactly this document, but the blade never calls it, so the human label the `Payable` contract provides (`getPayableLabel()`) is skipped and the extra query is wasted. |
| **Consequence** | A parent who downloads and keeps the receipt sees an internal PHP class path and a raw database id where a label such as "Fee Invoice #INV-2026-001" should be. |
| **Reproduce** | Open a successful payment and click **Receipt**; the first table row reads `Receipt For: Modules\StudentFee\Models\FeeInvoice #<id>`. |
| **Fix approach** | Render the payable label and fall back to the raw columns only when the relation is missing (a soft-deleted payable). No controller change is needed — the relation is already eager-loaded. |
| **Plan item** | BRC-03 in `02-fix-plan.md` §7 |

```php
// pdf.blade.php:24 — CURRENT
        <tr><th>Receipt For</th><td>{{ $payment->payable_type }} #{{ $payment->payable_id }}</td></tr>
```

**Evidence**
```
$ sed -n '24p' Modules/Payment/resources/views/receipts/pdf.blade.php
        <tr><th>Receipt For</th><td>{{ $payment->payable_type }} #{{ $payment->payable_id }}</td></tr>

$ timeout 90 php artisan tinker --execute '$t=\Modules\Prime\Models\Tenant::query()->first(); $t->run(function(){ foreach(\DB::table("ptm_payment_payments")->select("payable_type")->distinct()->limit(5)->get() as $r) echo $r->payable_type."\n"; });'
Modules\StudentFee\Models\FeeInvoice

$ grep -n "credential\|secret\|password\|token\|signature" Modules/Payment/resources/views/receipts/pdf.blade.php
38:        This is a computer-generated receipt and does not require a signature.
```

The blade also passes the F10 checks: no query in Blade, no `{!! !!}` on user text, `gateway` and `payable` both eager-loaded by the controller, and the file compiles cleanly.
```
$ grep -nE "Model::|DB::|->where\(|->get\(\)|->count\(\)|\{!!" Modules/Payment/resources/views/receipts/pdf.blade.php
(no output)

$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); $out=app("blade.compiler")->compileString(file_get_contents("Modules/Payment/resources/views/receipts/pdf.blade.php")); file_put_contents("/tmp/fa-blade.php",$out); echo "COMPILED len=".strlen($out)."\n";' && php -l /tmp/fa-blade.php
COMPILED len=1794
No syntax errors detected in /tmp/fa-blade.php
```

### F11 — Security and tenancy

clean — the suspected leak is **not present**. The blade prints only `$payment->gateway?->name` (line 26), never the gateway's `credentials` (an `encrypted:array` column holding merchant keys and webhook secrets) or `extra_config`. No `env()` call, no personal data over-exposed, no hard-coded id, no secrets logged. The route is private and sits behind `auth` + `verified` + tenancy.
```
$ grep -nE "credential|secret|extra_config|env\(|->metadata|password|token" Modules/Payment/resources/views/receipts/pdf.blade.php
(no output)
grep: no matches — only the word "signature" appears, in the static footer line 38

$ grep -rn "env(" Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php
(no output)
```

### F12 — Style

#### BRC-04 · L · STY-04 — copy-pasted emoji header comment, and the file is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers, no copy-pasted docblocks that describe another resource*; plus STY-02 (Pint-clean) |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php:14-23` (and the import order at lines 7-8) |
| **Root cause** | The class is preceded by an 11-line block comment that begins with the warning-symbol emoji and is copied verbatim into four Payment controllers (`PaymentController`, `Backend/PaymentController`, `RefundController`, `Backend/RefundController`), where it describes those files' methods, not this one. Separately, the imports are not alphabetically sorted, so `vendor/bin/pint --test` reports `ordered_imports`. |
| **Consequence** | Cosmetic: the file diverges from the style run, and the shared comment claims this controller had a `$this->authorize()` 500 that it never had. |
| **Reproduce** | `vendor/bin/pint Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php --test` reports `result: fail`. |
| **Fix approach** | Replace the copied block with a one-line comment naming this controller's real behaviour, then run Pint on the file (which fixes the import order too). |
| **Plan item** | BRC-04 in `02-fix-plan.md` §8 |

```php
// ReceiptController.php:14-23 — CURRENT
 * ⚠ Gate::authorize(...), NOT $this->authorize(...).
 *
 * Laravel 11 removed AuthorizesRequests from Illuminate\Routing\Controller and
 * App\Http\Controllers\Controller here is an empty abstract class, so $this->authorize()
 * resolves to nothing and every call was a BadMethodCallException — a 500 on the payment
 * list, the payment detail page, the receipt and the refund list. The authorization never
 * ran, because the request never got that far.
 *
 * The model argument is kept: it is what routes the check through the Policy.
 */
```

**Evidence**
```
$ vendor/bin/pint Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php --test --format json
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Http\/Controllers\/Backend\/ReceiptController.php","fixers":["ordered_imports"]}]}

$ grep -n '⚠' Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php
14: * ⚠ Gate::authorize(...), NOT $this->authorize(...).

$ grep -rln "Laravel 11 removed AuthorizesRequests" Modules/Payment/app/Http/Controllers/
Modules/Payment/app/Http/Controllers/PaymentController.php
Modules/Payment/app/Http/Controllers/Backend/PaymentController.php
Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php
Modules/Payment/app/Http/Controllers/Backend/RefundController.php
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There are **no mutating methods** in this controller — `show` is a pure read that streams a PDF. The table below still records the read path against the eight questions, because the document it produces can mislead.

| Method | 1 overwrite | 2 delete-before-store | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `show` (read) | ok | ok | ok | ok | ok | BRC-01 | BRC-02 | ok |

Notes for the only non-ok cells:

- **#6 auth hole → BRC-01**: the record is loaded before the gate (see F3).
- **#7 message lies → BRC-02**: the method's docblock (lines 26-28) says "a PDF receipt for a **successful** payment", but no status check exists. The Payments list only links the button for `status === 'success'` (`payments/index.blade.php:49`), so the normal click path is success-only — but the URL is directly addressable, so a `failed`, `cancelled`, `pending` or `initiated` payment's receipt can still be downloaded. That receipt then reads "Status: Failed" together with the heading "Amount Paid" and "Paid At: —", i.e. it calls an amount "paid" that was never collected. See finding below.
- **#8 dead feature**: none. The `payable` eager load is currently unused and is addressed by BRC-03.

#### BRC-02 · M · F13-7 — a receipt can be issued for a payment that never succeeded

| Field | Value |
|---|---|
| **Rule** | F13 #7 (M) — *the deep-read catalogue: "messages that lie" — success shown when nothing succeeded*. Medium rather than High because the UI only links the button on `success` rows, so this needs a hand-edited or bookmarked URL. |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php:29-40`, method `show()` (contrast with `payments/index.blade.php:49`, which gates the link on `success`) |
| **Root cause** | `show()` loads the payment by ulid and maps it to the PDF with no status guard, even though the docblock and the list view both treat a receipt as success-only. `Payment` declares `STATUS_SUCCESS` and a `scopeSuccessful()` scope, so the domain rule exists but is not applied on this read path. |
| **Consequence** | Anyone holding `tenant.payment.payment.view` can download a document headed "Payment Receipt" that shows "Amount Paid: ₹ …" for a failed or never-captured payment — a financial statement that is false on its face, which a parent could keep or forward. |
| **Reproduce** | Take the ulid of a `failed` payment and open `GET /payment/payments/{ulid}/receipt` directly. The PDF renders with "Status: Failed" and "Amount Paid". |
| **Fix approach** | Refuse a receipt for any status other than `success` by adding `abort_unless($payment->status === Payment::STATUS_SUCCESS, 404);` after the gate. A 404 (not 403) keeps the refusal from confirming that the payment exists. |
| **Plan item** | BRC-02 in `02-fix-plan.md` §5 |

```php
// ReceiptController.php:29-40 — CURRENT
    public function show(string $ulid): Response
    {
        $payment = Payment::with(['gateway', 'payable'])
            ->where('ulid', $ulid)
            ->firstOrFail();

        Gate::authorize('view', $payment);

        $pdf = Pdf::loadView('payment::receipts.pdf', compact('payment'));

        return $pdf->download("receipt-{$payment->ulid}.pdf");
    }
```

**Evidence**
```
$ sed -n '44,52p' Modules/Payment/resources/views/payments/index.blade.php
                                        <a href="{{ route('payment.backend.payments.show', $payment->ulid) }}" class="btn btn-sm btn-outline-primary">View</a>
                                        @if($payment->status === 'success')
                                            <a href="{{ route('payment.backend.receipts.show', $payment->ulid) }}" class="btn btn-sm btn-outline-success">Receipt</a>
                                        @endif

$ grep -n "STATUS_SUCCESS\|scopeSuccessful" Modules/Payment/app/Models/Payment.php
49:    const STATUS_SUCCESS    = 'success';
91:    public function scopeSuccessful($query)

$ timeout 90 php artisan tinker --execute '$t=\Modules\Prime\Models\Tenant::query()->first(); $t->run(function(){ echo "success=".\DB::table("ptm_payment_payments")->where("status","success")->count()."\n"; echo "failed=".\DB::table("ptm_payment_payments")->where("status","failed")->count()."\n"; });'
success=24
failed=8
```

**Filename check (part of this question).** The download name is `receipt-{ulid}.pdf`, built from the payment's own ULID, which is a public opaque identifier already shown in the payments list. It leaks no student name, no amount, no gateway secret and no sequential id, so the filename is clean and needs no change.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php` | The sibling `show()` loads the payment before `Gate::authorize('view', $payment)` (`:44-48`) — the same AUTH-02 ordering as BRC-01. Decide it once, then apply the same answer there. | AUTH-02 | [tarun/Payment-done/BackendPaymentController](../BackendPaymentController/01-report.md) (owner) |
| `Modules/Payment/app/Http/Controllers/PaymentController.php` | The full `Payment` graph (including `gateway.credentials`) is returned by the JSON detail endpoint — already filed as PAY-08 (Blocker) in the PaymentController report. Not a leak in this PDF, but the same gateway model is involved. | SEC-02 | [tarun/Payment-done/PaymentController](../PaymentController/01-report.md) (PAY-08) |
| `Modules/Payment/app/Providers/RouteServiceProvider.php` | Missing `declare(strict_types=1)`; module glue, so a note only. | STY-01 | Payment module owner |

## 8. Not covered, and why

- **Live HTTP behaviour** of the receipt route was not exercised (it needs an authenticated tenant session), so every finding above is proven from source plus the route/scan instruments, per D4 (no tests).
- **The exact visual PDF** was not generated: `Pdf::loadView(...)->download(...)` was not run, to avoid writing a file. The blade was compiled instead (`blade.compiler')->compileString(...)` → `php -l` passes), and its rendered row text was read from the source.
- **`Payment` route model binding (CTL-03)** was not filed as a finding: the route carries `{ulid}` while `Payment`'s route key is `id`, so binding would require a `getRouteKeyName()` change on the linked `Payment` model, which is out of this report's scope.
- **The `Payable` contract methods** (`getPayableLabel()` and friends) are owned by the ParentPortal report and were not re-audited; BRC-03 only relies on the label method existing.
- **Which roles hold `tenant.payment.payment.view`** was not measured against `sys_role_has_permissions_jnt`; the default (Super Admin, School Admin) is taken from the sibling PaymentController report.
