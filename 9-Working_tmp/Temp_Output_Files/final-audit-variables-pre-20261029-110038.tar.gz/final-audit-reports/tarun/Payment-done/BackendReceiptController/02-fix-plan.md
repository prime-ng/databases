# Fix Plan — Payment / BackendReceiptController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Payment/routes/web.php` | a route file — no route change is needed for any item here |
| `config/permissionslist.php` | shared config; the permissions this plan uses already exist |
| `Modules/Payment/app/Models/Payment.php` | owned by [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) |
| `Modules/Payment/app/Models/PaymentGateway.php` | owned by [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) |
| `Modules/Payment/app/Contracts/Payable.php` | owned by [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) |
| `Modules/Payment/app/Policies/PaymentPolicy.php` | owned by [tarun/Payment-done/PaymentController](../PaymentController/01-report.md) |
| `Modules/Payment/resources/views/payments/index.blade.php` | the caller view — read-only context, not part of any fix |

## 1. Blockers reachable today

None. The audit found no Blocker: the one suspected Blocker (gateway `credentials` leaking into the PDF) is not present — the blade prints only `gateway->name` (BRC-01 report §F11).

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None.

## 4. Authorization (F3)

BRC-01 is a DECISION and is listed in §9.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **BRC-02** · M · F13-7 · `ReceiptController.php:29-40` — refuse a receipt for a payment that is not `success`, so the PDF stops calling an uncollected amount "paid".
  - **Touches:** `Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php`
  - **Before** (`ReceiptController.php:29-40`):
    ```php
        public function show(string $ulid): Response
        {
            $payment = Payment::with(['gateway', 'payable'])
                ->where('ulid', $ulid)
                ->firstOrFail();

            Gate::authorize('view', $payment);

            $pdf = Pdf::loadView('payment::receipts.pdf', compact('payment'));

            return $pdf->download("receipt-{$payment->ulid}.pdf");
        }
    ```
  - **After:**
    ```php
        public function show(string $ulid): Response
        {
            $payment = Payment::with(['gateway', 'payable'])
                ->where('ulid', $ulid)
                ->firstOrFail();

            Gate::authorize('view', $payment);

            // BRC-02 (2026-10-19): a receipt is only valid for a captured payment.
            abort_unless($payment->status === Payment::STATUS_SUCCESS, 404);

            $pdf = Pdf::loadView('payment::receipts.pdf', compact('payment'));

            return $pdf->download("receipt-{$payment->ulid}.pdf");
        }
    ```
  - **Verify:** `grep -n "abort_unless\|STATUS_SUCCESS" Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php`
  - **Expect:** one line containing `abort_unless($payment->status === Payment::STATUS_SUCCESS, 404);`.
  - **Effort:** S

## 6. Queries & performance (F9)

None. The unused `payable` eager load is resolved by BRC-03 in §7 (the fix makes the view use that relation).

## 7. Views (F10)

- [ ] **BRC-03** · L · SEC-02 · `receipts/pdf.blade.php:24` — show the payable's human label instead of its internal class path and raw database id.
  - **Touches:** `Modules/Payment/resources/views/receipts/pdf.blade.php`
  - **Before** (`pdf.blade.php:24`):
    ```php
            <tr><th>Receipt For</th><td>{{ $payment->payable_type }} #{{ $payment->payable_id }}</td></tr>
    ```
  - **After:**
    ```php
            <tr><th>Receipt For</th><td>{{ $payment->payable?->getPayableLabel() ?? $payment->payable_type . ' #' . $payment->payable_id }}</td></tr>
    ```
  - **Verify:** `grep -n "getPayableLabel" Modules/Payment/resources/views/receipts/pdf.blade.php`
  - **Expect:** one line containing `getPayableLabel()`.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **BRC-04** · L · STY-04 · `ReceiptController.php:14-23` — replace the copy-pasted emoji header comment with a one-line comment, then make the file Pint-clean.
  - **Touches:** `Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php`
  - **Before** (`ReceiptController.php:14-23`):
    ```php
     * ⚠ Gate::authorize(...), NOT $this->authorize(...).
     *
     * Laravel 11 removed AuthorizesRequests from Illuminate\Routing\Controller and
     * App\Http\Controllers\Controller here is an empty abstract class, so $this->authorize()
     * resolves to nothing and every call was a BadMethodCallException — a 500 on the payment
     * list, the payment detail page, the receipt and the refund list. The authorization never
     * ran, because the request never got that far.
     *
     * The model argument is kept: it is what routes the check through the Policy.
     */
    ```
  - **After:**
    ```php
    /*
     * Permission: tenant.payment.payment.view, checked through PaymentPolicy::view().
     */
    ```
  - **Verify:** `vendor/bin/pint Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php --format agent && vendor/bin/pint Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php --test`
  - **Expect:** `result: pass` in the second command, and no line containing a warning-symbol emoji in the file.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BRC-01** · M · DECISION · AUTH-02 — should the check run before the payment is loaded, given the load currently happens first?
  - **Why it is a decision:** fixing it changes *which* permission a caller must hold, or adds a second gate; the current `view` ability needs the loaded model, so there is no automatic same-file fix. Pick one answer and apply it here and in the sibling `BackendPaymentController`.
  - (a) ⭐ accept and record — leave the order as it is. The route key is a ULID (a 128-bit random identifier), so the 404-vs-403 difference cannot be used to enumerate records, and the only link into the page is the Payments list, which is already gated by `viewAny`. No code change; record the accepted risk in `03-status.md`.
  - (b) add a pre-gate — insert `Gate::authorize('viewAny', Payment::class);` as the first line of `show()`, before the `Payment::with(...)` query, and keep `Gate::authorize('view', $payment);` after it. A caller with no payment rights is then refused before any query. Cost: `viewAny` already exists in `config/permissionslist.php` (the `$crud` floor), so no new key, but the method now requires both `viewAny` and `view`.
  - (c) introduce a record-independent ability — add a policy method (for example `viewReceipt`) that checks only the permission and call it before the load. This edits `PaymentPolicy.php`, which is owned by the PaymentController report, so it must be coordinated with that report and is `⚠ SHARED`.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| none | every finding in `01-report.md` (BRC-01 … BRC-04) has a plan item above |
