# Final Audit — Payment / WebhookController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/Payment/app/Http/Controllers/WebhookController.php` (147 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `POST /payment/webhooks/{gateway}` → route name `payment.webhook.handle`. A machine endpoint: it renders no page and answers JSON. |
| Menu path | None. There is no menu entry and no blade view for this controller; the stored rows are listed by a different controller (`Backend\WebhookController@index` at `payment/payment-webhooks`). |
| Who uses it | Payment gateway servers (Razorpay and the other drivers seeded in `ptm_payment_gateways`). The route is deliberately unauthenticated — a gateway has no session or token. It is protected by the `payment.webhook.verify` middleware, which HMAC-verifies the raw body against the tenant's gateway secret before the controller runs. |
| What a user does here | Nobody clicks anything. A gateway POSTs an event ("payment.captured", a refund event, and so on). The app verifies the signature, stores one row in `ptm_payment_webhooks`, queues `ProcessWebhookJob`, writes a courtesy activity-log entry, and answers `{"status":"queued"}` with HTTP 200. The job later hands the payload to the gateway driver and raises `WebhookReceived`. |
| Tables written | `ptm_payment_webhooks` (INSERT), `jobs` (queue dispatch), `sys_activity_logs` (attempted — see WHK-07) |
| Tables read | `ptm_payment_gateways` (via `GatewayManager`), `ptm_payment_webhooks` |
| Live data | test tenant `00000000-0000-4000-8000-000000000001`: `ptm_payment_webhooks` 0 rows, `ptm_payment_gateways` 6 rows (RAZORPAY active, OFFLINE active, the rest inactive). The table has the unique index `ptm_payment_webhooks_idempotency_key_unique`. |

**How to reach each bug in the browser:** the endpoint is not a browser screen. Each finding states its own reproduction, mostly a repeated gateway POST or a static reading.

## 1. Verdict

Not production-ready as written. The security spine is deliberately and correctly shaped for a gateway: the route is unauthenticated on purpose, CSRF is exempted for `payment/webhooks/*`, and `VerifyWebhookSignature` runs before the controller and HMAC-verifies the raw body. The controller also does not leak exception text to the caller, and it stores then queues rather than doing slow work in the request.

The single worst finding is the idempotency key: it uses the payment id, so two different Razorpay events for the same payment collide on the unique index, and it falls back to `uniqid()`, so an event it cannot parse is stored again on every replay (WHK-05/WHK-06). The collision path is answered with HTTP 500 instead of an idempotent 200, which makes the gateway retry a delivery that will never succeed. The activity log the code claims to write can never be written (WHK-07), because the helper needs a non-null `user_id` and a webhook has no user. The rest is medium/low: two errant controller catches against D1, exception logging without the exception object, a missing job timeout, two unused job dependencies, and a latent signature-assertion gap. Rough effort: the two H fixes are a few hours; the four DECISION items need one product/Tarun choice each.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 9 | 2 | 4 | 13 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | WHK-01, WHK-02, WHK-03 | F8 Services/Jobs | WHK-10, WHK-11 |
| F2 Transactions/Audit | WHK-04, WHK-05, WHK-06, WHK-07 | F9 Queries/Perf | clean |
| F3 Authorization | clean (deliberate, §4) | F10 Views | clean (no views) |
| F4 Validation | WHK-08 | F11 Security/Tenancy | WHK-12 |
| F5 Routes | clean | F12 Style | WHK-13 |
| F6 Controller shape | WHK-09 | F13 Deep read | see schedule in §6 F13 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Payment/app/Http/Controllers/WebhookController.php` | controller | 147 | this report | ✅ |
| 2 | `Modules/Payment/app/Http/Middleware/VerifyWebhookSignature.php` | middleware (in-scope boundary) | 76 | this report | ✅ |
| 3 | `Modules/Payment/app/Models/PaymentWebhook.php` | model | 43 | this report (pre-assigned 00-CLASS-OWNERS line 507) | ✅ |
| 4 | `Modules/Payment/app/Jobs/ProcessWebhookJob.php` | job | 76 | this report (line 508) | ✅ |
| 5 | `Modules/Payment/app/Events/WebhookReceived.php` | event | 12 | this report (line 509) | ✅ |
| 6 | `Modules/Payment/app/Listeners/WebhookReceivedListener.php` | listener | 36 | this report (line 510) | ✅ |
| 7 | `Modules/Payment/routes/webhooks.php` | route file | 30 | this report (routes only) | ✅ |
| 8 | `Modules/Payment/app/Providers/RouteServiceProvider.php` | provider (route registration) | 95 | this report (registration only) | ✅ |
| 9 | `Modules/Payment/app/Providers/EventServiceProvider.php` | provider (listener wiring) | 68 | this report (the single mapping only) | ✅ |
| 10 | `database/migrations/tenant/2026_06_18_100106_create_ptm_payment_webhooks_table.php` | migration (read-only evidence) | 46 | this report | ✅ |
| 11 | `Modules/Payment/app/Models/Payment.php` | model | 101 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) (line 324) | ↗ linked (usage checked, §7) |
| 12 | `Modules/Payment/app/Services/PaymentService.php` | service | — | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) (line 325) | ↗ linked (usage checked, §7) |
| 13 | `Modules/Payment/app/Services/AuditService.php` | service | 104 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) (line 356) | ↗ linked (usage checked, §7) |
| 14 | `Modules/Payment/app/Services/GatewayManager.php` | service | 85 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) (line 326) | ↗ linked (usage checked, §7) |
| 15 | `Modules/Payment/app/Gateways/RazorpayGateway.php`, `BaseGateway.php` | gateway + base | — | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) (lines 353-354) | ↗ linked (usage checked, §7) |
| 16 | `Modules/Payment/app/Models/PaymentAuditLog.php` | model (written by the listener) | 43 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) (line 360) | ↗ linked (usage checked, §7) |
| 17 | `app/Helpers/activityLog.php` | common helper | 51 | common (app/) — cross-cutting, §7 | ❌ common, not audited here |

No in-scope file appears in a `PRE-APPLIED-*.md` (the only such file is for TimetableFoundation).

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --path=payment/webhooks
  POST       payment/webhooks/{gateway} payment.webhook.handle › Modules\Paym…
```

The route's full middleware stack, from the uncached `route:list --json`:

```
["web","Stancl\\Tenancy\\Middleware\\PreventAccessFromCentralDomains","Stancl\\Tenancy\\Middleware\\InitializeTenancyByDomain","App\\Http\\Middleware\\EnsureTenantIsActive","Modules\\Payment\\Http\\Middleware\\VerifyWebhookSignature"]
```

`VerifyWebhookSignature` is the last middleware, so it runs after tenancy is initialized and **before** `handle()`. The route is registered in `Modules/Payment/routes/webhooks.php:25-30` and mounted by `RouteServiceProvider::mapWebhookRoutes()` (lines 66-75), which deliberately omits `auth` and `EnsureTenantHasModule`. CSRF is exempted for `payment/webhooks/*` in `bootstrap/app.php:66-74`, otherwise every gateway POST would die with 419 before the signature check.

Unauthenticated route: deliberate, not a finding. The evidence is the middleware stack above plus `VerifyWebhookSignature::handle()` (lines 30-75), which returns 401 on a bad signature and only calls `$next($request)` after setting the `webhook_payload` attribute.

Unrouted public methods: none — `handle()` is the only public method.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `handle` | 32 | POST payment/webhooks/{gateway} | none (deliberate; `payment.webhook.verify` middleware) | controller, lines 35-53 | 'Received' at line 60, AFTER the transaction | ptm_payment_webhooks, jobs, sys_activity_logs (attempted) | WHK-01, WHK-02, WHK-03, WHK-04, WHK-05, WHK-06, WHK-07, WHK-08, WHK-09, WHK-12, WHK-13 |
| `extractIdempotencyKey` | 97 | private | — | — | — | — | WHK-05, WHK-09 |
| `extractEventType` | 115 | private | — | — | — | — | WHK-09 |
| `extractBillDeskOrderId` | 129 | private | — | — | — | — | WHK-05, WHK-09 |
| `extractBillDeskStatus` | 140 | private | — | — | — | — | WHK-09 |

## 6. Findings

### F1 — Errors

#### WHK-01 · M · ERR-00 — Controller wraps the whole webhook flow in try/catch (against D1)

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M here) — *no try/catch in controllers; `DB::transaction` rolls back and rethrows, and the central handler in `bootstrap/app.php` renders; only the D2 shapes are allowed* |
| **Where** | `Modules/Payment/app/Http/Controllers/WebhookController.php:34-91`, method `handle()` |
| **Root cause** | The whole method sits inside `try { ... } catch (\Throwable $e)` (line 78) with an extra `catch (ModelNotFoundException)` (line 74) and a nested try/catch around `activityLog` (line 59). D1 removes controller try/catch because `DB::transaction` already rolls back and rethrows. The stated reason — a gateway must receive HTTP 500, not a redirect — is real, but the central renderer already returns HTTP 500 for an unexpected failure (the web branch in `bootstrap/app.php:140-151` returns null and Laravel renders its default 500), so the status the gateway needs survives without a controller catch. None of the three catches is one of the D2 shapes. |
| **Consequence** | Every unexpected failure is flattened into one generic `{"status":"error"}` and logged twice; the code carries three catches that must each stay correct against ERR-02/03/05/06, and the D1 idiom is not applied for no behavioural gain. |
| **Reproduce** | Static only — the shape is visible at `WebhookController.php:34,59,74,78`. A live reproduction needs a gateway POST, which this workflow does not run (D4). |
| **Fix approach** | Remove the outer `try`/`catch (\Throwable)` and the dead `catch (ModelNotFoundException)`; keep the transaction and return the JSON 200 after it, and let the central handler render failures. Decide the nested log catch with WHK-07/WHK-04. Because the correct shape depends on the gateway-500 requirement, this is a DECISION. |
| **Plan item** | WHK-01 in `02-fix-plan.md` §9 (DECISION) |

```php
// WebhookController.php:34-91 — CURRENT
        try {
            $webhook = DB::transaction(function () use ($request, $gateway) {
                $payload = $request->attributes->get('webhook_payload', $request->all());

                $webhook = PaymentWebhook::create([
                    'gateway'         => $gateway,
                    'event_type'      => $this->extractEventType($gateway, $payload),
                    'idempotency_key' => $this->extractIdempotencyKey($gateway, $payload, $request),
                    'payload'         => $payload,
                    'signature_valid' => true,
                    'processed'       => false,
                    'is_active'       => true,
                ]);

                // The queue table is on the central connection, outside this transaction.
                // afterCommit() keeps a rolled-back webhook from leaving an orphan job behind.
                ProcessWebhookJob::dispatch($webhook)->afterCommit();

                return $webhook;
            });

            // Deliberately outside the transaction and non-fatal. sys_activity_logs.user_id is
            // NOT NULL and a gateway request has no user, so this insert used to throw, roll the
            // webhook back and answer 500 — every genuine Razorpay webhook was rejected. The
            // stored PaymentWebhook row is the durable record of the event; this is a courtesy.
            try {
                activityLog($webhook, 'Received', [
                    'message'         => 'Payment webhook was received and queued.',
                    'gateway'         => $gateway,
                    'event_type'      => $webhook->event_type,
                    'idempotency_key' => $webhook->idempotency_key,
                ]);
            } catch (\Throwable $e) {
                Log::warning('Payment webhook stored and queued, but its activity log could not be written', [
                    'webhook_id' => $webhook->id,
                    'error'      => $e->getMessage(),
                ]);
            }

            return response()->json(['status' => 'queued'], 200);
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('WebhookController::handle failed', [
                'gateway' => $gateway,
                'error'   => $e->getMessage(),
            ]);

            // The caller is a payment gateway, not a browser. A redirect reads as a 3xx and
            // the gateway treats the delivery as accepted — the webhook would be dropped and
            // never retried. Answer with a 500 so its back-off actually fires.
            return response()->json([
                'status'  => 'error',
                'message' => 'The webhook could not be accepted.',
            ], 500);
        }
```

**Evidence**

```
$ grep -n "try {\|catch (" Modules/Payment/app/Http/Controllers/WebhookController.php
34:        try {
59:            try {
66:            } catch (\Throwable $e) {
74:        } catch (ModelNotFoundException $e) {
78:        } catch (\Throwable $e) {
```

#### WHK-02 · M · ERR-05 — Logs record `getMessage()` instead of the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not just its message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/Payment/app/Jobs/ProcessWebhookJob.php:74` (also `Modules/Payment/app/Http/Middleware/VerifyWebhookSignature.php:63,66`) |
| **Root cause** | Each catch interpolates `{$e->getMessage()}` into the log string or passes `'error' => $e->getMessage()`. The exception object is never handed to the logger, so nothing records the exception class, file, line or stack trace. `ProcessWebhookJob::handle()` (line 58) does it correctly (`'exception' => $e`); `failed()` and the middleware do not. The controller's own two log calls (lines 69, 81) are removed with WHK-01, so they are not fixed here. |
| **Consequence** | When a webhook fails, the log line names a message but not where it came from; an operator cannot tell a gateway-driver failure from a DB failure without reproducing it. |
| **Reproduce** | Static only — the log context is built at the named lines. |
| **Fix approach** | Pass the exception object: `['exception' => $e]`, keeping a fixed message string. |
| **Plan item** | WHK-02 in `02-fix-plan.md` §3 |

```php
// ProcessWebhookJob.php:74 — CURRENT
        Log::error("ProcessWebhookJob permanently failed for webhook [{$this->webhook->id}]: {$exception->getMessage()}");
```

**Evidence**

```
$ grep -n "getMessage" Modules/Payment/app/Jobs/ProcessWebhookJob.php Modules/Payment/app/Http/Middleware/VerifyWebhookSignature.php
Modules/Payment/app/Jobs/ProcessWebhookJob.php:74:        Log::error("ProcessWebhookJob permanently failed for webhook [{$this->webhook->id}]: {$exception->getMessage()}");
Modules/Payment/app/Http/Middleware/VerifyWebhookSignature.php:63:            Log::warning("Payment webhook: invalid JSON body for gateway [{$gatewayCode}]: {$e->getMessage()}");
Modules/Payment/app/Http/Middleware/VerifyWebhookSignature.php:66:            Log::error("Payment webhook: gateway driver error for [{$gatewayCode}]: {$e->getMessage()}");
```

#### WHK-03 · M · CTL-10 — Dead `catch (ModelNotFoundException)` cannot ever fire

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code*; also ERR-02 (H) — *a catch must never turn a 404 into a redirect*, but here the catch is unreachable, and it is the A1 re-throw shape that D2 does not list |
| **Where** | `Modules/Payment/app/Http/Controllers/WebhookController.php:74-77` |
| **Root cause** | `ModelNotFoundException` is thrown only by Eloquent `findOrFail`/`firstOrFail` and route-model binding. Nothing inside the `try` (lines 35-53) calls any of those: `PaymentWebhook::create()` and `ProcessWebhookJob::dispatch()` throw `QueryException` or other `Throwable`, never `ModelNotFoundException`. The `throw $e` at line 77 is therefore unreachable. |
| **Consequence** | The code implies a 404 path exists when it does not; a reader must reason about a branch that can never run. |
| **Reproduce** | Static only — the file has no `findOrFail`/`firstOrFail` call. |
| **Fix approach** | Delete the `catch (ModelNotFoundException)` block. WHK-01 removes it too if that DECISION is ticked; apply WHK-03 when WHK-01 is left unticked. |
| **Plan item** | WHK-03 in `02-fix-plan.md` §3 |

```php
// WebhookController.php:74-77 — CURRENT
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
```

**Evidence**

```
$ grep -n "findOrFail\|firstOrFail\|ModelNotFoundException" Modules/Payment/app/Http/Controllers/WebhookController.php
7:use Illuminate\Database\Eloquent\ModelNotFoundException;
74:        } catch (ModelNotFoundException $e) {
```

### F2 — Transactions and audit

#### WHK-04 · M · TXN-04 — `activityLog()` runs after the transaction, not inside it

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes; not before it, not after commit* |
| **Where** | `Modules/Payment/app/Http/Controllers/WebhookController.php:55-71` |
| **Root cause** | The transaction closure returns `$webhook` at line 52; the activity log is written at line 60, after the transaction has committed. The comment explains the placement as a workaround for the log throwing, but that is a symptom of WHK-07 (the log can never succeed as written), not a reason to move an audit write outside the write it describes. |
| **Consequence** | The webhook row and its audit entry are not atomic: a crash between the two leaves a stored webhook with no audit trail, and a failed log can never roll the webhook back even when it matters. |
| **Reproduce** | Static only — the `activityLog()` call is outside the closure that spans lines 35-53. |
| **Fix approach** | Once WHK-07 gives the log a real causer, move the `activityLog()` call to the end of the transaction closure, after `PaymentWebhook::create()` and the dispatch. |
| **Plan item** | WHK-04 in `02-fix-plan.md` §2 (sequenced after WHK-07) |

```php
// WebhookController.php:55-71 — CURRENT
            // Deliberately outside the transaction and non-fatal. sys_activity_logs.user_id is
            // NOT NULL and a gateway request has no user, so this insert used to throw, roll the
            // webhook back and answer 500 — every genuine Razorpay webhook was rejected. The
            // stored PaymentWebhook row is the durable record of the event; this is a courtesy.
            try {
                activityLog($webhook, 'Received', [
                    'message'         => 'Payment webhook was received and queued.',
                    'gateway'         => $gateway,
                    'event_type'      => $webhook->event_type,
                    'idempotency_key' => $webhook->idempotency_key,
                ]);
            } catch (\Throwable $e) {
                Log::warning('Payment webhook stored and queued, but its activity log could not be written', [
                    'webhook_id' => $webhook->id,
                    'error'      => $e->getMessage(),
                ]);
            }
```

**Evidence**

```
$ grep -n "activityLog\|DB::transaction" Modules/Payment/app/Http/Controllers/WebhookController.php
35:            $webhook = DB::transaction(function () use ($request, $gateway) {
60:                activityLog($webhook, 'Received', [
```

#### WHK-05 · H · TXN-06 — Idempotency key is wrong in both directions

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index; the unique index must identify ONE operation* |
| **Where** | `Modules/Payment/app/Http/Controllers/WebhookController.php:97-110`, method `extractIdempotencyKey()` |
| **Root cause** | The key is (a) too coarse: for Razorpay it is `payload.payment.entity.id`, the payment id, so two different events for the same payment (`payment.captured` and `order.paid`) produce the same key and collide on `ptm_payment_webhooks_idempotency_key_unique`; and (b) non-idempotent when extraction fails: `?? uniqid('', true)` (line 109) mints a fresh random key on every delivery, so a replayed event the match cannot parse is stored and queued again. The unique index exists, but (a) makes distinct events collide and (b) makes a duplicate not collide. |
| **Consequence** | Two different events for one payment collide on the unique index and the second is dropped with an HTTP 500 (see WHK-06); an event whose key cannot be extracted is processed twice — a double credit or double refund if the gateway driver is not itself idempotent. |
| **Reproduce** | Static only — Razorpay sends `payment.captured` and `order.paid` for the same payment entity id; both map to the same key at lines 100-102. Live reproduction needs real gateway POSTs (D4). |
| **Fix approach** | Build the key from the event identity (`X-Razorpay-Event-Id`, falling back to the raw-body hash) combined with `gateway:event_type:...`, and never fall back to `uniqid()`. |
| **Plan item** | WHK-05 in `02-fix-plan.md` §1 |

```php
// WebhookController.php:97-110 — CURRENT
    private function extractIdempotencyKey(string $gateway, array $payload, Request $request): string
    {
        $key = match (strtolower($gateway)) {
            'razorpay' => $payload['payload']['payment']['entity']['id']
                ?? $request->header('X-Razorpay-Event-Id')
                ?? null,
            'phonepe'  => $payload['data']['merchantTransactionId'] ?? null,
            'paytm'    => $payload['ORDERID'] ?? null,
            'billdesk' => $this->extractBillDeskOrderId($payload) ?? null,
            default    => null,
        };

        return $key ?? (strtolower($gateway) . '_' . uniqid('', true));
    }
```

**Evidence**

```
$ grep -n "uniqid\|idempotency_key" Modules/Payment/app/Http/Controllers/WebhookController.php
41:                    'idempotency_key' => $this->extractIdempotencyKey($gateway, $payload, $request),
109:        return $key ?? (strtolower($gateway) . '_' . uniqid('', true));

$ php artisan tinker --execute 'SHOW INDEX FROM ptm_payment_webhooks'
idx name=ptm_payment_webhooks_idempotency_key_unique col=idempotency_key unique=1
```

#### WHK-06 · H · ERR-06 — A replayed/duplicate webhook is answered with HTTP 500 instead of an idempotent 200

| Field | Value |
|---|---|
| **Rule** | ERR-06 (H) — *no swallowed or misreported failure on a write path*; F13-5 (race) and the at-least-once contract in the method docblock |
| **Where** | `Modules/Payment/app/Http/Controllers/WebhookController.php:78-91` |
| **Root cause** | When `PaymentWebhook::create()` hits the unique index — a genuine replay, or the collision in WHK-05 — MySQL throws `QueryException`/`UniqueConstraintViolationException`. The generic `catch (\Throwable $e)` at line 78 turns it into HTTP 500. A duplicate delivery is a success case for an at-least-once webhook: the row already exists, so the endpoint should answer 200 and do nothing. |
| **Consequence** | The gateway sees 500 and retries on its back-off schedule; every retry repeats the 500, so the delivery is never acknowledged and the gateway eventually gives up or disables the endpoint. |
| **Reproduce** | Static only — POST the same payload twice (the second hits the unique index) would show 500 instead of 200; running it needs a gateway harness (D4). |
| **Fix approach** | Detect a duplicate idempotency key and return the same `{"status":"queued"}` 200 without dispatching a second job. A controller catch is not a D2 shape, so the compliant route is a small intake method (new `Modules/Payment/Services/WebhookIntakeService.php`, owned by this report) that catches the unique violation and reports it. This is a DECISION. |
| **Plan item** | WHK-06 in `02-fix-plan.md` §1 (DECISION) |

```php
// WebhookController.php:78-91 — CURRENT
        } catch (\Throwable $e) {
            Log::error('WebhookController::handle failed', [
                'gateway' => $gateway,
                'error'   => $e->getMessage(),
            ]);

            // The caller is a payment gateway, not a browser. A redirect reads as a 3xx and
            // the gateway treats the delivery as accepted — the webhook would be dropped and
            // never retried. Answer with a 500 so its back-off actually fires.
            return response()->json([
                'status'  => 'error',
                'message' => 'The webhook could not be accepted.',
            ], 500);
        }
```

**Evidence**

```
$ grep -n "catch (" Modules/Payment/app/Http/Controllers/WebhookController.php
66:            } catch (\Throwable $e) {
74:        } catch (ModelNotFoundException $e) {
78:        } catch (\Throwable $e) {
```

#### WHK-07 · M · DECISION · TXN-01 — The 'Received' activity log can never be written (no causer)

| Field | Value |
|---|---|
| **Rule** | TXN-01 (M) — *a multi-table mutation runs in one transaction*; ERR-06 (M) — *no silent failure on a write path*; F13-8 (dead feature) |
| **Where** | `Modules/Payment/app/Http/Controllers/WebhookController.php:59-71`; helper at `app/Helpers/activityLog.php:25-49`; schema at `database/migrations/tenant/2026_06_16_071024_create_activity_logs_table.php:18-19` |
| **Root cause** | `activityLog()` writes `user_id = Auth::id()`. On the webhook route there is no authenticated user, and `PaymentWebhook` is not `Authenticatable`, so the causer id stays null. `sys_activity_logs.user_id` is `unsignedInteger` (NOT NULL) with a FK to `sys_users`, so the INSERT always fails; the nested catch at line 66 swallows it. The audit entry is therefore never written for any webhook, on any gateway. |
| **Consequence** | No webhook ever appears in the activity log. The feature the code claims ("activityLog 'Received'") does not exist, and the swallow hides that from every operator. |
| **Reproduce** | Static only — `Auth::id()` is null on an unauthenticated route; `grep -n "extends" PaymentWebhook.php` shows `BaseModel`, not `Authenticatable`. |
| **Fix approach** | DECISION — choose how a gateway causer is recorded (see plan §2). |
| **Plan item** | WHK-07 in `02-fix-plan.md` §2 (DECISION) |

```php
// WebhookController.php:59-71 — CURRENT
            try {
                activityLog($webhook, 'Received', [
                    'message'         => 'Payment webhook was received and queued.',
                    'gateway'         => $gateway,
                    'event_type'      => $webhook->event_type,
                    'idempotency_key' => $webhook->idempotency_key,
                ]);
            } catch (\Throwable $e) {
                Log::warning('Payment webhook stored and queued, but its activity log could not be written', [
                    'webhook_id' => $webhook->id,
                    'error'      => $e->getMessage(),
                ]);
            }
```

**Evidence**

```
$ sed -n '16,20p' database/migrations/tenant/2026_06_16_071024_create_activity_logs_table.php
            $table->index(['subject_type', 'subject_id']);
            $table->unsignedInteger('user_id');
            $table->foreign('user_id')->references('id')->on('sys_users')->restrictOnDelete();

$ grep -n "Auth::id\|function activityLog" app/Helpers/activityLog.php
19:    function activityLog($subject, string $event, array $properties = [])
30:        $causerId = Auth::id();
```

### F3 — Authorization

Clean — this is a machine endpoint and authorization is the HMAC signature, not a permission. Proving command:

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json (extract)
payment/webhooks/{gateway} → middleware includes Modules\Payment\Http\Middleware\VerifyWebhookSignature
$ sed -n '30,75p' Modules/Payment/app/Http/Middleware/VerifyWebhookSignature.php
handle() returns 401 when verifyWebhookSignature() is false and only calls $next($request) after the payload attribute is set.
```

No AUTH-01 finding: the route carries no `auth` middleware by design, and the signature middleware is the compensating control.

### F4 — Validation and input

#### WHK-08 · L · VAL-01 — The raw payload is persisted without schema validation (accepted risk)

| Field | Value |
|---|---|
| **Rule** | VAL-01 (L here) — *never write unvalidated input to a model*; severity lowered because the body is HMAC-verified and `payload` is an opaque JSON blob, not a model column set |
| **Where** | `Modules/Payment/app/Http/Controllers/WebhookController.php:36-46` |
| **Root cause** | The decoded payload (or `$request->all()` as a fallback) is persisted verbatim into the `payload` json column. There is no FormRequest because the shape is gateway-specific and the authenticity guarantee is the signature, not field validation. |
| **Consequence** | None while the signature check runs; a malformed-but-signed body is stored and later fails at driver level in the job, where the failure is recorded on the webhook row. |
| **Reproduce** | Static only — a signature-verified body is the accepted contract. |
| **Fix approach** | No change recommended — a signature-verified opaque payload is the correct model. Recorded as accepted. |
| **Plan item** | none — see plan §10 |

```php
// WebhookController.php:36-46 — CURRENT
                $payload = $request->attributes->get('webhook_payload', $request->all());

                $webhook = PaymentWebhook::create([
                    'gateway'         => $gateway,
                    'event_type'      => $this->extractEventType($gateway, $payload),
                    'idempotency_key' => $this->extractIdempotencyKey($gateway, $payload, $request),
                    'payload'         => $payload,
                    'signature_valid' => true,
                    'processed'       => false,
                    'is_active'       => true,
                ]);
```

**Evidence**

```
$ grep -n "request->all()" Modules/Payment/app/Http/Controllers/WebhookController.php
36:                $payload = $request->attributes->get('webhook_payload', $request->all());
```

### F5 — Routes

Clean. The route is POST (no state change over GET, RTE-01), the parameter `{gateway}` matches the method argument `string $gateway` (RTE-03), the method exists (RTE-02), and tenancy middleware is present (RTE-05). Proving command:

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --path=payment/webhooks
  POST       payment/webhooks/{gateway} payment.webhook.handle › Modules\Paym…
```

### F6 — Controller shape

#### WHK-09 · M · DECISION · CTL-06 — Per-gateway payload parsing lives in the controller, duplicating driver knowledge

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in services/actions*; SVC-04 (M) — *one implementation per business operation* |
| **Where** | `Modules/Payment/app/Http/Controllers/WebhookController.php:94-146` |
| **Root cause** | `extractIdempotencyKey`, `extractEventType`, `extractBillDeskOrderId` and `extractBillDeskStatus` encode each gateway's payload layout with `match` arms in the controller. The same gateway-specific knowledge already lives in the driver (`Modules/Payment/app/Gateways/*`, reached by `GatewayManager::resolve()`), so it exists in two places. |
| **Consequence** | A gateway payload-format change must be made in the driver and the controller; if only the driver is updated, the controller keeps mis-keying or mislabelling events. |
| **Reproduce** | Static only — `grep -n "private function"` lists the four parsers; the same codes appear in `GatewayManager::resolve()`. |
| **Fix approach** | DECISION — see plan §9. |
| **Plan item** | WHK-09 in `02-fix-plan.md` §9 (DECISION) |

```php
// WebhookController.php:97-124 — CURRENT
    private function extractIdempotencyKey(string $gateway, array $payload, Request $request): string
    {
        $key = match (strtolower($gateway)) {
            'razorpay' => $payload['payload']['payment']['entity']['id']
                ?? $request->header('X-Razorpay-Event-Id')
                ?? null,
            'phonepe'  => $payload['data']['merchantTransactionId'] ?? null,
            'paytm'    => $payload['ORDERID'] ?? null,
            'billdesk' => $this->extractBillDeskOrderId($payload) ?? null,
            default    => null,
        };

        return $key ?? (strtolower($gateway) . '_' . uniqid('', true));
    }

    /**
     * Extract the gateway event type from the payload.
     */
    private function extractEventType(string $gateway, array $payload): string
    {
        return match (strtolower($gateway)) {
            'razorpay' => $payload['event'] ?? 'unknown',
            'phonepe'  => $payload['code'] ?? 'unknown',
            'paytm'    => $payload['STATUS'] ?? 'unknown',
            'billdesk' => $this->extractBillDeskStatus($payload),
            default    => 'unknown',
        };
    }
```

**Evidence**

```
$ grep -n "private function" Modules/Payment/app/Http/Controllers/WebhookController.php
97:    private function extractIdempotencyKey(string $gateway, array $payload, Request $request): string
115:    private function extractEventType(string $gateway, array $payload): string
129:    private function extractBillDeskOrderId(array $payload): ?string
140:    private function extractBillDeskStatus(array $payload): string
```

### F7 — Models

Clean. `PaymentWebhook` declares `$fillable` (no sensitive columns), casts `payload` (array) and the three booleans, uses `SoftDeletes` with a matching `deleted_at`, sets `$table = 'ptm_payment_webhooks'` which exists in the migration, and its single relationship is return-typed. Proving commands:

```
$ grep -n "protected \$table\|protected \$fillable\|protected \$casts\|SoftDeletes\|deleted_at" Modules/Payment/app/Models/PaymentWebhook.php + migration
protected $table = 'ptm_payment_webhooks';
$table->softDeletes();  (migration 2026_06_18_100106, line 28)
$ php -l Modules/Payment/app/Models/PaymentWebhook.php → No syntax errors detected
```

### F8 — Services and jobs

#### WHK-10 · M · JOB-02 — `ProcessWebhookJob` declares `$tries`/`$backoff` but no `$timeout`

| Field | Value |
|---|---|
| **Rule** | JOB-02 (M) — *queued jobs declare `$tries`, `$timeout` (and `$backoff` for external calls)* |
| **Where** | `Modules/Payment/app/Jobs/ProcessWebhookJob.php:26-35` |
| **Root cause** | The job sets `public int $tries = 3;` and `public int $backoff = 30;` (lines 30-31) but no `$timeout`. A framework default timeout applies, so the job's own contract omits the bound. |
| **Consequence** | A slow or hung gateway `handleWebhook()` call ties up a worker for the framework default and the retry budget is implicit rather than reviewed. |
| **Reproduce** | Static only — `grep -n "timeout"` returns no property. |
| **Fix approach** | Add `public int $timeout = 60;` beside `$tries`/`$backoff`. |
| **Plan item** | WHK-10 in `02-fix-plan.md` §6 |

```php
// ProcessWebhookJob.php:26-35 — CURRENT
class ProcessWebhookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $backoff = 30; // seconds between retries

    public function __construct(
        public readonly PaymentWebhook $webhook,
    ) {}
```

**Evidence**

```
$ grep -n "tries\|backoff\|timeout" Modules/Payment/app/Jobs/ProcessWebhookJob.php
30:    public int $tries = 3;
31:    public int $backoff = 30; // seconds between retries
```

#### WHK-11 · M · CTL-10 — `ProcessWebhookJob` injects two services it never uses

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code*; SVC-02 (M) — *dependencies arrive by injection and are used* |
| **Where** | `Modules/Payment/app/Jobs/ProcessWebhookJob.php:37-41` |
| **Root cause** | `handle()` injects `PaymentService $paymentService` and `RefundService $refundService` (lines 39-40) but the body only uses `$gatewayManager`. `grep paymentService` returns only the parameter line. |
| **Consequence** | Two singletons are resolved for every webhook job for nothing, and a reader assumes the job calls them and may route behaviour through them. |
| **Reproduce** | Static only. |
| **Fix approach** | Remove the two unused parameters and their `use` imports. |
| **Plan item** | WHK-11 in `02-fix-plan.md` §6 |

```php
// ProcessWebhookJob.php:37-41 — CURRENT
    public function handle(
        GatewayManager $gatewayManager,
        PaymentService $paymentService,
        RefundService $refundService,
    ): void {
```

**Evidence**

```
$ grep -n "paymentService\|refundService" Modules/Payment/app/Jobs/ProcessWebhookJob.php
39:        PaymentService $paymentService,
40:        RefundService $refundService,
```

Job tenant-context check (JOB-01): clean. `QueueTenancyBootstrapper` is enabled (`config/tenancy.php:43`), and the dispatch happens inside `InitializeTenancyByDomain`, so the job is processed in the same tenant. Job payload check (JOB-05): clean — `SerializesModels` serializes the model's identifier, not the loaded row. Listener check (JOB-04): the listener writes one audit row synchronously; that is not "slow work" and needs no queue.

### F9 — Queries and performance

Clean — no queries inside a loop, no list endpoint, single `create()` and single `update()` per request. Proving command:

```
$ grep -n "foreach\|->get()\|->all()\|paginate" Modules/Payment/app/Http/Controllers/WebhookController.php Modules/Payment/app/Jobs/ProcessWebhookJob.php
(no query-in-loop or unbounded read; the only foreach is the header normalisation at VerifyWebhookSignature.php:50, over request headers)
```

### F10 — Views

Clean — this controller and its job/listener render no Blade view. Proving command:

```
$ grep -n "view(" Modules/Payment/app/Http/Controllers/WebhookController.php Modules/Payment/app/Jobs/ProcessWebhookJob.php
(no output)
```

### F11 — Security and tenancy

#### WHK-12 · M · SEC-05 — `signature_valid` is hardcoded true and the payload falls back to `$request->all()`

| Field | Value |
|---|---|
| **Rule** | SEC-05 (M here) — *trusted data is only processed through authorised routes*; F13-6 (authorization hole). Severity M because it is latent: the middleware is attached today |
| **Where** | `Modules/Payment/app/Http/Controllers/WebhookController.php:36-43` |
| **Root cause** | The controller records `'signature_valid' => true` unconditionally (line 43) and reads `$request->attributes->get('webhook_payload', $request->all())` (line 36). Nothing asserts that `VerifyWebhookSignature` actually ran and set `webhook_payload`. If the alias were removed, renamed or reordered in `PaymentServiceProvider`/`RouteServiceProvider`, the endpoint would still store `signature_valid = true` and process whatever body arrived. |
| **Consequence** | A defense-in-depth gap on the payment endpoint: a future one-line route/provider edit silently turns an unauthenticated POST into a trusted webhook, with no signal that verification stopped. |
| **Reproduce** | Static only — the fallback and the constant are visible at lines 36 and 43. |
| **Fix approach** | Assert the attribute (`abort_unless($request->attributes->has('webhook_payload'), 401)`) or read only the attribute and drop the `$request->all()` fallback, and set `signature_valid` from the middleware's result rather than a literal. |
| **Plan item** | WHK-12 in `02-fix-plan.md` §7 |

```php
// WebhookController.php:36-43 — CURRENT
                $payload = $request->attributes->get('webhook_payload', $request->all());

                $webhook = PaymentWebhook::create([
                    'gateway'         => $gateway,
                    'event_type'      => $this->extractEventType($gateway, $payload),
                    'idempotency_key' => $this->extractIdempotencyKey($gateway, $payload, $request),
                    'payload'         => $payload,
                    'signature_valid' => true,
```

**Evidence**

```
$ grep -n "signature_valid\|request->all()" Modules/Payment/app/Http/Controllers/WebhookController.php
36:                $payload = $request->attributes->get('webhook_payload', $request->all());
43:                    'signature_valid' => true,
```

Other Security/Tenancy checks: clean. `grep -n "env("` over all in-scope files returns nothing (SEC-01 clean). No request body or payment data is logged (SEC-04 clean). No hard-coded ids (SEC-03 clean). No central model is reached from tenant context, so `tenancy()->central()` is not required (TEN-03 clean).

### F12 — Style

#### WHK-13 · L · STY-02 — Pint/style issues (one item per file)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean: sorted imports, no stray blank lines between imports*; STY-04 (L) — *comments accurate and free of misleading notes* |
| **Where** | `Modules/Payment/app/Http/Controllers/WebhookController.php:7-17` (also `Modules/Payment/app/Events/WebhookReceived.php:1-6`) |
| **Root cause** | (1) In `WebhookController` the `use` statements are separated by blank lines and are not alphabetically ordered (lines 7-17), so Pint rewrites them. (2) In `WebhookReceived.php` there is no blank line after `<?php`/`declare` and none before `namespace`/imports, which Pint also rewrites. (3) The comment at `WebhookController.php:48` says the queue table is on the central connection; with `QUEUE_CONNECTION=database` and `DB_QUEUE_CONNECTION` unset (`config/queue.php:39`), the database queue uses the default connection, which tenancy switches to the tenant DB — the comment states the opposite of the truth. |
| **Consequence** | Low — noise on the next Pint run, and a comment that misleads anyone reasoning about the transaction boundary. |
| **Reproduce** | Static only. |
| **Fix approach** | Run `vendor/bin/pint <file> --format agent` on both files and correct the queue-connection comment. |
| **Plan item** | WHK-13 in `02-fix-plan.md` §8 |

```php
// WebhookController.php:7-17 — CURRENT
use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Payment\Jobs\ProcessWebhookJob;
use Modules\Payment\Models\PaymentWebhook;
```

**Evidence**

```
$ grep -n "^use " Modules/Payment/app/Http/Controllers/WebhookController.php
7:use Illuminate\Database\Eloquent\ModelNotFoundException;
9:use Illuminate\Support\Facades\Log;
11:use Illuminate\Support\Facades\DB;
13:use Illuminate\Http\JsonResponse;
14:use Illuminate\Http\Request;
15:use Illuminate\Routing\Controller;
16:use Modules\Payment\Jobs\ProcessWebhookJob;
17:use Modules\Payment\Models\PaymentWebhook;
```

Style note: `activityLog()` is called without the `use function activityLog;` import that sibling controllers use; PHP's global fallback makes it work, so it is not a defect, but Pint does not fix it either.

### F13 — Deep read (one row per mutating method, eight questions)

| Method | Q1 wrong data | Q2 delete-before-store | Q3 duplicate impl | Q4 soft-delete x unique | Q5 race | Q6 auth hole | Q7 message lies | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `WebhookController::handle` | WHK-05 | ok | WHK-09 | WHK-05 (a soft-deleted row still owns its unique key, so a later replay 500s forever) | WHK-05 | WHK-12 | WHK-13 (line 48 comment) | WHK-07 |
| `ProcessWebhookJob::handle` | ok | ok | ok | ok | ok | ok | ok | WHK-11 |
| `WebhookReceivedListener::handle` | ok | ok | ok | ok | ok | ok | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `app/Helpers/activityLog.php` | Requires a non-null causer (`Auth::id()`) for every subject, so any unauthenticated path that logs fails. Exposed here as WHK-07; the helper itself is common and is not edited by this workflow. | TXN-01 | the team, as a shared helper change |
| `ProcessWebhookJob` stored data | `error_message` keeps the raw exception text (lines 55, 71). That is a DB column, not a log, and is not returned to a user — recorded for awareness, no finding. | SEC-04 | accepted |
| `Modules/Payment/app/Services/PaymentService.php`, `AuditService.php`, `GatewayManager.php`, `Modules/Payment/app/Models/Payment.php`, `PaymentAuditLog.php`, `Gateways/RazorpayGateway.php`, `Gateways/BaseGateway.php` | Audited once by [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md). This report checked only how the webhook path uses them: `GatewayManager::resolve()` is called in the middleware and the job with the route's gateway code (case-insensitive lookup at `ptm_payment_gateways.code`, proven live, so a case mismatch is not a defect); `AuditService::logWebhook()` is called by the listener and its `ptm_payment_audit_logs.actor_id` is nullable (proven live), so it succeeds when `$webhook->payment` exists. | — | linked owner report |

## 8. Not covered, and why

- **No testing of any kind (D4).** The queue job was not dispatched and no gateway POST was sent. The double-processing consequence in WHK-05/WHK-06 and the HTTP-500 status are argued from the code, the live unique index and the gateway retry contract, not measured at runtime.
- **The gateway drivers** (`RazorpayGateway`, `BaseGateway`, the other gateways) were not audited here — they are owned by `tarun/ParentPortal-done/ParentFeePaymentController`. Their internal idempotency decides whether the double delivery in WHK-05 becomes a double credit; that question belongs to that report.
- **The gateway-side configuration** (the exact URL each gateway is told to POST to, and whether it re-sends an identical body on retry) is outside the repo and was not verified.
- **The `Backend\WebhookController` index screen** that lists stored webhooks is a different controller and is audited under its own row.
