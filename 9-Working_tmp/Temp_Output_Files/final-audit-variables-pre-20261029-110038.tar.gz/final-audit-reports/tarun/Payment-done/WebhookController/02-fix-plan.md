# Fix Plan — Payment / WebhookController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Payment/app/Http/Controllers/WebhookController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Payment/app/Providers/PaymentServiceProvider.php` | shared: registers the `payment.webhook.verify` alias and the service bindings |
| `Modules/Payment/app/Providers/RouteServiceProvider.php`, `Modules/Payment/routes/webhooks.php` | shared route registration; the audited middleware stack is correct and no route changes here |
| `Modules/Payment/app/Providers/EventServiceProvider.php` | shared listener wiring |
| `bootstrap/app.php` | shared: holds the CSRF exception for `payment/webhooks/*` and the central error renderer |
| `app/Helpers/activityLog.php` | common helper — a change here is WHK-07(c), which is Tarun's decision and a shared file |
| `database/migrations/tenant/**` | existing migrations are never edited; WHK-07(b) is a NEW additive migration and is never run by the fixer |
| `Modules/Payment/app/Services/PaymentService.php`, `AuditService.php`, `GatewayManager.php`, `Modules/Payment/app/Models/Payment.php`, `PaymentAuditLog.php`, `Modules/Payment/app/Gateways/**` | owned by `tarun/ParentPortal-done/ParentFeePaymentController`; link, do not edit |

## 1. Blockers reachable today

- [ ] **WHK-05** · H · TXN-06 · `Modules/Payment/app/Http/Controllers/WebhookController.php:97-110` — the idempotency key must identify ONE delivery of ONE event (stop using the payment id, stop falling back to `uniqid()`).
  - **Touches:** `Modules/Payment/app/Http/Controllers/WebhookController.php`
  - **Before** (`WebhookController.php:97-110`):
    ```php
    private function extractIdempotencyKey(string $gateway, array $payload, Request $request): string
    {
        $key = match (strtolower($gateway)) {
            'razorpay' => $payload['payload']['payment']['entity']['id']
                ?? $request->header('X-Razorpay-Event-Id')
                ?? null,
            'phonepe'  => $payload['data']['merchantTransactionId'] ?? null,
            'paytm'    => $payload['ORDERID'] ?? null,
            'billdesk' => $this->extractBillDeskOrderId($payload) ?? null,
            default    => null,
        };

        return $key ?? (strtolower($gateway) . '_' . uniqid('', true));
    }
    ```
  - **After:**
    ```php
    private function extractIdempotencyKey(string $gateway, array $payload, Request $request): string
    {
        $gateway = strtolower($gateway);

        $eventId = match ($gateway) {
            'razorpay' => $request->header('X-Razorpay-Event-Id')
                ?? $payload['payload']['payment']['entity']['id']
                ?? null,
            'phonepe'  => $payload['data']['merchantTransactionId'] ?? null,
            'paytm'    => $payload['ORDERID'] ?? null,
            'billdesk' => $this->extractBillDeskOrderId($payload),
            default    => null,
        };

        // A stable key must identify ONE delivery of ONE event. The event type is part of the
        // key so that two events for the same payment (payment.captured, order.paid) do not
        // collide on the unique index. The raw body hash is the last resort: an identical
        // replay hashes identically, so it stays idempotent.
        $identity = $eventId ?? hash('sha256', $request->getContent());

        return $gateway . ':' . $this->extractEventType($gateway, $payload) . ':' . $identity;
    }
    ```
  - **Verify:** `grep -n "uniqid" Modules/Payment/app/Http/Controllers/WebhookController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **WHK-06** · H · DECISION · ERR-06 — a replayed/duplicate webhook must be acknowledged with HTTP 200, not 500.
  - **Why it is a decision:** the fix needs a catch on the unique violation, which is not one of the D2 shapes; Tarun decides where it lives.
  - (a) ⭐ Add a new `Modules/Payment/Services/WebhookIntakeService.php` (owned by this report) whose `store()` runs `PaymentWebhook::create()` inside the transaction, catches `Illuminate\Database\UniqueConstraintViolationException`, returns the existing row, and reports the exception; the controller calls it and always returns `{"status":"queued"}` 200 without a second job.
  - (b) Keep the catch in the controller (`catch (UniqueConstraintViolationException)`) with a comment naming ERR-01 and the date — this extends D2.
  - (c) Pre-check `PaymentWebhook::where('idempotency_key', $key)->exists()` before inserting and return 200 when found, accepting that a true race still 500s.
  - ➜ Choice: ____

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **WHK-07** · M · DECISION · TXN-01 — the 'Received' activity log can never be written; choose how a gateway causer is recorded.
  - **Why it is a decision:** `sys_activity_logs.user_id` is NOT NULL and a webhook has no user; each option touches a shared helper, a shared table, or drops the feature.
  - (a) ⭐ Delete the activity-log block (lines 59-71); the stored `ptm_payment_webhooks` row is the durable record, as the code's own comment says. Touches `WebhookController.php` only. WHK-04 then has nothing to move and is recorded as superseded.
  - (b) ⚠ SHARED — write a NEW additive tenant migration making `sys_activity_logs.user_id` nullable, then move the log inside the transaction (WHK-04). Needs Tarun to run `php artisan tenants:migrate`.
  - (c) ⚠ SHARED — change `app/Helpers/activityLog.php` to accept an optional causer and pass a configured system-user id; needs a seeded `sys_users` row.
  - ➜ Choice: ____

- [ ] **WHK-04** · M · TXN-04 · `Modules/Payment/app/Http/Controllers/WebhookController.php:35-71` — move the activity log inside the transaction, after the write it describes. Apply only if WHK-07 choice is (b) or (c); if (a), this is superseded.
  - **Touches:** `Modules/Payment/app/Http/Controllers/WebhookController.php`
  - **Before** (`WebhookController.php:35-71`):
    ```php
    $webhook = DB::transaction(function () use ($request, $gateway) {
        $payload = $request->attributes->get('webhook_payload', $request->all());

        $webhook = PaymentWebhook::create([
            'gateway'         => $gateway,
            'event_type'      => $this->extractEventType($gateway, $payload),
            'idempotency_key' => $this->extractIdempotencyKey($gateway, $payload, $request),
            'payload'         => $payload,
            'signature_valid' => true,
            'processed'       => false,
            'is_active'       => true,
        ]);

        // The queue table is on the central connection, outside this transaction.
        // afterCommit() keeps a rolled-back webhook from leaving an orphan job behind.
        ProcessWebhookJob::dispatch($webhook)->afterCommit();

        return $webhook;
    });

    // Deliberately outside the transaction and non-fatal. sys_activity_logs.user_id is
    // NOT NULL and a gateway request has no user, so this insert used to throw, roll the
    // webhook back and answer 500 — every genuine Razorpay webhook was rejected. The
    // stored PaymentWebhook row is the durable record of the event; this is a courtesy.
    try {
        activityLog($webhook, 'Received', [
            'message'         => 'Payment webhook was received and queued.',
            'gateway'         => $gateway,
            'event_type'      => $webhook->event_type,
            'idempotency_key' => $webhook->idempotency_key,
        ]);
    } catch (\Throwable $e) {
        Log::warning('Payment webhook stored and queued, but its activity log could not be written', [
            'webhook_id' => $webhook->id,
            'error'      => $e->getMessage(),
        ]);
    }
    ```
  - **After:**
    ```php
    $webhook = DB::transaction(function () use ($request, $gateway) {
        $payload = $request->attributes->get('webhook_payload', $request->all());

        $webhook = PaymentWebhook::create([
            'gateway'         => $gateway,
            'event_type'      => $this->extractEventType($gateway, $payload),
            'idempotency_key' => $this->extractIdempotencyKey($gateway, $payload, $request),
            'payload'         => $payload,
            'signature_valid' => true,
            'processed'       => false,
            'is_active'       => true,
        ]);

        ProcessWebhookJob::dispatch($webhook)->afterCommit();

        activityLog($webhook, 'Received', [
            'message'         => 'Payment webhook was received and queued.',
            'gateway'         => $gateway,
            'event_type'      => $webhook->event_type,
            'idempotency_key' => $webhook->idempotency_key,
        ]);

        return $webhook;
    });
    ```
  - **Verify:** `grep -n "activityLog\|return $webhook" Modules/Payment/app/Http/Controllers/WebhookController.php`
  - **Expect:** one `activityLog` line whose number is lower than the `return $webhook;` line.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [ ] **WHK-02** · M · ERR-05 · `Modules/Payment/app/Jobs/ProcessWebhookJob.php:74` + `Modules/Payment/app/Http/Middleware/VerifyWebhookSignature.php:62-68` — log the exception object, not its message.
  - **Touches:** `Modules/Payment/app/Jobs/ProcessWebhookJob.php`, `Modules/Payment/app/Http/Middleware/VerifyWebhookSignature.php`
  - **Before** (`ProcessWebhookJob.php:74`):
    ```php
    Log::error("ProcessWebhookJob permanently failed for webhook [{$this->webhook->id}]: {$exception->getMessage()}");
    ```
  - **After:**
    ```php
    Log::error("ProcessWebhookJob permanently failed for webhook [{$this->webhook->id}]", [
        'exception' => $exception,
    ]);
    ```
  - **Before** (`VerifyWebhookSignature.php:62-68`):
    ```php
    } catch (\JsonException $e) {
        Log::warning("Payment webhook: invalid JSON body for gateway [{$gatewayCode}]: {$e->getMessage()}");
        return response()->json(['error' => 'Invalid JSON'], Response::HTTP_BAD_REQUEST);
    } catch (\Throwable $e) {
        Log::error("Payment webhook: gateway driver error for [{$gatewayCode}]: {$e->getMessage()}");
        return response()->json(['error' => 'Gateway error'], Response::HTTP_INTERNAL_SERVER_ERROR);
    }
    ```
  - **After:**
    ```php
    } catch (\JsonException $e) {
        Log::warning("Payment webhook: invalid JSON body for gateway [{$gatewayCode}]", [
            'exception' => $e,
        ]);
        return response()->json(['error' => 'Invalid JSON'], Response::HTTP_BAD_REQUEST);
    } catch (\Throwable $e) {
        Log::error("Payment webhook: gateway driver error for [{$gatewayCode}]", [
            'exception' => $e,
        ]);
        return response()->json(['error' => 'Gateway error'], Response::HTTP_INTERNAL_SERVER_ERROR);
    }
    ```
  - **Verify:** `grep -n "getMessage" Modules/Payment/app/Jobs/ProcessWebhookJob.php Modules/Payment/app/Http/Middleware/VerifyWebhookSignature.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **WHK-03** · M · CTL-10 · `Modules/Payment/app/Http/Controllers/WebhookController.php:7,74-78` — remove the dead `ModelNotFoundException` catch and its now-unused import.
  - **Touches:** `Modules/Payment/app/Http/Controllers/WebhookController.php`
  - **Before** (`WebhookController.php:74-78`):
    ```php
    } catch (ModelNotFoundException $e) {
        // Rule A1: a missing record must stay a 404. Without this the generic
        // catch below swallows it and the user gets a redirect instead.
        throw $e;
    } catch (\Throwable $e) {
    ```
  - **After:**
    ```php
    } catch (\Throwable $e) {
    ```
  - **Before** (`WebhookController.php:7-8`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;

    ```
  - **After:**
    ```php
    ```
  - **Verify:** `grep -n "ModelNotFoundException" Modules/Payment/app/Http/Controllers/WebhookController.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries, jobs & performance (F8/F9)

- [ ] **WHK-10** · M · JOB-02 · `Modules/Payment/app/Jobs/ProcessWebhookJob.php:30-31` — declare the job timeout.
  - **Touches:** `Modules/Payment/app/Jobs/ProcessWebhookJob.php`
  - **Before** (`ProcessWebhookJob.php:30-31`):
    ```php
    public int $tries = 3;
    public int $backoff = 30; // seconds between retries
    ```
  - **After:**
    ```php
    public int $tries = 3;
    public int $backoff = 30; // seconds between retries
    public int $timeout = 60;
    ```
  - **Verify:** `grep -n "timeout" Modules/Payment/app/Jobs/ProcessWebhookJob.php`
  - **Expect:** `public int $timeout = 60;`
  - **Effort:** S

- [ ] **WHK-11** · M · CTL-10 · `Modules/Payment/app/Jobs/ProcessWebhookJob.php:37-41` — remove the two injected services the job never uses.
  - **Touches:** `Modules/Payment/app/Jobs/ProcessWebhookJob.php`
  - **Before** (`ProcessWebhookJob.php:37-41`):
    ```php
    public function handle(
        GatewayManager $gatewayManager,
        PaymentService $paymentService,
        RefundService $refundService,
    ): void {
    ```
  - **After:**
    ```php
    public function handle(
        GatewayManager $gatewayManager,
    ): void {
    ```
  - **Before** (`ProcessWebhookJob.php:17-18`):
    ```php
    use Modules\Payment\Services\PaymentService;
    use Modules\Payment\Services\RefundService;
    ```
  - **After:**
    ```php
    ```
  - **Verify:** `grep -n "paymentService\|refundService\|PaymentService\|RefundService" Modules/Payment/app/Jobs/ProcessWebhookJob.php`
  - **Expect:** no output.
  - **Effort:** S

## 7. Security (F11)

- [ ] **WHK-12** · M · SEC-05 · `Modules/Payment/app/Http/Controllers/WebhookController.php:36-46` — assert the signature middleware ran; drop the `$request->all()` fallback.
  - **Touches:** `Modules/Payment/app/Http/Controllers/WebhookController.php`
  - **Before** (`WebhookController.php:36-46`):
    ```php
    $payload = $request->attributes->get('webhook_payload', $request->all());

    $webhook = PaymentWebhook::create([
        'gateway'         => $gateway,
        'event_type'      => $this->extractEventType($gateway, $payload),
        'idempotency_key' => $this->extractIdempotencyKey($gateway, $payload, $request),
        'payload'         => $payload,
        'signature_valid' => true,
        'processed'       => false,
        'is_active'       => true,
    ]);
    ```
  - **After:**
    ```php
    if (! $request->attributes->has('webhook_payload')) {
        abort(401, 'Webhook payload was not verified.');
    }

    $payload = $request->attributes->get('webhook_payload');

    $webhook = PaymentWebhook::create([
        'gateway'         => $gateway,
        'event_type'      => $this->extractEventType($gateway, $payload),
        'idempotency_key' => $this->extractIdempotencyKey($gateway, $payload, $request),
        'payload'         => $payload,
        'signature_valid' => true,
        'processed'       => false,
        'is_active'       => true,
    ]);
    ```
  - **Verify:** `grep -n "request->all()" Modules/Payment/app/Http/Controllers/WebhookController.php`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **WHK-13** · L · STY-02 · `Modules/Payment/app/Http/Controllers/WebhookController.php` + `Modules/Payment/app/Events/WebhookReceived.php` — make both Pint-clean and correct the queue-connection comment.
  - **Touches:** `Modules/Payment/app/Http/Controllers/WebhookController.php`, `Modules/Payment/app/Events/WebhookReceived.php`
  - **Before** (`WebhookController.php:7-17`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;

    use Illuminate\Support\Facades\Log;

    use Illuminate\Support\Facades\DB;

    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Modules\Payment\Jobs\ProcessWebhookJob;
    use Modules\Payment\Models\PaymentWebhook;
    ```
  - **After:**
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    use Illuminate\Routing\Controller;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Log;
    use Modules\Payment\Jobs\ProcessWebhookJob;
    use Modules\Payment\Models\PaymentWebhook;
    ```
  - **Before** (`WebhookController.php:48-50`):
    ```php
    // The queue table is on the central connection, outside this transaction.
    // afterCommit() keeps a rolled-back webhook from leaving an orphan job behind.
    ProcessWebhookJob::dispatch($webhook)->afterCommit();
    ```
  - **After:**
    ```php
    // The database queue runs on this tenant's connection, the same one as the transaction,
    // so afterCommit() keeps a rolled-back webhook from leaving an orphan job behind.
    ProcessWebhookJob::dispatch($webhook)->afterCommit();
    ```
  - **Before** (`WebhookReceived.php:1-6`):
    ```php
    <?php
    declare(strict_types=1);
    namespace Modules\Payment\Events;
    use Illuminate\Foundation\Events\Dispatchable;
    use Illuminate\Queue\SerializesModels;
    use Modules\Payment\Models\PaymentWebhook;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Payment\Events;

    use Illuminate\Foundation\Events\Dispatchable;
    use Illuminate\Queue\SerializesModels;
    use Modules\Payment\Models\PaymentWebhook;
    ```
  - **Verify:** `vendor/bin/pint Modules/Payment/app/Http/Controllers/WebhookController.php Modules/Payment/app/Events/WebhookReceived.php --format agent`
  - **Expect:** `{"tool":"pint","result":"passed"}`
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **WHK-01** · M · DECISION · ERR-00 — remove the controller try/catch (D1)?
  - **Why it is a decision:** the gateway-needs-500 argument is real, and D2 does not cover these catches, so Tarun must pick the target shape.
  - (a) ⭐ Remove the outer `try`/`catch (\Throwable)` and let the central renderer in `bootstrap/app.php` answer 500; keep the transaction and the JSON 200 return. Under this choice the nested log catch is gone (WHK-04 or WHK-07 decides the log).
  - (b) Keep the outer `try`/`catch` only for the JSON-500 gateway contract and add a comment naming ERR-01 and the date (extends D2); the `catch (ModelNotFoundException)` still goes (WHK-03).
  - (c) Leave the catches as they are and record the deviation as accepted.
  - ➜ Choice: ____

- [ ] **WHK-09** · M · DECISION · CTL-06 — move the four per-gateway payload parsers out of the controller?
  - **Why it is a decision:** option (c) changes a driver contract owned by another report; option (b) creates a new class.
  - (a) ⭐ Leave as is and record accepted; the parsers are small and the gateway set is stable.
  - (b) Move the four private parsers into a new `Modules/Payment/Services/WebhookPayloadParser.php` (owned by this report) and inject it.
  - (c) ⚠ SHARED — extend `PaymentGatewayInterface` with `eventType()`/`idempotencyKey()` (touches the driver contract owned by `tarun/ParentPortal-done/ParentFeePaymentController`).
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| WHK-08 | Accepted risk, not a defect: the payload is HMAC-verified before it is stored and the `payload` column is an opaque JSON blob, so there is no schema to validate against. Recorded for completeness. |
