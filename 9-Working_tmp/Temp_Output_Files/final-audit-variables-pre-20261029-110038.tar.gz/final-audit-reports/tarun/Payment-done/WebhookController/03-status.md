# Status — Payment / WebhookController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output |
|---|---|---|---|---|
| WHK-05 | `WebhookController.php` | Idempotency key now identifies gateway + event + event-id/body-hash; no `uniqid()`. | `grep "uniqid"` | none |
| WHK-06 | `Services/WebhookIntakeService.php` (new), `WebhookController.php` | Duplicate deliveries are caught on the unique index, reported, and acknowledged 200 without a second job. | `grep "UniqueConstraintViolationException"` | present |
| WHK-07 | `WebhookController.php` | Removed the unwritable activity-log block; the stored webhook row is the durable record. | `grep "activityLog"` | none |
| WHK-01 | `WebhookController.php` | Outer controller try/catch removed; central renderer handles failures. | `grep "try {|catch ("` | none |
| WHK-02 | `Jobs/ProcessWebhookJob.php`, `Http/Middleware/VerifyWebhookSignature.php` | Logs carry the exception object, not just `getMessage()`. | `grep "getMessage"` | none in logs |
| WHK-03 | `WebhookController.php` | Dead `ModelNotFoundException` catch/import removed. | `grep "ModelNotFoundException"` | none |
| WHK-10 | `Jobs/ProcessWebhookJob.php` | `public int $timeout = 60;`. | `grep "timeout"` | present |
| WHK-11 | `Jobs/ProcessWebhookJob.php` | Unused `PaymentService`/`RefundService` injections removed. | `grep "PaymentService|RefundService"` | none |
| WHK-12 | `WebhookController.php` | Rejects requests without the verified `webhook_payload` attribute; no `$request->all()` fallback. | `grep "request->all()"` | none |
| WHK-13 | controller/event | Pint-clean + import order; queue comment corrected in the new service. | `pint --test` | passed |

## 3. Not applied / deferred
- **WHK-04** — superseded by WHK-07(a).
- **WHK-08** — accepted: payload is HMAC-verified and opaque.
- **WHK-09** — accepted: per-gateway payload parsers stay in the controller.

## 4. Shared changes
- None.

## 5. Verification
- Pint passed; `php -l` clean.

## 6. Final state
FIXED. WHK-04 superseded; WHK-08/09 accepted.
