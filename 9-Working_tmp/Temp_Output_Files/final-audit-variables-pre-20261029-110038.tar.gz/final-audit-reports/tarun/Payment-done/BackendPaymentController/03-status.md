# Status — Payment / Backend\PaymentController

**Fixed:** 2026-10-21 · **By:** opencode · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
None.

## 2. Applied
| ID | File | What changed | Verify | Output |
|---|---|---|---|---|
| BPA-01 | `payments/index.blade.php`, `payments/show.blade.php` | Switched from the missing `prime::layouts.master` to `backend.layouts.master`; folded `content_header` into `content`. | `grep "prime::layouts.master"` | none |
| BPA-02 | both payment blades | Route calls now use the registered `payment.payment.backend.*` names. | `grep "payment.backend."` | none |
| BPA-03 | `Backend/PaymentController.php` | Added `Gate::authorize('viewAny', Payment::class)` before the row query in `show()`. | `grep "viewAny"` | before `firstOrFail` |
| BPA-04 | `Backend/PaymentController.php` | List paginates 10 with `paymentsPage`. | `grep "paginate"` | `paginate(10, ['*'], 'paymentsPage')` |
| BPA-06 | `payments/index.blade.php` | View action moved to `x-backend.table.action`; Receipt remains hand-rolled (component gap). | `grep "x-backend.table.action"` | 1 hit |
| BPA-07 | `Backend/PaymentController.php` | Removed unused `webhooks` eager load. | `grep "webhooks"` (controller) | only docblock |
| BPA-08 | both payment blades | Added standard breadcrumbs. | `grep "breadcrum"` | 2 hits |
| BPA-09 | `Backend/PaymentController.php` | Imports sorted/Pint-clean. | `pint --test` | passed |

## 3. Not applied / deferred
- **BPA-05** — accepted ⭐: keep the manual `where('ulid')->firstOrFail()`; route model binding deferred.

## 4. Shared changes
- None outside the controller's own views.

## 5. Verification
- Pint passed; `php -l` clean; `view:cache` compiled.

## 6. Final state
FIXED. BPA-05 recorded as accepted.
