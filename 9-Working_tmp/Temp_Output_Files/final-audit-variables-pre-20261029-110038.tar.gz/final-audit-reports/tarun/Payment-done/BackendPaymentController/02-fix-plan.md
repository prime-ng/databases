# Fix Plan — Payment / Backend\PaymentController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Payment/app/Models/Payment.php` | owned by `tarun/ParentPortal-done/ParentFeePaymentController` |
| `Modules/Payment/app/Models/PaymentGateway.php` | owned by `tarun/ParentPortal-done/ParentFeePaymentController` |
| `Modules/Payment/app/Policies/PaymentPolicy.php` | owned by `tarun/Payment-done/PaymentController` |
| `Modules/Payment/routes/web.php` | shared route file — a route change is a DECISION (BPA-05 option b) |
| `resources/views/backend/layouts/master.blade.php` | shared layout — read-only for this plan |
| `Modules/Prime/resources/views/**` | shared Prime views — only touched if BPA-01 option (b) is chosen |
| `config/permissionslist.php` | shared config — no permission change is proposed here |
| any migration | standing rule: never edit an existing migration |

## 1. Blockers reachable today

- [ ] **BPA-02** · B · RTE-02 · `Modules/Payment/resources/views/payments/index.blade.php:47-51` and `payments/show.blade.php:8` — point the three `route()` calls at the registered (doubled-prefix) route names so the pages stop 500-ing.
  - **Touches:** `Modules/Payment/resources/views/payments/index.blade.php`, `Modules/Payment/resources/views/payments/show.blade.php`
  - **Before** (`payments/index.blade.php:47-51`):
    ```blade
                                        <td>
                                            <a href="{{ route('payment.backend.payments.show', $payment->ulid) }}" class="btn btn-sm btn-outline-primary">View</a>
                                            @if($payment->status === 'success')
                                                <a href="{{ route('payment.backend.receipts.show', $payment->ulid) }}" class="btn btn-sm btn-outline-success">Receipt</a>
                                            @endif
    ```
  - **After:**
    ```blade
                                        <td>
                                            <a href="{{ route('payment.payment.backend.payments.show', $payment->ulid) }}" class="btn btn-sm btn-outline-primary">View</a>
                                            @if($payment->status === 'success')
                                                <a href="{{ route('payment.payment.backend.receipts.show', $payment->ulid) }}" class="btn btn-sm btn-outline-success">Receipt</a>
                                            @endif
    ```
  - **Before** (`payments/show.blade.php:8`):
    ```blade
            <a href="{{ route('payment.backend.payments.index') }}" class="btn btn-sm btn-outline-secondary">Back</a>
    ```
  - **After:**
    ```blade
            <a href="{{ route('payment.payment.backend.payments.index') }}" class="btn btn-sm btn-outline-secondary">Back</a>
    ```
  - **Verify:** `grep -nE "route\('payment\.backend\." Modules/Payment/resources/views/payments/index.blade.php Modules/Payment/resources/views/payments/show.blade.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BPA-01** · B · DECISION · VIEW-04 — both pages extend `prime::layouts.master`, which does not resolve, so the pages 500 before anything renders. Which layout should they use?
  - **Why it is a decision:** the target layout is a shared file, and the same broken `@extends` sits in four other Payment views owned by other reports. Creating a new layout file or editing a shared one reaches outside this controller's files.
  - (a) ⭐ Point the two audited views at the existing `backend.layouts.master` (`resources/views/backend/layouts/master.blade.php`, already used by 7 views); fold each `content_header` block into `@section('content')`, because that layout yields only `content`. No new file. Fixes only these two pages; the other four Payment views stay broken until their own reports.
  - (b) Create the missing `Modules/Prime/resources/views/layouts/master.blade.php` (an AdminLTE-style layout with `@yield('content')` and `@yield('content_header')`) so all six Payment views and any future `prime::layouts.master` consumer resolve. One new shared file; larger blast radius; needs a follow-up look at every `prime::layouts.master` user.
  - (c) Defer to a module-wide Payment view pass (the four other Payment views share the break) — leave both pages down until then.
  - ➜ Choice: ____

## 2. Fixes that arm a latent defect (sequenced)

None. BPA-01 must be fixed before the view-level items (BPA-02, BPA-08) are visible to a user, but the items are independent edits and any order leaves the code valid.

## 3. Errors & transactions (F1/F2)

None — the controller has no write path, no `try`/`catch` and no `activityLog` event.

## 4. Authorization (F3)

- [ ] **BPA-03** · H · AUTH-02 · `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:42-48` — add a page-level gate before the query so a missing ULID is no longer distinguishable from a forbidden one.
  - **Touches:** `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php`
  - **Before** (`PaymentController.php:42-50`):
    ```php
        public function show(string $ulid): View
        {
            $payment = Payment::with(['gateway', 'refunds', 'auditLogs', 'webhooks', 'offlineRecord'])
                ->where('ulid', $ulid)
                ->firstOrFail();

            Gate::authorize('view', $payment);

            return view('payment::payments.show', compact('payment'));
        }
    ```
  - **After:**
    ```php
        public function show(string $ulid): View
        {
            Gate::authorize('viewAny', Payment::class);

            $payment = Payment::with(['gateway', 'refunds', 'auditLogs', 'webhooks', 'offlineRecord'])
                ->where('ulid', $ulid)
                ->firstOrFail();

            Gate::authorize('view', $payment);

            return view('payment::payments.show', compact('payment'));
        }
    ```
  - **Verify:** `grep -n "viewAny\|firstOrFail" Modules/Payment/app/Http/Controllers/Backend/PaymentController.php`
  - **Expect:** a `Gate::authorize('viewAny', Payment::class);` line, and the `->firstOrFail();` line lower in the file than it.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

None.

## 6. Queries & performance (F9)

- [ ] **BPA-04** · M · QRY-13 · `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:32-34` — paginate the list at the house standard of 10 with a distinct page name.
  - **Touches:** `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php`
  - **Before** (`PaymentController.php:32-34`):
    ```php
            $payments = Payment::with('gateway')
                ->latest()
                ->paginate(20);
    ```
  - **After:**
    ```php
            $payments = Payment::with('gateway')
                ->latest()
                ->paginate(10, ['*'], 'paymentsPage');
    ```
  - **Verify:** `grep -n "paginate" Modules/Payment/app/Http/Controllers/Backend/PaymentController.php`
  - **Expect:** `->paginate(10, ['*'], 'paymentsPage');`
  - **Effort:** S

- [ ] **BPA-07** · L · QRY-03 · `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:44` — stop eager-loading `webhooks`, which no view reads.
  - **Touches:** `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php`
  - **Before** (`PaymentController.php:44`):
    ```php
            $payment = Payment::with(['gateway', 'refunds', 'auditLogs', 'webhooks', 'offlineRecord'])
    ```
  - **After:**
    ```php
            $payment = Payment::with(['gateway', 'refunds', 'auditLogs', 'offlineRecord'])
    ```
  - **Verify:** `grep -n "webhooks" Modules/Payment/app/Http/Controllers/Backend/PaymentController.php`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

- [ ] **BPA-08** · L · UI-STD · `Modules/Payment/resources/views/payments/index.blade.php:9-11` and `payments/show.blade.php:12-13` — add the standard breadcrumb to both pages.
  - **Touches:** `Modules/Payment/resources/views/payments/index.blade.php`, `Modules/Payment/resources/views/payments/show.blade.php`
  - **Before** (`payments/index.blade.php:9-11`):
    ```blade
    @section('content')
        <div class="card">
            <div class="card-body">
    ```
  - **After:**
    ```blade
    @section('content')
        <x-backend.components.breadcrum title="Payments" :links="[]" />

        <div class="card">
            <div class="card-body">
    ```
  - **Before** (`payments/show.blade.php:12-13`):
    ```blade
    @section('content')
        <div class="row">
    ```
  - **After:**
    ```blade
    @section('content')
        <x-backend.components.breadcrum title="Payment Details" :links="[]" />

        <div class="row">
    ```
  - **Verify:** `grep -n "breadcrum" Modules/Payment/resources/views/payments/index.blade.php Modules/Payment/resources/views/payments/show.blade.php`
  - **Expect:** one matching line in each file.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **BPA-09** · L · STY-02 · `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:7-10` — sort the `use` statements so the file is Pint-clean.
  - **Touches:** `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php`
  - **Before** (`PaymentController.php:7-10`):
    ```php
    use Illuminate\Support\Facades\Gate;
    use App\Http\Controllers\Controller;
    use Illuminate\View\View;
    use Modules\Payment\Models\Payment;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\Payment\Models\Payment;
    ```
  - **Verify:** `sed -n '7,10p' Modules/Payment/app/Http/Controllers/Backend/PaymentController.php`
  - **Expect:** the four imports in the order shown in **After** (`App\…` first).
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BPA-05** · M · DECISION · CTL-03 — the detail page finds the row with `where('ulid', $ulid)->firstOrFail()` instead of route model binding. Bind it?
  - **Why it is a decision:** binding the `{ulid}` parameter to the model needs a route-parameter change (`{ulid}` → `{payment:ulid}`) in the shared route file, or a `Payment::getRouteKeyName()` override on a model owned by another report.
  - (a) ⭐ Defer — keep the manual find for now; revisit binding in a dedicated route/model pass (the manual find is not a defect on its own).
  - (b) Change `Modules/Payment/routes/web.php:14` to `{payment:ulid}` and add `getRouteKeyName()` to `Modules/Payment/app/Models/Payment.php` (⚠ SHARED: route file + model owned elsewhere).
  - (c) Leave as is and record as accepted.
  - ➜ Choice: ____

- [ ] **BPA-06** · M · DECISION · UI-STD — the list row actions are hand-rolled anchors instead of `x-backend.table.action`. How should the View and Receipt actions be expressed?
  - **Why it is a decision:** the shared component's built-in actions are view/edit/delete and cannot express the custom "Receipt" button; changing the component is a shared-file change.
  - (a) ⭐ Use `<x-backend.table.action>` for the View action, and record the Receipt action as a component gap for a separate shared-component change.
  - (b) Keep the hand-rolled anchors and record as accepted.
  - (c) Extend `x-backend.table.action` to support a custom receipt action (⚠ SHARED: `app/View/Components/Backend/Table/Action.php`).
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | Every finding in `01-report.md` has a plan item above. |
