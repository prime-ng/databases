# Final Audit — TimetableFoundation / TimetableTypeController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/TimetableTypeController.php` (895 lines, 11 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 4 HIGH, 8 MEDIUM, 7 LOW.**

The write paths are all wrapped in a single `DB::transaction` and `activityLog` sits after the write — that part is sound. The single worst finding is **TTY-16**: the class-assignment resync in `update()` keys existing rows with `whereIn('academic_term_id', [null])`, which matches nothing, so any assignment saved without an academic term is invisible and is re-inserted on every save. The junction table has no unique index, so rows silently multiply.

Two more deep-read hazards ride on the same area: **TTY-17** (`forceDelete()` accepts a live id and checks no children) and **TTY-18** (`destroy()` trashes the default/in-use type and never clears `is_default`). **TTY-05** restores over a GET. The controller shape is heavy: `update()` is 307 lines and `store()` 210, with the validation block duplicated verbatim.

The effort is about a day. Six DECISION items need your choice first. Note that the registered `TimetableTypePolicy` is dead code and the string gates have no `Gate::define` — this is a module-wide pattern, not fixed here (see §7).

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 4 | 8 | 7 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TTY-01 | F8 Services/Jobs | clean: no service, no job, no event (`grep -nE "dispatch\(|event\(|Service" $C` → none) |
| F2 Transactions/Audit | clean: every mutator = one `DB::transaction` closure, `activityLog` after write inside, redirect built after | F9 Queries/Perf | TTY-12, TTY-13 |
| F3 Authorization | TTY-02 (dead policy / undefined string gate) | F10 Views | TTY-14 |
| F4 Validation | TTY-03, TTY-04 | F11 Security/Tenancy | clean: no `env()`, no hard-coded ids, JSON returns only `is_active`/`success`/`message`; tenant middleware present |
| F5 Routes | TTY-05 | F12 Style | TTY-15 |
| F6 Controller shape | TTY-06, TTY-07, TTY-08, TTY-09 | F13 Deep read | TTY-16, TTY-17, TTY-18, TTY-19 |
| F7 Models | TTY-10, TTY-11 | | |

**Findings per method** (controller only; no service in scope): `store` 8 · `update` 10 · `show` 2 · `edit` 2 · `destroy` 3 · `forceDelete` 3 · `restore` 3 · `toggleStatus` 2 · `index` 1 · `create` 0 · `trashedTimetableType` 0.

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/TimetableTypeController.php` | controller | 895 | this report | ✅ whole class |
| 2 | `app/Models/TimetableType.php` | model | 183 | **this report (pre-assigned)** | ✅ |
| 3 | `app/Policies/TimetableTypePolicy.php` | policy | 44 | this report | ✅ — registered but unreachable, TTY-02 |
| 4 | `routes/web.php` lines 104-110 (`timetable-type` block) | routes | — | this report | ✅ |
| 5 | `resources/views/timetable-type/create.blade.php` | page | 234 | this report | ✅ |
| 6 | `resources/views/timetable-type/edit.blade.php` | page | 360 | this report | ✅ |
| 7 | `resources/views/timetable-type/show.blade.php` | page | 133 | this report | ✅ |
| 8 | `resources/views/timetable-type/trash.blade.php` | page | 111 | this report | ✅ |
| 9 | `resources/views/timetable-type/index.blade.php` | page (orphan) | 47 | this report | ✅ — see TTY-14 |
| 10 | `resources/views/pages/partials/timetable-masters/timetable-types/_list.blade.php` | tab list (rendered via `timetable-masters.blade.php:47`, menu controller) | 291 | this report | ✅ — usage |
| 11 | `database/migrations/tenant/2026_06_16_152619_create_tt_timetable_type_table.php` | migration (schema ref) | 55 | this report | ✅ — schema match only |
| 12 | `Modules/TimetableFoundation/app/Providers/TimetableFoundationServiceProvider.php:141` | policy registration | — | common | referenced only |
| — | `ClassTimetableType` model | model | — | [ClassTimetableTypeController](../ClassTimetableTypeController-done/01-report.md) | ↗ linked (usage checked) |
| — | `AcademicTerm` model | model | — | [AcademicTermController](../AcademicTermController-done/01-report.md) | ↗ linked (usage checked) |
| — | `PeriodSet` model | model | — | [PeriodSetController](../PeriodSetController-done/01-report.md) | ↗ linked (usage checked) |
| — | `SchoolShift` model | model | — | [SchoolShiftController](../SchoolShiftController-done/01-report.md) | ↗ linked (usage checked) |
| — | `SlotRequirement` model | model | — | [SlotRequirementController](../SlotRequirementController-done/01-report.md) | ↗ linked (usage checked) |
| — | `SchoolClass` model | model | — | common (SchoolSetup module) | usage only |
| — | `x-backend.layouts.app`, `components.breadcrum`, `form.status-switch`, `form.button-submit`, `table.action`, `table.action-trashed`, `tab.search-bar` | shared components | — | common | props checked against constructors only |
| ⚠ | `ClassModeRule` model | model | — | [ClassTimetableTypeController](../ClassTimetableTypeController-done/01-report.md) | ↗ linked — missing table, TTY-11 |

**Pre-applied 2026-10-10:** this controller is **not** listed in `../PRE-APPLIED-2026-10-10.md`. One in-scope file *is* listed: **`routes/web.php`** ("dead routes cleaned. Result: 239 routes, 0 pointing at a missing method"). The timetable-type route block itself was not changed by that pass; the audit verified it fresh. No other in-scope file appears there.

## 4. Routes

Uncached probe: `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` (filtered on `TimetableTypeController@`).

```
GET|HEAD  timetable-foundation/timetable-type                        timetable-foundation.timetable-type.index       index
POST      timetable-foundation/timetable-type                        timetable-foundation.timetable-type.store       store
GET|HEAD  timetable-foundation/timetable-type/create                 timetable-foundation.timetable-type.create      create
GET|HEAD  timetable-foundation/timetable-type/trash/view             timetable-foundation.timetable-type.trashed     trashedTimetableType
GET|HEAD  timetable-foundation/timetable-type/{timetable_type}       timetable-foundation.timetable-type.show        show
PUT|PATCH timetable-foundation/timetable-type/{timetable_type}       timetable-foundation.timetable-type.update      update
DELETE    timetable-foundation/timetable-type/{timetable_type}       timetable-foundation.timetable-type.destroy     destroy
GET|HEAD  timetable-foundation/timetable-type/{timetable_type}/edit  timetable-foundation.timetable-type.edit        edit
POST      timetable-foundation/timetable-type/{timetableType}/toggle-status timetable-foundation.timetable-type.toggleStatus toggleStatus
DELETE    timetable-foundation/timetable-type/{id}/force-delete      timetable-foundation.timetable-type.forceDelete forceDelete
GET|HEAD  timetable-foundation/timetable-type/{id}/restore           timetable-foundation.timetable-type.restore     restore   ← GET
```

Middleware on every route (`route:list -v`): `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`.

**Unrouted public methods:** none. All 11 public methods are routed.
- RTE-02 clean (`route:list` loaded without error; every action resolves).
- RTE-06 not present: custom routes are declared after `Route::resource` (`routes/web.php:105-109`), but none collides with a resource URI — `/trash/view` is two segments, `/restore` and `/force-delete` are `/{id}/…`, and toggle-status is `/{timetableType}/toggle-status`; none is captured by `GET|DELETE /{timetable_type}`.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect to menu tab) | TTY-14 |
| create | ✅ | create | — | — | — | — |
| store | ✅ | create | ✅ closure (`:159`) | `Stored` (`:241`) | `tt_timetable_types`, `tt_class_timetable_types_jnt`, `sys_activity_logs` | TTY-01, 03, 04, 06, 07, 08, 09, 12 |
| show | ✅ | view | — | — | — | TTY-07, 09 |
| edit | ✅ | update | — | — | — | TTY-07, 09, 13 |
| update | ✅ | update | ✅ closure (`:521`) | `Updated` (`:656`, `:661`) | `tt_timetable_types`, `tt_class_timetable_types_jnt`, `sys_activity_logs` | TTY-01, 03, 06, 07, 08, 09, 12, 13, 16, 19 |
| destroy | ✅ | delete | ✅ closure (`:700`) | `Trashed` (`:708`) | `tt_timetable_types`, `sys_activity_logs` | TTY-01, 07, 18 |
| trashedTimetableType | ✅ | viewAny | — | — | — | — |
| forceDelete | ✅ | forceDelete | ✅ closure (`:761`) | `Deleted` (`:766`) | `tt_timetable_types` (+ FK children), `sys_activity_logs` | TTY-01, 07, 17 |
| restore | ✅ | restore | ✅ closure (`:804`) | `Restored` (`:812`) | `tt_timetable_types`, `sys_activity_logs` | TTY-01, 05, 07 |
| toggleStatus | ✅ | update | ✅ closure (`:856`) | `Toggled` (`:866`) | `tt_timetable_types`, `sys_activity_logs` | TTY-01, 03 |

**Tables each mutation SHOULD touch (measured, `controller-alignment.md` §0.1):**
- **store**: `tt_timetable_types` + one row per (class, section) in `tt_class_timetable_types_jnt` + the log, and (when `is_default`) clearing the previous default. All present.
- **update**: the type row + the (class, section, term) junction diff + the log. All present — but the junction diff is wrong for NULL terms (TTY-16).
- **destroy / forceDelete**: also the children of `tt_timetable_types` (`tt_class_timetable_types_jnt` NO ACTION 86 rows/type, `tt_slot_requirements` NO ACTION 43 on type 1, `tt_timetables` NO ACTION 7 on type 1, `tt_requirement_consolidations` SET NULL 662 on type 1). Neither checks any of them (TTY-17/TTY-18).

## 6. Findings

### F1 — Errors
#### TTY-01 · M · ERR-00 (D1) + ERR-05 — six mutators still catch their own errors; one throws and catches `RuntimeException`
**Where:** `store:155-260` · `update:518-680` · `destroy:699-726` · `forceDelete:760-784` · `restore:803-830` · `toggleStatus:855-887`
```php
} catch (\Throwable $e) {                       // update:669
    Log::error('TimetableType update failed', [
        'id' => $timetableType->id,
        'error' => $e->getMessage(),            // message, not the exception object (ERR-05)
        'trace' => $e->getTraceAsString(),
    ]);
    return redirect()->route(...)->with('error', flash('operation_failed.timetable_type', ...));
```
Also:
```php
if (!$saved) {
    throw new \RuntimeException('Failed to save timetable type status.');  // toggleStatus:862
}
```
**Evidence:** `grep -nE 'try \{|catch \(' $C` → 6 `try`, 6 `catch (\Throwable)`, 2 `catch (ModelNotFoundException)`. Under **D1** every controller try/catch is a finding, exactly as ATC-04 recorded for the sibling controller. Under **D2** `catch (\RuntimeException)` is forbidden and QueryException extends it; here `toggleStatus` both throws and catches it via `\Throwable`.
**Consequence:** failures lose the exception object in the log (ERR-05), and the controller uses two different error models from the rest of the module; the central handler would render the same cases without page-specific duplication.

### F2 — Transactions/Audit
Clean — every mutator runs inside one `DB::transaction(fn () => …)`; `activityLog()` is inside the closure and after the write it describes; no irreversible side effect (no mail/file/HTTP) inside any transaction; every redirect/JSON is built after the closure. Proven by reading `store:159-246`, `update:521-665`, `destroy:700-713`, `forceDelete:761-771`, `restore:804-817`, `toggleStatus:856-874`.

### F3 — Authorization
#### TTY-02 · L · AUTH-04 — the registered `TimetableTypePolicy` is never consulted, and the string gates have no definition
**Where:** controller `Gate::authorize('tenant.timetable-foundation.timetable-type.*')` (`:27,37,58,272,282,381,697,735,758,801,849`) · `TimetableFoundationServiceProvider.php:141` (`Gate::policy(TimetableType::class, TimetableTypePolicy::class)`) · `TimetableTypePolicy.php` (7 methods)
**Evidence:**
- `Gate::has('tenant.timetable-foundation.timetable-type.viewAny')` → `false`; `grep -rn "Gate::define" app/ Modules/` finds no definition for the tenant permission strings (only `Gate::before` super-admin bypass in `AppServiceProvider.php:78`).
- `Gate::forUser($nonSuperUser)->allows('tenant.timetable-foundation.timetable-type.viewAny')` → `false`, while `$user->hasPermissionTo(...)` is the intended check.
- All 7 permission names are declared in `config/permissionslist.php:649` and seeded (`sys_permissions` shows all 7).
**Consequence:** for a non-super-admin the gate denies; the policy that encodes the real rule is dead. This is the same module-wide pattern recorded as ATC-14 and the HrStaff finding, so it is **not fixed by this controller's pass**. Cross-cutting §7.

### F4 — Validation
#### TTY-03 · M · VAL-02 — validation is inline in three methods; the `store`/`update` blocks are duplicated verbatim
**Where:** `store:60-134` · `update:383-462` · `toggleStatus:851-853`
**Evidence:** `grep -n "request->validate" $C` → 3 hits. The two CRUD blocks are ~60 lines each and differ only in the `Rule::unique(...)->ignore(...)` clause. No `TimetableTypeRequest` exists (`ls app/Http/Requests/` → only `TimetableAssignmentRequest.php`).
**Consequence:** rule changes must be made twice and can drift; VAL-07 cross-field checks (time sanity, term scope) sit in the controller instead of the request `after()` hook.

#### TTY-04 · M · VAL-05 — `classes.*.academic_term_id` has no `exists` rule although the column has a NOT-ACTION FK; `is_active` is `sometimes` with no type
**Where:** `store:113,125` · `update:445,453`
```php
'is_active'                      => ['sometimes'],                       // store:113 — validates nothing
'classes.*.academic_term_id'     => ['nullable', 'integer'],              // no exists:sch_academic_term,id
```
**Evidence:** tenant probe — `tt_class_timetable_types_jnt.academic_term_id` FK → `sch_academic_term` DELETE_RULE=`NO ACTION`; sibling `classes.*.period_set_id` (`:124`) *does* carry `exists:tt_period_sets,id`.
**Consequence:** a crafted POST with an arbitrary term id passes validation and hits SQL 1452, surfaced only as the generic "Failed to create/update the timetable type" flash.

### F5 — Routes
#### TTY-05 · H · RTE-01 — Restore runs over a GET request
**Where:** `routes/web.php:107` — `Route::get('/timetable-type/{id}/restore', [TimetableTypeController::class, 'restore'])->name('timetable-type.restore');`
**Evidence:** `route:list` → `GET|HEAD …/{id}/restore`. The only in-repo caller is `trash.blade.php:81-86` via `<x-backend.table.action-trashed url="timetable-foundation.timetable-type" …>`, which derives the HTTP verb from the route, so changing the verb needs no blade edit.
**Consequence:** GET has no CSRF protection; a link preview or prefetcher can restore a trashed timetable type.

### F6 — Controller shape
#### TTY-06 · H · CTL-02 — `update()` is 307 lines and `store()` is 210 lines
**Where:** `store:56-265` (210) · `update:379-685` (307)
**Evidence:** `scan.php` → `store() is 210 lines`, `update() is 307 lines` (both > 150 → H). Both embed a ~40-line validation block, a single-default block and a class-assignment loop.
**Consequence:** the two heaviest write paths in the module are hard to review; a change to one rarely lands in the other.

#### TTY-07 · M · CTL-03 — five methods use `$id` + `findOrFail` instead of route model binding
**Where:** `show:270-274` · `edit:280-284` · `destroy:695-701` · `forceDelete:756-762` · `restore:799-805`
**Evidence:** `grep -nE 'public function (show|edit|destroy|forceDelete|restore)\(' $C` → all take `$id`. `update` and `toggleStatus` already bind (`TimetableType $timetableType`).
**Consequence:** the pattern differs between methods; the resource route already supplies `{timetable_type}`, so binding is free.

#### TTY-08 · M · CTL-05 / CTL-06 — duplicated validation and business logic in the controller
**Where:** validation `store:60-134` vs `update:383-462`; assignment build/sync `store:201-237` vs `update:591-639`
**Evidence:** the two validation arrays are identical apart from `ignore()`. The (class, section, term) diff/sync algorithm (~150 lines: `submittedAssignmentKeys`, `formEditableClassSections`, `assignmentKey`, the guard and the merge loop) lives entirely in the controller and is called only from `update`.
**Consequence:** the assignment algorithm cannot be unit-reasoned, reused, or tested outside a full request; the two validation copies drift.

#### TTY-09 · L · CTL-04 — no return types on any of the 11 public methods
**Evidence:** `scan.php` → `CTL-04` for index, create, store, show, edit, update, destroy, trashedTimetableType, forceDelete, restore, toggleStatus.

### F7 — Models
#### TTY-10 · L · MDL-04 — four relations lack return types
**Where:** `TimetableType.php:84` `shift()` · `:89` `classModeRules()` · `:97` `timetables()` · `:105` `classTimetableTypes()`
**Evidence:** `scan.php` → 4 × `MDL-04 relation … has no return type`. (Proven resolvable: `shift` and `timetables` resolve against live rows; `classTimetableTypes` is eager-loaded by the menu controller.)
**Consequence:** none at runtime; static analysis and IDE support suffer.

#### TTY-11 · L · MDL-07 (usage) — `classModeRules()` points at `tt_class_mode_rules`, which does not exist
**Where:** `TimetableType.php:89-95` → `ClassModeRule` whose `$table = 'tt_class_mode_rules'` (`ClassModeRule.php:18`)
**Evidence:** tenant probe `information_schema.tables … LIKE '%class_mode%'` → `count=0`; `grep -rln "tt_class_mode_rules" database/` → no migration. No application code calls `classModeRules()` (only a PHPStan cache and a unit test reference it).
**Consequence:** latent only. If anything calls the relation it 500s with "table not found". The class is owned by `ClassTimetableTypeController`; the relation is *our* model's usage → cross-cutting §7. Severity L while dead.

### F8 — Services/Jobs
Clean — no service, job, event, mail or notification is named or dispatched (`grep -nE "dispatch\(|event\(|Service|Job|Export|Import" $C` → none). The business logic that *should* be a service is TTY-08.

### F9 — Queries/Perf
#### TTY-12 · M · QRY-07 — helper rows are written one at a time in loops
**Where:** `store:223` and `:230` (`ClassTimetableType::create(...)` inside `foreach`) · `update:625` (`$row->update($payload)` per row) and `:627` (`ClassTimetableType::create($payload)`)
**Evidence:** `scan.php` → `QRY-07 ClassTimetableType::create() inside a loop` at `:223`, `:230`, `:627` and `->update() per row inside a loop` at `:625`. Live tenant: 344 junction rows, up to 86 per timetable type, so a save can issue dozens of individual statements.
**Consequence:** slow saves and many round-trips; a bulk `upsert()` would be one statement.

#### TTY-13 · L · QRY-05 — `->get()->groupBy()` / `->get()->filter()` loads then filters in PHP
**Where:** `edit:291-293` (`->get()->groupBy('class_id')`) · `update:485-490` and `:583-587` (`->get()->filter($isEditable)`)
**Evidence:** `scan.php` → `QRY-05` at `:291`, `:485`, `:583`. Lowered to **L** with reason: each query is already scoped to a single `timetable_type_id`, and the filters depend on a PHP closure (`$isEditable` / `assignmentKey`) that SQL cannot express; the sets are tens of rows.

### F10 — Views
#### TTY-14 · L · CTL-10 / (VIEW) — `index.blade.php` is an orphan that references a variable the controller never passes
**Where:** `timetable-type/index.blade.php:19` (`@forelse($schoolDays as $day)`) · controller `index():25-30` (redirects to the menu tab)
**Evidence:**
- `grep -rn "timetable-type\.index" app/ Modules/ resources/ routes/` (excluding storage/tests) → only `app/Services/Breadcrumbs/registry.php:3824`; no `view(...)` call.
- The controller passes no `$schoolDays`; the blade still renders `status-switch`/`action` with `url="timetable-foundation.timetable-type"`, i.e. it is a copy of another resource's list.
**Consequence:** dead 47-line file that would throw "Undefined variable $schoolDays" if ever rendered; delete candidate.

**Clean checks (one line each):**
- No `{!! !!}` on user data (`grep -n '{!!' railway-type/*.blade.php` → none).
- No queries in Blade; the `_list.blade.php` relations (`shift`, `classTimetableTypes.academicTerm`, `…periodSet.periods.periodType`, `…class.classSections.section`, `…section`) are eager-loaded by the menu controller (`TimetableFoundationController.php:539-551`).
- Row actions use `x-backend.table.action` and `action-trashed`; create form has more than 15 controls (class-assignment table), so a page rather than a modal is consistent with the standard.
- All `route()` names used in the in-scope blades exist; the `class-timetable.create` link is `Route::has()`-guarded (`_list.blade.php:127,262`).

### F11 — Security/Tenancy
Clean — no `env()` outside config (`grep -n env\( $C` → none); no hard-coded ids or `?? 1`; JSON endpoints return only `success` / `is_active` / `message` (`:882-893`); tenant middleware present on every route; `Rule::unique('tt_timetable_types','code')` queries the tenant table, so re-using a trashed code is rejected at validation (no 1062 leak). No cache is used, so no tenant-key concern.

### F12 — Style
#### TTY-15 · L · STY-01 / STY-04 — `strict_types`, emoji markers, redundant same-namespace imports
**Where:** controller `:1` (no `declare(strict_types=1)`), emoji markers at `:307` (⛔), `:334` (⚠), `:349` (⛔), `:581` (⚠) · model `:1` and redundant imports `:8-10` (`SchoolShift`, `ClassModeRule`, `Timetable` are in the same namespace) · policy `:1`
**Evidence:** `scan.php` → `STY-01` (controller, model) + 4 × `STY-04 emoji in comment`.
**Consequence:** consistency only. One plan item per file (see `02-fix-plan.md` §8).

### F13 — Deep read
#### TTY-16 · H · deep read — an assignment saved without an academic term is duplicated on every edit save
**Where:** `submittedAssignmentKeys():362-377` and the resync in `update():583-587`
```php
$termId = $classData['academic_term_id'] ?? null;      // submittedAssignmentKeys:368
...
$existing = ClassTimetableType::where('timetable_type_id', $timetableType->id)
    ->whereIn('academic_term_id', $submittedTerms)     // update:584 — [null] matches NOTHING
    ->get()->filter($isEditable)
    ->keyBy(fn ($row) => $this->assignmentKey(...));
```
**Evidence:**
- `whereIn('academic_term_id', [null])` compiles to `academic_term_id IN (NULL)`, which matches no row, so existing NULL-term rows are invisible to the diff and every submitted row is `ClassTimetableType::create()`d again.
- `tt_class_timetable_types_jnt` has **no unique index** beyond the primary key (tenant probe SHOW INDEX → only `PRIMARY`), so the duplicate insert succeeds.
- The create form's term select offers `-- Select --` (`create.blade.php:186-191`) and the column is nullable (`classes.*.academic_term_id => ['nullable','integer']`), so NULL-term rows are producible.
- Live data currently has no NULL-term rows (`GROUP BY academic_term_id` → `1:172, 2:172`), so the bug is latent, not yet triggered.
**Consequence:** a school that assigns a class without a term gets one extra junction row every time it presses Save, silently inflating the "Classes" count and the period totals on the list tab.

#### TTY-17 · H · deep read — Delete Permanently works on a live type and checks no children
**Where:** `forceDelete:762`
```php
$timetableType = TimetableType::withTrashed()->findOrFail($id);   // a LIVE id is accepted
```
**Evidence:**
- `withTrashed()` matches live rows, so `DELETE /timetable-type/1/force-delete` skips the trash entirely.
- No child guard. Measured children of `tt_timetable_types` (tenant probe):

| Table | ON DELETE | Rows (type 1) | Rows (types 2-4) |
|---|---|---|---|
| `tt_class_timetable_types_jnt` | NO ACTION | 86 | 86 each |
| `tt_slot_requirements` | NO ACTION | 43 | 0 |
| `tt_timetables` | NO ACTION | 7 | 0 |
| `tt_requirement_consolidations` | **SET NULL** | **662** | 0 |

**Consequence:**
- For every live type today, the delete fails with SQL 1451 and the user sees the generic "Failed to permanently delete the timetable type."
- If a type's NO-ACTION children were cleared first, the delete would **succeed** and silently blank `timetable_type_id` on up to 662 requirement-consolidation rows, with no warning.

#### TTY-18 · M · deep read — a type in use, or the default, can be trashed; `is_default` is never cleared
**Where:** `destroy:701-712`
```php
$timetableType = TimetableType::findOrFail($id);
$timetableType->is_active = false;
$timetableType->save();
$timetableType->delete();          // is_default is left as-is on the trashed row
```
**Evidence:** no `is_default` / child check in the method; live type 1 carries `is_default=1` and is referenced by 86 junction rows, 43 slot requirements, 662 consolidations and 7 timetables.
**Consequence:** soft-deleting the default leaves `is_default=1` on a trashed row (the `store`/`update` clear uses the SoftDeletes scope, so it no longer sees it) and the school has no active default; the many referencing rows keep pointing at a type that SoftDeletes queries treat as missing.

#### TTY-19 · M · TXN-06 — "single default" is enforced only in PHP; two concurrent saves can both win
**Where:** `store:166-169` (`TimetableType::where('is_default', true)->update(['is_default' => false])`) · `update:528-532`
**Evidence:** tenant `SHOW CREATE TABLE tt_timetable_types` → `is_default` is a plain column; there is no unique index on it (only `uq_tttype_code`).
**Consequence:** two simultaneous "make default" saves can both clear and both set, leaving two default types; every "default type" lookup then picks arbitrarily.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **String gates are undefined and the policy is dead (module-wide).** `Gate::has('tenant.timetable-foundation.timetable-type.*')` is `false`; no `Gate::define` maps these strings; only `Gate::before` (super-admin) grants access, so a non-super-admin is denied. The same root cause makes every policy in the module — including `TimetableTypePolicy` — unreachable. This is the pattern already recorded in the AcademicTerm report (ATC-14) and the HrStaff finding; it needs a module-level decision.
- **`ClassModeRule` (owned by `ClassTimetableTypeController`)** points at `tt_class_mode_rules`, a table with no migration anywhere. `TimetableType::classModeRules()` is a latent 500 (TTY-11). Its report owns the fix.
- **`activityLog()` helper** (common) is the sole cross-table write besides the junction rows; it behaves consistently and is always called inside the transaction.
- **`SchoolClass` (SchoolSetup module, common)** is loaded with `classSections.section` on create/edit; acceptable for a school-sized table, not audited here.
- **Breadcrumb registry** `app/Services/Breadcrumbs/registry.php:3824` still declares `timetable-foundation.timetable-type.index` even though `index()` redirects; `index.blade.php` (TTY-14) is the orphaned view behind it.

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static or a read-only SQL probe. `tests/Browser/.../TtTimetableTypeCrudTest.php` exists but was not run or relied upon.
- **Other writers of `tt_timetable_types` and `tt_class_timetable_types_jnt`:** seeders, the SmartTimetable generator, and `ClassTimetableTypeController` were not audited; TTY-16/TTY-19 risks partly come from them.
- **`ClassTimetableType` / `PeriodSet` / `SchoolShift` / `SlotRequirement` / `AcademicTerm` internals:** owned by other reports (`↗ linked`), only this controller's usage was checked.
- **Data repair:** no existing row was changed. The 662 consolidation rows and 344 junction rows are reported, not touched.
