# Fix Plan — TimetableFoundation / TimetableTypeController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick ("tick all" does not cover it).
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/TimetableTypeController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
_None (B = 0)._

## 2. Fixes that arm a latent defect (sequenced)
- [x] **TTY-16** · H · deep read · `TimetableTypeController.php:362-377, 583-587` — make the class-assignment resync see NULL-term rows:
  - In `submittedAssignmentKeys()` return the term ids **separately** from "is null present".
  - In `update()`, load `$existing` with `->where(fn ($q) => $q->whereIn('academic_term_id', $ids)->orWhereNull('academic_term_id'))` whenever a submitted class has no term; mirror the same fix in the pre-transaction removal guard at `:487`.
  - Do **not** add a unique index here — that is TTY-19.

  Order: apply this **before** TTY-17/TTY-18. Effort: S.
- [x] **TTY-17** · H · DECISION · deep read · `TimetableTypeController.php:762` — `forceDelete()` accepts a live id and checks no children.
      (a) ⭐ `onlyTrashed()->findOrFail()` so a live type can no longer be purged, **and** count the 4 FK children (`tt_class_timetable_types_jnt`, `tt_slot_requirements`, `tt_timetables` = NO ACTION; `tt_requirement_consolidations` = SET NULL). Refuse with a `\DomainException` naming each blocking table and its count.
      (b) `onlyTrashed()` only; accept that SET NULL children are silently blanked.
      (c) Leave as is.
      ➜ Choice: (a) — Tarun 2026-10-15
- [x] **TTY-18** · M · DECISION · deep read · `TimetableTypeController.php:701-712` — `destroy()` trashes the default/in-use type and never clears `is_default`.
      (a) ⭐ Refuse to trash a type that is `is_default`, or that has NO-ACTION children (same counts as TTY-17). Trashing an unused, non-default type stays allowed.
      (b) Refuse only the default type; allow trashing an in-use type.
      (c) Leave as is.
      ➜ Choice: (a) — Tarun 2026-10-15

## 3. Errors & transactions (F1/F2)
- [x] **TTY-01** · M · ERR-00 / D2 · `TimetableTypeController.php:155-260, 518-680, 699-726, 760-784, 803-830, 855-887` — remove the controller `try/catch` from all six mutators and use `return DB::transaction(fn …)`, the same shape as the pre-applied sibling controllers:
  - `store`/`update` return the model from the closure, then build the redirect.
  - `destroy`/`forceDelete`/`restore`/`toggleStatus` likewise; let the central handler render the failure (JSON for the AJAX toggle).
  - Replace the `throw new \RuntimeException(...)` at `:862` — a `\DomainException` (D2) or drop it; **never** catch `RuntimeException`.
  - Keep the `findOrFail()` outside any remaining catch (D1/ERR-02). Effort: M.
- [x] **TTY-19** · M · DECISION · TXN-06 · `TimetableTypeController.php:166-169, 528-532` + a new tenant migration — "single default" is enforced only in PHP; two concurrent saves can both win.
      (a) ⭐ A new additive tenant migration adds a generated `default_flag` column (`CASE WHEN is_default = 1 THEN 1 ELSE NULL END`) with a UNIQUE key, matching the existing DDL style; the controller is unchanged. ⚠ SHARED (tenant migration — written, never run).
      (b) Keep the app-only clear-then-set; accept the race.
      ➜ Choice: (a) — Tarun 2026-10-15

## 4. Authorization (F3)
- **No fix in this pass.** **TTY-02** (the registered `TimetableTypePolicy` is never consulted; `Gate::has('tenant.timetable-foundation.timetable-type.*')` is `false` and no `Gate::define` maps the string) is a **module-wide** defect — same root cause as ATC-14 and the HrStaff finding. ⚠ SHARED. Raise it to the module-level decision; do not change this controller alone.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **TTY-04** · M · VAL-05 · `TimetableTypeController.php:125, 453` (and `:113, 445`) — add `exists:sch_academic_term,id` to `classes.*.academic_term_id` in **both** `store` and `update` (the column has a NOT-ACTION FK); give `is_active` a `boolean` type instead of bare `sometimes`. Effort: S.
- [x] **TTY-05** · H · DECISION · RTE-01 · `routes/web.php:107` — Restore runs over GET.
      (a) ⭐ Change it to `Route::patch`. `<x-backend.table.action-trashed>` derives the HTTP verb from the route, so no blade edit is needed; the only caller is `trash.blade.php:81`. ⚠ SHARED (route file — needs its own explicit tick).
      (b) Leave as GET and accept the CSRF/prefetch risk.
      ➜ Choice: (a) — Tarun 2026-10-15
- [x] **TTY-03** · M · DECISION · VAL-02 · `TimetableTypeController.php:60-134, 383-462` — validation is inline and duplicated.
      (a) ⭐ Extract one `Modules/TimetableFoundation/app/Http/Requests/TimetableTypeRequest.php` used by `store` and `update`, moving the time-sanity check (`:141-151`) and the effective/term cross-checks into `after()`; `toggleStatus` keeps its one-field inline `validate()` (allowed by VAL-02).
      (b) Leave inline; defer the extraction to the split pass.
      ➜ Choice: (a) — Tarun 2026-10-15
- [x] **TTY-07** · M · CTL-03 · `TimetableTypeController.php:270, 280, 695` — bind `TimetableType $timetableType` in `show`, `edit`, `destroy` (the resource route already supplies `{timetable_type}`); for `forceDelete`/`restore` keep `$id` because they need `withTrashed()` / `onlyTrashed()` and note why. Effort: S.
- [x] **TTY-10** · L · MDL-04 · `TimetableType.php:84, 89, 97, 105` — add return types (`: BelongsTo`, `: HasMany`). ⚠ SHARED — 35 files reach this model; the change is a type-hint only. Effort: S.

## 6. Queries & performance (F9)
- [x] **TTY-12** · M · QRY-07 · `TimetableTypeController.php:223, 230, 625, 627` — replace the per-row `ClassTimetableType::create()` / `->update()` in loops with a single `upsert()` per submitted term scope (keyed on type + class + section + term). Effort: M.
- [x] **TTY-13** · L · QRY-05 · `TimetableTypeController.php:291, 485, 583` — optional; the sets are small and the filters are closure-based. Either keep (documented) or move the chosen-row set into SQL. Effort: S.

## 7. Views (F10)
- [x] **TTY-14** · L · CTL-10 · `resources/views/timetable-type/index.blade.php` — delete the orphan 47-line view. Before deleting, re-prove `routed=0 refs=0` for `timetablefoundation::timetable-type.index` at fix time (`index()` redirects; it also references `$schoolDays`, which this controller never passes). Effort: S.

## 8. Style (F12) — one item per file
- [x] **TTY-15a** · L · STY-01 / STY-04 · `TimetableTypeController.php` — add `declare(strict_types=1);`; remove the emoji markers at `:307, :334, :349, :581`. Effort: S.
- [x] **TTY-15b** · L · STY · `TimetableType.php` — add `declare(strict_types=1);`; drop the redundant same-namespace imports (`SchoolShift`, `ClassModeRule`, `Timetable`, `:8-10`). ⚠ SHARED. Effort: S.
- [x] **TTY-15c** · L · STY · `TimetableTypePolicy.php` — add `declare(strict_types=1);`. Effort: S.

## 9. Deferred / decisions
- [x] **TTY-06 + TTY-08** · H / M · DECISION · CTL-01 / CTL-02 / CTL-05 / CTL-06 — `update()` (307 lines) and `store()` (210) duplicate a ~60-line validation block and hold a ~150-line assignment algorithm.
      (a) ⭐ Defer to the split pass (D3): keep the URLs, route names and files as they are; record the split and the extraction of the assignment logic as one future change.
      (b) Extract an assignment service now (the controller stays long until the split).
      (c) Leave as is, accepted.
      ➜ Choice: (a) — Tarun 2026-10-15
- **TTY-11** (note, no tick) · L · MDL-07 — `TimetableType::classModeRules()` points at `ClassModeRule` whose table `tt_class_mode_rules` has no migration in any module and does not exist in the tenant DB. The class is owned by [ClassTimetableTypeController](../ClassTimetableTypeController-done/01-report.md); fix it there, or remove the unused relation from `TimetableType.php` in this pass if that report has not run.

---

**How to approve**
1. Tick `[x]` on every item to apply.
2. Fill each `➜ Choice:` for the 6 DECISION items (TTY-03, TTY-05, TTY-17, TTY-18, TTY-19, TTY-06+TTY-08).
3. Tick the `⚠ SHARED` items explicitly (TTY-05 route file, TTY-10 & TTY-15b model, TTY-19 migration).
4. Run `final-audit-fixer` on `Modules/TimetableFoundation/app/Http/Controllers/TimetableTypeController.php`.
