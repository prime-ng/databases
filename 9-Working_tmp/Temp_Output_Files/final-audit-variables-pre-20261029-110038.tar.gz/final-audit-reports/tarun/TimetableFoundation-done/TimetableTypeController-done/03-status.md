# Status — TimetableFoundation / TimetableTypeController

**Fixed:** 2026-10-15 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work

`../PRE-APPLIED-2026-10-10.md` has no row for this controller. Nothing to carry over.

## 2. Applied

17 plan items ticked. The decisions are recorded on each `➜ Choice:` line of `02-fix-plan.md`: all six DECISION items are **(a)**, chosen by Tarun on 2026-10-15.

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| TTY-16 | `TimetableTypeController.php:205, 281, 582-620` | `submittedAssignmentKeys()` now returns `[keys, termIds, hasNullTerm]`. The new `scopeToTerms()` builds `(academic_term_id IN (…) OR academic_term_id IS NULL)` for both the removal guard and the resync. `whereIn('academic_term_id', [null])` matched nothing, so NULL-term rows were never updated or removed and were re-inserted as duplicates | read-only reflection probe | `… and (academic_term_id in (?) or academic_term_id is null) …`. An empty submission gives `(0 = 1)`, count 0 | 2026-10-15 |
| TTY-17 (a) | `TimetableTypeController.php:54-59, 399-420, 493-530` | `forceDelete()` uses `onlyTrashed()->findOrFail()` outside the transaction, so a live id now gives 404. `refuseIfInUse(…, true)` counts all 4 FK child tables, trashed rows included, and throws a `DomainException` naming each table and its count | read-only probe on type 1 | `… cannot be permanently deleted: it is still used by 86 class assignment(s), 43 slot requirement(s), 5 timetable(s), 671 requirement consolidation(s).` | 2026-10-15 |
| TTY-18 (a) | `TimetableTypeController.php:347-375` | `destroy()` refuses the default type ("Make another type the default first.") and any type with live NO-ACTION children (class assignments, slot requirements, timetables). SET NULL consolidations do not block a trash. A refusal becomes a flash error | same probe, trash mode | `… cannot be moved to trash: it is still used by 86 class assignment(s), 43 slot requirement(s), 5 timetable(s).` | 2026-10-15 |
| TTY-01 | `TimetableTypeController.php` (whole class) | All controller `try/catch` removed. The only catches left are `DomainException` in `destroy` and `forceDelete` (D2). The `RuntimeException` throw in `toggleStatus` is gone. Each closure does the writes only, and the redirect is built after the transaction. `Log` and `ModelNotFoundException` imports dropped | `grep -c 'catch (' …` · `grep -c 'Log::' …` | 2, both `DomainException` (lines 369, 414) · 0 | 2026-10-15 |
| TTY-19 (a) ⚠ SHARED | `database/migrations/tenant/2026_10_15_000001_alter_tt_timetable_types_add_default_flag.php` (new) · `TimetableTypeController.php:428-450` | New additive migration adds `default_flag TINYINT(1) GENERATED ALWAYS AS (CASE WHEN is_default = 1 AND deleted_at IS NULL THEN 1 ELSE NULL END) STORED` plus `UNIQUE uq_tttype_default_flag`. It refuses to run while more than one live row is default. **Written, NOT run.** `restore()` clears `is_default` on a restored row when another live default exists, so a restore cannot hit 1062 | `php -l`; live count | ok · live defaults = 1 | 2026-10-15 |
| TTY-04 | `TimetableTypeRequest.php:76, 67` | `classes.*.academic_term_id` gains `exists:sch_academic_term,id`, so an unknown id fails validation instead of raising SQL 1452. `is_active` changes from bare `sometimes` to `nullable\|boolean` | read | — | 2026-10-15 |
| TTY-05 (a) ⚠ SHARED | `Modules/TimetableFoundation/routes/web.php:110-113` | Restore route GET → PATCH, with a comment. The trash page uses `<x-backend.table.action-trashed>`, which reads the verb from the route, so no blade edit was needed | router probe | `PATCH timetable-foundation/timetable-type/{id}/restore` → `restore` ✓ | 2026-10-15 |
| TTY-03 (a) | `Modules/TimetableFoundation/app/Http/Requests/TimetableTypeRequest.php` (new) · `TimetableTypeController.php:98, 182` | One FormRequest for `store` and `update`. It holds the unique code with `->ignore()` on update, the checkbox rules (`sometimes` on create, `required` on edit), and the school-day time check in `after()`. `authorize()` is `authorizeByCrudPermission('tenant.timetable-foundation.timetable-type')`, so POST → `.create` and PUT → `.update`. `toggleStatus` keeps its one-field inline `validate()` | `class_exists`, `php -l` | ok | 2026-10-15 |
| TTY-07 | `TimetableTypeController.php:147, 159, 347` | `show`, `edit` and `destroy` bind `TimetableType $timetableType` to `{timetable_type}`, which Laravel matches by snake form. `forceDelete` and `restore` keep `$id` because route binding cannot see a trashed row (said in their docblocks) | router probe | all 11 routed methods exist | 2026-10-15 |
| TTY-10 ⚠ SHARED | `Modules/TimetableFoundation/app/Models/TimetableType.php:85, 90, 98` | `shift(): BelongsTo`, `timetables(): HasMany`, `classTimetableTypes(): HasMany`, with their imports. Type hints only | `php -l`, `class_exists` | ok | 2026-10-15 |
| TTY-12 | `TimetableTypeController.php:131-137, 293-308, 629-692` | New rows are written by one `ClassTimetableType::insert()` (`insertAssignments()`, timestamps set by hand; the model has no events). Existing rows are `fill()`-ed and saved **only when dirty**. Corrected from the plan: `upsert()` needs a unique key and the junction table has only PRIMARY | read | — | 2026-10-15 |
| TTY-13 | — | Kept, as documented. The editable/term filters stay closure-based over small sets (one type's junction rows) | — | — | 2026-10-15 |
| TTY-14 | `resources/views/timetable-type/index.blade.php` | Deleted after re-proving at fix time that `index()` redirects and nothing references `timetablefoundation::timetable-type.index`. (`RouteAuthenticationTest.php:73` names the ROUTE, which still exists, not the view) | `grep -rn "timetable-type\.index" … \| grep -v route-name` | 0 hits; directory now holds create/edit/show/trash | 2026-10-15 |
| TTY-15a | `TimetableTypeController.php` | `declare(strict_types=1)`, return types on every method, the four emoji markers replaced with plain words, ERR-00 header docblock | `grep -cP '[⚠⛔]' …` | 0 | 2026-10-15 |
| TTY-15b ⚠ SHARED | `TimetableType.php:3` | `declare(strict_types=1)`. The redundant same-namespace imports the plan named were already gone, so nothing was left to drop | `grep -n "^use " …` | BaseModel, BelongsTo, HasMany, SoftDeletes, Carbon | 2026-10-15 |
| TTY-15c | `TimetableTypePolicy.php:3` | `declare(strict_types=1)` | `php -l` | ok | 2026-10-15 |
| TTY-06 + TTY-08 (a) | — | Deferred to the split pass (D3). `store()` and `update()` are shorter now, because validation moved to the FormRequest and the row building to `assignmentRows()`, but the assignment algorithm still lives in the controller | — | — | 2026-10-15 |

⚠ **The three ⚠ SHARED items (TTY-10, TTY-15b on the model, TTY-05 on the route file, TTY-19 the migration) were ticked explicitly in the plan.** None of them changes behaviour for the 35 callers of `TimetableType` except the new DB constraint, which is not live until the migration runs.

## 3. Not applied

| ID | Reason | Detail |
|---|---|---|
| TTY-02 | module-wide, no fix in this pass | The registered `TimetableTypePolicy` is never consulted, because every gate passes a permission string. Same root cause as ATC-14. Needs a module-level decision |
| TTY-11 | already resolved | `classModeRules()` is no longer on `TimetableType.php`; nothing to remove |
| TTY-13 | kept (documented) | see §2 |
| TTY-06 + TTY-08 | deferred (D3) | see §2 |

## 4. Needs Tarun's hand

1. ✅ **Migration run 2026-10-15** (batch 2 on test.localhost): `default_flag` is STORED GENERATED, `uq_tttype_default_flag` exists, and REGULAR alone holds `default_flag = 1`. Originally: `php artisan tenants:migrate`. It refuses with a readable message if more than one live row has `is_default = 1` (today: exactly one, id 1 REGULAR).
2. **Dusk test_25 now fails, as decided.** `TtTimetableTypeCrudTest::test_25_not_found_restore` does a GET on `/timetable-type/999999999/restore` and expects 404. The route is PATCH now, so it gets 405. This is the same outcome as the AcademicTerm and DayType siblings; it is left for the test team. Not edited (D4).
3. ⚠ **Behaviour change to know about (TTY-18 a):** all 4 live types are referenced by **86 class assignments each**, so **none of them can be moved to trash from the UI** until their class assignments are removed on the edit form. REGULAR is also the default. That is what option (a) asks for; say if trashing a type should instead cascade-trash its own class assignments.
4. **Browser check** of Timetable Masters → Timetable Types: create a type with a class that has no term, edit it, save again (no duplicate junction rows), trash an unused type, trash a used one (should refuse), restore from the trash page (PATCH), and use the status switch.

## 5. Unverifiable by this workflow (no tests, D4)

- The `uq_tttype_default_flag` behaviour on the real table. The migration has not been run.
- The full store/update write path (bulk insert, dirty-only update, NULL-term resync). Only the scoping SQL was proven, read-only; no row was written.
- Permission refusals on `store`/`update` through the FormRequest. They run as the user, and super-admin bypasses `Gate::before`.
- Dusk tests that create a type with `is_default` checked (`TtTimetableTypeCrudTest.php:386`) still move the school's default onto a test row, which is then force-deleted by cleanup. That is pre-existing test hygiene and was not changed.

## 6. Verification log
```
php -l  TimetableTypeController.php / TimetableTypeRequest.php / TimetableType.php / TimetableTypePolicy.php
        / 2026_10_15_000001 migration / routes/web.php                                   → No syntax errors
vendor/bin/pint <the 5 PHP files> --format agent                                         → passed
php -l re-run after Pint                                                                  → No syntax errors
class_exists: TimetableTypeController, TimetableTypeRequest, TimetableType, TimetableTypePolicy → OK ×4
route:clear + router probe: 11 timetable-type routes, method_exists ✓ on all; restore = PATCH
grep (controller): try=2 catch=2 (both DomainException) Log::=0 emoji=0
                   onlyTrashed()->findOrFail=2 (forceDelete, restore) validated()=2 inline validate=1 (toggleStatus)
Read-only probes (tenant test.localhost, no writes):
  submittedAssignmentKeys → [{"3|1|none","3|2|none","4|all|2"}, [2], true]
  scopeToTerms SQL       → (academic_term_id in (?) or academic_term_id is null)
  refuseIfInUse on all 4 types → every type blocked by 86 class assignments; REGULAR also by 43 slot reqs, 5 timetables
                                  (+671 consolidations for force)
  tt_timetable_types rows = 4 before and after; live defaults = 1
Orphan proof: grep "timetable-type.index" outside the route name → 0
```

## 7. Final state
Status: FIXED · Open plan items: B 0 · H 0 · M 0 · L 0 · Deferred: TTY-06+08 (split pass), TTY-02 (module-wide). Migration applied 2026-10-15. Dusk test_25 is expected red (405).
