# 03 — Status · SchoolShiftController

**Fixed:** 2026-10-12 · **By:** claude · **Branch:** development
**Decisions (Tarun, "fix all as recommended"):** SSH-01 (a) PATCH restore · SSH-05 (a) refuse to trash a shift still in use · SSH-04 added to this pass · SSH-06 deferred.

## 1. Pre-applied 2026-10-10
None.

## 2. Applied

| ID | File:line | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| SSH-02 | SchoolShiftController `forceDelete()` | `onlyTrashed()->findOrFail()`; `refuseIfInUse()` names each child table + count; only `DomainException` caught | probe: forceDelete a LIVE id | 404 (ModelNotFoundException) | 2026-10-12 |
| SSH-05 | `destroy()` | same `refuseIfInUse()` before trashing | probe: destroy MORNING | "…still used by 4 timetable type(s), 4 period set(s), 9 period config(s)." — row stays live | 2026-10-12 |
| SSH-03 | all 6 mutations | try/catch removed; transactions kept; DomainException catch only in destroy/forceDelete | `grep -c "catch (\\\\Throwable"` | 0 | 2026-10-12 |
| SSH-01 | routes/web.php:168 | restore `Route::get` → `Route::patch`; `action-trashed` derives the verb, no blade edit | route:list | `PATCH timetable-foundation/shift/{id}/restore` | 2026-10-12 |
| SSH-07 | `store()`, `update()` | duplicate `Gate::authorize` removed; `SchoolShiftRequest::authorize()` gates them | read | — | 2026-10-12 |
| SSH-04 | `show/edit/update/destroy` | `SchoolShift $shift` bound from `{shift}`; `findOrFail($id)` gone (restore/forceDelete keep `$id` on purpose) | class_exists + probe | OK | 2026-10-12 |
| SSH-08 | SchoolShiftController | strict_types, return types on all 11 methods, redundant `$request->boolean('is_active')` lines removed (validated() already carries it) | php -l, Pint | clean | 2026-10-12 |
| SSH-09/11 | SchoolShiftRequest, SchoolShiftPolicy | strict_types | php -l | clean | 2026-10-12 |
| SSH-10 | SchoolShift | strict_types + `timetableTypes(): HasMany` | php -l | clean | 2026-10-12 |
| SSH-12 | views/shift/create.blade.php | deleted after re-proving no `view()` reference and no `create` route | grep + route:list | 0 refs, no route | 2026-10-12 |

## 3. Not applied
- **SSH-06** (time columns cast as `datetime`) — deferred. `edit.blade.php` calls `->format('H:i')` on these values, so changing the cast also needs view edits.

## 4. Needs Tarun's hand
- **TtShiftTest `test_25_not_found_restore`** visits `GET /timetable-foundation/shift/999999999/restore` and expects a 404. Restore is PATCH now, so that GET no longer matches the route — expect 405 (or the DecryptUrl redirect). The test needs re-aiming (e.g. a PATCH via fetch, or assert "not reachable by GET"). `test_12` (restore via the button) is unaffected — the form now posts `_method=PATCH`. Not edited (D4).
- Browser check: delete the Morning shift from the tab → red message naming the 3 tables.

## 5. Cross-cutting (not fixed here)
- `Modules/SmartTimetable/resources/views/smart-timetable/partials/shifts/_list.blade.php:42` calls `route('timetable-foundation.shift.create')` with no `Route::has` guard. That route has not existed since 2026-09-10 (TM-05), so any page including the partial (`SmartTimetableController:194` index, `:1280` master; `TimetablePageController:688` master) throws RouteNotFoundException when rendered. Pre-existing, other module — needs its own instruction.

## 6. Verification log
```
php -l + Pint (4 files)                 clean
class_exists Controller/Request/Model/Policy   OK x4
route:list --path=timetable-foundation/shift   10 routes, restore = PATCH
rolled-back probe:
  destroy MORNING   refused, names 4 / 4 / 9, still live
  destroy AFTERNOON trashed
  forceDelete live id   404
  new unused shift: destroy -> trashed, restore -> live+active, forceDelete -> gone
  logs: Trashed, Restored, Deleted
  after rollback: 2 shifts
```

## 7. Final state
**FIXED.** Open: SSH-06 (deferred, M).
