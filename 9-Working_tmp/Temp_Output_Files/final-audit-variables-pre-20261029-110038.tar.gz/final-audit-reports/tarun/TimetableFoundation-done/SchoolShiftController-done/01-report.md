# Final Audit — TimetableFoundation / SchoolShiftController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/SchoolShiftController.php` (321 lines, 11 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 2 HIGH, mostly small.**

The CRUD is clean in shape — every mutation runs in one `DB::transaction` closure with the
`activityLog` inside, the FormRequest matches the DB's unconditional unique indexes exactly, and
all permissions are seeded by exact name. Two things can go wrong for a real user:

- **Restore runs over a GET request.** A link preview or prefetcher can restore a trashed shift.
- **Delete Permanently accepts a live shift.** `forceDelete` uses `withTrashed()`, so a crafted
  URL can permanently delete a shift that was never trashed, skipping the trash step. It also has
  no child guard — if the shift has children (period configs, period sets, timetable types) the
  FK fails with the generic "Failed to perform the operation" flash.

The worst is **SSH-02**, the force-delete on a live shift. Effort is about half a day.
Two DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 2 | 3 | 6 | 2 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | SSH-03 | F8 Services/Jobs | clean: no service, job, event, mail (`grep -nE "Service\\|dispatch\\|event\\(" $C` → none) |
| F2 Transactions/Audit | clean: every mutation is one closure with `activityLog` after the write inside it (SSH-05 is F13, not TXN) | F9 Queries/Perf | clean: `trashedShift` paginates 10; no `::all()`; no query in a loop |
| F3 Authorization | SSH-07 | F10 Views | SSH-12; blades all compile |
| F4 Validation | clean: FormRequest + `validated()`; one-field AJAX toggle exception applies (VAL-02) | F11 Security/Tenancy | SSH-01 (RTE-01); tenant middleware on every route ✅ |
| F5 Routes | SSH-01 | F12 Style | SSH-08, 09, 10, 11 |
| F6 Controller shape | SSH-04 | F13 Deep read | SSH-02, SSH-05 |
| F7 Models | SSH-06 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TimetableFoundation/app/Http/Controllers/SchoolShiftController.php` | controller | 321 | this report | ✅ whole class |
| 2 | `Modules/TimetableFoundation/app/Http/Requests/SchoolShiftRequest.php` | FormRequest | 98 | this report | ✅ whole class |
| 3 | `Modules/TimetableFoundation/app/Models/SchoolShift.php` | model | 75 | **this report (pre-assigned)** | ✅ |
| 4 | `Modules/TimetableFoundation/app/Policies/SchoolShiftPolicy.php` | policy | 44 | this report | ✅ — unreachable, see §7 |
| 5 | `Modules/TimetableFoundation/routes/web.php` lines 162-168 | routes | — | this report | ✅ |
| 6 | `views/shift/show.blade.php` | page | 63 | this report | ✅ |
| 7 | `views/shift/edit.blade.php` | page | 92 | this report | ✅ |
| 8 | `views/shift/trash.blade.php` | page | 80 | this report | ✅ |
| 9 | `views/shift/_create-modal.blade.php` | dialog | 22 | this report | ✅ |
| 10 | `views/shift/_create-fields.blade.php` | dialog fields | 82 | this report | ✅ |
| 11 | `views/shift/create.blade.php` | page (orphan) | 89 | this report | ✅ — dead, SSH-12 |
| 12 | `views/pages/partials/timetable-masters/shifts/_list.blade.php` | tab list | 110 | this report | ✅ (data comes from `TimetableFoundationController::timetableMasters`, own report) |
| — | `x-backend.tab.search-bar`, `x-backend.table.action`, `action-trashed`, `status-switch`, `form.status-switch`, `x-tenantcore::export-buttons`, layouts | shared components | — | common | props checked against constructors only |

**Pre-applied 2026-10-10:** `routes/web.php` was touched that day (dead routes cleaned, result 239
routes). `SchoolShiftController`, its request, the model and the blades are **not** in
`../PRE-APPLIED-2026-10-10.md`; there is nothing to name for them. The `create()` NOT ROUTED shape
predates the audit (comment dated 2026-09-10) and matches D5 already.

## 4. Routes

```
GET|HEAD  timetable-foundation/shift                         timetable-foundation.shift.index        index
POST      timetable-foundation/shift                         timetable-foundation.shift.store        store
GET|HEAD  timetable-foundation/shift/trash/view              timetable-foundation.shift.trashed      trashedShift
DELETE    timetable-foundation/shift/{id}/force-delete       timetable-foundation.shift.forceDelete  forceDelete
GET|HEAD  timetable-foundation/shift/{id}/restore            timetable-foundation.shift.restore      restore   ← GET
GET|HEAD  timetable-foundation/shift/{shift}                 timetable-foundation.shift.show         show
PUT|PATCH timetable-foundation/shift/{shift}                 timetable-foundation.shift.update       update
DELETE    timetable-foundation/shift/{shift}                 timetable-foundation.shift.destroy      destroy
GET|HEAD  timetable-foundation/shift/{shift}/edit            timetable-foundation.shift.edit         edit
POST      timetable-foundation/shift/{shift}/toggle-status   timetable-foundation.shift.toggleStatus toggleStatus
```

Middleware on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain,
EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified` (proven by the
uncached `route:list --json`).
**Unrouted public methods:** `create` (line 26) — already D5-compliant: body is `abort(403, …)`
with a `// NOT ROUTED` comment, and `Route::resource('shift', …)->except(['create'])`.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect to tab) | — |
| create | ❌ D5 | none (abort 403) | — | — | — | SSH-08 (no return type) |
| store | ✅ | create (+ request) | ✅ closure | `Stored` | tt_shifts, sys_activity_logs | SSH-03, 07, 08 |
| show | ✅ | view | — | — | — | SSH-04 |
| edit | ✅ | update | — | — | — | SSH-04 |
| update | ✅ | update (+ request) | ✅ closure | `Updated` | tt_shifts, sys_activity_logs | SSH-03, 04, 07, 08 |
| destroy | ✅ | delete | ✅ closure | `Trashed` | tt_shifts, sys_activity_logs | SSH-03, 05, 08 |
| trashedShift | ✅ | restore | — | — | — | — |
| restore | ✅ GET | restore | ✅ closure | `Restored` | tt_shifts, sys_activity_logs | SSH-01, 03 |
| forceDelete | ✅ | forceDelete | ✅ closure | `Deleted` | tt_shifts, sys_activity_logs | SSH-02, 03 |
| toggleStatus | ✅ | update | ✅ closure | `Toggled` | tt_shifts, sys_activity_logs | SSH-03, 08 |

**Tables each mutation SHOULD touch:** store/update/destroy/restore/forceDelete/toggleStatus each
write the shift row **and** the audit row (multi-table). All six run inside one `DB::transaction`
closure with `activityLog` after the write, inside the closure → **TXN-01/04 satisfied**. The
redirect and flash are built **after** the closure returns → **TXN-05 satisfied** (unlike ATC-12).

## 6. Findings

### F5 — Routes
#### SSH-01 · H · RTE-01 — Restore runs over a GET request
**Where:** `routes/web.php:165`
```php
Route::get('/shift/{id}/restore', [SchoolShiftController::class, 'restore'])->name('shift.restore');
```
**Evidence:** `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` → `GET|HEAD timetable-foundation/shift/{id}/restore`; the scanner's RTE-01 row confirms it. The only caller is `trash.blade.php:52` via `<x-backend.table.action-trashed url="timetable-foundation.shift" …>`, and that component derives the HTTP verb from the route (line 19-20), so changing the verb needs no blade edit.
**Consequence:** GET has no CSRF protection, so a link preview or prefetcher can silently restore a trashed shift.

### F13 — Deep read
#### SSH-02 · H · deep read (ATC-03 pattern, this module) — Delete Permanently works on a live shift and checks no children
**Where:** `SchoolShiftController.php:250`
```php
$shift = SchoolShift::withTrashed()->findOrFail($id);
```
**Evidence:** `withTrashed()` matches live rows too — `DELETE timetable-foundation/shift/{id}/force-delete` with a live id skips the trash entirely. Child tables of `tt_shifts`, measured read-only in the tenant DB:

| Table | ON DELETE | Rows (tenant) |
|---|---|---|
| tt_period_configs | NO ACTION | 9 |
| tt_period_sets | NO ACTION | 4 |
| tt_timetable_types | NO ACTION | 4 |

**Consequence:** a crafted URL can permanently delete a shift that still has NO ACTION children — the delete then fails with error 1451 and the user sees the generic "Failed to perform the operation on Shift" with no reason.

#### SSH-05 · M · deep read (ATC-09 pattern) — a shift still referenced by period configs / period sets / timetable types can be trashed
**Where:** `destroy:147-179` (only deactivates + soft-deletes)
**Consequence:** trashing hides the shift from every active dropdown (`SchoolShift::where('is_active', true)` in 6 other controllers) while 4 timetable types, 4 period sets and 9 period configs keep a `shift_id` pointing at a row that now looks missing. This is DECISION-worthy (see plan §7).

### F1 — Errors
#### SSH-03 · M · ERR-00 (D1) — six write methods still catch errors themselves
**Where:** `store:48-72`, `update:112-137`, `destroy:153-178`, `restore:211-236`, `forceDelete:252-272`, `toggleStatus:290-319`
```php
try {
    DB::transaction(function () use (…) {
        …
        activityLog(…);
    });

    return redirect()…;
} catch (\Throwable $e) {
    report($e);
    return redirect()->back()->with('error', flash('operation_failed.shift'))…;
}
```
**Evidence:** `grep -n "catch" $C` → 6 hits, all `catch (\Throwable $e)` — none is a D2 shape (`\DomainException`, truncate-rebuild, `SnapshotProtectionException`), and none carries an ERR-01+date comment.
**Note on the good parts:** each catch calls `report($e)` with the exception object (ERR-05 satisfied) and returns a fixed flash string, never `$e->getMessage()` (ERR-01 satisfied). The remaining defect is the shape: under D1 the central handler in `bootstrap/app.php` should render these failures (JSON for the toggle, redirect/500 for the form).
**Consequence:** failures produce a generic flash instead of the central handler's response — the exact family AcademicTerm's `store`/`update`/`destroy` were hardened to in the pre-applied pass.

### F6 — Controller shape
#### SSH-04 · M · CTL-03 — show/edit/update/destroy take `$id` + `findOrFail` on routes whose parameter is `{shift}`
**Where:** `SchoolShiftController.php:79, 90, 106, 147`
```php
public function show($id) { … SchoolShift::findOrFail($id); … }   // route: shift/{shift}
```
**Evidence:** `route:list` shows `{shift}` for these four; the controller arguments are `$id`, so no implicit binding fires and the raw value goes into `findOrFail`. (The route param name is `shift`; a method arg of `SchoolShift $shift` would bind.) `restore`/`forceDelete` intentionally stay on `$id` — binding would exclude trashed rows via the SoftDeletes global scope, so their `withTrashed()`/`onlyTrashed()` pattern is correct as-is.
**Consequence:** no user-visible bug today (404 still works), but the bindable routes silently skip the framework's 404 model resolution and its `with`-loading conveniences.

### F7 — Models
#### SSH-06 · M · MDL-02 — `time` columns are cast as `datetime`, fabricating today's date on every read
**Where:** `SchoolShift.php:36-37`
```php
protected $casts = [
    'default_start_time' => 'datetime',
    'default_end_time' => 'datetime',
];
```
**Evidence:** `SchoolShift::find(1)->default_start_time` → Carbon `2026-10-10 07:30:00` (date fabricated from "today"); a write serializes to the same fabricated full datetime (`2026-10-10 08:00:00`), which MySQL truncates into the `TIME` column (`SELECT CAST("2026-10-10 08:00:00" AS TIME)` → `08:00:00`). Live DDL: `default_start_time time DEFAULT NULL`.
**Consequence:** today every consumer formats only the time part (`->format('H:i')`), so nothing visibly breaks — but the model reports a date that changes with the day, a latent trap for any future consumer (export, API, date arithmetic).

### F3 — Authorization
#### SSH-07 · L · AUTH-04 — store/update authorize twice
**Where:** `SchoolShiftController.php:46, 108` vs `SchoolShiftRequest.php:20-26`
**Evidence:** the request's `authorize()` calls `authorizeByCrudPermission('tenant.timetable-foundation.shift')` (POST→create, PUT/PATCH→update), and the controller calls `Gate::authorize('tenant.timetable-foundation.shift.create/.update')` again for the same permission.
**Consequence:** two layers check the same string; harmless today, but a permission-name change has two places to drift. (The policy below is the bigger, module-wide question — §7.)

### F12 — Style
#### SSH-08 · L · STY / CTL-04 / CTL-05 · controller
No `declare(strict_types=1)`; no return types on any of the 11 public methods; `$validated['is_active'] = $request->boolean('is_active')` (`:51, :115`) re-assigns a value the FormRequest's `prepareForValidation()` has already merged and validated; the six try/transaction/redirect blocks are near-identical copy (SSH-03's shape).

#### SSH-09 · L · STY-01 · `SchoolShiftRequest.php`
No `declare(strict_types=1)`.

#### SSH-10 · L · STY-01 + MDL-04 · `SchoolShift.php`
No `declare(strict_types=1)`; `timetableTypes()` has no return type (scanner MDL-04 row).

#### SSH-11 · L · STY-01 · `SchoolShiftPolicy.php`
No `declare(strict_types=1)`.

### F10 — Views
#### SSH-12 · L · dead view — `shift/create.blade.php` is an orphan
**Evidence:** the `create` route does not exist (`except(['create'])`, 0 rows in `route:list` for `SchoolShiftController@create`), `create()` aborts 403, and `grep -rn "timetablefoundation::shift.create"` finds nothing. The live create UI is `_create-modal.blade.php` + `_create-fields.blade.php` (which says it was "lifted verbatim from shift/create.blade.php"). The 89-line `create.blade.php` is dead.

**Clean checks (one line each):**
- All seven crud permission names are seeded in the tenant `sys_permissions` **by exact name** (`viewAny view create update delete restore forceDelete` + `export` — 8/8 EXACT, 0 MISSING).
- View permission props are 4-part names; the search-bar is told `permissions="tenant.timetable-foundation.shift"` and the create modal grants `.create` — the component's `.create`/`.restore` glue matches the seeds.
- No `{!! !!}` on user text anywhere in the six in-scope blades.
- All six blades compile (`compileString()` → `php -l` → OK).
- No query inside a `@foreach`; relations used in the tab list are not lazy-loaded (there are none beyond scalar columns).
- `trashedShift()` uses `paginate(10)` with `onlyTrashed()`.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`SchoolShift` usage by other controllers (model owned here, §5):** 6 controllers + 2 models read it — `PeriodConfigController:107`, `PeriodSetController:219`, `TimetableFoundationController:85,453,560,566`, `TimetableTypeController:39,285`, `SmartTimetableController:78,1137`, `TimetablePageController`, `EmployeeProfileController`, `TeacherAvailability`, `TimetableType`. All read paths are `SchoolShift::where('is_active', true)` dropdown/paginator loads; none writes. The `timetableTypes()` relation resolves on this tenant (`tt count=4`).
- **`SchoolShiftPolicy` is registered but unreachable (module-wide pattern):** `TimetableFoundationServiceProvider.php:136` calls `Gate::policy(SchoolShift::class, SchoolShiftPolicy::class)`, but every gate in the controller passes a permission **string**, so the policy is never consulted. Same family as the module note in AcademicTerm ATC-14 — needs a module-level decision.
- **Timetable masters page:** the `_list.blade.php` shifts tab is fed by `TimetableFoundationController::timetableMasters` (paginated 10, `shift_page`, `withQueryString()`), which is that controller's report's scope; this report checked only how the shift rows are rendered.
- **Export:** `x-tenantcore::export-buttons` columns include `default_start_time`/`default_end_time`. Because of SSH-06, the exported "Start Time/End Time" values will carry today's fabricated date until the cast is fixed or a resolver is added in the partial (`_list.blade.php:47-51`).
- **Seeder:** `database/seeders/TimetableMastersCompleteSeeder.php:63` truncates and re-inserts `tt_shifts`; the two live rows came from there on 2026-10-09. Nothing here verifies that seeder (out of scope).

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static or a read-only SQL probe.
- **Other writers of `tt_shifts`:** the masters seeder and `TimetableFoundationController` reads were not audited beyond the drop-down/paginator usage check.
- **The live data dates:** the two existing shifts look seeded correctly; no repair needed.
- **`RouteAuthenticationTest.php:80`** references `timetable-foundation.shift.create` (the route's auth guard expectation). D5's `abort(403)` on `create()` may interact with it; that is for the team to verify (D4).