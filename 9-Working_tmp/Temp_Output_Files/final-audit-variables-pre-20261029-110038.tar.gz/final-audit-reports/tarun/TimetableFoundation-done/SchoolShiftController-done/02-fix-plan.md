# Fix Plan — TimetableFoundation / SchoolShiftController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/SchoolShiftController.php`. It applies **only** ticked items, in this order.

## 1. Blockers reachable today
_None (0 B)._

## 2. Fixes that arm a latent defect (sequenced)
- [x] **SSH-02** · H · deep read · `SchoolShiftController.php:250` — `forceDelete()`:
  - Use `onlyTrashed()->findOrFail($id)` so a live shift can no longer be purged.
  - Before deleting, count children across `tt_period_configs`, `tt_period_sets`, `tt_timetable_types`. If any exist, throw a `\DomainException` naming each blocking table and its count; catch it **only** as `DomainException` and turn it into a flash (ERR-01 comment + `2026-10-10`).

  Order matters: this goes **before** SSH-03's shape change. Effort: S.

## 3. Errors & transactions (F1/F2)
- [x] **SSH-03** · M · ERR-00 (D1) · `SchoolShiftController.php:48-72, 112-137, 153-178, 211-236, 252-272, 290-319` — remove the try/catch from `store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`:
  - Keep the existing `DB::transaction(fn …)` closures.
  - Let the central handler render failures (JSON for the AJAX toggle, redirect/500 for forms).
  - The `\DomainException` catches that SSH-02 adds (and any future business-rule messages) stay narrow per D2.

  This is the same hardening the pre-applied 2026-10-10 pass did to AcademicTerm's `store`/`update`/`destroy`. Effort: M.

## 4. Authorization (F3)
- [x] **SSH-07** · L · AUTH-04 · `SchoolShiftController.php:46, 108` — drop the duplicate `Gate::authorize` in `store`/`update`, keep the FormRequest `authorize()` (it runs first and maps POST→create, PUT/PATCH→update). The unreachable-policy question is module-wide and stays in §7. Effort: S.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **SSH-01** · H · DECISION · RTE-01 · `routes/web.php:165` — Restore runs over GET.
      (a) ⭐ Change it to `Route::patch('/shift/{id}/restore', …)`. The only caller is `action-trashed` (`trash.blade.php:52`), which derives the verb from the route, so no blade edit is needed. ⚠ This changes a route, so it needs explicit approval.
      (b) Leave it as GET and accept the risk.
      ➜ Choice: (a) — PATCH restore (2026-10-12)
- [ ] **SSH-06** _(DEFERRED 2026-10-12 — needs view changes too: edit/show call ->format() on these casts)_ · M · MDL-02 · `SchoolShift.php:36-37` — cast the two `time` columns as strings (or a dedicated time cast) instead of `datetime`, so reads no longer fabricate today's date. No migration needed (column stays `time`). Verify the four views still render `H:i` / `h:i A` and the export partial emits the bare time. Effort: S.

## 6. Queries & performance (F9)
_None._

## 7. Behaviour decisions (F13)
- [x] **SSH-05** · M · DECISION · `SchoolShiftController.php:147-179` — a shift still referenced by 4 timetable types, 4 period sets or 9 period configs can be trashed, leaving those rows pointing at a trashed shift.
      (a) ⭐ Refuse to trash a shift that has children, using the same child counts as SSH-02, with the message "This shift is still used by N period config(s) / period set(s) / timetable type(s)."
      (b) Allow it (trash is reversible), accept the dangling references.
      (c) Add a "children" warning on the trash page but allow the action.
      ➜ Choice: (a) — refuse to trash a shift still in use (2026-10-12)

## 8. Style (F12) — one item per file
- [x] **SSH-08** · L · STY / CTL-04 / CTL-05 · `SchoolShiftController.php` — add `declare(strict_types=1)`, return types on all 11 public methods, and remove the redundant `$validated['is_active'] = $request->boolean('is_active')` lines (`:51, :115`) since `prepareForValidation()` already merges and validates the boolean (keep the merged value from `validated()`). Effort: S.
- [x] **SSH-09** · L · STY-01 · `SchoolShiftRequest.php` — add `declare(strict_types=1)`. Effort: S.
- [x] **SSH-10** · L · STY-01 / MDL-04 · `SchoolShift.php` — add `declare(strict_types=1)` and a `: HasMany` return type on `timetableTypes()`. ⚠ SHARED — 12 files reach this model across modules; the change is declaration-only, no behaviour. Effort: S.
- [x] **SSH-11** · L · STY-01 · `SchoolShiftPolicy.php` — add `declare(strict_types=1)`. Effort: S.

## 8b. Added at fix time
- [x] **SSH-04** · M · CTL-03 — `show`/`edit`/`update`/`destroy` now type-hint `SchoolShift $shift` so the `{shift}` route parameter binds (was missing from this plan; approved 2026-10-12).

## 9. Views (F10)
- [x] **SSH-12** · L · dead view · `views/shift/create.blade.php` — delete it. Before deleting, re-prove `routed=0 refs=0` for `create` at fix time (`Route::has('timetable-foundation.shift.create')` is false and `grep` finds no `timetablefoundation::shift.create`). Effort: S.