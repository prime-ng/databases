# Status — TimetableFoundation / WorkingDayController

**Fixed:** 2026-10-15 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work

From `../PRE-APPLIED-2026-10-10.md`:

| Controller | Pre-applied 2026-10-10 |
|---|---|
| `WorkingDayController` | same as ClassWorkingDay: 7 `throw new \DomainException` across both controllers, 3 narrow catches. Pint applied |

⚠ **On 2026-10-15 that work was no longer in the file.** `addDayTypeToWorkingDay()` threw `\RuntimeException` again, and `ajaxStore`/`ajaxEdit` caught `\RuntimeException`. That is the catch D2 forbids, because `QueryException` extends it. This pass put the D2 shape back: every business refusal throws `\DomainException`, and the only two catches left catch `\DomainException` only, each with the "do NOT widen" comment. Who reverted it is not known; the editor-overwrite hazard is the likely cause.

## 2. Applied

Paths: `C` = `Modules/TimetableFoundation/app/Http/Controllers/WorkingDayController.php`; `B` = `Modules/TimetableFoundation/resources/views/pages/partials/timetable-masters/working-days/_list.blade.php`.

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| WDY-01 (a) | `routes/web.php` working-day block; `C:53,87,96` | `Route::resource('working-day', …)->except(['create','show','edit'])`. The three methods are now `: never { abort(403, …) }` with a NOT ROUTED docblock. No views were created | router probe over `timetable-foundation.working-day.*` | 11 routes, no `create`/`show`/`edit`, every action's method exists | 2026-10-15 |
| WDY-02 (b) | `C:503-505`; `B` remark popup | Rule `max:500` → `max:255`. Textarea `maxlength="255"`, hint text "Max 255 characters". No migration — the DDL and the live column are both `varchar(255)` | `grep -n "max:255" C`; `grep -n 'maxlength="255"' B` | 1 / 1 | 2026-10-15 |
| WDY-12 (a) | `C` `ajaxInitializeWorkingDays` | Auto-Fill now sets `day_type1_id` and nulls `day_type2_id`/`day_type3_id`/`day_type4_id` on every existing row it re-fills. ⚠ This changes data: a re-filled date loses any stacked types | read of the `$existing->update([...])` block | four slot keys present | 2026-10-15 |
| WDY-03 | `C` `store`/`update` | Validation moved out of the controller into `WorkingDayRequest`. It now fails before the controller runs, so a field error is no longer swallowed | `grep -c "validate(\[" C` | 2 (only `eventFeed` and `ajaxUpdateRemark`, both outside any try) | 2026-10-15 |
| WDY-05 | `C` `store`, `update`, `destroy`, `ajaxUpdateRemark`, `ajaxDestroy`, `ajaxInitializeWorkingDays`, `ajaxClearWorkingDays` | Removed the controller `try/catch`. Writes run in `DB::transaction(fn …)`; the central handler renders errors (JSON for the calendar's `fetch`, which sends `Accept: application/json`) | `grep -n "try {\|catch" C` | 2 `try`, 2 `catch (\DomainException`, nothing else | 2026-10-15 |
| WDY-05 / D2 | `C` `addDayTypeToWorkingDay`, `ajaxEdit` | Business refusals throw `\DomainException` again (6 throws), caught only in `ajaxStore` (per-date partial success) and `ajaxEdit` (422). See §1 | `grep -n "DomainException\|RuntimeException(" C` | 6 throws, 2 catches, 0 `RuntimeException(` | 2026-10-15 |
| WDY-06 | `C` | Every `Log::error(… $e->getMessage())` line removed, and the `Log` import with it | `grep -c "Log::" C` | 0 | 2026-10-15 |
| WDY-07 | `C` `store`/`update`/`destroy` | The transaction closure only writes and logs; the redirect and `with('success', …)` are built after it returns | read | — | 2026-10-15 |
| WDY-08 | `C` `ajaxUpdateRemark`, `ajaxDestroy`, `ajaxInitializeWorkingDays`, `ajaxClearWorkingDays` | `Gate::authorize` is the first statement. There is no surrounding `try`, so the check cannot be caught | `grep -c "Gate::authorize" C` | 11 (index, store, update, destroy, eventFeed, 6 ajax) | 2026-10-15 |
| WDY-09 | new `app/Http/Requests/WorkingDayRequest.php`, `app/Http/Requests/WorkingDayCalendarRequest.php` | `WorkingDayRequest` covers store/update and checks `.create`/`.update` via `authorizeByCrudPermission`. `WorkingDayCalendarRequest` covers `ajaxStore` (`.create`) and `ajaxEdit` (`.update`), branching on route name. `ajaxUpdateRemark` keeps its single-field inline rule | `class_exists` | OK / OK | 2026-10-15 |
| WDY-10 | `WorkingDayRequest::rules()` | `date` gets `Rule::unique('tt_working_days','date')->ignore($workingDay?->id)`. That mirrors `uq_workday_date`, and because `Rule::unique` adds no `deleted_at` filter, a trashed date is a field error instead of SQL 1062 | `SHOW INDEX` | `uq_workday_date (date)` | 2026-10-15 |
| WDY-11 | `C` `update` | Plan said WDY-01(a) resolves this. It does not fully: only create/show/edit were removed, and store/update/destroy are still routed. So `update()` now nulls slots 2-4, keeping the row single-slot like the revive paths. Mutual-exclusion and locking are not needed on that path: it writes exactly one type | read | — | 2026-10-15 |
| WDY-19 | `C` `eventFeed` | `start`/`end` validated `required|date` → 422 on a malformed range. The plan said `nullable`; `required` matches its stated goal ("422, not an empty feed"), and FullCalendar always sends both | read | — | 2026-10-15 |
| WDY-04 | `C` `ajaxInitializeWorkingDays`, `ajaxStore`, `addDayTypeToWorkingDay` | Auto-Fill loads the session's rows once (`withTrashed()`, keyed by `Y-m-d`), after the optional clear, instead of one SELECT per day. `ajaxStore` loads the day types once and passes them to `addDayTypeToWorkingDay()` (new optional `?Collection $typesById`). The per-date transaction in `ajaxStore` is kept on purpose (partial success) | read | — | 2026-10-15 |
| WDY-13 | `B` `eventClick` | The remark and the event title are HTML-escaped (`wdEsc`) before reaching SweetAlert's `html`. The remark goes into the textarea as `.value` in `didOpen`, so it is never concatenated into markup | `grep -n "wdEsc\|ta.value = currentRemark" B` | 3 + 1 | 2026-10-15 |
| WDY-16 | `B:26-30` | `$dtColors` now reads `WorkingDayController::DAY_TYPE_COLORS`; the copied array is gone | `grep -n DAY_TYPE_COLORS B` | 1 | 2026-10-15 |
| WDY-18a | `C` | `declare(strict_types=1)`; return types on all 14 public methods (`RedirectResponse`, `JsonResponse`, `never`); the `⚠` emoji removed from the palette docblock | `grep -c "⚠" C` | 0 | 2026-10-15 |
| WDY-18b ⚠ SHARED | `app/Models/WorkingDay.php` | `declare(strict_types=1)`; `: BelongsTo` on `dayType`…`dayType4`; the duplicate docblock merged into one. Type hints and comments only | `php -l`, `class_exists` | OK | 2026-10-15 |
| WDY-18c | `app/Policies/WorkingDayPolicy.php` | `declare(strict_types=1)` | `php -l` | OK | 2026-10-15 |

## 3. Not applied

| ID | Reason | Detail |
|---|---|---|
| WDY-14 | Decided (a): defer to the split pass (D3) | Lengths after this pass: `ajaxStore` ~118, `ajaxEdit` ~142, `ajaxDestroy` ~83, `ajaxInitializeWorkingDays` ~120 lines |
| WDY-15 | Decided (a): defer to the split pass (D3) | `addDayTypeToWorkingDay`/`removeSlotAndCompact` stay in the controller |
| WDY-17 | Record only (plan) | `WorkingDayPolicy` is registered and never consulted; gates pass strings. This is a module-wide decision |

## 4. Needs Tarun's hand

- **One test now names a route that no longer exists.** `Modules/TimetableFoundation/tests/Feature/RouteAuthenticationTest.php:84` lists `timetable-foundation.working-day.create`. The route was removed by WDY-01, so that data-set case will fail. Per D4 the test was not edited. Fix: delete that one line.
- **Browser check** of `/timetable-foundation/timetable-masters?tab=working-days`:
  - open an event: the remark shows in the textarea, the 255-character cap applies, save works;
  - drag a holiday onto a working date: the conflict message still shows;
  - run Auto-Fill on a date that has stacked types: they are cleared to one type.
- No migration, no seeder, no permission sync.

## 5. Unverifiable by this workflow (no tests, D4)

- A non-super-admin being refused by `WorkingDayRequest` / `WorkingDayCalendarRequest` `authorize()`. Every static check runs as code, not as a role.
- That the central handler returns a JSON body the calendar's error toast can read, for a database error on an AJAX write. The JS falls back to `data.message`.

## 6. Verification log

```
$ vendor/bin/pint <6 touched php files> --format agent
{"result":"fixed","files":[{"path":"Modules/TimetableFoundation/app/Models/WorkingDay.php","fixers":["class_attributes_separation","single_line_after_imports"]}]}

$ php -l (all touched files, after Pint)          → no syntax errors
$ class_exists                                      → WorkingDayController OK · WorkingDayRequest OK
                                                      WorkingDayCalendarRequest OK · WorkingDay OK · WorkingDayPolicy OK
$ php artisan route:clear; router probe timetable-foundation.working-day.*
  ajaxStore POST ok · ajaxEdit POST ok · ajaxUpdateRemark POST ok · ajaxDestroy DELETE ok
  ajaxInitializeWorkingDays POST ok · ajaxClearWorkingDays DELETE ok · eventFeed GET ok
  index GET ok · store POST ok · update PUT|PATCH ok · destroy DELETE ok      (no create/show/edit)
$ blade compileString(_list.blade.php) → php -l    → no syntax errors; @push src=0, startPush out=0
$ grep -c '{{--' / '--}}' _list.blade.php          → 4 / 4
$ grep -n "try {\|catch" WorkingDayController.php  → 249 try, 309 catch (\DomainException), 372 try, 468 catch (\DomainException)
$ grep -c "Log::" WorkingDayController.php          → 0
```

## 7. Final state

Status: FIXED · Open: B 0 · H 0 · M 2 (WDY-14, WDY-15 — deferred to the split pass) · L 1 (WDY-17 — record only)
