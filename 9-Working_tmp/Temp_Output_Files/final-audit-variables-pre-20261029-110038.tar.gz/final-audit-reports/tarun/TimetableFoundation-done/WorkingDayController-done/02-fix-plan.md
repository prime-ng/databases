# Fix Plan — TimetableFoundation / WorkingDayController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick. `"tick all"` does not cover it.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/WorkingDayController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
- [x] **WDY-01** · H · DECISION · RTE-03/VIEW · `WorkingDayController.php:39,92,104` + `routes/web.php:201` — `create`, `show` and `edit` render views that do not exist (`view()->exists()` → NO), so each is a 500.
      (a) ⭐ Match the module's own `school-day` treatment (`routes/web.php:150-154`): add `->except(['create','show','edit'])` to `Route::resource('working-day', …)`, and make the three method bodies `abort(403)` with a `// NOT ROUTED — the calendar has no resource pages` comment (D5 spirit). No view files are created. ⚠ This changes routes (a route file), so it needs explicit approval.
      (b) Create the three missing blades and keep the resource CRUD live (larger; the calendar links to none of them, so the pages would be orphaned).
      (c) Leave all three as-is and accept the 500s.
      ➜ Choice: (a) — Tarun 2026-10-15
- [x] **WDY-02** · H · DECISION · VAL-04 · `WorkingDayController.php:538-545` + migration (new) — the remark field allows 500 characters but `remarks` is `varchar(255)`; a 256–500 char note throws SQL 1406 and is lost.
      (a) ⭐ New additive migration widening `tt_working_days.remarks` to `varchar(500)` (matching the UI), keeping the `max:500` rule. The migration is written, never run — you run `php artisan tenants:migrate`.
      (b) App-only: lower the controller rule to `max:255` and the blade `maxlength` to `255`. No migration; the UI stops inviting 500.
      (c) Both.
      ➜ Choice: (b) — Tarun 2026-10-15

## 2. Fixes that arm a latent defect (sequenced)
- [x] **WDY-12** · M · DECISION · deep read · `WorkingDayController.php:864-869` — "Auto-Fill Year" overwrites `day_type1_id` but leaves `day_type2-4`, so a stacked row can end up with a holiday type beside a working type.
      (a) ⭐ On re-initialize, reset all four slots: set `day_type1_id` and null `day_type2_id`/`day_type3_id`/`day_type4_id`, matching the `ajaxStore`/`ajaxEdit` revive path (`:285-293`, `:455-463`). This changes existing data for re-filled dates.
      (b) Refuse (skip + report) any date that already has more than one slot, leaving the user to clear it first.
      (c) Leave as-is and document that Auto-Fill assumes a single-slot calendar.
      ➜ Choice: (a) — Tarun 2026-10-15

## 3. Errors & transactions (F1/F2)
- [x] **WDY-03** · H · ERR-02 · `WorkingDayController.php:49-80, 114-144` — move `$request->validate()` **before** the `try` in `store` and `update` so a `ValidationException` is never swallowed; the generic catch then stays the last branch.
- [x] **WDY-05** · M · ERR-00 (D1) · `WorkingDayController.php:49-80, 114-144, 154-175, 528-570, 579-673, 795-909, 917-966` — remove the controller `try/catch` from `store`, `update`, `destroy`, `ajaxUpdateRemark`, `ajaxDestroy`, `ajaxInitializeWorkingDays`, `ajaxClearWorkingDays`:
  - **Shape:** use the same `return DB::transaction(fn …)` shape already applied to `ajaxStore`/`ajaxEdit` (the 2026-10-10 pass), and let the central handler in `bootstrap/app.php` render errors (JSON for the AJAX endpoints).
  - **Keep:** the deliberate `\DomainException` catches and the `// do NOT widen to RuntimeException` comment in `ajaxStore`/`ajaxEdit` (D2). Do not add any new catch.
- [x] **WDY-06** · M · ERR-05 · `WorkingDayController.php:77,141,172,564,667,903,960` — delete these `Log::error(… ['error' => $e->getMessage()])` lines. They disappear with WDY-05; if any survive, replace with `report($e)` (never the bare message).
- [x] **WDY-07** · M · TXN-05 · `WorkingDayController.php:67-69, 131-133, 162-164` — each closure returns the model; build the redirect and `with('success', …)` **after** the transaction returns.

## 4. Authorization (F3)
- [x] **WDY-08** · M · AUTH-02 · `WorkingDayController.php:528, 579, 795, 917` — move each `Gate::authorize(...)` **above** its `try` block so authorization can never be caught by the method's error handling.
- [x] **WDY-17** · L · AUTH-04/AUTH-06 · `Modules/TimetableFoundation/app/Policies/WorkingDayPolicy.php` — the policy is registered (`TimetableFoundationServiceProvider.php:142`) but never consulted; gates pass strings. The unreachable-policy fix is **module-wide**, so it is not applied here. Record only. Effort: —.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **WDY-09** · M · VAL-02 · `WorkingDayController.php` + new `app/Http/Requests/WorkingDayRequest.php` — extract the duplicated `store`/`update` rules into a FormRequest; keep `ajaxStore`/`ajaxEdit`/`ajaxUpdateRemark` inline only if they stay one-field toggles (they do not — extract their shared rules too). Effort: S.
- [x] **WDY-10** · M · VAL-04 · `WorkingDayController.php:61` — make `store()` soft-delete-aware: either add a `unique:tt_working_days,date` rule that also sees trashed rows, or `withTrashed()->where('date', …)->first()` + restore. No migration. Effort: S.
- [x] **WDY-19** · L · VAL-05 · `WorkingDayController.php:206-207` — give `eventFeed` a `$request->validate(['start' => ['nullable','date'], 'end' => ['nullable','date']])` so a malformed range returns 422, not an empty feed. Effort: S.
- [x] **WDY-11** · M · deep read — the resource `store`/`update`/`destroy` duplicate the AJAX paths with weaker rules (no mutual-exclusion check, no `lockForUpdate`, `update` leaves `day_type2-4`). **Resolved by WDY-01(a)** (disable the resource routes) — no separate edit. If WDY-01(b) is chosen instead, this must be fixed: route the resource methods through `addDayTypeToWorkingDay()`/`removeSlotAndCompact()` and add the lock. Effort: S/—.
- [x] **WDY-18b** · L · STY/MDL · `Modules/TimetableFoundation/app/Models/WorkingDay.php` — `declare(strict_types=1)`; add `: BelongsTo` return types on `dayType`/`dayType2`/`dayType3`/`dayType4`; delete the duplicate docblock at `:63-65`. ⚠ SHARED — many files reach this model; the change is comment, type-hint and `strict_types` only. Effort: S.

## 6. Queries & performance (F9)
- [x] **WDY-04** · H · QRY-01 · `WorkingDayController.php:852-880` — pre-load the session's rows once (`WorkingDay::withTrashed()->whereBetween('date', …)->get()->keyBy(fn($r) => $r->date->format('Y-m-d'))`) and use the keyed collection inside the date loop, instead of one `withTrashed()->where('date', …)->first()` per day. Do **not** hoist `ajaxStore`'s per-date transaction (partial success is intentional); only remove the repeated `DayType` lookups in `addDayTypeToWorkingDay` (`:737`) by resolving the slot types once per call. Effort: M.

## 7. Views (F10)
- [x] **WDY-13** · M · VIEW-03 · `resources/views/pages/partials/timetable-masters/working-days/_list.blade.php:248,257` — escape the remark before it reaches `html:` (e.g. build the textarea with `document.getElementById(...).value = currentRemark`, or HTML-escape the string), so a saved remark cannot inject markup or break out of the `<textarea>`. Effort: S.
- [x] **WDY-16** · L · CTL-05 · `…/working-days/_list.blade.php:27-31` — replace the duplicated `$dtColors` array with the single source: `@php $dtColors = \Modules\TimetableFoundation\Http\Controllers\WorkingDayController::DAY_TYPE_COLORS; @endphp`. Effort: S.

## 8. Style (F12) — one item per file
- [x] **WDY-18a** · L · STY · `WorkingDayController.php` — add `declare(strict_types=1)`, return types on all 14 public methods, and remove the `⚠` emoji from the comment at `:188`. Effort: S.
- [x] **WDY-18c** · L · STY · `app/Policies/WorkingDayPolicy.php` — add `declare(strict_types=1)`. Effort: S.

## 9. Deferred / decisions
- [x] **WDY-15** · M · DECISION · CTL-06 (D3) — business rules (`addDayTypeToWorkingDay`, `removeSlotAndCompact`) live in the controller.
      (a) ⭐ Defer the extraction to a `WorkingDayService`/action to the split pass (D3); the controller stays as-is for now.
      (b) Extract a service now and have `ajaxStore`/`ajaxEdit` (and the resource path if kept) call it.
      (c) Leave as-is and record as accepted.
      ➜ Choice: (a) — Tarun 2026-10-15
- [x] **WDY-14** · M · DECISION · CTL-02 (D3) — four methods exceed 80 lines (`ajaxStore` 112, `ajaxEdit` 149, `ajaxDestroy` 98, `ajaxInitializeWorkingDays` 118).
      (a) ⭐ Defer to the split pass (D3); record the lengths.
      (b) Extract the per-branch write logic into private helpers now.
      (c) Leave as-is, accepted.
      ➜ Choice: (a) — Tarun 2026-10-15

---

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item you want applied.
> 2. Fill every `➜ Choice:` on a ticked **DECISION** item (WDY-01, WDY-02, WDY-12, WDY-15, WDY-14). The fixer refuses to start if one is empty.
> 3. Tick the `⚠ SHARED` items explicitly (this plan: WDY-18b; WDY-01 if it changes `routes/web.php`).
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/WorkingDayController.php` — it applies only ticked items, in this order.
> 5. ⚠ New migrations are **written, not run**. After the fixer, run `php artisan tenants:migrate` yourself.
