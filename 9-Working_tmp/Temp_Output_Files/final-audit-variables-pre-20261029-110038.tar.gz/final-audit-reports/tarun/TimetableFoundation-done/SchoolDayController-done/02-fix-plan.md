# Fix Plan — TimetableFoundation / SchoolDayController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/SchoolDayController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
_None (0 B)._

## 2. Fixes that arm a latent defect (sequenced)
- [x] **SDY-12** · H · deep read · `SchoolDayController.php:328` — `forceDelete()`:
  - Change `SchoolDay::withTrashed()->findOrFail($id)` to `SchoolDay::onlyTrashed()->findOrFail($id)` so a live day can no longer be permanently destroyed.
  - No child guard is needed: `information_schema` shows **0** FK constraints referencing `tt_school_days`. Correct the stale "NOTE: … has no inbound FK references" comment only if it is inaccurate (it is accurate).

  Effort: S.

## 3. Errors & transactions (F1/F2)
- [x] **SDY-01** · M · ERR-00 (D1) / ERR-05 · `SchoolDayController.php:78-118, 175-221, 246-279, 327-357, 382-416, 446-478` — remove the `try/catch` from the six mutating methods:
  - **Shape:** use `return DB::transaction(fn …)` for `store` (keep its return), and for `update`/`destroy`/`forceDelete`/`restore`/`toggleStatus` either `return DB::transaction(...)` or a bare `DB::transaction(...)`; the central handler renders the error.
  - **Keep** `findOrFail` of `update`/`destroy`/`forceDelete`/`restore` — but when SDY-07 lands, the binding produces the 404 *before* the method body, so the `catch (ModelNotFoundException) { throw }` blocks are deleted, not translated.
  - **`toggleStatus`** keeps its JSON contract. Under D1 the central handler already returns JSON `{message}` for `expectsJson()` callers; do **not** re-add a catch.
  - No `$e->getMessage()` is currently user-facing, so nothing else changes in the messages.

  Effort: M.

## 4. Authorization (F3)
- [x] **SDY-02** · L · AUTH-04 · `SchoolDayController.php:76, 173` and `SchoolDayRequest.php:65-71` — stop authorizing twice: keep the FormRequest's `authorize()` (it runs first) and drop the controller `Gate::authorize` in `store`/`update`, or the reverse. Keep exactly one per concern. Effort: S.
- [x] **SDY-03** · L · DECISION · AUTH / dead policy — `DayPolicy.php` (whole class), registered at `TimetableFoundationServiceProvider.php:135` but never consulted because every gate passes a permission string.
      (a) ⭐ Defer to a module-wide decision (the same is true of all 21 policies in `TimetableFoundationServiceProvider.php:122-142`). Change nothing here.
      (b) Remove the `Gate::policy(SchoolDay::class, DayPolicy::class)` registration and delete `DayPolicy.php`.
      (c) Convert this controller's gates to model-based (`$this->authorize('view', $schoolDay)`), which would start consulting the policy.
      ➜ Choice: (a) defer to the module-wide policy decision — Tarun, 2026-10-14

## 5. Validation, routes, models (F4/F5/F7)
- [x] **SDY-04** · M · DECISION · VAL-04 / BUG-003 · `SchoolDayRequest.php:107, 123` — the validator excludes trashed rows but `uq_schoolday_code` / `uq_schoolday_dow` are not soft-delete aware, so re-creating a trashed `code`/`day_of_week` raises 1062 → 500 (latent, 0 trashed today).
      (a) ⭐ Validator also checks trashed rows with the message "A trashed school day already uses this code/day — restore it instead." No migration.
      (b) A new additive migration replaces the two uniques with soft-delete-aware generated-column uniques.
      (c) Leave as is; accept the latent 500.
      ➜ Choice: (a) validator also refuses a code/weekday held by a trashed row — Tarun, 2026-10-14
- [x] **SDY-05** · M · VAL-05 / DDL-drift · `SchoolDayRequest.php:125-128, 134` —
  - add `max:255` to `ordinal` (the column is `tinyint unsigned`; STRICT mode turns 256 into MySQL 1264 → 500);
  - add the `boolean` rule to `is_active` on both paths (`['required','boolean']` / `['nullable','boolean']`) so the field is typed; `$request->boolean()` stays.

  Effort: S.
- [x] **SDY-06** · H · DECISION · RTE-01 · `routes/web.php:156` ⚠ SHARED — Restore runs over a GET request.
      (a) ⭐ Change it to `Route::patch`. `<x-backend.table.action-trashed>` (the only caller, `trash.blade.php:41`) derives the verb from the route, so no blade edit is needed.
      (b) Leave it as GET and accept the CSRF/prefetch risk.
      ➜ Choice: (a) Route::patch; test_25 (GET → 404) needs updating — Tarun, 2026-10-14
- [x] **SDY-07** · M · CTL-03 · `SchoolDayController.php:129, 145, 171, 242, 323, 378` — use route model binding: `show(SchoolDay $schoolDay)`, `edit(SchoolDay $schoolDay)`, `update(SchoolDayRequest $request, SchoolDay $schoolDay)`, `destroy(SchoolDay $schoolDay)`, `forceDelete(SchoolDay $schoolDay)` (`withTrashed()` via `->withTrashed()` on the route or `onlyTrashed` in-method), `restore(SchoolDay $schoolDay)`.
  - ⚠ The route parameter is `{school_day}` (snake); the bound argument is `$schoolDay`. Laravel binds by parameter name, so either rename the route parameter to `{schoolDay}` **or** bind explicitly. Confirm with `route:list` + a `method_exists` check after the change. Do **not** change the URL or route names.

  Effort: M.

## 6. Queries & performance (F9)
_None._

## 7. Views (F10)
- [x] **SDY-09** · L · VIEW · `Modules/TimetableFoundation/resources/views/school-day/show.blade.php:12` — change the Back link's `['tab' => 'school-day']` to `['tab' => 'school-days']` so Back lands on the School Days tab. Effort: S.
- [x] **SDY-10** · L · DECISION · orphan views — `views/school-day/create.blade.php` (104 lines) and `views/school-day/index.blade.php` (48 lines) are unreachable (create route retired, `index()` redirects).
      (a) ⭐ Delete both blades. Before deleting, re-prove `routed=0 refs=0` for `timetablefoundation::school-day.create` and `…index` at fix time.
      (b) Leave both in place; record as accepted debt.
      ➜ Choice: (a) delete both blades — Tarun, 2026-10-14

## 8. Style (F12) — one item per file
- [x] **SDY-08** · L · CTL-04 · `SchoolDayController.php` (11 methods) — add return types (`: RedirectResponse`, `: View`, `: JsonResponse`, `: never` for `create`). Effort: S.
- [x] **SDY-11a** · L · STY-01/02 · `SchoolDayController.php` — add `declare(strict_types=1)` and run Pint (`blank_line_before_statement`). Effort: S.
- [x] **SDY-11b** · L · STY-01/02 · `SchoolDayRequest.php` — add `declare(strict_types=1)` and run Pint (`fully_qualified_strict_types`, `ordered_imports`). Effort: S.
- [x] **SDY-11c** · L · STY-01 · `SchoolDay.php` — add `declare(strict_types=1)`. ⚠ SHARED — the model is pre-assigned to this report; the change is one line. Effort: S.
- [x] **SDY-11d** · L · STY-01 · `DayPolicy.php` — add `declare(strict_types=1)` (only if SDY-03 leaves the file in place). Effort: S.

## 9. Deferred / decisions
- [x] **SDY-13** · L · DECISION · deep read · `SchoolDayController.php:448, 475` — a failed toggle echoes the requested `is_active` with `success:false`.
      (a) ⭐ Leave the payload as is; the front-end keys off `success`. Record as accepted.
      (b) Re-read the persisted value before building the failure payload (`$schoolDay->refresh()`), at the cost of one query on the error path.
      ➜ Choice: (a) accepted as is — Tarun, 2026-10-14
- [x] **SDY-CTL01-DEFERRED** · — · CTL-01 — no god-controller split needed (480 lines, 11 methods, all under the 1,000-line / 25-method threshold). Recorded only to close the family.

---

> **How to approve**
> 1. Tick `[x]` on each item you want applied.
> 2. Fill every `➜ Choice:` on a ticked DECISION item.
> 3. Tick `⚠ SHARED` items explicitly (`SDY-06` route file, `SDY-11c` shared model) — "tick all" does not cover them.
> 4. Then run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/SchoolDayController.php`.
