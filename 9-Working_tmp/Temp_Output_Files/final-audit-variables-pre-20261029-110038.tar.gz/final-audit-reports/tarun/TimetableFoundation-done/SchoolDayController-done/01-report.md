# Final Audit — TimetableFoundation / SchoolDayController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/SchoolDayController.php` (480 lines, 11 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 2 HIGH.**

The write paths are individually sound: every mutating method wraps its row write and its `activityLog` row in one `DB::transaction`, and no exception text reaches the user (ERR-01 clean). But two HIGH defects are reachable, and the controller is 6 working days away from the D1 error model the rest of the module already follows:

- **Delete Permanently works on a live day.** `forceDelete()` uses `withTrashed()`, so a DELETE to `/school-day/{id}/force-delete` skips the trash and destroys an active row. (SDY-12)
- **Restore runs over a GET request.** A link prefetcher or preview can restore a day with no CSRF. (SDY-06)

The worst of these is **SDY-12**, because it is irreversible data loss on a non-trashed record. The effort is roughly half a day of code plus two decisions (route verb, and the soft-delete unique gap). Three DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 2 | 4 | 6 | 3 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | SDY-01 | F8 Services/Jobs | clean: no service, no job, no event (`grep -R "Service\|dispatch\|ShouldQueue" Module` → none) |
| F2 Transactions/Audit | clean: all 6 mutating methods wrap write + `activityLog` in one `DB::transaction`, log after the write | F9 Queries/Perf | clean: trash paginates 10, all other reads are single-row `findOrFail` |
| F3 Authorization | SDY-02, SDY-03 | F10 Views | SDY-09, SDY-10 |
| F4 Validation | SDY-04, SDY-05 | F11 Security/Tenancy | clean: no `env()`, no raw JSON, no cache, tenant middleware present |
| F5 Routes | SDY-06 | F12 Style | SDY-11 |
| F6 Controller shape | SDY-07, SDY-08 | F13 Deep read | SDY-12, SDY-13 |
| F7 Models | clean: `$fillable` sane, `$casts` complete, `$table` exists, `SoftDeletes` matches `deleted_at` | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/SchoolDayController.php` | controller | 480 | this report | ✅ whole class |
| 2 | `app/Http/Requests/SchoolDayRequest.php` | FormRequest | 156 | this report | ✅ whole class |
| 3 | `app/Models/SchoolDay.php` | model | 103 | this report (pre-assigned) | ✅ |
| 4 | `app/Policies/DayPolicy.php` | policy | 49 | **this report (claimed below)** | ✅ — unreachable, see SDY-03 |
| 5 | `routes/web.php` lines 153-158 | routes | — | this report | ✅ |
| 6 | `views/school-day/show.blade.php` | page | 65 | this report | ✅ |
| 7 | `views/school-day/edit.blade.php` | page | 102 | this report | ✅ |
| 8 | `views/school-day/trash.blade.php` | page | 68 | this report | ✅ |
| 9 | `views/pages/partials/timetable-masters/school-days/_list.blade.php` | tab list | 93 | this report | ✅ |
| 10 | `views/school-day/_create-modal.blade.php` | modal | 22 | this report | ✅ |
| 11 | `views/school-day/_create-fields.blade.php` | fields partial | 91 | this report | ✅ |
| 12 | `views/school-day/create.blade.php` | page (legacy) | 104 | this report | ✅ — orphan, SDY-10 |
| 13 | `views/school-day/index.blade.php` | page (legacy) | 48 | this report | ✅ — orphan, SDY-10 |
| — | `BaseModel`, `AuthorizesTenantFeature`, `activityLog()`, `flash()`, `x-backend.*` components | framework / agent glue | — | common | referenced only; §7 |
| — | `TimetableFoundationController::timetableMasters` | controller (other) | — | another report | loads the `$schoolDays` list; not audited here (§8) |
| — | `SmartTimetable/.../partials/school-days/_list.blade.php` | blade (other module) | 226 | common (other module) | cross-cutting note, §7 |

**Pre-applied 2026-10-10:** this controller is **not** listed in `../PRE-APPLIED-2026-10-10.md`. No file in scope was touched by that pass. (Its siblings `TimetableFoundationController` and `WorkingDayController` were; neither is in this scope.)

## 4. Routes

Uncached (`APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json`), filtered for `SchoolDayController@`:

```
GET|HEAD  timetable-foundation/school-day                                 timetable-foundation.school-day.index        index
POST      timetable-foundation/school-day                                 timetable-foundation.school-day.store        store
GET|HEAD  timetable-foundation/school-day/trash/view                      timetable-foundation.school-day.trashed      trashedDay
DELETE    timetable-foundation/school-day/{id}/force-delete               timetable-foundation.school-day.forceDelete  forceDelete
GET|HEAD  timetable-foundation/school-day/{id}/restore                    timetable-foundation.school-day.restore      restore   ← GET
POST      timetable-foundation/school-day/{schoolDay}/toggle-status       timetable-foundation.school-day.toggleStatus toggleStatus
GET|HEAD  timetable-foundation/school-day/{school_day}                    timetable-foundation.school-day.show         show
PUT|PATCH timetable-foundation/school-day/{school_day}                    timetable-foundation.school-day.update       update
DELETE    timetable-foundation/school-day/{school_day}                    timetable-foundation.school-day.destroy      destroy
GET|HEAD  timetable-foundation/school-day/{school_day}/edit               timetable-foundation.school-day.edit         edit
```

**Middleware on every route:** `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`. Tenant middleware present — RTE-05 ✅.

**Unrouted public method:** `create` (line 43). Its body is already `abort(403, …)` under a `// NOT ROUTED — TM-05` comment, and `routes/web.php:154` excludes the verb. This follows D5 — not a finding.

**Route-parameter inconsistency:** the resource routes use `{school_day}` (snake) while `toggleStatus` uses `{schoolDay}` (camel). Both resolve — the resource methods take `$id` positionally, and `toggleStatus` binds the model — but the two spellings are a style inconsistency (folded into SDY-07/SDY-11).

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect to masters tab) | — |
| create | ❌ (D5 abort 403) | none reached | — | — | — | — |
| store | ✅ | create (+ request) | ✅ closure | `Stored` | tt_school_days, sys_activity_logs | SDY-01, SDY-02 |
| show | ✅ | view | — | — | — | SDY-07 |
| edit | ✅ | update | — | — | — | SDY-07 |
| update | ✅ | update (+ request) | ✅ closure | `Updated` | tt_school_days, sys_activity_logs | SDY-01, SDY-02, SDY-07 |
| destroy | ✅ | delete | ✅ closure | `Trashed` | tt_school_days, sys_activity_logs | SDY-01, SDY-07 |
| trashedDay | ✅ | restore | — | — | — | — |
| forceDelete | ✅ | forceDelete | ✅ closure | `Deleted` | tt_school_days, sys_activity_logs | SDY-01, SDY-07, SDY-12 |
| restore | ✅ | restore | ✅ closure | `Restored` | tt_school_days, sys_activity_logs | SDY-01, SDY-06, SDY-07 |
| toggleStatus | ✅ | update | ✅ closure | `Toggled` | tt_school_days, sys_activity_logs | SDY-01, SDY-13 |

**Tables each mutation SHOULD touch:** every row write is one `tt_school_days` row plus one `sys_activity_logs` row (multi-table → transaction required). `destroy` writes the row twice (deactivate `save()` then `delete()`), still one table. No FK children exist (measured: 0 constraints reference `tt_school_days`), so no cascade table is expected. All six methods do exactly this, each inside one transaction.

## 6. Findings

### F1 — Errors
#### SDY-01 · M · ERR-00 (D1) + ERR-05 — six mutating methods still catch errors themselves and log only the message
**Where:** `store:78-118` · `update:175-221` · `destroy:246-279` · `forceDelete:327-357` · `restore:382-416` · `toggleStatus:446-478`
```php
// store:109-113 (the same shape repeats in the other five)
} catch (\Throwable $e) {
    Log::error('SchoolDay store failed', [
        'error' => $e->getMessage(),
        'code' => $request->input('code'),
    ]);
```
**Evidence:** `grep -c 'catch (' SchoolDayController.php` → 12 (six `catch (\Throwable)`, plus three `catch (ModelNotFoundException)` re-throws in update/destroy/forceDelete/restore). `php ../.../scan.php` → ERR-05 at lines 110, 213, 272, 349, 408, 468.
**Consequence:** the stack trace is lost (ERR-05 — `getMessage()` alone drops the frame), and the controller uses two error models while the rest of the module uses the D1 idiom. Note: **no** `$e->getMessage()` reaches the user — every failure flash is a fixed key (`flash('operation_failed.school_day')`, `flash('status_switch_failed.school_day')`), so ERR-01 is clean.

### F2 — Transactions/Audit
clean — every mutating method wraps its write and its `activityLog` in one `DB::transaction` closure, with `activityLog` placed **after** the write and inside the transaction (grep `DB::transaction` → 6, `activityLog(` → 6, all 6 within a closure). No mail/file/HTTP inside a transaction (TXN-03 ✅); no check-then-act race (TXN-06 ✅ — the uniques `uq_schoolday_code` / `uq_schoolday_dow` exist).

### F3 — Authorization
#### SDY-02 · L · AUTH-04 — every `store`/`update` is authorized twice
**Where:** `SchoolDayRequest.php:65-71` (`authorize()` → `authorizeByCrudPermission('tenant.timetable-foundation.school-day')`) · controller `:76`, `:173`
**Evidence:** the FormRequest maps POST→`create`, PUT/PATCH→`update` and calls `Gate::allows(...)`; the controller then calls `Gate::authorize('…school-day.create')` (store) / `'…school-day.update'` (update) on the same permission. `scan.php` → AUTH-04 at lines 74 and 171.
**Consequence:** the same ability is checked twice per write; one is redundant (the request's runs first). Keep the FormRequest `authorize()` or the controller gate, not both.

#### SDY-03 · L · AUTH / dead policy — `DayPolicy` is registered but never consulted
**Where:** `DayPolicy.php` (whole class) · `TimetableFoundationServiceProvider.php:135` — `Gate::policy(SchoolDay::class, DayPolicy::class)`
**Evidence:** every `Gate::authorize()`/`Gate::allows()` call in this controller and its request passes a **string** permission (`tenant.timetable-foundation.school-day.*`), which never reaches a Policy. `grep -rn "authorize('view'\|can('view',.*SchoolDay" ` → no callsite. The policy's seven methods correctly mirror the seeded permission names, but nothing invokes them.
**Consequence:** the policy looks like the authorization layer but is inert (module-wide pattern — same as `AcademicTermPolicy`). Changing it changes nothing until the module stops passing permission strings. Not fixed here.

### F4 — Validation
#### SDY-04 · M · VAL-04 / BUG-003 (latent) — re-creating a trashed code or day-of-week crashes
**Where:** `SchoolDayRequest.php:107,123` (`Rule::unique(...)->ignore(...)->whereNull('deleted_at')`) vs live `tt_school_days`
**Evidence:** `SHOW CREATE TABLE tt_school_days` →
```
UNIQUE KEY `uq_schoolday_code` (`code`),
UNIQUE KEY `uq_schoolday_dow` (`day_of_week`),
```
Neither index is soft-delete aware, and the validator excludes trashed rows (`whereNull('deleted_at')`). The request's own docblock (lines 40-44) admits the gap. Live data: 7 rows, **0 trashed** — so the failure is latent today.
**Consequence:** if a user trashes `MON` and creates `MON` again, validation passes and the insert raises MySQL 1062, showing a 500. Same shape as ATC-11.

#### SDY-05 · M · VAL-05 / DDL-drift — `ordinal` has no upper bound but the column is `tinyint UNSIGNED`; `is_active` is untyped
**Where:** `SchoolDayRequest.php:125-128` and `:134`
```php
'ordinal' => ['required', 'integer', 'min:1'],
...
'is_active' => $this->isMethod('POST') ? ['required'] : ['nullable'],
```
**Evidence:** `SHOW CREATE TABLE tt_school_days` → `` `ordinal` tinyint unsigned NOT NULL `` (max 255). `SELECT @@sql_mode` on the tenant → `…,STRICT_TRANS_TABLES,…`.
**Consequence:** a user entering an ordinal of 256 or more (a plausible typo for 2/26) trips MySQL 1264 "Out of range value", which becomes a 500 on create and edit. `is_active` carries no `boolean` rule, so the controller relies entirely on `$request->boolean()` to coerce it (currently safe, but the field is not typed as VAL-05 requires).

### F5 — Routes
#### SDY-06 · H · RTE-01 — Restore runs over a GET request
**Where:** `routes/web.php:156` — `Route::get('/school-day/{id}/restore', [SchoolDayController::class, 'restore'])->name('school-day.restore');`
**Evidence:** `route:list` shows `GET|HEAD …/{id}/restore`; `scan.php` → RTE-01 at the restore route. The only caller is `trash.blade.php:41` via `<x-backend.table.action-trashed>`, which derives the HTTP verb from the route, so no blade edit is needed to change it.
**Consequence:** GET has no CSRF protection, so a link preview, crawler or prefetcher can restore a day without the user acting.

### F6 — Controller shape
#### SDY-07 · M · CTL-03 — six methods take `$id` + `findOrFail` instead of route model binding
**Where:** `show:129` · `edit:145` · `update:171` · `destroy:242` · `forceDelete:323` · `restore:378`
```php
public function show($id) { … $schoolDay = SchoolDay::findOrFail($id); … }
```
**Evidence:** `route:list` shows `{school_day}` for these routes while the method arguments are `$id`; `scan.php` → CTL-03 at lines 129, 145, 171, 242, 323, 378.
**Consequence:** no functional failure today (Laravel passes the route value positionally to `$id`), but the untyped id bypasses binding, throws `ModelNotFoundException` as a 404 from inside method bodies, and forces the `catch (ModelNotFoundException) { throw }` workaround seen in SDY-01. `toggleStatus` already demonstrates the cleaner bound form (`SchoolDay $schoolDay`).

#### SDY-08 · L · CTL-04 — no return types on any of the 11 public methods
**Where:** lines `27, 43, 74, 129, 145, 171, 242, 290, 323, 378, 438`
**Evidence:** `scan.php` → CTL-04 ×11.
**Consequence:** none for behaviour; the public surface is undocumented.

**Family note (CTL-05):** the six `catch (\Throwable)` blocks and three identical `redirect()->route('…timetableMasters', ['tab' => 'school-days'])` blocks are copy-paste. Both are removed or greatly reduced by SDY-01, so they are reported here rather than as separate IDs.

### F7 — Models
clean — `SchoolDay.php`: `$fillable` declares exactly the 7 writable columns and nothing sensitive; `$casts` covers both booleans, both integers and all three timestamps; `$table = 'tt_school_days'` exists in the tenant migration (proved by `SHOW CREATE TABLE`); `SoftDeletes` is present and the table has `deleted_at`; the class documents that it has no relationships, and `information_schema.KEY_COLUMN_USAGE` confirms **0** FK constraints reference the table. Not `InteractsWithMedia`, no `$timestamps = false`. Only STY-01 applies (SDY-11).

### F8 — Services and jobs
clean — no service, job, listener or event is referenced or dispatched by the controller (`grep -nE "Service|dispatch|ShouldQueue|::create" SchoolDayController.php` → only `SchoolDay::create`).

### F9 — Queries and performance
clean — `trashedDay` paginates at 10 (`paginate(10)`, own page so the default `page` name is correct); every other read is a single-row `findOrFail` or the masters list loaded by `TimetableFoundationController`. No query in a loop, no `::all()`, no raw SQL, no `select *` over a list.

### F10 — Views
#### SDY-09 · L · VIEW — the show page's Back button uses the wrong tab id
**Where:** `show.blade.php:12`
```php
<a href="{{ route('timetable-foundation.menu.timetableMasters', ['tab' => 'school-day']) }}" …>Back</a>
```
**Evidence:** `pages/timetable-masters.blade.php:15` sets `:active="request('tab', 'shifts')"`, and the only school-days tab id is `school-days` (line 9). Everywhere else (index redirect `:31`, `_list.blade.php`, edit form, create fields) uses the plural `school-days`.
**Consequence:** pressing Back from a day's detail page drops the user on the default **Shifts** tab instead of School Days.

#### SDY-10 · L · VIEW — two orphaned blades
**Where:** `views/school-day/create.blade.php` (104 lines) · `views/school-day/index.blade.php` (48 lines)
**Evidence:**
- The `create` route was retired (`routes/web.php:154` `->except(['create'])`; `create()` aborts 403). `grep -rn "timetablefoundation::school-day.create"` → no view reference; the page's form only posts to `…store`.
- `index()` redirects to the masters tab (`:31`). `grep -rn "timetablefoundation::school-day.index"` → no view reference.
**Consequence:** two unreachable create/list pages sit beside the live modal (`_create-modal.blade.php`) and the masters tab. They can drift and mislead. Reported for removal.

**Clean checks (one line each):**
- All six in-scope blades compile (`Blade::compileString` → `php -l` → no syntax errors; `startPush` count 0 = no stray directive).
- No queries in Blade, no `{!! !!}` on any record field.
- Every `route()` used in the in-scope blades (`…edit`, `…update`, `…store`, `…trashed`, `…forceDelete`, `…restore`, `menu.timetableMasters`) exists in `route:list`.
- Permission props on `search-bar`, `status-switch`, `action` and `action-trashed` are 4-part names; all 8 `…school-day.*` permissions are seeded in `sys_permissions` (exact-name query).

### F11 — Security and tenancy
clean — no `env()` outside config; `toggleStatus` returns only `{success, is_active, message}` (no model serialisation); no hard-coded ids; logs contain only `code`/`id`; no cache or static cache; no central model reached from the tenant. Tenant middleware present on all routes (RTE-05 ✅).

### F12 — Style
#### SDY-11 · L · STY-01 / STY-02 — `strict_types` missing and Pint fails on two files
**Where:** `SchoolDayController.php` · `SchoolDayRequest.php` · `SchoolDay.php` · `DayPolicy.php`
**Evidence:** `grep -l "declare(strict_types" <files>` → none. `vendor/bin/pint --test <files> --format agent` →
```json
{"result":"fail","files":[
 {"path":"…/SchoolDayController.php","fixers":["blank_line_before_statement"]},
 {"path":"…/SchoolDayRequest.php","fixers":["fully_qualified_strict_types","ordered_imports"]}]}
```
(`SchoolDay.php` and `DayPolicy.php` are Pint-clean.)
**Consequence:** style/consistency only. Grouped as one plan item per file, per §7.

### F13 — Deep read
#### SDY-12 · H · deep read — Delete Permanently works on a live, non-trashed day
**Where:** `forceDelete:328`
```php
$schoolDay = SchoolDay::withTrashed()->findOrFail($id);
```
**Evidence:** `withTrashed()` matches live rows, so `DELETE /timetable-foundation/school-day/4/force-delete` accepts id 4 even though it is not in the trash. Live data has 7 active rows and 0 trashed. No FK constraint references `tt_school_days` (verified in `information_schema`), so there is no child guard to add.
**Consequence:** any request that reaches this route with a live id permanently destroys an active school day — no trash, no restore. Nothing on the trash screen links to it for a live row, but the URL is unauthenticated-by-record and directly callable. Fix: `onlyTrashed()->findOrFail()`.

#### SDY-13 · L · deep read — a failed toggle reports the requested status
**Where:** `toggleStatus:448, 475`
```php
$schoolDay->is_active = (bool) $request->input('is_active');   // set before save
…
return response()->json(['success' => false, 'is_active' => $schoolDay->is_active, …], 422);
```
**Evidence:** the attribute is mutated in memory before `save()`; if the transaction throws, the in-memory value (the user's requested value) is echoed with `success:false`.
**Consequence:** minor — the payload says `is_active` is the new value even though nothing was written; the front-end must trust `success:false`, not the value. The switch state also depends on the `<x-backend.table.status-switch>` component reading `success`.

**Answers to the deep-read questions:**
1. Can a write overwrite data it should not? **Yes** — `forceDelete` on a live row (SDY-12).
2. Deleted before replacement stored? No.
3. Duplicate implementations of one operation? No service/action used; each operation exists once.
4. Soft-delete × unique trap? **Yes** — SDY-04.
5. Race? No (uniques present, no check-then-act).
6. Authorization hole? No method lacks a gate; the dead policy is SDY-03.
7. Message that lies? `toggleStatus` failure payload (SDY-13); the show Back tab (SDY-09).
8. Dead feature? `create()`/`create.blade.php` and `index.blade.php` (SDY-10).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`SmartTimetable` school-days partial points at the retired create route.** `Modules/SmartTimetable/resources/views/smart-timetable/partials/school-days/_list.blade.php:42` emits `route('timetable-foundation.school-day.create')` unguarded, and the route no longer exists (`routes/web.php:154` excludes it). The partial is included by `smart-timetable/index.blade.php:34` and `smart-timetable/master.blade.php:25`. If either page renders, `route()` throws `RouteNotFoundException` → 500. This is a different module's blade; it is reported here because the cause is this controller's create-route retirement. The team should repoint it at the modal or guard it with `Route::has`.
- **Unreachable policies (module-wide).** All `Gate::policy(...)` registrations in `TimetableFoundationServiceProvider.php:122-142` are inert because every gate passes a permission **string**. `DayPolicy` (SDY-03) is one instance. Needs a module-level decision, not a per-controller fix.
- **`RouteAuthenticationTest` references the retired create route.** `Modules/TimetableFoundation/tests/Feature/RouteAuthenticationTest.php:78` lists `timetable-foundation.school-day.create`. It is a test (D4 — not edited/reported further); the team verifies it after the create-route retirement.
- **`activityLog()`, `flash()`, `x-backend.*` components, `AuthorizesTenantFeature`, `BaseModel`** are shared glue, referenced but not audited here. `flash()` resolves all eight keys used (`created`, `updated`, `trashed`, `restored`, `force_deleted`, `operation_failed`, `status_updated`, `status_switch_failed`) — verified in `config/flash.php`.

## 8. Not covered, and why

- **Runtime behaviour:** no browser, Dusk or Pest run (D4). Every finding is static or a read-only SQL probe.
- **The list loader.** The `$schoolDays` collection rendered by `_list.blade.php` is loaded by `TimetableFoundationController::timetableMasters` (a different controller, not in scope). Its pagination/`pageName`/search behaviour is that controller's audit, not this one's. The partial itself was checked only for compile, queries and permission props.
- **Data repair.** The live rows were read only (7 rows, 0 trashed). No data was changed.
- **`SmartTimetable` and `tests/`** are out of scope; the two cross-cutting notes in §7 are recorded, not fixed.
