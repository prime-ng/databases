# Status — TimetableFoundation / SchoolDayController

**Fixed:** 2026-10-14 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — 17 items ticked, all applied or recorded. Nothing left open in this controller's scope.

---

## 1. Pre-applied work

None. `PRE-APPLIED-2026-10-10.md` lists no file in this controller's scope (`grep -i "school.day"` → 0).

---

## 2. Applied

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| SDY-12 | `SchoolDayController.php` `forceDelete()` | `withTrashed()` → `onlyTrashed()->findOrFail()`. A **live** day can no longer be destroyed by posting its id; it must be trashed first. `tt_school_days` has 0 inbound FKs, so no child guard is needed. | rolled-back replay: DELETE `/school-day/1/force-delete` on a live row | **404**, row still exists |
| SDY-01 (D1) | controller, all 6 mutations | Removed every `try/catch`, `Log::error(['error' => getMessage()])` and the `operation_failed` / `status_switch_failed` flashes. Each write runs in one `DB::transaction` that rolls back on its own. The central handler in `bootstrap/app.php` logs and renders failures, as JSON for the AJAX toggle. `findOrFail()` and route binding sit outside the closures, so a 404 is still a 404. | `grep -c 'try {'` / `Log::` | 0 / 0 |
| SDY-02 | controller `store()`/`update()` | Dropped the duplicate `Gate::authorize`. `SchoolDayRequest::authorize()` runs first and is now the only gate on those two writes. Its docblock (which claimed the controller authorizes) was rewritten. | replay: store/update as user 1 | 302 with the expected outcome |
| SDY-04 (a) | `SchoolDayRequest.php` `withValidator()` | New `after()` hook refuses a `code` or `day_of_week` held by a **trashed** row: "A trashed school day already uses this code — restore it instead." (and "…this weekday…"). The live-row unique rules are unchanged, so a live duplicate still gets "has already been taken". The hook ignores the row being updated. | replay: trash TUE, then store code TUE / dow 2; update MON to TUE | both messages shown, no INSERT, no 1062 |
| SDY-05 | `SchoolDayRequest.php` | `ordinal` gained `max:255` (the column is `TINYINT UNSIGNED` in both the DDL and the live table). `is_active` became `['required','boolean']` on create and `['nullable','boolean']` on update. The create-path message "The is active field is required." is unchanged (`test_34` relies on it). | replay: ordinal 300, is_active `abc`, is_active missing | "must not be greater than 255" · "must be true or false" · "The is active field is required." |
| SDY-06 (a) | `routes/web.php:159-161` | Restore is now `Route::patch`. `x-backend.table.action-trashed` (the only caller, `trash.blade.php:41`) reads the verb from the route, so no blade changed. | uncached route probe; replay | `PATCH …/{id}/restore` → 302 to the trash page, row restored and active. GET → 302 → **405** |
| SDY-07 | controller `show/edit/update/destroy` | Route model binding. The resource parameter is `{school_day}`, so the argument is named **`$school_day`**: Laravel binds by name, and a camelCase `$schoolDay` would receive an empty, unbound model (module-finalization §3.3.1). Views still receive `$schoolDay`. `forceDelete`/`restore` keep `{id}` + `onlyTrashed()->findOrFail()` in the method, the plan's stated alternative. `toggleStatus` was already bound on `{schoolDay}`. | reflection over the uncached route list | all 10 routes: route params = signature params |
| SDY-08 | controller | Every public method has a return type: `View`, `RedirectResponse`, `JsonResponse`, or `never` for `create()`. | `php -l` | OK |
| SDY-09 | `school-day/show.blade.php:12` | Back link uses `['tab' => 'school-days']`, so it returns to the School Days tab. | replay: render show | page contains `tab=school-days` |
| SDY-10 (a) | `views/school-day/` | Deleted `create.blade.php` (104 lines) and `index.blade.php` (48 lines) after re-proving at fix time that no `view()` or `@include` references either. The `_create-modal` comment that mentions `create.blade.php` is historical and was left as is. | `grep -rnE "school-day\.(create\|index)['\"]"` over the app and view dirs, restricted to `view(`/`@include` | 0 |
| SDY-11a/b/c/d | controller, request, `SchoolDay.php`, `DayPolicy.php` | `declare(strict_types=1)` on all four. Pint fixed `fully_qualified_strict_types` and `ordered_imports` in the request; it made no other change. | `vendor/bin/pint <4 files> --format agent` | only the request changed |
| SDY-03 (a) | — | Deferred to the module-wide decision on unreachable policies. `DayPolicy` stays and gained only `strict_types`. | — | — |
| SDY-13 (a) | — | Accepted. The failure payload it described no longer exists: SDY-01 removed the catch, so a failed toggle is now rendered by the central handler as JSON. | — | — |
| SDY-CTL01 | — | Recorded only. 480 → 262 lines, 11 methods, well under the split thresholds. | — | — |

The controller went from 480 lines to 262.

### 2.1 Applied beyond the ticked plan

1. **`activityLog` moved inside the transaction on every mutation**, and after the write (C7.1). Before this, `store()`, `update()`, `destroy()`, `restore()` and `forceDelete()` logged inside a `try` with no transaction, so a failed log could leave a write with no audit row. Event literals are unchanged: `Stored`, `Updated`, `Trashed`, `Restored`, `Deleted`, `Toggled`.
2. **`SchoolDayRequest::schoolDayId()`** (private) turns the route parameter into an id. Since SDY-07 the parameter is a bound model, so the unique rules' `->ignore()` and the new trashed check both read the id through this helper. It also accepts a raw id.

---

## 3. Not applied

None. Every ticked item was applied or recorded as a decision above.

---

## 4. Needs Tarun's hand

1. **Update Dusk `test_25_not_found_restore`** in `tests/Browser/Modules/V2/TimetableFoundation/TimetableMasters/TtSchoolDayCrudTest.php` (line 506). The test does a browser GET to `/school-day/999999999/restore` and asserts "404"/"Not Found". With restore on PATCH, that GET now goes `302 → /e/… → 405`, so **this test will fail**. This was agreed when SDY-06 (a) was chosen, and per the standing rule I did not edit it. Two ways to fix it:
   - assert **405**;
   - or switch to `fetch(PATCH …/999999999/restore)` and assert 404.

   The rest of the suite was checked against the changes and still holds:
   - `test_12` drives the restore form, which now posts PATCH;
   - `test_13` trashes the row before force-deleting it;
   - `test_26` force-deletes a missing id and still gets 404;
   - `test_34` still gets its required message.
2. **Run the suite:** `php artisan dusk tests/Browser/Modules/V2/TimetableFoundation/TimetableMasters/TtSchoolDayCrudTest.php`.
3. **Browser check** of `/timetable-foundation/timetable-masters?tab=school-days`:
   - trash a day, then try to add a new day with the same code, and expect the "restore it instead" message;
   - restore the day from the trash page.

---

## 5. Unverifiable by this workflow (D4), and notes

- **Cross-module, pre-existing, not changed:** `Modules/SmartTimetable/resources/views/smart-timetable/partials/school-days/_list.blade.php:42` calls `route('timetable-foundation.school-day.create')` with no `Route::has()` guard. That route was excluded on 2026-09-10 (TM-05), so the partial throws `RouteNotFoundException` wherever it renders (`smart-timetable/index.blade.php:34`, `master.blade.php:25`). This belongs to SmartTimetable's audit.
- **Pre-existing test reference:** `Modules/TimetableFoundation/tests/Feature/RouteAuthenticationTest.php:78` lists the same retired `school-day.create` route name. Not touched (D4).
- The SDY-01 failure path (the central handler rendering a DB error) was not exercised. The replay covered success, validation, 404 and 405 paths only.

---

## 6. Verification log

```
php -l (controller, request, model, policy, routes/web.php; before and after Pint)  → No syntax errors
class_exists: SchoolDayController, SchoolDayRequest, SchoolDay, DayPolicy          → OK ×4
route probe (APP_ROUTES_CACHE=/tmp/fa-nocache.php), 10 school-day routes          → method_exists Y ×10;
    route params == signature params on all 10; restore = PATCH
blade compile: show, edit, trash, _create-modal, _create-fields                    → lint ok ×5; @push 0 / startPush 0
kernel replay (tenant test.localhost, user 1, DB::beginTransaction … rollBack):
   1 tab page                                     200
   2 show MON → /e/… → followed                   200, has code, back link tab=school-days
   3 show 999999999 → /e/… → followed             404
   4 store live duplicate                         "code has already been taken" + "day of week…"
   5 store code/dow of trashed TUE                both "A trashed school day already uses this … — restore it instead."
   6 ordinal 300 / is_active "abc"                max:255 + boolean messages
   6b store without is_active                     "The is active field is required."
   7 update own code                              302 → ?tab=school-days, name changed, 'Updated' log ×1
   8 update to trashed code                       trashed-code message
   9 GET restore                                  302 → /e/… → 405, row still trashed
  10 PATCH restore                                302 → trash page, restored, is_active=1, flash "restored successfully"
  11 force-delete LIVE row                        404, row still exists
  12 destroy                                      302 → ?tab=school-days, trashed, is_active=0, flash "moved to trash"
  13 force-delete TRASHED row                     302 → trash page, row gone, 'Deleted' log ×1
  14 toggle (AJAX)                                200 {"success":true,"is_active":false,…}, db=0
  15 toggle missing id                            404
  16 trash page                                   200
  rollback                                        7 live, 0 trashed (unchanged)
grep controller: try=0 · Log::=0 · DB::transaction=6 calls (7 grep hits; 1 is the class docblock) · activityLog=6 · Gate::authorize=8
```

---

## 7. Final state

**FIXED.** No open items remain in this controller's scope. One Dusk test (`test_25`) needs updating, as agreed (§4.1). Two cross-module notes (§5) are for other audits.
