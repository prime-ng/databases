# Status — TimetableFoundation / TimingProfileController

**Fixed:** 2026-10-15 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work

`../PRE-APPLIED-2026-10-10.md` has no row for this controller.

## 2. Applied

Decision **TPR-01 (a): retire the feature** (Tarun, 2026-10-15). Facts re-measured before acting: the model `Modules\TimetableFoundation\Models\TimingProfile` does not exist, the tenant has no table matching `%timing%`, no `glb_menus` row points at `timing-profile`, and 7 `tenant.timetable-foundation.timing-profile.*` permissions are seeded. The sibling `SchoolTimingProfileController` was left alone, also by decision.

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| TPR-01 (a) ⚠ SHARED | `Modules/TimetableFoundation/routes/web.php:367-371` | The 5 route lines (11 routes) were replaced with a RETIRED comment, and the `use …TimingProfileController` import was removed | router probe | TimingProfile routes = **0**; SchoolTimingProfile routes = 11 (untouched) | 2026-10-15 |
| TPR-01 (a) ⚠ SHARED | `config/permissionslist.php:700` | Removed the `timetable-foundation.timing-profile` key and left a dated comment in its place. `school-setup.timing-profile` (a different module) was kept | `grep -rn "timetable-foundation.timing-profile" config/` | only the comment, plus a stale `permissionslist.php.bak` | 2026-10-15 |
| TPR-01 (a) | `TimingProfileController.php` | Retired stub. All 11 public methods are kept with `strict_types` and return types. Each body is now `abort(403, 'Timing Profiles have been retired. Use Period Sets instead.')` with a NOT ROUTED note (D5). The missing-model import, the old bodies and the commented-out old `store()` are gone; they remain in git history | `php -l`, `class_exists` | ok | 2026-10-15 |
| TPR-01 (a) | `TimingProfileRequest.php`, `TimingProfilePolicy.php` | RETIRED header, no logic change. Both are kept because `tests/Unit/FormRequestValidationTest.php` and `tests/Unit/PolicyTest.php` name these classes | `class_exists` | ok | 2026-10-15 |
| TPR-01 (a) | `views/timing_profile/{create,edit,index,show,trash}.blade.php` | A RETIRED Blade comment on line 1 of each; nothing renders them now | compile each with `compileString` + `php -l` | 5 compile, comment stripped (no leak) | 2026-10-15 |
| TPR-15 / TPR-16 / TPR-17a | `TimingProfileController.php` | Covered by the stub: return types added, dead code removed, `strict_types` added, imports cleaned up | read | — | 2026-10-15 |
| TPR-17b | `TimingProfileRequest.php` | `declare(strict_types=1)`. Pint also reformatted the file's whitespace | `php -l` | ok | 2026-10-15 |
| TPR-17c | `TimingProfilePolicy.php` | `declare(strict_types=1)` | `php -l` | ok | 2026-10-15 |

## 3. Not applied

| ID | Reason |
|---|---|
| TPR-02, 03, 05, 06, 07, 08, 09, 10, 11, 12, 13 | Moot. Every method they would fix is now NOT ROUTED and only aborts |
| TPR-04 | Moot. The restore route was removed with TPR-01 |
| TPR-14 | Deferred to the module-wide policy decision. Moot for a retired feature |
| TPR-18 | Moot. The pages are no longer reachable |

## 4. Needs Tarun's hand

1. **Run `/system-config/sync-permissions`**, or a manual cleanup, if you want the 7 seeded `tenant.timetable-foundation.timing-profile.*` rows gone. The sync is additive-only, so it will **not** delete them. Removing them from `sys_permissions` is a separate, manual step.
2. **`Modules/TimetableFoundation/tests/Feature/RouteAuthenticationTest.php:99, 136`** list `timing-profile.index` / `.store`, which no longer exist. Those cases will now fail. Not edited (D4).
3. The breadcrumb registry (`app/Services/Breadcrumbs/registry.php:3834`) still holds a `timetable-foundation.timing-profile.index` entry. It is generated and harmless (the route is gone); it disappears on the next regeneration.

## 5. Unverifiable by this workflow (no tests, D4)

- That the 11 old URLs now return 404 in a browser. Statically the routes are gone, so Laravel's router answers 404.
- Cross-cutting, not fixed: `Modules/SmartTimetable/database/seeders/TimingProfileSeeder.php` and `SchoolTimingProfileSeeder.php` reference models that do not exist; running them would fatal.

## 6. Verification log
```
php -l  TimingProfileController.php / TimingProfileRequest.php / TimingProfilePolicy.php / routes/web.php / config/permissionslist.php → ok
vendor/bin/pint (3 PHP files) → fixed (Request whitespace); php -l re-run → ok
class_exists: TimingProfileController, TimingProfileRequest, TimingProfilePolicy → OK ×3
route:clear + router probe → TimingProfileController routes 0 · SchoolTimingProfileController routes 11
grep of retired route names outside the retired files → 0 (policy/request permission strings are expected)
Blade compile, 5 timing_profile views → all compile, RETIRED comment stripped
```

## 7. Final state
Status: FIXED (retired) · Open: none in this controller. 7 seeded permission rows remain until removed by hand. The sibling `SchoolTimingProfileController` is still AUDITED with the same defect.
