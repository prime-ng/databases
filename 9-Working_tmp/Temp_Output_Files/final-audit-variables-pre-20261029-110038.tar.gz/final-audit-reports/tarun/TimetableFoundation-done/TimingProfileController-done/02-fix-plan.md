# Fix Plan — TimetableFoundation / TimingProfileController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/TimingProfileController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
- [x] **TPR-01** · B · DECISION · MDL-07 / RTE-02 — the model `Modules\TimetableFoundation\Models\TimingProfile` does not exist and neither does the `tt_timing_profile` table, so all 11 routes 500. The orphan-tables audit calls this feature deprecated ("absorbed into period sets").
      (a) ⭐ **Retire the feature**: delete/disable the 4 route lines (`routes/web.php:345-349`), remove the `timing-profile` menu entry and the `timetable-foundation.timing-profile` permission, and mark the controller + request + policy + 5 blades as retired (a `// RETIRED 2026-10-10` header, no logic change). ⚠ Changing routes/`glb_menus`/permissions needs explicit approval and a `/system-config/sync-permissions` run on your hand.
      (b) **Rebuild it**: author the missing `TimingProfile` model and an additive tenant migration creating `tt_timing_profile` (DDL columns: `profile_code`, `name`, `total_periods`, `timezone`, `notes`, `is_active`, `deleted_at`, plus UNIQUE `profile_code`). Then apply TPR-03/TPR-12 so create persists every validated field.
      (c) Leave the routes live and accept the 500s.
      ➜ Choice: (a) retire — Tarun 2026-10-15

## 2. Fixes that arm a latent defect (sequenced)
- [ ] **TPR-03** · H · deep read · `TimingProfileController.php:76-78` — add `timezone` and `notes` to the `store()` allow-list (or switch to `$request->validated()` per TPR-12) so create does not silently drop the two form fields. **Do this before TPR-01(b), and do it regardless of TPR-01's answer** if the feature survives. Effort: S.

## 3. Errors, transactions & behaviour (F1/F2/F6)
- [ ] **TPR-05** · M · ERR-00 (D1) / ERR-05 · `TimingProfileController.php:70-99, 134-191, 202-224, 245-267, 277-299, 307-345` — remove the `try/catch` from all six mutating methods and let the central handler render and log:
  - **Shape:** `return DB::transaction(fn …)`, matching the controller's siblings after the pre-applied 2026-10-10 pass.
  - **Errors:** if TPR-01(b) adds business rules, throw `\DomainException` and catch only that, with an `ERR-01` + date comment; never re-introduce `catch (\Throwable)`.
  Effort: S.
- [ ] **TPR-02** · H · ERR-02 · `TimingProfileController.php:309` — move `$request->validate([...])` out of the `try` (it disappears entirely with TPR-05). The 422 must reach the caller as a 422. Effort: S.
- [ ] **TPR-06** · M · ERR-04 · `TimingProfileController.php:322-334, 341-345` — let the central handler answer the AJAX switch as JSON (it already does for `expectsJson()` callers). Removed by TPR-05. Effort: S.
- [ ] **TPR-07** · M · TXN-04 · `TimingProfileController.php:137-139, 156-177, 315-322` — call `activityLog()` **after** `$timingProfile->update(...)`, and compute the change set from what was actually sent (`$request->validated()` vs `getOriginal()`), not from `getChanges()` before the write. Same inversion in `toggleStatus`. Effort: S.
- [ ] **TPR-08** · M · TXN-05 · `TimingProfileController.php:87-89, 179-180, 212-213, 255-256, 287-288, 323-333` — the closure returns the model (or `true`); build `redirect()` / `response()` **after** the transaction. Effort: S.
- [ ] **TPR-11** · M · deep read · `TimingProfileController.php:88, 179, 212` — redirect to `timetable-foundation.timing-profile.index` (the list) instead of `timetable-foundation.index` (the module dashboard). Restore/forceDelete already redirect to `.trashed` ✅. Effort: S.

## 4. Authorization (F3)
- [ ] **TPR-13** · L · AUTH-04 · `TimingProfileController.php:68, 132` — drop the duplicate `Gate::authorize('…create'|'…update')` in `store`/`update`; keep the FormRequest `authorize()`, which runs first. Effort: S.
- [ ] **TPR-14** · L · AUTH-01 · DECISION · `app/Policies/TimingProfilePolicy.php` — the policy is unregistered and every gate passes a string, so it is never consulted.
      (a) ⭐ Defer to the module-wide policy decision (identical to the `AcademicTermController` ATC-14 and every other TimetableFoundation report). Do not touch it here.
      (b) Register it against the rebuilt model (only meaningful if TPR-01(b) is chosen) — but the string gates would still bypass it.
      ➜ Choice: (a) defer to module-wide decision — moot, feature retired

## 5. Validation, routes, models (F4/F5)
- [ ] **TPR-12** · M · VAL-01 · `TimingProfileController.php:77, 170-177` — replace `$request->only([...])` with `$request->validated()`; this removes the store/update divergence that causes TPR-03. Effort: S.
- [ ] **TPR-04** · H · DECISION · RTE-01 · `routes/web.php:347` — Restore runs over GET, so a prefetcher can restore a trashed profile.
      (a) ⭐ Change it to `Route::patch`/`Route::post`. `x-backend.table.action-trashed` derives the verb from the route, so **no blade edit** is needed. ⚠ This changes a route, so it needs explicit approval.
      (b) Leave it as GET and accept the risk.
      ➜ Choice: moot — routes removed with TPR-01(a)
- [ ] **TPR-09** · M · CTL-03 · `TimingProfileController.php:106, 117, 130, 198, 241, 273` — use route-model binding (`show(TimingProfile $timing_profile)`, `->onlyTrashed()` on restore/forceDelete) instead of `$id` + `findOrFail`. Align the route parameter name with the argument (the resource already uses `{timing_profile}`). ⚠ Depends on TPR-01(b); a no-op if the feature is retired. Effort: M.

## 6. Queries & performance (F9)
_None — both lists already `paginate(10)` with no N+1._

## 7. Views (F10)
- [ ] **TPR-18** · L · DECISION · modal-standard / breadcrumb-standard · `create.blade.php` + the four page blades — the 6-control create form should be a modal (`modal-standard.md` §2.5), and every breadcrumb passes `:links="[]"`.
      (a) ⭐ Defer — moot if TPR-01(a) retires the feature; otherwise convert `create` to a modal (matching the module's other create modals) and resolve the breadcrumb trail.
      (b) Leave the pages and empty breadcrumbs as they are.
      ➜ Choice: (a) defer — moot, feature retired

## 8. Style (F12) — one item per file
- [x] **TPR-15** · L · CTL-04 · `TimingProfileController.php` — add return types to all 11 public methods (`: View`, `: RedirectResponse`, `: JsonResponse`). Effort: S.
- [x] **TPR-16** · L · CTL-10 / STY-04 · `TimingProfileController.php:46-64, 91-94, 137-139` — delete the commented-out old `store()` (it contains `$request->all()`), the unreachable `catch (ModelNotFoundException)` in `store()`, and the dead `$original`/`$changes` once TPR-07 lands. Effort: S.
- [x] **TPR-17a** · L · STY-01/02/03 · `TimingProfileController.php` — add `declare(strict_types=1)`, sort/compress the imports (`:5-17`), and normalise the `store()` indentation (`:66-100`). Effort: S.
- [x] **TPR-17b** · L · STY-01 · `TimingProfileRequest.php` — add `declare(strict_types=1)`. Effort: S.
- [x] **TPR-17c** · L · STY-01 · `TimingProfilePolicy.php` — add `declare(strict_types=1)`. Effort: S.

## 9. Deferred / decisions
- [ ] **TPR-10** · M · DEFERRED · CTL-05 — the six copy-pasted transaction/catch blocks collapse naturally once TPR-05 removes them; if any remain, extract a shared helper. Do not split the controller (D3).
- **TPR-01** and **TPR-04** and **TPR-14** and **TPR-18** above are the DECISION items — fill their `➜ Choice:` before running the fixer.

> **How to approve**
> 1. Tick `[x]` on every item to apply.
> 2. Fill every `➜ Choice:` (TPR-01, TPR-04, TPR-14, TPR-18).
> 3. Then run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/TimingProfileController.php`.
