# Final Audit — TimetableFoundation / TimingProfileController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/TimingProfileController.php` (348 lines, 11 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 1 blocker, 3 HIGH.**

The single worst finding is **TPR-01**: the model this entire controller is built on —
`Modules\TimetableFoundation\Models\TimingProfile` — **does not exist**, and its table
`tt_timing_profile` is **absent from the tenant database**. Every routed method that touches
the model (`index`, `store`, `show`, `edit`, `update`, `destroy`, `trashedPeriod`, `restore`,
`forceDelete`, `toggleStatus`) fatals with "Class not found" on first use. Only `create()`
returns a view without touching the model. The feature looks live in the menu and in
`route:list`, but it cannot serve a single request.

Underneath the blocker, the controller is the pre-2026-10-10 style the module has been moving
away from: six methods carry `try/catch` and log only `$e->getMessage()`, responses are built
inside the transaction, and `update()` writes its activity log **before** the row it describes.
The orphan-tables audit calls this feature **deprecated** ("functionality absorbed into period
sets"), so the blocker is very likely a retire decision, not a rebuild.

Rough effort if retired: about 1 hour (a route/permission cleanup plus two style files). If the
feature is rebuilt, it is a day (model + migration + all the F1/F2 fixes). Three DECISION items
need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 1 | 3 | 8 | 6 | 3 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TPR-02, TPR-05, TPR-06 | F8 Services/Jobs | clean: no service, job, event (`grep -oE '[A-Z][A-Za-z]+(Request\|Policy\|Service\|Job\|Event…)' $C` → only `TimingProfileRequest`) |
| F2 Transactions/Audit | TPR-07, TPR-08 | F9 Queries/Perf | clean: both lists `paginate(10)`; no `::all()`, no query in a loop |
| F3 Authorization | TPR-13, TPR-14 | F10 Views | TPR-18 |
| F4 Validation | TPR-12, (TPR-03) | F11 Security/Tenancy | clean: no `env()`, no `?? 1`, tenant middleware present |
| F5 Routes | TPR-04 | F12 Style | TPR-15, TPR-16, TPR-17 |
| F6 Controller shape | TPR-09, TPR-10 | F13 Deep read | TPR-01, TPR-03, TPR-07, TPR-11 |
| F7 Models | TPR-01 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/TimingProfileController.php` | controller | 348 | this report | ✅ whole class |
| 2 | `app/Http/Requests/TimingProfileRequest.php` | FormRequest | 56 | this report | ✅ whole class |
| 3 | `app/Policies/TimingProfilePolicy.php` | policy | 43 | this report | ✅ — unreachable, see TPR-14 |
| 4 | `routes/web.php` lines 344-350 | routes | — | this report | ✅ |
| 5 | `views/timing_profile/index.blade.php` | page | 77 | this report | ✅ |
| 6 | `views/timing_profile/create.blade.php` | page | 91 | this report | ✅ |
| 7 | `views/timing_profile/edit.blade.php` | page | 107 | this report | ✅ |
| 8 | `views/timing_profile/show.blade.php` | page | 50 | this report | ✅ |
| 9 | `views/timing_profile/trash.blade.php` | page | 47 | this report | ✅ |
| — | `Modules\TimetableFoundation\Models\TimingProfile` | model | **missing** | — | ❌ class does not exist — TPR-01 |
| — | table `tt_timing_profile` | table | **absent** | — | ❌ not in tenant DB — TPR-01 |
| — | `App\Traits\AuthorizesTenantFeature`, base `Controller`, `x-backend.*` components, `tenancy()` | common | — | common (§4.2) | referenced only; component props checked against constructors |

**Shared-class ownership (§5):** no in-scope class is reachable by another controller, so
**nothing was appended to `00-CLASS-OWNERS.md`**. `TimingProfileRequest` and the five
`timing_profile` blades are used only here; the policy resolves to a model that does not exist.
The model is not registrable because it is absent. The sibling `SchoolTimingProfileController`
(already `CLAIMED` by opencode) has the same class of defect — see §7.

**Pre-applied 2026-10-10:** `TimingProfileController` is **not** listed in
`../PRE-APPLIED-2026-10-10.md`. No in-scope file was touched by that pass. The `try/catch`
pattern here is therefore *original*, not a regression of the pre-applied work.

## 4. Routes

```
GET|HEAD  timetable-foundation/timing-profile                       timetable-foundation.timing-profile.index       index
POST      timetable-foundation/timing-profile                       timetable-foundation.timing-profile.store       store
GET|HEAD  timetable-foundation/timing-profile/create                timetable-foundation.timing-profile.create      create
GET|HEAD  timetable-foundation/timing-profile/trash/view            timetable-foundation.timing-profile.trashed     trashedPeriod
GET|HEAD  timetable-foundation/timing-profile/{id}/restore          timetable-foundation.timing-profile.restore     restore    ← GET
DELETE    timetable-foundation/timing-profile/{id}/force-delete     timetable-foundation.timing-profile.forceDelete forceDelete
GET|HEAD  timetable-foundation/timing-profile/{timing_profile}      timetable-foundation.timing-profile.show        show
PUT|PATCH timetable-foundation/timing-profile/{timing_profile}      timetable-foundation.timing-profile.update      update
DELETE    timetable-foundation/timing-profile/{timing_profile}      timetable-foundation.timing-profile.destroy     destroy
GET|HEAD  timetable-foundation/timing-profile/{timing_profile}/edit timetable-foundation.timing-profile.edit        edit
POST      timetable-foundation/timing-profile/{timing_profile}/toggle-status timetable-foundation.timing-profile.toggleStatus toggleStatus
```

Middleware on every route (from `TimetableFoundationServiceProvider` → `RouteServiceProvider:45-56`):
`web, InitializeTenancyByDomain, PreventAccessFromCentralDomains, EnsureTenantIsActive,
EnsureTenantHasModule:TimetableFoundation, auth, verified` — tenant middleware present ✅ (RTE-05).

**Unrouted public methods:** none — all 11 public methods are routed ✅ (RTE-03).
**Route order:** the custom `trash/view`, `{id}/restore`, `{id}/force-delete`, `{timing_profile}/toggle-status`
routes are declared **after** `Route::resource('timing-profile', …)` (RTE-06). This is currently
benign — every custom path differs from a resource path by segment count or a literal segment, so
none is captured today. Recording it so it stays true when a new sub-route is added.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — | TPR-01 |
| create | ✅ | create | — | — | — | TPR-18 |
| store | ✅ | create (+ request) | ✅ closure | `Stored` | tt_timing_profile, sys_activity_logs | TPR-01, 03, 05, 08, 10, 12, 16 |
| show | ✅ | view | — | — | — | TPR-01, 09 |
| edit | ✅ | update | — | — | — | TPR-01, 09 |
| update | ✅ | update (+ request) | ✅ closure | `Updated` | tt_timing_profile, sys_activity_logs | TPR-01, 05, 07, 08, 09, 10, 12, 13, 16 |
| destroy | ✅ | delete | ✅ closure | `Trashed` | tt_timing_profile, sys_activity_logs | TPR-01, 05, 08, 09, 11 |
| trashedPeriod | ✅ | restore | — | — | — | TPR-01 |
| restore | ✅ | restore | ✅ closure | `Restored` | tt_timing_profile, sys_activity_logs | TPR-01, 04, 05, 08, 09 |
| forceDelete | ✅ | forceDelete | ✅ closure | `Deleted` | tt_timing_profile, sys_activity_logs | TPR-01, 05, 08, 09 |
| toggleStatus | ✅ | update | ✅ closure | `Toggled` | tt_timing_profile, sys_activity_logs | TPR-01, 02, 05, 06, 07, 08 |

**Tables each mutation SHOULD touch** (`controller-alignment.md` §0.1): every mutation writes the
profile row **plus** its activity-log row — `tt_timing_profile` + the tenant activity log
(`sys_activity_logs`). The code attempts both. `tt_timing_profile` does not exist, so the write
never lands (TPR-01).

## 6. Findings

### F7 — Models
#### TPR-01 · B · MDL-07 / RTE-02 · deep read — the controller's model class and its table do not exist
**Where:** `TimingProfileController.php:16` (import), `:29`, `:76`, `:110`, `:122`, `:136`, `:204`, `:234`, `:247`, `:279`, `:303`
```php
16: use Modules\TimetableFoundation\Models\TimingProfile;
29: $timingProfiles = TimingProfile::paginate(10);
76: $timingProfile = TimingProfile::create(…
```
**Evidence:**
- `find . -name 'TimingProfile.php' -not -path '*/vendor/*'` → **no file**.
- `grep -rn "class TimingProfile" Modules app` → only `TimingProfilePolicy`, `TimingProfileRequest`, `TimingProfileController`, `TimingProfileSeeder` — no model.
- `php -r '…bootstrap(); var_dump(class_exists(Modules\TimetableFoundation\Models\TimingProfile::class));'` → **`bool(false)`**.
- Tenant probe: `SHOW TABLES LIKE "%timing%"` → **0 rows**; `tt_timing_profile`, `tt_school_timing_profile`, `tt_period` all `NO`. (`sch_academic_term` = `Y`, so tenancy is correct.)
- The only reference to `tt_timing_profile` in the whole project is the unique rule in `TimingProfileRequest.php:20-21`.

**Consequence:** `GET /timetable-foundation/timing-profile` (the menu link), every row action, and
the status switch all crash with `Error: Class "Modules\TimetableFoundation\Models\TimingProfile"
not found` (HTTP 500); the feature is advertised but cannot serve one request.

### F1 — Errors
#### TPR-02 · H · ERR-02 · validation — `toggleStatus` runs `validate()` inside the `try`, so the generic catch swallows the 422
**Where:** `TimingProfileController.php:307-311` and `:341-345`
```php
307: try {
308:     return DB::transaction(function () use ($request, $timing_profile) {
309:         $request->validate([ 'is_active' => 'required|boolean' ]);
…
341: } catch (\Throwable $e) {
342:     Log::error('TimingProfileController::toggleStatus failed', ['error' => $e->getMessage()]);
343:     return back()->with('error', 'The operation could not be completed.');
```
**Evidence:** scanner row `ERR-02 · H · toggleStatus` confirms `validate inside try`; read confirms the catch is `\Throwable` and does not rethrow `ValidationException`.
**Consequence:** a bad `is_active` payload produces a redirect with a generic "operation could not be completed" banner instead of a 422 with the field error — the AJAX switch silently fails to explain itself.

#### TPR-03 · H · deep read — `store()` silently discards `timezone` and `notes`
**Where:** `TimingProfileController.php:76-78`; form fields at `create.blade.php:54-70`
```php
76: $timingProfile = TimingProfile::create(
77:     $request->only(['profile_code', 'name', 'total_periods', 'is_active'])
78: );
```
**Evidence:** the create form collects `timezone` (`create.blade.php:54`) and `notes` (`:67`), and the FormRequest validates both (`TimingProfileRequest.php:23-24`), but the create allow-list omits them. `update()` (`:170-177`) **does** persist them.
**Consequence:** a user who fills Timezone and Notes on the create form gets an "created successfully" toast and a row that lost both values, with no error.

#### TPR-04 · H · RTE-01 · routes — Restore runs over a GET request
**Where:** `routes/web.php:347`
```php
Route::get('/timing-profile/{id}/restore', [TimingProfileController::class, 'restore'])->name('timing-profile.restore');
```
**Evidence:** `route:list` shows `GET|HEAD …/{id}/restore`; scanner `RTE-01 · H · restore`. The only caller is `trash.blade.php:27` via `<x-backend.table.action-trashed>`, which derives the HTTP verb from the route itself (`action-trashed.blade.php:5`), so changing the verb needs no blade edit.
**Consequence:** GET has no CSRF protection, so a link preview or browser prefetcher can restore a trashed profile.

### F1 — Errors (continued)
#### TPR-05 · M · ERR-00 (D1) + ERR-05 · errors — six methods try/catch themselves and log only the message
**Where:** `store:91-99` · `update:183-191` · `destroy:216-224` · `restore:259-267` · `forceDelete:291-299` · `toggleStatus:337-345`
```php
91:  } catch (ModelNotFoundException $e) {
94:      throw $e;
95:  } catch (\Throwable $e) {
96:      Log::error('TimingProfileController::store failed', ['error' => $e->getMessage()]);
98:      return back()->with('error', 'The operation could not be completed.');
```
**Evidence:** under settled D1 (ERR-00 = the Laravel idiom) a controller try/catch is a finding. All six catches log only `$e->getMessage()` (ERR-05 loses the trace) instead of `report($e)`; the central handler in `bootstrap/app.php` already renders and logs. The pre-applied 2026-10-10 pass converted the sibling controllers to `return DB::transaction(fn …)` with no try/catch; this controller was missed.
**Consequence:** a stack trace is lost on every failure, the controller carries two error models, and each catch is a place to get ERR-01/02 wrong (TPR-02, TPR-06 are exactly that).

#### TPR-06 · M · ERR-04 · errors — `toggleStatus` returns JSON on success but a redirect in its catch
**Where:** `TimingProfileController.php:322-334` (JSON) vs `:341-345` (`back()`)
**Evidence:** scanner `ERR-04 · M · toggleStatus returns both JSON and redirects with no expectsJson() branch`.
**Consequence:** the AJAX status switch gets a JSON body when it works and an HTML redirect when it fails, so the caller's `success:false` branch never runs on a server error.

### F2 — Transactions/Audit
#### TPR-07 · M · TXN-04 + deep read — `update()` logs the change **before** the write, and the change set is always empty
**Where:** `TimingProfileController.php:137-139` and `:156-177`
```php
137: $original = $timingProfile->getOriginal();
139: $changes  = $timingProfile->getChanges();     // nothing has changed yet → []
…
156: if (!empty($changedAttributes)) {            // always false
…    } else {
163:     activityLog($timingProfile, 'Updated', ['message' => 'A new timing profile was updated. No attributes changed.', …]);
…
170: $timingProfile->update($request->only([ … ]));  // the write happens AFTER the log
```
**Evidence:** `getChanges()` is read before `update()`, so it is always `[]`; `activityLog()` runs before the write it describes. `toggleStatus` has the same inversion (`:315` sets the status, `:319` logs, `:322` saves).
**Consequence:** the activity log for every edit says "No attributes changed." even when fields changed — the audit trail lies — and the log row can be written for a write that then fails.

#### TPR-08 · M · TXN-05 · transactions — the redirect/response is built inside the `DB::transaction` closure
**Where:** `store:87-89` · `update:179-180` · `destroy:212-213` · `restore:255-256` · `forceDelete:287-288` · `toggleStatus:323-333`
```php
87:  return redirect()
88:      ->route('timetable-foundation.index')
89:      ->with('success', flash('created.timing_profile'));
```
**Evidence:** the `redirect()` and the session flash are created inside the closure (and, for the flash, before the commit).
**Consequence:** if the commit fails after the flash is written, the next page shows "Timing Profile was created successfully." for a row that does not exist.

### F6 — Controller shape
#### TPR-09 · M · CTL-03 · shape — `show`/`edit`/`update`/`destroy`/`restore`/`forceDelete` use `$id` + `findOrFail`
**Where:** `:106`, `:117`, `:130`, `:198`, `:241`, `:273`
```php
106: public function show($id)   { … $timingProfile = TimingProfile::findOrFail($id); }
```
**Evidence:** the resource routes declare `{timing_profile}` but the methods take `$id`; scanner `CTL-03` on all six. (`toggleStatus` correctly binds `TimingProfile $timing_profile`.)
**Consequence:** route-model binding is bypassed, so the route parameter and the method argument can drift, and the 404 logic is duplicated in every method.

#### TPR-10 · M · CTL-05 · shape — the transaction + three-catch + redirect block is copy-pasted six times
**Where:** `store:70-99`, `update:134-191`, `destroy:202-224`, `restore:245-267`, `forceDelete:277-299`, `toggleStatus:307-345`
**Evidence:** the same `try { DB::transaction(fn …) } catch (ModelNotFoundException) { throw } catch (\Throwable) { Log::error(…getMessage()…); return back()… }` shape appears verbatim in all six; even the comment "Rule A1: a missing record must stay a 404…" is duplicated.
**Consequence:** a fix to one block misses the other five — which is exactly how TPR-02 and TPR-06 exist only in `toggleStatus`.

#### TPR-11 · M · deep read — `store`/`update`/`destroy` redirect to the module dashboard, not the list
**Where:** `TimingProfileController.php:88`, `:179`, `:212`
```php
88: ->route('timetable-foundation.index')
```
**Evidence:** the commented-out original (`:62`) redirected to `timetable-foundation.timing-profile.index`. `timetable-foundation.index` resolves to the module root (`routes/web.php:46`).
**Consequence:** after saving or trashing a profile the user is dropped on the Timetable Foundation dashboard, unable to see the result of the action they just took.

### F4 — Validation
#### TPR-12 · M · VAL-01 / VAL-05 · validation — `store`/`update` use `$request->only([…])`, not `validated()`
**Where:** `TimingProfileController.php:77`, `:170-177`
**Evidence:** a FormRequest exists and validates the fields, but the controller reads a hand-written allow-list instead of `$request->validated()`. The two lists disagree with each other (`store` omits `timezone`/`notes`, `update` includes them — TPR-03), which is the failure mode `validated()` removes.
**Consequence:** the validated input and the persisted fields can silently diverge; today they already do.

### F3 — Authorization
#### TPR-13 · L · AUTH-04 · authorization — `store`/`update` authorize the same permission twice
**Where:** controller `:66-68`, `:130-132` and `TimingProfileRequest::authorize()` (`:38`)
**Evidence:** the FormRequest runs first (`Gate::allows('…create'|'…update')`) and then the controller calls `Gate::authorize('…create'|'…update')` for the same name. Scanner `AUTH-04 · L` on both.
**Consequence:** no functional loss, but two places to keep in step. Keep the FormRequest (it runs first), drop the duplicate `Gate::authorize` in `store`/`update`.

#### TPR-14 · L · AUTH-01 / AUTH-06 · authorization — `TimingProfilePolicy` is dead code that looks active
**Where:** `app/Policies/TimingProfilePolicy.php` (43 lines)
**Evidence:** `grep TimingProfilePolicy Modules/TimetableFoundation/app/Providers/` → **no registration** (the sibling policies are registered at `TimetableFoundationServiceProvider:122-140`; this one is absent, and cannot be registered while its model is missing). Even if registered, every gate passes a permission **string**, so the policy would never be consulted. Same module-wide pattern other reports recorded.
**Consequence:** a reader believes record-level policy checks exist; in fact only the string gates guard these methods.

### F12 — Style
#### TPR-15 · L · CTL-04 · style — no return types on any of the 11 public methods
**Where:** every `public function …` in the controller; scanner `CTL-04 · L` ×11.
**Consequence:** IDE and static analysis cannot tell a `View` from a `RedirectResponse` from a `JsonResponse`.

#### TPR-16 · L · CTL-10 / STY-04 · dead code — a commented-out `store()` and a catch that can never fire
**Where:** `TimingProfileController.php:46-64` (the entire old `store()` left commented) and `:91-94`
**Evidence:** the commented block contains `$request->all()` and a second `TimingProfile::create()`; the `catch (ModelNotFoundException)` in `store()` guards a method that contains no `findOrFail`, so it is unreachable. The `$original`/`$changes` variables at `:137-139` are similarly dead after TPR-07.
**Consequence:** a reader cannot tell which `store()` is current, and `$request->all()` is seeded into the file for the next copy-paste.

#### TPR-17 · L · STY-01/02/03 · style — controller, request and policy
- **Controller:** `declare(strict_types=1)` missing (`:1`); imports are separated by blank lines and unsorted (`:5-17`); `store()`'s body is indented at 4 while the signature sits at 0 (`:66-100`). Effort: S.
- **Request:** `declare(strict_types=1)` missing (`:1`). Effort: S.
- **Policy:** `declare(strict_types=1)` missing (`:1`). Effort: S.

### F10 — Views
#### TPR-18 · L · DECISION · modal-standard / breadcrumb-standard — create is a full page and breadcrumbs carry no trail
**Where:** `create.blade.php` (6 controls) · `index/edit/show/trash.blade.php` (`<x-backend.components.breadcrum … :links="[]" />`)
**Evidence:** `modal-standard.md` §2.5 — a create form with **15 or fewer** controls is a modal; this one has 6. Every breadcrumb passes `:links="[]"`, so no trail is resolved. (If the feature is retired per TPR-01 this is moot.)
**Consequence:** inconsistent with the module's other create modals, and the user gets no navigable breadcrumb trail.

**Clean checks (one line each):**
- **F9 queries:** `index` and `trashedPeriod` both `paginate(10)`; no `::all()`, no query in a loop, no `selectRaw`/interpolated SQL — clean (`grep -nE '::all\(|->get\(\)' $C` → none).
- **F11 security:** no `env()`, no hard-coded id/`?? 1`, no request body logged; tenant middleware present — clean.
- **F10 views:** no queries in Blade, no `{!! !!}`, relations not used in `@foreach`; `x-backend.table.action` / `action-trashed` / `status-switch` receive their correct `*Permission` props (the class components consume them — `Action.php:22-24`, `ActionTrashed.php:37-38`) — clean.
- **F8 services/jobs:** no service, job, event or listener referenced — clean.
- **F1 message leak:** no `$e->getMessage()` reaches `with()`/`withErrors`/`json()`/`back()`; messages are fixed strings — clean (ERR-01 not present).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **Sibling controller, same defect:** `SchoolTimingProfileController` (index row `CLAIMED`, opencode) imports `Modules\TimetableFoundation\Models\SchoolTimingProfile`, which **also does not exist** (`class_exists` → `false`; `find . -name 'SchoolTimingProfile.php'` → none), and its table is also absent. Fixing the two together avoids a second audit cycle.
- **Seeder references another missing model:** `Modules/SmartTimetable/database/seeders/TimingProfileSeeder.php:6,43` uses `Modules\SmartTimetable\Models\TimingProfile` and `SchoolTimingProfileSeeder` likewise — both models are absent. Any `db:seed` for these would fatal.
- **Unreachable policies (module-wide):** as in the `AcademicTermController` report, every policy is unreachable because gates pass strings. Module-level decision, not this report's.
- **`action.blade.php` `:canEdit`:** the anonymous `@props` (`canView/canEdit/canDelete`) are overridden by the `Action` class properties (`Action.php:34-39` documents this). The call sites here use the correct `viewPermission`/`editPermission`/`deletePermission`, so this controller is unaffected.

## 8. Not covered, and why

- **Runtime behaviour:** no browser run and no tests (D4). Every finding is static or a read-only SQL/`SHOW TABLES` probe.
- **The retire-vs-rebuild decision:** the orphan-tables audit (`pgdatabase/.../04_Orphan_Tables_In_Migrations.md:19`) marks `tt_timing_profile` "Deprecate — functionality absorbed into period sets". Whether to delete the feature is a product decision (TPR-01), not something this audit can settle.
- **The sibling `SchoolTimingProfileController` and its seeded data:** out of scope; noted in §7.
- **Writing/repairing data:** none attempted; this pass is read-only.
