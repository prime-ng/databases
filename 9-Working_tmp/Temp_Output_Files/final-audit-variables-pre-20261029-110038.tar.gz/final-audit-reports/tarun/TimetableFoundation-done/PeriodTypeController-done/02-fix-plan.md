# Fix Plan — TimetableFoundation / PeriodTypeController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/PeriodTypeController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
- [x] **PTC-13** · H · deep read · `PeriodTypeController.php:348` — `forceDelete()`:
  - Use `PeriodType::onlyTrashed()->findOrFail($id)` so a **live** period type can no longer be purged (7 of the 9 live rows have no FK children and would delete silently today).
  - Before deleting, count the two FK children — `tt_period_configs` and `tt_period_set_periods_jnt`. If any exist, refuse with a `\DomainException` naming each table and its count.
  - Because the guard throws, keep **one** catch in this method only: `catch (\DomainException $e)` → `back()->with('error', $e->getMessage())`, with a comment naming ERR-01 and the date (D2). Effort: S.

## 2. Fixes that arm a latent defect (sequenced)
- [x] **PTC-07** · M · DECISION · CTL-10 — the `is_system` guard is dead code over a missing column, and hides a latent crash.
  **Where** `PeriodTypeController.php:165, 244, 353, 399`; `show.blade.php`/`edit.blade.php`.
      (a) ⭐ Leave the guards in place and correct the class docblock to say the column is absent and the branches are inert; also add the two missing flash keys (`system_record_force_delete_not_allowed`, `system_record_status_change_not_allowed`) to `config/flash.php` so the guards show a real message if ever activated. No migration.
      (b) Add an additive migration for an `is_system` column — **and** fix the `update()` latent crash first: `:167-172` unsets `$validated['is_break']` then `:176` reads it, which throws "Undefined array key is_break" the moment the guard becomes reachable.
      (c) Remove the guards entirely (they protect nothing today).
      ➜ Choice: (c) — remove the dead guards; docblock corrected (2026-10-12)

## 3. Errors & transactions (F1/F2)
- [x] **PTC-01** · M · ERR-00 (D1) / ERR-05 · `PeriodTypeController.php:72-112, 155-225, 250-274, 290-314, 359-379, 407-435` — remove the controller `try/catch` from `store`, `update`, `destroy`, `restore` and `toggleStatus` (the same pass already applied to every other TimetableFoundation controller on 2026-10-10):
  - **Shape:** `return DB::transaction(fn …)`; the closure returns the model, the `redirect()`/JSON is built after it (see PTC-… no change to flashes or route names).
  - **Errors:** let the central handler render. For the AJAX `toggleStatus`, the handler returns JSON for `expectsJson()` callers.
  - `forceDelete` is handled by PTC-13 (its single `DomainException` catch is the D2 exception). Effort: S.

## 4. Authorization (F3)
- [x] **PTC-02** · L · AUTH-04 · `PeriodTypeController.php:70, 151` — drop the duplicate `Gate::authorize` in `store`/`update` and keep the FormRequest `authorize()` (it runs first). The unreachable-`PeriodTypePolicy` question is module-wide, so it is **not** fixed here. Effort: S.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **PTC-03** · M · VAL-07 / CTL-05 · `PeriodTypeController.php:77-91, 176-187` + `PeriodTypeRequest.php` — move the `is_break`-forces-flags rule into the FormRequest's `after()` hook (or a model mutator) once, and delete the duplicated block from both `store` and `update`. Keep behaviour identical. Effort: S.
- [x] **PTC-04** · H · DECISION · RTE-01 · `routes/web.php:207` — Restore runs over GET.
      (a) ⭐ Change it to `Route::patch('/period-type/{id}/restore', …)`. The component `action-trashed` derives the verb from the route, so no blade edit is needed; the only caller is `trash.blade.php:40`. ⚠ This changes a route, so it needs explicit approval.
      (b) Leave it as GET and accept the CSRF/prefetch risk.
      ➜ Choice: (a) — PATCH restore, plus {periodType} binding (2026-10-12)
- [x] **PTC-08** · M · DECISION · MDL-01 · `PeriodType.php:36` — `$fillable` lists `created_by`, but `tt_period_types` has no such column.
      (a) ⭐ Remove `'created_by'` from `$fillable` (matches the sibling `DayType` model's documented decision). ⚠ SHARED — the model is reached by PeriodSet/PeriodConfig controllers; the change is one array entry.
      (b) Add an additive migration adding a `created_by` column, and set it on create.
      ➜ Choice: (a) — removed from $fillable (2026-10-12)
- [x] **PTC-09** · L · STY / MDL-04 · `PeriodType.php:82, 87, 92, 97, 102, 113` — add return types (`: Builder` on the five scopes, `: HasMany` on `periodSetPeriods()`). ⚠ SHARED — model reached by other controllers; type-hint only, no behaviour change. Effort: S.

## 6. Queries & performance (F9)
_None — trash paginates 10, show/edit load a single record, no loop queries, no `::all()`._

## 7. Behaviour decisions (F13)
- [x] **PTC-14** · M · DECISION · `PeriodTypeController.php:250-263` — trashing a period type that children still reference is allowed with no check.
      (a) ⭐ Refuse to trash when `tt_period_configs` or `tt_period_set_periods_jnt` rows reference it, using the same counts as PTC-13 (`\DomainException` → flash). Trashing is reversible, but a referenced type silently vanishing is worse than a clear refusal.
      (b) Leave as is: allow the trash and let the admin restore if a child row breaks.
      ➜ Choice: (a) — refuse trash and permanent delete while in use (2026-10-12)

## 8. Style (F12) — one item per file
- [x] **PTC-06** · L · CTL-04 · `PeriodTypeController.php` (11 methods) — add return types (`: View`, `: RedirectResponse`, `: JsonResponse`). Effort: S.
- [x] **PTC-12** · L · STY-01 · `PeriodTypePolicy.php:1` — add `declare(strict_types=1);`. Effort: S (trivial).

## 9. Views (F10)
- [x] **PTC-10** · L · orphan · `views/period-type/index.blade.php` (48 lines) and `views/period-type/create.blade.php` (159 lines) — delete both. Before deleting, re-prove at fix time that no `view()`/`@include` references either (`grep -rn "period-type.index\|timetablefoundation::period-type.create"` → only comments/tests). Effort: S.
- [x] **PTC-11** · L · copy · `views/period-type/trash.blade.php:50` — change "No trashed period days found" to "No trashed period types found". Effort: S.

## 10. Deferred
_None. The controller is 437 lines / 11 methods — no CTL-01 split. `create()` is already D5-compliant (`abort(403)` + NOT ROUTED). No migration is required by any ticked item except an optional PTC-07(b)/PTC-08(b) choice._

> **How to approve**
> 1. Tick `[x]` on each item to apply.
> 2. Fill every `➜ Choice:` on the ticked DECISION items (PTC-07, PTC-04, PTC-08, PTC-14).
> 3. Then run `final-audit-fixer` on `Modules/TimetableFoundation/app/Http/Controllers/PeriodTypeController.php`. It applies only ticked items, in this order.
