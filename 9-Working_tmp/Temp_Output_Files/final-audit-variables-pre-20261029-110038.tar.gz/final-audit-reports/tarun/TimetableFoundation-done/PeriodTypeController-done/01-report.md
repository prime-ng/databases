# Final Audit — TimetableFoundation / PeriodTypeController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/PeriodTypeController.php` (437 lines, 11 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 2 HIGH.**

The write paths are structurally sound: every mutation runs in one `DB::transaction`, `activityLog()` sits inside it after the write, and no exception text reaches a user. But two things can lose or expose data on a real screen: **Delete Permanently accepts a live (non-trashed) record**, and **Restore still runs over a GET request**. On top of that, the controller is the only TimetableFoundation controller that never received the 2026-10-10 ERR-00 pass — six methods still carry their own `try/catch`.

The worst finding is **PTC-13**: `forceDelete()` resolves with `withTrashed()->findOrFail($id)`, so a crafted DELETE to `/period-type/2/force-delete` permanently destroys a live period type with no warning. Seven of the nine live rows have no children, so the delete succeeds silently.

The effort is roughly half a day. Four DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 2 | 6 | 6 | 4 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PTC-01 | F8 Services/Jobs | clean: no service, job, event or listener named (`grep -nE 'Service\|Job\|Event\|dispatch\|event\(' $C` → none) |
| F2 Transactions/Audit | clean: all 6 mutations use one `DB::transaction` closure with `activityLog()` inside, after the write | F9 Queries/Perf | clean: trash paginates 10; single-record show/edit; no `::all()`, no loop queries |
| F3 Authorization | PTC-02 | F10 Views | PTC-10 (orphans), PTC-11 (copy) |
| F4 Validation | PTC-03 | F11 Security/Tenancy | clean: no `env()`, no PII in JSON, 8/8 permissions seeded exact-match, tenant middleware present |
| F5 Routes | PTC-04; `create()` unrouted but already D5-compliant | F12 Style | PTC-12 |
| F6 Controller shape | PTC-05, PTC-06, PTC-07 | F13 Deep read | PTC-13, PTC-14 |
| F7 Models | PTC-08, PTC-09 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/PeriodTypeController.php` | controller | 437 | this report | ✅ whole class |
| 2 | `app/Http/Requests/PeriodTypeRequest.php` | FormRequest | 173 | this report | ✅ whole class |
| 3 | `app/Models/PeriodType.php` | model | 117 | **this report (pre-assigned/claimed)** | ✅ |
| 4 | `app/Policies/PeriodTypePolicy.php` | policy | 44 | this report | ✅ — unreachable, §7 |
| 5 | `routes/web.php:204-209` | routes | 6 | this report | ✅ |
| 6 | `app/Providers/RouteServiceProvider.php:43-57` | middleware group | 15 | common | checked — tenancy + auth confirmed |
| 7 | `views/period-type/show.blade.php` | page | 95 | this report | ✅ — compiles |
| 8 | `views/period-type/edit.blade.php` | page | 166 | this report | ✅ — compiles |
| 9 | `views/period-type/trash.blade.php` | page | 68 | this report | ✅ — compiles |
| 10 | `views/period-type/index.blade.php` | page (orphan) | 48 | this report | ✅ — unreachable, PTC-10 |
| 11 | `views/period-type/create.blade.php` | page (legacy, orphan) | 159 | this report | ✅ — unreachable, PTC-10 |
| 12 | `views/period-type/_create-modal.blade.php` | partial (modal) | 22 | this report (rendered from the masters page) | ✅ — compiles |
| 13 | `views/period-type/_create-fields.blade.php` | partial (fields) | 147 | this report (rendered from the masters page) | ✅ — compiles |
| 14 | `views/pages/partials/timetable-masters/period-types/_list.blade.php` | tab list | 123 | another controller (masters page) | checked usage only — route/permission contract |
| 15 | `views/pages/timetable-masters.blade.php` | page | 51 | another controller (masters page) | checked usage only — `@include` of `_list` |
| — | `PeriodSetPeriod` model | model (other controller) | — | PeriodSetPeriodController report (pre-assigned) | relation only — resolves, §7 |
| — | `x-backend.table.action`, `action-trashed`, `status-switch`, `tab.search-bar`, `tab.modal`, `export-buttons`, `breadcrum`, `form.status-switch`, `form.button-submit` | shared components | — | common | props checked against constructors only |

**Pre-applied 2026-10-10:** this controller does **not** appear in `../PRE-APPLIED-2026-10-10.md`. It is the only TimetableFoundation controller in this batch that kept its original `try/catch` model — see PTC-01.

## 4. Routes

```
GET|HEAD  timetable-foundation/period-type                             timetable-foundation.period-type.index        index
POST      timetable-foundation/period-type                             timetable-foundation.period-type.store        store
GET|HEAD  timetable-foundation/period-type/trash/view                  timetable-foundation.period-type.trashed      trashedPeriodType
DELETE    timetable-foundation/period-type/{id}/force-delete           timetable-foundation.period-type.forceDelete  forceDelete
GET|HEAD  timetable-foundation/period-type/{id}/restore                timetable-foundation.period-type.restore      restore   ← GET (PTC-04)
POST      timetable-foundation/period-type/{periodType}/toggle-status  timetable-foundation.period-type.toggleStatus toggleStatus
GET|HEAD  timetable-foundation/period-type/{period_type}               timetable-foundation.period-type.show         show
PUT|PATCH timetable-foundation/period-type/{period_type}               timetable-foundation.period-type.update       update
DELETE    timetable-foundation/period-type/{period_type}               timetable-foundation.period-type.destroy      destroy
GET|HEAD  timetable-foundation/period-type/{period_type}/edit          timetable-foundation.period-type.edit         edit
```

_Method evidence:_ `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` filtered for `PeriodTypeController@`.

Middleware on every route (from `RouteServiceProvider::mapWebRoutes`): `web, InitializeTenancyByDomain, PreventAccessFromCentralDomains, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`.

**Unrouted public methods:** `create()` (line 48). It is excluded by `Route::resource(...)->except(['create'])` and its body is already `abort(403, '…')` under a `// NOT ROUTED` comment — the D5 shape, applied before this audit. No action needed.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect only) | — |
| create | ❌ | **none** | — | — | — (abort) | D5-compliant |
| store | ✅ | create (+ request) | ✅ closure | `Stored` | tt_period_types, sys_activity_logs | PTC-01, 02, 03 |
| show | ✅ | view | — | — | — | PTC-05, 06 |
| edit | ✅ | update | — | — | — | PTC-05, 06 |
| update | ✅ | update (+ request) | ✅ closure | `Updated` (with diff) | tt_period_types, sys_activity_logs | PTC-01, 02, 03, 05, 07 |
| destroy | ✅ | delete | ✅ closure | `Trashed` | tt_period_types, sys_activity_logs | PTC-01, 05, 14 |
| restore | ✅ GET | restore | ✅ closure | `Restored` | tt_period_types, sys_activity_logs | PTC-01, 04, 05 |
| trashedPeriodType | ✅ | restore | — | — | — (paginate 10) | PTC-11 |
| forceDelete | ✅ | forceDelete | ✅ closure | `Deleted` | tt_period_types, sys_activity_logs | PTC-01, 05, 13 |
| toggleStatus | ✅ | update | ✅ closure | `Toggled` | tt_period_types, sys_activity_logs | PTC-01, 06 |

**Tables each mutation SHOULD touch:**
- **store / update / destroy / restore / toggleStatus** should write the period-type row plus the activity log. They do, in one transaction each.
- **forceDelete** should first account for its two FK children (`tt_period_configs`, `tt_period_set_periods_jnt`). It checks neither. See PTC-13.

## 6. Findings

### F1 — Errors
#### PTC-01 · M · ERR-00 (D1) + ERR-05 — six methods still carry a controller `try/catch`
**Where:** `PeriodTypeController.php` — `store:72-112`, `update:155-225`, `destroy:250-274`, `restore:290-314`, `forceDelete:359-379`, `toggleStatus:407-435`
```php
} catch (\Throwable $e) {
    report($e);
    return redirect()->back()->with('error', flash('operation_failed.period_type'))->withInput();
```
**Evidence:** `grep -n "catch (\\\\Throwable" $C` → 6 hits at lines 105, 218, 268, 308, 373, 427. `report($e)` is present (ERR-05 clean) and the messages are fixed (`flash('operation_failed.period_type')` / `flash('status_switch_failed.period_type')`, ERR-01 clean). The finding is the catch itself: under D1 the Laravel idiom is no controller try/catch — `DB::transaction()` rolls back and rethrows, and `bootstrap/app.php` renders the response. The 2026-10-10 pass converted every other TimetableFoundation controller; this one was missed.
**Consequence:** six failure paths render a page-specific flash instead of the central handler's response (and for the AJAX toggle, a hand-built `{success:false}` JSON), so error handling is split across two models and any future `\DomainException` added here will not surface correctly.

### F3 — Authorization
#### PTC-02 · L · AUTH-04 — store/update authorize the same permission twice
**Where:** `PeriodTypeController.php:70, 151` (Gate) vs `PeriodTypeRequest.php:75` (FormRequest `authorize()`)
**Evidence:** `PeriodTypeRequest::authorize()` calls `authorizeByCrudPermission('tenant.timetable-foundation.period-type')` → `.create` on POST / `.update` on PUT, exactly the strings the controller also checks. The request runs first, so the controller gate narrows nothing. The scanner flags `AUTH-04` at lines 68 and 149.
**Consequence:** none at runtime (permission is identical); it is duplicated authorization work and a drift risk if one side is renamed.

### F4 — Validation
#### PTC-03 · M · VAL-07 + CTL-05 — the `is_break` business rule and the colour-presence rule live in the controller, duplicated between store and update
**Where:** `PeriodTypeController.php:77-91` (store) and `:176-187` (update)
```php
if ($validated['is_break']) {
    $validated['is_schedulable'] = false;
    $validated['counts_as_teaching'] = false;
    $validated['counts_as_workload'] = false;
}
if (! $request->has('color_code')) {
    $validated['color_code'] = null;
}
```
**Evidence:** the same two blocks appear verbatim in both methods (`grep -n "is_break\|color_code" $C`). VAL-07 puts cross-field/business checks in the FormRequest `after()` hook; the business rule (a break period is not schedulable/teaching/workload) is an invariant that belongs on the model or the request, not in two controller methods.
**Consequence:** any other write path (seeder, import, a future bulk action) that sets `is_break = true` bypasses the rule and can persist a break period that still counts as teaching; the two copies can drift apart on the next edit.

### F5 — Routes
#### PTC-04 · H · RTE-01 — Restore runs over a GET request
**Where:** `routes/web.php:207` — `Route::get('/period-type/{id}/restore', …)->name('period-type.restore')`
**Evidence:** `route:list` shows `GET|HEAD …/{id}/restore`. The only caller is `views/period-type/trash.blade.php:40` via `<x-backend.table.action-trashed>`, which derives the HTTP verb from the route — so changing the verb needs no blade edit.
**Consequence:** GET has no CSRF protection, so a link preview, a prefetcher, or a crafted `<img src>` can restore a trashed period type without the user acting.

### F6 — Controller shape
#### PTC-05 · M · CTL-03 — six methods use `$id` + `findOrFail` instead of route model binding
**Where:** `PeriodTypeController.php:118` (show), `:130` (edit), `:149` (update), `:235` (destroy), `:284` (restore), `:344` (forceDelete)
**Evidence:** `show($id)`, `edit($id)`, `update(PeriodTypeRequest $request, $id)`, `destroy($id)`, `restore($id)`, `forceDelete($id)` — the resource routes expose `{period_type}`, but none of these type-hint `PeriodType`. `toggleStatus(Request $request, PeriodType $periodType)` is the only one that binds (scanner `CTL-03` at 6 lines).
**Consequence:** no `withoutTrashed`/`onlyTrashed` scoping is expressed in the signature, and each method repeats the manual load — part of how PTC-13 slipped in.

#### PTC-06 · L · CTL-04 — no return types on any of the 11 public methods
**Where:** `PeriodTypeController.php` — all public method signatures
**Evidence:** scanner `CTL-04` at 11 lines; `grep -nE 'public function [a-zA-Z_]+\([^)]*\)($|\s*\{)' $C` shows no `: View` / `: RedirectResponse` / `: JsonResponse`.
**Consequence:** callers and static analysis cannot tell a redirect from a view from JSON; low risk, mechanical to fix.

#### PTC-07 · M · CTL-10 / DDL-drift — the `is_system` guard is dead code over a column that does not exist, and hides a latent crash
**Where:** `PeriodTypeController.php:165, 244, 353, 399`; `PeriodType.php` (no `is_system`); `show.blade.php`/`edit.blade.php` too
```php
if ($periodType->is_system) { … }           // always null → falsy
```
**Evidence:**
- `SHOW COLUMNS` / `information_schema`: `is_system` column exists = **0**; `created_by` column exists = **0** (see PTC-08).
- All four guard branches are unreachable. `update:167-172` unsets the four boolean keys inside the guard, then `:176` reads `$validated['is_break']` — if the branch ever became reachable it would throw **"Undefined array key is_break"**. Latent, currently masked by the missing column.
- The two messages it flashes, `flash('system_record_force_delete_not_allowed')` (`:356`) and `flash('system_record_status_change_not_allowed')` (`:403`), are **not defined** in `config/flash.php` or `lang/`, so they resolve to `''` — an empty error toast.
**Consequence:** the controller reads as if it protects system records, but it protects nothing; a future additive migration for `is_system` would immediately break `update()` and show empty messages. The class docblock (G5, lines 26-30) already admits this.

### F7 — Models
#### PTC-08 · M · MDL-01 / DDL-drift — `PeriodType::$fillable` lists `created_by`, but `tt_period_types` has no such column
**Where:** `PeriodType.php:36` (`'created_by'`)
**Evidence:** `SHOW CREATE TABLE tt_period_types` has 16 columns and no `created_by`; `information_schema` column-exists count = 0. The sibling `DayType` model (line 21-22) explicitly documents that `created_by` is **not** fillable for exactly this reason.
**Consequence:** any future `PeriodType::create($data)` carrying `created_by` throws SQL 1054 (unknown column). Today it is inert only because no form field and no validation rule produce the key — dead `$fillable` entry.

#### PTC-09 · L · MDL-04 — the relationship (and the five scopes) have no return types
**Where:** `PeriodType.php:82, 87, 92, 97, 102, 113`
**Evidence:** scanner `MDL-04` at `PeriodType.php:113`; `periodSetPeriods()` has no `: HasMany`. Proven to resolve in tinker — `PeriodType::find(1)->periodSetPeriods()->count()` → **24**. The scopes (`scopeActive`, `scopeSchedulable`, `scopeTeaching`, `scopeBreaks`, `scopeOrdered`) likewise lack `: Builder`.
**Consequence:** style/IDE only; no runtime effect.

### F10 — Views
#### PTC-10 · L · orphan views — `period-type/index.blade.php` and `period-type/create.blade.php` are unreachable
**Where:** `views/period-type/index.blade.php` (48 lines), `views/period-type/create.blade.php` (159 lines)
**Evidence:**
- `index()` redirects to the masters page (`:42`) and never returns a view; `grep -rn "period-type.index"` finds no blade/view reference (only the test file `RouteAuthenticationTest.php:85`). The orphan still iterates `$schoolDays` and is titled **"Day Management"** — a copy-paste from another resource.
- `create` is excluded from `Route::resource`; `create()` aborts 403 (`:55`); `grep -rn "timetablefoundation::period-type.create\|period-type/create"` finds no `view()`/`@include` — only comment text. The live create UI is `_create-modal` + `_create-fields`.
**Consequence:** two dead blades that will drift from the live modal and mislead the next reader.

#### PTC-11 · L · copy — the empty-state text says "period days"
**Where:** `views/period-type/trash.blade.php:50` — `No trashed period days found`
**Evidence:** the resource is a **period type**, not a day; copy-pasted from the day-type trash blade.
**Consequence:** a user who empties the trash sees the wrong resource name.

### F12 — Style
#### PTC-12 · L · STY-01 — `PeriodTypePolicy` is missing `declare(strict_types=1)`
**Where:** `PeriodTypePolicy.php:1-3`
**Evidence:** scanner `STY-01`; the controller, request and model all declare it, the policy does not.
**Consequence:** inconsistent; no runtime effect.

### F13 — Deep read
#### PTC-13 · H · deep read — Delete Permanently works on a live record and checks no children
**Where:** `PeriodTypeController.php:348`
```php
$periodType = PeriodType::withTrashed()->findOrFail($id);   // a LIVE id is accepted
```
**Evidence:**
- `withTrashed()` matches live rows too, so `DELETE /period-type/2/force-delete` skips the trash entirely. The UI only reaches it from `trash.blade.php`, but the endpoint accepts any id, and the `restore` sibling at `:288` correctly uses `onlyTrashed()`.
- No child guard exists. FK children of `tt_period_types` (measured):
  | Table | Column | ON DELETE | Rows | Referenced ids |
  |---|---|---|---|---|
  | `tt_period_configs` | `period_type_id` | NO ACTION | 9 | 1, 8 |
  | `tt_period_set_periods_jnt` | `period_type_id` | NO ACTION | 27 | 1, 8 |
- Live rows: 9 (`id` 1..9), 0 trashed. Only ids **1 and 8** are referenced. The other **7** have no children, so a force-delete of them **succeeds silently** and permanently destroys a live row.
**Consequence:** a crafted or mistaken DELETE against a live period type with no children wipes it (and its `created_at`/audit trail) for good; against id 1 or 8 the FK raises 1451 and the user sees the generic "Failed to perform the operation." Both outcomes are wrong for a trash-only action.

#### PTC-14 · M · deep read — a soft-deleted period type can still be referenced, and trashing is not blocked
**Where:** `PeriodTypeController.php:250-263`
**Evidence:** `destroy()` sets `is_active = false`, soft-deletes, and logs — but never checks the two FK child tables. Today 9 `tt_period_configs` and 27 `tt_period_set_periods_jnt` rows point at ids 1 and 8; trashing either leaves those rows pointing at a row invisible to every default SoftDeletes query.
**Consequence:** the timetable-config grid and period-set membership keep foreign keys to a trashed type, which silently disappears from dropdowns while its child rows remain — inconsistent data until someone force-deletes or restores. Soft delete is reversible, so the risk is contained.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`PeriodTypePolicy` is unreachable.** It is registered at `TimetableFoundationServiceProvider.php:132` (`Gate::policy(PeriodType::class, PeriodTypePolicy::class)`), but every guard in the controller and request passes a permission **string** to `Gate::authorize`/`Gate::allows`, which never reaches the policy. This is the same module-wide pattern recorded in the AcademicTermController report (ATC-14).
- **`SmartTimetable` calls the retired create route.** `Modules/SmartTimetable/resources/views/smart-timetable/partials/period-types/_list.blade.php:42` renders `route('timetable-foundation.period-type.create')`, but that route is excluded and does not exist (`route:list` has no `period-type.create`; `grep` of `routes/web.php` finds no definition). If that blade renders, `route()` throws `RouteNotFoundException` → 500. Prefixing with `Route::has(...)` or pointing at the create modal is a SmartTimetable fix, outside this report.
- **`_list.blade.php` / `_create-modal` / `_create-fields` are rendered by `TimetableFoundationController`'s masters page** (rows 14-15 above). Their route/permission contract was checked here (all names valid), but the query that builds `$periodTypes` (a `pt_page` paginator at `TimetableFoundationController.php:469`) belongs to that controller's report.
- **`PeriodSetPeriod` model** is reached only through `PeriodType::periodSetPeriods()`; it is pre-assigned to the PeriodSetPeriodController report. The relation resolves (24 rows) — this report only confirms the FK usage.

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static, a read-only SQL probe, or a `compileString` check.
- **Other writers of `tt_period_types`:** `TtPeriodTypeSeeder` and any importer were not audited. PTC-03's and PTC-13's risk partly come from them.
- **The `TimetableFoundationController` masters query** that feeds `_list.blade.php` — another controller's report.
- **Data repair:** none performed or proposed; changing data is out of scope.
