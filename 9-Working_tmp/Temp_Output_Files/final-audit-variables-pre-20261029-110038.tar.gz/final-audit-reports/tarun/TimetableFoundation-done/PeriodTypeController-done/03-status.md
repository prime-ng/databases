# 03 — Status · PeriodTypeController

**Fixed:** 2026-10-12 · **By:** claude · **Branch:** development
**Decisions (Tarun):** PTC-13 + PTC-14 (a) refuse trash and permanent delete while in use · PTC-04 (a) PATCH restore, plus `{periodType}` binding · PTC-07 (c) remove the dead `is_system` guards · PTC-08 (a) drop `created_by` from `$fillable`.

## 1. Pre-applied 2026-10-10
None.

## 2. Applied

| ID | File:line | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| PTC-13 | PeriodTypeController `forceDelete()` | `onlyTrashed()->findOrFail()`; `refuseIfInUse()` counts `tt_period_configs` and `tt_period_set_periods_jnt` (both NO ACTION FKs); only `DomainException` caught (ERR-01) | probe: forceDelete a LIVE id | 404 | 2026-10-12 |
| PTC-14 | `destroy()` | same `refuseIfInUse()` before trashing | probe: destroy THEORY | "Period type "Theory / Lecture" cannot be moved to trash: it is still used by 8 period config(s), 24 period-set period(s)." — row stays live | 2026-10-12 |
| PTC-01 | all 5 mutations | try/catch, `report()` and the `operation_failed` / `status_switch_failed` fallbacks removed; transactions kept; `activityLog` inside them, after the write | `grep -c "Throwable\|report("` | 0 | 2026-10-12 |
| PTC-02 | `store()`, `update()` | duplicate `Gate::authorize` removed; `PeriodTypeRequest::authorize()` gates them | read | — | 2026-10-12 |
| PTC-03 | PeriodTypeRequest `prepareForValidation()` | the "a break is never schedulable / teaching / workload" rule moved here from the two copies in store/update. Put in `prepareForValidation()`, not `after()`/`passedValidation()`, because a merge there does not reach `validated()` | probe: POST is_break=1 with all three flags on | all three `false` in `validated()` | 2026-10-12 |
| PTC-04 | routes/web.php | restore `Route::get` → `Route::patch`; `action-trashed` derives the verb, no blade edit | route:list | `PATCH timetable-foundation/period-type/{id}/restore` | 2026-10-12 |
| PTC-05 | routes/web.php + controller + request | `->parameters(['period-type' => 'periodType'])`; show/edit/update/destroy bind `PeriodType $periodType` (restore/forceDelete keep `$id`); request reads `route('periodType')` | route:list + probe | OK | 2026-10-12 |
| PTC-06 | controller | return types on all 11 methods (`View`, `RedirectResponse`, `JsonResponse`, `never`) | php -l, Pint | clean | 2026-10-12 |
| PTC-07 | controller + docblock | the four `is_system` branches deleted (the column does not exist; the one in `update()` would have crashed on `is_break` if ever reached); docblock rewritten | `grep -c is_system` controller | 0 | 2026-10-12 |
| PTC-08 | PeriodType model | `'created_by'` removed from `$fillable` | probe | not fillable | 2026-10-12 |
| PTC-09 | PeriodType model | `Builder` on the five scopes, `HasMany` on `periodSetPeriods()` | php -l | clean | 2026-10-12 |
| PTC-10 | views/period-type/index.blade.php, create.blade.php | deleted after re-proving no `view()`/`@include` reference (`index()` redirects, `create()` aborts 403) | grep | 0 refs | 2026-10-12 |
| PTC-11 | views/period-type/trash.blade.php:50 | "No trashed period days found" → "No trashed period types found" | grep | 1 | 2026-10-12 |
| PTC-12 | PeriodTypePolicy | `declare(strict_types=1);` | php -l | clean | 2026-10-12 |

Probe (rolled back, 0 rows left): destroy refused → is_break forced → live purge 404 → trash → restore → trash → purge; activity log `Trashed,Restored,Trashed,Deleted`.

## 3. Not applied
None — all 13 plan items ticked. PTC-05 was a report finding with no separate plan item; it was applied together with PTC-04 because both edit the same route line.

## 4. Needs Tarun's hand
- **TtPeriodTypeTest `test_25_not_found_restore`** (identical copy in `prime_ai_dev/tests/...` and `prime_testing/tests/...`) visits `GET /timetable-foundation/period-type/999999999/restore` and expects 404. Restore is PATCH now, so expect 405 (or the DecryptUrl redirect). Same as TtShiftTest and TtDayTypeTest test_25. `test_12` (restore via the button) and `test_13` (force delete of a fresh, childless fixture) are unaffected. Not edited (D4).
- Browser check: trash "Theory / Lecture" from the Period Types tab → red message naming both tables.
- `PeriodTypeController.php` flash keys `operation_failed.period_type` and `status_switch_failed.period_type` are no longer used by this controller; the central handler now renders failures.

## 5. Unverifiable by this workflow (D4)
None beyond the Dusk run above.

## 6. Verification log
- `php -l` on the controller, request, model, policy and routes: no syntax errors.
- `vendor/bin/pint <5 files> --format agent`: fixed import order in PeriodTypeRequest only.
- `php artisan route:list --path=period-type`: 10 routes, restore PATCH, resource uses `{periodType}`.
- Rolled-back probe `scratchpad/pt2.php`: output quoted in §2.

## 7. Final state
FIXED. Open: 0 B · 0 H · 0 M · 0 L from this report. Cross-cutting (not this controller): the SmartTimetable partial `period-types/_list.blade.php:42` links to `timetable-foundation.period-type.create`, a route excluded long before this pass — RouteNotFoundException when that branch renders. `RouteAuthenticationTest` still lists `period-type.index` / `.create`.
