# Fix Plan — TimetableFoundation / SlotRequirementController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/SlotRequirementController.php`.
>    It applies **only** ticked items, in this order.
> 5. This controller has no migration. A new permission key is seeded by your hand
>    (`/system-config/sync-permissions`), never by the fixer.

## 1. Blockers reachable today
- [x] **SLR-17** · H · DECISION · deep read / data loss · `SlotRequirementController.php:80` +
      `RequirementTableTruncator.php:80-85` — Generate for one term+type TRUNCATEs slot requirements
      for **every** term/type and empties `tt_priority_configs`; only the selected pair is rebuilt.
      (a) ⭐ Keep the staged truncate as designed, but make the disclosure unavoidable: keep the
          confirm text (already correct) and add a code comment at line 80 citing SLR-17. No behaviour
          change — lowest risk, and the module's tab-lock already forces a re-run of later tabs.
      (b) Scope the truncate to the selected `(academic_term_id, timetable_type_id)` pair only
          (`RequirementTableTruncator` gains a scoped mode, or the controller does a scoped
          `DELETE` instead of `truncateFrom`). Removes the data loss but changes the "ids restart at 1"
          contract and touches the **shared** truncator owned by RequirementConsolidationController.
      (c) Leave as is, record as accepted.
      ➜ Choice: (a) keep the design; SLR-17 comment added at the truncate call (Tarun, 2026-10-14)
      Effort: (a) S · (b) M (⚠ touches a linked/shared class).

## 2. Fixes that arm a latent defect (sequenced)
- [x] **SLR-20** · L · deep read · `SlotRequirementController.php:241` — the `updateOrInsert` matches
      the unique key `uq_sa_class_section`, which excludes `deleted_at`, and bypasses SoftDeletes.
      **Fix this before SLR-17(b).** Add `whereNull('deleted_at')` to the match (or explicitly clear
      `deleted_at` in the update payload) so a narrow truncation can never revive a trashed row
      invisibly. Latent today because the table is truncated first. Effort: S.

## 3. Errors & transactions (F1/F2)
- [x] **SLR-01** · L · ERR-00 / D2 · `SlotRequirementController.php:214` — the allowed
      truncate-rebuild catch already has `report($e)` + a fixed message; add the missing
      `// Truncate-rebuild catch — allowed by D2 (ERR-01, 2026-10-10)…` comment so it cannot be read as
      an ERR-00 violation. Mirror `SlotRequirementGridService.php:123`. Effort: S.
- [x] **SLR-18** · M · DECISION · TXN-06 / deep read · `SlotRequirementController.php:80-209` — no lock
      around truncate + rebuild; two concurrent POSTs can interleave.
      (a) ⭐ Guard the method with `Cache::lock('slot-requirement-generate:'.tenant('id'), 30)` and
          return a friendly "already running" flash on a second hit — tenant-scoped key (TEN-02).
      (b) Leave it; the operation is admin-triggered and rare.
      ➜ Choice: (a) Cache::lock keyed by tenant id, 30s, "already running" flash (Tarun, 2026-10-14)
      Effort: S.

## 4. Authorization (F3)
- [x] **SLR-02** · M · DECISION · AUTH-06 · `SlotRequirementController.php:62` + ⚠ SHARED
      `config/permissionslist.php:695` — the destructive regenerate is gated by `…slot-requirement.create`.
      (a) ⭐ Add a `generate` verb to `'timetable-foundation.slot-requirement' => array_merge($crud, ['generate'])`
          and gate the method on `tenant.timetable-foundation.slot-requirement.generate`. The role that
          may wipe the table is then a deliberate grant. ⚠ SHARED — needs its own tick; seeding the new
          key is **your hand** (`/system-config/sync-permissions`), and until it is seeded no role but
          Super Admin can generate.
      (b) Keep `.create` and record it as accepted.
      ➜ Choice: (a) new `generate` verb; gate, FormRequest and blade moved to it (Tarun, 2026-10-14)
      Effort: S (+ your sync-permissions run).

## 5. Validation, routes, models (F4/F5/F7)
- [x] **SLR-04** · M · VAL-02 · `SlotRequirementController.php:68-71` — move the two rules into the
      existing `GenerateSlotRequirementRequest`, type the method as that request, and drop the inline
      `$request->validate()`. The dispatcher that required a plain `Request` was retired 2026-10-06.
      Effort: S.
- [x] **SLR-05** · L · VAL-04 · `SlotRequirementController.php:69-70` — make the `exists` rules
      soft-delete-aware (`Rule::exists('sch_academic_term','id')->whereNull('deleted_at')`, same for
      `tt_timetable_types`) so a trashed term/type id cannot be generated against. Effort: S.
- [x] **SLR-09** · L · CTL-04 · `SlotRequirementController.php:60` — add a return type
      (`: RedirectResponse`) once SLR-04 changes the parameter type. Effort: S.
- [x] **SLR-11** · L · STY-02 · `SlotRequirement.php` — run `vendor/bin/pint` on the model only
      (`no_unused_imports`, `class_attributes_separation`, `single_line_after_imports`). ⚠ SHARED —
      8+ files reference the model; the change is formatting only. Effort: S.
- [x] **SLR-10** · L · STY-01 · `SlotRequirement.php:1` — add `declare(strict_types=1);`. Effort: S.

## 6. Queries & performance (F9)
- [x] **SLR-12** · H · QRY-01 · `SlotRequirementController.php:158-162` — pre-fetch active sections for
      all class-level rows once (`sch_class_section_jnt` keyed by `class_id`), then read from the map
      inside the loop. Also select only `class_id, section_id`. Latent today (`applies_to_all_sections=1`
      rows = 0). Effort: S.
- [x] **SLR-13** · H · QRY-01 · `SlotRequirementController.php:197-206` — stop re-fetching each id:
      build the log rows by id (or `SlotRequirement::whereIn('id',$generatedIds)->get()->keyBy('id')`
      once) before the log loop. Effort: S.
- [x] **SLR-14** · M · QRY-07 · `SlotRequirementController.php:241-265` — replace the per-row
      `updateOrInsert` + re-`SELECT` with one chunked `upsert()` (the unique key is known), keeping the
      generated ids available for SLR-13. Effort: M.

## 7. Views (F10)
_None — the controller renders no view._

## 8. Style (F12) — one item per file
- [x] **SLR-15** · L · STY-04 · `SlotRequirementController.php:34` and
      `SlotRequirementGridService.php:27,152` — replace the emoji markers (`⚠`, `⛔`) with words. Effort: S.
- [x] **SLR-16** · L · STY-01 · `SlotRequirementGridService.php:1` — add `declare(strict_types=1);`. Effort: S.

## 9. Deferred / decisions
- [x] **SLR-06 + SLR-07 + SLR-08** · H/M · DECISION · CTL-01 / CTL-02 / CTL-05 / CTL-06 — the
      163-line `generateSlotRequirement()` should become a `SlotRequirementGenerator` service.
      (a) ⭐ Defer to the split pass (D3) as one unit: extract step 1, step 2 and the upsert into a
          service, fix SLR-08 (merge the two duplicated loops) at the same time, and have the
          controller call one service method. Keeps this pass behaviour-neutral.
      (b) Extract now, in this pass, keeping the fixed route/URL (D3 allows same-file/service moves).
      (c) Leave as is, record as accepted.
      ➜ Choice: (a) deferred to the split pass, D3 (Tarun, 2026-10-14)
      Effort: (a) — · (b) M.
- [x] **SLR-19** · L · DECISION · deep read · `SlotRequirementController.php:125,164` — `?? 8`
      silently invents a teaching count when `period_set_id` is unknown.
      (a) ⭐ Fail loudly: throw a `\DomainException` naming the class/row whose period set is missing,
          caught only as `DomainException` and shown as a flash (D2). Prevents a fabricated requirement.
      (b) Keep `?? 8` as a deliberate default; add a comment saying so.
      ➜ Choice: (a) DomainException, thrown before the truncate (plan recommendation; not asked separately — see 03-status)
      Effort: S.
- [ ] **SLR-03** · L · DEFERRED (cross-cutting) · `SlotRequirementPolicy.php`,
      `SlotRequirementRequest.php`, `GenerateSlotRequirementRequest.php` — dead/unreachable classes.
      The unreachable-policy pattern is module-wide (every gate passes a permission string). **Not fixed
      in this controller's pass** — it needs one module-level decision alongside `ATC-14`. Recorded here
      so it is not lost. No checkbox.
