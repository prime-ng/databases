# Status — TimetableFoundation / SlotRequirementController

**Fixed:** 2026-10-14 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — 17 items ticked, all applied or recorded. SLR-03 has no checkbox (deferred, cross-cutting).

---

## 1. Pre-applied work (2026-10-10)

From `PRE-APPLIED-2026-10-10.md:42`:

| File | Recorded as pre-applied | Re-measured 2026-10-14 |
|---|---|---|
| `SlotRequirementGridService` | "the catch now `report($e)` + a fixed message" | ❌ **Not true.** Line 125 still returned `'The slot grid could not be built: '.$e->getMessage()`. Fixed in this pass (§2.1 item 1). |

---

## 2. Applied

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| SLR-17 (a) | `SlotRequirementController.php:88-92` | The truncate stays as designed (all terms and types, ids restart at 1). A comment at the call cites SLR-17 and the 2026-10-14 decision. The confirm dialog already says every term and type is cleared, so it was not changed. | `grep -n "SLR-17" <controller>` | lines 37, 88 |
| SLR-20 | controller, upsert | The update column list includes `deleted_at`, and every row sets it to `null`. A match on a trashed row is therefore revived explicitly, never left trashed with new numbers. | rolled-back upsert of 43 rows | ok, row count unchanged |
| SLR-01 | controller `catch (Throwable)` | The truncate-rebuild catch carries its D2/ERR-01 comment. Its message now also says "The error has been logged." | read lines 131-138 | as described |
| SLR-18 (a) | controller `generateSlotRequirement()` | `Cache::lock('slot-requirement-generate:'.tenant('id'), 30)`. A second click while a run holds the lock gets "Slot requirement generation is already running. Please try again shortly." The lock is released in `finally`. The key carries the tenant id because `CacheTenancyBootstrapper` is disabled. | kernel replay with the lock held | 302, that message, 43 rows untouched |
| SLR-02 (a) ⚠ SHARED | `config/permissionslist.php` + controller + request + blade | `'timetable-foundation.slot-requirement' => array_merge($crud, ['generate'])`. The controller gate, `GenerateSlotRequirementRequest::authorize()` and the generate form's `@if` all use `tenant.timetable-foundation.slot-requirement.generate`. | exact-name query | declared ✅ · **seeded ❌** (see §4.1) |
| SLR-04 | controller + `GenerateSlotRequirementRequest.php` | The method type-hints the FormRequest and reads `validated()`. The inline `$request->validate()` is gone. The request's docblock was corrected: it said rows are hard-deleted per term+type, but they are truncated for every term and type. | kernel replay with term 999999 | 302, error on `academic_term_id`, 43 rows untouched |
| SLR-05 | request `rules()` | `Rule::exists('sch_academic_term','id')->whereNull('deleted_at')` and the same for `tt_timetable_types`, plus `integer`. Both tables have `deleted_at` (checked live). | as above | trashed or unknown ids refused |
| SLR-09 | controller | Return type `: RedirectResponse`. | `php -l` | OK |
| SLR-10 | `SlotRequirement.php` | `declare(strict_types=1)`. | `class_exists` | OK |
| SLR-11 ⚠ SHARED | `SlotRequirement.php` | Pint: `class_attributes_separation`, `no_unused_imports` (the redundant same-namespace `AcademicTerm` import), `single_line_after_imports`. Formatting only. | `vendor/bin/pint <model> --format agent` | exactly those 3 fixers |
| SLR-12 | controller `activeSectionsByClass()` | One `whereIn('class_id', …)` query for every class-level row, selecting only `class_id, section_id`, grouped by class. This replaces one query per class row. Filters are unchanged (`is_active = 1`). | `buildRows` vs live | identical 43 rows |
| SLR-13 | controller | The log loop reads the rows it wrote with one query (`timetable_type_id` + `academic_term_id`, ordered by id) instead of `find()` per id. One `'Generated'` log per row, inside the transaction, as before. | rolled-back read | 43 |
| SLR-14 | controller | `updateOrInsert` plus a re-SELECT per row became `SlotRequirement::upsert()` in chunks of 500 on the `uq_sa_class_section` key. `upsertSlotRequirement()` was removed. | rolled-back upsert | ok |
| SLR-15 | controller docblock + `SlotRequirementGridService.php:27,149` | Emoji markers replaced with `WARNING:` / `TRAP:`. | `grep -n "⚠\|⛔"` both files | 0 |
| SLR-16 | `SlotRequirementGridService.php` | `declare(strict_types=1)`. The service already casts every DB value explicitly. | `build()` in tinker | ok, all 8 keys |
| SLR-06/07/08 (a) | — | Deferred to the split pass (D3), as one unit. | — | — |
| SLR-19 (a) | controller `requirementRow()` | The `?? 8` fallback is gone. A row with no explicit `weekly_teaching_period_count` and no known period set throws a `DomainException` that names the row and the class. **It is thrown while reading, before the truncate**, so the tables are left intact and the message is shown as written (D2). Live: 0 such rows today. | reflection call on a fake row | message produced |

The controller went from 267 lines to 303. The growth is the read/write split and the docblocks; the two duplicated loops are now one `requirementRow()` helper per row. Merging the loops themselves is part of SLR-08 (deferred).

### 2.1 Applied beyond the ticked plan

1. **`SlotRequirementGridService::build()` catch** (ERR-01 / D2). The pre-applied note was not true. The catch now does `report($e)` and returns "The slot grid could not be built. The error has been logged." The raw exception text no longer reaches the page.
2. **The reads moved ahead of the truncate.** The original read the source rows inside the transaction, after the truncate. They are now built first, in `buildRows()`, so the new SLR-19 check can refuse a run without emptying anything. The writes and logs are still one transaction after the truncate.

---

## 3. Not applied

None. SLR-03 (unreachable `SlotRequirementPolicy` / dead requests) has no checkbox and stays deferred to the module-wide decision. `SlotRequirementPolicy::create()` still names `.create`. Nothing consults it.

---

## 4. Needs Tarun's hand

1. **Seed the new permission: run `/system-config/sync-permissions`**, then grant `tenant.timetable-foundation.slot-requirement.generate` to School Admin. Until then **only Super Admin can generate slot requirements**, and the Generate form is hidden for everyone else. This was agreed when SLR-02 (a) was chosen. Measured 2026-10-14: declared ✅, seeded ❌.
2. **Browser check** of `/timetable-foundation/timetable-requirement?tab=slot-requirements`:
   - as Super Admin, generate term 1 / type 1 and expect 43 rows and the success toast;
   - double-click Generate and expect the second request to get "already running".

---

## 5. Unverifiable by this workflow (D4), and notes

- **The full generate path was not replayed.** `TRUNCATE` commits implicitly and cannot be rolled back, so a kernel replay would have destroyed the live 43 rows. Instead each part was proven separately:
  - `buildRows` against live data (identical 43 rows);
  - the upsert and the log read inside a rolled-back transaction;
  - the SLR-19 throw;
  - the validation and lock refusals through the kernel, which stop before the truncate.
- **The `.generate` refusal cannot be shown yet.** The permission is unseeded, and every role that would be refused is refused for that reason alone (`module-finalization.md` §7.4.1).
- **Cross-module, not changed:** `Modules/SmartTimetable/resources/views/smart-timetable/partials/slot-availability/_list.blade.php:168` posts to the same generate route with no permission gate in the view. With SLR-02 it now 403s for anyone without `.generate`. That file also has stray text in the form tag (`class="card mb-4"php`). Both belong to SmartTimetable's audit.
- **Scanner after the fix:**
  - QRY-01 at line 97 is a false positive: the upsert runs once per chunk of 500, not once per row.
  - The ERR-01 DomainException hit is intended under D2.
  - The AUTH-04 double check (request + controller) uses the same name on purpose.
  - CTL-02 (`buildRows` 84 lines) belongs to the deferred split.

---

## 6. Verification log

```
php -l (controller, request, model, grid service, config/permissionslist.php; before and after Pint) → No syntax errors ×5
class_exists: SlotRequirementController, GenerateSlotRequirementRequest, SlotRequirement,
              SlotRequirementGridService                                   → OK ×4
route probe (APP_ROUTES_CACHE=/tmp/fa-nocache.php)                         → POST slot-requirement/generate,
    method_exists Y, no route params; tenant middleware chain intact
blade compile: slot-requirements/_list                                      → lint ok; @push 0 / startPush 0
tinker / kernel (tenant test.localhost, user 1):
   buildRows(term 1, type 1) vs live tt_slot_requirements                   built=43 live=43 identical=YES
   upsert 43 rows inside DB::beginTransaction … rollBack                    ok; count 43 → 43 → 43
   requirementRow() on a row with no period set and no teaching count      DomainException with row + class
   POST generate, academic_term_id=999999                                  302, error on academic_term_id, rows 43
   POST generate with the tenant lock already held                          302, "already running", rows 43
   GET tab                                                                  200, generate form ×1, comment leaks 0
   SlotRequirementGridService::build() under strict_types                   ok
   permission tenant.timetable-foundation.slot-requirement.generate        declared YES, seeded NO
grep controller: try=1 · DB::transaction=1 · Cache::lock=1 · activityLog=1 (per row, in tx) · Gate::authorize=1
grep grid service: getMessage=0 · report($e)=1
```

---

## 7. Final state

**FIXED.** Nothing in this controller's scope is open except two items:
- the deferred split (SLR-06/07/08);
- the cross-cutting SLR-03.

One hand step remains: seed and grant `.generate` (§4.1).
