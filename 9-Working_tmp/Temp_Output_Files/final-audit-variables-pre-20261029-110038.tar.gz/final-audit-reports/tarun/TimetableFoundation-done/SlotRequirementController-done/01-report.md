# Final Audit — TimetableFoundation / SlotRequirementController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/SlotRequirementController.php` (267 lines, 1 public method)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready as-is, but close. 0 blockers, 4 HIGH.**

This is a single-purpose generation controller. It authorizes correctly, runs its writes inside one
transaction, logs after the write, and uses the D2 truncate-then-rebuild catch with a fixed message —
the core patterns are sound. The problems are:

- **It is destructive beyond its inputs.** Generating for one term + type TRUNCATEs slot requirements
  for **every** term and type (and empties `tt_priority_configs`). Nothing downstream rebuilds the
  other terms, so their requirements silently vanish until someone regenerates each one.
- **That destructive action is gated by `.create`**, not a `.generate` ability, so the permission name
  does not describe the operation a role is actually being granted.
- **Two N+1 query loops** (one live today, one latent) and a **per-row upsert + re-select** run inside
  the generation loop.
- **The generation logic is a 163-line controller method** (>150 lines = H) that should be a service.

The worst single finding is **SLR-17** — the regenerating action clears slot requirements for all
terms/types. The effort is about a day, most of it extracting the generation loop into a service.
Five DECISION items need your choice first (SLR-17, SLR-02, SLR-18, the SLR-06/07/08 split, SLR-19).

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 4 | 6 | 10 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | SLR-01 | F8 Services/Jobs | clean for the grid service; `RequirementTableTruncator` linked |
| F2 Transactions/Audit | clean | F9 Queries/Perf | SLR-12, SLR-13, SLR-14 |
| F3 Authorization | SLR-02, SLR-03 | F10 Views | clean — controller renders none |
| F4 Validation | SLR-04, SLR-05 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | SLR-15, SLR-16 |
| F6 Controller shape | SLR-06, SLR-07, SLR-08, SLR-09 | F13 Deep read | SLR-17, SLR-18, SLR-19, SLR-20 |
| F7 Models | SLR-10, SLR-11 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/SlotRequirementController.php` | controller | 267 | this report | ✅ whole class |
| 2 | `app/Models/SlotRequirement.php` | model | 155 | **this report (pre-assigned)** | ✅ whole class |
| 3 | `app/Services/SlotRequirementGridService.php` | service | 338 | **this report (pre-assigned)** | ✅ whole class — **not called by this controller** (reached via `TimetableFoundationController:976`) |
| 4 | `app/Services/RequirementTableTruncator.php` | service | 192 | ↗ [RequirementConsolidationController](../RequirementConsolidationController-done/01-report.md) | ↗ linked — usage checked (SLR-17), not re-audited |
| 5 | `routes/web.php:301` | route | — | this report | ✅ one POST route |
| 6 | `app/Policies/SlotRequirementPolicy.php` | policy | 44 | this report | ✅ — unreachable, see SLR-03 |
| 7 | `app/Http/Requests/SlotRequirementRequest.php` | FormRequest | 100 | this report | ✅ — orphaned, see SLR-03 |
| 8 | `app/Http/Requests/GenerateSlotRequirementRequest.php` | FormRequest | — | this report | ✅ — orphaned (named only in a controller comment) |
| 9 | `resources/views/.../slot-requirements/_list.blade.php` | tab partial | 173 | not in scope | ❌ rendered by `TimetableFoundationController`, not here — its generate button (line 116) is the route caller |
| 10 | `resources/views/.../slot-requirements/_grid.blade.php` | partial | — | not in scope | ❌ consumer of the pre-assigned grid service, rendered by another controller |
| — | `activityLog()` (`app/Helpers/activityLog.php`), `flash()` (`app/Helpers/helpers.php`) | app glue | — | common | referenced only (§4.2) |
| — | `x-backend.tab.search-bar`, `x-tenantcore::export-buttons` | shared components | — | common | referenced only |

**Pre-applied 2026-10-10:** `SlotRequirementGridService` is listed in `../PRE-APPLIED-2026-10-10.md`.
Its `build()` catch was changed to `report($e)` + the fixed message "The slot grid could not be built.
The error has been logged." (line 122-127), with an `ERR-01, 2026-10-10` comment. This audit reviewed
that result fresh and found it **complete and compliant** — it is the model the controller's own catch
should follow (SLR-01). `RequirementTableTruncator` is also pre-applied; it is owned elsewhere.

## 4. Routes

```
POST      timetable-foundation/slot-requirement/generate   timetable-foundation.slot-requirement.generateSlotRequirement   generateSlotRequirement
```

Middleware (unchanged, verified): `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain,
EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`.

**Unrouted public methods:** none — the class has exactly one public method and it is routed.

Route source: `Modules/TimetableFoundation/routes/web.php:301`.
**Only caller:** the tab partial `slot-requirements/_list.blade.php:116` (and
`Modules/SmartTimetable/.../slot-availability/_list.blade.php:168`).

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| `generateSlotRequirement` | ✅ POST | `…slot-requirement.create` | ✅ one `DB::transaction` in-method | `Generated` (per row, inside tx) | `tt_slot_requirements`, `sys_activity_logs`; **plus TRUNCATE of `tt_slot_requirements` (all terms/types) + `tt_priority_configs` before the tx** | SLR-01,02,04,06,07,08,09,12,13,14,17,18,19 |
| `upsertSlotRequirement` (private) | — | — | called inside the tx | — | `tt_slot_requirements` | SLR-14, SLR-20 |

**Tables each mutation SHOULD touch (measured before counting):**
- A Generate for one term+type should write `tt_slot_requirements` for that pair and one
  `sys_activity_logs` row per generated requirement. It writes both. ✅
- It should **not** need to touch `tt_priority_configs` or other terms' rows — but the
  `RequirementTableTruncator` staged design makes it clear everything downstream, and it clears the
  whole `tt_slot_requirements` table. Reported as **SLR-17**.

## 6. Findings

### F1 — Errors
#### SLR-01 · L · ERR-00 / D2 — the allowed truncate-rebuild catch is not annotated `ERR-01` + date
**Where:** `SlotRequirementController.php:214`
```php
} catch (\Throwable $e) {
    report($e);
```
**Evidence:** `grep -n "ERR-01" SlotRequirementController.php` → no match; the sibling
`SlotRequirementGridService.php:123` carries `// … (ERR-01, 2026-10-10)`. D2: "each allowed catch
gets a comment naming ERR-01 and the date."
**Consequence:** none for the user — the catch already uses `report($e)` and a fixed message — but an
undocumented allowed catch reads like an ERR-00 violation to the next reviewer.

The rest of F1 is clean — the catch message is fixed ("…so they are now empty. Please try again."),
`findOrFail()`/`validate()`/`Gate::authorize()` all sit **before** the `try` (lines 62-74), and no
`$e->getMessage()` reaches the user (`grep -E "getMessage\(\)" … → none`).

### F2 — Transactions and audit
**Clean.** The two-table mutation (`tt_slot_requirements` + `sys_activity_logs`) runs inside one
`DB::transaction` (line 82); `activityLog($slotRequirement, 'Generated', …)` is after the write and
inside the transaction (lines 197-206); the redirect/flash is built **after** the closure returns
(line 211), so TXN-05 does not apply. The TRUNCATE sits outside the transaction by design — the
truncator itself refuses to run inside one (`RequirementTableTruncator.php:131`).

### F3 — Authorization
#### SLR-02 · M · AUTH-06 / AUTH-01 — a destructive regenerate is gated by `.create`, not a `.generate` ability
**Where:** `SlotRequirementController.php:62`
```php
Gate::authorize('tenant.timetable-foundation.slot-requirement.create');
```
**Evidence:** the permission exists (`sys_permissions` id 1574 on the tenant). But
`config/permissionslist.php:695` declares `'timetable-foundation.slot-requirement' => $crud` — plain
CRUD, no `generate` verb — while sibling generate controllers use a `.generate` ability
(`teacher-availability`, `room-availability` carry `'generate'`, `ActivityController` gates
`…activity.generate`). The action name therefore does not describe the operation being granted.
**Consequence:** any role holding only `slot-requirement.create` can trigger a whole-table TRUNCATE
and rebuild — an operation materially stronger than "create one row". Fixing it needs a new
permission key → **DECISION** (SLR-02 in the plan).

#### SLR-03 · L · AUTH / dead code — policy registered but never consulted; two FormRequests orphaned
**Where:** `TimetableFoundationServiceProvider.php:137` · `SlotRequirementPolicy.php` ·
`SlotRequirementRequest.php` · `GenerateSlotRequirementRequest.php`
```php
Gate::policy(SlotRequirement::class, SlotRequirementPolicy::class);
```
**Evidence:** every gate in this module passes a permission **string**, so the policy is never
consulted (module-wide pattern, same as `ATC-14`). `grep -rn "SlotRequirementRequest" Modules` finds
no caller; the only reference to `GenerateSlotRequirementRequest` is the controller comment at line 64.
The policy's `strict_types` is also missing.
**Consequence:** dead classes that look active. A future reader may "add" authorization to the policy
and expect it to run — it will not. This is a **cross-cutting** module decision, not fixed here.

### F4 — Validation and input
#### SLR-04 · M · VAL-02 — inline `$request->validate()` in the controller, with an unused FormRequest already written
**Where:** `SlotRequirementController.php:68-71`
```php
$validated = $request->validate([
    'academic_term_id' => 'required|exists:sch_academic_term,id',
    'timetable_type_id' => 'required|exists:tt_timetable_types,id',
]);
```
**Evidence:** `GenerateSlotRequirementRequest` exists and "mirrors" these rules (controller comment
line 64); the only reason given for the inline form is the `generateStep()` dispatcher that was
**retired 2026-10-06** (line 66). That reason no longer holds.
**Consequence:** validation lives in two places that can drift; the FormRequest's own tests/docs are
never exercised on the live path.

#### SLR-05 · L · VAL-04 (latent) — `exists` rules ignore soft deletes
**Where:** `SlotRequirementController.php:69-70`
**Evidence:** `SHOW COLUMNS sch_academic_term` and `tt_timetable_types` both have `deleted_at`. The
`exists` rule queries the table directly and does **not** apply the model's SoftDeletes scope, so a
trashed term or type id passes validation. The UI's generate form only lists active rows, so this is
latent.
**Consequence:** if a stale/crafted request posts a trashed `academic_term_id`, requirements are
rebuilt for a term no screen shows, silently.

### F5 — Routes
**Clean.** One route, `POST` (no state change over GET — RTE-01 ✅),
`routes/web.php:301` points at an existing method (RTE-02 ✅), the method is routed (RTE-03 ✅),
the tenant middleware group is present (RTE-05 ✅), no `Route::resource` shares the prefix (RTE-06 n/a).
Evidence: the uncached `route:list` output in §4.

### F6 — Controller shape
#### SLR-06 · H · CTL-02 — `generateSlotRequirement()` is 163 lines
**Where:** `SlotRequirementController.php:60-222`
**Evidence:** `php …scan.php` → `generateSlotRequirement() is 163 lines`; over 150 = H.
**Consequence:** the generation pipeline (two loops, helpers, log loop) is hard to review and
untestable in isolation; a bug in either loop is easy to miss.

#### SLR-07 · M · CTL-06 — generation business logic lives in the controller
**Where:** `SlotRequirementController.php:82-209`
**Evidence:** period-set resolution, section expansion, per-row upsert and activity logging are all
inline. There is no `SlotRequirementGenerator` service. On SQL-only SQL, this is CTL-06.
**Consequence:** the same pipeline cannot be reused by a job or command, and its correctness is only
exercised through an HTTP POST. Extract → **DECISION** (deferred split, D3), sequenced with SLR-06/08.

#### SLR-08 · M · CTL-05 — step 1 and step 2 are near-identical copy-paste blocks
**Where:** `SlotRequirementController.php:125-140` vs `:164-186`
**Evidence:** both compute
`$psTeaching = ($periodSetTeaching[$row->period_set_id] ?? 8) * $schoolDayCount;` and the same
`$teaching/$exam/$free` trio, then call `upsertSlotRequirement(...)` with the same argument shape.
**Consequence:** a change to the period-count rule must be made twice; today the two copies already
differ only by which row collection drives them.

#### SLR-09 · L · CTL-04 — no return type on the public method
**Where:** `SlotRequirementController.php:60`
```php
public function generateSlotRequirement(Request $request)
```
**Evidence:** `php …scan.php` → `generateSlotRequirement() has no return type`. The private
`upsertSlotRequirement(...): int` does declare one.
**Consequence:** none at runtime; convention drift.

### F7 — Models
#### SLR-10 · L · STY-01 / MDL — `SlotRequirement` lacks `declare(strict_types=1)`
**Where:** `SlotRequirement.php:1-5`
**Evidence:** `grep -l "declare(strict_types=1)"` lists only the controller. The model casts every
integer column, but without strict types the casts and the `===` in `isValid()` are the only guards.
**Consequence:** style/consistency only.

#### SLR-11 · L · STY-02 — `SlotRequirement` is not Pint-clean
**Where:** `SlotRequirement.php`
**Evidence:**
`vendor/bin/pint --test --format agent SlotRequirement.php` →
`{"result":"fail","fixers":["class_attributes_separation","no_unused_imports","single_line_after_imports"]}`.
The same command reports the **controller and the grid service clean**.
**Consequence:** a later `pint --dirty` will reformat this file inside an unrelated change.

**Model checks that passed:** `$table = 'tt_slot_requirements'` exists (SHOW CREATE); no
`created_at`/`updated_at` columns and `$timestamps = false` (consistent); `deleted_at` present and
`SoftDeletes` used; `$fillable` contains no sensitive field; every relationship is return-typed and
**resolves on live data** — proved in tinker:
`class → "Nursery"`, `section → "A"`, `timetableType → "Regular School Day"`,
`classTimetableType → id 1`, `academicTerm → "First Term"`.

### F8 — Services and jobs
**The pre-assigned `SlotRequirementGridService` is clean** on the service rules: no HTTP
(`grep -nE "request\(|session\(|redirect\(|response\(" …` → none), no writes on a read path, repeated
lookups memoised (`$csCache`, line 287), and its one `catch (Throwable $e)` is the allowed D2
service shape (`report($e)` + fixed message, `ERR-01, 2026-10-10`). Style items are reported at
SLR-15/16. `RequirementTableTruncator` is **owned elsewhere**; only its use by this controller was
checked (SLR-17). No jobs/events.

### F9 — Queries and performance
#### SLR-12 · H · QRY-01 — `sch_class_section_jnt` is queried inside the class-level loop
**Where:** `SlotRequirementController.php:158-162`
```php
foreach ($classLevelRows as $row) {
    $sections = DB::table('sch_class_section_jnt')
        ->where('class_id', $row->class_id)
        ->where('is_active', 1)
        ->get();
```
**Evidence:** the scanner flags `DB::table() inside a loop — N+1 query`. On this tenant
`applies_to_all_sections = 1` rows = **0**, so the loop body does not run today (the trap is latent);
on a tenant that uses class-level rows it issues one query per class and selects whole rows.
**Consequence:** a screen that already runs one POST becomes O(classes) queries; with 40 classes that
is 40 extra round trips per Generate.

#### SLR-13 · H · QRY-01 — `SlotRequirement::find()` inside the activity-log loop
**Where:** `SlotRequirementController.php:197-206`
```php
foreach ($generatedIds as $slotRequirementId) {
    $slotRequirement = SlotRequirement::find($slotRequirementId);
```
**Evidence:** the scanner flags it; `tt_slot_requirements` currently holds 43 rows, and a Generate
for the current term/type logs a subset of them — each id is re-fetched by primary key.
**Consequence:** N extra queries per Generate to re-read rows the code just wrote (it already has the
ids and could build the models once, or log by id).

#### SLR-14 · M · QRY-07 — per-row `updateOrInsert` + re-`SELECT` (two statements per row)
**Where:** `SlotRequirementController.php:241-265` (`upsertSlotRequirement`)
**Evidence:** every generated row runs an `updateOrInsert` and then a `SELECT id` back. This is the
"bulk write" rule: N×2 statements instead of chunked `upsert()`.
**Consequence:** generation slows linearly with the number of class-sections; each row also pays a
round trip to learn its id.

The rest of F9 is clean: helpers (`tt_period_sets`, `tt_school_days`) are read **once** outside the
loops (lines 91-99); no `::all()` feeds a list page; no leading-wildcard LIKE; no interpolated raw SQL.

### F10 — Views
**Clean — the controller renders no view.** `grep -oE "view\(['\"]…" SlotRequirementController.php`
→ none. The tab partials that display slot requirements and call this route are rendered by
`TimetableFoundationController::showTimetableRequirement()`, which is **not** this audit.

### F11 — Security and Tenancy
**Clean.** No `env()` outside config (`grep -nE "env\(" … → none`); no personal data in a response
(the method redirects); no hard-coded tenant/user/status id; no secrets logged (`report($e)` logs the
exception object); no cache. The only magic default is `?? 8`, reported at SLR-19.

### F12 — Style
#### SLR-15 · L · STY-04 — emoji markers in comments (grouped per file)
**Where:** `SlotRequirementController.php:34` (`⚠`) · `SlotRequirementGridService.php:27,152` (`⛔`,`⚠`)
**Evidence:** scanner rule `STY-04` fires on each. The rulebook: "no emoji markers".
**Consequence:** style only. One reword per file.

#### SLR-16 · L · STY-01 — `SlotRequirementGridService` lacks `declare(strict_types=1)`
**Where:** `SlotRequirementGridService.php:1-3`
**Evidence:** `grep -l "declare(strict_types=1)" …` → only the controller.
**Consequence:** style/consistency only. (The controller and its method already declare it.)

### F13 — Deep read
#### SLR-17 · H · deep read (data loss) — Generate for one term/type clears slot requirements for **all** terms/types and empties Priority Config
**Where:** `SlotRequirementController.php:80` → `RequirementTableTruncator.php:80-85,100-103,127-180`
```php
app(RequirementTableTruncator::class)->truncateFrom('slot_requirements');
// STAGES: 'slot_requirements' => ['tt_slot_requirements'],
//         'priority_configs' => ['tt_priority_configs'],   ← every later stage goes too
```
**Evidence:** `truncateFrom('slot_requirements')` truncates `tt_slot_requirements` (all rows) and
`tt_priority_configs`, then the transaction rebuilds only the selected `(term, type)` pair. The
confirm dialog at `_list.blade.php:121` states "slot requirements for EVERY term and timetable type
are cleared, then rebuilt for the selected term and timetable type only" — so it is **disclosed**, not
silent. It is nonetheless data loss that no code restores for the other terms.
**Consequence:** a school with slot requirements for 3 terms that regenerates 1 loses the other 2
terms' requirements (and its Priority Config) until an admin re-runs Generate per term+type. This is
the single worst finding. Whether to scope the truncation to the selected pair is a **DECISION**
(SLR-17 in the plan); D2 currently sanctions the truncate-then-rebuild shape.

#### SLR-18 · M · TXN-06 / deep read — no lock around truncate + rebuild (race)
**Where:** `SlotRequirementController.php:80-209`
**Evidence:** two concurrent POSTs both truncate before either opens its transaction; the second
truncate can erase rows the first just wrote, or interleave with the first transaction.
**Consequence:** double-click / two admins can leave the table half-rebuilt. There is no
`Cache::lock`/DB advisory lock and no unique-index fallback that would surface it.

#### SLR-19 · L · deep read / SEC-03-adjacent — silent `?? 8` fabricates a teaching count
**Where:** `SlotRequirementController.php:125,164`
```php
$psTeaching = ($periodSetTeaching[$row->period_set_id] ?? 8) * $schoolDayCount;
```
**Evidence:** when `period_set_id` is NULL/unknown to the plucked map, the code invents "8 teaching
periods per day" instead of failing or skipping.
**Consequence:** a class with a missing period set silently gets a plausible-looking requirement
instead of an error — a "message that lies" (deep-read #7) one layer down.

#### SLR-20 · L · deep read / MDL-03-adjacent — soft-delete × unique-index trap is latent
**Where:** `updateOrInsert` at `SlotRequirementController.php:241` vs
`UNIQUE uq_sa_class_section (timetable_type_id, class_timetable_type_id, class_id, section_id)`
**Evidence:** the unique key does not include `deleted_at`, and `DB::table()->updateOrInsert()`
bypasses the model's SoftDeletes scope — a soft-deleted row with the same 4 keys would be **updated
but left trashed** (revived invisibly). It is latent only because `truncateFrom()` empties the table
first; remove the truncate and the trap goes live.
**Consequence:** today, none; if the truncation is ever narrowed (SLR-17), a previously soft-deleted
requirement can be "updated" yet stay hidden.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`RequirementTableTruncator` (owned by RequirementConsolidationController):** its own ERR-05
  (`Log::error(… ['error' => $e->getMessage()])`, line 145) is that report's business. The scanner's
  `QRY-01` hit at line 173 (`DB::table($table)->truncate()` in a loop) is a **false positive** —
  TRUNCATE is DDL, not an N+1.
- **Dead classes:** `SlotRequirementPolicy`, `SlotRequirementRequest`, `GenerateSlotRequirementRequest`
  are unreachable/orphaned (SLR-03). The unreachable-policy pattern is module-wide and needs one
  decision.
- **Route-name copy-paste:** `routes/web.php:265` names the **TeacherAvailabilityController** route
  `teacher-availability.generateSlotRequirement` — a copy of this controller's name. Harmless but
  misleading; it belongs to the TeacherAvailability report.
- **Grid service caller:** `TimetableFoundationController:976` does `(new SlotRequirementGridService)->build()`
  rather than injecting it (SVC-02). That caller is not this audit; noted so it is not lost.

## 8. Not covered, and why

- **Runtime behaviour:** no browser, no test run (D4). Every finding is static or a read-only SQL probe.
- **`TimetableFoundationController`:** it is the actual renderer of the slot-requirements tab and the
  only caller of the pre-assigned grid service. It has its own audit row.
- **`RequirementTableTruncator` internals:** owned elsewhere (§5); only the four-line call contract was
  reviewed.
- **Data repair of the 43 live `tt_slot_requirements` rows:** out of scope.
- **`SlotRequirementRequest`/`GenerateSlotRequirementRequest` rule execution** (`module-finalization`
  §3.5.1): the FormRequests are dead, so this audit did not execute them.
