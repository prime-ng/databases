# Status — TimetableFoundation / ClassTimetableTypeController

**Fixed:** 2026-10-13 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — 23 items ticked. 1 item left open: CTT-07 (deferred by design).

---

## 1. Pre-applied work

None. No `PRE-APPLIED-2026-10-10.md` lists a file in this controller's scope.

---

## 2. Applied

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| CTT-01 | `Models/ClassTimetableType.php` | Added `use SoftDeletes`. Delete now moves a row to the trash. The trash page, restore and force-delete work. | `class_uses_recursive(ClassTimetableType::class)` | contains `SoftDeletes` |
| CTT-01 (blast radius) | — | Before adding the trait, classified every reader of `tt_class_timetable_types_jnt`. Eloquent readers (≈20, across TimetableFoundation, SmartTimetable, StandardTimetable and 2 debug commands) now skip trashed rows. **14 of the 15 raw `DB::table()` readers already filter `whereNull('deleted_at')`**, so both kinds agree on what "live" means; no half-applied scope. `deleted_at` was NULL on all 344 rows, so nothing visible today disappears. | `grep` each raw reader ±12 lines for `deleted_at` | 14/15 filter it. The 15th joins by id from `tt_slot_requirements` (see §5). |
| CTT-20 (a) | `ClassTimetableTypeController.php` `forceDelete()` | Uses `onlyTrashed()->findOrFail()`, so a live id gets a 404. If `tt_slot_requirements` still references the row, it throws `DomainException` naming the table and the count. The FK is `NO ACTION` and is the only FK child of this table. | rolled-back dry run | row #1: "1 slot requirement(s)". Live total today: 43. |
| CTT-21 | same, `saveAssignment()` | Logs `'Created'` when `wasRecentlyCreated` is true, otherwise `'Updated'`. | read | — |
| CTT-02 | `Http/Requests/ClassTimetableTypeUpdateRequest.php` (new) | Validation runs before the transaction. A 422 now redirects back with its field errors. | `class_exists` | OK |
| CTT-03, CTT-06 | controller | No try/catch except the two D2 `catch (DomainException)` blocks (force-delete, restore). Every closure returns its data, and the redirect or JSON is built after the transaction. No `Log::` and no `getMessage()` outside the D2 catches. | `grep -c 'try {'` / `Log::` | 2 / 0 |
| CTT-04 | controller `store()` | The whole class × section loop runs in one `DB::transaction`. `updateOrCreate` is kept instead of bulk `upsert()`: there is no unique index on the natural key, so `upsert()` could not match an existing row and would insert duplicates (the plan's stated fallback). | read | — |
| CTT-05 | controller `toggleStatus()` | `activityLog('Toggled')` now runs after a successful `save()`, inside the transaction. A failed save writes no log. | read | — |
| CTT-08 | `Http/Requests/ClassTimetableTypeStoreRequest.php` (new) | Holds the store rules. The class/section cross-field rule moved into `after()`. Both requests `authorize()` through `authorizeByCrudPermission('tenant.timetable-foundation.class-timetable')`, the same permission as the controller gates. | dry run: a class with no sections | rejected, same message as before |
| CTT-09 (a) | both requests | `effective_to` uses `after:effective_from`, matching the strict `<` in `chk_valid_effective_range`. | dry run: equal dates | rejected: "…must be a date after effective from." |
| CTT-11 | controller `show/edit/update/destroy` | Route model binding with the argument named `$classTimetable`, matching `{class_timetable}`. Views still receive `$classTimetableType`. | reflection over `route:list` | all 4 resource routes plus toggle-status: `=bound` |
| CTT-12 | controller | The per-row write moved into `saveAssignment()`. `store()` is now ~45 lines. | read | — |
| CTT-13 | controller | `formOptions()` serves both `create()` and `edit()`. | read | — |
| CTT-14 | controller | Every public method has a return type (`View` / `RedirectResponse` / `JsonResponse`). | `php -l` | OK |
| CTT-15 | controller `create()` | Removed the unused `$sections = collect()`. | `grep -c '\$sections' create.blade.php` | 0 |
| CTT-16 | controller `fullyAssignedClassIds()` | Two grouped queries (`COUNT(DISTINCT section_id)` and `COUNT(*)` per class) replace one `ClassSection::count()` per class. | rolled-back dry run, old vs new, every timetable type | 4/4 identical |
| CTT-17 (a) | `show.blade.php:32`, `trash.blade.php:25` | `->schoolClass` became `->class`. The Class column now shows the name instead of "—". | `grep schoolClass` | 0 |
| CTT-18 | `show.blade.php`; `index.blade.php` | Removed the non-existent `priority` row. Deleted the orphan `class-timetable-type/index.blade.php` (160 lines, a copy of the AcademicTerm list) after re-proving it has no `view()` caller. | `grep -rn "class-timetable-type.index"` | 0 |
| CTT-19a/b/c | controller, model, policy | `strict_types` added. Removed the unused `HasFactory` import from the model. Added a `BelongsTo` return type to each of the 5 relations. | `php -l` | OK |
| Dropdown cache (a) | — | Left uncached, recorded as accepted (small tables, low traffic). | — | — |
| CTT-10 (a) | `routes/web.php:256` | Restore is now `Route::patch` (was GET), so a link preview, prefetch or Back press cannot restore a row. `x-backend.table.action-trashed` reads the verb from the route, so `trash.blade.php` is unchanged. No other caller of the route name exists. | `route:list --path=class-timetable` + render the component | `PATCH …/{id}/restore`; form POST with `_method=PATCH` ×1 |
| Pint | the 5 touched PHP files | Pint changed one thing: `class_attributes_separation` in the model. | `php -l` re-run after Pint | OK |

The controller went from 594 lines to 525. Two new FormRequests were added (105 and 67 lines).

### 2.1 Applied beyond the ticked plan — read this

1. **`restore()` now refuses to create a duplicate.** Adding CTT-01 armed a new defect, so it is fixed in the same pass (module-finalization §6.2.1). The table has no unique index on (term, type, class, section). `store()` and `TimetableTypeController` both create a fresh row once the old one is trashed. Restoring the old row would then leave **two live rows for one class-section**, and the generator would read both. `restore()` now checks for a live twin and refuses with a `DomainException` that tells the user what to do instead.
2. **The trash page eager-loads** `class`, `section`, `timetableType`, `academicTerm` and `periodSet`. These are the five relations the trash blade reads. Without the eager load, each one was an N+1 per row.
3. **`saveAssignment()` carries a docblock** saying it is only called inside `store()`'s transaction. The scanner flags it as TXN-01; that is a false positive.

---

## 3. Not applied

| ID | Why |
|---|---|
| CTT-07 | Deferred by design. Every gate passes a permission string, so `ClassTimetableTypePolicy` is never consulted. This is the module-wide unreachable-policy decision (ATC-14). |

---

## 4. Needs Tarun's hand

1. **Browser check** of `/timetable-foundation/timetable-masters?tab=timetable-types`:
   - delete one assignment, then confirm it appears in the trash;
   - restore it;
   - try to force-delete a row that slot requirements use, and expect a refusal that names `tt_slot_requirements`.
2. No migration and no permission sync are needed. `deleted_at` already exists on the table.

---

## 5. Unverifiable by this workflow (D4), and notes

- **Restore when a live twin exists** is proven only by reading the code and a negative dry run (no twin, so the restore was allowed). Nobody has created a real twin yet.
- **`ClassTimetableTypeSeeder` uses a raw `updateOrInsert`** on the natural key. If a user trashes a seeded row and the seeder is re-run, the row is updated but stays trashed. That is consistent ("trashed stays trashed"), but worth knowing.
- **`TimetableTypeController:638`** runs `ClassTimetableType::whereIn(...)->delete()`, an Eloquent builder delete. It now **soft**-deletes the assignments a user removes from a timetable type. They then show in this trash, and they can be restored only when no live twin has replaced them (the guard in §2.1).
- **`SmartTimetable/TimetablePageController:251`** joins `tt_class_timetable_types_jnt` by id from slot requirements without a `deleted_at` filter. A slot requirement whose assignment is trashed still shows that assignment's data. This is cross-module, so it was not changed here.
- **`update()` can re-point a row** onto a natural key that another live row already holds. This is pre-existing and not in the report. The edit form keeps class and section as hidden inputs, so the UI cannot reach it today.

---

## 6. Verification log

```
php -l (5 PHP files, before and after Pint)              → No syntax errors ×10
class_exists: controller, model, policy, 2 requests       → OK ×5
SoftDeletes on model                                      → yes
route:list (uncached) + reflection, 12 routes             → every action method exists;
                                                            show/edit/update/destroy/toggleStatus bound
blade compile: create, edit, show, trash                  → OK; @push 1/1; comment delimiters balanced
dry run (rolled back, tenant xyz_school_00000000000040008000_202627):
  fullyAssignedClassIds old vs new, 4 timetable types     → SAME ×4
  soft delete #1                                          → live 344→343, trashed 1, raw row kept
  force-delete guard on #1                                → 1 slot requirement(s)
  restore                                                 → live 344
  after rollback                                          → live 344, trashed 0
  equal effective dates                                   → rejected
  class with no sections                                  → rejected
grep controller: try=2 (D2) · Log::=0 · tx=8 · activityLog=6 · Gate::authorize=12
scan.php + scanfilter (9 paths) → 9 rows, all triaged:
  RTE-01 restore GET (CTT-10 — fixed afterwards, route now PATCH) · AUTH-04 ×2 (request + controller check the same name,
  house pattern) · CTL-03 ×2 forceDelete/restore keep {id}+onlyTrashed (a trashed row cannot
  bind implicitly) · ERR-01 ×2 DomainException (D2) · VAL-02 toggleStatus one-field inline
  (F4 allows) · TXN-01 saveAssignment (false positive, runs inside store()'s transaction)
```

---

## 7. Final state

**Status: FIXED** (2026-10-13). Open items:

- 1 L: CTT-07, deferred module-wide.

The B blocker (CTT-01) and every other H item are closed.
