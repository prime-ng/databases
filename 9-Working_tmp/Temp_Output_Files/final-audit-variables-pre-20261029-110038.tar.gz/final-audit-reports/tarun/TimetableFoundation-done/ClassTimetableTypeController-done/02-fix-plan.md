# Fix Plan — TimetableFoundation / ClassTimetableTypeController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick; "tick all" does not cover it.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/ClassTimetableTypeController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.
> 6. CTT-01 must be ticked **together with** CTT-20 — the force-delete guard is unverifiable until the model soft-deletes.

## 1. Blockers reachable today
- [x] **CTT-01** · B · F7/MDL · `ClassTimetableType.php` — add `use Illuminate\Database\Eloquent\SoftDeletes;` to the model (the migration already adds `deleted_at`):
  - `destroy()` then soft-deletes instead of hard-deletes;
  - `trashedClassTimetable()`, `restore()` and `forceDelete()` stop throwing `BadMethodCallException`;
  - verify with `class_uses_recursive` and `method_exists(...,'onlyTrashed')`.
  Do **not** touch the existing rows; `deleted_at` stays NULL until a real delete. Effort: S. ⚠ SHARED model — other controllers (TimetableTypeController, seeders, SmartTimetable) read this table too; adding the trait is additive.

## 2. Fixes that arm a latent defect (sequenced)
- [x] **CTT-20** · H · DECISION · deep read · `ClassTimetableTypeController.php:471-502` — harden `forceDelete()` (runs only after CTT-01):
      (a) ⭐ `onlyTrashed()->findOrFail($id)` **and** refuse with a `\DomainException` message naming `tt_slot_requirements` and its live count (43 today) when children exist. Effort: S.
      (b) Only `onlyTrashed()->findOrFail($id)`; let the FK 1451 surface as the generic error. Effort: S.
      (c) Leave as is. Effort: none.
      ➜ Choice: (a) — applied 2026-10-13
- [x] **CTT-21** · M · deep read · `ClassTimetableTypeController.php:191-228` — in `store()`, log `'Created'` when `$entry->wasRecentlyCreated` is true and `'Updated'` otherwise, so re-submitting an existing combination no longer lies in the audit trail. Effort: S.

## 3. Errors & transactions (F1/F2)
- [x] **CTT-02** · H · ERR-02 · `ClassTimetableTypeController.php:305-368` — move `$request->validate(...)` **out of** the `try` (before `DB::transaction`), so a 422 redirects with its field errors and is never caught by `catch (\Throwable)`. Effort: S.
- [x] **CTT-03** · M · ERR-00 / ERR-05 / ERR-04 · `ClassTimetableTypeController.php:364-367, 404-407, 497-500, 537-540, 588-591` — remove the try/catch from `update`, `destroy`, `forceDelete`, `restore` and `toggleStatus`, using `return DB::transaction(fn () => …)` (the ERR-00 shape the 2026-10-10 pass applied elsewhere). The central handler then logs the exception and returns the right response for JSON (`toggleStatus`) and pages. Add `// ERR-00 …` / `// ERR-01 2026-10-10` comments on any catch kept per D2 (none here). Effort: S.
- [x] **CTT-04** · H · TXN-01 (+ QRY-07) · `ClassTimetableTypeController.php:186-231` — wrap `store()`'s whole class × section loop in one `DB::transaction` and replace the per-row `updateOrCreate` with a chunked bulk `upsert` where MySQL supports it (fall back to `updateOrCreate` inside the transaction if the FK semantics require it). `activityLog` stays inside the transaction, after each row. Effort: M.
- [x] **CTT-05** · M · TXN-04 · `ClassTimetableTypeController.php:557-567` — move the `activityLog($classTimetableType, 'Toggled', …)` call to **after** `$classTimetableType->save()` inside the same transaction. Effort: S.
- [x] **CTT-06** · L · TXN-05 · `ClassTimetableTypeController.php:355-357, 395-397, 488-490, 528-530, 570-581` — each transaction closure returns its data (the model); build the `redirect()`/`response()->json()` **after** `DB::transaction` returns. Effort: S.

## 4. Authorization (F3)
- [ ] **CTT-07** · L · AUTH-04 — see "Deferred" below: no per-controller change. The policy registration (`TimetableFoundationServiceProvider.php:125`, ⚠ SHARED) is left to the module-wide unreachable-policy decision (AcademicTermController ATC-14). All 12 gates stay as-is.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **CTT-08** · M · VAL-02 + VAL-07 · `ClassTimetableTypeController.php:121-160, 309-324` — extract `Modules/TimetableFoundation/app/Http/Requests/ClassTimetableTypeStoreRequest` and `…UpdateRequest`; move the inline rules and the "each selected class needs All Sections or a section" cross-field rule into the FormRequest's `after()` hook. Handle `section_id`, `period_set_id` etc. with `?? null` (VAL-03 already OK). Effort: M.
- [x] **CTT-11** · M · CTL-03 · `ClassTimetableTypeController.php:241, 253, 301, 374` — switch `show`/`edit`/`update`/`destroy` to route model binding (`ClassTimetableType $classTimetableType`). ⚠ Check the resource's implicit parameter name `{class_timetable}`: binding requires the method parameter to be named `$classTimetableType` **or** the route re-keyed `{classTimetableType}`. Verify with `route:list` after the change. Effort: S.

## 6. Queries & performance (F9)
- [x] **CTT-16** · H · QRY-01 / QRY-05 · `ClassTimetableTypeController.php:77-92` — replace the per-class `ClassSection::count()` with one `selectRaw('class_id, count(*) as total')->groupBy('class_id')` over the class ids, and drop the PHP-side `->get()->groupBy()` in favour of a single grouped query (`pluck('total','class_id')`). Effort: S.
- [x] **DECISION — cache the create/edit dropdowns** · M · QRY-12/TEN-02 — `create()` and `edit()` re-query `AcademicTerm`, `TimetableType`, `SchoolClass`, `PeriodSet` on every page load.
      (a) ⭐ Leave as is for now (small tables, low traffic), record as accepted.
      (b) Add a tenant-keyed cache (`Cache::remember("ctt_dropdowns.{tenant_id}" …)`) with invalidation on store/update/destroy. Cache keys must carry the tenant id.
      ➜ Choice: (a) — leave as is, recorded as accepted

## 7. Controller shape (F6)
- [x] **CTT-12** · M · CTL-02 · `ClassTimetableTypeController.php:112-236` — extract `store()`'s per-class/section write loop into a private helper (or the FormRequest-scoped builder) so the method drops under 80 lines. Effort: S.
- [x] **CTT-13** · M · CTL-05 · `ClassTimetableTypeController.php:40-57, 259-286` — share the academicTerms/timetableTypes/classes/periodSets loader between `create()` and `edit()` (private method or a small view-model). The 5 duplicate try/catch blocks disappear with CTT-03. Effort: S.
- [x] **CTT-14** · L · CTL-04 · `ClassTimetableTypeController.php` (all 12 public methods) — add return types: `: RedirectResponse` (index/store/show/edit/update/destroy/forceDelete/restore), `: View` (create/edit/trashedClassTimetable are `View`; index/store/… are redirects), `: JsonResponse` (getSectionsByClass, toggleStatus). Verify each against the current body. Effort: S.
- [x] **CTT-15** · L · CTL-10 · `ClassTimetableTypeController.php:52-53` — remove the unused `$sections = collect()` (the create view loads sections by AJAX). Effort: S.

## 8. Views (F10)
- [x] **CTT-18** · L · VIEW · `show.blade.php:52`, `index.blade.php` — drop the non-existent `priority` cell from the details page, and delete the orphan `class-timetable-type/index.blade.php` after re-proving `view('timetablefoundation::class-timetable-type.index')` has no callers (`grep -rn` → none today). Effort: S.

## 9. Style (F12) — one item per file
- [x] **CTT-19a** · L · STY · `ClassTimetableTypeController.php` — add `declare(strict_types=1);`. Effort: S.
- [x] **CTT-19b** · L · STY · `ClassTimetableType.php` — add `declare(strict_types=1);`, remove the unused `HasFactory` import, add return types on the 5 relationships (`: BelongsTo`). ⚠ SHARED — 9+ callers in the module and SmartTimetable/StandardTimetable; type-only and import-only changes. Effort: S.
- [x] **CTT-19c** · L · STY · `ClassTimetableTypePolicy.php` — add `declare(strict_types=1);`. Effort: S.

## 10. Deferred / decisions
- [x] **CTT-09** · H · DECISION · VAL/DDL · `ClassTimetableTypeController.php:138, 322` — `effective_to` uses `after_or_equal`, but `chk_valid_effective_range` requires `effective_from < effective_to` (strict).
      (a) ⭐ Tighten the rule to `after:effective_from` in both methods (move into the FormRequests when CTT-08 applies). No migration, matches the DDL.
      (b) Additive migration relaxing the CHECK to `<=` — **departs from the DDL**, so the DDL must be changed by you first (module-finalization §1.4.1).
      (c) Leave as is — an equal-date submission stays a 500 on create / generic flash on update.
      ➜ Choice: (a) — applied 2026-10-13
- [x] **CTT-10** · H · DECISION · RTE-01 · `routes/web.php:247` (⚠ SHARED) — Restore runs over GET.
      (a) ⭐ Change it to `Route::patch`. `x-backend.table.action-trashed` derives the verb from the route, so `trash.blade.php:45-49` needs no edit. ⚠ This changes a route; it needs explicit approval.
      (b) Leave it as GET and accept the prefetch/CSRF risk.
      ➜ Choice: (a) — ticked by Tarun 2026-10-13, applied (Route::patch; trash button adapts via the component)
- [x] **CTT-17** · M · DECISION · VIEW · `show.blade.php:32`, `trash.blade.php:25` — the Class cell reads `->schoolClass`, an accessor that does not exist (relation is `class`).
      (a) ⭐ Fix the two blades to use `$classTimetableType->class?->name` / `$ctt->class?->name`.
      (b) Add a `schoolClass()` alias on the model — ⚠ SHARED model, and keeps a name that shadows reality.
      (c) Leave it — the Class column stays "—" forever.
      ➜ Choice: (a) — applied 2026-10-13