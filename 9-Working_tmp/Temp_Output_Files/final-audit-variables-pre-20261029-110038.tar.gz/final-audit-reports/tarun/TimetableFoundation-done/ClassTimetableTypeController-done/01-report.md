# Final Audit — TimetableFoundation / ClassTimetableTypeController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/ClassTimetableTypeController.php` (594 lines, 12 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 1 blocker, 6 HIGH.**

The single worst finding is **CTT-01**: the model that this controller drives, `ClassTimetableType`,
is missing the `SoftDeletes` trait even though the migration builds `deleted_at` and the whole
trash/restore feature depends on it. The Delete action therefore **permanently destroys rows**
instead of soft-deleting them, the trash page 500s, and the restore and force-delete actions can
never work.

On top of that, `store()` writes many rows plus an audit entry per row with **no transaction**,
`update()` swallows validation errors into a generic flash, and Restore runs over a GET route.
The trash-cycle methods were not touched by the 2026-10-10 pre-applied pass, so this controller
still uses the pre-ERR-00 try/catch shape.

The effort is roughly one day, including five DECISION items that need a choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 1 | 6 | 8 | 6 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CTT-02, CTT-03 | F8 Services/Jobs | clean: no service, no job, no event (`grep -n "Service\|dispatch\|event(" $C` → none) |
| F2 Transactions/Audit | CTT-04, CTT-05, CTT-06 | F9 Queries/Perf | CTT-16 |
| F3 Authorization | CTT-07 | F10 Views | CTT-17, CTT-18 |
| F4 Validation | CTT-08, CTT-09 | F11 Security/Tenancy | clean: no `env()`, no personal data, no hard-coded ids (`grep -n "env(\|request()->all\|?? 1" $C` → none) |
| F5 Routes | CTT-10, CTT-11 | F12 Style | CTT-19 |
| F6 Controller shape | CTT-12, CTT-13, CTT-14, CTT-15 | F13 Deep read | CTT-20, CTT-21 |
| F7 Models | CTT-01 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TimetableFoundation/app/Http/Controllers/ClassTimetableTypeController.php` | controller | 594 | this report | ✅ whole class |
| 2 | `Modules/TimetableFoundation/app/Models/ClassTimetableType.php` | model | 143 | this report (pre-assigned in 00-CLASS-OWNERS) | ✅ whole class |
| 3 | `Modules/TimetableFoundation/app/Policies/ClassTimetableTypePolicy.php` | policy | 44 | this report | ✅ — unreachable, see CTT-07 |
| 4 | `Modules/TimetableFoundation/routes/web.php` lines 242-251 | routes | — | this report | ✅ |
| 5 | `resources/views/class-timetable-type/create.blade.php` | create page | 425 | this report | ✅ |
| 6 | `resources/views/class-timetable-type/edit.blade.php` | edit page | 202 | this report | ✅ |
| 7 | `resources/views/class-timetable-type/show.blade.php` | show page | 111 | this report | ✅ |
| 8 | `resources/views/class-timetable-type/trash.blade.php` | trash page | 72 | this report | ✅ |
| 9 | `resources/views/class-timetable-type/index.blade.php` | tab pane | 160 | this report | ✅ — orphan, CTT-18 |
| — | `AcademicTerm`, `TimetableType`, `PeriodSet` | TimetableFoundation models | — | ↗ AcademicTermController / TimetableTypeController / PeriodSetController reports | ↗ linked — usage only (loaded for dropdowns and shown in views) |
| — | `ClassSection`, `SchoolClass`, `Section` | SchoolSetup (other module) | — | common (§4.2) | usage only — `ClassSection::with('section')`, `SchoolClass::where('is_active')`, `Section` relation on the model |
| — | `Controller`, `BaseModel`, `activityLog()` helper, `x-backend.*` components, layouts | app glue / shared components | — | common | referenced only |

**Pre-applied 2026-10-10:** none of the in-scope files appears in `../PRE-APPLIED-2026-10-10.md`.
This controller was **not** part of that pass — it still carries the old try/catch shape (see CTT-03).

## 4. Routes

```
POST      timetable-foundation/class-timetable                                   class-timetable.store            store
GET|HEAD  timetable-foundation/class-timetable                                   class-timetable.index            index
GET|HEAD  timetable-foundation/class-timetable/ajax/sections/{classId}           class-timetable.sections.ajax     getSectionsByClass
GET|HEAD  timetable-foundation/class-timetable/create                            class-timetable.create           create
GET|HEAD  timetable-foundation/class-timetable/trash/view                        class-timetable.trashed          trashedClassTimetable
POST      timetable-foundation/class-timetable/{classTimetableType}/toggle-status class-timetable.toggleStatus    toggleStatus
GET|HEAD  timetable-foundation/class-timetable/{class_timetable}                 class-timetable.show             show
PUT|PATCH timetable-foundation/class-timetable/{class_timetable}                 class-timetable.update           update
DELETE    timetable-foundation/class-timetable/{class_timetable}                 class-timetable.destroy          destroy
GET|HEAD  timetable-foundation/class-timetable/{class_timetable}/edit            class-timetable.edit             edit
DELETE    timetable-foundation/class-timetable/{id}/force-delete                 class-timetable.forceDelete      forceDelete
GET|HEAD  timetable-foundation/class-timetable/{id}/restore                      class-timetable.restore          restore   ← GET
```

Middleware on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`. (RTE-05 ✅)
**Unrouted public methods:** none — all 12 public methods are routed.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect to tab) | — |
| create | ✅ | create | — | — | — | CTT-16 |
| store | ✅ | create | ❌ **none** | `Created` (per row) | tt_class_timetable_types_jnt, sys_activity_logs | CTT-04, 08, 09, 12, 13, 21 |
| show | ✅ | view | — | — | — | CTT-11, 17 |
| edit | ✅ | update | — | — | — | CTT-11, 13 |
| update | ✅ | update | ✅ inside try | `Updated` | tt_class_timetable_types_jnt, sys_activity_logs | CTT-02, 03, 06, 08, 09, 11, 12 |
| destroy | ✅ | delete | ✅ inside try | `Trashed` | tt_class_timetable_types_jnt (**hard delete**), sys_activity_logs | CTT-01, 03, 06 |
| getSectionsByClass | ✅ | viewAny | — | — | — | — |
| trashedClassTimetable | ✅ | restore | — | — | — (read; crashes) | CTT-01 |
| forceDelete | ✅ | forceDelete | ✅ inside try | `Deleted` | tt_class_timetable_types_jnt, sys_activity_logs | CTT-01, 03, 06, 20 |
| restore | ✅ GET | restore | ✅ inside try | `Restored` | tt_class_timetable_types_jnt, sys_activity_logs | CTT-01, 03, 06, 10 |
| toggleStatus | ✅ | update | ✅ inside try | `Toggled` (before save) | tt_class_timetable_types_jnt, sys_activity_logs | CTT-03, 05, 06 |

**Tables each mutation SHOULD touch (controller-alignment §0.1):**
- **destroy** should write `deleted_at` (soft delete) plus the log. It does neither — it physically deletes the row (CTT-01).
- **forceDelete** should only touch rows that are already in the trash, and should account for the 43 `tt_slot_requirements` rows that reference it (CTT-20). It does neither.
- **store** should atomically write all N class × section rows plus their N audit rows. It writes them one by one, un-atomic (CTT-04).

## 6. Findings

### F7 — Models
#### CTT-01 · **B** · F7/MDL — `ClassTimetableType` is missing `SoftDeletes`; Delete permanently destroys rows, the trash page 500s, restore and force-delete can never work
**Where:** `Modules/TimetableFoundation/app/Models/ClassTimetableType.php:10-13` (trait absent) vs `database/migrations/tenant/2026_06_16_152626_create_tt_class_timetable_type_jnt_table.php:43` (`$table->softDeletes();`) vs controller `:386` (`delete()`), `:461` (`onlyTrashed()`), `:477` (`withTrashed()`), `:513` (`onlyTrashed()`)
```php
// model — extends BaseModel, no trait
class ClassTimetableType extends BaseModel
{
    protected $table = 'tt_class_timetable_types_jnt';
// controller destroy()
$classTimetableType->delete();          // without SoftDeletes this is a HARD delete
// controller trashedClassTimetable()
$classTimetableTypes = ClassTimetableType::onlyTrashed()->orderByDesc('id')->paginate(10);
```
**Evidence:**
- `php artisan tinker --execute 'class_uses_recursive(...ClassTimetableType::class)'` → `SoftDeletes` NOT in the list; `method_exists(...,"onlyTrashed")` → `false`, `withTrashed` → `false`, `restore` → `false`.
- `SHOW COLUMNS FROM tt_class_timetable_types_jnt` → `deleted_at timestamp NULL` exists. Migration line 43 adds `$table->softDeletes()`.
- Live data: `total=344, trashed=0` — no row has ever accumulated a `deleted_at`.
- The `destroy()` docblock says "soft delete"; `restore()`/`forceDelete()`/`trashedClassTimetable()` all depend on SoftDeletes scope methods.

**Consequence:** every Delete on the Class Assignment tab physically removes a configuration row forever (data loss on a normal path), the Trash page crashes with `BadMethodCallException` (HTTP 500), and Restore/Permanently-Delete always fail with the generic flash because `onlyTrashed()`/`withTrashed()` throw inside the catch.

### F1 — Errors
#### CTT-02 · H · ERR-02 (under D1) — `update()` validates inside the `try`; the generic catch turns a 422 into a redirect and discards every field error
**Where:** `ClassTimetableTypeController.php:305-368` (validation at `:309`, generic catch at `:364-367`)
```php
try {
    return DB::transaction(function () use ($request, $id) {
        $classTimetableType = ClassTimetableType::findOrFail($id);
        $validated = $request->validate([ ... ]);
        ...
    });
} catch (ModelNotFoundException $e) {
    throw $e;
} catch (\Throwable $e) {
    Log::error('ClassTimetableTypeController::update failed', ['error' => $e->getMessage()]);
    return back()->with('error', 'The operation could not be completed.');
}
```
**Evidence:** `php ../prime_info/Final/CodeReview/scripts/scan.php…` flagged `validate/validateWithBag inside try; generic catch swallows ValidationException` at line 305. The first catch is `ModelNotFoundException` only, so a `ValidationException` (missing required `class_id`, bad date, …) falls into `catch (\Throwable)`.
**Consequence:** an invalid edit form submission shows "The operation could not be completed." with no field errors, so the user cannot tell what to fix.

#### CTT-03 · M · ERR-00 (D1) / ERR-05 / ERR-04 — five methods still carry the old try/catch shape, log only `getMessage()`, and toggleStatus returns a redirect on a JSON endpoint
**Where:** `ClassTimetableTypeController.php:364-367, 404-407, 497-500, 537-540, 588-591`
```php
} catch (\Throwable $e) {
    Log::error('ClassTimetableTypeController::update failed', ['error' => $e->getMessage()]);
    return back()->with('error', 'The operation could not be completed.');
}
```
**Evidence:** `substr_count($C,"try {")` = 5, `} catch` = 10 (5 × ModelNotFound + 5 × Throwable). `grep -c 'getMessage()'` → 5 log-only sites. `toggleStatus()` success path returns `response()->json(...)` while its catch returns `back()`.
**Consequence:** controller-internal errors lose the stack trace (ERR-05), the AJAX toggle gets an HTML redirect instead of JSON on failure (ERR-04), and five methods fail to match the rest of the module's ERR-00 shape.
**Note:** this is the same pattern the 2026-10-10 pass removed from the other TimetableFoundation controllers; it was missed here because this controller was not in the pass list.

### F2 — Transactions/Audit
#### CTT-04 · H · TXN-01 (+ QRY-07) — `store()` writes one row + one audit row per class × section with no `DB::transaction`
**Where:** `ClassTimetableTypeController.php:186-231`
```php
foreach ($classIds as $classId) {
    ...
    $entry = ClassTimetableType::updateOrCreate([...], array_merge($commonData, ...));
    activityLog($entry, 'Created', [...]);
    ...
}
```
**Evidence:** `grep -n "DB::transaction" $C` → appears only at lines 306, 379, 476, 512, 552 (update/destroy/forceDelete/restore/toggleStatus). `store()` has none. The scanner flags `store() makes 2 writes + activityLog with no transaction` and `updateOrCreate() inside a loop` twice (lines 191, 213).
**Consequence:** a failure halfway through (a duplicate-key, a check-constraint violation, a DB hiccup) leaves a partial assignment on the tab with no audit trail for the rows that did land.

#### CTT-05 · M · TXN-04 — `toggleStatus()` writes the audit row **before** the write it describes
**Where:** `ClassTimetableTypeController.php:557-567`
```php
$classTimetableType->is_active = (bool) $request->input('is_active');
// Activity Log
activityLog($classTimetableType, 'Toggled', [...]);
if ($classTimetableType->save()) { ... }
```
**Evidence:** the `activityLog` call (line 560) precedes `save()` (line 569) and is inside the transaction.
**Consequence:** if `save()` fails (a DB error), the audit entry "status was updated" is committed by the transaction rollback — but if any listener or check between log and save throws, the log and the save disagree about what happened; per TXN-04 the log must come after the write inside the same transaction.

#### CTT-06 · L · TXN-05 — the redirect/flash (and the toggle's JSON) are built inside the transaction closure
**Where:** `ClassTimetableTypeController.php:355-357, 395-397, 488-490, 528-530, 570-581`
**Evidence:** each `DB::transaction(function () { … return redirect()...; })` returns an HTTP response, not data. `return DB::transaction(...)` at all 5 sites.
**Consequence:** the success flash is written to the session before commit; if the commit fails, the next page shows "created successfully" for a row that does not exist.

### F3 — Authorization
#### CTT-07 · L · AUTH-04 — the ClassTimetableTypePolicy is registered but nothing consults it
**Where:** `Modules/TimetableFoundation/app/Providers/TimetableFoundationServiceProvider.php:125` (`Gate::policy(ClassTimetableType::class, ClassTimetableTypePolicy::class)`), all controller gates are strings (`Gate::authorize('tenant.timetable-foundation.class-timetable.*')`) at `:28,38,114,243,255,303,376,416,459,473,509,549`
**Evidence:** every routed method (12/12) passes a permission *string*, so PHP never dispatches to the policy (AUTH-01 ✅ — each method authorizes before loading records, and the exact-name permission query returns all 7 seeded rows in `sys_permissions`: `create`, `view`, `viewAny`, `update`, `delete`, `restore`, `forceDelete`).
**Consequence:** the policy is dead code that looks active — the module-wide pattern already reported as ATC-14 in the AcademicTermController audit; a future change to the policy silently changes nothing.

### F4 — Validation
#### CTT-08 · M · VAL-02 + VAL-07 — no FormRequest; validation is inline in `store()`/`update()`, and the class/section cross-field rule is hand-written in the controller
**Where:** `ClassTimetableTypeController.php:121-140` (store), `:309-324` (update), `:151-160` (store cross-field)
```php
foreach ($classIds as $classId) {
    if (! in_array((int) $classId, $allSectionClassIds) && empty($sectionIdsByClass[$classId])) {
        return back()->withInput()->withErrors([...]);
    }
}
```
**Evidence:** `grep -oE '[A-Z][A-Za-z]+Request\b' $C` → nothing (no FormRequest imported). Scanner flags `inline validation in controller` at lines 121, 309 and the business rule sits in the controller.
**Consequence:** the cross-field "each selected class needs All Sections or a section" rule cannot be unit-tested and is not enforced on any other writer of this table; validation and request shape live in the controller instead of a FormRequest.

#### CTT-09 · H · VAL/DDL — `after_or_equal` allows `effective_to == effective_from`, but the DB CHECK requires strictly `<`
**Where:** `ClassTimetableTypeController.php:138` (store), `:322` (update) vs `database/migrations/tenant/2026_06_16_152626_create_tt_class_timetable_type_jnt_table.php:47`
```php
'effective_to' => 'nullable|date|after_or_equal:effective_from',
```
**Evidence:** `SHOW` of `information_schema.CHECK_CONSTRAINTS` → `chk_valid_effective_range: (effective_from < effective_to)` is present on the live tenant table; `sql_mode` includes strict mode; 0 rows currently have equal dates.
**Consequence:** an admin who picks the same date for From and To passes validation and hits SQL error 3819 — a 500 on create (no try) and a generic "could not be completed" flash on update, losing the form.

### F5 — Routes
#### CTT-10 · H · RTE-01 — Restore runs over a GET request
**Where:** `Modules/TimetableFoundation/routes/web.php:247`
```php
Route::get('/class-timetable/{id}/restore', [ClassTimetableTypeController::class, 'restore'])->name('class-timetable.restore');
```
**Evidence:** `route:list` shows `GET|HEAD …/{id}/restore`. The only caller is `trash.blade.php:45-49` via `<x-backend.table.action-trashed>`, which derives the verb from the route. The scanner reports `GET …/{id}/restore … changes state`.
**Consequence:** GET has no CSRF protection, so a link preview or prefetcher can restore a trashed assignment.

#### CTT-11 · M · CTL-03/RTE — resource routes key `{class_timetable}` while show/edit/update/destroy take `$id` and `findOrFail`
**Where:** `ClassTimetableTypeController.php:241, 253, 301, 374` vs the resource at `routes/web.php:250` (implicit parameter `{class_timetable}`)
```php
public function show($id) { ... ClassTimetableType::findOrFail($id); }
```
**Evidence:** `route:list` shows `/{class_timetable}`; only `toggleStatus` (line 547) has a matching bound model (`ClassTimetableType $classTimetableType` against `{classTimetableType}`). The 4 scalar-`$id` methods still work (Laravel splices route parameters positionally) but skip route model binding.
**Consequence:** no 404-abort shorthand, repeated `findOrFail` on every read, and the parameter name disagrees with the route — the same inconsistency `module-finalization.md` §3.3.1 warns turns an unbound model into a silent INSERT.

### F6 — Controller shape
#### CTT-12 · M · CTL-02 — `store()` is 125 lines
**Where:** `ClassTimetableTypeController.php:112-236`
**Evidence:** `awk 'NR>=112 && NR<=236' $C | wc -l` → the method body spans 125 lines.
**Consequence:** the bulk-create loop, its validation block and its redirect could be read as three smaller units; at 125 lines it is past the 80-line extraction bar.

#### CTT-13 · M · CTL-05 — the same try/catch block and the same error string are duplicated in 5 methods; create()/edit() duplicate the dropdown loaders
**Where:** `ClassTimetableTypeController.php:364-368, 404-408, 497-501, 537-541, 588-592` (identical `catch (\Throwable)` + `'The operation could not be completed.'`); `:40-57` vs `:259-286` (academicTerms/timetableTypes/classes/periodSets loaders)
**Evidence:** `grep -c "The operation could not be completed.\|could not be completed" $C` → 5. The dropdown queries differ only in the `$id` guard gone from edit.
**Consequence:** one future change to the error shape or to the dropdown payload must be made 5 times, and a missed copy keeps old behaviour; CTT-03 removes the 5 duplicates in one pass.

#### CTT-14 · L · CTL-04 — all 12 public methods have no return type
**Where:** `ClassTimetableTypeController.php:26, 36, 112, 241, 253, 301, 374, 414, 457, 471, 507, 547`
**Evidence:** the scanner flags `index() has no return type` … `toggleStatus() has no return type`.
**Consequence:** the caller cannot tell a page, a redirect, or JSON is coming, and PHP cannot enforce it.

#### CTT-15 · L · CTL-10 — `$sections = collect()` is built and passed to `create()`'s view but never used there
**Where:** `ClassTimetableTypeController.php:52-53, 97-105`
**Evidence:** `create.blade.php` loads sections via AJAX (the `@json`/`fetch` block) and never references `$sections`; `grep -n '\$sections' create.blade.php` → none.
**Consequence:** one dead variable per request — harmless but signals the loader was copied from `edit()` and trimmed.

### F9 — Queries/Performance
#### CTT-16 · H · QRY-01 + QRY-05 — `create()` runs one `ClassSection` count per class and aggregates in PHP over all rows of the type
**Where:** `ClassTimetableTypeController.php:77-92`
```php
$assignedByClass = ClassTimetableType::where('timetable_type_id', $selectedTimetableTypeId)
    ->where('applies_to_all_sections', false)->whereNotNull('section_id')
    ->get()->groupBy('class_id')->map(...);
foreach ($assignedByClass as $classId => $assignedSectionIds) {
    $totalSections = ClassSection::where('class_id', $classId)->where('is_active', true)->count();   // per class
    ...
}
```
**Evidence:** the scanner reports `ClassSection::where() inside a loop — N+1 query` (line 85) and `->get()->groupBy() — filter/aggregate in SQL instead` (line 77).
**Consequence:** a school with many classes and a wide assignment gets one count query per class on the create page (N+1), plus the whole assignment table loaded into PHP to hide already-covered classes.

### F10 — Views
#### CTT-17 · M · VIEW/model usage — `show` and `trash` read `$ctt->schoolClass`, but the model's relation is `class()`
**Where:** `show.blade.php:32`, `trash.blade.php:25` vs `ClassTimetableType.php:76-79`
```php
// trash.blade.php
<td>{{ $ctt->schoolClass?->name ?? '—' }}</td>
// model
public function class() { return $this->belongsTo(SchoolClass::class, 'class_id'); }
```
**Evidence:** `method_exists(ClassTimetableType::class, "schoolClass")` → `false`; Eloquent returns `null` for a missing relation, so `?->name` silently resolves to `—`. The same table renders `$ctt->section?->name`, `$ctt->timetableType?->name`, `$ctt->academicTerm?->term_name` correctly — only the class column is wrong.
**Consequence:** the Class column on the show page and the trash table always shows "—" even though the row has a `class_id`; no error, so nobody notices until a screenshot.

#### CTT-18 · L · VIEW — `show.blade.php` prints a `priority` column that does not exist, and `index.blade.php` is an orphan copy of the AcademicTerm list
**Where:** `show.blade.php:52`, `index.blade.php:1-160`
```php
<td>{{ $classTimetableType->priority ?? 0 }}</td>
```
**Evidence:** `SHOW COLUMNS FROM tt_class_timetable_types_jnt` → no `priority` column, so the row always shows `0` ("Priority: 0"). `grep -rn "class-timetable-type.index" Modules app resources` → no view reference; `index()` redirects to the menu tab (`:30`), so the 160-line tab pane (which queries `$academicTerms`, `$academicSessions` — data `index()` never passes) is dead. Blade checks: all 5 in-scope blades compile with `push-lost=0, strayPush=0`; no `{!! !!}`; `@php` blocks do not contain `{{-- --}}`.
**Consequence:** a misleading "Priority: 0" on the details page, and a duplicated, drift-prone copy of the academic-term list sitting in the class-timetable folder — the same ATC-17 pattern from the AcademicTermController audit.

### F12 — Style
#### CTT-19 · L · STY — missing `strict_types`, an unused import, and import formatting
**Where:** `ClassTimetableTypeController.php:1-19`, `ClassTimetableType.php:1-9`, `ClassTimetableTypePolicy.php:1-6`
**Evidence:** the scanner flags `missing declare(strict_types=1)` in all three files. `ClassTimetableType.php:6` imports `HasFactory` but the class body never uses it (`grep -n "HasFactory" $M` line 6 only). The controller's `use` block has stray blank lines between framework imports.
**Consequence:** style debt only — Pint will collapse the import block, and `strict_types` is added when the files are touched.

### F13 — Deep read
#### CTT-20 · H · deep read — `forceDelete()` accepts a live id and checks no children; 43 rows are referenced by `tt_slot_requirements`
**Where:** `ClassTimetableTypeController.php:471-502`
```php
$classTimetableType = ClassTimetableType::withTrashed()->findOrFail($id);  // a LIVE id is accepted
$classTimetableType->forceDelete();
```
**Evidence:** `withTrashed()` matches live rows too, so a DELETE to `/class-timetable/{id}/force-delete` on a live row is accepted. FK measured: `tt_slot_requirements.class_timetable_type_id` → `tt_class_timetable_types_jnt` with `ON DELETE NO ACTION`, and 43 rows (43 distinct ctts) reference it. Unlike AcademicTerm (ATC-03's 9 FK tables), here only one child table exists.
**Consequence:** a caller who guesses an id can purge a live assignment row; with any `tt_slot_requirements` row attached, the delete fails with error 1451 and the generic flash — either way the "trash-first" guarantee is absent.
**Note:** this is latent today because CTT-01 makes `withTrashed()` throw first; it must be sequenced after the SoftDeletes fix.

#### CTT-21 · M · deep read — `store()` logs event `Created` even when `updateOrCreate` updated an existing row
**Where:** `ClassTimetableTypeController.php:191-208, 213-228`
**Evidence:** `updateOrCreate` matches on `(academic_term_id, timetable_type_id, class_id, section_id, applies_to_all_sections)`, so re-submitting the same combination silently overwrites the period set, flags and effective dates — and every loop iteration logs `'Created'`.
**Consequence:** the audit trail says "created" for rows that were overwritten, so the school's activity log understates what an edit to an existing assignment did.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **Other writers of `tt_class_timetable_types_jnt`:** `TimetableTypeController` (store/update flows, `Modules/TimetableFoundation/app/Http/Controllers/TimetableTypeController.php:223-230, 627, 638`), the `TimetableMastersCompleteSeeder` (`:56` hard `delete()`), the `ClassTimetableTypeSeeder`, and several SmartTimetable/StandardTimetable readers. CTT-01 (missing SoftDeletes) makes **any** soft-delete assumption about this table unsafe for all of them; the model fix on this controller's report is the shared-model fix.
- **Unreachable policies (module-wide):** the same gate-strings bypass as ATC-14 — every policy in the module is dead code until gates call policies or a module-level decision removes them.
- **`tt_slot_requirements` FK:** `fk_sa_class_timetable_type` is `ON DELETE NO ACTION` with 43 live rows; this is the only FK child of the table, and it must be part of the force-delete guard (or a later module decision).
- **The `class()` relation name:** it shadows the PHP keyword `class`; consumers must access it as `$ctt->class` (a bare keyword-safe attribute access in Blade) — which is exactly what the two blades fail to do (CTT-17).

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static or a read-only SQL probe. In particular, the live 344 assignment rows were not touched.
- **Other writers of the table:** `TimetableTypeController`'s assignment flow and the seeders were not audited; their behaviour with the shared model (once CTT-01 is fixed) is that report's business.
- **The `tt_slot_requirements` table itself** and the generation code that consumes `ClassTimetableType` rows (`TimetableFoundationController`, SmartTimetable services) were not audited here; only their FK and count were measured.
- **Data repair:** the 344 existing rows are configuration data and were neither changed nor assessed for correctness.