# TimetableFoundation — Final Audit Index

Protocol: `.claude/rules/final-audit.md`.
⛔ Append a row to claim. Edit only your own row. Never rewrite this file.

| Controller | Status | B | H | M | L | Report | By | Updated |
|---|---|---|---|---|---|---|---|---|
| AcademicTermController | FIXED | 0 | 4 | 7 | 6 | [01-report](AcademicTermController-done/01-report.md) · [03-status](AcademicTermController-done/03-status.md) | claude | 2026-10-12 |
| PeriodTypeController | FIXED | 0 | 2 | 6 | 6 | [01-report](PeriodTypeController-done/01-report.md) | opencode / claude (fix) | 2026-10-12 |
| ActivityController | FIXED | 0 | 1 | 8 | 8 | [01-report](ActivityController-done/01-report.md) · [03-status](ActivityController-done/03-status.md) | opencode / claude (fix) | 2026-10-13 |
| PeriodSetController | FIXED | 0 | 7 | 20 | 5 | [01-report](PeriodSetController-done/01-report.md) · [03-status](PeriodSetController-done/03-status.md) | opencode / claude (fix) | 2026-10-13 |
| WorkingDayController | FIXED | 0 | 4 | 11 | 4 | [01-report](WorkingDayController-done/01-report.md) · [03-status](WorkingDayController-done/03-status.md) | opencode / claude (fix) | 2026-10-15 |
| DayTypeController | FIXED | 0 | 2 | 6 | 5 | [01-report](DayTypeController-done/01-report.md) | opencode / claude (fix) | 2026-10-12 |
| RequirementConsolidationController | FIXED | 2 | 7 | 15 | 8 | [01-report](RequirementConsolidationController-done/01-report.md) · [03-status](RequirementConsolidationController-done/03-status.md) | opencode / claude (fix) | 2026-10-14 |
| TimetableTypeController | FIXED | 0 | 4 | 8 | 7 | [01-report](TimetableTypeController-done/01-report.md) · [03-status](TimetableTypeController-done/03-status.md) | opencode / claude (fix) | 2026-10-15 |
| ClassWorkingDayController | FIXED | 0 | 5 | 17 | 7 | [01-report](ClassWorkingDayController-done/01-report.md) · [03-status](ClassWorkingDayController-done/03-status.md) | opencode / claude (fix) | 2026-10-13 |
| SchoolShiftController | FIXED | 0 | 2 | 3 | 6 | [01-report](SchoolShiftController-done/01-report.md) | opencode / claude (fix) | 2026-10-12 |
| SchoolDayController | FIXED | 0 | 2 | 4 | 6 | [01-report](SchoolDayController-done/01-report.md) · [03-status](SchoolDayController-done/03-status.md) | opencode / claude (fix) | 2026-10-14 |
| ClassSubjectSubgroupController | FIXED | 1 | 7 | 16 | 4 | [01-report](ClassSubjectSubgroupController-done/01-report.md) · [03-status](ClassSubjectSubgroupController-done/03-status.md) | opencode / claude (fix) | 2026-10-13 |
| TeacherAssignmentRoleController | FIXED | 0 | 3 | 6 | 6 | [01-report](TeacherAssignmentRoleController-done/01-report.md) · [03-status](TeacherAssignmentRoleController-done/03-status.md) | opencode / claude (fix) | 2026-10-14 |
| ClassTimetableTypeController | FIXED | 1 | 6 | 8 | 6 | [01-report](ClassTimetableTypeController-done/01-report.md) · [03-status](ClassTimetableTypeController-done/03-status.md) | opencode / claude (fix) | 2026-10-13 |
| TimetableAssignmentController | FIXED | 0 | 2 | 6 | 10 | [01-report](TimetableAssignmentController-done/01-report.md) · [03-status](TimetableAssignmentController-done/03-status.md) | opencode / claude (fix) | 2026-10-14 |
| TeacherAvailabilityController | FIXED | 0 | 3 | 6 | 6 | [01-report](TeacherAvailabilityController-done/01-report.md) · [03-status](TeacherAvailabilityController-done/03-status.md) | opencode / claude (fix) | 2026-10-14 |
| PeriodConfigController | FIXED | 0 | 4 | 6 | 8 | [01-report](PeriodConfigController-done/01-report.md) · [03-status](PeriodConfigController-done/03-status.md) | opencode / claude (fix) | 2026-10-13 |
| PeriodSetPeriodController | FIXED | 2 | 3 | 13 | 6 | [01-report](PeriodSetPeriodController-done/01-report.md) · [03-status](PeriodSetPeriodController-done/03-status.md) | opencode / claude (fix) | 2026-10-13 |
| TimingProfileController | FIXED (retired) | 1 | 3 | 8 | 6 | [01-report](TimingProfileController-done/01-report.md) · [03-status](TimingProfileController-done/03-status.md) | opencode / claude (fix) | 2026-10-15 |
| SchoolTimingProfileController | AUDITED | 2 | 2 | 9 | 6 | [01-report](SchoolTimingProfileController/01-report.md) | opencode | 2026-10-10 |
| TimetableController | FIXED | 2 | 5 | 6 | 8 | [01-report](TimetableController-done/01-report.md) · [03-status](TimetableController-done/03-status.md) | opencode / claude (fix) | 2026-10-14 |
| SlotRequirementController | FIXED | 0 | 4 | 6 | 10 | [01-report](SlotRequirementController-done/01-report.md) · [03-status](SlotRequirementController-done/03-status.md) | opencode / claude (fix) | 2026-10-14 |
| SubActivityDetailController | FIXED | 1 | 2 | 3 | 3 | [01-report](SubActivityDetailController-done/01-report.md) · [03-status](SubActivityDetailController-done/03-status.md) | opencode / claude (fix) | 2026-10-14 |
| ConfigController | FIXED | 0 | 1 | 6 | 8 | [01-report](ConfigController-done/01-report.md) | opencode / claude (fix) | 2026-10-12 |
| OptimisationReportController | FIXED | 0 | 2 | 5 | 3 | [01-report](OptimisationReportController-done/01-report.md) · [03-status](OptimisationReportController-done/03-status.md) | opencode / claude (fix) | 2026-10-13 |
| RoomAvailabilityController | FIXED | 0 | 1 | 6 | 2 | [01-report](RoomAvailabilityController-done/01-report.md) · [03-status](RoomAvailabilityController-done/03-status.md) | opencode / claude (fix) | 2026-10-14 |
| PriorityConfigController | AUDITED | 0 | 0 | 6 | 6 | [01-report](PriorityConfigController/01-report.md) | opencode | 2026-10-10 |
| TimetableFoundationController | FIXED | 0 | 3 | 3 | 2 | [01-report](TimetableFoundationController-done/01-report.md) · [03-status](TimetableFoundationController-done/03-status.md) | claude | 2026-10-12 |
