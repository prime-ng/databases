# Final Audit — TimetableFoundation / PeriodSetController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/PeriodSetController.php` (1,153 lines, 13 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 7 HIGH.**
This is the largest and most write-heavy controller in the module. The routes and permissions are sound (all 8 abilities declared and seeded), but the write paths are not safe to ship:

- **`update()` is not atomic.** It performs seven separate write units — a default-clear, the parent row, three inner transactions, a counters recompute and an audit row — with no single transaction around them. A failure midway leaves the parent saved and the children lost.
- **Clearing a period's "Short Name" aborts the save.** Validation says `nullable`, the column is `NOT NULL` (DDL and migration agree). The whole period edit rolls back while the parent row — written outside the transaction — stays changed.
- **Delete Permanently accepts a live set** (`withTrashed()`) and checks no children. A set with only CASCADE children is silently purged; a set with NO ACTION children returns a raw FK error.
- **Restore runs over GET** and **`store()` clears the previous default outside its transaction**.

The worst finding is **PSC-03**, the non-atomic `update()`, because it is the path every save takes.
Effort is roughly a day to a day and a half. Eleven DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 7 | 20 | 5 | 9 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PSC-01, PSC-02 | F8 Services/Jobs | clean: no service, no job, no event (`grep -oE '[A-Z][A-Za-z]+(Request\|Policy\|Service\|Job\|Event)' $C` → none) |
| F2 Transactions/Audit | PSC-03, PSC-04, PSC-05, PSC-06, PSC-07 | F9 Queries/Perf | PSC-23, PSC-24, PSC-25 |
| F3 Authorization | PSC-08, PSC-09 | F10 Views | PSC-26, PSC-27, PSC-28 |
| F4 Validation | PSC-10, PSC-11, PSC-12 | F11 Security/Tenancy | clean |
| F5 Routes | PSC-13 | F12 Style | PSC-29 |
| F6 Controller shape | PSC-14, PSC-15, PSC-16, PSC-17, PSC-18, PSC-19, PSC-20 | F13 Deep read | PSC-30, PSC-31, PSC-32 |
| F7 Models | PSC-21, PSC-22 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TimetableFoundation/app/Http/Controllers/PeriodSetController.php` | controller | 1,153 | this report | ✅ whole class |
| 2 | `Modules/TimetableFoundation/app/Models/PeriodSet.php` | model | 155 | **this report (pre-assigned)** | ✅ |
| 3 | `Modules/TimetableFoundation/app/Policies/PeriodSetPolicy.php` | policy | 44 | this report | ✅ — unreachable, see PSC-09 |
| 4 | `Modules/TimetableFoundation/routes/web.php` lines 232-239 | routes | — | this report | ✅ |
| 5 | `resources/views/period-set/edit.blade.php` | page | 849 | this report | ✅ |
| 6 | `resources/views/period-set/show.blade.php` | page | 129 | this report | ✅ |
| 7 | `resources/views/period-set/trash.blade.php` | page | 91 | this report | ✅ — see PSC-26 |
| 8 | `resources/views/period-set/_create-modal.blade.php` | create dialog | 15 | this report | ✅ |
| 9 | `resources/views/period-set/_create-fields.blade.php` | dialog fields | 169 | this report | ✅ — see PSC-27 |
| 10 | `resources/views/pages/partials/timetable-masters/period-sets/_list.blade.php` | tab list | 168 | this report | ✅ (rendered by `TimetableFoundationController`) |
| 11 | `resources/views/period-set/index.blade.php` | page (dead) | 48 | this report | ✅ — orphan, PSC-28 |
| 12 | `resources/views/period-set/create.blade.php` | page (dead) | 190 | this report | ✅ — orphan, PSC-28 |
| 13 | `resources/views/period-set/_period-config-picker.blade.php` | partial (dead) | 297 | this report | ✅ — orphan, PSC-28 |
| — | `PeriodConfig.php` | model | — | [↗ PeriodConfigController](../../TimetableFoundation-done/PeriodConfigController-done/01-report.md) | usage only |
| — | `PeriodSetPeriod.php` | model | — | [↗ PeriodSetPeriodController](../../TimetableFoundation-done/PeriodSetPeriodController-done/01-report.md) | usage only |
| — | `PeriodType.php` | model | — | [↗ PeriodTypeController](../../TimetableFoundation-done/PeriodTypeController-done/01-report.md) | usage only |
| — | `SchoolShift.php` | model | — | [↗ SchoolShiftController](../../TimetableFoundation-done/SchoolShiftController-done/01-report.md) | usage only |
| — | `Config.php` | model | — | [↗ ConfigController](../../TimetableFoundation-done/ConfigController-done/01-report.md) | usage only |
| — | `ClassModeRule.php` | model | — | [↗ ClassSubjectSubgroupController](../../TimetableFoundation-done/ClassSubjectSubgroupController-done/01-report.md) | usage only — missing table, PSC-22 |
| — | `Timetable.php` | model | — | [↗ TimetableController](../../TimetableFoundation-done/TimetableController-done/01-report.md) | relation target only |
| — | `SchoolClass` (SchoolSetup), `BaseModel`, `activityLog()`, `flash()`, `x-backend.table.action`/`action-trashed`/`status-switch`/`tab.search-bar`/`tab.modal`/`form.status-switch`/`form.button-submit`, layouts, `x-tenantcore::export-buttons` | common | — | common | referenced; props checked against component sources only |

**Pre-applied 2026-10-10:** none of this controller's in-scope files appear in `../PRE-APPLIED-2026-10-10.md`. That pass touched `routes/web.php` (dead-route cleanup) — the `period-set` block (lines 232-239) is unchanged — and converted sibling controllers. This audit is fresh (D10). Consequence: the sibling controllers were moved to the D1 shape while PeriodSetController was not, so it is now the outlier holding seven controller `try/catch` blocks.

## 4. Routes

```
GET|HEAD  timetable-foundation/period-set                             timetable-foundation.period-set.index          index
POST      timetable-foundation/period-set                             timetable-foundation.period-set.store          store
GET|HEAD  timetable-foundation/period-set/ajax/period-configs         timetable-foundation.period-set.ajaxPeriodConfigs  ajaxPeriodConfigs
GET|HEAD  timetable-foundation/period-set/trash/view                  timetable-foundation.period-set.trashed        trashedPeriodSet
DELETE    timetable-foundation/period-set/{id}/force-delete           timetable-foundation.period-set.forceDelete    forceDelete
GET|HEAD  timetable-foundation/period-set/{id}/restore                timetable-foundation.period-set.restore        restore   ← GET
POST      timetable-foundation/period-set/{periodSet}/ajax/sync-range timetable-foundation.period-set.ajaxSyncRange  ajaxSyncRange
POST      timetable-foundation/period-set/{periodSet}/toggle-status   timetable-foundation.period-set.toggleStatus   toggleStatus
GET|HEAD  timetable-foundation/period-set/{period_set}                timetable-foundation.period-set.show           show
PUT|PATCH timetable-foundation/period-set/{period_set}                timetable-foundation.period-set.update         update
DELETE    timetable-foundation/period-set/{period_set}                timetable-foundation.period-set.destroy        destroy
GET|HEAD  timetable-foundation/period-set/{period_set}/edit           timetable-foundation.period-set.edit           edit
```

Middleware on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified` — RTE-05 clean.
**Unrouted public methods:** `create` (line 41). It is retired on purpose (TM-05) and already returns `abort(403, …)` under a `NOT ROUTED` comment — D5 satisfied, no action.
**RTE-06:** the custom routes (trash / restore / force-delete / toggle-status) are registered **after** `Route::resource` (lines 235-239), unlike the sibling `period-set-period` block which puts them first. No capture occurs — the resource's show matches exactly one segment (`/period-set/{period_set}`) and edit requires the literal `/edit`, so `/trash/view` and `/{id}/restore` cannot be swallowed. **Checked, not present.** The ordering is nevertheless inconsistent with the module's own convention and should be corrected opportunistically.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect to tab) | — |
| create | ❌ (retired) | none (abort 403) | — | — | — | D5-clean |
| store | ✅ | create | parent+children+counters+log in one closure; **default-clear outside** | `Stored` (inside) | tt_period_sets, tt_period_set_periods_jnt, sys_activity_logs | PSC-01, 04, 12, 17, 18 |
| show | ✅ | view | — | — | — | PSC-16 |
| edit | ✅ | update | — | — | — (reads only) | PSC-16, 19, 25 |
| update | ✅ | update (bound) | **no outer tx**; 3 inner closures; counters + log outside | `Updated` (**outside** tx) | tt_period_sets, tt_period_set_periods_jnt, sys_activity_logs | PSC-01, 02, 03, 05, 06, 07, 10, 11, 12, 15, 17, 23, 24, 32 |
| destroy | ✅ | delete | closure | `Trashed` (inside) | tt_period_sets, sys_activity_logs | PSC-01, 06, 31 |
| restore | ✅ GET | restore | closure | `Restored` (inside) | tt_period_sets, sys_activity_logs | PSC-01, 06, 13 |
| trashedPeriodSet | ✅ | restore | — | — | — | — |
| forceDelete | ✅ | forceDelete | closure | `Deleted` (inside) | tt_period_sets (cascade tt_period_set_periods_jnt), sys_activity_logs | PSC-01, 06, 30 |
| ajaxPeriodConfigs | ✅ | viewAny | — | — | — (read-only) | PSC-12 |
| ajaxSyncRange | ✅ | update (**inside try**) | closure | `Updated` (inside) | tt_period_sets, tt_period_set_periods_jnt, sys_activity_logs | PSC-01, 08, 12 |
| toggleStatus | ✅ | update (**inside try**) | **save outside**; the closure wraps only the log | `Toggled` (inside a log-only tx) | tt_period_sets, sys_activity_logs | PSC-01, 05, 08, 12 |

**Tables each mutation SHOULD touch (before counting what it does) — `controller-alignment.md` §0.1:**
- **store / update:** `tt_period_sets` (the row **and** the prior default), `tt_period_set_periods_jnt` (membership), `sys_activity_logs` — all in ONE transaction. store runs the default-clear outside it; update has no single transaction at all.
- **destroy / restore:** `tt_period_sets`, `sys_activity_logs`. destroy is soft-delete; children are untouched (see PSC-31).
- **forceDelete:** `tt_period_sets`, `sys_activity_logs`, and it MUST account for `tt_period_set_periods_jnt` (CASCADE), `tt_class_timetable_types_jnt` (NO ACTION, 344 rows), `tt_timetables` (NO ACTION, 7 rows). It checks none.
- **ajaxSyncRange / toggleStatus:** as listed; toggleStatus writes the row outside the transaction that logs it.

## 6. Findings

### F1 — Errors

#### PSC-01 · M · ERR-00 (D1) + ERR-05 — seven controller `try/catch` blocks survive, and each logs only the message
**Where:** `store:152-192` · `update:420-503` · `destroy:561-606` · `restore:612-642` · `forceDelete:661-698` · `ajaxSyncRange:781-850` · `toggleStatus:1095-1151`
```php
// store:182-186
} catch (\Throwable $e) {
    \Illuminate\Support\Facades\Log::error('PeriodSet store failed', [
        'code'  => $payload['code'] ?? null,
        'error' => $e->getMessage(),
    ]);
// toggleStatus:1142-1145
} catch (AuthorizationException|ValidationException|HttpExceptionInterface $e) {
    throw $e;   // 403 / 422 / abort() must not become a generic 500
} catch (\Throwable $e) {
    Log::error('PeriodSetController::toggleStatus failed', ['error' => $e->getMessage()]);
```
**Evidence:** `grep -nE 'catch \(' $C` → 7 method bodies; `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` confirms each is routed. Scanner rows `ERR-05` at lines 183, 603, 639, 695, 844, 1145.
**Consequence:** Under the settled D1 (Laravel idiom, `final-audit.md` §1) a controller `try/catch` is itself a finding. The file now uses two error models (three sibling controllers were converted on 2026-10-10). Each catch discards the stack trace (ERR-05) and replaces the central handler's response with a generic flash or a JSON 500. Fix: delete the catches; let `bootstrap/app.php` render. If any `\DomainException` is introduced (PSC-02), catch only that.

#### PSC-02 · M · ERR-01 (D2) — a business-rule message is thrown as `RuntimeException`, and nothing here catches it
**Where:** `update:444-448`
```php
if ($parkValue > 255) {
    throw new \RuntimeException(
        'Too many period_ord changes in one save — split into multiple saves.'
    );
}
```
**Evidence:** `grep -n "RuntimeException\|DomainException" $C` → one `RuntimeException`, zero `DomainException`. The surrounding try catches only `\Illuminate\Database\QueryException` (line 468), so this exception escapes `update()` to the central handler.
**Consequence:** D2 requires business-rule messages use `\DomainException`; `RuntimeException` must never be used (and, if caught, never caught broadly — `QueryException` extends it). Here the message is user-meaningful but surfaces as a raw 500. Change to `\DomainException` and catch it explicitly for a flash.

### F2 — Transactions and audit

#### PSC-03 · H · TXN-01 — `update()` is not atomic: seven write units, no single transaction
**Where:** `update:250-555`
```php
if (!empty($validated['is_default'])) { PeriodSet::where('id','!=',$periodSet->id)->update([...]); }   // (1) outside tx
$periodSet->update($payload);                                                                          // (2) outside tx
[$pickerAdded,$pickerRemoved] = $this->syncPickerMembership(...);                                      // (3) own tx
... DB::transaction(function () { ... $psp->update(...); });                                           // (4) own tx
$autoAddedCount = ... $this->autoAddInRangeConfigs($periodSet->fresh());                               // (5) own tx
$this->syncDerivedCountersFromJunction($periodSet);                                                    // (6) update, no tx
activityLog($periodSet, 'Updated', [...]);                                                             // (7) no tx
```
**Evidence:** scanner `TXN-04` at 531; manual read of 366-553. Tables touched: `tt_period_sets` (1,2,6), `tt_period_set_periods_jnt` (3,4,5), `sys_activity_logs` (7).
**Consequence:** TXN-01 requires every multi-table write in ONE `DB::transaction`. A failure after step 2 (e.g. PSC-10's Short Name error) rolls back only the inner closure — the parent row and the cleared default **stay changed**, the membership and audit do not. The user sees an error but half the edit persisted.

#### PSC-04 · H · TXN-01 — `store()` clears the previous default outside the create transaction
**Where:** `store:111-114` then `store:152-181`
```php
if (!empty($validated['is_default'])) {
    PeriodSet::where('is_default', true)->update(['is_default' => false]);   // BEFORE the transaction
}
...
try { DB::transaction(function () use ($payload, $validated, &$periodSet) { ... }); }
```
**Evidence:** manual read; live data has exactly one default (`SELECT SUM(is_default=1)` → 1).
**Consequence:** if `PeriodSet::create()` or the child sync fails, the old default is already unset and no new default exists. The school ends with **no** default period set; screens that resolve "the default set" then find none.

#### PSC-05 · M · TXN-04 — `activityLog()` runs outside the transaction that holds its write
**Where:** `update:529-539` · `toggleStatus:1115-1128`
```php
$periodSet->refresh();
activityLog($periodSet, 'Updated', [...]);   // update(): no enclosing transaction at all

$periodSet->is_active = (bool) $request->boolean('is_active');
if ($periodSet->save()) {                    // the WRITE is outside...
    DB::transaction(function () use ($periodSet) {
        activityLog($periodSet, 'Toggled', [...]);   // ...the transaction wraps only the log
    });
}
```
**Evidence:** scanner `TXN-04` at 531.
**Consequence:** A3 requires the log **inside** the transaction, **after** the write. Here `update()`'s log can be lost while the write stands; in `toggleStatus` the save can fail after the log transaction would have committed independently — a false audit trail in either direction.

#### PSC-06 · M · TXN-05 — the redirect and flash are built inside the transaction closures
**Where:** `destroy:567/593-595` · `restore:629-631` · `forceDelete:667/685-687`
```php
return DB::transaction(function () use ($id) {
    ...
    return redirect()->route('timetable-foundation.period-set.trashed')->with('success', flash('restored.period_set'));
});
```
**Evidence:** scanner `TXN-05` at 567, 629, 667.
**Consequence:** TXN-05: build `redirect()`/`response()` after the closure. Today the success flash is written before commit; a commit failure would still show "restored successfully" on the next page.

#### PSC-07 · M · TXN-06 — "one default set" is check-then-act with no lock and no unique index
**Where:** `store:111-114` · `update:366-370`
**Evidence:** `SHOW CREATE TABLE tt_period_sets` has no unique key on `is_default` (only `uq_periodset_code`); the DDL (`Timetable_DDL_v8.1.sql:466-471`) likewise defines none. Live data: exactly 1 default.
**Consequence:** two concurrent creates/updates can both clear-then-set, leaving two defaults (or none). Nothing in the schema or a lock prevents it. Fix needs `lockForUpdate()` or a partial unique index (DECISION).

### F3 — Authorization

#### PSC-08 · M · AUTH-02 — `Gate::authorize` is called inside the `try` block
**Where:** `ajaxSyncRange:781-782` · `toggleStatus:1095-1096`
```php
try {
    Gate::authorize('tenant.timetable-foundation.period-set.update');
```
**Evidence:** scanner `AUTH-02` at 781, 1095. Both catches do list `AuthorizationException` and rethrow, so the 403 survives **today** — but the authorization still runs after the try opens.
**Consequence:** AUTH-02 requires authorization before the guarded block, outside any `try`. Removing the try/catch entirely (PSC-01) resolves this; if a catch is kept, move the gate above the `try`.

#### PSC-09 · L · AUTH-04 — `PeriodSetPolicy` is registered but nothing consults it
**Where:** `PeriodSetPolicy.php:1-44` · `TimetableFoundationServiceProvider.php:130` (`Gate::policy(PeriodSet::class, PeriodSetPolicy::class)`)
**Evidence:** every gate in the controller, all views, and the request pass a permission **string** (`Gate::authorize('tenant.timetable-foundation.period-set.update')`), which never reaches a policy. `PolicyTest.php:80` exercises the class directly, which is why it looks alive.
**Consequence:** the policy is dead code that appears active — the same module-wide pattern recorded for AcademicTermController (ATC-14). A module-level decision, not a per-controller fix.

### F4 — Validation and input

#### PSC-10 · H · VAL / DDL — clearing a period's Short Name aborts the whole save
**Where:** `update:297` (`'periods.*.short_name' => ['nullable','string','max:50']`) · `update:452-457` (`'short_name' => $periodData['short_name'] ?? null`) · `edit.blade.php:290-296` (input has no `required`)
```php
$psp->update([
    'code'           => strtoupper($periodData['code']),
    'short_name'     => $periodData['short_name'] ?? null,   // NULL into a NOT NULL column
```
**Evidence:** `SHOW COLUMNS FROM tt_period_set_periods_jnt` → `short_name varchar(50) NOT NULL Default=NULL`. The DDL (`Timetable_DDL_v8.1.sql:488`) and the migration (`2026_06_16_152631…:18`) both define it `NOT NULL`. `ConvertEmptyStringsToNull` turns a cleared field into `null`.
**Consequence:** an admin who empties "Short Name" on an in-set row gets a DB integrity error; the inner transaction rolls back, but the parent `$periodSet->update()` (PSC-03) has already persisted, and the flash reads "Could not save the periods due to a database constraint" — which lies (it is not a duplicate). Workaround: re-type a value. H.

#### PSC-11 · M · VAL-04 — the `code` uniqueness rule ignores soft-deleted rows
**Where:** `store:70` · `update:265` — `Rule::unique('tt_period_sets', 'code')`
**Evidence:** the model `PeriodSet` uses `SoftDeletes`, so the rule's query excludes trashed rows. `SHOW CREATE TABLE tt_period_sets` → `UNIQUE KEY uq_periodset_code (code)` — a plain unique that does **not** exclude `deleted_at` (the DDL, `Timetable_DDL_v8.1.sql:470`, agrees). Live: 4 rows, **0 trashed** → latent.
**Consequence:** trash `STANDARD`, then create `STANDARD` again → validation passes, the INSERT raises 1062, the user gets a 500. Same BUG-003 class as ATC-11.

#### PSC-12 · M · VAL-02 / VAL-05 / VAL-07 — no FormRequest; inline, partly untyped, and one cross-field rule hand-written twice
**Where:** `store:64-106` · `update:259-301` · `ajaxPeriodConfigs:711-715` · `ajaxSyncRange:806-809` · `toggleStatus:1098-1100`
```php
$validated = $request->validate([...]);
'is_active' => ['nullable'],            // validates nothing (105, 293)
'periods.*.is_active' => ['nullable'],  // validates nothing (300)
```
**Evidence:** scanner `VAL-02` at 64, 259, 711, 806, 1098 and `VAL-05` at 105, 293, 300. There is no `PeriodSetRequest` in `app/Http/Requests/` (14 requests exist for other controllers). The "to_period_ord ≤ teaching-slot count" closure is duplicated verbatim at `store:87-96` and `update:278-287` (VAL-07).
**Consequence:** rules live in the controller, cannot be reused, and `'nullable'` alone accepts anything. `toggleStatus`'s one-field check is the only acceptable inline case; the rest should be Form Requests. (Extraction is a DECISION given the size.)

### F5 — Routes

#### PSC-13 · H · RTE-01 — Restore changes state over GET
**Where:** `routes/web.php:237` — `Route::get('/period-set/{id}/restore', [PeriodSetController::class, 'restore'])->name('period-set.restore')`
**Evidence:** `route:list` shows `GET|HEAD …/{id}/restore`. The only caller is `trash.blade.php:62` through `x-backend.table.action-trashed`, which derives the verb from `Route::methods()` (component lines 20-24) — so switching to PATCH needs no blade edit.
**Consequence:** GET has no CSRF protection; a link prefetcher or browser pre-scan can restore a trashed set.

### F6 — Controller shape

#### PSC-14 · M · CTL-01 — 1,153 lines, 13 public methods → god controller
**Evidence:** scanner `CTL-01` (`1128 lines, 13 public methods`; `wc -l` = 1,153). Over 1,000 lines = M; over 2,500 = H.
**Consequence:** maintainability debt. Per D3 the split is **deferred** — recorded, never applied in this pass.

#### PSC-15 · H · CTL-02 — `update()` is ~306 lines
**Where:** `update:250-556` (scanner: 306 lines). `store()` is 144 lines (M).
**Evidence:** scanner `CTL-02` at 250 (306) and 54 (144). Over 150 lines is H; over 80 is M.
**Consequence:** the method mixes validation, cross-row dedup, default handling, picker sync, per-row reordering, counter recompute and audit. It cannot be reasoned about in one pass — which is exactly why PSC-03 hides here.

#### PSC-16 · M · CTL-03 — five methods use `$id` + `findOrFail` instead of route-model binding
**Where:** `show:202-206` · `edit:213-217` · `destroy:557-563` · `restore:608-614` · `forceDelete:657-663`
**Evidence:** scanner `CTL-03` at 202, 213, 557, 608, 657. The route parameter is `{period_set}`; only `update`/`ajaxSyncRange`/`toggleStatus` declare a typed `PeriodSet $periodSet`.
**Consequence:** binding is bypassed, so `withTrashed()` / `onlyTrashed()` scoping is re-decided by hand in each method — and `forceDelete` gets it wrong (PSC-30).

#### PSC-17 · M · CTL-05 — copy-paste blocks
**Where:** `store:119-135` vs `update:375-391` (identical 11-key payload) · `autoAddInRangeConfigs:964-972` vs `syncPickerMembership:1038-1046` vs `syncPeriodSetPeriods:1080-1088` (identical 7-key junction array, ×3) · the "Floor of 15" comment repeated at 58-60, 222-224, 254-256.
**Evidence:** scanner `CTL-05` at 119 and 964; manual read of all three sync methods.
**Consequence:** four copies of "build a period-set payload" and "create a junction row" that can drift apart. Extract one builder and one junction-create.

#### PSC-18 · M · CTL-09 — commented-out debug call
**Where:** `store:63` — `// dd($request->all());`
**Evidence:** scanner `CTL-09` at 63.
**Consequence:** a `dd()` left in the create path signals an untested branch (the rulebook treats even a commented-out `dd()` as a signal). No runtime effect today; lowered from H to M for that reason.

#### PSC-19 · M · CTL-10 — dead code and a message that lies
**Where/Evidence:**
- `edit:218` — `$classes = SchoolClass::all();` is passed to the view (`edit:244`) but `edit.blade.php` never uses `$classes` (`grep -n '\$classes' edit.blade.php` → none). The import at `PeriodSetController.php:15` exists only for this dead query.
- `update:489` — `elseif (str_contains($msg, 'uq_psp_set_period_ord'))` can never match: the real index is **`uq_psp_set_ord`** (`SHOW CREATE TABLE tt_period_set_periods_jnt`). The false name also appears in the comment at `update:308`. A duplicate `period_ord` therefore always falls to the generic "database constraint" message.
- `create.blade.php` / `_period-config-picker.blade.php` are unreachable (see PSC-28).
**Consequence:** wasted full-table query on every edit, an error path that never fires, and a user-visible message that misnames the problem.

#### PSC-20 · L · CTL-04 — no return types on 11 public methods
**Where:** `index, create, store, show, edit, update, destroy, restore, trashedPeriodSet, forceDelete, toggleStatus` (only `ajaxPeriodConfigs`/`ajaxSyncRange`/`toggleStatus`-adjacent carry `: JsonResponse`; `toggleStatus` has none).
**Evidence:** scanner `CTL-04` at 31, 41, 54, 202, 213, 250, 557, 608, 644, 657, 1093.

### F7 — Models

#### PSC-21 · L · MDL-04 — relation methods have no return types
**Where:** `PeriodSet.php:90` (`timetables()`), `:101` (`periods()`), `:109` (`classModeRules()`)
**Evidence:** scanner `MDL-04` at 90, 101; manual read of 109. (`shift`, `periodSetPeriods`, `periodConfigs` at 117/122/130 **do** carry return types.)

#### PSC-22 · M · MDL-07 — `classModeRules()` points at a table that does not exist (↗ linked)
**Where:** `PeriodSet.php:109-115` → `ClassModeRule` (`app/Models/ClassModeRule.php:18`, `$table = 'tt_class_mode_rules'`)
**Evidence:** tinker against the tenant: `$ps->classModeRules()->count()` → `SQLSTATE[42S02] … Table '…tt_class_mode_rules' doesn't exist`. No migration creates it. `grep -rn "classModeRules" Modules/` → only relation **definitions** (PeriodSet, TimetableType, AcademicSession, SchoolClass) and no callers.
**Consequence:** the relation 500s on first use and is currently dead. The model `ClassModeRule` is owned by [ClassSubjectSubgroupController](../../TimetableFoundation-done/ClassSubjectSubgroupController-done/01-report.md) (already `CLAIMED`; PRE-APPLIED lists `ClassModeRule` as still pending) — link, not fix here.

**Model otherwise clean:** `$fillable` declared with nothing sensitive ✅; `$casts` cover every int and boolean and all three datetimes ✅; `$table = 'tt_period_sets'` exists ✅; `SoftDeletes` present and the table has `deleted_at` ✅; no pivots; no `InteractsWithMedia`. Relations **proved in tinker**: `periods()`=7, `periodSetPeriods()`=7, `periodConfigs()`=7 (the `hasManyThrough` resolves correctly), `shift()`="Morning Shift", `timetables()`=0, `day_start_time`/`day_end_time` → `08:20`/`12:40`.

### F8 — Services and jobs

**clean — no service, no job, no event.** `grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b' $C` → none; the only cross-class calls are Eloquent models and the `activityLog()` helper.

### F9 — Queries and performance

#### PSC-23 · H · QRY-01 — a query runs inside a loop in `update()`
**Where:** `update:430-433` (inside `foreach ($validated['periods'] as $periodId => $periodData)`)
```php
$psp = PeriodSetPeriod::where('id', (int) $periodId)
    ->where('period_set_id', $periodSet->id)
    ->first();
```
**Evidence:** scanner `QRY-01` at 431.
**Consequence:** one SELECT per submitted period row. A set with 20 rows issues 20 queries plus the two-pass updates. Pre-fetch the set's rows keyed by id (`->keyBy('id')`) and index into it.

#### PSC-24 · M · QRY-07 — per-row `create()` / `update()` in loops
**Where:** `update:449,452,465` (`$psp->update(...)`, three calls per row) · `autoAddInRangeConfigs:964` · `syncPickerMembership:1038` · `syncPeriodSetPeriods:1080`
**Evidence:** scanner `QRY-07` at 449, 452, 465, 964, 1038, 1080.
**Consequence:** N statements where one `upsert()` / `whereIn(...)->update()` would do. Combined with PSC-23 this is the dominant cost of a large set edit.

#### PSC-25 · M · QRY-02 / QRY-15 — whole-table loads on the edit page
**Where:** `edit:218` (`SchoolClass::all()` — also unused, PSC-19) · `edit:220` (`PeriodType::orderBy('name')->get()`)
**Evidence:** scanner `QRY-02` at 218 (H) and `QRY-15` at 220 (M). `SchoolClass` is a SchoolSetup model (common). Live `sch_classes` is non-trivial.
**Consequence:** every edit page loads the entire classes table for nothing and the entire period-types table unfiltered. Drop the `$classes` query; keep the period-type list (it feeds a dropdown) but select only `id, name`.

### F10 — Views

#### PSC-26 · M · VIEW / deep read — the trash page fabricates the current clock as the schedule
**Where:** `trash.blade.php:49-51`
```php
{{ \Carbon\Carbon::parse($periodSet->start_time)->format('h:i A') }}
–
{{ \Carbon\Carbon::parse($periodSet->end_time)->format('h:i A') }}
```
**Evidence:** `PeriodSet` has **no** `start_time`/`end_time` column or accessor (`SHOW CREATE TABLE tt_period_sets` has neither; the only time accessors are `day_start_time`/`day_end_time`, `PeriodSet.php:143-154`). `$periodSet->start_time` is `null`; `Carbon::parse(null)` returns **now**. The identical bug was fixed in `show.blade.php:28-36` but not here.
**Consequence:** every trashed row displays today's current time as its schedule — fabricated data presented as fact.

#### PSC-27 · M · VIEW / deep read — the create dialog's period picker is dead; new sets are created with zero periods
**Where:** `_create-fields.blade.php:123,163` (`id="ps_psPreviewSummary"`, `id="ps_psPreviewTbody"`, `id="ps_psAutoFillCounts"`) · `_period-config-picker.blade.php:23,30,35` (the only JS, looking for `psAutoFillCounts`/`psPreviewTbody`/`psSelectAll`)
**Evidence:** `_create-modal.blade.php:13` includes only `_create-fields`; it does **not** include `_period-config-picker`. The picker is included only by the retired `create.blade.php:185`. `grep -rln "ps_psPreviewTbody" Modules/TimetableFoundation/resources public` → only the element itself, no script. The dialog form has no `period_config_ids[]` input.
**Consequence:** the "Periods in this range" panel and "Auto-fill counts" button in the Add dialog never populate, and `store()`'s `period_config_ids` branch (`store:160-162`) is unreachable from the dialog — every newly created set is empty (the counters are then forced to 0 at `store:172`). The user must save, then edit, to attach periods. Dead feature.

#### PSC-28 · L · VIEW — three orphan blades
**Evidence:**
- `index.blade.php` (48 lines) references `$schoolDays`, `timetable-foundation.period-type` routes and a "Day Management" breadcrumb; `index()` redirects to the masters tab, so it is never rendered.
- `create.blade.php` (190 lines) is unreachable: the `create` route is excluded (`routes/web.php:235`) and `create()` aborts. Its only companion, `_period-config-picker.blade.php`, is orphaned with it.
- `grep -rn "period-set.index" Modules/ resources/ app/` → only a registry entry and a test; no view link.
**Consequence:** three dead files that will drift (PSC-27 exists because the picker was left behind when the page was retired). Decide: delete or restore the wire-up.

### F11 — Security and Tenancy

**clean.**
- `env()` only inside `config` — `grep -n "env(" $C` → none.
- No personal data over-exposed: `ajaxPeriodConfigs` returns a mapped array (`ajaxPeriodConfigs:754-769`), never whole models.
- No hard-coded ids / `?? 1`; no secrets or request bodies logged (`store:183`, `update:496` log code + SQLSTATE + message only).
- No cache, so no un-keyed cache (TEN-02 n/a). No central models reached from tenant context (TEN-03 n/a). No file serving (TEN-04 n/a).

### F12 — Style

#### PSC-29 · L · STY-01/02/04/06 — style sweep (one item per file)
**Where:** `PeriodSetController.php` and `PeriodSet.php`
**Evidence:** scanner `STY-01` (missing `declare(strict_types=1)`, both files); `STY-06` at 183, 496 (the file mixes `Log::`, `\Log::` and `\Illuminate\Support\Facades\Log::`); `STY-04` at 170, 799 (emoji in comments — and `⚠`, `──` are used throughout); `PeriodSetController.php:6,8` leave blank lines between `use` statements (not Pint-clean). `update:308` carries the false index-name comment (PSC-19).
**Consequence:** inconsistent with the rest of the module; Pint will reformat imports. Grouped as two plan items (one per file).

### F13 — Deep read

#### PSC-30 · H — Delete Permanently accepts a live set and checks no children
**Where:** `forceDelete:663`
```php
$periodSet = PeriodSet::withTrashed()->findOrFail($id);   // a LIVE id is accepted
```
**Evidence:** `withTrashed()` matches live rows, so a `DELETE /period-set/{id}/force-delete` skips the trash. FK children of `tt_period_sets`, measured:
| Table | ON DELETE | Rows |
|---|---|---|
| tt_period_set_periods_jnt | CASCADE | 27 |
| tt_class_timetable_types_jnt | NO ACTION | 344 |
| tt_timetables | NO ACTION | 7 |

Per-set: `HALF_DAY` (id 4) has **0** NO-ACTION children — it would be purged outright; `STANDARD` (id 3) has 288 + 7 NO-ACTION children — the delete fails with error 1451. Only `is_default` is protected.
**Consequence:** a crafted request permanently deletes a **live** period set (cascading its junction rows) with no warning, or returns the generic "could not be completed." Fix: `onlyTrashed()->findOrFail()`, then count the NO-ACTION children and refuse naming them.

#### PSC-31 · M — trashing a set that is in use leaves dangling references
**Where:** `destroy:576-580`
**Evidence:** `destroy` soft-deletes and deactivates; `tt_class_timetable_types_jnt` holds 288 rows for set 3 and 40 for set 1, `tt_timetables` 7 for set 3. Live trashed count: 0 (latent).
**Consequence:** after a trash, `ClassTimetableType::with('periodSet')` resolves to `null` (SoftDeletes hides the row), so timetables built on that set lose their link. Reversible via restore, but silent meanwhile.

#### PSC-32 · M — unchecking "Set as Default" on the only default leaves the school with no default
**Where:** `update:389` (`'is_default' => (bool) ($validated['is_default'] ?? false)`) and `update:366-370` (clears only **other** rows when a default is being **set**)
**Evidence:** live: exactly 1 default (`STANDARD`). Nothing promotes another row when the current default is unchecked.
**Consequence:** the masters page and every consumer that resolves "the default period set" find none. Same class as ATC-08.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`_list.blade.php` N+1 (rendered by `TimetableFoundationController`, not by PeriodSetController):** the tab list calls `$ps->shift`, `$ps->periods->count()`, `$ps->day_start_time` and `$ps->day_end_time` per row (`_list.blade.php:102,122,132,134`). The two accessors each run a `min()`/`max()` query (`PeriodSet.php:145,152`), so 10 rows emit ~40 queries. Belongs to the TimetableFoundationController report; flagged here because the accessors live on the shared `PeriodSet` model.
- **`ClassModeRule` (TimetableFoundation):** table `tt_class_mode_rules` does not exist (tinker). There are two `ClassModeRule` classes — `Modules\TimetableFoundation\Models\ClassModeRule` (`tt_class_mode_rules`) and `Modules\SmartTimetable\Models\ClassModeRule` (referenced by `SchoolClass`/`AcademicSession`). Owned by ClassSubjectSubgroupController; PRE-APPLIED lists it as still pending.
- **`PeriodSetPeriod` model (owned by PeriodSetPeriodController):** the junction table has `deleted_at` and the migration calls `softDeletes()`, but the model does **not** use `SoftDeletes`. The controller's `->forceDelete()` calls therefore hard-delete. Not this report's to fix; noted because PeriodSetController relies on it.
- **Unreachable policies (module-wide):** every gate in this module passes a permission string, so `PeriodSetPolicy` (and its siblings) never run. Needs one module-level decision.
- **`RouteAuthenticationTest.php:88` lists `timetable-foundation.period-set.create`**, a route that no longer exists (excluded at `routes/web.php:235`). A test concern for the team (D4).
- **`ControllerAuthTest`** lists `PeriodSetController` as fully authorized; `create()` carries `abort(403)` but no `Gate::authorize`, so the source-scan test will flag it. Team/verification concern (D4).

## 8. Not covered, and why

- **Runtime behaviour:** no browser and no test run (D4). Every finding is a static read or a read-only SQL/tinker probe.
- **`TimetableFoundationController@timetableMasters`:** it serves the period-sets tab list, the create dialog's `$dlgShifts`/`$dlgMaxPeriodsPerDay`, and pagination via `ps_page`. That controller is out of scope; the list/accessor N+1 is recorded above.
- **Other writers of `tt_period_sets` / `tt_period_set_periods_jnt`:** `PeriodSetPeriodController`, the importers and `TtPeriodSetPeriodJntSeeder` were not audited. PSC-11's risk comes from them.
- **Data repair:** the 0 trashed sets and the current 4 live sets were read, not modified.
- **The sibling controllers converted on 2026-10-10** were assumed correct; this report only notes that PeriodSetController was left outside that pass.
