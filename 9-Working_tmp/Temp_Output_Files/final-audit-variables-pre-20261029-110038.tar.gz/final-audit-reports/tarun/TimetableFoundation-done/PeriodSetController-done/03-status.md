# Status — TimetableFoundation / PeriodSetController

**Fixed:** 2026-10-13 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — 32 items ticked, 11 decisions filled. PSC-22 is left unticked (recorded only, the model is owned elsewhere). PSC-09 and PSC-14 are deferred by decision.
**Fixed together with:** `PeriodConfigController-done` and `PeriodSetPeriodController-done`.

---

## 1. Pre-applied work

None. `PRE-APPLIED-2026-10-10.md` lists no file in this controller's scope.

---

## 2. Applied

The controller was rewritten: 1,153 → 770 lines, with `strict_types`, return types, and constants `TAB_ROUTE` / `TAB`.

| ID | Where | What changed | Verified by |
|---|---|---|---|
| PSC-30, PSC-16 | `forceDelete()` | Uses `onlyTrashed()->findOrFail()`, so the live default gets a 404. Refuses when `tt_class_timetable_types_jnt` or `tt_timetables` still reference the set, counting trashed rows too. Both FKs are NO ACTION, so this replaces a raw 1451. | replay: refused, "used by 40 class timetable type(s)…"; live default → 404 |
| PSC-01, PSC-02, PSC-06, PSC-08 | whole class | The only catches are `catch (DomainException)` (D2) in store, update, destroy and forceDelete. "Too many period_ord changes" is now a `DomainException`; it was a `RuntimeException`. Closures return data, and the redirect is built after. Gates sit above every load. | `grep 'catch ('` → 4 × DomainException + 1 × QueryException (rethrown unless 1062) |
| PSC-03, PSC-15, PSC-17 | `update()` | One transaction that locks the row, then runs `payload` → `syncPickerMembership` → `applyPeriodOverrides` → auto-add → `syncDerivedCounters` → log. The old ~306-line method is now named helpers, and none of them opens its own transaction. | replay: a swap update leaves total = rows = 7 |
| PSC-04, PSC-07 (a) | `store()` / `update()` | Clearing the other defaults happens inside the transaction, under `lockForUpdate()`. | read |
| PSC-05 | toggle / update | `activityLog` runs after the write, inside the transaction. | read |
| PSC-10 (a) | `applyPeriodOverrides()` | A blank short name keeps the row's current value, or falls back to the code. No more NOT NULL 1048. | replay: short names kept |
| PSC-11 (a) | `PeriodSetRequest` | A closure refuses a code a trashed set still owns: "A trashed period set already uses this code — restore it instead." | replay: message shown |
| PSC-12 (a) | `Http/Requests/PeriodSetRequest.php`, `PeriodSetSyncRangeRequest.php` (new) | Typed rules. The shift teaching-slot check and the per-row duplicate ord/code check are in `after()`. `selected_period_config_ids` is now validated; it was read raw. | replay: duplicate ord → field error |
| PSC-13 (a) | `routes/web.php` | Restore is `PATCH`. | `route:list` |
| PSC-19 | `duplicateRowException()` | The 1062 branch now matches the real index names (`uq_psp_set_code`, `uq_psp_set_ord`, `uq_psp_set_config`). Before, it never fired. | read |
| PSC-20, PSC-29a/b | controller + `Models/PeriodSet.php` | Return types, `strict_types`, emoji removed, Pint. | `php -l` |
| PSC-21 | `PeriodSet.php` | `timetables()` and `periods()` return `HasMany`. Added `classTimetableTypes(): HasMany` for the trash warning. `classModeRules()` is not in the model (PSC-22). | read |
| PSC-23 | `applyPeriodOverrides()` | The set's rows are read once with `->keyBy('id')`, instead of one query per row. | read |
| PSC-24 (partial) | `insertJunctionRows()` | New rows go in as one bulk `insert()`. Bulk inserts skip the model mutator, so the code is uppercased by hand and timestamps are set. Overrides stay per-row: the two-pass ord park needs each row's own value. | replay: store with picker → 4 rows |
| PSC-25 | `edit()` | Dropped the unused `SchoolClass::all()`. The period-type list selects only the columns it needs. | read |
| PSC-26 | `period-set/trash.blade.php` | Reads `day_start_time` / `day_end_time` with `?->format() ?? '—'`. Before, it read non-existent attributes and showed "now". | blade compile |
| PSC-27 (a) | `_create-modal.blade.php`, `_period-config-picker.blade.php` | The picker is included in the Add dialog with `idPrefix = 'ps_'`. All 7 `getElementById` calls are prefixed. The page-wide fallback runs only when the prefix is empty, and the error text is escaped. New sets now get their periods. | render: modal, prefixed button and picker script present |
| PSC-28 (a) | `period-set/{index,create}.blade.php` | Both deleted after re-proving that no `view()` references them. `create()` is `abort(403)` (D5). | `grep -rn` → 0 |
| PSC-31 (a) | `_list.blade.php`, `TimetableFoundationController` (`withCount`) | Trashing a set that is still in use shows the counts, and says it can be restored. Uses the new optional `trashWarning` prop on `x-backend.table.action`. | render: 3 warnings (16 / 40 / 288 class types, 5 timetables) |
| PSC-32 (a) | `update()` / `toggleStatus()` / `destroy()` | Unsetting, disabling or trashing the only default is refused: "This is the default period set. Make another set the default first." Toggle answers 403 with `success:false`. | replay: all three guards hold |
| PSC-18 | controller | Removed `// dd(...)`. | `grep -c 'dd('` → 0 |

Event literals kept: `Stored` · `Updated` · `Trashed` · `Restored` · `Deleted` · `Toggled`.

### 2.1 Applied beyond the plan — read this

1. **New guard: "The default period set must be active."** You cannot save a default set as inactive. Without it, PSC-32 could be bypassed by deactivating the default.
2. **`exam_periods` input `min="1"` → `min="0"`.** The server rule is `min:0` and the default value is 0, so the browser blocked every Add submit.
3. **Dead route removed:** `period-set-period.addPeriodToOrganization`. Its method never existed, so the GET gave a 500. The report says this was removed on 2026-10-10, but that removal never reached this branch. `tests/Unit/Architecture/missing-controller-methods.txt:103` still lists it; that file is only an inventory.
4. **`ajaxSyncRange` does not re-sync the counters.** It updates from/to and auto-adds periods only. This is deliberate: `TtPeriodSetBasicTest::test_20` asserts that behaviour.
5. **Shared component:** `x-backend.table.action` got an optional `trashWarning` prop. With the prop absent, the output is byte-identical. Proof: 389 blades compiled clean.

---

## 3. Not applied

| ID | Why |
|---|---|
| PSC-09 (a) | Policy unreachable. Deferred to the module-wide decision. |
| PSC-14 (a) | Controller split. Deferred to the split pass (D3). Now 770 lines. |
| PSC-22 | `classModeRules()` / `tt_class_mode_rules` belongs to the ClassSubjectSubgroup report. Not touched. |

---

## 4. Needs Tarun's hand

1. **Data fix, your go needed.** STANDARD's stored `to_period_ord` is **9**, but its shift has only **8** active teaching slots (the highest `slot_ord` in its junction rows is 8). Because of that, the STANDARD edit page cannot be saved until To Period Ord is changed to 8. The fix is a one-off `syncDerivedCounters`, or setting `to_period_ord = 8`. I did not change any data.
2. **Run the Dusk suite** `tests/Browser/Modules/V2/TimetableFoundation/TimetableMasters/TtPeriodSetBasicTest.php`; I ran none (D4). The contracts it asserts were preserved:
   - test_17: 403 + `success:false`;
   - test_20: sync-range answers `status`;
   - test_16 and test_18: the default set survives.

   Expect test_06 and test_07 to fail, because they target the create page, which was already retired before this pass. The restore test should still match the action URL.
3. **Browser check** of the Add dialog: pick a shift and a range, and check the preview and Auto-fill now work.

---

## 5. Unverifiable by this workflow (D4), and cross-module notes

- SmartTimetable `partials/period-set/_list.blade.php:42` links `period-set.create`, which is not routed. It is cross-module, so I did not change it.
- SmartTimetable's period-set-period `_list` links `period-set-period.trashed`, which now answers 403 (see the PSP status).
- `RouteAuthenticationTest` lists `period-set.create` and `period-set.index`. Those are test files; I did not touch them.

---

## 6. Verification log

```
php -l (controller, 2 requests, model, 18 blades compiled) → OK, comment delimiters balanced
class_exists: 8 classes                                    → OK
route:list (uncached)                                      → 36 actions, 0 missing
kernel replay (rolled back, tenant test.localhost):
  masters ?tab=period-sets   → 200; modal + ps_ button + picker script; 3 trash warnings; no leaks
  edit / show / trash pages  → 200 / 200 / 200
  unset default (to=8)       → refused, still default
  toggle default off         → 403 {"success":false,…}
  trash default              → refused
  update with ord swap       → total = rows = 7, swap OK, codes upper, short names kept
  duplicate ord              → field error, nothing written
  store with picker          → created, 4 rows
  sync-range                 → status true
  trash set 1 / force set 1  → trashed / refused (40 class timetable types)
  force live default         → 404
  restore set 1              → active again
  trashed code reused        → "A trashed period set already uses this code — restore it instead."
  after rollback             → counts unchanged, PROBE_SET = 0
all flash keys               → non-empty text
Pint on touched files        → passed; php -l re-run → OK
```

---

## 7. Final state

**Status: FIXED** (2026-10-13). Open items:

- 2 deferred (PSC-09, PSC-14) and 1 recorded (PSC-22).
- The STANDARD `to_period_ord` data fix, which waits for your go.

Every H item is closed.
