# Fix Plan — TimetableFoundation / PeriodSetController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/PeriodSetController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
_None (0 B)._

## 2. Fixes that arm a latent defect (sequenced)
- [x] **PSC-30** · H · deep read · `PeriodSetController.php:663` — `forceDelete()`:
  - Use `onlyTrashed()->findOrFail($id)` so a live set can no longer be purged.
  - Before deleting, count the NO-ACTION children (`tt_class_timetable_types_jnt`, `tt_timetables`) for this set. If any exist, refuse with a `\DomainException` naming each table and its count. The CASCADE child (`tt_period_set_periods_jnt`) needs no guard.
  - `catch (\DomainException)` only, mapped to a flash — no generic `\Throwable` catch (PSC-01). Effort: S.

- [x] **PSC-10** · H · DECISION · VAL / DDL · `PeriodSetController.php:454` — clearing a period's Short Name writes `null` into a `NOT NULL` column and aborts the save.
      (a) ⭐ App only: coalesce an empty `short_name` to the existing row value (or `code` when there is none) before the update; no schema change. The DDL and migration both define `NOT NULL`, so this keeps them authoritative.
      (b) New additive migration making `tt_period_set_periods_jnt.short_name` nullable — **departs from the DDL** (`Timetable_DDL_v8.1.sql:488`), so the DDL must be changed by you first.
      (c) Leave it; document that Short Name cannot be cleared.
      ➜ Choice: (a) — blank keeps the row's current short name, else the code; no schema change (Tarun, 2026-10-13)

## 3. Errors & transactions (F1/F2)
- [x] **PSC-01** · M · ERR-00 (D1) / ERR-05 · `PeriodSetController.php` — remove the controller `try/catch` from `store (152-192)`, `update (420-503)`, `destroy (561-606)`, `restore (612-642)`, `forceDelete (661-698)`, `ajaxSyncRange (781-850)`, `toggleStatus (1095-1151)`.
  - Let `bootstrap/app.php` render failures. Where a friendly page-specific message is needed, follow the pattern already used by the three sibling controllers converted on 2026-10-10.
  - Drop the `getMessage()`-only logging (`report($e)` instead). The `update()` catch maps `QueryException` to per-row field errors — keep that behaviour but move the mapping out of a bare catch (wrap it in a small private method that rethrows `\DomainException`, PSC-02 + PSC-19).
  - The `ModelNotFoundException → throw` guards in destroy/restore/forceDelete become unnecessary once the catches are gone. Effort: M.

- [x] **PSC-02** · M · ERR-01 (D2) · `PeriodSetController.php:445` — change `throw new \RuntimeException('Too many period_ord changes…')` to `\DomainException`, and catch **only** `\DomainException` for the flash. Add the `// ERR-01, 2026-10-10` comment. Never catch `RuntimeException`. Effort: S.

- [x] **PSC-03** · H · TXN-01 · `PeriodSetController.php:250-555` — wrap the whole `update()` write sequence in ONE `DB::transaction`:
  - clear the prior default (366-370), `$periodSet->update($payload)` (393), `syncPickerMembership` (400), the periods park/rewrite loop (419-504), `autoAddInRangeConfigs` (511), `syncDerivedCountersFromJunction` (521) and `activityLog` (531) all commit together.
  - The inner closures in the private helpers already exist; call them inside the outer transaction (nested transactions are savepoints — or pass the outer `DB::transaction` level through).
  - Build the redirect/flash **after** the closure. Effort: M.

- [x] **PSC-04** · H · TXN-01 · `PeriodSetController.php:111-114` — move the prior-default clear **inside** the `store()` transaction, before `PeriodSet::create()`, so a failed create leaves the old default intact. Effort: S.

- [x] **PSC-05** · M · TXN-04 · `PeriodSetController.php:531` and `:1122-1128` — move `activityLog()` inside the write's transaction, after the write:
  - `update()`: covered by PSC-03.
  - `toggleStatus()`: move `$periodSet->save()` inside the `DB::transaction` that holds the log, so the row and its audit row commit together. Effort: S.

- [x] **PSC-06** · M · TXN-05 · `PeriodSetController.php:567/593`, `:629`, `:667/685` — have each closure return the model (or a result), and build the `redirect()`/flash **after** `DB::transaction` returns. Effort: S.

- [x] **PSC-07** · M · DECISION · TXN-06 · `PeriodSetController.php:111` / `:366` — "one default set" is check-then-act with no unique index.
      (a) ⭐ App lock: inside the PSC-03/PSC-04 transaction, `PeriodSet::lockForUpdate()` the current default row(s) before clearing, so two concurrent saves cannot both win. No schema change.
      (b) Migration adds a partial/functional unique index enforcing a single `is_default = 1` (MySQL has no partial index — needs a generated column). Departs from the DDL, so the DDL changes first.
      (c) Leave it; accept that a race can create two defaults.
      ➜ Choice: (a) — `lockForUpdate()` on the current default inside the write transaction (Tarun, 2026-10-13)

## 4. Authorization (F3)
- [x] **PSC-08** · M · AUTH-02 · `PeriodSetController.php:781-782`, `:1095-1096` — move `Gate::authorize(...)` above the `try` (it runs before validation and before any record load). Resolved automatically if PSC-01 is applied. Effort: S.

- [x] **PSC-09** · L · DECISION · AUTH-04 · `PeriodSetPolicy.php` + `TimetableFoundationServiceProvider.php:130` — every gate passes a permission string, so the policy is never consulted.
      (a) ⭐ Leave as is and raise it as a **module-wide** decision (all TimetableFoundation policies behave the same way); do not fix it controller-by-controller.
      (b) Stop registering `PeriodSetPolicy` (remove the `Gate::policy` line) so it stops looking active.
      (c) Convert this controller's gates to `$this->authorize('update', $periodSet)` policy calls — a larger change with the same permission names underneath.
      ➜ Choice: (a) — deferred to the module-wide policy decision (Tarun, 2026-10-13)

## 5. Validation, routes, models (F4/F5/F7)
- [x] **PSC-11** · M · DECISION · VAL-04 · `PeriodSetController.php:70` / `:265` — `Rule::unique('tt_period_sets','code')` ignores trashed rows while `UNIQUE uq_periodset_code` does not; re-creating a trashed code is a latent 500.
      (a) ⭐ The rule also checks trashed rows, with the message "A trashed period set already uses this code — restore it instead." No migration.
      (b) A migration adds a generated live-code column with a soft-delete-aware unique index.
      (c) Leave it (0 trashed sets today).
      ➜ Choice: (a) — closure rule refuses a trashed set's code with the restore message (Tarun, 2026-10-13)

- [x] **PSC-12** · M · DECISION · VAL-02 / VAL-05 / VAL-07 · `PeriodSetController.php:64-106, 259-301, 711-715, 806-809` — validation is inline in five methods; `'nullable'`-only rules; the teaching-slot closure is duplicated.
      (a) ⭐ Extract one `PeriodSetRequest` (store/update) plus a small AJAX request, type every field, and move the cross-field rule into the request's `after()` hook. The existing FormRequests in the module are the pattern (`AcademicTermRequest`, `PeriodTypeRequest`).
      (b) Defer extraction; fix only PSC-10/PSC-11 now and record the rest.
      (c) Leave inline.
      ➜ Choice: (a) — `PeriodSetRequest` + `PeriodSetSyncRangeRequest` (Tarun, 2026-10-13)

- [x] **PSC-13** · H · DECISION · RTE-01 · `routes/web.php:237` — Restore runs over GET.
      (a) ⭐ Change `Route::get('/period-set/{id}/restore', …)` to `Route::patch(...)`. `x-backend.table.action-trashed` derives the verb from the route (no blade edit); the only caller is `trash.blade.php:62`. ⚠ SHARED — this edits a route file, so it needs its own explicit tick.
      (b) Leave it as GET and accept the CSRF/prefetch risk.
      ➜ Choice: (a) — `Route::patch` (Tarun, 2026-10-13)

- [x] **PSC-16** · M · CTL-03 · `PeriodSetController.php:202, 213, 557, 608, 657` — bind the model in the signature: `show(PeriodSet $periodSet)`, `edit(PeriodSet $periodSet)`, `destroy(PeriodSet $periodSet)`, `restore(PeriodSet $periodSet)`, `forceDelete(PeriodSet $periodSet)`, with `->withTrashed()` / `->onlyTrashed()` scoping where required (aligns with PSC-30). Confirm the route parameter `{period_set}` resolves (it does — Laravel snake-cases the parameter). Effort: S.

- [x] **PSC-21** · L · MDL-04 · `PeriodSet.php:90, 101, 109` — add `: HasMany` return types to `timetables()`, `periods()`, `classModeRules()`. ⚠ SHARED — 8+ files reference `PeriodSet`; type-hint only. Effort: S.

- [ ] **PSC-22** · M · MDL-07 · `PeriodSet.php:109` — `classModeRules()` targets the missing table `tt_class_mode_rules`. **No fix here** — `ClassModeRule` is owned by the ClassSubjectSubgroupController report (still `CLAIMED`; PRE-APPLIED lists it pending). Recorded; verify there before touching the relation.

## 6. Queries & performance (F9)
- [x] **PSC-23** · H · QRY-01 · `PeriodSetController.php:431` — remove the per-row `PeriodSetPeriod::where('id',…)->first()`; pre-fetch the set's rows once (`->get()->keyBy('id')`) before the `foreach` and index into the collection. Effort: S.

- [x] **PSC-24** · M · QRY-07 · `PeriodSetController.php:449, 452, 465, 964, 1038, 1080` — replace per-row `create()`/`update()` with `upsert()` / `whereIn(...)->update()` batches. Keep behaviour identical. Effort: M.

- [x] **PSC-25** · M · QRY-02 / QRY-15 · `PeriodSetController.php:218, 220` — delete the unused `SchoolClass::all()` (and the now-unused `SchoolClass` import at :15); keep the period-type list but select `id, name` only. Effort: S.

## 7. Views (F10)
- [x] **PSC-26** · M · VIEW / deep read · `trash.blade.php:49-51` — replace `\Carbon\Carbon::parse($periodSet->start_time)` / `end_time` (non-existent attributes → "now") with the model's real accessors `day_start_time` / `day_end_time`, guarded with `?->format(...) ?? '—'`, exactly as `show.blade.php:35-36, 80-84` now does. Effort: S.

- [x] **PSC-27** · M · DECISION · VIEW / deep read · `_create-modal.blade.php` / `_create-fields.blade.php` / `_period-config-picker.blade.php` — the Add dialog's "Periods in this range" preview and "Auto-fill counts" button are dead (the picker JS is not included by the modal and targets IDs without the `ps_` prefix), so new sets are created with zero periods.
      (a) ⭐ Re-wire the picker into the create modal: include `_period-config-picker` in `_create-modal.blade.php`, fix its hard-coded DOM ids to the `ps_`-prefixed ones, and render hidden `period_config_ids[]` inputs so `store()`'s branch works.
      (b) Remove the preview panel and Auto-fill button from `_create-fields.blade.php` and accept that a new set starts empty (edit to add periods).
      (c) Leave the dead panel in place.
      ➜ Choice: (a) — picker included in the Add dialog with the `ps_` id prefix (Tarun, 2026-10-13)

- [x] **PSC-28** · L · DECISION · VIEW / CTL-10 · `index.blade.php`, `create.blade.php`, `_period-config-picker.blade.php` — three orphan blades.
      (a) ⭐ Delete `index.blade.php` and `create.blade.php` after re-proving `routed=0 refs=0` at fix time; keep `_period-config-picker.blade.php` only if PSC-27(a) is chosen.
      (b) Keep all three.
      ➜ Choice: (a) — `index.blade.php` and `create.blade.php` deleted; the picker is kept (PSC-27 = a) (Tarun, 2026-10-13)

## 8. Controller shape & style (F6/F12) — one item per file
- [x] **PSC-15** · H · CTL-02 · `PeriodSetController.php:250-556` — break `update()` (~306 lines) into named steps (validate, sync membership, rewrite rows, recompute counters) as part of PSC-03; the transaction stays in the controller. Effort: M.
- [x] **PSC-17** · M · CTL-05 · `PeriodSetController.php:119/375, 964/1038/1080` — extract one payload builder and one junction-row creator; drop the thrice-repeated "Floor of 15" comment to one helper. Effort: M.
- [x] **PSC-18** · M · CTL-09 · `PeriodSetController.php:63` — delete `// dd($request->all());`. Effort: S.
- [x] **PSC-19** · M · CTL-10 · `PeriodSetController.php:308` and `:489` — fix the wrong index name: the real key is `uq_psp_set_ord`, so the `period_ord`-duplicate branch must match that string, or it never fires; update the false comment at :308. (The unused `$classes` query is handled by PSC-25.) Effort: S.
- [x] **PSC-20** · L · CTL-04 · `PeriodSetController.php` — add return types to the 11 public methods (`: View`, `: RedirectResponse`, `: JsonResponse`). Effort: S.
- [x] **PSC-29a** · L · STY-01/02/04/06 · `PeriodSetController.php` — `declare(strict_types=1)`; one `Log::` style; remove emoji from comments; run `vendor/bin/pint` on this file only. Effort: S.
- [x] **PSC-29b** · L · STY · `PeriodSet.php` — `declare(strict_types=1)`; run `vendor/bin/pint` on this file only. ⚠ SHARED — 8+ files reference this model; comment/type-only. Effort: S.

## 9. Deferred / decisions
- [x] **PSC-14** · M · DECISION · CTL-01 — the controller is 1,153 lines / 13 public methods. Split it?
      (a) ⭐ Defer to the split pass (D3). The four private `sync*` helpers and the AJAX endpoints are the natural seams.
      (b) Extract the four `sync*` methods into a `PeriodSetSyncService` now.
      (c) Leave as is; record as accepted.
      ➜ Choice: (a) — deferred to the split pass, D3 (Tarun, 2026-10-13)
- [x] **PSC-31** · M · DECISION · deep read · `PeriodSetController.php:576-580` — trashing a set that is in use (288 + 7 NO-ACTION child rows for `STANDARD`) leaves those rows pointing at a soft-deleted set.
      (a) ⭐ Keep it allowed (it is reversible) but add a confirmation/warning with the child counts; restore already reactivates.
      (b) Refuse to trash a set with any NO-ACTION children, naming the counts.
      (c) Leave as is.
      ➜ Choice: (a) — allowed, with a trash warning naming the child counts (Tarun, 2026-10-13)
- [x] **PSC-32** · M · DECISION · deep read · `PeriodSetController.php:366-370, 389` — unchecking "Set as Default" on the only default leaves the school with none.
      (a) ⭐ Refuse to unset the only default with a `\DomainException` ("Make another set the default first.").
      (b) Allow it; nothing promotes a replacement.
      (c) Leave as is.
      ➜ Choice: (a) — refuse with a `DomainException` (Tarun, 2026-10-13)
