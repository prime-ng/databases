# Fix Plan — TimetableFoundation / ActivityController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/ActivityController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ No migration is needed for any item here.

## 1. Blockers reachable today
_None._

## 2. Fixes that arm a latent defect (sequenced)
- [x] **ACT-02** · M · ERR-02 · `ActivityController.php:164-175, 1108-1142` — make the D2 fixed message truthful and narrow the catch's reach:
  - Move the `OrganizationAcademicSession::firstOrFail()` and the timetable-type default out of the `try` (before the truncate), so a missing session/type returns normally instead of being swallowed.
  - The remaining single catch then only covers post-truncate work, which is exactly what the fixed "tabs are now empty. The error has been logged." message describes.
  - Effort: S.
- [x] **ACT-15** · M · DECISION · TEN-02 · `ActivityController.php:1422-1434` — the static `TeacherAssignmentRole` cache can cross tenants on a long-running process.
      (a) ⭐ Remove the four `static`s; memoise the roles locally inside `generateActivities()` (one query, passed in or resolved once per request).
      (b) Keep the statics and add an explicit comment scoping them to FPM web requests (mirrors `SubActivityGrouper`).
      (c) Leave as is, accepted.
      ➜ Choice: (a) — Tarun 2026-10-13 ("fix the issues as per the recommendation")

## 3. Errors & transactions (F1/F2)
- [x] **ACT-01** · M · ERR-00 / ERR-05 · `ActivityController.php:63-155` — remove the try/catch from `updateLocks`:
  - **Shape:** `return DB::transaction(fn () => …)` without the surrounding `try`.
  - **Errors:** let the central handler render them (JSON callers already get `success:false` there); a `\DomainException` from the request is already refused before this method runs.
  - Effort: S.
- [x] **ACT-04** · L · TXN-05 · `ActivityController.php:127-139` — the closure stores the lock change (and logs it) and **returns** the activity; build the JSON/redirect response after the `DB::transaction` call, outside the closure. Effort: S.
- [x] **ACT-03** · L · D2 · `ActivityController.php:1109-1116` — add `(ERR-01, 2026-10-10)` to the SnapshotProtectionException branch comment so the allowed verbatim message is traceable. Effort: S.

## 4. Authorization (F3)
- [x] **ACT-06** · L · AUTH-04 · `ActivityController.php:59` — drop the duplicate `Gate::authorize` in `updateLocks`; keep the FormRequest `authorize()` (it runs first and checks the same permission). The unreachable-policy question is module-wide (§7) and is **not** fixed here. Effort: S.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **ACT-11** · L · MDL-02 · `ActivityTeacher.php:43` — remove the `'preference_score' => 'integer'` cast; the column no longer exists on `tt_activity_teachers` (proved by `SHOW COLUMNS`). ⚠ SHARED. Effort: S.

## 6. Queries & performance (F9) — mechanical
- [x] **ACT-14** · M · QRY-01 · `ActivityController.php:277-283, 289, 1509-1514` — cut the per-requirement / per-teacher fan-out in generation:
  - Eager-load `classRequirementGroup.roomType.rooms` on the requirements query (`:212-219`) so `$group->roomType?->rooms?->count()` stops querying per requirement.
  - Pre-fetch `TeacherAvailability` eligible-teacher counts once for the term, keyed by `(class_id, subject_study_format_id)`, and read them in the loop instead of the per-requirement aggregate.
  - In `assignTeacherToActivity`, resolve `sch_teacher_profile`→`sch_teachers` in one `whereIn` mapping for the request instead of one `DB::table` lookup per teacher.
  - Effort: M.
- [x] **ACT-10** · L · dead code · `ActivityController.php:321-323, 1012-1014, 1090-1095` — remove the duplicated `class_group_id` keys (keep the one that wins), and delete the three after-generation count queries plus the unused `$consolidatedActivitiesInDb`/`$classGroupActivities` variables (the flash uses `$consolidatedActivities->count()`). Effort: S.

## 7. Views (F10)
_None — the controller renders no view._

## 8. Style (F12) — one item per file
- [x] **ACT-16a** · L · STY · `ActivityController.php` — add `declare(strict_types=1)`, return types on `updateLocks`/`generateActivities` (`RedirectResponse|JsonResponse` / `RedirectResponse`), and switch `\Log::error` (:1128) to the imported `Log`. Do **not** strip the module's `⛔`/`⚠` comment convention (team-wide choice). Effort: S.
- [x] **ACT-16b** · L · STY · `UpdateActivityLocksRequest.php` — add `declare(strict_types=1)`. Effort: S.
- [x] **ACT-16c** · L · STY · `Activity.php` — add `declare(strict_types=1)`. ⚠ SHARED. Effort: S.
- [x] **ACT-16d** · L · STY · `ActivityTeacher.php` — add `declare(strict_types=1)` (with ACT-11). ⚠ SHARED. Effort: S.
- [x] **ACT-16e** · L · STY · `SubActivity.php` — add `declare(strict_types=1)`. ⚠ SHARED. Effort: S.
- [x] **ACT-16f** · L · STY · `SubActivityMember.php` — add `declare(strict_types=1)`. ⚠ SHARED. Effort: S.
- [x] **ACT-16g** · L · STY · `ActivityPriority.php` — add `declare(strict_types=1)`. ⚠ SHARED. Effort: S.
- [x] **ACT-16h** · L · STY · `SubActivityGrouper.php` — add `declare(strict_types=1)`. ⚠ SHARED. Effort: S.
- [ ] **ACT-16i** · L · STY · `SubActivityService.php` — add `declare(strict_types=1)` and switch `\Log::info` (:77) to the imported `Log` (applied only if ACT-13 keeps the file). ⚠ SHARED. Effort: S.
- [x] **ACT-16j** · L · STY · `ActivityLockService.php` — add `declare(strict_types=1)`. ⚠ SHARED. Effort: S.

## 9. Deferred / decisions
- [x] **ACT-07 / ACT-08** · M/H · DECISION · CTL-01/CTL-02 — the 1,624-line controller with a 987-line `generateActivities()`.
      (a) ⭐ Defer to the god-controller split pass (D3) — record the split proposal here: generation orchestration (truncate + session + counts + flash) vs pooling/grouping (STEP 1.5/2/3) vs teacher assignment vs room resolution.
      (b) Extract the generation steps into the five pre-assigned services now.
      (c) Leave as is, accepted.
      ➜ Choice: (a) — Tarun 2026-10-13. Deferred to the split pass (D3); nothing applied
- [ ] **ACT-13** · M · DECISION · SVC-04 — `SubActivityService` is dead (no production caller) and its `SubActivity::create` would crash on this schema (wrong `class_requirement_subgroups` key, missing `section_id` on shared parents; SQL 1048). `tests/Unit/ServiceTest.php` asserts the class exists (D4 — not edited here).
      (a) ⭐ Delete `SubActivityService.php`; the team updates `ServiceTest.php` (a test change, D4, done outside this pass) — grep for callers first at fix time.
      (b) Keep the service and repair it: real `code`… (no `code` column exists — the whole design premise is gone), correct `class_requirement_subgroup_id`, wrap in `DB::transaction`, add `activityLog`.
      (c) Leave as is, accepted as dead code.
      ➜ Choice: (a) is the recommendation — ⚠ NOT TICKED 2026-10-13: deleting the service breaks the green `tests/Unit/ServiceTest.php` (asserts the class exists). Needs Tarun's explicit go, and a decision on who updates that test. ACT-16i stays unticked with it

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use (the pre-assigned models/services). It needs its own explicit tick — "tick all" does not cover them.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/ActivityController.php`. It applies **only** ticked items, in this order, and touches **only** the files each item names.