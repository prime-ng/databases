# Status — TimetableFoundation / ActivityController

**Fixed:** 2026-10-13 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`
**Instruction:** Tarun, 2026-10-13 — "fix the issues as per the recommendation" (the ⭐ option on every DECISION item).

## 1. Pre-applied work

From `../PRE-APPLIED-2026-10-10.md:30`:

| Controller | Pre-applied 2026-10-10 |
|---|---|
| `ActivityController` | user message "…now empty: '.$e->getMessage()" → "…now empty. The error has been logged." (truncate-rebuild D2). SnapshotProtectionException branch commented |

⚠ **The code found on 2026-10-13 did NOT match this row.** The `\Throwable` catch in
`generateActivities()` still appended `$e->getMessage()` to the user's flash, so the 2026-10-10 change had
been reverted (or overwritten) before this fix pass. It is re-applied here as part of ACT-02, in the shape
the plan asks for: a fixed message plus `report($e)`, with a separate `\DomainException` branch so the
room-type messages that were written for the user still reach them.

## 2. Applied

19 plan items ticked: 18 applied, and ACT-07/08 recorded as a deferral. Choices are on each `➜ Choice:` line in `02-fix-plan.md`.
All line numbers below are in `ActivityController.php` (1,568 lines after the pass; 1,621 before) unless another file is named.

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| ACT-02 | `:174-232`, `:1135-1168`, `:1281/1300/1312` | The current-session and timetable-type checks now run BEFORE `try` and the truncate, and return a normal error flash (`firstOrFail()` → `exists()` with "No current academic session is set…"). The catch is split: `SnapshotProtectionException` → its own message; `\DomainException` → roll back + "…cleared, so they are now empty: {message}"; `\Throwable` → roll back + `report($e)` + the fixed "…now empty. The error has been logged.". The three user-facing `\RuntimeException`s in `resolveSharedRoomRequirement()` are now `\DomainException`, so their messages still reach the user | `grep -c 'RuntimeException'` · `grep -nF 'throw new \DomainException('` · `grep -c 'firstOrFail'` | 0 · lines 1281, 1300, 1312 · 0 | 2026-10-13 |
| ACT-15 | `:43`, `:200-205`, `:1366-1369` | The four function-level `static`s in `assignTeacherToActivity()` are gone. The roles are resolved once at the start of `generateActivities()` into the private property `$assignmentRoles`, which is reset on every run, so it cannot carry one tenant's roles into the next on a long-running worker | `grep -c 'static \$'` | 0 | 2026-10-13 |
| ACT-01 | `:76-160` | `try/catch` removed from `updateLocks()`; errors go to the central handler, and the `DB::transaction` closure rolls back on its own | `grep -c 'try {'` (whole file) | 1 — the generate truncate-rebuild catch only | 2026-10-13 |
| ACT-04 | `:80-159` | The closure writes and logs, then `return $activity;` (`:143`). The JSON / redirect is built after the transaction commits | read | — | 2026-10-13 |
| ACT-03 | `:1135-1140` | The SnapshotProtectionException branch is its own `catch` with an `ERR-01 (2026-10-10)` comment | read | — | 2026-10-13 |
| ACT-06 | `:76-78` | Duplicate `Gate::authorize('…activity.update')` removed; `UpdateActivityLocksRequest::authorize()` still checks the same permission first | `grep -c 'Gate::authorize'` | 1 — `generateActivities()` only | 2026-10-13 |
| ACT-11 ⚠ SHARED | `Models/ActivityTeacher.php:42-45` | `'preference_score' => 'integer'` cast removed (the column does not exist on `tt_activity_teachers`; only `TeacherAvailability` uses that name) | `grep -c preference_score Models/ActivityTeacher.php` | 0 | 2026-10-13 |
| ACT-14 | `:244`, `:282-292`, `:317`, `:1437-1458` | (1) `classRequirementGroup.roomType.rooms` is eager-loaded, so the room score no longer queries per requirement. (2) Eligible-teacher counts are read ONCE into a map keyed `class_id|subject_study_format_id` (same filters: active rows, non-null profile, `COUNT(DISTINCT teacher_profile_id)`), replacing the per-requirement count. (3) `assignTeacherToActivity()` maps every `teacher_profile_id` to `sch_teachers` in ONE `whereIn` query, keeping the first row per profile as the old `->first()` did | `grep -c "distinct('teacher_profile_id')"` · `grep -c "where('tp.id', \$teacher"` · `grep -c "whereIn('tp.id'"` | 0 · 0 · 1 | 2026-10-13 |
| ACT-10 | `:353-356`, `:1043-1046`, `:1120-1121` | Duplicate `'class_group_id' => null` removed from both `updateOrCreate` arrays (the value that won is kept). `$classGroupActivities` and `$consolidatedActivitiesInDb` queries deleted. `$totalActivitiesInDb` is KEPT — the success flash prints it (the report's "delete all three" was stale on that point). The duplicate `$created`/`$skipped` initialisation before the requirements query is also removed | `grep -cE 'classGroupActivities\|consolidatedActivitiesInDb'` | 0 | 2026-10-13 |
| ACT-16a | whole class | `declare(strict_types=1)`; return types `RedirectResponse\|JsonResponse` / `RedirectResponse`; `\Log::error` is gone (replaced by `report($e)` under ACT-02), so the now-unused `Log` import was removed | `php -l`, `class_exists` | ok · ok | 2026-10-13 |
| ACT-16b | `UpdateActivityLocksRequest.php:3` | `strict_types`. Every value it passes to `ActivityLockService` is already cast with `(int)` | `php -l`, `class_exists` | ok · ok | 2026-10-13 |
| ACT-16c ⚠ SHARED | `Models/Activity.php:3`, `:325-330` | `strict_types`, plus an `(int)` cast in `schedulingScore()`: `min_teacher_availability_score` is `decimal:2` (a string), so the sum is a float, and strict mode would throw on the `: int` return. No caller of `schedulingScore()` exists today; the cast keeps the old non-strict result | `php -l`, `class_exists` | ok · ok | 2026-10-13 |
| ACT-16d ⚠ SHARED | `Models/ActivityTeacher.php:3` | `strict_types` (with ACT-11). Pint also removed a same-namespace `use …\TeacherAssignmentRole;` that did nothing | `php -l`, `class_exists` | ok · ok | 2026-10-13 |
| ACT-16e ⚠ SHARED | `Models/SubActivity.php:3` | `strict_types` | `php -l`, `class_exists` | ok · ok | 2026-10-13 |
| ACT-16f ⚠ SHARED | `Models/SubActivityMember.php:3` | `strict_types` | `php -l`, `class_exists` | ok · ok | 2026-10-13 |
| ACT-16g ⚠ SHARED | `Models/ActivityPriority.php:3`, `:100-104` | `strict_types`, plus `number_format((float) $this->priority_score, 2)`: `priority_score` is `decimal:2` (a string) and `number_format()` refuses a string under strict mode. Pint braced two single-line `if`s in `priorityLevel()` | `php -l`, `class_exists` | ok · ok | 2026-10-13 |
| ACT-16h ⚠ SHARED | `Services/SubActivityGrouper.php:3` | `strict_types`. Every internal call already passes ints (`(int)` casts on `students`, `class_id`, the config value) | `php -l`, `class_exists` | ok · ok | 2026-10-13 |
| ACT-16j ⚠ SHARED | `Services/ActivityLockService.php:3` | `strict_types`. Every input is cast to `int` before use; map keys are `"classId-sectionId"` strings | `php -l`, `class_exists` | ok · ok | 2026-10-13 |
| ACT-07 / 08 | — | DECISION (a): deferred to the god-controller split pass (D3). Nothing applied | — | — | 2026-10-13 |

### 2.1 Applied beyond the ticked plan — read this

`02-fix-plan.md` has **no item** for three findings the report raises (ACT-09, ACT-12, ACT-17). I applied
them under the same instruction. Each touches only `ActivityController.php`, and none changes behaviour.
They are listed here so they are not silent:

| ID | File:line | What changed | Verify | Output |
|---|---|---|---|---|
| ACT-09 | (removed) | Dead private helpers `getRoomCapacity()` and `calculateGroupsNeeded()` deleted, with their docblocks, and the now-unused `Room` import. Caller grep across `Modules/`, `app/`, `tests/` found only the definitions. The two misplaced docblocks were fixed too: a stray generate docblock sat above `updateLocks`, and the `resolveSharedRoomRequirement` docblock sat above `restoreIfTrashed`. Both now sit above their own methods | `grep -cE 'getRoomCapacity\|calculateGroupsNeeded'` · `grep -c 'Models\\Room;'` | 0 · 0 |
| ACT-12 | `:45-49`, `:230` | `RequirementTableTruncator` is constructor-injected; `app(RequirementTableTruncator::class)` is gone. **Not applied to the FormRequest:** a FormRequest has no usable constructor injection, so `app(ActivityLockService::class)` there stays | `grep -c 'app(RequirementTableTruncator'` · container build | 0 · `app(ActivityController::class)` resolves |
| ACT-17 | `:63-75` | The `updateLocks` docblock now says that only the TEACHER lock is checked at the form, and that the room-type lock is not | read | — |

## 3. Not applied

| ID | Reason | Detail |
|---|---|---|
| ACT-13 | **not ticked — needs Tarun's go** | The recommendation is (a): delete the dead `SubActivityService.php`. That breaks the green `Modules/TimetableFoundation/tests/Unit/ServiceTest.php`, which asserts the class exists and has `generateForTerm` / `generateForActivity`. Green tests are not changed without an explicit go, and D4 forbids editing tests in this pass |
| ACT-16i | depends on ACT-13 | `strict_types` on `SubActivityService.php` only if the file is kept. Left untouched until ACT-13 is decided |
| ACT-05 | no plan item | The dead service's delete-then-insert has no transaction. It goes away with ACT-13 (a) and is moot until then — the service has no production caller |
| **ACT-18 (new)** | found during this pass, not in the report or the plan | **H · MDL-03 · `Models/Activity.php:252-256`** — `parallelGroups()` is a `belongsToMany` over `tt_parallel_group_activity`, which HAS `deleted_at` (measured), and there is no `wherePivotNull('deleted_at')`. So a soft-deleted link still counts, and `isInParallelGroup()` would answer true for an activity that was removed from its group. **Latent:** the pivot holds 0 rows on this tenant. The report's F7 said MDL-03 "does not apply" because it checked only `SubActivity`/`SubActivityMember`. Not fixed — nothing ticked it, and the fix is a one-line `->wherePivotNull('tt_parallel_group_activity.deleted_at')` on a shared model |

## 4. Needs Tarun's hand

1. **Browser check of Generate.** `/timetable-foundation/timetable-requirement?tab=activities` (and the
   Preparation tab's copy of the button) → Generate. Expect the same "Activities generated successfully.
   Created: … Shared: … Total in DB: … Skipped: …" flash as before. Generation now runs one teacher-count
   query and one profile query per activity instead of one per requirement / per teacher, so the run should
   be no slower.
2. **The lock PATCH.** Set and clear a teacher lock and a room-type lock from the class-wise and room-wise
   views. Expect the JSON `{success:true, message:"Lock updated.", locks:{…}}`. An error now renders through
   the central handler instead of "The lock could not be saved."
3. **Decide ACT-13** (delete `SubActivityService.php` + who updates `ServiceTest.php`), and whether to fix
   **ACT-18** now or log it for the SmartTimetable/ParallelGroup pass.

No migration, seeder or permission sync is needed.

## 5. Unverifiable by this workflow (D4)

- **`strict_types` on the eight shared files.** Proven statically: every call site and every scalar return
  in those files was read, and the real runtime types were measured on `test.localhost` (all IDs come back
  as native `int` or `null`; no `tt_teacher_assignment_roles.code` is NULL). Two coercions strict mode would
  have refused were fixed (ACT-16c, ACT-16g). A path no test exercises could still pass a string somewhere
  this read missed — the Generate run in §4.1 is the real proof.
- **ACT-14 equivalence.** The prefetched counts use the same filters and the same model (global scopes
  intact), and run in the same place in the flow, so the activity scores should not change. Not proven
  against a before/after generation run.

## 6. Verification log

```
php -l (all 9 touched files, after Pint)            → No syntax errors detected ×9
class_exists (all 9 classes, framework booted)      → OK ×9
app(ActivityController::class)                       → resolves (constructor injection works)
APP_ROUTES_CACHE=/tmp/fa-nocache.php route:list      → 7,680 routes; routes with missing method: 0
  PATCH timetable-foundation/activity/{activity}/locks            → ActivityController@updateLocks
  POST  timetable-foundation/requirements/generate-activities/all → ActivityController@generateActivities
vendor/bin/pint <9 files> --format agent             → fixed ActivityTeacher.php, ActivityPriority.php (style only)
grep counts                                          → see §2 (all as expected)
scan.php + scanfilter.py (9 in-scope files)          → 58 rows. Gone: ERR-01 raw-message leak, static cache,
                                                        app() resolution, dead helpers, per-row TeacherAvailability
                                                        count, per-teacher profile query. Remaining rows are the
                                                        deferred CTL-01/02 sizes, the kept ⛔/⚠ comment convention
                                                        (STY-04), the two intended user-facing messages (ERR-01 L),
                                                        the report's accepted per-row writes (QRY-01/07), the
                                                        truncate-rebuild begin/commit (TXN-02), and the new ACT-18
runtime types on test.localhost                      → group/subgroup/profile ids int; roles with NULL code: 0
```

## 7. Final state

**Status: FIXED.** Open items: ACT-13 + ACT-16i (M/L, awaiting Tarun's go), ACT-05 (M, moot until ACT-13),
ACT-07/08 (M/H, deferred to the split pass), and the new **ACT-18 (H, latent)**.
