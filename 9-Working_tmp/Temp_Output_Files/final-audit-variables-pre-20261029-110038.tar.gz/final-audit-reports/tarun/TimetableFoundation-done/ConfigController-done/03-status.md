# 03 — Status · ConfigController

**Fixed:** 2026-10-12 · **By:** claude · **Branch:** development

Decisions taken with the recommended option (no answer was given; revisit if wrong):
- CFG-08 → (a) accept the plain `uq_settings_key`; no migration. Latent only — no create/restore path exists.
- CFG-09 → (a) static per-request memo in `Config::get()`, keyed by tenant then key, flushed on `saved`/`deleted`.
- CFG-14 → resource segment renamed to `timetable_config` → toasts read "Timetable Config was updated successfully." / "Timetable Config status was successfully changed."

## 1. Pre-applied 2026-10-10
None for these three files.

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| CFG-01 | ConfigController.php `update()`, `toggleStatus()` | both try/catch blocks removed; `DB::transaction` kept; response built after the closure | `grep -c "try {" ConfigController.php` | 0 | 2026-10-12 |
| CFG-02 | ConfigController.php `update()` | duplicate `Gate::authorize(...config.update)` removed; `ConfigRequest::authorize()` still gates it. `toggleStatus` keeps its own gate | `grep -n "Gate::authorize" ConfigController.php` | lines 45 (viewAny), 166 (toggle) | 2026-10-12 |
| CFG-03 | ConfigController.php `update()` + ConfigRequest.php `prepareForValidation()` | the four flags are normalized and written only when the request carries them | rolled-back probe: PUT `{value:3,description}` | `used_by_app` stayed 1 (was forced to 0 before) | 2026-10-12 |
| CFG-07 | Config.php `get()` | NUMBER keeps decimals; whole numbers stay int | probe: value `2.5` | `get()` → 2.5; value `9` → 9 | 2026-10-12 |
| CFG-08 | — | accepted, no change (choice a) | — | — | 2026-10-12 |
| CFG-09 | Config.php | `protected static array $resolved` memo + `flushResolved()`; `saved`/`deleted` hooks flush it | probe: two `get()` calls | 1 query; after save the new value is returned | 2026-10-12 |
| CFG-10 | Config.php `get()` | `->first(['value','value_type'])` | `grep -n "first(\['value'" Config.php` | 1 hit | 2026-10-12 |
| CFG-11a/b/c | all three files | `declare(strict_types=1);` | `grep -c strict_types` | 1 each | 2026-10-12 |
| CFG-12 | ConfigController.php docblock | ⚠ replaced with "Note:" | `grep -c "⚠" ConfigController.php` | 0 | 2026-10-12 |
| CFG-13 | all three files | Pint, file by file | `vendor/bin/pint <file> --format agent` | clean; `php -l` re-run after | 2026-10-12 |
| CFG-14 | ConfigController.php | `tt-config` → `timetable_config` in the three remaining flash calls (the two failure flashes went with CFG-01) | `grep -c "tt-config'" ConfigController.php` | 0 | 2026-10-12 |
| CFG-15 | — | superseded: CFG-01 removed the catch, and `bootstrap/app.php` renders JSON for JSON callers | — | — | 2026-10-12 |

`Log` import removed — its only use was the deleted catch.

## 3. Not applied
None. Every item was ticked.

## 4. Needs Tarun's hand
- **TtConfigTest will fail on the new toast text (CFG-14).** `MSG_UPDATED` (line 158) and `MSG_TOGGLE` (line 160) in `tests/Browser/Modules/V2/TimetableFoundation/TimetableConfiguration/TtConfigTest.php` (and the prime_testing copy) still say "Tt-config …". They should become "Timetable Config was updated successfully." and "Timetable Config status was successfully changed.". Not edited — tests are out of scope for this workflow (D4).
- A browser check of the edit dialog and the status switch on `/timetable-foundation/timetable-configuration?tab=tt-config`.

## 5. Unverifiable by this workflow (D4)
- The failure path of `update()` / `toggleStatus()` now relies on the central handler. Statically confirmed (`bootstrap/app.php` renders JSON for `expectsJson()`), but not driven in a browser.

## 6. Verification log
```
php -l (3 files, before and after Pint)          No syntax errors
class_exists Controller / Request / Model          OK OK OK
route:list --path=timetable-foundation/config      3 routes (index, update, toggle-status)
flash('updated.timetable_config')                  Timetable Config was updated successfully.
Config::get('total_number_of_period_per_day') x2   9, 9 — 1 query
save value 2.5 then get()                          2.5 (memo flushed)
partial PUT via ConfigRequest + update()           {"success":true,...}; flags unchanged
rollback                                           value back to 9
```

## 7. Final state
Status **FIXED**. Open: none in this controller. The module-wide note on the unreachable `TimetableConfigPolicy` stays in report §7 and needs its own instruction.
