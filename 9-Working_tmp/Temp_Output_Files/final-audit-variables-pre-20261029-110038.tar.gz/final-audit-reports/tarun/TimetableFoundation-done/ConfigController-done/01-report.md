# Final Audit — TimetableFoundation / ConfigController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/ConfigController.php` (213 lines, 3 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready, but close. 0 blockers, 1 HIGH.**

This is a small, edit-only controller (the 2026-09-09 decision retired every CRUD method and route). The transaction and audit shape is correct in both mutations, every route is gated, and the schema matches the DDL exactly.

The one real defect is **CFG-03**: `update()` unconditionally writes the four boolean flags (`tenant_can_modify`, `mandatory`, `used_by_app`, `is_active`) from `boolean()`, and the FormRequest forces them into every request. A PUT that omits them therefore **switches a live config off and clears its flags** — even though the controller's own comment says a partial PUT must not wipe fields. Because `Config::get()` only reads `is_active=true` rows, the engine silently falls back to hard-coded defaults.

The rest is medium/low debt: two hand-written try/catch blocks that contradict the settled ERR-00 (D1) idiom, an `update()` method over the 80-line bar, an uncached `Config::get()` (a caching DECISION), a latent soft-delete × unique-key trap, an `(int)` cast that truncates decimal NUMBER configs, and style/Pint items. Effort is well under half a day. **Two DECISION items** need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 1 | 6 | 8 | 2 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CFG-01 | F8 Services/Jobs | clean — controller names no Service/Job/Event (`grep -oE '[A-Z][A-Za-z]+(Service\|Job\|Event)\b'` → none) |
| F2 Transactions/Audit | clean — one `DB::transaction` per mutation, `activityLog` after write inside it | F9 Queries/Perf | CFG-09 (DECISION), CFG-10 |
| F3 Authorization | CFG-02; policy unreachable (§7) | F10 Views | clean — controller renders no view (`grep -oE "view\(['\"]"` → none) |
| F4 Validation | CFG-03 | F11 Security/Tenancy | clean — no `env()`, no hard-coded ids, no cache to leak; `key` is uniquely indexed |
| F5 Routes | clean — 3/3 methods routed, all tenant-middleware'd, `{config}` binds | F12 Style | CFG-11, CFG-12, CFG-13, CFG-14 |
| F6 Controller shape | CFG-04, CFG-05, CFG-06 | F13 Deep read | CFG-15 |
| F7 Models | CFG-07, CFG-08 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TimetableFoundation/app/Http/Controllers/ConfigController.php` | controller | 213 | this report | ✅ whole class |
| 2 | `Modules/TimetableFoundation/app/Http/Requests/ConfigRequest.php` | FormRequest (only this controller) | 193 | this report | ✅ whole class |
| 3 | `Modules/TimetableFoundation/app/Models/Config.php` | model (pre-assigned) | 145 | **this report (claimed — 13 files reach it)** | ✅ whole class |
| 4 | `Modules/TimetableFoundation/routes/web.php` lines 91–93 | routes | — | this report | ✅ |
| 5 | `database/migrations/tenant/2026_06_16_152557_create_tt_config_table.php` | migration (schema evidence) | 40 | not code under audit | ✅ read for MDL-07/DDL |
| 6 | `Modules/TimetableFoundation/resources/views/pages/partials/timetable-configuration/config/_list.blade.php` | consuming tab | 303 | not this report | ❌ — **not rendered by this controller** (rendered by `TimetableFoundationController::timetableConfiguration`); checked only for the F3 fourth permission surface |
| — | `App\Http\Controllers\Controller`, `App\Traits\AuthorizesTenantFeature`, `activityLog()`, `flash()`, `App\Models\BaseModel`, `x-backend.*` | common glue | — | common (§4.2) | referenced only |
| — | `Modules/TimetableFoundation/app/Policies/TimetableConfigPolicy.php` | policy | 34 | not consulted by this controller | ❌ unreachable — cross-cutting, §7 |

**Pre-applied 2026-10-10:** none of the in-scope files appear in `../PRE-APPLIED-2026-10-10.md`. This controller was not touched by that pass.

## 4. Routes

```
GET|HEAD  timetable-foundation/config                         timetable-foundation.config.index        index
PUT|PATCH timetable-foundation/config/{config}                timetable-foundation.config.update       update
POST      timetable-foundation/config/{config}/toggle-status  timetable-foundation.config.toggleStatus toggleStatus
```

Middleware on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified` (confirmed via `route:list --json`). `{config}` matches the `Config $config` argument → implicit model binding (the model uses `SoftDeletes`, so a trashed row 404s).

**Unrouted public methods:** none. All three public methods are routed; the retired CRUD methods were deleted, not stubbed.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | `viewAny` | — | — | — (redirect to tab) | — |
| update | ✅ | `update` (+ request) | ✅ closure :116 | `Updated` (:133) | tt_configs, sys_activity_logs | CFG-01, 03, 04, 05, 06, 13 |
| toggleStatus | ✅ | `update` | ✅ closure :189 | `Toggled` (:193) | tt_configs, sys_activity_logs | CFG-01, 15 |

**Tables each mutation SHOULD touch:** both mutations write the config row **and** the audit row (`sys_activity_logs` via `activityLog()`), so each needs one transaction. Both have exactly one. Correct.

## 6. Findings

### F1 — Errors
#### CFG-01 · M · ERR-00 (D1) · ERR-05 — two methods still hand-roll try/catch, and one logs only the message
**Where:** `ConfigController.php:114-170` (`update`), `:186-211` (`toggleStatus`)
```php
114:        try {
...
153:        } catch (\Throwable $e) {
154:            // STRICT RULE 1: meaningful catch — log + user-facing error flash.
155:            Log::error('Failed to update timetable configuration: '.$e->getMessage(), [
...
205:        } catch (\Throwable $e) {
206:            return response()->json([
207:                'success' => false,
208:                'is_active' => $config->is_active,
209:                'message' => flash('status_switch_failed.tt-config'),
210:            ]);
```
**Evidence:** `grep -nE "catch|try \{" ConfigController.php` → catches at 153 and 205. D1 = Laravel idiom: no try/catch; `DB::transaction()` rolls back and `bootstrap/app.php` renders. Neither D2 shape applies (no `\DomainException`, no truncate-rebuild, no `SnapshotProtectionException`).
**Consequence:** the controller uses a different error model than the settled idiom; `update` logs `getMessage()` without the exception object (ERR-05 — trace lost), and `toggleStatus` swallows the failure with **no log at all**, so a failed status save is invisible in the logs while the user gets a fixed toast.

### F3 — Authorization
#### CFG-02 · L · AUTH-04 — the update permission is checked twice
**Where:** `ConfigRequest.php:19` and `ConfigController.php:70`
```php
// ConfigRequest.php
19:        return $this->authorizeByCrudPermission('tenant.timetable-foundation.config');
// ConfigController.php
70:        Gate::authorize('tenant.timetable-foundation.config.update');
```
**Evidence:** scanner flagged `AUTH-04 … ConfigRequest::authorize() and Gate::authorize both check` at `ConfigController.php:68`; `AuthorizesTenantFeature::crudActionFromMethod()` maps PUT/PATCH → `update`, the same string. Both names exist in `config/permissionslist.php:640` (`$crud` carries `viewAny` and `update`).
**Consequence:** no user-visible fault — it is a duplicate of one concern. Rulebook keeps exactly one; the FormRequest check runs first and is the one to keep.
**Note (positive):** every routed method authorizes before loading a record (`Gate::authorize` before the model is touched), and all three routes sit behind the full tenant + auth middleware stack. AUTH-01/AUTH-02/AUTH-05 clean.

### F4 — Validation
#### CFG-03 · H · VAL-03 / deep read #1 — a partial `update()` silently switches a config off and clears its flags
**Where:** `ConfigController.php:87-90` · `ConfigRequest.php:73-78`
```php
// ConfigController.php — unconditional
87:        $data['tenant_can_modify'] = $request->boolean('tenant_can_modify') ? 1 : 0;
88:        $data['mandatory'] = $request->boolean('mandatory') ? 1 : 0;
89:        $data['used_by_app'] = $request->boolean('used_by_app') ? 1 : 0;
90:        $data['is_active'] = $request->boolean('is_active') ? 1 : 0;
// ConfigRequest.php — forces the four keys into EVERY request
73:        $this->merge([
74:            'is_active' => $this->boolean('is_active'),
75:            'tenant_can_modify' => $this->boolean('tenant_can_modify'),
76:            'mandatory' => $this->boolean('mandatory'),
77:            'used_by_app' => $this->boolean('used_by_app'),
78:        ]);
```
**Evidence:**
- Rules for the update path (`ConfigRequest::rules()` lines 27-34): the four flags are `boolean`, **not** `required`; `value` is the only required field.
- `$this->boolean($missing)` returns `false`; `merge()` then makes all four present, so `validated()` carries them and `update()` writes `0`.
- The controller **already knows** partial PUTs must not wipe fields — its comment at lines 79-85 protects `description` for exactly this reason, then does the opposite for the four flags.
- Live data: 15 rows, all `is_active=1`. `Config::get()` (`Config.php:132`) reads `where('is_active', true)`, so a zeroed row stops being read.
**Consequence:** an authorized caller who sends `PUT /timetable-foundation/config/{id}` with only `{"value":"…"}` (a normal API client; the bundled modal always posts hidden `0` inputs so it is safe) deactivates the row and clears `mandatory`, `used_by_app` and `tenant_can_modify`; the engine then silently falls back to hard-coded defaults (e.g. `total_number_of_period_per_day` returns 20 instead of the stored 9).

### F6 — Controller shape
#### CFG-04 · M · CTL-02 — `update()` is 104 lines
**Where:** `ConfigController.php:68-171`
**Evidence:** scanner `CTL-02 … update() is 104 lines`; `python`-free count = 171−68+1 = 104 > 80. The method mixes flag coercion, JSON decoding, type coercion per `value_type`, a transaction, a diff builder and two response shapes.
**Consequence:** hard to review and easy to break; the value-type coercion belongs in a service. (God-controller size is fine: 213 lines, 3 methods.)

#### CFG-05 · L · CTL-04 / MDL-04 — no return types on the three public methods
**Where:** `ConfigController.php:42, 68, 176` (`public function index()`, `update(...)`, `toggleStatus(...)`).
**Evidence:** scanner `CTL-04` ×3. The model's `scopeActive`/`scopeSearch`/`scopeByValueType`/`scopeByTenantModifiable`/`scopeByMandatory`/`scopeByUsedByApp` also lack return types (MDL-04 is for relationships; recorded here as style).
**Consequence:** IDE/route-static analysis cannot verify the declared shape; `: RedirectResponse|JsonResponse` would document the two-branch response.

#### CFG-06 · L · CTL-10 — dead JSON re-validation branch in `update()`
**Where:** `ConfigController.php:100-106`
```php
100:            } elseif ($config->value_type === 'JSON' && is_string($data['value'])) {
101:                $decoded = json_decode($data['value'], true);
102:                if (json_last_error() !== JSON_ERROR_NONE) {
103:                    return back()
104:                        ->withInput()
105:                        ->withErrors(['value' => 'Invalid JSON format. Please check your input.']);
```
**Evidence:** `ConfigRequest::getValueValidationRule('JSON')` returns `'required|json'` (`ConfigRequest.php:59`), and `withValidator()` re-checks JSON at 159-166. `json_last_error()` after a validation that already passed is always clean, so the branch (and its `$decoded`) can never execute on the routed path.
**Consequence:** dead code that suggests the JSON is validated here; it is validated one layer earlier. Note also this `back()` sits **outside** the try/catch, so it is not an ERR-02 issue.

**Clean checks (one line each):** no `dd()/dump()/var_dump()/print_r()/ray()`; no `extract()`; no `compact()`; `Request` is injected (no `request()` helper); no unused private methods or properties; no commented-out blocks.

### F7 — Models
#### CFG-07 · M · MDL-02 / QRY — `Config::get()` truncates decimal NUMBER values
**Where:** `Config.php:138-143`
```php
138:        return match (strtoupper((string) $record->value_type)) {
139:            'NUMBER'  => (int) $record->value,
140:            'BOOLEAN' => filter_var($record->value, FILTER_VALIDATE_BOOLEAN),
141:            'JSON'    => json_decode($record->value, true),
142:            default   => $record->value,
143:        };
```
**Evidence:** the write path accepts decimals — `ConfigRequest::getValueValidationRule('NUMBER')` is `'required|numeric'` and `prepareForValidation` casts a numeric `value` to `(float)` (`ConfigRequest.php:107-111`); the controller stores it unchanged (`ConfigController.php:109-110`). `Config::get('…')` then returns `(int) "12.5" = 12`. Live data happens to be all-integer (15 rows), so this is latent.
**Consequence:** a school that stores `12.5` reads back `12`; every consumer (`max(...)`, ratios) works on a truncated number with no warning.

#### CFG-08 · M · DECISION · VAL-04 / MDL — soft deletes + a plain unique `key` (latent trap)
**Where:** `Config.php:10` (`use SoftDeletes`) · migration `2026_06_16_152557_create_tt_config_table.php:27-28`
```php
27:            $table->unique('ordinal', 'uq_settings_ordinal');
28:            $table->unique('key', 'uq_settings_key');
...
30:            $table->softDeletes();
```
**Evidence:** `SHOW CREATE TABLE tt_configs` → `UNIQUE KEY uq_settings_key (key)` with a nullable `deleted_at`; the model's SoftDeletes global scope hides trashed rows from queries but the index still counts them. Live: 0 trashed rows. No create/restore/forceDelete route exists on this controller (retired 2026-09-09), so the trap is only reachable from a seeder or another writer of `tt_configs`.
**Consequence:** re-inserting a soft-deleted key (seeder re-run, future restore feature) raises MySQL 1062, which surfaces as a 500.
**Clean checks (one line each):** `$fillable` declared with no sensitive columns; `$casts` cover all four booleans and `additional_info` (json/array); `$table='tt_configs'` exists in the tenant migration and **matches DDL v8.1 exactly** (`SHOW CREATE TABLE` vs `Timetable_DDL_v8.1.sql:161-181` — no drift); SoftDeletes present and `deleted_at` exists; no `InteractsWithMedia`; no global scopes; no relationships.

### F8 — Services and jobs
Clean — the controller references no service, job, event, mail or notification (`grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b' ConfigController.php` → only `ConfigRequest`).

### F9 — Queries and performance
#### CFG-09 · M · DECISION · SVC-05 / QRY-12 / TEN-02 — `Config::get()` is uncached (caching candidate)
**Where:** `Config.php:130-134`
```php
130:    public static function get(string $key, mixed $default = null): mixed
131:    {
132:        $record = static::where('key', $key)->where('is_active', true)->first();
```
**Evidence:** `grep -n "static\|Cache\|cache" Config.php` → no cache, no memoisation; `grep -rn "Config::get(" --include=*.php Modules/TimetableFoundation/app/` → 12 call sites, e.g. `PeriodSetController` resolves `total_number_of_period_per_day` **three separate times** (lines 61, 225, 257) and `ClassSubjectSubgroupController` resolves the min/max pair twice (47/48 and 180/181). No call site is inside a loop, and there is **no cache at all**, so TEN-02 has nothing to key wrongly today.
**Consequence:** every `Config::get()` is a fresh DB round-trip; a single timetable page can issue several identical lookups. Any cache added **must** be keyed by tenant id (tenant DB) **and** invalidated when `ConfigController::update()`/`toggleStatus()` writes a row. This is a DECISION (rulebook §F9: adding a cache is not a fix).

#### CFG-10 · L · QRY-03 — `Config::get()` hydrates the whole row to read two columns
**Where:** `Config.php:132` (`->first()` with no column list).
**Evidence:** the method only uses `value` and `value_type`; `->first(['value','value_type'])` (or `->value()` plus a type lookup) returns the same result. The `key` column is uniquely indexed, so the lookup itself is cheap.
**Consequence:** minor wasted I/O per call; matters only once CFG-09 decides to cache or the table grows.
**Clean checks (one line each):** no query inside a loop; no `::all()`; the `key` filter uses the `uq_settings_key` index; `scopeSearch`'s 3 leading-wildcard `LIKE`s (scanner QRY-08, L) are acceptable on a 15-row table — noted, not raised.

### F10 — Views
Clean — the controller renders **no** Blade (`grep -oE "view\(['\"]" ConfigController.php` → none); `index()` redirects, the other two methods redirect/return JSON. There is therefore no view query, no `{!! !!}` and no breadcrumb to check here. The consuming tab partial is out of scope (see §3 #6 and §7).

### F11 — Security and tenancy
Clean — no `env()` in any in-scope file (SEC-01); no hard-coded ids or `?? 1` (SEC-03); `toggleStatus` returns only `success`, `is_active`, `message` — no personal data (SEC-02); no secrets logged; private files not involved; no central-model access. Tenant cache key question is moot because no cache exists (CFG-09).

### F12 — Style
#### CFG-11 · L · STY-01 — `declare(strict_types=1)` missing in all three files
**Evidence:** scanner `STY-01` on `ConfigController.php:1`, `ConfigRequest.php:1`, `Config.php:1`.
**Consequence:** type coercion stays loose; add on touch. Group per file in the plan.

#### CFG-12 · L · STY-04 — emoji in a controller comment
**Where:** `ConfigController.php:30` — `* ⚠ \`edit()\` is gone deliberately. …`
**Evidence:** scanner `STY-04 … emoji in comment`.
**Consequence:** style only; replace ⚠ with a plain word.

#### CFG-13 · L · STY-02 — not Pint-clean (`Config.php`, `ConfigRequest.php`)
**Evidence:** `vendor/bin/pint --test ConfigController.php Config.php ConfigRequest.php --format agent` → `{"result":"fail"}` for `Config.php` (fixers `concat_space`, `not_operator_with_successor_space`, `blank_line_before_statement`, `binary_operator_spaces`) and `ConfigRequest.php` (fixers `trailing_comma_in_multiline`, `not_operator_with_successor_space`, `ordered_imports`). `ConfigController.php` is clean.
**Consequence:** style drift; run Pint only on the touched files.

#### CFG-14 · L · STY-07 / copy — the flash resource renders as "Tt-config"
**Where:** `ConfigController.php:146, 152, 163, 169, 203, 209`
```php
146:                    'message' => flash('updated.tt-config'),
```
**Evidence:** `flash()` (`app/Helpers/helpers.php:24-27`) does `str_replace('_',' ', $resource)` then `ucwords(...)` — it replaces underscores, **not** hyphens. `flash.updated = ':resource was updated successfully.'` → "Tt-config was updated successfully." (same family as ATC-15).
**Consequence:** toasts read "Tt-config", not "Timetable Config".

### F13 — Deep read
#### CFG-15 · M · deep read #7 (message that lies) — `toggleStatus` reports the uncommitted new status on failure
**Where:** `ConfigController.php:189-210`
```php
189:            DB::transaction(function () use ($config, $newStatus) {
190:                $config->is_active = $newStatus;   // mutates the in-memory model
191:                $config->save();
...
205:        } catch (\Throwable $e) {
206:            return response()->json([
207:                'success' => false,
208:                'is_active' => $config->is_active,   // = $newStatus, even though the save failed
```
**Evidence:** `$config->is_active = $newStatus` runs before `save()`; if `save()` throws, the transaction rolls back the DB but the model instance keeps the new value. The catch then reports `$config->is_active` (the new value) beside `success:false`.
**Consequence:** the status switch can render ON (from `is_active:true`) while the database still holds the old value, until the page is reloaded. Fix: `$config->refresh()` (or echo back the pre-write value) in the failure path.

**Deep-read checklist — other questions:**
- *#2 irreversible order* — no deletes/mail/files; clean.
- *#3 duplicate implementations* — `Config::get()` is the single reader; no duplicate. `update` and `toggleStatus` both write `is_active` (two paths for one field) — acceptable, both audited/logged.
- *#4 soft-delete × unique index* — CFG-08 (latent).
- *#5 race* — no count-then-insert / exists-then-create; the `updating` immutability guard is a read of dirty attributes, no lock needed.
- *#6 authorization hole* — none; all three methods gated (CFG-02 only a duplicate).
- *#8 dead feature* — the class-level docblock documents the retired methods; no live dead code except CFG-06.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`TimetableConfigPolicy` is unreachable (module-wide).** Registered at `TimetableFoundationServiceProvider.php:127` (`Gate::policy(Config::class, TimetableConfigPolicy::class)`), but every check in this controller and its FormRequest passes a permission **string** to `Gate`. A string that is not a policy ability never reaches the Policy, so the class is dead code that looks active. Same pattern reported in the AcademicTerm and other module reports — needs a module-level decision.
- **The consuming tab partial** `.../timetable-configuration/config/_list.blade.php` is not rendered by this controller (it is rendered by `TimetableFoundationController::timetableConfiguration`). Checked only to confirm the F3 fourth surface: it uses `permission="tenant.timetable-foundation.config.update"` on `status-switch`, `action.editPermission` and `tab.modal` — **identical** to the string in controller and `config/permissionslist.php:640`. No discrepancy.
- **`Config` is shared by 13 files** (4 controllers, 1 service, the provider, tests, and 2 other-module controllers via the `TimetableConfig` alias). CFG-07/CFG-09 therefore have module-wide reach; the fix is in the one model owned by this report.

## 8. Not covered, and why

- **Runtime / browser behaviour:** no browser or test run (D4). Every finding is static or a read-only SQL probe.
- **`update()` partial-PUT bug (CFG-03):** reasoned statically; not executed, because a write is banned in this phase (no INSERT/UPDATE).
- **The consuming tab partial and the menu page** that render and post to these endpoints: out of scope (§4.1 — the controller renders no view). Their VIEW-family health belongs to `TimetableFoundationController`.
- **Other writers of `tt_configs`** (seeders, the DDL seed block at `Timetable_DDL_v8.1.sql:182`) were not audited; CFG-08's risk comes from them.
- **Tests:** `Modules/TimetableFoundation/tests/Unit/FormRequestValidationTest.php` references `ConfigRequest`, but D4 forbids running or editing tests.
