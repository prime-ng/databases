# Fix Plan — TimetableFoundation / ConfigController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/ConfigController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
_None._

## 2. Fixes that arm a latent defect (sequenced)
_None — CFG-08 (soft-delete trap) needs your decision first, so it sits in §5._

## 3. Errors & transactions (F1/F2)
- [x] **CFG-01** · M · ERR-00 / ERR-05 · `ConfigController.php:114-170, 186-211` — remove both try/catch blocks, per D1 (the Dalvik Laravel idiom):
  - `update()`: `return DB::transaction(fn () => …)` (the closure already exists at line 116), then build the JSON/redirect response **after** the closure. If the JSON `wantsJson()` branch should stay JSON on failure, keep it only if `$request->wantsJson()` re-renders through the central handler — verify `bootstrap/app.php` renders JSON for JSON callers first.
  - `toggleStatus()`: `return DB::transaction(fn () => …)`, return the JSON after.
  - No D2 catch is needed: a `\DomainException` is never thrown on these paths today (the immutability guard throws `\LogicException`, which the central handler will render as a 500 — acceptable, and CFG-03 removes most of its reach).
  Effort: S.

## 4. Authorization (F3)
- [x] **CFG-02** · L · AUTH-04 · `ConfigController.php:70` — drop the controller-level `Gate::authorize('tenant.timetable-foundation.config.update')` in `update()`; keep the FormRequest `authorize()` (it runs first and maps PUT/PATCH → `update` verbatim). ⚠ note: `toggleStatus` does **not** use the FormRequest, so it keeps its own `Gate::authorize` — do not remove that one. Effort: S.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **CFG-03** · H · VAL-03 · `ConfigController.php:87-90` — stop forcing the four flags on every update. Only write a flag when the client actually sent it:
  ```php
  foreach (['tenant_can_modify','mandatory','used_by_app','is_active'] as $f) {
      if ($request->has($f)) { $data[$f] = $request->boolean($f) ? 1 : 0; }
  }
  ```
  ⚠ **Also change `ConfigRequest::prepareForValidation()`** (`ConfigRequest.php:73-78`): it currently merges all four flags into every request, which is what makes the controller's `boolean()` see them as "present". Either merge them only when the field exists, or rely on `$request->has()` with the merge removed. The bundled form always posts hidden `0` inputs, so the UI path is unchanged. Effort: S.
- [x] **CFG-07** · M · MDL-02 · `Config.php:139` — when `value_type === 'NUMBER'`, preserve decimals: `is_numeric($record->value) && (float) $record->value != (int) $record->value ? (float) $record->value : (int) $record->value` (or return `(float)` and let integer consumers cast). ⚠ SHARED — 13 files read `Config::get()`; the change only makes decimal reads correct, never changes an all-integer today (live data verified). Effort: S.
- [x] **CFG-08** · M · DECISION · VAL-04 / MDL · `Config.php` + migration `2026_06_16_152557_create_tt_config_table.php:27-28` — soft-deleted rows still occupy the plain `uq_settings_key` unique. No create/restore path exists today, so this is latent.
      (a) ⭐ No migration: leave as is and record as accepted — the retire-2026-09-09 decision removed the only in-app writer; a seeder that re-inserts a trashed `key` remains a manual risk.
      (b) Add a generated `key_live` column with a soft-delete-aware unique (additive migration) — only worth it when a restore feature returns.
      ➜ Choice: (a) — accepted, no migration (2026-10-12)

## 6. Queries & performance (F9)
- [x] **CFG-09** · M · DECISION · SVC-05 / QRY-12 / TEN-02 · `Config.php:130-134` — cache `Config::get()`. The rulebook treats adding a cache as a DECISION.
      (a) ⭐ Static per-request cache: `protected static array $resolved = []` keyed by `$key` + the tenant id (`tenancy()->tenant?->id ?? 'central'`), flushed in a `static::saved()` / `static::updated()` hook — covers both write methods here (and future writers) with no cross-tenant leak. Does not survive requests, so no `Cache::` invalidation trap.
      (b) `Cache::rememberForever()` with a tenant-keyed key + explicit forget on save — persistent, needs a warm-up path and a clear invalidation contract.
      (c) No cache: leave every `Config::get()` as a fresh query.
      ➜ Choice: (a) — static per-request memo keyed by tenant, flushed on saved/deleted (2026-10-12)
- [x] **CFG-10** · L · QRY-03 · `Config.php:132` — `->first(['value','value_type'])` instead of `->first()` (only those two columns are used). Effort: S.

## 7. Views (F10)
_None — the controller renders no Blade._

## 8. Style (F12) — one item per file
- [x] **CFG-11a** · L · STY-01 · `ConfigController.php` — add `declare(strict_types=1);` at the top. ⚠ only if the returned JSON string values and `$data` array (mixed) still typecheck under strict mode; verify with `php -l` after Pint. Effort: S.
- [x] **CFG-11b** · L · STY-01 · `ConfigRequest.php` — add `declare(strict_types=1);`. Effort: S.
- [x] **CFG-11c** · L · STY-01 · `Config.php` — add `declare(strict_types=1);` (CFG-07 edits the same file; one pass). Effort: S.
- [x] **CFG-12** · L · STY-04 · `ConfigController.php:30` — replace the ⚠ in the docblock comment with plain text. Effort: S.
- [x] **CFG-13** · L · STY-02 · `Config.php` + `ConfigRequest.php` — run `vendor/bin/pint` on exactly these files (`.php` only), never `--dirty` (other sessions' files would be reformatted). Effort: S.
- [x] **CFG-14** · L · STY-07 / copy · `ConfigController.php:146,152,163,169,203,209` — make the toasts read a human resource. The `flash()` helper splits on `.` and title-cases after replacing `_` only, so `flash('updated.tt-config')` yields "Tt-config". Options: rename the resource segment to `tt_config` (reads "Tt Config") or introduce a `flash_config` key/wording. Pick the least surprising wording and keep it consistent across all six call sites. Effort: S.

## 9. Deferred / decisions
- [x] **CFG-15** · M · deep read #7 · `ConfigController.php:205-210` — on `toggleStatus` failure, report the **stored** status, not the uncommitted one: the JSON `is_active` should come from the pre-change value or a `$config->refresh()` inside the failure branch. ⚠ This item is listed last because CFG-01 removes the catch entirely — re-apply only if CFG-01 is ticked and a failure response must still be JSON. If CFG-01 is ticked and the central handler renders JSON for JSON callers, mark CFG-15 as **superseded**. Effort: S.
- **Deferred: none.** No split (D3): this controller is 213 lines / 3 methods. The only module-wide item — unreachable `TimetableConfigPolicy` (`TimetableFoundationServiceProvider.php:127`) — is a module-level decision, not a ConfigController fix; it is recorded in §7 of the report and needs a separate instruction.

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item (CFG-08, CFG-09), write your choice after `➜ Choice:`.
> 3. `⚠ SHARED` items (CFG-03 request file, CFG-07, and any `.blade`/config touch) need their own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/ConfigController.php`. It applies **only** ticked items, in this order.