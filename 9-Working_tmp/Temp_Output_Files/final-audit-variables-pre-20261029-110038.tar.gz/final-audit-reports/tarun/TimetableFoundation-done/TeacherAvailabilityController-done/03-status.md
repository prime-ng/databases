# 03 — Status · TimetableFoundation / TeacherAvailabilityController

**Fixed:** 2026-10-14 · **By:** opencode / claude (fix) · **Plan:** `02-fix-plan.md` (15 items ticked)

## 1. Pre-applied 2026-10-10

None. This controller is not listed in `PRE-APPLIED-2026-10-10.md`.

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| TAV-01 | `TeacherAvailabilityController.php` (rebuild loop) | Removed the per-teacher `catch (\Throwable)`. Any failed write now rolls the whole rebuild back and reaches the outer catch. The error counter and the error list are gone. | `grep -n "errorCount\|firstErrors" <controller>` | no output | 2026-10-14 |
| TAV-02 | same | **Superseded by TAV-01.** The `Log::error(['error' => $e->getMessage()])` call was inside the removed catch. The outer catch already calls `report($e)`. `Log` import removed. | `grep -n "Log::" <controller>` | no output | 2026-10-14 |
| TAV-03 | same, end of the transaction closure | `activityLog(auth()->user(), 'Generated', …)` moved inside `DB::transaction`, after the two set-based UPDATEs. The event literal is unchanged; the `errors` payload key is dropped because no error count exists any more. | `grep -n "activityLog" <controller>` | 1 hit, inside the closure | 2026-10-14 |
| TAV-14 (+ new) | same, outer catch | The failure message is now chosen from two flags, `$truncated` and `$rebuilt`: rebuilt → "rebuilt, but the staffing check failed"; truncated → "…cleared, so they are now empty"; neither → "Nothing was cleared". All three end with "The error has been logged." **New finding fixed here:** the old message appended the raw `$e->getMessage()` (D2 violation). Only the D2-sanctioned `SnapshotProtectionException` message is still shown verbatim. | `grep -n "getMessage" <controller>` | 2 hits, both in the `SnapshotProtectionException` branch | 2026-10-14 |
| TAV-04 | `views/pages/partials/timetable-requirement/teacher-availability/_list.blade.php:47-66` | The Generate form is wrapped in `@can('tenant.timetable-foundation.teacher-availability.generate')`. `Route::has` is kept inside it. | render (§6) | admin sees 1 form | 2026-10-14 |
| TAV-05 | `routes/web.php:284`, the blade above, and the comment in `resource-availability/teacher-availability/_list.blade.php:17` | Route renamed from `teacher-availability.generateSlotRequirement` to `teacher-availability.generate`. The URI is unchanged. | `grep -rn "teacher-availability.generateSlotRequirement" Modules app routes resources config` | no output | 2026-10-14 |
| TAV-08 | controller signature | `: JsonResponse\|RedirectResponse` added. | `php -l` | ok | 2026-10-14 |
| TAV-09 | controller signature | **Answered in the decision round (not in the plan).** `RequirementTableTruncator` and `OptionStaffingService` are method-injected; the two `app()` calls are gone. | `grep -n "app(" <controller>` | 1 hit, inside a comment | 2026-10-14 |
| TAV-10 | controller, before the requirement loop | Capabilities are loaded in ONE query (filters unchanged, `orderBy('id')`), grouped by `class_id`, and narrowed per requirement in PHP. | `/tmp/tav_eq.php` (§6) | 671 requirements, **0 differences**, queries 1,342 → 2 | 2026-10-14 |
| TAV-11 | controller, no-teacher branch | Rows with no eligible teacher go into their own `$pendingUnassigned` buffer and are batch-inserted. They carry exactly the columns `create()` wrote, plus explicit timestamps; the model has no `$attributes` and no observers. | read + render | — | 2026-10-14 |
| TAV-12 | controller comments | ⚠/⛔ markers removed. The sentences are kept. | `grep -n "⚠\|⛔" <controller>` | no output | 2026-10-14 |
| TAV-13a | `Services/OptionStaffingService.php` | `declare(strict_types=1);` | `class_exists` | OK | 2026-10-14 |
| TAV-13b | `Support/Snapshot/SnapshotProtectionException.php` | `declare(strict_types=1);` | `class_exists` | OK | 2026-10-14 |
| TAV-06/07 | — | Decision (a): **deferred** to the split pass (D3). Target: a `TeacherAvailabilityGenerator` service. The `$truncated`/`$rebuilt` flags must stay in the controller around it. | — | — | 2026-10-14 |
| TAV-15 | — | Decision (a): **accepted, report only.** No lock. | — | — | 2026-10-14 |

## 3. Not applied

Nothing. Every ticked item was applied, deferred or accepted as decided.

## 4. Needs Tarun's hand

- **Click Generate once** on `/timetable-foundation/timetable-requirement?tab=teacher-availability`. Generate truncates this tab and every later tab (TRUNCATE commits at once), so this workflow could not replay it, even inside a rolled-back transaction. Expect about 1,340 rows and a flash with no error count.
- **Dusk test to update (TAV-05):** `tests/Browser/Modules/V2/TimetableFoundation/TimetableRequirments/TtTeacherAvailabilityTest.php:468` looks the route up by its old name, `…teacher-availability.generateSlotRequirement`. That lookup now returns null. Change the name to `…teacher-availability.generate`. I did not edit or run it (D4).
- **Batch order:** rows with no eligible teacher are now inserted in a batch rather than between the teacher rows, so their ids are grouped. Nothing downstream orders by id. The later tabs are truncated and rebuilt anyway.

## 5. Unverifiable by this workflow (D4)

- **The end-to-end rebuild (destructive).** The candidate selection is proven identical to the old code (§6). The insert, UPDATE and log path is verified by reading only.
- **The three failure messages.** Forcing them would need a failing write mid-rebuild, which means truncating the live tables.

## 6. Verification log

```
php -l (controller, 2 services, routes)                       -> no syntax errors
vendor/bin/pint <4 files> --format agent                      -> passed
class_exists: controller / OptionStaffingService /
              SnapshotProtectionException                     -> OK OK OK
route:list (uncached)                                         -> POST timetable-foundation/teacher-availability/generate
                                                                 timetable-foundation.teacher-availability.generate
                                                                 (no new duplicate names)
old route name in code                                        -> 0 references
blade compile: both teacher-availability _list partials       -> lint ok, @push 0/0, comments 8/8 balanced

/tmp/tav_eq.php — old per-requirement query vs new grouped lookup, all active requirements:
  requirements=671  differing=0  candidate rows=1328  no-teacher reqs=0
  queries old=1342 new=2

kernel replay on test.localhost, user 1:
  /timetable-foundation/timetable-requirement?tab=teacher-availability   -> 200, Generate form 1, 0 leaks
  /timetable-foundation/resource-availability?tab=teacher-availability   -> 200, Generate form 0 (by design), 0 leaks
roleless non-admin (rolled back):
  Gate allows .generate                                       -> no
  POST /teacher-availability/generate                         -> 302 back to the tab (central 403 handler), rows still 1340
```

## 7. Final state

**FIXED.** Open items: TAV-06/07 (deferred split, H/M) and TAV-15 (accepted, L). The Dusk test rename in §4 is waiting on you.
