# Fix Plan — TimetableFoundation / TeacherAvailabilityController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/TeacherAvailabilityController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ No migration is needed by any item below. The split is deferred (D3); the route rename is a DECISION.

## 1. Blockers reachable today
_None._

## 2. Fixes that arm a latent defect (sequenced)
_None._

## 3. Errors & transactions (F1/F2)
- [x] **TAV-02** · M · ERR-05 · `TeacherAvailabilityController.php:373-377` — change the inner log context from
      `'error' => $e->getMessage()` to `'exception' => $e` (or call `report($e)`), so the trace is kept. Effort: S.
- [x] **TAV-03** · M · TXN-04 · `TeacherAvailabilityController.php:464-475` — move the `activityLog(auth()->user(), 'Generated', [...])`
      call **inside** the transaction closure, after the two set-based UPDATEs (`:401`, `:439`) and before `:464`. The closure must
      not change its return. Effort: S.
- [x] **TAV-14** · M · deep read · `TeacherAvailabilityController.php:509-531` — make the failure message honest:
      track whether the truncate actually ran (a local `$truncated = true` set right after `:106`) and only claim "…are now empty"
      when it did; otherwise use a plain "Generation failed. Nothing was cleared. The error has been logged.". Effort: S.
- [x] **TAV-01** · H · DECISION · ERR-06 / ERR-00(D2) · `TeacherAvailabilityController.php:366-378` — the per-teacher
      `catch (\Throwable)` is not one of the D2-sanctioned catches and lets the transaction commit a partial rebuild.
      (a) ⭐ **Fail fast:** delete the inner catch; let the exception reach the outer D2 catch, so a bad write rolls the
          whole rebuild back and the message is truthful. The `$errorCount`/`$firstErrors` counters go away.
      (b) **Keep best-effort** but narrow the catch to the D2 shapes only, wrap each teacher's write so a failure cannot
          poison the batch, and add the ERR-01/date comment. Larger change; partial commits remain possible.
      (c) Leave as is, accepted risk.
      ➜ Choice: (a) fail fast — inner catch removed (2026-10-14, Tarun)

## 4. Authorization (F3)
- [x] **TAV-04** · M · DECISION · AUTH-01 · ⚠ SHARED · `views/pages/partials/timetable-requirement/teacher-availability/_list.blade.php:47`
      — the Generate button is gated only by `Route::has`, not by `@can('tenant.timetable-foundation.teacher-availability.generate')`.
      The blade belongs to **TimetableFoundationController**'s screen, so any edit here is a shared-file change.
      (a) ⭐ **Add the `@can` here now:** wrap the `<form>` in `@can(...)` (keep `Route::has` inside it). No controller change.
      (b) **Defer** to TimetableFoundationController's report and tick it there.
      (c) Leave as is, accepted.
      ➜ Choice: (a) @can added on the Generate form (2026-10-14, Tarun)

## 5. Validation, routes, models (F4/F5/F7)
- [x] **TAV-05** · L · DECISION · STY / CTL-05 · ⚠ SHARED · `routes/web.php:265` — the route name
      `teacher-availability.generateSlotRequirement` is copied from the Slot Requirement route and misdescribes this action.
      (a) ⭐ **Rename to `teacher-availability.generate`** and update the two call sites: the caller blade
          `_list.blade.php:47-48` and `tests/Browser/.../TtTeacherAvailabilityTest.php:468`,
          `.../ResourceAvailability/TtSubjectWiseTeacherAvailabilityReportTest.php:473`. (Tests are **not** edited by this
          workflow — D4 — so this needs the team to update them.)
      (b) Leave the name; record as accepted.
      ➜ Choice: (a) renamed to teacher-availability.generate; Dusk test update left to Tarun (D4)
- _No models work: F7 is clean._

## 6. Queries & performance (F9)
- [x] **TAV-10** · H · QRY-01 · `TeacherAvailabilityController.php:210-250` — prefetch capabilities once instead of
      querying per requirement. Build the requirement loop's class ids and option subject/SSF maps first, load
      `TeacherCapability` (with `teacherProfile`) for the whole `whereIn('class_id', $classIds)` set in **one** query, key it by
      `class_id.subject_study_format_id`, and replace the in-loop `->get()->sortByDesc()->unique()` with a lookup on the keyed
      collection (do the sort/unique in SQL or once per key). Removes ~660 queries on this tenant. Effort: M.
- [x] **TAV-11** · L · QRY-07 · `TeacherAvailabilityController.php:252-261` — add the no-eligible-teacher row to the
      `$pending` buffer (then `$flush(false)`) instead of a standalone `TeacherAvailability::create()`, so every write takes
      one path. Effort: S.

## 7. Views (F10)
_None — the controller renders no view._

## 8. Style (F12) — one item per file
- [x] **TAV-08** · L · CTL-04 · `TeacherAvailabilityController.php:57` — add a return type to `generateTeacherAvailability()`
      (`: JsonResponse|RedirectResponse`). Effort: S.
- [x] **TAV-12** · L · STY-04 · `TeacherAvailabilityController.php` — remove the ⚠/⛔ emoji markers from the comments
      (`:61,68,102,238,275,284,308,323,327,396`), keeping the sentences. Effort: S.
- [x] **TAV-13a** · L · STY-01 · `OptionStaffingService.php:1-3` — add `declare(strict_types=1);`. Effort: S.
- [x] **TAV-13b** · L · STY-01 · `Support/Snapshot/SnapshotProtectionException.php:1-3` — add `declare(strict_types=1);`. Effort: S.

## 9. Deferred / decisions
- [x] **TAV-06 / TAV-07** · H/M · DECISION · CTL-02 / CTL-06 — the single method is 476 lines and carries the whole
      generation algorithm. D3 says a split is deferred in this pass.
      (a) ⭐ **Defer** to the split pass: keep the controller, record the extraction of `generateTeacherAvailability()` into a
          `TeacherAvailabilityGenerator` service as the target.
      (b) **Extract now** in this pass (move `:108-464` into a service; controller keeps gate + transaction + response). Larger
          change; must preserve the TRUNCATE-before-transaction order.
      (c) Leave as is, accepted.
      ➜ Choice: (a) defer the split to the split pass (D3)
- [x] **TAV-15** · L · DECISION · TXN-06 — the TRUNCATE + rebuild has no lock; two overlapping runs can interleave.
      (a) ⭐ **Accept + report only** (admin action behind a confirm dialog; re-run is always safe because everything is derived
          from Requirement Consolidations).
      (b) **Add a guard:** wrap the run so a second concurrent Generate is refused (cache lock or a `DB::transaction` …
          `lockForUpdate` on a sentinel), with a plain message.
      ➜ Choice: (a) accept + report only
