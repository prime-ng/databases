# Status — TimetableFoundation / OptimisationReportController

**Fixed:** 2026-10-13 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — 7 items ticked. OPT-05, OPT-06 and OPT-07 deferred by decision (D3).

---

## 1. Pre-applied work

None. `PRE-APPLIED-2026-10-10.md` lists no file in this controller's scope.

The service's `forReportsTab()` catch was added on 2026-10-12 under TFC-09 (`TimetableFoundationController`). It is that controller's D2 shape and was left as is.

---

## 2. Applied

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| OPT-01 | controller `full()` | Removed the try/catch around the build. A failure is now logged and rendered by the central handler. `optError` is passed as `null` with a comment; the page's `@if ($optError)` branch is dead but kept, because the tab partial shares it. | `grep -c 'try {'` | 0 |
| OPT-02 | controller `downloadPdf()` | Removed the try/catch and the `Log::error([... getMessage()])`. Dropped the `Log` import. The "no timetable" redirect stays, because it is a normal outcome rather than an error. | `grep -c 'Log::'` / `getMessage` | 0 / 0 |
| OPT-03 | service `schoolName()` | Removed the bare `catch (\Throwable)`. `sch_organizations` is a core table (1 row here), so a failure reading it goes to the central handler instead of printing "School". | read | — |
| OPT-03 | service `idleTeachers()` | Kept `report($e)` and added the D2 comment (ERR-01, 2026-10-13). The idle-teacher list is optional, so the rest of the report still renders. | read | — |
| OPT-04 (a) | controller `full()`, `fullPdf()` | Both now call `Gate::authorize('tenant.timetable-foundation.config.export')` before `abortUnlessSchoolAdmin()`. The role check stays as a second lock on salary data. No new key. | rolled-back query of role grants | permission id 1450 · Super Admin HAS · School Admin HAS · no other role holds it. Nobody loses access today |
| OPT-08 | service | Request-scoped `$memo`, cleared at the start of every `build()`. Memoised: `classSectionNames()`, `capabilityIndex()`, `classTeacherIds()`, and a new `classNames()` that replaces four inline `sch_classes` plucks. | old vs new build on timetable 4 | queries 39 → 31, output byte-identical in both modes |
| OPT-09 | controller + service | `SnapshotContext` is constructor-injected in both. It is bound `scoped()`, and neither class is a singleton, so it is the same per-request instance `app()` returned. | `grep -c 'app(SnapshotContext'` (controller) | 0 |
| OPT-10 | service | Replaced the ⚠ / ⛔ / ⭐ / box-drawing comment markers with plain text ("Note:", "Important:", plain section headers). Comments only. | `grep -cP '[⚠⛔─⭐]'` | 0 |
| Pint | the 2 touched PHP files | Passed with no changes. | `php -l` after Pint | OK ×2 |

### 2.1 Applied beyond the ticked plan — read this

1. **OPT-11 (new, found while doing OPT-08): unplaced lessons never showed the class name.** In `unplaced()`, the closure read `$classNames` without it being in `use()`. The `??` hid the undefined variable, so every class-level unplaced row read "Class #<id>". It is now passed in. A PHP probe shows the shape: the same lookup prints `Class #7` without `use()` and `Class 7` with it. ⚠ It is not shown on live data: timetable 4 has **0 unplaced lessons**, which is also why the old and new output are identical.

### 2.2 Not memoised, and why

- **`windowLoads()` and `optionKeys()`** are in-memory loops over `$teachers`, not queries. The report listed them under OPT-08, but memoising them would only risk a stale result if a section changed `$teachers`, with no query saved.
- **`teacherRows()`** is called with a different set of teacher ids each time (placed, idle, pool), so a per-call memo would never hit. A per-id memo is possible, but it changes the query shape; left for the split pass.

---

## 3. Not applied

| ID | Why |
|---|---|
| OPT-05 | Decision (a): defer the 2,940-line service split to the split pass (D3). |
| OPT-06 | Companion of OPT-05; deferred with it. |
| OPT-07 | The duplicate "can this teacher's lessons be handed over" and "qualified teachers per subject" logic touches the same class; deferred with OPT-05. |

---

## 4. Needs Tarun's hand

1. **Browser check:**
   - `/timetable-foundation/optimisation-report` as a School Admin: the page and its PDF still load.
   - As any other role: 403.
   - The salary-free PDF from the Reports & Logs tab still downloads.
2. No migration and no permission sync are needed. `config.export` is already seeded and granted to both admin roles.

---

## 5. Unverifiable by this workflow (D4)

- **OPT-11** cannot be shown on live data until a timetable has unplaced lessons.
- **The PDF path** was not rendered in this pass. Only the build behind it was compared old vs new.
- **A permission refusal on the salary pages** cannot be exercised: no role has the admin role without `config.export`.

---

## 6. Verification log

```
php -l (controller, service — after Pint)                → No syntax errors ×2
class_exists: controller, service                         → OK ×2
route:list --path=optimisation-report (uncached)         → 3 GET routes, unchanged
dry run, tenant xyz_school_00000000000040008000_202627, timetable 4 (read-only):
  old (backup copy) vs new build, salary-free             → queries 39 → 31; differing keys: none
  old vs new build, with money                            → queries 39 → 31; differing keys: none
  unplaced lessons on timetable 4                         → 0
role grants for tenant.timetable-foundation.config.export → Super Admin, School Admin; no other role
grep controller: try=0 · Log::=0 · getMessage=0 · Gate::authorize=3 · app(SnapshotContext=0
grep service: comment markers=0 · memo[ uses=6 · sch_classes pluck=1 (inside classNames())
```

---

## 7. Final state

**Status: FIXED** (2026-10-13). Open items, all deferred by decision under D3:

- 2 H: OPT-05, OPT-06.
- 1 M: OPT-07.

Every other item in the plan is closed, plus OPT-11.
