# Final Audit — TimetableFoundation / OptimisationReportController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/OptimisationReportController.php` (176 lines, 3 routed public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not sign-off clean, but no blocker. 0 blockers, 2 HIGH (both the service), 5 MEDIUM, 3 LOW.**

The controller itself is a thin, fully read-only wrapper: three GET routes, no writes, no CSRF surface, return types present, `strict_types` on, and its authorization works — the salary-free `pdf()` is gated on `tenant.timetable-foundation.config.export`, which is declared in `config/permissionslist.php` and **is seeded** on this tenant (id 1450), while the two salary pages autorize through `abortUnlessSchoolAdmin()`.

The single worst finding is **OPT-05**: its pre-assigned service, `SchoolOptimisationReportService`, is a **2,871-line, 45-method god class**, with six methods between 187 and 306 lines (OPT-06). That is maintainability debt, not a live crash. The remaining teeth are two controller `try/catch` blocks that still violate the settled D1 idiom (OPT-01, OPT-02) and a pair of duplicated planning implementations that can silently disagree (OPT-07).

Rough effort: about one day for the mechanical F1/F9/F12 items; the service split is deferred (D3) and is the real work.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 2 | 5 | 3 | 2 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | OPT-01, OPT-02, OPT-03 | F8 Services/Jobs | OPT-07, OPT-08, OPT-09 |
| F2 Transactions/Audit | clean — read-only, no write path (`grep` of both files → NONE) | F9 Queries/Perf | OPT-08; QRY-11 hits verified constant |
| F3 Authorization | OPT-04 (scanner AUTH-01 B hits on full/fullPdf are **false positives** — see OPT-04) | F10 Views | clean — no query in any blade; all 8 blades compile |
| F4 Validation | clean — FormRequest, `validated()` only | F11 Security/Tenancy | clean — no `env()`, no JSON, no tenant cache |
| F5 Routes | clean — 3 routes, all resolve, all read-only, tenancy+auth present | F12 Style | OPT-10 |
| F6 Controller shape | OPT-05, OPT-06 (service; controller itself is clean) | F13 Deep read | OPT-07; the `$optError` branch becomes dead after OPT-01 |
| F7 Models | n/a — no Eloquent model in scope (DB facade only) | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/OptimisationReportController.php` | controller | 176 | this report | ✅ whole class |
| 2 | `app/Http/Requests/OptimisationReportRequest.php` | FormRequest | 52 | this report (used only here) | ✅ whole class |
| 3 | `app/Services/SchoolOptimisationReportService.php` | service | 2871 | **this report (pre-assigned)** | ✅ whole class |
| 4 | `app/Services/OptionCellResolver.php` | service | 533 | ↗ linked → TimetableFoundationController (pre-assigned; report not yet written) | usage only |
| 5 | `app/Support/Snapshot/SnapshotContext.php` | support (subsystem) | 342 | ↗ shared subsystem — not audited here (§4.2/§5; same call as RequirementConsolidationController) | usage only |
| 6 | `resources/views/pages/optimisation-report.blade.php` | page (full) | 80 | this report | ✅ |
| 7 | `resources/views/pages/partials/reports-and-logs/optimisation-report/pdf.blade.php` | pdf | 16 | this report | ✅ |
| 8 | `.../optimisation-report/_report-body.blade.php` | partial (shared body) | 1126 | this report | ✅ |
| 9 | `.../optimisation-report/_coverage.blade.php` | partial | 372 | this report | ✅ |
| 10 | `.../optimisation-report/_coverage-charts.blade.php` | partial | 172 | this report | ✅ |
| 11 | `.../optimisation-report/_skills.blade.php` | partial | 15 | this report | ✅ |
| 12 | `.../optimisation-report/_charts-script.blade.php` | partial | 172 | this report | ✅ |
| 13 | `.../optimisation-report/_week-modal.blade.php` | partial | 129 | this report | ✅ |
| 14 | `routes/web.php` (the three `optimisationReport` routes) | routes | — | this report | ✅ |
| — | `Barryvdh\DomPDF\Facade\Pdf`, `Gate`, `Log`, `Str`, `Response`, `View` | framework | — | common | props checked |
| — | `x-backend.layouts.app`, `x-backend.components.breadcrum` | shared components | — | common | tag names checked |
| — | `Modules\SchoolSetup\Services\ActiveTeachers` | other-module service | — | common (§4.2) | usage only |
| — | `SnapshotTimetable`, `Timetable` models | other classes | — | reached only inside SnapshotContext (§5) | not audited here |

**Pre-applied 2026-10-10:** none. Neither the controller nor its service appears in `../PRE-APPLIED-2026-10-10.md`. Nothing here is a re-audit of that pass.

## 4. Routes

Uncached probe: `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` filtered for `OptimisationReportController@`.

```
GET|HEAD  timetable-foundation/optimisation-report                      timetable-foundation.optimisationReport.full     full
GET|HEAD  timetable-foundation/optimisation-report/pdf                  timetable-foundation.optimisationReport.fullPdf  fullPdf
GET|HEAD  timetable-foundation/reports-and-logs/optimisation-report/pdf timetable-foundation.optimisationReport.pdf      pdf
```

Middleware on all three: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified, EnterTimetableSnapshot`.

**Unrouted public methods:** none. The class has 3 routed public methods plus the constructor; every other method is `private` (D5 not triggered).

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| `pdf` | ✅ | `Gate::authorize('tenant.timetable-foundation.config.export')` | — | — | — (read-only) | — |
| `full` | ✅ | `abortUnlessSchoolAdmin()` (role) | — | — | — | OPT-01, OPT-04 |
| `fullPdf` | ✅ | `abortUnlessSchoolAdmin()` (role) | — | — | — | OPT-02 (via `downloadPdf`), OPT-04 |
| `downloadPdf` (private) | via `pdf`/`fullPdf` | inherited | — | — | — | OPT-02 |
| `abortUnlessSchoolAdmin` (private) | — | — | — | — | — | OPT-04 |
| `avgSalary` (private) | — | — | — | — | — | — |

**What each method SHOULD touch:** nothing — the class writes no table. Confirmed: `grep -nE 'DB::transaction|->save\(|::create\(|::update\(|->update\(|->delete\(|->insert\(|activityLog'` over controller + service → **NONE**.

## 6. Findings

### F1 — Errors
#### OPT-01 · M · ERR-00 (D1) / ERR-07 — `full()` still catches `Throwable` in the controller
**Where:** `OptimisationReportController.php:71-83`
```php
try {
    $timetableId = $this->service->resolveTimetableId(...);
    $optReport = $timetableId
        ? app(SnapshotContext::class)->run($timetableId, fn () => $this->service->build($timetableId, $avgSalary, true))
        : null;
} catch (\Throwable $e) {
    report($e);
    $optError = 'The optimisation report could not be built for this timetable. The error has been logged.';
}
```
**Evidence:** `grep -nE 'try \{|catch \(' OptimisationReportController.php` → lines 71/80 and 118/142.
**Consequence:** D1 forbids a controller try/catch that D2 does not allow; `full()` is read-only (ERR-07), so the central handler in `bootstrap/app.php` should render the failure. As written the page silently swaps in a fixed string and the controller carries a second, divergent error model.

#### OPT-02 · M · ERR-00 (D1) + ERR-05 — `downloadPdf()` catches `Throwable` and logs only `getMessage()`
**Where:** `OptimisationReportController.php:118,142-146`
```php
} catch (\Throwable $e) {
    Log::error('Optimisation report PDF failed', ['timetable_id' => $timetableId, 'with_money' => $withMoney, 'error' => $e->getMessage()]);
    return redirect($back)->with('error', 'The optimisation report PDF could not be generated. Please try again.');
}
```
**Evidence:** same `grep`; line 143 contains `$e->getMessage()`.
**Consequence:** two rules at once — a D1-forbidden controller catch, and ERR-05: logging the string alone loses the stack trace, so a production PDF failure cannot be diagnosed from the log.

#### OPT-03 · M · ERR-00 (D1) / ERR-05 — service catches with no `report()` or no ERR-01 comment
**Where:** `SchoolOptimisationReportService.php:2837-2841` and `:880-886`
```php
// schoolName()
try { $name = DB::table('sch_organizations')->value('name'); }
catch (\Throwable $e) { $name = null; }          // silently swallowed, never logged

// idleTeachers()
try { $ids = array_diff(array_map('intval', ActiveTeachers::ids()), array_keys($teachers)); }
catch (\Throwable $e) { report($e); return []; }  // reported, but no fixed message / ERR-01+date comment
```
**Evidence:** `grep -nE 'try \{|catch \(|report\(' SchoolOptimisationReportService.php` → 880/882/883, 2837/2839.
**Consequence:** `schoolName()` can hide a real DB error and silently fall back to `tenant()->name` (the table exists today — 1 row — so this only bites when something is genuinely wrong, which is exactly when it must log). D2 requires every allowed service catch to carry `report($e)`, a fixed message, and a comment naming ERR-01 + the date; neither catch does.

**Clean:** no `$e->getMessage()` reaches the user (`full()` flashes a fixed string; `downloadPdf()` flashes a fixed string); no `catch (\RuntimeException)`; no `findOrFail()` inside a catch; `pdf()`/`full()`/`fullPdf()` authorize before they load anything.

### F2 — Transactions and audit
**clean — read-only.** No write path exists, so no `DB::transaction`, no `activityLog()`, and no irreversible side effect is required (`grep` above → NONE). TXN-01..06 do not apply.

### F3 — Authorization
#### OPT-04 · L · AUTH-01 (downgraded) / AUTH-06 — salary pages gate on hard-coded role names, not a permission
**Where:** `OptimisationReportController.php:42,63,99,153-162`
```php
private const SALARY_ROLES = ['Super Admin', 'School Admin'];
...
abort_unless($user && ($user->is_super_admin || $user->hasAnyRole(self::SALARY_ROLES)), 403, '...');
```
**Evidence:** the scanner flags both methods B:
```
AUTH-01 sev=B full     "routed full() has no authorization ... OptimisationReportRequest::authorize() is weak"
AUTH-01 sev=B fullPdf  "routed fullPdf() has no authorization ..."
```
Read in source, these are **false positives**: `full()`/`fullPdf()` both call `abortUnlessSchoolAdmin()` as their first statement. The gate is real. The genuine (low) issue is that the module's permission system is bypassed for these two salary routes: `pdf()` uses `tenant.timetable-foundation.config.export` (declared at `config/permissionslist.php:640`, seeded id 1450), while the money pages are tied to the literal role names. A tenant that renames a role, or grants admin rights through a different role, silently loses (or gains) salary access with no permission row to manage it.
**Consequence:** salary visibility cannot be granted or revoked through `/system-admin/roles`; it follows role *names* only.

**Clean:** `pdf()` authorized; permission declared and seeded; no `Gate::any(...)` without `|| abort(403)`; no Policy is involved so none is left unreachable by this controller; FormRequest `authorize()` returns `true` and the controller is the one authorizing (AUTH-04 not violated — exactly one check per surface beyond the request).

### F4 — Validation and input
**clean.** `OptimisationReportRequest` types both fields (`nullable|integer|min:1`, `nullable|numeric|min:0|max:10000000`); the controller reads only `validated()`, and optional keys are guarded (`isset($validated['opt_timetable_id']) ? (int) … : null`; `isset($validated['opt_avg_salary']) …`). No `$request->all()`, `except()`, inline `validate()`, uniqueness rule or upload (`grep -nE '->all\(\)|->except\(|->validate\(' OptimisationReportController.php` → NONE). No cross-field rule, so no FormRequest execution probe was needed.

### F5 — Routes
**clean.** `route:list` shows three routes, each resolving to an existing method (`method_exists` holds); all three are GET **reads** (no state change, RTE-01 clear); every public method is routed (RTE-03 clear); each route carries the full tenancy + auth middleware chain (RTE-05 clear); no custom route shares a prefix with a `resource` (RTE-06 n/a).

### F6 — Controller shape
#### OPT-05 · H · CTL-01 — the service is a 2,871-line, 45-method god class
**Where:** `SchoolOptimisationReportService.php` (class starts `:49`; `wc -l` = 2871)
**Evidence:** `php ../prime_info/.../scan.php …` →
```
CTL-01 sev=H  SchoolOptimisationReportService: 2823 lines, 5 public methods
```
**Consequence:** a single service owns teachers, rooms, classes, schedule, coverage, skills, options, saving-range maths and INR formatting. Any change to one section risks the others; it cannot be unit-reasoned about, and it is the hardest file in this report to review or hand over. Split → **DEFERRED** per D3.

#### OPT-06 · H · CTL-02 — ten service methods are over 80 lines; six are over 150
**Where / Evidence:** scanner (body length between declarations):
```
CTL-02 H  teacherSection  306   CTL-02 H  freeingPlan     292
CTL-02 H  coverageSection 286   CTL-02 H  optionSection   212
CTL-02 H  classSection    197   CTL-02 H  skillSection    187
CTL-02 M  scheduleSection 144   CTL-02 M  build           126
CTL-02 M  roomSection     108   CTL-02 M  teachers        101
```
**Consequence:** six methods exceed the 150-line H threshold by up to 2×. Each interleaves SQL, ranking heuristics and prose-string assembly, so a bug in one branch is effectively unreviewable and untestable in isolation. Extract per section → **DEFERRED** with OPT-05.

### F7 — Models
**n/a.** Neither the controller nor the service names an Eloquent model; all reads use the `DB` query builder (verified: `grep -nE 'extends Model|::query\(\)' SchoolOptimisationReportService.php` → NONE outside the shared SnapshotContext). MDL-01..09 have no target here.

### F8 — Services and jobs
#### OPT-07 · M · SVC-04 — two handover implementations and two coverage implementations of the same idea
**Where:** `SchoolOptimisationReportService.php`
- `teacherSection()` builds a handover plan in `$tryHandover` (`:625-673`) and runs it (`:677-705`).
- `freeingPlan()` builds a second handover plan in `$handOver` (`:1003-1122`), with its own rules (list A / list B, new capabilities).

**Evidence:** `grep -nE 'function (teacherSection|freeingPlan|skillSection|coverageSection)' SchoolOptimisationReportService.php`.
**Consequence:** the "can this teacher's lessons be handed over?" question — qualified, under 85% of limit, day-length, option-clash — is answered by two separate code paths. They already differ (section 1 restricts to under-used teachers; section 7 tries everyone), so the two sections of one report can disagree about whether a handover is possible. Same duplication between `skillSection()` (`:2149`) and `coverageSection()` (`:1800`) for "qualified teachers per subject".

#### OPT-08 · M · SVC-05 / QRY-12 — repeated identical lookups, re-queried many times per report
**Where:** `SchoolOptimisationReportService.php` — each is resolved per call, never memoised:
```
classSectionNames()  def :2821   called :437, :1865, :2504, :2556           (4×)
capabilityIndex()    def :1448   called :594, :944                          (2×)
classTeacherIds()    def :1367   called :614, :970                          (2×)
optionKeys()         def :1323   called :606, :973                          (2×)
windowLoads()        def :1302   called :605, :972                          (2×)
teacherRows()        def :373    called :436, :890, :1864, :2195            (4×)
DB::table('sch_classes')->pluck('name','id')  at :438, :955, :1866, :2505   (4×)
```
**Evidence:** `grep -nE 'classSectionNames\(|capabilityIndex\(|classTeacherIds\(|optionKeys\(|windowLoads\(|teacherRows\(' SchoolOptimisationReportService.php`.
**Consequence:** one report build issues the same "load all class-sections", "load all capabilities", "load all class names" queries several times over. On a large school this multiplies the report's query count for zero new information. Mechanical fix: resolve once per `build()` (local property/memo), not caching (§7/§9 — a cache would be a DECISION, this is not).

#### OPT-09 · L · SVC-02 — `SnapshotContext` resolved mid-method with `app()` instead of injected
**Where:** `OptimisationReportController.php:78,120` and `SchoolOptimisationReportService.php:120`
```php
app(SnapshotContext::class)->run($timetableId, fn () => $this->service->build(...));
```
**Evidence:** `grep -nE 'app\(SnapshotContext::class\)'` → three sites.
**Consequence:** a service-locator call inside method bodies rather than constructor injection. `SnapshotContext` is `scoped()` (`TimetableFoundationServiceProvider.php:111`) and is already injected into `EnterTimetableSnapshot`, so it can be injected here too. Low: it is the module-wide pattern, not a defect introduced by this controller.

**Clean:** no HTTP in the service (SVC-01); no `updateOrCreate`/`firstOrCreate`/seeding on a read path (SVC-03); no job, listener or export class in scope.

### F9 — Queries and performance
**See OPT-08.** Additional checks: **no query inside a loop** (QRY-01) — every `DB::` call in the service sits before the loops that consume it (the two queries in `optionSection` at `:2657`/`:2659` sit in an `if`, not a loop). Lists that are genuinely paginated do not exist (the timetable picker is a bounded `<select>`, not a list page — QRY-02 n/a). The four scanner QRY-11 hits are `OptionCellResolver::…Sql() . ' AS owner_cid'` at `:341-344`: the concatenated tail is a literal string and the resolver interpolates only constant alias names — **verified constant, not a finding**.

### F10 — Views
**clean.** `grep -nE 'Model::|DB::|->where\(|->get\(\)|->count\(\)'` over all eight in-scope blades → **NONE** (the only `collect()` calls are in `_coverage-charts.blade.php:17,19`, in-memory). `{!! !!}` is used only for the two computed-HTML helpers `$bar()` and `$ttName()`; `$ttName` escapes the name with `e($name)` and casts the id `(int)`, and the `_skills` raw output is a literal `' · '`/`'<br>'` — no user text is emitted raw (VIEW-03 clear). All eight blades compile (`Blade::compileString()` → `php -l` → "No syntax errors"; `@push`/`startPush` both 0). No `{{-- --}}` inside `@php`.

### F11 — Security and tenancy
**clean.** No `env()` (`grep -nE '\benv\('` over both files → NONE). No JSON endpoint, so no personal-data-over-JSON exposure (SEC-02): the only salary/name output is HTML/PDF served to authorized admins, and the salary-free build scrubs every money key (`scrubMoney()`). No hard-coded ids or `?? 1` fallbacks. No cache or static cache introduced (TEN-02 n/a). `schoolName()` reads `sch_organizations` on the tenant connection (`Schema`/`DB` probe: table exists, 1 row); `tenant()?->name` is the documented fallback.

### F12 — Style
#### OPT-10 · L · STY-04 — emoji / warning markers in service comments
**Where:** `SchoolOptimisationReportService.php` comments at `:37,40,44,114,316,365,936,1245,1365,1785,1790,2487,2547` and more.
**Evidence:** scanner `STY-04 sev=L … "emoji in comment"` (16 hits, service only).
**Consequence:** the file uses `⚠` and `⛔` (and box-drawing/separator glyphs) as comment markers; STY-04 asks for plain English comments. Cosmetic; one cleanup item for the file. Both audited PHP files already carry `declare(strict_types=1)`, sorted imports and camelCase names, so no other F12 item applies.

### F13 — Deep read
- **Duplicate implementations (Q1/Q3):** OPT-07 — answered.
- **Messages that lie (Q7):** none user-facing. The controller docblock's claim that the try/catch exists so a failure "lands the user on a page with a message instead of a raw 500" is the exact behaviour the central handler already provides; after OPT-01 the `$optError` variable is only ever `null` and its view branch (`optimisation-report.blade.php:68-69`, `_list` equivalent) becomes dead — record, don't silently keep.
- **Writes / irreversible order / races (Q2/Q5):** none — the class performs no write and takes no lock.
- **Authorization hole (Q6):** none beyond OPT-04's role-vs-permission note.
- **Dead feature (Q8):** none found; the salary/full surfaces are reachable by URL exactly as documented.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`OptionCellResolver`** is owned by the `TimetableFoundationController` report (pre-assigned in `00-CLASS-OWNERS.md`, report not yet written). Its usage here is checked and correct: `joinOwner()`, `owner*Sql()`, `kindSql()`, `optionNameSql()` and `optionLabel()` are called with default/constant aliases; the raw-SQL fragments concatenate only literals, so the QRY-11 hits are safe. Audit it fully in its own report.
- **`SnapshotContext` + the Snapshot subsystem** is a shared, cross-module support subsystem (reached by 36 files across TimetableFoundation, SmartTimetable, SchoolSetup, StudentPortal, ParentPortal). It is treated as common/§4.2 infrastructure here, exactly as the RequirementConsolidationController report does (its `01-report.md:389`). Its usage by this controller is correct: every query is built **inside** the `run()`/`partition()` closure (R9), and the grammar is restored by `finally`.
- **`ActiveTeachers`** (`Modules\SchoolSetup`) is a service of a different module — common, used read-only.
- **`Pdf`, `Gate`, `Log`, `Str`, `View`, `Response`** are framework classes; `x-backend.layouts.app` and `x-backend.components.breadcrum` are shared components (the `breadcrum` spelling is the project's component name).

## 8. Not covered, and why

- **Runtime behaviour:** no browser and no test run (D4). Every finding is static or a read-only SQL/schema probe.
- **`_list.blade.php`** (58 lines) renders inside `TimetableFoundationController::reportsAndLogs()`; it is not reached by this controller, so it belongs to that controller's report. It shares `_report-body`, which **is** audited here.
- **The Snapshot subsystem internals** (`SnapshotContext`, `SnapshotQueryGrammar`, `SnapshotSchema`, `SnapshotTables`, `SnapshotWriter`, `SnapshotWriteGuard`): shared subsystem, not audited here (§5 / §7).
- **Data quality of the report's inputs** (`hrs_salary_assignments`, `tt_timetable_cells`, capabilities): the report is a read model; its correctness depends on those tables, which are outside this controller's scope.
