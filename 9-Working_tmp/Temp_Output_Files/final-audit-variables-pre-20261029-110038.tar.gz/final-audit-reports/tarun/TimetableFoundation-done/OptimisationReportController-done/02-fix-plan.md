# Fix Plan — TimetableFoundation / OptimisationReportController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick. *(No item below is `⚠ SHARED`.)*
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/OptimisationReportController.php`. It applies **only** ticked items, in this order.
> 5. No migration, no new permission key and no `glb_menus` edit is needed by any item here.

## 1. Blockers reachable today
_None._ The controller is read-only; there is no data-loss, security-hole or crash path on a normal user route.

## 2. Fixes that arm a latent defect (sequenced)
_None._ (The duplicated-logic item, OPT-07, is latent but is deferred with the service refactor in §9 — extracting it now would touch the same god class OPT-05 will split.)

## 3. Errors & transactions (F1/F2)
- [x] **OPT-01** · M · ERR-00 (D1) · `OptimisationReportController.php:71-83` — remove the `try/catch` around the `full()` build. Let the central handler in `bootstrap/app.php` log and render the failure. The `report($e)` call goes with it. The now-always-`null` `$optError` (and its `@if ($optError)` branch in the page) is left in place; it becomes dead and is recorded, not silently deleted. Effort: S.
- [x] **OPT-02** · M · ERR-00 (D1) / ERR-05 · `OptimisationReportController.php:118,142-146` — remove the `try/catch` around `downloadPdf()`. If the team prefers to keep a redirect-with-flash, the **only** acceptable D2 shape is a service method that does `report($e)` and returns a fixed message; never `Log::error(..., ['error' => $e->getMessage()])`. Recommended: drop the catch (central handler). Effort: S.
- [x] **OPT-03** · M · ERR-00 / ERR-05 · `SchoolOptimisationReportService.php:2837-2841` and `:880-886` — `schoolName()`: either remove the bare `catch (\Throwable)` (the table exists — 1 row on this tenant — so the failure is not expected) or add `report($e)` and a fixed message. `idleTeachers()`: keep `report($e)` and add the D2 comment naming ERR-01 and the date. Effort: S.

## 4. Authorization (F3)
- [x] **OPT-04** · L · DECISION · AUTH-01/AUTH-06 · `OptimisationReportController.php:42,63,99,153-162` — the salary pages (`full`, `fullPdf`) authorize on the literal role names `['Super Admin','School Admin']`; `pdf()` uses the permission `tenant.timetable-foundation.config.export` (declared and seeded). The scanner's AUTH-01 **B** hits are false positives (authorization is present via `abortUnlessSchoolAdmin()`).
      (a) ⭐ Gate `full()`/`fullPdf()` on `tenant.timetable-foundation.config.export` as well, and keep `abortUnlessSchoolAdmin()` as an additional role check. No new key, no `⚠ SHARED` edit — the permission already exists and is seeded (id 1450).
      (b) Keep the role-name gate; record as accepted.
      (c) Replace the role gate with a dedicated salary permission (new key → would be a separate permission/CONFIG decision).
      ➜ Choice: (a) — Tarun, 2026-10-13. Applied: full()/fullPdf() gate on config.export and keep the role check.

## 5. Validation, routes, models (F4/F5/F7)
_None._ Validation is a FormRequest using `validated()`; the three routes resolve with the full tenancy+auth chain; no Eloquent model is in scope.

## 6. Queries & performance (F9)
- [x] **OPT-08** · M · SVC-05 / QRY-12 · `SchoolOptimisationReportService.php` — resolve, once per `build()` and store on the instance, the lookups that are currently re-run: `classSectionNames()` (`:437,1865,2504,2556`), `capabilityIndex()` (`:594,944`), `classTeacherIds()` (`:614,970`), `optionKeys()` (`:606,973`), `windowLoads()` (`:605,972`), `teacherRows()` (`:436,890,1864,2195`), and `DB::table('sch_classes')->pluck('name','id')` (`:438,955,1866,2505`). This is request-scoped memoisation, **not** a cache — no cache key, no DECISION. Effort: M.

## 7. Views (F10)
_None._ No query in any in-scope blade; all eight compile; `{!! !!}` is used only on computed, escaped HTML.

## 8. Style (F12) — one item per file
- [x] **OPT-10** · L · STY-04 · `SchoolOptimisationReportService.php` — replace the `⚠` / `⛔` / box-drawing comment markers (16 scanner hits; e.g. `:37,40,44,316,936,1245,1365,1785,2487`) with plain English. Comments only; no behaviour change. Effort: S.

## 9. Deferred / decisions
- [ ] **OPT-05** · H · DECISION · CTL-01 · `SchoolOptimisationReportService.php` (2,871 lines, 45 methods) — split the god service?
      (a) ⭐ Defer to the split pass (D3). No code change in this pass; the file is frozen for refactor planning.
      (b) Split now, by report section (teachers / rooms / classes / schedule / coverage / skills / options / money).
      (c) Accept as is and record the debt.
      ➜ Choice: (a) defer to the split pass (D3) — Tarun, 2026-10-13. Not ticked; OPT-06 and OPT-07 deferred with it.
- [ ] **OPT-06** · H · CTL-02 · `SchoolOptimisationReportService.php` — extract the six >150-line methods (`teacherSection` 306, `freeingPlan` 292, `coverageSection` 286, `optionSection` 212, `classSection` 197, `skillSection` 187) and the four 80–150-line ones (`scheduleSection` 144, `build` 126, `roomSection` 108, `teachers` 101). This is the companion of OPT-05 and runs **inside** whatever OPT-05 chooses; if OPT-05 = (a) defer, this is deferred with it.
- [ ] **OPT-07** · M · SVC-04 · `SchoolOptimisationReportService.php:625-705` vs `:1003-1122` (handover planning), and `:2149` vs `:1800` (coverage) — two implementations of "can this teacher's lessons be handed over?" and two of "qualified teachers per subject". Extract each to one method so the report's sections cannot disagree. Deferred with OPT-05 (extraction touches the same class). Effort: M.
- [x] **OPT-09** · L · SVC-02 · `OptimisationReportController.php:78,120` · `SchoolOptimisationReportService.php:120` — inject `SnapshotContext` (already `scoped()`, `TimetableFoundationServiceProvider.php:111`) through the constructor instead of `app(SnapshotContext::class)` mid-method. Module-wide pattern; low priority. Effort: S.
