# Final Audit — TimetableFoundation / PeriodConfigController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/PeriodConfigController.php` (504 lines, 14 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 4 HIGH, 6 MEDIUM, 8 LOW.**

The controller's writes are structurally sound: every mutation runs in one `DB::transaction`, every
`activityLog()` sits after the write and inside it, and all 8 permission keys are seeded. But four
things break for a real user:

- **The Add-Timeslot button on the standalone list page is a dead link to a route that no longer
  exists** — opening `/timetable-foundation/period-config` with the `create` permission throws a
  500 (PCF-13).
- **Delete Permanently accepts a LIVE row and checks no children.** Every one of the 9 live period
  configs is referenced by `tt_period_set_periods_jnt` (27 rows, FK `NO ACTION`), so the delete
  either hard-deletes the row behind the trash or dies with error 1451 shown as a generic message
  (PCF-16).
- **Restore runs over a GET** — no CSRF protection (PCF-06).
- **Drag-to-reorder is N+1** — one SELECT and one UPDATE per row, plus one `exists` probe per id
  (PCF-11).

The worst of these is **PCF-13**: it is the only one that is guaranteed to 500 on a normal page
load, for the exact role that would use the page.

The effort is well under a day. Three DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 4 | 6 | 8 | 3 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PCF-01, PCF-02 | F8 Services/Jobs | clean: no service, no job, no event (`grep -nE "Service\|Job\|Event\|dispatch" $C` → none) |
| F2 Transactions/Audit | PCF-03 | F9 Queries/Perf | PCF-11, PCF-12 |
| F3 Authorization | PCF-04 | F10 Views | PCF-13, PCF-14 |
| F4 Validation | PCF-05 | F11 Security/Tenancy | clean: no `env()`, no PII, tenant middleware present |
| F5 Routes | PCF-06 | F12 Style | PCF-15 |
| F6 Controller shape | PCF-07, PCF-08, PCF-09 | F13 Deep read | PCF-16, PCF-17, PCF-18 |
| F7 Models | PCF-10 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/PeriodConfigController.php` | controller | 504 | this report | ✅ whole class |
| 2 | `app/Models/PeriodConfig.php` | model | 82 | **this report** (pre-assigned) | ✅ |
| 3 | `app/Policies/PeriodConfigPolicy.php` | policy | 44 | this report | ✅ — unreachable, see §7 |
| 4 | `routes/web.php` lines 211-219 | routes | — | this report | ✅ ⚠ SHARED file |
| 5 | `database/migrations/tenant/2026_06_16_152617_create_tt_period_config_table.php` | migration | 59 | this report | ✅ read-only (DDL match) |
| 6 | `views/period-config/index.blade.php` | page | 73 | this report | ✅ |
| 7 | `views/period-config/show.blade.php` | page | 30 | this report | ✅ |
| 8 | `views/period-config/edit.blade.php` | page | 177 | this report | ✅ |
| 9 | `views/period-config/trash.blade.php` | page | 64 | this report | ✅ |
| 10 | `views/period-config/create.blade.php` | page (orphan) | 169 | this report | ✅ — see PCF-14 |
| 11 | `views/period-config/_create-modal.blade.php` | modal | 22 | masters page (TimetableFoundationController) | ↗ linked — route/permission contract checked |
| 12 | `views/period-config/_create-fields.blade.php` | fields partial | 163 | this report / masters page | ✅ usage checked |
| 13 | `views/pages/partials/timetable-masters/period-configs/_list.blade.php` | tab list | 642 | masters page (TimetableFoundationController) | ↗ linked — AJAX/permission contract checked |
| 14 | `app/Models/SchoolShift.php` | other-controller model | 44 | [SchoolShiftController](../SchoolShiftController-done/01-report.md) | ↗ linked — usage checked |
| 15 | `app/Models/PeriodType.php` | other-controller model | ~100 | [PeriodTypeController](../PeriodTypeController-done/01-report.md) | ↗ linked — usage checked |
| 16 | `app/Models/PeriodSetPeriod.php` | other-controller model | — | [PeriodSetPeriodController](../PeriodSetPeriodController-done/01-report.md) | ↗ linked — relation checked |
| — | `x-backend.layouts.app`, `breadcrum`, `table.status-switch`, `table.action`, `table.action-trashed`, `form.status-switch`, `form.button-submit`, `tenantcore::export-buttons` | shared components | — | common | props checked against call sites only |

**Pre-applied 2026-10-10:** `PeriodConfigController` is **not** listed in
`../PRE-APPLIED-2026-10-10.md`. Nothing was applied to it in that pass; every finding below is
pre-existing. (The file is dated 2026-08-08 for its latest content changes.)

## 4. Routes

```
GET|HEAD  timetable-foundation/period-config                                     timetable-foundation.period-config.index         index
POST      timetable-foundation/period-config                                     timetable-foundation.period-config.store         store
POST      timetable-foundation/period-config/ajax/reorder                        timetable-foundation.period-config.ajaxReorder   ajaxReorder
GET|HEAD  timetable-foundation/period-config/trash/view                          timetable-foundation.period-config.trashed       trashedPeriodConfig
DELETE    timetable-foundation/period-config/{id}/force-delete                   timetable-foundation.period-config.forceDelete   forceDelete
GET|HEAD  timetable-foundation/period-config/{id}/restore                        timetable-foundation.period-config.restore       restore   ← GET
GET|HEAD  timetable-foundation/period-config/{period_config}                     timetable-foundation.period-config.show          show
PUT|PATCH timetable-foundation/period-config/{period_config}                     timetable-foundation.period-config.update        update
DELETE    timetable-foundation/period-config/{period_config}                     timetable-foundation.period-config.destroy       destroy
POST      timetable-foundation/period-config/{period_config}/ajax-can-be-free    timetable-foundation.period-config.ajaxToggleCanBeFree ajaxToggleCanBeFree
POST      timetable-foundation/period-config/{period_config}/ajax-times          timetable-foundation.period-config.ajaxUpdateTimes ajaxUpdateTimes
GET|HEAD  timetable-foundation/period-config/{period_config}/edit                timetable-foundation.period-config.edit          edit
POST      timetable-foundation/period-config/{period_config}/toggle-status       timetable-foundation.period-config.toggleStatus  toggleStatus
```

Evidence: `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` filtered for
`PeriodConfigController@` → 13 routes above.
Middleware (module provider, every route):
`web, InitializeTenancyByDomain, PreventAccessFromCentralDomains, EnsureTenantIsActive,
EnsureTenantHasModule:TimetableFoundation, auth, verified` — tenant context present ✅.

**Unrouted public method:** `create` (line 36). Its body is `abort(403, '…')` under a `// NOT
ROUTED — TM-05` comment, and `routes/web.php:219` registers the resource with `->except(['create'])`.
This is the D5 shape — compliant, not a finding. Note `Route::has('…period-config.create')` is
therefore `false` (PCF-13).

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (read) | PCF-12, PCF-13, PCF-14 |
| create | ❌ D5 | — | — | — | — | clean (D5) |
| store | ✅ | create | ✅ closure (71) | `Stored` | tt_period_configs, sys_activity_logs | PCF-01, 02, 04, 05, 07, 08 |
| show | ✅ | view | — | — | — (read) | PCF-07 |
| edit | ✅ | update | — | — | — (read) | PCF-07 |
| update | ✅ | update | ✅ closure (131) | `Updated` | tt_period_configs, sys_activity_logs | PCF-01, 02, 04, 05, 07, 08 |
| destroy | ✅ | delete | ✅ closure (161) | `Trashed` | tt_period_configs, sys_activity_logs | PCF-01, 02, 03, 17 |
| restore | ✅ GET | restore | ✅ closure (195) | `Restored` | tt_period_configs, sys_activity_logs | PCF-01, 02, 03, 06 |
| trashedPeriodConfig | ✅ | restore | — | — | — (read) | PCF-12 |
| forceDelete | ✅ | forceDelete | ✅ closure (237) | `Deleted` | tt_period_configs, sys_activity_logs | PCF-01, 02, 03, 16 |
| toggleStatus | ✅ | update | ✅ closure (276) | `Toggled` | tt_period_configs, sys_activity_logs | PCF-01 |
| ajaxToggleCanBeFree | ✅ | update | ✅ closure (326) | `Toggled` | tt_period_configs, sys_activity_logs | PCF-01 |
| ajaxUpdateTimes | ✅ | update | ✅ closure (363) | `Updated` | tt_period_configs, sys_activity_logs | PCF-01, 02, 04, 05 |
| ajaxReorder | ✅ | update | ✅ closure (426) | `Reordered` | tt_period_configs, sys_activity_logs | PCF-01, 02, 04, 05, 11, 18 |

**Tables each mutation SHOULD touch (F2 / §0.1):**
- `store` / `update`: the config row **plus** the audit row → both do, in one transaction ✅.
- `destroy` / `restore` / `forceDelete`: the config row (or its `deleted_at` / hard DELETE) **plus**
  the audit row; `forceDelete` **must first consult** `tt_period_set_periods_jnt` (FK `NO ACTION`) —
  it does not (PCF-16).
- `ajaxReorder`: N config rows (`display_order` only) plus one audit row per changed row — inside
  one transaction ✅, but query-per-row (PCF-11).

## 6. Findings

### F1 — Errors
#### PCF-01 · M · ERR-00 (D1) — nine methods still wrap their body in a controller `try/catch`
**Where:** `PeriodConfigController.php:48, 115, 160, 194, 236, 275, 325, 352, 395`
```php
try {
    …
} catch (AuthorizationException|ValidationException|HttpExceptionInterface $e) {
    throw $e;   // 403 / 422 / abort() must not become a generic 500
} catch (\Throwable $e) {
    Log::error('PeriodConfigController::store failed', ['error' => $e->getMessage()]);
    return back()->with('error', 'The operation could not be completed.');
}
```
**Evidence:** `grep -nE 'try \{|\} catch' $C` → 9 `try` blocks. `PeriodConfigController` is **not** in
`PRE-APPLIED-2026-10-10.md`, so the D1 conversion did not reach it. Methods: `store`, `update`,
`destroy`, `restore`, `forceDelete`, `toggleStatus`, `ajaxToggleCanBeFree`, `ajaxUpdateTimes`,
`ajaxReorder`.
**Consequence:** the controller uses two error models at once; under D1 the central renderer in
`bootstrap/app.php` should own this, and every catch is a place for the ERR-02 class of bug to
reappear. No user-facing exception text leaks today (ERR-01 clean), but the stack is not recorded.

#### PCF-02 · M · ERR-05 — the catch logs `getMessage()` instead of the exception object
**Where:** `PeriodConfigController.php:87, 150, 184, 213, 253, 384, 456`
```php
Log::error('PeriodConfigController::store failed', ['error' => $e->getMessage()]);
```
**Evidence:** `grep -n 'getMessage()' $C` → 7 hits, all inside `Log::error(...)` context arrays;
`grep -n 'report($e)' $C` → 0.
**Consequence:** the trace is discarded, so a production write failure cannot be diagnosed; ERR-05
requires `report($e)` or `['exception' => $e]`.

### F2 — Transactions and audit
#### PCF-03 · L · TXN-05 — the redirect and flash are built inside the transaction closure
**Where:** `PeriodConfigController.php:174-176` (destroy), `203-205` (restore), `243-245` (forceDelete)
```php
return DB::transaction(function () use ($id) {
    …
    return redirect()->route('timetable-foundation.period-config.trashed')
        ->with('success', flash('trashed.period_config'));   // built before commit
});
```
**Evidence:** `grep -n 'HTTP response built inside DB::transaction closure' /tmp/fa-pcf.json` →
3 hits (scanner rows for destroy/restore/forceDelete). `store`/`update` return the redirect after
the closure ✅.
**Consequence:** the success flash reaches the session before the commit; if the commit itself fails,
the next page shows "…was trashed successfully" for a row that is not trashed.

### F3 — Authorization
#### PCF-04 · L · AUTH-02 — `Gate::authorize` sits inside the try block in four methods
**Where:** `PeriodConfigController.php:49` (store), `116` (update), `353` (ajaxUpdateTimes), `396` (ajaxReorder)
**Evidence:** scanner `AUTH-02` rows at those lines; each method also has an explicit
`catch (AuthorizationException …) { throw $e; }`, so the 403 is preserved at runtime.
**Consequence:** none today — the rethrow keeps the 403. It is a latent trap (remove the rethrow and
an authorization failure becomes a redirect) and disappears with PCF-01.

**F3 clean checks:** all 13 routed methods call `Gate::authorize` before loading any record; the 8
permission names (`viewAny, view, create, update, delete, restore, forceDelete, export`) are declared
in `config/permissionslist.php:703` and seeded exactly in `sys_permissions` (probe below). No
FormRequest, so no duplicate authorization (AUTH-04 not present). No per-user data, so AUTH-03 n/a.
```
grep -n "timetable-foundation.period-config" config/permissionslist.php
703: 'timetable-foundation.period-config' => array_merge($crud, ['export']),
tenant sys_permissions WHERE name LIKE '%period-config%' → count=8 (create, delete, export,
  forceDelete, restore, update, view, viewAny)
```

### F4 — Validation and input
#### PCF-05 · M · VAL-02 / VAL-07 — no FormRequest; validation and a business rule live in the controller
**Where:** `PeriodConfigController.php:465-503` (`validatePayload`, used by `store:51`/`update:118`),
`:355-358` (ajaxUpdateTimes), `:398-408` (ajaxReorder); business rule at `:58-61`, `:125-128`
```php
return $request->validate([
    'shift_id' => ['required', 'integer', 'exists:tt_shifts,id'],
    …
    'code' => ['required', 'string', 'max:20', Rule::unique('tt_period_configs', 'code')…],
]);
```
**Evidence:** `find Modules -name 'PeriodConfigRequest.php'` → nothing. The only FormRequest named in
the file is a comment reference to `SchoolShiftRequest` (line 480).
**Consequence:** the project rule (validation in a FormRequest) is unmet; the same rules have to be
re-declared for any future import/bulk writer, and the "non-teaching ⇒ slot_ord null / can_be_free
false" rule sits in the controller where no request-level test can see it. Uniqueness itself **is**
correct (matches the unconditional `uq_pc_shift_code` / `uq_pc_shift_ord`; VAL-04 clean). The two
single-field AJAX toggles (`toggleStatus:263`, `ajaxToggleCanBeFree:304`) are the allowed exception.

**F4 clean checks:** no `$request->all()` / `except()` into a model (VAL-01 clean); optional fields
read with `?? null`/`sometimes` (VAL-03 clean); every field typed (VAL-05 clean); no uploads
(VAL-06 n/a).

### F5 — Routes
#### PCF-06 · H · RTE-01 — Restore runs over a GET request
**Where:** `routes/web.php:216`
```php
Route::get('/period-config/{id}/restore', [PeriodConfigController::class, 'restore'])->name('period-config.restore');
```
**Evidence:** `route:list` shows `GET|HEAD …/{id}/restore`. The only caller is
`trash.blade.php:46` via `<x-backend.table.action-trashed>`, which derives the HTTP verb from the
route, so a verb change needs no blade edit.
**Consequence:** a link prefetch or browser prefetch can restore a trashed timeslot with no CSRF
token and no user intent.

**F5 clean checks:** every route points at a method that exists (RTE-02 clean); custom routes at
`web.php:212-218` are registered **before** `Route::resource` at `:219` (RTE-06 clean); the `create`
verb is excluded and its method is `abort(403)` (RTE-03/D5 clean).

### F6 — Controller shape
#### PCF-07 · M · CTL-03 — five methods use `$id` + `findOrFail` instead of route model binding
**Where:** `show:93,97` · `edit:102,106` · `destroy:156,162` · `restore:190,196` · `forceDelete:232,238`
```php
public function show($id) {
    Gate::authorize('tenant.timetable-foundation.period-config.view');
    $periodConfig = PeriodConfig::with(['shift', 'periodType'])->findOrFail($id);
```
**Evidence:** `grep -nE 'public function [a-zA-Z_]+' $C` shows `show($id)`, `edit($id)`,
`destroy($id)`, `restore($id)`, `forceDelete($id)`; the `destroy` route parameter is
`{period_config}` (`route:list`) while the method argument is `$id` — a name mismatch that only
works because the argument is untyped. `update`, `toggleStatus`, `ajaxToggleCanBeFree`,
`ajaxUpdateTimes` do bind (`PeriodConfig $periodConfig`, `{period_config}`) ✅.
**Consequence:** no implicit binding; trashed routes cannot use `->withTrashed()` binding, and each
method hand-loads a record where a `PeriodConfig $periodConfig` parameter would do it.

#### PCF-08 · M · CTL-05 — `store()` and `update()` duplicate the same 30-line block
**Where:** `PeriodConfigController.php:46-91` vs `113-154`
**Evidence:** both call `validatePayload()`, set the same three booleans (`53-55` / `120-122`), run
the same non-teaching rule (`58-61` / `125-128`), and open the same transaction; only the redirect
target and event differ. `grep -n 'is_teaching_slot' $C` → the pair repeats.
**Consequence:** the two paths can drift (they already differ in redirect anchoring); a fix to one
(e.g. a new business rule) can silently miss the other.

#### PCF-09 · L · CTL-04 — eleven public methods have no return type
**Where:** `index:24, create:36, store:46, show:93, edit:102, update:113, destroy:156, restore:190,
trashedPeriodConfig:219, forceDelete:232, toggleStatus:259`
**Evidence:** `grep -nE 'public function .*\): ' $C` → only the three AJAX endpoints declare
`: JsonResponse`.
**Consequence:** return types are not machine-checked; a returned `back()` where a `View` is expected
would only surface at runtime.

### F7 — Models
#### PCF-10 · L · MDL-02 — TIME columns are cast as `datetime`, and `$guarded` is redundant
**Where:** `PeriodConfig.php:31, 38-39`
```php
protected $guarded = ['duration_minutes'];
'start_time' => 'datetime:H:i:s',
'end_time'   => 'datetime:H:i:s',
```
**Evidence:** `SHOW CREATE TABLE tt_period_configs` → `start_time time NOT NULL`, `end_time time NOT
NULL`; live `MIN(start_time)=08:20:00, MAX(end_time)=13:50:00`. `$fillable` is non-empty, so
`$guarded` is ignored by Eloquent.
**Consequence:** works today because every stored TIME is ≤ 23:59 and accessors only read `H:i`; a
hand-inserted TIME above 23:59:59 would make `Carbon::parse()` throw on display. `$guarded` gives a
false sense of protection alongside `$fillable`.

**F7 clean checks:** `$fillable` declared with nothing sensitive (MDL-01 clean); `$casts` cover every
boolean/int (MDL-02 mostly clean); `$table='tt_period_configs'` exists in the migration (MDL-07
clean); `SoftDeletes` present and `deleted_at` exists (clean); relations survive exact equality
(`PeriodConfig::find(1)->shift`, `->periodType`, `->periodSetPeriods()->count()` → 4 — proven in
tinker); relationships are return-typed; no `belongsToMany` (MDL-03 n/a); no `InteractsWithMedia`
(MDL-05 n/a); `scopeOrdered()` is used by `PeriodSetPeriodController` and `PeriodSetController`
(not dead).

### F8 — Services and jobs
clean — the controller names no Service/Job/Event/Mail; `grep -nE 'Service|Job|Event|dispatch'
$C` → none.

### F9 — Queries and performance
#### PCF-11 · H · QRY-01 — drag-to-reorder issues one SELECT and one UPDATE per row, inside a loop
**Where:** `PeriodConfigController.php:427-449`
```php
foreach ($validated['ids'] as $displayPos => $id) {
    $config = PeriodConfig::find($id);                         // SELECT per row
    if ($config === null || (int) $config->display_order === $newOrder) { continue; }
    DB::table('tt_period_configs')->where('id', $id)->update([…]);   // UPDATE per row
    activityLog($config, 'Reordered', […]);
}
```
**Evidence:** scanner rows `QRY-01 @430` (`PeriodConfig::find()` inside a loop) and `QRY-01 @437`
(`DB::table()` inside a loop). The `ids.*` `exists:tt_period_configs,id` rule at `:400` also runs one
query per id.
**Consequence:** a 25-row drag fires ~50 (reorder) + 25 (validation) queries; on a large grid the
endpoint is slow and holds an open transaction for the whole burst.

#### PCF-12 · L · QRY-02 / C12 — lists paginate at 25, not the house 10
**Where:** `PeriodConfigController.php:31` (index), `:227` (trashed)
```php
->paginate(25);
```
**Evidence:** `grep -n 'paginate(' $C` → both 25. The masters tab (another controller) uses
`paginate($perPage, ['*'], 'pc_page')`, a distinct page name; these two standalone pages use the
default `page`.
**Consequence:** longer pages than the module standard; no functional break, but the standalone list
and the tab list page differently.

### F10 — Views
#### PCF-13 · H · RTE (dangling route reference) / VIEW — the list page links to the retired `create` route and 500s
**Where:** `views/period-config/index.blade.php:10-14`
```blade
@can('tenant.timetable-foundation.period-config.create')
    <a href="{{ route('timetable-foundation.period-config.create') }}" class="btn btn-primary btn-sm">
        Add Timeslot
    </a>
@endcan
```
**Evidence:**
```text
$ php artisan tinker --execute 'echo Route::has("timetable-foundation.period-config.create")?"true":"false";'
false
$ … route("timetable-foundation.period-config.create")
Symfony\Component\Routing\Exception\RouteNotFoundException: Route [timetable-foundation.period-config.create] not defined.
```
The route is excluded at `routes/web.php:219` (`->except(['create'])`); the anchor has **no**
`Route::has()` guard. (The AcademicTermController report's `show.blade.php` link to
`timetable.validation` is the same class of defect but is guarded — this one is not.)
**Consequence:** any user holding `.period-config.create` who opens
`GET /timetable-foundation/period-config` gets a 500 instead of the list. The `_list.blade.php` tab
uses the modal (`createModal="#createPeriodConfigModal"`), so this page is the only broken surface.

#### PCF-14 · L · CTL-10 / VIEW — an orphan create page, an unlinked index, and empty breadcrumbs
**Where:** `views/period-config/create.blade.php` (169 lines); `index.blade.php:2`, `show.blade.php:2`,
`edit.blade.php:2`, `trash.blade.php:2`
**Evidence:**
- `create.blade.php` posts to `period-config.store` and reads `$shifts`/`$periodTypes`, but `create()`
  is `abort(403)` and the route is excluded — the file is unreachable. `_create-modal.blade.php`
  (line 1) and `_create-fields.blade.php` (line 2) both say they were converted **from**
  `create.blade.php`.
- `grep -rn 'period-config.index' Modules/ resources/` → only the controller itself; `glb_menus` has
  no `period-config` entry. The standalone index is routed but linked from nowhere.
- All four pages pass `:links="[]"` to `x-backend.components.breadcrum` — no trail is resolved.
**Consequence:** dead UI files drift from the live modal and mislead the next developer; the
breadcrumb standard (`breadcrumb-standard.md`) is unmet.

**F10 clean checks:** no `Model::`/`DB::`/`->get()` inside the four rendered blades (VIEW-01 clean);
`shift`/`periodType` are eager-loaded by the controller, so `optional($pc->shift)->…` is not N+1
(VIEW-02 clean); no `{!! !!}` anywhere in `period-config/` (VIEW-03 clean); row actions use
`x-backend.table.action` / `action-trashed`; all six blades compile (`Blade::compileString` → `php
-l` → OK).

### F11 — Security and tenancy
clean — `grep -n 'env(' $C $M` → none; no JSON returns a whole model with PII; no hard-coded user/
tenant ids (`?? 1` at `ajaxReorder:410` is a display-order offset, not an id); no secrets logged;
tenant middleware present on every route.

### F12 — Style
#### PCF-15 · L · STY-01/02/04 — style debt across controller, model and policy
**Where:** `PeriodConfigController.php:1-20, 270` · `PeriodConfig.php:1` · `PeriodConfigPolicy.php:1`
**Evidence:**
- `strict_types` missing on all three (`scanner STY-01` at each file line 1).
- Emoji marker in a comment: `PeriodConfigController.php:270` `// ⛔ The JSON key here stays 'success'…`
  (`scanner STY-04`).
- Imports are split by stray blank lines (`:5-20`), so Pint would re-sort; the model's
  `scopeOrdered($query)` has no `: Builder` return type.
**Consequence:** consistency only; no runtime effect. (Reported as one plan item per file, per F12.)

### F13 — Deep read
#### PCF-16 · H · deep read — Delete Permanently accepts a LIVE row and checks no children
**Where:** `PeriodConfigController.php:238`
```php
$periodConfig = PeriodConfig::withTrashed()->findOrFail($id);   // a LIVE id is accepted
$periodConfig->forceDelete();
```
**Evidence:**
- `withTrashed()` matches live rows, so a crafted `DELETE /period-config/1/force-delete` skips the
  trash entirely.
- No child guard. The only FK child of `tt_period_configs` is
  `tt_period_set_periods_jnt.period_config_id`, delete rule **NO ACTION**; it holds **27 rows**
  across **all 9 live configs** (probe: `GROUP BY period_config_id` → pc 1-9, 1-4 rows each).
**Consequence:**
- A referenced row (all of them today) fails with error **1451**, shown as the generic "The operation
  could not be completed." — the user cannot act on it.
- An unreferenced live row is **hard-deleted** with no trash step and no warning.

#### PCF-17 · M · deep read — `destroy()` soft-deletes a config that period sets still reference
**Where:** `PeriodConfigController.php:161-167`
```php
$periodConfig = PeriodConfig::findOrFail($id);
$periodConfig->is_active = false;
$periodConfig->save();
$periodConfig->delete();          // soft delete — 27 jnt rows keep pointing at it
```
**Evidence:** `tt_period_set_periods_jnt` holds 27 rows referencing the 9 configs; soft delete does
not cascade, and `PeriodConfig`'s default `SoftDeletes` scope then hides the row from
`PeriodSetPeriod`'s `periodConfig` relation.
**Consequence:** trashing a config in use silently blanks it inside every period set that used it,
with no warning; the period-set screens show a missing period until someone restores it.

#### PCF-18 · L · TXN-06 / QRY-10 — reorder is a check-then-act with no lock; `start_at` defaults to 1
**Where:** `PeriodConfigController.php:410, 430-440`
```php
$startAt = (int) ($validated['start_at'] ?? 1);
…
if ($config === null || (int) $config->display_order === $newOrder) { continue; }
DB::table('tt_period_configs')->where('id', $id)->update(['display_order' => $newOrder, …]);
```
**Evidence:** no `lockForUpdate()`; the blade always sends `start_at` (`_list.blade.php:298`), but the
endpoint defaults to 1 when it is absent.
**Consequence:** two concurrent drags can interleave and leave duplicate `display_order` values; any
caller that omits `start_at` rewrites numbers from 1, overwriting page-1 ordering.

**F13 clean checks:** no message lies (all `flash()` keys use `.period_config`, which `flash()`
renders as "Period Config" ✅); no dead write path; `restore()` correctly re-activates
(`is_active = true`, `:198`) — the opposite of the AcademicTermController's ATC-07.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`PeriodConfigPolicy` is unreachable.** Registered at
  `TimetableFoundationServiceProvider.php:129` (`Gate::policy(PeriodConfig::class, PeriodConfigPolicy::class)`),
  but every guard passes a permission **string** to `Gate::authorize`, which never consults the
  policy. Same module-wide pattern as ATC-14 / PTC-215; needs one module-level decision.
- **`_list.blade.php` (642 lines) is owned by the TimetableFoundationController masters page.**
  Its AJAX contract with this controller was checked and is consistent: `ajaxReorder` →
  `data.status` (`:302`), `ajaxUpdateTimes` → `data.status` (`:376`), `ajaxToggleCanBeFree` →
  `data.status` (`:465`, normalised 2026-08-08), `toggleStatus` → `response.success` via the shared
  status-switch component. The `$periodConfigs` query (a `pc_page` paginator at
  `TimetableFoundationController.php:514-523`) belongs to that controller's report.
- **`SchoolShift`, `PeriodType`, `PeriodSetPeriod`** are audited by their own controller reports;
  here only *how this controller uses them* was checked (`edit()` dropdowns load only active rows;
  relations resolve).
- **Shared components** (`x-backend.table.action`, `action-trashed`, `status-switch`,
  `tab.search-bar`, `tenantcore::export-buttons`) were checked against their call-site props only —
  their internals are common and out of scope.

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static or a read-only SQL
  probe.
- **`_create-modal.blade.php` / `_create-fields.blade.php` internals:** rendered by the masters-tab
  controller; only their route/permission contract was verified here.
- **Other writers of `tt_period_configs`:** seeders, importers and `PeriodSetController` were not
  audited. PCF-16/PCF-17's risk partly comes from them.
- **`tt_period_set_periods_jnt` schema:** owned by the PeriodSetPeriodController report; only its FK
  delete rule and row counts were measured here.
- **A migration to rebuild anything:** none is proposed; the schema matches its DDL (`duration_minutes`
  is the generated column the DDL specifies).
