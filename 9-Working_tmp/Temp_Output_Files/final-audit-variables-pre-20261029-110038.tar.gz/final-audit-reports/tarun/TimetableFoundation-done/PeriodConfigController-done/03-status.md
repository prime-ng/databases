# Status — TimetableFoundation / PeriodConfigController

**Fixed:** 2026-10-13 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — 19 items ticked, 4 decisions filled. Nothing left open in the plan.
**Fixed together with:** `PeriodSetController-done` and `PeriodSetPeriodController-done` (one pass — the three share tables, routes and the masters page).

---

## 1. Pre-applied work

None. `PRE-APPLIED-2026-10-10.md` lists no file in this controller's scope.

---

## 2. Applied

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| PCF-16 | `PeriodConfigController.php` `forceDelete()` | Uses `onlyTrashed()->findOrFail()`, so a live row gets a 404. If `tt_period_set_periods_jnt` still references the timeslot, it throws a `DomainException` that names the sets and the count. Before, MySQL raised 1451 and the user saw a generic message. | rolled-back kernel replay | refused, message names the sets |
| PCF-17 (a) | same, `destroy()` | Refuses to trash a timeslot that any period set uses, naming the sets. Unused timeslots can still be trashed. | rolled-back replay on a used timeslot | refused, names **4 sets** |
| PCF-01, PCF-02 | controller | No try/catch left except two `catch (DomainException)` blocks (D2), in `destroy()` and `forceDelete()`. There is no `['error' => $e->getMessage()]` logging any more; the central handler logs. | `grep -c 'catch ('` / `getMessage` | 2 / 2 (both inside the D2 catches) |
| PCF-03 | `store/update/destroy/restore/forceDelete` | Each closure returns the model. The redirect is built after the transaction. | read | — |
| PCF-04 | 13 `Gate::authorize` calls | Every gate runs before the first record load. | `grep -c Gate::authorize` | 13 |
| PCF-05 (a) | `Http/Requests/PeriodConfigRequest.php` (new) | Holds the store and update rules. `authorize()` uses `authorizeByCrudPermission('tenant.timetable-foundation.period-config')`. The "non-teaching ⇒ slot_ord null, can_be_free false" rule is applied to the validated array, because a merge in `passedValidation()` never reaches `validated()`. | `class_exists` | OK |
| PCF-06 (a) | `routes/web.php:225` | Restore is `Route::patch`. `action-trashed` reads the verb from the route, so no blade edit was needed. | `route:list --path=period-config` | `PATCH …/{id}/restore` |
| PCF-07 | `show/edit/update/destroy` | Use route model binding. `restore` and `forceDelete` keep `{id}` + `onlyTrashed()`, because a trashed row cannot bind implicitly. | reflection over the routes | all bound |
| PCF-10 | `Models/PeriodConfig.php` | Dropped the redundant `$guarded = ['duration_minutes']`. | `grep guarded` | comment only |
| PCF-11, PCF-18 | `ajaxReorder()` | Reads the rows once with `whereIn(...)->lockForUpdate()->get()->keyBy('id')`, inside the transaction. Before, it ran one query per row. | rolled-back replay (`ids` + `start_at`) | reorder OK |
| PCF-12 | `index()` / `trashedPeriodConfig()` | Both paginate 10, with page names `pc_page` and `pc_trash_page`. | `grep paginate` | 2 × 10 |
| PCF-13 | `period-config/index.blade.php:10-14` | "Add Timeslot" linked to `period-config.create`, a route that does not exist (500). It now links to the masters tab, where the Add dialog lives, inside `@can(...create)`. | blade compile + render | 200 |
| PCF-14a | `period-config/create.blade.php` | Deleted after proving nothing renders it (`routed=0 refs=0`). `create()` is now `abort(403)` with a `NOT ROUTED` comment (D5). | `grep -rn period-config.create` | comments only |
| PCF-14b (a) | `config/breadcrumbs.php:944-948` | index/edit/show/create/trashed now parent to the masters page on tab `period-configs`. | resolver | Home / … / Timetable Masters / Period Configs / … |
| PCF-15a/b/c | controller, model, policy | `strict_types` added to all three. Return types on every public method. `scopeOrdered(): Builder`. The `⛔` emoji comment was removed. | `php -l` + Pint | OK |

Event literals kept: `Stored` · `Updated` · `Trashed` · `Restored` · `Deleted` · `Toggled` · `Reordered`.

---

## 3. Not applied

| ID | Why |
|---|---|
| Policy unreachable | Module-wide decision (gates pass strings, ATC-14). Not a per-controller fix. |
| CTL-01 split | Not needed. 444 lines, under the threshold. |

---

## 4. Needs Tarun's hand

1. **Run the Dusk suites** for the masters page; I did not run them (D4, one Dusk port). Two existing tests hit retired pages; see §5.
2. **Browser check** of `?tab=period-configs`:
   - trash a timeslot used by a set, and expect a refusal that names the sets;
   - trash an unused one, then restore it from the trash page (now a PATCH);
   - drag-reorder.
3. No migration and no permission sync are needed.

---

## 5. Unverifiable by this workflow (D4), and notes

- **No tests were run.** Verification was static, plus a kernel replay inside a rolled-back transaction.
- The new `trashWarning` prop on the shared `x-backend.table.action` component is additive: with no prop, the output is unchanged. Proof: 389 blades that use the component compiled clean. It is used by the period-sets list (see `PeriodSetController-done/03-status.md`).
- Cross-module: SmartTimetable views still link a few period routes that this pass retired. They are listed once, in `PeriodSetController-done/03-status.md` §5.

---

## 6. Verification log

```
php -l (controller, request, model, policy, routes)   → No syntax errors
class_exists: controller, PeriodConfigRequest, model  → OK
route:list (uncached) — every routed action exists     → 36 actions across the 3 controllers, 0 missing
blade compile: period-config/{index,edit,show,trash}, _create-* → OK, comment delimiters balanced
kernel replay (rolled back, tenant test.localhost):
  masters ?tab=period-configs                          → 200
  trash a used timeslot                                → refused, names 4 sets, nothing written
  ajaxReorder                                          → OK
  after rollback                                       → counts unchanged
Pint on touched files                                  → passed; php -l re-run → OK
```

---

## 7. Final state

**Status: FIXED** (2026-10-13). There are no open items in the plan. The policy question is the module-wide decision.
