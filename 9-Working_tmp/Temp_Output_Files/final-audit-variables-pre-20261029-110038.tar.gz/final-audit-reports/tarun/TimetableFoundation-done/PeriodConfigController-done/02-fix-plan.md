# Fix Plan — TimetableFoundation / PeriodConfigController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/PeriodConfigController.php`.
>    It applies **only** ticked items, in this order.
> 5. ⚠ `PeriodConfigController` was **not** part of the 2026-10-10 pre-applied pass — every item is
>    net-new work.

## 1. Blockers reachable today
_None. (B = 0.)_

## 2. Fixes that arm a latent defect (sequenced)
- [x] **PCF-16** · H · deep read · `PeriodConfigController.php:238` — `forceDelete()`:
  - Use `onlyTrashed()->findOrFail($id)` so a LIVE row can no longer be purged behind the trash.
  - Before deleting, count children in `tt_period_set_periods_jnt.period_config_id`. If any exist,
    refuse with a `\DomainException` naming the period sets and the count, instead of letting MySQL
    raise 1451 shown as "The operation could not be completed."

  Order matters: this goes **before** PCF-17. Effort: S.

## 3. Errors & transactions (F1/F2)
- [x] **PCF-01** · M · ERR-00 (D1) · `PeriodConfigController.php:48, 115, 160, 194, 236, 275, 325, 352, 395` —
  remove the controller try/catch from all nine methods and let the central handler in
  `bootstrap/app.php` render errors (JSON for the AJAX endpoints, redirect for the form endpoints).
  Keep every existing flash message and `activityLog()` event literal. If a `\DomainException` is
  introduced by PCF-16, catch **only** `\DomainException` and keep its fixed message. Effort: M.
- [x] **PCF-02** · M · ERR-05 · `PeriodConfigController.php:87, 150, 184, 213, 253, 384, 456` — replace
  `['error' => $e->getMessage()]` with `report($e)` (or `['exception' => $e]`). Usually absorbed by
  PCF-01 when the catches are removed; do it explicitly on any catch that survives. Effort: S.
- [x] **PCF-03** · L · TXN-05 · `PeriodConfigController.php:161-178, 195-207, 237-247` — each closure
  returns the model; build the `redirect()->route(...)->with('success', …)` **after** the transaction.
  Effort: S.

## 4. Authorization (F3)
- [x] **PCF-04** · L · AUTH-02 · `PeriodConfigController.php:49, 116, 353, 396` — with PCF-01 applied,
  `Gate::authorize` naturally sits outside any try. Verify it still runs **before** the first record
  load; no other change. Effort: XS.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **PCF-05** · M · DECISION · VAL-02/VAL-07 — extract validation into a FormRequest?
      (a) ⭐ Create `Modules/TimetableFoundation/app/Http/Requests/PeriodConfigRequest.php` holding
          the rules from `validatePayload()` (`authorizeByCrudPermission('tenant.timetable-foundation.period-config')`),
          move the "non-teaching ⇒ slot_ord null / can_be_free false" rule into its `passedValidation()`
          or the controller's post-validate block, and type-hint it in `store`/`update`.
      (b) Keep `validatePayload()` where it is and defer the extraction (the AJAX endpoints' inline
          `validate()` stays for the single-field toggles, moves for the two-field/time editors).
      (c) Leave validation as is and record it as accepted.
      ➜ Choice: (a) — new `PeriodConfigRequest` (Tarun, 2026-10-13)
- [x] **PCF-06** · H · DECISION · RTE-01 · `routes/web.php:216` — Restore runs over GET.
      (a) ⭐ Change it to `Route::patch`. `action-trashed` derives the verb from the route, so no blade
          edit is needed; the only caller is `trash.blade.php:46`. ⚠ This touches a route file and
          changes the verb, so it needs explicit approval.
      (b) Leave it as GET and accept the CSRF exposure.
      ➜ Choice: (a) — `Route::patch` (Tarun, 2026-10-13)
- [x] **PCF-07** · M · CTL-03 · `PeriodConfigController.php:93, 102, 156, 190, 232` — convert `show`,
  `edit`, `destroy` to `PeriodConfig $periodConfig` binding, and `restore`/`forceDelete` to
  `->withTrashed()` binding (`{period_config}`); keep authorization first. Effort: M.
- [x] **PCF-10** · L · MDL-02 · `PeriodConfig.php:31, 38-39` — drop the redundant `$guarded` line
  (`$fillable` is authoritative) and, if you want, add a comment that the TIME columns are read only
  as `H:i`. No behavioural change. ⚠ SHARED — many controllers reach this model; the change is a
  comment/property removal only. Effort: XS.

## 6. Queries & performance (F9)
- [x] **PCF-11** · H · QRY-01 · `PeriodConfigController.php:427-449` — pre-fetch the ids in one query
  (`PeriodConfig::whereIn('id', $ids)->get()->keyBy('id')`), compute the delta in memory, then write
  with a single `upsert()`/`case` update (or `whereIn` per group). Drop the per-id `exists` probe by
  validating the loaded set once. Effort: M.
- [x] **PCF-12** · L · QRY-02 / C12 · `PeriodConfigController.php:31, 227` — paginate at **10** (the
  module standard) and give each standalone list a distinct page name (e.g. `pc_page` for index,
  `pc_trash_page` for the trash) so they never collide. Effort: XS.
- [x] **PCF-18** · L · TXN-06 / QRY-10 · `PeriodConfigController.php:410, 430-440` — re-read the rows
  with `lockForUpdate()` inside the transaction before comparing, and require `start_at` (or keep the
  default but document it). Prevents duplicate `display_order` under concurrent drags. Effort: S.

## 7. Behaviour decisions (F13)
- [x] **PCF-17** · M · DECISION · deep read · `PeriodConfigController.php:161-167` — `destroy()`
  soft-deletes a config that `tt_period_set_periods_jnt` still references (27 rows today).
      (a) ⭐ Refuse to trash a config that any period set uses, with a `\DomainException` naming the
          sets (same child-count helper as PCF-16) — trashing stays allowed only for unused configs.
      (b) Allow the trash but cascade-clean the `tt_period_set_periods_jnt` references in the same
          transaction (destructive; loses the period-set membership).
      (c) Leave it as is; the period-set screen shows a missing period until someone restores it.
      ➜ Choice: (a) — refuse to trash a timeslot a period set uses, naming the sets (Tarun, 2026-10-13)

## 8. Style (F12) — one item per file
- [x] **PCF-15a** · L · STY · `PeriodConfigController.php` — add `declare(strict_types=1)`, remove the
  `⛔` emoji from the comment on line 270, collapse the stray blank lines in the import block (run
  Pint on the file only), and add return types per PCF-09. Effort: S.
- [x] **PCF-15b** · L · STY · `PeriodConfig.php` — add `declare(strict_types=1)` and a `: Builder`
  return type on `scopeOrdered()`. ⚠ SHARED. Effort: XS.
- [x] **PCF-15c** · L · STY · `PeriodConfigPolicy.php` — add `declare(strict_types=1)`. Effort: XS.

## 9. Views (F10)
- [x] **PCF-13** · H · RTE/VIEW · `views/period-config/index.blade.php:10-14` — the "Add Timeslot"
  anchor calls `route('timetable-foundation.period-config.create')`, which is undefined and throws a
  500. Replace the anchor with the create **modal trigger** used by the tab (`createModal="#createPeriodConfigModal"`)
  or delete the button; at minimum guard it with `@if (Route::has('…create'))`. Effort: S.
- [x] **PCF-14a** · L · CTL-10 · `views/period-config/create.blade.php` — delete the orphan page.
  Before deleting, re-prove at fix time: `Route::has('timetable-foundation.period-config.create')` is
  `false` and `grep -rn 'period-config.create'` finds only comments. Effort: S.
- [x] **PCF-14b** · L · DECISION · VIEW · `index/show/edit/trash.blade.php:2` — all four pass
  `:links="[]"` to the breadcrumb, so no trail is resolved.
      (a) ⭐ Resolve a real trail (e.g. Timetable Masters → Period Configs → {action}) per
          `breadcrumb-standard.md`.
      (b) Leave the empty trail and record it as accepted.
      ➜ Choice: (a) — real trail via `config/breadcrumbs.php` (Tarun, 2026-10-13)

## 10. Deferred / not fixed here
- **CTL-01 split** — not applicable: 504 lines / 14 methods, both under the thresholds. Recorded as
  checked, not needed.
- **`PeriodConfigPolicy` unreachable** — module-wide (gates pass strings). Not fixed per controller;
  needs one module-level decision (same as ATC-14).
