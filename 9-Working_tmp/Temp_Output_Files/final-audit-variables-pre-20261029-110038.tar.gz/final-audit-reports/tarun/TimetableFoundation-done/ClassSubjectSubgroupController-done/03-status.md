# Status — TimetableFoundation / ClassSubjectSubgroupController

**Fixed:** 2026-10-13 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — 31 items ticked and 1 left open (CSG-17).

---

## 1. Pre-applied work

No pre-applied work. `PRE-APPLIED-2026-10-10.md` does not list any file in this controller's scope.

---

## 2. Applied

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| CSG-14 (c) | `routes/web.php` (was 284-289, now a 4-line comment) | Removed the `Route::resource(...)->names('class-subgroup')` line. Also removed its trash, restore, forceDelete and toggleStatus routes and `sections.ajax`. The two AJAX routes are kept. | uncached `route:list` filtered on `class-subgroup` | 2 routes: `ajax.toggleSharing` and `ajax.saveShareTargets` |
| CSG-14 (c) | `ClassSubjectSubgroupController.php` | 12 retired methods now have the body `abort(403, 'This action is not available.')`, return `never`, and carry a `NOT ROUTED (CSG-14, 2026-10-13)` docblock. They are `index`, `create`, `store`, `listSubgroups`, `show`, `edit`, `update`, `destroy`, `getSectionsByClass`, `getSectionsWithClassGroups`, `generateClassSubgroups` and `getSubgroupStats`. | `grep -c "abort(403" …` | 13 (12 stubs + 1 docblock mention) |
| CSG-27 | same | Now only the `ClassSubjectSubgroup` half (AJAX, member FK, policy, permissions) is reachable, so the two-model split cannot come back. | `class_exists` on the controller via the container | resolves |
| CSG-15 (b) | `Models/ClassModeRule.php` | File deleted. Also removed `classModeRules()` from `TimetableType`, `PeriodSet`, `AcademicSession` and `SchoolClass`, `timetableModeRules()` from `SchoolClass`, and three `use` lines. | `grep -rn ClassModeRule Modules/ app/` | 0 hits in app code (tests: see §4) |
| CSG-11 (a) | `Services/ClassSubgroupSharePoolService.php` (new, 186 lines) | Moved the pool-merge algorithm out of the controller verbatim, inside `DB::transaction`. An unresolved target now throws `ValidationException` (Laravel renders it as a 422 whose `message` the blade JS already displays). | rolled-back dry run (§6) | identical targets → 0 rows changed; empty → removed=1; invalid → 422 |
| CSG-20 | same service | `$findPartner` is memoised in `$partners`, keyed by `class_id\|section_id`. | read lines 66-86 | one lookup per cohort |
| CSG-07 | `Http/Requests/SaveShareTargetsRequest.php` (new) | `authorize()` checks `tenant.timetable-foundation.class-subgroup.update`. Rules: `targets present\|array`, `targets.*.class_id required\|integer\|min:1`, `targets.*.section_id nullable\|integer`. | `php -l` and `class_exists` | OK |
| CSG-04, CSG-05 | `ClassSubjectSubgroupController.php` | The controller has no try/catch and no `getMessage()`. Both transaction closures return data; the JSON response is built after the closure returns. | `grep -c 'try {'` / `getMessage` | 0 / 0 |
| CSG-09 | same | Applied as part of the CSG-14 stubs. ⚠ Goes beyond the plan: see §2.1. | | |
| CSG-16 | `Models/ClassSubjectSubgroup.php`, `ClassSubgroupMember.php` | Added `members(): HasMany` (`class_subgroup_id`). The member relations now return `BelongsTo`. Added `created_at`, `updated_at` and `deleted_at` casts on `ClassSubgroupMember`. | tinker on `test.localhost` | `members()` is HasMany (subgroup #1 has 0 rows); member relations are BelongsTo |
| CSG-25 (a) | `resources/views/class-subgroup/` | Deleted. ⚠ Goes beyond the plan: see §2.1. | `routed=0 refs=0` re-proved before deleting | no `view()` names any of them |
| CSG-26a | controller | Added `strict_types` and return types on every public method. No `\Log::` and no emoji remain. | `php -l` | OK |
| CSG-26b/c/e | `ClassSubjectSubgroup.php`, `ClassSubgroupMember.php`, `ClassSubgroupPolicy.php` | Added `strict_types`. Removed the unused `HasFactory` import and the commented factory line from the member model. | `php -l` | OK |
| Pint | all 11 touched files | `vendor/bin/pint <files>` changed formatting in the controller, `TimetableType`, `PeriodSet`, `AcademicSession` and `SchoolClass`. | `php -l` re-run after Pint | OK |

The controller went from 906 lines (before) to 391 lines (after).

### 2.1 Applied beyond the ticked plan — read this

1. **`generateClassSubgroups()` became an `abort(403)` stub.** CSG-09 listed three unrouted methods, but this fourth one was also unrouted and had a full body. It was given the same D5 treatment.
2. **All 7 class-subgroup blades were deleted**, not just the 2 that CSG-25 names. Once CSG-14(c) took effect, `create`, `edit`, `show`, `_partials/_scripts` and `_partials/_styles` had no route left either. In total 1,657 lines were removed, and `routed=0 refs=0` was re-proved before deletion. CSG-22, -23 and -24 are therefore moot.
3. **`composer dump-autoload` was run.** The optimised classmap (built 2026-09-30) still listed the deleted `ClassModeRule.php`, so `class_exists` fataled until the classmap was rebuilt (15,776 classes).

---

## 3. Not applied

| ID | Why |
|---|---|
| **CSG-17** | **Left unticked.** It is a decision for you, and option (a) needs a migration. See §4. |
| CSG-01, -02, -03, -08, -18, -19, -21, -22, -23, -24, -28 | Moot. The methods and blades they target were retired by CSG-14(c). |
| CSG-10 | Moot for the retired routes. The two AJAX routes keep `{id}` + `findOrFail`, because the blade JS builds those URLs (CTL-03 is accepted). |
| CSG-06 | Accepted. Every gate in the module passes a plain permission string, so no Policy is ever consulted (a module-wide pattern). `Gate::policy(ClassSubgroup::class, …)` in `TimetableFoundationServiceProvider.php` now names a class that nothing loads, which is harmless. It is a shared file and was left as is. |
| CSG-12 | (a) Keep. The 9 `generate*` helpers and `updateStudentCount` are now dead (scanner: CTL-10 ×4) and are kept per D5. |
| CSG-26d | Moot. The file was deleted. |

---

## 4. Needs Tarun's hand

1. **Decide CSG-17** (the soft-delete × unique-index trap on `tt_class_requirement_subgroups`):
   - **Current state.** Measured on the live table:
     - `uq_subgroup_code (code)` and `uq_subgroup_class_section_ssf_option` both exist; the latter is built over the virtual column `option_key`.
     - The table holds 132 rows, 0 of them trashed.
   - **Main generator: no trap.** It truncates the table and force-deletes trashed rows.
   - **SchoolSetup generator: the trap fires.** `smart-timetable/class-subject-group/generate-class-groups` (`ClassSubjectGroupController::generateClassSubjectGroups`) soft-deletes rows and then recreates them. That raises error 1062 and the whole transaction rolls back.
   - **Cost of (a).** Adding "live" columns would also make `tt_snap_class_requirement_subgroups`, the snapshot mirror, drift from this table.
2. **Browser check** on `timetable-requirement?tab=generated-groups`:
   - toggle sharing on a subgroup;
   - save share targets;
   - post an invalid target, and confirm the red error text shows the 422 message.
3. **Run tests** — see §5. Nothing was run by this workflow (D4).

---

## 5. Unverifiable by this workflow (D4), and tests that need updating

These are reported only; the files were not edited:

| Test | Why it will go red |
|---|---|
| `Modules/TimetableFoundation/tests/Feature/RouteAuthenticationTest.php:95-96` | Lists `timetable-foundation.class-subgroup.index` and `.create`, both of which are now removed. |
| `Modules/TimetableFoundation/tests/Unit/ModelStructureTest.php:17, 118, 685-692` | Imports and asserts the deleted `ClassModeRule`, so the whole file fails at load time. |
| `tests/Browser/Modules/V2/TimetableFoundation/TimetableMasters/TtSchemaTest.php:11, 815-842` | Imports `ClassModeRule`, so the whole class fails at load time. |
| `Modules/TimetableFoundation/tests/Unit/PolicyTest.php:74` | **Unaffected.** `ClassSubgroupPolicy` still exists. |

**Cross-cutting notes** (not fixed here):
- **Orphan blades** that are rendered by nothing and still name the removed routes:
  - `class-subgroups/_list.blade.php` (guarded by `Route::has`);
  - `class-group-requirement/show.blade.php` (unguarded `class-subgroup.index`);
  - `SmartTimetable/.../class-group-jnt/_list.blade.php` (unguarded `.create` and `.trashed`).
- The breadcrumb entry for `timetable-foundation.class-subgroup.index` at `app/Services/Breadcrumbs/registry.php:3744` is now inert.
- **10 routed actions in other TimetableFoundation controllers have no method.** All of these existed before this pass:
  - `TimetableFoundationController@store`, `@show`, `@update` and `@destroy`;
  - `PeriodSetPeriodController@addPeriodToOrganization`;
  - `RequirementConsolidationController@getRequirementsStats`;
  - `TimetableController@trashedTimetable`, `@forceDelete`, `@restore` and `@toggleStatus`.

---

## 6. Verification log

```
php -l on all touched files (before and after Pint)   -> No syntax errors
composer dump-autoload                                 -> 15,776 classes; ClassModeRule gone
class_exists: controller, service, request, 2 models, policy, 4 edited models -> true
uncached route:list                                    -> 2 class-subgroup routes, both resolve to methods
route probe (with the autoloader loaded)               -> 242 TF actions, 10 without a method (pre-existing, §5)
generated-groups/_list.blade.php compiled              -> php -l OK; declared @push=0, emitted startPush=0;
                                                          both route() names resolve (lines 533, 557)
scan.php + scanfilter (6 in-scope files)                -> 20 rows: 12 RTE-03 (D5 stubs), 4 CTL-10 (D5 helpers),
                                                          VAL-02 (allowed one-field toggle), 2 CTL-03 (accepted),
                                                          CTL-02 saveTargets 135 lines (the extracted algorithm, verbatim)
grep controller: try=0 tx=1 activityLog=1 getMessage=0 abort(403)=13
service dry run inside a transaction, then rolled back (subgroup #14):
  same targets   -> pool_size=2 removed=0 updated_rows=0
  empty targets  -> pool_size=1 removed=1 updated_rows=2 targets=[]
  invalid target -> ValidationException 422 {"targets":["Class 999999 has no active subgroup ..."]}
  after rollback -> pooled=82 logs=1949 (unchanged)
```

---

## 7. Final state

**FIXED**, with one open decision (CSG-17, M). The 1 B (CSG-14) and every H finding are closed: they were either applied or made moot by retiring the CRUD half. Still open: CSG-17 (M), plus 3 test files the team has to update (§5).
