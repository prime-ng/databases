# Fix Plan — TimetableFoundation / ClassSubjectSubgroupController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/ClassSubjectSubgroupController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today

- [x] **CSG-14** · B · DECISION · MDL-07 · `ClassSubjectSubgroupController.php:16-17` — the CRUD half of this controller loads `Modules\SmartTimetable\Models\ClassSubgroup` and `…\ClassGroupJnt`, neither of which exists (no file, no autoload entry, no table). The screen currently 500s on create/store/show/edit/update. Choose the canonical model:
      (a) ⭐ **Repoint CRUD to `ClassSubjectSubgroup`** (the only subgroups class; table `tt_class_requirement_subgroups` exists). Renames the two imports and the `ClassSubgroup::` call sites, drops `::SUBGROUP_TYPES` for a constant on `ClassSubjectSubgroup`, and fixes the column/view mismatches (CSG-22, CSG-27). No new table. Matches the member FK, the policy, the permissions and the two AJAX methods, which already target `ClassSubjectSubgroup`.
      (b) **Create the missing `SmartTimetable` models + their tables** (`tt_class_subgroups`, `tt_class_groups_jnt`) from the original design. Two new classes and a new migration; leaves the member FK, policy and AJAX methods pointing at a different table.
      (c) Leave the CRUD half `abort(403)` and keep only the AJAX methods.
      ➜ Choice: (c) retire the CRUD — Tarun 2026-10-13 ("subgroups are generated on timetable-requirement?tab=generated-groups; we don't need the CRUD"). Resource + trash/restore/forceDelete/toggle + sections.ajax routes removed; 12 methods abort(403) NOT ROUTED; 7 class-subgroup blades deleted
      Effort: M (option a) / L (option b). ⚠ Option (b) needs a migration → your hand.

- [x] **CSG-27** · H · deep read · same files — the controller treats one resource as two: CRUD on `ClassSubgroup`, AJAX/member-FK/policy/permissions on `ClassSubjectSubgroup`. Whichever model CSG-14 selects, **one half changes**. This item is the enforcement of the CSG-14 choice; it is listed so the mismatch is not re-introduced. Apply with CSG-14, not separately. Effort: S.
      ➜ Status: applied with CSG-14(c): the CRUD half is retired, so only the ClassSubjectSubgroup half (AJAX + member FK + policy + permissions) remains — the mismatch cannot recur

## 2. Fixes that arm a latent defect (sequenced)

- [x] **CSG-03** · H · ERR-02 · `ClassSubjectSubgroupController.php:325-357` — `getSectionsWithClassGroups()` catches its own `firstOrFail()` and returns 500 for a missing class. It is unrouted today, so **fix CSG-09 first** (which makes this body `abort(403)` and this defect disappears). If CSG-09 is not ticked and you route the method instead, then move `firstOrFail()` out of the `try` and rethrow `ModelNotFoundException` as a 404. Effort: S.
      ➜ Status: moot — getSectionsWithClassGroups() body is abort(403) (CSG-09)

## 3. Errors & transactions (F1/F2)

- [x] **CSG-01** · M · ERR-00 / TXN-02 · `ClassSubjectSubgroupController.php:205-238` — rewrite `update()` as `return DB::transaction(fn () => …)`: keep `findOrFail` (194) and `validate` (197) before the closure; return the model from the closure; build the redirect afterwards; delete `beginTransaction`/`commit`/`rollBack` and the try/catch. Effort: S.
      ➜ Status: moot — update() retired by CSG-14(c), body is abort(403)
- [x] **CSG-02** · M · ERR-07 / ERR-00 · `ClassSubjectSubgroupController.php:256-314` — remove the try/catch from `getSectionsByClass()`. Let `firstOrFail` (260) 404 through the central handler; if a JSON 404 body is required, keep only the `ModelNotFoundException` branch **outside** the generic one. Keep the JSON success shape. Effort: S.
      ➜ Status: moot — getSectionsByClass() retired (its sections.ajax route removed with the CRUD)
- [x] **CSG-04** · M · ERR-05 · `ClassSubjectSubgroupController.php:307, 597, 782` — replace the three message-only logs with `report($e)` (or `Log::error('…', ['exception' => $e])`); drop the `getMessage()` concatenation. Effort: S.
      ➜ Status: applied — controller now has 0 try/catch and 0 getMessage(); errors reach the central handler
- [x] **CSG-05** · M · TXN-05 · `ClassSubjectSubgroupController.php:585-589, 765-775` — have each transaction closure `return` the data (mode, final targets, pool_size, removed, changed); build `response()->json([...])` **after** the closure returns. Effort: S.
      ➜ Status: applied — ajaxToggleSharing and SharePoolService::saveTargets() return data from the closure; JSON built after

## 4. Authorization (F3)

- [x] **CSG-06** · L · AUTH-05 · `TimetableFoundationServiceProvider.php:124` — `Gate::policy(ClassSubgroup::class, …)` binds a policy to a class that does not exist, and every gate passes a string so no Policy is consulted. This is a **module-wide** pattern (all policies registered at lines 119-140 are equally unreachable). If CSG-14(a) is chosen, re-point the class here; otherwise leave the policy as-is and record it as accepted. ⚠ SHARED file. Effort: S. → see §9.
      ➜ Status: accepted — the module-wide string-gate pattern is out of scope here; Gate::policy(ClassSubgroup) now points at a class nothing loads (cross-cutting note in 03-status)

## 5. Validation, routes, models (F4/F5/F7)

- [x] **CSG-07** · M · VAL-02 · `ClassSubjectSubgroupController.php:61-77, 197-203, 638-642` — extract `StoreClassSubjectSubgroupRequest`, `UpdateClassSubjectSubgroupRequest` and `SaveShareTargetsRequest` under `app/Http/Requests/`; call `$request->validated()`. Leave the one-field `ajaxToggleSharing` `mode` check inline (VAL-02 allows it). `authorize()` in each request replicates the current `Gate::authorize` string. Effort: M.
      ➜ Status: applied for SaveShareTargetsRequest only; the Store/Update requests are moot (CRUD retired). ajaxToggleSharing keeps its one-field inline check
- [x] **CSG-08** · M · VAL-07 · the Store request (from CSG-07) and `ClassSubjectSubgroupController.php:104-108` — add `members.*.class_id` distinct-with-`section_id` validation (e.g. `Rule::distinct` per member index, or an `after()` hook comparing `(class_id, section_id)` pairs) so the "unique combination" the create page promises is enforced. Effort: S.
      ➜ Status: moot — store() retired
- [x] **CSG-09** · M · RTE-03 · `ClassSubjectSubgroupController.php:122, 321, 529` — per D5: replace the bodies of `listSubgroups()`, `getSectionsWithClassGroups()` and `getSubgroupStats()` with `abort(403, …)` under a `// NOT ROUTED` comment. Keep them, do not delete. ⚠ May change what `ControllerAuthTest` expects; that is for the team (D4). Effort: S.
      ➜ Status: applied — listSubgroups/getSectionsWithClassGroups/getSubgroupStats are abort(403) + NOT ROUTED; ⚠ beyond plan: generateClassSubgroups() had a full unrouted body and got the same treatment
- [x] **CSG-10** · M · CTL-03 · `ClassSubjectSubgroupController.php:145, 169, 189, 244, 252` + `routes/web.php` — add route-model binding: type-hint the model and make the route parameter name match each argument (`{class_subject_subgroup}` → e.g. `classSubgroup`, `{class}` → `classId`), or keep the URL and add `->parameters([...])` to the resource. `findOrFail` then disappears. ⚠ SHARED `routes/web.php`. Effort: S.
      ➜ Status: moot for the retired CRUD routes; the two AJAX routes keep {id} + findOrFail (CTL-03 accepted, the route URLs are fixed by the blade JS)
- [x] **CSG-15** · H · DECISION · MDL-07 · `ClassModeRule.php:18` — `tt_class_mode_rules` exists in neither the tenant nor the central DB and no migration creates it.
      (a) ⭐ **Write an additive tenant migration** creating `tt_class_mode_rules` with the columns the model already declares (`class_id`, `timetable_type_id`, `period_set_id`, `academic_session_id`, `allow_teaching`, `allow_exam`, `exam_period_count`, `teaching_after_exam`, `effective_from`, `effective_to`, `is_active`, timestamps, `deleted_at`). The fixer writes it; **you run** `php artisan tenants:migrate`. Requires the DDL/design to confirm columns and keys.
      (b) Delete the model and its four relations (TimetableType, PeriodSet, AcademicSession, SchoolClass) if the feature is abandoned.
      ➜ Choice: (b) delete the model — Tarun 2026-10-13. ClassModeRule.php deleted; classModeRules() removed from TimetableType, PeriodSet, AcademicSession, SchoolClass (+ timetableModeRules() on SchoolClass)
      Effort: S. ⚠ A migration is written, never run.

- [x] **CSG-16** · M · MDL-04 / MDL-02 · `ClassSubjectSubgroup.php:65-125` — add the missing inverse relation `members(): HasMany` to `ClassSubgroupMember` (the FK `fk_csm_subgroup` already points here); add return types to every relation in `ClassSubgroup`, `ClassSubgroupMember` and `ClassModeRule`; add `created_at`/`updated_at`/`deleted_at` casts to `ClassSubgroupMember`. ⚠ SHARED — `ClassSubjectSubgroup` is reached by other controllers. Effort: S.
      ➜ Status: applied — members(): HasMany on ClassSubjectSubgroup; return types + timestamp casts on ClassSubgroupMember. The ClassSubgroup/ClassModeRule parts are moot (classes do not exist / deleted by CSG-15)
- [ ] **CSG-17** · M · DECISION · MDL-03 / VAL-04 · `tt_class_requirement_subgroups` — the soft-delete × unique-index trap (re-creating a trashed `code` or cohort → SQL 1062).
      (a) ⭐ New additive migration adds generated "live" columns (`code_live`, `cohort_live`) and rebuilds `uq_subgroup_code` / `uq_subgroup_class_section_ssf_option` over them, so trashed rows do not block a re-create; plus a validator note.
      (b) Validator only: make the `code` uniqueness check include trashed rows, and accept the cohort trap.
      (c) Accept as-is.
      ➜ Choice: ⚠ NOT TICKED — needs Tarun. Evidence: live has uq_subgroup_code + uq_subgroup_class_section_ssf_option (option_key is a VIRTUAL generated col); 132 rows, 0 trashed. The main generator truncates + force-deletes trashed rows (no trap). The SchoolSetup ClassSubjectGroupController::generateClassSubjectGroups path soft-deletes then recreates → 1062 + rollback. Adding live columns also drifts the tt_snap_class_requirement_subgroups snapshot mirror. Options unchanged; (a) needs a migration you run
      Effort: M. ⚠ A migration is written, never run.

## 6. Queries & performance (F9)

- [x] **CSG-18** · H · QRY-01 · `ClassSubjectSubgroupController.php:263-286` — eager-load the relation: `ClassSection::with('section')->where('is_active', true)->where('class_id', $classId)->get(...)`, and select only the columns used (`id, section_id, capacity, actual_total_student`). Effort: S.
      ➜ Status: moot — getSectionsByClass() retired
- [x] **CSG-19** · M · QRY-07 · `ClassSubjectSubgroupController.php:101-109` — build the member rows as an array and `ClassSubgroupMember::insert($rows)` (or `upsert`) instead of `create()` per iteration; keep `updateStudentCount` after the insert. Effort: S.
      ➜ Status: moot — store() retired
- [x] **CSG-20** · M · QRY-01 / QRY-12 · `ClassSubjectSubgroupController.php:660-684, 715-760` — memoise `$findPartner` results in an array keyed by `class_id|section_id`, and have `$poolOf` reuse that cache, so a partner is resolved once per request. Effort: S.
      ➜ Status: applied — $findPartner memoised by class_id|section_id inside ClassSubgroupSharePoolService
- [x] **CSG-21** · L · QRY-02 / QRY-15 · `ClassSubjectSubgroupController.php:128, 41, 43, 174, 176` — if `listSubgroups` is ever routed, paginate at 10 with a distinct `pageName`; add a filter/limit to the `ClassGroupJnt::all()` / `SchoolClass::active()->get()` form loads. Latent until CSG-09 is reversed. Effort: S.
      ➜ Status: moot — listSubgroups() stays abort(403)

## 7. Views (F10)

- [x] **CSG-22** · H · VIEW / MDL · `show.blade.php:64, 110, 120, 205-208, 287, 308, 349, 355` and `edit.blade.php:31, 167-168, 270, 286` — after the CSG-14 choice, align the blades with the real model: replace `availableSeats()` / `hasMinimumStudents()` / `isFull()` with the model's actual methods (or add them to `ClassSubjectSubgroup`); use the real relation names (`schClassGroup` not `classGroup`, add `members()` per CSG-16); drop `current_version` (not a column). Depends on CSG-14 and CSG-16. Effort: M.
      ➜ Status: moot — show/edit blades deleted with the CRUD (CSG-14c, CSG-25)
- [x] **CSG-23** · H · VIEW / CTL-09 · `_partials/_scripts.blade.php:62-73, 227-234, 304, 324` — remove the unconditional `e.preventDefault()` in the submit handler (or move it inside each failing branch and let the form submit); delete the undefined `template`/`predefinedClassId` block; stop referencing `$classSubgroup` in the shared partial (guard it, or move the edit-only script into `edit.blade.php`). Effort: M.
      ➜ Status: moot — _partials/_scripts.blade.php deleted with the CRUD
- [x] **CSG-24** · M · VIEW · `_partials/_scripts.blade.php:107` — change the fetch URL to the registered route, `{{ route('timetable-foundation.class-subgroup.sections.ajax', ':id') }}` or `/timetable-foundation/class-subject-subgroup/${classId}/get/sections`. Effort: S.
      ➜ Status: moot — _partials/_scripts.blade.php deleted with the CRUD
- [x] **CSG-25** · L · DECISION · orphan views — `class-subgroup/index.blade.php` (Day Management copy) and `class-subgroup/trash.blade.php` (teacher-availability copy) are unreachable; `listSubgroups` points at a partial that does not exist.
      (a) ⭐ Delete `index.blade.php` and `trash.blade.php` (re-prove `routed=0 refs=0` at fix time), and let CSG-09 make `listSubgroups` `abort(403)`.
      (b) Keep both blades.
      ➜ Choice: (a) — Tarun 2026-10-13 (via CSG-14). ⚠ Extended: all 7 class-subgroup blades deleted (create, edit, index, show, trash, _partials/_scripts, _partials/_styles — 1,657 lines), routed=0 refs=0 re-proved at fix time
      Effort: S.

## 8. Style (F12) — one item per file

- [x] **CSG-26a** · L · STY · `ClassSubjectSubgroupController.php` — add `declare(strict_types=1)`; add return types to all 14 public methods; replace `\Log::` (307) with the imported `Log`; remove emoji markers in comments (613, 626, 743). Effort: S.
      ➜ Status: applied — strict_types, return types, no \Log::, no emoji
- [x] **CSG-26b** · L · STY · `ClassSubjectSubgroup.php` — add `declare(strict_types=1)`. ⚠ SHARED. Effort: S.
      ➜ Status: applied
- [x] **CSG-26c** · L · STY · `ClassSubgroupMember.php` — add `declare(strict_types=1)`; drop the unused `HasFactory` import and the commented `// use …Factory` line. Effort: S.
      ➜ Status: applied
- [x] **CSG-26d** · L · STY · `ClassModeRule.php` — add `declare(strict_types=1)`; drop the unused `HasFactory` import and the commented `// use …Factory` line. Effort: S.
      ➜ Status: moot — ClassModeRule.php deleted (CSG-15 b)
- [x] **CSG-26e** · L · STY · `ClassSubgroupPolicy.php` — add `declare(strict_types=1)`. Effort: S.
      ➜ Status: applied

## 9. Deferred / decisions

- [x] **CSG-11** · H · DECISION · CTL-02 · `ClassSubjectSubgroupController.php:632-789` — `ajaxSaveShareTargets()` is 158 lines holding the whole pool-merge algorithm.
      (a) ⭐ **Extract it to a service** (`ClassSubgroupSharePoolService`), keeping the route and behaviour identical. Not a god-controller split, so D3 does not defer it.
      (b) Defer with the module's god-controller splits (D3).
      (c) Leave as is, recorded as accepted.
      ➜ Choice: (a) — 2026-10-13, per the ⭐. Extracted to Modules/TimetableFoundation/app/Services/ClassSubgroupSharePoolService.php; route, URL, request and JSON keys unchanged
      Effort: M.
- [x] **CSG-12** · M · DECISION · CTL-10 · `ClassSubjectSubgroupController.php:377-524` — the 9 dead `generate*` helpers (D5 keeps them; their only caller is now `abort(403)`).
      (a) ⭐ **Keep** per D5; no code change. Record as accepted.
      (b) Delete all 9; they live in git history.
      ➜ Choice: (a) keep per D5 — 2026-10-13. No change
      Effort: — (a) / S (b).
- [x] **CSG-13** · M · CTL-05 / SVC-04 · resolved by CSG-14 — the duplicate CRUD/AJAX model families and the duplicated `listSubgroups`/`getSubgroupStats` (SchoolSetup's `ClassGroupController` owns the same pair). CSG-14 picks the single model; CSG-09 retires the duplicate methods. No separate change.
      ➜ Status: resolved by CSG-14(c) + CSG-09, no separate change
- [x] **CSG-28** · M · DECISION · deep read · `ClassSubjectSubgroupController.php:244-247` — `destroy()` runs `Gate::authorize` and returns nothing; the `DELETE` route silently deletes nothing.
      (a) ⭐ **Implement** `destroy()` as `ClassSubjectSubgroup::findOrFail($id)->delete()` inside a transaction with an `activityLog('Trashed')`, and keep the route.
      (b) Make the body `abort(403)` under a `// NOT ROUTED` comment and remove the `destroy` route (it has no caller).
      (c) Leave as is, recorded as accepted.
      ➜ Choice: (b) in effect — 2026-10-13: destroy() retired with the CRUD (abort(403), DELETE route removed)
      Effort: S (a) / S (b).

---

> **After approval:** run final-audit-fixer on
> `Modules/TimetableFoundation/app/Http/Controllers/ClassSubjectSubgroupController.php`.
> Two items (`CSG-14b`, `CSG-15`, `CSG-17`) require a migration that the fixer **writes but never runs**;
> you run `php artisan tenants:migrate` after. `CSG-06`, `CSG-10`, `CSG-16b`, `CSG-16c` touch shared
> files and need their own explicit tick.
