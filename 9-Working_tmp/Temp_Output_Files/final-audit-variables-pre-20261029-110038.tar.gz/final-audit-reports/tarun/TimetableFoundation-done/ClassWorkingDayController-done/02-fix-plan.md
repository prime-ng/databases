# Fix Plan — TimetableFoundation / ClassWorkingDayController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/ClassWorkingDayController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
_None (0 B)._

## 2. Fixes that arm a latent defect (sequenced)
- [x] **CWD-28** · M · deep read / TXN-06 · `ClassWorkingDayController.php:306` — `forceDelete()` must use `onlyTrashed()->findOrFail($id)` so a live row can no longer be purged. `restore:338` already does this. No FK children exist (measured), so no child guard is needed. Effort: S.
- [x] **CWD-09** · M · VAL-04 · `ClassWorkingDayController.php:103, 217` — add a uniqueness rule that mirrors `uq_class_working_day (class_id, section_id, working_day_id)` **including trashed rows**, so a re-create of a trashed class/day returns a field error instead of SQL 1062. Do this before CWD-01, which deletes the catch that currently hides the 1062. Effort: S.
- [x] **CWD-05** · M · TXN-06 · `ClassWorkingDayController.php:591-617, 748-781` — close the check-then-act race: wrap the upsert lookup in `lockForUpdate()` inside the transaction, or catch the unique violation once (the null-section case needs the lock). Effort: M.

## 3. Errors & transactions (F1/F2)
- [x] **CWD-01** · M · ERR-00 (D1) · `ClassWorkingDayController.php:78-131, 190-245, 255-280, 304-326, 336-360, 379-401, 668-700, 710-818` — remove the `try/catch` from all **eight** non-D2 methods. Keep the one allowed D2 catch in `ajaxStore:640` (`\DomainException`, already commented ERR-01/2026-10-10). Let the central handler in `bootstrap/app.php` render form failures as a redirect and AJAX failures as JSON. Also drop the now-unused imports `AuthorizationException`, `ModelNotFoundException`, `ValidationException`, `HttpExceptionInterface`. Effort: M.
- [x] **CWD-02** · H · ERR-02 · `ClassWorkingDayController.php:80, 194` — move `$request->validate([...])` to the top of `store`/`update`, **before** the transaction (and before the try, which CWD-01 removes), so field errors surface. Effort: S.
- [x] **CWD-03** · M · ERR-05 · `ClassWorkingDayController.php:128, 242, 277, 323, 357, 392, 694, 812` — replace each `Log::error('…', ['error' => $e->getMessage()])` with `report($e)`. (Resolved automatically once CWD-01 deletes the catches; do this if any catch is kept.) Effort: S.
- [x] **CWD-04** · M · TXN-05 · `ClassWorkingDayController.php:118-120, 232-234, 267-269, 313-315, 347-349` — have each closure return the model, then build the redirect/flash **after** `DB::transaction(...)`. Effort: S.

## 4. Authorization (F3)
- [x] **CWD-06** · M · AUTH-02 · `ClassWorkingDayController.php:668-669, 710-711` — move `Gate::authorize(...)` above the `try` in `ajaxDestroy` and `ajaxInitialize`. (Resolved automatically once CWD-01 removes those try blocks — do this if the catches stay.) Effort: S.
- [ ] **CWD-07** · L · AUTH-04 / AUTH-06 · `ClassWorkingDayPolicy.php` + controller — the registered `ClassWorkingDayPolicy` is never consulted; the seven permission strings are repeated literals. **Do not change here.** The unreachable-policy/constant question is module-wide (see `WorkingDayController` WDY-17, `AcademicTermController` ATC-14). Recommend a single module-level decision. Effort: S once decided.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **CWD-08** · M · VAL-02 · `ClassWorkingDayController.php` + new `app/Http/Requests/ClassWorkingDayRequest.php` — extract the `store`/`update` rule set into a FormRequest; reuse it in `ajaxStore`/`ajaxInitialize` where the payload overlaps. `toggleStatus`'s single boolean stays inline (allowed). Effort: M.
- [x] **CWD-10** · H · DECISION · RTE-01 · `routes/web.php:313` — Restore runs over GET.
      (a) ⭐ Change it to `Route::patch('/class-working-day/{id}/restore', …)`. `x-backend.table.action-trashed` derives the verb from the route, so no blade edit is needed; the only caller is `trash.blade.php:45`. ⚠ Changes a route — needs explicit approval.
      (b) Leave it as GET and accept the CSRF/prefetch risk.
      ➜ Choice: (a) — Tarun, 2026-10-13. Applied: route is PATCH.
- [x] **CWD-16** · L · MDL-04 · `ClassWorkingDay.php:84, 89, 94, 99` — add `: BelongsTo` return types to `academicSession()`, `class()`, `section()`, `workingDay()`. Optionally add `declare(strict_types=1)`. Effort: S.
- [ ] **CWD-17** · M · DECISION · MDL/DDL-drift · migration `2026_06_16_152556_create_tt_class_working_day_jnt_table.php:46` vs `Timetable_DDL_v8.1.sql:360` — the live unique key is `(class_id, section_id, working_day_id)`; every DDL version defines `(class_id, working_day_id)`.
      (a) ⭐ Keep the app's three-column key (it is what makes "class default + per-section override" possible) and **fix the DDL** to match; correct the migration comment that claims v7.9 already includes `section_id`. The DDL is outside this repo's code, so it is a Tarun hand-item.
      (b) Match the DDL: a new **additive** migration rebuilds the key as `(class_id, working_day_id)`. ⚠ This rejects the class-level + per-section coexistence the controller relies on and can fail on existing data.
      (c) Correct the comments only; leave the schema as built.
      ➜ Choice: not ticked — Tarun hand-item (fix the DDL; the migration comment cannot be edited).

## 6. Queries & performance (F9)
- [x] **CWD-19** · H · QRY-01 · `ClassWorkingDayController.php:567, 591, 741, 748` — remove the queries from inside the loops: pre-load the session's `WorkingDay` rows into a `keyBy('date')` collection, and the existing `ClassWorkingDay` children into a keyed collection before the class × section × date loops. Effort: M.
- [x] **CWD-20** · M · QRY-07 · `ClassWorkingDayController.php:609-613, 773-778` — replace per-row `create`/`update`/`restore` with a chunked `upsert()` (or batched inserts) once CWD-19's pre-load is in place. Effort: M.
- [x] **CWD-21** · M · QRY-15 · `ClassWorkingDayController.php:56, 167` — restrict the create/edit `WorkingDay` dropdown to the selected academic session and select only `id, date`. Effort: S.

## 7. Views (F10)
- [x] **CWD-22** · H · VIEW / deep read · `resources/views/class-working-day/show.blade.php:28`, `resources/views/class-working-day/trash.blade.php:29` — change `$model->schoolClass?->name` to `$model->class?->name` (the real relation). Proven: `class` resolves, `schoolClass` is null. Effort: S.
- [ ] **CWD-23** · L · DECISION · VIEW / CTL · `ClassWorkingDayController.php:40-69, 137-181` — `create`/`show`/`edit` are orphaned pages; the live UI is the calendar tab.
      (a) ⭐ Make `create()` `abort(403)` with a NOT ROUTED-style comment (D5 spirit), and leave the blades in place; keep `show`/`edit` as-is or treat them the same.
      (b) Leave all three pages.
      (c) Retire `show` too and drop its route.
      ➜ Choice: not ticked — would break green tests 11/12 (see 03-status §4).
- [x] **CWD-24** · L · VAL-05 · `ClassWorkingDayController.php:422-431, 477-483` — validate `start`/`end` as `nullable|date` in `eventFeed`/`workingDayFeed`, returning a 422 for a malformed range. Effort: S.

## 8. Style (F12) — one item per file
- [x] **CWD-26a** · L · STY · `ClassWorkingDayController.php` — add `declare(strict_types=1)`; remove the four emoji markers from comments (`:444, 501, 584, 756`); add return types to the 16 public methods (CWD-15). Pint is currently clean. Effort: S.
- [x] **CWD-26b** · L · STY · `ClassWorkingDay.php` — add `declare(strict_types=1)`. ⚠ SHARED — 5 other controllers reach this model; the change is a header only. Effort: S.
- [x] **CWD-26c** · L · STY · `ClassWorkingDayPolicy.php` — add `declare(strict_types=1)`. Effort: S.

## 9. Deferred / decisions
- [ ] **CWD-14** · M · DECISION · CTL-06 — extract the 100+ line generation loops from `ajaxStore`/`ajaxInitialize` into a service/action?
      (a) ⭐ defer to the split/refactor pass (D3); record as accepted debt
      (b) extract a `ClassWorkingDayService` now (shared rules for both ajax methods and any future writer)
      (c) leave as is
      ➜ Choice: not ticked — deferred under D3.
- [x] **CWD-18** · H · DECISION · deep read #8 / F8 — the `SpecialDayAssigned` event has no listener, so "Send Notification" silently does nothing.
      (a) ⭐ Fix the send: create a listener (queued, tenant-aware, `$tries`/`$timeout`) that delivers to the validated channels. ⚠ New class + queue config.
      (b) Remove the `send_notification` / `notification_channels` fields and the dispatch, so the UI stops offering a dead feature.
      (c) Leave as is (documented dead feature).
      ➜ Choice: (b) — Tarun, 2026-10-13. Applied: fields, dispatch and modal removed.
- [x] **CWD-25** · M · DECISION · SEC-03 — `ajaxStore:600` falls back to `academic_session_id = 1` when there is no current session.
      (a) ⭐ Return a 422 "No current academic session." exactly like `ajaxInitialize:722-724`; never write a hard-coded id.
      (b) Fall back to the latest active session.
      (c) Leave as is.
      ➜ Choice: (a) — applied 2026-10-13: 422 "No current academic session."
- [ ] **CWD-27** · M · DECISION · deep read — the resource `store`/`update` duplicate the AJAX path with weaker rules (no working-day-exists check, no `date` vs `working_day_id` consistency).
      (a) ⭐ Align the resource path with `ajaxStore` (require a configured working day for the date, and keep `date` consistent with `working_day_id`).
      (b) Retire the resource write path with CWD-23(a) (abort 403), so there is one writer only.
      (c) Leave as is.
      ➜ Choice: not ticked — would break green test 15 (see 03-status §4).

---

### How to approve

1. Tick `[x]` on the items you want applied.
2. Fill every `➜ Choice:` on a ticked DECISION item.
3. Run `final-audit-fixer` on
   `Modules/TimetableFoundation/app/Http/Controllers/ClassWorkingDayController.php`.
