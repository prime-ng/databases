# Final Audit — TimetableFoundation / ClassWorkingDayController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/ClassWorkingDayController.php` (820 lines, 16 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 5 HIGH, 17 MEDIUM, 7 LOW.**

This is a 820-line, 16-method controller with two write surfaces that disagree: the resource CRUD (`store`/`update`/`destroy`) and the calendar AJAX path (`ajaxStore`/`ajaxInitialize`/`ajaxDestroy`). The live UI is the calendar tab; the resource pages are reachable only by URL. The 2026-10-10 pass converted **only** `ajaxStore` to the D2 error shape; **eight other methods still wrap their body in a controller `try/catch`**, and in `store`/`update` the `validate()` call sits inside it, so a bad input is shown as "The operation could not be completed." instead of field errors.

The single worst finding is **CWD-18**: `ajaxStore` dispatches the `SpecialDayAssigned` event when an admin ticks "Send Notification", but **no listener is registered anywhere in the app**, so the notification is silently never sent and the request still reports success.

The two silent data-display/behaviour bugs a user will actually see are **CWD-22** (the Class column on the show and trash pages is always "—" because the blades read `schoolClass`, a relation that does not exist) and **CWD-10** (Restore runs over a GET request). The effort is about a day. Six DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 5 | 17 | 7 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CWD-01, CWD-02, CWD-03 | F8 Services/Jobs | CWD-18 |
| F2 Transactions/Audit | CWD-04, CWD-05 | F9 Queries/Perf | CWD-19, CWD-20, CWD-21 |
| F3 Authorization | CWD-06, CWD-07 | F10 Views | CWD-22, CWD-23, CWD-24 |
| F4 Validation | CWD-08, CWD-09 | F11 Security/Tenancy | CWD-25 |
| F5 Routes | CWD-10 | F12 Style | CWD-26 |
| F6 Controller shape | CWD-11, CWD-12, CWD-13, CWD-14, CWD-15 | F13 Deep read | CWD-27, CWD-28, CWD-29 |
| F7 Models | CWD-16, CWD-17 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TimetableFoundation/app/Http/Controllers/ClassWorkingDayController.php` | controller | 820 | this report | ✅ whole class |
| 2 | `Modules/TimetableFoundation/app/Models/ClassWorkingDay.php` | model | 194 | **this report (pre-assigned — reached by 5 other controllers)** | ✅ |
| 3 | `Modules/TimetableFoundation/app/Policies/ClassWorkingDayPolicy.php` | policy | 44 | this report | ✅ — unreachable, CWD-07 |
| 4 | `Modules/TimetableFoundation/app/Events/SpecialDayAssigned.php` | event | 22 | this report (claimed) | ✅ — CWD-18 |
| 5 | `Modules/TimetableFoundation/routes/web.php` lines 304-317 | routes | — | this report (shared file) | ✅ |
| 6 | `resources/views/class-working-day/create.blade.php` | page | 155 | this report | ✅ — orphan, CWD-23 |
| 7 | `resources/views/class-working-day/edit.blade.php` | page | 154 | this report | ✅ — orphan, CWD-23 |
| 8 | `resources/views/class-working-day/show.blade.php` | page | 91 | this report | ✅ — CWD-22 |
| 9 | `resources/views/class-working-day/trash.blade.php` | page | 72 | this report | ✅ — CWD-22 |
| 10 | `resources/views/pages/partials/timetable-masters/class-working-days/_list.blade.php` | tab partial (consumer) | 643 | ↗ rendered by `TimetableFoundationController`; checked for this controller's data sinks only | ↗ linked |
| 11 | `Modules/TimetableFoundation/app/Models/WorkingDay.php` | model (other report) | 118 | ↗ [WorkingDayController](../WorkingDayController-done/01-report.md) | usage only |
| 12 | `Modules/TimetableFoundation/app/Models/DayType.php` | model (other report) | 193 | ↗ [DayTypeController](../DayTypeController-done/01-report.md) | usage only (`display_color`, `background_color`) |
| 13 | `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php` | model (other module) | 46 | common (§4.2) | relation only; §7 |
| 14 | `Modules/SchoolSetup/app/Models/SchoolClass.php`, `Section.php` | models (other module) | — | common (§4.2) | properties only |
| 15 | `Modules/TimetableFoundation/app/Providers/TimetableFoundationServiceProvider.php:126` | provider (glue) | — | common | policy registration read only |
| 16 | `config/permissionslist.php:659` | config (shared) | — | common | 7 keys read |
| 17 | `flash()`, `activityLog()` | helpers | — | common | not audited |
| 18 | `Modules/TimetableFoundation/tests/Unit/ControllerAuthTest.php` | test | — | team (D4) | not edited; cross-cutting §7 |

**Pre-applied 2026-10-10:** this controller is listed in `../PRE-APPLIED-2026-10-10.md` ("rule messages thrown as `\DomainException`, caught only as `DomainException`, with the 'do not widen to RuntimeException' comment (ERR-01). Pint applied"). On disk that change is **`ajaxStore` only** (`:637-645`, the `catch (\DomainException)` with the ERR-01/2026-10-10 comment). This audit reviewed the result fresh: the D2 shape there is correct and allowed. The other **eight** methods still carry non-D2 controller `try/catch` — the reason CWD-01 exists. `WorkingDayController` was touched in the same pass and shares the `ClassWorkingDay`/`DayType` models and this calendar pattern; it is owned by its own report — linked, not re-audited.

## 4. Routes

```
GET|HEAD  timetable-foundation/class-working-day                          timetable-foundation.class-working-day.index          index
POST      timetable-foundation/class-working-day                          timetable-foundation.class-working-day.store          store
DELETE    timetable-foundation/class-working-day/ajax/delete/{id}         timetable-foundation.class-working-day.ajaxDestroy    ajaxDestroy
GET|HEAD  timetable-foundation/class-working-day/ajax/events              timetable-foundation.class-working-day.eventFeed      eventFeed
POST      timetable-foundation/class-working-day/ajax/initialize          timetable-foundation.class-working-day.ajaxInitialize ajaxInitialize
POST      timetable-foundation/class-working-day/ajax/store               timetable-foundation.class-working-day.ajaxStore      ajaxStore
GET|HEAD  timetable-foundation/class-working-day/ajax/working-day-feed    timetable-foundation.class-working-day.workingDayFeed workingDayFeed
GET|HEAD  timetable-foundation/class-working-day/create                   timetable-foundation.class-working-day.create        create
GET|HEAD  timetable-foundation/class-working-day/trash/view               timetable-foundation.class-working-day.trashed        trashedClassWorkingDay
GET|HEAD  timetable-foundation/class-working-day/{class_working_day}      timetable-foundation.class-working-day.show           show
PUT|PATCH timetable-foundation/class-working-day/{class_working_day}      timetable-foundation.class-working-day.update         update
DELETE    timetable-foundation/class-working-day/{class_working_day}      timetable-foundation.class-working-day.destroy        destroy
GET|HEAD  timetable-foundation/class-working-day/{class_working_day}/edit timetable-foundation.class-working-day.edit          edit
POST      timetable-foundation/class-working-day/{class_working_day}/toggle-status timetable-foundation.class-working-day.toggleStatus toggleStatus
DELETE    timetable-foundation/class-working-day/{id}/force-delete        timetable-foundation.class-working-day.forceDelete    forceDelete
GET|HEAD  timetable-foundation/class-working-day/{id}/restore             timetable-foundation.class-working-day.restore        restore   ← GET
```

Middleware on every route (`RouteServiceProvider.php:45-56`): `web, InitializeTenancyByDomain, PreventAccessFromCentralDomains, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`. ✅ RTE-05.

**Unrouted public methods:** none — all 16 public methods are routed (`route:list` → 16 rows). Custom AJAX/trash routes are declared (lines 306-315) **before** `Route::resource` (line 316), so `{class_working_day}` cannot capture `ajax/*`. ✅ RTE-06. The `restore` route is GET — CWD-10.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect to tab) | — |
| create | ✅ | create | — | — | — | CWD-21, CWD-23 |
| store | ✅ | create | ✅ closure | `Created` | tt_class_working_days_jnt, sys_activity_logs | CWD-01, 02, 03, 04, 08, 09, 11, 12, 13, 27 |
| show | ✅ | view | — | — | — | CWD-12, 22, 23 |
| edit | ✅ | update | — | — | — | CWD-12, 21, 23 |
| update | ✅ | update | ✅ closure | `Updated` | tt_class_working_days_jnt, sys_activity_logs | CWD-01, 02, 03, 04, 08, 09, 12, 13, 27 |
| destroy | ✅ | delete | ✅ closure | `Trashed` | tt_class_working_days_jnt, sys_activity_logs | CWD-01, 03, 04, 12 |
| trashedClassWorkingDay | ✅ | restore | — | — | — | CWD-22 |
| forceDelete | ✅ | forceDelete | ✅ closure | `Deleted` | tt_class_working_days_jnt, sys_activity_logs | CWD-01, 03, 04, 12, 28 |
| restore | ✅ GET | restore | ✅ closure | `Restored` | tt_class_working_days_jnt, sys_activity_logs | CWD-01, 03, 04, 10, 12 |
| toggleStatus | ✅ | update | ✅ closure | `Toggled` | tt_class_working_days_jnt, sys_activity_logs | CWD-01, 03 |
| eventFeed | ✅ GET | viewAny | — | — | — | CWD-24 |
| workingDayFeed | ✅ GET | viewAny | — | — | — | CWD-24 |
| ajaxStore | ✅ | create | ✅ closure | `Created` | tt_class_working_days_jnt, sys_activity_logs | CWD-05, 08, 13, 14, 18, 19, 20, 25, 27 |
| ajaxDestroy | ✅ | delete (inside try) | ✅ closure | `Deleted` | tt_class_working_days_jnt, sys_activity_logs | CWD-01, 03, 06, 12, 28 |
| ajaxInitialize | ✅ | create (inside try) | ✅ closure | `Created` / `Updated` | tt_class_working_days_jnt, sys_activity_logs | CWD-01, 03, 05, 06, 08, 13, 14, 19, 20, 29 |

**Tables each mutation SHOULD touch, before counting what it does:** every mutation below writes the `tt_class_working_days_jnt` row plus one audit row (`sys_activity_logs`, because `activityLog()` is a second table). All of them do both. No transaction lives in a service — this controller has **no service and no job**; every closure is in the controller.

## 6. Findings

### F1 — Errors
#### CWD-01 · M · ERR-00 (D1) — eight methods still carry a controller `try/catch` that D2 does not allow
**Where:** `store:78-131` · `update:190-245` · `destroy:255-280` · `forceDelete:304-326` · `restore:336-360` · `toggleStatus:379-401` · `ajaxDestroy:668-700` · `ajaxInitialize:710-818`
```php
} catch (ModelNotFoundException $e) {
    // Rule A1: a missing record must stay a 404. …
    throw $e;
} catch (\Throwable $e) {
    Log::error('ClassWorkingDayController::store failed', ['error' => $e->getMessage()]);
    return back()->with('error', 'The operation could not be completed.');
}
```
**Evidence:** the 2026-10-10 pass put the allowed D2 shape in **`ajaxStore` only** (`catch (\DomainException)` at `:640` with the ERR-01 comment). These eight still wrap their body in `try { … }`. D2 allows only a `\DomainException` business message, a truncate-then-rebuild catch, a `SnapshotProtectionException`, or a service `report($e)` — none applies. Scanner: `ERR-02 H ×2`, `AUTH-02 M ×2`, plus the eight catches.
**Consequence:** errors are rendered twice (local catch + the central handler in `bootstrap/app.php`); the local catch hides the real exception class and makes the 404/403/422 rethrow list something a future edit can forget. Fixing this removes four now-dead imports (`AuthorizationException`, `ModelNotFoundException`, `ValidationException`, `HttpExceptionInterface`).

#### CWD-02 · H · ERR-02 — `validate()` runs inside the try, so ValidationException is swallowed into a generic flash
**Where:** `store:80` inside `try` at `:78`; `update:194` inside `try` at `:190`
```php
try {
    return DB::transaction(function () use ($request) {
        $validated = $request->validate([ 'academic_session_id' => 'required|integer|exists:…', … ]);
```
**Evidence:** scanner ERR-02 H at `store:78` and `update:190`. Unlike `ajaxDestroy`/`ajaxInitialize`, this catch does **not** rethrow `ValidationException`, so `\Throwable` catches it and converts it into a flash. `role="H-only"` is not the case here: this is a real swallow.
**Consequence:** a bad submit to `POST/PUT /class-working-day` shows "The operation could not be completed." instead of the field errors, so the admin cannot see which input is wrong. Reachable only by direct submit (the pages are orphan, CWD-23) but the store endpoint is live.

#### CWD-03 · M · ERR-05 — the local catches log only `$e->getMessage()`
**Where:** `:128`, `:242`, `:277`, `:323`, `:357`, `:392`, `:694`, `:812`
```php
Log::error('ClassWorkingDayController::store failed', ['error' => $e->getMessage()]);
```
**Evidence:** scanner ERR-05 M at all eight sites; no `report($e)` and no exception object is passed.
**Consequence:** the stack trace is discarded, so a production failure cannot be traced from the log.

### F2 — Transactions and audit
#### CWD-04 · M · TXN-05 — the redirect and flash are built inside the transaction closure
**Where:** `store:118-120`, `update:232-234`, `destroy:267-269`, `forceDelete:313-315`, `restore:347-349`
```php
return redirect()
    ->route('timetable-foundation.menu.timetableMasters', ['tab' => 'class-working-days'])
    ->with('success', flash('created.class_working_day'));
// the redirect IS the closure's return value
```
**Evidence:** the response is built inside `DB::transaction(...)`. Scanner TXN-05 M ×5.
**Consequence:** the success flash is queued before the commit. If the commit fails, the next page can still show "Class Working Day was created successfully." for a row that does not exist. Fix: the closure returns the model; build the redirect after it.

#### CWD-05 · M · TXN-06 — the upsert is check-then-act with no lock and no unique-index handling
**Where:** `ajaxStore:591-617` (`withTrashed()->…->first()` then `create`/`update`) · `ajaxInitialize:748-781` (same pattern)
**Evidence:** `first()` then `create()` with no `lockForUpdate()`; the unique index `uq_class_working_day (class_id, section_id, working_day_id)` treats NULLs as distinct, so two concurrent class-level (`section_id = NULL`) requests can both see "no existing row" and both insert.
**Consequence:** a double-click or two admins on the same class/day can create duplicate class-level rows; the one-to-one "one row per class+day" invariant is then broken. A lock or an `insertOrIgnore`/unique-catch closes it.

### F3 — Authorization
#### CWD-06 · M · AUTH-02 — `Gate::authorize` runs inside the try (2 methods)
**Where:** `ajaxDestroy:669` (try at `:668`) · `ajaxInitialize:711` (try at `:710`)
**Evidence:** scanner AUTH-02 M at `:668` and `:710`. Each authorizes before loading its record, which is correct; the problem is only that the call is inside the `try`.
**Consequence:** a 403 stays a 403 only because each catch rethrows `AuthorizationException`. If a future edit widens a catch, an authorization failure silently becomes a generic 500. Authorize before the `try`.

#### CWD-07 · L · AUTH-04 / AUTH-06 — `ClassWorkingDayPolicy` is registered but never consulted
**Where:** `TimetableFoundationServiceProvider.php:126` `Gate::policy(ClassWorkingDay::class, ClassWorkingDayPolicy::class)`; every gate in the controller passes a permission **string** (`Gate::authorize('tenant.timetable-foundation.class-working-day.…')`).
**Evidence:** no `$this->authorize('…', $classWorkingDay)` or `can:` middleware exists for this model, so none of the policy's seven methods is ever reached. The seven permission strings are repeated as literals across 16 methods.
**Consequence:** dead code that looks active; a permission change must be made in a string literal, not one place. Module-wide pattern (see §7) — same as ATC-14 / WDY-17.

### F4 — Validation
#### CWD-08 · M · VAL-02 — validation lives inline in the controller, not a FormRequest
**Where:** `store:80-101`, `update:194-215`, `ajaxStore:539-554`, `ajaxInitialize:713-719`
**Evidence:** `ls Modules/TimetableFoundation/app/Http/Requests/` → 14 files, **no `ClassWorkingDayRequest`**. Every rule set is a literal `$request->validate([...])`. The single-field `toggleStatus` toggle (`:370`) is the allowed exception.
**Consequence:** the rule block is duplicated in `store` and `update` (CWD-13) and is unavailable to any other entry point, so the two can drift.

#### CWD-09 · M · VAL-04 — the resource `store`/`update` have no uniqueness rule and no soft-delete handling
**Where:** `store:103` `ClassWorkingDay::create([...])` · `update:217` `$classWorkingDay->update([...])`
**Evidence:** the controller validates `exists:` on the FKs but never checks `(class_id, section_id, working_day_id)`. Live index `uq_class_working_day (class_id, section_id, working_day_id)` is a plain UNIQUE that includes soft-deleted rows. There are 0 trashed rows today → latent.
**Consequence:** creating a class working day that already exists (live **or** trashed) raises SQL 1062, which CWD-01/02 turn into "The operation could not be completed." instead of "that class/day already exists — restore it instead."

### F5 — Routes
#### CWD-10 · H · RTE-01 — Restore runs over a GET request
**Where:** `routes/web.php:313` `Route::get('/class-working-day/{id}/restore', [ClassWorkingDayController::class, 'restore'])->name('class-working-day.restore');`
**Evidence:** `route:list` shows `GET|HEAD …/{id}/restore`. The only caller is `trash.blade.php:45` via `<x-backend.table.action-trashed>`, which derives the HTTP verb from the route, so changing the verb needs no blade edit.
**Consequence:** GET has no CSRF protection, so a link preview or a prefetcher can restore a trashed class working day. (Same defect as ATC-05; a route change, so a DECISION.)

### F6 — Controller shape
#### CWD-11 · M · CTL-02 — two methods exceed 80 lines
**Where:** `ajaxStore` 127 lines (`:535-661`), `ajaxInitialize` 112 lines (`:708-819`)
**Evidence:** scanner CTL-02 M at `:535` and `:708`. No method exceeds 150.
**Consequence:** the per-class × per-section × per-date loops are hard to review; extraction is deferred (D3).

#### CWD-12 · M · CTL-03 — no route model binding on seven methods
**Where:** `show:137/141`, `edit:149/153`, `update:186/192`, `destroy:251/257`, `forceDelete:300/306`, `restore:332/338`, `ajaxDestroy:666/672`
```php
public function show($id) { … $classWorkingDay = ClassWorkingDay::findOrFail($id); }
```
**Evidence:** only `toggleStatus` binds (`ClassWorkingDay $classWorkingDay`); the resource routes carry `{class_working_day}` but the methods take a raw `$id`. Scanner CTL-03 M ×7.
**Consequence:** the model is loaded twice and the 404 path is hand-written in seven places; route model binding removes both.

#### CWD-13 · M · CTL-05 / SVC-04 — the write logic is copy-pasted between methods
**Where:** validation array `store:80-101` = `update:194-215`; payload `store:103-111` = `update:217-225`; upsert lookup `ajaxStore:591-597` = `ajaxInitialize:748-754`; upsert payload `ajaxStore:599-606` = `ajaxInitialize:763-770`.
**Evidence:** scanner CTL-05 M at `:80` and `:103` ("identical 7-item array literal repeated 2×"). The two ajax methods implement the same upsert with only the "clear existing" step differing.
**Consequence:** a rule change (e.g. the section_id key) must be made in four places or the two write paths disagree — which is exactly what CWD-27 reports.

#### CWD-14 · M · CTL-06 — business logic lives in the controller
**Where:** `ajaxStore:562-636` (per-date WorkingDay lookup, day-type validation, per-class/section upsert, audit) · `ajaxInitialize:737-802` (clear-existing, per-date copy-down, upsert, audit)
**Evidence:** both are 100+ line loops with domain rules in the controller; there is no `ClassWorkingDayService` or action class.
**Consequence:** importers, APIs or a future scheduler cannot reuse the "one working day exists / day type copied from parent" rules, so an alternative writer can store rows that violate them. Extraction is a DECISION (D3 spirit).

#### CWD-15 · L · CTL-04 — no return types on any of the 16 public methods
**Where:** `index:30`, `create:40`, `store:74`, `show:137`, `edit:149`, `update:186`, `destroy:251`, `trashedClassWorkingDay:286`, `forceDelete:300`, `restore:332`, `toggleStatus:366`, `eventFeed:418`, `workingDayFeed:473`, `ajaxStore:535`, `ajaxDestroy:666`, `ajaxInitialize:708`
**Evidence:** scanner CTL-04 L ×16.
**Consequence:** the declared contract (`View` / `RedirectResponse` / `JsonResponse`) is implicit.

### F7 — Models
#### CWD-16 · L · MDL-04 — four relations have no return type
**Where:** `ClassWorkingDay.php:84` `academicSession()`, `:89` `class()`, `:94` `section()`, `:99` `workingDay()` (only `dayType(): BelongsTo` at `:111` is typed)
**Evidence:** grep of `function ` in the model; scanner flagged the model under CTL-04/MDL-04.
**Consequence:** static analysis cannot confirm the relation type. Otherwise the model is clean: `$fillable` declared (no `$guarded = []`), `$casts` cover every boolean/date/int, `$table = tt_class_working_days_jnt` exists in the migration, `SoftDeletes` present and the table has `deleted_at`. Relationships resolved in tinker: `class` → `Nursery`, `dayType` → `Working Day`, `workingDay` → `1`, `academicSession` → `Session - 2020-21`.

#### CWD-17 · M · MDL / DDL-drift — the live unique key departs from every DDL version, and the migration comment states the opposite
**Where:** `database/migrations/tenant/2026_06_16_152556_create_tt_class_working_day_jnt_table.php:46` · live `SHOW CREATE TABLE` · DDL `pgdatabase/2-DDL_Tenant_Enhanced/Timetable/Timetable_DDL_v8.1.sql:360`
```php
// migration:46  $table->unique(['class_id', 'section_id', 'working_day_id'], 'uq_class_working_day');
// migration:42-45 comment: "⚠ MySQL treats NULLs as distinct … Both are guarded in
//   ClassWorkingDayController's upsert lookup."
// DDL v7.8/v7.9/v8.1: UNIQUE KEY `uq_class_working_day` (`class_id`, `working_day_id`)
```
**Evidence:**
- `SHOW CREATE TABLE tt_class_working_days_jnt` → `UNIQUE KEY uq_class_working_day (class_id, section_id, working_day_id)`, plus `idx_class_working_day_day_type` which the DDL does not define.
- `grep -n "uq_class_working_day"` in `Timetable_DDL_v7.8.sql`, `v7.9.sql`, `v8.1.sql` → all three define the **two-column** key.

**Consequence:** the DDL cannot recreate the live table. Applied as written, DDL v8.1 makes a class-level row (`section_id = NULL`) and a per-section row for the same class/day collide, breaking the "class default + section override" model the controller and `ajaxStore` rely on. The migration's claim that v7.9's key includes `section_id` is false in all three DDL files. Per the rulebook the DDL wins — this is a drift, not necessarily a code bug.

### F8 — Services and jobs
#### CWD-18 · H · deep read #8 / F8 — the "send notification" feature is dead: the event has no listener
**Where:** `ajaxStore:648-654`
```php
if (($validated['send_notification'] ?? false) && ! empty($createdRecords)) {
    event(new SpecialDayAssigned(
        array_map(fn ($r) => $r->toArray(), $createdRecords),
        $validated['notification_channels'] ?? [],
        auth()->user(),
    ));
}
```
**Evidence:**
- `grep -rn "SpecialDayAssigned" --include=*.php .` (excluding vendor) returns **only** the event class and this dispatch. No listener, no `Event::listen`, no entry in any `Listeners/` directory.
- `ajaxStore:551-553` validates `send_notification` and `notification_channels.*` as `in:email,sms,in_app`, so the UI invites the choice.
- The request then returns `{"status": true, "message": "… class working day(s) saved."}`.

**Consequence:** an admin marks a date, ticks "Send Notification" and picks email/SMS/in-app; the save reports success, but no notification is ever delivered and no error appears. Either register a listener or drop the option.

### F9 — Queries and performance
#### CWD-19 · H · QRY-01 — queries inside the per-date / per-class loops (N+1)
**Where:** `ajaxStore:567` `WorkingDay::where('date', $date->toDateString())->first()` (once per date); `ajaxStore:591` `ClassWorkingDay::withTrashed()->…->first()` (once per class × section × date); `ajaxInitialize:741` `ClassWorkingDay::where(...)->forceDelete()` (once per class); `ajaxInitialize:748` `withTrashed()->…->first()` (once per class × section × working day).
**Evidence:** scanner QRY-01 H at `:567`, `:591`, `:741`, `:748`. The live table holds **4,620** rows; `ajaxInitialize` iterates every working day of the current session for each class × section.
**Consequence:** "Initialize" over, say, 10 classes × 3 sections × 200 working days issues ~6,000 SELECTs plus 6,000 single-row writes, one at a time. Pre-load the working days and the existing children into keyed collections and bulk-write.

#### CWD-20 · M · QRY-07 — per-row writes inside the loops
**Where:** `ajaxStore:609` `->restore()`, `:610` `->update()`, `:613` `create()` · `ajaxInitialize:773` `->restore()`, `:774` `->update()`, `:778` `create()`
**Evidence:** scanner QRY-07 M ×6.
**Consequence:** every row is its own INSERT/UPDATE; a bulk `upsert()` or chunked `insert()` would collapse the work. (Pairs with CWD-19; one coherent fix.)

#### CWD-21 · M · QRY-15 — the create/edit forms load every working day unfiltered
**Where:** `create:56` `WorkingDay::orderByDesc('id')->get()` · `edit:167` (same)
**Evidence:** scanner QRY-15 M at `:56` and `:167`. No date/session filter, no column selection.
**Consequence:** the form pulls the entire `tt_working_days` table (365 rows today, one full session **per** year) just to fill one `<select>`; it should be filtered to the selected academic session and limited to `id, date`.

### F10 — Views
#### CWD-22 · H · VIEW / deep read — the Class column is always "—": the blades read `schoolClass`, a relation that does not exist
**Where:** `resources/views/class-working-day/show.blade.php:28` `{{ $classWorkingDay->schoolClass?->name ?? '—' }}` · `resources/views/class-working-day/trash.blade.php:29` `{{ $cwd->schoolClass?->name ?? '—' }}`
**Evidence:**
- `ClassWorkingDay.php` defines `class()` (`:89`), `section()`, `workingDay()`, `dayType()`, `academicSession()` — **no `schoolClass()`** and `BaseModel` has none.
- Tinker: `$c->class?->name` → `'Nursery'`; `$c->schoolClass` → `NULL`. Eloquent does not error on an unknown property, it returns null forever.
- The model itself warns about this exact trap (`TimetableCell.php:101-104`).
**Consequence:** on both the detail page and the trash page the Class column silently shows "—" for every row; the admin cannot see which class a working day belongs to.

#### CWD-23 · L · VIEW / CTL — create, show and edit pages are orphaned; the create route is a second create surface
**Where:** `create:40-69` + `create.blade.php` (155) · `show:137-144` + `show.blade.php` (91) · `edit:149-181` + `edit.blade.php` (154)
**Evidence:** the live UI is the `class-working-days` tab partial (`_list.blade.php`), which calls only `ajaxStore`/`ajaxDestroy`/`ajaxInitialize`/`eventFeed`/`workingDayFeed`. `grep -rn "class-working-day\.\(create\|show\|edit\)"` across blades/controllers finds the route names **only inside their own blades**. `create.blade.php` posts to `store`, so the resource form is a second create path beside the calendar.
**Consequence:** the pages are reachable by URL but linked from nowhere; the create page can drift from the calendar's rules (CWD-27). Same shape as ATC-17b.

#### CWD-24 · L · VAL-05 / VIEW — the calendar feeds do not validate `start`/`end`
**Where:** `eventFeed:422-431` and `workingDayFeed:477-483`
```php
$start = $request->input('start'); $end = $request->input('end');
…->whereBetween('date', [$start, $end])…
```
**Evidence:** no `validate()` in either method; a missing bound yields `date BETWEEN NULL AND NULL` → `[]`.
**Consequence:** low — FullCalendar always sends ISO bounds; a malformed range silently returns an empty feed rather than a 422.

### F11 — Security and tenancy
#### CWD-25 · M · SEC-03 — hard-coded academic-session fallback `?? 1`
**Where:** `ajaxStore:600` `'academic_session_id' => $academicSession?->id ?? 1,`
**Evidence:** `ajaxStore:556` reads `OrganizationAcademicSession::where('is_current', true)->first()`; when none exists, the row is written with `academic_session_id = 1` and no error. Live proof of the drift this invites: all **4,620** rows carry `academic_session_id = 1` (Session 2020-21) while the current session is id 7 (2026-27). `ajaxInitialize:722-724` handles the same case correctly (`422`).
**Consequence:** on a tenant with no current session, the calendar silently files class days under the wrong year. Return a 422 like `ajaxInitialize` instead.
**Clean:** `grep -n "env(" $C` → none; no secrets logged; tenant middleware present; no cache (TEN-02 n/a).

### F12 — Style
#### CWD-26 · L · STY — style debt across the in-scope files
**Evidence (scanner + read):**
- `ClassWorkingDayController.php` — `STY-01` (no `declare(strict_types=1)`); `STY-04` (emoji `⚠`/`⛔` in comments at `:444`, `:501`, `:584`, `:756`); `CTL-04` (CWD-15). Pint is clean: `vendor/bin/pint … --test --format agent` → `{"result":"passed"}`.
- `ClassWorkingDay.php` — `STY-01`.
- `ClassWorkingDayPolicy.php` — `STY-01`.
**Consequence:** consistency debt only. Grouped as one item per file in the plan.

### F13 — Deep read
#### CWD-27 · M · deep read — the resource `store`/`update` duplicate the AJAX path with weaker rules
**Where:** `store:80-111` / `update:194-225` vs `ajaxStore:562-636`
**Evidence:** the resource path calls `ClassWorkingDay::create()/update()` directly. It (a) never checks that a `tt_working_days` row exists for the submitted `date` (`ajaxStore:567-574` refuses otherwise), (b) never checks that `date` matches the bound `working_day_id` (the unique key is `(class_id, section_id, working_day_id)` — `date` is not part of it), and (c) has no upsert/restore handling. Live data currently shows 0 mismatches, so it is latent.
**Consequence:** a direct POST can create a class working day for a date with no configured working day, or with a `date` that disagrees with its `working_day_id`; the calendar then shows a class chip on a date the school never configured. Align the resource path with `ajaxStore` or retire it (CWD-23).

#### CWD-28 · M · deep read — `forceDelete` accepts a live (non-trashed) row
**Where:** `forceDelete:306` `$classWorkingDay = ClassWorkingDay::withTrashed()->findOrFail($id);` (and `ajaxDestroy:672` operates on any live id by design)
**Evidence:** `withTrashed()` matches live rows, so `DELETE /class-working-day/{id}/force-delete` purges a row that was never trashed. `restore:338` correctly uses `onlyTrashed()`. FK children of `tt_class_working_days_jnt`: **NONE** (`information_schema.KEY_COLUMN_USAGE` → no rows), so there is no cascade — the blast radius is the single row.
**Consequence:** a crafted DELETE bypasses the trash and permanently removes a live row with no warning. Use `onlyTrashed()->findOrFail()`.

#### CWD-29 · L · deep read #7 — the initialize message says "created" for rows that were updated
**Where:** `ajaxInitialize:776,782,784` (`$event = 'Updated'` / `'Created'`; `$created++` for both) and `:806` `"{$created} class working days created from working days calendar."`
**Evidence:** the counter is incremented for both branches, so the message counts restored/updated rows as "created".
**Consequence:** the toast over-reports "created" when the run only refreshed existing rows.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **Unreachable policies (module-wide):** every policy in TimetableFoundation is unreachable because gates pass strings (CWD-07). Same pattern as ATC-14 and WDY-17; a module-level decision.
- **`OrganizationAcademicSession` (SchoolSetup):** common; resolves. `where('is_current', true)` → session 7 (2026-27, 2026-04-01…2027-03-31). The tenant's 4,620 class-working-day rows all carry session id 1 — a data-drift observation, repair out of scope.
- **`WorkingDay` / `DayType` models:** owned by the WorkingDayController and DayTypeController reports. This controller only reads them; the `dayType1_id` copy-down and the `display_color`/`background_color` accessors resolved in tinker. Not re-audited.
- **`_list.blade.php` (masters tab partial):** rendered by `TimetableFoundationController`, not by this controller. Checked for this controller's data sinks (it consumes `eventFeed`/`workingDayFeed` via `extendedProps.dayTypeName` into `textContent`); no user-controlled HTML sink found at the lines checked. Full VIEW audit belongs to that controller's report.
- **`ControllerAuthTest`:** references this controller and the `ClassWorkingDay` model. Not edited (D4); the CWD-01/06/10 changes will interact with its auth-exempt lists — the team verifies.
- **DDL v8.1 (`Timetable_DDL_v8.1.sql`):** also names the session FK as `tt_academic_session.id`, which does not exist; the app correctly uses `sch_org_academic_sessions_jnt`. Cross-cutting DDL-drift, not fixed here.

## 8. Not covered, and why

- **Runtime behaviour:** no browser and no test run (D4). Every finding is static analysis or a read-only SQL / tinker probe.
- **Blade compilation of the four pages and the tab partial:** not compiled here (D4). They are source-level reads; CWD-22 is confirmed by the tinker property probe.
- **Pint edit:** only `--test` was run (read-only). The controller is Pint-clean; the model and policy were not Pint-tested.
- **`ClassWorkingDayRequest`:** does not exist; CWD-08 recommends creating one, which is a fix, not an audit.
- **The other controllers that write `tt_class_working_days_jnt`** (`PeriodSetController`, `WorkingDayController`, `TimetableFoundationController`, `PeriodConfigController`) and seeders/importers were not audited; CWD-05/CWD-09's risk comes from them.
- **Data repair of the 4,620 rows carrying `academic_session_id = 1`** (CWD-25): reported only.
