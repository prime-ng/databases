# Status — TimetableFoundation / RoomAvailabilityController

**Fixed:** 2026-10-14 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — all 12 items ticked. Nothing left open.

---

## 1. Pre-applied 2026-10-10

Copied from `final-audit-reports/tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md` (line 27):

| File | Pre-applied change | Found on 2026-10-14 |
|---|---|---|
| `RoomAvailabilityController` | `generate()`: try/catch removed, `$count = DB::transaction(...)` kept, ERR-00 comment added. Pint applied | ⚠ **Not present.** `generate()` still had its `try { … } catch (\Exception $e)`, and the catch flashed `'Generation failed: ' . $e->getMessage()` to the user. The last commit to touch the file is `3eefd728e` (2026-08-20). The audit's §1 and §4 repeated the ledger's claim ("confirms the change is complete") without it being true. Fixed in this pass under RAV-01. |

---

## 2. Applied

All in `Modules/TimetableFoundation/app/`.

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| RAV-01 | `Http/Controllers/RoomAvailabilityController.php:36-60, 76-122` | No try/catch in either method. Each write runs in one `DB::transaction`, with `activityLog` inside it. `generate()` no longer shows the raw exception text — that was the pre-applied item that had never landed (§1). | `grep -nE "try \{\|getMessage\|Log::" <controller>` | no matches |
| RAV-03 | same | The gate is the first statement of each method, outside any try. Resolved by RAV-01. | read | `Gate::authorize` on lines 38 and 78 |
| RAV-04 (a) | `…Controller.php:62-122` | Status comes from `ResourceRatioService::roomRatios()`, the same per-room supply and demand the Ratio tab shows. Mapping: over capacity → `Unavailable`; exactly full → `Partially Available`; spare capacity or no demand → `Available`. The old maths is gone: supply from the slot-requirement row count or 365×8, and `ratio >= 1.2` = Available. The flash text "Room availability ratio computed. N room(s) updated." is unchanged, and so is the button. | rolled-back replay, then compare each stored status with `ResourceRatioService::bandKey($row, true)` | 69 rows, **0 mismatches** |
| RAV-07 | same | One grouped `UPDATE … WHERE room_id IN (…)` per status (at most 3) replaces one `update()` per row. Covered by RAV-04 (a). | read | 3 statements at most |
| RAV-08 | same | The hard-coded `?? 1` "one room" fallback is gone; supply comes from the service. Covered by RAV-04 (a). | `grep "?? 1"` | no matches |
| RAV-02 (b) | `Services/RoomAvailabilityService.php:24-30` | Generate locks the active `sch_rooms` rows with `lockForUpdate()`, inside the controller's transaction. Two concurrent clicks therefore run one after the other. No schema change. | replay Generate twice | 69 rows, 0 duplicate `room_id` |
| RAV-06 | `Services/RoomAvailabilityService.php:97-104` | `updateEligibleRoomCount()` now uses the real columns: `available_for_full_timetable_duration` and `rooms_type_id`. | `grep` | old names gone |
| RAV-05 (b) | `Models/RoomAvailabilityDetail.php:16-23` | No trait added. A docblock records that `deleted_at` is unused on purpose, because AvailabilityCanvasService rebuilds the grid with a plain delete. | read | present |
| RAV-09a | `…Controller.php` | `declare(strict_types=1)`; `: RedirectResponse` on both methods; unused `$request` parameter and 8 unused imports removed. | `php -l`, Pint | clean, passed |
| RAV-09b | `Services/RoomAvailabilityService.php` | `declare(strict_types=1)`; `\Log::info` → imported `Log::info`. Pint fixed chaining and alignment. | Pint | fixed, then clean |
| RAV-09c | `Models/RoomAvailabilityDetail.php` | `declare(strict_types=1)`; `Builder` parameter and return types on the four scopes. Pint removed one unused same-namespace import. | `php -l`, `class_exists` | clean, OK |
| RAV-09d | `Models/RoomAvailability.php:95` | The stale `roomType()` comment now names `sch_rooms_type` / `Modules\SchoolSetup\Models\RoomType`. ⚠ Pint, run on the touched file per the workflow, also changed formatting: cast alignment, import order, two redundant same-namespace imports removed, and `RoomType` imported. Formatting only; `git diff` shows no logic change. | `git diff` | 24+ / 25− lines, all whitespace or imports |

### 2.1 Applied beyond plan

| What | Where | Why |
|---|---|---|
| The ratio flash said "0 room(s) updated" after a correct run | `…Controller.php:94-100` | MySQL's affected-row count skips rows whose status was already right. The count is now the number of rooms recomputed (69). The flash literal the Dusk suites assert ("Room availability ratio computed") is unchanged. |
| `activityLog('RoomAvailabilityRatioComputed')` now records `by_status` | `…Controller.php:109-113` | So the audit trail shows how many rooms landed in each status, not just the total. |

---

## 3. Not applied

Nothing — every item was ticked.

| Rejected option | Why |
|---|---|
| RAV-02 (a), the unique index on `room_id` | Re-asked after the DDL check. `Timetable_DDL_v7.8.sql`'s only unique key on this table is `uq_ra_class_wise (room_id, rooms_type_id, class_id, section_id, subject_study_format_id)`. The schema is designed to hold several rows per room, so `unique(room_id)` would contradict it (DDL wins). That key also does not stop the race, because its other columns are NULL on generated rows and MySQL treats NULLs as distinct. Tarun chose (b). No migration was written. |

---

## 4. Needs Tarun's hand

1. **Browser check** of `/timetable-foundation/resource-availability`:
   - On `?tab=room-availability`, click **Generate from Rooms**. Expect 69 rooms processed.
   - On `?tab=room-availability-ratio`, click **Regenerate Ratio**.
   - Confirm each room's Overall Status agrees with the Ratio tab's band: Over capacity → Unavailable, Exactly full → Partially Available, otherwise Available.
2. No migration and no permission sync are needed.

---

## 5. Unverifiable by this workflow (D4), and notes

- **The `Unavailable` and `Partially Available` branches are unexercised.** On the test tenant all 69 rooms have spare capacity or no demand, so the replay could only show `Available`. Both branches use the Ratio tab's own `is_over` flag and the same 0.001 tolerance as `isOver()`.
- **The `lockForUpdate()` guard** is proven by reading the code and by a sequential double run (0 duplicates). A true concurrent double-click was not simulated.
- **`can_be_assigned = false` rooms** are mapped by demand like any other room, exactly as the old code did. The tab shows `can_be_assigned` in its own column.
- **Dusk suites** `TtRoomRatioReportTest` and `TtRoomAvailabilityReportTest` post to both endpoints. They assert a valid ENUM status (never `Assigned`) and the flash literals, all of which are kept. They were not run (D4).
- **`updateEligibleRoomCount()` still has no production caller** (only a reflection unit test). RAV-06 makes it safe to call; nothing calls it yet.

---

## 6. Verification log

```
php -l   controller · service · RoomAvailability · RoomAvailabilityDetail → No syntax errors (after Pint)
vendor/bin/pint <4 files> --format agent → controller passed · service, both models fixed (formatting) · re-run passed
class_exists → OK ×4
route probe (APP_ROUTES_CACHE=/tmp/fa-nocache.php)
   POST room-availability/generate-ratio → generateRoomAvailabilityRatio exists
   POST room-availability/generate       → generate exists
kernel replay inside DB::beginTransaction … DB::rollBack (tenant test.localhost, user 1)
   generate        302  "Room availability generated successfully. 69 room(s) processed."  rows=69
   generate again  rows=69  duplicate room_id=0
   generate-ratio  302  "Room availability ratio computed. 69 room(s) updated."
   statuses        Available=69
   vs bandKey(row, rooms=true)   69 rows, 0 mismatches
   activity log    {"rooms":69,"by_status":{"Available":69,"Unavailable":0,"Partially Available":0}}
   rolled back     rows=0 (table was empty before)
grep controller → try { 0 · getMessage 0 · Log:: 0 · "?? 1" 0
```

---

## 7. Final state

**Status: FIXED** (2026-10-14). No open items. The H finding (RAV-04) is closed, and the Room Availability and Ratio tabs now read the same numbers.
