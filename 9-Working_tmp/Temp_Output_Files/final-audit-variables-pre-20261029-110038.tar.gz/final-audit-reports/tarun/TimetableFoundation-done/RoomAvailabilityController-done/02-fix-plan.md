# Fix Plan — TimetableFoundation / RoomAvailabilityController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/RoomAvailabilityController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
_None._

## 2. Fixes that arm a latent defect / wrong result (sequenced)
- [x] **RAV-04** · H · DECISION · SVC-04 / CTL-06 · `RoomAvailabilityController.php:54-93` — `generateRoomAvailabilityRatio()` is a second, older implementation of the room ratio that `ResourceRatioService` replaced on 2026-09-01; its weekly supply is `SlotRequirement` row count (43) or `365×8=2,920` from the calendar table, and it writes the pre-2026-09-01 reading (`ratio >= 1.2` = "Available") into a status column the Room Availability tab displays.
      (a) ⭐ Delegate: either call `ResourceRatioService`-derived supply/demand, or fix the arithmetic to the module's decided numbers (school days × teaching periods per day, `weeklyPeriods()`), and map the status to the current reading (`ratio < 1.0` = over-capacity → NOT "Available"). This makes RAV-07 and RAV-08 disappear too. ⚠ Verify the display blades in the TimetableFoundationController report when choosing option (a), so the stored status and the pane agree.
      (b) Stop writing the status at all: keep the method as a no-op / `abort(403)` with a NOT ROUTED comment (the Ratio tab already computes its own bands from the same data) — D5 spirit, smallest blast radius.
      (c) Leave as is; record the wrong statuses as accepted.
      ➜ Choice: (a) Reuse ResourceRatioService::roomRatios() per room; covers RAV-07 and RAV-08 (Tarun, 2026-10-14)

- [x] **RAV-06** · M · MDL/SVC · `RoomAvailabilityService.php:90, 94` — rename the two non-existent columns in `updateEligibleRoomCount()`: `available_for_full_timetable` → `available_for_full_timetable_duration` and `room_type_id` → `rooms_type_id`. No caller exists today; this is what arms the Phase 3.2 generator call that the docblock promises. Effort: S.

## 3. Errors & transactions (F1/F2)
- [x] **RAV-01** · M · ERR-00 (D1) / ERR-05 · `RoomAvailabilityController.php:50, 107-113` — remove the try/catch from `generateRoomAvailabilityRatio()`, same shape as `generate()`: `return DB::transaction(fn …)`; let the central handler render failures (JSON for AJAX callers). The current `AuthorizationException|ValidationException|HttpExceptionInterface` rethrow is ERR-02-correct but becomes unnecessary because the gate moves out of any try. Also removes RAV-03. Effort: S.
- [x] **RAV-02** · M · DECISION · TXN-06 · `RoomAvailabilityService.php:49-50` — concurrent double-submits of GENERATE can both insert a row for the same room because no unique index protects `room_id`.
      (a) ⭐ New additive migration adds `$table->unique('room_id', 'uq_ra_room_unique')` on `tt_room_availabilities` (the service's `updateOrCreate` matches on `room_id` only; class-wise rows are never written by this flow — pre-check that no duplicate `room_id` rows exist before running). ⚠ Migration is written, never run, by the fixer.
      (b) Keep the schema; add `lockForUpdate()` / a per-request guard in the service for the rare double-click.
      (c) Accept the race (idempotent in normal single-click use).
      ➜ Choice: (b) Lock the active sch_rooms rows inside the generate transaction. (a) was rejected after the DDL check: its only unique key is the 5-column uq_ra_class_wise, so unique(room_id) would contradict it (Tarun, 2026-10-14)

## 4. Authorization (F3)
- [x] **RAV-03** · L · AUTH-02 · `RoomAvailabilityController.php:52` — resolved by RAV-01 (the gate leaves the try). No separate change if RAV-01 is ticked; otherwise move `Gate::authorize` above the `try`. Effort: S.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **RAV-05** · M · DECISION · MDL — `RoomAvailabilityDetail.php` does not use `SoftDeletes` although the table has `deleted_at`; the sibling model does.
      (a) ⭐ Add the trait, then audit the two live writers: SmartTimetable's `AvailabilityCanvasService` `->delete()` (a rebuild — should become `forceDelete()`) and `TimetableFoundationController:2307`'s read (filters correctly once the trait exists). ⚠ SHARED — other-module service; explicit tick required, and the fixer must re-read both before editing.
      (b) Leave without the trait; record that `deleted_at` is unused dead schema.
      (c) Additive migration drops `deleted_at` from the detail table to match the model.
      ➜ Choice: (b) Leave it; deleted_at recorded as unused, with a note on the model (Tarun, 2026-10-14)

## 6. Queries & performance (F9)
- [x] **RAV-07** · M · QRY-07 · `RoomAvailabilityController.php:78-95` — if RAV-04 is not chosen as (b)/(c), replace the per-row `$ra->update()` loop with three grouped `RoomAvailability::where(...)->update([...])` calls (one per status bucket), or a single load + bulk `case` update. If RAV-04 (a) lands, this item is covered there. Effort: S.
- [x] **RAV-08** · M · SEC-03 · `RoomAvailabilityController.php:80` — replace `$countByType[$typeId] ?? 1` with a real answer: a room whose type has zero assignable rooms should get supply 0 and fall into the unavailable band; remove the hard-coded `1`. If RAV-04 (a) lands, this is part of that item. Effort: S.

## 7. Views (F10)
_None — this controller renders no views (see report §7 for the blades owned by TimetableFoundationController)._

## 8. Style (F12) — one item per file
- [x] **RAV-09a** · L · STY/CTL-04 · `RoomAvailabilityController.php` — add `declare(strict_types=1)`; add `: RedirectResponse` return types to `generate()` and `generateRoomAvailabilityRatio()`; drop the unused `$request` parameter (or remove the import if it becomes unused). Effort: S.
- [x] **RAV-09b** · L · STY · `RoomAvailabilityService.php` — add `declare(strict_types=1)`; change `\Log::info(` to the imported `Log::info(`. Effort: S.
- [x] **RAV-09c** · L · STY · `RoomAvailabilityDetail.php` — add `declare(strict_types=1)`; add return types to the scopes (`: Builder`). Effort: S.
- [x] **RAV-09d** · L · STY-04 · `RoomAvailability.php` — fix the stale `roomType()` comment ("references sch_room_type — verify model class name in SchoolSetup" → the real class `Modules\SchoolSetup\Models\RoomType`, table `sch_rooms_type`). ⚠ SHARED — model reachable by other flows; comment-only. Effort: S.

## 9. Deferred / decisions
- RAV-04, RAV-02 and RAV-05 are DECISION items in sections 2, 3 and 5 above. Tick each and write your choice after its `➜ Choice:`.