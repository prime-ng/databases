# Final Audit — TimetableFoundation / DayTypeController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/DayTypeController.php` (490 lines, 11 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 2 HIGH.**

The write paths are the best-shaped in the module: all six mutations run inside a `DB::transaction` closure with the activity log after the write, restore correctly re-activates, and no exception text ever reaches a user. But two things can destroy a real user's data, and both are on the permanent-delete path:

- **Delete Permanently works on a live day type.** It accepts a non-trashed id and checks no children. `tt_working_days` has a RESTRICT FK so a referenced type is blocked, but **`tt_class_working_days_jnt.day_type_id` (4,620 rows) has no FK at all** — a type referenced only there is purged silently and those rows are orphaned.
- **Restore runs over a GET request**, so a prefetcher or crawler can restore rows.

The worst finding is **DTC-12**, the force-delete on a live record. Two latent traps — a soft-delete × unique-index mismatch (DTC-03) and a broken `timetableTypes()` relation (DTC-09) — are not firing today. The controller is also the module's last hold-out of the pre-D1 error model (six try/catch blocks, logging only `getMessage()`).

The effort is about half a day. Six DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 2 | 6 | 5 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | DTC-01 | F8 Services/Jobs | clean — no service, job, event, mail or notification is named (`grep -nE 'Service\|Job\|Event\|Mail\|Notification\|dispatch\|event\('` → none) |
| F2 Transactions/Audit | clean — all six mutations use `DB::transaction(fn …)` with `activityLog()` after the write inside the closure | F9 Queries/Perf | clean — trash paginates 10, no N+1, no raw SQL |
| F3 Authorization | DTC-02 | F10 Views | DTC-10 |
| F4 Validation | DTC-03, DTC-04 | F11 Security/Tenancy | clean — no `env()`, no hard-coded ids, tenant+auth middleware present |
| F5 Routes | DTC-05 | F12 Style | DTC-11 |
| F6 Controller shape | DTC-06, DTC-07, DTC-08 | F13 Deep read | DTC-12, DTC-13 |
| F7 Models | DTC-09 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/DayTypeController.php` | controller | 490 | this report | ✅ whole class |
| 2 | `app/Http/Requests/DayTypeRequest.php` | FormRequest | 143 | this report (only this controller uses it) | ✅ whole class |
| 3 | `app/Models/DayType.php` | model | 193 | **this report (pre-assigned)** | ✅ |
| 4 | `app/Policies/DayTypePolicy.php` | policy | 44 | this report (claimed) | ✅ — unreachable, see DTC-02 |
| 5 | `routes/web.php` lines 171-177 | routes | — | this report | ✅ |
| 6 | `views/day-type/show.blade.php` | page | 67 | this report | ✅ |
| 7 | `views/day-type/edit.blade.php` | page | 88 | this report | ✅ |
| 8 | `views/day-type/trash.blade.php` | page | 87 | this report | ✅ |
| 9 | `views/day-type/_create-modal.blade.php` | partial | 22 | this report | ✅ |
| 10 | `views/day-type/_create-fields.blade.php` | partial | 83 | this report | ✅ |
| 11 | `views/day-type/create.blade.php` | page (orphan) | 91 | this report | ✅ — DTC-10 |
| 12 | `views/pages/partials/timetable-masters/day-types/_list.blade.php` | tab list | 96 | this report | ✅ |
| — | `x-backend.table.action`, `action-trashed`, `status-switch`, `x-backend.tab.search-bar`, `x-backend.tab.modal`, `x-backend.form.status-switch`, `button-submit`, `breadcrum`, `x-tenantcore::export-buttons` | shared components | — | common | props checked against their class components only |
| — | `Modules/SmartTimetable/.../partials/day-types/_list.blade.php`, `.../working-days/_list.blade.php` | other-module views | — | **other module (SmartTimetable)** | ↗ linked — see §7; they call `route('timetable-foundation.day-type.create')`, a route that no longer exists |
| — | `PeriodType` model | other module | — | [PeriodTypeController](../PeriodTypeController-done/01-report.md) | not reached — the controller never names it |

**Pre-applied 2026-10-10:** `DayTypeController.php` is **not** listed in `../PRE-APPLIED-2026-10-10.md`. The route file `routes/web.php` **is** listed (dead routes cleaned that day), but its Day Type block (171-177) was not touched by that pass. This audit reviewed the controller fresh.

## 4. Routes

```
GET|HEAD  timetable-foundation/day-type                                timetable-foundation.day-type.index         index
POST      timetable-foundation/day-type                                timetable-foundation.day-type.store         store
GET|HEAD  timetable-foundation/day-type/trash/view                     timetable-foundation.day-type.trashed       trashedDayType
POST      timetable-foundation/day-type/{dayType}/toggle-status        timetable-foundation.day-type.toggleStatus  toggleStatus
GET|HEAD  timetable-foundation/day-type/{day_type}                     timetable-foundation.day-type.show          show
PUT|PATCH timetable-foundation/day-type/{day_type}                     timetable-foundation.day-type.update        update
DELETE    timetable-foundation/day-type/{day_type}                     timetable-foundation.day-type.destroy       destroy
GET|HEAD  timetable-foundation/day-type/{day_type}/edit                timetable-foundation.day-type.edit          edit
DELETE    timetable-foundation/day-type/{id}/force-delete              timetable-foundation.day-type.forceDelete   forceDelete
GET|HEAD  timetable-foundation/day-type/{id}/restore                   timetable-foundation.day-type.restore       restore
```

Middleware on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified` (uncached `route:list --json`).

**Route registration order:** `Route::resource` (line 172) is registered **before** the custom trash/restore/force-delete routes (173-176) — the opposite of the module comment on the Shift block (162). It is nevertheless **safe**: the resource's only 3-segment GET is `{day_type}/edit`, so `/day-type/trash/view` and `/{id}/restore` are not captured. `route:list` proves all ten routes resolve. No RTE-06 defect.

**Unrouted public methods:** `create` (line 43). It is **already D5-compliant** — its body is `abort(403, '…')` under a `// NOT ROUTED — TM-05` comment (lines 45-50), and `Route::resource(...)->except(['create'])` removes the verb. No work needed. ⚠ A cross-cutting side effect is that two SmartTimetable blades still call `route('timetable-foundation.day-type.create')` directly — see §7.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ GET | viewAny | — | — | — (redirect to masters) | — |
| create | ❌ (D5 `abort(403)`) | none (abort) | — | — | — | — |
| store | ✅ POST | create (×2 — DTC-02) | ✅ closure (:80) | `Stored` (:92) | tt_day_types, sys_activity_logs | DTC-01, DTC-02 |
| show | ✅ GET | view | — | — | — | DTC-06, DTC-07 |
| edit | ✅ GET | update | — | — | — | DTC-06, DTC-07 |
| update | ✅ PUT | update (×2 — DTC-02) | ✅ closure (:177) | `Updated` (:190) | tt_day_types, sys_activity_logs | DTC-01, DTC-02, DTC-06, DTC-08 |
| destroy | ✅ DELETE | delete | ✅ closure (:246) | `Trashed` (:254) | tt_day_types, sys_activity_logs | DTC-01, DTC-06, DTC-13 |
| trashedDayType | ✅ GET | restore | — | — | — | — |
| forceDelete | ✅ DELETE | forceDelete | ✅ closure (:329) | `Deleted` (:333) | tt_day_types, sys_activity_logs | DTC-01, DTC-06, DTC-12 |
| restore | ✅ GET | restore | ✅ closure (:395) | `Restored` (:403) | tt_day_types, sys_activity_logs | DTC-01, DTC-05, DTC-06 |
| toggleStatus | ✅ POST | update | ✅ closure (:457) | `Toggled` (:462) | tt_day_types, sys_activity_logs | DTC-01 |

**Tables each mutation SHOULD touch:** every method is single-table CRUD — one `tt_day_types` row plus the `sys_activity_logs` audit row. No pivots or child tables are written. That makes TXN-01 trivially satisfied for store/update/restore/toggleStatus. `destroy` and `forceDelete` are the exception in the other direction: they should *account for* the children that point at the row (DTC-12 / DTC-13) — they check none.

Model/style findings (DTC-09, DTC-11) attach to files, not methods.

## 6. Findings

### F1 — Errors
#### DTC-01 · M · ERR-00 (D1) + ERR-05 — six methods still catch errors themselves and log only the message
**Where:** `DayTypeController.php:107-116` (store) · `:203-218` (update) · `:264-276` (destroy) · `:343-367` (forceDelete) · `:413-426` (restore) · `:477-488` (toggleStatus)
```php
} catch (\Throwable $e) {
    Log::error('DayType store failed', [
        'error' => $e->getMessage(),
        'code' => $request->input('code'),
    ]);
    return redirect()->back()->withInput()->with('error', flash('operation_failed.day_type'));
```
**Evidence:** `grep -nE 'catch|Log::|getMessage' DayTypeController.php` → 6 `catch (\Throwable)`, 4 `catch (ModelNotFoundException)` re-throws, 1 `catch (QueryException)`, and 7 `Log::…` blocks each passing `'error' => $e->getMessage()`. Scanner rule `ERR-05` fires at lines 108, 210, 269, 350, 359, 418, 478.
**Consequence:** every failed write loses its stack trace, and the controller uses two error models (local flashes here, the central handler everywhere else). Under D1 the `catch (\Throwable)` blocks should go. None of these catches is a D2 shape. The `catch (QueryException)` in `forceDelete` is the only source of the friendly "referenced by working days" message — it must be replaced by the DTC-12 child guard first.

**F1 rest — checked, clean:** no `$e->getMessage()` reaches a user (ERR-01) — every user string is a `flash()` key, none interpolates exception text; no swallowed write (ERR-06) — each catch redirects with an error; read-only methods (`index`, `show`, `edit`, `trashedDayType`, `create`) carry no try/catch (ERR-07).

### F2 — Transactions / Audit
**clean** — all six mutations run in one `DB::transaction(fn …)` closure (`:80, :177, :246, :329, :395, :457`), and `activityLog()` sits after the write inside that closure (`:92, :190, :254, :333, :403, :462`) with a verbatim event literal each time. Redirects/JSON are built **after** the closure returns, so TXN-05 is clean. No manual `beginTransaction` (TXN-02), no irreversible side effect (TXN-03). Evidence: `grep -n 'DB::\|activityLog' DayTypeController.php` → the 12 sites above. No private helper writes outside a transaction (there are no private methods).

### F3 — Authorization
#### DTC-02 · L · AUTH-04 — every write is authorized twice, and the policy is never consulted
**Where:** controller `:75` (store), `:171` (update) · `DayTypeRequest.php:66` · `TimetableFoundationServiceProvider.php:128`
```php
// controller
Gate::authorize('tenant.timetable-foundation.day-type.create');
// request authorize()
return $this->authorizeByCrudPermission('tenant.timetable-foundation.day-type');
```
**Evidence:** `AuthorizesTenantFeature::authorizeByCrudPermission()` does a real `Gate::allows('…​.create'|'…​.update')` (trait `:23-33`), and the FormRequest runs first. Exact-name probe against `sys_permissions` → all eight abilities present (`viewAny, view, create, update, delete, restore, forceDelete, export` = 8/8). `DayTypePolicy` is registered (`Gate::policy(DayType::class, DayTypePolicy::class)`, ServiceProvider:128) but every gate passes a **permission string**, so the policy is never consulted — module-wide pattern (so is the equivalent finding in the AcademicTerm and Activity reports).
**Consequence:** the double check adds no protection; the registered policy is dead code that looks active. Keep one (the FormRequest's), drop the controller's duplicate on store/update.

**Rest of F3 — checked, clean:** every routed method authorizes before it loads a record (`index:30, show:129, edit:145, store:75, update:171, destroy:241, trashedDayType:289, forceDelete:324, restore:390, toggleStatus:450`); `create` is unrouted so it has no gate (D5). The permission name is 4-part and appears identically on all four surfaces — controller, FormRequest `authorize()`, the blades' `permission=`/`permissions=` props, and `config/permissionslist.php:657`. No record-ownership rule is needed (tenant-wide masters).

### F4 — Validation
#### DTC-03 · M · VAL-04 + BUG-003 (latent) — re-creating a trashed code/name/ordinal crashes
**Where:** `DayTypeRequest.php:95-113` vs `database/migrations/tenant/2026_06_16_152600_create_tt_day_type_table.php:25-27`
```php
Rule::unique('tt_day_types', 'code')->ignore($dayTypeId)->whereNull('deleted_at'),
// migration
$table->unique('ordinal', 'uq_daytype_ordinal');
$table->unique('code',    'uq_daytype_code');
$table->unique('name',    'uq_daytype_name');
```
**Evidence:** `SHOW CREATE TABLE tt_day_types` → the three UNIQUE keys are **plain**; they do not account for `deleted_at`. The validator queries the SoftDeletes model, so a trashed row is invisible to it. Live data: 9 rows, **0 trashed** — so this is latent today. The request's own docblock (`:40-44`) acknowledges the gap ("tracked separately (Option C / additive ALTER migration)").
**Consequence:** if a user trashes `HOLIDAY` and then creates `HOLIDAY` again, validation passes and the insert raises SQL 1062, which the `catch (\Throwable)` turns into a generic "operation failed" toast — the user cannot tell why. Same trap as ATC-11.

#### DTC-04 · M · VAL-05 — `is_active` is required/nullable but never typed `boolean`
**Where:** `DayTypeRequest.php:119`
```php
'is_active' => $this->isMethod('POST') ? ['required'] : ['nullable'],
```
**Evidence:** the rule carries no `boolean` token. The controller ignores `$validated['is_active']` and re-reads the raw input through `$request->boolean('is_active')` (`:89, :186`), which coerces any non-`"1"`/`"true"`/`"on"` value to `false`.
**Consequence:** a direct POST of `is_active=abc` passes `required` and silently creates an **inactive** day type; the field is not actually validated as a flag.

**Rest of F4 — checked, clean:** `description` is read with `?? null` (VAL-03); no `$request->all()` / `except()` anywhere (VAL-01); no file upload (VAL-06); the only inline `$request->validate()` is the one-field AJAX toggle in `toggleStatus` (`:452-454`), which VAL-02 explicitly allows; there is no cross-field rule (VAL-07 n/a), so no FormRequest execution is required.

### F5 — Routes
#### DTC-05 · H · RTE-01 — Restore runs over a GET request
**Where:** `routes/web.php:174`
```php
Route::get('/day-type/{id}/restore', [DayTypeController::class, 'restore'])->name('day-type.restore');
```
**Evidence:** uncached `route:list` shows `GET|HEAD …/{id}/restore`. The only UI caller is `trash.blade.php:61` via `<x-backend.table.action-trashed>`, and that component derives the HTTP verb from the route itself (`app/View/Components/Backend/Table/ActionTrashed.php` + `action-trashed.blade.php:19-23`), so changing the verb needs **no blade edit**.
**Consequence:** GET carries no CSRF token, so a link prefetcher, crawler or `<img>` tag can restore a trashed day type with no user intent. Identical to ATC-05.

**Rest of F5 — checked, clean:** every route points at an existing method (RTE-02); `create` is deliberately unrouted and D5-compliant (RTE-03); all routes carry the tenant + auth middleware group (RTE-05); custom routes registered after `Route::resource` but no `{id}` capture occurs (RTE-06 proved by `route:list`).

### F6 — Controller shape
#### DTC-06 · M · CTL-03 — no route model binding on six methods
**Where:** `show:127` · `edit:143` · `update:169` · `destroy:239` · `forceDelete:322` · `restore:388`
```php
public function show($id)   { $dayType = DayType::findOrFail($id); … }
public function edit($id)   { $dayType = DayType::findOrFail($id); … }
```
**Evidence:** `grep -nE 'public function'` → these take `$id`; only `toggleStatus:448` binds (`DayType $dayType`, route `{dayType}`). The resource routes emit `{day_type}` and the custom routes `{id}`.
**Consequence:** more code and a hand-written `findOrFail` in six places; the mismatch between `{day_type}` and `$id` is the exact shape `module-finalization.md` §3.3.1 warns about (here it is harmless only because the parameter is not type-hinted). Converting cleanly needs the resource parameter renamed, which is a route change (DECISION).

#### DTC-07 · L · CTL-04 — no public method declares a return type
**Where:** all 11 public methods (`:28-448`)
**Evidence:** `grep -nE 'public function [a-zA-Z_]+\([^)]*\):' DayTypeController.php` → nothing; scanner `CTL-04` fires at every method.
**Consequence:** the IDE and the reader cannot see that `store`/`update`/`destroy`/`restore`/`forceDelete` return `RedirectResponse`, `show`/`edit`/`trashedDayType` return `View`, and `toggleStatus` returns `JsonResponse`.

#### DTC-08 · L · CTL-05 / MDL-06 — copy-pasted payload and controller-side normalisation
**Where:** `store:81-90` vs `update:178-187`
```php
'code' => strtoupper($validated['code']),
'name' => $validated['name'],
…
'is_active' => $request->boolean('is_active'),
```
**Evidence:** the two arrays are identical save for the comments; `strtoupper()` (`:82, :179`) and the checkbox coercion are data normalisation that MDL-06 wants in a model mutator/cast.
**Consequence:** the create and update rules can drift apart (one already carries a different `is_active` comment), and code casing is enforced in two places.

**Rest of F6 — checked, clean:** 490 lines / 11 methods — under CTL-01's 1,000-line, 25-method marks; longest method (`update`, ~50 lines) is under CTL-02's 80; no `dd()/dump()/ray()` (CTL-09); `request()` helper not used (CTL-08 — `Request` is injected); no `compact()` over 15 vars (CTL-07); no unused private methods (CTL-10).

### F7 — Models
#### DTC-09 · M · MDL-04 (relation does not resolve) — `timetableTypes()` queries a column that does not exist
**Where:** `DayType.php:182-192`
```php
* (tt_timetable_types.day_type_id -> tt_day_types.id).
public function timetableTypes()
{
    return $this->hasMany(TimetableType::class, 'day_type_id');
}
```
**Evidence:** tenant probe — `DayType::find(1)->timetableTypes()->limit(1)->get()` throws
`Illuminate\Database\QueryException: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'tt_timetable_types.day_type_id' in 'where clause'`.
`tt_timetable_types` has **no** `day_type_id` column (proved with `Schema::hasColumn`). The real table with that column is `tt_class_working_days_jnt` (4,620 rows). No caller exists: `grep -rn 'timetableTypes'` finds only `SchoolShift`'s relation, `TimetableType` queries, and view variables — never `$dayType->timetableTypes`.
**Consequence:** the relation is dead and broken; the docblock tells a future developer to reach the wrong table. Anybody who wires it to the calendar gets a 500. MDL-04's "relation resolves" check fails.

**Rest of F7 — checked, clean:** `$fillable` declared (`:25-33`), nothing sensitive, and it correctly omits the non-existent `created_by`; `$casts` cover every boolean/integer/date column that exists (`:38-46`); `$table = 'tt_day_types'` exists in the migration; `SoftDeletes` is present exactly because `deleted_at` exists; no `belongsToMany` pivot (MDL-03 n/a); no `$timestamps = false`.

### F8 — Services / Jobs
**clean** — `grep -nE 'Service|Job|Event|Mail|Notification|dispatch|event\(|ShouldQueue' DayTypeController.php` → none. The controller names no service, dispatches no job/event, sends no mail/notification, and performs its single-table CRUD inline.

### F9 — Queries / Performance
**clean** — the only list is `DayType::onlyTrashed()->orderBy('ordinal')->paginate(10)` (`:291-293`); every other read is a `findOrFail` by id; no query inside a loop, no `Model::all()`, no `->get()->count()`, no raw SQL. Evidence: `grep -nE '::all\(|->get\(\)|paginate|DB::raw|whereRaw|selectRaw|foreach|->map\(' DayTypeController.php`. The day-types **tab list** is queried by `TimetableFoundationController::timetableMasters` (`:461-466`): it paginates 10 with the distinct `dt_page` page name — that query belongs to another controller (§7).

### F10 — Views
#### DTC-10 · L · VIEW / orphan — `day-type/create.blade.php` is orphan; `_create-fields` duplicates its fields
**Where:** `views/day-type/create.blade.php` (91 lines)
**Evidence:** `grep -rn 'day-type\.create\|day-type/create'` finds no live caller — only docblock mentions in `_create-modal.blade.php:2` and `_create-fields.blade.php:2`. The create route is `except(['create'])`, so the page is unreachable and the live form is the modal (`_list.blade.php:96` → `_create-modal` → `_create-fields`).
**Consequence:** two copies of the create form exist and can drift; the orphan page is dead weight a future edit may mistakenly update.

**F10 rest — checked, clean:** no Blade queries (`grep` for `Model::`/`DB::`/`->where(` in the in-scope blades → none); no `{!! !!}` on user text; row actions use `x-backend.table.action` and trash rows use `action-trashed`; `status-switch` and `search-bar` receive 4-part permission strings; the Add button is `Route::has($url.'.create')`-guarded so it does not render; all `route()` names used in the blades resolve.

### F11 — Security / Tenancy
**clean** — no `env()` outside `config/`; no hard-coded ids or `?? 1`; no personal data in responses (`toggleStatus` returns only `success`, `is_active`, a flash string); no request-body or secret logging (`Log::` passes only `code`/`id`); every route sits inside the tenant + `auth` middleware group (proved from `route:list`). Evidence: `grep -nE 'env\(|->all\(\)|secret|password|token' DayTypeController.php` → none.

### F12 — Style
#### DTC-11 · L · STY-01 / STY-04 — one item per file (detailed in the fix plan)
**Evidence:** `head -4` on the four in-scope PHP files shows `declare(strict_types=1)` in none of them (`DayTypeController`, `DayTypeRequest`, `DayType`, `DayTypePolicy`). Scanner `STY-01` fires on all four; `STY-04` fires on `DayType.php:67, 86, 92` (the `⚠`/`⛔` marker convention). The controller's docblocks cite test names (`TtDayTypeTest::test_…`) and describe "Strict Rules" — harmless but stale. Pint is otherwise clean; the model's `display_color`/`background_color` accessors and the no-`color_code` decision are documented and correct.

### F13 — Deep read
#### DTC-12 · H · deep read — Delete Permanently accepts a live record and checks no children
**Where:** `DayTypeController.php:327-338`
```php
$dayType = DayType::withTrashed()->findOrFail($id);
DB::transaction(function () use ($dayType) {
    $dayType->forceDelete();
```
**Evidence:**
- `withTrashed()` matches **live** rows too, so `DELETE /day-type/{id}/force-delete` purges a non-trashed type without visiting the trash first.
- No child guard exists. Tenant FK list referencing `tt_day_types` (from `information_schema`):
  `tt_working_days.day_type1_id … day_type4_id` → NO ACTION (blocks the delete with SQL 1451).
- **`tt_class_working_days_jnt.day_type_id` has NO FK constraint** (proved: the info-schema query returns only the 4 `tt_working_days` rows). It holds **4,620** rows, all with a non-null `day_type_id`.
- Live reference counts: `tt_working_days` → day type 1 = 308 rows, day type 6 = 57; `tt_class_working_days_jnt` → 4,620 rows (distinct `day_type_id` = 1).

**Consequence:** a day type that has `tt_working_days` children is blocked (the `catch (QueryException)` shows a generic friendly flash); a day type referenced **only** by `tt_class_working_days_jnt` — the shape any newly added type can take — is deleted silently, orphaning 4,620-odd class-working-day rows on no warning. Same shape as ATC-03.

#### DTC-13 · M · deep read — a day type in use can be trashed
**Where:** `DayTypeController.php:243-259`
```php
$dayType = DayType::findOrFail($id);
DB::transaction(function () use ($dayType) {
    $dayType->is_active = false;
    $dayType->save();
    $dayType->delete();
```
**Evidence:** no usage check before the soft-delete. Trashing day type 1 affects 308 `tt_working_days` rows and 4,620 `tt_class_working_days_jnt` rows; `ClassWorkingDay::dayType()` then returns `null` (its model is documented as "FAILS CLOSED on a missing day type"), and the masters' Working Days / Class Working Days calendars lose their day-type labels.
**Consequence:** an admin can silently break the working-day calendar by trashing a type in active use; it is recoverable by restore, but nothing warns them. (Restore itself is correct — it sets `is_active = true`, `:399` — so the AcademicTerm ATC-07 bug is not repeated here.)

**Deep-read answers folded in:** (1) no write overwrites data it should not — single-column updates only; (2) nothing is deleted before its replacement is stored; (3) no duplicate implementation of one operation (the broken relation DTC-09 is unused, not a second writer); (4) soft-delete × unique trap **present** — DTC-03; (5) no material race — all writes are single-row by primary key; (6) no authorization hole — every routed method gates first; (7) no message lies — all eight `flash()` keys exist in `config/flash.php` and match their event; (8) dead features — DTC-09 (broken relation) and DTC-10 (orphan blade).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **⚠ HIGH — two SmartTimetable blades call a route that no longer exists.** `Modules/SmartTimetable/resources/views/smart-timetable/partials/day-types/_list.blade.php:42` and `.../working-days/_list.blade.php:45` both call `route('timetable-foundation.day-type.create')` directly (no `Route::has` guard). That route was removed by `DayTypeController`'s `except(['create'])`, so if those partials render, `route()` throws `RouteNotFoundException` → a 500 on the Smart Timetable page. They are `@include`d from `smart-timetable/index.blade.php:36-37` and `smart-timetable/master.blade.php:31,34`. The fix belongs to the SmartTimetable module (delete the Add-Type buttons or point them at `day-type.index`); it is the direct consequence of the DayType create route shape and deserves its own ticket.
- **Module-wide: policies are unreachable because gates pass permission strings.** `DayTypePolicy` (registered at `TimetableFoundationServiceProvider.php:128`) is never consulted; the same pattern is ATC-14 and ACT-06. Module-level decision.
- **`TimetableFoundationController::timetableMasters`** owns the day-types tab query (`:461-466`) and the `dt_page` pagination name; its correctness is that controller's report.
- **`ControllerAuthTest`** lists `DayTypeController` in `$fullyAuthorizedControllers` (`tests/Unit/ControllerAuthTest.php:87`) and expects every public method to contain an authorization call; `create()` has only `abort(403)`, and `DayTypeController` is not in `$authExemptMethods` (:107-111). That assertion will fail on `create()`. D4 — the team verifies; either add the exempt entry or a `Gate::check` alongside the abort.
- **`RouteAuthenticationTest.php:82`** still lists `timetable-foundation.day-type.create`; the helper skips an unresolvable route (`:40-45`), so it is a stale entry, not a failure. Belongs to the team (D4).

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is a static read or a read-only SQL probe.
- **`tests/Unit/ControllerAuthTest.php`, `tests/Feature/RouteAuthenticationTest.php`, `TtDayTypeTest`:** read only to learn expectations; not executed and not edited. The two assertions flagged in §7 are for the team.
- **Other writers/readers of `tt_day_types`:** `TtDayTypeSeeder`, `TtWorkingDaySeeder`, `TtClassWorkingDaySeeder`, and `TimetableFoundationController`'s calendar were not audited — only their existence was noted where it bears on DTC-12/DTC-13.
- **Data repair:** none needed. The tenant has 9 day types, 0 trashed; no FK orphan exists today; the DTC-09 relation is unused.
- **SmartTimetable blades (§7):** outside this controller's scope; reported so the regression is not lost.
