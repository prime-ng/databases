# Fix Plan — TimetableFoundation / DayTypeController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers/reports use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/DayTypeController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ DTC-12 must be applied **before** DTC-01; DTC-01 removes the `catch (QueryException)` that is currently the only source of the friendly force-delete message.

## 1. Blockers reachable today
_None._ (DTC-12 is H and can destroy data, but the populated day types are protected by the `tt_working_days` FK and the button only renders on the trash page. It is sequenced first below.)

## 2. Fixes that arm a latent defect (sequenced)
- [x] **DTC-12** · H · DECISION · deep read · `DayTypeController.php:327-338` — `forceDelete()` accepts a LIVE record (`withTrashed()->findOrFail`) and checks no children.
      (a) ⭐ Switch to `onlyTrashed()->findOrFail()` so a live day type cannot be purged, **and** before deleting count children across the real referencing tables — `tt_working_days.day_type1_id…day_type4_id` (has FK) and `tt_class_working_days_jnt.day_type_id` (has NO FK, 4,620 rows). If any exist, refuse with a `\DomainException` naming each table and count (a D2 shape).
      (b) Only switch to `onlyTrashed()` and leave the child check out.
      (c) Leave as is, record as accepted.
      ➜ Choice: (a) — onlyTrashed + usage guard across both tables (2026-10-12)

## 3. Errors & transactions (F1/F2)
- [x] **DTC-01** · M · ERR-00 (D1) + ERR-05 · `DayTypeController.php:77-116, 173-218, 243-276, 326-367, 392-426, 456-488` — remove the six controller try/catch blocks and the seven `Log::…['error' => $e->getMessage()]` blocks:
      - `store`/`update`/`destroy`/`restore`/`toggleStatus` → `return DB::transaction(fn …)`; keep `findOrFail` outside; build the redirect/JSON after the closure (`toggleStatus` returns JSON, the central handler renders the rest).
      - `forceDelete` → **after DTC-12**, catch **only** `\DomainException` (the child-guard refusal) and flash it on the trash page; let every other error reach the central handler.
      - Do not remove the `catch (QueryException)` until DTC-12's guard is in place.
      Effort: S.

## 4. Authorization (F3)
- [x] **DTC-02** · L · AUTH-04 · `DayTypeController.php:75, 171` — drop the duplicate `Gate::authorize` in `store`/`update` and keep `DayTypeRequest::authorize()` (it runs first). The unreachable `DayTypePolicy` is a module-wide pattern and is **not** fixed here. Effort: S.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **DTC-03** · M · DECISION · VAL-04/BUG-003 · `DayTypeRequest.php:95-113` — a trashed code/name/ordinal can be re-used, then crashes with SQL 1062 (the three DB UNIQUE keys are not soft-delete aware).
      (a) ⭐ The validator also checks trashed rows and returns "A trashed day type already uses this code — restore it instead." No migration. (Mirrors ATC-11(a).)
      (b) A new additive migration adds a generated live-column + soft-delete-aware unique index for each of code/name/ordinal.
      ➜ Choice: (a) — validator checks trashed rows, "restore it instead" (2026-10-12)
- [x] **DTC-05** · H · DECISION · RTE-01 · `routes/web.php:174` — Restore runs over GET.
      (a) ⭐ Change to `Route::patch('/day-type/{id}/restore', …)`. `action-trashed` derives the verb from the route, so no blade edit is needed; the only caller is `trash.blade.php:61`. ⚠ SHARED — changes a route.
      (b) Leave as GET and accept the risk.
      ➜ Choice: (a) — PATCH restore (2026-10-12)
- [x] **DTC-06** · M · DECISION · CTL-03 · `DayTypeController.php:127,143,169,239,322,388` + `routes/web.php:172` — no route model binding on six methods.
      (a) ⭐ Add `->parameters(['day-type' => 'dayType'])` to `Route::resource('day-type', …)` and bind `DayType $dayType` in `show`/`edit`/`update`/`destroy`; the custom `{id}` routes (forceDelete/restore) may stay. A missing id still 404s. ⚠ SHARED — renames the route parameter.
      (b) Bind only the resource methods, keeping `{day_type}` and renaming the method variables.
      (c) Accept `findOrFail` as-is (no route change).
      ➜ Choice: (a) — {dayType} parameter + bound DayType (2026-10-12)
- [x] **DTC-09** · M · DECISION · MDL-04 · `DayType.php:186-192` — `timetableTypes()` queries `tt_timetable_types.day_type_id`, a column that does not exist (proved: `QueryException` 1054). It has no caller.
      (a) ⭐ Repoint it to the real child — `hasMany(ClassWorkingDay::class, 'day_type_id')` (rename to `classWorkingDays`), add the return type, and correct the false comment.
      (b) Delete the dead relation and its docblock.
      (c) Leave as is, record as accepted dead code.
      ➜ Choice: (a) — repointed as classWorkingDays() (2026-10-12)
- [x] **DTC-04** · M · VAL-05 · `DayTypeRequest.php:119` — add `boolean` to the `is_active` rule (create `['required','boolean']`, update `['nullable','boolean']`) so it matches the controller's `$request->boolean()` coercion. Effort: S.

## 6. Queries & performance (F9)
_None._

## 7. Views (F10)
- [x] **DTC-10** · L · orphan · `Modules/TimetableFoundation/resources/views/day-type/create.blade.php` — delete it. Before deleting, re-prove `routed=0 refs=0` at fix time (the create route is `except(['create'])`; the live form is `_create-modal` → `_create-fields`). Effort: S.

## 8. Style (F12) — one item per file
- [x] **DTC-11a** · L · STY-01 · `DayTypeController.php` — add `declare(strict_types=1)`. Effort: S.
- [x] **DTC-11b** · L · STY-01 · `DayTypeRequest.php` — add `declare(strict_types=1)`. Effort: S.
- [x] **DTC-11c** · L · STY-01/04 · `DayType.php` — add `declare(strict_types=1)`; if STY-04 is enforced strictly, replace the scanner-flagged `⚠`/`⛔` markers at `:67, :86, :92`. ⚠ SHARED — this model is read by the working-day seeders and the masters calendar. Effort: S.
- [x] **DTC-11d** · L · STY-01 · `DayTypePolicy.php` — add `declare(strict_types=1)`. Effort: S.

## 9. Deferred / decisions
- [x] **DTC-13** · M · DECISION · deep read · `DayTypeController.php:243-259` — a day type in use can be trashed, which blanks it on the working-day calendar.
      (a) ⭐ Refuse to trash a day type referenced by `tt_working_days` or `tt_class_working_days_jnt`, reusing DTC-12's counts, with a `\DomainException`.
      (b) Allow it but warn in the SweetAlert confirm dialog.
      (c) Leave as is (soft-delete is reversible).
      ➜ Choice: (a) — refuse to trash a day type still in use (2026-10-12)
- **Deferred — not in this plan:** the SmartTimetable blade regression (`partials/day-types/_list.blade.php:42`, `partials/working-days/_list.blade.php:45` call the removed `day-type.create` route) belongs to the SmartTimetable module; and the module-wide unreachable-policy question needs a module-level decision.

---

> **How to approve**
> 1. Tick `[x]` the items you want applied.
> 2. Fill every `➜ Choice:` after a ticked **DECISION** item.
> 3. Tick each `⚠ SHARED` item explicitly — "tick all" does not cover them.
> 4. Run `final-audit-fixer` on `Modules/TimetableFoundation/app/Http/Controllers/DayTypeController.php`. It applies only ticked items, in the order above.
