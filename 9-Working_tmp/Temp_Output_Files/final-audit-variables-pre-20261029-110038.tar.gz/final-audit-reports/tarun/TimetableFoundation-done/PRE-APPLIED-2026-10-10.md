# TimetableFoundation — work applied 2026-10-10, before the final-audit workflow existed

**What this is.** A manual hardening pass made these changes on 2026-10-10.

- The final audit is **fresh** (decision D10). Every file is audited as it stands now.
- When a fixer writes `03-status.md` for a controller listed here, it copies that controller's
  rows into the "Pre-applied 2026-10-10" section.
- The auditor names the rows in the report's scope section, so nobody re-applies or reverts them.

On-disk presence was verified by grep the same day. Each item below is
**"done, not re-verified by the audit"**. The audit decides whether it is complete.

## Decisions that shaped this pass

- ERR-00 is the Laravel idiom.
- ERR-01 sub-decisions: `\DomainException` for rule messages; never catch `RuntimeException`;
  truncate-then-rebuild keeps one catch with a fixed message; `SnapshotProtectionException`
  messages are shown verbatim; services use `report($e)` plus a fixed message.
- Unrouted method → `abort(403)` + a NOT ROUTED comment.
- No testing.

## Controllers

| File | Applied 2026-10-10 |
|---|---|
| `AcademicTermController` | `store` / `update` / `destroy` / `toggleCurrent` → `return DB::transaction(fn …)`; try/catch and manual rollBack removed (ERR-00). Pint applied |
| `RoomAvailabilityController` | `generate()`: try/catch removed, `$count = DB::transaction(...)` kept, ERR-00 comment added. Pint applied |
| `ClassWorkingDayController` | rule messages thrown as `\DomainException`, caught only as `DomainException`, with the "do not widen to RuntimeException" comment (ERR-01). Pint applied |
| `WorkingDayController` | same as ClassWorkingDay: 7 `throw new \DomainException` across both controllers, 3 narrow catches. Pint applied |
| `ActivityController` | user message "…now empty: '.$e->getMessage()" → "…now empty. The error has been logged." (truncate-rebuild D2). SnapshotProtectionException branch commented |
| `RequirementConsolidationController` | same raw-message removal (truncate-rebuild). `generateClassGroups`' second catch gained `report($e)` |
| `TeacherAvailabilityController` | same raw-message removal. `$firstErrors[]` now `"capability #{id} (requirement #{id})"` instead of exception text |
| `PriorityConfigController` | same raw-message removal |
| `TimetableFoundationController` | same raw-message removal; SnapshotProtectionException branches commented |
| `ClassSubjectSubgroupController` | `store()` rewritten as `DB::transaction` returning the subgroup, then redirect to `class-subgroup.show`. Optional fields read with `?? null`. `generateClassSubgroups()` → NOT ROUTED + `abort(403)`; its 9 private helpers are now dead code, **left in place** (D5) — the audit should report them as CTL-10 |

## Services

| File | Applied 2026-10-10 |
|---|---|
| `GenerationReadinessReportService` | `CHECK_FAILED` constant added. 7 catches now `report($e)` + the fixed message |
| `SlotRequirementGridService` | the catch now `report($e)` + a fixed message |
| `RequirementTableTruncator` | raw `(' . $e->getMessage() . ')'` removed from the SnapshotProtectionException message |

## Routes and views

| File | Applied 2026-10-10 |
|---|---|
| `routes/web.php` | dead routes cleaned. Result: 239 routes, 0 pointing at a missing method |
| `routes/api.php` | the scaffold `apiResource` was removed (it pointed at missing methods and rendered HTML behind `auth:sanctum`). A comment explains why the file stays |
| `resources/views/pages/partials/timetable-requirement/class-subgroups/_list.blade.php` | Trash button removed (route gone). Compiles OK |

⚠ The same pass also removed a Trash button from `Modules/SmartTimetable/.../class-group-jnt/_list.blade.php`.
That is another module; it is recorded here only so it is not lost.

## Known open items carried into the audit

- **ERR-01 went from 28 to 7.** The 7 that remain are accepted, deliberate D2 messages. The
  remaining `getMessage()` occurrences per controller are mostly `Log::` context. The audit must
  classify each one as user-facing (ERR-01) or log-only (ERR-05).
- **`ControllerAuthTest` showed 10 failures before testing stopped.** This is partly expected
  from the `generateClassSubgroups` `abort(403)`. It is left for the team to test (D4).
- **Still pending:**
  - the dead `generateClassSubgroups` helpers;
  - `ClassModeRule`;
  - query optimisation and caching;
  - god-controller splits (deferred, D3).
