# Final Audit — TimetableFoundation / PriorityConfigController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/PriorityConfigController.php` (60 lines, 1 public method)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready as-is, but close. 0 blockers, 0 HIGH, 6 MEDIUM.**

This is a single-purpose recalculation controller. It authorizes before any write, runs the rebuild
inside **one** `DB::transaction` closure with `activityLog` after the write, keeps the D2 truncate-
then-rebuild catch with `report($e)` and a fixed message, and routes over POST only — the core
patterns are correct. The problems are: the destructive regenerate is gated by a **view-level**
permission of an unrelated feature (`config.viewAny`), which does not describe what the button does
(PRC-03); the controller and its service both open a `DB::transaction`, a redundant nesting that will
surprise the next editor (PRC-02); the service rewrites 662 rows one `updateOrInsert` at a time on a
table it just truncated (PRC-06); and a concurrent double-click can leave the table duplicated or
half-built because nothing locks the truncate+rebuild (PRC-10).

The single worst finding is **PRC-03**: any user who may merely *view* the timetable-requirement page
can wipe the entire Priority Config table and rebuild it, because the operation is gated by the
read-level `tenant.timetable-foundation.config.viewAny` permission and no `priority-config.*` ability
exists at all.

The effort is about half a day, most of it the PRC-06 bulk-write. Five DECISION items need your
choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 0 | 6 | 6 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PRC-01 | F8 Services/Jobs | PRC-05 |
| F2 Transactions/Audit | PRC-02 | F9 Queries/Perf | PRC-06 |
| F3 Authorization | PRC-03 | F10 Views | clean: controller renders no view (`grep -oE "view\(['\"]…" → none`); the tab partial that shows the flash is rendered by `TimetableFoundationController` |
| F4 Validation | clean: no user input, no FormRequest, no `$request->validate()` (`grep -nE "validate|Request" → only the injected service/truncator`) | F11 Security/Tenancy | PRC-07, PRC-08 |
| F5 Routes | clean | F12 Style | PRC-09 |
| F6 Controller shape | PRC-04 | F13 Deep read | PRC-10, PRC-11, PRC-12 |
| F7 Models | linked-only usage checks (see §6) | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/PriorityConfigController.php` | controller | 60 | this report | ✅ whole class |
| 2 | `app/Services/PriorityConfigService.php` | service | 173 | **this report (pre-assigned)** | ✅ whole class |
| 3 | `app/Services/RequirementTableTruncator.php` | service | 192 | ↗ [RequirementConsolidationController](../RequirementConsolidationController-done/01-report.md) | ↗ linked — usage checked (truncate order, stage), not re-audited |
| 4 | `app/Models/RequirementConsolidation.php` | model | — | ↗ [RequirementConsolidationController](../RequirementConsolidationController-done/01-report.md) | ↗ linked — usage checked (relations/casts resolve on live data, §6) |
| 5 | `app/Models/PeriodSet.php` | model | — | ↗ [PeriodSetController](../PeriodSetController-done/01-report.md) | ↗ linked — usage checked (read-only lookup) |
| 6 | `app/Models/SchoolDay.php` | model | — | ↗ [SchoolDayController](../SchoolDayController-done/01-report.md) | ↗ linked — usage checked (read-only count) |
| 7 | `routes/web.php:54` | route | — | this report | ✅ one POST route |
| 8 | `resources/views/pages/partials/timetable-requirement/priority-config/_list.blade.php` | tab partial | 274 | not in scope | ❌ rendered by `TimetableFoundationController`, not this controller — its Recalculate button (line 19) is the route caller; the flash keys it reads (`success`/`error`, lines 33-44) match the controller's `with()` keys ✅ |
| 9 | `Modules/SmartTimetable/app/Models/PriorityConfig.php` | model (consumer, other module) | 92 | not in scope — common (other module) | ❌ reads `tt_priority_configs` for display only; usage noted in §7 (PRC-11) |
| — | `activityLog()` (`app/Helpers/activityLog.php`), `flash()` (`app/Helpers/helpers.php`) | app glue | — | common | referenced only (§4.2) |

**Pre-applied 2026-10-10:** this controller is listed in `../PRE-APPLIED-2026-10-10.md`
("same raw-message removal"). The pass removed the raw `$e->getMessage()` from the truncate-rebuild
catch and left `report($e)` + the fixed message "…so it is now empty. The error has been logged."
This audit reviewed that result fresh: the shape is **complete and compliant** with D2 — the only
gap is that its allowed catch never names ERR-01 (PRC-01).

## 4. Routes

```
POST  timetable-foundation/priority-config/recalculate  timetable-foundation.priority-config.recalculate  recalculate
```

Middleware (from the uncached `route:list --json`): `web, PreventAccessFromCentralDomains,
InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth,
verified`. Registered in `routes/web.php:54`, inside the module's tenant route group
(`RouteServiceProvider::mapWebRoutes`).

**Unrouted public methods:** none — the class has exactly one public method and it is routed.

**Only caller:** the tab partial `priority-config/_list.blade.php:19`, POST with `@csrf`. The route
is `name`d `timetable-foundation.priority-config.recalculate`.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| `recalculate` | ✅ POST | `…config.viewAny` | ✅ `DB::transaction` in controller (line 37) **nested over the service's own at line 34** | `Recalculated` — after the write, inside the controller's tx | TRUNCATE `tt_priority_configs` (pre-tx, D2) + per-row upsert `tt_priority_configs` + `sys_activity_logs` | PRC-01…12 |

**Tables this mutation SHOULD touch (measured before counting):** `tt_priority_configs` and one
`sys_activity_logs` row. It writes both. The TRUNCATE is a deliberate pre-transaction side effect,
sanctioned by D2 and disclosed in the confirm dialog (`_list.blade.php:19-24`, via
`RequirementTableTruncator::warningFor('priority_configs')` = "WARNING: this TRUNCATES (empties, ids
restart at 1) Priority Config. If generation fails, it stays EMPTY. This cannot be undone.").

## 6. Findings

### F1 — Errors
#### PRC-01 · L · ERR-00 / D2 — the allowed truncate-rebuild catch is not annotated `ERR-01` + date
**Where:** `PriorityConfigController.php:51-58`
```php
} catch (\Throwable $e) {
    report($e);

    // The table was truncated before the transaction, so it is now EMPTY.
    return redirect()
        ->route('timetable-foundation.menu.timetableRequirement', ['tab' => 'priority-config'])
        ->with('error', 'Recalculation failed after Priority Config was cleared, so it is now empty. The error has been logged.');
```
**Evidence:** `grep -n "ERR-01" PriorityConfigController.php` → no match. The sibling service
`RequirementTableTruncator.php:153` carries `// … (ERR-01, 2026-10-10)`. D2: "each allowed catch gets
a comment naming ERR-01 and the date."
**Consequence:** none for the user — the catch already uses `report($e)` and a fixed message — but an
undocumented allowed catch reads like an ERR-00 violation to the next reviewer.

The rest of F1 is clean: the message is fixed, the exception object is logged, and no
`$e->getMessage()` reaches the user (`grep -nE "getMessage\(" → none in either in-scope file`).

### F2 — Transactions and audit
#### PRC-02 · M · TXN-01 / TXN-02 — the controller and the service each open their own `DB::transaction` (nested)
**Where:** `PriorityConfigController.php:37` and `PriorityConfigService.php:34`
```php
// controller                               // service
$count = DB::transaction(function () {      DB::transaction(function () use (
    $count = $this->service->recalculate();     $consolidations, …, &$count
    activityLog(…)                             ) {
    return $count;                              foreach ($consolidations as $rc) { … }
});                                          });
```
**Evidence:** `grep -n "DB::transaction"` on both files → line 37 (controller) and line 34 (service).
Laravel nests these as savepoints, so today it works; the controller's closure is the only one that
matters for `activityLog` placement, which is correct (inside the tx, after the writes, event literal
`Recalculated`, message and `requirements` count recorded).
**Consequence:** the service's inner transaction is redundant, and the next editor may "simplify" or
early-return across it in a way that leaks a savepoint or half-commits — the F2 rule is *one*
transaction per multi-table write. Fix: the service drops its closure and the controller keeps the
single outer transaction.

### F3 — Authorization
#### PRC-03 · M · AUTH-06 / AUTH-01 · DECISION — a destructive regenerate is gated by a read-level permission of an unrelated feature
**Where:** `PriorityConfigController.php:25`
```php
Gate::authorize('tenant.timetable-foundation.config.viewAny');
```
**Evidence:**
- Live tenant probe (tinker): `sys_permissions` contains exactly **1** exact-name row
  `tenant.timetable-foundation.config.viewAny`; **0** rows for `tenant.timetable-foundation.priority-config.*`.
- `config/permissionslist.php:640`: `'timetable-foundation.config' => array_merge($crud, ['export'])`.
- Sibling regenerate controllers gate on a dedicated `.generate` ability (`.teacher-availability`,
  `.room-availability`, `.activity`, `.requirement-consolidation` in `permissionslist.php`).
- The page that hosts the button is gated by the same string
  (`TimetableFoundationController.php:593`), so this is *not* an access-escalation — but a user who
  can merely view the page can wipe and rebuild the whole table.
**Consequence:** the permission name says "view configuration" while the button TRUNCATES and
rebuilds every priority-score row; least-privilege reviews of a School Admin role cannot tell that
`config.viewAny` grants a destructive write. Fixing it needs a new permission key → **DECISION**.

### F4 — Validation
**Clean — there is no user input.** The POST carries only the CSRF token; there is no FormRequest,
no `$request->validate()`, no `$request->all()` into any model. The controller reads nothing from the
request (`grep -nE "request\(" → none`).

### F5 — Routes
**Clean.** One route, POST — no state change over GET (RTE-01 ✅); it points at an existing method
(RTE-02 ✅); the one public method is routed (RTE-03 ✅); it sits inside the auth + tenancy
middleware group (RTE-05 ✅); no `Route::resource` shares the prefix (RTE-06 n/a). Evidence: the
uncached `route:list` output in §4.

### F6 — Controller shape
#### PRC-04 · L · CTL-08 / SVC-02 — `app(RequirementTableTruncator::class)` resolved mid-method instead of constructor-injected
**Where:** `PriorityConfigController.php:32`
```php
app(RequirementTableTruncator::class)->truncateFrom('priority_configs');
```
**Evidence:** the controller already constructor-injects `PriorityConfigService` (lines 16-18); the
truncator is the only dependency resolved by the container inside the method body.
**Consequence:** convention drift only — the alternative (constructor promotion) would make the
dependency visible in tests and the signature. (Same pattern as `SlotRequirementController:80`.)

The rest of the class is clean: 60 lines, 1 public method (CTL-01/02 n/a), `strict_types=1`, the
return type is declared, no debug leftovers, no dead code (`grep -nE "dd\(|dump\(|var_dump" → none`).

### F7 — Models
**Linked-only, usage checked.** The service reads `RequirementConsolidation` (with `class`,
`section`, `subject`, `studyFormat`, `requiredRoomType`), `PeriodSet`, and `SchoolDay` — all owned by
other reports. Its usage is sound, proved on live data in tinker:
- `RequirementConsolidation::with([…])->where('is_active', true)` returns 662 active rows; the first
  row resolves `class = "Class I"`, `section = "A"`, `subject = "English"`, `studyFormat =
  "LECTURE"`, `requiredRoomType → id 1`; `preferred_periods_json` is cast to array (`gettype → NULL`
  when empty — `is_array()` guard at `PriorityConfigService.php:90` is correct).
- `tt_teacher_availabilities` exists with `class_id`, `section_id`, `subject_study_format_id` and
  `proficiency_percentage`; 1,168 active rows; the service's join keys all exist.
- No model in scope is owned here; no MDL finding against `PriorityConfigService`.

### F8 — Services and jobs
#### PRC-05 · M · SVC-04 — a second, orphaned implementation of the same operation computes different scores
**Where:** `Modules/TimetableFoundation/database/seeders/TtPriorityConfigSeeder.php:28-30`
```php
$teacherScarcity = $eligibleTeachers > 0 ? round(max(1, 3 / $eligibleTeachers), 2) : 1.00;
$weeklyLoadRatio  = $requiredWeekly > 0 ? round($requiredWeekly / 8, 2) : 0.10;
```
**Evidence:** `grep -rn "TtPriorityConfigSeeder" Modules/ database/` finds **no caller** — the module's
`TimetableFoundationDatabaseSeeder.php` does not call it, and nothing else references it. Its formula
disagrees with `PriorityConfigService::recalculate()` (which uses `eligible_teacher_count` directly as
the scarcity index, `totalWeeklyPeriods()` instead of a hard-coded 8, `student_count ?? 30`, and caps
ratios at 9.99). Its empty-consolidations fallback also inserts `requirement_consolidation_id` 1..5,
which do not exist — rows the display's `whereHas('requirementConsolidation')` hides forever.
**Consequence:** dead, divergent code: if anyone ever runs this seeder, goal-seeking scores silently
change to a different invented formula, and the failure mode is invisible.

The service itself is clean on SVC-01 (no `request()/session()/redirect()/response()`, verified by
grep), SVC-02 (no constructor deps to inject), SVC-03 (this is a write path by design) and SVC-05
(lookups `totalWeeklyPeriods`, `roomCountByType`, `avgTeacherAvailabilityByRc` are each resolved once
before the loop). No jobs or events exist.

### F9 — Queries and performance
#### PRC-06 · M · QRY-07 — per-row `updateOrInsert` (SELECT + write per row) on a table that was just truncated
**Where:** `PriorityConfigService.php:38-57`
```php
foreach ($consolidations as $rc) {
    $scores = $this->computeScores(...);
    DB::table('tt_priority_configs')->updateOrInsert(
        ['requirement_consolidation_id' => $rc->id, 'deleted_at' => null],
        array_merge($scores, [...])
    );
    $count++;
}
```
**Evidence:** the scanner reports `QRY-01 H …:46 DB::table() inside a loop` — confirmed in source to
be a **write** (an N+1 *read* it is not, so this is reported as QRY-07 M, not QRY-01 H; the
truncator's loop has the same false positive, noted at SLR-19-precedent). The controller TRUNCATES
`tt_priority_configs` before the transaction (`PriorityConfigController.php:32`), so at the moment of
this loop every row is new: `updateOrInsert` still issues a SELECT that can never match, then the
write — two statements per row. On this tenant: 662 consolidations → ~1,324 statements.
**Consequence:** recalculation slows linearly with the number of requirements, and each row pays a
round trip to confirm a match that cannot exist. A chunked `insert()` (the table is empty) or one
`upsert()` would be one statement per N rows.

### F10 — Views
**Clean — the controller renders no view.** `grep -oE "view\(['\"]…" PriorityConfigController.php →`
none. The tab partial that displays the rows and shows the flash is rendered by
`TimetableFoundationController::timetableRequirement()` (not this audit); its flash keys
(`success`/`error`, `_list.blade.php:33-44`) match the controller's `with()` keys, and its
`$priorityConfigs` collection is eager-loaded by the rendering controller (`TimetableFoundationController:1239`).

### F11 — Security and tenancy
#### PRC-07 · M · SEC-03 — `auth()->id() ?? 1` fabricates a causer when auth is absent
**Where:** `PriorityConfigService.php:31`
```php
$createdBy = auth()->id() ?? 1;
```
**Evidence:** scanner `SEC-03` fires at line 31. The controller route is behind `auth` + `verified`,
so `auth()->id()` is always set today; the fallback only matters if the service is ever reused from a
job/command, where auth is null and every row silently gets `created_by = 1`.
**Consequence:** latent — a future non-HTTP caller would attribute all priority rows to user id 1
instead of failing, corrupting audit attribution.

#### PRC-08 · L · SEC-03-adjacent / deep read · DECISION — silent fabricated defaults distort the scores
**Where:** `PriorityConfigService.php:129, 100, 86` (and `:77`)
```php
$periodsPerDay = PeriodSet::where('is_active', true)->orderByDesc('is_default')->value('total_periods') ?? 8;
$availableRooms = $rc->required_room_type_id ? ($roomCountByType[$rc->required_room_type_id] ?? 1) : PHP_INT_MAX;
$avgTar = $teacherAvgByRc[$rc->id] ?? 100.00;
```
**Evidence:** when a school has no active period set, or a required room type has no active rooms, or
a consolidation has no teacher-availability rows, the code invents "8 periods per day", "1 room
available" and "100% teacher availability" instead of failing or skipping. The `teacher_scarcity`
index is also clamped with `max(1, …)` (line 77).
**Consequence:** priority ranks computed from invented numbers — a "message that lies" (deep-read #7)
one layer down; two schools with identical classes but different data gaps get incomparable scores.

No `env()` outside config, no secrets logged (`report($e)` logs the exception object), no cache, no
file serving — F11 is otherwise clean (`grep -nE "env\(" → none`).

### F12 — Style
#### PRC-09 · L · STY-02 — the service is not Pint-clean
**Where:** `PriorityConfigService.php` (whole file)
**Evidence:** `vendor/bin/pint --test --format agent` on both files →
`{"result":"fail","files":[{"path":"…PriorityConfigService.php","fixers":["array_indentation",
"method_chaining_indentation","phpdoc_separation","binary_operator_spaces"]}]}`. The controller is
reported clean.
**Consequence:** a later `pint --dirty` will reformat this file inside an unrelated change.

Style otherwise fine: both files declare `strict_types=1`; the controller's method has a return type;
all service methods have return types; neither file contains debug leftovers, emoji markers, or
commented-out code (>3 lines).

### F13 — Deep read
#### PRC-10 · M · TXN-06 / deep read · DECISION — no lock around truncate + rebuild (race)
**Where:** `PriorityConfigController.php:32-46` vs `PriorityConfigService.php:46`
**Evidence:** two concurrent POSTs both call `truncateFrom('priority_configs')` (DDL, commits
immediately) before either opens its transaction; the second truncate can erase rows the first just
wrote, or the two transactions interleave on the empty table — and `tt_priority_configs` has **no
unique index** on `requirement_consolidation_id` (SHOW INDEX → PRIMARY + `fk_pc_created_by` only), so
nothing prevents two copies of the same row. The button has no JS disable and no lock.
**Consequence:** a double-click or two admins can leave the table duplicated (up to 2× rows) or
half-rebuilt, and the flash reports the count of whichever transaction finished, whether or not its
rows survived.

#### PRC-11 · L · deep read #8 · DECISION — the computed scores have no consumer beyond the display tab
**Where:** `PriorityConfigService.php` (writes) vs the whole codebase (reads)
**Evidence:** `grep -rn "tt_priority_configs\|PriorityConfig"` across `Modules/` shows two readers of
the table: the display path (`TimetableFoundationController:1239` → `PriorityConfig` model →
`_list.blade.php`) and the model itself. No solver, generator or constraint compiler anywhere
references the `tt_priority_configs` score columns — including `Modules/SmartTimetable/app/Services/*`
(verified by grep).
**Consequence:** if the solver ignores these scores, the entire Recalculate feature is decorative —
an admin computes scores nobody reads. Product question: where the solver reads them (e.g. by CTE on
another system) needs confirmation.

#### PRC-12 · L · MDL / DDL-drift · DECISION — the live table lacks the DDL's FK to the requirement consolidations
**Where:** `database/migrations/tenant/2026_06_16_152603_create_tt_priority_config_table.php` vs
`pgdatabase/2-DDL_Tenant_Consolidated/Timetable_DDL_v7.8.sql:902`
**Evidence:** tinker `information_schema.KEY_COLUMN_USAGE` shows the live table's only FK is
`created_by → sys_users`. The canonical DDL declares
`CONSTRAINT fk_prioConfig_reqCon FOREIGN KEY (requirement_consolidation_id) REFERENCES
tt_requirement_consolidations (id)`; no migration ever created it.
**Consequence:** outside the truncate-rebuild path (e.g. a force-deleted consolidation), a priority
row can orphan silently; the display's `whereHas` then hides it, so the orphan is invisible. The
recalc path is unaffected because it truncates first.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`RequirementTableTruncator` (owned by the RequirementConsolidationController report):** this
  controller's call `truncateFrom('priority_configs')` truncates only `tt_priority_configs` (the last
  STAGE), so a recalculate does **not** wipe slot requirements or later stages — the reverse of
  `generateSlotRequirement`, which clears `tt_priority_configs` too (SLR-17). The relationship is
  one-way: **any regenerate of slot requirements empties Priority Config**, and this Recalculate
  button is the only place that rebuilds it. After a slot-requirement regenerate, an admin must click
  Recalculate here to get scores back.
- **`Modules/SmartTimetable/app/Models/PriorityConfig.php`** is a consumer from another module; its
  `$casts` and `SoftDeletes` are consistent with the live table, and the table carries a
  `deleted_at` column but the service's raw `updateOrInsert` bypasses SoftDeletes (it matches
  `deleted_at => null` explicitly). No unique index exists, so the SOFT-delete × unique-index trap
  cannot fire; only the race (PRC-10) matters.
- **SlotRequirement/SLR-02 precedent:** the `?? 8`-style fabricated defaults here match the SLR-19
  decision pattern and are offered the same way.
- **Unreachable policies (module-wide):** no policy is consulted for this path either — a string is
  passed to `Gate::authorize`. Same module-level note as ATC-14 / SLR-03; not fixed here.

## 8. Not covered, and why

- **Runtime behaviour:** no browser, no test run (D4). Every finding is static or a read-only SQL probe.
- **The actual solver consumption of the score columns** is a SmartTimetable question (PRC-11); the
  E2E answer needs a design read of `PrimeSolver`/`TimetableGenerationService`, not a code change here.
- **`TimetableFoundationController`** is the renderer of the tab and the owner of other reports
  (CLAIMED); only its read of `$priorityConfigs` was checked.
- **The `tt_requirement_consolidations` table and force-delete semantics** belong to the
  RequirementConsolidationController report.
- **Data repair:** the table currently holds 0 rows (the slot-requirement regenerate has already
  emptied it); nothing in this audit changes data.