# Fix Plan — TimetableFoundation / PriorityConfigController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/PriorityConfigController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
_None._

## 2. Fixes that arm a latent defect (sequenced)
_None — no item here unblocks another fix in this pair of files._

## 3. Errors & transactions (F1/F2)
- [ ] **PRC-01** · L · ERR-00 / D2 · `PriorityConfigController.php:51-58` — add the `ERR-01, 2026-10-10`
      comment to the allowed truncate-rebuild catch, matching `RequirementTableTruncator.php:153`.
      Comment only, no behaviour change. Effort: S.
- [ ] **PRC-02** · M · TXN-01 / TXN-02 · `PriorityConfigController.php:37` + `PriorityConfigService.php:34`
      — remove the service's inner `DB::transaction(...)` and leave its loop inside the controller's
      single outer transaction (which already owns the `activityLog`). The service keeps returning
      `$count`. Net effect: one transaction per recalc, as F2 requires. Effort: S.

## 4. Authorization (F3)
- [ ] **PRC-03** · M · DECISION · AUTH-06 / AUTH-01 · `PriorityConfigController.php:25` — the
      regenerate is gated by the read-level `…config.viewAny`; no `priority-config.*` ability exists.
      (a) ⭐ Mint a dedicated ability and gate on it: add `'timetable-foundation.priority-config' =>
          array_merge($crud, ['generate'])` to `config/permissionslist.php`, gate
          `recalculate()` on `tenant.timetable-foundation.priority-config.generate`, and seed with
          `/system-config/sync-permissions` (⚠ SHARED — `config/permissionslist.php`; the page and
          its other tabs keep `config.viewAny`).
      (b) Keep `config.viewAny` and accept the naming gap, recording it as accepted.
      ➜ Choice: ____
      Effort: S.

## 5. Validation, routes, models (F4/F5/F7)
_None — F4/F5 clean; F7 is linked-only._

## 6. Queries & performance (F9)
- [ ] **PRC-06** · M · QRY-07 · `PriorityConfigService.php:38-57` — replace the per-row
      `updateOrInsert` with a chunked `DB::table('tt_priority_configs')->insert($rows)` batch
      (e.g. 100 per chunk). The controller TRUNCATES the table right before the transaction, so every
      row is new and `updateOrInsert`'s SELECT can never match — a plain insert is behaviour-neutral.
      Keep `$count` as the number of rows written. Effort: S.

## 7. Views (F10)
_None._

## 8. Style (F12) — one item per file
- [ ] **PRC-04** · L · CTL-08 / SVC-02 · `PriorityConfigController.php:16-18, 32` — inject
      `RequirementTableTruncator` through the constructor (alongside `PriorityConfigService`) and drop
      the `app(...)` call. Effort: S.
- [ ] **PRC-09** · L · STY-02 · `PriorityConfigService.php` — run Pint on the file
      (`vendor/bin/pint Modules/TimetableFoundation/app/Services/PriorityConfigService.php --format agent`)
      to fix `array_indentation`, `method_chaining_indentation`, `phpdoc_separation`,
      `binary_operator_spaces`. Effort: S.

## 9. Deferred / decisions
- [ ] **PRC-10** · M · DECISION · TXN-06 / deep read · `PriorityConfigController.php:32-46` — no lock
      around the truncate + rebuild; a double-click can duplicate or erase the table.
      (a) ⭐ Serialise with a tenant-scoped lock: `Cache::lock('tt_priority_configs:recalc:'.
          tenant('id'), 30)->get(...)` around the truncate + transaction, releasing after. A second
          click either waits or is refused with the flash "Recalculation already running." This is a
          cache addition → needs a named, tenant-scoped key (TEN-02).
      (b) Leave as is and accept the double-click risk (matches the pre-existing SLR-18 posture).
      ➜ Choice: ____
      Effort: S.
- [ ] **PRC-08** · L · DECISION · SEC-03-adjacent / deep read · `PriorityConfigService.php:77, 86,
      100, 129` — silent defaults fabricate scores (8 periods/day, 1 room, 100% TAR, min scarcity 1).
      (a) ⭐ Fail loudly on the meaningful gaps: throw a `\DomainException` naming the school when no
          active `PeriodSet`/`SchoolDay` exists (caught only as `DomainException` by the controller
          and flashed per the settled D1/D2), and keep documented defaults only for harmless 0-counts
          (e.g. no preferred periods → rigidity 1.00).
      (b) Keep the invented defaults, with a comment stating they are deliberate.
      ➜ Choice: ____
      Effort: S.
- [ ] **PRC-11** · L · DECISION · deep read #8 · `PriorityConfigService.php` (all) — no solver reads
      the computed scores; the feature may be display-only today.
      (a) ⭐ Confirm where/if the scoring is consumed (SmartTimetable `PrimeSolver` /
          `TimetableGenerationService` read of `tt_priority_configs`). If nothing reads it, hide the
          Recalculate button and tab until the solver consumes it (or document it as informational).
      (b) Keep as is — the tab is a diagnostic readout by design.
      ➜ Choice: ____
      Effort: S (analysis only).
- [ ] **PRC-12** · L · DECISION · MDL / DDL-drift · `tt_priority_configs` — the live table lacks
      `fk_prioConfig_reqCon` (`requirement_consolidation_id → tt_requirement_consolidations`) that the
      canonical DDL declares.
      (a) ⭐ Add the FK in a new additive migration (never edit the existing one). Pre-check: every
          live `requirement_consolidation_id` must exist in `tt_requirement_consolidations`
          (this tenant has 0 rows in the table, so it passes). ⚠ Migration is written, never run.
      (b) Leave as is — the truncate-rebuild path never leaves orphans.
      ➜ Choice: ____
      Effort: S.
- [ ] **PRC-07** · M · SEC-03 · `PriorityConfigService.php:31` — the route is behind `auth`, so
      `auth()->id()` is always set; drop the `?? 1` fallback and pass `auth()->id()` directly, or
      type-safely require it (the service can take `created_by` as a parameter from the controller).
      Keeps jobs/console from silently attributing rows to user 1. Effort: S.