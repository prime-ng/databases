# Fix Plan — TimetableFoundation / RequirementConsolidationController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick. `"tick all"` does not cover it.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/RequirementConsolidationController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today

- [x] **RCC-22** · B · DECISION · VIEW/RTE · `resources/views/class-group-requirement/create.blade.php:7,293` — the create screen 500s: its form action and cancel link call `route('timetable-foundation.class-group-requirement.store')` / `.index`, which do not exist. The screen is linked from `Modules/SmartTimetable/.../class-timetable-type/_list.blade.php:42`. Choose the direction; `RCC-15` below depends on it.
      (a) ⭐ **Repair the legacy create path**: introduce a real `ClassGroupRequirement` model (the validation rules and the seeder describe a `weekly_periods`-style table that no longer exists), or retarget `store()` to `tt_class_requirement_groups`, and change the two route names in the blade to `…requirement-consolidation.store` / `.index`. Largest scope; touches a shared route file and a SmartTimetable blade.
      (b) **Retire the create surface**: make `create()` and `store()` `abort(403)` under a `// NOT ROUTED`-style comment (they stay, per D5 spirit), delete the three orphan blades (RCC-23) and remove the `+` button at `Modules/SmartTimetable/.../class-timetable-type/_list.blade.php:42`. ⚠ SHARED — the button is in another module.
      (c) Leave all three as is; record as accepted (the button stays broken).
      ➜ Choice: (b) Retire — create()/store() abort(403); orphan blades deleted (Tarun, 2026-10-14)
- [x] **RCC-15** · B · MDL-07 · `RequirementConsolidationController.php:249,271` — `store()` calls `ClassGroupRequirement`, a class that exists nowhere; line `:249` is outside the `try`, so a POST fatals with a 500. **Apply only if RCC-22(a) is chosen** (retarget to `ClassSubjectGroup`/the real model, or add the class). If RCC-22(b) is chosen this is subsumed by the `abort(403)`. Effort: S–M.

## 2. Fixes that arm a latent defect (sequenced)

- [x] **RCC-29** · H · deep read · `RequirementConsolidationController.php:793` — `forceDelete()` uses `withTrashed()->findOrFail()`, so a live requirement can be permanently destroyed. Change to `onlyTrashed()->findOrFail()`. No child tables reference the table, so no count guard is needed. Sequence before the write-path cleanups in §3. Effort: S.

## 3. Errors & transactions (F1/F2)

- [x] **RCC-01** · H · ERR-02 · `RequirementConsolidationController.php:376-378, 484-491, 949-956, 1008-1019` — `validate()` is inside the `try`, so a `ValidationException` is swallowed by the generic `\Throwable` catch. Move the `$request->validate(...)` **before** each `try` (or into a FormRequest per RCC-04). Effort: S.
- [x] **RCC-02** · M · ERR-00 (D1) · `RequirementConsolidationController.php:268, 376, 484, 724, 792, 837, 899, 949, 1008, 1140` — remove the controller `try/catch` from nine methods, using `return DB::transaction(fn …)` and letting the central handler render errors (JSON for the AJAX methods). Keep `generateRequirements:1211` (the D2 truncate-rebuild shape). Effort: M.
- [x] **RCC-03** · M · ERR-05 · `RequirementConsolidationController.php:285, 470, 696, 750, 814, 863, 925, 983, 1091, 1157` and `RequirementTableTruncator.php:145` — replace `Log::error('… '.$e->getMessage(), ['exception' => get_class($e)])` with `report($e)` (or `['exception' => $e]`), keeping a fixed flash/JSON message. The 2026-10-10 pass claimed `report($e)` for the second catch; it is absent. Effort: S.

## 4. Authorization (F3)

_None required._ All gates use declared, seeded permission names. The unreachable-policy question is module-wide (§7 of the report).

## 5. Validation, routes, models (F4/F5/F7)

- [x] **RCC-04** · M · DECISION · VAL-02 · `Http/Requests/` — no FormRequest exists; validation is inline in seven methods and duplicated between `store` and the dead legacy `update` branch.
      (a) ⭐ Extract one `RequirementConsolidationRequest` covering the primary `store`/`update` rules; leave the AJAX one-field toggles inline (allowed by VAL-02). Note the rule names must be fixed per RCC-06.
      (b) Defer to the split pass (RCC-08).
      (c) Leave inline; record as accepted.
      ➜ Choice: (a) Extract one — RequirementConsolidationRequest for update() (Tarun, 2026-10-14)
- [x] **RCC-05** · M · VAL-05 · `RequirementConsolidationController.php:167-169, 580-582` — `'is_active' => ['nullable']` validates nothing; type it `'boolean'` (the field is read with `$request->boolean()`). Effort: S.
- [x] **RCC-06** · H · VAL-07 · `RequirementConsolidationController.php:216-217, 228-229` — the weekly/daily min≤max checks test `*_required_*` keys that validation never sets, so they never fire. Rename to the validated keys (`min_periods_per_week` / `max_periods_per_week`, `min_per_day` / `max_per_day`) or move the rule into the FormRequest's `after()`. Effort: S.
- [x] **RCC-07** · H · RTE-01 · `routes/web.php:287` — Restore runs over `GET`. Change to `Route::patch` (the `action-trashed` component derives the verb from the route, so no blade edit). ⚠ SHARED — route file. Effort: S.
- [x] **RCC-16** · H · MDL-07/MDL-04 · `ClassRequirementGroup.php:67,74,83,91` and `ClassRequirementSubgroup.php:78,87,113` — the `class` / `section` / `subjectStudyFormat` / `classHouseRoom` relations point at `SchClass`, `SchSection`, `SchSubjectStudyFormatJnt`, `SchRoom`, none of which exist. Repoint to the working classes used by `ClassSubjectGroup` (`SchoolClass`, `Section`, `SubjectStudyFormat`, `Room`). Effort: S.
- [x] **RCC-17** · M · MDL-02 · `ClassRequirementSubgroup.php:51-68` — add `'subject_study_format_option_id' => 'integer'` to `$casts` (it is fillable at `:37` but uncast). Effort: S.
- [x] **RCC-18** · M · DECISION · MDL duplicate · `ClassSubjectGroup.php:21` and `ClassRequirementGroup.php:13` both map `tt_class_requirement_groups` with divergent relations. `ClassRequirementGroup` is not referenced by this controller.
      (a) ⭐ Deprecate `ClassRequirementGroup`: keep the file but add a header comment "superseded by ClassSubjectGroup; kept for backward compatibility", and repoint any external caller to `ClassSubjectGroup`. No deletion.
      (b) Merge the two into one model now (touches every caller — measure first).
      (c) Leave both; record as accepted.
      ➜ Choice: (a) Deprecate, keep the file — header added, relations repaired (Tarun, 2026-10-14)

## 6. Queries & performance (F9)

- [x] **RCC-20** · H · QRY-02/QRY-15 · `RequirementConsolidationController.php:48,49,342-350` — replace `::all()` / unfiltered `orderBy()->get()` dropdown loaders with `->get(['id','name'])` or `->pluck('name','id')`; the create screen alone loads 539 + 123 rows. Effort: S.
- [x] **RCC-21** · M · QRY-01/VIEW-02 · `RequirementConsolidationController.php:771-773` — add `->with(['classRequirementGroup','classRequirementSubgroup','academicTerm','class','section','subject'])` to the trash paginator so the six per-row relations are eager-loaded. Effort: S.
- [x] **RCC-CACHE** · M · DECISION · QRY / CACHE-001 · `RequirementConsolidationController.php:342-350` — the create/edit dropdowns (masters, room types, timetable types) are re-queried on every open and are a caching candidate.
      (a) ⭐ Add a tenant-keyed cache (`cache()->remember("tenant:{tenant_id}:req-dropdowns", …)`) and bust it on master change. Cache key must carry the tenant id (TEN-02).
      (b) Leave uncached.
      ➜ Choice: (b) No cache — slim the dropdown queries only (Tarun, 2026-10-14)

## 7. Views (F10)

- [x] **RCC-23** · L · VIEW · `resources/views/class-group-requirement/edit.blade.php` (196), `index.blade.php` (44), `show.blade.php` (25) — orphan blades no method renders; `edit.blade.php` also calls a non-existent route. Delete them **unless RCC-22(a)** reintroduces the legacy screen (then wire them instead). Effort: S.

## 8. Style (F12) — one item per file

- [x] **RCC-13** · L · CTL-04 · `RequirementConsolidationController.php` — add return types to all 15 public methods. Effort: S.
- [x] **RCC-14** · L · CTL-08 · `RequirementConsolidationController.php:375` — use the injected `$request` instead of `request()->route()`. Effort: S.
- [x] **RCC-26** · L · STY-01 · `RequirementConsolidationController.php`, `RequirementConsolidation.php`, `ClassSubjectGroup.php`, `ClassRequirementGroup.php`, `ClassRequirementSubgroup.php`, `RequirementTableTruncator.php` — add `declare(strict_types=1);`. ⚠ SHARED — several files are reachable by other reports; type-hint/declare only. Effort: S.
- [x] **RCC-27** · L · STY-04 · `RequirementConsolidationController.php:1221,1411,1422,1426` and `RequirementTableTruncator.php:21,27,135` — remove emoji from comments. Effort: S.
- [x] **RCC-28** · L · STY-02 · `ClassRequirementGroup.php` — run `vendor/bin/pint` on this file (`fully_qualified_strict_types`). It is the only in-scope file that fails `pint --test`. Effort: S.

## 9. Deferred / decisions

- [x] **RCC-08** · M · DECISION · CTL-01 — the controller is 1,616 lines / 15 methods and `update()` is 337 lines (RCC-09). Split?
      (a) ⭐ Defer to the split pass (D3) — make no structural change now.
      (b) Extract the generation methods (`processClassSubject*`, `map*`, `feasibleMaxPerDay`) into a `RequirementGeneratorService` now.
      (c) Leave as is; record as accepted.
      ➜ Choice: (a) Defer to the split pass (D3, 2026-10-14)
- [x] **RCC-30** · M · DECISION · deep read · `RequirementConsolidationController.php:1219-1225` — `generateRequirements` truncates `tt_requirement_consolidations` **and six later pipeline stages** before rebuilding; a mid-run failure leaves all seven empty (the fixed-message catch says so). This is the deliberate D2 truncate-rebuild contract.
      (a) ⭐ Accept as documented: add a code comment naming this accepted hazard and the 2026-10-10 decision; no behaviour change.
      (b) Add a pre-truncate confirmation/guard that refuses when the run would empty tabs the user has not re-confirmed.
      (c) Leave unchanged; record as accepted.
      ➜ Choice: (a) Accept the documented D2 truncate-rebuild hazard (2026-10-14)
- [x] **RCC-11** · M · CTL-05/CTL-10 · `RequirementConsolidationController.php:481-704` — the legacy `update` branch is unreachable (its route name is never registered) and duplicates `store`. Remove the 224-line block and the unused `$classGroupRequirement = RequirementConsolidation::find($id)` at `:373`. Effort: S. *(Listed here because it is dead-code removal, not a blocker.)*
- [ ] **RCC-09** · H · CTL-02 · `RequirementConsolidationController.php:68-295, 369-705` — `store()` (228 lines) and `update()` (337 lines) are over the 150-line limit. If RCC-08(b) is chosen, extract a service; otherwise tracked for the split pass. **(No standalone action unless RCC-08(b).)**
- [ ] **RCC-12** · M · CTL-06 · `RequirementConsolidationController.php:1294-1615` — generation/business logic (`processClassSubject*`, `map*`, `feasibleMaxPerDay`) sits in the controller. Fold into RCC-08(b); otherwise recorded as debt. **(No standalone action unless RCC-08(b).)**
- [ ] **RCC-10** · M · CTL-03 · `RequirementConsolidationController.php` — seven methods use `$id` + `findOrFail` instead of route model binding. Mechanical, but safer to fold into the split pass. **(No standalone action recommended now.)**
- [x] **RCC-19** · M · SVC-02 · `RequirementConsolidationController.php:1225` — resolve `RequirementTableTruncator` by constructor injection instead of `app(...)`. Effort: S.
- [x] **RCC-24** · M · SEC-03 · `RequirementConsolidationController.php:1527,1605` — remove the `?? 1` room-type fallback; use the configured value or `null` and surface the gap. Effort: S.
- [x] **RCC-25** · M · SEC-02 · `RequirementConsolidationController.php:1085` — return a mapped array instead of the whole `$requirement` model in the AJAX JSON. Effort: S.
- [x] **RCC-31** · L · deep read · `RequirementConsolidationController.php:1321-1326,1364-1369` — the upsert key includes a nullable column, so group rows never trigger `ON DUPLICATE KEY`. Latent (table is truncated first). Record as accepted unless a non-truncating regenerate is ever added. Effort: —
- [x] **RCC-32** · L · deep read · `RequirementConsolidationController.php:1046-1047` — `?? 0` / `?? 50` silently reset omitted fields on a partial AJAX payload. Change to keep the existing value when the key is absent. Effort: S.

> **How to approve**
> 1. Tick `[x]` on each item to apply.
> 2. Fill every `➜ Choice:` on a ticked DECISION item (`RCC-22`, `RCC-04`, `RCC-18`, `RCC-CACHE`, `RCC-08`, `RCC-30`).
> 3. Give each `⚠ SHARED` item its own explicit tick (`RCC-07` route file; `RCC-22(b)`/`RCC-26` cross-report files).
> 4. Then run `final-audit-fixer` on `Modules/TimetableFoundation/app/Http/Controllers/RequirementConsolidationController.php`.
