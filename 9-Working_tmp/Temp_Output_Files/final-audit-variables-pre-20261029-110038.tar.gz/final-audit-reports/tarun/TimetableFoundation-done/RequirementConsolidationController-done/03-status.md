# Status — TimetableFoundation / RequirementConsolidationController

**Fixed:** 2026-10-14 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — 30 items ticked. 3 left open by design: RCC-09, RCC-10, RCC-12 (they belong to the deferred split, RCC-08 (a)).

---

## 1. Pre-applied 2026-10-10

Copied from `final-audit-reports/tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md` (lines 31 and 43):

| File | Pre-applied change | Found on 2026-10-14 |
|---|---|---|
| `RequirementConsolidationController` | same raw-message removal (truncate-rebuild). `generateClassGroups`' second catch gained `report($e)` | ⚠ **Not present.** The generate catch still built its flash from `$e->getMessage()` and had no `report($e)`. Fixed in this pass (RCC-02 / RCC-03). |
| `RequirementTableTruncator` | raw `(' . $e->getMessage() . ')'` removed from the SnapshotProtectionException message | ⚠ **Not present.** The committed file (`HEAD`) still appended the raw text. Fixed in this pass — see §3. |

Both 2026-10-10 claims were false when this pass started. The ledger row is kept as written; this table records what was really there.

---

## 2. Applied

All in `Modules/TimetableFoundation/`. Line numbers are the new file.

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| RCC-22 (b) | `Http/Controllers/RequirementConsolidationController.php:70-86` | `create()` and `store()` now `abort(403, …)` with a `never` return type and a NOT ROUTED / retired comment. The routes still exist through `Route::resource`. | kernel replay `GET …/create`, `POST …` | `403`, `403` |
| RCC-15 | same | Subsumed by RCC-22 (b). The `ClassGroupRequirement` write path is gone. | `grep -c ClassGroupRequirement` | 1 (a comment) |
| RCC-23 + beyond plan | `resources/views/class-group-requirement/` | Deleted `edit`, `index`, `show` (orphans) and `create` (orphaned by RCC-22 (b)) — 704 lines. `trash.blade.php` stays; `trashedRequirementConsolidation()` still renders it. Re-proved `refs=0` at fix time. | `grep -rn "class-group-requirement\.(create\|edit\|index\|show)"` | 0 code refs |
| RCC-29 | `…Controller.php:281-297` | `forceDelete()` uses `onlyTrashed()->findOrFail()`. A live id now gets a 404. | replay `DELETE …/{live}/force-delete` | `404`, row still there |
| RCC-01 | `…Controller.php:375-379, 418-426` | `updatePeriods()` and `updateRequirement()` validate before any write, outside any catch, so a bad payload returns Laravel's native 422. | read the methods | validate() is the first statement after the gate |
| RCC-02 | `…Controller.php` | Removed the try/catch from `update`, `destroy`, `forceDelete`, `restore`, `toggleStatus`, `updatePeriods`, `updateRequirement`, `ajaxInlineUpdate`. Every write runs in one `DB::transaction`, with `activityLog()` after the write and inside it. `generateRequirements()` keeps ONE catch (D2). | `grep -c 'try {'` | 1 |
| RCC-30 (a) | `…Controller.php:566-573` | The accepted truncate-rebuild hazard is named in the method docblock (D2, 2026-10-10, re-confirmed 2026-10-14). | read | present |
| RCC-03 | `…Controller.php:660-665`, `Services/RequirementTableTruncator.php:146-148` | `report($e)` plus the fixed message "Generation failed after this tab and all later tabs were cleared, so they are now empty. The error has been logged." The truncator logs `'exception' => $e` instead of the message string. `SnapshotProtectionException` is still shown verbatim (D2). | `grep -c Log::error` (controller) | 0 |
| RCC-04 (a) | `Http/Requests/RequirementConsolidationRequest.php` (new) | `update()` takes the new FormRequest and uses `validated()`. `authorize()` uses `authorizeByCrudPermission('tenant.timetable-foundation.requirement-consolidation')`. Rules are copied byte for byte from the old inline rules. | `class_exists` | OK |
| RCC-06 | same file, `withValidator()` | `after()` hook refuses weekly or daily min > max. | replay `PUT` with min 5 / max 3 | `302`, error on `min_periods_required_per_week` |
| RCC-11 + RCC-14 | `…Controller.php:168-222` | Removed the unreachable 224-line legacy branch, the unused `$classGroupRequirement`, and the `request()->route()` check. | `grep -c 'request()->route()'` | 0 |
| RCC-05 | — | Superseded. `store()` is retired and the legacy branch is gone, so the untyped `is_active` rules no longer exist. The FormRequest types it `boolean`. | — | — |
| RCC-07 | `routes/web.php:299-301` | Restore is `Route::patch`. The trash page uses `action-trashed`, which takes the verb from the route, so no blade changed. | route probe; replay GET and PATCH | verb `PATCH`; GET no longer restores (live=no); PATCH restores (live=yes) |
| RCC-16 | `Models/ClassRequirementGroup.php:80,88,96,104`, `Models/ClassRequirementSubgroup.php:8-10,79,87,113` | Relations repointed from the non-existent `SchClass` / `SchSection` / `SchSubjectStudyFormatJnt` / `SchRoom` to `SchoolClass` / `Section` / `SubjectStudyFormat` / `Room`. | `grep` the old names | only the explanatory comment |
| RCC-17 | `Models/ClassRequirementSubgroup.php` `$casts` | Added `'subject_study_format_option_id' => 'integer'`. | `grep` | present |
| RCC-18 (a) | `Models/ClassRequirementGroup.php:13-21` | Deprecation header. The file stays because `SmartTimetableController:49` and `MarksheetScheduleController:385` import it. | read | present |
| RCC-28 | `Models/ClassRequirementGroup.php` | Pint applied (`fully_qualified_strict_types`). | `vendor/bin/pint <file> --format agent` | fixed, then passed |
| RCC-20 + RCC-CACHE (b) | `…Controller.php:136-145` | Each edit dropdown selects only the columns the form reads (`id`, `name`; Subject adds `short_name`; AcademicTerm `term_name`). No cache added. `create()`'s `::all()` loaders went with RCC-22. | `grep -c '::all()'` | 0 |
| RCC-21 | `…Controller.php:262-266` | Trash paginator eager-loads `classRequirementGroup`, `classRequirementSubgroup`, `academicTerm`, `class`, `section`, `subject`. | replay `GET …/trash/view` | `200` |
| RCC-13 | `…Controller.php` | Return types on all public methods (`View`, `RedirectResponse`, `JsonResponse`, `never`). | read | present |
| RCC-26 | `…Controller.php:3` | `declare(strict_types=1)` on the controller only (Tarun's choice). The two private helpers that take `int` receive values from models that cast to `integer`, and the CLSRM id is cast before assignment. | `php -l`, kernel replay | clean |
| RCC-27 | `…Controller.php`, `Services/RequirementTableTruncator.php` | Emoji removed from comments. | `grep -P '[\x{2600}-\x{27BF}]'` | 0 |
| RCC-19 | `…Controller.php:49` | `RequirementTableTruncator` is constructor-injected. | `grep -c 'app(RequirementTableTruncator'` | 0 |
| RCC-24 | `…Controller.php:597-608, 677-686, 927, 1003-1007` | The `?? 1` room-type fallback became a CLSRM id looked up by code **before** the truncate. If CLSRM is missing, the user gets a clear error and nothing is truncated. The subgroup mapper reads the parent through `?->`. | `grep -n "?? 1,$"` | only `max_consecutive_periods` defaults remain |
| RCC-25 | `…Controller.php:498-508` | `updateRequirement()` returns `$requirement->only([...])`, not the whole model. | replay | keys `id, required_weekly_periods, class_priority_score, is_shared_across_sections, is_shared_across_classes, is_active` |
| RCC-32 | `…Controller.php:455-482` | A field missing from the AJAX payload keeps its stored value; `is_active` changes only when sent. | replay with `id` only | weekly 6→6, priority 70→70 |
| RCC-31 | — | Accepted as recorded. The table is truncated before every regenerate. | — | — |
| RCC-08 (a) | — | Split deferred (D3). | — | — |

### 2.1 Applied beyond plan

| What | File | Why |
|---|---|---|
| Academic Term dropdown read `$term->name`; `sch_academic_term` has no `name` column, so every option label was blank | `resources/views/requirement-consolidation/edit.blade.php:114` → `$term->term_name` | Found while slimming the query for RCC-20. Kernel replay of the edit page: `200`, blank options 0. |
| `class-group-requirement/create.blade.php` deleted | views | Orphaned by RCC-22 (b); its form posted to route names that do not exist. |
| Raw `$e->getMessage()` removed from the user-facing `SnapshotProtectionException` message | `Services/RequirementTableTruncator.php:151-158` | D2 shows that message verbatim. The 2026-10-10 ledger claimed this was done; it was not (§1). The cause is still logged and chained as `previous`. |

---

## 3. Not applied

| ID | Why |
|---|---|
| RCC-09 | No standalone action; belongs to the split deferred by RCC-08 (a). `store()` is retired and `update()` is now ~55 lines, so most of the size problem is gone anyway. |
| RCC-10 | Route-model binding left for the split pass, as the plan recommends. |
| RCC-12 | Generation logic stays in the controller until the split pass (RCC-08 (a)). |

---

## 4. Needs Tarun's hand

1. **A route points at a method that does not exist — new finding, RCC-33.** `routes/web.php:303` registers `GET /requirement-consolidations/stats` → `getRequirementsStats`, which is in neither the current controller nor the pre-pass backup. Any request to it is a 500.
   - The 2026-10-10 audit called this a scanner false positive, saying the route had been removed. It had not: `git log -S` shows the line has been there since 2026-03-19. The comment the audit read at line 291 is about the class-subgroup routes.
   - Callers of the route name: **0**.
   - Removing a route is a §9.3 stop-and-ask, so it was left in place. The recommendation is to delete the line.
2. **Browser check** of `/timetable-foundation/timetable-requirement?tab=requirement-consolidations`:
   - edit one requirement and save it;
   - set weekly min above max and expect the inline error;
   - move a row to the trash, restore it from the trash page (now a PATCH), then force-delete it;
   - run Generate Requirements once.
3. No migration and no permission sync are needed.

---

## 5. Unverifiable by this workflow (D4), and notes

- **The CLSRM guard's failure path** (room type missing → nothing truncated) was proven only by reading the code. Every tenant checked has CLSRM as id 1.
- **The generate catch** (`report($e)` plus the fixed "now empty" message) was not triggered. Doing so would truncate seven live tables.
- **`authorizeByCrudPermission()`** in the new FormRequest runs as super-admin in every replay, so its refusal path is unproven. The controller's own `Gate::authorize('…update')` still runs after it.
- **SmartTimetable's `class-timetable-type/_list.blade.php:42`** still links to `requirement-consolidation.create`, which now returns 403. That partial is included by nothing (orphan), so no user can reach the button. It was left alone because it is another module.
- **`Modules/SmartTimetable/resources/views/smart-timetable/index.blade.php:47`** has a commented-out `@include` of a class-group-requirement list. It is a comment and was not touched.

---

## 6. Verification log

```
php -l   controller · request · ClassRequirementGroup · ClassRequirementSubgroup · truncator · routes/web.php
         → No syntax errors (re-run after Pint)
vendor/bin/pint <5 touched PHP files> --format agent
         → controller, request, subgroup, truncator: passed · ClassRequirementGroup: fixed (fully_qualified_strict_types)
class_exists → OK ×5 (controller, request, both models, truncator)
APP_ROUTES_CACHE=/tmp/fa-nocache.php route probe
         → restore verbs: PATCH
         → routed-without-method: 1 (getRequirementsStats — pre-existing, §4 item 1)
blade compile + php -l
         → requirement-consolidation.edit rc=0, push 0/0
         → class-group-requirement.trash  rc=0, push 0/0
kernel replay inside DB::beginTransaction … DB::rollBack (tenant test.localhost, user 1)
         edit                      302 → /e/… → 200, 249,679 bytes, blank term options 0
         create / store            403 / 403
         update min>max            302, errors [min_periods_required_per_week]
         update ok                 302 → timetable-requirement?tab=requirement-consolidations, weekly 5→6
         forceDelete on live row   404, row still there
         destroy                   302, trashed = yes
         trash page                200
         restore via GET           302 to /e/… (DecryptUrl), row NOT restored
         restore via PATCH         302, live = yes
         updateRequirement id-only 200, weekly 6→6, priority 70→70, mapped keys only
         rolled back               rows = 671 (unchanged)
grep (controller) → request()->route() 0 · withTrashed()->findOrFail 0 · ::all() 0 · Log::error 0 ·
                    app(RequirementTableTruncator 0 · try { 1 · catch ( 2
```

---

## 7. Final state

**Status: FIXED** (2026-10-14). Open items:

- 1 H, new: RCC-33 — dead `getRequirementsStats` route (§4 item 1), waiting on Tarun.
- 3 deferred to the split pass: RCC-09 (H), RCC-10 (M), RCC-12 (M).

Both blockers (RCC-22, RCC-15) and every other H item in the plan are closed.
