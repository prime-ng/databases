# TimetableFoundation — Module Audit Summary

**Protocol:** `.claude/rules/final-audit.md` §13.2 · **Rulebook:** `../prime_info/Final/CodeReview/00-RULEBOOK.md`
**Audited:** 2026-10-10 · **By:** claude (AcademicTerm) + opencode (27 controllers)
**Phase:** AUDIT. Read-only — no application code changed.

All 28 controllers of `Modules/TimetableFoundation` are audited. One folder per controller holds
`01-report.md` + `02-fix-plan.md`. Tick items in each plan, then run `final-audit-fixer` on the
controller path.

## 1. Per-controller results

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| TimetableFoundationController | 4,320 | 0 | 7 | 12 | 7 | 11 | TFC-03 — ~500 dead queries / ~256 ms per requirement load; 4,320-line god controller | [01](TimetableFoundationController-done/01-report.md) |
| RequirementConsolidationController | 1,616 | 2 | 7 | 15 | 8 | 6 | RCC-22 — "+" button opens a create screen that 500s on render; `store()` fatals on an undefined class | [01](RequirementConsolidationController-done/01-report.md) |
| ActivityController | 1,624 | 0 | 1 | 8 | 8 | 3 | ACT-08 — `generateActivities()` is 987 lines with per-requirement/per-teacher query fan-out | [01](ActivityController-done/01-report.md) |
| PeriodSetController | 1,153 | 0 | 7 | 20 | 5 | 11 | PSC-03 — `update()` not atomic (7 write units, no single transaction) | [01](PeriodSetController-done/01-report.md) |
| WorkingDayController | 970 | 0 | 4 | 11 | 4 | 5 | `create`/`show`/`edit` route to views that do not exist → 500 | [01](WorkingDayController-done/01-report.md) |
| TimetableTypeController | 895 | 0 | 4 | 8 | 7 | 6 | TTY-16 — `whereIn('academic_term_id',[null])` resync matches nothing; duplicate rows re-inserted | [01](TimetableTypeController-done/01-report.md) |
| ClassWorkingDayController | 820 | 0 | 5 | 17 | 7 | 6 | CWD-18 — `SpecialDayAssigned` event has no listener; notification silently never sent | [01](ClassWorkingDayController-done/01-report.md) |
| ClassSubjectSubgroupController | 790 | 1 | 7 | 16 | 4 | 7 | CSG-14 — CRUD loads non-existent `SmartTimetable\ClassSubgroup`/`ClassGroupJnt`; every route 500s | [01](ClassSubjectSubgroupController-done/01-report.md) |
| TeacherAssignmentRoleController | 622 | 0 | 3 | 6 | 6 | 4 | TAR-13 — `forceDelete()` purges a live role via `withTrashed()` | [01](TeacherAssignmentRoleController-done/01-report.md) |
| ClassTimetableTypeController | 594 | 1 | 6 | 8 | 6 | 5 | CTT-01 — `ClassTimetableType` missing `SoftDeletes`; destroy hard-deletes, trash 500s | [01](ClassTimetableTypeController-done/01-report.md) |
| TimetableAssignmentController | 540 | 0 | 2 | 6 | 10 | 4 | TTA-03 — check-then-act default guard (TXN-06 race) | [01](TimetableAssignmentController-done/01-report.md) |
| TeacherAvailabilityController | 533 | 0 | 3 | 6 | 6 | 5 | TAV-10 — one query per requirement (662 → ~1,324 queries per Generate) | [01](TeacherAvailabilityController-done/01-report.md) |
| PeriodConfigController | 504 | 0 | 4 | 6 | 8 | 3 | PCF-13 — undefined `period-config.create` route in the list page → 500 | [01](PeriodConfigController-done/01-report.md) |
| DayTypeController | 490 | 0 | 2 | 6 | 5 | 6 | DTC-12 — `forceDelete()` purges a live type, orphaning 4,620 join rows (no FK) | [01](DayTypeController-done/01-report.md) |
| SchoolDayController | 480 | 0 | 2 | 4 | 6 | 3 | SDY-12 — `forceDelete()` destroys a live school day | [01](SchoolDayController-done/01-report.md) |
| PeriodSetPeriodController | 471 | 2 | 3 | 13 | 6 | 5 | PSP-01 — `PeriodSetPeriod` missing `SoftDeletes`; destroy hard-deletes while claiming "trash" | [01](PeriodSetPeriodController-done/01-report.md) |
| PeriodTypeController | 437 | 0 | 2 | 6 | 6 | 4 | PTC-13 — `forceDelete()` destroys a live period type | [01](PeriodTypeController-done/01-report.md) |
| AcademicTermController | 431 | 0 | 4 | 7 | 6 | 8 | ATC-03 — `forceDelete()` on a live term blanks 662 requirement rows | [01](AcademicTermController-done/01-report.md) |
| TimingProfileController | 348 | 1 | 3 | 8 | 6 | 4 | TPR-01 — model + table missing; all 11 routes 500 | [01](TimingProfileController-done/01-report.md) |
| SchoolShiftController | 321 | 0 | 2 | 3 | 6 | 2 | SSH-02 — `forceDelete()` purges a live shift | [01](SchoolShiftController-done/01-report.md) |
| SchoolTimingProfileController | 293 | 2 | 2 | 9 | 6 | 3 | STP-01 — model + table missing; 10/11 routes 500 (plus missing `Period`) | [01](SchoolTimingProfileController/01-report.md) |
| TimetableController | 279 | 2 | 5 | 6 | 8 | 6 | TBL-05 — validates against non-existent `sch_organization_academic_sessions`; create silently fails | [01](TimetableController-done/01-report.md) |
| SlotRequirementController | 267 | 0 | 4 | 6 | 10 | 5 | SLR-17 — generate TRUNCATEs requirements for every term/type, not just the selected one | [01](SlotRequirementController-done/01-report.md) |
| SubActivityDetailController | 249 | 1 | 2 | 3 | 3 | 3 | SAD-05 — eager-loads `sch_teachers.name` (no such column) → listing 500s | [01](SubActivityDetailController-done/01-report.md) |
| ConfigController | 213 | 0 | 1 | 6 | 8 | 2 | CFG-03 — partial `update()` silently deactivates the config | [01](ConfigController-done/01-report.md) |
| OptimisationReportController | 176 | 0 | 2 | 5 | 3 | 2 | OPT-05 — pre-assigned `SchoolOptimisationReportService` is a 2,871-line, 45-method god class | [01](OptimisationReportController-done/01-report.md) |
| RoomAvailabilityController | 115 | 0 | 1 | 6 | 2 | 3 | RAV-04 — reimplements room-ratio arithmetic wrong; stamps a wrong availability status | [01](RoomAvailabilityController-done/01-report.md) |
| PriorityConfigController | 60 | 0 | 0 | 6 | 6 | 5 | PRC-03 — destructive truncate of `tt_priority_configs` gated by a **read** permission | [01](PriorityConfigController/01-report.md) |

## 2. Module totals

| B | H | M | L | DECISIONs |
|---|---|---|---|---|
| **12** | **95** | **233** | **173** | **~137** |

**Blockers (B=12):** RequirementConsolidation ×2, ClassSubjectSubgroup, ClassTimetableType,
PeriodSetPeriod ×2, TimingProfile, SchoolTimingProfile ×2, Timetable ×2, SubActivityDetail.
Every one is a page-killer or a hard data-loss path on a reachable screen.

## 3. Cross-controller families (fix as one change)

1. **`forceDelete()` accepts a LIVE row** (`withTrashed()->findOrFail($id)` + no child guard) —
   the single most repeated defect: AcademicTerm, PeriodType, DayType, SchoolShift, SchoolDay,
   TeacherAssignmentRole, ClassTimetableType. A crafted DELETE permanently destroys a non-trashed
   record, sometimes blanking FK children (SET NULL).
2. **Missing model / table / column → controller-wide 500s** — TimingProfile (model+table),
   SchoolTimingProfile (model+table), ClassSubjectSubgroup (SmartTimetable models),
   SubActivityDetail (wrong column), Timetable (wrong table name). Several features are orphaned.
3. **SoftDeletes drift** — models without the trait over tables that have `deleted_at`
   (ClassTimetableType, PeriodSetPeriod): destroy hard-deletes while claiming "moved to trash",
   and trash/restore routes 500.
4. **`restore` over GET** (RTE-01) — AcademicTerm, PeriodType, DayType, WorkingDay,
   TeacherAssignmentRole, PeriodConfig, PeriodSetPeriod, TimetableAssignment and others. GET has
   no CSRF; a prefetcher can trigger it.
5. **`\DomainException` + one D2 catch** was applied on 2026-10-10 to WorkingDay, ClassWorkingDay,
   Activity, RequirementConsolidation, TeacherAvailability, PriorityConfig, TimetableFoundation,
   RoomAvailability, ClassSubjectSubgroup; the audits confirm it is **incomplete** on WorkingDay
   (7 methods still catch) and a few siblings.
6. **God classes** — `TimetableFoundationController` (4,320 lines), `generateActivities()` (987),
   `SchoolOptimisationReportService` (2,871 / 45 methods). All splits are DEFERRED (D3).
7. **N+1 / dead-query fan-out** — TimetableFoundationController (~500 dead queries/load),
   TeacherAvailability (~1,324 queries/Generate), Activity generation.

## 4. Shared classes and their owner reports

`../00-CLASS-OWNERS.md` is the registry. Key owners: `AcademicTerm` → AcademicTermController;
`Activity`/`SubActivity*`/`Activity*` + 5 services → ActivityController; `PeriodSet` →
PeriodSetController; `WorkingDay` → WorkingDayController; `DayType` → DayTypeController;
`PeriodType` → PeriodTypeController; `RequirementConsolidation`/`Class*Group*` +
`RequirementTableTruncator` → RequirementConsolidationController; `TimetableType`, `ClassWorkingDay`,
`SchoolShift`, `SchoolDay`, `ClassSubjectSubgroup`, `TeacherAssignmentRole`, `ClassTimetableType`,
`TimetableAssignment`/`ClassTimetableResolver`, `TeacherAvailability`/`OptionStaffingService`,
`PeriodConfig`, `PeriodSetPeriod`, `Timetable*`, `SlotRequirement`/`SlotRequirementGridService`,
`SubActivityDetail*`, `Config`, `SchoolOptimisationReportService`, `RoomAvailability*`,
`PriorityConfigService`, and the 9 TimetableFoundationController services. Policies claimed during
the run: `WorkingDayPolicy`, `DayTypePolicy`, `DayPolicy`, `TimetablePolicy`,
`SubActivityObserver`, `SpecialDayAssigned`, `SnapshotProtectionException`. No duplicate claims.

## 5. Module-wide decisions (need one answer, then apply everywhere)

1. **Unreachable policies.** Every module Policy is dead code: gates pass permission *strings*, so
   no Policy is ever consulted. One decision fixes the whole module (or documents it as intended).
2. **Permission-string gates with no `Gate::define`.** `Gate::authorize('tenant.…')` with no
   matching definition is a no-op unless a Gate::before / permission package intercepts. Confirm
   the interception and the `.viewAny`-gated destructive actions (PriorityConfig PRC-03).
3. **Soft-delete × unique-index trap** recurs (AcademicTerm, SubActivityDetail, Config,
   ClassSubjectSubgroup, PeriodType): a UNIQUE index that ignores `deleted_at` blocks re-create.
4. **Cross-module regressions in SmartTimetable** (another module): blades still call the removed
   `day-type.create` and `school-day.create` routes → 500 if rendered. Recorded in the DayType and
   SchoolDay reports §7; not fixed by this workflow.

## 6. Status

- **Index:** all 28 rows `AUDITED` (`00-INDEX.md`).
- **Not fixed:** the audit is read-only. Fixes wait on Tarun ticking `02-fix-plan.md` items and
  the final-audit-fixer run, one controller at a time.
- **Blocked:** nothing.
- **Next:** approve plans (tick `[x]`, fill every `➜ Choice:`), then run the fixer per controller.
  Re-audit (mode §14) is available once a controller is `FIXED`.
