# Status — TimetableFoundation / SubActivityDetailController

**Fixed:** 2026-10-14 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — 9 items ticked, all applied. All three DECISION items took option (a).

---

## 1. Pre-applied work (2026-10-10)

None. This controller is not listed in `PRE-APPLIED-2026-10-10.md`.

---

## 2. Applied

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| SAD-05 (a) | `SubActivityDetail.php` `teacher()` + controller `index()` | `teacher()` now `belongsTo(TeacherProfile::class, 'assigned_teacher_id')`, the table `fk_subact_detail_teacher` and the DDL reference (it was `Teacher` / `sch_teachers`). `index()` eager-loads `teacher:id,user_id`, `teacher.user:id,name`, `room:id,name`. The old `teacher:id,name` would 1054 on the first assigned teacher; neither teacher table has `name`. | kernel replay, `index` after a store | 200, `teacher.user.name = AJAY BHATIA` |
| SAD-09 (a) ⚠ SHARED | new `database/migrations/tenant/2026_10_14_000001_alter_tt_sub_activity_details_soft_delete_aware_unique.php` | Adds `deleted_key` (STORED, `COALESCE(deleted_at, epoch)`) and rebuilds `uq_subact_detail` to include it, so a trashed period no longer blocks a re-add. Also adds `idx_subact_detail_subact` first — the old key was the only index `fk_subact_detail_subact` could use. Refuses with a readable message if live duplicates exist. **Written, not run.** | DDL tested on a throwaway database, then dropped | applies; trash then re-add OK; cascade OK |
| SAD-02 (a) ⚠ SHARED | same migration + `SubActivityDetailSeeder.php` `insertMissing()` | Adds `sub_activity_key` (VIRTUAL, `COALESCE(sub_activity_id, 0)`) to the key, so activity-direct rows (1,735 of 2,013) are unique per period too. The seeder's read and bulk insert now share one `DB::transaction`. | throwaway DB: duplicate activity-direct insert | 1062, as intended |
| SAD-04 | `SubActivityDetailRequest.php` | `assigned_teacher_id` → `Rule::exists('sch_teacher_profile','id')->whereNull('deleted_at')` (was `exists:sch_teachers,id`). | kernel replay, teacher 999999 | 422 on `assigned_teacher_id` |
| SAD-01 | controller `seed`/`store`/`update`/`destroy` | The four `try/catch (\Throwable)` blocks and their `Log::error` calls are gone (D1). Each write is one `DB::transaction`; the central handler logs and renders failures as JSON. A duplicate live period is refused by validation (422) instead of by a catch around the insert. ⚠ A `DomainException` pre-check was NOT used: on a JSON call `bootstrap/app.php` renders it as a 500 (and hides the message in production), so it cannot give a 422. | `grep -c "try {\|Log::" <controller>` | 0 · 0 |
| SAD-03 | new `Http/Requests/SubActivityDetailRequest.php` | One request for `store` (POST) and `update` (PATCH). `authorize()` checks `.create` / `.update` by verb. Store adds `period_number` with a `Rule::unique` scoped to the sub-activity and live rows, mirroring the index, and a readable message. `seed`'s single-field `count` rule stays inline. | kernel replay | dup → 422 "This sub-activity already has a plan row for that period." |
| SAD-06 | `SubActivityDetail.php` docblock | The false "uniqueness is NOT enforced at the DB level" now describes the rebuilt key, both generated columns, and that they must never be written. | read | as described |
| SAD-07 | `SubActivityDetailSeeder.php` | `seedForSubActivity()` / `seedForActivity()` take `?int $userId`; the service no longer reads `auth()`. The controller passes `$request->user()?->id`. `now()` is kept: a clock read is not request state. | `grep -n "auth()" <seeder>` | comment only |
| SAD-08 | controller, model, seeder (+ request, migration) | `declare(strict_types=1)` on all; Pint run on the touched files only. | `vendor/bin/pint <files> --format agent` | fixed: model (3 fixers), seeder (3 fixers) |

### 2.1 Beyond the plan

| File | What changed | Why |
|---|---|---|
| `Observers/ActivityObserver.php`, `Observers/SubActivityObserver.php` | Pass `auth()->id()` to the seeder. | Removing `auth()` from the service (SAD-07) would otherwise have left `created_by` NULL on every observer-seeded row — a silent behaviour change. The backfill command runs from the CLI, where it was always NULL, so it is unchanged. |

---

## 3. Not applied

Nothing ticked was left out.

---

## 4. Needs Tarun's hand

1. **Run the migration:** `php artisan tenants:migrate`. Until then the old key is live: a trashed period still blocks a re-add, and activity-direct rows are still only guarded by the code. The new validation rule already refuses duplicate live periods through `store`.
2. **Update the DDL.** `Timetable_DDL_v7.8.sql` does not have `deleted_key`, `sub_activity_key` or the new key. The `.sql` was not edited (rule: never edit the DDL to match the code).

---

## 5. Unverifiable by this workflow (D4), and notes

- **Teacher ids.** The Period Plan blade (`_period-plan-table.blade.php:65`) compares `assigned_teacher_id` with capable-teacher ids built from `sch_teachers` (`TimetableFoundationController.php:1744`). On test.localhost all 89 teachers have the same id in both tables (measured 2026-10-14), so nothing differs today. If the two tables ever drift, that comparison will mismatch — the SchoolSetup question of one canonical teacher table is still open (plan §9).
- **The migration is unrun on the tenant.** It was proven on a throwaway database with the same column types and foreign keys, not on test.localhost.
- **The race between two simultaneous stores** is caught by the unique key (after the migration) and surfaces as the central handler's 500, not a 422. Validation covers the normal case.
- No test suite was run (D4).

---

## 6. Verification log

```
php -l  — 7 touched files                                         all OK (before and after Pint)
class_exists — controller, request, model, seeder, 2 observers    all OK
route probe (APP_ROUTES_CACHE=/tmp/fa-nocache.php)
  GET    sub-activity/{subActivity}/details        index   exists=Y params=subActivity       sig=subActivity
  POST   sub-activity/{subActivity}/details        store   exists=Y params=subActivity       sig=request,subActivity
  POST   sub-activity/{subActivity}/details/seed   seed    exists=Y params=subActivity       sig=request,subActivity,seeder
  PATCH  sub-activity-detail/{subActivityDetail}   update  exists=Y params=subActivityDetail sig=request,subActivityDetail
  DELETE sub-activity-detail/{subActivityDetail}   destroy exists=Y params=subActivityDetail sig=subActivityDetail
blade compile — none touched (JSON API)
kernel replay, test.localhost, user 1, inside DB::beginTransaction / rollBack
  index    200 count=6
  store    201 status=TEACHER_ASSIGNED   (teacher = a sch_teacher_profile id)
  dup      422 "This sub-activity already has a plan row for that period."
  badteach 422 assigned_teacher_id
  index2   200 teacher.user.name=AJAY BHATIA
  update   200 slot=MON-P3 teacher kept
  destroy  200
  seed     200 created=0
  logs     Stored,Updated,Trashed
  after rollback rows=2013
throwaway database (created, tested, dropped) — the migration DDL
  migration applies · duplicate activity-direct row → 1062 · trash then re-add OK · CASCADE OK
pre-check on test.localhost: duplicate live groups = 0 (direct) / 0 (sub-activity)
```

---

## 7. Final state

**FIXED.** The controller is 188 lines (was 249), with no try/catch and one transaction per write. Open items: run the migration, update the DDL, and the cross-module teacher-table question (§5).
