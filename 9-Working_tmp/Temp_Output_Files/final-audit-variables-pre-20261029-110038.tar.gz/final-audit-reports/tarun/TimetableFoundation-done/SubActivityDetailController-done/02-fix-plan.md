# Fix Plan — TimetableFoundation / SubActivityDetailController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers or other reports use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/SubActivityDetailController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.
> ℹ This controller is **not** in `PRE-APPLIED-2026-10-10.md`; there is no pre-applied shape to preserve.

## 1. Blockers reachable today
- [x] **SAD-05** · B · DECISION · MDL/usage · `SubActivityDetailController.php:34-36`, `SubActivityDetail.php:94-97` — `index()` eager-loads `teacher:id,name`, but `sch_teachers` has **no `name` column**; the listing 500s (1054) on the first teacher assignment. The FK/DDL point at a **different** table (`sch_teacher_profile`). Choose the canonical source:
      (a) ⭐ **Repoint the relation to the FK/DDL table.** Change `SubActivityDetail::teacher()` to `belongsTo(TeacherProfile::class, 'assigned_teacher_id')` (`Modules/SchoolSetup/app/Models/TeacherProfile.php`, `$table = 'sch_teacher_profile'`) and eager-load `with(['teacher.user:id,name', 'room:id,name'])`; the name lives on `sys_users`, not on either teacher table. This matches `fk_subact_detail_teacher` and the DDL. SAD-04 (the `exists:` rule) follows from this choice.
      (b) **Keep `Teacher`/`sch_teachers`, fix the columns only.** Eager-load `with(['teacher:id,user_id', 'teacher.user:id,name'])` so the existing `getNameAttribute()` accessor resolves. Removes the 500 but leaves the FK/DDL table mismatch open.
      ➜ Choice: (a) repoint to TeacherProfile — Tarun 2026-10-14

## 2. Fixes that arm a latent defect (sequenced)
- [x] **SAD-09** · H · DECISION · deep read / VAL-04 / TXN-06 · `SubActivityDetailController.php:222-230`, `SubActivityDetailSeeder.php:96-131` — a soft-deleted period can never be re-created: `uq_subact_detail (sub_activity_id, period_number)` ignores `deleted_at`, while the seeder's SoftDeletes-aware `pluck()` cannot see the trashed row, so the re-insert raises 1062 and the endpoint 422s forever.
      (a) ⭐ **Make the key soft-delete aware, additively.** A new tenant migration adds a STORED generated column `deleted_key` = `COALESCE(deleted_at, '1970-01-01 00:00:00')`, drops `uq_subact_detail`, and recreates it as UNIQUE `(sub_activity_id, period_number, deleted_key)`. Live rows keep uniqueness; a trashed row no longer blocks a new live row. ⚠ SHARED — tenant migration; the fixer writes it, you run `php artisan tenants:migrate`. Also correct the false model docblock (SAD-06).
      (b) **App-only.** The seeder (and `store`) detects a matching trashed row and restores it instead of inserting. No migration, but it hard-restores data and `store()` must carry the same branch.
      (c) **Accept.** Document that a period row must never be deleted.
      ➜ Choice: (a) additive migration with generated deleted_key — Tarun 2026-10-14
- [x] **SAD-04** · H · VAL / DDL-drift · `SubActivityDetailController.php:108, 166` — the `exists:` rule checks `sch_teachers` while the FK/DDL constrain `sch_teacher_profile`. **Gate this on SAD-05's choice:** change the rule to `exists:sch_teacher_profile,id` (option a) or leave the table but document the drift (option b). Do **not** apply before SAD-05, so validation and the relation agree. Effort: S.

## 3. Errors & transactions (F1/F2)
- [x] **SAD-01** · M · ERR-00 (D1) / ERR-05 / CTL-05 · `SubActivityDetailController.php:67-89, 116-154, 174-209, 221-247` — remove the four `try/catch (\Throwable)` blocks from `seed`, `store`, `update`, `destroy`:
  - Let the central handler in `bootstrap/app.php` log and render (D1). Keep validation `$request->validate(...)` outside (already is).
  - If a friendly 422 for the duplicate-period case is wanted, add it as a **`\DomainException`** pre-check (the only D2-allowed shape, with an `// ERR-01` comment and the date), not as a catch of `\Throwable`.
  - The four copy-pasted blocks go with them. Effort: S.
- [x] **SAD-02** · M · DECISION · TXN-06 · `SubActivityDetailSeeder.php:96-131` — `insertMissing()` reads-then-writes with no lock, and activity-direct rows (`sub_activity_id IS NULL`) have no DB uniqueness (MySQL treats NULLs as distinct).
      (a) ⭐ **Cover activity-direct rows too.** Extend the SAD-09 migration so `activity_id` also participates in a NULL-safe unique key (e.g. a second generated `sub_activity_key` = `COALESCE(sub_activity_id, 0)` and UNIQUE `(activity_id, sub_activity_key, period_number, deleted_key)`); wrap `insertMissing()` in `DB::transaction`. ⚠ SHARED — tenant migration.
      (b) **App-only.** `lockForUpdate()` the parent's existing rows inside a transaction before the read. Closes the sub-activity race; does not close NULL phantom inserts for activity-direct rows.
      (c) **Accept.** Document the low concurrency risk.
      ➜ Choice: (a) folded into the same migration (sub_activity_key VIRTUAL) — Tarun 2026-10-14

## 4. Authorization (F3)
_None — all 5 routed methods authorize as their first line, and the 4 permission names exist exactly once in `sys_permissions`._

## 5. Validation, routes, models (F4/F5/F7)
- [x] **SAD-03** · M · VAL-02 · `SubActivityDetailController.php:106-111, 165-170` — extract an `app/Http/Requests/SubActivityDetailRequest.php` for `store` and `update`, moving the rules verbatim (include SAD-04's table choice). Keep `seed`'s single-field `count` rule inline (one-field call). Effort: M.

## 6. Queries & performance (F9)
_None — `index()` eager-loads `teacher`/`room`; the seeder bulk-inserts in one statement._

## 7. Views (F10)
_None — JSON API, no Blade._

## 8. Style (F12) — one item per file
- [x] **SAD-06** · L · MDL/copy · `SubActivityDetail.php:25-28` — correct the docblock: `uq_subact_detail` **exists** on `(sub_activity_id, period_number)`; only activity-direct rows (`sub_activity_id IS NULL`) are genuinely unconstrained. Effort: S.
- [x] **SAD-07** · L · SVC-01 · `SubActivityDetailSeeder.php:104-105` — stop reading `auth()->id()`/`now()` inside the service; pass `$userId` and `$now` from the caller (or accept `null` explicitly). Effort: S.
- [x] **SAD-08** · L · STY-01 / STY-02 · `SubActivityDetailController.php`, `SubActivityDetail.php`, `SubActivityDetailSeeder.php` — add `declare(strict_types=1);` to all three and run `vendor/bin/pint <the three files> --format agent`. Effort: S.

## 9. Deferred / decisions
- The **canonical teacher source** is a SchoolSetup module question (SAD-05/§7). If option (a) is chosen, the `Teacher` model's mis-target is a cross-module note, not fixed here.
- **FormRequest extraction** (SAD-03) and any **god-controller split** are not splits — 249 lines, 5 methods, no split needed (D3).

---

### Approve
Tick `[x]` on the items to apply, fill every `➜ Choice:` above, then run `final-audit-fixer` on
`Modules/TimetableFoundation/app/Http/Controllers/SubActivityDetailController.php`. ⚠ Items marked **SHARED**
(tenant migration) need their own tick. `"tick all"` does **not** cover them.
