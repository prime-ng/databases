# Final Audit — TimetableFoundation / AcademicTermController

**Audited:** 2026-10-10 · **By:** claude · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/AcademicTermController.php` (431 lines, 13 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 4 HIGH.**

The write paths are mostly sound after today's pre-applied pass. But four things can go wrong for a real user:

- **Empty Settings box → error page.** Saving a term with the Settings box empty crashes the page. The column is NOT NULL, while the rule allows null.
- **Delete Permanently works on a live term.** It accepts a term that is not in the trash. It has no child check, and can silently blank the term link on 662 requirement rows.
- **"One current term" is not enforced by the database.** The code comments say it is. It is not, because the migration built `current_flag` as a plain column where the DDL defines a generated one.
- **Restore runs over a GET request.**

The worst of these is **ATC-03**, the force-delete on a live term.

The effort is about half a day. Eight DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 4 | 7 | 6 | 8 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | ATC-04 | F8 Services/Jobs | clean: no service, no job, no event (`grep -n "Service\|dispatch\|event(" $C` → none) |
| F2 Transactions/Audit | ATC-12 | F9 Queries/Perf | clean: trash paginates 10, list eager-loads `academicSession`, no `::all()` |
| F3 Authorization | ATC-06 (ungated method), ATC-14 | F10 Views | ATC-02 (textarea), ATC-17 |
| F4 Validation | ATC-02, ATC-10, ATC-11 | F11 Security/Tenancy | ATC-05; `origin` redirect is allow-listed (store:96) ✅ |
| F5 Routes | ATC-05, ATC-06 | F12 Style | ATC-15, ATC-16 |
| F6 Controller shape | ATC-13 | F13 Deep read | ATC-03, ATC-07, ATC-08, ATC-09 |
| F7 Models | ATC-01 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/AcademicTermController.php` | controller | 431 | this report | ✅ whole class |
| 2 | `app/Http/Requests/AcademicTermRequest.php` | FormRequest | 182 | this report | ✅ whole class |
| 3 | `app/Models/AcademicTerm.php` | model | 133 | **this report (claimed — 35 files reach it)** | ✅ |
| 4 | `app/Policies/AcademicTermPolicy.php` | policy | 47 | this report | ✅ — unreachable, see ATC-14 |
| 5 | `routes/web.php` lines 98-108 | routes | — | this report | ✅ |
| 6 | `views/pages/partials/timetable-configuration/academic-terms/_list.blade.php` | tab list | 159 | this report | ✅ |
| 7 | `views/pages/partials/timetable-configuration/academic-terms/_create-modal.blade.php` | create modal | 304 | this report | ✅ |
| 8 | `views/school-academic-term/edit.blade.php` | page | 379 | this report | ✅ |
| 9 | `views/school-academic-term/show.blade.php` | page | 198 | this report | ✅ |
| 10 | `views/school-academic-term/trash.blade.php` | page | 75 | this report | ✅ |
| 11 | `views/school-academic-term/create.blade.php` | page (legacy) | 361 | this report | ✅ — see ATC-17 |
| 12 | `views/school-academic-term/index.blade.php` | page | 160 | this report | ✅ — orphan, ATC-17 |
| — | `OrganizationAcademicSession` model | SchoolSetup class | — | common (other module) | relation only; §7 |
| — | `x-backend.table.action`, `action-trashed`, `status-switch`, `tab.modal`, `tab.search-bar`, `components.breadcrum` | shared components | — | common | props checked against constructors only |

**Pre-applied 2026-10-10:** this controller is listed in `../PRE-APPLIED-2026-10-10.md`. In that pass, `store`, `update`, `destroy` and `toggleCurrent` were changed to `return DB::transaction(fn …)`, and their try/catch was removed. This audit reviewed the result fresh. ATC-12 concerns the shape of that change.

## 4. Routes

```
GET|HEAD  timetable-foundation/academic-term                     academic-term.index        index
POST      timetable-foundation/academic-term                     academic-term.store        store
GET|HEAD  timetable-foundation/academic-term/create              academic-term.create       create
GET|HEAD  timetable-foundation/academic-term/trash/view          academic-term.trashed      trashed
GET|HEAD  timetable-foundation/academic-term/{academic_term}     academic-term.show         show
PUT|PATCH timetable-foundation/academic-term/{academic_term}     academic-term.update       update
DELETE    timetable-foundation/academic-term/{academic_term}     academic-term.destroy      destroy
GET|HEAD  timetable-foundation/academic-term/{academic_term}/edit academic-term.edit        edit
POST      timetable-foundation/academic-term/{academic_term}/toggle-status academic-term.toggleStatus toggleStatus
DELETE    timetable-foundation/academic-term/{id}/force-delete   academic-term.forceDelete  forceDelete
GET|HEAD  timetable-foundation/academic-term/{id}/restore        academic-term.restore      restore   ← GET
```

Middleware on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`.
**Unrouted public methods:** `toggleCurrent` (line 382) and `getSessionDates` (line 422). See ATC-06.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect to tab) | — |
| create | ✅ | create | — | — | — | ATC-17 |
| store | ✅ | create (+ request) | ✅ closure | `Stored` | sch_academic_term, sys_activity_logs | ATC-01, 02, 10, 12, 13 |
| show | ✅ | view | — | — | — | — |
| edit | ✅ | update | — | — | — | — |
| update | ✅ | update (+ request) | ✅ closure | `Updated` (with diff) | sch_academic_term, sys_activity_logs | ATC-01, 02, 10, 12, 13 |
| destroy | ✅ | delete | ✅ closure | `Trashed` | sch_academic_term, sys_activity_logs | ATC-09, 12 |
| trashed | ✅ | restore | — | — | — | — |
| restore | ✅ GET | restore | ✅ inside try | `Restored` | sch_academic_term, sys_activity_logs | ATC-04, 05, 07 |
| forceDelete | ✅ | forceDelete | ✅ inside try | `Deleted` | sch_academic_term (+ SET NULL children), sys_activity_logs | ATC-03, 04 |
| toggleStatus | ✅ | update | ✅ inside try | `Toggled` | sch_academic_term, sys_activity_logs | ATC-04, 08 |
| toggleCurrent | ❌ | update | ✅ closure | `Current Toggled` | — (unreachable) | ATC-06 |
| getSessionDates | ❌ | **none** | — | — | — (unreachable) | ATC-06 |

**Tables each mutation SHOULD touch:**
- **store and update** should write the term row plus the log. When the term is made current, they should also clear the previous current term. They do all three.
- **destroy and forceDelete** should also account for the 9 FK child tables listed in §6 (ATC-03 / ATC-09). They check none of them.

## 6. Findings

### F7 — Models
#### ATC-01 · H · MDL / DDL-drift — "one current term" is not enforced by the database; the comments say it is
**Where:** `database/migrations/tenant/2026_06_15_145405_create_sch_academic_term_table.php:34,40` · `AcademicTerm.php:46,49` · controller `:73-74`, `:166-167`, `:394-395`
```php
// migration                                  // DDL (Timetable_DDL_v7.8.sql:21,27)
$table->boolean('current_flag')->nullable();  `current_flag` tinyint(1) GENERATED ALWAYS AS
$table->unique('current_flag', …);              ((case when (`is_current`=1) then '1' else NULL end)) STORED,
                                              UNIQUE KEY `uq_AcademicTerm_currentFlag` (`current_flag`)
// controller comment: "DB-enforced via uq_AcademicTerm_currentFlag unique on (academic_session_id, current_flag)"
```
**Evidence:**
- `SHOW CREATE TABLE sch_academic_term` returns `current_flag tinyint(1) DEFAULT NULL`, a plain column that is not generated.
- Both live rows have `current_flag = NULL`, and nothing in the app writes it.
- The unique index is on `current_flag` alone.

So, as built:
- Nothing in the database prevents two current terms.
- The comment claiming the index is "on (academic_session_id, current_flag)" is false in all three places it appears.
- If the DDL is applied as written, its index allows only **one current term for the whole school**, while the app clears the current term only within the same session.

**Consequence:** today, only the controller's clear-then-set code prevents two current terms. A second write path (seeder, import, or a sibling controller) can create two, and every "current term" lookup then picks one arbitrarily. If the DDL is applied unchanged, making a term current in a second session throws a duplicate-key error.

### F4 — Validation
#### ATC-02 · H · VAL / DDL-drift — an empty Settings box crashes the save
**Where:** `AcademicTermRequest.php` (`'settings_json' => 'nullable|json'`) · `_create-modal.blade.php:198-199` · `edit.blade.php:220` · controller `:61`, `:154`
```php
if (isset($data['settings_json']) && is_string($data['settings_json']) && $data['settings_json'] !== '') { … }
// null is left in $data and goes straight into create()/update()
```
**Evidence:**
- `SHOW COLUMNS … settings_json` returns `Null=NO Default=NULL`.
- `sql_mode` includes `STRICT_TRANS_TABLES`.
- The rule is `nullable|json`.
- The DDL (line 22) declares `settings_json JSON`, which is nullable. The migration made it NOT NULL.
- The textarea defaults to `{}`, but a user can clear it. `ConvertEmptyStringsToNull` then turns it into null, which passes validation and hits SQL 1048.

**Consequence:** a user who clears the Settings box gets a 500 on both create and edit, and loses everything they typed.

#### ATC-10 · M · VAL — term dates are checked against session dates the client sends, not the real session
**Where:** `AcademicTermRequest.php:37-43`
```php
$sessionStartDate = $this->input('academic_year_start_date');
$sessionEndDate   = $this->input('academic_year_end_date');
```
**Evidence:**
- `academic_session_id` must exist, but its real `start_date` and `end_date` are never read.
- Live data shows the result. Both terms belong to session 7, which runs 2026-04-01 → 2027-03-31. Both carry `academic_year_*` dates of 2025-04-01 → 2026-03-31, and term dates in 2025-26.

**Consequence:** a school can save a term that lies entirely outside its own academic session. Timetable generation and term lookups then run on the wrong year. This has already happened on this tenant.

#### ATC-11 · M · BUG-003 (latent) — re-creating a trashed term's code crashes
**Where:** `AcademicTermRequest.php` (the `term_code` closure, which excludes trashed rows) vs live `UNIQUE uq_AcademicTerm_session_code (academic_session_id, term_code)`
**Evidence:**
- The validator queries the SoftDeletes model, so trashed rows are invisible to it.
- The index is a plain UNIQUE that does not account for soft deletes.
- There are 0 trashed rows today, so this is latent.

**Consequence:** if a user trashes TERM_1 and then creates TERM_1 again, validation passes and the insert raises 1062, which shows a 500.

### F13 — Deep read
#### ATC-03 · H · deep read — Delete Permanently works on a live term and checks no children
**Where:** controller `:297`
```php
$academicTerm = AcademicTerm::withTrashed()->findOrFail($id);   // a LIVE id is accepted
```
**Evidence:**
- `withTrashed()` matches live rows too, so a DELETE to `/academic-term/1/force-delete` skips the trash entirely.
- No child guard exists. FK children of `sch_academic_term`, measured:

| Table | ON DELETE | Rows |
|---|---|---|
| tt_activities | NO ACTION | 599 |
| tt_class_timetable_types_jnt | NO ACTION | 344 |
| tt_slot_requirements | NO ACTION | 43 |
| tt_constraints | RESTRICT | 6 |
| hpc_reports | NO ACTION | 2 |
| ptm_events | NO ACTION | 2 |
| **tt_requirement_consolidations** | **SET NULL** | **662** |
| ba_assessment_periods | SET NULL | 4 |
| tt_timetable_assignment | SET NULL | 0 |

**Consequence:**
- If a term has any NO ACTION child, the delete fails with error 1451, and the user sees the generic "Failed to permanently delete academic term."
- If a term has only SET NULL children, the delete **succeeds**. It silently blanks the term on every requirement-consolidation and assessment-period row, with no warning.

#### ATC-07 · M · deep read — a restored term stays inactive
**Where:** `destroy:211` sets `is_active=false`. `restore:255-258` only calls `restore()`.
**Consequence:** a restored term comes back switched off. It is invisible to `scopeActive()` and to every dropdown that lists active terms, until someone notices and toggles it.

#### ATC-08 · M · deep read — the current term can be deactivated
**Where:** `toggleStatus:344-350`. There is no `is_current` check.
**Consequence:** the school's current term can be switched off while it is still marked current. The result is `is_current=1, is_active=0`. Code that asks for "the current active term" then finds none.

#### ATC-09 · M · deep read — a term in use, or the current term, can be trashed
**Where:** `destroy:210-212`
**Consequence:**
- Trashing a term that 599 activities and 344 class-timetable-type rows still point at leaves those rows referring to a trashed term. SoftDeletes queries then treat that term as missing.
- Trashing the current term silently leaves the school with **no** current term (`is_current` is cleared as part of the destroy).

### F1 — Errors
#### ATC-04 · M · ERR-00 (D1) + ERR-05 — three methods still catch errors themselves and log only the message
**Where:** `restore:254-281` · `forceDelete:297-324` · `toggleStatus:346-377`
```php
} catch (\Throwable $e) {
    Log::error('Failed to restore academic term: '.$e->getMessage(), [...]);
```
**Evidence:** the pre-applied pass converted `store`, `update` and `destroy` to the D1 pattern. These three were left with try/catch, so the controller now uses two different error models.
**Consequence:** the stack trace is lost (ERR-05). A failure also produces a generic flash instead of the central handler's response. Note that for `toggleStatus` (AJAX), the central handler already returns `{success:false, message}` for JSON callers.

### F5 — Routes
#### ATC-05 · H · RTE-01 — Restore runs over a GET request
**Where:** `routes/web.php` — `Route::get('/academic-term/{id}/restore', …)`
**Evidence:** `route:list` shows `GET|HEAD …/{id}/restore`. The only caller is `trash.blade.php:49` via `<x-backend.table.action-trashed>`. That component derives the HTTP verb from the route, so changing the verb needs no blade edit.
**Consequence:** GET has no CSRF protection, so a link preview or prefetcher can restore a term.

#### ATC-06 · M · RTE-03 + AUTH-01 — two unrouted methods, one of them ungated
**Where:** `toggleCurrent:382` and `getSessionDates:422`
**Evidence:**
- `route:list` shows neither method.
- `getSessionDates` has no `Gate::authorize`.
- `toggleCurrent` flashes `current_status_updated.academic-term`, which resolves to `''` (an empty toast).
- `tests/Unit/ControllerAuthTest.php:108` lists `getSessionDates` as auth-exempt.
**Consequence:** both are dead today. If either is ever routed, `getSessionDates` leaks session dates to any authenticated user. Per D5, each body becomes `abort(403)` with a NOT ROUTED comment. ⚠ This may change what `ControllerAuthTest` expects; that is for the team to verify (D4).

### F2 — Transactions/Audit
#### ATC-12 · L · TXN-05 — the redirect and flash are built inside the transaction closure
**Where:** `store:100`, `update:197-199`, `destroy:219-221` (the pre-applied shape)
**Consequence:** the success flash is written to the session before the commit. If the commit itself fails, the next page shows a "created successfully" toast for a row that does not exist. Fix: the closure returns the model, and the redirect is built after the closure.

### F6 — Controller shape
#### ATC-13 · L · dead code — the max/min resting clamp can never fire
**Where:** `store:67-69`, `update:162-164`
**Evidence:** `AcademicTermRequest.php:119-124` already rejects the case with `gte:term_min_resting_periods_per_day`.

### F3 — Authorization
#### ATC-14 · L · AUTH-04 — every write is authorized twice, and the policy is never consulted
**Where:**
- The request's `authorize()` calls `authorizeByCrudPermission(...)`, and the controller's `Gate::authorize` checks the same permission again.
- `AcademicTermPolicy` is registered at `TimetableFoundationServiceProvider.php:122`, but every gate passes a permission STRING, so the policy is never consulted. It is dead code that looks active (module-wide pattern).

### F12 — Style
#### ATC-15 · L · copy — toast text reads "Academic-term"
**Evidence:** `flash('created.academic-term')` renders "Academic-term was created successfully." `flash()` replaces underscores, not hyphens. All 7 keys are affected.

#### ATC-16 · L · STY / CTL-04 / MDL-04 — style
- **Controller:** 13 methods have no return type, `strict_types` is not declared, and the false "(academic_session_id, current_flag)" comment appears at three sites.
- **Request:** `Rule` and `DB` are imported but unused, and `strict_types` is not declared.
- **Model:** `academicSession()` has no return type, and the comment "current_flag is a STORED generated column" is false (ATC-01).
- **Policy:** `strict_types` is not declared.

### F10 — Views
#### ATC-17 · L · views — orphan index blade and a leftover create page
**Evidence:**
- **index.blade.php:** `index()` redirects to the tab. `grep -rn "timetablefoundation::school-academic-term.index"` finds nothing; the only `school-academic-term.index` reference is `smarttimetable::`, a different module's view. So `school-academic-term/index.blade.php` (160 lines) is an orphan.
- **create page:** the create UI is now the modal (`_create-modal.blade.php`, converted 2026-09-09), but the `create` route and the 361-line `create.blade.php` page are still reachable by URL. That means two create forms that can drift apart.
- **show.blade.php:18:** links to `timetable.validation`, which does not exist. The link is guarded by `Route::has`, so it never renders.

**Clean checks (one line each):**
- Every `route()` used in the in-scope blades exists. The only exception, `timetable.validation`, is guarded.
- Permission props on `action`, `status-switch`, `action-trashed` and `search-bar` use 4-part names. All 7 crud names are seeded.
- No `{!! !!}` on user data.
- No `{{-- --}}` inside `@php`.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`OrganizationAcademicSession` (SchoolSetup):** `academicSession` resolves ("Session - 2026-27"). It is the source the date check in ATC-10 should read, but the class itself is not audited here.
- **Unreachable policies (module-wide):** every policy in the module is unreachable because gates pass strings. This is the same pattern as the HrStaff finding in §2.0.4 #11 and needs a module-level decision.
- **`ControllerAuthTest`:** the ATC-06 change will interact with its auth-exempt list. It belongs to the team (D4).

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static or a read-only SQL probe.
- **Other writers of `sch_academic_term`:** seeders, importers, and the dashboard session-board were not audited. ATC-01's risk comes from them.
- **Data repair of the two live terms dated 2025-26 (ATC-10):** reported only. Changing data is out of scope.
