# Fix Plan — TimetableFoundation / AcademicTermController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/AcademicTermController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
_None._

## 2. Fixes that arm a latent defect (sequenced)
- [x] **ATC-03** · H · deep read · `AcademicTermController.php:297` — `forceDelete()`:
  - Use `onlyTrashed()->findOrFail()` so a live term can no longer be purged.
  - Before deleting, count children across the 9 FK tables. If any exist, refuse with a `\DomainException` that names each blocking table and its count.

  Order matters: this goes **before** ATC-09/ATC-07. Effort: S.

## 3. Errors & transactions (F1/F2)
- [x] **ATC-04** · M · ERR-00 / ERR-05 · `AcademicTermController.php:254-281, 297-324, 346-377` — remove the try/catch from `restore`, `forceDelete` and `toggleStatus`:
  - **Shape:** use `return DB::transaction(fn …)`, the same shape as store/update/destroy.
  - **Errors:** let the central handler render them (JSON for the AJAX toggle). If ATC-03 adds a `\DomainException`, it is caught **only** as `DomainException` and turned into a flash.

  Effort: S.
- [x] **ATC-12** · L · TXN-05 · `AcademicTermController.php:52-101, 142-200, 210-222` — each closure returns the model; build the redirect and flash after the transaction. This reshapes the pre-applied 2026-10-10 change. Effort: S.

## 4. Authorization (F3)
- [x] **ATC-06** · M · RTE-03 / AUTH-01 · `AcademicTermController.php:382, 422` — per D5:
  - Replace the bodies of `toggleCurrent()` and `getSessionDates()` with `abort(403)`, under a `// NOT ROUTED` comment. Both methods are kept, not deleted.
  - ⚠ `tests/Unit/ControllerAuthTest.php:108` lists `getSessionDates` as exempt. The test is not edited (D4); the team verifies it.

  Effort: S.
- [x] **ATC-14** · L · AUTH-04 · `AcademicTermController.php:50, 140` — drop the duplicate `Gate::authorize` in `store`/`update`, and keep the FormRequest `authorize()` (it runs first). The unreachable-policy question is module-wide, so it is not fixed here. Effort: S.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **ATC-02** · H · DECISION · VAL/DDL — the Settings box can be submitted empty, but the column is NOT NULL (the DDL says nullable).
      (a) ⭐ Both: a new additive migration making `settings_json` nullable (matching the DDL), **and** the controller coalesces an empty value to `[]` so a blank box never stores NULL.
      (b) App only: coalesce to `[]` in the controller. The column stays NOT NULL, and the DDL drift stays open.
      (c) Migration only.
      ➜ Choice: (a) migration makes settings_json nullable + controller stores [] for a blank box — Tarun 2026-10-12
- [x] **ATC-01** · H · DECISION · MDL/DDL — `current_flag` is a plain column, but the DDL defines it as GENERATED with a school-wide UNIQUE.
      (a) ⭐ Match the DDL:
          - A new additive migration rebuilds `current_flag` as the DDL's generated column, keeping UNIQUE on it (one current term for the whole school).
          - The controller clears `is_current` across **all** sessions, not just the same one.
          - The three false comments are corrected.
          - ⚠ Pre-check: the migration fails if two rows are current today. Live data has exactly 1 current row.
      (b) Generated column, with the unique on `(academic_session_id, current_flag)` (one current term per session). This **departs from the DDL**, so the DDL must be changed by you first (§1.4.1).
      (c) No schema change: correct the comments only, and keep relying on the controller's clear-then-set.
      ➜ Choice: (a) match the DDL: generated current_flag, school-wide UNIQUE; controller clears is_current across all sessions — Tarun 2026-10-12
- [x] **ATC-05** · H · DECISION · RTE-01 · `routes/web.php` (restore route) — Restore runs over GET.
      (a) ⭐ Change it to `Route::patch`. The component `action-trashed` derives the verb from the route, so no blade edit is needed. The only caller is `trash.blade.php:49`. ⚠ This changes a route, so it needs explicit approval.
      (b) Leave it as GET and accept the risk.
      ➜ Choice: (a) restore becomes PATCH — Tarun 2026-10-12
- [x] **ATC-11** · M · DECISION · BUG-003 · `AcademicTermRequest.php` (the `term_code` closure) — re-creating a trashed term's code crashes.
      (a) ⭐ The validator also checks trashed rows, with the message "A trashed term already uses this code — restore it instead." No migration.
      (b) A migration adds a generated `term_code_live` column, with a soft-delete-aware unique index.
      ➜ Choice: (a) validator checks trashed rows: "A trashed term already uses this code — restore it instead." — Tarun 2026-10-12
- [x] **ATC-10** · M · VAL · `AcademicTermRequest.php:37-43` — read `start_date` and `end_date` from the selected `sch_org_academic_sessions_jnt` row and validate against those, instead of trusting `academic_year_start_date` / `academic_year_end_date` from the form. The two live terms that already sit outside their session are **not** repaired (a data change, reported only). Effort: S.

## 6. Queries & performance (F9)
_None._

## 7. Behaviour decisions (F13)
- [x] **ATC-07** · M · DECISION · `AcademicTermController.php:255-258` — Restore leaves the term inactive.
      (a) ⭐ `restore()` sets `is_active = true` (the inverse of what destroy sets).
      (b) Leave it as is; an admin re-activates by hand.
      ➜ Choice: (a) restore sets is_active = true — Tarun 2026-10-12
- [x] **ATC-08** · M · DECISION · `AcademicTermController.php:344-350` — the current term can be switched off.
      (a) ⭐ Refuse to deactivate the current term, with the message "Make another term current first." (`DomainException` → JSON `success:false`).
      (b) Deactivating also clears `is_current`, leaving the school with no current term.
      (c) Leave it as is.
      ➜ Choice: (a) refuse: "Make another term current first." — Tarun 2026-10-12
- [x] **ATC-09** · M · DECISION · `AcademicTermController.php:210-212` — a term in use, or the current term, can be trashed.
      (a) ⭐ Refuse to trash the **current** term only; trashing a non-current term with children stays allowed (it is reversible).
      (b) Also refuse when any FK children exist, using the same counts as ATC-03.
      (c) Leave it as is.
      ➜ Choice: (b) refuse the current term AND any term with FK children — Tarun 2026-10-12

## 8. Style (F12) — one item per file
- [x] **ATC-13** · L · dead code · `AcademicTermController.php:67-69, 162-164` — remove the unreachable max/min resting clamp; the `gte` rule already enforces it. Effort: S.
- [x] **ATC-15** · L · copy · `AcademicTermController.php` (7 `flash()` calls) — change `.academic-term` to `.academic_term` so toasts read "Academic Term …". Effort: S.
- [x] **ATC-16a** · L · STY · `AcademicTermController.php` — return types on all 13 methods, `declare(strict_types=1)`, and correct the three "(academic_session_id, current_flag)" comments. Effort: S.
- [x] **ATC-16b** · L · STY · `AcademicTermRequest.php` — drop the unused `Rule` and `DB` imports, and add `declare(strict_types=1)`. Effort: S.
- [x] **ATC-16c** · L · STY / MDL-04 · `AcademicTerm.php` — add `: BelongsTo` on `academicSession()`, `declare(strict_types=1)`, and correct the "STORED generated column" comment to match ATC-01's outcome. ⚠ SHARED — 35 files reach this model; the change is comment and type-hint only. Effort: S.
- [x] **ATC-16d** · L · STY · `AcademicTermPolicy.php` — add `declare(strict_types=1)`. Effort: S.

## 9. Views (F10)
- [x] **ATC-17a** · L · orphan · `views/school-academic-term/index.blade.php` — delete it. Before deleting, re-prove `routed=0 refs=0` for the `timetablefoundation::` namespace at fix time. Effort: S.
- [x] **ATC-17b** · L · DECISION · the `create` route and `create.blade.php` page still exist beside the create modal.
      (a) ⭐ Make the `create()` body `abort(403)` with a NOT ROUTED-style comment, and leave the blade in place (D5 spirit). ⚠ This changes what the route does, so it needs approval.
      (b) Leave both create surfaces.
      ➜ Choice: (a) create() becomes abort(403); create.blade.php kept — Tarun 2026-10-12
