# Status — TimetableFoundation / AcademicTermController

**Fixed:** 2026-10-12 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work

From `../PRE-APPLIED-2026-10-10.md:26`:

| Controller | Pre-applied 2026-10-10 |
|---|---|
| `AcademicTermController` | `store` / `update` / `destroy` / `toggleCurrent` → `return DB::transaction(fn …)`; try/catch and manual rollBack removed (ERR-00). Pint applied |

⚠ **The code found on 2026-10-12 did NOT match this row.** `store`, `update` and `destroy` were back on
`DB::beginTransaction()` / `try` / `rollBack()`, so the 2026-10-10 change had been reverted (or overwritten)
before this fix pass. It was re-applied here as part of ATC-04 / ATC-12, in the shape the plan asks for
(closure returns nothing the redirect needs; redirect + flash built after the transaction).

## 2. Applied

All 21 plan items were ticked. Decisions recorded in `02-fix-plan.md` on each `➜ Choice:` line.

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| ATC-01 | `database/migrations/tenant/2026_10_12_000001_alter_sch_academic_term_current_flag_settings_json.php` (new) · `AcademicTermController.php:91-99, 164-175` | New additive migration rebuilds `current_flag` as `GENERATED … STORED` with the UNIQUE key, refusing to run while two rows are current. `store`/`update` clear `is_current` across **all** sessions (the unique is school-wide) | SQL proven on a TEMPORARY copy of the table | generated values correct; 2nd current row → 1062; switch after clearing works; temp table dropped | 2026-10-12 |
| ATC-02 | same migration · `AcademicTermController.php:410-423` (`normalise`) | `settings_json` → `JSON NULL`; a blank or non-array Settings box is stored as `[]` | NULL insert on the temp copy | accepted | 2026-10-12 |
| ATC-03 | `AcademicTermController.php:46-57, 429-451` | `CHILD_TABLES` (9 tables) + `refuseIfInUse()`; `forceDelete` refuses a term still referenced | rolled-back probe on term 1 | `Term "First Term" cannot be moved to trash: it is still used by 614 activities, 671 requirement consolidations, 172 class timetable types, 43 slot requirements, 6 constraints, 4 behavioural assessment periods, 1 HPC reports, 2 PTM events.` | 2026-10-12 |
| ATC-04 | `AcademicTermController.php` (whole class) | try/catch removed from `restore` / `forceDelete` / `toggleStatus` (and `store`/`update`); only `DomainException` is caught, per D2 | `grep -c 'catch (' …` | 3 — all `DomainException` (destroy, forceDelete, toggleStatus) | 2026-10-12 |
| ATC-05 | `Modules/TimetableFoundation/routes/web.php:99-102` | restore route GET → PATCH; the trash page's `action-trashed` reads the verb from the route, no blade edit | uncached `route:list` + trash render | `PATCH timetable-foundation.academic-term.restore`; trash page carries `value="PATCH"` ×1 | 2026-10-12 |
| ATC-06 | `AcademicTermController.php:384-397` | `toggleCurrent()` and `getSessionDates()` bodies → `abort(403)` with NOT ROUTED comments (D5) | `grep -n "abort(403" …` | lines 78, 386, 396 | 2026-10-12 |
| ATC-07 | `AcademicTermController.php:269-279` | restore sets `is_active = true` before `restore()` — one write | read | — | 2026-10-12 |
| ATC-08 | `AcademicTermController.php:345-370` | deactivating the current term throws `DomainException('Make another term current first.')`; the JSON returns `success:false` + the real `is_active` so the shared switch reverts | rolled-back probe | `{"success":false,"is_active":true,"message":"Make another term current first."}` | 2026-10-12 |
| ATC-09 | `AcademicTermController.php:214-235` | `destroy` refuses the current term, then any term with FK children (same counts as ATC-03); refusal is a flash error | rolled-back probe | `This is the current term. Make another term current first.` · row still exists | 2026-10-12 |
| ATC-10 | `AcademicTermRequest.php:145-165` | `prepareForValidation()` replaces the posted `academic_year_*` dates with the selected session's own dates | probe posting `1900-01-01` | merged `2026-04-01 .. 2027-03-31` | 2026-10-12 |
| ATC-11 | `AcademicTermRequest.php:68-88` | `term_code` closure checks `withTrashed()` and says so | rolled-back probe | trashed → `A trashed term already uses this code — restore it instead.` · live → `Term code already exists for this academic session.` · free → passes | 2026-10-12 |
| ATC-12 | `AcademicTermController.php:87-121, 160-198` | closures do the writes only; redirect + flash built after the transaction | read | — | 2026-10-12 |
| ATC-13 | `AcademicTermController.php` | unreachable resting min/max clamp removed (`gte` rule already enforces it) | `grep -c resting …Controller.php` | 0 | 2026-10-12 |
| ATC-14 | `AcademicTermController.php:87, 160` | duplicate `Gate::authorize` dropped in `store`/`update`; the FormRequest `authorize()` (runs first) keeps the same create/update permission | `grep -n "Gate::authorize" …` | none in store/update | 2026-10-12 |
| ATC-15 | `AcademicTermController.php:121, 198, 237, 284, 322, 375` | `.academic-term` → `.academic_term`. The plan counted 7; the 7th lived in `toggleCurrent()`, now `abort(403)` under ATC-06 | `grep -o "academic_term')" … \| wc -l` | 6 — all remaining `flash()` calls | 2026-10-12 |
| ATC-16a | `AcademicTermController.php` | `declare(strict_types=1)`, return types on every method, `current_flag` comments corrected | `php -l`, `class_exists` | ok | 2026-10-12 |
| ATC-16b | `AcademicTermRequest.php` | `strict_types`; unused `Rule`/`DB` imports dropped | `php -l` | ok | 2026-10-12 |
| ATC-16c ⚠ SHARED | `Modules/TimetableFoundation/app/Models/AcademicTerm.php:8, 52-64` | `: BelongsTo` on `academicSession()`, `strict_types`, `current_flag` comment rewritten. Type-hint and comment only — no behaviour change for the 35 callers | `php -l`, `class_exists` | ok | 2026-10-12 |
| ATC-16d | `AcademicTermPolicy.php` | `strict_types` | `php -l` | ok | 2026-10-12 |
| ATC-17a | `views/school-academic-term/index.blade.php` | deleted (`git rm`) after re-proving `routed=0 refs=0` at fix time | `ls`, grep for the view name | gone; 0 references | 2026-10-12 |
| ATC-17b | `AcademicTermController.php:76-79` | `create()` → `abort(403, '…created from the dialog…')`; `create.blade.php` kept | `grep -n "abort(403" …` | line 78 | 2026-10-12 |

⚠ **ATC-16c touches a ⚠ SHARED model and was applied under the plan tick without a separate
explicit go.** The change is a return-type hint and a comment; nothing any of the 35 callers can
observe changes. Recorded here so that is a known decision, not a silent one.

## 3. Not applied

| ID | Reason | Detail |
|---|---|---|
| — | — | Every ticked item was applied |
| (data) | out of scope | The two live terms whose dates sit outside session 7's range were **not** repaired (plan ATC-10 note — a data change, reported only) |

## 4. Needs Tarun's hand

1. **Run the migration:** `php artisan tenants:migrate`. It refuses with a readable message if more
   than one row has `is_current = 1` (today: exactly one).
2. **Browser check** of the Timetable Configuration → Academic Terms tab: create (blank Settings box),
   edit, the status switch on the current term (should refuse and flip back), trash a term that is in
   use (should refuse), and restore from the trash page (PATCH).

## 5. Unverifiable by this workflow (no tests, D4)

- The `uq_AcademicTerm_currentFlag` behaviour on the **real** table — proven on a temporary copy only;
  the migration has not been run.
- `update()` can still save `is_active = 0` on the current term through the edit form; ATC-08 guards
  the list toggle only. Not in the plan — a residual to decide.
- `Modules/TimetableFoundation/tests/Unit/ControllerAuthTest.php:108` lists `getSessionDates` as an
  exemption; not edited (D4).
- Cross-cutting (not this controller): `Modules/SmartTimetable/resources/views/index.blade.php:18`
  includes `smarttimetable::school-academic-term.index`, which does not exist.

## 6. Verification log
```
php -l  AcademicTermController.php / AcademicTermRequest.php / AcademicTerm.php / AcademicTermPolicy.php / new migration   → No syntax errors
class_exists (all four classes)                                                                                              → true
APP_ROUTES_CACHE=<missing> route:list → 11 academic-term routes, method_exists ok on all 11; restore = PATCH
Blade compile (php -l on compiled output):
  school-academic-term/{trash,edit,create,show} · pages/timetable-configuration · academic-terms/{_create-modal,_list}  → ok
  (_list declares 1 '@push(' inside a Blade comment and emits 0 — correct, the comment is stripped)
Render (bound real routes, tenant test.localhost, root user):
  timetable-configuration?tab=academic-terms  342,746 bytes · 0 comment leaks · modal date inputs present
  show 179,096 bytes · edit 193,599 bytes · trash 174,443 bytes (PATCH form present)
Functional probes (inside DB::beginTransaction / rollBack): see §2 ATC-03, 08, 09, 10, 11
Tenant row count before / after probes: sch_academic_term = 2 / 2
vendor/bin/pint <touched files> --format agent → applied; php -l + class_exists re-run after Pint → ok
```

## 7. Final state
Status: FIXED · Open (plan items): B 0 · H 0 · M 0 · L 0 · Residual: 1 (update() can deactivate the current term) — pending Tarun's decision. Migration pending `tenants:migrate`.
