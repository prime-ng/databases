# 03 — Status · TimetableFoundation / TeacherAssignmentRoleController

**Fixed:** 2026-10-14 · **By:** opencode / claude (fix) · **Plan:** `02-fix-plan.md` (all 18 items ticked)

## 1. Pre-applied 2026-10-10

None. `PRE-APPLIED-2026-10-10.md` has no entry for this controller or its classes.

## 2. Applied

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| TAR-13 | `TeacherAssignmentRoleController.php` `forceDelete()` | `withTrashed()` → `onlyTrashed()`. A child pre-check via `assertNotInUse(…, true)` counts trashed child rows too, because they still hold the FK. It throws `\DomainException`, which is caught only as `DomainException` and returned as a flash. The `QueryException` catch is removed. | replay: force-delete a live role; force-delete a trashed role that has a trashed child | live role → **404**; trashed role with a child → refused with "…0 activity teacher(s) and 1 timetable cell(s)…" |
| TAR-04 | `edit.blade.php:74` | `@disabled(!$countsForWorkload)` → `@readonly(...)`. Header comment updated. | replay: edit a role whose counts_for_workload is false | the input renders `readonly`; update returns 302 with factor stored as 0.00 |
| TAR-01 | controller, all 6 mutations | Every try/catch removed and every `Log::error` dropped. Writes stay inside `DB::transaction`. The only catches left are `DomainException` in `destroy`/`forceDelete` (D2). | `grep -c 'try {'` / `grep -c 'catch (DomainException'` | 2 / 2 (both are DomainException only) |
| TAR-02 | controller `store`/`update` | Duplicate `Gate::authorize` removed. `TeacherAssignmentRoleRequest::authorize()` checks create/update first (`authorizeByCrudPermission`). | replay: store / update | 302 success |
| TAR-03 | controller `index()` | Gate is now `tenant.timetable-foundation.config.viewAny`, the same as the destination `timetableMasters()`. | replay: index | 302 → `/timetable-masters?tab=teacher-roles` |
| TAR-05 / TAR-08 | controller `resolveAttributes()` | One private helper handles the 4 boolean flags and the 2 business rules for both store and update. | replay: update with counts_for_workload absent | factor = 0.00 |
| TAR-06 | `routes/web.php` (restore) | `Route::get` → `Route::patch`. `action-trashed` reads the verb from the route, so no blade edit was needed. | replay: trash page; GET restore; PATCH restore | trash form carries `value="PATCH"`; GET → **405**; PATCH → 302, row restored and active |
| TAR-07 | `routes/web.php` + controller + request | `->parameters(['teacher-assignment-role' => 'teacherAssignmentRole'])`. show/edit/update/destroy are now type-hinted. **The request's unique rule now reads `$this->route('teacherAssignmentRole')?->getKey()`.** The old `teacher_assignment_role` name would return null and reject every update against its own code. | route probe: params vs signature; replay: update keeping the same code | params match on all 10 routes; update with the role's own code → 302 success |
| TAR-09 | controller, all public methods | Return types added (`RedirectResponse`/`View`/`JsonResponse`/`never`). | `php -l` + `class_exists` | OK |
| TAR-10 | `TeacherAssignmentRole.php:137,148` | `: HasMany` on `activityTeachers()` / `timetableCellTeachers()`. | `grep -n "): HasMany"` | 2 hits |
| TAR-11 | `teacher-assignment-role/create.blade.php` | **Deleted.** Re-proved at fix time: route excluded (`route:list` count 0) and 0 `view()` refs. Comments in `_create-fields` / `_create-modal` now say it was deleted. | `ls views/teacher-assignment-role` | `_create-fields _create-modal edit show trash` |
| TAR-12a | controller | `strict_types`. The forceDelete docblock now says `ON DELETE NO ACTION` (it said RESTRICT). | `head -3` | OK |
| TAR-12b | request | `strict_types` | — | OK |
| TAR-12c | model | `strict_types` | — | OK |
| TAR-12d | policy | `strict_types` | — | OK |
| TAR-14 | controller `destroy()` | `assertNotInUse(…, false)` counts **live** child rows and throws `DomainException`, shown as a flash. | replay: trash a role while an activity_teachers row points at it | refused: "…still used by 1 activity teacher(s) and 0 timetable cell(s)…"; row not trashed |
| TAR-15 | request + controller | `is_system` removed from the rules. `store()` forces `false`. `update()` leaves the stored value alone. | replay: store with `is_system=1` posted | stored `is_system=false` |

**Beyond plan:**
- The "Is System Role" checkbox was removed from `_create-fields.blade.php` and `edit.blade.php`. Once TAR-15 stopped accepting the field, keeping it on the forms would mislead users. Replay: the edit page shows 0 `name="is_system"` inputs.
- `toggleStatus()` now reads `$request->boolean('is_active')` instead of `(bool) $request->input(...)`. Same result.
- The child checks count trashed rows only for force-delete, because `ActivityTeacher` and `TimetableCellTeacher` use SoftDeletes: a trashed child still holds the FK, but trashing the role does not break it.

## 3. Not applied

None — all 18 items were ticked and applied.

## 4. Needs Tarun's hand

- **One Dusk test will change result:** `tests/Browser/Modules/V2/TimetableFoundation/ResourceAvailability/TtTeacherAssignmentRoleTest.php:891` opens `/teacher-assignment-role/999999999/restore` with a GET and expects a 404. It now gets **405** (method not allowed), because restore is PATCH (TAR-06).
- **One basic-suite test will fail:** `tests/Browser/Modules/V2/TimetableFoundation/TimetableMasters/TtTeacherAssignmentRoleBasicTest.php:862` asserts the create dialog has an `is_system` input. That input was removed (TAR-15). `test_06` still passes, because `store()` now always saves `is_system = false`.
- Tests that are not affected: basic `test_11` (restore) clicks the trash-page button. `action-trashed` builds that form's verb from the route, so it now sends PATCH. `TtTeacherAssignmentRoleTest::test_35` already uses the dialog instead of the create page.
- I did not edit or run any test (D4). Updating the two lines above needs your go.
- **Cross-cutting, outside this controller (not fixed).** `Modules/SmartTimetable/resources/views/smart-timetable/partials/teacher-assignment-role/_list.blade.php:42` calls `route('timetable-foundation.teacher-assignment-role.create')` with no `Route::has()` guard. The `create` route has been excluded since 2026-09-10. That partial is `@include`d by `smart-timetable/index.blade.php:46` and `master.blade.php:55`, so those pages hit a `RouteNotFoundException` when they render. This was already true before today; it needs its own decision (guard the link or remove it).
- `tenant.timetable-foundation.teacher-assignment-role.status` is **not seeded**. Nothing in this controller gates on it, so it is not needed today. Noted only because the toggle uses `.update`.

## 5. Unverifiable by this workflow (D4)

- TAR-14 and TAR-13 only apply to roles users create. On this tenant all 5 roles are system roles, and the system-role guard blocks them first. The in-use guards were proven in the replay on a throwaway role; with real data they will be latent until someone creates a role and assigns teachers to it.
- TAR-02/TAR-03: the replay ran as Super Admin (`Gate::before`), so the permission gates were not exercised. Exercising them needs a role that holds `config.viewAny` without `teacher-assignment-role.viewAny` (or the reverse).

## 6. Verification log

```
php -l   controller / request / model / policy / routes/web.php          → No syntax errors (before and after Pint)
pint     request: fully_qualified_strict_types, ordered_imports; model: no_unused_imports
class_exists  TeacherAssignmentRoleController / Request / Model / Policy → OK x4
route probe (APP_ROUTES_CACHE=/tmp/fa-nocache.php): 10 routes, every method exists, params == signature
   PATCH {id}/restore · DELETE {id}/force-delete · {teacherAssignmentRole} on show/edit/update/destroy/toggle-status
blade compile + php -l: _create-fields, _create-modal, edit, show, trash → ok; @push declared/emitted 0/0
kernel replay (tenant test.localhost, user 1, DB::beginTransaction … rollBack):
   index 302 → timetable-masters?tab=teacher-roles
   store 302, is_system=false (posted 1) · edit 200 (0 is_system inputs) · show 200
   edit(no workload) 200 READONLY · update(self code) 302, factor 0.00
   update system role 302 ERR "…it is a system role." (unchanged)
   toggle 200 success · toggle system 403
   destroy(in use) refused · destroy 302 trashed
   trash 200 PATCH form · restore GET 405 · restore PATCH 302 active
   forceDelete(live) 404 · forceDelete(trashed child) refused · forceDelete 302 gone
   activity log: Stored,Updated,Toggled,Trashed,Restored,Trashed,Deleted
   masters tab 200
   rolled back; roles = 5
```

## 7. Final state

**FIXED.** All 18 plan items applied. Open: 0 items in this controller. One cross-cutting item (the SmartTimetable partial's unguarded `create` route link) is recorded in §4 and is owned elsewhere.
