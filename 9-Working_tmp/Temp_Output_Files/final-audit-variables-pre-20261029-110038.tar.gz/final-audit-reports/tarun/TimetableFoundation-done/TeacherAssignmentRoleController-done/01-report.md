# Final Audit — TimetableFoundation / TeacherAssignmentRoleController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/TeacherAssignmentRoleController.php` (622 lines, 11 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 3 HIGH.** The write paths are transactional and correctly
audited, authorization is present on every routed method, and the soft-delete × unique-index
design is right. Three things can go wrong for a real user:

- **Delete Permanently accepts a live role** (`withTrashed()` matches untrashed ids), so a crafted
  `DELETE …/{id}/force-delete` permanently destroys a row that never went to the trash. This is
  the worst finding (**TAR-13**).
- **The edit form cannot be saved for a role that does not count for workload** — the
  `workload_factor` input is `@disabled`, so it is not submitted, and the FormRequest still
  requires it (**TAR-04**).
- **Restore runs over GET** (**TAR-06**), which has no CSRF protection.

The controller was **not** part of the pre-applied 2026-10-10 pass, so all six of its original
`try/catch` blocks remain — the house has otherwise moved to the Laravel idiom (D1, **TAR-01**).

Rough effort: about one day. Four DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 3 | 6 | 6 | 4 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TAR-01 | F8 Services/Jobs | clean: no service, no job, no event (`grep -n "Service\|dispatch\|event(" $C` → none) |
| F2 Transactions/Audit | clean: all 6 mutations use `DB::transaction`, `activityLog` inside after the write | F9 Queries/Perf | clean: trash paginates 10; list partial eager-loaded by `TimetableFoundationController` |
| F3 Authorization | TAR-02, TAR-03 | F10 Views | TAR-11 |
| F4 Validation | TAR-04, TAR-05 | F11 Security/Tenancy | clean: no `env()`, no hard-coded ids, permissions seeded (8/8) |
| F5 Routes | TAR-06, TAR-07 | F12 Style | TAR-12 |
| F6 Controller shape | TAR-08, TAR-09 | F13 Deep read | TAR-13, TAR-14, TAR-15 |
| F7 Models | TAR-10 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TimetableFoundation/app/Http/Controllers/TeacherAssignmentRoleController.php` | controller | 622 | this report | ✅ whole class |
| 2 | `Modules/TimetableFoundation/app/Http/Requests/TeacherAssignmentRoleRequest.php` | FormRequest | 163 | this report | ✅ whole class |
| 3 | `Modules/TimetableFoundation/app/Models/TeacherAssignmentRole.php` | model | 152 | **this report (pre-assigned — 43 files reach it)** | ✅ |
| 4 | `Modules/TimetableFoundation/app/Policies/TeacherAssignmentRolePolicy.php` | policy | 44 | this report | ✅ — unreachable, see TAR-02 |
| 5 | `Modules/TimetableFoundation/routes/web.php` lines 253-259 | routes | — | this report | ✅ |
| 6 | `Modules/TimetableFoundation/resources/views/teacher-assignment-role/edit.blade.php` | page | 148 | this report | ✅ |
| 7 | `Modules/TimetableFoundation/resources/views/teacher-assignment-role/show.blade.php` | page | 88 | this report | ✅ |
| 8 | `Modules/TimetableFoundation/resources/views/teacher-assignment-role/trash.blade.php` | page | 131 | this report | ✅ |
| 9 | `Modules/TimetableFoundation/resources/views/teacher-assignment-role/create.blade.php` | page (orphan) | 137 | this report | ✅ — see TAR-11 |
| 10 | `Modules/TimetableFoundation/resources/views/teacher-assignment-role/_create-modal.blade.php` | create dialog | 22 | this report | ✅ |
| 11 | `Modules/TimetableFoundation/resources/views/teacher-assignment-role/_create-fields.blade.php` | dialog fields | 119 | this report | ✅ |
| 12 | `Modules/TimetableFoundation/resources/views/pages/partials/timetable-masters/teacher-roles/_list.blade.php` | tab list | 262 | this report (de-facto list UI) | ✅ — rendered by `TimetableFoundationController::timetableMasters` |
| — | `app/Traits/AuthorizesTenantFeature.php`, `activityLog()` / `flash()` helpers, `x-backend.table.action`, `action-trashed`, `status-switch`, `tab.modal`, `tab.search-bar`, `components.breadcrum`, `x-tenantcore::export-buttons`, layout | common | — | common (§4.2) | props checked against constructors only |

**Pre-applied 2026-10-10:** this controller is **not** listed in `../PRE-APPLIED-2026-10-10.md`
(`grep -n "TeacherAssignmentRole" ../PRE-APPLIED-2026-10-10.md` → not found). No pre-applied row applies.

## 4. Routes

UNCACHED probe: `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` filtered for
`TeacherAssignmentRoleController@`.

```
GET|HEAD  timetable-foundation/teacher-assignment-role                       timetable-foundation.teacher-assignment-role.index      index
POST      timetable-foundation/teacher-assignment-role                       timetable-foundation.teacher-assignment-role.store      store
GET|HEAD  timetable-foundation/teacher-assignment-role/trash/view            timetable-foundation.teacher-assignment-role.trashed    trashedTeacherAssignmentRole
DELETE    timetable-foundation/teacher-assignment-role/{id}/force-delete     timetable-foundation.teacher-assignment-role.forceDelete forceDelete
GET|HEAD  timetable-foundation/teacher-assignment-role/{id}/restore          timetable-foundation.teacher-assignment-role.restore    restore   ← GET
POST      timetable-foundation/teacher-assignment-role/{teacherAssignmentRole}/toggle-status timetable-foundation.teacher-assignment-role.toggleStatus toggleStatus
GET|HEAD  timetable-foundation/teacher-assignment-role/{teacher_assignment_role} timetable-foundation.teacher-assignment-role.show    show
PUT|PATCH timetable-foundation/teacher-assignment-role/{teacher_assignment_role} timetable-foundation.teacher-assignment-role.update  update
DELETE    timetable-foundation/teacher-assignment-role/{teacher_assignment_role} timetable-foundation.teacher-assignment-role.destroy destroy
GET|HEAD  timetable-foundation/teacher-assignment-role/{teacher_assignment_role}/edit timetable-foundation.teacher-assignment-role.edit edit
```

Middleware on every route (module `RouteServiceProvider.php:45-53`): `web, InitializeTenancyByDomain,
PreventAccessFromCentralDomains, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation,
auth, verified`.

**Unrouted public methods:** `create` (line 64). It is already D5-compliant — the body is
`abort(403, '…')` under a `// NOT ROUTED` comment (lines 66-71), and `Route::resource(...)->except(['create'])`
(line 254) keeps the route absent. Not a finding.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | `.viewAny` | — | — | — (redirect) | TAR-03 |
| create | ❌ (D5) | none (body `abort(403)`) | — | — | — | — |
| store | ✅ | `.create` (+ request `.create`) | ✅ closure | `Stored` | tt_teacher_assignment_roles, sys_activity_logs | TAR-01, 02, 05, 08 |
| show | ✅ | `.view` | — | — | — | TAR-07 |
| edit | ✅ | `.update` | — | — | — | TAR-07 |
| update | ✅ | `.update` (+ request `.update`) | ✅ closure | `Updated` | tt_teacher_assignment_roles, sys_activity_logs | TAR-01, 02, 05, 07, 08 |
| destroy | ✅ | `.delete` | ✅ closure | `Trashed` | tt_teacher_assignment_roles, sys_activity_logs | TAR-01, 07, 14, 15 |
| trashedTeacherAssignmentRole | ✅ | `.restore` | — | — | — (read) | — |
| forceDelete | ✅ | `.forceDelete` | ✅ closure | `Deleted` | tt_teacher_assignment_roles, sys_activity_logs | TAR-01, 13 |
| restore | ✅ GET | `.restore` | ✅ closure | `Restored` | tt_teacher_assignment_roles, sys_activity_logs | TAR-01, 06, 07 |
| toggleStatus | ✅ | `.update` | ✅ closure | `Toggled` | tt_teacher_assignment_roles, sys_activity_logs | TAR-01 |

**Tables each mutation SHOULD touch:** each mutation writes the role row plus its `sys_activity_logs`
entry (a multi-table write). It does exactly that, inside one transaction.
`destroy` also touches `tt_activity_teachers` (1029 rows referenced) and
`tt_timetable_cell_teachers` (11059 rows referenced) only through the FK — it checks neither
(TAR-14).

## 6. Findings

### F1 — Errors
#### TAR-01 · M · ERR-00 (D1) + ERR-05 — six methods still catch errors themselves and log only the message
**Where:** `TeacherAssignmentRoleController.php` `store:106,145-149` · `update:220,270-285` ·
`destroy:315,348-360` · `forceDelete:421,450-474` · `restore:503,526-539` · `toggleStatus:588,609-620`
```php
// store:145
} catch (\Throwable $e) {
    Log::error('TeacherAssignmentRole store failed', [
        'error' => $e->getMessage(),      // ERR-05: trace lost
        'code' => $request->input('code'),
    ]);
    return redirect()->back()->withInput()
        ->with('error', flash('operation_failed.teacher_assignment_role'));
}
```
**Evidence:** `grep -c "try {" …Controller.php` → `6`. `grep -c "activityLog(" …` → `6`.
Scanner `/tmp/fa-tar.json` reports `ERR-05` at lines 146, 277, 353, 457, 466, 531, 610.
**Consequence:** the controller uses two error models (the rest of the module uses the Laravel
idiom per D1), the stack trace is lost for every failure, and the hand-written catches are exactly
where the next 404/422-swallowing bug will appear. `forceDelete`'s separate
`catch (QueryException)` (line 454) is outside the allowed D2 shapes.
User-facing text is fixed strings (`flash('operation_failed.teacher_assignment_role')`, the FK
message at line 464), so **ERR-01 is not present**.

### F3 — Authorization
#### TAR-02 · L · AUTH-04 + dead policy — every write is authorized twice, and the Policy is never consulted
**Where:** `store:104` + `TeacherAssignmentRoleRequest.php:66-72`; `update:218` + the same request.
`TeacherAssignmentRolePolicy` is registered at `TimetableFoundationServiceProvider.php:138` but every
gate passes a permission **string**, so the Policy is never reached.
**Evidence:** `grep -n "Gate::policy(TeacherAssignmentRole" TimetableFoundationServiceProvider.php`
→ line 138. `grep -n "authorizeByCrudPermission" TeacherAssignmentRoleRequest.php` → line 71.
**Consequence:** the same permission is checked twice per write (once in the FormRequest, once in
the controller), and a Policy that looks active is dead code. The module-wide unreachable-policy
question is not fixed here (§7).

#### TAR-03 · L · AUTH / permission scope — `index` authorizes a permission the destination page does not check
**Where:** `TeacherAssignmentRoleController.php:50`
```php
Gate::authorize('tenant.timetable-foundation.teacher-assignment-role.viewAny');
return redirect()->route('timetable-foundation.menu.timetableMasters', ['tab' => 'teacher-roles']);
```
**Evidence:** `TimetableFoundationController::timetableMasters` (line 409) authorizes
`tenant.timetable-foundation.config.viewAny`, a **different** permission.
**Consequence:** a user granted only `teacher-assignment-role.viewAny` is redirected into a 403.
The two permissions must agree, or the index route should not exist as a separate gate.
8/8 permission names are seeded (`sys_permissions` exact query returns 8 rows), so no name is missing.

### F4 — Validation
#### TAR-04 · H · VAL / form mismatch — editing a role that does not count for workload always fails validation
**Where:** `edit.blade.php:70-73` vs `TeacherAssignmentRoleRequest.php:139-144`
```blade
<input type="number" name="workload_factor" … @disabled(!$countsForWorkload)>
```
```php
'workload_factor' => ['required', 'numeric', 'min:0', 'max:9.99'],
```
**Evidence:** a disabled HTML input is **not submitted**. The rules are shared by store/update and
`workload_factor` is `required` with no `sometimes`. Live data already contains a non-workload role
(`OBSERVER`, `counts_for_workload=0`) but it is `is_system=1` and so blocked by the update guard;
the trap opens the moment a user creates a custom non-workload role.
**Consequence:** an admin who opens a non-workload role and saves any change gets
"The workload factor field is required." and the edit is rejected — the only way out is to
re-check "Counts for Workload", which silently changes the role's meaning.

#### TAR-05 · M · VAL-07 / CTL-06 — business rules live in the controller, not the request/service
**Where:** `store:119-128` and `update:243-252`
```php
if (!$validated['counts_for_workload']) { $validated['workload_factor'] = 0; }
if ($validated['is_primary_instructor']) { $validated['allows_overlap'] = false; }
```
**Evidence:** the same 10-line block appears in both `store` and `update`; the FormRequest has no
`after()` hook.
**Consequence:** two copies of the same rule drift apart; the edit form's disabled input (TAR-04)
is a symptom of the rule being split between blade, request and controller instead of one place.

### F5 — Routes
#### TAR-06 · H · RTE-01 — Restore runs over a GET request
**Where:** `routes/web.php:256`
```php
Route::get('/teacher-assignment-role/{id}/restore', [TeacherAssignmentRoleController::class, 'restore'])->name('teacher-assignment-role.restore');
```
**Evidence:** `route:list` shows `GET|HEAD …/{id}/restore`; `restore()->methods()` → `["GET","HEAD"]`.
The only caller is `trash.blade.php:101` via `<x-backend.table.action-trashed>`, whose class
component (`ActionTrashed.php:19-20`) derives the verb from the route — so changing the verb needs
**no blade edit**.
**Consequence:** GET has no CSRF protection, so a link prefetch, an `<img>` tag, or a browser
prefetch can restore a trashed role without the user clicking anything.

#### TAR-07 · M · CTL-03 — no route model binding; the route parameter and the argument names differ
**Where:** `routes/web.php:254` (`Route::resource('teacher-assignment-role', …)`) vs
`show:165`, `edit:182`, `update:216`, `destroy:311` — all take `$id`.
**Evidence:**
- `route()->getByName('…show')->parameterNames()` → `["teacher_assignment_role"]`.
- The method signatures are `show($id)`, `edit($id)`, `update(TeacherAssignmentRoleRequest $request, $id)`, `destroy($id)`.
Laravel fills untyped scalar route parameters positionally, so this works today (the tests and the
list UI rely on it), but the names do not match and no `TeacherAssignmentRole $model` binding is used.
`forceDelete`/`restore` use `{id}` + `$id` and match.
**Consequence:** the mismatch is a maintenance trap — a future rename of the resource parameter, or
anyone adding a second parameter, silently shifts values. Route model binding would also remove
four `findOrFail()` calls.

### F6 — Controller shape
#### TAR-08 · M · CTL-05 — copy-paste blocks
**Where:** `store:106-140` vs `update:220-265` — the five `$request->boolean(...)` resolutions and the
two business rules are duplicated verbatim; the six `catch` blocks are near-identical.
**Evidence:** diff of the two method bodies; `grep -n "\$request->boolean("` returns 10 lines across
the two methods.
**Consequence:** a change to checkbox handling or the catch policy must be made in two (or six)
places; the store/update divergence already exists (update has the system-role guard, store does not).

#### TAR-09 · L · CTL-04 — no return types on any public method
**Where:** all 11 public methods (`index:48`, `create:64`, … `toggleStatus:568`).
**Evidence:** `grep -nE 'public function …' …Controller.php | grep -c ':'` → `0` (scanner reports
`CTL-04` at every method).
**Consequence:** the declared contract (`View`, `RedirectResponse`, `JsonResponse`) is invisible to
static analysis and readers.

### F7 — Models
#### TAR-10 · L · MDL-04 — relationship methods are not return-typed
**Where:** `TeacherAssignmentRole.php:134` (`activityTeachers`) and `:145` (`timetableCellTeachers`).
```php
public function activityTeachers()        // no : HasMany
public function timetableCellTeachers()   // no : HasMany
```
**Evidence:** scanner `/tmp/fa-tar.json` reports `MDL-04` at lines 134 and 145. Both relationships
resolve and are eager-loadable — proved in tinker:
`$r->activityTeachers()->count()` → `895`, `$r->timetableCellTeachers()->count()` → `10669`.
`$fillable` is declared, `$casts` covers every boolean/integer/decimal/timestamp, `$table`
(`tt_teacher_assignment_roles`) exists in the tenant migration, `SoftDeletes` matches the
`deleted_at` column. No `InteractsWithMedia`, no global scopes.

### F10 — Views
#### TAR-11 · L · views — orphan `create.blade.php` and an empty breadcrumb trail
**Where:** `teacher-assignment-role/create.blade.php` (137 lines), `edit.blade.php:21`,
`show.blade.php:7`, `trash.blade.php:8`.
**Evidence:**
- The create route is excluded (`routes/web.php:254`) and `create()` is `abort(403)`; the dialog is
  `_create-modal.blade.php` → `_create-fields.blade.php`. `grep -rn "teacher-assignment-role.create\b"`
  finds no `route()` call, so `create.blade.php` is reachable only by direct file path and is dead.
- All three rendered views pass `:links="[]"` to `x-backend.components.breadcrum`, so no trail is
  resolved.
**Consequence:** two create forms exist on disk and will drift; the breadcrumb gives the user no
context. All seven in-scope blades compile (`Blade::compileString` → `php -l` → PHP-OK for each);
no `{!! !!}`, no queries in Blade, no `{{-- --}}` inside `@php`.

### F12 — Style
#### TAR-12 · L · STY-01 / STY-04 — `strict_types` missing, and a docblock describes the wrong FK rule
**Where:**
- `declare(strict_types=1)` is absent in the controller, the request, the model and the policy
  (`grep -c "declare(strict_types"` → `0` in each; scanner `STY-01` at line 1 of all four).
- `forceDelete` docblock, `TeacherAssignmentRoleController.php:405-407`:
  ```php
  // FK protection: tt_activity_teachers.assignment_role_id and
  // tt_timetable_cell_teachers.assignment_role_id reference this table
  // with ON DELETE RESTRICT (test_42 …)
  ```
**Evidence:** `information_schema.REFERENTIAL_CONSTRAINTS` → `fk_at_role` and `fk_cct_role` both
`DELETE_RULE = NO ACTION`, not `RESTRICT`. (In MySQL the two behave the same, so this is a comment
defect only, not a behaviour bug.)
**Consequence:** the comment is a message that lies; a reader who trusts it will misread the FK
behaviour. Pint-clean status was not asserted (the audit is read-only and does not run Pint);
the scanner reported no `STY-02` hit for any in-scope file.

### F13 — Deep read
#### TAR-13 · H · deep read — Delete Permanently accepts a LIVE role and bypasses the trash
**Where:** `TeacherAssignmentRoleController.php:421-422`
```php
try {
    $role = TeacherAssignmentRole::withTrashed()->findOrFail($id);
```
**Evidence:**
- `withTrashed()` matches untrashed rows too, so `DELETE /timetable-foundation/teacher-assignment-role/{id}/force-delete`
  with any **live, non-system** id skips the trash entirely and permanently removes it.
- The guard only blocks `is_system`. All 5 live rows today are `is_system=1` (so blocked for them),
  but any user-created role is non-system and reachable.
- The two referencing FKs (`fk_at_role`, `fk_cct_role`, `NO ACTION`) will raise 1451 only while the
  role is referenced; an unreferenced live role deletes silently.
**Consequence:** a user with the `forceDelete` permission can permanently destroy a live role with
no "move to trash" step and no recovery. Fix: `onlyTrashed()->findOrFail()`.

#### TAR-14 · M · deep read — destroy can trash a role that thousands of rows still reference
**Where:** `TeacherAssignmentRoleController.php:315-343`. The only guard is `is_system` (line 319).
**Evidence (read-only counts):**
| Referencing table | Column | Rows referencing a role |
|---|---|---|
| `tt_activity_teachers` | `assignment_role_id` | 1029 |
| `tt_timetable_cell_teachers` | `assignment_role_id` | 11059 |
**Consequence:** soft-deleting a custom role that activities/cells still point at leaves those rows
referring to a trashed role; a `belongsTo` lookup with `SoftDeletes` then returns null and the
activity loses its role label. The action is reversible, so it is M, not H.

#### TAR-15 · M · deep read — `is_system` is user-controlled, so a role can be made permanently immutable
**Where:** `store:116` / `update:240` (`$validated['is_system'] = $request->boolean('is_system')`),
the `is_system` checkbox in `_create-fields.blade.php:75` and `edit.blade.php:98`, and the guards in
`update:224`, `destroy:319`, `forceDelete:425`, `toggleStatus:577`.
**Evidence:** the model defaults `'is_system' => true` (`TeacherAssignmentRole.php:90`) and the
column is `$fillable`; `is_system` is not excluded by the request rules.
**Consequence:** a user can create or convert a normal role to `is_system = true`; from then on it
cannot be updated, trashed, toggled or force-deleted by anyone, and there is no UI path back —
a permanent lock-in of a user-created row.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **Unreachable policies (module-wide):** every policy in TimetableFoundation is unreachable because
  gates pass permission strings, not model instances. Same pattern as AcademicTermController
  (ATC-14) — needs one module-level decision.
- **List partial ownership:** `pages/partials/timetable-masters/teacher-roles/_list.blade.php` is
  rendered by `TimetableFoundationController::timetableMasters`, which eager-loads
  `activityTeachers.teacher.user`, `activityTeachers.activity.subject/class/section` and paginates at
  10 with the `tr_page` page name. There is therefore **no N+1** on the list — the loading is that
  controller's responsibility, not this one's.
- **`x-backend.table.status-switch`** is a class component that takes `permission`; the
  `permission="…update"` prop in the tab list is honoured. `x-backend.table.action` uses
  `viewPermission`/`editPermission`/`deletePermission`; the tab list passes these correctly.
- **Model default `is_system => true`:** any non-controller create path (seeder, import) that omits
  `is_system` silently creates a protected system row. Recorded only; the controller always sets it
  explicitly.

## 8. What this audit did not cover, and why

- **Runtime behaviour:** no browser run and no tests (D4). Every finding is static, a read-only SQL
  probe, or a Blade/route inspection.
- **Writers other than this controller:** seeders and importers of `tt_teacher_assignment_roles`
  were not audited. TAR-15's risk partly comes from them.
- **Data repair of the 5 live seeded roles (all `is_system=1`):** reported only; changing data is
  out of scope.
- **`ControllerAuthTest` / `TtTeacherAssignmentRoleTest`:** the tests referenced in the docblocks
  were not run or edited (D4). Several findings change behaviour those tests assert; the team
  verifies after the fix.
