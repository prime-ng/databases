# Fix Plan — TimetableFoundation / TeacherAssignmentRoleController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/TeacherAssignmentRoleController.php`. It applies **only** ticked items, in this order.

## 1. Blockers reachable today
- [x] **TAR-13** · H · deep read · `TeacherAssignmentRoleController.php:422` — `forceDelete()`: use
      `onlyTrashed()->findOrFail($id)` so a live role can no longer be purged. Before deleting, count
      children in `tt_activity_teachers` and `tt_timetable_cell_teachers`; if any exist, throw a
      `\DomainException` naming the blocking table, caught only as `DomainException` (ERR-01). This
      also removes the need for the `catch (QueryException)` in TAR-01. Effort: S.
- [x] **TAR-04** · H · DECISION · VAL · `edit.blade.php:70-73` (and `TeacherAssignmentRoleRequest.php:139-144`) —
      a non-workload role's `workload_factor` input is `@disabled`, so it is not submitted, yet the rule is `required`.
      (a) ⭐ Blade only: replace `@disabled(!$countsForWorkload)` with `@readonly(!$countsForWorkload)` —
          a `readonly` field **is** submitted, so the current factor posts and the controller still forces 0.
      (b) Request + controller: make `workload_factor` `nullable|numeric` on update and have the controller
          coerce a missing value to 0 when `counts_for_workload` is false.
      (c) Both.
      ➜ Choice: (a) — @readonly in edit.blade.php (Tarun, 2026-10-14)

## 2. Fixes that arm a latent defect (sequenced)
_None._ (TAR-13's child pre-check is self-contained; it does not arm TAR-14.)

## 3. Errors & transactions (F1/F2)
- [x] **TAR-01** · M · ERR-00 / ERR-05 · `TeacherAssignmentRoleController.php:106-154, 220-285, 315-360, 421-474, 503-539, 588-620` —
      remove the try/catch from `store`, `update`, `destroy`, `forceDelete`, `restore` and `toggleStatus`:
  - **Shape:** `return DB::transaction(fn …)` (store/update/destroy already build their redirect after
    the closure; apply the same shape to forceDelete/restore/toggleStatus).
  - **Errors:** let the central handler render them (JSON for the AJAX toggle). Any `\DomainException`
    from TAR-13/TAR-14 is caught **only** as `DomainException` and turned into a flash/JSON message.
  - **Logging:** replace every `Log::error(…, ['error' => $e->getMessage()])` with `report($e)`.

  Effort: S.

## 4. Authorization (F3)
- [x] **TAR-02** · L · AUTH-04 · `TeacherAssignmentRoleController.php:104, 218` — drop the duplicate
      `Gate::authorize` in `store`/`update`; keep the FormRequest `authorize()` (it runs first). The
      unreachable-policy question is module-wide, so it is not fixed here. Effort: S.
- [x] **TAR-03** · L · AUTH · `TeacherAssignmentRoleController.php:50` — the `index` gate checks
      `.teacher-assignment-role.viewAny` but redirects to a page gated on `.config.viewAny`. Align the
      `index` gate with the destination (`tenant.timetable-foundation.config.viewAny`) so the two agree.
      Effort: S.

## 5. Validation, routes, models (F4/F5/F7)
- [x] **TAR-05** · M · VAL-07 / CTL-06 · `TeacherAssignmentRoleController.php:119-128, 243-252` — move the two
      business rules ("no workload ⇒ factor 0"; "primary ⇒ no overlap") to one place — a FormRequest
      `after()` hook or a single private helper — instead of duplicating them in `store` and `update`.
      Effort: S.
- [x] **TAR-06** · H · DECISION · RTE-01 · `routes/web.php:256` — Restore runs over GET.
      (a) ⭐ Change it to `Route::patch`. `x-backend.table.action-trashed` derives the verb from the
          route, so no blade edit is needed; the only caller is `trash.blade.php:101`.
          ⚠ SHARED — this edits `routes/web.php`, so it needs its own explicit tick.
      (b) Leave it as GET and accept the CSRF/prefetch risk.
      ➜ Choice: (a) — Route::patch (Tarun, 2026-10-14; ⚠ SHARED tick given)
- [x] **TAR-07** · M · CTL-03 · `routes/web.php:254` + `TeacherAssignmentRoleController.php:165, 182, 216, 311` —
      the resource parameter is `{teacher_assignment_role}` but the methods take `$id`. Add route model
      binding: `Route::resource('teacher-assignment-role', …)->parameters(['teacher-assignment-role' => 'teacherAssignmentRole'])`
      and type-hint `TeacherAssignmentRole $teacherAssignmentRole` in `show`/`edit`/`update`/`destroy`.
      ⚠ SHARED — edits `routes/web.php`. Effort: M.
- [x] **TAR-10** · L · MDL-04 · `TeacherAssignmentRole.php:134, 145` — add `: HasMany` return types to
      `activityTeachers()` and `timetableCellTeachers()`. ⚠ SHARED — 43 files reach this model; the
      change is type-hint only. Effort: S.

## 6. Controller shape (F6)
- [x] **TAR-08** · M · CTL-05 · `TeacherAssignmentRoleController.php:110-128, 236-252` — the five
      `$request->boolean(...)` resolutions and the two business rules are copied verbatim between
      `store` and `update`. Extract to one private method (or fold into TAR-05's request hook). Effort: S.
- [x] **TAR-09** · L · CTL-04 · `TeacherAssignmentRoleController.php` (all 11 public methods) — add return
      types (`View`, `RedirectResponse`, `JsonResponse`). Effort: S.

## 7. Queries & performance (F9)
_None._

## 8. Behaviour decisions (F13)
- [x] **TAR-14** · M · DECISION · `TeacherAssignmentRoleController.php:315-343` — trashing a role that
      `tt_activity_teachers` (1029 rows) or `tt_timetable_cell_teachers` (11059 rows) still reference leaves
      those rows pointing at a trashed role.
      (a) ⭐ Refuse to trash when either table still references the role, with a `\DomainException` naming
          the count (same guard shape as TAR-13). The action stays reversible by unassigning first.
      (b) Leave it as is — the trash is reversible, so the dangling reference is temporary.
      ➜ Choice: (a) — refuse while referenced, counts named (Tarun, 2026-10-14)
- [x] **TAR-15** · M · DECISION · `TeacherAssignmentRoleController.php:116, 240` — `is_system` is taken from
      the form, so a user can mark a normal role as a system role and make it permanently immutable.
      (a) ⭐ Stop accepting `is_system` from the form: drop it from the request rules and force
          `is_system = false` on create (system roles are seeded only).
      (b) Keep it user-settable but block escalating a non-system role to system.
      (c) Leave it as is.
      ➜ Choice: (a) — is_system dropped from the form; new roles always non-system (Tarun, 2026-10-14)

## 9. Views (F10)
- [x] **TAR-11** · L · orphan · `teacher-assignment-role/create.blade.php` — delete it (the create route is
      excluded and `create()` is `abort(403)`; the live form is `_create-modal` → `_create-fields`).
      Before deleting, re-prove `routed=0 refs=0` for `teacher-assignment-role.create` at fix time.
      Optional in the same pass: give the three rendered views a real breadcrumb trail instead of `:links="[]"`.
      Effort: S.

## 10. Style (F12) — one item per file
- [x] **TAR-12a** · L · STY-01 / STY-04 · `TeacherAssignmentRoleController.php` — add `declare(strict_types=1)`,
      and correct the `forceDelete` docblock (`:405-407`) which says the FKs are `ON DELETE RESTRICT`; the DB
      reports `NO ACTION` (behaviourally identical in MySQL). Effort: S.
- [x] **TAR-12b** · L · STY-01 · `TeacherAssignmentRoleRequest.php` — add `declare(strict_types=1)`. Effort: S.
- [x] **TAR-12c** · L · STY-01 · `TeacherAssignmentRole.php` — add `declare(strict_types=1)`. ⚠ SHARED.
      Effort: S.
- [x] **TAR-12d** · L · STY-01 · `TeacherAssignmentRolePolicy.php` — add `declare(strict_types=1)`. Effort: S.

## 11. Deferred
_None._ (No god-controller split; 622 lines / 11 methods is within CTL-01.)

---

> **How to approve**
> 1. Tick `[x]` on the items to apply.
> 2. Fill every `➜ Choice: ____` (four DECISION items: TAR-04, TAR-06, TAR-14, TAR-15).
> 3. Then run `final-audit-fixer` on `Modules/TimetableFoundation/app/Http/Controllers/TeacherAssignmentRoleController.php`.
>    It applies only the ticked items, in this order, and touches no file an item does not name.
