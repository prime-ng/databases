# Fix Plan — TimetableFoundation / TimetableAssignmentController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/TimetableAssignmentController.php`. It applies **only** ticked items, in this order.
> 5. Item TTA-07 changes a route (`routes/web.php`). It is a DECISION item and needs explicit approval.

## 1. Blockers reachable today
_None._

## 2. Fixes that arm a latent defect (sequenced)
- [x] **TTA-03** · H · TXN-06 · `TimetableAssignmentController.php:79-81, 206-211, 465-486` — close the session-level default race: inside the transaction, take `->lockForUpdate()` on the `assertSingleDefault()` read (both the store and the update call site) so two concurrent "make default" submissions cannot both pass the check. The DB unique key already guards the per-term case; this closes the term-NULL case the migration documents as open. No migration. Effort: S.

## 3. Errors & transactions (F1/F2)
- [x] **TTA-01** · M · ERR-00 / ERR-05 · `TimetableAssignmentController.php:65-184, 194-242, 255-274, 335-357, 372-400` — convert `store`, `update`, `destroy`, `restore` and `forceDelete` to the settled D1 shape:
  - Keep `return DB::transaction(fn () => …)`; drop the surrounding `try` and the `catch (\Throwable)` blocks and their `Log::error(..., ['error' => $e->getMessage()])` lines (the central handler in `bootstrap/app.php` now logs with `report()` and renders the 500/JSON).
  - Keep ONLY `catch (ValidationException)` in `store`/`update` (it redirects the controller-thrown validation from `currentSessionId()`/`assertSingleDefault()` back to the Class Assignment tab); add the allowed-catch comment naming ERR-01 and the date. Move `findOrFail` calls outside the remaining catch if any catch remains.
  - Update the three stale "Satisfies Rule A1" docblocks (`:57-60`, `:327-330`, `:402-407`).
  Effort: M.
- [x] **TTA-02** · L · TXN-05 · `TimetableAssignmentController.php:126, 164-168, 231, 265, 348, 391` — each transaction closure returns the model/count; build the `redirect`/`back()` + `with('success', flash(...))` **after** the closure returns, so the flash is committed only when the transaction commits. Effort: S.
- [x] **TTA-04** · L · audit event · `TimetableAssignmentController.php:380` — change the force-delete event literal from `'Force Deleted'` to `'Deleted'` to match the estate (AcademicTerm, ClassWorkingDay, WorkingDay, PeriodConfig, SchoolTimingProfile, TimingProfile). Effort: S.

## 4. Authorization (F3)
- [x] **TTA-05** · L · AUTH-04 · `TimetableAssignmentController.php:63, 192` — drop the duplicate `Gate::authorize` in `store` and `update`; keep the FormRequest `authorize()` (it runs first, and `authorizeByCrudPermission` maps the verb to the same exact names). Effort: S.

## 5. Validation, routes, models (F4/F5/F7)
_None mechanical — TTA-07 (restore verb) is a route change and is a DECISION item below._

## 6. Queries & performance (F9)
- [x] **TTA-13** · M · QRY / estate C12 · `TimetableAssignmentController.php:314` — change the trash list to `->paginate(10)` to match the estate norm (16 of 19 module paginations use 10). Effort: S.

## 7. Behaviour decisions (F13)
- [x] **TTA-16** · M · DECISION · `TimetableAssignmentController.php:218, 256-258` + `ClassTimetableResolver.php:213` — what should happen when an admin deactivates or trashes the DEFAULT assignment?
      (a) ⭐ Refuse: if the row `is_default_timetable` and the request would deactivate it (update) or trash it (destroy), throw a `\DomainException` ("Make another assignment the default first") that the D1-style handler returns as JSON/flash — the school's fallback can never be retired by accident.
      (b) Auto-clear the flag: deactivating or trashing the default also resets `is_default_timetable`, leaving the school with no named default and the portals' empty state.
      (c) Leave as is — the documented honest state ("no default" renders the empty layout).
      ➜ Choice: (a) refuse — DomainException on update (default + switched off) and destroy (default). Tarun 2026-10-14
- [x] **TTA-09** · M · DECISION · CTL-03 · route model binding on update/destroy/restore/forceDelete.
      (a) ⭐ Keep `{id}` + `findOrFail`/`onlyTrashed()->findOrFail` on all four: `restore`/`forceDelete` genuinely need trashed rows, and binding half the resource while the other half re-resolves would be worse than none. Record as accepted.
      (b) Bind `update`/`destroy` to `{assignment}` and keep `{id}` on `restore`/`forceDelete`.
      (c) Full binding with a custom trashed-aware resolver on `restore`/`forceDelete` (largest change; not worth the one-liner each currently is).
      ➜ Choice: (a) keep {id} + findOrFail; accepted. Tarun 2026-10-14

## 8. Routes (F5)
- [x] **TTA-07** · H · DECISION · RTE-01 · `routes/web.php:340` — Restore runs over GET.
      (a) ⭐ Change it to `Route::post('/timetable-assignment/{id}/restore', …)`. The only caller is `<x-backend.table.action-trashed>`, which already derives the verb from the route and renders a CSRF-protected POST form; no blade edit. ⚠ This changes a route, so it needs explicit approval.
      (b) Change it to `Route::delete(...)` (same component support, semantically "delete a trash state").
      (c) Leave it as GET and accept the no-CSRF risk.
      ➜ Choice: PATCH (not POST) — the estate convention set by CWD-10/TAR-06; action-trashed derives the verb. Tarun 2026-10-14
- [x] **TTA-12** · M · DECISION · QRY-07 · `TimetableAssignmentController.php:129-160` — one `create()` per target row in `store()`.
      (a) ⭐ Leave as is: the per-row activity log needs each new row's id, and a batch `insert()` has no ids to log; the N is bounded by the create dialog. Add no code.
      (b) Batch-insert and drop the per-row disposition (one log row for the submission) — audit attribution loses which class each row belonged to.
      ➜ Choice: (a) leave as is; accepted. Tarun 2026-10-14

## 9. Style (F12) — one item per file
- [x] **TTA-STY-1** · L · STY · `TimetableAssignmentController.php` — add `declare(strict_types=1);`, return types on the 7 public methods (and `backToTab`'s `: RedirectResponse`), replace the stale "Rule A1" docblocks (see TTA-01). The `⚠` comment markers are the module convention and are left alone. Effort: S.
- [x] **TTA-STY-2** · L · STY · `TimetableAssignmentRequest.php` — add `declare(strict_types=1);`. The `⚠` markers are left alone. Effort: S.
- [x] **TTA-STY-3** · L · STY · `TimetableAssignment.php` — add `declare(strict_types=1);`. The `⚠` markers are left alone. ⚠ SHARED — other controllers and services reach this model; comment/declare-only change. Effort: S.
- [x] **TTA-STY-4** · L · STY · `ClassTimetableResolver.php` — no code change; the file already declares `strict_types`. The "TEMPORARY, AND DELETABLE ONCE EVERY TENANT IS MIGRATED" marker on `assignmentsAvailable()` is an intentional migration guard; leave it. Effort: S.

## 10. Queries — leave-as-is notes (reported only, no checkbox)
- **TTA-14** · L · QRY-08 — 4 leading-wildcard LIKEs in the trash search. Acceptable while the trashed set is small; revisit when a tenant approaches a large withdrawn population.
- **TTA-15** · L · QRY — the section-pairing closure runs one query per target row during validation. Bounded by the create form; accepted.

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. `⚠ SHARED` items (TTA-STY-3) and route changes (TTA-07) need their own explicit tick — "tick all" does not cover them.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/TimetableAssignmentController.php`. It applies **only** ticked items, in this order.