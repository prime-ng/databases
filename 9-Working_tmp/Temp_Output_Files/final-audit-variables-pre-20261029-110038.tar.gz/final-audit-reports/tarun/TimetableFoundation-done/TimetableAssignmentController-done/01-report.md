# Final Audit — TimetableFoundation / TimetableAssignmentController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/TimetableAssignmentController.php` (540 lines, 7 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready, but the shortest H-list of the module so far: 0 blockers, 2 HIGH.**

The controller is small, the routes are all correct, every method gates before it loads anything,
and the `tt_timetable_assignment` table currently holds **zero rows**, so nothing here is
destroying data today. The two H findings are a **GET restore** (no CSRF, a preview can withdraw a
withdrawal) and a **check-then-act race** on the session-level default (the documented unique-key
hole means two concurrent saves can both succeed). The biggest maintenance debit is that all five
write paths still use the pre-settlement "Rule A1" try/catch shape — the audit is fresh and that
pattern was already settled away on 2026-10-10 (D1). Because of that, every failure logs only
`$e->getMessage()` (no trace) and returns a generic flash instead of the central renderer.

The effort is about half a day. Four DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 2 | 6 | 10 | 4 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TTA-01 | F8 Services/Jobs | clean: resolver is read-only, constructor-injected, tenant-keyed memo (`grep -n "HTTP\|request()\|create(\|update(\|delete(" ClassTimetableResolver.php` → none) |
| F2 Transactions/Audit | TTA-02, TTA-03, TTA-04 | F9 Queries/Perf | TTA-12, TTA-13, TTA-14, TTA-15 |
| F3 Authorization | TTA-05; all 7 methods gate (TTA-clean) | F10 Views | clean: no queries, relations eager-loaded, action props match gates, breadcrumb registered |
| F4 Validation | clean (typed rules, no `all()`, cross-field in closures) | F11 Security/Tenancy | clean: no `env()`, resolver memo keyed by DB name (TEN-02), logs carry no bodies |
| F5 Routes | TTA-07 | F12 Style | TTA-STY-1..4 |
| F6 Controller shape | TTA-08, TTA-09, TTA-10 | F13 Deep read | TTA-16 |
| F7 Models | clean (MDL-07 scanner hit disproved) | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/TimetableAssignmentController.php` | controller | 540 | this report | ✅ whole class |
| 2 | `app/Http/Requests/TimetableAssignmentRequest.php` | FormRequest | 279 | this report | ✅ whole class |
| 3 | `app/Models/TimetableAssignment.php` | model | 529 | **this report (pre-assigned in 00-CLASS-OWNERS)** | ✅ |
| 4 | `app/Services/ClassTimetableResolver.php` | service | 351 | **this report (pre-assigned in 00-CLASS-OWNERS)** | ✅ |
| 5 | `resources/views/timetable-assignment/trash.blade.php` | view | 132 | this report | ✅ whole file |
| 6 | `routes/web.php` lines 322-342 | routes | — | this report | ✅ |
| 7 | `Modules/SmartTimetable/resources/views/pages/partials/view-and-refinement/class-assignment/_list.blade.php` | host-page tab + forms (SmartTimetable) | 895 | other module | ⚠ usage only: permission props, @can, form field names checked against the Request/controller; full blade audit belongs to the SmartTimetable audit |
| — | `AcademicTerm` model | other module (via `academicTerm()` relation) | — | AcademicTermController report | `↗ linked` |
| — | `Timetable` model | other module (via `timetable()` relation) | — | TimetableController report (pre-assigned) | `↗ linked` |
| — | `OrganizationAcademicSession`, `SchoolClass`, `Section` | SchoolSetup (relations) | — | common | relation targets, referenced only; §7 |
| — | `x-backend.layouts.app`, `x-backend.components.breadcrum`, `x-backend.tab.search-bar`, `x-backend.table.action-trashed` | shared components | — | common | props checked against constructors only |

**Pre-applied 2026-10-10:** none of the in-scope files appears in `../PRE-APPLIED-2026-10-10.md`
(checked: the list covers `AcademicTermController`, `RoomAvailabilityController`,
`ClassWorkingDayController`, `WorkingDayController`, `ActivityController`,
`RequirementConsolidationController`, `TeacherAvailabilityController`, `PriorityConfigController`,
`TimetableFoundationController`, `ClassSubjectSubgroupController` and services — not this
controller, its request, model or service). The try/catch here therefore still pre-dates the
settled ERR-00 decision and is reported fresh as TTA-01.

## 4. Routes

```
GET|HEAD  timetable-foundation/timetable-assignment                      timetable-foundation.timetable-assignment.index        TimetableAssignmentController@index
POST      timetable-foundation/timetable-assignment                      timetable-foundation.timetable-assignment.store        TimetableAssignmentController@store
GET|HEAD  timetable-foundation/timetable-assignment/trash/view           timetable-foundation.timetable-assignment.trashed      TimetableAssignmentController@trashed
PUT       timetable-foundation/timetable-assignment/{id}                 timetable-foundation.timetable-assignment.update       TimetableAssignmentController@update
DELETE    timetable-foundation/timetable-assignment/{id}                 timetable-foundation.timetable-assignment.destroy      TimetableAssignmentController@destroy
DELETE    timetable-foundation/timetable-assignment/{id}/force-delete    timetable-foundation.timetable-assignment.forceDelete  TimetableAssignmentController@forceDelete
GET|HEAD  timetable-foundation/timetable-assignment/{id}/restore         timetable-foundation.timetable-assignment.restore      TimetableAssignmentController@restore   ← GET
```

Evidence probe (uncached):
```
APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | filter TimetableAssignmentController@  → the 7 rows above
```
Middleware on every route (RouteServiceProvider:45-53): `web, InitializeTenancyByDomain,
PreventAccessFromCentralDomains, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation,
auth, verified`. RTE-05 satisfied.

Unrouted public methods: **none** — every public method is routed (RTE-03 clean). Custom routes
(`/trash/view`, `/{id}/restore`, `/{id}/force-delete`) are declared before any `/{id}`
route that could swallow them (RTE-06 clean).

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect to tab) | — |
| store | ✅ | create (request + gate) | ✅ closure (:66) | `Created` (per row) | tt_timetable_assignment, sys_activity_logs | TTA-01, 02, 08, 12 |
| update | ✅ | update (request + gate) | ✅ closure (:195) | `Updated` | tt_timetable_assignment, sys_activity_logs | TTA-01, 02, 09, 16 |
| destroy | ✅ | delete | ✅ closure (:256) | `Trashed` | tt_timetable_assignment, sys_activity_logs | TTA-01, 02, 09, 16 |
| trashed | ✅ | restore | — | — | — (read-only) | TTA-13, 14 |
| restore | ✅ GET | restore | ✅ closure (:336) | `Restored` | tt_timetable_assignment, sys_activity_logs | TTA-01, 02, 07, 09 |
| forceDelete | ✅ | forceDelete | ✅ closure (:373) | `Force Deleted` | tt_timetable_assignment, sys_activity_logs | TTA-01, 02, 04, 09 |

**Tables each mutation SHOULD touch (controller-alignment §0.1):** every write touches the
assignment row plus one `sys_activity_logs` row — nothing more. No FK children reference
`tt_timetable_assignment` (probe), so `forceDelete` has no cascade/restrict surface to check.
`store` writes N rows + N log rows (one submission, many targets — deliberate, see TTA-12).

## 6. Findings

### F1 — Errors
#### TTA-01 · M · ERR-00 (D1) + ERR-05 — five write methods still use the pre-settlement "Rule A1" try/catch and log only `$e->getMessage()`
**Where:** `TimetableAssignmentController.php:65-184` (store), `:194-242` (update), `:255-274` (destroy), `:335-357` (restore), `:372-400` (forceDelete)
```php
177:        } catch (\Throwable $e) {
178:            Log::error('TimetableAssignmentController::store failed', ['error' => $e->getMessage()]);
...
183:            return redirect()->to($this->tabUrl())->withInput()->with('error', 'The operation could not be completed.');
```
**Evidence:** `grep -n "catch\|try {"` → 5 methods each with `catch (\Throwable)`; scanner `ERR-05` flagged all 5 (`/tmp/fa-tta.json`). The docblocks claim "Satisfies Rule A1" (`:58`, `:328`) — A1 was settled away on 2026-10-10 (D1 = the Laravel idiom). The `catch (ValidationException)` in store/update and the `catch (ModelNotFoundException)` rethrows are the correct narrow shapes; the generic `\Throwable` catch is not.
**Consequence:** any non-validation failure hides behind a generic "could not be completed" flash and loses its stack trace, so production errors stop at an opaque toast and a message-only log line instead of reaching the central handler that logs `report($e)` and renders the proper 500/JSON.

Clean checks: no `$e->getMessage()` reaches the user (ERR-01 satisfied — user strings are fixed); no `findOrFail` is turned into a redirect by a catch (ERR-02 satisfied via the re-throws); no `catch (\RuntimeException)`.

### F2 — Transactions/Audit
#### TTA-02 · L · TXN-05 — the success flash and RedirectResponse are built inside the transaction closure (all five writes)
**Where:** store `:126` and `:164-168`, update `:231`, destroy `:265`, restore `:348`, forceDelete `:391`
```php
164:                return $this->backToTab(
165:                    count($created) === 1
166:                        ? flash('created.timetable_assignment')
167:                        : count($created).' class assignments were created successfully.'
168:                );
```
and `restore:348` / `forceDelete:391` both `return back()->with('success', flash(...))`.
**Evidence:** each closure `return`s a `RedirectResponse` and calls `->with(...)` before commit.
**Consequence:** the session flash is written before the transaction commits; if the commit itself fails, the next page shows "was created successfully / was restored" for a row that does not exist.
#### TTA-03 · H · TXN-06 — the session-level default guard is check-then-act with no lock, and the unique key cannot protect it
**Where:** store `:79-81` calls `assertSingleDefault()` before the write; `assertSingleDefault:465-486`; the DB-side hole is documented in `database/migrations/tenant/2026_09_08_000001_rename_tt_timetable_class_jnt_to_tt_timetable_assignment.php:151-167`
```php
79:                if ($isDefault) {
80:                    $this->assertSingleDefault($sessionId, $termId, null);
81:                }
```
```php
465:    private function assertSingleDefault(int $sessionId, ?int $termId, ?int $ignoreId): void
466:    {
467:        $clash = TimetableAssignment::withTrashed()
468:            ->defaultFor($sessionId, $termId)
469:            ->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId))
470:            ->orderByDesc('id')
471:            ->first();
```
**Evidence:** `SHOW CREATE TABLE tt_timetable_assignment` → `UNIQUE KEY uq_ttc_ttAssign_defaultFlag (academic_session_id, academic_term_id, default_flag)`, `default_flag` a generated 1/NULL column. When `academic_term_id` is NULL (the common "not tied to a term" case) MySQL treats every NULL in a unique key as distinct, so the index never engages — exactly what the migration comment (line 151-167) says. No `lockForUpdate()` anywhere in the controller.
**Consequence:** two admins submitting a session-level default in the same instant both pass the read and both insert `is_default_timetable=1` rows; the resolver then silently picks between them by `priority` then `id`, and the school's chosen default may not be the one that wins. Latent — 0 rows on this tenant, and unreachable without concurrency.
#### TTA-04 · L · audit — the force-delete event literal `Force Deleted` matches no sibling controller
**Where:** forceDelete `:380`
```php
380:                activityLog($assignment, 'Force Deleted', [
```
**Evidence:** `grep -rn "'Force Deleted'" Modules/TimetableFoundation/app/Http/Controllers/` → only this file; the estate uses `'Deleted'` (AcademicTerm:303, ClassWorkingDay:309/679, WorkingDay:438/632, PeriodConfig:241, SchoolTimingProfile:229, TimingProfile:284).
**Consequence:** activity-log consumers filtering on `Deleted` miss this resource's permanent deletions; the audit trail of one screen disagrees with every other screen in the estate.

### F3 — Authorization
#### TTA-05 · L · AUTH-04 — `store` and `update` authorize the same permission twice
**Where:** controller store `:63`, update `:192`; request `authorize()` `:51-54`
```php
63:        Gate::authorize('tenant.timetable-foundation.timetable-assignment.create');
```
```php
51:    public function authorize(): bool
52:    {
53:        return $this->authorizeByCrudPermission('tenant.timetable-foundation.timetable-assignment');
54:    }
```
**Evidence:** `AuthorizesTenantFeature::crudActionFromMethod()` maps POST→create, PUT/PATCH→update; both layers ask for the same 4-part name. No `TimetableAssignmentPolicy` exists, so no dead-policy companion issue here (unlike the module-wide pattern).
**Consequence:** redundant checking only — the same permission is evaluated twice and both must pass; harmless today, but a second place to keep in step.

Clean — auth: every routed method calls `Gate::authorize(...)` **before** any record load (AUTH-02 satisfied: store:63, update:192, destroy:253, trashed:294, restore:333, forceDelete:370, index:50). All 7 names are declared in `config/permissionslist.php` (`'timetable-foundation.timetable-assignment' => $crud`) and probed as seeded + granted to **Super Admin and School Admin** on the measured tenant (exact-name query, 7 rows, 0 orphaned `timetable-class` rows after the v8.0 rename migration). The SmartTimetable host blade and the trash blade use the same `.create` / `.update` / `.restore` / `.forceDelete` / `.viewAny` props.

### F4 — Validation
Clean — `TimetableAssignmentRequest.php` is the strongest file in the audit: verb-branched `storeRules()`/`updateRules()`, every field typed, no `$request->all()` (VAL-01), cross-field checks in closures rather than the controller (VAL-07), booleans read via `$request->boolean()` with the `?? 1` priority floor (VAL-03 safe — a `null` from a cleared field hits `?? 1` and becomes priority 1), pre-v8.0 alternate payloads documented. `class`-vs-`school` scope is posted, not inferred, so an empty form cannot become "whole school" by accident.

### F5 — Routes
#### TTA-07 · H · RTE-01 — Restore runs over a GET request
**Where:** `routes/web.php:340`
```php
340:Route::get('/timetable-assignment/{id}/restore', [TimetableAssignmentController::class, 'restore'])->name('timetable-assignment.restore');
```
**Evidence:** `route:list` → `GET|HEAD .../{id}/restore`. The only caller is `x-backend.table.action-trashed` (`trash.blade.php:103-108`), which derives the HTTP verb from the route — so changing the verb needs no blade edit (it already renders a POST form for non-GET verbs, with CSRF).
**Consequence:** GET has no CSRF protection, so a link prefetch, preview or automated crawler can restore a withdrawn assignment (and the request URI leaks the id to every middleware log/referrer along the way).

Otherwise clean — all route targets exist (RTE-02), every public method routed (RTE-03), literal `/trash/view` declared before `/{id}` (RTE-06), tenant middleware group present (RTE-05), all state changes are POST/PUT/DELETE except the restore above (RTE-04 clean).

### F6 — Controller shape
#### TTA-08 · M · CTL-02 — `store()` is 125 lines
**Where:** store `:61-185`
**Evidence:** scanner `CTL-02` → "store() is 125 lines"; `sed -n '61,185p'` confirms one long method; the docblock explains the whole-school branch versus the per-target loop.
**Consequence:** the longest method in the file mixes the school-wide single-row branch and the class target loop, so the two payload shapes are harder to hold in one head than a small private writer per branch would be.
#### TTA-09 · M · CTL-03 — four write methods take `$id` + `findOrFail` instead of route model binding
**Where:** update `:190/:196`, destroy `:251/:257`, restore `:331/:337` (`onlyTrashed()->findOrFail`), forceDelete `:368/:374` (`onlyTrashed()->findOrFail`)
**Evidence:** every route binds the placeholder as `{id}` and every method re-resolves it. Plain route-model binding would use a live `findOrFail` and break `restore`/`forceDelete`, which explicitly need trashed rows.
**Consequence:** maintainability only — a must-change for the binding style, with a real constraint on restore/forceDelete if it is ever attempted (see decision in the plan).
#### TTA-10 · L · CTL-04 — no return types on any of the 7 public methods
**Evidence:** scanner `CTL-04` for index/store/update/destroy/trashed/restore/forceDelete.
**Consequence:** the helpers are typed but the entry points are not, so callers and future editors get no contract from the signature.

Clean — no debug leftovers (`dd/dump/ray` — scanner CTL-09 only flags a parse error in an unrelated SchoolSetup policy), no dead private methods (all 5 helpers are called), no `compact()` over ~15 variables, no `request()` helper inside methods (the Request is injected in `trashed`; the other write methods rely on the injected FormRequest.

### F7 — Models
Clean with notes. `TimetableAssignment.php`:
- **MDL-07 scanner hit disproved.** The scanner said "table 'tt_timetable_assignment' is not created by any migration" — false: `SHOW CREATE TABLE` proves the table exists, created by `2026_06_16_152628_create_tt_timetable_class_jnt_table.php` and renamed by `2026_09_08_000001_...`. MDL-07 checked, not present.
- `$fillable` declared without sensitive columns; `applies_to_all_classes` and `default_flag` deliberately absent (CHECK-constraint / generated-column protection, MDL-01 ✓).
- `$casts` cover every boolean, date and integer column (MDL-02 ✓); `SoftDeletes` present and `deleted_at` exists (MDL-03 ✓).
- Relationships `academicSession`/`academicTerm`/`class`/`section`/`timetable` all have `BelongsTo` return types and resolve in tinker (`class_exists`, `getTable()` probe ✓).
- `booted()` derives `applies_to_all_classes` from `class_id` at `saving` — the single source of truth for the CHECK constraint (MDL-06 ✓).
- `makeSchoolDefault()` is public dead write code, kept on purpose and documented (`:334-362`, "NOTHING CALLS THIS. IT IS KEPT, UNCALLED, ON PURPOSE"); recorded, not fixed by this workflow.

### F8 — Services/Jobs
Clean — `ClassTimetableResolver.php`: constructor-injected into the controller (SVC-02), read-only public surface `assignmentFor`/`defaultFor`/`timetableIdFor`/`competingWith` (SVC-03 ✓ — no `create`/`update`/`delete` anywhere), no HTTP/session use (SVC-01 ✓). The per-tenant memo `$tableExists`/`$termTableExists` is keyed by database name, not a bare bool (TEN-02 ✓). No jobs, events, mail or notifications in scope.

### F9 — Queries/Performance
#### TTA-12 · M · QRY-07 — `store()` inserts one row per target in a loop
**Where:** store `:129-160`
```php
129:                foreach ($validated['targets'] as $index => $target) {
...
148:                    $assignment = TimetableAssignment::create($attributes);
```
**Evidence:** scanner `QRY-07` → "TimetableAssignment::create() inside a loop". The comment at `:162-163` explains why: each row must be logged separately with its own id, and a batch write has no per-row ids to log.
**Consequence:** an N-target submission runs N inserts — bounded (a handful) and not an N+1, but the module's first place a batch `insert()` was consciously traded for per-row attribution; whether to keep the trade is your call (decision in the plan).
#### TTA-13 · M · QRY / estate C12 — the trash list paginates 20, not the estate's 10
**Where:** trashed `:314`
```php
314:            ->paginate(20)
```
**Evidence:** `grep -rn "paginate("` across the module → 16 `paginate(10)`, 3 `paginate(20)`, 2 `paginate(25)`; the gold-standard AcademicTerm test calls 10 the norm. `->withQueryString()` is present (QRY-13 ✓).
**Consequence:** one trash screen in the module loads 2× the estate-standard page of rows; minor memory/latency debt, not a correctness bug.
#### TTA-14 · L · QRY-08 — 4 leading-wildcard `LIKE '%x%'` searches on related names
**Where:** trashed `:306-309`
```php
306:                    $qq->whereHas('class', fn ($r) => $r->where('name', 'like', "%{$term}%"))
307:                        ->orWhereHas('section', fn ($r) => $r->where('name', 'like', "%{$term}%"))
308:                        ->orWhereHas('timetable', fn ($r) => $r->where('name', 'like', "%{$term}%")
309:                            ->orWhere('code', 'like', "%{$term}%"));
```
**Evidence:** scanner `QRY-08` → 4 leading-wildcard LIKEs; the alternate is prefix `LIKE 'x%'` or a FULLTEXT column.
**Consequence:** the search cannot use an index on the related tables' name/code columns — acceptable while the trashed set is tiny, a growing cost when a large school withdraws many assignments.
#### TTA-15 · L · QRY — the section-pairing closure runs one DB query per target row during validation
**Where:** `TimetableAssignmentRequest.php:138-161` (`DB::table('sch_class_section_jnt')->...->exists()`)
**Evidence:** the closure in `storeRules()` executes for every row of `targets.*`.
**Consequence:** an N-line submission costs up to N point lookups during validation — bounded by the form size, but the only query-on-input pattern in the class.

Clean — `trashed()` eager-loads the four relations the blade touches (VRY-02 ✓), uses `value()`/`exists()`, no `::all()`, and the resolver reuses one base `coveringDate` predicate.

### F10 — Views
Clean — `trash.blade.php` (132 lines): no `Model::`/`DB::` calls (VIEW-01), all relations used in the loop are eager-loaded (VIEW-02), user text rendered through `{{ }}` (VIEW-03 — no `{!! !!}`), row actions use `<x-backend.table.action-trashed>` with the exact `.restore`/`.forceDelete` permission props, school-wide rows render a badge instead of a null class call, the breadcrumb resolves through the registered `timetable-foundation.timetable-assignment.index` entry (derives `.trashed`), and the blade compiles (no `{{-- --}}` inside `@php`).

### F11 — Security/Tenancy
Clean — no `env()` outside config (SEC-01), logs carry no request bodies or tokens (SEC-04), no hard-coded ids (`?? 1` absent; the priority floor is the documented column default), the resolver memo is tenant-keyed by database name (TEN-02), no central-model access from tenant context without `tenancy()` (TEN-03 — `OrganizationAcademicSession` is a tenant model), no media in scope (TEN-01 n/a).

### F12 — Style (L — one plan item per file)
- **TTA-STY-1** · controller — `strict_types` not declared; 7 public methods without return types (see TTA-10); stale "Satisfies Rule A1" docblocks at `:58`/`:328` now describing a settled-away standard; the module's `⚠` comment markers throughout.
- **TTA-STY-2** · request — `strict_types` not declared; `⚠` markers in comments.
- **TTA-STY-3** · model — `strict_types` not declared; `⚠` markers in comments.
- **TTA-STY-4** · service — `strict_types` IS declared (`:3`, the only in-scope file with it); remaining hits are `⚠` markers plus the documented "⛔ TEMPORARY" marker on `assignmentsAvailable()` (`:70`), which is an intentional migration-guard, not a debug leftover.

### F13 — Deep read
#### TTA-16 · M · deep read — the DEFAULT assignment can be deactivated or trashed with no warning, silently retiring the school's fallback
**Where:** update `:218` (the `is_active` checkbox is editable on any row), destroy `:258` (a default row is trashed like any other); the consequence is documented in `ClassTimetableResolver.php:213-214` (`->active()` filters `defaultFor`).
```php
218:                    'is_active' => $request->boolean('is_active'),
```
```php
256:                $assignment = TimetableAssignment::findOrFail($id);
257:                $assignment->delete();
```
**Evidence:** `defaultFor()` begins with `->active()->where('is_default_timetable', true)`; an inactive or trashed default returns nothing, so every date its window covered resolves to **no timetable** (the resolver's "no default at all" state — `ClassTimetableResolver.php:165-173`).
**Consequence:** an admin who unticks Active (or trashes) the default row removes the fallback for the whole window with no refusal and no warning, and the student/parent portals silently show the empty state instead.

**Deep-read answers (one line each):** 1 no overwrite of unrelated rows (the only broad writer, `makeSchoolDefault`, is dead); 2 nothing deleted before its replacement is stored (defaults are repointed only by the dead method, so nothing overwrites a default behind the user's back); 3 one implementation of the precedence rule (lives only in `ClassTimetableResolver`, noted as THE ONE PLACE); 4 the soft-delete × unique trap is deliberately handled (`assertSingleDefault` uses `withTrashed()` so a trashed default still blocks a 1062 — matches the migration comment); 5 a race exists — TTA-03; 6 no authorization hole (all methods gate first, and both surfaces use the same permission); 7 messages tell the truth (fixed strings, honest counts); 8 dead features — `makeSchoolDefault` (model, documented) and the pre-v8.0 overlap ban (both `assertNoOverlap` remnants are gone and documented).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **The SmartTimetable host blade** (`class-assignment/_list.blade.php`, 895 lines) is the real UI of this controller. The four enforcement surfaces and the form field names were verified against the Request/controller, but the blade's own logic belongs to the SmartTimetable audit, which has not started. Nothing in it needs this report.
- **Unreachable policies (module-wide):** the module registers 23 policies but most gates pass strings. This resource has **no** `TimetableAssignmentPolicy`, so it is not affected.
- **`PublishedTimetable`** (owner report: TimetableFoundationController) consumes `ClassTimetableResolver::defaultFor()` / `timetableIdFor()` on the portals; the resolver is audited here, the portal consumer is not.
- **The `⚠` comment convention** is module-wide and appears in every file this audit saw; TTA-STY-1..4 report it, but removing it is a team decision, not a per-controller fix.
- **Zero data:** on the measured tenant `tt_timetable_assignment` holds 0 rows, so no live school is affected by TTA-03/TTA-16 today; that also means the trash screen's LIKE search has nothing to be slow about.

## 8. Not covered, and why

- **Runtime behaviour:** no browser, no tests, no DB writes of any kind (D4 and the hard bans). Every finding is static or a read-only SQL probe on `test.localhost`.
- **Other writers/readers of `tt_timetable_assignment`:** the seeder `TtTimetableAssignmentSeeder`, the create-default-when-timetable-created path, and `PublishedTimetable` were not audited; they are named in model comments as the other surfaces the booted() hook and the default guard must stay in step with.
- **The SmartTimetable tab blade** beyond the four surfaces and form fields — §7.
- **Data repair:** none exists to repair (0 rows).