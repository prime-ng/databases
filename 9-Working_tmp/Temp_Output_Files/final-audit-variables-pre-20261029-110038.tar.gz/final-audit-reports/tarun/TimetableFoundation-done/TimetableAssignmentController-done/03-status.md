# 03 — Status · TimetableFoundation / TimetableAssignmentController

**Fixed:** 2026-10-14 · **By:** opencode / claude (fix) · **Plan:** `02-fix-plan.md` (14 items ticked)

## 1. Pre-applied 2026-10-10

None. This controller is not listed in `PRE-APPLIED-2026-10-10.md`.

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| TTA-01 | `TimetableAssignmentController.php` — `store`, `update`, `destroy`, `restore`, `forceDelete` | D1 shape. Every `catch (\Throwable)` + `Log::error` is gone; the transaction rolls back on its own and the central handler logs and renders. Kept: `catch (ValidationException)` in `store`/`update` (re-points the field error at the tab, ERR-01) and `catch (\DomainException)` in `update`/`destroy` (TTA-16 refusal, ERR-01). The stale "Rule A1" docblocks are replaced with final-audit notes. `Log` and `ModelNotFoundException` imports removed. | `grep -n "Throwable\|Log::\|Rule A1" <controller>` | no output | 2026-10-14 |
| TTA-02 | same five methods | Each closure returns a count or nothing; the redirect and `flash()` are built **after** the transaction returns. | read | — | 2026-10-14 |
| TTA-03 | `assertSingleDefault()` | `->lockForUpdate()` on the default lookup. Both callers (`store`, `update`) run inside the transaction. | `grep -n "lockForUpdate" <controller>` | 1 hit | 2026-10-14 |
| TTA-04 | `forceDelete()` | Event literal `'Force Deleted'` → `'Deleted'` (estate convention). 0 old log rows existed on this tenant. | replay §6 | last log event = `Deleted` | 2026-10-14 |
| TTA-05 | `store()`, `update()` | Duplicate `Gate::authorize` dropped. `TimetableAssignmentRequest::authorize()` runs first and `authorizeByCrudPermission` maps POST→`.create`, PUT→`.update` — the same names. | `grep -c "Gate::authorize" <controller>` | 5 (index, destroy, trashed, restore, forceDelete) | 2026-10-14 |
| TTA-07 | `routes/web.php:362` | Restore is `Route::patch` (was GET). `x-backend.table.action-trashed` reads the verb from the route, so `trash.blade.php` is unchanged. Choice: PATCH, matching CWD-10/TAR-06, not the plan's POST. | uncached `route:list` | `PATCH …/{id}/restore` | 2026-10-14 |
| TTA-13 | `trashed()` | `->paginate(20)` → `->paginate(10)`. | `grep -n "paginate" <controller>` | `paginate(10)` | 2026-10-14 |
| TTA-16 | `update()`, `destroy()` | **Decision (a): refuse.** `update` throws a `DomainException` when the result would be a default that is switched off; `destroy` throws one when the row is the default. Unticking "Default" stays allowed, so the default can still be moved. Both refusals redirect to the tab with the message as an `error` flash; no write, no log. | replay §6 | both 302 + message, row unchanged | 2026-10-14 |
| TTA-09 | — | Decision (a): **accepted.** `{id}` + `findOrFail` / `onlyTrashed()->findOrFail` kept on all four. | — | — | 2026-10-14 |
| TTA-12 | `store()` loop | Decision (a): **accepted.** One `create()` per target; a comment records why (per-row log needs each id). | — | — | 2026-10-14 |
| TTA-STY-1 | controller | `declare(strict_types=1);`, return types on all 7 public methods (`RedirectResponse` / `View`) and on `backToTab()`. | `php -l`, `class_exists` | ok | 2026-10-14 |
| TTA-STY-2 | `Http/Requests/TimetableAssignmentRequest.php` | `declare(strict_types=1);` | `class_exists` | ok | 2026-10-14 |
| TTA-STY-3 ⚠ SHARED | `Models/TimetableAssignment.php` | `declare(strict_types=1);` — explicitly approved. It governs only calls made from inside the model file; the class-assignment tab (which reads it through the resolver) renders 200. | replay §6 | tab 200 | 2026-10-14 |
| TTA-STY-4 | `Services/ClassTimetableResolver.php` | No change — already declares `strict_types`. | — | — | 2026-10-14 |

## 3. Not applied

Nothing. TTA-14 and TTA-15 were report-only (§10 of the plan) and stay accepted.

## 4. Needs Tarun's hand

- **Browser check of the two refusals** on `/smart-timetable/view-and-refinement?tab=class-assignment`: edit the default row and switch "Active" off, then try to withdraw it. Each should show the red error toast and leave the row as it was.
- **No Dusk test references the restore route or the `'Force Deleted'` literal** (grep of `tests/` and `prime_testing/tests`: 0 hits), so no suite needs updating.

## 5. Unverifiable by this workflow (D4)

- **The `lockForUpdate` race (TTA-03).** Two simultaneous "make default" saves cannot be produced from one process. The lock is verified by reading only. On a term-NULL session with no default row yet, InnoDB locks the index gap, which narrows but does not fully close the window the migration documents.

## 6. Verification log

```
php -l (controller, request, model, routes)             -> no syntax errors (re-run after Pint)
vendor/bin/pint <3 php files> --format agent            -> passed
class_exists: controller / model / request              -> true true true
route:list (uncached), TimetableAssignmentController     -> 7 routes; restore = PATCH
trash.blade.php compile                                 -> lint ok, @push 0/0

kernel replay on test.localhost, user 1, inside DB::beginTransaction / rollBack:
  GET /smart-timetable/view-and-refinement?tab=class-assignment   -> 200 (361,499 bytes)
  GET /timetable-foundation/timetable-assignment/trash/view       -> 200
  PUT  default row, is_active=0                                   -> 302, error flash, still active=1
  DELETE default row                                              -> 302, error flash, not trashed
  DELETE throwaway non-default row                                -> 302, trashed, "moved to trash"
  PATCH restore                                                   -> 302, restored
  DELETE force-delete                                             -> 302, gone, last log event 'Deleted'
  after rollback: live rows = 1 (unchanged)
```

## 7. Final state

**FIXED.** Open: TTA-09 and TTA-12 (accepted), TTA-14 and TTA-15 (report only). Pre-existing note, not in the plan: two stacked, stale docblocks sit above `assertSingleDefault()` (one describes a removed method) — candidate for the next style pass.
