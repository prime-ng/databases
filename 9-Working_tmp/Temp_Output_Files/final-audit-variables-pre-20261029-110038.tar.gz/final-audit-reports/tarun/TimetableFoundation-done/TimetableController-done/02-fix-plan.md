# Fix Plan — TimetableFoundation / TimetableController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/TimetableController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

## 1. Blockers reachable today
- [x] **TBL-05** · B · VAL · `TimetableController.php:75` — change the rule to `exists:sch_org_academic_sessions_jnt,id` (the table the `OrganizationAcademicSession` model already reads; the dropdown data and the rule must name the same table). Effort: S.
- [x] **TBL-07** · B · DECISION · VAL/DDL — `academic_term_id` is NOT NULL but the create form has no term field.
      (a) ⭐ Add a Term selector to `create.blade.php` (and the future edit form) and make `academic_term_id` `required` (term is the unit timetables hang off; all 7 live rows have a term). No migration.
      (b) A new additive migration makes `academic_term_id` nullable; keep the `nullable` rule and no form field.
      (c) Leave as is; the create path stays dead.
      ➜ Choice: (a) — Term picker added to create.blade.php; `academic_term_id` required and scoped to the session (Tarun 2026-10-14)

## 2. Fixes that arm a latent defect (sequenced)
- [x] **TBL-18** · H · VIEW-02 · `show.blade.php:324, 439` — read the grid with the ordinal key: `$cellData = $timetableGrid[$day->id][$period->period_ord] ?? null;` (controller keys by `period_ord`; ids 15–23 vs ords 1–9 measured). This is what makes the weekly grid and Detailed Schedule list render the 2,227 scheduled cells. Effort: S.
- [x] **TBL-08** · H · VAL-05/CTL-05 · `TimetableController.php:207` — align `update()`'s name rule with `store()`: `max:200` + the same `Rule::unique('tt_timetables','name')` scoped to term/type/`whereNull('deleted_at')`, so renames respect `uq_tt_name_term_type` and long names cannot 1406. Effort: S.
- [x] **TBL-10** · H · DECISION · RTE-02 — the `edit` route renders a view that does not exist.
      (a) ⭐ Make `edit()`'s body `abort(403)` with a `// NOT ROUTED` comment, and leave `update()` as the (currently form-less) write path. Small, kills the 500; the real edit form is a future feature. ⚠ This changes what the route does, so it needs explicit approval.
      (b) Build `resources/views/timetable/edit.blade.php` and wire it (a real form is a feature, not a fix — effort M).
      (c) Remove `edit`/`update` from the resource (`->except(['edit','update'])`) and gate both methods.
      ➜ Choice: (a) — `edit()` now aborts 403 after its Gate; `update()` stays the write path (Tarun 2026-10-14)

## 3. Errors & transactions (F1/F2)
- [x] **TBL-01** · M · ERR-00/ERR-05 · `TimetableController.php:102-108, 229-237, 269-277` — remove the manual try/catch in `store`, `update` and `destroy`; keep/return `DB::transaction(fn () => …)`. Move each `Gate::authorize` to the top of the method, and `update()`'s `$request->validate()` **before** the closure. Where a log is still needed, use `report($e)` or `Log::error(…, ['exception' => $e])` — never `['error' => $e->getMessage()]`. Let the central handler render the friendly page/JSON. Effort: S.
- [x] **TBL-02** · H · ERR-02 · `TimetableController.php:204-237` — resolve `ValidateException`-swallowing by the TBL-01 change alone (validation moves out of the catch range); verify the form gets `withErrors` again. Effort: S.
- [x] **TBL-03** · L · TXN-05 · `TimetableController.php:224-226, 264-266` — each closure returns the model/result; build `redirect()` and the flash after the closure. Effort: S.

## 4. Authorization (F3)
_None tickable here — TBL-04 is the module-wide unreachable-policy pattern (deferred, §10)._

## 5. Validation, routes, models (F4/F5/F7)
- [x] **TBL-09** · M · VAL-02 · `TimetableController.php:57-82, 206-214` — extract the rules into a `TimetableRequest` (module `app/Http/Requests/`), include `authorize()` returning the same permission the method gates (so one authoriser per concern), and use `$request->validated()` in both methods. Adjust both methods' signatures as needed. Effort: S–M.
- [x] **TBL-06** · L · CTL-10 · `TimetableController.php:84` — delete the `uuid` assignment; no column, no reader, no DDL intent (proven in the report). Effort: S.
- [x] **TBL-15** · H · MDL-03 · `TimetableCell.php:84-93` — add `->wherePivotNull('deleted_at')` to `teachers()`, matching the pivot's `SoftDeletes`. ⚠ SHARED — the model is reachable by SmartTimetable and the substitution surfaces.
- [x] **TBL-14** · L · MDL/CTL-10 · `TimetableCell.php:150-153, 176-182, 201-209, 222-234` — remove `dayByOrder()` (binds a non-existent `order` column), `scopeForClass()` (binds non-existent `class_id`/`section_id`), the `ACTIVE` branch in `scopeActive()` (not an enum value), and the dead `?? 'N/A'` in `getTimeSlotAttribute()`. ⚠ SHARED. Effort: S.
- [x] **TBL-16** · L · MDL-04/STY · `TimetableCellTeacher.php:43,48,53` — add `: BelongsTo` return types; add int casts for `published_by`, `created_by`, `parent_timetable_id`, `generation_strategy_id` in `Timetable::$casts`. ⚠ SHARED (Timetable model).

## 6. Queries & performance (F9)
- [x] **TBL-17** · M · DECISION · QRY-02 — `show()` pulls ~30,000 cells + 4 eager relations on every GET (measured).
      (a) ⭐ Defer: leave the read as-is this pass (correct, eager-loading avoids N+1), record as accepted debt. Fix the display first (TBL-18/19) so the data is at least used.
      (b) Cache the grid payload per (tenant, timetable) with a tenant-keyed cache — cache addition is a DECISION by §7.
      (c) Paginate the Detailed Schedule list and drop the unrendered columns.
      ➜ Choice: (a) — deferred as accepted debt; note the class picker (TBL-18b) already cut the read to one class's cells

## 7. Views (F10)
- [x] **TBL-19** · M · VIEW · `show.blade.php:114, 297, 190` + controller `:161` — count only activity-bearing cells for the "Periods/Week" and "classes" figures (the grid already has `activity_id`), and render the Hard Violations card from `constraint_violations` (the real column) instead of the non-existent `hard_violations`. Effort: S.
- [x] **TBL-13** · L · CTL-10 · `views/timetable/{index,trash,preview}.blade.php` — delete the three orphan blades. Re-prove `rendered=0` (`grep -rn "timetablefoundation::timetable.{index,trash,preview}"`) at fix time before deleting. Effort: S. ⚠ `index.blade.php` is the only one any route name (`timetable-foundation.timetable.index`) could be confused with; the route redirects, the blade renders nothing.

## 8. Style (F12) — one item per file
- [x] **TBL-20a** · L · STY/CTL-04 · `TimetableController.php` — add `declare(strict_types=1)` and return types on all 7 public methods (`: RedirectResponse`, `: View`, `: Response`). Effort: S.
- [x] **TBL-20b** · L · STY-04 · `Timetable.php` — drop the ⚠-block emoji markers in the comments (lines 426, 437, 443, 448) and add `declare(strict_types=1)`. ⚠ SHARED.
- [x] **TBL-20c** · L · STY-04 · `TimetableCell.php` — drop the emoji markers in the warning comments (lines 52, 56, 101, 107, 113, 117, 136, 139, 142) and add `declare(strict_types=1)`. ⚠ SHARED.
- [x] **TBL-20d** · L · STY-01 · `TimetableCellTeacher.php` — add `declare(strict_types=1)`. ⚠ SHARED.
- [x] **TBL-20e** · L · STY-01 · `TimetableSnapshot.php` — add `declare(strict_types=1)`. ⚠ SHARED (written by SnapshotWriter).
- [x] **TBL-20f** · L · STY-01 · `SnapshotTimetable.php` — add `declare(strict_types=1)`. ⚠ SHARED.
- [x] **TBL-20g** · L · STY-01 · `TimetablePolicy.php` — add `declare(strict_types=1)`. Effort: S.

## 9. Behaviour decisions (F13)
- [x] **TBL-21** · M · DECISION · `TimetableController.php:248-258` — destroy() soft-deletes a timetable that still has ~30k cells and snapshot links, and there is no restore UI.
      (a) ⭐ Refuse with a `\DomainException` when the timetable is referenced by `tt_timetable_assignment` or is a `parent_timetable_id` of another timetable (the real "in use" signals). Message names the count, per the D2 shape.
      (b) Refuse whenever any cells exist (blocks trashing every generated timetable).
      (c) Leave as is.
      ➜ Choice: (a) — refuse while `tt_timetable_assignment` rows or child timetables exist; message names both counts (Tarun 2026-10-14)
- [x] **TBL-22** · M · DECISION · `TimetableController.php:57-82` / `create.blade.php:123-130` — the Generation Method select is silently ignored (every create is MANUAL) and the Active toggle is overridden by the model's `saving` hook.
      (a) ⭐ Wire `generation_method` into `store()` (rule + pass-through; it is already `$fillable`), and relabel the Active switch or read it only for display — the model's `is_active mirrors status` rule stays authoritative.
      (b) Remove the Generation Method field from the form (MANUAL-only).
      (c) Leave as is.
      ➜ Choice: (a) — `generation_method` validated and stored (default MANUAL); Active switch replaced by a note that new timetables start as draft (Tarun 2026-10-14)

## 10. Deferred / module-wide
- [x] **TBL-04** · L · DECISION · AUTH-06 — TimetablePolicy and every module policy are registered but never consulted (gates pass strings; same as AcademicTerm ATC-14).
      (a) ⭐ Defer to the module-wide pass; record once in the module summary.
      (b) Make each gate in this controller call the policy (`Gate::authorize('view', $timetable)`) — large behavioural change, do not do in this pass.
      ➜ Choice: (a) — deferred to the module-wide policy pass (Tarun 2026-10-14)

> **How to approve** — tick `[x]`; fill every `➜ Choice:`; then run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/TimetableController.php`. The fixer applies only ticked items, in the order above, and touches only the files each item names.

## 11. Found during fixing (2026-10-14) — applied with Tarun's go
- [x] **TBL-RTE** · M · RTE-02 · `routes/web.php` — removed the four custom routes (trash/view, restore, force-delete, toggle-status) that pointed at methods that never existed. Approved round 2: "Remove the 4 routes".
- [x] **TBL-23** · B · CTL · `TimetableController.php` `create()` — `OrganizationAcademicSession` and `PeriodSet` have no `ordered()` scope, so the create page returned 500 for every user (pre-existing; missed by the audit). Ordered explicitly in the controller (`orderByDesc('start_date')`, `orderBy('name')`); no shared model touched.
- [x] **TBL-18b** · H · VIEW · `TimetableController.php` `show()` + `show.blade.php` — the grid has one box per day×period but ~620 class-group cells per slot, so after TBL-18 46 of 48 boxes read "N/A". Approved: "Add a class picker". The page now shows one class-section's week (same rule as `StandardTimetableController::classView()`), with a "+N more" badge for parallel cells.
