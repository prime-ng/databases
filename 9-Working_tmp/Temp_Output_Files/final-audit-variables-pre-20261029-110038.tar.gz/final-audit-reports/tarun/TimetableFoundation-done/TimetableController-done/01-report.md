# Final Audit — TimetableFoundation / TimetableController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/TimetableController.php` (279 lines, 7 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 2 blockers, 5 HIGH.**

The read-only `show` screen and the two write paths that *can* run (update, destroy) are structurally sound — every mutation uses one `DB::transaction`, `activityLog` sits inside it after the write, every routed method gates, and route-model binding is intact. But three things break a real school:

- **Creating a timetable is impossible.** `store()` validates `academic_session_id` against a table that does not exist (`sch_organization_academic_sessions`; the live table is `sch_org_academic_sessions_jnt`), so every submit dies with a generic "could not be completed" flash. Even after that is fixed, the create form has no Term field while the column `academic_term_id` is NOT NULL, so the INSERT raises 1364.
- **The show page's weekly grid is permanently empty.** The controller keys cells by `period_ord`; the blade reads them by the period row's `id`. Measured on this tenant: period ids are 15–23 while ordinals are 1–9, so every lookup misses and the page says "No Scheduled Classes" for timetables that have 2,227 scheduled cells.
- **The edit route 500s.** `edit()` renders `timetablefoundation::timetable.edit`, which does not exist.

The worst single finding is **TBL-05** — the dead create path, because the table-name slip is invisible to linters and makes the whole feature silently inert.

Effort is roughly one day, and six DECISION items need your choice.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 2 | 5 | 6 | 8 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TBL-01, TBL-02 | F8 Services/Jobs | clean: no service/job/event (`grep -oE '…(Service\|Job\|Event)\b' $C` → none) |
| F2 Transactions/Audit | TBL-03 | F9 Queries/Perf | TBL-17 |
| F3 Authorization | TBL-04 | F10 Views | TBL-18, TBL-19 |
| F4 Validation | TBL-05, TBL-06, TBL-07, TBL-08, TBL-09 | F11 Security/Tenancy | clean: no `env()`, no JSON exposure, tenant middleware present on all 7 routes |
| F5 Routes | TBL-10 | F12 Style | TBL-20 |
| F6 Controller shape | TBL-11, TBL-13 | F13 Deep read | TBL-21, TBL-22 |
| F7 Models | TBL-14, TBL-15, TBL-16 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/TimetableController.php` | controller | 279 | this report | ✅ whole class |
| 2 | `app/Models/Timetable.php` | model | 516 | **this report (pre-assigned, 00-CLASS-OWNERS)** | ✅ |
| 3 | `app/Models/TimetableCell.php` | model | 279 | **this report (pre-assigned)** | ✅ |
| 4 | `app/Models/TimetableCellTeacher.php` | model | 78 | **this report (pre-assigned)** | ✅ |
| 5 | `app/Models/TimetableSnapshot.php` | model | 40 | **this report (pre-assigned)** | ✅ |
| 6 | `app/Models/SnapshotTimetable.php` | model | 57 | **this report (pre-assigned)** | ✅ |
| 7 | `app/Policies/TimetablePolicy.php` | policy | 44 | **this report (claimed this audit, §5)** | ✅ — unreachable, TBL-04 |
| 8 | `resources/views/timetable/create.blade.php` | create page | 145 | this report | ✅ |
| 9 | `resources/views/timetable/show.blade.php` | show page | 490 | this report | ✅ — TBL-18, TBL-19 |
| 10 | `resources/views/timetable/edit.blade.php` | edit page | **MISSING** | this report | ❌ does not exist — TBL-10 |
| 11 | `resources/views/timetable/index.blade.php` | tab list | 47 | this report | ✅ orphan — TBL-13 |
| 12 | `resources/views/timetable/trash.blade.php` | trash page | orph. | this report | ✅ orphan — TBL-13 |
| 13 | `resources/views/timetable/preview.blade.php` | preview page | orph. | this report | ✅ orphan — TBL-13 |
| 14 | `routes/web.php:141-145` | route lines | — | this report | ✅ — TBL-10 |
| — | `PeriodSet` model | TimetableFoundation | — | [↗ PeriodSetController](../PeriodSetController-done/01-report.md) | linked; usage in create/edit/show checked |
| — | `TimetableType` model | TimetableFoundation | — | [↗ TimetableTypeController](../TimetableTypeController-done/01-report.md) | linked; usage checked |
| — | `SchoolDay` model | TimetableFoundation | — | [↗ SchoolDayController](../SchoolDayController-done/01-report.md) | linked; usage in show checked |
| — | `Activity` model | TimetableFoundation | — | [↗ ActivityController](../ActivityController-done/01-report.md) | linked; eager-load shape checked |
| — | `OrganizationAcademicSession` | SchoolSetup | — | common (§4.2) | usage checked; validation table-name bug is TBL-05 |
| — | `x-backend.layouts.app`, `breadcrum`, `status-switch`, `button-submit` | shared components | — | common | props checked against constructors only |

**Pre-applied 2026-10-10:** the `routes/web.php` row in `../PRE-APPLIED-2026-10-10.md` covers this controller's route lines — the dead `trashed / restore / forceDelete / toggleStatus` routes were removed that day. Confirmed: the uncached `route:list` shows only the 7 resource routes; the stale candidates in `scan.php`'s `routes.json` (RTE-02 for those four) are refuted by the live table. The controller itself is **not** in the pre-applied list; this audit reviewed it fresh.

## 4. Routes

```
GET|HEAD  timetable-foundation/timetable          timetable-foundation.timetable.index   index
POST      timetable-foundation/timetable          timetable-foundation.timetable.store   store
GET|HEAD  timetable-foundation/timetable/create   timetable-foundation.timetable.create  create
GET|HEAD  timetable-foundation/timetable/{timetable}     timetable-foundation.timetable.show    show
PUT|PATCH timetable-foundation/timetable/{timetable}     timetable-foundation.timetable.update  update
DELETE    timetable-foundation/timetable/{timetable}     timetable-foundation.timetable.destroy destroy
GET|HEAD  timetable-foundation/timetable/{timetable}/edit timetable-foundation.timetable.edit   edit
```

Middleware on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified` (verified via `route:list -v`).
Route parameters `{timetable}` bind 1:1 to `Timetable $timetable` arguments (reflection check — no unbound model, §3.3.1 clean).
**Unrouted public methods:** none — all 7 methods are routed. No state change over GET (the pre-applied pass removed the GET `restore`).

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect) | — |
| create | ✅ | create | — | — | — | — |
| store | ✅ | create (inside try) | ✅ closure | `Stored` (after write, in tx) | tt_timetables, sys_activity_logs (intended) | TBL-01, 05, 06, 07, 09, 22 |
| show | ✅ | view | — | — | — | TBL-17, 18, 19 |
| edit | ✅ | update | — | — | — | TBL-10 |
| update | ✅ | update | ✅ closure | `Updated` (after write, in tx) | tt_timetables, sys_activity_logs | TBL-01, 02, 03, 08, 09 |
| destroy | ✅ | delete | ✅ closure | `Trashed` (after write, in tx) | tt_timetables, sys_activity_logs | TBL-01, 03, 21 |

**Tables each mutation SHOULD touch:** store/update/destroy should write the timetable row plus the log (they do). `destroy` should also account for the timetable's children before soft-deleting — 29,784 live cells per timetable and 7 snapshot-link rows on this tenant (TBL-21). `store` should write every column the schema demands: `academic_term_id` is missing from the form entirely (TBL-07). **Mutations live in the controller** — no service is called, so the transaction audit is complete here.

## 6. Findings

### F4 — Validation and input
#### TBL-05 · B · VAL / DDL — store's session-exists rule names a table that does not exist, so every create dies
**Where:** `TimetableController.php:75` (validation block `:57-82`)
```php
'academic_session_id' => 'required|exists:sch_organization_academic_sessions,id',
```
**Evidence:**
```
SHOW TABLES LIKE "%academic_session%"  →  sch_org_academic_sessions_jnt, std_student_academic_sessions
SHOW COLUMNS FROM sch_organization_academic_sessions → 1146 Table '…sch_organization_academic_sessions' doesn't exist
tinker: Validator::make(["academic_session_id"=>7], ["…"=>"exists:sch_organization_academic_sessions,id"])->validate()
  → Illuminate\Database\QueryException  SQLSTATE[42S02] 1146 Table doesn't exist
```
The OrganizationAcademicSession model (the dropdown in `create()`/`edit()`) reads the real table `sch_org_academic_sessions_jnt`; only the string in the rule is wrong. The controller's `\Throwable` catch turns the QueryException into `back()->with('error', 'The operation could not be completed.')`.
**Consequence:** every attempt to create a timetable fails silently with a generic message — the create feature is dead for every user, and the error text hides what is wrong.

#### TBL-07 · B · VAL-03 / DDL (BUG-003b) — `academic_term_id` is NOT NULL, but the rule is `nullable` and the form has no such field
**Where:** `TimetableController.php:76` · `create.blade.php` (no term control anywhere) · live schema
```php
'academic_term_id' => 'nullable|exists:sch_academic_term,id',   // column: academic_term_id int unsigned Null=NO Default=NULL
```
**Evidence:** `SHOW COLUMNS FROM tt_timetables` → `academic_term_id Null=NO Default=NULL`; `sql_mode` includes `STRICT_TRANS_TABLES`; `grep -n "academic_term" create.blade.php` → 0 hits; `Timetable::$fillable` includes `academic_term_id` (so an absent value is simply omitted from the INSERT).
**Consequence:** once TBL-05 is fixed, every create submit still raises SQL 1364 (field has no default) and the user gets the generic failure — the create path needs a Term selection and a `required` rule to survive. (`effective_from` has the same NOT-NULL×nullable shape, line 79, but the browser marks it required so it is usually sent.)

#### TBL-08 · H · VAL-05 / CTL-05 — update()'s inline rules drifted from store()'s: `max:255` over a VARCHAR(200), and no uniqueness check
**Where:** `TimetableController.php:207` (update) vs `:63-72` (store)
```php
// store
'name' => ['required','string','max:200', Rule::unique('tt_timetables','name')->where(term/type/whereNull deleted_at)],
// update
'name' => 'required|string|max:255',
```
**Evidence:** `SHOW COLUMNS FROM tt_timetables` → `name varchar(200) Null=NO`; the unique index `uq_tt_name_term_type` is on `(name_live, academic_term_id, timetable_type_id)`; `grep -n "'name'" TimetableController.php` shows the two rules.
**Consequence:** a 201–255-character name passes update validation and raises SQL 1406, and two timetables can be renamed to the same name in one term+type because update never enforces the unique contract that the seed rule describes.

#### TBL-09 · M · VAL-02 — validation is inline `$request->validate()`, not a FormRequest
**Where:** `TimetableController.php:57, 206`
**Evidence:** `grep -nE 'validate\(\[' $C` → 2 hits; no `use …Request` import (imports list, §4.1 #3).
**Consequence:** no `authorize()`/`after()` hook, and the two copies of the rules are already drifting apart (TBL-08); a FormRequest is the single home for them.

#### TBL-06 · L · CTL-10 — store() assigns a `uuid` that the table has never had; Eloquent silently drops it
**Where:** `TimetableController.php:84`
```php
$validated['uuid'] = (string) Str::uuid();
```
**Evidence:** `SHOW COLUMNS FROM tt_timetables` → no `uuid`; `grep -n uuid Timetable_DDL_v7.8.sql` → none; tinker `$m->fill(["name"=>"x","uuid"=>Str::uuid()])` → `uuid attribute retained: 'NOT SET'` (not in `$fillable`, so `create()` discards it — no SQL error). `grep -rn "->uuid" Modules/*Timetable*/app` finds no reader of a timetable uuid.
**Consequence:** the assignment is pure dead code — it neither crashes nor stores anything, and it signals an identifier intent the schema does not support.

### F5 — Routes
#### TBL-10 · H · RTE-02 / CTL — the edit route exists, but the view it renders does not, so GET …/edit 500s
**Where:** `TimetableController.php:189` · `routes/web.php:141` (`Route::resource`)
```php
return view('timetablefoundation::timetable.edit', [ … ]);
```
**Evidence:** `view()->exists('timetablefoundation::timetable.edit')` → `bool(false)`; `find … -name "edit*.blade.php"` in the module has no `timetable/edit.blade.php`; `route:list` shows `GET|HEAD timetable-foundation/timetable/{timetable}/edit`; `grep -rn "timetable-foundation.timetable.edit" Modules resources` → only the controller line (= no app UI links today, but the URL is routable).
**Consequence:** an admin who hits the standard edit URL (or a future link) gets a 500, and `update()` has no form anywhere, so it is unreachable from the UI too.

### F1 — Errors
#### TBL-01 · M · ERR-00 (D1) + ERR-05 — three mutations still catch `\Throwable` themselves and log only the message
**Where:** `TimetableController.php:102-108` (store) · `:229-237` (update) · `:269-277` (destroy)
```php
} catch (\Throwable $e) {
    Log::error('TimetableController::store failed', ['error' => $e->getMessage()]);
    return back()->with('error', 'The operation could not be completed.');
}
```
**Evidence:** `grep -n "catch (\Throwable" $C` → 3; each catch logs `['error' => $e->getMessage()]` only (ARGV: no `$e` object → the trace is lost, ERR-05). These are not a D2 shape (no DomainException/truncate/SnapshotProtection path here).
**Consequence:** failures lose their stack trace, and the central handler in `bootstrap/app.php` never gets to render the friendly page/JSON it owns; note that TBL-02's swallowed 422 lives inside this same shape.

#### TBL-02 · H · ERR-02 — update() swallows ValidationException: field errors never reach the form
**Where:** `TimetableController.php:204-237`
```php
try {
    return DB::transaction(function () use ($request, $timetable) {
        $validated = $request->validate([ … ]);
```
**Evidence:** `$request->validate()` runs inside the `try`; the catch chain is `catch (ModelNotFoundException …) { throw }` then `catch (\Throwable …)` — `ValidationException` extends `Exception`, so it hits the generic catch and `back()->with('error', …)` without `withErrors`.
**Consequence:** a user who submits an invalid name/date gets the generic "could not be completed" and no field-level error, and the 422 contract of the validation API is turned into a redirect.

### F2 — Transactions and audit
#### TBL-03 · L · TXN-05 — update() and destroy() build the redirect + flash inside the transaction closure
**Where:** `TimetableController.php:224-226, 264-266`
**Consequence:** the success flash is stored on the session before the commit; if the commit fails, the next page shows "updated successfully" for a row that was not updated. (Lowered from M: same shape as ATC-12, flash-only harm.)
Clean checks: every mutation uses the closure form, `activityLog` sits after the write inside the transaction (A2/A3 ✅), the PUBLISHED blocked path writes no log ✅, and no irreversible side effect sits in any transaction (TXN-03 ✅).

### F3 — Authorization
#### TBL-04 · L · AUTH-06 / dead policy — TimetablePolicy is registered but every gate passes a string, so it is never consulted
**Where:** `TimetablePolicy.php:10-43` · `TimetableFoundationServiceProvider.php:140`
**Evidence:** `Gate::policy(Timetable::class, TimetablePolicy::class)` is registered; all seven controller gates call `Gate::authorize('tenant.timetable-foundation.timetable.*')` — a permission string, never a `Timetable` instance — so no policy method fires. All seven 4-part names exist and are seeded exactly (`SELECT id,name FROM sys_permissions WHERE name LIKE '%timetable-foundation.timetable.%'` → ids 1459–1465).
**Consequence:** the policy looks active and is dead (module-wide pattern, see §7); every method is still authorised, so the risk is only dead-code confusion. AUTH-01 ✅ on all 7 methods.

### F6 — Controller shape
#### TBL-11 · L · CTL-04 — no return types on any public method
**Where:** `TimetableController.php:28,38,52,114,185,200,243`
**Consequence:** maintenance debt; the fixer adds `: RedirectResponse` / `: View` etc.

#### TBL-13 · L · CTL-10 — three orphan blades under `views/timetable/`
**Where:** `index.blade.php` (47 lines, renders `$schoolDays` the controller never passes), `trash.blade.php`, `preview.blade.php` (52,481 bytes)
**Evidence:** `grep -rn "timetablefoundation::timetable.preview\|…trash\|…index" Modules --include=*.php --include=*.blade.php` → 0 rendering references; `index()` redirects to the menu, and no trash/restore routes exist (removed 2026-10-10).
**Consequence:** dead markup that can drift from the real UI; `index.blade.php` is a stale copy of the SchoolDay list (proves it is from another resource).

### F7 — Models
#### TBL-15 · H · MDL-03 — TimetableCell::teachers() reads a soft-delete pivot without wherePivotNull
**Where:** `TimetableCell.php:84-93`
```php
return $this->belongsToMany(Teacher::class, 'tt_timetable_cell_teachers', 'cell_id', 'teacher_id')
    ->withPivot('assignment_role_id', 'is_substitute')->withTimestamps();
```
**Evidence:** `TimetableCellTeacher` uses `SoftDeletes` (`$table = 'tt_timetable_cell_teachers'`), and `grep -rn "wherePivotNull" Modules/TimetableFoundation Modules/SmartTimetable` → 0 hits on this relation.
**Consequence:** a cell whose teacher row was soft-deleted still reports that teacher as assigned (used by the substitution/manual-placement surfaces that load `teachers`); this controller never loads `teachers`, so the blast radius is in the linked consumers.

#### TBL-14 · L · MDL / app-disagrees-with-its-schema — dead members on TimetableCell query missing columns and statuses
**Where:** `TimetableCell.php:176-182` (`scopeActive`: `where('status','ACTIVE')`), `:201-209` (`scopeForClass`: `where('class_id',…)`/`where('section_id',…)`), `:150-153` (`dayByOrder`: binds `day_of_week` → `tt_school_days.order`), `:222-234` (`getTimeSlotAttribute`: dead `?? 'N/A'`)
**Evidence:** `tt_timetable_cells` has no `class_id`/`section_id`; `tt_school_days` has `ordinal`, not `order`; the `status` enum is `('ARCHIVED','DRAFT','GENERATED','GENERATING','PUBLISHED')` — no `ACTIVE`; `grep -rn "forClass\|dayByOrder\|->scopeActive" Modules --include=*.php` outside the model finds no callers.
**Consequence:** dead scope plumbing that raises SQL 1054/1054 if any future caller uses it — same family the model's own comment warns about for the removed relationships.

#### TBL-16 · L · MDL-04 / STY — untyped relations on the pivot model; missing int casts on Timetable
**Where:** `TimetableCellTeacher.php:43,48,53` (`cell`, `teacher`, `assignmentRole` have no return type); `Timetable.php` `$casts` lacks `published_by`, `created_by`, `parent_timetable_id`, `generation_strategy_id`
**Consequence:** consistency debt only.

Clean checks: Timetable/TimetableCell/TimetableCellTeacher/TimetableSnapshot/SnapshotTimetable all declare `$fillable` (MDL-01 ✅), sensible `$casts` including booleans/dates/JSON ✅, `$table` exists in migrations and live (MDL-07 ✅, `tt_snapshots`/`tt_snapshot_timetables` confirmed), `SoftDeletes` ↔ `deleted_at` agree ✅, and no Spatie media anywhere (MDL-05/TEN-01 ✅). Timetable's `booted()` snapshot/`saving` hooks are coherent with the storage service and `archiveOthersInScope()` uses a deliberate query-builder update.

### F9 — Queries and performance
#### TBL-17 · M · QRY-02/15 — show() loads every cell of the timetable (≈30k rows) with four eager relations on each GET
**Where:** `TimetableController.php:138-140, 122`
```php
$cells = TimetableCell::where('timetable_id', $selectedTimetableId)
    ->with(['activity.subject','activity.class','activity.section','activity.studyFormat'])->get();
$allTimetables = Timetable::orderByDesc('created_at')->get(['id','name','code','status']);
```
**Evidence:** tenant probe — `tt_timetable_cells` per timetable: `tt=3 cells=29784 withAct=2227` (total 148,856). No pagination (QRY-02), whole relation loaded on a read path; the second query pulls every timetable row (QRY-15, columns restricted).
**Consequence:** each visit to the single most detailed screen moves ~30,000 rows with 4 eager joins; fine on this demo tenant, a serious latency trap on a large school, and it is currently pointless because TBL-18 renders nothing from them.

### F10 — Views
#### TBL-18 · H · VIEW-02 / deep read — the grid and the blade disagree on the period key, so the weekly grid is always empty
**Where:** controller `TimetableController.php:146` vs `show.blade.php:324, 439`
```php
// controller builds        // blade reads
$timetableGrid[$cell->day_of_week][$cell->period_ord] = …;
$cellData = $timetableGrid[$day->id][$period->id] ?? null;
```
**Evidence:** tenant probe — `tt_period_set_periods_jnt` for set 3 (the set of all 7 live timetables): `id=15 ord=1`, `id=16 ord=2`, … `id=23 ord=9`. The controller keys by `period_ord` (1–9), the blade looks up `$period->id` (15–23), so every lookup falls into `?? null`. Cells with activities: 2,227 per timetable. (`$day->id` happens to equal `day_of_week` 1–7 through the `day()` relation, so the day key matches; the period key never does.)
**Consequence:** the Weekly Timetable grid and Detailed Schedule list render "No Scheduled Classes" on every timetable that demonstrably has 2,227 scheduled classes — the feature's main screen shows nothing.

#### TBL-19 · M · VIEW / deep read — the summary numbers lie: Periods/Week counts empty cells, and the Hard Violations card reads a column that does not exist
**Where:** `show.blade.php:297` (`{{ $totalPeriods }} classes`), `:114` (`Periods / Week`), `:190` (`{{ $timetable->hard_violations ?? 0 }}`)
**Evidence:** the controller sets `$totalPeriods = $cells->count()` (29,784 per timetable, of which only 2,227 have an activity); `SHOW COLUMNS FROM tt_timetables` has no `hard_violations` (the column is `constraint_violations`) and the model has no accessor for it.
**Consequence:** "Periods / Week" shows ~29,784 for a school with ~54 real periods, the Workload Summary is therefore meaningless, and the Hard Violations card is a permanent 0 even when `constraint_violations` is non-zero — none of it errors, all of it lies.

Clean checks: no queries in create/show blades (VIEW-01 ✅); relations used in loops are eager-loaded by the controller (show) ✅; no `{!! !!}` on user text ✅; blades compile (the module's only in-scope parse failure is the orphan `preview.blade.php` flagged by scan.php — an orphan, reported not fixed).

### F12 — Style
#### TBL-20 · L · STY-01/STY-04 — `strict_types` missing everywhere; emoji/commented directive noise in the models
**Where:** controller `:1` plus all five models and the policy (SN `scan.php` findings: STY-01 on TimetableController, Timetable, TimetableCell, TimetableCellTeacher, TimetableSnapshot, SnapshotTimetable, TimetablePolicy; STY-04 ⚠-block emoji comments in Timetable.php:426-448 and TimetableCell.php:52-142).
**Consequence:** style debt only; grouped one item per file in the plan.

### F13 — Deep read
#### TBL-21 · M · deep read — destroy() soft-deletes a timetable while ~30k live cells and snapshot links still reference it, and no restore UI exists
**Where:** `TimetableController.php:248-266`
**Evidence:** tenant probe — each non-draft timetable has 29,784 cells and a `tt_snapshot_timetables` link (7 rows total); `routes/web.php` comment: trash/restore routes were removed 2026-10-10 because the methods did not exist.
**Consequence:** a deliberately deleted GENERATED timetable hides from every list while its 29,784 cells keep pointing at a trashed parent, and nothing in the UI can bring it back — the `PUBLISHED` guard protects the live one, but there is no guard for "in use" and no restore path.

#### TBL-22 · M · deep read — the create form's Generation Method and Active switches are ignored by store()
**Where:** `create.blade.php:123-130` (`generation_method` select) · `TimetableController.php:57-82` (no `generation_method` rule) · `Timetable.php:93-95` (saving hook forces `is_active = status === 'PUBLISHED'`) · store `:86`
**Evidence:** `grep -n "generation_method" TimetableController.php` → 1 (comment only, no rule); tinker `Timetable` default `generation_method=MANUAL`; a created DRAFT always gets `is_active=false` regardless of the form's `status-switch` (defaults `true`).
**Consequence:** MANUAL/SEMI_AUTO/FULL_AUTO never records the user's choice (every create is MANUAL), and the Active toggle on the form is a lie — the same family as the catalogue's "a control that lies about what it does".

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **Unreachable policies (module-wide).** Every policy in the module, including `TimetablePolicy`, is registered then never consulted because gates pass permission strings. Same decision as AcademicTerm ATC-14; the fix (gate via policy or drop the registration) is module-wide, not this controller's.
- **`scan.php` stale-route candidates.** Its `routes.json` still contains `trash/view`, `force-delete`, `restore`, `toggle-status` routes for this controller (scanned as RTE-02 B). The uncached `route:list` proves all four are gone (removed 2026-10-10); the candidates are refuted, not confirmed.
- **Orphan `_partials` and `preview.blade.php`:** `_activities-summary`, `_scripts`, `_style` partials exist under `views/timetable/_partials/` — grep found no renderer; reported with the orphan family, not fixed here.
- **RouteAuthenticationTest:** `timetable-foundation.timetable.create` and `.index` appear in the module's route-auth test. The team verifies test expectations after the TBL-01/02 shape changes (D4).

## 8. What this audit did not cover, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static or a read-only SQL probe.
- **Other writers of `tt_timetables`:** `ManualTimetableService`, `StandardTimetableController`, `TimetableStorageService` and `SnapshotWriter` were not audited; only the Timetable model (shared) was. `uuid` absent from all of them corroborates TBL-06.
- **The `tt_timetable_cells` data itself** (29,784 rows per timetable) is a generation-run artefact, not this controller's output; the QRY and display findings quote it as evidence, they do not repair it.
- **Seeding of `tt_*` master tables** (days, periods, period sets) — owned by their own controllers' reports.