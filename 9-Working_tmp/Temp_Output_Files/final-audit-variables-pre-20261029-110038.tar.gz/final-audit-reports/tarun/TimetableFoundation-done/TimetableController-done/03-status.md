# 03 — Status · TimetableFoundation / TimetableController

**Fixed:** 2026-10-14 · **By:** opencode / claude (fix) · **Plan:** `02-fix-plan.md` (26 items ticked + 3 found during fixing)

## 1. Pre-applied 2026-10-10

None. No file of this controller's scope is listed in `PRE-APPLIED-2026-10-10.md`.

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| TBL-05 | `Http/Requests/TimetableRequest.php` | `academic_session_id` now `exists:sch_org_academic_sessions_jnt,id` — the table the dropdown reads. The old rule named a table that does not exist, so every create raised SQL 42S02. | replay §6 | store 302, row created | 2026-10-14 |
| TBL-07 (a) | `TimetableRequest.php`, `TimetableController::create()`, `create.blade.php` | "Academic Term *" select added before Timetable Type (options `term_name (term_code)`). Rule `required` + `Rule::exists('sch_academic_term','id')` scoped to the chosen session and `whereNull('deleted_at')`, with its own message. | replay §6 | mismatch → "The selected term does not belong to the selected academic session." | 2026-10-14 |
| TBL-18 | `show.blade.php` grid + detailed list | Both read `$timetableGrid[$day->day_of_week][$period->period_ord]` (was `[$period->id]`, which never matched). | replay §6 | grid renders filled cells | 2026-10-14 |
| TBL-08 | `TimetableRequest.php` (PUT rules) | Update uses the same name rule as store: `max:200` + `Rule::unique` scoped to term/type, `whereNull('deleted_at')`, ignoring its own id. | replay §6 | 201-char name → max:200 error | 2026-10-14 |
| TBL-10 (a) | `TimetableController::edit()` | Gate first, then `abort(403, 'Timetables cannot be edited from this screen.')`. Return type `never`. | replay §6 | GET edit → 403 | 2026-10-14 |
| TBL-01/02/03 | `store`, `update`, `destroy` | D1 shape. No `catch (\Throwable)`; each write runs in one `DB::transaction`; `activityLog` after the write, inside it ('Stored' / 'Updated' / 'Trashed'). Validation now comes from the FormRequest, so a 422 reaches the form again. Redirect + flash are built after the closure. Only catch left: `\DomainException` in `destroy` (D2). | `grep -n "Throwable\|Log::" <controller>` | no output | 2026-10-14 |
| TBL-09 | new `Http/Requests/TimetableRequest.php` | Rules moved out of the controller; `authorize()` = `authorizeByCrudPermission('tenant.timetable-foundation.timetable')`; both methods use `validated()`. `is_active` deliberately not accepted (the model's saving hook mirrors status). | `class_exists` | true | 2026-10-14 |
| TBL-06 | `store()` | The `uuid` assignment removed (no column). | `grep -n uuid <controller>` | no output | 2026-10-14 |
| TBL-15 ⚠ SHARED | `Models/TimetableCell.php` `teachers()` | `->wherePivotNull('deleted_at')` added. | read; replay | 4,559 live pivots, 0 trashed | 2026-10-14 |
| TBL-14 ⚠ SHARED | `TimetableCell.php` | Removed `dayByOrder()` and `scopeForClass()` (bound non-existent columns; 0 callers re-proven). `scopeActive()` = `status = 'GENERATED'` only. `getTimeSlotAttribute()` rewritten (see §8). | grep callers | 0 | 2026-10-14 |
| TBL-16 ⚠ SHARED | `TimetableCellTeacher.php`, `Timetable.php` | `: BelongsTo` on `cell`/`teacher`/`assignmentRole`; integer casts for `published_by`, `created_by`, `parent_timetable_id`, `generation_strategy_id`. Pint then dropped two unused imports in `TimetableCellTeacher` (`HasFactory`, a same-namespace `TeacherAssignmentRole`). | relation sweep | 529 calls, 0 errors | 2026-10-14 |
| TBL-17 (a) | — | Deferred as accepted debt. TBL-18b below already cuts the read from ~30k cells to one class's week. | — | — | 2026-10-14 |
| TBL-19 | `show()` + `show.blade.php:190` | Periods/Week and the "classes" badge count filled slots of the selected class, not raw cells; Hard Violations reads `constraint_violations`. | replay §6 | figures match the witness (§6) | 2026-10-14 |
| TBL-13 | `views/timetable/{index,trash,preview}.blade.php` | Deleted after re-proving 0 references to `timetablefoundation::timetable.{index,trash,preview}`. Backups in `/tmp/TBL-orphans/`. | `grep -rn` | 0 hits | 2026-10-14 |
| TBL-20a | controller | `declare(strict_types=1)`, return types on all 7 public methods. | `php -l`, `class_exists` | ok | 2026-10-14 |
| TBL-20b–g ⚠ SHARED | `Timetable.php`, `TimetableCell.php`, `TimetableCellTeacher.php`, `TimetableSnapshot.php`, `SnapshotTimetable.php`, `TimetablePolicy.php` | `declare(strict_types=1)`; emoji markers stripped from the two model comment blocks. | `diff` vs backup | strict line only on the three small files | 2026-10-14 |
| TBL-21 (a) | `destroy()` | Refuses (`\DomainException`, D2) while the timetable is PUBLISHED (original message kept) or used by `tt_timetable_assignment` rows / child timetables — the message names both counts. | replay §6 | PUBLISHED and in-use both refused, row kept | 2026-10-14 |
| TBL-22 (a) | `TimetableRequest.php`, `store()`, `create.blade.php` | `generation_method` validated `in:MANUAL,SEMI_AUTO,FULL_AUTO` and stored (default MANUAL). The misleading Active switch is replaced by an info note: new timetables start as a draft and become active when published. | replay §6 | stored `SEMI_AUTO`, `DRAFT`, `is_active=false` | 2026-10-14 |
| TBL-04 (a) | — | Deferred to the module-wide policy pass. | — | — | 2026-10-14 |
| TBL-RTE | `routes/web.php` | Removed the 4 custom routes (trash/view, restore, force-delete, toggle-status) that named methods that never existed; 3-line comment explains. Only generated baselines still mention the names (see §4). | uncached `route:list` | 7 routes, all methods exist | 2026-10-14 |
| TBL-23 (new) | `TimetableController::create()` | `OrganizationAcademicSession` and `PeriodSet` have no `ordered()` scope, so the create page returned **500 for every user** (pre-existing; the original `create()` already called it; missed by the audit). Ordered in the controller: `orderByDesc('start_date')` and `orderBy('name')` (the estate's most common forms). No shared model touched. | replay §6 | GET create → 200 | 2026-10-14 |
| TBL-18b (new, approved) | `show()` + `show.blade.php` | The grid has one box per day×period but ~620 class-group cells per slot, so after TBL-18 46 of 48 boxes read "N/A" (last cell wins, usually empty). Approved: **add a class picker**. A Class-Section select sits in the existing GET form; each option shows its cell count. Cells are filtered through `activity.class_id/section_id` — the same rule as `StandardTimetableController::classView()`. Parallel cells in one slot show the first plus a "+N more" badge. | replay §6 | class 5: 25 filled boxes = SQL witness 25; 0 "N/A" | 2026-10-14 |

## 3. Not applied

Nothing ticked was skipped. TBL-17 and TBL-04 were deferred by your decision (a).

## 4. Needs Tarun's hand

- **Browser check of the create form** (`/timetable-foundation/timetable/create`): the Term select, the draft note, and a save with Generation Method = Semi-Auto.
- **Browser check of the show page**: switch the Class-Section picker and confirm the grid shows that class's week.
- **No migration, seeder or permission sync is needed.**
- **No Dusk suite drives this controller** (grep of `tests/` and `prime_testing/tests`: the two hits were other controllers' names containing "TimetableController"), so no suite needs updating.
- Generated baselines `tests/Unit/Architecture/missing-controller-methods.txt` and `breadcrumb-baseline.json` still list the removed routes. They are regenerated by their own scripts; not hand-edited.

## 5. Unverifiable by this workflow (D4)

- **Permission refusals** (create/update/delete/edit as a role without the ability) — the replay runs as user 1 (super-admin, `Gate::before`).
- **The "+N more" badge** — no class-section on this tenant has two cells in one slot (the multi-cell slots belong to shared lessons with no section), so the badge renders nowhere today. Verified by reading only.
- **Shared lessons on the show page** — 540 cells whose activity has no class/section are not shown under any class, exactly as on the StandardTimetable class view. Recorded, not changed.
- The grid uses the timetable's period set; a class on a different period set would show its own lessons in those columns only. StandardTimetable resolves a per-class set through a private method of its own controller, which this module cannot call.

## 6. Verification log

```
php -l: controller, request, 5 models, policy, routes         -> no syntax errors (re-run after Pint)
vendor/bin/pint <8 php files> --format agent                   -> fixed 2 files (imports/spacing), re-linted ok
class_exists: controller, request, 5 models, policy            -> 8 x OK
route:list (uncached) + method_exists                          -> 7 routes, 0 missing
blade compile show + create                                    -> php -l ok; @push 0/0; {{-- --}} 11/11
time_slot accessor                                             -> "8:20 AM - 9:00 AM"
scan.php after (7 in-scope paths)                              -> 5 rows: AUTH-04 x2 (house pattern), ERR-01 (D2,
                                                                  intentional), CTL-02 show() 120 lines, QRY-15 the
                                                                  5-row timetable dropdown — all accepted

kernel replay on test.localhost, user 1, inside DB::beginTransaction / rollBack:
  GET  create                                  -> 200, term select present (2 options), no Active switch, draft note
  POST store (session 7, term 1, SEMI_AUTO)    -> 302, row DRAFT, term 1, SEMI_AUTO, is_active false, log 'Stored'
  POST store same name                         -> 302, "The name has already been taken."
  POST store term from another session         -> 302, "The selected term does not belong to the selected academic session."
  GET  show #4 (default class)                 -> 200, 34 filled boxes, 0 "N/A"
  GET  show #4 ?class_section_id=5             -> 200, 25 filled boxes (SQL witness: 25 distinct slots)
  GET  show #1 (no cells)                      -> 200, empty state
  GET  edit #4                                 -> 403
  DELETE #4 as PUBLISHED                       -> 302, "Cannot delete a published timetable. Please unpublish it first."
  DELETE #4 (ARCHIVED, 1 assignment)           -> 302, "...used by 1 class assignment(s) and 0 timetable(s)...", row kept
  DELETE throwaway                             -> 302, "Timetable was deleted successfully.", trashed, log 'Trashed'
  PUT  #5 name 201 chars                       -> 302, max:200 error
  PUT  #5 valid                                -> 302, "Timetable was updated successfully."
  after rollback                               -> 5 live, 0 probe rows, #4 ARCHIVED, #5 name unchanged
```

## 7. Final state

**FIXED.** Open by decision: TBL-17 (deferred debt), TBL-04 (module-wide). Residual scanner rows above are accepted.

## 8. Incidents during this pass

- **`strict_types` broke the shared `time_slot` accessor.** Adding `declare(strict_types=1)` to `TimetableCell` made `strtotime()` refuse the Carbon-cast `start_time` ("must be of type string, Carbon given"). The accessor is read by the Parent and Student portals and by SmartTimetable. Rewritten to format through `Carbon::parse(...)->format('g:i A')`; same output, verified.
- **`TimetableSnapshot.php` was truncated to 0 bytes** by a Python one-liner that opened the file for writing before reading it. Restored from `/tmp/TBL-TimetableSnapshot.before`, then `strict_types` added; the three small files were diffed against their backups (only the strict line differs).
- **Three unasked changes in my own draft were reverted** before landing: the `deleted` flash key renamed to `trashed`, a changed delete log message, and the grid skipping empty cells. Only the approved changes shipped. (The empty-cell question then came back as TBL-18b and was decided by you.)
- **The audit missed TBL-23** (create page 500) — found by the replay, not by the report.
