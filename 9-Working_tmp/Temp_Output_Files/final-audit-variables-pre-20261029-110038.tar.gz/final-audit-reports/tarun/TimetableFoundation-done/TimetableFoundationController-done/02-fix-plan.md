# Fix Plan — TimetableFoundation / TimetableFoundationController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/TimetableFoundationController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ The split (TFC-01) and the method extractions (TFC-02) are **DECISION** items and are **deferred** by default (D3). Nothing here is applied unless ticked.

## 1. Blockers reachable today
_None._

## 2. Fixes that arm a latent defect (sequenced)
- [ ] **TFC-03** · H · CTL-10/QRY · `TimetableFoundationController.php:978-989, 1013, 1015-1236, 1318-1319` — remove the dead output:
  - Delete `$healthChecks = $this->runPreGenerationChecks();` (`:989`) **and** the `runPreGenerationChecks()` private method (`:1415-2036`, 622 lines).
  - Delete the `$dashboardStats` class-capacity + teacher-load block (`:1015-1236`) and its `compact()` entries (`:1318-1319`).
  - This **must** run before TFC-10: it removes the two `$e->getMessage()` catches at `:1746`/`:2028` that TFC-10 would otherwise edit.
  - ⚠ Confirm on the tenant that no blade reads them (proved: only a comment). Effort: S–M. **DECISION — see §9 TFC-03.**
- [ ] **TFC-19** · M · CTL-06/CTL-10 · `TimetableFoundationController.php:967-1236` — the same block is generation "health"/dashboard **business logic living in the controller**. It is removed with TFC-03; if TFC-03 is deferred, move it into a service instead of leaving it inline. Effort: S (with TFC-03) / M (moved).

## 3. Errors & transactions (F1/F2)
- [ ] **TFC-10** · M · ERR-05/ERR-06 · `TimetableFoundationController.php:4313-4315` — in `sharedSubgroupFitWarnings()`, replace `Log::warning('…', ['error' => $e->getMessage()])` with `report($e)` plus a fixed log line. The read-path swallow stays; only the trace is fixed. (The `:1746`/`:2028` pairs are removed by TFC-03.) Effort: S.
- [ ] **TFC-09** · M · ERR-07/ERR-00(D1) · `TimetableFoundationController.php:3481-3492` — the `reportsAndLogs` optimisation-report `try/catch`. **DECISION — see §9 TFC-09.**
- [ ] **TFC-16** · M · ERR-05 · `ProblemExporter.php:2059-2063` — `catch (\Throwable $e)` around `$this->priorities->persist(...)`: add `report($e)` and change the warning to `'activity priorities could not be saved. The error has been logged.'` ⚠ SHARED — `ProblemExporter` is also called by SmartTimetable's `PythonTimetableController`; the change is message-only. Effort: S.
- [ ] **TFC-17** · M · ERR-05 · `GenerationReadinessReportService.php:123-128` — give the one bare `catch (Throwable)` a variable, `report($e)`, and return `0` (matching the other six catches). Effort: S.
- [ ] **TFC-08** · M · TXN-02 · `TimetableFoundationController.php:3586-3936` — replace the manual `DB::beginTransaction(); … DB::commit();` / `catch { DB::rollBack(); }` with `DB::transaction(function () { … return $counts; })` (D1). Keep the `truncateFrom()` catch at `:3570-3584` **outside** and unchanged (D2 truncate carve-out). Build the redirect after the closure returns. Effort: M.

## 4. Authorization (F3)
- [ ] **TFC-23** · L · AUTH-06 · module-wide — permission string literals repeated in ten methods. **DECISION — see §9 TFC-23.** Not fixable in this controller alone (it is the whole module's pattern); the recommendation is to defer to a module-level constants/Policy pass.

## 5. Validation, routes, models, security (F4/F5/F7/F11)
- [ ] **TFC-14** · M · SEC-03 · `TimetableFoundationController.php:3643` — replace `Room::where('is_active', true)->value('id') ?? 1` with `?? null` (the column contract), so a class-section with no home room stores NULL instead of a hard-coded id that may point at a deleted or wrong room. If a room is genuinely required, throw a `\DomainException` naming the class-section. Effort: S.

_F4/F5/F7 otherwise clean. No FormRequest is required (no request body reaches a model); no route points at a missing method; `generateStep` is already `abort(403)` (D5)._

## 6. Queries & performance (F9)
- [ ] **TFC-04** · H · QRY-01 · `TimetableFoundationController.php:1034, 1454, 1619, 3821, 3844, 4282` — hoist the per-iteration query out of its loop:
  - `:1034` / `:1619` — pre-load the class→period-set map once, key it, drop the `first()` inside the loop (the `:1619` site disappears with TFC-03).
  - `:3821` / `:3844` — pre-load the subgroup ids for `$record->id` once per record instead of `exists()`/`get()` per option.
  - `:4282` — pre-load all flag-pool members once (one `whereIn` over the union of `member_ids`) before the `foreach ($result['pools'])`.
  - `:1454` disappears with TFC-03. Effort: M.
- [ ] **TFC-12** · M · QRY-15/QRY-05 · `TimetableFoundationController.php:510-511, 729, 736, 792, 829` — add `->select([...])` with only the columns the tables render; the two calendar calendars (`tt_working_days` 365 rows, `tt_class_working_days_jnt` 4,620 rows) are the biggest win. **Caching is a DECISION — see §9 TFC-12.** Effort: M.
- [ ] **TFC-13** · M · QRY-07 · `TimetableFoundationController.php:3737-3744, 3844-3850` — replace the per-row `->delete()` loops with one `->whereIn('id', $ids)->update(['deleted_at' => now()])` **and** a single `activityLog` call carrying the batch; if the per-row log event is required, keep the loop and record it as accepted. Effort: S–M.
- [ ] **TFC-18** · M · QRY-05 · `TimetableFoundationController.php:612, 644, 693, 706, 726, 758, 893, 1078, 1793, 2313` — move the `->get()->groupBy()` aggregations into `groupBy` + `selectRaw` where the grouped value is not re-shaped in PHP; leave the ones whose grouping is presentation-only. Effort: M.
- [ ] **TFC-25** · L · QRY-08 · `TimetableFoundationController.php:187-189, 430, 3050` — accepted (small master tables). No change.

## 7. Views (F10)
- [ ] **TFC-05** · H · VIEW-01 · `resources/views/pages/partials/timetable-masters/class-working-days/_list.blade.php:14` — remove the `@php … SchoolClass::where(...)->get() … @endphp` query; pass the collection from `TimetableFoundationController::timetableMasters()`. ⚠ SHARED — this partial is the masters-tab list owned by this report but consumed by the masters page. Effort: S.
- [ ] **TFC-26** · L · CTL-07 · `TimetableFoundationController.php:1298, 2345, 3001, 3494` — replace the 36/23/21/31-name `compact()` with a typed view-model array; TFC-03's dead entries fall out of the same change. Effort: S.

## 8. Style (F12) — one item per file
- [ ] **TFC-20a** · L · STY-01/STY-04 · `TimetableFoundationController.php` — add `declare(strict_types=1)` and strip emoji from comments (43 lines). Effort: S.
- [ ] **TFC-20b** · L · STY-01/STY-04 · the nine pre-assigned services — `declare(strict_types=1)` + emoji removal. ⚠ SHARED files; one item, applied together. Effort: S.
- [ ] **TFC-21** · L · CTL-08 · `TimetableFoundationController.php:158, 411, 595, 2087, 2384, 3037, 2459` — inject `Request` into the six page methods and use it instead of `request()`. Effort: S.
- [ ] **TFC-22** · L · CTL-04 · `TimetableFoundationController.php:78, 3544` — add `: View` and `: RedirectResponse` return types. Effort: S.
- [ ] **TFC-24** · L · CTL-10 · `TimetableFoundationController.php:1182-1184` — delete the no-op `$at->assignmentRole = $at->assignmentRole;` loop (it is inside the TFC-03 dead block, so it goes with TFC-03). **DECISION on the commented block at `:2315-2343` — see §9 TFC-24.** Effort: S.

## 9. Deferred / decisions
- [ ] **TFC-01** · H · DECISION · CTL-01 — split the 4,320-line / 11-method god controller?
      (a) ⭐ **defer to the split pass** (D3) — record as accepted for this workflow; it is the module's biggest structural debt and too large for the fixer pass.
      (b) extract the seven page methods into single-purpose page controllers now (large, changes routes only if names are re-scoped — needs re-approval).
      (c) leave as is, record as accepted.
      ➜ Choice: ____
- [ ] **TFC-02** · H · DECISION · CTL-02 — eight methods over 150 lines (746 / 645 / 622 / 495 / 394 / 315 / 289 / 177).
      (a) ⭐ extract the per-tab **data builders** into the existing services (readiness, slot grid, resource ratio) or new ones, leaving the methods as "call service, return view" — do the read methods first (`timetableRequirement`, `reportsAndLogs`).
      (b) defer to the same pass as TFC-01.
      (c) accept the sizes.
      ➜ Choice: ____
- [ ] **TFC-07** · H · DECISION · CTL-02 (services) — `ProblemExporter::emitOptionBlock` is 279 lines, `optionBlocks` 162, `ConstraintCompiler::teacherFreePeriodPerHalf` 123.
      (a) ⭐ defer to a service-split pass — extract the option-block builder's stages (this is the Python boundary; change it only with the pipeline tests, which this workflow cannot run, D4).
      (b) extract now.
      (c) accept the sizes.
      ➜ Choice: ____
- [ ] **TFC-03** · H · DECISION · CTL-10/QRY — delete the dead ~500-query / ~256 ms computation?
      (a) ⭐ **delete both** (`runPreGenerationChecks()` + the `$dashboardStats` block + their `compact()` entries) — the output is read by no blade; the comment already asks for exactly this.
      (b) keep them behind a debug flag / admin-only toggle so the measurement can be re-run.
      (c) keep both, accept the per-load cost.
      ➜ Choice: ____
- [ ] **TFC-06** · H · DECISION · TXN-06 — two administrators can interleave the school-wide truncate-rebuild.
      (a) ⭐ wrap both `generateClassGroups` and `resetRequirements` in a **single** shared lock (e.g. a DB advisory lock / `Cache::lock` with a tenant-scoped key) so the second waits or is refused with a message.
      (b) add a DB unique guard and let the second fail with the existing D2 message.
      (c) accept (single-admin schools).
      ➜ Choice: ____
- [ ] **TFC-09** · M · DECISION · ERR-07 — the `reportsAndLogs` read catch (`:3481-3492`).
      (a) ⭐ move the try/catch into `SchoolOptimisationReportService` (a service may return a fixed error payload), leaving the controller catch-free per D1.
      (b) keep the controller catch and accept the documented exception.
      (c) remove the catch; let the central handler take the page down if the report fails.
      ➜ Choice: ____
- [ ] **TFC-12** · M · DECISION · caching — the dropdown/settings/master lists are re-queried on every request.
      (a) ⭐ cache the school-wide master lists (`StudyFormat`, `SchoolClass`, `Section`, `Subject`, shifts/period-types) with **tenant-scoped** keys and a short TTL.
      (b) add only `->select()` column narrowing now (TFC-12 above) and defer caching.
      (c) no caching.
      ➜ Choice: ____
- [ ] **TFC-15** · M · DECISION · SVC-04 — the pool-keying rule is duplicated between `sharedSubgroupFitWarnings()` and `ActivityController` STEP 1.5.
      (a) ⭐ extract one shared pooler (a service) both call, so the warning and generation cannot drift.
      (b) leave the duplicate and accept the "keep in step" comment.
      ➜ Choice: ____
- [ ] **TFC-23** · L · DECISION · AUTH-06 — permission strings are literals in ten methods across the module, and every Policy is unreachable because gates pass strings.
      (a) ⭐ defer to a module-wide pass: introduce permission constants (or make the gates use policies) for the whole module at once. ⚠ SHARED — touches every module controller.
      (b) fix only this controller's ten literals now.
      (c) accept.
      ➜ Choice: ____
- [ ] **TFC-11** · M · DECISION · SVC-02 — services built with `new`/`app()` mid-method (`:971, :976, :2163, :2951`).
      (a) ⭐ add a constructor and inject the four services (the rest stay `app(…)` where a per-call resolve is intended).
      (b) leave as is.
      ➜ Choice: ____
- [ ] **TFC-24** · L · DECISION · CTL-10 — the commented teacher-slot-matrix query (`:2315-2343`).
      (a) ⭐ keep it (it carries a restore recipe and its tab is deliberately hidden).
      (b) delete it and the `TeacherAvailabilityDetail` import; record the restore steps in the report instead.
      ➜ Choice: ____

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. Fill every `➜ Choice:` on the ticked DECISION items (TFC-01, 02, 03, 06, 07, 09, 11, 12, 15, 23, 24).
> 3. TFC-01 and TFC-02 are **deferred** unless you pick (b) — the fixer will not touch the file if they are ticked with (a)/(c).
> 4. Run `final-audit-fixer` on `Modules/TimetableFoundation/app/Http/Controllers/TimetableFoundationController.php`.
> 5. ⚠ Items marked SHARED (TFC-16, TFC-20b, TFC-05, TFC-23) need their own explicit tick.
