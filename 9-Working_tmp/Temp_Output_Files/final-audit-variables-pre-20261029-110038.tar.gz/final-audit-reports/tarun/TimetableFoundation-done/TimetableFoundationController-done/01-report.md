# Final Audit — TimetableFoundation / TimetableFoundationController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/TimetableFoundationController.php` (4,320 lines, 11 public methods + 4 private helpers)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`
**ABBR:** `TFC`

## 1. Verdict

**Not production-ready — 0 blockers, 7 HIGH.**

This is the module's god controller: **4,320 lines and 11 public methods**, eight of which are
longer than the rulebook's 150-line HIGH threshold (the largest is 746 lines). It renders the
seven shared menu pages, so a defect here is a defect on the whole module's navigation.

The worst finding is **TFC-03**: on every load of the Timetable Requirement page the controller
runs `runPreGenerationChecks()` (622 lines, ~289 queries / ~256 ms measured in the code's own
comment) **and** builds a `$dashboardStats` teacher-load block (another ~230 lines of queries),
then passes both to a blade that **reads neither**. The page pays for ~500 queries and half a
second of work that produces no output. The code comment already documents this; the audit
confirms it and names the fix.

The write paths are otherwise sound. `generateClassGroups` and `resetRequirements` were hardened
on 2026-10-10 (truncate-then-rebuild, D2 message). Every routed method authorizes. The remaining
HIGH items are size (CTL-01/02), N+1 loops (QRY-01) and one query inside a master-page Blade
(VIEW-01).

Rough effort: **1–1.5 days** for the mechanical fixes; the god-controller split is a separate
deferred project. **11 DECISION items** need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 7 | 12 | 7 | 11 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TFC-09, TFC-10, TFC-16, TFC-17 | F8 Services/Jobs | TFC-07, TFC-11, TFC-15, TFC-16, TFC-17 |
| F2 Transactions/Audit | TFC-06, TFC-08 | F9 Queries/Perf | TFC-03, TFC-04, TFC-12, TFC-13, TFC-18, TFC-25 |
| F3 Authorization | TFC-23 (module-wide) | F10 Views | TFC-05, TFC-26 |
| F4 Validation | clean — see below | F11 Security/Tenancy | TFC-14 |
| F5 Routes | clean — see below | F12 Style | TFC-20, TFC-21, TFC-22, TFC-24 |
| F6 Controller shape | TFC-01, TFC-02, TFC-03, TFC-11, TFC-19, TFC-24 | F13 Deep read | TFC-06, TFC-15 |
| F7 Models | ↗ linked (all models owned elsewhere) | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/TimetableFoundationController.php` | controller | 4320 | **this report** | ✅ whole class |
| 2 | `routes/web.php` lines 46–63 (this controller's block) | routes | — | this report | ✅ |
| 3 | `routes/api.php` | routes | 11 | this report | ✅ — scaffold removed 2026-10-10, 0 routes (proved) |
| 4 | `app/Services/GenerationReadinessReportService.php` | service | 1090 | **this report** | ✅ |
| 5 | `app/Services/TimetableGridService.php` | service | 506 | **this report** | ✅ |
| 6 | `app/Services/OptionalSubjectBreakdownService.php` | service | 198 | **this report** | ✅ |
| 7 | `app/Services/OptionCellResolver.php` | service | 533 | **this report** | ✅ |
| 8 | `app/Services/ResourceRatioService.php` | service | 810 | **this report** | ✅ |
| 9 | `app/Services/AnalyticsService.php` | service | 287 | **this report** | ✅ — not reached by this controller (see §7) |
| 10 | `app/Services/ConstraintCompiler.php` | service | 812 | **this report** | ✅ — not reached by this controller (see §7) |
| 11 | `app/Services/ProblemExporter.php` | service | 2147 | **this report** | ✅ |
| 12 | `app/Services/PublishedTimetable.php` | service | 255 | **this report** | ✅ — not reached by this controller (see §7) |
| 13 | `app/Services/ActivityLockService.php` | service | — | ↗ [ActivityController](../ActivityController-done/01-report.md) | ↗ linked + usage checked |
| 14 | `app/Services/OptionStaffingService.php` | service | — | ↗ [TeacherAvailabilityController](../TeacherAvailabilityController-done/01-report.md) | ↗ linked + usage checked |
| 15 | `app/Services/RequirementTableTruncator.php` | service | — | ↗ [RequirementConsolidationController](../RequirementConsolidationController-done/01-report.md) | ↗ linked + usage checked |
| 16 | `app/Services/SchoolOptimisationReportService.php` | service | — | ↗ [OptimisationReportController](../OptimisationReportController-done/01-report.md) | ↗ linked + usage checked |
| 17 | `app/Services/SlotRequirementGridService.php` | service | — | ↗ [SlotRequirementController](../SlotRequirementController-done/01-report.md) | ↗ linked + usage checked |
| 18 | `app/Services/SubActivityGrouper.php` | service | — | ↗ [ActivityController](../ActivityController-done/01-report.md) | ↗ linked + usage checked |
| 19 | `app/Support/Snapshot/SnapshotContext.php` | support | — | common (module support) | usage checked |
| 20 | `app/Support/Snapshot/SnapshotProtectionException.php` | exception | — | ↗ [TeacherAvailabilityController](../TeacherAvailabilityController-done/01-report.md) | ↗ linked |
| 21 | `resources/views/index.blade.php` | page | 147 | this report | ✅ |
| 22 | `resources/views/pages/timetable-configuration.blade.php` | page | 47 | this report | ✅ |
| 23 | `resources/views/pages/pre-requisites-setup.blade.php` | page | 31 | this report | ✅ |
| 24 | `resources/views/pages/timetable-masters.blade.php` | page | 50 | this report | ✅ |
| 25 | `resources/views/pages/timetable-requirement.blade.php` | page | 226 | this report | ✅ |
| 26 | `resources/views/pages/resource-availability.blade.php` | page | 69 | this report | ✅ |
| 27 | `resources/views/pages/timetable-preparation.blade.php` | page | 23 | this report | ✅ |
| 28 | `resources/views/pages/reports-and-logs.blade.php` | page | 31 | this report | ✅ |
| 29 | `resources/views/pages/partials/**` (8 tab dirs, 71 blades) | tab partials | 71 files | **this report** (many other reports link theirs here) | ✅ walked — see the note below |
| — | `app/Models/**` (~40 imports: SchoolSetup, TimetableFoundation, SmartTimetable) | models | — | ↗ linked to their owning reports | usage only |
| — | `x-backend.*`, `x-tenantcore.*`, layouts, breadcrumbs | shared components | — | common | props checked only |

**Files this report is the declared owner for, because other reports linked them here** (confirmed in `../*/01-report.md`): the masters-page tab lists (`timetable-masters/{shifts,day-types,period-types,teacher-roles,school-days,period-configs,period-sets,timetable-types,working-days,class-working-days}/_list.blade.php`), the configuration tabs (`timetable-configuration/{config,academic-terms,generation-strategy}/_list`), the pre-requisites tabs, the requirement tabs (`generation-strategy`, `class-subject-requirements`, `teacher-availability`, `activities`, `generated-groups`, `requirement-consolidations`, `slot-requirements`, `priority-config`, `pre-generation-checks`), the resource-availability panes, the preparation tabs, and the reports-and-logs tabs. Each was walked for VIEW-01/02/03 and the four-permission surface. One real defect was found (TFC-05); the rest are clean (see F10).

**Pre-applied 2026-10-10:** this controller is listed in `../PRE-APPLIED-2026-10-10.md`. That pass removed the raw exception message from the truncate-then-rebuild paths and commented the `SnapshotProtectionException` branches. Reviewed fresh: the `SnapshotProtectionException` branches are in fact **live** (`:1381`, `:3577`) and are the D2-allowed verbatim shape, so they are **not** findings. The pre-applied `report($e)` at `:3929` and the fixed truncate message at `:3935` are present and accepted.

## 4. Routes

Uncached probe: `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` filtered for `TimetableFoundationController@`:

```
GET|HEAD   timetable-foundation                                     timetable-foundation.index                     index
POST       timetable-foundation/generate-class-groups               timetable-foundation.generateClassGroups       generateClassGroups
GET|HEAD   timetable-foundation/pre-requisites-setup                timetable-foundation.menu.preRequisitesSetup   preRequisitesSetup
GET|HEAD   timetable-foundation/reports-and-logs                    timetable-foundation.menu.reportsAndLogs       reportsAndLogs
GET|HEAD   timetable-foundation/resource-availability               timetable-foundation.menu.resourceAvailability resourceAvailability
GET|HEAD   timetable-foundation/timetable-configuration             timetable-foundation.menu.timetableConfiguration timetableConfiguration
GET|HEAD   timetable-foundation/timetable-masters                   timetable-foundation.menu.timetableMasters     timetableMasters
GET|HEAD   timetable-foundation/timetable-preparation               timetable-foundation.menu.timetablePreparation timetablePreparation
GET|HEAD   timetable-foundation/timetable-requirement               timetable-foundation.menu.timetableRequirement timetableRequirement
DELETE     timetable-foundation/timetable-requirement/reset         timetable-foundation.resetRequirements         resetRequirements
```

10 routes. Middleware: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`.

**Every public method is accounted for:**
- 10 routed (above).
- `generateStep()` (`:1406`) — **unrouted, already D5-compliant**: body is `abort(403, 'Generate All has been retired…')` under a `NOT ROUTED` docblock. The route was removed 2026-10-06 (`routes/web.php:52`). No finding.
- The 4 private helpers (`runPreGenerationChecks`, `paginateCollection`, `upsertRequirementRow`, `sharedSubgroupFitWarnings`) are not routes.

**Stale-scanner hit disproved:** the scanner's four `[B] RTE-02 POST/GET/PUT/DELETE api/v1/timetablefoundations → store/show/update/destroy` rows are from the pre-removal `routes.json`. Live probe: `count=0` routes match `timetablefoundation` under `api/`. `routes/api.php` is an 11-line comment. **Not findings.**

## 5. Per-method table

| Method | Lines | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| index | 48 | ✅ | config.viewAny | — | — | — | — |
| timetableConfiguration | 106 | ✅ | any(config,academic-term).viewAny | — | — | — | TFC-02 |
| preRequisitesSetup | 147 | ✅ | config.viewAny | — | — | — | TFC-02 |
| timetableMasters | 177 | ✅ | config.viewAny | — | — | — | TFC-02, TFC-05, TFC-18 |
| timetableRequirement | 746 | ✅ | config.viewAny | — | — | — | TFC-02, TFC-03, TFC-04, TFC-18 |
| resetRequirements | 37 | ✅ | config.create | — (TRUNCATE; D2) | `RequirementsReset` | (truncates 12 derived tables) | TFC-06 |
| generateStep | 4 | ❌ | — (abort 403) | — | — | — | — (D5 done) |
| resourceAvailability | 289 | ✅ | config.viewAny | — | — | — | TFC-02, TFC-04 |
| timetablePreparation | 644 | ✅ | config.viewAny | — | — | — | TFC-02, TFC-12 |
| reportsAndLogs | 495 | ✅ | config.viewAny | — | — | — | TFC-02, TFC-09, TFC-12 |
| generateClassGroups | 394 | ✅ | config.create | manual begin/commit/rollBack `:3587,3910,3928` | `Stored`/`Updated`/`Trashed` `:3741,3835,3849,3889,3905` | `tt_class_requirement_groups`, `tt_class_requirement_subgroups`, `sys_activity_logs` | TFC-04, TFC-06, TFC-08, TFC-13, TFC-14, TFC-15 |
| runPreGenerationChecks (pvt) | 622 | — | — | — | — | (reads only) | TFC-03, TFC-10 |
| sharedSubgroupFitWarnings (pvt) | 315 | — | — | — | — | (reads only) | TFC-04, TFC-10, TFC-15 |

**Scanner TXN-01 disproved.** The scanner reported `timetablePreparation() makes 6 writes with no transaction`. Verified false: `grep -nE '->(create|save|update|delete|insert)\('` in the method's span (2380–3024) returns **zero**. The six writes all live in `generateClassGroups`/`upsertRequirementRow` (`:3740,3848,3955,3957,3961,3966`), inside the manual transaction. Not a finding.

**Tables each mutation SHOULD touch, before counting:**
- `generateClassGroups` should write: the two requirement tables (`tt_class_requirement_groups` / `tt_class_requirement_subgroups`, soft-delete-aware) **plus** one `sys_activity_logs` row per row touched. It does all three, inside one transaction. Counts today: 539 groups, 123 subgroups, 1341 log rows.
- `resetRequirements` should report the truncated set to `sys_activity_logs`. It does (`RequirementsReset`, actor-scoped).

## 6. Findings

### F6 — Controller shape
#### TFC-01 · H · CTL-01 — god controller: 4,320 lines, 11 public methods
**Where:** `TimetableFoundationController.php:70`
```php
class TimetableFoundationController extends Controller
```
**Evidence:** `wc -l` → `4320`; `grep -nE 'public function'` → 11 public methods. Rulebook CTL-01: over 2,500 lines is **H**. This is the largest controller in the module and the audit brief names it the god controller.
**Consequence:** every one of the seven menu pages shares one 4,320-line class; a change to any page risks every other page, and the file cannot be reviewed end-to-end. **Split is DEFERRED (D3).**
**DECISION** — see plan §9.

#### TFC-02 · H · CTL-02 — eight methods exceed 150 lines (largest 746)
**Where:** `timetableRequirement:591-1336` (746), `timetablePreparation:2380-3024` (645), `runPreGenerationChecks:1415-2036` (622), `reportsAndLogs:3033-3527` (495), `generateClassGroups:3544-3937` (394), `sharedSubgroupFitWarnings:4005-4319` (315), `resourceAvailability:2083-2371` (289), `timetableMasters:407-584` (177). (`preRequisitesSetup` 147 and `timetableConfiguration` 106 are M.)
```php
public function timetableRequirement(): mixed   // 746 lines
```
**Evidence:** `awk` method-span counts against `grep -nE '(public|private) function'`; scanner confirms `CTL-02 … is 746 lines`.
**Consequence:** a 746-line read method is where TFC-03/TFC-04 hide; no reviewer can hold it in view, so defects survive.
**DECISION** — extract the per-tab data builders into services (see plan §9).

#### TFC-11 · M · SVC-02 / CTL-06 — services built with `new`/`app()` mid-method; heavy business logic in the controller
**Where:** `:971` `new GenerationReadinessReportService`, `:976` `new SlotRequirementGridService`, `:2163` `new ResourceRatioService`, `:2951` `new ActivityLockService`, plus `app(...)` at `:618,769,1361,3111,3420,3482,3490,3571,3652`.
```php
$readinessService = new GenerationReadinessReportService;     // :971
$ratioService = new ResourceRatioService;                     // :2163
```
**Evidence:** `grep -nE 'app\(|new [A-Z][A-Za-z]+Service'` → 14 sites; the class has **no `__construct`**.
**Consequence:** dependencies are unmockable and untestable; the class cannot be swapped or wrapped, and the readiness/dashboard/health computation (not a thin "read input, call one service") lives in the controller. (D4: no tests, so this is structure, not a proven failure.)

#### TFC-19 · M · CTL-06 / CTL-10 — the controller computes generation "health" and dashboard statistics itself
**Where:** `:967-1236` — `runPreGenerationChecks()` result, `$dashboardStats` class-capacity loop (`:1030-1044`) and a 96-line teacher-load loop (`:1110-1203`).
**Evidence:** `grep -nE 'foreach \(\$(allActs|classSections)'`; the computation is ~230 lines of controller business logic.
**Consequence:** the rulebook's "controller reads input, calls one service, returns a response" is reversed here; the analysis is welded to the render path. Part of the same dead output as TFC-03.

### F9 — Queries and performance
#### TFC-03 · H · CTL-10 / QRY — dead work: ~500 queries and ~256 ms on every Requirement-page load, read by nobody  ⟵ **worst finding**
**Where:** `:978-989` (the comment + call), `:1013`, `:1015-1236` (`$dashboardStats`), passed to the view at `:1318-1319`.
```php
// :983-989
// Measured cost of still calling this: 256 ms and 289 queries on EVERY load of
// this nine-tab page, producing output nobody reads. ...
$healthChecks = $this->runPreGenerationChecks();
```
Blade proof — `pre-generation-checks/_list.blade.php:20`:
```
⚠ The old $healthChecks / $dashboardStats variables are no longer read here.
```
**Evidence:** `grep -rln 'healthChecks\|dashboardStats' resources/views/` → only the above comment line; **no** `$healthChecks`/`$dashboardStats` interpolation anywhere in `pages/`. `runPreGenerationChecks()` is 622 lines and runs ~289 queries per its own measured comment; `$dashboardStats` adds the 230-line teacher-load loop.
**Consequence:** the busiest page in the module does half a second and ~500 queries of work whose result no template prints — a pure latency tax on every administrator's load, and dead code that will be maintained forever.
**DECISION** — remove both, or keep as a hidden debug switch (see plan §9).

#### TFC-04 · H · QRY-01 — queries inside loops (N+1)
**Where:**
- `:1034` inside `foreach ($allActs->groupBy(...))` — `ClassTimetableType::with('periodSet')->where('class_id', …)->…->first()` per class-section.
- `:1454` inside `foreach ($periodSets)` — `PeriodSetPeriod::where(...)->count()` (in `runPreGenerationChecks`, dead per TFC-03).
- `:1619` inside `foreach ($activitiesByClass)` — `ClassTimetableType::…->first()` (same dead method).
- `:3821` inside `foreach ($chosenOptions)` — `ClassSubjectSubgroup::where($match)->exists()` per option.
- `:3844` inside `foreach ($classGroupJnts)` — `ClassSubjectSubgroup::where('class_group_id', …)->get()` per requirement row.
- `:4282` inside `foreach ($result['pools'])` — `DB::table('tt_class_requirement_subgroups')->whereIn(...)->get()` per pool.
```php
$ctt = ClassTimetableType::with('periodSet')
    ->where('class_id', $first->class_id)          // :1034 — inside the classCapacity loop
    ...
    ->first();
```
**Evidence:** scanner rows `[H] QRY-01 …:1034, :1454, :1619, :3821, :3844, :4282`; each read confirmed in source as a query whose key comes from the enclosing loop.
**Consequence:** the page query count grows with the number of classes / options / pools; on the ~42-class-section tenant the Requirement and Groups pages already issue hundreds of small selects where a single pre-keyed map would do.

#### TFC-12 · M · QRY-15 / QRY-05 — unbounded `->get()` loads and `->get()->groupBy()` on the list pages
**Where:** `WorkingDay::with(...)->get()` `:510`, `ClassWorkingDay::with(...)->get()` `:511`, `ClassSubjectSubgroup::with(...)->get()` `:729`, `AcademicTerm::orderByDesc(...)->get()` `:736`, `ClassSection::query()->with(...)->get()` `:792` and `:829`, plus `->get()->groupBy(...)` at `:612,644,693,706,726,758,893,1078,1793,2313,3637`.
```php
$workingDays = WorkingDay::with(['dayType','dayType2','dayType3','dayType4'])->get();      // :510
$classWorkingDays = ClassWorkingDay::with([...])->get();                                    // :511
```
**Evidence:** `grep -nE '->get\(\)'` on the controller; scanner QRY-15 rows. `tt_working_days` holds **365 rows** on the tenant, `tt_class_working_days_jnt` **4,620 rows**.
**Consequence:** the masters/requirement pages load full calendar tables into memory on every request; dropping to the columns used (`select(...)`) and aggregating in SQL is the mechanical fix. (Caching is a DECISION.)

#### TFC-13 · M · QRY-07 — `->delete()` per row inside loops instead of one bulk `whereIn()->update()`
**Where:** `:3740` (`...->get()->each(fn ($stale) => $stale->delete())`) and `:3848` (same shape for stale option subgroups).
```php
ClassSubjectSubgroup::where('class_group_id', $record->id)
    ->whereNotIn('id', $keptIds)->get()
    ->each(function ($stale) { $stale->delete(); ... });   // :3844-3850
```
**Evidence:** scanner `[M] QRY-07 …:3740, :3848`; confirmed — one DELETE per stale row.
**Consequence:** tearing down a school's groups issues one statement per retired row; a single `->whereIn('id', …)->update(['deleted_at' => now()])` would do. (Soft-delete + `activityLog` per row keeps the loop; the log is the reason, so this is M not H.)

#### TFC-18 · M · QRY-05 — aggregates computed in PHP over full result sets
**Where:** `->get()->groupBy()` at `:612, :644, :693, :706, :726, :758, :893, :1078, :1793, :2313`, and `->get()->filter()` at `:4262`.
**Evidence:** scanner `[M] QRY-05` rows; each is a full `get()` followed by a PHP grouping.
**Consequence:** the database could `GROUP BY` these; today every row crosses the wire before the grouping.

#### TFC-25 · L · QRY-08 — leading-wildcard `LIKE '%…%'` searches
**Where:** `timetableConfiguration:187-189` (4), `timetableMasters:430` (4), `reportsAndLogs:3050`.
**Evidence:** scanner `[L] QRY-08`; the values are bound (no injection), searched on small master tables.
**Consequence:** index-unfriendly, but the tables are small; acceptable at L.

### F10 — Views
#### TFC-05 · H · VIEW-01 — a query runs inside the masters-page Blade
**Where:** `resources/views/pages/partials/timetable-masters/class-working-days/_list.blade.php:14`
```blade
@php $classes = \Modules\SchoolSetup\Models\SchoolClass::where('is_active', true)->orderBy('ordinal')->get(); @endphp
```
**Evidence:** `grep -rnE '(\bDB::|::where\(|::get\(|::all\()' resources/views/pages/ --include=*.blade.php` → this is the **only** genuine model query in the 71 partials (the other matches are `Collection::count()` on already-loaded data and a comment).
**Consequence:** a DB call hidden in a template — it cannot be cached, eager-loaded, or seen by anyone profiling the controller; the controller already loads class data on this page, so this is a duplicate query the controller cannot control.
**Fix:** pass `$classes` from `timetableMasters()` (the controller already builds `$filterClasses`-style lists).

#### TFC-26 · L · CTL-07 / VIEW — `compact()` of 36 / 31 / 23 variables
**Where:** `:1298` (36 vars), `:3494` (31), `:2345` (23), `:3001` (21).
```php
return view('timetablefoundation::pages.timetable-requirement', compact(
    'activityLockCount', 'subgroupFitWarnings', ... // 36 names
));
```
**Evidence:** scanner `[L] CTL-07 … compact() of 36 variables`.
**Consequence:** a 36-name `compact()` hides which variable is actually consumed; a typed view-model would expose dead entries (TFC-03 falls out of exactly this).

**Clean (one line each):**
- **VIEW-03:** `grep -rn '{!!' resources/views/pages/` — every raw echo is a trusted helper (`$bar()` bar-chart HTML, `$ttName()` link builder, a constant `'<br>'`); **no** user text through `{!! !!}`.
- **VIEW-02:** the eager-load lists in the controller are extensive and per-relation comments show the N+1s they fixed; no lazy relation found in a `@foreach` of the audited pages.
- **Permission surface:** `grep -rhoE 'permission="[^"]+"'` returns 12 distinct 4-part names, all present in `config/permissionslist.php`; the page-level gate (`config.viewAny` / `config.create`) matches the controller.
- **Blade compile:** no `{{-- --}}` inside `@php` found in the walked partials.

### F2 — Transactions and audit
#### TFC-06 · H · TXN-06 — school-wide truncate-and-rebuild has no lock; two admins corrupt each other
**Where:** `resetRequirements:1360-1368` and `generateClassGroups:3565-3590`.
```php
app(RequirementTableTruncator::class)->truncateFrom('groups');   // :3571
...
DB::beginTransaction();                                          // :3587
```
**Evidence:** both methods TRUNCATE 12 derived tables and rebuild them; there is no `lockForUpdate`, no advisory lock, no unique guard on the concurrent window (`RequirementTableTruncator` truncates unconditionally). The route is `POST`/`DELETE` and reachable from two tabs.
**Consequence:** two administrators generating at the same moment interleave truncate and rebuild — one's rows are wiped by the other's `truncateFrom`, leaving the requirement tables half-built with no error. On this tenant that is 539 groups + 123 subgroups + downstream activities.
**DECISION** — see plan §9.

#### TFC-08 · M · TXN-02 — manual `beginTransaction`/`commit`/`rollBack` instead of a closure
**Where:** `:3587` `DB::beginTransaction()`, `:3910` `DB::commit()`, `:3928` `DB::rollBack()`.
```php
try {
    DB::beginTransaction();
    ...
    DB::commit();
} catch (\Throwable $e) {
    DB::rollBack();
    report($e);
```
**Evidence:** `grep -nE 'beginTransaction|commit\(|rollBack'` → only this method. Rulebook TXN-02: use `DB::transaction(fn () => …)`.
**Consequence:** an early `return` between begin and commit leaks an open transaction; the closure form cannot. The D2 truncate carve-out requires one catch around the **truncate**, not around the write block.

### F1 — Errors
#### TFC-09 · M · ERR-07 / ERR-00 (D1) — a read method is wrapped in try/catch
**Where:** `reportsAndLogs:3481-3492`
```php
try {
    $optService = app(SchoolOptimisationReportService::class);
    ...
    $optReport = $optTimetableId ? $snap->run($optTimetableId, fn () => $optService->build(...)) : null;
} catch (\Throwable $e) {
    report($e);
    $optService = app(SchoolOptimisationReportService::class);
    $optError = 'The optimisation report could not be built for this timetable. The error has been logged.';
}
```
**Evidence:** `grep -nE 'try \{|catch'` → caught at `:3481`. Under D1 a read method takes no try/catch; ERR-07 says `index/show/create/edit/lookups` need none. This one is deliberate (comment: stop one tab taking the other four down).
**Consequence:** the controller uses two error models; the table state is correct (fixed message + `report`) but this is the pattern a future editor copies into a write path. Fix by moving the resilience into the service, or accept explicitly.
**DECISION** — inline in plan §3.

#### TFC-10 · M · ERR-05 / ERR-06 — `sharedSubgroupFitWarnings` swallows with a message-only log
**Where:** `:4313-4315`
```php
} catch (\Throwable $e) {
    Log::warning('sharedSubgroupFitWarnings failed', ['error' => $e->getMessage()]);
    $result = ['count' => 0, 'pools' => []];
}
```
Plus the two read catches inside the dead `runPreGenerationChecks` (`:1740-1750`, `:2022-2032`), where `$e->getMessage()` is written into the `explanation` field (not user-visible today only because TFC-03 makes the array unused).
**Evidence:** `grep -n 'getMessage'` → `:4314` (log-only), `:1746`/`:2028` (dead array).
**Consequence:** ERR-05 — the trace is lost (`Log::warning(…, ['error' => $e->getMessage()])`, not the exception object). If TFC-03 ever revives `$healthChecks`, `:1746`/`:2028` would put a raw SQL error on the page (ERR-01). **Sequenced after TFC-03.**

#### TFC-16 · M · ERR-05 / ERR-01 — `ProblemExporter` swallows a write failure into a raw message
**Where:** `ProblemExporter.php:2059-2063`
```php
try {
    $this->priorities->persist($computed['rows']);
} catch (\Throwable $e) {
    $warnings[] = 'activity priorities could not be saved: '.$e->getMessage();
}
```
**Evidence:** `grep -n 'getMessage' app/Services/ProblemExporter.php` → this is the only one. No `report($e)`. `$warnings` is returned inside the export payload consumed by `PythonTimetableController` and by `GenerationReadinessReportService::optionParallel` (`:536`).
**Consequence:** a failed priority persist reports the database error text upward; if any caller surfaces warnings, SQL leaks (ERR-01). Fix: `report($e)` + a fixed message. (Called by SmartTimetable too — see §7.)

#### TFC-17 · M · ERR-05 — `GenerationReadinessReportService` has one silent catch
**Where:** `GenerationReadinessReportService.php:123-128`
```php
try {
    return (int) DB::table('tt_school_days')->where('is_active', true)->whereNull('deleted_at')->count();
} catch (Throwable) {
    return 0;
}
```
**Evidence:** `grep -nE 'try \{|catch'` on the service → 7 catches, six of which call `report($e)` + `self::CHECK_FAILED` (the pre-applied 2026-10-10 work); **this one** still swallows with no variable and no report.
**Consequence:** a schema problem becomes "0 active school days" and the page silently reports a different reason; the error is not in the log. Align the last catch with the other six.

### F3 — Authorization
#### TFC-23 · L · AUTH-06 — permission literals repeated across ten methods (module-wide pattern)
**Where:** `config.viewAny` at `:80, :252, :409, :593, :2085, :2382, :3035`; `config.create` at `:1358, :3548`; `Gate::any([...])` at `:150-156`.
**Evidence:** `grep -nE "Gate::authorize|Gate::any"` → 9 sites, no constants or Policy.
**Consequence:** a rename touches ten lines; a Policy would centralise it. **The whole module passes permission strings**, so every policy is unreachable — a module-level decision, not a per-controller fix. No `Gate::any` without a following `abort_unless` (the `:150` call is wrapped correctly).

**Clean:**
- Every routed method authorizes before loading records (AUTH-01/02).
- No record-ownership surface on this controller (AUTH-03 n/a).
- No duplicate/`dead` gate logic (AUTH-04/05).

### F4 — Validation
**Clean.** `grep -nE '\$request->|->validate\(|->all\(\)|->except\('` → the only request reads are `.input('tab')`/`.input('search')` filters and `request('timetable_id')`; all are bound into parameterised queries, none reaches a model write. `generateClassGroups` and `resetRequirements` read no user body. No FormRequest is required for filters. No `Carbon::parse($request->…)`, no upload.

### F5 — Routes
**Clean.** No state change over GET (mutations are `POST`/`DELETE`). `generateStep` is unrouted and already `abort(403)` (D5). No route points at a missing method (uncached probe). Custom trash routes are not relevant (no resource). Tenant middleware present on all ten.

### F12 — Style
#### TFC-20 · L · STY-01 / STY-04 — no `strict_types`; emoji in comments
**Where:** controller line 1 (no `declare`); 43 emoji-comment lines (`:875,978,997,1279,1349,2129,2158,2172,2203,2218,2253,2317,2328,2333,2442,2450,2464,2538,2677,2699,2779,2784,2946,3039,3067,3095,3104,3143,3247,3264,3299,3333,3390,3428,3432,3438,3565,3694,3892,3970,3981,3991`). Same in all nine services (controller + `ConstraintCompiler` 24, `ProblemExporter` 42, `PublishedTimetable` 23, etc.).
**Evidence:** scanner `[L] STY-01` and `[L] STY-04` rows.
**Consequence:** Pint/style debt only; group as one plan item per file.

#### TFC-21 · L · CTL-08 — `request()` helper instead of the injected `Request`
**Where:** `:158, :411, :595, :2087, :2384, :3037` (`$r = request();`) and `:2459` (`request('timetable_id')`).
**Evidence:** scanner `[L] CTL-08` rows.
**Consequence:** the six page methods have no `Request` parameter; `preRequisitesSetup` shows the clean form. Consistency debt.

#### TFC-22 · L · CTL-04 — two public methods have no return type
**Where:** `index():` `:78`, `generateClassGroups()` `:3544` (the other nine return `mixed`/`RedirectResponse`/`JsonResponse`).
**Evidence:** scanner `[L] CTL-04 … index() has no return type`; `grep -nE 'public function'`.
**Consequence:** L style; the framework return types are available (`View`, `RedirectResponse`).

#### TFC-24 · L · CTL-10 — a no-op assignment loop and a long commented-out block
**Where:** `:1182-1184`
```php
foreach ($nonPrimaries as $at) {
    $at->assignmentRole = $at->assignmentRole;   // assigns a property to itself
}
```
and the commented teacher-slot-matrix block `:2315-2343` (>3 lines, deliberately retained with a restore recipe).
**Evidence:** read at both sites.
**Consequence:** the self-assignment does nothing and signals unfinished code (inside the same dead `$dashboardStats` computation, TFC-03); the commented block is justified by its note but is >3 lines.

### F7 — Models
**↗ linked.** All ~40 imported models belong to other reports (`AcademicTerm`→AcademicTermController, `Activity`/`ActivityTeacher`→ActivityController, `ClassSubjectSubgroup`→ClassSubjectSubgroupController, `Timetable`→TimetableController, etc. — `00-CLASS-OWNERS.md`). This controller's use of them was checked for wrong arguments / missing eager loads; no misuse found. No model is claimed here.

### F8 — Services and jobs
**Clean / linked:** `TimetableGridService`, `OptionalSubjectBreakdownService`, `OptionCellResolver`, `ResourceRatioService`, `AnalyticsService`, `ConstraintCompiler`, `PublishedTimetable` — no HTTP, no writes on read paths, no `env()`, no non-tenant cache. `OptionCellResolver` is `final` + static (no constructor needed). `ProblemExporter` and `GenerationReadinessReportService` carry the two service-level findings (TFC-16/TFC-17). `ConstraintCompiler::teacherFreePeriodPerHalf` (123 lines) and `ProblemExporter::emitOptionBlock` (279) / `optionBlocks` (162) are CTL-02-size (TFC-07). No jobs/events in scope.

#### TFC-07 · H · CTL-02 (services) — `ProblemExporter::emitOptionBlock` is 279 lines; `optionBlocks` 162
**Where:** `ProblemExporter.php:1628` (`emitOptionBlock`, 279 lines) and `:1435` (`optionBlocks`, 162); `ConstraintCompiler.php:372` (123).
**Evidence:** scanner `[H] CTL-02 …emitOptionBlock() is 279 lines`, `[H] …optionBlocks() is 162 lines`.
**Consequence:** the exporter is 2,147 lines and its option-block builder is a 279-line method; the Python boundary is the module's most correctness-critical output and it cannot be reviewed.

#### TFC-15 · M · SVC-04 — the pool-keying rule is duplicated between controller and generator
**Where:** `sharedSubgroupFitWarnings:3981-4105` explicitly "REPLICATE ActivityController STEP 1.5 POOL KEYING VERBATIM", and the room resolution at `:4128-4152` "the way generation resolves it".
```php
// :3981-3984
// ⛔ MIRRORS THE GENERATOR'S OWN POOL KEYING AND ROOM RESOLUTION SO THE WARNING AND
// THE RUN CAN NEVER DISAGREE:
```
**Evidence:** the comment names the source method; two copies of optionKey / crossClass / mixedWeekly / resolveSharedRoomRequirement now exist.
**Consequence:** the warning and the generator agree only by discipline; the next change to `ActivityController` silently makes the page lie about what generation will do. Extract one shared pooler.

### F11 — Security and tenancy
#### TFC-14 · M · SEC-03 — a hard-coded room-id fallback (`?? 1`)
**Where:** `TimetableFoundationController.php:3643`
```php
$defaultRoomId = Room::where('is_active', true)->value('id') ?? 1;
```
**Evidence:** `grep -nE '\?\? 1'` → this site. The value is written into `class_house_room_id` for every generated requirement row whose class-section has no home room (`:3700`).
**Consequence:** on a tenant where the first active room is not id 1 (deleted/re-created), every generated group is stamped with a foreign key to a room that may not exist or is the wrong room — a silently wrong FK. When no room exists at all, the literal `1` writes an FK that can 500 or point at another tenant's row under a re-used id. Prefer `null` (the column contract) or fail with a `\DomainException`.
**Note:** the scanner's `[M] SEC-03 … ResourceRatioService.php:533 ($roomsPerType[...] ?? 1)` is a **false positive** — that is an arithmetic divisor floor, not an id fallback.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **Unreachable policies (module-wide):** every `Gate::authorize` here passes a string, so no Policy is consulted (same pattern as the rest of the module). TFC-23.
- **`ProblemExporter` is also called by SmartTimetable** (`PythonTimetableController:176,287,662`) and `ProblemExporter` consumes `ActivityPriorityCalculator`/`ActivityLockService` (owned by ActivityController). TFC-16's blast radius reaches the Python pipeline; the fix is local to the catch but the class is shared.
- **`ResourceRatioService` is also called by `SmartTimetable\PythonTimetableController`** — the SEC-03 scanner hit at `ResourceRatioService.php:533` is a **false positive**: `max(1, (int) ($roomsPerType[...] ?? 1))` is a divisor floor, not a user/tenant/status id fallback. Not reported.
- **`AnalyticsService` and `ConstraintCompiler`** are pre-assigned to this report but are **not reached by this controller** (grep: only comments). `AnalyticsService` has six `->get()`-then-loop report builders (its own QRY-01 shape) and is used by SmartTimetable/portals; `ConstraintCompiler` is used by `ProblemExporter` and `PythonTimetableController`. Audited at service level; defects there are the other modules' screens.
- **`PublishedTimetable`** is also pre-assigned but not reached by this controller; it *is* the module's single "visible timetable" resolver used by nine portal controllers. It declares `strict_types` and shows no defect in the read; its `idFor()` method (113 lines) is CTL-02-size (service).
- **`OptionCellResolver` QRY-11 scanner hits are false positives:** every interpolated fragment is `ownerClassIdSql()`/`kindSql()`/`$snap->t(...)` — constants or a trusted wrapper, no user input. Its `owners()` loop is `array_chunk(..., 1000)` (the QRY-06 bulk pattern), not N+1.

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4); every finding is static or a read-only SQL probe.
- **The 71 tab partials' inner JavaScript** (calendar feeds, sortable grids, chart config) was checked for queries/XSS/permission props only; their JS logic is not a VIEW-family rule.
- **Models:** all imported models are owned by other reports (§7, F7); their `$fillable`/`$casts`/relations were not re-audited here.
- **The `RequirementTableTruncator` table list** (12 tables) was read for its call sites only; the truncator itself is owned by RequirementConsolidationController.
- **Seeders/importers** that also write the requirement tables were not audited; TFC-06's race risk is between the two controller paths named.
- **`routes.json` is stale** for `api/v1/timetablefoundations` (four `[B]` RTE-02 rows); disproved live, §4.
