# Status — TimetableFoundation / TimetableFoundationController

**Fixed:** 2026-10-12 · **By:** claude · **Developer folder:** tarun · **Plan:** `02-fix-plan.md`

Decisions came from Tarun in conversation, not as ticks in the plan:
- TFC-01, 02, 07, 15 and 23 are postponed.
- Both dead query blocks are deleted (TFC-03).
- The rebuild lock refuses a second request (TFC-06).
- The recommended option was taken for TFC-11, 13, 24 and 25.

## 1. Pre-applied work

None for this controller's files. `final-audit-reports/TimetableFoundation/PRE-APPLIED-2026-10-10.md` does not list `TimetableFoundationController.php` or the three services it uses.

Earlier 2026-10-12 work on the same screens is included in §2 because it shipped in the same change. That work was:
- the pre-requisites tabs (room-types, class-sections);
- the academic-terms tab;
- the masters status filter.

## 2. Applied

| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| TFC-03 + TFC-19 | `TimetableFoundationController.php:1077` | Removed the dead health-check computation: `runPreGenerationChecks()`, about 380 lines, and the `$dashboardStats` block. Both were computed on every load and rendered nowhere. | `grep -c 'function runPreGenerationChecks' <ctl>` | `0` | 2026-10-12 |
| TFC-04 | `<ctl>` option-subgroup branch + `sharedSubgroupFitWarnings()` | Moved the per-iteration queries out of their loops. Option subgroups are loaded once per group and matched in memory. Pool members are loaded once and keyed by id. | `grep -n 'existingSubgroups\|poolMembers' <ctl>` | hoisted reads present | 2026-10-12 |
| TFC-05 | `class-working-days/_list.blade.php:14` | Removed the blade's `SchoolClass` query. The view now loops over `$cwdClasses`, which `timetableMasters()` passes. | `grep -c 'SchoolClass::' <blade>` | `0` | 2026-10-12 |
| TFC-06 | `<ctl>` `resetRequirements()` and `generateClassGroups()` | Added a tenant-scoped `Cache::lock` around both rebuilds. A second concurrent request gets "A rebuild is already running, try again in a minute." The bodies moved to `truncateAllRequirements()` and `rebuildClassGroups()`, wrapped in try/finally. | `grep -n 'Cache::lock' <ctl>` | 2 sites | 2026-10-12 |
| TFC-08 | `<ctl>` `rebuildClassGroups()` | Replaced the manual begin/commit/rollBack with `DB::transaction(fn …)`, which returns `[$counts, $skippedLabels, $optionWarnings]`. The truncate catch stays outside the transaction (D2). The failure message is now the fixed text "…so they are now empty. The error has been logged." and the exception goes to `report($e)`. | `grep -c 'DB::beginTransaction' <ctl>` | `0` | 2026-10-12 |
| TFC-09 | `SchoolOptimisationReportService.php:151` (`forReportsTab`) | Moved the reports-tab try/catch into the service, so `reportsAndLogs()` has no catch (D1). | `grep -n 'forReportsTab' <ctl>` | `2715` | 2026-10-12 |
| TFC-10 | `<ctl>` `sharedSubgroupFitWarnings()` | Replaced the `Log::warning(getMessage)` call with `report($e)`. | `grep -n 'report(\$e)' <ctl>` | 2 sites | 2026-10-12 |
| TFC-11 | `<ctl>` constructor | Constructor-injected the four services: readiness, slot grid, ratio and lock. Removed the mid-method `new` and `app()` calls. | `class_exists` + `app(<ctl>)` | resolves | 2026-10-12 |
| TFC-12 (part) | `<ctl>` `timetableMasters()` | Removed the two unused calendar loads: `WorkingDay` (365 rows) and `ClassWorkingDay` (4,620 rows). Those tabs load over AJAX. The shift query now runs once instead of twice. Each tab's query is skipped when the user cannot see that tab. | render harness | masters 80 queries | 2026-10-12 |
| TFC-14 | `<ctl>` `rebuildClassGroups()` | Removed the `?? 1` room fallback. **Deviation from the plan:** the plan said to throw `DomainException`, but this runs after the truncate. Throwing would leave every tab empty. So a class-section with no home room and no active room is now **skipped** and named in the warning ("— no home room set and no active room exists"). The `class_house_room_id` column is NOT NULL in both tables, so storing NULL is not possible. | `grep -n "Room::where('is_active', true)->value('id')" <ctl>` | no `?? 1` | 2026-10-12 |
| TFC-16 | `ProblemExporter.php:2062` | The catch now calls `report($e)` and shows the fixed message "activity priorities could not be saved. The error has been logged." ⚠ SHARED: SmartTimetable calls this too. The change is message-only. | `grep -n 'TFC-16' <file>` | `2062` | 2026-10-12 |
| TFC-17 | `GenerationReadinessReportService.php:120` | Named the bare catch's variable, added `report($e)` and made it return `0`. | `grep -n 'TFC-17' <file>` | `120` | 2026-10-12 |
| TFC-21 | `<ctl>` six page methods | Injected `Request` into the six page methods; no `request()` helper calls remain. | `grep -c '\brequest()' <ctl>` | `0` | 2026-10-12 |
| TFC-22 | `<ctl>` all public methods | Added `: View` and `: RedirectResponse` return types. | `grep -nE 'public function' <ctl>` | all typed | 2026-10-12 |
| TFC-24 | `<ctl>` | The no-op `assignmentRole` loop went with TFC-03. The commented teacher-slot-matrix block was **kept**, per option (a). | — | — | 2026-10-12 |
| TFC-26 | `<ctl>` 7 `view()` calls | Replaced each `compact()` with an explicit array. While doing this, a commented-out `teacherSlotMatrix` entry was caught and kept commented. | render harness | 9/9 pages OK | 2026-10-12 |
| **TFC-27 (new)** | `working-days/_list.blade.php` | The day-type palette read the Day Types tab's **paginated and filtered** `$dayTypes`, so filtering that tab shrank the palette. It now loops over `$wdDayTypes` (all active day types). | `grep -n 'wdDayTypes' <blade>` | present | 2026-10-12 |
| masters page | `<ctl>` `timetableMasters()` | Per-tab `viewAny` gating: tabs the user cannot see return an empty paginator. LIKE-escaped search. No default status filter. | render with `pc_search=%_` | OK | 2026-10-12 |
| masters blades ×8 | day-types, period-sets, period-types, period-configs, shifts, school-days, timetable-types, teacher-roles | The status control no longer defaults to Active, and "All Status" is now `selected` when no value is given. | blade compile | 8/8 ok | 2026-10-12 |
| pre-req blades | room-types, class-sections `_list` | room-types now reads `required_resources` (previously a column that does not exist). class-sections now shows inactive sections, and its totals count active sections only. | blade compile | ok | 2026-10-12 |

`<ctl>` = `Modules/TimetableFoundation/app/Http/Controllers/TimetableFoundationController.php`.

## 3. Not applied

| ID | Reason | Detail |
|---|---|---|
| TFC-01 | postponed (Tarun) | Split the god controller (now 3,603 lines). D3 says fix in place. |
| TFC-02 | postponed (Tarun) | Eight methods over 150 lines. This goes with TFC-01. |
| TFC-07 | postponed (Tarun) | The long service methods in `ProblemExporter` and `ConstraintCompiler`. |
| TFC-15 | postponed (Tarun) | The pool-keying rule is duplicated with `ActivityController`. |
| TFC-23 | postponed (Tarun) | Module-wide permission literals and unreachable policies. |
| TFC-12 (rest) | blocked: decision | **Caching (option a) was not applied.** It still needs your explicit pick. The remaining `->select()` narrowing at `timetableRequirement` was also not applied. Those blades read columns across nested partials, and `$classTeachersMap` has a comment saying a narrowed select returned null relations. Narrowing without a full column map risks blank cells. |
| TFC-13 | accepted (option kept) | The per-row delete loops stay, so each row keeps its own activity log event. |
| TFC-18 | deferred | The `->get()->groupBy()` sites mostly reshape the data in PHP for the blades. Moving them into SQL is a per-site rewrite with no measured slow page. Revisit with TFC-01. |
| TFC-20a / 20b | deferred | `strict_types` would turn the string-to-int request coercions on these pages into TypeErrors (the `basic-test-creation-rule.md` §6.4.1 family). It needs a per-page browser pass. Emoji removal is cosmetic and belongs in the same pass. |
| TFC-25 | accepted | Small master tables, no change. |

## 4. Needs Tarun's hand

- **Browser check** of the six pages. In particular:
  - Timetable Masters with a non-super-admin role, to confirm hidden tabs show nothing.
  - Two simultaneous "Generate Class Groups" or "Reset All" clicks: the second should get the busy message.
- **Decision on TFC-12 caching** (a / b / c in the plan, §9).
- No migration, seeder or permission sync is needed.

## 5. Unverifiable by this workflow (no tests, D4)

- **TFC-06 (lock refusal):** I proved the lock works with a probe (`get()` then a second `get()` returns false on the file driver). A real two-request race was not exercised.
- **Per-tab gating on Masters:** it only matters for a role holding some tab permissions but not others, and super-admin bypasses all of them. Whether such a role exists on this tenant was not checked.
- **TFC-14 skip path:** it needs a tenant with no active room at all. No such data exists.

## 6. Verification log

```
$ php -l TimetableFoundationController.php ProblemExporter.php GenerationReadinessReportService.php SchoolOptimisationReportService.php
No syntax errors detected  (x4, before and after Pint)

$ vendor/bin/pint <the 4 files> --format agent
fixed: TimetableFoundationController.php (no_unused_imports, concat_space, function_declaration, …)

$ class_exists + app(TimetableFoundationController::class)
OK — resolves from the container with the 4 injected services

$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json   (filtered to this controller)
ROUTES-OK 15 — every web route's method exists.
  ⚠ the 5 api/v1/timetablefoundations routes point at index/store/show/update/destroy;
    store/show/update/destroy DO NOT EXIST (pre-existing, not touched — see §7 note)

$ render harness (real bound route, root@tenant.com, all page methods)
OK index                   196,037 bytes   26 queries
OK preRequisitesSetup      318,883 bytes   28 queries
OK timetableConfiguration  342,223 bytes   10 queries
OK timetableMasters      1,867,575 bytes   80 queries
OK timetableMasters      ?tab=working-day&pc_search=%_   77 queries
OK timetableRequirement 30,382,643 bytes  262 queries
OK resourceAvailability  2,173,025 bytes   34 queries
OK timetablePreparation 18,052,433 bytes   65 queries
OK reportsAndLogs       10,425,596 bytes  145 queries
(0 leaked Blade comments on every page)

$ blade compile, 14 edited blades: all compile, php -l clean, no stray @push emitted
```

**Regression found and fixed during verification.** The TFC-03 deletion range ran past `runPreGenerationChecks()`. It took with it the `RA_ROWS_PER_PAGE` and `RA_CARDS_PER_PAGE` constants and the `resourceAvailability()` docblock. As a result, Resource Availability fataled with "Undefined constant". I restored all three from the pre-pass backup, and the page now renders (above). I diffed the method and constant lists against the backup: only `runPreGenerationChecks` is gone, which is intended.

## 7. Final state

Status: FIXED (with decisions outstanding) · Open: B 0 · H 3 · M 3 · L 2

- **Open H:** TFC-01, 02, 07 (postponed).
- **Open M:** TFC-12 (caching decision), 15 (postponed), 18 (deferred).
- **Open L:** TFC-20 (deferred), 23 (postponed).

**Cross-cutting notes.** These are not fixed here; they fall outside this controller.

- `GenerationReadinessReportService` still returns `['error' => $e->getMessage()]` from 7 catches (`:248, 324, 404, 474, 671, 836, 953`). If the readiness card renders that `error` key, raw exception text reaches the user (ERR-01). This service belongs to this report's scope as a shared class, but the plan only covered `:123`. It needs its own item.
- `routes/api.php` registers `api.timetablefoundation.store/show/update/destroy` against methods that do not exist on this controller (RTE-02). Those routes 500 if called.
- `class-working-days/_list.blade.php:30-31` has a nested `{{--` that is already in git HEAD. It is harmless, because Blade comments do not nest and the render shows no leak.
