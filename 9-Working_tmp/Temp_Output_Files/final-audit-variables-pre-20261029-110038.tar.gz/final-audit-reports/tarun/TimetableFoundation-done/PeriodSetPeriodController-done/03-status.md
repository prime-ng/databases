# Status — TimetableFoundation / PeriodSetPeriodController

**Fixed:** 2026-10-13 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — 20 items ticked, 5 decisions filled. PSP-16 and PSP-21 are deferred by decision.
**Fixed together with:** `PeriodConfigController-done` and `PeriodSetController-done`.

---

## 1. Pre-applied work

None. `PRE-APPLIED-2026-10-10.md` lists no file in this controller's scope.

---

## 2. Applied

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| PSP-01 (a), PSP-02 | `PeriodSetPeriodController.php` `destroy()` | The delete was already permanent, because the model has no SoftDeletes. It is now honest about it: event `Deleted`, message "…was permanently deleted.", and the flash says the same. | read | — |
| PSP-01 (a) | `trashedPeriodSetPeriod/restore/forceDelete` | Each body is now `abort(403, 'Not routed: …')` with a `NOT ROUTED` comment (D5). They used to call `onlyTrashed()` on a model with no SoftDeletes, which gave a 500. The methods were kept, not deleted. | `grep -c 'abort(403'` | 4 (3 here + `create()`) |
| PSP-03 (c) | — | Moot. The restore route body is now `abort(403)`. | — | — |
| PSP-12 | `store()` / `update()` | Takes `PeriodSet::lockForUpdate()` before the cap check. The cap is now the daily maximum (`maxPeriodsPerDay()`). Two concurrent adds can no longer both pass the check. | read | — |
| PSP-04 | `PeriodSetPeriodRequest` | Adds the missing mirror of `uq_psp_set_config`: unique per set, `->ignore()` on update. A duplicate timeslot now gets a 422 with a field error, not a 1062. | rolled-back replay | duplicate → 422 |
| PSP-05 (a) | request + `period-set-period/{create,edit}` | Short name is `required`. It is **`max:50`, not `max:10`** — the column is VARCHAR(50), and 10 would refuse valid data. Both forms show the asterisk. | read | — |
| PSP-06, PSP-07, PSP-11 | controller | No try/catch except `catch (DomainException)` (D2) in `store` and `update`. Each closure returns its data; the redirect or JSON is built after the transaction. The six `Log::error` lines are gone. | `grep -c 'catch ('` | 2 |
| PSP-08, PSP-13 | `Http/Requests/PeriodSetPeriodRequest.php` (new) | Holds the store and update rules. The shift-consistency check is in `after()`. The two controller copies of it were deleted. | `class_exists` | OK |
| PSP-09 | request | `is_active` is `sometimes|boolean`. | read | — |
| PSP-10 | `toggleStatus()` | `save()` runs before `activityLog('Toggled')`, inside the transaction. | read | — |
| PSP-14 | `show/edit/update/destroy` | Route model binding. | reflection | bound |
| PSP-17 (a) | `index()` + redirects | Go to `timetableMasters?tab=period-sets`. Before, they went to `tab=period-set-period`, which does not exist, so the user saw an empty page after every edit. | read | — |
| PSP-18, PSP-19 | `period-set-period/{index,trash}.blade.php` | Both deleted. Nothing renders them: the controller no longer renders trash, and the only external link hits `index()`, which redirects. | `grep -rn "period-set-period\.\(index\|trash\)"` in `view()` calls | 0 |
| PSP-20 | `destroy()` / `toggleStatus()` | Use the injected `$request`. | read | — |
| PSP-22, PSP-23 | controller | `strict_types`, return types on every public method, stub docblocks dropped. | `php -l` | OK |
| PSP-24 ⚠ SHARED | `Models/PeriodSetPeriod.php:83` | `setCodeAttribute()` uppercases every write, including writes through the SmartTimetable alias that extends this model. The change is additive; current writers already uppercased. | read | — |

Event literals: `Stored` · `Updated` · `Deleted` · `Toggled`.

---

## 3. Not applied

| ID | Why |
|---|---|
| PSP-16 (a) | Deferred by decision. The global `ordered` scope stays, because the SmartTimetable alias also relies on it. Recorded as a known perf item. |
| PSP-21 | Unreachable `PeriodPolicy`. Deferred to the module-wide policy decision (ATC-14). |

---

## 4. Needs Tarun's hand

1. **Run the Dusk suites**; I ran none (D4).
2. **Browser check**:
   - add a period to a set past the daily maximum, and expect a refusal;
   - add a duplicate timeslot, and expect an inline field error;
   - edit a period, and expect to land back on `?tab=period-sets`.
3. No migration and no permission sync are needed.

---

## 5. Unverifiable by this workflow (D4), and notes

- **SmartTimetable's period-set-period `_list` links `period-set-period.trashed`**, which now answers 403 by design. It is a cross-module blade, so I did not change it. Remove or guard that link when SmartTimetable is next touched.
- The trash routes still exist in `routes/web.php` (lines 233-235). Their bodies are `abort(403)`, as D5 says (fail loudly). Delete them only together with the SmartTimetable link above.

---

## 6. Verification log

```
php -l (controller, request, model)                    → No syntax errors
class_exists: controller, PeriodSetPeriodRequest       → OK
route:list (uncached)                                  → every routed action exists
blade compile: period-set-period/{create,edit,show}    → OK
kernel replay (rolled back, tenant test.localhost):
  PSP add                                              → status true, set counters resync to 5
  PSP add, duplicate timeslot                          → 422, field error, nothing written
  PSP delete                                           → OK, 'Deleted' logged
  after rollback                                       → counts unchanged
Pint on touched files                                  → passed; php -l re-run → OK
```

---

## 7. Final state

**Status: FIXED** (2026-10-13). Open items:

- 1 M: PSP-16, deferred.
- 1 L: PSP-21, module-wide.

Both B blockers (PSP-01, PSP-02) are closed.
