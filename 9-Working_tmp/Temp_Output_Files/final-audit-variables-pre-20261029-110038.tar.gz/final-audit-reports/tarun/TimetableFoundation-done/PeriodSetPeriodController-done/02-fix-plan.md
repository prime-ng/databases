# Fix Plan — TimetableFoundation / PeriodSetPeriodController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/PeriodSetPeriodController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ The PSP-01 choice decides the fate of the trash routes and PSP-03/PSP-18. Fill it before the fixer runs.

## 1. Blockers reachable today
- [x] **PSP-01** · B · DECISION · MDL-03 — the model has no `SoftDeletes`, so `destroy()` hard-deletes, and `trashedPeriodSetPeriod` / `restore` / `forceDelete` call `onlyTrashed()` and 500 or flash-fail.
      (a) ⭐ **Make the hard delete honest and kill the dead trash flow (no migration):** change `destroy`'s `activityLog` event/message and flash from "Trashed / deactivated and moved to trash" to honest "permanently deleted" wording; put `abort(403, 'Not routed.')` + a `// NOT ROUTED` comment in `trashedPeriodSetPeriod`, `restore`, `forceDelete` (D5 spirit — the routes stop working by explicit choice); leave the broken `trash.blade.php` in place or delete it. Smallest change; matches the real UI, where rows are force-deleted through the period-set matrix anyway. Cost: the four routes die.
      (b) Add `use SoftDeletes` to `PeriodSetPeriod` and make the trash flow work: fix the trash blade (PSP-18), the restore-over-GET (PSP-03), and the soft-delete × unique trap (validator must then check trashed `code`/`period_ord`, or re-creating a trashed code 1062s on the plain UNIQUE indexes — see §7 of the report). Bigger change, needs approval for the route/behaviour reshaping.
      (c) Leave as is (trash is fake; Delete is permanent).
      ➜ Choice: (a) — honest hard delete; trash/restore/forceDelete become `abort(403)` NOT ROUTED (Tarun, 2026-10-13)
- [x] **PSP-02** · B · deep read · `PeriodSetPeriodController.php:317, 319-323, 329` — make `destroy()` tell the truth about what it does, according to the PSP-01 choice:
      - if PSP-01 = (a): `activityLog` event `Deleted`, message "…was permanently deleted.", flash "Period permanently deleted.";
      - if PSP-01 = (b): `delete()` becomes a soft delete and today's "moved to trash" wording is then correct; no change here.
      Effort: S.

## 2. Fixes that arm a latent defect (sequenced)
- [x] **PSP-12** · M · TXN-06 · `PeriodSetPeriodController.php:107-115` — take a row lock before the cap check: inside the transaction, `PeriodSet::whereKey($validated['period_set_id'])->lockForUpdate()->firstOrFail()`, then count and compare, then create. Effort: S. (Goes before PSP-04/PSP-05 so a failed insert can't smuggle a duplicate through.)
- [x] **PSP-03** · H · DECISION · RTE-01 · `routes/web.php:225` — Restore runs over GET. Only reachable once the trash flow works (PSP-01 = b).
      (a) ⭐ Change to `Route::patch` (the `action-trashed` component derives the verb from the route — no blade edit needed). ⚠ A route change needs approval.
      (b) Leave as GET and accept the risk.
      (c) Moot if PSP-01 = (a): the route dies with the `abort(403)` body; no change needed.
      ➜ Choice: (c) — moot, the route body is `abort(403)` (follows PSP-01 = a)

## 3. Errors & transactions (F1/F2)
- [x] **PSP-06** · M · ERR-00 / ERR-05 · `PeriodSetPeriodController.php:55-165, 200-304, 314-340, 350-390, 411-435, 445-469` — remove the hand-rolled try/catch from `store`, `update`, `destroy`, `toggleStatus`, `restore`, `forceDelete`; shape each as `return DB::transaction(fn () => …)`; drop the six `Log::error(..., ['error' => $e->getMessage()])` lines (the central handler logs). Any `\DomainException` added later is caught **only** as `DomainException` (ERR-01 + date comment). Effort: M.
- [x] **PSP-07** · M · ERR-04 · `PeriodSetPeriodController.php:158-165, 243-247, 293-304` — stop hand-picking the response format:
      - remove the generic-catch `response()->json(..., 500)` in `store` (the handler renders JSON for JSON callers);
      - in `update`, make the shift-consistency branch and the error return respect `$request->expectsJson()` (mirror `store`'s branch), now that PSP-06 removed the enclosing catch.
      Effort: S.
- [x] **PSP-10** · M · TXN-04 · `PeriodSetPeriodController.php:358-367` — in `toggleStatus`, call `$period->save()` **before** `activityLog('Toggled', …)`; the closure returns the saved model; build the JSON response after the transaction (with PSP-11). Effort: S.
- [x] **PSP-11** · M · TXN-05 · `PeriodSetPeriodController.php:325-329, 367-379, 422-424, 456-458` — `destroy`, `toggleStatus`, `restore`, `forceDelete`: each closure returns data (model/result), and the `redirect()` / `response()` is built **after** the transaction. Effort: S.

## 4. Authorization (F3)
_None — all 11 methods already gate before loading anything; PSP-21 (unreachable `PeriodPolicy`) is module-wide and deferred to the module decision (report §7)._

## 5. Validation, routes, models (F4/F5/F7)
- [x] **PSP-04** · H · VAL · `PeriodSetPeriodController.php:60, 207` — add the missing mirror of `uq_psp_set_config`: `Rule::unique('tt_period_set_periods_jnt')->where(fn ($q) => $q->where('period_set_id', $request->period_set_id))->whereNull('deleted_at')` on `period_config_id`, with `->ignore($periodSetPeriod->id)` in `update`. Effort: S.
- [x] **PSP-05** · H · DECISION · VAL-03 / DDL — Short Name is `nullable` in the rules but `NOT NULL` in both the migration and the DDL; a blank box 500s.
      (a) ⭐ Make the field `required|string|max:10` (matches the NOT NULL DDL — a period without a short name has no business meaning). No migration.
      (b) Additive migration making the column nullable, and the controller coalesces blank → null (departs from DDL `NOT NULL`; DDL must change first per §1.4.1).
      (c) Leave as is.
      ➜ Choice: (a) — required on add, `max:50` not `max:10` (column is VARCHAR(50)); a blank on the period-set edit page keeps the old value (PSC-10) (Tarun, 2026-10-13)
- [x] **PSP-08** · M · VAL-02 + VAL-07 + CTL-06/CTL-05 · `PeriodSetPeriodController.php:58-84, 205-233, 94-100, 243-247` — new `PeriodSetPeriodRequest` (FormRequest) holding the store+update rules; move the shift-consistency check into its `after()` hook and delete both controller copies (this also removes PSP-13's duplication). `authorize()` returns `true` — the controller's `Gate::authorize` stays (AUTH-04: keep exactly one per concern). Effort: M.
- [x] **PSP-09** · M · VAL-05 · `PeriodSetPeriodController.php:83, 232` — `'is_active' => ['sometimes', 'boolean']`. Effort: S.
- [x] **PSP-14** · M · CTL-03 · `PeriodSetPeriodController.php:171, 182, 198, 310` — type the four methods to the model: `show(PeriodSetPeriod $periodSetPeriod)`, `edit`, `update`, `destroy` (the resource route parameter is already `{period_set_period}`), and drop the `findOrFail($id)` calls. `toggleStatus` already binds. Effort: S.
- [x] **PSP-17** · M · DECISION · RTE/UX · `PeriodSetPeriodController.php:32, 293-295` — `index()` and the post-`update` redirect point at `tab=period-set-period`, a tab that does not exist on the masters page.
      (a) ⭐ Point the `update()` redirect at `tab=period-sets` (the pane that exists and shows the set), and `index()` the same way.
      (b) Point `update()` at `period-set.edit` of the owning set (shows the edited row), `index()` at `tab=period-sets`.
      (c) Leave as is (empty page after every edit).
      ➜ Choice: (a) — `tab=period-sets` for `index()` and every redirect (Tarun, 2026-10-13)

## 6. Queries & performance (F9)
- [x] **PSP-16** · M · DECISION · MDL-08 · `PeriodSetPeriod.php:61-73` — the global `ordered` scope runs three correlated `orderByRaw` subqueries on every read.
      (a) ⭐ Defer: keep the scope (it also orders the SmartTimetable alias's reads), record as a known perf item. No code change.
      (b) Drop the global scope and order via explicit joins in the few list queries, measured against the alias's consumers.
      (c) Leave as is.
      ➜ Choice: (a) — deferred, scope kept, recorded as a perf item (Tarun, 2026-10-13)

## 7. Views (F10)
- [x] **PSP-18** · L · VIEW · `views/period-set-period/trash.blade.php:22-66` — depends on PSP-01:
      - if PSP-01 = (b): iterate `$trashedPeriods` (not `$periodSets`), render PSP columns (code/period-set/period-type/time/status), and use `url="timetable-foundation.period-set-period"` + `tenant.timetable-foundation.period-set-period.restore/forceDelete` permissions;
      - if PSP-01 = (a): leave the blade (or delete it) — the controller no longer renders it.
      Effort: S.
- [x] **PSP-19** · L · CTL-10 · `views/period-set-period/index.blade.php` — delete the orphan blade (it renders "Day Management" and iterates `$schoolDays`); re-prove at fix time that nothing renders `timetablefoundation::period-set-period.index` and that the only external link (`Modules/SmartTimetable/.../slot-availability/show.blade.php:107`) hits the redirecting `index()` route, not the blade. Effort: S.

## 8. Style (F12) — one item per file
- [x] **PSP-20** · L · CTL-08 · `PeriodSetPeriodController.php:325` — use the injected `$request` instead of the `request()` helper in `destroy` (and make `toggleStatus` consistent). Effort: S.
- [x] **PSP-22 + PSP-23** · L · CTL-04 + STY · `PeriodSetPeriodController.php` — add return types (`: RedirectResponse`, `: View`, `: JsonResponse`) to all 11 public methods, `declare(strict_types=1)`, remove the stray blank lines between `use` statements, drop the copy-paste stub docblocks. Effort: S.
- [x] **PSP-24** · L · MDL-06 · `PeriodSetPeriod.php` — move `strtoupper($validated['code'])` into a model mutator (`setCodeAttribute` uppercase) so every writer normalizes. ⚠ SHARED — `Modules/SmartTimetable/.../PeriodSetPeriod` extends this model. The change is additive and behaviour-preserving for current writers. Effort: S.

## 9. Deferred / decisions
- **PSP-21** (unreachable `PeriodPolicy`, module-wide gate-string pattern) — deferred to the module-level policy decision, same as ATC-14. Not fixed in this pass.
- **PSP-03 / PSP-18 / PSP-19** route-and-blade fates are bound to the **PSP-01** choice above.

## How to approve
1. Tick `[x]` each item to apply.
2. Fill every `➜ Choice:` on the ticked DECISION items — **PSP-01 first** (it decides PSP-03 and PSP-18).
3. Explicitly tick the `⚠` items (PSP-03 route change, PSP-24 shared model).
4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/PeriodSetPeriodController.php`. It touches only the files each ticked item names.