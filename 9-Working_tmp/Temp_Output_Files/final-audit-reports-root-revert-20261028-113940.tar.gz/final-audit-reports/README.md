# Final Audit Reports

The last pass before production: one controller at a time, every change tracked.
**Protocol:** `.claude/rules/final-audit.md`, which both agents and their OpenCode twins read.

## How to run

1. **Audit.** Ask the `final-audit-auditor` agent to audit a controller path **for a developer**,
   for example `Modules/TimetableFoundation/app/Http/Controllers/ActivityController.php — shailesh`.
   The report goes in that developer's folder. No developer name → the agent asks.
   It writes `01-report.md` and `02-fix-plan.md`, then stops. It changes no code.
2. **Approve.** In `02-fix-plan.md`:
   - tick `[ ]` → `[x]` on what should be fixed;
   - on every ticked DECISION item, write your choice after `➜ Choice:`;
   - `⚠ SHARED` items need an explicit tick of their own.
3. **Fix.** Ask the `final-audit-fixer` agent to fix the same controller path, same developer. It applies only
   the ticked items, verifies them (no tests), and writes `03-status.md`.

## Who does what *(settled 2026-10-10)*

| Step | Who | Tool |
|---|---|---|
| Audit a controller | Tarun (or a module run) | OpenCode `final-audit-auditor` — writes `01-report.md` + `02-fix-plan.md`, must pass `_tools/selfcheck.py` |
| Approve | **Tarun** | tick `[x]` and fill `➜ Choice:` in `02-fix-plan.md` |
| Fix | **the developer whose folder it is** | OpenCode `final-audit-fixer` — applies only ticked items, writes `03-status.md` |
| Re-audit | Tarun | `final-audit-auditor` in re-audit mode — writes `04-reaudit.md` |

Everything the agents need is inside `prime_testing/`: the protocol (`../.claude/rules/final-audit.md`),
the templates (`_templates/`), and the rulebook, scanner and self-check (`_tools/`). The application
under audit is `../prime_ai_dev/`.

**Module-level shortcut (OpenCode):** the `code-auditor` agent in
`OpenCode_Brain/agents/code-auditor.md` takes `Module_Name` and `Developer_Name` and can either
audit every controller in the module or produce a read-only module-wide `00-STATUS.md` re-check.

## Layout

```
final-audit-reports/
├── _Info/                      00-CLASS-OWNERS.md · FINAL-AUDIT-PROTOCOL.md · README.md
├── _templates/                 the five file shapes (00-INDEX · 01-report · 02-fix-plan · 03-status · 04-module-status)
├── _tools/                     00-RULEBOOK.md (rule IDs), scan.php (static scanner), selfcheck.py (report checker)
├── tarun/ shailesh/ gaurav/    one folder per developer (since 2026-10-10)
│   └── <Module>/ or <Module>-done/
│       ├── 00-INDEX.md         the tracking sheet: controller · status · B/H/M/L · links
│       ├── 00-SUMMARY.md       module audit summary
│       ├── 00-STATUS.md        module-wide status / re-check (Code Auditor)
│       └── <Controller>/       or <Controller>-done/
│           ├── 01-report.md    the evidence
│           ├── 02-fix-plan.md  the approval sheet (tick boxes)
│           └── 03-status.md    what was actually applied, verified and left open
└── tarun/TimetableFoundation-done/   LEGACY (pre-2026-10-10) — left as is
```

Status flow in the index: `CLAIMED → AUDITED → APPROVED → FIXING → FIXED` (or `BLOCKED`).
⛔ **Parallel sessions:** append rows and edit only your own row. Never rewrite an index or the
registry.
