# Final Audit — Payment / Backend\PaymentController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php` (52 lines, 2 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `https://<tenant-host>/payment/payments` (list) and `https://<tenant-host>/payment/payments/{ulid}` (detail) |
| Menu path | Payment module backend. The exact `glb_menus` trail was not measured — see §8. |
| Who uses it | Roles holding `tenant.payment.payment.viewAny` (list) and `tenant.payment.payment.view` (detail). `config/permission_role_defaults.php` has no payment entries, so by the project rule (`AUTO_GRANT_ROLES = [Super Admin, School Admin]`) only those two roles hold them by default. |
| What a user does here | A school admin opens the Payments list to see every online/offline payment, then clicks View on a row to read one payment: gateway, amount, status, the payable it belongs to, any offline (cash/cheque) record, refunds and the audit log. Both pages are read-only — there is no create, edit or delete here. |
| Tables written | none — both methods are read-only. |
| Tables read | `ptm_payment_payments`, `ptm_payment_gateways`, `ptm_payment_refunds`, `ptm_payment_audit_logs`, `ptm_payment_offline_records` |
| Live data | not measured — no tenant DB session was opened in this read-only pass (see §8). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. The controller body itself is small and correct in shape (it authorizes, it eager-loads, it has no try/catch), but both pages it renders are broken before the controller's output is ever shown: the views extend a layout that does not exist (`prime::layouts.master`), so each page throws a 500 on load (BPA-01), and once that is fixed they call three named routes that are not registered (`payment.backend.payments.index/show`, `payment.backend.receipts.show`), so they 500 again (BPA-02). The single worst finding is BPA-01: `prime::layouts.master` cannot be resolved by the view finder, so the payment list and the payment detail page are both down. The next real defect is BPA-03: `show()` loads the payment with `firstOrFail()` **before** it authorizes, so the page leaks whether a given ULID exists (404 vs 403). The remaining items are a pagination-standard miss, a wasted eager load, two view deviations and one style item. Rough effort: S (about half a day), with three items held as decisions for Tarun.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 1 | 3 | 3 | 3 | 12 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | n/a — no service or job in scope |
| F2 Transactions/Audit | clean — read-only, no writes | F9 Queries/Perf | BPA-04, BPA-07 |
| F3 Authorization | BPA-03 | F10 Views | BPA-01, BPA-02, BPA-06, BPA-08 |
| F4 Validation | clean — no request input beyond the route parameter | F11 Security/Tenancy | clean — see §7 |
| F5 Routes | clean — see §4 | F12 Style | BPA-09 |
| F6 Controller shape | BPA-05 | F13 Deep read | clean — no mutating methods |
| F7 Models | ↗ linked — see §3 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php` | controller | 52 | this report | ✅ |
| 2 | `Modules/Payment/resources/views/payments/index.blade.php` | view | 64 | this report | ✅ |
| 3 | `Modules/Payment/resources/views/payments/show.blade.php` | view | 119 | this report | ✅ |
| 4 | `Modules/Payment/app/Models/Payment.php` | model | 101 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 5 | `Modules/Payment/app/Models/PaymentGateway.php` | model | 76 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 6 | `Modules/Payment/routes/web.php` | route file | 38 | shared route file (§4.2, "common") | ❌ inspected only — confirms the two routes at lines 13-14; not audited here |
| 7 | `Modules/Payment/app/Providers/RouteServiceProvider.php` | provider | 95 | module glue (§4.2, "common") | ❌ inspected only — confirms the `payment.` name prefix and tenant middleware at lines 42-56 |
| 8 | `Modules/Payment/app/Policies/PaymentPolicy.php` | policy | 46 | ↗ [tarun/Payment-done/PaymentController](../PaymentController/01-report.md) | ↗ linked — usage checked only |

The two views in rows 2-3 are now claimed in `_Info/00-CLASS-OWNERS.md` (appended 2026-10-19). Rows 4-5 were already owned elsewhere (the brief assigned them to `ParentPortal-done/ParentFeePaymentController`); they are linked, not re-audited. `PaymentRefund`, `PaymentAuditLog`, `PaymentWebhook` and `OfflinePaymentRecord` are reached only through the `Payment` relations and are owned by other Payment reports (Refund / Webhook / ParentPortal) — not registered here.

No pre-applied (`PRE-APPLIED-2026-10-10`) files are in this scope.

## 4. Routes

```
GET|HEAD  payment/payments           payment.payment.backend.payments.index   Modules\Payment\Http\Controllers\Backend\PaymentController@index
GET|HEAD  payment/payments/{ulid}    payment.payment.backend.payments.show    Modules\Payment\Http\Controllers\Backend\PaymentController@show
```

Both public methods are routed. Unrouted public methods: none.

Middleware group (`Modules/Payment/app/Providers/RouteServiceProvider.php:44-52`): `web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Payment`, `auth`, `verified`. Tenant middleware present — F5 clean.

Note for the fixer: the RouteServiceProvider adds its own `payment.` name prefix (line 54) on top of the `payment.backend.` prefix declared inside `Modules/Payment/routes/web.php:12`. The registered names are therefore **doubled**: `payment.payment.backend.…`. The views use the single-prefix names, which do not exist — this is BPA-02.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 28 | GET payment/payments | `Gate::authorize('viewAny', Payment::class)` → `tenant.payment.payment.viewAny` | n/a (read) | n/a | none | BPA-01, BPA-02, BPA-04, BPA-06, BPA-08 |
| `show` | 42 | GET payment/payments/{ulid} | `Gate::authorize('view', $payment)` → `tenant.payment.payment.view` | n/a (read) | n/a | none | BPA-01, BPA-02, BPA-03, BPA-05, BPA-07, BPA-08 |

## 6. Findings

### F1 — Errors

clean — no `try`/`catch`, no `getMessage`, no write path in the controller.

```
$ grep -nE 'try \{|catch \(|getMessage' Modules/Payment/app/Http/Controllers/Backend/PaymentController.php
(no output)
```

### F2 — Transactions and audit

clean — both methods are read-only; there is no INSERT/UPDATE/DELETE and therefore nothing to wrap in `DB::transaction` and no `activityLog()` event to place.

```
$ grep -nE 'DB::transaction|activityLog|->save\(\)|->update\(|->create\(|->delete\(\)' Modules/Payment/app/Http/Controllers/Backend/PaymentController.php
(no output)
```

### F3 — Authorization

#### BPA-03 · H · AUTH-02 — the detail page checks the permission only after it has loaded the row

| Field | Value |
|---|---|
| **Rule** | AUTH-02 (H) — *authorize first, before loading records; loading first leaks whether an id exists (404 vs 403)* |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:42-48`, method `show()` |
| **Root cause** | The query runs before the gate. `Payment::…->firstOrFail()` throws a 404 for an unknown ULID and returns the row for a known one, and only then does `Gate::authorize('view', $payment)` decide 403. A caller without the `view` permission can therefore tell a real ULID (403) from a made-up one (404). |
| **Consequence** | Any logged-in user who lacks payment-view rights can enumerate which payment ULIDs exist — the page answers 404 for a fake id and 403 for a real one. |
| **Reproduce** | static only — it needs a logged-in tenant user without `tenant.payment.payment.view`; open `/payment/payments/<real-ulid>` (403) versus `/payment/payments/does-not-exist` (404). |
| **Fix approach** | Add a page-level `Gate::authorize('viewAny', Payment::class)` **before** the query (the same permission the list already requires), then keep the record-level `Gate::authorize('view', $payment)` after the load. This mirrors the top-level `PaymentController@show`, which checks a permission string before loading. |
| **Plan item** | BPA-03 in `02-fix-plan.md` §4 |

```php
// PaymentController.php:42-48 — CURRENT
    public function show(string $ulid): View
    {
        $payment = Payment::with(['gateway', 'refunds', 'auditLogs', 'webhooks', 'offlineRecord'])
            ->where('ulid', $ulid)
            ->firstOrFail();

        Gate::authorize('view', $payment);
```

**Evidence**
```
$ sed -n '42,48p' Modules/Payment/app/Http/Controllers/Backend/PaymentController.php
    public function show(string $ulid): View
    {
        $payment = Payment::with(['gateway', 'refunds', 'auditLogs', 'webhooks', 'offlineRecord'])
            ->where('ulid', $ulid)
            ->firstOrFail();

        Gate::authorize('view', $payment);

$ sed -n '28,30p' Modules/Payment/app/Http/Controllers/Backend/PaymentController.php   # index() does it correctly
    public function index(): View
    {
        Gate::authorize('viewAny', Payment::class);
```

### F4 — Validation and input

clean — the only input is the `{ulid}` route parameter, consumed by `where('ulid', $ulid)`. No request body is read, so there is no validation surface.

```
$ grep -nE '\$request|validate\(|Request ' Modules/Payment/app/Http/Controllers/Backend/PaymentController.php
(no output)
```

### F5 — Routes

clean — both public methods are routed (see §4), both routes point at methods that exist, reads use GET, and the tenant + auth middleware group wraps both (`RouteServiceProvider.php:44-52`).

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '...Backend\PaymentController...'
payment.payment.backend.payments.index   payment/payments
payment.payment.backend.payments.show    payment/payments/{ulid}
```

### F6 — Controller shape

#### BPA-05 · M · CTL-03 — the detail page finds the row by hand instead of using route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding (`show(Payment $payment)`), not `$id` + `findOrFail`* |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:44-46`, method `show()` |
| **Root cause** | The controller reaches into the query builder with `where('ulid', $ulid)->firstOrFail()` rather than letting the router bind `{ulid}` to the model. The route parameter is named `{ulid}`, so binding needs either a `{payment:ulid}` route parameter or a `Payment::getRouteKeyName()` override — both are changes outside this controller. |
| **Consequence** | No wrong result today; it is the maintainability debt the rule targets, and it is the reason the authorize-order defect (BPA-03) is easy to write. |
| **Reproduce** | static only — a code-shape defect with no browser-visible symptom. |
| **Fix approach** | Prefer `show(Payment $payment)` bound by ULID. Because that needs a route-parameter change (`{ulid}` → `{payment:ulid}`) in the shared route file, it is a DECISION item; the recommended option is to defer it and keep the manual find, or to make the route change in a dedicated pass. |
| **Plan item** | BPA-05 in `02-fix-plan.md` §9 |

```php
// PaymentController.php:44-46 — CURRENT
        $payment = Payment::with(['gateway', 'refunds', 'auditLogs', 'webhooks', 'offlineRecord'])
            ->where('ulid', $ulid)
            ->firstOrFail();
```

**Evidence**
```
$ grep -n "firstOrFail\|public function show" Modules/Payment/app/Http/Controllers/Backend/PaymentController.php
42:    public function show(string $ulid): View
46:            ->firstOrFail();
```

### F7 — Models

↗ linked — `Payment` and `PaymentGateway` are owned by `tarun/ParentPortal-done/ParentFeePaymentController` and were not re-audited. Usage checked here: both relations (`gateway`, `refunds`, `auditLogs`, `webhooks`, `offlineRecord`) are declared on `Payment.php:55-88` with return types and resolve. One usage note is recorded in §7 (the `offlineRecord` relation name is singular for a `hasMany`).

### F8 — Services and jobs

n/a — this controller injects nothing and calls no service, job, event or listener.

### F9 — Queries and performance

#### BPA-04 · M · QRY-13 — the list paginates at 20 without a page name (house standard is 10)

| Field | Value |
|---|---|
| **Rule** | QRY-13 (M, raised from L to M — it hits the only list on the module and every row is a money record) — *paginators keep filters and use distinct page names; the house list standard is 10 rows (C12)* |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:32-34`, method `index()` |
| **Root cause** | `->paginate(20)` uses the default 20 rows and the default page name (`page`). The project standard for a backend list is 10 rows with a distinct `pageName`, so a second paginator added to this page later would collide on `page`. |
| **Consequence** | The admin scrolls twice as long per page and any future filter/second paginator will jump the wrong page. |
| **Reproduce** | Open `/payment/payments` — the page shows up to 20 rows instead of the house 10. |
| **Fix approach** | Change to `paginate(10, ['*'], 'paymentsPage')`. No view change is needed; `{{ $payments->links() }}` reads the page name from the paginator. |
| **Plan item** | BPA-04 in `02-fix-plan.md` §6 |

```php
// PaymentController.php:32-34 — CURRENT
        $payments = Payment::with('gateway')
            ->latest()
            ->paginate(20);
```

**Evidence**
```
$ grep -n "paginate" Modules/Payment/app/Http/Controllers/Backend/PaymentController.php
34:            ->paginate(20);
```

#### BPA-07 · L · QRY-03 — the detail page eager-loads `webhooks` that the view never reads

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M, lowered to L — one extra query, no wrong result) — *select only what you use* |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:44`, method `show()` |
| **Root cause** | The `with([...])` list includes `'webhooks'`, but `payments/show.blade.php` renders no webhook data (and neither does any other consumer of this view). The eager load therefore issues a `ptm_payment_webhooks` query on every detail view for nothing. The method docblock also claims webhooks are shown. |
| **Consequence** | One wasted database query per payment-detail view; no visible error. |
| **Reproduce** | static only — a performance defect with no browser-visible symptom. |
| **Fix approach** | Drop `'webhooks'` from the `with([...])` list. If webhooks are meant to be displayed, that is a separate feature request, not this fix. |
| **Plan item** | BPA-07 in `02-fix-plan.md` §6 |

```php
// PaymentController.php:44 — CURRENT
        $payment = Payment::with(['gateway', 'refunds', 'auditLogs', 'webhooks', 'offlineRecord'])
```

**Evidence**
```
$ grep -n "webhook" Modules/Payment/resources/views/payments/show.blade.php
(no output)

$ grep -n "webhook" Modules/Payment/resources/views/payments/index.blade.php
(no output)
```

### F10 — Views

#### BPA-01 · B · VIEW-04 — both pages extend a layout that does not exist (500 on every load)

| Field | Value |
|---|---|
| **Rule** | VIEW-04 (B) — no rulebook line; from protocol F10 (`final-audit.md` §6): *"Blades must compile."* An `@extends` whose target is missing throws `InvalidArgumentException` — a crash on a normal user path, so B. |
| **Where** | `Modules/Payment/resources/views/payments/index.blade.php:1` (and `payments/show.blade.php:1`) |
| **Root cause** | The `prime` view namespace resolves only to `Modules/Prime/resources/views`, where there is no `layouts/` directory. The view finder therefore cannot resolve `prime::layouts.master`; only `prime::components.layouts.master` exists. Every one of the six Payment backend views extends this missing name. |
| **Consequence** | Opening the Payments list or a payment detail page throws a 500 before any content is shown. The whole Payment backend is down. |
| **Reproduce** | Open `/payment/payments` (or `/payment/payments/<ulid>`) — Laravel reports `View [layouts.master] not found`. |
| **Fix approach** | Choose a resolvable parent (see BPA-01 in the plan). The only existing backend layout is `backend.layouts.master` (`resources/views/backend/layouts/master.blade.php`), used by 7 other views; it yields `content` but not `content_header`, so the header would be folded into `content`. Because the target is a shared-layout choice affecting 4 views owned by other reports, this is a DECISION item. |
| **Plan item** | BPA-01 in `02-fix-plan.md` §1 (DECISION) |

```blade
@extends('prime::layouts.master')

@section('title', 'Payments')

@section('content_header')
    <h5 class="mb-0">Payments</h5>
@endsection
```

**Evidence**
```
$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); foreach(["prime::layouts.master","prime::components.layouts.master"] as $v){ echo $v." => ".(view()->exists($v)?"EXISTS":"MISSING")."\n"; }'
prime::layouts.master => MISSING
prime::components.layouts.master => EXISTS
prime hints: [ Modules/Prime/resources/views ]     # no layouts/ subdirectory exists

$ ls Modules/Prime/resources/views/ | grep -i layout
(no output)

$ grep -rl "@extends('prime::layouts.master')" Modules --include=*.blade.php
Modules/Payment/resources/views/webhooks/index.blade.php
Modules/Payment/resources/views/payments/show.blade.php
Modules/Payment/resources/views/payments/index.blade.php
Modules/Payment/resources/views/reconciliation/show.blade.php
Modules/Payment/resources/views/reconciliation/index.blade.php
Modules/Payment/resources/views/refunds/index.blade.php
```

#### BPA-02 · B · RTE-02 — both pages link to named routes that are not registered (500 once the layout is fixed)

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *every route reference must resolve; `route()` on an unknown name throws `RouteNotFoundException`* (rulebook wording is about routes pointing at real methods; here the mirror case — a page naming a route that does not exist — is the same crash class) |
| **Where** | `Modules/Payment/resources/views/payments/index.blade.php:47-51` (and `payments/show.blade.php:8`) |
| **Root cause** | The views use `payment.backend.…`, but `RouteServiceProvider::mapWebRoutes()` prepends its own `payment.` name prefix (`->name('payment.')`, line 54) on top of the `payment.backend.` prefix in `routes/web.php:12`, so the real names are `payment.payment.backend.…`. The single-prefix names do not exist. |
| **Consequence** | The list page 500s on the first row (the View link), and the detail page 500s in its header (the Back link). The `Receipt` link is broken the same way. |
| **Reproduce** | Open `/payment/payments` with at least one row — `Route [payment.backend.payments.show] not defined`. |
| **Fix approach** | Point the three `route()` calls at the registered names (`payment.payment.backend.payments.show`, `payment.payment.backend.receipts.show`, `payment.payment.backend.payments.index`). No route file change is needed. |
| **Plan item** | BPA-02 in `02-fix-plan.md` §1 |

```blade
                                    <td>
                                        <a href="{{ route('payment.backend.payments.show', $payment->ulid) }}" class="btn btn-sm btn-outline-primary">View</a>
                                        @if($payment->status === 'success')
                                            <a href="{{ route('payment.backend.receipts.show', $payment->ulid) }}" class="btn btn-sm btn-outline-success">Receipt</a>
                                        @endif
```

**Evidence**
```
$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); $r=app("router")->getRoutes(); foreach(["payment.backend.payments.index","payment.backend.payments.show","payment.backend.receipts.show","payment.payment.backend.payments.index","payment.payment.backend.payments.show","payment.payment.backend.receipts.show"] as $n){ printf("%-45s %s\n",$n,$r->getByName($n)?"EXISTS":"MISSING"); }'
payment.backend.payments.index      MISSING
payment.backend.payments.show       MISSING
payment.backend.receipts.show       MISSING
payment.payment.backend.payments.index    EXISTS
payment.payment.backend.payments.show     EXISTS
payment.payment.backend.receipts.show     EXISTS
```

#### BPA-06 · M · UI-STD — the list row actions are hand-rolled anchors, not `x-backend.table.action`

| Field | Value |
|---|---|
| **Rule** | UI-STD (M) — Table Action Standard §1: *"A list row's actions are ALWAYS `<x-backend.table.action>` … Never hand-rolled."* |
| **Where** | `Modules/Payment/resources/views/payments/index.blade.php:47-51` |
| **Root cause** | The row actions are two plain `<a class="btn …">` links. The standard requires the `x-backend.table.action` component, which carries the permission gate, the `Route::has()` guards and the dialog binding. The component's built-in actions are view/edit/delete; the custom "Receipt" action is not expressible by it, which is itself the finding the standard asks to raise. |
| **Consequence** | The row markup drifts from every other list, gets no permission gate from the component, and the Receipt action has no standard home. |
| **Reproduce** | Open `/payment/payments` and inspect a row — it renders loose anchors, not the shared action component. |
| **Fix approach** | Use `<x-backend.table.action>` for the View action and decide (Tarun) how the Receipt action is expressed. Because the component cannot express the Receipt button, this is a DECISION item. |
| **Plan item** | BPA-06 in `02-fix-plan.md` §9 (DECISION) |

```blade
                                    <td>
                                        <a href="{{ route('payment.backend.payments.show', $payment->ulid) }}" class="btn btn-sm btn-outline-primary">View</a>
                                        @if($payment->status === 'success')
                                            <a href="{{ route('payment.backend.receipts.show', $payment->ulid) }}" class="btn btn-sm btn-outline-success">Receipt</a>
                                        @endif
```

**Evidence**
```
$ grep -n "x-backend.table.action" Modules/Payment/resources/views/payments/index.blade.php
(no output)

$ ls app/View/Components/Backend/Table/Action.php resources/views/components/backend/table/action.blade.php
app/View/Components/Backend/Table/Action.php
resources/views/components/backend/table/action.blade.php
```

#### BPA-08 · L · UI-STD — neither page renders a breadcrumb

| Field | Value |
|---|---|
| **Rule** | UI-STD (L) — Breadcrumb Standard §1: every backend page renders `<x-backend.components.breadcrum>`. |
| **Where** | `Modules/Payment/resources/views/payments/index.blade.php:1-7` (and `payments/show.blade.php:12`) |
| **Root cause** | Neither view includes the breadcrumb component, and the layout it extends (`prime::layouts.master`, itself missing — BPA-01) does not inject one either. |
| **Consequence** | A user cannot see where the Payments page sits in the 47-module tree; only the "Back" link (show) offers a way out. |
| **Reproduce** | Open `/payment/payments` — the page renders no breadcrumb trail. |
| **Fix approach** | Add `<x-backend.components.breadcrum title="Payments" :links="[]" />` at the top of each `@section('content')`. The trail's parent links are resolved by the standard's registry. |
| **Plan item** | BPA-08 in `02-fix-plan.md` §7 |

```blade
@extends('prime::layouts.master')

@section('title', 'Payments')

@section('content_header')
    <h5 class="mb-0">Payments</h5>
@endsection
```

**Evidence**
```
$ grep -n "breadcrum" Modules/Payment/resources/views/payments/index.blade.php Modules/Payment/resources/views/payments/show.blade.php
(no output)

$ head -3 Modules/Prime/resources/views/index.blade.php
<x-prime.layouts.app>

    <x-backend.components.breadcrum
```

### F11 — Security and tenancy

clean — the encrypted `gateway.credentials` column is **not** exposed by either blade: the only gateway field rendered is `$payment->gateway?->name` (`index.blade.php:31`, `show.blade.php:20`). No `{!! !!}` on user text, no `env()`, no secrets in logs, and no hard-coded ids in either file.

```
$ grep -n "credentials\|{!!\|env(" Modules/Payment/resources/views/payments/index.blade.php Modules/Payment/resources/views/payments/show.blade.php
(no output)
```

A related cross-cutting note lives in §7 (the *API* `show()` in another controller does leak credentials — PAY-08).

### F12 — Style

#### BPA-09 · L · STY-02 — the controller's imports are not Pint-sorted

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports* |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:7-10` |
| **Root cause** | The `use` statements are not in alphabetical order: `Illuminate\Support\Facades\Gate` precedes `App\Http\Controllers\Controller`. Pint's Laravel preset sorts imports, so the file is not Pint-clean. |
| **Consequence** | Running Pint on this file later produces a diff unrelated to the fix; style checks fail. |
| **Reproduce** | static only — a formatting defect. |
| **Fix approach** | Reorder the four `use` statements alphabetically (or run `vendor/bin/pint` on the file). |
| **Plan item** | BPA-09 in `02-fix-plan.md` §8 |

```php
// PaymentController.php:7-10 — CURRENT
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use Illuminate\View\View;
use Modules\Payment\Models\Payment;
```

**Evidence**
```
$ sed -n '7,10p' Modules/Payment/app/Http/Controllers/Backend/PaymentController.php
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use Illuminate\View\View;
use Modules\Payment\Models\Payment;
```

### F13 — Deep read (answer all 8 questions for every mutating method)

No mutating methods — both `index()` and `show()` are read-only (no `save`, `update`, `create`, `delete`, `activityLog`). The eight deep-read questions (wrong data, irreversible order, duplicate implementations, soft-delete × unique index, races, authorization holes, lying messages, dead features) are therefore answered `n/a` for every method; the one authorization-order question that *can* apply to a read is captured as BPA-03.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Payment/app/Http/Controllers/PaymentController.php` (API `show()`, line 128) | Returns `$payment->load(['gateway', …])` as JSON; `PaymentGateway` has no `$hidden`, so the encrypted `credentials` (merchant keys, webhook secrets) are decrypted and sent to the caller. | SEC-02 / PAY-08 | `tarun/Payment-done/PaymentController` (already reported as PAY-08) |
| `Modules/Payment/app/Http/Controllers/Backend/ReceiptController.php:32-34` | Repeats the same `firstOrFail()`-before-`Gate::authorize` order as BPA-03. | AUTH-02 | `tarun/Payment-done/BackendReceiptController` |
| `Modules/Payment/resources/views/refunds/index.blade.php`, `webhooks/index.blade.php`, `reconciliation/index.blade.php`, `reconciliation/show.blade.php` | All four extend the same missing `prime::layouts.master` as BPA-01, so they also 500. | VIEW-04 | the respective Payment controller reports |
| `Modules/Payment/app/Models/Payment.php:85-88` | `offlineRecord()` is a `hasMany` named in the singular; the view reads `$payment->offlineRecord`. | STY-03 | `tarun/ParentPortal-done/ParentFeePaymentController` |
| `Modules/Payment/routes/web.php:12-16` | Carries a `payment.backend.` name prefix that is doubled by the provider's `payment.` prefix; any consumer of these route names must use the doubled form. | RTE-02 | module owner (route file is shared) |

## 8. Not covered, and why

- **Live row counts** (§0) — no tenant database session was opened; this pass ran read-only against the central bootstrap (D4).
- **Rendered pages** — the screens were not opened in a browser; the layout and route-name failures were proved with `view()->exists()` and the route collection, not by loading the page (the `auth` + tenancy middleware group makes a tenant session necessary).
- **`glb_menus` trail** (§0) — not measured; it is a central-DB lookup outside this controller's scope.
- **`Payment`, `PaymentGateway`, `PaymentPolicy` internals** — owned by other reports (§3/§5); only this controller's *usage* of them was checked.
- **The four other Payment views** that share the missing-layout defect — noted in §7, not audited here.
