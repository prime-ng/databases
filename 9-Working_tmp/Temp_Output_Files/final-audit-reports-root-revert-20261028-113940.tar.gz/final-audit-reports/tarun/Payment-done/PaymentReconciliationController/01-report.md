# Final Audit — Payment / PaymentReconciliationController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php` (149 lines, 4 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `https://<tenant-host>/payment/payment/reconciliation` (list, named `payment.payment.reconciliation.index`) and `https://<tenant-host>/payment/payment/reconciliation/{id}` (detail, named `payment.payment.reconciliation.show`) |
| Menu path | Not measured — no `glb_menus` row was queried in this read-only pass (see §8). The routes are reachable directly. |
| Who uses it | Roles holding `tenant.payment.reconciliation.viewAny` and `.view` (the two pages) or `.create` / `.resolve` (the two actions). `config/permission_role_defaults.php` has no `payment` entries, so by the project rule `AUTO_GRANT_ROLES = [Super Admin, School Admin]` only those two roles hold them by default. |
| What a user does here | A school accountant opens the Payment Reconciliation list, uploads a bank/gateway settlement CSV for one gateway and one date, and the system matches every CSV line against recorded `Payment` rows and stores a reconciliation with its lines. The accountant then opens the reconciliation detail to read the matched / unmatched / amount-mismatch counts and the per-line detail, and can mark a discrepant reconciliation as resolved. |
| Tables written | `ptm_payment_reconciliations`, `ptm_reconciliation_lines`, `sys_activity_logs` (through `activityLog()`) |
| Tables read | `ptm_payment_reconciliations`, `ptm_reconciliation_lines`, `ptm_payment_gateways`, `ptm_payment_payments` |
| Live data | not measured — no tenant DB session was opened in this read-only pass (see §8). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. The controller is small and structured, but both pages and both write paths are broken by two shared root causes: the two views extend `prime::layouts.master`, which does not resolve, so `index` and `show` throw a 500 before anything renders (PRC-14), and every `route('payment.reconciliation.*')` reference in the controller and the views names a route that is not registered — the real names are `payment.payment.reconciliation.*` — so the modal, the row links, the back link, the upload success redirect and the resolve flow all throw `RouteNotFoundException` (PRC-06). The single worst finding is PRC-06: it is reachable on the happy path of every page and every action, and in `resolve()` it rolls the transaction back while the controller's catch tells the user only that "the operation could not be completed". On top of that the service runs one `Payment` query per CSV row (PRC-09, N+1) and the two mutating methods carry the controller `try/catch` that D1 removes (PRC-01). Rough effort: M (about one to one-and-a-half days), with two items held as decisions for Tarun.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 3 | 11 | 2 | 2 | 18 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PRC-01, PRC-02 | F8 Services/Jobs | PRC-09, PRC-10, PRC-11 |
| F2 Transactions/Audit | PRC-03 | F9 Queries/Perf | PRC-12, PRC-13 |
| F3 Authorization | PRC-04 | F10 Views | PRC-14, PRC-15, PRC-16 |
| F4 Validation | PRC-05 | F11 Security/Tenancy | clean — see the F11 note |
| F5 Routes | PRC-06 | F12 Style | PRC-17 |
| F6 Controller shape | PRC-07, PRC-08 | F13 Deep read | PRC-18 |
| F7 Models | clean — see the F7 note | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php` | controller | 149 | this report | ✅ |
| 2 | `Modules/Payment/app/Services/PaymentReconciliationService.php` | service | 316 | this report | ✅ |
| 3 | `Modules/Payment/app/Models/PaymentReconciliation.php` | model | 85 | this report | ✅ |
| 4 | `Modules/Payment/app/Models/PaymentReconciliationLine.php` | model | 53 | this report | ✅ |
| 5 | `Modules/Payment/resources/views/reconciliation/index.blade.php` | view | 115 | this report | ✅ |
| 6 | `Modules/Payment/resources/views/reconciliation/show.blade.php` | view | 163 | this report | ✅ |
| 7 | `Modules/Payment/app/Models/PaymentGateway.php` | model | 76 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked — usage only |
| 8 | `Modules/Payment/app/Models/Payment.php` | model | 101 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked — usage only |
| 9 | `Modules/Payment/routes/web.php` | route file | 38 | shared route file (§4.2, "common") | ❌ inspected only — confirms the reconciliation group at lines 33-37 |
| 10 | `Modules/Payment/app/Providers/RouteServiceProvider.php` | provider | 95 | module glue (§4.2, "common") | ❌ inspected only — confirms the `payment.` name prefix at lines 42-56 |
| 11 | `Modules/Prime/resources/views/components/layouts/master.blade.php` | shared layout | n/a | shared Prime view (§4.2) | ❌ inspected only — proves the `@extends` target is missing |

Rows 3-6 (two models, one service, two views) are claimed in `_Info/00-CLASS-OWNERS.md` — rows 3-5 were pre-assigned 2026-10-19, rows 5-6 were appended by this report on 2026-10-19. Rows 7-8 were already owned by `tarun/ParentPortal-done/ParentFeePaymentController`; they are linked, not re-audited. No `PRE-APPLIED-2026-10-10` files are in this scope.

## 4. Routes

```
GET|HEAD payment/payment/reconciliation                payment.payment.reconciliation.index     PaymentReconciliationController@index
POST     payment/payment/reconciliation                payment.payment.reconciliation.store     PaymentReconciliationController@store
GET|HEAD payment/payment/reconciliation/{id}           payment.payment.reconciliation.show      PaymentReconciliationController@show
POST     payment/payment/reconciliation/{id}/resolve   payment.payment.reconciliation.resolve   PaymentReconciliationController@resolve
```

Middleware on all four (from `RouteServiceProvider::mapWebRoutes()`): `web`, `PreventAccessFromCentralDomains`, `InitializeTenancyByDomain`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Payment`, `auth`, `verified`. RTE-05 is satisfied.

Unrouted public methods: none — `index`, `show`, `store`, `resolve` are all routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 31 | GET payment/payment/reconciliation | `tenant.payment.reconciliation.viewAny` | none (read) | none | none | PRC-13, PRC-15, PRC-16 |
| `show` | 45 | GET payment/payment/reconciliation/{id} | `tenant.payment.reconciliation.view` | none (read) | none | none | PRC-07, PRC-12 |
| `store` | 73 | POST payment/payment/reconciliation | `tenant.payment.reconciliation.create` | service (`reconcile`) | 'Reconciled' (service) | ptm_payment_reconciliations, ptm_reconciliation_lines, sys_activity_logs | PRC-01, PRC-02, PRC-05, PRC-06 |
| `resolve` | 117 | POST payment/payment/reconciliation/{id}/resolve | `tenant.payment.reconciliation.resolve` | controller (`DB::transaction`) | 'Resolved' | ptm_payment_reconciliations, sys_activity_logs | PRC-01, PRC-02, PRC-03, PRC-06, PRC-07 |
| `reconcile` (service) | 27 | n/a | n/a | service (`DB::transaction`, lines 35-131) | 'Reconciled' (line 118, inside the tx, after the writes) | ptm_payment_reconciliations, ptm_reconciliation_lines, sys_activity_logs | PRC-08, PRC-09, PRC-10 |
| `parseCsv` (service) | 141 | n/a | n/a | none (read of a file) | none | none | PRC-11 |

**Transactions, counted across controller and service (§6 of `controller-alignment.md`)**: `store()` has no transaction of its own — the only write path is `PaymentReconciliationService::reconcile()`, which runs ONE `DB::transaction` (service lines 35-131) that wraps the reconciliation insert, every line insert, the summary update and the `activityLog('Reconciled')`. `resolve()` runs ONE `DB::transaction` in the controller (line 122). Total: two transactions, each in the layer that owns the write it protects — this division is correct; the defect is what is built *inside* `resolve()`'s closure (PRC-03).

## 6. Findings

### F1 — Errors

#### PRC-01 · H · ERR-00 — both mutating methods carry a controller try/catch (D1)

| Field | Value |
|---|---|
| **Rule** | ERR-00 (H) — *the open decision; under `.claude/rules/final-audit.md` D1 the Laravel idiom wins: **no try/catch in a controller**, except the D2 shapes*. Severity kept at H: the catch is on a money write path and swallows real failures. |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:83-107` (`store`), and `121-147` (`resolve`) |
| **Root cause** | Both methods wrap their body in `try { … } catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { … }`. The comments call this "Rule A1", but D1 supersedes house rule A1 for any module under final audit, and none of the D2 shapes applies (`\DomainException`, truncate-then-rebuild, `SnapshotProtectionException`, or a service doing `report($e)`). The `ModelNotFoundException` re-throw is a symptom of the same design — with the `try` gone, `findOrFail()` outside any catch is already a 404. |
| **Consequence** | Any real failure (including the route-name crash PRC-06) is swallowed and rendered as a generic red flash, and a `404`/`403`/`422` raised inside the try becomes a redirect instead of its own status. The user cannot tell a saved reconciliation from a failed one. |
| **Reproduce** | static only — the shape is proven by the source; the *effect* of the swallow is shown by PRC-06 (open `/payment/payment/reconciliation` and submit the upload). |
| **Fix approach** | Delete the `try`, both `catch` blocks in each method. Keep `findOrFail()` outside any catch and let `DB::transaction` + the central handler in `bootstrap/app.php` do the work (D1). |
| **Plan item** | PRC-01 in `02-fix-plan.md` §3 |

```php
// PaymentReconciliationController.php:83-107 — CURRENT (store)
        try {
            $gateway = PaymentGateway::findOrFail($validated['gateway_id']);

            $path = $request->file('file')->getRealPath();

            $recon = $this->reconciliationService->reconcile(
                gateway: $gateway,
                filePath: $path,
                date: $validated['date'],
            );

            return redirect()->route('payment.reconciliation.show', $recon->id)
                ->with('success', "Reconciliation #{$recon->id} completed.");
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing gateway must stay a 404. Without this the generic catch
            // below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('PaymentReconciliationController::store failed', [
                'gateway_id' => $validated['gateway_id'],
                'error'      => $e->getMessage(),
            ]);

            return back()->with('error', 'The reconciliation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "try {\|catch (" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php
83:        try {
96:        } catch (ModelNotFoundException $e) {
100:        } catch (\Throwable $e) {
121:        try {
139:        } catch (ModelNotFoundException $e) {
143:        } catch (\Throwable $e) {
```

#### PRC-02 · M · ERR-05 — logs `getMessage()` without the exception, losing the trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception object (`report($e)` / `Log::error('…', ['exception' => $e])`), never `getMessage()` alone* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:101-104` (`store`) and `144` (`resolve`) |
| **Root cause** | Both catches log only the string message. The stack trace and the exception class are dropped, so a later failure cannot be diagnosed from the log. |
| **Consequence** | When reconciliation fails in production the log holds a bare SQL/exception sentence with no trace and no request context — the operator cannot find the cause. |
| **Reproduce** | static only — an observability defect with no browser-visible symptom. |
| **Fix approach** | These two calls are deleted anyway when PRC-01 removes the try/catch; the failure then flows to the central handler, which logs the exception object itself. No separate edit is needed. |
| **Plan item** | none — see plan §10 (removed with PRC-01) |

```php
// PaymentReconciliationController.php:100-104 — CURRENT (store catch)
        } catch (\Throwable $e) {
            Log::error('PaymentReconciliationController::store failed', [
                'gateway_id' => $validated['gateway_id'],
                'error'      => $e->getMessage(),
            ]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php
103:                'error'      => $e->getMessage(),
144:            Log::error('PaymentReconciliationController::resolve failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### PRC-03 · M · TXN-05 — `resolve()` builds the redirect inside the `DB::transaction` closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build `redirect()` / `response()` after it* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:135-137`, method `resolve()` |
| **Root cause** | The closure returns a `RedirectResponse` instead of the model. The response is therefore composed inside the transaction, and any exception while building it (here, the unregistered route name — PRC-06) rolls the write back. The written row is discarded even though the status change itself succeeded. |
| **Consequence** | Marking a reconciliation resolved can silently roll back, and the user is told the operation failed. |
| **Reproduce** | Open a reconciliation detail page and press Resolve — the write is rolled back by the exception from `route('payment.reconciliation.show', …)`. |
| **Fix approach** | Return `$recon` from the closure; build the redirect after `DB::transaction` returns. |
| **Plan item** | PRC-03 in `02-fix-plan.md` §3 |

```php
// PaymentReconciliationController.php:135-138 — CURRENT
                return redirect()->route('payment.reconciliation.show', $recon->id)
                    ->with('success', 'Reconciliation marked as resolved.');

            });
```

**Evidence**
```
$ grep -n "DB::transaction\|return redirect()" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php
94:            return redirect()->route('payment.reconciliation.show', $recon->id)
122:            return DB::transaction(function () use ($id) {
135:                return redirect()->route('payment.reconciliation.show', $recon->id)
```

### F3 — Authorization

#### PRC-04 · M · AUTH-01 — the views never gate the Upload / Resolve actions

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B in the rulebook; lowered to M here because the controller *does* authorize and the worst case is a post-click 403, not an unauthorized write) — *the permission name must appear on all four surfaces: controller, FormRequest `authorize()`, view (`@can` / `permission=`), config* |
| **Where** | `Modules/Payment/resources/views/reconciliation/index.blade.php:8-10` (Upload button) and `Modules/Payment/resources/views/reconciliation/show.blade.php:9-17` (Resolve form) |
| **Root cause** | The controller calls `Gate::authorize` in all four methods, and the config declares all four names, but neither view adds an `@can` / `permission=` guard. The view surface is the missing one. |
| **Consequence** | A user who holds only `viewAny`/`view` still sees "Upload Settlement CSV" and "Resolve", clicks them, and gets a 403 page — a dead control with no explanation. |
| **Reproduce** | Sign in as a role with `tenant.payment.reconciliation.viewAny` but not `.create`; the Upload button on `/payment/payment/reconciliation` is visible and 403s on submit. |
| **Fix approach** | Wrap the Upload button in `@can('tenant.payment.reconciliation.create')` and the Resolve form in `@can('tenant.payment.reconciliation.resolve')`. |
| **Plan item** | PRC-04 in `02-fix-plan.md` §4 |

```blade
        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#uploadModal">
            <i class="fas fa-upload"></i> Upload Settlement CSV
        </button>
```

**Evidence**
```
$ grep -n "@can\|permission=" Modules/Payment/resources/views/reconciliation/index.blade.php Modules/Payment/resources/views/reconciliation/show.blade.php
NO GATE ON VIEW SURFACE
```

### F4 — Validation and input

#### PRC-05 · M · VAL-02 — `store()` validates inline instead of in a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request, except a one-field AJAX toggle* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:77-81`, method `store()` |
| **Root cause** | Three fields (`gateway_id`, `file`, `date`) are validated with an inline `$request->validate([…])`. This is not a toggle, so the project rule requires a FormRequest. The validation also cannot be reused by the console command or a future endpoint. |
| **Consequence** | No user-visible bug today, but the rules live in the controller rather than with the request, so an AJAX or API caller duplicates them and the two copies drift. |
| **Reproduce** | static only — a structural rule with no browser symptom. |
| **Fix approach** | Add `StorePaymentReconciliationRequest` (rules + `authorize()` on `tenant.payment.reconciliation.create`), type-hint it in `store()`, and read `$request->validated()`. Remove the now-duplicate `Gate::authorize` from the controller (AUTH-04: authorize once). |
| **Plan item** | PRC-05 in `02-fix-plan.md` §5 |

```php
// PaymentReconciliationController.php:73-81 — CURRENT
    public function store(Request $request): RedirectResponse
    {
        Gate::authorize('tenant.payment.reconciliation.create');

        $validated = $request->validate([
            'gateway_id' => 'required|exists:ptm_payment_gateways,id',
            'file'       => 'required|file|mimes:csv,txt|max:10240',
            'date'       => 'required|date_format:Y-m-d',
        ]);
```

**Evidence**
```
$ grep -n "request->validate" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php
77:        $validated = $request->validate([
```

### F5 — Routes

#### PRC-06 · B · RTE-02 — every `payment.reconciliation.*` route reference names an unregistered route (500 / rollback)

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *every route reference must resolve; `route()` on an unknown name throws `RouteNotFoundException`*. Here the page references a name that does not exist, the mirror of the rulebook wording. |
| **Where** | `Modules/Payment/resources/views/reconciliation/index.blade.php:62,80`; also `show.blade.php:10,18` and controller `:94,135` |
| **Root cause** | `RouteServiceProvider::mapWebRoutes()` applies `->prefix('payment')->name('payment.')` (lines 42-56) on top of the group declared in `routes/web.php:33` (`->prefix('payment/reconciliation')->name('payment.reconciliation.')`), so the real names are double-prefixed: `payment.payment.reconciliation.*`. The declared single-prefix names in the controller and the views do not exist. |
| **Consequence** | The index page 500s at the upload modal (`route('payment.reconciliation.store')`), the table's View link 500s per row, the detail page 500s at the Resolve form and the Back link, the upload success redirect throws after a successful save, and Resolve rolls back (PRC-03). Every path through this controller fails. |
| **Reproduce** | Open `/payment/payment/reconciliation` — Laravel reports `Route [payment.reconciliation.store] not defined`. |
| **Fix approach** | Point every reference at the registered names (`payment.payment.reconciliation.index/show/store/resolve`). No route-file change is needed. |
| **Plan item** | PRC-06 in `02-fix-plan.md` §1 |

```blade
                                        <a href="{{ route('payment.reconciliation.show', $recon->id) }}"
                                           class="btn btn-sm btn-outline-primary">View</a>
```

**Evidence**
```
$ php -r '…foreach(["payment.reconciliation.index","payment.reconciliation.show","payment.reconciliation.store","payment.reconciliation.resolve","payment.payment.reconciliation.show"] as $n){ printf("%-45s %s\n",$n,app("router")->has($n)?"EXISTS":"MISSING"); }'
payment.reconciliation.index                  MISSING
payment.reconciliation.show                   MISSING
payment.reconciliation.store                  MISSING
payment.reconciliation.resolve                MISSING
payment.payment.reconciliation.show           EXISTS
```

### F6 — Controller shape

#### PRC-07 · M · CTL-03 — no route model binding on `show()` and `resolve()`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding (`show(Model $model)`), not `$id` + `findOrFail`* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:45-52` (`show`), `:117-123` (`resolve`), `store` `:84` |
| **Root cause** | Both methods take an `int $id` and call `findOrFail($id)` by hand; `store()` does the same for the gateway. The route parameters are `{id}`. |
| **Consequence** | No user-visible bug — the 404 still works — but the pattern is repeated three times and does not use the framework binding, so a parameter/name drift is not caught at routing time. |
| **Reproduce** | static only — a structural rule. |
| **Fix approach** | Route model binding needs the route parameter renamed from `{id}` to `{reconciliation}`, which edits the shared route file — see the decision in the plan. |
| **Plan item** | PRC-07 in `02-fix-plan.md` §9 (DECISION) |

```php
// PaymentReconciliationController.php:45-52 — CURRENT
    public function show(int $id): View
    {
        Gate::authorize('tenant.payment.reconciliation.view');

        $reconciliation = PaymentReconciliation::with([
            'gateway',
            'lines.matchedPayment',
        ])->findOrFail($id);
```

**Evidence**
```
$ grep -n "findOrFail\|public function show\|public function resolve" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php
45:    public function show(int $id): View
52:        ])->findOrFail($id);
84:            $gateway = PaymentGateway::findOrFail($validated['gateway_id']);
117:    public function resolve(int $id): RedirectResponse
123:                $recon = PaymentReconciliation::findOrFail($id);
```

#### PRC-08 · M · CTL-02 — the service `reconcile()` method is 106 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *a method over 80 lines should be extracted* (applied here to the service method the controller drives) |
| **Where** | `Modules/Payment/app/Services/PaymentReconciliationService.php:27-132`, method `reconcile()` |
| **Root cause** | `reconcile()` parses, matches, counts, inserts, updates the summary and logs in one method; the scanning loop body alone runs nearly 40 lines. The static scanner flags the length independently. |
| **Consequence** | No user-visible bug; the method is hard to test and to change, and the counting/inserting logic cannot be reused by the console command in isolation. |
| **Reproduce** | static only. |
| **Fix approach** | Extract the per-row loop body into a private `persistLine()` and the tally into a small value object / array; keep behaviour identical. |
| **Plan item** | PRC-08 in `02-fix-plan.md` §6 |

```php
// PaymentReconciliationService.php:27-33 — CURRENT
    public function reconcile(
        PaymentGateway $gateway,
        string $filePath,
        string $date,
        bool $dryRun = false,
    ): PaymentReconciliation {
        $rows = $this->parseCsv($filePath);
```

**Evidence**
```
$ wc -l Modules/Payment/app/Services/PaymentReconciliationService.php
316 Modules/Payment/app/Services/PaymentReconciliationService.php   # reconcile() spans 27-132 = 106 lines

$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-prc.json Modules/Payment/app/Services/PaymentReconciliationService.php
M  CTL-02   Modules/Payment/app/Services/PaymentReconciliationService.php:27  reconcile — reconcile() is 106 lines
```

**F7 note — models are clean.** `PaymentReconciliation` (`ptm_payment_reconciliations`) and `PaymentReconciliationLine` (`ptm_reconciliation_lines`) each declare `$fillable`, cast every date/decimal/json/boolean column, and use `SoftDeletes`; the DDL (`pgdatabase/NEW/Payment_Module_Tables.sql:333-384`) has `deleted_at` on both, so `SoftDeletes` is correct. `$table` exists in the tenant migrations `2026_06_18_100107_create_ptm_payment_reconciliations_table.php` and `2026_07_08_000001_create_ptm_reconciliation_lines_table.php`. No MDL finding. Proof: `grep -n "fillable\|casts\|SoftDeletes\|protected \$table" Modules/Payment/app/Models/PaymentReconciliation.php Modules/Payment/app/Models/PaymentReconciliationLine.php` → all four present in both.

### F8 — Services and jobs

#### PRC-09 · H · QRY-01 — one `Payment` query per CSV row (N+1) inside the reconcile loop

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; pre-fetch or key the collection, then match in memory* |
| **Where** | `Modules/Payment/app/Services/PaymentReconciliationService.php:54-58` (loop) calling `matchPayment()` at `:198-211` |
| **Root cause** | `matchPayment($row)` runs `Payment::query()->…->first()` for every CSV row. A settlement file with N rows issues 1 + N queries (the `first()` also lazy-loads `Payment`'s relations on use). |
| **Consequence** | A month-end settlement of a few thousand rows issues a few thousand queries inside one open transaction, holding locks and slowing the upload until it may time out — a serious performance trap on a real screen. |
| **Reproduce** | static only — the shape is proven by the source; the load would be visible in the query log on a large CSV. |
| **Fix approach** | Collect all `gateway_payment_id` / `gateway_order_id` values first, fetch the matching `Payment` rows in one `whereIn(...)->get()->keyBy(...)`, and have `matchPayment()` consult the in-memory map. |
| **Plan item** | PRC-09 in `02-fix-plan.md` §6 |

```php
// PaymentReconciliationService.php:54-58 — CURRENT
            foreach ($rows as $row) {
                $expectedTotal += $row['amount'];

                $payment = $this->matchPayment($row);
                $matchStatus = $this->determineMatchStatus($payment, $row);
```

**Evidence**
```
$ grep -n "matchPayment" Modules/Payment/app/Services/PaymentReconciliationService.php
57:                $payment = $this->matchPayment($row);
198:    public function matchPayment(array $row): ?Payment
# matchPayment() body (198-211) runs Payment::query()->first() — one query per call.
```

#### PRC-10 · M · QRY-07 — reconciliation lines are inserted one row at a time

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *bulk-write: `insert()` / `upsert()` / `whereIn(...)->update()`, not `create()` per row in a loop* |
| **Where** | `Modules/Payment/app/Services/PaymentReconciliationService.php:70-85` |
| **Root cause** | `PaymentReconciliationLine::create([…])` runs one INSERT per CSV row inside the loop. |
| **Consequence** | For N rows the system issues N INSERT statements instead of a handful of batched inserts — part of the same upload slow-down as PRC-09. |
| **Reproduce** | static only. |
| **Fix approach** | Build an array of line rows in the loop, then `PaymentReconciliationLine::insert($chunks)` in batches (e.g. `array_chunk($rows, 500)`), adding `created_at`/`updated_at` explicitly. |
| **Plan item** | PRC-10 in `02-fix-plan.md` §6 |

```php
// PaymentReconciliationService.php:70-85 — CURRENT
                if (! $dryRun) {
                    PaymentReconciliationLine::create([
                        'reconciliation_id'  => $recon->id,
                        'gateway_payment_id' => $row['gateway_payment_id'],
                        'gateway_order_id'   => $row['gateway_order_id'],
                        'transaction_date'   => $row['transaction_date'],
                        'amount'             => $row['amount'],
                        'fee'                => $row['fee'],
                        'net_amount'         => $row['net_amount'],
                        'matched_payment_id' => $payment?->id,
                        'match_status'       => $matchStatus,
                        'notes'              => $this->buildNotes($payment, $row),
                        'is_active'          => true,
                        'created_by'         => $this->getUserId(),
                    ]);
                }
```

**Evidence**
```
$ grep -n "PaymentReconciliationLine::create" Modules/Payment/app/Services/PaymentReconciliationService.php
71:                    PaymentReconciliationLine::create([
```

#### PRC-11 · M · ERR-06 — malformed CSV rows are silently skipped, so totals quietly under-count

| Field | Value |
|---|---|
| **Rule** | ERR-06 (H in the rulebook; lowered to M here because it needs a malformed input row and nothing is lost that the operator cannot re-upload) — *no swallowed failures on a write path* |
| **Where** | `Modules/Payment/app/Services/PaymentReconciliationService.php:160-165` |
| **Root cause** | A row with fewer columns than the header is dropped with `continue;` and no record. The reconciliation then reports the survivors as if the file had only those rows — the tally, the expected/settled totals and the "total_rows" stored on the record all silently exclude the skipped lines. |
| **Consequence** | An accountant sees a "matched" or "discrepant" reconciliation that under-reports the settlement, with no warning that part of the file was discarded. A wrong money figure is presented as complete. |
| **Reproduce** | Upload a CSV whose last row has one column missing — the row does not appear in the detail table and is not counted anywhere. |
| **Fix approach** | Count the skipped rows and surface them (e.g. include `skipped_rows` in `bank_statement_json`, and either log at warning level or fail the upload with a fixed message when any row is malformed). |
| **Plan item** | PRC-11 in `02-fix-plan.md` §3 |

```php
// PaymentReconciliationService.php:160-165 — CURRENT
        while (($line = fgetcsv($handle)) !== false) {
            $line = array_map('trim', $line);

            if (count($line) < count($headers)) {
                continue; // skip malformed rows
            }
```

**Evidence**
```
$ grep -n "continue;" Modules/Payment/app/Services/PaymentReconciliationService.php
164:                continue; // skip malformed rows
```

### F9 — Queries and performance

#### PRC-12 · M · QRY-05 — `show()` loads every line and counts them in PHP

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M) — *aggregate in SQL (`withCount`, `selectRaw`), not `->get()->groupBy()` / `->count()` over a loaded collection* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:54-59` |
| **Root cause** | `$reconciliation->lines` is materialised (all columns of all lines) and then filtered four times in PHP for the summary cards. The same four numbers can be produced by a single grouped `count(*)` query, and the loaded collection is also re-iterated by the view. |
| **Consequence** | A reconciliation with thousands of lines loads all of them just to display four numbers and a table; memory and time grow with the CSV size. |
| **Reproduce** | static only — a performance defect with no error. |
| **Fix approach** | Add a grouped count (`PaymentReconciliationLine::where('reconciliation_id', $id)->selectRaw('match_status, count(*) as total')->groupBy('match_status')->pluck('total', 'match_status')`) for the summary, and paginate the lines table separately for display. |
| **Plan item** | PRC-12 in `02-fix-plan.md` §6 |

```php
// PaymentReconciliationController.php:54-59 — CURRENT
        $summary = [
            'total'     => $reconciliation->lines->count(),
            'matched'   => $reconciliation->lines->where('match_status', 'matched')->count(),
            'unmatched' => $reconciliation->lines->where('match_status', 'unmatched')->count(),
            'mismatch'  => $reconciliation->lines->where('match_status', 'amount_mismatch')->count(),
        ];
```

**Evidence**
```
$ grep -n "lines->\|->lines" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php
55:            'total'     => $reconciliation->lines->count(),
56:            'matched'   => $reconciliation->lines->where('match_status', 'matched')->count(),
57:            'unmatched' => $reconciliation->lines->where('match_status', 'unmatched')->count(),
58:            'mismatch'  => $reconciliation->lines->where('match_status', 'amount_mismatch')->count(),
```

#### PRC-13 · M · QRY-13 — the list paginates at 20, not the house standard of 10

| Field | Value |
|---|---|
| **Rule** | QRY-13 (M here — house pagination standard; the rulebook default for the family is L) — *lists paginate at the house standard (10) with a distinct page name* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:35-37` |
| **Root cause** | `->paginate(20)` uses 20 per page; every other audited list in the module uses 10. No `pageName` is set, so a second paginator on the page would collide. |
| **Consequence** | The list is inconsistent with the rest of the backend; a second list on the same page would share the `page` query parameter. |
| **Reproduce** | static only. |
| **Fix approach** | Change to `->paginate(10, ['*'], 'reconciliationPage')->withQueryString()`. |
| **Plan item** | PRC-13 in `02-fix-plan.md` §6 |

```php
// PaymentReconciliationController.php:35-37 — CURRENT
        $reconciliations = PaymentReconciliation::with('gateway')
            ->latest()
            ->paginate(20);
```

**Evidence**
```
$ grep -n "paginate" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php
37:            ->paginate(20);
```

### F10 — Views

#### PRC-14 · B · VIEW-04 — both views extend a layout that does not exist (500 on every load)

| Field | Value |
|---|---|
| **Rule** | VIEW-04 (B) — no rulebook line; from protocol F10 (`final-audit.md` §6): *"Blades must compile." An `@extends` whose target is missing throws `InvalidArgumentException` — a crash on a normal user path, so B.* |
| **Where** | `Modules/Payment/resources/views/reconciliation/index.blade.php:1` and `show.blade.php:1` |
| **Root cause** | The `prime` view namespace resolves only to `Modules/Prime/resources/views`, which has no `layouts/` directory; only `prime::components.layouts.master` exists. Both views extend the missing `prime::layouts.master`. This is the same defect reported by `tarun/Payment-done/BackendPaymentController` (BPA-01) and `tarun/Payment-done/BackendRefundController` (BRF-01) for the other Payment views. |
| **Consequence** | Opening the reconciliation list or a reconciliation detail throws a 500 before any content is shown — both pages are down. |
| **Reproduce** | Open `/payment/payment/reconciliation` — Laravel reports `View [layouts.master] not found`. |
| **Fix approach** | Choose a resolvable parent — see the decision PRC-14 in the plan (option (a) mirrors BPA-01: point the views at `backend.layouts.master` and fold `content_header` into `content`). |
| **Plan item** | PRC-14 in `02-fix-plan.md` §1 (DECISION) |

```blade
@extends('prime::layouts.master')
```

**Evidence**
```
$ php -r '…foreach(["prime::layouts.master","prime::components.layouts.master"] as $v){ echo $v." => ".(view()->exists($v)?"EXISTS":"MISSING")."\n"; }'
prime::layouts.master => MISSING
prime::components.layouts.master => EXISTS

$ ls Modules/Prime/resources/views/ | grep -i layout
(no output — there is no layouts/ directory in the prime namespace)
```

#### PRC-15 · H · VIEW-01 — a `PaymentGateway` query runs inside the Blade upload form

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H) — *no queries in Blade; pass data from the controller* |
| **Where** | `Modules/Payment/resources/views/reconciliation/index.blade.php:91` |
| **Root cause** | The modal's gateway `<select>` is fed by `\Modules\Payment\Models\PaymentGateway::where('is_active', true)->get()` called directly in the template. The controller passes no gateway list. |
| **Consequence** | A model query runs in the view layer, loading every column of every active gateway on each render, and the presentation of the form depends on the model — the query cannot be seen or cached by the controller. |
| **Reproduce** | static only — the scanner confirms the query; no error is thrown. |
| **Fix approach** | Query the gateways in `index()` (`PaymentGateway::where('is_active', true)->pluck('name', 'id')`) and pass them to the view; iterate the passed collection. |
| **Plan item** | PRC-15 in `02-fix-plan.md` §7 |

```blade
                            @foreach(\Modules\Payment\Models\PaymentGateway::where('is_active', true)->get() as $gw)
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-prc.json Modules/Payment/resources/views/reconciliation/index.blade.php
H  VIEW-01  Modules/Payment/resources/views/reconciliation/index.blade.php:91  - — query inside @foreach: @foreach(\Modules\Payment\Models\PaymentGateway::where('is_active', true)->get() as $gw)
```

#### PRC-16 · M · UI-STD — the row action is a hand-rolled anchor, not `x-backend.table.action`

| Field | Value |
|---|---|
| **Rule** | UI-STD (M) — Table Action Standard §1: *a list row's actions are always `<x-backend.table.action>`; never hand-rolled* |
| **Where** | `Modules/Payment/resources/views/reconciliation/index.blade.php:61-64` |
| **Root cause** | The single "View" row action is a plain `<a class="btn …">`, so it carries no permission gate and no `Route::has()` guard from the standard component. The standard's `view` action covers exactly this case. |
| **Consequence** | The row markup drifts from every other list and, combined with PRC-06, a bad route name crashes the row instead of degrading gracefully. |
| **Reproduce** | static only — a markup-standard deviation. |
| **Fix approach** | Replace the anchor with `<x-backend.table.action :model="$recon" :route="route('payment.payment.reconciliation.show', $recon->id)" />` (or the component's documented view action). |
| **Plan item** | PRC-16 in `02-fix-plan.md` §7 |

```blade
                                    <td>
                                        <a href="{{ route('payment.reconciliation.show', $recon->id) }}"
                                           class="btn btn-sm btn-outline-primary">View</a>
                                    </td>
```

**Evidence**
```
$ grep -n "x-backend.table.action" Modules/Payment/resources/views/reconciliation/index.blade.php
(no output)
```

### F11 — Security and tenancy

clean — `grep -n "env(" Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php Modules/Payment/app/Services/PaymentReconciliationService.php` → no output; the routes carry `InitializeTenancyByDomain` + `EnsureTenantHasModule:Payment`; no request body is logged; no personal data is returned by `show()`.

### F12 — Style

#### PRC-17 · L · STY-02 — the controller import block is not Pint-sorted (blank line between every import)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean: sorted imports, no stray blank lines between imports* |
| **Where** | `Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:7-20` |
| **Root cause** | Every `use` statement is separated by a blank line and the block is not alphabetised, so `vendor/bin/pint` would rewrite it. |
| **Consequence** | Style only — no runtime effect. |
| **Reproduce** | static only. |
| **Fix approach** | Replace the import block with the sorted, contiguous version in the plan. |
| **Plan item** | PRC-17 in `02-fix-plan.md` §8 |

```php
// PaymentReconciliationController.php:7-12 — CURRENT
use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\DB;
```

**Evidence**
```
$ sed -n '7,20p' Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php
use Illuminate\Database\Eloquent\ModelNotFoundException;
(blank)
use Illuminate\Support\Facades\Log;
(blank)
use Illuminate\Support\Facades\DB;
(blank)
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Gate;
use Illuminate\View\View;
use Modules\Payment\Models\PaymentGateway;
use Modules\Payment\Models\PaymentReconciliation;
use Modules\Payment\Services\PaymentReconciliationService;
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicate impl | 4 Soft-delete×unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok | ok | ok | PRC-06 | PRC-18 |
| `resolve` | ok | ok | ok | ok | ok | ok | PRC-06 | — |
| `reconcile` (service) | ok | ok | ok | ok | ok | n/a | PRC-11 | — |

- **Q7 for `store`/`resolve`**: the success redirect throws because the route name is wrong (PRC-06); `store` then tells the user "The reconciliation could not be completed" although the rows were saved, and `resolve` rolls back. This is the "message lies" answer.
- **Q8**: `PaymentReconciliation::computeDiscrepancy()` is never called (PRC-18).

#### PRC-18 · L · CTL-10 — dead method `computeDiscrepancy()` on the reconciliation model

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M in the rulebook; lowered to L here — a one-line convenience method in a model, no runtime effect) — *no dead code* |
| **Where** | `Modules/Payment/app/Models/PaymentReconciliation.php:81-84` |
| **Root cause** | `computeDiscrepancy()` exists but no caller anywhere in the module; the service computes `discrepancy` inline instead (`round($expectedTotal - $settledTotal, 2)`). |
| **Consequence** | None at runtime; it is a second, unused implementation of the same calculation, inviting divergence. |
| **Reproduce** | static only. |
| **Fix approach** | Either delete it, or call it from the service so there is one implementation (the DDD-clean option). Deleting is the smaller change. |
| **Plan item** | PRC-18 in `02-fix-plan.md` §8 |

```php
// PaymentReconciliation.php:81-84 — CURRENT
    public function computeDiscrepancy(): void
    {
        $this->discrepancy = round($this->expected_amount - $this->settled_amount, 2);
    }
```

**Evidence**
```
$ grep -rn "computeDiscrepancy" Modules/Payment
Modules/Payment/app/Models/PaymentReconciliation.php:81:    public function computeDiscrepancy(): void
# only the definition — no caller
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Prime/resources/views/**` | the `prime::layouts.master` name consumers extend does not exist; only `prime::components.layouts.master` does. Both reconciliation views and the other four Payment views hit it. Tracked as the BPA-01 / BRF-01 family. | VIEW-04 | Prime module owner (module-wide layout decision) |
| `Modules/Payment/app/Providers/RouteServiceProvider.php` | `->name('payment.')` (line 54) doubles the `payment.` prefix declared in `routes/web.php:33` (and `:12`), so names like `payment.reconciliation.*` and `payment.backend.*` do not exist. Tracked as the BPA-02 family. | RTE-02 | Payment module owner |

## 8. Not covered, and why

- **Live row counts** (`ptm_payment_reconciliations`, `ptm_reconciliation_lines`) were not measured — no tenant DB session was opened in this read-only pass.
- **`glb_menus` trail** for the reconciliation screen was not queried, so the menu path in §0 is unmeasured.
- **The console command `ReconcileGatewaySettlements`** (`Modules/Payment/app/Console/Commands/`) is not reached by this controller; it calls the same service and is out of scope for this report. Its own `error()` call to the console is not a user-facing leak.
- **The `dryRun = true` path** of `reconcile()` is only driven by the console command, never by this controller, so it was not exercised.
- **Browser rendering** could not be verified (protocol D4): the `@extends` crash and the route-name crash are proven statically and by `route:list` / `view()->exists()`, not by loading the page.
- **No policy** is consulted by this controller (it uses string gates), so the F3 check covered the controller and view surfaces and `config/permissionslist.php` only.
- **No queue jobs, listeners or events** are involved in this controller.
