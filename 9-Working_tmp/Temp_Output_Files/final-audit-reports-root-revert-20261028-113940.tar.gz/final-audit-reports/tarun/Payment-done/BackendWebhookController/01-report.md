# Final Audit — Payment / Backend\WebhookController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/Payment/app/Http/Controllers/Backend/WebhookController.php` (27 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://SCHOOL-HOST/payment/payment-webhooks` — the only page this controller renders. The source declares the name `payment.backend.webhooks.index`, but the module provider prepends its own `payment.` name prefix (`RouteServiceProvider.php:54`), so the registered name is `payment.payment.backend.webhooks.index` (see §7). |
| Menu path | Finance. `app/Services/Breadcrumbs/registry.php:2692` carries `payment.payment.backend.webhooks.index` with parent `dashboard.finance`. No `glb_menus` seeder entry for webhooks was found in the repo. |
| Who uses it | The page is gated by `tenant.payment.reconciliation.viewAny` (the reconciliation permission, not a webhook one — BWH-02). `config/permission_role_defaults.php` has no payment entries, so by the project rule (`AUTO_GRANT_ROLES = [Super Admin, School Admin]`) only those two roles hold it by default. |
| What a user does here | A school admin opens a read-only table of every inbound payment-gateway webhook: its numeric id, gateway name, event type, the payment ULID it maps to, whether the HMAC signature validated, whether it has been processed, and when it arrived. There is no create, edit, delete, restore or row action on this page. |
| Tables written | none — the method is read-only. |
| Tables read | `ptm_payment_webhooks` (the list) and `ptm_payment_payments` (the `payment.ulid` shown per row, via the eager load `payment`). |
| Live data | not measured — no tenant DB session was opened in this read-only pass (see §8). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Not production-ready — the page does not open at all.** The controller is tiny and correct in shape: it authorizes before querying, it eager-loads the `payment` relation the view reads, it has no `try`/`catch`, and it returns a typed `View`. But the view it renders extends a layout that does not exist (`prime::layouts.master`), so `GET /payment/payment-webhooks` throws a 500 before the controller's output is ever shown (**BWH-01**, the single worst finding). Behind that, the page is gated by an unrelated feature's permission — there is no `payment.webhook` key at all, so viewing webhooks is governed by reconciliation rights (**BWH-02**) — and the list paginates 20 rows with no page name where the house standard is 10 (**BWH-03**). One low item remains (a missing breadcrumb). Rough effort to work the plan: **S — about half a day**, with two items held as decisions for Tarun (the shared layout, and whether a dedicated webhook permission is created).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 0 | 2 | 1 | 2 | 4 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | n/a — no service or job in scope |
| F2 Transactions/Audit | clean — read-only, no writes | F9 Queries/Perf | BWH-03 |
| F3 Authorization | BWH-02 | F10 Views | BWH-01, BWH-04 |
| F4 Validation | clean — no request input | F11 Security/Tenancy | clean — see §7 |
| F5 Routes | clean — see §4 | F12 Style | clean |
| F6 Controller shape | clean | F13 Deep read | clean — no mutating method |
| F7 Models | ↗ linked — see §3 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Payment/app/Http/Controllers/Backend/WebhookController.php` | controller | 27 | this report | ✅ |
| 2 | `Modules/Payment/resources/views/webhooks/index.blade.php` | view (used only here) | 67 | this report | ✅ |
| 3 | `Modules/Payment/app/Models/PaymentWebhook.php` | model | 43 | ↗ [tarun/Payment-done/WebhookController](../WebhookController/01-report.md) | ↗ linked |
| 4 | `Modules/Payment/app/Models/Payment.php` | model | 101 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 5 | `Modules/Payment/routes/web.php` | route file (the one webhook route) | 38 | shared route file (§4.2, "common") | ❌ inspected only — confirms the route at line 19 |
| 6 | `Modules/Payment/app/Providers/RouteServiceProvider.php` | provider | 95 | common module glue (§4.2) | ❌ inspected only — confirms the `payment.` name prefix and tenant middleware |
| 7 | `Modules/Payment/app/Providers/PaymentServiceProvider.php` | provider | 212 | common module glue (§4.2) | ❌ inspected only — owns the reconciliation gate definitions (see §7) |
| 8 | `config/permissionslist.php` | config (shared) | — | common (shared) | ❌ inspected only — confirms no webhook key exists (BWH-02) |
| 9 | `app/Services/Breadcrumbs/registry.php` | app glue | — | common | ❌ inspected only — confirms the trail entry at line 2692 |

The view in row 2 is now claimed in `_Info/00-CLASS-OWNERS.md` (appended 2026-10-19). Rows 3-4 were already owned elsewhere (pre-assigned by the main session); they are linked, not re-audited. Rows 5-9 are common per §4.2 and are never fixed by this workflow.

No pre-applied files for this controller (only TimetableFoundation has a `PRE-APPLIED-2026-10-10.md`).

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '... Backend\WebhookController ...'
GET|HEAD  payment/payment-webhooks   payment.payment.backend.webhooks.index   Modules\Payment\Http\Controllers\Backend\WebhookController@index
```

Unrouted public methods: none. `index` is the only public method and it is routed. There is no constructor.

Middleware group (`Modules/Payment/app/Providers/RouteServiceProvider.php:44-52`, `mapWebRoutes()`): `web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Payment`, `auth`, `verified`. Tenant middleware present — F5 clean. The webhook *ingestion* routes in `routes/webhooks.php` are registered separately without `auth`; this *view* route is not one of them.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | GET `payment/payment-webhooks` (name `payment.payment.backend.webhooks.index`) | `tenant.payment.reconciliation.viewAny` | none (read) | none | none — read-only | BWH-01, BWH-02, BWH-03, BWH-04 |

## 6. Findings

### F1 — Errors

clean — `grep -nE "try \{|catch \(|getMessage|withErrors|Log::" Modules/Payment/app/Http/Controllers/Backend/WebhookController.php` → no output. The only method is a read path with no error handling to get wrong.

### F2 — Transactions and audit

clean — the controller has no write path: `grep -nE "DB::|->create\(|->update\(|->delete\(|->save\(|activityLog" Modules/Payment/app/Http/Controllers/Backend/WebhookController.php` → no output.

### F3 — Authorization

#### BWH-02 · M · AUTH-06 — the webhook list is gated by an unrelated *reconciliation* permission; no webhook permission exists

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy or constants — not repeated as literals; and the name must identify the feature it protects* (`scope.module.feature.action`). |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/WebhookController.php:19`, method `index()` |
| **Root cause** | The controller authorizes with the raw literal `'tenant.payment.reconciliation.viewAny'`. That key is declared in `config/permissionslist.php:1133` as `payment.reconciliation` — a *different* feature (the reconciliation screen). There is **no** `payment.webhook` key anywhere in the config, so webhooks have no permission of their own and are governed by whoever can view reconciliation. The literal is also duplicated (the API reconciliation controller and the reconciliation backend controller use the same string), so a permission rename would silently disagree across three screens. |
| **Consequence** | Access to webhook data is coupled to reconciliation rights. Any role granted reconciliation-view can read the webhook log, and a role that should see webhooks cannot unless it is also granted reconciliation — the two features cannot be separated without a code change. No wrong result today (only Super Admin/School Admin hold the key by default), but the authorization metadata does not describe what it protects. |
| **Reproduce** | Static only — the page 500s first (BWH-01), and separating the permissions is a design change, which this read-only audit cannot stage (D4). |
| **Fix approach** | Give webhooks their own key (see BWH-02 in the plan — a DECISION, because a new permission key needs `config/permissionslist.php`, a reseed by Tarun and possibly a `glb_menus` edit) and gate with `tenant.payment.webhook.viewAny`. If Tarun decides webhooks are genuinely a reconciliation concern, the alternative is to keep this gate and record it as accepted. |
| **Plan item** | BWH-02 in `02-fix-plan.md` §4 (DECISION) |

```php
// WebhookController.php:19 — CURRENT
        Gate::authorize('tenant.payment.reconciliation.viewAny');
```

**Evidence**
```
$ grep -rniE "webhook" config/permissionslist.php
(no output)                       # no payment.webhook key exists

$ grep -n "tenant.payment.reconciliation.viewAny" Modules/Payment --include=*.php --include=*.blade.php
Modules/Payment/resources/views/index.blade.php:10        ['permission' => 'tenant.payment.reconciliation.viewAny'],
Modules/Payment/resources/views/index.blade.php:16            @can('tenant.payment.reconciliation.viewAny')
Modules/Payment/app/Providers/PaymentServiceProvider.php:51            'tenant.payment.reconciliation.viewAny',
Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:33        Gate::authorize('tenant.payment.reconciliation.viewAny');
Modules/Payment/app/Http/Controllers/Backend/WebhookController.php:19        Gate::authorize('tenant.payment.reconciliation.viewAny');

$ sed -n '1133p' config/permissionslist.php
        'payment.reconciliation' => array_merge($crud, ['resolve', 'export']),
# flatten() prepends the scope: payment.reconciliation.viewAny -> tenant.payment.reconciliation.viewAny (declared + seeded)
```

### F4 — Validation and input

clean — the method takes no input. `grep -nE "Request|validate|all\(\)|except\(|input\(" Modules/Payment/app/Http/Controllers/Backend/WebhookController.php` → no output.

### F5 — Routes

clean — one route (GET `payment/payment-webhooks`) points at the existing `index()`, the method is routed, there is no state change over GET, the route sits inside the tenancy + `auth` + `verified` group (§4), and there is no `Route::resource` prefix to collide with. Evidence: §4 route output and `grep -nE "public function" Modules/Payment/app/Http/Controllers/Backend/WebhookController.php` → `index` at line 17. (The source route name is doubled by the provider prefix — recorded in §7, not a defect here.)

### F6 — Controller shape

clean — 27 lines and 1 public method (thresholds 1,000 lines / 25 methods), the method is 10 lines (threshold 80), it returns the declared `: View`, `compact()` is called with one variable, no `request()` helper, no `dd()`/`dump()`, no dead code. Evidence: `wc -l` 27 and `grep -nE "public function|compact|request\(\)|dd\(|dump\(" Modules/Payment/app/Http/Controllers/Backend/WebhookController.php` → `index` at line 17 and `compact('webhooks')` at line 25.

### F7 — Models

↗ linked — `PaymentWebhook` is owned by `tarun/Payment-done/WebhookController` and `Payment` by `tarun/ParentPortal-done/ParentFeePaymentController`; neither was re-audited. Usage checked here: the eager load `with('payment')` resolves because `PaymentWebhook::payment()` is a return-typed `BelongsTo` (line 39-42) and `payment_id` is nullable, so a webhook that arrived before its payment resolves still renders the em-dash branch in the view. `$table = 'ptm_payment_webhooks'` matches the migration `database/migrations/tenant/2026_06_18_100106_create_ptm_payment_webhooks_table.php`; the view's columns (`event_type`, `gateway`, `signature_valid`, `processed`, `created_at`) all exist there. No `InteractsWithMedia`, no `$guarded = []`. See §3 rows 3-4.

### F8 — Services and jobs

n/a — this controller injects nothing and calls no service, job, event or listener; it queries the model directly. `grep -nE "Service|Job|event\(|dispatch|app\(" Modules/Payment/app/Http/Controllers/Backend/WebhookController.php` → no output.

### F9 — Queries and performance

#### BWH-03 · M · QRY-13 — the list paginates 20 rows with no page name (house standard is 10)

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L default, raised to M here to match the sibling `Backend/PaymentController` report BPA-04 and the protocol F9 note on C12 — *lists paginate at 10 with a distinct `pageName` per list*) — *filtered paginators keep filters and use distinct page names; the house list standard is 10 rows*. |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/WebhookController.php:21-23`, method `index()` |
| **Root cause** | `->paginate(20)` uses the default 20 rows and the default page name (`page`). The Payment module's local norm is mixed (paginate(20) in three controllers, 15 in two, 10 in one) while the house/estate standard is 10 with a distinct page name per list (C12). Only one paginator appears on this page, so the missing `pageName` is latent rather than active today; the count of 20 is the actual deviation. |
| **Consequence** | The admin loads up to 20 webhook rows where the estate standard loads 10 — more work per request and an inconsistent page size next to the payment-gateway lists. No wrong result. |
| **Reproduce** | Open `http://SCHOOL-HOST/payment/payment-webhooks` once BWH-01 is fixed — the page shows up to 20 rows instead of the house 10. |
| **Fix approach** | Change to `paginate(10, ['*'], 'webhooksPage')`. No view change is needed; `{{ $webhooks->links() }}` reads the page name from the paginator. |
| **Plan item** | BWH-03 in `02-fix-plan.md` §6 |
| **Evidence** | `grep -rn "paginate(" Modules/Payment/app/Http/Controllers/` (output below) |

```php
// WebhookController.php:21-23 — CURRENT
        $webhooks = PaymentWebhook::with('payment')
            ->latest()
            ->paginate(20);
```

**Evidence**
```
$ grep -rn "paginate(" Modules/Payment/app/Http/Controllers/
Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:37:            ->paginate(20);
Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:48:            ->paginate(15, ['*'], 'gateway_page')
Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:65:            ->paginate(15, ['*'], 'history_page')
Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:245:            ->paginate(10);
Modules/Payment/app/Http/Controllers/Backend/RefundController.php:39:            ->paginate(20);
Modules/Payment/app/Http/Controllers/Backend/WebhookController.php:23:            ->paginate(20);
Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:34:            ->paginate(20);
```

### F10 — Views

#### BWH-01 · B · VIEW-04 — the webhook page extends a layout that does not exist (500 on every load)

| Field | Value |
|---|---|
| **Rule** | VIEW-04 (B) — no rulebook line; from protocol F10 (`final-audit.md` §6): *"Blades must compile."* An `@extends` whose target does not resolve throws `InvalidArgumentException` — a crash on a normal user path, so **B**. (Same rule ID and root cause as BPA-01 in the sibling `Backend/PaymentController` report and BRF-01 in `Backend/RefundController`.) |
| **Where** | `Modules/Payment/resources/views/webhooks/index.blade.php:1`, the view rendered by `index()` at line 25 |
| **Root cause** | The `prime` view namespace resolves only to `Modules/Prime/resources/views` (verified from the view finder hints). There is no `layouts/` directory there, so `prime::layouts.master` cannot be resolved. Only `prime::components.layouts.master` exists, and `backend.layouts.master` (`resources/views/backend/layouts/master.blade.php`) is the usable backend layout. The identical broken `@extends` sits in five other Payment backend views (see §7). |
| **Consequence** | Opening `/payment/payment-webhooks` throws `View [layouts.master] not found` — a 500 before any webhook row is shown. The webhook page is completely down. |
| **Reproduce** | Open `http://SCHOOL-HOST/payment/payment-webhooks` as a role holding the reconciliation-view permission; Laravel reports `View [layouts.master] not found`. Static proof below (D4 — no browser/tenant session was opened). |
| **Fix approach** | Point the view at a layout that resolves (see BWH-01 in the plan — a DECISION, because the layout target is shared and the same break is owned by the sibling Payment reports). Recommended: the one-line change to `@extends('backend.layouts.master')` for this view, matching BPA-01/BRF-01 option (a); the `content_header` block then becomes unused because that layout yields only `content`, so fold the heading into `content`. |
| **Plan item** | BWH-01 in `02-fix-plan.md` §1 (DECISION) |
| **Evidence** | `view()->exists()` probes (output below) |

```blade
@extends('prime::layouts.master')

@section('title', 'Payment Webhooks')

@section('content_header')
    <h5 class="mb-0">Payment Webhooks</h5>
@endsection
```

**Evidence**
```
$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); foreach(["prime::layouts.master","prime::components.layouts.master","backend.layouts.master"] as $v){ echo $v." => ".(view()->exists($v)?"EXISTS":"MISSING")."\n"; }'
prime::layouts.master => MISSING
prime::components.layouts.master => EXISTS
backend.layouts.master => EXISTS
prime hint: [".../Modules/Prime/resources/views"]     # no layouts/ subdirectory exists

$ grep -rln "@extends('prime::layouts.master')" Modules --include=*.blade.php
Modules/Payment/resources/views/payments/show.blade.php
Modules/Payment/resources/views/payments/index.blade.php
Modules/Payment/resources/views/reconciliation/show.blade.php
Modules/Payment/resources/views/reconciliation/index.blade.php
Modules/Payment/resources/views/webhooks/index.blade.php
Modules/Payment/resources/views/refunds/index.blade.php
```

#### BWH-04 · L · UI-STD — the webhook page renders no breadcrumb

| Field | Value |
|---|---|
| **Rule** | UI-STD (L) — Breadcrumb Standard §1: every backend page renders `<x-backend.components.breadcrum>`. (Same rule and shape as BPA-08 in the sibling `Backend/PaymentController` report and BRF-04 in `Backend/RefundController`.) |
| **Where** | `Modules/Payment/resources/views/webhooks/index.blade.php:9-11` |
| **Root cause** | The view defines only `content_header` (a plain heading) and `content`; it never includes the breadcrumb component. Even once BWH-01 is fixed, the layout it would extend (`backend.layouts.master`) does not inject a breadcrumb either, so the trail is absent by construction. The registry already carries an entry for this route (`app/Services/Breadcrumbs/registry.php:2692`, parent `dashboard.finance`), so the trail is ready to render. |
| **Consequence** | A user cannot see where the Webhooks page sits in the Finance area of the module tree; only the browser back button leaves the page. |
| **Reproduce** | Once BWH-01 is fixed, open `http://SCHOOL-HOST/payment/payment-webhooks` — no breadcrumb trail is rendered. |
| **Fix approach** | Add `<x-backend.components.breadcrum title="Payment Webhooks" :links="[]" />` as the first line of `@section('content')`. The parent links are resolved by the registry entry, so no extra data is needed. |
| **Plan item** | BWH-04 in `02-fix-plan.md` §7 |
| **Evidence** | `grep -n "breadcrum" ...` and the registry entry (output below) |

```blade
// webhooks/index.blade.php:9-11 — CURRENT
@section('content')
    <div class="card">
        <div class="card-body">
```

**Evidence**
```
$ grep -n "breadcrum" Modules/Payment/resources/views/webhooks/index.blade.php
(no output)

$ sed -n '2691,2694p' app/Services/Breadcrumbs/registry.php
    // S3_SIBLING
    'payment.payment.backend.webhooks.index' => [
        'parent' => 'dashboard.finance',
    ],
```

### F11 — Security and tenancy

clean — no `env()` (`grep -n "env(" Modules/Payment/app/Http/Controllers/Backend/WebhookController.php` → no output), no hard-coded ids or `?? 1`, no logging of request data, no service locator. The route sits inside the tenancy middleware group (§4), so the query runs against the tenant connection. The view prints only scalar columns through `{{ }}` and never renders the `payload` JSON column, so no gateway payload or signature secret is exposed. `grep -nE "\{!!|payload" Modules/Payment/resources/views/webhooks/index.blade.php` → no output.

### F12 — Style

clean — the controller is Pint-clean (`vendor/bin/pint --test Modules/Payment/app/Http/Controllers/Backend/WebhookController.php` → `{"tool":"pint","result":"passed"}`), already carries `declare(strict_types=1);` (line 3), imports are sorted (lines 7-10), the docblock is plain English with no emoji, and there is no commented-out code or aliased import.

### F13 — Deep read (answer all 8 questions for every mutating method)

No mutating methods — `index()` is the only method and it is read-only (no `save`, `update`, `create`, `delete`, `activityLog`). The eight questions (wrong-data overwrite, delete-before-store, duplicate implementation, soft-delete × unique index, race, authorization hole, lying message, dead feature) are therefore `n/a` for every method. The one question that can apply to a read — **authorization** — is captured as BWH-02: no role reads webhooks that cannot already read reconciliation, and no additional role sees data beyond the webhook log columns listed in §0.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Payment/resources/views/payments/index.blade.php`, `payments/show.blade.php`, `reconciliation/index.blade.php`, `reconciliation/show.blade.php`, `refunds/index.blade.php` | All five extend the same missing `prime::layouts.master` as BWH-01, so they also 500. | VIEW-04 | `tarun/Payment-done/BackendPaymentController` (BPA-01), `tarun/Payment-done/PaymentReconciliationController`, `tarun/Payment-done/BackendRefundController` (BRF-01) |
| `Modules/Payment/routes/web.php:19` | Declares the name `payment.backend.webhooks.index`, but the module provider's own `payment.` name prefix (`RouteServiceProvider.php:54`) doubles it, so the registered name is `payment.payment.backend.webhooks.index`. The breadcrumb registry already uses the doubled form; any consumer must use the doubled name. | RTE-02 | module owner (route file is shared) |
| `Modules/Payment/app/Providers/PaymentServiceProvider.php:57-61` | `registerGates()` defines `tenant.payment.reconciliation.viewAny` (and the sibling abilities) as `Gate::define($ability, fn ($user) => $user->can($ability))`. For a user who does **not** hold the permission and is not a Super Admin, the Spatie `Gate::before` returns null, the ability callback then calls `$user->can($ability)`, which re-enters the same Gate — a recursion risk (stack overflow / 500 instead of a clean 403). ⚠ UNVERIFIED — D4 forbids exercising the route; it would be settled by opening the page as a tenant user whose role lacks the permission. The same gate is reached by `PaymentReconciliationController` and by this controller's BWH-02 gate. | AUTH-01 / F13-6 | the module provider owner (common module glue; the shared root is the provider, not this controller) |
| `config/permissionslist.php` | No `payment.webhook` key exists; the webhook screen borrows `payment.reconciliation`. | AUTH-06 | recorded as BWH-02 (DECISION) |

## 8. Not covered, and why

- **The rendered page in a browser** — the route sits behind `auth` + tenancy middleware, so no tenant session was opened (D4). The 500 was proved with `view()->exists()` and the view's first line, not by loading the page.
- **Live row counts** — the tenant database was not opened in this read-only pass; the counts table in §0 is therefore "not measured".
- **The five sibling views' breadcrumbs and rows** — owned by other reports (§7).
- **The gate-recursion risk** — flagged in §7 as ⚠ UNVERIFIED; exercising it would require a logged-in non-privileged tenant user (D4).
- **`PaymentWebhook`/`Payment` internals** — owned elsewhere and linked in §3; only this controller's *usage* of them was checked.
