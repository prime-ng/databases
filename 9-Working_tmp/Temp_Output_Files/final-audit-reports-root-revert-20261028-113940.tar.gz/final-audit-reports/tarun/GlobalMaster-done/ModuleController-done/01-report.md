# Final Audit — GlobalMaster / ModuleController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php` (322 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/global-master/module` (list) · `/global-master/module/create` (create form) · `/global-master/module/{module}/edit` · `/global-master/module/{module}` (show) · `/global-master/module/trash/view` (trash) · `/global-master/module/{id}/restore` (restore) · `/global-master/module/{module}/toggle-status` (status switch) |
| Menu path | Foundation Setup → Sales Plan & Module Management → Modules tab (menu id 8, `central.prime.sales-plan-mgmt.index`); the module CRUD forms live on the `global-master/module/*` routes |
| Who uses it | Central (super-admin) staff. 9 roles hold `prime.global-master.module.*` today: Super Admin, Dev Team, App Maintenance, Finance & Billing, Sales Team, School Admin, Support Team, CRM Team, Demo |
| What a user does here | Lists the product modules of the platform (glb_modules), views one module with its menus, creates and edits a module, picks which menus hang off it, toggles its active state, and moves a module to trash; from the trash screen it can restore or permanently delete a module. Save actions bounce back to `central.prime.sales-plan-mgmt.index#modules` |
| Tables written | `glb_modules` (global_master), `glb_menu_module_jnt` (pivot: attach/sync/detach), `sys_central_activity_logs` (via `activityLog()`) |
| Tables read | `glb_modules`, `glb_menus` (menus of each module) |
| Live data | `glb_modules` 16 live, 0 trashed (connection `global_master_mysql`) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready**. The create screen cannot save a module at all: the `code` column of `glb_modules` is NOT NULL with no default, and neither the form nor `ModuleRequest` ever supplies it, so every `store()` hits a SQL error that the generic catch reduces to "The operation could not be completed." The single worst finding is that Blocker — a page that exists and is linked from the list header cannot perform its only action. On top of that, restore is a GET route that changes state with no CSRF, and the six mutation methods all wrap the Laravel transaction idiom in try/catch that hides real failures (D1). The model and request classes are small and mostly sound, but the model has one soft-delete pivot trap and a pivot-ordering defect. Rough effort for the whole plan: 3-5 developer-hours, plus four decisions Tarun must make (code population, restore route method, the unused `available_perm_*` columns, and whether to keep responses inside transactions).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 4 | 8 | 6 | 4 | 19 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | MOD-01, MOD-02, MOD-03, MOD-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | MOD-05 | F9 Queries/Perf | clean |
| F3 Authorization | MOD-06 | F10 Views | clean |
| F4 Validation | MOD-07, MOD-08, MOD-09, MOD-10 | F11 Security/Tenancy | clean |
| F5 Routes | MOD-11 | F12 Style | MOD-17, MOD-18, MOD-19 |
| F6 Controller shape | MOD-12, MOD-13 | F13 Deep read | MOD-20 |
| F7 Models | MOD-14, MOD-15 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php` | controller | 322 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Models/Module.php` | model | 98 | this report (claimed in _Info/00-CLASS-OWNERS.md) | ✅ |
| 3 | `Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php` | FormRequest | 81 | this report (claimed in _Info/00-CLASS-OWNERS.md) | ✅ |
| 4 | `Modules/GlobalMaster/resources/views/module/index.blade.php` | blade | 64 | this report | ✅ |
| 5 | `Modules/GlobalMaster/resources/views/module/create.blade.php` | blade | 70 | this report | ✅ |
| 6 | `Modules/GlobalMaster/resources/views/module/edit.blade.php` | blade | 72 | this report | ✅ |
| 7 | `Modules/GlobalMaster/resources/views/module/show.blade.php` | blade | 94 | this report | ✅ |
| 8 | `Modules/GlobalMaster/resources/views/module/trash.blade.php` | blade | 51 | this report | ✅ |
| 9 | `Modules/GlobalMaster/routes/web.php` | route file | ~150 | common (shared by all GlobalMaster controllers) | ☑ read for F5 wiring only |
| 10 | `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` | component | 54 | common (shared estate-wide) | ☑ read for F5; cross-cutting |
| 11 | `App\Traits\AuthorizesTenantFeature.php` | trait | 56 | common | ☑ referenced |
| 12 | `App\Models\BaseModel.php` | model base | 22 | common | ☑ referenced |
| 13 | `App\Http\Controllers\Controller.php` | base controller | — | common | ☑ referenced |

No pre-applied files (this module has no `PRE-APPLIED-*.md`).

**Owned elsewhere / linked:** none — `Modules/GlobalMaster/app/Models/Plan.php`, `Modules/Prime/app/Models/Tenant.php` and `TenantPlanModule.php` are reached only through relations the controller never executes; PlanController (later batch) owns them. `Modules\GlobalMaster\Models\Plan` is used bare in `Module::plans()` and resolves under the same namespace; it is not audited here.

## 4. Routes

```
GET|HEAD   global-master/module                          central.global-master.module.index        ModuleController@index
POST       global-master/module                          central.global-master.module.store        ModuleController@store
GET|HEAD   global-master/module/create                   central.global-master.module.create       ModuleController@create
GET|HEAD   global-master/module/trash/view               central.global-master.module.trashed      ModuleController@trashedModule
DELETE     global-master/module/{id}/force-delete        central.global-master.module.forceDelete  ModuleController@forceDelete
GET|HEAD   global-master/module/{id}/restore             central.global-master.module.restore      ModuleController@restore
GET|HEAD   global-master/module/{module}                 central.global-master.module.show         ModuleController@show
PUT|PATCH  global-master/module/{module}                 central.global-master.module.update       ModuleController@update
DELETE     global-master/module/{module}                 central.global-master.module.destroy      ModuleController@destroy
GET|HEAD   global-master/module/{module}/edit            central.global-master.module.edit         ModuleController@edit
POST       global-master/module/{module}/toggle-status   central.global-master.module.toggleStatus ModuleController@toggleStatus
```

Source: `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json`.

Unrouted public methods: **none** — all 11 public methods are routed (RTE-03 clean).

Route-parameter note: `restore`/`forceDelete` use `{id}`; `show`/`update`/`edit`/`destroy`/`toggleStatus` use `{module}`. The `$id`-typed methods bind positionally, so nothing is broken today.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 20 | GET /global-master/module | `prime.global-master.module.viewAny` | none | none | — (reads glb_modules, glb_menus) | MOD-13 |
| `create` | 31 | GET /global-master/module/create | `prime.global-master.module.create` | none | none | — | MOD-13 |
| `store` | 41 | POST /global-master/module | `prime.global-master.module.create` | controller closure (46) | 'Stored' | glb_modules, glb_menu_module_jnt, sys_central_activity_logs | MOD-01, MOD-03, MOD-05, MOD-06, MOD-07, MOD-08, MOD-09, MOD-10, MOD-13, MOD-20 |
| `show` | 81 | GET /global-master/module/{module} | `prime.global-master.module.view` | none | none | — | MOD-13 |
| `edit` | 92 | GET /global-master/module/{module}/edit | `prime.global-master.module.update` | none | none | — | MOD-12, MOD-13 |
| `update` | 103 | PUT /global-master/module/{module} | `prime.global-master.module.update` | controller closure (108) | 'Updated' | glb_modules, glb_menu_module_jnt, sys_central_activity_logs | MOD-01, MOD-03, MOD-05, MOD-06, MOD-08, MOD-09, MOD-10, MOD-13, MOD-20 |
| `destroy` | 175 | DELETE /global-master/module/{module} | `prime.global-master.module.delete` | controller closure (180) | 'Trashed' | glb_modules, sys_central_activity_logs | MOD-01, MOD-03, MOD-05, MOD-12, MOD-13 |
| `trashedModule` | 207 | GET /global-master/module/trash/view | `prime.global-master.module.restore` | none | none | — | MOD-13 |
| `restore` | 215 | GET /global-master/module/{id}/restore | `prime.global-master.module.restore` | controller closure (220) | 'Restored' | glb_modules, sys_central_activity_logs | MOD-01, MOD-03, MOD-05, MOD-11, MOD-13 |
| `forceDelete` | 243 | DELETE /global-master/module/{id}/force-delete | `prime.global-master.module.forceDelete` | controller closure (248) | 'Deleted' | glb_modules, glb_menu_module_jnt, sys_central_activity_logs | MOD-01, MOD-03, MOD-05, MOD-13 |
| `toggleStatus` | 275 | POST /global-master/module/{module}/toggle-status | `prime.global-master.module.update` | controller closure (280) | 'Toggled' | glb_modules, sys_central_activity_logs | MOD-01, MOD-02, MOD-03, MOD-04, MOD-05, MOD-13 |

## 6. Findings

### F1 — Errors

#### MOD-01 · H · ERR-00 — try/catch wraps the Laravel transaction idiom in all 6 mutating methods

| Field | Value |
|---|---|
| **Rule** | ERR-00 settled by D1 (H default) — *a controller try/catch is a finding; `DB::transaction(fn () => ...)` rolls back and rethrows, and the central handler in `bootstrap/app.php` renders* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php:45-75` (store), 107-169 (update), 179-202 (destroy), 219-240 (restore), 247-270 (forceDelete), 279-319 (toggleStatus) |
| **Root cause** | Every mutation is wrapped in `try { return DB::transaction(...) } catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { Log::error(...getMessage()); return back()->with('error', 'The operation could not be completed.'); }`. D1 allows no controller try/catch; D2's allowed shapes are `\DomainException`, the truncate-then-rebuild catch, or `SnapshotProtectionException` — none apply here. The `ModelNotFoundException` catch is dead weight (it only rethrows), and the generic catch hides every real failure — including the MOD-07 SQL error — behind a generic flash. |
| **Consequence** | Every write failure becomes a red flash "The operation could not be completed." instead of Laravel's diagnostic 500 page, so broken paths (like the missing-`code` create) look like user error and get re-tried forever. |
| **Reproduce** | Submit the create form; observe the generic red flash instead of the real SQL error (which the logs carry only as `getMessage()`). |
| **Fix approach** | Remove the `try`/`catch` wrappers from all six methods (D1). `DB::transaction` keeps its atomicity; `findOrFail` inside the closures still 404s (the rethrow catch is not needed once the wrapper is gone); validation errors inside `toggleStatus` propagate as 422 instead of being swallowed (see MOD-02). |
| **Plan item** | MOD-01 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -nE "catch \(|try \{"` — see below |

```php
// ModuleController.php:45-75 — CURRENT (store; the same wrapper repeats in update/destroy/restore/forceDelete/toggleStatus)
        try {
            return DB::transaction(function () use ($request) {
                $module = Module::create($request->validated());

                // Set sort_order based on menu_id array order
                $menuData = [];
                foreach ($request['menu_id'] as $index => $menuId) {
                    $menuData[$menuId] = ['sort_order' => $index + 1];
                }

                $module->menus()->attach($menuData);

                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($module, 'Stored', ['message' => 'Module was created.', 'other' => 'some other information']);
                // end::Activity Log

                return redirect()
                    ->to(route('central.prime.sales-plan-mgmt.index').'#modules')
                    ->with('success', flash('created.module'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('ModuleController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -nE "catch \(|try \{" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php
45:        try {
67:        } catch (ModelNotFoundException $e) {
71:        } catch (\Throwable $e) {
107:        try {
161:        } catch (ModelNotFoundException $e) {
165:        } catch (\Throwable $e) {
179:        try {
194:        } catch (ModelNotFoundException $e) {
198:        } catch (\Throwable $e) {
219:        try {
232:        } catch (ModelNotFoundException $e) {
236:        } catch (\Throwable $e) {
247:        try {
262:        } catch (ModelNotFoundException $e) {
266:        } catch (\Throwable $e) {
279:        try {
311:        } catch (ModelNotFoundException $e) {
315:        } catch (\Throwable $e) {
```

#### MOD-02 · H · ERR-02 — `validate()` inside `toggleStatus`'s try; a 422 becomes a generic redirect

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500; validate/authorize/findOrFail belong before the try* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php:279-318`, method `toggleStatus()` |
| **Root cause** | `$request->validate(['is_active' => 'required|boolean'])` (line 281) runs inside `DB::transaction` inside the `try`. A `ValidationException` is a `\Throwable`, so the generic catch at 315 turns the 422 into `back()->with('error', ...)` and the field error never reaches the view. |
| **Consequence** | The status-switch AJAX call with a bad payload shows the generic flash instead of the is_active field error. |
| **Reproduce** | POST `/global-master/module/{module}/toggle-status` with no `is_active`; the response is a redirect, not a 422. |
| **Fix approach** | Removed together with MOD-01: with no catch, the `ValidationException` propagates to the central handler and renders the field error. |
| **Plan item** | none — see plan §10 (resolved by MOD-01) |
| **Evidence** | `grep -nE "catch \(|try \{"` — line 281 sits inside the 279-319 try (quoted in MOD-01) |

```php
// ModuleController.php:279-283 — CURRENT (validate inside try)
        try {
            return DB::transaction(function () use ($request, $module) {
                $request->validate([
                    'is_active' => 'required|boolean',
                ]);
```

**Evidence**
```
$ grep -n "validate" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php
281:                $request->validate([
```

#### MOD-03 · M · ERR-05 — catches log `getMessage()` only, losing the exception and trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('...', ['exception' => $e]`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php:72,166,199,237,267,316` — one per catch |
| **Root cause** | Each generic catch logs `['error' => $e->getMessage()]`. The SQL text alone cannot be traced back to a stack frame, so the real failure site stays hidden (this is exactly why MOD-07's SQL error is invisible). |
| **Consequence** | Support cannot tell which query failed or where; duplicate failures look identical. |
| **Reproduce** | Trigger any write failure and read `storage/logs/laravel.log`. |
| **Fix approach** | Resolved together with MOD-01: the catches are removed and `bootstrap/app.php`'s central handler logs the full exception. |
| **Plan item** | none — see plan §10 (resolved by MOD-01) |
| **Evidence** | `grep -n "Log::error"` — see below |

```php
// ModuleController.php:72 — CURRENT (one of six identical lines)
            Log::error('ModuleController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "Log::error" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php
72:            Log::error('ModuleController::store failed', ['error' => $e->getMessage()]);
166:            Log::error('ModuleController::update failed', ['error' => $e->getMessage()]);
199:            Log::error('ModuleController::destroy failed', ['error' => $e->getMessage()]);
237:            Log::error('ModuleController::restore failed', ['error' => $e->getMessage()]);
267:            Log::error('ModuleController::forceDelete failed', ['error' => $e->getMessage()]);
316:            Log::error('ModuleController::toggleStatus failed', ['error' => $e->getMessage()]);
```

#### MOD-04 · M · ERR-04 — `toggleStatus` returns JSON on success but an HTML redirect on failure, with no `expectsJson()` branch

| Field | Value |
|---|---|
| **Rule** | ERR-04 (M) — *JSON endpoints fail with JSON, form endpoints fail with a redirect; use `$request->expectsJson()` when one method serves both* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php:297-318`, method `toggleStatus()` |
| **Root cause** | The happy path returns `response()->json(...)` but the generic catch returns `back()->with('error', ...)`. The AJAX status switch therefore gets an HTML redirect on failure — the React/JS caller receives a 302 body instead of a JSON error. |
| **Consequence** | A failed status toggle is presented as a page redirect to the AJAX caller. |
| **Reproduce** | Toggle with an invalid `is_active` and watch the fetch response. |
| **Fix approach** | Resolved together with MOD-01: the catch disappears and the central handler returns JSON for a request that `expectsJson()` (the status-switch component sends `X-Requested-With`/fetches JSON). |
| **Plan item** | none — see plan §10 (resolved by MOD-01) |
| **Evidence** | `grep -nE "response\(\)->json|return back"` — see below |

```php
// ModuleController.php:297-318 — CURRENT (JSON happy path, redirect catch)
                    return response()->json([
                        'success' => true,
                        'is_active' => $module->is_active,
                        'message' => flash('status_updated.module'),
                    ]);
                } else {
                    return response()->json([
                        'success' => false,
                        'is_active' => $module->is_active,
                        'message' => flash('status_switch_failed.module'),
                    ]);
                }

            });
        } catch (ModelNotFoundException $e) {
```

**Evidence**
```
$ grep -nE "response\(\)->json|return back" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php
297:                    return response()->json([
303:                    return response()->json([
318:            return back()->with('error', 'The operation could not be completed.');
```

### F2 — Transactions and audit

Transactions themselves are clean: every mutation runs in ONE `DB::transaction` closure, and `activityLog()` sits **after** the write and **inside** the transaction in all six methods (store/update/destroy/restore/forceDelete/toggleStatus). Event literals are consistent: 'Stored', 'Updated', 'Trashed', 'Restored', 'Deleted', 'Toggled'. No mail/file-delete/HTTP call happens inside a transaction. Evidence: `grep -n "DB::transaction\|activityLog("` shows one transaction per method and `activityLog` inside it. The one F2 finding is TXN-05 below.

#### MOD-05 · M · TXN-05 · DECISION — HTTP responses are built inside the transaction closures

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()`/`response()` after it* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php:62,158,191,229,259,297,303` — the `return redirect(...)` / `return response()->json(...)` inside each `DB::transaction` closure |
| **Root cause** | Each closure returns the HTTP response object itself rather than a value the method turns into a response. This works (the closure's return value is what `DB::transaction` returns), but it builds the response before the commit is confirmed and couples the transaction to the response shape. |
| **Consequence** | Maintainability debt only; no wrong behaviour is observable today because a redirect/JSON build has no side effects. |
| **Reproduce** | Static only — the code returns the response from the closure. |
| **Fix approach** | Either accept as-is (recommended: harmless, Laravel-legal) or refactor the closures to return the saved model/count and build the response after the transaction. This is a decision because it is a 6-site structural rewrite with no user-visible gain. |
| **Plan item** | MOD-05 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `grep -nE "return redirect|return response"` — see below |

```php
// ModuleController.php:62-75 — CURRENT (redirect built inside the closure; same pattern at 158/191/229/259/297/303)
                return redirect()
                    ->to(route('central.prime.sales-plan-mgmt.index').'#modules')
                    ->with('success', flash('created.module'));

            });
        } catch (ModelNotFoundException $e) {
```

**Evidence**
```
$ grep -nE "return redirect|return response" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php
62:                return redirect()
158:                return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#modules')->with('success', flash('updated.module'));
191:                return redirect()->to(route('central.prime.sales-plan-mgmt.index').'#modules')->with('success', flash('trashed.module'));
229:                return redirect()->route('central.global-master.module.trashed')->with('success', flash('restored.module'));
259:                return redirect()->route('central.global-master.module.trashed')->with('success', flash('force_deleted.module'));
297:                    return response()->json([
303:                    return response()->json([
```

### F3 — Authorization

Every routed method authorizes **before** it loads any record (AUTH-01/AUTH-02 clean). The seven permission names (`viewAny, create, view, update, delete, restore, forceDelete)` are declared in `config/permissionslist.php` under the `prime` scope and seeded in `sys_permissions` with exact names (evidence below); no Policy exists that a string Gate bypasses (AUTH-06 checked — none registered for this controller). One finding: the FormRequest double-checks the same permission.

#### MOD-06 · L · AUTH-04 — `ModuleRequest::authorize()` duplicates the controller's Gate check on store/update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php:71-80`; duplicates `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php:43,105` |
| **Root cause** | `ModuleRequest::authorize()` calls `$this->authorizeByCrudPermission('prime.global-master.module')`, which maps POST→create and PUT/PATCH→update and returns `Gate::allows(...)`. The controller then runs `Gate::authorize('prime.global-master.module.create'/'update')` again. The request's own comment admits it "narrows nothing and widens nothing". |
| **Consequence** | Two checks of the same permission per write; harmless but redundant, and a second place to update if the permission ever changes. |
| **Reproduce** | Static only — both checks are visible in source. |
| **Fix approach** | Keep the controller's `Gate::authorize()` as the single check and return `true` from the request's `authorize()` with an AUTH-04 comment. |
| **Plan item** | MOD-06 in `02-fix-plan.md` §4 |
| **Evidence** | `sed -n '71,80p'` — see below |

```php
// ModuleRequest.php:71-80 — CURRENT
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        // T6b — mirrors the controller's own gate: prime.module.create on POST,
        // prime.module.update on PUT/PATCH. Same permission, checked one step
        // earlier, so this narrows nothing and widens nothing.
        return $this->authorizeByCrudPermission('prime.global-master.module');
    }
```

**Evidence**
```
$ php artisan tinker --execute '...sys_permissions where name like "prime.global-master.module%"...'
prime.global-master.module.create
prime.global-master.module.delete
prime.global-master.module.forceDelete
prime.global-master.module.restore
prime.global-master.module.update
prime.global-master.module.view
prime.global-master.module.viewAny
```

### F4 — Validation and input

The request uses `validated()` everywhere (`Module::create($request->validated())`, `$module->update($request->validated())`) — never `$request->all()` (VAL-01 clean). `toggleStatus`'s inline one-field validation is the allowed AJAX-toggle exception (VAL-02 clean). There is no cross-field rule, so execution of the request against a payload was not required for F4 (the validator's own rules were read and are checked below). The four findings below are: a required column never supplied (Blocker), a uniqueness rule that does not mirror the real index, two type mismatches, and a silent overwrite of unused permission flags.

#### MOD-07 · B · VAL-05 (raised) · DECISION — create always fails: `code` (NOT NULL, no default) is never supplied

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M default, raised to B) — *write paths must validate every column they write; here the required `code` column is neither validated nor supplied, so the normal create path crashes. Severity raised because this is a page-killer on a live screen* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php:46-47` (store); `Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php:20-50` has no `code` rule; `Modules/GlobalMaster/resources/views/module/create.blade.php:24-60` has no `code` input |
| **Root cause** | `glb_modules.code` is `varchar(6) NOT NULL` with `default NULL` (verified via `SHOW COLUMNS`). `ModuleRequest::rules()` validates `name, menu_id, version, ...` but not `code`, and `prepareForValidation()` does not add it. The create form renders no code field. `$module = Module::create($request->validated())` therefore issues an INSERT without `code`, which MySQL rejects (strict mode), and MOD-01's catch hides it as a generic flash. So the module can only ever be created by seeders/commands that set `code` explicitly. |
| **Consequence** | A user who clicks Add Module on the list and submits the form always sees "The operation could not be completed." — the module is never created. |
| **Reproduce** | Open `/global-master/module/create`, fill the form, submit; observe the generic error and zero rows written. |
| **Fix approach** | A decision: (a) auto-generate a 6-char code from the name in `store()` (matches the seeder idiom `strtoupper(substr(...))`), (b) add a visible `code` input plus a rule, or (c) change the column to nullable/defaulted via a migration (Tarun's hand). |
| **Plan item** | MOD-07 in `02-fix-plan.md` §1 (DECISION, top blocker) |
| **Evidence** | `SHOW COLUMNS FROM glb_modules` + `grep -rn 'name="code"' .../views/module` (no output) — see below |

```php
// ModuleController.php:45-52 — CURRENT (create path; code is never in validated())
        try {
            return DB::transaction(function () use ($request) {
                $module = Module::create($request->validated());
```

**Evidence**
```
$ php artisan tinker --execute 'SHOW COLUMNS FROM glb_modules (global_master_mysql)'
code                         varchar(6)           null=NO default=NULL

$ grep -rn 'name="code"\|"code"' Modules/GlobalMaster/resources/views/module
(no output)

$ grep -n "'code'" Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php
(no output)
```

#### MOD-08 · M · VAL-04 — the `name` uniqueness rule does not mirror the real unique index

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H default, lowered to M) — *uniqueness rules must mirror the DB unique index including soft-delete semantics. Lowered because the mismatch here refuses a legitimate create (a 422), not a crash* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php:25-26` vs the DB index `uq_module_key_live` |
| **Root cause** | The real unique constraint (migration `2026_08_25_150000_make_plan_module_unique_indexes_soft_delete_aware.php`) is `uq_module_key_live` = `CASE WHEN deleted_at IS NULL THEN CONCAT(COALESCE(parent_id,0),'|',name,'|',version)`. The request validates `Rule::unique('glb_modules')->ignore($moduleId)->whereNull('deleted_at')` on `name` alone. The soft-delete half is aligned (whereNull matches the generated column), but ignoring `parent_id` and `version` makes validation STRICTER than the DB: a new module named like an existing one is refused even when the DB would accept it (different parent or version). The migration docblock explicitly named this follow-up. |
| **Consequence** | A user cannot create "Finance 2.0" (version 2) when "Finance" (version 1) exists, or a sub-module that shares a name with a root module. |
| **Reproduce** | Create module A (name X, version 1), then try to create another module named X with version 2 — validation refuses although the DB index allows it. |
| **Fix approach** | Mirror the index: unique on name where `version` matches the submitted version and `COALESCE(parent_id,0)` matches the submitted parent id (use `where()` + a bound `whereRaw`). |
| **Plan item** | MOD-08 in `02-fix-plan.md` §5 |
| **Evidence** | `SHOW INDEX FROM glb_modules` + `sed -n '18,27p'` — see below |

```php
// ModuleRequest.php:18-27 — CURRENT (name-only unique rule)
        $moduleId = $this->route('module') ? $this->route('module')->id : null;

        return [
            'name' => [
                'required',
                'string',
                'max:50',
                // Unique on the correct table, ignoring current record
                Rule::unique('glb_modules')->ignore($moduleId)->whereNull('deleted_at'),
            ],
```

**Evidence**
```
$ php artisan tinker --execute 'SHOW INDEX FROM glb_modules (global_master_mysql)'
IDX uq_module_key_live col=module_key_live nonuniq=0
(module_key_live = CASE WHEN deleted_at IS NULL THEN CONCAT(COALESCE(parent_id,0),'|',name,'|',version) ELSE NULL END, STORED)
```

#### MOD-09 · M · VAL-05 — `is_sub_module` and `version` are validated with the wrong types

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; a type mismatch on a write path is a wrong-value risk* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php:37-38` vs `Modules/GlobalMaster/app/Models/Module.php:38-51` casts and the DDL |
| **Root cause** | `is_sub_module` is validated `['nullable','string','max:50']` but the column is `tinyint(1)` and the model casts it `boolean`; `version` is validated `['required','string','max:10']` but the column is `tinyint` and the model casts it `integer`. A posted `is_sub_module = "anything"` passes validation and is cast to `true`; a posted `version = "v2"` is cast to int, storing 0 or raising a strict-mode error. There is no form input for `is_sub_module` today, so the mis-typed rule is dormant but wrong. |
| **Consequence** | A malformed `version` (free-text field in the form) can store a wrong value or 500; `is_sub_module` accepts any string. |
| **Reproduce** | Type "v2" in the Version field and submit the create form. |
| **Fix approach** | Validate `version` as `['required','integer','min:1','max:127']` (tinyint signed) and drop the `is_sub_module` rule (no input exists; the DB default `false` applies when it is absent from `validated()`). |
| **Plan item** | MOD-09 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -n "is_sub_module\|'version'"` — see below |

```php
// ModuleRequest.php:37-38 — CURRENT
            'is_sub_module' => ['nullable', 'string', 'max:50'],
            'version' => ['required', 'string', 'max:10'],
```

**Evidence**
```
$ grep -n "is_sub_module\|'version'" Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php
37:            'is_sub_module' => ['nullable', 'string', 'max:50'],
38:            'version' => ['required', 'string', 'max:10'],

$ php artisan tinker --execute 'SHOW COLUMNS FROM glb_modules (global_master_mysql)'
is_sub_module  tinyint(1)  null=NO default='0'
version        tinyint     null=NO default='1'
```

#### MOD-10 · M · F13 (dead feature + silent overwrite) · DECISION — `available_perm_*` are forced to false on every save, and nothing ever reads them

| Field | Value |
|---|---|
| **Rule** | F13 deep-read Q1/Q8 — *a write must not overwrite data it should not; a screen whose saved data no consumer reads is dead* (no rulebook default; set M) |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php:53-69` (`prepareForValidation`), `Modules/GlobalMaster/resources/views/module/create.blade.php:24-60` and `edit.blade.php:24-62` (no perm inputs) |
| **Root cause** | `prepareForValidation()` merges the seven `available_perm_*` keys using `$this->boolean(...)`, which returns `false` when the checkbox is absent. Neither the create nor the edit blade renders those checkboxes (they were present in the legacy `resources/views/backend/v1/global-master/module-bk/` forms), so every `store()` and every `update()` writes all seven flags to `false`, overriding the DDL default `true`. A grep for readers finds only writers (ModuleSeeder, MenuSyncController, the migration, the model's fillable/casts, this request) — no runtime code reads `available_perm_*`, so the overwrite has no visible effect today but silently destroys data a future feature would read. |
| **Consequence** | Every created/edited module has all permission flags false, and the columns are write-only dead data. |
| **Reproduce** | Create a module, then `SELECT available_perm_view ... FROM glb_modules WHERE id = <new>` → 0 despite the DDL default 1. |
| **Fix approach** | A decision: (a) add the seven checkboxes back to both blades (exposes the flags, keeps overwrite intent), (b) remove the `available_perm_*` rules and merges so the DDL default applies until a reader exists, or (c) accept and record the dead feature. |
| **Plan item** | MOD-10 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `sed -n '53,69p'` + `grep -rln "available_perm_view"` — see below |

```php
// ModuleRequest.php:53-69 — CURRENT (perm flags merged to false when absent)
    protected function prepareForValidation()
    {
        // Checkbox sends value="1" when checked, nothing when unchecked.
        // $this->boolean() handles '1', 'true', 'on', 'yes' → true; absent/0/false → false.
        $this->merge([
            'is_active' => $this->boolean('is_active'),
            'available_perm_view' => $this->boolean('available_perm_view'),
            'available_perm_add' => $this->boolean('available_perm_add'),
            'available_perm_edit' => $this->boolean('available_perm_edit'),
            'available_perm_delete' => $this->boolean('available_perm_delete'),
            'available_perm_export' => $this->boolean('available_perm_export'),
            'available_perm_import' => $this->boolean('available_perm_import'),
            'available_perm_print' => $this->boolean('available_perm_print'),
            'default_visible' => $this->boolean('default_visible'),
            'is_core' => $this->boolean('is_core'),
        ]);
    }
```

**Evidence**
```
$ grep -rln "available_perm_view" --include=*.php --include=*.blade.php Modules app resources | grep -v module-bk
Modules/Prime/database/seeders/ModuleSeeder.php
Modules/GlobalMaster/database/migrations/2025_10_21_091607_create_modules_table.php
Modules/GlobalMaster/app/Models/Module.php
Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php
Modules/PrimeCore/app/Http/Controllers/MenuSyncController.php
(no reader — every hit is a writer)
```

### F5 — Routes

RTE-02/RTE-03 clean (every route's method exists, every public method routed). RTE-06 checked, not present: the custom routes register after `Route::resource('module')` but `/module/trash/view` is three segments and is not shadowed by `/module/{module}`. Tenant middleware: this is a central super-admin screen, so the `['auth','verified']` group is correct (RTE-05 clean for central scope). One finding: the restore state change rides a GET.

#### MOD-11 · H · RTE-01 · DECISION — restore changes state over GET, with no CSRF

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/GlobalMaster/routes/web.php:140` — `Route::get('/module/{id}/restore', ...)`; the trash row renders it as a plain link in `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php:5` |
| **Root cause** | The route is `GET global-master/module/{id}/restore` (verb from the uncached route:list) and the shared trash component emits `<a href="{{ route($url . '.restore', $id) }}">` — a GET anchor with no `@csrf`. The `restore()` method mutates `deleted_at` back to null. A prefetcher, crawler, or a CSRF-forced request can restore a trashed module without consent. |
| **Consequence** | A module the admin trashed can be silently un-trashed by a GET hit; the "confirm" is only a client-side SweetAlert. |
| **Reproduce** | From `/global-master/module/trash/view`, an attacker/crawler GET on `/global-master/module/1/restore` restores the row. |
| **Fix approach** | A decision (same pattern exists across all GlobalMaster siblings and the shared component): (a) change this module's restore route to `POST` and render a CSRF form in `trash.blade.php` (touches the shared route file and swaps the shared component call), (b) fix it estate-wide with all sibling controllers in one coordinated change, or (c) accept for now. |
| **Plan item** | MOD-11 in `02-fix-plan.md` §1 (DECISION, ⚠ SHARED) |
| **Evidence** | route:list + `sed -n '1,10p'` of the component — see below |

```php
// Modules/GlobalMaster/routes/web.php:140 — CURRENT
        Route::get('/module/{id}/restore', [ModuleController::class, 'restore'])->name('module.restore');
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | grep restore
GET|HEAD   global-master/module/{id}/restore   central.global-master.module.restore   ModuleController@restore

$ sed -n '5,5p' Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php
        <a href="{{ route($url . '.restore', $id) }}" class="btn btn-outline-warning btn-sm confirm-action-restore">
```

### F6 — Controller shape

322 lines / 11 public methods — under the CTL-01 thresholds (clean). No `request()` helper, no `dd/dump`, no `compact()` over ~15 vars, no debug leftovers. Two findings: unused route model binding, and missing return types.

#### MOD-12 · M · CTL-03 — `edit` and `destroy` look up by `$id` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Module $module)`), not `$id` + `findOrFail`* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php:92-98` (edit), 175-184 (destroy). `restore`/`forceDelete` keep the explicit `withTrashed()->findOrFail($id)` lookups — the correct idiom for trash routes — so they are not part of the fix |
| **Root cause** | `edit(string $id)` and `destroy(string $id)` re-query `Module::findOrFail($id)` although the resource route already binds `{module}` for both (the binding is used by `show`/`update`/`toggleStatus`). |
| **Consequence** | Duplicated lookup logic; a future route-parameter rename silently breaks the lookup. |
| **Reproduce** | Static only — both methods show the manual lookup. |
| **Fix approach** | Type-hint `Module $module` in `edit` and `destroy` so the route binds the model (destroy's rewrite is carried out in MOD-01's After, which already rewrites destroy's body). |
| **Plan item** | MOD-12 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -n "findOrFail"` — see below |

```php
// ModuleController.php:92-98 — CURRENT (edit)
    public function edit(string $id)
    {
        Gate::authorize('prime.global-master.module.update');
        $module = Module::findOrFail($id);

        return view('globalmaster::module.edit', compact('module'));
    }
```

**Evidence**
```
$ grep -n "findOrFail" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php
95:        $module = Module::findOrFail($id);
181:                $module = Module::findOrFail($id);
221:                $module = Module::withTrashed()->findOrFail($id);
249:                $module = Module::withTrashed()->findOrFail($id);
(95=edit, 181=destroy; 221/249=trash lookups, correct idiom)
```

#### MOD-13 · L · CTL-04 — no return types on any public method

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php:20,31,41,81,92,103,175,207,215,243,275` — all 11 public methods |
| **Root cause** | None of the public methods declares a return type. |
| **Consequence** | Lint-level consistency debt; no runtime effect. |
| **Reproduce** | Static only. |
| **Fix approach** | Add return types when the methods are rewritten by MOD-01 (store/update/destroy/restore/forceDelete/toggleStatus) and independently for index/create/show/edit/trashedModule. |
| **Plan item** | MOD-13 in `02-fix-plan.md` §8 (with the MOD-17 style pass) |
| **Evidence** | `grep -nE "public function"` — see below |

```php
// ModuleController.php:20-26 — CURRENT (index, representative)
    public function index()
    {
        Gate::authorize('prime.global-master.module.viewAny');
        $modules = Module::with('menus')->paginate(10);

        return view('globalmaster::module.index', compact('modules'));
    }
```

**Evidence**
```
$ grep -nE "public function [a-zA-Z_]+" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php
20:    public function index()
31:    public function create()
41:    public function store(ModuleRequest $request)
81:    public function show(Module $module)
92:    public function edit(string $id)
103:    public function update(ModuleRequest $request, Module $module)
175:    public function destroy(string $id)
207:    public function trashedModule()
215:    public function restore($id)
243:    public function forceDelete($id)
275:    public function toggleStatus(Request $request, Module $module)
```

### F7 — Models

`Module.php` (owned here): `$fillable` present, nothing sensitive (MDL-01 clean); `$casts` cover every boolean and the integer version (MDL-02 clean); `$table = 'glb_modules'` exists in the migration and live DB (MDL-07 clean); `SoftDeletes` matches `deleted_at`; `menus()` pivot has no `deleted_at`, so no `wherePivotNull` needed there (MDL-03 clean for menus). Two findings: the soft-delete pivot trap on `tenantInvoices()`, and missing relation return types.

#### MOD-14 · H · MDL-03 — `tenantInvoices()` joins a soft-delete pivot without `wherePivotNull('deleted_at')`

| Field | Value |
|---|---|
| **Rule** | MDL-03 (H) — *a `belongsToMany` over a pivot table that has `deleted_at` must add `wherePivotNull('deleted_at')`, or removed rows still count as members* |
| **Where** | `Modules/GlobalMaster/app/Models/Module.php:71-74`, relation `tenantInvoices()` |
| **Root cause** | The pivot `bil_tenant_invoicing_modules_jnt` has a `deleted_at` column (verified via `SHOW COLUMNS`), but the relation does not filter trashed pivot rows. |
| **Consequence** | A soft-deleted invoice link still appears as a member when the relation is used; billing reports could count revoked entitlements. This controller never runs the relation, but the model is owned here and PlanController/billing code may reach it. |
| **Reproduce** | Static — the relation lacks the pivot filter; `SHOW COLUMNS` proves the pivot is soft-delete-capable. |
| **Fix approach** | Add `->wherePivotNull('deleted_at')` to the `belongsToMany` chain. |
| **Plan item** | MOD-14 in `02-fix-plan.md` §5 |
| **Evidence** | `SHOW COLUMNS FROM bil_tenant_invoicing_modules_jnt` — see below |

```php
// Module.php:71-74 — CURRENT
    public function tenantInvoices()
    {
        return $this->belongsToMany(TenantInvoice::class, 'bil_tenant_invoicing_modules_jnt', 'module_id', 'tenant_invoice_id');
    }
```

**Evidence**
```
$ php artisan tinker --execute 'SHOW COLUMNS FROM bil_tenant_invoicing_modules_jnt (mysql)'
id,tenant_invoice_id,module_id,created_at,updated_at,deleted_at
```

#### MOD-15 · L · MDL-04 — model relations have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`, ...)* |
| **Where** | `Modules/GlobalMaster/app/Models/Module.php:55,60,65,71,77,89` — `parent()`, `children()`, `tenantPlanModules()`, `tenantInvoices()`, `menus()`, `plans()` |
| **Root cause** | None of the six relations declares a return type. |
| **Consequence** | Lint-level consistency debt. |
| **Reproduce** | Static only. |
| **Fix approach** | Add the Eloquent return types. `menus()` is covered by MOD-20's rewrite (which adds `: BelongsToMany`); `tenantInvoices()` is covered by MOD-14's rewrite. This item handles `parent()`, `children()`, `tenantPlanModules()`, `plans()`. |
| **Plan item** | MOD-15 in `02-fix-plan.md` §5 |
| **Evidence** | `sed -n '55,96p'` — see below |

```php
// Module.php:55-96 — CURRENT (all six relations, representative excerpt)
    public function parent()
    {
        return $this->belongsTo(Module::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(Module::class, 'parent_id');
    }

    public function tenantPlanModules()
    {
        return $this->hasMany(TenantPlanModule::class, 'module_id');
    }


    public function tenantInvoices()
    {
        return $this->belongsToMany(TenantInvoice::class, 'bil_tenant_invoicing_modules_jnt', 'module_id', 'tenant_invoice_id');
    }
```

**Evidence**
```
$ grep -nE "public function (parent|children|tenantPlanModules|tenantInvoices|menus|plans)\(" Modules/GlobalMaster/app/Models/Module.php
55:    public function parent()
60:    public function children()
65:    public function tenantPlanModules()
71:    public function tenantInvoices()
77:    public function menus()
89:    public function plans()
(none has a return type)
```

### F8 — Services and jobs

clean — no services, jobs, events, or listeners in scope. `grep -oE '...Service|...Job|...Event'` on the controller returns nothing but `ModuleRequest`. Nothing to check for SVC/JOB.

### F9 — Queries and performance

clean — `index` eager-loads `menus` (`Module::with('menus')->paginate(10)`), lists paginate at 10, `show` uses `loadMissing('menus')`, `trashedModule` paginates, no query sits in a loop, no interpolated raw SQL reaches user input (the model's `plans()` interpolates only a DB name from config — acceptable, not QRY-11), and no dropdown is re-queried per request (the select-menu component owns that). The `menus()` ordering defect is reported under F13 (MOD-20) because it is a wrong-result bug rather than a performance issue.

### F10 — Views

clean — no `Model::`/`DB::` queries in any of the five module blades (VIEW-01); relations used in loops are eager-loaded by the controller (index and show; edit lazy-loads `$module->menus` once, not in a loop); no `{!! !!}` on user text (VIEW-03); row actions use the shared `x-backend.table.action` / `x-prime.table.action-trashed` components; the create form is a standalone page (not a modal) and has 15 or fewer controls, so modal-standard does not apply. `index.blade.php` empty-state `colspan="4"` vs 5 table columns is a cosmetic nit only (L, folded into MOD-17's file-style pass). Blades were not rendered in a browser (D4) — noted in §8.

### F11 — Security and tenancy

clean — no `env()` outside config, no `?? 1` fallbacks, no secrets logged (after MOD-01 the `getMessage()` logging is gone), no personal data exposed by this central screen. Cache/tenancy rules (TEN-01..04) do not apply: no cache, no media, no central-model access from tenant context (this controller IS central).

### F12 — Style

#### MOD-17 · L · STY-01/STY-04 — controller file: no `strict_types`, emoji comments, copy-pasted activityLog docblocks and placeholder payloads

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` on files you touch*; STY-04 (L) — *comments in English, no emoji markers, no copy-pasted docblocks* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php:1` (no strict_types), 58/187/225/255 (the repeated `// Syntex : activityLog(...)` docblock), 59/188/226/256/294 (`'other' => 'some other information'` placeholder payloads), 136/144 (emoji `⚠` in the update comment), 46 (index empty-state colspan is a blade nit) |
| **Root cause** | File starts without `strict_types`; every `activityLog` call carries a four-line copy-pasted "Syntex" comment and a placeholder payload that adds noise to every audit row. |
| **Consequence** | Style debt only. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);`, drop the placeholder `'other'` keys (keep the real `message`/`changes` payloads), remove the emoji and the duplicated Syntex comment lines. |
| **Plan item** | MOD-17 in `02-fix-plan.md` §8 |
| **Evidence** | `sed -n '1,1p'` + `grep -n "Syntex\|some other information"` — see below |

```php
// ModuleController.php:1 — CURRENT
<?php
```

**Evidence**
```
$ grep -n "Syntex\|some other information" Modules/GlobalMaster/app/Http/Controllers/ModuleController.php
58:                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
59:                activityLog($module, 'Stored', ['message' => 'Module was created.', 'other' => 'some other information']);
187:                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
188:                activityLog($module, 'Trashed', ['message' => 'A new module was deactivated and deleted.', 'other' => 'some other information']);
225:                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
226:                activityLog($module, 'Restored', ['message' => 'A new module was restored.', 'other' => 'some other information']);
255:                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
256:                activityLog($module, 'Deleted', ['message' => 'A new module was permanently deleted.', 'other' => 'some other information']);
294:                    activityLog($module, 'Toggled', ['message' => 'Module toggle was updated.', 'other' => 'some other information']);
```

#### MOD-18 · L · STY-01/STY-04 — model file: no `strict_types`, commented-out factory import

| Field | Value |
|---|---|
| **Rule** | STY-01 (L); STY-04 (L) — *no commented-out code* |
| **Where** | `Modules/GlobalMaster/app/Models/Module.php:1` (no strict_types), 11 (`// use Modules\GlobalMaster\Database\Factories\ModuleFactory;`) |
| **Root cause** | File starts without `strict_types` and carries a commented-out factory import. |
| **Consequence** | Style debt only. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` and delete the commented import. |
| **Plan item** | MOD-18 in `02-fix-plan.md` §8 |
| **Evidence** | `sed -n '1,11p'` — see below |

```php
// Module.php:1-11 — CURRENT
<?php

namespace Modules\GlobalMaster\Models;

use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;
use Modules\Prime\Models\Menu;
use Modules\Prime\Models\TenantInvoice;
use Modules\Prime\Models\TenantPlanModule;
// use Modules\GlobalMaster\Database\Factories\ModuleFactory;
```

**Evidence**
```
$ grep -n "ModuleFactory" Modules/GlobalMaster/app/Models/Module.php
11:// use Modules\GlobalMaster\Database\Factories\ModuleFactory;
```

#### MOD-19 · L · STY-01 — request file: no `strict_types`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php:1` |
| **Root cause** | File starts without `strict_types`. |
| **Consequence** | Style debt only. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` to the request file. |
| **Plan item** | MOD-19 in `02-fix-plan.md` §8 |
| **Evidence** | `sed -n '1,1p'` — see below |

```php
// ModuleRequest.php:1 — CURRENT
<?php
```

**Evidence**
```
$ sed -n '1,1p' Modules/GlobalMaster/app/Http/Requests/ModuleRequest.php
<?php
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 overwrite? | Q2 delete-before-store? | Q3 duplicate impls? | Q4 soft-delete × unique? | Q5 race? | Q6 auth hole? | Q7 message lies? | Q8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | MOD-09, MOD-10 (types, perm flags) | ok | ok | ok (DB index is soft-delete aware; rule has whereNull) | ok (DB unique index backs the check) | ok (gated) | ok | MOD-20 (pivot order), plus MOD-07 (code missing) |
| `update` | MOD-10 (perm flags forced false) | ok | ok | ok | ok | ok | ok | MOD-20 (pivot order) |
| `destroy` | ok (only sets is_active + deletes) | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | MOD-17 (restore does not re-activate `is_active` — trashed modules stay inactive; treat as intended) |
| `forceDelete` | ok (detaches pivot first) | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |

One F13 finding:

#### MOD-20 · M · SVC-04/F13 — the pivot `sort_order` written on every save is never used for ordering

| Field | Value |
|---|---|
| **Rule** | F13 deep-read Q3/Q8 (duplicate/wrong implementation, dead feature) — set M: the user-selected menu order is stored but never applied |
| **Where** | `Modules/GlobalMaster/app/Models/Module.php:77-83` (`menus()`) vs `Modules/GlobalMaster/app/Http/Controllers/ModuleController.php:49-55` and `:112-117` (store/update write pivot `sort_order` from the submitted order) |
| **Root cause** | `store()` and `update()` build `$menuData[$menuId] = ['sort_order' => $index + 1]` so the module's menus appear in the admin's chosen order; but `menus()` orders with `->orderBy('sort_order')`, which Eloquent resolves against the **menu's own** column (`glb_menus.sort_order`, because it is an output column name), not the pivot's. The eager-load SQL logged in tinker ends `order by sort_order asc` and returns menus in `glb_menus.sort_order` order. Confirmed: an explicit SQL with both columns unqualified raises `1052 Column 'sort_order' in order clause is ambiguous`, while the Eloquent query resolves to the `glb_menus.*` column. No consumer reads `pivot_sort_order` anywhere (grep for `pivot_sort_order`/`orderByPivot('sort_order')` finds none on this model) — so the carefully-written pivot order is dead. |
| **Consequence** | The menu order an admin selects in the create/edit form is silently ignored; menus always display in the global menu order instead. |
| **Reproduce** | Edit a module, reorder its menus, save; the index and show screens still list them in `glb_menus.sort_order` order. |
| **Fix approach** | Use `->orderByPivot('sort_order')` so the relation honours the pivot order the controller stores (the idiom already used elsewhere in the codebase, e.g. `orderByPivot('sequence_order')`). |
| **Plan item** | MOD-20 in `02-fix-plan.md` §5 |
| **Evidence** | tinker query log — see below |

```php
// Module.php:77-83 — CURRENT (menus relation)
    public function menus()
    {
        return $this->belongsToMany(Menu::class, 'glb_menu_module_jnt', 'module_id', 'menu_id')
            ->withPivot('sort_order')
            ->withTimestamps()
            ->orderBy('sort_order');
    }
```

**Evidence**
```
$ php artisan tinker --execute 'DB::connection("global_master_mysql")->enableQueryLog(); Module::with("menus")->first(); foreach(getQueryLog() as $q){ echo $q["query"]; }'
... select `glb_menus`.*, `glb_menu_module_jnt`.`sort_order` as `pivot_sort_order`, ... order by `sort_order` asc
(orders by glb_menus.sort_order, not the pivot; explicit unqualified sort_order over both tables raises 1052)

$ grep -rn "pivot_sort_order\|orderByPivot('sort_order')\|pivot->sort_order" --include=*.php --include=*.blade.php Modules app resources | grep -i "menu_module"
(no output — nothing reads the pivot order)
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` | Renders restore as a plain GET `<a href>`; only a SweetAlert confirms. Estate-wide: every GlobalMaster sibling controller registers the same GET restore route | RTE-01 | Estate-wide coordinated fix (see MOD-11 decision) |
| `Modules/GlobalMaster/routes/web.php` | The GET restore pattern repeats for every controller in this module (module, board, country, plan, session-board-setup...) | RTE-01 | Module-wide fix; MOD-11 decision should cover all siblings |
| `config/permissionslist.php` | `global-master.module` is defined under both the `prime` scope (line 262) and the `tenant` scope (line 364); the tenant copy mints permissions nothing checks | AUTH-06/STY-07 | Config owner |

## 8. Not covered, and why

- Blades were read but **not rendered or compiled** (D4: no testing of any kind, and no browser session was available).
- `Module::plans()`, `parent()`, `children()`, `tenantPlanModules()` and `tenantInvoices()` relations were not executed against a tenant/plan; `plans()` depends on `Modules\GlobalMaster\Models\Plan` (owned by PlanController) and `TenantPlanModule` (common). Evidence above covers only `menus()`.
- The MOD-07 create failure was not reproduced in the browser (no authenticated session), but the SQL path is proven: NOT NULL column, no input, no rule, no mutator.
- The four DECISION items were not resolved — Tarun chooses in `02-fix-plan.md`.
- The permission check was verified by exact-name seeding, not by exercising a role's refusal (unverifiable without a browser session; D4).