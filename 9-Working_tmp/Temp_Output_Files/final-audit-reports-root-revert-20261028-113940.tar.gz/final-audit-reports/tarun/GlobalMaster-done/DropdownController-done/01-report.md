# Final Audit — GlobalMaster / DropdownController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/DropdownController.php` (128 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | **None.** `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` returns **0 routes** for `Modules\GlobalMaster\Http\Controllers\DropdownController`. The live central dropdown screens (the same `/system-config/dropdown*` URLs) are served by `Modules\Prime\Http\Controllers\DropdownController` (central, prime_db) and `Modules\SystemConfig\Http\Controllers\TenantDropdownController` (tenant). |
| Menu path | None. No menu or blade links to `global-master.dropdown.*`; `Modules/Prime/routes/web.php:171` records that on 2026-08-24 the dropdown routes were moved out of the `global-master` group into `system-config` because "the data lives in prime_db, not global_db", and the old duplicate sets were deleted — this controller, its views and a stray duplicate model file are the leftovers of that move. |
| Who uses it | Nobody. No route, no menu, no feed from another screen. |
| What a user does here | Nothing reachable. The read methods (`index`, `create`, `show`, `edit`, `trashedDropdown`) still carry full live bodies that would query `sys_dropdown_table` and render `globalmaster::dropdown.*` views; the write methods (`store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`) already throw `abort(403)` with a NOT ROUTED comment. |
| Tables written | None — every mutating method is `abort(403)`. |
| Tables read | `sys_dropdown_table` (in `index`, `edit`, `trashedDropdown`), `sys_dropdown_needs` (via the `dropdownNeeds()` relation on the model). |
| Live data | On the default `mysql` connection: `sys_dropdown_table` **392 rows, 0 trashed** (verified in tinker, SELECT only). |

**How to reach each bug in the browser:** none of the findings below are reachable in the browser today — every method is unrouted. They are latent (armed by re-adding a route) or dead code.

## 1. Verdict

The controller is **not production-ready — but it is also not reachable**, so nothing in production breaks because of it. The single worst finding is that five public methods keep full live bodies (including an N+1 loop that issues one extra query per distinct dropdown key) while no route has pointed at any method since the 2026-08-24 move of the dropdown feature to `Modules\Prime` — a dead screen that becomes a real bug the moment someone re-wires it. The same move left behind a duplicate `Dropdown` model class in a non-convention directory that can never autoload, four orphaned views, a missing `show` view, and a FormRequest whose uniqueness rule is broken. Effort to apply the plan: **S–M** (most items are one-liners; the DECISION about deleting the dead controller needs Tarun).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 4 | 4 | 1 | 9 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean — none |
| F2 Transactions/Audit | clean — no writes | F9 Queries/Perf | DROPDOWN-02 |
| F3 Authorization | clean (see §7 notes) | F10 Views | DROPDOWN-01 |
| F4 Validation | DROPDOWN-04 | F11 Security/Tenancy | clean |
| F5 Routes | DROPDOWN-01 | F12 Style | DROPDOWN-06, DROPDOWN-07 |
| F6 Controller shape | DROPDOWN-03, DROPDOWN-05 | F13 Deep read | n/a — no live mutators |
| F7 Models | DROPDOWN-08, DROPDOWN-09 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/DropdownController.php` | controller | 128 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Models/Dropdown.php` | model (autoloaded) | 141 | this report (claimed in `_Info/00-CLASS-OWNERS.md`; shared by Transport/Template/SyllabusBooks/Vendor) | ✅ |
| 3 | `Modules/GlobalMaster/Models/Dropdown.php` | model (dead duplicate, never autoloaded) | 29 | this report | ✅ — reported as dead code, **not** claimed |
| 4 | `Modules/GlobalMaster/app/Http/Requests/DropdownRequest.php` | FormRequest | 79 | this report (used only by this controller) | ✅ |
| 5 | `Modules/GlobalMaster/resources/views/dropdown/index.blade.php` | blade (orphaned) | 112 | this report | ✅ |
| 6 | `Modules/GlobalMaster/resources/views/dropdown/create.blade.php` | blade (orphaned) | 63 | this report | ✅ |
| 7 | `Modules/GlobalMaster/resources/views/dropdown/edit.blade.php` | blade (orphaned) | 63 | this report | ✅ |
| 8 | `Modules/GlobalMaster/resources/views/dropdown/trash.blade.php` | blade (orphaned) | 51 | this report | ✅ |
| 9 | `Modules/GlobalMaster/resources/views/dropdown/show.blade.php` | blade — **does not exist** | — | this report | ❌ missing; `view()->exists()` = false |

No pre-applied files.

**Shared class claim:** `Modules/GlobalMaster/app/Models/Dropdown.php` is imported by `Modules/Transport`, `Modules/Template`, `Modules/SyllabusBooks` and `Modules/Vendor` (`use Modules\GlobalMaster\Models\Dropdown;`) — all of these resolve to this same file (the PSR-4 mapping points at `app/`). It was unclaimed, so this report claims and fully audits it. The other in-scope files (the request, the stray duplicate model, the views) are reachable only from this controller, so they are audited here and not registered.

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '$r=json_decode(stream_get_contents(STDIN),true);
  foreach($r as $x) if(str_contains($x["action"]??"","GlobalMaster\\Http\\Controllers\\DropdownController")) echo ...;'
TOTAL GlobalMaster DropdownController routes: 0
```

The route list (`/tmp/fa-routes.json`, repo-wide, fresh) contains **no** route whose action is this controller. The only `DropdownController@…` actions in the app belong to `Modules\Prime\Http\Controllers\DropdownController` (`system-config/dropdown*`, names `central.system-config.dropdown.*`) and `Modules\SystemConfig\Http\Controllers\TenantDropdownController` (`system-config/dropdown*`, tenant). `Modules/GlobalMaster/routes/web.php` does not import this controller at all.

Unrouted public methods: **all 11** — `index()`:18, `create()`:40, `store()`:50, `show()`:60, `edit()`:70, `update()`:81, `destroy()`:88, `trashedDropdown()`:97, `restore()`:105, `forceDelete()`:112, `toggleStatus()`:121.

The six write/disable methods (`store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`) already follow D5 — body is `abort(403)` with a NOT ROUTED comment. The five read methods (`index`, `create`, `show`, `edit`, `trashedDropdown`) do **not**.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 18 | **no** | `prime.prime.dropdown.viewAny` | none (read) | none | — | DROPDOWN-01, DROPDOWN-02 |
| `create` | 40 | **no** | `prime.prime.dropdown.create` | none (read) | none | — | DROPDOWN-01 |
| `store` | 50 | **no** (abort 403) | none | none | none | — | clean (D5 already applied) |
| `show` | 60 | **no** | `prime.prime.dropdown.view` | none (read) | none | — | DROPDOWN-01 (view missing) |
| `edit` | 70 | **no** | `prime.prime.dropdown.update` | none (read) | none | — | DROPDOWN-01, DROPDOWN-05 |
| `update` | 81 | **no** (abort 403) | none | none | none | — | clean (D5 already applied) |
| `destroy` | 88 | **no** (abort 403) | none | none | none | — | clean (D5 already applied) |
| `trashedDropdown` | 97 | **no** | `prime.prime.dropdown.restore` | none (read) | none | — | DROPDOWN-01 |
| `restore` | 105 | **no** (abort 403) | none | none | none | — | clean (D5 already applied) |
| `forceDelete` | 112 | **no** (abort 403) | none | none | none | — | clean (D5 already applied) |
| `toggleStatus` | 121 | **no** (abort 403) | none | none | none | — | clean (D5 already applied) |

## 6. Findings

### F1 — Errors

clean — `grep -n 'try\s*{\|catch\s*(\|getMessage' Modules/GlobalMaster/app/Http/Controllers/DropdownController.php Modules/GlobalMaster/app/Http/Requests/DropdownRequest.php Modules/GlobalMaster/app/Models/Dropdown.php Modules/GlobalMaster/Models/Dropdown.php` → no output. No try/catch, no `$e->getMessage()` anywhere in scope (D1/D2 shape is empty because there are no live writes).

### F2 — Transactions and audit

clean — there is no live write path: all six mutating methods are `abort(403)` (D5), and no method calls `activityLog()`. `grep -n 'activityLog\|DB::transaction' Modules/GlobalMaster/app/Http/Controllers/DropdownController.php` → no output.

### F3 — Authorization

clean — every one of the five live-body methods authorizes first with a string gate, and every gate string is a declared, seeded permission: `prime.prime.dropdown.viewAny/view/create/update/restore` all `true` in `PermissionHelper::flatten('prime')` (tinker). The six disabled methods authorize nothing because they throw 403 immediately. The FormRequest `DropdownRequest::authorize()` maps POST→`.create` and PUT/PATCH→`.update`, matching the controller's gate strings, and the request routes are dead in any case, so there is no AUTH-04 double-authorize. See §7 for the systemic "string gate never reaches a Policy" note, which matches the other GlobalMaster audits and is not re-numbered here.

### F4 — Validation and input

#### DROPDOWN-04 · M · VAL-04 — unique rule does not mirror the real unique index and depends on inputs that are never validated

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H default; **lowered to M** — the only callers, `store()`/`update()`, are `abort(403)` (D5), so the defect is latent) — *uniqueness rules mirror the DB unique index including soft-delete semantics* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/DropdownRequest.php:49-58`, method `rules()` |
| **Root cause** | The `value` unique rule filters on `key = $this->input('table_name') . '.' . $this->input('column_name')`, but those two inputs have **no validation rules of their own** (the block that defined them, lines 18-41, is commented out). When absent, `null . '.' . null` resolves to `"."`, so the uniqueness check silently filters on a key that does not exist. The rule has no `->ignore($this->route('dropdown'))`, so an update of the row itself would fail its own unique check. The DB index is `uq_dropdownTable_key_value` = `(key, value)` with soft-delete semantics (`deleted_at`); the rule neither matches that index shape nor applies `whereNull('deleted_at')`. |
| **Consequence** | If `store`/`update` are ever re-routed (or the controller is deleted and the request is NOT), duplicate `(key, value)` pairs are accepted on create and every update 500s on the PK-unique check. |
| **Reproduce** | Static only — the routes to `store`/`update` do not exist (verified route:list, TOTAL 0). |
| **Fix approach** | Restore the `key`/`type` validation rules (or drop them if the form does not send them), and make the unique rule mirror the real index: `Rule::unique('sys_dropdown_table', 'value')->ignore($this->route('dropdown'))->where(fn ($q) => $q->where('key', $this->input('key'))->whereNull('deleted_at'))`. |
| **Plan item** | DROPDOWN-04 in `02-fix-plan.md` §5 |

```php
// DropdownRequest.php:49-58 — CURRENT
            'value' => [
                'required',
                'string',
                'max:255',
                Rule::unique('sys_dropdown_table')
                    ->where(fn($q) => $q->where('key', $this->input('table_name') . '.' . $this->input('column_name')))
            ],

            'is_active' => ['required', 'boolean'],
```

**Evidence**
```
$ sed -n '44,58p' Modules/GlobalMaster/app/Http/Requests/DropdownRequest.php
        return [
            // 'db_type'     => ['required', 'string'],
            // 'table_name'  => ['required', 'string'],
            // 'column_name' => ['required', 'string'],

            'value' => [
                'required',
                'string',
                'max:255',
                Rule::unique('sys_dropdown_table')
                    ->where(fn($q) => $q->where('key', $this->input('table_name') . '.' . $this->input('column_name')))
            ],
```
```
$ sed -n '10,22p' database/migrations/tenant/2026_06_15_145406_create_sys_dropdown_table.php
            $table->softDeletes();

            $table->unique(['key', 'value'], 'uq_dropdownTable_key_value');
            $table->unique(['key', 'ordinal'], 'uq_dropdownTable_key_ordinal');
```

### F5 — Routes

#### DROPDOWN-01 · M · RTE-03 — five unrouted public methods keep live bodies; the rendered `show` view does not exist; all four views are orphaned

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`)* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DropdownController.php:18-35, 40-45, 60-65, 70-76, 97-103` — methods `index()`, `create()`, `show()`, `edit()`, `trashedDropdown()` |
| **Root cause** | When the dropdown feature moved out of GlobalMaster on 2026-08-24 (`Modules/Prime/routes/web.php:171`), the GlobalMaster routes were removed and six write methods were disabled in place with D5 `abort(403)` — but the five read methods were left with their original bodies. The 2026-08-24 cleanup also left the four views (`globalmaster::dropdown.*`) orphaned — `grep -rn 'globalmaster::dropdown' Modules` matches only this controller — and `show()` renders `globalmaster::dropdown.show`, which **does not exist** (`view()->exists()` = false). |
| **Consequence** | A dead screen that 500s (missing view) and runs an N+1 query loop (DROPDOWN-02) the moment anyone wires a route; the four orphaned views keep the dead feature alive in the codebase. |
| **Reproduce** | Static only — no route reaches these methods (route:list, TOTAL 0). |
| **Fix approach** | Apply D5 to the five methods exactly like their six disabled siblings (comment + `abort(403)`). The orphaned views and the controller's eventual fate go to DECISION (plan §9). |
| **Plan item** | DROPDOWN-01 in `02-fix-plan.md` §2 |

```php
// DropdownController.php:18-35, 40-45, 60-65, 70-76, 97-103 — CURRENT (abridged: full bodies in plan)
    public function index()
    {
        Gate::authorize('prime.prime.dropdown.viewAny');

        // get the distinct keys
       // $keys = Dropdown::select('key')->distinct()->get();
          $keys = Dropdown::select('key')->distinct()->orderBy('key')->paginate(10);
        // for each key get the 'values' list
        $groupedDropdowns = collect();

        foreach ($keys as $item) {
            $groupedDropdowns->put(
                $item->key,
                Dropdown::where('key', $item->key)->get()
            );
        }
        return view('globalmaster::dropdown.index', compact('groupedDropdowns' , 'keys'));
    }
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '$r=json_decode(stream_get_contents(STDIN),true); $n=0;
  foreach($r as $x){ if(str_contains($x["action"]??"","GlobalMaster\\Http\\Controllers\\DropdownController")){ $n++; } } echo "TOTAL GlobalMaster DropdownController routes: $n\n";'
TOTAL GlobalMaster DropdownController routes: 0
```
```
$ php artisan tinker --execute 'echo var_export(view()->exists("globalmaster::dropdown.show"), true) . PHP_EOL;'
false
```
```
$ grep -rn "globalmaster::dropdown" Modules --include=*.php --include=*.blade.php | grep -v "app/Http/Controllers/DropdownController.php"
(no output — the views are referenced only by the dead controller)
```

### F6 — Controller shape

#### DROPDOWN-03 · M · CTL-10 — duplicate `Dropdown` model class in a non-convention directory that can never autoload

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code* — raised from its L default because a duplicate class of a shared model is a trap for the next developer who `find`s by filename |
| **Where** | `Modules/GlobalMaster/Models/Dropdown.php` (entire file, 29 lines) |
| **Root cause** | The same FQCN `Modules\GlobalMaster\Models\Dropdown` is declared twice. The module's `composer.json` maps `Modules\GlobalMaster\` → `app/` (PSR-4), so `Modules/GlobalMaster/Models/Dropdown.php` is outside every PSR-4 rule and is **never autoloaded** — the sibling `app/Models/Dropdown.php` (extends `BaseModel`, table `sys_dropdown_table`) wins. The duplicate extends plain `Model`, carries a different `$fillable` (`org_id`, `dropdown_needs_id`) and a different relation (`needs()`), so if it ever DID autoload it would change behaviour; today it is silently dead. `Modules/GlobalMaster/Models/` contains no other file. |
| **Consequence** | A developer grepping for "Dropdown model" finds two files that disagree, and any future merge that maps the root `Modules/GlobalMaster/` namespace would make the wrong one win and silently change every consumer (Transport, Template, SyllabusBooks, Vendor import this FQCN). |
| **Reproduce** | Static only. `class_exists` resolves through the `app/` file (reflection: `getFileName()` = `.../app/Models/Dropdown.php`). |
| **Fix approach** | Delete the stray file after re-verifying the reflection still resolves to `app/Models/Dropdown.php`. |
| **Plan item** | DROPDOWN-03 in `02-fix-plan.md` §5 |

```php
// Modules/GlobalMaster/Models/Dropdown.php:1-29 — CURRENT (dead duplicate)
<?php

namespace Modules\GlobalMaster\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Prime\Models\DropdownNeed;

class Dropdown extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'org_id',
        'ordinal',
        'key',
        'value',
        'type',
        'is_active',
        'dropdown_needs_id'
    ];

    public function needs()
    {
        return $this->belongsTo(DropdownNeed::class, 'dropdown_needs_id');
    }
}
```

**Evidence**
```
$ cat Modules/GlobalMaster/composer.json   (autoload section)
    "autoload": {
        "psr-4": {
            "Modules\\GlobalMaster\\": "app/",
            "Modules\\GlobalMaster\\Database\\Factories\\": "database/factories/",
            "Modules\\GlobalMaster\\Database\\Seeders\\": "database/seeders/"
        }
    }
```
```
$ php artisan tinker --execute '$r = new ReflectionClass(\Modules\GlobalMaster\Models\Dropdown::class); echo $r->getFileName() . PHP_EOL;'
/Users/bkwork/Herd/prime_ai_dev/Modules/GlobalMaster/app/Models/Dropdown.php
```

#### DROPDOWN-05 · L · CTL-03 — `edit()` resolves the record manually instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M default; **lowered to L** — the method is unrouted and DROPDOWN-01 disables it) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DropdownController.php:70-76`, method `edit()` |
| **Root cause** | `edit($id)` calls `Dropdown::findOrFail($id)` instead of accepting `Dropdown $dropdown` with implicit binding. |
| **Consequence** | If this method were ever routed, `/{id}/edit` would resolve the model by hand (a 404 works, but the code is inconsistent with `update`/`toggleStatus` which already type-hint `Dropdown $dropdown`). |
| **Reproduce** | Static only — method unrouted. |
| **Fix approach** | None needed once DROPDOWN-01 disables the method (D5); if re-wired later, switch the signature to `edit(Dropdown $dropdown)` and drop the `findOrFail`. |
| **Plan item** | No item — see plan §10 (disabled by DROPDOWN-01) |

```php
// DropdownController.php:70-76 — CURRENT
    public function edit($id)
    {
        Gate::authorize('prime.prime.dropdown.update');

        $dropdown = Dropdown::findOrFail($id);
        return view('globalmaster::dropdown.edit', compact('dropdown'));
    }
```

**Evidence**
```
$ grep -n "findOrFail\|edit(\$id)" Modules/GlobalMaster/app/Http/Controllers/DropdownController.php
74:        $dropdown = Dropdown::findOrFail($id);
70:    public function edit($id)
```

### F7 — Models

#### DROPDOWN-08 · L · MDL-04 — the autoloaded `Dropdown` model declares twelve relations with no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`…)* |
| **Where** | `Modules/GlobalMaster/app/Models/Dropdown.php:51-140` — `dropdownNeeds()`, `junction()`, `complaintCategoriesBySeverity()`, `complaintCategoriesByPriority()`, `complaintSlasByTargetType()`, `complaintsByStatus()`, `complaintsBySeverity()`, `complaintsByPriority()`, `complaintActions()`, `medicalChecksByType()`, `medicalChecksByResult()`, `aiInsightsBySentiment()` |
| **Root cause** | None of the twelve relation methods declares a return type. The file also carries commented-out dead code (lines 16 and 83-92) — folded into the same per-file style item. |
| **Consequence** | Static analysis (and the IDE) cannot verify the relation types; a wrong `with(['dropdownNeeds'])` string is not caught at compile time. |
| **Reproduce** | Static only (scanner rows listed below). |
| **Fix approach** | Add the correct return types (`: BelongsToMany`, `: HasOne`, `: HasMany`) and remove the commented-out blocks. |
| **Plan item** | DROPDOWN-08 in `02-fix-plan.md` §5 |

```php
// Dropdown.php:51-60 — CURRENT (one of twelve; all twelve in plan)
    public function dropdownNeeds()
    {
        return $this->belongsToMany(
            DropdownNeed::class,
            'sys_dropdown_need_table_jnt',
            'dropdown_table_id',
            'dropdown_needs_id'
        )->withPivot('is_active')
            ->withTimestamps();
    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json \
    Modules/GlobalMaster/app/Models/Dropdown.php
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:51  dropdownNeeds — relation dropdownNeeds() has no return type
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:65  junction — relation junction() has no return type
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:74  complaintCategoriesBySeverity — relation complaintCategoriesBySeverity() has no return type
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:96  complaintCategoriesByPriority — relation complaintCategoriesByPriority() has no return type
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:104  complaintSlasByTargetType — relation complaintSlasByTargetType() has no return type
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:109  complaintsByStatus — relation complaintsByStatus() has no return type
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:114  complaintsBySeverity — relation complaintsBySeverity() has no return type
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:119  complaintsByPriority — relation complaintsByPriority() has no return type
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:123  complaintActions — relation complaintActions() has no return type
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:127  medicalChecksByType — relation medicalChecksByType() has no return type
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:132  medicalChecksByResult — relation medicalChecksByResult() has no return type
L  MDL-04   Modules/GlobalMaster/app/Models/Dropdown.php:137  aiInsightsBySentiment — relation aiInsightsBySentiment() has no return type
```

#### DROPDOWN-09 · M · MDL-03 — `dropdownNeeds()` joins a soft-delete pivot without `wherePivotNull('deleted_at')`

| Field | Value |
|---|---|
| **Rule** | MDL-03 (H default; **lowered to M** — the relation is currently unused anywhere in the codebase, verified by grep) — *a `belongsToMany` over a pivot table that has `deleted_at` must add `->wherePivotNull('deleted_at')`* |
| **Where** | `Modules/GlobalMaster/app/Models/Dropdown.php:51-60`, method `dropdownNeeds()` |
| **Root cause** | The pivot `sys_dropdown_need_table_jnt` has `$table->softDeletes()` (migration `2026_02_04_133437_create_dropdown_need_table_jnts_table.php`), but the relation does not filter `wherePivotNull('deleted_at')`. The generated SQL shown in Evidence joins the pivot with **no** `deleted_at is null` predicate. |
| **Consequence** | A junction row that was soft-deleted still counts as a member, so any consumer of `dropdownNeeds()` reports removed mappings as active. |
| **Reproduce** | Static + SQL probe (below). |
| **Fix approach** | Add `->wherePivotNull('deleted_at')` to the relation. |
| **Plan item** | DROPDOWN-09 in `02-fix-plan.md` §5 |

```php
// Dropdown.php:51-60 — CURRENT
    public function dropdownNeeds()
    {
        return $this->belongsToMany(
            DropdownNeed::class,
            'sys_dropdown_need_table_jnt',
            'dropdown_table_id',
            'dropdown_needs_id'
        )->withPivot('is_active')
            ->withTimestamps();
    }
```

**Evidence**
```
$ php artisan tinker --execute 'echo (new \Modules\GlobalMaster\Models\Dropdown())->dropdownNeeds()->getQuery()->toSql() . PHP_EOL;'
select * from `sys_dropdown_needs` inner join `sys_dropdown_need_table_jnt` on `sys_dropdown_needs`.`id` = `sys_dropdown_need_table_jnt`.`dropdown_needs_id` where `sys_dropdown_need_table_jnt`.`dropdown_table_id` is null and `sys_dropdown_needs`.`deleted_at` is null
```
```
$ grep -n "softDeletes" Modules/Prime/database/migrations/2026_02_04_133437_create_dropdown_need_table_jnts_table.php
18:            $table->softDeletes();
```

### F8 — Services and jobs

clean — the controller calls no services, jobs, events or listeners. `grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b' DropdownController.php` → only `DropdownRequest`.

### F9 — Queries and performance

#### DROPDOWN-02 · H · QRY-01 — `index()` runs one query per dropdown key (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DropdownController.php:24-33`, method `index()` |
| **Root cause** | `index()` paginates the distinct keys (1 query), then inside `foreach ($keys as $item)` executes `Dropdown::where('key', $item->key)->get()` once per key — 1 + N queries, and each inner query fetches the full row set for the key. |
| **Consequence** | A list page with 20 distinct keys costs 21 queries and delivers unbounded rows per key. Currently latent because the method is unrouted (DROPDOWN-01). |
| **Reproduce** | Static only — method unrouted. |
| **Fix approach** | Disable the method (DROPDOWN-01) — the fix that removes reachability. If the screen is ever resurrected, replace the loop with a single grouped query. |
| **Plan item** | No item — see plan §10 (disabled by DROPDOWN-01) |

```php
// DropdownController.php:24-33 — CURRENT
          $keys = Dropdown::select('key')->distinct()->orderBy('key')->paginate(10);
        // for each key get the 'values' list
        $groupedDropdowns = collect();

        foreach ($keys as $item) {
            $groupedDropdowns->put(
                $item->key,
                Dropdown::where('key', $item->key)->get()
            );
        }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/GlobalMaster/app/Http/Controllers/DropdownController.php
H  QRY-01   Modules/GlobalMaster/app/Http/Controllers/DropdownController.php:31  index — Dropdown::where() inside a loop — N+1 query
```

### F10 — Views

Covered by **DROPDOWN-01**: the four existing views (`index/create/edit/trash`) are referenced only by the unrouted controller (`grep -rn 'globalmaster::dropdown' Modules`), `show.blade.php` does not exist (`view()->exists()` false), and `index.blade.php` tags its row actions with `tenant.system-config.dropdown.update/view/delete` permissions while the controller gates on `prime.prime.dropdown.*` — the surfaces disagree because the blade was written for the tenant screen. All of this is dead until a route returns. No queries in the blades (`grep -nE 'Model::|DB::|->where\('` on the four files → no output); user text is escaped with `{{ }}` (no `{!! !!}`).

### F11 — Security and tenancy

clean — `grep -n 'env('` over the four PHP files → no output. No JSON endpoints, no personal data emitted, no hard-coded ids (`?? 1` absent), no media in scope.

### F12 — Style

#### DROPDOWN-06 · L · F12 — controller style: no `strict_types`, two unused imports, commented-out line, no return types

| Field | Value |
|---|---|
| **Rule** | F12/STY-01 (L) `declare(strict_types=1)`; STY-02 (L) Pint-clean; STY-05 (L) one import per class — `Str` and `Collection` are imported but never used; CTL-04 (L) return types |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DropdownController.php:1,7,11,23` and all 11 methods |
| **Root cause** | The file was never Pinted after the 2026-08-24 gutting: two imports survive though unused (`Str`, `Collection`), a commented-out duplicate query remains (`// $keys = Dropdown::select('key')->distinct()->get();` line 23), `compact('groupedDropdowns' , 'keys')` has a stray space, and none of the 11 public methods declares a return type. |
| **Consequence** | Cosmetic; the unused imports fail Pint's sorted-import check and confuse readers. |
| **Reproduce** | Static only. |
| **Fix approach** | `vendor/bin/pint` on the file, restore `strict_types`/return types on the methods that survive DROPDOWN-01, delete the unused imports. |
| **Plan item** | DROPDOWN-06 in `02-fix-plan.md` §8 |

```php
// DropdownController.php:1-13 — CURRENT
<?php

namespace Modules\GlobalMaster\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Gate;
use Modules\GlobalMaster\Http\Requests\DropdownRequest;
use Modules\GlobalMaster\Models\Dropdown;
use Illuminate\Support\Collection;

class DropdownController extends Controller
{
```

**Evidence**
```
$ grep -n "^use " Modules/GlobalMaster/app/Http/Controllers/DropdownController.php
5:use App\Http\Controllers\Controller;
6:use Illuminate\Http\Request;
7:use Illuminate\Support\Str;
8:use Illuminate\Support\Facades\Gate;
9:use Modules\GlobalMaster\Http\Requests\DropdownRequest;
10:use Modules\GlobalMaster\Models\Dropdown;
11:use Illuminate\Support\Collection;
$ grep -n "Str::" Modules/GlobalMaster/app/Http/Controllers/DropdownController.php
(no output — Str unused)
$ grep -nE "Collection::|Collection \$|: Collection" Modules/GlobalMaster/app/Http/Controllers/DropdownController.php
(no output — Collection unused)
```

#### DROPDOWN-07 · L · F12/STY-04 — `DropdownRequest` carries a 24-line commented-out rules block

| Field | Value |
|---|---|
| **Rule** | F12/STY-04 (L) — *no commented-out code*; CTL-10 (M, folded here as L on a dead request) |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/DropdownRequest.php:18-41` |
| **Root cause** | The original `key`/`type`/`value` rules (with `Rule::unique()->ignore(...)`) are commented out and replaced by the broken `table_name.column_name` variant (DROPDOWN-04). A 24-line commented block is dead code that hides the intended behaviour. |
| **Consequence** | The next developer cannot tell which validation was meant; the latent unique-rule defect is harder to spot. |
| **Reproduce** | Static only. |
| **Fix approach** | Delete the commented block as part of the DROPDOWN-04 rewrite (or delete the request with the controller — DECISION). |
| **Plan item** | DROPDOWN-07 in `02-fix-plan.md` §8 |

```php
// DropdownRequest.php:18-41 — CURRENT
        // return [
        //     'key' => [
        //         'required',
        //         'string',
        //         'max:50'
        //     ],
        //     'type' => [
        //         'required',
        //         Rule::in(['String', 'Integer', 'Decimal', 'Date', 'Datetime', 'Time', 'Boolean'])
        //     ],
        //     'value' => [
        //         'required',
        //         'string',
        //         'max:255',
        //         Rule::unique('sys_dropdown_table')
        //             ->ignore($this->route('dropdown'))
        //             ->where(function ($query) {
        //                 return $query->where('key', $this->input('key'));
        //             })
        //     ],
        //     'is_active' => [
        //         'boolean'   
        //     ],
        // ];
```

**Evidence**
```
$ sed -n '18,41p' Modules/GlobalMaster/app/Http/Requests/DropdownRequest.php
        // return [
        //     'key' => [
        //         'required',
        //         'string',
        //         'max:50'
        //     ],
        //     'type' => [
        //         'required',
        //         Rule::in(['String', 'Integer', 'Decimal', 'Date', 'Datetime', 'Time', 'Boolean'])
        //     ],
        //     'value' => [
        //         'required',
        //         'string',
        //         'max:255',
        //         Rule::unique('sys_dropdown_table')
        //             ->ignore($this->route('dropdown'))
        //             ->where(function ($query) {
        //                 return $query->where('key', $this->input('key'));
        //             })
        //     ],
        //     'is_active' => [
        //         'boolean'   
        //     ],
        // ];
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There are no live mutating methods: `store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus` all throw `abort(403)` before touching any data (D5). The table below records that deliberately.

| Mutating method | 1 wrong data | 2 irreversible order | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | n/a (abort) | n/a (abort) | n/a (abort) | n/a (abort) | n/a (abort) | no gate — 403 (D5) | no | yes — DROPDOWN-01 |
| `update` | n/a | n/a | n/a | n/a | n/a | 403 (D5) | no | yes — DROPDOWN-01 |
| `destroy` | n/a | n/a | n/a | n/a | n/a | 403 (D5) | no | yes — DROPDOWN-01 |
| `restore` | n/a | n/a | n/a | n/a | n/a | 403 (D5) | no | yes — DROPDOWN-01 |
| `forceDelete` | n/a | n/a | n/a | n/a | n/a | 403 (D5) | no | yes — DROPDOWN-01 |
| `toggleStatus` | n/a | n/a | n/a | n/a | n/a | 403 (D5) | no | yes — DROPDOWN-01 |

Read methods (`index`, `create`, `show`, `edit`, `trashedDropdown`) perform no writes.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/GlobalMaster/app/Providers/GlobalMasterServiceProvider.php` | `registerPolicies()` calls `Gate::policy(Dropdown::class, DropdownPolicy::class)` with `use Modules\Prime\Models\Dropdown;` — the policy is bound to the **Prime** model class, not `Modules\GlobalMaster\Models\Dropdown` that this controller (and Transport/Template/etc.) use. A `Gate::authorize('view', $dropdown)` with a GlobalMaster instance would resolve no policy. | AUTH-06 / F3 | GlobalMaster module owner (this provider is module glue, owned by no single report) |
| `App\Providers\AppServiceProvider.php` + all GlobalMaster controllers | `Gate::authorize('prime.prime.dropdown.*')` (and every other `prime.*` string gate) never reaches a Policy: no `Gate::define` exists for these strings and `Gate::authorize` with a string and no model argument never consults `DropdownPolicy`. Only the super-admin `Gate::before` passes. Same systemic behaviour as every other GlobalMaster audit; recorded here, not re-numbered. | AUTH-06 (M) | Platform-wide decision |
| `Modules/Prime/resources/views/dropdown-need-mgmt/*.blade.php` | Live Prime blades `fetch()` `/global-master/dropdowns/map-to-need`, `/global-master/dropdown/get-by-need/…`, `/global-master/dropdown/check-key/…` — **no route with a `global-master/dropdown` URI exists** (route list grep), so those live dropdown-mapping screens 404 on their own AJAX calls. | RTE-02 (B) | Prime module owner (Prime's own controller audit) |

## 8. Not covered, and why

- **Live routes of the replacement screens** (`Modules\Prime\Http\Controllers\DropdownController`, `Modules\SystemConfig\Http\Controllers\TenantDropdownController`) are out of scope — they belong to other modules' audits. Only their route **actions** were used to prove this controller is unrouted.
- **Row counts in tenant databases** — the 392-row count was taken on the default `mysql` connection (central). Tenant copies of `sys_dropdown_table` were not counted (not needed for any finding).
- **Blade rendering** — the four views were not rendered to HTML; they are unreachable (no routes). Compile-level checks run by the fixer (§10) will confirm.
- **The two unit test files** (`Modules/GlobalMaster/tests/Unit/ArchitectureTest.php`, `ControllerAuthTest.php`) which reference this controller were read but not run (D4). A deletion DECISION must account for them (they assert `class_exists`).