# Final Audit — GlobalMaster / AppConfigController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php` (173 lines, 5 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `system-config/setting?tab=app-config` on the central host — the **App Config** tab on the Settings page. Every action in this controller redirects back to that tab. |
| Menu path | System Config → Settings → App Config tab |
| Who uses it | Super Admin, Dev Team, App Maintenance (measured: `sys_role_has_permissions_jnt` holds `prime.global-master.app-config.create` and `.update` for all three roles). Central host only. |
| What a user does here | Creates a global application setting (key, label, display order, value, type), edits its label/flags, edits only its value inline, and switches a setting active/inactive. A setting is never deleted — the status switch retires it. |
| Tables written | `glb_app_config` (global_master_mysql connection) + `sys_central_activity_logs` (prime_db connection, via the common `activityLog()` sink) |
| Tables read | `glb_app_config`, `glb_app_modules` (for module_id/key existence and the module list) |
| Live data | `glb_app_config` 4 rows, 0 trashed · `glb_app_modules` referenced by module_id='ACC' exists (proved in tinker) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

The screen works and is properly gated, but the controller is built on the OLD house-rule A1 shape (`try/catch (\Throwable)` around a `DB::transaction` inside which the redirect is built) which the protocol settled against on 2026-10-10 (D1: no try/catch in controllers). Worse, two of the four write methods (`updateValue`, `toggleStatus`) have **no transaction at all**, so a failed activity-log insert leaves the setting actually changed while the user is told "The operation could not be completed." — a failed write that is really a partial success. The single worst finding is AFC-01/02: every write path swallows failures into a fixed flash string, and half of them write two tables without a transaction. The fix is small (4 method rewrites, 3 small file edits, roughly 45 minutes). **Production-ready only after the two H items are fixed.**

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 2 | 4 | 0 | 8 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | AFC-01 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | AFC-02 | F9 Queries/Perf | clean |
| F3 Authorization | clean | F10 Views | clean (pane spot-check) |
| F4 Validation | AFC-03, AFC-04 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | AFC-06, AFC-07 |
| F6 Controller shape | AFC-05 | F13 Deep read | see §6 table |
| F7 Models | AFC-08 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php` | controller | 173 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Models/AppConfig.php` | model | 71 | this report (claimed in _Info/00-CLASS-OWNERS.md) | ✅ |
| 3 | `Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php` | FormRequest | 128 | this report (claimed in _Info/00-CLASS-OWNERS.md) | ✅ |
| 4 | `Modules/GlobalMaster/app/Models/AppModule.php` | model (reached via `AppConfig::module()`) | — | ↗ [tarun/GlobalMaster-done/AppModuleController](../AppModuleController-done/01-report.md) (owner report CLAIMED, in progress) | ↗ linked — usage checked here: relationship resolves and is used only for display |
| 5 | `App\Http\Controllers\Controller` | base controller | — | COMMON — referenced, not audited | — |
| 6 | `app/Helpers/activityLog.php` | helper (common sink) | — | COMMON — referenced, not audited | — |
| 7 | `Modules/GlobalMaster/resources/views/app-config/_pane.blade.php` | blade (rendered by Prime `SettingController`) | — | other controller's view — spot-checked for F10 only | ⚠ partial |
| 8 | `Modules/GlobalMaster/routes/web.php` | route file (shared) | 198 | shared route file — read for RTE only, not fixable by this workflow | — |

No pre-applied files (this module has no `PRE-APPLIED-*.md` entry for these files).

## 4. Routes

Uncached `route:list` (via `/tmp/fa-routes.json`, exported fresh 2026-10-12 10:36):

```
POST    system-config/app-config                                central.system-config.app-config.store             Modules\GlobalMaster\Http\Controllers\AppConfigController@store
PUT     system-config/app-config/{appConfig}                    central.system-config.app-config.update            Modules\GlobalMaster\Http\Controllers\AppConfigController@update
POST    system-config/app-config/{appConfig}/toggle-status      central.system-config.app-config.toggleStatus      Modules\GlobalMaster\Http\Controllers\AppConfigController@toggleStatus
PATCH   system-config/app-config/{appConfig}/value              central.system-config.app-config.updateValue       Modules\GlobalMaster\Http\Controllers\AppConfigController@updateValue
```

All four routes sit in `Modules/GlobalMaster/routes/web.php` inside `Route::domain(config('app.domain'))->name('central.')` with `middleware(['auth','verified'])` — central-only, so tenancy middleware does not apply (F5/RTE-05 satisfied for central routes). Route parameter `{appConfig}` matches the `AppConfig $appConfig` type-hints → implicit binding by id (proved: `parameterNames()` returns `[appConfig]` for update/updateValue/toggleStatus).

Unrouted public methods: `destroy()` at `AppConfigController.php:117` — **D5-compliant**: body is `abort(403, ...)` and the docblock says UNROUTED BY DECISION. Not a finding.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `store` | 34 | POST system-config/app-config | `prime.global-master.app-config.create` | `DB::transaction` (default `mysql` conn) | 'Stored' | glb_app_config, sys_central_activity_logs | AFC-01 |
| `update` | 62 | PUT system-config/app-config/{appConfig} | `prime.global-master.app-config.update` | `DB::transaction` (default `mysql` conn) | 'Edited' | glb_app_config, sys_central_activity_logs | AFC-01 |
| `updateValue` | 88 | PATCH system-config/app-config/{appConfig}/value | `prime.global-master.app-config.update` | **none** | 'Edited' | glb_app_config, sys_central_activity_logs | AFC-01, AFC-02 |
| `destroy` | 117 | — (unrouted, D5) | — | — | — | — | clean |
| `toggleStatus` | 128 | POST system-config/app-config/{appConfig}/toggle-status | `prime.global-master.app-config.update` | **none** | 'Toggled' | glb_app_config, sys_central_activity_logs | AFC-01, AFC-02 |

## 6. Findings

### F1 — Errors

#### AFC-01 · H · ERR-06 (D1/D2; ERR-05, TXN-05 folded) — every write method swallows failures in a controller try/catch that logs only the message and returns a fixed flash

| Field | Value |
|---|---|
| **Rule** | ERR-06 (H) — *no swallowed failures in write paths — an empty catch, or a catch that logs and then continues as if the write succeeded*. Protocol D1 overrides ERR-00: a controller try/catch is a finding unless a D2 shape applies; none does here. ERR-05 (M) — *log the exception object, not just getMessage()*. TXN-05 (M) — *build the redirect/response after the transaction closure*. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:38-59` (`store`), `:66-80` (`update`), `:92-102` (`updateValue`), `:132-152` (`toggleStatus`) |
| **Root cause** | The controller keeps the pre-2026-10-10 house rule A1 shape: `try { …write… return redirect(); } catch (ModelNotFoundException/ValidationException) { throw; } catch (\Throwable $e) { Log::error(…, ['error' => $e->getMessage()]); return back()->with('error', fixed string); }`. D1 forbids it. The `catch (ModelNotFoundException)` in store/update is also dead code: the route binds `AppConfig` implicitly, so a missing row 404s before the method runs. `Log::error(..., ['error' => $e->getMessage()])` loses the trace (ERR-05). store/update build the `redirect()` inside the transaction closure (TXN-05). |
| **Consequence** | When any part of a write fails, the user sees "The operation could not be completed." even when the setting row WAS written (see AFC-02 — on `updateValue`/`toggleStatus` there is no transaction, so the row commit is not rolled back), and the log entry has no stack trace. |
| **Reproduce** | Force the activity-log insert to fail (e.g. stop prime_db) while saving a setting: the value is saved to `glb_app_config`, the screen shows the red "could not be completed" flash, and the row is already changed. |
| **Fix approach** | Remove every `try/catch`; let `DB::transaction()` roll back and the central handler in `bootstrap/app.php` render. Move the `redirect()` out of the closure. On `toggleStatus`, the shared status-switch JS already reverts the checkbox on a jQuery `error:` response (proved — see §7), so the switch snaps back without the controller catch. |
| **Plan item** | AFC-01 in `02-fix-plan.md` §3 (items 1–4) |
| **Evidence** | see code block 2 |

```php
// AppConfigController.php:38-59 — CURRENT (store; update/updateValue/toggleStatus are the same shape)
    public function store(AppConfigRequest $request): RedirectResponse
    {
        Gate::authorize('prime.global-master.app-config.create');

        try {
            return DB::transaction(function () use ($request) {
                $data = $request->validated();

                // `key` is guarded on the model: application code looks a setting up by
                // (module_id, key), so it is written once here and never mass-assigned
                // on update. key_name is the label users are free to rename.
                $config = new AppConfig($data);
                $config->key = $data['key'];
                $config->save();

                activityLog($config, 'Stored', ['message' => 'A new application setting was created.']);

                return redirect()->to($this->backToTab())->with('success', flash('created.app_config'));
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('AppConfigController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
    }
```

**Evidence**
```
$ grep -n "catch (\|Log::error\|return redirect" Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php
53:        } catch (ModelNotFoundException $e) {
55:        } catch (\Throwable $e) {
56:            Log::error('AppConfigController::store failed', ['error' => $e->getMessage()]);
74:        } catch (ModelNotFoundException $e) {
76:        } catch (\Throwable $e) {
77:            Log::error('AppConfigController::update failed', ['error' => $e->getMessage()]);
98:        } catch (\Throwable $e) {
99:            Log::error('AppConfigController::updateValue failed', ['error' => $e->getMessage()]);
146:        } catch (ValidationException $e) {
148:        } catch (\Throwable $e) {
149:            Log::error('AppConfigController::toggleStatus failed', ['error' => $e->getMessage()]);
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php Modules/GlobalMaster/app/Models/AppConfig.php Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php
M  ERR-05   Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:56  store — logs getMessage() without the exception/trace
M  ERR-05   Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:77  update — logs getMessage() without the exception/trace
M  ERR-05   Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:99  updateValue — logs getMessage() without the exception/trace
M  ERR-05   Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:149  toggleStatus — logs getMessage() without the exception/trace
M  TXN-05   Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:51  store — HTTP response built inside DB::transaction closure
M  TXN-05   Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:72  update — HTTP response built inside DB::transaction closure
```

### F2 — Transactions and audit

#### AFC-02 · H · TXN-01 — updateValue and toggleStatus write two tables with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (two models, a model + its audit row…) runs inside one `DB::transaction`*. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:88-103` (`updateValue`), `:128-153` (`toggleStatus`) |
| **Root cause** | Both methods update `glb_app_config` (via `$appConfig->update(...)`) and then call `activityLog(...)`, which inserts into `sys_central_activity_logs` — two tables, different connections — with no `DB::transaction` anywhere. `store`/`update` do wrap in one (same pattern), these two do not. |
| **Consequence** | If the activity-log insert throws, the setting's value/status is already committed and the catch tells the user the operation could not be completed — a partial write presented as a failure (and the reverse lie as well: success flash with the audit row missing). |
| **Reproduce** | Flip a setting's status while the central activity-log write fails (stop prime_db): the row flips in `glb_app_config` (different connection), the switch shows the failure toast (AFC-01) and still lands. |
| **Fix approach** | Wrap update + activityLog in `DB::transaction(fn () => …)` in both methods, exactly as `store`/`update` do. |
| **Plan item** | AFC-02 in `02-fix-plan.md` §3 (items 3–4, folded into the AFC-01 rewrites) |
| **Evidence** | see code block 2 |

```php
// AppConfigController.php:92-102 — CURRENT (updateValue: two writes, no transaction)
        try {
            $appConfig->update(['value' => $request->validated()['value']]);

            activityLog($appConfig, 'Edited', ['message' => 'An application setting value was updated.']);

            return redirect()->to($this->backToTab())->with('success', flash('updated.app_config'));
        } catch (\Throwable $e) {
            Log::error('AppConfigController::updateValue failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "function updateValue\|function toggleStatus\|activityLog\|DB::transaction" Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php
39:            return DB::transaction(function () use ($request) {
67:            return DB::transaction(function () use ($request, $appConfig) {
88:    public function updateValue(AppConfigRequest $request, AppConfig $appConfig): RedirectResponse
93:            $appConfig->update(['value' => $request->validated()['value']]);
95:            activityLog($appConfig, 'Edited', ['message' => 'An application setting value was updated.']);
128:    public function toggleStatus(Request $request, AppConfig $appConfig)
138:            $appConfig->update(['is_active' => (bool) $validated['is_active']]);
140:            activityLog($appConfig, 'Toggled', [
# → updateValue and toggleStatus contain an update + activityLog but NO DB::transaction
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php
H  TXN-01   Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:88  updateValue — updateValue() makes 1 writes + activityLog with no transaction
H  TXN-01   Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:128  toggleStatus — toggleStatus() makes 1 writes + activityLog with no transaction
```

### F3 — Authorization

clean — every routed method calls `Gate::authorize` before loading or writing, the permission names are 4-part and declared in `config/permissionslist.php` (`'global-master.app-config' => $crud`, flattening to `prime.global-master.app-config.create/update/...`), and they appear on the view (`Gate::allows` + `permission=` in the pane) and are seeded with exact-name rows:

```
$ grep -n "global-master.app-config" config/permissionslist.php
226:        'global-master.app-config' => $crud,
$ php artisan tinker --execute 'DB::table("sys_permissions")->whereIn("name", ["prime.global-master.app-config.create","prime.global-master.app-config.update"])->pluck("name")'
prime.global-master.app-config.create, prime.global-master.app-config.update
$ php artisan tinker --execute '…->join("sys_roles", ...)->pluck("roles.name")'
Super Admin, Dev Team, App Maintenance
```

The FormRequest `authorize()` returns `true` and the controller holds the only Gate check → no AUTH-04 duplication. `destroy()` is unrouted, so no gate is expected (D5). Record-level authorization is not applicable: this table is a super-admin catalogue whose list is visible to every holder of the tab, so a 404-vs-403 ordering difference (AUTH-02) leaks nothing.

### F4 — Validation and input

#### AFC-03 · M · VAL-04 — uniqueness rules exclude trashed rows but the DB unique index includes them (latent)

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H, lowered to M — *latent only: no delete route can produce a trashed row today*) — *uniqueness rules mirror the DB unique index including soft-delete semantics. A DB unique index that includes trashed rows + a rule with `whereNull('deleted_at')` = a 500 on re-create*. |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php:38-44` (ordinal rule), `:64-69` (key rule) |
| **Root cause** | The DB indexes `uq_settings_key (module_id, key)` and `uq_settings_ordinal (module_id, ordinal)` include trashed rows (no `deleted_at` in the key — proved with `SHOW INDEX`). The FormRequest rules add `->whereNull('deleted_at')`, so a create/update that collides only with a TRASHED row passes validation and then dies on the DB unique constraint (1050 → 500). The table has 0 trashed rows today and no route can create one (`destroy()` aborts), so this cannot fire yet — it arms the moment a delete route or seeder writes a trashed row. |
| **Consequence** | A future soft-deleted setting (or a restored-then-recreated key) makes the screen 500 instead of showing a clean duplicate error. |
| **Reproduce** | Static only — requires a trashed row, which no current UI path produces (0 trashed today). The mismatch is proved by comparing `SHOW INDEX` with the rules. |
| **Fix approach** | Remove `->whereNull('deleted_at')` so the rule mirrors the index exactly (the app's design never soft-deletes these rows). Add a comment naming AFC-03 so a future delete feature changes the index instead. |
| **Plan item** | AFC-03 in `02-fix-plan.md` §2 |
| **Evidence** | see code block 2 |

```php
// AppConfigRequest.php:38-44 — CURRENT (the key rule at :64-69 has the same whereNull)
            'ordinal' => [
                'required', 'integer', 'min:0', 'max:65535',
                Rule::unique('global_master_mysql.glb_app_config', 'ordinal')
                    ->where(fn ($q) => $q->where('module_id', $moduleId))
                    ->ignore($configId)
                    ->whereNull('deleted_at'),
            ],
```

**Evidence**
```
$ php artisan tinker --execute 'DB::connection("global_master_mysql")->select("SHOW INDEX FROM glb_app_config")…'
PRIMARY(id); uq_settings_key(module_id); uq_settings_key(key); uq_settings_ordinal(module_id); uq_settings_ordinal(ordinal)
# → no deleted_at column in either unique key
$ php artisan tinker --execute '…glb_app_config->whereNotNull("deleted_at")->count()'
0
```

#### AFC-04 · M · VAL-07 — the TIME cross-field check accepts out-of-range clock values (25:99)

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M) — *cross-field / business checks go in the Form Request's `after()` hook* — here the hook exists but its TIME branch validates format only, not range. |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php:80-104`, specifically line 95 |
| **Root cause** | The `after()` hook checks `TIME` with `/^\d{2}:\d{2}(:\d{2})?$/`, which accepts hour 25 and minute 99. A consumer that later parses the stored value with `Carbon::parse('25:99')` throws. The hook exists precisely to stop values that do not match the selected type — the range gap lets one class of invalid value through. |
| **Consequence** | A super-admin typo (25:99) is stored as a TIME setting and can crash the consumer screen that reads it via `AppConfig::typedValue()`. |
| **Reproduce** | Executed (F4 §6): a real `AppConfigRequest` with `value_type=TIME, value=25:99` PASSES — proof in Evidence. |
| **Fix approach** | Replace the TIME regex with a range-checking one (`00-23` hours, `00-59` minutes/seconds). |
| **Plan item** | AFC-04 in `02-fix-plan.md` §5 |
| **Evidence** | see code block 2 |

```php
// AppConfigRequest.php:94-96 — CURRENT
                'DATE' => ! preg_match('/^\d{4}-\d{2}-\d{2}$/', $value),
                'TIME' => ! preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $value),
                'DATETIME' => strtotime($value) === false,
```

**Evidence**
```
$ php artisan tinker --execute '… AppConfigRequest::createFrom(Request::create("/x","POST",["value_type"=>"TIME","value"=>"25:99"])) …'
TIME/25:99 => ok            # ← 25:99 passes; a valid 23:59 also passes
$ php artisan tinker --execute '… same loop, the other six types …'
BOOLEAN/yes => ERR[The value does not match the selected type (BOOLEAN).]
NUMBER/abc => ERR[The value does not match the selected type (NUMBER).]
JSON/{bad  => ERR[The value does not match the selected type (JSON).]
DATE/12/31/2025 => ERR[The value does not match the selected type (DATE).]
DATETIME/not-a-date => ERR[The value does not match the selected type (DATETIME).]
STRING/2011-01-01 => ok
BOOLEAN/1 => ok / NUMBER/42.5 => ok / JSON/{"a":1} => ok / DATE/2025-12-31 => ok / TIME/23:59 => ok
```

### F5 — Routes

clean —

- no state change over GET (`RTE-01`): all mutations are POST/PUT/PATCH.
- every route points at a method that exists (`RTE-02`): the four routes above map to store/update/updateValue/toggleStatus.
- every public method is routed or follows D5 (`RTE-03`): `destroy()` aborts 403 with a NOT-ROUTED comment; `Route::has('.destroy')` is what hides the button in the shared action component (the pane confirms: "x-backend.table.action checks Route::has($url.'.destroy')").
- route parameter `{appConfig}` matches the controller argument on all three bound routes → implicit binding by id, not an unbound-INSERT trap (§12, `parameterNames()` proved).
- tenant middleware (`RTE-05`): not applicable — the routes are central-only (`Route::domain(config('app.domain'))`).
- custom routes before resource (`RTE-06`): no `Route::resource` here.

### F6 — Controller shape

#### AFC-05 · L · CTL-04 — two public methods and a helper lack return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* (`: View`, `: RedirectResponse`, `: JsonResponse`) |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:117-120` (`destroy`), `:128` (`toggleStatus`), `:159` (`toggleResponse`) |
| **Root cause** | `store`/`update`/`updateValue` declare `: RedirectResponse`; the other three methods do not. |
| **Consequence** | None at runtime — pure consistency debt; the scanner flags it. |
| **Reproduce** | Static only — the signatures are visible in source; there is no runtime path difference. |
| **Fix approach** | `destroy(): never` (it always aborts); `toggleStatus(): RedirectResponse\|JsonResponse`; `toggleResponse(): RedirectResponse\|JsonResponse` with the `JsonResponse` import added. |
| **Plan item** | AFC-05 in `02-fix-plan.md` §8 |
| **Evidence** | see code block 2 |

```php
// AppConfigController.php:117-120 — CURRENT (destroy; toggleStatus at :128 and toggleResponse at :159 also lack types)
    public function destroy(AppConfig $appConfig)
    {
        abort(403, 'App settings cannot be deleted. Deactivate the setting instead.');
    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-commonchat.json Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:117  destroy — destroy() has no return type
L  CTL-04   Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:128  toggleStatus — toggleStatus() has no return type
$ grep -n "function toggleStatus\|function toggleResponse" Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php
128:    public function toggleStatus(Request $request, AppConfig $appConfig)
159:    private function toggleResponse(Request $request, bool $ok, bool $isActive, string $message)
```

Remaining F6: controller is 173 lines / 5 public methods (CTL-01 clean); longest method ~25 lines (CTL-02 clean); route model binding used (CTL-03 clean); the store/update/updateValue copy-paste (CTL-05) IS the A1 try/catch being removed by AFC-01 — one rewrite per method, no separate finding; no `compact()` abuse, no `request()` helper (CTL-07/08 clean); no debug leftovers:

```
$ grep -nE 'dd\(|dump\(|var_dump|print_r|ray\(|phpinfo' Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php Modules/GlobalMaster/app/Models/AppConfig.php Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php
→ no output
```

### F7 — Models

The model `AppConfig.php` (claimed here) is healthy: `$fillable` declared with nothing sensitive (MDL-01) and `key` deliberately excluded; `$casts` covers every boolean plus `ordinal` + `additional_info` (MDL-02); `SoftDeletes` matches the table's `deleted_at` (proved by SHOW COLUMNS); `$table` exists and is created by `Modules/GlobalMaster/database/migrations/2026_08_31_120100_create_glb_app_config_table.php` (MDL-07); `module(): BelongsTo` is return-typed and resolves (MDL-04); no Spatie media (MDL-05/TEN-01 n/a); `BaseModel` adds no global scopes (MDL-08 clean); `$timestamps` default with `created_at/updated_at` present.

#### AFC-08 · L · MDL-09 — the seven `value_type` literals are repeated across files, not a single enum/constants

| Field | Value |
|---|---|
| **Rule** | MDL-09 (L) — *status/type strings are PHP enums or model constants, not literals repeated across files* |
| **Where** | `Modules/GlobalMaster/app/Models/AppConfig.php:59-64` (`typedValue()`); the same literals also appear in the migration `2026_08_31_120100_create_glb_app_config_table.php:71-73` and in `Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php:47`, plus the seeder |
| **Root cause** | The string list `STRING, NUMBER, BOOLEAN, DATE, TIME, DATETIME, JSON` is spelled out in the migration enum, the request's `Rule::in`, and the model's `match`. Adding a type means editing three+ places. |
| **Consequence** | None today; drift risk when a type is added (e.g. a new validation type that the model's `typedValue()` does not know falls to `default => $this->value` silently). |
| **Reproduce** | Static only — duplication read in three files. |
| **Fix approach** | Introduce a `ValueType` PHP enum (or model constants) and reference it in request + model. Refactor, not safety — deferred in this pass. |
| **Plan item** | none — see `02-fix-plan.md` §10 |
| **Evidence** | see code block 2 |

```php
// AppConfig.php:59-64 — CURRENT (typedValue; the same literals appear in the migration enum and AppConfigRequest.php:47)
        return match ($this->value_type) {
            'BOOLEAN' => filter_var($this->value, FILTER_VALIDATE_BOOLEAN),
            'NUMBER' => is_numeric($this->value) ? $this->value + 0 : null,
            'JSON' => json_decode($this->value, true),
            default => $this->value,
        };
```

**Evidence**
```
$ grep -n "STRING'\|'NUMBER'\|'BOOLEAN'\|'JSON'" Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php
47:            'value_type' => ['required', Rule::in(['STRING', 'NUMBER', 'BOOLEAN', 'DATE', 'TIME', 'DATETIME', 'JSON'])],
$ grep -n "STRING" Modules/GlobalMaster/database/migrations/2026_08_31_120100_create_glb_app_config_table.php
71:            $table->enum('value_type', [
```

### F8 — Services and jobs

clean — no services, jobs, events, mail or notifications are used or injected (`grep -oE '…(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b'` returns only `AppConfigRequest`).

### F9 — Queries and performance

clean — the four mutations are single-row writes; no loops, no N+1, no lists, no SQL interpolation, no caching. The list itself is rendered by the Settings screen, not this controller.

```
$ grep -nE "foreach|->get\(\)|::all\(|whereRaw|DB::raw" Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php
→ no output
```

### F10 — Views

clean (spot-check of the pane `_pane.blade.php`, which is rendered by the Prime Settings controller): no `Model::`/`DB::`/`->get()` in the blade (VIEW-01); the `@foreach` over `$configs` receives a preloaded collection from the Settings controller — no lazy loads here (VIEW-02); no `{!! !!}` on user text (VIEW-03); permissions appear on the view as `Gate::allows('prime.global-master.app-config.create'/'…update')` and `permission="prime.global-master.app-config.update"` on the shared status-switch and action components — the four surfaces agree.

### F11 — Security and tenancy

clean — no `env()` in the three files (`grep -n 'env('` → no output); `toggleResponse` returns only `success/is_active/message` (no PII, SEC-02); no hard-coded ids or `?? 1` fallbacks (SEC-03); the logs on the write path log only the exception message with no request body (SEC-04 — and the catch disappears with AFC-01); files: none served. Tenancy: the routes are central-only; `AppConfig` pins `$connection = 'global_master_mysql'` explicitly (no TEN-02/03/04 surface here — no caching, no central-model-from-tenant access, no files).

### F12 — Style

#### AFC-06 · L · STY-01 — AppConfig.php lacks declare(strict_types=1)

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `Modules/GlobalMaster/app/Models/AppConfig.php:1-3` |
| **Root cause** | The controller and the request both declare `strict_types`; the model does not. |
| **Consequence** | None at runtime — style consistency debt; a future strict call would silently coerce. |
| **Reproduce** | Static only — compare the top of the three files. |
| **Fix approach** | Add `declare(strict_types=1);` after `<?php` in the model. |
| **Plan item** | AFC-06 in `02-fix-plan.md` §8 |
| **Evidence** | see code block 2 |

```php
// AppConfig.php:1-3 — CURRENT
<?php

namespace Modules\GlobalMaster\Models;
```

**Evidence**
```
$ head -3 Modules/GlobalMaster/app/Models/AppConfig.php
<?php

namespace Modules\GlobalMaster\Models;
$ head -3 Modules/GlobalMaster/app/Models/AppConfig.php | grep -c "strict_types"
0
```

#### AFC-07 · L · STY-04 — emoji markers in two comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php:106` and `Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php:19` |
| **Root cause** | The controller's destroy docblock opens with `⛔` and the request's `rules()` comment opens with `⚠`. |
| **Consequence** | None — style debt; grep-based tooling catches them as noise. |
| **Reproduce** | Static only — read the two comment lines. |
| **Fix approach** | Remove the two emoji characters, keep the text. |
| **Plan item** | AFC-07 in `02-fix-plan.md` §8 |
| **Evidence** | see code block 2 |

```php
    /**
     * ⛔ UNROUTED BY DECISION (2026-08-31) — there is no delete route for these settings.
     *
```

**Evidence**
```
$ grep -nP '[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}\x{23CE}\x{2B00}-\x{2BFF}]' Modules/GlobalMaster/app/Http/Controllers/AppConfigController.php
106:     * ⛔ UNROUTED BY DECISION (2026-08-31) — there is no delete route for these settings.
$ grep -nP '[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}\x{23CE}\x{2B00}-\x{2BFF}]' Modules/GlobalMaster/app/Http/Requests/AppConfigRequest.php
19:        // ⚠ updateValue() edits ONE column inline. Validating the full row there would
```

Everything else STY is clean: one import per class, camelCase, English comments, no commented-out code.

### F13 — Deep read

| Q | store | update | updateValue | toggleStatus |
|---|---|---|---|---|
| 1. overwrite data it should not? | ok — `key` guarded/immutable, fillable-only mass assign | ok — `validated()` excludes `key`/`module_id` on update | ok — only `value` written | ok — only `is_active` written, posted value not stale negation |
| 2. deleted before replacement stored? | ok | ok | ok | ok |
| 3. duplicate implementations? | ok — one write path per operation | ok | ok | ok |
| 4. soft-delete × unique trap? | ok (no trashed rows possible today) | ok | ok | ok — but see AFC-03 (request-level latent) |
| 5. race? | unique index backs the FormRequest unique rule (TXN-06 mit.); residual concurrent-duplicate → central 500, acceptable | ok | ok | ok — the negative-state race the code comments about is handled by using the posted value |
| 6. authorization hole? | ok — Gate before write | ok | ok | ok |
| 7. message lies? | **AFC-01/AFC-02** — fixed flash on partial success | **AFC-01/AFC-02** — same | **AFC-01/AFC-02** — write commits (no tx), flash says failed | **AFC-01/AFC-02** — same |
| 8. dead feature? | ok | ok | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `DB::transaction` semantics across connections | `DB::transaction()` runs on the default `mysql` (prime_db) connection, but the `AppConfig` write goes to `global_master_mysql`. Even `store`/`update` cannot roll back the global-master row when the central activity-log insert fails — the "atomic" transaction is partial. Affects every central controller writing to a `global_*` connection. | TXN-01 | architecture / module-wide pattern (report in 00-SUMMARY) |
| Shared status-switch JS (`footer-scripts.blade.php:220-238`) | The jQuery `error:` branch reverts the checkbox — so removing the toggleStatus try/catch (AFC-01) is UI-safe: a 500 snaps the switch back. Confirmed, not a defect. | — | none |
| `Modules/GlobalMaster/routes/web.php` `system-config` group | Carries `['auth','verified']` but not `2fa`, while the sibling `/prime/*` group carries `2fa`. Route-file-level difference; shared file. | AUTH-adjacent | route-file owner (cross-cutting, not this plan) |
| `Modules/GlobalMaster/app/Models/AppModule.php` | Reached by `AppConfig::module()`; resolves fine in tinker. Full audit lives in AppModuleController's report (owner CLAIMED). | — | AppModuleController report |

## 8. Not covered, and why

- **List rendering and the create/edit modals** — `app-config/_pane.blade.php` is rendered by the Prime `SettingController`; only spot-checked for F10. Modal markup, the module dropdown and the search bar are that controller's scope.
- **Concurrent duplicate-key creates** (TXN-06 residual) — not fired (D4: no test execution); mitigated by FormRequest unique rules + DB unique index.
- **Browser behaviour of the toggle switch** — the shared JS was read, not executed; D4 forbids running the screen.
- **Seeder content** — `AppConfigSeeder` read only for the `value_type` duplication evidence (AFC-08), not executed.