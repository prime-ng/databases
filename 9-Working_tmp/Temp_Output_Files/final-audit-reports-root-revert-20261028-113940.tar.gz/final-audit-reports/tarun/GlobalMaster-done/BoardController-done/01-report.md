# Final Audit — GlobalMaster / BoardController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/BoardController.php` (250 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/global-master/board` (list), `/global-master/board/create`, `/global-master/board/{board}` (show), `/global-master/board/{board}/edit`, `/global-master/board/trash/view` (trash). Create/edit/delete/restore all redirect afterwards to `http://test.localhost:8000/prime/session-board-setup#academicboard`. |
| Menu path | Global Master side, reached from the **Session & Board Setup** tab screen (`central.prime.session-board-setup.index#academicboard`). The standalone `board.index` list is reached by the routes below and from the tenant setup partial. |
| Who uses it | Central platform / super-admin side. Holders of `prime.global-master.board.*` (measured in `sys_role_has_permissions_jnt`): `viewAny` and `view` are held by Super Admin, Dev Team, App Maintenance, School Admin, Support Team, CRM Team, Finance & Billing, Sales Team and Demo; `create`, `update`, `delete`, `restore` and `forceDelete` are held by **Super Admin, Dev Team, App Maintenance and School Admin** only. |
| What a user does here | A platform operator maintains the academic-board catalogue (for example CBSE, ICSE, a State Board): adds a board with a name, a short name and an active flag, edits it, views it, moves it to trash, restores it, permanently deletes it, and switches its active/inactive status from the list. Boards are the values an organization is later linked to together with an academic session. |
| Tables written | `glb_boards` (create/update/soft-delete/restore/force-delete), plus one central `activity_logs` row per mutation written by the common `activityLog()` helper. |
| Tables read | `glb_boards` (all list/show/edit pages). The model also declares an `organizations()` relation that would read `sch_organizations` and `sch_board_organization_jnt`, but it is broken — see BOA-11. |
| Live data | On `global_master_mysql`: `glb_boards` **10 rows, 0 trashed**. On the tenant `mysql` connection: `sch_board_organization_jnt` **0 rows** (nothing is linked to any board today). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready: **BOA-07** writes raw request input straight into the model (`Board::create($request->all())` and `$board->update($request->all())`), which is a blocker under the project rule that models are never filled from `$request->all()`; today `$fillable` happens to restrict it to three columns, so the practical exposure is small but the pattern is banned. The single worst finding is that a **trashed board's name can never be reused** because the uniqueness rule and the live `UNIQUE` index both count soft-deleted rows — but the more urgent and reachable problem is that **`Board::organizations()` is a dead relation that throws a "table not found" SQL error** the moment anyone calls it, because `Board` lives on `global_master_mysql` while the pivot and `sch_organizations` live in the tenant DB. The rest is the retired "Rule A1" try/catch envelope, which protocol **D1** now bans, plus a GET route that mutates state, missing return types and copy-paste in the blades. Effort to apply the plan: **S–M** — the changes are mechanical, plus one edit to the shared route file (marked ⚠ SHARED).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 3 | 6 | 8 | 1 | 18 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BOA-01, BOA-02, BOA-03, BOA-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | BOA-05 | F9 Queries/Perf | clean |
| F3 Authorization | BOA-06 | F10 Views | BOA-13, BOA-14 |
| F4 Validation | BOA-07 | F11 Security/Tenancy | clean |
| F5 Routes | BOA-08 | F12 Style | BOA-15, BOA-16 |
| F6 Controller shape | BOA-09, BOA-10 | F13 Deep read | BOA-17, BOA-18 |
| F7 Models | BOA-11, BOA-12 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php` | controller | 250 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Models/Board.php` | model | 37 | this report (claimed in `_Info/00-CLASS-OWNERS.md`) | ✅ |
| 3 | `Modules/GlobalMaster/app/Http/Requests/BoardRequest.php` | form request | 59 | this report (claimed in `_Info/00-CLASS-OWNERS.md`) | ✅ |
| 4 | `Modules/GlobalMaster/routes/web.php` (lines 129-135 only) | route file | 198 | ⚠ SHARED — board rows only | ✅ usage; edits are ⚠ SHARED |
| 5 | `Modules/GlobalMaster/resources/views/board/index.blade.php` | view | 62 | this report | ✅ |
| 6 | `Modules/GlobalMaster/resources/views/board/create.blade.php` | view | 56 | this report | ✅ |
| 7 | `Modules/GlobalMaster/resources/views/board/edit.blade.php` | view | 58 | this report | ✅ |
| 8 | `Modules/GlobalMaster/resources/views/board/show.blade.php` | view | 58 | this report | ✅ |
| 9 | `Modules/GlobalMaster/resources/views/board/trash.blade.php` | view | 54 | this report | ✅ |
| 10 | `Modules/SchoolSetup/app/Models/Organization.php` | model (relation target) | 320 | not claimed — owned by `OrganizationController` (later batch) | ↗ linked — usage only; the relation is broken (BOA-11) |
| 11 | `App\Http\Controllers\Controller`, `App\Models\BaseModel`, `App\Traits\AuthorizesTenantFeature`, `app/Helpers/activityLog.php`, `app/Helpers/helpers.php` (`flash`), `config/permissionslist.php`, `resources/views/components/backend/table/{action,action-trashed,status-switch}.blade.php` plus their classes under `app/View/Components/Backend/Table/` | common | — | common (§4.2) | referenced, not owned |

No pre-applied files — no `PRE-APPLIED-2026-10-10.md` exists for GlobalMaster.

Classes claimed in `_Info/00-CLASS-OWNERS.md` by this report: `Modules/GlobalMaster/app/Models/Board.php`, `Modules/GlobalMaster/app/Http/Requests/BoardRequest.php`. `Organization.php` is used only as the target of the broken `Board::organizations()` relation and is linked, not claimed.

## 4. Routes

Uncached route list filtered for `BoardController@` (from the fresh `/tmp/fa-routes.json`, generated with `APP_ROUTES_CACHE=/tmp/fa-nocache.php`):

```
GET|HEAD global-master/board                                   central.global-master.board.index         BoardController@index
POST     global-master/board                                   central.global-master.board.store         BoardController@store
GET|HEAD global-master/board/create                            central.global-master.board.create        BoardController@create
GET|HEAD global-master/board/trash/view                        central.global-master.board.trashed       BoardController@trashedBoard
GET|HEAD global-master/board/{board}                           central.global-master.board.show          BoardController@show
PUT|PATCH global-master/board/{board}                          central.global-master.board.update        BoardController@update
DELETE   global-master/board/{board}                           central.global-master.board.destroy       BoardController@destroy
GET|HEAD global-master/board/{board}/edit                      central.global-master.board.edit          BoardController@edit
POST     global-master/board/{board}/toggle-status             central.global-master.board.toggleStatus  BoardController@toggleStatus
DELETE   global-master/board/{id}/force-delete                 central.global-master.board.forceDelete   BoardController@forceDelete
GET|HEAD global-master/board/{id}/restore                      central.global-master.board.restore       BoardController@restore
```

Unrouted public methods: **none** — all 11 public methods are routed (RTE-03 clean; RTE-02 clean: every route resolves to an existing method).

Route file: `Modules/GlobalMaster/routes/web.php:129-135`, inside `Route::domain(config('app.domain'))` (central only) with the `['auth','verified']` middleware group (lines 127). `Route::resource('board', …)` (line 130) is registered **before** the four custom routes (131-134). The custom URIs carry a distinguishing literal segment (`/board/trash/view`, `/board/{id}/restore`, `/board/{id}/force-delete`, `/board/{board}/toggle-status`) that the resource's single-segment `/{board}` cannot capture, so RTE-06 is not triggered. There is no `prime/board` copy (unlike Country/City).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | GET /global-master/board | `prime.global-master.board.viewAny` | none (read) | — | reads glb_boards | BOA-10 |
| `create` | 25 | GET /global-master/board/create | `prime.global-master.board.create` | none (read) | — | — | BOA-10, BOA-13 |
| `store` | 32 | POST /global-master/board | `prime.global-master.board.create` (+ FormRequest) | controller `DB::transaction` | Stored | glb_boards, sys_activity_logs | BOA-01, BOA-03, BOA-05, BOA-06, BOA-07 |
| `show` | 56 | GET /global-master/board/{board} | `prime.global-master.board.view` | none (read) | — | reads glb_boards | BOA-10 |
| `edit` | 63 | GET /global-master/board/{board}/edit | `prime.global-master.board.update` | none (read) | — | reads glb_boards | BOA-09, BOA-10, BOA-13 |
| `update` | 71 | PUT/PATCH /global-master/board/{board} | `prime.global-master.board.update` (+ FormRequest) | controller `DB::transaction` | Updated | glb_boards, sys_activity_logs | BOA-01, BOA-03, BOA-05, BOA-06, BOA-07 |
| `destroy` | 120 | DELETE /global-master/board/{board} | `prime.global-master.board.delete` | controller `DB::transaction` | Trashed | glb_boards, sys_activity_logs | BOA-01, BOA-03, BOA-05, BOA-09, BOA-18 |
| `trashedBoard` | 147 | GET /global-master/board/trash/view | `prime.global-master.board.restore` | none (read) | — | reads glb_boards | BOA-10 |
| `restore` | 155 | GET /global-master/board/{id}/restore | `prime.global-master.board.restore` | controller `DB::transaction` | Restored | glb_boards, sys_activity_logs | BOA-01, BOA-03, BOA-05, BOA-08, BOA-09, BOA-18 |
| `forceDelete` | 180 | DELETE /global-master/board/{id}/force-delete | `prime.global-master.board.forceDelete` | controller `DB::transaction` | Deleted | glb_boards, sys_activity_logs | BOA-01, BOA-03, BOA-05, BOA-09, BOA-17 |
| `toggleStatus` | 205 | POST /global-master/board/{board}/toggle-status | `prime.global-master.board.update` | controller `DB::transaction` | Toggled | glb_boards, sys_activity_logs | BOA-01, BOA-02, BOA-03, BOA-04, BOA-05 |

## 6. Findings

### F1 — Errors

#### BOA-01 · H · ERR-00 (settled by D1) — the six mutating methods wrap their writes in a controller try/catch

| Field | Value |
|---|---|
| **Rule** | ERR-00 (H, raised from "undecided" by protocol D1) — *the Laravel idiom: no try/catch in controllers; `DB::transaction()` rolls back by itself and the central handler in `bootstrap/app.php` renders the error*. The same blocks also break ERR-05 (M) — *log the exception, not the message*. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:36-53` (`store`); identical envelope at `:75-117` (`update`), `:124-144` (`destroy`), `:159-177` (`restore`), `:184-202` (`forceDelete`), `:209-248` (`toggleStatus`) |
| **Root cause** | Every mutating method follows the retired house "Rule A1" shape: `try { DB::transaction(...) } catch (ModelNotFoundException) { throw } catch (\Throwable) { log; back() }`. Protocol D1 supersedes A1 for audited modules and none of the D2 exceptions apply (no `\DomainException`, no truncate-then-rebuild, no `SnapshotProtectionException`). The `catch (ModelNotFoundException)` rethrow is unreachable in `store`, `update` and `toggleStatus` (no `findOrFail` runs there — the bound `Board` already exists). |
| **Consequence** | On any unexpected failure the user gets the vague "The operation could not be completed." instead of the framework's error page, and the log records only the message with no stack trace, so the true failing call cannot be located. |
| **Reproduce** | static only — exercising a failing write needs a DB error and D4 forbids tests. The six envelopes are visible at the line ranges above. |
| **Fix approach** | Delete the try/catch envelope in all six methods; have each closure return the model (or a boolean) and build the redirect/JSON after `DB::transaction()`; move `$request->validate()` above the transaction in `toggleStatus`. This also applies BOA-02, BOA-03, BOA-04, BOA-05 and BOA-07. |
| **Plan item** | BOA-01 in `02-fix-plan.md` §1 |

```php
// BoardController.php:36-53 — CURRENT (store; same envelope in update/destroy/restore/forceDelete/toggleStatus)
        try {
            return DB::transaction(function () use ($request) {
                $board = Board::create($request->all());

                activityLog($board, 'Stored', ['message' => 'A new board was created.', 'other' => 'some other information']);

                return redirect()->to(route('central.prime.session-board-setup.index').'#academicboard')->with('success', flash('created.board'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BoardController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -c "try {" Modules/GlobalMaster/app/Http/Controllers/BoardController.php
6
$ grep -n "catch (" Modules/GlobalMaster/app/Http/Controllers/BoardController.php
45:        } catch (ModelNotFoundException $e) {
49:        } catch (\Throwable $e) {
109:        } catch (ModelNotFoundException $e) {
113:        } catch (\Throwable $e) {
136:        } catch (ModelNotFoundException $e) {
140:        } catch (\Throwable $e) {
169:        } catch (ModelNotFoundException $e) {
173:        } catch (\Throwable $e) {
194:        } catch (ModelNotFoundException $e) {
198:        } catch (\Throwable $e) {
240:        } catch (ModelNotFoundException $e) {
244:        } catch (\Throwable $e) {
```

#### BOA-02 · H · ERR-02 — `toggleStatus` validates inside the try, so the generic catch swallows the 422

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422/`abort()` into a redirect or 500* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:209-248`, method `toggleStatus()` |
| **Root cause** | `$request->validate([...])` runs **inside** `DB::transaction` and inside the `try`; the generic `catch (\Throwable $e)` catches the `ValidationException` it throws. |
| **Consequence** | A bogus `is_active` value sent by the status-switch AJAX call returns a `back()` HTML redirect (302) instead of the JSON 422 the caller expects; the switch flips back with no message. |
| **Reproduce** | `curl -X POST http://test.localhost:8000/global-master/board/1/toggle-status -d 'is_active=banana'`. Expected JSON 422; actual 302 HTML redirect. |
| **Fix approach** | Move `$request->validate([...])` above the transaction and remove the try — under D1 there is no catch left to swallow the exception. Applied by plan item BOA-01. |
| **Plan item** | none — applied by plan item BOA-01 (see `02-fix-plan.md` §10) |

```php
// BoardController.php:209-215 — CURRENT (validate sits inside the try)
        try {
            return DB::transaction(function () use ($request, $board) {
                $request->validate([
                    'is_active' => 'required|boolean',
                ]);
                $newStatus = $request->input('is_active');
                $board->is_active = $newStatus;
```

**Evidence**
```
$ grep -n "validate(" Modules/GlobalMaster/app/Http/Controllers/BoardController.php
211:                $request->validate([
$ grep -n "catch (\\\\Throwable" Modules/GlobalMaster/app/Http/Controllers/BoardController.php
49:        } catch (\Throwable $e) {
113:        } catch (\Throwable $e) {
140:        } catch (\Throwable $e) {
173:        } catch (\Throwable $e) {
198:        } catch (\Throwable $e) {
244:        } catch (\Throwable $e) {
```

#### BOA-03 · M · ERR-05 — the six log calls drop the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error(…, ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:50,114,141,174,199,245` (`store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`) |
| **Root cause** | The retired A1 catch template logs `['error' => $e->getMessage()]`, the exact anti-pattern the rulebook's Contradictions table bans. |
| **Consequence** | Every failure is logged without a stack trace; raw SQL text also leaks into the log file, and the failing call cannot be located from the line alone. |
| **Reproduce** | static only — the log line shape is visible at each line above. |
| **Fix approach** | With the try removed (BOA-01) the `Log::error` lines disappear entirely; nothing logs a bare message. Applied by plan item BOA-01. |
| **Plan item** | none — applied by plan item BOA-01 (see `02-fix-plan.md` §10) |

```php
// BoardController.php:50 — CURRENT (identical at 114, 141, 174, 199, 245)
            Log::error('BoardController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "Log::error" Modules/GlobalMaster/app/Http/Controllers/BoardController.php
50:            Log::error('BoardController::store failed', ['error' => $e->getMessage()]);
114:            Log::error('BoardController::update failed', ['error' => $e->getMessage()]);
141:            Log::error('BoardController::destroy failed', ['error' => $e->getMessage()]);
174:            Log::error('BoardController::restore failed', ['error' => $e->getMessage()]);
199:            Log::error('BoardController::forceDelete failed', ['error' => $e->getMessage()]);
245:            Log::error('BoardController::toggleStatus failed', ['error' => $e->getMessage()]);
```

#### BOA-04 · M · ERR-04 — `toggleStatus` mixes a JSON success with an HTML failure and never checks `expectsJson()`

| Field | Value |
|---|---|
| **Rule** | ERR-04 (M) — *JSON endpoints fail with JSON; form endpoints fail with a redirect; use `$request->expectsJson()` when one method serves both* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:226-247`, method `toggleStatus()` |
| **Root cause** | The success branch returns `response()->json(...)` but the failure branch of the enclosing catch returns `back()->with('error', ...)` (HTML). The endpoint is only ever called by the AJAX status switch. |
| **Consequence** | Any failure delivers HTML to the JSON caller; the toggle silently fails with no user message. |
| **Reproduce** | `curl -X POST http://test.localhost:8000/global-master/board/1/toggle-status` with no `is_active`; inspect `Content-Type`: `text/html`, not JSON. |
| **Fix approach** | Remove the try (BOA-01) so no catch returns HTML; keep `$request->validate()` outside the transaction so the 422 the central renderer produces is JSON for AJAX. Applied by plan item BOA-01. |
| **Plan item** | none — applied by plan item BOA-01 (see `02-fix-plan.md` §10) |

```php
// BoardController.php:226-237 — CURRENT (JSON success; the HTML failure is the catch at 247)
                    return response()->json([
                        'success' => true,
                        'is_active' => $board->is_active,
                        'message' => flash('status_updated.board'),
                    ]);
                } else {
                    return response()->json([
                        'success' => false,
                        'is_active' => $board->is_active,
                        'message' => flash('status_switch_failed.board'),
                    ]);
```

**Evidence**
```
$ grep -n "response()->json\|back()" Modules/GlobalMaster/app/Http/Controllers/BoardController.php
52:            return back()->with('error', 'The operation could not be completed.');
116:            return back()->with('error', 'The operation could not be completed.');
143:            return back()->with('error', 'The operation could not be completed.');
176:            return back()->with('error', 'The operation could not be completed.');
201:            return back()->with('error', 'The operation could not be completed.');
226:                    return response()->json([
232:                    return response()->json([
247:            return back()->with('error', 'The operation could not be completed.');
```

### F2 — Transactions and audit

#### BOA-05 · M · TXN-05 — HTTP responses are built inside the `DB::transaction` closure in all six mutating methods

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()`/`response()` after it* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:37-42, 76-106, 125-133, 160-166, 185-191, 210-237` (`store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`) |
| **Root cause** | Each closure ends with `return redirect()...` / `return response()->json(...)`, so the flash and URL are constructed while the transaction is still open; the commit only happens because the closure returns the response. |
| **Consequence** | No user-visible break today (the closure returns the response and the method returns it), but it couples response construction to the atomic block and is the reason the try/catch envelope (BOA-01) looks necessary. |
| **Reproduce** | static only — read any of the six closures. |
| **Fix approach** | Have the closure return the model (or a boolean), then build the redirect/JSON after `DB::transaction()` returns. Applied by plan item BOA-01. |
| **Plan item** | none — applied by plan item BOA-01 (see `02-fix-plan.md` §10) |

```php
// BoardController.php:37-42 — CURRENT (store; same return-inside-closure shape in the other five)
            return DB::transaction(function () use ($request) {
                $board = Board::create($request->all());

                activityLog($board, 'Stored', ['message' => 'A new board was created.', 'other' => 'some other information']);

                return redirect()->to(route('central.prime.session-board-setup.index').'#academicboard')->with('success', flash('created.board'));
```

**Evidence**
```
$ grep -n "return DB::transaction\|return redirect\|return response" Modules/GlobalMaster/app/Http/Controllers/BoardController.php
37:            return DB::transaction(function () use ($request) {
42:                return redirect()->to(route('central.prime.session-board-setup.index').'#academicboard')->with('success', flash('created.board'));
76:            return DB::transaction(function () use ($request, $board) {
106:                return redirect()->to(route('central.prime.session-board-setup.index').'#academicboard')->with('success', flash('updated.board'));
125:            return DB::transaction(function () use ($id) {
133:                return redirect()->to(route('central.prime.session-board-setup.index').'#academicboard')->with('success', flash('trashed.board'));
160:            return DB::transaction(function () use ($id) {
166:                return redirect()->route('central.global-master.board.trashed')->with('success', flash('restored.board'));
185:            return DB::transaction(function () use ($id) {
191:                return redirect()->route('central.global-master.board.trashed')->with('success', flash('force_deleted.board'));
210:            return DB::transaction(function () use ($request, $board) {
226:                    return response()->json([
232:                    return response()->json([
```

### F3 — Authorization

#### BOA-06 · L · AUTH-04 — `store` and `update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (FormRequest `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:34` and `:73`; `Modules/GlobalMaster/app/Http/Requests/BoardRequest.php:42-48` |
| **Root cause** | `BoardRequest::authorize()` maps POST to `prime.global-master.board.create` and PUT/PATCH to `prime.global-master.board.update`, and the controller then calls `Gate::authorize` for the same names immediately after. The FormRequest runs first, so the controller call can never change the outcome. |
| **Consequence** | No security gap — the check is redundant, so it costs one extra Gate lookup and creates a second place to keep in sync. |
| **Reproduce** | static only — both checks pass or fail together. Permission keys verified present in `config/permissionslist.php:251` (`global-master.board`) with the seven `$crud` actions. |
| **Fix approach** | Keep the FormRequest `authorize()` (it runs first) and drop the two `Gate::authorize` calls in `store()` and `update()`. Applied by plan item BOA-06. |
| **Plan item** | BOA-06 in `02-fix-plan.md` §4 |

```php
// BoardController.php:34 — CURRENT (store; update is identical at :73)
        Gate::authorize('prime.global-master.board.create');
```
```php
// BoardRequest.php:42-48 — CURRENT (the FormRequest authorize that already gates store/update)
    public function authorize(): bool
    {
        // T6b — mirrors the controller's own gate: prime.board.create on POST,
        // prime.board.update on PUT/PATCH. Same permission, checked one step
        // earlier, so this narrows nothing and widens nothing.
        return $this->authorizeByCrudPermission('prime.global-master.board');
    }
```

**Evidence**
```
$ grep -n "Gate::authorize\|authorizeByCrudPermission" Modules/GlobalMaster/app/Http/Controllers/BoardController.php Modules/GlobalMaster/app/Http/Requests/BoardRequest.php
BoardController.php:34:        Gate::authorize('prime.global-master.board.create');
BoardController.php:73:        Gate::authorize('prime.global-master.board.update');
BoardRequest.php:47:        return $this->authorizeByCrudPermission('prime.global-master.board');
```

### F4 — Validation and input

#### BOA-07 · B · VAL-01 — raw request input is written straight into the model

| Field | Value |
|---|---|
| **Rule** | VAL-01 (B) — *never write unvalidated input: no `create($request->all())`, `update($request->all())`, `fill($request->all())`, `$request->except(...)` into a model* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:38` (`store`) and `:78` (`update`) |
| **Root cause** | The validated FormRequest data is discarded and `$request->all()` is passed to the model. `Board::$fillable` restricts the write to `name`, `short_name`, `is_active`, so the extra keys are dropped — but the write does not use the validated payload, so any future `$fillable` change silently widens mass assignment. |
| **Consequence** | Today the exposure is limited by `$fillable`, but the pattern is banned because a `$fillable` edit turns it into mass assignment; the safe call is `$request->validated()`. |
| **Reproduce** | static only — the two `$request->all()` writes are at lines 38 and 78. |
| **Fix approach** | Replace both with `$request->validated()`. Applied by plan item BOA-01 (which rewrites both methods). |
| **Plan item** | none — applied by plan item BOA-01 (see `02-fix-plan.md` §10) |

```php
// BoardController.php:38 — CURRENT
                $board = Board::create($request->all());
```
```php
// BoardController.php:78 — CURRENT
                $board->update($request->all());
```

**Evidence**
```
$ grep -n "request->all()" Modules/GlobalMaster/app/Http/Controllers/BoardController.php
38:                $board = Board::create($request->all());
78:                $board->update($request->all());
```

### F5 — Routes

#### BOA-08 · H · RTE-01 — the `restore` route changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/GlobalMaster/routes/web.php:132`; handled by `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:155-178` `restore()`; the trash view calls it through `resources/views/components/backend/table/action-trashed.blade.php:29-44` |
| **Root cause** | `Route::get('/board/{id}/restore', …)` runs `$board->restore()` — a write — on a GET request. The shared `action-trashed` component reads the route verb and, because it is GET, submits a plain GET form with **no CSRF token**. The sibling `force-delete` route correctly uses DELETE. |
| **Consequence** | Any GET that hits `/global-master/board/{id}/restore` restores the board with no CSRF check; a link prefetcher, the browser back button, or an inline image on another site can silently un-trash a board. |
| **Reproduce** | Open `/global-master/board/trash/view`, click the restore icon, and note the request is `GET /global-master/board/{id}/restore` with no `_token`. |
| **Fix approach** | Change the route to `Route::delete('/board/{id}/restore', …)`. The shared `action-trashed` component already switches its form to DELETE with `@csrf`/`@method` when the route verb is not GET, so no component change is needed. ⚠ SHARED — edits the route file. |
| **Plan item** | BOA-08 in `02-fix-plan.md` §1 (marked ⚠ SHARED — route file) |

```php
// Modules/GlobalMaster/routes/web.php:131-134 — CURRENT
        Route::get('/board/trash/view', [BoardController::class, 'trashedBoard'])->name('board.trashed');
        Route::get('/board/{id}/restore', [BoardController::class, 'restore'])->name('board.restore');
        Route::delete('/board/{id}/force-delete', [BoardController::class, 'forceDelete'])->name('board.forceDelete');
        Route::post('/board/{board}/toggle-status', [BoardController::class, 'toggleStatus'])->name('board.toggleStatus');
```

**Evidence**
```
$ grep -n "board/{id}/restore" Modules/GlobalMaster/routes/web.php
132:        Route::get('/board/{id}/restore', [BoardController::class, 'restore'])->name('board.restore');
$ grep -n "restoreMethod === 'GET' ? 'GET' : 'POST'" resources/views/components/backend/table/action-trashed.blade.php
30:          method="{{ $restoreMethod === 'GET' ? 'GET' : 'POST' }}"
```

### F6 — Controller shape

#### BOA-09 · M · CTL-03 — four methods take `string $id` plus `findOrFail()` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Board $board)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:63-68` (`edit`), `:120-126` (`destroy`), `:155-161` (`restore`), `:180-186` (`forceDelete`) |
| **Root cause** | `show`, `update` and `toggleStatus` already type-hint `Board $board` and get the 404 for free. The four lifecycle methods use `string $id` plus `Board::findOrFail($id)` / `Board::withTrashed()->findOrFail($id)` instead. The route parameters are passed positionally by Laravel so it works, but it re-implements what binding gives free — and the `destroy` route parameter is `{board}` while `restore`/`forceDelete` use `{id}`, two names for the same resource. |
| **Consequence** | More code per method and an easy renaming trap; the 404 is raised only when `findOrFail` runs, not when the route is matched. |
| **Reproduce** | static only. |
| **Fix approach** | Convert `edit(Board $board)`, `destroy(Board $board)`, `restore(Board $board)` (with `->withTrashed()` binding) and `forceDelete(Board $board)`; align the custom route parameters to `{board}`. Applied by plan item BOA-09. |
| **Plan item** | BOA-09 in `02-fix-plan.md` §5 |

```php
// BoardController.php:63-68 — CURRENT (edit; destroy(string $id) at 120-126, restore($id) at 155-161, forceDelete($id) at 180-186)
    public function edit(string $id)
    {
        Gate::authorize('prime.global-master.board.update');
        $board = Board::findOrFail($id);

        return view('globalmaster::board.edit', compact('board'));
    }
```

**Evidence**
```
$ grep -nE 'public function (edit|destroy|restore|forceDelete)|findOrFail' Modules/GlobalMaster/app/Http/Controllers/BoardController.php
63:    public function edit(string $id)
66:        $board = Board::findOrFail($id);
120:    public function destroy(string $id)
126:                $board = Board::findOrFail($id);
155:    public function restore($id)
161:                $board = Board::withTrashed()->findOrFail($id);
180:    public function forceDelete($id)
186:                $board = Board::withTrashed()->findOrFail($id);
```

#### BOA-10 · L · CTL-04 — no return types on any of the 11 public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php` — all 11 methods (lines 17, 25, 32, 56, 63, 71, 120, 147, 155, 180, 205) |
| **Root cause** | No method declares a return type. |
| **Consequence** | PHP/static analysis cannot enforce the response contract; every response shape is implicit. |
| **Reproduce** | static only. |
| **Fix approach** | Add the matching return type to each method: `: \Illuminate\Contracts\View\View` for `index`/`create`/`show`/`edit`/`trashedBoard`, `: \Illuminate\Http\RedirectResponse` for `store`/`update`/`destroy`/`restore`/`forceDelete`, `: \Illuminate\Http\JsonResponse` for `toggleStatus`. Applied by plan item BOA-10. |
| **Plan item** | BOA-10 in `02-fix-plan.md` §8 |

```php
// BoardController.php:17 and :205 — CURRENT
    public function index()
```
```php
    public function toggleStatus(Request $request, Board $board)
```

**Evidence**
```
$ grep -cE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/GlobalMaster/app/Http/Controllers/BoardController.php
11
```

### F7 — Models

#### BOA-11 · M · MDL-04 / CTL-10 — `Board::organizations()` is a dead relation that throws on first use

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L — relationship resolves) raised to M under CTL-10 (dead code): the relation cannot resolve on the `Board` connection. |
| **Where** | `Modules/GlobalMaster/app/Models/Board.php:27-35` |
| **Root cause** | `Board` uses the `global_master_mysql` connection; `Organization` and the pivot table `sch_board_organization_jnt` live in the tenant `mysql` database. A `belongsToMany` runs its query on the parent connection, so it looks for `sch_organizations` in `global_master_mysql`, where neither it nor the pivot exists. `Modules/SchoolSetup/app/Models/Organization.php:102-132` documents this exact limitation and provides `getBoards()` as the two-step workaround. Nothing in the codebase reads `Board::organizations()` (the only reference is a `method_exists` assertion in `Modules/GlobalMaster/tests/Unit/ModelStructureTest.php:195`), so the relation is dead code that would 500 the moment it is used. |
| **Consequence** | No live screen breaks today, but any call to `$board->organizations` or `Board::with('organizations')` throws `SQLSTATE[42S02] Base table or view not found … sch_organizations`, and the call site must then fall back to the `Organization::getBoards()` two-step. |
| **Reproduce** | `php artisan tinker --execute '$b = Modules\GlobalMaster\Models\Board::with("organizations")->first();'` throws the 42S02 error. |
| **Fix approach** | Remove the `organizations()` relation (dead) and the now-unused `Organization` import, or replace it with a documented accessor that mirrors `Organization::getBoards()`. Applied by plan item BOA-11. |
| **Plan item** | BOA-11 in `02-fix-plan.md` §5 |

```php
// Board.php:26-36 — CURRENT
    //begin::Eloquent Relationship
    public function organizations()
    {
        return $this->belongsToMany(
            Organization::class,
            'sch_board_organization_jnt',
            'board_id',
            'organization_id'
        )->withPivot('academic_sessions_id'); // MANY TO MANY WITH EXTRA FILEDS
    }
    //end::Eloquent Relationship
```

**Evidence**
```
$ php artisan tinker --execute '$b = Modules\GlobalMaster\Models\Board::with("organizations")->first();'
SQLSTATE[42S02]: Base table or view not found: 1146 Table 'global_master.sch_organizations' doesn't exist
  (Connection: global_master_mysql, SQL: select `sch_organizations`.*, `sch_board_organization_jnt`.`board_id`
   as `pivot_board_id` ... from `sch_organizations` inner join `sch_board_organization_jnt` ...)
$ grep -rn ">organizations\|with('organizations')\|with(\['organizations'" Modules/ | grep -v tests
(no output — only Modules/GlobalMaster/tests/Unit/ModelStructureTest.php:195)
```

#### BOA-12 · L · STY-05 / STY-02 / STY-04 — `Board.php` carries a dead import, a commented-out import and fails Pint

| Field | Value |
|---|---|
| **Rule** | STY-05 (L — no unused imports), STY-02 (L — Pint-clean), STY-04 (L — no commented-out code) |
| **Where** | `Modules/GlobalMaster/app/Models/Board.php:5-9` |
| **Root cause** | `use Illuminate\Database\Eloquent\Factories\HasFactory;` is imported but the class never `use`s the trait, and `// use Modules\GlobalMaster\Database\Factories\BoardFactory;` is a commented-out import. Pint reports four fixers on the file. |
| **Consequence** | Consistency debt; the dead import misleads a reader into thinking the model is factory-backed. |
| **Reproduce** | `vendor/bin/pint --test Modules/GlobalMaster/app/Models/Board.php --format agent` fails. |
| **Fix approach** | Delete both import lines, add `declare(strict_types=1);` and separate class attributes with blank lines so Pint passes. Applied by plan item BOA-11 (same file). |
| **Plan item** | none — applied by plan item BOA-11 (see `02-fix-plan.md` §10) |

```php
// Board.php:5-9 — CURRENT
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Modules\SchoolSetup\Models\Organization;
// use Modules\GlobalMaster\Database\Factories\BoardFactory;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/GlobalMaster/app/Models/Board.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\/GlobalMaster\/app\/Models\/Board.php","fixers":["class_attributes_separation","single_line_comment_spacing","no_unused_imports","single_line_after_imports"]}]}
$ grep -n "HasFactory\|BoardFactory" Modules/GlobalMaster/app/Models/Board.php
6:use Illuminate\Database\Eloquent\Factories\HasFactory;
9:// use Modules\GlobalMaster\Database\Factories\BoardFactory;
```

### F8 — Services and jobs

clean — the controller uses no services, jobs, events, mail or notifications. `grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b' Modules/GlobalMaster/app/Http/Controllers/BoardController.php` prints only `BoardRequest`.

### F9 — Queries and performance

clean — both list methods paginate at 10 (`Board::paginate(10)` at `:20`, `Board::onlyTrashed()->paginate(10)` at `:150`); no `Model::all()`, no query inside a loop, no raw or interpolated SQL, no unbounded `->get()`. `grep -nE "::all\(\)|->get\(\)|DB::raw|whereRaw" Modules/GlobalMaster/app/Http/Controllers/BoardController.php` → no output. The `toggleStatus` write is a single `save()`, not a per-row loop.

### F10 — Views

#### BOA-13 · M · VIEW (modal-standard §2.5) — create/edit are full pages where the standard wants a modal

| Field | Value |
|---|---|
| **Rule** | VIEW / `modal-standard.md` §2.5 (M) — *a create page with 15 or fewer visible controls is converted to the shared modal; over 15, do not convert* |
| **Where** | `Modules/GlobalMaster/resources/views/board/create.blade.php:24-48` and `edit.blade.php:24-48`; `BoardController::create`/`edit` at `:25`/`:63` |
| **Root cause** | The board create form has 3 visible controls (name, short name, status switch) — well under the 15-control ceiling — yet it renders as a full page. The board list is reached from the Session & Board Setup tab, which uses modal-style add/edit affordances elsewhere. This is a module-wide pattern (shared with State/District/City/Country), so the fix is a conversion pass, not a one-controller edit. |
| **Consequence** | A user adding a board leaves the list and reloads a page instead of getting the standard in-place modal; the UI is inconsistent with the tab screen's own add affordance. |
| **Reproduce** | Open `/global-master/board/create` — a full page, not a modal. |
| **Fix approach** | Decide whether to convert this controller's create/edit to `<x-backend.tab.modal>` now or defer to the module's modal pass. |
| **Plan item** | BOA-13 in `02-fix-plan.md` §9 (DECISION) |

```php
// create.blade.php:24-25 — CURRENT (full-page form)
                        <form action="{{ route('central.global-master.board.store') }}" method="POST"
                            enctype="multipart/form-data">
```

**Evidence**
```
$ grep -c "x-backend.form.input-text\|x-backend.form.status-switch" Modules/GlobalMaster/resources/views/board/create.blade.php
3
$ grep -n "form action" Modules/GlobalMaster/resources/views/board/create.blade.php
24:                        <form action="{{ route('central.global-master.board.store') }}" method="POST"
```

#### BOA-14 · L · VIEW / STY-04 — copy-paste from the Country screens in the board blades

| Field | Value |
|---|---|
| **Rule** | STY-04 (L — copy-pasted code/comments that describe another resource) applied to views |
| **Where** | `Modules/GlobalMaster/resources/views/board/trash.blade.php:16`, `create.blade.php:36`, `edit.blade.php:38`, `show.blade.php:29-32`, `trash.blade.php:10` |
| **Root cause** | The trash table header still says **Country** while the column prints `$board->name`; both the create and edit short-name inputs carry the placeholder "Enter Country Short Name"; the add-form header and an ID row in `show.blade.php` are commented out. |
| **Consequence** | A user sees a "Country" column header on the Board trash screen, and the create/edit form advertises a country field; cosmetic but misleading on live screens. |
| **Reproduce** | Open `/global-master/board/trash/view` (header says Country) and `/global-master/board/create` (placeholder says Enter Country Short Name). |
| **Fix approach** | Change the trash header to `Name`; change both placeholders to "Enter Board Short Name". Applied by plan item BOA-14. |
| **Plan item** | BOA-14 in `02-fix-plan.md` §7 |

```php
// trash.blade.php:16 — CURRENT
                                    <th>Country</th>
```

**Evidence**
```
$ grep -n "Country\|Enter Country" Modules/GlobalMaster/resources/views/board/create.blade.php Modules/GlobalMaster/resources/views/board/edit.blade.php Modules/GlobalMaster/resources/views/board/trash.blade.php
create.blade.php:36:                                        placeholder="Enter Country Short Name" id="short_name" label="Short Name"
edit.blade.php:38:                                        placeholder="Enter Country Short Name" id="short_name" label="Short Name"
trash.blade.php:16:                                    <th>Country</th>
```

### F11 — Security and tenancy

clean — no `env()` outside `config/` (`grep -n "env("` on controller/model/request → no output); no hard-coded ids or `?? 1`; no request body/password logged; no personal data emitted. Permission names use the four-part `scope.module.feature.action` form and each is seeded (`global-master.board` in `config/permissionslist.php:251`, flattened to the seven `prime.global-master.board.*` keys — all verified present and assigned to roles). Central-only routes run against `global_master_mysql` with no tenant context; tenant rules are not applicable to a central master-data screen. Page lists paginate at 10.

### F12 — Style

#### BOA-15 · L · STY-01 — missing `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:1`, `Modules/GlobalMaster/app/Http/Requests/BoardRequest.php:1`, `Modules/GlobalMaster/app/Models/Board.php:1` |
| **Root cause** | All three owned PHP files open with `<?php` and no `declare(strict_types=1);`. |
| **Consequence** | Consistency debt; no runtime effect. |
| **Reproduce** | static only. |
| **Fix approach** | Insert `declare(strict_types=1);` after the opening tag in the controller and the FormRequest. The model's declaration is applied by plan item BOA-11. |
| **Plan item** | BOA-15 in `02-fix-plan.md` §8 |

```php
// BoardController.php:1-3 — CURRENT (same opening in BoardRequest.php; Board.php is covered by BOA-11)
<?php

namespace Modules\GlobalMaster\Http\Controllers;
```

**Evidence**
```
$ head -1 Modules/GlobalMaster/app/Http/Controllers/BoardController.php Modules/GlobalMaster/app/Models/Board.php Modules/GlobalMaster/app/Http/Requests/BoardRequest.php
==> Modules/GlobalMaster/app/Http/Controllers/BoardController.php <==
<?php
==> Modules/GlobalMaster/app/Models/Board.php <==
<?php
==> Modules/GlobalMaster/app/Http/Requests/BoardRequest.php <==
<?php
```

#### BOA-16 · L · STY-04 — `BoardRequest` comment names a permission prefix that does not exist

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no copy-pasted docblocks that describe another resource* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/BoardRequest.php:44-46` |
| **Root cause** | The `authorize()` comment names `prime.board.create` and `prime.board.update`, but the code checks `prime.global-master.board.create` / `.update` (via `authorizeByCrudPermission('prime.global-master.board')`). A reader who greps `prime.board.create` finds nothing. |
| **Consequence** | A reader distrusts the file; the comment points at a permission prefix that is not declared anywhere. |
| **Reproduce** | `grep -rn "prime.board.create" config/ Modules/` → no output. |
| **Fix approach** | Update the comment to the real permission names `prime.global-master.board.create` / `prime.global-master.board.update`. Applied by plan item BOA-16. |
| **Plan item** | BOA-16 in `02-fix-plan.md` §8 |

```php
// BoardRequest.php:44-46 — CURRENT
        // T6b — mirrors the controller's own gate: prime.board.create on POST,
        // prime.board.update on PUT/PATCH. Same permission, checked one step
        // earlier, so this narrows nothing and widens nothing.
```

**Evidence**
```
$ grep -n "prime.board" Modules/GlobalMaster/app/Http/Requests/BoardRequest.php
44:        // T6b — mirrors the controller's own gate: prime.board.create on POST,
45:        // prime.board.update on PUT/PATCH. Same permission, checked one step
$ grep -rn "prime.board.create" config/ Modules/ 2>/dev/null
(no output)
```

### F13 — Deep read (all eight questions, per mutating method)

| Method | 1 overwrite? | 2 delete before replace? | 3 duplicate impl? | 4 soft-delete×unique? | 5 race? | 6 auth hole? | 7 message lies? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok — new row, `$fillable` limits the columns | ok | ok | accepted — see below | ok — DB `UNIQUE` on `name`/`short_name` backs the rule | ok — create gate + request | ok | ok |
| `update` | ok — full validated row is the edit form's contract | ok | ok | accepted — see below | ok | ok — update gate + request | BOA-16 (stale comment) | ok |
| `destroy` | ok — sets `is_active=false` then soft-deletes in one transaction | ok | ok | ok | ok | ok — delete gate | ok — event `Trashed`, message says "deactivated and deleted" which is what happens | ok |
| `restore` | ok — un-deletes only; `is_active` stays false (sibling convention) | ok | ok | ok | ok | ok — restore gate | BOA-18 (informational) | ok |
| `forceDelete` | ok — permanent delete plus a fresh audit row | ok — the audit row is created fresh, not replacing data | ok | ok | ok | ok — forceDelete gate | ok | ok |
| `toggleStatus` | ok — only `is_active` from a boolean-validated input | ok | ok | ok | ok | ok — update gate | ok | ok |

Deep-read verdict: no wrong overwrite, no delete-before-replace, no race needing a lock and no auth hole. The soft-delete × uniqueness behaviour (question 4) is **accepted, not a defect**: the migration `2025_10_09_043158_create_boards_table.php:20-21` declares `UNIQUE` on `name` and `short_name`, the live `glb_boards` table has both unique indexes, and `BoardRequest`'s `Rule::unique('glb_boards')` checks all rows including trashed ones — rule and database agree, so there is no false rejection and no 500. The consequence (a trashed board's name cannot be reused until the row is force-deleted) is the intended meaning of that unique index.

#### BOA-17 · L · F13 (deep-read #2/#5) — `forceDelete` has no guard for linked organizations

| Field | Value |
|---|---|
| **Rule** | F13 deep-read (*is anything deleted before its replacement; is there a race; does a message lie*), backed by the DB: `sch_board_organization_jnt.board_id` is `FOREIGN KEY … ON DELETE RESTRICT`. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:186-189`, method `forceDelete()` |
| **Root cause** | `$board->forceDelete()` runs on any trashed board. The pivot `sch_board_organization_jnt` references `glb_boards.id` with `restrictOnDelete`, so a board that is linked to an organization cannot be hard-deleted. |
| **Consequence** | If a board is ever linked, the permanent-delete action throws a `QueryException` (today the generic catch returns "The operation could not be completed."; after BOA-01 it becomes a 500). Today `sch_board_organization_jnt` has 0 rows, so no board is linked and the action succeeds, but the screen gives no hint that linked boards must be unlinked first. |
| **Reproduce** | static only — the FK constraint is proven from the migration and the 0-row pivot; D4 forbids tests, so the live failure was not exercised. |
| **Fix approach** | Informational. If desired, block early with a clear message when the board has linked organizations. No plan item — see `02-fix-plan.md` §10. |
| **Plan item** | none — see `02-fix-plan.md` §10 (informational) |

```php
// BoardController.php:186-189 — CURRENT
                $board = Board::withTrashed()->findOrFail($id);
                $board->forceDelete();

                activityLog($board, 'Deleted', ['message' => 'A new board was permanently deleted.', 'other' => 'some other information']);
```

**Evidence**
```
$ grep -n "board_id" Modules/GlobalMaster/database/migrations/2025_10_18_085546_create_board_organization_table.php
19:            $table->unsignedInteger('board_id');
20:            $table->foreign('board_id')->references('id')->on($globalDb . '.glb_boards')->restrictOnDelete();
$ php artisan tinker --execute 'echo DB::connection("mysql")->table("sch_board_organization_jnt")->count();'
0
```

#### BOA-18 · L · F13 (deep-read #1/#7) — `destroy` deactivates then trashes; `restore` never re-activates

| Field | Value |
|---|---|
| **Rule** | F13 deep-read (*does a write overwrite data it should not; does a message lie*) |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/BoardController.php:127-131` (`destroy`) and `:161-164` (`restore`) |
| **Root cause** | `destroy` sets `is_active = false`, saves, then soft-deletes. `restore` only un-deletes; it does not set `is_active` back to true. So the deactivation half of delete is irreversible through the visible restore action. |
| **Consequence** | An operator trashes a board and later restores it; the board returns to the list still inactive, so they must remember to toggle the status switch again. The flash "board restored" is technically true but the row is not back to its previous state. This matches the `Country`/`City`/`State`/`District` sibling convention (their `destroy` also deactivates, their `restore` also leaves it off), so it is recorded as accepted behaviour. |
| **Reproduce** | static only — the two methods are at the lines above. |
| **Fix approach** | Informational. If the product wants restore to re-activate, set `$board->is_active = true; $board->save();` before `restore()`. No plan item — see `02-fix-plan.md` §10. |
| **Plan item** | none — see `02-fix-plan.md` §10 (informational) |

```php
// BoardController.php:127-131 — CURRENT
                $board->is_active = false;
                $board->save();
                $board->delete();

                activityLog($board, 'Trashed', ['message' => 'A new board was deactivated and deleted.', 'other' => 'some other information']);
```

**Evidence**
```
$ grep -n "is_active = false\|->restore()" Modules/GlobalMaster/app/Http/Controllers/BoardController.php
127:                $board->is_active = false;
162:                $board->restore();
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/GlobalMaster/routes/web.php` | The `restore` route is a GET (BOA-08). The file is shared by all GlobalMaster controllers; the fix is a ⚠ SHARED plan item, not a controller edit. | RTE-01 | Route-file owner — ⚠ SHARED (BOA-08) |
| `resources/views/components/backend/table/action-trashed.blade.php` + `app/View/Components/Backend/Table/ActionTrashed.php` | Reads the route verb and renders a `GET` form with no CSRF because the `restore` route is GET. It correctly switches to DELETE with `@csrf`/`@method` once the route verb changes, so no component change is needed (unlike the PrimeCore copy used by City). | — | Component owner (no change needed for BOA-08) |
| `Modules/SchoolSetup/app/Models/Organization.php` | Already documents the cross-database limitation (`:102-132`) and offers `getBoards()`. `Board::organizations()` should be removed or re-implemented the same way (BOA-11). | MDL-04 | Board-owner report (this report) for Board; Organization is owned by `OrganizationController` |
| `config/permissionslist.php` (`global-master.board`) | Key exists with all seven `$crud` actions and is seeded; no defect. Noted so the fixer does not add a new key. | — | — |
| Sibling controllers `CountryController`, `CityController`, `StateController`, `DistrictController` | Same six-block try/catch, same `getMessage()` logging, same GET `restore`, same `findOrFail($id)` — the whole geography family carries BOA-01/03/08/09. | ERR-00, ERR-05, RTE-01, CTL-03 | Their own reports — module-level cross-controller family |

## 8. Not covered, and why

- **No write or failure path was executed.** D4 forbids tests; the `forceDelete` FK rejection (BOA-17), the `toggleStatus` rollback (BOA-02/BOA-04) and the broken relation (BOA-11) were proven from the schema, a `tinker` SELECT/read and the code, not by running the screen.
- **No Blade was rendered in a browser.** View checks were static (`grep`) and by reading the templates; the shared layout and components are common classes, not audited here.
- **The `activityLog()` sink** (`Modules/Prime/Models/ActivityLog` in central context), `AuthorizesTenantFeature` and `flash()` are common classes; only the arguments passed from this controller were checked.
- **`Board::organizations()`** could not be exercised beyond the failing query shown in BOA-11; its intended data shape was read from `Organization::getBoards()`.
- **The permission deny path** was not exercised in a browser; the gates are standard `Gate::authorize` calls and the renderer is common.
