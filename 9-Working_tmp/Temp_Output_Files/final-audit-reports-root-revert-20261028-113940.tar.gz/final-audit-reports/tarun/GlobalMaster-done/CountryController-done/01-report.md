# Final Audit — GlobalMaster / CountryController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/CountryController.php` (303 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/global-master/country` (list), `/create`, `/{country}/edit`, `/{country}` (show), `/global-master/country/trash/view` (trash). A second copy answers on `http://test.localhost:8000/prime/country...` (route group `central.prime.country.*`). |
| Menu path | System Config → Location Setup → Country tab (the live tab screen is `cg-global-master.location-setup.index#country`, rendered by `Modules/GlobalMaster/resources/views/location-management/index.blade.php`). The standalone `country.index` page is reached only by the routes here. |
| Who uses it | Super Admin and any role holding `prime.global-master.country.*` (central db, `prime` scope). Seeded centrally by `Modules/Prime/database/seeders/RolePermissionSeeder`. |
| What a user does here | Add a country (name, short name, global code, currency code, active flag), edit it, view it, move it to trash, restore it, or permanently delete it. The status switch on the list also cascades the active/inactive flag down to every state and district of that country. |
| Tables written | `glb_countries` (create/update/soft-delete/restore/force-delete), `glb_states` and `glb_districts` (cascade in `toggleStatus`), plus one central `activity_logs` row per mutation through the `activityLog()` helper. |
| Tables read | `glb_countries` (all list/show/edit), `glb_states` and `glb_districts` (cascade in `toggleStatus`). |
| Live data | On `global_master_mysql`: `glb_countries` 1 row (0 trashed), `glb_states` 36, `glb_districts` 785, `glb_cities` 1592. The single country "India" (id 1) owns all 36 states. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller does the core CRUD correctly and every method authorizes before it loads data, but it is **not production-ready as written**: it wraps all five mutating methods and `toggleStatus` in hand-written `try/catch` blocks, which protocol decision **D1** forbids — the Laravel idiom is `DB::transaction()` plus the central handler. The single worst finding is the `toggleStatus` cascade: it commits a country/state/district status change through a manual `beginTransaction`/`commit`, and its `catch` reports the **new** status back to the browser even after the rollback, so a failed toggle can show the switch as changed when nothing persisted. The fixes are mechanical and small (roughly S–M): delete the `try/catch` blocks, move the redirects out of the transaction closures, convert the manual transaction to a closure, restore the missing `is_active` cast, fix one GET-that-mutates route, and clean up four dead imports (two of them point at classes that do not exist).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 5 | 6 | 2 | 13 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CNTRY-01 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | CNTRY-02, CNTRY-03 | F9 Queries/Perf | clean |
| F3 Authorization | CNTRY-04 | F10 Views | CNTRY-09 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | CNTRY-05 | F12 Style | CNTRY-10, CNTRY-11, CNTRY-12 |
| F6 Controller shape | CNTRY-06 | F13 Deep read | CNTRY-13 |
| F7 Models | CNTRY-07, CNTRY-08 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/CountryController.php` | controller | 303 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Models/Country.php` | model | 31 | this report | ✅ |
| 3 | `Modules/GlobalMaster/app/Http/Requests/CountryRequest.php` | FormRequest | 65 | this report | ✅ |
| 4 | `Modules/GlobalMaster/resources/views/country/index.blade.php` | blade | 66 | this report | ✅ |
| 5 | `Modules/GlobalMaster/resources/views/country/create.blade.php` | blade | 66 | this report | ✅ |
| 6 | `Modules/GlobalMaster/resources/views/country/edit.blade.php` | blade | 69 | this report | ✅ |
| 7 | `Modules/GlobalMaster/resources/views/country/show.blade.php` | blade | 66 | this report | ✅ |
| 8 | `Modules/GlobalMaster/resources/views/country/trash.blade.php` | blade | 57 | this report | ✅ |
| 9 | `Modules/GlobalMaster/app/Models/State.php` | model | 41 | ↗ [tarun/GlobalMaster-done/StateController](../StateController-done/01-report.md) — audited by the State/District batch | ↗ linked (usage only) |
| 10 | `Modules/GlobalMaster/app/Models/District.php` | model | 39 | ↗ [tarun/GlobalMaster-done/DistrictController](../DistrictController-done/01-report.md) — audited by the State/District batch | ↗ linked (usage only) |
| 11 | `App\Models\V1\GlobalMaster\State` and `App\Models\V1\GlobalMaster\District` | phantom imports | 0 | does not exist | ❌ no such class on disk (`app/Models/V1` is absent) |
| 12 | `app/Models/BaseModel.php` | common base | 22 | common | ❌ common |
| 13 | `app/Traits/AuthorizesTenantFeature.php` | common trait | 62 | common | ❌ common |
| 14 | `app/Helpers/activityLog.php` → `Modules/Prime/Models/ActivityLog` | common helper/sink | 51 | common | ❌ common |
| 15 | `resources/views/components/backend/table/{action,action-trashed,status-switch}.blade.php`, `resources/views/components/backend/partials/footer-scripts.blade.php` | shared components | — | common | ❌ common (usage checked) |

Classes claimed in `_Info/00-CLASS-OWNERS.md` by this report: `Modules/GlobalMaster/app/Models/Country.php`, `Modules/GlobalMaster/app/Http/Requests/CountryRequest.php`. `State.php` / `District.php` are owned by the State/District batch and are used here only for the `toggleStatus` cascade (usage check, not ownership).

No pre-applied files.

## 4. Routes

```
GET|HEAD  global-master/country                     central.global-master.country.index          CountryController@index
POST      global-master/country                     central.global-master.country.store          CountryController@store
GET|HEAD  global-master/country/create              central.global-master.country.create         CountryController@create
GET|HEAD  global-master/country/trash/view          central.global-master.country.trashed        CountryController@trashedCountry
GET|HEAD  global-master/country/{country}           central.global-master.country.show           CountryController@show
PUT|PATCH global-master/country/{country}           central.global-master.country.update         CountryController@update
DELETE    global-master/country/{country}           central.global-master.country.destroy        CountryController@destroy
GET|HEAD  global-master/country/{country}/edit      central.global-master.country.edit           CountryController@edit
POST      global-master/country/{country}/toggle-status central.global-master.country.toggleStatus CountryController@toggleStatus
DELETE    global-master/country/{id}/force-delete   central.global-master.country.forceDelete    CountryController@forceDelete
GET|HEAD  global-master/country/{id}/restore        central.global-master.country.restore        CountryController@restore
GET|HEAD  prime/country                             central.prime.country.index                  CountryController@index
POST      prime/country                             central.prime.country.store                  CountryController@store
GET|HEAD  prime/country/create                      central.prime.country.create                 CountryController@create
GET|HEAD  prime/country/trash/view                  central.prime.country.trashed                CountryController@trashedCountry
GET|HEAD  prime/country/{country}                   central.prime.country.show                   CountryController@show
PUT|PATCH prime/country/{country}                   central.prime.country.update                 CountryController@update
DELETE    prime/country/{country}                   central.prime.country.destroy                CountryController@destroy
GET|HEAD  prime/country/{country}/edit              central.prime.country.edit                   CountryController@edit
POST      prime/country/{country}/toggle-status     central.prime.country.toggleStatus           CountryController@toggleStatus
DELETE    prime/country/{id}/force-delete           central.prime.country.forceDelete            CountryController@forceDelete
GET|HEAD  prime/country/{id}/restore                central.prime.country.restore                CountryController@restore
```

Unrouted public methods: none — all 11 public methods are routed.

Route file: `Modules/GlobalMaster/routes/web.php` lines 39-45 (`prime` group) and 149-155 (`global-master` group). Both groups sit inside `Route::domain(config('app.domain'))` with `auth` and `verified`. Custom routes are registered **after** `Route::resource` (lines 40-44 / 150-154); the resource's `country/{country}` does not capture them because `/country/trash/view` has three segments and `/country/{id}/restore`, `/country/{id}/force-delete`, `/country/{country}/toggle-status` all carry a distinguishing literal segment — confirmed by the route list above (RTE-06 clean).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 22 | GET global-master/country (+ prime/country) | `prime.global-master.country.viewAny` | none (read) | — | reads glb_countries | CNTRY-06 |
| `create` | 33 | GET global-master/country/create | `prime.global-master.country.create` | none | — | — | CNTRY-06, CNTRY-09 |
| `store` | 43 | POST global-master/country | `prime.global-master.country.create` (+ FormRequest) | controller `DB::transaction` | `Stored` | glb_countries, activity_logs | CNTRY-01, CNTRY-03, CNTRY-04, CNTRY-06 |
| `show` | 74 | GET global-master/country/{country} | `prime.global-master.country.view` | none | — | reads glb_countries | CNTRY-06 |
| `edit` | 84 | GET global-master/country/{country}/edit | `prime.global-master.country.update` | none | — | reads glb_countries | CNTRY-06, CNTRY-09 |
| `update` | 94 | PUT/PATCH global-master/country/{country} | `prime.global-master.country.update` (+ FormRequest) | controller `DB::transaction` | `Updated` | glb_countries, activity_logs | CNTRY-01, CNTRY-03, CNTRY-04, CNTRY-06 |
| `destroy` | 150 | DELETE global-master/country/{country} | `prime.global-master.country.delete` | controller `DB::transaction` | `Trashed` | glb_countries, activity_logs | CNTRY-01, CNTRY-03, CNTRY-06 |
| `trashedCountry` | 182 | GET global-master/country/trash/view | `prime.global-master.country.restore` | none (read) | — | reads glb_countries | CNTRY-06 |
| `restore` | 190 | GET global-master/country/{id}/restore | `prime.global-master.country.restore` | controller `DB::transaction` | `Restored` | glb_countries, activity_logs | CNTRY-01, CNTRY-03, CNTRY-05, CNTRY-06 |
| `forceDelete` | 218 | DELETE global-master/country/{id}/force-delete | `prime.global-master.country.forceDelete` | controller `DB::transaction` | `Deleted` | glb_countries, activity_logs | CNTRY-01, CNTRY-03, CNTRY-06, CNTRY-13 |
| `toggleStatus` | 249 | POST global-master/country/{country}/toggle-status | `prime.global-master.country.update` | controller manual `beginTransaction`/`commit` | `Toggled` | glb_countries, glb_states, glb_districts, activity_logs | CNTRY-02, CNTRY-06 |

## 6. Findings

### F1 — Errors

#### CNTRY-01 · H · ERR-00 — the five CRUD/trash methods wrap their writes in a controller try/catch (D1)

| Field | Value |
|---|---|
| **Rule** | ERR-00 (H) — *no `try`/`catch` in controllers; `DB::transaction()` rolls back by itself and the central handler in `bootstrap/app.php` renders the error* (protocol D1). The same blocks also break ERR-05 (M) — *log the exception, not the message*. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:47-68`, method `store()`; identical shape at `:98-144` `update()`, `:154-177` `destroy()`, `:194-215` `restore()`, `:222-243` `forceDelete()` |
| **Root cause** | Each mutating method wraps its `DB::transaction(...)` in `try { … } catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { Log::error(…, ['error' => $e->getMessage()]); return back()->with('error', …); }`. Under D1 a controller keeps no `try` at all. The `catch (ModelNotFoundException)` is unreachable in `store`/`update`/`destroy` (no `findOrFail` runs there — the bound `Country` already exists). The generic catch turns a genuine 500 into a red flash and logs only the message, losing the stack trace that the central handler would have written. |
| **Consequence** | On a real write failure the user gets the vague "The operation could not be completed." instead of the framework's error page, and no trace reaches the log to diagnose it. |
| **Reproduce** | static only — exercising the failure branch needs a DB write that throws and D4 forbids tests. The shape is visible at the five line ranges above. |
| **Fix approach** | Delete the outer `try`/`catch` in all five methods; keep `DB::transaction(...)` and build the redirect after the closure returns (this also clears CNTRY-03). Delete the now-unused `Log` and `ModelNotFoundException` imports. |
| **Plan item** | CNTRY-01 in `02-fix-plan.md` §1 |

```php
// CountryController.php:47-68 — CURRENT (store; identical shape in update/destroy/restore/forceDelete)
        try {
            return DB::transaction(function () use ($request) {
                $country = Country::create($request->validated());

                activityLog($country, 'Stored', ['message' => 'A new country was created.', 'other' => 'some other information']);

                return redirect()->to(route('central.global-master.location-setup.index').'#country')
                    ->with('success', flash('created.country'));

            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('CountryController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "catch (" Modules/GlobalMaster/app/Http/Controllers/CountryController.php
60:        } catch (ModelNotFoundException $e) {
64:        } catch (\Throwable $e) {
136:        } catch (ModelNotFoundException $e) {
140:        } catch (\Throwable $e) {
169:        } catch (ModelNotFoundException $e) {
173:        } catch (\Throwable $e) {
207:        } catch (ModelNotFoundException $e) {
211:        } catch (\Throwable $e) {
235:        } catch (ModelNotFoundException $e) {
239:        } catch (\Throwable $e) {
290:        } catch (\Throwable $e) {
$ grep -n "getMessage" Modules/GlobalMaster/app/Http/Controllers/CountryController.php
65:            Log::error('CountryController::store failed', ['error' => $e->getMessage()]);
141:            Log::error('CountryController::update failed', ['error' => $e->getMessage()]);
174:            Log::error('CountryController::destroy failed', ['error' => $e->getMessage()]);
212:            Log::error('CountryController::restore failed', ['error' => $e->getMessage()]);
240:            Log::error('CountryController::forceDelete failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### CNTRY-02 · M · TXN-02 — `toggleStatus` uses a manual begin/commit/rollback instead of `DB::transaction`

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`; never return between begin and commit.* Also touches ERR-00 (D1) — no controller `try`/`catch`. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:256-300`, method `toggleStatus()` |
| **Root cause** | The method opens `DB::beginTransaction()` by hand, does four writes (country, states, districts, activity log) and commits; a `catch (\Throwable)` rolls back. This is the exact shape TXN-02 forbids: the closure form cannot leak an open transaction on an early return, and D1 removes the catch entirely. The catch also returns `'is_active' => $country->is_active` — the in-memory model still holds the newly assigned value after `DB::rollBack()`, so a failed toggle reports the status it did **not** persist. |
| **Consequence** | If the state/district cascade throws, the browser is told the switch is now on (`is_active` = new value, `success` = false) while the database rolled back to off; the screen and the database disagree until reload. |
| **Reproduce** | static only — the rollback path needs a failing cascade; D4 forbids tests. |
| **Fix approach** | Replace the manual transaction and catch with one `DB::transaction(function () use ($request, $country) { … })`, keep the `Toggled` activity-log call inside and after the writes, and build the JSON response after the closure. The shared footer script (`resources/views/components/backend/partials/footer-scripts.blade.php:170-232`) already has an AJAX `error` handler, so the central handler's failure response is handled. |
| **Plan item** | CNTRY-02 in `02-fix-plan.md` §3 |

```php
// CountryController.php:256-300 — CURRENT (toggleStatus)
        DB::beginTransaction();

        try {
            // Change the Country status.
            $country->is_active = $request->input('is_active');
            $country->save();
            $status = $country->is_active;
            \Modules\GlobalMaster\Models\State::where('country_id', $country->id)->update([
                'is_active' => $status,
            ]);
            $stateId = \Modules\GlobalMaster\Models\State::where('country_id', $country->id)->pluck('id');

            \Modules\GlobalMaster\Models\District::whereIn('state_id', $stateId)->update([
                'is_active' => $status,
            ]);
            activityLog($country, 'Toggled', ['message' => 'A new country status was updated.', 'other' => 'some other information']);

            DB::commit();

            return response()->json([
                'success' => true,
                'is_active' => $country->is_active,
                'message' => flash('status_updated.country'),
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'is_active' => $country->is_active,
                'message' => flash('status_switch_failed.country'),
            ]);
        }
```

**Evidence**
```
$ grep -n "beginTransaction\|DB::commit\|rollBack" Modules/GlobalMaster/app/Http/Controllers/CountryController.php
256:        DB::beginTransaction();
283:            DB::commit();
293:            DB::rollBack();
```

#### CNTRY-03 · M · TXN-05 — HTTP responses are built inside the `DB::transaction` closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()`/`response()` after it.* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:56-57` (`store`), `:132-133` (`update`), `:165-166` (`destroy`), `:204` (`restore`), `:232` (`forceDelete`) |
| **Root cause** | Each closure ends with `return redirect()…`, so the flash and URL are constructed inside the atomic block. TXN-05 wants the closure to return the model/count and the response built afterwards. |
| **Consequence** | No user-visible break today (the closure returns the response object and the method returns it), but it couples response construction to the transaction and is the reason the `try`/`catch` around it (CNTRY-01) looks necessary. |
| **Reproduce** | static only — shape-only finding. |
| **Fix approach** | Covered by the CNTRY-01 rewrite: the closure returns nothing, and the redirect is built after `DB::transaction(...)`. |
| **Plan item** | none — resolved by plan item CNTRY-01 (see §10) |

```php
// CountryController.php:56-57 — CURRENT (store; same pattern in the other four)
                return redirect()->to(route('central.global-master.location-setup.index').'#country')
                    ->with('success', flash('created.country'));
```

**Evidence**
```
$ grep -n "return redirect\|return response" Modules/GlobalMaster/app/Http/Controllers/CountryController.php
56:                return redirect()->to(route('central.global-master.location-setup.index').'#country')
132:                return redirect()->to(route('central.global-master.location-setup.index').'#country')
165:                return redirect()->to(route('central.global-master.location-setup.index').'#country')
204:                return redirect()->route('central.global-master.country.trashed')->with('success', flash('restored.country'));
232:                return redirect()->route('central.global-master.country.trashed')->with('success', flash('force_deleted.country'));
```

### F3 — Authorization

#### CNTRY-04 · L · AUTH-04 — `store`/`update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (FormRequest `authorize()` + `Gate::authorize`); keep one.* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:45` and `:96`; `Modules/GlobalMaster/app/Http/Requests/CountryRequest.php:50-56` |
| **Root cause** | `CountryRequest::authorize()` calls `authorizeByCrudPermission('prime.global-master.country')` (mapping the verb to `.create`/`.update`), and the controller then calls `Gate::authorize('prime.global-master.country.create')` / `.update` again. Both resolve to the same keys. |
| **Consequence** | No security gap — the check is redundant, so it costs one extra Gate lookup and creates a second place to keep in sync. |
| **Reproduce** | static only — both checks pass or fail together. Permission keys verified present in `config/permissionslist.php:213` (`global-master.country`) with the seven `$crud` actions. |
| **Fix approach** | Keep the FormRequest `authorize()` and drop the controller `Gate::authorize` in `store` and `update` (or vice-versa); one owner per concern. |
| **Plan item** | CNTRY-04 in `02-fix-plan.md` §4 |

```php
// CountryController.php:45 (store) and :96 (update)
        Gate::authorize('prime.global-master.country.create');
```
```php
// CountryRequest.php:55
        return $this->authorizeByCrudPermission('prime.global-master.country');
```

**Evidence**
```
$ grep -n "authorizeByCrudPermission\|Gate::authorize" Modules/GlobalMaster/app/Http/Requests/CountryRequest.php Modules/GlobalMaster/app/Http/Controllers/CountryController.php
Modules/GlobalMaster/app/Http/Requests/CountryRequest.php:55:        return $this->authorizeByCrudPermission('prime.global-master.country');
Modules/GlobalMaster/app/Http/Controllers/CountryController.php:45:        Gate::authorize('prime.global-master.country.create');
Modules/GlobalMaster/app/Http/Controllers/CountryController.php:96:        Gate::authorize('prime.global-master.country.update');
```

### F4 — Validation and input

clean — `store`/`update` use `CountryRequest` and `$request->validated()` (no `$request->all()`); `toggleStatus` uses `$request->validate(['is_active' => 'required|boolean'])`, the allowed one-field AJAX toggle. `grep -nE "request->all\(|->except\(" Modules/GlobalMaster/app/Http/Controllers/CountryController.php` → no output. Uniqueness rules mirror the real live indexes: `SHOW INDEX FROM glb_countries` returns exactly `name` and `short_name` unique, both covered by `Rule::unique('glb_countries')` in `CountryRequest.php:25,31`. (The nullable `global_code` has no unique rule; the live DB has no unique index on it either — see §7.)

### F5 — Routes

#### CNTRY-05 · H · RTE-01 — the `restore` route changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (restore, delete, toggle, publish, approve, sync, generate); GET has no CSRF protection and link prefetchers trigger it.* |
| **Where** | `Modules/GlobalMaster/routes/web.php:42` and `:152`; handled by `CountryController.php:190-216` `restore()`; the trash view calls it through `resources/views/components/backend/table/action-trashed.blade.php:29-44` |
| **Root cause** | `Route::get('/country/{id}/restore', [CountryController::class, 'restore'])` runs `$country->restore()` — a write — on a GET request. The shared `action-trashed` component reads the route verb and submits a plain `GET` form with **no CSRF token** for this route (line 30), because GET is treated as safe. |
| **Consequence** | Any GET that hits `/global-master/country/{id}/restore` restores the country with no CSRF check; a link prefetcher, the browser back button, or an inline image on another site can silently un-trash a country. It is also the only restore route in this group that is a GET — `force-delete` correctly uses DELETE. |
| **Reproduce** | Open `/global-master/country/trash/view`, click the restore icon, and note the request is `GET /global-master/country/1/restore` (no `_token`, no confirm beyond the JS dialog). |
| **Fix approach** | Change both `restore` routes to `DELETE` (matching `force-delete`); the `action-trashed` component already switches its form to `DELETE` with `@csrf`/`@method` when the route verb is not GET, so no component change is needed. |
| **Plan item** | CNTRY-05 in `02-fix-plan.md` §1 (marked SHARED — route file) |

```php
// Modules/GlobalMaster/routes/web.php:42 (and identically :152)
        Route::get('/country/{id}/restore', [CountryController::class, 'restore'])->name('country.restore');
```

**Evidence**
```
$ grep -n "country/{id}/restore" Modules/GlobalMaster/routes/web.php
42:        Route::get('/country/{id}/restore', [CountryController::class, 'restore'])->name('country.restore');
152:        Route::get('/country/{id}/restore', [CountryController::class, 'restore'])->name('country.restore');
$ grep -n "restoreMethod === 'GET' ? 'GET' : 'POST'" resources/views/components/backend/table/action-trashed.blade.php
30:          method="{{ $restoreMethod === 'GET' ? 'GET' : 'POST' }}"
```

### F6 — Controller shape

#### CNTRY-06 · L · CTL-04 — public methods have no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`).* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:22,33,43,74,84,94,150,182,190,218,249` (all 11 public methods) |
| **Root cause** | None of the methods declares a return type. |
| **Consequence** | A caller (and static analysis) cannot tell a redirect method from a view method; a wrong return becomes a runtime surprise instead of a compile-time signal. |
| **Reproduce** | static only. |
| **Fix approach** | Add the matching return type to each method: `: View` for `index`/`create`/`show`/`edit`/`trashedCountry`, `: RedirectResponse` for `store`/`update`/`destroy`/`restore`/`forceDelete`, `: JsonResponse` for `toggleStatus`. |
| **Plan item** | CNTRY-06 in `02-fix-plan.md` §5 |

```php
// CountryController.php:22 and :249
    public function index()
```
```php
    public function toggleStatus(Request $request, Country $country)
```

**Evidence**
```
$ grep -cE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/GlobalMaster/app/Http/Controllers/CountryController.php
11
```

### F7 — Models

#### CNTRY-07 · M · MDL-02 — `Country` has no cast for `is_active`

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` for every boolean, date/datetime, decimal, json/array and enum column.* |
| **Where** | `Modules/GlobalMaster/app/Models/Country.php:9-22` |
| **Root cause** | `glb_countries.is_active` is `tinyint(1)`, but the model has no `$casts` at all, so `$country->is_active` is returned as `0`/`1` (or a string) rather than a boolean. Its sibling models `State.php:25-27` and `District.php:22-24` both cast `is_active => boolean`. |
| **Consequence** | `@if ($country->is_active)` in `show.blade.php:52` works by truthiness, but strict comparisons and JSON responses (`'is_active' => $country->is_active` in `toggleStatus`) emit `0`/`1` instead of `false`/`true`, which differs from how the shared status switch reads the sibling models. |
| **Reproduce** | static only; compare the three models' `$casts` blocks. |
| **Fix approach** | Add `protected $casts = ['is_active' => 'boolean'];` to `Country`, matching `State` and `District`. |
| **Plan item** | CNTRY-07 in `02-fix-plan.md` §5 |

```php
// Country.php:9-22 — CURRENT
class Country extends BaseModel
{
    use SoftDeletes;

    protected $connection = 'global_master_mysql';

    protected $table = 'glb_countries';
    protected $fillable = [
        'name',
        'short_name',
        'global_code',
        'currency_code',
        'is_active',
    ];
```

**Evidence**
```
$ grep -n "casts" Modules/GlobalMaster/app/Models/Country.php Modules/GlobalMaster/app/Models/State.php Modules/GlobalMaster/app/Models/District.php
Modules/GlobalMaster/app/Models/State.php:25:    protected $casts = [
Modules/GlobalMaster/app/Models/District.php:22:    protected $casts = [
(Country.php: no match)
```

#### CNTRY-08 · L · MDL-04 — `states()` relationship has no return type

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`…).* |
| **Where** | `Modules/GlobalMaster/app/Models/Country.php:25-28` |
| **Root cause** | `public function states()` returns `$this->hasMany(State::class)` without a `: HasMany` return type. The sibling `State::country()` and `District::cities()` are the same. |
| **Consequence** | Style/consistency only; no runtime effect. |
| **Reproduce** | static only. |
| **Fix approach** | Declare `: HasMany` and import `Illuminate\Database\Eloquent\Relations\HasMany`. |
| **Plan item** | CNTRY-08 in `02-fix-plan.md` §5 |

```php
// Country.php:25-28 — CURRENT
    public function states()
    {
        return $this->hasMany(State::class);
    }
```

**Evidence**
```
$ grep -n "public function states" Modules/GlobalMaster/app/Models/Country.php
25:    public function states()
```

### F8 — Services and jobs

clean — the controller has no constructor injection, service, job, listener, event, mail or notification. `grep -nE "Service|Job|Event|Mail|Notification" Modules/GlobalMaster/app/Http/Controllers/CountryController.php` → no output.

### F9 — Queries and performance

clean — both list methods paginate at 10 (`Country::orderBy('is_active','desc')->paginate(10)` at `:25`, `Country::onlyTrashed()->paginate(10)` at `:185`); no `Model::all()`, no query inside a loop, no raw/interpolated SQL. `grep -nE "::all\(\)|->get\(\)|DB::raw|whereRaw" Modules/GlobalMaster/app/Http/Controllers/CountryController.php` → no output. The `toggleStatus` cascade is two bounded statements (one `update`, one `pluck`), not a per-row loop.

### F10 — Views

#### CNTRY-09 · M · VIEW (modal-standard §2.5) — create/edit are dedicated pages where the standard wants a modal

| Field | Value |
|---|---|
| **Rule** | VIEW / `modal-standard.md` §2.5 (M) — *a create page with 15 or fewer visible controls is converted to the shared modal; over 15, do not convert.* |
| **Where** | `Modules/GlobalMaster/resources/views/country/create.blade.php:24-56` and `edit.blade.php:24-59`; `CountryController::create`/`edit` at `:33-38`/`:84-89` |
| **Root cause** | The country create form has 5 visible controls (name, short name, global code, currency code, status switch) — under the 15-control ceiling — yet it renders as a full page. The list screen's tab already expects a modal-style add/edit via `x-backend.tab.search-bar`. This is a module-wide pattern (shared with State/District/City), so the fix is a conversion pass, not a one-controller edit. |
| **Consequence** | A user adding a country leaves the list and reloads a page instead of getting the standard in-place modal; the UI is inconsistent with the tab screen's own "add" affordance. |
| **Reproduce** | Open `/global-master/country/create` — a full page, not a modal. |
| **Fix approach** | Decide whether to convert this controller's create/edit to `<x-backend.tab.modal>` now or defer to the module's modal pass. |
| **Plan item** | CNTRY-09 in `02-fix-plan.md` §9 (DECISION) |

```php
// create.blade.php:24-25 — CURRENT (full-page form)
                        <form action="{{ route('central.global-master.country.store') }}" method="POST"
                            enctype="multipart/form-data">
```

**Evidence**
```
$ grep -c "x-backend.form.input-text\|x-backend.form.status-switch" Modules/GlobalMaster/resources/views/country/create.blade.php
5
$ grep -n "form action" Modules/GlobalMaster/resources/views/country/create.blade.php
24:                        <form action="{{ route('central.global-master.country.store') }}" method="POST"
```

### F11 — Security and tenancy

clean — no `env()` outside config, no hard-coded ids or `?? 1`, no request body/password logged, no personal data emitted. Permission names use the four-part `scope.module.feature.action` form and every one is seeded (`global-master.country` in `config/permissionslist.php:213`, flattened to the seven `prime.global-master.country.*` keys — all verified present). Central-only routes correctly run against the `global_master_mysql` connection with no tenant context. `grep -nE "env\(|getMessage\(\)|->all\(\)" Modules/GlobalMaster/app/Http/Controllers/CountryController.php` → only the five `getMessage()` log lines already filed as CNTRY-01.

### F12 — Style

#### CNTRY-10 · L · STY-01 — missing `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files (new files mandatory; old files when touched).* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:1`, `Modules/GlobalMaster/app/Http/Requests/CountryRequest.php:1`, `Modules/GlobalMaster/app/Models/Country.php:1` |
| **Root cause** | All three owned PHP files open with `<?php` and no `declare(strict_types=1);`. |
| **Consequence** | Style/consistency only; no runtime effect. |
| **Reproduce** | static only. |
| **Fix approach** | Insert `declare(strict_types=1);` after the opening tag in each of the three files. |
| **Plan item** | CNTRY-10 in `02-fix-plan.md` §8 |

```php
// CountryController.php:1-3 (same opening in Country.php and CountryRequest.php)
<?php

namespace Modules\GlobalMaster\Http\Controllers;
```

**Evidence**
```
$ head -2 Modules/GlobalMaster/app/Http/Controllers/CountryController.php
<?php

```

#### CNTRY-11 · L · STY-05 — two dead imports point at classes that do not exist

| Field | Value |
|---|---|
| **Rule** | STY-05 (L) — *one import per class; no unused imports.* Dead code under CTL-10. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:6-7` |
| **Root cause** | The file imports `App\Models\V1\GlobalMaster\District` and `App\Models\V1\GlobalMaster\State`, but `app/Models/V1` does not exist (`grep -rl "App\\Models\\V1\\GlobalMaster" app` → no match; `class_exists` returns false). The real cascade uses fully-qualified `\Modules\GlobalMaster\Models\State` / `District` at `:265,268,271`, so the imports are unused and name non-existent classes. |
| **Consequence** | Today harmless, but any future unqualified `State::` or `District::` in this namespace resolves to a non-existent class and fatals; a reader is misled about which model the cascade touches. |
| **Reproduce** | static only. |
| **Fix approach** | Delete both `use` lines. |
| **Plan item** | CNTRY-11 in `02-fix-plan.md` §8 |

```php
// CountryController.php:5-8 — CURRENT
use App\Http\Controllers\Controller;
use App\Models\V1\GlobalMaster\District;
use App\Models\V1\GlobalMaster\State;
use Illuminate\Database\Eloquent\ModelNotFoundException;
```

**Evidence**
```
$ grep -n "App\\Models\\V1\\GlobalMaster" Modules/GlobalMaster/app/Http/Controllers/CountryController.php
6:use App\Models\V1\GlobalMaster\District;
7:use App\Models\V1\GlobalMaster\State;
$ php -r '... class_exists("App\\Models\\V1\\GlobalMaster\\State") ...' 
bool(false)   # both phantom classes; Modules\GlobalMaster\Models\State => bool(true)
$ ls app/Models/V1
ls: cannot access 'app/Models/V1': No such file or directory
```

#### CNTRY-12 · L · STY-04 — copy-pasted boilerplate comments in five methods

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English without emoji; no copy-pasted docblocks; no "temporary"/"debug" notes.* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:51-54`, `:160-163`, `:199-202`, `:227-230`, `:274-280` |
| **Root cause** | The same `begin::Activity Log` / `Syntex : activityLog(...)` block (with the misspelled "Syntex") is pasted into `store`, `destroy`, `restore`, `forceDelete` and `toggleStatus`. The `toggleStatus` copy (`:274-280`) is a stale multi-line explanation of a previous version. |
| **Consequence** | Noise that hides the real intent of each `activityLog()` call and drifts from the code it describes. |
| **Reproduce** | static only. |
| **Fix approach** | Remove the copy-pasted "Syntex" boilerplate lines, keeping only the `activityLog(...)` call. |
| **Plan item** | CNTRY-12 in `02-fix-plan.md` §8 |

```php
// CountryController.php:51-53 — CURRENT (repeated in the other four methods)
                // begin::Activity Log
                // Syntex : activityLog('Subject: on which operation is performed', 'even : created, edited, deleted , trashed , toggleSwitch etc', ['Key' => 'Pair' , container the detailed information if requied]);
                activityLog($country, 'Stored', ['message' => 'A new country was created.', 'other' => 'some other information']);
```

**Evidence**
```
$ grep -cn "Syntex : activityLog" Modules/GlobalMaster/app/Http/Controllers/CountryController.php
5
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 wrong overwrite | 2 delete before store | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok | ok (DB unique on name/short_name) | ok | ok | ok |
| `update` | ok | ok | ok | ok | ok | ok | CNTRY-12 (wording) | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | ok | ok | ok | ok | CNTRY-13 | ok | CNTRY-13 | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | CNTRY-02 | ok |

#### CNTRY-13 · M · F13 (deep-read #2/#5) — `forceDelete` has no guard for dependent states

| Field | Value |
|---|---|
| **Rule** | F13 deep-read — *is anything deleted before its replacement / is there a race; does a message lie.* The DB enforces it: `glb_states.country_id` has `FOREIGN KEY ... ON DELETE RESTRICT`. |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/CountryController.php:222-243`, method `forceDelete()` |
| **Root cause** | `$country->forceDelete()` runs on any trashed country. Live data has one country (India, id 1) with 36 states, and `glb_states_country_id_foreign` is `ON DELETE RESTRICT`, so the delete throws a `QueryException`. The generic `catch (\Throwable)` (CNTRY-01) turns it into the vague "The operation could not be completed." The activity-log write sits **after** the delete, so nothing is logged for the attempt. |
| **Consequence** | Super Admin clicks the permanent-delete icon on India, confirms, and gets a generic error with no explanation; the country can never be force-deleted while it has states, and the screen gives no hint that states must be removed first. |
| **Reproduce** | Open `/global-master/country/trash/view` (after trashing a country that has states) and click permanent delete — expected a clear "remove its states first" message; actual is the generic error. |
| **Fix approach** | Decide the behaviour: (a) block early with a clear message when `$country->states()->exists()`, or (b) leave the DB to reject and translate the FK failure into a readable message. |
| **Plan item** | CNTRY-13 in `02-fix-plan.md` §9 (DECISION) |

```php
// CountryController.php:224-229 — CURRENT
                $country = Country::withTrashed()->findOrFail($id);
                $country->forceDelete();

                activityLog($country, 'Deleted', ['message' => 'A new country was permanently deleted.', 'other' => 'some other information']);
```

**Evidence**
```
$ php artisan tinker --execute '... information_schema.REFERENTIAL_CONSTRAINTS ...'
glb_states_country_id_foreign | RESTRICT
$ php artisan tinker --execute '... counts ...'
{"c":1,"s":36,"d":785,"ci":1592}
$ php artisan tinker --execute 'SELECT c.id,c.name,(SELECT COUNT(*) FROM glb_states s WHERE s.country_id=c.id) st FROM glb_countries c'
[{"id":1,"name":"India","st":36}]
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/GlobalMaster/routes/web.php` | Two complete route groups (`central.prime.country.*` and `central.global-master.country.*`) point at this controller. The `prime` group is referenced only by `app/Services/Breadcrumbs/registry.php:1059`; the live screen uses the `global-master` names. Duplicated surface and a second place to keep middleware in sync. | RTE / CTL-05 | Route-file owner (shared) |
| `config/permissionslist.php` (`global-master.country`) | Key exists with all seven `$crud` actions; no defect. Noted so the fixer does not add a new key. | — | — |
| Canonical DDL `pgdatabase/2-DDL_Tenant_Enhanced/_Core/_global_db_v4.1.sql:14-27` | The canonical DDL declares `UNIQUE KEY uq_glb_countries_globalCode (global_code)`, but the **live** `glb_countries` has only `name` and `short_name` unique, and `CountryRequest` does not validate `global_code` uniqueness. If the DDL is ever applied, a duplicate non-null `global_code` becomes a 500. Schema drift — outside this controller's fix plan. | VAL-04 (latent) | DDL / migration owner |
| `resources/views/components/backend/table/action-trashed.blade.php` | Builds a GET form for `restore` because the route is GET; correctly switches to DELETE with CSRF when the route verb changes. Not fixed here (shared component). | — | Component owner |
| `Modules/GlobalMaster/app/Models/State.php`, `District.php` | Used by `toggleStatus` for the cascade. Both cast `is_active` and are SoftDeletes; the cascade uses mass `update()`, which applies the soft-delete scope, so trashed children are not resurrected. No defect found in usage. | — | State/District audits |

## 8. Not covered, and why

- **No write or failure path was executed.** D4 forbids tests; the force-delete FK rejection (CNTRY-13) and the `toggleStatus` rollback (CNTRY-02) were proven from the schema and the code, not by running them.
- **No Blade was rendered in a browser.** View checks were static (`grep`) and by reading the templates; the shared layout and components are common classes, not audited here.
- **The `activityLog()` sink** (`Modules/Prime/Models/ActivityLog` in central context) and `AuthorizesTenantFeature` are common classes; only the arguments passed from this controller were checked.
- **The duplicate `prime` route group** was observed and logged in §7 but not audited controller-by-controller; it belongs to the route file.
