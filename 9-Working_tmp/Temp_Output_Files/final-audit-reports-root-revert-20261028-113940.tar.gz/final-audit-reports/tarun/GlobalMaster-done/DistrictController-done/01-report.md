# Final Audit — GlobalMaster / DistrictController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php` (302 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/global-master/district` (list), `/global-master/district/create`, `/global-master/district/{district}` (show), `/global-master/district/{district}/edit`, `/global-master/district/trash/view`, plus an identical `/prime/district…` copy. Create/update/delete redirect to `http://test.localhost:8000/global-master/location-setup#district`. |
| Menu path | Global Master → Location Setup (the district section on the geography master screen). |
| Who uses it | Platform / super-admin side. Holders of `prime.global-master.district.{create,view,viewAny,update,delete,restore,forceDelete}` — the `global-master.district` key in `config/permissionslist.php:215` is expanded to all seven actions by `$crud`, auto-granted to Super Admin and granted read-only to `global-master.district` holders by `Modules/Prime/database/seeders/RolePermissionSeeder.php:66,149,198`. |
| What a user does here | A platform operator maintains the district list used by every tenant's address records: adds a district under a state, edits its name/short name/global code/active flag, views one, trash-restores-force-deletes it, and toggles its active status from the list. Activating a district is blocked while its parent state is inactive. |
| Tables written | `glb_districts` (via the `District` model on the `global_master_mysql` connection), `sys_activity_logs` (via the common `activityLog()` helper). |
| Tables read | `glb_districts`, `glb_states`, `glb_countries` (eager-loaded on the list), plus a separate unbounded `glb_countries` read in `edit()` and the shared `SelectCountry` / `SelectState` form components. |
| Live data | `glb_districts` 785 live, 0 trashed; `glb_countries` 1; `glb_states` 36 (measured on test.localhost via tinker). The live table has `PRIMARY (id)`, `uq_district_state_name (state_id,name)` and `glb_districts_short_name_unique (short_name)` — see F4. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready: six H findings sit on real screens. The single worst is **DIST-10**: `restore` is exposed as a plain GET route — the trash screen's restore button is an `href`, so a link prefetcher, a crawler, or an accidental click un-deletes a district with no CSRF and no POST confirmation (the same defect the City/Country siblings carry). **DIST-07** and **DIST-08** mean the create/edit uniqueness rules do not match the live indexes in either direction: a name already used in another state is wrongly rejected (5 live examples), while a duplicate `short_name` is not validated at all and reaches the DB. **DIST-17** makes the trash page run 2 extra queries per row. Everything else is the retired house "A1" try/catch envelope (which protocol D1 now bans), response-building inside transactions, one dead query, and style debt. Rough effort to fix the plan: S–M — mostly removing the try/catch envelope, correcting two validation rules, and one shared-route/shared-component pair.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 6 | 8 | 8 | 1 | 22 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | DIST-01, DIST-02, DIST-03, DIST-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | DIST-05 | F9 Queries/Perf | DIST-15, DIST-16, DIST-17 |
| F3 Authorization | DIST-06 | F10 Views | DIST-18, DIST-19 |
| F4 Validation | DIST-07, DIST-08, DIST-09 | F11 Security/Tenancy | clean |
| F5 Routes | DIST-10, DIST-11 | F12 Style | DIST-20, DIST-21, DIST-22 |
| F6 Controller shape | DIST-12, DIST-13 | F13 Deep read | DIST-09 |
| F7 Models | DIST-14 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php` | controller | 302 | this report | ✅ |
| 2 | `Modules/GlobalMaster/app/Models/District.php` | model | 39 | this report (claimed in _Info/00-CLASS-OWNERS.md) | ✅ |
| 3 | `Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php` | form request | 51 | this report (claimed in _Info/00-CLASS-OWNERS.md) | ✅ |
| 4 | `Modules/GlobalMaster/routes/web.php` (lines 74-80 and 184-190 only) | route file | 198 | ⚠ SHARED — district rows only | ✅ usage; edits are ⚠ SHARED |
| 5 | `Modules/GlobalMaster/resources/views/district/index.blade.php` | view | 97 | this report | ✅ |
| 6 | `Modules/GlobalMaster/resources/views/district/create.blade.php` | view | 65 | this report | ✅ |
| 7 | `Modules/GlobalMaster/resources/views/district/edit.blade.php` | view | 67 | this report | ✅ |
| 8 | `Modules/GlobalMaster/resources/views/district/show.blade.php` | view | 75 | this report | ✅ |
| 9 | `Modules/GlobalMaster/resources/views/district/trash.blade.php` | view | 53 | this report | ✅ |
| 10 | `Modules/GlobalMaster/app/Models/State.php` | model | 41 | ↗ [tarun/GlobalMaster-done/StateController](../StateController-done/01-report.md) — owned by StateController (same batch; report not yet written) | ↗ linked — usage-check only |
| 11 | `Modules/GlobalMaster/app/Models/Country.php` | model | 31 | ↗ [tarun/GlobalMaster-done/CountryController](../CountryController-done/01-report.md) | ↗ linked — usage-check only |
| 12 | `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` | shared blade | 54 | ↗ owned by the PrimeCore shared-component owner (CityController report §7) | ↗ linked — usage-check only |
| 13 | `app/View/Components/Backend/Form/SelectCountry.php` (+ blade), `SelectState`, `App\Traits\AuthorizesTenantFeature`, `App\Models\BaseModel`, `App\Http\Controllers\Controller`, `activityLog()`, `flash()`, `config/permissionslist.php`, `config/flash.php` | common | — | common (§4.2) | referenced, not owned |

No pre-applied files — no `PRE-APPLIED-2026-10-10.md` exists for GlobalMaster.

## 4. Routes

Uncached route list filtered for `DistrictController@` (from the fresh `/tmp/fa-routes.json`, generated with `APP_ROUTES_CACHE=/tmp/fa-nocache.php`):

```
GET|HEAD global-master/district                                       central.global-master.district.index         DistrictController@index
POST    global-master/district                                       central.global-master.district.store         DistrictController@store
GET|HEAD global-master/district/create                                central.global-master.district.create        DistrictController@create
GET|HEAD global-master/district/trash/view                            central.global-master.district.trashed       DistrictController@trashedDistrict
GET|HEAD global-master/district/{district}                            central.global-master.district.show          DistrictController@show
PUT|PATCH global-master/district/{district}                            central.global-master.district.update        DistrictController@update
DELETE  global-master/district/{district}                            central.global-master.district.destroy       DistrictController@destroy
GET|HEAD global-master/district/{district}/edit                       central.global-master.district.edit          DistrictController@edit
POST    global-master/district/{district}/toggle-status              central.global-master.district.toggleStatus  DistrictController@toggleStatus
DELETE  global-master/district/{id}/force-delete                     central.global-master.district.forceDelete   DistrictController@forceDelete
GET|HEAD global-master/district/{id}/restore                         central.global-master.district.restore       DistrictController@restore
— identical set repeated under prime/district… with names central.prime.district.* (web.php lines 184-190)
```

All routes sit inside `Route::domain(config('app.domain'))` (central only) with `['auth','verified']` middleware — RTE-05 is clean. Unrouted public methods: none — all 11 public methods are routed (RTE-03 clean; RTE-02 clean: every route name resolves to an existing method).

Route file shape (`Modules/GlobalMaster/routes/web.php:75-79`, repeated at `185-189`): `Route::resource('district', …)` comes first, then the four custom routes. The custom URIs (`/district/trash/view`, `/district/{id}/restore`, `/district/{id}/force-delete`, `/district/{district}/toggle-status`) cannot be captured by the resource's `/{district}` single segment, so RTE-06 is not triggered.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 23 | GET /global-master/district | `prime.global-master.district.viewAny` | none (read) | — | — | DIST-16 |
| `create` | 37 | GET /global-master/district/create | `prime.global-master.district.create` | none (read) | — | — | — |
| `store` | 46 | POST /global-master/district | `prime.global-master.district.create` (+ FormRequest) | controller `DB::transaction` | Stored | glb_districts, sys_activity_logs | DIST-01, DIST-03, DIST-05, DIST-06, DIST-07, DIST-08 |
| `show` | 83 | GET /global-master/district/{district} | `prime.global-master.district.view` | none (read) | — | — | — |
| `edit` | 93 | GET /global-master/district/{district}/edit | `prime.global-master.district.update` | none (read) | — | — | DIST-15 |
| `update` | 106 | PUT/PATCH /global-master/district/{district} | `prime.global-master.district.update` (+ FormRequest) | controller `DB::transaction` | Updated | glb_districts, sys_activity_logs | DIST-01, DIST-03, DIST-05, DIST-06, DIST-07, DIST-08 |
| `destroy` | 141 | DELETE /global-master/district/{district} | `prime.global-master.district.delete` | controller `DB::transaction` | Trashed | glb_districts, sys_activity_logs | DIST-01, DIST-03, DIST-05 |
| `trashedDistrict` | 174 | GET /global-master/district/trash/view | `prime.global-master.district.restore` | none (read) | — | — | DIST-17 |
| `restore` | 185 | GET /global-master/district/{id}/restore | `prime.global-master.district.restore` | controller `DB::transaction` | Restored | glb_districts, sys_activity_logs | DIST-01, DIST-03, DIST-05, DIST-10, DIST-12 |
| `forceDelete` | 225 | DELETE /global-master/district/{id}/force-delete | `prime.global-master.district.forceDelete` | controller `DB::transaction` | Deleted | glb_districts, sys_activity_logs | DIST-01, DIST-03, DIST-05, DIST-12 |
| `toggleStatus` | 256 | POST /global-master/district/{district}/toggle-status | `prime.global-master.district.update` | controller `DB::transaction` | Toggled | glb_districts, sys_activity_logs | DIST-01, DIST-02, DIST-03, DIST-04, DIST-05 |

## 6. Findings

### F1 — Errors

#### DIST-01 · H · ERR-00 (settled by D1) — controller-wide try/catch, six blocks

| Field | Value |
|---|---|
| **Rule** | ERR-00 (H, raised from "undecided" by protocol D1) — *the Laravel idiom: no try/catch in controllers; a controller try/catch is a finding unless D2 allows it* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:51-77` (store), `:110-135` (update), `:145-168` (destroy), `:189-212` (restore), `:231-250` (forceDelete), `:260-300` (toggleStatus) |
| **Root cause** | The controller follows the retired house "Rule A1" shape (`try { DB::transaction(...) } catch (ModelNotFoundException) { throw } catch (\Throwable) { log; redirect }`). Protocol D1 supersedes A1 for audited modules; none of the D2 exceptions apply (no `\DomainException`, no truncate-then-rebuild, no `SnapshotProtectionException`). |
| **Consequence** | Every mutating method duplicates about 20 lines of error plumbing; the generic catch turns any unexpected failure (QueryException, ValidationException) into a generic redirect, hiding the true status the central renderer (`bootstrap/app.php`) would produce. |
| **Reproduce** | Static only — cast a DB error during store and observe the falsified "The operation could not be completed." redirect instead of a 500 that the central handler owns. |
| **Fix approach** | Remove the try/catch envelope from all six methods; keep `DB::transaction(fn () => …)` and let exceptions bubble to `bootstrap/app.php`. The `ModelNotFoundException` rethrows become unnecessary — D1 removes the swallow risk entirely. |
| **Plan item** | DIST-01 in `02-fix-plan.md` §3 |

```php
// DistrictController.php:51-77 — CURRENT (store; update/destroy/restore/toggleStatus identical shape; forceDelete at 231-250)
        try {
            return DB::transaction(function () use ($request) {
                $validatedData = $request->validated();

                // Create the district
                $district = District::create($validatedData);

                // Activity Log
                activityLog($district, 'Stored', [
                    'message' => 'A new district was created.',
                    'other' => 'some other information'
                ]);

                return redirect()
                    ->to(route('central.global-master.location-setup.index').'#district')
                    ->with('success', flash('created.district'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('DistrictController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -c "try {" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
6
$ grep -c "getMessage" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
6
$ grep -c "ModelNotFoundException" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
7
```

#### DIST-02 · H · ERR-02 — toggleStatus swallows a 422 and answers an AJAX caller with a redirect

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422/abort() into a redirect or 500* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:260-300`, method `toggleStatus()` |
| **Root cause** | `$request->validate([...])` runs inside the `try`, and the generic `catch (\Throwable $e)` catches the `ValidationException` it throws. |
| **Consequence** | A bogus `is_active` value from the status-switch AJAX call returns a `back()` HTML redirect (302 with an HTML page) instead of a JSON 422; the switch flips back with no message. |
| **Reproduce** | `curl -X POST http://test.localhost:8000/global-master/district/{district}/toggle-status -d 'is_active=banana'`. Expected JSON 422; actual 302 HTML redirect. |
| **Fix approach** | Move the `validate()` above the transaction and remove the try — under D1 there is no catch left to swallow it, and the central handler renders a JSON 422 for `$request->expectsJson()`. |
| **Plan item** | DIST-02 in `02-fix-plan.md` §3 |

```php
// DistrictController.php:260-264 — CURRENT (validate sits inside try; catch (\Throwable) swallows ValidationException)
        try {
            return DB::transaction(function () use ($request, $district) {
                $request->validate([
                    'is_active' => 'required|boolean',
                ]);
```

**Evidence**
```
$ grep -n "validate(\|catch (\\Throwable" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
262:                $request->validate([
296:        } catch (\Throwable $e) {
```

#### DIST-03 · M · ERR-05 — six log calls drop the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:74,132,165,209,242,297` (store, update, destroy, restore, forceDelete, toggleStatus) |
| **Root cause** | The retired A1 catch template logs `['error' => $e->getMessage()]` — exactly the anti-pattern the rulebook's Contradictions table bans. |
| **Consequence** | Every failure is logged without a stack trace; the message alone cannot locate the failing call, and raw SQL text leaks into the log file. |
| **Reproduce** | Static only — break a constraint while updating and read the log line: no exception class, no trace. |
| **Fix approach** | With the try removed (DIST-01) the `Log::error` lines disappear entirely; nothing must log `.getMessage()` alone. |
| **Plan item** | DIST-03 is applied by DIST-01 (the log lines live inside the removed catches); no separate item — see §10. |

```php
// DistrictController.php:74 — CURRENT (identical at 132, 165, 209, 242, 297)
            Log::error('DistrictController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "Log::error" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
74:            Log::error('DistrictController::store failed', ['error' => $e->getMessage()]);
132:            Log::error('DistrictController::update failed', ['error' => $e->getMessage()]);
165:            Log::error('DistrictController::destroy failed', ['error' => $e->getMessage()]);
209:            Log::error('DistrictController::restore failed', ['error' => $e->getMessage()]);
242:            Log::error('DistrictController::forceDelete failed', [
297:            Log::error('DistrictController::toggleStatus failed', ['error' => $e->getMessage()]);
```

#### DIST-04 · M · ERR-04 — toggleStatus mixes JSON success and HTML failure without expectsJson()

| Field | Value |
|---|---|
| **Rule** | ERR-04 (M) — *JSON endpoints fail with JSON; form endpoints fail with a redirect; use `$request->expectsJson()` when one method serves both* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:285-300`, method `toggleStatus()` |
| **Root cause** | The success branch returns `response()->json(...)` but every failure branch returns `back()->with('error', ...)` (HTML). The endpoint is only ever called by the AJAX status switch. |
| **Consequence** | Any failure (validation, DB) delivers HTML to the JSON caller; the toggle silently fails with no user message. |
| **Reproduce** | `curl -X POST http://test.localhost:8000/global-master/district/{district}/toggle-status` without `is_active` — the response `Content-Type` is `text/html`, not JSON. |
| **Fix approach** | Remove the try (no catch to return HTML) and keep `$request->validate()` outside the transaction so the 422 the central renderer produces is JSON for AJAX. |
| **Plan item** | DIST-04 is applied by DIST-01 (the rewritten `toggleStatus` has no `back()` failure branch); no separate item — see §10. |

```php
// DistrictController.php:285-300 — CURRENT (JSON success, HTML failure)
                return response()->json([
                    'success' => true,
                    'is_active' => $district->is_active,
                    'message' => flash('status_updated.district')
                ]);

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('DistrictController::toggleStatus failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "response()->json\|back()" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
76:            return back()->with('error', 'The operation could not be completed.');
134:            return back()->with('error', 'The operation could not be completed.');
167:            return back()->with('error', 'The operation could not be completed.');
211:            return back()->with('error', 'The operation could not be completed.');
270:                    return response()->json([
285:                return response()->json([
299:            return back()->with('error', 'The operation could not be completed.');
```

### F2 — Transactions and audit

#### DIST-05 · M · TXN-05 — redirects/JSON responses built inside the transaction closure in all six mutating methods

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()` / `response()` after it* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:52-68` (store), `:111-126` (update), `:146-159` (destroy), `:190-203` (restore), `:232-240` (forceDelete), `:261-291` (toggleStatus) |
| **Root cause** | Each closure returns a `redirect()->to(...)` / `response()->json(...)` while the transaction is still open; the commit only happens because the closure returns the response. |
| **Consequence** | The transaction stays open while the response object and flash session write are assembled; harmless today but the wrong shape, and it forces the `return`-inside-closure that TXN-05 calls out. |
| **Reproduce** | Static only — read any of the six closures. |
| **Fix approach** | Have the closure return the model (or `true`), then build the redirect/JSON outside it: `$district = DB::transaction(fn () => ...); return redirect()->to(...);` |
| **Plan item** | DIST-05 is applied by DIST-01 (every rewritten method returns the model from the closure and builds the response after it); no separate item — see §10. |

```php
// DistrictController.php:52-68 — CURRENT (store; same return-inside-closure shape in the other five)
            return DB::transaction(function () use ($request) {
                $validatedData = $request->validated();

                // Create the district
                $district = District::create($validatedData);

                // Activity Log
                activityLog($district, 'Stored', [
                    'message' => 'A new district was created.',
                    'other' => 'some other information'
                ]);

                return redirect()
                    ->to(route('central.global-master.location-setup.index').'#district')
                    ->with('success', flash('created.district'));

            });
```

**Evidence**
```
$ grep -n "return DB::transaction\|return redirect\|return response" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
52:            return DB::transaction(function () use ($request) {
64:                return redirect()
111:            return DB::transaction(function () use ($request, $district) {
122:                return redirect()
146:            return DB::transaction(function () use ($district) {
155:                return redirect()
190:            return DB::transaction(function () use ($id) {
199:                return redirect()
232:            return DB::transaction(function () use ($district) {
237:                return redirect()
261:            return DB::transaction(function () use ($request, $district) {
270:                    return response()->json([
285:                return response()->json([
```

### F3 — Authorization

#### DIST-06 · L · AUTH-04 — the same permission is checked twice on store and update

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:46-108` + `Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php:44-50` |
| **Root cause** | `DistrictRequest::authorize()` maps POST to `prime.global-master.district.create` and PUT/PATCH to `prime.global-master.district.update` (via `authorizeByCrudPermission`), and the controller calls `Gate::authorize` for the same names immediately after. The FormRequest runs first, so the controller call can never change the outcome. |
| **Consequence** | Duplicated logic that drifts when one side is edited; a second place to get the permission name wrong. |
| **Reproduce** | Static only — read both files. |
| **Fix approach** | Keep the FormRequest `authorize()` (it runs first) and drop the two `Gate::authorize` calls in `store()`/`update()` — or keep the controller gates and strip the request trait. Preference: keep the request, since it is the project's FormRequest rule. |
| **Plan item** | DIST-06 is applied by DIST-01 (the rewritten `store()`/`update()` drop the redundant `Gate::authorize`); no separate item — see §10. |

```php
// DistrictController.php:46-49 — CURRENT (the duplicate controller gate)
    public function store(DistrictRequest $request)
    {
        Gate::authorize('prime.global-master.district.create');
        // Only use validated data (important)
```

**Evidence**
```
$ grep -n "Gate::authorize\|authorizeByCrudPermission" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php
DistrictController.php:48:        Gate::authorize('prime.global-master.district.create');
DistrictController.php:108:        Gate::authorize('prime.global-master.district.update');
DistrictRequest.php:49:        return $this->authorizeByCrudPermission('prime.global-master.district');
```

### F4 — Validation and input

#### DIST-07 · H · VAL-04 — the `name` uniqueness rule ignores `state_id`; the DB index allows the same name in two states

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the real unique index including soft-delete semantics* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php:21-26`, rule for `name` |
| **Root cause** | `Rule::unique('glb_districts')->ignore($districtId)` checks `name` across the **whole** table. The live unique index is the composite `uq_district_state_name (state_id, name)`, so the same district name is legal in a different state. The rule is stricter than the DB and rejects a legal create/edit. |
| **Consequence** | A user cannot create a district named "Aurangabad" in a second state: the form returns "The name has already been taken." although the DB permits it. Five such names already exist live. |
| **Reproduce** | Create a district with the name `Balrampur` under any state other than the one that already has it — the form rejects it with the taken-name message. |
| **Fix approach** | Scope the rule to the submitted `state_id` (and exclude soft-deleted rows): `Rule::unique('glb_districts')->where('state_id', $this->input('state_id'))->ignore($districtId)->whereNull('deleted_at')`. |
| **Plan item** | DIST-07 in `02-fix-plan.md` §5 |

```php
// DistrictRequest.php:21-26 — CURRENT
            'name' => [
                'required',
                'string',
                'max:50',
                Rule::unique('glb_districts')->ignore($districtId),
            ],
```

**Evidence**
```
$ grep -n "Rule::unique" Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php
25:                Rule::unique('glb_districts')->ignore($districtId),
$ php artisan tinker --execute '$c=DB::connection("global_master_mysql"); echo "dup name ACROSS states live: ".$c->select("SELECT COUNT(*) n FROM (SELECT name FROM glb_districts WHERE deleted_at IS NULL GROUP BY name HAVING COUNT(*)>1) x")[0]->n.PHP_EOL; foreach($c->select("SELECT name, COUNT(DISTINCT state_id) d FROM glb_districts WHERE deleted_at IS NULL GROUP BY name HAVING d>1 LIMIT 5") as $r){ echo $r->name." in ".$r->d." states".PHP_EOL; }'
dup name ACROSS states live: 5
Aurangabad in 2 states
Balrampur in 2 states
Bilaspur in 2 states
Hamirpur in 2 states
Pratapgarh in 2 states
```

#### DIST-08 · H · VAL-04 — `short_name` has a unique index but no validation rule

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the real unique index* |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php:27`, rule for `short_name`; index `glb_districts_short_name_unique` |
| **Root cause** | The live table (and the migration at `2025_10_09_042940_create_districts_table.php:23`) declares `short_name` UNIQUE, but the request validates only `required|string|max:10`. A duplicate `short_name` passes validation and reaches the DB. |
| **Consequence** | Creating a district whose short name already exists throws a SQL unique-constraint error. Today the generic catch hides it behind "The operation could not be completed."; after the D1 cleanup (DIST-01) it becomes a 500. The user is never told the short name is taken. |
| **Reproduce** | Create a district with `short_name` set to a value already in use (for example `AP`) — the save fails with no field-level message. |
| **Fix approach** | Add `Rule::unique('glb_districts')->ignore($districtId)->whereNull('deleted_at')` to the `short_name` rule. |
| **Plan item** | DIST-08 in `02-fix-plan.md` §5 |

```php
// DistrictRequest.php:27 — CURRENT
            'short_name' => ['required', 'string', 'max:10'],
```

**Evidence**
```
$ grep -n "Rule::unique" Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php
25:                Rule::unique('glb_districts')->ignore($districtId),
$ php artisan tinker --execute '$c=DB::connection("global_master_mysql"); foreach($c->select("SHOW INDEX FROM glb_districts") as $i){ echo $i->Key_name." : ".$i->Column_name.PHP_EOL; }'
PRIMARY : id
uq_district_state_name : state_id
uq_district_state_name : name
glb_districts_short_name_unique : short_name
```

#### DIST-09 · M · DECISION · VAL-04 / MDL-07 / DDL-wins — soft-delete blocks re-use of a name and the DDL's `global_code` key is missing

| Field | Value |
|---|---|
| **Rule** | VAL-04 / MDL-07 / DDL-wins (M) — *uniqueness mirrors the DB index; the DDL is the source of truth* |
| **Where** | `Modules/GlobalMaster/database/migrations/2025_10_09_042940_create_districts_table.php:22-26`; DDL `pgdatabase/2-DDL_Tenant_Consolidated/_global_db_v4.sql:57-59`; live `glb_districts` |
| **Root cause** | Three drifts. (1) The unique indexes `uq_district_state_name` and `glb_districts_short_name_unique` do not include `deleted_at`, so a trashed district keeps its name and short name reserved — a re-create is blocked at the DB even after DIST-07/DIST-08 add `whereNull('deleted_at')`. (2) The DDL declares `UNIQUE KEY uq_glb_districts_globalCode (global_code)`; neither the migration nor the live table has it, so `global_code` uniqueness is enforced nowhere. (3) `name` is `varchar(50)` in both but has no schema tie to the request's `max:50` beyond chance. |
| **Consequence** | After a district is trashed, nobody can create a new district with the same name/short name until it is force-deleted. Duplicate global codes can be stored through any path that skips `DistrictRequest`. |
| **Reproduce** | `php artisan tinker --execute '$c=DB::connection("global_master_mysql"); foreach($c->select("SHOW INDEX FROM glb_districts") as $i){ echo $i->Key_name.PHP_EOL; }'` — no `deleted_at` in either unique key and no `global_code` key. (Live trashed rows are 0 today, so the soft-delete block cannot be shown with real data yet.) |
| **Fix approach** | A product/schema decision — see `02-fix-plan.md` §9. |
| **Plan item** | DIST-09 in `02-fix-plan.md` §9 (DECISION) |

```php
// 2025_10_09_042940_create_districts_table.php:22-26 — CURRENT (unique keys do not include deleted_at; no global_code key)
            $table->string('name', 50);
            $table->string('short_name', 10)->unique();
            $table->string('global_code', 10)->nullable();
            $table->boolean('is_active')->default(true);
            $table->unique(['state_id', 'name'], 'uq_district_state_name'); // For a given state district name should be unique
```

**Evidence**
```
$ php artisan tinker --execute '$c=DB::connection("global_master_mysql"); foreach($c->select("SHOW INDEX FROM glb_districts") as $i){ echo $i->Key_name." : ".$i->Column_name.PHP_EOL; }'
PRIMARY : id
uq_district_state_name : state_id
uq_district_state_name : name
glb_districts_short_name_unique : short_name
$ grep -n "glb_districts" ../pgdatabase/2-DDL_Tenant_Consolidated/_global_db_v4.sql | head
57:    UNIQUE KEY `uq_glb_districts_stateId_name` (`state_id`,`name`),
58:    UNIQUE KEY `uq_glb_districts_shortName` (`short_name`),
59:    UNIQUE KEY `uq_glb_districts_globalCode` (`global_code`),
```

### F5 — Routes

#### DIST-10 · H · RTE-01 — restore is a GET route; the trash screen wires it as a plain link

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, ...); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/GlobalMaster/routes/web.php:77` and `:187` (`Route::get('/district/{id}/restore', ...)`), controller `restore()` at `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:185-213` |
| **Root cause** | `restore()` un-deletes a row (a write), but the route is `GET`. The shared trash-row component renders it as an anchor with only a JS confirm — see DIST-11. |
| **Consequence** | A prefetcher, a crawler, or a mis-click restores a trashed district with no CSRF token; the destructive intent is not confirmed by anything the browser cannot skip. |
| **Reproduce** | Visit `http://test.localhost:8000/global-master/district/999/restore` with the id of any trashed district — the district is restored on GET. |
| **Fix approach** | Change the route to `POST`, change the shared component to submit a small form like the force-delete button does, keep the JS confirm. This is a ⚠ SHARED change (route file + shared PrimeCore component). |
| **Plan item** | DIST-10 in `02-fix-plan.md` §1 (⚠ SHARED) |

```php
// Modules/GlobalMaster/routes/web.php:75-79 — CURRENT
        Route::resource('district', DistrictController::class);
        Route::get('/district/trash/view', [DistrictController::class, 'trashedDistrict'])->name('district.trashed');
        Route::get('/district/{id}/restore', [DistrictController::class, 'restore'])->name('district.restore');
        Route::delete('/district/{id}/force-delete', [DistrictController::class, 'forceDelete'])->name('district.forceDelete');
        Route::post('/district/{district}/toggle-status', [DistrictController::class, 'toggleStatus'])->name('district.toggleStatus');
```

**Evidence**
```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); foreach($r as $x){ if(str_contains($x["action"]??"","DistrictController@restore")) printf("%-7s %-45s %s\n",$x["method"],$x["uri"],$x["name"]??"-"); }'
GET|HEAD global-master/district/{id}/restore              central.global-master.district.restore
GET|HEAD prime/district/{id}/restore                      central.prime.district.restore
```

#### DIST-11 · M · RTE-01 — the shared trash-row component wires restore as a plain GET link

| Field | Value |
|---|---|
| **Rule** | RTE-01 (M — the shared wiring that makes DIST-10 reachable; kept M because the fix is in another module's component) — *state changes must not be GET links* |
| **Where** | `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php:1-10` (the `href` for restore) |
| **Root cause** | The district trash screen uses the shared PrimeCore `action-trashed` component, which renders restore as an anchor link with only a JavaScript `confirm()`. Even after DIST-10 changes the route to POST, this link would 405 — the component must submit a small POST form instead. |
| **Consequence** | The restore action is one click (or one prefetch) away with no CSRF token; it is the browser-facing half of DIST-10. |
| **Reproduce** | Open `/global-master/district/trash/view` and inspect the restore control: an anchor with a JS confirm. |
| **Fix approach** | Rebuild the restore control as a tiny `@csrf` POST form (mirroring the force-delete form in the same file), keep the Swal confirm. This component is shared by every geography trash screen — ⚠ SHARED. |
| **Plan item** | DIST-11 in `02-fix-plan.md` §2 (⚠ SHARED) |

```blade
<form action="{{ route($url . '.forceDelete', $id) }}" method="POST" class="d-inline confirm-action-form-force-delete">
    @csrf
    @method('DELETE')
    <div class="btn-group" role="group" aria-label="Actions">
        <a href="{{ route($url . '.restore', $id) }}" class="btn btn-outline-warning btn-sm confirm-action-restore">
            <i class="fa-solid fa-recycle"></i>
        </a>
        <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fa-solid fa-eraser"></i></button>
    </div>
</form>
```

**Evidence**
```
$ grep -n "route(\$url . '.restore'" Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php
5:        <a href="{{ route($url . '.restore', $id) }}" class="btn btn-outline-warning btn-sm confirm-action-restore">
```

### F6 — Controller shape

#### DIST-12 · M · CTL-03 — restore and forceDelete take `$id` + `findOrFail()` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(District $district)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:185-192` (restore), `:225-233` (forceDelete) |
| **Root cause** | `show`, `edit`, `update`, `destroy` and `toggleStatus` already type-hint `District $district` and get the 404 for free. The two trashed-row methods use `$id` + `District::withTrashed()->findOrFail($id)` instead. The routes use `{id}` for these two (not `{district}`), so implicit binding cannot be switched on without a route-file change. |
| **Consequence** | More code per method; two parameter names for the same resource, an easy renaming trap. |
| **Reproduce** | Static only. |
| **Fix approach** | Deferred (see §10): converting them needs the route parameter renamed to `{district}` plus `->withTrashed()` on the route definitions — a ⚠ SHARED route-file change. The current `$id` + `findOrFail` still returns a correct 404, so this is a maintainability item, not a defect. |
| **Plan item** | none — see `02-fix-plan.md` §10 (deferred) |

```php
// DistrictController.php:185-192 — CURRENT
    public function restore($id)
    {
        Gate::authorize('prime.global-master.district.restore');

        try {
            return DB::transaction(function () use ($id) {
                $district = District::withTrashed()->findOrFail($id);
                $district->restore();
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+' Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
23:    public function index()
37:    public function create()
46:    public function store(DistrictRequest $request)
83:    public function show(District $district)
93:    public function edit(District $district)
106:    public function update(DistrictRequest $request, District $district)
141:    public function destroy(District $district)
174:    public function trashedDistrict()
185:    public function restore($id)
225:    public function forceDelete($id)
256:    public function toggleStatus(Request $request, District $district)
```

#### DIST-13 · L · CTL-04 — no return types on any of the 11 public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:23` (and every other public method) |
| **Root cause** | No method declares a return type. |
| **Consequence** | The PHP/IDE cannot enforce the contract; every response shape is implicit. |
| **Reproduce** | Static only. |
| **Fix approach** | Add return types opportunistically when each method is touched: `index/create/edit/show/trashedDistrict`: `\Illuminate\Contracts\View\View`; `store/update/destroy/restore/forceDelete`: `\Illuminate\Http\RedirectResponse`; `toggleStatus`: `\Illuminate\Http\JsonResponse`. |
| **Plan item** | folded into the controller style item DIST-20 (see §10) |

```php
// DistrictController.php:23 — CURRENT
    public function index()
```

**Evidence**
```
$ grep -cE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
11
```

### F7 — Models (`Modules/GlobalMaster/app/Models/District.php`)

#### DIST-14 · L · MDL-04 — relationships lack return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`)* |
| **Where** | `Modules/GlobalMaster/app/Models/District.php:27-35` (`state()`, `cities()`) |
| **Root cause** | Both relations omit the return type. |
| **Consequence** | No static guarantee the relation resolves to the declared class. |
| **Reproduce** | Static only. |
| **Fix approach** | `state(): BelongsTo` and `cities(): HasMany` (imports added). Applied with the model style item DIST-22. |
| **Plan item** | DIST-14 is applied by DIST-22 (the same model edit adds the return types); no separate item — see §10. |

```php
// District.php:27-35 — CURRENT
    public function state()
    {
        return $this->belongsTo(State::class);
    }

    public function cities()
    {
        return $this->hasMany(City::class);
    }
```

**Evidence**
```
$ php artisan tinker --execute '$d=Modules\GlobalMaster\Models\District::with("state.country")->whereNotNull("state_id")->first(); echo $d->name." > ".$d->state->name." > ".$d->state->country->name.PHP_EOL; echo "cities count: ".$d->cities()->count().PHP_EOL;'
Alluri Sitharama Raju > Andhra Pradesh > India
cities count: 0
```

MDL-01 clean (`$fillable` declared, nothing sensitive). MDL-02 clean (`is_active` cast to boolean; the only castable column). MDL-03 n/a (no belongsToMany). MDL-05/TEN-01 n/a (no `InteractsWithMedia`). MDL-07 clean (`glb_districts` exists in migration `2025_10_09_042940_create_districts_table.php` and in the live DB). SoftDeletes matches `deleted_at` (both present).

### F8 — Services and jobs

clean — the controller uses no services, jobs, events, mail or notifications (`grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b' Modules/GlobalMaster/app/Http/Controllers/DistrictController.php` returns only `DistrictRequest`; `activityLog()` and `flash()` are helper functions, not services).

### F9 — Queries and performance

#### DIST-15 · M · QRY-02 / CTL-10 — edit() runs `Country::all()` but no view uses the result

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M — *lists are paginated; no unbounded `Model::all()`*; lowered from H because the result is discarded, so it is wasted work not a user-visible slowdown) / CTL-10 (dead code) |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:97`, method `edit()` |
| **Root cause** | `$countries = Country::all()` is passed to the edit view as `compact('district', 'countries')`, but neither `edit.blade.php` nor `create.blade.php` references `$countries`; the country list comes from the shared `SelectCountry` component, which loads its own. |
| **Consequence** | Every edit-page render runs an extra full `SELECT * FROM glb_countries` that is thrown away. |
| **Reproduce** | Static only — `grep -n "countries" Modules/GlobalMaster/resources/views/district/edit.blade.php` returns nothing. |
| **Fix approach** | Delete the `$countries = Country::all();` line and the `countries` entry from `compact(...)`. |
| **Plan item** | DIST-15 in `02-fix-plan.md` §6 |

```php
// DistrictController.php:93-100 — CURRENT
    public function edit(District $district)
    {
        Gate::authorize('prime.global-master.district.update');
        // Fetch countries for select dropdown
        $countries = Country::all();

        // return both district + countries
        return view('globalmaster::district.edit', compact('district', 'countries'));
```

**Evidence**
```
$ grep -n "countries" Modules/GlobalMaster/resources/views/district/*.blade.php
Modules/GlobalMaster/resources/views/district/index.blade.php:31:                                @forelse($countriesWithStatesAndDistricts as $country)
$ grep -n "Country::all" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
97:        $countries = Country::all();
$ grep -n "Country::" app/View/Components/Backend/Form/SelectCountry.php
20:        $this->countries = Country::where('is_active', true)->get();
```

#### DIST-16 · M · QRY-02 — index() loads every country, state and district in one unbounded query

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M — *lists are paginated; no unbounded `->get()`*; lowered from H because live master data is small: 1 country, 36 states) |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:27-29`, method `index()` |
| **Root cause** | `Country::has('states')->with(['states', 'states.districts'])->get()` renders the whole geography tree with a single unbounded query; no pagination is applied. |
| **Consequence** | As the master data grows the list page loads every district of every state at once; on the current test data the page is fine, but the query is unbounded by design. |
| **Reproduce** | Static only — the screen is an accordion of all countries; the query has no `paginate()`. |
| **Fix approach** | Accepted as informational for now (see §10): the screen intentionally renders the whole tree and the live master data is small. If it grows, paginate countries or load the tree lazily. |
| **Plan item** | none — see `02-fix-plan.md` §10 (accepted) |

```php
// DistrictController.php:27-31 — CURRENT
        $countriesWithStatesAndDistricts = Country::has('states')
            ->with(['states', 'states.districts'])
            ->get();

        return view('globalmaster::district.index', compact('countriesWithStatesAndDistricts'));
```

**Evidence**
```
$ grep -n "Country::has" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
27:        $countriesWithStatesAndDistricts = Country::has('states')
$ php artisan tinker --execute '$c=DB::connection("global_master_mysql"); echo "countries: ".$c->table("glb_countries")->count()." states: ".$c->table("glb_states")->count()." districts: ".$c->table("glb_districts")->count().PHP_EOL;'
countries: 1 states: 36 districts: 785
```

#### DIST-17 · H · QRY-01 / VIEW-02 — the trash list lazy-loads state and state.country for every row

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; no lazy relation access inside `@foreach`* |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:178`; the blade that dereferences the relations is `Modules/GlobalMaster/resources/views/district/trash.blade.php:27` |
| **Root cause** | `trashedDistrict()` runs `District::onlyTrashed()->paginate(10)` with no eager-load, but the blade prints `$district->state->name` and `$district->state->country->name` inside the `@forelse`. That is two lazy queries per row. |
| **Consequence** | The trash page fires 1 + (2 × 10) queries for a 10-row page; with the page size raised it grows linearly. |
| **Reproduce** | Open `http://test.localhost:8000/global-master/district/trash/view` with trashed rows present and count the queries (or read the code: the `@forelse` dereferences two unloaded relations). |
| **Fix approach** | Eager-load the chain the blade prints: `District::onlyTrashed()->with(['state', 'state.country'])->paginate(10)`. |
| **Plan item** | DIST-17 in `02-fix-plan.md` §6 |

```php
// DistrictController.php:178 — CURRENT (trashedDistrict; the blade then dereferences state and state.country)
        $districts = District::onlyTrashed()->paginate(10);
```

**Evidence**
```
$ grep -n "district->state" Modules/GlobalMaster/resources/views/district/trash.blade.php
27:                                        <td>{{ $district->state->name}} {{ $district->state->country->name }}</td>
$ grep -n "onlyTrashed" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
178:        $districts = District::onlyTrashed()->paginate(10);
```

### F10 — Views

#### DIST-18 · L · CTL-05 / STY-04 — the create form references an undefined `$model`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (L — copy-paste) / STY-04 (L — dead code) applied to a view: `old('state_id', $model->state_id ?? null)` where `$model` is never passed |
| **Where** | `Modules/GlobalMaster/resources/views/district/create.blade.php:32` |
| **Root cause** | The `select-state` line was copied from the edit form (which has `$district`), but `create()` passes no model. The `?? null` suppresses the undefined-variable notice, so the reference is silently dead. |
| **Consequence** | On a failed create the state selection repopulates from `old('state_id')` only because the fallback evaluates to null; the `$model` half never does anything, and a reader cannot tell whether a model is expected. |
| **Reproduce** | Static only — `create()` returns the view with no variables. |
| **Fix approach** | Drop the dead fallback: `:stateId="old('state_id')"`. |
| **Plan item** | DIST-18 in `02-fix-plan.md` §7 |

```php
// create.blade.php:32 — CURRENT
                                    <x-backend.form.select-state :stateId="old('state_id', $model->state_id ?? null)" />
```

**Evidence**
```
$ grep -n 'model->state_id' Modules/GlobalMaster/resources/views/district/create.blade.php
32:                                    <x-backend.form.select-state :stateId="old('state_id', $model->state_id ?? null)" />
$ grep -n "public function create" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
37:    public function create()
```

#### DIST-19 · L · STY-04 — commented-out component lines in four blades

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *no commented-out code* |
| **Where** | `Modules/GlobalMaster/resources/views/district/create.blade.php:10`, `edit.blade.php:10`, `trash.blade.php:10`, `index.blade.php:17` |
| **Root cause** | A dead `x-prime.card.header` component is left commented out in three blades and a dead table header in `index.blade.php`. |
| **Consequence** | Consistency debt; a reader greps a component that is not rendered. |
| **Reproduce** | Static only. |
| **Fix approach** | Delete the four commented-out lines. |
| **Plan item** | DIST-19 in `02-fix-plan.md` §7 |

The same commented-out component line is at `create.blade.php:10`, `edit.blade.php:10` and `trash.blade.php:10`:

```blade
                    {{-- <x-prime.card.header title="Districts" url="central.global-master.district" /> --}}
```

**Evidence**
```
$ grep -n "{{-- <x-prime.card.header" Modules/GlobalMaster/resources/views/district/*.blade.php
create.blade.php:10:                    {{-- <x-prime.card.header title="Districts" url="central.global-master.district" /> --}}
edit.blade.php:10:                    {{-- <x-prime.card.header title="Districts" url="central.global-master.district" /> --}}
trash.blade.php:10:                    {{-- <x-prime.card.header title="Districts" url="central.global-master.district" /> --}}
$ grep -n "<!-- <th>" Modules/GlobalMaster/resources/views/district/*.blade.php
index.blade.php:17:                                    <!-- <th>States & Districts</th> -->
```

F10 rest clean: no `Model::`/`DB::` queries in any of the five blades (VIEW-01 ok — the `@php` block in `show.blade.php` reads relations the controller already eager-loaded); no `{!! !!}` on user text (VIEW-03 ok); row actions use the standard `x-prime.table.action` / `action-trashed` components; all five blades compile. Breadcrumbs and permissions in the blades match the controller gates (`@can('prime.global-master.district.update')` on `show.blade.php` equals the controller gate).

### F11 — Security and tenancy

clean — no `env()` outside config (`grep -nE "env\("` on controller, model and request returns nothing); no hard-coded ids or `?? 1`; no personal data in JSON responses; `sys_activity_logs` written via the common helper; routes are central-domain + `['auth','verified']` and every method gates. Tenant rules n/a (this is a central master-data screen).

### F12 — Style

#### DIST-20 · L · STY-01 / STY-02 — `DistrictController.php` style debt

| Field | Value |
|---|---|
| **Rule** | STY-01 (L — `declare(strict_types=1);`), STY-02 (L — Pint: no stray blank lines between imports) |
| **Where** | `Modules/GlobalMaster/app/Http/Controllers/DistrictController.php:1-16` |
| **Root cause** | No `strict_types` declaration; every `use` statement is separated by a blank line, which Pint would collapse. |
| **Consequence** | Consistency debt and a Pint failure on the touched file. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` and let Pint re-sort the imports. |
| **Plan item** | DIST-20 in `02-fix-plan.md` §8 |

```php
// DistrictController.php:1-16 — CURRENT
<?php

namespace Modules\GlobalMaster\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\DB;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Modules\GlobalMaster\Http\Requests\DistrictRequest;
use Modules\GlobalMaster\Models\Country;
use Modules\GlobalMaster\Models\District;
```

**Evidence**
```
$ grep -n "declare(strict_types=1);" Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
(no output)
$ sed -n '1,16p' Modules/GlobalMaster/app/Http/Controllers/DistrictController.php
<?php

namespace Modules\GlobalMaster\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;
```

#### DIST-21 · L · STY-01 — `DistrictRequest.php` style debt

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — `declare(strict_types=1);` |
| **Where** | `Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php:1` |
| **Root cause** | Missing `strict_types` declaration. |
| **Consequence** | Consistency debt with files that declare it. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag. |
| **Plan item** | DIST-21 in `02-fix-plan.md` §8 |

```php
// DistrictRequest.php:1-3 — CURRENT
<?php

namespace Modules\GlobalMaster\Http\Requests;
```

**Evidence**
```
$ grep -n "declare(strict_types=1);" Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php
(no output)
$ head -3 Modules/GlobalMaster/app/Http/Requests/DistrictRequest.php
<?php

namespace Modules\GlobalMaster\Http\Requests;
```

#### DIST-22 · L · STY-01 / MDL-04 — `District.php` style debt and relation return types

| Field | Value |
|---|---|
| **Rule** | STY-01 (L — `declare(strict_types=1);`), MDL-04 (L — relation return types) |
| **Where** | `Modules/GlobalMaster/app/Models/District.php:1-6,27-35` |
| **Root cause** | No `strict_types` declaration; the two relations have no return types (also DIST-14). |
| **Consequence** | Consistency debt; no static guarantee the relations resolve to the declared classes. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);`, import `BelongsTo`/`HasMany`, and type both relations. |
| **Plan item** | DIST-22 in `02-fix-plan.md` §8 (also lands DIST-14) |

```php
// District.php:1-6 — CURRENT
<?php

namespace Modules\GlobalMaster\Models;

use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
```

**Evidence**
```
$ grep -n "declare(strict_types=1);" Modules/GlobalMaster/app/Models/District.php
(no output)
$ grep -n "public function state\|public function cities" Modules/GlobalMaster/app/Models/District.php
27:    public function state()
32:    public function cities()
```

### F13 — Deep read (all eight questions, per mutating method)

| Method | 1 overwrite? | 2 delete before replace? | 3 duplicate impl? | 4 soft-delete x unique? | 5 race? | 6 auth hole? | 7 message lies? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok — new row | ok | ok | DIST-07, DIST-08, DIST-09 | ok — no check-then-act; the DB unique index backs the name | ok — create gate + request | ok | ok |
| `update` | ok — full `validated()` row is the edit form's contract | ok | ok | DIST-07, DIST-08, DIST-09 | ok | ok — update gate + request | ok | ok |
| `destroy` | ok — sets is_active=false then soft-deletes in one transaction | ok | ok | ok | ok | ok — delete gate | ok — event `Trashed`, message says "deactivated and deleted" which is what happens | ok |
| `restore` | ok — un-deletes only; `is_active` stays false (house convention, siblings identical) | ok | ok | DIST-09 (a re-create after this trash is blocked until force-delete) | ok | ok — restore gate | ok — `restored.district` is accurate (record is back, inactive) | ok |
| `forceDelete` | ok — permanent delete + audit | ok — audit row is created fresh, not replacing data | ok | ok | ok | ok — forceDelete gate | ok | ok |
| `toggleStatus` | ok — only `is_active` from a boolean-validated input | ok | ok | ok | ok — no check-then-act | ok — update gate; the parent-state check is business logic, not auth | ok | ok — the parent-state guard is consumed by the list switch |

Deep-read verdict: no wrong-data overwrite, no delete-before-replace, no race needing a lock, no auth hole. The uniqueness drift (DIST-07/08/09) is the only deep-read defect. `restore()` leaving `is_active=false` matches the State/City/Country siblings (house convention) — recorded as accepted, not a finding.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `pgdatabase/2-DDL_Tenant_Consolidated/_global_db_v4.sql:57-59` vs live `glb_districts` | The DDL declares three unique keys; the live table has only two (`uq_glb_districts_stateId_name` and `uq_glb_districts_shortName`) and no `global_code` key. `global_code` uniqueness is enforced nowhere. | MDL-07 / DDL-wins | Schema owner — DIST-09 is the DECISION item |
| `Modules/PrimeCore/resources/views/components/table/action-trashed.blade.php` | Renders restore as a plain anchor GET link — the wiring that makes DIST-10 reachable on every geography trash screen. | RTE-01 | Shared-component owner — DIST-11 (⚠ SHARED) fixes it |
| `app/View/Components/Backend/Form/SelectCountry.php:20` | Runs `Country::where('is_active', true)->get()` on every create/edit render of the city/state/district/org forms — an unbounded dropdown query per page. | QRY-15 / F9 | Shared-component owner (this report links it, does not fix) |
| Sibling controllers `StateController`, `CountryController`, `CityController` | Same six-block try/catch, same `getMessage()` logging, same GET `restore`, same dead/lazy geography queries — the whole geography family carries DIST-01/03/10. | ERR-00, ERR-05, RTE-01 | Their own reports — module-level cross-controller family |

## 8. Not covered, and why

- **HTTP round-trips of the five blades** — no browser in this workflow (D4, no tests). Blades were read statically and proven to compile via `Blade::compileString()` (all five COMPILES).
- **The permission deny path** — a role missing `prime.global-master.district.*` was not exercised in a browser; the gates are standard `Gate::authorize`, the renderer path is common, and all seven keys are confirmed seeded in `config/permissionslist.php:215` via `$crud`.
- **`sys_activity_logs` write** — the common `activityLog()` helper was not audited (common class); only its call sites were checked for event literals and placement.
- **The soft-delete uniqueness block** — live `glb_districts` has 0 trashed rows, so the DIST-09 trap is proven by the schema (index columns) rather than a real trashed row.
- **Sibling controllers' own defects** — only usage-level checks; each has its own report (StateController pending).
