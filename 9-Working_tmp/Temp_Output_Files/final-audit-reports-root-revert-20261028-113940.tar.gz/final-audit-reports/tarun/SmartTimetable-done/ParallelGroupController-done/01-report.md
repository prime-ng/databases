# Final Audit — SmartTimetable / ParallelGroupController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php` (493 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/parallel-group` (list), `/create`, `/{id}` (detail), `/{id}/edit` |
| Menu path | Timetable Management → Parallel Groups (a card on the Smart Timetable dashboard, `TimetableMenuController`); breadcrumb parent `dashboard.timetable-management` |
| Who uses it | Any role holding a `tenant.smart-timetable.parallel-group.*` ability. Measured: **2 roles** hold each of the 7 seeded permissions (`sys_role_has_permissions_jnt`, tenant DB). |
| What a user does here | A timetable admin creates a "parallel group" — two or more activities (e.g. Class 6 Hobby: Dance / Music) that must be scheduled at the same time so students can split across them. On the detail page the admin adds member activities from the selected academic term, marks one as the anchor, and removes members. |
| Tables written | `tt_parallel_groups`, `tt_parallel_group_activity`, `sys_activity_logs` (via `activityLog()`) |
| Tables read | `tt_parallel_groups`, `tt_parallel_group_activity`, `tt_activities`, `sch_academic_term`, `sys_permissions`, pivot teacher/class/section/subject/study_format lookups |
| Live data | `test.localhost` tenant `xyz_school_00000000000040008000_202627`: `tt_parallel_groups` **0** rows (0 trashed), `tt_parallel_group_activity` **0** rows (0 trashed), `tt_activities` **0** rows. The tenant is effectively empty, so counts are 0 rather than "clean". |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready as-is, but the defects are concentrated in one method and one model. The single worst finding is **PGX-01**: because the pivot unique index `uq_pga_group_activity(parallel_group_id, activity_id)` includes soft-deleted rows, an activity that was removed and is then added back fails the insert and the user sees "The operation could not be completed." — re-adding a removed activity is impossible. **PGX-02** (the `activities()` relation ignores the pivot soft-delete column) makes removed activities still appear as members. **PGX-03** silently forces both boolean checkboxes back to `true` when the admin unticks them, so a group can never be created or edited with "Hard Constraint" off. The rest is conventional debt (hand-rolled controller `try/catch` per D1, no route-model binding, duplicated dropdown loaders, view buttons missing `@can`). Rough effort to clear the plan: **M** (about one focused day).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 3 | 5 | 7 | 1 | 15 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PGX-04 | F8 Services/Jobs | clean (none referenced) |
| F2 Transactions/Audit | PGX-04 | F9 Queries/Perf | PGX-01, PGX-05, PGX-08, PGX-12, PGX-13 |
| F3 Authorization | PGX-10 | F10 Views | PGX-14 |
| F4 Validation | PGX-03, PGX-09 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | PGX-15 |
| F6 Controller shape | PGX-06, PGX-07, PGX-11 | F13 Deep read | PGX-01, PGX-03, PGX-05 |
| F7 Models | PGX-02 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php` | controller | 493 | this report | ✅ |
| 2 | `Modules/SmartTimetable/app/Http/Requests/StoreParallelGroupRequest.php` | form request | 66 | this report | ✅ |
| 3 | `Modules/SmartTimetable/app/Http/Requests/UpdateParallelGroupRequest.php` | form request | 71 | this report | ✅ |
| 4 | `Modules/SmartTimetable/app/Http/Requests/AddActivitiesToParallelGroupRequest.php` | form request | 29 | this report | ✅ |
| 5 | `Modules/SmartTimetable/app/Models/ParallelGroup.php` | model | 146 | this report (pre-assigned) | ✅ |
| 6 | `Modules/SmartTimetable/app/Models/ParallelGroupActivity.php` | model | 40 | this report (pre-assigned) | ✅ |
| 7 | `Modules/TimetableFoundation/app/Models/Activity.php` | model | 345 | ↗ `tarun/TimetableFoundation/ActivityController` (registry `_Info/00-CLASS-OWNERS.md` line 10) | ↗ linked |
| 8 | `Modules/TimetableFoundation/app/Models/AcademicTerm.php` | model | 133 | ↗ `tarun/TimetableFoundation/AcademicTermController` (registry line 9) | ↗ linked |
| 9 | `Modules/SmartTimetable/resources/views/parallel-group/index.blade.php` | view | 148 | this report | ✅ |
| 10 | `Modules/SmartTimetable/resources/views/parallel-group/create.blade.php` | view | 204 | this report | ✅ |
| 11 | `Modules/SmartTimetable/resources/views/parallel-group/edit.blade.php` | view | 195 | this report | ✅ |
| 12 | `Modules/SmartTimetable/resources/views/parallel-group/show.blade.php` | view | 320 | this report | ✅ |
| 13 | `Modules/SmartTimetable/routes/web.php` (parallel-group group, lines 26-40) | route file | common | common | referenced only |
| 14 | `database/migrations/tenant/2026_07_09_000005_create_tt_parallel_groups_table.php` | migration | 39 | read-only (never edited) | ❌ not editable |
| 15 | `database/migrations/tenant/2026_07_09_000006_create_tt_parallel_group_activity_table.php` | migration | 39 | read-only (never edited) | ❌ not editable |
| 16 | `config/permissionslist.php` (line 739) | config | common | common | referenced only |

Common and not audited here: base `App\Http\Controllers\Controller`, `App\Models\BaseModel`, `activityLog()` helper, `Illuminate` facades (`DB`, `Gate`, `Auth`, `Log`), `Modules/Prime` domain/tenancy, `app/Services/Breadcrumbs/registry.php`.

No pre-applied SmartTimetable file is named for this controller in a `PRE-APPLIED-*.md`.

## 4. Routes

```
GET|HEAD  smart-timetable/parallel-group                                  smart-timetable.parallel-group.index            ParallelGroupController@index
POST      smart-timetable/parallel-group                                  smart-timetable.parallel-group.store            ParallelGroupController@store
POST      smart-timetable/parallel-group/auto-detect                      smart-timetable.parallel-group.auto-detect      ParallelGroupController@autoDetect
GET|HEAD  smart-timetable/parallel-group/create                           smart-timetable.parallel-group.create           ParallelGroupController@create
GET|HEAD  smart-timetable/parallel-group/{parallelGroup}                  smart-timetable.parallel-group.show             ParallelGroupController@show
PUT       smart-timetable/parallel-group/{parallelGroup}                  smart-timetable.parallel-group.update           ParallelGroupController@update
DELETE    smart-timetable/parallel-group/{parallelGroup}                  smart-timetable.parallel-group.destroy          ParallelGroupController@destroy
DELETE    smart-timetable/parallel-group/{parallelGroup}/activity/{activity} smart-timetable.parallel-group.remove-activity ParallelGroupController@removeActivity
POST      smart-timetable/parallel-group/{parallelGroup}/add-activities   smart-timetable.parallel-group.add-activities   ParallelGroupController@addActivities
GET|HEAD  smart-timetable/parallel-group/{parallelGroup}/edit             smart-timetable.parallel-group.edit             ParallelGroupController@edit
POST      smart-timetable/parallel-group/{parallelGroup}/set-anchor/{activity} smart-timetable.parallel-group.set-anchor  ParallelGroupController@setAnchor
```

Unrouted public methods: none — all 11 public methods are routed. The middleware group is `['web', 'auth', EnsureTenantHasModule::class.':smart-timetable']` (`Modules/SmartTimetable/routes/web.php:27`); tenancy is initialised by the `web` group (`SetTenantAuthGuard` prepended in `bootstrap/app.php:48`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 28 | GET smart-timetable/parallel-group | `tenant.smart-timetable.parallel-group.viewAny` | none (read) | none | none | PGX-12, PGX-13 |
| `create` | 72 | GET smart-timetable/parallel-group/create | `tenant.smart-timetable.parallel-group.create` | none (read) | none | none | PGX-07 |
| `store` | 102 | POST smart-timetable/parallel-group | `tenant.smart-timetable.parallel-group.create` | controller `DB::transaction` | 'Stored' | tt_parallel_groups, sys_activity_logs | PGX-04, PGX-10 |
| `show` | 134 | GET smart-timetable/parallel-group/{parallelGroup} | `tenant.smart-timetable.parallel-group.view` | none (read) | none | none | PGX-06 |
| `edit` | 168 | GET smart-timetable/parallel-group/{parallelGroup}/edit | `tenant.smart-timetable.parallel-group.update` | none (read) | none | none | PGX-06, PGX-07 |
| `update` | 201 | PUT smart-timetable/parallel-group/{parallelGroup} | `tenant.smart-timetable.parallel-group.update` | controller | 'Updated' | tt_parallel_groups, sys_activity_logs | PGX-04, PGX-06, PGX-10 |
| `destroy` | 231 | DELETE smart-timetable/parallel-group/{parallelGroup} | `tenant.smart-timetable.parallel-group.delete` | controller | 'Trashed' | tt_parallel_groups, sys_activity_logs | PGX-04, PGX-06 |
| `addActivities` | 261 | POST smart-timetable/parallel-group/{parallelGroup}/add-activities | `tenant.smart-timetable.parallel-group.update` | controller | 'ActivitiesAdded' | tt_parallel_group_activity, sys_activity_logs | PGX-01, PGX-04, PGX-05, PGX-06, PGX-10 |
| `removeActivity` | 336 | DELETE smart-timetable/parallel-group/{parallelGroup}/activity/{activity} | `tenant.smart-timetable.parallel-group.update` | controller | 'ActivityRemoved' | tt_parallel_group_activity (soft delete), sys_activity_logs | PGX-04, PGX-06 |
| `setAnchor` | 382 | POST smart-timetable/parallel-group/{parallelGroup}/set-anchor/{activity} | `tenant.smart-timetable.parallel-group.update` | controller | 'AnchorSet' | tt_parallel_group_activity, sys_activity_logs | PGX-04, PGX-06 |
| `autoDetect` | 437 | POST smart-timetable/parallel-group/auto-detect | `tenant.smart-timetable.parallel-group.create` | none (read) | none | none | PGX-08, PGX-09 |

## 6. Findings

### F1 — Errors

#### PGX-04 · M · ERR-00 + ERR-05 + TXN-05 — six mutating methods hand-roll `try/catch` and build the HTTP response inside the transaction

| Field | Value |
|---|---|
| **Rule** | ERR-00 (D1: the Laravel idiom — no `try/catch` in a controller) + ERR-05 (M) — *log the exception, not `getMessage()`* + TXN-05 (M) — *the transaction closure returns data; build `redirect()`/`response()` after it* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:106-128`, methods `store()`, `update()`, `destroy()`, `addActivities()`, `removeActivity()`, `setAnchor()` |
| **Root cause** | Each mutation wraps the `DB::transaction()` closure in `try { … } catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { Log::error(…, ['error' => $e->getMessage()]); return …; }`. D1 settled that a controller must not carry this scaffolding — `DB::transaction()` already rolls back and rethrows, and the central handler in `bootstrap/app.php` renders the error. The `catch (\Throwable)` also builds the `redirect()`/`response()` *inside* the transaction closure (TXN-05), and the `getMessage()`-only log loses the stack trace (ERR-05). |
| **Consequence** | The deviation is copied into six methods, so any future edit repeats the pattern; a real failure is logged without a trace (harder to diagnose), and the page-specific message is generic. No current data loss: the transaction still rolls back and `ModelNotFoundException` is re-thrown. |
| **Reproduce** | static only — the handler shape is visible in source; a live failure needs a forced DB error. |
| **Fix approach** | Remove every `try/catch` and `Log::error` from the six methods; keep `DB::transaction(fn () => …)` returning the model/count and build the `redirect()`/`response()` after it (see plan PGX-04). The `ModelNotFoundException`, `Log` imports then become unused (plan PGX-15 removes them). |
| **Plan item** | PGX-04 in `02-fix-plan.md` §3 (and PGX-01 for `addActivities`) |

```php
        try {
            return DB::transaction(function () use ($request) {
                $data = $request->validated();
                $data['created_by'] = Auth::id();

                $parallelGroup = ParallelGroup::create($data);

                activityLog($parallelGroup, 'Stored', ['message' => 'ParallelGroup was stored.']);

                return redirect()
                    ->route('smart-timetable.parallel-group.show', $parallelGroup->id)
                    ->with('success', 'Parallel group created successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('ParallelGroupController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "catch (\|getMessage" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php
120:        } catch (ModelNotFoundException $e) {
124:        } catch (\Throwable $e) {
125:            Log::error('ParallelGroupController::store failed', ['error' => $e->getMessage()]);
217:        } catch (ModelNotFoundException $e) {
221:        } catch (\Throwable $e) {
222:            Log::error('ParallelGroupController::update failed', ['error' => $e->getMessage()]);
247:        } catch (ModelNotFoundException $e) {
251:        } catch (\Throwable $e) {
252:            Log::error('ParallelGroupController::destroy failed', ['error' => $e->getMessage()]);
317:        } catch (ModelNotFoundException $e) {
321:        } catch (\Throwable $e) {
322:            Log::error('ParallelGroupController::addActivities failed', ['error' => $e->getMessage()]);
362:        } catch (ModelNotFoundException $e) {
366:        } catch (\Throwable $e) {
367:            Log::error('ParallelGroupController::removeActivity failed', ['error' => $e->getMessage()]);
416:        } catch (ModelNotFoundException $e) {
420:        } catch (\Throwable $e) {
421:            Log::error('ParallelGroupController::setAnchor failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

All six mutations run their writes inside one `DB::transaction` with `activityLog()` after the write and inside the closure (event literals: 'Stored', 'Updated', 'Trashed', 'ActivitiesAdded', 'ActivityRemoved', 'AnchorSet'). The only F2 defect is TXN-05, folded into PGX-04 — the closure builds and returns the `redirect()`/`response()` instead of returning the model/count.

**Evidence** — clean for TXN-01/TXN-04:
```
$ grep -n "DB::transaction\|activityLog" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php
107:            return DB::transaction(function () use ($request) {
113:                activityLog($parallelGroup, 'Stored', ['message' => 'ParallelGroup was stored.']);
206:            return DB::transaction(function () use ($request, $id) {
210:                activityLog($parallelGroup, 'Updated', ['message' => 'ParallelGroup was updated.']);
236:            return DB::transaction(function () use ($id) {
240:                activityLog($parallelGroup, 'Trashed', ['message' => 'ParallelGroup was trashed.']);
266:            return DB::transaction(function () use ($request, $id) {
302:                    activityLog($parallelGroup, 'ActivitiesAdded', [
341:            return DB::transaction(function () use ($groupId, $activityId) {
351:                activityLog($parallelGroup, 'ActivityRemoved', [
387:            return DB::transaction(function () use ($groupId, $activityId) {
404:                activityLog($parallelGroup, 'AnchorSet', [
```

### F3 — Authorization

Every routed method authorizes before loading a record (AUTH-01 satisfied). The only F3 defect is AUTH-04 (PGX-10): `store`, `update` and `addActivities` each run the same permission twice — the FormRequest's `authorize()` (which runs first) and a redundant `Gate::authorize()`.

**Evidence**
```
$ grep -n "Gate::authorize" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php
30:        Gate::authorize('tenant.smart-timetable.parallel-group.viewAny');
74:        Gate::authorize('tenant.smart-timetable.parallel-group.create');
104:        Gate::authorize('tenant.smart-timetable.parallel-group.create');
136:        Gate::authorize('tenant.smart-timetable.parallel-group.view');
170:        Gate::authorize('tenant.smart-timetable.parallel-group.update');
203:        Gate::authorize('tenant.smart-timetable.parallel-group.update');
233:        Gate::authorize('tenant.smart-timetable.parallel-group.delete');
263:        Gate::authorize('tenant.smart-timetable.parallel-group.update');
338:        Gate::authorize('tenant.smart-timetable.parallel-group.update');
384:        Gate::authorize('tenant.smart-timetable.parallel-group.update');
439:        Gate::authorize('tenant.smart-timetable.parallel-group.create');
```

#### PGX-10 · L · AUTH-04 — `store`/`update`/`addActivities` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:104`, `:203`, `:263`, methods `store()`, `update()`, `addActivities()` |
| **Root cause** | `StoreParallelGroupRequest::authorize()` already returns `auth()->user()->can('tenant.smart-timetable.parallel-group.create')` (`StoreParallelGroupRequest.php:12`) and runs before the controller; the controller then repeats the check with `Gate::authorize('…create')`. The same duplication exists for `update` and `addActivities`. |
| **Consequence** | Dead code: the second check can never change the outcome, and a future permission rename must be kept in sync in two places. No user-visible effect. |
| **Reproduce** | static only — both checks are in source; the FormRequest always runs first. |
| **Fix approach** | Drop the redundant `Gate::authorize()` in `store`, `update`, `addActivities`; the FormRequest `authorize()` keeps the guard. Resolved as part of the plan PGX-04 and PGX-01 rewrites. |
| **Plan item** | none — see plan §10 (resolved within PGX-04 / PGX-01) |

```php
    public function store(StoreParallelGroupRequest $request)
    {
        Gate::authorize('tenant.smart-timetable.parallel-group.create');
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php | grep AUTH-04
L  AUTH-04  Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:102  store — StoreParallelGroupRequest::authorize() and Gate::authorize both check
L  AUTH-04  Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:201  update — UpdateParallelGroupRequest::authorize() and Gate::authorize both check
L  AUTH-04  Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:261  addActivities — AddActivitiesToParallelGroupRequest::authorize() and Gate::authorize both check
```

### F4 — Validation and input

Validation largely lives in the three FormRequests (`store`, `update`, `addActivities`), with typed rules and `validated()` used correctly. Two defects: the boolean normalisation forces unticked checkboxes to `true` (PGX-03), and `autoDetect` validates inline (PGX-09).

#### PGX-03 · H · VAL-05 — an unticked `is_hard_constraint` / `is_active` checkbox is forced back to `true`

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M, raised to H — it silently persists the opposite of what the admin chose, on a normal create/edit path) — *every field is typed; a write path must not normalise input into a wrong value* |
| **Where** | `Modules/SmartTimetable/app/Http/Requests/StoreParallelGroupRequest.php:44-52` and `Modules/SmartTimetable/app/Http/Requests/UpdateParallelGroupRequest.php:49-57`, method `prepareForValidation()` |
| **Root cause** | The merge uses `$this->has('is_hard_constraint') ? $this->boolean('is_hard_constraint') : true`. An HTML checkbox that is unticked is simply **absent** from the request, so `has()` is false and the field is set to `true`. There is no way to submit `false` for either field. |
| **Consequence** | A timetable admin who unticks "Hard Constraint" (or "Active") on create or edit still gets a hard-constraint / active group. On edit, opening a soft-constraint group and saving silently upgrades it to hard. |
| **Reproduce** | Open `/smart-timetable/parallel-group/create`, untick "Hard Constraint", submit; the created group shows "Hard Constraint". Same on any `/edit`. |
| **Fix approach** | Drop the `has()` guard and use `$this->boolean('is_hard_constraint')` / `$this->boolean('is_active')` — an absent checkbox then becomes `false`, matching the browser. |
| **Plan item** | PGX-03 in `02-fix-plan.md` §1 |

```php
    protected function prepareForValidation(): void
    {
        $this->merge([
            'requires_same_teacher' => $this->boolean('requires_same_teacher'),
            'requires_same_room_type' => $this->boolean('requires_same_room_type'),
            'is_hard_constraint' => $this->has('is_hard_constraint') ? $this->boolean('is_hard_constraint') : true,
            'is_active' => $this->has('is_active') ? $this->boolean('is_active') : true,
        ]);
    }
```

**Evidence**
```
$ grep -n "has('is_hard_constraint')\|has('is_active')" Modules/SmartTimetable/app/Http/Requests/StoreParallelGroupRequest.php Modules/SmartTimetable/app/Http/Requests/UpdateParallelGroupRequest.php
Modules/SmartTimetable/app/Http/Requests/StoreParallelGroupRequest.php:49:            'is_hard_constraint' => $this->has('is_hard_constraint') ? $this->boolean('is_hard_constraint') : true,
Modules/SmartTimetable/app/Http/Requests/StoreParallelGroupRequest.php:50:            'is_active' => $this->has('is_active') ? $this->boolean('is_active') : true,
Modules/SmartTimetable/app/Http/Requests/UpdateParallelGroupRequest.php:54:            'is_hard_constraint' => $this->has('is_hard_constraint') ? $this->boolean('is_hard_constraint') : true,
Modules/SmartTimetable/app/Http/Requests/UpdateParallelGroupRequest.php:55:            'is_active' => $this->has('is_active') ? $this->boolean('is_active') : true,
```

#### PGX-09 · M · VAL-02 — `autoDetect` validates inline instead of in a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request, not inline `$request->validate()` — except a one-field AJAX toggle* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:437-443`, method `autoDetect()` |
| **Root cause** | `autoDetect()` calls `$request->validate(['academic_term_id' => 'required|integer|exists:tt_academic_terms,id'])` in the controller and separately runs `Gate::authorize`. Every other write/read method uses a FormRequest. |
| **Consequence** | The project's single place to look for validation (the Requests folder) does not contain this rule, so a future `academic_term_id` change can be missed; the method also repeats the authorization. |
| **Reproduce** | static only — call `POST /smart-timetable/parallel-group/auto-detect` without `academic_term_id`; it 302s back with a validation error produced inline. |
| **Fix approach** | Add `AutoDetectParallelGroupsRequest` (rules + `authorize()` for `…parallel-group.create`), type-hint it into `autoDetect()`, drop the inline `validate()` and the redundant `Gate::authorize`. |
| **Plan item** | PGX-09 in `02-fix-plan.md` §5 |

```php
        $request->validate([
            'academic_term_id' => 'required|integer|exists:tt_academic_terms,id',
        ]);
```

**Evidence**
```
$ grep -n "request->validate" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php
441:        $request->validate([
```

### F5 — Routes

clean — every public method is routed (all 11), no state change over GET, custom routes (`/create`, `/auto-detect`) are registered before the `/{parallelGroup}` wildcard, and the group sits inside `web` + `auth` + `EnsureTenantHasModule::class.':smart-timetable'` (tenancy initialised by the `web` group). Evidence:
```
$ grep -n "Route::" Modules/SmartTimetable/routes/web.php | sed -n '1,14p'
26:Route::prefix('smart-timetable/parallel-group')->name('smart-timetable.parallel-group.')
27:    ->middleware(['web', 'auth', EnsureTenantHasModule::class.':smart-timetable'])
29:        Route::get('/', [ParallelGroupController::class, 'index'])->name('index');
30:        Route::get('/create', [ParallelGroupController::class, 'create'])->name('create');
31:        Route::post('/', [ParallelGroupController::class, 'store'])->name('store');
32:        Route::post('/auto-detect', [ParallelGroupController::class, 'autoDetect'])->name('auto-detect');
33:        Route::get('/{parallelGroup}', [ParallelGroupController::class, 'show'])->name('show');
```

### F6 — Controller shape

Size is fine (493 lines, 11 methods — under the 1,000-line / 25-method CTL-01 threshold; longest method `addActivities` is ~71 lines, under 80). Defects: no route-model binding (PGX-06), duplicated dropdown loaders (PGX-07), no return types (PGX-11). No debug leftovers — clean.

#### PGX-06 · M · CTL-03 — no route-model binding; methods take `$id`/`$groupId`/`$activityId` and call `findOrFail()`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route-model binding (`show(Homework $homework)`), not `$id` + `findOrFail`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:134`, `:168`, `:201`, `:231`, `:261`, `:336`, `:382`, methods `show()`, `edit()`, `update()`, `destroy()`, `addActivities()`, `removeActivity()`, `setAnchor()` |
| **Root cause** | The routes declare `{parallelGroup}` and `{activity}` but the controller methods accept untyped `$id`/`$groupId`/`$activityId`; Laravel passes the route values positionally and each method re-queries with `findOrFail()`. (It works, but binding is not used and the parameter names disagree with the route.) |
| **Consequence** | Seven methods repeat the same lookup; a rename of the route parameter silently keeps working by position, hiding the mismatch, and each call is a separate query that binding would do as part of resolution. |
| **Reproduce** | static only — signatures and route parameter names are in source. |
| **Fix approach** | Type-hint `ParallelGroup $parallelGroup` / `Activity $activity` and drop `findOrFail()`; the route parameter names already match. `show`/`edit` in plan PGX-06; the mutation methods adopt binding inside the PGX-04 / PGX-01 rewrites. |
| **Plan item** | PGX-06 in `02-fix-plan.md` §5 |

```php
        $parallelGroup = ParallelGroup::with([
            'academicTerm',
            'activities.class',
            'activities.section',
            'activities.subject',
            'activities.studyFormat',
            'activities.teachers',
        ])->findOrFail($id);
```

**Evidence**
```
$ grep -n "findOrFail" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php
145:        ])->findOrFail($id);
172:        $parallelGroup = ParallelGroup::findOrFail($id);
207:                $parallelGroup = ParallelGroup::findOrFail($id);
237:                $parallelGroup = ParallelGroup::findOrFail($id);
267:                $parallelGroup = ParallelGroup::findOrFail($id);
342:                $parallelGroup = ParallelGroup::findOrFail($groupId);
388:                $parallelGroup = ParallelGroup::findOrFail($groupId);
```

#### PGX-07 · M · CTL-05 — the group-type / coordination-type dropdown arrays and the term loader are copy-pasted across `index`, `create`, `edit`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: dropdown loaders shared by `create`/`edit`, the same payload repeated* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:52-60`, `:76-90`, `:174-188`, methods `index()`, `create()`, `edit()` |
| **Root cause** | The 5-entry `$groupTypes` array is written three times (`:54`, `:78`, `:176`), `$coordinationTypes` twice (`:86`, `:184`), and `AcademicTerm::active()->orderByDesc('id')->get()` three times (`:52`, `:76`, `:174`). The `ParallelGroup` model already owns `getGroupTypeLabel()`, so the labels are duplicated in a third place. |
| **Consequence** | Adding or renaming a group type means editing three controller blocks (and the model), and any miss leaves the filter dropdown and the forms disagreeing. |
| **Reproduce** | static only — identical literals visible at the three line ranges. |
| **Fix approach** | Extract three private helpers on the controller (`activeAcademicTerms()`, `groupTypes()`, `coordinationTypes()`) and call them from `index`, `create`, `edit`. |
| **Plan item** | PGX-07 in `02-fix-plan.md` §5 |

```php
        $groupTypes = [
            'PARALLEL_SECTION' => 'Section Parallel',
            'PARALLEL_OPTIONAL' => 'Optional Subject',
            'PARALLEL_SKILL' => 'Skill Subject',
            'PARALLEL_HOBBY' => 'Hobby',
            'PARALLEL_CUSTOM' => 'Custom',
        ];
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php | grep CTL-05
M  CTL-05   Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:54  - — identical 5-item array literal repeated 3× (lines 54,78,176)
```

#### PGX-11 · L · CTL-04 — public methods carry no return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:28-437`, all 11 public methods |
| **Root cause** | Every method is declared `public function name(...)` with no `:` return type. |
| **Consequence** | IDE and static analysis cannot infer the response shape; a method changed to return the wrong type is not caught until runtime. |
| **Reproduce** | static only — signatures in source. |
| **Fix approach** | Add return types where each method is rewritten (PGX-04, PGX-06, PGX-09) and to `index`/`create` (`: View`) for the rest. |
| **Plan item** | none — see plan §10 (adopted inside PGX-04/06/09; the two remaining reads are style-only) |

```php
    public function index(Request $request)
```

**Evidence**
```
$ grep -nE "public function [a-zA-Z_]+\(" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php
28:    public function index(Request $request)
72:    public function create()
102:    public function store(StoreParallelGroupRequest $request)
134:    public function show($id)
168:    public function edit($id)
201:    public function update(UpdateParallelGroupRequest $request, $id)
231:    public function destroy($id)
261:    public function addActivities(AddActivitiesToParallelGroupRequest $request, $id)
336:    public function removeActivity($groupId, $activityId)
382:    public function setAnchor($groupId, $activityId)
437:    public function autoDetect(Request $request)
```

### F7 — Models

Both owned models are clean on `$fillable`, `$casts` (all booleans/ints/dates covered) and `$table` (both tables exist in the tenant migrations). One defect: `activities()` ignores the pivot soft-delete column (PGX-02). `scopeActive`/`scopeByType`/`scopeForTerm` lack return types — folded into the style item PGX-15.

#### PGX-02 · H · MDL-03 — `activities()` belongs-to-many over the soft-deleting pivot never filters `deleted_at`, so removed activities still count as members

| Field | Value |
|---|---|
| **Rule** | MDL-03 (H) — *a `belongsToMany` over a pivot table that has `deleted_at` must add `->wherePivotNull('deleted_at')`, or removed rows still count as members* |
| **Where** | `Modules/SmartTimetable/app/Models/ParallelGroup.php:59-69`, method `activities()` |
| **Root cause** | `tt_parallel_group_activity` has `deleted_at` (migration `2026_07_09_000006` line 19; `ParallelGroupActivity` uses `SoftDeletes`). The `belongsToMany` chain uses `withPivot(...)`, `withTimestamps()`, `orderByPivot(...)` but omits `wherePivotNull('deleted_at')`, so the relation includes soft-deleted pivot rows. |
| **Consequence** | After an admin removes an activity from a group, the detail page still lists it as a member and the index's `withCount('activities')` badge still counts it. The same ghost appears in `getAnchorActivity()`, `getMemberActivities()` and `hasAnchor()`, which all build on `activities()`. |
| **Reproduce** | Open a group's detail page, remove an activity; it disappears in the DOM until reload, then reappears and the "Member Activities" badge is unchanged. |
| **Fix approach** | Add `->wherePivotNull('deleted_at')` to the `activities()` relation; the three helper methods inherit it. |
| **Plan item** | PGX-02 in `02-fix-plan.md` §1 |

```php
    public function activities(): BelongsToMany
    {
        return $this->belongsToMany(
            Activity::class,
            'tt_parallel_group_activity',
            'parallel_group_id',
            'activity_id'
        )->withPivot(['sequence_order', 'is_anchor', 'is_active'])
         ->withTimestamps()
         ->orderByPivot('sequence_order');
    }
```

**Evidence**
```
$ grep -n -e "belongsToMany" -e "wherePivotNull" -e "withPivot" Modules/SmartTimetable/app/Models/ParallelGroup.php
61:        return $this->belongsToMany(
66:        )->withPivot(['sequence_order', 'is_anchor', 'is_active'])
```

### F8 — Services and jobs

clean — the controller injects no service, dispatches no job and uses no cache. Evidence:
```
$ grep -nE "Service|Job|dispatch|Cache::|Notification" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php
(no output)
```

### F9 — Queries and performance

The list paginates (with `withQueryString()`), `show()` eager-loads every relation it renders, and `availableActivities` is filtered by term. Defects: the soft-delete re-add trap (PGX-01), the per-activity loop in `addActivities` (PGX-05), and two lower-priority items (PGX-12, PGX-13). PGX-08 (PHP-side grouping in `autoDetect`) is recorded as informational in plan §10.

#### PGX-01 · H · VAL-04 — removing an activity and re-adding it fails because the pivot unique index includes soft-deleted rows

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness must mirror the DB unique index including soft-delete semantics; a unique index that includes trashed rows plus a check using `whereNull('deleted_at')` = a 500 on re-create* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:276-297`, method `addActivities()` |
| **Root cause** | `tt_parallel_group_activity` has `UNIQUE (parallel_group_id, activity_id)` named `uq_pga_group_activity` **without** `deleted_at` (migration `2026_07_09_000006:29`). `removeActivity()` soft-deletes the pivot row. `addActivities()`'s guard skips only rows **live** rows (`->whereNull('deleted_at')->exists()`), so when the activity is re-added the guard reports "not present" and `ParallelGroupActivity::create()` tries to insert a second row for the same `(group, activity)`, violating the unique index. |
| **Consequence** | A timetable admin who removes an activity by mistake cannot add it back; the request hits the generic catch and the UI shows "The operation could not be completed." The soft-deleted row also stays in the member list (see PGX-02). |
| **Reproduce** | Open a group's detail page, remove a member activity, then select the same activity again and press "Add Selected" — the AJAX response is `{"success":false,"message":"The operation could not be completed."}` with HTTP 500. |
| **Fix approach** | In `addActivities()`, look up the pivot **including trashed** rows (`withTrashed()`); if a trashed row exists, `restore()` it and update `sequence_order`/`is_anchor`; only `insert()` when no row exists at all. (A schema alternative is a DECISION — see plan §9.) |
| **Plan item** | PGX-01 in `02-fix-plan.md` §9 (DECISION) |

```php
                foreach ($activityIds as $activityId) {
                    // Skip if already in group
                    $exists = ParallelGroupActivity::where('parallel_group_id', $parallelGroup->id)
                        ->where('activity_id', $activityId)
                        ->whereNull('deleted_at')
                        ->exists();

                    if ($exists) {
                        $skipped++;
                        continue;
                    }

                    $maxOrder++;
                    ParallelGroupActivity::create([
                        'parallel_group_id' => $parallelGroup->id,
                        'activity_id' => $activityId,
                        'sequence_order' => $maxOrder,
                        'is_anchor' => false,
                        'is_active' => true,
                    ]);
                    $added++;
                }
```

**Evidence**
```
$ php artisan tinker --execute '$d=\Modules\Prime\Models\Domain::where("domain","test.localhost")->first(); tenancy()->initialize($d->tenant); $r=DB::select("SHOW INDEX FROM tt_parallel_group_activity"); foreach($r as $i){ echo $i->Key_name." uniq=".$i->Non_unique." col=".$i->Column_name.PHP_EOL; }'
PRIMARY uniq=0 col=id
uq_pga_group_activity uniq=0 col=parallel_group_id
uq_pga_group_activity uniq=0 col=activity_id
idx_pga_group uniq=1 col=parallel_group_id
idx_pga_activity uniq=1 col=activity_id
```

#### PGX-05 · M · QRY-01 + QRY-07 — `addActivities` runs one `exists()` query and one `create()` per selected activity

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H, lowered to M — the loop is bounded by the multi-select on one screen) — *no queries inside loops* + QRY-07 (M) — *bulk writes* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:276-297`, method `addActivities()` |
| **Root cause** | For every `activity_id` the method issues `ParallelGroupActivity::where(...)->exists()` then, if new, `ParallelGroupActivity::create([...])`. N selected activities = up to N `SELECT` + N `INSERT` statements inside one transaction. |
| **Consequence** | Selecting all activities of a term makes the "Add Selected" button slow and holds the transaction open longer; the repeated insert statements also enlarge the binary log for no reason. |
| **Reproduce** | static only — the two calls are inside `foreach` at `:278` and `:289`; the loop is driven by the multi-select `activity_ids[]`. |
| **Fix approach** | Pre-fetch the group's pivot rows once (`withTrashed()->get()->keyBy('activity_id')`), then compute the inserts in PHP and write them with a single `ParallelGroupActivity::insert()` (and a single `restore()` update for trashed rows). Covered by the plan PGX-01 rewrite. |
| **Plan item** | none — see plan §10 (covered by PGX-01 option (a)) |

```php
                    $exists = ParallelGroupActivity::where('parallel_group_id', $parallelGroup->id)
                        ->where('activity_id', $activityId)
                        ->whereNull('deleted_at')
                        ->exists();
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php | grep QRY
H  QRY-01   Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:278  addActivities — ParallelGroupActivity::where() inside a loop — N+1 query
M  QRY-07   Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:289  addActivities — ParallelGroupActivity::create() inside a loop — bulk insert/upsert/whereIn->update
```

#### PGX-08 · L · QRY-05 — `autoDetect` loads every term activity and groups/filters in PHP

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M, lowered to L — the `get()` is filtered to one academic term, a few hundred rows, not a whole table) — *aggregate in SQL, not `->get()->groupBy()`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:448-460`, method `autoDetect()` |
| **Root cause** | `Activity::with(...)->where('academic_term_id', $termId)->…->get()->groupBy(...)->filter(...)` pulls all matching activities into memory and does the "≥ 2 distinct sections" test in PHP. |
| **Consequence** | Extra memory and PHP work on each auto-detect call; acceptable at current term sizes, so it is not a blocker. |
| **Reproduce** | static only — `->get()` at `:452` precedes `->groupBy()` at `:453`. |
| **Fix approach** | Optional refactor: add a `GROUP BY class_id, study_format_id HAVING COUNT(DISTINCT section_id) >= 2` sub-query to restrict the fetch. Recorded as informational; not required to ship. |
| **Plan item** | none — see plan §10 |

```php
        $candidates = Activity::with(['class', 'section', 'subject', 'studyFormat'])
            ->where('academic_term_id', $termId)
            ->where('is_active', true)
            ->whereNotNull('study_format_id')
            ->get()
            ->groupBy(function ($activity) {
                return $activity->class_id . '_' . $activity->study_format_id;
            })
            ->filter(function ($group) {
                // Only keep groups that span at least 2 different sections
                return $group->pluck('section_id')->unique()->count() >= 2;
            })
            ->values();
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php | grep QRY-05
M  QRY-05   Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:448  autoDetect — ->get()->groupBy() — filter/aggregate in SQL instead
```

#### PGX-12 · L · QRY-08 — the index search uses two leading-wildcard `LIKE` predicates

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M, lowered to L — `tt_parallel_groups` is a small table, currently 0 live rows) — *leading-wildcard `LIKE '%x%'` cannot use an index; acceptable on small tables* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:42-48`, method `index()` |
| **Root cause** | `where('name', 'like', "%{$search}%")` and the same for `code` force a full scan of the table. |
| **Consequence** | No measurable cost at current row counts; would matter only if the table grew large. |
| **Reproduce** | static only — both predicates are in the search closure. |
| **Fix approach** | Accepted for now; revisit only if `tt_parallel_groups` grows. |
| **Plan item** | none — see plan §10 |

```php
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('code', 'like', "%{$search}%");
            });
        }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php | grep QRY-08
L  QRY-08   Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:45  index — 2 leading-wildcard LIKE search(es)
```

#### PGX-13 · L · QRY-02 — the list paginates at 20, the project standard is 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M, lowered to L — cosmetic consistency, not a performance trap) — *lists are paginated; the project standard is 10 per page* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:50`, method `index()` |
| **Root cause** | `->paginate(20)` deviates from the module's `paginate(10)` convention (see `ConstraintCategoryScopeController`, `ConstraintTypeController`). |
| **Consequence** | Pages show twice as many rows as every other SmartTimetable list; harmless. |
| **Reproduce** | Open `/smart-timetable/parallel-group` — the page-size control reads 20. |
| **Fix approach** | Change `paginate(20)` to `paginate(10)`. |
| **Plan item** | PGX-13 in `02-fix-plan.md` §6 |

```php
        $parallelGroups = $query->orderByDesc('created_at')->paginate(20)->withQueryString();
```

**Evidence**
```
$ grep -n "paginate" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php
50:        $parallelGroups = $query->orderByDesc('created_at')->paginate(20)->withQueryString();
```

### F10 — Views

No Blade issues a query and no view uses `{!! !!}`. The action buttons on `index` and `show` are not wrapped in `@can`, so a view-only role sees Edit/Delete (PGX-14). The breadcrumb passes `:links="[]"` (recorded as a module-wide cross-cutting note in §7).

**Evidence**
```
$ grep -rnE "::|->where\(|->get\(\)|->count\(\)|DB::" Modules/SmartTimetable/resources/views/parallel-group/ | grep -v "@"
Modules/SmartTimetable/resources/views/parallel-group/show.blade.php:96:                    <span class="badge bg-info ms-1">{{ $parallelGroup->activities->count() }}</span>
```
(line 96 counts the already eager-loaded collection — no query.)

#### PGX-14 · L · VIEW-01 (UI standard) — row-action buttons are not gated with `@can`

| Field | Value |
|---|---|
| **Rule** | VIEW (UI standard, final-audit §6 F10) — *the view is one of the four places a permission must appear (`@can`); row actions use the shared action component* |
| **Where** | `Modules/SmartTimetable/resources/views/parallel-group/index.blade.php:107-126` and `Modules/SmartTimetable/resources/views/parallel-group/show.blade.php:26-29` |
| **Root cause** | The index renders View/Edit/Delete buttons and the detail page renders an Edit button with no `@can('tenant.smart-timetable.parallel-group.update')` / `.delete` guard. `grep` for `@can` across the four blades returns nothing. |
| **Consequence** | A user who can only view still sees Edit and Delete; clicking them is refused server-side (403) but the buttons should not render. |
| **Reproduce** | Log in as a role that has `.view`/`.viewAny` but not `.update`; open `/smart-timetable/parallel-group` — the Edit and Delete buttons are visible. |
| **Fix approach** | Wrap the Edit button in `@can('tenant.smart-timetable.parallel-group.update')`, the Delete form in `@can('…delete')`, the "New Group" link in `@can('…create')`, and the detail-page Edit link in `@can('…update')`. |
| **Plan item** | PGX-14 in `02-fix-plan.md` §7 |

```blade
                                        <td>
                                            <div class="d-flex gap-1">
                                                <a href="{{ route('smart-timetable.parallel-group.show', $group->id) }}"
                                                    class="btn btn-xs btn-outline-info" title="View">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="{{ route('smart-timetable.parallel-group.edit', $group->id) }}"
                                                    class="btn btn-xs btn-outline-primary" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form method="POST"
                                                    action="{{ route('smart-timetable.parallel-group.destroy', $group->id) }}"
                                                    onsubmit="return confirm('Delete this parallel group?')">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-xs btn-outline-danger" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
```

**Evidence**
```
$ grep -rn "@can\|permission=" Modules/SmartTimetable/resources/views/parallel-group/
(no output)
```

### F11 — Security and tenancy

clean — no `env()`, no `$request->all()`, no hard-coded ids, no secrets in logs, no personal data. `autoDetect` returns mapped arrays (not full models), and all queries run through tenant-scoped models. Evidence:
```
$ grep -nE "env\(|->all\(\)|DB::raw|whereRaw|orderByRaw" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php
(no output)
```

### F12 — Style

Everything below is **L** and grouped into one item per file. Defect: missing `declare(strict_types=1)` on all six in-scope PHP files, and an unsorted/haphazard import block on the controller (blank lines between imports, `App\…` after `Illuminate\…`). The `ModelNotFoundException` and `Log` imports become unused once PGX-04 lands. No commented-out code, no emoji.

#### PGX-15 · L · STY-01 + STY-02 — missing `strict_types`, unsorted imports, and dead imports after PGX-04

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files; old files when touched* + STY-02 (L) — *Pint-clean: sorted imports, no stray blank lines* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php:1-13`; also line 1 of `StoreParallelGroupRequest.php`, `UpdateParallelGroupRequest.php`, `AddActivitiesToParallelGroupRequest.php`, `ParallelGroup.php`, `ParallelGroupActivity.php` |
| **Root cause** | None of the six files declares `strict_types`; the controller's imports are separated by blank lines and are not alphabetically ordered (`App\Http\Controllers\Controller` sits after the `Illuminate` lines). `ModelNotFoundException` and `Log` are used only by the catch blocks removed in PGX-04. |
| **Consequence** | Style-only; `vendor/bin/pint --format agent` would still reformat the imports on next edit, and the unused imports are dead weight. |
| **Reproduce** | static only — `grep -rn "^declare(strict_types=1)"` over the six files returns nothing. |
| **Fix approach** | Add `declare(strict_types=1);` after `<?php` in all six files; on the controller, drop `ModelNotFoundException` and `Log` and sort the remaining imports. Apply only after PGX-04 (the imports are still used until then). |
| **Plan item** | PGX-15 in `02-fix-plan.md` §8 |

```php
use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\DB;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
```

**Evidence**
```
$ grep -rl "^declare(strict_types=1)" Modules/SmartTimetable/app/Http/Controllers/ParallelGroupController.php Modules/SmartTimetable/app/Http/Requests/StoreParallelGroupRequest.php Modules/SmartTimetable/app/Http/Requests/UpdateParallelGroupRequest.php Modules/SmartTimetable/app/Http/Requests/AddActivitiesToParallelGroupRequest.php Modules/SmartTimetable/app/Models/ParallelGroup.php Modules/SmartTimetable/app/Models/ParallelGroupActivity.php
(no output)
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong overwrite | 2 Delete before store | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | PGX-07 | ok | ok | PGX-10 | ok | ok |
| `update` | ok | ok | PGX-07 | ok | ok | PGX-10 | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `addActivities` | ok | ok | PGX-05 | PGX-01 | PGX-05 | PGX-10 | ok | ok |
| `removeActivity` | ok | ok | ok | ok | ok | ok | ok | ok |
| `setAnchor` | ok | ok | ok | ok | ok | ok | ok | ok |

Notes: (1) `setAnchor` clears all anchors before setting one by design, inside the transaction — no partial state. (8) the feature is consumed: `TimetableGenerationService` reads `tt_parallel_groups`, so it is not a dead screen. (5) the `exists()`-then-`create()` race is caught by the unique index, but that same index is what makes PGX-01 fail on re-add.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/TimetableFoundation/app/Models/Activity.php` | Audited by `tarun/TimetableFoundation/ActivityController`; this report only checked how it is used (`class`/`section`/`subject`/`studyFormat`/`teachers` relations all resolve, eager-loaded correctly by `show`/`autoDetect`). | — | `ActivityController` report |
| `Modules/TimetableFoundation/app/Models/AcademicTerm.php` | Audited by `tarun/TimetableFoundation/AcademicTermController`; `scopeActive()` exists and is used correctly. | — | `AcademicTermController` report |
| `x-backend.components.breadcrum` + every `parallel-group/*.blade.php` | All four blades pass `:links="[]"`, so no page carries a breadcrumb trail. Module-wide convention across all 72 SmartTimetable views, not this controller's defect. | VIEW (UI standard) | SmartTimetable views pass |
| `config/permissionslist.php:739` | `smart-timetable.parallel-group => $crud` is correct; all 7 abilities (`viewAny/view/create/update/delete/restore/forceDelete`) are seeded in the tenant DB with exact names. | — | no action |
| `database/migrations/tenant/2026_07_09_000006…` | The `uq_pga_group_activity` unique index includes soft-deleted pivot rows. Never edit an existing migration; the fix lives in the controller (PGX-01) or an additive migration (PGX-01 option (b)). | VAL-04 | this plan, §9 |

## 8. Not covered, and why

- **No request was executed** (D4 — no tests, no HTTP). Findings are from source, scanner rows, `php -l`, `route:list` and read-only `SELECT`/`SHOW`; the reproduce steps were not clicked.
- **The tenant DB is empty** (`tt_parallel_groups` 0, `tt_parallel_group_activity` 0, `tt_activities` 0), so no live row sample could confirm the PGX-01 500 — the mechanism is proven from the `SHOW INDEX` output plus the source, not from a live insert.
- **Blades were not rendered** — they were read and grepped; no `blade.compiler()` compile check was run for this report.
- **No queue, job, event, mail or notification** is referenced, so F8 is "none referenced" rather than "exercised".
- **`TimetableGenerationService`** (the consumer of parallel groups) was not audited — it belongs to `TimetableGenerationController`.
