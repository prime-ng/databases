# Final Audit — SmartTimetable / TimetablePublishController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php` (184 lines, 2 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `POST /smart-timetable/timetable/{id}/publish` and `POST /smart-timetable/timetable/{id}/unpublish` (JSON-only, called by `fetch()` from the publish list) |
| Menu path | View & Refinement → Publish Timetable |
| Who uses it | Super Admin and School Admin. The gate string `tenant.smart-timetable.timetable.update` is permission id 1643 on `test.localhost`, granted to exactly those two roles (`sys_role_has_permissions_jnt`). |
| What a user does here | On the Publish Timetable list the user clicks Publish on a row. A complete timetable goes live immediately (status PUBLISHED, `published_at`/`published_by` stamped, every other live timetable in the same scope archived). An incomplete one first answers "not complete, publish anyway?"; a second request with `confirm=1` publishes it and records that the completeness gate was bypassed. Unpublish reverts a row to DRAFT. |
| Tables written | `tt_timetables` (UPDATE — status/published_at/published_by/is_active, and ARCHIVED on the other in-scope rows) and `sys_activity_logs` (INSERT via the `activityLog()` helper). |
| Tables read | `tt_timetables`, `tt_activities`, `tt_timetable_cells` (both via `TimetableReadiness`). |
| Live data | `tt_timetables` 0 rows (0 published, 0 archived, 0 draft, 0 generated, 0 trashed); `tt_activities` 0; `tt_timetable_cells` 0; `sys_activity_logs` 396. The tenant `xyz_school_00000000000040008000_202627` holds no timetables today, so the write path cannot be exercised in the browser. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready while TPB-01 stands. The publish/unpublish AJAX endpoints return the raw exception text to the browser on any failure, so a database error shows the user SQL and table names; the same catch blocks also violate D1 (no try/catch in controllers) and lose the stack trace. The single worst finding is TPB-01 (B). Two further high-value items: the publish path takes no row lock and no status guard (TPB-04, H — concurrent publishes can archive the live timetable), and `TimetableReadiness::assert()` throws `RuntimeException` where D2 requires `\DomainException` (TPB-08). Everything else is idiomatic debt (route model binding, method length) and style. The files are small and the fixes are contained; rough effort S-M.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 1 | 5 | 1 | 2 | 8 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TPB-01, TPB-02, TPB-03, TPB-08 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | TPB-04 | F9 Queries/Perf | clean |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | TPB-07 |
| F6 Controller shape | TPB-05, TPB-06 | F13 Deep read | see table |
| F7 Models | clean (linked) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php` | controller | 184 | this report | ✅ |
| 2 | `Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php` | service | 127 | this report (claimed 2026-10-10) | ✅ |
| 3 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | 516 | ↗ [TimetableFoundation/TimetableController](../../TimetableFoundation-done/TimetableController-done/01-report.md) | ↗ linked |
| 4 | `app/Helpers/activityLog.php` | helper | 51 | common (app/) | ↗ common |
| 5 | `Modules/SmartTimetable/resources/views/pages/partials/view-and-refinement/publish-timetable/_list.blade.php` | blade (caller) | 470 | ↗ TimetableMenuController | ↗ linked |
| 6 | `Modules/SmartTimetable/routes/web.php` | route file | — | shared | ↗ common |

No pre-applied files for this module.

The controller imports `Modules\TimetableFoundation\Models\Timetable` (line 14), not the SmartTimetable model, so the SmartTimetable `Timetable` pre-assignment to AnalyticsController does not apply here. `TimetableReadiness` was unclaimed; a claim line was appended to `final-audit-reports/_Info/00-CLASS-OWNERS.md` and it is audited in full in this report.

## 4. Routes

```
POST    smart-timetable/timetable/{id}/publish                  smart-timetable.timetable.publish                  Modules\SmartTimetable\Http\Controllers\TimetablePublishController@publishTimetable
POST    smart-timetable/timetable/{id}/unpublish                smart-timetable.timetable.unpublish                Modules\SmartTimetable\Http\Controllers\TimetablePublishController@unpublishTimetable
```

Middleware (uncached, from `route:list --json`): both routes carry `web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `auth`, `verified`, `EnsureTenantHasModule:smart-timetable`. Publish additionally carries `BlockSnapshotWrites` (`snapshot.readonly`).

Unrouted public methods: none — both public methods are routed (`grep -nE 'public function'` → lines 34 and 153).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `publishTimetable` | 34 | POST smart-timetable/timetable/{id}/publish | `tenant.smart-timetable.timetable.update` | controller, `DB::transaction` at 83 | `'Published'` | tt_timetables, sys_activity_logs | TPB-01, TPB-02, TPB-03, TPB-04, TPB-05, TPB-06, TPB-07 |
| `unpublishTimetable` | 153 | POST smart-timetable/timetable/{id}/unpublish | `tenant.smart-timetable.timetable.update` | controller, `DB::transaction` at 160 | `'Unpublished'` | tt_timetables, sys_activity_logs | TPB-01, TPB-02, TPB-03, TPB-05, TPB-07 |
| `TimetableReadiness::check` | 32 | n/a (service, called at controller:49) | n/a | none (read) | none | none | — |
| `TimetableReadiness::assert` | 62 | n/a (service, no live caller) | n/a | none | none | none | TPB-08 |
| `TimetableReadiness::unplacedPeriods` | 89 | n/a (service, called at controller:49) | n/a | none (read) | none | none | — |
| `TimetableReadiness::conflictCells` | 119 | n/a (service, called at controller:49) | n/a | none (read) | none | none | — |

## 6. Findings

### F1 — Errors

#### TPB-01 · B · ERR-01 — The publish and unpublish catches return raw exception text to the browser

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user: no `$e->getMessage()` in `withErrors`, `with('error')`, `response()->json` or `back()`; SQL, table and column names leak* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:130-136`, method `publishTimetable()`, and `:173-179`, method `unpublishTimetable()` |
| **Root cause** | Both `catch (Throwable $e)` blocks interpolate `$e->getMessage()` into the JSON `message` field, and the caller blade shows that string through `alert(d.message)`; the exception text is treated as a user message. |
| **Consequence** | A failed publish shows the user a raw PDO/SQL message (table names, sometimes the statement) instead of a plain failure notice. |
| **Reproduce** | static only — no live timetable rows on `test.localhost` (`tt_timetables` = 0), so the write path cannot be triggered in the browser; the message path is proven by the quoted lines and the caller's `alert(d.message)`. |
| **Fix approach** | Delete both controller try/catch blocks (D1, the Laravel idiom). `DB::transaction` rolls back by itself and the central handler in `bootstrap/app.php` already returns `{success:false,message}` for JSON callers, with the message generic in production. |
| **Plan item** | TPB-01 in `02-fix-plan.md` §1 |

```php
        } catch (Throwable $e) {
            Log::error('Timetable publish failed', ['timetable_id' => $id, 'error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to publish timetable: '.$e->getMessage(),
            ], 500);
        }
```

**Evidence**
```
$ grep -n "getMessage" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php
131:            Log::error('Timetable publish failed', ['timetable_id' => $id, 'error' => $e->getMessage()]);
135:                'message' => 'Failed to publish timetable: '.$e->getMessage(),
174:            Log::error('Timetable unpublish failed', ['timetable_id' => $id, 'error' => $e->getMessage()]);
178:                'message' => 'Failed to unpublish timetable: '.$e->getMessage(),
```

#### TPB-02 · M · ERR-05 — The error log records only the message, losing the stack trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:131`, method `publishTimetable()`, and `:174`, method `unpublishTimetable()` |
| **Root cause** | `Log::error(..., ['error' => $e->getMessage()])` stores a string, so the exception class, file and line are dropped before the log row is written. |
| **Consequence** | An operator debugging a failed publish gets one line with no location and cannot tell where the failure came from. |
| **Reproduce** | static only — no live timetable rows to trigger a failure. |
| **Fix approach** | Removing the catch per TPB-01 also removes this line; if a catch is ever kept, log the exception object instead of the message. |
| **Plan item** | none — see plan §10 (folded into TPB-01) |

```php
            Log::error('Timetable publish failed', ['timetable_id' => $id, 'error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "Log::error" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php
131:            Log::error('Timetable publish failed', ['timetable_id' => $id, 'error' => $e->getMessage()]);
174:            Log::error('Timetable unpublish failed', ['timetable_id' => $id, 'error' => $e->getMessage()]);
```

#### TPB-03 · M · ERR-00 — A controller try/catch is the wrong error shape under D1

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M) — *under D1 the Laravel idiom governs: no try/catch in controllers; `DB::transaction` rolls back and rethrows, and one renderer in `bootstrap/app.php` gives the friendly response* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:82` and `:130`, method `publishTimetable()`, and `:159` and `:173`, method `unpublishTimetable()` |
| **Root cause** | The methods wrap their mutation in `try { DB::transaction(...) } catch (Throwable)`, a leftover of house rule A1 which D1 replaced for modules under final audit. |
| **Consequence** | The page-specific message path is also the path that leaks the raw error (TPB-01); while it exists the 404/403/500 handling differs from the rest of the app. |
| **Reproduce** | static only — no live timetable rows. |
| **Fix approach** | Remove both try/catch blocks and keep the `DB::transaction(...)` call; the central handler renders failures. |
| **Plan item** | none — see plan §10 (folded into TPB-01) |

```php
        try {
            DB::transaction(function () use ($timetable, $readiness, $bypassed) {
```

**Evidence**
```
$ grep -nE "try \{|catch \(Throwable" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php
82:        try {
130:        } catch (Throwable $e) {
159:        try {
173:        } catch (Throwable $e) {
```

#### TPB-08 · M · ERR-01 — The service refusal throws `RuntimeException`, where D2 requires `\DomainException`

| Field | Value |
|---|---|
| **Rule** | ERR-01 (M) — *D2 sub-decision: business-rule messages use `\DomainException`, and no caller may catch `RuntimeException` because `QueryException` extends it, so the refusal must not be a bare `RuntimeException`* |
| **Where** | `Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php:70-73`, method `assert()` |
| **Root cause** | The refusal that blocks an incomplete publish throws a bare `RuntimeException`; a caller that catches `RuntimeException` to show the message would then also swallow database errors. |
| **Consequence** | A future publish caller that renders the refusal can accidentally turn a `QueryException` into a friendly "cannot be published" notice and hide a real database failure. |
| **Reproduce** | static only — `assert()` has no live caller; its only caller, `TimetableStorageService::publishTimetable()`, is not dispatched from anywhere (`grep -rn -e "->publishTimetable(" app/ Modules/` returns no call site), so the exception class cannot be observed at runtime on this tenant. |
| **Fix approach** | Throw `\DomainException` with the same message and change the `@throws` docblock and the import. |
| **Plan item** | TPB-08 in `02-fix-plan.md` §3 |

```php
        throw new RuntimeException(
            'This timetable cannot be published yet. '.implode(' ', $result['reasons'])
            .' Finish it on the editing screen, then publish.'
        );
```

**Evidence**
```
$ grep -n "RuntimeException" Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php
9:use RuntimeException;
60:     * @throws RuntimeException when the timetable is not ready
70:        throw new RuntimeException(
```

### F2 — Transactions and audit

#### TPB-04 · H · TXN-06 — Concurrent publishes can archive the live timetable (no lock, no status guard)

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index: use `lockForUpdate()` inside the transaction, or rely on a DB unique index and catch the duplicate* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:38` (resolve outside any transaction) and `:82-93` (the write and `archiveOthersInScope()`), method `publishTimetable()` |
| **Root cause** | The row is read with `findOrFail()` outside a transaction, with no `lockForUpdate()` and no check that the row is not already PUBLISHED, so two publish requests interleave: each marks its own row PUBLISHED and then archives the other, which can retire the whole scope. |
| **Consequence** | Two administrators publishing different timetables at the same time can take the school's live timetable offline entirely — both rows end up ARCHIVED and none is published. |
| **Reproduce** | static only — no live timetable rows on `test.localhost` to run two requests against. |
| **Fix approach** | Resolve and guard the row inside `DB::transaction` with `lockForUpdate()` and re-run the readiness check there (the pattern the now-dead `TimetableStorageService::publishTimetable()` used), or add a DB unique index for one published row per scope. DECISION. |
| **Plan item** | TPB-04 in `02-fix-plan.md` §9 |

```php
        Gate::authorize('tenant.smart-timetable.timetable.update');

        $timetable = Timetable::findOrFail($id);
```

**Evidence**
```
$ grep -n "lockForUpdate\|findOrFail\|archiveOthersInScope" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php
38:        $timetable = Timetable::findOrFail($id);
93:                $timetable->archiveOthersInScope();
157:        $timetable = Timetable::findOrFail($id);
```

### F3 — Authorization

clean — `grep -n "Gate::authorize" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php` → line 36 and line 155, both `Gate::authorize('tenant.smart-timetable.timetable.update')`, called before `findOrFail()`. The string is declared in `config/permissionslist.php:714` (`'smart-timetable.timetable' => array_merge($crud, ['generate'])`) and seeded on the tenant as permission id 1643 (`tenant.smart-timetable.timetable.update`), granted to Super Admin and School Admin. See §7 for the missing view-surface gate (owned by another controller).

### F4 — Validation and input

clean — the only input is `$request->boolean('confirm')` (`:50`); no `$request->all()`, `except()` or mass-assignment reaches a model anywhere — `grep -n "request()->all\|->all()\|except(" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php` → no output. A single boolean AJAX toggle needs no FormRequest (VAL-02 exception).

### F5 — Routes

clean — both writes are POST (no state change over GET), both target existing methods, both public methods are routed, the `{id}` route parameter matches the `int $id` argument, and tenancy middleware is present (`InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive` from `RouteServiceProvider::mapWebRoutes()`). Proven by the `route:list --json` output in §4.

### F6 — Controller shape

#### TPB-05 · M · CTL-03 — No route model binding; the raw id is resolved by hand

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:34` and `:38`, method `publishTimetable()`, and `:153` and `:157`, method `unpublishTimetable()` |
| **Root cause** | The route already carries `{id}`, but the method takes `int $id` and calls `Timetable::findOrFail($id)`, so the model is resolved by hand instead of injected. |
| **Consequence** | The 404 is hand-rolled and the same two-line pattern is repeated in both methods; a later change to the lookup has to be made twice. |
| **Reproduce** | static only — no live timetable rows. |
| **Fix approach** | Type-hint the existing route parameter: `publishTimetable(Timetable $id, Request $request)` and `unpublishTimetable(Timetable $id)`, deleting the `findOrFail()` lines. The route parameter keeps its name, so no route edit is needed. |
| **Plan item** | TPB-05 in `02-fix-plan.md` §5 |

```php
    public function publishTimetable(int $id, Request $request): JsonResponse
    {
        Gate::authorize('tenant.smart-timetable.timetable.update');

        $timetable = Timetable::findOrFail($id);
```

**Evidence**
```
$ grep -nE "public function (publish|unpublish)Timetable|findOrFail" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php
34:    public function publishTimetable(int $id, Request $request): JsonResponse
38:        $timetable = Timetable::findOrFail($id);
153:    public function unpublishTimetable(int $id): JsonResponse
157:        $timetable = Timetable::findOrFail($id);
```

#### TPB-06 · M · CTL-02 — `publishTimetable()` is 113 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method length: over 80 lines extract, over 150 lines is H* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:34-146`, method `publishTimetable()` |
| **Root cause** | The readiness confirmation, the transaction and both responses live in one method; most of the 113 lines are explanatory comments rather than statements. |
| **Consequence** | A method this long is harder to review and to change without disturbing the publish gate, even though its executable body is short. |
| **Reproduce** | static only — measured with the scanner (`CTL-02 ... publishTimetable() is 113 lines`). |
| **Fix approach** | DECISION: defer (the excess is comments and the method is cohesive), or extract the "not ready" response and the response-building into private methods. |
| **Plan item** | TPB-06 in `02-fix-plan.md` §9 |

```php
    public function publishTimetable(int $id, Request $request): JsonResponse
    {
        Gate::authorize('tenant.smart-timetable.timetable.update');

        $timetable = Timetable::findOrFail($id);
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php
M  CTL-02   Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:34  publishTimetable — publishTimetable() is 113 lines
M  CTL-03   Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:34  publishTimetable — publishTimetable($id) + findOrFail — use route model binding
```

### F7 — Models

clean — the controller uses `Modules\TimetableFoundation\Models\Timetable`, owned by `TimetableFoundation/TimetableController`, and is linked not re-audited. Its use here is correct: every column written (`published_at`, `published_by`, `status`, `is_active`) is in `$fillable` and cast (`published_at` → datetime, `is_active` → boolean), and `archiveOthersInScope()` exists at `Timetable.php:178` and returns `int`. The `is_active => true/false` values written here are also forced by the model's `booted()` `saving` hook (`Timetable.php:91-94`), so they agree.

### F8 — Services and jobs

clean — `TimetableReadiness` takes no HTTP call, has no writes on a read path (both queries are SELECT), and is constructor-injected into the controller (`:19`). Its raw SQL uses bindings, not interpolation.

### F9 — Queries and performance

clean — `TimetableReadiness::unplacedPeriods()` (`:91-104`) uses a `DB::select` with `?` bindings (no QRY-11 interpolation), and `conflictCells()` (`:121-125`) uses `count()` on the query builder (no `get()->count()`). The columns it reads exist on the tenant: `tt_activities.required_weekly_periods`, `tt_activities.weekly_periods`, `tt_activities.is_active`, `tt_activities.deleted_at`, `tt_timetable_cells.has_conflict`, `tt_timetable_cells.is_active`, `tt_timetable_cells.deleted_at` (verified with `SHOW COLUMNS`). Proven by `grep -nE "DB::select|has_conflict|count\(\)" Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php`.

### F10 — Views

clean — the controller renders no view: `grep -nE "view\(|@include" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php` → no output. It returns JSON only. The caller blade is not owned by this report (see §3 and §7).

### F11 — Security and tenancy

clean — no `env()`, no hard-coded ids (the `$id` comes from the route), no secrets logged, and both routes run inside the tenancy middleware group (proven in §4). The activity log writes through the tenant helper `activityLog()`, which routes to the tenant table `sys_activity_logs` when tenancy is initialized.

### F12 — Style

#### TPB-07 · L · STY-04 — Emoji markers in comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers, no commented-out code* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:41,52,64,96,104,111` and `Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php:18,23,79,85,112` |
| **Root cause** | Each warning comment opens with a pictograph marker (`⛔` or `⚠`) instead of a word. |
| **Consequence** | Style only — the files fail the house comment standard and read differently from emoji-free files. |
| **Reproduce** | static only — `grep -nE "⛔|⚠" <file>` lists every marker. |
| **Fix approach** | Replace the leading `⛔ ` with `IMPORTANT: ` and the leading `⚠ ` with `NOTE: ` on the listed lines in both files. |
| **Plan item** | TPB-07 in `02-fix-plan.md` §8 |

```php
        /*
        | ⛔ COMPLETE AND CLASH-FREE, OR NOT AT ALL.
        |
```

**Evidence**
```
$ grep -nE "⛔|⚠" Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php
Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:41:        | ⛔ COMPLETE AND CLASH-FREE, OR NOT AT ALL.
Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:52:        /* ⚠ AN INCOMPLETE TIMETABLE IS A WARNING TO CONFIRM, NOT AN ERROR TO REFUSE.
Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:64:         * ⛔ The gate is NOT gone. Without confirm=1 this still refuses, so nothing
Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:96:                 * ⛔ PUBLISHING CHANGES THE STATUS ONLY — it writes NO tt_timetable_assignments row.
Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:104:                 * ⛔ AND SINCE 2026-09-11 THERE IS NOTHING BEHIND IT. PublishedTimetable's
Modules/SmartTimetable/app/Http/Controllers/TimetablePublishController.php:111:                 * ⛔ DO NOT RE-ADD THE CALL HERE. TimetableAssignment::makeSchoolDefault() is kept,
Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php:18: * ⛔ ONE DEFINITION, SHARED BY EVERY PUBLISH PATH. There are three ways to publish
Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php:23: * ⚠ NOT A UI CONCERN. The screens should of course say why the button is refused,
Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php:79:     * ⚠ SUMMED PER ACTIVITY as max(0, required - placed), never as
Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php:85:     * ⚠ Counts cells through the ACTIVITY. A shared group's cell reaches its class
Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php:112:     * ⚠ is_active IS NOT FILTERED, and that is the point. The generator writes
```

### F13 — Deep read (answer all 8 questions for every mutating method)

Columns: 1 wrong data · 2 delete before store · 3 duplicate impls · 4 soft-delete x unique · 5 race · 6 authz hole · 7 lying message · 8 dead feature.

| Method | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|---|---|---|---|---|---|---|---|---|
| `publishTimetable` | TPB-03 | ok | TPB-05 | ok | TPB-04 | ok | ok | ok |
| `unpublishTimetable` | ok | ok | TPB-05 | ok | ok | ok | ok | TPB-03 |

- **Q1 (wrong data):** `archiveOthersInScope()` (called at `:93`) permanently sets every other live row in the scope to ARCHIVED, and `unpublishTimetable` never restores one; a published-then-unpublished pair leaves the scope with no published row. This is recorded inside TPB-03/TXN context; whether unpublish should restore the previous row is a product question, not provable from the code. Marked `⚠ UNVERIFIED — needs a product decision; the code comments treat one-published-per-scope as intended`.
- **Q3 (duplicate implementations):** the controller is now the only live publish path; `TimetableStorageService::publishTimetable()` is uncalled (see §7). TPB-05 records the repeated `int $id` + `findOrFail` shape across the two methods.
- **Q5 (race):** TPB-04.
- **Q7 (lying message):** in-scope flash/JSON text is truthful; the out-of-scope docblock that contradicts the current 200-with-confirmation behaviour is noted in §7.
- **Q8 (dead feature):** the in-scope service `assert()` has no live caller; noted in TPB-08 and §7.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php::publishTimetable()` | Uncalled dead method (`grep -rn -e "->publishTimetable(" app/ Modules/` finds no call site). The controller's own comment (`:46`) calls it "the other way in", but nothing dispatches it, so the controller is the only live publish path. | CTL-10 / SVC-04 | the report owning that service (not this one) |
| `Modules/SmartTimetable/resources/views/pages/partials/view-and-refinement/publish-timetable/_list.blade.php` | The Publish and Unpublish buttons are not wrapped in `@can('tenant.smart-timetable.timetable.update')` (no `@can`/`permission=` in the partial), so the view surface is missing and only the controller Gate stops an unauthorized click. | AUTH-01 (view surface) | TimetableMenuController report (renders `pages/view-and-refinement.blade.php:26`) |
| `Modules/SmartTimetable/app/Http/Requests/UpdateTimetableRequest.php:59` | Docblock says `TimetablePublishController::publishTimetable()` "refuses a timetable that is not complete and clash-free (422 with unplaced_periods and conflict_cells)", but the controller now answers 200 with `requires_confirmation` (changed 2026-09-07 at `:52-67`). The comment lies about the controller's status. | STY-04 | SmartTimetableController report |

## 8. Not covered, and why

- **No live publish run.** The tenant `test.localhost` holds 0 rows in `tt_timetables`, `tt_activities` and `tt_timetable_cells`, so no Publish/Unpublish request could be exercised end to end. Every **Reproduce** above is static, and every consequence is reasoned from the code plus the caller blade.
- **The snapshot copy was not run.** `Timetable::queueSnapshotRefresh()` runs after commit; with no timetable rows it never executed, so this audit does not verify the `tt_snapshot_timetables` write.
- **The caller blades were not rendered.** `_list.blade.php` was read as a consumer of the JSON, not compiled or rendered.
- **The scanner JSON was read only through `scanfilter.py`** (17 candidate rows for the two in-scope files); it was never opened directly.
- **`TimetableStorageService::publishTimetable()` was not audited** — it is not reachable from this controller; its dead status is noted in §7.
