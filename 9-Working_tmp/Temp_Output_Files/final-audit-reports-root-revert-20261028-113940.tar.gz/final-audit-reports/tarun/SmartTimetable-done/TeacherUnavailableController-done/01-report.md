# Final Audit — SmartTimetable / TeacherUnavailableController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php` (584 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/teacher-unavailable` (index), `/smart-timetable/teacher-unavailable/{id}` (show), `/smart-timetable/teacher-unavailable/{id}/edit` (edit), `/smart-timetable/teacher-unavailable/trash/view` (trash). The Add form is a dialog on the host page `/smart-timetable/constraint-engine?tab=teacher-unavailability`, rendered by `TimetableMenuController@constraintEngine`; this controller only serves the CRUD the tab calls. |
| Menu path | Smart Timetable dashboard → "Constraint Engine" → the **Teacher Unavailability** tab. |
| Who uses it | Roles holding the eight permissions = **Super Admin** (role 1) and **School Admin** (role 2), measured in `sys_role_has_permissions_jnt` on the tenant DB. |
| What a user does here | Records when a teacher cannot teach — a day, optionally a period, either recurring or across a date range — with a reason. Each rule can be switched active/inactive (AJAX), edited, soft-deleted, restored and permanently deleted. The rows are read by the solver through `AvailabilityCanvasService` and the `TEACHER_UNAVAILABLE_PERIODS` hard constraint. |
| Tables written | `tt_teacher_unavailabilities` (INSERT/UPDATE/soft-DELETE/force-DELETE/restore); `sys_activity_logs` (one row per mutation through the `activityLog()` helper, inside the same transaction). |
| Tables read | `tt_teacher_unavailabilities`, `sch_teachers` + `sys_users` (teacher dropdown and relation), `tt_constraints` (constraint dropdown and relation), `sys_permissions` (gate). |
| Live data | tenant `xyz_school_00000000000040008000_202627`: `tt_teacher_unavailabilities` = **0 live, 0 trashed**; `sch_teachers` active = 89; `tt_constraints` active = 5; `sys_activity_logs` = 396. All eight `tenant.smart-timetable.teacher-unavailable.*` permissions exist in `sys_permissions`. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is close to production-ready but not there yet. Its authorization is real and correct on every routed method, every mutating method wraps its writes in one `DB::transaction` with `activityLog()` placed correctly inside it, both FormRequests are well-built, the list and trash queries eager-load their relations, and the flash keys all resolve. It is **not production-ready** because it still carries six hand-written controller `try/catch` blocks that the settled D1 decision removes (every one logging only `$e->getMessage()`, so the stack trace is lost); because the **restore action runs over a GET URL** with no CSRF token; and because `period_no` is a JSON column cast to `integer`. The single worst finding is **TUA-04** (RTE-01, H): a link prefetcher, a crawler or an image tag can restore a trashed rule with no user intent. The second worst is **TUA-01** (ERR-00, M): all six write actions hide errors from the central handler. Rough effort for the full plan: **M**, under a day, with four DECISION items (one route verb, one route-binding rename, one JSON-cast feature, one race). No migration and no new permission is needed.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 6 | 6 | 4 | 13 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TUA-01 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | TUA-02, TUA-11 | F9 Queries/Perf | TUA-10 |
| F3 Authorization | TUA-03 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | TUA-04 | F12 Style | TUA-12, TUA-13 |
| F6 Controller shape | TUA-05, TUA-06, TUA-07 | F13 Deep read | TUA-11 |
| F7 Models | TUA-08, TUA-09 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php` | controller | 584 | this report | ✅ whole class |
| 2 | `Modules/SmartTimetable/app/Models/TeacherUnavailable.php` | model | 124 | this report (pre-assigned) | ✅ whole class |
| 3 | `Modules/SmartTimetable/app/Http/Requests/StoreTeacherUnavailableRequest.php` | FormRequest | 43 | this report (only this controller uses it) | ✅ whole class |
| 4 | `Modules/SmartTimetable/app/Http/Requests/UpdateTeacherUnavailableRequest.php` | FormRequest | 43 | this report (only this controller uses it) | ✅ whole class |
| 5 | `Modules/SmartTimetable/resources/views/teacher-unavailable/index.blade.php` | blade | 116 | this report | ✅ |
| 6 | `Modules/SmartTimetable/resources/views/teacher-unavailable/show.blade.php` | blade | 96 | this report | ✅ |
| 7 | `Modules/SmartTimetable/resources/views/teacher-unavailable/edit.blade.php` | blade | 169 | this report | ✅ |
| 8 | `Modules/SmartTimetable/resources/views/teacher-unavailable/trash.blade.php` | blade | 112 | this report | ✅ |
| 9 | `Modules/SmartTimetable/resources/views/teacher-unavailable/create.blade.php` | blade | 166 | this report | ✅ — dead, TUA-07 |
| 10 | `Modules/SmartTimetable/routes/web.php` lines 272-276 | routes | 5 | this report (usage) | ✅ |
| — | `Modules/SmartTimetable/app/Models/Constraint.php` | model | — | ↗ [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked — usage checked: `edit()` calls `Constraint::where('is_active', true)->get()`; `show`/`index` eager-load the `constraint` relation |
| — | `Modules/SchoolSetup/app/Models/Teacher.php` | model | — | common (SchoolSetup) | referenced only — `edit()` calls `Teacher::with('user')->active()->get()`; `scopeActive()` exists at line 233 |
| — | `resources/views/components/backend/table/action.blade.php`, `action-trashed.blade.php`, `status-switch.blade.php`, `card/header.blade.php`, `components/breadcrum.blade.php`, `app/Helpers/activityLog.php`, `app/Helpers/helpers.php` (`flash()`), base `Controller`, base `BaseModel` | common | — | common | referenced only |

The two FormRequests are used only by this controller and are not in `_Info/00-CLASS-OWNERS.md`, so they are audited here and not registered (§5: "a FormRequest used only by this controller is owned by this controller"). `Constraint` was pre-assigned to `ConstraintCategoryScopeController` (still CLAIMED), so it is linked, not re-audited; only this controller's use of it is checked. `AvailabilityCanvasService` and `TeacherStaffingAnalysisService` appear only in the class docblock, never in code, so they are **not** in scope and were not audited.

No in-scope file appears in a module `PRE-APPLIED-*.md`.

## 4. Routes

```
GET|HEAD smart-timetable/teacher-unavailable                     smart-timetable.teacher-unavailable.index          Modules\SmartTimetable\Http\Controllers\TeacherUnavailableController@index
POST     smart-timetable/teacher-unavailable                     smart-timetable.teacher-unavailable.store          Modules\SmartTimetable\Http\Controllers\TeacherUnavailableController@store
GET|HEAD smart-timetable/teacher-unavailable/trash/view          smart-timetable.teacher-unavailable.trashed        Modules\SmartTimetable\Http\Controllers\TeacherUnavailableController@trashedTeacherUnavailable
DELETE   smart-timetable/teacher-unavailable/{id}/force-delete   smart-timetable.teacher-unavailable.forceDelete    Modules\SmartTimetable\Http\Controllers\TeacherUnavailableController@forceDelete
GET|HEAD smart-timetable/teacher-unavailable/{id}/restore        smart-timetable.teacher-unavailable.restore        Modules\SmartTimetable\Http\Controllers\TeacherUnavailableController@restore
GET|HEAD smart-timetable/teacher-unavailable/{teacher_unavailable} smart-timetable.teacher-unavailable.show         Modules\SmartTimetable\Http\Controllers\TeacherUnavailableController@show
PUT|PATCH smart-timetable/teacher-unavailable/{teacher_unavailable} smart-timetable.teacher-unavailable.update       Modules\SmartTimetable\Http\Controllers\TeacherUnavailableController@update
DELETE   smart-timetable/teacher-unavailable/{teacher_unavailable} smart-timetable.teacher-unavailable.destroy      Modules\SmartTimetable\Http\Controllers\TeacherUnavailableController@destroy
GET|HEAD smart-timetable/teacher-unavailable/{teacher_unavailable}/edit smart-timetable.teacher-unavailable.edit   Modules\SmartTimetable\Http\Controllers\TeacherUnavailableController@edit
POST     smart-timetable/teacher-unavailable/{teacher_unavailable}/toggle-status smart-timetable.teacher-unavailable.toggleStatus Modules\SmartTimetable\Http\Controllers\TeacherUnavailableController@toggleStatus
```

Unrouted public methods: `create` at line 195 — deliberately unrouted (the resource is `->except(['create'])`) and D5-compliant: its body is `abort(403, 'The create page is retired — use the Add dialog on the Teacher Unavailability tab.')` with a `NOT ROUTED` comment. All other public methods are routed. Every route sits inside `Route::middleware(['web', 'auth', 'verified', EnsureTenantHasModule::class.':smart-timetable'])` with prefix `smart-timetable` (`Modules/SmartTimetable/routes/web.php:43-46`), so the tenant middleware is present (RTE-05 clean).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 175 | GET /smart-timetable/teacher-unavailable | `tenant.smart-timetable.teacher-unavailable.viewAny` | none — read-only | — | none | TUA-10 |
| `create` | 195 | not routed (D5 abort 403) | none | none | — | none | TUA-07 |
| `store` | 221 | POST /smart-timetable/teacher-unavailable | `...teacher-unavailable.create` (+ FormRequest `.create`) | controller | 'Stored' | tt_teacher_unavailabilities, sys_activity_logs | TUA-01, TUA-02, TUA-03, TUA-11 |
| `show` | 264 | GET /smart-timetable/teacher-unavailable/{teacher_unavailable} | `...teacher-unavailable.view` | none — read-only | — | none | TUA-05, TUA-06 |
| `edit` | 286 | GET /smart-timetable/teacher-unavailable/{teacher_unavailable}/edit | `...teacher-unavailable.update` | none — read-only | — | none | TUA-05, TUA-06 |
| `update` | 316 | PUT\|PATCH /smart-timetable/teacher-unavailable/{teacher_unavailable} | `...teacher-unavailable.update` (+ FormRequest `.update`) | controller | 'Updated' | tt_teacher_unavailabilities, sys_activity_logs | TUA-01, TUA-02, TUA-03, TUA-11 |
| `destroy` | 379 | DELETE /smart-timetable/teacher-unavailable/{teacher_unavailable} | `...teacher-unavailable.delete` | controller | 'Trashed' | tt_teacher_unavailabilities, sys_activity_logs | TUA-01, TUA-02, TUA-05, TUA-06 |
| `trashedTeacherUnavailable` | 416 | GET /smart-timetable/teacher-unavailable/trash/view | `...teacher-unavailable.viewAny` | none — read-only | — | none | — |
| `forceDelete` | 441 | DELETE /smart-timetable/teacher-unavailable/{id}/force-delete | `...teacher-unavailable.forceDelete` | controller | 'Deleted' | tt_teacher_unavailabilities, sys_activity_logs | TUA-01, TUA-02, TUA-05, TUA-06 |
| `restore` | 483 | GET /smart-timetable/teacher-unavailable/{id}/restore | `...teacher-unavailable.restore` | controller | 'Restored' | tt_teacher_unavailabilities, sys_activity_logs | TUA-01, TUA-02, TUA-04, TUA-05, TUA-06 |
| `toggleStatus` | 538 | POST /smart-timetable/teacher-unavailable/{teacher_unavailable}/toggle-status | `...teacher-unavailable.update` | controller | 'Toggled' | tt_teacher_unavailabilities, sys_activity_logs | TUA-01, TUA-02 |

Tables each mutation SHOULD touch: every mutation writes one `tt_teacher_unavailabilities` row plus one `sys_activity_logs` audit row (`activityLog()`). All six mutating methods do exactly those two, inside one `DB::transaction` — the transaction COUNT is correct (`controller-alignment.md` §6); the defects are the shape (D1) and the response placement (TXN-05), not a missing transaction.

## 6. Findings

### F1 — Errors

#### TUA-01 · M · ERR-00 (D1) + ERR-05 — six mutating actions keep a controller try/catch that logs only the message

| Field | Value |
|---|---|
| **Rule** | ERR-00 under D1 (M by project decision) — *no try/catch in controllers; `DB::transaction()` rolls back and rethrows by itself; the central handler in `bootstrap/app.php` renders errors*; ERR-05 (M) — *log the exception, not `getMessage()`*. None of the D2 shapes (a business `\DomainException`, a truncate-then-rebuild, a `SnapshotProtectionException`) is present. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php:233-255`, method `store()` (same shape at `update()`:328-363, `destroy()`:385-408, `forceDelete()`:447-468, `restore()`:489-513, `toggleStatus()`:548-582) |
| **Root cause** | Each mutating action wraps its `DB::transaction()` in `try { … } catch (Throwable $e)`, then logs `['error' => $e->getMessage()]` and returns a hand-written flash/JSON. D1 settled that controllers carry no try/catch except the D2 shapes; none of these six is a D2 shape. |
| **Consequence** | Every real DB failure is reduced to a fixed sentence and the stack trace is lost, so a failing write on the Teacher Unavailability tab cannot be diagnosed from the log; and each catch is another place the 404/403/422 class of bug can creep back in. |
| **Reproduce** | Static only — the failure needs a broken DB, which cannot be forced from the UI; the shape is verified by grep. |
| **Fix approach** | Delete the outer `try`/`catch` in all six methods, keep the `DB::transaction()` closure and its `activityLog()` call, and return the model from the closure. Build the `redirect()`/`response()` after the closure (see TUA-02). Remove the now-unused `Log` and `Throwable` imports. |
| **Plan item** | TUA-01 in `02-fix-plan.md` §3 |

```php
        try {
            return DB::transaction(function () use ($validated) {
                $teacherUnavailable = TeacherUnavailable::create($this->attributesFrom($validated));

                activityLog(
                    $teacherUnavailable,
                    'Stored',
                    ['message' => 'Teacher unavailability was created.']
                );

                return $this->backToTab()
                    ->with('success', flash('created.teacher_unavailable'));
            });
        } catch (Throwable $e) {
            Log::error('TeacherUnavailable store failed', [
                'teacher_id' => $validated['teacher_id'] ?? null,
                'error' => $e->getMessage(),
            ]);

            return back()
                ->withInput()
                ->with('error', flash('operation_failed.teacher_unavailable'));
        }
```

**Evidence**
```
$ grep -nE 'try \{|catch \(|Log::error\(' Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php
233:        try {
246:        } catch (Throwable $e) {
247:            Log::error('TeacherUnavailable store failed', [
328:        try {
354:        } catch (Throwable $e) {
355:            Log::error('TeacherUnavailable update failed', [
385:        try {
401:        } catch (Throwable $e) {
402:            Log::error('TeacherUnavailable destroy failed', [
447:        try {
461:        } catch (Throwable $e) {
462:            Log::error('TeacherUnavailable forceDelete failed', [
489:        try {
506:        } catch (Throwable $e) {
507:            Log::error('TeacherUnavailable restore failed', [
548:        try {
571:        } catch (Throwable $e) {
572:            Log::error('TeacherUnavailable toggleStatus failed', [
```

### F2 — Transactions and audit

#### TUA-02 · M · TXN-05 — all six methods build the HTTP response inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build the `redirect()` / `response()` after it* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php:549-570`, method `toggleStatus()` (same shape at `store()`:243-244, `update()`:351-352, `destroy()`:398-399, `forceDelete()`:457-459, `restore()`:502-504) |
| **Root cause** | Every closure's last expression constructs the `RedirectResponse` or `JsonResponse`, so the HTTP response object is created before the transaction has committed. |
| **Consequence** | The response is coupled to the transaction body: any later change that needs the committed model's values cannot see them, and the two idioms drift within one file. No user-visible failure today. |
| **Reproduce** | Static only — a returned `RedirectResponse` is not visible in the browser. |
| **Fix approach** | Return the model from the closure, then call `redirect()` / `response()` after `DB::transaction()` returns. Covered by the same rewrite as TUA-01. |
| **Plan item** | none — see plan §10 (folded into TUA-01) |

```php
            return DB::transaction(function () use ($request, $teacherUnavailable) {
                $teacherUnavailable->is_active = $request->boolean('is_active');

                if (! $teacherUnavailable->save()) {
                    throw new RuntimeException('Failed to persist the status change.');
                }

                activityLog(
                    $teacherUnavailable,
                    'Toggled',
                    [
                        'message' => 'Teacher unavailability status was updated.',
                        'is_active' => $teacherUnavailable->is_active,
                    ]
                );

                return response()->json([
                    'success' => true,
                    'is_active' => $teacherUnavailable->is_active,
                    'message' => flash('status_updated.teacher_unavailability'),
                ]);
            });
```

**Evidence**
```
$ grep -nE 'return DB::transaction|return \$this->backToTab|return redirect\(\)|return response\(\)->json' Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php
234:            return DB::transaction(function () use ($validated) {
243:                return $this->backToTab()
329:            return DB::transaction(function () use ($validated, $teacherUnavailable) {
351:                return $this->backToTab()
386:            return DB::transaction(function () use ($teacherUnavailable) {
398:                return $this->backToTab()
448:            return DB::transaction(function () use ($teacherUnavailable) {
457:                return redirect()
490:            return DB::transaction(function () use ($teacherUnavailable) {
502:                return redirect()
549:            return DB::transaction(function () use ($request, $teacherUnavailable) {
565:                return response()->json([
```

#### TUA-11 · M · TXN-06 — the overlap guard is a check-then-act with no lock or unique index

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M, lowered from H — single-school timetabling config screen, two writers at most) — *check-then-act needs a lock or a unique index: `exists()` then `create()`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php:106-131`, method `overlapExists()` (called by `store()`:227 and `update()`:322) |
| **Root cause** | The duplicate-overlap rule is an `->exists()` check that runs **before** the `DB::transaction` and is not repeated inside it with a lock. `tt_teacher_unavailabilities` has no unique index (verified in the DDL and the tenant schema: only `idx_tu_teacher` on `teacher_id`). Two concurrent POSTs can both read "no overlap" and both insert. |
| **Consequence** | A double-submit or two simultaneous School Admins can create two overlapping rules for the same teacher/day; the solver then double-counts the unavailability. |
| **Reproduce** | Static only — a race cannot be forced from one browser; the missing index is proved by `SHOW INDEX` below. |
| **Fix approach** | Either move the guard inside the transaction behind `lockForUpdate()`, or add a unique index (a migration, hence a DECISION). |
| **Plan item** | TUA-11 (DECISION) in `02-fix-plan.md` §9 |

```php
        return TeacherUnavailable::query()
            ->when($ignoreId !== null, fn ($q) => $q->where('id', '!=', $ignoreId))
            ->where('teacher_id', $validated['teacher_id'])
            ->where('day_of_week', $validated['day_of_week'])
            ->where(function ($q) use ($validated) {
                // No period given = a full-day rule, which only collides with another
                // full-day rule. A specific period collides with that same period AND
                // with any full-day rule already covering it.
                if (empty($validated['period_no'] ?? null)) {
                    $q->whereNull('period_no');
                } else {
                    $q->where(function ($p) use ($validated) {
                        $p->whereNull('period_no')
                            ->orWhere('period_no', $validated['period_no']);
                    });
                }
            })
            ->where('is_active', true)
            ->when(
                ! $validated['is_recurring'],
                fn ($q) => $q
                    ->where(fn ($d) => $d->whereNull('start_date')->orWhere('start_date', '<=', $validated['end_date']))
                    ->where(fn ($d) => $d->whereNull('end_date')->orWhere('end_date', '>=', $validated['start_date']))
            )
            ->exists();
    }
```

**Evidence**
```
$ php artisan tinker --execute '... SHOW INDEX FROM tt_teacher_unavailabilities ...'  (tenant xyz_school_00000000000040008000_202627)
idx_tu_teacher  teacher_id  (non_unique=1)
(no unique index on teacher_id + day_of_week + period_no)
$ grep -n "overlapExists" Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php
104:    private function overlapExists(array $validated, ?int $ignoreId = null): bool
227:        if ($this->overlapExists($validated)) {
322:        if ($this->overlapExists($validated, $teacherUnavailable->id)) {
```

### F3 — Authorization

#### TUA-03 · L · AUTH-04 — `store()` and `update()` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice; keep one check per concern* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php:221-223`, method `store()` (same at `update()`:316-318) |
| **Root cause** | `StoreTeacherUnavailableRequest::authorize()` checks `...teacher-unavailable.create` and `UpdateTeacherUnavailableRequest::authorize()` checks `...teacher-unavailable.update`; both run **before** the controller body, then the controller calls `Gate::authorize()` for the same permission again. |
| **Consequence** | The permission name is duplicated in two places, so a rename applied to one and not the other silently locks the action or leaves it half-guarded; no functional change today. |
| **Reproduce** | Static only — the FormRequest runs first and already denies; the second check is unreachable as a denial. |
| **Fix approach** | Drop the controller `Gate::authorize()` line in `store` and `update`; keep the FormRequests. Leave the `Gate::authorize()` calls in the other nine methods untouched (they have no FormRequest). |
| **Plan item** | TUA-03 in `02-fix-plan.md` §4 |

```php
    public function store(StoreTeacherUnavailableRequest $request)
    {
        Gate::authorize('tenant.smart-timetable.teacher-unavailable.create');

        $validated = $request->validated();
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php
177:        Gate::authorize('tenant.smart-timetable.teacher-unavailable.viewAny');
223:        Gate::authorize('tenant.smart-timetable.teacher-unavailable.create');
266:        Gate::authorize('tenant.smart-timetable.teacher-unavailable.view');
288:        Gate::authorize('tenant.smart-timetable.teacher-unavailable.update');
318:        Gate::authorize('tenant.smart-timetable.teacher-unavailable.update');
381:        Gate::authorize('tenant.smart-timetable.teacher-unavailable.delete');
418:        Gate::authorize('tenant.smart-timetable.teacher-unavailable.viewAny');
443:        Gate::authorize('tenant.smart-timetable.teacher-unavailable.forceDelete');
485:        Gate::authorize('tenant.smart-timetable.teacher-unavailable.restore');
540:        Gate::authorize('tenant.smart-timetable.teacher-unavailable.update');
$ grep -n "can('tenant.smart-timetable.teacher-unavailable" Modules/SmartTimetable/app/Http/Requests/StoreTeacherUnavailableRequest.php Modules/SmartTimetable/app/Http/Requests/UpdateTeacherUnavailableRequest.php
StoreTeacherUnavailableRequest.php:13:        return auth()->user()->can('tenant.smart-timetable.teacher-unavailable.create');
UpdateTeacherUnavailableRequest.php:13:        return auth()->user()->can('tenant.smart-timetable.teacher-unavailable.update');
```

### F4 — Validation and input

clean — validation lives in the two FormRequests (`StoreTeacherUnavailableRequest`, `UpdateTeacherUnavailableRequest`), never `$request->all()` or `except()` (VAL-01); `attributesFrom()` reads every optional key with `?? null` (`constraint_id`, `reason`, `period_no`, `start_date`, `end_date`), and the four booleans are always present because `prepareForValidation()` merges them (VAL-03); every field is typed — `integer`, `boolean`, `date`, `in:…` — and `start_date`/`end_date` carry `required_if:is_recurring,false` (VAL-05); there is no upload (VAL-06); the only inline `$request->validate()` is the single-field AJAX toggle in `toggleStatus():544-546`, which VAL-02 explicitly allows; `teacher_id`/`constraint_id` mirror real FK columns, and there is no unique index, so no soft-delete × unique 1062 trap (VAL-04). The duplicate-overlap rule is a DB-backed business check kept in the controller's `overlapExists()` helper rather than a FormRequest `after()` hook; it is deliberate and shared by both write paths, so it is not raised here (VAL-07 not present as a defect). Evidence: `grep -n "request->all\|->except(" <controller> <both FormRequests>` → no output.

### F5 — Routes

#### TUA-04 · H · RTE-01 — Restore runs over a GET request

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/SmartTimetable/routes/web.php:274` |
| **Root cause** | `Route::get('/teacher-unavailable/{id}/restore', …)` performs a write (un-soft-deletes the row and flips `is_active` back on) behind a GET verb. |
| **Consequence** | A browser prefetch, a crawler or an image tag can restore a trashed rule with no user intent and no CSRF token. |
| **Reproduce** | While signed in as School Admin, open `http://test.localhost:8000/smart-timetable/teacher-unavailable/1/restore` directly — it restores rule id 1. Expected: a 405 for a plain GET. |
| **Fix approach** | Change the verb. The only UI caller is `trash.blade.php:85` via the shared `x-backend.table.action-trashed` component, which reads the verb from the route itself, so changing the route needs no blade edit. This is a route change, so it is a DECISION (⚠ SHARED). |
| **Plan item** | TUA-04 (DECISION) in `02-fix-plan.md` §5 |

```php
        Route::get('/teacher-unavailable/{id}/restore', [TeacherUnavailableController::class, 'restore'])->name('teacher-unavailable.restore');
```

**Evidence**
```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); foreach($r as $x) if(str_contains($x["action"],"TeacherUnavailableController@restore")) printf("%-7s %s\n",$x["method"],$x["uri"]);'
GET|HEAD smart-timetable/teacher-unavailable/{id}/restore
```

**Rest of F5 — checked, clean:** every route points at an existing method (RTE-02); `create` is deliberately unrouted and D5-compliant (RTE-03); reads are GET and the other writes are POST/PUT/DELETE apart from TUA-04 (RTE-04); every route carries the `web, auth, verified, EnsureTenantHasModule` group (RTE-05); the custom routes are declared **after** `Route::resource` but no conflict occurs because each custom path has an extra segment, so `/{teacher_unavailable}` never captures `/trash/view`, `/{id}/restore`, `/{id}/force-delete` or `/{teacher_unavailable}/toggle-status` (RTE-06, proved by the `route:list` above).

### F6 — Controller shape

#### TUA-05 · M · CTL-03 — five methods take a raw `$id` and call `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php:264-268`, method `show()` (same at `edit()`:286-290, `destroy()`:379-383, `forceDelete()`:441-445, `restore()`:483-487) |
| **Root cause** | These five methods accept an untyped `$id` and resolve the record by hand. `update()` and `toggleStatus()` already bind `TeacherUnavailable $teacherUnavailable`. Three of the resource routes use the parameter `{teacher_unavailable}` while the method variable is `$id`, so a clean conversion means renaming the argument or the route parameter. |
| **Consequence** | More code, a hand-written `findOrFail` in five places, and a route-parameter name that does not match the controller argument; a missing id still 404s, so behaviour is correct today. |
| **Reproduce** | Static only — no user-visible difference. |
| **Fix approach** | Bind the model. Because this changes route parameter names it is a DECISION (⚠ SHARED). |
| **Plan item** | TUA-05 (DECISION) in `02-fix-plan.md` §5 |

```php
    public function show($id)
    {
        Gate::authorize('tenant.smart-timetable.teacher-unavailable.view');

        $teacherUnavailable = TeacherUnavailable::with(['teacher.user', 'constraint'])->findOrFail($id);
```

**Evidence**
```
$ grep -nE 'public function (show|edit|destroy|forceDelete|restore|update|toggleStatus)\(' Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php
264:    public function show($id)
286:    public function edit($id)
316:    public function update(UpdateTeacherUnavailableRequest $request, TeacherUnavailable $teacherUnavailable)
379:    public function destroy($id)
441:    public function forceDelete($id)
483:    public function restore($id)
538:    public function toggleStatus(Request $request, TeacherUnavailable $teacherUnavailable)
```

#### TUA-06 · L · CTL-04 — no public method declares a return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php:175-181`, method `index()` (same on all 11 public methods) |
| **Root cause** | Every action omits its return type, so the response shape of each method is documented nowhere. |
| **Consequence** | A later change that returns the wrong type (for example `back()` from a `view()` method) is caught only at runtime. |
| **Reproduce** | Static only — scanner CTL-04 fires at every method. |
| **Fix approach** | Add the response imports and type every public method. |
| **Plan item** | TUA-06 in `02-fix-plan.md` §5 |

```php
    public function index()
    {
        Gate::authorize('tenant.smart-timetable.teacher-unavailable.viewAny');

        $teacherUnavailables = TeacherUnavailable::with(['teacher.user', 'constraint'])
            ->latest()
            ->paginate(15);
```

**Evidence**
```
$ grep -cE 'public function [a-zA-Z_]+\([^)]*\)\s*:' Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php
0
```

#### TUA-07 · M · CTL-10 — the `create.blade.php` view is dead

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *dead code: unreachable code left in the tree* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php:195-204`, method `create()` (renders no view; the dead file is `Modules/SmartTimetable/resources/views/teacher-unavailable/create.blade.php`) |
| **Root cause** | `create()` aborts 403 and the route is excluded by `->except(['create'])`; the create form now lives in `resources/views/pages/partials/constraint-engine/teacher-unavailability/_create-fields.blade.php`. `create.blade.php` (166 lines) is never rendered by any route. |
| **Consequence** | A file no route can reach stays in the tree and misleads a reader into thinking the standalone create page still exists; if a future route rendered it, the blades it shares may have drifted (its header comment already says the fields were lifted into the dialog). |
| **Reproduce** | Static only — `route:list` shows no action renders the view; the create route is excluded. |
| **Fix approach** | Delete `create.blade.php` after re-proving it is unreferenced. Recorded as a cleanup, not a mechanical fix — see plan §10. |
| **Plan item** | none — see plan §10 |

```php
    public function create()
    {
        // NOT ROUTED — CE-02 (2026-09-10, Tarun). The create form is now a DIALOG on
        // /smart-timetable/constraint-engine (resources/views/pages/partials/constraint-engine/
        // teacher-unavailability/_create-modal.blade.php), and routes/web.php excludes the `create` verb so
        // Route::has() reports FALSE and no shared component renders a link here.
        //
        // Kept as abort(403) rather than deleted: a re-added route then fails loudly instead
        // of 500ing on a view that still exists.
        abort(403, 'The create page is retired — use the Add dialog on the Teacher Unavailability tab.');
```

**Evidence**
```
$ grep -rn "teacher-unavailable.index\|create" Modules/SmartTimetable/resources/views/teacher-unavailable/create.blade.php | head -1
(the file exists, 166 lines)
$ grep -rn "teacher-unavailable.create'" Modules/SmartTimetable/resources/views Modules/SmartTimetable/app | grep -v Http/Requests | grep -v Http/Controllers
Modules/SmartTimetable/resources/views/smart-timetable/partials/teacher-unavailable/_list.blade.php:42:                        <a href="{{ route('smart-timetable.teacher-unavailable.create') }}" class="btn btn-sm btn-outline-primary">
(only the old dead partial references the retired route; create.blade.php itself is rendered by nothing)
```

### F7 — Models

#### TUA-08 · M · MDL-02 — `period_no` is a JSON column cast to `integer`

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` for every boolean, date/datetime, decimal, json/array and enum column* |
| **Where** | `Modules/SmartTimetable/app/Models/TeacherUnavailable.php:38-53` |
| **Root cause** | The migration and the live tenant schema both define `period_no` as a `json` column ("if Teacher available for more then 1 or More Periods"), but the model casts it to `integer` (line 44). The FormRequest validates `period_no` as `integer|min:1` and the blade renders a single `<input type="number">`, so only one period can ever be stored. |
| **Consequence** | The documented multi-period capability is unreachable: a user cannot mark a teacher unavailable for more than one period, and any future code that writes an array to this column through the model is coerced to a scalar. This is the known BUG-TU-2, deliberately deferred in the class docblock. |
| **Reproduce** | Static only — the write path works only because an HTML form posts a string that MySQL parses as the JSON scalar; a true multi-period value has no UI. |
| **Fix approach** | Make it a real feature change (cast `array`, validation `array`, multi-select blade and the solver readers), or record the single-int behaviour as accepted. A feature change, so a DECISION. |
| **Plan item** | TUA-08 (DECISION) in `02-fix-plan.md` §5 |

```php
    protected $casts = [
        'teacher_id'                 => 'integer',
        'constraint_id'              => 'integer',
        'unavailable_for_all_days'   => 'boolean',
        'day_of_week'                => 'string',
        'unavailable_for_all_periods'=> 'boolean',
        'period_no'                  => 'integer',
        'is_recurring'               => 'boolean',
        'recurring_frequency'        => 'string',
        'start_date'                 => 'date',
        'end_date'                   => 'date',
        'is_active'                  => 'boolean',
        'created_at'                 => 'datetime',
        'updated_at'                 => 'datetime',
        'deleted_at'                 => 'datetime',
    ];
```

**Evidence**
```
$ php artisan tinker --execute '... SHOW COLUMNS FROM tt_teacher_unavailabilities ...'
period_no | json | null=YES
$ grep -n "period_no" Modules/SmartTimetable/app/Models/TeacherUnavailable.php
29:        'period_no',
44:        'period_no'                  => 'integer',
97:        return $query->where('period_no', $periodNo);
117:        return $this->unavailable_for_all_periods || is_null($this->period_no);
```

#### TUA-09 · L · MDL-04 — the model's two relationships have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`)* |
| **Where** | `Modules/SmartTimetable/app/Models/TeacherUnavailable.php:69-77` |
| **Root cause** | `teacher()` and `constraint()` both lack a return type; the base model and siblings in the module declare them. |
| **Consequence** | Low: an editor cannot see the relation type, and a wrong relation class is caught only at runtime. The relations themselves resolve (`teacher()->getRelated()` = `Teacher`, `constraint()->getRelated()` = `Constraint`, proved in tinker). |
| **Reproduce** | Static only. |
| **Fix approach** | Add `: BelongsTo` to both and import the relation class. |
| **Plan item** | TUA-09 in `02-fix-plan.md` §5 |

```php
    public function teacher()
    {
        return $this->belongsTo(Teacher::class, 'teacher_id');
    }

    public function constraint()
    {
        return $this->belongsTo(Constraint::class, 'constraint_id');
    }
```

**Evidence**
```
$ grep -nE 'public function (teacher|constraint)\(' Modules/SmartTimetable/app/Models/TeacherUnavailable.php
69:    public function teacher()
74:    public function constraint()
$ php artisan tinker --execute '...' (tenant xyz_school_00000000000040008000_202627)
teacher-rel=Modules\SchoolSetup\Models\Teacher
constraint-rel=Modules\SmartTimetable\Models\Constraint
```

**Rest of F7 — checked, clean:** `$table = 'tt_teacher_unavailabilities'` exists in `database/migrations/tenant/2026_06_16_152614_create_tt_teacher_unavailable_table.php` and in the live tenant schema (MDL-07); `$fillable` is declared and holds no sensitive column (MDL-01); `$casts` covers every boolean and date and all three timestamps — the only gap is `period_no` (TUA-08, MDL-02); `SoftDeletes` matches the table's `deleted_at` (MDL-05 not applicable — no media); every boolean/date cast in the DDL has a matching cast (MDL-03 n/a — no pivot).

### F8 — Services and jobs

clean — this controller injects no service and dispatches no job; all work is in the controller and the model. `grep -nE 'Service|Job|dispatch|event\(' Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php` → only the class-docblock mention of `AvailabilityCanvasService`, no code use.

### F9 — Queries and performance

#### TUA-10 · L · QRY-02 — the index list paginates at 15, not the house standard of 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M default, lowered to L — the list is short and the difference is cosmetic) / final-audit F9 — *lists paginate at 10, with a distinct `pageName` per list (C12)* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php:179-181`, method `index()` |
| **Root cause** | `index()` calls `->paginate(15)` while the trash list at line 423 calls `->paginate(10)`; the project page size is 10 (`screen-readiness-audit.md` C12). |
| **Consequence** | Cosmetic: the index renders 15 rows where the rest of the product renders 10. |
| **Reproduce** | Open `http://test.localhost:8000/smart-timetable/teacher-unavailable` with more than 10 rows and count rows per page. |
| **Fix approach** | Change `paginate(15)` to `paginate(10)`, matching `trashedTeacherUnavailable()`. |
| **Plan item** | TUA-10 in `02-fix-plan.md` §6 |

```php
        $teacherUnavailables = TeacherUnavailable::with(['teacher.user', 'constraint'])
            ->latest()
            ->paginate(15);
```

**Evidence**
```
$ grep -n "paginate(" Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php
181:            ->paginate(15);
423:            ->paginate(10);
```

**Rest of F9 — checked, clean:** both list queries eager-load the relations their blades read — `index()` loads `['teacher.user', 'constraint']` (used at `index.blade.php:29`), `trashedTeacherUnavailable()` loads `['teacher.user']` (used at `trash.blade.php:29`) — so no N+1 (`with()` proved by `grep -n "with(\["` → lines 179 and 421); `edit()` loads two bounded dropdowns (`Teacher::with('user')->active()->get()` = 89 rows, `Constraint::where('is_active', true)->get()` = 5 rows); `overlapExists()` uses `->exists()` not `->get()->count()`; no raw SQL, no query in a loop.

### F10 — Views

clean — no queries in any rendered Blade: `grep -nE 'Model::|DB::|->where\(|->get\(|->count\(|\{!!' Modules/SmartTimetable/resources/views/teacher-unavailable/index.blade.php Modules/SmartTimetable/resources/views/teacher-unavailable/show.blade.php Modules/SmartTimetable/resources/views/teacher-unavailable/edit.blade.php Modules/SmartTimetable/resources/views/teacher-unavailable/trash.blade.php` → no output. `show.blade.php` and `trash.blade.php` use the `teacher.user` and `constraint` relations, both eager-loaded by the controller. Row actions use `x-backend.table.action` / `x-backend.table.action-trashed`; status uses `x-backend.table.status-switch` with `permission="tenant.smart-timetable.teacher-unavailable.update"`. The only view-level issue is the dead `create.blade.php`, counted as TUA-07.

### F11 — Security and tenancy

clean — no `env()`, no hard-coded ids or `?? 1`, no secrets logged (`grep -nE 'env\(|\?\? 1' Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php` → no output); every method authorizes before loading the record (AUTH-02); the eight permission names exist in `config/permissionslist.php:731` (`'smart-timetable.teacher-unavailable' => array_merge($crud, ['export'])`) and are **seeded** in the tenant DB to Super Admin and School Admin with the exact names (`sys_permissions` ids 1651-1658; this makes the class-docblock BUG-TU-7 — "None of the smart-timetable.* permissions exist in the tenant DB" — stale, see §7). No cache is used, so no tenant cache-key risk.

### F12 — Style

#### TUA-12 · L · STY-01 + STY-04 — the controller has no `declare(strict_types=1)` and carries emoji markers in comments

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files*; STY-04 (L) — *comments in English, no emoji markers* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php:1-3` |
| **Root cause** | The file opens with `<?php` and jumps straight to the namespace, and five docblocks carry a `⚠` marker (lines 40, 139, 279, 521, 532). |
| **Consequence** | Silent type coercion stays on for this file, and the emoji markers are inconsistent with the plain-English comment standard; low impact, no behaviour change. |
| **Reproduce** | Static only — `head`/`grep` of the file. |
| **Fix approach** | Add the declaration after the opening tag and replace each `⚠ ` prefix with a plain word. |
| **Plan item** | TUA-12 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SmartTimetable\Http\Controllers;
```

**Evidence**
```
$ grep -c "declare(strict_types" Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php
0
$ grep -nP '[\x{26A0}\x{26D4}]' Modules/SmartTimetable/app/Http/Controllers/TeacherUnavailableController.php
40: * ⚠ findOrFail() is deliberately called OUTSIDE every try block. Wrapping it would
139:     * ⚠ start_date / end_date are FORCED to null for a recurring rule. A recurring
279:     * ⚠ The teacher dropdown MUST NOT filter on is_active. sch_teachers has no such
521:     * ⚠ The activityLog call MUST stay AFTER save(). It previously ran BEFORE, so a
532:     * ⚠ The flash resource token here is 'teacher_unavailability', not
```

#### TUA-13 · L · STY-01 — the model has no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files* |
| **Where** | `Modules/SmartTimetable/app/Models/TeacherUnavailable.php:1-3` |
| **Root cause** | The model file opens with `<?php` and has no strict-types declaration. |
| **Consequence** | Type coercion stays silent for the model's casts and helpers; low impact but inconsistent with both FormRequests, which already declare it. |
| **Reproduce** | Static only — `head` of the file. |
| **Fix approach** | Add the declaration after the opening tag. |
| **Plan item** | TUA-13 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SmartTimetable\Models;
```

**Evidence**
```
$ grep -c "declare(strict_types" Modules/SmartTimetable/app/Models/TeacherUnavailable.php
0
```

**Rest of F12 — checked:** camelCase variables, one import per class, no commented-out code, no `extract()` and no `compact()` over 15 variables (`compact('teacherUnavailables')`, `compact('teacherUnavailable')` only, in `edit()` a four-item `compact`), flash text through `flash()` keys.

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Overwrite | 2 Delete-first | 3 Dup impl | 4 Soft-del × unique | 5 Race | 6 Auth hole | 7 Lying msg | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | n/a | ok | ok | TUA-11 | ok | ok | ok |
| `update` | ok | n/a | ok | ok | TUA-11 | ok | ok | ok |
| `destroy` | ok — sets `is_active=false` then soft-deletes | n/a | ok | ok | ok | ok | ok | ok |
| `forceDelete` | ok | ok — no child FK references the table | ok | n/a | ok | ok | ok | ok |
| `restore` | ok — restores then sets `is_active=true` | n/a | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | n/a | ok | n/a | ok | ok | ok | ok |

Notes: **wrong data** — `update()` writes only the validated payload, and `attributesFrom()` forces `start_date`/`end_date` to null for a recurring rule so a stale date cannot silently exclude it from the solver; **irreversible order** — no file or row is deleted before its replacement; the `forceDelete` child-FK probe returned zero referencing rows, so it cannot orphan anything; **duplicate implementations** — the overlap guard and the attribute map were already extracted into `overlapExists()` and `attributesFrom()`, so `store` and `update` cannot drift; **messages** — every flash resolves through `config/flash.php` (all keys exist) and none carries exception text; **dead feature** — the `period_no` multi-period capability (TUA-08) is unreachable from the UI, and the `create.blade.php` view (TUA-07) is dead.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SmartTimetable/resources/views/smart-timetable/partials/teacher-unavailable/_list.blade.php:42` | The old partial still calls `route('smart-timetable.teacher-unavailable.create')`, but the `create` route is excluded by `->except(['create'])`, so rendering it throws `RouteNotFoundException`. The live tab partial is under `pages/partials/constraint-engine/`; this file appears dead. | RTE-02 / VIEW | the `TimetableMenuController` / SmartTimetable views pass |
| `resources/views/components/backend/table/action-trashed.blade.php` | Every SmartTimetable trash screen drives restore through this component; changing the restore verb in TUA-04 needs no edit here because the component reads the verb from the route itself. | — | this report (usage checked) |
| All `teacher-unavailable/*.blade.php` | Each passes `:links="[]"` to `x-backend.components.breadcrum`, so no page carries a breadcrumb trail. Module-wide convention, not this controller's defect. | VIEW (UI standard) | SmartTimetable views pass |
| `TeacherUnavailableController` class docblock, lines 79-81 | BUG-TU-7 claims "None of the smart-timetable.* permissions exist in the tenant DB, so every Gate::authorize below currently passes only via the Super Admin Gate::before bypass." On the test tenant all eight permissions are seeded to Super Admin and School Admin, so the claim is stale. Informational; the seeder has been run. | — | documentation pass |

## 8. Not covered, and why

- The pages were not opened in a browser; no server was run for this read-only audit (D4 forbids tests).
- The AJAX `toggleStatus` response was not exercised live — the test tenant has 0 rows, so the switch has nothing to toggle; the method's shape was read statically.
- `AvailabilityCanvasService` and `TeacherStaffingAnalysisService` are named only in the class docblock and are not referenced by this controller, so they are out of scope (D7: scope is everything the controller uses). They were not registered or audited.
- `Modules/SmartTimetable/app/Models/Constraint.php` and `Modules/SchoolSetup/app/Models/Teacher.php` are owned elsewhere / common; this report checked only how this controller and its model use them.
- The constraint-engine host page (`TimetableMenuController@constraintEngine`) and its tab partials, including `pages/partials/constraint-engine/teacher-unavailability/*`, are a different controller's scope and were not audited here.
- No queue job or scheduled task is dispatched by this controller, so the JOB family had nothing to check.
