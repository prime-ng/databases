# Final Audit — SmartTimetable / TimetableWorkspaceController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php` (255 lines, 2 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/preview/{timetable}` (the workspace page) and `http://test.localhost:8000/smart-timetable/workspace/{timetable}/grid?class_section_id=N` (the JSON the class picker fetches) |
| Menu path | No dedicated `glb_menus` row. The page is reached through the route name `smart-timetable.timetable.preview`, which is referenced from eleven places (five blades including one in Modules/Dashboard, and three controller redirects). |
| Who uses it | The two roles that hold `tenant.smart-timetable.timetable.view` (permission id 1641): Super Admin (role 1) and School Admin (role 2), measured in `sys_role_has_permissions_jnt`. |
| What a user does here | A timetabler opens a timetable's editing workspace. The page paints the first class-section's weekly grid on the left (activities) and beside it (days by periods); a Vue app then lets them switch class-section without a page reload. The actual drag, drop, remove and lock writes are NOT in this controller — they live in `TimetablePreviewController`. This controller only renders the workspace shell and serves the per-class grid payload that the client swaps in. |
| Tables written | none — this controller and its two services only read. (The grid it draws is edited through `TimetablePreviewController`.) |
| Tables read | `sch_class_section_jnt`, `sch_classes`, `sch_sections`, `sch_rooms`, `sch_teachers`, `sch_teacher_profiles`, `sys_users`, `tt_timetables`, `tt_timetable_cells`, `tt_timetable_cell_teachers`, `tt_activities`, `tt_sub_activities`, `tt_sub_activity_members`, `tt_class_requirement_subgroups`, `sch_class_groups_jnt`, `tt_class_timetable_types_jnt`, `tt_period_set_periods_jnt`, `sch_subjects`, `tt_teacher_assignment_roles`, `tt_school_days` |
| Live data | `sch_class_section_jnt` 43 · `sch_classes` 15 · `sch_sections` 8 · `sch_rooms` 68 · `sch_teachers` 89 · `tt_timetables` 0 · `tt_timetable_cells` 0 · `tt_activities` 0 · `tt_period_set_periods_jnt` 0 · `sys_activity_logs` 396. There is **no timetable on this tenant**, so the workspace cannot be rendered with real data here. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Not production-ready. 1 high, 5 medium.** The single worst finding is **TWK-01**: `grid()` wraps its `ClassSection::findOrFail()` in a `catch (\Throwable)`. A soft-deleted class-section passes the `exists` validation rule (the rule reads the raw table) but is excluded by the model's global soft-delete scope, so `findOrFail()` throws `ModelNotFoundException`; the catch swallows it and the endpoint answers a hand-built JSON 500 instead of a 404. The same catch is also banned by D1 (no try/catch in a controller) and logs only `$e->getMessage()`, losing the trace. The remaining findings are maintainability: two giant service methods (238 and 344 lines), a service-locator call in a service, a duplicated grid loader, an in-PHP sort, and style debt. Nothing here can corrupt data (the controller is read-only); rough effort for the plan is **S** to **M** (under a day), with three DECISION items that need a choice first.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 5 | 3 | 3 | 9 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TWK-01 | F8 Services/Jobs | TWK-05, TWK-06 |
| F2 Transactions/Audit | clean — see evidence in the family section | F9 Queries/Perf | TWK-07 |
| F3 Authorization | TWK-02 | F10 Views | clean — see evidence in the family section |
| F4 Validation | TWK-03 | F11 Security/Tenancy | clean — see evidence in the family section |
| F5 Routes | clean — see evidence in the family section | F12 Style | TWK-08, TWK-09 |
| F6 Controller shape | TWK-04 | F13 Deep read | answers in the family section (no mutations) |
| F7 Models | linked — usage checked | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php` | controller | 255 | this report | ✅ whole class |
| 2 | `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php` | service | 776 | this report (claim appended to `_Info/00-CLASS-OWNERS.md`) | ✅ whole class |
| 3 | `Modules/SmartTimetable/app/Services/Workspace/WorkspaceGridState.php` | service | 385 | this report (claim appended to `_Info/00-CLASS-OWNERS.md`) | ✅ whole class |
| 4 | `Modules/SmartTimetable/resources/views/workspace/index.blade.php` | blade | 2367 | this report | ✅ whole file |
| 5 | `Modules/SmartTimetable/resources/views/workspace/partials/_insights-body.blade.php` | blade | 107 | this report | ✅ whole file |
| 6 | `Modules/SmartTimetable/routes/web.php` lines 82-105 | routes | — | this report | ✅ |
| 7 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | 516 | ↗ [tarun/TimetableFoundation/TimetableController](../../TimetableFoundation-done/TimetableController-done/01-report.md) | ↗ linked — usage checked (route binding + `id`, `name`, `status`, `isSnapshot()`, `period_set_id`, `academic_term_id`, `timetable_type_id`) |
| 8 | `Modules/SmartTimetable/app/Models/Timetable.php` | model | 11 | ↗ [tarun/SmartTimetable/AnalyticsController](../AnalyticsController-done/01-report.md) | ↗ linked — **not used by this controller** (the import resolves to the TimetableFoundation model, row 7) |
| 9 | `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php` | service | 619 | ↗ [tarun/SmartTimetable/TimetablePreviewController](../TimetablePreviewController-done/01-report.md) (CLAIMED, may not be finished) | ↗ linked — usage checked (`classGroupIdsFor()`, `classSubgroupIdsFor()` read methods only) |
| 10 | `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | support | — | ↗ [tarun/StandardTimetable/StandardTimetableController-done](../../StandardTimetable-done/StandardTimetableController-done/01-report.md) | ↗ linked — usage checked (`t()` table-name resolver) |
| 11 | `Modules/TimetableFoundation/app/Models/Activity.php` | model | — | ↗ [tarun/TimetableFoundation/ActivityController](../../TimetableFoundation-done/ActivityController-done/01-report.md) | ↗ linked — read only |
| 12 | `Modules/TimetableFoundation/app/Models/TimetableCell.php` | model | — | ↗ [tarun/TimetableFoundation/TimetableController](../../TimetableFoundation-done/TimetableController-done/01-report.md) | ↗ linked — read only |
| 13 | `Modules/TimetableFoundation/app/Models/SchoolDay.php` | model | — | ↗ [tarun/TimetableFoundation/SchoolDayController](../../TimetableFoundation-done/SchoolDayController-done/01-report.md) | ↗ linked — read only |
| 14 | `Modules/TimetableFoundation/app/Models/PeriodSet.php` | model | — | ↗ [tarun/TimetableFoundation/PeriodSetController](../../TimetableFoundation-done/PeriodSetController-done/01-report.md) | ↗ linked — read only |
| 15 | `Modules/TimetableFoundation/app/Models/ClassTimetableType.php` | model | — | ↗ [tarun/TimetableFoundation/ClassTimetableTypeController](../../TimetableFoundation-done/ClassTimetableTypeController-done/01-report.md) | ↗ linked — read only |
| 16 | `Modules/TimetableFoundation/app/Http/Middleware/BlockSnapshotWrites.php` | middleware | — | not claimed | referenced only (one class constant read by WorkspaceGridState) |
| 17 | `Modules/SchoolSetup/**` models (`ClassSection`, `Room`, `Teacher`, `TeacherProfile`) | models | — | common | referenced only |

No in-scope file appears in a module `PRE-APPLIED-*.md`.

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json 2>/dev/null | php -r 'filter TimetableWorkspaceController@'
GET|HEAD smart-timetable/preview/{timetable}          smart-timetable.timetable.preview         Modules\SmartTimetable\Http\Controllers\TimetableWorkspaceController@workspace
GET|HEAD smart-timetable/workspace/{timetable}/grid   smart-timetable.timetable.workspace.grid  Modules\SmartTimetable\Http\Controllers\TimetableWorkspaceController@grid
```

Middleware on both routes (uncached `route:list --json`): `web`, `Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains`, `Stancl\Tenancy\Middleware\InitializeTenancyByDomain`, `App\Http\Middleware\EnsureTenantIsActive`, `Illuminate\Auth\Middleware\Authenticate`, `Illuminate\Auth\Middleware\EnsureEmailIsVerified`, `App\Http\Middleware\EnsureTenantHasModule:smart-timetable`, `Modules\TimetableFoundation\Http\Middleware\EnterTimetableSnapshot` (the `snapshot.read` alias). Both routes are GET and only read, so RTE-01 does not apply. Route parameter `{timetable}` matches the `Timetable $timetable` argument on both methods (RTE-03/CTL-03 satisfied).

Unrouted public methods: none. `route:list` covers both public actions; the only other `public function` is the constructor (`TimetableWorkspaceController.php:56`), which is not an action.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `workspace` (controller) | 65 | GET /smart-timetable/preview/{timetable} | `tenant.smart-timetable.timetable.view` | none — read-only | — | none | TWK-02 |
| `grid` (controller) | 117 | GET /smart-timetable/workspace/{timetable}/grid | `tenant.smart-timetable.timetable.view` | none — read-only | — | none | TWK-01, TWK-02, TWK-03 |
| `selectableClassSections` (controller, private) | 196 | not routed (helper) | inherited from caller | none | — | none | TWK-07 |
| `classOptions` (controller, private) | 217 | not routed (helper) | inherited from caller | none | — | none | — |
| `resolveClassSection` (controller, private) | 239 | not routed (helper) | inherited from caller | none | — | none | — |
| `build` (WorkspaceContext) | 68 | called by both actions | n/a (service) | none | — | none | TWK-04, TWK-05, TWK-06 |
| `legalityMaps` (WorkspaceContext, private) | 316 | called by `build` | n/a (service) | none | — | none | TWK-04 |
| `outstandingByClassSection` (WorkspaceContext) | 430 | called by `classOptions` | n/a (service) | none | — | none | TWK-05 |
| `sharedRequirements` (WorkspaceContext) | 489 | called by `build` and `outstandingByClassSection` | n/a (service) | none | — | none | TWK-05 |
| `sharedSlotInfo` (WorkspaceContext, private) | 563 | called by `build` | n/a (service) | none | — | none | — |
| `teacherLoadMap` (WorkspaceContext, private) | 622 | called by `build` | n/a (service) | none | — | none | — |
| `periodSetIdForClassSection` (WorkspaceContext, private) | 702 | called by `build` | n/a (service) | none | — | none | — |
| `widestPeriodSetIdForType` (WorkspaceContext, private) | 727 | called by `build` | n/a (service) | none | — | none | — |
| `periodBlockReason` (WorkspaceContext, private) | 760 | called by `build` | n/a (service) | none | — | none | — |
| `transform` (WorkspaceGridState) | 31 | called by both actions | n/a (service) | none | — | none | TWK-04 |
| `build` (WorkspaceGridState) | 381 | not called by this controller | n/a (service) | none | — | none | TWK-04 |

The controller is read-only: no method writes any table, opens a transaction, or calls `activityLog()`.

## 6. Findings

### F1 — Errors

#### TWK-01 · H · ERR-02 — the grid catch swallows a 404 and breaks D1

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500*; D1/ERR-00 also bans a controller try/catch (no D2 shape applies here), and ERR-05 (M) — *log the exception object, not `getMessage()`, which loses the trace*. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php:125-169`, method `grid()`. |
| **Root cause** | The `ClassSection::findOrFail()` call sits **inside** the `try`. The preceding `exists:sch_class_section_jnt,id` rule reads the raw table, so a **soft-deleted** class-section passes validation; `findOrFail()` then applies the model's `SoftDeletes` global scope, finds nothing, and throws `ModelNotFoundException`. The generic `catch (\Throwable $e)` swallows it and replaces the framework's 404 with a hand-built 500 JSON body. The same catch is not one of the two D2-allowed shapes, so it is also a D1 violation, and it logs only `$e->getMessage()`. |
| **Consequence** | A user who opens (or whose client requests) a class-section that has since been deleted sees the generic message "Could not load that class. Please try again." as a 500 error instead of a 404, and the failure is logged as an application error with no stack trace. |
| **Reproduce** | Sign in as School Admin, soft-delete any row of `sch_class_section_jnt`, then call `GET /smart-timetable/workspace/1/grid?class_section_id=<that id>`. Expected 404; actual 500 JSON `{"success":false,"message":"Could not load that class. Please try again."}`. |
| **Fix approach** | Delete the `try`/`catch` entirely (D1). Call `findOrFail()` directly so the framework returns the 404, and remove the now-unused `Log` import. The central handler in `bootstrap/app.php` renders JSON for an AJAX request. |
| **Plan item** | TWK-01 in `02-fix-plan.md` §3 |

```php
        try {
            $classSection = ClassSection::with(['class', 'section'])
                ->findOrFail($validated['class_section_id']);

            $ctx = $this->context->build($timetable, $classSection);
            $gridState = $this->gridState->transform($ctx);

            return response()->json([
                'success' => true,
                'grid_state' => $gridState,

                // Refreshed on every switch so the flags stay true as work is done
                // elsewhere in the timetable — one extra ~8 ms query.
                'class_options' => $this->classOptions($this->selectableClassSections(), $timetable),

                /*
                | ⚠ SAME KEY SHAPE the client's applyInsights() already reads
                | ({ insights: { html, teacher_load } }), so the panel refreshes on a class
                | switch with no client change.
                |
                | It does NOT refresh after a drop: place / remove / move return no insights
                | key, and applyInsights() no-ops when it is absent. The toolbar's placed
                | count IS live — Vue computes that from the grid — so the number people
                | watch stays honest. Wiring live insights means changing three shared write
                | endpoints, which is deliberately out of this screen's scope.
                */
                'insights' => [
                    'html' => view('smarttimetable::workspace.partials._insights-body', [
                        'gs' => $gridState,
                    ])->render(),
                    'teacher_load' => $gridState['teacher_loads'],
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('Workspace grid load failed', [
                'timetable_id' => $timetable->id,
                'class_section_id' => $validated['class_section_id'],
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Could not load that class. Please try again.',
            ], 500);
        }
```

**Evidence**
```
$ grep -nE 'try \{|\} catch \(|getMessage|Facades\\Log' Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php
12:use Illuminate\Support\Facades\Log;
125:        try {
158:        } catch (\Throwable $e) {
162:                'error' => $e->getMessage(),
$ php artisan tinker --execute '...tenancy()->initialize(...); SHOW COLUMNS FROM sch_class_section_jnt LIKE "deleted_at"'
deleted_at  timestamp NULL
```

### F2 — Transactions and audit

clean — this controller and its two services are read-only. `grep -nE 'DB::transaction|activityLog|->create\(|->update\(|->delete\(|->save\(|insert\(' Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php Modules/SmartTimetable/app/Services/Workspace/WorkspaceGridState.php` → no output.

### F3 — Authorization

#### TWK-02 · M · AUTH-02 — the bound timetable is loaded before `Gate::authorize` runs

| Field | Value |
|---|---|
| **Rule** | AUTH-02 (H, lowered one notch to M — the permission is global, login is already required, and the only leak is an id-existence oracle) — *authorize first, before loading records; loading first leaks whether an id exists (404 vs 403)*. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php:65-67` (method `workspace()`) and `:117-119` (method `grid()`). |
| **Root cause** | Both methods type-hint `Timetable $timetable`, so Laravel's implicit route-model binding resolves `{timetable}` in the `SubstituteBindings` step of the `web` middleware group — before the controller body and before `Gate::authorize()` runs. An id whose row is missing throws a 404 at binding time; an id whose row exists reaches the gate and returns a 403. |
| **Consequence** | A signed-in user whose role lacks `tenant.smart-timetable.timetable.view` can tell an existing timetable id from a missing one by the status code (403 versus 404), even though the permission check is correct in every other respect. |
| **Reproduce** | Sign in as a role without the permission and open `/smart-timetable/preview/1` (403) versus `/smart-timetable/preview/999999` (404). The difference reveals whether id 999999 exists. |
| **Fix approach** | DECISION. Either accept (standard framework binding, low sensitivity), or move the gate in front of the bind by taking `int $timetableId` and calling `Gate::authorize()` before `Timetable::findOrFail()`. |
| **Plan item** | TWK-02 (DECISION) in `02-fix-plan.md` §9 |

```php
    public function workspace(Request $request, Timetable $timetable): View
    {
        Gate::authorize('tenant.smart-timetable.timetable.view');
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json 2>/dev/null | php -r 'filter TimetableWorkspaceController@'
GET|HEAD smart-timetable/preview/{timetable}          smart-timetable.timetable.preview         ...@workspace | mw: web,...,Illuminate\Auth\Middleware\Authenticate,...
GET|HEAD smart-timetable/workspace/{timetable}/grid   smart-timetable.timetable.workspace.grid   ...@grid | mw: web,...,Illuminate\Auth\Middleware\Authenticate,...
$ grep -nE 'public function workspace|public function grid|Gate::authorize' Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php
65:    public function workspace(Request $request, Timetable $timetable): View
67:        Gate::authorize('tenant.smart-timetable.timetable.view');
117:    public function grid(Request $request, Timetable $timetable): JsonResponse
119:        Gate::authorize('tenant.smart-timetable.timetable.view');
```

### F4 — Validation and input

#### TWK-03 · L · VAL-05 — the grid `exists` rule is wider than the picker it mirrors

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M, lowered to L — a read-only lookup, no write) — *every field is typed; the rule must mirror what the screen actually allows*. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php:121-123`, method `grid()`. |
| **Root cause** | The rule is `exists:sch_class_section_jnt,id` with no `where('is_active', true)`, while the class picker `selectableClassSections()` (line 198-206) offers only active class-sections. A caller can therefore fetch a grid for an inactive class-section that the UI never exposes. Inline validation is acceptable here (the rulebook permits a one-field AJAX endpoint), so the finding is the missing filter, not the location. |
| **Consequence** | A hand-edited or stale `class_section_id` for a deactivated class renders a grid the picker would never show; the heading and grid can disagree with the picker's own notion of available classes. |
| **Reproduce** | Static only — the tenant has no inactive row to call live; deactivate a `sch_class_section_jnt` row and request its id on the grid URL. |
| **Fix approach** | Mirror the picker in the rule with `Rule::exists(...)->where('is_active', true)`, referenced fully-qualified so no import line is added. |
| **Plan item** | TWK-03 in `02-fix-plan.md` §5 |

```php
        $validated = $request->validate([
            'class_section_id' => 'required|integer|exists:sch_class_section_jnt,id',
        ]);
```

**Evidence**
```
$ grep -n 'exists:sch_class_section_jnt' Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php
122:            'class_section_id' => 'required|integer|exists:sch_class_section_jnt,id',
$ grep -n 'is_active' Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php
199:            ->where('is_active', true)
```

### F5 — Routes

clean — both public methods are routed, both routes are GET reads, and each carries the full tenant + auth + module + snapshot middleware chain (RTE-05). The route parameter `{timetable}` matches the controller argument, so there is no unbound-model insert risk. There is no `Route::resource` sharing the prefix, so RTE-06 does not apply. Evidence is the `route:list` output in §4.

### F6 — Controller shape

#### TWK-04 · M · CTL-02 — two service methods run 238 and 344 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M, lowered from the default H for a method over 150 lines — CTL-02 targets controller methods; these are query-free assembler methods, so the cost is maintainability, not a deploy blocker) — *method length: over 80 lines extracts; over 150 is H*. |
| **Where** | `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php:68-305` (method `build()`, 238 lines) and `Modules/SmartTimetable/app/Services/Workspace/WorkspaceGridState.php:31-374` (method `transform()`, 344 lines); `WorkspaceContext.php:316-408` (`legalityMaps()`, 93 lines) is over the 80-line mark. |
| **Root cause** | Both services build one large array in a single straight-line method: `build()` runs roughly twenty queries and assembles a 30-key array; `transform()` maps that array to the client contract in one body. Neither has internal structure beyond inline comments. |
| **Consequence** | A reader cannot see the payload boundary at a glance, and any change to one key risks the file's ordering and the hidden column-by-column coupling documented in the comments. This is maintainability debt, not a bug. |
| **Reproduce** | Static only — count the line span of each method. |
| **Fix approach** | DECISION (D3): defer the extraction of `build()` and `transform()` into section methods (days, periods, activities, cells, legality maps) to a refactor pass; a split of a read-only assembler carries no deploy risk but is not part of this pass. |
| **Plan item** | TWK-04 (DECISION) in `02-fix-plan.md` §9 |

```php
    public function build(Timetable $timetable, ClassSection $classSection): array
```

**Evidence**
```
$ awk 'NR>=68 && NR<=305' Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php | wc -l
238
$ awk 'NR>=31 && NR<=374' Modules/SmartTimetable/app/Services/Workspace/WorkspaceGridState.php | wc -l
344
$ grep -n 'build(\|transform(\|legalityMaps(' Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php Modules/SmartTimetable/app/Services/Workspace/WorkspaceGridState.php
WorkspaceContext.php:68:    public function build(Timetable $timetable, ClassSection $classSection): array
WorkspaceContext.php:316:    private function legalityMaps(int $timetableId, ...): array
WorkspaceGridState.php:31:    public function transform(array $ctx): array
```

### F7 — Models

linked — the controller resolves `Modules/TimetableFoundation/app/Models/Timetable.php` (scope row 7), audited by its owner report. Usage checked: route binding and `->id`, `->name`, `->status`, `->isSnapshot()` all exist and are read-only. The `Modules/SmartTimetable/app/Models/Timetable.php` alias registered to the Analytics report (scope row 8) is **not** imported here. The service models (Activity, TimetableCell, SchoolDay, PeriodSet, ClassTimetableType) are all linked to their TimetableFoundation owners; this report only reads them. No model-level finding here.

### F8 — Services and jobs

#### TWK-05 · M · SVC-02 — `app(SnapshotContext::class)` resolves a dependency at call time

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection, not `app(Foo::class)` mid-method*. |
| **Where** | `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php:435` and `:492`, methods `outstandingByClassSection()` and `sharedRequirements()`. |
| **Root cause** | `WorkspaceContext` already injects `PreviewPlacementService` through its constructor, but fetches `SnapshotContext` with the service-locator helper inside two methods. `SnapshotContext` is therefore resolved once per call (twice in one request) instead of once, and the class's dependency list is invisible from its signature. |
| **Consequence** | The class cannot be constructed with a test double for `SnapshotContext`, the repeated `app()` calls re-resolve the container binding, and a reader cannot see from the constructor that the class depends on snapshot handling. |
| **Reproduce** | Static only — grep the two call sites. |
| **Fix approach** | Add `private readonly SnapshotContext $snapshot` to the constructor (the class is already imported) and replace both `app(SnapshotContext::class)` calls with `$this->snapshot`. |
| **Plan item** | TWK-05 in `02-fix-plan.md` §6 |

```php
    public function __construct(
        private readonly PreviewPlacementService $placement,
    ) {}
```

**Evidence**
```
$ grep -n 'app(SnapshotContext::class)' Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php
435:        $snap = app(SnapshotContext::class);
492:        $snap = app(SnapshotContext::class);   // raw SQL: see outstandingByClassSection()
```

#### TWK-06 · M · SVC-04 — the grid loader is a second copy of StandardTimetableController's

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *one implementation per business operation; two copies that disagree are a bug source*. |
| **Where** | `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php:45-53`, method `build()` (and the class header at lines 22-58). |
| **Root cause** | The class documents that its loading logic is copied from `StandardTimetableController::manualPlacement()` (roughly lines 105-660 as of 2026-09-03) and that the copy is deliberate. The two copies read the same `tt_*` tables and will drift. |
| **Consequence** | A fix applied to one screen's loader silently misses the other; the two screens can show different grids for the same data with no error. This is the debt the class itself records. |
| **Reproduce** | Static only — the class header names the source method. |
| **Fix approach** | DECISION: defer the extraction of the shared loader to a dedicated refactor pass once both screens are proven (the class header recommends exactly this), or schedule the extraction now. |
| **Plan item** | TWK-06 (DECISION) in `02-fix-plan.md` §9 |

```php
 * The loading logic below is copied from StandardTimetableController::manualPlacement()
 * (lines ~105-660 as of 2026-09-03). Both modules read the SAME tt_* tables, so the logic
```

**Evidence**
```
$ grep -nE 'DUPLICATION|StandardTimetableController::manualPlacement|copied from' Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php
43: * ⚠ DUPLICATION, DELIBERATE AND RECORDED
45: * The loading logic below is copied from StandardTimetableController::manualPlacement()
```

### F9 — Queries and performance

#### TWK-07 · M · QRY-05 — the class picker loads every class-section and sorts in PHP

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M) — *aggregate/order in SQL, not over a whole fetched collection*. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php:198-206`, method `selectableClassSections()`; also `WorkspaceContext.php:232-240` (`Room::get()->groupBy()`). |
| **Root cause** | The method loads all active class-sections with two relations and then sorts them in PHP with a composite string key. The sort key — `class.ordinal` then `section.ordinal` — exists on the related `sch_classes` and `sch_sections` tables, so the database can order the rows directly with a join. The method runs on every page load and on every class switch (`grid()` calls it at line 138). |
| **Consequence** | Three queries (class-sections plus both eager loads) and an in-PHP sort run on every class switch instead of one ordered query; the cost is small today (43 rows) but grows with the school and it is repeated on the hot path. |
| **Reproduce** | Static only — read the method and count the calls in `grid()`. |
| **Fix approach** | Order in SQL: join `sch_classes` and `sch_sections`, filter on the qualified `sch_class_section_jnt.is_active`, order by the two ordinals, and select `sch_class_section_jnt.*`. Keep `with(['class', 'section'])` for the label. |
| **Plan item** | TWK-07 in `02-fix-plan.md` §6 |

```php
        return ClassSection::with(['class', 'section'])
            ->where('is_active', true)
            ->get()
            ->sortBy(fn ($cs) => sprintf(
                '%06d-%06d',
                (int) ($cs->class?->ordinal ?? 0),
                (int) ($cs->section?->ordinal ?? 0),
            ))
            ->values();
```

**Evidence**
```
$ grep -nE 'sortBy\(|->get\(\)' Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php
200:            ->get()
201:            ->sortBy(fn ($cs) => sprintf(
$ grep -n 'selectableClassSections()' Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php
69:        $classSections = $this->selectableClassSections();
138:                'class_options' => $this->classOptions($this->selectableClassSections(), $timetable),
```

Dismissed scanner candidate: the `QRY-11 interpolated raw SQL` rows in `WorkspaceContext.php:436,493,513` are **not** a finding. Every value is bound with `?`; the only interpolation is the table name returned by `SnapshotContext::t()`, which maps a literal table name through the snapshot grammar (`SnapshotContext.php:254-266`) and never receives user input.

### F10 — Views

clean — neither blade issues a query and neither prints raw user text. `grep -nE 'Model::|DB::|->where\(|->get\(|->count\(|::find|::all|\{!!' Modules/SmartTimetable/resources/views/workspace/index.blade.php Modules/SmartTimetable/resources/views/workspace/partials/_insights-body.blade.php` → no output. The only `v-html` target (`index.blade.php:1010`) is filled with HTML that the same server-side blade renders through `{{ }}`, so it is escaped at source. Both blades compile (`blade.compiler()->compileString()` returned 107478 bytes and 5104 bytes respectively). The breadcrumb passes `:links="[]"` — recorded as a module-wide cross-cutting note in §7.

### F11 — Security and tenancy

clean — no `env()` outside config, no hard-coded ids or `?? 1`, no request body or secret logged (the only log line carried `timetable_id` and `class_section_id`), no cache to key by tenant, and no Spatie media. `grep -nE 'env\(|\?\? 1|cache\(' across the controller and both services` → no output. The permission `tenant.smart-timetable.timetable.view` (id 1641) is declared in `config/permissionslist.php:714` (key `smart-timetable.timetable` = `$crud` + `generate`) and seeded in the tenant to roles 1 (Super Admin) and 2 (School Admin).

### F12 — Style

#### TWK-08 · L · STY-04 — emoji markers in the comments of all three files

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers*. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php` (8 marker lines), `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php` (15), `Modules/SmartTimetable/app/Services/Workspace/WorkspaceGridState.php` (10). |
| **Root cause** | The comments use `⛔` and `⚠` as attention markers. The house style requires plain English. |
| **Consequence** | Style drift; the markers also render inconsistently in terminals and diffs. No functional effect. |
| **Reproduce** | Static only — grep the two characters. |
| **Fix approach** | Replace each `⛔` and `⚠` that opens a comment line with the plain prefix `NOTE:`. One item covers the three files. |
| **Plan item** | TWK-08 in `02-fix-plan.md` §8 |

```php
     * ⛔ ONE COMPOSITE KEY, NOT sortBy([closure, closure]).
```

**Evidence**
```
$ grep -cE '⛔|⚠' Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php
8
$ grep -cE '⛔|⚠' Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php
15
$ grep -cE '⛔|⚠' Modules/SmartTimetable/app/Services/Workspace/WorkspaceGridState.php
10
```

#### TWK-09 · L · STY-02 — WorkspaceContext is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset), sorted imports*. |
| **Where** | `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php:7-20`. |
| **Root cause** | The `use Modules\TimetableFoundation\Support\Snapshot\SnapshotContext;` import sits on line 9, before the `Modules\SchoolSetup\...` block; Pint's `ordered_imports` rule moves it after the `Modules\TimetableFoundation\Models\...` block. |
| **Consequence** | The file fails `vendor/bin/pint --test` and will be reformatted the next time anyone runs Pint on a touched file. |
| **Reproduce** | Run `vendor/bin/pint Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php --test --format agent`. |
| **Fix approach** | Run Pint on the file (it also reports `unary_operator_spaces`, `braces_position`, `not_operator_with_successor_space` and `single_line_empty_body`). The Before/After below is the one concrete diff the import rule makes. |
| **Plan item** | TWK-09 in `02-fix-plan.md` §8 |

```php
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Modules\TimetableFoundation\Support\Snapshot\SnapshotContext;
use Modules\SchoolSetup\Models\ClassSection;
use Modules\SchoolSetup\Models\Room;
use Modules\SchoolSetup\Models\Teacher;
use Modules\SchoolSetup\Models\TeacherProfile;
use Modules\SmartTimetable\Services\Preview\PreviewPlacementService;
use Modules\TimetableFoundation\Models\Activity;
use Modules\TimetableFoundation\Models\ClassTimetableType;
use Modules\TimetableFoundation\Models\PeriodSet;
use Modules\TimetableFoundation\Models\SchoolDay;
use Modules\TimetableFoundation\Models\Timetable;
use Modules\TimetableFoundation\Models\TimetableCell;
```

**Evidence**
```
$ vendor/bin/pint Modules/SmartTimetable/app/Http/Controllers/TimetableWorkspaceController.php Modules/SmartTimetable/app/Services/Workspace/WorkspaceGridState.php Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php --test --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\/SmartTimetable\/app\/Services\/Workspace\/WorkspaceContext.php","fixers":["unary_operator_spaces","braces_position","not_operator_with_successor_space","single_line_empty_body","ordered_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There are **no mutating methods**. Every method in this controller and its two services is a read: the controller renders views and assembles JSON, and the services run SELECT-only queries (dismissed QRY-11 check in §F9). The table records the eight questions per service entry point; a write-only question is `n/a`.

| Entry point | 1 Overwrite | 2 Delete-first | 3 Dup impl | 4 Soft-del×unique | 5 Race | 6 Auth hole | 7 Lying msg | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `workspace` (controller) | n/a | n/a | ok | n/a | ok | TWK-02 | ok | ok |
| `grid` (controller) | n/a | n/a | TWK-07 | n/a | ok | TWK-02 | TWK-01 — a missing class-section is reported as "Could not load that class", which does not describe the cause | ok |
| `build` (WorkspaceContext) | n/a | n/a | TWK-06 | n/a | ok | ok | ok | ok |
| `outstandingByClassSection` / `sharedRequirements` | n/a | n/a | ok | n/a | ok | ok | ok | ok |
| `transform` (WorkspaceGridState) | n/a | n/a | ok | n/a | ok | ok | ok | ok |

**Wrong data (Q1):** no write, so no data can be overwritten or corrupted. **Irreversible order (Q2):** n/a. **Duplicate implementations (Q3):** TWK-06 (the grid loader duplicates StandardTimetableController) and TWK-07 (the ordering is done twice, in PHP). **Soft-delete × unique (Q4):** n/a. **Races (Q5):** none — every read is a single statement or a stable eager load. **Auth holes (Q6):** TWK-02. **Lying messages (Q7):** TWK-01's catch reports a 404 as a generic failure. **Dead features (Q8):** none found; `WorkspaceGridState::build()` (line 381) is unused by this controller but is a public convenience used elsewhere (StandardTimetable pattern), so it is not dead.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `resources/views/components/**` + the workspace blade | `index.blade.php:32` passes `:links="[]"`, so the page carries no breadcrumb trail; the UI standard says resolve the trail. Every SmartTimetable view does the same. | VIEW (UI standard) | the SmartTimetable views pass |
| `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php` | Used here only for two read lookups (`classGroupIdsFor`, `classSubgroupIdsFor`); owned and audited by the TimetablePreviewController report (currently CLAIMED, may not be finished). | — | [tarun/SmartTimetable/TimetablePreviewController](../TimetablePreviewController-done/01-report.md) |
| `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | Table-name resolver reached through the service locator; its own audit is elsewhere. | — | [tarun/StandardTimetable/StandardTimetableController-done](../../StandardTimetable-done/StandardTimetableController-done/01-report.md) |
| `tenant.smart-timetable.timetable.view` literal | The same permission string is repeated as a literal in at least twelve SmartTimetable controllers; there is no constant or policy holding it. Module-wide, not this controller's defect. | AUTH-06 | the SmartTimetable module pass |
| `Modules/TimetableFoundation/app/Models/Timetable.php` | Parent model bound by the route; audited by its owner report. | — | [tarun/TimetableFoundation/TimetableController](../../TimetableFoundation-done/TimetableController-done/01-report.md) |

## 8. Not covered, and why

- **Browser run**: none. This is a read-only audit (D4 forbids tests), so no server was started and no page was opened.
- **Live rendering**: the tenant `test.localhost` has 0 `tt_timetables`, 0 `tt_timetable_cells` and 0 `tt_activities`, so the workspace renders only its empty-state branch here; every finding is proven statically.
- **Service internals of `PreviewPlacementService`**: audited by the TimetablePreviewController report that owns the class; this report checked only the two read methods it calls.
- **The three DECISION items** (TWK-02, TWK-04, TWK-06): options are in the plan; no choice is assumed here.
- **Jobs, events, mail, notifications, exports, imports**: this controller references none.
