# Final Audit — SmartTimetable / TimetableExportController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php` (429 lines, 5 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/smart-timetable/export/pdf/{timetableId}`, `/smart-timetable/export/html/{timetableId}`, `/smart-timetable/export/excel/{timetableId}`, `/smart-timetable/export/teacher-pdf/{timetableId}`, `/smart-timetable/export/teacher-html/{timetableId}` — opened from the timetable preview page's Export modal (`_export-modal.blade.php`) |
| Menu path | Smart Timetable → View & Refinement → Preview → Export (PDF / HTML / Excel; class-wise and teacher-wise) |
| Who uses it | Roles that hold `tenant.smart-timetable.timetable.view` (probed from `sys_role_has_permissions_jnt`): **Super Admin, School Admin** |
| What a user does here | Downloads a timetable as a printable A4-landscape PDF, a self-contained Bootstrap HTML file, or an Excel workbook. A user can optionally limit the class export to chosen class-sections (`class_section_ids[]`) and the teacher export to chosen teachers (`teacher_ids[]`). This is a pure read path — nothing is written to the database. |
| Tables written | none (read-only controller) |
| Tables read | `tt_timetables`, `tt_school_days`, `tt_period_set_periods_jnt`, `tt_period_configs`, `tt_period_types`, `tt_timetable_cells`, `tt_timetable_cell_teachers`, `tt_activities` (+ its relations), `sch_class_section_jnt`, `sch_class_groups_jnt`, `tt_class_requirement_subgroups`, `sch_classes`, `sch_sections`, `sch_subject_study_format_options`, `sch_rooms`, `sch_teachers`, `sch_room_types` |
| Live data | On `test.localhost` (tenant `xyz_school_00000000000040008000_202627`): `tt_timetables` 0, `tt_timetable_cells` 0 (0 trashed), `tt_school_days` 7, `tt_period_set_periods_jnt` 27, `sch_class_section_jnt` 43, `sch_teachers` 89, `sch_rooms` 68, `tt_activities` 0 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **production-ready for the current data size, with fixes wanted before go-live**. It is a clean, read-only export controller: every routed method authorizes, there is no try/catch, no validation hole, no N+1 (all relations are eager-loaded in one pass), and every blade compiles. The single worst finding is that all five export endpoints are gated on `tenant.smart-timetable.timetable.view` — the plain read permission — instead of an export-specific ability, so anyone who can view the timetable can silently download the whole schedule as a file; the module's own standard (and the config comment at `permissionslist.php:720-724`) treats export as its own, stronger right. The other findings are maintainability (an 173-line private builder and a duplicated loader block) and absence of route model binding and of a record cap on exports. Rough effort to fix the whole plan: S–M, about 2–4 hours, mostly decisions that need Tarun's hand (a new permission key + seeding).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 3 | 3 | 4 | 8 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean (no writes) | F9 Queries/Perf | TEX-05, TEX-06 |
| F3 Authorization | TEX-01 | F10 Views | clean (blades); export-gate issue filed as TEX-01 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | TEX-07, TEX-08 |
| F6 Controller shape | TEX-02, TEX-03, TEX-04 | F13 Deep read | see table in §6 F13 |
| F7 Models | clean (aliases); Foundation models linked | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php` | controller | 429 | this report | ✅ |
| 2 | `Modules/SmartTimetable/app/Exports/TimetableExport.php` | export class | 127 | this report (only caller) | ✅ |
| 3 | `Modules/SmartTimetable/app/Services/Preview/SlotOwnerResolver.php` | service | 95 | this report (claimed in `_Info/00-CLASS-OWNERS.md`) | ✅ |
| 4 | `Modules/SmartTimetable/app/Models/SchoolDay.php` | alias model | 11 | this report (pre-assigned) | ✅ |
| 5 | `Modules/SmartTimetable/app/Models/PeriodSetPeriod.php` | alias model | 11 | this report (pre-assigned) | ✅ |
| 6 | `Modules/SmartTimetable/app/Models/TimetableCell.php` | alias model | 11 | this report (pre-assigned) | ✅ |
| 7 | `Modules/TimetableFoundation/app/Models/SchoolDay.php` | model | 103 | ↗ [tarun/TimetableFoundation/SchoolDayController](../../TimetableFoundation-done/SchoolDayController-done/01-report.md) | ↗ linked |
| 8 | `Modules/TimetableFoundation/app/Models/PeriodSetPeriod.php` | model | 152 | ↗ [tarun/TimetableFoundation/PeriodSetPeriodController](../../TimetableFoundation-done/PeriodSetPeriodController-done/01-report.md) | ↗ linked |
| 9 | `Modules/TimetableFoundation/app/Models/TimetableCell.php` | model | 279 | ↗ [tarun/TimetableFoundation/TimetableController](../../TimetableFoundation-done/TimetableController-done/01-report.md) | ↗ linked |
| 10 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | 516 | ↗ [tarun/SmartTimetable/AnalyticsController](../AnalyticsController-done/01-report.md) | ↗ linked |
| 11 | `Modules/SmartTimetable/resources/views/exports/timetable-pdf-printable.blade.php` | blade | 471 | this report | ✅ |
| 12 | `Modules/SmartTimetable/resources/views/exports/teacher-pdf.blade.php` | blade | 428 | this report | ✅ |
| 13 | `Modules/SmartTimetable/resources/views/exports/timetable-html.blade.php` | blade | 418 | this report | ✅ |
| 14 | `Modules/SmartTimetable/resources/views/exports/teacher-html.blade.php` | blade | 390 | this report | ✅ |
| 15 | `Modules/SmartTimetable/resources/views/exports/partials/_pdf-band.blade.php` | blade partial | 46 | this report | ✅ |
| 16 | `Modules/SmartTimetable/resources/views/exports/partials/_html-theme.blade.php` | blade partial | 26 | this report | ✅ |
| 17 | `Modules/SmartTimetable/routes/web.php` (export group only, lines 184-191) | route file | 283 | this report (export rows) | ✅ |
| 18 | `Modules/Shared/SmartTimetable\Models\ClassSection`, `Room`, `Teacher` (SchoolSetup) | models | — | common (different module) | referenced |
| 19 | `config/permissionslist.php` (line 714) | config | 1699 | common | cross-cutting |

No in-scope file appears in a module `PRE-APPLIED-2026-10-10.md`. **No pre-applied files.**

## 4. Routes

```
GET|HEAD smart-timetable/export/excel/{timetableId}                   smart-timetable.export.excel                  Modules\SmartTimetable\Http\Controllers\TimetableExportController@exportExcel
GET|HEAD smart-timetable/export/html/{timetableId}                    smart-timetable.export.html                   Modules\SmartTimetable\Http\Controllers\TimetableExportController@exportHtml
GET|HEAD smart-timetable/export/pdf/{timetableId}                     smart-timetable.export.pdf                    Modules\SmartTimetable\Http\Controllers\TimetableExportController@exportPdf
GET|HEAD smart-timetable/export/teacher-html/{timetableId}            smart-timetable.export.teacherHtml            Modules\SmartTimetable\Http\Controllers\TimetableExportController@exportTeacherHtml
GET|HEAD smart-timetable/export/teacher-pdf/{timetableId}             smart-timetable.export.teacherPdf             Modules\SmartTimetable\Http\Controllers\TimetableExportController@exportTeacherPdf
```

Unrouted public methods: none — all 5 public methods are routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `exportPdf` | 30 | GET `/smart-timetable/export/pdf/{timetableId}` | `tenant.smart-timetable.timetable.view` | none (read-only) | none | none | TEX-01, TEX-02, TEX-04, TEX-05 |
| `exportHtml` | 48 | GET `/smart-timetable/export/html/{timetableId}` | `tenant.smart-timetable.timetable.view` | none (read-only) | none | none | TEX-01, TEX-02, TEX-04, TEX-05 |
| `exportExcel` | 66 | GET `/smart-timetable/export/excel/{timetableId}` | `tenant.smart-timetable.timetable.view` | none (read-only) | none | none | TEX-01, TEX-04, TEX-05 |
| `exportTeacherPdf` | 81 | GET `/smart-timetable/export/teacher-pdf/{timetableId}` | `tenant.smart-timetable.timetable.view` | none (read-only) | none | none | TEX-01, TEX-02, TEX-04, TEX-05 |
| `exportTeacherHtml` | 97 | GET `/smart-timetable/export/teacher-html/{timetableId}` | `tenant.smart-timetable.timetable.view` | none (read-only) | none | none | TEX-01, TEX-02, TEX-04, TEX-05 |

## 6. Findings

### F1 — Errors

clean — `grep -nE "try \{|catch |getMessage" Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php` → no output. No try/catch anywhere; the D2 catch shapes are not present because there are no writes.

### F2 — Transactions and audit

clean — this controller never mutates. Grep for the mutations the audit guards: `grep -nE "update|create|save|insert|delete|activityLog|DB::transaction" Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php Modules/SmartTimetable/app/Exports/TimetableExport.php Modules/SmartTimetable/app/Services/Preview/SlotOwnerResolver.php` → no database write anywhere on this read path.

### F3 — Authorization

#### TEX-01 · H · AUTH-01 — Export endpoints are gated on the plain read ability `view`, not an export ability

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B default — *every routed controller method authorizes*; lowered to H: it does authorize, but with the wrong, weaker ability) and the final-audit F10 standard: *export gates use `.export`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:32,50,68,83,99`, methods `exportPdf()`, `exportHtml()`, `exportExcel()`, `exportTeacherPdf()`, `exportTeacherHtml()` |
| **Root cause** | Every method copies the preview page's gate `tenant.smart-timetable.timetable.view`. There is no export ability: `config/permissionslist.php:714` declares `'smart-timetable.timetable' => array_merge($crud, ['generate'])` — no `export`. The module's own standard (config comment, lines 720-724) says "Export is its own ability, never viewAny: reading a page of rules is not the right to take the whole rule base away", and the sibling export (AnalyticsController:97) uses `tenant.smart-timetable.report.export`. |
| **Consequence** | A role granted only read access (`view`, no export) can silently download the entire timetable as PDF, HTML or Excel — the whole schedule leaves the organisation, which the house standard treats as a separate, stronger right. |
| **Reproduce** | Static only — `permissionslist.php:714` proves no `smart-timetable.timetable.export` name exists, so the five `Gate::authorize('…view')` calls are the only thing between a logged-in user and the file. On test.localhost both holders of `view` (Super Admin, School Admin) also hold the other CRUD verbs, so the divergence is latent until a view-only read role is granted. |
| **Fix approach** | Declare `'smart-timetable.timetable' => array_merge($crud, ['generate', 'export'])`, seed it via `/system-config/sync-permissions` (Tarun's hand), then change all five gates to `tenant.smart-timetable.timetable.export` and mirror that name on the preview's export buttons. |
| **Plan item** | TEX-01 in `02-fix-plan.md` §9 (DECISION) |

```php
// TimetableExportController.php:30-34 — CURRENT
    public function exportPdf(Request $request, int $timetableId): Response
    {
        Gate::authorize('tenant.smart-timetable.timetable.view');

        $data = $this->buildExportData($timetableId, $request->input('class_section_ids', []));
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php
32:        Gate::authorize('tenant.smart-timetable.timetable.view');
50:        Gate::authorize('tenant.smart-timetable.timetable.view');
68:        Gate::authorize('tenant.smart-timetable.timetable.view');
83:        Gate::authorize('tenant.smart-timetable.timetable.view');
99:        Gate::authorize('tenant.smart-timetable.timetable.view');
$ grep -n "smart-timetable.timetable'" config/permissionslist.php
714:        'smart-timetable.timetable' => array_merge($crud, ['generate']),
$ php artisan tinker --execute '...DB::table("sys_permissions")->where("name","like","%smart-timetable.timetable%")->pluck("name")...'
tenant.smart-timetable.timetable.create / .view / .viewAny / .update / .delete / .restore / .forceDelete / .generate
(no .export seeded)
```

### F4 — Validation and input

clean — the only user input is the `class_section_ids[]` / `teacher_ids[]` filters; both are coerced with `array_filter(array_map('intval', (array) $filter))` before use (lines 258, 335), so no unvalidated value can reach a query.

### F5 — Routes

clean — all 5 methods routed with matching names (`web.php:186-190`), all GET (no state change over GET, RTE-01 clean), tenant middleware present (`web`, `auth`, `verified`, `EnsureTenantHasModule:smart-timetable` on the parent group), routes registered inside the `export` prefix group (RTE-06 clean). `route:list` confirmed every route points at an existing method. No unrouted public method (RTE-03 clean).

### F6 — Controller shape

#### TEX-02 · H · CTL-02 — `buildExportData()` is 173 lines and `buildTeacherExportData()` is 122 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M default — *method length over 80 lines → extract, over 150 is H*; raised to H because 173 exceeds the H threshold) |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:119-291` (`buildExportData`) and `:300-421` (`buildTeacherExportData`) |
| **Root cause** | The grid-building business logic — slot ownership, option blocks, per-class activity counts and requirements, room lookups, class-section filtering — all lives inside the two private controller builders. The docblock says it "mirrors TimetablePreviewController", so the same logic also exists in a second controller. |
| **Consequence** | A developer must hold two large builders (plus the preview controller) in mind at once; the code comments show an earlier export bug (dropped optional/shared lessons) came from exactly this duplication diverging from the screen. |
| **Reproduce** | Static only — open the file; the two private methods between lines 119 and 421 are the entire export logic. |
| **Fix approach** | Extract the builders to a service (e.g. reuse/`TimetableExportData`) shared with the preview path; per D3 the split is deferred, never applied in this pass. |
| **Plan item** | TEX-02 in `02-fix-plan.md` §9 (DECISION) |

```php
// TimetableExportController.php:119-123 — CURRENT
    private function buildExportData(int $timetableId, array $classSectionIds): array
    {
        $timetable = Timetable::with(['timetableType', 'academicTerm', 'academicSession', 'periodSet'])
            ->findOrFail($timetableId);
```

**Evidence**
```
$ sed -n '119,291p' Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php | wc -l
173
$ sed -n '300,421p' Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php | wc -l
122
```

#### TEX-03 · M · CTL-05 — The timetable/day/period loader block is copy-pasted across both builders

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same 18-line loader repeated in two methods is a divergence source* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:121-139` and `:302-320` |
| **Root cause** | `buildExportData()` opens the timetable, days and periods in one 19-line block; `buildTeacherExportData()` repeats the identical block (including the comment explaining the teaching/break stamp). Any future change (e.g. a new eager load on `Timetable`) must be applied twice. |
| **Consequence** | The two builders can silently drift apart — the exact mechanism the comment at lines 131-135 says caused the earlier option-dropping export bug. |
| **Reproduce** | Static only — diff the two blocks: `diff <(sed -n '121,139p' F.php) <(sed -n '302,320p' F.php)` shows only whitespace differences. |
| **Fix approach** | Extract a private `loadExportContext(int $timetableId): array` returning `[$timetable, $days, $periods]` and call it from both builders. |
| **Plan item** | TEX-03 in `02-fix-plan.md` §2 |

```php
// TimetableExportController.php:121-139 — CURRENT (identical block at 302-320)
        $timetable = Timetable::with(['timetableType', 'academicTerm', 'academicSession', 'periodSet'])
            ->findOrFail($timetableId);

        $days = SchoolDay::schoolDays()->get();

        $periods = PeriodSetPeriod::with('periodType')
            ->where('is_active', true)
            ->when($timetable->period_set_id, fn ($q) => $q->where('period_set_id', $timetable->period_set_id))
            ->orderBy('period_ord')
            ->get()
            ->each(function ($period) {
                $period->is_teaching = (bool) ($period->periodType?->counts_as_teaching ?? true);
                $period->is_break = (bool) ($period->periodType?->is_break ?? false);
            });
```

**Evidence**
```
$ diff <(sed -n '121,139p' Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php) <(sed -n '302,320p' Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php)
(no output — the two blocks are identical)
```

#### TEX-04 · M · CTL-03 — No route model binding: five methods take `int $timetableId` and call `findOrFail`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`exportPdf(Timetable $timetableId)`), not `$id` + `findOrFail`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:30,48,66,81,97` (signatures) and `:70,122,303` (`Timetable::findOrFail`) |
| **Root cause** | The route parameters (`web.php:186-190`, named `{timetableId}`) are not bound to the `Timetable` model; every method re-resolves the record inside the private builders, which also re-loads relations with `with()`. |
| **Consequence** | Not a bug today — but it is three separate `findOrFail` call sites for one concept, and an unbound `timetableId` that does not exist 404s inside the builder rather than at the route boundary. |
| **Reproduce** | Static only — signature inspection; all five signatures type the parameter as `int`. |
| **Fix approach** | Bind `Timetable` in the signatures (keeping the argument name aligned with the route parameter). This changes five signatures and both private builders, so it is deferred as a DECISION. |
| **Plan item** | TEX-04 in `02-fix-plan.md` §9 (DECISION) |

```php
// TimetableExportController.php:66-70 — CURRENT
    public function exportExcel(Request $request, int $timetableId): BinaryFileResponse
    {
        Gate::authorize('tenant.smart-timetable.timetable.view');

        $timetable = Timetable::findOrFail($timetableId);
```

**Evidence**
```
$ grep -n "findOrFail\|int \$timetableId" Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php
30:    public function exportPdf(Request $request, int $timetableId): Response
48:    public function exportHtml(Request $request, int $timetableId): Response
66:    public function exportExcel(Request $request, int $timetableId): BinaryFileResponse
70:        $timetable = Timetable::findOrFail($timetableId);
81:    public function exportTeacherPdf(Request $request, int $timetableId): Response
97:    public function exportTeacherHtml(Request $request, int $timetableId): Response
119:    private function buildExportData(int $timetableId, array $classSectionIds): array
122:            ->findOrFail($timetableId);
300:    private function buildTeacherExportData(int $timetableId, array $teacherIds): array
303:            ->findOrFail($timetableId);
```

### F7 — Models

clean for this report's own (pre-assigned) models — the three `Modules/SmartTimetable/app/Models/*` classes are 11-line backward-compatibility aliases that extend the TimetableFoundation models; nothing sensitive, correct `$fillable`/`$casts` inherited, and the controller does not use the aliases at all (it imports the Foundation classes directly). The Foundation models used by this controller are owned by other reports (see §3); every relation this controller exercises was proven in tinker: `TimetableCell::teachers/activity/timetable/room/period/day` and `Timetable::timetableType/academicTerm/academicSession/periodSet` all run OK against the tenant DB.

### F8 — Services and jobs

clean — `SlotOwnerResolver` is a static helper: no HTTP, no writes, constructor-injection not applicable, and its per-cell closure runs zero queries (all lookups are pre-fetched into keyed collections). `TimetableExport` is a Maatwebsite export class, not a service or job. No jobs, listeners or commands in scope.

### F9 — Queries and performance

#### TEX-05 · M · QRY-06 — Exports pull every row into memory with unbounded `get()` and no record cap

| Field | Value |
|---|---|
| **Rule** | QRY-06 (M) — *bulk data in batches (`chunkById`/`lazyById`/`cursor`) for exports over large tables*, plus the TenantCore export standard's 3,000-record cap |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:153` (cells, class export), `:333` (cells, teacher export), `:124,305` (days), `:262` (class sections) and `Modules/SmartTimetable/app/Exports/TimetableExport.php:45` (cells, Excel) |
| **Root cause** | The grid builders need the full cell set in memory to build the per-class/per-teacher slot maps, so they use plain `->get()`. There is no cap equivalent to the TenantCore export component's `max_limit ?? 3000`. |
| **Consequence** | A large school (thousands of timetable cells across classes, teachers and rooms — say 40 classes × 8 periods × 6 days already exceeds 1,900 cells) can exhaust PHP memory or the PDF renderer on the export URL, which is exactly the case the 3,000-record standard exists for. On test.localhost today there are 0 cells, so the failure is latent, not live. |
| **Reproduce** | Static only — `grep -n "->get();"` lists five unbounded fetches; no `limit`/`chunk` anywhere. Live count proof: `tt_timetable_cells` = 0 rows. |
| **Fix approach** | Add a record cap (limit with a message) or stream cells with `lazyById` into the builders. Either changes export behaviour / the builder shape, so it is a DECISION. |
| **Plan item** | TEX-05 in `02-fix-plan.md` §9 (DECISION) |

```php
// TimetableExportController.php:141-153 — CURRENT (unbounded; no cap, no chunk)
        $cells = TimetableCell::with([
            'activity.class',
            'activity.section',
            'activity.subject',
            'activity.studyFormat',
            'activity.subjectStudyFormat.subject',
            'activity.subjectStudyFormat.studyFormat',
            'activity.requiredRoomType',
            'activity.preferredRoomType',
            'activity.teachers.teacher.user',
            'activity.subActivities',
            'teachers.user',
        ])->where('timetable_id', $timetable->id)->get();
```

**Evidence**
```
$ grep -n "->get();" Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php Modules/SmartTimetable/app/Exports/TimetableExport.php
Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:124:        $days = SchoolDay::schoolDays()->get();
Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:153:        ])->where('timetable_id', $timetable->id)->get();
Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:262:            ->get()
Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:305:        $days = SchoolDay::schoolDays()->get();
Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:333:            ->get();
Modules/SmartTimetable/app/Exports/TimetableExport.php:45:            ->get();
$ php artisan tinker --execute '...DB::table("tt_timetable_cells")->count()...'
0
```

#### TEX-06 · L · QRY-05 — `ClassSection` is loaded fully and filtered in PHP instead of in SQL

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M default — *aggregate/filter in SQL*; lowered to L: the table is 43 rows on test.localhost, so there is no live cost) |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php:260-274` |
| **Root cause** | `ClassSection::where('is_active', true)->with([...])->get()` loads every active class-section, then a closure filters by grid keys and `$classSectionIds`. The filter key (`class.code-section.code`) is derived from cell ownership, so it cannot be expressed as a simple `whereIn` on the class-section id. |
| **Consequence** | A few wasted rows per export (43 rows live). No user-visible problem. |
| **Reproduce** | Static only — open the export of any timetable; the class-section list is loaded in full. |
| **Fix approach** | None mechanical — moving the filter into SQL would need pre-computed class/section id sets from the grid or a join; not worth it at this table size. |
| **Plan item** | none — see plan §10 |

```php
// TimetableExportController.php:260-274 — CURRENT
        $classSections = ClassSection::where('is_active', true)
            ->with(['class', 'section', 'classTeacher', 'assistanceClassTeacher', 'classHouseRoom'])
            ->get()
            ->filter(function ($cs) use ($gridClassKeys, $classSectionIds) {
                $key = ($cs->class->code ?? 'unknown').'-'.($cs->section->code ?? 'unknown');
                if (! in_array($key, $gridClassKeys, true)) {
                    return false;
                }
                if (! empty($classSectionIds) && ! in_array((int) $cs->id, $classSectionIds, true)) {
                    return false;
                }

                return true;
            })
            ->values();
```

**Evidence**
```
$ php artisan tinker --execute '...DB::table("sch_class_section_jnt")->count()...'
43
$ sed -n '260,274p' Modules/SmartTimetable/app/Http/Controllers/TimetableExportController.php | grep -nE "get\(\)|filter\(" 
3:            ->get()
5:            ->filter(function ($cs) use ($gridClassKeys, $classSectionIds) {
```

Otherwise clean — no N+1: the per-cell ownership closure (`SlotOwnerResolver::forCells`) runs zero queries (all ids pre-fetched into keyed collections), `$periods->firstWhere()` is in-memory collection work, and every relation used in the export loops (`activity.*`, `teachers.user`, `room`, `day`, `period`) is eager-loaded in the single `with([...])` call (lines 141-153, 322-333, and `TimetableExport.php:34-42`). No query sits inside a loop.

### F10 — Views

clean — the four export blades and the two partials contain no `Model::`/`DB::`/`->where(`/`->get()` queries (all data is passed from the controller), no unescaped user text (`_pdf-band.blade.php:36` uses `{!! !!}` only over `e()`-escaped `$bandParts` and a hard-coded separator), and all five blades compile (verified below). The export-gate standard issue is filed as TEX-01 under F3.

**Evidence**
```
$ grep -nE "Model::|DB::|->where\(|\{!!" Modules/SmartTimetable/resources/views/exports/*.blade.php Modules/SmartTimetable/resources/views/exports/partials/*.blade.php
Modules/SmartTimetable/resources/views/exports/partials/_pdf-band.blade.php:36: ... @endif{!! implode('<span class="dot">&bull;</span>', $bandParts) !!}
$ php -r '...foreach(glob("Modules/SmartTimetable/resources/views/exports/*.blade.php") as $f){ Blade::compileString(file_get_contents($f)); echo basename($f)." OK\n"; }'
teacher-html.blade.php OK
teacher-pdf.blade.php OK
timetable-html.blade.php OK
timetable-pdf-printable.blade.php OK
timetable-pdf.blade.php OK
```

### F11 — Security and tenancy

clean — no `env()` outside config; no hard-coded ids or `?? 1` fallbacks; no secrets logged; the exports render timetable data only (no full `User`/`Student` models over JSON — the exposed fields are the timetable display fields); the tenant DB is reached through the tenancy connection (the tinker probe ran against tenant `xyz_school_...`); no cache keys, media or URLs in scope. Personal-data exposure is limited to teacher display names, which is the purpose of a teacher timetable.

### F12 — Style

#### TEX-07 · L · STY-02 — `TimetableExport.php` is not Pint-clean: `fn($t)` spacing and a fully-qualified `\PhpOffice\...\Fill` inline

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/SmartTimetable/app/Exports/TimetableExport.php:54` and `:117-118` |
| **Root cause** | `fn($t)` lacks the Pint-required space (`fn ($t)`), and `\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID` is used inline instead of an imported `Fill`. |
| **Consequence** | Style only — Pint would reformat these lines on the next touch. |
| **Reproduce** | Static only — `vendor/bin/pint Modules/SmartTimetable/app/Exports/TimetableExport.php --test --format agent` reports diffs on both lines. |
| **Fix approach** | Add the space and import `PhpOffice\PhpSpreadsheet\Style\Fill`. |
| **Plan item** | TEX-07 in `02-fix-plan.md` §8 |

```php
// TimetableExport.php:54 — CURRENT
            $teacherNames = $cell->teachers->map(fn($t) => $t->user->name ?? 'N/A')->implode(', ');
```

**Evidence**
```
$ sed -n '54p' Modules/SmartTimetable/app/Exports/TimetableExport.php
            $teacherNames = $cell->teachers->map(fn($t) => $t->user->name ?? 'N/A')->implode(', ');
$ sed -n '118p' Modules/SmartTimetable/app/Exports/TimetableExport.php
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
```

#### TEX-08 · L · STY-01 — The three alias models have no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` on PHP files* |
| **Where** | `Modules/SmartTimetable/app/Models/SchoolDay.php:1`, `Modules/SmartTimetable/app/Models/PeriodSetPeriod.php:1`, `Modules/SmartTimetable/app/Models/TimetableCell.php:1` |
| **Root cause** | The three backward-compatibility aliases start with `<?php` then `namespace`, with no `strict_types` declaration. |
| **Consequence** | Style only; the classes are 11-line shims scheduled for "Phase 6 cleanup" per their docblocks, and the controller does not use them (it imports the Foundation classes). |
| **Reproduce** | Static only — `head -3` of each alias shows no `declare`. |
| **Fix approach** | Add `declare(strict_types=1);` when the files are touched — otherwise churn on files marked for deletion. |
| **Plan item** | none — see plan §10 |

```php
// SchoolDay.php:1-9 — CURRENT (same header in the other two aliases)
<?php

namespace Modules\SmartTimetable\Models;

/**
 * Backward-compatibility alias — model moved to TimetableFoundation.
 * Will be removed in Phase 6 cleanup.
 */
class SchoolDay extends \Modules\TimetableFoundation\Models\SchoolDay
```

**Evidence**
```
$ for f in Modules/SmartTimetable/app/Models/SchoolDay.php Modules/SmartTimetable/app/Models/PeriodSetPeriod.php Modules/SmartTimetable/app/Models/TimetableCell.php; do grep -c "declare(strict_types" "$f"; done
SchoolDay.php:0
PeriodSetPeriod.php:0
TimetableCell.php:0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There are **no mutating methods** in this controller or in its export class/service (confirmed in F2). The eight-question deep read is answered per exported method as a read-only table:

| Method | 1 overwrite? | 2 delete-before-store? | 3 duplicate impl? | 4 soft-delete × unique? | 5 race? | 6 auth hole? | 7 lying message? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `exportPdf` | n/a — no write | n/a | ok — single export path | ok — reads `TimetableCell` (SoftDeletes) — trashed cells hidden by the model | n/a — read only | TEX-01 (view vs export gate) | ok — `generatedAt` matches the band header | ok |
| `exportHtml` | n/a | n/a | ok | ok | n/a | TEX-01 | ok | ok |
| `exportExcel` | n/a | n/a | ok (`TimetableExport` is the one Excel impl) | ok | n/a | TEX-01 | ok | ok |
| `exportTeacherPdf` | n/a | n/a | ok | ok | n/a | TEX-01 | ok | ok |
| `exportTeacherHtml` | n/a | n/a | ok | ok | n/a | TEX-01 | ok | ok |

Deep-read answers beyond the table: **Q2** — nothing is deleted (no files on the write path before the download; the PDF/HTML are rendered in memory). **Q3** — the grid-building logic is duplicated between this controller and `TimetablePreviewController` (documented by the comment at lines 114 and 313), which is the drift source behind earlier export bugs; noted in TEX-02. **Q4** — the soft-delete pivot issue found in the linked Foundation `TimetableCell::teachers()` (see §7) does affect this controller's `$cell->teachers` reads. **Q6** — TEX-01. **Q7** — no user-facing error messages exist on this path. **Q8** — no dead features found; all five exports are referenced from `_export-modal.blade.php:213-218`.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/TimetableFoundation/app/Models/TimetableCell.php:84` | `teachers()` is a `belongsToMany` over the soft-delete pivot `tt_timetable_cell_teachers` without `->wherePivotNull('deleted_at')`; trashed pivot rows still count as teachers in this controller's `$cell->teachers` reads, so a removed teacher can appear in an export. The pivot migration proves `softDeletes()` is present. | MDL-03 | owner: `tarun/TimetableFoundation/TimetableController` |
| `Modules/TimetableFoundation/app/Models/TimetableCell.php:201-209` | `scopeForClass()` queries `class_id`/`section_id` columns that `tt_timetable_cells` does not have (the model's own comment at lines 100-118 documents this). Dead scope — not used by this controller. | MDL-07/CTL-10 | owner: `tarun/TimetableFoundation/TimetableController` |
| `Modules/TimetableFoundation/app/Models/PeriodSetPeriod.php:61-73` | Global scope `ordered` runs three correlated `orderByRaw` subqueries on every query of the model, including this controller's two period loads. Constants only (no user input), so not a security issue — a perf note. | MDL-08/QRY-11 | owner: `tarun/TimetableFoundation/PeriodSetPeriodController` |
| `Modules/SmartTimetable/app/Models/{SchoolDay,PeriodSetPeriod,TimetableCell}.php` | Backward-compatibility aliases; nothing references the SmartTimetable versions of these classes (the controller imports the Foundation classes). Dead once the migration to Foundation is complete (Phase 6). | CTL-10 | this module's cleanup pass |

## 8. Not covered, and why

- **PDF / HTML / Excel rendering was not executed end-to-end.** The tenant has 0 timetables and 0 cells, so none of the five export URLs can be exercised in a browser; blade compilation proves only template syntax, and `Pdf::loadView`/`Excel::download` paths (dompdf, PhpSpreadsheet) were not run. D4 forbids writing tests for this.
- **The `.view`-vs-`.export` divergence is unverifiable live** because every role that holds `tenant.smart-timetable.timetable.view` on test.localhost also holds the other CRUD verbs — no view-only read role exists to prove the bypass in the browser.
- **The two shared partials (`_html-theme`, `_pdf-band`)** were read and grep-checked but not rendered; styling fidelity (CSS classes used by the HTML blobs) was not visually compared.
- **`Modules/SchoolSetup` models (`ClassSection`, `Room`, `Teacher`)** are treated as common and were only checked at the call sites, not audited.