# Final Audit — SmartTimetable / TimetablePreviewController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php` (1,652 lines, 5 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/preview/{timetable}/all-classes` (the read-heavy screen); the four POST endpoints the page's JavaScript calls: `smart-timetable/place-cell`, `remove-cell`, `move-cell`, `toggle-cell-lock` |
| Menu path | Smart Timetable → Timetables → a saved timetable → "All classes" preview |
| Who uses it | Any role granted `tenant.smart-timetable.timetable.view` (read) or `tenant.smart-timetable.timetable.update` (the four edits). Both keys are declared in `config/permissionslist.php` and seeded (exact-name probe returned 1 row each) |
| What a user does here | Opens a saved smart timetable and sees every class-section at once. The page shows the whole school grid (one tab per class-section), a conflicts card, placement diagnostics, and a Vue island. An authorised user can drag a lesson into a slot, remove a lesson, move a lesson, or lock a cell; each edit posts JSON to one of the four endpoints |
| Tables written | `tt_timetable_cells` (fill/clear/move/lock), `tt_timetable_cell_teachers` (re-pointed on place/move/clear), and the activity log written by `activityLog()` |
| Tables read | `tt_timetables`, `tt_timetable_cells`, `tt_timetable_cell_teachers`, `tt_activities`, `tt_activity_teachers`, `tt_conflict_detection`, `tt_class_requirement_subgroups`, `tt_period_set_periods`, `tt_school_days`, `tt_academic_terms`, `sch_class_groups_jnt`, plus the SchoolSetup class-section and room tables |
| Live data | Measured on tenant `xyz_school_00000000000040008000_202627`: `tt_timetables` 0, `tt_timetable_cells` 0, `tt_activities` 0, `tt_conflict_detection` 0, `ClassSection` 43, `tt_period_set_periods` 27. The hosted tenant is empty of timetables, so the screenshots below are static |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready** in its current read-heavy form, but the damage is concentrated in two places, not spread everywhere: the all-classes preview loads the entire school grid without a limit, and the per-write conflict recompute runs a query per cell. The single worst finding is **TPV-01** (H, ERR-00): all four write endpoints still wrap their whole body in a controller try/catch, which is exactly the pattern D1 removed — every non-404 failure is flattened into a generic 500 and logged without a trace. Authorization, transactions and the conflict-service logic are otherwise solid: every routed method gates first, every multi-table write is inside one `DB::transaction`, and the placement service is a single, well-documented implementation. There is also one real stored-XSS vector (**TPV-11**, H) in the class-conflicts partial. Rough effort: **M** — the four catch removals plus the dead-code and cache-key fixes are mechanical; the two performance rewrites are the bulk.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 5 | 6 | 3 | 4 | 14 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TPV-01 | F8 Services/Jobs | clean (see F8) |
| F2 Transactions/Audit | TPV-02 | F9 Queries/Perf | TPV-09, TPV-10 |
| F3 Authorization | TPV-03 | F10 Views | TPV-11 |
| F4 Validation | TPV-04 | F11 Security/Tenancy | TPV-12 |
| F5 Routes | clean (see F5) | F12 Style | TPV-13, TPV-14 |
| F6 Controller shape | TPV-05, TPV-06, TPV-07, TPV-08 | F13 Deep read | see F13 table |
| F7 Models | clean (see F7) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php` | controller | 1652 | this report | ✅ |
| 2 | `Modules/SmartTimetable/app/Services/Preview/PreviewDerivedData.php` | service | 511 | this report (claimed) | ✅ |
| 3 | `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php` | service | 619 | this report (claimed) | ✅ |
| 4 | `Modules/SmartTimetable/app/Services/Preview/PreviewGridState.php` | service | 815 | ↗ [TimetableGenerationController](../TimetableGenerationController-done/01-report.md) | ↗ linked |
| 5 | `Modules/SmartTimetable/app/Services/Preview/SlotOwnerResolver.php` | service | 95 | ↗ [TimetableExportController](../TimetableExportController-done/01-report.md) | ↗ linked |
| 6 | `Modules/SmartTimetable/app/Services/TimetableGenerationService.php` | service | 3287 | ↗ [TimetableGenerationController](../TimetableGenerationController-done/01-report.md) | ↗ linked |
| 7 | `Modules/SmartTimetable/app/Services/Workspace/WorkspaceContext.php` | service | 776 | ↗ [TimetableWorkspaceController](../TimetableWorkspaceController-done/01-report.md) | ↗ linked |
| 8 | `Modules/TimetableFoundation/app/Services/OptionCellResolver.php` | service | 533 | ↗ [TimetableFoundationController](../../TimetableFoundation-done/TimetableFoundationController-done/01-report.md) | ↗ linked |
| 9 | `Modules/SmartTimetable/app/Models/ConflictDetection.php` | model | 155 | ↗ [TimetableGenerationController](../TimetableGenerationController-done/01-report.md) | ↗ linked |
| 10 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | 516 | ↗ [AnalyticsController](../AnalyticsController-done/01-report.md) | ↗ linked |
| 11 | `Modules/TimetableFoundation/app/Models/Activity.php` | model | — | ↗ [TtGenerationStrategyController](../TtGenerationStrategyController-done/01-report.md) | ↗ linked |
| 12 | `Modules/TimetableFoundation/app/Models/SchoolDay.php` | model | — | ↗ [TimetableExportController](../TimetableExportController-done/01-report.md) | ↗ linked |
| 13 | `Modules/TimetableFoundation/app/Models/PeriodSetPeriod.php` | model | — | ↗ [TimetableExportController](../TimetableExportController-done/01-report.md) | ↗ linked |
| 14 | `Modules/TimetableFoundation/app/Models/TimetableCell.php` | model | — | ↗ [TimetableExportController](../TimetableExportController-done/01-report.md) | ↗ linked |
| 15 | `Modules/TimetableFoundation/app/Models/AcademicTerm.php` | model | — | ↗ [TimetableFoundation/AcademicTermController](../../TimetableFoundation-done/AcademicTermController-done/01-report.md) | ↗ linked |
| 16 | `Modules/TimetableFoundation/app/Models/PeriodSet.php` | model | — | ↗ [TimetableFoundation/PeriodSetController](../../TimetableFoundation-done/PeriodSetController-done/01-report.md) | ↗ linked |
| 17 | `Modules/TimetableFoundation/app/Models/TimetableType.php` | model | — | ↗ [TimetableFoundation/TimetableTypeController](../../TimetableFoundation-done/TimetableTypeController-done/01-report.md) | ↗ linked |
| 18 | `Modules/SmartTimetable/resources/views/preview/index.blade.php` | blade | 3311 | ↗ [TimetableGenerationController](../TimetableGenerationController-done/01-report.md) | ↗ linked |
| 19 | `Modules/SmartTimetable/resources/views/preview/partials/_class-conflicts.blade.php` | blade | 596 | this report (claimed) | ✅ |

**Common classes referenced but not audited here** (per `.claude/rules/final-audit.md` §4.2): `App\Http\Controllers\Controller`; `Modules/SchoolSetup/Models/ClassSection` and `Room`; `Modules/Prime/Models/AcademicSession`. No in-scope file appears in a module `PRE-APPLIED-*.md`, so **no pre-applied files**. `_Info/00-CLASS-OWNERS.md` had no row for `PreviewDerivedData.php`, `PreviewPlacementService.php` or `_class-conflicts.blade.php`; this report appended claims for all three.

## 4. Routes

```
GET|HEAD smart-timetable/preview/{timetable}/all-classes   smart-timetable.timetable.preview.allClasses   Modules\SmartTimetable\Http\Controllers\TimetablePreviewController@preview
POST     smart-timetable/place-cell                        smart-timetable.timetable.placeCell            Modules\SmartTimetable\Http\Controllers\TimetablePreviewController@placeCell
POST     smart-timetable/remove-cell                       smart-timetable.timetable.removeCell           Modules\SmartTimetable\Http\Controllers\TimetablePreviewController@removeCell
POST     smart-timetable/move-cell                         smart-timetable.timetable.moveCell             Modules\SmartTimetable\Http\Controllers\TimetablePreviewController@moveCell
POST     smart-timetable/toggle-cell-lock                  smart-timetable.timetable.toggleCellLock       Modules\SmartTimetable\Http\Controllers\TimetablePreviewController@toggleLock
```

Unrouted public methods: none. All five public methods (`preview`, `placeCell`, `removeCell`, `moveCell`, `toggleLock`) have a route. The group sits inside `Route::middleware(['web', 'auth', 'verified', EnsureTenantHasModule::class.':smart-timetable'])->prefix('smart-timetable')` (`Modules/SmartTimetable/routes/web.php:43-44`), so auth and tenancy are present. The old `preview/{timetable}` route now points at `TimetableWorkspaceController@workspace`; only `preview/{timetable}/all-classes` reaches this controller's `preview()`.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `preview` | 46 | GET smart-timetable/preview/{timetable}/all-classes | `tenant.smart-timetable.timetable.view` | none (read path) | none | none (read path) | TPV-05, TPV-06, TPV-09, TPV-10 |
| `placeCell` | 664 | POST smart-timetable/place-cell | `tenant.smart-timetable.timetable.update` | controller line 748 `DB::transaction` | 'Placed' | tt_timetable_cells, tt_timetable_cell_teachers, activity log | TPV-01, TPV-02, TPV-04 |
| `removeCell` | 943 | POST smart-timetable/remove-cell | `tenant.smart-timetable.timetable.update` | controller line 966 `DB::transaction` | 'Removed' | tt_timetable_cells, tt_timetable_cell_teachers, activity log | TPV-01, TPV-02, TPV-04 |
| `moveCell` | 1107 | POST smart-timetable/move-cell | `tenant.smart-timetable.timetable.update` | controller line 1131 `DB::transaction` | 'Moved' | tt_timetable_cells, tt_timetable_cell_teachers, activity log | TPV-01, TPV-02, TPV-04 |
| `toggleLock` | 1388 | POST smart-timetable/toggle-cell-lock | `tenant.smart-timetable.timetable.update` | controller line 1399 `DB::transaction` | 'Locked' / 'Unlocked' | tt_timetable_cells, activity log | TPV-01, TPV-02, TPV-04 |
| `sharedLessonRefusal` (private) | 1344 | not applicable | inherited from caller | none | none | none | none |
| `cellTargets` (private) | 1460 | not applicable | inherited from caller | none | none | none | none |
| `slotOwnerResolver` (private) | 1515 | not applicable | inherited from caller | none | none | none | none |
| `classSectionLabel` (private) | 1525 | not applicable | inherited from caller | none | none | none | TPV-11 |
| `activityPayload` (private) | 1552 | not applicable | inherited from caller | none | none | none | none |
| `loadActivities` (private) | 1602 | not applicable | none | none | none | none | TPV-07 |
| `loadClassSections` (private) | 1625 | not applicable | inherited from caller | none | none | none | none |
| `loadSchoolDays` (private) | 1632 | not applicable | none | none | none | none | TPV-07 |
| `loadPeriodSet` (private) | 1637 | not applicable | none | none | none | none | TPV-07 |

## 6. Findings

### F1 — Errors

#### TPV-01 · H · ERR-00 — four write endpoints still wrap their whole body in a controller try/catch

| Field | Value |
|---|---|
| **Rule** | ERR-00 (H, raised from the rulebook's "open decision" because it is settled here) — final-audit D1: no try/catch in a controller; `DB::transaction()` rolls back by itself and the central handler in `bootstrap/app.php` logs and renders. Also carries ERR-05 (M) — log the exception object, not `getMessage()` |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:681-929` and `955-1081`, `1120-1330`, `1398-1447`; methods `placeCell()`, `removeCell()`, `moveCell()`, `toggleLock()` |
| **Root cause** | These four methods were written to the older Variant-H house rule (try + rethrow 404 + generic catch). Each opens `try {`, runs the write inside `DB::transaction(...)`, then closes with `catch (ModelNotFoundException $e) { throw $e; } catch (\Throwable $e) { Log::error(..., ['error' => $e->getMessage()]); return response()->json(..., 500); }`. D1 removed this pattern because it is a place to get ERR-01..05 wrong |
| **Consequence** | Any non-404 failure on a drag — a `QueryException`, a `TypeError`, a constraint violation — becomes a generic "The operation could not be completed." 500, and the log entry holds only the message with no stack trace, so a teacher's failed edit cannot be diagnosed from the log |
| **Reproduce** | static only — the hosted tenant for test.localhost carries 0 timetables and 0 cells (measured in §0), so no write endpoint can be exercised in the browser |
| **Fix approach** | Remove the four `try`/`catch` wrappers per D1 and let the exceptions reach the central handler. The eight edit points are enumerated in plan item TPV-01 |
| **Plan item** | TPV-01 in `02-fix-plan.md` §3 |
| **Evidence** | `sed -n '916,929p'` on the controller, and `grep -n 'try {\|catch ('` output below |

```php
// TimetablePreviewController.php:916-929 — CURRENT (placeCell)
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic catch
            // below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('TimetablePreviewController::placeCell failed', ['error' => $e->getMessage()]);

            // Declared `: JsonResponse` and called by the grid — a redirect here was a
            // TypeError, and fetch() would have followed it as success.
            return response()->json([
                'success' => false,
                'message' => 'The operation could not be completed.',
            ], 500);
        }
```

**Evidence**
```
$ grep -nE 'try \{|catch \(' Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php
681:        try {
916:        } catch (ModelNotFoundException $e) {
920:        } catch (\Throwable $e) {
955:        try {
1072:        } catch (ModelNotFoundException $e) {
1074:        } catch (\Throwable $e) {
1120:        try {
1321:        } catch (ModelNotFoundException $e) {
1323:        } catch (\Throwable $e) {
1398:        try {
1438:        } catch (ModelNotFoundException $e) {
1440:        } catch (\Throwable $e) {
```

### F2 — Transactions and audit

#### TPV-02 · M · TXN-05 — the HTTP response is built inside the `DB::transaction` closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — the transaction closure returns data; build the `redirect()` / `response()` after it |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:748-915`, and the same shape at `966-1071`, `1131-1320`, `1399-1437` |
| **Root cause** | Each `DB::transaction(function () { ... })` closure ends by returning `response()->json(...)` instead of a plain payload, so the response object is constructed while the transaction is still logically open |
| **Consequence** | No user-visible failure today; the JSON is correct because `DB::transaction` returns whatever the closure returns. It is a rule breach that makes the commit boundary unclear to a reader and blocks later extraction of the closure into a service |
| **Reproduce** | static only — no live timetable data on the hosted tenant |
| **Fix approach** | Return a plain array from each closure and build the `response()->json()` after it. Deferred — see plan §10 |
| **Plan item** | none — see plan §10 |
| **Evidence** | `sed -n '894,914p'` output below |

```php
// TimetablePreviewController.php:894-914 — CURRENT (placeCell, inside the closure)
                return response()->json([
                    'success' => true,
                    'cell_id' => (int) $cell->id,
                    'cell_ids' => collect($cells)->pluck('id')->map(fn ($id) => (int) $id)->all(),
                    'has_conflict' => $conflicts !== [],
                    'conflicts' => $conflicts,
```

**Evidence**
```
$ grep -nE 'return DB::transaction|return response\(\)->json' Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php | head
748:            return DB::transaction(function () use (
894:                return response()->json([
966:            return DB::transaction(function () use ($validated) {
1060:                return response()->json([
1131:            return DB::transaction(function () use ($validated) {
1309:                return response()->json([
1399:            return DB::transaction(function () use ($validated) {
1430:                return response()->json([
```

### F3 — Authorization

#### TPV-03 · M · AUTH-06 — the update permission string is repeated as a literal in four methods

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — permission strings live in one place (a Policy or constants), not repeated as literals in every method |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:666`, `945`, `1109`, `1390` |
| **Root cause** | The literal `tenant.smart-timetable.timetable.update` is typed into each of the four write methods instead of a single constant; the view permission is typed once at line 48 |
| **Consequence** | A rename of the permission key requires four coordinated edits; one missed edit silently gates a write under a name nothing else uses |
| **Reproduce** | static only |
| **Fix approach** | Hold the name in a class constant. Deferred — see plan §10 |
| **Plan item** | none — see plan §10 |
| **Evidence** | `grep -c` below |

```php
// TimetablePreviewController.php:666 — CURRENT
        Gate::authorize('tenant.smart-timetable.timetable.update');
```

**Evidence**
```
$ grep -c "tenant.smart-timetable.timetable.update" Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php
4
```

### F4 — Validation and input

#### TPV-04 · M · VAL-02 — four AJAX write methods validate inline instead of through Form Requests

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — validation lives in a Form Request, not inline `$request->validate()`, except a one-field AJAX toggle |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:668-679`, `947-953`, `1111-1118`, `1392-1396` |
| **Root cause** | All four write methods call `$request->validate([...])` directly. `placeCell` and `moveCell` carry nine and six fields respectively; only `toggleLock` is close to a one-field toggle (it still has three fields) |
| **Consequence** | The rules cannot be reused or unit-checked, cross-field checks have nowhere to live, and two methods that share a field duplicate the rule text |
| **Reproduce** | static only |
| **Fix approach** | Extract the rules into Form Requests. Deferred — the CTL-01 split (TPV-05) will carve the controller into resource controllers, which is the natural point to add the Form Requests. See plan §9 |
| **Plan item** | TPV-04 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `grep -nE 'request\(\)->validate|->validate\('` below |

```php
// TimetablePreviewController.php:668-679 — CURRENT (placeCell)
        $validated = $request->validate([
            'timetable_id' => 'required|integer|exists:tt_timetables,id',
            'activity_id' => 'required|integer|exists:tt_activities,id',
            'day_of_week' => 'required|integer|min:1|max:7',
            'period_ord' => 'required|integer|min:1',
            // The grid the user dropped on. Required: it is what makes a slot a slot.
            'class_id' => 'required|integer',
            'section_id' => 'required|integer',
            'teacher_id' => 'nullable|integer',
            'room_id' => 'nullable|integer',
            'sub_activity_id' => 'nullable|integer',
        ]);
```

**Evidence**
```
$ grep -nE '\$request->validate\(' Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php
668:        $validated = $request->validate([
947:        $validated = $request->validate([
1111:        $validated = $request->validate([
1392:        $validated = $request->validate([
```

### F5 — Routes

clean — `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` piped to a PHP filter for `TimetablePreviewController@` returned the five methods `preview`, `placeCell`, `removeCell`, `moveCell`, `toggleLock` (one route each); `grep -nE 'public function'` on the controller shows exactly those five public methods, so every public method is routed (RTE-03), no GET changes state (RTE-01), and the group at `Modules/SmartTimetable/routes/web.php:43-44` carries `web`, `auth`, `verified` and `EnsureTenantHasModule` (RTE-05).

### F6 — Controller shape

#### TPV-05 · M · CTL-01 — the controller is 1,652 lines, over the 1,000-line threshold

| Field | Value |
|---|---|
| **Rule** | CTL-01 (M) — over 1,000 lines or 25 public methods is a god controller; split by resource/responsibility. Over 2,500 lines is H |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:33` (class body) |
| **Root cause** | One controller serves both the read-heavy all-classes preview and four write endpoints, plus nine private helpers. The class has grown by accretion: large explanatory docblocks inflate the line count, and the write endpoints belong with the workspace controller that already shares them |
| **Consequence** | Every edit risks the read and write paths at once; the file is 1,652 lines, so a reviewer cannot hold it in view |
| **Reproduce** | static only |
| **Fix approach** | Split into a preview controller and a cell-edit controller. DEFERRED per D3 — see plan §9 |
| **Plan item** | TPV-05 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `wc -l` below |

```php
// TimetablePreviewController.php:40-44 — CURRENT (constructor, one of nine injected/declared dependencies)
    public function __construct(
        protected PreviewPlacementService $placement,
        protected PreviewDerivedData $derived,
        protected PreviewGridState $gridState,
    ) {}
```

**Evidence**
```
$ wc -l Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php
1652 Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php
```

#### TPV-06 · H · CTL-02 — four methods exceed the 150-line limit, one by far

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — a method over 80 lines should be extracted; over 150 lines is H |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:46` (`preview`, 579 lines), `664` (`placeCell`, 267), `1107` (`moveCell`, 225), `943` (`removeCell`, 140) |
| **Root cause** | `preview()` builds the whole page payload inline — reference data, grid rebuild, option-block pooling, conflicts, diagnostics, parity shims and the Vue island payload — with no sub-methods. The write methods inline their conflict/refusal handling |
| **Consequence** | A defect anywhere in the page payload is invisible; the method cannot be read or tested in parts, and any change to one panel forces a re-read of the whole 579 lines |
| **Reproduce** | static only |
| **Fix approach** | Extract the payload builders into private methods or a view-model service. Deferred with the CTL-01 split — see plan §9 |
| **Plan item** | TPV-06 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | scan.php output below |

```php
// TimetablePreviewController.php:46-48 — CURRENT
    public function preview(Timetable $timetable)
    {
        Gate::authorize('tenant.smart-timetable.timetable.view');
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json "Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php" | grep -E 'CTL-02|CTL-01'
M  CTL-01   .../TimetablePreviewController.php:33  - — TimetablePreviewController: 1620 lines, 5 public methods
H  CTL-02   .../TimetablePreviewController.php:46  preview — preview() is 579 lines
H  CTL-02   .../TimetablePreviewController.php:664  placeCell — placeCell() is 267 lines
H  CTL-02   .../TimetablePreviewController.php:1107  moveCell — moveCell() is 225 lines
M  CTL-02   .../TimetablePreviewController.php:943  removeCell — removeCell() is 140 lines
```

#### TPV-07 · L · CTL-04 — `preview()` has no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — return types on public methods |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:46` |
| **Root cause** | `preview()` returns either a redirect (via `redirect()->back()` at line 126) or a `View` at line 587, so it was left untyped rather than typed as the union |
| **Consequence** | No runtime effect; the declared contract is missing for the one method a reader meets first |
| **Reproduce** | static only |
| **Fix approach** | Add the union return type `RedirectResponse|View`. See plan item TPV-07 |
| **Plan item** | TPV-07 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n 'public function preview'` below |

```php
// TimetablePreviewController.php:46 — CURRENT
    public function preview(Timetable $timetable)
```

**Evidence**
```
$ grep -nE 'public function [a-z]+\(.*\)$' Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php
46:    public function preview(Timetable $timetable)
```

#### TPV-08 · M · CTL-10 — three private helper methods are never called

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — no dead code: unused private methods |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:1602-1623` (`loadActivities`), `1632-1635` (`loadSchoolDays`), `1637-1651` (`loadPeriodSet`) |
| **Root cause** | `preview()` inlines the school-day, period-set and class-section loads (`SchoolDay::schoolDays()`, `PeriodSetPeriod::with('periodType')...`) and never calls the private helpers; `loadActivities` has no caller at all. They are leftovers of an earlier shape |
| **Consequence** | A reader maintains three methods that cannot affect the page; the inlined loads at lines 58-95 are the real ones, so the two copies can silently drift |
| **Reproduce** | static only |
| **Fix approach** | Delete the three uncalled methods. See plan item TPV-08 |
| **Plan item** | TPV-08 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n` for call sites below |

```php
// TimetablePreviewController.php:1602-1623 — CURRENT (loadActivities, no caller)
    private function loadActivities(
        int $classId,
        int $sectionId
    ): Collection {
        return Activity::where('is_active', true)
            ->where('class_id', $classId)
            ->where('section_id', $sectionId)
            ->with([
                'class',
                'section',
                'subject',
                'studyFormat',
                'subjectStudyFormat.subject',
                'subjectStudyFormat.studyFormat',
                'subjectType',
                'teachers',
                'classGroup',
                'classSubgroup',
            ])
            ->get()
            ->keyBy('id');
    }
```

**Evidence**
```
$ grep -nE '\$this->(loadActivities|loadSchoolDays|loadPeriodSet)\(' Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php
(no output — none of the three is ever called)
```

### F7 — Models

clean (usage) — every model this controller touches is owned by another report (§3) and is audited there; this report checked only how it is used. `TimetableCell`, `Timetable`, `Activity`, `SchoolDay`, `PeriodSetPeriod`, `AcademicTerm`, `PeriodSet` and `TimetableType` are used with explicit `with([...])` eager loads at lines 108-123, 380-384, 417-420 and 560-565, and no write reaches a model with `$request->all()`. Scanner rows for the models were empty: `python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json` on the model paths returned no MDL rows for this scope.

### F8 — Services and jobs

clean (with one dismissed candidate) — `PreviewDerivedData` and `PreviewPlacementService` were read in full. No service calls `request()`, `session()`, `redirect()`, `response()` or `back()` (SVC-01 clean); dependencies arrive by constructor injection (SVC-02 clean); `classGroupIdsFor()` and `classSubgroupIdsFor()` are memoised with a per-process static cache (SVC-05 clean). The scanner flagged `TXN-01` on `PreviewPlacementService::clearCell()` (line 162) and `writeCellTeachers()` (line 596) because each makes two writes with no local transaction — confirmed false positive: `grep -rn 'clearCell(\|writeCellTeachers('` shows the only callers are `placeCell()` (lines 812, 866), `removeCell()` (1029) and `moveCell()` (1261), and every one of those calls sits inside the caller's `DB::transaction()` closure. No job is dispatched by this controller.

### F9 — Queries and performance

#### TPV-09 · H · QRY-01 — `recomputeConflictsAtSlot()` runs a query per cell inside a loop

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — no queries inside loops; eager-load or pre-fetch |
| **Where** | `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php:558-589`, method `recomputeConflictsAtSlot()`; called from the controller at lines 892, 1046, 1290 and 1291 |
| **Root cause** | The method loads every filled cell at one slot and then loops, calling `checkConflicts()` for each cell. `checkConflicts()` itself issues up to two `->get()` queries per call, and the loop then `save()`s each row. The slot is not scoped to the class that changed, so on a whole-school grid the loop walks every class's cell at that slot |
| **Consequence** | A single drag triggers one or two recompute passes, each issuing roughly two selects plus one update per filled cell at the slot. On this tenant's documented 28,848-cell grid the write becomes a multi-hundred-query request and the drag feels stalled |
| **Reproduce** | static only — tenant has 0 cells; the count is structural, not measured live |
| **Fix approach** | Pre-load the slot's cells once (as now) and evaluate conflicts in memory, or refactor `checkConflicts()` to accept the pre-loaded collection. Deferred — see plan §9 |
| **Plan item** | TPV-09 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | scan.php candidates and `grep -n` call sites below |

```php
// PreviewPlacementService.php:567-588 — CURRENT
        foreach ($cells as $cell) {
            if (! $cell->activity_id) {
                continue;
            }

            $conflicts = $this->checkConflicts(
                $timetableId,
                $dayOfWeek,
                $periodOrd,
                $cell->teachers->pluck('id')->map(fn ($id) => (int) $id)->all() ?: null,
                $cell->room_id ? (int) $cell->room_id : null,
                [$cell->id],
                $cell->sub_activity_id ? (int) $cell->sub_activity_id : null,
            );

            $cell->forceFill([
                'has_conflict' => $conflicts !== [],
                'conflict_details_json' => $conflicts !== []
                    ? ['conflict_type' => $conflicts[0]['conflict_type'], 'conflicts' => $conflicts]
                    : null,
            ])->save();
        }
    }
```

**Evidence**
```
$ grep -n 'recomputeConflictsAtSlot(' Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php
892:                $this->placement->recomputeConflictsAtSlot($timetableId, $day, $ord);
1046:                $this->placement->recomputeConflictsAtSlot($timetableId, $day, $ord);
1290:                $this->placement->recomputeConflictsAtSlot($timetableId, $fromDay, $fromOrd);
1291:                $this->placement->recomputeConflictsAtSlot($timetableId, $toDay, $toOrd);
```

#### TPV-10 · M · QRY-02 — `preview()` loads every timetable cell with no bound

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M) — lists are paginated; no unbounded `->get()` feeding a page |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:108-123` |
| **Root cause** | `TimetableCell::with([...])->where('timetable_id', ...)->get()` returns every skeleton row for the timetable — a smart timetable holds one row per class group per slot. The same route's own docblock in `Modules/SmartTimetable/routes/web.php` records the cost: about 60 MB and 28,848 cells per timetable |
| **Consequence** | The all-classes screen builds the whole school grid in memory on every visit; a large school pays a slow, memory-heavy response on the secondary view |
| **Reproduce** | static only — tenant has 0 cells; cost is the route's own documented figure |
| **Fix approach** | The workspace route (`preview/{timetable}`, one class at a time) is already the mitigated path. Accept the all-classes route as a documented tradeoff, or drop it in favour of the workspace. See plan §10 |
| **Plan item** | none — see plan §10 |
| **Evidence** | the quoted query and the route docblock below |

```php
// TimetablePreviewController.php:108-123 — CURRENT
        $cells = TimetableCell::with([
            'activity',
            'activity.class',
            'activity.section',
            'activity.subject',
            'activity.studyFormat',
            'activity.subjectStudyFormat.subject',
            'activity.subjectStudyFormat.studyFormat',
            'activity.requiredRoomType',
            'activity.preferredRoomType',
            'activity.teachers.teacher.user',
            'activity.subActivities',
            'teachers.user',
        ])
            ->where('timetable_id', $timetable->id)
            ->get();
```

**Evidence**
```
$ sed -n '95,99p' Modules/SmartTimetable/routes/web.php
        | A second screen beside preview above, not a replacement for it. The preview route
        | renders EVERY class-section in one response; measured 2026-09-03 that is ~60 MB on
        | this tenant (28,848 cells, 601 activities per timetable), and it put the drop
        | target off-screen from the drag source.
```

### F10 — Views

#### TPV-11 · H · VIEW-03 — the class-conflicts partial prints a partly user-supplied string unescaped

| Field | Value |
|---|---|
| **Rule** | VIEW-03 (H) — `{!! !!}` only for trusted HTML; user-entered text through `{!! !!}` is stored XSS |
| **Where** | `Modules/SmartTimetable/resources/views/preview/partials/_class-conflicts.blade.php:326` (output) built at line 140 (source) |
| **Root cause** | Line 140 builds `$detail` by interpolating `$assignedName` (a teacher's user name) raw into an HTML string; line 326 then outputs `Str::of($cti['detail_html'])->stripTags('<strong><em><br><ul><ol><li><span>')` unescaped. `strip_tags` keeps the listed tags with all their attributes, so an allowed tag carrying an event handler survives |
| **Consequence** | A teacher whose name contains an allowed tag with an event handler (for example a span with an onmouseover attribute) is stored and then executed when another user opens the class-conflicts panel — a stored cross-site-scripting vector |
| **Reproduce** | static only — confirmed by the `php -r` probe below; no live data to render the panel |
| **Fix approach** | Escape the name where `$detail` is assembled (`e($assignedName)`), keeping the intentional bold wrapper. See plan item TPV-10 |
| **Plan item** | TPV-11 in `02-fix-plan.md` §7 |
| **Evidence** | `php -r` `strip_tags` probe below |

```php
// _class-conflicts.blade.php:326 — CURRENT
                                {!! \Illuminate\Support\Str::of($cti['detail_html'])->stripTags('<strong><em><br><ul><ol><li><span>') !!}
```

**Evidence**
```
$ php -r 'echo strip_tags("Bob <span onmouseover=\"alert(1)\">x</span>", "<strong><em><br><ul><ol><li><span>"), PHP_EOL;'
Bob <span onmouseover="alert(1)">x</span>
```

### F11 — Security and tenancy

#### TPV-12 · H · TEN-02 — process-static caches are not keyed by tenant

| Field | Value |
|---|---|
| **Rule** | TEN-02 (H) — cache keys and static/in-memory caches include the tenant (and snapshot where relevant) |
| **Where** | `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php:190` and `222`; `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:1528` |
| **Root cause** | `classSubgroupIdsFor()` and `classGroupIdsFor()` cache on `snapshotId:classId:sectionId` and `classSectionLabel()` caches on `classId:sectionId`, none of which carry the tenant id. The service's own comment says a long-lived process (a queue worker) can serve more than one read, so the static array can outlive a tenant switch |
| **Consequence** | In a long-lived worker or any process that handles two tenants, the first tenant's class-group/subgroup ids are returned for the second — a shared lesson can drop out of a grid or a wrong class label can be printed. A cross-tenant data leak of ids |
| **Reproduce** | static only — no live data; the risk is in the key construction |
| **Fix approach** | Prefix every process-static cache key with the current tenant id. See plan item TPV-11 |
| **Plan item** | TPV-12 in `02-fix-plan.md` §6 |
| **Evidence** | `grep -n 'static \$cache\|$key ='` below |

```php
// PreviewPlacementService.php:190 — CURRENT
        $key = (app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
```

**Evidence**
```
$ grep -nE 'static \$cache|\$key = ' Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php
185:        static $cache = [];
190:        $key = (app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
217:        static $cache = [];
222:        $key = (app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
```

### F12 — Style

#### TPV-13 · L · STY-01 — `declare(strict_types=1)` is missing from all three files

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — `declare(strict_types=1)` in PHP files (touched files) |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:1`, `Modules/SmartTimetable/app/Services/Preview/PreviewDerivedData.php:1`, `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php:1` |
| **Root cause** | None of the three files opens with the declare statement |
| **Consequence** | PHP performs loose scalar coercion; a string id passed where an int is expected is silently cast instead of raising |
| **Reproduce** | static only |
| **Fix approach** | Add the declare line below the opening tag in each of the three files. See plan item TPV-12 |
| **Plan item** | TPV-13 in `02-fix-plan.md` §8 |
| **Evidence** | `head` of each file below |

```php
// TimetablePreviewController.php:1-3 — CURRENT
<?php

namespace Modules\SmartTimetable\Http\Controllers;
```

**Evidence**
```
$ head -3 Modules/SmartTimetable/app/Services/Preview/PreviewDerivedData.php Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php
==> .../PreviewDerivedData.php <==
<?php

namespace Modules\SmartTimetable\Services\Preview;
==> .../PreviewPlacementService.php <==
<?php

namespace Modules\SmartTimetable\Services\Preview;
(no declare(strict_types=1) line in either)
```

#### TPV-14 · L · STY-04 — emoji markers in comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — comments in English, no emoji markers |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php:67`, and the same in `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php:17` and `Modules/SmartTimetable/app/Services/Preview/PreviewDerivedData.php:15`. The controller also carries a commented-out statement at line 130 |
| **Root cause** | Progress markers such as the warning sign, the no-entry sign and the star were left in comments while the code was fixed |
| **Consequence** | No functional effect; it is noise the project's style rule forbids, and the commented-out return at line 130 is dead code |
| **Reproduce** | static only |
| **Fix approach** | Strip the emoji from the comment lines in the three files and delete the commented-out return at line 130. See plan item TPV-13 |
| **Plan item** | TPV-14 in `02-fix-plan.md` §8 |
| **Evidence** | scan.php STY-04 rows below |

```php
// TimetablePreviewController.php:67-70 — CURRENT
            // ⚠ These were NEVER set on this path, and the consequences were
            // visible on screen. The grid body decides a cell's treatment with
            //     $isTeaching = $period->is_teaching ?? ! ($period->is_break ?? false);
            // Both were null, so `?? ! (null ?? false)` evaluated to TRUE and
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json "Modules/SmartTimetable/app/Http/Controllers/TimetablePreviewController.php" "Modules/SmartTimetable/app/Services/Preview/PreviewDerivedData.php" "Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php" | grep -c 'STY-04'
31
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 wrong data | Q2 delete before store | Q3 duplicate impl | Q4 soft-delete x unique | Q5 race | Q6 authz hole | Q7 lying message | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `placeCell` | ok — replacement is scoped to the class-section via `slotCellQuery` and a locked occupant is refused | ok — `clearCell()` runs after every target has agreed, inside the transaction | ok — one implementation in `PreviewPlacementService` | ok — fills the skeleton row rather than inserting beside it | ok — `lockForUpdate()` on the slot and the skeleton | ok — gate first | ok — success only after the writes | TPV-08 (the uncalled loaders) |
| `removeCell` | ok — clears the whole group, not one copy | ok — no delete, the skeleton row is emptied | ok — same service | ok — as above | ok — `lockForUpdate()` | ok — gate first | ok — "already empty" is returned only when truly empty | TPV-08 |
| `moveCell` | ok — carries teacher, room and lock; refuses a locked source | ok — destination filled before source cleared, all inside the transaction | ok — deliberately does not use `RefinementService::moveActivity()` (see docblock) | ok — creates the destination keyed as `chk_cell_target` demands | ok — `lockForUpdate()` on source, moving cells and destination | ok — gate first | ok — `NO_MOVE` and occupied messages are accurate | TPV-08 |
| `toggleLock` | ok — lock is applied to the whole shared group | not applicable — no delete | ok — one implementation | not applicable | ok — `lockForUpdate()` | ok — gate first | ok — event is `Locked`/`Unlocked` matching the state | TPV-08 |

Answers with no finding ID are `ok`, confirmed by reading `Modules/SmartTimetable/app/Services/Preview/PreviewPlacementService.php` lines 80-173 and 455-618. Q4 is not applicable: no soft-delete plus unique-index trap was found on the write path — the skeleton-fill design was built specifically to avoid it.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SchoolSetup/Models/ClassSection` | Used with `with(['class', 'section', 'classTeacher', 'assistanceClassTeacher'])` at 600 rows; not audited here (common) | — | SchoolSetup owner |
| `Modules/Prime/Models/AcademicSession` | Read in tenant context at line 93 without `tenancy()->central()`; common model, not audited here | TEN-03 | Prime owner |
| `preview/index.blade.php` | 3,311-line shared blade; audited "shallow only" by TimetableGenerationController. Linked, not re-audited | — | TimetableGenerationController report |

## 8. Not covered, and why

- **Browser rendering.** The Vue island and the four write endpoints were not exercised; the hosted tenant carries 0 timetables and 0 cells, so there was nothing to render. Every "Reproduce" above is therefore static.
- **Linked classes.** `PreviewGridState`, `SlotOwnerResolver`, `TimetableGenerationService`, `WorkspaceContext`, `OptionCellResolver`, `ConflictDetection`, `Timetable`, `Activity`, `SchoolDay`, `PeriodSetPeriod`, `TimetableCell`, `AcademicTerm`, `PeriodSet`, `TimetableType` and `preview/index.blade.php` are owned by other reports and were not re-audited. Only how this controller calls them was checked, and those checks are clean except as noted.
- **Queue behaviour of the static caches.** TPV-12 is a static key-construction finding; no worker was run to reproduce a cross-tenant hit (D4).
- **Pint.** No file was run through Pint (read-only audit).
- **The `snapshot.read` / `snapshot.readonly` middleware internals.** Out of scope; the route middleware is present and named as required.
