# Fix Plan — SmartTimetable / ConstraintController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php` | Shared by every SmartTimetable controller. Only the DECISION items CST-07/CST-08 (if ticked) may touch it, and only in the exact way the item describes. |
| `resources/views/components/backend/table/action-trashed.blade.php` | Shared component; only DECISION CST-07 (if ticked) names it. |
| `config/permissionslist.php` | Shared; no item needs a new permission key. |
| `Modules/SmartTimetable/app/Models/Constraint.php`, `ConstraintType.php`, `ConstraintCategoryScope.php`, `Activity.php`, `Modules/TimetableFoundation/app/Models/AcademicTerm.php` | Owned by other reports (_Info/00-CLASS-OWNERS.md). |
| `Modules/SmartTimetable/app/Providers/SmartTimetableServiceProvider.php` | Common provider; only DECISION CST-19 (if ticked) names it. |
| `Modules/SmartTimetable/app/Services/Generator/*` (`PrimeSolver`, `PrimeConstraintBridge`, `ImprovedTimetableGenerator`), `TimetableGenerationService.php`, `GenerateTimetableJob.php` | Owned by TimetableGenerationController's report; out of reach except through the DECISIONs' approved scope. |

## 1. Blockers reachable today

- [x] **CST-01** · B · ERR-01 · `ConstraintController.php:217-248` — stop sending the raw exception text to the user in `store()`, remove the controller try/catch (D1) and build the redirect after the closure.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Before** (`ConstraintController.php:217-248`):
    ```php
        try {
            return DB::transaction(function () use ($validated, $paramsJson, $applicableDays) {
                $constraint = Constraint::create([
                    'constraint_type_id' => $validated['constraint_type_id'],
                    'name' => $validated['name'] ?? null,
                    'description' => $validated['description'] ?? null,
                    'academic_term_id' => $validated['academic_term_id'] ?? null,
                    'target_type' => $validated['target_type'],
                    'target_id' => $validated['target_id'] ?? null,
                    'is_hard' => (bool) ($validated['is_hard'] ?? false),
                    'weight' => (int) ($validated['weight'] ?? 100),
                    'params_json' => $paramsJson ?? [],
                    'effective_from' => $validated['effective_from'] ?? null,
                    'effective_to' => $validated['effective_to'] ?? null,
                    'apply_for_all_days' => (bool) ($validated['apply_for_all_days'] ?? true),
                    'applicable_days' => $applicableDays ?: null,
                    'impact_score' => (int) ($validated['impact_score'] ?? 50),
                    'is_active' => (bool) ($validated['is_active'] ?? true),
                    'created_by' => Auth::id(),
                ]);

                // Event is 'Created', NOT the canonical 'Stored'. Deviation is
                // deliberate and pre-existing; the suite asserts what is declared here.
                activityLog($constraint, 'Created', ['message' => 'Constraint created successfully.']);

                return redirect()
                    ->route('smart-timetable.menu.constraintEngine')
                    ->with('success', 'Constraint created successfully.');
            });
        } catch (\Throwable $e) {
            return back()->withInput()->with('error', 'Failed to create constraint: ' . $e->getMessage());
        }
    ```
  - **After:**
    ```php
        $constraint = DB::transaction(function () use ($validated, $paramsJson, $applicableDays) {
            $constraint = Constraint::create([
                'constraint_type_id' => $validated['constraint_type_id'],
                'name' => $validated['name'] ?? null,
                'description' => $validated['description'] ?? null,
                'academic_term_id' => $validated['academic_term_id'] ?? null,
                'target_type' => $validated['target_type'],
                'target_id' => $validated['target_id'] ?? null,
                'is_hard' => (bool) ($validated['is_hard'] ?? false),
                'weight' => (int) ($validated['weight'] ?? 100),
                'params_json' => $paramsJson ?? [],
                'effective_from' => $validated['effective_from'] ?? null,
                'effective_to' => $validated['effective_to'] ?? null,
                'apply_for_all_days' => (bool) ($validated['apply_for_all_days'] ?? true),
                'applicable_days' => $applicableDays ?: null,
                'impact_score' => (int) ($validated['impact_score'] ?? 50),
                'is_active' => (bool) ($validated['is_active'] ?? true),
                'created_by' => Auth::id(),
            ]);

            activityLog($constraint, 'Created', ['message' => 'Constraint created successfully.']);

            return $constraint;
        });

        return redirect()
            ->route('smart-timetable.menu.constraintEngine')
            ->with('success', 'Constraint created successfully.');
    ```
  - **Verify:** `grep -n "getMessage\|try {" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Expect:** the only `getMessage` hits are lines 357 until CST-02 is applied; no `try {` between lines 217 and 248.
  - **Effort:** S

- [x] **CST-02** · B · ERR-01 · `ConstraintController.php:330-358` — stop sending the raw exception text to the user in `update()`, remove the controller try/catch (D1) and build the redirect after the closure.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Before** (`ConstraintController.php:330-358`):
    ```php
        try {
            return DB::transaction(function () use ($validated, $constraint, $paramsJson, $applicableDays) {
                $constraint->update([
                    'constraint_type_id' => $validated['constraint_type_id'],
                    'name' => $validated['name'] ?? $constraint->name,
                    'description' => $validated['description'] ?? $constraint->description,
                    'academic_term_id' => $validated['academic_term_id'] ?? $constraint->academic_term_id,
                    'target_type' => $validated['target_type'],
                    'target_id' => $validated['target_id'] ?? null,
                    'is_hard' => (bool) ($validated['is_hard'] ?? false),
                    'weight' => (int) ($validated['weight'] ?? $constraint->weight),
                    'params_json' => $paramsJson ?? [],
                    'effective_from' => $validated['effective_from'] ?? null,
                    'effective_to' => $validated['effective_to'] ?? null,
                    'apply_for_all_days' => (bool) ($validated['apply_for_all_days'] ?? $constraint->apply_for_all_days),
                    'applicable_days' => $applicableDays ?: null,
                    'impact_score' => (int) ($validated['impact_score'] ?? $constraint->impact_score),
                    'is_active' => (bool) ($validated['is_active'] ?? $constraint->is_active),
                ]);

                activityLog($constraint, 'Updated', ['message' => 'Constraint updated successfully.']);

                return redirect()
                    ->route('smart-timetable.menu.constraintEngine')
                    ->with('success', 'Constraint updated successfully.');
            });
        } catch (\Throwable $e) {
            return back()->withInput()->with('error', 'Failed to update constraint: ' . $e->getMessage());
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($validated, $constraint, $paramsJson, $applicableDays) {
            $constraint->update([
                'constraint_type_id' => $validated['constraint_type_id'],
                'name' => $validated['name'] ?? $constraint->name,
                'description' => $validated['description'] ?? $constraint->description,
                'academic_term_id' => $validated['academic_term_id'] ?? $constraint->academic_term_id,
                'target_type' => $validated['target_type'],
                'target_id' => $validated['target_id'] ?? null,
                'is_hard' => (bool) ($validated['is_hard'] ?? false),
                'weight' => (int) ($validated['weight'] ?? $constraint->weight),
                'params_json' => $paramsJson ?? [],
                'effective_from' => $validated['effective_from'] ?? null,
                'effective_to' => $validated['effective_to'] ?? null,
                'apply_for_all_days' => (bool) ($validated['apply_for_all_days'] ?? $constraint->apply_for_all_days),
                'applicable_days' => $applicableDays ?: null,
                'impact_score' => (int) ($validated['impact_score'] ?? $constraint->impact_score),
                'is_active' => (bool) ($validated['is_active'] ?? $constraint->is_active),
            ]);

            activityLog($constraint, 'Updated', ['message' => 'Constraint updated successfully.']);
        });

        return redirect()
            ->route('smart-timetable.menu.constraintEngine')
            ->with('success', 'Constraint updated successfully.');
    ```
  - **Verify:** `grep -n "getMessage" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Expect:** no output after both CST-01 and CST-02 are applied.
  - **Effort:** S

- [x] **CST-16** · B · DEEP-01 · `ConstraintManager.php:75-81` — make the hard-constraint rejection unconditional instead of gated on `verbose_logging`.
  - **Touches:** `Modules/SmartTimetable/app/Services/Constraints/ConstraintManager.php`
  - **Before** (`ConstraintManager.php:75-81`):
    ```php
            if (!$constraint->passes($slot, $activity, $context)) {
                $this->evaluationCache[$cacheKey] = false;

                if (config('smart_timetable.verbose_logging', false))

                return false;
            }
    ```
  - **After:**
    ```php
            if (!$constraint->passes($slot, $activity, $context)) {
                $this->evaluationCache[$cacheKey] = false;

                return false;
            }
    ```
  - **Verify:** `grep -n "verbose_logging" Modules/SmartTimetable/app/Services/Constraints/ConstraintManager.php`
  - **Expect:** no output (the config guard is gone; `return false;` is unconditional).
  - **Effort:** S

- [x] **CST-17** · B · DEEP-01 · `ConstraintEvaluator.php:97-99` — stop calling the non-static factory method statically.
  - **Touches:** `Modules/SmartTimetable/app/Services/Constraints/ConstraintEvaluator.php`
  - **Before** (`ConstraintEvaluator.php:96-99`):
    ```php
            $memberConstraints = $members->map(function ($m) {
                return ConstraintFactory::createFromDatabase($m->constraint);
            })->filter();
    ```
  - **After:**
    ```php
            $memberConstraints = $members->map(function ($m) {
                return (new ConstraintFactory())->createFromDatabase($m->constraint);
            })->filter();
    ```
  - **Verify:** `grep -n "ConstraintFactory::createFromDatabase" Modules/SmartTimetable/app/Services/Constraints/ConstraintEvaluator.php`
  - **Expect:** no output (the call now instantiates the factory; same namespace, no import needed).
  - **Effort:** S

- [x] **CST-18** · H · DEEP-01 · `ConstraintFactory.php:47-60` — read the model attributes that actually exist when building `_constraint_meta`.
  - **Touches:** `Modules/SmartTimetable/app/Services/Constraints/ConstraintFactory.php`
  - **Before** (`ConstraintFactory.php:47-60`):
    ```php
        $params['_constraint_meta'] = [
            'id' => $constraint->id,
            'uuid' => $constraint->uuid,
            'name' => $constraint->name,
            'description' => $constraint->description,
            'target_type' => $constraint->target_type,
            'target_id' => $constraint->target_id,
            'effective_from' => $constraint->effective_from_date,
            'effective_to'   => $constraint->effective_to_date,
            'applies_to_days' => $constraint->applicable_days_json ?? [],
            'weight' => $constraint->weight,
            'scope' => $constraint->constraintType->scope,
            'category' => $constraint->constraintType->category,
        ];
    ```
  - **After:**
    ```php
        $params['_constraint_meta'] = [
            'id' => $constraint->id,
            'uuid' => $constraint->id,
            'name' => $constraint->name,
            'description' => $constraint->description,
            'target_type' => $constraint->target_type,
            'target_id' => $constraint->target_id,
            'effective_from' => $constraint->effective_from,
            'effective_to'   => $constraint->effective_to,
            'applies_to_days' => $constraint->applicable_days ?? [],
            'weight' => $constraint->weight,
            'scope' => $constraint->constraintType->scope,
            'category' => $constraint->constraintType->category,
        ];
    ```
  - **Verify:** `grep -n "effective_from_date\|effective_to_date\|applicable_days_json" Modules/SmartTimetable/app/Services/Constraints/ConstraintFactory.php`
  - **Expect:** no output.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

(All sequencing happens inside §1/§3; nothing extra here beyond the DECISION items in §9.)

## 3. Errors & transactions (F1/F2)

- [x] **CST-03** · M · ERR-00 (D1) · `ConstraintController.php:377-391` — remove the destroy() try/catch and stop wiping `is_active` on trash so restore can keep the pre-trash state (deep-read Q1).
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Before** (`ConstraintController.php:377-391`):
    ```php
        try {
            DB::transaction(function () use ($constraint) {
                $constraint->is_active = false;
                $constraint->save();
                $constraint->delete();

                activityLog($constraint, 'Trashed', ['message' => 'Constraint moved to trash.']);
            });

            return redirect()
                ->route('smart-timetable.menu.constraintEngine')
                ->with('success', 'Constraint moved to trash.');
        } catch (\Throwable $e) {
            return back()->with('error', 'Failed to trash constraint.');
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($constraint) {
            $constraint->delete();

            activityLog($constraint, 'Trashed', ['message' => 'Constraint moved to trash.']);
        });

        return redirect()
            ->route('smart-timetable.menu.constraintEngine')
            ->with('success', 'Constraint moved to trash.');
    ```
  - **Verify:** `grep -n "is_active = false\|catch (\$e)\|try {" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Expect:** no `is_active = false` and no `try {` between lines 377 and 391.
  - **Effort:** S

- [x] **CST-04** · M · ERR-00 (D1) · `ConstraintController.php:419-433` — remove the restore() try/catch and the forced `is_active = true` so a previously inactive constraint stays inactive after restore.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Before** (`ConstraintController.php:419-433`):
    ```php
        try {
            DB::transaction(function () use ($constraint) {
                $constraint->restore();
                $constraint->is_active = true;
                $constraint->save();

                activityLog($constraint, 'Restored', ['message' => 'Constraint restored successfully.']);
            });

            return redirect()
                ->route('smart-timetable.constraint.trashed')
                ->with('success', 'Constraint restored.');
        } catch (\Throwable $e) {
            return back()->with('error', 'Failed to restore constraint.');
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($constraint) {
            $constraint->restore();

            activityLog($constraint, 'Restored', ['message' => 'Constraint restored successfully.']);
        });

        return redirect()
            ->route('smart-timetable.constraint.trashed')
            ->with('success', 'Constraint restored.');
    ```
  - **Verify:** `grep -n "is_active = true\|catch (\$e)\|try {" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Expect:** no `is_active = true` and no `try {` between lines 419 and 433.
  - **Effort:** S

- [x] **CST-05** · M · ERR-00 (D1) · `ConstraintController.php:454-466` — remove the forceDelete() try/catch and build the redirect after the closure.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Before** (`ConstraintController.php:454-466`):
    ```php
        try {
            return DB::transaction(function () use ($constraint) {
                $constraint->forceDelete();

                activityLog($constraint, 'Deleted', ['message' => 'Constraint permanently deleted.']);

                return redirect()
                    ->route('smart-timetable.constraint.trashed')
                    ->with('success', 'Constraint permanently deleted.');
            });
        } catch (\Throwable $e) {
            return back()->with('error', 'Failed to permanently delete constraint.');
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($constraint) {
            $constraint->forceDelete();

            activityLog($constraint, 'Deleted', ['message' => 'Constraint permanently deleted.']);
        });

        return redirect()
            ->route('smart-timetable.constraint.trashed')
            ->with('success', 'Constraint permanently deleted.');
    ```
  - **Verify:** `grep -n "try {\|catch (\$e)" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Expect:** lines 377-516 show no `try {` before the closures after CST-01..CST-06 are applied.
  - **Effort:** S

- [x] **CST-06** · M · ERR-00 (D1) · `ConstraintController.php:491-516` — remove the toggleStatus() try/catch and the RuntimeException escalation; keep the one-field inline validation (VAL-02 allows it).
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Before** (`ConstraintController.php:491-516`):
    ```php
        try {
            return DB::transaction(function () use ($request, $constraint) {
                $constraint->is_active = $request->boolean('is_active');

                if (!$constraint->save()) {
                    throw new \RuntimeException('Failed to persist the constraint status change.');
                }

                activityLog($constraint, 'Toggled', [
                    'message' => 'Constraint status updated.',
                    'is_active' => $constraint->is_active,
                ]);

                return response()->json([
                    'success' => true,
                    'is_active' => $constraint->is_active,
                    'message' => 'Status updated.',
                ]);
            });
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'is_active' => $constraint->fresh()?->is_active ?? $constraint->is_active,
                'message' => 'Failed to update status.',
            ], 422);
        }
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($request, $constraint) {
            $constraint->is_active = $request->boolean('is_active');
            $constraint->save();

            activityLog($constraint, 'Toggled', [
                'message' => 'Constraint status updated.',
                'is_active' => $constraint->is_active,
            ]);
        });

        return response()->json([
            'success' => true,
            'is_active' => $constraint->is_active,
            'message' => 'Status updated.',
        ]);
    ```
  - **Verify:** `grep -n "RuntimeException\|fresh()" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Expect:** no output (the escalation and the failure re-read are gone).
  - **Effort:** S

- [x] **CST-20** · M · ERR-06 · `ConstraintEvaluator.php:70-77` — stop swallowing soft-constraint scoring failures in an empty catch.
  - **Touches:** `Modules/SmartTimetable/app/Services/Constraints/ConstraintEvaluator.php`
  - **Before** (`ConstraintEvaluator.php:70-77`):
    ```php
            try {
                $weight = $constraint->getWeight();
                if ($constraint->passes($slot, $activity, $context)) {
                    $score += $weight;
                }
            } catch (\Throwable $e) {
            }
    ```
  - **After:**
    ```php
            $weight = $constraint->getWeight();
            if ($constraint->passes($slot, $activity, $context)) {
                $score += $weight;
            }
    ```
  - **Verify:** `grep -n "catch (\\Throwable \$e) {}" Modules/SmartTimetable/app/Services/Constraints/ConstraintEvaluator.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **CST-21** · M · ERR-05 · `DatabaseConstraintService.php:43-48` — log the exception object (with trace) instead of only its message.
  - **Touches:** `Modules/SmartTimetable/app/Services/DatabaseConstraintService.php`
  - **Before** (`DatabaseConstraintService.php:43-48`):
    ```php
            } catch (\Exception $e) {
                \Log::error('Failed to load constraint', [
                    'constraint_id' => $constraint->id,
                    'error' => $e->getMessage(),
                ]);
            }
    ```
  - **After:**
    ```php
            } catch (\Throwable $e) {
                report($e);
                continue;
            }
    ```
  - **Verify:** `grep -n "getMessage\|Log::error" Modules/SmartTimetable/app/Services/DatabaseConstraintService.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

(The AUTH-02 fix is DECISION CST-08 in §9 because it needs route middleware. The AUTH-04 duplicate gate CST-14 is accepted in §10.)

## 5. Validation, routes, models (F4/F5/F7)

- [x] **CST-09** · M · VAL-07 · both constraint requests — a non-GLOBAL constraint must carry a target id; add the cross-field rule to `after()` and `strict_types` headers.
  - **Touches:** `Modules/SmartTimetable/app/Http/Requests/StoreConstraintRequest.php`, `Modules/SmartTimetable/app/Http/Requests/UpdateConstraintRequest.php`
  - **Before** (`StoreConstraintRequest.php:48-61` / `UpdateConstraintRequest.php:45-58`, byte-identical):
    ```php
    public function withValidator($validator): void
    {
        $validator->after(function ($v) {
            foreach (['params_json', 'applicable_days'] as $field) {
                $value = $this->input($field);
                if (is_string($value) && $value !== '') {
                    json_decode($value);
                    if (json_last_error() !== JSON_ERROR_NONE) {
                        $v->errors()->add($field, "Invalid JSON format for {$field}.");
                    }
                }
            }
        });
    }
    ```
  - **After:**
    ```php
    public function withValidator($validator): void
    {
        $validator->after(function ($v) {
            foreach (['params_json', 'applicable_days'] as $field) {
                $value = $this->input($field);
                if (is_string($value) && $value !== '') {
                    json_decode($value);
                    if (json_last_error() !== JSON_ERROR_NONE) {
                        $v->errors()->add($field, "Invalid JSON format for {$field}.");
                    }
                }
            }

            $targetType = $v->getData()['target_type'] ?? null;
            if ($targetType !== Constraint::TARGET_GLOBAL && empty($v->getData()['target_id'] ?? null)) {
                $v->errors()->add('target_id', 'A target id is required for non-global constraints.');
            }
        });
    }
    ```
  - **Before** (both request headers, `StoreConstraintRequest.php:1-3` / `UpdateConstraintRequest.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Http\Requests;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Requests;
    ```
  - **Verify:** `grep -n "A target id is required\|strict_types" Modules/SmartTimetable/app/Http/Requests/*ConstraintRequest.php`
  - **Expect:** each file shows `declare(strict_types=1);` and the new message once; `Constraint` is already imported by both requests (verified).
  - **Effort:** S

- [x] **CST-10** · M · CTL-03 · `ConstraintController.php` — use route model binding in `show`, `edit`, `update`, `destroy` (all four routes already declare `{constraint}`).
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Before** (`show`, `ConstraintController.php:254-271`):
    ```php
    public function show($id)
    {
        Gate::authorize('tenant.smart-timetable.constraint.view');

        // 'scope' was eager-loaded here while target_type held a
        // tt_constraint_category_scopes id. That relation is gone — target_type is
        // now a morph alias — and leaving it in the with() list threw
        // "Call to undefined relationship [scope]", 500-ing every show page.
        //
        // The morph relation is deliberately NOT eager-loaded in its place: a
        // GLOBAL constraint stores target_type = 'GLOBAL', which has no morph-map
        // entry, and Eloquent would try to instantiate it as a class. Read the
        // target through Constraint::resolveTarget(), which guards for that.
        $constraint = Constraint::with(['constraintType.category', 'academicTerm', 'creator'])
            ->findOrFail($id);

        return view('smarttimetable::constraint.show', compact('constraint'));
    }
    ```
  - **After:**
    ```php
    public function show(Constraint $constraint)
    {
        Gate::authorize('tenant.smart-timetable.constraint.view');

        $constraint->load(['constraintType.category', 'academicTerm', 'creator']);

        return view('smarttimetable::constraint.show', compact('constraint'));
    }
    ```
  - **Before** (`edit`, `edit()` signature + body, `ConstraintController.php:276-284`):
    ```php
    public function edit($id)
    {
        Gate::authorize('tenant.smart-timetable.constraint.update');

        $constraint = Constraint::with(['constraintType'])->findOrFail($id);

        return view('smarttimetable::constraint.edit', [
            'constraint' => $constraint,
            'constraintTypes' => ConstraintType::where('is_active', true)->get(),
            // target_type is a morph ALIAS, not a scope id. The blade previously
            // listed ConstraintCategoryScope rows by id, which no form could submit
            // validly once the column became a Laravel morph type.
            'targetTypes' => Constraint::TARGET_TYPES,
            'academicTerms' => AcademicTerm::where('is_active', 1)->limit(10)->get(),
        ]);
    }
    ```
  - **After:**
    ```php
    public function edit(Constraint $constraint)
    {
        Gate::authorize('tenant.smart-timetable.constraint.update');

        $constraint->load(['constraintType']);

        return view('smarttimetable::constraint.edit', [
            'constraint' => $constraint,
            'constraintTypes' => ConstraintType::where('is_active', true)->get(),
            'targetTypes' => Constraint::TARGET_TYPES,
            'academicTerms' => AcademicTerm::where('is_active', 1)->limit(10)->get(),
        ]);
    }
    ```
  - **Before** (`update` signature + lookup, `ConstraintController.php:296-300`):
    ```php
    public function update(UpdateConstraintRequest $request, $id)
    {
        Gate::authorize('tenant.smart-timetable.constraint.update');

        $constraint = Constraint::findOrFail($id);
    ```
  - **After:**
    ```php
    public function update(UpdateConstraintRequest $request, Constraint $constraint)
    {
        Gate::authorize('tenant.smart-timetable.constraint.update');
    ```
  - **Before** (`destroy` signature + lookup, `ConstraintController.php:364-368`):
    ```php
    public function destroy($id)
    {
        Gate::authorize('tenant.smart-timetable.constraint.delete');

        $constraint = Constraint::findOrFail($id);
    ```
  - **After:**
    ```php
    public function destroy(Constraint $constraint)
    {
        Gate::authorize('tenant.smart-timetable.constraint.delete');
    ```
  - **Verify:** `grep -n "public function show\|public function edit\|public function update\|public function destroy" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Expect:** show/edit/update/destroy now receive `Constraint $constraint`; only restore/forceDelete keep `$id` (their route params are `{id}`, deferred in §10).
  - **Effort:** M

## 6. Queries & performance (F9)

- [x] **CST-11** · M · CTL-05 (+ CST-12 QRY-15 folded) · `ConstraintController.php` — extract one private `categoryLookups()` helper that both category methods call, selecting only the columns the blades render.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Before** (`createByCategory` loader block, `ConstraintController.php:56-95`):
    ```php
        $constraintTypes = ConstraintType::active()
            ->whereHas('category', fn($q) => $q->where('code', $categoryCode))
            ->orderBy('name')
            ->get();

        $scopes = ConstraintCategoryScope::active()->ofScope()->get();
        $academicTerms = AcademicTerm::where('is_active', 1)->limit(10)->get();
        $categoryLabel = ucwords(strtolower(str_replace('_', ' ', $categoryCode)));

        $teachers = collect();
        $classes = collect();
        $sections = collect();
        $rooms = collect();
        $activities = collect();

        if ($categoryCode === 'TEACHER_AVAILABILITY') {
            $teachers = Teacher::with('user')->active()->orderBy('id')->get();
        }

        if ($categoryCode === 'STUDENT_CLASS_RULES') {
            $classes = SchoolClass::where('is_active', true)->get();
            $sections = Section::where('is_active', true)->get();
        }

        if ($categoryCode === 'ROOM_SPACE') {
            $rooms = Room::with('building')->where('is_active', true)->get();
        }

        if ($categoryCode === 'INTER_ACTIVITY') {
            $activities = Activity::where('is_active', true)->with(['class', 'section'])->get();
        }
    ```
  - **After:**
    ```php
        $lookups = $this->categoryLookups($categoryCode);
        $constraintTypes = $lookups['constraintTypes'];
        $scopes = $lookups['scopes'];
        $academicTerms = $lookups['academicTerms'];
        $categoryLabel = $lookups['categoryLabel'];
        $teachers = $lookups['teachers'];
        $classes = $lookups['classes'];
        $sections = $lookups['sections'];
        $rooms = $lookups['rooms'];
        $activities = $lookups['activities'];
    ```
  - **Before** (`editByCategory` loader block, `ConstraintController.php:120-151`, same shape as createByCategory plus the orderByDesc line):
    ```php
        $constraintTypes = ConstraintType::active()
            ->whereHas('category', fn($q) => $q->where('code', $categoryCode))
            ->orderBy('name')
            ->get();

        $scopes = ConstraintCategoryScope::active()->ofScope()->get();
        $academicTerms = AcademicTerm::where('is_active', 1)->orderByDesc('start_date')->limit(10)->get();
        $categoryLabel = ucwords(strtolower(str_replace('_', ' ', $categoryCode)));
    ```
  - **After:**
    ```php
        $lookups = $this->categoryLookups($categoryCode);
        $constraintTypes = $lookups['constraintTypes'];
        $scopes = $lookups['scopes'];
        $academicTerms = $lookups['academicTerms'];
        $categoryLabel = $lookups['categoryLabel'];
        $teachers = $lookups['teachers'];
        $classes = $lookups['classes'];
        $sections = $lookups['sections'];
        $rooms = $lookups['rooms'];
        $activities = $lookups['activities'];
    ```
  - **Before** (insert the helper above `normalizeJson`, `ConstraintController.php:521-523`):
    ```php
    /**
     * Normalize a JSON input (array or JSON string) to array.
     * Returns false on invalid JSON, null on empty input.
     */
    private function normalizeJson(mixed $input): array|false|null
    ```
  - **After:**
    ```php
    /**
     * Shared dropdown data for the category create/edit forms (CST-11).
     * Column lists mirror what the constraint-management blades render.
     */
    private function categoryLookups(string $categoryCode): array
    {
        $constraintTypes = ConstraintType::active()
            ->whereHas('category', fn($q) => $q->where('code', $categoryCode))
            ->orderBy('name')
            ->get(['id', 'name']);

        $scopes = ConstraintCategoryScope::active()->ofScope()->get();
        $academicTerms = AcademicTerm::where('is_active', 1)->orderByDesc('start_date')->limit(10)->get(['id', 'term_name']);
        $categoryLabel = ucwords(strtolower(str_replace('_', ' ', $categoryCode)));

        $teachers = collect();
        $classes = collect();
        $sections = collect();
        $rooms = collect();
        $activities = collect();

        if ($categoryCode === 'TEACHER_AVAILABILITY') {
            $teachers = Teacher::with('user:id,name')->active()->orderBy('id')->get(['id']);
        }

        if ($categoryCode === 'STUDENT_CLASS_RULES') {
            $classes = SchoolClass::where('is_active', true)->get(['id', 'name']);
            $sections = Section::where('is_active', true)->get(['id', 'name']);
        }

        if ($categoryCode === 'ROOM_SPACE') {
            $rooms = Room::with('building:id,name')->where('is_active', true)->get(['id', 'name']);
        }

        if ($categoryCode === 'INTER_ACTIVITY') {
            $activities = Activity::where('is_active', true)->get(['id', 'name', 'code']);
        }

        return compact('constraintTypes', 'scopes', 'academicTerms', 'categoryLabel', 'teachers', 'classes', 'sections', 'rooms', 'activities');
    }

    /**
     * Normalize a JSON input (array or JSON string) to array.
     * Returns false on invalid JSON, null on empty input.
     */
    private function normalizeJson(mixed $input): array|false|null
    ```
  - **Verify:** `grep -n "categoryLookups" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Expect:** three hits (one definition, one call in createByCategory, one call in editByCategory); both `with(['class', 'section'])` Activity eager loads are gone.
  - **Effort:** M

## 7. Views (F10)

(No view items — the constraint blades are clean.)

## 8. Style (F12) — one item per file

- [x] **CST-15** · L · STY-01 / STY-04 · `ConstraintController.php` — add `declare(strict_types=1);` after the opening tag and drop the `⚠` emoji marker from the toggleStatus comment.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Before** (`ConstraintController.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Http\Controllers;
    ```
  - **Before** (`ConstraintController.php:480`):
    ```php
        // ⚠ Rule A3 — activityLog now runs AFTER save(), not before it.
    ```
  - **After:**
    ```php
        // Rule A3 — activityLog now runs AFTER save(), not before it.
    ```
  - **Verify:** `grep -n "strict_types\|⚠" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php`
  - **Expect:** `declare(strict_types=1);` on line 3 and no `⚠` in the file.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **CST-07** · H · DECISION · RTE-01 — move `restore` from GET to POST so a state change stops riding on a no-CSRF verb.
  - **Why it is a decision:** touches the shared route file and the shared `action-trashed` component, and changes the trash page's Restore interaction.
  - (a) ⭐ Change `Route::get('/constraint/{id}/restore'...)` to `Route::post(...)`, name unchanged, and make the shared `x-backend.table.action-trashed` component submit restore as POST; the component change is then used by the other trash pages in this module.
  - (b) Keep the router but add a state-change guard/middleware that rejects non-POST restore requests — no UI change, but the GET link still prefetches a 405.
  - (c) Leave as-is and record the risk (bad link prefetchers aside, CSRF is the blocker).
  - ➜ Choice: (a), but as PUT not POST (Tarun 2026-10-15). No component edit was needed — `action-trashed` reads the verb from the route.

- [x] **CST-08** · H · DECISION · AUTH-02 — authorize before the model is loaded on the two route-bound methods.
  - **Why it is a decision:** the clean fix moves authorization into the route layer (`can:` middleware), which touches the shared route file and changes where the 403 is produced.
  - (a) ⭐ Add `->middleware('can:tenant.smart-timetable.constraint.update')` to the `editByCategory` and `toggleStatus` routes and delete the in-method `Gate::authorize` lines; the FormRequest/route middleware owns the 403 before the model resolves.
  - (b) Revert `editByCategory`/`toggleStatus` to `$id` + `findOrFail` after the in-method Gate — removes the oracle without touching the route file, but undoes the binding CST-10 keeps for the other four methods.
  - (c) Leave as-is (the oracle is only visible to users who are already logged in but lack the update permission).
  - ➜ Choice: (b) — switched from the recommended (a): `SubstituteBindings` runs BEFORE the `can:` middleware (vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php:113-114), so (a) would still 404 before it 403s. Gate first, then `findOrFail($id)`; no route-file change.

- [x] **CST-19** · H · DECISION · DEEP-01 — make the six live constraint types map to classes that actually enforce the stored rules.
  - **Why it is a decision:** changes generator results (timetables that currently ignore lunch/break/limits will start honouring them); needs new mappings and real `passes()` implementations, and re-verifying with a generated timetable.
  - (a) ⭐ Rebuild the resolution: register the real `tt_constraint_types` codes (`LUNCH_BREAK_FIXED`, `SHORT_BREAK_FIXED`, `MAX_LESSONS_PER_DAY`, `NO_TEACHER_GAPS`, `NO_CONSECUTIVE_SAME_SUBJECT`, `TEACHER_FREE_PERIOD_PER_HALF`) to dedicated classes in `SmartTimetableServiceProvider`/`ConstraintFactory`, implement each `passes()` from the stored params (`period_type_code`, `max_lessons`, ...), and remove the dead legacy map keys.
  - (b) Teach `GenericHardConstraint`/`GenericSoftConstraint` to interpret the stored param keys generically (period_type_code blocking, max counts against solver context) — smaller change, but every rule stays fuzzy.
  - (c) Accept constraints as decorative until the generator rewrite, and add an engine-readiness warning in the UI.
  - ➜ Choice: Deferred — not applied (Tarun 2026-10-15: bug fixes only). Neither the rebuild nor option (c)'s UI warning was added.

- [x] **CST-22** · M · DECISION · SVC-04 — one evaluation engine, one context contract.
  - **Why it is a decision:** architectural; both engines are referenced by different code and unifying them changes the generated-timetable behaviour.
  - (a) ⭐ Keep `ConstraintManager` (the engine `PrimeSolver` imports), unify `ConstraintContext::toArray()` with `buildContextArray()` (one shape: `TEACHER` as array), and delete or fully align `ConstraintEvaluator` so its defects (CST-17/CST-20) cannot re-enter.
  - (b) Move `PrimeSolver` onto `ConstraintEvaluator` instead — larger blast radius, no benefit over (a).
  - (c) Leave both engines; document the divergence and fix only the landmine (CST-17).
  - ➜ Choice: (c) — both engines kept; only the landmines fixed (CST-17, CST-20).

- [x] **CST-23** · M · DECISION · DEEP-01 — the individual constraint classes need one base and a documented context contract.
  - **Why it is a decision:** a 70-file refactor with engine risk; the sampled defects (copy-pasted constructors, `$context->teacherOccupied` / `$context->periods` reads that silently no-op) need the contract question answered first.
  - (a) ⭐ Add an abstract base (owns `$meta`/`$params` and the constructor), define the context object contract (which arrays PrimeSolver must supply), and convert all Hard/Soft classes onto it; until then, fix only the sampled `TeacherMaxGapsPerDayConstraint` and `GenericHardConstraint` reads to check the context shape explicitly.
  - (b) Fix only the two sampled reads now and defer the base-class refactor to the generator rewrite.
  - (c) Leave as-is; the classes are mostly unreachable because of CST-19 anyway.
  - ➜ Choice: (b) — the two sampled context reads fixed (TeacherMaxGapsPerDayConstraint, GenericHardConstraint); base-class refactor deferred.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CST-12 | Folded into CST-11 — the extracted `categoryLookups()` helper selects only the columns the blades render (`id`,`name`,`code`) for teachers/classes/sections/rooms/activities, so the QRY-15 fix lands with the CTL-05 extraction in one edit of the same lines. |
| CST-13 | Accepted (L) — the six mutating methods gain their declared return types implicitly when items CST-01..CST-06 rewrite them if Tarun chooses to add them there; the remaining read methods are low-risk and stay as-is until a style pass. |
| CST-14 | Accepted (L) — the double authorization (FormRequest `authorize()` plus in-method `Gate::authorize`) is harmless; removing the FormRequest check would weaken the request classes, and removing the in-method Gate would move the 403 earlier — both are cosmetic. |