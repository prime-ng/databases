# Fix Plan — SmartTimetable / ConstraintCategoryScopeController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/SmartTimetable/routes/web.php` (every line except 260) | shared route file — only CCS-06 may change line 260 |
| `resources/views/components/backend/table/action-trashed.blade.php` | shared common component — CCS-06 needs no change here |
| `config/permissionslist.php` | shared permission config — all eight keys already exist and are seeded |
| `database/migrations/**` | no migration is written in this pass; CCS-09 is a DECISION only |
| `final-audit-reports/_Info/00-CLASS-OWNERS.md` | append-only registry (this report already claimed both models) |

## 1. Blockers reachable today

None — there is no B-severity finding. The highest-severity item (CCS-06, high) is in §5.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [x] **CCS-01** · M · ERR-00 (D1) · `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php:44-68, 96-124, 134-158, 184-207, 217-241, 251-282` — delete the six controller `try/catch` blocks (D1), move `findOrFail()` above the transaction, and build the redirect/JSON after the closure (this single rewrite also clears CCS-02 and CCS-03).
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php`
  - **Before** (`ConstraintCategoryScopeController.php:44-68`, method `store`):
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.create');

        try {
            return DB::transaction(function () use ($request) {
                $record = ConstraintCategoryScope::create([
                    'type' => $request->validated('type'),
                    'code' => $request->validated('code'),
                    'name' => $request->validated('name'),
                    'description' => $request->validated('description'),
                    'is_active' => $request->boolean('is_active'),
                ]);

                activityLog($record, 'Stored', [
                    'message' => "Constraint {$this->label($record->type)} was created successfully.",
                ]);

                return redirect()
                    ->route('smart-timetable.menu.constraintEngine', ['tab' => 'category-scope'])
                    ->with('success', flash('created.constraint_category_scope'));
            });
        } catch (\Throwable $e) {
            Log::error('ConstraintCategoryScope store failed', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', flash('operation_failed.constraint_category_scope'));
        }
    ```
  - **After:**
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.create');

        $record = DB::transaction(function () use ($request) {
            $record = ConstraintCategoryScope::create([
                'type' => $request->validated('type'),
                'code' => $request->validated('code'),
                'name' => $request->validated('name'),
                'description' => $request->validated('description'),
                'is_active' => $request->boolean('is_active'),
            ]);

            activityLog($record, 'Stored', [
                'message' => "Constraint {$this->label($record->type)} was created successfully.",
            ]);

            return $record;
        });

        return redirect()
            ->route('smart-timetable.menu.constraintEngine', ['tab' => 'category-scope'])
            ->with('success', flash('created.constraint_category_scope'));
    ```
  - **Before** (`ConstraintCategoryScopeController.php:96-124`, method `update`):
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.update');

        try {
            $record = ConstraintCategoryScope::findOrFail($id);

            return DB::transaction(function () use ($request, $record) {
                $record->update([
                    'type' => $request->validated('type'),
                    'code' => $request->validated('code'),
                    'name' => $request->validated('name'),
                    'description' => $request->validated('description'),
                    'is_active' => $request->boolean('is_active'),
                ]);

                activityLog($record, 'Updated', [
                    'message' => "Constraint {$this->label($record->type)} was updated successfully.",
                ]);

                return redirect()
                    ->route('smart-timetable.menu.constraintEngine', ['tab' => 'category-scope'])
                    ->with('success', flash('updated.constraint_category_scope'));
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('ConstraintCategoryScope update failed', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->withInput()->with('error', flash('operation_failed.constraint_category_scope'));
        }
    ```
  - **After:**
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.update');

        $record = ConstraintCategoryScope::findOrFail($id);

        DB::transaction(function () use ($request, $record) {
            $record->update([
                'type' => $request->validated('type'),
                'code' => $request->validated('code'),
                'name' => $request->validated('name'),
                'description' => $request->validated('description'),
                'is_active' => $request->boolean('is_active'),
            ]);

            activityLog($record, 'Updated', [
                'message' => "Constraint {$this->label($record->type)} was updated successfully.",
            ]);
        });

        return redirect()
            ->route('smart-timetable.menu.constraintEngine', ['tab' => 'category-scope'])
            ->with('success', flash('updated.constraint_category_scope'));
    ```
  - **Before** (`ConstraintCategoryScopeController.php:134-158`, method `destroy`):
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.delete');

        try {
            $record = ConstraintCategoryScope::findOrFail($id);

            return DB::transaction(function () use ($record) {
                $record->is_active = false;
                $record->save();
                $record->delete();

                activityLog($record, 'Trashed', [
                    'message' => "Constraint {$this->label($record->type)} was deactivated and moved to trash.",
                ]);

                return redirect()
                    ->route('smart-timetable.menu.constraintEngine', ['tab' => 'category-scope'])
                    ->with('success', flash('trashed.constraint_category_scope'));
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('ConstraintCategoryScope destroy failed', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', flash('operation_failed.constraint_category_scope'));
        }
    ```
  - **After:**
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.delete');

        $record = ConstraintCategoryScope::findOrFail($id);

        DB::transaction(function () use ($record) {
            $record->is_active = false;
            $record->save();
            $record->delete();

            activityLog($record, 'Trashed', [
                'message' => "Constraint {$this->label($record->type)} was deactivated and moved to trash.",
            ]);
        });

        return redirect()
            ->route('smart-timetable.menu.constraintEngine', ['tab' => 'category-scope'])
            ->with('success', flash('trashed.constraint_category_scope'));
    ```
  - **Before** (`ConstraintCategoryScopeController.php:184-207`, method `forceDelete`):
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.forceDelete');

        try {
            $record = ConstraintCategoryScope::withTrashed()->findOrFail($id);
            $label = $this->label($record->type);

            return DB::transaction(function () use ($record, $label) {
                $record->forceDelete();

                activityLog($record, 'Deleted', [
                    'message' => "Constraint {$label} was permanently deleted.",
                ]);

                return redirect()
                    ->route('smart-timetable.constraint-category-scope.trashed')
                    ->with('success', flash('force_deleted.constraint_category_scope'));
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('ConstraintCategoryScope forceDelete failed', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', flash('operation_failed.constraint_category_scope'));
        }
    ```
  - **After:**
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.forceDelete');

        $record = ConstraintCategoryScope::withTrashed()->findOrFail($id);
        $label = $this->label($record->type);

        DB::transaction(function () use ($record, $label) {
            $record->forceDelete();

            activityLog($record, 'Deleted', [
                'message' => "Constraint {$label} was permanently deleted.",
            ]);
        });

        return redirect()
            ->route('smart-timetable.constraint-category-scope.trashed')
            ->with('success', flash('force_deleted.constraint_category_scope'));
    ```
  - **Before** (`ConstraintCategoryScopeController.php:217-241`, method `restore`):
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.restore');

        try {
            $record = ConstraintCategoryScope::onlyTrashed()->findOrFail($id);

            return DB::transaction(function () use ($record) {
                $record->restore();
                $record->is_active = true;
                $record->save();

                activityLog($record, 'Restored', [
                    'message' => "Constraint {$this->label($record->type)} was restored successfully.",
                ]);

                return redirect()
                    ->route('smart-timetable.constraint-category-scope.trashed')
                    ->with('success', flash('restored.constraint_category_scope'));
            });
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('ConstraintCategoryScope restore failed', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', flash('operation_failed.constraint_category_scope'));
        }
    ```
  - **After:**
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.restore');

        $record = ConstraintCategoryScope::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($record) {
            $record->restore();
            $record->is_active = true;
            $record->save();

            activityLog($record, 'Restored', [
                'message' => "Constraint {$this->label($record->type)} was restored successfully.",
            ]);
        });

        return redirect()
            ->route('smart-timetable.constraint-category-scope.trashed')
            ->with('success', flash('restored.constraint_category_scope'));
    ```
  - **Before** (`ConstraintCategoryScopeController.php:251-282`, method `toggleStatus`):
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.update');

        $request->validate(['is_active' => 'required|boolean']);

        try {
            $record = ConstraintCategoryScope::findOrFail($id);
            $record->is_active = $request->boolean('is_active');

            DB::transaction(function () use ($record) {
                $record->save();

                activityLog($record, 'Toggled', [
                    'message' => "Constraint {$this->label($record->type)} status was updated.",
                    'is_active' => $record->is_active,
                ]);
            });

            return response()->json([
                'success' => true,
                'is_active' => $record->is_active,
                'message' => flash('status_updated.constraint_category_scope'),
            ]);
        } catch (ModelNotFoundException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('ConstraintCategoryScope toggleStatus failed', ['id' => $id, 'error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => flash('status_switch_failed.constraint_category_scope'),
            ], 422);
        }
    ```
  - **After:**
    ```php
        Gate::authorize('tenant.smart-timetable.constraint-category-scope.update');

        $request->validate(['is_active' => 'required|boolean']);

        $record = ConstraintCategoryScope::findOrFail($id);
        $record->is_active = $request->boolean('is_active');

        DB::transaction(function () use ($record) {
            $record->save();

            activityLog($record, 'Toggled', [
                'message' => "Constraint {$this->label($record->type)} status was updated.",
                'is_active' => $record->is_active,
            ]);
        });

        return response()->json([
            'success' => true,
            'is_active' => $record->is_active,
            'message' => flash('status_updated.constraint_category_scope'),
        ]);
    ```
  - **Verify:** `grep -n "try {\|catch (" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php`
  - **Expect:** no output.
  - **Effort:** M

## 4. Authorization (F3)

- [x] **CCS-04** · L · AUTH-04 · `Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php:13-19` — stop authorizing the same permission twice; keep the controller's `Gate::authorize()` and make the FormRequest's `authorize()` return true.
  - **Touches:** `Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php`
  - **Before** (`ConstraintCategoryScopeRequest.php:13-19`):
    ```php
        public function authorize(): bool
        {
            if ($this->isMethod('POST')) {
                return auth()->user()->can('tenant.smart-timetable.constraint-category-scope.create');
            }
            return auth()->user()->can('tenant.smart-timetable.constraint-category-scope.update');
        }
    ```
  - **After:**
    ```php
        public function authorize(): bool
        {
            // Authorization is enforced once, by Gate::authorize() in the controller
            // (CCS-04, 2026-10-10); this FormRequest must not check it a second time.
            return true;
        }
    ```
  - **Verify:** `grep -n "authorize\|can(" Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php`
  - **Expect:** the `authorize()` method contains `return true;` and no `->can(` call.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [x] **CCS-06** · H · RTE-01 · `Modules/SmartTimetable/routes/web.php:260` — register the restore route as POST, not GET, so a state change can no longer be triggered by a prefetch or an unconfirmed fetch. **⚠ SHARED** — route file.
  - **Touches:** `Modules/SmartTimetable/routes/web.php`
  - **Before** (`web.php:260`):
    ```php
            Route::get('/constraint-category-scope/{id}/restore', [ConstraintCategoryScopeController::class, 'restore'])->name('constraint-category-scope.restore');
    ```
  - **After:**
    ```php
            Route::post('/constraint-category-scope/{id}/restore', [ConstraintCategoryScopeController::class, 'restore'])->name('constraint-category-scope.restore');
    ```
  - **Verify:** `grep -n "constraint-category-scope/{id}/restore" Modules/SmartTimetable/routes/web.php`
  - **Expect:** one line whose verb is `Route::post(`.
  - **Effort:** S

- [x] **CCS-05** · M · VAL-05 · `Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php:51` — type the `is_active` field so a non-boolean value is rejected instead of silently coerced to false.
  - **Touches:** `Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php`
  - **Before** (`ConstraintCategoryScopeRequest.php:50-51`):
    ```php
                'description' => ['nullable', 'string', 'max:255'],
                'is_active'   => ['nullable'],
    ```
  - **After:**
    ```php
                'description' => ['nullable', 'string', 'max:255'],
                'is_active' => ['nullable', 'boolean'],
    ```
  - **Verify:** `grep -n "is_active" Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php`
  - **Expect:** the rule line reads `'is_active' => ['nullable', 'boolean'],`.
  - **Effort:** S

- [x] **CCS-08** · L · CTL-04 · `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php:18, 25, 42, 71, 80, 94, 132, 161, 182, 215, 249` — declare a return type on every public method.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php`
  - **Before** (`ConstraintCategoryScopeController.php:5-14`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\SmartTimetable\Http\Requests\ConstraintCategoryScopeRequest;
    use Modules\SmartTimetable\Models\ConstraintCategoryScope;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Contracts\View\View;
    use Illuminate\Database\Eloquent\ModelNotFoundException;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\SmartTimetable\Http\Requests\ConstraintCategoryScopeRequest;
    use Modules\SmartTimetable\Models\ConstraintCategoryScope;
    ```
  - **Before** (`ConstraintCategoryScopeController.php:18`):
    ```php
        public function index()
    ```
  - **After:**
    ```php
        public function index(): RedirectResponse
    ```
  - **Before** (`ConstraintCategoryScopeController.php:25`):
    ```php
        public function create()
    ```
  - **After:**
    ```php
        public function create(): never
    ```
  - **Before** (`ConstraintCategoryScopeController.php:42`):
    ```php
        public function store(ConstraintCategoryScopeRequest $request)
    ```
  - **After:**
    ```php
        public function store(ConstraintCategoryScopeRequest $request): RedirectResponse
    ```
  - **Before** (`ConstraintCategoryScopeController.php:71`):
    ```php
        public function show($id)
    ```
  - **After:**
    ```php
        public function show($id): View
    ```
  - **Before** (`ConstraintCategoryScopeController.php:80`):
    ```php
        public function edit($id)
    ```
  - **After:**
    ```php
        public function edit($id): View
    ```
  - **Before** (`ConstraintCategoryScopeController.php:94`):
    ```php
        public function update(ConstraintCategoryScopeRequest $request, $id)
    ```
  - **After:**
    ```php
        public function update(ConstraintCategoryScopeRequest $request, $id): RedirectResponse
    ```
  - **Before** (`ConstraintCategoryScopeController.php:132`):
    ```php
        public function destroy($id)
    ```
  - **After:**
    ```php
        public function destroy($id): RedirectResponse
    ```
  - **Before** (`ConstraintCategoryScopeController.php:161`):
    ```php
        public function trashed(Request $request)
    ```
  - **After:**
    ```php
        public function trashed(Request $request): View
    ```
  - **Before** (`ConstraintCategoryScopeController.php:182`):
    ```php
        public function forceDelete($id)
    ```
  - **After:**
    ```php
        public function forceDelete($id): RedirectResponse
    ```
  - **Before** (`ConstraintCategoryScopeController.php:215`):
    ```php
        public function restore($id)
    ```
  - **After:**
    ```php
        public function restore($id): RedirectResponse
    ```
  - **Before** (`ConstraintCategoryScopeController.php:249`):
    ```php
        public function toggleStatus(Request $request, $id)
    ```
  - **After:**
    ```php
        public function toggleStatus(Request $request, $id): JsonResponse
    ```
  - **Verify:** `grep -nE "public function (index|create|store|show|edit|update|destroy|trashed|forceDelete|restore|toggleStatus)\(" Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php`
  - **Expect:** no output (every signature now ends with a return type).
  - **Effort:** S

## 6. Queries & performance (F9)

None.

## 7. Views (F10)

None — the three views are clean.

## 8. Style (F12) — one item per file

- [x] **CCS-10** · L · STY-01/STY-02/STY-04 · `Modules/SmartTimetable/app/Models/Constraint.php:1-14, 183` — add `declare(strict_types=1)`, import `Model`, replace the three `⚠` markers, and run Pint (which sorts imports and un-aligns the `=>` blocks).
  - **Touches:** `Modules/SmartTimetable/app/Models/Constraint.php`
  - **Before** (`Constraint.php:1-14`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Models;

    use Modules\SchoolSetup\Models\User;
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\MorphTo;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\SchoolSetup\Models\Room;
    use Modules\SchoolSetup\Models\SchoolClass;
    use Modules\SchoolSetup\Models\Teacher;
    use Modules\TimetableFoundation\Models\AcademicTerm;
    use Modules\TimetableFoundation\Models\Activity;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Model;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\MorphTo;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\SchoolSetup\Models\Room;
    use Modules\SchoolSetup\Models\SchoolClass;
    use Modules\SchoolSetup\Models\Teacher;
    use Modules\SchoolSetup\Models\User;
    use Modules\TimetableFoundation\Models\AcademicTerm;
    use Modules\TimetableFoundation\Models\Activity;
    ```
  - **Before** (`Constraint.php:183`):
    ```php
        public function resolveTarget(): ?\Illuminate\Database\Eloquent\Model
    ```
  - **After:**
    ```php
        public function resolveTarget(): ?Model
    ```
  - **Note:** replace the `⚠` at lines 129, 141 and 177 with `Warning:`; run `vendor/bin/pint Modules/SmartTimetable/app/Models/Constraint.php --format agent` to un-align the `TARGET_MORPH_MAP` and `$casts` arrays.
  - **Verify:** `vendor/bin/pint --test Modules/SmartTimetable/app/Models/Constraint.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

- [x] **CCS-11** · L · STY-01/STY-02 · `Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php:1, 14-15, 26` — add `declare(strict_types=1)` and run Pint (which separates the constants and un-aligns the `$casts` key).
  - **Touches:** `Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php`
  - **Before** (`ConstraintCategoryScope.php:1-3`):
    ```php
    <?php

    namespace Modules\SmartTimetable\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\SmartTimetable\Models;
    ```
  - **Before** (`ConstraintCategoryScope.php:14-15`):
    ```php
        public const TYPE_CATEGORY = 'CATEGORY';
        public const TYPE_SCOPE    = 'SCOPE';
    ```
  - **After:**
    ```php
        public const TYPE_CATEGORY = 'CATEGORY';

        public const TYPE_SCOPE = 'SCOPE';
    ```
  - **Before** (`ConstraintCategoryScope.php:26`):
    ```php
            'is_active'  => 'boolean',
    ```
  - **After:**
    ```php
            'is_active' => 'boolean',
    ```
  - **Verify:** `vendor/bin/pint --test Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

- [x] **CCS-12** · L · STY-02 · `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php:168` — add the space the Laravel preset requires after `fn`.
  - **Touches:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php`
  - **Before** (`ConstraintCategoryScopeController.php:168`):
    ```php
                    fn($q) => $q->where('type', $this->resolveType($request->input('type')))
    ```
  - **After:**
    ```php
                    fn ($q) => $q->where('type', $this->resolveType($request->input('type')))
    ```
  - **Note:** if CCS-01 is ticked, run `vendor/bin/pint` on this file instead; it also removes the `ModelNotFoundException` import that CCS-01 leaves unused.
  - **Verify:** `vendor/bin/pint --test Modules/SmartTimetable/app/Http/Controllers/ConstraintCategoryScopeController.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** S

- [x] **CCS-13** · L · STY-02 · `Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php:23` — un-align the `$id` assignment so the file is Pint-clean (the `authorize()` blank-line hunk is removed by CCS-04 and the `is_active` alignment by CCS-05).
  - **Touches:** `Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php`
  - **Before** (`ConstraintCategoryScopeRequest.php:23`):
    ```php
            $id   = $this->route('constraint_category_scope') ?? $this->route('id');
    ```
  - **After:**
    ```php
            $id = $this->route('constraint_category_scope') ?? $this->route('id');
    ```
  - **Verify:** `vendor/bin/pint --test Modules/SmartTimetable/app/Http/Requests/ConstraintCategoryScopeRequest.php --format agent`
  - **Expect:** `"result":"pass"` (after CCS-04 and CCS-05 are applied).
  - **Effort:** S

## 9. Deferred / decisions

- [x] **CCS-07** · M · DECISION · CTL-03 — the seven `$id` methods use `findOrFail()` instead of route model binding. Convert them?
  - **Why it is a decision:** binding the four resource methods needs no route change (their parameter is already `constraint_category_scope`), but binding `restore`/`forceDelete`/`toggleStatus` requires renaming their `{id}` route parameters, which is a route-file change.
  - (a) ⭐ bind the four resource methods now (`show`, `edit`, `update`, `destroy`) with a typed `ConstraintCategoryScope $constraintCategoryScope` argument; leave the three trash methods on `$id` and record why.
  - (b) rename the three trash route parameters to `{constraint_category_scope}` and bind all seven (touches the shared route file).
  - (c) leave all seven as they are and record the manual `findOrFail()` as accepted.
  - ➜ Choice: (a) — `show`/`edit`/`update`/`destroy` bound to `ConstraintCategoryScope $constraintCategoryScope`; `restore`/`forceDelete`/`toggleStatus` stay on `$id`. Applied 2026-10-15.

- [x] **CCS-09** · M · DECISION · TXN-06 — `name` uniqueness is enforced only in the FormRequest; two concurrent creates can store the same name. Fix the race or accept it?
  - **Why it is a decision:** a true fix is a new unique index on `(type, name)`, which is an additive migration (Tarun's hand) and re-opens the soft-delete interaction with the index.
  - (a) ⭐ accept for now — this is a single-admin config screen and sequential duplicates are already blocked; add a one-line code comment naming CCS-09 next to the `name` rule.
  - (b) add a unique index on `(type, name)` in an additive migration and mirror it in the rule with `whereNull('deleted_at')`.
  - (c) wrap the create in a `lockForUpdate()` transaction instead of a DB index.
  - ➜ Choice: (a) — accepted; CCS-09 comment beside the `name` rule in ConstraintCategoryScopeRequest.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CCS-02 | covered by **CCS-01**: deleting the six `try/catch` blocks removes every `Log::error(..., ['error' => $e->getMessage()])` call, so the trace is no longer dropped. |
| CCS-03 | covered by **CCS-01**: the rewrite returns the record from `DB::transaction()` and builds the `redirect()` / `response()->json()` after the closure. |
