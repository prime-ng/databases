# Final Audit — TenantCore / EvaluationController

**Audited:** 2026-10-15 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/TenantCore/app/Http/Controllers/EvaluationController.php` (150 lines, 7 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /tenantcore/evaluation/{context}/{owner}/queue`, `GET …/scripts/{subject}`, `POST …/scripts/{subject}/mark`, `POST …/scripts/{subject}/annotations`, `POST …/scripts/{subject}/meta`, `POST …/scripts/{subject}/flag`, `POST …/scripts/{subject}/finalize` (all JSON; route prefix `tenantcore.`) |
| Menu path | No menu entry. These are the AJAX endpoints of the shared paper-evaluator (Vue app `pe-*.js`), embedded in the evaluator screens of the Exam / Quest / Homework / Admission modules. |
| Who uses it | Teachers / exam evaluators who hold the context's permission (e.g. `tenant.lms-exam.exam.update` for Exam, `tenant.lms-exam.exam.viewAny` to read the queue). The permission is enforced by the concrete driver, not by this controller. |
| What a user does here | A teacher opens the paper evaluator, reads the queue of students' attempts, opens one script, marks each question, draws annotations and comments over the scanned pages, sets flags (e.g. UFM), writes a script comment, and clicks a finalize button that writes the result and locks the script. Every call here returns JSON the Vue app renders. |
| Tables written | `lms_eval_scripts` (ScriptService), `lms_eval_annotations` (AnnotationService, AnnotationBurnService), `lms_eval_audit` (AuditService). Plus the context's own answer/result tables, written by the concrete driver (other modules). |
| Tables read | Same three `lms_eval_*` tables, plus whatever the driver reads (e.g. `lms_exam_attempts`, `lms_exam_results`). |
| Live data | ⚠ UNVERIFIED — tenant-DB row counts of `lms_eval_scripts` / `lms_eval_annotations` were not measured; this read-only pass used static evidence and did not open a tenant connection. A tenant `SELECT COUNT(*)` would settle it. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready until EVL-02 is decided: a locking finalize burns the annotations into the student's **PDF inside the database transaction**, so a later failure rolls the database back while the file on disk stays rewritten — the two disagree permanently.

The controller itself is small, well-structured, and delegates authorization correctly to `$driver->authorize()` before it loads any record, so the "no authorization" scanner hits are false positives (F3 explains why). The real defects live one layer down in the shared service classes: a multi-row annotation autosave with no transaction (EVL-03), a non-atomic two-write block in `ScriptService::open()` (EVL-04), and two logs that record only the exception message and lose the stack trace (EVL-01, EVL-08).

Rough effort: S. Eight mechanical plan items plus one decision; none needs a migration.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 1 | 4 | 3 | 1 | 9 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | EVL-01 | F8 Services/Jobs | EVL-08 |
| F2 Transactions/Audit | EVL-02, EVL-03, EVL-04 | F9 Queries/Perf | EVL-03 (shared with F2) |
| F3 Authorization | clean | F10 Views | clean (no views) |
| F4 Validation | EVL-05 | F11 Security/Tenancy | clean |
| F5 Routes | EVL-06 | F12 Style | EVL-09 |
| F6 Controller shape | EVL-07 | F13 Deep read | table in §6 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

Resolved mechanically with §4.1 (`route:list` + `grep public function` + imports), then walked outward through the injected services and the classes they reach. Note: the brief's short path `Modules/TenantCore/Evaluation/**` is really `Modules/TenantCore/app/Evaluation/**`; the real paths are used below.

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TenantCore/app/Http/Controllers/EvaluationController.php` | controller | 150 | this report | ✅ |
| 2 | `Modules/TenantCore/app/Http/Requests/Evaluation/ItemMarkRequest.php` | FormRequest | 39 | this report | ✅ |
| 3 | `Modules/TenantCore/app/Http/Requests/Evaluation/AnnotationsRequest.php` | FormRequest | 26 | this report | ✅ |
| 4 | `Modules/TenantCore/app/Http/Requests/Evaluation/FinalizeRequest.php` | FormRequest | 28 | this report | ✅ |
| 5 | `Modules/TenantCore/app/Http/Requests/Evaluation/FlagRequest.php` | FormRequest | 25 | this report | ✅ |
| 6 | `Modules/TenantCore/app/Http/Requests/Evaluation/ScriptMetaRequest.php` | FormRequest | 24 | this report | ✅ |
| 7 | `Modules/TenantCore/app/Evaluation/Contracts/EvaluationDriver.php` | contract | 97 | this report | ✅ |
| 8 | `Modules/TenantCore/app/Evaluation/Contracts/TotalsRule.php` | contract | 13 | this report | ✅ |
| 9 | `Modules/TenantCore/app/Evaluation/Registry/EvaluationRegistry.php` | registry | 57 | this report | ✅ |
| 10 | `Modules/TenantCore/app/Evaluation/Services/EvaluationService.php` | service | 111 | this report | ✅ |
| 11 | `Modules/TenantCore/app/Evaluation/Services/ScriptService.php` | service | 123 | this report | ✅ |
| 12 | `Modules/TenantCore/app/Evaluation/Services/AnnotationService.php` | service | 114 | this report | ✅ |
| 13 | `Modules/TenantCore/app/Evaluation/Services/AuditService.php` | service | 29 | this report | ✅ |
| 14 | `Modules/TenantCore/app/Evaluation/Services/AnnotationBurnService.php` | service | 251 | this report | ✅ |
| 15 | `Modules/TenantCore/app/Evaluation/Totals/TotalsCalculator.php` | totals | 70 | this report | ✅ |
| 16 | `Modules/TenantCore/app/Evaluation/Totals/TotalsResult.php` | totals | 28 | this report | ✅ |
| 17 | `Modules/TenantCore/app/Evaluation/Totals/TotalsState.php` | totals | 25 | this report | ✅ |
| 18 | `Modules/TenantCore/app/Evaluation/Totals/TotalsLine.php` | totals | 40 | this report | ✅ |
| 19 | `Modules/TenantCore/app/Evaluation/Totals/Rules/StepSum.php` | totals rule | 31 | this report | ✅ |
| 20 | `Modules/TenantCore/app/Evaluation/Totals/Rules/NotAttempted.php` | totals rule | 22 | this report | ✅ |
| 21 | `Modules/TenantCore/app/Evaluation/Totals/Rules/NegativeMarking.php` | totals rule | 22 | this report | ✅ |
| 22 | `Modules/TenantCore/app/Evaluation/Totals/Rules/MaxCap.php` | totals rule | 26 | this report | ✅ |
| 23 | `Modules/TenantCore/app/Evaluation/Totals/Rules/ChoiceDiscard.php` | totals rule | 47 | this report | ✅ |
| 24 | `Modules/TenantCore/app/Evaluation/Models/EvalScript.php` | model | 51 | this report | ✅ |
| 25 | `Modules/TenantCore/app/Evaluation/Models/EvalAnnotation.php` | model | 45 | this report | ✅ |
| 26 | `Modules/TenantCore/app/Evaluation/Models/EvalAudit.php` | model | 19 | this report | ✅ |
| 27 | `Modules/TenantCore/app/Evaluation/Drivers/AbstractEvaluationDriver.php` | driver base | 122 | this report | ✅ |
| 28 | `Modules/TenantCore/app/Evaluation/Exceptions/EvaluationException.php` | exception | 36 | this report | ✅ |
| 29 | `Modules/TenantCore/app/Evaluation/Data/QueueEntry.php` | DTO | 23 | this report | ✅ |
| 30 | `Modules/TenantCore/app/Evaluation/Data/MarkData.php` | DTO | 46 | this report | ✅ |
| 31 | `Modules/TenantCore/app/Evaluation/Data/ScriptData.php` | DTO | 53 | this report | ✅ |
| 32 | `Modules/TenantCore/app/Evaluation/Data/ItemData.php` | DTO | 40 | this report | ✅ |
| 33 | `Modules/TenantCore/app/Evaluation/Data/Capabilities.php` | DTO | 77 | this report | ✅ |
| 34 | `Modules/TenantCore/app/Evaluation/Data/FinalizeAction.php` | DTO | 35 | this report | ✅ |
| 35 | `Modules/TenantCore/app/Evaluation/Data/FlagType.php` | DTO | 23 | this report | ✅ |
| 36 | `Modules/TenantCore/app/Evaluation/Data/AnswerData.php` | DTO | 39 | this report | ✅ |
| 37 | `Modules/TenantCore/app/Evaluation/Data/ChoiceGroupData.php` | DTO | 20 | this report | ✅ |
| 38 | `Modules/TenantCore/app/Evaluation/Data/StepData.php` | DTO | 20 | this report | ✅ |
| 39 | `Modules/TenantCore/app/Evaluation/Data/QuestionPrompt.php` | DTO | 25 | this report | ✅ |
| 40 | `Modules/TenantCore/app/Evaluation/Data/FileData.php` | DTO | 22 | this report | ✅ |
| 41 | `Modules/TenantCore/app/Evaluation/Events/ItemMarked.php` | event | 21 | this report | ✅ |
| 42 | `Modules/TenantCore/app/Evaluation/Events/ScriptFinalized.php` | event | 21 | this report | ✅ |
| 43 | `Modules/TenantCore/app/Evaluation/Events/ScriptFlagged.php` | event | 20 | this report | ✅ |

No in-scope file appears in a module `PRE-APPLIED-*.md`. No in-scope class is listed in `final-audit-reports/_Info/00-CLASS-OWNERS.md` — none is `↗ linked`; every class above is audited fully here. (The main session appends the CLASS-CLAIMS from the hand-back.)

The concrete drivers (`ExamEvaluationDriver`, `OfflineExamEvaluationDriver`, `OfflineBulkExamEvaluationDriver`, `HomeworkEvaluationDriver`, `QuestEvaluationDriver`, `AdmissionEvaluationDriver`) live in **other modules** and only reach this subsystem at runtime; they are recorded as cross-cutting (§7), not audited here.

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache2.php php artisan route:list --json | (filter EvaluationController@)
GET|HEAD  tenantcore/evaluation/{context}/{owner}/queue                  tenantcore.evaluation.queue          Modules\TenantCore\Http\Controllers\EvaluationController@queue
GET|HEAD  tenantcore/evaluation/{context}/{owner}/scripts/{subject}      tenantcore.evaluation.script         Modules\TenantCore\Http\Controllers\EvaluationController@script
POST      tenantcore/evaluation/{context}/{owner}/scripts/{subject}/mark          tenantcore.evaluation.mark        EvaluationController@mark
POST      tenantcore/evaluation/{context}/{owner}/scripts/{subject}/annotations   tenantcore.evaluation.annotations EvaluationController@annotations
POST      tenantcore/evaluation/{context}/{owner}/scripts/{subject}/meta          tenantcore.evaluation.meta        EvaluationController@meta
POST      tenantcore/evaluation/{context}/{owner}/scripts/{subject}/flag          tenantcore.evaluation.flag        EvaluationController@flag
POST      tenantcore/evaluation/{context}/{owner}/scripts/{subject}/finalize      tenantcore.evaluation.finalize    EvaluationController@finalize
```

Middleware on **all seven** routes (from `route:list`): `web`, `Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains`, `Stancl\Tenancy\Middleware\InitializeTenancyByDomain`, `App\Http\Middleware\SetTenantAuthGuard`, `App\Http\Middleware\EnsureTenantIsActive`, `Illuminate\Auth\Middleware\Authenticate`, `Illuminate\Auth\Middleware\EnsureEmailIsVerified`. Tenant-aware and behind `auth` — RTE-05 satisfied.

Unrouted public methods: none. All 7 public methods are routed; `run()` is `private` (line 123).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `queue` | 40 | GET …/queue | `$driver->authorize('view', …)` → e.g. `tenant.lms-exam.exam.viewAny` | none (read) | none | none | EVL-07 |
| `script` | 49 | GET …/scripts/{subject} | `view` | none; `open()` INSERTs a draft row | none | `lms_eval_scripts`, `lms_eval_audit` | EVL-06 |
| `mark` | 67 | POST …/mark | `mark` → e.g. `tenant.lms-exam.exam.update` | `EvaluationService::markItem` L42 | EvalAudit `field='mark'` (AuditService) | `lms_eval_scripts`, `lms_eval_audit`, driver tables | — |
| `annotations` | 75 | POST …/annotations | `mark` | none | none | `lms_eval_annotations` | EVL-03 |
| `meta` | 86 | POST …/meta | `mark` | none | EvalAudit `field='comment'` (only if comment set) | `lms_eval_scripts`, `lms_eval_audit` | — |
| `flag` | 102 | POST …/flag | `flag` → `update` | none | EvalAudit `field='flag'` | `lms_eval_scripts`, `lms_eval_audit` | — |
| `finalize` | 114 | POST …/finalize | `finalize` → `update` | `EvaluationService::finalize` L79 | EvalAudit `field='status'` | `lms_eval_scripts`, `lms_eval_annotations` (burn soft-delete), `lms_eval_audit`, driver tables | EVL-02 |

Notes for F2: this subsystem does **not** call the app-wide `activityLog()` helper; it writes its own append-only change history through `AuditService::record()` (table `lms_eval_audit`). That audit row is written **after** the mutation and **inside** the surrounding transaction in `markItem`/`finalize`, so TXN-04 holds for those two. `annotations`, `meta` and `flag` have no surrounding transaction (EVL-03/EVL-04).

## 6. Findings

### F1 — Errors

#### EVL-01 · M · ERR-05 — the controller's generic catch logs only the exception message and swallows the trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace.* Also D1 (ERR-00): a controller `try/catch` is a finding unless it is a D2 shape — the generic catch here is not. |
| **Where** | `Modules/TenantCore/app/Http/Controllers/EvaluationController.php:144-147`, method `run()` |
| **Root cause** | The catch-all branch logs `['error' => $e->getMessage()]` (no exception object, so no stack trace) and converts every unexpected throwable into a generic 500. The `catch (ModelNotFoundException $e) { throw $e; }` above it is a rethrow that does nothing. Under D1 the whole block is a controller try/catch that is not one of the D2 shapes (D2 allows a `\DomainException` business-rule catch; `EvaluationException` currently extends `RuntimeException`). |
| **Consequence** | A production 500 from this endpoint leaves a one-line message in the log with no file/line or stack, so the failure cannot be reproduced; and the controller owns an error path that D1 assigns to the central handler. |
| **Reproduce** | Static only — the branch fires only when `$work()` throws a non-domain exception, which no seeded input triggers without a code fault. |
| **Fix approach** | Make `EvaluationException` extend `\DomainException` so the remaining catch is a D2 shape, delete the `ModelNotFoundException` rethrow and the `\Throwable` catch, and let the central handler in `bootstrap/app.php` log and render unexpected failures. |
| **Plan item** | EVL-01 in `02-fix-plan.md` §3 |

```php
// EvaluationController.php:144-147 — CURRENT
        } catch (\Throwable $e) {
            Log::error('EvaluationController failed', ['context' => $context, 'owner' => $owner, 'subject' => $subject, 'error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => 'The operation could not be completed.'], 500);
        }
```

**Evidence**
```
$ grep -n "getMessage\|catch (" Modules/TenantCore/app/Http/Controllers/EvaluationController.php
136:        } catch (EvaluationException $e) {
139:                'message' => $e->getMessage(),
140:                'errors' => [$e->field ?? 'general' => [$e->getMessage()]],
142:        } catch (ModelNotFoundException $e) {
144:        } catch (\Throwable $e) {
145:            Log::error('EvaluationController failed', ['context' => $context, 'owner' => $owner, 'subject' => $subject, 'error' => $e->getMessage()]);
```

Note on the two lines at 139-140 (the domain catch): the messages returned there are the subsytem's own authored business messages (e.g. "Marks must be between 0 and 10."), so they are safe to show once `EvaluationException` is a `\DomainException` (D2). The scanner's ERR-01 `L` row for line 137 is therefore treated as intentional, folded into this item.

### F2 — Transactions and audit

#### EVL-02 · B · TXN-03 — a locking finalize rewrites the student's PDF inside the database transaction

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B) — *no irreversible side effect inside a transaction or before the write succeeds: file deletes, mail, SMS, push, HTTP. Do them after commit.* |
| **Where** | `Modules/TenantCore/app/Evaluation/Services/EvaluationService.php:97-99` (the call), inside `DB::transaction(...)` opening at line 79; the file write is `AnnotationBurnService::storeBurnedFile()` at `AnnotationBurnService.php:72`; the transaction closes at line 104. |
| **Root cause** | `$this->burner->burn(...)` is called inside the `DB::transaction` closure. `burn()` renders each PDF and then calls `$driver->storeBurnedFile(...)`, which writes the new bytes to disk (`AnnotationBurnService.php:72`). A file write cannot be rolled back. If `ScriptFinalized::dispatch($script, …)` on line 101 (or any listener, or the commit itself) fails, the database rolls back to draft, but the PDF on disk has already been overwritten with the burned annotations. |
| **Consequence** | A teacher sees the script still open/draft and re-submits, while the copy on disk already carries the burned stamps; the burned annotation rows were rolled back too, so the overlay reappears over a PDF that already has the marks — duplicated marks on the student's copy. |
| **Reproduce** | Static only — triggering the rollback needs a listener or commit failure; no request alone shows it. |
| **Fix approach** | Decide how to make the burn survive-safe: render inside the transaction but write the files after commit (`DB::afterCommit()`), or accept the current order and document it. This is a **DECISION** because the fix changes ordering semantics for the audit row and the annotation soft-delete (see plan §1). |
| **Plan item** | EVL-02 in `02-fix-plan.md` §1 (DECISION) |

```php
// EvaluationService.php:96-104 — CURRENT
            if ($actionDef->burnsAnnotations()) {
                $this->burner->burn($driver, $script, $ownerId, $subjectId);
            }

            ScriptFinalized::dispatch($script, $action, $totals);

            return $totals;
        });
```

**Evidence**
```
$ sed -n '79p;97,99p;104p' Modules/TenantCore/app/Evaluation/Services/EvaluationService.php
        return DB::transaction(function () use ($driver, $ownerId, $subjectId, $action, $actionDef, $input) {
            if ($actionDef->burnsAnnotations()) {
                $this->burner->burn($driver, $script, $ownerId, $subjectId);
            }
        });
$ sed -n '72p' Modules/TenantCore/app/Evaluation/Services/AnnotationBurnService.php
            $burned[$ref] = $driver->storeBurnedFile($ownerId, $subjectId, $ref, $bytes);
```

#### EVL-03 · H · TXN-01 — the annotation autosave writes up to 500 rows with no transaction and one SELECT per row

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write runs inside one `DB::transaction`*, also QRY-01 (H) — *no queries inside loops*. |
| **Where** | `Modules/TenantCore/app/Evaluation/Services/AnnotationService.php:31-52`, method `sync()`; called from `EvaluationController::annotations()` at `EvaluationController.php:80` with no surrounding transaction. |
| **Root cause** | `sync()` loops over `$upserts` and, per row, issues a `SELECT …->first()` (line 40) and then an `update()` (line 42) or `create()` (line 44). Nothing wraps the loop in a transaction, so a `clean()` validation failure on row N (line 39 throws) leaves rows 1…N-1 already committed — a partially applied autosave. The per-row `SELECT` is an N+1 (up to 500 selects for one save). |
| **Consequence** | When one annotation in a paste is rejected, the teacher's canvas shows some stamps saved and others silently missing after reload, with no way to tell which; and a large autosave fires hundreds of queries. |
| **Reproduce** | POST a large `upserts` array whose last element has an invalid `uid` or an out-of-range `x`, then GET the script: earlier annotations are present, later ones are not. |
| **Fix approach** | Wrap the whole sync body in `DB::transaction`, and pre-load the existing rows for the incoming uids in ONE query (`whereIn('client_uid', …)->get()->keyBy('client_uid')`) instead of one `first()` per row. |
| **Plan item** | EVL-03 in `02-fix-plan.md` §3 |

```php
// AnnotationService.php:38-45 — CURRENT
        foreach ($upserts as $i => $a) {
            $row = $this->clean($a, $allowedTools, $i);
            $existing = EvalAnnotation::where('script_id', $script->id)->where('client_uid', $row['client_uid'])->first();
            if ($existing) {
                $existing->update($row + ['updated_by' => $userId]);
            } else {
                EvalAnnotation::create($row + ['script_id' => $script->id, 'created_by' => $userId, 'updated_by' => $userId]);
            }
        }
```

**Evidence**
```
$ grep -n "DB::transaction\|->first()\|->update(\|->create(" Modules/TenantCore/app/Evaluation/Services/AnnotationService.php
40:            $existing = EvalAnnotation::where('script_id', $script->id)->where('client_uid', $row['client_uid'])->first();
42:                $existing->update($row + ['updated_by' => $userId]);
44:                EvalAnnotation::create($row + ['script_id' => $script->id, 'created_by' => $userId, 'updated_by' => $userId]);
$ grep -n "sync(" Modules/TenantCore/app/Http/Controllers/EvaluationController.php
80:            $this->annotations->sync($script, (array) $request->validated('upserts', []), (array) $request->validated('deletes', []), $driver->allowedTools());
```
No `DB::transaction` line appears in `AnnotationService.php`, proving the loop is unwrapped.

#### EVL-04 · M · TXN-01 — `ScriptService::open()` writes the lock transition and its audit row without a transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (M) — *a model write plus its audit row runs inside one `DB::transaction`* (lowered from H: this branch runs only when a context enables `lock_from_subject` and the subject is already locked — a rare path). |
| **Where** | `Modules/TenantCore/app/Evaluation/Services/ScriptService.php:32-37`, method `open()` |
| **Root cause** | When `lock_from_subject` is enabled and the subject is locked elsewhere, `open()` updates `lms_eval_scripts` (line 35) and then inserts the `lms_eval_audit` row (line 36) with no transaction around the pair. `open()` is called from `EvaluationService::script()` (GET), and from `meta()`/`flag()`/`annotations()` outside any transaction. If the audit insert fails, the status change is committed with no history row. |
| **Consequence** | The script is silently locked with no audit entry, so a later reviewer cannot tell why the script became read-only. |
| **Reproduce** | Static only — needs the `lock_from_subject` capability plus a subject whose `ScriptData::$locked` is true, then a failing audit insert. |
| **Fix approach** | Wrap the status update and the `audit->record()` call in one `DB::transaction` (safe whether or not an outer transaction already exists). |
| **Plan item** | EVL-04 in `02-fix-plan.md` §3 |

```php
// ScriptService.php:32-37 — CURRENT
        if (! $script->isLocked() && $driver->capabilities()->enabled('lock_from_subject')
            && $driver->loadScript($ownerId, $subjectId)->locked) {
            $old = $script->status;
            $script->update(['status' => EvalScript::STATUS_LOCKED, 'locked_at' => now(), 'updated_by' => $userId]);
            $this->audit->record($script, 'status', $old, $script->status, null, 'finalized outside the evaluator');
        }
```

**Evidence**
```
$ grep -n "DB::transaction\|firstOrCreate\|audit->record\|->update(" Modules/TenantCore/app/Evaluation/Services/ScriptService.php
24:        $script = EvalScript::firstOrCreate(
35:            $script->update(['status' => EvalScript::STATUS_LOCKED, 'locked_at' => now(), 'updated_by' => $userId]);
36:            $this->audit->record($script, 'status', $old, $script->status, null, 'finalized outside the evaluator');
```
No `DB::transaction` line appears in `ScriptService.php`.

TXN-06 clean: `EvalScript::firstOrCreate()` (line 24) is safe under concurrency because Laravel 12 routes it through `createOrFirst()`, which catches `UniqueConstraintViolationException` and re-queries — proven by `vendor/laravel/framework/src/Illuminate/Database/Eloquent/Builder.php:722-728`.

### F3 — Authorization

clean — every routed method authorizes through the driver **before** it loads any record.

```
$ sed -n '125,135p' Modules/TenantCore/app/Http/Controllers/EvaluationController.php
        if (! EvaluationRegistry::has($context)) {
            abort(404);
        }
        $driver = EvaluationRegistry::driver($context);

        if (! $driver->authorize($ability, $owner, $subject, auth()->user())) {
            abort(403);
        }

        try {
            return response()->json(['success' => true] + $work($driver));
```

The scanner flags AUTH-01 **B** on all seven methods ("no authorization"); that is a false positive because the scanner cannot follow the delegation. `run()` (lines 125-132) resolves the driver, calls `$driver->authorize($ability, $owner, $subject, auth()->user())`, and only then enters `$work()`. The concrete driver enforces both the permission and the owner→subject scoping — e.g. `ExamEvaluationDriver::authorize()` (lines 81-94, other module): `Gate::forUser($user)->allows('tenant.lms-exam.exam.update')` plus `ExamAttempt::whereKey($subject)->where('exam_paper_id', $owner)->exists()`. `abort(403)`/`abort(404)` are raised **before** the `try` (lines 126, 131), so they are never swallowed. AUTH-04 clean (the FormRequests' `authorize()` return `true`; they do not duplicate a permission check). AUTH-05/AUTH-06: no `Gate::any`, no literal permission strings in this controller — the strings live in the drivers' `private const` (cross-cutting, §7).

### F4 — Validation and input

#### EVL-05 · L · VAL-05 — `FinalizeRequest` accepts a free-form `input` array whose values are untyped

| Field | Value |
|---|---|
| **Rule** | VAL-05 (L) — *every field is typed; a write path with no validation at all is H.* Lowered to L because the concrete drivers coerce each key they read before use. |
| **Where** | `Modules/TenantCore/app/Http/Requests/Evaluation/FinalizeRequest.php:24-25` |
| **Root cause** | `'input' => ['nullable','array','max:20']` and `'input.*' => ['nullable']` place no type or size limit on the values, and the request cannot know which keys a driver reads. The values reach `$driver->finalize(..., $input)`. |
| **Consequence** | A client can send a nested value (e.g. `input.remarks = [...]`) which a driver casts with `(string)` to the literal `"Array"`; the drivers all truncate with `mb_substr`, so no unbounded value is stored. Blast radius is cosmetic. |
| **Reproduce** | POST `…/finalize` with `{"action":"submit","input":{"remarks":["x"]}}` and read the stored remark. |
| **Fix approach** | Accepted by design — the request is intentionally shape-only (its docblock says so) and each driver coerces the keys it consumes. Recorded here, no code change. |
| **Plan item** | none — see plan §10 |

```php
// FinalizeRequest.php:24-25 — CURRENT
            'input' => ['nullable', 'array', 'max:20'],
            'input.*' => ['nullable'],
```

**Evidence**
```
$ grep -n "'input'" Modules/TenantCore/app/Http/Requests/Evaluation/FinalizeRequest.php
24:            'input' => ['nullable', 'array', 'max:20'],
25:            'input.*' => ['nullable'],
```
Driver-side coercion that bounds the impact (other modules): `ExamEvaluationDriver.php:215` `filter_var($input['publish'] ?? false, FILTER_VALIDATE_BOOLEAN)`; `ExamEvaluationDriver.php:231` `mb_substr((string) $input['remarks'], 0, 2000)`.

Validation otherwise clean: all POST methods use a FormRequest; `validated()` is used everywhere (`EvaluationController.php:70-71,80,91,94,105,117-118`), no `$request->all()`/`except()`; the one inline read is a GET filter (`queue()`, see EVL-07).

### F5 — Routes

#### EVL-06 · M · RTE-01 — `GET …/scripts/{subject}` performs a write (lazy-creates the eval script row)

| Field | Value |
|---|---|
| **Rule** | RTE-01 (M) — *no state change over GET* (lowered from H: the write is an idempotent lazy-init of the caller's own row and loses no data). |
| **Where** | `Modules/TenantCore/app/Http/Controllers/EvaluationController.php:49-53` → `EvaluationService::script():107-110` → `ScriptService::open():20-28` (`EvalScript::firstOrCreate`, line 24). |
| **Root cause** | The GET `script()` endpoint calls `EvaluationService::script()` → `ScriptService::open()`, which `firstOrCreate`s the evaluator's `lms_eval_scripts` row on first view. A GET therefore inserts a row (and can set `started_at`). Link prefetchers, browser back/forward and crawlers with an authenticated session can create draft rows. |
| **Consequence** | Opening an evaluator URL without intending to mark creates a draft script row (with a start time), which then appears in "in progress" reports; the write happens under a verb with no CSRF protection. |
| **Reproduce** | `GET /tenantcore/evaluation/exam/<paperId>/scripts/<attemptId>` while authenticated, then count `lms_eval_scripts` for that (context, subject, evaluator): one new draft row. |
| **Fix approach** | Accepted design — the row is the evaluator's own tracking row, created once and reused; moving creation to a POST would change the boot flow of every context. Recorded here, no code change. |
| **Plan item** | none — see plan §10 |

```php
// EvaluationController.php:49-53 — CURRENT
    public function script(string $context, string $owner, string $subject): JsonResponse
    {
        return $this->run($context, $owner, $subject, EvaluationDriver::ABILITY_VIEW, function (EvaluationDriver $driver) use ($owner, $subject) {
            $data = $driver->loadScript($owner, $subject);
            $state = $this->evaluation->script($driver, $owner, $subject);
```

**Evidence**
```
$ grep -n "function script\|scripts->open" Modules/TenantCore/app/Evaluation/Services/EvaluationService.php
107:    public function script(EvaluationDriver $driver, string $ownerId, string $subjectId): EvalScript
109:        return $this->scripts->open($driver, $ownerId, $subjectId);
$ grep -n "firstOrCreate" Modules/TenantCore/app/Evaluation/Services/ScriptService.php
24:        $script = EvalScript::firstOrCreate(
```

Otherwise clean: all 7 routes point at existing methods (F5 §4); route params `{context}/{owner}/{subject}` match the method arguments exactly (no unbound model — all are `string`); tenant + auth middleware present; no `Route::resource` shares the prefix.

### F6 — Controller shape

#### EVL-07 · L · CTL-08 — `queue()` uses the `request()` helper instead of injecting `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods.* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/EvaluationController.php:43`, method `queue()` |
| **Root cause** | `queue()` reads its filters with `request()->only([...])` instead of a typed `Request $request` parameter, so the dependency is hidden and the method is harder to test. |
| **Consequence** | No user-visible fault; maintainability only. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `Request $request` as the first parameter and read `$request->only([...])`. |
| **Plan item** | EVL-07 in `02-fix-plan.md` §8 |

```php
// EvaluationController.php:40-45 — CURRENT
    public function queue(string $context, string $owner): JsonResponse
    {
        return $this->run($context, $owner, null, EvaluationDriver::ABILITY_VIEW, function (EvaluationDriver $driver) use ($owner) {
            $filters = request()->only(['status', 'search', 'allocation_id']);
```

**Evidence**
```
$ grep -n "request()" Modules/TenantCore/app/Http/Controllers/EvaluationController.php
43:            $filters = request()->only(['status', 'search', 'allocation_id']);
```

Clean: 150 lines, 7 public methods (well under CTL-01); longest method `run()` is 27 lines (under CTL-02); all public methods have `: JsonResponse` return types (CTL-04); no `dd()`/`dump()`/`ray()`/`var_dump()` (proved in F12); no `compact()`; no `extract()`; no copy-pasted blocks beyond the shared `run()` wrapper.

### F7 — Models

clean — `EvalScript`, `EvalAnnotation`, `EvalAudit` all pass MDL checks.

```
$ grep -n "protected \$fillable\|protected \$casts\|protected \$table\|use SoftDeletes\|public function annotations\|public function audit\|public function script" \
    Modules/TenantCore/app/Evaluation/Models/EvalScript.php \
    Modules/TenantCore/app/Evaluation/Models/EvalAnnotation.php \
    Modules/TenantCore/app/Evaluation/Models/EvalAudit.php
EvalScript.php:14:    use SoftDeletes;
EvalScript.php:20:    protected $table = 'lms_eval_scripts';
EvalScript.php:22:    protected $fillable = [
EvalScript.php:27:    protected $casts = [
EvalAnnotation.php:14:    use SoftDeletes;
EvalAnnotation.php:16:    protected $table = 'lms_eval_annotations';
...
```

- MDL-01: `$fillable` declared in all three; nothing sensitive (`EvalScript` fillable includes only ids/state/timestamps).
- MDL-02: `EvalScript::$casts` covers `started_at`/`submitted_at`/`locked_at` (datetime), `elapsed_seconds` (int), `flags`/`totals` (array), `is_active` (bool); `EvalAnnotation::$casts` covers `page` (int), `x/y/w/h/value` (float), `payload` (array); `EvalAudit::$casts` covers `old_value`/`new_value` (array), `created_at` (datetime).
- MDL-07 / table exists: all three tables are created in `database/migrations/tenant/2026_09_25_120000_create_lms_eval_tables.php:26,53,81`.
- SoftDeletes ⇔ `deleted_at`: `EvalScript` and `EvalAnnotation` use `SoftDeletes` and their tables have `deleted_at`; `EvalAudit` does not use `SoftDeletes` and its table has no `deleted_at` — correct.
- MDL-03: no `belongsToMany` here.
- MDL-04: relationship methods return-typed (`EvalScript::annotations(): HasMany`, `EvalScript::audit(): HasMany`, `EvalAnnotation::script(): BelongsTo`).
- MDL-05/TEN-01: none of the three uses Spatie `InteractsWithMedia`; not applicable.

### F8 — Services and jobs

#### EVL-08 · M · ERR-05 — the annotation-burn catch logs only the exception message, not the trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message*; D2 — *services use `report($e)` plus a fixed message.* |
| **Where** | `Modules/TenantCore/app/Evaluation/Services/AnnotationBurnService.php:64-66`, method `burn()` |
| **Root cause** | The per-file catch logs `Log::warning('Annotation burn skipped', [..., 'error' => $e->getMessage()])` (loses the stack trace) and only then composes the user-safe skip text. On a broken PDF this is the only record of why the burn was skipped. |
| **Consequence** | When a student's PDF fails to parse, the log holds a truncated one-line reason ("unreadable PDF: …") with no file/line, so the operator cannot tell an FPDI parse failure from a disk error. The submit still succeeds (intended), but the failure is under-diagnosed. |
| **Reproduce** | Static only — needs a corrupt PDF in a finalize-burn. |
| **Fix approach** | Replace the `Log::warning(...)` with `report($e)` (logs the full exception) and keep the fixed user-safe skip message. Remove the now-unused `Log` import. |
| **Plan item** | EVL-08 in `02-fix-plan.md` §3 |

```php
// AnnotationBurnService.php:62-67 — CURRENT
            try {
                $rendered[$ref] = [$this->render(Storage::disk($target['disk'])->get($target['path']), $annotations), $annotations];
            } catch (\Throwable $e) {
                Log::warning('Annotation burn skipped', ['script' => $script->id, 'ref' => $ref, 'error' => $e->getMessage()]);
                $skipped[$ref] = 'unreadable PDF: '.mb_substr($e->getMessage(), 0, 120);
            }
```

**Evidence**
```
$ grep -n "Log::" Modules/TenantCore/app/Evaluation/Services/AnnotationBurnService.php
65:                Log::warning('Annotation burn skipped', ['script' => $script->id, 'ref' => $ref, 'error' => $e->getMessage()]);
```

Clean otherwise (F8): no HTTP inside services (`grep -n "Http::\|Guzzle\|file_get_contents('http" Evaluation` → none); constructor injection everywhere (`EvaluationService`, `ScriptService`, `AnnotationBurnService`, `AuditService`); events `ItemMarked`/`ScriptFinalized`/`ScriptFlagged` carry models and are dispatched inside the service (JOB checks N/A — they are events, not queued jobs; no `ShouldQueue` listeners are defined in TenantCore).

### F9 — Queries and performance

The only in-scope N+1 is the per-row `SELECT` inside `AnnotationService::sync()`, already reported as **EVL-03** (F2) with its fix. Deducted once there.

Clean — no other query-in-loop, no interpolated raw SQL:

```
$ grep -rn "foreach\|->map(\|->each(" Modules/TenantCore/app/Evaluation/Services Modules/TenantCore/app/Evaluation/Totals
AnnotationService.php:38:        foreach ($upserts as $i => $a) {        # the EVL-03 loop
AnnotationBurnService.php:54:        foreach ($byRef as $ref => $annotations) {   # one query per distinct file ref, bounded (few refs per script)
AnnotationBurnService.php:71:        foreach ($rendered as $ref => [$bytes, $annotations]) {  # same bound; one soft-delete per ref
$ grep -rn "DB::raw\|whereRaw\|orderByRaw\|selectRaw" Modules/TenantCore/app/Evaluation
(none)
```

No lists are returned to a paginated page (all endpoints are per-subject JSON, not list pages); `script()`/`queue()` are bounded to one owner's attempts.

### F10 — Views

clean — this controller renders no Blade view.

```
$ grep -n "view(\|@include\|<x-" Modules/TenantCore/app/Http/Controllers/EvaluationController.php
(none)
```

All seven methods return `JsonResponse`. The Vue front-end (`pe-*.js`) that consumes them is out of scope (§8).

### F11 — Security and tenancy

clean.

```
$ grep -rn "env(" Modules/TenantCore/app/Evaluation Modules/TenantCore/app/Http/Controllers/EvaluationController.php
(none)
$ grep -rn "?? 1\|hard\|password\|secret\|token" Modules/TenantCore/app/Evaluation/Services
(none)
```

- SEC-01: no `env()` outside `config/`.
- SEC-02: responses return mapped arrays (`QueueEntry::toArray`, `EvalAnnotation::toClient`), not whole models; only the evaluator's own subject data is exposed.
- SEC-03: no hard-coded ids or `?? 1`.
- SEC-04: the two log calls carry ids only (`context`, `owner`, `subject`, `ref`) — no request body, no PII.
- TEN: all access is on the tenant connection; the routes are wrapped by the tenancy middleware group (§4); no central model is touched. `EvaluationRegistry`'s static `$drivers` map holds only class-strings registered by service providers, no tenant data.

### F12 — Style

#### EVL-09 · L · STY-02 — five in-scope files are not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset).* |
| **Where** | `Modules/TenantCore/app/Evaluation/Totals/TotalsLine.php:12-15`, `Modules/TenantCore/app/Evaluation/Data/Capabilities.php:14-15`, `Modules/TenantCore/app/Evaluation/Data/AnswerData.php:14-17`, `Modules/TenantCore/app/Evaluation/Services/AnnotationService.php:17-18`, `Modules/TenantCore/app/Evaluation/Models/EvalScript.php:16-18` |
| **Root cause** | `class_attributes_separation` (and, in two files, `braces_position`/`single_line_empty_body`/`unary_operator_spaces`/`not_operator_with_successor_space`) want a blank line between adjacent class members/consts. |
| **Consequence** | No user impact; a future `pint` run reformats files owned by this subsystem in a change unrelated to the fix. |
| **Reproduce** | `vendor/bin/pint --test Modules/TenantCore/app/Evaluation` → reports these five files. |
| **Fix approach** | Run Pint on the five files (the Before/After pairs in plan §8 give each edit). |
| **Plan item** | EVL-09 in `02-fix-plan.md` §8 |

```php
// Totals/TotalsLine.php:12-15 — CURRENT
    public ?float $effective;
    public float $floor = 0.0;
    public bool $counted = true;
    /** @var string[] */
```

**Evidence**
```
$ vendor/bin/pint --test Modules/TenantCore/app/Evaluation Modules/TenantCore/app/Http/Controllers/EvaluationController.php Modules/TenantCore/app/Http/Requests/Evaluation
{"tool":"pint","result":"fail","files":[
 {"path":"Modules\/TenantCore\/app\/Evaluation\/Totals\/TotalsLine.php","fixers":["class_attributes_separation","unary_operator_spaces","not_operator_with_successor_space"]},
 {"path":"Modules\/TenantCore\/app\/Evaluation\/Data\/Capabilities.php","fixers":["class_attributes_separation","braces_position","single_line_empty_body"]},
 {"path":"Modules\/TenantCore\/app\/Evaluation\/Data\/AnswerData.php","fixers":["class_attributes_separation","braces_position","single_line_empty_body"]},
 {"path":"Modules\/TenantCore\/app\/Evaluation\/Services\/AnnotationService.php","fixers":["class_attributes_separation","unary_operator_spaces","not_operator_with_successor_space"]},
 {"path":"Modules\/TenantCore\/app\/Evaluation\/Models\/EvalScript.php","fixers":["class_attributes_separation"]}]}
```

Clean: `declare(strict_types=1)` present in every in-scope PHP file (`grep -rL "declare(strict_types=1)" …` → no output); no emoji in comments (`grep -rlP "[\x{1F300}-\x{1FAFF}]" …` → no output); no commented-out code lines; camelCase names; one import per class (STY-05). STY-04/STY-06 clean.

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 wrong data | Q2 irreversible order | Q3 dup impl | Q4 soft-delete×unique | Q5 race | Q6 auth hole | Q7 message lies | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `mark` (`markItem`) | ok | ok | ok | ok | ok | ok | ok | ok |
| `annotations` (`sync`) | EVL-03 | ok | ok | ok | ok | ok | ok | ok |
| `meta` (`addElapsed`/`setComment`) | ok | ok | ok | ok | ok | ok | ok | ok |
| `flag` (`flag`) | ok | ok | ok | ok | ok | ok | ok | ok |
| `finalize` (`finalize`) | ok | EVL-02 | ok | ok | ok | ok | ok | ok |

Notes:
- Q4 (soft-delete × unique): the unique indexes are `(context, subject_id, evaluator_id, uq_guard)` and `(script_id, client_uid, uq_guard)` where `uq_guard = IFNULL(deleted_at,'1970-01-01')` (migration lines 45-47, 72-74). A re-created row after a soft delete gets a different `uq_guard`, so it never collides with the trashed row — correct.
- Q5 (race): `firstOrCreate` is race-safe (Laravel 12 `createOrFirst`); `AnnotationService::sync` reads-then-writes without a lock but a concurrent double save of the same `uid` is guarded by the unique index → at worst a 500 for the loser, no duplicate row.
- Q6 (auth hole): guarded by the driver (F3).
- Q7 (messages lie): the 422 body uses `$e->field ?? 'general'` and the authored domain text; the success envelope `['success' => true] + $work(...)` matches the data returned.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/LmsExam/app/Evaluation/ExamEvaluationDriver.php` and the other 5 concrete drivers | They own the permission checks (`authorize()`) and the record scoping this controller relies on. `ExamEvaluationDriver::authorize()` (lines 81-94) does it correctly (Gate + `where('exam_paper_id', $owner)`), but a new driver that returns `true` without the scoping check is an IDOR the core cannot catch. | AUTH-03 | the owning module's audit report |
| `Modules/TenantCore/app/Evaluation/Concerns/ResolvesStoredFiles.php:97` | `catch (\Throwable)` with no `report($e)` — swallows a failure silently (ERR-05/ERR-06). | ERR-05 | TenantCore audit (this file is not on EvaluationController's call path) |
| `Modules/TenantCore/app/Evaluation/Services/BootStateBuilder.php` | Builds the endpoint URLs (`route('tenantcore.evaluation.*')`) consumed by the Vue app; not on this controller's call path, so not audited here. Its route-name literals must stay in sync with `routes/web.php`. | RTE-02 | TenantCore audit |
| `Modules/LmsExam/app/Providers/LmsExamServiceProvider.php:58-61`, `LmsQuests…:40`, `LmsHomework…:39`, `Admission…:112` | `EvaluationRegistry::register(...)` is called from each module's provider. The registry's static `$drivers` map is process-local; under Laravel Octane the registration must be idempotent (it is an array assignment, so it is). | TEN | platform/Octane review |
| Vue front-end `pe-annotations.js` / `paper-evaluator.css` | Consumes these endpoints; the burn service mirrors its stamp geometry. Not audited here. | VIEW | front-end review |

## 8. Not covered, and why

- **Concrete drivers and their tables** (`LmsExam`, `LmsQuests`, `LmsHomework`, `Admission`): other-module classes; reached only at runtime via `EvaluationRegistry`; they self-register and are audited by their own modules' reports (§7).
- **Event listeners** for `ItemMarked`, `ScriptFinalized`, `ScriptFlagged`: no listeners are registered inside `TenantCore`; any context listener lives in another module and is dispatched synchronously inside the transaction (relevant to EVL-02 but not audited here).
- **Live row counts** of the `lms_eval_*` tables (§0): not measured — this read-only pass avoided opening a tenant connection; `SELECT COUNT(*)` on a tenant DB would settle it.
- **The Vue front-end** and the browser-rendered evaluator: not rendered by this controller (all JSON).
- **Runtime bug reproduction**: no endpoint was called (D4 — no tests, read-only). Every finding was proven with a command and source lines; the two "Reproduce" entries marked *static only* say why.
