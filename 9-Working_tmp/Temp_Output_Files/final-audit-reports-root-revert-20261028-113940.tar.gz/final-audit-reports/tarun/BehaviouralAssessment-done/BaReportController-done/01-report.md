# Final Audit — BehaviouralAssessment / BaReportController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php` (854 lines, 7 public methods + 3 private helpers)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | GET `behavioural-assessment/reports` (the Reports hub) · GET `behavioural-assessment/reports/student/{student}` (with `?period_id=`) · GET `behavioural-assessment/reports/class/{classSection}` (with `?period_id=`, `?anonymised=1`) · GET `behavioural-assessment/reports/incidents` (with date/type/severity/status/location/category filters, paginated) · GET `behavioural-assessment/reports/period/{period}` (with `?anonymised=1`) · GET `behavioural-assessment/reports/categories` (with `?period_id=`) · POST `behavioural-assessment/reports/export` |
| Menu path | Behavioural Assessment → Reports (`reports-page`, the combined tab page) → the per-report pages; the hub also links from the dashboard |
| Who uses it | Anyone holding `tenant.behavioural-assessment.reports.view` (permission id 5004, seeded today to roles 1 Super Admin, 2 School Admin) may view every report; `tenant.behavioural-assessment.reports.viewAny` (id 5005, same roles) for the hub; `tenant.behavioural-assessment.reports.export` (id 5010, roles 1–2) for the Export button — all measured with exact-name queries on the test tenant |
| What a user does here | Opens the Reports hub with summary counts and a 6-month incident trend; opens a single student's behaviour summary (category scores, criterion ratings, remarks, incidents, overall score/grade/trend, rank); opens a class-section analysis (class averages, per-category stats, student ranking, at-risk list, incident breakdown); opens the incident log and interventions report with filters and breakdowns; opens the period teacher-progress report; opens the school-wide category and criteria performance report; and exports any catalogue report as xlsx/csv/pdf, optionally anonymised (BR-BA-020), with large exports queued to the Exports tab |
| Tables written | Only on the export POST, and only indirectly: `ba_report_exports` and `ba_audit_log` (both written by `BaReportExportService::request()`, which is owned by the BaReportExportController report), plus one `ba_audit_log` row written directly by this controller's `export()` (`downloaded` event, line 837). All six GET report methods write nothing. |
| Tables read | `ba_computed_overall`, `ba_computed_scores`, `ba_assessments`, `ba_assessment_ratings`, `ba_assessment_periods`, `ba_incidents`, `ba_incident_followups`, `ba_incident_intervention_jnt`, `ba_interventions`, `ba_student_remarks`, `ba_categories`, `ba_criteria`, `ba_class_category_jnt`, `ba_config`, `ba_framework_snapshots`, `ba_score_runs`, `ba_report_exports`, the views `v_ba_assessment_progress` / `v_ba_open_interventions`, `std_students`, `sch_employees`, `sys_users`, `sch_classes`, `sch_class_sections` |
| Live data | On the test tenant `00000000-0000-4000-8000-000000000001` (db `xyz_school_00000000000040008000_202627`): `ba_computed_overall` 193 live / 0 trashed; `ba_computed_scores` 1,737 live / 0 trashed; `ba_report_exports` 0 live / 0 trashed; `ba_incidents` 24; `ba_assessment_periods` 4; `ba_assessments` 17 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **production-ready only after the two blockers are fixed**. The report pages are read-only, every routed method authorizes before loading, the routes are correct and tenanted, and the views eager-load every relation they loop over. The single worst finding is that raw exception text reaches the user twice: the export POST's failed-branch flash echoes `ba_report_exports.error_message` (BAR-02), and the scoring service stores the raw exception message in `ba_score_runs.error_message`, which the Setup → Snapshots tab renders in a tooltip (BAR-14). Around that, the controller is long (five methods over 80 lines, two over 150) and repeats a handful of queries and literals; the two owned services have real but bounded N+1 query patterns on the score-run path that do not run on any page this controller renders. Rough effort: **M** — roughly a focused day: the two leak fixes are small, the service N+1 fixes are contained, and the style/deferred items are opportunistic. The controller's own export POST also violates D1 with a `try/catch`, which is a small removal (BAR-01).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 1 | 11 | 4 | 3 | 18 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BAR-01, BAR-02, BAR-14 | F8 Services/Jobs | BAR-07 |
| F2 Transactions/Audit | clean | F9 Queries/Perf | BAR-08, BAR-09, BAR-10, BAR-11, BAR-12 |
| F3 Authorization | BAR-03 | F10 Views | BAR-13 |
| F4 Validation | clean | F11 Security/Tenancy | BAR-15 |
| F5 Routes | clean | F12 Style | BAR-16, BAR-17 |
| F6 Controller shape | BAR-04, BAR-05, BAR-06 | F13 Deep read | BAR-18 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php` | controller | 854 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Models/BaComputedOverall.php` | model | 87 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php` | service | 443 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php` | service | 826 | this report | ✅ |
| 5 | `Modules/BehaviouralAssessment/app/Http/Requests/BaReportExportRequest.php` | FormRequest | 49 | this report | ✅ |
| 6 | `Modules/BehaviouralAssessment/resources/views/reports/index.blade.php` | view | 357 | this report | ✅ |
| 7 | `Modules/BehaviouralAssessment/resources/views/reports/student.blade.php` | view | 447 | this report | ✅ |
| 8 | `Modules/BehaviouralAssessment/resources/views/reports/by-class.blade.php` | view | 380 | this report | ✅ |
| 9 | `Modules/BehaviouralAssessment/resources/views/reports/incidents.blade.php` | view | 637 | this report | ✅ |
| 10 | `Modules/BehaviouralAssessment/resources/views/reports/period.blade.php` | view | 337 | this report | ✅ |
| 11 | `Modules/BehaviouralAssessment/resources/views/reports/categories.blade.php` | view | 229 | this report | ✅ |
| 12 | `Modules/BehaviouralAssessment/resources/views/reports/_partials/export-controls.blade.php` | view partial | 69 | this report | ✅ |
| 13 | `Modules/BehaviouralAssessment/resources/views/reports/exports/pdf.blade.php` | view partial | 46 | this report | ✅ (referenced by the export service's PDF path; renders only `$data`/`$export` passed in) |
| 14 | `Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_exports.blade.php` | view partial | 136 | this report | ✅ (the export register; rendered on the reports-page tab, see §8) |
| 15 | `Modules/BehaviouralAssessment/app/Models/BaAssessment.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaAssessmentController-done](../BaAssessmentController-done/01-report.md) | ↗ linked |
| 16 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentPeriod.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaAuditLogController-done](../BaAuditLogController-done/01-report.md) | ↗ linked |
| 17 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentRating.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaClassScaleController-done](../BaClassScaleController-done/01-report.md) | ↗ linked |
| 18 | `Modules/BehaviouralAssessment/app/Models/BaCategory.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaCategoryController-done](../BaCategoryController-done/01-report.md) | ↗ linked |
| 19 | `Modules/BehaviouralAssessment/app/Models/BaClassCategoryJnt.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaClassCategoryController-done](../BaClassCategoryController-done/01-report.md) | ↗ linked |
| 20 | `Modules/BehaviouralAssessment/app/Models/BaComputedScore.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaAssessmentPeriodController-done](../BaAssessmentPeriodController-done/01-report.md) | ↗ linked (being audited in this same batch) |
| 21 | `Modules/BehaviouralAssessment/app/Models/BaConfig.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaConfigController-done](../BaConfigController-done/01-report.md) | ↗ linked |
| 22 | `Modules/BehaviouralAssessment/app/Models/BaCriterion.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaCategoryController-done](../BaCategoryController-done/01-report.md) | ↗ linked |
| 23 | `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaAuditLogController-done](../BaAuditLogController-done/01-report.md) | ↗ linked |
| 24 | `Modules/BehaviouralAssessment/app/Models/BaIncident.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaIncidentController-done](../BaIncidentController-done/01-report.md) | ↗ linked |
| 25 | `Modules/BehaviouralAssessment/app/Models/BaRatingScale.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaRatingScaleController-done](../BaRatingScaleController-done/01-report.md) | ↗ linked |
| 26 | `Modules/BehaviouralAssessment/app/Models/BaReportExport.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaReportExportController-done](../BaReportExportController-done/01-report.md) | ↗ linked |
| 27 | `Modules/BehaviouralAssessment/app/Models/BaStudentRemark.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaAssessmentController-done](../BaAssessmentController-done/01-report.md) | ↗ linked |
| 28 | `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php` | service | 671 | ↗ [tarun/BehaviouralAssessment-done/BaReportExportController-done](../BaReportExportController-done/01-report.md) | ↗ linked (usage checked) |
| 29 | `Modules/BehaviouralAssessment/app/Services/BaBehaviourPointService.php` | service | — | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked (usage checked, `student()` lines 237-238) |
| 30 | `Modules/BehaviouralAssessment/app/Support/BaPseudonym.php` | support helper | — | unclaimed (no owners row) | ❌ referenced only — pure static mapping/label helpers used by the anonymised views; no DB writes |
| 31 | `Modules/BehaviouralAssessment/app/Models/BaScoreRun.php` | model | — | unclaimed (no owners row) | ❌ referenced only — written by the owned `BehaviouralScoreService` on the score-run path, which this controller's routes never reach; the table `ba_score_runs` exists in migration `2026_06_16_130633_create_ba_score_runs_table.php` |

Other-module classes (`Modules\StudentProfile\Models\Student`, `Modules\SchoolSetup\Models\ClassSection`/`SchoolClass`/`User`) are common per §4.2 — referenced, not audited here.

No pre-applied files.

## 4. Routes

From the uncached route list (`/tmp/fa-routes.json`), the seven routes that point at this controller:

```
GET|HEAD behavioural-assessment/reports                       behavioural-assessment.reports.index      BaReportController@index
GET|HEAD behavioural-assessment/reports/categories            behavioural-assessment.reports.categories BaReportController@categories
GET|HEAD behavioural-assessment/reports/class/{classSection}   behavioural-assessment.reports.class       BaReportController@byClass
POST      behavioural-assessment/reports/export               behavioural-assessment.reports.export      BaReportController@export
GET|HEAD behavioural-assessment/reports/incidents             behavioural-assessment.reports.incidents   BaReportController@incidents
GET|HEAD behavioural-assessment/reports/period/{period}       behavioural-assessment.reports.period      BaReportController@period
GET|HEAD behavioural-assessment/reports/student/{student}     behavioural-assessment.reports.student     BaReportController@student
```

All seven live in `Modules/BehaviouralAssessment/routes/web.php:154-163`, inside the module group (`web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:BehaviouralAssessment`, `auth`, `verified`) with prefix `behavioural-assessment` and name prefix `behavioural-assessment.`. Route parameter names (`student`, `classSection`, `period`) match the controller arguments exactly, so there is no unbound-model INSERT risk.

Unrouted public methods: none (7 public methods; all are routed).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 104 | GET `reports` | `tenant.behavioural-assessment.reports.viewAny` | none — read-only | — | — | BAR-04 |
| `student` | 143 | GET `reports/student/{student}` | `tenant.behavioural-assessment.reports.view` | none — read-only | — | — | BAR-04, BAR-05, BAR-06, BAR-07, BAR-12, BAR-18 |
| `byClass` | 257 | GET `reports/class/{classSection}` | `tenant.behavioural-assessment.reports.view` | none — read-only | — | — | BAR-04, BAR-05, BAR-06, BAR-07, BAR-12 |
| `incidents` | 419 | GET `reports/incidents` | `tenant.behavioural-assessment.reports.view` | none — read-only | — | — | BAR-04, BAR-06, BAR-07, BAR-12 |
| `period` | 583 | GET `reports/period/{period}` | `tenant.behavioural-assessment.reports.view` | none — read-only | — | — | BAR-04, BAR-05, BAR-06, BAR-07, BAR-12 |
| `categories` | 690 | GET `reports/categories` | `tenant.behavioural-assessment.reports.view` | none — read-only | — | — | BAR-04, BAR-06, BAR-07, BAR-12 |
| `export` | 817 | POST `reports/export` | `BaReportExportRequest::authorize()` → `tenant.behavioural-assessment.reports.export` | none in this controller; the service's `request()` has no transaction (BAEXP-03, cross-cutting §7) | `BaAuditLog::log(..., 'downloaded', ...)` at line 837 (the service logs `'requested'`) | `ba_report_exports` (via service), `ba_audit_log` (via service + line 837), the generated file | BAR-01, BAR-02, BAR-03 |

## 6. Findings

### F1 — Errors

#### BAR-01 · M · ERR-00 — `export()` wraps the service call in a controller `try/catch`

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M, raised to binding by D1) — *D1 settled the Laravel idiom: no try/catch in controllers; the central handler in `bootstrap/app.php` logs and renders.* (Secondary ERR-05 (M): the catch logs `getMessage()` without the trace.) |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:821-832`, method `export()` |
| **Root cause** | The method catches every `\Throwable` from `$exports->request(...)`, logs only `$e->getMessage()`, and returns a fixed flash. D1 forbids controller try/catch except the D2 shapes (business-rule `\DomainException`, truncate-then-rebuild, `SnapshotProtectionException`); a generic `\Throwable` catch is none of them, and the log line loses the trace (ERR-05). |
| **Consequence** | The failure path is the one place a real infrastructure error (a `QueryException` from `countRows()`/`create()`, a disk error) is converted into a two-line log with no stack, so production outages of the export path are undebuggable, and the controller carries the one try/catch D1 forbids. |
| **Reproduce** | Static only — the branch is the failure path of the export POST (needs a DB failure during `request()`); the catch text is visible in source. |
| **Fix approach** | Remove the `try`/`catch`; let `BaReportExportService::request()`'s exceptions bubble to the central handler. `request()` already validates its own report codes and formats (throwing `InvalidArgumentException` that the FormRequest makes unreachable), and `generate()` already catches and marks the row failed internally. |
| **Plan item** | BAR-01 in `02-fix-plan.md` §3 |

```php
// BaReportController.php:819-832 — CURRENT
        $data = $request->validated();

        try {
            $export = $exports->request(
                $data['report_code'],
                (array) ($data['filters'] ?? []),
                $data['format'],
                (bool) ($data['anonymised'] ?? false),
            );
        } catch (\Throwable $e) {
            Log::error('BA report export request failed', ['report' => $data['report_code'], 'error' => $e->getMessage()]);

            return back()->with('error', 'The export could not be started. Please try again.');
        }
```

**Evidence**
```
$ sed -n '819,832p' Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
        $data = $request->validated();

        try {
            $export = $exports->request(
                $data['report_code'],
                (array) ($data['filters'] ?? []),
                $data['format'],
                (bool) ($data['anonymised'] ?? false),
            );
        } catch (\Throwable $e) {
            Log::error('BA report export request failed', ['report' => $data['report_code'], 'error' => $e->getMessage()]);

            return back()->with('error', 'The export could not be started. Please try again.');
        }
$ grep -n "getMessage\|catch (\\\\Throwable" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
828:            Log::error('BA report export request failed', ['report' => $data['report_code'], 'error' => $e->getMessage()]);
```

#### BAR-02 · B · ERR-01 — the failed-export flash echoes the raw `error_message`

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak.* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:843-845`, method `export()` |
| **Root cause** | When `BaReportExportService::generate()` fails it stores the raw exception text in `ba_report_exports.error_message` (BAEXP-01, owned by the export service report). This method echoes that column verbatim into a session flash: `'The export failed: '.($export->error_message ?: 'unknown error').'.'`. A `QueryException` from the report dataset carries the SQL statement and the table/column names; a storage failure carries the private path. |
| **Consequence** | When any export fails, the user's red flash shows database/SQL or file-path text instead of a fixed "could not be generated" sentence. |
| **Reproduce** | POST `behavioural-assessment/reports/export` for a report whose generation throws (e.g. a query failure), then follow the redirect — the red flash shows the raw reason. |
| **Fix approach** | Do not echo `error_message`; flash a fixed sentence. The raw reason stays in the register's log (its display there is BAEXP-01's business) and in the row for support staff. |
| **Plan item** | BAR-02 in `02-fix-plan.md` §1 |

```php
// BaReportController.php:842-845 — CURRENT
        $tab = route('behavioural-assessment.reports-page', ['tab' => 'exports']);
        if ($export->status === BaReportExport::STATUS_FAILED) {
            return redirect($tab)->with('error', 'The export failed: '.($export->error_message ?: 'unknown error').'.');
        }
```

**Evidence**
```
$ sed -n '842,845p' Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
        $tab = route('behavioural-assessment.reports-page', ['tab' => 'exports']);
        if ($export->status === BaReportExport::STATUS_FAILED) {
            return redirect($tab)->with('error', 'The export failed: '.($export->error_message ?: 'unknown error').'.');
        }
$ grep -n "error_message" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
844:            return redirect($tab)->with('error', 'The export failed: '.($export->error_message ?: 'unknown error').'.');
```

#### BAR-14 · B · ERR-01 — the score-run failure stores the raw exception text in `error_message`

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak.* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php:148-160`, method `computeForPeriod()` |
| **Root cause** | The catch writes `'error_message' => BaTriggerError::message($e) ?? $e->getMessage()`. `BaTriggerError::message()` returns a safe sentence only for BA trigger SQLSTATE 45000; for every other exception the raw `$e->getMessage()` — a `QueryException` includes the SQL text — is stored in `ba_score_runs.error_message`. The Setup → Framework Snapshots tab renders that column to users: `pages/partials/setup/_snapshots.blade.php:172` (`title="{{ $run->error_message }}"`). The `report($e)` on the line before is correct, but the column still ships the raw text. |
| **Consequence** | When a score run fails on a non-trigger error, any user who opens Setup → Framework Snapshots sees SQL/table/path detail in the Failed badge tooltip. |
| **Reproduce** | Force a score run to fail with a non-trigger exception (e.g. a missing table), then open the Setup → Snapshots tab — the failed run's tooltip shows the raw message. Static confirmation: `grep -n "error_message" Modules/BehaviouralAssessment/resources/views/pages/partials/setup/_snapshots.blade.php`. |
| **Fix approach** | Keep `report($e)` for the trace and store a fixed sentence instead of `$e->getMessage()`; `BaTriggerError` still supplies the user-safe trigger message. |
| **Plan item** | BAR-14 in `02-fix-plan.md` §1 |

```php
// BehaviouralScoreService.php:148-161 — CURRENT
        } catch (Throwable $e) {
            report($e);
            Log::error('BehaviouralAssessment: score run failed', [
                'score_run_id' => $run->id,
                'period_id' => $periodId,
                'class_section_id' => $classSectionId,
                'error' => $e->getMessage(),
            ]);

            $finish([
                'status' => BaScoreRun::STATUS_FAILED,
                'error_message' => BaTriggerError::message($e) ?? $e->getMessage(),
            ]);
        }
```

**Evidence**
```
$ sed -n '148,161p' Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php
        } catch (Throwable $e) {
            report($e);
            Log::error('BehaviouralAssessment: score run failed', [
                'score_run_id' => $run->id,
                'period_id' => $periodId,
                'class_section_id' => $classSectionId,
                'error' => $e->getMessage(),
            ]);

            $finish([
                'status' => BaScoreRun::STATUS_FAILED,
                'error_message' => BaTriggerError::message($e) ?? $e->getMessage(),
            ]);
        }
$ grep -n "error_message" Modules/BehaviouralAssessment/resources/views/pages/partials/setup/_snapshots.blade.php
172:                            <span class="badge bg-danger" title="{{ $run->error_message }}">Failed</span>
```

### F2 — Transactions and audit

clean — none of the six GET report methods writes anything, so there is no transaction or audit requirement on them. The `export()` method's own direct write is one append-only `BaAuditLog::log(..., 'downloaded', ...)` (line 837), a single-table insert that needs no transaction on its own. The multi-table write it triggers lives in `BaReportExportService::request()` (create + audit with no transaction), which is owned by the BaReportExportController report and is already BAEXP-03 there — see §7. The owned services are clean on this family: `BaFrameworkSnapshotService::capture()` is a single insert whose caller (`BaPeriodService::lock`) owns the transaction per its docblock, and `BehaviouralScoreService::computeForPeriod()` wraps `runComputation()` (including `persistStudentRows()`, which writes `ba_computed_scores` + `ba_computed_overall`) in one `DB::transaction` (line 138), with the score-run row lifecycle intentionally outside it. Scanner candidates TXN-01 on `buildLive()` (no writes, only reads) and on `persistStudentRows()` (already inside the line-138 transaction) are rejected after source confirmation.

### F3 — Authorization

#### BAR-03 · M · AUTH-06 — the report permission strings are repeated as literals in six methods

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy, or constants — not repeated as literals in every method.* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:106,145,259,421,585,692` — `Gate::authorize('tenant.behavioural-assessment.reports.view')` at 145/259/421/585/692 and `...viewAny` at 106 |
| **Root cause** | The same permission literal is hand-typed six times. A rename, a typo, or a permission-scheme change must find all six by grep, and the string is not discoverable from one place (the sibling export service already models the correct pattern with `BaReportExportService::EXPORT_PERMISSION`). |
| **Consequence** | A future permission rename that misses one of the six sites silently drops a gate's effect or 403s a page; the strings cannot be linted against `config/permissionslist.php`. |
| **Reproduce** | Static only — `grep -n "Gate::authorize"` lists the six literals. |
| **Fix approach** | Declare `VIEW_PERMISSION` and `VIEW_ANY_PERMISSION` constants on the controller and reference them. No behaviour change; all names are already seeded (ids 5004/5005). |
| **Plan item** | BAR-03 in `02-fix-plan.md` §4 |

```php
// BaReportController.php:104-106 — CURRENT (first of six)
    public function index(): View
    {
        Gate::authorize('tenant.behavioural-assessment.reports.viewAny');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
106:        Gate::authorize('tenant.behavioural-assessment.reports.viewAny');
145:        Gate::authorize('tenant.behavioural-assessment.reports.view');
259:        Gate::authorize('tenant.behavioural-assessment.reports.view');
421:        Gate::authorize('tenant.behavioural-assessment.reports.view');
585:        Gate::authorize('tenant.behavioural-assessment.reports.view');
692:        Gate::authorize('tenant.behavioural-assessment.reports.view');
$ php artisan tinker --execute '... tenancy()->initialize(...); DB::table("sys_permissions")->where("name","tenant.behavioural-assessment.reports.view")->value("id") ...'
tenant.behavioural-assessment.reports.view => id=5004
tenant.behavioural-assessment.reports.viewAny => id=5005
```

For the rest of F3: clean. Every routed method authorizes before loading any record (AUTH-02 — `Gate::authorize` is the first line of each method, before `findOrFail`), with the export POST gated by `BaReportExportRequest::authorize()` which checks `tenant.behavioural-assessment.reports.export` (id 5010) — one gate per concern, no double-authorization (AUTH-04), and the export form in the view is `@can`-gated with the same exact string (`_partials/export-controls.blade.php:32`). The `view`/`viewAny`/`export` keys all exist in `config/permissionslist.php:1439` (`'behavioural-assessment.reports' => array_merge($crud, ['export'])`) and are seeded with exact-name rows. No Policy is consulted by these gate strings (they are `Gate::authorize` string calls, not `$this->authorize`), so there is no dead Policy to report.

### F4 — Validation and input

clean — the six GET methods write nothing, so `$request->all()`/`create()`/`update()` rules (VAL-01) do not apply. Query filters are read-only: `period_id`, `category_id` are passed to `find()`/`where()` (a missing or malformed value yields an empty result, never a crash), and the enumerated filters (`incident_type`, `severity`, `status`, `location`) are coerced against the model constants (`BaReportController.php:429-436`) so a hand-typed value filters nothing instead of erroring. The only write path (`export()`) validates entirely in `BaReportExportRequest`, which is in scope and audited: `report_code` and `format` are `Rule::in()` against the service's `REPORTS`/`FORMATS`, `anonymised` is nullable boolean, `filters` is an array of nullable max-length strings, and `authorize()` checks the `.export` permission. The controller then reads only `$request->validated()` (line 819). The FormRequest has one `nullable` optional read with a default (`filters` read as `(array) ($data['filters'] ?? [])`, line 824), so VAL-03 is satisfied.

### F5 — Routes

clean — reads are GET and the only state-changing route (the export POST) is POST (RTE-01); every route points at a method that exists (RTE-02, `php -l` clean and the §4 probe); every public method is routed (RTE-03, no unrouted methods); route parameter names match the method arguments (`student`, `classSection`, `period` — module-finalization §3.3.1, no unbound-model INSERT); the tenant middleware group is present (RTE-05, module `RouteServiceProvider` group); there is no `Route::resource` sharing the `reports` prefix, so RTE-06 does not apply. The `reports.export` POST is correct as a POST because it creates a `ba_report_exports` row (comment at web.php:159-160).

### F6 — Controller shape

#### BAR-04 · H · CTL-02 — five report methods exceed the 80/150-line limits

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M, raised to H because two methods exceed 150 lines) — *method length: over 80 lines → extract; over 150 lines is H.* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:143,257,419,583,690` — `student()` 108 lines, `byClass()` 159, `incidents()` 158, `period()` 104, `categories()` 110 |
| **Root cause** | Each report method inlines its whole statistic load (aggregate queries, rank/at-risk computation, level-of-detail maps) instead of delegating per-section queries to the two services it already owns. The same report-building logic cannot be reached from a second caller, and the methods are hard to review in one pass. |
| **Consequence** | The two 150+ methods are the module's longest bodies; any change to a statistic risks touching unrelated ones on the same screen, and the balloons that made the scanner flag CTL-02 on five methods remain. |
| **Reproduce** | Static only — measured method lengths below. |
| **Fix approach** | Defer the split to the D3 refactor pass (god-controller split), consistent with the settled decision; the extraction would reorganise the whole report builder without changing behaviour. |
| **Plan item** | BAR-04 in `02-fix-plan.md` §9 (DECISION) |

```php
// BaReportController.php:257 — byClass() opening (159-line body, H)
    public function byClass(int $classSection): View
    {
        Gate::authorize('tenant.behavioural-assessment.reports.view');
```

**Evidence**
```
$ php -r '... method length scan ...'
resolveScale         lines 53-82 = 30
frozenFramework      lines 85-88 = 4
overlayFrozen        lines 94-100 = 7
index                lines 104-136 = 33
student              lines 143-250 = 108
byClass              lines 257-415 = 159
incidents            lines 419-576 = 158
period               lines 583-686 = 104
categories           lines 690-799 = 110
export               lines 817-853 = 37
```

#### BAR-05 · M · CTL-03 — route model binding is not used on the three id routes

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`), not `$id` + `findOrFail`.* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:143,147` (`student`), `:257,260` (`byClass`), `:583,586` (`period`) |
| **Root cause** | Each routed method takes a raw `int` and calls `findOrFail()` by hand, so the route's 404 contract and the eager-load are written twice (`int $student` plus `Student::with('currentAcademicSession')->findOrFail($student)`). Laravel's implicit binding would 404 automatically and leave only the eager load to write. |
| **Consequence** | The 404 behaviour is correct today, but the boilerplate is repeated three times and a future controller that forgets the guard-less `find` becomes an INSERT; the binding eliminates the class of error. |
| **Reproduce** | Static only — `grep -n "findOrFail"` shows the three hand loads. |
| **Fix approach** | Type the params as the models (`Student $student`, `ClassSection $classSection`, `BaAssessmentPeriod $period`) and replace `findOrFail(...)` with `load(...)` for the eager relations. No route change needed — the parameter names already match. |
| **Plan item** | BAR-05 in `02-fix-plan.md` §5 |

```php
// BaReportController.php:143-148 — CURRENT (student)
    public function student(int $student): View
    {
        Gate::authorize('tenant.behavioural-assessment.reports.view');
        // A student's class-section lives on the current academic session, not on std_students.
        $student = Student::with('currentAcademicSession')->findOrFail($student);
        $classSection = $student->currentAcademicSession?->classSection;
```

**Evidence**
```
$ grep -n "findOrFail" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
147:        $student = Student::with('currentAcademicSession')->findOrFail($student);
260:        $classSection = ClassSection::with(['class', 'section'])->findOrFail($classSection);
586:        $period = BaAssessmentPeriod::with('academicSession')->findOrFail($period);
```

#### BAR-06 · L · CTL-08 — the `request()` helper is used inside controller methods

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods.* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:150,261,403,422-430,565,675,693,790` — `request(...)` / `request()->boolean(...)` |
| **Root cause** | The methods that read query parameters call the global `request()` helper instead of an injected `Illuminate\Http\Request`. The helper works, but it hides the method's inputs and makes the same method unusable from a solo console/queue context without a global request. |
| **Consequence** | No runtime defect on these GET pages (the helper resolves the current request); the methods cannot be invoked cleanly outside HTTP and the parameters are invisible in the signatures. |
| **Reproduce** | Static only — `grep -n "request("` lists 14 call sites. |
| **Fix approach** | Deferred — every call site sits inside one of the five oversized report methods that BAR-04 defers; converting the calls is naturally part of that extraction. |
| **Plan item** | none — see `02-fix-plan.md` §10 (deferred with BAR-04) |

```php
// BaReportController.php:149-155 — CURRENT (representative call)
        $periodId = request('period_id');
        $period = $periodId
            ? BaAssessmentPeriod::find($periodId)
            : BaAssessmentPeriod::orderByDesc('created_at')->first();

        $periods = BaAssessmentPeriod::orderByDesc('created_at')->get();
```

**Evidence**
```
$ grep -n "request(" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
150:        $periodId = request('period_id');
261:        $periodId = request('period_id');
403:        $anon = request()->boolean('anonymised');
422:        $incidentType = request('incident_type');
423:        $severity = request('severity');
424:        $fromDate = request('from_date', now()->startOfMonth()->toDateString());
425:        $toDate = request('to_date', now()->toDateString());
426:        $categoryId = request('category_id');
429:        $status = in_array(request('status'), BaIncident::STATUSES, true) ? request('status') : null;
430:        $location = in_array(request('location'), BaIncident::LOCATIONS, true) ? request('location') : null;
565:        $anon = request()->boolean('anonymised');
675:        $anon = request()->boolean('anonymised');
693:        $periodId = request('period_id');
790:        $anon = request()->boolean('anonymised');
```

For the rest of F6: clean. 854 lines / 10 methods is under the CTL-01 god-controller thresholds, so no split is triggered on size alone (the deferral in BAR-04 covers the extraction). Return types are present on every public method (CTL-04). No `dd`/`dump`/`var_dump`/`print_r`/`ray`/`phpinfo` (CTL-09, proven by `grep -nE '(^|[^a-zA-Z_])(dd|dump|var_dump|print_r|phpinfo)\('` over the controller and both owned services → no output). No commented-out debug blocks (CTL-10). The `resolveScale`/`frozenFramework`/`overlayFrozen` private helpers are all used (CTL-10). Copy-paste exists (the 6-month trend query is identical in `index()` 121-130 and `incidents()` 542-551, and the same period dropdown query is in four methods) but both are covered by BAR-12/QRY findings; no separate CTL-05 item is raised because the mechanical dedupe is part of the BAR-04 extraction.

### F7 — Models

clean for every model this report reaches. The one model it owns — `BaComputedOverall` — was audited fully: `$fillable` declared with nothing sensitive (MDL-01); `$casts` cover every boolean (`is_at_risk`, `is_active`), datetime (`computed_at`, `deleted_at`), integer (`student_id`, `period_id`, `categories_scored`, `score_run_id`, `created_by`, `updated_by`) and decimal (`overall_score`, `normalised_score`, `previous_overall`, `score_delta` — all `decimal:3`, MDL-02), leaving only the string `trend`/`at_risk_reason`/`overall_grade` columns, which are strings by design; `$table = 'ba_computed_overall'` exists in migration `2026_06_16_130634_create_ba_computed_overall_table.php` (MDL-07); `SoftDeletes` matches the table's `deleted_at` column and its `uq_guard` stored-generated unique guard, so the soft-delete × unique-index trap is handled at the DDL (MDL-03/VAL-04 n/a); no `InteractsWithMedia` (MDL-05/TEN-01 n/a); relations `student()`, `period()`, `scoreRun()` are return-typed and resolve (MDL-04, proven in tinker below). The linked models were checked only as used — eager loads resolve (`BaAssessmentRating::criterion.category`/`ratingLevel`, `BaIncident::student`/`category`/`interventions`/`followups`, `BaAssessment::teacher`/`reviewer`/`classSection.class`/`classSection.section`, `BaPeriod::academicSession`, `BaComputedScore::student`/`category`, `BaCategory::criteria`, `BaClassCategoryJnt::schoolClass`/`category`) and the usage matches.

**Evidence**
```
$ php artisan tinker --execute '... tenancy()->initialize(...); echo (new BaComputedOverall)->student()->getRelated()::class; ...'
ba_computed_overall total=193 trashed=0
ba_computed_scores total=1737 trashed=0
BaComputedOverall student related=Modules\StudentProfile\Models\Student
BaComputedOverall period related=Modules\BehaviouralAssessment\Models\BaAssessmentPeriod
BaComputedOverall scoreRun related=Modules\BehaviouralAssessment\Models\BaScoreRun
table ba_computed_overall exists: yes
```

### F8 — Services and jobs

#### BAR-07 · M · SVC-02/SVC-05 — the controller resolves the scoring services with `app()` mid-method, so their per-instance memoisation never persists

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection, not `new FooService()` or `app(Foo::class)` mid-method*; SVC-05 (M) — *repeated lookups inside a request are memoised or cached once.* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:55,87,618` — `app(BehaviouralScoreService::class)` and `app(BaFrameworkSnapshotService::class)` (also 404/566/676 for `BaReportExportService`, linked class) |
| **Root cause** | Neither service is bound as a singleton in the module provider (grep finds no `singleton` binding), so every `app(...)` call returns a fresh instance with an empty `$memo`/`$scaleCache`. `student()` calls `frozenFramework()` four times (once in `resolveScale`, three times in `overlayFrozen`), each of which re-runs `lockedFramework()` → `snapshotFor()` (a `BaFrameworkSnapshot::find`) plus `frameworkFor()` on a new instance, and `period()` calls `app(...)->frameworkFor($period)` which re-runs the live-framework build on a fresh instance. `BaFrameworkSnapshotService::$memo` (line 68-69) is keyed by `db:period:snapshot` and would serve all four calls if the instance were shared, exactly as its comment intends. |
| **Consequence** | A single report request repeats `snapshotFor`/`frameworkFor` lookups (up to 8 `find`s in `student()`; a full live-framework build per call in `lockedFramework`), so the memoisation the services were written with is dead on the report screens. |
| **Reproduce** | Static only — `grep -nE "app\([A-Za-z]+Service::class\)" BaReportController.php` lists the six `app()` sites; no `singleton` binding exists under `Modules/BehaviouralAssessment/app/Providers`. |
| **Fix approach** | Add a constructor to the controller that injects `BehaviouralScoreService` and `BaFrameworkSnapshotService`, and replace the three `app(...)` calls (55, 87, 618) with the injected properties. The two services stay transient per request but now one instance serves the whole request, so their memo caches work. (`BaReportExportService` at 404/566/676 is a linked class; its `app()` pattern is BAEXP-05's business.) |
| **Plan item** | BAR-07 in `02-fix-plan.md` §6 |

```php
// BaReportController.php:53-55 — CURRENT
    private function resolveScale(?BaAssessmentPeriod $period, ?int $classId = null): array
    {
        $service = app(BehaviouralScoreService::class);
```

**Evidence**
```
$ grep -nE "app\([A-Za-z]+Service::class\)" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
55:        $service = app(BehaviouralScoreService::class);
87:        return app(BaFrameworkSnapshotService::class)->lockedFramework($period);
404:        $pseudonyms = $anon ? app(BaReportExportService::class)->classPseudonyms((int) $classSection->id) : [];
566:        $pseudonyms = $anon ? app(BaReportExportService::class)->incidentPseudonyms($fromDate, $toDate) : [];
618:        $framework = app(BaFrameworkSnapshotService::class)->frameworkFor($period);
676:        $pseudonyms = $anon ? app(BaReportExportService::class)->teacherPseudonyms((int) $period->id) : [];
$ grep -rn "singleton" Modules/BehaviouralAssessment/app/Providers
(no output — no singleton bindings)
```

For the rest of F8: clean. `BaFrameworkSnapshotService` has no HTTP calls, no writes on its read path (`frameworkFor`/`lockedFramework`/`buildLive`/`snapshotFor` are reads; `capture()` is the single write, called by the lock path that owns its transaction), one builder for both sources (no duplicate implementation, SVC-04), and the `$memo` key already carries the database name for tenant safety. `BehaviouralScoreService` uses constructor injection (line 67, SVC-02), its read methods (`scaleForPeriod`, `configFor`, `atRiskPercent`, the `get*` getters, `integrableOverall`) write nothing (SVC-03), and its write path is the single `computeForPeriod` engine. There are no jobs in this controller's scope (the export job is owned by the BaReportExportController report; the score compute jobs run through the assessment controller's report).

### F9 — Queries and performance

#### BAR-08 · M · QRY-01 — the scoring run queries `ba_assessment_ratings` once per class-section

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H, lowered to M: the run is an admin/background batch over a bounded set of sections and students, not a user screen) — *no queries inside loops.* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php:224-240`, method `runComputation()` |
| **Root cause** | `BaAssessmentRating::whereIn('assessment_id', $sectionAssessments->pluck('id'))` runs inside `foreach ($assessments->groupBy('class_section_id') ...)`, so the run issues one ratings query per class-section. A school with 40 sections pays 40 queries where one `whereIn` over every assessment id would do. |
| **Consequence** | A whole-school score run (period lock/recompute) issues a query burst proportional to the number of class-sections, each fetching the same table with a different id list. |
| **Reproduce** | Static only — the query sits at line 237 inside the section loop; a locked-period recompute over many sections would show the N+1 in the query log. |
| **Fix approach** | Hoist one `whereIn` over all assessment ids before the loop, `groupBy('assessment_id')`, and take each section's rows from the map. |
| **Plan item** | BAR-08 in `02-fix-plan.md` §6 |

```php
// BehaviouralScoreService.php:224-240 — CURRENT
        foreach ($assessments->groupBy('class_section_id') as $sectionId => $sectionAssessments) {
            $classId = $classIdBySection->get($sectionId);
            $classId = $classId !== null ? (int) $classId : null;

            $scale = BaFrameworkSnapshotService::scaleFor($framework, $classId);
            if (! $scale) {
                $stats['warnings']['no_scale_class_sections'][] = (int) $sectionId;

                continue;
            }

            $teacherByAssessment = $sectionAssessments->pluck('teacher_id', 'id');

            $ratings = BaAssessmentRating::whereIn('assessment_id', $sectionAssessments->pluck('id'))
                ->whereNotNull('rating_value')
                ->where('is_active', true)
                ->get(['id', 'assessment_id', 'student_id', 'criterion_id', 'rating_value']);
```

**Evidence**
```
$ sed -n '224,240p' Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php
        foreach ($assessments->groupBy('class_section_id') as $sectionId => $sectionAssessments) {
            $classId = $classIdBySection->get($sectionId);
            $classId = $classId !== null ? (int) $classId : null;

            $scale = BaFrameworkSnapshotService::scaleFor($framework, $classId);
            if (! $scale) {
                $stats['warnings']['no_scale_class_sections'][] = (int) $sectionId;

                continue;
            }

            $teacherByAssessment = $sectionAssessments->pluck('teacher_id', 'id');

            $ratings = BaAssessmentRating::whereIn('assessment_id', $sectionAssessments->pluck('id'))
                ->whereNotNull('rating_value')
                ->where('is_active', true)
                ->get(['id', 'assessment_id', 'student_id', 'criterion_id', 'rating_value']);
```

#### BAR-09 · M · QRY-01 — the scoring run issues two queries per student (`previousOverall()` and the at-risk incident count)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H, lowered to M: the run is an admin/background batch, not a user screen) — *no queries inside loops.* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php:387,390` (calls into `previousOverall()` at 551-565 and `atRisk()` at 600-626) |
| **Root cause** | Inside the per-student loop of `runComputation()`, `computeStudentRows()` calls `previousOverall()` — a joined `BaComputedOverall` lookup (line 553) — and `atRisk()` — a `BaIncident` count per student (line 613). For N students a run issues ~2N extra queries, all of which could be two grouped queries resolved once. |
| **Consequence** | A whole-school score run over hundreds of students issues hundreds of small indexed queries, adding seconds to the period lock/recompute path. |
| **Reproduce** | Static only — `grep -n "previousOverall\|BaIncident::where('student_id'" BehaviouralScoreService.php` shows the per-student call sites. |
| **Fix approach** | Pre-fetch the latest earlier-period overalls (one joined query, grouped by student) and the negative-incident counts (one grouped `count(*)` query) before the student loop, and pass the two keyed collections into `computeStudentRows()`/`atRisk()`. |
| **Plan item** | BAR-09 in `02-fix-plan.md` §6 |

```php
// BehaviouralScoreService.php:386-390 — CURRENT
        $previous = $this->previousOverall($studentId, $period);
        $delta = ($overall !== null && $previous !== null) ? round($overall - $previous, 3) : null;

        [$isAtRisk, $atRiskReason] = $this->atRisk($studentId, $period, $overall, $scaleMin, $range, $config);
```

**Evidence**
```
$ sed -n '387,390p' Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php
        $previous = $this->previousOverall($studentId, $period);
        $delta = ($overall !== null && $previous !== null) ? round($overall - $previous, 3) : null;

        [$isAtRisk, $atRiskReason] = $this->atRisk($studentId, $period, $overall, $scaleMin, $range, $config);
$ sed -n '610,619p' Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php
        $incidentLimit = (int) ($config['at_risk_incident_count'] ?? self::DEFAULT_AT_RISK_INCIDENT_COUNT);
        if ($incidentLimit > 0) {
            $negatives = BaIncident::where('student_id', $studentId)
                ->where('incident_type', 'negative_incident')
                ->where('status', '!=', 'cancelled')
                ->where('is_active', true)
                ->whereBetween('incident_date', [$period->start_date, $period->end_date])
                ->count();
```

#### BAR-10 · M · QRY-07 — `persistStudentRows()` writes `ba_computed_scores` one `updateOrCreate` at a time

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M, no change) — *bulk writes: `insert()`, `upsert()`, `whereIn(...)->update()` instead of `create()`/`update()` per row in a loop.* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php:421-427`, method `persistStudentRows()` |
| **Root cause** | Each student's category rows are written with one `BaComputedScore::updateOrCreate()` per category inside a `foreach`. The table has a unique index `uq_ba_score (student_id, category_id, period_id, uq_guard)`, so the rows could be a single `upsert()` per student. |
| **Consequence** | The write path issues one upsert statement per category per student (up to ~categories × students statements per run); with the existing transaction the data is safe, but the statement count is several times the minimum. |
| **Reproduce** | Static only — the loop is at lines 421-427. |
| **Fix approach** | Accepted for this pass: the loop is bounded by the number of categories per student (single digits), runs inside the one score-run transaction, and the table size today is 1,737 rows; the statement count is not the bottleneck of the run. |
| **Plan item** | none — see `02-fix-plan.md` §10 (accepted, bounded) |

```php
// BehaviouralScoreService.php:419-427 — CURRENT
        $written = 0;

        foreach ($rows['categories'] as $categoryId => $attributes) {
            BaComputedScore::updateOrCreate(
                ['student_id' => $studentId, 'category_id' => $categoryId, 'period_id' => $period->id],
                $attributes + $stamp
            );
            $written++;
        }
```

**Evidence**
```
$ sed -n '419,427p' Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php
        $written = 0;

        foreach ($rows['categories'] as $categoryId => $attributes) {
            BaComputedScore::updateOrCreate(
                ['student_id' => $studentId, 'category_id' => $categoryId, 'period_id' => $period->id],
                $attributes + $stamp
            );
            $written++;
        }
$ grep -n "uq_ba_score" database/migrations/tenant/2026_06_16_130619_create_ba_computed_scores_table.php
44:            $table->unique(['student_id', 'category_id', 'period_id', 'uq_guard'], 'uq_ba_score');
```

#### BAR-11 · M · QRY-01 — `buildLive()` queries `ba_rating_levels` once per scale

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H, lowered to M: the scales set is at most class-override + session + default, so usually 1-3 rows) — *no queries inside loops.* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php:298-307`, method `buildLive()` |
| **Root cause** | `BaRatingScale::whereIn(...)->get()->map(fn (BaRatingScale $s) => [ ... 'levels' => BaRatingLevel::where('rating_scale_id', $s->id)...` issues a `ba_rating_levels` query per scale inside the `map`. |
| **Consequence** | Each framework build performs one levels query per scale (plus the scale query already batched) — a small N+1 that repeats on every snapshot capture and every live-period report call that reaches `frameworkFor()`. |
| **Reproduce** | Static only — `sed -n '298,307p'` shows the nested query. |
| **Fix approach** | Eager-load the levels: query `BaRatingScale::with('levels')->whereIn(...)`, filter active levels in PHP, or prefetch `BaRatingLevel::whereIn('rating_scale_id', $scaleIds)` once and group by `rating_scale_id`. |
| **Plan item** | BAR-11 in `02-fix-plan.md` §6 |

```php
// BaFrameworkSnapshotService.php:298-307 — CURRENT
        $scales = BaRatingScale::whereIn('id', $scaleIds)->where('is_active', true)->orderBy('id')->get()
            ->map(fn (BaRatingScale $s) => [
                'id' => (int) $s->id,
                'code' => $s->code,
                'name' => $s->name,
                'grade_type' => $s->grade_type,
                'min_rating' => self::dec($s->min_rating),
                'max_rating' => self::dec($s->max_rating),
                'is_default' => (bool) $s->is_default,
                'levels' => BaRatingLevel::where('rating_scale_id', $s->id)->where('is_active', true)->orderBy('id')->get()
                    ->map(fn (BaRatingLevel $l) => [
```

**Evidence**
```
$ sed -n '298,307p' Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php
        $scales = BaRatingScale::whereIn('id', $scaleIds)->where('is_active', true)->orderBy('id')->get()
            ->map(fn (BaRatingScale $s) => [
                'id' => (int) $s->id,
                'code' => $s->code,
                'name' => $s->name,
                'grade_type' => $s->grade_type,
                'min_rating' => self::dec($s->min_rating),
                'max_rating' => self::dec($s->max_rating),
                'is_default' => (bool) $s->is_default,
                'levels' => BaRatingLevel::where('rating_scale_id', $s->id)->where('is_active', true)->orderBy('id')->get()
                    ->map(fn (BaRatingLevel $l) => [
```

#### BAR-12 · M · QRY-03/QRY-15 — the period dropdown loads every period row, whole, on four pages

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M) — *select only what you use; JSON endpoints must not return whole models*; QRY-15 (M) — *don't load every row of a big table for a form.* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:155,263,587,695` — `BaAssessmentPeriod::orderByDesc('created_at')->get()` |
| **Root cause** | The same unbounded `->get()` feeds the period selector on `student()`, `byClass()`, `period()` and `categories()`. Every column of every period (including `snapshot_id`, `locked_by`, timestamps, and the `uq_guard` generated column) is hydrated just to render `id`/`name`/`status` in a dropdown. |
| **Consequence** | As a school accumulates periods, four report pages hydrate the full period table for a selector that needs three columns; the payload and hydration cost grow with no user benefit. |
| **Reproduce** | Open any of the four report pages and watch the query log — one `select * from ba_assessment_periods` per page. |
| **Fix approach** | Select only the columns the dropdown renders (`id`, `name`, `status`, `created_at`). The dropdowns use `$p->id`, `$p->name`, `$p->status` (and `created_at` for the fallback order in `student()`), so `->get(['id', 'name', 'status', 'created_at'])` is behaviour-preserving. |
| **Plan item** | BAR-12 in `02-fix-plan.md` §6 |

```php
// BaReportController.php:155 — CURRENT (identical at 263, 587, 695)
        $periods = BaAssessmentPeriod::orderByDesc('created_at')->get();
```

**Evidence**
```
$ grep -n "BaAssessmentPeriod::orderByDesc('created_at')->get()" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
155:        $periods = BaAssessmentPeriod::orderByDesc('created_at')->get();
263:        $periods = BaAssessmentPeriod::orderByDesc('created_at')->get();
587:        $periods = BaAssessmentPeriod::orderByDesc('created_at')->get();
695:        $periods = BaAssessmentPeriod::orderByDesc('created_at')->get();
```

For the rest of F9: clean. The incident log paginates at 10 (line 559) with `withQueryString()` on the links (VIEW `incidents.blade.php:630`); it is the only paginator on that page, so no page-name collision (QRY-13). Aggregates are done in SQL (`selectRaw` + `groupBy`, lines 112-114, 121-130, 367-371, 448-495, 542-551, 604-607, 654-658, 661-664, 708-721, 742-759). `exists()`/`count()`/`pluck()`/`value()` are used instead of `get()->...` (e.g. `distinct('student_id')->count('student_id')` at 108; `->count()` at 362-364, 456-460). No interpolated raw SQL — the raw `selectRaw` strings carry only literals and bindings (QRY-11 clean). Scanner candidate QRY-05 on `integrableOverall()` (`->get()->unique('student_id')`) is rejected: the result is bounded by `whereIn('student_id', $studentIds)` and the `unique('student_id')` implements "latest locked period per student", which the method's contract requires; it is not called from any route of this controller anyway. Scanner candidates QRY-15 on `buildLive()`'s `BaCategory::orderBy('id')->get()` / `BaCriterion::...->get()` / `BaClassCategoryJnt::...->get()` are rejected: the framework snapshot deliberately carries every row (inactive categories are kept with their flag so a since-deactivated criterion's rating still scores — service docblock lines 44-46), and the masters are small tables.

### F10 — Views

#### BAR-13 · M · VIEW-01 — the export register runs its paginated query (and per-row label queries) inside the Blade template

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H, lowered to M: the listing is paginated at 10 and the only page it renders, and the per-row `describeFilters()` lookups are the service's BAEXP-06) — *no queries in Blade.* |
| **Where** | `Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_exports.blade.php:19-23,92` — `$exRows = $exSvc->listing(...)` and `{{ $exSvc->describeFilters($ex) }}` |
| **Root cause** | The partial resolves `BaReportExportService` with `app()` inside the template and runs the paginated listing query at line 23, then calls `describeFilters($ex)` once per row at line 92 (each call resolves period/class/student/category labels with its own queries — BAEXP-06). The comment at lines 16-17 says the data is loaded "here rather than in BaDashboardController::reportsPage", so the page's data loading is deliberately in the view instead of the controller. |
| **Consequence** | The Exports tab performs its primary query (`listing`) and a burst of label lookups from inside Blade, which no unit can intercept, cannot be cached at the controller, and breaks the VIEW-01 rule the rest of the module follows. |
| **Reproduce** | Open `behavioural-assessment/reports-page?tab=exports` with a few exports and inspect the query log — the listing plus per-row label queries originate from the template render. |
| **Fix approach** | Move the `listing()` call (and the label lookups) into the rendering controller — `BaDashboardController::reportsPage()` — and pass `$exRows`/`$exSvc` to the partial. That controller is not audited yet (no report folder), so this is a cross-controller DECISION. |
| **Plan item** | BAR-13 in `02-fix-plan.md` §9 (DECISION) |

```php
// _exports.blade.php:19-23 — CURRENT
@php
    $exSvc = app(\Modules\BehaviouralAssessment\Services\BaReportExportService::class);
    $exCanAll = \Illuminate\Support\Facades\Gate::allows(\Modules\BehaviouralAssessment\Services\BaReportExportService::VIEW_ALL_PERMISSION);
    $exAll = $exCanAll && request('ex_scope') === 'all';
    $exRows = $exSvc->listing($exAll, (int) auth()->id(), 10);
```

**Evidence**
```
$ sed -n '19,23p' Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_exports.blade.php
@php
    $exSvc = app(\Modules\BehaviouralAssessment\Services\BaReportExportService::class);
    $exCanAll = \Illuminate\Support\Facades\Gate::allows(\Modules\BehaviouralAssessment\Services\BaReportExportService::VIEW_ALL_PERMISSION);
    $exAll = $exCanAll && request('ex_scope') === 'all';
    $exRows = $exSvc->listing($exAll, (int) auth()->id(), 10);
$ sed -n '90,93p' Modules/BehaviouralAssessment/resources/views/pages/partials/reports/_exports.blade.php
                        </div>
                    </td>
                    <td class="small text-muted" style="max-width:260px">{{ $exSvc->describeFilters($ex) }}</td>
                    <td class="small text-uppercase">{{ $ex->format }}</td>
```

For the rest of F10: clean. Every relation used inside a `@foreach` on the six report pages is eager-loaded by the controller (VIEW-02): `student.blade` `$rating->criterion?->category`/`$rating->ratingLevel` (eager `criterion.category`, `ratingLevel`, lines 193), `$incident->interventions`/`->category` (eager, line 210-211), `$remark->assessment?->teacher` (eager, line 204); `by-class.blade` `$ss['student']`/`$ss['category_scores']` (from `BaComputedScore::with(['student','category'])`, line 275), `$sec->class`/`->section` (eager `classSection.class`, `classSection.section`, line 598); `period.blade` `$tp['teacher']`/`$tp['sections']` (eager `teacher`, `classSection.class`, `classSection.section`, line 598); `incidents.blade` `$fu->student`/`->category` (eager, line 517-518), `$incident->student`/`->category`/`->interventions` (eager, line 555), and the `$openInterventions` rows are plain DB results (line 528, no lazy models). No `{!! !!}` anywhere in the report views or the partial (proved by grep → no output), so there is no stored-XSS surface (VIEW-03). No `{{ $model->relation }}` raw-row dumps. The only `@can` on the export form uses the service's `EXPORT_PERMISSION` constant (export-component-standard §11) — good. One dead `$sc` variable sits in `index.blade.php:136` (assigned, never used on that line's branch) — style-level, folded into BAR-16's Pint pass only if Pint touches it (it will not; noted here, not raised).

### F11 — Security and tenancy

#### BAR-15 · L · TEN-02 — `BehaviouralScoreService::$scaleCache` keys do not carry the tenant

| Field | Value |
|---|---|
| **Rule** | TEN-02 (H, lowered to L: no singleton binding or queue holder exists today, so no cross-tenant sharing can occur) — *cache keys and static/in-memory caches include the tenant.* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php:690-692`, method `resolveScale()` |
| **Root cause** | The memo key is `$academicSessionId.':'.($classId ?? '-')` with no tenant component. The sibling service (`BaFrameworkSnapshotService::$memo`) keys by `$period->getConnection()->getDatabaseName()`, so the codebase's own convention shows the tenant must be in the key. Today the service is transient per `app()` call and per request, so the cache cannot cross tenants — but the moment anything binds it as a singleton, a helper, or a tenant-iterating command resolves it once, a session id in tenant A returns tenant B's scale. |
| **Consequence** | Latent: today no wrong scale is served; if the service ever becomes shared, a class's cached scale leaks across tenants. |
| **Reproduce** | Static only — no live cross-tenant holder exists (grep `singleton` in the module provider → no output), so this is a latent defect, not reachable today. |
| **Fix approach** | Prefix the key with the connection database name, exactly as `BaFrameworkSnapshotService::$memo` does. One line. |
| **Plan item** | BAR-15 in `02-fix-plan.md` §6 |

```php
// BehaviouralScoreService.php:690-692 — CURRENT
    public function resolveScale(int $academicSessionId, ?int $classId = null): ?BaRatingScale
    {
        $key = $academicSessionId.':'.($classId ?? '-');
```

**Evidence**
```
$ sed -n '690,694p' Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php
    public function resolveScale(int $academicSessionId, ?int $classId = null): ?BaRatingScale
    {
        $key = $academicSessionId.':'.($classId ?? '-');

        if (array_key_exists($key, $this->scaleCache)) {
```

For the rest of F11: clean. No `env()` outside config (grep over the controller and both owned services → no output, SEC-01). No hard-coded user/tenant/status ids (`?? 1.0` at controller lines 62/68 are scale-minimum fallbacks for `min_rating`, not ids — SEC-03). Report pages show student/teacher names only to users holding the `.view` permission, with the anonymised flip (`?anonymised=1`, BR-BA-020) that replaces identifiers with stable cohort pseudonyms — the pseudonym map is keyed by the report scope and the ids are hashed, not alphabetical (SEC-02). The `ba_report_exports` download path is the linked export controller's business (SEC-05). No secrets are logged: the only log sites log report codes, ids and errors, never request bodies (SEC-04); BAR-01/BAR-14 remove the two `getMessage()`-only log lines.

### F12 — Style

#### BAR-16 · L · STY-02/CTL-10 — `BaReportController.php` is not Pint-clean and carries two unused imports

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)*; CTL-10 (M, reported at L here as dead imports) — *no unused properties/imports.* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:21,25` (`use ...BaConfig;` and `use ...BaRatingScale;`) plus the Pint fixer list below |
| **Root cause** | `vendor/bin/pint --test` reports `fully_qualified_strict_types`, `unary_operator_spaces`, `no_unused_imports`, `not_operator_with_successor_space`, `ordered_imports` on the controller, and greps confirm `BaConfig` (line 21) and `BaRatingScale` (line 25) are imported but never referenced in the body. |
| **Consequence** | The file drifts from the enforced style; a later Pint run shows unrelated diffs, and the two dead imports suggest dead code paths. |
| **Reproduce** | Static only — `vendor/bin/pint --test --format agent` on the controller (output below). |
| **Fix approach** | Remove the two unused imports and run Pint on the file ($10 of the protocol runs Pint on every touched file anyway). |
| **Plan item** | BAR-16 in `02-fix-plan.md` §8 |

```php
// BaReportController.php:19-27 — CURRENT (the two unused imports are 21 and 25)
use Modules\BehaviouralAssessment\Models\BaComputedOverall;
use Modules\BehaviouralAssessment\Models\BaComputedScore;
use Modules\BehaviouralAssessment\Models\BaConfig;
use Modules\BehaviouralAssessment\Models\BaCriterion;
use Modules\BehaviouralAssessment\Models\BaAuditLog;
use Modules\BehaviouralAssessment\Models\BaIncident;
use Modules\BehaviouralAssessment\Models\BaRatingScale;
use Modules\BehaviouralAssessment\Models\BaReportExport;
use Modules\BehaviouralAssessment\Models\BaStudentRemark;
```

**Evidence**
```
$ vendor/bin/pint --test --format agent Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php Modules/BehaviouralAssessment/app/Models/BaComputedOverall.php Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php Modules/BehaviouralAssessment/app/Http/Requests/BaReportExportRequest.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Http\/Controllers\/BaReportController.php","fixers":["fully_qualified_strict_types","unary_operator_spaces","no_unused_imports","not_operator_with_successor_space","ordered_imports"]}]}
$ grep -n "BaConfig\|BaRatingScale" Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
21:use Modules\BehaviouralAssessment\Models\BaConfig;
25:use Modules\BehaviouralAssessment\Models\BaRatingScale;
```

#### BAR-17 · L · STY-04 — the `⚠` marker in a `BehaviouralScoreService` comment

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers.* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php:323`, method `computeStudentRows()` |
| **Root cause** | The inline comment starts with a `⚠` symbol marker (`* ⚠ This was (max + 1) - raw, ...`). The same marker appears in four controller comments (lines 293, 304, 383, 703) folded into BAR-16's Pint pass, and here in the owned service. |
| **Consequence** | Cosmetic only; the symbol is not an emoji in the strict sense, but the project style requires plain English markup-free comments. |
| **Reproduce** | Static only. |
| **Fix approach** | Replace `⚠` with a plain word ("Note:") in the one comment. |
| **Plan item** | BAR-17 in `02-fix-plan.md` §8 |

```php
// BehaviouralScoreService.php:323 — CURRENT
                 * ⚠ This was (max + 1) - raw, which is the same thing ONLY when the
```

**Evidence**
```
$ sed -n '323p' Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php
                 * ⚠ This was (max + 1) - raw, which is the same thing ONLY when the
```

For the rest of F12: clean. `declare(strict_types=1);` present in the controller, both services, the model and the FormRequest (STY-01). Named variables are camelCase and unabbreviated (STY-03). One import per class (STY-05 — the only duplication issue is the unused pair covered by BAR-16). `Log::` and `\Log::` are used consistently as `Log::` (STY-06). No commented-out code in the controller or the owned services (grep → no output, STY-04).

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutation (method) | 1 wrong-data overwrite | 2 delete-before-store | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| controller `export()` (INSERT `ba_report_exports` via service + 2 INSERT `ba_audit_log`) | ok — service creates one row, this method never updates it | ok — no deletes | ok — one export-request path (service is the only writer) | ok — no unique index on `ba_report_exports` | ok — one row per POST; no check-then-act | ok — `BaReportExportRequest::authorize()` runs first | BAR-02 (raw error text in flash); the `requested`/`downloaded` event literals are accurate | ok — register/download consumer exists (linked export report) |
| service `BaFrameworkSnapshotService::capture()` (INSERT `ba_framework_snapshots`) | ok — new row per capture, version = max+1 under `lockForUpdate` | ok — nothing deleted | ok — one capture builder | ok — no soft-delete on snapshots | ok — `lockForUpdate()->max('version')` inside the caller-owned transaction (TXN-06 satisfied) | ok — called by `BaPeriodService::lock`, not user-routed | ok — version/checksum accurate | ok — read by `frameworkFor()`/period report |
| service `BehaviouralScoreService::computeForPeriod()` (INSERT `ba_score_runs` + the runComputation transaction) | ok — compare mode leaves stored rows untouched; write mode overwrites only the same student+period+category keys | ok — nothing deleted | ok — the single scoring engine; compare vs write are one implementation | ok — `updateOrCreate` scopes out trashed rows; `uq_guard` handles the soft-delete unique index at DDL | ok — one run row per trigger; `hasSnapshotBaseline` excludes the current run | ok — not user-routed; triggered by the assessment/recompute/lock paths | BAR-14 (raw error text persisted) | ok — `ba_computed_overall`/`ba_computed_scores` consumed by these reports and the result-integration pull |
| service `persistStudentRows()` (upsert `ba_computed_scores` + `ba_computed_overall`) | ok — overwrites only its own student+period(+category) keys with authority (BR-BA-064 compare mode skips it) | ok — no deletes | ok — one persist path | ok — `updateOrCreate` + `uq_guard` (BAR-10 is performance only) | ok — inside the single run transaction | ok — not user-routed | ok — row values match the computation (BAR-10 QRY-07 only) | ok — consumed by reports/rank/integration |
| service `BaReportExportService::request()` + `generate()` (writes `ba_report_exports` + `ba_audit_log` + file) | ok — handled by the linked export report (BAEXP-03, BAEXP-01) | ok — file replaced only after `write()` succeeds (generate) | ok — one export builder | ok — no unique index | BAR-10 n/a; BAEXP-03's transaction gap owned by the export report | ok — gated at the controller FormRequest | BAR-02 (flash echoes error_message) | ok — register/download consumers exist |

#### BAR-18 · M · CTL-06 — the student report's "Class Rank" is a school-wide period rank, not a class rank

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in services/actions, not ad hoc in the controller*; secondary deep-read #7 — *does any message lie?* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php:223-234`, method `student()`; label at `Modules/BehaviouralAssessment/resources/views/reports/student.blade.php:84-86` |
| **Root cause** | `$classRankData` queries `ba_computed_overall` for the whole period with no class filter (`where('period_id', ...)` only, lines 225-230), so the rank is among every scored student of the period, school-wide. The view labels the widget "Class Rank" with the subtitle "Overall scored students" (`student.blade.php:84-86`), and the controller's own comment (line 223) says "Rank among the period's students". The rank and its label describe different scopes. |
| **Consequence** | A teacher reading "Class Rank 5 / 120" assumes a class of 40, while the number actually ranks the student across the whole school's scored students; the figure over- or under-states the student's standing in their own class. |
| **Reproduce** | Open `behavioural-assessment/reports/student/{student}` for a student in a class smaller than the school — the Class Rank denominator is the whole period's scored students, not the class's. |
| **Fix approach** | DECISION: either relabel the widget to "Rank (period-wide)" without changing the computation, or scope `$classRankData` to the student's class-section so the label matches a class rank. |
| **Plan item** | BAR-18 in `02-fix-plan.md` §9 (DECISION) |

```php
// BaReportController.php:223-234 — CURRENT
        // Rank among the period's students by the stored overall (ba_computed_overall).
        $classRankData = $period
            ? BaComputedOverall::where('period_id', $period->id)
                ->where('is_active', true)
                ->whereNotNull('overall_score')
                ->orderByDesc('overall_score')
                ->get(['student_id', 'overall_score'])
            : collect();

        $classRank = $classRankData->search(fn ($row) => $row->student_id === $student->id);
        $classRank = $classRank !== false ? $classRank + 1 : null;
        $totalStudentsRanked = $classRankData->count();
```

**Evidence**
```
$ sed -n '223,234p' Modules/BehaviouralAssessment/app/Http/Controllers/BaReportController.php
        // Rank among the period's students by the stored overall (ba_computed_overall).
        $classRankData = $period
            ? BaComputedOverall::where('period_id', $period->id)
                ->where('is_active', true)
                ->whereNotNull('overall_score')
                ->orderByDesc('overall_score')
                ->get(['student_id', 'overall_score'])
            : collect();

        $classRank = $classRankData->search(fn ($row) => $row->student_id === $student->id);
        $classRank = $classRank !== false ? $classRank + 1 : null;
        $totalStudentsRanked = $classRankData->count();
$ sed -n '82,88p' Modules/BehaviouralAssessment/resources/views/reports/student.blade.php
                    @if($classRank)
                    <div class="p-3 rounded-3 bg-light text-center">
                        <div class="text-muted small mb-1">Class Rank</div>
                        <div class="fw-bold fs-3 text-primary">{{ $classRank }} / {{ $totalStudentsRanked }}</div>
                        <div class="text-muted small">Overall scored students</div>
                    </div>
                    @endif
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:129-147` | `request()` writes `ba_report_exports` + `ba_audit_log` with no transaction; a failure between the two breaks the disclosure record. Already BAEXP-03 in the export report. | TXN-01 | BaReportExportController report |
| `Modules/BehaviouralAssessment/app/Services/BaReportExportService.php:192-195` | `generate()` stores raw `$e->getMessage()` into the user-visible `error_message` column — the source of the BAR-02 flash text and of the register tooltip (BAEXP-01). | ERR-01 | BaReportExportController report |
| `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php:131-164` | `BaAuditLog::log()` reads `request()->ip()` / `request()->userAgent()` itself (an HTTP touch in a model); the export service and this controller rely on it. | SVC-01 (paradigm) | BaAuditLogController report |
| `Modules/BehaviouralAssessment/resources/views/pages/reports.blade.php:364` + `BaDashboardController::reportsPage` | The dashboard controller renders the `_exports` partial (owned by this report) but is not itself audited yet (no report folder); that is why BAR-13's fix is a decision. | VIEW-01 | main session (queue BaDashboardController audit) |
| `<x-backend.components.breadcrum title="..." :links="[]" />` | All six report pages hand the breadcrumb component an empty links array instead of resolving the trail (`:links="[]"` in every report view line 3). Common component; a consistent trail would need each page's menu context. | F10 breadcrumb standard | main session (template-level standard, not per-controller) |
| `Modules/BehaviouralAssessment/app/Support/BaPseudonym.php` | Pure static map/label helpers used by the anonymised views and the linked export service; no claim exists in `_Info/00-CLASS-OWNERS.md`. Static, no DB writes, so low risk. | — | main session (assign an owner) |
| `Modules/BehaviouralAssessment/app/Models/BaScoreRun.php` | Written by the owned `BehaviouralScoreService`; no claim exists. Its `ba_score_runs` table exists (migration `2026_06_16_130633`); the BAR-14 fix is in the service, not the model. | — | main session (assign an owner, likely BaAssessmentPeriodController) |

## 8. Not covered, and why

- **Browser click-through of the six report pages** — no authenticated session is available in this read-only audit (D4 anyway); every finding on the pages was verified statically by grep/sed against source, not by rendering.
- **The `_exports.blade.php` partial's rendering page** — it is included by `pages/reports.blade.php:364` under `@can('tenant.behavioural-assessment.reports.export')`, which is rendered by `BaDashboardController::reportsPage()` (a controller with no report folder yet). Its full audit belongs to the dashboard report; this report audits the partial's own content per the brief and leaves the fix as BAR-13.
- **The async export job path** — `GenerateReportExportJob` under `BA_ASYNC_JOBS` is owned by the BaReportExportController report (already audited/CLAIMED); it was not re-audited here.
- **The score-run/lock path** — `BaFrameworkSnapshotService::capture()`'s caller (`BaPeriodService::lock`) and the `computeForPeriod()` triggers (assessment approve/recompute/lock) run through BaAssessmentController/BaAssessmentPeriodController; only the service bodies were audited here.
- **`BaPseudonym`/`BaScoreRun`** — referenced only; neither has a `_Info/00-CLASS-OWNERS.md` claim, so they were checked as used rather than audited as owners (see §7 and the hand-back).
- **Blades were not compiled** — `view:cache`/compileString was not run to avoid side effects on the tenant caches; the templates were read in full, and the syntax expected by `@foreach`/`@php`/`@forelse` blocks was verified by eye. The lone dead `$sc` at `index.blade.php:136` and the emoji markers are noted but not raised as independent findings (BAR-16 covers the file-level cleanup).
- **The exports register and score-run register were empty/almost empty on the test tenant** (ba_report_exports 0 rows), so the BAR-02/BAR-13/BAR-14 user-visible paths are reasoned from code, not exercised.