# Final Audit — BehaviouralAssessment / BaIncidentAttachmentController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php` (112 lines, 4 public methods incl. `__construct`, 3 routed)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/behavioural-assessment/incidents/{incident}` (the incident show page, owned by `BaIncidentController`) is where the Evidence tab lists attachments and shows the Upload Evidence modal; this controller only serves the three actions on that page: POST `/behavioural-assessment/incidents/{incident}/attachments` (upload), GET `/behavioural-assessment/incident-attachments/{attachment}` (download), DELETE `/behavioural-assessment/incident-attachments/{attachment}` (remove) |
| Menu path | Behavioural Assessment → Incidents (page `behavioural-assessment.incidents-page`) → open an incident → Evidence tab |
| Who uses it | Holders of `tenant.behavioural-assessment.incidents.view` / `.update`, measured in `sys_permissions` + `sys_role_has_permissions_jnt` on the test tenant: **School Admin, Super Admin** (the sibling `BaIncidentController` report also found Principal holding `escalate`/`witness-confidential`; it does not change this audit) |
| What a user does here | Uploads one piece of incident evidence per request (JPG, JPEG, PNG, PDF, DOC, DOCX or MP4, up to 10 MB), optionally with a caption and a "Staff only — hide from parent/student views" flag; downloads that evidence; removes an attachment. Removal is a soft delete (the file stays on disk as evidence) and is allowed only for the uploader or a holder of `incidents.update`, and never once the incident is closed/cancelled. Files live on the private `local` disk under the tenant path prefix and are served ONLY through the authorised download action — there is no public URL. |
| Tables written | `ba_incident_attachments`, `ba_audit_logs` (via `BaAuditLog::log`, inside the transaction) |
| Tables read | `ba_incidents`, `ba_incident_attachments`, `sch_employees` (via `BaIncidentService::currentEmployee()`), `sys_users` (auth) |
| Live data | test tenant DB — `ba_incident_attachments` total=0, live=0, trashed=0 (measured 2026-10-12) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **production-ready in behaviour**: all three routed methods authorize before loading records, the upload path validates `file` + `mimes` + `max` in a FormRequest, files are stored on the private disk and served only through the gated download route (`Storage::download` with `X-Content-Type-Options: nosniff`), the delete path enforces uploader-or-`update` inside the service, and every write runs inside one transaction with an audit row after the write. The single worst finding is **BIAC-01**: like every other BA write controller, `store()` and `destroy()` wrap their transaction in a controller-level `try/catch` that maps MySQL `SQLSTATE 45000` trigger rejections into friendly form messages; D1 settled that controllers carry no `try/catch` and D2 does not list DB-trigger mapping among the allowed catches, so the shape is a settled-decision violation — safe today, drift-prone. The rest is small: `failed()` logs the exception message without the trace (BIAC-02), and two authorization strings are redundant or inconsistent with the effective rules (BIAC-03, BIAC-04, both accepted). Effort to clear the plan: **S–M** (one decision to make, then two one-line changes).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 2 | 2 | 1 | 4 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BIAC-01, BIAC-02 | F8 Services/Jobs | clean (linked) |
| F2 Transactions/Audit | clean (BAI-01 linked) | F9 Queries/Perf | clean |
| F3 Authorization | BIAC-03, BIAC-04 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | clean |
| F6 Controller shape | clean | F13 Deep read | table — no new IDs |
| F7 Models | clean (linked) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php` | controller | 112 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Http/Requests/BaIncidentAttachmentRequest.php` | FormRequest | 46 | this report (used only here; not registered in `_Info/00-CLASS-OWNERS.md`) | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Services/BaIncidentAttachmentService.php` | service | 124 | ↗ [tarun/BehaviouralAssessment-done/BaIncidentController-done](../BaIncidentController-done/01-report.md) | ↗ linked |
| 4 | `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php` | service | 633 | ↗ [tarun/BehaviouralAssessment-done/BaIncidentController-done](../BaIncidentController-done/01-report.md) | ↗ linked |
| 5 | `Modules/BehaviouralAssessment/app/Models/BaIncident.php` | model | 238 | ↗ [tarun/BehaviouralAssessment-done/BaIncidentController-done](../BaIncidentController-done/01-report.md) | ↗ linked |
| 6 | `Modules/BehaviouralAssessment/app/Models/BaIncidentAttachment.php` | model | 61 | ↗ [tarun/BehaviouralAssessment-done/BaIncidentController-done](../BaIncidentController-done/01-report.md) | ↗ linked |
| 7 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support | 37 | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |
| 8 | `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` | model | 203 | ↗ [tarun/BehaviouralAssessment-done/BaAuditLogController-done](../BaAuditLogController-done/01-report.md) | ↗ linked (reached via the service) |
| 9 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | 45 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked (reached via the service) |
| 10 | `Modules/SchoolSetup/app/Models/Employee.php` | other module | — | common (other module) | ❌ not audited here |
| 11 | `Modules/BehaviouralAssessment/routes/web.php` | route file | 167 | common (shared) | ✅ routes reviewed (lines 131-133) |
| 12 | `config/permissionslist.php` | config | — | common (shared) | ✅ names verified |

No pre-applied files (no `PRE-APPLIED-*.md` entry covers this controller or its FormRequest).

## 4. Routes

```
GET|HEAD behavioural-assessment/incident-attachments/{attachment} behavioural-assessment.incident-attachments.show Modules\BehaviouralAssessment\Http\Controllers\BaIncidentAttachmentController@download | middleware: [web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:BehaviouralAssessment, Authenticate, EnsureEmailIsVerified]
DELETE behavioural-assessment/incident-attachments/{attachment} behavioural-assessment.incident-attachments.destroy Modules\BehaviouralAssessment\Http\Controllers\BaIncidentAttachmentController@destroy | middleware: [web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:BehaviouralAssessment, Authenticate, EnsureEmailIsVerified]
POST behavioural-assessment/incidents/{incident}/attachments behavioural-assessment.incidents.attachments.store Modules\BehaviouralAssessment\Http\Controllers\BaIncidentAttachmentController@store | middleware: [web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:BehaviouralAssessment, Authenticate, EnsureEmailIsVerified]
```

Unrouted public methods: none. `__construct` is a constructor; `failed()` is private and called from both catches.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `store` | 35 | POST /incidents/{incident}/attachments | FormRequest `authorize()` first, then `Gate::authorize('tenant.behavioural-assessment.incidents.update')` | controller — `DB::transaction` wraps the whole service call | `BaAuditLog::log` event `attachment_added` (in service, after the write, inside tx) | ba_incident_attachments, ba_audit_logs | BIAC-01, BIAC-03 (BAI-01 linked) |
| `download` | 65 | GET /incident-attachments/{attachment} | `Gate::authorize('tenant.behavioural-assessment.incidents.view')` | none (read) | none | none | clean |
| `destroy` | 82 | DELETE /incident-attachments/{attachment} | `Gate::authorize('...incidents.view')` + service `canDelete()` (uploader or `...incidents.update`) | controller — `DB::transaction` wraps the whole service call | `BaAuditLog::log` event `attachment_removed` (in service, after the write, inside tx) | ba_incident_attachments, ba_audit_logs | BIAC-01, BIAC-04 |

## 6. Findings

### F1 — Errors

#### BIAC-01 · M · ERR-00 — store() and destroy() wrap their transaction in a controller-level try/catch that D2 does not sanction

| Field | Value |
|---|---|
| **Rule** | ERR-00 (D1 settles: no try/catch in controllers; D2 lists the only allowed catches — `\DomainException` business messages, one truncate-then-rebuild catch, `SnapshotProtectionException` verbatim, service `report($e)` + fixed message; DB-trigger mapping is **not** among them) |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php:45-57` (`store`), `:88-94` (`destroy`), funnelled through `failed()` at `:101-111` |
| **Root cause** | The module deliberately catches `Throwable` to translate a MySQL `SQLSTATE 45000` trigger rejection (`BA: …` text) into a 422 form error via `BaTriggerError::message()`. Without it, the friendly trigger text would never reach the user. The shape is centralised, re-throws `ValidationException`/`HttpExceptionInterface`, and never exposes raw SQL, so ERR-01/ERR-02 are not violated — but it is a controller try/catch outside the D2 list, exactly the pattern the sibling report flagged as BAI-03. |
| **Consequence** | No user-visible defect today. The risk is drift: each new write method must remember to route through `failed()`, and the shape contradicts D1's one-renderer design in `bootstrap/app.php`. |
| **Reproduce** | Static only — verified by reading the two `try {` sites. |
| **Fix approach** | DECISION: keep it documented (validate the D2 carve-out), remove it and lose the trigger messages, or move the mapping into an exception resolved in `bootstrap/app.php`. |
| **Plan item** | BIAC-01 in `02-fix-plan.md` §9 (DECISION) |

```php
// BaIncidentAttachmentController.php:45-57 — CURRENT (store)
        try {
            DB::transaction(fn () => $this->service->store(
                $model,
                $request->file('file'),
                $request->validated('caption'),
                (bool) $request->validated('is_staff_only'),
                $uploader
            ));
        } catch (ValidationException|HttpExceptionInterface $e) {
            throw $e;
        } catch (Throwable $e) {
            return $this->failed($e, 'store', ['incident' => $incident]);
        }
```

**Evidence**
```
$ grep -n "try {\|catch (\|Throwable" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php
22:use Throwable;
45:        try {
53:        } catch (ValidationException|HttpExceptionInterface $e) {
55:        } catch (Throwable $e) {
88:        try {
90:        } catch (ValidationException|HttpExceptionInterface $e) {
92:        } catch (Throwable $e) {
101:    private function failed(Throwable $e, string $method, array $context): RedirectResponse
```

Same shape in `destroy()` (`:88-94`, quoted from the file):

```php
// BaIncidentAttachmentController.php:88-94 — CURRENT (destroy)
        try {
            DB::transaction(fn () => $this->service->delete($row, $model, BaIncidentService::currentEmployee()));
        } catch (ValidationException|HttpExceptionInterface $e) {
            throw $e;
        } catch (Throwable $e) {
            return $this->failed($e, 'destroy', ['attachment' => $attachment]);
        }
```

#### BIAC-02 · M · ERR-05 — failed() logs the exception message but not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php:108`, method `failed()` |
| **Root cause** | Line 108 logs `['error' => $e->getMessage()]`. Because the controller catch swallows the exception and returns a redirect, the default exception handler never sees it, so the one-line message is the **only** record — no class, no file, no stack. |
| **Consequence** | When an upload or delete fails for an unexpected reason, the ops log shows a message with no trace, so nobody can tell where the failure happened. |
| **Reproduce** | Static only — the log line is reached only when `BaTriggerError::message()` returns null, i.e. a non-trigger failure. |
| **Fix approach** | Replace with `report($e)` plus a fixed-message log line (D2's service shape: report the exception, keep the context). |
| **Plan item** | BIAC-02 in `02-fix-plan.md` §3 |

```php
// BaIncidentAttachmentController.php:108 — CURRENT
        Log::error('BaIncidentAttachmentController::'.$method.' failed', $context + ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php
108:        Log::error('BaIncidentAttachmentController::'.$method.' failed', $context + ['error' => $e->getMessage()]);
```

ERR-01 clean — `grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php` shows only line 108, which feeds the log, not the user; `BaTriggerError::message()` returns only the curated `BA: …` text, and `failed()` otherwise returns the fixed string `'The operation could not be completed.'`.

### F2 — Transactions and audit

clean (for this controller's own code) — both mutations run inside **one** `DB::transaction(fn () => …)` closure (TXN-01/TXN-02 satisfied: attachment row + audit row); `BaAuditLog::log` is called by the service **after** the write and **inside** the transaction (`attachment_added` in `store`, `attachment_removed` in `delete` — TXN-04 satisfied with the module's audit helper instead of `activityLog()`); the redirect is built after the closure (TXN-05). The one TXN-03 defect on this path — the evidence file is written to disk by `BaIncidentAttachmentService::store()` at `Storage::putFileAs(...)` inside the transaction, so a rollback leaves an orphaned file — is **owned by `BaIncidentController` (BAI-01)**; proved by `grep -n "putFileAs" Modules/BehaviouralAssessment/app/Services/BaIncidentAttachmentService.php` → `56: $path = Storage::disk(self::DISK)->putFileAs($dir, $file, Str::uuid()->toString().'.'.$ext);`. Linked, not re-audited, no new ID.

### F3 — Authorization

#### BIAC-03 · L · AUTH-04 — store() authorizes the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (FormRequest `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php:37` (`store`); the FormRequest `authorize()` at `Modules/BehaviouralAssessment/app/Http/Requests/BaIncidentAttachmentRequest.php:19-22` runs first |
| **Root cause** | The FormRequest already checks `tenant.behavioural-assessment.incidents.update` via `authorizePermission()`, then the controller repeats the same `Gate::authorize` on the same string. Same pattern as BAI-07, accepted there. |
| **Consequence** | None for the user; a small maintenance cost — two places must agree on the permission string. |
| **Reproduce** | Static only — see evidence. |
| **Fix approach** | Keep the FormRequest guard (it runs first) and drop the duplicate controller `Gate::authorize` in `store()`. Accepted as low priority; the string is seeded and correct on both surfaces. |
| **Plan item** | none — see `02-fix-plan.md` §10 (accepted, mirroring BAI-07) |

```php
// BaIncidentAttachmentController.php:37 — CURRENT (store)
        Gate::authorize('tenant.behavioural-assessment.incidents.update');
```

The FormRequest guard that already ran (`BaIncidentAttachmentRequest.php:19-22`):

```php
    public function authorize(): bool
    {
        return $this->authorizePermission('tenant.behavioural-assessment.incidents.update');
    }
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php
37:        Gate::authorize('tenant.behavioural-assessment.incidents.update');
67:        Gate::authorize('tenant.behavioural-assessment.incidents.view');
84:        Gate::authorize('tenant.behavioural-assessment.incidents.view');
```

#### BIAC-04 · L · AUTH-06 — destroy()'s gate names the read permission while the delete authority lives only in the service

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (L) — *permission strings live in one place, not repeated as literals in every method; a gate must name the operation it guards* (severity kept L: no hole exists today) |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php:84` (`destroy`); the real authority is `BaIncidentAttachmentService::canDelete()` at `Modules/BehaviouralAssessment/app/Services/BaIncidentAttachmentService.php:89-97` (uploader id match **or** `Gate::allows(self::UPDATE_PERMISSION)`), called at `:89` inside the transaction |
| **Root cause** | A write endpoint (delete) is entered with the incident **read** permission `…incidents.view`; the operation's actual rule (uploader, or `…incidents.update`) is enforced only inside the service, and the `view` literal is also repeated in the blade row action `deletePermission="tenant.behavioural-assessment.incidents.view"` (`incident/show.blade.php:377`, owned by `BaIncidentController`). The three surfaces disagree about what this action requires. |
| **Consequence** | No hole today — `canDelete()` aborts 403 before any write, so a viewer who is neither the uploader nor an update-holder cannot remove anything. The risk is that a future edit trusts the written gate and drops the service check. No single permission string can replace the gate (`update` alone would block the uploader-only case), so the service must stay the authority. |
| **Reproduce** | Static only — see evidence. |
| **Fix approach** | Accepted low priority: keep the service's `canDelete()` as the single authority; align or document the controller gate. |
| **Plan item** | none — see `02-fix-plan.md` §10 (accepted) |

```php
// BaIncidentAttachmentController.php:82-86 — CURRENT (destroy)
    public function destroy(int $attachment): RedirectResponse
    {
        Gate::authorize('tenant.behavioural-assessment.incidents.view');
        $row = BaIncidentAttachment::findOrFail($attachment);
        $model = BaIncident::findOrFail($row->incident_id);
```

The effective authority (`BaIncidentAttachmentService.php:89-97`, owned by the `BaIncidentController` report):

```php
    public static function canDelete(BaIncidentAttachment $attachment, BaIncident $incident, ?Employee $actor): bool
    {
        if (in_array($incident->status, [BaIncident::STATUS_CLOSED, BaIncident::STATUS_CANCELLED], true)) {
            return false;
        }

        return ($actor !== null && (int) $attachment->uploaded_by === (int) $actor->id)
            || Gate::allows(self::UPDATE_PERMISSION);
    }
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php
67:        Gate::authorize('tenant.behavioural-assessment.incidents.view');
84:        Gate::authorize('tenant.behavioural-assessment.incidents.view');
$ mysql -N -e "USE xyz_school_00000000000040008000_202627; SELECT name FROM sys_permissions WHERE name IN ('tenant.behavioural-assessment.incidents.view','tenant.behavioural-assessment.incidents.update');"
tenant.behavioural-assessment.incidents.update
tenant.behavioural-assessment.incidents.view
```

Positive checks: every routed method authorizes before it loads any record (AUTH-01/AUTH-02 — `store` gates at :37 before `findOrFail` at :38; `download` gates at :67 before :68; `destroy` gates at :84 before :85); both permission names are declared in `config/permissionslist.php` under `behavioural-assessment.incidents` → `$crud` (which contains `'view'`, `'update'`) and are seeded with an **exact-name** query on the test tenant (`=`, never `LIKE`); on this tenant `view` and `update` are held by School Admin and Super Admin; `destroy`'s service check then enforces uploader-or-update (AUTH-03 record-level rule).

### F4 — Validation and input

clean — validation lives in `BaIncidentAttachmentRequest` (VAL-02); the upload carries `file` + `mimes` + `max` (VAL-06): `'file' => array_merge(['required'], BaIncidentAttachmentService::fileRules())` where `fileRules()` is `['file', 'max:10240', 'mimes:jpg,jpeg,png,pdf,doc,docx,mp4']` (10 MB — the message `'An attachment may not be larger than 10 MB.'` matches); `caption` is `nullable|string|max:255` (VAL-03 safe: the controller reads `$request->validated('caption')`, which returns null when absent); `is_staff_only` is typed `boolean` and normalised by `prepareForValidation()` (`$this->merge(['is_staff_only' => $this->boolean('is_staff_only')])`), read as `(bool) $request->validated('is_staff_only')`; the controller never passes `$request->all()` or `except()` into a model (VAL-01): only `validated()` keys reach the service. The FormRequest has no cross-field rules, so the §3.5.1 execution rule does not apply — reading the rules is enough.

### F5 — Routes

clean — all three routes point at methods that exist (RTE-02), verified by the filtered `route:list` in §4; every public method except the constructor is routed (RTE-03); no state change over GET (RTE-01: `download` is read-only; the writes are POST/DELETE); the route parameter names match the controller arguments (`incidents/{incident}` → `int $incident`, `incident-attachments/{attachment}` → `int $attachment`), so there is no unbound-model hazard (`module-finalization.md` §3.3.1); tenant + auth + verified middleware are present on all three routes (RTE-05, see §4 output); the custom routes are not shadowed by the `incidents` resource route registered at `routes/web.php:119` (no path collision).

### F6 — Controller shape

clean — 112 lines, 4 public methods, none over 80 lines (CTL-01/CTL-02); no debug leftovers (`grep -n "dd(\|dump(\|var_dump(\|print_r(\|ray("` → no output, CTL-09); no dead code — `failed()` is called from both catches (CTL-10). CTL-03 (route model binding) is **deliberately not applied**: `store()` uses `int $incident` + `findOrFail` strictly **after** authorization so a 404 cannot leak the incident's existence ahead of the FormRequest guard (AUTH-02), and `download()`/`destroy()` are keyed by the attachment id alone by design (docblock `:24-30`) so the standard `x-backend.table.action` component can address the row actions; the route parameter names still match the method arguments, so no §3.3.1 INSERT hazard. Return types are present on all public methods (CTL-04).

### F7 — Models

clean for usage — both models are owned by `BaIncidentController`; only the usage is audited here. `BaIncidentAttachment` uses `SoftDeletes`, so `BaIncidentAttachment::findOrFail($attachment)` returns 404 for a trashed row exactly as the docblock claims; `$fillable`, `$casts`, `$table` were audited in the owner report. `BaIncident::findOrFail($incident)` is used only to resolve the incident for the redirect and the service call.

### F8 — Services and jobs

clean for usage — `BaIncidentAttachmentService` is constructor-injected (SVC-02); the service performs no HTTP (SVC-01); there are no writes on read paths (SVC-03: `download` never writes); `BaIncidentService::currentEmployee()` is called once per request path. The file-write-inside-transaction in `BaIncidentAttachmentService::store()` is owned by `BaIncidentController` (BAI-01) — linked in F2.

### F9 — Queries and performance

clean — no query inside a loop; reads are single-row `findOrFail` calls; there is no list here to paginate (the listing lives on the incident show page, owned by `BaIncidentController`); no repeated lookups per request.

### F10 — Views

clean for this controller — it renders no views (it returns `RedirectResponse`s and one `StreamedResponse`). The upload modal and the download/destroy row actions live in `incident/show.blade.php` (owned by `BaIncidentController`); their route gating is checked in F11.

### F11 — Security and tenancy

clean — private files are stored on the `local` disk under the tenant path prefix (`TenantPathPrefix::get()`, service) and served **only** through the gated download route (SEC-05): `Gate::authorize('tenant.behavioural-assessment.incidents.view')` runs before the row is loaded, `findOrFail` refuses trashed rows, the response is a stream with `Content-Disposition: attachment` and `X-Content-Type-Options: nosniff` (no inline HTML execution); the stored `file_path` is a server-generated uuid path, never a request value, so there is no traversal; no `env()` outside config (SEC-01); no secrets logged — the only log input is the exception message plus the ids `incident`/`attachment` (SEC-04); no hard-coded ids or `?? 1` (SEC-03); all routes sit inside the tenancy middleware group (TEN context); the `is_staff_only` flag's promise ("hide from parent/student views") holds because no parent/student role holds any BA permission on the test tenant (measured: `view`/`update` → School Admin, Super Admin only).

### F12 — Style

clean —
```
$ vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentAttachmentController.php Modules/BehaviouralAssessment/app/Http/Requests/BaIncidentAttachmentRequest.php Modules/BehaviouralAssessment/app/Services/BaIncidentAttachmentService.php Modules/BehaviouralAssessment/app/Models/BaIncidentAttachment.php Modules/BehaviouralAssessment/app/Support/BaTriggerError.php
{"tool":"pint","result":"passed"}
```
`declare(strict_types=1)` present in every in-scope PHP file (STY-01); imports sorted, one per class, no `\Log::` vs `Log::` mix in this controller.

### F13 — Deep read (answer all 8 questions for every mutating method)

`download` is read-only — no row; the two mutating methods:

| Method | 1 overwrite? | 2 delete before replace? | 3 duplicate impls? | 4 soft-delete × unique? | 5 race? | 6 auth hole? | 7 message lies? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok (`fileRules()` single source) | ok | ok | ok — FormRequest + gate; BIAC-03 is a duplicate, not a hole; BAI-01 linked (file-in-tx) | ok — `'Attachment uploaded.'` only after the redirect target is resolved | ok |
| `destroy` | ok | ok (soft delete only; file kept) | ok (`canDelete()` single source) | ok (soft delete; `findOrFail` 404s trashed) | ok | ok — `canDelete()` uploader-or-update aborts 403 before any write; BIAC-04 is a mismatch, not a hole | ok — `'Attachment removed.'` only after success | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `BaIncidentAttachmentService::store()` (`putFileAs` inside the caller's `DB::transaction`) | Evidence file is written before the DB row commits; a rollback leaves an orphaned file. Same root cause as BAI-01; this controller's `store()` inherits it. | TXN-03 (B) | `BaIncidentController` fix plan (item BAI-01) |
| `incident/show.blade.php` row action `deletePermission="tenant.behavioural-assessment.incidents.view"` | The written permission for the delete action is the read permission; the real rule (uploader or `…incidents.update`) lives only in `canDelete()`. Agrees with the controller gate, so not a hole. | AUTH-06 | `BaIncidentController` report (the view is owned there) |
| `bootstrap/app.php` central exception renderer | No handler exists for BA `SQLSTATE 45000` trigger messages, which is why the controllers carry the D2-unsanctioned try/catch (BIAC-01). | ERR-00 | Decision item BIAC-01 §9 |

## 8. Not covered, and why

- **Live browser flow** — no upload/download/delete was exercised in a browser and no test was written (D4). Everything above is static proof or database measurement.
- **The storage layer** — the `local` disk root and the tenant path mapping (`TenantPathPrefix::get()`) were audited by the owner report of `BaIncidentAttachmentService`, not re-measured here.
- **DB triggers** — the `BA: …` message texts that `BaTriggerError` surfaces were not fired; verified by code reading only.
- **Parent/student exposure** — no parent/student portal route references `incident-attachments` (grep across the app found only `incident/show.blade.php`), so the staff-only promise rests on the roles measured on this test tenant.