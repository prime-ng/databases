# Final Audit — BehaviouralAssessment / BaAssessmentPeriodController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php` (427 lines, 16 methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /behavioural-assessment/assessment-periods` (redirects to the Setup tab), `GET /behavioural-assessment/assessment-periods/create`, `GET /behavioural-assessment/assessment-periods/{assessment_period}`, `GET /behavioural-assessment/assessment-periods/{assessment_period}/edit`, `GET /behavioural-assessment/assessment-periods/trash`, plus the writes `POST /assessment-periods`, `PUT /assessment-periods/{assessment_period}`, `DELETE /assessment-periods/{assessment_period}`, `GET /assessment-periods/{id}/restore`, `DELETE /assessment-periods/{id}/force-delete`, `POST /assessment-periods/{period}/toggle-status`, `POST /assessment-periods/{period}/close`, `POST /assessment-periods/{period}/reopen`, `POST /assessment-periods/{period}/lock`, `POST /assessment-periods/{period}/recompute` |
| Menu path | Behavioural Assessment → Setup page → Assessment Periods tab (the tab body is rendered by `BaDashboardController::setup()`; this controller's `index()` redirects there) |
| Who uses it | On tenant `00000000-0000-4000-8000-000000000001` all 11 `tenant.behavioural-assessment.assessment-periods.*` permissions are seeded and granted to **Super Admin** and **School Admin**; `recompute` is additionally granted to **Principal** (measured from `sys_role_has_permissions_jnt`) |
| What a user does here | A school admin defines an assessment window (name, start/end dates, submission deadline, optional academic term), edits it, activates/deactivates it, then moves it through its lifecycle: open → closed → locked (or closed → reopened → open). Locking freezes the framework into a snapshot and refuses while any sheet is still draft/submitted. An admin can also request a school-wide score recompute, and trash/restore/permanently delete a period. A locked period is terminal — there is deliberately no unlock action. |
| Tables written | `ba_assessment_periods` (this controller + `BaPeriodService`), `ba_audit_log` (service), `sys_activity_logs` (the `activityLog()` helper), `ba_assessments` and `ba_framework_snapshots` (service `lock()`), `ba_score_runs` / `ba_computed_scores` / `ba_computed_overall` (via `ComputeSchoolScoresJob`) |
| Tables read | `ba_assessment_periods`, `ba_assessments`, `ba_computed_scores`, `ba_audit_log`, `ba_framework_snapshots`, `ba_score_runs`, `sch_org_academic_sessions_jnt`, `sch_academic_term`, `sch_employees`, `sys_users` |
| Live data | On tenant `00000000-0000-4000-8000-000000000001`: `ba_assessment_periods` 4 live / 0 trashed (status spread `{"open":2,"closed":1,"locked":1}`); `ba_computed_scores` 1737 live / 0 trashed; `ba_assessments` 17 live / 0 trashed; `ba_score_runs` 2 rows; `ba_framework_snapshots` 1 row |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **close to production-ready — yes, after the two High items**. Every routed method authorizes before loading a record, every permission string resolves to a seeded key, the status FSM and its transactions live in `BaPeriodService`, no raw exception text reaches the user (only `\DomainException` business messages and the documented `BaTriggerError` BA-trigger text), and the soft-delete × unique-index design on `ba_assessment_periods` is coherent for create. The single worst finding is **BAP-07**: `restore` has no live-name clash check, so restoring a period after its name has been re-used fails with a generic "could not be completed" flash (the generated `uq_guard` recomputes to the live value and collides). The next is **BAP-08**: `restore` runs a state change over GET. The rest is the D1 shape decision (BAP-01), audit-log placement (BAP-03), responses built inside transactions (BAP-04), duplicate authorization (BAP-05), missing route-model binding (BAP-09), controller/service copy-paste (BAP-10, BAP-11) and mechanical style debt (BAP-13, BAP-14). Rough effort to apply the whole plan: **S–M (about half a day)**.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 9 | 3 | 3 | 14 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BAP-01, BAP-02 | F8 Services/Jobs | BAP-11 |
| F2 Transactions/Audit | BAP-03, BAP-04 | F9 Queries/Perf | BAP-12 |
| F3 Authorization | BAP-05, BAP-06 | F10 Views | clean |
| F4 Validation | BAP-07 | F11 Security/Tenancy | clean |
| F5 Routes | BAP-08 | F12 Style | BAP-13, BAP-14 |
| F6 Controller shape | BAP-09, BAP-10 | F13 Deep read | see the F13 table |
| F7 Models | clean — tinker-proven | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php` | controller | 427 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Services/BaPeriodService.php` | service | 225 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Models/BaComputedScore.php` | model (`ba_computed_scores`) | 79 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentPeriod.php` | model (`ba_assessment_periods`) | 145 | ↗ [tarun/BehaviouralAssessment-done/BaAuditLogController-done](../BaAuditLogController-done/01-report.md) | ↗ linked |
| 5 | `Modules/BehaviouralAssessment/app/Models/BaAssessment.php` | model (`ba_assessments`) | 183 | ↗ [tarun/BehaviouralAssessment-done/BaAssessmentController-done](../BaAssessmentController-done/01-report.md) | ↗ linked |
| 6 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | 45 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 7 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support | 37 | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |
| 8 | `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentPeriodRequest.php` | FormRequest (used only here — not registered) | 62 | this report | ✅ |
| 9 | `Modules/BehaviouralAssessment/app/Http/Requests/BaPeriodReopenRequest.php` | FormRequest (used only here — not registered) | 33 | this report | ✅ |
| 10 | `Modules/BehaviouralAssessment/app/Http/Requests/LocksAcademicSession.php` | trait | 32 | ↗ [tarun/BehaviouralAssessment-done/BaClassScaleController-done](../BaClassScaleController-done/01-report.md) | ↗ linked |
| 11 | `Modules/BehaviouralAssessment/routes/web.php` | route file (assessment-periods section, lines 75-84) | 167 | this report | ✅ |
| 12 | `Modules/BehaviouralAssessment/resources/views/assessment-period/create.blade.php` | view | 159 | this report | ✅ |
| 13 | `Modules/BehaviouralAssessment/resources/views/assessment-period/edit.blade.php` | view | 166 | this report | ✅ |
| 14 | `Modules/BehaviouralAssessment/resources/views/assessment-period/show.blade.php` | view | 167 | this report | ✅ |
| 15 | `Modules/BehaviouralAssessment/resources/views/assessment-period/trash.blade.php` | view | 83 | this report | ✅ |
| 16 | `Modules/BehaviouralAssessment/resources/views/assessment-period/_create-fields.blade.php` | view | 83 | this report | ✅ |

No pre-applied files. `_periods.blade.php` (the tab body with the close/reopen/lock/recompute buttons) is rendered by `BaDashboardController::setup()`, not by this controller, so it is a cross-cutting note in §7, not an in-scope view.

## 4. Routes

```
GET|HEAD behavioural-assessment/assessment-periods               behavioural-assessment.assessment-periods.index         BaAssessmentPeriodController@index
POST     behavioural-assessment/assessment-periods               behavioural-assessment.assessment-periods.store         BaAssessmentPeriodController@store
GET|HEAD behavioural-assessment/assessment-periods/create        behavioural-assessment.assessment-periods.create        BaAssessmentPeriodController@create
GET|HEAD behavioural-assessment/assessment-periods/trash         behavioural-assessment.assessment-periods.trashed       BaAssessmentPeriodController@trashed
GET|HEAD behavioural-assessment/assessment-periods/{assessment_period} behavioural-assessment.assessment-periods.show          BaAssessmentPeriodController@show
PUT|PATCH behavioural-assessment/assessment-periods/{assessment_period} behavioural-assessment.assessment-periods.update        BaAssessmentPeriodController@update
DELETE   behavioural-assessment/assessment-periods/{assessment_period} behavioural-assessment.assessment-periods.destroy       BaAssessmentPeriodController@destroy
GET|HEAD behavioural-assessment/assessment-periods/{assessment_period}/edit behavioural-assessment.assessment-periods.edit          BaAssessmentPeriodController@edit
DELETE   behavioural-assessment/assessment-periods/{id}/force-delete behavioural-assessment.assessment-periods.forceDelete   BaAssessmentPeriodController@forceDelete
GET|HEAD behavioural-assessment/assessment-periods/{id}/restore  behavioural-assessment.assessment-periods.restore       BaAssessmentPeriodController@restore
POST     behavioural-assessment/assessment-periods/{period}/close behavioural-assessment.assessment-periods.close         BaAssessmentPeriodController@close
POST     behavioural-assessment/assessment-periods/{period}/lock behavioural-assessment.assessment-periods.lock          BaAssessmentPeriodController@lock
POST     behavioural-assessment/assessment-periods/{period}/recompute behavioural-assessment.assessment-periods.recompute     BaAssessmentPeriodController@recompute
POST     behavioural-assessment/assessment-periods/{period}/reopen behavioural-assessment.assessment-periods.reopen        BaAssessmentPeriodController@reopen
POST     behavioural-assessment/assessment-periods/{period}/toggle-status behavioural-assessment.assessment-periods.toggleStatus  BaAssessmentPeriodController@toggleStatus
```

Unrouted public methods: none (all 16 declared methods are routed; `failure()` is private).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `__construct` | 35 | — | — | — | — | — | clean |
| `index` | 37 | GET `assessment-periods` | `tenant.behavioural-assessment.assessment-periods.viewAny` | none (read) | — | — | clean |
| `create` | 44 | GET `assessment-periods/create` | `tenant.behavioural-assessment.assessment-periods.create` | none (read) | — | — | BAP-10 |
| `store` | 53 | POST `assessment-periods` | `tenant.behavioural-assessment.assessment-periods.create` + FormRequest | controller `DB::transaction` (58) | `'Stored'` (inside tx) | `ba_assessment_periods`, `sys_activity_logs` | BAP-01, BAP-02, BAP-04, BAP-05, BAP-10 |
| `show` | 83 | GET `assessment-periods/{assessment_period}` | `tenant.behavioural-assessment.assessment-periods.view` | none (read) | — | — | BAP-09 |
| `edit` | 107 | GET `assessment-periods/{assessment_period}/edit` | `tenant.behavioural-assessment.assessment-periods.update` | none (read) | — | — | BAP-09, BAP-10 |
| `update` | 123 | PUT `assessment-periods/{assessment_period}` | `tenant.behavioural-assessment.assessment-periods.update` + FormRequest | controller `DB::transaction` (128) | `'Updated'` (inside tx) | `ba_assessment_periods`, `sys_activity_logs` | BAP-01, BAP-02, BAP-04, BAP-05, BAP-09 |
| `destroy` | 155 | DELETE `assessment-periods/{assessment_period}` | `tenant.behavioural-assessment.assessment-periods.delete` | controller `DB::transaction` (160) | `'Trashed'` (inside tx) | `ba_assessment_periods`, `sys_activity_logs` | BAP-01, BAP-02, BAP-04, BAP-09 |
| `trashed` | 190 | GET `assessment-periods/trash` | `tenant.behavioural-assessment.assessment-periods.restore` | none (read) | — | — | clean |
| `restore` | 201 | GET `assessment-periods/{id}/restore` | `tenant.behavioural-assessment.assessment-periods.restore` | controller `DB::transaction` (206) | `'Restored'` (inside tx) | `ba_assessment_periods`, `sys_activity_logs` | BAP-01, BAP-02, BAP-04, BAP-07, BAP-08, BAP-09 |
| `forceDelete` | 228 | DELETE `assessment-periods/{id}/force-delete` | `tenant.behavioural-assessment.assessment-periods.forceDelete` | controller `DB::transaction` (233) | `'Deleted'` (inside tx) | `ba_assessment_periods`, `sys_activity_logs` | BAP-01, BAP-02, BAP-04, BAP-09 |
| `toggleStatus` | 260 | POST `assessment-periods/{period}/toggle-status` | `tenant.behavioural-assessment.assessment-periods.update` | controller `DB::transaction` (265) | `'Toggled'` (inside tx) | `ba_assessment_periods`, `sys_activity_logs` | BAP-01, BAP-02, BAP-04 |
| `close` | 296 | POST `assessment-periods/{period}/close` | `tenant.behavioural-assessment.assessment-periods.close` | service `BaPeriodService::close` (42) | `'Closed'` (after service tx) | `ba_assessment_periods`, `ba_audit_log` (service), `sys_activity_logs` | BAP-01, BAP-03 |
| `reopen` | 316 | POST `assessment-periods/{period}/reopen` | `tenant.behavioural-assessment.assessment-periods.reopen` + FormRequest | service `BaPeriodService::reopen` (70) | `'Reopened'` (after service tx) | `ba_assessment_periods`, `ba_audit_log` (service), `sys_activity_logs` | BAP-01, BAP-03, BAP-05 |
| `lock` | 343 | POST `assessment-periods/{period}/lock` | `tenant.behavioural-assessment.assessment-periods.lock` | service `BaPeriodService::lock` (122) | `'Locked'` (after service tx) | `ba_assessment_periods`, `ba_assessments`, `ba_framework_snapshots`, `ba_audit_log` (service), `sys_activity_logs` | BAP-01, BAP-03, BAP-12 |
| `recompute` | 382 | POST `assessment-periods/{period}/recompute` | `tenant.behavioural-assessment.assessment-periods.recompute` | service dispatch (`BaPeriodService::recompute`) | `'Recompute'` (after service) | `sys_activity_logs`, `ba_score_runs` (via job) | BAP-01, BAP-11 |
| `failure` (private) | 408 | — | — | — | — | — | BAP-01, BAP-02 |

## 6. Findings

### F1 — Errors

#### BAP-01 · M · ERR-00 — every write path wraps the transaction or service call in `try/catch`, a shape D2 does not sanction

| Field | Value |
|---|---|
| **Rule** | ERR-00 (D1, no default severity) — under the settled Laravel idiom D1 there is **no** try/catch in controllers; D2 lists the only allowed catches (`\DomainException` for business-rule messages; one truncate-then-rebuild catch; `SnapshotProtectionException` verbatim; service `report($e)` + fixed message). Mapping a MySQL `SQLSTATE 45000` trigger rejection is **not** among them. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php:57-80` (`store`); also `:127-152` (`update`), `:159-187` (`destroy`), `:205-225` (`restore`), `:232-257` (`forceDelete`), `:264-293` (`toggleStatus`), `:300-304` (`close`), `:321-325` (`reopen`), `:347-351` (`lock`), `:388-392` (`recompute`), funnelled through `failure()` at `:408-426` |
| **Root cause** | The controller catches `Throwable` on every write so a `\DomainException` (business rule) or a `QueryException` carrying a `BA: ` trigger message becomes a readable flash. Six methods inline the catch (`store`/`update`/`destroy`/`restore`/`forceDelete`/`toggleStatus`); four funnel through `failure()` (`close`/`reopen`/`lock`/`recompute`). Both shapes are a controller try/catch outside the D2 list: the generic branch converts any other failure (deadlock, duplicate key, DB down) into a fixed flash plus a `Log::error` line instead of letting the central handler in `bootstrap/app.php` render. |
| **Consequence** | No user-visible defect on today's happy paths; a genuine infrastructure failure is hidden behind a generic flash and loses the central 500 page, and every new write method must remember the pattern. |
| **Reproduce** | static only — read the ten `try {` sites; the generic branch needs an infrastructure failure that cannot be forced from the browser. |
| **Fix approach** | **Decision** — (a) keep this as the module's documented ERR-01 exception, comment each catch naming ERR-01 + date and route all six inline catches through `failure()` so there is one funnel; (b) move the trigger mapping into a custom exception rendered by `bootstrap/app.php` and delete all controller catches (the pure D1 shape); (c) leave as is, record as accepted. |
| **Plan item** | BAP-01 in `02-fix-plan.md` §3 (DECISION) |

```php
        try {
            return DB::transaction(function () use ($request) {
                $record = BaAssessmentPeriod::create($request->validated() + [
                    'status' => BaAssessmentPeriod::STATUS_OPEN,
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Stored', ['message' => 'BaAssessmentPeriod was stored.']);

                return redirect()
                    ->route('behavioural-assessment.setup', ['tab' => 'periods'])
                    ->with('success', 'Assessment period created successfully.');

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('BaAssessmentPeriodController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "try {\|} catch (" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php
57:        try {
72:        } catch (ModelNotFoundException $e) {
76:        } catch (\Throwable $e) {
127:        try {
144:        } catch (ModelNotFoundException $e) {
148:        } catch (\Throwable $e) {
159:        try {
179:        } catch (ModelNotFoundException $e) {
183:        } catch (\Throwable $e) {
205:        try {
217:        } catch (ModelNotFoundException $e) {
221:        } catch (\Throwable $e) {
232:        try {
249:        } catch (ModelNotFoundException $e) {
253:        } catch (\Throwable $e) {
264:        try {
280:        } catch (ModelNotFoundException $e) {
284:        } catch (\Throwable $e) {
300:        try {
302:        } catch (Throwable $e) {
321:        try {
323:        } catch (Throwable $e) {
347:        try {
349:        } catch (Throwable $e) {
388:        try {
390:        } catch (Throwable $e) {
```

#### BAP-02 · M · ERR-05 — the logger records only the exception message, never the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php:77` (`store`), `:149` (`update`), `:184` (`destroy`), `:222` (`restore`), `:254` (`forceDelete`), `:285` (`toggleStatus`), `:421` (`failure`) |
| **Root cause** | All seven log sites pass `'error' => $e->getMessage()` into `Log::error(...)` — a flat string with no stack trace, no file/line and no exception chain. A failure diagnosed from the log alone cannot be located. |
| **Consequence** | When a write fails, the operator sees only a message fragment, so the offending exception (class, trace, SQL) is not recoverable from the logs. |
| **Reproduce** | static only — the log lines run only on a failed write, which needs a forced DB failure. |
| **Fix approach** | Add `'exception' => $e` to each log context, keeping the existing scalar context. |
| **Plan item** | BAP-02 in `02-fix-plan.md` §3 |

```php
        } catch (\Throwable $e) {
            Log::error('BaAssessmentPeriodController::store failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php
77:            Log::error('BaAssessmentPeriodController::store failed', ['error' => $e->getMessage()]);
149:            Log::error('BaAssessmentPeriodController::update failed', ['error' => $e->getMessage()]);
184:            Log::error('BaAssessmentPeriodController::destroy failed', ['error' => $e->getMessage()]);
222:            Log::error('BaAssessmentPeriodController::restore failed', ['error' => $e->getMessage()]);
254:            Log::error('BaAssessmentPeriodController::forceDelete failed', ['error' => $e->getMessage()]);
285:            Log::error('BaAssessmentPeriodController::toggleStatus failed', ['error' => $e->getMessage()]);
421:            Log::error("BaAssessmentPeriodController::{$action} failed", ['error' => $e->getMessage()]);
```

Clean sub-checks in this family: no `$e->getMessage()` reaches the user (ERR-01 clean — only `\DomainException` messages and the documented `BaTriggerError` trigger text are flashed); every write catch re-throws `ModelNotFoundException`, so a missing record stays a 404 (ERR-02 clean); every catch block returns the method's declared return type — `RedirectResponse` from `failure()`, `JsonResponse` from `toggleStatus` (ERR-03 clean); `toggleStatus` answers JSON and the form methods redirect (ERR-04 clean); no empty catch and no write path continues after a caught failure (ERR-06 checked, not present); the read methods (`index`/`create`/`show`/`edit`/`trashed`) carry no try/catch (ERR-07 clean). Proof: `grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php` shows only the seven log sites above.

### F2 — Transactions and audit

#### BAP-03 · M · TXN-04 — `activityLog()` runs after the service transaction commits, in three methods

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes — not after commit* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php:306` (`close`), `:327` (`reopen`), `:365` (`lock`) — the write is committed by `BaPeriodService::close`/`reopen`/`lock` (each its own `DB::transaction`), then the controller calls `activityLog()` in a separate statement |
| **Root cause** | The service owns the transaction that writes `ba_assessment_periods` and `ba_audit_log` and returns the model; the controller then writes `sys_activity_logs` outside it. If that log insert fails, the business write is already committed and the request returns a 500 even though the change landed; if the service write fails, no controller log is written. |
| **Consequence** | The activity trail can silently miss a close/reopen/lock, and a log-insert failure is reported to the user as a failed operation even though the period moved. |
| **Reproduce** | static only — the log call is outside every service closure; see the `grep` output below. |
| **Fix approach** | Wrap each service call together with its `activityLog()` in the controller's own `DB::transaction` (nested as a savepoint with the service's), then build the redirect after the wrapper. |
| **Plan item** | BAP-03 in `02-fix-plan.md` §3 |

```php
        try {
            $item = $this->service->close($period);
        } catch (Throwable $e) {
            return $this->failure($e, 'close');
        }

        activityLog($item, 'Closed', [
            'message' => 'Assessment period was closed.',
            'status' => $item->status,
        ]);
```

**Evidence**
```
$ grep -n "activityLog" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php
65:                activityLog($record, 'Stored', ['message' => 'BaAssessmentPeriod was stored.']);
137:                activityLog($period, 'Updated', ['message' => 'BaAssessmentPeriod was updated.']);
172:                activityLog($period, 'Trashed', ['message' => 'BaAssessmentPeriod was trashed.']);
210:                activityLog($period, 'Restored', ['message' => 'BaAssessmentPeriod was restored.']);
242:                activityLog($period, 'Deleted', ['message' => 'BaAssessmentPeriod was deleted.']);
271:                activityLog($item, 'Toggled', ['message' => 'BaAssessmentPeriod was toggled.']);
306:        activityLog($item, 'Closed', [
327:        activityLog($item, 'Reopened', [
365:        activityLog($result['period'], 'Locked', [
394:        activityLog($model, 'Recompute', [
```

Clean sub-checks in this family: `store`/`update`/`destroy`/`restore`/`forceDelete`/`toggleStatus` log **inside** their own transaction (lines 65/137/172/210/242/271 — TXN-04 clean for those six); every multi-table write runs inside ONE `DB::transaction` closure (TXN-01 clean — the controller for the six, the service for `close`/`reopen`/`lock`, counted across both per `controller-alignment.md` §6); the closure form is used everywhere, never manual `beginTransaction` (TXN-02 clean); no irreversible side effect sits inside a transaction — `PeriodLocked` is dispatched inside `lock()`'s transaction but implements `ShouldDispatchAfterCommit`, and `recompute()` dispatches outside any transaction (TXN-03 clean); check-then-act is backstopped by the DB unique index `uq_ba_period_name` and by `lockForUpdate()` on the period and reviewed assessments (TXN-06 clean). `recompute`'s single `activityLog` write is not multi-table, so it needs no transaction (clean).

#### BAP-04 · M · TXN-05 — six methods build HTTP responses inside the `DB::transaction` closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()`/`response()` after it* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php:58-71` (`store`), `:128-143` (`update`), `:160-178` (`destroy`), `:206-216` (`restore`), `:233-248` (`forceDelete`), `:265-279` (`toggleStatus`) |
| **Root cause** | Every `DB::transaction` closure ends with `return redirect()->...->with(...)` (or a `response()->json([...])` in `toggleStatus`), so a `RedirectResponse`/`JsonResponse` is built while the transaction is still open. The guard refusals (`update` locked, `destroy`/`forceDelete` has-assessments) also `return back()->with(...)` inside the closure, committing an empty transaction. |
| **Consequence** | No user-visible defect — it couples response construction to the open transaction and is the documented anti-shape for TXN-05. |
| **Reproduce** | static only — response object literals inside the closures. |
| **Fix approach** | Return the model (or throw a `\DomainException` for the guards, which D2 sanctions) from the closure and build the redirect/JSON after it. |
| **Plan item** | BAP-04 in `02-fix-plan.md` §3 |

```php
            return DB::transaction(function () use ($request) {
                $record = BaAssessmentPeriod::create($request->validated() + [
                    'status' => BaAssessmentPeriod::STATUS_OPEN,
                    'created_by' => BaActor::id(),
                    'updated_by' => BaActor::id(),
                ]);

                activityLog($record, 'Stored', ['message' => 'BaAssessmentPeriod was stored.']);

                return redirect()
                    ->route('behavioural-assessment.setup', ['tab' => 'periods'])
                    ->with('success', 'Assessment period created successfully.');

            });
```

**Evidence**
```
$ grep -n "return redirect\|return back\|return response()->json" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php
41:        return redirect()->route('behavioural-assessment.setup', ['tab' => 'periods']);
67:                return redirect()
79:            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
113:            return redirect()->route('behavioural-assessment.setup', ['tab' => 'periods'])
132:                    return back()->withInput()->with('error', 'A locked period is final and cannot be edited.');
139:                return redirect()
151:            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
164:                    return back()->with('error', 'Cannot delete this assessment period because it has active assessments or computed scores.');
174:                return redirect()
186:            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
212:                return redirect()
224:            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
237:                    return back()->with('error', 'Cannot permanently delete this assessment period because it has associated assessments or computed scores (active or trashed).');
244:                return redirect()
256:            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
273:                return response()->json([
289:            return response()->json([
311:        return redirect()
```

### F3 — Authorization

#### BAP-05 · L · AUTH-04 — the same permission is authorized twice on three write methods

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php:55` (`store`), `:125` (`update`), `:318` (`reopen`); the FormRequests already check the same abilities at `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentPeriodRequest.php:21` and `Modules/BehaviouralAssessment/app/Http/Requests/BaPeriodReopenRequest.php:17` |
| **Root cause** | `BaAssessmentPeriodRequest::authorize()` calls `authorizeByCrudPermission('tenant.behavioural-assessment.assessment-periods')` (POST → `.create`, PUT/PATCH → `.update`) and `BaPeriodReopenRequest::authorize()` calls `authorizePermission('…reopen')`; those run first. The controller then calls `Gate::authorize` for the same verbs — two checks, one concern. |
| **Consequence** | No user-visible effect; duplicated logic that can drift (one surface changed, the other forgotten). |
| **Reproduce** | static only — both checks pass or fail together today. |
| **Fix approach** | Keep the FormRequest checks (they run first) and remove the three redundant `Gate::authorize` lines in `store`, `update` and `reopen`. |
| **Plan item** | BAP-05 in `02-fix-plan.md` §4 |

```php
        Gate::authorize('tenant.behavioural-assessment.assessment-periods.create');
```

**Evidence**
```
$ grep -n "authorizeByCrudPermission\|authorizePermission" Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentPeriodRequest.php Modules/BehaviouralAssessment/app/Http/Requests/BaPeriodReopenRequest.php
BaAssessmentPeriodRequest.php:21:        return $this->authorizeByCrudPermission('tenant.behavioural-assessment.assessment-periods');
BaPeriodReopenRequest.php:17:        return $this->authorizePermission('tenant.behavioural-assessment.assessment-periods.reopen');
$ grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php
46:        Gate::authorize('tenant.behavioural-assessment.assessment-periods.create');
55:        Gate::authorize('tenant.behavioural-assessment.assessment-periods.create');
109:        Gate::authorize('tenant.behavioural-assessment.assessment-periods.update');
125:        Gate::authorize('tenant.behavioural-assessment.assessment-periods.update');
262:        Gate::authorize('tenant.behavioural-assessment.assessment-periods.update');
318:        Gate::authorize('tenant.behavioural-assessment.assessment-periods.reopen');
```

#### BAP-06 · M · AUTH-06 — permission strings are repeated as literals across the controller, requests and blades

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy, or constants — not repeated as literals in every method* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php:39` and 14 more controller lines; plus `BaAssessmentPeriodRequest.php:21`, `BaPeriodReopenRequest.php:17`, `assessment-period/show.blade.php:156`, `assessment-period/trash.blade.php:25` |
| **Root cause** | Nothing binds the base string `tenant.behavioural-assessment.assessment-periods`; it is written out verbatim 15 times in the controller and again in both requests and blades. |
| **Consequence** | A permission rename is a search-and-replace across many files, and one missed surface silently un-guards (or over-blocks) an action. |
| **Reproduce** | static only — count the literals. |
| **Fix approach** | Not a per-controller fix — a Policy or a constants class (module-wide pass), tracked by the module summary like `BaAssessmentController`'s BASS-06. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
        Gate::authorize('tenant.behavioural-assessment.assessment-periods.viewAny');
```

**Evidence**
```
$ grep -c "tenant.behavioural-assessment.assessment-periods" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php
15
```

Clean sub-checks in this family: every routed method authorizes before it loads a record — `store`/`update` by the FormRequest, the rest by `Gate::authorize` at the top (AUTH-01, AUTH-02 clean); the five declared actions `lock`, `close`, `reopen`, `recompute` and the CRUD verbs all exist in `config/permissionslist.php` (`'behavioural-assessment.assessment-periods' => array_merge($crud, ['lock', 'close', 'reopen', 'recompute'])`, line 1414) and are seeded on the tenant (all 11 names measured) — not a dead key (AUTH-01 clean); no `Gate::any(...)` without `|| abort(403)` and no string passed to `Gate::authorize` that should reach a Policy (AUTH-05 clean); no permission authorized twice in the blades beyond the same pattern noted in BAP-06.

### F4 — Validation and input

#### BAP-07 · H · VAL-04 — restoring a trashed period whose name was re-used fails with a generic error flash

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the DB unique index including soft-delete semantics; a soft-delete × unique-index mismatch is a 500 on re-add* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php:207-208` (`restore`); index at `database/migrations/tenant/2026_06_16_130612_create_ba_assessment_periods_table.php:44,46` |
| **Root cause** | `uq_ba_period_name` is `(academic_session_id, name, uq_guard)` where `uq_guard` is the generated column `IFNULL(deleted_at,'1970-01-01 00:00:00.000000')`. A trashed row's `uq_guard` is its `deleted_at`, so the create rule (`->whereNull('deleted_at')`) correctly allows a new live period with the same name. On `restore()`, `deleted_at` becomes NULL, so `uq_guard` recomputes to `'1970-01-01'` and collides with the live same-name row → a `QueryException`, caught by the generic `catch (\Throwable)` and replaced by "The operation could not be completed." Unlike `BaAssessmentController::restore`, this method has no pre-restore clash check. |
| **Consequence** | A user who trashes "Term 1", creates a new "Term 1", then clicks Restore on the old one gets a red "The operation could not be completed." flash and the period is **not** restored; there is no hint that the name is the problem. |
| **Reproduce** | Trash a period named "Term 1" (Setup → Periods → row → delete), create a new period named "Term 1" (allowed), open `/behavioural-assessment/assessment-periods/trash`, click Restore on the old row → red error flash, nothing restored. |
| **Fix approach** | Before `$period->restore()`, check for a live row with the same `(academic_session_id, name)` and flash a readable message. |
| **Plan item** | BAP-07 in `02-fix-plan.md` §1 |

```php
        try {
            return DB::transaction(function () use ($id) {
                $period = BaAssessmentPeriod::onlyTrashed()->findOrFail($id);
                $period->restore();

                activityLog($period, 'Restored', ['message' => 'BaAssessmentPeriod was restored.']);
```

**Evidence**
```
$ sed -n '44,46p' database/migrations/tenant/2026_06_16_130612_create_ba_assessment_periods_table.php
            $table->dateTime('uq_guard', 6)->storedAs("IFNULL(`deleted_at`,'1970-01-01 00:00:00.000000')");

            $table->unique(['academic_session_id', 'name', 'uq_guard'], 'uq_ba_period_name');
$ grep -n "onlyTrashed()->findOrFail\|restore()" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php
207:                $period = BaAssessmentPeriod::onlyTrashed()->findOrFail($id);
208:                $period->restore();
```

Cross-field validation (`deadline >= end_date`, `end_date >= start_date`, the `name` unique rule) is statically correct and mirrors the index. ⚠ UNVERIFIED — executing the FormRequest's cross-field rule needs a real POST/PUT through the route with an invalid deadline (D4 forbids tests); what would settle it is a browser submit of a deadline earlier than the end date and observing a 422.

### F5 — Routes

#### BAP-08 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …): GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/BehaviouralAssessment/routes/web.php:76` |
| **Root cause** | The state-changing `restore` action is registered as a GET route. A GET carries no CSRF token and can be fired by a browser prefetch, a cached link or a crawler. |
| **Consequence** | A period can be un-trashed with no CSRF token and no deliberate click. |
| **Reproduce** | Open `/behavioural-assessment/assessment-periods/{id}/restore` directly in a browser tab; the period is restored. |
| **Fix approach** | Change the route to POST. The shared `resources/views/components/backend/table/action-trashed.blade.php` reads the route verb (`parameterNames()` / `methods()`) and already emits a POST form with `@csrf`, so no component or view change is needed. |
| **Plan item** | BAP-08 in `02-fix-plan.md` §1 (⚠ SHARED — route file) |

```php
Route::get('assessment-periods/{id}/restore', [BaAssessmentPeriodController::class, 'restore'])->name('assessment-periods.restore');
```

**Evidence**
```
$ grep -n "assessment-periods/{id}/restore" Modules/BehaviouralAssessment/routes/web.php
76:Route::get('assessment-periods/{id}/restore', [BaAssessmentPeriodController::class, 'restore'])->name('assessment-periods.restore');
$ grep -n "restoreMethods\|restoreMethod === 'GET'" resources/views/components/backend/table/action-trashed.blade.php
19:    $restoreMethods = collect($restoreRoute?->methods() ?? ['GET'])->reject(fn ($method) => $method === 'HEAD')->values();
20:    $restoreMethod = strtoupper($restoreMethods->first() ?? 'GET');
30:          method="{{ $restoreMethod === 'GET' ? 'GET' : 'POST' }}"
```

Clean sub-checks in this family: every custom route points at a method that exists (RTE-02 clean); every public method is routed (RTE-03 clean — see §4); the static routes `trash`, `{id}/restore`, `{id}/force-delete`, `{period}/toggle-status|close|reopen|lock|recompute` are all registered **before** `Route::resource` (RTE-06 clean — `web.php:75-84`); every route sits inside the `web + InitializeTenancyByDomain + PreventAccessFromCentralDomains + EnsureTenantIsActive + EnsureTenantHasModule + auth + verified` group (RTE-05 clean — proven from the uncached route middleware list). The resource routes bind `{assessment_period}` while the methods take `$id` (parameter-name mismatch) — see BAP-09.

### F6 — Controller shape

#### BAP-09 · M · CTL-03 — no route-model binding; the methods load by `$id` with `findOrFail`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php:95` (`show`), `:110` (`edit`), `:129` (`update`), `:161` (`destroy`), `:207` (`restore`), `:234` (`forceDelete`), `:266` (`toggleStatus`), `:386` (`recompute`) |
| **Root cause** | `Route::resource('assessment-periods', …)` binds `{assessment_period}`, but every method declares `int $id` (or `int $period`), so Laravel never performs implicit model binding and each method calls `findOrFail()` itself. The name mismatch (`assessment_period` vs `$id`) means the route value is matched **positionally**, which is fragile. |
| **Consequence** | No functional defect today; a route-parameter rename would silently break the controller, and every method repeats the same load. |
| **Reproduce** | static only — compare the route parameter names with the method parameters. |
| **Fix approach** | **Decision** — bind `BaAssessmentPeriod $assessmentPeriod` (and `->withTrashed()` on `restore`/`forceDelete`). This is a behaviour-preserving refactor of eight methods (D3 defers splits, but binding is confined to this controller). |
| **Plan item** | BAP-09 in `02-fix-plan.md` §9 (DECISION) |

```php
        $period = BaAssessmentPeriod::with(['academicSession', 'academicTerm', 'closedBy', 'lockedBy', 'snapshot'])->findOrFail($id);
```

**Evidence**
```
$ grep -n "findOrFail" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php
95:        $period = BaAssessmentPeriod::with(['academicSession', 'academicTerm', 'closedBy', 'lockedBy', 'snapshot'])->findOrFail($id);
110:        $period = BaAssessmentPeriod::findOrFail($id);
129:                $period = BaAssessmentPeriod::findOrFail($id);
161:                $period = BaAssessmentPeriod::findOrFail($id);
207:                $period = BaAssessmentPeriod::onlyTrashed()->findOrFail($id);
234:                $period = BaAssessmentPeriod::withTrashed()->findOrFail($id);
266:                $item = BaAssessmentPeriod::findOrFail($period);
386:        $model = BaAssessmentPeriod::findOrFail($period);
$ python3 -c "import json;r=json.load(open('/tmp/fa-routes.json'));[print(x['method'].split('|')[0], x['uri']) for x in r if 'BaAssessmentPeriodController@show' in x.get('action','') or 'BaAssessmentPeriodController@update' in x.get('action','')]"
GET behavioural-assessment/assessment-periods/{assessment_period}
PUT behavioural-assessment/assessment-periods/{assessment_period}
```

#### BAP-10 · M · CTL-05 — `create` and `edit` repeat the same two dropdown loaders

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: dropdown loaders shared by `create`/`edit`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php:117-118` (`edit`), duplicating `:47-48` (`create`) |
| **Root cause** | Both methods run the identical two queries to seed the academic-session and academic-term selects. `BaDashboardController::setup()` runs the same two queries a third time for the tab. |
| **Consequence** | Maintainability — a change to either loader must be repeated in two (three) places and can drift. |
| **Reproduce** | static only — the two lines are byte-identical in both methods. |
| **Fix approach** | Extract a private `formOptions()` returning the two collections and use it from `create` and `edit`. |
| **Plan item** | BAP-10 in `02-fix-plan.md` §5 |

```php
        $academicSessions = OrganizationAcademicSession::where('is_active', true)->orderByDesc('is_current')->get();
        $academicTerms = AcademicTerm::where('is_active', true)->orderBy('term_ordinal')->get();
```

**Evidence**
```
$ grep -n "OrganizationAcademicSession::where\|AcademicTerm::where" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php
47:        $academicSessions = OrganizationAcademicSession::where('is_active', true)->orderByDesc('is_current')->get();
48:        $academicTerms = AcademicTerm::where('is_active', true)->orderBy('term_ordinal')->get();
117:        $academicSessions = OrganizationAcademicSession::where('is_active', true)->orderByDesc('is_current')->get();
118:        $academicTerms = AcademicTerm::where('is_active', true)->orderBy('term_ordinal')->get();
```

Clean sub-checks in this family: size is within thresholds — 427 lines, 16 methods (CTL-01 clean: under 1,000 lines and 25 methods, so no split; D3 DEFERRED n/a); no method exceeds 80 lines (CTL-02 clean — longest is `lock` at 32 lines); every public method has a return type (CTL-04 clean); no `extract()` and no `compact()` over 15 variables (CTL-07 clean — largest is 3); the injected `BaPeriodService $service` is used, and `request()` is never called in a method (CTL-08 clean); no `dd()`/`dump()`/`var_dump()`/`print_r()`/`ray()` leftovers (CTL-09 clean); no dead private methods, properties or commented-out blocks (CTL-10 clean).

### F7 — Models

Clean for the owned model — `BaComputedScore` declares `$table = 'ba_computed_scores'` on a real migration (`2026_06_16_130619_create_ba_computed_scores_table.php`, MDL-07), a `$fillable` list with nothing sensitive and no generated column (`uq_guard` is excluded, MDL-01), `$casts` covering every integer/boolean/decimal (`decimal:3`) / datetime column including `deleted_at` (MDL-02), `SoftDeletes` matching the real `deleted_at` (MDL-03 clean — no `belongsToMany` over a trashed pivot), return-typed relationships (MDL-04), no Spatie `InteractsWithMedia` (MDL-05/TEN-01 clean), and cheap global scopes (MDL-08 clean). Proof (tinker on tenant `00000000-0000-4000-8000-000000000001`, `tenancy()->initialize(...)` first):

```
$ php artisan tinker --execute 'use Modules\Prime\Models\Tenant; tenancy()->initialize(Tenant::find("00000000-0000-4000-8000-000000000001")); $s = Modules\BehaviouralAssessment\Models\BaComputedScore::with(["student","category","period","scoreRun"])->first(); echo "relations=".json_encode(array_keys($s->getRelations()));'
relations=["student","category","period","scoreRun"]
```

`BaAssessmentPeriod` and `BaAssessment` are owned by other reports (§3) and were usage-checked only: the relations this controller uses (`academicSession`, `academicTerm`, `closedBy`, `lockedBy`, `snapshot`, `assessments`, `computedScores`) all resolve — `BaAssessmentPeriod::with([...])->first()` loaded `["academicSession","academicTerm","closedBy","lockedBy","snapshot"]` with no error.

### F8 — Services and jobs

#### BAP-11 · M · SVC-02 — `recompute` pulls `BaPeriodService` with `app()` instead of the injected instance

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection — not `new FooService()` or `app(Foo::class)` mid-method* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php:389` (`recompute`); the constructor at `:35` already injects `BaPeriodService $service` |
| **Root cause** | `recompute` resolves a second `BaPeriodService` from the container even though `$this->service` is the same class, already constructed with its own dependencies. |
| **Consequence** | No visible defect, but a second service instance is constructed per call and the controller is inconsistent with its twelve sibling methods that use `$this->service`. |
| **Reproduce** | static only. |
| **Fix approach** | Call `$this->service->recompute($model)`. |
| **Plan item** | BAP-11 in `02-fix-plan.md` §5 |

```php
        try {
            app(BaPeriodService::class)->recompute($model);
        } catch (Throwable $e) {
            return $this->failure($e, 'recompute');
        }
```

**Evidence**
```
$ grep -n "__construct\|app(BaPeriodService" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php
35:    public function __construct(private readonly BaPeriodService $service) {}
389:            app(BaPeriodService::class)->recompute($model);
```

Clean sub-checks in this family: `BaPeriodService` does not touch HTTP — no `request()`, `session()`, `redirect()`, `response()` or `back()` (SVC-01 clean; the `auth()` read via `BaActor::id()` is not HTTP); dependencies arrive by constructor injection (`BaAssessmentService`, `BaFrameworkSnapshotService`, SVC-02 clean inside the service); no writes on a read path — `lockBlockers()` is read-only, `close`/`reopen`/`lock` are action methods (SVC-03 clean); one implementation per operation (SVC-04 clean); `snapshotFor`/`verify`/`currentEmployeeId` are each resolved once per call (SVC-05 clean). The jobs are tenant-aware via `QueueTenancyBootstrapper` and `ComputeSchoolScoresJob` declares `$tries = 1` and `$timeout = 900` (JOB-01/JOB-02 clean); `PeriodLocked` implements `ShouldDispatchAfterCommit` (TXN-03/clean).

### F9 — Queries and performance

#### BAP-12 · M · QRY-07 — `BaPeriodService::lock()` updates assessments one row at a time in a loop

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *bulk writes: `insert()`, `upsert()`, `whereIn(...)->update()` instead of `create()`/`update()` per row in a loop* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaPeriodService.php:153-162` |
| **Root cause** | The method fetches all reviewed assessments and, inside `->each()`, calls `$assessment->update(['snapshot_id' => …])` and then `$this->assessments->lockReviewed($assessment, $employeeId)` (which itself updates the row and inserts a status-history row) per assessment. A period with many reviewed sheets issues several statements per sheet inside the period row lock. |
| **Consequence** | For a large period the lock transaction holds the row lock while issuing O(number of reviewed sheets) statements, lengthening the window in which concurrent writers block. |
| **Reproduce** | static only; the scanner flagged it (see evidence). |
| **Fix approach** | **Decision** — reduce the per-row statements where possible (e.g. one `whereIn(...)->update(['snapshot_id' => …])` for the already-locked sheets at line 166 is already bulk; the reviewed-sheet loop cannot be fully collapsed because `lockReviewed` appends a status-history row per sheet). |
| **Plan item** | BAP-12 in `02-fix-plan.md` §6 (DECISION) |

```php
            $lockedCount = 0;
            BaAssessment::where('period_id', $period->id)
                ->where('status', BaAssessment::STATUS_REVIEWED)
                ->lockForUpdate()
                ->get()
                ->each(function (BaAssessment $assessment) use ($employeeId, $snapshot, &$lockedCount) {
                    $assessment->update(['snapshot_id' => $snapshot->id]);
                    $this->assessments->lockReviewed($assessment, $employeeId);
                    $lockedCount++;
                });
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-ba-module.json Modules/BehaviouralAssessment/app/Services/BaPeriodService.php
M  QRY-07   Modules/BehaviouralAssessment/app/Services/BaPeriodService.php:159  lock — ->update() per row inside a loop
```

Clean sub-checks in this family: `show` uses `count()` and `distinct('student_id')->count('student_id')`, which compiles to `count(distinct student_id)` — proved by query log (`result=48`, `raw_distinct=48`, SQL `select count(distinct student_id) as aggregate from ba_computed_scores …`) (QRY-04 clean); `trashed` paginates at 10 with `academicSession` eager-loaded (QRY-02/QRY-03 clean); `create`/`edit` load two small master tables with no per-row queries (QRY-01 clean); `lockBlockers` uses a bounded `whereIn` with eager loads, not a loop of queries (QRY-01 clean); no interpolated raw SQL anywhere in the controller or service (QRY-11 clean).

### F10 — Views

Clean — `show`/`edit`/`create`/`trash`/`_create-fields` contain no `Model::`, `DB::`, `->where(`, `->get()` or `->count()` (VIEW-01 clean, proof: `grep -nE "Model::|DB::|->where\(|->get\(|->count\(\)" Modules/BehaviouralAssessment/resources/views/assessment-period/*.blade.php` → no output); every relation printed is eager-loaded by the controller (`show` loads `academicSession`, `academicTerm`, `closedBy`, `lockedBy`, `snapshot`; `trashed` loads `academicSession`) so no N+1 (VIEW-02 clean); no `{!! !!}` on user text (VIEW-03 clean — `grep -n "{!!" …/*.blade.php` → no output); row actions use `x-backend.table.action` and trash rows use `x-backend.table.action-trashed` with `restorePermission`/`forceDeletePermission`, and the discarded `permission` prop was already removed (VIEW clean). `_periods.blade.php` — the tab body — is rendered by `BaDashboardController`, not this controller; see §7.

### F11 — Security and tenancy

Clean — no `env()` in the controller or service (SEC-01 clean); no personal data in any response (the controller returns redirects and a two-field JSON toggle, SEC-02 clean); no hard-coded ids or `?? 1` user/status fallbacks (SEC-03 clean; the `BaActor` fallback to the lowest `sys_users` id is documented and owned elsewhere); no request body or secret is logged (SEC-04 clean — only `getMessage()`); no private-file serving here (SEC-05 n/a). Tenant context is established by the route middleware (`InitializeTenancyByDomain`) and the recompute/listen jobs carry the tenant id via `QueueTenancyBootstrapper` (TEN-01..TEN-04 clean; no Spatie media, no cache keys, no `asset('storage/…')`).

### F12 — Style

#### BAP-13 · L · STY-02 — the controller is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no redundant fully-qualified names* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php:76,148,183,221,253,284` (and the trailing fixers listed below) |
| **Root cause** | `Throwable` is imported at line 27, but six catch clauses use the fully-qualified `\Throwable`; Pint also reports `unary_operator_spaces`, `braces_position`, `not_operator_with_successor_space` and `single_line_empty_body` fixers. |
| **Consequence** | Cosmetic — the file drifts from the project's enforced style. |
| **Reproduce** | `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php`. |
| **Fix approach** | Run `vendor/bin/pint` on the controller (the fixer's §10 already does this). |
| **Plan item** | BAP-13 in `02-fix-plan.md` §8 |

```php
        } catch (\Throwable $e) {
```

**Evidence**
```
$ vendor/bin/pint --test --format agent Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentPeriodController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Http\/Controllers\/BaAssessmentPeriodController.php","fixers":["fully_qualified_strict_types","unary_operator_spaces","braces_position","not_operator_with_successor_space","single_line_empty_body"]}]}
```

#### BAP-14 · L · STY-02 — `BaAssessmentPeriodRequest` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean; one import per class; sorted imports* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentPeriodRequest.php:55` (and the aligned `=>` block at `:27-41`) |
| **Root cause** | `prepareForValidation()` writes the fully-qualified `\Modules\BehaviouralAssessment\Models\BaAssessmentPeriod::class` instead of importing the class, and the rules array aligns its `=>` operators (Pint's `binary_operator_spaces`). Pint's `fully_qualified_strict_types` fixer adds the `use` import and shortens the name. |
| **Consequence** | Cosmetic — the request drifts from the enforced style. |
| **Reproduce** | `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentPeriodRequest.php`. |
| **Fix approach** | Run `vendor/bin/pint` on the request. |
| **Plan item** | BAP-14 in `02-fix-plan.md` §8 |

```php
        $this->lockAcademicSession(\Modules\BehaviouralAssessment\Models\BaAssessmentPeriod::class, $this->route('assessment_period') ?? $this->route('id'));
```

**Evidence**
```
$ vendor/bin/pint --test --format agent Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentPeriodRequest.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Http\/Requests\/BaAssessmentPeriodRequest.php","fixers":["fully_qualified_strict_types","binary_operator_spaces"]}]}
```

`BaPeriodService`, `BaComputedScore` and `BaPeriodReopenRequest` are already Pint-clean (`vendor/bin/pint --test --format agent` → `{"result":"passed"}`). `declare(strict_types=1)` is present in every in-scope PHP file (STY-01 clean); comments are English, no emoji, no commented-out code, no copy-pasted docblocks (STY-04 clean); no aliased duplicate imports (STY-05 clean).

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1. Wrong data | 2. Irreversible order | 3. Duplicate impl | 4. Soft-delete × unique | 5. Race | 6. Authz hole | 7. Message lies | 8. Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok | ok | BAP-05 | ok | ok |
| `update` | ok | ok | ok | ok | ok | BAP-05 | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | BAP-07 | ok | ok | BAP-07 | ok |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |
| `close` | ok | ok | ok | ok | ok | ok | ok | ok |
| `reopen` | ok | ok | ok | ok | ok | BAP-05 | ok | ok |
| `lock` | ok | ok | BAP-12 | ok | ok | ok | ok | ok |
| `recompute` | ok | ok | ok | ok | ok | ok | ok | ok |

Notes: (1) no write overwrites data it should not — `update` uses `$request->validated() + ['updated_by' => …]` and every key is fillable (status/created_by are not reset); `destroy` sets `is_active = false` before soft-deleting (intentional). (2) nothing is deleted before its replacement is stored. (3) `lock()`'s reviewed-sheet loop is the only duplicate-implementation concern (BAP-12); the FSM itself has one implementation (`BaPeriodService`). (4) the restore path is the soft-delete × unique-index trap (BAP-07). (5) `lock()` takes `lockForUpdate()` on the period and reviewed sheets; `store` is guarded by the DB unique index (no race). (6) the only authorization duplication is BAP-05. (7) `restore`'s failure message does not explain the name clash (BAP-07). (8) no dead feature — every screen action maps to a route and every route to a method.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `resources/views/pages/partials/setup/_periods.blade.php` (rendered by `BaDashboardController::setup`) | This is the real UI for the resource (close/reopen/lock/recompute buttons, trash link) but is owned by `BaDashboardController`, which has no audit report yet. It calls this controller's routes and repeats the permission literals; not audited here. | AUTH-06 | `BaDashboardController` report / module summary |
| `Modules/BehaviouralAssessment/app/Services/BaAssessmentService::recordTransition()` | Reached from `BaPeriodService::lock()` → `lockReviewed()` → `recordTransition()`; it reads the HTTP `request()` (client IP) inside a service. Owned by `BaAssessmentController` (BASS-10). | SVC-01 | `BaAssessmentController` report |
| `Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php` | Reached indirectly via `BaPeriodService` (`capture`, `snapshotFor`, `verify`); not in this report's owned list and not registered anywhere, so it is unaudited. | — | module summary / main session |
| `Modules/BehaviouralAssessment/app/Jobs/ComputeSchoolScoresJob.php` | Dispatched (sync or queued) by `BaPeriodService::recompute()`; declares `$tries`/`$timeout` and is tenant-aware. Usage-checked only. | JOB-01 | `BaAssessmentController` report |

## 8. Not covered, and why

- `_periods.blade.php` and `BaDashboardController::setup()` — not rendered by this controller; see §7.
- `BaFrameworkSnapshotService` — reached indirectly through `BaPeriodService`; not in the owned list from the brief and not registered in `_Info/00-CLASS-OWNERS.md`.
- Cross-field FormRequest rule execution (BAP-07's F4 note) — ⚠ UNVERIFIED; D4 forbids tests, and exercising the rule needs a real POST/PUT.
- Browser rendering of the views and the JS confirm dialogs — not exercised (read-only audit).
- The `lock`/`recompute` job outcomes (`ba_score_runs` rows) — the jobs are not run by this workflow.
