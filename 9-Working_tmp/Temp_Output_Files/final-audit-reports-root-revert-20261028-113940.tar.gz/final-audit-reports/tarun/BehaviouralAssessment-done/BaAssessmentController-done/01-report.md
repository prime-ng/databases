# Final Audit — BehaviouralAssessment / BaAssessmentController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php` (622 lines, 20 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /behavioural-assessment/assessments` (redirects to the tab page), `GET /behavioural-assessment/assessments/create`, `GET /behavioural-assessment/assessments/{assessment}` (the rating sheet), `GET /behavioural-assessment/assessments/{assessment}/edit`, `GET /behavioural-assessment/assessments/trash`, `GET /behavioural-assessment/reviews`, `GET /behavioural-assessment/reviews/{assessment}`, plus the writes `POST /assessments`, `PUT /assessments/{assessment}`, `DELETE /assessments/{assessment}`, `GET /assessments/{id}/restore`, `DELETE /assessments/{id}/force-delete`, `POST /assessments/{assessment}/auto-save`, `POST /assessments/{assessment}/bulk-rate`, `POST /assessments/{assessment}/submit`, `POST /reviews/{assessment}/approve`, `POST /reviews/{assessment}/send-back`, `GET /assessments/{assessment}/details`, `GET /assessments/remarks/{remark}/details` |
| Menu path | Behavioural Assessment → Assessments page ("My Assessments" / "Trash" tabs, rendered by `BaDashboardController::assessmentsPage()`) and → Reviews page (queue rendered by `reviews.index`) |
| Who uses it | Only `School Admin` and `Super Admin` hold `tenant.behavioural-assessment.assessments.*` and `tenant.behavioural-assessment.reviews.*` on tenant `00000000-0000-4000-8000-000000000001` (measured: 14 assessment permissions + 7 review permissions, each granted to exactly those two roles — teachers hold none on this tenant) |
| What a user does here | A school admin starts an assessment sheet for one teacher × class-section × period, opens the rating grid (students × criteria, one rating level per cell plus optional remarks), edits the sheet header, submits it for review, and a reviewer approves it or sends it back with a remark. Drafts can be trashed and restored; reviewed sheets pass through to the score computation job. |
| Tables written | `ba_assessments`, `ba_assessment_ratings`, `ba_student_remarks`, `ba_assessment_status_history` (service), `ba_audit_logs` (service), `ba_comment_bank` (`usage_count`), `ba_rating_scales` (`is_locked`), `sys_activity_logs` (controller helper), `ba_score_runs` (via the job) |
| Tables read | `ba_assessments`, `ba_assessment_ratings`, `ba_student_remarks`, `ba_assessment_status_history`, `ba_assessment_periods`, `ba_comment_bank`, `ba_categories`, `ba_criteria`, `ba_class_category_jnt`, `ba_class_criterion_jnt`, `ba_class_scale_jnt`, `ba_config`, `ba_rating_scales`, `ba_rating_levels`, `sch_class_section_jnt`, `sch_employees`, `sch_subjects`, `std_students`, `std_student_academic_sessions` |
| Live data | On tenant `00000000-0000-4000-8000-000000000001`: `ba_assessments` 17 live, 0 trashed; `ba_student_remarks` 611 live, 0 trashed; status spread `{"locked":1,"draft":4,"submitted":7,"reviewed":5}` |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **close to production-ready — yes, after the plan**: every routed method authorizes before loading, every write path routes through a service that owns the FSM and its transactions, no user-facing exception text leaks (only `DomainException` business messages and the documented BA-trigger text), and the soft-delete × unique-index design on `ba_assessments` and `ba_assessment_ratings` is coherent (verified against the DDL). The single worst finding is **BASS-07**: `restore` runs a write over GET — a link prefetcher or a plain GET in a browser tab can un-trash a sheet with no CSRF token. The next group is the D1 shape decision (BASS-01): all ten write paths wrap the service call in `try/catch (\Throwable)`, which the settled decision forbids except for the D2-listed catches. The remaining items are the audit-log placement (BASS-03), responses built inside transactions (BASS-04), an N+1 on the review queue (BASS-14), service purity items (BASS-10, BASS-11) and mechanical style/performance debt. Rough effort to apply the whole plan: **S–M (about half a day)**, of which the DECISION items (BASS-01, BASS-08, BASS-12, BASS-13) take a per-item tick.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 1 | 12 | 6 | 4 | 19 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BASS-01, BASS-02 | F8 Services/Jobs | BASS-10, BASS-11, BASS-12 |
| F2 Transactions/Audit | BASS-03, BASS-04 | F9 Queries/Perf | BASS-13 |
| F3 Authorization | BASS-05, BASS-06 | F10 Views | BASS-14 |
| F4 Validation | clean — FormRequests everywhere (execution ⚠ UNVERIFIED) | F11 Security/Tenancy | clean |
| F5 Routes | BASS-07 | F12 Style | BASS-15, BASS-16, BASS-17, BASS-18, BASS-19 |
| F6 Controller shape | BASS-08, BASS-09 | F13 Deep read | see the F13 table |
| F7 Models | clean — tinker-proven | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php` | controller | 622 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php` | service | 761 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Services/BaReviewSignalService.php` | service | 599 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Models/BaAssessment.php` | model (`ba_assessments`) | 183 | this report | ✅ |
| 5 | `Modules/BehaviouralAssessment/app/Models/BaStudentRemark.php` | model (`ba_student_remarks`) | 53 | this report | ✅ |
| 6 | `Modules/BehaviouralAssessment/app/Jobs/ComputeStudentScoresJob.php` | job | 51 | this report | ✅ |
| 7 | `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRequest.php` | FormRequest (used only here — not registered) | 57 | this report | ✅ |
| 8 | `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRatingsRequest.php` | FormRequest (used only here — not registered) | 71 | this report | ✅ |
| 9 | `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentSendBackRequest.php` | FormRequest (used only here — not registered) | 34 | this report | ✅ |
| 10 | `Modules/BehaviouralAssessment/routes/web.php` | route file (assessments + reviews section, lines 99–113) | 167 | this report | ✅ |
| 11 | `Modules/BehaviouralAssessment/resources/views/assessment/create.blade.php` | view | 183 | this report | ✅ |
| 12 | `Modules/BehaviouralAssessment/resources/views/assessment/edit.blade.php` | view | 152 | this report | ✅ |
| 13 | `Modules/BehaviouralAssessment/resources/views/assessment/show.blade.php` | view | 649 | this report | ✅ |
| 14 | `Modules/BehaviouralAssessment/resources/views/assessment/trashed.blade.php` | view | 61 | this report | ✅ |
| 15 | `Modules/BehaviouralAssessment/resources/views/assessment/review-index.blade.php` | view | 175 | this report | ✅ |
| 16 | `Modules/BehaviouralAssessment/resources/views/assessment/review-show.blade.php` | view | 300 | this report | ✅ |
| 17 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentPeriod.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaAuditLogController-done](../BaAuditLogController-done/01-report.md) | ↗ linked |
| 18 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentRating.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaClassScaleController-done](../BaClassScaleController-done/01-report.md) | ↗ linked |
| 19 | `Modules/BehaviouralAssessment/app/Models/BaCommentBank.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 20 | `Modules/BehaviouralAssessment/app/Support/BaDispatch.php` | support | — | ↗ [tarun/BehaviouralAssessment-done/BaNotificationController-done](../BaNotificationController-done/01-report.md) | ↗ linked |
| 21 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support | — | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |
| 22 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | — | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 23 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentStatusHistory.php` | model (`ba_assessment_status_history`, written by the service) | — | this report (usage only; not registered — see §8) | ✅ (usage) |

Long-tail classes the service reads/uses, owned by their own reports or common (§4.2), checked for usage only: `BaConfig` (owner BaConfigController), `BaRatingScale`/`BaRatingLevel` (BaRatingScaleController), `BaCategory`/`BaCriterion` (BaCategoryController), `BaClassCategoryJnt`/`BaClassCriterionJnt` (BaClassCategoryController), `BaClassScaleJnt` (BaClassScaleController), `BaAuditLog` (BaAuditLogController), events `AssessmentApproved`/`AssessmentSubmitted` (BaIncidentController/event listeners), plus other-module models `ClassSection`, `Subject`, `Employee`, `Student`, `StudentAcademicSession`.

No pre-applied files: no `Modules/BehaviouralAssessment/**` file appears in a `PRE-APPLIED-*.md`.

## 4. Routes

Uncached `route:list` (APP_ROUTES_CACHE=/tmp/fa-nocache.php), filtered to `BaAssessmentController@`:

```
GET|HEAD  behavioural-assessment/assessments                 behavioural-assessment.assessments.index       ...@index
POST      behavioural-assessment/assessments                 behavioural-assessment.assessments.store       ...@store
GET|HEAD  behavioural-assessment/assessments/create          behavioural-assessment.assessments.create      ...@create
GET|HEAD  behavioural-assessment/assessments/remarks/{remark}/details behavioural-assessment.assessments.remarks.details ...@remarkDetails
GET|HEAD  behavioural-assessment/assessments/trash           behavioural-assessment.assessments.trashed     ...@trashed
GET|HEAD  behavioural-assessment/assessments/{assessment}    behavioural-assessment.assessments.show        ...@show
PUT|PATCH behavioural-assessment/assessments/{assessment}    behavioural-assessment.assessments.update      ...@update
DELETE    behavioural-assessment/assessments/{assessment}    behavioural-assessment.assessments.destroy     ...@destroy
POST      behavioural-assessment/assessments/{assessment}/auto-save behavioural-assessment.assessments.auto-save ...@autoSave
POST      behavioural-assessment/assessments/{assessment}/bulk-rate behavioural-assessment.assessments.bulk-rate ...@bulkRate
GET|HEAD  behavioural-assessment/assessments/{assessment}/details behavioural-assessment.assessments.details ...@details
GET|HEAD  behavioural-assessment/assessments/{assessment}/edit behavioural-assessment.assessments.edit       ...@edit
POST      behavioural-assessment/assessments/{assessment}/submit behavioural-assessment.assessments.submit   ...@submit
DELETE    behavioural-assessment/assessments/{id}/force-delete behavioural-assessment.assessments.forceDelete ...@forceDelete
GET|HEAD  behavioural-assessment/assessments/{id}/restore    behavioural-assessment.assessments.restore     ...@restore
GET|HEAD  behavioural-assessment/reviews                     behavioural-assessment.reviews.index           ...@reviewIndex
GET|HEAD  behavioural-assessment/reviews/{assessment}        behavioural-assessment.reviews.show            ...@reviewShow
POST      behavioural-assessment/reviews/{assessment}/approve behavioural-assessment.reviews.approve         ...@approve
POST      behavioural-assessment/reviews/{assessment}/send-back behavioural-assessment.reviews.send-back     ...@sendBack
```

Unrouted public methods: none — all 20 public methods are exactly the 19 routes above (plus the constructor). Tenant middleware: the module's `RouteServiceProvider::map()` wraps the group in `['web', InitializeTenancyByDomain, PreventAccessFromCentralDomains, EnsureTenantIsActive, EnsureTenantHasModule:BehaviouralAssessment, 'auth', 'verified']` with prefix `behavioural-assessment` (verified `Modules/BehaviouralAssessment/app/Providers/RouteServiceProvider.php:25-36`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `__construct` | 42 | — | — | — | — | — | — |
| `index` | 44 | GET `assessments` | `tenant.behavioural-assessment.assessments.viewAny` | none (reads + redirect) | — | — | clean |
| `create` | 51 | GET `assessments/create` | `tenant.behavioural-assessment.assessments.create` | none (reads) | — | — | BASS-09 |
| `store` | 67 | POST `assessments` | `tenant.behavioural-assessment.assessments.create` + FormRequest | service `DB::transaction` (`create()`); activityLog **after** it | `'Stored'` (after commit) | `ba_assessments`, `ba_assessment_status_history`, `sys_activity_logs` | BASS-01, BASS-02, BASS-03, BASS-05 |
| `show` | 94 | GET `assessments/{assessment}` | `tenant.behavioural-assessment.assessments.view` | none (reads) | — | — | clean |
| `edit` | 118 | GET `assessments/{assessment}/edit` | `tenant.behavioural-assessment.assessments.update` | none (reads) | — | — | BASS-09 |
| `update` | 154 | PUT `assessments/{assessment}` | `tenant.behavioural-assessment.assessments.update` + FormRequest | service `DB::transaction` (`updateHeader()`); activityLog **after** it | `'Updated'` (after commit) | `ba_assessments`, `ba_audit_logs`, `sys_activity_logs` | BASS-01, BASS-02, BASS-03, BASS-05 |
| `trashed` | 174 | GET `assessments/trash` | `tenant.behavioural-assessment.assessments.restore` | none (reads) | — | — | clean |
| `restore` | 185 | GET `assessments/{id}/restore` | `tenant.behavioural-assessment.assessments.restore` | controller `DB::transaction` (190) | `'Restored'` (inside tx) | `ba_assessments`, `sys_activity_logs` | BASS-01, BASS-02, BASS-04, BASS-07 |
| `forceDelete` | 221 | DELETE `assessments/{id}/force-delete` | `tenant.behavioural-assessment.assessments.forceDelete` | controller `DB::transaction` (226) | `'Deleted'` (inside tx) | `ba_assessments` + cascade `ba_assessment_ratings`/`ba_student_remarks`/`ba_assessment_status_history`, `sys_activity_logs` | BASS-01, BASS-02, BASS-04 |
| `details` | 251 | GET `assessments/{assessment}/details` | `tenant.behavioural-assessment.assessments.view` | none (reads) | — | — | clean |
| `remarkDetails` | 283 | GET `assessments/remarks/{remark}/details` | `tenant.behavioural-assessment.assessments.view` | none (reads) | — | — | clean |
| `destroy` | 334 | DELETE `assessments/{assessment}` | `tenant.behavioural-assessment.assessments.delete` | controller `DB::transaction` (339) | `'Trashed'` (inside tx) | `ba_assessments`, `sys_activity_logs` | BASS-01, BASS-02, BASS-04 |
| `bulkRate` | 371 | POST `assessments/{assessment}/bulk-rate` | `tenant.behavioural-assessment.assessments.update` + FormRequest | service `DB::transaction` (`saveRatings()`) | none (BR-BA-055) | `ba_assessment_ratings`, `ba_student_remarks`, `ba_comment_bank`, `ba_rating_scales`, `ba_assessments` | BASS-01, BASS-05, BASS-13 |
| `autoSave` | 397 | POST `assessments/{assessment}/auto-save` | `tenant.behavioural-assessment.assessments.update` + FormRequest | service `DB::transaction` (`saveRatings()`) | none (BR-BA-055) | same as `bulkRate` | BASS-01, BASS-05, BASS-13 |
| `submit` | 423 | POST `assessments/{assessment}/submit` | `tenant.behavioural-assessment.assessments.update` | service `DB::transaction` (`submit()`); activityLog **after** it | `'Submitted'` (after commit) | `ba_assessments`, `ba_assessment_status_history`, `sys_activity_logs`, `ba_score_runs` (via job) | BASS-01, BASS-02, BASS-03 |
| `reviewIndex` | 459 | GET `reviews` | `tenant.behavioural-assessment.reviews.viewAny` | none (reads) | — | — | BASS-11, BASS-14 |
| `reviewShow` | 473 | GET `reviews/{assessment}` | `tenant.behavioural-assessment.reviews.view` | none (reads) | — | — | BASS-11 |
| `approve` | 488 | POST `reviews/{assessment}/approve` | `tenant.behavioural-assessment.reviews.update` | service `DB::transaction` (`approve()`); activityLog **after** it | `'Approved'` (after commit) | `ba_assessments`, `ba_assessment_status_history`, `sys_activity_logs`, `ba_score_runs` (via job) | BASS-01, BASS-02, BASS-03 |
| `sendBack` | 517 | POST `reviews/{assessment}/send-back` | `tenant.behavioural-assessment.reviews.update` + FormRequest | service `DB::transaction` (`sendBack()`); activityLog **after** it | `'SentBack'` (after commit) | `ba_assessments`, `ba_assessment_status_history`, `sys_activity_logs`, `ba_score_runs` (via job) | BASS-01, BASS-02, BASS-03, BASS-05 |

## 6. Findings

### F1 — Errors

#### BASS-01 · M · ERR-00 — every write path wraps the service call or transaction in `try/catch (\Throwable)`, a shape the D2 list does not sanction

| Field | Value |
|---|---|
| **Rule** | ERR-00 (D1, no default severity) — under the settled Laravel idiom D1 there is **no** try/catch in controllers; D2 lists the only allowed catches (`\DomainException`; one truncate-then-rebuild catch; `SnapshotProtectionException` verbatim; service `report($e)` + fixed message). Mapping a MySQL `SQLSTATE 45000` trigger rejection is **not** among them. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:72-76` (`store`), `:158-162` (`update`), `:189-218` (`restore`), `:225-248` (`forceDelete`), `:338-365` (`destroy`), `:376-388` (`bulkRate`), `:402-414` (`autoSave`), `:427-433` (`submit`), `:492-498` (`approve`), `:522-528` (`sendBack`), all funnelled through `failure()` at `:596-621` |
| **Root cause** | The controller deliberately catches `Throwable` on every write so that a `\DomainException` (business rule) or a `QueryException` carrying a `BA: ` trigger message becomes a readable 422/flash via `failure()` / `BaTriggerError`. That centralisation is consistent and re-throws `ModelNotFoundException`, so ERR-02 is not violated — but it is still a controller try/catch outside the D2 list: the generic branch converts any other failure (deadlock, duplicate-key, DB down) into a fixed "The operation could not be completed." flash and a `Log::error` line instead of letting the central handler in `bootstrap/app.php` render. |
| **Consequence** | No user-visible defect on today's happy paths; a genuine infrastructure failure is hidden behind a generic flash and loses the friendly 500 page, and every new write method must remember to route through `failure()`. |
| **Reproduce** | static only — read the ten `try {` sites; triggering the generic branch needs an infrastructure failure that cannot be forced from the browser. |
| **Fix approach** | **Decision** — (a) keep this as the module's documented ERR-01 exception: comment each catch naming ERR-01 + date, and route `restore()`/`forceDelete()` through `failure()` too so there is one funnel; (b) move the trigger mapping into a custom exception rendered by `bootstrap/app.php` and delete the controller catches entirely (the pure D1 shape); (c) leave as is, record as accepted. |
| **Plan item** | BASS-01 in `02-fix-plan.md` §3 (DECISION) |

```php
        try {
            [$assessment, $created] = $this->service->create($request->validated(), $employee?->id);
        } catch (Throwable $e) {
            return $this->failure($request, $e, 'store');
        }
```

**Evidence**
```
$ grep -n "try {\|catch (\|Log::error" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php
72:        try {
74:        } catch (Throwable $e) {
158:        try {
160:        } catch (Throwable $e) {
189:        try {
210:        } catch (ModelNotFoundException $e) {
214:        } catch (Throwable $e) {
215:            Log::error('BaAssessmentController::restore failed', ['error' => $e->getMessage()]);
225:        try {
240:        } catch (ModelNotFoundException $e) {
244:        } catch (Throwable $e) {
245:            Log::error('BaAssessmentController::forceDelete failed', ['error' => $e->getMessage()]);
338:        try {
359:        } catch (ModelNotFoundException $e) {
363:        } catch (Throwable $e) {
376:        try {
384:        } catch (ModelNotFoundException $e) {
386:        } catch (Throwable $e) {
402:        try {
410:        } catch (ModelNotFoundException $e) {
412:        } catch (Throwable $e) {
427:        try {
429:        } catch (ModelNotFoundException $e) {
431:        } catch (Throwable $e) {
492:        try {
494:        } catch (ModelNotFoundException $e) {
496:        } catch (Throwable $e) {
522:        try {
524:        } catch (ModelNotFoundException $e) {
526:        } catch (Throwable $e) {
575:        try {
580:        } catch (Throwable $e) {
581:            Log::error('BaAssessmentController: score recompute failed', [
609:            Log::error("BaAssessmentController::{$action} failed", ['error' => $e->getMessage()]);
```

#### BASS-02 · M · ERR-05 — the logger records only the exception message, never the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:215` (`restore` catch), `:245` (`forceDelete` catch), `:581-585` (`recomputeScores`), `:609` (`failure`) and `Modules/BehaviouralAssessment/app/Jobs/ComputeStudentScoresJob.php:45` (`failed`) |
| **Root cause** | All five log sites pass `'error' => $e->getMessage()` (or `$exception?->getMessage()`) into `Log::error(...)` — a flat string with no stack trace, no file/line, no exception chain. A failure diagnosed from the log alone cannot be located. |
| **Consequence** | When a write fails, the operator sees only a message fragment, so the offending exception (class, trace, SQL) is not recoverable from the logs. |
| **Reproduce** | static only — the log lines run only on a failed write or a failed job, which need a forced DB/worker failure. |
| **Fix approach** | Add `'exception' => $e` (and `'exception' => $exception` in the job) to each log context, keeping the existing scalar context. |
| **Plan item** | BASS-02 in `02-fix-plan.md` §3 |

```php
        } catch (Throwable $e) {
            Log::error('BaAssessmentController::restore failed', ['error' => $e->getMessage()]);

            return back()->with('error', BaTriggerError::message($e) ?? 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -n "Log::error\|getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php Modules/BehaviouralAssessment/app/Jobs/ComputeStudentScoresJob.php
214:        } catch (Throwable $e) {
215:            Log::error('BaAssessmentController::restore failed', ['error' => $e->getMessage()]);
244:        } catch (Throwable $e) {
245:            Log::error('BaAssessmentController::forceDelete failed', ['error' => $e->getMessage()]);
581:            Log::error('BaAssessmentController: score recompute failed', [
584:                'error' => $e->getMessage(),
585:            ]);
609:            Log::error("BaAssessmentController::{$action} failed", ['error' => $e->getMessage()]);
```

Clean sub-checks in this family: no `$e->getMessage()` reaches the user (only `\DomainException` messages and the documented `BaTriggerError` trigger text; ERR-01 clean); every write catch re-throws `ModelNotFoundException`, so a missing record stays a 404 (ERR-02 clean); catch blocks return the method's declared return type (`RedirectResponse` / `JsonResponse|RedirectResponse` — ERR-03 clean); JSON and form failures are split by `$request->expectsJson()` (ERR-04 clean); `recomputeScores()` logs and returns `false` after a **committed** transition, which is a deliberate documented design, not a swallowed write (ERR-06 checked, not present). Evidence: `grep -n "getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php` shows only the log sites above and the `DomainException`/`BaTriggerError` message reads in `failure()`.

### F2 — Transactions and audit

#### BASS-03 · M · TXN-04 — `activityLog()` runs after the service transaction commits, in five methods

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes — not after commit* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:79` (`store`, service tx ends at `service->create()`), `:164` (`update`), `:436-442` (`submit`), `:500-505` (`approve`), `:530-534` (`sendBack`) |
| **Root cause** | Each write is committed by the service's own `DB::transaction(...)` and **then** the controller calls the `activityLog()` helper, which writes `sys_activity_logs` in a separate statement. If that helper fails (DB hiccup on the log insert), the business write is already committed and the request returns a 500 even though the change landed; if the write fails, no log is written and the audit trail silently misses the attempted change. `restore`/`forceDelete`/`destroy` already place their `activityLog()` inside their own transaction — these five do not. |
| **Consequence** | The activity trail can silently miss a change, and a log failure is reported to the user as a failed operation even though the assessment was created/updated/submitted. |
| **Reproduce** | static only — the log call is outside every service closure; see the `grep` output below. |
| **Fix approach** | Wrap each service call + its `activityLog()` in the controller's own `DB::transaction` (nested with the service's savepoint — one atomic unit), then build the response after the wrapper. |
| **Plan item** | BASS-03 in `02-fix-plan.md` §3 |

```php
        if ($created) {
            activityLog($assessment, 'Stored', ['message' => 'BaAssessment was stored.']);
        }
```

**Evidence**
```
$ grep -n "activityLog" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php
79:            activityLog($assessment, 'Stored', ['message' => 'BaAssessment was stored.']);
164:        activityLog($assessment, 'Updated', ['message' => 'BaAssessment was updated.']);
205:                activityLog($id, 'Restored', ['message' => 'BaAssessment was restored.']);
235:                activityLog($id, 'Deleted', ['message' => 'BaAssessment was deleted.']);
350:                activityLog($assessment, 'Trashed', ['message' => 'BaAssessment was trashed.']);
436:        activityLog($item, 'Submitted', [
500:        activityLog($item, 'Approved', [
530:        activityLog($item, 'SentBack', [
```

Note: `restore` (205), `forceDelete` (235) and `destroy` (350) already log **inside** their transaction — the five methods above do not. `bulkRate`/`autoSave` record no activity log at all by documented design (BR-BA-055: a draft grid is re-saved by a debounced autosave; logging each save would flood `sys_activity_logs`) — checked, accepted, not a finding.

#### BASS-04 · M · TXN-05 — `restore()`, `forceDelete()` and `destroy()` build HTTP responses inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()`/`response()` after it* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:200` (and `:207-208`; also `:230,237-238` in `forceDelete`, `:343-345,352-357` in `destroy`) |
| **Root cause** | In all three methods the `DB::transaction` closure ends with `return redirect()->route(...)->with(...)` (or `return back()->with(...)`, or a JSON response inside `destroy`), so a `RedirectResponse`/`JsonResponse` is constructed while the transaction is open, and the guard early-returns inside the closure commit an empty transaction on the refused path. |
| **Consequence** | No user-visible defect — it couples response construction to the transaction and is the documented anti-shape for TXN-05. |
| **Reproduce** | static only — response object literals inside the closures. |
| **Fix approach** | Return the model (or throw a `\DomainException` for the guards, which D2 sanctions) from the closure and build the redirect/JSON after it. |
| **Plan item** | BASS-04 in `02-fix-plan.md` §3 |

```php
                if ($clash) {
                    return back()->with('error', 'A live assessment already exists for this teacher, class-section and period. Delete it before restoring this one.');
                }

                $assessment->restore();

                activityLog($id, 'Restored', ['message' => 'BaAssessment was restored.']);

                return redirect()->route('behavioural-assessment.assessments.trashed')
                    ->with('success', 'Assessment restored successfully.');
```

**Evidence**
```
$ grep -n "return redirect\|return back\|return response()->json" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php
200:                    return back()->with('error', 'A live assessment already exists for this teacher, class-section and period. Delete it before restoring this one.');
207:                return redirect()->route('behavioural-assessment.assessments.trashed')
230:                    return back()->with('error', 'Only draft assessments can be permanently deleted.');
237:                return redirect()->route('behavioural-assessment.assessments.trashed')
343:                    ? response()->json(['success' => false, 'message' => 'Only draft assessments can be deleted.'], 422)
344:                    : back()->with('error', 'Only draft assessments can be deleted.');
352:                    return response()->json(['success' => true, 'message' => 'Assessment moved to trash.']);
356:                return redirect()->route('behavioural-assessment.assessments-page', ['tab' => 'my-assessments'])
```

Clean sub-checks in this family: every other multi-table write runs inside ONE `DB::transaction` closure (TXN-01 clean — `store`/`update`/`submit`/`approve`/`sendBack` defer to the service's own transaction, counted in §5 and F13); closure form is used everywhere, never manual `beginTransaction` (TXN-02 clean); no irreversible side effect sits inside a transaction — `AssessmentSubmitted`/`AssessmentApproved` dispatch with `ShouldDispatchAfterCommit`, and the controller's `recomputeScores()` call after `submit`/`sendBack` runs after commit (TXN-03 clean); check-then-act is backstopped by the DB unique index `uq_ba_assessment` (TXN-06 clean — the `$clash`/`$existing` reads are for a friendly message, the index is the real guard; verified in the migration).

### F3 — Authorization

#### BASS-05 · L · AUTH-04 — the same permission is authorized twice on five write methods

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:69` (and `:156`, `:373`, `:399`, `:519`) and `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRequest.php:20`, `BaAssessmentRatingsRequest.php:22`, `BaAssessmentSendBackRequest.php:17` |
| **Root cause** | The FormRequests already authorize: `BaAssessmentRequest` via `authorizeByCrudPermission('tenant.behavioural-assessment.assessments')` (POST → `.create`, PUT → `.update`), `BaAssessmentRatingsRequest` and `BaAssessmentSendBackRequest` via `authorizePermission(...)`. The controller then calls `Gate::authorize` for the same verbs — two checks, one concern, on `store`, `update`, `bulkRate`, `autoSave` and `sendBack`. |
| **Consequence** | No user-visible effect; duplicated logic that can drift (one surface changed, the other forgotten). |
| **Reproduce** | static only — both checks pass or fail together today. |
| **Fix approach** | Keep the FormRequest checks (they run first) and remove the five redundant `Gate::authorize` lines. |
| **Plan item** | BASS-05 in `02-fix-plan.md` §4 |

```php
        Gate::authorize('tenant.behavioural-assessment.assessments.create');
```

**Evidence**
```
$ grep -n "authorizeByCrudPermission\|authorizePermission" Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRequest.php Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRatingsRequest.php Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentSendBackRequest.php
BaAssessmentRequest.php:20:        return $this->authorizeByCrudPermission('tenant.behavioural-assessment.assessments');
BaAssessmentRatingsRequest.php:22:        return $this->authorizePermission('tenant.behavioural-assessment.assessments.update');
BaAssessmentSendBackRequest.php:17:        return $this->authorizePermission('tenant.behavioural-assessment.reviews.update');
```

#### BASS-06 · M · AUTH-06 — permission strings are repeated as literals across the controller and requests

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy, or constants — not repeated as literals in every method* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:46` (and `:53`, `:69`, `:96`, `:120`, `:156`, `:176`, `:187`, `:223`, `:253`, `:285`, `:336`, `:373`, `:399`, `:425`, `:461`, `:475`, `:490`, `:519`) and the three FormRequests |
| **Root cause** | The permission strings `tenant.behavioural-assessment.assessments.*` and `tenant.behavioural-assessment.reviews.*` are written out verbatim in 19 controller lines and 3 request files (plus the blades). Nothing binds them, so a rename is a search-and-replace across many files and one missed surface silently un-guards an action. |
| **Consequence** | No current user-visible effect — maintenance risk: one surface renamed, another missed, producing a silently un-guarded or always-denied action. |
| **Reproduce** | static only — the strings are consistent today. |
| **Fix approach** | A module-wide permission-constant / Policy pass. Not fixed per-controller here. |
| **Plan item** | none — see plan §10 (BASS-06) |
| **Evidence** | `grep -c "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php` → `19` |

```php
        Gate::authorize('tenant.behavioural-assessment.assessments.viewAny');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php
46:        Gate::authorize('tenant.behavioural-assessment.assessments.viewAny');
53:        Gate::authorize('tenant.behavioural-assessment.assessments.create');
69:        Gate::authorize('tenant.behavioural-assessment.assessments.create');
96:        Gate::authorize('tenant.behavioural-assessment.assessments.view');
120:        Gate::authorize('tenant.behavioural-assessment.assessments.update');
156:        Gate::authorize('tenant.behavioural-assessment.assessments.update');
176:        Gate::authorize('tenant.behavioural-assessment.assessments.restore');
187:        Gate::authorize('tenant.behavioural-assessment.assessments.restore');
223:        Gate::authorize('tenant.behavioural-assessment.assessments.forceDelete');
253:        Gate::authorize('tenant.behavioural-assessment.assessments.view');
285:        Gate::authorize('tenant.behavioural-assessment.assessments.view');
336:        Gate::authorize('tenant.behavioural-assessment.assessments.delete');
373:        Gate::authorize('tenant.behavioural-assessment.assessments.update');
399:        Gate::authorize('tenant.behavioural-assessment.assessments.update');
425:        Gate::authorize('tenant.behavioural-assessment.assessments.update');
461:        Gate::authorize('tenant.behavioural-assessment.reviews.viewAny');
475:        Gate::authorize('tenant.behavioural-assessment.reviews.view');
490:        Gate::authorize('tenant.behavioural-assessment.reviews.update');
519:        Gate::authorize('tenant.behavioural-assessment.reviews.update');
```

Clean sub-checks in this family: every routed method authorizes BEFORE loading any record (AUTH-01/AUTH-02 clean — `Gate::authorize` is the first statement in every method); every gate string is producible from `config/permissionslist.php` (`'behavioural-assessment.assessments' => $crud` and `'behavioural-assessment.reviews' => $crud` at lines 1419-1420, and `$crud` includes `viewAny/create/view/update/delete/restore/forceDelete` at lines 176-183 — evidence above); record-level ownership (AUTH-03) was measured: only `School Admin` and `Super Admin` hold `tenant.behavioural-assessment.assessments.*` / `reviews.*` on the test tenant, so the tenant-wide gate is today's intended boundary — no teacher-held ownership check is missing (query: `sys_role_has_permissions_jnt` joined to roles/permissions returned exactly those two roles). No `Gate::any` no-op (AUTH-05 clean). No Policy is consulted because gates pass strings — the module-wide pattern, listed in §13.2-style notes of the module summary; informational here.

### F4 — Validation and input

clean — all five write methods validate through FormRequests (`BaAssessmentRequest`, `BaAssessmentRatingsRequest`, `BaAssessmentSendBackRequest`); the controller reads only `$request->validated()` (never `$request->all()`/`except()` — evidence: `grep -n "validated()"` shows `store`/`update` at `:73,159`, `bulkRate`/`autoSave` at `:374,400`, `sendBack` at `:520`); optional fields are read with `?? []`/`?? null` or `array_key_exists` (VAL-03 clean); every field is typed (`integer`, `array`, `string`, `max:`, `in:`, `required_if`/`prohibited_if` — VAL-05 clean); no uploads (VAL-06 clean); the BR-BA-050 subject/scope cross-field rule lives in `BaAssessmentRequest` rules (`required_if`/`prohibited_if`), not hand-written in the controller (VAL-07 clean); uniqueness is enforced by the DB `uq_ba_assessment` plus friendly pre-checks in the service, and the soft-delete × unique interaction is coherent — `uq_guard = IFNULL(deleted_at,'1970-01-01')` means a trashed sheet does NOT block re-creating the same slot, while a live sheet does (VAL-04 clean; verified, see F13 #4).

⚠ UNVERIFIED — the F4 checklist asks to *execute* every FormRequest with cross-field rules against a realistic payload. `BaAssessmentRequest` has such rules; attempting `BaAssessmentRequest::createFromBase(...)->validateResolved()` in tinker aborted at the `authorize()` step with `AuthorizationException: This action is unauthorized.` before any rule ran, because no authenticated tenant user exists in tinker. What would settle it: an authenticated, permissioned HTTP POST in the browser with `assessment_scope=class_teacher` + `subject_id` set, expecting the 422 `'A class-teacher assessment is not tied to a subject.'` (a Pest feature test would prove the same — D4 forbids writing one). The `BaAssessmentRatingsRequest`/`BaAssessmentSendBackRequest` have no cross-field rules; their scalar rules are satisfied by inspection.

### F5 — Routes

#### BASS-07 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …): GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/BehaviouralAssessment/routes/web.php:102` (route) and `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:185` (method `restore`) |
| **Root cause** | `Route::get('assessments/{id}/restore', ...)` runs a write — `$assessment->restore()`, `activityLog()`, `sys_activity_logs` row — behind a GET. |
| **Consequence** | A link prefetcher, a crawler or a plain `GET /behavioural-assessment/assessments/{id}/restore` in a browser tab silently un-trashes a sheet with no CSRF token; the trash page's confirm dialog gives false confidence. |
| **Reproduce** | Open `/behavioural-assessment/assessments/{id}/restore` for a trashed sheet in a plain browser tab — the sheet is restored. |
| **Fix approach** | Change the route verb to POST; the shared `x-backend.table.action-trashed` component already emits `@csrf` and a POST form whenever the route is not GET, so only the route line changes. |
| **Plan item** | BASS-07 in `02-fix-plan.md` §1 (⚠ SHARED — route file) |

```php
Route::get('assessments/{id}/restore', [BaAssessmentController::class, 'restore'])->name('assessments.restore');
```

**Evidence**
```
$ sed -n '99,104p' Modules/BehaviouralAssessment/routes/web.php
Route::get('assessments/trash', [BaAssessmentController::class, 'trashed'])->name('assessments.trashed');
Route::get('assessments/{assessment}/details', [BaAssessmentController::class, 'details'])->name('assessments.details');
Route::get('assessments/remarks/{remark}/details', [BaAssessmentController::class, 'remarkDetails'])->name('assessments.remarks.details');
Route::get('assessments/{id}/restore', [BaAssessmentController::class, 'restore'])->name('assessments.restore');
Route::delete('assessments/{id}/force-delete', [BaAssessmentController::class, 'forceDelete'])->name('assessments.forceDelete');
Route::resource('assessments', BaAssessmentController::class)->only(['index', 'create', 'store', 'show', 'edit', 'update', 'destroy']);
```

Clean sub-checks in this family: every route points at an existing public method (RTE-02 — shown by §4's `route:list`); every public method is routed (RTE-03 — the 19 routes above cover all 20 public methods); reads are GET and writes are POST/PUT/DELETE except BASS-07 (RTE-04); the tenant middleware group (tenancy + `auth` + `verified`) wraps every route — verified in `RouteServiceProvider.php:25-36` (RTE-05); custom routes (`trash`, `details`, `remarks/{remark}/details`, `restore`, `force-delete`) are registered BEFORE `Route::resource` at web.php:99-104, so `/{id}` cannot capture `/trash` (RTE-06); the route `{assessment}`/`{id}` params feed scalar `int` arguments, so there is no unbound-model insert risk (`module-finalization.md` §3.3.1 checked, clean).

### F6 — Controller shape

#### BASS-08 · M · CTL-03 — no route-model binding; twelve methods load by `$id`/`$assessment` with `findOrFail()`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:94` (and `:118`, `:154`, `:185`, `:221`, `:251`, `:283`, `:334`, `:371`, `:397`, `:423`, `:473`) |
| **Root cause** | `show`/`edit`/`update`/`restore`/`forceDelete`/`details`/`remarkDetails`/`destroy`/`bulkRate`/`autoSave`/`submit`/`reviewShow` take `int $id`/`int $assessment` and call `findOrFail()`; the routes already carry `{assessment}`/`{id}`/`{remark}`, so implicit binding is available and the manual load is redundant. |
| **Consequence** | No user-visible defect today — the explicit `findOrFail()` is correct — so the cost is boilerplate and one more place to remember `->onlyTrashed()`/`->withTrashed()` if a parameter is ever rebound. |
| **Reproduce** | static only. |
| **Fix approach** | Bind the models (`BaAssessment $assessment` on the `{assessment}` routes, `BaAssessment $assessment` + `->withTrashed()` on the trash routes after renaming `{id}` → `{assessment}`). This touches the route file, so it is offered as a DECISION. |
| **Plan item** | BASS-08 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
    public function show(int $id): View
    {
        Gate::authorize('tenant.behavioural-assessment.assessments.view');
        $assessment = BaAssessment::with([
```

**Evidence**
```
$ grep -n "findOrFail" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php
104:        ])->findOrFail($id);
125:        ])->findOrFail($id);
191:        $assessment = BaAssessment::onlyTrashed()->findOrFail($id);
227:        $assessment = BaAssessment::onlyTrashed()->findOrFail($id);
265:        ])->findOrFail($id);
296:        ])->findOrFail($id);
340:        $assessment = BaAssessment::findOrFail($id);
478:        ])->findOrFail($assessment);
```

#### BASS-09 · M · CTL-05 — the create/edit dropdown loaders are copy-pasted

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: dropdown loaders shared by `create`/`edit`* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:54-57` (`create`) and `:141,147-149` (`edit`) |
| **Root cause** | The identical `openPeriods`, `classSections` and `subjects` loader queries (and the `employee` lookup) are written twice — create() at 54-57 and edit() at 141/147-149 — so a future change to the option lists must be made in two places. |
| **Consequence** | No user-visible defect; the two forms can drift (e.g. one adds a filter the other forgets). |
| **Reproduce** | static only — compare `sed -n '54,57p'` with `sed -n '147,149p'`. |
| **Fix approach** | Extract one private `formOptions(?Employee $employee): array` helper used by both `create()` and `edit()` (edit keeps its "own period stays selectable" prepend). |
| **Plan item** | BASS-09 in `02-fix-plan.md` §5 |

```php
        $openPeriods = BaAssessmentPeriod::where('status', BaAssessmentPeriod::STATUS_OPEN)->where('is_active', true)->orderByDesc('created_at')->get();
        $classSections = ClassSection::with(['class', 'section'])->where('is_active', true)->orderBy('name')->get();
        $subjects = Subject::where('is_active', true)->orderBy('name')->get(['id', 'name']);
```

**Evidence**
```
$ sed -n '54,57p' Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php
        $employee = Employee::where('user_id', auth()->id())->first();
        $openPeriods = BaAssessmentPeriod::where('status', BaAssessmentPeriod::STATUS_OPEN)->where('is_active', true)->orderByDesc('created_at')->get();
        $classSections = ClassSection::with(['class', 'section'])->where('is_active', true)->orderBy('name')->get();
        $subjects = Subject::where('is_active', true)->orderBy('name')->get(['id', 'name']);
$ sed -n '147,149p' Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php
        $classSections = ClassSection::with(['class', 'section'])->where('is_active', true)->orderBy('name')->get();
        $allTeachers = Employee::active()->orderBy('first_name')->get();
        $subjects = Subject::where('is_active', true)->orderBy('name')->get(['id', 'name']);
```

Clean sub-checks in this family: 622 lines / 20 public methods — under the CTL-01 thresholds (1,000 lines, 25 methods); no controller method exceeds 80 lines (largest is `restore` at 35 — CTL-02 clean in the controller); every public method has a return type (CTL-04 clean); no `extract()`, no `compact()` over ~15 variables (max 6 — CTL-07 clean); no `request()` helper in the controller, the `Request` is always injected (CTL-08 clean); no `dd()`/`dump()`/`ray()`/`print_r()` (CTL-09 clean; `grep -n "dd(\|dump(\|ray("` → no output); no dead code — private helpers `sheetExtras`, `recomputeScores`, `failure` are all called (CTL-10 clean in the controller).

### F7 — Models

clean — `BaAssessment` and `BaStudentRemark` both declare `$table` on a real migration (`2026_06_16_130617_create_ba_assessments_table.php`, `2026_06_16_130636_create_ba_student_remarks_table.php`), a `$fillable` list with nothing sensitive (MDL-01), `$casts` covering every integer/boolean/decimal/datetime column including `deleted_at` (MDL-02), `SoftDeletes` matching the real `deleted_at` (MDL-03 clean — no `belongsToMany` over a trashed pivot here), and every relationship is return-typed (MDL-04) and resolves. Neither model uses Spatie `InteractsWithMedia` (MDL-05/TEN-01 clean — no `getMediaModel()` needed). `BaAssessmentStatusHistory` is written by the service with all columns the DDL declares. Proof (tinker on tenant `00000000-0000-4000-8000-000000000001`, `tenancy()->initialize(...)` first):

```
BaAssessment::period => Modules\BehaviouralAssessment\Models\BaAssessmentPeriod
BaAssessment::teacher => Modules\SchoolSetup\Models\Employee
BaAssessment::subject => NULL (first row is class-teacher scope; relation resolves)
BaAssessment::classSection => Modules\SchoolSetup\Models\ClassSection
BaAssessment::submittedBy / reviewer / approvedBy / lockedBy => Modules\SchoolSetup\Models\Employee
BaAssessment::ratings / studentRemarks / statusHistory => Illuminate\Database\Eloquent\Collection
BaStudentRemark::assessment => Modules\BehaviouralAssessment\Models\BaAssessment
BaStudentRemark::commentTemplate => null (first row has none; relation resolves)
BaStudentRemark::student => Modules\StudentProfile\Models\Student
```

The `uq_guard` generated column (`IFNULL(deleted_at,'1970-01-01')`) is correctly omitted from `$fillable` and never written by application code, matching the DDL (`2026_06_16_130617...` line 55).

### F8 — Services and jobs

#### BASS-10 · M · SVC-01 — `BaAssessmentService::recordTransition()` reads the current HTTP request to capture the client IP

| Field | Value |
|---|---|
| **Rule** | SVC-01 (M) — *services don't touch HTTP: no `request()`, `session()`, `redirect()`, `response()`, `back()`* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php:714-717`, method `recordTransition()` (called by `create`, `submit`, `approve`, `sendBack`, `lockReviewed`) |
| **Root cause** | The service reaches into the HTTP layer (`app()->bound('request')`, `request()->ip()`) to fill `ba_assessment_status_history.ip_address`. A service should be given its inputs; the caller (the controller) is the layer that knows the request. When the service runs from a console command the IP silently becomes `null` with no signal. |
| **Consequence** | The transition audit's IP column is empty for any non-HTTP caller, and the service cannot be used cleanly from a console command or a differently-sourced caller. |
| **Reproduce** | static only — the HTTP read is at the top of `recordTransition()`; behaviour is differential (web vs console). |
| **Fix approach** | Add `?string $clientIp = null` to `recordTransition()` (and forward it through `create`, `submit`, `approve`, `sendBack`, `lockReviewed`); the controller passes `$request->ip()` at its four call sites. |
| **Plan item** | BASS-10 in `02-fix-plan.md` §5 |

```php
        $actor = BaActor::id();
        $ip = null;

        if (app()->bound('request') && ! app()->runningInConsole() && request()->ip() !== null) {
            $packed = @inet_pton((string) request()->ip());
            $ip = $packed === false ? null : $packed;
        }
```

**Evidence**
```
$ grep -n "request()\|app()->bound\|runningInConsole" Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php
714:        if (app()->bound('request') && ! app()->runningInConsole() && request()->ip() !== null) {
715:            $packed = @inet_pton((string) request()->ip());
```

#### BASS-11 · M · SVC-02 — `BaReviewSignalService` is pulled with `app()` mid-method instead of constructor injection

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection — not `new FooService()` or `app(Foo::class)` mid-method* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:468` (`reviewIndex`) and `:484` (`reviewShow`) |
| **Root cause** | The controller injects `BaAssessmentService` through its constructor but resolves the signal service with `app(BaReviewSignalService::class)` at two call sites. The dependency is invisible in the class signature and is re-resolved per call. |
| **Consequence** | The dependency cannot be swapped and is not visible in the class contract; a third grid page would repeat the `app()` call. |
| **Reproduce** | static only. |
| **Fix approach** | Add `private readonly BaReviewSignalService $signals` to the constructor and replace the two `app(...)` calls with `$this->signals->...`. |
| **Plan item** | BASS-11 in `02-fix-plan.md` §5 |

```php
        $reviewSignals = app(BaReviewSignalService::class)->forAssessments($queue->getCollection());
```

**Evidence**
```
$ grep -n "app(BaReviewSignalService" Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php
468:        $reviewSignals = app(BaReviewSignalService::class)->forAssessments($queue->getCollection());
484:            'reviewSignals' => app(BaReviewSignalService::class)->forAssessment($item),
```

#### BASS-12 · M · CTL-02 — two service methods exceed the method-length guidance (`saveRatings` 196 lines, `assemble` 108 lines)

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M; the rule's own text makes > 150 lines H, and I keep M because the target is a working transactional service method whose length is maintainability debt, not a wrong result — §8.4 #8) — *method length: over 80 lines → extract; over 150 lines is H* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php:338-533` (`saveRatings`) and `Modules/BehaviouralAssessment/app/Services/BaReviewSignalService.php:199-306` (`assemble`) |
| **Root cause** | `saveRatings()` performs five concerns in one closure — rating cells, criterion remarks, student remarks, scale freezing, header completion update — and `assemble()` builds all five signals plus the shared meta block in one method. Both exceed the extract-at-80 guidance. |
| **Consequence** | No user-visible defect; the methods are hard to read, hard to test in isolation, and the QRY-07 bulk-write conversion (BASS-13) is entangled with `saveRatings`' length. |
| **Reproduce** | static only. |
| **Fix approach** | **Decision** — (a) extract `saveRatings` into per-concern private helpers (`saveRatingCells`, `saveCriterionRemarks`, `saveStudentRemarks`) and `assemble` into per-signal builders now; (b) defer to the D3 split/refactor pass after go-live; (c) leave as is, record as accepted. |
| **Plan item** | BASS-12 in `02-fix-plan.md` §9 (DECISION) |

```php
    public function saveRatings(int $assessmentId, array $ratings, ?array $remarks, ?array $criterionRemarks = null, array $remarkTemplates = []): BaAssessment
    {
        return DB::transaction(function () use ($assessmentId, $ratings, $remarks, $criterionRemarks, $remarkTemplates) {
```

**Evidence**
```
$ wc -l <(sed -n '338,533p' Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php)
196
$ wc -l <(sed -n '199,306p' Modules/BehaviouralAssessment/app/Services/BaReviewSignalService.php)
108
```

Clean sub-checks in this family: `BaAssessmentService` performs no other HTTP touch, has no constructor dependencies to inject (SVC-02 clean apart from BASS-11), never writes on a read path — `grid()`, `studentsFor()`, `criteriaForClass()`, `ratingScaleIdFor()`, `ratingLevelsFor()` are SELECT-only (SVC-03 clean); one implementation per FSM operation — `recordTransition()` is the single status-history writer, `lockReviewed()` is shared by `submit`/`approve` (SVC-04 clean); repeated lookups are bounded (SVC-05 addressed in BASS-11's memoisation concern — accepted as M here, see F9 note). `ComputeStudentScoresJob` stores ids, not models (JOB-05), declares `$tries = 1` and `$timeout = 300` with a `failed()` (JOB-02), runs in tenant context through `QueueTenancyBootstrapper` (JOB-01 — `config/tenancy.php` line 43 enables it, and `BaDispatch::job()` dispatches inside the initialized tenant), and delegates batching to `BehaviouralScoreService` (JOB-03 checked, the job itself never loops). BaDispatch usage is correct (linked report owns the class); the inline/async switch matches `config('behaviouralassessment.async_jobs')`.

### F9 — Queries and performance

#### BASS-13 · M · QRY-07 — `saveRatings` writes one row at a time in three loops

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *bulk writes: `insert()`, `upsert()`, `whereIn(...)->update()` instead of `create()`/`update()` per row in a loop* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php:394` (and `:396`, `:430`, `:433`, `:494`, `:497`) — the rating, criterion-remark and student-remark write loops of `saveRatings()` |
| **Root cause** | The grid save loop calls `$row->update($attributes)` or `BaAssessmentRating::create(...)` / `BaStudentRemark::create(...)` per row. The loop bound is the grid payload — the request's own comment (BaAssessmentRatingsRequest.php:28-30) cites a 48-student × 36-criterion grid (1,728 cells), so a full-sheet save issues up to ~1,700 write statements inside the transaction. |
| **Consequence** | A full-grid save is slow and generates thousands of individual UPDATE/INSERT statements; on a large school the auto-save runs this several times a minute. |
| **Reproduce** | Save a filled grid on the rating sheet and watch the query log (or time it); the per-cell statements are visible in the source loop. |
| **Fix approach** | **Decision** — (a) ⭐ fold the bulk conversion into the BASS-12 extraction: pre-validate the incoming cells, then `upsert()` on the `(assessment_id, student_id, criterion_id)` trio and `whereIn(...)->update()` for the diffs; `ba_assessment_ratings` has `uq_ba_rating (assessment_id, student_id, criterion_id, uq_guard)` (migration line 43), which supports MySQL `ON DUPLICATE KEY UPDATE`; (b) do a standalone bulk conversion now, outside the extraction; (c) accept, document. |
| **Plan item** | BASS-13 in `02-fix-plan.md` §6 (DECISION) |

```php
                    if ($row) {
                        $row->update($attributes);
                    } else {
                        BaAssessmentRating::create($attributes + [
```

**Evidence**
```
$ grep -n "->update(\$attributes)\|BaAssessmentRating::create\|BaStudentRemark::create\|->update(\['remark'" Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php
394:                    if ($row) {
395:                        $row->update($attributes);
396:                    } else {
397:                        BaAssessmentRating::create($attributes + [
430:                                $row->update(['remark' => $text, 'updated_by' => $actor]);
433:                            BaAssessmentRating::create([
494:                                $remark->update($changes + ['updated_by' => $actor]);
497:                        BaStudentRemark::create([
```

Clean sub-checks in this family: lists paginate at 10 — `trashed()` and `reviewIndex()` both `->paginate(10)` (QRY-02 clean; each page has a single paginator so no page-name clash, QRY-13 clean); no query inside a loop — the loops in `saveRatings` write, and every read they need was pre-fetched (`$existing`, `$cells`, `$existingRemarks`, `$levels`, `$studentSet`, `$criterionSet` — QRY-01 clean); the scanner candidates QRY-04 (`studentsFor` `->get()->pluck('student')`) and QRY-05 (`grid` `->get()->groupBy()`) are rejected: they restructure a **bounded per-sheet collection** (current students of one class-section; one assessment's ratings) into the `[student][criterion]` shape, which SQL cannot produce directly, and the tables are small (17 assessments / 611 remarks live in the test tenant) — not a whole-table aggregation; QRY-11 candidates in `BaReviewSignalService` are confirmed constant-only: every interpolated fragment (`$unexplained`, `$lowCut`, `$highCut`, `$band`) is built from `self::BAND_FRACTION` and string literals, never from request input (evidence: `grep -n "whereRaw\|selectRaw"` at lines 329,345,360,410-411,414,419-420,433-434,462 — every interpolation traceable to a constant); the `cohortMeans()` query adds one grouped query per page — 4 aggregate queries per review page regardless of page size, the documented REQ-BA-023 design (SVC-05: `ratingScaleIdFor`/`configFor` re-run within one request — accepted as M maintainability, see the plan note in BASS-12; the signal service already memoises per instance via `$fractionCache`/`$bankFragments`).

### F10 — Views

#### BASS-14 · M · VIEW-02 / QRY-01 — `review-index` lazy-loads `teacher.user` inside the queue loop

| Field | Value |
|---|---|
| **Rule** | VIEW-02 (M) — *relations used inside `@foreach` are eager-loaded by the controller (lazy loads in a loop = N+1)* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:462` (the `with([...])` list in `reviewIndex`) and `Modules/BehaviouralAssessment/resources/views/assessment/review-index.blade.php:47,126` |
| **Root cause** | `reviewIndex()` eager-loads `['period', 'teacher', 'subject', 'classSection.class', 'classSection.section']`, but the blade reads `$assessment->teacher?->user` at line 47 (name badge) and line 126 (send-back modal). `teacher` is loaded, `teacher.user` is not — so the `@forelse($queue as $assessment)` loop fires one extra query per row (10 extra queries per full page). |
| **Consequence** | The review queue page runs 1 + N queries (N = rows on the page) instead of a fixed count. |
| **Reproduce** | Open `/behavioural-assessment/reviews` with a full page and watch the query log: one `select * from sys_users` per row. |
| **Fix approach** | Add `'teacher.user'` to the `with([...])` list in `reviewIndex()`. |
| **Plan item** | BASS-14 in `02-fix-plan.md` §7 |

```php
        $queue = BaAssessment::with(['period', 'teacher', 'subject', 'classSection.class', 'classSection.section'])
```

**Evidence**
```
$ grep -n "teacher?->user\|@forelse(\$queue" Modules/BehaviouralAssessment/resources/views/assessment/review-index.blade.php
42:                                @forelse($queue as $assessment)
47:                                            @if($assessment->teacher?->user)
126:                                                                    {{ $assessment->teacher?->user?->name ?? 'Unknown' }}<br>
```

Clean sub-checks in this family: no `Model::`/`DB::` queries in any of the six assessment blades (VIEW-01 clean — `grep -rn "Model::\|DB::\|->where("` over `assessment/*.blade.php` matches only collection methods like `->count()`/`->groupBy()` on passed-in collections); no `{!! !!}` anywhere (VIEW-03 clean — `grep -rn "{!!"` → no output; all user text renders through `{{ }}`); `show()` eager-loads everything its blade touches (`classSection.class`, `classSection.section`, `period`, `subject`, `teacher`, `statusHistory.actor` — verified against `show.blade.php`'s relation chains); the trash row actions use `x-backend.table.action-trashed` with the `restorePermission`/`forceDeletePermission` props (was the standard component); the create-form control count (~6) is below the modal-standard threshold but the module ships `create` as a page with a separate edit page — page-level, accepted; the single-item pages (`review-show` line 47 `$item->teacher?->user`, `edit` lines 151-152 `$assessment->teacher`/`$assessment->subject`) each make 1-2 lazy queries for ONE row — not an N+1, noted only.

### F11 — Security and tenancy

clean — no `env()` in any in-scope file (`grep -rn "env("` → no output); no hard-coded ids or `?? 1` fallbacks (SEC-03 clean — status/period ids all come from validated input or the DB); the JSON endpoints shape their payloads (`remarkDetails` builds a mapped array; `details` returns the assessment `toArray()` plus flattened names, with eager loads restricted to `:id,name`-style columns — SEC-02 clean; the users of these endpoints hold the measured admin-only permissions); no request body/token logging — every `Log::error` carries ids and a message, never `$request->all()` (SEC-04 clean); no file serving (SEC-05 clean — file exports live in other controllers); no cache usage in scope (TEN-02 clean); no central-model access from tenant code (TEN-03 clean); `config('behaviouralassessment.async_jobs')` is read through the config file, not `env()` (SEC-01 clean).

### F12 — Style

#### BASS-15 · L · STY-02 — the controller is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php:13-28` (and `:553`) |
| **Root cause** | Two imports are out of sorted order (`Illuminate\Support\Collection` is missing, `ComputeStudentScoresJob` sits after `BaTriggerError`) and the `sheetExtras()` docblock uses a fully-qualified class name (`\Illuminate\Support\Collection`) instead of the imported short name. |
| **Consequence** | Fails a `pint --test` gate; noise diff for the next editor. |
| **Reproduce** | Run `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php` — it reports `fail`. |
| **Fix approach** | Apply the Pint fixers (verified against a copy). |
| **Plan item** | BASS-15 in `02-fix-plan.md` §8 |
| **Evidence** | `vendor/bin/pint --test ...` output below |

```php
use Modules\BehaviouralAssessment\Jobs\ComputeStudentScoresJob;
use Modules\BehaviouralAssessment\Support\BaDispatch;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Http\/Controllers\/BaAssessmentController.php","fixers":["fully_qualified_strict_types","unary_operator_spaces","braces_position","not_operator_with_successor_space","single_line_empty_body","ordered_imports"]}]}
$ diff Modules/BehaviouralAssessment/app/Http/Controllers/BaAssessmentController.php /tmp/opencode/pintcp/BaAssessmentController.php
13a14
> use Illuminate\Support\Collection;
20a22
> use Modules\BehaviouralAssessment\Jobs\ComputeStudentScoresJob;
28d29
< use Modules\BehaviouralAssessment\Jobs\ComputeStudentScoresJob;
553c554
<      * @return array{cellMeta: \Illuminate\Support\Collection, remarkTemplateIds: \Illuminate\Support\Collection}
---
>      * @return array{cellMeta: Collection, remarkTemplateIds: Collection}
```

#### BASS-16 · L · STY-02 — `BaAssessmentService` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php:334` (and `:336` — the `saveRatings` docblock continuation alignment) |
| **Root cause** | The `phpdoc_align` fixer re-aligns two `*` continuation lines under the `@param` list of `saveRatings`. |
| **Consequence** | Fails a `pint --test` gate. |
| **Reproduce** | Run `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php` — it reports `fail`. |
| **Fix approach** | Apply the Pint fixers. |
| **Plan item** | BASS-16 in `02-fix-plan.md` §8 |
| **Evidence** | `vendor/bin/pint --test ...` output below |

```php
     *                                                                                (ba_assessment_ratings.remark); null = untouched
```

**Evidence**
```
$ vendor/bin/pint --test Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Services\/BaAssessmentService.php","fixers":["unary_operator_spaces","not_operator_with_successor_space","phpdoc_align"]}]}
$ diff Modules/BehaviouralAssessment/app/Services/BaAssessmentService.php /tmp/opencode/pintcp/BaAssessmentService.php
334c334
<      *                                                                                (ba_assessment_ratings.remark); null = untouched
---
>      *                                                                              (ba_assessment_ratings.remark); null = untouched
336c336
<      *                                                    (comment_template_id, analytics only); absent/empty = unchanged
---
>      *                                                     (comment_template_id, analytics only); absent/empty = unchanged
```

#### BASS-17 · L · STY-02 — `BaReviewSignalService` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaReviewSignalService.php:11-12` (and `:187`) |
| **Root cause** | `BaConfig` is used fully-qualified (`\Modules\BehaviouralAssessment\Models\BaConfig::where(...)`) instead of imported. |
| **Consequence** | Fails a `pint --test` gate. |
| **Reproduce** | Run `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Services/BaReviewSignalService.php` — it reports `fail`. |
| **Fix approach** | Add the import and use the short name. |
| **Plan item** | BASS-17 in `02-fix-plan.md` §8 |
| **Evidence** | `vendor/bin/pint --test ...` output below |

```php
                ? \Modules\BehaviouralAssessment\Models\BaConfig::where('academic_session_id', $sessionId)->first()
```

**Evidence**
```
$ vendor/bin/pint --test Modules/BehaviouralAssessment/app/Services/BaReviewSignalService.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Services\/BaReviewSignalService.php","fixers":["fully_qualified_strict_types","unary_operator_spaces","not_operator_with_successor_space"]}]}
$ diff Modules/BehaviouralAssessment/app/Services/BaReviewSignalService.php /tmp/opencode/pintcp/BaReviewSignalService.php
11a12
> use Modules\BehaviouralAssessment\Models\BaConfig;
187c188
<                 ? \Modules\BehaviouralAssessment\Models\BaConfig::where('academic_session_id', $sessionId)->first()
---
>                 ? BaConfig::where('academic_session_id', $sessionId)->first()
```

#### BASS-18 · L · STY-02 — `BaAssessmentRequest` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRequest.php:26` (and `:28`, `:35`) |
| **Root cause** | The `=>` in `rules()` are column-aligned; the `binary_operator_spaces` fixer un-aligns them. |
| **Consequence** | Fails a `pint --test` gate. |
| **Reproduce** | Run `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRequest.php` — it reports `fail`. |
| **Fix approach** | Apply the Pint fixers. |
| **Plan item** | BASS-18 in `02-fix-plan.md` §8 |
| **Evidence** | `vendor/bin/pint --test ...` output below |

```php
            'period_id'        => ['required', 'integer', 'exists:ba_assessment_periods,id'],
```

**Evidence**
```
$ vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRequest.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Http\/Requests\/BaAssessmentRequest.php","fixers":["binary_operator_spaces"]}]}
$ diff Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRequest.php /tmp/opencode/pintcp/BaAssessmentRequest.php
26c26
<             'period_id'        => ['required', 'integer', 'exists:ba_assessment_periods,id'],
---
>             'period_id' => ['required', 'integer', 'exists:ba_assessment_periods,id'],
28c28
<             'teacher_id'       => ['nullable', 'integer', 'exists:sch_employees,id'],
---
>             'teacher_id' => ['nullable', 'integer', 'exists:sch_employees,id'],
35c35
<             'subject_id'       => [
---
>             'subject_id' => [
```

#### BASS-19 · L · STY-02 — `BaAssessmentRatingsRequest` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRatingsRequest.php:55-67` |
| **Root cause** | The `=>` in `rules()` are column-aligned; the `binary_operator_spaces` fixer un-aligns them. |
| **Consequence** | Fails a `pint --test` gate. |
| **Reproduce** | Run `vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRatingsRequest.php` — it reports `fail`. |
| **Fix approach** | Apply the Pint fixers. |
| **Plan item** | BASS-19 in `02-fix-plan.md` §8 |
| **Evidence** | `vendor/bin/pint --test ...` output below |

```php
            'ratings'     => ['nullable', 'array'],
```

**Evidence**
```
$ vendor/bin/pint --test Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRatingsRequest.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/BehaviouralAssessment\/app\/Http\/Requests\/BaAssessmentRatingsRequest.php","fixers":["unary_operator_spaces","not_operator_with_successor_space","binary_operator_spaces"]}]}
$ diff Modules/BehaviouralAssessment/app/Http/Requests/BaAssessmentRatingsRequest.php /tmp/opencode/pintcp/BaAssessmentRatingsRequest.php
55,56c55,56
<             'ratings'     => ['nullable', 'array'],
<             'ratings.*'   => ['array'],
---
>             'ratings' => ['nullable', 'array'],
>             'ratings.*' => ['array'],
58,59c58,59
<             'remarks'     => ['nullable', 'array'],
<             'remarks.*'   => ['nullable', 'string', 'max:1000'],
---
>             'remarks' => ['nullable', 'array'],
>             'remarks.*' => ['nullable', 'string', 'max:1000'],
61,62c61,62
<             'criterion_remarks'     => ['nullable', 'array'],
<             'criterion_remarks.*'   => ['array'],
---
>             'criterion_remarks' => ['nullable', 'array'],
>             'criterion_remarks.*' => ['array'],
67c67
<             'remark_templates'   => ['nullable', 'array'],
---
>             'remark_templates' => ['nullable', 'array'],
```

Informational (no ID): STY-07 (user-facing strings hard-coded rather than via `__()` keys) is present here, as it is module-wide — accepted, not planned. All in-scope files already carry `declare(strict_types=1);` (STY-01 clean).

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong overwrite | 2 Delete-before-store | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Lying message | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok | ok (uq index) | BASS-05 (dup, L) | ok | ok |
| `update` | ok | ok | ok | ok | ok (lock) | BASS-05 | ok | ok |
| `restore` | ok | ok | ok | ok | ok (uq index) | ok | ok | ok |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `bulkRate` / `autoSave` | ok | ok | ok | ok | ok (lock) | BASS-05 | ok | ok |
| `submit` | ok | ok | ok | ok | ok (lock) | ok | ok | ok |
| `approve` | ok | ok | ok | ok | ok (lock) | ok | ok | ok |
| `sendBack` | ok | ok | ok | ok | ok (lock) | BASS-05 | ok | ok |

Notes. (1) `update` writes only the five validated header keys via `$changes` (period/class-section/teacher/scope/subject) and rejects moves once ratings exist; `saveRatings` writes only rating/remark/freeze/header-completion fields; no method resets another's data. (2) `forceDelete` runs on trashed+draft rows only, and the FKs `fk_ba_rating_assess` / `fk_ba_remark_assess` / `fk_ba_hist_assess` are `cascadeOnDelete`, so no orphaned rows survive; `destroy` soft-deletes and the trash page restores the whole sheet. (3) One implementation per FSM operation (`recordTransition`, `lockReviewed`, `status` constants). (4) The `uq_guard = IFNULL(deleted_at,'1970-01-01')` design is coherent: a **trashed** sheet does not block a new sheet for the same slot (new row's guard is `1970-01-01`, the trashed row's guard is its delete timestamp), while two **live** sheets for one slot collide on the index — verified in `2026_06_16_130617_create_ba_assessments_table.php:55-57`; the same design on `ba_assessment_ratings` (`uq_ba_rating`) lets a re-added remark create a fresh live row next to a trashed one. (5) `create()`/`restore()` check-then-act is backstopped by `uq_ba_assessment`; all other service writes take `lockForUpdate()`. A race loser in `create()` (two admins starting the same sheet) gets the generic failure message rather than the friendly "already exists" text because the duplicate-key `QueryException` (SQLSTATE 23000) is not a BA trigger — cosmetic, covered by BASS-01's shape. (6) Every routed method authorizes (F3 clean list); the duplicate gates are BASS-05. (7) Messages match the actual FSM: `submit` says "accepted (no review required)" only when `!$item->isSubmitted()` (true only for the auto-publish → REVIEWED path), `approve` says "scores are being recomputed" only when the job is dispatched, `sendBack` restores draft and recomputes when the sheet had counted (`previous === REVIEWED`). (8) All endpoints are consumed: `details`/`remarkDetails` by `_my-assessments-scripts.blade.php`, `auto-save`/`bulk-rate`/`submit` by `show.blade.php` and `_my-assessments.blade.php`, `reviews.*` by `review-index/review-show` and `_review-queue.blade.php` — no dead feature.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` (owner: BaAuditLogController) | `BaAuditLog::log()` reads `request()->ip()`/`request()->userAgent()` itself — the same SVC-01 HTTP-in-model paradigm the service's `recordTransition()` mirrors (BASS-10). If the audit-log owner fixes it, `recordTransition` could copy that pattern instead of the pass-through. | SVC-01 | the BaAuditLogController report |
| `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` (owner: BaBehaviourPointController) | `message()` only maps `SQLSTATE 45000` + `'BA: '`; in the `restore`/`forceDelete` catches it is the only attempt at a friendly message, so a genuine duplicate-key race (SQLSTATE 23000) becomes the generic flash — see BASS-01. | ERR-01 (informational) | the BaBehaviourPointController report |
| `resources/views/components/backend/table/action-trashed.blade.php` (common component) | Reads the restore route's verb at render time, so a GET restore renders as a GET form. Correct as written; it adapts automatically when BASS-07 changes the verb. | RTE-01 | no change needed |
| `resources/views/pages/partials/assessments/*.blade.php`, `_review-queue.blade.php` (BaDashboardController) | The "My Assessments"/"Review Queue" tab lists that post to `submit`/`approve`/`send-back` and fetch `details`/`remarkDetails` are rendered by `BaDashboardController::assessmentsPage()`; the queue list duplicates part of `reviewIndex()`'s row markup. | VIEW (informational) | the BaDashboardController audit |
| `Modules/BehaviouralAssessment/app/Support/BaActor.php` (owner: BaCommentBankController) | `BaActor::id()` supplies `created_by`/`updated_by`/`actor_id`; its `sys_users`-vs-`sch_employees` return type decides whether the `*_by` FKs resolve — read by both the controller and the service. | — (informational) | the BaCommentBankController report |

## 8. Not covered, and why

- **FormRequest cross-field execution** (F4): `BaAssessmentRequest` could not be executed in tinker — `authorize()` aborts with `AuthorizationException` because no authenticated tenant user exists in the tinker process. Marked `⚠ UNVERIFIED` in F4; a browser POST or a Pest feature test (D4 forbids writing tests) would settle it.
- **Views rendering**: per D4 no page was rendered in a browser; the six assessment blades were audited by source read only (queries, eager-loads, `{!! !!}`, row actions).
- **The queue path with `BA_ASYNC_JOBS=true`**: `ComputeStudentScoresJob` was inspected, not run with a queue worker (Hostinger has none by design — `BaDispatch` exists precisely for that); the `QueueTenancyBootstrapper` stamping is verified in `config/tenancy.php` only.
- **`BehaviouralScoreService::computeForPeriod()`** (the job's target): read for the job's contract (never throws, records on `ba_score_runs`), not audited — it belongs to the score/period controller's report.
- **The DB triggers** (`trg_ba_assessment_status_bu` backstop FSM): read only via the restore comment and the `BaTriggerError` mapping; not executed.
- **Live DB row counts**: single tenant `00000000-0000-4000-8000-000000000001`; other tenants were not queried.
- **`BaAssessmentStatusHistory`**: full audit deferred — it is written by the service (`recordTransition`) but has no owner row in `_Info/00-CLASS-OWNERS.md`; listed here as usage-only so the main session can register it.