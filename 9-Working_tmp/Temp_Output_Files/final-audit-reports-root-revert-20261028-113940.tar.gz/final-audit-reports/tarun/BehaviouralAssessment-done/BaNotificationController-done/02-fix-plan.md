# Fix Plan — BehaviouralAssessment / BaNotificationController

**From:** `01-report.md` (2026-10-12) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` to `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/BehaviouralAssessment/routes/web.php` | route file — no ticked item changes the route; `{notification}` already matches the controller argument |
| `config/permissionslist.php` | shared by all modules; `tenant.behavioural-assessment.notifications.retry` is already declared and seeded |
| `Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/_outbox.blade.php` | rendered by `BaDashboardController` — not this report |
| `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | owned by `tarun/BehaviouralAssessment-done/BaBehaviourPointController-done` |
| `Modules/BehaviouralAssessment/app/Support/BaActor.php` | owned by `tarun/BehaviouralAssessment-done/BaCommentBankController-done` |
| `Modules/BehaviouralAssessment/app/Jobs/DispatchNotificationJob.php` | clean — no item touches it |
| `database/migrations/tenant/**` | never edit an existing migration |
| `final-audit-reports/_Info/00-CLASS-OWNERS.md`, `final-audit-reports/tarun/BehaviouralAssessment/00-INDEX.md` | managed centrally by the main session |

## 1. Blockers reachable today

_None — no B-severity finding._

## 2. Fixes that arm a latent defect (sequenced)

_None._

## 3. Errors & transactions (F1/F2)

- [ ] **BNC-01** · H · TXN-01 · `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:663-672` — put each status write and the incident-flag update in ONE transaction.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php`
  - **Before** (`retry`, lines 663-672):
    ```php
        if ($notification->status !== BaNotification::STATUS_PENDING) {
            $notification->forceFill([
                'status' => BaNotification::STATUS_PENDING,
                'failure_reason' => null,
                'suppress_reason' => null,
                'updated_by' => BaActor::id(),
            ])->save();

            $this->syncIncidentNotified($notification);
        }
    ```
  - **After:** (`retry`, lines 663-672):
    ```php
        if ($notification->status !== BaNotification::STATUS_PENDING) {
            $this->persistOutcome($notification, [
                'status' => BaNotification::STATUS_PENDING,
                'failure_reason' => null,
                'suppress_reason' => null,
                'updated_by' => BaActor::id(),
            ]);
        }
    ```
  - **Before** (`attempt`, sent branch, lines 737-746):
    ```php
            $row->forceFill([
                'status' => BaNotification::STATUS_SENT,
                'sent_at' => $now,
                'attempt_count' => $attempts,
                'last_attempt_at' => $now,
                'failure_reason' => $errors === [] ? null
                    : mb_substr('Partial: '.count($errors).' of '.count($contacts).' recipients failed — '.$errors[0], 0, 500),
                'updated_by' => BaActor::id(),
            ])->save();
            $this->syncIncidentNotified($row);
    ```
  - **After:** (`attempt`, sent branch, lines 737-746):
    ```php
            $this->persistOutcome($row, [
                'status' => BaNotification::STATUS_SENT,
                'sent_at' => $now,
                'attempt_count' => $attempts,
                'last_attempt_at' => $now,
                'failure_reason' => $errors === [] ? null
                    : mb_substr('Partial: '.count($errors).' of '.count($contacts).' recipients failed — '.$errors[0], 0, 500),
                'updated_by' => BaActor::id(),
            ]);
    ```
  - **Before** (`attempt`, failure branch, lines 754-764):
    ```php
        $row->forceFill([
            'status' => $final ? BaNotification::STATUS_FAILED : BaNotification::STATUS_PENDING,
            'attempt_count' => $attempts,
            'last_attempt_at' => $now,
            'failure_reason' => $reason,
            'updated_by' => BaActor::id(),
        ])->save();

        if ($final) {
            $this->syncIncidentNotified($row);
        }
    ```
  - **After:** (`attempt`, failure branch, lines 754-764):
    ```php
        $this->persistOutcome($row, [
            'status' => $final ? BaNotification::STATUS_FAILED : BaNotification::STATUS_PENDING,
            'attempt_count' => $attempts,
            'last_attempt_at' => $now,
            'failure_reason' => $reason,
            'updated_by' => BaActor::id(),
        ]);
    ```
  - **Before** (`markFailed`, lines 777-783):
    ```php
        $row->forceFill([
            'status' => BaNotification::STATUS_FAILED,
            'failure_reason' => mb_substr($reason, 0, 500),
            'last_attempt_at' => Carbon::now(),
            'updated_by' => BaActor::id(),
        ])->save();
        $this->syncIncidentNotified($row);
    ```
  - **After:** (`markFailed`, lines 777-783):
    ```php
        $this->persistOutcome($row, [
            'status' => BaNotification::STATUS_FAILED,
            'failure_reason' => mb_substr($reason, 0, 500),
            'last_attempt_at' => Carbon::now(),
            'updated_by' => BaActor::id(),
        ]);
    ```
  - **Before** (`suppress`, lines 1010-1016):
    ```php
        $row->forceFill([
            'status' => BaNotification::STATUS_SUPPRESSED,
            'suppress_reason' => mb_substr($reason, 0, 255),
            'last_attempt_at' => Carbon::now(),
            'updated_by' => BaActor::id(),
        ])->save();
        $this->syncIncidentNotified($row);
    ```
  - **After:** (`suppress`, lines 1010-1016):
    ```php
        $this->persistOutcome($row, [
            'status' => BaNotification::STATUS_SUPPRESSED,
            'suppress_reason' => mb_substr($reason, 0, 255),
            'last_attempt_at' => Carbon::now(),
            'updated_by' => BaActor::id(),
        ]);
    ```
  - **After:** (new private helper — add it immediately after `syncIncidentNotified()` ends at line 803, before the `// Internals` comment at line 805):
    ```php
        /**
         * Save a status change and re-derive ba_incidents.is_notified in ONE transaction, so the
         * two writes commit or roll back together (TXN-01, 2026-10-12).
         *
         * @param  array<string, mixed>  $attributes
         */
        private function persistOutcome(BaNotification $row, array $attributes): void
        {
            DB::transaction(function () use ($row, $attributes): void {
                $row->forceFill($attributes)->save();
                $this->syncIncidentNotified($row);
            });
        }
    ```
  - **Verify:** `grep -n "DB::transaction\|persistOutcome(" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php`
  - **Expect:** one `DB::transaction` line (inside `persistOutcome`) and six `persistOutcome(` lines (one declaration plus five calls).
  - **Effort:** M

- [ ] **BNC-03** · M · ERR-05 · `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php:47`, `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:726-729` — log the exception object, not its message.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php`, `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php`
  - **Before** (controller line 47):
    ```php
                Log::error('BaNotificationController::retry failed', ['id' => $row->id, 'error' => $e->getMessage()]);
    ```
  - **After:** (controller line 47):
    ```php
                report($e);
    ```
  - **Before** (service lines 726-729):
    ```php
                Log::warning('BA notification delivery failed', [
                    'ba_notification_id' => $row->id,
                    'error' => $e->getMessage(),
                ]);
    ```
  - **After:** (service lines 726-729):
    ```php
                Log::warning('BA notification delivery failed', [
                    'ba_notification_id' => $row->id,
                    'exception' => $e,
                ]);
    ```
  - **Verify:** `grep -n "error.*=>.*getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php Modules/BehaviouralAssessment/app/Services/BaNotificationService.php`
  - **Expect:** no output (the `$errors[] = $e->getMessage();` on service line 725 stays — it builds the stored failure reason, not a log).
  - **Effort:** S

## 4. Authorization (F3)

_None — the single `Gate::authorize` at `BaNotificationController.php:33` already runs before the record load and the exact permission is seeded._

## 5. Validation, routes, models, controller & service shape (F4/F5/F6/F7/F8)

- [ ] **BNC-05** · M · SVC-02 · `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:126,288,339,384` — inject `BaAssessmentService` instead of resolving it with `app()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php`
  - **Before** (constructor, line 126):
    ```php
        public function __construct(private NotificationService $delivery) {}
    ```
  - **After:** (constructor, line 126):
    ```php
        public function __construct(
            private NotificationService $delivery,
            private BaAssessmentService $assessments,
        ) {}
    ```
  - **Before** (line 288):
    ```php
            $config = app(BaAssessmentService::class)->configFor($assessment->period);
    ```
  - **After:** (line 288):
    ```php
            $config = $this->assessments->configFor($assessment->period);
    ```
  - **Before** (lines 339 and 384, identical):
    ```php
            $config = app(BaAssessmentService::class)->configFor($period);
    ```
  - **After:** (lines 339 and 384, identical):
    ```php
            $config = $this->assessments->configFor($period);
    ```
  - **Verify:** `grep -n "app(BaAssessmentService" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **BNC-10** · L · CTL-10 · `Modules/BehaviouralAssessment/app/Models/BaNotification.php:149-153` — delete the unused `scopePending()`.
  - **Touches:** `Modules/BehaviouralAssessment/app/Models/BaNotification.php`
  - **Before** (lines 149-153):
    ```php
        public function scopePending($query)
        {
            return $query->where('status', self::STATUS_PENDING);
        }
    }
    ```
  - **After:** (lines 149-153):
    ```php
    }
    ```
  - **Verify:** `grep -n "scopePending" Modules/BehaviouralAssessment/app/Models/BaNotification.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **BNC-04** · H · QRY-01 · `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php:935-945` — resolve guardian user ids in one query, not one per guardian.
  - **Touches:** `Modules/BehaviouralAssessment/app/Services/BaNotificationService.php`
  - **Before** (`resolveContacts`, parent case, lines 935-945):
    ```php
                $contacts = StudentGuardianJnt::where('student_id', $row->recipient_id)
                    ->where('can_receive_notifications', true)
                    ->with('guardian')
                    ->get()
                    ->map(fn ($jnt) => $jnt->guardian)
                    ->filter(fn ($g) => $g !== null && $g->is_active !== false)
                    ->map(fn ($g) => [
                        'user_id' => $g->user_id && User::whereKey($g->user_id)->exists() ? (int) $g->user_id : null,
                        'email' => $g->email ?: null,
                        'name' => trim(($g->first_name ?? '').' '.($g->last_name ?? '')),
                    ])->values()->all();
    ```
  - **After:** (`resolveContacts`, parent case, lines 935-945):
    ```php
                $guardians = StudentGuardianJnt::where('student_id', $row->recipient_id)
                    ->where('can_receive_notifications', true)
                    ->with('guardian')
                    ->get()
                    ->map(fn ($jnt) => $jnt->guardian)
                    ->filter(fn ($g) => $g !== null && $g->is_active !== false)
                    ->values();

                $validUserIds = User::whereIn('id', $guardians->pluck('user_id')->filter()->all())
                    ->pluck('id')
                    ->all();

                $contacts = $guardians->map(fn ($g) => [
                    'user_id' => $g->user_id && in_array((int) $g->user_id, $validUserIds, true) ? (int) $g->user_id : null,
                    'email' => $g->email ?: null,
                    'name' => trim(($g->first_name ?? '').' '.($g->last_name ?? '')),
                ])->values()->all();
    ```
  - **Verify:** `grep -n "User::whereKey" Modules/BehaviouralAssessment/app/Services/BaNotificationService.php`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

_None — this controller renders no view._

## 8. Style (F12) — one item per file

- [ ] **BNC-11** · L · STY-07 · `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php:53` — make the success flash true in sync mode.
  - **Touches:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php`
  - **Before** (line 53):
    ```php
            return $this->backToOutbox()->with('success', 'Notification #'.$row->id.' queued for another attempt.');
    ```
  - **After:** (line 53):
    ```php
            return $this->backToOutbox()->with('success', 'Notification #'.$row->id.' retry requested.');
    ```
  - **Verify:** `grep -n "queued for another attempt" Modules/BehaviouralAssessment/app/Http/Controllers/BaNotificationController.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **BNC-02** · M · DECISION · ERR-00 — the controller keeps its own `try/catch (Throwable)`; D1 forbids a controller catch. How far do we go?
  - **Why it is a decision:** removing the catch changes where failures are handled (central handler instead of a flash), and the service must then own the user-facing message. It is a behaviour choice, not a mechanical edit.
  - (a) ⭐ remove the broad catch; keep only `catch (\DomainException $e)` showing `$e->getMessage()`, and move the `BaTriggerError` mapping into `BaNotificationService::retry()` (which throws `\DomainException` with the trigger text). Touches the controller and the service. This is also what BNC-06 needs.
  - (b) keep the catch but narrow it to `catch (\DomainException $e)` only (no trigger mapping); any `QueryException` then becomes a 500 through the central handler.
  - (c) accept as is — record ERR-00 as an accepted deviation for this controller.
  - ➜ Choice: ____

- [ ] **BNC-06** · M · DECISION · SVC-04 — the retryable-status rule is written in the controller AND the service, and they disagree. Which copy wins?
  - **Why it is a decision:** it decides which class owns the rule, and any answer changes either the controller guard or the service branches (behaviour).
  - (a) ⭐ move the rule into `BaNotificationService::retry()` (throw `\DomainException('Only a failed or suppressed notification can be retried.')` for any other status) and delete the controller guard at lines 36-38; the controller then only catches and shows it. Pairs with BNC-02 option (a).
  - (b) keep the rule in the controller and delete the service's unreachable `pending`/`sent` special-casing (lines 659-667), leaving the service to reset and dispatch unconditionally.
  - (c) accept as is — the two copies stay, recorded as SVC-04 accepted.
  - ➜ Choice: ____

- [ ] **BNC-09** · M · DECISION · CTL-01 — split the 1,065-line `BaNotificationService`?
  - **Why it is a decision:** a split is a structural change deferred by D3 and it re-homes nine `evaluate*` methods plus the delivery half.
  - (a) ⭐ defer to the split pass (D3) — record the size and move on; nothing else here depends on it.
  - (b) extract the delivery half now (`attempt`, `suppress`, `syncIncidentNotified`, `resolveContacts`, `persistOutcome`) into a `BaNotificationDeliveryService` and keep the `evaluate*` obligations here.
  - (c) leave as is and record the size as accepted debt.
  - ➜ Choice: ____

- [ ] **BNC-12** · M · DECISION · TXN-06 — concurrent Retry clicks can revert a `sent` row and deliver twice. Lock or accept?
  - **Why it is a decision:** the fix adds a row lock and moves the dispatch outside the transaction (behaviour + a new failure mode to consider), so it needs a choice.
  - (a) ⭐ re-read the row with `lockForUpdate()` inside a transaction, re-check the status, and dispatch after the transaction commits.
  - (b) reset with a conditional update guarded on the expected status (`where('status', $expected)->update(...)`) and skip the dispatch when nothing was updated.
  - (c) accept — the double-send needs two overlapping submits; record TXN-06 as accepted.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| BNC-07 | Resolved by BNC-01: extracting `persistOutcome()` removes both outcome branches from `attempt()`, which drops the method below the 80-line CTL-02 threshold. No separate edit is needed. |
