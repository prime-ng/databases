# TeacherPortal — Module Audit Summary

**Protocol:** `.claude/rules/final-audit.md` §13.2 · **Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md`
**Audited:** 2026-10-14 · **By:** opencode · **Developer folder:** tarun
**Phase:** AUDIT. Read-only — no application code changed. Every report passed `_tools/selfcheck.py`.

All 3 controllers of `Modules/TeacherPortal` are audited (2 were pre-assigned in the main session;
none of the 10 module services, the FormRequest or the cross-module first-reaches was owned before).
One folder per controller holds `01-report.md` + `02-fix-plan.md`. Tick items in each plan, then run
`final-audit-fixer` on the path (developer `tarun`).

## 1. Per-controller results

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| TeacherPortalController | 871 | 1 | 3 | 4 | 6 | 2 | `routes/api.php` registers `apiResource('teacherportals')` for `index/store/show/update/destroy`, none of which exist → every `/api/v1/teacherportals` request 500s on a display-only module | [01](TeacherPortalController/01-report.md) |
| Mobile/MobileTeacherDashboardController | 211 | 0 | 4 | 6 | 3 | 4 | `substitutionsToday()` returns undecorated rows, so a cover lesson on the Substitutions tab renders with no period label and no clock time | [01](MobileTeacherDashboardController/01-report.md) |
| Mobile/MobileTeacherAttendanceController | 295 | 0 | 2 | 6 | 4 | 2 | leave approval upserts `std_student_attendance` with keys that omit `attendance_period`/wrong session → same-day row rolls back the review (SQLSTATE 23000 → 500) and a trashed row is updated invisibly | [01](MobileTeacherAttendanceController/01-report.md) |

## 2. Module totals

| B | H | M | L | DECISIONs | Findings |
|---|---|---|---|---|---|
| **1** | **9** | **16** | **13** | **8** | **39** |

**Blockers (B=1):** TeacherPortalController — TPC-08 (dead `apiResource` routes; fix is a route change → DECISION).

## 3. Cross-controller families (fix as one change)

1. **Hand-rolled access gate instead of a permission** (AUTH-01) — TPC-05, MTD-01, MTA-04. The web
   stack applies `role:Teacher`; the mobile routes rely only on a `sch_teachers` presence check. One
   module-wide decision (see §5).
2. **Controller `try/catch` + message-only logging** (ERR-00/D1, ERR-05) — TPC-01 (four methods),
   MTA-01 (`store()`, `review()`). Remove the catches; let `bootstrap/app.php` render (D1).
3. **Inline `$request->validate()` instead of Form Requests** (VAL-02) — TPC-07, MTA-05.
4. **Emoji/symbol comment markers** (STY-04) — TPC-14, MTD-13, MTA-10, MTA-11 (and the services they list).
5. **Missing transaction on a multi-write path** (TXN-01) — TPC-02 (balance not debited), TPC-03
   (`storeDocuments()` two writes), MTA-03 (`deleteLeaveType()` — owned by gaurav's report).
6. **Write path with no `activityLog`** (TXN-04) — MTA-02 (register save), unlike the module's review path.
7. **Repeated lookups not memoised / resolved with `app()`** (SVC-05, SVC-02) — TPC-12, MTA-07, MTD-10.

## 4. Shared classes and their owner reports

`final-audit-reports/_Info/00-CLASS-OWNERS.md`. Owned by **this run** (18 rows): `TeacherContext`,
`TeacherDashboardService`, `TeacherScheduleService` → MobileTeacherDashboardController;
`TeacherAttendanceService`, `TeacherStudentLeaveService` → MobileTeacherAttendanceController;
`ApplyLeaveRequest`, `TeacherClassesService`, `TeacherLeaveService`, `TeacherNotificationService`,
`TeacherProfileService`, `TeacherPtmService`, `SchoolSetup\Employee`, `SchoolSetup\EmployeeLeaveApplication`,
`SchoolSetup\StaffLeaveType`, `SchoolSetup\StaffLeaveService` → TeacherPortalController; `SchoolSetup\Teacher`,
`SchoolSetup\OrganizationAcademicSession`, `SchoolSetup\User` → MobileTeacherDashboardController.

**Linked to other reports:** `LeaveApplication`, `LeaveApplicationRemark`, `LeaveApplicationDocument`,
`LeaveType`, `Student`, `StudentAttendance`, `StudentProfile\Services\LeaveService` → gaurav's
StudentProfile reports; `TimetableFoundation\Models\Timetable` → TimetableFoundation/TimetableController;
`PublishedTimetable` → TimetableFoundation/TimetableFoundationController; `SnapshotContext` →
tarun/StandardTimetable/StandardTimetableController-done; `SubstitutionHistoryReader` →
tarun/SmartTimetable/SubstitutionController. `SchoolSetup\User::$fillable` exposes `is_super_admin`
(app-wide SEC-002) — recorded as a cross-cutting note, not fixed here.

⚠ **Two duplicate claims were reconciled 2026-10-14** by keeping the earlier claim: `Timetable.php`
(TimetableFoundation/TimetableController-done) and `StudentProfile\Services\LeaveService.php`
(gaurav/StudentProfile/StdLeaveController). The later reports (Dashboard, Attendance) now `↗ link`.

## 5. Module-wide decisions

1. **Portal access model** (TPC-05, MTD-01, MTA-04) — replace the hand-rolled `sch_teachers` presence
   check with the same `role:Teacher` gate the web stack uses, or accept the deviation. Edits route
   files → DECISION.
2. **`apiResource('teacherportals')`** (TPC-08) — the module is display-only; either add the five
   missing methods or remove the resource. Route change → DECISION.
3. **`dashboard()` is a 137-line method** (MTD-02) — split is **DEFERRED** (D3).

## 6. Not covered, and why

- **Transitive models reached only via `TeacherProfileService::for()` eager-loads** (EmployeeProfile,
  TeacherProfile, EmployeeAddress, EmployeeEmergencyContact, EmployeeBankDetail, EmployeeDocument,
  TeacherCapability, ClassSection, SubjectStudyFormat, StudyFormat, StaffLeaveConfig, LeaveApprovalPolicy,
  Holiday, EmployeeLeaveBalance, EmployeeLeaveApproval, EmployeeLeaveApplicationDoc,
  EmployeeLeaveApplicationRemark) — listed by the TeacherPortalController audit but **not audited and
  not registered**; they need their own owner (follow-up).
- **Runtime behaviour** — no browser/test run (D4); findings are static or read-only SQL probes.
- **The mobile client UI** — the JSON was inspected from `tinker` (SELECT only); the phone app was not run.

## 7. Status

- **Index:** all 3 rows `AUDITED` (`tarun/TeacherPortal-done/00-INDEX.md`).
- **Self-check:** every report prints `SELF-CHECK PASS`.
- **Not fixed:** read-only audit. Fixes wait on Tarun ticking `02-fix-plan.md` items and tarun running
  `final-audit-fixer`.
- **Blocked:** nothing.
