# Final Audit — TimetableFoundation / SchoolTimingProfileController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/SchoolTimingProfileController.php` (293 lines, 11 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 2 blockers, 2 HIGH.**

The worst finding is **STP-01**: the model this controller is built on —
`Modules\TimetableFoundation\Models\SchoolTimingProfile` — **does not exist**, and its table
`school_timing_profiles` is **absent from the tenant database**. Ten of the eleven routed
methods (`index`, `store`, `show`, `edit`, `update`, `destroy`, `trashedPeriod`, `restore`,
`forceDelete`, `toggleStatus`) fail on first use; only `create()` returns a view without
touching the model. Called via `trashedPeriod`, the controller also imports a second model,
`Modules\TimetableFoundation\Models\Period`, which is **also absent** (**STP-02**).

This answers the sibling question directly: this controller does **not** share
`TimingProfile`'s model — it has its own (`SchoolTimingProfile`) — but that model and table are
just as missing, and it adds a second one (`Period`). There is **no migration** for either
table and **no menu entry** for the feature: it is reachable only by typing the URL.

Beneath the blocker, the controller is the pre-2026-10-10 style: six methods carry `try/catch`
that log only `$e->getMessage()`, the JSON status switch swallows its own 422, responses are
built inside the transaction, and one status switch writes its audit log **before** the save.
The orphan-tables audit marks the companion `tt_timing_profile` **"Deprecate — functionality
absorbed into period sets"**, so the blocker is very likely a **retire** decision, not a rebuild.

Rough effort if retired: about 2 hours (route/permission/controller/request/policy/view
cleanup). If rebuilt: a day and a half (two models + migrations + all the F1/F2 fixes).
Three DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 2 | 2 | 9 | 6 | 3 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | STP-03, STP-04, STP-05 | F8 Services/Jobs | clean: no service, job, event (`grep -oE '[A-Z][A-Za-z]+(Request\|Policy\|Service\|Job\|Event…)' $C` → only `SchoolTimingProfileRequest`) |
| F2 Transactions/Audit | STP-06, STP-07 | F9 Queries/Perf | STP-16 |
| F3 Authorization | STP-08, STP-09 | F10 Views | STP-17 |
| F4 Validation | STP-10 | F11 Security/Tenancy | clean: no `env()`, no `?? 1`, no request body logged, tenant middleware present |
| F5 Routes | STP-11 | F12 Style | STP-15, STP-18, STP-19 |
| F6 Controller shape | STP-12, STP-13, STP-14 | F13 Deep read | STP-01, STP-02, STP-14 |
| F7 Models | STP-01, STP-02 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/SchoolTimingProfileController.php` | controller | 293 | this report | ✅ whole class |
| 2 | `app/Http/Requests/SchoolTimingProfileRequest.php` | FormRequest | 63 | this report | ✅ whole class |
| 3 | `app/Policies/SchoolTimingProfilePolicy.php` | policy | 43 | this report | ✅ — unreachable, see STP-09 |
| 4 | `routes/web.php` lines 353-357 | routes | — | this report | ✅ |
| 5 | `resources/views/school-timing-profile/index.blade.php` | page | 55 | this report | ✅ |
| 6 | `resources/views/school-timing-profile/create.blade.php` | page | 63 | this report | ✅ |
| 7 | `resources/views/school-timing-profile/edit.blade.php` | page | 62 | this report | ✅ |
| 8 | `resources/views/school-timing-profile/show.blade.php` | page | 47 | this report | ✅ |
| 9 | `resources/views/school-timing-profile/trash.blade.php` | page | 44 | this report | ✅ |
| — | `Modules\TimetableFoundation\Models\SchoolTimingProfile` | model | **missing** | — | ❌ class does not exist — STP-01 |
| — | table `school_timing_profiles` | table | **absent** | — | ❌ not in tenant DB, no migration — STP-01 |
| — | `Modules\TimetableFoundation\Models\Period` | model | **missing** | — | ❌ class does not exist — STP-02 |
| — | table `periods` | table | **absent** | — | ❌ not in tenant DB, no migration — STP-02 |
| — | `App\Traits\AuthorizesTenantFeature`, base `Controller`, `activityLog()`/`flash()` helpers, `x-backend.*` components, layout, `tenancy()` | common | — | common (§4.2) | referenced only; component props checked against constructors |

**Shared-class ownership (§5):** no in-scope class is reachable by another controller, so
**nothing was appended to `_Info/00-CLASS-OWNERS.md`**. `SchoolTimingProfileRequest`, the five
`school-timing-profile` blades and the policy are used only here; the policy is additionally
unregistered. The two models are absent and therefore not registrable. (`Modules/SmartTimetable/
database/seeders/PeriodSeeder.php` references a *different* FQCN, `Modules\SmartTimetable\Models\
\Period`, which is also absent — see §7.)

**Pre-applied 2026-10-10:** `SchoolTimingProfileController` is **not** listed in
`../PRE-APPLIED-2026-10-10.md`. No in-scope file was touched by that pass. The `try/catch`
pattern here is therefore *original*, not a regression of the pre-applied work.

## 4. Routes

```
GET|HEAD  timetable-foundation/school-timing-profile                                timetable-foundation.school-timing-profile.index       index
POST      timetable-foundation/school-timing-profile                                timetable-foundation.school-timing-profile.store       store
GET|HEAD  timetable-foundation/school-timing-profile/create                         timetable-foundation.school-timing-profile.create      create
GET|HEAD  timetable-foundation/school-timing-profile/trash/view                     timetable-foundation.school-timing-profile.trashed      trashedPeriod
DELETE    timetable-foundation/school-timing-profile/{id}/force-delete              timetable-foundation.school-timing-profile.forceDelete  forceDelete
GET|HEAD  timetable-foundation/school-timing-profile/{id}/restore                   timetable-foundation.school-timing-profile.restore      restore   ← GET
GET|HEAD  timetable-foundation/school-timing-profile/{school_timing_profile}        timetable-foundation.school-timing-profile.show        show
PUT|PATCH timetable-foundation/school-timing-profile/{school_timing_profile}        timetable-foundation.school-timing-profile.update      update
DELETE    timetable-foundation/school-timing-profile/{school_timing_profile}        timetable-foundation.school-timing-profile.destroy     destroy
GET|HEAD  timetable-foundation/school-timing-profile/{school_timing_profile}/edit   timetable-foundation.school-timing-profile.edit        edit
POST      timetable-foundation/school-timing-profile/{school_timing_profile}/toggle-status timetable-foundation.school-timing-profile.toggleStatus toggleStatus
```

Middleware on every route (`RouteServiceProvider::mapWebRoutes`, lines 45-56):
`web, InitializeTenancyByDomain, PreventAccessFromCentralDomains, EnsureTenantIsActive,
EnsureTenantHasModule:TimetableFoundation, auth, verified` — tenant middleware present ✅ (RTE-05).

**Unrouted public methods:** none — all 11 public methods are routed ✅ (RTE-03).
**Route order (RTE-06, note not a finding):** the custom `trash/view`, `{id}/restore`,
`{id}/force-delete`, `{school_timing_profile}/toggle-status` routes are declared **after**
`Route::resource('school-timing-profile', …)` at `routes/web.php:353-357`. This is currently
benign: every custom path differs from a resource path by segment count or a literal segment,
so none is captured today. Recorded so it stays true when a new sub-route is added.
**Route-model binding:** `show`/`edit` bind `{school_timing_profile}` implicitly (Laravel
snake-cases `$schoolTimingProfile` → `school_timing_profile`); `update`/`destroy` bind
`$school_timing_profile` directly. `restore`/`forceDelete` use `{id}` + `findOrFail` (STP-13).

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — | STP-01 |
| create | ✅ | create | — | — | — | STP-17 |
| store | ✅ | create (+ request) | ✅ closure | `Stored` | school_timing_profiles, sys_activity_logs | STP-01, 04, 07, 08, 12, 14 |
| show | ✅ | view | — | — | — | STP-01 |
| edit | ✅ | update | — | — | — | STP-01 |
| update | ✅ | update (+ request) | ✅ closure | `Updated` | school_timing_profiles, sys_activity_logs | STP-01, 04, 07, 08, 10, 12, 14 |
| destroy | ✅ | delete | ✅ closure | `Trashed` | school_timing_profiles, sys_activity_logs | STP-01, 04, 07, 12, 14 |
| trashedPeriod | ✅ | restore | — | — | reads school_timing_profiles + periods | STP-01, 02, 16 |
| restore | ✅ | restore | ✅ closure | `Restored` | school_timing_profiles, sys_activity_logs | STP-01, 04, 07, 11, 13 |
| forceDelete | ✅ | forceDelete | ✅ closure | `Deleted` | school_timing_profiles, sys_activity_logs | STP-01, 04, 07, 13 |
| toggleStatus | ✅ | update | ✅ closure | `Toggled` | school_timing_profiles, sys_activity_logs | STP-01, 03, 04, 05, 06, 07 |

**Tables each mutation SHOULD touch** (`controller-alignment.md` §0.1): every mutation writes
the profile row **plus** its activity-log row — `school_timing_profiles` + the tenant activity
log `sys_activity_logs` (`Modules\GlobalMaster\Models\ActivityLog`, `$table = 'sys_activity_logs'`).
Both fits inside one transaction, so TXN-01 is satisfied by shape — but `school_timing_profiles`
does not exist, so the write never lands (STP-01). No other table should be touched. There is no
service; every transaction lives in the controller.

## 6. Findings

### F7 — Models
#### STP-01 · B · MDL-07 / RTE-02 · deep read — the controller's model class and its table do not exist
**Where:** `SchoolTimingProfileController.php:17` (import), `:27`, `:49`, `:75`, `:84`, `:93`, `:147`, `:183`, `:194`, `:224`, `:249`; request `:33-34`
```php
17: use Modules\TimetableFoundation\Models\SchoolTimingProfile;
27: $schoolTimingProfiles = SchoolTimingProfile::paginate(10);
49: $schoolTimingProfile = SchoolTimingProfile::create($request->validated());
```
**Evidence:**
- `find . -name 'SchoolTimingProfile.php' -not -path '*/vendor/*'` → **no file**.
- `grep -rn "class SchoolTimingProfile" Modules app` → only `SchoolTimingProfilePolicy`,
  `SchoolTimingProfileRequest`, `SchoolTimingProfileController`, `SchoolTimingProfileSeeder` — no model.
- `class_exists(Modules\TimetableFoundation\Models\SchoolTimingProfile::class)` → **`bool(false)`**.
- Tenant probe: `SHOW TABLES` → `school_timing_profiles` = **NO**; `sch_academic_term` = **Y**
  (so tenancy is correct); `tt_timing_profile`, `tt_school_timing_profile` = **NO** too.
- `grep -rln "school_timing_profiles" database/ Modules/` → only the FormRequest and the
  SmartTimetable seeder; **no migration**. There is no `Schema::create` for `periods` either.
- No `glb_menus` row references `school-timing-profile` (below), and `grep -rn
  "school-timing-profile" Modules/*/resources/views resources/views` finds only self-references.
  The feature is **not linked from any menu or page**.

**Consequence:** `GET /timetable-foundation/school-timing-profile` — and every create/save/edit/
delete/restore/status action — crashes with `Error: Class "Modules\TimetableFoundation\Models\
\SchoolTimingProfile" not found` (HTTP 500); even `store` fails earlier because the FormRequest's
`unique:school_timing_profiles,…` rule queries a table that does not exist (SQL 1146).

#### STP-02 · B · MDL-07 · deep read — a second missing model, `Period`, used by the trash page
**Where:** `SchoolTimingProfileController.php:16` (import), `:184`
```php
16: use Modules\TimetableFoundation\Models\Period;
184: $periods = Period::onlyTrashed()->paginate(10);
```
**Evidence:**
- `class_exists(Modules\TimetableFoundation\Models\Period::class)` → **`bool(false)`**.
- `ls Modules/TimetableFoundation/app/Models/` → no `Period.php` (only `PeriodSet`, `PeriodSetPeriod`,
  `PeriodType`, `PeriodConfig`).
- `grep -rn "class Period" Modules app` → no `Modules\TimetableFoundation\Models\Period` anywhere.
- Tenant probe: table `periods` = **NO** (`tt_period_types`, `tt_period_configs`, `tt_period_sets`
  are the pluralised tables that do exist, but the model resolves to `periods`).

**Consequence:** once STP-01 is fixed, `GET /timetable-foundation/school-timing-profile/trash/view`
still crashes with `Class "…\Models\Period" not found` — the trash page is a page-killer for a
second, unrelated reason. Sequenced immediately after STP-01 in the plan.

### F1 — Errors
#### STP-03 · H · ERR-02 · validation — `toggleStatus` runs `validate()` inside the `try`, so the generic catch swallows the 422
**Where:** `SchoolTimingProfileController.php:253-257` and `:286-289`
```php
253: try {
254:     return DB::transaction(function () use ($request, $school_timing_profile) {
255:         $request->validate([
256:             'is_active' => 'required|boolean',
257:         ]);
…
286: } catch (\Throwable $e) {
287:     Log::error('SchoolTimingProfileController::toggleStatus failed', ['error' => $e->getMessage()]);
289:     return back()->with('error', 'The operation could not be completed.');
```
**Evidence:** scanner row `ERR-02 · H · toggleStatus — validate/validateWithBag inside try; generic
catch swallows ValidationException`; read confirms the catch is `\Throwable` and does not rethrow.
**Consequence:** a bad `is_active` payload produces a 302 redirect with a generic banner instead of
a 422 with the field error, so the AJAX status switch silently fails to explain itself.

#### STP-04 · M · ERR-00 (D1) + ERR-05 · errors — six methods try/catch themselves and log only the message
**Where:** `store:47-69` · `update:98-140` · `destroy:151-174` · `restore:192-215` · `forceDelete:222-245` · `toggleStatus:253-290`
```php
65: } catch (\Throwable $e) {
66:     Log::error('SchoolTimingProfileController::store failed', ['error' => $e->getMessage()]);
68:     return back()->with('error', 'The operation could not be completed.');
```
**Evidence:** under settled D1 (ERR-00 = the Laravel idiom) a controller try/catch is a finding.
All six catches log only `$e->getMessage()` (ERR-05 loses the trace) instead of `report($e)`; the
central handler in `bootstrap/app.php` (`withExceptions`, lines 83-131) already renders and logs.
The `catch (ModelNotFoundException) { throw $e; }` guards are dead weight: they only re-throw what
the generic `\Throwable` catch would have caught anyway, and they do not protect the `findOrFail()`
calls in `restore`/`forceDelete`. Scanner: `ERR-05 · M` ×6. The pre-applied 2026-10-10 pass
converted sibling controllers to `return DB::transaction(fn …)` with no try/catch; this one was missed.
**Consequence:** a stack trace is lost on every failure, the controller carries two error models,
and each catch is a place to get ERR-01/02/04 wrong — STP-03 and STP-05 are exactly that.

#### STP-05 · M · ERR-04 · errors — `toggleStatus` returns JSON on success but a redirect in its catch
**Where:** `SchoolTimingProfileController.php:268-278` (JSON) vs `:286-289` (`back()`)
**Evidence:** scanner `ERR-04 · M · toggleStatus() returns both JSON and redirects with no expectsJson() branch`.
**Consequence:** the AJAX status switch receives a JSON body when it works and an HTML/redirect
when it fails, so the caller's `success:false` branch never runs on a server error.

### F2 — Transactions/Audit
#### STP-06 · M · TXN-04 + deep read — `toggleStatus` logs the change **before** the save
**Where:** `SchoolTimingProfileController.php:259-267`
```php
259: $newStatus = $request->input('is_active');
260: $school_timing_profile->is_active = $newStatus;
264: activityLog($school_timing_profile, 'Toggled', ['message' => 'A new school timing profile status was updated.', …]);
267: if ($school_timing_profile->save()) {
```
**Evidence:** the property is set at `:260`, `activityLog()` runs at `:264`, and `save()` happens at
`:267` — the log describes a write that has not happened yet. (The other five mutations log **after**
the write, correctly.)
**Consequence:** if the save fails, the audit trail already claims the status was toggled, so the log
lies about an event that never occurred.

#### STP-07 · M · TXN-05 · transactions — the redirect/response is built inside the `DB::transaction` closure
**Where:** `store:56-58` · `update:128-130` · `destroy:161-163` · `restore:202-204` · `forceDelete:232-234` · `toggleStatus:268-278`
```php
56: return redirect()
57:     ->route('timetable-foundation.index')
58:     ->with('success', flash('created.school-timing-profile'));
```
**Evidence:** scanner `TXN-05 · M` on all six (`store:56`, `update:128`, `destroy:161`, `restore:202`,
`forceDelete:232`, `toggleStatus:268`); the `redirect()` and the session flash are created inside the
closure, before the commit.
**Consequence:** if the commit fails after the flash is written, the next page shows
"… was created successfully." for a row that does not exist.

### F3 — Authorization
#### STP-08 · L · AUTH-04 · authorization — `store`/`update` authorize the same permission twice
**Where:** controller `:45`, `:95` and `SchoolTimingProfileRequest::authorize()` (`:51`)
```php
// controller                                     // request
45: Gate::authorize('…school-timing-profile.create');   51: return $this->authorizeByCrudPermission('tenant.timetable-foundation.school-timing-profile');
95: Gate::authorize('…school-timing-profile.update');
```
**Evidence:** the FormRequest runs first (`Gate::allows('…create'|'…update')`) and then the controller
calls `Gate::authorize('…create'|'…update')` for the same name. Scanner `AUTH-04 · L` on both.
**Consequence:** no functional loss, but two places to keep in step. Keep the FormRequest (it runs
first), drop the duplicate `Gate::authorize` in `store`/`update`.

#### STP-09 · L · AUTH-06 / AUTH-01 · authorization — `SchoolTimingProfilePolicy` is dead code that looks active
**Where:** `app/Policies/SchoolTimingProfilePolicy.php` (43 lines)
**Evidence:** `grep -n "SchoolTimingProfilePolicy" Modules/TimetableFoundation/app/Providers/TimetableFoundationServiceProvider.php`
→ **no match** (the sibling policies are registered at `:120-140`; this one is absent, and cannot be
registered while its model is missing). Even if registered, every gate passes a permission **string**,
so the policy would never be consulted — the module-wide pattern other reports recorded.
**Consequence:** a reader believes record-level policy checks exist; in fact only the string gates
guard these methods.

### F4 — Validation
#### STP-10 · M · VAL-03 · validation — `rules()` dereferences a route parameter that is absent on `store`
**Where:** `SchoolTimingProfileRequest.php:30`
```php
30: $id = $this->route('school_timing_profile')->id ?? null;
```
**Evidence:** on `POST /school-timing-profile` the route has **no** `{school_timing_profile}`
segment, so `$this->route('school_timing_profile')` is `null` and `null->id` emits
"Attempt to read property 'id' on null". On `update` the bound model is present, so it works there.
The `?? null` suppresses an undefined key but not the null property read. `rules()` also has no
`: array` return type.
**Consequence:** a warning is emitted on every create submission; the same pattern is fragile if the
parameter is ever renamed. Use `$this->route('school_timing_profile')?->id`.

### F5 — Routes
#### STP-11 · H · RTE-01 · routes — Restore runs over a GET request
**Where:** `routes/web.php:355`
```php
Route::get('/school-timing-profile/{id}/restore', [SchoolTimingProfileController::class, 'restore'])->name('school-timing-profile.restore');
```
**Evidence:** `route:list` shows `GET|HEAD …/{id}/restore`; scanner `RTE-01 · H · restore`. The only
caller is `trash.blade.php:26` via `<x-backend.table.action-trashed>`, which derives the HTTP verb
from the route itself, so changing the verb needs no blade edit.
**Consequence:** GET has no CSRF protection, so a link preview or browser prefetcher can restore a
trashed profile.

### F6 — Controller shape
#### STP-12 · M · CTL-05 · shape — the transaction + two-catch + redirect block is copy-pasted six times
**Where:** `store:47-69`, `update:98-140`, `destroy:151-174`, `restore:192-215`, `forceDelete:222-245`, `toggleStatus:253-290`
**Evidence:** the same `try { DB::transaction(fn …) } catch (ModelNotFoundException) { throw } catch
(\Throwable) { Log::error(…getMessage()…); return back()… }` shape appears verbatim in all six; even
the comment "Rule A1: a missing record must stay a 404…" is duplicated. `grep -c 'catch (ModelNotFoundException'`
→ 6.
**Consequence:** a fix to one block misses the other five — which is how STP-03 and STP-05 exist only
in `toggleStatus`. Removing the catches (STP-04) collapses the duplication as a side effect.

#### STP-13 · M · CTL-03 · shape — `restore`/`forceDelete` use `$id` + `findOrFail` instead of route-model binding
**Where:** `SchoolTimingProfileController.php:188, :194` and `:218, :224`
```php
188: public function restore($id) { … $schoolTimingProfile = SchoolTimingProfile::onlyTrashed()->findOrFail($id); }
218: public function forceDelete($id) { … $schoolTimingProfile = SchoolTimingProfile::withTrashed()->findOrFail($id); }
```
**Evidence:** scanner `CTL-03 · M` on both. The routes declare `{id}`; the trashed lookups need
`->withTrashed()` binding, which these methods implement by hand rather than via the route.
**Consequence:** the 404 logic is duplicated and the route parameter and method argument can drift.
(Depends on STP-01: binding cannot be resolved until the model exists.)

#### STP-14 · M · deep read / CTL-05 · shape — `store`/`update`/`destroy` return to the module dashboard, not the list
**Where:** `SchoolTimingProfileController.php:57`, `:129`, `:162`
```php
57: ->route('timetable-foundation.index')
129: ->route('timetable-foundation.index')
162: ->route('timetable-foundation.index')
```
**Evidence:** `route:list` resolves `timetable-foundation.index` to
`TimetableFoundationController@index` (the module landing page), whereas the list is
`timetable-foundation.school-timing-profile.index`. `restore`/`forceDelete` correctly return to
`.trashed`.
**Consequence:** after creating, saving or trashing a profile the user is dropped on the Timetable
Foundation dashboard and cannot see the result of the action they just took.

### F9 — Queries/Performance
#### STP-16 · M · CTL-10 / QRY-13 · queries — `trashedPeriod` runs a second paginated query the view never uses
**Where:** `SchoolTimingProfileController.php:183-185` and `trash.blade.php` (whole file)
```php
183: $schoolTimingProfiles = SchoolTimingProfile::onlyTrashed()->paginate(10);
184: $periods = Period::onlyTrashed()->paginate(10);
185: return view('timetablefoundation::school-timing-profile.trash', compact('schoolTimingProfiles','periods'));
```
**Evidence:** `trash.blade.php` reads only `$schoolTimingProfiles`; `$periods` is passed but never
used. Both paginators share the default page name `page` (QRY-13: distinct `pageName` per list).
**Consequence:** an extra query (over a model that does not exist — STP-02) runs on every trash-page
load, and the two paginators would fight over `?page=` if `$periods` ever rendered.

### F12 — Style
#### STP-15 · L · CTL-04 / STY-01 / STY-02 · style — no return types, no `strict_types`, imports split by blank lines
**Where:** controller `:1`, `:24-291`; request `:1`; policy `:1`
**Evidence:** scanner `CTL-04 · L` ×11 (every public method), `STY-01 · L` ×3 (controller, request,
policy). The controller imports are separated by blank lines and unsorted (`:5-17`); `update()`'s
body is indented at column 0 while its signature sits at column 0 too (`:94-141`). Effort: S.

#### STP-17 · L · DECISION · VIEW / modal-standard / breadcrumb-standard — create is a full page and breadcrumbs carry no trail
**Where:** `create.blade.php` (4 controls) · `index/edit/show/trash` (`<x-backend.components.breadcrum … :links="[]" />`)
**Evidence:** `modal-standard.md` §2.5 — a create form with **15 or fewer** controls is a modal;
this one has 4. Every breadcrumb passes `:links="[]"`, so no trail is resolved.
**Consequence:** inconsistent with the module's other create modals, and the user gets no navigable
breadcrumb trail. (If the feature is retired per STP-01 this is moot.)

#### STP-18 · L · CTL-10 / STY-04 · dead code — a commented-out `rules()` block in the FormRequest
**Where:** `SchoolTimingProfileRequest.php:15-26`
```php
15: // public function rules(): array
16: // {
17: //     //Azad i have changes here sch_school_id to id
…
```
**Evidence:** a 12-line commented-out block (>3 lines) containing a stale second `rules()` that uses
`$this->route('school_timing_profiles')` (wrong param) and would seed a wrong unique rule for the next
copy-paste.
**Consequence:** a reader cannot tell which `rules()` is current.

#### STP-19 · L · STY / copy — toast text reads "School-timing-profile"
**Where:** `SchoolTimingProfileController.php:58`, `:163`
**Evidence:** `flash()` (`app/Helpers/helpers.php:11`) replaces underscores with spaces, not hyphens;
`flash('created.school-timing-profile')` → "School-timing-profile was created successfully.", and
`flash('trashed.school-timing-profile')` likewise. The other three keys
(`force_deleted.school_timing_profile`, `status_updated.school_timing_profile`,
`status_switch_failed.school_timing_profile`) already use underscores and render correctly.
**Consequence:** two of five toasts show a hyphenated resource name.

**Clean checks (one line each):**
- **F3 authorization surfaces:** every routed method calls `Gate::authorize` with
  `tenant.timetable-foundation.school-timing-profile.{action}`; the same base is in
  `SchoolTimingProfileRequest::authorize()`, the views (`@can`/`permission=`), and
  `config/permissionslist.php:700`. All 7 keys are **seeded** (`sys_permissions`, exact-name query:
  create, delete, forceDelete, restore, update, view, viewAny) — clean (AUTH-01/02).
- **F4 input writes:** `store` and `update` persist `$request->validated()`; no `$request->all()` /
  `except()` into a model. The one inline `validate()` is a single-field AJAX toggle, within the
  VAL-02 exception — clean (VAL-01/02).
- **F11 security/tenancy:** no `env()`, no hard-coded id/`?? 1`, no request body logged; tenant
  middleware present — clean.
- **F8 services/jobs:** no service, job, event, mail or notification referenced — clean.
- **F1 message leak (ERR-01):** no `$e->getMessage()` reaches `with()`/`withErrors`/`json()`/`back()`;
  catches return fixed strings — clean (ERR-01 not present).
- **F9 N+1:** no query inside a loop, no `::all()`; both lists `paginate(10)` — clean apart from STP-16.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **Sibling `TimingProfileController`:** its report (TPR-01) found `TimingProfile` and table
  `tt_timing_profile` absent. This controller has **its own** missing model (`SchoolTimingProfile`)
  and **adds** a second (`Period`). Both features are the same class of leftover; fixing them
  together avoids a second audit cycle. Neither has a `glb_menus` entry.
- **Seeder references another missing model:** `Modules/SmartTimetable/database/seeders/
  SchoolTimingProfileSeeder.php:18` inserts into `school_timing_profiles` (table absent), and
  `PeriodSeeder.php:6` uses `Modules\SmartTimetable\Models\Period` (model absent). Any
  `db:seed` for these would fatal. Registered in
  `SmartTimetableDatabaseSeeder.php:25`, so a full seed run reaches it.
- **Historical DDL:** `pgdatabase/8-Team_Work/Sameer/DB_Scema_Data/scema_tenant_db.sql:2993`
  shows the old `school_timing_profiles` table (with `deleted_at`), created by migration
  `2025_11_05_132119_create_school_timing_profile_table` — neither the migration nor the table is
  in the current codebase or tenant DB.
- **Unreachable policies (module-wide):** as in the `AcademicTermController` report, every policy
  is unreachable because gates pass strings. Module-level decision, not this report's.
- **Team tests reference this controller:** `Modules/TimetableFoundation/tests/Unit/
  ControllerAuthTest.php:95,163`, `PolicyTest.php:85`, `FormRequestValidationTest.php:28,63,132`.
  They will interact with any STP-01/STP-09 change; they are not edited here (D4).

## 8. Not covered, and why

- **Runtime behaviour:** no browser run and no tests (D4). Every finding is static or a read-only
  SQL / `SHOW TABLES` / `class_exists` probe.
- **The retire-vs-rebuild decision:** the orphan-tables audit
  (`pgdatabase/8-Team_Work/Tarun/4-Prompt_Output_Old/SmartTimetable_DDL_Audit_2026-03-17/
  04_Orphan_Tables_In_Migrations.md:19`) marks `tt_timing_profile` "Deprecate — functionality
  absorbed into period sets". Whether to delete this feature is a product decision (STP-01), not
  something this audit can settle.
- **The `Period` model's intended table:** if the feature is rebuilt, the correct table
  (`periods` vs one of the live `tt_period_*` tables) is a design question the DDL must answer.
- **Writing/repairing data:** none attempted; this pass is read-only.
