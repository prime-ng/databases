# Fix Plan — TimetableFoundation / SchoolTimingProfileController

**From:** `01-report.md` (2026-10-10) · **Applied by:** `final-audit-fixer`

> **How to approve**
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick.
> 4. Run the fixer on `Modules/TimetableFoundation/app/Http/Controllers/SchoolTimingProfileController.php`. It applies **only** ticked items, in this order.
> 5. ⚠ A migration is **written**, never run, by the fixer. You run `php artisan tenants:migrate` afterwards.

> **Read this first.** STP-01 is a retire-vs-rebuild decision. If you choose **retire**, most items
> below become moot (the routes, controller, request, policy, views and the seven permission keys go
> away together). If you choose **rebuild**, work items 1→10 in order.

## 1. Blockers reachable today
- [ ] **STP-01** · B · DECISION · MDL-07 / RTE-02 — `SchoolTimingProfile` model and `school_timing_profiles` table do not exist; all 10 model-touching methods 500.
      (a) ⭐ **Retire the feature.** Delete/short-circuit: remove the 11 routes (`routes/web.php:353-357`), the `create`/`index` blades, and the `create` Menu link if any; leave the controller/request/policy as dead code or delete them in the same pass. Confirm the companion `tt_timing_profile` (sibling `TimingProfileController`, TPR-01) is retired or rebuilt at the same time. No migration.
      (b) **Rebuild.** Write an additive tenant migration creating `school_timing_profiles` (columns per the old DDL in `pgdatabase/.../scema_tenant_db.sql:2993`: `id, profile_name, short_name, description, is_active, deleted_at, timestamps`) **and** a `Models\SchoolTimingProfile` model. ⚠ SHARED — a new model is reachable by the seeder; register it in `_Info/00-CLASS-OWNERS.md`. The migration is written, not run, by the fixer.
      ➜ Choice: ____

## 2. Fixes that arm a latent defect (sequenced)
- [ ] **STP-02** · B · MDL-07 · `SchoolTimingProfileController.php:16,184` — the trash page also fatals on a second missing model. Sequenced **after** STP-01.
      (a) If STP-01(a) retire → part of that cleanup.
      (b) If STP-01(b) rebuild → create `Models\Period` (and its migration/table), or, if `$periods` is genuinely unused, delete the `$periods` query (STP-16) instead of building a model. Effort: S if the query is dropped.
      ➜ Choice: ____

## 3. Errors & transactions (F1/F2)
- [ ] **STP-03** · H · ERR-02 · `SchoolTimingProfileController.php:255` — move the `$request->validate([...])` in `toggleStatus` **outside** the `try` (or into a FormRequest), so a bad payload raises a 422 instead of being swallowed by the `\Throwable` catch. Effort: S.
- [ ] **STP-04** · M · ERR-00 / ERR-05 · `SchoolTimingProfileController.php:47-69, 98-140, 151-174, 192-215, 222-245, 253-290` — remove the try/catch from `store`, `update`, `destroy`, `restore`, `forceDelete`, `toggleStatus`:
  - **Shape:** `return DB::transaction(fn …)`; let the central handler in `bootstrap/app.php` log and render. Any future business-rule message uses `\DomainException` (D2). Effort: M.
  - This also removes the six duplicated blocks and their dead `catch (ModelNotFoundException)` guards (STP-12).
- [ ] **STP-05** · M · ERR-04 · `SchoolTimingProfileController.php:286-289` — if STP-04 is applied this catch disappears. If any catch is kept, branch on `$request->expectsJson()` so the AJAX switch gets JSON on failure too. Effort: S.
- [ ] **STP-06** · M · TXN-04 · `SchoolTimingProfileController.php:264,267` — move `activityLog(..., 'Toggled', …)` to **after** `$school_timing_profile->save()` (inside the transaction), matching the other five mutations. Effort: S.
- [ ] **STP-07** · M · TXN-05 · `SchoolTimingProfileController.php:56,128,161,202,232,268` — build each `redirect()`/`response()` **after** the transaction closure returns the model, so no success flash is written before the commit. Effort: M.

## 4. Authorization (F3)
- [ ] **STP-08** · L · AUTH-04 · `SchoolTimingProfileController.php:45,95` — drop the duplicate `Gate::authorize` in `store`/`update`; keep the FormRequest `authorize()` (it runs first). Effort: S.
- [ ] **STP-09** · L · AUTH-06 / AUTH-01 · `app/Policies/SchoolTimingProfilePolicy.php` — the policy is unregistered and unreachable (gates pass strings). Module-wide question, not fixed here; recorded so it is not mistaken for active. If STP-01(b) rebuild is chosen, either register it or delete it. No edit in this pass.

## 5. Validation, routes, models (F4/F5/F7)
- [ ] **STP-10** · M · VAL-03 · `SchoolTimingProfileRequest.php:30` — use `$this->route('school_timing_profile')?->id`, so `store` (no route param) stops emitting a null-property warning; add `: array` to `rules()`. Effort: S.
- [ ] **STP-11** · H · DECISION · RTE-01 · `routes/web.php:355` — Restore runs over GET.
      (a) ⭐ Change it to `Route::patch` (or `DELETE`). `x-backend.table.action-trashed` derives the verb from the route, so no blade edit is needed; the only caller is `trash.blade.php:26`. ⚠ SHARED — a route change needs explicit approval.
      (b) Leave it as GET and accept the risk.
      ➜ Choice: ____
- [ ] **STP-13** · M · CTL-03 · `SchoolTimingProfileController.php:188,218` + `routes/web.php:355-356` — replace `$id` + `findOrFail` with route-model binding (`{school_timing_profile}` + `->withTrashed()->findOrFail()` or a scoped binding). ⚠ SHARED — touches the route file; depends on STP-01. Effort: S.

## 6. Queries & performance (F9)
- [ ] **STP-16** · M · CTL-10 / QRY-13 · `SchoolTimingProfileController.php:183-185` — drop the unused `$periods` query from `trashedPeriod()` (the view never reads it); if it is ever restored, give each paginator a distinct `pageName`. Effort: S.

## 7. Behaviour (F13)
- [ ] **STP-14** · M · deep read / CTL-05 · `SchoolTimingProfileController.php:57,129,162` — redirect to `timetable-foundation.school-timing-profile.index` (the list) instead of `timetable-foundation.index` (the module dashboard), so the user sees the result of the action. Effort: S.

## 8. Views (F10)
- [ ] **STP-17** · L · DECISION · modal-standard / breadcrumb-standard — `create.blade.php` is a full page with 4 controls (≤15 → modal), and all five breadcrumbs pass `:links="[]"`.
      (a) ⭐ Convert `create` to a modal (matching the module's other mocks) and resolve the breadcrumb trail.
      (b) Leave as is; accept the inconsistency.
      (c) Moot if STP-01(a) retire is chosen.
      ➜ Choice: ____

## 9. Style (F12) — one item per file
- [ ] **STP-15a** · L · CTL-04 / STY-01/02 · `SchoolTimingProfileController.php` — return types on all 11 methods, `declare(strict_types=1)`, sort the imports, and fix the `update()` body indentation (`:94-141`). Effort: S.
- [ ] **STP-15b** · L · STY-01 / CTL-10 · `SchoolTimingProfileRequest.php` — add `declare(strict_types=1)` **and** delete the commented-out `rules()` block at `:15-26` (STP-18). Effort: S.
- [ ] **STP-19** · L · STY / copy · `SchoolTimingProfileController.php:58,163` — change `.school-timing-profile` to `.school_timing_profile` in the `created`/`trashed` `flash()` keys so toasts read "School Timing Profile …". Effort: S.
- [ ] **STP-15c** · L · STY-01 · `SchoolTimingProfilePolicy.php` — add `declare(strict_types=1)`. Effort: S. (Skip if STP-01(a) deletes the policy.)

## 10. Deferred / decisions
- [ ] **STP-01** / **STP-02** / **STP-11** / **STP-17** — see §1, §2, §5, §8. These carry the `➜ Choice:` boxes.
- **Deferred (D3):** no god-controller split needed — 293 lines, 11 methods, all under the CTL-01/CTL-02 thresholds.
- **Waiting on another report:** the sibling `TimingProfileController` (TPR-01) retire-vs-rebuild decision should be taken together with STP-01.
