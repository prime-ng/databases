# Final Audit — TimetableFoundation / TeacherAvailabilityController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/TeacherAvailabilityController.php` (533 lines, 1 public method)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 3 HIGH, 6 MEDIUM, 6 LOW.**

This is a generation-only controller: one method, `generateTeacherAvailability()`, that truncates
`tt_teacher_availabilities` (and every later pipeline table) and rebuilds it from active Requirement
Consolidations. There is no CRUD, no FormRequest, and no rendered view.

Three things make it risky to ship. First (**TAV-10**), the rebuild still runs one
`TeacherCapability` query *per requirement* inside the outer loop — **662 queries on this tenant,
~1,324 including the eager load** — while the in-code comment claims "well under a hundred". That is
the same N+1 class that caused the 30-second timeout on 2026-09-03. Second (**TAV-01**), the
per-teacher `catch (\Throwable)` inside the write loop swallows failures and lets the enclosing
transaction commit a partially-built table — a catch shape D2 does not allow. Third (**TAV-06**), the
single method is 476 lines, so the truncate/transaction interplay is invisible to review.

The worst finding is **TAV-10**: every Generate click issues hundreds of redundant queries.

The effort is roughly one day: the query prefetch is the only real code change; the rest is a small
catch/log reshape, one batch insert, a view gate and style. Five DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 3 | 6 | 6 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TAV-01, TAV-02 | F8 Services/Jobs | TAV-09 |
| F2 Transactions/Audit | TAV-03 | F9 Queries/Perf | TAV-10, TAV-11 |
| F3 Authorization | TAV-04 | F10 Views | clean — no view rendered (`grep -n "view(" $C` → none) |
| F4 Validation | clean — no user input; no FormRequest needed | F11 Security/Tenancy | clean — no `env()`, no interpolated raw SQL, no secrets logged |
| F5 Routes | TAV-05 | F12 Style | TAV-12, TAV-13 |
| F6 Controller shape | TAV-06, TAV-07, TAV-08 | F13 Deep read | TAV-14, TAV-15 |
| F7 Models | clean — `TeacherAvailability` fillable/casts/table/SoftDeletes all correct; relations resolve in tinker | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/TeacherAvailabilityController.php` | controller | 533 | this report | ✅ whole class |
| 2 | `app/Models/TeacherAvailability.php` | model | 230 | this report (pre-assigned) | ✅ whole class |
| 3 | `app/Services/OptionStaffingService.php` | service | 95 | this report (pre-assigned) | ✅ whole class |
| 4 | `app/Support/Snapshot/SnapshotProtectionException.php` | support exception | 13 | this report (claimed — unclaimed & reachable) | ✅ whole class |
| 5 | `app/Models/RequirementConsolidation.php` | model | — | [RequirementConsolidationController](../RequirementConsolidationController-done/01-report.md) | ↗ linked — usage checked (`withoutTrashed`, read columns all exist) |
| 6 | `app/Models/TeacherAssignmentRole.php` | model | — | [TeacherAssignmentRoleController](../TeacherAssignmentRoleController-done/01-report.md) | ↗ linked — usage checked (`updateOrCreate` inside tx) |
| 7 | `app/Services/RequirementTableTruncator.php` | service | — | [RequirementConsolidationController](../RequirementConsolidationController-done/01-report.md) | ↗ linked — usage checked (`truncateFrom('teacher_availability')`, outside tx, documented) |
| 8 | `routes/web.php` line 265 | route | — | this report | ✅ |
| — | `Modules/SchoolSetup/Models/TeacherCapability.php` | model (other module) | — | common (§4.2) | ❌ different-module model — usage checked only; §7 cross-cutting note |
| — | `views/.../timetable-requirement/teacher-availability/_list.blade.php` (caller) | blade (other controller) | — | TimetableFoundationController's screen | ❌ not rendered by this controller; the ungated button is a cross-cutting note (§7) |

**Pre-applied 2026-10-10.** This controller is listed in `../PRE-APPLIED-2026-10-10.md`: the raw
exception text was removed and `$firstErrors[]` now reads `"capability #{id} (requirement #{id})"`
instead of the exception message. This audit reviewed that result fresh and it is **correct** — see
the F1 note. Nothing was re-applied or reverted.

## 4. Routes

```
POST      timetable-foundation/teacher-availability/generate   timetable-foundation.teacher-availability.generateSlotRequirement   Modules\TimetableFoundation\Http\Controllers\TeacherAvailabilityController@generateTeacherAvailability
```

Middleware on the route: `web, Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,
Stancl\Tenancy\Middleware\InitializeTenancyByDomain, App\Http\Middleware\EnsureTenantIsActive,
App\Http\Middleware\EnsureTenantHasModule:TimetableFoundation, Illuminate\Auth\Middleware\Authenticate,
Illuminate\Auth\Middleware\EnsureEmailIsVerified`.

**Unrouted public methods:** none (1 public method, 1 route — RTE-03 ✅).

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| generateTeacherAvailability | ✅ POST | `tenant.timetable-foundation.teacher-availability.generate` | ✅ `DB::transaction` closure at line 108; TRUNCATE at 106 is intentionally **outside** (DDL) | `Generated` (line 470, **outside** the tx) | truncates `tt_teacher_availabilities` + downstream; writes `tt_teacher_availabilities`, `tt_teacher_assignment_roles`, `sys_activity_logs` | TAV-01..15 |

**Tables each mutation SHOULD touch:** `tt_teacher_availabilities` (rebuild), `tt_teacher_assignment_roles`
(the two canonical-role upserts), `sys_activity_logs` (activityLog), plus the truncator's downstream
tables. The transaction covers roles + availability + the two set-based UPDATEs; the log and the
TRUNCATE sit outside it — the log is the finding (TAV-03); the TRUNCATE is the sanctioned D2 shape.

## 6. Findings

### F1 — Errors

#### TAV-01 · H · ERR-06 (+ ERR-00/D2) — the per-teacher catch swallows write failures and lets the transaction commit a partial table
**Where:** `TeacherAvailabilityController.php:366-378`
```php
} catch (\Throwable $e) {
    $errorCount++;
    if (count($firstErrors) < 3) {
        // Name the row, not the raw exception — it can be SQL
        // (ERR-01, 2026-10-10). The full error is logged below.
        $firstErrors[] = "capability #{$capability->id} (requirement #{$requirement->id})";
    }
    Log::error('Teacher availability generation failed for capability', [
        'capability_id' => $capability->id,
        'requirement_id' => $requirement->id,
        'error' => $e->getMessage(),
    ]);
}
```
**Evidence:** `grep -n "catch" Modules/TimetableFoundation/app/Http/Controllers/TeacherAvailabilityController.php` → two catches, line 366 (inner) and line 509 (outer). D2 allows only `\DomainException`, the truncate-then-rebuild fixed message, `SnapshotProtectionException` verbatim, and (in services) `report($e)` + fixed message. This inner catch is none of those, and it catches `\Throwable` — which includes `RuntimeException`/`QueryException`, explicitly banned by D2.
**Consequence:** a genuine write failure mid-rebuild (deadlock, dropped connection, a bad column value) is swallowed; the loop continues and the enclosing `DB::transaction` commits every row that did succeed, so the table is silently incomplete while the run is reported as merely "with N errors".

Note (compliant): the **outer** catch at line 509 is the D2 truncate-then-rebuild shape — `report($e)`,
a fixed "…now empty. The error has been logged." message, and the `SnapshotProtectionException` branch
whose message D2 shows verbatim. The scanner's `ERR-01` hit at `:516` is a **confirmed false positive**
(it is the D2-sanctioned `SnapshotProtectionException` message, guarded by `instanceof`).

#### TAV-02 · M · ERR-05 — the log records the message, not the exception
**Where:** `TeacherAvailabilityController.php:373-377`
```php
Log::error('Teacher availability generation failed for capability', [
    'capability_id' => $capability->id,
    'requirement_id' => $requirement->id,
    'error' => $e->getMessage(),
]);
```
**Evidence:** guard against the §12 trap "a grep hit inside a comment": `grep -n "getMessage" …` → line 376 is live code, not the `166`-style context comment. The rule wants the object (`['exception' => $e]` or `report($e)`).
**Consequence:** the stack trace and chained `$previous` are lost, so a production failure in the generation loop cannot be traced back to the SQL or the failing model.

### F2 — Transactions/Audit

#### TAV-03 · M · TXN-04 — `activityLog()` sits outside the transaction
**Where:** `TeacherAvailabilityController.php:464-475`
```php
});                        // ← DB::transaction closes here
activityLog(auth()->user(), 'Generated', [
    'message' => "Teacher availability was generated ({$createdCount} assigned).",
```
**Evidence:** `grep -n "activityLog\|DB::transaction" …` → transaction opens at 108, closes at 464; the log call is at 470. `app/Helpers/activityLog.php:35-39` shows it writes a `sys_activity_logs` row, so it is a second-table write. Rule A3/TXN-04 require it **inside** the transaction, after the write it describes.
**Consequence:** if the log insert fails, the rebuild is already committed but the run leaves no audit trail; the outer catch then reports the (now false) "tables are now empty" message (see TAV-14).

### F3 — Authorization

#### TAV-04 · M · AUTH-01 (view surface) — the Generate button is not gated on `.generate`
**Where:** `views/pages/partials/timetable-requirement/teacher-availability/_list.blade.php:47-48`
```blade
@if(Route::has('timetable-foundation.teacher-availability.generateSlotRequirement'))
    <form action="{{ route('timetable-foundation.teacher-availability.generateSlotRequirement') }}" method="POST" class="d-inline"
```
**Evidence:** the containing tab is gated on `.viewAny` (`timetable-requirement.blade.php:80`), but the form uses only `Route::has` — `grep -rn "teacher-availability.generate" --include=*.blade.php .` finds no `@can`. The permission itself is sound: `config/permissionslist.php:693` declares `'timetable-foundation.teacher-availability' => array_merge($crud, ['generate', 'export'])`; the tenant has permission id 1563 `tenant.timetable-foundation.teacher-availability.generate`, granted to 2 roles (ids 1, 2).
**Consequence:** a user with `.viewAny` but without `.generate` sees the destructive "Generate from Requirements" button and gets a 403 only after clicking it. Not a security hole (the controller gate holds), but a four-surface inconsistency. The fix touches another controller's partial — recorded ⚠ SHARED.

### F4 — Validation

clean — the method takes no user input and writes no request data; it authorizes before loading anything (`Gate::authorize` at `:59`, records loaded at `:83`). No FormRequest is required for a zero-input POST. `grep -n "\$request->" …` → only `wantsJson()`.

### F5 — Routes

#### TAV-05 · L · STY / CTL-05 (copy-paste) — the route name misdescribes the action
**Where:** `routes/web.php:265`
```php
Route::post('/teacher-availability/generate', [TeacherAvailabilityController::class, 'generateTeacherAvailability'])->name('teacher-availability.generateSlotRequirement');
```
**Evidence:** the name `generateSlotRequirement` is copied verbatim from the sibling `slot-requirement.generateSlotRequirement` (`routes/web.php:301`). It names the wrong resource in every log, every `route()` call and every test.
**Consequence:** developers grep for a route name that describes a different table; the mistake is cosmetic but permanent once referenced by tests. Rename is ⚠ SHARED (route file + caller + two Dusk tests).

Route checks that pass: state change is POST not GET; the route points at an existing method; the single public method is routed; tenant + auth + verified middleware are present (RTE-02/03/05 ✅).

### F6 — Controller shape

#### TAV-06 · H · CTL-02 — the single method is 476 lines
**Where:** `TeacherAvailabilityController.php:57-532`
**Evidence:** `php -r` scanner → `CTL-02 H L57 generateTeacherAvailability() is 476 lines`; rulebook thresholds: over 150 lines is **H**.
**Consequence:** the truncate-before-transaction contract, the buffered insert and the two set-based UPDATEs are all in one body; a reviewer or a future edit cannot see the ordering hazards, which is exactly how the 2026-09-03 timeout recurred.

#### TAV-07 · M · CTL-06 — the generation algorithm lives in the controller
**Where:** `:108-464` (the whole rebuild)
**Evidence:** only two responsibilities are extracted (`RequirementTableTruncator` at `:106`, `OptionStaffingService` at `:485`); the candidate selection, buffering, flush and score arithmetic are inline.
**Consequence:** the algorithm cannot be reused by the scheduler or tested without an HTTP request; `OptionStaffingService` proves the extraction pattern already exists here.

#### TAV-08 · L · CTL-04 — no return type on the public method
**Where:** `:57` `public function generateTeacherAvailability(Request $request)` — returns `JsonResponse|RedirectResponse`.
**Evidence:** `grep -nE 'public function' …` → no `: Type` suffix (the class does carry `declare(strict_types=1)` at `:3`).
**Consequence:** callers and static analysis cannot see the response contract.

Other CTL checks: no `request()` helper (✅ injected `Request`), no `compact()`/`extract()`, no `dd()`/`dump()` (CTL-09 ✅), no dead private methods (CTL-10 ✅).

### F7 — Models

clean — `Modules/TimetableFoundation/app/Models/TeacherAvailability.php`: `$fillable` declared (`:39-83`, nothing sensitive); `$casts` cover every boolean/date/decimal column (`:91-131`); `$table = 'tt_teacher_availabilities'` exists (`SHOW CREATE TABLE` returned it, with `deleted_at`); `SoftDeletes` present and correct; all 7 relations are return-typed and resolve — proven in tinker on row id 1:
`requirementConsolidation=1, class=4, section=1, subjectStudyFormat=1, teacherProfile=59, preferredShift=1, activity=null`.

### F8 — Services and jobs

#### TAV-09 · M · SVC-02 — services are resolved with `app()` mid-method instead of constructor injection
**Where:** `:106` `app(RequirementTableTruncator::class)->truncateFrom('teacher_availability');` and `:485` `$staffing = app(OptionStaffingService::class);`
**Evidence:** `grep -n "app(" …` → the two sites above. The controller declares no `__construct`.
**Consequence:** the service dependencies are hidden from the container and from the method signature; both classes are stateless and trivial to inject.

`OptionStaffingService` itself is clean: no HTTP/session/redirect, no writes (read-only query), one implementation, called once per run (`SVC-01/03/04` ✅).

### F9 — Queries and performance

#### TAV-10 · H · QRY-01 (+ QRY-05) — a `TeacherCapability` query runs once per requirement (N+1)
**Where:** `TeacherAvailabilityController.php:210-250`
```php
foreach ($requirements as $requirement) {
    ...
    $eligibleTeachers = TeacherCapability::query()
        ->where('class_id', $requirement->class_id)
        ->whereIn('subject_study_format_id', $capabilitySsfIds)
        ...
        ->with('teacherProfile')
        ->get()
        ->sortByDesc(fn ($c) => [(int) $c->is_primary_subject, (int) ($c->proficiency_percentage ?? 0)])
        ->unique('teacher_profile_id')
        ->values();
```
**Evidence:**
- scanner: `QRY-01 H L217 TeacherCapability::query() inside a loop — N+1 query`.
- tenant probe (`tinker`): `active_reqs=662`. The loop body therefore runs **662** times, each issuing a `TeacherCapability` `SELECT` plus the `teacherProfile` eager-load `SELECT` ⇒ **≈1,324 queries per Generate**, before the two set-based UPDATEs.
- the in-code comment at `:157` claims this scaffolding "replace[s] ~72,000 queries with **well under a hundred**"; that is **false**: the per-requirement query is not one of the three optimisations listed. The flagged `->get()->sortByDesc()` (`QRY-05`) is the per-requirement sort/unique that SQL can do.

**Consequence:** every Generate click hammers the DB with ~1,300 round-trips on a school of this size, scaling linearly with the number of requirements — exactly the trap that timed out at PHP's 30-second web limit on 2026-09-03 and left the table empty.

#### TAV-11 · L · QRY-07 — the no-eligible-teacher fallback inserts one row at a time
**Where:** `:252-261`
```php
if ($eligibleTeachers->isEmpty()) {
    TeacherAvailability::create([ ... 'teacher_profile_id' => null, ... ]);
    $skippedCount++;
```
**Evidence:** scanner `QRY-07 M L253`. Severity **lowered to L**: it fires at most once per requirement and only for the (rare) requirement with no capable teacher — it is **not** the per-row hot path. `TT_teacher_availabilities` has no incoming FK (`information_schema.KEY_COLUMN_USAGE` → `incoming_fks=0`) and the unique key `uq_ta_requirement_teacher` allows repeated `NULL` teacher ids, so the row can safely join `$pending`.
**Consequence:** negligible today; folding it into the buffer keeps the "one insert path" contract.

Query checks that pass: no interpolated raw SQL — the two `DB::statement` blocks (`:401`, `:439`) are constant strings (QRY-11 ✅); the `tt_shifts` lookup is plucked once (`:162`); the two aggregates are set-based SQL, not `->get()->groupBy()`.

### F10 — Views

clean — the controller renders no Blade (`grep -nE "view\(|@include|@can" …` → none); it returns JSON or a redirect. (The caller partial's missing gate is a cross-cutting note, §7.)

### F11 — Security and tenancy

clean — no `env()` outside `config/` (`grep -n "env(" …` → none); the raw SQL carries no interpolation (QRY-11); the log context contains ids and an error message only — no request bodies, passwords or tokens; no central model is reached (all tables are tenant-local). Note for the record: `@set_time_limit(0)` at `:72-74` removes the web execution cap for this request, which is the acknowledged trade-off behind TAV-06/TAV-10.

### F12 — Style

#### TAV-12 · L · STY-04 — emoji markers in comments
**Where:** `TeacherAvailabilityController.php:61,68,102,238,275,284,308,323,327,396` (⚠ / ⛔ at ten sites)
**Evidence:** scanner `STY-04 L` at those lines; rulebook STY-04 bans emoji markers in comments.
**Consequence:** cosmetic; conflicts with the Pint/English-comment standard. One item per file.

#### TAV-13 · L · STY-01 — missing `declare(strict_types=1)`
**Where:** `OptionStaffingService.php:1-3` (`<?php` + blank line + `namespace`), `SnapshotProtectionException.php:1-3`
**Evidence:** scanner `STY-01 L L1` for both files. The controller and `TeacherAvailability` already declare it.
**Consequence:** loose typing on the service boundary; one item per file.

### F13 — Deep read

#### TAV-14 · M · deep read #7 — the failure message can assert tables are empty when they are not
**Where:** `TeacherAvailabilityController.php:509-531`
```php
} catch (\Throwable $e) {
    report($e);
    ...
    return response()->json([
        'success' => false,
        'message' => 'Generation failed after this tab and all later tabs were cleared, so they are now empty. The error has been logged.',
    ], 422);
```
**Evidence:** the truncate runs at `:106`; the reads/calls that can throw **before** it are the requirements query (`:83`) and, **after** a successful rebuild, `activityLog` (`:470`) and `OptionStaffingService` (`:485`). Only the `SnapshotProtectionException` branch (`:515`) is guarded for the "nothing was truncated" case.
**Consequence:** a failure in the requirements query (no truncate yet) or in the post-build staffing check (tables freshly rebuilt) tells the admin the tabs are **empty** when they are not — a false statement that drives a needless, destructive re-run.

#### TAV-15 · L · TXN-06 — the truncate + rebuild has no lock
**Where:** `:106` (TRUNCATE) then `:108` (`DB::transaction`)
**Evidence:** nothing serialises two concurrent `POST …/generate` requests; the truncator's stage list includes `tt_timetable_cells`, so a second request can truncate mid-rebuild of the first. The caller's `data-swal-confirm` discourages a double-click but does not prevent two admins.
**Consequence:** low likelihood, but two overlapping runs can interleave a TRUNCATE with another run's inserts and commit a mixed table. Report only.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`TeacherCapability` (SchoolSetup module)** — a different-module model, therefore **common** under
  `final-audit.md` §4.2 (this controller is not the first to reach it), so it is **not** claimed in
  `_Info/00-CLASS-OWNERS.md` and not audited here. Usage is correct: the queried columns exist
  (`class_id, subject_study_format_id, is_active, effective_from, effective_to, teacher_profile_id`
  and the `teacherProfile` relation), and the casts line up. Its only scanner hit is `STY-01`
  (no `strict_types`).
- **The Generate button's view surface (`timetable-requirement/teacher-availability/_list.blade.php`)**
  belongs to **TimetableFoundationController**'s screen, not this controller. The missing `@can`
  (TAV-04) should be fixed there, or claimed by that report; it is recorded here because it is the
  view surface of *this* controller's permission.
- **`RequirementTableTruncator` / `RequirementConsolidation` / `TeacherAssignmentRole`** are owned by
  other reports (see §3); only this controller's usage was checked. `truncateFrom('teacher_availability')`
  intentionally empties every downstream stage — documented at the call site and in the service.

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static reading, the scanner, or a
  read-only SQL/tinker probe.
- **The Dusk tests** (`tests/Browser/.../TtTeacherAvailabilityTest.php`, `.../ResourceAvailability/...`)
  pin the current route name and the JSON `message`; they were read only as evidence for TAV-05/TAV-14.
  They are not edited (D4).
- **Data repair:** none proposed. The `max_allocated_periods_weekly`/`min_allocated_periods_weekly`
  fallback (the documented `max_periods_daily ?? 6` / `?? 1` derivation) is left exactly as the code
  comment describes — changing it is a product decision, not this audit's.
- **Concurrent writers of `tt_teacher_availabilities`:** seeders/importers were not audited; TAV-15's
  race concerns only this route.
