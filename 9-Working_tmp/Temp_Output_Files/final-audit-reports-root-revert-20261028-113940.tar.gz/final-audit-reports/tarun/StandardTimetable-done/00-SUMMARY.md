# StandardTimetable — Module Audit Summary

**Protocol:** `.claude/rules/final-audit.md` §13.2 · **Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md`
**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Phase:** AUDIT. Read-only — no application code changed. The report passed `_tools/selfcheck.py`.

The module has **one** top-level controller (the manual-placement / timetable-grid god controller).
One folder holds `01-report.md` + `02-fix-plan.md`. Tick items, then run `final-audit-fixer` on the path.

## 1. Results

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| StandardTimetableController | 4,950 | 2 | 4 | 10 | 8 | 6 | STT-01 — 15 mutating endpoints return the raw exception text (SQL, table and column names) to the browser on any write failure; none of the 19 catches calls `report()` | [01](StandardTimetableController-done/01-report.md) |

## 2. Module totals

| B | H | M | L | DECISIONs |
|---|---|---|---|---|
| **2** | **4** | **10** | **8** | **6** |

**Blockers (B=2):** STT-01 (raw `$e->getMessage()` on every write path) and STT-07 (the module's
`Route::apiResource` points at `store`/`show`/`update`/`destroy`, which do not exist → guaranteed 500s).

## 3. Families inside this controller (fix as one change each)

1. **Raw exception text to the user** (ERR-01) — 15 mutating endpoints; the fix is one helper/pattern
   across the controller plus `report($e)` (ERR-05) in the 19 catches.
2. **Dead API routes** (RTE-02, B) — the scaffold `apiResource` targets non-existent methods.
3. **Manual transactions + N+1 in the service** (TXN-02, QRY-01/07) — `ManualTimetableService` uses
   `beginTransaction`/`commit` and `DB::table()` inside loops (`placeCell`, `copyTimetable`).
4. **Missing transactions / misplaced `activityLog`** in multi-write methods (F2).
5. **God controller** — 4,950 lines / 27 methods is CTL-01 H; the split is a **DEFERRED** decision (D3).
6. **Style** — emoji comments and missing `declare(strict_types=1)` across the module's requests,
   service, policy and providers (one F12 item per file).

## 4. Shared classes and ownership

`final-audit-reports/_Info/00-CLASS-OWNERS.md`:
- Owned by this report: `ManualTimetableService`, `StandardTimetablePolicy`, the 5 FormRequests
  (used only here → not registered), and the newly claimed
  `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php`.
- Linked (owned by the `tarun/TimetableFoundation` reports): `Timetable`/`TimetableCell`,
  `AcademicTerm`, `Activity`/`ActivityTeacher`/`SubActivity`, `ClassTimetableType`, `PeriodSet`,
  `SchoolDay`, `TimetableType`.
- Common (§4.2, referenced only): SchoolSetup `ClassSection`, `Room`, `Teacher`, `TeacherProfile`.

## 5. Module-wide decisions

1. **God-controller split** (CTL-01) — deferred to the split pass (D3).
2. **`snapshot.readonly` / `snapshot.read` middleware** gating the grid mutations — confirm the
   snapshot lock semantics with the TimetableFoundation snapshot owner.

## 6. Not covered, and why

- **Runtime behaviour** — no browser/test run (D4); every finding is static or a read-only SQL probe.
- **TimetableFoundation models** — audited by their own reports; this report only checks this
  controller's use of them.

## 7. Status

- **Index:** 1 row `AUDITED` (`tarun/StandardTimetable/00-INDEX.md`).
- **Self-check:** `SELF-CHECK PASS — 24 findings, 18 plan items, every field present.`
- **Not fixed:** read-only audit. Fixes wait on Tarun ticking `02-fix-plan.md` and tarun running
  `final-audit-fixer`.
