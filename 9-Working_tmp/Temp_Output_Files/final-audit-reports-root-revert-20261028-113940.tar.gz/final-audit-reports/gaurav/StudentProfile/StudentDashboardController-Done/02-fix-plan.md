# Fix Plan — StudentProfile / StudentDashboardController

**From:** `01-report.md` (2026-10-10) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/StudentProfile/database/migrations/` (any file) | Never edit an existing migration; a new additive migration is written only if the SDB-01 DECISION is ticked, and it is **never run** — running `php artisan tenants:migrate` is Tarun's hand |
| `Modules/StudentProfile/routes/web.php` | route file — no item here changes routing |
| `resources/views/components/backend/**` and `Modules/Dashboard/resources/views/components/stat-card-icon.blade.php` | shared components (§4.2) — owned by no single report |
| `config/permissionslist.php` | shared config — no new permission is needed |
| Classes owned by other reports (`_Info/00-CLASS-OWNERS.md`) | this controller reaches none, and none are touched |

## 1. Blockers reachable today

None — there is no B-severity finding in `01-report.md`.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

No separate item — finding **SDB-03** (ERR-07, swallowed errors in `safeCount()`) is fixed by item **SDB-02** in §6 below, because both changes are the same 15-line method and must be replaced atomically. See plan §10.

## 4. Authorization (F3)

None — the permission exists, is exact-seeded, and is enforced first thing in `index()`.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **SDB-04** · L · CTL-04 · `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php:14` — give `index()` its return type.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php`
  - **Before** (`StudentDashboardController.php:14`):
    ```php
        public function index()
    ```
  - **After:**
    ```php
        public function index(): \Illuminate\Contracts\View\View
    ```
  - **Verify:** `grep -n "public function index" Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php`
  - **Expect:** `14:    public function index(): \Illuminate\Contracts\View\View`
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **SDB-02** · M · QRY-12 / ERR-07 · `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php:33-47` — memoise the per-request counts in `safeCount()` and stop swallowing DB errors (this atomic replacement also closes finding SDB-03).
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php`
  - **Why it is one change:** the memoisation cache and the removal of the `try/catch` (SDB-03) are both edits to the same 15-line `safeCount()` method; applying them as two separate items would make the second item's Before block stale. The replacement below does both.
  - **Before** — the import block (`StudentDashboardController.php:7-10`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\DB;
    use Carbon\Carbon;
    ```
  - **After:** — the import block:
    ```php
    use App\Http\Controllers\Controller;
    use Carbon\Carbon;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Schema;
    ```
  - **Before** — the method (`StudentDashboardController.php:33-47`):
    ```php
        private function safeCount(string $table, array $conditions = []): int
        {
            try {
                $query = DB::table($table);
                if (\Illuminate\Support\Facades\Schema::hasColumn($table, 'deleted_at')) {
                    $query->whereNull('deleted_at');
                }
                foreach ($conditions as $col => $val) {
                    $query->where($col, $val);
                }
                return (int) $query->count();
            } catch (\Exception $e) {
                return 0;
            }
        }
    ```
  - **After:** — the method (complete, paste-ready):
    ```php
        /** @var array<string, int> */
        private array $countCache = [];

        private function safeCount(string $table, array $conditions = []): int
        {
            $key = $table.'|'.json_encode($conditions);
            if (isset($this->countCache[$key])) {
                return $this->countCache[$key];
            }

            $query = DB::table($table);
            if (Schema::hasColumn($table, 'deleted_at')) {
                $query->whereNull('deleted_at');
            }
            foreach ($conditions as $col => $val) {
                $query->where($col, $val);
            }

            return $this->countCache[$key] = (int) $query->count();
        }
    ```
  - **Verify:** `grep -n "countCache\|catch (" Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php`
  - **Expect:** three `countCache` lines and no `catch (` line in the controller.
  - **Effort:** S

## 7. Views (F10)

None — the blade is clean and compiles.

## 8. Style (F12) — one item per file

- [ ] **SDB-05** · L · STY-02 · `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php` — make the file Pint-clean.
  - **Touches:** `Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php`
  - **Before** (`StudentDashboardController.php:7-10` — current state; the same four lines before Pint):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\DB;
    use Carbon\Carbon;
    ```
  - **After:** run `vendor/bin/pint Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php --format agent` — it sorts the imports, imports `Schema`, de-aligns the multi-assignment blocks and adds the blank line before `return` in `safeCount()`. The expected post-Pint import block (the fixers measured were `fully_qualified_strict_types`, `blank_line_before_statement`, `ordered_imports`, `binary_operator_spaces`):
    ```php
    use App\Http\Controllers\Controller;
    use Carbon\Carbon;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Schema;
    ```
  - **Verify:** `vendor/bin/pint --test Modules/StudentProfile/app/Http/Controllers/StudentDashboardController.php`
  - **Expect:** `{"tool":"pint","result":"passed"}`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **SDB-01** · H · DECISION · QRY-14 — make the attendance stats useable: index `std_student_attendance.attendance_date` and stop wrapping it in `DATE()`.
  - **Why it is a decision:** the fix needs an **additive migration** (new index) that the fixer writes but Tarun runs (`php artisan tenants:migrate`); it also changes two SQL clauses in a query the school admin sees on login.
  - (a) ⭐ **Range queries + additive index** — in `buildAttendanceStats()` replace both `->whereDate('attendance_date', Carbon::today())` with `->where('attendance_date', '>=', Carbon::today()->startOfDay())->where('attendance_date', '<', Carbon::today()->addDay()->startOfDay())`, and write a **new additive migration** `Modules/StudentProfile/database/migrations/<date>_add_index_attendance_date_to_std_student_attendance_table.php` containing `Schema::table('std_student_attendance', function (Blueprint $table) { $table->index('attendance_date', 'idx_std_att_date'); });` — the migration is never run by the fixer. Result: the two today counts drop from `type=index rows=99160` to a range on a leading-key index.
  - (b) **Range queries only, no migration** — the code stops wrapping in `DATE()`, but with no leading-key index MySQL still full-scans until someone adds the index separately (EXPLAIN stays `type=index`).
  - (c) **Defer** — record as accepted performance debt and revisit in the post-launch sprint.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| SDB-03 | Fixed by item SDB-02 in §6 — the swallowed-error catch and the memoisation are both inside the same 15-line `safeCount()` method, and the item's After block replaces the method once, removing the `catch (\Exception $e) { return 0; }` and adding the cache in the same atomic edit. A separate item would give the fixer a stale Before block. |