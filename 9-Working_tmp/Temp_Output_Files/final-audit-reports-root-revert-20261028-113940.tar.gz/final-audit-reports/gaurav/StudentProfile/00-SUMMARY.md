# StudentProfile — Module Audit Summary

**Protocol:** `.claude/rules/final-audit.md` §13.2 · **Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md`
**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** gaurav
**Phase:** AUDIT. Read-only — no application code changed. Every report passed `_tools/selfcheck.py`.

All 8 top-level controllers of `Modules/StudentProfile` are audited. One folder per controller holds
`01-report.md` + `02-fix-plan.md`. Tick items in each plan, then run `final-audit-fixer` on the path.

## 1. Per-controller results

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| StudentController | 5,500 | 4 | 7 | 22 | 10 | 3 | STC-23 — 3 media models lack `getMediaModel()`; uploads land in the central DB | [01](StudentController-done/01-report.md) |
| AttendanceController | 454 | 1 | 1 | 13 | 4 | 6 | ATD-01 — all three write paths return the raw `$e->getMessage()` to the user | [01](AttendanceController-done/01-report.md) |
| StdLeaveController | 419 | 1 | 6 | 8 | 4 | 4 | SLV-11 — `LeaveApplicationDocument` has no `getMediaModel()`; leave docs leak to central DB | [01](StdLeaveController-done/01-report.md) |
| MedicalIncidentController | 339 | 2 | 5 | 9 | 4 | 4 | `index()` 500s (partial needs `$incidentsExport`, never passed); media leaks to central DB | [01](MedicalIncidentController-done/01-report.md) |
| StudentDashboardController | 277 | 0 | 1 | 2 | 2 | 1 | attendance stats full-scan the 99,334-row `std_student_attendance` table 4× per render | [01](StudentDashboardController-done/01-report.md) |
| StudentReportController | 223 | 1 | 2 | 5 | 3 | 3 | SRP-08 — `Student` media to central DB; plus ~1,825 queries/page in the chronic-absenteeism queue | [01](StudentReportController-done/01-report.md) |
| StudentLeaveTypeController | 179 | 0 | 2 | 2 | 6 | 3 | SLT-01 — writes and their `activityLog` row commit separately (no transaction) | [01](StudentLeaveTypeController-done/01-report.md) |
| StudentProfileController | 70 | 1 | 3 | 1 | 4 | 1 | SPR-06 — `StudentProfile` uses `InteractsWithMedia` without `getMediaModel()` (central-DB leak) | [01](StudentProfileController-NotUsed/01-report.md) |

## 2. Module totals

| B | H | M | L | DECISIONs |
|---|---|---|---|---|
| **10** | **27** | **62** | **37** | **25** |

**Blockers (B=10):** StudentController ×4, AttendanceController, StdLeaveController,
MedicalIncidentController ×2, StudentReportController, StudentProfileController. Every one is a
page-killer or a cross-tenant data leak on a reachable screen.

## 3. Cross-controller families (fix as one change)

1. **Spatie media without `getMediaModel()` → media rows written to the CENTRAL database** (MDL-05 /
   TEN-01). The dominant family: `StudentProfile`, `Student`, `MedicalIncident`,
   `LeaveApplicationDocument`, and three more models in `StudentController`. Every affected model
   needs the same `getMediaModel()` override → `App\Models\TenantMedia`. One module-wide fix.
2. **Raw exception text to the user** (ERR-01) — `AttendanceController` returns `$e->getMessage()`
   on all three write paths; check every controller's flash/`withErrors`/JSON strings.
3. **Media/DDL and schema drift** — models over tables whose columns/relations disagree with the
   controller (several `Student*` models); several unreachable routes and missing views cause 500s.
4. **N+1 / unbounded reads** (QRY-01/02) — `StudentReportController` (~1,825 queries/page),
   `StudentDashboardController` (4× 99k-row scans), `StudentController` list/export paths.
5. **Missing transactions / misplaced `activityLog`** (TXN-01/04) — `StudentLeaveTypeController` and
   the multi-write blocks inside `StudentController` and `AttendanceController`.
6. **Unreachable Policies** — every module Policy is dead code because gates pass permission
   strings; one module-level decision fixes all of them.
7. **God controller** — `StudentController` (5,500 lines / many methods) is CTL-01 H; the split is a
   DEFERRED decision (D3), not applied in this pass.

## 4. Shared classes and their owner reports

`final-audit-reports/_Info/00-CLASS-OWNERS.md` is the registry (pre-assigned by the main session before
batch 1). Owners: `Student` + `StudentAnalyticsService` → StudentReportController; `StudentProfile` →
StudentProfileController; `LeaveType`/`LeaveTypePolicy`/`StudentLeaveTypeRequest` →
StudentLeaveTypeController; `MedicalIncident`/`MedicalIncidentPolicy` → MedicalIncidentController;
`LeaveApplication`/`LeaveApplicationDocument`/`LeaveApplicationRemark`/`LeaveApplicationPolicy`/
`LeaveService` → StdLeaveController; `StudentAttendance`/`AttendanceService`/`AttendancePolicy` →
AttendanceController; the `Guardian*`/`StudentAddress`/`StudentAcademicSession`/`StudentDocument`/
`StudentGuardianJnt`/`StudentHealthProfile`/`StudentOptedSubject`/`PreviousEducation`/
`StudentAttendanceCorrection`/`VaccinationRecord`/`StudentPolicy`/`StudentDocumentPolicy`/
`PrintIdCardsRequest` and 5 helper classes (`StudentImport`, `StudentReadOnly`, `StudentsExport`,
`StudentLoginCreated`, `StudentProfileHelper`) → StudentController. No duplicate claims.

## 5. Module-wide decisions (need one answer, then apply everywhere)

1. **`getMediaModel()` override** — add it to every tenant media model (the 7+ flagged). One pattern,
   many files.
2. **Unreachable policies** — decide whether to bind them (Gate/Policy) or document them as intended.
3. **Dropdown/settings caching** — several controllers re-query the same lookups every request
   (caching is a DECISION item, keyed by tenant id).

## 6. Not covered, and why

- **Mobile API controllers** — `Modules/StudentProfile/app/Http/Controllers/Mobile/AttendanceController.php`
  (256 lines) and `.../Mobile/AdminStudentLeaveController.php` (309 lines) were **out of scope**:
  module mode lists `Controllers/*.php` (top level) per `final-audit.md` §13.1 step 1. Their routes
  live in `routes/mobile_api.php`. Say the word and I audit them as a follow-up batch.
- **Runtime behaviour** — no browser/test run (D4); every finding is static or a read-only SQL probe.

## 7. Status

- **Index:** all 8 rows `AUDITED` (`gaurav/StudentProfile/00-INDEX.md`).
- **Self-check:** every report prints `SELF-CHECK PASS`.
- **Not fixed:** the audit is read-only. Fixes wait on Tarun ticking `02-fix-plan.md` items and the
  developer (gaurav) running `final-audit-fixer`.
- **Blocked:** nothing.
