# Final Audit — StudentProfile / StudentController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/StudentProfile/app/Http/Controllers/StudentController.php` (5500 lines, 58 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/student-profile/student` (list with two tabs: Student Management, Missing Optional Subjects), `…/student/{id}` (profile), `…/student/{id}/edit` (8-tab wizard), `…/student/create/student/details` (admission/create wizard), `…/student/trash/view`, `…/student/export/{pdf,excel,csv}`, `…/student/download-template`, `…/student/print-id-cards` and `…/student/{student}/print-id-card`, plus the AJAX `…/student/filter-dependencies`, `…/student/class/{class}/streams`, `…/student/stream-subjects/{class}/{stream}`, `…/student/subject-group/{group}/subjects`, `…/student/resolve-subject-group`. All under `/student-profile/…`. |
| Menu path | Student Mgmt. (menu) → Student Profile & Leave Mgmt. → Student (menu id 66 → `student-profile.student.index`) |
| Who uses it | Roles that hold `tenant.student-profile.student.viewAny` on test.localhost: **Super Admin** and **School Admin** (measured, permission id 816, 2 roles). |
| What a user does here | Admins list and search students (by name, admission no, class, section, optional-subject gaps), open a student record, walk the admission wizard (login → basic details → parents → sessions → previous education → health), upload documents and parent photos, print ID cards (single and whole-class), export the list to PDF/Excel/CSV, download the import template, validate and run an Excel import, soft-delete/restore/force-delete, and toggle a student's active status. |
| Tables written | `std_students`, `std_student_profiles`, `std_student_addresses`, `std_student_academic_sessions`, `std_student_opted_subjects`, `std_guardians`, `std_student_guardian_jnt`, `std_student_documents`, `std_previous_education`, `std_health_profiles`, `std_vaccination_records`, `std_medical_incidents`, `sys_users` (login/parent users), `sys_roles` pivot (via `syncRoles`), Spatie `media` rows, `sys_activity_logs` (only toggle/delete/restore/force-delete). |
| Tables read | `std_students`, `std_student_profiles`, `std_student_addresses`, `std_student_academic_sessions`, `std_student_opted_subjects`, `std_guardians`, `std_student_guardian_jnt`, `std_student_documents`, `std_previous_education`, `std_health_profiles`, `std_vaccination_records`, `std_medical_incidents`, `std_attendance_corrections`, `sys_users`, `sch_classes`, `sch_sections`, `sch_class_section_jnt`, `sch_subject_groups`, `sch_subjects`, `sch_class_streams`, `sys_dropdown_table`, `sch_org_academic_sessions_jnt`, `glb_languages`, `glb_cities`, `sys_permissions` (via Gate). |
| Live data | tenant `xyz_school_00000000000040008000_202627` on test.localhost — `std_students` 1825 (0 trashed), `std_guardians` 3650, `std_student_addresses` 3650, `std_student_academic_sessions` 9759, `std_student_documents` 5475, `std_student_guardian_jnt` 3650, `std_health_profiles` 1825, `std_student_opted_subjects` 0, `std_previous_education` 1825, `std_attendance_corrections` 0, `std_vaccination_records` 8187. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is not production-ready. It is the admission/student-management core, 5,500 lines with 58 public methods; the single worst finding is that 14 of the 15 model classes that touch media files (this controller's own pre-assigned models among them) do not override Spatie's `getMediaModel()`, so **every student photo, guardian photo and document upload lands in the central database instead of the tenant** (STC-23, B) — the same cross-tenant leak pattern the earlier StudentProfile report found. Around it sit three more blockers: raw `$e->getMessage()` text is sent to users in ~30 write paths (STC-01, B), a credentials **email is sent inside a transaction** before commit (STC-05, B), and three routes point at methods whose bodies are commented out, so they 500 (STC-13, B). The rest is a tower of mechanical debt — manual transactions, inline validation, findOrFail inside try, N+1 loops, per-row writes in loops — all fixable in place (D3), with three DECISION items (the dead-route cleanup, the god-controller split, a dropdown cache). Rough effort: M–L (the mechanical items are repetitive and safe; the decisions need Tarun's call).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 4 | 7 | 22 | 10 | 3 | 43 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | STC-01, STC-02, STC-03, STC-04 | F8 Services/Jobs | STC-27 |
| F2 Transactions/Audit | STC-05, STC-06, STC-07, STC-08, STC-43 | F9 Queries/Perf | STC-28, STC-29, STC-30, STC-31, STC-32, STC-33, STC-34 |
| F3 Authorization | STC-09, STC-10 | F10 Views | clean |
| F4 Validation | STC-11, STC-12 | F11 Security/Tenancy | STC-35, STC-36 |
| F5 Routes | STC-13, STC-14 | F12 Style | STC-37, STC-38, STC-39, STC-40 |
| F6 Controller shape | STC-15, STC-16, STC-17, STC-18, STC-19, STC-20, STC-21, STC-22 | F13 Deep read | STC-41, STC-42 (+ table) |
| F7 Models | STC-23, STC-24, STC-25, STC-26 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php` | controller | 5500 | this report | ✅ |
| 2 | `Modules/StudentProfile/app/Models/Guardian.php` | model | 152 | this report | ✅ |
| 3 | `Modules/StudentProfile/app/Policies/GuardianPolicy.php` | policy | 44 | this report | ✅ |
| 4 | `Modules/StudentProfile/app/Models/StudentAddress.php` | model | 48 | this report | ✅ |
| 5 | `Modules/StudentProfile/app/Models/StudentAcademicSession.php` | model | 211 | this report | ✅ |
| 6 | `Modules/StudentProfile/app/Models/StudentDocument.php` | model | 90 | this report | ✅ |
| 7 | `Modules/StudentProfile/app/Policies/StudentDocumentPolicy.php` | policy | 44 | this report | ✅ |
| 8 | `Modules/StudentProfile/app/Models/StudentGuardianJnt.php` | model | 60 | this report | ✅ |
| 9 | `Modules/StudentProfile/app/Models/StudentHealthProfile.php` | model | 82 | this report | ✅ |
| 10 | `Modules/StudentProfile/app/Models/StudentOptedSubject.php` | model | 52 | this report | ✅ |
| 11 | `Modules/StudentProfile/app/Models/PreviousEducation.php` | model | 54 | this report | ✅ |
| 12 | `Modules/StudentProfile/app/Policies/StudentPolicy.php` | policy | 80 | this report | ✅ |
| 13 | `Modules/StudentProfile/app/Models/StudentAttendanceCorrection.php` | model | 54 | this report | ✅ |
| 14 | `Modules/StudentProfile/app/Models/VaccinationRecord.php` | model | 44 | this report | ✅ |
| 15 | `Modules/StudentProfile/app/Http/Requests/PrintIdCardsRequest.php` | FormRequest | 43 | this report | ✅ |
| 16 | `Modules/StudentProfile/app/Imports/StudentImport.php` | import | 285 | this report (claimed in `_Info/00-CLASS-OWNERS.md` this session) | ✅ |
| 17 | `Modules/StudentProfile/app/Imports/StudentReadOnly.php` | import | 15 | this report (claimed this session) | ✅ |
| 18 | `Modules/StudentProfile/app/Exports/StudentsExport.php` | export | 221 | this report (claimed this session) | ✅ |
| 19 | `Modules/StudentProfile/app/Emails/StudentLoginCreated.php` | mailable | 29 | this report (claimed this session) | ✅ |
| 20 | `Modules/StudentProfile/app/Helpers/StudentProfileHelper.php` | helper | 92 | this report (claimed this session) | ✅ |
| 21 | `Modules/StudentProfile/resources/views/student/*` (12 views + partials; 29 blades compiled) | blades | — | this report | ✅ compiled, no queries |
| 22 | `Modules/StudentProfile/resources/views/exports/pdf.blade.php` | blade | — | this report | ✅ compiled, no queries |
| 23 | `Modules/StudentProfile/routes/web.php` | routes | — | this report (module route file; ⚠ shared) | ✅ |
| 24 | `Modules/StudentProfile/app/Models/Student.php` | model | — | ↗ [gaurav/StudentProfile/StudentReportController](../StudentReportController-done/01-report.md) | ↗ linked (usage checked) |
| 25 | `Modules/StudentProfile/app/Models/StudentProfile.php` | model | — | ↗ [gaurav/StudentProfile/StudentProfileController](../StudentProfileController-NotUsed/01-report.md) | ↗ linked (usage checked) |
| 26 | `Modules/StudentProfile/app/Models/StudentAttendance.php` | model | — | ↗ [gaurav/StudentProfile/AttendanceController](../AttendanceController-done/01-report.md) | ↗ linked (usage checked) |
| 27 | `Modules/StudentProfile/app/Services/AttendanceService.php` | service | — | ↗ [gaurav/StudentProfile/AttendanceController](../AttendanceController-done/01-report.md) | ↗ linked (not called by this controller) |
| 28 | `Modules/StudentProfile/app/Policies/AttendancePolicy.php` | policy | — | ↗ [gaurav/StudentProfile/AttendanceController](../AttendanceController-done/01-report.md) | ↗ linked |
| 29 | `Modules/StudentProfile/app/Models/MedicalIncident.php` | model | — | ↗ [gaurav/StudentProfile/MedicalIncidentController](../MedicalIncidentController-done/01-report.md) | ↗ linked (usage checked: updateHealthProfile/deleteMedicalIncident) |
| 30 | `Modules/StudentProfile/app/Policies/MedicalIncidentPolicy.php` | policy | — | ↗ [gaurav/StudentProfile/MedicalIncidentController](../MedicalIncidentController-done/01-report.md) | ↗ linked |
| 31 | `Modules/StudentProfile/app/Models/LeaveApplication.php` | model | — | ↗ [gaurav/StudentProfile/StdLeaveController](../StdLeaveController-done/01-report.md) | ↗ linked |
| 32 | `Modules/StudentProfile/app/Services/LeaveService.php` | service | — | ↗ [gaurav/StudentProfile/StdLeaveController](../StdLeaveController-done/01-report.md) | ↗ linked |
| 33 | `Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php` | policy | — | ↗ [gaurav/StudentProfile/StdLeaveController](../StdLeaveController-done/01-report.md) | ↗ linked |
| 34 | `Modules/StudentProfile/app/Models/LeaveType.php` | model | — | ↗ [gaurav/StudentProfile/StudentLeaveTypeController](../StudentLeaveTypeController-done/01-report.md) | ↗ linked |
| 35 | `Modules/StudentProfile/app/Policies/LeaveTypePolicy.php` | policy | — | ↗ [gaurav/StudentProfile/StudentLeaveTypeController](../StudentLeaveTypeController-done/01-report.md) | ↗ linked |
| 36 | `Modules/Template/facades/Template.php`, `Modules/Template/Services/CardPrintLayout.php` | other-module service | — | common (module `Template`) | ❌ other module, not audited here (§8) |
| 37 | `Modules/SchoolSetup/app/Models/User.php`, `Role`, `ClassSection`, `Section`, `SchoolClass`, `ClassStream`, `Subject`, `SubjectGroup`, `SubjectGroupSubject`, `SubjectStudyFormat`, `SubjectStudyFormatOption`, `SchClassGroupsJnt`, `Organization`, `OrganizationAcademicSession` | other-module models | — | common (module `SchoolSetup`) | ❌ other module, not audited here (§8) |
| 38 | `Modules/Prime/Models/AcademicSession.php` | other-module model | — | common | ❌ not audited here (§8) |
| 39 | `Modules/GlobalMaster/Models/City.php`, `Language.php` | other-module models | — | common | ❌ not audited here (§8) |
| 40 | `Modules/SystemConfig/Models/Dropdown.php`, `Setting.php` | other-module models | — | common | ❌ not audited here (§8) |
| 41 | `Modules/Notification/Models/Notification.php` | other-module model | — | common | ❌ not audited here (§8) |
| 42 | `app/Helpers/activityLog.php`, `app/Helpers/helpers.php` (enc_id/dec_id), `App/Http/Controllers/Controller.php`, `App/Models/BaseModel.php` | app glue | — | common | ❌ not audited here (§8) |
| 43 | `Modules/TenantCore/**`, `resources/views/components/**` | shared components/layouts | — | common | ❌ not audited here (§8) |

No pre-applied files.

## 4. Routes

Uncached route list (`APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json`), filtered to `StudentController@`:

```
GET  student-profile/student                                      student-profile.student.index
GET  school-setup/student/create1                                 school-setup.school-setup.student.create1  → create()
GET  student-profile/student/create/student/details             student-profile.student.create              → editStudentDetails()
GET  student-profile/student/trash/view                            student-profile.student.trashed             → trashed()
GET  student-profile/student/{student}                             student-profile.student.show                → show()
GET  student-profile/student/{student}/edit                        student-profile.student.edit                → edit()
GET  student-profile/student/{student}/complete-profile            student-profile.student.completeProfile      → completeProfile()
GET  student-profile/student/{student}/print-id-card               student-profile.student.print-id-card        → printIdCard()
GET  student-profile/student/print-id-cards                        student-profile.student.print-id-cards       → printIdCards()
GET  student-profile/student/export/{type}                         student-profile.student.export               → export()
GET  student-profile/student/download-template                     student-profile.student.download-template    → downloadTemplate()
GET  student-profile/student/filter-dependencies                   student-profile.student.filter-dependencies  → getFilterDependencies()
GET  student-profile/student/class/{classId}/streams               student-profile.student.class.streams        → getClassStreams()
GET  student-profile/student/stream-subjects/{classId}/{streamId}  student-profile.student.stream.subjects      → getStreamSubjects()
GET  student-profile/student/subject-group/{groupId}/subjects      student-profile.student.subject-group.subjects → getSubjectGroupSubjects()
POST student-profile/student/resolve-subject-group                 student-profile.student.resolve-subject-group → resolveSubjectGroup()
GET  student-profile/student/{student}/update                      student-profile.student.editStudentDetails closure (redirects to student.create)
GET  student-profile/student/edit/student/update                   student-profile.student.handle-update-view   → handleStudentUpdateView()   ⛔ MISSING METHOD
POST student-profile/student/create-student-login                  student-profile.student.createStudentLogin   → createStudentLogin()
PUT  student-profile/student/{user}/update-login                   student-profile.student.updateLogin          → updateLogin()
POST student-profile/student/create-student-details                student-profile.student.createStudentDetails → createStudentDetails()
PUT  student-profile/student/{student}/update-student-details      student-profile.student.updateStudentDetails → updateStudentDetails()
PUT  student-profile/student/{student}/update-profile              student-profile.student.updateProfile        → updateProfile()
PUT  student-profile/student/{student}/update-address              student-profile.student.updateStudentAddress → updateStudentAddress()
POST student-profile/student/{student}/toggle-status               student-profile.student.toggleStatus         → toggleStatus()
POST student-profile/student/create-parent-details                 student-profile.student.createParentDetails  → createParentDetails()
PUT  student-profile/parent/{parent}/update                        student-profile.student.updateParentDetails  → updateParentDetails()
POST student-profile/student/create-student-session                student-profile.student.createStudentSession → createStudentSession()
PUT  student-profile/session/{session}/update                      student-profile.student.updateStudentSession → updateStudentSession()
DELETE student-profile/session/{session}/delete                    student-profile.student.deleteStudentSession → deleteStudentSession()
POST student-profile/student/create-student-prev-edu-details       student-profile.student.createStudentPrevEduDetails → createStudentPrevEduDetails()
PUT  student-profile/previous-education/{education}/update         student-profile.student.updatePreviousEducation → updatePreviousEducation()
DELETE student-profile/previous-education/{education}/delete       student-profile.student.deletePreviousEducation → deletePreviousEducation()
PUT  student-profile/student-document/{document}/update            student-profile.student.updateStudentDocument → updateStudentDocument()
DELETE student-profile/student-document/{document}/delete          student-profile.student.deleteStudentDocument → deleteStudentDocument()
POST student-profile/student/create-student-medical-details        student-profile.student.createStudentMedicalDetails → createStudentMedicalDetails()
PUT  student-profile/student/{student}/health-profile/update       student-profile.student.updateHealthProfile → updateHealthProfile()
PUT  student-profile/vaccination/{vaccination}/update              student-profile.student.updateVaccinationRecord → updateVaccinationRecord()  ⛔ MISSING METHOD
DELETE student-profile/vaccination/{vaccination}/delete            student-profile.student.deleteVaccinationRecord → deleteVaccinationRecord()
PUT  student-profile/medical-incident/{incident}/update            student-profile.student.updateMedicalIncident → updateMedicalIncident()  ⛔ MISSING METHOD
DELETE student-profile/medical-incident/{incident}/delete          student-profile.student.deleteMedicalIncident → deleteMedicalIncident()
GET  student-profile/previous-education/{education}/edit           student-profile.student.getPreviousEducationData → getPreviousEducationData()
GET  student-profile/student-document/{document}/edit              student-profile.student.getStudentDocumentData → getStudentDocumentData()
GET  student-profile/session/{session}/edit                        student-profile.student.getSessionData       → getSessionData()
GET  student-profile/vaccination/{vaccination}/edit                student-profile.student.getVaccinationData   → getVaccinationData()
GET  student-profile/medical-incident/{incident}/edit              student-profile.student.getMedicalIncidentData → getMedicalIncidentData()
DELETE student-profile/student/{student}                           student-profile.student.destroy              → destroy()
PATCH student-profile/student/{id}/restore                         student-profile.student.restore              → restore()
DELETE student-profile/student/{id}/force-delete                   student-profile.student.forceDelete          → forceDelete()
POST student-profile/students/send-credentials                     student-profile.student.send-credentials     → sendCredentials()
POST student-profile/student/validate-import                       student-profile.student.validate-import      → validateImport()
POST student-profile/student/start-import                          student-profile.student.start-import         → startImport()
```

Unrouted public methods (10): `store` (line 366), `trashedStudent` (1542), `update` (1611), `showAttendance` (3709), `scanQrAttendance` (3725), `manualAttendance` (3789), `requestAttendanceCorrection` (3853), `bulkClassAttendance` (3887), `getStudentsByClass` (3948), `getTodayAttendance` (3964).

## 5. Per-method table

Routed = verb + uri from §4. Tx = transaction shape: `manual` = `DB::beginTransaction()/commit()/rollBack()` inside the method; `none` = no transaction. Gate = exact permission string; `(in try)` = checked inside the try block.

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 68 | GET /student | `tenant.student-profile.student.viewAny` | none (read) | — | — | STC-16,18,19,28*/(search),30,31,33 |
| `create` | 354 | GET school-setup/student/create1 | `tenant.student-profile.student.create` | none | — | — | (redirect only) |
| `store` | 366 | — | none | none | — | — | STC-14,21 |
| `show` | 370 | GET /student/{student} | `tenant.student-profile.student.view` | none (read) | — | — | STC-18 |
| `printIdCard` | 411 | GET /student/{student}/print-id-card | `tenant.student-profile.student.view` | none (read) | — | — | STC-02,03,18,22 |
| `printIdCards` | 472 | GET /student/print-id-cards | `tenant.student-profile.student.view` (Request + Gate = AUTH-04 dup) | none (read) | — | — | STC-03,18,09 |
| `edit` | 654 | GET /student/{student}/edit | `tenant.student-profile.student.update` | none (read) | — | — | STC-16,19,30,34 |
| `createStudentLogin` | 788 | POST create-student-login | `tenant.student-profile.student.create` (in try) | manual | — (none) | sys_users, sys_roles pivot, std_students, media | STC-01,05,06,10,12,43 |
| `updateLogin` | 871 | PUT /student/{user}/update-login | `tenant.student-profile.student.update` | manual | — (none) | sys_users, media | STC-01,06,11,12 |
| `createStudentDetails` | 944 | POST create-student-details | `tenant.student-profile.student.create` (in try) | manual | — (none) | std_students, std_student_profiles, std_student_addresses, std_health_profiles, media | STC-01,02,06,10,11 |
| `updateStudentDetails` | 1163 | PUT /student/{student}/update-student-details | `tenant.student-profile.student.update` | manual | — (none) | std_students, std_student_profiles, std_student_addresses, std_health_profiles, media | STC-01,02,06,11,16,28,29 |
| `updateProfile` | 1285 | PUT /student/{student}/update-profile | `tenant.student-profile.student.update` | none (single write) | — (none) | std_student_profiles | STC-11 |
| `updateStudentAddress` | 1418 | PUT /student/{student}/update-address | `tenant.student-profile.student.update` | manual | — (none) | std_student_addresses | STC-01,06,11 |
| `editStudentDetails` | 1447 | GET create/student/details | `tenant.student-profile.student.create` | none (read) | — | — | STC-16,19,30 |
| `trashedStudent` | 1542 | — | `tenant.student-profile.student.delete` | none (read) | — | — | STC-14 |
| `toggleStatus` | 1570 | POST /student/{student}/toggle-status | `tenant.student-profile.student.update` | manual | Toggled (AFTER commit) | std_students, sys_users | STC-01,03,06,07 |
| `update` | 1611 | — | none | none | — | — | STC-14,21 |
| `createParentDetails` | 1624 | POST create-parent-details | `tenant.student-profile.guardian.create` | manual | — (none) | std_guardians, sys_users, std_student_guardian_jnt, media | STC-01,06,11,16,28,29,43 |
| `updateParentDetails` | 1914 | PUT /parent/{parent}/update | `tenant.student-profile.student.update` | manual | — (none) | std_guardians, sys_users, std_student_guardian_jnt, media | STC-01,02,04,06,11,16,17 |
| `createStudentSession` | 2017 | POST create-student-session | `tenant.student-profile.student.create` | manual | — (none) | std_student_academic_sessions, std_student_opted_subjects, media | STC-01,05?,06,11,16,17,20,29 |
| `updateStudentSession` | 2218 | PUT /session/{session}/update | `tenant.student-profile.student.update` | manual | — (none) | std_student_academic_sessions, std_student_opted_subjects, media | STC-01,02,06,11,16,17,20,29 |
| `deleteStudentSession` | 2384 | DELETE /session/{session}/delete | `tenant.student-profile.student.update` | manual | — (none) | std_student_academic_sessions | STC-01,02,06,17 |
| `createStudentPrevEduDetails` | 2421 | POST create-student-prev-edu-details | `tenant.student-profile.student.create` | manual | — (none) | std_previous_education, std_student_documents, media | STC-01,03,06,11,16,17 |
| `updatePreviousEducation` | 2606 | PUT previous-education/{education}/update | `tenant.student-profile.student.update` | manual | — (none) | std_previous_education, std_student_documents, media | STC-01,02,06,11,16,17,28,29 |
| `deletePreviousEducation` | 2966 | DELETE previous-education/{education}/delete | `tenant.student-profile.student.delete` | manual | — (none) | std_previous_education, std_student_documents | STC-01,02,06,17 |
| `updateStudentDocument` | 3003 | PUT student-document/{document}/update | `tenant.student-profile.student.update` | manual | — (none) | std_student_documents, media | STC-01,02,06,11,17 |
| `deleteStudentDocument` | 3120 | DELETE student-document/{document}/delete | `tenant.student-profile.student-document.delete` | manual | — (none) | std_student_documents, media | STC-01,02,06,17 |
| `createStudentMedicalDetails` | 3153 | POST create-student-medical-details | `tenant.student-profile.student.create` (in try) | manual | — (none) | std_health_profiles, std_student_profiles, std_vaccination_records, media | STC-01,02,06,10,11,16,28,29 |
| `updateHealthProfile` | 3350 | PUT /student/{student}/health-profile/update | `tenant.student-profile.student.update` | manual | — (none) | std_health_profiles, std_vaccination_records, std_medical_incidents, media | STC-01,03,06,11,16,28,29 |
| `deleteVaccinationRecord` | 3617 | DELETE vaccination/{vaccination}/delete | `tenant.student-profile.student.update` | manual | — (none) | std_vaccination_records | STC-01,02,06,17 |
| `deleteMedicalIncident` | 3649 | DELETE medical-incident/{incident}/delete | `tenant.student-profile.medical-incident.delete` | manual | — (none) | std_medical_incidents | STC-01,02,06,17 |
| `showAttendance` | 3709 | — | `tenant.student-profile.student.create` | none (read) | — | — | STC-14 |
| `scanQrAttendance` | 3725 | — | `tenant.student-profile.student.create` | manual | — (none) | std_student_attendance | STC-01,06,11,14 |
| `manualAttendance` | 3789 | — | `tenant.student-profile.student.create` | manual | — (none) | std_student_attendance | STC-01,06,11,14 |
| `requestAttendanceCorrection` | 3853 | — | `tenant.student-profile.student-attendance.correction` | manual | — (none) | std_attendance_corrections | STC-01,06,11,14 |
| `bulkClassAttendance` | 3887 | — | `tenant.student-profile.student.create` | manual | — (none) | std_student_attendance | STC-01,06,11,14,20,28,29 |
| `getStudentsByClass` | 3948 | — | (commented out) | none (read) | — | — | STC-14 |
| `getTodayAttendance` | 3964 | — | (commented out) | none (read) | — | — | STC-14 |
| `getFilterDependencies` | 3978 | GET filter-dependencies | `tenant.student-profile.student.viewAny` | none (read) | — | — | STC-02,16,32,35 |
| `getSubjectGroupSubjects` | 4085 | GET subject-group/{group}/subjects | `tenant.student-profile.student.viewAny` | none (read) | — | — | STC-02,03,28 |
| `getClassStreams` | 4133 | GET class/{classId}/streams | `tenant.student-profile.student.viewAny` | none (read) | — | — | STC-02,03 |
| `getStreamSubjects` | 4174 | GET stream-subjects/{classId}/{streamId} | `tenant.student-profile.student.viewAny` | none (read) | — | — | STC-02,03,16,28,31,36 |
| `resolveSubjectGroup` | 4334 | POST resolve-subject-group | `tenant.student-profile.student.viewAny` | none (read) | — | — | STC-02,03,16 |
| `sendCredentials` | 4438 | POST students/send-credentials | `tenant.student-profile.student.update` | none | — (none) | sys_users (password resets), mail | STC-01,02,08,11,38,42 |
| `getPreviousEducationData` | 4539 | GET previous-education/{education}/edit | `tenant.student-profile.student.viewAny` | none (read) | — | — | STC-02,17 |
| `getStudentDocumentData` | 4561 | GET student-document/{document}/edit | `tenant.student-profile.student-document.viewAny` | none (read) | — | — | STC-02,17 |
| `getSessionData` | 4583 | GET session/{session}/edit | `tenant.student-profile.student.viewAny` | none (read) | — | — | STC-02,17 |
| `getVaccinationData` | 4606 | GET vaccination/{vaccination}/edit | `tenant.student-profile.student.viewAny` | none (read) | — | — | STC-02,17 |
| `getMedicalIncidentData` | 4628 | GET medical-incident/{incident}/edit | `tenant.student-profile.medical-incident.viewAny` | none (read) | — | — | STC-02,17 |
| `destroy` | 4672 | DELETE /student/{student} | `tenant.student-profile.student.delete` | manual | Deleted (AFTER commit) | std_students, sys_users | STC-01,06,07,17 |
| `trashed` | 4715 | GET trash/view | `tenant.student-profile.student.restore` | none (read) | — | — | STC-18 |
| `restore` | 4734 | PATCH /student/{id}/restore | `tenant.student-profile.student.restore` | manual | Restored (AFTER commit) | std_students, sys_users | STC-01,06,07,17 |
| `forceDelete` | 4778 | DELETE /student/{id}/force-delete | `tenant.student-profile.student.forceDelete` | manual | Force Deleted (AFTER commit) | std_students, sys_users, media | STC-01,06,07,17 |
| `completeProfile` | 4846 | GET /student/{student}/complete-profile | `tenant.student-profile.student.update` | none (read) | — | — | (redirect logic) |
| `export` | 4888 | GET export/{type} | `tenant.student-profile.student.export` | none (read) | — | — | STC-16,22,29?,31,41 |
| `validateImport` | 5084 | POST validate-import | `tenant.student-profile.student.create` | none (read + temp file store) | — | storage `imports/students`, session | STC-01,02,03,11,16,28 |
| `startImport` | 5273 | POST start-import | `tenant.student-profile.student.create` | `DB::transaction` closure (Excel::import) | — (none) | sys_users, std_students, std_guardians, std_student_guardian_jnt, std_student_addresses, sch_class_section_jnt, std_student_academic_sessions | STC-01,03,27 |
| `downloadTemplate` | 5319 | GET download-template | `tenant.student-profile.student.create` | none (read/write xlsx stream) | — | (download only) | STC-16 |

Private helpers called by the above: `generateStudentEmpCode` (769), `storeStudentPhoto` (930, media writer), `validateStudentRequest` (991), `storeStudent` (1046, writes std_students), `ensureSinglePrimaryAddress` (1265), `storeStudentProfile` (1324, writes std_student_profiles + std_health_profiles), `storeStudentAddress` (1376, writes std_student_addresses), `cleanOldInput` (1870, **dead**, never called), `updateStudentAddressLogic` (3682, writes std_student_addresses), `getNextIncompleteTabForCreate` (4859), `exportPDF` (5007).

## 6. Findings

### F1 — Errors

#### STC-01 · B · ERR-01 — raw exception text sent to the user in every write path

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *Never send exception text to the user: no `$e->getMessage()` in `withErrors`, `with('error')`, `response()->json`, or `back()` — SQL, table and column names leak* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:864,918,987,1261,1443,1606,1860,2013,2199,2380,2413,2417,2588,2818,2824,2989,2995,3052,3058,3143,3149,3335,3338,3505,3639,3645,3672,3678,3785,3849,3883,3944,4078,4126,4167,4327,4431,4490,4508,4531,4551,4573,4596,4618,4640,4711,4747,4774,4842,5263,5266,5306` (also `Modules/StudentProfile/app/Imports/StudentImport.php:145,152` swallow-and-fallback) |
| **Root cause** | Every `catch (\Throwable $e)` / `catch (\Exception $e)` returns `$e->getMessage()` to the user, and errors like a duplicate mobile number or a unique-index race are **QueryExceptions whose message is raw SQL text**. Exceptional branches were written to be useful, but they leak DB internals and contradict the central error handler (`bootstrap/app.php`). |
| **Consequence** | A user who hits any write failure — duplicate admission number, mobile number collision (`uq_std_guardians_mobile`), a FK error — sees raw SQL/column names (e.g. `SQLSTATE[23000]…Duplicate entry…`) in the flash or JSON instead of a safe message. |
| **Reproduce** | `createParentDetails` with a mobile number that already exists under a race → the 500 JSON/redirect shows the raw unique-index error; or `toggleStatus` with a locked row. |
| **Fix approach** | D1: remove the `catch` blocks; let the central handler render a friendly 500/friendly JSON, or keep the allowed D2 shapes only. Where a business message is needed, throw `\DomainException` with user-safe text. |
| **Plan item** | STC-01 in `02-fix-plan.md` §1 |

```php
        } catch (\Throwable $e) {
            DB::rollBack();
            return back()->with('error', $e->getMessage())->withInput();
        }
```

**Evidence**
```
$ grep -c "getMessage()" Modules/StudentProfile/app/Http/Controllers/StudentController.php
51
$ grep -c "with('error', \$e->getMessage())\|getMessage(), 500\|'error' => \$e->getMessage()" Modules/StudentProfile/app/Http/Controllers/StudentController.php
22
```

#### STC-02 · H · ERR-02 — `findOrFail`/`authorize`/`validate` inside try; generic catch swallows 404/403/422

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *A catch must never turn a 404/403/422/`abort()` into a redirect or 500. `validate()`, `authorize()` and `findOrFail()` belong **before** the `try`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:791,953,1939,2314,2388,2634,2971,3026,3124,3169,3621,3653,3978,4089,4137,4178,4338,4441,4543,4565,4587,4610,4632,4677,4739,4783,5088` |
| **Root cause** | `Gate::authorize()`, `$request->validate()` and `findOrFail()` sit inside the `try`, and the generic `catch` converts the corresponding `AuthorizationException`, `ValidationException` and `ModelNotFoundException` into a redirect with a flash (or a 500 JSON in the AJAX methods), because those exceptions are subclasses of the caught type. |
| **Consequence** | A missing record yields "Failed to … : No query results for model" instead of a Laravel 404; a permission refusal yields a flash instead of 403; a validation failure is caught first by the generic catch in several methods (e.g. `updateParentDetails` `catch (\Exception)`), turning a normal form error into a 500/raw SQL string. |
| **Reproduce** | Open `student-profile/session/999999/edit` (`getSessionData`) → raw exception JSON list; submit `deleteStudentSession` with a stale id → redirect with raw SQL text. |
| **Fix approach** | D1: move validate/authorize/findOrFail above the transaction; delete the generic catches (they repeat STC-01's leak anyway). Keep only the D2 shapes. |
| **Plan item** | STC-02 in `02-fix-plan.md` §2 |

```php
        try {
            Gate::authorize('tenant.student-profile.student.create');
            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'short_name' => 'required|string|max:30|unique:sys_users,short_name',
```

**Evidence**
```
$ grep -cE "findOrFail\(|firstOrFail\(|sole\(" Modules/StudentProfile/app/Http/Controllers/StudentController.php
14
$ grep -n "inside a try; generic catch swallows" /tmp/fa-studentprofile.json | head -1   # scan candidates
H  ERR-02   Modules/StudentProfile/app/Http/Controllers/StudentController.php:2634  updatePreviousEducation — validate/validateWithBag inside try; generic catch swallows ValidationException
```

#### STC-03 · M · ERR-05 — log sites record only the message, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *Log the exception not the message: `report($e)` or `Log::error('…', ['exception' => $e])` — `getMessage()` alone loses the trace* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:437,525,1601,2586,3330,3503,4125,4166,4326,4430,5262,5305` |
| **Root cause** | Every `Log::error(…, ['error' => $e->getMessage()])` / `\Log::error('…: ' . $e->getMessage())` stores a string, so a production failure leaves no stack trace and no exception class. |
| **Consequence** | Support gets a one-line message ("The file could not be written", "Call to a member function on null") with no file/line/trace; the root cause of an import or print failure is lost. |
| **Reproduce** | Force an ID-card template error (`printIdCard`) and read `storage/logs` — only the message is logged. |
| **Fix approach** | Replace each site with `report($e)` or `Log::error('…', ['exception' => $e])`. |
| **Plan item** | STC-03 in `02-fix-plan.md` §3 |

```php
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('StudentController::toggleStatus failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -c "getMessage()\]);" Modules/StudentProfile/app/Http/Controllers/StudentController.php
6
$ grep -c "error' => \$e->getMessage()" Modules/StudentProfile/app/Http/Controllers/StudentController.php
7
```

#### STC-04 · H · ERR-06 — swallowed media-upload failure in updateParentDetails

| Field | Value |
|---|---|
| **Rule** | ERR-06 (H) — *No swallowed failures in write paths — an empty catch, or a catch that logs and then continues as if the write succeeded* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1990-2002` (method `updateParentDetails`) |
| **Root cause** | The guardian-photo upload failure is caught by an **empty catch** whose only body is a commented-out log line (the `// \Log::error` line). The guardian record was already mutated, the transaction then commits, and the page flashes success — the photo silently vanished. The DOB parse catches in `validateImport` (5191-5197) are a legitimate fallback and are not part of this finding. |
| **Consequence** | An administrator thinks the guardian photo was saved (success flash); the file is lost, no log, no retry. |
| **Reproduce** | Upload a corrupt image for a parent — success message, empty `parent_img` collection. |
| **Fix approach** | Let the media error rethrow (D1) so the transaction rolls back, or `report($e)` and surface a fixed message. |
| **Plan item** | STC-04 in `02-fix-plan.md` §2 |

```php
                } catch (\Exception $e) {
                    // \Log::error('Failed to upload guardian image: ' . $e->getMessage());
                }
```

**Evidence**
```
$ sed -n '1990,2002p' Modules/StudentProfile/app/Http/Controllers/StudentController.php | grep -c "}"
3
$ grep -c "catch (\Exception \$e) {" Modules/StudentProfile/app/Http/Controllers/StudentController.php
1
```

### F2 — Transactions and audit

#### STC-05 · B · TXN-03 — credentials email sent inside the transaction, before commit

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B) — *No irreversible side effect inside a transaction or before the write succeeds: mail, SMS, push, HTTP. Do them after commit* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:835-843` (method `createStudentLogin`) |
| **Root cause** | `Mail::to($user->email)->send(new StudentLoginCreated($user, $plainPassword))` runs **between `DB::beginTransaction()` and `DB::commit()`**. Laravel's `Mail` is an outbox of its own: the send happens immediately, then the DB commit happens. If any later statement (the role sync, the student link, the file store) throws, the catch rolls back the user row but the email was already delivered. |
| **Consequence** | A parent/student can receive a "Your Student Login Credentials" mail for an account that was rolled back and does not exist — a phantom login on every smtp-unreachable or mid-save failure path. |
| **Reproduce** | Static only — mail precedes `DB::commit()`. An injection that fails after line 839 delivers a stale credential mail. |
| **Fix approach** | Commit first, then send the mail outside the transaction (after the closure returns), per D2 service guidance. |
| **Plan item** | STC-05 in `02-fix-plan.md` §1 |

```php
            Mail::to($user->email)->send(
                new StudentLoginCreated($user, $plainPassword)
            );

            DB::commit();
```

**Evidence**
```
$ sed -n '839,843p' Modules/StudentProfile/app/Http/Controllers/StudentController.php
            Mail::to($user->email)->send(
                new StudentLoginCreated($user, $plainPassword)
            );

            DB::commit();
$ grep -c "Mail::to" Modules/StudentProfile/app/Http/Controllers/StudentController.php
3
```

#### STC-06 · M · TXN-02 — manual `beginTransaction/commit/rollBack` with no closure

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *Use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`. Never `return` between `beginTransaction` and `commit`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:790,890,952,1175,1431,1579,1652,1938,2128,2312,2387,2469,2633,2970,3025,3123,3168,3354,3620,3652,3739,3803,3867,3905,4676,4738,4782` |
| **Root cause** | 27 write methods open manual transactions (`DB::beginTransaction()`) and close them in separate catch blocks. Every early `return redirect()` before `DB::commit()` (they exist — e.g. `createStudentSession` returns inside the try at 2188 after commit, but `updateLogin`/`createStudentDetails` return inside the try) risks a leaked open transaction; the pattern is the exact shape TXN-02 forbids. |
| **Consequence** | A `return` between begin and commit leaks an open transaction for the rest of the request; audit rows written after commit (see STC-07) are never atomic. Pure maintainability/robustness debt otherwise. |
| **Reproduce** | Static — `grep -c beginTransaction` = 27 manual opens. |
| **Fix approach** | D1: convert every manual open/commit/rollBack pair to `DB::transaction(function () …)` returning the redirect/response from the closure. |
| **Plan item** | STC-06 in `02-fix-plan.md` §3 |

```php
        DB::beginTransaction();
        try {
            $student = $this->storeStudent($request, $validated);
            $this->storeStudentProfile($request, $student->id);
```

**Evidence**
```
$ grep -c "DB::beginTransaction()" Modules/StudentProfile/app/Http/Controllers/StudentController.php
27
$ grep -c "DB::transaction(function" Modules/StudentProfile/app/Http/Controllers/StudentController.php
1
```

#### STC-07 · M · TXN-04 — `activityLog()` placed after commit (and absent from 22 other write methods)

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, **after** the write it describes — not before it, not after commit* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1588-1592,4698-4702,4761-4765,4823-4828` |
| **Root cause** | The only four `activityLog()` calls in the file run **after** `DB::commit()`. The audit row is therefore written outside the transaction: if `activityLog` fails, the row is saved but no audit exists; if a later step fails, the row has an audit that was never committed with it. The other 22 write methods (all create/update paths above) have **no `activityLog()` at all**, so the audit trail the ERP promises is mostly empty. |
| **Consequence** | Student/guardian/session creates and updates leave no audit events; the four events that exist can desync from the rows they describe. |
| **Reproduce** | `static only — the ordering commit→activityLog is visible in all four methods.` |
| **Fix approach** | Move each `activityLog()` inside the `DB::transaction` after the write. Adding the missing `activityLog()` calls to the other mutators is a separate decision (event semantics) — list in plan. |
| **Plan item** | STC-07 in `02-fix-plan.md` §3 |

```php
            DB::commit();

            activityLog($student, 'Toggled', [
                'message' => 'Student and linked user status updated to ' . ($isActive ? 'Active' : 'Inactive'),
            ]);
```

**Evidence**
```
$ grep -c "activityLog(" Modules/StudentProfile/app/Http/Controllers/StudentController.php
4
$ grep -n "DB::commit();" Modules/StudentProfile/app/Http/Controllers/StudentController.php | wc -l
27
```

#### STC-08 · H · TXN-01 — `sendCredentials` writes multiple password rows with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *More than one write (two models, a model + its audit row) runs inside **one** `DB::transaction`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:4438-4534` (method `sendCredentials`, writes at 4472-4482) |
| **Root cause** | The loop resets each selected user's password with `->save()` (and sends mail) with **no `DB::transaction` at all**. A failure mid-loop (an SMTP throw at 4489 is caught per-student, but a DB error is not) leaves students 1..n with new random passwords and the rest untouched; the JSON then claims "Credentials sent to N student(s)". |
| **Consequence** | A partially-reset batch of student passwords with no rollback and no accurate count — students unknowingly locked out with a random password until they read a mail that may not have been sent. |
| **Reproduce** | `POST student-profile/students/send-credentials` with 50 students and kill the DB on the 30th row. |
| **Fix approach** | Wrap the loop's writes in one `DB::transaction`; send all mail after commit (`DB::afterCommit` per-student is fine). |
| **Plan item** | STC-08 in `02-fix-plan.md` §2 |

```php
                        case 'reset':
                            $plainPassword = Str::random(10);
                            $student->password = Hash::make($plainPassword);
                            $student->save();
                            break;
```

**Evidence**
```
$ grep -c "DB::transaction" Modules/StudentProfile/app/Http/Controllers/StudentController.php
1        # only startImport uses a closure
$ sed -n '4463,4483p' Modules/StudentProfile/app/Http/Controllers/StudentController.php | grep -c "save()"
2
```

#### STC-43 · M · TXN-06 — guardian mobile check-then-create has a unique index but no lock; the race surfaces as raw SQL 500

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H, lowered to M) — *Check-then-act needs a lock or a unique index* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1732-1756` (method `createParentDetails`) |
| **Root cause** | `Guardian::where('mobile_no', $gData['mobile_no'])->first()` then (if absent) `Guardian::create([... 'mobile_no' ...])`. The unique index `uq_std_guardians_mobile` (tenant migration) protects data, but a simultaneous submit at that instant makes the second insert raise a unique-violation QueryException, whose raw SQL text goes straight to the user (STC-01). The pre-check is safe data-wise but racy UX-wise. |
| **Consequence** | Two admins adding the same parent mobile in the same second → one gets a 500/redirect with `SQLSTATE[23000]` raw SQL text instead of the friendly "already registered" message. |
| **Reproduce** | Static — double-submit the parent form with the same mobile; the second request hits `uq_std_guardians_mobile`. |
| **Fix approach** | Lock the candidate row (`lockForUpdate`) inside the transaction, or catch the unique violation as the allowed D2 shape and return the friendly message. |
| **Plan item** | STC-43 in `02-fix-plan.md` §2 |

```php
                    // Handle New Guardian Creation
                    $existingGuardian = Guardian::where('mobile_no', $gData['mobile_no'])->first();
```

**Evidence**
```
$ grep -n "uq_std_guardians_mobile" database/migrations/tenant/2026_06_15_151300_create_std_guardians_table.php
36:            $table->unique('mobile_no', 'uq_std_guardians_mobile');
```

### F3 — Authorization

#### STC-09 · M · AUTH-06 — the three registered policies are never consulted by this controller or its views

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *Permission strings live in one place — a Policy, or constants — not repeated as literals in every method* |
| **Where** | `Modules/StudentProfile/app/Policies/GuardianPolicy.php:15-18`, `Modules/StudentProfile/app/Policies/StudentPolicy.php:13-39`, `Modules/StudentProfile/app/Policies/StudentDocumentPolicy.php:15-18` |
| **Root cause** | `StudentProfileServiceProvider` registers `Gate::policy(Student::class, StudentPolicy::class)` etc. (lines 62-66), but this controller only ever calls string gates (`Gate::authorize('tenant.student-profile.student.view')`), which never reaches a policy. The views also only use string `@can`/`permission=` checks. So `StudentPolicy::view()`'s record-level rules — "students may view their own record, parents their linked children" — run nowhere the backend enforces them. The permission strings are simultaneously in the controller (as literals), the config and the policies — AUTH-06's duplication. |
| **Consequence** | Dead policy code that promises per-record ownership on `Student` but delivers it nowhere; a future caller who trusts the policy registration will be surprised. (Severity M — no live authorization hole on the web side, the string gates do gate.) |
| **Reproduce** | Static — `grep -rn "Gate::policy" Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php` shows the registrations; the controller has no model-bound `authorize`. |
| **Fix approach** | Either call the policies (change `Gate::authorize('tenant.student-profile.student.view')` to a model-bound `Gate::authorize('view', $student)` route-model style) or delete the registrations; consolidate literals into the policy. |
| **Plan item** | STC-09 in `02-fix-plan.md` §4 (decision-flavoured; behaviour change) |

```php
    public function view(User $user, Guardian $guardian): bool
    {
        return $user->can('tenant.student-profile.guardian.view');
    }
```

**Evidence**
```
$ grep -rn "Gate::policy" Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php
62:        Gate::policy(Student::class, StudentPolicy::class);
64:        Gate::policy(Guardian::class, GuardianPolicy::class);
66:        Gate::policy(StudentDocument::class, StudentDocumentPolicy::class);
$ grep -c "Gate::authorize(" Modules/StudentProfile/app/Http/Controllers/StudentController.php
47      # all string gates; none model-bound
```

#### STC-10 · M · AUTH-02 — authorize runs inside try, after the transaction opens

| Field | Value |
|---|---|
| **Rule** | AUTH-02 (H, lowered to M) — *Authorize first — before loading records and outside any try* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:790-792,953-954,3169-3170` |
| **Root cause** | In `createStudentLogin`, `createStudentDetails` and `createStudentMedicalDetails` the permission check sits **inside** `try` after `DB::beginTransaction()` (and after any earlier record load in `createStudentMedicalDetails`). A `Gate::authorize` denial becomes an exception that the generic catch turns into a redirect/flash with the raw message rather than a 403. |
| **Consequence** | A user without the permission gets a misleading "error" flash + a rolled-back (wasted) transaction instead of the standard 403 page. |
| **Reproduce** | Log in as a role without create, POST `create-student-login`. |
| **Fix approach** | Move each `Gate::authorize` above the transaction (D1) before any record loading. |
| **Plan item** | STC-10 in `02-fix-plan.md` §4 |

```php
        DB::beginTransaction();
        try {
            Gate::authorize('tenant.student-profile.student.create');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/StudentProfile/app/Http/Controllers/StudentController.php | head -3
70:        Gate::authorize('tenant.student-profile.student.viewAny');
356:        Gate::authorize('tenant.student-profile.student.create');
792:            Gate::authorize('tenant.student-profile.student.create');
```

### F4 — Validation and input

#### STC-11 · M · VAL-02 — validation lives inline in the controller, not in FormRequests

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *Validation lives in a Form Request (project rule), not inline `$request->validate()`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:793,879,997-1043,1289,1422,1573,1627,1920,2044,2071,2229,2255,2441,2636,3011,3171,3728,3792,3856,3890,4442,5089` |
| **Root cause** | 20+ inline `$request->validate([...])` / `Validator::make($request->all(), ...)` rule arrays live inside the controller (including `validateStudentRequest`), with cross-field "if status inactive then leaving_date required" logic hand-rolled at 2067-2078/2251-2262 instead of a FormRequest `after()` hook (VAL-07). Only `printIdCards` uses a FormRequest. |
| **Consequence** | Validation rules are unreachable from tests, un-reusable, and drift from the DB (e.g. `updateLogin` requires `short_name`/`emp_code`/`email` while the create rules differ); the "sometimes, nullable" mistakes in STC-12 live here too. |
| **Reproduce** | Static — `grep -c "->validate("` = 20 inline sites. |
| **Fix approach** | Extract one FormRequest per resource (student-login, student-details(+address), parent, session, previous-education, document, health, attendance, credentials, import) and move the cross-field rules into `after()`. |
| **Plan item** | STC-11 in `02-fix-plan.md` §5 (large; may be split into per-tab items) |

```php
            $validated = $request->validate([
                'student_id' => 'required|exists:std_students,id',
                'academic_session_id' => 'required',
```

**Evidence**
```
$ grep -c "->validate(\[" Modules/StudentProfile/app/Http/Controllers/StudentController.php
18
$ grep -c "Validator::make" Modules/StudentProfile/app/Http/Controllers/StudentController.php
1
```

#### STC-12 · M · VAL-05 — `'nullable'` on booleans validates nothing

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *Every field is typed: `boolean`, `integer`, `date`, `Rule::enum()`. `'sometimes'` alone validates nothing* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:801-802` (and the mirrored `886-887` in `updateLogin`) |
| **Root cause** | `'is_active' => 'nullable'` and `'two_factor_auth_enabled' => 'nullable'` accept **any value** (a string `"not-a-bool"` passes); they are read with `$request->boolean()` afterwards, so a malicious or typo'd value is silently coerced to false. |
| **Consequence** | A crafted request can set `two_factor_auth_enabled`/`is_active` to anything; type coercion masks the mistake instead of rejecting it. |
| **Reproduce** | POST `create-student-login` with `is_active=banana` → row created with `0`. |
| **Fix approach** | Type the rules: `'is_active' => 'nullable|boolean'`, `'two_factor_auth_enabled' => 'nullable|boolean'` (as `updateLogin` already does). |
| **Plan item** | STC-12 in `02-fix-plan.md` §5 |

```php
                'is_active' => 'nullable',
                'two_factor_auth_enabled' => 'nullable',
                'user_img' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
```

**Evidence**
```
$ sed -n '801,803p' Modules/StudentProfile/app/Http/Controllers/StudentController.php
                'is_active' => 'nullable',
                'two_factor_auth_enabled' => 'nullable',
                'user_img' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
```

### F5 — Routes

#### STC-13 · B · RTE-02 — three routes point at methods whose bodies are commented out

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *Every route points to a method that exists* |
| **Where** | `Modules/StudentProfile/routes/web.php:50,115-116,121-122` |
| **Root cause** | The controller's `handleStudentUpdateView()`, `updateVaccinationRecord()` and `updateMedicalIncident()` are commented-out (controller lines 1527-1540, 3512-3557, 3558-3616). The routes still reference them, so hitting any of the three URLs throws a `BadMethodCallException`/redirect-class resolution error → 500. |
| **Consequence** | `GET student-profile/student/edit/student/update`, `PUT …/vaccination/{v}/update` and `PUT …/medical-incident/{i}/update` are guaranteed 500s — and the latter two are the natural "edit vaccine/incident" links on the health tab, so an admin editing a vaccine record breaks (the delete routes still work). |
| **Reproduce** | `curl -X PUT http://test.localhost:8000/student-profile/vaccination/1/update` → 500 (method missing). |
| **Fix approach** | DECISION (touches the shared module route file): (a) remove/comment the three dead route registrations (recommended), (b) re-implement the two update methods by restoring the commented bodies, or (c) leave as is. |
| **Plan item** | STC-13 in `02-fix-plan.md` §1 (DECISION, ⚠ SHARED route file) |

```php
    Route::put('/vaccination/{vaccination}/update', [StudentController::class, 'updateVaccinationRecord'])
        ->name('student.updateVaccinationRecord');
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json 2>/dev/null | php -r '$r=json_decode(stream_get_contents(STDIN),true);foreach($r as $x) if(str_contains($x["action"],"StudentController@") && (str_contains($x["action"],"updateVaccinationRecord")||str_contains($x["action"],"updateMedicalIncident")||str_contains($x["action"],"handleStudentUpdateView"))) echo $x["method"]." ".$x["uri"]." ".$x["action"]."\n";'
PUT  student-profile/vaccination/{vaccination}/update  Modules\StudentProfile\Http\Controllers\StudentController@updateVaccinationRecord
PUT  student-profile/medical-incident/{incident}/update  Modules\StudentProfile\Http\Controllers\StudentController@updateMedicalIncident
GET|HEAD  student-profile/student/edit/student/update  Modules\StudentProfile\Http\Controllers\StudentController@handleStudentUpdateView
```

#### STC-14 · M · RTE-03 — ten public methods are unrouted and still live

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *Every public controller method is routed, or is deliberately disabled* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:366,1542,1611,3709,3725,3789,3853,3887,3948,3964` |
| **Root cause** | `store` (empty body), `update` (empty body), `trashedStudent`, `showAttendance`, `scanQrAttendance`, `manualAttendance`, `requestAttendanceCorrection`, `bulkClassAttendance`, `getStudentsByClass`, `getTodayAttendance` have no route. Their work is duplicated by the resource routes and by `AttendanceController` (which owns the routed `attendance.scan`/`attendence.manual`/`bulk-attendance`); two of them (`getStudentsByClass`, `getTodayAttendance`) even have their `Gate::authorize` commented out, so if they were ever exposed they would be **unauthenticated data endpoints**. |
| **Consequence** | 10 dead entry points with commented-out authorization; a future route addition accidentally exposing `getStudentsByClass` would leak the student list with no gate. |
| **Reproduce** | `grep -nE "public function"` — the list above has no matching route in `routes/web.php`. |
| **Fix approach** | D5: turn each unrouted body into `abort(403, 'Not routed.')` with a `// NOT ROUTED` comment; `store`/`update` get the same. |
| **Plan item** | STC-14 in `02-fix-plan.md` §5 |

```php
    public function trashedStudent()
    {
        Gate::authorize('tenant.student-profile.student.delete');
        $students = User::onlyTrashed()->role('Student')->paginate(10);
        return view('studentprofile::student.trash', compact('students'));
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json 2>/dev/null | php -r '$r=json_decode(stream_get_contents(STDIN),true);$m=preg_grep("/public function (store|update|trashedStudent|showAttendance|scanQrAttendance|manualAttendance|requestAttendanceCorrection|bulkClassAttendance|getStudentsByClass|getTodayAttendance)\(/", file("Modules/StudentProfile/app/Http/Controllers/StudentController.php"));foreach($r as $x) if(str_contains($x["action"],"StudentController@")){foreach(["store","update","trashedStudent","showAttendance","scanQrAttendance","manualAttendance","requestAttendanceCorrection","bulkClassAttendance","getStudentsByClass","getTodayAttendance"] as $mm){if(str_contains($x["action"],"@$mm")) echo "ROUTED $mm\n";}}'
# (no output = none of the ten are routed)
```

### F6 — Controller shape

#### STC-15 · H · CTL-01 — the god controller (5,500 lines, 58 public methods) — split deferred

| Field | Value |
|---|---|
| **Rule** | CTL-01 (M; over 2,500 lines → **H**) — *No god controllers. Over 1,000 lines or 25 public methods → split by resource* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:63-70` |
| **Root cause** | The file holds student CRUD + admission wizard + guardians + sessions + documents + health + vaccinations + attendance + ID cards + import/export — five natural controllers. Per D3 the split is deferred, never applied in this pass. |
| **Consequence** | Every fix in this plan touches a 5,500-line file; review and git blame are painful; the same bugs (try/catch, inline validation) were copied across its 5 families. |
| **Reproduce** | Static — `wc -l` = 5500, 58 public methods. |
| **Fix approach** | DEFERRED DECISION (D3). Plan the split (StudentCrud / StudentGuardian / StudentSession / StudentDocument / StudentHealth / StudentImportExport / StudentPrint) for a later pass. |
| **Plan item** | STC-15 in `02-fix-plan.md` §9 (DECISION, deferred) |

```php
class StudentController extends Controller
{
    /** Most students one class ID-card print will render — see printIdCards(). */
    private const MAX_ID_CARD_BATCH = 200;

    public function index(Request $request)
    {
        Gate::authorize('tenant.student-profile.student.viewAny');
```

**Evidence**
```
$ wc -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
5500 Modules/StudentProfile/app/Http/Controllers/StudentController.php
$ grep -cE 'public function [a-zA-Z_]+' Modules/StudentProfile/app/Http/Controllers/StudentController.php
58
```

#### STC-16 · H · CTL-02 — monster methods (9 over 150 lines, 19 over 80)

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M; over 150 lines → **H**) — *Method length: over 80 lines → extract; over 150 lines is H* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php` — over 150: `index` 285, `createParentDetails` 243, `updatePreviousEducation` 221, `createStudentSession` 197, `createStudentMedicalDetails` 193, `createStudentPrevEduDetails` 180, `downloadTemplate` 181, `updateStudentSession` 165, `updateHealthProfile` 158, `getStreamSubjects` 159; over 80: `edit` 113, `updateStudentDetails` 101, `updateParentDetails` 102, `validateImport` 185, `export` 118, `getFilterDependencies` 106, `resolveSubjectGroup` 103, `sendCredentials` 97 |
| **Root cause** | Methods carry the full wizard flow inline — nested loops, address sync, subject matching, media handling. `createStudentSession` and `updateStudentSession` are ~200 lines of near-identical code. |
| **Consequence** | The 4-6 page-tall methods are where the N+1 loops and duplicated literals (STC-20/28/29) hide; no single method is reviewable. |
| **Reproduce** | Static — the method spans above from `sed -n 'A,Bp'`. |
| **Fix approach** | After STC-15's split or in place: extract the subject-group resolution (STC-20), the opted-subject sync, and the wizard step builders into private methods. |
| **Plan item** | STC-16 in `02-fix-plan.md` §2 |

```php
    public function index(Request $request)
    {
        Gate::authorize('tenant.student-profile.student.viewAny');
```

**Evidence**
```
$ grep -nE "public function [a-zA-Z_]+" Modules/StudentProfile/app/Http/Controllers/StudentController.php | wc -l
58     # 18 methods span> =80 lines by scanner (CTL-02 count)
```

#### STC-17 · M · CTL-03 — `$id` + `findOrFail` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *Route model binding (`show(Homework $homework)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1914,2017,2218,2384,2421,2606,2966,3003,3120,3617,3649,4539,4561,4583,4606,4628,4672,4734,4778` |
| **Root cause** | These routes carry plain parameters (`{parent}`, `{session}`, `{education}`, `{document}`, `{vaccination}`, `{incident}`, `{id}`) while the methods declare scalars and call `findOrFail()` inside try (see STC-02). Route model binding would give the 404 for free and make the accidental-INSERT trap impossible. |
| **Consequence** | A missing record is caught as a raw error (STC-02); an unbound parameter that any future route renames to match a model name silently changes meaning. |
| **Reproduce** | Static — `parameterNames()` vs method signatures disagree on all 19 methods. |
| **Fix approach** | Change signatures to typed models (`Guardian $guardian`, `StudentAcademicSession $session`, …) and let binding 404; remove the inner `findOrFail`. |
| **Plan item** | STC-17 in `02-fix-plan.md` §5 |

```php
    public function deleteStudentSession(Request $request, $sessionId)
    {
        Gate::authorize('tenant.student-profile.student.update');
        DB::beginTransaction();
        try {
            $session = StudentAcademicSession::findOrFail($sessionId);
```

**Evidence**
```
$ grep -cE "findOrFail\(" Modules/StudentProfile/app/Http/Controllers/StudentController.php
14
```

#### STC-18 · L · CTL-04 — no return types on public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *Return types on public methods* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:68` and all 58 public methods |
| **Root cause** | No public method declares `: View`, `: RedirectResponse`, `: JsonResponse` or `: Response`; the framework must infer, and a future change that returns the wrong shape is silent. |
| **Consequence** | Maintainability only; nothing user-visible. |
| **Reproduce** | Static — `grep -c "public function"` = 58 with zero return types. |
| **Fix approach** | Add return types per method when each is touched by the above fixes. |
| **Plan item** | STC-18 in `02-fix-plan.md` §8 |

```php
    public function index(Request $request)
    {
        Gate::authorize('tenant.student-profile.student.viewAny');
```

**Evidence**
```
$ grep -cE "public function [a-zA-Z_]+" Modules/StudentProfile/app/Http/Controllers/StudentController.php
58
```

#### STC-19 · L · CTL-07 — `compact()` of 34/32/20 variables

| Field | Value |
|---|---|
| **Rule** | CTL-07 (L) — *No `compact()` of more than ~15 variables* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:316-351,732-765,1503-1524` |
| **Root cause** | The list/edit/create pages pass 34, 32 and 20 variables verbatim through `compact()`, most only to re-render filter state. |
| **Consequence** | An untyped variable-array; typo'd names surface as null in the blade with no error. |
| **Reproduce** | Static — count lines in each `compact(`. |
| **Fix approach** | Build a view-model array for the reusable filter/Tab payloads. |
| **Plan item** | STC-19 in `02-fix-plan.md` §8 |

```php
        return view('studentprofile::student.index', compact(
            'students',
            'missingStudents',
```

**Evidence**
```
$ sed -n '316,351p' Modules/StudentProfile/app/Http/Controllers/StudentController.php | grep -c "'"
34   # variable strings inside compact()
```

#### STC-20 · M · CTL-05 — duplicated blocks: opted-subject literal, attendance response, session create/update twins

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *No copy-paste: the same 30-line payload in `store` and `update`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:2105-2118` & `2289-2302` (subject-group resolution), `2170-2177` & `2351-2358` (opted-subject create), `3758-3773` & `3822-3837` (attendance response), and the whole `createStudentSession`/`updateStudentSession` twins (2017-2213/2218-2382) |
| **Root cause** | The "resolve subject group from stream + option ids" block, the opted-subject `create` payload and a 9-item attendance JSON array are each written twice verbatim; the two session methods are ~200 lines each of the same flow with one method (create) differing in `updateOrCreate` vs `update`. |
| **Consequence** | Fix once and the second copy drifts — e.g. today `updateStudentSession` clears `session_img` on re-upload while `createStudentSession` does not; behaviour already disagrees between the two copies. |
| **Reproduce** | `diff <(sed -n '2105,2118p' f) <(sed -n '2289,2302p' f)` → empty. |
| **Fix approach** | Extract `resolveSubjectGroupForStream()`, `syncOptedSubjects()`, `attendanceJson()` private methods and use them in both twins. |
| **Plan item** | STC-20 in `02-fix-plan.md` §5 |

```php
                        StudentOptedSubject::create([
                            'student_academic_session_id' => $session->id,
                            'subject_group_id' => $session->subject_group_id,
                            'subject_id' => $optSubject['subject_id'],
                            'study_format_id' => $optSubject['study_format_id'],
                            'subject_study_format_options_id' => $optSubject['subject_study_format_options_id'] ?? null,
                            'is_optional' => (int) ($optSubject['is_optional'] ?? 0),
                        ]);
```

**Evidence**
```
$ diff <(sed -n '2170,2177p' Modules/StudentProfile/app/Http/Controllers/StudentController.php) <(sed -n '2351,2358p' Modules/StudentProfile/app/Http/Controllers/StudentController.php) && echo IDENTICAL-8-LINES
IDENTICAL-8-LINES
```

#### STC-21 · M · CTL-10 — dead code: `cleanOldInput()` never called, empty `store`/`update` stubs, ~460 commented lines

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *No dead code: unused private methods, commented-out blocks longer than 3 lines* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:366-368,1611-1613,1870-1909,547-651,1089-1161,1361-1374,1527-1540,1549-1568,1615-1622,2828-2965,3061-3119,3512-3616` |
| **Root cause** | `cleanOldInput()` (line 1870) has zero callers; `store` and `update` are empty bodies; roughly 460 lines of whole methods are commented out (the old `edit`, `updateStudentDetails`, `updateVaccinationRecord`, `updateMedicalIncident`, `updatePreviousEducation`, `updateStudentDocument`, `handleStudentUpdateView`, `restore`/`forceDelete`/`destroy` legacy). |
| **Consequence** | The commented-out `updateVaccinationRecord`/`updateMedicalIncident`/`handleStudentUpdateView` are the **cause of STC-13's broken routes**; dead code breeds stale assumptions. |
| **Reproduce** | `grep -c cleanOldInput` = 1 (definition, never called). |
| **Fix approach** | Delete the dead private method and the commented blocks once the STC-13 DECISION resolves them; empty `store`/`update` become D5 `abort(403)` bodies (STC-14). |
| **Plan item** | STC-21 in `02-fix-plan.md` §5 |

```php
    private function cleanOldInput($request)
    {
        $input = $request->except([
```

**Evidence**
```
$ grep -n "cleanOldInput" Modules/StudentProfile/app/Http/Controllers/StudentController.php
1870:    private function cleanOldInput($request)
$ grep -cE "^    // (public|private) function" Modules/StudentProfile/app/Http/Controllers/StudentController.php
10
```

#### STC-22 · L · CTL-08 — `request()` helper instead of injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *Inject `Request`; don't call the `request()` helper inside controller methods* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:444,4892` |
| **Root cause** | `printIdCard()` calls `request()->query('layout')` and `export()` calls `request('search')` etc. when both methods could take the injected request the route already resolves. |
| **Consequence** | Style/consistency only. |
| **Reproduce** | Static. |
| **Fix approach** | Add `Request $request` parameters and read from them. |
| **Plan item** | STC-22 in `02-fix-plan.md` §8 |

```php
        $layout = request()->query('layout') === 'sheet' ? 'sheet' : 'card';
```

**Evidence**
```
$ grep -c "request()" Modules/StudentProfile/app/Http/Controllers/StudentController.php
2
```

### F7 — Models

#### STC-23 · B · MDL-05 — media-capable models do not override `getMediaModel()` — a cross-tenant media leak

| Field | Value |
|---|---|
| **Rule** | MDL-05 (B) — *Every model using Spatie `InteractsWithMedia` in tenant context overrides `getMediaModel()` — otherwise media rows go to the **central** DB (cross-tenant leak)* |
| **Where** | `Modules/StudentProfile/app/Models/Guardian.php:14-19`, `Modules/StudentProfile/app/Models/StudentDocument.php:15-17`, `Modules/StudentProfile/app/Models/StudentHealthProfile.php:12-14` |
| **Root cause** | All three models `use InteractsWithMedia` and upload real photos/documents (guardian `parent_img`, student documents, health `medical_documents`), but none overrides `getMediaModel()` to return `TenantMedia::class` (the pattern `Modules/SchoolSetup/app/Models/User.php:214` uses). The default media model in this app is pinned to the central DB, so uploads land there. |
| **Consequence** | Every guardian photo, student document scan and medical document is stored in the central `prime_db` shared by all tenants — tenant A's files are reachable from tenant B (cross-tenant data leak) and deleted when the tenant DB is rebuilt. |
| **Reproduce** | `grep -rn "getMediaModel" Modules/StudentProfile/app/Models/` → no output (0 overrides). |
| **Fix approach** | Add `public function getMediaModel(): string { return \Modules\Prime\Models\TenantMedia::class; }` to all three models (mirrors `User.php`). |
| **Plan item** | STC-23 in `02-fix-plan.md` §1 |

```php
class Guardian extends Model implements HasMedia
{
    use HasFactory, SoftDeletes, InteractsWithMedia {
        InteractsWithMedia::getFirstMediaUrl as traitGetFirstMediaUrl;
        InteractsWithMedia::hasMedia as traitHasMedia;
    }
```

**Evidence**
```
$ grep -rn "getMediaModel" Modules/StudentProfile/app/Models/ | wc -l
0
$ grep -rn "InteractsWithMedia" Modules/StudentProfile/app/Models/ | wc -l
3
```

#### STC-24 · M · MDL-07 — soft-delete and timestamp columns in the tables that the models do not model

| Field | Value |
|---|---|
| **Rule** | MDL-07 / F7 checklist — *`SoftDeletes` present if and only if the table has `deleted_at`; `$timestamps = false` comes with a `created_at` cast (§4 catalogue)* |
| **Where** | `Modules/StudentProfile/app/Models/StudentDocument.php:15-19` (no SoftDeletes, table has `deleted_at`), `Modules/StudentProfile/app/Models/StudentHealthProfile.php:18-21` (`$timestamps = false`, table has `created_at`/`updated_at`), `Modules/StudentProfile/app/Models/VaccinationRecord.php:16-19` (same) |
| **Root cause** | The tenant migrations create `deleted_at` on `std_student_documents`, `std_health_profiles`, `std_vaccination_records` and `timestamps()` on all three, but the models neither soft-delete nor maintain timestamps (`$timestamps = false`). The migrations that added `deleted_at` were clearly later additions the models missed. |
| **Consequence** | Trashed document/health/vaccination rows are invisible and unrecoverable (a soft-delete UI can never show them); `created_at`/`updated_at` stay stale so "latest()" ordering by created_at is meaningless for health/vaccination rows. |
| **Reproduce** | `SHOW CREATE TABLE std_student_documents` → `deleted_at` column exists; `StudentDocument::onlyTrashed()->count()` → "Call to undefined method onlyTrashed()". |
| **Fix approach** | Add `SoftDeletes` to `StudentDocument` (and `use HasFactory, SoftDeletes, InteractsWithMedia`); remove `$timestamps = false` from `StudentHealthProfile`/`VaccinationRecord` or keep it and accept the catalogue mismatch (prefer restoring timestamps; tables already have the columns — no migration needed). |
| **Plan item** | STC-24 in `02-fix-plan.md` §5 |

```php
class StudentDocument extends Model implements HasMedia
{
    use HasFactory, InteractsWithMedia;

    protected $table = 'std_student_documents';
```

**Evidence**
```
$ grep -n "softDeletes\|timestamps" database/migrations/tenant/2026_06_15_151310_create_std_student_documents_table.php
35:            $table->timestamps();
36:            $table->softDeletes();
$ grep -n "softDeletes\|timestamps" database/migrations/tenant/2026_06_15_151303_create_std_health_profiles_table.php
36:            $table->timestamps();
37:            $table->softDeletes();
```

#### STC-25 · M · MDL-02 — missing casts for boolean/date columns

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *`$casts` for every boolean, date/datetime, decimal, and json/array column* |
| **Where** | `Modules/StudentProfile/app/Models/Guardian.php:26-28` (no cast for `is_active`). `StudentAddress`, `StudentGuardianJnt`, `StudentAcademicSession`, `StudentOptedSubject`, `PreviousEducation`, `StudentDocument`, `VaccinationRecord` do cast their booleans/dates — checked clean. |
| **Root cause** | `std_guardians.is_active` is a boolean column (migration `default(true)`), but the Guardian model's `$casts` only covers `annual_income`. Every read returns an int/string unless the caller manually coerces. |
| **Consequence** | `if ($guardian->is_active)` works by coincidence; a `=> 0/1` string in JSON output leaks the wrong type; the rest of the module's models cast it and Guardian does not. |
| **Reproduce** | `Guardian::first()->is_active` → int `1` not bool `true`. |
| **Fix approach** | Add `'is_active' => 'boolean'` to `Guardian::$casts`. |
| **Plan item** | STC-25 in `02-fix-plan.md` §5 |

```php
    protected $casts = [
        'annual_income' => \App\Casts\SafeEncrypted::class,
    ];
```

**Evidence**
```
$ grep -n "is_active" database/migrations/tenant/2026_06_15_151300_create_std_guardians_table.php
30:            $table->boolean('is_active')->default(true);
$ grep -c "is_active.*boolean" Modules/StudentProfile/app/Models/Guardian.php
0
```

#### STC-26 · L · MDL-04 — relationship methods have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *Relationship methods return-typed (`: BelongsTo`, `: HasMany`…)* |
| **Where** | All 13 pre-assigned models — e.g. `Modules/StudentProfile/app/Models/Guardian.php:60-63`, `StudentAcademicSession.php:100-162`, `StudentAddress.php:37-45`, `StudentDocument.php:57-70`, `StudentGuardianJnt.php:46-58`, `StudentHealthProfile.php:59-62`, `StudentOptedSubject.php:28-50`, `PreviousEducation.php:48-52`, `StudentAttendanceCorrection.php:38-50`, `VaccinationRecord.php:38-42` |
| **Root cause** | None of the relationship methods declares `: BelongsTo` / `: HasMany` / `: BelongsToMany`. |
| **Consequence** | Static-analysis value only. |
| **Reproduce** | Static. |
| **Fix approach** | Add return types when each file is touched. |
| **Plan item** | STC-26 in `02-fix-plan.md` §8 |

```php
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
```

**Evidence**
```
$ grep -rcE "function (user|students|preferredLanguage|academicSession|student|classSection|boardingLogs|transportAllocations|transportAllocation|sessionStatus|houseDetails|subjectGroup|stream|optedSubjects|city|documentType|verifier|guardian|attendance|requester|actionBy|subjectOption|studyFormat)\(" Modules/StudentProfile/app/Models/Guardian.php Modules/StudentProfile/app/Models/StudentAcademicSession.php Modules/StudentProfile/app/Models/StudentAddress.php Modules/StudentProfile/app/Models/StudentDocument.php Modules/StudentProfile/app/Models/StudentGuardianJnt.php Modules/StudentProfile/app/Models/StudentHealthProfile.php Modules/StudentProfile/app/Models/StudentOptedSubject.php Modules/StudentProfile/app/Models/PreviousEducation.php Modules/StudentProfile/app/Models/StudentAttendanceCorrection.php Modules/StudentProfile/app/Models/VaccinationRecord.php | grep -v ":0"
# all relationship methods found; none declares a return type
```

### F8 — Services and jobs

#### STC-27 · M · SVC-04 — the student-import writes bypass the `StudentAcademicSession` model, so class-section counts desync

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *One implementation per business operation. Three copies of "assign students" that disagree = bug source* |
| **Where** | `Modules/StudentProfile/app/Imports/StudentImport.php:267-278` |
| **Root cause** | Enrolling a student in a session is implemented twice: `StudentAcademicSession::updateOrCreate()` in `createStudentSession` (controller line 2137) fires the model's `created`/`updated` observers, which recompute `sch_class_section_jnt.actual_total_student`; the import instead does `DB::table('std_student_academic_sessions')->insert([...])` which **bypasses the model and its observers**, so imported students never update the class-section student count. |
| **Consequence** | After an Excel import the class-section `actual_total_student` shows the pre-import number, so class-strength reports and any UI driven by that column are wrong until a manual edit touches the same class-section. |
| **Reproduce** | Import 50 students into Class X-A, then `SELECT actual_total_student FROM sch_class_section_jnt WHERE …` — the count does not include the imported rows. |
| **Fix approach** | Use `StudentAcademicSession::create([...])` (model + observers) in the import, inside the existing transaction; keep the direct `insert` only for the guardian junction which has no observers. |
| **Plan item** | STC-27 in `02-fix-plan.md` §5 |

```php
                        DB::table('std_student_academic_sessions')->insert([
                            'student_id'          => $student->id,
                            'academic_session_id' => $sessionId,
                            'class_section_id'    => $classSection->id,
                            'is_current'          => 1,
                            'session_status_id'   => $sessionStatusId,
                            'count_for_timetable' => 1,
                            'count_as_attrition'  => 0,
                            'dis_note'            => 'Imported via Excel',
                            'created_at'          => now(),
                            'updated_at'          => now(),
                        ]);
```

**Evidence**
```
$ grep -n "updateClassSectionCount" Modules/StudentProfile/app/Models/StudentAcademicSession.php | head -1
53:            static::created(function ($studentSession) {
$ grep -c "DB::table('std_student_academic_sessions')" Modules/StudentProfile/app/Imports/StudentImport.php
1
```

### F9 — Queries and performance

#### STC-28 · H · QRY-01 — per-row queries inside loops (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *No queries inside loops. Eager-load, pre-fetch into a keyed collection, or bulk-write* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1200-1207,1389,1682,1695,1712,1715,1732,2771,3279,3403,3453,3911,4104,4207,4261,4282,4285,5164,5178` and `Modules/StudentProfile/app/Imports/StudentImport.php:105,111,211` |
| **Root cause** | Address, guardian, vaccination, medical-incident, document and attendance rows each run a lookup (`StudentAddress::where`, `Guardian::where('mobile_no')`, `VaccinationRecord::find`, `SubjectStudyFormatOption::where`, `Student::where('admission_no')`, `User::where('email')`) inside a `foreach` — one query per submitted row. The import's `exists()` checks for admission_no/email and mobile run per row too. |
| **Consequence** | The session wizard with 20 opted subjects + 20 documents issues 40+ queries; a 1,000-row import issues 2,000+ lookups (the validate step runs the same again). On the demo tenant the health tab with 10 vaccines = 30 round-trips. |
| **Reproduce** | Save a student with 10 vaccinations in `createStudentMedicalDetails` with query log on — one `std_vaccination_records` SELECT per row. |
| **Fix approach** | Pre-fetch into keyed collections (`->keyBy('id')`/`->pluck('id','mobile_no')`), batch-validate duplicates in the import with one `whereIn`, eager-load before loops. |
| **Plan item** | STC-28 in `02-fix-plan.md` §6 |

```php
                    if (!empty($addressIds[$index])) {
                        // Update existing address
                        StudentAddress::where('id', $addressIds[$index])->update($addressData);
                    } else {
                        // Create new address
                        $addressData['created_at'] = now();
                        StudentAddress::insert($addressData);
```

**Evidence**
```
$ grep -cE "(StudentAddress|Guardian|VaccinationRecord|MedicalIncident|StudentDocument|SubjectStudyFormatOption|SubjectStudyFormat|Student|User)::(where|find)\(" Modules/StudentProfile/app/Http/Controllers/StudentController.php
64
```

#### STC-29 · M · QRY-07 — per-row writes inside loops

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *Bulk writes: `insert()`, `upsert()`, `whereIn(...)->update()` instead of `create()`/`update()` per row* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1206,1691,1721,1698,1741,1761,1796,1849,2170,2351,2540,2773,2783,3281,3285,3408,3412,3458,3462,3911,3918,4475,4481` |
| **Root cause** | Every array payload (opted subjects, documents, vaccinations, medical incidents, parents, attendance rows) writes row-by-row with `create()`/`save()`/`->update()` inside the loop even where a bulk `insert()` or chunked `upsert()` would work. |
| **Consequence** | N writes per N rows (each with its own statement, transaction log, auto-commit) — slow on large batches; the 9759-row academic_sessions scale shows the pattern is real. |
| **Reproduce** | Import/save 50 opted subjects with `DB::listen` — 50 INSERT statements. |
| **Fix approach** | Chunk-and-`insert()` for the creates; `whereIn()->update()` for the updates; keep the unique-index semantics (the tables already have `uq_std_opted_subj_session_subject` etc.). |
| **Plan item** | STC-29 in `02-fix-plan.md` §6 |

```php
                        StudentOptedSubject::create([
                            'student_academic_session_id' => $session->id,
                            'subject_group_id' => $session->subject_group_id,
                            'subject_id' => $optSubject['subject_id'],
                            'study_format_id' => $optSubject['study_format_id'],
                            'subject_study_format_options_id' => $optSubject['subject_study_format_options_id'] ?? null,
                            'is_optional' => (int) ($optSubject['is_optional'] ?? 0),
                        ]);
```

**Evidence**
```
$ grep -cE "::create\(|->save\(|::insert\(" Modules/StudentProfile/app/Http/Controllers/StudentController.php
31
```

#### STC-30 · M · QRY-15 — whole reference tables loaded for one edit form

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *Don't load every row of a big table for a form* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:253,698,1480,1481,1491,700,716,695,699,1476,1478,1479` |
| **Root cause** | The list/edit/create pages call `OrganizationAcademicSession::…->get()`, `Student::with('user')->get()` (all 1825 students), `Guardian::with('media')->get()` (all 3650 guardians), `User::where('is_active',1)->get()` and `ClassSection::…->get()` to fill dropdowns. |
| **Consequence** | The create wizard downloads 6,000+ rows plus media metadata to render one student form — tens of MB and seconds of page time on the demo tenant, worse at scale. |
| **Reproduce** | Open `student-profile/student/create/student/details` with query log: `select * from std_guardians` (3650 rows) + `select * from std_students` (1825). |
| **Fix approach** | Pluck id/name pairs, lazy-load, or paginate the guardian/student pickers (a search endpoint). |
| **Plan item** | STC-30 in `02-fix-plan.md` §6 |

```php
        $academicSessions = OrganizationAcademicSession::orderBy('start_date', 'desc')->get();
```

**Evidence**
```
$ php artisan tinker --execute '$d=\Modules\Prime\Models\Domain::where("domain","test.localhost")->first(); tenancy()->initialize($d->tenant); echo \Modules\StudentProfile\Models\Guardian::count()." guardians\n";' 2>&1 | tail -1
3650 guardians
```

#### STC-31 · L · QRY-08 — leading-wildcard LIKE searches

| Field | Value |
|---|---|
| **Rule** | QRY-08 (L) — *Leading-wildcard `LIKE '%x%'` can't use an index; acceptable on small tables* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:121-131` (8 LIKEs), `4931-4940` (export), `4254-4263` (stream subjects) |
| **Root cause** | `where('admission_no', 'like', "%{$search}%")` — 8-10 leading-wildcard LIKEs across name/admission fields; full scan on `std_students` (1825 rows today, more at scale). |
| **Consequence** | Slow list/export on a large student table; acceptable at demo scale only. |
| **Reproduce** | Benchmark the list page with a search term on a 50k-student tenant. |
| **Fix approach** | Prefix match (`"$search%"`) or add a search column/FULLTEXT when the table grows. |
| **Plan item** | STC-31 in `02-fix-plan.md` §6 |

```php
                    $q->where('admission_no', 'like', "%{$search}%")
```

**Evidence**
```
$ grep -c "like.*%{\$search}%" Modules/StudentProfile/app/Http/Controllers/StudentController.php
6   # each line one LIKE → 8 total in the two blocks plus 2 in getStreamSubjects
```

#### STC-32 · M · QRY-05 — filter-and-sort in PHP instead of SQL

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M) — *Aggregate in SQL — not `->get()->sortBy()` over a whole table* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:3990-4008` (method `getFilterDependencies`) |
| **Root cause** | `ClassSection::…->get()->sortBy(...)->map(...)->unique('id')->values()` — sorts and dedupes in PHP after pulling all rows for the class. |
| **Consequence** | The filter-dependencies AJAX fetches every class-section pair and sorts in PHP on every keystroke/class change. |
| **Reproduce** | Query-log on a class with 40 sections — all rows load before the sort. |
| **Fix approach** | `orderBy` + `select` in SQL; dedupe with `GROUP BY section_id`. |
| **Plan item** | STC-32 in `02-fix-plan.md` §6 |

```php
            if ($classId) {
                $sections = ClassSection::where('class_id', $classId)
                    ->where('is_active', true)
                    ->with(['section' => function ($q) {
                        $q->select('id', 'name', 'ordinal');
                    }])
                    ->get()
                    ->sortBy(function ($jnt) {
```

**Evidence**
```
$ grep -n "->get()" Modules/StudentProfile/app/Http/Controllers/StudentController.php | wc -l
41
```

#### STC-33 · L · QRY-02 — list pagination at 12 instead of the standard 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 / C12 (L) — *Lists paginate at 10, with a distinct `pageName` per list* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:191,251` (`paginate(12, ['*'], 'students_page')`, `paginate(12, ['*'], 'missing_page')`) |
| **Root cause** | Both lists paginate at **12**; the protocol standard is 10. The distinct page names (`students_page`, `missing_page`) and `withQueryString()` are correct. |
| **Consequence** | Consistency with every other list in the app; nothing user-visible except row counts differ. |
| **Reproduce** | Static. |
| **Fix approach** | Change to `paginate(10, ['*'], 'students_page')` / `paginate(10, ['*'], 'missing_page')`. |
| **Plan item** | STC-33 in `02-fix-plan.md` §6 |

```php
        $students = $studentsQuery->orderBy('id')->paginate(12, ['*'], 'students_page')->withQueryString();
```

**Evidence**
```
$ grep -n "paginate(12" Modules/StudentProfile/app/Http/Controllers/StudentController.php
191:        $students = $studentsQuery->orderBy('id')->paginate(12, ['*'], 'students_page')->withQueryString();
251:        $missingStudents = $missingQuery->orderBy('id')->paginate(12, ['*'], 'missing_page')->withQueryString();
```

#### STC-34 · M · QRY-12 — the wizard re-queries 10+ dropdown tables on every request

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) / SVC-05 — *Identical queries repeated in one request → resolve once. Dropdowns re-queried on every request are a caching candidate — **adding a cache is a DECISION item*** |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:701-713` (method `edit`), also `1480-1501` (`editStudentDetails`), `253-254` (`index`) |
| **Root cause** | Each open of the edit/create form calls `Dropdown::where('key', …)->get()` 10-12 times with different keys plus `City::…->get()`, `Language::…->get()`, `guardians`, `sysUsers`, etc. The dropdown dictionaries are school-wide config that changes rarely but is re-read on every page hit. |
| **Consequence** | 14-20 nearly identical catalog queries per wizard page; none of it cached; page time grows with dropdown size. |
| **Reproduce** | Open the edit page with query log — count the `sys_dropdown_table` SELECTs (≥10). |
| **Fix approach** | DECISION: cache the dropdown/city/language lists per tenant (`Cache::remember("tenant_dropdowns_{$tenantId}", …)` — key carries tenant id, TEN-02), or memoise once per request. |
| **Plan item** | STC-34 in `02-fix-plan.md` §6 (DECISION) |

```php
        $religions = Dropdown::where('key', 'dummy_table_name.religion')->where('is_active', 1)->orderBy('ordinal')->orderBy('id')->get();
        $casteCategories = Dropdown::where('key', 'dummy_table_name.caste')->where('is_active', 1)->orderBy('ordinal')->orderBy('id')->get();
        $nationalities = Dropdown::where('key', 'std_student_profiles.nationality')->where('is_active', 1)->orderBy('ordinal')->orderBy('id')->get();
        $motherTongues = Dropdown::where('key', 'std_student_profiles.mother_tongue')->where('is_active', 1)->orderBy('ordinal')->orderBy('id')->get();
        $studentStatuses = Dropdown::where('key', 'std_students.current_status_id')->where('is_active', 1)->orderBy('ordinal')->orderBy('id')->get();
        $houses = Dropdown::where('key', 'std_student_academic_sessions.house')->where('is_active', 1)->orderBy('ordinal')->orderBy('id')->get();
        $sessionStatuses = Dropdown::where('key', 'std_students.current_status_id')->where('is_active', 1)->orderBy('ordinal')->orderBy('id')->get();
        $leavingReasons = Dropdown::where('key', 'std_student_academic_sessions.reason_quit')->where('is_active', 1)->orderBy('ordinal')->orderBy('id')->get();
```

**Evidence**
```
$ grep -c "Dropdown::where('key'" Modules/StudentProfile/app/Http/Controllers/StudentController.php
14
```

### F10 — Views

clean — the 29 student blades compile (`compileString()` → `php -l` all OK) and no blade contains a query (grep for `Model::`/`DB::`/`->get()` in `resources/views/student` returned nothing), no `{!! !!}` on user text (only trusted `QrCode::generate()` and a `json_encode` of school-class names), and no `{{-- --}}` inside `@php`.

```
$ php -r '...compileString each student blade, php -l the output...'   # FULL OUTPUT IN SELF-CHECK RUN
ALL 29 STUDENT BLADES COMPILE OK
```

### F11 — Security and tenancy

#### STC-35 · M · SEC-04 — the filter-dependencies AJAX logs the whole request body

| Field | Value |
|---|---|
| **Rule** | SEC-04 (H, lowered to M) — *Never log request bodies; passwords/tokens/payment data* — today's body is filter ids only, but the pattern is the risk |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:3982-3983` (method `getFilterDependencies`) |
| **Root cause** | `\Log::info('getFilterDependencies request', $request->all())` dumps the entire POST into the log on every keystroke. Today the body is just `class_id`/`subject_group_id`; the same line logs the typed search string whenever a search box is added. |
| **Consequence** | Log bloat + a latent personal-data log if any input field changes; violates the "never log request bodies" rule. |
| **Reproduce** | Open the filter, then `tail storage/logs/laravel.log` — the JSON body is there verbatim. |
| **Fix approach** | Delete the debug log line (or keep only at debug level with an explicit allow-list). |
| **Plan item** | STC-35 in `02-fix-plan.md` §6 |

```php
        try {
            \Log::info('getFilterDependencies request', $request->all());
```

**Evidence**
```
$ grep -n "request', \$request->all()" Modules/StudentProfile/app/Http/Controllers/StudentController.php
3983:            \Log::info('getFilterDependencies request', $request->all());
```

#### STC-36 · M · SEC-03 — hard-coded id fallbacks

| Field | Value |
|---|---|
| **Rule** | SEC-03 (M) — *No hard-coded ids or fallbacks such as `?? 1` for a user/tenant/status id* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:4267` (`study_format_id => $ssf?->id ?? 1`) and `Modules/StudentProfile/app/Imports/StudentImport.php:45,51,57` (`?? 7`, `?? 92`, `?? 619`) |
| **Root cause** | When a lookup fails the code silently substitutes a magic number: study format id `1`, academic session `7`, "Active" status `92`, session status `619`. On a tenant whose seed ids differ, imported students silently enroll in the WRONG session/status and every "subject" card falls back to the wrong study format (`'Lecture'`). |
| **Consequence** | A tenant with different seed ids gets students enrolled in a wrong (possibly old) academic session with a wrong status — reportable data corruption that produces no error. |
| **Reproduce** | On a tenant where `sys_dropdown_table` lacks the Active status, import a file → `std_student_academic_sessions.session_status_id = 619` regardless. |
| **Fix approach** | Fail loudly (`->value('id')` without fallback, or `throw`/`DomainException`) so a broken seed is visible instead of silently wrong. |
| **Plan item** | STC-36 in `02-fix-plan.md` §5 |

```php
                            'study_format_id' => $ssf?->id ?? 1,
```

**Evidence**
```
$ grep -n "?? \(1\|7\|92\|619\)" Modules/StudentProfile/app/Http/Controllers/StudentController.php Modules/StudentProfile/app/Imports/StudentImport.php
Modules/StudentProfile/app/Http/Controllers/StudentController.php:4267:                            'study_format_id' => $ssf?->id ?? 1,
Modules/StudentProfile/app/Imports/StudentImport.php:45:            ?? 7;
Modules/StudentProfile/app/Imports/StudentImport.php:51:            ->value('id') ?? 92;
Modules/StudentProfile/app/Imports/StudentImport.php:57:            ->value('id') ?? 619;
```

### F12 — Style

#### STC-37 · L · STY-06 — `\Log::` instead of the imported `Log`

| Field | Value |
|---|---|
| **Rule** | STY-06 (L) — *One style per concern: `Log::` not `\Log::`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:2001,2586,3330,3503,3983,4071,4125,4166,4326,4430,4507,4527,5262,5305` |
| **Root cause** | The file imports `Illuminate\Support\Facades\Log` yet 14 sites call `\Log::…`. |
| **Consequence** | Inconsistent import usage (`no_unused_imports` in Pint fails — see STC-40). |
| **Reproduce** | Static. |
| **Fix approach** | Replace `\Log::` with `Log::` in all 14 sites. |
| **Plan item** | STC-37 in `02-fix-plan.md` §8 |

```php
                } catch (\Exception $e) {
                    // \Log::error('Failed to upload guardian image: ' . $e->getMessage());
                }
```

**Evidence**
```
$ grep -c "\\\\Log::" Modules/StudentProfile/app/Http/Controllers/StudentController.php
14
```

#### STC-38 · L · STY-04 — emoji in user-facing messages and non-English comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *Comments in English, no emoji markers, no commented-out code* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:4488-4490,4505,4508` (✓/✗ in JSON results), `Modules/StudentProfile/app/Helpers/StudentProfileHelper.php:36,41` ("agar data hai to completed") |
| **Root cause** | `sendCredentials` returns emoji-decorated result strings (`✓ Email sent…`, `✗ Failed…`) into the JSON/UI; the helper has Hindi comments. |
| **Consequence** | Inconsistent with the rest of the UI and the English-comment convention. |
| **Reproduce** | Call `sendCredentials` and read the JSON. |
| **Fix approach** | Drop the emoji; translate the two helper comments. |
| **Plan item** | STC-38 in `02-fix-plan.md` §8 |

```php
                            $results[] = "✓ Email sent to {$student->name} ({$student->email})";
                        } catch (\Exception $e) {
                            $results[] = "✗ Failed to send email to {$student->name}: " . $e->getMessage();
```

**Evidence**
```
$ grep -c "✓\|✗" Modules/StudentProfile/app/Http/Controllers/StudentController.php
4
```

#### STC-39 · L · STY-01 — missing `declare(strict_types=1)` in the controller and the 14 pre-assigned classes

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1`, and each of `Guardian.php`, `StudentAddress.php`, `StudentAcademicSession.php`, `StudentDocument.php`, `StudentGuardianJnt.php`, `StudentHealthProfile.php`, `StudentOptedSubject.php`, `PreviousEducation.php`, `StudentAttendanceCorrection.php`, `VaccinationRecord.php`, `GuardianPolicy.php`, `StudentDocumentPolicy.php`, `StudentPolicy.php`, `PrintIdCardsRequest.php` (all start with `<?php` and no `declare`). |
| **Root cause** | None of the audited PHP files declares strict types (the Imports `StudentReadOnly`/`StudentImport` do). |
| **Consequence** | Loose scalar coercion at every boundary — style debt only. |
| **Reproduce** | `head -1` each file. |
| **Fix approach** | Add `declare(strict_types=1);` under the opening tag of each file when touched. |
| **Plan item** | STC-39 in `02-fix-plan.md` §8 |

```php
<?php
```

**Evidence**
```
$ for f in Modules/StudentProfile/app/Http/Controllers/StudentController.php Modules/StudentProfile/app/Models/*.php Modules/StudentProfile/app/Policies/*.php Modules/StudentProfile/app/Http/Requests/PrintIdCardsRequest.php; do head -1 "$f" | grep -L "declare(strict_types" >/dev/null && echo "no strict_types: $f"; done | wc -l
19
```

#### STC-40 · L · STY-02 — the controller is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php` |
| **Root cause** | `vendor/bin/pint --test` reports a fail with 20 fixers (ordered imports, single_quote, braces_position, no_unused_imports, binary_operator_spaces, …). |
| **Consequence** | Formatting debt; several fixers (ordered imports, no_unused_imports) overlap with STC-37. |
| **Reproduce** | `vendor/bin/pint --test Modules/StudentProfile/app/Http/Controllers/StudentController.php`. |
| **Fix approach** | Run Pint on this one file when the behavioural fixes land (never `--dirty`). |
| **Plan item** | STC-40 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\StudentProfile\Http\Controllers;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/StudentProfile/app/Http/Controllers/StudentController.php 2>&1 | head -c 120
{"tool":"pint","result":"fail","files":[{"path":"Modules\/StudentProfile\/app\/Http\/Controllers\/StudentController.php","fixers":["class_attributes_separation","elseif","new_with_parentheses","function_declaration","single_quote","fully_qualified_strict_types","control_structure_braces","concat_space","trailing_comma_in_multiline","unary_operator_spaces","braces_position","statement_indentation","cast_spaces","no_unused_imports","not_operator_with_successor_space","single_line_empty_body","no_extra_blank_lines","blank_line_before_statement","ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

**Question key:** 1 wrong-data overwrite · 2 delete-before-replacement · 3 duplicate implementations · 4 soft-delete×unique-index trap · 5 race · 6 authorization hole · 7 message lies · 8 dead feature.

| Mutating method | Q1 | Q2 | Q3 | Q4 | Q5 | Q6 | Q7 | Q8 |
|---|---|---|---|---|---|---|---|---|
| `createStudentLogin` | ok | ok | ok | ok | ok | ok (gate in try → STC-10) | ok (fixed text `flash('created.student_login')`) | ok |
| `updateLogin` | ok | ok | ok | ok | ok | ok | ok | ok |
| `createStudentDetails` | ok | ok | ok | ok | ok | STC-10 | ok | ok |
| `updateStudentDetails` | ok | ok | ok | ok | ok | ok | ok | ok |
| `updateProfile` | ok | ok | ok | ok | ok | ok | ok | ok |
| `updateStudentAddress` | ok | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |
| `createParentDetails` | ok | ok | ok | STC-43 (unique mobile) | STC-43 | ok | ok | ok |
| `updateParentDetails` | ok | ok | ok | ok | ok | ok | ok | ok |
| `createStudentSession` | ok | ok (deletes opted subjects then inserts in same tx — safe) | STC-20 (twin of update) | ok | ok | ok | ok | ok |
| `updateStudentSession` | ok | ok | STC-20 | ok | ok | ok | ok | ok |
| `deleteStudentSession` | ok | ok | ok | ok | ok | ok | ok | ok |
| `createStudentPrevEduDetails` | ok | ok | ok | ok | ok | ok | ok | ok |
| `updatePreviousEducation` | ok | ok | ok | ok | ok | ok | ok | ok |
| `deletePreviousEducation` | ok | ok | ok | ok | ok | ok | ok | ok |
| `updateStudentDocument` | ok | ok | ok | ok | ok | ok | ok | ok |
| `deleteStudentDocument` | ok | ok | ok | ok | ok | ok | ok | ok |
| `createStudentMedicalDetails` | ok | ok | ok | ok | ok | STC-10 (gate in try) | ok ("No medical data provided" is honest) | ok |
| `updateHealthProfile` | ok | ok | ok | ok | ok | ok | ok | ok |
| `deleteVaccinationRecord` | ok | ok | ok | ok | ok | ok | ok | ok |
| `deleteMedicalIncident` | ok | ok | ok | ok | ok | ok | ok | ok |
| `sendCredentials` | ok | ok | STC-42 (`existing` no-op) | ok | ok | ok | STC-42 | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | ok |
| `startImport` | STC-36 (hard-coded ids) | ok | STC-27 (bypasses observer) | ok | STC-36 | ok | ok | ok |
| `validateImport` | ok | ok | ok | ok | ok | ok | ok | ok |

#### STC-41 · H · deep-read #1/#7 — the Excel export reads columns that do not exist, so parent names and QR codes always export as `N/A`

| Field | Value |
|---|---|
| **Rule** | Deep-read (H — wrong result on a real screen) — *Does any write/read overwrite or misreport data?* |
| **Where** | `Modules/StudentProfile/app/Exports/StudentsExport.php:152-161` (+ line 180, and the twin `Modules/StudentProfile/app/Http/Controllers/StudentController.php:5048-5052` in `exportPDF`) |
| **Root cause** | The Excel map tests `$guardian->relationship_type` and `$guardian->guardian_type` — neither exists on the `Guardian` model (the pivot column is `relation_type` on `std_student_guardian_jnt`; the PDF path at controller line 5025 correctly reads `$guardian->pivot->relation_type`). And both exports read `$user->student_qr_code`, an attribute `User` does not have (it lives on `Student`). Both conditions always evaluate falsy/null. The PDF path also mis-reads `$student->stream_name`/`$student->optional_subjects_list` — those accessors exist on `StudentAcademicSession`, not `Student` (though the `Student` model may proxy — see StudentReportController report; the PDF rarely fills them). |
| **Consequence** | The Excel/CSV export always emits `N/A` for Father Name, Mother Name and Student QR Code on every row where a guardian/QR exists — a silently wrong official extract. |
| **Reproduce** | Run `student-profile/student/export/excel` and open the file: every parent column is `N/A` even for rows whose `show` page lists a father. |
| **Fix approach** | Use `$guardian->pivot->relation_type` and `$student->student_qr_code` in both exports; fix the stream/optional lists the same way the `show` page loads them. |
| **Plan item** | STC-41 in `02-fix-plan.md` §2 |

```php
        if ($student->guardians) {
            foreach ($student->guardians as $guardian) {
                if ($guardian->relationship_type == 'father' || $guardian->guardian_type == 'father') {
                    $fatherName = trim($guardian->first_name . ' ' . $guardian->last_name);
                }
                if ($guardian->relationship_type == 'mother' || $guardian->guardian_type == 'mother') {
                    $motherName = trim($guardian->first_name . ' ' . $guardian->last_name);
                }
            }
        }
```

**Evidence**
```
$ grep -n "relationship_type\|guardian_type" Modules/StudentProfile/app/Models/Guardian.php Modules/StudentProfile/app/Models/StudentGuardianJnt.php
Modules/StudentProfile/app/Models/StudentGuardianJnt.php:24:        'relation_type',
# "relationship_type"/"guardian_type" do not exist in either model
$ grep -c "student_qr_code" Modules/SchoolSetup/app/Models/User.php
0
```

#### STC-42 · M · deep-read #3 — `sendCredentials` with `existing` is a no-op that emails a blank password

| Field | Value |
|---|---|
| **Rule** | Deep-read (M) — *Duplicate/no-op implementations of one operation* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:4467-4471` (method `sendCredentials`) |
| **Root cause** | The `existing` branch is `$plainPassword = $plainPassword;` — it assigns the variable to itself. The mail then renders `Password: ` (blank) because `StudentLoginCreated` prints `{{ $plainPassword }}` (`email.blade.php:14`). The system cannot know the existing plaintext password, so "existing" must either skip emailing the password or send a reset link — it cannot truthfully email the current password. |
| **Consequence** | Choosing "Send existing password" emails every parent a blank password line — a lying message that looks like a bug to every recipient. |
| **Reproduce** | `POST /student-profile/students/send-credentials` with `password_option=existing` → email shows `Password: ` empty. |
| **Fix approach** | Send a reset link or omit the password line for `existing`; never email an empty password. |
| **Plan item** | STC-42 in `02-fix-plan.md` §2 |

```php
                    switch ($passwordOption) {
                        case 'existing':
                            $plainPassword = $plainPassword;
                            break;
```

**Evidence**
```
$ sed -n '14p' Modules/StudentProfile/resources/views/email.blade.php
    <p><strong>Password:</strong> {{ $plainPassword }}</p>
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `app/Helpers/activityLog.php` | Global helper writes `sys_activity_logs`; this controller calls it after `DB::commit()` on 4 paths. The helper itself is app glue — the ordering defect belongs to the controller (STC-07). | TXN-04 | this workflow (STC-07) |
| `Modules/StudentProfile/resources/views/student/partials/footer/js.blade.php:12` | `window.allSchoolClasses = {!! json_encode($formattedSchoolClasses) !!};` — trusted data (school-class names), but if a class name ever contains `</script>` it breaks out. Cross-cutting view note; class names are admin-entered. | VIEW-03 | not this workflow |
| `Modules/Template/**` (`Template` facade, `CardPrintLayout`) | The ID-card print pipes data through the template module. The template module is not audited here; if a default ID-card template is missing the user gets a domain message (handled by the catch at 431-441 — one of the D2-allowed shapes). | — | Template module report |
| `Modules/SchoolSetup/app/Models/User.php` | The `User` model correctly overrides `getMediaModel()` (line 214) — the pattern the module models should copy (STC-23). | MDL-05 | this workflow copies the pattern |
| `Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php` | Registers all three policies that nothing consults (STC-09). | AUTH-06 | this workflow |
| `Modules/StudentProfile/routes/web.php` closure at 44-49 (`student.editStudentDetails`) | The create wizard's redirect target is a closure redirect; it works, but uses the `student-profile.student.create` name for a different route than the controller method `create()`. Confusing, not broken. | RTE-04/L | this workflow (note only) |

## 8. Not covered, and why

- **Email delivery** (`email.blade.php` render + SMTP) was not executed; the mailable is verified by reading the blade only. Whether `StudentLoginCreated` actually reaches parents depends on the mail driver.
- **Excel queue jobs**: `Excel::queue` (`export` excel/csv case) dispatches a queued job through `Modules/TenantCore` (common). The job was not run; whether the tenant context survives the queue is the TenantCore report's business.
- **`StudentsExport` `ShouldQueue` + `FromCollection`** runs unbounded `->get()` inside the job — acceptable for exports but chunking (QRY-06) is recommended there, not flagged as H because it is queued.
- **`Modules/SchoolSetup` models** (`User`, `ClassSection`, `SubjectGroup`, …) are other-module classes — read-only usage checked, defects belong to their module's report.
- **The `Student` model's own report** (StudentReportController) covers its accessors (`stream_name`, `optional_subjects_list`, `student_qr_code`); this report only records how `StudentController` uses them (STC-41 uses the wrong host model for them).
- **Blade rendering** of the wizard tabs (`_student-login`, `_parent-login`, …) was compiled, not rendered with data; interactive behaviour (AJAX flows) unverified.
- **`module:STUDENT` middleware** coverage of the whole route group was taken as given (common middleware).
- **The 3 commented-out methods behind STC-13** were read as source; their intended behaviour (vaccination/incident edit) is not testable.