# Final Audit — Complaint / ComplaintActionController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Complaint/app/Http/Controllers/ComplaintActionController.php` (72 lines, 7 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `POST /complaint/complaint-actions` (`store`), `GET /complaint/complaint-actions/{complaint_action}` (`show`), `DELETE /complaint/complaint-actions/{complaint_action}` (`destroy`), `GET /complaint/complaint-actions/{id}/restore` (`restore`), `DELETE /complaint/complaint-actions/{id}/force-delete` (`forceDelete`). Host on this machine is the tenant domain for tenant DB `xyz_school_00000000000040008000_202627` (⚠ UNVERIFIED — the exact host was not printed by the read-only probe). |
| Menu path | **None.** No `glb_menus` row references `complaint-actions` (see evidence in F3). The real Complaint "Actions" tab is served by a *different* controller: route `complaint-actions.index` → `ComplaintController@index` (`Modules/Complaint/routes/web.php:142`), reached from the tenant menu "Complaint" (`glb_menus` id 297, `route = complaint.complaint-mgt.index`). These five URLs are only reachable by typing them directly. |
| Who uses it | Roles that hold the permissions, measured from `sys_role_has_permissions_jnt` on the tenant DB: **Super Admin** and **School Admin** (both hold all eight `tenant.complaint.complaint-action.*` keys). |
| What a user does here | Intended to add a timeline/audit action against a complaint, view one, delete one, restore a deleted one and force-delete one. In practice **nothing on this screen works**: the two `{id}/restore` and `{id}/force-delete` methods do not exist (500), `show` points at a Blade file that does not exist (500), and `store`/`destroy` authorize and then do nothing (HTTP 200, no change). |
| Tables written | Intended: `cmp_complaint_actions`. Actually: **none** — the controller runs no `DB::`, no `save()`/`create()`/`update()`/`delete()`, no `activityLog()` (see F2 evidence). |
| Tables read | None — the controller runs no query of any kind. |
| Live data | Tenant DB `xyz_school_00000000000040008000_202627`: `cmp_complaint_actions` **30 live rows, 0 trashed**; `cmp_complaints` **12 rows**. |

**How to reach each bug in the browser:** each finding below names the URL under **Reproduce**.

## 1. Verdict

This controller is **not production-ready and is reachable today**, so it carries two live blockers. It is a leftover nwidart scaffold: `index`/`create`/`edit`/`update` are unrouted, `store`/`destroy` are routed but silently do nothing, `show` is routed but renders `complaint::show`, a Blade file that does not exist, and the `restore`/`forceDelete` routes point at methods the class never had. The single worst finding is **CACT-01**: `GET /complaint/complaint-actions/{id}/restore` and `DELETE /complaint/complaint-actions/{id}/force-delete` return HTTP 500 on every call because `restore()` and `forceDelete()` are absent, even though both permissions are seeded for Super Admin and School Admin. The clean disposition is a Tarun decision (blocker **CACT-01**, DECISION): disable this scaffold per D5 and drop its five orphan routes, since the real Actions tab is already served by `ComplaintController@index`. Effort to apply the recommended plan: **S** (one small controller rewrite plus a route-file removal behind the SHARED tick).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 1 | 1 | 4 | 1 | 8 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | clean |
| F3 Authorization | clean | F10 Views | see CACT-04 (F6) |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | CACT-01, CACT-02, CACT-03 | F12 Style | CACT-06, CACT-07, CACT-08 |
| F6 Controller shape | CACT-04, CACT-05 | F13 Deep read | CACT-01, CACT-03, CACT-04 (table) |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Complaint/app/Http/Controllers/ComplaintActionController.php` | controller | 72 | this report | ✅ |
| 2 | `Modules/Complaint/resources/views/index.blade.php` | blade (`complaint::index`) | 7 | this report | ✅ |
| 3 | `Modules/Complaint/resources/views/create.blade.php` | blade (`complaint::create`) | 0 | this report | ❌ missing |
| 4 | `Modules/Complaint/resources/views/show.blade.php` | blade (`complaint::show`) | 0 | this report | ❌ missing |
| 5 | `Modules/Complaint/resources/views/edit.blade.php` | blade (`complaint::edit`) | 0 | this report | ❌ missing |
| 6 | `Modules/Complaint/routes/web.php` | route file (⚠ SHARED) | 198 | route-file owner | ↗ linked (findings recorded here; edits go through the SHARED decision) |
| 7 | `Modules/Complaint/app/Models/ComplaintAction.php` | model | — | ↗ [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) (`_Info/00-CLASS-OWNERS.md:433`) | ↗ linked — not audited here |

The controller imports no service, FormRequest, policy, job or event, so no other module class is in scope. The `complaint::` view namespace is bound to `Modules/Complaint/resources/views` by `ComplaintServiceProvider::registerViews()` (`loadViewsFrom($sourcePath, 'complaint')`, lines 153–160). No pre-applied files.

## 4. Routes

```
POST      complaint/complaint-actions                             complaint.complaint-actions.store   Modules\Complaint\Http\Controllers\ComplaintActionController@store
GET|HEAD  complaint/complaint-actions/{complaint_action}          complaint.complaint-actions.show    Modules\Complaint\Http\Controllers\ComplaintActionController@show
DELETE    complaint/complaint-actions/{complaint_action}          complaint.complaint-actions.destroy Modules\Complaint\Http\Controllers\ComplaintActionController@destroy
DELETE    complaint/complaint-actions/{id}/force-delete           complaint.complaint-actions.forceDelete Modules\Complaint\Http\Controllers\ComplaintActionController@forceDelete
GET|HEAD  complaint/complaint-actions/{id}/restore                complaint.complaint-actions.restore Modules\Complaint\Http\Controllers\ComplaintActionController@restore
```

Unrouted public methods:
- `index` (`ComplaintActionController.php:17`)
- `create` (`:27`)
- `edit` (`:54`)
- `update` (`:64`)

Routed actions with **no** matching method: `restore` and `forceDelete` (see CACT-01). Note `complaint-actions.index` does **not** point at this class — it points at `ComplaintController@index` (`Modules/Complaint/routes/web.php:142`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | none (unrouted) | `tenant.complaint.complaint-action.viewAny` | none | none | none | CACT-03 |
| `create` | 27 | none (unrouted) | `tenant.complaint.complaint-action.create` | none | none | none | CACT-03, CACT-04 |
| `store` | 37 | POST /complaint/complaint-actions | `tenant.complaint.complaint-action.create` | none | none | none | CACT-04 |
| `show` | 44 | GET /complaint/complaint-actions/{complaint_action} | `tenant.complaint.complaint-action.view` | none | none | none | CACT-04 |
| `edit` | 54 | none (unrouted) | `tenant.complaint.complaint-action.update` | none | none | none | CACT-03, CACT-04 |
| `update` | 64 | none (unrouted) | none | none | none | none | CACT-03 |
| `destroy` | 69 | DELETE /complaint/complaint-actions/{complaint_action} | `tenant.complaint.complaint-action.delete` | none | none | none | CACT-04 |

The routes `restore` and `forceDelete` have no row because the class has no such methods (CACT-01). Neither route carries a `Gate::authorize` — only the global `auth` + tenancy middleware group.

## 6. Findings

### F1 — Errors

clean — `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintActionController.php -Pattern 'try\s*\{','catch\s*\(','getMessage','report\(','Log::'` → no output. There is no `try`/`catch` and no exception text reaches a user (D1 satisfied).

### F2 — Transactions and audit

clean — `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintActionController.php -Pattern 'DB::transaction|->create\(|->update\(|->delete\(|->save\(|activityLog|firstOrCreate|updateOrCreate'` → no output. The controller performs no write, so there is no mutation to wrap in a transaction and no audit row to place.

### F3 — Authorization

clean for the three routed methods that exist. Each authorizes **before** loading anything, with a permission that is declared in `config/permissionslist.php:861` and seeded in the tenant DB with all four surfaces consistent (controller string = seeded name).

Evidence:
```
$ Select-String -Path "config\permissionslist.php" -Pattern "complaint-action"
861:         'complaint.complaint-action' => array_merge($crud, ['export']),

$ tenant sys_permissions (tenant.complaint.complaint-action.*):
create, view, viewAny, update, delete, restore, forceDelete, export  (ids 2392–2399)

$ roles holding them: Super Admin, School Admin (all eight)
```
The permission names follow `scope.module.feature.action` (for example `tenant.complaint.complaint-action.create`). `store` uses the write key `.create`, `destroy` uses the write key `.delete`, `show` uses the read key `.view` — no read-only permission is used for a write, so F3 is clean. The unrouted methods are reported as CACT-03 (F5), not duplicated here.

### F4 — Validation and input

clean — `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintActionController.php -Pattern 'validate\(','->all\(\)','->except\(','validated\(\)'` → no output. There is no write path, so no unvalidated input can reach a model. `store(Request $request)` receives a `Request` but writes nothing; that is reported as CACT-04, not as a VAL blocker.

### F5 — Routes

#### CACT-01 · B · RTE-02 — two live routes call methods that do not exist (HTTP 500)

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *every route points to a method that exists* |
| **Where** | Route registration `Modules/Complaint/routes/web.php:147-155` (`restore`, `forceDelete`); the class `ComplaintActionController.php` has no such methods (public methods are `index`, `create`, `store`, `show`, `edit`, `update`, `destroy`) |
| **Root cause** | The route file registers `restore()` and `forceDelete()` against `ComplaintActionController`, but the class was generated without them (an unfinished nwidart scaffold). Nothing else in the app supplies the methods. |
| **Consequence** | Any user who opens `/complaint/complaint-actions/{id}/restore` or calls `DELETE /complaint/complaint-actions/{id}/force-delete` gets HTTP 500 (Laravel `BadMethodCallException`) — the route exists, the action does not, so the controller is never reached. |
| **Reproduce** | As School Admin (holds `.restore`/`.forceDelete`), open `/complaint/complaint-actions/1/restore` in the browser → 500 error page. Static proof of the missing methods is below. |
| **Fix approach** | Tarun decides (plan CACT-01, DECISION): either add `restore()`/`forceDelete()` to the controller, or remove the two orphan route blocks from the route file (⚠ SHARED). Recommended: remove the routes and disable the scaffold, because the real Actions tab is served by `ComplaintController@index`. |
| **Plan item** | CACT-01 in `02-fix-plan.md` §1 (DECISION) |

```php
// Modules/Complaint/routes/web.php:147-155 — CURRENT
Route::get(
    'complaint-actions/{id}/restore',
    [ComplaintActionController::class, 'restore']
)->name('complaint-actions.restore');

Route::delete(
    'complaint-actions/{id}/force-delete',
    [ComplaintActionController::class, 'forceDelete']
)->name('complaint-actions.forceDelete');
```

**Evidence**
```
$ $env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --json 2>$null | php routesprobe.php "Modules\Complaint\Http\Controllers\ComplaintActionController"
DELETE    complaint/complaint-actions/{id}/force-delete           complaint.complaint-actions.forceDelete Modules\Complaint\Http\Controllers\ComplaintActionController@forceDelete
GET|HEAD  complaint/complaint-actions/{id}/restore                complaint.complaint-actions.restore Modules\Complaint\Http\Controllers\ComplaintActionController@restore

$ method_exists probe (Modules\Complaint\Http\Controllers\ComplaintActionController):
index=YES
create=YES
store=YES
show=YES
edit=YES
update=YES
destroy=YES
restore=NO
forceDelete=NO
```

#### CACT-02 · H · RTE-01 — `restore` is a state change over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Complaint/routes/web.php:147-150` — `Route::get('complaint-actions/{id}/restore', …)` |
| **Root cause** | `restore` un-deletes a row (a write) but was registered with `Route::get`, unlike its sibling `force-delete` which correctly uses `Route::delete`. |
| **Consequence** | Once `restore()` is implemented, a browser/preview link prefetcher or a crawler following the URL can silently restore a deleted complaint action, and the request carries no CSRF token. Today this path 500s first (CACT-01), so the risk is latent. |
| **Reproduce** | static only — the method does not exist yet, so no state changes; the route verb is the defect. |
| **Fix approach** | Covered by the CACT-01 disposition: option (a) removes the route entirely; if the route is kept, change `Route::get` to `Route::post`/`Route::delete`. |
| **Plan item** | none — see plan §10 (resolved by the CACT-01 disposition) |

```php
// Modules/Complaint/routes/web.php:147-150 — CURRENT
Route::get(
    'complaint-actions/{id}/restore',
    [ComplaintActionController::class, 'restore']
)->name('complaint-actions.restore');
```

**Evidence**
```
$ $env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --json 2>$null | php routesprobe.php "Modules\Complaint\Http\Controllers\ComplaintActionController"
GET|HEAD  complaint/complaint-actions/{id}/restore                complaint.complaint-actions.restore Modules\Complaint\Http\Controllers\ComplaintActionController@restore
DELETE    complaint/complaint-actions/{id}/force-delete           complaint.complaint-actions.forceDelete Modules\Complaint\Http\Controllers\ComplaintActionController@forceDelete

$ Select-String -Path Modules\Complaint\routes\web.php -Pattern "complaint-actions"
147: Route::get(
148: 'complaint-actions/{id}/restore',
150: )->name('complaint-actions.restore');
```

#### CACT-03 · M · RTE-03 — four public methods are unrouted (D5)

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`)*; under protocol D5 the disabled body becomes `abort(403, '…')` with a `NOT ROUTED` comment, and the method is never deleted |
| **Where** | `ComplaintActionController.php:17` (`index`), `:27` (`create`), `:54` (`edit`), `:64` (`update`) |
| **Root cause** | The resource was registered with `->only(['store', 'show', 'destroy'])` (`web.php:143-145`), and `complaint-actions.index` points at `ComplaintController@index`, so these four methods can never be reached. |
| **Consequence** | Dead, misleading code that still shows up in IDE search; if a future route is added naively it would resurrect an empty/no-op body. |
| **Reproduce** | static only — no route resolves to these four methods (see §4). |
| **Fix approach** | Apply D5: replace each body with `abort(403, '…')` plus a `NOT ROUTED` comment. |
| **Plan item** | CACT-03 in `02-fix-plan.md` §5 |

```php
// ComplaintActionController.php:17-64 — CURRENT (the four unrouted methods)
    public function index()
    {
        
        Gate::authorize('tenant.complaint.complaint-action.viewAny');
return view('complaint::index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        
        Gate::authorize('tenant.complaint.complaint-action.create');
return view('complaint::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {
        Gate::authorize('tenant.complaint.complaint-action.create');
}

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        
        Gate::authorize('tenant.complaint.complaint-action.view');
return view('complaint::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        
        Gate::authorize('tenant.complaint.complaint-action.update');
return view('complaint::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id) {}
```

**Evidence**
```
$ Select-String -Path "Modules\Complaint\app\Http\Controllers\ComplaintActionController.php" -Pattern 'public function'
17:     public function index()
27:     public function create()
37:     public function store(Request $request) {
44:     public function show($id)
54:     public function edit($id)
64:     public function update(Request $request, $id) {}
69:     public function destroy($id) {

$ $env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --json 2>$null | php routesprobe.php "Modules\Complaint\Http\Controllers\ComplaintActionController"
(no rows whose action is @index, @create, @edit or @update)
```

### F6 — Controller shape

#### CACT-04 · B · CTL-10 — unfinished scaffold: the routed `show` 500s, `store`/`destroy` are silent no-ops

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M default, **raised to B** — the defect is reachable today on a normal path and produces a 500, so it is a blocker, not dead code) — *no dead code; the deep-read item 8 (dead feature) applies* |
| **Where** | `ComplaintActionController.php:31` (`create` → `complaint::create`), `:48` (`show` → `complaint::show`), `:58` (`edit` → `complaint::edit`), and the no-op bodies at `:37-39` (`store`) and `:69-71` (`destroy`) |
| **Root cause** | The class is a leftover nwidart scaffold. `complaint::create`, `complaint::show` and `complaint::edit` have no file under `Modules/Complaint/resources/views/` (only `index.blade.php` exists); `store` and `destroy` authorize and then return without writing anything. |
| **Consequence** | `GET /complaint/complaint-actions/{id}` (the routed `show`) returns HTTP 500 "View [complaint::show] not found" for every caller; `POST /complaint/complaint-actions` and `DELETE /complaint/complaint-actions/{id}` return HTTP 200 while changing nothing, so the UI reports success on a delete that never happened. |
| **Reproduce** | As School Admin (holds `.view`), open `/complaint/complaint-actions/1` → 500. `POST` the store URL with any body → 200, and `cmp_complaint_actions` is unchanged. |
| **Fix approach** | No separate fix: whichever CACT-01 option is chosen resolves this (option (a) replaces every body with `abort(403)`; option (b) adds the missing views and write logic). |
| **Plan item** | none — see plan §10 (covered by the CACT-01 DECISION) |

```php
// ComplaintActionController.php:37-71 — CURRENT (no-op writes and missing-view renders)
    public function store(Request $request) {
        Gate::authorize('tenant.complaint.complaint-action.create');
}

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        
        Gate::authorize('tenant.complaint.complaint-action.view');
return view('complaint::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        
        Gate::authorize('tenant.complaint.complaint-action.update');
return view('complaint::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id) {}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {
        Gate::authorize('tenant.complaint.complaint-action.delete');
}
```

**Evidence**
```
$ bootstrap probe, view()->exists() for each of the four names:
complaint::index=EXISTS
complaint::create=MISSING
complaint::show=MISSING
complaint::edit=MISSING

$ Test-Path (module view root):
"Modules\Complaint\resources\views\index.blade.php"  → True
"Modules\Complaint\resources\views\show.blade.php"   → False
```

#### CACT-05 · L · CTL-04 — public methods declare no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `ComplaintActionController.php:17, 27, 37, 44, 54, 64, 69` — every public method |
| **Root cause** | The scaffold stubs were written as `public function index()` with no return-type clause, and the `use Illuminate\View\View;` / `use Illuminate\Http\RedirectResponse;` imports are never used. |
| **Consequence** | Editors and static analysis cannot infer the response type; no user-visible effect. |
| **Reproduce** | static only — style finding. |
| **Fix approach** | Covered by the chosen disposition: option (a) gives each method `: never` (the `abort(403)` body); the unrouted four also gain `: never` via CACT-03. |
| **Plan item** | none — see plan §10 (folded into CACT-01 / CACT-03) |

```php
// ComplaintActionController.php:17-18 — CURRENT
    public function index()
    {
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintActionController.php -Pattern ': View|: RedirectResponse|: JsonResponse|: never|: RedirectResponse'
(no output)
```

### F7 — Models

clean — the controller imports and references no model: `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintActionController.php -Pattern '::find','::create','::where'` → no output. The `ComplaintAction` model is not touched by this controller and is owned by `gaurav/Complaint/ComplaintController` (`_Info/00-CLASS-OWNERS.md:433`).

### F8 — Services and jobs

clean — `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintActionController.php -Pattern '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification|Export|Import)\b'` → no output. No service, job, event, mail or notification is referenced.

### F9 — Queries and performance

clean — `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintActionController.php -Pattern 'foreach','->get\(','paginate','::all','where\(','orderBy'` → no output. The controller runs no query.

### F10 — Views

clean for the one view that exists — `Modules/Complaint/resources/views/index.blade.php` (7 lines) has no query (`Model::`/`DB::`/`->get()`/`@foreach`) and its only `{!! !!}` is `{!! config('complaint.name') !!}` (trusted config, not user text). The three missing views (`create`/`show`/`edit`) are recorded as **CACT-04** (F6).

### F11 — Security and tenancy

clean — `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintActionController.php -Pattern 'env\(','Log::','\?\? 1'` → no output. No `env()` outside config, no logging of request data, no hard-coded ids/fallback, no cache. Tenant middleware is present on all five routes (see §4 middleware group: `InitializeTenancyByDomain` + `EnsureTenantIsActive`).

### F12 — Style

#### CACT-06 · L · STY-01 — the file has no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `ComplaintActionController.php:1-3` (header) |
| **Root cause** | The scaffold was generated without a strict-types declaration. |
| **Consequence** | None user-visible; consistency only. |
| **Reproduce** | static only — style finding. |
| **Fix approach** | Add `declare(strict_types=1);` immediately after `<?php`. |
| **Plan item** | CACT-06 in `02-fix-plan.md` §8 (the single style item for this file) |

```php
// ComplaintActionController.php:1-3 — CURRENT
<?php

namespace Modules\Complaint\Http\Controllers;
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintActionController.php -Pattern 'declare\(strict_types'
(no output)
```

#### CACT-07 · L · STY-02 — the file is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines* |
| **Where** | `ComplaintActionController.php` (whole file) |
| **Root cause** | The scaffold has unsorted/unused imports, mis-indented statements, and blank-line/brace-position deviations; `RedirectResponse` and `View` are imported but unused. |
| **Consequence** | None user-visible; fails the project's Pint gate. |
| **Reproduce** | static only — style finding. |
| **Fix approach** | Run `vendor/bin/pint` on this file (the CACT-06 style item). |
| **Plan item** | CACT-06 in `02-fix-plan.md` §8 |

```php
// ComplaintActionController.php:5-10 — CURRENT (unused, unsorted imports)
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Gate;
use Illuminate\View\View;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
```

**Evidence**
```
$ vendor\bin\pint --test "Modules\Complaint\app\Http\Controllers\ComplaintActionController.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Complaint\\app\\Http\\Controllers\\ComplaintActionController.php","fixers":["braces_position","statement_indentation","no_unused_imports","single_line_empty_body","no_extra_blank_lines","blank_line_before_statement","ordered_imports","no_whitespace_in_blank_line"]}]}
```

#### CACT-08 · L · STY-04 — seven copy-pasted scaffold docblocks

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *no copy-pasted docblocks that describe another resource; docblocks only where they add meaning* |
| **Where** | `ComplaintActionController.php:14-16, 24-26, 34-36, 41-43, 51-53, 61-63, 66-68` |
| **Root cause** | Generator boilerplate ("Display a listing of the resource." …) that describes generic CRUD, not this class. |
| **Consequence** | None user-visible; the comments mislead a reader once the methods are disabled or implemented. |
| **Reproduce** | static only — style finding. |
| **Fix approach** | Remove the seven docblocks (folded into the style item CACT-06). |
| **Plan item** | CACT-06 in `02-fix-plan.md` §8 |

```php
// ComplaintActionController.php:14-16 — CURRENT (one of seven identical scaffold docblocks)
    /**
     * Display a listing of the resource.
     */
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintActionController.php -Pattern 'Display a listing|Show the form|Store a newly|Show the specified|Update the specified|Remove the specified'
15:     * Display a listing of the resource.
25:     * Show the form for creating a new resource.
35:     * Store a newly created resource in storage.
42:     * Show the specified resource.
52:     * Show the form for editing the specified resource.
62:     * Update the specified resource in storage.
67:     * Remove the specified resource from storage.
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutating method | 1 overwrite? | 2 delete-before-store? | 3 duplicate impl? | 4 soft-delete × unique? | 5 race? | 6 auth hole? | 7 message lies? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` (`:37`) | ok (no write) | ok | ok | ok | ok | ok (Gate `.create`) | CACT-04 (200, no change) | CACT-04 |
| `update` (`:64`) | ok (no write) | ok | ok | ok | ok | CACT-03 (unrouted, no gate) | ok | CACT-03 |
| `destroy` (`:69`) | ok (no write) | ok | ok | ok | ok | ok (Gate `.delete`) | CACT-04 (200, no change) | CACT-04 |
| `restore` (route only) | ok | ok | ok | ok | ok | CACT-01 (no method) | CACT-01 | CACT-01 |
| `forceDelete` (route only) | ok | ok | ok | ok | ok | CACT-01 (no method) | CACT-01 | CACT-01 |

No method writes any row, so questions 1–5 have no live instance; question 6 is carried by the unrouted/missing-method findings; question 7 and 8 are carried by CACT-04.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Complaint/routes/web.php:143-155` | A route file (⚠ SHARED) registers `restore`/`forceDelete` against methods the class never had, and points `complaint-actions` at an unfinished scaffold. A route-file change needs an explicit SHARED tick (§8.2). | RTE-02 / RTE-01 | route-file owner / main session (via the CACT-01 DECISION) |
| `config/permissionslist.php:861` | `'complaint.complaint-action' => array_merge($crud, ['export'])` declares an `export` ability no method of this controller uses. Harmless; noted for completeness. | AUTH-06 (dead permission surface) | `ComplaintController` report / main session |
| `Modules/Complaint/app/Models/ComplaintAction.php` | Owned by `gaurav/Complaint/ComplaintController` (`_Info/00-CLASS-OWNERS.md:433`); this controller does not use it, so it is not audited here. | — | `gaurav/Complaint/ComplaintController` |

## 8. Not covered, and why

- **Scanner and self-check skipped.** Per Tarun's tooling override for this run, `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are **missing** (`Test-Path` → `False` for both), so `scan.php` was **not** run and the §15 self-check was **not** run. The F1–F13 checklist above was worked manually with the `read` tool, `Select-String`, `php -l`, the uncached `route:list` probe, a bootstrap `method_exists`/`view()->exists` probe, tenant-DB queries, and `vendor/bin/pint --test`.
- **Exact tenant host for the URLs** — ⚠ UNVERIFIED. The read-only probe identified the tenant DB (`xyz_school_00000000000040008000_202627`) and its domains table (`prm_tenant_domains`) but did not print the host string; the URLs given are route paths, and the host is whatever domain the tenant serves on.
- **`restore`/`forceDelete` behaviour** — cannot be run: the methods do not exist, so no request can reach past the 500. Recorded as CACT-01.
- **The three missing views** — their files do not exist, so their contents are unavailable; that absence is the finding CACT-04 itself.
- **Pint-fixed output** — `vendor/bin/pint` was not run in write mode (read-only audit); only `--test` was run, so the exact post-Pint diff is not captured. CACT-07 records the failing fixer list.
