# Fix Plan — Complaint / ComplaintCategoryController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | shared config — no new permission is needed (all used keys already exist and are seeded) |
| `database/migrations/**` | never edit an existing migration (standing rule) |
| `resources/views/components/**` | shared components (`form-dropdown`, `status-switch`, `action-trashed`, `modal`, `search-bar`, `export-buttons`) |
| `resources/views/components/backend/layouts/**` | shared layouts |
| `Modules/GlobalMaster/app/Models/Dropdown.php` | owned by the GlobalMaster module |
| `Modules/SchoolSetup/app/Models/EntityGroup.php`, `Department.php` | owned by the SchoolSetup module |
| `Modules/Complaint/app/Http/Controllers/ComplaintController.php` | the category-list owner — audited by its own report |
| `Modules/Complaint/resources/views/complaint/category/index.blade.php` | rendered by `ComplaintController@index` |
| `final-audit-reports/_Info/00-CLASS-OWNERS.md`, `gaurav/Complaint/00-INDEX.md` | append-only registries, not edited by the fixer here |
| `Modules/Complaint/routes/web.php` | shared route file — touched **only** by the explicitly-ticked `⚠ SHARED` item CCAT-08 |

## 1. Blockers reachable today

- [ ] **CCAT-18** · H · TXN-03/F13 · `ComplaintCategoryController.php:269` — make the force-delete child check see soft-deleted children so the DB cascade cannot silently hard-delete them.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Before** (`ComplaintCategoryController.php:269`):
    ```php
            $hasChildren = ComplaintCategory::where('parent_id', $category->id)->exists();
    ```
  - **After:**
    ```php
            $hasChildren = ComplaintCategory::withTrashed()->where('parent_id', $category->id)->exists();
    ```
  - **Verify:** `grep -n "hasChildren" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Expect:** the line reads `ComplaintCategory::withTrashed()->where('parent_id', $category->id)->exists();`
  - **Effort:** S

- [ ] **CCAT-08** · H · RTE-01 · `Modules/Complaint/routes/web.php:60` — stop restoring a category over GET; the shared trash component already renders a POST+CSRF form for a non-GET restore route.
  - **Touches:** `Modules/Complaint/routes/web.php`  ⚠ SHARED
  - **Before** (`Modules/Complaint/routes/web.php:60`):
    ```php
    Route::get('complaint-categories/{id}/restore', [ComplaintCategoryController::class, 'restore'])->name('complaint-categories.restore');
    ```
  - **After:**
    ```php
    Route::post('complaint-categories/{id}/restore', [ComplaintCategoryController::class, 'restore'])->name('complaint-categories.restore');
    ```
  - **Verify:** `grep -n "categories/{id}/restore" Modules/Complaint/routes/web.php`
  - **Expect:** the line begins `Route::post('complaint-categories/{id}/restore'`.
  - **Effort:** XS
  - **Note:** the restore button is rendered by `resources/views/components/backend/table/action-trashed.blade.php`, which reads the route's own methods (`$restoreRoute->methods()`) and emits a `POST` form with `@csrf` when the route is not GET — so no component or blade edit is needed. Re-check the trash page after applying (browser check, Tarun's hand).

- [ ] **CCAT-19** · M · F13 · `ComplaintCategoryController.php:169-201` — add the same child guard to `destroy()` that `forceDelete()` already has, and drop the forbidden `try/catch` (D1) in the same rewrite.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Before** (`ComplaintCategoryController.php:169-201`):
    ```php
    public function destroy($id)
    {
        Gate::authorize('tenant.complaint.complaint-category.delete');

        $category = ComplaintCategory::findOrFail($id);

        try {
            DB::transaction(function () use ($category) {
                // optional: deactivate before delete
                $category->is_active = false;
                $category->save();

                $category->delete();

                activityLog($category, 'Deleted', [
                    'message' => 'Complaint category deleted'
                ]);
            });

            return redirect()
                ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
                ->with('success', 'Complaint category deleted successfully!');
        } catch (\Throwable $e) {
            Log::error('Failed to delete complaint category: ' . $e->getMessage(), [
                'id' => $category->id,
                'exception' => get_class($e),
            ]);

            return redirect()
                ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
                ->with('error', flash('operation_failed.complaint_category', 'Failed to delete the complaint category.'));
        }
    }
    ```
  - **After:**
    ```php
    public function destroy($id)
    {
        Gate::authorize('tenant.complaint.complaint-category.delete');

        $category = ComplaintCategory::findOrFail($id);

        if (ComplaintCategory::where('parent_id', $category->id)->exists()) {
            return redirect()
                ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
                ->with('error', 'Cannot delete a category that has subcategories.');
        }

        DB::transaction(function () use ($category) {
            $category->delete();

            activityLog($category, 'Deleted', [
                'message' => 'Complaint category deleted'
            ]);
        });

        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
            ->with('success', 'Complaint category deleted successfully!');
    }
    ```
  - **Verify:** `grep -n "Cannot delete a category that has subcategories\|category->save()" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Expect:** the guard line appears; `$category->save();` no longer appears in `destroy()`. (`CCAT-01` then needs no change to `destroy()`.)
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **CCAT-01** · M · ERR-00 (D1) · controller `store:68-90`, `update:127-162`, `restore:236-257`, `forceDelete:277-298`, `toggleStatus:316-341` — remove the forbidden `try/catch (\Throwable)` wrappers (D1). Also removes the `Log::error(... getMessage())` calls (CCAT-02). `destroy()` is handled by CCAT-19.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Before — imports** (`ComplaintCategoryController.php:5-15`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Complaint\Models\ComplaintCategory;
    use Modules\GlobalMaster\Models\Dropdown;
    use Modules\SchoolSetup\Models\Department;
    use Modules\SchoolSetup\Models\EntityGroup;
    use Modules\Complaint\Http\Requests\ComplaintCategoryRequest;
    ```
  - **After — imports:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Complaint\Models\ComplaintCategory;
    use Modules\GlobalMaster\Models\Dropdown;
    use Modules\SchoolSetup\Models\Department;
    use Modules\SchoolSetup\Models\EntityGroup;
    use Modules\Complaint\Http\Requests\ComplaintCategoryRequest;
    ```
  - **Before — `store`** (`ComplaintCategoryController.php:62-91`):
    ```php
    public function store(ComplaintCategoryRequest $request)
    {
        Gate::authorize('tenant.complaint.complaint-category.create');

        $data = $request->validated();

        try {
            DB::transaction(function () use ($data) {
                $category = ComplaintCategory::create($data);

                activityLog($category, 'Created', [
                    'message' => 'Complaint category created.',
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });

            return redirect()
                ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
                ->with('success', flash('created.complaint_category'));
        } catch (\Throwable $e) {
            Log::error('Failed to create complaint category: ' . $e->getMessage(), [
                'exception' => get_class($e),
                'data' => $data,
            ]);

            return redirect()
                ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
                ->with('error', flash('operation_failed.complaint_category', 'Failed to create the complaint category.'));
        }
    }
    ```
  - **After — `store`:**
    ```php
    public function store(ComplaintCategoryRequest $request)
    {
        Gate::authorize('tenant.complaint.complaint-category.create');

        $data = $request->validated();

        DB::transaction(function () use ($data) {
            $category = ComplaintCategory::create($data);

            activityLog($category, 'Created', [
                'message' => 'Complaint category created.',
                'performed_by' => Auth::user()->name ?? null,
            ]);
        });

        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
            ->with('success', flash('created.complaint_category'));
    }
    ```
  - **Before — `update`** (`ComplaintCategoryController.php:120-163`):
    ```php
    public function update(ComplaintCategoryRequest $request, $id)
    {
        Gate::authorize('tenant.complaint.complaint-category.update');

        $category = ComplaintCategory::findOrFail($id);
        $data = $request->validated();

        try {
            DB::transaction(function () use ($category, $data) {
                $original = $category->getOriginal();

                $category->update($data);

                $changes = [];
                foreach ($category->getChanges() as $field => $newValue) {
                    if ($field === 'updated_at')
                        continue;
                    $changes[$field] = [
                        'old' => $original[$field] ?? null,
                        'new' => $newValue,
                    ];
                }

                activityLog($category, 'Updated', [
                    'message' => 'Complaint category updated.',
                    'changes' => $changes,
                    'performed_by' => Auth::user()->name ?? null,
                ]);
            });

            return redirect()
                ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
                ->with('success', flash('updated.complaint_category'));
        } catch (\Throwable $e) {
            Log::error('Failed to update complaint category: ' . $e->getMessage(), [
                'id' => $id,
                'exception' => get_class($e),
            ]);

            return redirect()
                ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
                ->with('error', flash('operation_failed.complaint_category', 'Failed to update the complaint category.'));
        }
    }
    ```
  - **After — `update`:**
    ```php
    public function update(ComplaintCategoryRequest $request, $id)
    {
        Gate::authorize('tenant.complaint.complaint-category.update');

        $category = ComplaintCategory::findOrFail($id);
        $data = $request->validated();

        DB::transaction(function () use ($category, $data) {
            $original = $category->getOriginal();

            $category->update($data);

            $changes = [];
            foreach ($category->getChanges() as $field => $newValue) {
                if ($field === 'updated_at')
                    continue;
                $changes[$field] = [
                    'old' => $original[$field] ?? null,
                    'new' => $newValue,
                ];
            }

            activityLog($category, 'Updated', [
                'message' => 'Complaint category updated.',
                'changes' => $changes,
                'performed_by' => Auth::user()->name ?? null,
            ]);
        });

        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
            ->with('success', flash('updated.complaint_category'));
    }
    ```
  - **Before — `restore`** (`ComplaintCategoryController.php:229-258`):
    ```php
    public function restore($id)
    {
        Gate::authorize('tenant.complaint.complaint-category.restore');

        $category = ComplaintCategory::onlyTrashed()
            ->findOrFail($id);

        try {
            DB::transaction(function () use ($category) {
                $category->restore();

                activityLog($category, 'Restored', [
                    'message' => 'Complaint category restored'
                ]);
            });

            return redirect()
                ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
                ->with('success', 'Complaint category restored successfully!');
        } catch (\Throwable $e) {
            Log::error('Failed to restore complaint category: ' . $e->getMessage(), [
                'id' => $id,
                'exception' => get_class($e),
            ]);

            return redirect()
                ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
                ->with('error', flash('operation_failed.complaint_category', 'Failed to restore the complaint category.'));
        }
    }
    ```
  - **After — `restore`:**
    ```php
    public function restore($id)
    {
        Gate::authorize('tenant.complaint.complaint-category.restore');

        $category = ComplaintCategory::onlyTrashed()
            ->findOrFail($id);

        DB::transaction(function () use ($category) {
            $category->restore();

            activityLog($category, 'Restored', [
                'message' => 'Complaint category restored'
            ]);
        });

        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
            ->with('success', 'Complaint category restored successfully!');
    }
    ```
  - **Before — `forceDelete` body** (`ComplaintCategoryController.php:277-298`):
    ```php
        try {
            DB::transaction(function () use ($category) {
                $category->forceDelete();

                activityLog($category, 'Force Deleted', [
                    'message' => 'Complaint category permanently deleted'
                ]);
            });

            return redirect()
                ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
                ->with('success', 'Complaint category permanently deleted!');
        } catch (\Throwable $e) {
            Log::error('Failed to force delete complaint category: ' . $e->getMessage(), [
                'id' => $id,
                'exception' => get_class($e),
            ]);

            return redirect()
                ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
                ->with('error', flash('operation_failed.complaint_category', 'Failed to permanently delete the complaint category.'));
        }
    ```
  - **After — `forceDelete` body:**
    ```php
        DB::transaction(function () use ($category) {
            $category->forceDelete();

            activityLog($category, 'Force Deleted', [
                'message' => 'Complaint category permanently deleted'
            ]);
        });

        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'category'])
            ->with('success', 'Complaint category permanently deleted!');
    }
    ```
  - **Before — `toggleStatus`** (`ComplaintCategoryController.php:306-342`):
    ```php
    public function toggleStatus(Request $request, $id)
    {
        Gate::authorize('tenant.complaint.complaint-category.update');

        $request->validate([
            'is_active' => 'required|boolean',
        ]);

        $category = ComplaintCategory::withTrashed()->findOrFail($id);

        try {
            DB::transaction(function () use ($category, $request) {
                $category->is_active = (bool) $request->is_active;
                $category->save();

                activityLog($category, 'Toggled', [
                    'message' => 'Complaint category status toggled.',
                ]);
            });

            return response()->json([
                'success' => true,
                'is_active' => $category->is_active,
                'message' => flash('status_updated.complaint_category'),
            ]);
        } catch (\Throwable $e) {
            Log::error('Failed to toggle complaint category status: ' . $e->getMessage(), [
                'id' => $id,
                'exception' => get_class($e),
            ]);

            return response()->json([
                'success' => false,
                'message' => flash('status_switch_failed.complaint_category', 'Failed to change the status of the complaint category.'),
            ], 500);
        }
    }
    ```
  - **After — `toggleStatus`:**
    ```php
    public function toggleStatus(Request $request, $id)
    {
        Gate::authorize('tenant.complaint.complaint-category.update');

        $request->validate([
            'is_active' => 'required|boolean',
        ]);

        $category = ComplaintCategory::withTrashed()->findOrFail($id);

        DB::transaction(function () use ($category, $request) {
            $category->is_active = (bool) $request->is_active;
            $category->save();

            activityLog($category, 'Toggled', [
                'message' => 'Complaint category status toggled.',
            ]);
        });

        return response()->json([
            'success' => true,
            'is_active' => $category->is_active,
            'message' => flash('status_updated.complaint_category'),
        ]);
    }
    ```
  - **Verify:** `grep -n "catch (" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Expect:** no output (after CCAT-19 also removes `destroy()`'s catch).
  - **Effort:** M

## 4. Authorization (F3)

- [ ] **CCAT-05** · L · AUTH-04 · `ComplaintCategoryController.php:64,122` — drop the two controller gates that duplicate the FormRequest's `authorize()` for `store`/`update`.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Before** (`ComplaintCategoryController.php:62-66`):
    ```php
    public function store(ComplaintCategoryRequest $request)
    {
        Gate::authorize('tenant.complaint.complaint-category.create');

        $data = $request->validated();
    ```
  - **After:**
    ```php
    public function store(ComplaintCategoryRequest $request)
    {
        $data = $request->validated();
    ```
  - **Before** (`ComplaintCategoryController.php:120-125`):
    ```php
    public function update(ComplaintCategoryRequest $request, $id)
    {
        Gate::authorize('tenant.complaint.complaint-category.update');

        $category = ComplaintCategory::findOrFail($id);
    ```
  - **After:**
    ```php
    public function update(ComplaintCategoryRequest $request, $id)
    {
        $category = ComplaintCategory::findOrFail($id);
    ```
  - **Verify:** `grep -n "Gate::authorize('tenant.complaint.complaint-category.create')\|Gate::authorize('tenant.complaint.complaint-category.update')" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Expect:** only `edit` (line ~98) and `toggleStatus` (line ~308) remain — the `store`/`update` duplicates are gone and `ComplaintCategoryRequest::authorize()` still guards both.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **CCAT-07** · M · VAL-07 · `ComplaintCategoryRequest.php` — reject a `parent_id` that is a descendant of the record, closing the self-ancestor cycle.
  - **Touches:** `Modules/Complaint/app/Http/Requests/ComplaintCategoryRequest.php`
  - **Before — imports** (`ComplaintCategoryRequest.php:5-7`):
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    ```
  - **After — imports:**
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Modules\Complaint\Models\ComplaintCategory;
    ```
  - **Before — end of `rules()`** (`ComplaintCategoryRequest.php:87-90`):
    ```php
                'is_medical_check_required' => 'boolean',
                'is_active' => 'boolean',
            ];
        }
    ```
  - **After — end of `rules()` plus the new methods:**
    ```php
                'is_medical_check_required' => 'boolean',
                'is_active' => 'boolean',
            ];
        }

        public function after(): array
        {
            return [
                function (\Illuminate\Validation\Validator $validator) {
                    $id = $this->route('complaint_category') ?? $this->route('id');
                    if (is_object($id)) {
                        $id = $id->id;
                    }

                    $parentId = $this->input('parent_id');

                    if (! $id || ! $parentId) {
                        return;
                    }

                    if (in_array((int) $parentId, $this->descendantIds((int) $id), true)) {
                        $validator->errors()->add('parent_id', 'The selected parent category is a sub-category of this category.');
                    }
                },
            ];
        }

        private function descendantIds(int $id): array
        {
            $ids = [];
            $queue = [$id];

            while ($queue) {
                $current = array_shift($queue);
                $children = ComplaintCategory::where('parent_id', $current)->pluck('id')->all();

                foreach ($children as $child) {
                    if (! in_array($child, $ids, true)) {
                        $ids[] = $child;
                        $queue[] = $child;
                    }
                }
            }

            return $ids;
        }
    ```
  - **Verify:** `grep -n "public function after\|descendantIds" Modules/Complaint/app/Http/Requests/ComplaintCategoryRequest.php`
  - **Expect:** both names appear.
  - **Effort:** M

- [ ] **CCAT-09** · M · RTE-03 (D5) · `ComplaintCategoryController.php:22-27` — disable the unrouted `index()` per D5.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Before** (`ComplaintCategoryController.php:22-27`):
    ```php
    public function index()
    {
        Gate::authorize('tenant.complaint.complaint-category.viewAny');

        return redirect()->route('complaint.complaint-mgt.index', ['tab' => 'category']);
    }
    ```
  - **After:**
    ```php
    public function index()
    {
        // NOT ROUTED — the category list is served by ComplaintController@index
        // (route complaint.complaint-categories.index). Kept per final-audit D5.
        abort(403, 'This endpoint is not routed.');
    }
    ```
  - **Verify:** `grep -n "NOT ROUTED\|abort(403" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Expect:** both appear at `index()`.
  - **Effort:** XS

## 6. Queries & performance (F9)

- [ ] **CCAT-14** · M · QRY-15/QRY-03 · `ComplaintCategoryController.php:37-50,101-106` — select only the columns the dropdowns need, and drop the two unused `Dropdown` queries in `edit()`.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Before — `create()`** (`ComplaintCategoryController.php:37-50`):
    ```php
            $parentCategories = ComplaintCategory::whereNull('parent_id')->get();
            // $severityLevels = DB::table('sys_dropdown_table')
            //     ->where('key', 'severity_level')
            //     ->where('is_active', 1)
            //     ->orderBy('value')
            //     ->get();
            // $priorityScores = DB::table('sys_dropdown_table')
            //     ->where('key', 'priority_score')
            //     ->where('is_active', 1)
            //     ->orderBy('value')
            //     ->get();
            $groups = EntityGroup::all();

            $departments = Department::select('id', 'name')->get();
    ```
  - **After — `create()`:**
    ```php
            $parentCategories = ComplaintCategory::whereNull('parent_id')->get(['id', 'name']);
            $groups = EntityGroup::get(['id', 'name']);

            $departments = Department::select('id', 'name')->get();
    ```
  - **Before — `edit()`** (`ComplaintCategoryController.php:100-106`):
    ```php
            $category = ComplaintCategory::findOrFail($id);
            $parentCategories = ComplaintCategory::whereNull('parent_id')
                ->where('id', '!=', $id)
                ->get();
            $severityLevels = Dropdown::where('type', 'SEVERITY_LEVEL')->get();
            $priorityScores = Dropdown::where('type', 'PRIORITY_SCORE')->get();
            $groups = EntityGroup::all();
    ```
  - **After — `edit()`:**
    ```php
            $category = ComplaintCategory::findOrFail($id);
            $parentCategories = ComplaintCategory::whereNull('parent_id')
                ->where('id', '!=', $id)
                ->get(['id', 'name']);
            $groups = EntityGroup::get(['id', 'name']);
    ```
  - **Verify:** `grep -n "severityLevels\|priorityScores\|EntityGroup::all" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Expect:** no output.
  - **Effort:** S
  - **Note:** the `edit` view does not read `$severityLevels`/`$priorityScores` (the `form-dropdown` component loads severity/priority by `key`). If the developer would rather keep the variables, CCAT-12 is the item that removes them — do not tick both.

## 7. Views (F10)

- [ ] **CCAT-16** · L · F13 · `show.blade.php:55-67,72-84` — remove the dead `severity_label`/`priority_label` branches (no such columns).
  - **Touches:** `Modules/Complaint/resources/views/complaint/category/show.blade.php`
  - **Before** (`show.blade.php:54-67`):
    ```php
                                            <td>
                                                @if ($category->severityLevel || isset($category->severity_label))
                                                    <span
                                                        class="badge 
                                                        @if (isset($category->severity_label) && in_array(strtolower($category->severity_label), ['high', 'critical', 'urgent'])) badge-danger
                                                        @elseif(isset($category->severity_label) && in_array(strtolower($category->severity_label), ['medium', 'moderate'])) badge-warning
                                                        @elseif(isset($category->severity_label) && in_array(strtolower($category->severity_label), ['low', 'minor'])) badge-info
                                                        @else badge-secondary @endif">
                                                        {{ $category->severityLevel?->value ?? ($category->severity_label ?? '-') }}
                                                    </span>
                                                @else
                                                    <span class="text-muted">-</span>
                                                @endif
                                            </td>
    ```
  - **After:**
    ```php
                                            <td>
                                                @if ($category->severityLevel)
                                                    <span class="badge badge-secondary">
                                                        {{ $category->severityLevel->value }}
                                                    </span>
                                                @else
                                                    <span class="text-muted">-</span>
                                                @endif
                                            </td>
    ```
  - **Before** (`show.blade.php:71-84`):
    ```php
                                            <td>
                                                @if ($category->priorityScore || isset($category->priority_label))
                                                    <span
                                                        class="badge 
                                                        @if (isset($category->priority_label) && in_array(strtolower($category->priority_label), ['high', 'urgent', 'critical'])) badge-danger
                                                        @elseif(isset($category->priority_label) && in_array(strtolower($category->priority_label), ['medium', 'normal'])) badge-warning
                                                        @elseif(isset($category->priority_label) && in_array(strtolower($category->priority_label), ['low'])) badge-info
                                                        @else badge-secondary @endif">
                                                        {{ $category->priorityScore?->value ?? ($category->priority_label ?? '-') }}
                                                    </span>
                                                @else
                                                    <span class="text-muted">-</span>
                                                @endif
                                            </td>
    ```
  - **After:**
    ```php
                                            <td>
                                                @if ($category->priorityScore)
                                                    <span class="badge badge-secondary">
                                                        {{ $category->priorityScore->value }}
                                                    </span>
                                                @else
                                                    <span class="text-muted">-</span>
                                                @endif
                                            </td>
    ```
  - **Verify:** `grep -n "severity_label\|priority_label" Modules/Complaint/resources/views/complaint/category/show.blade.php`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **CCAT-11** · L · CTL-04 · `ComplaintCategoryController.php` — add return types to the ten responding public methods.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Before — imports** (`ComplaintCategoryController.php:5-8`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    ```
  - **After — imports:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Contracts\View\View;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    ```
  - **Before/After — signatures:**
    - `public function create()` → `public function create(): View`
    - `public function store(ComplaintCategoryRequest $request)` → `public function store(ComplaintCategoryRequest $request): RedirectResponse`
    - `public function edit($id)` → `public function edit($id): View`
    - `public function update(ComplaintCategoryRequest $request, $id)` → `public function update(ComplaintCategoryRequest $request, $id): RedirectResponse`
    - `public function destroy($id)` → `public function destroy($id): RedirectResponse`
    - `public function trashed()` → `public function trashed(): View`
    - `public function restore($id)` → `public function restore($id): RedirectResponse`
    - `public function forceDelete($id)` → `public function forceDelete($id): RedirectResponse`
    - `public function toggleStatus(Request $request, $id)` → `public function toggleStatus(Request $request, $id): JsonResponse`
    - `public function show($id)` → `public function show($id): View`
    - `index()` is left untyped (CCAT-09 turns it into `abort()`).
  - **Verify:** `grep -nE "public function (create|store|edit|update|destroy|trashed|restore|forceDelete|toggleStatus|show).*\): (View|JsonResponse|RedirectResponse)" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Expect:** ten matching lines.
  - **Effort:** S

- [ ] **CCAT-12** · L · CTL-10 · `ComplaintCategoryController.php` — remove the dead `show()` branch and the unused commented blocks.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Before** (`ComplaintCategoryController.php:361-366`):
    ```php
            if (request()->ajax()) {
                return view('complaint::complaint.category.show', compact('category'));
            }

            return view('complaint::complaint.category.show', compact('category'));
        }
    ```
  - **After:**
    ```php
            return view('complaint::complaint.category.show', compact('category'));
        }
    ```
  - **Before — commented block in `create()`** (`ComplaintCategoryController.php:38-47`): the six commented `DB::table('sys_dropdown_table')` lines removed together with the `$severityLevels`/`$priorityScores` leftovers from CCAT-14; if CCAT-14 was not ticked, delete only these comment lines.
  - **After:** those comment lines are gone.
  - **Note:** `Dropdown` import (`line 12`) becomes unused once CCAT-14 removes the two `Dropdown::where` calls; run Pint (CCAT-17) or delete the import here.
  - **Verify:** `grep -n "request()->ajax()" Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CCAT-13** · L · MDL-04 · `ComplaintCategory.php:94-180` — add return types to the relationship methods.
  - **Touches:** `Modules/Complaint/app/Models/ComplaintCategory.php`
  - **Before — imports** (`ComplaintCategory.php:5-7`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **After — imports:**
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Before/After — methods:**
    - `public function parent()` → `public function parent(): BelongsTo`
    - `public function children()` → `public function children(): HasMany`
    - `public function recursiveChildren()` → `public function recursiveChildren(): HasMany`
    - `public function severityLevel()` → `public function severityLevel(): BelongsTo`
    - `public function priorityScore()` → `public function priorityScore(): BelongsTo`
    - `public function complaints()` → `public function complaints(): HasMany`
    - `public function departmentSlas()` → `public function departmentSlas(): HasMany`
    - `public function subCategoryComplaints()` → `public function subCategoryComplaints(): HasMany`
    - `public function aiPredictedInsights()` → `public function aiPredictedInsights(): HasMany`
    - `public function l1Group()` → `public function l1Group(): BelongsTo`
    - `public function l2Group()` → `public function l2Group(): BelongsTo`
    - `public function l3Group()` → `public function l3Group(): BelongsTo`
    - `public function l4Group()` → `public function l4Group(): BelongsTo`
    - `public function l5Group()` → `public function l5Group(): BelongsTo`
    - `public function scopeParents($query)` → `public function scopeParents($query)` (scopes are left as-is)
  - **Verify:** `grep -nE "public function (parent|children|recursiveChildren|severityLevel|priorityScore|complaints|departmentSlas|subCategoryComplaints|aiPredictedInsights|l[1-5]Group)\(\): (BelongsTo|HasMany)" Modules/Complaint/app/Models/ComplaintCategory.php`
  - **Expect:** fourteen matching lines.
  - **Effort:** S

- [ ] **CCAT-17** · L · STY-01/02/04/05 · three files — run Pint and add `strict_types`; remove the unused imports.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php`, `Modules/Complaint/app/Models/ComplaintCategory.php`, `Modules/Complaint/app/Http/Requests/ComplaintCategoryRequest.php`
  - **Before — model top** (`ComplaintCategory.php:1-11`):
    ```php
    <?php

    namespace Modules\Complaint\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Facades\Auth;
    use Modules\GlobalMaster\Models\Dropdown;
    use Modules\SchoolSetup\Models\Department;
    use Modules\SchoolSetup\Models\EntityGroup;
    ```
  - **After — model top:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Models;

    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Facades\Auth;
    use Modules\GlobalMaster\Models\Dropdown;
    use Modules\SchoolSetup\Models\EntityGroup;
    ```
    (`HasFactory` and `Department` are unused — remove both; `strict_types` added. Removing the observers per CCAT-03 would also remove `Auth`.)
  - **Before — controller / FormRequest first line:** `<?php` with no `declare(strict_types=1);`.
  - **After:** add `declare(strict_types=1);` directly under `<?php` in both files, then run Pint.
  - **Verify:** `vendor/bin/pint Modules/Complaint/app/Http/Controllers/ComplaintCategoryController.php Modules/Complaint/app/Models/ComplaintCategory.php Modules/Complaint/app/Http/Requests/ComplaintCategoryRequest.php` then `vendor/bin/pint --test` on those same three files with `--format agent`
  - **Expect:** the first command reports fixed files; the second prints `result":"pass"`.
  - **Effort:** S
  - **Note:** do not add `strict_types` to `show.blade.php` (not a PHP class file). Pint is run per-file, never `--dirty` (standing rule).

## 9. Deferred / decisions

- [ ] **CCAT-03** · H · DECISION · TXN-04 — every create/update/delete writes two audit rows (three for `destroy`) because the model observers and the controller both call `activityLog()`.
  - **Why it is a decision:** a behaviour choice — which layer owns the audit trail and which event names survive.
  - (a) ⭐ **remove the model's `booted()` observers** (`ComplaintCategory.php:19-50`) and keep the controller's richer logs (`'Created'`/`'Updated'`/`'Deleted'`/`'Restored'`/`'Force Deleted'`/`'Toggled'`, with the `changes` detail). One row per controller action. This also removes the empty `catch` blocks (CCAT-04).
    - **Before** (`ComplaintCategory.php:17-55`):
      ```php
          protected $table = 'cmp_complaint_categories';

          protected static function booted(): void
          {
              static::created(function (self $category) {
                  try {
                      activityLog($category, 'Stored', [
                          'message'      => 'Complaint category created.',
                          'performed_by' => Auth::user()->name ?? null,
                      ]);
                  } catch (\Throwable $e) {
                  }
              });

              static::updated(function (self $category) {
                  try {
                      activityLog($category, 'Updated', [
                          'message'      => 'Complaint category updated.',
                          'performed_by' => Auth::user()->name ?? null,
                      ]);
                  } catch (\Throwable $e) {
                  }
              });

              static::deleted(function (self $category) {
                  try {
                      activityLog($category, 'Trashed', [
                          'message'      => 'Complaint category deleted.',
                          'performed_by' => Auth::user()->name ?? null,
                      ]);
                  } catch (\Throwable $e) {
                  }
              });
          }

          /**
           * Mass assignable attributes
           */
          protected $fillable = [
      ```
    - **After:**
      ```php
          protected $table = 'cmp_complaint_categories';

          /**
           * Mass assignable attributes
           */
          protected $fillable = [
      ```
    - **Verify:** `grep -n "static::created\|static::updated\|static::deleted" Modules/Complaint/app/Models/ComplaintCategory.php`
    - **Expect:** no output.
    - ⚠ **Side effect to confirm:** any other code that creates/edits a `ComplaintCategory` without going through this controller would stop logging. Verify with `grep -rn "ComplaintCategory::create\|ComplaintCategory::find.*->update\|->save()" Modules/Complaint/app/Http/Controllers` before ticking.
  - (b) **remove the controller's `activityLog()` calls** and keep the model observers (logs every path, but generic event names `'Stored'`/`'Updated'`/`'Trashed'` and no `changes` detail; the empty catches stay).
  - (c) **leave as is** — accept the duplicated audit trail.
  - ➜ Choice: ____

- [ ] **CCAT-15** · M · DECISION · F9 — cache the create/edit dropdown lookups (categories / entity groups / departments).
  - **Why it is a decision:** adding a cache is a DECISION (protocol §6, F9); it needs a tenant-scoped key (TEN-02).
  - (a) ⭐ **defer** — the tables are tiny today (`sch_entity_groups` = 8 rows, `sch_departments` = 14). Record as a post-launch optimisation.
  - (b) **add a `cache()->remember()` lookup** in `create()`/`edit()` — build a tenant-scoped key such as `"tenant:{$tenantId}:complaint_category_form"` with an explicit TTL, and forget it when a category/group/department changes.
  - (c) **add a dedicated `FormLookupService`** and inject it (larger change; overlaps the god-controller pass).
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CCAT-02 | No separate item — the `Log::error('…'.$e->getMessage())` call is deleted by **CCAT-01** in each of the five methods it rewrites; the copy inside `destroy()` is deleted by **CCAT-19**. |
| CCAT-04 | No separate item — the empty `catch` blocks in the model observers are removed by the recommended option (a) of **CCAT-03**. If option (b)/(c) is chosen, replace the empty body with `report($e);`. |
| CCAT-06 | **Accepted, no change** — `ComplaintCategoryPolicy` is registered (`ComplaintServiceProvider.php:61`) but never consulted; it duplicates the permission strings and is harmless. Deleting it would touch a shared provider file, so it is recorded here, not planned. |
| CCAT-10 | **Deferred** — the route parameter `{complaint_category}` vs the controller `$id` works via positional binding. Converting `edit`/`update`/`destroy`/`show` to route-model binding changes four signatures and their bodies; deferred to the refactor pass (D3) so it does not collide with CCAT-01/CCAT-11/CCAT-19. |
