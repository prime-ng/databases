# Fix Plan — Complaint / AiInsightController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Complaint/app/Http/Controllers/AiInsightController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Complaint/routes/web.php` | shared route file; the unused `use …AiInsightController;` import on line 4 is a cross-cutting note (report §7), not this plan's job |
| `config/permissionslist.php` | shared config; the `complaint.ai-insights` permission (line 862) is a cross-cutting note (report §7) |
| `final-audit-reports/gaurav/Complaint/00-INDEX.md` | maintained by the main session |
| `final-audit-reports/_Info/00-CLASS-OWNERS.md` | maintained by the main session |
| `Modules/Complaint/resources/views/create.blade.php` · `show.blade.php` · `edit.blade.php` | do NOT create these missing views — this plan disables the methods instead (D5) |
| every other Modules/Complaint controller | owned by another report |

## 1. Blockers reachable today

None. The controller has no route, so nothing here is reachable by a user.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None.

## 4. Authorization (F3)

None.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **AIN-01** · M · RTE-03 · `AiInsightController.php:13-55` — disable all 7 unrouted methods per D5 so the dead controller cannot 500 or silently no-op if a route is ever re-added.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/AiInsightController.php`
  - **Before** (`AiInsightController.php:13-55`):
    ```php
    public function index()
    {
        return view('complaint::index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('complaint::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {}

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('complaint::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('complaint::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id) {}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {}
    ```
  - **After:**
    ```php
    public function index(): never
    {
        // NOT ROUTED — disabled per final-audit D5 (2026-10-17), finding AIN-01.
        abort(403, 'This action is not routed.');
    }

    public function create(): never
    {
        // NOT ROUTED — disabled per final-audit D5 (2026-10-17), finding AIN-01.
        abort(403, 'This action is not routed.');
    }

    public function store(Request $request): never
    {
        // NOT ROUTED — disabled per final-audit D5 (2026-10-17), finding AIN-01.
        abort(403, 'This action is not routed.');
    }

    public function show($id): never
    {
        // NOT ROUTED — disabled per final-audit D5 (2026-10-17), finding AIN-01.
        abort(403, 'This action is not routed.');
    }

    public function edit($id): never
    {
        // NOT ROUTED — disabled per final-audit D5 (2026-10-17), finding AIN-01.
        abort(403, 'This action is not routed.');
    }

    public function update(Request $request, $id): never
    {
        // NOT ROUTED — disabled per final-audit D5 (2026-10-17), finding AIN-01.
        abort(403, 'This action is not routed.');
    }

    public function destroy($id): never
    {
        // NOT ROUTED — disabled per final-audit D5 (2026-10-17), finding AIN-01.
        abort(403, 'This action is not routed.');
    }
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\AiInsightController.php -Pattern 'return view\('`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

None.

## 7. Views (F10)

None.

## 8. Style (F12) — one item per file

- [ ] **AIN-04** · L · STY-01 · `AiInsightController.php:1-3` — add a strict-types declaration to the touched file.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/AiInsightController.php`
  - **Before** (`AiInsightController.php:1-3`):
    ```php
    <?php

    namespace Modules\Complaint\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Http\Controllers;
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\AiInsightController.php -Pattern 'declare\(strict_types'`
  - **Expect:** one hit on line 3 (`declare(strict_types=1);`).
  - **Effort:** S

## 9. Deferred / decisions

None.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| AIN-02 | No separate item — the AIN-01 edit replaces every method body with `abort(403)`, which removes the missing-view references (`complaint::create`/`show`/`edit`) and the empty `store`/`update`/`destroy` bodies. |
| AIN-03 | No separate item — the AIN-01 edit adds `: never` to each method, satisfying CTL-04. |
| AIN-05 | No separate item — the AIN-01 edit rewrites lines 13-55 and drops the seven copy-pasted scaffold docblocks. |
