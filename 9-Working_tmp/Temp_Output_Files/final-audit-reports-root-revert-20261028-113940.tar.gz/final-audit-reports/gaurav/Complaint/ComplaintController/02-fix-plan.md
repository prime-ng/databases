# Fix Plan — Complaint / ComplaintController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Complaint/app/Http/Controllers/ComplaintController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

**Apply order note:** in §3, apply **CMP-06** before **CMP-01**, **CMP-05** and **CMP-07** (those three assume the `DB::transaction(function () { … })` closure form that CMP-06 introduces).

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Complaint/routes/web.php` | shared route file — touched ONLY by CMP-11, CMP-12, CMP-23, each `⚠ SHARED` and ticked individually |
| `database/migrations/tenant/*cmp_*` | migrations are immutable; the `is_active` gap (CMP-23) is solved by removing the dead feature, not by a new migration |
| `config/permissionslist.php` | shared permission registry (CMP-08 uses existing keys only) |
| `Modules/Complaint/app/Models/ComplaintCategory.php`, `DepartmentSla.php`, `MedicalCheck.php` | owned by other reports (linked ↗, not re-audited) |
| `final-audit-reports/**/00-INDEX.md`, `_Info/00-CLASS-OWNERS.md`, `_index*` | registries — never edited by the fixer |
| `Modules/Complaint/app/Services/ComplaintAIInsightEngine.php` | the `is_sensitive` read (F7 note) is informational; no plan item |

## 1. Blockers reachable today

- [ ] **CMP-02** · B · ERR-01 · `Modules/Complaint/app/Http/Controllers/ComplaintController.php:1705-1716` — stop returning the raw exception text from `getTableColumns()`.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:1710-1715`):
    ```php
        try {
            $columns = DB::getSchemaBuilder()->getColumnListing($table);
            return response()->json($columns);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
    ```
  - **After:**
    ```php
        $columns = DB::getSchemaBuilder()->getColumnListing($table);

        return response()->json($columns);
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "getMessage"`
  - **Expect:** no line at ~1714 containing `response()->json(['error' => $e->getMessage()], 400)`.
  - **Effort:** S

- [ ] **CMP-05** · B · TXN-03 · `ComplaintController.php:418-422, 445, 745` — move the notification and media deletes out of the transaction.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:418-422`, the same fix applies at 445 and 745):
    ```php
                event(new ComplaintSaved($complaint));

                //begin::Send Notification to Admin roles users
                $admins = User::role('Super Admin')->get();
                Notification::send($admins, new StudentPortalComplaintRegistered($complaint));
    ```
  - **After:**
    ```php
                event(new ComplaintSaved($complaint));

                DB::afterCommit(function () use ($complaint) {
                    $admins = User::role('Super Admin')->get();
                    Notification::send($admins, new StudentPortalComplaintRegistered($complaint));
                });
    ```
    and at line 445 and 745 replace `$complaint->clearMediaCollection('complaint_img');` with:
    ```php
                DB::afterCommit(fn () => $complaint->clearMediaCollection('complaint_img'));
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "afterCommit|clearMediaCollection|Notification::send"`
  - **Expect:** `Notification::send` and both `clearMediaCollection` calls are wrapped by `DB::afterCommit`.
  - **Effort:** M

- [ ] **CMP-13** · H · RTE-02 · `ComplaintController.php:1022-1024` — redirect to the registered route name so a successful reopen is not reported as a failure.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:1020-1024`):
    ```php
                DB::commit();

                return redirect()
                    ->route('complaints.show', $complaint->id)
                    ->with('success', 'Complaint reopened successfully.');
    ```
  - **After:**
    ```php
                DB::commit();

                return redirect()
                    ->route('complaint.complaints.show', $complaint->id)
                    ->with('success', 'Complaint reopened successfully.');
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "route\('complaints\.show'"`
  - **Expect:** no output (the name is now `complaint.complaints.show`).
  - **Effort:** S

- [ ] **CMP-22** · B · MDL-05/TEN-01 · `Modules/Complaint/app/Models/Complaint.php:18-20` — point media at the tenant model so uploads stop landing in the central DB.
  - **Touches:** `Modules/Complaint/app/Models/Complaint.php`
  - **Before** (`Complaint.php:18-20`):
    ```php
    class Complaint extends Model implements HasMedia
    {
        use HasFactory, SoftDeletes, InteractsWithMedia;
    ```
  - **After:**
    ```php
    class Complaint extends Model implements HasMedia
    {
        use HasFactory, SoftDeletes, InteractsWithMedia;

        public function getMediaModel(): string
        {
            return \App\Models\TenantMedia::class;
        }
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Models\Complaint.php -Pattern "function getMediaModel"`
  - **Expect:** one match returning `\App\Models\TenantMedia::class`.
  - **Effort:** S

- [ ] **CMP-23** · B · MDL-07 · `ComplaintController.php:1037-1073` + `routes/web.php:123-126` — remove the `toggle-status` endpoint, which writes `is_active`, a column that does not exist on `cmp_complaints`. **⚠ SHARED — route file.**
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`, `Modules/Complaint/routes/web.php`
  - **Before** (`routes/web.php:123-126`):
    ```php
    Route::post(
        'complaints/{id}/toggle-status',
        [ComplaintController::class, 'toggleStatus']
    )->name('complaints.toggleStatus');
    ```
  - **After** (delete the four lines above) and delete the whole `toggleStatus()` method in the controller (`ComplaintController.php:1037-1073`). No complaint view calls it (verified: the endpoint has no caller in `resources/views`).
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "function toggleStatus"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CMP-34** · B · VIEW-01 · `resources/views/complaint/complaint/trash.blade.php` — rewrite the Department-SLA copy for complaints so `$data` is the iterated variable.
  - **Touches:** `Modules/Complaint/resources/views/complaint/complaint/trash.blade.php`
  - **Before** (`trash.blade.php:13` and `32-69`):
    ```blade
    <x-backend.card.header title="Trashed Department SLAs" url="complaint.department-sla" />

                                @forelse($slas as $sla)
                                    <tr>
                                        {{-- Complaint Category --}}
                                        <td>{{ $sla->category?->name ?? '-' }}</td>

                                        {{-- Complaint Sub Category --}}
                                        <td>{{ $sla->subCategory?->name ?? 'All Sub Categories' }}</td>

                                        {{-- Target Department --}}
                                        <td>{{ $sla->target_department_id ?? '-' }}</td>

                                        {{-- Expected Resolution --}}
                                        <td>{{ $sla->dept_expected_resolution_hours }} hrs</td>

                                        <td>
                                            <span class="badge bg-danger">Trashed</span>
                                        </td>
                                        @canany(['tenant.complaint.complaint.view', 'tenant.complaint.complaint.update', 'tenant.complaint.complaint.delete'])
                                        <td>
                                            <x-backend.table.action-trashed :id="$sla->id"
                                                url="complaint.department-sla"
                                                restorePermission="tenant.complaint.department-sla.restore"
                                                forceDeletePermission="tenant.complaint.department-sla.forceDelete"
                                            />
                                        </td>
                                        @endcanany
                                    </tr>
                                @empty
                                    <tr class="align-middle text-center">
                                        <td colspan="7">No Trashed Categories Found</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>

                        <div class="row d-flex justify-content-center align-items-center my-4 px-4">
                            <div class="col-sm-12">
                                {{ $slas->links() }}
    ```
  - **After** (header/url/permissions/collection all point at complaints; the loop variable becomes `$data`):
    ```blade
    <x-backend.card.header title="Trashed Complaints" url="complaint.complaints" />

                                @forelse($data as $complaint)
                                    <tr>
                                        {{-- Complaint Category --}}
                                        <td>{{ $complaint->category?->name ?? '-' }}</td>

                                        {{-- Complaint Sub Category --}}
                                        <td>{{ $complaint->subCategory?->name ?? 'All Sub Categories' }}</td>

                                        {{-- Target Department --}}
                                        <td>{{ $complaint->target_department_id ?? '-' }}</td>

                                        {{-- Expected Resolution --}}
                                        <td>{{ $complaint->dept_expected_resolution_hours }} hrs</td>

                                        <td>
                                            <span class="badge bg-danger">Trashed</span>
                                        </td>
                                        @canany(['tenant.complaint.complaint.view', 'tenant.complaint.complaint.update', 'tenant.complaint.complaint.delete'])
                                        <td>
                                            <x-backend.table.action-trashed :id="$complaint->id"
                                                url="complaint.complaints"
                                                restorePermission="tenant.complaint.complaint.restore"
                                                forceDeletePermission="tenant.complaint.complaint.forceDelete"
                                            />
                                        </td>
                                        @endcanany
                                    </tr>
                                @empty
                                    <tr class="align-middle text-center">
                                        <td colspan="7">No Trashed Complaints Found</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>

                        <div class="row d-flex justify-content-center align-items-center my-4 px-4">
                            <div class="col-sm-12">
                                {{ $data->links() }}
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\resources\views\complaint\complaint\trash.blade.php -Pattern "slas|department-sla"`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **CMP-38** · H · SEC-02 · `ComplaintController.php:1550-1703` — narrow the table allow-list for `getTableData()` to the tables the complaint forms actually target.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:1556-1570`, after the `SHOW TABLES` loader):
    ```php
        if (!in_array($table, $allowedTables, true)) {
            return response()->json(['error' => 'Invalid table'], 400);
        }
    ```
  - **After** (replace the `SHOW TABLES` allow-list with an explicit small list):
    ```php
        $allowedTables = [
            'sch_departments',
            'sch_designations',
            'sch_classes',
            'sch_class_sections',
            'slb_entity_groups',
        ];

        if (!in_array($table, $allowedTables, true)) {
            return response()->json(['error' => 'Invalid table'], 400);
        }
    ```
    Keep the existing `request()->filled('user_type')` branch only if a caller passes `sys_users`; otherwise delete the `sys_users` branch (1684-1697) too. The complaint create/edit forms target the five tables listed.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "SHOW TABLES"`
  - **Expect:** no output for `getTableData` — the allow-list is now the explicit array.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **CMP-39** · M · SEC-03 · `ComplaintController.php:328, 334` — replace the magic-id fallbacks with a loud failure.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:324-334`):
    ```php
                $statusId = DB::table('sys_dropdown_table')
                    ->where('key', 'cmp_complaints.status_id')
                    ->where('value', 'Open')
                    ->first()
                        ?->id ?? 124; // Fallback to 124 if not found for safety

                $priorityScoreId = DB::table('sys_dropdown_table')
                    ->where('key', 'cmp_complaint_categories.priority_score_id')
                    ->where('value', 'Medium')
                    ->first()
                        ?->id ?? 3; // Fallback to 3 if not found for safety
    ```
  - **After:**
    ```php
                $statusId = DB::table('sys_dropdown_table')
                    ->where('key', 'cmp_complaints.status_id')
                    ->where('value', 'Open')
                    ->firstOrFail()
                    ->id;

                $priorityScoreId = DB::table('sys_dropdown_table')
                    ->where('key', 'cmp_complaint_categories.priority_score_id')
                    ->where('value', 'Medium')
                    ->firstOrFail()
                    ->id;
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "\?\? 124|\?\? 3"`
  - **Expect:** no output.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [ ] **CMP-01** · M · ERR-00 · `ComplaintController.php` (10 methods) — delete the try/catch around the writes and let the framework render failures.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:322-325` open + `468-479` close; same shape at `739/817`, `839/867`, `903/916`, `934/947`, `988/1025`, `1047/1062`, `243/253`, `610/620`):
    ```php
            try {

                $statusId = DB::table('sys_dropdown_table')
                    ->where('key', 'cmp_complaints.status_id')
                    ->where('value', 'Open')
                    ->first()
                        ?->id ?? 124; // Fallback to 124 if not found for safety

                $priorityScoreId = DB::table('sys_dropdown_table')
                    ->where('key', 'cmp_complaint_categories.priority_score_id')
                    ->where('value', 'Medium')
                    ->first()
                        ?->id ?? 3; // Fallback to 3 if not found for safety
    ```
    ```php
            } catch (\Throwable $e) {
                DB::rollBack();

                Log::error('Failed to create complaint: ' . $e->getMessage(), [
                    'ticket_no' => $ticketNo ?? null,
                    'exception' => get_class($e),
                ]);

                return back()
                    ->withInput()
                    ->with('error', flash('operation_failed.complaint', 'Failed to create the complaint. Please try again.'));
            }
    ```
  - **After:** remove the `try {` and the whole `} catch (\Throwable $e) { … }` block; de-indent the body by one level. Keep the outer `findOrFail()` (move it above the removed `try` if it sat inside). The method ends after the success `return`. Repeat for each method listed in the **Where** field of CMP-01.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "catch \(\\Throwable|catch \(\\Exception"`
  - **Expect:** no output.
  - **Effort:** L

- [ ] **CMP-03** · M · ERR-05 · `ComplaintController.php:253, 471, 620, 818, 868, 917, 948, 1028, 1063` — log the exception object, not the message. (If CMP-01 is applied first these catches are gone; if not, apply this.)
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:471-474`):
    ```php
                Log::error('Failed to create complaint: ' . $e->getMessage(), [
                    'ticket_no' => $ticketNo ?? null,
                    'exception' => get_class($e),
                ]);
    ```
  - **After:**
    ```php
                report($e);
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "get_class\(\$e\)"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CMP-04** · M · ERR-04 · `ComplaintController.php` `index`/`show`/`store`/`update`/`destroy` — branch the response shape on `expectsJson()` so the API resource stops returning HTML.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:188-226` end of `index`):
    ```php
            return view('complaint::complaint.index', compact(
                'categories',
    ```
  - **After** (guard before the `view()` return; repeat the same guard pattern before the other four methods' web returns):
    ```php
            if ($request->expectsJson()) {
                return response()->json($data);
            }

            return view('complaint::complaint.index', compact(
                'categories',
    ```
    For `store`/`update`/`destroy`, return `response()->json($complaint, 201)` / `response()->json($complaint)` / `response()->json(['deleted' => true])` when `$request->expectsJson()`.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "expectsJson"`
  - **Expect:** at least 5 matches (one per API-shared method).
  - **Effort:** M

- [ ] **CMP-06** · M · TXN-02 · `ComplaintController.php:320/463/469` (`store`) and `987/1020/1026` (`reopen`) — convert the manual transactions to the closure form.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:320`, `463`, `469`):
    ```php
            DB::beginTransaction();

            try {
    ```
    ```php
                DB::commit();

                return redirect()
                    ->route('complaint.complaints.index', ['tab' => 'complaint-manage'])
                    ->with('success', "Complaint Lodged. Ticket No: {$ticketNo}");
            } catch (\Throwable $e) {
                DB::rollBack();
    ```
  - **After** (wrap the body in a closure; return the redirect after it returns):
    ```php
            $complaint = DB::transaction(function () use ($request) {
                // … existing store body (unchanged), without beginTransaction/commit/rollBack …
                return $complaint;
            });

            return redirect()
                ->route('complaint.complaints.index')
                ->with('success', 'Complaint created successfully.');
    ```
    Do the same for `reopen()`.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "beginTransaction|DB::rollBack"`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **CMP-07** · M · TXN-03 · `ComplaintController.php:418, 752, 996` — fire the `ComplaintSaved` event after the transaction commits.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:418`, inside the store transaction):
    ```php
                event(new ComplaintSaved($complaint));
    ```
  - **After:**
    ```php
                DB::afterCommit(fn () => event(new ComplaintSaved($complaint)));
    ```
    Apply the same wrap at 752 and 996.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "event\(new ComplaintSaved"`
  - **Expect:** all three matches are wrapped in `DB::afterCommit`.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **CMP-08** · M · AUTH-05 · `ComplaintController.php:52-60` vs `99` — remove the dead `Gate::any([…])` so the seven tab permissions are no longer silently overridden.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:52-60`):
    ```php
            Gate::any([
                'tenant.complaint.complaint-dashboard.viewAny',
                'tenant.complaint.complaint-category.viewAny',
                'tenant.complaint.complaint-sla.viewAny',
                'tenant.complaint.medical-checks.viewAny',
                'tenant.complaint.complaint-actions.viewAny',
                'tenant.complaint.ai-insights.viewAny',
                'tenant.complaint.complaint-complaint-management.viewAny',
            ]) || abort(403);
    ```
  - **After:** delete the `Gate::any([…]) || abort(403);` block; keep the explicit `Gate::authorize('tenant.complaint.complaint.viewAny');` at line 99 as the single rule (the other tab controllers already authorize themselves).
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "Gate::any"`
  - **Expect:** no output.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **CMP-09** · M · VAL-02 · `ComplaintController.php:296-317, 659-695` — move the create/update rule arrays into FormRequests.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`, `Modules/Complaint/app/Http/Requests/StoreComplaintRequest.php` (new), `Modules/Complaint/app/Http/Requests/UpdateComplaintRequest.php` (new)
  - **Before** (`ComplaintController.php:296-303`):
    ```php
            $request->validate([
                'target_table_name' => 'nullable|string',
                'target_column' => 'nullable|string',
                'target_type_id' => 'required|exists:sys_dropdown_table,id',
    ```
  - **After** (controller signature + call sites):
    ```php
        public function store(StoreComplaintRequest $request)
        {
            $validated = $request->validated();
    ```
    ```php
        public function update(UpdateComplaintRequest $request, $id)
        {
            $validated = $request->validated();
    ```
    ```php
    <?php

    namespace Modules\Complaint\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;

    class StoreComplaintRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }

        public function rules(): array
        {
            return [
                // paste the exact rule array that was at ComplaintController.php:296-317
            ];
        }
    }
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "request->validate\("`
  - **Expect:** no output for `store`/`update` (only the three donut methods remain, if still inline).
  - **Effort:** L

- [ ] **CMP-10** · H · VAL-05 · `ComplaintController.php:376/388/389/407/716/719/1799-1800` — validate the unvalidated write fields and parse dates from validated input.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:1795-1804`):
    ```php
        public function filter(Request $request, ComplaintDashboardService $service)
        {
            Gate::authorize('tenant.complaint.complaint.viewAny');

            $from = Carbon::parse($request->from_date)->startOfDay();
            $to = Carbon::parse($request->to_date)->endOfDay();
    ```
  - **After:**
    ```php
        public function filter(Request $request, ComplaintDashboardService $service)
        {
            Gate::authorize('tenant.complaint.complaint.viewAny');

            $validated = $request->validate([
                'from_date' => 'nullable|date',
                'to_date' => 'nullable|date|after_or_equal:from_date',
            ]);

            $from = Carbon::parse($validated['from_date'] ?? now()->subDays(30))->startOfDay();
            $to = Carbon::parse($validated['to_date'] ?? now())->endOfDay();
    ```
    Add `'target_name' => 'nullable|string|max:191'`, `'target_code' => 'nullable|string|max:191'`, `'ticket_date' => 'nullable|date'`, `'source_id' => 'nullable|integer|exists:sys_dropdown_table,id'` to the FormRequest rule arrays (CMP-09).
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "Carbon::parse\(\$request"`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **CMP-11** · H · RTE-01 · `routes/web.php:113-116` — change `restore` from GET to POST. **⚠ SHARED — route file.**
  - **Touches:** `Modules/Complaint/routes/web.php`
  - **Before** (`routes/web.php:113-116`):
    ```php
    Route::get(
        'complaints/{id}/restore',
        [ComplaintController::class, 'restore']
    )->name('complaints.restore');
    ```
  - **After:**
    ```php
    Route::post(
        'complaints/{id}/restore',
        [ComplaintController::class, 'restore']
    )->name('complaints.restore');
    ```
    Update the trash view's restore action to submit a POST form (same card-action component, method="POST" with `@csrf`).
  - **Verify:** `Select-String -Path Modules\Complaint\routes\web.php -Pattern "complaints/\{id\}/restore"`
  - **Expect:** the preceding line reads `Route::post(`.
  - **Effort:** S

- [ ] **CMP-12** · M · RTE-06 · `routes/web.php:105-106` vs `133-136` — register `complaints/manage` before the resource so it is not shadowed. **⚠ SHARED — route file.**
  - **Touches:** `Modules/Complaint/routes/web.php`
  - **Before** (`routes/web.php:105-106` then `133-136`):
    ```php
    Route::resource('complaints', ComplaintController::class)
        ->names('complaints');

    Route::get(
        'complaints/trash/view',
        [ComplaintController::class, 'trashed']
    )->name('complaints.trashed');

    Route::get(
        'complaints/{id}/restore',
        [ComplaintController::class, 'restore']
    )->name('complaints.restore');

    Route::delete(
        'complaints/{id}/force-delete',
        [ComplaintController::class, 'forceDelete']
    )->name('complaints.forceDelete');

    Route::post(
        'complaints/{id}/toggle-status',
        [ComplaintController::class, 'toggleStatus']
    )->name('complaints.toggleStatus');

    Route::post(
        'complaints/{id}/reopen',
        [ComplaintController::class, 'reopen']
    )->name('complaints.reopen');

    Route::get(
        'complaints/manage',
        [ComplaintController::class, 'manage']
    )->name('complaints.manage');
    ```
  - **After:** move the four `complaints/manage` lines to immediately **above** the `Route::resource('complaints', …)` block:
    ```php
    Route::get(
        'complaints/manage',
        [ComplaintController::class, 'manage']
    )->name('complaints.manage');

    Route::resource('complaints', ComplaintController::class)
        ->names('complaints');
    ```
  - **Verify:** `php artisan route:clear; $env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --path=complaint/complaints/manage`
  - **Expect:** the `manage` route resolves to `@manage` and the earlier `{complaint}` wildcard no longer appears first.
  - **Effort:** S

- [ ] **CMP-16** · M · CTL-03 · `ComplaintController.php` (9 methods) — adopt route-model binding.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`, `Modules/Complaint/routes/web.php` (only if `withTrashed()` must be added)
  - **Before** (`ComplaintController.php:485-498`):
    ```php
        public function show($id)
        {
            Gate::authorize('tenant.complaint.complaint.view');

            $complaint = Complaint::with([
                'category',
                'subCategory',
                'assignedRole',
                'assignedUser',
                'resolvedByRole',
                'resolvedByUser',
                'complainantUser',
                'creator',
            ])->findOrFail($id);
    ```
  - **After:**
    ```php
        public function show(Complaint $complaint)
        {
            Gate::authorize('tenant.complaint.complaint.view');

            $complaint->load([
                'category',
                'subCategory',
                'assignedRole',
                'assignedUser',
                'resolvedByRole',
                'resolvedByUser',
                'complainantUser',
                'creator',
            ]);
    ```
    Do the same for `edit`, `update`, `destroy`, `restore`, `forceDelete`, `reopen`, `toggleStatus` (removed by CMP-23), `manage`. For the trash routes (`restore`, `forceDelete`, `trashed`), add `->withTrashed()` on the route registration.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "findOrFail\(\$id\)"`
  - **Expect:** no output.
  - **Effort:** L

- [ ] **CMP-24** · M · MDL-01/MDL-07 · `Complaint.php:44, 75, 177-188` — remove the phantom fillable keys and the broken polymorphic relation.
  - **Touches:** `Modules/Complaint/app/Models/Complaint.php`
  - **Before** (`Complaint.php:44` and `177-188`):
    ```php
            'target_user_type_id',
            'target_id',
            'target_name',
            'target_table_name',
            'target_selected_id',
            'target_code',
    ```
    ```php
        public function target()
        {
            return $this->target_id;
        }

        public function targetable()
        {
            return $this->morphTo('targetable', 'target_table_name', 'target_id');
        }
    ```
  - **After** (delete the `'target_id'` and `'escalation_level'` fillable lines, and delete both `target()` and `targetable()` if nothing references them — verified: no in-module caller):
    ```php
        // (both fillable keys removed)
    ```
    If `targetable()` must stay, correct it to use the real column:
    ```php
        public function targetable()
        {
            return $this->morphTo('targetable', 'target_table_name', 'target_selected_id');
        }
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Models\Complaint.php -Pattern "target_id'|escalation_level"`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **CMP-15** · H · CTL-02 · `ComplaintController.php:50-227/270-480/644-827/1550-1703` — split the four over-150-line methods.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`, `Modules/Complaint/app/Services/ComplaintService.php` (new)
  - **Before** (`ComplaintController.php:270-271`):
    ```php
        public function store(Request $request)
        {
    ```
  - **After** (introduce a service; keep the controller method a thin orchestrator):
    ```php
    <?php

    namespace Modules\Complaint\app\Services;

    class ComplaintService
    {
        public function create(array $validated, Request $request): Complaint { /* moved store() body */ }

        public function updateComplaint(Complaint $complaint, array $validated, Request $request): Complaint { /* moved update() body */ }
    }
    ```
    ```php
        public function store(StoreComplaintRequest $request, ComplaintService $service)
        {
            $complaint = $service->create($request->validated(), $request);

            return redirect()->route('complaint.complaints.index')->with('success', 'Complaint created successfully.');
        }
    ```
    Move the `index()` tab loaders into private `*Query` helpers and the `getTableData()` DB phases into `tableDataQuery*` helpers.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "public function store"`
  - **Expect:** `store()` is under 30 lines.
  - **Effort:** L

- [ ] **CMP-17** · M · CTL-05 · `ComplaintController.php:243-254, 610-621, 1556-1563, 276-294, 703-714` — extract the three copy-pasted blocks.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:243-254`):
    ```php
            try {
                $rows = DB::select('SHOW TABLES');
                foreach ($rows as $row) {
                    $tableName = array_values((array) $row)[0] ?? null;
                    if (!$tableName) {
                        continue;
                    }
                    $tables[$tableName] = str_replace('_', ' ', $tableName);
                }
            } catch (\Exception $e) {
                \Log::error('Failed to fetch DB tables: ' . $e->getMessage());
            }
    ```
  - **After** (a private helper, called from all three sites):
    ```php
        private function listTenantTables(): array
        {
            $tables = [];
            foreach (DB::select('SHOW TABLES') as $row) {
                $tableName = array_values((array) $row)[0] ?? null;
                if ($tableName) {
                    $tables[$tableName] = str_replace('_', ' ', $tableName);
                }
            }

            return $tables;
        }
    ```
    Add a `resolveComplainant($request): array` helper and call it from `store`/`update`; delete the controller's duplicate `getRecentCriticalTickets()` (CMP-19/CMP-28).
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "SHOW TABLES"`
  - **Expect:** exactly one match (inside `listTenantTables`).
  - **Effort:** M

- [ ] **CMP-18** · M · CTL-07 · `ComplaintController.php:188-226` — replace the 28-key `compact()` with a single view-model array.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:188-226`):
    ```php
            return view('complaint::complaint.index', compact(
                'categories',
                'categoriesExport',
                'complaintsExport',
                'slas',
                'slasExport',
                'medicalChecksExport',
                'medicalChecks',
                'checkTypes',
                'results',
                'complaints',
                'actions',
                'actionTypes',
                'actionUsers',
                'assignedUsers',
                'dashboard',
                'aiInsights',
                'sentimentLabels',
                'predictedCategories',
                'dateFrom',
                'dateTo',
                'dateLabel',
                'severityLevels',
                'priorityScores',
                'complaintStatuses',
                'parentCategories',
                'departments',
                'groups',
                'slaCategories',
                'slaDepartments',
                'designations',
                'roles',
                'users',
                'vehicles',
                'vendors',
                'medicalComplaints',
                'frustrationReport',
                'activeTab'
            ));
    ```
  - **After:**
    ```php
            return view('complaint::complaint.index', [
                'activeTab' => $activeTab,
                'tabData' => [
                    'categories' => $categories,
                    'categoriesExport' => $categoriesExport,
                    'complaintsExport' => $complaintsExport,
                    // … remaining keys grouped by tab …
                ],
            ]);
    ```
    and update `index.blade.php` to read `$tabData['…']`. (Alternatively keep `compact()` but cap it at ≤15 keys per method.)
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "compact\("`
  - **Expect:** no single `compact()` with more than 15 arguments.
  - **Effort:** M

- [ ] **CMP-19** · M · CTL-10 · `ComplaintController.php:1441-1466, 1810-1822, 160, 22, 435` — delete dead code.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:1441-1444`, `1810-1811`, `160`, `22`, `435`):
    ```php
        private function getRecentCriticalTickets()
        {
            $now = now();

            return Complaint::with('category')
                ->whereNotNull('resolution_due_at')
                ->whereNull('actual_resolved_at')
                ->orderBy('resolution_due_at')
                ->limit(5)
                ->get()
                ->map(function ($complaint) use ($now) {

                    $hoursLeft = $now->diffInMinutes(
                        $complaint->resolution_due_at,
                        false
                    ) / 60;

                    return [
                        'ticket_no' => $complaint->ticket_no,
                        'title' => $complaint->title,
                        'hours' => round($hoursLeft, 1),
                        'is_breach' => $hoursLeft < 0,
                        'is_critical' => $hoursLeft <= 5,
                    ];
                });
        }
    ```
    ```php
        private function getFilteredDashboardData(?string $from = null, ?string $to = null): array
        {
            $from = $from ? Carbon::parse($from) : now()->subDays(30);
            $to = $to ? Carbon::parse($to) : now();

            $dashboard = $this->dashboardService->getDashboardData($from, $to);
            $dashboard['criticalTickets'] = $this->dashboardService->getRecentCriticalTickets($from, $to);
            $dashboard['escalationHeatmap'] = $this->dashboardService->getEscalationHeatmapData($from, $to);
            $dashboard['aiRiskPredictions'] = $this->dashboardService->getHighRiskPredictions($from, $to);
            $dashboard['sentimentTrend'] = $this->dashboardService->getSentimentTrend($from, $to);

            return $dashboard;
        }
    ```
    ```php
        // ComplaintController.php:160 — assigned but never used
        $slasAll = DepartmentSla::all();
    ```
    ```php
        // ComplaintController.php:22 — commented-out import
    // use Modules\GlobalMaster\Models\Dropdown;
    ```
    ```php
        // ComplaintController.php:435 — commented-out array key
                    // 'action_type_id' => 157,
    ```
  - **After:** delete both unused private methods (`getRecentCriticalTickets`, `getFilteredDashboardData`), the `$slasAll = DepartmentSla::all();` line, and the two commented-out lines. (Same edit also satisfies CMP-28.)
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "getFilteredDashboardData|slasAll"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CMP-27** · H · QRY-01 · `Services/ComplaintDashboardService.php:139-158` — pre-load the status map instead of querying per complaint.
  - **Touches:** `Modules/Complaint/app/Services/ComplaintDashboardService.php`
  - **Before** (`ComplaintDashboardService.php:154-158`):
    ```php
        private function calculateCurrentEscalationLevel(Complaint $complaint): ?string
        {
            $status = DB::table('sys_dropdown_table')
                ->where('id', $complaint->status_id)
                ->value('value');
    ```
  - **After** (look up from a pre-loaded map; load once at the top of `getEscalationHeatmapData`):
    ```php
        public function getEscalationHeatmapData(Carbon $from, Carbon $to): array
        {
            $statusMap = DB::table('sys_dropdown_table')
                ->where('key', 'cmp_complaints.status_id')
                ->pluck('value', 'id');
    ```
    ```php
        private function calculateCurrentEscalationLevel(Complaint $complaint, $statusMap): ?string
        {
            $status = $statusMap[$complaint->status_id] ?? null;
    ```
    Pass `$statusMap` into the per-row call inside the loop.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Services\ComplaintDashboardService.php -Pattern "foreach|->where\('id'"`
  - **Expect:** no `->where('id', $complaint->status_id)` inside the loop.
  - **Effort:** M

- [ ] **CMP-28** · M · SVC-04 · `ComplaintController.php:1441-1466` — delete the duplicate of `ComplaintDashboardService::getRecentCriticalTickets()`. (Covered by CMP-19.)
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:1441-1442`):
    ```php
        private function getRecentCriticalTickets()
        {
    ```
  - **After:** delete the whole method (through its closing brace at 1466). The service copy at `ComplaintDashboardService.php:104` is the one in use.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "function getRecentCriticalTickets"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CMP-30** · M · QRY-15 · `ComplaintController.php:160-182` — stop loading eight whole tables on every `index()` load.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:160, 173-182`):
    ```php
            $slasAll = DepartmentSla::all();

            /* ================= COMPLAINT ACTIONS (NEW) ================= */
            [
                'actions' => $actions,
                'actionTypes' => $actionTypes,
                'actionUsers' => $actionUsers,
                'assignedUsers' => $assignedUsers,
            ] = $this->getComplaintActionsData($request, $activeTab);

            $aiInsights = $this->getAiInsights($request, $activeTab);

            $sentimentLabels = Dropdown::where('key', 'cmp_ai_insights.sentiment_label_id')->get();
            $predictedCategories = ComplaintCategory::all();

            $groups = EntityGroup::all();
            $slaCategories = ComplaintCategory::parents()->get();
            $slaDepartments = Department::select('id', 'name')->get();
            $designations = Designation::all();
            $roles = Role::all();
            $users = User::whereIn('user_type', ['EMPLOYEE', 'TEACHER', 'PRIME', 'SYSTEM'])->select('id', 'name')->get();
            $vehicles = class_exists(Vehicle::class) ? Vehicle::all() : collect();
            $vendors = class_exists(Vendor::class) ? Vendor::all() : collect();
    ```
  - **After:** delete the unused `$slasAll` line, and load each remaining collection **only inside the branch for the tab that needs it** (e.g. `$groups`/`$slaCategories` only in the `sla` branch; `$vehicles`/`$vendors` only in the `complaint-manage` branch). Each query selects `id,name` only.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "::all\(\)"`
  - **Expect:** at most one unconditional `::all()` remains before the tab branch.
  - **Effort:** M

- [ ] **CMP-31** · M · QRY-12 · `ComplaintController.php:1408-1409` — resolve the user list once.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:1408-1409`):
    ```php
            $actionUsers = User::orderBy('name')->get(['id', 'name']);
            $assignedUsers = User::orderBy('name')->get(['id', 'name']);
    ```
  - **After:**
    ```php
            $actionUsers = User::orderBy('name')->get(['id', 'name']);
            $assignedUsers = $actionUsers;
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "User::orderBy"`
  - **Expect:** one match.
  - **Effort:** S

- [ ] **CMP-32** · M · QRY-11 · `ComplaintController.php:1654` — keep the table allow-list immediately above the interpolated `SHOW COLUMNS`.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:1652-1654`):
    ```php
            if (!$nameColumn) {
                try {
                    $columnMeta = DB::select("SHOW COLUMNS FROM `$table`");
    ```
  - **After** (guarantee the guard, then interpolate only the validated `$table`):
    ```php
            if (!in_array($table, $allowedTables, true)) {
                return response()->json(['error' => 'Invalid table'], 400);
            }

            if (!$nameColumn) {
                $columnMeta = DB::select('SHOW COLUMNS FROM `' . $table . '`');
    ```
    (The allow-list is the explicit array from CMP-38; keep the guard directly above the interpolation.)
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "SHOW COLUMNS"`
  - **Expect:** one match, preceded within 10 lines by the `in_array($table, $allowedTables` guard.
  - **Effort:** M

- [ ] **CMP-33** · M · QRY-05 · `Services/ComplaintDashboardService.php:135, 274, 447` — aggregate in SQL instead of pulling whole tables.
  - **Touches:** `Modules/Complaint/app/Services/ComplaintDashboardService.php`
  - **Before** (`ComplaintDashboardService.php:131-135`):
    ```php
        public function getEscalationHeatmapData(Carbon $from, Carbon $to): array
        {
            $complaints = Complaint::with('category')
                ->whereBetween('ticket_date', [$from, $to])
                ->get();
    ```
  - **After** (group/aggregate in the query; one shape):
    ```php
        public function getEscalationHeatmapData(Carbon $from, Carbon $to): array
        {
            $rows = Complaint::query()
                ->whereBetween('ticket_date', [$from, $to])
                ->selectRaw('current_escalation_level, COUNT(*) as total')
                ->groupBy('current_escalation_level')
                ->get();
    ```
    Apply the same to `getSentimentTrend` (274) and `getRepeatedTargetFrustration` (447): use `groupBy` + `selectRaw('COUNT(*)')`/`AVG(...)` rather than `->get()` then `groupBy()`/`filter()`/`sortBy()` in PHP.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Services\ComplaintDashboardService.php -Pattern "->get\(\)"`
  - **Expect:** no `->get()` immediately followed by a PHP `groupBy`/`sum`/`filter` over the whole range.
  - **Effort:** L

## 7. Views (F10)

- [ ] **CMP-35** · H · VIEW-01 · `complaint/complaint/index.blade.php:98-101`, `complaint/complaint-manage/index.blade.php:210, 243` — remove the per-row `DB::` queries.
  - **Touches:** `resources/views/complaint/complaint/index.blade.php`, `resources/views/complaint/complaint-manage/index.blade.php`
  - **Before** (`index.blade.php:98-101`):
    ```blade
                                @php
                                    $priority = DB::table('sys_dropdown_table')
                                        ->where('id', $complaint->priority_score_id)
                                        ->value('value');
                                @endphp
    ```
  - **After** (read the eager-loaded relation instead):
    ```blade
                                @php
                                    $priority = $complaint->priorityScore?->value;
                                @endphp
    ```
    For the status cells at `complaint-manage/index.blade.php:210/243`, replace `DB::table('sys_dropdown_table')->where('id', $complaint->status_id)->value('value')` with `$complaint->status?->value` (ensure `status` is eager-loaded in `complaintsQuery`).
  - **Verify:** `Select-String -Path Modules\Complaint\resources\views\complaint\complaint\index.blade.php,Modules\Complaint\resources\views\complaint\complaint-manage\index.blade.php -Pattern "DB::"`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **CMP-36** · H · VIEW-01 · `complaint/complaint/index.blade.php:116-122` — stop reading the undefined `sla_remaining_seconds`.
  - **Touches:** `resources/views/complaint/complaint/index.blade.php`, `Modules/Complaint/app/Models/Complaint.php`
  - **Before** (`index.blade.php:114-122`):
    ```blade
                            <td>
                                <span class="sla-timer text-warning fw-semibold"
                                    data-seconds="{{ $complaint->sla_remaining_seconds }}" data-id="{{ $complaint->id }}">
    ```
  - **After** (add the accessor to `Complaint`, then the view can keep reading it):
    ```php
        public function getSlaRemainingSecondsAttribute(): ?int
        {
            if (!$this->resolution_due_at || $this->actual_resolved_at) {
                return null;
            }

            return now()->diffInSeconds($this->resolution_due_at, false);
        }
    ```
    and in the view guard the null:
    ```blade
                                @if (($complaint->sla_remaining_seconds ?? 0) > 0)
                                    {{ gmdate('H\h i\m s\s', $complaint->sla_remaining_seconds) }}
                                @else
                                    Breached
                                @endif
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Models\Complaint.php -Pattern "getSlaRemainingSecondsAttribute"`
  - **Expect:** one match.
  - **Effort:** M

## 8. Style (F12) — one item per file

- [ ] **CMP-20** · L · CTL-08 · `ComplaintController.php:69, 1573-1697, 1711` — inject `Request` instead of calling the `request()` helper.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:1550`):
    ```php
        public function getTableData($table)
    ```
  - **After:**
    ```php
        public function getTableData(Request $request, $table)
    ```
    and `public function getTableColumns(Request $request, $table)`; replace `request()->query('x')` with `$request->query('x')`, `request()->filled('x')` with `$request->filled('x')`, and `request()->route()` at line 69 with the already-injected `$request` (or `$request->route()`).
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "request\(\)->"`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **CMP-21** · L · CTL-04 · `ComplaintController.php` — add return types to the public methods.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/ComplaintController.php`
  - **Before** (`ComplaintController.php:50, 485, 1795`):
    ```php
        public function index(Request $request)
    ```
    ```php
        public function show($id)
    ```
    ```php
        public function filter(Request $request, ComplaintDashboardService $service)
    ```
  - **After:**
    ```php
        public function index(Request $request): View
    ```
    ```php
        public function show(Complaint $complaint): View
    ```
    ```php
        public function filter(Request $request, ComplaintDashboardService $service): JsonResponse
    ```
    Use `View` for page methods, `RedirectResponse` for store/update/destroy/restore/reopen, `JsonResponse` for the AJAX/donut/`getTable*` methods, and `StreamedResponse`/`BinaryFileResponse` if any export returns a download.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern "public function (index|show|filter)\(.*\)(?!:)"`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **CMP-25** · L · MDL-04 · `Complaint.php`, `ComplaintAction.php`, `AiInsight.php` — return-type the relations.
  - **Touches:** `Modules/Complaint/app/Models/Complaint.php`, `Modules/Complaint/app/Models/ComplaintAction.php`, `Modules/Complaint/app/Models/AiInsight.php`
  - **Before** (`Complaint.php:151-154`):
    ```php
        public function complainantType()
        {
            return $this->belongsTo(Dropdown::class, 'complainant_type_id');
        }
    ```
  - **After:**
    ```php
        public function complainantType(): BelongsTo
        {
            return $this->belongsTo(Dropdown::class, 'complainant_type_id');
        }
    ```
    Apply `: BelongsTo` / `: HasMany` / `: HasOne` to every relation in the three models, adding the `use Illuminate\Database\Eloquent\Relations\…;` imports.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Models\Complaint.php -Pattern "public function [a-z]+\(\)$"`
  - **Expect:** no output (all relations typed).
  - **Effort:** M

- [ ] **CMP-26** · L · MDL-02 · `Complaint.php:92-102` — add the missing casts.
  - **Touches:** `Modules/Complaint/app/Models/Complaint.php`
  - **Before** (`Complaint.php:92-102`):
    ```php
        protected $casts = [
            'ticket_date' => 'date',
            'incident_date' => 'datetime',
            'resolution_due_at' => 'datetime',
            'actual_resolved_at' => 'datetime',
            'dept_specific_info' => 'array',
            'is_anonymous' => 'boolean',
            'is_escalated' => 'boolean',
            'is_medical_check_required' => 'boolean',
            'support_file' => 'boolean',
        ];
    ```
  - **After:**
    ```php
        protected $casts = [
            'ticket_date' => 'date',
            'incident_date' => 'datetime',
            'incident_time' => 'string',
            'resolution_due_at' => 'datetime',
            'actual_resolved_at' => 'datetime',
            'dept_specific_info' => 'array',
            'is_anonymous' => 'boolean',
            'is_escalated' => 'boolean',
            'is_medical_check_required' => 'boolean',
            'support_file' => 'boolean',
            'current_escalation_level' => 'integer',
        ];
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Models\Complaint.php -Pattern "incident_time|current_escalation_level"`
  - **Expect:** both appear inside `$casts`.
  - **Effort:** S

- [ ] **CMP-29** · L · JOB-04 · `Listeners/ProcessComplaintAIInsights.php:8` — queue the listener.
  - **Touches:** `Modules/Complaint/app/Listeners/ProcessComplaintAIInsights.php`
  - **Before** (`ProcessComplaintAIInsights.php:8-10`):
    ```php
    class ProcessComplaintAIInsights
    {
        protected ComplaintAIInsightEngine $engine;
    ```
  - **After:**
    ```php
    use Illuminate\Contracts\Queue\ShouldQueue;

    class ProcessComplaintAIInsights implements ShouldQueue
    {
        protected ComplaintAIInsightEngine $engine;
    ```
    (No-op until a queue worker runs; safe to merge now.) Set `public int $tries = 3;` and `public int $timeout = 30;` if the deploy has a worker.
  - **Verify:** `Select-String -Path Modules\Complaint\app\Listeners\ProcessComplaintAIInsights.php -Pattern "ShouldQueue"`
  - **Expect:** one match.
  - **Effort:** S

- [ ] **CMP-37** · L · VIEW-03 · `complaint/complaint/edit.blade.php:150`, `show.blade.php:160` — document the `{!! !!}` sink against the model sanitizer.
  - **Touches:** `resources/views/complaint/complaint/edit.blade.php`, `resources/views/complaint/complaint/show.blade.php`
  - **Before** (`edit.blade.php:150`):
    ```blade
                                        {!! $complaint->description !!}
    ```
  - **After** (keep the sink; add the guard comment that ties it to `SanitizesRichText`):
    ```blade
                                        {{-- Sanitized on write by Complaint::$sanitizable — see App\Traits\SanitizesRichText --}}
                                        {!! $complaint->description !!}
    ```
    Same comment above the `show.blade.php:160` sink.
  - **Verify:** `Select-String -Path Modules\Complaint\resources\views\complaint\complaint\edit.blade.php -Pattern "SanitizesRichText"`
  - **Expect:** one match directly above the `{!! !!}`.
  - **Effort:** S

- [ ] **CMP-40** · L · STY-01 · eight in-scope files — add `declare(strict_types=1);`.
  - **Touches:** `ComplaintController.php`, `Complaint.php`, `ComplaintAction.php`, `AiInsight.php`, `ComplaintDashboardService.php`, `ComplaintAIInsightEngine.php`, `ComplaintSaved.php`, `ProcessComplaintAIInsights.php`
  - **Before** (`ComplaintController.php:1-3`):
    ```php
    <?php

    namespace Modules\Complaint\Http\Controllers;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Http\Controllers;
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Services\ComplaintDashboardService.php -Pattern "declare\(strict_types"`
  - **Expect:** one match.
  - **Effort:** S

- [ ] **CMP-41** · L · STY-02/STY-04 · `ComplaintController.php` (+ in-scope files) — run Pint and delete the two commented lines.
  - **Touches:** `ComplaintController.php`, `Complaint.php`, `ComplaintAction.php`, `AiInsight.php`, `ComplaintDashboardService.php`, `ComplaintAIInsightEngine.php`, `ComplaintSaved.php`, `ProcessComplaintAIInsights.php`
  - **Before** (`ComplaintController.php:22` and `435`):
    ```php
    // use Modules\GlobalMaster\Models\Dropdown;
    ```
    ```php
                    // 'action_type_id' => 157,
    ```
  - **After:** delete both commented lines, then apply the preset:
    ```php
    vendor\bin\pint Modules\Complaint\app\Http\Controllers\ComplaintController.php Modules\Complaint\app\Models\Complaint.php Modules\Complaint\app\Models\ComplaintAction.php Modules\Complaint\app\Models\AiInsight.php Modules\Complaint\app\Services\ComplaintDashboardService.php Modules\Complaint\app\Services\ComplaintAIInsightEngine.php Modules\Complaint\app\Events\ComplaintSaved.php Modules\Complaint\app\Listeners\ProcessComplaintAIInsights.php
    ```
  - **Verify:** `vendor\bin\pint --test Modules\Complaint\app\Http\Controllers\ComplaintController.php --format agent`
  - **Expect:** `"result":"pass"`.
  - **Effort:** M

## 9. Deferred / decisions

- [ ] **CMP-14** · M · DECISION · CTL-01 — split the 1,896-line god controller?
  - **Why it is a decision:** a split changes class boundaries, route targets and the module's public surface; it is a multi-day refactor with a review cost, not a bug fix (D3).
  - (a) ⭐ **Split by responsibility now** — `ComplaintController` keeps CRUD, and four new controllers take `trash-lifecycle` (trashed/restore/forceDelete/reopen), `ajax-lookups` (getTableData/getTableColumns/getSectionsByClass/getSubCategories/getCategoryMeta/usersByRole), `dashboard` (filter + three donuts), and the tab-hub `index` moves to a `ComplaintHubController`. 23 public methods become ≤7 per class; route file updated in the same PR.
  - (b) **Split later, behind a service first** — extract `ComplaintService` (CMP-15) and the dashboard calls, leaving the controller a thin façade; split the class in a follow-up.
  - (c) **Accept and leave** — record the size as accepted debt and only apply CMP-15/CMP-17/CMP-18. Revisit if a fourth tab is added.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | None. All 41 findings (CMP-01…CMP-41) carry an item above; CMP-14 is the deliberately deferred DECISION in §9. The cross-cutting notes in `01-report.md` §7 (policies, `ComplaintCategory` swallow-catch, `MedicalCheck` media, `ComplaintAIInsightEngine::$is_sensitive`, `ComplaintDashboardService` null-guard) are informational and owned outside this report. |
