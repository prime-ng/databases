# Final Audit — Complaint / MedicalCheckController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php` (284 lines, 10 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /complaint/medical-checks/create` (`create`), `GET /complaint/medical-checks/{id}/edit` (`edit`), `GET /complaint/medical-checks/{id}` (`show`), `GET /complaint/medical-checks/trash/view` (`trashed`). Host: tenant domain `test.localhost` (`prm_tenant_domains` id 1). The list tab itself is **not** this controller — `GET /complaint/medical-checks` and the "Medical" tab of `/complaint/complaint-mgt?tab=medical` are served by `ComplaintController@index` (`Modules/Complaint/routes/web.php:161`), which renders `complaint::complaint.medical-checks.index`. |
| Menu path | **Support & Maintenance** (`glb_menus` id 294) → **Complaint** (id 297, `route = complaint.complaint-mgt.index`) → the **Medical** tab on that page. No `glb_menus` row points directly at this controller. |
| Who uses it | Roles that hold `tenant.complaint.medical-check.*`, measured from `sys_role_has_permissions_jnt` on tenant DB `xyz_school_00000000000040008000_202627`: **Super Admin** and **School Admin** (both hold all eight keys, ids 2384–2391). |
| What a user does here | Record one medical examination against a complaint that is flagged as requiring one: choose the complaint ticket, the check type (Alcohol/Drug/Fitness), a result, a reading value, the doctor and a date, and attach an evidence photo. From the list a user can also open a record read-only, edit it, soft-delete it, and (from the trash page) restore or permanently delete it. |
| Tables written | `cmp_medical_checks` (create, update, soft-delete, restore, force-delete). Media evidence is written to `sys_media` — but on the **central** `prime_db` connection, not the tenant DB (see MEDC-15). No audit row is written (`sys_activity_logs` is never touched). |
| Tables read | `cmp_medical_checks`, `cmp_complaints`, `sys_dropdown_table`, `sys_users`. |
| Live data | Tenant DB: `cmp_medical_checks` **4 live rows, 0 trashed**; `cmp_complaints` **12 rows**; `sys_dropdown_table` **716 rows**; `sys_users` **5630 rows**. (Counted 2026-10-17 on `xyz_school_00000000000040008000_202627`.) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready**. Its authorization and basic CRUD shape are sound, but it carries one live blocker: every evidence image it saves is written to the **central** `prime_db.sys_media` table instead of the tenant database, because `MedicalCheck` uses Spatie `InteractsWithMedia` without overriding `getMediaModel()` (MEDC-15) — a cross-tenant leak of personal health evidence on a path School Admin can use today. Behind that, `store`/`update`/`forceDelete` write more than one table with no transaction (MEDC-01), no upload is validated (MEDC-06), media is erased before the replacement is stored (MEDC-03), and `restore` changes state over GET (MEDC-08). The single worst finding is **MEDC-15**. Effort to apply the recommended plan: **M** (roughly half a day: one model method, one transaction wrapper, one FormRequest, one route verb, plus clean-ups).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 6 | 8 | 5 | 2 | 20 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | MEDC-01, MEDC-02, MEDC-03 | F9 Queries/Perf | MEDC-17 |
| F3 Authorization | MEDC-04, MEDC-05 | F10 Views | MEDC-18 |
| F4 Validation | MEDC-06, MEDC-07 | F11 Security/Tenancy | see MEDC-15 (F7) |
| F5 Routes | MEDC-08, MEDC-09, MEDC-10 | F12 Style | MEDC-19 |
| F6 Controller shape | MEDC-11, MEDC-12, MEDC-13, MEDC-14 | F13 Deep read | MEDC-01, MEDC-03, MEDC-18 (table) |
| F7 Models | MEDC-15, MEDC-16, MEDC-20 | | |

DECISION items: **MEDC-04**, **MEDC-20** (both in plan §9).

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Complaint/app/Http/Controllers/MedicalCheckController.php` | controller | 284 | this report | ✅ |
| 2 | `Modules/Complaint/app/Models/MedicalCheck.php` | model | 95 | this report (`_Info/00-CLASS-OWNERS.md`) | ✅ |
| 3 | `Modules/Complaint/resources/views/complaint/medical-checks/create.blade.php` | blade (`complaint::complaint.medical-checks.create`) | 98 | this report | ✅ |
| 4 | `Modules/Complaint/resources/views/complaint/medical-checks/edit.blade.php` | blade (`complaint::complaint.medical-checks.edit`) | 136 | this report | ✅ |
| 5 | `Modules/Complaint/resources/views/complaint/medical-checks/show.blade.php` | blade (`complaint::complaint.medical-checks.show`) | 174 | this report | ✅ |
| 6 | `Modules/Complaint/resources/views/complaint/medical-checks/trash.blade.php` | blade (`complaint::complaint.medical-checks.trash`) | 91 | this report | ✅ |
| 7 | `Modules/Complaint/resources/views/complaint/medical-checks/index.blade.php` | blade (`complaint::complaint.medical-checks.index`) | 221 | ↗ [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) — rendered by `ComplaintController@index`, not this class | ↗ linked |
| 8 | `Modules/Complaint/app/Models/Complaint.php` | model | — | ↗ [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) | ↗ linked — usage checked only |
| 9 | `Modules/Complaint/app/Models/ComplaintCategory.php` | model | — | ↗ [gaurav/Complaint/ComplaintCategoryController](../ComplaintCategoryController/01-report.md) | ↗ linked — imported but **unused** (MEDC-13) |
| 10 | `Modules/Complaint/app/Policies/MedicalCheckPolicy.php` | policy | 65 | this report (no prior owner row) | ✅ |
| 11 | `Modules/Complaint/routes/web.php` | route file (⚠ SHARED) | 198 | route-file owner | findings recorded here (MEDC-08, MEDC-09); edits go through a SHARED tick |
| 12 | `Modules/SchoolSetup/app/Models/User.php` | model | — | other module (common) | ↗ linked — usage only (MEDC-17) |

`MedicalCheck` is listed as owned by this report in `_Info/00-CLASS-OWNERS.md` (pre-assigned, 2026-10-17). `MedicalCheckPolicy.php` has no registry row; per the task instruction not to edit the registry, it is audited here and a claim is **not** appended. No pre-applied files.

## 4. Routes

```
POST      complaint/medical-checks                                complaint.medical-checks.store      Modules\Complaint\Http\Controllers\MedicalCheckController@store
GET|HEAD  complaint/medical-checks/create                         complaint.medical-checks.create     Modules\Complaint\Http\Controllers\MedicalCheckController@create
GET|HEAD  complaint/medical-checks/trash/view                     complaint.medical-checks.trashed    Modules\Complaint\Http\Controllers\MedicalCheckController@trashed
DELETE    complaint/medical-checks/{id}/force-delete              complaint.medical-checks.forceDelete Modules\Complaint\Http\Controllers\MedicalCheckController@forceDelete
GET|HEAD  complaint/medical-checks/{id}/restore                   complaint.medical-checks.restore    Modules\Complaint\Http\Controllers\MedicalCheckController@restore
GET|HEAD  complaint/medical-checks/{medical_check}                complaint.medical-checks.show       Modules\Complaint\Http\Controllers\MedicalCheckController@show
PUT|PATCH complaint/medical-checks/{medical_check}                complaint.medical-checks.update     Modules\Complaint\Http\Controllers\MedicalCheckController@update
DELETE    complaint/medical-checks/{medical_check}                complaint.medical-checks.destroy    Modules\Complaint\Http\Controllers\MedicalCheckController@destroy
GET|HEAD  complaint/medical-checks/{medical_check}/edit           complaint.medical-checks.edit       Modules\Complaint\Http\Controllers\MedicalCheckController@edit
```

Every route sits in the group `[web, Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains, Stancl\Tenancy\Middleware\InitializeTenancyByDomain, App\Http\Middleware\EnsureTenantIsActive, App\Http\Middleware\EnsureTenantHasModule:Complaint, Illuminate\Auth\Middleware\Authenticate, Illuminate\Auth\Middleware\EnsureEmailIsVerified]` — tenant middleware is present (RTE-05 satisfied).

Unrouted public methods:
- `index` (`MedicalCheckController.php:19`) — no route action points at it (`GET complaint/medical-checks` → `ComplaintController@index`, `web.php:161`; the resource is `->except(['index'])`, `web.php:162-164`). Reported as **MEDC-09**.

The resource parameter is `{medical_check}` for `show`/`update`/`destroy`/`edit` but the controller arguments are `$id` — reported as **MEDC-10**.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 19 | none (unrouted) | `tenant.complaint.medical-check.viewAny` | none | none | none | MEDC-09 |
| `create` | 53 | GET /complaint/medical-checks/create | `tenant.complaint.medical-check.create` | none | none | none (reads) | MEDC-13, MEDC-17 |
| `store` | 68 | POST /complaint/medical-checks | `tenant.complaint.medical-check.create` | none | none | `cmp_medical_checks`, `sys_media` | MEDC-01, MEDC-02, MEDC-06, MEDC-11, MEDC-12 |
| `edit` | 119 | GET complaint/medical-checks/{medical_check}/edit | `tenant.complaint.medical-check.update` | none | none | none (reads) | MEDC-10, MEDC-17 |
| `update` | 138 | PUT/PATCH complaint/medical-checks/{medical_check} | `tenant.complaint.medical-check.update` | none | none | `cmp_medical_checks`, `sys_media` | MEDC-01, MEDC-02, MEDC-03, MEDC-06, MEDC-10, MEDC-12 |
| `destroy` | 185 | DELETE complaint/medical-checks/{medical_check} | `tenant.complaint.medical-check.delete` | none | none | `cmp_medical_checks` | MEDC-02, MEDC-10 |
| `trashed` | 200 | GET /complaint/medical-checks/trash/view | `tenant.complaint.medical-check.restore` | none | none | none (reads) | MEDC-05 |
| `restore` | 221 | GET complaint/medical-checks/{id}/restore | `tenant.complaint.medical-check.restore` | none | none | `cmp_medical_checks` | MEDC-02, MEDC-08 |
| `forceDelete` | 236 | DELETE complaint/medical-checks/{id}/force-delete | `tenant.complaint.medical-check.forceDelete` | none | none | `cmp_medical_checks`, `sys_media` | MEDC-01, MEDC-02, MEDC-03 |
| `show` | 272 | GET complaint/medical-checks/{medical_check} | `tenant.complaint.medical-check.view` | none | none | none (reads) | MEDC-10 |

No method calls `activityLog()` or opens a `DB::transaction`. `create`/`edit`/`trashed`/`show` are read paths.

## 6. Findings

### F1 — Errors

clean — `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'try\s*\{','catch\s*\(','getMessage','report\(','Log::'` → no output. The controller has no `try`/`catch` and no exception text can reach a user (D1 satisfied).

### F2 — Transactions and audit

#### MEDC-01 · H · TXN-01 — `store`, `update` and `forceDelete` write two tables with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (two models, a model + its audit row, a model + pivot) runs inside one `DB::transaction`* |
| **Where** | `MedicalCheckController.php:86-108` (`store`), `:153-173` (`update`), `:240-245` (`forceDelete`) |
| **Root cause** | Each method writes `cmp_medical_checks` **and** `sys_media` (Spatie media rows + `clearMediaCollection`) as separate statements. `clearMediaCollection` and `addMediaFromRequest` issue their own writes/deletes; nothing groups them with the model write. There is no `DB::transaction` anywhere in the file. |
| **Consequence** | If the media write fails (bad MIME, disk error, oversized file — no validation guards it, see MEDC-06) the `cmp_medical_checks` row is already committed, leaving a medical check with `evidence_uploaded=true` set later (or false) and no file; in `forceDelete` a half-deleted record can survive a media failure. |
| **Reproduce** | static only — the missing transaction is a code-shape defect; triggering a mid-write failure needs a storage error. |
| **Fix approach** | Wrap the model write + `evidence_uploaded` update in one `DB::transaction(fn () => …)`; per D2 keep media work inside so the row rolls back with it, or move irreversible media work after commit and re-read MEDC-03. Plan item MEDC-01. |
| **Plan item** | MEDC-01 in `02-fix-plan.md` §3 |

```php
// MedicalCheckController.php:86-108 — CURRENT (store; no transaction)
        $medical = MedicalCheck::create($validated);

        if ($request->hasFile('medical_img')) {

            $medical->clearMediaCollection('medical_img');

            $medical
                ->addMediaFromRequest('medical_img')
                ->toMediaCollection('medical_img');

            // force DB write
            $medical->update([
                'evidence_uploaded' => true
            ]);
        } else {

            $medical->update([
                'evidence_uploaded' => false
            ]);
        }


        $medical->save();
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'DB::transaction','activityLog','beginTransaction'
(no output)
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern '->create\(|->update\(|->save\(|->delete\(|forceDelete\('
86:        $medical = MedicalCheck::create($validated);
97:            $medical->update([
102:            $medical->update([
108:        $medical->save();
153:        $medicalCheck->update($validated);
163:            $medicalCheck->update([
169:                $medicalCheck->update([
190:        $medicalCheck->delete();
245:        $medicalCheck->forceDelete();
```

#### MEDC-02 · M · TXN-04 — no `activityLog()` on any mutating method

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `store` (`:86-112`), `update` (`:153-177`), `destroy` (`:189-194`), `restore` (`:225-230`), `forceDelete` (`:240-249`) |
| **Root cause** | Every sibling Complaint controller logs an audit event (for example `ComplaintCategoryController.php:72 activityLog($category, 'Created', [ … ])`, `DepartmentSlaController.php:62`), but this controller never calls `activityLog`/`Log`. |
| **Consequence** | Creating, editing, deleting or restoring a medical check leaves no audit trail, so there is no record of who changed a health record — the module's other resources are audited, this one silently is not. |
| **Reproduce** | static only — `Select-String … -Pattern 'activityLog'` returns no output. |
| **Fix approach** | Add an `activityLog()` call inside each new transaction after the write (events to match siblings: `Created`, `Updated`, `Deleted`, `Restored`, `Force Deleted`). Plan item MEDC-02. |
| **Plan item** | MEDC-02 in `02-fix-plan.md` §3 |

```php
// MedicalCheckController.php:110-113 — CURRENT (store returns with no audit row)
        return redirect()
            ->route('complaint.complaint-mgt.index', ['tab' => 'medical'])
            ->with('success', 'Medical check created successfully.');
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'activityLog'
(no output)
$ Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintCategoryController.php -Pattern 'activityLog'
72:                activityLog($category, 'Created', [
143:                activityLog($category, 'Updated', [
```

#### MEDC-03 · H · TXN-03 — media is erased before its replacement (or the row) is safely stored

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B default, **lowered to H** — the loss is a single evidence file, not a table of data, but it is still irreversible) — *no irreversible side effect inside a transaction or before the write succeeds: file deletes, mail, HTTP* |
| **Where** | `MedicalCheckController.php:157-161` (`update`), `:243-245` (`forceDelete`) |
| **Root cause** | `update` calls `$medicalCheck->clearMediaCollection('medical_img')` **before** `addMediaFromRequest()`. `forceDelete` calls `clearMediaCollection` **before** `forceDelete()`. If the subsequent step throws (disk full, invalid file, DB error), the old media is already gone. |
| **Consequence** | Replacing an evidence photo can destroy the original even though the new one never uploaded; a failed permanent delete removes the file but can leave the soft-deleted row. The user sees a success flash (or a 500) and loses the only copy of the evidence. |
| **Reproduce** | static only — requires a storage/DB failure mid-operation. |
| **Fix approach** | Store the new media first and only then remove the old collection, and delete media after the `forceDelete()` succeeds (or via `DB::afterCommit`). Combined with MEDC-01's transaction. Plan item MEDC-03. |
| **Plan item** | MEDC-03 in `02-fix-plan.md` §3 |

```php
// MedicalCheckController.php:155-162 — CURRENT (update: clear before add)
        if ($request->hasFile('medical_img')) {

            $medicalCheck->clearMediaCollection('medical_img');

            $medicalCheck
                ->addMediaFromRequest('medical_img')
                ->toMediaCollection('medical_img');
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'clearMediaCollection'
90:            $medical->clearMediaCollection('medical_img');
157:            $medicalCheck->clearMediaCollection('medical_img');
243:        $medicalCheck->clearMediaCollection('medical_img');
```

### F3 — Authorization

#### MEDC-04 · M · AUTH-06 — `MedicalCheckPolicy` is registered but never consulted

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M default, kept — *permission strings live in one place*) plus F3's standing instruction *report every Policy that nothing consults* |
| **Where** | `Modules/Complaint/app/Policies/MedicalCheckPolicy.php`; registered at `Modules/Complaint/app/Providers/ComplaintServiceProvider.php:64` (`Gate::policy(MedicalCheck::class, MedicalCheckPolicy::class)`) |
| **Root cause** | The controller authorizes with **permission strings** (`Gate::authorize('tenant.complaint.medical-check.create')`). Laravel resolves a policy only when the ability is a policy method **and** a `MedicalCheck` model/class is passed as an argument. No call site passes the model, so the policy's seven methods are unreachable. |
| **Consequence** | The permission strings are duplicated in the controller, the policy, and the views, and the policy is dead code that invites a future developer to edit a file that changes nothing. |
| **Reproduce** | static only — `Select-String … -Pattern "Gate::authorize\('(viewAny|view|create|update|delete|restore|forceDelete)', MedicalCheck"` returns no output. |
| **Fix approach** | Tarun decides (plan MEDC-04, DECISION): (a) delete the policy and its `Gate::policy` registration, keeping the string gates, or (b) convert every check to `Gate::authorize('create', MedicalCheck::class)` and keep the policy. |
| **Plan item** | MEDC-04 in `02-fix-plan.md` §9 (DECISION) |

```php
// ComplaintServiceProvider.php:64 — CURRENT registration (policy never reached)
        Gate::policy(MedicalCheck::class, MedicalCheckPolicy::class);
```

**Evidence**
```
$ Select-String -Path . -Recurse -Pattern 'MedicalCheckPolicy'   (project-wide)
Modules\Complaint\app\Providers\ComplaintServiceProvider.php:20: use Modules\Complaint\Policies\MedicalCheckPolicy;
Modules\Complaint\app\Providers\ComplaintServiceProvider.php:64: Gate::policy(MedicalCheck::class, MedicalCheckPolicy::class);
Modules\Complaint\app\Policies\MedicalCheckPolicy.php:8: class MedicalCheckPolicy

$ Select-String (project) -Pattern "Gate::authorize\('(viewAny|view|create|update|delete|restore|forceDelete)', MedicalCheck"
(no output)
```

#### MEDC-05 · L · AUTH-01 — the trash list is gated on the write permission `.restore`

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B default, **lowered to L** — it is not a security hole; the gate used is stricter than needed) — *every routed method authorizes …* with a permission that matches the operation |
| **Where** | `MedicalCheckController.php:202` — `trashed()` calls `Gate::authorize('tenant.complaint.medical-check.restore')` |
| **Root cause** | `trashed()` is a **read** page (it lists soft-deleted rows) but is gated on the restore **write** permission. The read key `.viewAny` exists and is seeded for the same roles. |
| **Consequence** | A role granted `viewAny` but not `restore` cannot open the trash page at all; a role that only needs to see deleted records must be given restore rights. |
| **Reproduce** | As a role holding only `.viewAny`, open `/complaint/medical-checks/trash/view` → 403. |
| **Fix approach** | Change the gate on `trashed()` to `tenant.complaint.medical-check.viewAny` (already declared and seeded). Plan item MEDC-05. |
| **Plan item** | MEDC-05 in `02-fix-plan.md` §4 |

```php
// MedicalCheckController.php:200-202 — CURRENT
    public function trashed()
    {
        Gate::authorize('tenant.complaint.medical-check.restore');
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'Gate::authorize'
21:        Gate::authorize('tenant.complaint.medical-check.viewAny');
55:        Gate::authorize('tenant.complaint.medical-check.create');
70:        Gate::authorize('tenant.complaint.medical-check.create');
121:        Gate::authorize('tenant.complaint.medical-check.update');
140:        Gate::authorize('tenant.complaint.medical-check.update');
187:        Gate::authorize('tenant.complaint.medical-check.delete');
202:        Gate::authorize('tenant.complaint.medical-check.restore');
223:        Gate::authorize('tenant.complaint.medical-check.restore');
238:        Gate::authorize('tenant.complaint.medical-check.forceDelete');
274:        Gate::authorize('tenant.complaint.medical-check.view');
```

Note: all ten strings exist verbatim in `config/permissionslist.php:860` (`'complaint.medical-check' => array_merge($crud, ['export'])`, where `$crud = ['create','view','viewAny','update','delete','restore','forceDelete']`) and are seeded in the tenant DB (`tenant.complaint.medical-check.*`, ids 2384–2391) for **Super Admin** and **School Admin**. All routed methods authorize before loading a record (AUTH-02 satisfied).

### F4 — Validation and input

#### MEDC-06 · H · VAL-06 — the `medical_img` upload is never validated

| Field | Value |
|---|---|
| **Rule** | VAL-06 (H) — *every upload has `file` + `mimes:`/`mimetypes:` + `max:`* |
| **Where** | `MedicalCheckController.php:88` and `:155` (`if ($request->hasFile('medical_img'))`); the rule list at `:255-267` |
| **Root cause** | `validateMedicalCheck()` lists no `medical_img` rule at all, yet `store`/`update` feed the file straight into Spatie `addMediaFromRequest`. |
| **Consequence** | Any file type and any size can be attached (a `.php`, `.svg`, or a 500 MB file); a malformed upload can throw mid-write, which combines badly with the missing transaction (MEDC-01) and the media-before-write delete (MEDC-03). |
| **Reproduce** | `POST /complaint/medical-checks` with `medical_img` set to an oversized or non-image file → accepted (no 422) and handed to MediaLibrary. |
| **Fix approach** | Add `'medical_img' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:5120'` to the validation rules (and read it into the FormRequest created for MEDC-07). Plan item MEDC-06. |
| **Plan item** | MEDC-06 in `02-fix-plan.md` §5 |

```php
// MedicalCheckController.php:255-267 — CURRENT (no medical_img rule)
    protected function validateMedicalCheck(Request $request)
    {
        return $request->validate([
            'complaint_id' => 'required|exists:cmp_complaints,id',
            'check_type_id' => 'required|exists:sys_dropdown_table,id',
            'conducted_by' => 'nullable|string|max:100',
            'conducted_at' => 'required|date',
            'result' => 'required|exists:sys_dropdown_table,id',
            'reading_value' => 'nullable|string|max:50',
            'remarks' => 'nullable|string',
            // 'evidence_uploded' => 'boolean',
        ]);
    }
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'mimes|max:|mimetypes|hasFile'
88:        if ($request->hasFile('medical_img')) {
155:        if ($request->hasFile('medical_img')) {
```

#### MEDC-07 · M · VAL-02 — validation is inline in a controller helper, not a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request, not inline `$request->validate()` — except one-field AJAX toggles* |
| **Where** | `MedicalCheckController.php:255-267` (`validateMedicalCheck`), called from `store:77` and `update:144` |
| **Root cause** | A private `$request->validate()` helper was used instead of a dedicated `MedicalCheckRequest`. Sibling controllers (`ComplaintCategoryRequest`, `DepartmentSlaRequest`) use FormRequests with `authorizeByCrudPermission()`. |
| **Consequence** | Rules are not reusable by other entry points, and the FormRequest surface (`authorize()`, `after()` cross-field hooks) the project standard relies on is absent. |
| **Reproduce** | static only — `Select-String … -Pattern 'validate\('` finds the inline call and no `Request` class. |
| **Fix approach** | Extract the rules into a new `Modules/Complaint/app/Http/Requests/MedicalCheckRequest.php` (add the MEDC-06 upload rule there) and type-hint it in `store`/`update`. Plan item MEDC-07. |
| **Plan item** | MEDC-07 in `02-fix-plan.md` §5 |

```php
// MedicalCheckController.php:77 — CURRENT (inline validation)
        $validated = $this->validateMedicalCheck($request);
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'validate\(|FormRequest|Request \$'
68:    public function store(Request $request)
77:        $validated = $this->validateMedicalCheck($request);
138:    public function update(Request $request, $id)
144:        $validated = $this->validateMedicalCheck($request);
257:        return $request->validate([
```

### F5 — Routes

#### MEDC-08 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Complaint/routes/web.php:171-174` — `Route::get('medical-checks/{id}/restore', …)` |
| **Root cause** | `restore()` un-deletes a row (a write) but the route is registered with `Route::get`, unlike `force-delete` which correctly uses `Route::delete`. |
| **Consequence** | Any browser/preview prefetch or crawler that follows `/complaint/medical-checks/{id}/restore` silently un-deletes a record, with no CSRF token. |
| **Reproduce** | In the browser, open `/complaint/medical-checks/1/restore` directly as School Admin → the record is restored (a GET performs the state change). |
| **Fix approach** | ⚠ SHARED (route file): change `Route::get` to `Route::delete` (or `Route::post`) and update the trash-row action that links it. Plan item MEDC-08. |
| **Plan item** | MEDC-08 in `02-fix-plan.md` §5 |

```php
// Modules/Complaint/routes/web.php:171-174 — CURRENT
Route::get(
    'medical-checks/{id}/restore',
    [MedicalCheckController::class, 'restore']
)->name('medical-checks.restore');
```

**Evidence**
```
$ $env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --json 2>$null | php routesprobe.php "Modules\Complaint\Http\Controllers\MedicalCheckController"
GET|HEAD  complaint/medical-checks/{id}/restore    complaint.medical-checks.restore    Modules\Complaint\Http\Controllers\MedicalCheckController@restore
$ Select-String -Path Modules\Complaint\routes\web.php -Pattern "restore"
171: Route::get(
172:     'medical-checks/{id}/restore',
174: )->name('medical-checks.restore');
```

#### MEDC-09 · M · RTE-03 — `index()` is unrouted (D5)

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`, per D5)* |
| **Where** | `MedicalCheckController.php:19-48` (`index`); route facts at `Modules/Complaint/routes/web.php:161-164` |
| **Root cause** | `Route::get('medical-checks', [ComplaintController::class, 'index'])->name('medical-checks.index')` and `Route::resource('medical-checks', MedicalCheckController::class)->except(['index'])` — the real list is the "Medical" tab served by `ComplaintController@index`, so this `index()` can never be reached. |
| **Consequence** | Dead, misleading code: a future route could resurrect a body whose view expects `ComplaintController`-only variables (`$medicalChecksExport`, `$medicalComplaints`) and 500. |
| **Reproduce** | static only — no route action resolves to `MedicalCheckController@index` (probe output in §4). |
| **Fix approach** | Apply D5: replace the body with `abort(403, '…')` plus a `NOT ROUTED` comment; never delete the method. Plan item MEDC-09. |
| **Plan item** | MEDC-09 in `02-fix-plan.md` §5 |

```php
// MedicalCheckController.php:19-21 — CURRENT
    public function index(Request $request)
    {
        Gate::authorize('tenant.complaint.medical-check.viewAny');
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\routes\web.php -Pattern "medical-checks.index|except"
161: Route::get('medical-checks', [ComplaintController::class, 'index'])->name('medical-checks.index');
163:     ->except(['index'])
$ probe (MedicalCheckController) — actions listed: @store @create @trashed @forceDelete @restore @show @update @destroy @edit  (no @index)
```

#### MEDC-10 · L · RTE-06 — route parameter `{medical_check}` does not match the controller argument `$id`; no route model binding

| Field | Value |
|---|---|
| **Rule** | RTE-06 (M default, **lowered to L** — it works by position, no route conflict was found) plus CTL-03 *route model binding* |
| **Where** | `Modules/Complaint/routes/web.php:162-164` (resource names `{medical_check}`), against `MedicalCheckController.php:119,138,185,272` (`edit($id)`, `update(Request $request, $id)`, `destroy($id)`, `show($id)`) |
| **Root cause** | The resource is registered under `medical-checks`, so its parameter is `{medical_check}`, but every method takes `$id` and calls `findOrFail($id)` instead of using binding. |
| **Consequence** | Works today because Laravel passes the single route value positionally, but it is brittle and blocks `->withTrashed()` binding; a reader cannot tell from the signature which parameter is expected. |
| **Reproduce** | static only — `route:list` shows `{medical_check}`, the methods show `$id`. |
| **Fix approach** | Prefer route model binding: `public function show(MedicalCheck $medicalCheck)`, `edit(MedicalCheck $medicalCheck)`, `update(MedicalCheckRequest $request, MedicalCheck $medicalCheck)`, `destroy(MedicalCheck $medicalCheck)`; for trash routes use `MedicalCheck::onlyTrashed()` explicitly. Plan item MEDC-10. |
| **Plan item** | MEDC-10 in `02-fix-plan.md` §5 |

```php
// MedicalCheckController.php:138-142 — CURRENT
    public function update(Request $request, $id)
    {
        Gate::authorize('tenant.complaint.medical-check.update');

        $medicalCheck = MedicalCheck::findOrFail($id);
```

**Evidence**
```
$ probe (MedicalCheckController)
GET|HEAD  complaint/medical-checks/{medical_check}                complaint.medical-checks.show
PUT|PATCH complaint/medical-checks/{medical_check}                complaint.medical-checks.update
DELETE    complaint/medical-checks/{medical_check}                complaint.medical-checks.destroy
GET|HEAD  complaint/medical-checks/{medical_check}/edit           complaint.medical-checks.edit
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern '\$id'
119:    public function edit($id)
138:    public function update(Request $request, $id)
185:    public function destroy($id)
221:    public function restore($id)
236:    public function forceDelete($id)
272:    public function show($id)
```

### F6 — Controller shape

#### MEDC-11 · H · CTL-09 — commented-out `dd()` debug leftovers in `store`

| Field | Value |
|---|---|
| **Rule** | CTL-09 (H) — *no debug leftovers: `dd()`, `dump()`, … including commented-out `// dd(` (signals untested paths); live ones are B* |
| **Where** | `MedicalCheckController.php:71-75` |
| **Root cause** | Three commented `dd()`/debug lines and a commented merge block were left in `store` from development. |
| **Consequence** | Signals the create path was never finished/tested; dead noise that misleads the next reader and fails the debug-leftover gate. |
| **Reproduce** | static only. |
| **Fix approach** | Delete lines 71-75. Plan item MEDC-11. |
| **Plan item** | MEDC-11 in `02-fix-plan.md` §5 |

```php
// MedicalCheckController.php:71-75 — CURRENT
        // dd($request->all());
        // $request->merge([
        //     'evidence_uploded' => $request->has('evidence_uploded') ? 1 : 0,
        // ]);
        // dd($request->all());
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'dd\(|dump\(|var_dump|print_r'
71:        // dd($request->all());
75:        // dd($request->all());
```

#### MEDC-12 · M · CTL-05 — the "complaint must require a medical check" guard is copy-pasted

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same block repeated …* |
| **Where** | `MedicalCheckController.php:79-84` (`store`) and `:146-151` (`update`) |
| **Root cause** | The identical `Complaint::find()` + `is_medical_check_required` check + flash text is duplicated verbatim. |
| **Consequence** | Two copies can drift; a rule change must be made twice, and the error string says "created" even on update. |
| **Reproduce** | static only. |
| **Fix approach** | Extract one private guard (or a FormRequest `after()` hook) used by both methods; fix the message to "saved". Plan item MEDC-12. |
| **Plan item** | MEDC-12 in `02-fix-plan.md` §5 |

```php
// MedicalCheckController.php:79-84 — CURRENT (identical to :146-151)
        $complaint = Complaint::find($validated['complaint_id']);
        if (!$complaint || !$complaint->is_medical_check_required) {
            return back()
                ->withInput()
                ->with('error', 'Medical check can only be created for complaints whose category requires a medical check.');
        }
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'is_medical_check_required'
80:        if (!$complaint || !$complaint->is_medical_check_required) {
147:        if (!$complaint || !$complaint->is_medical_check_required) {
```

#### MEDC-13 · M · CTL-10 — dead code: unused import, redundant save, unused `create()` loads

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: unused imports, unused properties, redundant statements* |
| **Where** | Unused import `MedicalCheckController.php:9` (`use Modules\Complaint\Models\ComplaintCategory;`); redundant `$medical->save()` `:108` (the model was already persisted by `create()` and `update()`); unused `create()` payload `:59-61` (`checkTypes`, `results`, `users`) |
| **Root cause** | Scaffold leftovers: `ComplaintCategory` is imported and never referenced; `save()` re-persists an already-saved model; `create.blade.php` reads only `$complaints` (the dropdowns come from `<x-backend.form.form-dropdown>`, and `$users` is never read). |
| **Consequence** | Confusing dead code, plus three wasted queries on every create-page load (folded into MEDC-17 for the performance half). |
| **Reproduce** | static only. |
| **Fix approach** | Remove the unused import and the redundant `save()`; delete the three unused `create()` payload entries. Plan item MEDC-13. |
| **Plan item** | MEDC-13 in `02-fix-plan.md` §5 |

```php
// MedicalCheckController.php:9 — CURRENT
use Modules\Complaint\Models\ComplaintCategory;
// MedicalCheckController.php:106-108 — CURRENT
 

        $medical->save();
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'ComplaintCategory'
9:use Modules\Complaint\Models\ComplaintCategory;
$ Select-String -Path Modules\Complaint\resources\views\complaint\medical-checks\create.blade.php -Pattern '\$checkTypes|\$results|\$users'
(no output)
```

#### MEDC-14 · L · CTL-04 — public methods declare no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `MedicalCheckController.php:19, 53, 68, 119, 138, 185, 200, 221, 236, 272` |
| **Root cause** | Every method was written without a return-type clause. |
| **Consequence** | No user-visible effect; static analysis and IDE support are lost. |
| **Reproduce** | static only. |
| **Fix approach** | Add `: View` / `: RedirectResponse` (and `: never` after the MEDC-09 D5 disable) to each public method. Plan item MEDC-14. |
| **Plan item** | MEDC-14 in `02-fix-plan.md` §5 |

```php
// MedicalCheckController.php:53 — CURRENT
    public function create()
    {
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern ': View|: RedirectResponse|: JsonResponse|: never'
(no output)
```

### F7 — Models

#### MEDC-15 · B · MDL-05 / TEN-01 — tenant media is written to the central database (cross-tenant leak)

| Field | Value |
|---|---|
| **Rule** | MDL-05 / TEN-01 (B) — *every model using Spatie `InteractsWithMedia` in tenant context overrides `getMediaModel()` — otherwise media rows go to the central DB (cross-tenant leak)* |
| **Where** | `Modules/Complaint/app/Models/MedicalCheck.php:15-17` (implements `HasMedia`, uses `InteractsWithMedia`) with **no** `getMediaModel()` override |
| **Root cause** | The trait default `getMediaModel()` returns `config('media-library.media_model')`, which is `Modules\Prime\Models\Media` — a class that pins `protected $connection = 'mysql'` (the central `prime_db`). The codebase has `App\Models\TenantMedia` for exactly this purpose; `MedicalCheck` never opts in, so every `store`/`update` upload writes the evidence file record to `prime_db.sys_media` instead of the tenant's own `sys_media`. |
| **Consequence** | A child's medical evidence image (personal health data) is registered in the shared central database, mixed with every other tenant's files, and the tenant's own `cmp_medical_checks` row cannot join to it — a cross-tenant data leak and broken downloads. |
| **Reproduce** | As School Admin, create a medical check with an image, then run `SELECT COUNT(*) FROM prime_db.sys_media` — the row count grows there, not in the tenant `sys_media`. |
| **Fix approach** | Add `public function getMediaModel(): string { return \App\Models\TenantMedia::class; }` to `MedicalCheck` (as `Modules/CommonChat/app/Models/ChatMessage.php` already does). Plan item MEDC-15. |
| **Plan item** | MEDC-15 in `02-fix-plan.md` §1 |

```php
// Modules/Complaint/app/Models/MedicalCheck.php:15-19 — CURRENT (no override)
class MedicalCheck extends Model implements HasMedia
{
    use HasFactory, SoftDeletes, InteractsWithMedia;
    
    protected $table = 'cmp_medical_checks';
```

**Evidence**
```
$ Get-ChildItem -Recurse -Path Modules -Filter *.php | Select-String -Pattern 'function getMediaModel' -List | Select-Object -ExpandProperty Path
Modules\Admission\app\Models\Application.php
Modules\CommonChat\app\Models\ChatMessage.php
Modules\Library\app\Models\LibBookMaster.php
Modules\SchoolSetup\app\Models\Employee.php
Modules\SchoolSetup\app\Models\User.php
Modules\StudentProfile\app\Models\Guardian.php
Modules\StudentProfile\app\Models\Student.php
Modules\Complaint\app\Models\MedicalCheck.php is NOT in the output
$ Get-Content config\media-library.php | Select-String 'media_model'
    'media_model' => Media::class,
$ Get-Content config\media-library.php | Select-String 'use Modules\\Prime\\Models\\Media'
use Modules\Prime\Models\Media;
$ Get-Content Modules\Prime\app\Models\Media.php | Select-String 'connection'
    protected $connection = 'mysql';
$ bootstrap reflection: (new ReflectionMethod(MedicalCheck::class,'getMediaModel'))->getDeclaringClass()
Modules\Complaint\Models\MedicalCheck  (i.e. the inherited trait method; the file itself has no override)
```

#### MEDC-16 · L · MDL-04 — relationships declare no return type

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`…)* |
| **Where** | `Modules/Complaint/app/Models/MedicalCheck.php:75, 83, 91` (`complaint()`, `checkType()`, `resultStatus()`) |
| **Root cause** | The three relations were written as `public function complaint()` with no `: BelongsTo`. |
| **Consequence** | No user-visible effect; type information is lost. |
| **Reproduce** | static only. |
| **Fix approach** | Add `: BelongsTo` to each relation and import `Illuminate\Database\Eloquent\Relations\BelongsTo`. Plan item MEDC-16. |
| **Plan item** | MEDC-16 in `02-fix-plan.md` §5 |

```php
// Modules/Complaint/app/Models/MedicalCheck.php:75-78 — CURRENT
    public function complaint()
    {
        return $this->belongsTo(Complaint::class, 'complaint_id');
    }
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Models\MedicalCheck.php -Pattern 'public function|: BelongsTo'
75:    public function complaint()
83:    public function checkType()
91:    public function resultStatus()
(no ': BelongsTo' found)
```

#### MEDC-20 · M · MDL-04 / F7 — `resultStatus()` cannot resolve because `result` stores a label, not a dropdown id

| Field | Value |
|---|---|
| **Rule** | MDL-04 / F7 *relationships must resolve* — the relation is modelled on `result` as a dropdown id, but stored data holds the label |
| **Where** | Relation `MedicalCheck.php:91-94` (`belongsTo(Dropdown::class, 'result')`); data written by `Modules/Complaint/database/seeders/MedicalCheckSeeder.php:60` (`'result' => $resultValue`, e.g. `'Negative'`) |
| **Root cause** | The controller validates `result` as `exists:sys_dropdown_table,id` and the form posts a dropdown **id** (`create.blade.php:59-60`), but the seeder inserts the human **value** (`'Negative'`). The relation joins `cmp_medical_checks.result` to `sys_dropdown_table.id`, so seeded rows never match. |
| **Consequence** | On the existing data every Result cell renders `-` (see evidence), and the export column `resultStatus.value` (index.blade.php:65) is silently empty — the user sees a result they know exists displayed as blank. |
| **Reproduce** | Open the Medical tab (or `GET /complaint/medical-checks/1`) for the seeded rows — Result shows `-`; DB join returns NULL. |
| **Fix approach** | Tarun decides (plan MEDC-20, DECISION): (a) change the seeder to write dropdown **ids** and backfill the 4 existing rows, or (b) keep labels and re-model. Plan item MEDC-20. |
| **Plan item** | MEDC-20 in `02-fix-plan.md` §9 (DECISION) |

```php
// Modules/Complaint/database/seeders/MedicalCheckSeeder.php:30-34 — CURRENT
        $resultValues = [
            'AlcoholTest' => ['Negative', '0.000'],
            'DrugTest' => ['Negative', 'Clean'],
            'FitnessCheck' => ['Positive', 'Fit'],
        ];
```

```php
// Modules/Complaint/database/seeders/MedicalCheckSeeder.php:55-65 — CURRENT
            DB::table('cmp_medical_checks')->insert([
                'complaint_id' => $complaint->id,
                'check_type_id' => $typeId,
                'conducted_by' => 'Dr. A. Sharma',
                'conducted_at' => $now->copy()->subHours(rand(1, 12)),
                'result' => $resultValue,
                'reading_value' => $reading,
                'remarks' => "Routine {$typeName} completed for the complaint.",
                'evidence_uploaded' => false,
                'created_at' => $now,
            ]);
```

**Evidence**
```
$ mysql -uroot -e "SELECT m.id, m.result, d.value AS result_value FROM xyz_school_00000000000040008000_202627.cmp_medical_checks m LEFT JOIN xyz_school_00000000000040008000_202627.sys_dropdown_table d ON d.id=m.result;"
id  result      result_value
1   Negative    NULL
2   Negative    NULL
3   Negative    NULL
4   Negative    NULL
$ mysql -uroot -e "SELECT id,`key`,value FROM xyz_school_00000000000040008000_202627.sys_dropdown_table WHERE `key`='cmp_medical_checks.result';"
241  cmp_medical_checks.result  Positive
242  cmp_medical_checks.result  Negative
243  cmp_medical_checks.result  Inconclusive
```

Other model checks: `$table = 'cmp_medical_checks'` exists in `database/migrations/tenant/2026_06_15_155153_create_cmp_medical_checks_table.php` (MDL-07 ok); `SoftDeletes` present and `deleted_at` added by `2026_06_18_100115_add_deleted_at_to_cmp_medical_checks_table.php` (ok); `$fillable` declared, nothing sensitive (MDL-01 ok); `$casts` cover `conducted_at` (datetime) and `evidence_uploaded` (boolean) (MDL-02 ok). `checkType()` resolves (ids 238/239 are present dropdown rows).

### F8 — Services and jobs

clean — `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification|Export|Import)\b'` → no output. No service, job, event, mail or notification is referenced.

### F9 — Queries and performance

#### MEDC-17 · H · QRY-02 / QRY-15 — forms load whole tables (5630 users) for dropdowns the view does not use

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M default, **raised to H** — `User::all()` loads 5630 rows on every create-page open) / QRY-02 *no unbounded `->get()` feeding a list* |
| **Where** | `MedicalCheckController.php:57-62` (`create`): `Complaint::all()`, two `DB::table('sys_dropdown_table')->…->get(['id','value'])` calls, `User::all()`; `:131` (`edit`): `Complaint::all()` |
| **Root cause** | Dropdown data is loaded with `all()`/unfiltered `get()`; the create view reads only `$complaints` — `$checkTypes`/`$results` are supplied again by `<x-backend.form.form-dropdown>`, and `$users` is never referenced at all. |
| **Consequence** | Every open of the create page hydrates 5630 `User` models plus every complaint for data that is mostly discarded; on a large tenant this is a slow page and a memory spike. |
| **Reproduce** | Open `/complaint/medical-checks/create` with query logging on — three of the four queries are unused by the rendered page. |
| **Fix approach** | Remove `User::all()` and the unused `checkTypes`/`results` from `create()` (the components self-load); for `edit`/`create` complaint lists use `Complaint::where('is_medical_check_required', true)->get(['id','ticket_no','title'])`. Plan item MEDC-17. |
| **Plan item** | MEDC-17 in `02-fix-plan.md` §6 |

```php
// MedicalCheckController.php:57-62 — CURRENT
        return view('complaint::complaint.medical-checks.create', [
            'complaints' => Complaint::all(),
            'checkTypes' => DB::table('sys_dropdown_table')->where('key', 'cmp_medical_checks.check_type_id')->get(['id', 'value']),
            'results' => DB::table('sys_dropdown_table')->where('key', 'cmp_medical_checks.result')->get(['id', 'value']),
            'users' => User::all(),
        ]);
```

**Evidence**
```
$ mysql -uroot -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_users;"
5630
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern '::all\(\)'
58:            'complaints' => Complaint::all(),
61:            'users' => User::all(),
131:            'complaints' => Complaint::all(),
```

Note: `index()`'s `search` filter at `:26-31` uses an ungrouped `orWhere`, which would break boolean precedence if it were reachable, but `index()` is unrouted (MEDC-09) so it is dead. The pagination on the (unrouted) `index`/`trashed` uses `paginate(15)` with no `pageName`; not a live defect because the live list is `ComplaintController`'s (`…'med_page'`).

### F10 — Views

#### MEDC-18 · M · VIEW / F13-Q8 — the "Evidence Uploaded" checkbox is a dead control

| Field | Value |
|---|---|
| **Rule** | F13 deep-read item 8 (dead feature) / VAL-02 — the control's value is never read |
| **Where** | `Modules/Complaint/resources/views/complaint/medical-checks/edit.blade.php:94-98`; controller `update` `:144-173` |
| **Root cause** | The edit form posts `evidence_uploaded` (`name="evidence_uploaded" value="1"`), but the controller's rule for it is commented out (`MedicalCheckController.php:265`) and `update()` overwrites the column from the media state instead. `$validated` never contains the key. |
| **Consequence** | A user who ticks or unticks "Evidence Uploaded" and saves sees success while nothing they chose is stored — the message lies. |
| **Reproduce** | Edit a medical check, toggle "Evidence Uploaded", save → the column is unchanged (it follows the media state, not the checkbox). |
| **Fix approach** | Either remove the checkbox or honour it in validation and `update()`. Plan item MEDC-18. |
| **Plan item** | MEDC-18 in `02-fix-plan.md` §7 |

```php
// edit.blade.php:94-98 — CURRENT
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="evidence_uploaded"
                                                name="evidence_uploaded" value="1"
                                                {{ old('evidence_uploaded', $medicalCheck->evidence_uploaded) ? 'checked' : '' }}>
                                        </div>
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'evidence_uploaded'
98:                'evidence_uploaded' => true
103:                'evidence_uploaded' => false
164:                'evidence_uploaded' => true
170:                'evidence_uploaded' => false
265:            // 'evidence_uploded' => 'boolean',
$ Select-String -Path Modules\Complaint\resources\views\complaint\medical-checks\edit.blade.php -Pattern 'evidence_uploaded'
95:  <input class="form-check-input" type="checkbox" id="evidence_uploaded"
```

The four in-scope blades that this controller renders (`create`, `edit`, `show`, `trash`) contain no `Model::`/`DB::`/`->get()` queries (proved: `Select-String -Path Modules\Complaint\resources\views\complaint\medical-checks\*.blade.php -Pattern 'Model::','DB::','::where','::all\(','->get\(\)','->count\(\)'` → no output). `trash.blade.php` and `show.blade.php` use `complaint`/`checkType`/`resultStatus`, and both controller methods eager-load them (VIEW-02 satisfied). `index.blade.php` is rendered by `ComplaintController@index` and is ↗ linked.

### F11 — Security and tenancy

clean — `Select-String -Path Modules\Complaint\app\Http\Controllers\MedicalCheckController.php -Pattern 'env\(','Log::','\?\? 1','->all\(\)'` → no output (no `env()` outside config, no logging of request data, no hard-coded id fallback, no `$request->all()` into a model). Tenant middleware is present on all nine routes (§4). The one tenancy defect — media going to the central database — is reported as **MEDC-15** (TEN-01).

### F12 — Style

#### MEDC-19 · L · STY-01 / STY-02 / STY-04 — no `strict_types`, not Pint-clean, commented-out code

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) · STY-02 (L, *Pint-clean*) · STY-04 (L, *no commented-out code*) |
| **Where** | `MedicalCheckController.php` (whole file) and `Modules/Complaint/app/Models/MedicalCheck.php` (whole file) |
| **Root cause** | Neither file declares `declare(strict_types=1);`; both fail Pint (unsorted imports, spacing, unused import, class-attribute separation); the controller keeps the commented `dd()` block (MEDC-11). |
| **Consequence** | No user-visible effect; fails the project's Pint gate and the consistency standard. |
| **Reproduce** | static only. |
| **Fix approach** | Run `vendor/bin/pint` on both files and add `declare(strict_types=1);`. One style item per file. Plan item MEDC-19. |
| **Plan item** | MEDC-19 in `02-fix-plan.md` §8 |

```php
// MedicalCheckController.php:1-3 — CURRENT
<?php

namespace Modules\Complaint\Http\Controllers;
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Complaint\app\Http\Controllers\MedicalCheckController.php Modules\Complaint\app\Models\MedicalCheck.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Complaint\\app\\Http\\Controllers\\MedicalCheckController.php","fixers":["class_attributes_separation","function_declaration","no_multiline_whitespace_around_double_arrow","trailing_comma_in_multiline","no_unused_imports","not_operator_with_successor_space","no_extra_blank_lines","ordered_imports"]},{"path":"Modules\\Complaint\\app\\Models\\MedicalCheck.php","fixers":["class_attributes_separation","single_line_comment_spacing","ordered_traits","ordered_imports","no_whitespace_in_blank_line"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutating method | 1 overwrite? | 2 delete-before-store? | 3 duplicate impl? | 4 soft-delete × unique? | 5 race? | 6 auth hole? | 7 message lies? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` (`:68`) | ok | ok | MEDC-12 (guard duplicated) | ok (no unique index) | ok | ok (`Gate .create` first) | ok | MEDC-13 (redundant save) |
| `update` (`:138`) | ok | MEDC-03 | MEDC-12 (guard duplicated) | ok | ok | ok (`Gate .update` first) | MEDC-18 (evidence checkbox ignored) | MEDC-18 |
| `destroy` (`:185`) | ok | ok | ok | ok | ok | ok (`Gate .delete` first) | ok | ok |
| `restore` (`:221`) | ok | ok | ok | ok | ok | ok (`Gate .restore` first) — but reachable over GET (MEDC-08) | ok | ok |
| `forceDelete` (`:236`) | ok | MEDC-03 (media cleared before `forceDelete`) | ok | n/a (hard delete) | ok | ok (`Gate .forceDelete` first) | ok | ok |

No method has a race (no count-then-insert, no unique-index-vs-soft-delete trap). Question 6 is satisfied for direct calls; the only tenancy-level hole is MEDC-15 (media DB). Question 1: `update` writes only the validated columns, so it does not reset unrelated data.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Complaint/database/seeders/MedicalCheckSeeder.php:60` | Writes `result` as a **label** (`'Negative'`) while the controller/model treat `result` as a `sys_dropdown_table` id; the joined value is NULL for every seeded row. See MEDC-20. | MDL-04 / VAL-04 | module seeder owner (via the MEDC-20 DECISION) |
| `Modules/Complaint/app/Models/Complaint.php` | Also uses `InteractsWithMedia` without a `getMediaModel()` override — the same MDL-05/TEN-01 central-media leak. | MDL-05 / TEN-01 | `gaurav/Complaint/ComplaintController` |
| `Modules/Complaint/resources/views/complaint/medical-checks/index.blade.php` | Belongs to `ComplaintController@index` (needs `$medicalChecksExport`, `$medicalComplaints`); its row actions call this controller's routes. Not rendered by this controller. | — | `gaurav/Complaint/ComplaintController` |
| `Modules/Complaint/routes/web.php:171-174` | `restore` registered over GET (⚠ SHARED route file). | RTE-01 | route-file owner (via the MEDC-08 SHARED tick) |
| `Modules/Complaint/app/Providers/ComplaintServiceProvider.php:64` | Registers `MedicalCheckPolicy`, which nothing consults (⚠ SHARED provider file). | AUTH-06 | provider owner (via the MEDC-04 DECISION) |
| `config/permissionslist.php:860` | `'complaint.medical-check' => array_merge($crud, ['export'])` declares an `export` ability no method of this controller uses; harmless. | AUTH-06 | main session |

## 8. Not covered, and why

- **Scanner and self-check skipped.** Per Tarun's tooling override for this run, `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are **missing** (`Test-Path` → `False` for both), so `scan.php` was **not** run and the §15 self-check was **not** run. The F1–F13 checklist above was worked manually with the `read` tool, `Select-String`, `php -l`, the uncached `route:list` probe piped through `routesprobe.php`, a bootstrap `method_exists`/reflection probe, tenant-DB queries via the MySQL client, and `vendor/bin/pint --test`.
- **Live row counts and permission seeding** are measured on the one tenant DB present (`xyz_school_00000000000040008000_202627`, domain `test.localhost`); other tenants were not queried — ⚠ UNVERIFIED for tenants other than this one.
- **Upload/storage failure behaviour (MEDC-01/MEDC-03)** — not exercised: reproducing it needs a mid-write storage fault. The defect is proven statically (no `DB::transaction`; `clearMediaCollection` before `addMediaFromRequest`/`forceDelete`).
- **The media leak (MEDC-15) end-to-end count** — ⚠ UNVERIFIED — would be settled by uploading one image through `store` and re-counting `prime_db.sys_media` before/after; that requires a write, which this read-only audit did not perform. The code path (trait default → `config('media-library.media_model')` → `Modules\Prime\Models\Media`, connection `mysql`) is proven.
- **`MedicalCheckSeeder` was not run** — its `result` label behaviour is proven by reading its source and by the live join returning NULL, not by re-running it.
- **The `create`/`edit`/`show`/`trash` blades were not rendered** — findings there (MEDC-18) are static; the pages render only for an authorised tenant user and were not opened in a browser.
