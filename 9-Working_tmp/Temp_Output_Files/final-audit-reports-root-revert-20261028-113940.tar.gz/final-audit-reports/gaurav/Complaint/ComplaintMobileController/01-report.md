# Final Audit — Complaint / ComplaintMobileController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php` (686 lines, 9 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | JSON API, no HTML page. Base `http://test.localhost:8000/api/mobile/v1/admin/complaints` — sub-paths `dashboard`, `categories/list`, `categories/{id}/subcategories`, `dropdowns/{key}`, `users`, `{id}` (GET), `{id}` (POST). |
| Menu path | **None.** This is a mobile-app API, not a web menu. It is not referenced by `glb_menus`. |
| Who uses it | The mobile **admin** app. The six permissions it gates on are held by **Super Admin** and **School Admin** (measured 2026-10-17 on tenant `xyz_school_00000000000040008000_202627`; `sys_role_has_permissions_jnt`). |
| What a user does here | An admin opens the app to see complaint stats (dashboard), browse/search/filter the complaint list, open one complaint's detail and action history, create a complaint (with an optional photo), change its status / assignment / resolution, and load the category, sub-category, dropdown and user lists the create/edit forms need. |
| Tables written | `cmp_complaints`, `cmp_complaint_actions`, Spatie `media`, `notifications`; `ai_insights` via the `ComplaintSaved` listener. |
| Tables read | `cmp_complaints`, `cmp_complaint_categories`, `sys_dropdown_table`, `sys_users`, `sys_roles`, `cmp_department_sla`, `ai_insights`, `cmp_complaint_actions`. |
| Live data | tenant `xyz_school_00000000000040008000_202627`: `cmp_complaints` 12 live / 0 trashed, `cmp_complaint_actions` 30, `cmp_complaint_categories` 15, `cmp_department_sla` 15 (measured 2026-10-17). |

**How to reach each bug in the browser:** these are JSON endpoints; every finding is proven with a curl-style URL, a static read, or a direct DB query. Each finding says which under **Reproduce**.

## 1. Verdict

This controller is **not production-ready**. It is a working mobile API — every method authorizes against a real permission, every route resolves, and the list endpoint paginates — but it ships three blockers and a family of correctness bugs. The single worst finding is **CMBL-25**: the dashboard and the create method resolve the complaint status and priority ids through the dropdown key `cmp_complaints.status_id` / `cmp_complaint_categories.priority_score_id`, while this tenant's 12 real complaints all use ids 491–494 under the key `dummy_table_name.complaint_status` (and `dummy_table_name.priority_score`) — so the mobile dashboard reports **Open = 0 and Resolved = 0**, and every complaint created from the app is stamped with a status/priority id the rest of the module does not recognise. The next two blockers are a raw-exception leak (**CMBL-01**) and a file write inside a database transaction (**CMBL-05**). The full plan is roughly **M (a day)**: four structural items are deferred as DECISIONs, the rest are mechanical. Rough effort: **M**.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 3 | 8 | 12 | 2 | 2 | 25 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CMBL-01, CMBL-02 | F8 Services/Jobs | clean (usage note, §F8) |
| F2 Transactions/Audit | CMBL-03, CMBL-04, CMBL-05 | F9 Queries/Perf | CMBL-14, CMBL-15, CMBL-16, CMBL-17, CMBL-18, CMBL-19 |
| F3 Authorization | clean | F10 Views | n/a — no Blade |
| F4 Validation | CMBL-06, CMBL-07, CMBL-08, CMBL-09 | F11 Security/Tenancy | CMBL-20 |
| F5 Routes | clean | F12 Style | CMBL-21 |
| F6 Controller shape | CMBL-10, CMBL-11, CMBL-12, CMBL-13 | F13 Deep read | CMBL-22, CMBL-23, CMBL-24, CMBL-25 |
| F7 Models | ↗ linked (§3) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php` | controller | 686 | this report | ✅ |
| 2 | `Modules/Complaint/routes/mobile_api.php` | route file (⚠ SHARED) | 18 | route-file owner | ↗ linked — findings recorded here |
| 3 | `Modules/Complaint/app/Models/Complaint.php` | model | 370 | ↗ [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) (`_Info/00-CLASS-OWNERS.md:431`) | ↗ linked — usage checked, not re-audited |
| 4 | `Modules/Complaint/app/Models/ComplaintAction.php` | model | 101 | ↗ [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) (`:433`) | ↗ linked — usage checked |
| 5 | `Modules/Complaint/app/Models/ComplaintCategory.php` | model | 182 | ↗ [gaurav/Complaint/ComplaintCategoryController](../ComplaintCategoryController/01-report.md) (`:432`) | ↗ linked — usage checked |
| 6 | `Modules/Complaint/app/Models/DepartmentSla.php` | model | 179 | ↗ [gaurav/Complaint/DepartmentSlaController](../DepartmentSlaController/01-report.md) (`:434`) | ↗ linked — imported but unused here (CMBL-21) |
| 7 | `Modules/Complaint/app/Services/ComplaintDashboardService.php` | service | 514 | ↗ [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) (`:437`) | ↗ linked — usage checked (CMBL-18) |
| 8 | `Modules/Complaint/app/Events/ComplaintSaved.php` | event | 19 | ↗ [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) (`:439`) | ↗ linked — dispatch placement checked (CMBL-03/05) |
| 9 | `Modules/Complaint/app/Listeners/ProcessComplaintAIInsights.php` | listener | 21 | ↗ [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) (`:440`) | ↗ linked — not queued; cross-cutting §7 |
| 10 | `Modules/Complaint/app/Services/ComplaintAIInsightEngine.php` | service | 203 | ↗ [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) (`:438`) | ↗ linked — not re-audited |
| 11 | `app/Notifications/StudentPortalComplaintRegistered.php` | notification (common) | 51 | common (§4.2) | ❌ not audited — cross-cutting §7 |
| 12 | `Modules/Prime/app/Models/Dropdown.php`, `Modules/SchoolSetup/app/Models/User.php`, `Modules/SchoolSetup/app/Models/Role.php` | other-module models (common) | — | common (§4.2) | ❌ not audited — usage checked in F9/F11 |

No pre-applied files (`Modules/Complaint/` has no `PRE-APPLIED-*.md`).

## 4. Routes

Command:
```
$env:APP_ROUTES_CACHE="$env:TEMP\fa-nocache.php"; php artisan route:list --json 2>$null |
  php ...\routesprobe.php "Modules\Complaint\Http\Controllers\Mobile\ComplaintMobileController"
```
Output (real):
```
GET|HEAD  api/mobile/v1/admin/complaints                          -   ...ComplaintMobileController@index  [api,ValidateMobileApiKey,InitializeTenancyByMobileHeader,Authenticate:sanctum]
POST      api/mobile/v1/admin/complaints                          -   ...ComplaintMobileController@store  [same]
GET|HEAD  api/mobile/v1/admin/complaints/categories/list          -   ...ComplaintMobileController@categories  [same]
GET|HEAD  api/mobile/v1/admin/complaints/categories/{id}/subcategories - ...ComplaintMobileController@subcategories  [same]
GET|HEAD  api/mobile/v1/admin/complaints/dashboard                -   ...ComplaintMobileController@dashboard  [same]
GET|HEAD  api/mobile/v1/admin/complaints/dropdowns/{key}          -   ...ComplaintMobileController@dropdowns  [same]
GET|HEAD  api/mobile/v1/admin/complaints/users                    -   ...ComplaintMobileController@users  [same]
GET|HEAD  api/mobile/v1/admin/complaints/{id}                     -   ...ComplaintMobileController@show  [same]
POST      api/mobile/v1/admin/complaints/{id}                     -   ...ComplaintMobileController@update  [same]
```

Unrouted public methods: **none** — all nine public methods are routed (the `__construct` is not a route target).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `dashboard` | 37 | GET .../dashboard | `tenant.complaint.complaint-dashboard.viewAny` | none | none | none (reads) | CMBL-01, CMBL-18, CMBL-25 |
| `index` | 104 | GET .../complaints | `tenant.complaint.complaint.viewAny` | none | none | none (reads) | CMBL-01, CMBL-16, CMBL-17 |
| `show` | 181 | GET .../{id} | `tenant.complaint.complaint.view` | none | none | none (reads) | CMBL-02, CMBL-11, CMBL-14, CMBL-19 |
| `store` | 314 | POST .../complaints | `tenant.complaint.complaint.create` | controller manual (362/447) | **none** | cmp_complaints, cmp_complaint_actions, media, notifications | CMBL-01, CMBL-03, CMBL-04, CMBL-05, CMBL-06, CMBL-07, CMBL-08, CMBL-09, CMBL-10, CMBL-12, CMBL-20, CMBL-22, CMBL-23, CMBL-25 |
| `update` | 472 | POST .../{id} | `tenant.complaint.complaint.update` | controller manual (497/557) | **none** | cmp_complaints, cmp_complaint_actions | CMBL-01, CMBL-03, CMBL-04, CMBL-06, CMBL-08, CMBL-11, CMBL-24 |
| `categories` | 582 | GET .../categories/list | `tenant.complaint.complaint-category.viewAny` | none | none | none (reads) | — |
| `subcategories` | 602 | GET .../categories/{id}/subcategories | `tenant.complaint.complaint-category.viewAny` | none | none | none (reads) | — |
| `dropdowns` | 622 | GET .../dropdowns/{key} | `tenant.complaint.complaint.viewAny` | none | none | none (reads) | — |
| `users` | 658 | GET .../users | `tenant.complaint.complaint.update` | none | none | none (reads) | CMBL-15 |

## 6. Findings

### F1 — Errors

#### CMBL-01 · B · ERR-01 — raw exception text is returned to the mobile user in all five JSON responses

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; no `$e->getMessage()` in `response()->json`* (D1 also forbids a controller `try/catch` outside the D2 shapes) |
| **Where** | `ComplaintMobileController.php:90-96, 167-173, 300-306, 457-464, 567-574` (methods `dashboard`, `index`, `show`, `store`, `update`) |
| **Root cause** | Every method wraps its body in `try { … } catch (\Exception $e) { report($e); return response()->json(['message' => '…' . $e->getMessage()]); }`. `report()` is correct, but the same exception object's text is concatenated into the JSON body. D1 says the controller should have no `try/catch` at all — the central handler in `bootstrap/app.php` renders the failure. |
| **Consequence** | A failed query sends the SQL text, table and column names to the phone, e.g. `Failed to load complaints: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'x'` — an information leak and an ugly payload. |
| **Reproduce** | `curl -H "Accept: application/json" "http://test.localhost:8000/api/mobile/v1/admin/complaints"` with a forced bad filter, or open DevTools in the mobile app on any 500. |
| **Fix approach** | Per D1 remove the `try/catch`; at minimum replace every concatenated `$e->getMessage()` with a fixed sentence (plan item CMBL-01). |
| **Plan item** | CMBL-01 in `02-fix-plan.md` §1 |

```php
// ComplaintMobileController.php:90-96 — CURRENT (dashboard; the same shape repeats at 167,300,457,567)
        } catch (\Exception $e) {
            report($e);
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to load dashboard: ' . $e->getMessage(),
            ], 500);
        }
```

**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'getMessage'
94:                'message' => 'Failed to load dashboard: ' . $e->getMessage(),
171:                'message' => 'Failed to load complaints: ' . $e->getMessage(),
304:                'message' => 'Failed to load complaint: ' . $e->getMessage(),
462:                'message' => 'Failed to create complaint: ' . $e->getMessage(),
572:                'message' => 'Failed to update complaint: ' . $e->getMessage(),
```

#### CMBL-02 · H · ERR-02 — opening a deleted complaint returns a 500 with the SQL leak instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422/`abort()` into a redirect or 500* |
| **Where** | `ComplaintMobileController.php:185-306`, method `show()` (`try` at 185, `findOrFail($id)` at 198, `catch (\Exception $e)` at 300) |
| **Root cause** | `Complaint::with([...])->findOrFail($id)` sits **inside** the `try`. `findOrFail` throws `ModelNotFoundException`, which extends `RuntimeException` and then `Exception`, so the generic catch swallows it and renders HTTP 500 "Failed to load complaint: …" rather than a 404. D1 says `findOrFail()` belongs before the `try` (and, better, as route-model binding). |
| **Consequence** | A user who taps a complaint that was deleted on the web sees a generic server error (and the raw text — CMBL-01) instead of a clean "not found". |
| **Reproduce** | `curl -H "Accept: application/json" http://test.localhost:8000/api/mobile/v1/admin/complaints/999999` → HTTP 500, expected 404. |
| **Fix approach** | Move the `findOrFail` above the `try` (or drop the `try` entirely per D1). |
| **Plan item** | CMBL-02 in `02-fix-plan.md` §3 |

```php
// ComplaintMobileController.php:185-198 — CURRENT
        try {
            $complaint = Complaint::with([
                …
            ])->findOrFail($id);
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'try \{|findOrFail|catch \('
185:        try {
198:            ])->findOrFail($id);
300:        } catch (\Exception $e) {
476:        $complaint = Complaint::findOrFail($id);   # update(): correct — outside its try at 499
```

### F2 — Transactions and audit

#### CMBL-03 · M · TXN-02 — manual `beginTransaction`/`commit`/`rollBack` instead of `DB::transaction()`

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`; never `return` between them* |
| **Where** | `ComplaintMobileController.php:362-447, 457-458` (`store`) and `497-557, 567-568` (`update`) |
| **Root cause** | Both mutating methods open a transaction by hand and close it in the `try`, with `DB::rollBack()` in the `catch`. Any early `return` added between `beginTransaction()` and `commit()` leaks an open transaction; the closure form cannot. |
| **Consequence** | Maintainability/robustness debt — a future edit that returns early leaves the connection inside an open transaction, which on a pooled mobile connection can lock rows for the next request. |
| **Reproduce** | static only — the shape is visible at the quoted lines. |
| **Fix approach** | Replace the wrapper with `DB::transaction(function () { … });` and delete the `catch`/`rollBack` (D1). |
| **Plan item** | CMBL-03 in `02-fix-plan.md` §3 |

```php
// ComplaintMobileController.php:362-364 — CURRENT (store)
        DB::beginTransaction();

        try {
// ComplaintMobileController.php:447-447 — CURRENT
            DB::commit();
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'beginTransaction|DB::commit|DB::rollBack'
362:        DB::beginTransaction();
447:            DB::commit();
458:            DB::rollBack();
497:        DB::beginTransaction();
557:            DB::commit();
568:            DB::rollBack();
```

#### CMBL-04 · M · TXN-04 — neither mutation writes an `activityLog()` row, so the audit trail skips the mobile app

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `ComplaintMobileController.php:390-447` (`store`) and `500-557` (`update`) |
| **Root cause** | The only audit call is the private `logAction()` helper (`682-685`), which inserts a domain row into `cmp_complaint_actions`. The house A3 `activityLog()` (which writes `sys_activity_logs`) is never called. The two sibling web mutations in the same module do call it — `ComplaintController.php:458` (`activityLog($complaint, 'Created', …)`) and `:808` (`'Updated'`). |
| **Consequence** | A complaint created or edited from the phone leaves no row in the platform activity log, so the audit/activity screen cannot show who changed what from mobile. |
| **Reproduce** | static only — `activityLog(` does not occur in this file. |
| **Fix approach** | Add `activityLog($complaint, 'Created'|'Updated', […])` after the write, inside the transaction (plan item CMBL-04). |
| **Plan item** | CMBL-04 in `02-fix-plan.md` §3 |

```php
// ComplaintMobileController.php:431-437 — CURRENT (store; a domain action, not the A3 audit log)
            $this->logAction([
                'complaint_id' => $complaint->id,
                'action_type_id' => $actionTypeId,
                'performed_by_user_id' => Auth::id(),
                'performed_by_role_id' => Auth::user()->role_id ?? null,
                'notes' => "Complaint created with Ticket No {$ticketNo}",
            ]);
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'activityLog'
<no output>
$ Select-String -Path Modules\Complaint\app\Http\Controllers\ComplaintController.php -Pattern 'activityLog' | Select-Object -First 2
458:            activityLog($complaint, 'Created', [
808:                activityLog($complaint, 'Updated', [
```

#### CMBL-05 · B · TXN-03 — the uploaded photo is written to storage inside the database transaction

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B) — *no irreversible side effect inside a transaction; file writes/deletes, mail, SMS, push and HTTP calls happen after commit* |
| **Where** | `ComplaintMobileController.php:439-447`, method `store()` |
| **Root cause** | `$complaint->addMediaFromRequest('complaint_img')->toMediaCollection('complaint_img')` copies the uploaded file into the tenant media store **before** `DB::commit()`. A file write cannot be rolled back; if anything after it throws (lines 443-447 or a later step), the DB row is rolled back but the copied file — and its path prefix — remains, orphaned. |
| **Consequence** | Failed creates leave orphan image files on disk that no row points at, and the stored file count slowly drifts from the database. Severity kept at the rulebook default **B** because the side effect is unrecoverable by rollback. |
| **Reproduce** | static only — media handling is before the commit; a browser reproduction needs a failed create, which the running app cannot force without a test (D4). |
| **Fix approach** | Move the media block to run **after** the transaction closure returns (plan item CMBL-05). |
| **Plan item** | CMBL-05 in `02-fix-plan.md` §1 |

```php
// ComplaintMobileController.php:439-447 — CURRENT
            // Handle image upload
            if ($request->hasFile('complaint_img')) {
                $complaint->addMediaFromRequest('complaint_img')
                    ->toMediaCollection('complaint_img');
                $complaint->support_file = 1;
                $complaint->save();
            }

            DB::commit();
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'addMediaFromRequest|DB::commit'
441:                $complaint->addMediaFromRequest('complaint_img')
447:            DB::commit();          # commit comes AFTER the file write at 441
```

### F3 — Authorization

clean — all nine routed methods call `Gate::authorize()` before loading any record, and every ability exists and is seeded. Proving commands:
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'Gate::authorize' | Measure-Object
Count : 11                          # 9 routed methods; dashboard and category reads covered
$ php ...\permprobe.php             # exact-name lookup in the tenant sys_permissions
FOUND tenant.complaint.complaint-dashboard.viewAny (1)
FOUND tenant.complaint.complaint.viewAny (1)
FOUND tenant.complaint.complaint.view (1)
FOUND tenant.complaint.complaint.create (1)
FOUND tenant.complaint.complaint.update (1)
FOUND tenant.complaint.complaint-category.viewAny (1)
```
The `tenant.` prefix is produced by `PermissionCatalogService::nameFor()` (`scope.module.feature.action`, scope defaults to `tenant`), so `config/permissionslist.php` key `complaint.complaint` → permission `tenant.complaint.complaint.*` — the strings on all four surfaces agree. **Record-level authorization** (AUTH-03) is intentionally absent: this is an `admin/…` API and `InitializeTenancyByMobileHeader` isolates one tenant, so any holder of `.view` may read every complaint in the tenant — noted, not raised, because that is the admin scope by design. Cross-cutting: the string gates never reach `ComplaintPolicy` / `ComplaintCategoryPolicy` / `ComplaintDashboardPolicy` (they resolve through `hasPermissionTo`) — see §7.

### F4 — Validation and input

#### CMBL-06 · M · VAL-02 — validation is inline in the controller, not in a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request; inline `$request->validate()` is allowed only for a one-field AJAX toggle* |
| **Where** | `ComplaintMobileController.php:344-360` (`store`) and `482-492` (`update`) |
| **Root cause** | Both write methods define their rule arrays inline. These are full create/update payloads, not a one-field toggle, so a `FormRequest` (e.g. `ComplaintMobileRequest`) is the project standard. |
| **Consequence** | The rules cannot be reused or unit-tested in isolation, and the two payloads have drifted (the create rules do not match the fields the method writes — see CMBL-07). |
| **Reproduce** | static only. |
| **Fix approach** | Extract both rule sets into a `ComplaintMobileRequest` and call `$request->validated()` (plan item CMBL-06). |
| **Plan item** | CMBL-06 in `02-fix-plan.md` §5 |

```php
// ComplaintMobileController.php:344-360 — CURRENT
        $validated = $request->validate([
            'complainant_type_id' => 'required|exists:sys_dropdown_table,id',
            'category_id' => 'required|exists:cmp_complaint_categories,id',
            …
            'target_code' => 'nullable|string',
        ]);
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'request->validate'
344:        $validated = $request->validate([
482:        $validated = $request->validate([
```

#### CMBL-07 · H · VAL-05 — fields written to the model are never validated

| Field | Value |
|---|---|
| **Rule** | VAL-05 (H) — *write paths with unvalidated fields are High; every field is typed* |
| **Where** | `ComplaintMobileController.php:399, 411-413` (`target_table_name`, `target_column`) and `324`→`397` (`complainant_contact`, anonymous branch), method `store()` |
| **Root cause** | The `validate()` array (344-360) has no rule for `target_table_name` or `target_column`, yet both are written: `target_table_name` into the `cmp_complaints` column and into the `dept_specific_info` JSON cast, `target_column` into the same JSON. For an anonymous complaint, `complainant_contact` is read raw at line 324 and written at 397 with no rule. `target_table_name` is the morph column the `targetable()` relation resolves against, so it is security-relevant. |
| **Consequence** | A client can store any string as the target table/column and as the anonymous contact — values that later render in the detail screen and drive polymorphic lookups. |
| **Reproduce** | `POST .../api/mobile/v1/admin/complaints` with `"target_table_name":"sys_users"` — accepted, stored. |
| **Fix approach** | Add `string` rules (and, for `target_table_name`, an allow-list) to the FormRequest (plan item CMBL-07). |
| **Plan item** | CMBL-07 in `02-fix-plan.md` §5 |

```php
// ComplaintMobileController.php:399-413 — CURRENT
                'target_table_name' => $request->target_table_name,
                …
                'dept_specific_info' => array_filter([
                    'target_table_name' => $request->input('target_table_name'),
                    'target_column' => $request->input('target_column'),
                    'target_code' => $request->input('target_code'),
                ], fn($v) => $v !== null && $v !== ''),
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern "target_table_name|target_column"
399: 'target_table_name' => $request->target_table_name,
411: 'target_table_name' => $request->input('target_table_name'),
412: 'target_column' => $request->input('target_column'),
# no rule line contains either name in the validate() blocks at 344-360 / 482-492
```

#### CMBL-08 · M · VAL-05 — foreign-key ids are validated as bare `integer`, with no `exists` check

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; `exists` for a foreign key* |
| **Where** | `ComplaintMobileController.php:349-357` (`store`) and `483-491` (`update`) |
| **Root cause** | `severity_level_id => 'required\|integer'`, `priority_score_id => 'nullable\|integer'`, `target_id => 'nullable\|integer'`; in `update`, `status_id`, `assigned_to_user_id`, `assigned_to_role_id`, `resolved_by_user_id`, `resolved_by_role_id`, `source_id` are all `nullable\|integer`. None carries `exists:`, unlike `category_id` and `complainant_user_id` which do. |
| **Consequence** | A client can save a complaint or assignment pointing at a status/user/role id that does not exist; the detail screen then shows a blank label (`?? '-'`) for a value the DB accepted. |
| **Reproduce** | `POST .../api/mobile/v1/admin/complaints/{id}` with `"status_id":999999` → 200 OK, complaint now points at a non-existent dropdown. |
| **Fix approach** | Add `exists:` to each FK rule in the FormRequest (plan item CMBL-08). |
| **Plan item** | CMBL-08 in `02-fix-plan.md` §5 |

```php
// ComplaintMobileController.php:483-491 — CURRENT (update)
            'status_id' => 'nullable|integer',
            'assigned_to_role_id' => 'nullable|integer',
            'assigned_to_user_id' => 'nullable|integer',
            …
            'source_id' => 'nullable|integer',
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern "nullable\|integer|required\|integer"
349: 'severity_level_id' => 'required|integer',
350: 'priority_score_id' => 'nullable|integer',
357: 'target_id' => 'nullable|integer',
483-491: status_id / assigned_to_* / resolved_by_* / source_id  → all 'nullable|integer'
```

#### CMBL-09 · H · VAL-06 — the image upload has no `mimes`/`max` rule

| Field | Value |
|---|---|
| **Rule** | VAL-06 (H) — *every upload has `file` + `mimes:`/`mimetypes:` + `max:`* |
| **Where** | `ComplaintMobileController.php:440-442`, method `store()` |
| **Root cause** | `complaint_img` is handled with `$request->hasFile('complaint_img')` but no `'complaint_img' => 'file|mimes:…|max:…'` rule exists in the validation array (344-360). Any file type and any size is accepted. |
| **Consequence** | A user can upload an executable, an oversized file, or non-image content that becomes the complaint's `.support_file` media and is served by `getFirstMediaUrl('complaint_img')`. |
| **Reproduce** | `curl -F "complaint_img=@evil.php" ... POST .../api/mobile/v1/admin/complaints` → accepted. |
| **Fix approach** | Add `'complaint_img' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:5120'` to the FormRequest (plan item CMBL-09). |
| **Plan item** | CMBL-09 in `02-fix-plan.md` §5 |

```php
// ComplaintMobileController.php:440-442 — CURRENT
            if ($request->hasFile('complaint_img')) {
                $complaint->addMediaFromRequest('complaint_img')
                    ->toMediaCollection('complaint_img');
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern "complaint_img|mimes|max:"
440: if ($request->hasFile('complaint_img')) {
441:     $complaint->addMediaFromRequest('complaint_img')
442:         ->toMediaCollection('complaint_img');
# no mimes:/max: rule for complaint_img anywhere in the file
```

### F5 — Routes

clean — nine routes, all pointing at existing methods; no state change over GET; the custom prefixes (`categories/list`, `categories/{id}/subcategories`, `dropdowns/{key}`, `users`) are declared **before** the `{id}` catch-all in `Modules/Complaint/routes/mobile_api.php:9-17`; every route sits in `api,ValidateMobileApiKey,InitializeTenancyByMobileHeader,Authenticate:sanctum`. Proven by the §4 probe output and:
```
$ Get-Content Modules\Complaint\routes\mobile_api.php | Select-Object -Skip 8 -First 9
        Route::get('dashboard', 'dashboard');
        Route::get('categories/list', 'categories');
        Route::get('categories/{id}/subcategories', 'subcategories');
        Route::get('dropdowns/{key}', 'dropdowns');
        Route::get('users', 'users');
        Route::get('', 'index');
        Route::post('', 'store');
        Route::get('{id}', 'show');
        Route::post('{id}', 'update');
```
(No route name is set on any of the nine; that is not a rulebook violation for a JSON API, but it means no `route()` call can build these URLs.)

### F6 — Controller shape

#### CMBL-10 · H · CTL-02 — `store()` is 152 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — *a method over 150 lines is High (over 80 is M)* |
| **Where** | `ComplaintMobileController.php:314-465`, method `store()` |
| **Root cause** | One method performs five jobs — complainant resolution, ticket-number generation, create, admin notification, action logging and media handling — instead of delegating. |
| **Consequence** | The method is hard to review and every change risks the ticket-number block or the transaction; a bug in any of the five jobs hides in one 152-line body. |
| **Reproduce** | static only — length measured below. |
| **Fix approach** | Extract ticket generation and the create pipeline into a service / private methods (deferred DECISION, plan §9). |
| **Plan item** | CMBL-10 in `02-fix-plan.md` §9 (DECISION — structural) |

```php
// ComplaintMobileController.php:314 — CURRENT (method start)
    public function store(Request $request): JsonResponse
    {
// …closing brace at 465 → 152 lines
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'public function'
314: public function store(Request $request): JsonResponse   # ends 465  → 152 lines  (>150 = H)
```

#### CMBL-11 · M · CTL-02 — `show()` (127) and `update()` (104) exceed 80 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *a method over 80 lines should be extracted* |
| **Where** | `ComplaintMobileController.php:181-307` (`show`) and `:472-575` (`update`) |
| **Root cause** | `show()` builds a ~100-field response array inline and resolves roles/options in the same body; `update()` repeats three near-identical "log this change" blocks. |
| **Consequence** | Hard to diff and review; the duplicated change-log blocks drift apart. |
| **Reproduce** | static only. |
| **Fix approach** | Extract the payload mapping into a resource/mapper and the change-log blocks into a helper (deferred DECISION, plan §9). |
| **Plan item** | CMBL-11 in `02-fix-plan.md` §9 (DECISION — structural) |

```php
// ComplaintMobileController.php:181 — CURRENT (method start)
    public function show(int $id): JsonResponse
    {
// …ends 307 → 127 lines
```
**Evidence**
```
$ Select-String ... -Pattern 'public function'
181: public function show(int $id): JsonResponse    # ends 307 → 127 lines  (>80 = M)
472: public function update(Request $request, int $id): JsonResponse  # ends 575 → 104 lines
```

#### CMBL-12 · M · CTL-06 — business logic (ticket numbering, notification, media) lives in the controller

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in services; a controller reads input, calls one service, returns a response* |
| **Where** | `ComplaintMobileController.php:373-445`, method `store()` |
| **Root cause** | Ticket-number generation (`CMP-YYYY-000001`), the admin notification fan-out and the media handling are inlined in the controller. There is already a `ComplaintController` doing the same create on the web surface, so the two create paths are separate implementations of one operation. |
| **Consequence** | The web and mobile create pipelines can diverge (they already do — the mobile one resolves the wrong status ids, CMBL-25) and there is no single place to fix create behaviour. |
| **Reproduce** | static only. |
| **Fix approach** | Extract a `ComplaintCreationService` (deferred DECISION, plan §9). |
| **Plan item** | CMBL-12 in `02-fix-plan.md` §9 (DECISION — structural) |

```php
// ComplaintMobileController.php:373-386 — CURRENT
            // Generate ticket number: CMP-YYYY-000001
            $year = now()->year;
            $lastTicket = Complaint::where('ticket_no', 'like', "CMP-{$year}-%")
                ->orderBy('ticket_no', 'desc')
                ->lockForUpdate()
                ->first();
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'ticketNo|Notification::send|addMediaFromRequest'
375: $lastTicket = Complaint::where('ticket_no', 'like', "CMP-{$year}-%")
381: $ticketNo = 'CMP-' . $year . '-' . str_pad(...)
423: Notification::send($admins, new StudentPortalComplaintRegistered($complaint));
441: $complaint->addMediaFromRequest('complaint_img')
```

#### CMBL-13 · M · CTL-03 — `show`/`update` take `int $id` and call `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` + `findOrFail`* |
| **Where** | `ComplaintMobileController.php:181` (`show(int $id)`), `:472` (`update(Request $request, int $id)`); routes `mobile_api.php:16-17` |
| **Root cause** | The routes are `Route::get('{id}', 'show')` / `Route::post('{id}', 'update')` and the methods accept a raw `int` and call `Complaint::findOrFail($id)` themselves. |
| **Consequence** | Maintainability only — the model is not injected, so `show`/`update` cannot use implicit binding or route-level scoping. |
| **Reproduce** | static only. |
| **Fix approach** | Rename the route parameter to `{complaint}` and type-hint `Complaint $complaint` — this changes `mobile_api.php` (⚠ SHARED), hence a DECISION. |
| **Plan item** | CMBL-13 in `02-fix-plan.md` §9 (DECISION — route file) |

```php
// Modules/Complaint/routes/mobile_api.php:16-17 — CURRENT
        Route::get('{id}', 'show');
        Route::post('{id}', 'update');
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'function show|function update' | Select-Object -First 2
181: public function show(int $id): JsonResponse
472: public function update(Request $request, int $id): JsonResponse
```

### F7 — Models

↗ linked. `Complaint`, `ComplaintAction`, `ComplaintCategory`, `DepartmentSla` are owned by other reports (`_Info/00-CLASS-OWNERS.md:431-434`), so their internals are not re-audited here. How this controller **uses** them was checked: `Complaint::create()` uses only `$fillable` keys, `ComplaintAction::create()` uses only `$fillable` keys, and `ComplaintCategory::select()` picks real columns. One cross-cutting model defect surfaced (media tenancy) — §7. The `Complaint` model's own comment (`Complaint.php:305-325`) is what proves CMBL-25.

### F8 — Services and jobs

clean in the controller — the only injected dependency is `ComplaintDashboardService` (constructor injection, `:27-30`), and the controller does not construct services mid-method or perform HTTP inside one. Usage note: `dashboard()` calls `getRecentCriticalTickets()` directly at `:46` while `getDashboardData()` already calls it at service `:83` — recorded as CMBL-18 (F9). The `ComplaintSaved` listener `ProcessComplaintAIInsights` does **not** implement `ShouldQueue` and runs inside the create transaction; that is the listener's defect and is recorded as a cross-cutting note (§7), not a SVC finding here.
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern '__construct|new .*Service|->dashboardService'
27:    public function __construct(
28:        protected ComplaintDashboardService $dashboardService
45:            $dashboard = $this->dashboardService->getDashboardData($from, $to);
46:            $criticalTickets = $this->dashboardService->getRecentCriticalTickets($from, $to);
```

### F9 — Queries and performance

#### CMBL-14 · H · QRY-01 — N+1 query in `show()` (one count query per role)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; eager-load or pre-fetch* |
| **Where** | `ComplaintMobileController.php:213-221`, method `show()` |
| **Root Cause** | `Role::orderBy('name')->get()->map(fn ($role) => ['user_count' => $role->users()->count()])` runs one `COUNT` query for **every role** in the tenant. |
| **Consequence** | The complaint-detail screen issues 1 + N role queries on every open; with many roles the detail page slows down linearly. |
| **Reproduce** | Open a complaint in the mobile app and watch the query log, or count with a tinker loop. |
| **Fix approach** | Use `Role::withCount('users')` once (plan item CMBL-14). |
| **Plan item** | CMBL-14 in `02-fix-plan.md` §6 |

```php
// ComplaintMobileController.php:213-221 — CURRENT
            $roles = Role::orderBy('name')
                ->get()
                ->map(function ($role) {
                    return [
                        'id' => $role->id,
                        'name' => $role->name,
                        'user_count' => $role->users()->count(),
                    ];
                });
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'users\(\)->count'
219:                        'user_count' => $role->users()->count(),
```

#### CMBL-15 · H · QRY-02 — `users()` returns every user in the tenant with no pagination

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H) — *no unbounded `->get()` feeding a JSON list* |
| **Where** | `ComplaintMobileController.php:658-672`, method `users()` |
| **Root cause** | `User::select('id','name')->orderBy('name')->get()` returns the whole `sys_users` table when no `role_id` filter is supplied; the mobile app calls this with no filter to populate an assignment picker. |
| **Consequence** | On a large school the response (and the phone's memory) grows with the user count; the endpoint has no `per_page`. |
| **Reproduce** | `curl .../api/mobile/v1/admin/complaints/users` → returns all users in one JSON array. |
| **Fix approach** | Require/paginate, or cap with `limit()` on the picker (plan item CMBL-15). |
| **Plan item** | CMBL-15 in `02-fix-plan.md` §6 |

```php
// ComplaintMobileController.php:662-672 — CURRENT
        $query = User::select('id', 'name')
            ->orderBy('name');

        if ($request->filled('role_id')) {
            $role = Role::find($request->role_id);
            if ($role) {
                $query->role($role->name);
            }
        }

        $users = $query->get();
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern '\$users = \$query->get'
672:        $users = $query->get();
```

#### CMBL-16 · M · QRY-02 — `per_page` is taken from the client with no upper bound

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M) — *lists paginate at 10; the page size must not be client-unbounded* |
| **Where** | `ComplaintMobileController.php:133-134`, method `index()` |
| **Root cause** | `$perPage = (int) $request->get('per_page', 10);` then `$query->paginate($perPage)`. A client can send `per_page=100000`. |
| **Consequence** | A single request can load the whole complaints table into memory and return a multi-megabyte JSON payload. |
| **Reproduce** | `curl "...//complaints?per_page=100000"` → all rows. |
| **Fix approach** | Clamp: `min(50, max(1, (int) …))` (plan item CMBL-16). |
| **Plan item** | CMBL-16 in `02-fix-plan.md` §6 |

```php
// ComplaintMobileController.php:133-134 — CURRENT
            $perPage = (int) $request->get('per_page', 10);
            $complaints = $query->paginate($perPage);
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'per_page'
133:            $perPage = (int) $request->get('per_page', 10);
```

#### CMBL-17 · M · QRY-08 — leading-wildcard `LIKE '%search%'` search

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M) — *a leading-wildcard `LIKE` cannot use an index* |
| **Where** | `ComplaintMobileController.php:110-117`, method `index()` |
| **Root cause** | The search wraps four columns in `'like', "%{$search}%"`. |
| **Consequence** | Each search does a full table scan across four columns; on a large complaints table the list endpoint slows under load. |
| **Reproduce** | `curl ".../complaints?search=abc"` and inspect the slow-query log. |
| **Fix approach** | Accept as small-table, or add a prefix match / search column (plan item CMBL-17). |
| **Plan item** | CMBL-17 in `02-fix-plan.md` §6 |

```php
// ComplaintMobileController.php:112-116 — CURRENT
                    $q->where(function ($query) use ($search) {
                        $query->where('ticket_no', 'like', "%{$search}%")
                            ->orWhere('title', 'like', "%{$search}%")
                            ->orWhere('complainant_name', 'like', "%{$search}%")
                            ->orWhere('target_name', 'like', "%{$search}%");
                    });
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern "like', \"%"
113: $query->where('ticket_no', 'like', "%{$search}%")
114:     ->orWhere('title', 'like', "%{$search}%")
115:     ->orWhere('complainant_name', 'like', "%{$search}%")
116:     ->orWhere('target_name', 'like', "%{$search}%");
```

#### CMBL-18 · M · QRY-12 — the critical-tickets query runs twice per dashboard request

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) — *identical queries repeated in one request are resolved once* |
| **Where** | `ComplaintMobileController.php:45-46` calling `ComplaintDashboardService::getDashboardData()` (`:83`) and `getRecentCriticalTickets()` |
| **Root cause** | `dashboard()` calls `$this->dashboardService->getRecentCriticalTickets($from, $to)` at line 46 for the `critical_tickets` key, but `getDashboardData()` already computes and returns `criticalTickets` at service line 83 — the controller ignores that value and re-runs the query. |
| **Consequence** | Two identical `Complaint … orderBy resolution_due_at limit 5` queries per dashboard load. |
| **Reproduce** | static only — both call sites quoted below. |
| **Fix approach** | Use `$dashboard['criticalTickets']` returned by `getDashboardData()` (plan item CMBL-18). |
| **Plan item** | CMBL-18 in `02-fix-plan.md` §6 |

```php
// ComplaintMobileController.php:45-46 — CURRENT
            $dashboard = $this->dashboardService->getDashboardData($from, $to);
            $criticalTickets = $this->dashboardService->getRecentCriticalTickets($from, $to);
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'getRecentCriticalTickets'
46:            $criticalTickets = $this->dashboardService->getRecentCriticalTickets($from, $to);
$ Select-String -Path Modules\Complaint\app\Services\ComplaintDashboardService.php -Pattern 'getRecentCriticalTickets'
83:            'criticalTickets' => $this->getRecentCriticalTickets($from, $to),
104:    public function getRecentCriticalTickets(Carbon $from, Carbon $to)
```

#### CMBL-19 · L · QRY-03 — `show()` eager-loads `medicalChecks` that the response never uses

| Field | Value |
|---|---|
| **Rule** | QRY-03 (L) — *select / load only what you use* |
| **Where** | `ComplaintMobileController.php:197`, method `show()` |
| **Root Cause** | `->with([... 'medicalChecks'])` loads the media-check relation, but the response array (231-293) contains no `medicalChecks` key. |
| **Consequence** | One wasted query per detail open; harmless, but it hides the fact that medical-check data is not exposed to mobile. |
| **Reproduce** | static only. |
| **Fix approach** | Drop `medicalChecks` from the `with()` list (plan item CMBL-19). |
| **Plan item** | CMBL-19 in `02-fix-plan.md` §6 |

```php
// ComplaintMobileController.php:186-198 — CURRENT (last relation)
                'actions.assignedToUser',
                'medicalChecks',
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'medicalChecks'
197:                'medicalChecks',
# no 'medicalChecks' key in the response array (lines 229-299)
```

### F10 — Views

n/a — this is a JSON controller; it renders no Blade. `grep -n "view(" ComplaintMobileController.php` → no output.

### F11 — Security and tenancy

#### CMBL-20 · M · SEC-03 — hard-coded fallback ids `124` and `3` for status and priority

| Field | Value |
|---|---|
| **Rule** | SEC-03 (M) — *no hard-coded ids or fallbacks such as `?? 1` for a user/tenant/status id* |
| **Where** | `ComplaintMobileController.php:365-367` (status `?? 124`) and `:369-371` (priority `?? 3`), method `store()` |
| **Root cause** | When the dropdown lookup returns null the code silently falls back to a magic id: `->value('id') ?? 124` and `->value('id') ?? 3`. Neither 124 nor 3 is a valid id in this tenant's dropdown table (measured: status ids are 220-225 / 491-496, priority ids 197-201 / 457-461). |
| **Consequence** | If the lookup ever returns null, the complaint is created pointing at a non-existent status/priority id, and the detail screen shows `-`. |
| **Reproduce** | static only — the fallback ids are literals. |
| **Fix approach** | Fail loudly (throw a `DomainException`) or use the module's real key; never a magic id (plan item CMBL-20). |
| **Plan item** | CMBL-20 in `02-fix-plan.md` §1 |

```php
// ComplaintMobileController.php:365-371 — CURRENT
            $statusId = Dropdown::where('key', 'cmp_complaints.status_id')
                ->where('value', 'Open')
                ->value('id') ?? 124;
            …
            $priorityScoreId = Dropdown::where('key', 'cmp_complaint_categories.priority_score_id')
                ->where('value', 'Medium')
                ->value('id') ?? 3;
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern '124|=> 3'
367:                ->value('id') ?? 124;
371:                ->value('id') ?? 3;
```

### F12 — Style

#### CMBL-21 · L · STY-02 / STY-05 — Pint fails on the file and one import is unused

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean* · STY-05 (L) — *one import per class, no unused imports* |
| **Where** | `ComplaintMobileController.php` file-wide; unused import at `:19` (`use Modules\Complaint\Models\DepartmentSla;`) |
| **Root cause** | The file was hand-written without running Pint; `DepartmentSla` is imported but never referenced. Pint reports seven fixers including `no_unused_imports`, `ordered_imports`, `concat_space`, `not_operator_with_successor_space`, `function_declaration`, `blank_line_before_statement`, `single_line_empty_body`. |
| **Consequence** | Cosmetic/consistency only; a stale import misleads a reader about what the controller touches. |
| **Reproduce** | `vendor\bin\pint --test Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php --format agent`. |
| **Fix approach** | Run `vendor\bin\pint` on this one file; it removes the unused import and fixes the rest (one style item for the one file, per §12). |
| **Plan item** | CMBL-21 in `02-fix-plan.md` §8 |

```php
// ComplaintMobileController.php:19 — CURRENT (unused)
use Modules\Complaint\Models\DepartmentSla;
```
**Evidence**
```
$ vendor\bin\pint --test Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Complaint\\app\\Http\\Controllers\\Mobile\\ComplaintMobileController.php","fixers":["function_declaration","concat_space","no_unused_imports","not_operator_with_successor_space","single_line_empty_body","blank_line_before_statement","ordered_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutating method | 1 Wrong data | 2 Delete before store | 3 Duplicate impl | 4 Soft-delete×unique | 5 Race | 6 Authz hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` (314) | CMBL-25 | ok | CMBL-12 | CMBL-22 | CMBL-23 | ok (gated) | CMBL-25 | ok |
| `update` (472) | CMBL-24 | ok | ok | ok | ok | ok (gated) | ok | ok |

#### CMBL-22 · H · VAL-04 / F13-Q4 — soft-deleted complaints can make the next generated `ticket_no` collide

| Field | Value |
|---|---|
| **Rule** | VAL-04 / F13-Q4 (H) — *a uniqueness rule must mirror the real index including soft-delete semantics* |
| **Where** | `ComplaintMobileController.php:375-386`, method `store()`; `Complaint` uses `SoftDeletes` (`Complaint.php:20`) and `cmp_complaints.ticket_no` carries a unique index (`uq_ticket_no`, measured) |
| **Root cause** | The serial is derived from `Complaint::where('ticket_no','like',"CMP-{$year}-%")->orderByDesc()->first()` and the collision guard is `Complaint::where('ticket_no',$ticketNo)->exists()`. Both use the **default** scope, which excludes trashed rows. A unique index, however, includes trashed rows. If a trashed complaint holds a higher serial than the live maximum, the next live serial can equal a trashed serial and the unique index rejects the insert. |
| **Consequence** | Once any complaint is soft-deleted, the next mobile create can fail with a duplicate-key 500 (surfaced by CMBL-01). Latent today (0 trashed rows) but armed as soon as the web trash/restore button is used. |
| **Reproduce** | static only — measured: `uq_ticket_no` is unique; `Complaint` uses `SoftDeletes`; the guard query has no `withTrashed()`. |
| **Fix approach** | Use `->withTrashed()` in both the max lookup and the exists guard (plan item CMBL-22). |
| **Plan item** | CMBL-22 in `02-fix-plan.md` §2 |

```php
// ComplaintMobileController.php:375-386 — CURRENT
            $lastTicket = Complaint::where('ticket_no', 'like', "CMP-{$year}-%")
                ->orderBy('ticket_no', 'desc')
                ->lockForUpdate()
                ->first();
            $nextSerial = $lastTicket ? ((int) substr($lastTicket->ticket_no, -6) + 1) : 1;
            $ticketNo = 'CMP-' . $year . '-' . str_pad((string) $nextSerial, 6, '0', STR_PAD_LEFT);
            while (Complaint::where('ticket_no', $ticketNo)->exists()) {
                $nextSerial++;
                $ticketNo = 'CMP-' . $year . '-' . str_pad((string) $nextSerial, 6, '0', STR_PAD_LEFT);
            }
```
**Evidence**
```
$ php ...\dbprobe.php
ticket_no_indexes=1
  uq_ticket_no unique=yes
complaints_trashed=0
$ Select-String -Path Modules\Complaint\app\Models\Complaint.php -Pattern 'use HasFactory, SoftDeletes'
20:    use HasFactory, SoftDeletes, InteractsWithMedia;
```

#### CMBL-23 · M · TXN-06 — the ticket-serial check-then-act races under concurrent creates

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M, lowered from H) — *check-then-act needs a lock or a unique index* |
| **Where** | `ComplaintMobileController.php:375-386`, method `store()` |
| **Root cause** | The serial is read (`orderByDesc()->lockForUpdate()->first()`), incremented, then re-checked in a `while ... exists()` loop. `lockForUpdate()` locks existing rows but not the gap where the next row will go; two requests that read the same last serial both compute the same next number. |
| **Consequence** | Two simultaneous creates can compute the same `ticket_no`; the unique index rejects the second, which then returns a 500 (not corruption). Lowered to **M** from the rulebook default **H** because the unique index prevents a duplicate row — the damage is a failed request, not bad data. |
| **Reproduce** | static only — a true race cannot be forced without a test (D4). |
| **Fix approach** | Rely on a dedicated sequence/`AUTO_INCREMENT`, or catch the duplicate and retry once inside the transaction (plan item CMBL-23). |
| **Plan item** | CMBL-23 in `02-fix-plan.md` §3 |

```php
// ComplaintMobileController.php:377-386 — CURRENT
                ->lockForUpdate()
                ->first();
            …
            while (Complaint::where('ticket_no', $ticketNo)->exists()) {
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'lockForUpdate|->exists\(\)'
377:                ->lockForUpdate()
383:            while (Complaint::where('ticket_no', $ticketNo)->exists()) {
```

#### CMBL-24 · H · F13-Q1 — omitting the flags on an update silently resets `is_escalated` and `is_medical_check_required` to 0

| Field | Value |
|---|---|
| **Rule** | F13-Q1 (H) — *wrong data: a write overwrites data it should not* |
| **Where** | `ComplaintMobileController.php:494-495`, method `update()` |
| **Root cause** | `$validated['is_escalated'] = $request->boolean('is_escalated') ? 1 : 0;` (and the medical-check twin) are set **unconditionally** and then passed to `$complaint->update($validated)` at 500. `$request->boolean()` returns `false` when the key is absent, so any update that does not send these two fields forces both columns back to 0. |
| **Consequence** | An admin who only changes the status from the app turns off an escalation flag and a required medical check without asking — silent data loss on a normal path. |
| **Reproduce** | `POST .../api/mobile/v1/admin/complaints/{id}` with only `{"status_id":…}` against a complaint whose `is_escalated=1` → it becomes 0. |
| **Fix approach** | Only set the flags when the request actually has them: `if ($request->has('is_escalated')) { $validated['is_escalated'] = …; }` (plan item CMBL-24). |
| **Plan item** | CMBL-24 in `02-fix-plan.md` §2 |

```php
// ComplaintMobileController.php:494-495 — CURRENT
        $validated['is_escalated'] = $request->boolean('is_escalated') ? 1 : 0;
        $validated['is_medical_check_required'] = $request->boolean('is_medical_check_required') ? 1 : 0;
```
**Evidence**
```
$ Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'is_escalated|is_medical_check_required'
494:        $validated['is_escalated'] = $request->boolean('is_escalated') ? 1 : 0;
495:        $validated['is_medical_check_required'] = $request->boolean('is_medical_check_required') ? 1 : 0;
500:            $complaint->update($validated);
```

#### CMBL-25 · B · F13-Q1 / F13-Q7 — status and priority are resolved through the wrong dropdown key, so the dashboard shows 0 open / 0 resolved and new complaints get foreign status ids

| Field | Value |
|---|---|
| **Rule** | F13-Q1 (B) — *wrong data written* · F13-Q7 (B) — *messages that lie* |
| **Where** | `ComplaintMobileController.php:49-58` (`dashboard`) and `:365-371` (`store`) |
| **Root cause** | Both methods resolve ids with `Dropdown::where('key','cmp_complaints.status_id')->where('value','Open'/'Resolved')` and `…'cmp_complaint_categories.priority_score_id'…`. That key returns ids **220 / 223** (status) and **200** (priority). But this tenant's complaints all use the key `dummy_table_name.complaint_status` — ids **491–494** — and `dummy_table_name.priority_score` — ids **457–461**. The `Complaint` model documents exactly this trap (`Complaint.php:305-325`). The dashboard's `Complaint::where('status_id', $statusOpenId)->count()` therefore counts 0. |
| **Consequence** | The mobile dashboard reports **Open = 0** and **Resolved = 0** while 8 open and 1 resolved complaint exist; every complaint created from the app is stamped `status_id=220` / `priority_score_id=200`, ids the web filters and dashboard never match. Severity **B**: the create writes data inconsistent with the rest of the module's own rows. |
| **Reproduce** | `curl .../api/mobile/v1/admin/complaints/dashboard` → `"open":0,"resolved":0` although the tenant has 8 open + 1 resolved. |
| **Fix approach** | Resolve statuses by reading the related row's value (as the model accessor does) or use the module's real key `dummy_table_name.complaint_status`; drop the hard-coded fallbacks too (plan item CMBL-25). |
| **Plan item** | CMBL-25 in `02-fix-plan.md` §1 |

```php
// ComplaintMobileController.php:49-58 — CURRENT (dashboard)
            $statusOpenId = Dropdown::where('key', 'cmp_complaints.status_id')
                ->where('value', 'Open')
                ->value('id');
            $statusResolvedId = Dropdown::where('key', 'cmp_complaints.status_id')
                ->where('value', 'Resolved')
                ->value('id');
            $total = Complaint::count();
            $openCount = $statusOpenId ? Complaint::where('status_id', $statusOpenId)->count() : 0;
            $resolvedCount = $statusResolvedId ? Complaint::where('status_id', $statusResolvedId)->count() : 0;
```
**Evidence**
```
$ php ...\ddprobe.php
id=220 key=cmp_complaints.status_id value=Open
id=223 key=cmp_complaints.status_id value=Resolved
id=491 key=dummy_table_name.complaint_status value=Open
id=494 key=dummy_table_name.complaint_status value=Resolved
-- actual status_id values on complaints --
status_id=491 count=8
status_id=492 count=2
status_id=493 count=1
status_id=494 count=1
priority Medium id=200   (key cmp_complaint_categories.priority_score_id)
id=460 key=dummy_table_name.priority_score value=Medium   # the ids the module actually uses
```
The dashboard's ids 220/223 match **0** rows; ids 491/494 match 9.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Complaint/app/Models/Complaint.php` | Uses Spatie `InteractsWithMedia` in tenant context with **no `getMediaModel()` override** (`Complaint.php:18-20,121-124`), so tenant complaint images can be written to the central media table — the controller's `addMediaFromRequest` is the first writer. | MDL-05 / TEN-01 | [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) |
| `Modules/Complaint/app/Listeners/ProcessComplaintAIInsights.php` | Does not implement `ShouldQueue` (`:8`), so the AI-insight `updateOrCreate` runs synchronously inside the create transaction. | JOB-04 | [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) |
| `app/Notifications/StudentPortalComplaintRegistered.php` | Not `ShouldQueue`; its `toArray()` calls the **web** route `route('complaint.complaints.show', …)`, which exists, so no error — informational only. | JOB-04 | common (`app/`) |
| `Modules/Complaint/app/Policies/*` | `ComplaintPolicy`, `ComplaintCategoryPolicy`, `ComplaintDashboardPolicy` exist but the string gates used here resolve via Spatie `hasPermissionTo`, never through these policies. | AUTH-06 | the Complaint module / policy owner |
| `Modules/Complaint/app/Models/Complaint.php:177-180` | `target()` returns `$this->target_id` (a scalar, not a relation), which is a misleading API. | MDL-04 | [gaurav/Complaint/ComplaintController](../ComplaintController/01-report.md) |
| `Modules/Complaint/routes/mobile_api.php` | Route file (⚠ SHARED) — no route names; only touched by the CMBL-13 DECISION. | RTE | route-file owner / main session |

## 8. Not covered, and why

- **`_tools/scanfilter.py` and `_tools/selfcheck.py` are missing** from `final-audit-reports/_tools/`, and this run's brief forbids running `scan.php`; **the scanner and the self-check were therefore skipped.** The F1–F13 checklist was worked **manually** with `read`/`Select-String`, `php -l`, `vendor\bin\pint --test`, the route probe and direct tenant DB queries. The §15 self-check PASS line cannot be produced this run.
- **No browser check.** These are JSON endpoints; no HTML page renders. Each finding that can be shown in the app is given a `curl` URL under **Reproduce**; the rest are marked "static only".
- **No `php artisan test` / Pest / Dusk** — D4 forbids testing, so the ticket-number race (CMBL-23) and the rollback-orphan (CMBL-05) are argued statically and labelled as such.
- **The linked classes were not re-audited** (§5) — `Complaint`, `ComplaintAction`, `ComplaintCategory`, `DepartmentSla`, `ComplaintDashboardService`, `ComplaintSaved`, `ProcessComplaintAIInsights`, `ComplaintAIInsightEngine` are owned by other reports; only how this controller calls them was checked.
- **The `Modules/Prime\Models\Dropdown` and `Modules/SchoolSetup` models** are other-module/common and were checked only for usage (the dropdown-key mismatch CMBL-25 is a controller defect, proven against live data).
