# Fix Plan — Complaint / ComplaintMobileController

**From:** `01-report.md` (2026-10-17) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php` for developer `gaurav`. It applies **only** ticked items, in this order.
>
> ⚠ **Items A1, A2, B, C, D all edit `ComplaintMobileController.php` and some edit the same methods.** Apply them top-to-bottom; re-read the method before each one (final-audit.md §9.2 #3). Each item's **Before** lines below are copied from today's file and survive the earlier items unchanged, so a sequential apply never has to merge.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Complaint/routes/mobile_api.php` | route file (⚠ SHARED) — touched **only** by the §9 CMBL-13 DECISION, and only with its own explicit tick |
| `config/permissionslist.php` | shared config (⚠ SHARED) — already contains the `complaint.*` keys; this plan adds none |
| `Modules/Complaint/app/Models/Complaint.php`, `ComplaintAction.php`, `ComplaintCategory.php`, `DepartmentSla.php` | owned by other reports (`_Info/00-CLASS-OWNERS.md:431-434`) |
| `Modules/Complaint/app/Services/ComplaintDashboardService.php`, `ComplaintAIInsightEngine.php`, `Events/ComplaintSaved.php`, `Listeners/ProcessComplaintAIInsights.php` | owned by `gaurav/Complaint/ComplaintController` (`_Info/00-CLASS-OWNERS.md:437-440`) |
| `app/Notifications/StudentPortalComplaintRegistered.php` | common class (§4.2) |
| `final-audit-reports/_Info/00-CLASS-OWNERS.md`, `final-audit-reports/gaurav/Complaint/00-INDEX.md` | maintained by the main session |

## 1. Blockers reachable today

- [ ] **A1** · B · ERR-01 · `ComplaintMobileController.php:41,90-96,108,167-173,185,300-306` — remove the `try/catch` from the three read methods so no `$e->getMessage()` reaches the phone and `show()` returns a real 404 (also fixes CMBL-02).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Before** (`ComplaintMobileController.php` — the `try {` openers and the three catch blocks; delete every span exactly as written):
    ```php
    // :41 (dashboard) — delete this line
            try {
    // :90-96 (dashboard) — delete this whole block
            } catch (\Exception $e) {
                report($e);
                return response()->json([
                    'status' => 'error',
                    'message' => 'Failed to load dashboard: ' . $e->getMessage(),
                ], 500);
            }
    // :108 (index) — delete this line
            try {
    // :167-173 (index) — delete this whole block
            } catch (\Exception $e) {
                report($e);
                return response()->json([
                    'status' => 'error',
                    'message' => 'Failed to load complaints: ' . $e->getMessage(),
                ], 500);
            }
    // :185 (show) — delete this line
            try {
    // :300-306 (show) — delete this whole block
            } catch (\Exception $e) {
                report($e);
                return response()->json([
                    'status' => 'error',
                    'message' => 'Failed to load complaint: ' . $e->getMessage(),
                ], 500);
            }
    ```
  - **After:**
    ```php
    // Delete the six spans quoted above and change nothing else. Each method's
    // body keeps its original statements; a failure now propagates to the central
    // handler in bootstrap/app.php, which renders JSON for an API request (ERR-00/D1).
    // show()'s `findOrFail($id)` is no longer inside a catch, so a missing complaint
    // correctly yields HTTP 404 instead of the old 500 (ERR-02 / CMBL-02).
    // Reindent the formerly-nested bodies with Pint (item L).
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'try \{' | Select-Object -First 1`
  - **Expect:** the first remaining `try {` is inside `store()` (was line 364), i.e. no `try {` in `dashboard`, `index` or `show`.
  - **Effort:** S

- [ ] **A2** · B · ERR-01 / TXN-03 · `ComplaintMobileController.php:314-465,472-575` — rewrite `store()` and `update()`: one `DB::transaction` closure each (TXN-02), no `try/catch` (D1, no `$e->getMessage()`), the media file written **after** commit (TXN-03), and `activityLog()` after the write inside the transaction (TXN-04). Also fixes CMBL-03, CMBL-04, CMBL-05.
  - **Touches:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Before** (`ComplaintMobileController.php:314-465`, method `store()`):
    ```php
    public function store(Request $request): JsonResponse
    {
        Gate::authorize('tenant.complaint.complaint.create');

        $user = auth()->user();

        if ($request->boolean('is_anonymous')) {
            $complainantType = 'Anonymous';
            $complainantUserId = null;
            $complainantName = $request->input('complainant_name', 'Anonymous');
            $complainantContact = $request->input('complainant_contact');
        } else {
            $userType = $user->user_type ?? 'Staff';
            $complainantType = strtolower($userType) === 'student' ? 'Student' : 'Staff';
            $complainantUserId = $user->id;
            $complainantName = null;
            $complainantContact = $user->mobile_no ?? null;
        }

        $complainantTypeId = Dropdown::where('key', 'cmp_complaints.complainant_type_id')
            ->where('value', $complainantType)
            ->value('id');

        $request->merge([
            'complainant_type_id' => $complainantTypeId,
            'complainant_user_id' => $complainantUserId,
            'complainant_name' => $complainantName,
            'complainant_contact' => $complainantContact,
        ]);

        $validated = $request->validate([
            'complainant_type_id' => 'required|exists:sys_dropdown_table,id',
            'category_id' => 'required|exists:cmp_complaint_categories,id',
            'subcategory_id' => 'nullable|exists:cmp_complaint_categories,id',
            'target_type_id' => 'nullable|exists:sys_dropdown_table,id',
            'severity_level_id' => 'required|integer',
            'priority_score_id' => 'nullable|integer',
            'title' => 'required|string|max:200',
            'description' => 'nullable|string',
            'location_details' => 'nullable|string|max:255',
            'incident_date' => 'nullable|date',
            'complainant_name' => 'nullable|string|max:150',
            'complainant_user_id' => 'nullable|exists:sys_users,id',
            'target_id' => 'nullable|integer',
            'target_name' => 'nullable|string',
            'target_code' => 'nullable|string',
        ]);

        DB::beginTransaction();

        try {
            $statusId = Dropdown::where('key', 'cmp_complaints.status_id')
                ->where('value', 'Open')
                ->value('id') ?? 124;

            $priorityScoreId = Dropdown::where('key', 'cmp_complaint_categories.priority_score_id')
                ->where('value', 'Medium')
                ->value('id') ?? 3;

            // Generate ticket number: CMP-YYYY-000001
            $year = now()->year;
            $lastTicket = Complaint::where('ticket_no', 'like', "CMP-{$year}-%")
                ->orderBy('ticket_no', 'desc')
                ->lockForUpdate()
                ->first();

            $nextSerial = $lastTicket ? ((int) substr($lastTicket->ticket_no, -6) + 1) : 1;
            $ticketNo = 'CMP-' . $year . '-' . str_pad((string) $nextSerial, 6, '0', STR_PAD_LEFT);

            while (Complaint::where('ticket_no', $ticketNo)->exists()) {
                $nextSerial++;
                $ticketNo = 'CMP-' . $year . '-' . str_pad((string) $nextSerial, 6, '0', STR_PAD_LEFT);
            }

            $isAnonymous = strtolower($complainantType) === 'anonymous' ? 1 : 0;

            $complaint = Complaint::create([
                'ticket_no' => $ticketNo,
                'ticket_date' => now(),
                'target_user_type_id' => $request->target_type_id,
                'complainant_type_id' => $request->complainant_type_id,
                'complainant_user_id' => $isAnonymous ? null : $request->complainant_user_id,
                'complainant_name' => $isAnonymous ? $request->complainant_name : null,
                'complainant_contact' => $request->complainant_contact,
                'is_anonymous' => $isAnonymous,
                'target_table_name' => $request->target_table_name,
                'target_selected_id' => $request->target_id,
                'target_name' => $request->target_name,
                'category_id' => $request->category_id,
                'subcategory_id' => $request->subcategory_id,
                'severity_level_id' => $request->severity_level_id,
                'priority_score_id' => $request->priority_score_id ?: $priorityScoreId,
                'title' => $request->title,
                'description' => $request->description,
                'location_details' => $request->location_details,
                'incident_date' => $request->incident_date,
                'dept_specific_info' => array_filter([
                    'target_table_name' => $request->input('target_table_name'),
                    'target_column' => $request->input('target_column'),
                    'target_code' => $request->input('target_code'),
                ], fn($v) => $v !== null && $v !== ''),
                'created_by' => Auth::id(),
                'status_id' => $statusId,
            ]);

            event(new ComplaintSaved($complaint));

            // Notify admins
            $admins = User::role('Super Admin')->get();
            Notification::send($admins, new StudentPortalComplaintRegistered($complaint));

            // Log creation action
            $actionTypeId = Dropdown::where('key', 'cmp_complaint_actions.action_type_id')
                ->where('value', 'Created')
                ->firstOrFail()
                ->id;

            $this->logAction([
                'complaint_id' => $complaint->id,
                'action_type_id' => $actionTypeId,
                'performed_by_user_id' => Auth::id(),
                'performed_by_role_id' => Auth::user()->role_id ?? null,
                'notes' => "Complaint created with Ticket No {$ticketNo}",
            ]);

            // Handle image upload
            if ($request->hasFile('complaint_img')) {
                $complaint->addMediaFromRequest('complaint_img')
                    ->toMediaCollection('complaint_img');
                $complaint->support_file = 1;
                $complaint->save();
            }

            DB::commit();

            return response()->json([
                'status' => 'ok',
                'message' => "Complaint created. Ticket No: {$ticketNo}",
                'data' => [
                    'id' => $complaint->id,
                    'ticket_no' => $complaint->ticket_no,
                ],
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            report($e);
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to create complaint: ' . $e->getMessage(),
            ], 500);
        }
    }
    ```
  - **After** (`ComplaintMobileController.php:314-465`, method `store()` (rewritten)):
    ```php
    public function store(Request $request): JsonResponse
    {
        Gate::authorize('tenant.complaint.complaint.create');

        $user = auth()->user();

        if ($request->boolean('is_anonymous')) {
            $complainantType = 'Anonymous';
            $complainantUserId = null;
            $complainantName = $request->input('complainant_name', 'Anonymous');
            $complainantContact = $request->input('complainant_contact');
        } else {
            $userType = $user->user_type ?? 'Staff';
            $complainantType = strtolower($userType) === 'student' ? 'Student' : 'Staff';
            $complainantUserId = $user->id;
            $complainantName = null;
            $complainantContact = $user->mobile_no ?? null;
        }

        $complainantTypeId = Dropdown::where('key', 'cmp_complaints.complainant_type_id')
            ->where('value', $complainantType)
            ->value('id');

        $request->merge([
            'complainant_type_id' => $complainantTypeId,
            'complainant_user_id' => $complainantUserId,
            'complainant_name' => $complainantName,
            'complainant_contact' => $complainantContact,
        ]);

        $validated = $request->validate([
            'complainant_type_id' => 'required|exists:sys_dropdown_table,id',
            'category_id' => 'required|exists:cmp_complaint_categories,id',
            'subcategory_id' => 'nullable|exists:cmp_complaint_categories,id',
            'target_type_id' => 'nullable|exists:sys_dropdown_table,id',
            'severity_level_id' => 'required|integer',
            'priority_score_id' => 'nullable|integer',
            'title' => 'required|string|max:200',
            'description' => 'nullable|string',
            'location_details' => 'nullable|string|max:255',
            'incident_date' => 'nullable|date',
            'complainant_name' => 'nullable|string|max:150',
            'complainant_user_id' => 'nullable|exists:sys_users,id',
            'target_id' => 'nullable|integer',
            'target_name' => 'nullable|string',
            'target_code' => 'nullable|string',
        ]);

        $ticketNo = '';

        // TXN-01/TXN-02 (2026-10-17): one closure transaction; it rolls back by itself.
        $complaint = DB::transaction(function () use ($request, $complainantType, &$ticketNo) {
            $statusId = Dropdown::where('key', 'cmp_complaints.status_id')
                ->where('value', 'Open')
                ->value('id') ?? 124;

            $priorityScoreId = Dropdown::where('key', 'cmp_complaint_categories.priority_score_id')
                ->where('value', 'Medium')
                ->value('id') ?? 3;

            // Generate ticket number: CMP-YYYY-000001
            $year = now()->year;
            $lastTicket = Complaint::where('ticket_no', 'like', "CMP-{$year}-%")
                ->orderBy('ticket_no', 'desc')
                ->lockForUpdate()
                ->first();

            $nextSerial = $lastTicket ? ((int) substr($lastTicket->ticket_no, -6) + 1) : 1;
            $ticketNo = 'CMP-' . $year . '-' . str_pad((string) $nextSerial, 6, '0', STR_PAD_LEFT);

            while (Complaint::where('ticket_no', $ticketNo)->exists()) {
                $nextSerial++;
                $ticketNo = 'CMP-' . $year . '-' . str_pad((string) $nextSerial, 6, '0', STR_PAD_LEFT);
            }

            $isAnonymous = strtolower($complainantType) === 'anonymous' ? 1 : 0;

            $complaint = Complaint::create([
                'ticket_no' => $ticketNo,
                'ticket_date' => now(),
                'target_user_type_id' => $request->target_type_id,
                'complainant_type_id' => $request->complainant_type_id,
                'complainant_user_id' => $isAnonymous ? null : $request->complainant_user_id,
                'complainant_name' => $isAnonymous ? $request->complainant_name : null,
                'complainant_contact' => $request->complainant_contact,
                'is_anonymous' => $isAnonymous,
                'target_table_name' => $request->target_table_name,
                'target_selected_id' => $request->target_id,
                'target_name' => $request->target_name,
                'category_id' => $request->category_id,
                'subcategory_id' => $request->subcategory_id,
                'severity_level_id' => $request->severity_level_id,
                'priority_score_id' => $request->priority_score_id ?: $priorityScoreId,
                'title' => $request->title,
                'description' => $request->description,
                'location_details' => $request->location_details,
                'incident_date' => $request->incident_date,
                'dept_specific_info' => array_filter([
                    'target_table_name' => $request->input('target_table_name'),
                    'target_column' => $request->input('target_column'),
                    'target_code' => $request->input('target_code'),
                ], fn($v) => $v !== null && $v !== ''),
                'created_by' => Auth::id(),
                'status_id' => $statusId,
            ]);

            event(new ComplaintSaved($complaint));

            // Notify admins
            $admins = User::role('Super Admin')->get();
            Notification::send($admins, new StudentPortalComplaintRegistered($complaint));

            // Log creation action
            $actionTypeId = Dropdown::where('key', 'cmp_complaint_actions.action_type_id')
                ->where('value', 'Created')
                ->firstOrFail()
                ->id;

            $this->logAction([
                'complaint_id' => $complaint->id,
                'action_type_id' => $actionTypeId,
                'performed_by_user_id' => Auth::id(),
                'performed_by_role_id' => Auth::user()->role_id ?? null,
                'notes' => "Complaint created with Ticket No {$ticketNo}",
            ]);

            // TXN-04 (2026-10-17): platform audit row, after the write, inside the transaction.
            activityLog($complaint, 'Created', [
                'message' => "Complaint created with Ticket No {$ticketNo}.",
                'performed_by' => Auth::user()->name ?? null,
            ]);

            return $complaint;
        });

        // TXN-03 (2026-10-17): the file write runs AFTER the commit, so a rolled-back
        // create cannot leave an orphaned upload on disk.
        if ($request->hasFile('complaint_img')) {
            $complaint->addMediaFromRequest('complaint_img')
                ->toMediaCollection('complaint_img');
            $complaint->support_file = 1;
            $complaint->save();
        }

        return response()->json([
            'status' => 'ok',
            'message' => "Complaint created. Ticket No: {$ticketNo}",
            'data' => [
                'id' => $complaint->id,
                'ticket_no' => $complaint->ticket_no,
            ],
        ], 201);
    }
    ```
  - **Before** (`ComplaintMobileController.php:472-575`, method `update()`):
    ```php
    public function update(Request $request, int $id): JsonResponse
    {
        Gate::authorize('tenant.complaint.complaint.update');

        $complaint = Complaint::findOrFail($id);

        $oldStatusId = $complaint->status_id;
        $oldAssignedUserId = $complaint->assigned_to_user_id;
        $oldAssignedRoleId = $complaint->assigned_to_role_id;

        $validated = $request->validate([
            'status_id' => 'nullable|integer',
            'assigned_to_role_id' => 'nullable|integer',
            'assigned_to_user_id' => 'nullable|integer',
            'resolution_due_at' => 'nullable|date',
            'actual_resolved_at' => 'nullable|date',
            'resolved_by_role_id' => 'nullable|integer',
            'resolved_by_user_id' => 'nullable|integer',
            'resolution_summary' => 'nullable|string',
            'source_id' => 'nullable|integer',
        ]);

        $validated['is_escalated'] = $request->boolean('is_escalated') ? 1 : 0;
        $validated['is_medical_check_required'] = $request->boolean('is_medical_check_required') ? 1 : 0;

        DB::beginTransaction();

        try {
            $complaint->update($validated);

            event(new ComplaintSaved($complaint));

            // Log status change
            if ($oldStatusId != $complaint->status_id) {
                $statusChangeActionId = Dropdown::where('key', 'cmp_complaint_actions.action_type_id')
                    ->where('value', 'StatusChange')
                    ->firstOrFail()
                    ->id;

                $oldStatus = Dropdown::where('id', $oldStatusId)->value('value') ?? $oldStatusId;
                $newStatus = Dropdown::where('id', $complaint->status_id)->value('value') ?? $complaint->status_id;

                $this->logAction([
                    'complaint_id' => $complaint->id,
                    'action_type_id' => $statusChangeActionId,
                    'performed_by_user_id' => Auth::id(),
                    'performed_by_role_id' => Auth::user()->role_id ?? null,
                    'notes' => "Status changed from {$oldStatus} to {$newStatus}",
                ]);
            }

            // Log assignment change
            if ($oldAssignedUserId != $complaint->assigned_to_user_id || $oldAssignedRoleId != $complaint->assigned_to_role_id) {
                $assignedActionId = Dropdown::where('key', 'cmp_complaint_actions.action_type_id')
                    ->where('value', 'Assigned')
                    ->firstOrFail()
                    ->id;

                $this->logAction([
                    'complaint_id' => $complaint->id,
                    'action_type_id' => $assignedActionId,
                    'performed_by_user_id' => Auth::id(),
                    'performed_by_role_id' => Auth::user()->role_id ?? null,
                    'assigned_to_user_id' => $complaint->assigned_to_user_id,
                    'assigned_to_role_id' => $complaint->assigned_to_role_id,
                    'notes' => 'Complaint assigned',
                ]);
            }

            // Log resolution
            if ($complaint->actual_resolved_at && !$complaint->getOriginal('actual_resolved_at')) {
                $resolvedActionId = Dropdown::where('key', 'cmp_complaint_actions.action_type_id')
                    ->where('value', 'Resolved')
                    ->firstOrFail()
                    ->id;

                $this->logAction([
                    'complaint_id' => $complaint->id,
                    'action_type_id' => $resolvedActionId,
                    'performed_by_user_id' => Auth::id(),
                    'performed_by_role_id' => Auth::user()->role_id ?? null,
                    'notes' => $complaint->resolution_summary ?? 'Complaint resolved',
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 'ok',
                'message' => 'Complaint updated successfully.',
                'data' => [
                    'id' => $complaint->id,
                    'ticket_no' => $complaint->ticket_no,
                ],
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            report($e);
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to update complaint: ' . $e->getMessage(),
            ], 500);
        }
    }
    ```
  - **After** (`ComplaintMobileController.php:472-575`, method `update()` (rewritten)):
    ```php
    public function update(Request $request, int $id): JsonResponse
    {
        Gate::authorize('tenant.complaint.complaint.update');

        $complaint = Complaint::findOrFail($id);

        $oldStatusId = $complaint->status_id;
        $oldAssignedUserId = $complaint->assigned_to_user_id;
        $oldAssignedRoleId = $complaint->assigned_to_role_id;

        $validated = $request->validate([
            'status_id' => 'nullable|integer',
            'assigned_to_role_id' => 'nullable|integer',
            'assigned_to_user_id' => 'nullable|integer',
            'resolution_due_at' => 'nullable|date',
            'actual_resolved_at' => 'nullable|date',
            'resolved_by_role_id' => 'nullable|integer',
            'resolved_by_user_id' => 'nullable|integer',
            'resolution_summary' => 'nullable|string',
            'source_id' => 'nullable|integer',
        ]);

        $validated['is_escalated'] = $request->boolean('is_escalated') ? 1 : 0;
        $validated['is_medical_check_required'] = $request->boolean('is_medical_check_required') ? 1 : 0;

        // TXN-01/TXN-02 (2026-10-17): one closure transaction; no try/catch (D1).
        DB::transaction(function () use ($complaint, $validated, $oldStatusId, $oldAssignedUserId, $oldAssignedRoleId) {
            $complaint->update($validated);

            event(new ComplaintSaved($complaint));

            // Log status change
            if ($oldStatusId != $complaint->status_id) {
                $statusChangeActionId = Dropdown::where('key', 'cmp_complaint_actions.action_type_id')
                    ->where('value', 'StatusChange')
                    ->firstOrFail()
                    ->id;

                $oldStatus = Dropdown::where('id', $oldStatusId)->value('value') ?? $oldStatusId;
                $newStatus = Dropdown::where('id', $complaint->status_id)->value('value') ?? $complaint->status_id;

                $this->logAction([
                    'complaint_id' => $complaint->id,
                    'action_type_id' => $statusChangeActionId,
                    'performed_by_user_id' => Auth::id(),
                    'performed_by_role_id' => Auth::user()->role_id ?? null,
                    'notes' => "Status changed from {$oldStatus} to {$newStatus}",
                ]);
            }

            // Log assignment change
            if ($oldAssignedUserId != $complaint->assigned_to_user_id || $oldAssignedRoleId != $complaint->assigned_to_role_id) {
                $assignedActionId = Dropdown::where('key', 'cmp_complaint_actions.action_type_id')
                    ->where('value', 'Assigned')
                    ->firstOrFail()
                    ->id;

                $this->logAction([
                    'complaint_id' => $complaint->id,
                    'action_type_id' => $assignedActionId,
                    'performed_by_user_id' => Auth::id(),
                    'performed_by_role_id' => Auth::user()->role_id ?? null,
                    'assigned_to_user_id' => $complaint->assigned_to_user_id,
                    'assigned_to_role_id' => $complaint->assigned_to_role_id,
                    'notes' => 'Complaint assigned',
                ]);
            }

            // Log resolution
            if ($complaint->actual_resolved_at && !$complaint->getOriginal('actual_resolved_at')) {
                $resolvedActionId = Dropdown::where('key', 'cmp_complaint_actions.action_type_id')
                    ->where('value', 'Resolved')
                    ->firstOrFail()
                    ->id;

                $this->logAction([
                    'complaint_id' => $complaint->id,
                    'action_type_id' => $resolvedActionId,
                    'performed_by_user_id' => Auth::id(),
                    'performed_by_role_id' => Auth::user()->role_id ?? null,
                    'notes' => $complaint->resolution_summary ?? 'Complaint resolved',
                ]);
            }

            // TXN-04 (2026-10-17): platform audit row, after the write, inside the transaction.
            activityLog($complaint, 'Updated', [
                'message' => "Complaint {$complaint->ticket_no} updated from the mobile app.",
                'performed_by' => Auth::user()->name ?? null,
            ]);
        });

        return response()->json([
            'status' => 'ok',
            'message' => 'Complaint updated successfully.',
            'data' => [
                'id' => $complaint->id,
                'ticket_no' => $complaint->ticket_no,
            ],
        ]);
    }
    ```
  - **Verify:** `php -l Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php; Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'getMessage|beginTransaction|DB::rollBack'`
  - **Expect:** `No syntax errors detected …`; then no output (no `getMessage`, no `beginTransaction`, no `DB::rollBack`).
  - **Effort:** M

- [ ] **B** · B · F13-Q1 · `ComplaintMobileController.php:49-58,365-371` — resolve the status/priority dropdown ids the way the rest of the module does (value lookup across the real keys), which fixes the dashboard's `open:0/resolved:0` (CMBL-25) and removes the magic fallbacks `?? 124` / `?? 3` (CMBL-20).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Before** (`ComplaintMobileController.php:48-59`, `dashboard()`):
    ```php
            // Count status buckets
            $statusOpenId = Dropdown::where('key', 'cmp_complaints.status_id')
                ->where('value', 'Open')
                ->value('id');
            $statusResolvedId = Dropdown::where('key', 'cmp_complaints.status_id')
                ->where('value', 'Resolved')
                ->value('id');

            $total = Complaint::count();
            $openCount = $statusOpenId ? Complaint::where('status_id', $statusOpenId)->count() : 0;
            $resolvedCount = $statusResolvedId ? Complaint::where('status_id', $statusResolvedId)->count() : 0;
            $inProgressCount = $total - $openCount - $resolvedCount;
    ```
  - **After:**
    ```php
            // CMBL-25 (2026-10-17): this tenant files complaint statuses under the
            // placeholder key `dummy_table_name.complaint_status` (ids 491-496), not
            // `cmp_complaints.status_id` (ids 220-225). Match by value across both keys.
            $statusKeys = ['dummy_table_name.complaint_status', 'cmp_complaints.status_id'];

            $openStatusIds = Dropdown::whereIn('key', $statusKeys)
                ->where('value', 'Open')
                ->pluck('id');
            $resolvedStatusIds = Dropdown::whereIn('key', $statusKeys)
                ->where('value', 'Resolved')
                ->pluck('id');

            $total = Complaint::count();
            $openCount = Complaint::whereIn('status_id', $openStatusIds)->count();
            $resolvedCount = Complaint::whereIn('status_id', $resolvedStatusIds)->count();
            $inProgressCount = $total - $openCount - $resolvedCount;
    ```
  - **Before** (`ComplaintMobileController.php:365-371`, `store()`):
    ```php
            $statusId = Dropdown::where('key', 'cmp_complaints.status_id')
                ->where('value', 'Open')
                ->value('id') ?? 124;

            $priorityScoreId = Dropdown::where('key', 'cmp_complaint_categories.priority_score_id')
                ->where('value', 'Medium')
                ->value('id') ?? 3;
    ```
  - **After:**
    ```php
            // CMBL-25 / CMBL-20 (2026-10-17): match by value across the module's real
            // keys; fail loudly instead of falling back to a magic id.
            $statusId = Dropdown::whereIn('key', ['dummy_table_name.complaint_status', 'cmp_complaints.status_id'])
                ->where('value', 'Open')
                ->value('id');

            if (! $statusId) {
                throw new \DomainException('The complaint status "Open" is not configured.');
            }

            $priorityScoreId = Dropdown::whereIn('key', ['dummy_table_name.priority_score', 'cmp_complaint_categories.priority_score_id'])
                ->where('value', 'Medium')
                ->value('id');
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern '\?\? 124|\?\? 3|key'', ''cmp_complaints.status_id'`
  - **Expect:** no output (no `?? 124`, no `?? 3`, no single-key status lookup).
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **C** · H · VAL-04 / TXN-06 · `ComplaintMobileController.php:373-386` — include trashed rows in the ticket-number lookups (CMBL-22) and document the unique-index backstop for the residual race (CMBL-23).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Before** (`ComplaintMobileController.php:373-386`):
    ```php
            // Generate ticket number: CMP-YYYY-000001
            $year = now()->year;
            $lastTicket = Complaint::where('ticket_no', 'like', "CMP-{$year}-%")
                ->orderBy('ticket_no', 'desc')
                ->lockForUpdate()
                ->first();

            $nextSerial = $lastTicket ? ((int) substr($lastTicket->ticket_no, -6) + 1) : 1;
            $ticketNo = 'CMP-' . $year . '-' . str_pad((string) $nextSerial, 6, '0', STR_PAD_LEFT);

            while (Complaint::where('ticket_no', $ticketNo)->exists()) {
                $nextSerial++;
                $ticketNo = 'CMP-' . $year . '-' . str_pad((string) $nextSerial, 6, '0', STR_PAD_LEFT);
            }
    ```
  - **After:**
    ```php
            // Generate ticket number: CMP-YYYY-000001
            //
            // VAL-04 (2026-10-17): `cmp_complaints.ticket_no` has a UNIQUE index
            // (`uq_ticket_no`) that includes soft-deleted rows, so the max lookup and the
            // collision guard MUST see trashed rows too — otherwise a soft-deleted
            // complaint can hold a serial the next insert reuses, and the unique index
            // rejects the create. `withTrashed()` on both queries keeps them in step.
            //
            // TXN-06 (2026-10-17): `lockForUpdate()` serialises concurrent creates that
            // find an existing last row. Two creates on an empty year can still compute
            // the same first serial; the `uq_ticket_no` unique index is the backstop
            // (the second insert fails rather than corrupting data). A dedicated
            // sequence table would remove the residual race entirely.
            $year = now()->year;
            $lastTicket = Complaint::withTrashed()
                ->where('ticket_no', 'like', "CMP-{$year}-%")
                ->orderBy('ticket_no', 'desc')
                ->lockForUpdate()
                ->first();

            $nextSerial = $lastTicket ? ((int) substr($lastTicket->ticket_no, -6) + 1) : 1;
            $ticketNo = 'CMP-' . $year . '-' . str_pad((string) $nextSerial, 6, '0', STR_PAD_LEFT);

            while (Complaint::withTrashed()->where('ticket_no', $ticketNo)->exists()) {
                $nextSerial++;
                $ticketNo = 'CMP-' . $year . '-' . str_pad((string) $nextSerial, 6, '0', STR_PAD_LEFT);
            }
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'withTrashed'`
  - **Expect:** two lines: the `$lastTicket = Complaint::withTrashed()` line and the `while (Complaint::withTrashed()->where('ticket_no', $ticketNo)->exists())` line.
  - **Effort:** S

- [ ] **D** · H · F13-Q1 · `ComplaintMobileController.php:494-495` — only write the two boolean flags when the request actually carries them, so a partial update stops resetting `is_escalated` / `is_medical_check_required` to 0 (CMBL-24).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Before** (`ComplaintMobileController.php:494-495`):
    ```php
            $validated['is_escalated'] = $request->boolean('is_escalated') ? 1 : 0;
            $validated['is_medical_check_required'] = $request->boolean('is_medical_check_required') ? 1 : 0;
    ```
  - **After:**
    ```php
            // F13-Q1 (2026-10-17): only touch a flag the client actually sent; an absent
            // key must not silently reset escalated/medical-check complaints to 0.
            if ($request->has('is_escalated')) {
                $validated['is_escalated'] = $request->boolean('is_escalated') ? 1 : 0;
            }
            if ($request->has('is_medical_check_required')) {
                $validated['is_medical_check_required'] = $request->boolean('is_medical_check_required') ? 1 : 0;
            }
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern "request->has\('is_escalated'\)"`
  - **Expect:** one matching line.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

None separate — the error-handling and transaction findings (CMBL-01, CMBL-02, CMBL-03, CMBL-04, CMBL-05) are all resolved by items **A1** and **A2** in §1. (The CMBL-23 race half of TXN-06 is resolved by item **C** in §2.)

## 4. Authorization (F3)

None — F3 is clean (`01-report.md` §F3): all nine routed methods authorise against a seeded permission on all four surfaces; the strings live on the four surfaces identically.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **E** · H · VAL-02/05/06 · `ComplaintMobileController.php:344-360,482-492` — move both rule sets into a `ComplaintMobileRequest`, complete the rules (target fields, `exists`, the upload), and switch the two methods to it. Fixes CMBL-06, CMBL-07, CMBL-08, CMBL-09.
  - **Touches:** `Modules/Complaint/app/Http/Requests/ComplaintMobileRequest.php` (new file), `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Why one item:** the four validation findings are one change — one request class — for the two methods that share it.
  - **After** (new file `Modules/Complaint/app/Http/Requests/ComplaintMobileRequest.php`, full content):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Complaint\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;

    class ComplaintMobileRequest extends FormRequest
    {
        // The controller already calls Gate::authorize(); authorising here too would be
        // the AUTH-04 double-check. Keep this true.
        public function authorize(): bool
        {
            return true;
        }

        /**
         * @return array<string,mixed>
         */
        public function rules(): array
        {
            return [
                // create + update
                'status_id' => 'nullable|integer|exists:sys_dropdown_table,id',
                'assigned_to_role_id' => 'nullable|integer|exists:sys_roles,id',
                'assigned_to_user_id' => 'nullable|integer|exists:sys_users,id',
                'resolution_due_at' => 'nullable|date',
                'actual_resolved_at' => 'nullable|date',
                'resolved_by_role_id' => 'nullable|integer|exists:sys_roles,id',
                'resolved_by_user_id' => 'nullable|integer|exists:sys_users,id',
                'resolution_summary' => 'nullable|string',
                'source_id' => 'nullable|integer|exists:sys_dropdown_table,id',
                'is_escalated' => 'sometimes|boolean',
                'is_medical_check_required' => 'sometimes|boolean',

                // create only
                'complainant_type_id' => 'sometimes|required|exists:sys_dropdown_table,id',
                'category_id' => 'sometimes|required|exists:cmp_complaint_categories,id',
                'subcategory_id' => 'nullable|exists:cmp_complaint_categories,id',
                'severity_level_id' => 'sometimes|required|integer|exists:sys_dropdown_table,id',
                'priority_score_id' => 'nullable|integer|exists:sys_dropdown_table,id',
                'title' => 'sometimes|required|string|max:200',
                'description' => 'nullable|string',
                'location_details' => 'nullable|string|max:255',
                'incident_date' => 'nullable|date',
                'complainant_name' => 'nullable|string|max:150',
                'complainant_user_id' => 'nullable|exists:sys_users,id',
                'target_id' => 'nullable|integer',
                'target_type_id' => 'nullable|exists:sys_dropdown_table,id',
                'target_name' => 'nullable|string',
                'target_code' => 'nullable|string',

                // CMBL-07 (2026-10-17): these were written but never validated. Restrict
                // the morph table to a known list, and the column to a short name.
                'target_table_name' => 'nullable|string|in:sys_users,sch_departments,trn_vehicles',
                'target_column' => 'nullable|string|max:100',

                // CMBL-09 (2026-10-17): the upload had no rule at all.
                'complaint_img' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:5120',
            ];
        }
    }
    ```
  - **Before/After** (`ComplaintMobileController.php` — the two signatures and the two `validate()` calls):
    ```php
    // :314 — CURRENT
    public function store(Request $request): JsonResponse
    // :472 — CURRENT
    public function update(Request $request, int $id): JsonResponse
    ```
    ```php
    // :314 — AFTER
    public function store(ComplaintMobileRequest $request): JsonResponse
    // :472 — AFTER
    public function update(ComplaintMobileRequest $request, int $id): JsonResponse
    ```
  - **Before** (`ComplaintMobileController.php:344-360`, the `store` rules):
    ```php
        $validated = $request->validate([
            'complainant_type_id' => 'required|exists:sys_dropdown_table,id',
            'category_id' => 'required|exists:cmp_complaint_categories,id',
            'subcategory_id' => 'nullable|exists:cmp_complaint_categories,id',
            'target_type_id' => 'nullable|exists:sys_dropdown_table,id',
            'severity_level_id' => 'required|integer',
            'priority_score_id' => 'nullable|integer',
            'title' => 'required|string|max:200',
            'description' => 'nullable|string',
            'location_details' => 'nullable|string|max:255',
            'incident_date' => 'nullable|date',
            'complainant_name' => 'nullable|string|max:150',
            'complainant_user_id' => 'nullable|exists:sys_users,id',
            'target_id' => 'nullable|integer',
            'target_name' => 'nullable|string',
            'target_code' => 'nullable|string',
        ]);
    ```
  - **After** (`store`):
    ```php
        $validated = $request->validated();
    ```
  - **Before** (`ComplaintMobileController.php:482-492`, the `update` rules):
    ```php
        $validated = $request->validate([
            'status_id' => 'nullable|integer',
            'assigned_to_role_id' => 'nullable|integer',
            'assigned_to_user_id' => 'nullable|integer',
            'resolution_due_at' => 'nullable|date',
            'actual_resolved_at' => 'nullable|date',
            'resolved_by_role_id' => 'nullable|integer',
            'resolved_by_user_id' => 'nullable|integer',
            'resolution_summary' => 'nullable|string',
            'source_id' => 'nullable|integer',
        ]);
    ```
  - **After** (`update`):
    ```php
        $validated = $request->validated();
    ```
  - **Before** (`ComplaintMobileController.php:9-10`, the import to add):
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    ```
  - **After**:
    ```php
    use Illuminate\Http\JsonResponse;
    use Modules\Complaint\Http\Requests\ComplaintMobileRequest;
    ```
    (Drop the now-unused `Request` import; item L/Pint will also remove any other unused import.)
  - **Verify:** `php -l Modules/Complaint/app/Http/Requests/ComplaintMobileRequest.php; Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'request->validate'`
  - **Expect:** `No syntax errors detected …`; then no output (no inline `validate()` left).
  - **Effort:** M

## 6. Queries & performance (F9)

- [ ] **F** · H · QRY-01 · `ComplaintMobileController.php:213-221` — replace the per-role `users()->count()` loop with `withCount('users')` (CMBL-14).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Before** (`ComplaintMobileController.php:213-221`):
    ```php
            $roles = Role::orderBy('name')
                ->get()
                ->map(function ($role) {
                    return [
                        'id' => $role->id,
                        'name' => $role->name,
                        'user_count' => $role->users()->count(),
                    ];
                });
    ```
  - **After:**
    ```php
            // QRY-01 (2026-10-17): one query with a count, not one COUNT per role.
            $roles = Role::withCount('users')
                ->orderBy('name')
                ->get()
                ->map(function ($role) {
                    return [
                        'id' => $role->id,
                        'name' => $role->name,
                        'user_count' => $role->users_count,
                    ];
                });
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern "withCount\('users'\)"`
  - **Expect:** one matching line.
  - **Effort:** S

- [ ] **G** · H · QRY-02 · `ComplaintMobileController.php:672` — cap the unfiltered `users()` list so it cannot return the whole `sys_users` table (CMBL-15).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Before** (`ComplaintMobileController.php:672`):
    ```php
            $users = $query->get();
    ```
  - **After:**
    ```php
            // QRY-02 (2026-10-17): bound the assignment picker; the app filters by role.
            $users = $query->limit(200)->get();
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'limit\(200\)'`
  - **Expect:** one matching line.
  - **Effort:** S

- [ ] **H** · M · QRY-02 · `ComplaintMobileController.php:133` — clamp `per_page` so a client cannot request the whole table (CMBL-16).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Before** (`ComplaintMobileController.php:133`):
    ```php
                $perPage = (int) $request->get('per_page', 10);
    ```
  - **After:**
    ```php
                // QRY-02 (2026-10-17): clamp the page size (1..50).
                $perPage = min(50, max(1, (int) $request->get('per_page', 10)));
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'min\(50, max\(1'`
  - **Expect:** one matching line.
  - **Effort:** S

- [ ] **J** · M · QRY-12 · `ComplaintMobileController.php:46` — reuse the `criticalTickets` value `getDashboardData()` already computed (CMBL-18).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Before** (`ComplaintMobileController.php:45-46`):
    ```php
                $dashboard = $this->dashboardService->getDashboardData($from, $to);
                $criticalTickets = $this->dashboardService->getRecentCriticalTickets($from, $to);
    ```
  - **After:**
    ```php
                $dashboard = $this->dashboardService->getDashboardData($from, $to);
                // QRY-12 (2026-10-17): getDashboardData() already computed criticalTickets (service:83).
                $criticalTickets = $dashboard['criticalTickets'] ?? collect();
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'getRecentCriticalTickets'`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **K** · L · QRY-03 · `ComplaintMobileController.php:197` — drop the `medicalChecks` eager load the response never uses (CMBL-19).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Before** (`ComplaintMobileController.php:196-197`):
    ```php
                    'actions.assignedToUser',
                    'medicalChecks',
    ```
  - **After:**
    ```php
                    'actions.assignedToUser',
    ```
  - **Verify:** `Select-String -Path Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php -Pattern 'medicalChecks'`
  - **Expect:** no output.
  - **Effort:** S

## 7. Views (F10)

None — this controller renders no Blade (`grep "view("` → no output). Nothing to fix.

## 8. Style (F12) — one item per file

- [ ] **L** · L · STY-02 / STY-05 · `ComplaintMobileController.php` (whole file) — run Pint; it fixes `no_unused_imports` (the unused `DepartmentSla` import at `:19`), `ordered_imports`, `concat_space`, `not_operator_with_successor_space`, `function_declaration`, `blank_line_before_statement` and `single_line_empty_body` (CMBL-21).
  - **Touches:** `Modules/Complaint/app/Http/Controllers/Mobile/ComplaintMobileController.php`
  - **Before** (`ComplaintMobileController.php:19` — the one unused import Pint removes; the rest is whitespace/ordering):
    ```php
    use Modules\Complaint\Models\DepartmentSla;
    ```
  - **After:** run the command below — Pint rewrites the file; the `DepartmentSla` import is deleted and the other fixers normalise spacing/ordering. No manual edit.
  - **Verify:** `vendor\bin\pint --test Modules\Complaint\app\Http\Controllers\Mobile\ComplaintMobileController.php --format agent`
  - **Expect:** `{"tool":"pint","result":"passed"}`
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **M** · H · DECISION · CTL-02 / CTL-06 — `store()` is 152 lines, `show()` 127 and `update()` 104; ticket-number generation, the admin notification and media handling are business logic in the controller (CMBL-10, CMBL-11, CMBL-12). Extract now, or defer the structural refactor?
  - **Why it is a decision:** it is a behaviour-preserving redesign into a service / private helpers — a scope change, not a mechanical fix (D3/D11). It also duplicates the create path that `ComplaintController` already implements.
  - (a) ⭐ **Defer to the split pass (D3)** — record CMBL-10/11/12 as accepted structural debt; keep the mechanical fixes above.
  - (b) **Extract a `ComplaintCreationService` now** — move ticket-numbering + create + notify + media out of the controller, and have both web and mobile call it (touches `ComplaintController` too, which is another report's file).
  - (c) **Extract only private helpers inside this controller** — no new file, shorter methods, no service.
  - ➜ Choice: ____

- [ ] **N** · M · DECISION · CTL-03 — `show`/`update` take `int $id` + `findOrFail`; route-model binding needs the route parameter renamed to `{complaint}` (CMBL-13). ⚠ SHARED (route file).
  - **Why it is a decision:** it changes `Modules/Complaint/routes/mobile_api.php`, a shared route file — Tarun's call (§9.3), and it needs its own explicit tick.
  - (a) ⭐ **Defer** — keep `int $id` + `findOrFail`; the findOrFail is already outside any catch after item A2.
  - (b) **Rename the parameter** — `Route::get('{complaint}', 'show')` / `Route::post('{complaint}', 'update')` and type-hint `Complaint $complaint` in both methods. Verify the mobile client does not hard-code `/{id}`.
  - (c) **Leave as is, accepted** — record the debt.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CMBL-17 | QRY-08 is **accepted** for this table: `cmp_complaints` holds 12 rows (measured 2026-10-17), where a leading-wildcard scan is cheap. Revisit if the table grows; a prefix match (`$search%`) or a search column is the later fix. |

All other findings are covered by the items above: CMBL-01 → A1/A2 · CMBL-02 → A1 · CMBL-03/04/05 → A2 · CMBL-06/07/08/09 → E · CMBL-10/11/12 → M · CMBL-13 → N · CMBL-14 → F · CMBL-15 → G · CMBL-16 → H · CMBL-18 → J · CMBL-19 → K · CMBL-20 → B · CMBL-21 → L · CMBL-22/23 → C · CMBL-24 → D · CMBL-25 → B.
