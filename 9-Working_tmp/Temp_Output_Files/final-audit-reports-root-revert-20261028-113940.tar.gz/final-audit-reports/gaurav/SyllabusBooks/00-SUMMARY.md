# SyllabusBooks — Final Audit Summary

Protocol: `.claude/rules/final-audit.md` §13.2 · Developer: `gaurav` · Audited 2026-10-28 by `opencode`
Module: `Modules/SyllabusBooks` · 12 controllers · Read-only audit — no `prime_ai_dev/` code was changed.

| Controller | Lines | B | H | M | L | DECISIONs | Worst finding (one line) | Report |
|---|---|---|---|---|---|---|---|---|
| SyllabusBooksController | 185 | 1 | 0 | 4 | 2 | 1 | API `show` renders a Blade view that does not exist → 500 | [01-report.md](SyllabusBooksController/01-report.md) |
| SyllabusBookConfigController | 37 | 0 | 1 | 2 | 3 | 1 | Settings cache key is shared by every tenant | [01-report.md](SyllabusBookConfigController/01-report.md) |
| SyllabusBookReportController | 175 | 1 | 2 | 1 | 2 | 2 | KPI compares `Approved`/`Pending` but notes store `APPROVED`/`PENDING_APPROVAL` | [01-report.md](SyllabusBookReportController/01-report.md) |
| AuthorController | 270 | 1 | 1 | 3 | 2 | 0 | Nine paths send the raw SQL error; restore leaves the author inactive | [01-report.md](AuthorController/01-report.md) |
| BookFileController | 100 | 1 | 2 | 4 | 1 | 0 | The "not downloadable" policy rule never runs; delete destroys media inside the transaction | [01-report.md](BookFileController/01-report.md) |
| BookTopicMappingController | 182 | 2 | 1 | 3 | 2 | 1 | Model table `slb_book_topic_mapping` does not exist; index renders the wrong view | [01-report.md](BookTopicMappingController/01-report.md) |
| BookChapterController | 44 | 0 | 1 | 3 | 1 | 0 | A chapter can be deleted through another book's URL | [01-report.md](BookChapterController/01-report.md) |
| NoteDownloadController | 24 | 0 | 0 | 0 | 1 | 0 | Missing `strict_types` only | [01-report.md](NoteDownloadController/01-report.md) |
| NoteFileController | 122 | 2 | 1 | 3 | 1 | 0 | `SlbNotesFile` has no `getMediaModel()` → media written to the central DB | [01-report.md](NoteFileController/01-report.md) |
| NoteRatingController | 133 | 0 | 2 | 2 | 2 | 0 | The ratee's user id comes from the form; rating and average are not in one transaction | [01-report.md](NoteRatingController/01-report.md) |
| NoteController | 409 | 2 | 1 | 5 | 2 | 0 | Edited note loses its file before the replacement is stored | [01-report.md](NoteController/01-report.md) |
| BookController | 1136 | 1 | 3 | 5 | 2 | 2 | Edit form queries dropdown key `language` (0 rows) so the language list is empty | [01-report.md](BookController/01-report.md) |
| **TOTAL** | **2817** | **11** | **15** | **35** | **21** | **7** | **82 findings · 12 fix-plan files** | |

## Module totals

- 82 findings: **11 B · 15 H · 35 M · 21 L**. Seven of them are DECISION items, each with options in its plan: `SBC-02` (M, SyllabusBookConfig), `BTM-01` (B, BookTopicMapping), `RPT-04` (H, SyllabusBookReport), `RPT-03` (M, SyllabusBookReport), `BOK-01` (H, Book), `BOK-08` (M, Book) and `SBS-03` (M, SyllabusBooks).
- 79 plan items in total; 3 findings have no plan item and are listed in their plan §10 (`ATH-01`, `BOK-05`, `NOT-10` — three rows across three plans).
- Self-check: **PASS 12/12**.

## Cross-controller families

These are the same defect in several controllers. Fix them as one decision per family where the code allows.

| Family | Controllers | Rule | Note |
|---|---|---|---|
| Raw exception text returned to the user | Author (9 sites), Book (9), Note (8), Report (1) | ERR-01 B | four separate `B` findings; the same edit pattern closes all four |
| Controller try/catch, including `QueryException` | Author, Book, Note, Report | ERR-00 / D1 / D2 | removing them is the same change as the ERR-01 fix, so pair the ticks |
| `activityLog()` outside the transaction | Book (create/update), Note (create/update), BookFile (none at all), BookChapter (none), BookTopicMapping (no transaction) | TXN-04 M | the module's only well-placed logs are in `BookController::destroy/restore/forceDelete/toggleStatus` |
| Restore does not reset `is_active` | Author, Note | CTL-06 H | delete deactivates; restore never reactivates, so the record never reappears |
| Trash list gated on the `restore` permission | Author, Note | AUTH-05 M | a view-only role gets 403 on the trash screen |
| Permission string passed where a policy ability is expected | BookFile (download bypass), and the same pattern is one argument away in every `Gate::authorize('tenant.…', $model)` call | AUTH-05 H | `BookFilePolicy::download()` — the `is_downloadable` guard — is dead |
| Unbounded dropdown loads | SyllabusBooks (5,671 users), Note (5,671 users), Book (authors/classes/subjects) | QRY-15 M | users need a searchable picker, not a `get()` |
| No `declare(strict_types=1)` and Pint failures | 11 of 12 controllers (all except SyllabusBookReportController, which has strict types but still fails Pint) | STY-01/02 L | one style item per file in every plan |

## Shared classes

Claimed in `_Info/00-CLASS-OWNERS.md` under `gaurav/SyllabusBooks/…` for: `BookAuthors`, `AuthorPolicy`, `BookAuthorJnt`, `BookTopicMapping`, `BookTopicMappingPolicy`, `SyllabusBookConfig`, `SyllabusBookConfigService`, `SyllabusBookConfigPolicy`, `BookChapterService`, `BookChapterPolicy`, `BookFileService`, `BookFilePolicy`, `SyllabusBookReportService`, `BookImport`, `BookReadOnly`, `BookPolicy`, `BookDownloadPolicy`, `NotePolicy`, `NoteDownloadPolicy`, `NoteRatingPolicy`, `SlbNotesFile`.

Linked, not re-audited (owned by `tarun/StudentPortal-done/…`): `BokBook`, `BookClassSubject`, `BookFile`, `BookChapter`, `SlbNote`, `SlbNotesDownload`, `SlbNotesRating`, `SlbBookDownload`.

⚠ `_Info/00-CLASS-OWNERS.md` already contained **three duplicate row sets** for the StudentPortal-owned SyllabusBooks models (around lines 642, 914 and 995) before this audit. The earliest claim was kept; this audit added no duplicate.

## Decisions that apply module-wide

1. **Cache tenancy** — `config/tenancy.php:37-40` disables `CacheTenancyBootstrapper` for the `database` cache store. Every module that caches tenant data with a bare key leaks across tenants (proven here in `SyllabusBookConfig`). One platform decision fixes the class of bug; it is a cross-cutting note, not this module's edit.
2. **Policies vs permission strings** — the module registers ten policies but most controllers call `Gate::authorize('tenant.…')`, which never reaches them. Either pass abilities (`Gate::authorize('update', $model)`) or stop registering policies; the current mix hides real guards (BookFile download, NotePolicy).
3. **`SlbNotesFile` media model** — NFC-01 (B) is the only tenant-media defect; `SlbNote`, `BookFile` and `BokBook` already override `getMediaModel()`. Fix NFC-01 before any note file is uploaded in production.
4. **BookTopicMapping table** — BTM-01 needs a tenant migration; the screen is dead until Tarun creates and runs it.

---
**Hand-back:** 12/12 controllers audited under `final-audit-reports/gaurav/SyllabusBooks/`; 82 findings (11 B · 15 H · 35 M · 21 L · 7 decision items); self-check PASS 12/12. Start with `NoteFileController` NFC-01 and `BookTopicMappingController` BTM-01/02, then the four ERR-01 blockers. No application code was changed. Tick items in each `02-fix-plan.md`, then run `final-audit-fixer` per controller.
