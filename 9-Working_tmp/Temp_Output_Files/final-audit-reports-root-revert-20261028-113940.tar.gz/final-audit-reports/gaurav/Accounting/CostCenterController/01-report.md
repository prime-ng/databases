# Final Audit — Accounting / CostCenterController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/CostCenterController.php` (253 lines, 10 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/setup-masters?tab=cost-centers` (list tab), `/accounting/cost-center/create`, `/accounting/cost-center/{id}`, `/accounting/cost-center/{id}/edit`, `/accounting/cost-center/trash/view` |
| Menu path | Accounting → Setup & Masters → Cost Centers (tab) |
| Who uses it | School Admin and Super Admin hold `tenant.accounting.cost-center.*` (exact-name query against `sys_permissions` and `sys_role_has_permissions_jnt` on `xyz_school_00000000000040008000_202627`) |
| What a user does here | Maintains a hierarchical list of cost centers. A user creates a center with a code, name, category, optional parent, optional campus and optional in-charge; edits it; toggles it active/inactive; moves it to the trash; restores it; or permanently deletes it. |
| Tables written | `acc_cost_centers`, `sys_activity_logs` |
| Tables read | `acc_cost_centers`, `acc_cost_categories`, `acc_campuses`, `sys_users`; on create also `acc_financial_years` and `acc_accounting_periods` through `AccountingContext` |
| Live data | `acc_cost_centers` 12 live, 0 trashed; `acc_cost_categories` 6; `acc_campuses` 4; `sys_users` 5,636 (all active) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No. The controller is not production-ready until the blocker and the four high findings are fixed. The single worst finding is CSCT-01 together with CSCT-05: re-creating a cost center whose code or name belongs to a trashed row passes validation, the database rejects the insert, and the user is shown the raw SQL error. The parent picker also allows a descendant (CSCT-06), which can corrupt the materialised path and recurse forever, and restore mutates data over GET (CSCT-07). Rough effort is S–M, about one developer-day for CSCT-01, CSCT-05, CSCT-06, CSCT-09, CSCT-11 and the Pint pass; the restore-route change is a module-wide decision because the shared trash component has 373 call sites.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 4 | 6 | 4 | 3 | 15 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CSCT-01, CSCT-02, CSCT-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | CSCT-04 | F9 Queries/Perf | CSCT-08, CSCT-12 |
| F3 Authorization | CSCT-10 | F10 Views | CSCT-13 |
| F4 Validation | CSCT-05, CSCT-06 | F11 Security/Tenancy | clean |
| F5 Routes | CSCT-07 | F12 Style | CSCT-15 |
| F6 Controller shape | CSCT-09, CSCT-11 | F13 Deep read | CSCT-14 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/CostCenterController.php` | controller | 253 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/CostCenter.php` | model | 262 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/CostCenterRequest.php` | FormRequest | 80 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | model base | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 5 | `Modules/Accounting/app/Models/CostCategory.php` | model | 64 | ↗ [gaurav/Accounting/CostCategoryController](../CostCategoryController/01-report.md) | ↗ linked |
| 6 | `Modules/Accounting/app/Models/Campus.php` | model | 83 | ↗ [gaurav/Accounting/CampusController](../CampusController/01-report.md) | ↗ linked |
| 7 | `Modules/SchoolSetup/app/Models/User.php` | model | 317 | ↗ [tarun/TeacherPortal-done/MobileTeacherDashboardController](../../../tarun/TeacherPortal-done/MobileTeacherDashboardController/01-report.md) | ↗ linked |
| 8 | `Modules/Accounting/app/Services/AccountingContext.php` | service (reached through the model base) | 110 | unclaimed shared — see §7 | ⚠ cross-cutting |
| 9 | `Modules/GlobalMaster/app/Models/ActivityLog.php` | model (reached through `activityLog()`) | 50 | unclaimed shared — see §7 | ⚠ cross-cutting |
| 10 | `Modules/Accounting/resources/views/cost-center/create.blade.php` | view | 194 | this report | ✅ |
| 11 | `Modules/Accounting/resources/views/cost-center/edit.blade.php` | view | 195 | this report | ✅ |
| 12 | `Modules/Accounting/resources/views/cost-center/show.blade.php` | view | 212 | this report | ✅ |
| 13 | `Modules/Accounting/resources/views/cost-center/trash.blade.php` | view | 69 | this report | ✅ |
| 14 | `Modules/Accounting/resources/views/cost-center/index.blade.php` | view | 90 | this report | ❌ never rendered — `index()` redirects to the setup-masters tab |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/cost-center                                  accounting.cost-center.index        Modules\Accounting\Http\Controllers\CostCenterController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/cost-center                                  accounting.cost-center.store        Modules\Accounting\Http\Controllers\CostCenterController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cost-center/create                           accounting.cost-center.create       Modules\Accounting\Http\Controllers\CostCenterController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cost-center/trash/view                       accounting.cost-center.trashed      Modules\Accounting\Http\Controllers\CostCenterController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cost-center/{cost_center}                    accounting.cost-center.show         Modules\Accounting\Http\Controllers\CostCenterController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/cost-center/{cost_center}                    accounting.cost-center.update       Modules\Accounting\Http\Controllers\CostCenterController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/cost-center/{cost_center}                    accounting.cost-center.destroy      Modules\Accounting\Http\Controllers\CostCenterController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cost-center/{cost_center}/edit               accounting.cost-center.edit         Modules\Accounting\Http\Controllers\CostCenterController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/cost-center/{cost_center}/toggle-status      accounting.cost-center.toggleStatus Modules\Accounting\Http\Controllers\CostCenterController@toggleStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/cost-center/{id}/force-delete                accounting.cost-center.forceDelete  Modules\Accounting\Http\Controllers\CostCenterController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cost-center/{id}/restore                     accounting.cost-center.restore      Modules\Accounting\Http\Controllers\CostCenterController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none — all 10 public methods have a route (see the list above).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 20 | GET /accounting/cost-center | `tenant.accounting.cost-center.viewAny` | none | none | none | CSCT-11 |
| `create` | 27 | GET /accounting/cost-center/create | `tenant.accounting.cost-center.create` | none | none | none | CSCT-08, CSCT-09, CSCT-11 |
| `store` | 39 | POST /accounting/cost-center | `tenant.accounting.cost-center.create` | controller (manual) | `Created` | `acc_cost_centers`, `sys_activity_logs` | CSCT-01, CSCT-03, CSCT-04, CSCT-10 |
| `show` | 72 | GET /accounting/cost-center/{cost_center} | `tenant.accounting.cost-center.view` | none | none | none | CSCT-11 |
| `edit` | 89 | GET /accounting/cost-center/{cost_center}/edit | `tenant.accounting.cost-center.update` | none | none | none | CSCT-08, CSCT-09, CSCT-11 |
| `update` | 101 | PUT/PATCH /accounting/cost-center/{cost_center} | `tenant.accounting.cost-center.update` | controller (manual) | `Updated` | `acc_cost_centers`, `sys_activity_logs` | CSCT-01, CSCT-03, CSCT-04, CSCT-06, CSCT-10 |
| `destroy` | 131 | DELETE /accounting/cost-center/{cost_center} | `tenant.accounting.cost-center.delete` | controller (manual) | `Trashed` | `acc_cost_centers`, `sys_activity_logs` | CSCT-01, CSCT-03, CSCT-04, CSCT-14 |
| `toggleStatus` | 163 | POST /accounting/cost-center/{cost_center}/toggle-status | `tenant.accounting.cost-center.update` | controller (manual) | `Toggled` | `acc_cost_centers`, `sys_activity_logs` | CSCT-01, CSCT-03, CSCT-04 |
| `trashed` | 191 | GET /accounting/cost-center/trash/view | `tenant.accounting.cost-center.restore` | none | none | none | none |
| `restore` | 200 | GET /accounting/cost-center/{id}/restore | `tenant.accounting.cost-center.restore` | controller (manual) | `Restored` | `acc_cost_centers`, `sys_activity_logs` | CSCT-01, CSCT-02, CSCT-03, CSCT-04, CSCT-07 |
| `forceDelete` | 227 | DELETE /accounting/cost-center/{id}/force-delete | `tenant.accounting.cost-center.forceDelete` | controller (manual) | `Deleted` | `acc_cost_centers`, `sys_activity_logs` | CSCT-01, CSCT-02, CSCT-03, CSCT-04, CSCT-14 |

## 6. Findings

### F1 — Errors

#### CSCT-01 · B · ERR-01 — The raw exception text is shown to the user in six write paths

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCenterController.php:68, 127, 159, 187, 223, 250`, methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Every mutation has its own `try/catch (\Throwable)` and appends `$e->getMessage()` to the flash or JSON message. `QueryException` extends `RuntimeException`, so a duplicate key, a foreign-key failure or a trigger error reaches the browser as SQL text. |
| **Consequence** | A user who submits a duplicate code sees the database error (for example `SQLSTATE[23000] ... uq_acc_cc_code`) instead of "That code is already taken"; table and column names are exposed. |
| **Reproduce** | Create a cost center with the code of a trashed center; validation passes (CSCT-05), the insert fails, and the red flash contains the SQL error. |
| **Fix approach** | Remove the `try/catch` (D1) and let `bootstrap/app.php` render the error. Keep a fixed message only if a D2 shape ever applies. Plan item CSCT-01 rewrites all six methods. |
| **Plan item** | CSCT-01 in `02-fix-plan.md` §1 |

```php
// CostCenterController.php:61-68 — CURRENT
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Cost Center', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Cost Center: ' . $e->getMessage());
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "getMessage"
64:                'error' => $e->getMessage(),
68:            return back()->withInput()->with('error', 'Failed to create Cost Center: ' . $e->getMessage());
124:                'error' => $e->getMessage(),
127:            return back()->withInput()->with('error', 'Failed to update Cost Center: ' . $e->getMessage());
156:                'error' => $e->getMessage(),
159:            return back()->with('error', 'Failed to delete Cost Center: ' . $e->getMessage());
185:            Log::error('Failed to toggle Cost Center status', ['id' => $costCenter->id, 'error' => $e->getMessage()]);
187:            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
221:            Log::error('Failed to restore Cost Center', ['id' => $id, 'error' => $e->getMessage()]);
223:            return back()->with('error', 'Failed to restore Cost Center: ' . $e->getMessage());
248:            Log::error('Failed to force delete Cost Center', ['id' => $id, 'error' => $e->getMessage()]);
250:            return back()->with('error', 'Failed to delete Cost Center: ' . $e->getMessage());
```

#### CSCT-02 · H · ERR-02 — A missing record becomes a redirect instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCenterController.php:206` (`restore()`), `:233` (`forceDelete()`) |
| **Root cause** | `findOrFail()` sits inside the `try`, and `catch (\Throwable $e)` swallows `ModelNotFoundException`, redirects back and flashes "Failed to restore" or "Failed to delete". |
| **Consequence** | A restore or force-delete URL for an id that is not in the expected state (already restored, already deleted, or a stale link) shows a red flash instead of a 404, so the operator cannot tell a bad link from a server failure. |
| **Reproduce** | Open `/accounting/cost-center/999999/restore` while logged in as School Admin; expected 404, actual redirect with "Failed to restore Cost Center". |
| **Fix approach** | Move `findOrFail()` above the transaction; the D1 rewrite in CSCT-01 removes the `try` entirely. |
| **Plan item** | CSCT-01 in `02-fix-plan.md` §1 |

```php
// CostCenterController.php:204-207 — CURRENT
        DB::beginTransaction();
        try {
            $model = CostCenter::onlyTrashed()->findOrFail($id);
            $model->restore();
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "findOrFail|catch \("
61:        } catch (\Throwable $e) {
120:        } catch (\Throwable $e) {
152:        } catch (\Throwable $e) {
183:        } catch (\Throwable $e) {
206:            $model = CostCenter::onlyTrashed()->findOrFail($id);
219:        } catch (\Throwable $e) {
233:            $model = CostCenter::withTrashed()->findOrFail($id);
246:        } catch (\Throwable $e) {
```

#### CSCT-03 · M · ERR-05 — The log records the message string, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCenterController.php:63-66, 122-125, 154-157, 185, 221, 248` |
| **Root cause** | The catches call `Log::error(..., ['error' => $e->getMessage()])`; `store()` also stores `getTraceAsString()` as text. No exception object is passed, so the handler cannot render or group the failure. |
| **Consequence** | Production debugging is slower: the log has a string, not the exception class and stack, and nothing is reported to the central handler. |
| **Reproduce** | Static only — a log inspection is needed after forcing any write failure. |
| **Fix approach** | Let the exception escape (D1) so the central handler logs the object; if a D2 catch is ever kept, use `report($e)`. |
| **Plan item** | CSCT-01 in `02-fix-plan.md` §1 |

```php
// CostCenterController.php:63-66 — CURRENT
            Log::error('Failed to create Cost Center', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "Log::error"
63:            Log::error('Failed to create Cost Center', [
122:            Log::error('Failed to update Cost Center', [
154:            Log::error('Failed to trash Cost Center', [
185:            Log::error('Failed to toggle Cost Center status', ['id' => $costCenter->id, 'error' => $e->getMessage()]);
221:            Log::error('Failed to restore Cost Center', ['id' => $id, 'error' => $e->getMessage()]);
248:            Log::error('Failed to force delete Cost Center', ['id' => $id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### CSCT-04 · M · TXN-02 — Six methods hand-roll beginTransaction/commit/rollBack

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCenterController.php:46-57, 105-116, 135-148, 169-180, 204-216, 231-243` |
| **Root cause** | Each mutation opens a transaction by hand and guards it with a controller `try/catch` (D1 forbids that shape). A future early `return` between `beginTransaction()` and `commit()` leaves the connection inside an open transaction. |
| **Consequence** | The write paths are fragile: one added early return or throw can leak a transaction and make later queries on the same request behave unpredictably. |
| **Reproduce** | Static only — the current paths reach commit or rollBack, but the shape is not safe to extend. |
| **Fix approach** | Wrap each mutation in `DB::transaction(function () { … })`; build the redirect/JSON after the closure. CSCT-01 does this for all six methods. |
| **Plan item** | CSCT-01 in `02-fix-plan.md` §1 |

```php
// CostCenterController.php:46-57 — CURRENT
        DB::beginTransaction();
        try {
            $costCenter = CostCenter::create($validated);

            activityLog($costCenter, 'Created', [
                'message'      => 'Cost Center created: ' . $costCenter->name,
                'code'         => $costCenter->code,
                'name'         => $costCenter->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "DB::beginTransaction|DB::commit|DB::rollBack"
46:        DB::beginTransaction();
57:        DB::commit();
62:            DB::rollBack();
105:        DB::beginTransaction();
116:        DB::commit();
121:            DB::rollBack();
135:        DB::beginTransaction();
148:        DB::commit();
153:            DB::rollBack();
169:        DB::beginTransaction();
180:        DB::commit();
184:            DB::rollBack();
204:        DB::beginTransaction();
216:        DB::commit();
220:            DB::rollBack();
231:        DB::beginTransaction();
243:        DB::commit();
247:            DB::rollBack();
```

### F3 — Authorization

#### CSCT-10 · L · AUTH-04 — create/update permission is checked twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *do not authorize the same permission twice; keep one* |
| **Where** | `Modules/Accounting/app/Http/Requests/CostCenterRequest.php:15-18` and `Modules/Accounting/app/Http/Controllers/CostCenterController.php:41, 103` |
| **Root cause** | `CostCenterRequest::authorize()` maps POST to `...create` and PUT/PATCH to `...update`; the controller then calls `Gate::authorize()` with the same two names. |
| **Consequence** | No runtime difference; a future permission rename or policy change must be made in two places, and one copy can drift. |
| **Reproduce** | Static only — inspect the FormRequest and the two controller methods. |
| **Fix approach** | Keep the FormRequest check for `store`/`update` and remove the two duplicate `Gate::authorize()` lines (folded into the CSCT-01 rewrite). |
| **Plan item** | none — covered by CSCT-01; see `02-fix-plan.md` §10 |

```php
// CostCenterController.php:41 and :103 — CURRENT
        Gate::authorize('tenant.accounting.cost-center.create');
        Gate::authorize('tenant.accounting.cost-center.update');
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\CostCenterRequest.php","Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "authorizeByCrudPermission|Gate::authorize"
CostCenterRequest.php:17:        return $this->authorizeByCrudPermission('tenant.accounting.cost-center');
CostCenterController.php:41:        Gate::authorize('tenant.accounting.cost-center.create');
CostCenterController.php:103:        Gate::authorize('tenant.accounting.cost-center.update');
```

### F4 — Validation and input

#### CSCT-05 · H · VAL-04 — Soft-deleted codes and names pass validation but violate the unique index

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules must mirror the DB unique index, including soft-delete semantics* |
| **Where** | `Modules/Accounting/app/Http/Requests/CostCenterRequest.php:31, 37-40`; index from `database/migrations/tenant/2026_09_16_100012_create_acc_cost_centers_table.php:38-39` |
| **Root cause** | Both `Rule::unique()` calls add `->whereNull('deleted_at')`, so the validator ignores trashed rows, but `uq_acc_cc_code` (`code`) and `uq_acc_cc_cat_name` (`cost_category_id`, `name`) have no `deleted_at` column and still count them. |
| **Consequence** | Re-creating a center with the code or category+name of a trashed center passes validation and then fails the insert; the raw SQL error is shown to the user through CSCT-01. |
| **Reproduce** | Trash a cost center, then create a new one with the same code; validation passes, the insert throws a duplicate-key error. |
| **Fix approach** | Remove `->whereNull('deleted_at')` from both rules so validation matches the database index. |
| **Plan item** | CSCT-05 in `02-fix-plan.md` §5 |

```php
// CostCenterRequest.php:27-41 — CURRENT
            'code'              => [
                'required',
                'string',
                'max:20',
                Rule::unique('acc_cost_centers', 'code')->ignore($id)->whereNull('deleted_at'),
            ],
            'name'              => [
                'required',
                'string',
                'max:120',
                Rule::unique('acc_cost_centers', 'name')
                    ->where(fn ($q) => $q->where('cost_category_id', $this->input('cost_category_id')))
                    ->ignore($id)
                    ->whereNull('deleted_at'),
            ],
```

**Evidence**
```
> mysql -e "SELECT INDEX_NAME, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA='xyz_school_00000000000040008000_202627' AND TABLE_NAME='acc_cost_centers' AND NON_UNIQUE=0 GROUP BY INDEX_NAME;"
PRIMARY	id
uq_acc_cc_cat_name	cost_category_id,name
uq_acc_cc_code	code

> Select-String -Path "Modules\Accounting\app\Http\Requests\CostCenterRequest.php" -Pattern "whereNull"
31:                Rule::unique('acc_cost_centers', 'code')->ignore($id)->whereNull('deleted_at'),
40:                    ->whereNull('deleted_at'),
```

#### CSCT-06 · H · VAL-07 — The parent picker allows a descendant, creating a cycle

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M default; raised to H because a cycle makes `recalculateChildrenTree()` recurse forever) — *cross-field/business checks belong in the FormRequest* |
| **Where** | `Modules/Accounting/app/Http/Requests/CostCenterRequest.php:42-46`; `Modules/Accounting/app/Models/CostCenter.php:237-243, 61-72, 81-90` |
| **Root cause** | `Rule::notIn([$id])` blocks only self, and `selectableParents()` excludes only `$excludeId`; neither checks the parent's `path` against the current record's `path`. The `updating` hook then writes a path through the descendant, and `updated` calls `recalculateChildrenTree()` on a cyclic graph. |
| **Consequence** | An edit that selects a sub-center as its own parent corrupts the materialised path and can hang or 500 the request with unbounded recursion. |
| **Reproduce** | Create a parent and a child, open the parent's edit page, choose the child in "Parent Cost Center", and submit. |
| **Fix approach** | Add an `after()` validation hook that rejects any parent whose `path` starts with the current record's `path`. |
| **Plan item** | CSCT-06 in `02-fix-plan.md` §5 |

```php
// CostCenterRequest.php:42-46 — CURRENT
            'parent_id'         => [
                'nullable',
                'exists:acc_cost_centers,id',
                Rule::notIn(array_filter([$id])),
            ],
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\CostCenterRequest.php" -Pattern "notIn|parent_id"
42:            'parent_id'         => [
45:                Rule::notIn(array_filter([$id])),

> Select-String -Path "Modules\Accounting\app\Models\CostCenter.php" -Pattern "selectableParents|recalculateChildrenTree|parent_id"
76:            $model->recalculateChildrenTree();
81:    public function recalculateChildrenTree(): void
83:        $children = static::where('parent_id', $this->id)->get();
88:            $child->recalculateChildrenTree();
237:    public static function selectableParents($excludeId = null)
239:        return static::active()
240:            ->when($excludeId, fn ($q) => $q->where('id', '!=', $excludeId))
```

### F5 — Routes

#### CSCT-07 · H · RTE-01 — Restoring a cost center changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection* |
| **Where** | `Modules/Accounting/routes/web.php:177`; `Modules/Accounting/app/Http/Controllers/CostCenterController.php:200-218` |
| **Root cause** | The restore route is `Route::get`, and the trash view's action is a link; any prefetch, crawler or authenticated GET restores the record. |
| **Consequence** | A browser prefetch or a pasted URL can restore a trashed cost center without an explicit confirmation or CSRF token. |
| **Reproduce** | Open `/accounting/cost-center/{id}/restore` directly for a trashed center; it is restored with a success flash. |
| **Fix approach** | Move the action to POST/DELETE. The route file is shared and the shared `x-backend.table.action-trashed` component has 373 call sites, so this is a module-wide decision. |
| **Plan item** | CSCT-07 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// Modules/Accounting/routes/web.php:177 — CURRENT
Route::get('/cost-center/{id}/restore', [CostCenterController::class, 'restore'])->name('cost-center.restore');
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "cost-center.*restore"
177:Route::get('/cost-center/{id}/restore', [CostCenterController::class, 'restore'])->name('cost-center.restore');

> (Select-String -Path "Modules\*\resources\views\**\*.blade.php" -Pattern "x-backend.table.action-trashed").Count
373
```

### F6 — Controller shape

#### CSCT-09 · M · CTL-05 — create() and edit() duplicate the four dropdown loaders

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste dropdown loaders shared by create/edit* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCenterController.php:31-34, 93-96` |
| **Root cause** | The same four queries are written twice; the edit copy differs only in the `$costCenter->id` argument. A later change to one form silently diverges from the other. |
| **Consequence** | The create and edit pages can show different categories, campuses or users after the next edit to one copy. |
| **Reproduce** | Static only — compare the two blocks. |
| **Fix approach** | Extract one private `formData(?int $excludeId = null): array` and call it from both actions. |
| **Plan item** | CSCT-09 in `02-fix-plan.md` §5 |

```php
// CostCenterController.php:31-34 — CURRENT
        $costCenters    = CostCenter::selectableParents();
        $costCategories = CostCategory::where('is_active', true)->orderBy('name')->get();
        $campuses       = Campus::where('is_active', true)->orderBy('ordinal')->get();
        $users          = User::orderBy('name')->get();
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "selectableParents|CostCategory::where|Campus::where|User::orderBy"
31:        $costCenters    = CostCenter::selectableParents();
32:        $costCategories = CostCategory::where('is_active', true)->orderBy('name')->get();
33:        $campuses       = Campus::where('is_active', true)->orderBy('ordinal')->get();
34:        $users          = User::orderBy('name')->get();
93:        $costCenters    = CostCenter::selectableParents($costCenter->id);
94:        $costCategories = CostCategory::where('is_active', true)->orderBy('name')->get();
95:        $campuses       = Campus::where('is_active', true)->orderBy('ordinal')->get();
96:        $users          = User::orderBy('name')->get();
```

#### CSCT-11 · L · CTL-04 — Eight public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCenterController.php:20, 27, 39, 72, 89, 101, 131, 163` |
| **Root cause** | Only `trashed()`, `restore()` and `forceDelete()` declare a return type; the other eight methods declare none. |
| **Consequence** | No runtime effect; the response contract is invisible to static analysis and to the next developer. |
| **Reproduce** | Static only — inspect the signatures. |
| **Fix approach** | Add `RedirectResponse`, `View` and `JsonResponse` return types to the eight signatures. |
| **Plan item** | CSCT-11 in `02-fix-plan.md` §8 |

```php
// CostCenterController.php:20-163 — CURRENT signatures
    public function index()
    public function create()
    public function store(CostCenterRequest $request)
    public function show(CostCenter $costCenter)
    public function edit(CostCenter $costCenter)
    public function update(CostCenterRequest $request, CostCenter $costCenter)
    public function destroy(CostCenter $costCenter)
    public function toggleStatus(Request $request, CostCenter $costCenter)
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "public function"
20:    public function index()
27:    public function create()
39:    public function store(CostCenterRequest $request)
72:    public function show(CostCenter $costCenter)
89:    public function edit(CostCenter $costCenter)
101:    public function update(CostCenterRequest $request, CostCenter $costCenter)
131:    public function destroy(CostCenter $costCenter)
163:    public function toggleStatus(Request $request, CostCenter $costCenter)
191:    public function trashed(): \Illuminate\View\View
200:    public function restore($id): \Illuminate\Http\RedirectResponse
227:    public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

### F7 — Models

clean — `php -l Modules\Accounting\app\Models\CostCenter.php` → `No syntax errors detected`; `$table = 'acc_cost_centers'` exists in `database/migrations/tenant/2026_09_16_100012_create_acc_cost_centers_table.php`; `$fillable` lists 10 columns; `$casts` covers `is_active` (boolean), `depth` (integer) and `path` (string); `SoftDeletes` is present and the table has `deleted_at`; every relationship is return-typed (`protected function` scopes excepted).

### F8 — Services and jobs

clean — `Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "Service|Job|dispatch|queue"` → no output (the controller calls no service and dispatches no job; `AccountingContext` is reached only through the model base).

### F9 — Queries and performance

#### CSCT-08 · M · QRY-15 — The create/edit forms load all 5,636 users

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *do not load every row of a big table for a form; also QRY-03 (select only the columns used)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCenterController.php:34, 96` |
| **Root cause** | `User::orderBy('name')->get()` selects every column of every tenant user. The live tenant has 5,636 users, all active, and the query runs on every create and edit page. |
| **Consequence** | Each form load hydrates thousands of models and renders a 5,636-option `<select>`; the page is slow and memory-heavy, and the picker is unusable without search. |
| **Reproduce** | Open `/accounting/cost-center/create` and count the In-Charge options. |
| **Fix approach** | Use a searchable AJAX picker, or at minimum select `id`, `name` and the display column and filter active users. The UI choice is a decision. |
| **Plan item** | CSCT-08 in `02-fix-plan.md` §9 (DECISION) |

```php
// CostCenterController.php:34 and :96 — CURRENT
        $users          = User::orderBy('name')->get();
```

**Evidence**
```
> mysql -e "SELECT COUNT(*), SUM(is_active=1) FROM xyz_school_00000000000040008000_202627.sys_users;"
5636	5636

> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "User::orderBy"
34:        $users          = User::orderBy('name')->get();
96:        $users          = User::orderBy('name')->get();
```

#### CSCT-12 · M · QRY-01 — recalculateChildrenTree() runs one query per child

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H default; lowered to M because the live tree has 12 rows and no hierarchy yet) — *no queries inside loops* |
| **Where** | `Modules/Accounting/app/Models/CostCenter.php:81-90` (called from `updated()` at `:74-78`) |
| **Root cause** | The recursion calls `where('parent_id', $this->id)->get()` once per node and `saveQuietly()` once per child, so a parent change with N descendants runs N+1 reads and N writes. |
| **Consequence** | Editing a center in a deep or wide tree becomes slow; with today's 12 flat rows the cost is negligible. |
| **Reproduce** | Static only — create a large tree and measure the edit. |
| **Fix approach** | Load all descendants in one query and update paths in chunks, or accept at current volume. |
| **Plan item** | none — see `02-fix-plan.md` §10 (accepted at current volume; revisit when the tree grows) |

```php
// CostCenter.php:81-90 — CURRENT
    public function recalculateChildrenTree(): void
    {
        $children = static::where('parent_id', $this->id)->get();
        foreach ($children as $child) {
            $child->depth = $this->depth + 1;
            $child->path = $this->path . $child->id . '/';
            $child->saveQuietly();
            $child->recalculateChildrenTree();
        }
    }
```

**Evidence**
```
> mysql -e "SELECT COUNT(*) AS cc_total, SUM(parent_id IS NOT NULL) AS children FROM xyz_school_00000000000040008000_202627.acc_cost_centers;"
12	0

> Select-String -Path "Modules\Accounting\app\Models\CostCenter.php" -Pattern "where\('parent_id'|saveQuietly|recalculateChildrenTree"
83:        $children = static::where('parent_id', $this->id)->get();
87:            $child->saveQuietly();
88:            $child->recalculateChildrenTree();
```

### F10 — Views

#### CSCT-13 · L · CTL-10 — The index view is orphaned and reads an attribute that does not exist

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *no dead code; dead views and unused files are dead code* |
| **Where** | `Modules/Accounting/resources/views/cost-center/index.blade.php:41-42, 78` |
| **Root cause** | `index()` redirects to the setup-masters tab; the real list is `pages/partials/setup-masters/_cost-centers.blade.php`, rendered by `AccDashboardController::setupMasters()`. Nothing references `accounting::cost-center.index`. The orphan also reads `$costCenter->category`, but `CostCenter` exposes `costCategory()`, not `category`, and calls `hasPages()` on a collection that may not be a paginator. |
| **Consequence** | No user sees it today. If someone re-points `index()` at this view, every Category cell shows "-" and pagination can fail on a plain collection. |
| **Reproduce** | Static only — `Select-String -Path ... -Pattern "cost-center.index"` returns no output. |
| **Fix approach** | Delete the orphan, or repair it (`costCategory?->name`, paginated data) if it is meant to be the real list. |
| **Plan item** | none — see `02-fix-plan.md` §10 (dead file; cleanup pass) |

```php
// index.blade.php:41-42 — CURRENT
                                                @if($costCenter->category)
                                                    <span class="badge bg-light text-dark border px-3 py-2 fs-6 shadow-sm"><i class="fas fa-layer-group text-muted me-1"></i>{{ $costCenter->category }}</span>
```

**Evidence**
```
> (Select-String -Path "Modules\Accounting\resources\views\**\*.blade.php" -Pattern "cost-center.index").Count
0

> Select-String -Path "Modules\Accounting\app\Models\CostCenter.php" -Pattern "getCategoryAttribute|category\(" 
no output
```

### F11 — Security and tenancy

clean — `Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "env\(|\?\? 1|DB::raw|whereRaw|Log::.*request"` → no output. The controller uses no raw SQL, no hard-coded ids, no `env()` and no request payload logging; every route carries the tenant middleware group (see §4).

### F12 — Style

#### CSCT-15 · L · STY-02 — Pint fails on all three in-scope PHP files

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCenterController.php`; `Modules/Accounting/app/Http/Requests/CostCenterRequest.php`; `Modules/Accounting/app/Models/CostCenter.php` |
| **Root cause** | The controller fails `fully_qualified_strict_types`, `concat_space`, `ordered_imports` and `binary_operator_spaces`; the request fails `ordered_imports` and `binary_operator_spaces`; the model fails nine fixers including `no_unused_imports`, `not_operator_with_successor_space` and `blank_line_before_statement`. |
| **Consequence** | The style gate fails, and the next Pint run rewrites large parts of the file, creating review noise. |
| **Reproduce** | `vendor\bin\pint --test <file> --format agent` on each file. |
| **Fix approach** | Run Pint on the three files; the controller's `\Illuminate\View\View` / `\Illuminate\Http\RedirectResponse` return types are converted to imports. |
| **Plan item** | CSCT-15 in `02-fix-plan.md` §8 |

```php
// CostCenterController.php:7-16 — CURRENT imports (Pint asks for View / RedirectResponse imports)
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Modules\Accounting\Http\Requests\CostCenterRequest;
use Modules\Accounting\Models\Campus;
use Modules\Accounting\Models\CostCategory;
use Modules\Accounting\Models\CostCenter;
use Modules\SchoolSetup\Models\User;
```

**Evidence**
```
> vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\CostCenterController.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\CostCenterController.php","fixers":["fully_qualified_strict_types","concat_space","ordered_imports","binary_operator_spaces"]}]}

> vendor\bin\pint --test "Modules\Accounting\app\Http\Requests\CostCenterRequest.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\CostCenterRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}

> vendor\bin\pint --test "Modules\Accounting\app\Models\CostCenter.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\CostCenter.php","fixers":["new_with_parentheses","fully_qualified_strict_types","concat_space","unary_operator_spaces","no_unused_imports","not_operator_with_successor_space","blank_line_before_statement","ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 Wrong data? | Q2 Delete before replacement? | Q3 Duplicate implementation? | Q4 Soft-delete × unique? | Q5 Race? | Q6 Auth hole? | Q7 Message lies? | Q8 Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | CSCT-05 | ok | CSCT-10 | ok | ok |
| `update` | CSCT-06 | ok | CSCT-09 | CSCT-05 | ok | CSCT-10 | ok | ok |
| `destroy` | CSCT-14 | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | CSCT-14 | ok | ok | ok | ok | ok | ok | ok |

#### CSCT-14 · M · F13-Q1 — Trashing a parent leaves active children pointing at a hidden parent

| Field | Value |
|---|---|
| **Rule** | F13 deep-read Q1 (M) — *a write must not overwrite or orphan data it should not* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCenterController.php:137-139`; `Modules/Accounting/app/Models/CostCenter.php:158-166` |
| **Root cause** | `destroy()` soft-deletes only the selected row. Children keep `parent_id` and `is_active = true`. The setup list starts from roots (`whereNull('parent_id')`), so the children disappear from the tree, while `selectableParents()` (active rows) still offers them. |
| **Consequence** | After trashing a parent, its sub-centers vanish from the list but remain selectable as parents and in dropdowns; the hierarchy is inconsistent and the operator has no way to see the orphaned rows. |
| **Reproduce** | Create a parent and a child, trash the parent, then open the Cost Centers tab; the child is gone from the tree but still appears in the Parent dropdown. |
| **Fix approach** | Decide whether to block trashing a center that has active children (safest) or cascade the soft delete to descendants. |
| **Plan item** | CSCT-14 in `02-fix-plan.md` §9 (DECISION) |

```php
// CostCenterController.php:137-139 — CURRENT
            $costCenter->is_active = false;
            $costCenter->save();
            $costCenter->delete();
```

**Evidence**
```
> mysql -e "SELECT COUNT(*) AS cc_total, SUM(parent_id IS NOT NULL) AS children, SUM(deleted_at IS NOT NULL) AS trashed FROM xyz_school_00000000000040008000_202627.acc_cost_centers;"
12	0	0

> Select-String -Path "Modules\Accounting\app\Http\Controllers\AccDashboardController.php" -Pattern "whereNull\('parent_id'\)"
224:                $costCentersQuery->whereNull('parent_id');
227:            $costCentersQuery->whereNull('parent_id');
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Services/AccountingContext.php:89-100, 106-108` | `getCampusId()` returns the literal `1` when no session or user campus exists, and `getUserId()` returns `Auth::id() ?? 1`; every Accounting create can silently stamp campus/user 1. | SEC-03 | unclaimed shared service — needs an owner in `_Info/00-CLASS-OWNERS.md` |
| `Modules/GlobalMaster/app/Models/ActivityLog.php:9, 35-47` | The `subject()` and `user()` relationship methods have no return types (MDL-04), and a commented-out factory import remains on line 9 (STY-04). | MDL-04, STY-04 | GlobalMaster owner — unclaimed shared model |
| `database/migrations/tenant/2026_06_15_161019_create_acc_cost_centers_table.php` | A second `Schema::create('acc_cost_centers')` exists alongside `2026_09_16_100012_create_acc_cost_centers_table.php`; the 06_15 migration creates the table first, so a fresh tenant migration reaches a duplicate-table error at 09_16. The live tenant already has the v4.8 columns. | MDL-07 / standing migration rule | not fixed by this workflow — migrations are out of bounds |

## 8. Not covered, and why

- **Scanner and self-check skipped.** `final-audit-reports/_tools/scanfilter.py` and `final-audit-reports/_tools/selfcheck.py` are missing, and `scan.php` must not be run under the tooling override. F1–F13 were checked manually with `read`, `Select-String`, `php -l`, `route:list` and Pint.
- **No tests run** (D4). No browser render was performed; the four in-scope blades were read, not compiled in a browser.
- **The actual list pane is not in scope.** `AccDashboardController::setupMasters()` and `pages/partials/setup-masters/_cost-centers.blade.php` render the Cost Centers tab; their filters and unbounded `->get()` belong to the AccDashboardController report.
- **Linked classes were not re-audited.** `BaseAccountingModel`, `Campus`, `CostCategory` and `SchoolSetup\User` are owned elsewhere; this report checked only how the controller uses them.
- **`AccountingContext` and the GlobalMaster `ActivityLog`** are unclaimed shared classes. They were read and are recorded in §7; they are not fixed here.
