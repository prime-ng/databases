# Final Audit — Accounting / BankStatementEntryController

**Audited:** 2026-10-24 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php` (214 lines, 11 routed public methods plus the constructor)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/cheques-reconciliation?tab=bank-statement-entries` (the list — rendered by `AccDashboardController`, not this controller) · `http://test.localhost:8000/accounting/bank-statement-entry` (this controller's `index`, which immediately redirects to the tab) · `/accounting/bank-statement-entry/create` · `/accounting/bank-statement-entry/{id}` (show) · `/accounting/bank-statement-entry/{id}/edit` · `/accounting/bank-statement-entry/trash/view` |
| Menu path | Accounting → Cheques & Reconciliation → Bank Statement Entries tab (`glb_menus` id 1034, route `accounting.menu.chequesReconciliation`) |
| Who uses it | Super Admin, School Admin, Management, Account Staff, Account Manager — the 5 roles that hold `tenant.accounting.bank-statement-entry.create` in `sys_role_has_permissions_jnt` on tenant `xyz_school_…_202627` |
| What a user does here | Records one line of a bank statement by hand (date, debit or credit, reference), or excludes a line that is not the school's. A line can be viewed, edited, soft-deleted, restored from the trash, or permanently deleted. Matching a line to an accounting voucher is done elsewhere (Reconciliation Matches), which is why the match status shown here is derived from another table. |
| Tables written | `acc_bank_statement_entries` (insert / update / soft delete / restore / hard delete), `sys_activity_logs` (one row per mutation). A permanent delete also cascades `acc_bank_reconciliation_matches` rows through the foreign key. |
| Tables read | `acc_bank_statement_entries`, `acc_bank_reconciliations`, `acc_ledgers`, `acc_bank_reconciliation_matches`, `acc_voucher_items`, `acc_vouchers`, `sys_users` |
| Live data | `acc_bank_statement_entries` 7 live, 0 trashed (4 `Matched`, 0 `Excluded`) · `acc_bank_reconciliations` 2 · `acc_bank_reconciliation_matches` 4 · `sys_activity_logs` 405 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No — this controller is not production-ready. The single worst finding is BKSE-01: all five write methods catch every failure and flash the raw exception text (SQL, table and constraint names) into the red error box while logging only that text, so a normal duplicate-key or foreign-key failure shows the user internal SQL. Behind it sit two data-integrity defects: `store()` silently writes the entry against the *first* bank account when no ledger is chosen (BKSE-06), and nothing on the server stops a user editing or permanently deleting an entry that is already reconciled (BKSE-20). Rough effort to clear the plan: M, about 3–4 hours of careful edits, no migration.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 6 | 7 | 6 | 3 | 20 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BKSE-01, BKSE-02, BKSE-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | BKSE-04 | F9 Queries/Perf | BKSE-15, BKSE-16 |
| F3 Authorization | BKSE-05 | F10 Views | clean |
| F4 Validation | BKSE-06, BKSE-07 | F11 Security/Tenancy | clean |
| F5 Routes | BKSE-08 | F12 Style | BKSE-17, BKSE-18, BKSE-19 |
| F6 Controller shape | BKSE-09, BKSE-10, BKSE-11 | F13 Deep read | BKSE-20 |
| F7 Models | BKSE-12, BKSE-13, BKSE-14 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php` | controller | 214 | this report | ✅ |
| 2 | `Modules/Accounting/app/Http/Requests/BankStatementEntryRequest.php` | FormRequest | 108 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Models/BankStatementEntry.php` | model | 176 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/resources/views/bank-statement-entry/create.blade.php` | blade | 170 | this report | ✅ |
| 5 | `Modules/Accounting/resources/views/bank-statement-entry/edit.blade.php` | blade | 188 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/bank-statement-entry/show.blade.php` | blade | 196 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/bank-statement-entry/trash.blade.php` | blade | 61 | this report | ✅ |
| 8 | `Modules/Accounting/app/Models/BankReconciliation.php` | model | 242 | ↗ [gaurav/Accounting/BankReconciliationController](../BankReconciliationController/01-report.md) | ↗ linked (report not written yet; the index row is `CLAIMED`) |
| 9 | `Modules/Accounting/app/Models/Ledger.php` | model | 408 | ↗ [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) | ↗ linked |
| 10 | `Modules/Accounting/app/Models/BankReconciliationMatch.php` | model | 96 | ↗ [gaurav/Accounting/BankReconciliationMatchController](../BankReconciliationMatchController/01-report.md) | ↗ linked (report not written yet; the index row is `CLAIMED`) |
| 11 | `Modules/Accounting/app/Services/ReconciliationService.php` | service | 397 | unclaimed | ❌ not audited — injected into the constructor but never called from this controller; see §7 and §8 |
| 12 | `app/Helpers/activityLog.php` | helper (common) | 51 | common, §4.2 | ❌ not audited — usage checked only |
| 13 | `app/Traits/AuthorizesTenantFeature.php` | trait (common) | 56 | common, §4.2 | ❌ not audited — usage checked only |
| 14 | `resources/views/components/backend/table/action-trashed.blade.php` | shared component | 110 | common, §4.2 | ❌ not audited — usage checked only |
| 15 | `Modules/Accounting/routes/web.php` | route file | 536 | shared route file | ❌ not audited — the 5 route lines for this controller were read (245–249) |
| 16 | `database/migrations/tenant/2026_09_16_100031_create_acc_bank_statement_entries_table.php` | migration | 70 | frozen (never edited) | evidence only |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/bank-statement-entry                         accounting.bank-statement-entry.index Modules\Accounting\Http\Controllers\BankStatementEntryController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/bank-statement-entry                         accounting.bank-statement-entry.store Modules\Accounting\Http\Controllers\BankStatementEntryController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/bank-statement-entry/create                  accounting.bank-statement-entry.create Modules\Accounting\Http\Controllers\BankStatementEntryController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/bank-statement-entry/trash/view              accounting.bank-statement-entry.trashed Modules\Accounting\Http\Controllers\BankStatementEntryController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/bank-statement-entry/{bank_statement_entry}  accounting.bank-statement-entry.show Modules\Accounting\Http\Controllers\BankStatementEntryController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/bank-statement-entry/{bank_statement_entry}  accounting.bank-statement-entry.update Modules\Accounting\Http\Controllers\BankStatementEntryController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/bank-statement-entry/{bank_statement_entry}  accounting.bank-statement-entry.destroy Modules\Accounting\Http\Controllers\BankStatementEntryController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/bank-statement-entry/{bank_statement_entry}/edit accounting.bank-statement-entry.edit Modules\Accounting\Http\Controllers\BankStatementEntryController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/bank-statement-entry/{bank_statement_entry}/exclude accounting.bank-statement-entry.exclude Modules\Accounting\Http\Controllers\BankStatementEntryController@exclude  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/bank-statement-entry/{id}/force-delete       accounting.bank-statement-entry.forceDelete Modules\Accounting\Http\Controllers\BankStatementEntryController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/bank-statement-entry/{id}/restore            accounting.bank-statement-entry.restore Modules\Accounting\Http\Controllers\BankStatementEntryController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none — all 11 public methods appear in the route list above.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 21 | GET `/accounting/bank-statement-entry` | `tenant.accounting.bank-statement-entry.viewAny` | none | none | none (redirect only) | — |
| `create` | 28 | GET `…/create` | `tenant.accounting.bank-statement-entry.create` | none | none | none | BKSE-10, BKSE-15 |
| `store` | 38 | POST `/accounting/bank-statement-entry` | `tenant.accounting.bank-statement-entry.create` (controller + FormRequest) | controller, line 59 | `Created` | `acc_bank_statement_entries`, `sys_activity_logs` | BKSE-01, BKSE-02, BKSE-03, BKSE-05, BKSE-06, BKSE-13 |
| `show` | 78 | GET `…/{bank_statement_entry}` | `tenant.accounting.bank-statement-entry.view` | none | none | none | — |
| `edit` | 87 | GET `…/{bank_statement_entry}/edit` | `tenant.accounting.bank-statement-entry.update` | none | none | none | BKSE-10, BKSE-15 |
| `update` | 98 | PUT/PATCH `…/{bank_statement_entry}` | `tenant.accounting.bank-statement-entry.update` (controller + FormRequest) | controller, line 105 | `Updated` | `acc_bank_statement_entries`, `sys_activity_logs` | BKSE-01, BKSE-02, BKSE-03, BKSE-05, BKSE-06, BKSE-14, BKSE-20 |
| `destroy` | 122 | DELETE `…/{bank_statement_entry}` | `tenant.accounting.bank-statement-entry.delete` | controller, line 127 | `Deleted` | `acc_bank_statement_entries` (soft delete), `sys_activity_logs` | BKSE-01, BKSE-02, BKSE-03, BKSE-13, BKSE-20 |
| `trashed` | 143 | GET `…/trash/view` | `tenant.accounting.bank-statement-entry.restore` | none | none | none | BKSE-16 |
| `restore` | 152 | GET `…/{id}/restore` | `tenant.accounting.bank-statement-entry.restore` | controller, line 157 | `Restored` | `acc_bank_statement_entries`, `sys_activity_logs` | BKSE-01, BKSE-02, BKSE-03, BKSE-08, BKSE-11, BKSE-13 |
| `forceDelete` | 173 | DELETE `…/{id}/force-delete` | `tenant.accounting.bank-statement-entry.forceDelete` | controller, line 178 | `ForceDeleted` | `acc_bank_statement_entries`, `acc_bank_reconciliation_matches` (FK cascade), `sys_activity_logs` | BKSE-01, BKSE-02, BKSE-03, BKSE-11, BKSE-20 |
| `exclude` | 194 | POST `…/{bank_statement_entry}/exclude` | `tenant.accounting.bank-statement-entry.update` | none | `Excluded` | `acc_bank_statement_entries`, `sys_activity_logs` | BKSE-04, BKSE-07, BKSE-20 |

## 6. Findings

### F1 — Errors

#### BKSE-01 · B · ERR-01 — Every write failure flashes the raw exception text to the user

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:69-71`, `113-115`, `134-136`, `165-166`, `186-187` — methods `store()`, `update()`, `destroy()`, `restore()`, `forceDelete()` |
| **Root cause** | Each write is wrapped in a generic `catch (\Throwable $e)` whose flash message concatenates `$e->getMessage()`. A `QueryException` therefore renders the failing SQL statement, the table name and the constraint name in the red error box. The same text is also written to the log instead of the exception object (ERR-05). |
| **Consequence** | A user who creates a duplicate statement line (the unique key `uq_acc_bse_hash`) sees raw SQL such as `Duplicate entry … for key 'uq_acc_bse_hash'` instead of a plain message — internal schema disclosure on a normal user path. |
| **Reproduce** | Delete an entry, then create an identical manual entry (same date, description, debit/credit). The insert collides with the trashed row's unique key and the flash shows the SQL error. |
| **Fix approach** | Delete the five catches (D1); let `DB::transaction` roll back and the central handler render the error. |
| **Plan item** | BKSE-01 and BKSE-02 in `02-fix-plan.md` §1 |

```php
// BankStatementEntryController.php:69-71 — CURRENT
        } catch (\Throwable $e) {
            Log::error('Bank Statement Entry create failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to create statement entry: ' . $e->getMessage())->withInput();
        }
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "getMessage|catch"
69:        } catch (\Throwable $e) {
70:            Log::error('Bank Statement Entry create failed: ' . $e->getMessage());
71:            return back()->with('error', 'Failed to create statement entry: ' . $e->getMessage())->withInput();
113:        } catch (\Throwable $e) {
114:            Log::error('Bank Statement Entry update failed: ' . $e->getMessage());
115:            return back()->with('error', 'Failed to update statement entry: ' . $e->getMessage())->withInput();
134:        } catch (\Throwable $e) {
135:            Log::error('Bank Statement Entry delete failed: ' . $e->getMessage());
136:            return back()->with('error', 'Failed to delete statement entry: ' . $e->getMessage());
165:        } catch (\Throwable $e) {
166:            return back()->with('error', 'Failed to restore entry: ' . $e->getMessage());
186:        } catch (\Throwable $e) {
187:            return back()->with('error', 'Failed to permanently delete entry: ' . $e->getMessage());
```

#### BKSE-02 · H · ERR-02 — A missing trashed entry becomes a red flash instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:156-167` (`restore()`), `177-188` (`forceDelete()`) |
| **Root cause** | `findOrFail($id)` sits inside the `try`, and the generic `catch (\Throwable)` swallows `ModelNotFoundException`. The 404 is re-rendered as a `back()` redirect carrying the exception text. |
| **Consequence** | A stale trash tab or a double-clicked restore shows "Failed to restore entry: No query results for model …" instead of a 404, and the failure is logged as a controller failure. |
| **Reproduce** | Open `/accounting/bank-statement-entry/999999/restore` while logged in. Expected 404; actual redirect to the previous page with a red flash. |
| **Fix approach** | Remove the catch (D1) and keep `findOrFail` outside any catch; the central handler returns 404. |
| **Plan item** | BKSE-02 in `02-fix-plan.md` §1 |

```php
// BankStatementEntryController.php:156-167 — CURRENT
        try {
            DB::transaction(function () use ($id) {
                $item = BankStatementEntry::onlyTrashed()->findOrFail($id);
                $item->restore();
                activityLog($item, 'Restored', [
                    'message'      => 'Bank Statement Entry restored.',
                    'performed_by' => auth()->id(),
                ]);
            });
        } catch (\Throwable $e) {
            return back()->with('error', 'Failed to restore entry: ' . $e->getMessage());
        }
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "findOrFail"
158:$item = BankStatementEntry::onlyTrashed()->findOrFail($id);
179:$item = BankStatementEntry::withTrashed()->findOrFail($id);
```

#### BKSE-03 · M · ERR-00 — Five controller try/catch blocks contradict D1 and log only the message

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M — raised from unset to M: it is five copies of a forbidden construct, not one) — *D1: the Laravel idiom; no try/catch in controllers* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:58-72`, `104-116`, `126-137`, `156-167`, `177-188` |
| **Root cause** | Every mutation is hand-wrapped in `try { DB::transaction(...) } catch (\Throwable)`. `DB::transaction` already rolls back and rethrows; the central renderer in `bootstrap/app.php` already logs and renders. The catch adds nothing and is the vehicle for BKSE-01/BKSE-02. `Log::error('…' . $e->getMessage())` also loses the trace (ERR-05). |
| **Consequence** | Every failure on this screen is reported in a different shape from the rest of the application, and debugging has only a message string instead of a stack trace. |
| **Reproduce** | Static only — the construct is visible in the file; no browser action is needed. |
| **Fix approach** | Delete the five catches and the now-unused `Log` import. |
| **Plan item** | BKSE-01 and BKSE-02 in `02-fix-plan.md` §1 |

```php
// BankStatementEntryController.php:58-72 — CURRENT
        try {
            $entry = DB::transaction(function () use ($validated) {
                $entry = BankStatementEntry::create($validated);

                activityLog($entry, 'Created', [
                    'message'      => 'Bank Statement Entry created.',
                    'performed_by' => auth()->id(),
                ]);

                return $entry;
            });
        } catch (\Throwable $e) {
            Log::error('Bank Statement Entry create failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to create statement entry: ' . $e->getMessage())->withInput();
        }
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "try \{"
58:        try {
104:        try {
126:        try {
156:        try {
177:        try {
```

### F2 — Transactions and audit

#### BKSE-04 · H · TXN-01 — `exclude()` writes the entry and the audit row with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write runs inside one `DB::transaction`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:202-210`, method `exclude()` |
| **Root cause** | The method updates `acc_bank_statement_entries` and then inserts `sys_activity_logs` as two independent statements. The other five mutations use `DB::transaction`; this one does not. |
| **Consequence** | If the audit insert fails (for example `user_id` is null after a session expiry), the entry is marked `Excluded` with no audit row; the screen then claims the action succeeded while the trail is incomplete. |
| **Reproduce** | Static only — it needs a forced failure of the audit insert, otherwise the two statements simply run one after the other. |
| **Fix approach** | Wrap the `update()` and `activityLog()` in one `DB::transaction` closure and read the value from `validate()`. |
| **Plan item** | BKSE-04 in `02-fix-plan.md` §3 |

```php
// BankStatementEntryController.php:198-210 — CURRENT
        $request->validate([
            'exclude_reason' => 'required|string|max:500',
        ]);

        $bankStatementEntry->update([
            'match_status'   => 'Excluded',
            'exclude_reason' => $request->input('exclude_reason'),
        ]);

        activityLog($bankStatementEntry, 'Excluded', [
            'message'      => 'Bank Statement Entry excluded: ' . $request->input('exclude_reason'),
            'performed_by' => auth()->id(),
        ]);
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "DB::transaction"
59:$entry = DB::transaction(function () use ($validated) {
105:DB::transaction(function () use ($bankStatementEntry, $validated) {
127:DB::transaction(function () use ($bankStatementEntry) {
157:DB::transaction(function () use ($id) {
178:DB::transaction(function () use ($id) {
# no line between 194 and 213, i.e. exclude() has none
```

### F3 — Authorization

#### BKSE-05 · L · AUTH-04 — `store()` and `update()` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice; keep one* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:40` and `100`; `Modules/Accounting/app/Http/Requests/BankStatementEntryRequest.php:15-18` |
| **Root cause** | `BankStatementEntryRequest::authorize()` maps POST→`.create` and PUT/PATCH→`.update` through `AuthorizesTenantFeature`; the controller then calls `Gate::authorize()` with the identical string. The FormRequest check already ran before the controller method. |
| **Consequence** | No user-visible effect today. It doubles the Gate work and invites the two copies to drift when the permission is renamed. |
| **Reproduce** | Static only — the duplicate is visible in the file. |
| **Fix approach** | Keep the FormRequest check (it runs first) and delete the two controller `Gate::authorize` lines. |
| **Plan item** | BKSE-05 in `02-fix-plan.md` §4 |

```php
// BankStatementEntryController.php:38-40 — CURRENT
    public function store(BankStatementEntryRequest $request)
    {
        Gate::authorize('tenant.accounting.bank-statement-entry.create');
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Requests\BankStatementEntryRequest.php" -Pattern "authorizeByCrudPermission"
17:        return $this->authorizeByCrudPermission('tenant.accounting.bank-statement-entry');
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "Gate::authorize"
23:        Gate::authorize('tenant.accounting.bank-statement-entry.viewAny');
30:        Gate::authorize('tenant.accounting.bank-statement-entry.create');
40:        Gate::authorize('tenant.accounting.bank-statement-entry.create');
80:        Gate::authorize('tenant.accounting.bank-statement-entry.view');
89:        Gate::authorize('tenant.accounting.bank-statement-entry.update');
100:        Gate::authorize('tenant.accounting.bank-statement-entry.update');
124:        Gate::authorize('tenant.accounting.bank-statement-entry.delete');
145:        Gate::authorize('tenant.accounting.bank-statement-entry.restore');
154:        Gate::authorize('tenant.accounting.bank-statement-entry.restore');
175:        Gate::authorize('tenant.accounting.bank-statement-entry.forceDelete');
196:        Gate::authorize('tenant.accounting.bank-statement-entry.update');
```

### F4 — Validation and input

#### BKSE-06 · H · VAL-05 — A blank bank account is silently replaced by the first bank account in the ledger

| Field | Value |
|---|---|
| **Rule** | VAL-05 (H) — *every field is typed; a write path with no reference validation is H* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:46-56`; `Modules/Accounting/app/Http/Requests/BankStatementEntryRequest.php:23-24` |
| **Root cause** | `reconciliation_id` and `bank_ledger_id` are validated only as `integer` — no `exists:` rule — and when `bank_ledger_id` is blank the controller falls back to `Ledger::bankAccounts()->value('id')`, the first bank account in table order. An invalid `reconciliation_id` therefore still produces an insert, either against the wrong bank account or against an FK that then fails. |
| **Consequence** | A statement line saved without choosing a bank account can be booked to an unrelated bank account, so the reconciliation for the expected account is short by that amount and another account is over by it. The screen still says "created successfully". |
| **Reproduce** | Static only for the silent substitution; the misbooking needs a tenant with more than one bank ledger and an entry submitted with the Bank Account select left on "Auto-detect". |
| **Fix approach** | Add `exists:` rules for both ids and replace the first-bank-account fallback with a derivation from the validated reconciliation; fail loudly if that reconciliation has no ledger. |
| **Plan item** | BKSE-06 in `02-fix-plan.md` §5 |

```php
// BankStatementEntryController.php:46-56 — CURRENT
        if (empty($validated['bank_ledger_id']) && !empty($validated['reconciliation_id'])) {
            $recon = BankReconciliation::find($validated['reconciliation_id']);
            if ($recon) {
                $validated['bank_ledger_id'] = $recon->bank_ledger_id;
            }
        }

        if (empty($validated['bank_ledger_id'])) {
            $firstBank = \Modules\Accounting\Models\Ledger::bankAccounts()->value('id');
            $validated['bank_ledger_id'] = $firstBank;
        }
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Requests\BankStatementEntryRequest.php" -Pattern "exists"
# no output
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "bankAccounts" 
54:            $firstBank = \Modules\Accounting\Models\Ledger::bankAccounts()->value('id');
```

#### BKSE-07 · L · VAL-02 — `exclude()` validates inline instead of in a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M → lowered to L: one field, one endpoint, and the rule is complete) — *validation belongs in a Form Request except a one-field AJAX toggle* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:198-200` |
| **Root cause** | `$request->validate([...])` is called in the controller. It is not an AJAX toggle, but it is a single field and the check is correct as written. |
| **Consequence** | The rule lives away from the other rules for this resource; a future second field would have to be validated in the controller too. |
| **Reproduce** | Static only. |
| **Fix approach** | Accepted inline for a single field; the plan only switches the read to the validated array (part of BKSE-04). |
| **Plan item** | none — see plan §10 |

```php
// BankStatementEntryController.php:198-200 — CURRENT
        $request->validate([
            'exclude_reason' => 'required|string|max:500',
        ]);
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "validate\("
198:        $request->validate([
```

### F5 — Routes

#### BKSE-08 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:246`; `BankStatementEntryController.php:152` |
| **Root cause** | The route is `Route::get('/bank-statement-entry/{id}/restore', …)`. Restoring writes two tables. A browser prefetch, a crawler or a pasted URL restores the row with no confirmation and no CSRF token. |
| **Consequence** | An entry can be restored by opening a link — for example from a chat message, a bookmark or a link prefetcher — without the user pressing the Restore button. |
| **Reproduce** | Log in and open `http://test.localhost:8000/accounting/bank-statement-entry/{id}/restore` directly. The entry is restored. |
| **Fix approach** | Make the route `DELETE`; `x-backend.table.action-trashed` already reads the route verb and emits a POST form with `@method('DELETE')` (component lines 22–40). |
| **Plan item** | BKSE-02 in `02-fix-plan.md` §1 |

```php
// routes/web.php:246 — CURRENT
Route::get('/bank-statement-entry/{id}/restore', [\Modules\Accounting\Http\Controllers\BankStatementEntryController::class, 'restore'])->name('bank-statement-entry.restore');
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\routes\web.php" -Pattern "bank-statement-entry.\{id\}"
246: Route::get('/bank-statement-entry/{id}/restore', [\Modules\Accounting\Http\Controllers\BankStatementEntryController::class, 'restore'])->name('bank-statement-entry.restore');
247: Route::delete('/bank-statement-entry/{id}/force-delete', [\Modules\Accounting\Http\Controllers\BankStatementEntryController::class, 'forceDelete'])->name('bank-statement-entry.forceDelete');
```

### F6 — Controller shape

#### BKSE-09 · M · CTL-10 — `ReconciliationService` is injected and never used

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: unused private methods, unused properties* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:15` and `19` |
| **Root cause** | The constructor promotes `ReconciliationService` to a readonly property, but no method in the class reads `$this->service`. The service is the owner of `import()` and `autoMatch()`, neither of which this screen calls. |
| **Consequence** | Every request instantiates the service (and its dependencies) for nothing, and a reader assumes this controller does reconciliation work when it does not. |
| **Reproduce** | Static only. |
| **Fix approach** | Remove the constructor and the import. |
| **Plan item** | BKSE-09 in `02-fix-plan.md` §2 |

```php
// BankStatementEntryController.php:15-19 — CURRENT
use Modules\Accounting\Services\ReconciliationService;

class BankStatementEntryController extends Controller
{
    public function __construct(private readonly ReconciliationService $service) {}
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern '\$this->service'
# no output
```

#### BKSE-10 · M · CTL-05 — `create()` and `edit()` repeat the same two dropdown queries

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: dropdown loaders shared by create/edit* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:32-35` and `92-95` |
| **Root cause** | The same `BankReconciliation::with('bankLedger')…->get()` and `Ledger::selectableBankAccounts()` pair is written twice, with the Ledger class named by its full namespace both times. |
| **Consequence** | A change to the picker (a new filter, a column) must be made twice; forgetting one makes the edit screen offer a different set from the create screen. |
| **Reproduce** | Static only. |
| **Fix approach** | Extract one private `formData()` method and call it from both actions. |
| **Plan item** | BKSE-10 in `02-fix-plan.md` §2 |

```php
// BankStatementEntryController.php:32-35 — CURRENT
        $reconciliations = BankReconciliation::with('bankLedger')->where('is_active', true)->orderByDesc('statement_date')->get();
        $bankLedgers = \Modules\Accounting\Models\Ledger::selectableBankAccounts();

        return view('accounting::bank-statement-entry.create', compact('reconciliations', 'bankLedgers'));
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "orderByDesc\('statement_date'\)"
32:        $reconciliations = BankReconciliation::with('bankLedger')->where('is_active', true)->orderByDesc('statement_date')->get();
92:        $reconciliations = BankReconciliation::with('bankLedger')->where('is_active', true)->orderByDesc('statement_date')->get();
```

#### BKSE-11 · M · CTL-03 — `restore()` and `forceDelete()` take an integer id instead of a bound model

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:152`, `158`; `173`, `179` |
| **Root cause** | Both methods declare `int $id` and query inside the transaction. The routes name the parameter `{id}`. Every other action in this controller uses binding. |
| **Consequence** | The record is loaded twice on the success path and the method cannot be routed from a resource-style URL. No user-visible effect today. |
| **Reproduce** | Static only. |
| **Fix approach** | Bind `BankStatementEntry $bankStatementEntry` on both routes with `->withTrashed()`, and keep `abort_unless($bankStatementEntry->trashed(), 404)` in `restore()`. |
| **Plan item** | BKSE-02 in `02-fix-plan.md` §1 (same route edit) |

```php
// BankStatementEntryController.php:152-158 — CURRENT
    public function restore(int $id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.bank-statement-entry.restore');

        try {
            DB::transaction(function () use ($id) {
                $item = BankStatementEntry::onlyTrashed()->findOrFail($id);
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "public function restore|public function forceDelete"
152:    public function restore(int $id): \Illuminate\Http\RedirectResponse
173:    public function forceDelete(int $id): \Illuminate\Http\RedirectResponse
$ Select-String -LiteralPath "Modules\Accounting\routes\web.php" -Pattern "restore|force-delete"
246: Route::get('/bank-statement-entry/{id}/restore', [\Modules\Accounting\Http\Controllers\BankStatementEntryController::class, 'restore'])->name('bank-statement-entry.restore');
247: Route::delete('/bank-statement-entry/{id}/force-delete', [\Modules\Accounting\Http\Controllers\BankStatementEntryController::class, 'forceDelete'])->name('bank-statement-entry.forceDelete');
```

### F7 — Models

#### BKSE-12 · M · MDL-04 — `creator()` and `matchedByUser()` point at columns the table does not have

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L → raised to M: calling either relation is a SQL 500) — *relationships have return types and resolve* |
| **Where** | `Modules/Accounting/app/Models/BankStatementEntry.php:96-104` |
| **Root cause** | The model declares `belongsTo(..., 'created_by')` and `belongsTo(..., 'matched_by')`, but the live table `acc_bank_statement_entries` has neither column (the 2026-09-16 create migration does not add them; only the dropped legacy 2026-06-15 table had `matched_by`). `creator()` appears to be a copy of the pattern used by other Accounting models. |
| **Consequence** | Any blade or report that reads `$entry->creator` or `$entry->matchedByUser` fails with "Unknown column 'created_by'"; today nothing reads them, so the defect is latent. |
| **Reproduce** | Static only — proven against the live schema, not by calling the relation. |
| **Fix approach** | Either delete the two relations (recommended: nothing reads them) or add the two columns by migration (a DECISION, because a migration is required). |
| **Plan item** | BKSE-12 in `02-fix-plan.md` §9 (DECISION) |

```php
// BankStatementEntry.php:96-104 — CURRENT
    public function creator(): BelongsTo
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'created_by');
    }

    public function matchedByUser(): BelongsTo
    {
        return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'matched_by');
    }
```

**Evidence**
```
$ mysql -uroot -e "select column_name from information_schema.columns where table_schema='xyz_school_00000000000040008000_202627' and table_name='acc_bank_statement_entries' order by ordinal_position;"
COLUMN_NAME
id
reconciliation_id
bank_ledger_id
transaction_date
value_date
description
reference
instrument_no
debit
credit
balance
entry_type
source_row_no
row_hash
row_occurrence
match_status
matched_amount
exclude_reason
reconciler_remarks
created_at
updated_at
is_active
deleted_at
```

#### BKSE-13 · H · VAL-04 — A soft-deleted line still holds the unique key, so re-adding it fails with a 500

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules mirror the DB unique index including soft-delete semantics* |
| **Where** | `Modules/Accounting/app/Models/BankStatementEntry.php:136-141`; index `uq_acc_bse_hash` in `database/migrations/tenant/2026_09_16_100031_create_acc_bank_statement_entries_table.php:44` |
| **Root cause** | The `creating` hook computes `row_occurrence` as `count(live rows with this hash) + 1`. The count query uses the model's default scope, so soft-deleted rows are invisible — but the unique index `(reconciliation_id, row_hash, row_occurrence)` does not exclude them. Deleting occurrence 1 and creating the same line again produces occurrence 1 again and a duplicate-key error. |
| **Consequence** | After deleting a bank line, the same line cannot be entered or imported again; the user gets the raw SQL error from BKSE-01 instead of a clean duplicate warning. |
| **Reproduce** | Soft-delete entry 1 (`Matched`, recon 1), then create a manual entry with the same date/description/debit as the original. The insert fails on `uq_acc_bse_hash`. |
| **Fix approach** | Count with `withTrashed()` so the counter steps over the soft-deleted occurrence. |
| **Plan item** | BKSE-13 in `02-fix-plan.md` §5 |

```php
// BankStatementEntry.php:136-141 — CURRENT
            if (empty($entry->row_occurrence) && !empty($entry->reconciliation_id)) {
                $count = static::where('reconciliation_id', $entry->reconciliation_id)
                    ->where('row_hash', $entry->row_hash)
                    ->count();
                $entry->row_occurrence = $count + 1;
            }
```

**Evidence**
```
$ Select-String -LiteralPath "database\migrations\tenant\2026_09_16_100031_create_acc_bank_statement_entries_table.php" -Pattern "unique\(|uq_acc_bse_hash"
44:            $table->unique(['reconciliation_id', 'row_hash', 'row_occurrence'], 'uq_acc_bse_hash');
$ Select-String -LiteralPath "Modules\Accounting\app\Models\BankStatementEntry.php" -Pattern "count\(\)"
139:                    ->count();
```

#### BKSE-14 · M · MDL-06 — Editing a line leaves `row_hash` stale, so a re-import brings the old line back

| Field | Value |
|---|---|
| **Rule** | MDL-06 (M) — *data normalisation belongs in mutators/casts, not left to the caller; a derived key must be maintained where it is defined* |
| **Where** | `Modules/Accounting/app/Models/BankStatementEntry.php:123-143` (only `creating`), controller `update()` line 106 |
| **Root cause** | `row_hash` is computed in `creating` only. `update()` changes `description`, `debit`, `credit`, `balance` and dates without recomputing it, so the row keeps the hash of the original import row while its content differs. |
| **Consequence** | Re-importing the original statement file finds no live row with that hash and inserts the line a second time; the two lines can then be matched to different vouchers, double-counting the same bank movement. |
| **Reproduce** | Edit an imported line's amount, then run the statement import again: the original row is imported as new. |
| **Fix approach** | A behaviour decision (see plan §9): freeze the hash-covered fields after import, or recompute hash (and occurrence) on update. |
| **Plan item** | BKSE-14 in `02-fix-plan.md` §9 (DECISION) |

```php
// BankStatementEntry.php:123-135 — CURRENT
    protected static function booted(): void
    {
        static::creating(function (BankStatementEntry $entry) {
            if (empty($entry->row_hash)) {
                $raw = ($entry->transaction_date ? (is_string($entry->transaction_date) ? $entry->transaction_date : $entry->transaction_date->format('Y-m-d')) : '') . '|'
                     . ($entry->description ?? '') . '|'
                     . ($entry->reference ?? '') . '|'
                     . ($entry->instrument_no ?? '') . '|'
                     . number_format((float)$entry->debit, 2, '.', '') . '|'
                     . number_format((float)$entry->credit, 2, '.', '') . '|'
                     . number_format((float)($entry->balance ?? 0), 2, '.', '');
                $entry->row_hash = hash('sha256', $raw);
            }
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Models\BankStatementEntry.php" -Pattern "static::creating|static::updating|static::saving"
125:        static::creating(function (BankStatementEntry $entry) {
# no updating/saving hook
```

### F8 — Services and jobs

clean — `Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern '\$this->service'` → no output; the injected service is never called (that is BKSE-09, a dead dependency, not a service defect).

### F9 — Queries and performance

#### BKSE-15 · L · QRY-15 — The reconciliation picker loads every active reconciliation in full

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M → lowered to L: the query is already filtered to active rows and the table is tenant-scoped and small) — *don't load every row of a big table for a form* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:32` and `92` |
| **Root cause** | `get()` selects all columns and is unbounded; the form needs only `id`, `bank_ledger_id` and `statement_date`. |
| **Consequence** | Two extra wide rows per reconciliation on every create/edit page; a tenant with hundreds of reconciliations pays for columns it never renders. |
| **Reproduce** | Static only. |
| **Fix approach** | Select the three needed columns in the extracted `formData()` helper (same edit as BKSE-10). |
| **Plan item** | BKSE-10 in `02-fix-plan.md` §2 |

```php
// BankStatementEntryController.php:32 — CURRENT
        $reconciliations = BankReconciliation::with('bankLedger')->where('is_active', true)->orderByDesc('statement_date')->get();
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "->get\(\)"
32:        $reconciliations = BankReconciliation::with('bankLedger')->where('is_active', true)->orderByDesc('statement_date')->get();
92:        $reconciliations = BankReconciliation::with('bankLedger')->where('is_active', true)->orderByDesc('statement_date')->get();
```

#### BKSE-16 · M · QRY-02 — The trash list paginates at 20, not the house 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H → lowered to M: the list is paginated, only the page size is wrong) — *lists are paginated; the house size is 10* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:147` |
| **Root cause** | `paginate(20)` overrides the house default of 10. |
| **Consequence** | The trash page shows twice as many rows as every other list in the module, and pays for twice the eager-loaded reconciliation/ledger rows per request. |
| **Reproduce** | Open `…/accounting/bank-statement-entry/trash/view` with more than 10 trashed rows. |
| **Fix approach** | `paginate(10)`. |
| **Plan item** | BKSE-16 in `02-fix-plan.md` §6 |

```php
// BankStatementEntryController.php:147 — CURRENT
        $items = BankStatementEntry::onlyTrashed()->with(['reconciliation.bankLedger', 'bankLedger'])->orderByDesc('deleted_at')->paginate(20);
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "paginate\("
147:        $items = BankStatementEntry::onlyTrashed()->with(['reconciliation.bankLedger', 'bankLedger'])->orderByDesc('deleted_at')->paginate(20);
```

### F10 — Views

clean — `Select-String -Path "Modules\Accounting\resources\views\bank-statement-entry\*.blade.php" -Pattern "Model::|DB::|->get\(\)|->count\(\)|->where\("` → no output; `-Pattern "\{!!"` → no output. Relations used in `@foreach` are eager-loaded by `trashed()` and `show()`.

### F11 — Security and tenancy

clean — `Select-String -LiteralPath "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" -Pattern "env\(|->all\(|->except\(|Log::info|dd\(|dump\("` → no output. All 11 routes carry `InitializeTenancyByDomain` plus `EnsureTenantHasModule:Accounting` (see §4). Permission names exist with an exact-name query on the tenant DB (§4 evidence below).

### F12 — Style

#### BKSE-17 · L · STY-02 — The controller is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php` (whole file) |
| **Root cause** | The file has never been run through Pint; fully-qualified types in signatures and the `!empty` spacing are the visible drift. |
| **Consequence** | `vendor/bin/pint --test` fails, so the file cannot be part of a clean pre-deploy style gate. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php --format agent` |
| **Fix approach** | Run Pint on the file (one command; no hand edits). |
| **Plan item** | BKSE-17 in `02-fix-plan.md` §8 |

```php
// BankStatementEntryController.php:143 — CURRENT
    public function trashed(): \Illuminate\Contracts\View\View
```

**Evidence**
```
$ vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\BankStatementEntryController.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\BankStatementEntryController.php","fixers":["fully_qualified_strict_types","concat_space","braces_position","not_operator_with_successor_space","single_line_empty_body","blank_line_before_statement","ordered_imports","binary_operator_spaces"]}]}
```

#### BKSE-18 · L · STY-02 — `BankStatementEntryRequest` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Requests/BankStatementEntryRequest.php` (whole file) |
| **Root cause** | Import order and `=>` spacing drifted from the Laravel preset. |
| **Consequence** | `pint --test` fails on a file this plan already edits. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Http\Requests\BankStatementEntryRequest.php --format agent` |
| **Fix approach** | Run Pint on the file. |
| **Plan item** | BKSE-18 in `02-fix-plan.md` §8 |

```php
// BankStatementEntryRequest.php:67-69 — CURRENT
        return [
            'reconciliation_id'  => 'Bank Reconciliation Profile',
            'bank_ledger_id'     => 'Bank Account',
```

**Evidence**
```
$ vendor\bin\pint --test "Modules\Accounting\app\Http\Requests\BankStatementEntryRequest.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\BankStatementEntryRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
```

#### BKSE-19 · L · STY-02 — `BankStatementEntry` model is not Pint-clean (and has an unused import)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Models/BankStatementEntry.php` (whole file) |
| **Root cause** | `use App\Models\BaseModel;` is unused, and the FQCN relationships/casts do not match the preset. |
| **Consequence** | `pint --test` fails on the model this plan edits. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Models\BankStatementEntry.php --format agent` |
| **Fix approach** | Run Pint on the file (it removes the unused import too). |
| **Plan item** | BKSE-19 in `02-fix-plan.md` §8 |

```php
// BankStatementEntry.php:7 — CURRENT
use App\Models\BaseModel;
```

**Evidence**
```
$ vendor\bin\pint --test "Modules\Accounting\app\Models\BankStatementEntry.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\BankStatementEntry.php","fixers":["fully_qualified_strict_types","concat_space","cast_spaces","no_unused_imports","not_operator_with_successor_space","ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data? | 2 Deleted before replacement? | 3 Duplicate implementations? | 4 Soft-delete × unique trap? | 5 Race? | 6 Auth hole? | 7 Message that lies? | 8 Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | BKSE-06 | ok | ok | BKSE-13 | BKSE-13 | ok | ok | ok |
| `update` | BKSE-20 | ok | ok | BKSE-14 | ok | ok | ok | BKSE-14 |
| `destroy` | BKSE-20 | ok | ok | BKSE-13 | ok | ok | ok | ok |
| `restore` | ok | ok | ok | BKSE-13 | BKSE-13 | ok | ok | ok |
| `forceDelete` | BKSE-20 | BKSE-20 | ok | ok | ok | ok | ok | ok |
| `exclude` | BKSE-20 | ok | ok | ok | ok | ok | BKSE-20 | ok |

#### BKSE-20 · H · VAL-07 — A reconciled line can be re-flagged, moved or permanently deleted with no server-side guard

| Field | Value |
|---|---|
| **Rule** | VAL-07 (H — raised from M: the guard is UI-only, so a direct POST reaches it) — *business rules (a state that may not be edited) belong in the FormRequest's `after()` hook or the controller, not only in the view* |
| **Where** | `Modules/Accounting/app/Http/Controllers/BankStatementEntryController.php:98-120` (`update`), `122-141` (`destroy`), `173-192` (`forceDelete`), `194-213` (`exclude`); `BankStatementEntryRequest.php:35-36` |
| **Root cause** | `match_status` and `matched_amount` are described by the DDL as *derived from `acc_bank_reconciliation_matches`*, but the edit form posts both, the FormRequest accepts both, and `update()` writes whatever arrives. `forceDelete()` hard-deletes any line regardless of status, and the FK `fk_acc_brm_entry` is `cascadeOnDelete`, so the confirmed match row disappears silently. The only "guard" is the blade's `@if($entry->match_status !== 'Matched' …)` around the Exclude button (partial line 238), which is not a server check. |
| **Consequence** | A user can mark an unmatched line as `Matched` with no match behind it, change an already-matched line's amount/reconciliation, or permanently delete a reconciled line — each time the reconciliation reports stop agreeing with the matches table with no audit of the undo. |
| **Reproduce** | Open the edit page of a `Matched` entry (id 1, `match_status` = `Matched`), change Match Status to `Unmatched`, save. The entry becomes editable/excludable while its `Confirmed` match row still exists. |
| **Fix approach** | A behaviour decision (see plan §9): lock `match_status`/`matched_amount`/`reconciliation_id` once a confirmed match exists, and refuse `forceDelete` for such a row (or undo the match first). |
| **Plan item** | BKSE-20 in `02-fix-plan.md` §9 (DECISION) |

```php
// BankStatementEntryController.php:202-205 — CURRENT
        $bankStatementEntry->update([
            'match_status'   => 'Excluded',
            'exclude_reason' => $request->input('exclude_reason'),
        ]);
```

**Evidence**
```
$ Select-String -LiteralPath "Modules\Accounting\app\Http\Requests\BankStatementEntryRequest.php" -Pattern "match_status|matched_amount"
35:            'match_status'       => ['nullable', 'in:Unmatched,Proposed,Matched,Excluded'],
36:            'matched_amount'     => ['nullable', 'numeric', 'min:0'],
$ Select-String -LiteralPath "database\migrations\tenant\2026_09_16_100062_create_acc_bank_reconciliation_matches_table.php" -Pattern "fk_acc_brm_entry"
54:            $table->foreign('statement_entry_id', 'fk_acc_brm_entry')->references('id')->on('acc_bank_statement_entries')->cascadeOnDelete();
$ Select-String -LiteralPath "Modules\Accounting\resources\views\pages\partials\cheques-reconciliation\_bank-statement-entries.blade.php" -Pattern "match_status !== 'Matched'"
238:                                            @if($entry->match_status !== 'Matched' && $entry->match_status !== 'Excluded')
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Services/ReconciliationService.php` | Not registered in `_Info/00-CLASS-OWNERS.md`; `import()` dedupes with the default scope (soft-deleted rows invisible, same trap as BKSE-13), passes `created_by` to a table that has no such column (the value is silently dropped), and `match()` runs a per-entry matching loop. Not reached from this controller. | VAL-04, MDL-07, QRY-01 | Needs an owner — the `BankReconciliationController` index row is `CLAIMED` but its `01-report.md` does not exist yet |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | `updated_by = Auth::id() ?? 1` — a hard-coded user fallback. | SEC-03 | ↗ `gaurav/Accounting/AccountingStatusMasterController` |
| `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_bank-statement-entries.blade.php` | Renders a create **modal** that posts to the same `store()` while this controller also owns a full create **page**; two create surfaces, one of which is redundant. Also its own list paginator. | CTL-05 | ↗ `AccDashboardController` (not in this scope) |
| `resources/views/components/backend/table/action-trashed.blade.php` | No defect found: it reads the route verb (lines 22–40) and will emit `@method('DELETE')` once BKSE-08 changes the route. | — | not fixed here |
| `app/Helpers/activityLog.php` | No defect found: routes to the tenant log when tenancy is initialised, uses the authenticated user id, and stores the exception-free metadata this controller passes. | — | not fixed here |
| `app/Traits/AuthorizesTenantFeature.php` | No defect found for this controller: POST→`create`, PUT/PATCH→`update` matches the strings in `config/permissionslist.php` and the seed. | — | not fixed here |

Permission proof used for F3:

```
$ mysql -uroot -e "select name from xyz_school_00000000000040008000_202627.sys_permissions where name like 'tenant.accounting.bank-statement-entry%' order by name;"
name
tenant.accounting.bank-statement-entry.create
tenant.accounting.bank-statement-entry.delete
tenant.accounting.bank-statement-entry.forceDelete
tenant.accounting.bank-statement-entry.restore
tenant.accounting.bank-statement-entry.update
tenant.accounting.bank-statement-entry.view
tenant.accounting.bank-statement-entry.viewAny
```

```
$ Select-String -Path "config\permissionslist.php" -Pattern "bank-statement-entry"
641:        'accounting.bank-statement-entry' => $crud,
```

## 8. Not covered, and why

- **The static scanner and the self-check were skipped.** This is a binding override for this run: `final-audit-reports/_tools/scanfilter.py` and `final-audit-reports/_tools/selfcheck.py` are missing, and `scan.php` must not be run. F1–F13 were therefore worked **manually** with `read`, `Select-String`/grep, `route:list`, `php -l`, Pint and SQL. No scanner row exists for this report; the §15 PASS line cannot be produced.
- **`ReconciliationService` was not audited.** It is injected but never called here, it is not owned in `_Info/00-CLASS-OWNERS.md`, and this run is forbidden from editing that registry. Its defects are recorded in §7 only.
- **`BankReconciliation`, `Ledger`, `BankReconciliationMatch`, `BaseAccountingModel`, `activityLog` and the shared blade components were not re-audited** — they are owned or common (§4.2/D7). Only this controller's usage of them was checked.
- **The list tab itself** (`AccDashboardController::chequesReconciliation` and its partials) is another controller's screen; only the links and permission strings it shares with this controller were read.
- **No browser run and no tests** (D4). The repro paths above are static reasoning from the code, the live schema and the live row counts; the permission refusal per role was measured in SQL, not by logging in as each role.
- **Blades were read, not compiled or rendered.** `php -l` covers PHP files only; a Blade compile would need the view engine and is the fixer's §10 step.
- **Live counts are a snapshot** of tenant `xyz_school_00000000000040008000_202627` at audit time (7 entries, 0 trashed, 2 reconciliations, 4 matches).
